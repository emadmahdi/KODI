# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l1l11l_l1_ import *
import bidi.algorithm,base64
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪ㍇")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l11111ll11l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ㍈"))
	l1ll11llll_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ㍉"))
	l11l1l1l1l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ㍊"))
	l111l1ll1l1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㍋"),l1l111_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㍌"),l1l111_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭㍍"))
	l11ll111111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㍎"),l1l111_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㍏"),l1l111_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ㍐"))
	l1llll1l1l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍑"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍒"),l1l111_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ㍓"))
	half_triangular_colon = l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ㍔")
	from urllib.parse import quote as _1llll1ll1ll_l1_
else:
	l11111ll11l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ㍕"))
	l1ll11llll_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ㍖"))
	l11l1l1l1l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ㍗"))
	l111l1ll1l1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍘"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍙"),l1l111_l1_ (u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬ㍚"))
	l11ll111111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍛"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍜"),l1l111_l1_ (u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ㍝"))
	l1llll1l1l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍞"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍟"),l1l111_l1_ (u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭㍠"))
	half_triangular_colon = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ㍡").encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㍢"))
	from urllib import quote as _1llll1ll1ll_l1_
l1llll1llll1_l1_ = os.path.join(l11l1l1l1l1_l1_,l1l111_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ㍣"))
l1llllllllll_l1_ = os.path.join(l11l1l1l1l1_l1_,l1l111_l1_ (u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ㍤"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㍥"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㍦"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㍧"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨ㍨"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ㍩"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ㍪"))
l1l1ll1ll1ll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡪࡡࡵࠩ㍫"))
l1l1llll11ll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ㍬"))
l1l1l1lll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠬࡶࡡࡵࡪࠪ㍭"))
defaulticon = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ㍮"))
defaultthumb = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ㍯"))
defaultfanart = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ㍰"))
defaultbanner = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭㍱"))
defaultlandscape = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪ㍲"))
defaultposter = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨ㍳"))
defaultclearlogo = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬ㍴"))
defaultclearart = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬ㍵"))
l1ll1llll1ll_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧ㍶"))
l1lllllll1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ㍷"))
l1ll1lll111l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㍸"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㍹"),addon_id,l1l111_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ㍺"))
l1111l1l111_l1_ = os.path.join(l11111ll11l_l1_,l1l111_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࠫ㍻"),l1l111_l1_ (u"࠭ࡆࡰࡰࡷࡷࠬ㍼"),l1l111_l1_ (u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪ㍽"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠨืไีࠬ㍾"),l1l111_l1_ (u"ࠩฦ์้࠭㍿"),l1l111_l1_ (u"ࠪฯฬ์๊ࠨ㎀"),l1l111_l1_ (u"ࠫะอไฬࠩ㎁"),l1l111_l1_ (u"ࠬืวษ฻ࠪ㎂"),l1l111_l1_ (u"࠭ฮศ็ึࠫ㎃"),l1l111_l1_ (u"ࠧิษาืࠬ㎄"),l1l111_l1_ (u"ࠨีสฬ฾࠭㎅"),l1l111_l1_ (u"ࠩฮห๊์ࠧ㎆"),l1l111_l1_ (u"ࠪฮฬููࠨ㎇"),l1l111_l1_ (u"ࠫ฾อิาࠩ㎈")]
l1llllllll1l_l1_ = l1l111_l1_ (u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭㎉")
l11ll11l_l1_ = 0
l1lll11lll1l_l1_ = 30*l1l1lll1l11_l1_
l111l11l_l1_ = 2*l1l1l11l111_l1_
l11l1l1_l1_ = 16*l1l1l11l111_l1_
l1lll11ll11_l1_ = 30*l1l1l111l11_l1_
l1l11l1lll1_l1_ = 1*l1l1l11l111_l1_
l1ll11111l1l_l1_ = [l1l111_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ㎊")]
l11111ll111_l1_ = [l1l111_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ㎋"),l1l111_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㎌"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㎍"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㎎"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㎏"),l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㎐"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㎑"),l1l111_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㎒")]
l11111ll111_l1_ += [l1l111_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ㎓"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ㎔"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㎕"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㎖"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㎗"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㎘"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㎙"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㎚")]
l1l1ll1llll1_l1_ = [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㎛"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㎜"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㎝"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㎞")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㎟"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㎠"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㎡"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㎢")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㎣"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㎤"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㎥")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㎦"),l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㎧"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㎨"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㎩"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㎪"),l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㎫"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㎬")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㎭"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㎮"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㎯"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㎰"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㎱"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㎲")]
l1ll1lll1l1_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㎳"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㎴"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㎵"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㎶")]
l1ll1lll1l1_l1_ += [l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㎷"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㎸"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㎹"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㎺"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㎻")]
l1lll1111ll_l1_ = [l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㎼"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㎽"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㎾"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㎿"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㏀"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ㏁")]
l1lll1111ll_l1_ += [l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㏂"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㏃"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㏄"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㏅"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㏆"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭㏇")]
l1lll1llll1_l1_ = [l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㏈"),l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㏉"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ㏊"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㏋"),l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㏌"),l1l111_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ㏍"),l1l111_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㏎"),l1l111_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭㏏")]
l1lll1llll1_l1_ += [l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㏐"),l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㏑"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㏒"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㏓"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㏔"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭㏕")]
l1lll111111l_l1_  = [l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㏖"),l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㏗"),l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㏘"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㏙"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㏚"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㏛"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㏜"),l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ㏝"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㏞")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㏟"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㏠"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㏡"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㏢"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㏣"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㏤"),l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㏥"),l1l111_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㏦"),l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㏧")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㏨"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㏩"),l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㏪"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㏫"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ㏬"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㏭"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㏮")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㏯"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㏰"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭㏱"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㏲"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㏳"),l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㏴"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㏵")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ㏶"),l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ㏷"),l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㏸"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㏹"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㏺"),l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㏻"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㏼")]
l1ll11l111ll_l1_  = [l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㏽"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㏾"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㏿"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ㐀")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ㐁"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ㐂")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ㐃"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㐄"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㐅")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ㐆"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㐇"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ㐈")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㐉"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㐊"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㐋")]
l1ll1l111111_l1_ = [l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㐌"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㐍"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㐎"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㐏"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㐐")]
l1lll1l1111_l1_ = l1lll111111l_l1_+l1ll11l111ll_l1_
l1ll1ll1l11l_l1_ = l1lll111111l_l1_+l1ll1l111111_l1_
l1l111l11l1_l1_ = l1lll111111l_l1_+l1ll1l111111_l1_
l1lll11llll_l1_ = l1l1ll1llll1_l1_+l1lll1111ll_l1_+l1lll1llll1_l1_+l1ll1lll1l1_l1_
l1llllll1ll1_l1_ = [
						l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㐑")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭㐒")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫ㐓")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ㐔")
						,l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ㐕")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㐖")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ㐗")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬ㐘")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭㐙")
						,l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ㐚")
						,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ㐛")
						,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ㐜")
						]
l11l1ll111l_l1_ = l1llllll1ll1_l1_+[
				 l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡔࡒ࡜࡞ࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ㐝")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡋࡘ࡙ࡖࡓࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ㐞")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ㐟")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠴ࡱࡨࠬ㐠")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠴ࡷࡹ࠭㐡")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠶ࡳࡪࠧ㐢")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠵ࡸࡺࠧ㐣")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠷ࡴࡤࠨ㐤")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ㐥")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ㐦")
				,l1l111_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ㐧")
				,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭㐨")
				,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧ㐩")
				,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪ㐪")
				,l1l111_l1_ (u"࠭ࡍࡆࡐࡘࡗ࠲࡙ࡈࡐ࡙ࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ㐫")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㐬")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㐭")
				]
l1111l11lll_l1_ = [l1l111_l1_ (u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ㐮"),l1l111_l1_ (u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫ㐯"),l1l111_l1_ (u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ㐰"),l1l111_l1_ (u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭㐱"),l1l111_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ㐲"),l1l111_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ㐳")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㐴")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡱࡩࡹ࠭㐵")]
			,l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㐶")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭㐷")]
			,l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㐸")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶࠪ㐹")]
			,l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㐺")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪ㐻")]
			,l1l111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㐼")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶࠨ㐽")]
			,l1l111_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㐾")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ㐿")]
			,l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㑀")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ㑁")]
			,l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㑂")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ㑃")]
			,l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㑄")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ㑅")]
			,l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㑆")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ㑇")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㑈")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ㑉")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㑊")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ㑋")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㑌")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ㑍")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㑎")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷࡰ࡯࡮ࠨ㑏")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㑐")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡽ࡯ࡳ࡭ࠪ㑑")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㑒")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦ࡭ࡲࡧࡦࡢࡰࡶ࠲ࡨࡵ࡭ࠨ㑓")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ㑔")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠹࠲ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵࠩ㑕")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㑖")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭࡯ࡱࡺ࠲ࡨࡵ࡭ࠨ㑗")]
			,l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㑘")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ㑙"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ㑚")]
			,l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㑛")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡥ࠱ࡨࡷࡧ࡭ࡢࡵ࠺࠲ࡨࡵ࡭ࠨ㑜")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㑝")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱ࠱ࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭㑞")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ㑟")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡢࡦࡵࡷ࠲ࡸࡺ࡯ࡳࡧࠪ㑠")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭㑡")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬ㑢")]
			,l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㑣")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ㑤")]
			,l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ㑥")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦࠩ㑦")]
			,l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ㑧")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫ㑨")]
			,l1l111_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭㑩")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫ㑪")]
			,l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㑫")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭㑬")]
			,l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㑭")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡹ࡭ࡵ࠭㑮")]
			,l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㑯")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫ㑰")]
			,l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㑱")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫ㑲")]
			,l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㑳")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡻࡳࠨ㑴")]
			,l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㑵")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㑶"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭㑷"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㑸"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㑹"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨ㑺")]
			,l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㑻")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫ㑼")]
			,l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㑽")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ㑾")]
			,l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ㑿")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡲࡺ࠳ࡱࡩࡵ࡭ࡲࡸ࠳ࡺࡶࠨ㒀")]
			,l1l111_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ㒁")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭㒂"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ㒃")]
			,l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㒄")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮ࡤࡣࡰࠫ㒅")]
			,l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ㒆")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ㒇")]
			,l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㒈")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡡ࠯ࡥࡤࡱࠬ㒉")]
			,l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㒊")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪ㒋")]
			,l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㒌")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬ㒍")]
			,l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㒎")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ㒏"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㒐"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭㒑")]
			,l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㒒")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪ㒓")]
			,l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㒔")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡥ࡯࡭ࡨࡱࠧ㒕")]
			,l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㒖")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ㒗")]
			,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㒘")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ㒙")]
			,l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㒚")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㒛"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㒜"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㒝"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㒞"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㒟"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㒠"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㒡"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㒢"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ㒣")]
			,l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㒤")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㒥"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㒦"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㒧"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㒨"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㒩"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㒪"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㒫"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㒬"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㒭")]
			,l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㒮")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ㒯"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ㒰"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ㒱")]
			,l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ㒲")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㒳"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ㒴"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭㒵")]
			,l1l111_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭㒶")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭㒷"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬ㒸"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫ㒹")]
			}
l111l111111_l1_ = [l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫ㒺"),l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫ㒻"),l1l111_l1_ (u"ࠫࡊࡓࡁࡊࡎࡖࠫ㒼"),l1l111_l1_ (u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ㒽"),l1l111_l1_ (u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ㒾"),l1l111_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㒿"),l1l111_l1_ (u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭㓀"),l1l111_l1_ (u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ㓁"),l1l111_l1_ (u"ࠪࡘࡊ࡙ࡔࡊࡐࡊࠫ㓂")]
l11l11llll1_l1_ = [l1l111_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖࠫ㓃"),l1l111_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠾ࠧ㓄"),l1l111_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠹ࠨ㓅")]
class l1ll1l1111l1_l1_(l1l1ll11l1l_l1_):
	def __init__(self,*args,**kwargs):
		self.l1l11111l11_l1_ = -1
	def onClick(self,l1111l1l1ll_l1_):
		if l1111l1l1ll_l1_>=9010: self.l1l11111l11_l1_ = l1111l1l1ll_l1_-9010
		self.delete()
	def l11l11111l1_l1_(self,*args):
		self.l111l1l11l1_l1_,self.l1ll11ll1l11_l1_,self.l111l1l1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll111ll1l_l1_ = args[5],args[6]
		self.l1lll11l11l1_l1_,self.l1l1ll1l1lll_l1_,self.l1ll1111lll1_l1_ = args[7],args[8],args[9]
		if self.l1l1ll1l1lll_l1_>0 or self.l1ll1111lll1_l1_>0: self.l1ll1lll1l11_l1_ = True
		else: self.l1ll1lll1l11_l1_ = False
		self.l1lll11l11ll_l1_,self.l11l11111ll_l1_ = l1lllllllll1_l1_(self.l111l1l11l1_l1_,self.l1ll11ll1l11_l1_,self.l111l1l1lll_l1_,self.header,self.text,self.profile,self.l1lll111ll1l_l1_,self.l1lll11l11l1_l1_,self.l1ll1lll1l11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll11l11ll_l1_)
		self.getControl(9050).setHeight(self.l11l11111ll_l1_)
		if not self.l1ll11ll1l11_l1_ and self.l111l1l11l1_l1_ and self.l111l1l1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll11l11ll_l1_,self.l11l11111ll_l1_
	def l1l1111111l_l1_(self):
		if self.l1l1ll1l1lll_l1_:
			from threading import Thread
			self.l1l11l1l1ll_l1_ = Thread(target=self.l1lll1l11lll_l1_,args=())
			self.l1l11l1l1ll_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1lll1l11lll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l11l111l_l1_ in range(1,self.l1l1ll1l1lll_l1_+1):
			time.sleep(1)
			l1l1ll1lll11_l1_ = int(100*l1l11l111l_l1_/self.l1l1ll1l1lll_l1_)
			self.l1l1lllll111_l1_(l1l1ll1lll11_l1_)
			if self.l1l11111l11_l1_>0: break
		self.l11l11l1ll1_l1_()
	def l11lll1l1l1_l1_(self):
		if self.l1ll1111lll1_l1_:
			from threading import Thread
			self.l1ll1ll1l111_l1_ = Thread(target=self.l1111111ll1_l1_,args=())
			self.l1ll1ll1l111_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1111111ll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1ll1l1lll_l1_)
		for l1l11l111l_l1_ in range(self.l1ll1111lll1_l1_-1,-1,-1):
			time.sleep(1)
			l1l1ll1lll11_l1_ = int(100*l1l11l111l_l1_/self.l1ll1111lll1_l1_)
			self.l1l1lllll111_l1_(l1l1ll1lll11_l1_)
			if self.l1l11111l11_l1_>0: break
		if self.l1ll1111lll1_l1_>0: self.l1l11111l11_l1_ = 10
		self.delete()
	def l1l1lllll111_l1_(self,l1l1ll1lll11_l1_):
		self.l1ll111l11ll_l1_ = l1l1ll1lll11_l1_
		self.getControl(9020).setPercent(self.l1ll111l11ll_l1_)
	def l11l11l1ll1_l1_(self):
		if self.l111l1l11l1_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll11ll1l11_l1_: self.getControl(9011).setEnabled(True)
		if self.l111l1l1lll_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll11l11ll_l1_)
		except: pass
class l11l11ll111_l1_():
	def __init__(self,l11_l1_=False,l1ll1lll1lll_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1ll1lll1lll_l1_ = l1ll1lll1lll_l1_
		self.l11l1l1l1ll_l1_,self.l1l111l111l_l1_ = [],[]
		self.l1111l1ll11_l1_,self.l1lllll1ll11_l1_ = {},{}
		self.l111ll1lll1_l1_ = []
		self.l1l1lllll11l_l1_,self.l1ll111111ll_l1_,self.l11lllll1l1_l1_ = {},{},{}
	def l11l111ll11_l1_(self,id,func,*args):
		id = str(id)
		self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ㓆")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨࠩ㓇"),id)
		from threading import Thread
		l1l11111ll1_l1_ = Thread(target=self.run,args=(id,func,args))
		self.l111ll1lll1_l1_.append(l1l11111ll1_l1_)
		return l1l11111ll1_l1_
	def start_new_thread(self,id,func,*args):
		l1l11111ll1_l1_ = self.l11l111ll11_l1_(id,func,*args)
		l1l11111ll1_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l1lllll11l_l1_[id] = time.time()
		try:
			self.l1lllll1ll11_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪ㓈") in str(func) and not self.l1lllll1ll11_l1_[id].succeeded:
				l11111l11l1_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡦࡸࡩࠥࡺ࡯ࠡࡶ࡫ࡶࡪࡧࡤࡦࡦࠣࡓࡕࡋࡎࡖࡔࡏࠤ࡫ࡧࡩ࡭ࠩ㓉"))
			self.l11l1l1l1ll_l1_.append(id)
			self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩ࠭㓊")
		except Exception as err:
			if self.l1ll1lll1lll_l1_:
				l1111llll11_l1_ = traceback.format_exc()
				sys.stderr.write(l1111llll11_l1_)
			self.l1l111l111l_l1_.append(id)
			self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㓋")
		self.l1ll111111ll_l1_[id] = time.time()
		self.l11lllll1l1_l1_[id] = self.l1ll111111ll_l1_[id] - self.l1l1lllll11l_l1_[id]
	def l1ll1lll1ll1_l1_(self):
		for proc in self.l111ll1lll1_l1_:
			proc.start()
	def l1l1lll1111l_l1_(self):
		while l1l111_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㓌") in list(self.l1111l1ll11_l1_.values()): time.sleep(1.000)
def l1lll111l11l_l1_():
	l1ll1l1lll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㓍"))
	l111l11lll1_l1_ = True
	if l1ll1l1lll11_l1_==l1l11l1llll_l1_:
		status = l1l111_l1_ (u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫ㓎")
		l111l11lll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㓏")
		os.makedirs(addoncachefolder)
	else:
		status = l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ㓐")
		l1ll11l1111l_l1_ = [l1l111_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ㓑"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ㓒"),l1l111_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ㓓"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ㓔"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ㓕"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭㓖"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ㓗"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ㓘"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ㓙"),l1l111_l1_ (u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪ㓚")]
		l1lllll1111l_l1_ = l1ll11l1111l_l1_[-1]
		l111l1ll11l_l1_ = l1l1ll1ll1l1_l1_(l1lllll1111l_l1_)
		l1llll111l1l_l1_ = l1l1ll1ll1l1_l1_(l1l11l1llll_l1_)
		if l1llll111l1l_l1_>l111l1ll11l_l1_:
			status = l1l111_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㓛")
	return status,l111l11lll1_l1_
def l11111l1111_l1_(l1lll111lll_l1_,l1lll1lllll1_l1_):
	succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_ = True,False,False
	type,name,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_ = l1lll111lll_l1_
	l1ll11111l11_l1_ = type,name,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,l1l111_l1_ (u"ࠨࠩ㓜"),l1llllll11l_l1_
	l1ll1ll1ll1l_l1_ = int(mode)
	l1ll1ll1ll11_l1_ = int(l1ll1ll1ll1l_l1_%10)
	l1ll1ll1lll1_l1_ = int(l1ll1ll1ll1l_l1_/10)
	l1l1lll11111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㓝"))
	l111l11111l_l1_,l111l11lll1_l1_ = l1lll111l11l_l1_()
	if l111l11lll1_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㓞"),l1l111_l1_ (u"ࠫࠬ㓟"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㓠"),l1l111_l1_ (u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭㓡")+l1l11l1llll_l1_)
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㓢"),l1l111_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㓣"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㓤"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㓥"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㓦"),l1l111_l1_ (u"ࠬࡇࡕࡕࡊࠪ㓧"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㓨"),l1l111_l1_ (u"ࠧࡊࡆࡖࠫ㓩"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ㓪"),l1l111_l1_ (u"ࠩࠪ㓫"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡵࡳࡵࡣࠪ㓬"),l1l111_l1_ (u"ࠫࠬ㓭"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡤࡵࡥࡰࡧࠧ㓮"),l1l111_l1_ (u"࠭ࠧ㓯"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ㓰"),l1l111_l1_ (u"ࠨࠩ㓱"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㓲"),l1l111_l1_ (u"ࠪࠫ㓳"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㓴"),l1l111_l1_ (u"ࠬ࠭㓵"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭㓶"),l1l111_l1_ (u"ࠧࠨ㓷"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㓸"),l1l111_l1_ (u"ࠩࠪ㓹"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡲࡲࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㓺"),l1l111_l1_ (u"ࠫࠬ㓻"))
		import l1l1l11l1ll_l1_
		if l111l11111l_l1_==l1l111_l1_ (u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ㓼"):
			l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㓽"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㓾")+addon_path+l1l111_l1_ (u"ࠨࠢࡠࠫ㓿"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㔀"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㔁"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ㔂"))
		else:
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㔃"),l1l111_l1_ (u"࠭࠮ࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㔄")+addon_path+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㔅"))
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㔆"),l1l111_l1_ (u"ࠩࠪ㔇"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㔈"),l1l111_l1_ (u"ࠫฯ๋ࠠหอห๎ฯࠦร้ࠢอัิ๐หࠡษ็ษฺีวาࠢส่ัี๊ะࠢ็ฬึ์วๆฮࠣห้็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣวํࠦสๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰࠣื๏่่ๆࠢส่ว์ࠠศๆหี๋อๅอࠢหฬ฾฼ࠠศๆไัํ฻วหࠢ็ฺ๊อๆࠡ฻่่ࠥอไษำ้ห๊าࠠษื๋ีฮࠦีฮ์ะอࠥ๎ๅหๅส้้ฯࠧ㔉"))
			l11l1lllll1_l1_()
			FIX_ALL_DATABASES(False)
			l1l1l11l1ll_l1_.l1ll11l1llll_l1_()
			l1l1l11l1ll_l1_.l1l1ll11l11_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㔊"),False)
			l1l1l11l1ll_l1_.l1l1ll11l11_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ㔋"),False)
			l1l1l11l1ll_l1_.l111111111l_l1_(False)
			l1l1l11l1ll_l1_.l1ll11l1l111_l1_(False)
			l1l1l11l1ll_l1_.l111ll11l1l_l1_(l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㔌"),l1l111_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ㔍"),False)
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㔎"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㔏"),l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ㔐"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㔑"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㔒"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭㔓"),l1l111_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ㔔"))
			except: pass
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㔕"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㔖"),l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ㔗"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㔘"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㔙"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪ㔚"),l1l111_l1_ (u"ࠨ࠵ࠪ㔛"))
			except: pass
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㔜"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㔝"),l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㔞"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㔟"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㔠"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬ㔡"),l1l111_l1_ (u"ࠨ࠴ࠪ㔢"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l11llll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1ll1ll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㔣"),l1l11l1llll_l1_)
		l1l1l11l1ll_l1_.l11lll11l11_l1_(False)
	l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㔤"))
	l1l111lll1_l1_ = l11lll1llll_l1_(l1lll1lllll1_l1_)
	l1l1l1111ll_l1_ = l11lll1llll_l1_(name)
	l11111l1l11_l1_ = [0,15,17,19,26,34,50,53]
	l1lll11l1111_l1_ = [0,15,17,19,26,34,50,53]
	l11llllllll_l1_ = l1ll1ll1lll1_l1_ not in l1lll11l1111_l1_
	l1l1lll111ll_l1_ = l1ll1ll1lll1_l1_ in [23,28,71,72]
	l1lll1lll111_l1_ = l1ll1ll1ll1l_l1_ in [265,270]
	l1llllll1111_l1_ = (l11llllllll_l1_ or l1l1lll111ll_l1_) and not l1lll1lll111_l1_
	l11l1lll1l1_l1_ = l1ll11ll1l_l1_!=l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㔥") and (l1ll11ll1l_l1_!=l1l111_l1_ (u"ࠬ࠭㔦") or context==l1l111_l1_ (u"࠭ࠧ㔧"))
	l1ll1lll11l1_l1_ = l1l111_l1_ (u"ࠧࡵࡻࡳࡩࡂ࠭㔨") in l1ll11ll1l_l1_
	l1ll11l1l1l1_l1_ = l1ll1ll1ll1l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1ll1ll1ll11_l1_==9 or l1ll1ll1ll1l_l1_ in [145,516,523,45]
	l11lll1lll1_l1_ = not l1ll11l1l1l1_l1_
	l11l1l1l111_l1_ = not l1lll1_l1_
	l1llll1111ll_l1_ = l1l111lll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㔩"),l1l111_l1_ (u"ࠩ࠱࠲ࠬ㔪")]
	l111l1l1ll1_l1_ = l1llll1111ll_l1_ or l11lll1lll1_l1_
	l11111l1lll_l1_ = l1llll1111ll_l1_ or l11l1l1l111_l1_ or l1ll1lll11l1_l1_
	l1ll11111lll_l1_ = l1ll1ll1ll1l_l1_ not in [260,261,265,270,330,540]
	if l1l1lll11111_l1_: l111l1l11ll_l1_ = l1lll1_l1_ or l1ll11l1l1l1_l1_
	else: l111l1l11ll_l1_ = True
	l1ll1llll1_l1_ = l1ll1ll1lll1_l1_ in [74,75]
	l11lll11ll1_l1_ = l1ll1ll1ll1l_l1_ in [280,720]
	l111ll111l1_l1_ = not l1ll1llll1_l1_ and not l11lll11ll1_l1_
	l1l1lll11ll1_l1_ = l111l1l1ll1_l1_ and l11111l1lll_l1_ and l1ll11111lll_l1_ and l111l1l11ll_l1_ and l111ll111l1_l1_
	l11l1l111l1_l1_ = l1ll11111lll_l1_ and l111l1l11ll_l1_ and l111ll111l1_l1_
	l11ll111ll1_l1_ = l11l1l111l1_l1_
	l1l111l1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡲࡵࡳࡻ࡯ࡤࡦࡴࠪ㔫"))
	l111lll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧ㔬"))
	if 1 and l11l1lll1l1_l1_ and l1l1lll11ll1_l1_:
		l1lllll1l11l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㔭"),l1l111_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㔮")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠧࡠࠩ㔯")+l111lll1l1l_l1_,l1ll11111l11_l1_)
		if l1lllll1l11l_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࠩ㔰"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㔱")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠪࡣࠬ㔲")+l111lll1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࡍࡱࡤࡨ࡮ࡴࡧࠡ࡯ࡨࡲࡺࠦࡦࡳࡱࡰࠤࡨࡧࡣࡩࡧࠪ㔳"))
			if 1 and l1ll1lll11l1_l1_:
				l11lll1l111_l1_ = []
				from l1ll111l1l1l_l1_ import l1lllll11ll1_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1llll111111_l1_ = l1lllll11ll1_l1_
				l11lll1111l_l1_ = GET_ALL_FAVORITES()
				l1111l1llll_l1_ = l1ll11ll1l_l1_
				l11l11lllll_l1_,l11l1l1ll11_l1_,l1lll1lll11l_l1_,l1ll1ll11ll1_l1_,l11ll11l1l1_l1_,l111111ll11_l1_,l11l1l1ll1l_l1_,l1lll11ll11l_l1_,l111111l111_l1_ = EXTRACT_KODI_PATH(l1111l1llll_l1_)
				l1llll1111l1_l1_ = l11l11lllll_l1_,l11l1l1ll11_l1_,l1lll1lll11l_l1_,l1ll1ll11ll1_l1_,l11ll11l1l1_l1_,l111111ll11_l1_,l11l1l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭㔴"),l111111l111_l1_
				for l1l111l1l1l_l1_ in l1lllll1l11l_l1_:
					l1ll1l111ll1_l1_ = l1l111l1l1l_l1_[l1l111_l1_ (u"࠭࡭ࡦࡰࡸࡍࡹ࡫࡭ࠨ㔵")]
					if l1ll1l111ll1_l1_==l1llll1111l1_l1_ or l1l111l1l1l_l1_[l1l111_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ㔶")] in [265,270]:
						l1l111l1l1l_l1_ = GET_LIST_ITEM(l1ll1l111ll1_l1_,l1llll111111_l1_,l11lll1111l_l1_)
						if l1l111l1l1l_l1_[l1l111_l1_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ㔷")]:
							l1ll1l1lll1l_l1_ = GET_FAVORITES_CONTEXT_MENU(l11lll1111l_l1_,l1ll1l111ll1_l1_,l1l111l1l1l_l1_[l1l111_l1_ (u"ࠩࡱࡩࡼࡶࡡࡵࡪࠪ㔸")])
							l1l111l1l1l_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ㔹")] = l1ll1l1lll1l_l1_+l1l111l1l1l_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ㔺")]
					l11lll1l111_l1_.append(l1l111l1l1l_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㔻"),l1l111_l1_ (u"࠭ࠧ㔼"))
				if type==l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔽"): l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㔾")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠩࡢࠫ㔿")+l111lll1l1l_l1_,l1ll11111l11_l1_,l11lll1l111_l1_,l11l1l1_l1_)
			else: l11lll1l111_l1_ = l1lllll1l11l_l1_
			if type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕀") and l1l111lll1_l1_!=l1l111_l1_ (u"ࠫ࠳࠴ࠧ㕁") and l1llllll1111_l1_: l1l1ll111ll_l1_()
			l11l1ll1ll1_l1_ = CREATE_KODI_MENU(l1ll11111l11_l1_,l11lll1l111_l1_,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
			return
	elif type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕂") and l1ll11ll1l_l1_==l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㕃") and l11l1l111l1_l1_:
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㕄")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠨࡡࠪ㕅")+l111lll1l1l_l1_,l1ll11111l11_l1_)
	if l1l111_l1_ (u"ࠩࡢࠫ㕆") in context: l1lll11l1l11_l1_,l1ll1111ll11_l1_ = context.split(l1l111_l1_ (u"ࠪࡣࠬ㕇"),1)
	else: l1lll11l1l11_l1_,l1ll1111ll11_l1_ = context,l1l111_l1_ (u"ࠫࠬ㕈")
	if l1lll11l1l11_l1_ in [l1l111_l1_ (u"ࠬ࠷ࠧ㕉"),l1l111_l1_ (u"࠭࠲ࠨ㕊"),l1l111_l1_ (u"ࠧ࠴ࠩ㕋"),l1l111_l1_ (u"ࠨ࠶ࠪ㕌"),l1l111_l1_ (u"ࠩ࠸ࠫ㕍")] and l1ll1111ll11_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㕎"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㕏"))
		return
	elif l1lll11l1l11_l1_==l1l111_l1_ (u"ࠬ࠼ࠧ㕐"):
		if l1ll1111ll11_l1_==l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㕑"): l1ll1lll_l1_(l1l111_l1_ (u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧ㕒"),l1l111_l1_ (u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨ㕓"))
		elif l1ll1111ll11_l1_==l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠩ㕔"): l1ll1ll1ll1l_l1_ = 334
		l1lll_l1_ = l1ll1l11l11l_l1_(type,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,l1ll1ll1ll1l_l1_,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㕕"))
		return
	elif context==l1l111_l1_ (u"ࠫ࠼࠭㕖"):
		from l1111l11l1_l1_ import l1lll111l11_l1_
		l1lll111l11_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㕗"))
		return
	elif context==l1l111_l1_ (u"࠭࠸ࠨ㕘"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㕙")+addon_id+l1l111_l1_ (u"ࠨࡁࡰࡳࡩ࡫࠽ࠨ㕚")+str(mode)+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩ㕛"))
		return
	elif context==l1l111_l1_ (u"ࠪ࠽ࠬ㕜"):
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㕝"),l1l111_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ㕞"))
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㕟"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㕠")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㕡"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㕢"),l1l111_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ㕣")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㕤"),l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㕥"))
	if not settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭㕦")): settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ㕧"),l1111l11lll_l1_[0])
	l1l1llll1111_l1_ = False if l1l11llllll_l1_(l1l111_l1_ (u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩ㕨")) else True
	l1l111111ll_l1_ = l111l11l_l1_ if l1l1llll1111_l1_ else l11l1l1_l1_
	l11llll111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㕩"))
	l1ll1111l111_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㕪")))
	l1ll1111l111_l1_ = 0 if not l1ll1111l111_l1_ else int(l1ll1111l111_l1_)
	if l11llll111l_l1_ in [l1l111_l1_ (u"ࠫࠬ㕫"),l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㕬")] or not l1l111111ll_l1_ or not l1ll1111l111_l1_ or now-l1ll1111l111_l1_<0 or now-l1ll1111l111_l1_>l1l111111ll_l1_:
		l11llll111l_l1_ = l11111ll1l1_l1_(True,False)
	l11lllll1ll_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㕭")))
	l11lllll1ll_l1_ = 0 if not l11lllll1ll_l1_ else int(l11lllll1ll_l1_)
	l11l1l1l11l_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㕮")))
	l11l1l1l11l_l1_ = 0 if not l11l1l1l11l_l1_ else int(l11l1l1l11l_l1_)
	if not l11lllll1ll_l1_ or not l11l1l1l11l_l1_ or now-l11l1l1l11l_l1_<0 or now-l11l1l1l11l_l1_>l11lllll1ll_l1_:
		l1ll1l1ll11l_l1_ = 1
		if l1l1llll1111_l1_:
			l1ll1l11l111_l1_ = l11llll1lll_l1_(True)
			if len(l1ll1l11l111_l1_)>1:
				l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㕯"),l1l111_l1_ (u"ࠩ࠱ࠤ࡙ࠥࡨࡰࡹ࡬ࡲ࡬ࠦࡑࡶࡧࡶࡸ࡮ࡵ࡮ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㕰")+addon_path+l1l111_l1_ (u"ࠪࠤࡢ࠭㕱"))
				id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1l11l111_l1_[0]
				l1111l1ll1l_l1_,l1111l1lll1_l1_ = l11l11l1l11_l1_.split(l1l111_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ㕲"))
				del l1ll1l11l111_l1_[0]
				l1ll1ll1llll_l1_ = random.sample(l1ll1l11l111_l1_,1)
				id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1ll1llll_l1_[0]
				l1l1llllll1l_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠺ࠡࠩ㕳")+id+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㕴")+l1l1llllll1l_l1_
				l11l111ll1l_l1_ = l1l111_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ㕵")
				l1llllllll1l_l1_ = l1l111_l1_ (u"ࠨษ็ฮอืูศฬࠪ㕶")
				l111l1l11l1_l1_,l1ll11ll1l11_l1_ = l11l11l1l11_l1_,l11l111ll1l_l1_
				l111llll_l1_ = [l111l1l11l1_l1_,l1ll11ll1l11_l1_,l1llllllll1l_l1_]
				l11l1111111_l1_ = 5 if l1l11llllll_l1_(l1l111_l1_ (u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪ㕷")) else 5
				l11l111111l_l1_ = -9
				while l11l111111l_l1_<0:
					l11l1ll1111_l1_ = random.sample(l111llll_l1_,3)
					l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠪࠫ㕸"),l11l1ll1111_l1_[0],l11l1ll1111_l1_[1],l11l1ll1111_l1_[2],l1111l1ll1l_l1_,l1l1llllll1l_l1_,l1l111_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭㕹"),l11l1111111_l1_,60)
					if l11l111111l_l1_==10: break
					from l1l1l11l1ll_l1_ import l1ll1lllll1l_l1_,l1l1l1ll1ll_l1_
					if l11l111111l_l1_>=0 and l11l1ll1111_l1_[l11l111111l_l1_]==l111llll_l1_[1]:
						l1ll1lllll1l_l1_()
						if l11l111111l_l1_>=0: l11l111111l_l1_ = -9
					elif l11l111111l_l1_>=0 and l11l1ll1111_l1_[l11l111111l_l1_]==l111llll_l1_[2]:
						l1l1l1ll1ll_l1_(False)
					if l11l111111l_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㕺"),l1l111_l1_ (u"࠭ࠧ㕻"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㕼"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠาึ๎ฬࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠡๆ็าึ๎ฬࠡษ็ูา๐อࠡลัฮึ่ࠦศฯาࠤ๊์ࠠศๆฦะํฮษࠡษ็้ฯ๎แาหࠪ㕽"))
				l1ll1l1ll11l_l1_ = 1
			else: l1ll1l1ll11l_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㕾"),l1lll1111111_l1_(now))
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㕿"),l1l111_l1_ (u"ࠫࡆ࡛ࡔࡉࠩ㖀"),l1ll1l1ll11l_l1_,l1ll111l1l1_l1_)
	l1lll_l1_ = l1ll1l11l11l_l1_(type,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_)
	if l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㖁") in text: l1111lll1l1_l1_ = True
	if type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㖂"):
		if l1l111lll1_l1_!=l1l111_l1_ (u"ࠧ࠯࠰ࠪ㖃") and l1llllll1111_l1_: l1l1ll111ll_l1_()
		if addon_handle>-1:
			if (l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡫ࡱࡸࠬ㖄"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㖅"),l1l111_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ㖆")) or l1ll1ll1ll1l_l1_ not in l11111l1l11_l1_) and not l1l11llllll_l1_(l1l111_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ㖇")):
				from l1ll111l1l1l_l1_ import l1lllll11ll1_l1_
				l1lllll1l11l_l1_ = GET_ALL_LIST_ITEMS(l1lllll11ll1_l1_)
				l11l1ll1ll1_l1_ = CREATE_KODI_MENU(l1ll11111l11_l1_,l1lllll1l11l_l1_,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
				if 1 and l1lllll1l11l_l1_ and l11ll111ll1_l1_:
					l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㖈")+l1l111l1l11_l1_+l1l111_l1_ (u"࠭࡟ࠨ㖉")+l111lll1l1l_l1_,l1ll11111l11_l1_,l1lllll1l11l_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㖊")+addon_id+l1l111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ㖋"),xbmcgui.ListItem(l1l111_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦๅ็ࠢฯ๋ฬุใࠨ㖌")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㖍")+addon_id+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㖎"),xbmcgui.ListItem(l1l111_l1_ (u"ࠬษแหฯ่ࠣฯ่ัฤࠢส่ฯ็วึ์็ࠫ㖏")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
	return
def l1ll1l11l11l_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_):
	l1ll1ll1ll1l_l1_ = int(mode)
	l1ll1ll1lll1_l1_ = int(l1ll1ll1ll1l_l1_//10)
	if   l1ll1ll1lll1_l1_==0:  from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==2:  from l1ll1ll1lll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==3:  from l11l11lll11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==5:  from l11lllll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==8:  from l1ll1lll111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==9:  from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==10: from l1lll1llll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url)
	elif l1ll1ll1lll1_l1_==11: from l1ll11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==12: from l11l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==14: from l11lll1l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1ll1ll1lll1_l1_==15: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==16: from l1ll11l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==17: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==18: from l1l1lll1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==19: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==21: from l111lllllll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==22: from l111l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==26: from l1ll111l1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,context)
	elif l1ll1ll1lll1_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==29: from l11ll1l111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==30: from l1111111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==31: from l11l1l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==32: from l1ll11lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==33: from l11lll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url)
	elif l1ll1ll1lll1_l1_==34: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==36: from l1lll1l11l11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==38: from l1ll1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==39: from l1llll1lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==40: from l1l1l11l1l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==41: from l1l1l11l1l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==43: from l111l111l1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==44: from l111l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==45: from l1l1111l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==46: from l11111l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==47: from l111111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==48: from l1ll111lll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==49: from l1111l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==50: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==51: from l1111l111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==52: from l1111l111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==53: from l1ll111l1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==54: from l1111l11l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==56: from l1ll1l1111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==57: from l1llll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==58: from l11ll1lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==59: from l1llll11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==60: from l1llll111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==62: from l1lllll11l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==63: from l1111l11l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==64: from l1111lll11l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==66: from l11llll1111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==67: from l1ll11ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==68: from l11ll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==70: from l1ll111ll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==74: from l1ll1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_)
	elif l1ll1ll1lll1_l1_==75: from l1ll1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_)
	elif l1ll1ll1lll1_l1_==76: from l1ll11l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==77: from l111llll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==78: from l111ll1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==79: from l111ll11l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==80: from l111l1ll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==81: from l1ll11llll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==82: from l1111llll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1l1111lll_l1_(name=l1l111_l1_ (u"࠭ࠧ㖐")):
	if not name: name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ㖑"))
	name = name.replace(l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㖒"),l1l111_l1_ (u"ࠩࠪ㖓"))
	name = name.replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ㖔"),l1l111_l1_ (u"ࠫࠥ࠭㖕")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㖖"),l1l111_l1_ (u"࠭ࠠࠨ㖗")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ㖘"),l1l111_l1_ (u"ࠨࠢࠪ㖙")).strip(l1l111_l1_ (u"ࠩࠣࠫ㖚"))
	name = name.replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㖛"),l1l111_l1_ (u"ࠫࠬ㖜")).replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㖝"),l1l111_l1_ (u"࠭ࠧ㖞"))
	tmp = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࠫ㖟"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l111_l1_ (u"ࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫ㖠")
	return name
def l1lllll11lll_l1_(code,reason,source,l11_l1_):
	l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㖡"))
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㖢"),l1l111_l1_ (u"ࠫࠬ㖣"))
	if l1l111_l1_ (u"ࠬ࠳ࠧ㖤") in source: l1lll11l1ll_l1_ = source.split(l1l111_l1_ (u"࠭࠭ࠨ㖥"),1)[0]
	else: l1lll11l1ll_l1_ = source
	l11l1ll1lll_l1_ = code in [7,11001,11002,10054]
	l1l1lll11l1l_l1_ = reason.lower()
	l1llll1l1lll_l1_ = code in [0,104,10061,111]
	l1llll1l1ll1_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㖦") in l1l1lll11l1l_l1_
	l1llll1l1l1l_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㖧") in l1l1lll11l1l_l1_
	l1llll1l1l11_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㖨") in l1l1lll11l1l_l1_
	l1llll1l11ll_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㖩") in l1l1lll11l1l_l1_
	l1ll11l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㖪"))
	l1ll111ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㖫"))
	l11111lll1l_l1_ = l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ㖬")
	l111111ll1l_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠧ㖭")+str(code)+l1l111_l1_ (u"ࠨ࠼ࠣࠫ㖮")+reason
	l111111ll1l_l1_ = l111l11_l1_(l111111ll1l_l1_)
	if l1llll1l1lll_l1_ or l1llll1l1ll1_l1_ or l1llll1l1l1l_l1_ or l1llll1l1l11_l1_ or l1llll1l11ll_l1_:
		l11111lll1l_l1_ += l1l111_l1_ (u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ㖯")
	if l11l1ll1lll_l1_: l11111lll1l_l1_ += l1l111_l1_ (u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ㖰")
	l111111ll1l_l1_ = l1l111_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㖱")+l111111ll1l_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㖲")
	if l1ll11l1lll1_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㖳") or l1ll111ll11l_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㖴"):
		l11111lll1l_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㖵")
	l11llll1l11_l1_ = False
	if l11_l1_ and source not in l1llllll1ll1_l1_:
		if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㖶") or l1ll111ll11l_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㖷"):
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㖸"),l1l111_l1_ (u"ࠬิั้ฮࠪ㖹"),l1l111_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠫ㖺"),l1l111_l1_ (u"ࠧฦื็หาࠦวๅ็ื็้ฯࠧ㖻"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠬ㖼")+TRANSLATE(l1lll11l1ll_l1_),l11111lll1l_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㖽")+l111111ll1l_l1_)
			if l11l111111l_l1_==1:
				from l1l1l11l1ll_l1_ import l1ll1lllll1l_l1_
				l1ll1lllll1l_l1_()
			elif l11l111111l_l1_==2: l11llll1l11_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㖾"),l1l111_l1_ (u"ࠫࠬ㖿"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㗀")+TRANSLATE(l1lll11l1ll_l1_),l11111lll1l_l1_,l111111ll1l_l1_)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㗁"),l1111111lll_l1_)
	return l11llll1l11_l1_
def l11l1lllll1_l1_(l1ll111l11l1_l1_=False):
	l1111l111l1_l1_ = [l1l1l11llll_l1_,favoritesfile,l1l1ll1ll1ll_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1ll111l11l1_l1_ and (filename.startswith(l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ㗂")) or filename.startswith(l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ㗃"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ㗄")): continue
		l1lllll1l1ll_l1_ = os.path.join(addoncachefolder,filename)
		if l1lllll1l1ll_l1_ in l1111l111l1_l1_: continue
		try: os.remove(l1lllll1l1ll_l1_)
		except: pass
	time.sleep(1)
	return
def l1lll1ll1111_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	l1ll11lllll1_l1_,l1lll1ll11ll_l1_ = proxy.split(l1l111_l1_ (u"ࠪ࠾ࠬ㗅"))
	url = url+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㗆")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_,l1lll1111lll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l11111l11l1_l1_(l1l111_l1_ (u"ࠬࡎࡔࡕࡒࠣࡖࡪࡷࡵࡦࡵࡷࠤࡋࡧࡩ࡭ࡷࡵࡩࠬ㗇"))
	return response
def l1ll111l1ll1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㗈"),url,l1l111_l1_ (u"ࠧࠨ㗉"),l1l111_l1_ (u"ࠨࠩ㗊"),True,l1l111_l1_ (u"ࠩࠪ㗋"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ㗌"),True,False)
	l111l1l1l11_l1_ = []
	if response.succeeded:
		html = response.content
		l1ll1llllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧ㗍"),html)
		if l1ll1llllll1_l1_: html = l1l111_l1_ (u"ࠬࡢ࡮ࠨ㗎").join(l1ll1llllll1_l1_)
		proxies = html.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㗏"),l1l111_l1_ (u"ࠧࠨ㗐")).strip(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㗑")).split(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㗒"))
		l111l1l1l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠪ࠲ࠬ㗓"))==3: l111l1l1l11_l1_.append(proxy)
	return l111l1l1l11_l1_
def l11ll1ll1ll_l1_(*args):
	l11llllll11_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬ㗔")
	l1llll1lll11_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩ㗕")
	l111l1l1l1l_l1_ = l1ll111l1ll1_l1_(l1llll1lll11_l1_)
	l111l1l1l11_l1_ = l1ll111l1ll1_l1_(l11llllll11_l1_)
	l1l1111l11l_l1_ = l111l1l1l1l_l1_+l111l1l1l11_l1_
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㗖"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡺࠠࡱࡴࡲࡼ࡮࡫ࡳࠡ࡮࡬ࡷࡹࠦࠠࠡ࠳ࡶࡸ࠰࠸࡮ࡥ࠼ࠣ࡟ࠥ࠭㗗")+str(len(l111l1l1l1l_l1_))+l1l111_l1_ (u"ࠨ࠭ࠪ㗘")+str(len(l111l1l1l11_l1_))+l1l111_l1_ (u"ࠩࠣࡡࠬ㗙"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ㗚"))
	response = l1l1lllll1l_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㗛"),l1l111_l1_ (u"ࠬ࠭㗜"))
	if proxy or l1l1111l11l_l1_:
		id,l1l111ll11l_l1_ = 0,10
		l111ll11ll1_l1_ = len(l1l1111l11l_l1_)
		l111llll1ll_l1_ = l1l111ll11l_l1_
		if l111ll11ll1_l1_>l111llll1ll_l1_: counts = l111llll1ll_l1_
		else: counts = l111ll11ll1_l1_
		l11l1l1llll_l1_ = random.sample(l1l1111l11l_l1_,counts)
		if proxy: l11l1l1llll_l1_ = [proxy]+l11l1l1llll_l1_
		threads = l11l11ll111_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l111ll11l_l1_ and not threads.l11l1l1l1ll_l1_:
			if id<counts:
				proxy = l11l1l1llll_l1_[id]
				threads.start_new_thread(id,l1lll1ll1111_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㗝"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㗞")+proxy+l1l111_l1_ (u"ࠨࠢࡠࠫ㗟"))
		l11l1l1l1ll_l1_ = threads.l11l1l1l1ll_l1_
		if l11l1l1l1ll_l1_:
			l1lllll1ll11_l1_ = threads.l1lllll1ll11_l1_
			l111111l1ll_l1_ = l11l1l1l1ll_l1_[0]
			response = l1lllll1ll11_l1_[l111111l1ll_l1_]
			proxy = l11l1l1llll_l1_[int(l111111l1ll_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㗠"),proxy)
			if l111111l1ll_l1_!=0: l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㗡"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㗢")+proxy+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㗣"))
			else: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㗤"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㗥")+proxy+l1l111_l1_ (u"ࠨࠢࡠࠫ㗦"))
	return response
def l1ll11111111_l1_(connection,l1l1lll1llll_l1_):
	l11l11l1111_l1_ = connection.create_connection
	def l1ll1l11ll1l_l1_(address,*args,**kwargs):
		host,port = address
		l1ll1lll11ll_l1_ = DNS_RESOLVER(host,l1l1lll1llll_l1_)
		if l1ll1lll11ll_l1_: host = l1ll1lll11ll_l1_[0]
		else:
			if l1l1lll1llll_l1_ in l1111l11lll_l1_: l1111l11lll_l1_.remove(l1l1lll1llll_l1_)
			if l1111l11lll_l1_:
				l111lll1111_l1_ = l1111l11lll_l1_[0]
				l1ll1lll11ll_l1_ = DNS_RESOLVER(host,l111lll1111_l1_)
				if l1ll1lll11ll_l1_: host = l1ll1lll11ll_l1_[0]
		address = (host,port)
		return l11l11l1111_l1_(address,*args,**kwargs)
	connection.create_connection = l1ll1l11ll1l_l1_
	return l11l11l1111_l1_
def l1l1lll1l11l_l1_(url):
	l11l1lll1ll_l1_,l111l111lll_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ㗧"))[2],80
	if l1l111_l1_ (u"ࠪ࠾ࠬ㗨") in l11l1lll1ll_l1_: l11l1lll1ll_l1_,l111l111lll_l1_ = l11l1lll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠿࠭㗩"))
	l11l111l111_l1_ = l1l111_l1_ (u"ࠬ࠵ࠧ㗪")+l1l111_l1_ (u"࠭࠯ࠨ㗫").join(url.split(l1l111_l1_ (u"ࠧ࠰ࠩ㗬"))[3:])
	request = l1l111_l1_ (u"ࠨࡉࡈࡘࠥ࠭㗭")+l11l111l111_l1_+l1l111_l1_ (u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩ㗮")
	request += l1l111_l1_ (u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ㗯")+l11l1lll1ll_l1_+l1l111_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㗰")
	request += l1l111_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㗱")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1lll1ll_l1_,l111l111lll_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"࠭ࠧ㗲")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"ࠧ࠯ࠩ㗳") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ㗴")
	l1ll1l1l1lll_l1_,l1ll1l1l1ll1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠱ࠫ㗵"),1)
	l1ll1l1l1l1l_l1_,l1ll1l1l1l11_l1_ = l1ll1l1l1ll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ㗶"),1)
	server = l1ll1l1l1lll_l1_+l1l111_l1_ (u"ࠫ࠳࠭㗷")+l1ll1l1l1l1l_l1_
	if type in [l1l111_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ㗸"),l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㗹")] and l1l111_l1_ (u"ࠧ࠰ࠩ㗺") in server: server = server.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪ㗻"),1)[1]
	if type==l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㗼") and l1l111_l1_ (u"ࠪ࠲ࠬ㗽") in server:
		l1lll111lll1_l1_ = server.split(l1l111_l1_ (u"ࠫ࠳࠭㗾"))
		l1l1l1l1lll_l1_ = len(l1lll111lll1_l1_)
		if l1l1l1l1lll_l1_<=2 or l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㗿") in server: l1lll111lll1_l1_ = l1lll111lll1_l1_[0]
		elif l1l1l1l1lll_l1_>=3: l1lll111lll1_l1_ = l1lll111lll1_l1_[1]
		if len(l1lll111lll1_l1_)>1: server = l1lll111lll1_l1_
	return server
def l111ll11lll_l1_(l11l11ll1l1_l1_):
	l11l11ll1ll_l1_ = repr(l11l11ll1l1_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㘀"))).replace(l1l111_l1_ (u"ࠢࠨࠤ㘁"),l1l111_l1_ (u"ࠨࠩ㘂"))
	return l11l11ll1ll_l1_
def l1ll11l111l_l1_(string):
	l1ll111111l1_l1_ = l1l111_l1_ (u"ࠩࠪ㘃")
	if kodi_version<19: string = string.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㘄"))
	from unicodedata import decomposition
	for l1lllllll1l1_l1_ in string:
		if   l1lllllll1l1_l1_==l1l111_l1_ (u"ࡹࠬศࠧ㘅"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭㘆")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡻࠧฤࠩ㘇"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨ㘈")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡶࠩวࠫ㘉"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪ㘊")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡸࠫส࠭㘋"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬ㘌")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡺ࠭ฦࠨ㘍"): l11111l1l1l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ㘎")
		else:
			l1l1ll1l11ll_l1_ = decomposition(l1lllllll1l1_l1_)
			if l1l111_l1_ (u"ࠧࠡࠩ㘏") in l1l1ll1l11ll_l1_: l11111l1l1l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹࠬ㘐")+l1l1ll1l11ll_l1_.split(l1l111_l1_ (u"ࠩࠣࠫ㘑"),1)[1]
			else:
				l11111l1l1l_l1_ = l1l111_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ㘒")+hex(ord(l1lllllll1l1_l1_)).replace(l1l111_l1_ (u"ࠫ࠵ࡾࠧ㘓"),l1l111_l1_ (u"ࠬ࠭㘔"))
				l11111l1l1l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷࠪ㘕")+l11111l1l1l_l1_[-4:]
		l1ll111111l1_l1_ += l11111l1l1l_l1_
	l1ll111111l1_l1_ = l1ll111111l1_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨ㘖"),l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ࠩ㘗"))
	if kodi_version<19: l1ll111111l1_l1_ = l1ll111111l1_l1_.decode(l1l111_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㘘")).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㘙"))
	else: l1ll111111l1_l1_ = l1ll111111l1_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㘚")).decode(l1l111_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㘛"))
	return l1ll111111l1_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭㘜"),default=l1l111_l1_ (u"ࠧࠨ㘝"),l111llll11l_l1_=False,source=l1l111_l1_ (u"ࠨࠩ㘞")):
	text = l1ll1llll111_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠩࠣࠤࠬ㘟"),l1l111_l1_ (u"ࠪࠤࠬ㘠")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ㘡"),l1l111_l1_ (u"ࠬࠦࠧ㘢")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ㘣"),l1l111_l1_ (u"ࠧࠡࠩ㘤"))
	if not text and not l111llll11l_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㘥"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㘦")+text+l1l111_l1_ (u"ࠪࠦࠬ㘧"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㘨"),l1l111_l1_ (u"ࠬ࠭㘩"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㘪"),l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สีฮศๆࠪ㘫"))
		return l1l111_l1_ (u"ࠨࠩ㘬")
	if text not in [l1l111_l1_ (u"ࠩࠪ㘭"),l1l111_l1_ (u"ࠪࠤࠬ㘮")]:
		text = text.strip(l1l111_l1_ (u"ࠫࠥ࠭㘯"))
		text = l1ll11l111l_l1_(text)
	if source!=l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ㘰") and l11111l_l1_(l1l111_l1_ (u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨ㘱"),l1l111_l1_ (u"ࠧࠨ㘲"),[text],False):
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㘳"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬ㘴")+text+l1l111_l1_ (u"ࠪࠦࠬ㘵"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㘶"),l1l111_l1_ (u"ࠬ࠭㘷"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㘸"),l1l111_l1_ (u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩ㘹"))
		return l1l111_l1_ (u"ࠨࠩ㘺")
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㘻"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㘼")+text+l1l111_l1_ (u"ࠫࠧ࠭㘽"))
	return text
def l1l11l1ll1_l1_(l1lllll1_l1_,headers={}):
	url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭㘾")
	if l1l111_l1_ (u"࠭ࡼࠨ㘿") in l1lllll1_l1_:
		url,params = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧࡽࠩ㙀"),1)
		if l1l111_l1_ (u"ࠨ࠿ࠪ㙁") not in params: url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ㙂")
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㙃"),url,l1l111_l1_ (u"ࠫࠬ㙄"),headers,l1l111_l1_ (u"ࠬ࠭㙅"),l1l111_l1_ (u"࠭ࠧ㙆"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ㙇"),False,False)
	html = response.content
	if l1l111_l1_ (u"ࠨࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊࠬ㙈") not in html: return [l1l111_l1_ (u"ࠩ࠰࠵ࠬ㙉")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡃࡘࡈࡎࡕࠧ㙊") in html: return [l1l111_l1_ (u"ࠫ࠲࠷ࠧ㙋")],[l1lllll1_l1_]
	if l1l111_l1_ (u"࡚࡙ࠬࡑࡇࡀ࡚ࡎࡊࡅࡐࠩ㙌") in html: return [l1l111_l1_ (u"࠭࠭࠲ࠩ㙍")],[l1lllll1_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉ࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠨ㙎"),html+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㙏"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠩ࠰࠵ࠬ㙐")],[l1lllll1_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1l1lllll1l1_l1_,l11ll1l11ll_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠪࠫ㙑")
		items = line.split(l1l111_l1_ (u"ࠫ࠱࠭㙒"))
		for item in items:
			if l1l111_l1_ (u"ࠬࡃࠧ㙓") in item:
				key,value = item.split(l1l111_l1_ (u"࠭࠽ࠨ㙔"),1)
				l1l1lllll1l1_l1_[key.lower()] = value
		if l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㙕") in line.lower():
			l11ll1l11ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㙖")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㙗")
		elif l1l111_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㙘") in line.lower():
			l11ll1l11ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ㙙")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ㙚")
		if l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ㙛") in line.lower():
			l111l1ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫ㙜")].split(l1l111_l1_ (u"ࠨࡺࠪ㙝"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠬ㙞")
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠥ࠭㙟"))
		if not title: title = l1l111_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ㙠")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㙡")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"࠭࠯࠰ࠩ㙢")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠧ࠻ࠩ㙣"),1)[0]+l1l111_l1_ (u"ࠨ࠼ࠪ㙤")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࠲ࠫ㙥")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㙦"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠫ࠴࠭㙧"),1)[0]+l1l111_l1_ (u"ࠬ࠵ࠧ㙨")+l1ll1ll_l1_
		if params!=l1l111_l1_ (u"࠭ࠧ㙩"): l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࠩ㙪")+params
		if l1l111_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㙫") in list(l1l1lllll1l1_l1_.keys()):
			l111lllll_l1_ = l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㙬")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠪࠦࠬ㙭"),l1l111_l1_ (u"ࠫࠬ㙮")).replace(l1l111_l1_ (u"ࠧ࠭ࠢ㙯"),l1l111_l1_ (u"࠭ࠧ㙰")).split(l1l111_l1_ (u"ࠧࠤࠩ㙱"),1)[0]
			l11ll1l11l_l1_ = l1l111ll1l_l1_(l111lllll_l1_)
			if l11ll1l11l_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠨࠢࠣࠫ㙲")+l11ll1l11l_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠩࠣࠤࡕࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦࠩ㙳")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠪࠤࠥ࠭㙴")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㙵"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111l1llll1_l1_.append(l111l1ll_l1_)
			l1lll111ll11_l1_.append(l11ll1l11ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠩࠧ㙶"),1)[0]
		l11ll1l11l_l1_ = l1l111ll1l_l1_(l1ll1ll_l1_)
		if l11ll1l11l_l1_: title = title+l1l111_l1_ (u"࠭ࠠࠡࠩ㙷")+l11ll1l11l_l1_
		title = title+l1l111_l1_ (u"ࠧࠡࠢࠪ㙸")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㙹"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111l1llll1_l1_.append(l111l1ll_l1_)
		l1lll111ll11_l1_.append(l11ll1l11ll_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l1lll1llll_l1_=l1l111_l1_ (u"ࠩࠪ㙺")):
	if not l1l1lll1llll_l1_: l1l1lll1llll_l1_ = l1111l11lll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠪ࠲ࠬ㙻"),l1l111_l1_ (u"ࠫࠬ㙼")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1111l11111_l1_ = pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㙽"), 12049)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㙾"), 256)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㙿"), 1)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚀"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚁"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㚂"), 0)
		if kodi_version>18.99: l1lllll11l1l_l1_ = host.split(l1l111_l1_ (u"ࠫ࠳࠭㚃"))
		else: l1lllll11l1l_l1_ = host.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㚄")).split(l1l111_l1_ (u"࠭࠮ࠨ㚅"))
		for part in l1lllll11l1l_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚆"))
			l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠣࡄࠥ㚇"), len(part))
			for l111l1111ll_l1_ in part:
				l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠤࡦࠦ㚈"), l111l1111ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㚉")))
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠦࡇࠨ㚊"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚋"), 1)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㚌"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1111l11111_l1_), (l1l1lll1llll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1ll1l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࡊࡋࡌࡍࡎࡈࠣ㚍"), data, 0)
		l111ll1l1ll_l1_ = l11l1ll1l1l_l1_[3]
		offset = len(host)+18
		l11l11l1l11_l1_ = []
		for _ in range(l111ll1l1ll_l1_):
			l111l1lll11_l1_ = offset
			l1lll1lll1l1_l1_ = 1
			l11111lll11_l1_ = False
			while True:
				l111l1111ll_l1_ = unpack_from(l1l111_l1_ (u"ࠣࡀࡅࠦ㚎"), data, l111l1lll11_l1_)[0]
				if l111l1111ll_l1_ == 0:
					l111l1lll11_l1_ += 1
					break
				if l111l1111ll_l1_ >= 192:
					l1111lll1ll_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࡆࠧ㚏"), data, l111l1lll11_l1_ + 1)[0]
					l111l1lll11_l1_ = ((l111l1111ll_l1_ << 8) + l1111lll1ll_l1_ - 0xc000) - 1
					l11111lll11_l1_ = True
				l111l1lll11_l1_ += 1
				if l11111lll11_l1_ == False: l1lll1lll1l1_l1_ += 1
			if l11111lll11_l1_ == True: l1lll1lll1l1_l1_ += 1
			offset = offset + l1lll1lll1l1_l1_
			l1l11111l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࡍࡎࡉࡉࠤ㚐"), data, offset)
			offset = offset + 10
			l11l1lll11l_l1_ = l1l11111l1l_l1_[0]
			l11111llll1_l1_ = l1l11111l1l_l1_[3]
			if l11l1lll11l_l1_ == 1:
				l111l111l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠦࡃࠨ㚑")+l1l111_l1_ (u"ࠧࡈࠢ㚒")*l11111llll1_l1_, data, offset)
				l1ll1lll11ll_l1_ = l1l111_l1_ (u"࠭ࠧ㚓")
				for l111l1111ll_l1_ in l111l111l1l_l1_: l1ll1lll11ll_l1_ += str(l111l1111ll_l1_) + l1l111_l1_ (u"ࠧ࠯ࠩ㚔")
				l1ll1lll11ll_l1_ = l1ll1lll11ll_l1_[0:-1]
				l11l11l1l11_l1_.append(l1ll1lll11ll_l1_)
			if l11l1lll11l_l1_ in [1,2,5,6,15,28]: offset = offset + l11111llll1_l1_
	except: l11l11l1l11_l1_ = []
	if not l11l11l1l11_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㚕"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊࡎࡔࡡࡕࡉࡘࡕࡌࡗࡇࡕࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡈࡰࡵࡷ࠾ࠥࡡࠠࠨ㚖")+host+l1l111_l1_ (u"ࠪࠤࡢ࠭㚗"))
	return l11l11l1l11_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1ll11ll_l1_ = [l1l111_l1_ (u"่ࠫฮวาࠩ㚘"),l1l111_l1_ (u"ࠬฮวๅ฼ࠪ㚙"),l1l111_l1_ (u"࠭ࡡࡥࡷ࡯ࡸࠬ㚚"),l1l111_l1_ (u"ࠧࡹࡺࠪ㚛"),l1l111_l1_ (u"ࠨࡵࡨࡼࠬ㚜")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㚝"):
			l11l1ll11ll_l1_ += [l1l111_l1_ (u"ࠪࡶ࠿࠭㚞"),l1l111_l1_ (u"ࠫࡷ࠳ࠧ㚟"),l1l111_l1_ (u"ࠬ࠳࡭ࡢࠩ㚠")]
			l11l1ll11ll_l1_ += [l1l111_l1_ (u"࠭࠺ࡳࠩ㚡"),l1l111_l1_ (u"ࠧ࠮ࡴࠪ㚢"),l1l111_l1_ (u"ࠨ࡯ࡤ࠱ࠬ㚣")]
		for l1111lll1l_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠩࡪࡩࡹ࠴ࡰࡩࡲࡂࠫ㚤") in l1111lll1l_l1_: continue
			if l1l111_l1_ (u"ࠪั้่ษࠨ㚥") in l1111lll1l_l1_: continue
			l1111lll1l_l1_ = l1111lll1l_l1_.lower()
			if kodi_version<19: l1111lll1l_l1_ = l1111lll1l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㚦")).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㚧"))
			l1111lll1l_l1_ = l1111lll1l_l1_.replace(l1l111_l1_ (u"࠭࠺ࠨ㚨"),l1l111_l1_ (u"ࠧࠨ㚩"))
			l11l111lll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮࠭ࠬ㚪"),l1111lll1l_l1_,re.DOTALL)
			l1lll111llll_l1_ = False
			for digits in l11l111lll1_l1_:
				if len(digits)==2:
					l1lll111llll_l1_ = True
					break
			if l1l111_l1_ (u"ࠩࡱࡳࡹࠦࡲࡢࡶࡨࡨࠬ㚫") in l1111lll1l_l1_: continue
			elif l1l111_l1_ (u"ࠪࡹࡳࡸࡡࡵࡧࡧࠫ㚬") in l1111lll1l_l1_: continue
			elif l1l111_l1_ (u"ࠫ฿๐ัࠡ็ุ๊ๆ࠭㚭") in l1111lll1l_l1_: continue
			elif l1l11llllll_l1_(l1l111_l1_ (u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡲࡖࡅࡘࡈ࡚ࡊ࡞ࠧ㚮")): continue
			elif l1111lll1l_l1_ in [l1l111_l1_ (u"࠭ࡲࠨ㚯")] or l1lll111llll_l1_ or any(value in l1111lll1l_l1_ for value in l11l1ll11ll_l1_):
				l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㚰"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡧࡤࡶ࡮ࡷࡷࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㚱")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㚲"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㚳"),l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥไไสสีࠥ็โุ๋ࠢว๋อࠠๆ่฼ฮ์࠭㚴"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll111ll1l_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㚵")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"࠭วิฬ่ีฬืࠧ㚶")
		header = args[2]
		text = l1l111_l1_ (u"ࠧ࡝ࡰࠪ㚷").join(args[3:])
	else: l1lll111ll1l_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠨࠩ㚸"),l1l111_l1_ (u"ࠩࡒࡏࠬ㚹"),l1l111_l1_ (u"ࠪࠫ㚺"),l1l111_l1_ (u"ࠫࠬ㚻")
	l1l1lll11lll_l1_(l1lll111ll1l_l1_,l1l111_l1_ (u"ࠬ࠭㚼"),l11l111l_l1_,l1l111_l1_ (u"࠭ࠧ㚽"),header,text,**kwargs)
	return
def l1ll1l1111_l1_(*args,**kwargs):
	l1lll111ll1l_l1_ = args[0]
	l1llll11l11l_l1_ = args[1]
	l1lll1ll1ll1_l1_ = args[2]
	if l1lll1ll1ll1_l1_ or l1llll11l11l_l1_: l1llll111ll1_l1_ = True
	else: l1llll111ll1_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㚾")
	if not l1llll11l11l_l1_: l1llll11l11l_l1_ = l1l111_l1_ (u"ࠨๅ็หࠬ㚿")
	if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"้ࠩ฽๊࠭㛀")
	if len(args)>=6: text += l1l111_l1_ (u"ࠪࡠࡳ࠭㛁")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠫࡡࡴࠧ㛂")+args[6]
	l11l111111l_l1_ = l1l1lll11lll_l1_(l1lll111ll1l_l1_,l1llll11l11l_l1_,l1l111_l1_ (u"ࠬ࠭㛃"),l1lll1ll1ll1_l1_,header,text,**kwargs)
	if l11l111111l_l1_==-1 and l1llll111ll1_l1_: l11l111111l_l1_ = -1
	elif l11l111111l_l1_==-1 and not l1llll111ll1_l1_: l11l111111l_l1_ = False
	elif l11l111111l_l1_==0: l11l111111l_l1_ = False
	elif l11l111111l_l1_==2: l11l111111l_l1_ = True
	return l11l111111l_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㛄") in list(kwargs.keys()): l1l1111llll_l1_ = kwargs[l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㛅")]
	else: l1l1111llll_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㛆") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ㛇")
	l1ll1111ll1l_l1_ = l1l1ll11l1l_l1_(l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪ㛈"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㛉"),l1l111_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㛊"))
	l1lll11l11ll_l1_,l11l11111ll_l1_ = l1lllllllll1_l1_(l1l111_l1_ (u"࠭ࠧ㛋"),l1l111_l1_ (u"ࠧࠨ㛌"),l1l111_l1_ (u"ࠨࠩ㛍"),header,text,profile,l1l111_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㛎"),720,False)
	l1ll1111ll1l_l1_.show()
	if profile==l1l111_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ㛏"):
		l1ll1111ll1l_l1_.getControl(9040).setHeight(215)
		l1ll1111ll1l_l1_.getControl(9040).setPosition(55,-80)
		l1ll1111ll1l_l1_.getControl(9050).setPosition(120,-60)
		l1ll1111ll1l_l1_.getControl(400).setPosition(90,-35)
	l1ll1111ll1l_l1_.getControl(401).setVisible(False)
	l1ll1111ll1l_l1_.getControl(402).setVisible(False)
	l1ll1111ll1l_l1_.getControl(9050).setImage(l1lll11l11ll_l1_)
	l1ll1111ll1l_l1_.getControl(9050).setHeight(l11l11111ll_l1_)
	from threading import Thread
	l1l11111ll1_l1_ = Thread(target=l1l1ll1l1l1l_l1_,args=(l1ll1111ll1l_l1_,l1lll11l11ll_l1_,l1l1111llll_l1_))
	l1l11111ll1_l1_.start()
	return
def l1l1ll1l1l1l_l1_(l1ll1111ll1l_l1_,l1lll11l11ll_l1_,l1l1111llll_l1_):
	time.sleep(l1l1111llll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll11l11ll_l1_):
		try: os.remove(l1lll11l11ll_l1_)
		except: pass
	return
def l1ll11l11l11_l1_(*args,**kwargs):
	header,text,profile,l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ㛐"),l1l111_l1_ (u"ࠬ࠭㛑"),l1l111_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ㛒"),l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㛓")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll111ll1l_l1_ = args[3]
	return l1l11ll111_l1_(l1lll111ll1l_l1_,header,text,profile)
def l11ll11l1ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1ll1l1ll1l1_l1_(*args,**kwargs)
def l1l11111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1ll1llll111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l11l1111_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll1ll1l1_l1_(l1lll1ll111l_l1_):
	if kodi_version>17.99: l1ll1111ll1l_l1_ = l1l111_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭㛔")
	else: l1ll1111ll1l_l1_ = l1l111_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭㛕")
	l1lll1ll111l_l1_ = l1lll1ll111l_l1_.lower()
	if l1lll1ll111l_l1_==l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ㛖"): xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭㛗")+l1ll1111ll1l_l1_+l1l111_l1_ (u"ࠬ࠯ࠧ㛘"))
	elif l1lll1ll111l_l1_==l1l111_l1_ (u"࠭ࡳࡵࡱࡳࠫ㛙"): xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧ㛚")+l1ll1111ll1l_l1_+l1l111_l1_ (u"ࠨࠫࠪ㛛"))
	return
def l1l1lll11lll_l1_(l1lll111ll1l_l1_,l111l1l11l1_l1_=l1l111_l1_ (u"ࠩࠪ㛜"),l1ll11ll1l11_l1_=l1l111_l1_ (u"ࠪࠫ㛝"),l111l1l1lll_l1_=l1l111_l1_ (u"ࠫࠬ㛞"),header=l1l111_l1_ (u"ࠬ࠭㛟"),text=l1l111_l1_ (u"࠭ࠧ㛠"),profile=l1l111_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㛡"),l1llll111l11_l1_=0,l1ll1ll1l1l1_l1_=0):
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㛢")
	l1ll1111ll1l_l1_ = l1ll1l1111l1_l1_(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㛣"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㛤"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㛥"))
	l1ll1111ll1l_l1_.l11l11111l1_l1_(l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text,profile,l1lll111ll1l_l1_,900,l1llll111l11_l1_,l1ll1ll1l1l1_l1_)
	if l1llll111l11_l1_>0: l1ll1111ll1l_l1_.l1l1111111l_l1_()
	if l1ll1ll1l1l1_l1_>0: l1ll1111ll1l_l1_.l11lll1l1l1_l1_()
	if l1llll111l11_l1_==0 and l1ll1ll1l1l1_l1_==0: l1ll1111ll1l_l1_.l11l11l1ll1_l1_()
	l1ll1111ll1l_l1_.doModal()
	l11l111111l_l1_ = l1ll1111ll1l_l1_.l1l11111l11_l1_
	return l11l111111l_l1_
def l1l11ll111_l1_(l1lll111ll1l_l1_,header,text,profile=l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㛦")):
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㛧")
	l1ll1111ll1l_l1_ = l1l1ll11l1l_l1_(l1l111_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡔࡦࡺࡷ࡚࡮࡫ࡷࡦࡴࡉࡹࡱࡲࡓࡤࡴࡨࡩࡳ࠴ࡸ࡮࡮ࠪ㛨"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㛩"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㛪"))
	l1lll11l11ll_l1_,l11l11111ll_l1_ = l1lllllllll1_l1_(l1l111_l1_ (u"ࠪࠫ㛫"),l1l111_l1_ (u"ࠫࠬ㛬"),l1l111_l1_ (u"ࠬ࠭㛭"),header,text,profile,l1lll111ll1l_l1_,1270,False)
	l1ll1111ll1l_l1_.show()
	l1ll1111ll1l_l1_.getControl(9050).setHeight(l11l11111ll_l1_)
	l1ll1111ll1l_l1_.getControl(9050).setImage(l1lll11l11ll_l1_)
	result = l1ll1111ll1l_l1_.doModal()
	try: os.remove(l1lll11l11ll_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1ll1l1llll1_l1_=True):
	if l1ll1l1llll1_l1_:
		l11ll1l1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡳࡵࡴࠪ㛮"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㛯"),l1l111_l1_ (u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫ㛰"))
		if l11ll1l1l1_l1_: return l11ll1l1l1_l1_
	text = l1l111_l1_ (u"ࠩࠪ㛱")
	url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡫ࡣࡩࡤ࡯ࡳ࡬࠴ࡷࡪ࡮࡯ࡷ࡭ࡵࡵࡴࡧ࠱ࡧࡴࡳ࠯࠳࠲࠴࠶࠴࠶࠱࠰࠲࠶࠳ࡲࡵࡳࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹࡹ࠯ࠨ㛲")
	headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㛳"):url}
	response = l11l1l_l1_(l1lll11ll11_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㛴"),url,l1l111_l1_ (u"࠭ࠧ㛵"),headers,l1l111_l1_ (u"ࠧࠨ㛶"),l1l111_l1_ (u"ࠨࠩ㛷"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ㛸"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫ㛹"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㛺"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1lllll11l11_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㛻"),l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧ㛼"))
		text = open(l1lllll11l11_l1_,l1l111_l1_ (u"ࠧࡳࡤࠪ㛽")).read()
		if kodi_version>18.99: text = text.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㛾"))
		text = text.replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ㛿"),l1l111_l1_ (u"ࠪࠫ㜀"))
	l1llllll1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡓ࡯ࡻ࡫࡯ࡰࡦ࠴ࠪࡀࠫ࡟ࡲࠬ㜁"),text,re.DOTALL)
	l11ll1l1lll_l1_ = []
	for line in l1llllll1lll_l1_:
		l1lll1l1lll1_l1_ = line.lower()
		if l1l111_l1_ (u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭㜂") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"࠭ࡵࡣࡷࡱࡸࡺ࠭㜃") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"ࠧࡪࡲ࡫ࡳࡳ࡫ࠧ㜄") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"ࠨࡥࡵࡳࡸ࠭㜅") in l1lll1l1lll1_l1_: continue
		l11ll1l1lll_l1_.append(line)
	l11ll1l1l1_l1_ = random.sample(l11ll1l1lll_l1_,1)
	l11ll1l1l1_l1_ = l11ll1l1l1_l1_[0]
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㜆"),l1l111_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㜇"),l11ll1l1l1_l1_,l11l1l1_l1_)
	return l11ll1l1l1_l1_
def l11l1l1111l_l1_(l1111llll11_l1_):
	sys.stderr.write(l1111llll11_l1_)
	lines = l1111llll11_l1_.splitlines()
	error = lines[-1]
	l111l1lll1l_l1_ = open(l1llll1llll1_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㜈")).read()
	if kodi_version>18.99: l111l1lll1l_l1_ = l111l1lll1l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㜉"))
	l111l1lll1l_l1_ = l111l1lll1l_l1_[-8000:]
	sep = l1l111_l1_ (u"࠭࠽ࠨ㜊")*100
	if sep in l111l1lll1l_l1_: l111l1lll1l_l1_ = l111l1lll1l_l1_.rsplit(sep,1)[1]
	if error in l111l1lll1l_l1_: l111l1lll1l_l1_ = l111l1lll1l_l1_.rsplit(error,1)[0]
	l1ll1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭㜋"),l111l1lll1l_l1_,re.DOTALL)
	for typ,source in reversed(l1ll1l11l1l1_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨ㜌")
	file,line,func = l1l111_l1_ (u"ࠩࠪ㜍"),l1l111_l1_ (u"ࠪࠫ㜎"),l1l111_l1_ (u"ࠫࠬ㜏")
	l11ll11lll1_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜐")+error
	l1ll1l1ll1ll_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜑")+source
	for l1llll111lll_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠧ㜒") in l1llll111lll_l1_ and l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㜓") in l1llll111lll_l1_: break
	l1llll111lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬ㜔"),l1llll111lll_l1_,re.DOTALL)
	if l1llll111lll_l1_:
		file,line,func = l1llll111lll_l1_[0]
		if l1l111_l1_ (u"ࠪ࠳ࠬ㜕") in file: file = file.rsplit(l1l111_l1_ (u"ࠫ࠴࠭㜖"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㜗"),1)[1]
		l1ll11111ll1_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㜘")+file
		line2 = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜙")+line
		l1l111111l1_l1_ = l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㜚")+func
		l111ll1111l_l1_ = l1ll11111ll1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜛")+line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㜜")+l1l111111l1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㜝")+l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜞")+l11ll11lll1_l1_
		l1lll11lllll_l1_ = line2+l1l111_l1_ (u"࠭࡜࡯ࠩ㜟")+l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㜠")+l11ll11lll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜡")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜢")+l1l111111l1_l1_
		l11111111l1_l1_ = line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㜣")+l11ll11lll1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㜤")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜥")+l1l111111l1_l1_
	else:
		l1ll11111ll1_l1_,line2,l1l111111l1_l1_ = l1l111_l1_ (u"࠭ࠧ㜦"),l1l111_l1_ (u"ࠧࠨ㜧"),l1l111_l1_ (u"ࠨࠩ㜨")
		l111ll1111l_l1_ = l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㜩")+l11ll11lll1_l1_
		l1lll11lllll_l1_ = l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㜪")+l11ll11lll1_l1_
		l11111111l1_l1_ = l11ll11lll1_l1_
	l11l11lll1l_l1_ = l1l111_l1_ (u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨ㜫")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜬")
	l1ll1111l1ll_l1_ = l111llll111_l1_()
	l1llll1ll1l1_l1_ = []
	l1lll_l1_ = l1ll1111l1ll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㜭")]
	l1llll111l1l_l1_ = l1l1ll1ll1l1_l1_(l1l11l1llll_l1_)
	if l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㜮") in list(l1ll1111l1ll_l1_.keys()):
		for l1ll1l1lll11_l1_,l1111ll11ll_l1_,l11ll1l1111_l1_ in l1lll_l1_: l1llll1ll1l1_l1_ = max(l1llll1ll1l1_l1_,l1111ll11ll_l1_)
		if l1llll111l1l_l1_<l1llll1ll1l1_l1_:
			header = l1l111_l1_ (u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫ㜯")
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㜰"),l1l111_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㜱"),l1l111_l1_ (u"ࠫฯำฯ๋อࠪ㜲"),l1l111_l1_ (u"ࠬิั้ฮࠪ㜳"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
			if l11l111111l_l1_==0:
				l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㜴"),l1l111_l1_ (u"ࠧฯำ๋ะࠬ㜵"),l1l111_l1_ (u"ࠨฬะำ๏ัࠧ㜶"),l1l111_l1_ (u"ࠩࠪ㜷"),header)
				if l1llll1l11_l1_==1: l11l111111l_l1_ = 1
			if l11l111111l_l1_==1:
				from l1l1l11l1ll_l1_ import l1lll1ll1l1l_l1_
				l1lll1ll1l1l_l1_()
			return
	l1l1ll1l1l11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㜸"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㜹"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㜺"))
	if not l1l1ll1l1l11_l1_: l1l1ll1l1l11_l1_ = []
	l1lll11lllll_l1_ = l1lll11lllll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㜻"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㜼")).replace(l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㜽"),l1l111_l1_ (u"ࠩࠪ㜾")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㜿"),l1l111_l1_ (u"ࠫࠬ㝀")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝁"),l1l111_l1_ (u"࠭ࠧ㝂"))
	l11111111l1_l1_ = l11111111l1_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㝃"),l1l111_l1_ (u"ࠨ࡞࡟ࡲࠬ㝄")).replace(l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ㝅"),l1l111_l1_ (u"ࠪࠫ㝆")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㝇"),l1l111_l1_ (u"ࠬ࠭㝈")).replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㝉"),l1l111_l1_ (u"ࠧࠨ㝊"))
	l1l1lll11l11_l1_ = l1l11l1llll_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ㝋")+l11111111l1_l1_
	if l1l1lll11l11_l1_ in l1l1ll1l1l11_l1_:
		header = l1l111_l1_ (u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ㝌")
		l1111l1_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㝍"),l1l111_l1_ (u"ࠫࠬ㝎"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
		return
	l1l1lll1lll1_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠬ࠴ࠧ㝏"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㝐")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㝑"),url,l1l111_l1_ (u"ࠨࠩ㝒"),l1l111_l1_ (u"ࠩࠪ㝓"),l1l111_l1_ (u"ࠪࠫ㝔"),l1l111_l1_ (u"ࠫࠬ㝕"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨ㝖"),False,False)
	html = response.content
	l11lll1l11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㝗"),html,re.DOTALL)
	for l11l11ll11l_l1_,l11ll11ll1l_l1_,l111111l11l_l1_,l1lll11llll1_l1_ in l11lll1l11l_l1_:
		l11l11ll11l_l1_ = l11l11ll11l_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㝘"))
		l111111l11l_l1_ = l111111l11l_l1_.split(l1l111_l1_ (u"ࠨ࠭ࠪ㝙"))
		l1lll11llll1_l1_ = l1lll11llll1_l1_.split(l1l111_l1_ (u"ࠩ࠮ࠫ㝚"))
		if line in l11l11ll11l_l1_ and error==l11ll11ll1l_l1_ and l1l11l1llll_l1_ in l111111l11l_l1_ and l1l1lll1lll1_l1_ in l1lll11llll1_l1_:
			header = l1l111_l1_ (u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨ㝛")
			l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㝜"),l1l111_l1_ (u"ࠬิั้ฮࠪ㝝"),l1l111_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ㝞"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
			if l1llll1l11_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㝟"),l1l111_l1_ (u"ࠨࠩ㝠"),l1l111_l1_ (u"ࠩࠪ㝡"),header)
			return
	header = l1l111_l1_ (u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ㝢")
	l1111l1_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㝣"),l1l111_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㝤"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㝥"),l1l111_l1_ (u"ࠧไๆสࠫ㝦"),l1l111_l1_ (u"ࠨ่฼้ࠬ㝧"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㝨"),l1l111_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫ㝩"))
	if l1llll1l11_l1_==1: l1l1lll1l111_l1_ = l1l111_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㝪")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㝫"),l1l111_l1_ (u"࠭ࠧ㝬"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㝭"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭㝮"))
		return
	message = l1lll11lllll_l1_
	from l1l1l11l1ll_l1_ import l11l1l11lll_l1_
	succeeded = l11l1l11lll_l1_(l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࡴࠩ㝯"),message,True,l1l111_l1_ (u"ࠪࠫ㝰"),l1l111_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㝱"),l1l1lll1l111_l1_)
	if succeeded and l1l1lll1l111_l1_:
		l1l1ll1l1l11_l1_.append(l1l1lll11l11_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㝲"),l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ㝳"),l1l1ll1l1l11_l1_,l1ll111l1l1_l1_)
	return
def l1ll1l1lllll_l1_(data):
	if kodi_version>18.99: data = data.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㝴"))
	filename = l1l111_l1_ (u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨ㝵")+str(time.time())+l1l111_l1_ (u"ࠩ࠱ࡨࡦࡺࠧ㝶")
	open(filename,l1l111_l1_ (u"ࠪࡻࡧ࠭㝷")).write(data)
	return
def l11llll1lll_l1_(l1l1lll11ll_l1_):
	if l1l1lll11ll_l1_:
		l1ll1l11l111_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㝸"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㝹"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㝺"))
		if l1ll1l11l111_l1_: return l1ll1l11l111_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㝻")][5]
	user = l1l1ll1l11l_l1_(32)
	l1111ll1l11_l1_ = l11l1111lll_l1_()
	l1lll1l1l1ll_l1_ = l1111ll1l11_l1_.split(l1l111_l1_ (u"ࠨ࠮ࠪ㝼"))[2]
	l1lll1111l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㝽"))
	l1llllll1l11_l1_ = l1l1llllllll_l1_()
	payload = {l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㝾"):user,l1l111_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㝿"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㞀"):l1lll1l1l1ll_l1_,l1l111_l1_ (u"࠭ࡩࡥࡵࠪ㞁"):l1lll1111111_l1_(l1llllll1l11_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㞂"),url,payload,l1l111_l1_ (u"ࠨࠩ㞃"),l1l111_l1_ (u"ࠩࠪ㞄"),l1l111_l1_ (u"ࠪࠫ㞅"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩ㞆"))
	if not response.succeeded: return []
	html = response.content
	l1ll1l11l111_l1_ = html.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡳࠩ㞇"),l1l111_l1_ (u"࠭࡜࡯ࠩ㞈")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㞉"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㞊")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㞋"),l1l111_l1_ (u"ࠪࡠࡳ࠭㞌")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㞍"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㞎"))
	l1ll1l11l111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ㞏"),l1ll1l11l111_l1_,re.DOTALL)
	if not l1ll1l11l111_l1_: return []
	l1ll1l11l111_l1_ = sorted(l1ll1l11l111_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1l11l111_l1_[0]
	l1lll1l111l1_l1_ = reason if l1l11llllll_l1_(l1l111_l1_ (u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭㞐")) else l1l1llllll1l_l1_
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㞑"),l1lll1l111l1_l1_)
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㞒"),l1l111_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㞓"),l1ll1l11l111_l1_,l11l1l1_l1_)
	return l1ll1l11l111_l1_
def SPLIT_BIGLIST(items,l1l1lll111l1_l1_=0,l1lllll1l1l1_l1_=0):
	if l1l1lll111l1_l1_ and not l1lllll1l1l1_l1_: l1lllll1l1l1_l1_ = len(items)//l1l1lll111l1_l1_
	l1lll11111l1_l1_,l1l11l111l_l1_,l1lll1l1llll_l1_ = [],-1,0
	for item in items:
		if l1lll1l1llll_l1_%l1lllll1l1l1_l1_==0:
			l1l11l111l_l1_ += 1
			l1lll11111l1_l1_.append([])
		l1lll11111l1_l1_[l1l11l111l_l1_].append(item)
		l1lll1l1llll_l1_ += 1
	return l1lll11111l1_l1_
def l111lll111l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ㞔") not in filename or l1l111_l1_ (u"ࠬࡓ࠳ࡖࡡࠪ㞕") not in filename: text = str(data)
	else:
		l1lll11111l1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"࠭ࠧ㞖")
		for split in l1lll11111l1_l1_:
			text += str(split)+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㞗")
		text = text.strip(l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㞘"))
	l1l1l1ll1l1_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠩࡺࡦࠬ㞙")).write(l1l1l1ll1l1_l1_)
	return
def l11ll1l1ll1_l1_(l1l1ll11111_l1_,filename):
	if l1l1ll11111_l1_==l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㞚"): data = {}
	elif l1l1ll11111_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㞛"): data = []
	elif l1l1ll11111_l1_==l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㞜"): data = l1l111_l1_ (u"࠭ࠧ㞝")
	elif l1l1ll11111_l1_==l1l111_l1_ (u"ࠧࡪࡰࡷࠫ㞞"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1ll1l1_l1_ = open(filepath,l1l111_l1_ (u"ࠨࡴࡥࠫ㞟")).read()
	text = zlib.decompress(l1l1l1ll1l1_l1_)
	if l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㞠") not in text: data = eval(text)
	else:
		l1lll11111l1_l1_ = text.split(l1l111_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㞡"))
		del text
		data = []
		l11l1l1lll1_l1_ = l11l11ll111_l1_()
		id = 0
		for split in l1lll11111l1_l1_:
			l11l1l1lll1_l1_.l11l111ll11_l1_(str(id),eval,split)
			id += 1
		del l1lll11111l1_l1_
		l11l1l1lll1_l1_.l1ll1lll1ll1_l1_()
		l11l1l1lll1_l1_.l1l1lll1111l_l1_()
		l1l1llllll11_l1_ = list(l11l1l1lll1_l1_.l1lllll1ll11_l1_.keys())
		l1ll11l11ll1_l1_ = sorted(l1l1llllll11_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll11l11ll1_l1_:
			data += l11l1l1lll1_l1_.l1lllll1ll11_l1_[id]
	return data
def l1ll1l11111l_l1_(addon_id):
	l1ll11llllll_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㞢"),addon_id,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ㞣"))
	try: l1111ll111l_l1_ = open(l1ll11llllll_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㞤")).read()
	except:
		l1lll1l1ll11_l1_ = os.path.join(l11111ll11l_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㞥"),addon_id,l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ㞦"))
		try: l1111ll111l_l1_ = open(l1lll1l1ll11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㞧")).read()
		except: return l1l111_l1_ (u"ࠪࠫ㞨"),[]
	if kodi_version>18.99: l1111ll111l_l1_ = l1111ll111l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㞩"))
	version = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩ㞪"),l1111ll111l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"࠭ࠧ㞫"),[]
	l1l1111l1ll_l1_,l11l111l1l1_l1_ = version[0],l1l1ll1ll1l1_l1_(version[0])
	return l1l1111l1ll_l1_,l11l111l1l1_l1_
def l111llll111_l1_():
	l111l11llll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㞬"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㞭"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㞮"))
	if l111l11llll_l1_: return l111l11llll_l1_
	l1ll1111l1ll_l1_,l111l11llll_l1_ = {},{}
	l1ll1l11l1l1_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㞯")][0]]
	if kodi_version>17.99: l1ll1l11l1l1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㞰")][1])
	if kodi_version>18.99: l1ll1l11l1l1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㞱")][2])
	for l1ll11ll111l_l1_ in l1ll1l11l1l1_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㞲"),l1ll11ll111l_l1_,l1l111_l1_ (u"ࠧࠨ㞳"),l1l111_l1_ (u"ࠨࠩ㞴"),l1l111_l1_ (u"ࠩࠪ㞵"),l1l111_l1_ (u"ࠪࠫ㞶"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㞷"))
		if response.succeeded:
			html = response.content
			l1l1lll1ll11_l1_ = l1ll11ll111l_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧ㞸"),1)[0]
			l111l1l111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㞹"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111ll1llll_l1_ in l111l1l111l_l1_:
				l11l111l1ll_l1_ = l1l1lll1ll11_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ㞺")+addon_id+l1l111_l1_ (u"ࠨ࠱ࠪ㞻")+addon_id+l1l111_l1_ (u"ࠩ࠰ࠫ㞼")+l111ll1llll_l1_+l1l111_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ㞽")
				if addon_id not in list(l1ll1111l1ll_l1_.keys()):
					l1ll1111l1ll_l1_[addon_id] = []
					l111l11llll_l1_[addon_id] = []
				l1lll1ll1lll_l1_ = l1l1ll1ll1l1_l1_(l111ll1llll_l1_)
				l1ll1111l1ll_l1_[addon_id].append((l111ll1llll_l1_,l1lll1ll1lll_l1_,l11l111l1ll_l1_))
	for addon_id in list(l1ll1111l1ll_l1_.keys()):
		l111l11llll_l1_[addon_id] = sorted(l1ll1111l1ll_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㞾"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㞿"),l111l11llll_l1_,l11l1l1_l1_)
	return l111l11llll_l1_
def l1l1ll1ll1l1_l1_(l111ll1llll_l1_):
	l1lll1ll1lll_l1_ = []
	l1llll11lll_l1_ = l111ll1llll_l1_.split(l1l111_l1_ (u"࠭࠮ࠨ㟀"))
	for l1l1ll1l1l_l1_ in l1llll11lll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ㟁"),l1l1ll1l1l_l1_,re.DOTALL)
		l1l1lllllll1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l1lllllll1_l1_.append(part)
		l1lll1ll1lll_l1_.append(l1l1lllllll1_l1_)
	return l1lll1ll1lll_l1_
def l1lll11l1ll1_l1_(l1lll1ll1lll_l1_):
	l111ll1llll_l1_ = l1l111_l1_ (u"ࠨࠩ㟂")
	for l1l1ll1l1l_l1_ in l1lll1ll1lll_l1_:
		for part in l1l1ll1l1l_l1_: l111ll1llll_l1_ += str(part)
		l111ll1llll_l1_ += l1l111_l1_ (u"ࠩ࠱ࠫ㟃")
	l111ll1llll_l1_ = l111ll1llll_l1_.strip(l1l111_l1_ (u"ࠪ࠲ࠬ㟄"))
	return l111ll1llll_l1_
def l1lllllll1ll_l1_(l11ll1l1l11_l1_):
	l1l1lll1ll1l_l1_ = {}
	l1ll1111l1ll_l1_ = l111llll111_l1_()
	l11lll1ll1l_l1_ = l1ll1lll1l1l_l1_(l11ll1l1l11_l1_)
	for addon_id in l11ll1l1l11_l1_:
		if addon_id not in list(l1ll1111l1ll_l1_.keys()): continue
		l111l11llll_l1_ = l1ll1111l1ll_l1_[addon_id]
		l11lll11l1l_l1_,l11lll111ll_l1_,l1l1ll1l1111_l1_ = l111l11llll_l1_[0]
		l1111lllll1_l1_,l1111l11l11_l1_ = l1ll1l11111l_l1_(addon_id)
		l11l1llllll_l1_,l1lllll1l111_l1_ = l11lll1ll1l_l1_[addon_id]
		l11lllll111_l1_ = l11lll111ll_l1_>l1111l11l11_l1_ and l11l1llllll_l1_
		l1l1ll1l11l1_l1_ = True
		if not l11l1llllll_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ㟅")
		elif not l1lllll1l111_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ㟆")
		elif l11lllll111_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"࠭࡯࡭ࡦࠪ㟇")
		else:
			l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠧࡨࡱࡲࡨࠬ㟈")
			l1l1ll1l11l1_l1_ = False
		l1l1lll1ll1l_l1_[addon_id] = (l1l1ll1l11l1_l1_,l1111lllll1_l1_,l1111l11l11_l1_,l11lll11l1l_l1_,l11lll111ll_l1_,l1l1111ll1l_l1_,l1l1ll1l1111_l1_)
	return l1l1lll1ll1l_l1_
def l1l1111l11_l1_(l1l111l111_l1_,l1111l1l1l1_l1_,l11l11l1lll_l1_=l1l111_l1_ (u"ࠨࠩ㟉"),line2=l1l111_l1_ (u"ࠩࠪ㟊"),l11l11ll11l_l1_=l1l111_l1_ (u"ࠪࠫ㟋")):
	if kodi_version<19: l1l111l111_l1_.update(l1111l1l1l1_l1_,l11l11l1lll_l1_,line2,l11l11ll11l_l1_)
	else: l1l111l111_l1_.update(l1111l1l1l1_l1_,l11l11l1lll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㟌")+line2+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㟍")+l11l11ll11l_l1_)
	return
def l1ll1llll11l_l1_(l1111111l1l_l1_):
	def l1llllll11ll_l1_(num,b,l1ll1ll11111_l1_=l1l111_l1_ (u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨ㟎")):
		return ((num == 0) and l1ll1ll11111_l1_[0]) or (l1llllll11ll_l1_(num // b, b, l1ll1ll11111_l1_).lstrip(l1ll1ll11111_l1_[0]) + l1ll1ll11111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠢ࡝࡞ࡥࠦ㟏") + l1llllll11ll_l1_(c, a) + l1l111_l1_ (u"ࠣ࡞࡟ࡦࠧ㟐"),  k[c], p)
		return p
	l1111111l1l_l1_ = l1111111l1l_l1_.split(l1l111_l1_ (u"ࠩࢀࠬࠬ㟑"))[1][:-1]
	l1ll1l1ll111_l1_ = eval(l1l111_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫ㟒")+l1111111l1l_l1_,{l1l111_l1_ (u"ࠫࡧࡧࡳࡦࡐࠪ㟓"):l1llllll11ll_l1_,l1l111_l1_ (u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬ㟔"):unpack})
	return l1ll1l1ll111_l1_
def l111lll11ll_l1_(url,l1lll1111l11_l1_=l1l111_l1_ (u"࠭ࠧ㟕")):
	if l1lll1111l11_l1_==l1l111_l1_ (u"ࠧ࡭ࡱࡺࡩࡷ࠭㟖"): url = re.sub(l1l111_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨ㟗"),lambda l1l11111111_l1_: l1l11111111_l1_.group(0).lower(),url)
	elif l1lll1111l11_l1_==l1l111_l1_ (u"ࠩࡸࡴࡵ࡫ࡲࠨ㟘"): url = re.sub(l1l111_l1_ (u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪ㟙"),lambda l1l11111111_l1_: l1l11111111_l1_.group(0).upper(),url)
	return url
def l1ll1lll1l1l_l1_(l11ll1l1l11_l1_):
	l111lllll11_l1_,l11111ll1ll_l1_ = False,False
	conn = sqlite3.connect(l111l1ll1l1_l1_)
	conn.text_factory = str
	l1lllll1l1_l1_ = conn.cursor()
	if len(l11ll1l1l11_l1_)==1: l111lll1lll_l1_ = l1l111_l1_ (u"ࠫ࠭ࠨࠧ㟚")+l11ll1l1l11_l1_[0]+l1l111_l1_ (u"ࠬࠨࠩࠨ㟛")
	else: l111lll1lll_l1_ = str(tuple(l11ll1l1l11_l1_))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭㟜")+l111lll1lll_l1_+l1l111_l1_ (u"ࠧࠡ࠽ࠪ㟝"))
	l1l1l11l11l_l1_ = l1lllll1l1_l1_.fetchall()
	l11lll1ll1l_l1_ = {}
	for addon_id in l11ll1l1l11_l1_: l11lll1ll1l_l1_[addon_id] = (False,False)
	for addon_id,l11111ll1ll_l1_ in l1l1l11l11l_l1_:
		l111lllll11_l1_ = True
		l11111ll1ll_l1_ = l11111ll1ll_l1_==1
		l11lll1ll1l_l1_[addon_id] = (l111lllll11_l1_,l11111ll1ll_l1_)
	conn.close()
	return l11lll1ll1l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠨࠩ㟞")
	if file==l1l1ll1ll1ll_l1_: status = l11111ll1l1_l1_(True,False)
	if os.path.exists(file):
		l1l11lllll1_l1_ = open(file,l1l111_l1_ (u"ࠩࡵࡦࠬ㟟")).read()
		if kodi_version>18.99: l1l11lllll1_l1_ = l1l11lllll1_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㟠"))
		if file==l1l1ll1ll1ll_l1_: l1lll_l1_ = l1l11lllll1_l1_
		else:
			l111l1111l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㟡"),l1l11lllll1_l1_)
			if l111l1111l1_l1_:
				l1lll_l1_ = {}
				for key in l111l1111l1_l1_.keys():
					l1lll_l1_[key] = []
					for l1llllllll11_l1_ in l111l1111l1_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = l1l111_l1_ (u"ࠬ࠭㟢"),l1l111_l1_ (u"࠭ࠧ㟣"),l1l111_l1_ (u"ࠧࠨ㟤"),l1l111_l1_ (u"ࠨࠩ㟥"),l1l111_l1_ (u"ࠩࠪ㟦"),l1l111_l1_ (u"ࠪࠫ㟧"),l1l111_l1_ (u"ࠫࠬ㟨"),l1l111_l1_ (u"ࠬ࠭㟩"),l1l111_l1_ (u"࠭ࠧ㟪")
						type = l1llllllll11_l1_[0]
						name = l1llllllll11_l1_[1]
						name = l11lll1llll_l1_(name)
						url = l1llllllll11_l1_[2]
						mode = l1llllllll11_l1_[3]
						l11l_l1_ = l1llllllll11_l1_[4]
						l1llllll1_l1_ = l1llllllll11_l1_[5]
						if len(l1llllllll11_l1_)>6: text = l1llllllll11_l1_[6]
						if len(l1llllllll11_l1_)>7: context = l1llllllll11_l1_[7]
						if len(l1llllllll11_l1_)>8: l1llllll11l_l1_ = l1llllllll11_l1_[8]
						if file==favoritesfile: l1l1llll1ll1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠧࠨ㟫"),l1llllll11l_l1_
						else: l1l1llll1ll1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
						l1lll_l1_[key].append(l1l1llll1ll1_l1_)
			l1l11ll1111_l1_ = str(l1lll_l1_)
			if kodi_version>18.99: l1l11ll1111_l1_ = l1l11ll1111_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㟬"))
			open(file,l1l111_l1_ (u"ࠩࡺࡦࠬ㟭")).write(l1l11ll1111_l1_)
	return l1lll_l1_
def l1ll1llll1l_l1_(l1lll11l1ll_l1_):
	l1lll1l1l11l_l1_ = l1lll11l1ll_l1_.split(l1l111_l1_ (u"ࠪ࠱ࠬ㟮"),1)[0]
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1l111_l1_ (u"ࠫࠬ㟯"),l1l111_l1_ (u"ࠬ࠭㟰"),l1l111_l1_ (u"࠭ࠧ㟱")
	if   l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㟲")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㟳")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㟴")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㟵")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ㟶")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㟷")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ㟸")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㟹")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㟺"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㟻")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㟼")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㟽")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㟾")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㟿")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㠀")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㠁"):	from l1111l11l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㠂"):		from l1111llll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ㠃")	:	from l1111l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭㠄")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ㠅")	:	from l111111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㠆")	:	from l1111111l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㠇"):	from l1l1l11l1l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㠈")	:	from l11ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ㠉")	:	from l11l11l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㠊")	:	from l111llll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㠋")	:	from l111ll1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㠌")	:	from l111ll11l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㠍")	:	from l111l1ll1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ㠎")	:	from l111l111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ㠏")	:	from l111l111l1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ㠐")	:	from l1lllll11l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㠑")	:	from l1llll1lll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㠒")	:	from l1llll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ㠓")	:	from l1llll11l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㠔")		:	from l1llll111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㠕")	:	from l1ll1lll111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㠖")		:	from l1ll1ll1lll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㠗")		:	from IPTV			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㠘")	:	from l1ll11lllll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㠙")	:	from l1ll11llll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㠚")	:	from l1ll11ll1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㠛")	:	from l1ll111ll11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㠜")	:	from l1l1111l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㠝")		:	from M3U			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㠞")	:	from l1ll1ll11lll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ㠟")	:	from l1lll1l11l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㠠")		:	from l11l11lll11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㠡")	:	from l1ll11lll1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㠢"):	from l11ll1lllll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㠣")	:	from l11l1l111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㠤")	:	from l1111lll11l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㠥")	:	from l11lllll11l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ㠦")	:	from l1ll111lll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㠧")		:	from l11111l1ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ㠨")	:	from l1ll1l1111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㠩")		:	from l11llll1111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㠪")	:	from l11lll1l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㠫"):	from l11ll1l111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_
	return l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_
def l1llll11llll_l1_(l1l1ll1l111l_l1_,headers,l11_l1_):
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㠬"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨ㠭")+l1l1ll1l111l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ㠮")+str(headers)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㠯"))
	l1l111l111_l1_ = l1l11l1111_l1_()
	l1l111l111_l1_.create(l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㠰"),l1l111_l1_ (u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ㠱"))
	l1l11l1l1l_l1_ = 1024*1024
	chunksize = 1*l1l11l1l1l_l1_
	from requests import get
	response = get(l1l1ll1l111l_l1_,stream=True,headers=headers)
	l1ll111ll1ll_l1_ = response.headers
	response.close()
	l1ll111l1l11_l1_ = bytes()
	if not l1ll111ll1ll_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㠲"),l1l111_l1_ (u"ࠩࠪ㠳"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㠴"),l1l111_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧ㠵"))
		l1l111l111_l1_.close()
	else:
		if l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭㠶") not in list(l1ll111ll1ll_l1_.keys()): filesize = 0
		else: filesize = int(l1ll111ll1ll_l1_[l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ㠷")])
		l1l111llll_l1_ = str(int(1000*filesize/l1l11l1l1l_l1_)/1000.0)
		l11llll111_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧ㠸") in list(l1ll111ll1ll_l1_.keys()) and filesize>l1l11l1l1l_l1_:
			l1ll11ll11ll_l1_ = True
			ranges = []
			l11ll111l1l_l1_ = 10
			ranges.append(str(0*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㠹")+str(1*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(1*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㠺")+str(2*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(2*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㠻")+str(3*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(3*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㠼")+str(4*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(4*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㠽")+str(5*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(5*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㠾")+str(6*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(6*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㠿")+str(7*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(7*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡀")+str(8*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(8*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡁")+str(9*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(9*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㡂"))
			l11ll1lll1l_l1_ = float(l11llll111_l1_)/l11ll111l1l_l1_
			l111111l1l1_l1_ = l11ll1lll1l_l1_/int(1+l11ll1lll1l_l1_)
		else:
			l1ll11ll11ll_l1_ = False
			l11ll111l1l_l1_ = 1
			l111111l1l1_l1_ = 1
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㡃"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭㡄")+str(l1ll11ll11ll_l1_)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ㡅")+str(filesize)+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㡆"))
		l1l11l111l_l1_,l1ll11llll1l_l1_ = 0,0
		for l1lll1l1llll_l1_ in range(l11ll111l1l_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll11ll11ll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ㡇")] = l1l111_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩ㡈")+ranges[l1lll1l1llll_l1_]
			response = get(l1l1ll1l111l_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l111l111_l1_.iscanceled():
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㡉"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫ㡊"))
					break
				l1l11l111l_l1_ += l111111l1l1_l1_
				l1ll111l1l11_l1_ += chunk
				if not l1ll11llll1l_l1_: l1ll11llll1l_l1_ = len(chunk)
				if filesize: l1l1111l11_l1_(l1l111l111_l1_,100*l1l11l111l_l1_//l11llll111_l1_,l1l111_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭㡋"),str(100.0*l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"࠭ࠠ࠰ࠢࠪ㡌")+l1l111llll_l1_+l1l111_l1_ (u"ࠧࠡࡏࡅࠫ㡍"))
				else: l1l1111l11_l1_(l1l111l111_l1_,l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize,l1l111_l1_ (u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭㡎"),str(100.0*l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠩࠣࡑࡇ࠭㡏"))
			response.close()
		l1l111l111_l1_.close()
		if len(l1ll111l1l11_l1_)<filesize and filesize>0:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㡐"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ㡑")+str(len(l1ll111l1l11_l1_)//l1l11l1l1l_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪ㡒")+l1l111llll_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㡓"))
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠧࠨ㡔"),l1l111_l1_ (u"ࠨว็฾ฬว้ࠠะิ์ั࠭㡕"),l1l111_l1_ (u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩ㡖"),l1l111_l1_ (u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬ㡗"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㡘"),l1l111_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩ㡙")+str(len(l1ll111l1l11_l1_)//l1l11l1l1l_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ㡚")+l1l111llll_l1_+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ㡛"))
			if l11l111111l_l1_==2: l1ll111l1l11_l1_ = l1llll11llll_l1_(l1l1ll1l111l_l1_,headers,l11_l1_)
			elif l11l111111l_l1_==1: l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㡜"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ㡝"))
			else: return l1l111_l1_ (u"ࠪࠫ㡞")
			if not l1ll111l1l11_l1_: return l1l111_l1_ (u"ࠫࠬ㡟")
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㡠"),l1l111_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ㡡")+l1l111llll_l1_+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㡢"))
	return l1ll111l1l11_l1_
def l111111lll1_l1_(l1ll1_l1_):
	return response
def l11l1111lll_l1_(l1ll1lll11ll_l1_=l1l111_l1_ (u"ࠨࠩ㡣")):
	l1ll11lll1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡶࡸࡷ࠭㡤"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㡥"),l1l111_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ㡦"))
	if l1ll11lll1l1_l1_: return l1ll11lll1l1_l1_
	l1ll1lll11ll_l1_,l1ll1l111l11_l1_,l1lll1l1l1ll_l1_,l1l1111lll1_l1_,l1lll1l1l1l1_l1_,l1111ll11l1_l1_,timezone = l1l111_l1_ (u"ࠬ࠭㡧"),l1l111_l1_ (u"࠭ࠧ㡨"),l1l111_l1_ (u"ࠧࠨ㡩"),l1l111_l1_ (u"ࠨࠩ㡪"),l1l111_l1_ (u"ࠩࠪ㡫"),l1l111_l1_ (u"ࠪࠫ㡬"),l1l111_l1_ (u"ࠫࠬ㡭")
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ㡮")+l1ll1lll11ll_l1_+l1l111_l1_ (u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㡯")
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㡰"):l1l111_l1_ (u"ࠨࠩ㡱")}
	response = l1111llllll_l1_(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㡲"),url,l1l111_l1_ (u"ࠪࠫ㡳"),headers,l1l111_l1_ (u"ࠫࠬ㡴"),l1l111_l1_ (u"ࠬ࠭㡵"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㡶"))
	if not response.succeeded: l1111ll1l11_l1_ = l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㡷")+l1ll1l111l11_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㡸")+l1lll1l1l1ll_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㡹")+l1lll1l1l1l1_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㡺")+l1111ll11l1_l1_+l1l111_l1_ (u"ࠫ࠱࠭㡻")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠬࡢࡻ࠯ࠬࡂࡠࢂࡢࡽࠨ㡼"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l11l111l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㡽"),html)
			if l1l111_l1_ (u"ࠧࡪࡲࠪ㡾") in list(l11l11l111l_l1_.keys()): l1ll1lll11ll_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠨ࡫ࡳࠫ㡿")]
			if l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ㢀") in list(l11l11l111l_l1_.keys()): l1ll1l111l11_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭㢁")]
			if l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㢂") in list(l11l11l111l_l1_.keys()): l1lll1l1l1ll_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㢃")]
			if l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ㢄") in list(l11l11l111l_l1_.keys()): l1l1111lll1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭㢅")]
			if l1l111_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ㢆") in list(l11l11l111l_l1_.keys()): l1lll1l1l1l1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ㢇")]
			if l1l111_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ㢈") in list(l11l11l111l_l1_.keys()): l1111ll11l1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ㢉")]
			if l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㢊") in list(l11l11l111l_l1_.keys()):
				timezone = l11l11l111l_l1_[l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㢋")][l1l111_l1_ (u"ࠧࡶࡶࡦࠫ㢌")]
				if timezone[0] not in [l1l111_l1_ (u"ࠨ࠯ࠪ㢍"),l1l111_l1_ (u"ࠩ࠮ࠫ㢎")]: timezone = l1l111_l1_ (u"ࠪ࠯ࠬ㢏")+timezone
			l1111ll1l11_l1_ = l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢐")+l1ll1l111l11_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㢑")+l1lll1l1l1ll_l1_+l1l111_l1_ (u"࠭ࠬࠨ㢒")+l1lll1l1l1l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢓")+l1111ll11l1_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㢔")+timezone
			if kodi_version>18.99: l1111ll1l11_l1_ = l1111ll1l11_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㢕")).decode(l1l111_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㢖"))
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㢗"),l1l111_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ㢘"),l1111ll1l11_l1_,l111l11l_l1_)
	return l1111ll1l11_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"࠭ࠧ㢙"),True
	if search.count(l1l111_l1_ (u"ࠧࡠࠩ㢚"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠨࡡࠪ㢛"),1)
		options = l1l111_l1_ (u"ࠩࡢࠫ㢜")+options
		if l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㢝") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1l1llllllll_l1_():
	l1lll1111l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㢞"))
	l1llllll1l11_l1_ = 0
	if os.path.exists(l1lll1111l1l_l1_):
		for filename in os.listdir(l1lll1111l1l_l1_):
			if l1l111_l1_ (u"ࠬ࠴ࡰࡺࡱࠪ㢟") in filename: continue
			if l1l111_l1_ (u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫ㢠") in filename: continue
			l1ll1111ll_l1_ = os.path.join(l1lll1111l1l_l1_,filename)
			size,count = l1ll1l1ll1_l1_(l1ll1111ll_l1_)
			l1llllll1l11_l1_ += size
	return l1llllll1l11_l1_
def l11111ll1l1_l1_(l1l1lll11ll_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㢡")][3]
	user = l1l1ll1l11l_l1_(32)
	l1111ll1l11_l1_ = l11l1111lll_l1_()
	l1lll1l1l1ll_l1_ = l1111ll1l11_l1_.split(l1l111_l1_ (u"ࠨ࠮ࠪ㢢"))[2]
	l1llllll1l11_l1_ = l1l1llllllll_l1_()
	payload = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㢣"):user,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㢤"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㢥"):l1lll1l1l1ll_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㢦"):l1lll1111111_l1_(l1llllll1l11_l1_)}
	if not l1l1lll11ll_l1_: l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㢧"),(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㢨"),url,payload,l1l111_l1_ (u"ࠨࠩ㢩"),l1l111_l1_ (u"ࠩࠪ㢪"),l1l111_l1_ (u"ࠪࠫ㢫")))
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㢬"),l1l111_l1_ (u"ࠬ࠭㢭"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㢮"),url,payload,l1l111_l1_ (u"ࠧࠨ㢯"),l1l111_l1_ (u"ࠨࠩ㢰"),l1l111_l1_ (u"ࠩࠪ㢱"),l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭㢲"),True,True)
	l11llll1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㢳"))
	if not l11llll1ll1_l1_: l11llll1ll1_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡘࠩ㢴")
	l1lll11ll1l1_l1_ = l11llll1ll1_l1_
	if not response.succeeded: l1lll11ll1l1_l1_ = l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㢵")
	else:
		l1l11lll1ll_l1_,l1111llll1l_l1_,l111l11l11l_l1_,l11l1l11111_l1_ = l1l111_l1_ (u"ࠧࠨ㢶"),l1l111_l1_ (u"ࠨࠩ㢷"),l1l111_l1_ (u"ࠩࠪ㢸"),[]
		newfile = response.content
		if newfile:
			l11l1l11111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㢹"),newfile)
			for l1lllll11111_l1_,l1ll1l11l1ll_l1_,message in l11l1l11111_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㢺")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㢻"))
				if l1lllll11111_l1_==l1l111_l1_ (u"࠭࠰ࠨ㢼"): l1l11lll1ll_l1_ += message+l1l111_l1_ (u"ࠧ࠻࠼ࠪ㢽")
				else: l1111llll1l_l1_ += message+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㢾")
			l1111llll1l_l1_ = l1111llll1l_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㢿"))
			l1l11lll1ll_l1_ = l1l11lll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠾࠿࠭㣀"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㣁"),l1l11lll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㣂"),l1lll1111111_l1_(now))
		if os.path.exists(l1l1ll1ll1ll_l1_): l111l11l11l_l1_ = open(l1l1ll1ll1ll_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㣃")).read()
		if kodi_version>18.99: l1111llll1l_l1_ = l1111llll1l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㣄"))
		if l1111llll1l_l1_!=l111l11l11l_l1_:
			l1lll11ll1l1_l1_ = l1l111_l1_ (u"ࠨࡐࡈ࡛ࠬ㣅")
			try: open(l1l1ll1ll1ll_l1_,l1l111_l1_ (u"ࠩࡺࡦࠬ㣆")).write(l1111llll1l_l1_)
			except: pass
		if l11_l1_:
			l11l1l11111_l1_ = sorted(l11l1l11111_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l11l111_l1_ = l1l111_l1_ (u"ࠪࠫ㣇")
			for l1lllll11111_l1_,l1ll1l11l1ll_l1_,message in l11l1l11111_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㣈")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㣉"))
				if l111l11l111_l1_: l111l11l111_l1_ += l1l111_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ㣊")
				if l1lllll11111_l1_==l1l111_l1_ (u"ࠧ࠱ࠩ㣋"): continue
				date = message.split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㣌"))[0]
				l11ll1111l1_l1_ = l1l111_l1_ (u"ࠩࠪ㣍")
				if l1ll1l11l1ll_l1_:
					l11ll1111l1_l1_ = l1l111_l1_ (u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧ㣎")
					if kodi_version>18.99: l11ll1111l1_l1_ = l11ll1111l1_l1_.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㣏")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㣐"))
				l111l11l111_l1_ += message.replace(date,l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㣑")+date+l11ll1111l1_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㣒"))+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㣓")
			l111l11l111_l1_ = escapeUNICODE(l111l11l111_l1_)
			l1l11ll111_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㣔"),l1l111_l1_ (u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭㣕"),l111l11l111_l1_,l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㣖"))
			l1lll11ll1l1_l1_ = l1l111_l1_ (u"ࠬࡕࡌࡅࠩ㣗")
		if l1lll11ll1l1_l1_!=l11llll1ll1_l1_:
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㣘"),l1lll11ll1l1_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㣙"))
	return l1lll11ll1l1_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll11l1ll1l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll11l1ll1l_l1_ = False
	l11ll1llll_l1_ = time.time()
	if l1ll11l1ll1l_l1_: resp = l11ll1llll_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠨࠩ㣚"),l1l111_l1_ (u"ࠩࠪ㣛"),l1l111_l1_ (u"ࠪࠫ㣜"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㣝"),l1l111_l1_ (u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫ㣞"))
	else: l1llll1l11_l1_ = True
	if l1llll1l11_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"࠭࠮ࡥࡤࠪ㣟")) and l1l111_l1_ (u"ࠧࡥࡣࡷࡥࠬ㣠") in filename:
				l1lll11111_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
				except: return
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡱࡸࡪ࡭ࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭࠾ࠫ㣡"))
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡲࡴࡹ࡯࡭ࡪࡼࡨ࠿ࠬ㣢"))
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫ㣣"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㣤"),l1l111_l1_ (u"ࠬ࠭㣥"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㣦"),l1l111_l1_ (u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ㣧"))
	return
def l1ll11lll111_l1_(word):
	if l1l111_l1_ (u"ࠨ࡝ࠪ㣨") in word and l1l111_l1_ (u"ࠩࡠࠫ㣩") in word:
		l11ll1ll111_l1_ = [l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㣪"),l1l111_l1_ (u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ㣫"),l1l111_l1_ (u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭㣬"),l1l111_l1_ (u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨ㣭"),l1l111_l1_ (u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ㣮"),l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㣯"),l1l111_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ㣰"),l1l111_l1_ (u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫ㣱"),l1l111_l1_ (u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭㣲")]
		l11ll1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬ㣳"),word,re.DOTALL)
		l11ll111l11_l1_ = re.findall(l1l111_l1_ (u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨ㣴"),word,re.DOTALL)
		l1ll1l111lll_l1_ = l11ll1ll111_l1_+l11ll1111ll_l1_+l11ll111l11_l1_
		for tag in l1ll1l111lll_l1_: word = word.replace(tag,l1l111_l1_ (u"ࠧࠨ㣵"))
	return word
def l1lllll111ll_l1_(l1l111l11ll_l1_,l1111l1111l_l1_,l1lll1llll11_l1_,l1ll1ll111l1_l1_):
	from PIL import ImageDraw,ImageFont,Image
	l11ll1l1l1l_l1_,l11l1l11l1l_l1_,l1ll111ll111_l1_ = l1l111_l1_ (u"ࠨࠩ㣶"),0,15000
	l1l111l11ll_l1_ = l1l111l11ll_l1_.replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ㣷"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔ࠽࠾࠿࠭㣸"))
	l1l1llll1l11_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l1111l1111l_l1_)
	l1lll1llll11_l1_ -= l1111l1111l_l1_*2
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"ࠫࡗࡍࡂࡂࠩ㣹"),(l1lll1llll11_l1_,99),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	for l1ll11ll1111_l1_ in l1l111l11ll_l1_.splitlines():
		l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
		l1111l11ll1_l1_,newline = 0,l1l111_l1_ (u"ࠬ࠭㣺")
		for word in l1ll11ll1111_l1_.split(l1l111_l1_ (u"࠭ࠠࠨ㣻")):
			l111ll111ll_l1_ = l1ll11lll111_l1_(l1l111_l1_ (u"ࠧࠡࠩ㣼")+word)
			l1lllll1ll1l_l1_,l111ll1l111_l1_ = l111lll11l1_l1_.textsize(l111ll111ll_l1_,font=l1l1llll1l11_l1_)
			if l1111l11ll1_l1_+l1lllll1ll1l_l1_<l1lll1llll11_l1_:
				if not newline: newline += word
				else: newline += l1l111_l1_ (u"ࠨࠢࠪ㣽")+word
				l1111l11ll1_l1_ += l1lllll1ll1l_l1_
			else:
				if l1lllll1ll1l_l1_<l1lll1llll11_l1_:
					newline += l1l111_l1_ (u"ࠩ࡟ࡲࠥ࠭㣾")+word
					l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
					l1111l11ll1_l1_ = l1lllll1ll1l_l1_
				else:
					while l1lllll1ll1l_l1_>l1lll1llll11_l1_:
						for l1l11l111l_l1_ in range(1,len(l1l111_l1_ (u"ࠪࠤࠬ㣿")+word),1):
							l111lll1ll1_l1_ = l1l111_l1_ (u"ࠫࠥ࠭㤀")+word[:l1l11l111l_l1_]
							l11l111llll_l1_ = word[l1l11l111l_l1_:]
							l1llll11111l_l1_ = l1ll11lll111_l1_(l111lll1ll1_l1_)
							l11ll11ll11_l1_,l111l1l1111_l1_ = l111lll11l1_l1_.textsize(l1llll11111l_l1_,font=l1l1llll1l11_l1_)
							if l1111l11ll1_l1_+l11ll11ll11_l1_>l1lll1llll11_l1_:
								l1lll1l1l111_l1_ = l1lllll1ll1l_l1_-l11ll11ll11_l1_
								newline += l111lll1ll1_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤁")
								l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
								l1lllll1ll1l_l1_ = l1lll1l1l111_l1_
								if l1lll1l1l111_l1_>l1lll1llll11_l1_:
									l1111l11ll1_l1_ = 0
									word = l11l111llll_l1_
								else:
									l1111l11ll1_l1_ = l1lll1l1l111_l1_
									newline += l11l111llll_l1_
								break
				if l11l1l11l1l_l1_>l1ll111ll111_l1_: break
		l11ll1l1l1l_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠩ㤂")+newline
		if l11l1l11l1l_l1_>l1ll111ll111_l1_: break
	l11ll1l1l1l_l1_ = l11ll1l1l1l_l1_[1:]
	l11ll1l1l1l_l1_ = l11ll1l1l1l_l1_.replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ㤃"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ㤄"))
	return l11ll1l1l1l_l1_
def l11l1ll1l11_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤅"),l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ㤆"))
	text = text.replace(l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㤇"),l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴࡷࡰࡤ࠭㤈"))
	text = text.replace(l1l111_l1_ (u"࡛࠭ࡍࡇࡉࡘࡢ࠭㤉"),l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ㤊"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡝ࡕࡍࡌࡎࡔ࡞ࠩ㤋"),l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡩࡨࡪࡷࡣࠬ㤌"))
	text = text.replace(l1l111_l1_ (u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ㤍"),l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡤࡧࡱࡸࡪࡸ࡟ࠨ㤎"))
	text = text.replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㤏"),l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤ࡫࡮ࡥࡥࡲࡰࡴࡸ࡟ࠨ㤐"))
	l1llllll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝࡝ࡆࡓࡑࡕࡒࠡࠪ࠱࠮ࡄ࠯࡜࡞ࠩ㤑"),text,re.DOTALL)
	for l1lll1l111ll_l1_ in l1llllll11l1_l1_: text = text.replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ㤒")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠩࡠࠫ㤓"),l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡩ࡯࡭ࡱࡵࠫ㤔")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠫࡤ࠭㤕"))
	return text
def l1lllllllll1_l1_(l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text,profile,l11ll1l11l1_l1_,l1lll11l11l1_l1_,l1ll1lll1l11_l1_):
	l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㤖"))
	if l1111111lll_l1_:
		l1lll_l1_ = LANGUAGE_TRANSLATE([l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text])
		if l1lll_l1_: l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text = l1lll_l1_
	from PIL import ImageDraw,ImageFont,Image
	if kodi_version<19:
		text = text.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㤗"))
		header = header.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㤘"))
		l111l1l11l1_l1_ = l111l1l11l1_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㤙"))
		l1ll11ll1l11_l1_ = l1ll11ll1l11_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㤚"))
		l111l1l1lll_l1_ = l111l1l1lll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㤛"))
	l111ll1ll11_l1_ = 5
	l1l1llll111l_l1_ = 20
	l1llll1ll111_l1_ = 20
	l1lll1l1ll1l_l1_ = 0
	l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㤜")
	l1ll1111llll_l1_ = 0
	l1ll11l11111_l1_ = 19
	l11l1l11l11_l1_ = 30
	l1llll1l1111_l1_ = 8
	l1lll1l11ll1_l1_ = True
	l1ll11ll1l1l_l1_ = 375
	l1l1lllll1ll_l1_ = 410
	l1l1ll1lllll_l1_ = 50
	l1ll1ll11l11_l1_ = 280
	l111l111ll1_l1_ = 28
	l1ll1111l11l_l1_ = 5
	l11l1111l11_l1_ = 0
	l1lll1lll1ll_l1_ = 31
	l11l1111ll1_l1_ = [36,32,28]
	if profile in [l1l111_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ㤝"),l1l111_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ㤞")]:
		if profile==l1l111_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ㤟"):
			l1l111l1111_l1_ = l1l111_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ㤠")
			l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㤡")
			l1lll1l11ll1_l1_ = True
			l1lll1l1ll1l_l1_ = 10
		else:
			l1l111l1111_l1_ = 97+20
			l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㤢")
			l1lll1l11ll1_l1_ = False
		l11l1111ll1_l1_ = [33,33,33]
		l1llll1ll111_l1_ = 20
		l1l1llll111l_l1_ = 0
		l11l1l11l11_l1_ = 20
		l1ll11l11111_l1_ = 25+10
	elif profile==l1l111_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨ㤣"): l11l1111ll1_l1_ = [28,24,20] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪ㤤"): l11l1111ll1_l1_ = [32,28,24] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㤥"): l11l1111ll1_l1_ = [36,32,28] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㤦"): l1l111l1111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㤧"): l1l111l1111_l1_ = l1l111_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ㤨")
	elif profile==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨ㤩"): l11l1111ll1_l1_ = [28,23,18] ; l1l111l1111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ㤪"): l11l1111ll1_l1_ = [28,23,18] ; l1l111l1111_l1_ = l1l111_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ㤫")
	l11111lllll_l1_ = l11l1111ll1_l1_[0]
	l11l11l11ll_l1_ = l11l1111ll1_l1_[1]
	l1l1111ll11_l1_ = l11l1111ll1_l1_[2]
	l1111l1l11l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l11111lllll_l1_)
	l1llll1lll1l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l11l11l11ll_l1_)
	l1llllll111l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l1l1111ll11_l1_)
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"࠭ࡒࡈࡄࡄࠫ㤬"),(100,100),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	l1ll11l11lll_l1_,l1lll1111ll1_l1_ = l111lll11l1_l1_.textsize(l1l111_l1_ (u"ࠧࡉࡊࡋࠤࡇࡈࡂࠡ࠺࠻࠼ࠥ࠶࠰࠱ࠩ㤭"),font=l1llll1lll1l_l1_)
	l1ll11ll11l1_l1_,l111l11ll1l_l1_ = l111lll11l1_l1_.textsize(l1l111_l1_ (u"ࠨࡊࡋࡌࠥࡈࡂࡃࠢ࠻࠼࠽ࠦ࠰࠱࠲ࠪ㤮"),font=l1111l1l11l_l1_)
	l1ll111l111l_l1_ = header.count(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤯"))+1
	l11ll11l11l_l1_ = l1l1llll111l_l1_+l1ll111l111l_l1_*(l111l11ll1l_l1_+l1lll1l1ll1l_l1_)-l1lll1l1ll1l_l1_
	l1lll11l1lll_l1_ = {l1l111_l1_ (u"ࠪࡨࡪࡲࡥࡵࡧࡢ࡬ࡦࡸࡡ࡬ࡣࡷࠫ㤰"):False,l1l111_l1_ (u"ࠫࡸࡻࡰࡱࡱࡵࡸࡤࡲࡩࡨࡣࡷࡹࡷ࡫ࡳࠨ㤱"):True,l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇࠥࡒࡉࡈࡃࡗ࡙ࡗࡋࠠࡂࡎࡏࡅࡍ࠭㤲"):False}
	from arabic_reshaper import ArabicReshaper
	l11ll11l111_l1_ = ArabicReshaper(configuration=l1lll11l1lll_l1_)
	if text:
		l1l1111l1l1_l1_ = l1lll11l11l1_l1_-l11l1l11l11_l1_*2
		l1ll111lllll_l1_ = l1lll1111ll1_l1_+l1llll1l1111_l1_
		l1lll11lll11_l1_ = l11ll11l111_l1_.reshape(text)
		if l1lll1l11ll1_l1_:
			l1l1ll1l1ll1_l1_ = l1lllll111ll_l1_(l1lll11lll11_l1_,l11l11l11ll_l1_,l1l1111l1l1_l1_,l1ll111lllll_l1_)
			l11111111ll_l1_ = l1ll11lll111_l1_(l1l1ll1l1ll1_l1_)
			l1lll11l1l1l_l1_ = l11111111ll_l1_.count(l1l111_l1_ (u"࠭࡜࡯ࠩ㤳"))+1
			if l1lll11l1l1l_l1_<6:
				l1ll11ll1lll_l1_ = l1l1111l1l1_l1_
				l1l1ll1l1ll1_l1_ = l1lllll111ll_l1_(l1lll11lll11_l1_,l11l11l11ll_l1_,l1ll11ll1lll_l1_,l1ll111lllll_l1_)
				l11111111ll_l1_ = l1ll11lll111_l1_(l1l1ll1l1ll1_l1_)
				l1lll11l1l1l_l1_ = l11111111ll_l1_.count(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㤴"))+1
			l11lll11lll_l1_ = l1ll11l11111_l1_+l1lll11l1l1l_l1_*l1ll111lllll_l1_-l1llll1l1111_l1_
		else:
			l11lll11lll_l1_ = l1ll11l11111_l1_+l1lll1111ll1_l1_
			l11111111ll_l1_ = l1lll11lll11_l1_.split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤵"))[0]
			l1l1ll1l1ll1_l1_ = l1lll11lll11_l1_.split(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤶"))[0]
	else: l11lll11lll_l1_ = l1ll11l11111_l1_
	l1lll1ll1l11_l1_ = l11l1111l11_l1_+l1lll1lll1ll_l1_
	if l1ll1lll1l11_l1_:
		l1ll1l1l11ll_l1_ = l1l1lllll1ll_l1_-l1ll11ll1l1l_l1_
		l1lll1ll1l11_l1_ += l1ll1l1l11ll_l1_
	else: l1ll1l1l11ll_l1_ = 0
	if l111l1l11l1_l1_ or l1ll11ll1l11_l1_ or l111l1l1lll_l1_: l1lll1ll1l11_l1_ += l1l1ll1lllll_l1_
	if l1l111l1111_l1_!=l1l111_l1_ (u"࡙ࠪࡕࡖࡅࡓࠩ㤷"): l11l11111ll_l1_ = l1l111l1111_l1_
	else: l11l11111ll_l1_ = l11ll11l11l_l1_+l11lll11lll_l1_+l1lll1ll1l11_l1_
	l1lllllll11l_l1_ = l11l11111ll_l1_-l11ll11l11l_l1_-l1lll1ll1l11_l1_-l1ll11l11111_l1_
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"ࠫࡗࡍࡂࡂࠩ㤸"),(l1lll11l11l1_l1_,l11l11111ll_l1_),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	if not l1ll11ll1l11_l1_ and l111l1l11l1_l1_ and l111l1l1lll_l1_:
		l111l111ll1_l1_ += 105
		l1ll1111l11l_l1_ -= 110
	if header:
		l111ll1ll1l_l1_ = l1l1llll111l_l1_
		header = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(line,font=l1111l1l11l_l1_)
				if l1l111l1ll1_l1_==l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㤹"): l1ll11llll11_l1_ = l111ll1ll11_l1_+(l1lll11l11l1_l1_-width)/2
				elif l1l111l1ll1_l1_==l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㤺"): l1ll11llll11_l1_ = l111ll1ll11_l1_+l1lll11l11l1_l1_-width-l1llll1ll111_l1_
				elif l1l111l1ll1_l1_==l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㤻"): l1ll11llll11_l1_ = l111ll1ll11_l1_+l1llll1ll111_l1_
				l111lll11l1_l1_.text((l1ll11llll11_l1_,l111ll1ll1l_l1_),line,font=l1111l1l11l_l1_,fill=l1l111_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ㤼"))
			l111ll1ll1l_l1_ += l11111lllll_l1_+l1lll1l1ll1l_l1_
	if l111l1l11l1_l1_ or l1ll11ll1l11_l1_ or l111l1l1lll_l1_:
		l11ll111lll_l1_ = l11ll11l11l_l1_+l1lllllll11l_l1_+l1ll11l11111_l1_+l1ll1l1l11ll_l1_+l11l1111l11_l1_
		if l111l1l11l1_l1_:
			l111l1l11l1_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l111l1l11l1_l1_))
			l1lll111l1ll_l1_,l111llllll1_l1_ = l111lll11l1_l1_.textsize(l111l1l11l1_l1_,font=l1llllll111l_l1_)
			l11l1111l1l_l1_ = l111l111ll1_l1_+0*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l1lll111l1ll_l1_)/2
			l111lll11l1_l1_.text((l11l1111l1l_l1_,l11ll111lll_l1_),l111l1l11l1_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ㤽"))
		if l1ll11ll1l11_l1_:
			l1ll11ll1l11_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l1ll11ll1l11_l1_))
			l1llll1l111l_l1_,l1lll1llllll_l1_ = l111lll11l1_l1_.textsize(l1ll11ll1l11_l1_,font=l1llllll111l_l1_)
			l11l11l11l1_l1_ = l111l111ll1_l1_+1*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l1llll1l111l_l1_)/2
			l111lll11l1_l1_.text((l11l11l11l1_l1_,l11ll111lll_l1_),l1ll11ll1l11_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠪࡽࡪࡲ࡬ࡰࡹࠪ㤾"))
		if l111l1l1lll_l1_:
			l111l1l1lll_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l111l1l1lll_l1_))
			l11l1llll11_l1_,l111l11l1l1_l1_ = l111lll11l1_l1_.textsize(l111l1l1lll_l1_,font=l1llllll111l_l1_)
			l11111l11ll_l1_ = l111l111ll1_l1_+2*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l11l1llll11_l1_)/2
			l111lll11l1_l1_.text((l11111l11ll_l1_,l11ll111lll_l1_),l111l1l1lll_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠫࡾ࡫࡬࡭ࡱࡺࠫ㤿"))
	if text:
		l1l1lll1l1l1_l1_,l11ll11111l_l1_ = [],[]
		l1l1ll1l1ll1_l1_ = l11l1ll1l11_l1_(l1l1ll1l1ll1_l1_)
		l1ll11l1l1ll_l1_ = l1l1ll1l1ll1_l1_.split(l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡳ࡫ࡷ࡭࡫ࡱࡩࡤ࠭㥀"))
		for l1ll1111111l_l1_ in l1ll11l1l1ll_l1_:
			l11lll1ll11_l1_ = l11ll1l11l1_l1_
			if   l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨ㥁") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㥂")
			elif l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ㥃") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㥄")
			elif l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧ㥅") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㥆")
			l11llll11ll_l1_ = l1ll1111111l_l1_
			l11ll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣ࠳࠰࠿ࡠࠩ㥇"),l1ll1111111l_l1_,re.DOTALL)
			for tag in l11ll1ll111_l1_: l11llll11ll_l1_ = l11llll11ll_l1_.replace(tag,l1l111_l1_ (u"࠭ࠧ㥈"))
			if l11llll11ll_l1_==l1l111_l1_ (u"ࠧࠨ㥉"): width,l1lll1l11111_l1_ = 0,l1ll111lllll_l1_
			else: width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(l11llll11ll_l1_,font=l1llll1lll1l_l1_)
			if   l11lll1ll11_l1_==l1l111_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㥊"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_
			elif l11lll1ll11_l1_==l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㥋"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_+l1l1111l1l1_l1_-width
			elif l11lll1ll11_l1_==l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㥌"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_+(l1l1111l1l1_l1_-width)/2
			if l1111ll1ll1_l1_<l11l1l11l11_l1_: l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_
			l1l1lll1l1l1_l1_.append(l1111ll1ll1_l1_)
			l11ll11111l_l1_.append(width)
		l1111ll1ll1_l1_ = l1l1lll1l1l1_l1_[0]
		l1ll11lll11l_l1_ = l1l1ll1l1ll1_l1_.split(l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࠪ㥍"))
		l11lllllll1_l1_ = (255,255,255,255)
		l1lllll111l1_l1_ = l11lllllll1_l1_
		l1ll111llll1_l1_,l1llll11l111_l1_ = 0,0
		l11111l111l_l1_ = False
		l111l1ll1ll_l1_ = 0
		l1ll111l1111_l1_ = l11ll11l11l_l1_+l1ll11l11111_l1_/2
		if l11lll11lll_l1_<(l1lllllll11l_l1_+l1ll11l11111_l1_):
			l111ll1l11l_l1_ = (l1lllllll11l_l1_+l1ll11l11111_l1_-l11lll11lll_l1_)/2
			l1ll111l1111_l1_ = l11ll11l11l_l1_+l1ll11l11111_l1_+l111ll1l11l_l1_-l1lll1111ll1_l1_/2
		for line in l1ll11lll11l_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1ll1l1l1111_l1_ = line.split(l1l111_l1_ (u"ࠬࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ㥎"),1)
			l1ll1l1l111l_l1_ = line.split(l1l111_l1_ (u"࠭࡟࡯ࡧࡺࡧࡴࡲ࡯ࡳࠩ㥏"),1)
			l1ll1l1l11l1_l1_ = line.split(l1l111_l1_ (u"ࠧࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ㥐"),1)
			l1ll1l11ll11_l1_ = line.split(l1l111_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫ࡲࡵ࡮ࡢࠫ㥑"),1)
			l1lllll1lll1_l1_ = line.split(l1l111_l1_ (u"ࠩࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭㥒"),1)
			l1ll1l11lll1_l1_ = line.split(l1l111_l1_ (u"ࠪࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ㥓"),1)
			l1ll1l11llll_l1_ = line.split(l1l111_l1_ (u"ࠫࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ㥔"),1)
			if len(l1ll1l1l1111_l1_)>1:
				l111l1ll1ll_l1_ += 1
				line = l1ll1l1l1111_l1_[1]
				l1ll111llll1_l1_ = 0
				l1111ll1ll1_l1_ = l1l1lll1l1l1_l1_[l111l1ll1ll_l1_]
				l1llll11l111_l1_ += l1ll111lllll_l1_
				l11111l111l_l1_ = False
			elif len(l1ll1l1l111l_l1_)>1:
				line = l1ll1l1l111l_l1_[1]
				l1lllll111l1_l1_ = line[0:8]
				l1lllll111l1_l1_ = l1l111_l1_ (u"ࠬࠩࠧ㥕")+l1lllll111l1_l1_[2:]
				line = line[9:]
			elif len(l1ll1l1l11l1_l1_)>1:
				line = l1ll1l1l11l1_l1_[1]
				l1lllll111l1_l1_ = l11lllllll1_l1_
			elif len(l1ll1l11ll11_l1_)>1:
				line = l1ll1l11ll11_l1_[1]
				l11111l111l_l1_ = True
				l1ll111llll1_l1_ = l11ll11111l_l1_[l111l1ll1ll_l1_]
			elif len(l1lllll1lll1_l1_)>1:
				line = l1lllll1lll1_l1_[1]
			elif len(l1ll1l11lll1_l1_)>1:
				line = l1ll1l11lll1_l1_[1]
			elif len(l1ll1l11llll_l1_)>1:
				line = l1ll1l11llll_l1_[1]
			if line:
				l1ll1ll111ll_l1_ = l1ll111l1111_l1_+l1llll11l111_l1_
				line = bidi.algorithm.get_display(line)
				width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(line,font=l1llll1lll1l_l1_)
				if l11111l111l_l1_: l1ll111llll1_l1_ -= width
				l1111ll1l1l_l1_ = l1111ll1ll1_l1_+l1ll111llll1_l1_
				l111lll11l1_l1_.text((l1111ll1l1l_l1_,l1ll1ll111ll_l1_),line,font=l1llll1lll1l_l1_,fill=l1lllll111l1_l1_)
				if not l11111l111l_l1_: l1ll111llll1_l1_ += width
				if l1ll1ll111ll_l1_>l1lllllll11l_l1_+l1ll111lllll_l1_: break
	l1lll11l11ll_l1_ = l1l1llll11ll_l1_.replace(l1l111_l1_ (u"࠭࡟࠱࠲࠳࠴ࡤ࠭㥖"),l1l111_l1_ (u"ࠧࡠࠩ㥗")+str(time.time())+l1l111_l1_ (u"ࠨࡡࠪ㥘"))
	l1lll11l11ll_l1_ = l1lll11l11ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ㥙"),l1l111_l1_ (u"ࠪࡠࡡࡢ࡜ࠨ㥚")).replace(l1l111_l1_ (u"ࠫ࠴࠵ࠧ㥛"),l1l111_l1_ (u"ࠬ࠵࠯࠰࠱ࠪ㥜"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	l11l1llll1l_l1_.save(l1lll11l11ll_l1_)
	return l1lll11l11ll_l1_,l11l11111ll_l1_
def l1111llllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	if allow_redirects==l1l111_l1_ (u"࠭ࠧ㥝"): allow_redirects = True
	if l11_l1_==l1l111_l1_ (u"ࠧࠨ㥞"): l11_l1_ = True
	if l11ll1ll11l_l1_==l1l111_l1_ (u"ࠨࠩ㥟"): l11ll1ll11l_l1_ = True
	if l1lll1111lll_l1_==l1l111_l1_ (u"ࠩࠪ㥠"): l1lll1111lll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1lll1l11l1l_l1_ = list(headers.keys())
	if l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㥡") not in l1lll1l11l1l_l1_: headers[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㥢")] = l1l111_l1_ (u"ࠬࡆࡀࡁࡕࡎࡍࡕࡥࡈࡆࡃࡇࡉࡗࡆࡀࡁࠩ㥣")
	l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_ = l1ll1111l1l1_l1_(url)
	l1l1lll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭㥤"))
	l1ll111ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㥥"))
	l1ll11l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ㥦"))
	l1lll11111ll_l1_ = (l1ll11l11l1l_l1_==None and l1lll111l1l1_l1_==None and l1ll1lll1111_l1_==None)
	l111ll1l1l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㥧")]
	l1ll111l1lll_l1_ = l1lllll1_l1_ in l111ll1l1l1_l1_
	l111lll1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㥨")]
	l11ll1llll1_l1_ = l1lllll1_l1_ in l111lll1l11_l1_
	l111llll1l1_l1_ = l1ll111l1lll_l1_ or l11ll1llll1_l1_
	if l1lll11111ll_l1_ and l111llll1l1_l1_:
		if l1ll111l1lll_l1_:
			l1lllllll111_l1_ = l111ll1l1l1_l1_.index(l1lllll1_l1_)
			l1111ll1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㥩")][l1lllllll111_l1_]
			l111l1ll111_l1_ = l111l111111_l1_[l1lllllll111_l1_]
		elif l11ll1llll1_l1_:
			l1lllllll111_l1_ = l111lll1l11_l1_.index(l1lllll1_l1_)
			l1111ll1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨ㥪")][l1lllllll111_l1_]
			l111l1ll111_l1_ = l11l11llll1_l1_[l1lllllll111_l1_]
	if l1lll111l1l1_l1_==l1l111_l1_ (u"࠭ࠧ㥫"): l1lll111l1l1_l1_ = l1l1lll1llll_l1_
	elif l1lll111l1l1_l1_==None and l1ll111ll11l_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㥬"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㥭")] and l11ll1ll11l_l1_: l1lll111l1l1_l1_ = l1l1lll1llll_l1_
	l1lll111l111_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㥮")][7]
	if source==l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪ㥯"): l1l111ll11l_l1_ = 120
	elif source==l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㥰"): l1l111ll11l_l1_ = 20
	elif source==l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㥱"): l1l111ll11l_l1_ = 20
	elif source in l1llllll1ll1_l1_: l1l111ll11l_l1_ = 10
	elif l1ll111l1lll_l1_ or l11ll1llll1_l1_: l1l111ll11l_l1_ = 15
	elif l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍࠨ㥲") in source: l1l111ll11l_l1_ = 70
	elif l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㥳") in source: l1l111ll11l_l1_ = 75
	elif l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㥴") in source: l1l111ll11l_l1_ = 25
	elif l1l111_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㥵") in source: l1l111ll11l_l1_ = 20
	elif l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㥶") in source: l1l111ll11l_l1_ = 20
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㥷") in source: l1l111ll11l_l1_ = 30
	elif l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㥸") in source: l1l111ll11l_l1_ = 25
	elif l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㥹") in source: l1l111ll11l_l1_ = 30
	elif l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㥺") in source: l1l111ll11l_l1_ = 20
	else: l1l111ll11l_l1_ = 15
	if l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㥻") in source and not data and l1l111_l1_ (u"ࠩࠩࠫ㥼") not in l1lllll1_l1_ and l1l111_l1_ (u"ࠪࡃࠬ㥽") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠫ࠴࠭㥾"))+l1l111_l1_ (u"ࠬ࠵ࠧ㥿")
	l11lll111l1_l1_ = (l1ll11l11l1l_l1_!=None)
	l1ll1lllllll_l1_ = (l1lll111l1l1_l1_!=None and l1ll111ll11l_l1_!=l1l111_l1_ (u"࠭ࡓࡕࡑࡓࠫ㦀"))
	if l11lll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧหใ฼๎้ࠦศา๊ๆื๏ࠦัใ็ࠪ㦁"),l1ll11l11l1l_l1_)
	elif l1ll1lllllll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨฬไ฽๏๊ࠠࡅࡐࡖࠤึ่ๅࠨ㦂"),l1lll111l1l1_l1_)
	if l11lll111l1_l1_:
		proxies = {l1l111_l1_ (u"ࠤ࡫ࡸࡹࡶࠢ㦃"):l1ll11l11l1l_l1_,l1l111_l1_ (u"ࠥ࡬ࡹࡺࡰࡴࠤ㦄"):l1ll11l11l1l_l1_}
		l1111111111_l1_ = l1ll11l11l1l_l1_
	else: proxies,l1111111111_l1_ = {},l1l111_l1_ (u"ࠫࠬ㦅")
	if l1ll1lllllll_l1_:
		import urllib3.util.connection as connection
		l11l11l1111_l1_ = l1ll11111111_l1_(connection,l1l1lll1llll_l1_)
	verify = True
	l1ll11ll1ll1_l1_,l1ll1l1ll1ll_l1_,l1l11lll1_l1_,l11llll11l1_l1_,l11lll11111_l1_ = allow_redirects,source,method,False,False
	if l1lll111l111_l1_: l11lll11111_l1_ = True
	if l111llll1l1_l1_ or allow_redirects: l1ll11ll1ll1_l1_ = False
	if l1ll111l1lll_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㦆")
	import requests
	code,reason = -1,l1l111_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭㦇")
	for l1l11l111l_l1_ in range(9):
		l1llll1lllll_l1_ = True
		succeeded = False
		try:
			if l1l11l111l_l1_: l1ll1l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠶ࡹࡴࠨ㦈")
			if not l11lll111l1_l1_: l1l1ll1111l_l1_(l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭㦉"),l1lllll1_l1_,data,headers,l1ll1l1ll1ll_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1ll11ll1ll1_l1_,timeout=l1l111ll11l_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11llll11l1_l1_:
					l1111111l11_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㦊") in l1111111l11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㦋")]
					elif l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭㦌") in l1111111l11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㦍")]
					else: l11llll11l1_l1_ = True
					if not l11llll11l1_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧ㦎"),l1l111_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ㦏")).decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㦐"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ㦑"))
					if l111llll1l1_l1_ and response.status_code==307:
						l1ll11ll1ll1_l1_ = allow_redirects
						l1l11lll1_l1_ = method
						l11llll11l1_l1_ = True
						l1lll1l1111l_l1_
				if not l11llll11l1_l1_ or allow_redirects:
					if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㦒") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㦓"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠬ࠵ࠧ㦔")+l1lllll1_l1_
				if not l11llll11l1_l1_ and allow_redirects:
					l11ll1l11l_l1_ = l1l111ll1l_l1_(l1lllll1_l1_)
					if l11ll1l11l_l1_ not in [l1l111_l1_ (u"࠭࠮ࡢࡸ࡬ࠫ㦕"),l1l111_l1_ (u"ࠧ࠯ࡶࡶࠫ㦖"),l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭㦗"),l1l111_l1_ (u"ࠩ࠱ࡥࡦࡩࠧ㦘"),l1l111_l1_ (u"ࠪ࠲ࡲࡱࡶࠨ㦙"),l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠴ࠩ㦚"),l1l111_l1_ (u"ࠬ࠴ࡷࡦࡤࡰࠫ㦛")]: l1lll1l1111l_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11lll11111_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l1l111_l1_ (u"࠭࠺ࠡࠩ㦜"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠧ࠻ࠢࠪ㦝"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠨࡇࡵࡶࡳࡵࠧ㦞") in error: code,reason = re.findall(l1l111_l1_ (u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦ㦟"),error)[0]
				elif l1l111_l1_ (u"ࠪ࠰ࠥ࡫ࡲࡳࡱࡵࠬࠬ㦠") in error: code,reason = re.findall(l1l111_l1_ (u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢ㦡"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠬࡀࠧ㦢"))>=2: reason,code = re.findall(l1l111_l1_ (u"࠭࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪࠩ㦣"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1llll1lllll_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㦤"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㦥")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㦦")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㦧")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㦨")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㦩"))
		if l1llll1lllll_l1_ and l111llll1l1_l1_ and not l11lll11111_l1_ and code!=200:
			l1lllll1_l1_ = l1111ll1lll_l1_
			l11lll11111_l1_ = True
			continue
		if l1llll1lllll_l1_: break
	if l1lll111l1l1_l1_!=None and l1ll111ll11l_l1_!=l1l111_l1_ (u"࠭ࡓࡕࡑࡓࠫ㦪"): connection.create_connection = l11l11l1111_l1_
	if l1ll111ll11l_l1_==l1l111_l1_ (u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧ㦫") and l11ll1ll11l_l1_: l1lll111l1l1_l1_ = None
	if not succeeded and l1ll11l11l1l_l1_==None and source not in l1llllll1ll1_l1_:
		l1111llll11_l1_ = traceback.format_exc()
		sys.stderr.write(l1111llll11_l1_)
	l1lll1l11_l1_ = l1l1lllll1l_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠨࠩ㦬")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㦭"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = headers
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1lll1l11_l1_.content,str): l1ll111ll1l1_l1_ = l1lll1l11_l1_.content.lower()
	else: l1ll111ll1l1_l1_ = l1l111_l1_ (u"ࠪࠫ㦮")
	l1llll11ll11_l1_ = (l1l111_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㦯") in l1ll111ll1l1_l1_ or l1l111_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬ㦰") in l1ll111ll1l1_l1_) and l1ll111ll1l1_l1_.count(l1l111_l1_ (u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㦱"))>2 and l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㦲") not in source and l1l111_l1_ (u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪ㦳") not in l1ll111ll1l1_l1_
	if code==200 and l1llll11ll11_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1lll11111ll_l1_ and l111llll1l1_l1_:
		if l1lll111l111_l1_: l111l1ll111_l1_ = l1l111_l1_ (u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ㦴")+data[l1l111_l1_ (u"ࠪ࡮ࡴࡨࠧ㦵")].upper().replace(l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㦶"),l1l111_l1_ (u"ࠬ࠭㦷"))
		l1lll11ll_l1_ = l1ll1111111_l1_(l111l1ll111_l1_)
	if not l1lll1l11_l1_.succeeded and l1lll11111ll_l1_:
		l1llll11l1l1_l1_ = (l1l111_l1_ (u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪ㦸") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩ㦹") in l1ll111ll1l1_l1_)
		l1llll11l1ll_l1_ = (l1l111_l1_ (u"ࠨ࠷ࠣࡷࡪࡩࠧ㦺") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ㦻") in l1ll111ll1l1_l1_)
		l1llll11ll1l_l1_ = (code in [403] and l1l111_l1_ (u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭㦼") in l1ll111ll1l1_l1_)
		l1llll11lll1_l1_ = (l1l111_l1_ (u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭㦽") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩ㦾") in l1ll111ll1l1_l1_)
		if   l1llll11ll11_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭㦿")
		elif l1llll11l1l1_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㧀")
		elif l1llll11l1ll_l1_: reason = l1l111_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㧁")
		elif l1llll11ll1l_l1_: reason = l1l111_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪ㧂")
		elif l1llll11lll1_l1_: reason = l1l111_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㧃")
		else: reason = str(reason)
		if source in l1llllll1ll1_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㧄"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㧅")+str(code)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㧆")+reason+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧇")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧈")+l1lllll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㧉"))
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㧊"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㧋")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㧌")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧍")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧎")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㧏"))
		l1111l111ll_l1_ = l111l11_l1_(l1lllll1_l1_)
		if kodi_version<19 and isinstance(l1111l111ll_l1_,unicode): l1111l111ll_l1_ = l1111l111ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㧐"))
		if l111llll1l1_l1_: l1111l111ll_l1_ = l1111l111ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ㧑"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠫࡡࡴࠨࠡࠩ㧒")+l1111l111ll_l1_+l1l111_l1_ (u"ࠬࠦࠩࠨ㧓")
		if l1llll11ll11_l1_ or l1llll11l1l1_l1_ or l1llll11l1ll_l1_ or l1llll11ll1l_l1_ or l1llll11lll1_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
		l1llll1l11_l1_ = True
		if (l1ll111ll11l_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㧔") or l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧕")) and (l11ll1ll11l_l1_ or l1lll1111lll_l1_):
			l1llll1l11_l1_ = l1lllll11lll_l1_(code,reason,source,l11_l1_)
			if l1llll1l11_l1_ and l1ll111ll11l_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㧖"): l1ll111ll11l_l1_ = l1l111_l1_ (u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ㧗")
			else: l1ll111ll11l_l1_ = l1l111_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ㧘")
			if l1llll1l11_l1_ and l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㧙"): l1ll11l1lll1_l1_ = l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㧚")
			else: l1ll11l1lll1_l1_ = l1l111_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㧛")
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㧜"),l1ll111ll11l_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ㧝"),l1ll11l1lll1_l1_)
		if l1llll1l11_l1_:
			l1l1llll1l1l_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ㧞") in l1lllll1_l1_ and l1l1llll1l1l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪ㧟"),l1l111_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㧠"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠬࢂࡼࡎࡻࡖࡗࡑ࡛ࡲ࡭࠿ࠪ㧡")
				l1lll11ll_l1_ = l1111llllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧢"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧣")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧤")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㧥"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧ㧦"),l1l111_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㧧"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㧨"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧩")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧪")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㧫"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬ㧬"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧭"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll11l1lll1_l1_ in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㧮"),l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㧯")] and l1lll1111lll_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭㧰"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧱"),time=2000)
				l1lll11ll_l1_ = l11ll1ll1ll_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㧲"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧳")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧴")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧵"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ์ฬศฯࠣื๏ืแาษอࠤอื่ไีํࠫ㧶"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧷"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㧸"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧹")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧺")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧻"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆฺไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ㧼"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧽"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll111ll11l_l1_ in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㧾"),l1l111_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㧿")] and l11ll1ll11l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨฬไ฽๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠪ㨀"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㨁"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠪࢀࢁࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨ㨂")
				l1lll11ll_l1_ = l1111llllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㨃"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬ㨄")+l1l1lll1llll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㨅")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㨆")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㨇"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"้ࠩะฬำࠠิ์ิๅึࠦࡄࡏࡕࠪ㨈"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㨉"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㨊"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩ㨋")+l1l1lll1llll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㨌")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㨍")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㨎"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦำ๋ำไีࠥࡊࡎࡔࠩ㨏"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㨐"),time=2000)
		if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭㨑") or l1ll111ll11l_l1_==l1l111_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㨒"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11llll1l11_l1_ = l1lllll11lll_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1ll111l_l1_ and l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪ㨓") not in source:
				l11111l11l1_l1_(l1l111_l1_ (u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡴࡥࡵࡹࡲࡶࡰࠦࡩࡴࡵࡸࡩࡸࠦࡷࡪࡶ࡫࠾ࠥ࠭㨔")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㨕")) not in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㨖"),l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㨗"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㨘")]: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㨙"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㨚"))
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㨛")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㨜"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㨝"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㨞")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㨟"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㨠"))
	return l1lll1l11_l1_
def l11l1l_l1_(l1l1l1llll1_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	item = method,url,data,headers,allow_redirects,l11_l1_
	if l1l1l1llll1_l1_:
		response = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ㨡"),l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ㨢"),item)
		if response.succeeded:
			l1l1ll1111l_l1_(l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨ㨣"),url,data,headers,source,method)
			return response
	response = l1111llllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_,l1lll1111lll_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㨤") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l1l1l1llll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㨥"),item,response,l1l1l1llll1_l1_)
	return response
def l1l1llll_l1_(l1l1l1llll1_l1_,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㨦")
	else:
		method = l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㨧")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(l1l1l1llll1_l1_,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1111l1l1_l1_(url):
	l1ll11l1ll11_l1_ = url.split(l1l111_l1_ (u"࠭ࡼࡽࠩ㨨"))
	l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_ = l1ll11l1ll11_l1_[0],None,None,None
	for item in l1ll11l1ll11_l1_:
		if l1l111_l1_ (u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ㨩") in item: l1ll11l11l1l_l1_ = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ㨪"))[1]
		elif l1l111_l1_ (u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ㨫") in item: l1lll111l1l1_l1_ = item.split(l1l111_l1_ (u"ࠪࡁࠬ㨬"))[1]
		elif l1l111_l1_ (u"ࠫࡒࡿࡓࡔࡎࡘࡶࡱࡃࠧ㨭") in item: l1ll1lll1111_l1_ = item.split(l1l111_l1_ (u"ࠬࡃࠧ㨮"))[1]
	return l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_
def l11lll1llll_l1_(name):
	start,l1lll11l1ll_l1_,modified = l1l111_l1_ (u"࠭ࠧ㨯"),l1l111_l1_ (u"ࠧࠨ㨰"),l1l111_l1_ (u"ࠨࠩ㨱")
	name = name.replace(ltr,l1l111_l1_ (u"ࠩࠪ㨲")).replace(rtl,l1l111_l1_ (u"ࠪࠫ㨳"))
	tmp = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫ㨴"),name,re.DOTALL)
	if tmp: start,l1lll11l1ll_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠬࠦࠧ㨵"),l1l111_l1_ (u"࠭ࠬࠨ㨶"),l1l111_l1_ (u"ࠧࠨ㨷")]: modified = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㨸")
	if l1lll11l1ll_l1_: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡢࠫ㨹")+l1lll11l1ll_l1_+l1l111_l1_ (u"ࠪࡣࠬ㨺")
	name = l1lll11l1ll_l1_+modified+name
	return name
def l1lllll11ll_l1_(url,l1ll1ll1l1ll_l1_,l1ll1llll1l1_l1_,l1llllll1l1l_l1_,headers={}):
	l1l1ll1lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㨻"))
	l11l1l11ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㨼")+l1ll1ll1l1ll_l1_)
	if l1l1ll1lll1l_l1_==l11l1l11ll1_l1_: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ㨽")+l1ll1ll1l1ll_l1_,l1l111_l1_ (u"ࠧࠨ㨾"))
	if l11l1l11ll1_l1_: l1llllll_l1_ = url.replace(l1l1ll1lll1l_l1_,l11l1l11ll1_l1_)
	else:
		l1llllll_l1_ = url
		l11l1l11ll1_l1_ = l1l1ll1lll1l_l1_
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㨿"),l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㩀"),headers,l1l111_l1_ (u"ࠪࠫ㩁"),l1l111_l1_ (u"ࠫࠬ㩂"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㩃"))
	html = l1lll11ll_l1_.content
	try: html = html.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㩄"),l1l111_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ㩅"))
	except: pass
	if not l1lll11ll_l1_.succeeded or l1llllll1l1l_l1_ not in html:
		l1ll1llll1l1_l1_ = l1ll1llll1l1_l1_.replace(l1l111_l1_ (u"ࠨࠢࠪ㩆"),l1l111_l1_ (u"ࠩ࠮ࠫ㩇"))
		l1lllll1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ㩈")+l1ll1llll1l1_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㩉"):l1l111_l1_ (u"ࠬ࠭㩊")}
		l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㩋"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㩌"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ㩍"),l1l111_l1_ (u"ࠩࠪ㩎"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧ㩏"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㩐"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㩑"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱࡟ࡻ࠯ࡢ࠿࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ㩒"),html,re.DOTALL)
			l1111ll1111_l1_ = [l11l1l11ll1_l1_]
			l111l11ll11_l1_ = [l1l111_l1_ (u"ࠧࡢࡲ࡮ࠫ㩓"),l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㩔"),l1l111_l1_ (u"ࠩࡷࡻ࡮ࡺࡴࡦࡴࠪ㩕"),l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ㩖"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭㩗")]
			for l1ll1ll_l1_ in l1ll_l1_:
				l11l1l11ll1_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㩘"))
				if any(value in l1ll1ll_l1_ for value in l111l11ll11_l1_): continue
				if l11l1l11ll1_l1_ in l1111ll1111_l1_: continue
				if len(l1111ll1111_l1_)==9:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㩙"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭㩚")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭㩛")+l1l1ll1lll1l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㩜"))
					settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ㩝")+l1ll1ll1l1ll_l1_,l1l111_l1_ (u"ࠫࠬ㩞"))
					break
				l1111ll1111_l1_.append(l11l1l11ll1_l1_)
				l1llllll_l1_ = url.replace(l1l1ll1lll1l_l1_,l11l1l11ll1_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㩟"),l1llllll_l1_,l1l111_l1_ (u"࠭ࠧ㩠"),headers,l1l111_l1_ (u"ࠧࠨ㩡"),l1l111_l1_ (u"ࠨࠩ㩢"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭㩣"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l1llllll1l1l_l1_ in html:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㩤"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㩥")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫ㩦")+l11l1l11ll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫ㩧")+l1l1ll1lll1l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㩨"))
					settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ㩩")+l1ll1ll1l1ll_l1_,l11l1l11ll1_l1_)
					break
	return l11l1l11ll1_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠩࡲࡰࡩ࠭㩪")			:l1l111_l1_ (u"ࠪๆิ๐ๅࠨ㩫")
	,l1l111_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭㩬")		:l1l111_l1_ (u"๋ࠬส้ไไࠫ㩭")
	,l1l111_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ㩮")		:l1l111_l1_ (u"ࠧๆใๅ์ิ࠭㩯")
	,l1l111_l1_ (u"ࠨࡩࡲࡳࡩ࠭㩰")			:l1l111_l1_ (u"ࠩฯ๎ิ࠭㩱")
	,l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㩲")		:l1l111_l1_ (u"ࠫๆฺไࠨ㩳")
	,l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩴")		:l1l111_l1_ (u"࠭ๅอๆาࠫ㩵")
	,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㩶")		:l1l111_l1_ (u"ࠨใํำ๏๎ࠧ㩷")
	,l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㩸")			:l1l111_l1_ (u"ࠪๆ๋อษࠨ㩹")
	,l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࠪ㩺")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩ㩻")
	,l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࠬ㩼")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫ㩽")
	,l1l111_l1_ (u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪ㩾")		:l1l111_l1_ (u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪ㩿")
	,l1l111_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ㪀")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫ㪁")
	,l1l111_l1_ (u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧ㪂")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ㪃")
	,l1l111_l1_ (u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪ㪄")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫ㪅")
	,l1l111_l1_ (u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫ㪆")		:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧ㪇")
	,l1l111_l1_ (u"ࠫࡦࡸࡢ࡭࡫ࡲࡲࡿ࠭㪈")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ฽ึฮࠠๅ์๋๊ื࠭㪉")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪ㪊")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬ㪋")
	,l1l111_l1_ (u"ࠨࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣࠪ㪌")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศๆึ๎๋๋วࠨ㪍")
	,l1l111_l1_ (u"ࠪ࡬ࡪࡲࡡ࡭ࠩ㪎")		:l1l111_l1_ (u"๊ࠫ๎โฺ๊่ࠢฬ๊๋๊ࠠอ๎ํฮࠧ㪏")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡩࡥࡳࡹࠧ㪐")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧ㪑")
	,l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㪒")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ㪓")
	,l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦ࡮ࡣࡻࠫ㪔")		:l1l111_l1_ (u"้ࠪํู่ࠡึ๋ๅ๋ࠥวไีࠪ㪕")
	,l1l111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭㪖")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬ㪗")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ㪘")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧ㪙")
	,l1l111_l1_ (u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫ㪚")	:l1l111_l1_ (u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬ㪛")
	,l1l111_l1_ (u"ࠪࡽࡹࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ㪜")	:l1l111_l1_ (u"๊ࠫ๎วใ฻ࠣ๎ํะ๊้สࠪ㪝")
	,l1l111_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ㪞")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭㪟")
	,l1l111_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ㪠")		:l1l111_l1_ (u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧ㪡")
	,l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ㪢")		:l1l111_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬ㪣")
	,l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠭㪤")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨ㪥")
	,l1l111_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ㪦")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮใาษࠪ㪧")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ㪨")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪ㪩")
	,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࡵࡸࠪ㪪")		:l1l111_l1_ (u"๊๊ࠫแࠨ㪫")
	,l1l111_l1_ (u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭㪬")		:l1l111_l1_ (u"࠭ๅๅใࠪ㪭")
	,l1l111_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ㪮")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪ㪯")
	,l1l111_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࡴࡪࡲࡻࠬ㪰")	:l1l111_l1_ (u"้ࠪํู่ࠡใฯีฺ่ࠥࠨ㪱")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ㪲")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭㪳")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨ㪴")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ㪵")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪ㪶")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬ㪷")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ㪸")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧ㪹")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧ㪺")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩ㪻")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ㪼")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪ㪽")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ㪾")		:l1l111_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦๆศ๊ࠪ㪿")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡥࡧࡤࡨࠬ㫀")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊ࠡัํำࠬ㫁")
	,l1l111_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ㫂")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ㫃")
	,l1l111_l1_ (u"ࠨ࡮ࡲࡨࡾࡴࡥࡵࠩ㫄")		:l1l111_l1_ (u"่ࠩ์็฿ࠠๅ๊า๎ࠥ์สࠨ㫅")
	,l1l111_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ㫆")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ㫇")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨ㫈")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧ㫉")
	,l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫ㫊")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩ㫋")
	,l1l111_l1_ (u"ࠩࡩࡳࡸࡺࡡࠨ㫌")		:l1l111_l1_ (u"้ࠪํู่ࠡใ๋ืฯอࠧ㫍")
	,l1l111_l1_ (u"ࠫࡦ࡮ࡷࡢ࡭ࠪ㫎")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧ㫏")
	,l1l111_l1_ (u"࠭ࡦࡢࡤࡵࡥࡰࡧࠧ㫐")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ็ศาๅฬࠫ㫑")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࡺࡳࡷࡱࠧ㫒")	:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠣ฽๊๊ࠧ㫓")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬ㫔")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㫕")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡨ࡫ࡥࠬ㫖")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨ㫗")
	,l1l111_l1_ (u"ࠧࡣࡴࡶࡸࡪࡰࠧ㫘")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭㫙")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪ㫚")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪ㫛")
	,l1l111_l1_ (u"ࠫࡱࡧࡲࡰࡼࡤࠫ㫜")		:l1l111_l1_ (u"๋่ࠬใ฻่ࠣฬื่ำษࠪ㫝")
	,l1l111_l1_ (u"࠭ࡹࡢࡳࡲࡸࠬ㫞")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ㫟")
	,l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ㫠")		:l1l111_l1_ (u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭㫡")
	,l1l111_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬ㫢")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭㫣")
	,l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪ㫤")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨ㫥")
	,l1l111_l1_ (u"ࠧࡥࡴࡤࡱࡦࡹ࠷ࠨ㫦")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨ㫧")
	,l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ㫨")		:l1l111_l1_ (u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩ㫩")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯ࠪ㫪")				:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩ㫫")
	,l1l111_l1_ (u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬ㫬")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩ㫭")
	,l1l111_l1_ (u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨ㫮")		:l1l111_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧ㫯")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵࠩ㫰")				:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠨ㫱")
	,l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ㫲")			:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩ㫳")
	,l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭㫴")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭㫵")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㫶")				:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨ㫷")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬ㫸")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ㫹")
	,l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ㫺")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫ㫻")
	,l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㫼")		:l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭㫽")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠭㫾")			:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭㫿")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡲࡨࡶࡸࡵ࡮ࡴࠩ㬀")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡไสีห࠭㬁")
	,l1l111_l1_ (u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪ㬂")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩ㬃")
	,l1l111_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬ㬄")		:l1l111_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬ㬅")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㬆")			:l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭㬇")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡻ࡯ࡤࡦࡱࡶࠫ㬈")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪ㬉")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ㬊"):l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ㬋")
	,l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㬌")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่ࠥๆ้ษอࠫ㬍")
	,l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡸࡴࡶࡩࡤࡵࠪ㬎")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠๆ๊สฺ๏฿ࠧ㬏")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ㬐")					:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㬑")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬ㬒")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧ㬓")
	,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㬔")			:l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩ㬕")
	,l1l111_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㬖")			:l1l111_l1_ (u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭㬗")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ㬘")					:l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㬙")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬ㬚")				:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧ㬛")
	,l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㬜")			:l1l111_l1_ (u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩ㬝")
	,l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㬞")			:l1l111_l1_ (u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭㬟")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠩࠪ㬠")
	return result
def l11111l11l1_l1_(message=l1l111_l1_ (u"ࠪࠫ㬡")):
	l1ll1lllll11_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠫ࠿࠵ࠧ㬢")):
	return _1llll1ll1ll_l1_(urll,exceptions)
def l11l111l11l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠬ࠭㬣"),l1l111_l1_ (u"࠭࠰ࠨ㬤"),0]: return l1l111_l1_ (u"ࠧࠨ㬥")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1ll11l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll11l11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll11l1_l1_)+str(l111ll11l11_l1_)+str(l111l111_l1_)
	return result
def l1ll11l1l11l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㬦"),l1l111_l1_ (u"ࠩ࠳ࠫ㬧"),0]: return l1l111_l1_ (u"ࠪࠫ㬨")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠫࠬ㬩")
	if len(l1l1llll1_l1_)==15:
		l11l1ll11l1_l1_,l111ll11l11_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1ll11l1_l1_ = int(l11l1ll11l1_l1_)^l111l11l_l1_
		l111ll11l11_l1_ = int(l111ll11l11_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1ll11l1_l1_==l111ll11l11_l1_==l111l111_l1_: result = str(l11l1ll11l1_l1_*60)
	return result
def l1lll1111111_l1_(l1l1llll1_l1_,l1lll11l111l_l1_=l1l111_l1_ (u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ㬪")):
	if l1l1llll1_l1_==l1l111_l1_ (u"࠭ࠧ㬫"): return l1l111_l1_ (u"ࠧࠨ㬬")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll11l111l_l1_)
	l11l1ll11l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll11l11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll11l1_l1_)+str(l111ll11l11_l1_)+str(l111l111_l1_)
	return result
def l111111llll_l1_(l1l1llll1_l1_,l1lll11l111l_l1_=l1l111_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ㬭")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠩࠪ㬮"): return l1l111_l1_ (u"ࠪࠫ㬯")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l1l1lll_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1ll11l1_l1_ = int(l1l1llll1_l1_[0:l1l1l1l1lll_l1_])^l1ll1ll1_l1_
	l111ll11l11_l1_ = int(l1l1llll1_l1_[l1l1l1l1lll_l1_:2*l1l1l1l1lll_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l1l1lll_l1_:3*l1l1l1l1lll_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠫࠬ㬰")
	if l11l1ll11l1_l1_==l111ll11l11_l1_==l111l111_l1_: result = str(int(l11l1ll11l1_l1_)-int(l1lll11l111l_l1_))
	return result
def l1l1ll1l111_l1_(l1l11ll1ll1_l1_):
	l1llll1l11l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬱")][8]
	l1111lll111_l1_ = l1l1ll1l11l_l1_(32)
	l1ll1ll11l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ㬲"),l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲࡸ࠭㬳"),l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㬴"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㬵"),l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㬶"))
	l11ll11llll_l1_,l111lllll1l_l1_ = l1ll1l1ll1_l1_(l1ll1ll11l1l_l1_)
	l11ll11llll_l1_ = l1lll1111111_l1_(l11ll11llll_l1_,l1l111_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ㬷"))
	l111l1lllll_l1_ = {l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㬸"):l1l111_l1_ (u"࠭ࡄࡊࡃࡏࡓࡌ࠭㬹"),l1l111_l1_ (u"ࠧࡶࡵࡵࠫ㬺"):l1111lll111_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࠬ㬻"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠩࡶࡧࡷ࠭㬼"):l1l11ll1ll1_l1_,l1l111_l1_ (u"ࠪࡷ࡮ࢀࠧ㬽"):l11ll11llll_l1_}
	l1lll11ll1ll_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㬾"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㬿")}
	l1llll1ll11l_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㭀"),l1llll1l11l1_l1_,l111l1lllll_l1_,l1lll11ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ㭁"),l1l111_l1_ (u"ࠨࠩ㭂"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪ㭃"))
	l1l1llll1lll_l1_ = l1llll1ll11l_l1_.content
	try:
		if not l1l1llll1lll_l1_: l1ll111lll1l_l1_
		l1lll11ll111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㭄"),l1l1llll1lll_l1_)
		l1l1llll11l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"ࠫࡲࡹࡧࠨ㭅")]
		l1ll11l111l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"ࠬࡹࡥࡤࠩ㭆")]
		l1lll1ll11l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"࠭ࡳࡵࡲࠪ㭇")]
		l1ll11l111l1_l1_ = int(l111111llll_l1_(l1ll11l111l1_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㭈")))
		l1lll1ll11l1_l1_ = int(l111111llll_l1_(l1lll1ll11l1_l1_,l1l111_l1_ (u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ㭉")))
		for l111l111l11_l1_ in range(l1ll11l111l1_l1_,0,-l1lll1ll11l1_l1_):
			if not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㭊")): l1ll111lll1l_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩ㭋"),str(l111l111l11_l1_)+l1l111_l1_ (u"ࠫࠥࠦหศ่ํอࠬ㭌"),time=500)
			xbmc.sleep(l1lll1ll11l1_l1_*1000)
		if eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㭍")):
			l111ll11111_l1_ = l1l111_l1_ (u"ࠨࡄࡊࡃࡏࡓࡌ࡭࡟ࡐࡍࠫࠫࠬ࠲ࠧฯำ๋ะࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬࠨ㭎")+l1l1llll11l1_l1_+l1l111_l1_ (u"ࠢࠨࠫࠥ㭏")
			l111ll11111_l1_ = l111ll11111_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㭐"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㭑")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㭒"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㭓"))
			exec(l111ll11111_l1_)
		l1ll111lll1l_l1_
	except: exec(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ㭔"))
	return
def l1l111lll1l_l1_():
	exec(l1l111_l1_ (u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫ㭕"))
	return
def l1ll1l1ll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1lllll11l_l1_(l1lllll1llll_l1_,l1ll1l111l1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠧࠨ㭖"),l1l111_l1_ (u"ࠨࠩ㭗"),l1l111_l1_ (u"ࠩࠪ㭘"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭙"),l1lllll1llll_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㭚")+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㭛"))
		if l1llll1l11_l1_!=1: return
	error = False
	if os.path.exists(l1lllll1llll_l1_):
		for root,dirs,l1l1111111_l1_ in os.walk(l1lllll1llll_l1_,topdown=False):
			for file in l1l1111111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㭜"),l1l111_l1_ (u"ࠧࠨ㭝"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㭞"),str(err))
					error = True
			if l1ll1l111l1l_l1_:
				for dir in dirs:
					l1l1ll1ll11l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l1ll1ll11l_l1_)
					except: pass
		if l1ll1l111l1l_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㭟"),l1l111_l1_ (u"ࠪࠫ㭠"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㭡"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭㭢"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭣"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ㭤"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㭥"))
	return
def l1ll1lllll11_l1_(l1111llll11_l1_=l1l111_l1_ (u"ࠩࠪ㭦")):
	if l1111llll11_l1_:
		l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㭧"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㭨"),l1l111_l1_ (u"ࠬ࠭㭩"))
		l11l1l1111l_l1_(l1111llll11_l1_)
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㭪"),l1111111lll_l1_)
	l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㭫"))
	if l1ll11ll1l_l1_==l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ㭬"): settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㭭"),l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㭮"))
	elif l1ll11ll1l_l1_==l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㭯"): settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㭰"),l1l111_l1_ (u"࠭ࠧ㭱"))
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㭲")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㭳"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㭴"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㭵")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㭶"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㭷"))
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㭸")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㭹"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㭺"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㭻")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㭼"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㭽"))
	l11llllll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㭾"))
	l11l11l1l1l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ㭿"))
	if l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭㮀") in str(l11l11l1l1l_l1_) and l11llllll1l_l1_ in [l1l111_l1_ (u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫ㮁"),l1l111_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ㮂")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧ㮃"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
	return
def l1llll1llll_l1_(l1l1l1llll1_l1_,method,url,data,headers,source):
	if l1l1l1llll1_l1_:
		html = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡸࡺࡲࠨ㮄"),l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭㮅"),(method,url,data,headers))
		if html:
			l1l1ll1111l_l1_(l1l111_l1_ (u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫ㮆"),url,data,headers,source,method)
			return html
	html = l1l111llll1_l1_(method,url,data,headers,source)
	if html and l1l1l1llll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ㮇"),(method,url,data,headers),html,l1l1l1llll1_l1_)
	return html
DIALOGg_OK = l1111l1_l1_
l1l11111lll_l1_ = l11ll1ll1l1_l1_
l11llll1l1l_l1_ = l1ll1llll111_l1_
DIALOGg_YESNO = l1ll1l1111_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l11l1111_l1_
DIALOGg_TEXTVIEWER = l1ll11l11l11_l1_
DIALOGg_CONTEXTMENU = l11ll11l1ll_l1_
l111l11l1ll_l1_ = l1l11111l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1l1lll11lll_l1_
l1ll1ll1111l_l1_ = l1l11ll111_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l1111l11_l1_
DOWNLOADd_USING_PROGRESSBAR = l1llll11llll_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l1l11l111_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11ll11_l1_
PERMANENT_CACHEe = l1ll111l1l1_l1_
from EXCLUDES import *
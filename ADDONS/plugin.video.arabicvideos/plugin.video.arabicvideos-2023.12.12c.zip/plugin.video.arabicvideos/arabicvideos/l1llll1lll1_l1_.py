# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ⢸")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨ⢹")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้ะี็์ไหฯ࠭⢺"),l1l111_l1_ (u"ࠫฬ์ิศรࠣัุอศࠨ⢻"),l1l111_l1_ (u"ࠬ฽ไษษอࠤฬ๊า้๓สีࠬ⢼")]
def l11l1ll_l1_(mode,url,text):
	if   mode==390: l1lll_l1_ = l1l1l11_l1_()
	elif mode==391: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==392: l1lll_l1_ = PLAY(url)
	elif mode==393: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==399: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢽"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⢾"),l1l111_l1_ (u"ࠨࠩ⢿"),399,l1l111_l1_ (u"ࠩࠪ⣀"),l1l111_l1_ (u"ࠪࠫ⣁"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⣂"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⣃"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⣄"),l1l111_l1_ (u"ࠧࠨ⣅"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⣆"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ⣇"),l1l111_l1_ (u"ࠪࠫ⣈"),l1l111_l1_ (u"ࠫࠬ⣉"),l1l111_l1_ (u"ࠬ࠭⣊"),l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⣋"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⣌"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣍"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⣎")+l1lllll_l1_+title,l111l1_l1_,391,l1l111_l1_ (u"ࠪࠫ⣏"),l1l111_l1_ (u"ࠫࠬ⣐"),l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ⣑")+str(seq))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣒"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⣓")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ัฮฬืวหࠢ฼ุํอฦ๋หࠪ⣔"),l111l1_l1_,391,l1l111_l1_ (u"ࠩࠪ⣕"),l1l111_l1_ (u"ࠪࠫ⣖"),l1l111_l1_ (u"ࠫࡷࡧ࡮ࡥࡱࡰࡷࠬ⣗"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣘"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⣙")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤ฻็ํࠥอไฤใ็ห๊ࠦสใ์ํ้ฬ๑ࠧ⣚"),l111l1_l1_,391,l1l111_l1_ (u"ࠨࠩ⣛"),l1l111_l1_ (u"ࠩࠪ⣜"),l1l111_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⣝"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣞"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⣟")+l1lllll_l1_+l1l111_l1_ (u"࠭รฺๆ์ࠤฬ๊ๅิๆึ่ฬะࠠหไํ๎๊อ๋ࠨ⣠"),l111l1_l1_,391,l1l111_l1_ (u"ࠧࠨ⣡"),l1l111_l1_ (u"ࠨࠩ⣢"),l1l111_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫ⣣"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣤"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⣥")+l1lllll_l1_+l1l111_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪ⣦"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ⣧"),391,l1l111_l1_ (u"ࠧࠨ⣨"),l1l111_l1_ (u"ࠨࠩ⣩"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ⣪"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣫"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⣬")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬ⣭"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳࠨ⣮"),391,l1l111_l1_ (u"ࠧࠨ⣯"),l1l111_l1_ (u"ࠨࠩ⣰"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬ⣱"))
	block = l1l111_l1_ (u"ࠪࠫ⣲")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡩࡩࡵࡲࠣࠩ⣳"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⣴"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ⣵"),l1l111_l1_ (u"ࠧࠨ⣶"),l1l111_l1_ (u"ࠨࠩ⣷"),l1l111_l1_ (u"ࠩࠪ⣸"),l1l111_l1_ (u"ࠪࠫ⣹"),l1l111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ⣺"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡭ࡧࡤࡷࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫ⣻"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⣼"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⣽"),l1l111_l1_ (u"ࠨࠩ⣾"),9999)
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⣿"),block,re.DOTALL)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠪห้ษูๅู๋้ࠣอ็ะหࠪ⤀"):
			if first:
				title = l1l111_l1_ (u"ࠫฬ๊วโๆส้ࠥ࠭⤁")+title
				first = False
			else: title = l1l111_l1_ (u"ࠬอไๆี็ื้อสࠡࠩ⤂")+title
		if title not in l11lll_l1_:
			if title==l1l111_l1_ (u"࠭รโๆส้ࠬ⤃"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤄"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⤅")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ⤆"),391,l1l111_l1_ (u"ࠪࠫ⤇"),l1l111_l1_ (u"ࠫࠬ⤈"),l1l111_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⤉"))
			elif title==l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠧ⤊"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤋"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⤌")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶࠫ⤍"),391,l1l111_l1_ (u"ࠪࠫ⤎"),l1l111_l1_ (u"ࠫࠬ⤏"),l1l111_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⤐"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤑"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⤒")+l1lllll_l1_+title,l1ll1ll_l1_,391)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⤓"),url,l1l111_l1_ (u"ࠩࠪ⤔"),l1l111_l1_ (u"ࠪࠫ⤕"),l1l111_l1_ (u"ࠫࠬ⤖"),l1l111_l1_ (u"ࠬ࠭⤗"),l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⤘"))
	html = response.content
	if type in [l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⤙"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⤚")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ⤛"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⤜"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡣࡵࡧ࡭࡯ࡶࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭⤝"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⤞"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴ࡭ࡧࡩࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠩࡷࡳࡵ࠳ࡩ࡮ࡦࡥ࠱ࡱ࡯ࡳࡵࠢࡷࡶ࡮࡭ࡨࡵࠤ⤟"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠢࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥ⤠"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡷࡪࡸࡩࡦࡵࠪ⤡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡷࡳࡵ࠳ࡩ࡮ࡦࡥ࠱ࡱ࡯ࡳࡵࠢࡷࡶ࡮࡭ࡨࡵࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷࠨ⤢"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠥ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨ⤣"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ⤤"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡢࡴࡦ࡬࠲ࡶࡡࡨࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ⤥"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⤦"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭⤧"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸࠬ⤨"),html,re.DOTALL)
		block = l11llll_l1_[0]
		l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⤩"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*l1lll1l_l1_)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠪࡶࡦࡴࡤࡰ࡯ࡶࠫ⤪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡶࡹࡷ࡭ࡵࡷࡴࠤࠫ࠲࠯ࡅࠩ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ⤫"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⤬"),block,re.DOTALL)
	elif l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭⤭") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ⤮"),l1l111_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡴࡶࡤࡶࡹࡄࠧ⤯"))
		html = html.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ⤰"),l1l111_l1_ (u"ࠪࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽ࡧࡱࡨࡃ࠭⤱"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡴࡢࡴࡷࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡳࡪ࠾ࠨ⤲"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==6:
			l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⤳"),block,re.DOTALL)
			l1l1ll1ll_l1_,l1l1lll1_l1_,l1llll_l1_ = zip(*l1lll1l_l1_)
			items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡿࡷ࡮ࡪࡥࡣࡣࡵ࠭ࠬ⤴"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭⤵") in url:
				items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⤶"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠩ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳ࠬ⤷") in url:
				items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⤸"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⤹"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠪ⤺") in title: continue
		if l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࠬ⤻") in title:
			title = re.findall(l1l111_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡪࡸࡩࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⤼"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⤽")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾ࠪ⤾"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭⤿") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⥀"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⥁") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⥂"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ⥃") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⥄"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ⥅") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⥆"),l1lllll_l1_+title,l1ll1ll_l1_,391,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⥇"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	if type not in [l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⥈"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ⥉")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⥊"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⥋"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥌"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ⥍")+title,l1ll1ll_l1_,391,l1l111_l1_ (u"ࠫࠬ⥎"),l1l111_l1_ (u"ࠬ࠭⥏"),type)
	return
def l1ll1l11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ⥐"))
	url = url.replace(server,l111l1_l1_)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⥑"),url,l1l111_l1_ (u"ࠨࠩ⥒"),l1l111_l1_ (u"ࠩࠪ⥓"),l1l111_l1_ (u"ࠪࠫ⥔"),l1l111_l1_ (u"ࠫࠬ⥕"),l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⥖"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⥗"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ⥘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⥙"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⥚"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1llll1llll_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⥛"),url,l1l111_l1_ (u"ࠫࠬ⥜"),l1l111_l1_ (u"ࠬ࠭⥝"),l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⥞"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⥟"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࠨࡼ࡝ࠩࡠࠬࡸ࡮ࡥࡢࡦࡨࡶࢁࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠭ࡠࠨࡼ࡝ࠩࡠࠫ⥠"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡵࡵࡳࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡸࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡹ࡭ࡩࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⥡"),block,re.DOTALL)
		for type,l1ll11l_l1_,l1lllll1111_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡥࡱࡲࡣࡵࡲࡡࡺࡧࡵࡣࡦࡰࡡࡹࠨࡳࡳࡸࡺ࠽ࠨ⥢")+l1ll11l_l1_+l1l111_l1_ (u"ࠫࠫࡴࡵ࡮ࡧࡀࠫ⥣")+l1lllll1111_l1_+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ⥤")+type
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⥥")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⥦")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪ࡭ࡩࡃ࡛ࠣࠩࡠࡨࡴࡽ࡮࡭ࡱࡤࡨࡠࠨࠧ࡞ࠢࡦࡰࡦࡹࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࠨࠧ࡞ࡵࡥࡳࡽࡡࠢࠨ࡟ࠪࠫࠬ⥧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠪࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡ࠳࠰࠿ࡩࡴࡨࡪࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡ࠳࠰࠿࡜ࠤࠪࡡࡶࡻࡡ࡭࡫ࡷࡽࡠࠨࠧ࡞ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ⥨"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l111l1ll_l1_,l1lllll111l_l1_ in items:
			if l1l111_l1_ (u"ࠪࡁࠬ⥩") in l1ll1l_l1_:
				host = l1ll1l_l1_.split(l1l111_l1_ (u"ࠫࡂ࠭⥪"))[1]
				title = l1l111l_l1_(host,l1l111_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ⥫"))
			else: title = l1l111_l1_ (u"࠭ࠧ⥬")
			title = l1lllll111l_l1_+l1l111_l1_ (u"ࠧࠡࠩ⥭")+title
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⥮")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟ࡠࡡࠪ⥯")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⥰"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ⥱"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭⥲"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ⥳"),l1l111_l1_ (u"ࠧࠬࠩ⥴"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⥵")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ⥶"))
	return
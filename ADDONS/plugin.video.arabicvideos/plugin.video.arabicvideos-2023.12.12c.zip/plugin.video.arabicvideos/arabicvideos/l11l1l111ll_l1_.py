# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ坫")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ坬")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭坭"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1111l11l_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坮"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ坯"),l1l111_l1_ (u"ࠬ࠭坰"),319,l1l111_l1_ (u"࠭ࠧ坱"),l1l111_l1_ (u"ࠧࠨ坲"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ坳"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭坴"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ坵"),l1l111_l1_ (u"ࠫࠬ坶"),l1l111_l1_ (u"ࠬ࠭坷"),l1l111_l1_ (u"࠭ࠧ坸"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ坹"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷ࡯࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ坺"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ坻"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ坼"),l1l111_l1_ (u"ࠫࠬ坽"),9999)
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠶ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠹ࡃ࠭坾"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"࠭ࠠࠨ坿"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垀"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ垁")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠩࠪ垂"),l1l111_l1_ (u"ࠪࠫ垃"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垄"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ垅")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅใษฺ฽ฺࠥ็าࠩ垆"),l111l1_l1_,314,l1l111_l1_ (u"ࠧࠨ垇"),l1l111_l1_ (u"ࠨࠩ垈"),l1l111_l1_ (u"ࠩ࠳ࠫ垉"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ垊"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ型"),l1l111_l1_ (u"ࠬ࠭垌"),9999)
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡄࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡆࡃ࠭垍"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垎")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ垐")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垑"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ垒"),l1l111_l1_ (u"ࠬ࠭垓"),l1l111_l1_ (u"࠭ࠧ垔"),l1l111_l1_ (u"ࠧࠨ垕"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ垖"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠩ࠳ࠫ垗"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ垘"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垙"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垚")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垛"))
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垜"))
			title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垝")+name+l1l111_l1_ (u"ࠩࠬࠫ垞")
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ垟"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠫ࠶࠭垠"),l1l111_l1_ (u"ࠬ࠸ࠧ垡"),l1l111_l1_ (u"࠭࠳ࠨ垢")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡱ࡭ࠧ垣"),html,re.DOTALL)
		l11l1111l1l1_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1111l1l1_l1_]
		if seq==l1l111_l1_ (u"ࠨ࠳ࠪ垤"): items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垥"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垦"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垧")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垨")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垩"))
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垪"))
			title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垫")+name+l1l111_l1_ (u"ࠩࠬࠫ垬")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垭"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠫ࠹࠭垮"),l1l111_l1_ (u"ࠬ࠻ࠧ垯"),l1l111_l1_ (u"࠭࠶ࠨ垰")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ垱"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃ࠲ࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垲"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11l11_l1_,title,l1lllllllll_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ垳")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ垴")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭垵"))
			l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ垶"))
			l1lllllllll_l1_ = l1lllllllll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ垷"))
			if l1ll1l11l11_l1_: name = l1ll1l11l11_l1_
			else: name = l1lllllllll_l1_
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垸")+name+l1l111_l1_ (u"ࠨࠫࠪ垹")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垺"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垻"),url,l1l111_l1_ (u"ࠫࠬ垼"),l1l111_l1_ (u"ࠬ࠭垽"),l1l111_l1_ (u"࠭ࠧ垾"),l1l111_l1_ (u"ࠧࠨ垿"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ埀"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡦࡴࡾ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡦ࡭ࡱࡤࡸ࠲ࡸࡩࡨࡪࡷࠫ埁"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠪࡧࡦࡺࡳࡶ࡯࠰ࡱࡴࡨࡩ࡭ࡧࠪ埂") in block:
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埃"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ埄")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ埅")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠧࠡษ็ูํะ๊ส࠼ࠣࠫ埆"),l1l111_l1_ (u"ࠨ࠼ࠪ埇"))
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埈"))
				title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埉")+count+l1l111_l1_ (u"ࠫ࠮࠭埊")
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埋"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭埌"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1111l1ll_l1_,l1l1lll1ll_l1_ in items:
			if title==l1l111_l1_ (u"ࠧࠨ埍") or l11l1111l1ll_l1_==l1l111_l1_ (u"ࠨࠩ城"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埏")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埐")+l1l1lll1ll_l1_+l1l111_l1_ (u"ࠫ࠮࠭埑")
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埒"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ埓"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ埔"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll1ll_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埕")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埖"))
		name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ埗"))
		title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ埘")+name+l1l111_l1_ (u"ࠬ࠯ࠧ埙")
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ埚"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠧࠨ埛"),l1l1lll1ll_l1_)
	return
def l11l1111l11l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ埜"),url,l1l111_l1_ (u"ࠩࠪ埝"),l1l111_l1_ (u"ࠪࠫ埞"),l1l111_l1_ (u"ࠫࠬ域"),l1l111_l1_ (u"ࠬ࠭埠"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉࡡࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ埡"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠦࡰ࠮࠳ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ埢"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埣"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埤")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ埥"))
		if l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠰ࠫ埦") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埧"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埨"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ埩"),url,l1l111_l1_ (u"ࠨࠩ埪"),l1l111_l1_ (u"ࠩࠪ埫"),l1l111_l1_ (u"ࠪࠫ埬"),l1l111_l1_ (u"ࠫࠬ埭"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ埮"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭埯"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埰"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ埱"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ埲"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ埳"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭埴"),l1l111_l1_ (u"ࠬ࠱ࠧ埵"))
	l11l1111ll11_l1_ = [l1l111_l1_ (u"࠭ࠦࡵ࠿ࡤࠫ埶"),l1l111_l1_ (u"ࠧࠧࡶࡀࡧࠬ執"),l1l111_l1_ (u"ࠨࠨࡷࡁࡸ࠭埸")]
	if l11_l1_:
		l11l1111l111_l1_ = [l1l111_l1_ (u"ࠩๅหึฬࠧ培"),l1l111_l1_ (u"ࠪษฺีวาࠢ࠲ࠤ๊าไะࠩ基"),l1l111_l1_ (u"๊่ࠫืฺࠢสฺ่๎ส๋ࠩ埻")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠ࠮ࠢฦาฯืࠠศๆหัะ࠭埼"), l11l1111l111_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࡣࠬ埽") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬ埾") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࡤ࠭埿") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1111ll11_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ堀")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ堁"),url,l1l111_l1_ (u"ࠫࠬ堂"),l1l111_l1_ (u"ࠬ࠭堃"),l1l111_l1_ (u"࠭ࠧ堄"),l1l111_l1_ (u"ࠧࠨ堅"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ堆"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭堇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ堈"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭堉"))
				name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ堊"))
				title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ堋")+name+l1l111_l1_ (u"ࠧࠪࠩ堌")
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堍"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ堎"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ堏"))
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭堐"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ堑")+name+l1l111_l1_ (u"࠭ࠩࠨ堒")
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭堓"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
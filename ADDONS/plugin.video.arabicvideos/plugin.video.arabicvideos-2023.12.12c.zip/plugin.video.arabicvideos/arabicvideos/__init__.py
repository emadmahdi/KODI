# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l1l11l_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡋࡑࡍ࡙࠭揝")
l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ揞"),l1l111_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠨ揟"))
l1lll111lll_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = l1lll111lll_l1_
l1ll1ll1ll1l_l1_ = int(mode)
l1lll1lllll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ揠"))
l1lll1lllll1_l1_ = l1lll1lllll1_l1_.replace(ltr,l1l111_l1_ (u"ࠬ࠭握")).replace(rtl,l1l111_l1_ (u"࠭ࠧ揢"))
if l1ll1ll1ll1l_l1_==260: message = l1l111_l1_ (u"࡚ࠧࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࡡࠠࠨ揣")+l1l11l1llll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡋࡰࡦ࡬࠾ࠥࡡࠠࠨ揤")+l1l1l1l11ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ揥")
else:
	l111l1ll11l1_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭揦"),l1l111_l1_ (u"ࠫࠬ揧")).replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ揨"),l1l111_l1_ (u"࠭ࠧ揩"))
	l111l1ll11l1_l1_ = l111l1ll11l1_l1_.replace(l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ揪"),l1l111_l1_ (u"ࠨࠩ揫")).strip(l1l111_l1_ (u"ࠩࠣࠫ揬"))
	l111l1ll11l1_l1_ = l111l1ll11l1_l1_.replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ揭"),l1l111_l1_ (u"ࠫࠥ࠭揮")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ揯"),l1l111_l1_ (u"࠭ࠠࠨ揰")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ揱"),l1l111_l1_ (u"ࠨࠢࠪ揲"))
	message = l1l111_l1_ (u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨ揳")+l1lll1lllll1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪ援")+mode+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ揵")+l111l1ll11l1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ揶")
l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭揷"),l11lllll11_l1_(l1ll1_l1_)+message)
l1ll1l1lll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ揸"))
l111l11lll1_l1_ = False if l1ll1l1lll11_l1_==l1l11l1llll_l1_ else True
if not l111l11lll1_l1_ and l1ll1ll1ll1l_l1_ in [235,715]:
	l1l1l11111ll_l1_ = str(l1llllll11l_l1_[l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ揹")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ揺") if l1ll1ll1ll1l_l1_==235 else l1l111_l1_ (u"ࠪࡱ࠸ࡻࠧ揻")
	l11ll1l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࠨ揼")+l1ll1_l1_+l1l111_l1_ (u"ࠬ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ揽")+l1l1l11111ll_l1_)
	l11lll1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࠪ揾")+l1ll1_l1_+l1l111_l1_ (u"ࠧ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ揿")+l1l1l11111ll_l1_)
	if l11ll1l1l1_l1_ or l11lll1ll1_l1_:
		url += l1l111_l1_ (u"ࠨࡾࠪ搀")
		if l11ll1l1l1_l1_: url += l1l111_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ搁")+l11ll1l1l1_l1_
		if l11lll1ll1_l1_: url += l1l111_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭搂")+l11lll1ll1_l1_
		url = url.replace(l1l111_l1_ (u"ࠫࢁࠬࠧ搃"),l1l111_l1_ (u"ࠬࢂࠧ搄"))
	l11l11ll11_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࠪ搅")+l1ll1_l1_+l1l111_l1_ (u"ࠧ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ搆")+l1l1l11111ll_l1_)
	if l11l11ll11_l1_:
		l111l1ll11ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫ搇"),url,re.DOTALL)
		url = url.replace(l111l1ll11ll_l1_[0],l11l11ll11_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll1ll1l1_l1_,l11111l1111_l1_,l1ll1lllll11_l1_
	l1111llll11_l1_ = l1l111_l1_ (u"ࠩࠪ搈")
	l11ll1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ搉"))
	try: l11111l1111_l1_(l1lll111lll_l1_,l1lll1lllll1_l1_)
	except Exception as error: l1111llll11_l1_ = traceback.format_exc()
	l11ll1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ搊"))
	l1ll1lllll11_l1_(l1111llll11_l1_)
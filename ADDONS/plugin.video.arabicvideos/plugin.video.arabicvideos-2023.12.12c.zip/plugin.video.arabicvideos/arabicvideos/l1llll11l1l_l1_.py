# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ⨝")
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⨞"):l1l111_l1_ (u"ࠪࠫ⨟")}
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡌࡈ࠳ࡡࠪ⨠")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬࡽࡷࡦࠩ⨡")]
def l11l1ll_l1_(mode,url,text):
	if   mode==590: l1lll_l1_ = l1l1l11_l1_()
	elif mode==591: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==592: l1lll_l1_ = PLAY(url)
	elif mode==593: l1lll_l1_ = l111l1111_l1_(url,text)
	elif mode==599: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⨢"),l1l11ll_l1_,l1l111_l1_ (u"ࠧࠨ⨣"),l1l111_l1_ (u"ࠨࠩ⨤"),l1l111_l1_ (u"ࠩࠪ⨥"),l1l111_l1_ (u"ࠪࠫ⨦"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⨧"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨨"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⨩"),l1l11ll_l1_,599,l1l111_l1_ (u"ࠧࠨ⨪"),l1l111_l1_ (u"ࠨࠩ⨫"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⨬"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⨭"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⨮"),l1l111_l1_ (u"ࠬ࠭⨯"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨰"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ⨱"),l1l11ll_l1_,591,l1l111_l1_ (u"ࠨࠩ⨲"),l1l111_l1_ (u"ࠩࠪ⨳"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⨴"))
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⨵"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨶"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⨷")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠧࠨ⨸"),l1l111_l1_ (u"ࠨࠩ⨹"),l1l111_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠴ࠫ⨺"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⨻"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⨼"),l1l111_l1_ (u"ࠬ࠭⨽"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡩࡧࡤࡨࡪࡸ࠭ࡴࡱࡦ࡭ࡦࡲࠧ⨾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡮࡬ࠤ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ⨿"),block,re.DOTALL)
		for l1llll1ll1l_l1_ in l1llll1l1ll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⩀"),l1llll1ll1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⩁") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩂"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⩃")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠬ࠭⩄"),l1l111_l1_ (u"࠭ࠧ⩅"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⩆"))
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⩇")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⩈"),url,l1l111_l1_ (u"ࠪࠫ⩉"),l1l111_l1_ (u"ࠫࠬ⩊"),l1l111_l1_ (u"ࠬ࠭⩋"),l1l111_l1_ (u"࠭ࠧ⩌"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⩍"))
	html = response.content
	l1llll11l11_l1_ = 0
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡷࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽ࡪ࠷ࡂࠬ⩎"),html,re.DOTALL)
	if l11ll11_l1_: l1l1l1l_l1_ = l11ll11_l1_[0]
	else: l1l1l1l_l1_ = l1l111_l1_ (u"ࠩࠪ⩏")
	if type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⩐"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹ࡬ࡪࡦࡨࡶ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡁࠫ⩑"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡴ࡮࡬ࡨࡪࡸ࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⩒"),block,re.DOTALL)
		l11ll1l11_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⩓"):
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠷࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ⩔"),l1l1l1l_l1_,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⩕"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭⩖"),l1l111_l1_ (u"ࠪ࠳ࠬ⩗")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ⩘"),l1l111_l1_ (u"ࠬࠨࠧ⩙"))]
	elif type==l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨ⩚") and l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ⩛") in l1l1l1l_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡂࠬ⩜"),html,re.DOTALL)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩝"),l1lllll_l1_+l1l111_l1_ (u"้๊ࠪ๐าสࠩ⩞"),url,591,l1l111_l1_ (u"ࠫࠬ⩟"),l1l111_l1_ (u"ࠬ࠭⩠"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⩡"))
		title = l11llll_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⩢"),l1lllll_l1_+title,url,591,l1l111_l1_ (u"ࠨࠩ⩣"),l1l111_l1_ (u"ࠩࠪ⩤"),l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠷ࠬ⩥"))
		return
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠾ࠨ⩦"),html,re.DOTALL)
		title,block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⩧"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭⩨"),l1l111_l1_ (u"ࠧโ์็้ࠬ⩩"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ⩪"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ⩫"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ⩬"),l1l111_l1_ (u"ࠫ์ีวโࠩ⩭"),l1l111_l1_ (u"๋ࠬศศำสอࠬ⩮"),l1l111_l1_ (u"ู࠭าุࠪ⩯"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ⩰"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ⩱"),l1l111_l1_ (u"่ࠩืึำ๊สࠩ⩲"),l1l111_l1_ (u"ࠪั้่ษࠨ⩳")]
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⩴"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⩵"),title,re.DOTALL)
		if l1l111_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ⩶") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⩷"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠨࠩ⩸"):
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⩹")+l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩺"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⩻"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⩼"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⩽"):
		l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ⩾"),block,re.DOTALL)
		if l111l1lll1_l1_:
			count = l111l1lll1_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ⩿")+count
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⪀"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭⪁"),l1ll1ll_l1_,591,l1l111_l1_ (u"ࠫࠬ⪂"),l1l111_l1_ (u"ࠬ࠭⪃"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⪄"))
	elif l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳࠨ⪅") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⪆"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⪇"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ูࠪๆำษࠡࠩ⪈")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪉"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠬ࠭⪊"),l1l111_l1_ (u"࠭ࠧ⪋"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠵ࠩ⪌"))
	return
def l111l1111_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⪍")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⪎"),url,l1l111_l1_ (u"ࠪࠫ⪏"),l1l111_l1_ (u"ࠫࠬ⪐"),l1l111_l1_ (u"ࠬ࠭⪑"),l1l111_l1_ (u"࠭ࠧ⪒"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⪓"))
	html = response.content
	l111llll1l_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡩࡦࡹ࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡦࡹ࡯࡯ࡵࡁࠫ⪔"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ⪕"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ⪖"))
				l111llll1l_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪗"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭⪘"),l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⪙"))
	if type==l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⪚") or not l111llll1l_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡥ࡯ื࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠧࡄ࠼࠰ࡤ࡮ࡂࠬ⪛"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ⪜")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡦࡲ࡬࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡰࡱ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠿ࠩ⪝"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⪞"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⪟"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⪠"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l11l_l1_,l1llll1ll11_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⪡"),url,l1l111_l1_ (u"ࠨࠩ⪢"),l1l111_l1_ (u"ࠩࠪ⪣"),l1l111_l1_ (u"ࠪࠫ⪤"),l1l111_l1_ (u"ࠫࠬ⪥"),l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⪦"))
	html = response.content
	l1llll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅ฻่ีࠥࡀ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬ⪧"),html,re.DOTALL)
	if l1llll11ll1_l1_ and l11111l_l1_(l1ll1_l1_,url,l1llll11ll1_l1_): return
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⪨"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ⪩"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡱ࡯ࡣࡦ࠯ࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⪪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⪫"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭⪬"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⪭")+name+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⪮"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸࡄࠧ⪯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⪰"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⪱")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⪲"))
	for l1llll1l111_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l111_l1_.split(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࠫ⪳"))
		if l1ll1ll_l1_ not in l1llll1l11l_l1_:
			l1llll1l11l_l1_.append(l1ll1ll_l1_)
			l1llll1ll11_l1_.append(l1llll1l111_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1ll11_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⪴"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ⪵"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ⪶"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⪷"),l1l111_l1_ (u"ࠩ࠮ࠫ⪸"))
	l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⪹")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠺࠭⪺"))
	return
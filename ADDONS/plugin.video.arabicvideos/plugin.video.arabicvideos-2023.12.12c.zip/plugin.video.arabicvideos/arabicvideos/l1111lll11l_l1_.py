# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ堔")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍ࡚࡟ࠨ堕")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ堖"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ堗"),l1l111_l1_ (u"ࠬษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠨ堘")]
def l11l1ll_l1_(mode,url,text):
	if   mode==640: l1lll_l1_ = l1l1l11_l1_()
	elif mode==641: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==642: l1lll_l1_ = PLAY(url)
	elif mode==643: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==644: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==649: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堙"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ堚"),l1l111_l1_ (u"ࠨࠩ堛"),l1l111_l1_ (u"ࠩࠪ堜"),l1l111_l1_ (u"ࠪࠫ堝"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭堞"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堟"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭堠"),l1l111_l1_ (u"ࠧࠨ堡"),649,l1l111_l1_ (u"ࠨࠩ堢"),l1l111_l1_ (u"ࠩࠪ堣"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ堤"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ堥"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ堦"),l1l111_l1_ (u"࠭ࠧ堧"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ堨"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ堩"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠩࠪ堪"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ堫"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堬"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ堭")+l1lllll_l1_+title,l1ll1ll_l1_,644)
	return
def l11ll1_l1_(url):
	l11ll111l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堮"),url,l1l111_l1_ (u"ࠧࠨ堯"),l1l111_l1_ (u"ࠨࠩ堰"),l1l111_l1_ (u"ࠩࠪ報"),l1l111_l1_ (u"ࠪࠫ堲"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ堳"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ場"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ堵"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭堶"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ堷"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪ堸"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ堹"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ堺"),l1l111_l1_ (u"ࠬ࠭堻"),9999)
		for l11111_l1_,block in l11llll_l1_:
			l11ll111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ堼"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪ堽")
			for l1ll1ll_l1_,title in l11ll111l_l1_:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堾"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭堿"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ塀"),block,re.DOTALL)
		if len(l1l1111_l1_)<30:
			if l11ll111l_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ塁"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ塂"),l1l111_l1_ (u"࠭ࠧ塃"),9999)
			for l1ll1ll_l1_,title in l1l1111_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塄"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩ塅")):
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ塆"):
		url,search = url.split(l1l111_l1_ (u"ࠪࡃࠬ塇"),1)
		data = l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ塈")+search
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ塉"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭塊")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ塋"),url,data,headers,l1l111_l1_ (u"ࠨࠩ塌"),l1l111_l1_ (u"ࠩࠪ塍"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ塎"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ塏"),url,l1l111_l1_ (u"ࠬ࠭塐"),l1l111_l1_ (u"࠭ࠧ塑"),l1l111_l1_ (u"ࠧࠨ塒"),l1l111_l1_ (u"ࠨࠩ塓"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭塔"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠪࠫ塕"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ塖"))
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ塗"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ塘"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨ塙"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ塚"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ塛"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ塜"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ塝"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ塞"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭塟"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ塠"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ塡"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ塢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠪࠫ塣"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ塤"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ塥"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭塦"),l1l111_l1_ (u"ࠧโ์็้ࠬ塧"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ塨"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ塩"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ塪"),l1l111_l1_ (u"ࠫ์ีวโࠩ填"),l1l111_l1_ (u"๋ࠬศศำสอࠬ塬"),l1l111_l1_ (u"ู࠭าุࠪ塭"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ塮"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ塯"),l1l111_l1_ (u"่ࠩืึำ๊สࠩ塰")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭塱"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ塲"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ塳"):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ塴"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭塵") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ塶"),l1lllll_l1_+title,l1ll1ll_l1_,643,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ塷"),l1lllll_l1_+title,l1ll1ll_l1_,643,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ塸"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ塹"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ塺"): continue
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ塻") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ塼")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ塽"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ塾"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ塿")+title,l1ll1ll_l1_,641)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ墀"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ墁"),url,l1l111_l1_ (u"࠭ࠧ墂"),l1l111_l1_ (u"ࠧࠨ境"),l1l111_l1_ (u"ࠨࠩ墄"),l1l111_l1_ (u"ࠩࠪ墅"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ墆"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ墇"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ墈"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࠧ墉")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ墊"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠨࠥࠪ墋"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墌"),l1lllll_l1_+title,url,643,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ墍"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦࠬ墎")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ墏"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ墐"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ墑") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ墒")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ墓"))
			title = title.replace(l1l111_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ墔"),l1l111_l1_ (u"ࠫࠥ࠭墕"))
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ墖"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ増"),l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠴ࡰࡩࡲࠪ墘"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ墙"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ墚"),l1l111_l1_ (u"ࠪࠫ墛"),l1l111_l1_ (u"ࠫࠬ墜"),l1l111_l1_ (u"ࠬ࠭墝"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ增"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ墟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭墠"),block,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_ = l1ll_l1_[0]
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ墡"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ墢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ墣"),block,re.DOTALL)
		block = block.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ墤"),l1l111_l1_ (u"࠭ࠢࠨ墥")).replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ墦"),l1l111_l1_ (u"ࠨ࠱ࠪ墧"))
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡀ࡮࡬ࡲࡢ࡯ࡨ࠲ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ墨"),block,re.DOTALL)
		if len(l11l1l1l1_l1_)==len(l1ll_l1_):
			for id,title in l11l1l1l1_l1_:
				l1ll1ll_l1_ = l1ll_l1_[int(id)]
				if l1ll1ll_l1_ not in l1llll_l1_:
					l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ墩")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ墪"))
					l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ墫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ墬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ墭")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ墮"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ墯"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ墰"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ墱"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ墲"),l1l111_l1_ (u"࠭ࠫࠨ墳"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ墴")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ墵"))
	return
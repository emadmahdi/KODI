# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ僃")
headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ僄") : l1l111_l1_ (u"࠭ࠧ僅") }
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭僆")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11ll1l1l1ll_l1_(url)
	elif mode==215: l1lll_l1_ = l11ll1l1ll11_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1l1ll1111_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1ll1111_l1_():
	message = l1l111_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭僇")
	l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ僈"),l1l111_l1_ (u"ࠪࠫ僉"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ僊"),l1l111_l1_ (u"ࠬอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠫ僋"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僌"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ働"),l1l111_l1_ (u"ࠨࠩ僎"),219,l1l111_l1_ (u"ࠩࠪ像"),l1l111_l1_ (u"ࠪࠫ僐"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僑"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡑ࡫ࡱࡃࡹࡿࡰࡦ࠿ࡲࡲࡪࠬࡤࡢࡶࡤࡁࡵ࡯࡮ࠧ࡮࡬ࡱ࡮ࡺ࠽࠳࠷ࠪ僒")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僓"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ僔")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ僕"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪ僖"),headers,l1l111_l1_ (u"ࠪࠫ僗"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ僘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡌࡩ࡭ࡶࡨࡶࡸࡈࡵࡵࡶࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ僙"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ僚"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫ僛")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僜"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ僝")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ僞"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ僟"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"๋ࠬำๅี็หฯࠦว็็ํࠫ僠"),l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ僡")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ僢"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僣"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ僤")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ僥"),headers,l1l111_l1_ (u"ࠫࠬ僦"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ僧"))
	if l1l111_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ僨") in url or l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ僩") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡏࡨࡨ࡮ࡧࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ僪"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ僫"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ僬"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ僭"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ僮"),l1l111_l1_ (u"࠭ใๅ์หࠫ僯"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭僰"),l1l111_l1_ (u"ࠨ้าหๆ࠭僱"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ僲"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ僳"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ僴"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ僵")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ僶") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩ僷"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ僸"))
		if l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ價") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ僺"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ僻") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ僼") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ僽"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭僾") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僿"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ儀"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ儁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ儂"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭儃"),l1l111_l1_ (u"࠭ࠧ億"))
			if title!=l1l111_l1_ (u"ࠧࠨ儅"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ儆"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ儇")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ儈"),headers,l1l111_l1_ (u"ࠫࠬ儉"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ儊"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡴࡪ࠯࡯࡭ࡸࡺ࠭࡯ࡷࡰࡦࡪࡸࡥࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭儋"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠧࠨ儌").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ儍"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ儎"))
		title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ儏") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭儐"))[-1].replace(l1l111_l1_ (u"ࠬ࠳ࠧ儑"),l1l111_l1_ (u"࠭ࠠࠨ儒"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧศๆะ่็ฯ࠭ࠩ࡞ࡧ࠯࠮࠭儓"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ儔"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ儕")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ儖"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ儗"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ儘") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ儙") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儚"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ儛") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ儜"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ儝"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ儞"),headers,l1l111_l1_ (u"ࠬ࠭償"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ儠"))
	if l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ儡") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ儢"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ儣"),headers,l1l111_l1_ (u"ࠪࠫ儤"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ儥"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ儦"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡧࡵࡺࡪࡸ࡟ࡪ࡯ࡤ࡫ࡪࠨ࠾࡝ࡰࠫ࠲࠯ࡅࠩ࡝ࡰࠪ儧"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ儨"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l11l11_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫ儩")+l1l1l11l11_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭優")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ儫")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ儬")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭儭"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ儮") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ儯"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ儰"),headers,l1l111_l1_ (u"ࠩࠪ儱"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ儲"))
		id = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡋࡧ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ儳"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l11l11_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ儴"):l1l111_l1_ (u"࠭ࠧ儵") , l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ儶"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ儷") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ儸")+l1l1l11l11_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ儹"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ儺"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭儻"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ儼"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ儽"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ儾")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭儿")+l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ兀")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠶ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ允"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠬ࠭兂")
					items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ元"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"ࠧࠧࠨࠪ兄") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ充"))[2].lower() + l1l111_l1_ (u"ࠩࠩࠪࠬ兆")
						server = server.replace(l1l111_l1_ (u"ࠪ࠲ࡨࡵ࡭ࠧࠨࠪ兇"),l1l111_l1_ (u"ࠫࠬ先")).replace(l1l111_l1_ (u"ࠬ࠴ࡣࡰࠨࠩࠫ光"),l1l111_l1_ (u"࠭ࠧ兊"))
						server = server.replace(l1l111_l1_ (u"ࠧ࠯ࡰࡨࡸࠫࠬࠧ克"),l1l111_l1_ (u"ࠨࠩ兌")).replace(l1l111_l1_ (u"ࠩ࠱ࡳࡷ࡭ࠦࠧࠩ免"),l1l111_l1_ (u"ࠪࠫ兎"))
						server = server.replace(l1l111_l1_ (u"ࠫ࠳ࡲࡩࡷࡧࠩࠪࠬ兏"),l1l111_l1_ (u"ࠬ࠭児")).replace(l1l111_l1_ (u"࠭࠮ࡰࡰ࡯࡭ࡳ࡫ࠦࠧࠩ兑"),l1l111_l1_ (u"ࠧࠨ兒"))
						server = server.replace(l1l111_l1_ (u"ࠨࠨࠩ࡬ࡩ࠴ࠧ兓"),l1l111_l1_ (u"ࠩࠪ兔")).replace(l1l111_l1_ (u"ࠪࠪࠫࡽࡷࡸ࠰ࠪ兕"),l1l111_l1_ (u"ࠫࠬ兖"))
						server = server.replace(l1l111_l1_ (u"ࠬࠬࠦࠨ兗"),l1l111_l1_ (u"࠭ࠧ兘"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ兙") + name + server + l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ党")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ兛"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ兜"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ兝"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ兞"),l1l111_l1_ (u"࠭ࠫࠨ兟"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ兠")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ຅")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬຆ"):l1l1ll11l_l1_()}
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨງ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬຈ"),l1l111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษ๎ࠫຉ"),l1l111_l1_ (u"๋ࠬีศำ฼๋ࠬຊ"),l1l111_l1_ (u"࠭วฺๆ้ࠤ๊฿ๆศࠢ⠖ࠤࡋࡵࡲࠡࡣࡧࡷࠬ຋"),l1l111_l1_ (u"ࠧๆ๊หห๏๊วหࠩຌ"),l1l111_l1_ (u"ࠨสิห๊าࠠไ็ห๎ํะัࠨຍ"),l1l111_l1_ (u"ࠩส่฾อศࠡๅ่ฬ๏๎สาࠩຎ"),l1l111_l1_ (u"ࠪหุ๊วๆ์สฮࠬຏ"),l1l111_l1_ (u"ࠫฬิั๊ࠩຐ"),l1l111_l1_ (u"ࠬอโิษ่ࠤฬิั๋ࠩຑ"),l1l111_l1_ (u"࠭วีฬิห่อสࠨຒ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==250: l1lll_l1_ = l1l1l11_l1_()
	elif mode==251: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==252: l1lll_l1_ = PLAY(url)
	elif mode==253: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==254: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧຓ")+text)
	elif mode==255: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬດ")+text)
	elif mode==256: l1lll_l1_ = l11ll1_l1_(url,text)
	elif mode==259: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ຕ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩຖ"),l1l111_l1_ (u"ࠫࠬທ"),headers,l1l111_l1_ (u"ࠬ࠭ຘ"),l1l111_l1_ (u"࠭ࠧນ"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫບ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨປ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩຜ"),l1l111_l1_ (u"ࠪࠫຝ"),259,l1l111_l1_ (u"ࠫࠬພ"),l1l111_l1_ (u"ࠬ࠭ຟ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪຠ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧມ"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫຢ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪຣ"),254)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ຤"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧລ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭຦"),255)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫວ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧຨ"),l1l111_l1_ (u"ࠨࠩຩ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩສ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫຫ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪຬ"),251,l1l111_l1_ (u"ࠬ࠭ອ"),l1l111_l1_ (u"࠭ࠧຮ"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡥ࡮ࡴࠧຯ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨະ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫັ")+l1lllll_l1_+l1l111_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩາ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪຳ"),251,l1l111_l1_ (u"ࠬ࠭ິ"),l1l111_l1_ (u"࠭ࠧີ"),l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫຶ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨື"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢຸࠫ")+l1lllll_l1_+l1l111_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหູࠩ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳࡡࡪࡰ຺ࠪ"),251,l1l111_l1_ (u"ࠬ࠭ົ"),l1l111_l1_ (u"࠭ࠧຼ"),l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ຽ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ຾"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ຿")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪເ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡡࡵࡧࡶࡸࠬແ"),251,l1l111_l1_ (u"ࠬ࠭ໂ"),l1l111_l1_ (u"࠭ࠧໃ"),l1l111_l1_ (u"ࠧ࡭ࡣࡶࡸࡪࡹࡴࠨໄ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭໅"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩໆ"),l1l111_l1_ (u"ࠪࠫ໇"),9999)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒ࡫࡮ࡶࡊࡨࡥࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ່࠭"),html,re.DOTALL)
	l1l1l1l_l1_ = l11ll11_l1_[0]
	l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ້ࠧ"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in l1l1111_l1_:
		title = unescapeHTML(title)
		if title not in l11lll_l1_ and title!=l1l111_l1_ (u"໊࠭ࠧ"):
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴ໋ࠬ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໌"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫໍ")+l1lllll_l1_+title,l1ll1ll_l1_,256)
	return html
def l11ll1_l1_(url,type):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ໎"),url,l1l111_l1_ (u"ࠫࠬ໏"),headers,l1l111_l1_ (u"ࠬ࠭໐"),l1l111_l1_ (u"࠭ࠧ໑"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ໒"))
	html = response.content
	if l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠪ໓") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ໔"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪ໕"),url,251,l1l111_l1_ (u"ࠫࠬ໖"),l1l111_l1_ (u"ࠬ࠭໗"),l1l111_l1_ (u"࠭࡭ࡰࡵࡷࠫ໘"))
	if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠫ໙") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໚"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ໛"),url,251,l1l111_l1_ (u"ࠪࠫໜ"),l1l111_l1_ (u"ࠫࠬໝ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧໞ"))
	if l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩໟ") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭໠"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			if len(l11llll_l1_)>1 and type==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ໡"): block = l11llll_l1_[1]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ໢"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ໣"),title,re.DOTALL)
				try: l1l11ll11_l1_ = l1lllllll_l1_[0][0]
				except: l1l11ll11_l1_ = l1l111_l1_ (u"ࠫࠬ໤")
				try: l1l11ll1l_l1_ = l1lllllll_l1_[0][1]
				except: l1l11ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭໥")
				l1lllllll_l1_ = l1l11ll11_l1_+l1l11ll1l_l1_
				l1lllllll_l1_ = l1lllllll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ໦"),l1l111_l1_ (u"ࠧࠨ໧"))
				if l1l111_l1_ (u"ࠨ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠪ໨") in title:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭໩"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if not l1lllllll_l1_:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ໪"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if l1lllllll_l1_:
					if l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ໫") in l1ll1ll_l1_: type = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ໬"))[1]
					else: type = l1l111_l1_ (u"࠭࡮ࡦࡹࡨࡷࡹ࠭໭")
					l1lllllll_l1_ = l1lllllll_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ໮"))
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໯"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠩࠪ໰"),l1l111_l1_ (u"ࠪࠫ໱"),type)
	return
def l1lll11_l1_(url,type):
	method,data,items = l1l111_l1_ (u"ࠫࡌࡋࡔࠨ໲"),l1l111_l1_ (u"ࠬ࠭໳"),[]
	if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ໴"):
		if l1l111_l1_ (u"ࠧࡀࠩ໵") in url:
			l1l11lll1_l1_,l1l11llll_l1_ = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭໶"),{}
			l1lllll1_l1_,l1l1l1111_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࠫ໷"))
			lines = l1l1l1111_l1_.split(l1l111_l1_ (u"ࠪࠪࠬ໸"))
			for line in lines:
				key,value = line.split(l1l111_l1_ (u"ࠫࡂ࠭໹"))
				l1l11llll_l1_[key] = value
			if lines: method,url,data = l1l11lll1_l1_,l1lllll1_l1_,l1l11llll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,method,url,data,headers,l1l111_l1_ (u"ࠬ࠭໺"),l1l111_l1_ (u"࠭ࠧ໻"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭໼"))
	html = response.content
	if type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ໽"): l11llll_l1_ = [html]
	elif l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ໾") in type: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧ໿"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨༀ"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬาฯ๋ัࠣห้อแๅษ่࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ༁"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ༂"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ༃"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭༄"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫ༅"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡆࡱࡵࡣ࡬ࡵ࠰࡙ࡑࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡆࡨ࡯ࡆ࡮ࡖࡩࡪࡪࠢࠨ༆"),html,re.DOTALL)
	if l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭༇") in type:
		block = l11llll_l1_[0]
		zz = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡱࡧࡺࡺ࠰࠭ࡃࠥ࠮ࡳࡳࡥࡿࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫ࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༈"),block,re.DOTALL)
		if zz:
			l1llll_l1_,l1l1lll1_l1_,l1l1l1l1l_l1_,l1l1ll1ll_l1_ = zip(*zz)
			items = zip(l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_)
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࡁࡳࡧࡤ࠲࠯ࡅࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭࡝ࡹࡾ࠷࠱࠻ࡽ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ༉"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧࡘ࡙ࡈࠫ༊") in title: continue
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨษ็ั้่ษࠨ་") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ༌"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ།") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ༎"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ༏"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ༐") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧๆี็ื้࠭༑") in title:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ༒"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ༓"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"ࠪࡲࡪࡽࡥࡴࡶࠪ༔"),l1l111_l1_ (u"ࠫࡧ࡫ࡳࡵࠩ༕"),l1l111_l1_ (u"ࠬࡳ࡯ࡴࡶࠪ༖")]:
		items = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡳࡻ࡭ࡣࡧࡵࡷࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ༗"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ༘ࠧ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮ༙ࠦࠧ")+title,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠩࠪ༚"),l1l111_l1_ (u"ࠪࠫ༛"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ༜"),url,l1l111_l1_ (u"ࠬ࠭༝"),headers,l1l111_l1_ (u"࠭ࠧ༞"),l1l111_l1_ (u"ࠧࠨ༟"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ༠"))
	html = response.content
	html = html[10000:]
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ༡"),html,re.DOTALL)
	if not items: return
	l1ll1l_l1_,name = items[0]
	if l1l111_l1_ (u"ࠪห้ำไใหࠪ༢") in name: name = name.split(l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ༣"))[0].strip(l1l111_l1_ (u"ࠬࠦࠧ༤"))
	elif l1l111_l1_ (u"࠭อๅไฬࠫ༥") in name: name = name.split(l1l111_l1_ (u"ࠧฮๆๅอࠬ༦"))[0].strip(l1l111_l1_ (u"ࠨࠢࠪ༧"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶࡊࡶࡩࡴࡱࡧࡩࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ༨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ༩"),block,re.DOTALL)
		for l1ll1ll_l1_,l1l1lll_l1_ in items:
			title = name+l1l111_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠาไ่ࠤࠬ༪")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ༫"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ༬"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ༭"),url,252,l1ll1l_l1_)
	return
def l1l111lll_l1_(title,l1ll1ll_l1_):
	l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡝ࡤ࠱ࡿࡇ࡛࠭࠯ࡠ࠯ࠬ༮"),title,re.DOTALL)
	if l1lllllll_l1_: title = l1lllllll_l1_[0]
	else: title = title+l1l111_l1_ (u"ࠩࠣࠫ༯")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ༰"))
	title = title.replace(l1l111_l1_ (u"ࠫ฾ืศࠡีํำࠬ༱"),l1l111_l1_ (u"ࠬ࠭༲")).replace(l1l111_l1_ (u"࠭ๅษษืีࠬ༳"),l1l111_l1_ (u"ࠧࠨ༴")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠨ༵"),l1l111_l1_ (u"ࠩࠪ༶"))
	title = title.replace(l1l111_l1_ (u"ࠪ๑༷ࠬ"),l1l111_l1_ (u"ࠫࠬ༸"))
	title = title.replace(l1l111_l1_ (u"ࠬࠦࠠࠨ༹"),l1l111_l1_ (u"࠭ࠠࠨ༺")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ༻"),l1l111_l1_ (u"ࠨࠢࠪ༼"))
	return title
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭༽"),url,l1l111_l1_ (u"ࠪࠫ༾"),headers,l1l111_l1_ (u"ࠫࠬ༿"),l1l111_l1_ (u"ࠬ࠭ཀ"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪཁ"))
	html = response.content
	l1lllll1_l1_ = response.url
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫག"))
	headers[l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩགྷ")] = server+l1l111_l1_ (u"ࠩ࠲ࠫང")
	l1l111ll1_l1_,l1l1l11ll_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫཅ"),l1l111_l1_ (u"ࠫࠬཆ"),[]
	l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡆࡺࡺࡴࡰࡰࡶࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࠨࡸࡣࡷࡧ࡭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࠬࡂ࠭ࠧ࠭ཇ"),html,re.DOTALL)
	if l1l1ll1l1_l1_: l1l111ll1_l1_,l1l1l1lll_l1_,l1l1l11ll_l1_,l1l1l1ll1_l1_ = l1l1ll1l1_l1_[0]
	else:
		l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡇࡻࡴࡵࡱࡱࡷࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ཈"),html,re.DOTALL)
		if l1l1ll1l1_l1_:
			l1ll1ll_l1_,l1l1l1lll_l1_ = l1l1ll1l1_l1_[0]
			if l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭ཉ") in l1l1l1lll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			else: l1l1l11ll_l1_ = l1ll1ll_l1_
	if l1l111ll1_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬཊ"),l1l111ll1_l1_,l1l111_l1_ (u"ࠩࠪཋ"),headers,l1l111_l1_ (u"ࠪࠫཌ"),l1l111_l1_ (u"ࠫࠬཌྷ"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩཎ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡪࡸࡁࡳࡧࡤࠦ࠭࠴ࠪࡀ࠾࠲ࡹࡱࡄࠩࠨཏ"),html,re.DOTALL)
		if l11llll_l1_:
			l1l111l11_l1_ = l11llll_l1_[0]
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ཐ"),l1l111_l1_ (u"ࠨ࠾࡫࠷ࡃ࠭ད"))
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"ࠩ࠿࡬࠸ࡄࠧདྷ"),l1l111_l1_ (u"ࠪࡀ࡭࠹࠾࠽ࡪ࠶ࡂࠬན"))
			l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠳࠿࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽ࡪ࠶ࡂࠬཔ"),l1l111l11_l1_,re.DOTALL)
			if not l1lll1l1_l1_: l1lll1l1_l1_ = [(l1l111_l1_ (u"ࠬ࠭ཕ"),l1l111l11_l1_)]
			for l111l1ll_l1_,block in l1lll1l1_l1_:
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫབ")+l111l1ll_l1_
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫབྷ"),block,re.DOTALL)
				for l1ll1ll_l1_,name in items:
					if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭མ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨཙ")+l1ll1ll_l1_
					l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫཚ")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬཛ")+l111l1ll_l1_
					l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡊࡨࡵࡥࡲ࡫ࠢ࠯ࠬࡂࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ཛྷ"),html,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࡋࡩࡶࡦࡳࡥࠣ࠰࠭ࡃ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡈࡆࡋࡊࡌ࡙ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧཝ"),html,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_,l111l1ll_l1_ = l1ll_l1_[0]
			name = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬཞ"))
			if l1l111_l1_ (u"ࠨࠧࠪཟ") in l111l1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪའ")+name+l1l111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭ཡ")
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬར")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࡠࡡࠪལ")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l1l11ll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪཤ"),l1l1l11ll_l1_,l1l111_l1_ (u"ࠧࠨཥ"),headers,l1l111_l1_ (u"ࠨࠩས"),l1l111_l1_ (u"ࠩࠪཧ"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧཨ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡇࡲࡦࡣࠥࠬ࠳࠰࠿ࠪࡨࡸࡲࡨࡺࡩࡰࡰࠪཀྵ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬཪ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
				if not l1ll1ll_l1_: continue
				if l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡹࡴࡢࡶ࡬ࡳࡳ࠭ཫ") in l1ll1ll_l1_: continue
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨཬ")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ཭")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	l1l11l11l_l1_ = str(l1llll_l1_)
	l111ll1l_l1_ = [l1l111_l1_ (u"ࠩ࠱ࡾ࡮ࡶ࠿ࠨ཮"),l1l111_l1_ (u"ࠪ࠲ࡷࡧࡲࡀࠩ཯"),l1l111_l1_ (u"ࠫ࠳ࡺࡸࡵࡁࠪ཰"),l1l111_l1_ (u"ࠬ࠴ࡰࡥࡨࡂཱࠫ"),l1l111_l1_ (u"࠭࠮ࡵࡣࡵࡃིࠬ"),l1l111_l1_ (u"ࠧ࠯࡫ࡶࡳࡄཱི࠭"),l1l111_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠴ུࠧ"),l1l111_l1_ (u"ࠩ࠱ࡶࡦࡸ࠮ࠨཱུ"),l1l111_l1_ (u"ࠪ࠲ࡹࡾࡴ࠯ࠩྲྀ"),l1l111_l1_ (u"ࠫ࠳ࡶࡤࡧ࠰ࠪཷ"),l1l111_l1_ (u"ࠬ࠴ࡴࡢࡴ࠱ࠫླྀ"),l1l111_l1_ (u"࠭࠮ࡪࡵࡲ࠲ࠬཹ")]
	if any(value in l1l11l11l_l1_ for value in l111ll1l_l1_):
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨེ"),l1l111_l1_ (u"ࠨཻࠩ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะོࠬ"),l1l111_l1_ (u"ࠪะึฮࠠาษห฻๋ࠥฮหๆไࠤ้ษๆ้ࠡำหࠥอไาษห฻๊๊ࠥิ่๊ࠢࠥ์ฺ่ࠢส่ึ๎วษูࠣห้ะ๊ࠡใํ๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠๅล้ࠤ์ึวࠡษ็้ํู่ࠡใํ๋ࠥิฯๆษอࠤศิั๊ࠢ฽๎ึࠦๅๅใสฮࠥอไโ์า๎ํཽ࠭"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪཾ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧཿ"),l1l111_l1_ (u"࠭ࠫࠨྀ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨ࡬ࡲࡩ࠵࠿ࡧ࡫ࡱࡨࡂཱྀ࠭")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨྂ"))
	return
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠩࡂࡃࠬྃ") in url: url = url.split(l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀ྄ࠩ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ྅"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭྆"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧ྇"),l1l111_l1_ (u"ࠧࠨྈ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬྉ"))
	if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ྊ"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠪࡁࡂ࠭ྋ") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠫࡂࡃࠧྌ") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨྍ")+category+l1l111_l1_ (u"࠭࠽࠾࠲ࠪྎ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪྏ")+category+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬྐ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬྑ"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧྒ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧྒྷ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨྔ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬྕ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨྖ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪྗ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ྘"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ྙ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬྚ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫྛ")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ྜ"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪྜྷ"),l1111111_l1_,251,l1l111_l1_ (u"ࠨࠩྞ"),l1l111_l1_ (u"ࠩࠪྟ"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫྠ"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྡ"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬྡྷ")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬྣ"),l1111111_l1_,251,l1l111_l1_ (u"ࠧࠨྤ"),l1l111_l1_ (u"ࠨࠩྥ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪྦ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨྦྷ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫྨ"),l1l111_l1_ (u"ࠬ࠭ྩ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫྪ"),url,l1l111_l1_ (u"ࠧࠨྫ"),headers,l1l111_l1_ (u"ࠨࠩྫྷ"),l1l111_l1_ (u"ࠩࠪྭ"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨྮ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀ࡙ࠦࡧࡸࡑࡣࡪࡩࡋ࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡗࡩࡷࡳࡂࡕࡐࡶࠦࠬྯ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l1l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡚ࠧࡡࡹࡒࡤ࡫ࡪࡌࡩ࡭ࡶࡨࡶࡎࡺࡥ࡮ࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧྰ"),block,re.DOTALL)
	l1l1l111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡒࡢࡶ࡬ࡲ࡬ࡌࡩ࡭ࡶࡨࡶࠧ࠴ࠪࡀ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿࠰࠭ࡃ࠭ࡂࡵ࡭ࡀࠬࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧྱ"),block,re.DOTALL)
	l1l11l1l_l1_ = l1l1l1l11_l1_+l1l1l111l_l1_
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨྲ"),block,re.DOTALL)
		if name==l1l111_l1_ (u"ࠨษัี๎࠭ླ"): name = l1l111_l1_ (u"ࠩส่ฬ่ำศ็ࠪྴ")
		if not items:
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡴࡤࡸࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪྵ"),block,re.DOTALL)
			items = []
			for option,value in l1l1111_l1_: items.append([option,l1l111_l1_ (u"ࠫࠬྶ"),value])
			l1l111ll_l1_ = l1l111_l1_ (u"ࠬࡸࡡࡵࡧࠪྷ")
			name = l1l111_l1_ (u"࠭วๅฬๅ๎๏๋ࠧྸ")
		else: l1l111ll_l1_ = items[0][1]
		if l1l111_l1_ (u"ࠧ࠾࠿ࠪྐྵ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬྺ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩྻ")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྼ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ྽"),l1111111_l1_,251,l1l111_l1_ (u"ࠬ࠭྾"),l1l111_l1_ (u"࠭ࠧ྿"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ࿀"))
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿁"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ࿂"),l1lllll1_l1_,254,l1l111_l1_ (u"ࠪࠫ࿃"),l1l111_l1_ (u"ࠫࠬ࿄"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭࿅"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࿆࠭ࠦࠧࠩ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ࿇")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ࿈")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭࿉")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ࿊")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿋"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ࿌")+name,l1lllll1_l1_,255,l1l111_l1_ (u"࠭ࠧ࿍"),l1l111_l1_ (u"ࠧࠨ࿎"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for option,dummy,value in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠨษ็็้࠭࿏") in option: continue
			option = unescapeHTML(option)
			l1l11l1ll_l1_,l1lllllll_l1_ = option,option
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠩ࠽ࠤࠬ࿐")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭࿑")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃࠧ࿒")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ࿓")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩ࿔")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ࿕")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ࿖"):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿗"),l1lllll_l1_+l1lllllll_l1_,url,255,l1l111_l1_ (u"ࠪࠫ࿘"),l1l111_l1_ (u"ࠫࠬ࿙"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ࿚") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"࠭࠽࠾ࠩ࿛") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ࿜"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ࿝")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿞"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,251,l1l111_l1_ (u"ࠪࠫ࿟"),l1l111_l1_ (u"ࠫࠬ࿠"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭࿡"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࿢"),l1lllll_l1_+l1lllllll_l1_,url,254,l1l111_l1_ (u"ࠧࠨ࿣"),l1l111_l1_ (u"ࠨࠩ࿤"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ࿥"),l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ࿦"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ࿧")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ࿨"),l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ࿩"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭࿪"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ࿫"),l1l111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ࿬"),l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ࿭"),l1l111_l1_ (u"ࠫࡷࡧࡴࡦࠩ࿮")]
def l1l1l11l1_l1_(url):
	l1l111l1l_l1_ = l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉࡱࡹࡨࡢ࡫࡮࡬࠷࠶࠲࠲࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡋࡳࡲ࡫࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡋࡳࡲ࡫࠮ࡱࡪࡳࠫ࿯")
	url = url.replace(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࿰"),l1l111l1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ࿱"),l1l111_l1_ (u"ࠨࠩ࿲"))
	if l1l111l1l_l1_ not in url: url = url+l1l111l1l_l1_
	url = url.replace(l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ࿳"),l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨ࿴"))
	url = url.replace(l1l111_l1_ (u"ࠫࡄࡅࠧ࿵"),l1l111_l1_ (u"ࠬࡅࠧ࿶"))
	url = url.replace(l1l111_l1_ (u"࠭ࠦࠧࠩ࿷"),l1l111_l1_ (u"ࠧࠧࠩ࿸"))
	url = url.replace(l1l111_l1_ (u"ࠨ࠿ࡀࠫ࿹"),l1l111_l1_ (u"ࠩࡀࠫ࿺"))
	return url
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭࿻"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠫࠬ࿼")
	if l1l111_l1_ (u"ࠬࡃ࠽ࠨ࿽") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠧࠩ࿾"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾࠿ࠪ࿿"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪက")
		if l1l111_l1_ (u"ࠩࠨࠫခ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬဂ") and value!=l1l111_l1_ (u"ࠫ࠵࠭ဃ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩင")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩစ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩဆ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫဇ")+key+l1l111_l1_ (u"ࠩࡀࡁࠬဈ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧဉ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧည")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨဋ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪဌ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪဍ"))
	return l1l1l111_l1_
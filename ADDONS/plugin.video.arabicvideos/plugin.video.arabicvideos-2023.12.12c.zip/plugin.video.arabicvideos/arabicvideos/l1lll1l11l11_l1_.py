# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ䏵")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䏶"):l1l111_l1_ (u"ࠫࠬ䏷")}
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫ䏸")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ䏹"),l1l111_l1_ (u"ࠧࡸࡹࡨࠫ䏺")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ䏻")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭䏼")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䏽"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䏾"),l111l1_l1_,369,l1l111_l1_ (u"ࠬ࠭䏿"),l1l111_l1_ (u"࠭ࠧ䐀"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䐁"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐂"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ䐃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䐄"),364)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐅"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ䐆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䐇"),365)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䐈"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐉"),l1l111_l1_ (u"ࠩࠪ䐊"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䐋"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䐌"),l1l111_l1_ (u"ࠬ࠭䐍"),l1l111_l1_ (u"࠭ࠧ䐎"),l1l111_l1_ (u"ࠧࠨ䐏"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ䐐"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡒࡵࡳࡩࡻࡣࡵ࡫ࡲࡲࡸࡒࡩࡴࡶࡅࡹࡹࡺ࡯࡯ࠤࠪ䐑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䐒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠫࠬ䐓"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐔"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䐕")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䐖"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐗"),l1l111_l1_ (u"ࠩࠪ䐘"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩࠬ䐙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䐚"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐛"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䐜")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䐝"),url,l1l111_l1_ (u"ࠨࠩ䐞"),l1l111_l1_ (u"ࠩࠪ䐟"),l1l111_l1_ (u"ࠪࠫ䐠"),l1l111_l1_ (u"ࠫࠬ䐡"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䐢"))
	html = response.content
	if l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠭䐣") in html:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐤"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ䐥"),url,361,l1l111_l1_ (u"ࠩࠪ䐦"),l1l111_l1_ (u"ࠪࠫ䐧"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䐨"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭䐩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐪"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐫"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1lll1lll11l_l1_,type=l1l111_l1_ (u"ࠨࠩ䐬")):
	if l1l111_l1_ (u"ࠩ࠽࠾ࠬ䐭") in l1lll1lll11l_l1_:
		l1llllll_l1_,url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠪ࠾࠿࠭䐮"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䐯"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1lll11l_l1_,l1lll1lll11l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䐰"),url,l1l111_l1_ (u"࠭ࠧ䐱"),l1l111_l1_ (u"ࠧࠨ䐲"),l1l111_l1_ (u"ࠨࠩ䐳"),l1l111_l1_ (u"ࠩࠪ䐴"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䐵"))
	html = response.content
	if type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䐶"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠩ䐷"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䐸"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠧ࡝࡞࠲ࠫ䐹"),l1l111_l1_ (u"ࠨ࠱ࠪ䐺")).replace(l1l111_l1_ (u"ࠩ࡟ࡠࠧ࠭䐻"),l1l111_l1_ (u"ࠪࠦࠬ䐼"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡌࡸࡩࡥ࠯࠰ࡑࡾࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ䐽"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ䐾"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ䐿"),l1l111_l1_ (u"ࠧࠨ䑀"))
			if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ䑁") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑂"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠪั้่ษࠨ䑃") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠯า๊โสࠢ࠮ࡠࡩ࠱ࠧ䑄"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䑅") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑆"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䑇"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䑈"):
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ䑉"),block,re.DOTALL)
			if l111l1lll1_l1_:
				count = l111l1lll1_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ䑊")+count
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑋"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ䑌"),l1ll1ll_l1_,361,l1l111_l1_ (u"࠭ࠧ䑍"),l1l111_l1_ (u"ࠧࠨ䑎"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䑏"))
		elif type==l1l111_l1_ (u"ࠩࠪ䑐"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䑑"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䑒"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䑓")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑔"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ䑕")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䑖"),url,l1l111_l1_ (u"ࠩࠪ䑗"),l1l111_l1_ (u"ࠪࠫ䑘"),l1l111_l1_ (u"ࠫࠬ䑙"),l1l111_l1_ (u"ࠬ࠭䑚"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䑛"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥ࡭ࡹ࡫࡭ࠣࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠮࠮ࠫࡁࠬࠦࠬ䑜"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠨ࠯ࠪ䑝"),l1l111_l1_ (u"ࠩࠣࠫ䑞")).strip(l1l111_l1_ (u"ࠪ࠳ࠬ䑟"))
	if l1l111_l1_ (u"๊ࠫ๎ำๆࠩ䑠") in name and type==l1l111_l1_ (u"ࠬ࠭䑡"):
		name = name.split(l1l111_l1_ (u"࠭ๅ้ี่ࠫ䑢"))[0]
		name = name.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ䑣"),l1l111_l1_ (u"ࠨࠩ䑤")).strip(l1l111_l1_ (u"ࠩࠣࠫ䑥"))
	elif l1l111_l1_ (u"ࠪั้่ษࠨ䑦") in name:
		name = name.split(l1l111_l1_ (u"ࠫา๊โสࠩ䑧"))[0]
		name = name.replace(l1l111_l1_ (u"๋ࠬิศ้าอࠬ䑨"),l1l111_l1_ (u"࠭ࠧ䑩")).strip(l1l111_l1_ (u"ࠧࠡࠩ䑪"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡩ࡯ࡩ࡯ࡩࡸ࡫ࡣࡵ࡫ࡲࡲࠬ䑫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠩࠪ䑬"):
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ䑭"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࠪ䑮") in title: continue
				if l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭䑯") in title: continue
				title = name+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ䑰")+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑱"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠨࠩ䑲"),l1l111_l1_ (u"ࠩࠪ䑳"),l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䑴"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡊࡶࡩࡴࡱࡧࡩࡸ࠳࠭ࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠩࠪࠬ䑵"),block+l1l111_l1_ (u"ࠬࠬࠦࠨ䑶"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡳ࡭ࡸࡵࡤࡦࡖ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䑷"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䑸"))
				title = name+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䑹")+title
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䑺"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䑻"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠫࠥ࠳ࠠๆษํࠤุ๐ๅศࠩ䑼"),l1l111_l1_ (u"ࠬ࠭䑽")).replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ䑾"),l1l111_l1_ (u"ࠧࠨ䑿"))
		else: title = l1l111_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭䒀")
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䒁"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䒂"),url,l1l111_l1_ (u"ࠫࠬ䒃"),l1l111_l1_ (u"ࠬ࠭䒄"),l1l111_l1_ (u"࠭ࠧ䒅"),l1l111_l1_ (u"ࠧࠨ䒆"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䒇"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ษ็ฮฺ์๊โ࠾࠱࠮ࡄࡂࡡ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䒈"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡈࡱࡧ࡫ࡤࠣࠩ䒉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䒊"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䒋") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"࠭ำ๋ำไี๋ࠥว๋ࠢึ๎๊อࠧ䒌"): name = l1l111_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ䒍")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䒎")+name+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䒏")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡹࡴ࠮࠯ࡇࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䒐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䒑"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䒒") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ䒓"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬ䒔")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䒕")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡰࡽࡨ࡯࡭ࡢࠩ䒖")+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䒗")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䒘"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠬ࠭䒙")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ䒚"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ䒛"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ䒜"),l1l111_l1_ (u"ࠩ࠮ࠫ䒝"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䒞"),l1l111_l1_ (u"ࠫ࠴࠭䒟"),l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ䒠"),l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ䒡"),l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ䒢")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠨษ็็้࠭䒣"),l1l111_l1_ (u"ࠩส่ศ็ไศ็ࠪ䒤"),l1l111_l1_ (u"ࠪห้๋ำๅี็หฯ࠭䒥"),l1l111_l1_ (u"ࠫฬ๊ว็์่๎ࠥ๎ࠠศๆๆีฯ๎ๆࠨ䒦"),l1l111_l1_ (u"ࠬอไษำส้ัࠦสๅ์ไึ๏๎ๆ๋หࠪ䒧")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ䒨"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠧࠨ䒩"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䒪"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ䒫"),l1l111_l1_ (u"ࠪࠫ䒬"),False,l1l111_l1_ (u"ࠫࠬ䒭"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䒮"))
		hostname = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䒯")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠧ࠰ࠩ䒰"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ䒱")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1lll11l_l1_,filter):
	if l1l111_l1_ (u"ࠩࡂࡃࠬ䒲") in l1lll1lll11l_l1_: url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䒳"))[0]
	else: url = l1lll1lll11l_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䒴"),l1l111_l1_ (u"ࠬ࠭䒵"))
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ䒶"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ䒷"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ䒸"),l1l111_l1_ (u"ࠩࠪ䒹")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ䒺"))
	if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䒻"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䒼") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"࠭࠽࠾ࠩ䒽") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䒾")+category+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䒿")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䓀")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ䓁")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ䓂"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䓃")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ䓄"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䓅"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䓆")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ䓇"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ䓈"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ䓉"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䓊"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ䓋"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䓌")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓍"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ䓎"),l1111111_l1_,361,l1l111_l1_ (u"ࠪࠫ䓏"),l1l111_l1_ (u"ࠫࠬ䓐"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓑"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓒"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ䓓")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ䓔"),l1111111_l1_,361,l1l111_l1_ (u"ࠩࠪ䓕"),l1l111_l1_ (u"ࠪࠫ䓖"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䓗"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓘"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓙"),l1l111_l1_ (u"ࠧࠨ䓚"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䓛"),url,l1l111_l1_ (u"ࠩࠪ䓜"),l1l111_l1_ (u"ࠪࠫ䓝"),l1l111_l1_ (u"ࠫࠬ䓞"),l1l111_l1_ (u"ࠬ࠭䓟"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䓠"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ䓡"),l1l111_l1_ (u"ࠨࠤࠪ䓢")).replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭䓣"),l1l111_l1_ (u"ࠪ࠳ࠬ䓤"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ䓥"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ䓦"),block+l1l111_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ䓧"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ䓨") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ䓩"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠩࡀࡁࠬ䓪") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䓫"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䓬")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓭"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭䓮"),l1111111_l1_,361,l1l111_l1_ (u"ࠧࠨ䓯"),l1l111_l1_ (u"ࠨࠩ䓰"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䓱"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓲"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ䓳"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠬ࠭䓴"),l1l111_l1_ (u"࠭ࠧ䓵"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䓶"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䓷")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭䓸")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䓹")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ䓺")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䓻")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓼"),l1lllll_l1_+name+l1l111_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ䓽"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠨࠩ䓾"),l1l111_l1_ (u"ࠩࠪ䓿"),l1l111l1_l1_+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䔀"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠫࡷ࠭䔁") or value==l1l111_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ䔂"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䔃") in option: continue
			if l1l111_l1_ (u"ࠧศๆๆ่ࠬ䔄") in option: continue
			if l1l111_l1_ (u"ࠨࡰ࠰ࡥࠬ䔅") in value: continue
			if option==l1l111_l1_ (u"ࠩࠪ䔆"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ䔇"),option,re.DOTALL)
			if l1ll1l11l11_l1_: l1l11l1ll_l1_ = l1ll1l11l11_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠫ࠿ࠦࠧ䔈")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䔉")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩ䔊")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䔋")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔌")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭䔍")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䔎"):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔏"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠬ࠭䔐"),l1l111_l1_ (u"࠭ࠧ䔑"),l1l1l11l_l1_+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䔒"))
			elif type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䔓") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠩࡀࡁࠬ䔔") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䔕"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䔖")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1lll11l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔗"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"࠭ࠧ䔘"),l1l111_l1_ (u"ࠧࠨ䔙"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䔚"))
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔛"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"ࠪࠫ䔜"),l1l111_l1_ (u"ࠫࠬ䔝"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ䔞"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䔟"),l1l111_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ䔠")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭䔡"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ䔢"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䔣"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭䔤"),l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭䔥"),l1l111_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ䔦"),l1l111_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ䔧"),l1l111_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ䔨")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䔩") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䔪"),l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ䔫"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䔬"),l1l111_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ䔭"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔮"),l1l111_l1_ (u"ࠨ࠱ࠪ䔯"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩࠩࠪࠬ䔰"),l1l111_l1_ (u"ࠪ࠳ࠬ䔱"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ䔲"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠬ࠭䔳")
	if l1l111_l1_ (u"࠭࠽࠾ࠩ䔴") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠨࠪ䔵"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔶"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫ䔷")
		if l1l111_l1_ (u"ࠪࠩࠬ䔸") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䔹") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ䔺"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ䔻")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䔼") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ䔽"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䔾")+key+l1l111_l1_ (u"ࠪࡁࡂ࠭䔿")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ䕀"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䕁")+key+l1l111_l1_ (u"࠭࠽࠾ࠩ䕂")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ䕃"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ䕄"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ屻")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ屼")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111ll1l11l1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l111ll1l1111_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l111llll11l1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l111lll111ll_l1_()
	elif mode==148: l1lll_l1_ = l111lll11l1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屽"),l1lllll_l1_+l1l111_l1_ (u"ࠫ็อฦๆหࠪ屾"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࡐࡍࡃ࡭࠹ࡌࡹ࠸ࡇࡊ࠻࡞ࡳ࡛ࡢࡇ࠲ࡕ࡚࠲࠽ࡇ࠴ࡄࡲࡵࡎࡿ࡚ࡂ࠶ࡸࡗࡆ࠭屿"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岀"),l1lllll_l1_+l1l111_l1_ (u"ࠧีะุࠫ岁"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࡕࡅࡑࡳ࡫࡬ࡩࡤ࡫ࡤࡰࠬ岂"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岃"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํู่ࠨ岄"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࡕࡄࡳ࠸࠽ࡦࡍࡎࡴࡳ࠼ࡦࡧ࡮ࡷࡗࡖࡴ࠵࡚ࡺࡶࡨࡹࠪ岅"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岆"),l1lllll_l1_+l1l111_l1_ (u"࠭อิษหࠫ岇"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡂࡗ࡬ࡪ࡙࡯ࡤ࡫ࡤࡰࡈ࡚ࡖࠨ岈"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岉"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่฾อศࠨ岊"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ岋"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岌"),l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠫ岍"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ岎"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岏"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ัฮฬืวหࠩ岐"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ岑"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岒"),l1lllll_l1_+l1l111_l1_ (u"ࠫ็฻๊าหࠪ岓"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭岔"),144,l1l111_l1_ (u"࠭ࠧ岕"),l1l111_l1_ (u"ࠧࠨ岖"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ岗"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岘"),l1lllll_l1_+l1l111_l1_ (u"ࠪฮฺ็อࠨ岙"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ岚"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岛"),l1lllll_l1_+l1l111_l1_ (u"࠭ัว์ึ๎ฮ࠭岜"),l111l1_l1_+l1l111_l1_ (u"ࠧࠨ岝"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岞"),l1lllll_l1_+l1l111_l1_ (u"ࠩิหหาࠧ岟"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࡃࡧࡶ࠽ࠨ岠"),144)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ岡"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ岢"),l1l111_l1_ (u"࠭ࠧ岣"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岤"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ岥"),l1l111_l1_ (u"ࠩࠪ岦"),149,l1l111_l1_ (u"ࠪࠫ岧"),l1l111_l1_ (u"ࠫࠬ岨"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ岩"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ岪"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ岫"),l1l111_l1_ (u"ࠨࠩ岬"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岭"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ岮"),l111l1_l1_+l1l111_l1_ (u"ࠫࠬ岯"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岰"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅำสสัฯࠧ岱"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ岲"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岳"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ฯ฻แฮࠩ岴"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭岵"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岶"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไใืํีฮ࠭岷"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ岸"),144,l1l111_l1_ (u"ࠧࠨ岹"),l1l111_l1_ (u"ࠨࠩ岺"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭岻"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岼"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫิสศำสฮࠥ๐่ห์๋ฬࠬ岽"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ岾"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岿"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆะอหึอสࠡษ็ฬึ์วๆฮࠪ峀"),l1l111_l1_ (u"ࠨࠩ峁"),290)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ峂"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ峃"),l1l111_l1_ (u"ࠫࠬ峄"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峅"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ峆"),l1l111_l1_ (u"ࠧࠨ峇"),147)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峈"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯࠦรอ่ห๎ฮ࠭峉"),l1l111_l1_ (u"ࠪࠫ峊"),148)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峋"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ峌"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ峍"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峎"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ峏"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ峐"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峑"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ峒"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭峓"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峔"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯูࠦาสํอࠬ峕"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืู้ไࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭峖"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峗"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ峘"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ峙"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峚"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ峛"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭峜"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峝"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ峞"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭ๆีอ๊วย࠭ส่ๆ฼วว์ฬ࠯ำ฽ศส࠭ส่ัู๋สࠨࡶࡴࡂࡉࡁࡊࡕࡄ࡬ࡆࡈࠧ峟"),144)
	return
def l111ll1l1111_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峠"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡉࡈࡏࡎ࠽ࠤࠥ࠭峡")+name,url,144,l11l_l1_)
	return
def l111lll111ll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭峢"))
	return
def l111lll11l1l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ峣"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠨࠨࠪ峤"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111ll1lll11_l1_(yccc,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ峥"))
	l111ll11lll1_l1_,l111ll1lll1l_l1_ = [],[]
	if l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ峦") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟ࠥ峧"))
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ峨") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡆࡳࡲࡳࡡ࡯ࡦࡶࠫࡢࠨ峩"))
	if level==l1l111_l1_ (u"ࠧ࠲ࠩ峪"): l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ峫"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峬"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࠨ峭"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡩࡳࡺࡲࡪࡧࡶࠫࡢࠨ峮"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࡠ࠹࡝࡜ࠩࡪࡹ࡮ࡪࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ峯"))
	l111lll1l111_l1_,yddd,l111ll1ll1ll_l1_ = l111ll11ll11_l1_(yccc,l1l111_l1_ (u"࠭ࠧ峰"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"ࠧ࠲ࠩ峱") and l111lll1l111_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ峲") not in url:
			for zz in range(len(yddd)):
				l111ll1l1l1l_l1_ = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ峳")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ峴"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ峵")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ島"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ峷")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠢ࡞ࠤ峸"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠨࠩ峹"),l111ll11lll1_l1_)
				if succeeded: l111ll1lll1l_l1_.append([item,url,l1l111_l1_ (u"ࠩ࠵࠾࠿࠭峺")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ峻")])
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࠧ峼"))
			succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yccc,l1l111_l1_ (u"ࠬ࠭峽"),l111ll11lll1_l1_)
			if succeeded and l111ll1lll1l_l1_ and l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ峾") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ峿")
				l111ll1lll1l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ崀")])
	return yddd,l111lll1l111_l1_,l111ll1lll1l_l1_,l111ll1ll1ll_l1_
def l111ll11l11l_l1_(yccc,yddd,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ崁"))
	l111ll11lll1_l1_,l111ll1llll1_l1_ = [],[]
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崂"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崃")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ崄"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠶ࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ崅"))
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪ࠭崆") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ崇"))
	elif l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ崈") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崉"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崊")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崋"))
	if l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ崌") in url or (l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ崍") in url and l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ崎") not in url):
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崏")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崐"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崑")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崒"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崓")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡤࡦࡱ࡫ࡔࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崔"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ崕")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ崖"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ崗")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠦࡢࠨ崘"))
	l111lll11ll1_l1_,yeee,l111ll1ll1l1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠬ࠭崙"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"࠭࠲ࠨ崚") and l111lll11ll1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崛")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ崜"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崝")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ崞"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崟")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ崠"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崡")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ崢"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崣")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ崤"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崥")+index2+l1l111_l1_ (u"ࠦࡢࠨ崦"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yeee,l1l111_l1_ (u"ࠬ࠭崧"),l111ll11lll1_l1_)
				if succeeded: l111ll1llll1_l1_.append([item,url,l1l111_l1_ (u"࠭࠳࠻࠼ࠪ崨")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ崩")+index2+l1l111_l1_ (u"ࠨ࠼࠽࠴ࠬ崪")])
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠳ࡠࠦ崫"))
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠳ࡠࠦ崬"))
			succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠫࠬ崭"),l111ll11lll1_l1_)
			if succeeded and l111ll1llll1_l1_ and l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ崮") in list(item.keys()):
				l111ll1llll1_l1_.append([item,url,l1l111_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ崯")])
	return yeee,l111lll11ll1_l1_,l111ll1llll1_l1_,l111ll1ll1l1_l1_
def l111ll1l111l_l1_(yccc,yeee,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ崰"))
	l111ll11lll1_l1_,l111ll1l11ll_l1_ = [],[]
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崱")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡼࡥࡳࡶ࡬ࡧࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崲"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崳")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崴"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崵")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡸࡥࡦ࡮ࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崶"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崷")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崸"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崹")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崺"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崻")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崼"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崽")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ崾"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崿")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嵀"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嵁"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ嵂"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嵃"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嵄")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嵅"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嵆")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嵇"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥࠣ嵈"))
	l111lll1l1l1_l1_,yfff,l111llll1l11_l1_ = l111ll11ll11_l1_(yeee,l1l111_l1_ (u"ࠫࠬ嵉"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"ࠬ࠹ࠧ嵊") and l111lll1l1l1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l111ll1l1lll_l1_ = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡧࡨࡩ࡟ࠧ嵋")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ嵌"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ嵍")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ嵎"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ嵏")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ嵐"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ嵑")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠨ࡝ࠣ嵒"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yfff,l1l111_l1_ (u"ࠧࠨ嵓"),l111ll11lll1_l1_)
				if succeeded: l111ll1l11ll_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠶࠽࠾ࠬ嵔")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵕")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嵖")+l111ll1l1lll_l1_])
	return yfff,l111lll1l1l1_l1_,l111ll1l11ll_l1_,l111llll1l11_l1_
def l111ll11ll11_l1_(l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l111ll1l1l11_l1_):
	yccc,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yddd,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yeee,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yfff,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	item,yrender = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	count = len(l111ll1l1l11_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll1l1l11_l1_[l1l11l111l_l1_])
			return True,out,l1l11l111l_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠫࠬ嵗"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠬ࠭嵘"),data=l1l111_l1_ (u"࠭ࠧ嵙")):
	l111ll1lll1l_l1_,l111ll1llll1_l1_,l111ll1l11ll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵚") not in index: index = l1l111_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ嵛")
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵜"))
	if level==l1l111_l1_ (u"ࠪ࠸ࠬ嵝"): level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠫ࠶࠭嵞"),l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_
	data = data.replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ嵟"),l1l111_l1_ (u"࠭ࠧ嵠"))
	html,yccc,l1l11llll_l1_ = l111ll1lllll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵡")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵢")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵣")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠪ࠵ࠬ嵤"),l1l111_l1_ (u"ࠫ࠷࠭嵥"),l1l111_l1_ (u"ࠬ࠹ࠧ嵦")]:
		yddd,l111lll1l111_l1_,l111ll1lll1l_l1_,l111ll1ll1ll_l1_ = l111ll1lll11_l1_(yccc,url,index)
		if not l111lll1l111_l1_: return
		l1lllll111_l1_ = len(l111ll1lll1l_l1_)
		if l1lllll111_l1_<2:
			if level==l1l111_l1_ (u"࠭࠱ࠨ嵧"): level = l1l111_l1_ (u"ࠧ࠳ࠩ嵨")
			l111ll1lll1l_l1_ = []
	index = level+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵩")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵪")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嵫")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠫ࠷࠭嵬"),l1l111_l1_ (u"ࠬ࠹ࠧ嵭")]:
		yeee,l111lll11ll1_l1_,l111ll1llll1_l1_,l111ll1ll1l1_l1_ = l111ll11l11l_l1_(yccc,yddd,url,index)
		if not l111lll11ll1_l1_: return
		l1ll1l1l11_l1_ = len(l111ll1llll1_l1_)
		if l1ll1l1l11_l1_<2:
			if level==l1l111_l1_ (u"࠭࠲ࠨ嵮"): level = l1l111_l1_ (u"ࠧ࠴ࠩ嵯")
			l111ll1llll1_l1_ = []
	index = level+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵰")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵱")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嵲")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠫ࠸࠭嵳")]:
		yfff,l111lll1l1l1_l1_,l111ll1l11ll_l1_,l111llll1l11_l1_ = l111ll1l111l_l1_(yccc,yeee,url,index)
		if not l111lll1l1l1_l1_: return
		l1ll1l1l1l_l1_ = len(l111ll1l11ll_l1_)
	for item,url,index in l111ll1lll1l_l1_+l111ll1llll1_l1_+l111ll1l11ll_l1_:
		l1ll11l1ll1l_l1_ = l111ll11llll_l1_(item,url,index)
	return
def l111ll11llll_l1_(item,url=l1l111_l1_ (u"ࠬ࠭嵴"),index=l1l111_l1_ (u"࠭ࠧ嵵")):
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵶") in index: level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵷"))
	else: level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ嵸"),l1l111_l1_ (u"ࠪ࠴ࠬ嵹"),l1l111_l1_ (u"ࠫ࠵࠭嵺"),l1l111_l1_ (u"ࠬ࠶ࠧ嵻")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,l111llll111l_l1_ = l111llll1ll1_l1_(item)
	l1llll11ll11_l1_ = l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠿ࠨ嵼") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡵࡷࡶࡪࡧ࡭ࡴࡁࠪ嵽") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࡄ࠭嵾") in l1ll1ll_l1_
	l1llll11l1l1_l1_ = l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࡄ࠭嵿") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࡃࠬ嶀") in l1ll1ll_l1_
	if l1llll11ll11_l1_ or l1llll11l1l1_l1_: l1ll1ll_l1_ = url
	l1llll11ll11_l1_ = l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭嶁") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ嶂") not in l1ll1ll_l1_
	l1llll11l1l1_l1_ = l1l111_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ嶃") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡳࡵࡱࡵࡩ࡫ࡸ࡯࡯ࡶࠪ嶄") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺ࠨ嶅") and l1llll11ll11_l1_ and l1llll11l1l1_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ嶆") in url or l1l111_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ嶇") in l1ll1ll_l1_:
		level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠫ࠶࠭嶈"),l1l111_l1_ (u"ࠬ࠶ࠧ嶉"),l1l111_l1_ (u"࠭࠰ࠨ嶊"),l1l111_l1_ (u"ࠧ࠱ࠩ嶋")
		index = l1l111_l1_ (u"ࠨࠩ嶌")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠩࠪ嶍")
	if l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ嶎") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ嶏") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ嶐") in url:
		data = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ嶑"))
		if data.count(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嶒"))==4:
			l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = data.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ嶓"))
			l1l11llll_l1_ = l111lll1l11l_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭嶔")+key+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ嶕")+l111lll11l11_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ嶖")+l111lll1111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ嶗")+l111llll111l_l1_
			if l1l111_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ嶘") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀ࡭ࡨࡽࡂ࠭嶙")+key
	if not title:
		global l111ll1l11l1_l1_
		l111ll1l11l1_l1_ += 1
		title = l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣࠫ嶚")+str(l111ll1l11l1_l1_)
		index = l1l111_l1_ (u"ࠩ࠶ࠫ嶛")+l1l111_l1_ (u"ࠪ࠾࠿࠭嶜")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶝")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶞")+l111ll1l1lll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡖࡹࡷࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嶟") in str(item): return False
	elif l1l111_l1_ (u"ࠧ࠰ࡣࡥࡳࡺࡺࠧ嶠") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠨ࠱ࡦࡳࡲࡳࡵ࡯࡫ࡷࡽࠬ嶡") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭嶢") in list(item.keys()) or l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩ嶣") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶤")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶥")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嶦")+l111ll1l1lll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶧"),l1lllll_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ嶨")+l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ嶩"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ嶪") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ嶫")+title
		index = l1l111_l1_ (u"ࠬ࠹ࠧ嶬")+l1l111_l1_ (u"࠭࠺࠻ࠩ嶭")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶮")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶯")+l111ll1l1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ嶰"),l1l111_l1_ (u"ࠪࠫ嶱"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嶲"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠬ࠭嶳"),index,l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ嶴"))
	elif l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭嶵") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠨ࠵ࠪ嶶")+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶷")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭嶸")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶹")+l111ll1l1lll_l1_
		title = l1l111_l1_ (u"ࠬࡀ࠺ࠡࠩ嶺")+title
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶻"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ嶼") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ嶽")+title
		index = l1l111_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭嶾")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶿"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ巀") in str(item):
		title = l1l111_l1_ (u"ࠬࡀ࠺ࠡࠩ巁")+title
		index = l1l111_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ巂")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巃"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ巄") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ巅"),l1lllll_l1_+title,l1l111_l1_ (u"ࠪࠫ巆"),9999)
	elif l111lll1l1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ巇"),l1lllll_l1_+l111lll1l1ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ巈") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巉"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬ巊")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ巋")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ巌") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ巍"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ巎"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ巏") in l1ll1ll_l1_:
		if l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭巐") in l1ll1ll_l1_ and count:
			l111lll11lll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ巑"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ巒")+l111lll11lll_l1_
			index = l1l111_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭巓")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ巔"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡑࡏࡓࡕࠩ巕")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ巖")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭巗"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭巘"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	elif l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ巙") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡧ࠴࠭巚") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠪ࠳ࡅ࠭巛") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠫ࠴࠭巜"))==3):
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ川"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫ州")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ巟")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࠨ巠") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巡"),l1lllll_l1_+l1l111_l1_ (u"࡙ࠪࡘࡋࡒࠨ巢")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ巣")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠬࡀ࠺ࠡࠩ巤")+title
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭工"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l111llll1ll1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token = False,l1l111_l1_ (u"ࠧࠨ左"),l1l111_l1_ (u"ࠨࠩ巧"),l1l111_l1_ (u"ࠩࠪ巨"),l1l111_l1_ (u"ࠪࠫ巩"),l1l111_l1_ (u"ࠫࠬ巪"),l1l111_l1_ (u"ࠬ࠭巫"),l1l111_l1_ (u"࠭ࠧ巬"),l1l111_l1_ (u"ࠧࠨ巭")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token
	for l111lll111l1_l1_ in list(item.keys()):
		yrender = item[l111lll111l1_l1_]
		if isinstance(yrender,dict): break
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡐ࡮ࡹࡴࡉࡧࡤࡨࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ差"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ巯"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦ࡯࡭ࡳ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ巰"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ己"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ已"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ巳"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ巴"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ巵"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ巶"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ巷"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ巸"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡷ࡫ࡥ࡭࡙ࡤࡸࡨ࡮ࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡻ࡯ࡤࡦࡱࡌࡨࠬࡣࠢ巹"))
	succeeded,title,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ巺"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ巻"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡧࡰࡪࡗࡵࡰࠬࡣࠢ巼"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ巽"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ巾"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ巿"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帀"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ币"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ市"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ布"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࠨ࡟ࠥ帄"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࡖࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ帅"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡇࡵࡴࡵࡱࡰࡔࡦࡴࡥ࡭ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ帆"))
	succeeded,count,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ帇"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ师"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡯ࡩࡳ࡭ࡴࡩࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ帉"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡧࡴࡴࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࡕࡻࡳࡩࠬࡣࠢ帊"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡷࡹࡿ࡬ࡦࠩࡠࠦ帋"))
	succeeded,l1l1lll1ll_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡶࡲ࡯ࡪࡴࠧ࡞ࠤ希"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ帍"))
	succeeded,token,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	if l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ帎") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ帏"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ帐")
	if l1l111_l1_ (u"ࠨ็หหูืࠧ帑") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ帒"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ帓")
	if l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ帔") in list(yrender.keys()):
		l111lll1llll_l1_ = str(yrender[l1l111_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ帕")])
		if l1l111_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭帖") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ帗")
		if l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭帘") in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ帙")
		if l1l111_l1_ (u"ࠪࡆࡺࡿࠧ帚") in l111lll1llll_l1_ or l1l111_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ帛") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ帜")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡻࠧๆสสุึ࠭帝")) in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ帞")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡶࠩืีฬวࠧ帟")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ帠")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡸࠫฬูสวฮสีࠬ帡")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ帢")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ帣")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ帤")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ帥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠨࡁࠪ带"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ帧") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ帨")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111lll11111_l1_: title = l111lll11111_l1_+title
	l1l1lll1ll_l1_ = l1l1lll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࠱࠭帩"),l1l111_l1_ (u"ࠬ࠭帪"))
	count = count.replace(l1l111_l1_ (u"࠭ࠬࠨ師"),l1l111_l1_ (u"ࠧࠨ帬"))
	count = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧ࠯ࠬ席"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠩࠪ帮")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token
def l111ll1lllll_l1_(url,data=l1l111_l1_ (u"ࠪࠫ帯"),request=l1l111_l1_ (u"ࠫࠬ帰")):
	if request==l1l111_l1_ (u"ࠬ࠭帱"): request = l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭帲")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ帳"):l11ll1l1l1_l1_,l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ帴"):l1l111_l1_ (u"ࠩࡓࡖࡊࡌ࠽ࡩ࡮ࡀࡥࡷ࠭帵")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ帶"))
	if data.count(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ帷"))==4: l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = data.split(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ常"))
	else: l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = l1l111_l1_ (u"࠭ࠧ帹"),l1l111_l1_ (u"ࠧࠨ帺"),l1l111_l1_ (u"ࠨࠩ帻"),l1l111_l1_ (u"ࠩࠪ帼"),l1l111_l1_ (u"ࠪࠫ帽")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠦࡨࡵ࡮ࡵࡧࡻࡸࠧ帾"):{l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࠧ帿"):{l1l111_l1_ (u"ࠨࡨ࡭ࠤ幀"):l1l111_l1_ (u"ࠢࡢࡴࠥ幁"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ幂"):l1l111_l1_ (u"ࠤ࡚ࡉࡇࠨ幃"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ幄"):l111lll11l11_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ幅") or l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ幆") in url:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡸࡥࡦ࡮࠲ࡶࡪ࡫࡬ࡠࡹࡤࡸࡨ࡮࡟ࡴࡧࡴࡹࡪࡴࡣࡦࠩ幇")+l1l111_l1_ (u"ࠧࡀ࡭ࡨࡽࡂ࠭幈")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࡓࡥࡷࡧ࡭ࡴࠩ幉")] = l111lll1l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ幊"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ幋"))
	elif l1l111_l1_ (u"ࠫ࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ幌") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ幍")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ幎"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ幏"))
	elif l1l111_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭幐") in url and l111lll1l11l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ幑")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ幒")][l1l111_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࠫ幓")][l1l111_l1_ (u"ࠬࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠪ幔")] = l111lll1l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ幕"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ幖"))
	elif l1l111_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ幗") in url and l111lll1111l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ幘"):l1l111_l1_ (u"ࠪ࠵ࠬ幙"),l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ幚"):l111lll11l11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ幛"):l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࡁࠬ幜")+l111lll1111l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ幝"),url,l1l111_l1_ (u"ࠨࠩ幞"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ幟"),l1l111_l1_ (u"ࠪࠫ幠"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠻ࡴࡩࠩ幡"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ幢"),url,l1l111_l1_ (u"࠭ࠧ幣"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ幤"),l1l111_l1_ (u"ࠨࠩ幥"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠺ࡹ࡮ࠧ幦"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ幧"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡶࡦࡴࠥ࠲࠯ࡅࠢࡷࡣ࡯ࡹࡪࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ幨"),html,re.DOTALL|re.I)
	if tmp: l111lll11l11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ幩"),html,re.DOTALL|re.I)
	if tmp: l111lll1l11l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ幪") in list(cookies.keys()): l111lll1111l_l1_ = cookies[l1l111_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ幫")]
	l1l1l1111_l1_ = l111lll1l11l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ幬")+key+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭幭")+l111lll11l11_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ幮")+l111lll1111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ幯")+token
	if request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ幰") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭幱") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡸ࡫ࡱࡨࡴࡽ࡜࡜ࠤࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠤ࡟ࡡࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ干"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ平"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭年"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ幵") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ并") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ幷"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ幸"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"ࠧ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ幹") not in html: l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ幺"),html)
	else: l111lll1lll1_l1_ = l1l111_l1_ (u"ࠩࠪ幻")
	if 0:
		yccc = str(l111lll1lll1_l1_)
		if kodi_version>18.99: yccc = yccc.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幼"))
		open(l1l111_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱ࡨࡦࡺࠧ幽"),l1l111_l1_ (u"ࠬࡽࡢࠨ幾")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ广"),l1l1l1111_l1_)
	return html,l111lll1lll1_l1_,l1l1l1111_l1_
def l111llll11l1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ庀"),l1l111_l1_ (u"ࠨ࠭ࠪ庁"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ庂")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ広"),l1l111_l1_ (u"ࠫ࠰࠭庄"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ庅")+search
	if not l11_l1_:
		if l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ庆") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ庇")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ庈") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ庉")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ床") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ庋")
		else: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠬ࠭庌")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1ll11l_l1_
	else:
		l111ll1ll111_l1_,l111ll11l1ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"࠭ࠧ庍")
		l111ll11ll1l_l1_ = [l1l111_l1_ (u"ࠧษั๋๊ࠥะัห์หࠫ庎"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ๊ี้ࠡษ็ู้ฯࠧ序"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥะวา์ัࠤฬ๊สฮ็ํ่ࠬ庐"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือูࠦะัࠣห้๋ิศ้าหฯ࠭庑"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠศๆอๆ๏๐ๅࠨ庒")]
		l111lll1ll1l_l1_ = [l1l111_l1_ (u"ࠬ࠭库"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡇࠥ࠳࠷࠶ࡈࠬ应"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡉࠦ࠴࠸࠷ࡉ࠭底"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡎࠧ࠵࠹࠸ࡊࠧ庖"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡇࠨ࠶࠺࠹ࡄࠨ店")]
		l111llll1111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ฮึะ๊ษࠩ庘"),l111ll11ll1l_l1_)
		if l111llll1111_l1_ == -1: return
		l111ll1l1ll1_l1_ = l111lll1ll1l_l1_[l111llll1111_l1_]
		html,c,data = l111ll1lllll_l1_(l1lllll1_l1_+l111ll1l1ll1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭庙")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ庚")][l1l111_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ庛")][l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭府")][l1l111_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ庝")][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ庞")][l1l111_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࡵࠪ废")]
				for l111ll11l1l1_l1_ in range(len(d)):
					group = d[l111ll11l1l1_l1_][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡊࡶࡴࡻࡰࡓࡧࡱࡨࡪࡸࡥࡳࠩ庠")][l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭庡")]
					for l111llll11ll_l1_ in range(len(group)):
						yrender = group[l111llll11ll_l1_][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭庢")]
						if l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ庣") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭庤")][l1l111_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ庥")][l1l111_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ度")][l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ座")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢࡵ࠱࠲࠵࠺ࠬ庨"),l1l111_l1_ (u"࠭ࠦࠨ庩"))
							title = yrender[l1l111_l1_ (u"ࠧࡵࡱࡲࡰࡹ࡯ࡰࠨ庪")]
							title = title.replace(l1l111_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣࠫ庫"),l1l111_l1_ (u"ࠩࠪ庬"))
							if l1l111_l1_ (u"ࠪษือไสࠢส่ๆ๊สาࠩ庭") in title: continue
							if l1l111_l1_ (u"ࠫ็อฦๆหࠣฮูเ๊ๅࠩ庮") in title:
								title = l1l111_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭庯")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠩ庰") in title: continue
							title = title.replace(l1l111_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠤࠬ庱"),l1l111_l1_ (u"ࠨࠩ庲"))
							if l1l111_l1_ (u"ࠩࡕࡩࡲࡵࡶࡦࠩ庳") in title: continue
							if l1l111_l1_ (u"ࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ庴") in title:
								title = l1l111_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ庵")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"࡙ࠬ࡯ࡳࡶࠣࡦࡾ࠭庶") in title: continue
							l111ll1ll111_l1_.append(escapeUNICODE(title))
							l111ll11l1ll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l111lll1ll11_l1_ = l1l111_l1_ (u"࠭ࠧ康")
		else:
			l111ll1ll111_l1_ = [l1l111_l1_ (u"ࠧษั๋๊ࠥ็ไหำࠪ庸"),l1lllllll_l1_]+l111ll1ll111_l1_
			l111ll11l1ll_l1_ = [l1l111_l1_ (u"ࠨࠩ庹"),l111lllll_l1_]+l111ll11l1ll_l1_
			l111llll1l1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆไ่ฯืࠧ庺"),l111ll1ll111_l1_)
			if l111llll1l1l_l1_ == -1: return
			l111lll1ll11_l1_ = l111ll11l1ll_l1_[l111llll1l1l_l1_]
		if l111lll1ll11_l1_: l1llllll_l1_ = l111l1_l1_+l111lll1ll11_l1_
		elif l111ll1l1ll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1ll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
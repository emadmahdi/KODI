# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ㮈")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㮉")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠴ࠬ㮊"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠶࠭㮋"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠸ࠧ㮌"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠳ࠨ㮍"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠵ࠩ㮎"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮏"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㮐")+l1l111_l1_ (u"ࠪๆํอฦๆࠢไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠨ㮑"),l1l111_l1_ (u"ࠫࠬ㮒"),762)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮓"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ㮔")+l1l111_l1_ (u"ࠧใ๊สส๊ࠦแ๋ัํ์์อสࠡࡋࡓࡘ࡛࠭㮕"),l1l111_l1_ (u"ࠨࠩ㮖"),761)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮗"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠰ࡠࠩ㮘")+l1l111_l1_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨ㮙"),l1l111_l1_ (u"ࠬ࠭㮚"),101)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮛"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠸ࡤ࠭㮜")+l1l111_l1_ (u"ࠨไ้์ฬะࠠๆะอหึฯࠠๆ่ࠣ๎ํะ๊้สࠪ㮝"),l1l111_l1_ (u"ࠩࠪ㮞"),106)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮟"),l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㮠")+l1l111_l1_ (u"่ࠬๆ้ษอࠤ฾ืศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㮡"),l1l111_l1_ (u"࠭ࠧ㮢"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮣"),l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ㮤")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡลฯ๊อ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㮥"),l1l111_l1_ (u"ࠪࠫ㮦"),148)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮧"),l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㮨")+l1l111_l1_ (u"࠭ࠠࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠣࠤࠬ㮩"),l1l111_l1_ (u"ࠧࠨ㮪"),28)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㮫"),l1l111_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨ㮬")+l1l111_l1_ (u"ࠪๆ๋อษࠡษ็้฾อัโ่๊๋่ࠢࠥใ฻๊้ࠬ㮭"),l1l111_l1_ (u"ࠫࠬ㮮"),41)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㮯"),l1l111_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ㮰")+l1l111_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ㮱"),l1l111_l1_ (u"ࠨࠩ㮲"),38)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㮳"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㮴"),l1l111_l1_ (u"ࠫࠬ㮵"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮶"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠴ࡣࠬ㮷")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ฼ห๊ฯࠧ㮸"),l1l111_l1_ (u"ࠨࠩ㮹"),102)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮺"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠲ࡠࠩ㮻")+l1l111_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦฮศืฬࠫ㮼"),l1l111_l1_ (u"ࠬ࠭㮽"),103)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮾"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠷ࡤ࠭㮿")+l1l111_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋ห่้ࠣ็อึࠩ㯀"),l1l111_l1_ (u"ࠩࠪ㯁"),104)
	return
def ITEMS(l1llll1ll1l_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡙࡜ࠧ㯂")+l1llll1ll1l_l1_+l1l111_l1_ (u"ࠫࡤ࠭㯃")
	user = l1l1ll1l11l_l1_(32)
	payload = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ㯄"):l1l111_l1_ (u"࠭ࠧ㯅"),l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㯆"):user,l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㯇"):l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㯈"),l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㯉"):l1llll1ll1l_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㯊"),l111l1_l1_,payload,l1l111_l1_ (u"ࠬ࠭㯋"),l1l111_l1_ (u"࠭ࠧ㯌"),l1l111_l1_ (u"ࠧࠨ㯍"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ㯎"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ㯏"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠪࡥࡱ࠭㯐"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯑"))
			start = start.replace(l1l111_l1_ (u"ࠬࡋ࡬ࠨ㯒"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯓"))
			start = start.replace(l1l111_l1_ (u"ࠧࡂࡎࠪ㯔"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㯕"))
			start = start.replace(l1l111_l1_ (u"ࠩࡈࡐࠬ㯖"),l1l111_l1_ (u"ࠪࡅࡱ࠭㯗"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠫࡆࡲ࠭ࠨ㯘"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㯙"))
			start = start.replace(l1l111_l1_ (u"࠭ࡁ࡭ࠢࠪ㯚"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯛"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l11l11_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠨࠥࠪ㯜") in source: continue
			if source!=l1l111_l1_ (u"ࠩࡘࡖࡑ࠭㯝"): name = name+l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠࠡࠩ㯞")+source+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㯟")
			url = source+l1l111_l1_ (u"ࠬࡁ࠻ࠨ㯠")+server+l1l111_l1_ (u"࠭࠻࠼ࠩ㯡")+l1l1l11l11_l1_+l1l111_l1_ (u"ࠧ࠼࠽ࠪ㯢")+l1llll1ll1l_l1_
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㯣"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠪ㯤")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㯥"),l1lllll_l1_+l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㯦"),l1l111_l1_ (u"ࠬ࠭㯧"),9999)
	return
def PLAY(id):
	source,server,l1l1l11l11_l1_,l1llll1ll1l_l1_ = id.split(l1l111_l1_ (u"࠭࠻࠼ࠩ㯨"))
	url = l1l111_l1_ (u"ࠧࠨ㯩")
	user = l1l1ll1l11l_l1_(32)
	if source==l1l111_l1_ (u"ࠨࡗࡕࡐࠬ㯪"): url = l1l1l11l11_l1_
	elif source==l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㯫"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㯬")][0]+l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ㯭")+l1l1l11l11_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㯮"),url)
		return
	elif source==l1l111_l1_ (u"࠭ࡇࡂࠩ㯯"):
		payload = { l1l111_l1_ (u"ࠧࡪࡦࠪ㯰") : l1l111_l1_ (u"ࠨࠩ㯱"), l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㯲") : user , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㯳") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠵ࠬ㯴") , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㯵") : l1l111_l1_ (u"࠭ࠧ㯶") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㯷"),l111l1_l1_,payload,l1l111_l1_ (u"ࠨࠩ㯸"),False,l1l111_l1_ (u"ࠩࠪ㯹"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㯺"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㯻"),l1l111_l1_ (u"ࠬ࠭㯼"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㯽"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㯾"))
			return
		html = response.content
		cookies = response.cookies
		l1l1ll11lll1_l1_ = cookies[l1l111_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࠬ㯿")]
		url = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㰀")]
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㰁") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㰂") : user , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㰃") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠸ࠧ㰄") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㰅") : l1l111_l1_ (u"ࠨࠩ㰆") }
		headers = { l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ㰇") : l1l111_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪ࠽ࠨ㰈")+l1l1ll11lll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㰉"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠬ࠭㰊"),l1l111_l1_ (u"࠭ࠧ㰋"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㰌"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㰍"),l1l111_l1_ (u"ࠩࠪ㰎"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㰏"),l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㰐"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠬࡸࡥࡴࡲࠥ࠾ࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅ࡭࠴ࡷ࠻࠭࠭࠴ࠪࡀࠫࠥࠫ㰑"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1l1ll11ll1l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠹࠰ࠪ㰒")+server+l1l111_l1_ (u"ࠧ࠸࠹࠺࠳ࠬ㰓")+l1l1l11l11_l1_+l1l111_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㰔")+params
		l1l1ll11ll11_l1_ = l1l1ll11ll1l_l1_.replace(l1l111_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㰕"),l1l111_l1_ (u"ࠪ࠸࠵ࡀ࠷ࠨ㰖")).replace(l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㰗"),l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㰘"))
		l1l1ll11llll_l1_ = l1l1ll11ll1l_l1_.replace(l1l111_l1_ (u"࠭࠳࠷࠼࠺ࠫ㰙"),l1l111_l1_ (u"ࠧ࠵࠴࠽࠻ࠬ㰚")).replace(l1l111_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㰛"),l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㰜"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠪࡌࡉ࠭㰝"),l1l111_l1_ (u"ࠫࡘࡊ࠱ࠨ㰞"),l1l111_l1_ (u"࡙ࠬࡄ࠳ࠩ㰟")]
		l1llll_l1_ = [l1l1ll11ll1l_l1_,l1l1ll11ll11_l1_,l1l1ll11llll_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"࠭ࡎࡕࠩ㰠"):
		headers = { l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㰡") : l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㰢") }
		payload = { l1l111_l1_ (u"ࠩ࡬ࡨࠬ㰣") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㰤") : user , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㰥") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡑࡘࠬ㰦") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㰧") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㰨"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠨࠩ㰩"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ㰪"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㰫"),l1l111_l1_ (u"ࠫࠬ㰬"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㰭"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㰮"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㰯")]
		url = url.replace(l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ㰰"),l1l111_l1_ (u"ࠩࠣࠫ㰱"))
		url = url.replace(l1l111_l1_ (u"ࠪࠩ࠸ࡊࠧ㰲"),l1l111_l1_ (u"ࠫࡂ࠭㰳"))
		if l1l111_l1_ (u"ࠬࡒࡥࡢࡴࡱࠫ㰴") in l1l1l11l11_l1_:
			url = url.replace(l1l111_l1_ (u"࠭ࡎࡕࡐࡑ࡭ࡱ࡫ࠧ㰵"),l1l111_l1_ (u"ࠧࠨ㰶"))
			url = url.replace(l1l111_l1_ (u"ࠨ࡮ࡨࡥࡷࡴࡩ࡯ࡩ࠴ࠫ㰷"),l1l111_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࡪࡰࡪࠫ㰸"))
	elif source==l1l111_l1_ (u"ࠪࡔࡑ࠭㰹"):
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㰺") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㰻") : user , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㰼") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡕࡒࠧ㰽") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㰾") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㰿"), l111l1_l1_, payload, l1l111_l1_ (u"ࠪࠫ㱀"),False,l1l111_l1_ (u"ࠫࠬ㱁"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ㱂"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㱃"),l1l111_l1_ (u"ࠧࠨ㱄"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㱅"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㱆"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㱇")]
		headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㱈"):response.headers[l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㱉")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㱊"),url, l1l111_l1_ (u"ࠧࠨ㱋"),headers , l1l111_l1_ (u"ࠨࠩ㱌"),l1l111_l1_ (u"ࠩࠪ㱍"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬ㱎"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㱏"),l1l111_l1_ (u"ࠬ࠭㱐"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㱑"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㱒"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㱓"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠩࡗࡅࠬ㱔"),l1l111_l1_ (u"ࠪࡊࡒ࠭㱕"),l1l111_l1_ (u"ࠫ࡞࡛ࠧ㱖"),l1l111_l1_ (u"ࠬ࡝ࡓ࠲ࠩ㱗"),l1l111_l1_ (u"࠭ࡗࡔ࠴ࠪ㱘"),l1l111_l1_ (u"ࠧࡓࡎ࠴ࠫ㱙"),l1l111_l1_ (u"ࠨࡔࡏ࠶ࠬ㱚")]:
		if source==l1l111_l1_ (u"ࠩࡗࡅࠬ㱛"): l1l1l11l11_l1_ = id
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㱜") : l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㱝") }
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㱞") : l1l1l11l11_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㱟") : user , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㱠") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࠭㱡")+source , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㱢") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㱣"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠫࠬ㱤"),l1l111_l1_ (u"ࠬ࠭㱥"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠻ࡺࡨࠨ㱦"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㱧"),l1l111_l1_ (u"ࠨࠩ㱨"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱩"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱪"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㱫")]
		if source==l1l111_l1_ (u"ࠬࡌࡍࠨ㱬"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㱭"), url, l1l111_l1_ (u"ࠧࠨ㱮"), l1l111_l1_ (u"ࠨࠩ㱯"), False,l1l111_l1_ (u"ࠩࠪ㱰"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠹ࡷ࡬ࠬ㱱"))
			url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㱲")]
			url = url.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㱳"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㱴"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㱵"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭䗔")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡍࡕࡗࡣࠬ䗕")
l1l1l11l1ll1_l1_ = 4
l1l1l11l11l1_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll11l_l1_):
	try: l1l1l11111ll_l1_ = str(l1llllll11l_l1_[l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗖")])
	except: l1l1l11111ll_l1_ = l1l111_l1_ (u"ࠨࠩ䗗")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1l1l11l1l_l1_(text)
	elif mode==162: l1lll_l1_ = l1l11llll11l_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l11llll11l_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1l1l111ll_l1_(text)
	elif mode==165: l1lll_l1_ = l1l11ll1ll1l_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1l11ll1ll_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l11ll1ll11_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l11ll1111l_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1l1l11111_l1_()
	elif mode==762: l1lll_l1_ = l1l1l111l111_l1_()
	elif mode==763: l1lll_l1_ = l1l1l1111ll1_l1_(l1l1l11111ll_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1l11l1l11_l1_(l1l1l11111ll_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1l11llll1_l1_(l1l1l11111ll_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗘"),l1l111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ࠣ฽ู๎วว์ฬࠫ䗙"),l1l111_l1_ (u"ࠫࠬ䗚"),161,l1l111_l1_ (u"ࠬ࠭䗛"),l1l111_l1_ (u"࠭ࠧ䗜"),l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗝"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗞"),l1l111_l1_ (u"ࠩๅืู๊ࠦี๊สส๏࠭䗟"),l1l111_l1_ (u"ࠪࠫ䗠"),162,l1l111_l1_ (u"ࠫࠬ䗡"),l1l111_l1_ (u"ࠬ࠭䗢"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䗣"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗤"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ䗥"),l1l111_l1_ (u"ࠩࠪ䗦"),163,l1l111_l1_ (u"ࠪࠫ䗧"),l1l111_l1_ (u"ࠫࠬ䗨"),l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䗩"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗪"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭䗫"),l1l111_l1_ (u"ࠨࠩ䗬"),164,l1l111_l1_ (u"ࠩࠪ䗭"),l1l111_l1_ (u"ࠪࠫ䗮"),l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗯"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗰"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ䗱"),l1l111_l1_ (u"ࠧࠨ䗲"),763,l1l111_l1_ (u"ࠨࠩ䗳"),l1l111_l1_ (u"ࠩࠪ䗴"),l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䗵"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䗶"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䗷"),l1l111_l1_ (u"࠭ࠧ䗸"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗹"),l1l111_l1_ (u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ䗺"),l1l111_l1_ (u"ࠩࠪ䗻"),163,l1l111_l1_ (u"ࠪࠫ䗼"),l1l111_l1_ (u"ࠫࠬ䗽"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗾"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗿"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ䘀"),l1l111_l1_ (u"ࠨࠩ䘁"),163,l1l111_l1_ (u"ࠩࠪ䘂"),l1l111_l1_ (u"ࠪࠫ䘃"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘄"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘅"),l1l111_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭䘆"),l1l111_l1_ (u"ࠧࠨ䘇"),162,l1l111_l1_ (u"ࠨࠩ䘈"),l1l111_l1_ (u"ࠩࠪ䘉"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘊"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘋"),l1l111_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬ䘌"),l1l111_l1_ (u"࠭ࠧ䘍"),162,l1l111_l1_ (u"ࠧࠨ䘎"),l1l111_l1_ (u"ࠨࠩ䘏"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘐"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘑"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣฬาัฺࠠึ๋หห๐ࠧ䘒"),l1l111_l1_ (u"ࠬ࠭䘓"),164,l1l111_l1_ (u"࠭ࠧ䘔"),l1l111_l1_ (u"ࠧࠨ䘕"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘖"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘗"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䘘"),l1l111_l1_ (u"ࠫࠬ䘙"),765,l1l111_l1_ (u"ࠬ࠭䘚"),l1l111_l1_ (u"࠭ࠧ䘛"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘜"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䘝"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䘞"),l1l111_l1_ (u"ࠪࠫ䘟"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘠"),l1l111_l1_ (u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ䘡"),l1l111_l1_ (u"࠭ࠧ䘢"),163,l1l111_l1_ (u"ࠧࠨ䘣"),l1l111_l1_ (u"ࠨࠩ䘤"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘥"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘦"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ䘧"),l1l111_l1_ (u"ࠬ࠭䘨"),163,l1l111_l1_ (u"࠭ࠧ䘩"),l1l111_l1_ (u"ࠧࠨ䘪"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘫"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘬"),l1l111_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ䘭"),l1l111_l1_ (u"ࠫࠬ䘮"),162,l1l111_l1_ (u"ࠬ࠭䘯"),l1l111_l1_ (u"࠭ࠧ䘰"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘱"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘲"),l1l111_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ䘳"),l1l111_l1_ (u"ࠪࠫ䘴"),162,l1l111_l1_ (u"ࠫࠬ䘵"),l1l111_l1_ (u"ࠬ࠭䘶"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘷"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘸"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡสะฯࠥ฿ิ้ษษ๎ࠬ䘹"),l1l111_l1_ (u"ࠩࠪ䘺"),164,l1l111_l1_ (u"ࠪࠫ䘻"),l1l111_l1_ (u"ࠫࠬ䘼"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘽"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘾"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ䘿"),l1l111_l1_ (u"ࠨࠩ䙀"),764,l1l111_l1_ (u"ࠩࠪ䙁"),l1l111_l1_ (u"ࠪࠫ䙂"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䙃"))
	return
def l1l1l1l11111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙄"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ䙅")+l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡊࡒࡗ࡚ࠬ䙆"),l1l111_l1_ (u"ࠨࠩ䙇"),764)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䙈"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䙉"),l1l111_l1_ (u"ࠫࠬ䙊"),9999)
	for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡉࡑࠩ䙋")+str(l1l1l11111ll_l1_)+l1l111_l1_ (u"࠭࡟ࠨ䙌")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䙍"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪ䙎")+NUMBERS_SEQ_NAME[l1l1l11111ll_l1_],l1l111_l1_ (u"ࠩࠪ䙏"),764,l1l111_l1_ (u"ࠪࠫ䙐"),l1l111_l1_ (u"ࠫࠬ䙑"),l1l111_l1_ (u"ࠬ࠭䙒"),l1l111_l1_ (u"࠭ࠧ䙓"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䙔"):l1l1l11111ll_l1_})
	return
def l1l1l111l111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙕"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䙖")+l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡑ࠸࡛ࠧ䙗"),l1l111_l1_ (u"ࠫࠬ䙘"),765)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙙"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䙚"),l1l111_l1_ (u"ࠧࠨ䙛"),9999)
	for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐ࡙ࠬ䙜")+str(l1l1l11111ll_l1_)+l1l111_l1_ (u"ࠩࡢࠫ䙝")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙞"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭䙟")+NUMBERS_SEQ_NAME[l1l1l11111ll_l1_],l1l111_l1_ (u"ࠬ࠭䙠"),765,l1l111_l1_ (u"࠭ࠧ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),l1l111_l1_ (u"ࠨࠩ䙣"),l1l111_l1_ (u"ࠩࠪ䙤"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙥"):l1l1l11111ll_l1_})
	return
def l1l1l11lllll_l1_(l1lll11l1ll_l1_):
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
	try:
		if l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ䙦") in l1lll11l1ll_l1_: l1lll1111l1_l1_(l1lll11l1ll_l1_)
		else: l1lll1111l1_l1_()
		l1l1l1111lll_l1_ = False
	except: l1l1l1111lll_l1_ = True
	l1lll11l1ll_l1_ = TRANSLATE(l1lll11l1ll_l1_)
	if l1l1l1111lll_l1_: l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠬ็ิๅࠢห๋ีอࠠศๆ่์็฿ࠧ䙧"),time=2000)
	else: l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"࠭สๆࠢฯ่อࠦวๅลๅืฬ๋ࠧ䙨"),time=2000)
	return l1l1l1111lll_l1_
def l1l1l111111l_l1_(l1l1l111l11l_l1_=True):
	if not l1l1l111l11l_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ䙩"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䙪"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧ䙫"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䙬"),l1l111_l1_ (u"ࠫࠬ䙭"),l1l111_l1_ (u"ࠬ࠭䙮"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䙯"),l1l111_l1_ (u"ࠧๅๅํࠤฯ๋ไว๊ࠢิ์ࠦวๅไสส๊ฯࠠ࠯ࠢส่อืๆศ็ฯࠤ๏ำสศฮࠣว๋๊ࠦโฯุࠤัฺ๋๊่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠโ์ࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํืฯิัอ่๊ࠢ์อࠠโไฺࠤฬ๊รใีส้ࠥอไาศํื๏ฯࠠ࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴ฺࠠ็็๎ฮࠦๅๅศࠣะ๊๐ูࠡษ็ว็ูวๆࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอ็฼ࠤ็อฦๆหࠣห้ษโิษ่ࠤฬ๊ย็ࠢยࠫ䙰"))
	if l1llll1l11_l1_!=1: return
	l1l11ll11ll1_l1_ = menuItemsLIST
	l1l11lllllll_l1_,l1l11lllll1l_l1_ = 0,l1l111_l1_ (u"ࠨࠩ䙱")
	for l1lll11l1ll_l1_ in l1l111l11l1_l1_:
		time.sleep(0.5)
		l1l1l1111lll_l1_ = l1l1l11lllll_l1_(l1lll11l1ll_l1_)
		if l1l1l1111lll_l1_:
			l1l11lllllll_l1_ += 1
			l1l11lllll1l_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䙲")+l1lll11l1ll_l1_
			if l1l11lllllll_l1_>=l1l1l11l11l1_l1_: break
	menuItemsLIST[:] = l1l11ll11ll1_l1_
	if l1l11lllllll_l1_>=l1l1l11l11l1_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䙳"),l1l111_l1_ (u"ࠫࠬ䙴"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䙵"),l1l111_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧ䙶")+str(l1l11lllllll_l1_)+l1l111_l1_ (u"ࠧࠡ็๋ห็฿ࠠๆ่้ࠣํอโฺࠢส่อืๆศ็ฯࠤ࠳࠴࠮๊ࠡึฬอํวࠡไาࠤ๏้่็ࠢ฼ำ๊่ࠦอ๊าࠤส์สา่ํฮࠥ็๊ࠡฮ๊หื้้้ࠠํ࠾ࠬ䙷")+l1l11lllll1l_l1_)
	else:
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䙸"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧ䙹"),contentsDICT,l1ll111l1l1_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䙺"),l1l111_l1_ (u"ࠫࠬ䙻"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䙼"),l1l111_l1_ (u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬ䙽"))
	return
def l1l11lll1ll1_l1_(l1l1l11111ll_l1_,options):
	l1l1lll11ll_l1_ = False
	l1l11ll111l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䙾") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䙿"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ䚀"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫ䚁")+l1l1l11111ll_l1_)
	elif l1l111_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ䚂") not in options or l1l111_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ䚃") not in options:
		import IPTV
		message = l1l111_l1_ (u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ䚄")
		if l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䚅") not in options:
			try: IPTV.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚆"),l1l111_l1_ (u"ࠩࠪ䚇"),l1l111_l1_ (u"ࠪࠫ䚈"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚉"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚊"),l1l111_l1_ (u"࠭ࠧ䚋"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ䚌"),message)
			try: IPTV.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚍"),l1l111_l1_ (u"ࠩࠪ䚎"),l1l111_l1_ (u"ࠪࠫ䚏"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚐"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚑"),l1l111_l1_ (u"࠭ࠧ䚒"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ䚓"),message)
			try: IPTV.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚔"),l1l111_l1_ (u"ࠩࠪ䚕"),l1l111_l1_ (u"ࠪࠫ䚖"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚗"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚘"),l1l111_l1_ (u"࠭ࠧ䚙"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ䚚"),message)
		if l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䚛") not in options:
			try: IPTV.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚜"),l1l111_l1_ (u"ࠪࠫ䚝"),l1l111_l1_ (u"ࠫࠬ䚞"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䚟"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚠"),l1l111_l1_ (u"ࠧࠨ䚡"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭䚢"),message)
			try: IPTV.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚣"),l1l111_l1_ (u"ࠪࠫ䚤"),l1l111_l1_ (u"ࠫࠬ䚥"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䚦"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚧"),l1l111_l1_ (u"ࠧࠨ䚨"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭䚩"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ䚪"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫ䚫")+l1l1l11111ll_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111l1_l1_
	return l1lll_l1_
def l1l1l1111l1l_l1_(l1l1l11111ll_l1_,options):
	l1l1lll11ll_l1_ = False
	l1l11ll111l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䚬") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䚭"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ䚮"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ䚯")+l1l1l11111ll_l1_)
	elif l1l111_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ䚰") not in options or l1l111_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ䚱") not in options:
		import M3U
		message = l1l111_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ䚲")
		if l1l111_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ䚳") not in options:
			try: M3U.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚴"),l1l111_l1_ (u"࠭ࠧ䚵"),l1l111_l1_ (u"ࠧࠨ䚶"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚷"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚸"),l1l111_l1_ (u"ࠪࠫ䚹"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ䚺"),message)
			try: M3U.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䚻"),l1l111_l1_ (u"࠭ࠧ䚼"),l1l111_l1_ (u"ࠧࠨ䚽"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚾"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚿"),l1l111_l1_ (u"ࠪࠫ䛀"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ䛁"),message)
			try: M3U.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䛂"),l1l111_l1_ (u"࠭ࠧ䛃"),l1l111_l1_ (u"ࠧࠨ䛄"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䛅"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䛆"),l1l111_l1_ (u"ࠪࠫ䛇"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ䛈"),message)
		if l1l111_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ䛉") not in options:
			try: M3U.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䛊"),l1l111_l1_ (u"ࠧࠨ䛋"),l1l111_l1_ (u"ࠨࠩ䛌"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䛍"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䛎"),l1l111_l1_ (u"ࠫࠬ䛏"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ䛐"),message)
			try: M3U.GROUPS(l1l1l11111ll_l1_,l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䛑"),l1l111_l1_ (u"ࠧࠨ䛒"),l1l111_l1_ (u"ࠨࠩ䛓"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䛔"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䛕"),l1l111_l1_ (u"ࠫࠬ䛖"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ䛗"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ䛘"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ䛙")+l1l1l11111ll_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111l1_l1_
	return l1lll_l1_
def l1l1l1111ll1_l1_(l1l1l11111ll_l1_,options,l1l11ll1llll_l1_):
	if l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䛚") in options and l1l11ll1llll_l1_==l1l111_l1_ (u"ࠩࠪ䛛"): l1l1l111111l_l1_(True)
	elif l1l11ll1llll_l1_: l1l1l111111l_l1_(False)
	l1l11lll11l1_l1_ = options.replace(l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䛜"),l1l111_l1_ (u"ࠫࠬ䛝")).replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䛞"),l1l111_l1_ (u"࠭ࠧ䛟")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䛠"),l1l111_l1_ (u"ࠨࠩ䛡"))
	if not l1l11ll1llll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䛢"),l1l111_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䛣"),l1l111_l1_ (u"ࠫࠬ䛤"),763,l1l111_l1_ (u"ࠬ࠭䛥"),l1l111_l1_ (u"࠭ࠧ䛦"),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䛧")+l1l11lll11l1_l1_,l1l111_l1_ (u"ࠨࠩ䛨"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䛩"):l1l1l11111ll_l1_})
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䛪"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䛫"),l1l111_l1_ (u"ࠬ࠭䛬"),9999)
	l1llllllll_l1_ = [l1l111_l1_ (u"࠭รโๆส้ࠬ䛭"),l1l111_l1_ (u"ࠧๆี็ื้อสࠨ䛮"),l1l111_l1_ (u"ࠨ็ึีา๐วหࠩ䛯"),l1l111_l1_ (u"ࠩหีฬ๋ฬࠨ䛰"),l1l111_l1_ (u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩ䛱"),l1l111_l1_ (u"ࠫึ๋ึศ่ࠪ䛲"),l1l111_l1_ (u"ࠬษอะอ࠰วำืࠧ䛳"),l1l111_l1_ (u"࠭ำๅษึ่ࠬ䛴"),l1l111_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ䛵"),l1l111_l1_ (u"ࠨลื๋ึ࠳รไอิࠫ䛶"),l1l111_l1_ (u"ࠩส่ว์ࠧ䛷"),l1l111_l1_ (u"ฺࠪา้ࠧ䛸"),l1l111_l1_ (u"ࠫึ๐วืหࠪ䛹"),l1l111_l1_ (u"ࠬ์๊หใ็็ุ࠭䛺"),l1l111_l1_ (u"࠭ๅๆอ็๎๋࠭䛻"),l1l111_l1_ (u"ࠧษอࠣั๏࠭䛼"),l1l111_l1_ (u"ࠨัํ๊๏ฯࠧ䛽"),l1l111_l1_ (u"ࠩึ๊ํอสࠨ䛾"),l1l111_l1_ (u"ࠪวำื้ࠨ䛿")]
	l1l11ll11lll_l1_ = [l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ䜀"),l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ䜁"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ䜂"),l1l111_l1_ (u"ࠧโๆ่ࠫ䜃")]
	l1ll11lll1l_l1_ = [l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ䜄"),l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䜅")]
	l1l1l1l11l11_l1_ = [l1l111_l1_ (u"ุ้ࠪอัฮࠩ䜆"),l1l111_l1_ (u"ู๊ࠫัฮ์สฮࠬ䜇")]
	l1l11lll111l_l1_ = [l1l111_l1_ (u"ࠬฮัศ็ฯࠫ䜈"),l1l111_l1_ (u"࠭ࡳࡩࡱࡺࠫ䜉"),l1l111_l1_ (u"ࠧหๆไึ๏๎ๆࠨ䜊"),l1l111_l1_ (u"ࠨฬ็๎ๆุ๊้่ࠪ䜋")]
	l1l1l11l1111_l1_ = [l1l111_l1_ (u"ࠩส๊๊๐ࠧ䜌"),l1l111_l1_ (u"ࠪ็ึะ่็ࠩ䜍"),l1l111_l1_ (u"่ࠫอัห๊้ࠫ䜎"),l1l111_l1_ (u"ࠬࡱࡩࡥࡵࠪ䜏"),l1l111_l1_ (u"࠭ืโๆࠪ䜐"),l1l111_l1_ (u"ࠧศูไห้࠭䜑")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠨำฺ่ฬ์ࠧ䜒")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠩสัิัࠧ䜓"),l1l111_l1_ (u"ࠪหำืࠧ䜔"),l1l111_l1_ (u"๊ࠫ๎ฮาࠩ䜕"),l1l111_l1_ (u"ࠬาฯ๋ัࠪ䜖"),l1l111_l1_ (u"࠭ๅืษไࠫ䜗"),l1l111_l1_ (u"ࠧฮัํฯࠬ䜘")]
	l1l11lll1lll_l1_ = [l1l111_l1_ (u"ࠨี็หุ๊ࠧ䜙"),l1l111_l1_ (u"ࠩึุ่๊็ࠨ䜚")]
	l1l11ll11111_l1_ = [l1l111_l1_ (u"ࠪห฿อๆ๋ࠩ䜛"),l1l111_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ䜜"),l1l111_l1_ (u"้ࠬไ๋สࠪ䜝"),l1l111_l1_ (u"࠭อโๆࠪ䜞"),l1l111_l1_ (u"ࠧ࡮ࡷࡶ࡭ࡨ࠭䜟")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠨษๆฯึ࠭䜠"),l1l111_l1_ (u"ࠩสุ์ืࠧ䜡"),l1l111_l1_ (u"้๊ࠪ๐า่ࠩ䜢"),l1l111_l1_ (u"ࠫฬ฿ไ๊ࠩ䜣"),l1l111_l1_ (u"๋ࠬฮหษิ๋ࠬ䜤"),l1l111_l1_ (u"࠭ๅฯฬสีฬะࠧ䜥"),l1l111_l1_ (u"ࠧศไ๋ํࠬ䜦")]
	l1l11l1lllll_l1_ = [l1l111_l1_ (u"ࠨษ็ห๋࠭䜧"),l1l111_l1_ (u"ࠩะห้๐ࠧ䜨"),l1l111_l1_ (u"้ࠪะฮสࠨ䜩"),l1l111_l1_ (u"ࠫึอฦอࠩ䜪")]
	l1l11ll111ll_l1_ = [l1l111_l1_ (u"ࠬ฼อไࠩ䜫"),l1l111_l1_ (u"࠭ใ้็ํำ๏࠭䜬")]
	l1l1l11ll1l1_l1_ = [l1l111_l1_ (u"ࠧา์สฺ์࠭䜭"),l1l111_l1_ (u"ࠨๅ๋ี์࠭䜮"),l1l111_l1_ (u"ู่ࠩฬืู่ࠩ䜯"),l1l111_l1_ (u"ุࠪํะࠧ䜰"),l1l111_l1_ (u"ࠫึ๐วืหࠪ䜱")]
	l1l1l111l1ll_l1_ = [l1l111_l1_ (u"ࠬ์๊หใ็็ุ࠭䜲"),l1l111_l1_ (u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧ䜳"),l1l111_l1_ (u"ࠧ็์อๅ้๐ใิࠩ䜴")]
	l1l11ll11l1l_l1_ = [l1l111_l1_ (u"ࠨ็่ฯ้๐ๆࠨ䜵"),l1l111_l1_ (u"ࠩสุำอีࠨ䜶"),l1l111_l1_ (u"๊ࠪั๎ๅࠨ䜷")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠫอัࠠฮ์ࠪ䜸"),l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ䜹"),l1l111_l1_ (u"࠭โ็ษ๊ࠫ䜺"),l1l111_l1_ (u"ࠧใ่๋หฯ࠭䜻")]
	l1l1l111lll1_l1_ = [l1l111_l1_ (u"ࠨัํ๊ࠬ䜼"),l1l111_l1_ (u"ࠩสำ฾๐็ࠨ䜽"),l1l111_l1_ (u"ࠪึ๏อัศฬࠪ䜾"),l1l111_l1_ (u"้ࠫ฽ๅ๋ษอࠫ䜿"),l1l111_l1_ (u"ࠬีูศรࠪ䝀"),l1l111_l1_ (u"࠭โาษ้ࠫ䝁"),l1l111_l1_ (u"ࠧใืสสิ࠭䝂"),l1l111_l1_ (u"ࠨำฮหฦ࠭䝃"),l1l111_l1_ (u"่ࠩีั฿๊่ࠩ䝄"),l1l111_l1_ (u"ࠪหีอๆࠨ䝅"),l1l111_l1_ (u"ࠫฬูไศ็ࠪ䝆"),l1l111_l1_ (u"ࠬะ่ศึํัࠬ䝇"),l1l111_l1_ (u"࠭ฮุสࠪ䝈"),l1l111_l1_ (u"ࠧฮ๊ี์๏࠭䝉"),l1l111_l1_ (u"ࠨ฻อฬฬะࠧ䝊"),l1l111_l1_ (u"่ࠩ์ฬ๊๊ะࠩ䝋"),l1l111_l1_ (u"๊ࠪํอู๋ࠩ䝌"),l1l111_l1_ (u"ࠫ฾่ววัࠪ䝍"),l1l111_l1_ (u"ࠬอๆศึํำࠬ䝎")]
	l1l11ll1l111_l1_ = [l1l111_l1_ (u"࠭࠱࠺ࠩ䝏"),l1l111_l1_ (u"ࠧ࠳࠲ࠪ䝐"),l1l111_l1_ (u"ࠨ࠴࠴ࠫ䝑"),l1l111_l1_ (u"ࠩ࠵࠶ࠬ䝒"),l1l111_l1_ (u"ࠪ࠶࠸࠭䝓"),l1l111_l1_ (u"ࠫ࠷࠺ࠧ䝔"),l1l111_l1_ (u"ࠬ࠸࠵ࠨ䝕"),l1l111_l1_ (u"࠭࠲࠷ࠩ䝖")]
	if not l1l11ll1llll_l1_:
		l1l11ll1llll_l1_ = 0
		for l1l1l11111l1_l1_ in l1llllllll_l1_:
			l1l11ll1llll_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝗"),l1lllll_l1_+l1l1l11111l1_l1_,l1l111_l1_ (u"ࠨࠩ䝘"),763,l1l111_l1_ (u"ࠩࠪ䝙"),str(l1l11ll1llll_l1_),l1l11lll11l1_l1_,l1l111_l1_ (u"ࠪࠫ䝚"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝛"):l1l1l11111ll_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1lllllllll_l1_ = name.lower()
			category = []
			if any(value in l1lllllllll_l1_ for value in l1l11ll11lll_l1_): category.append(1)
			if any(value in l1lllllllll_l1_ for value in l1ll11lll1l_l1_): category.append(2)
			if any(value in l1lllllllll_l1_ for value in l1l1l1l11l11_l1_): category.append(3)
			if any(value in l1lllllllll_l1_ for value in l1l11lll111l_l1_): category.append(4)
			if any(value in l1lllllllll_l1_ for value in l1l1l11l1111_l1_): category.append(5)
			if any(value in l1lllllllll_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l1lllllllll_l1_ for value in l1lllll1l_l1_) and l1lllllllll_l1_ not in [l1l111_l1_ (u"ࠬอฮา๋ࠪ䝜")]: category.append(7)
			if any(value in l1lllllllll_l1_ for value in l1l11lll1lll_l1_): category.append(8)
			if any(value in l1lllllllll_l1_ for value in l1l11ll11111_l1_): category.append(9)
			if any(value in l1lllllllll_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l1lllllllll_l1_ for value in l1l11l1lllll_l1_): category.append(11)
			if any(value in l1lllllllll_l1_ for value in l1l11ll111ll_l1_): category.append(12)
			if any(value in l1lllllllll_l1_ for value in l1l1l11ll1l1_l1_): category.append(13)
			if any(value in l1lllllllll_l1_ for value in l1l1l111l1ll_l1_): category.append(14)
			if any(value in l1lllllllll_l1_ for value in l1l11ll11l1l_l1_): category.append(15)
			if any(value in l1lllllllll_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l1lllllllll_l1_ for value in l1l1l111lll1_l1_): category.append(17)
			if any(value in l1lllllllll_l1_ for value in l1l11ll1l111_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l11ll1llll_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝝"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠧࠨ䝞"),l1l111_l1_ (u"ࠨࠩ䝟"),l1l11lll11l1_l1_+l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䝠"))
	return
def l1l1l11l1l11_l1_(l1l1l11111ll_l1_,options):
	l1l1lll11ll_l1_ = False
	if l1l1lll11ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䝡"),l1l111_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ䝢"),l1l111_l1_ (u"ࠬ࠭䝣"),764,l1l111_l1_ (u"࠭ࠧ䝤"),l1l111_l1_ (u"ࠧࠨ䝥"),l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䝦"),l1l111_l1_ (u"ࠩࠪ䝧"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝨"):l1l1l11111ll_l1_})
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䝩"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䝪"),l1l111_l1_ (u"࠭ࠧ䝫"),9999)
	l1l11ll111l1_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1l11111ll_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1l11111ll_l1_,True): return
		l1l11llll111_l1_ = l1l11lll1ll1_l1_(l1l1l11111ll_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l11llll111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䝬"),True): return
		if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䝭") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䝮"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ䝯"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨ䝰"))
		else:
			l1l11ll1l11l_l1_,l111l1l1ll_l1_,l1l11llll111_l1_ = [],[],[]
			for l1l1l1111111_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l11lll1ll1_l1_(str(l1l1l1111111_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l111l1l1ll_l1_:
				if text not in l1l11ll1l11l_l1_:
					l1l11ll1l11l_l1_.append(text)
					l1l1l11lll11_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll11l_l1_
					l1l11llll111_l1_.append(l1l1l11lll11_l1_)
			l111l1l1ll_l1_ = sorted(l1l11llll111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䝱"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪ䝲"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111l1_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ䝳"))
	return
def l1l1l11llll1_l1_(l1l1l11111ll_l1_,options):
	l1l1lll11ll_l1_ = False
	if l1l1lll11ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䝴"),l1l111_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭䝵"),l1l111_l1_ (u"ࠪࠫ䝶"),765,l1l111_l1_ (u"ࠫࠬ䝷"),l1l111_l1_ (u"ࠬ࠭䝸"),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䝹"),l1l111_l1_ (u"ࠧࠨ䝺"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝻"):l1l1l11111ll_l1_})
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝼"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䝽"),l1l111_l1_ (u"ࠫࠬ䝾"),9999)
	l1l11ll111l1_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1l11111ll_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1l11111ll_l1_,True): return
		l1l11llll111_l1_ = l1l1l1111l1l_l1_(l1l1l11111ll_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l11llll111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䝿"),True): return
		if l1l1lll11ll_l1_ and l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䞀") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䞁"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ䞂"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬ䞃"))
		else:
			l1l11ll1l11l_l1_,l111l1l1ll_l1_,l1l11llll111_l1_ = [],[],[]
			for l1l1l1111111_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l1l1111l1l_l1_(str(l1l1l1111111_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l111l1l1ll_l1_:
				if text not in l1l11ll1l11l_l1_:
					l1l11ll1l11l_l1_.append(text)
					l1l1l11lll11_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll11l_l1_
					l1l11llll111_l1_.append(l1l1l11lll11_l1_)
			l111l1l1ll_l1_ = sorted(l1l11llll111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ䞄"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ䞅"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111l1_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䞆"))
	return
def l1l11ll1ll1l_l1_(group,options):
	l1l1lll11ll_l1_ = False
	l1lll_l1_ = []
	l1l1l1111l11_l1_ = l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䞇") if l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䞈") in options else l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䞉")
	if l1l1lll11ll_l1_: l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䞊"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ䞋")+l1l1l1111l11_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1lll11ll_l1_: l1lll_l1_ += l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䞌"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ䞍")+l1l1l1111l11_l1_[:-1],l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ䞎")+l1l1l1111l11_l1_+str(l1l1l11111ll_l1_))
			elif l1l1l1111l11_l1_==l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䞏"): l1lll_l1_ += l1l11lll1ll1_l1_(str(l1l1l11111ll_l1_),l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䞐"))
			elif l1l1l1111l11_l1_==l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䞑"): l1lll_l1_ += l1l1l1111l1l_l1_(str(l1l1l11111ll_l1_),l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䞒"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l1lll_l1_:
			if text==group: l1ll1l11l11l_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in menuItemsLIST:
			l1l1l111ll1l_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠫࠬ䞓")
			if l1l1l111ll1l_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1l111ll1l_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ䞔")+l1l1l1111l11_l1_[:-1],group,l1lll_l1_,l1ll111l1l1_l1_)
	if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䞕") in options and len(l1lll_l1_)>l1l1l11l1ll1_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䞖"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䞗")+group+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䞘"),group,165,l1l111_l1_ (u"ࠪࠫ䞙"),l1l111_l1_ (u"ࠫࠬ䞚"),l1l1l1111l11_l1_+l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䞛"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䞜"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䞝"),group,165,l1l111_l1_ (u"ࠨࠩ䞞"),l1l111_l1_ (u"ࠩࠪ䞟"),l1l1l1111l11_l1_+l1l111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞠"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䞡"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䞢"),l1l111_l1_ (u"࠭ࠧ䞣"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1l11l1ll1_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ䞤"))
	return
def l1l1l1l11l1l_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䞥"),l1l111_l1_ (u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥๆ้ษอࠤ฾ฺ่ศศํอࠬ䞦"),l1l111_l1_ (u"ࠪࠫ䞧"),161,l1l111_l1_ (u"ࠫࠬ䞨"),l1l111_l1_ (u"ࠬ࠭䞩"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭䞪"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䞫"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䞬"),l1l111_l1_ (u"ࠩࠪ䞭"),9999)
	l1l1l11l11ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1lll1llll1l_l1_
	l1lll1llll1l_l1_.ITEMS(l1l111_l1_ (u"ࠪ࠴ࠬ䞮"),False)
	l1lll1llll1l_l1_.ITEMS(l1l111_l1_ (u"ࠫ࠶࠭䞯"),False)
	l1lll1llll1l_l1_.ITEMS(l1l111_l1_ (u"ࠬ࠸ࠧ䞰"),False)
	if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䞱") in options:
		menuItemsLIST[:] = l1l11lllll11_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l11l1ll1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1ll1_l1_)
	menuItemsLIST[:] = l1l1l11l11ll_l1_+menuItemsLIST
	return
def l1l1l1l111ll_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞲"),l1l111_l1_ (u"ࠨࠩ䞳")).replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䞴"),l1l111_l1_ (u"ࠪࠫ䞵"))
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䞶") : l1l111_l1_ (u"ࠬ࠭䞷") }
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡧ࡫ࡳࡵࡴࡤࡲࡩࡵ࡭ࡴ࠰ࡦࡳࡲ࠵ࡲࡢࡰࡧࡳࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠳ࡷࡰࡴࡧࡷࠬ䞸")
	data = {l1l111_l1_ (u"ࠧࡲࡷࡤࡲࡹ࡯ࡴࡺࠩ䞹"):l1l111_l1_ (u"ࠨ࠷࠳ࠫ䞺")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䞻"),url,data,headers,l1l111_l1_ (u"ࠪࠫ䞼"),l1l111_l1_ (u"ࠫࠬ䞽"),l1l111_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧ䞾"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨ䞿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ䟀"),block,re.DOTALL)
	l1l11l1lll1l_l1_,l1l11ll1l1l1_l1_ = list(zip(*items))
	l1l1l11lll1l_l1_ = []
	l1l1l1l111l1_l1_ = [l1l111_l1_ (u"ࠨࠢࠪ䟁"),l1l111_l1_ (u"ࠩࠥࠫ䟂"),l1l111_l1_ (u"ࠪࡤࠬ䟃"),l1l111_l1_ (u"ࠫ࠱࠭䟄"),l1l111_l1_ (u"ࠬ࠴ࠧ䟅"),l1l111_l1_ (u"࠭࠺ࠨ䟆"),l1l111_l1_ (u"ࠧ࠼ࠩ䟇"),l1l111_l1_ (u"ࠣࠩࠥ䟈"),l1l111_l1_ (u"ࠩ࠰ࠫ䟉")]
	l1l11lll11ll_l1_ = l1l11ll1l1l1_l1_+l1l11l1lll1l_l1_
	for word in l1l11lll11ll_l1_:
		if word in l1l11ll1l1l1_l1_: l1l1l111l1l1_l1_ = 2
		if word in l1l11l1lll1l_l1_: l1l1l111l1l1_l1_ = 4
		l1l11lll1l1l_l1_ = [i in word for i in l1l1l1l111l1_l1_]
		if any(l1l11lll1l1l_l1_):
			index = l1l11lll1l1l_l1_.index(True)
			l1l11lll1111_l1_ = l1l1l1l111l1_l1_[index]
			l1l1l11ll111_l1_ = l1l111_l1_ (u"ࠪࠫ䟊")
			if word.count(l1l11lll1111_l1_)>1: l1l1l11ll11l_l1_,l1l1l11l1lll_l1_,l1l1l11ll111_l1_ = word.split(l1l11lll1111_l1_,2)
			else: l1l1l11ll11l_l1_,l1l1l11l1lll_l1_ = word.split(l1l11lll1111_l1_,1)
			if len(l1l1l11ll11l_l1_)>l1l1l111l1l1_l1_: l1l1l11lll1l_l1_.append(l1l1l11ll11l_l1_.lower())
			if len(l1l1l11l1lll_l1_)>l1l1l111l1l1_l1_: l1l1l11lll1l_l1_.append(l1l1l11l1lll_l1_.lower())
			if len(l1l1l11ll111_l1_)>l1l1l111l1l1_l1_: l1l1l11lll1l_l1_.append(l1l1l11ll111_l1_.lower())
		elif len(word)>l1l1l111l1l1_l1_: l1l1l11lll1l_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1l11lll1l_l1_)
	if l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ䟋") in options:
		l1l11ll11l11_l1_ = l1ll1ll1l11l_l1_
	elif l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䟌") in options:
		l1l11ll11l11_l1_ = [l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ䟍")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䟎"),True): return
	elif l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䟏") in options:
		l1l11ll11l11_l1_ = [l1l111_l1_ (u"ࠩࡐ࠷࡚࠭䟐")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䟑"),True): return
	count,l1l11ll1l1ll_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䟒"),l1l111_l1_ (u"ࠬࡡࠠࠡ࡟ࠣ࠾ฬ๊ศฮอࠣ฽๋࠭䟓"),l1l111_l1_ (u"࠭ࠧ䟔"),164,l1l111_l1_ (u"ࠧࠨ䟕"),l1l111_l1_ (u"ࠨࠩ䟖"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䟗")+options)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟘"),l1l111_l1_ (u"ࠫส฿วะหࠣห้ฮอฬࠢส่฾ฺ่ศศํࠫ䟙"),l1l111_l1_ (u"ࠬ࠭䟚"),164,l1l111_l1_ (u"࠭ࠧ䟛"),l1l111_l1_ (u"ࠧࠨ䟜"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟝")+options)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䟞"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䟟"),l1l111_l1_ (u"ࠫࠬ䟠"),9999)
	l1l11l1lll11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l1l1111l_l1_ = []
	for word in l1l1l11lll1l_l1_:
		l1l1l11l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡡࠠ࡝࠮࡟࠿ࡡࡀ࡜࠮࡞࠮ࡠࡂࡢࠢ࡝ࠩ࡟࡟ࡡࡣ࡜ࠩ࡞ࠬࡠࢀࡢࡽ࡝ࠣ࡟ࡄࠬ䟡")+l1l111_l1_ (u"࠭ࠣࠨ䟢")+l1l111_l1_ (u"ࠧ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫ䟣"),word,re.DOTALL)
		if l1l1l11l1lll_l1_: word = word.split(l1l1l11l1lll_l1_[0],1)[0]
		l1l1l11l111l_l1_ = word.replace(l1l111_l1_ (u"ࠨ๓ࠪ䟤"),l1l111_l1_ (u"ࠩࠪ䟥")).replace(l1l111_l1_ (u"ࠪ๒ࠬ䟦"),l1l111_l1_ (u"ࠫࠬ䟧")).replace(l1l111_l1_ (u"ࠬ๑ࠧ䟨"),l1l111_l1_ (u"࠭ࠧ䟩")).replace(l1l111_l1_ (u"ࠧ๐ࠩ䟪"),l1l111_l1_ (u"ࠨࠩ䟫")).replace(l1l111_l1_ (u"ࠩ๏ࠫ䟬"),l1l111_l1_ (u"ࠪࠫ䟭"))
		l1l1l11l111l_l1_ = l1l1l11l111l_l1_.replace(l1l111_l1_ (u"ࠫ๕࠭䟮"),l1l111_l1_ (u"ࠬ࠭䟯")).replace(l1l111_l1_ (u"࠭ํࠨ䟰"),l1l111_l1_ (u"ࠧࠨ䟱")).replace(l1l111_l1_ (u"ࠨ๔ࠪ䟲"),l1l111_l1_ (u"ࠩࠪ䟳")).replace(l1l111_l1_ (u"ࠪฐࠬ䟴"),l1l111_l1_ (u"ࠫࠬ䟵")).replace(l1l111_l1_ (u"ࠬๆࠧ䟶"),l1l111_l1_ (u"࠭ࠧ䟷"))
		if l1l1l11l111l_l1_: l1l1l1l1111l_l1_.append(l1l1l11l111l_l1_)
	l1l1l111llll_l1_ = []
	for l1l11l111l_l1_ in range(0,20):
		search = random.sample(l1l1l1l1111l_l1_,1)[0]
		if search in l1l1l111llll_l1_: continue
		l1l1l111llll_l1_.append(search)
		l1lll11l1ll_l1_ = random.sample(l1l11ll11l11_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䟸"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡧࡲࡤࡪࠣࠤࠥࡹࡩࡵࡧ࠽ࠫ䟹")+str(l1lll11l1ll_l1_)+l1l111_l1_ (u"ࠩࠣࠤࡸ࡫ࡡࡳࡥ࡫࠾ࠬ䟺")+search)
		l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
		l1lll11l1l1_l1_(search+l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䟻"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䟼"),l1l111_l1_ (u"ࠬ࠭䟽"))
	l1l11l1lll11_l1_[0][1] = l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䟾")+search+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ฬาัฺ่ࠠࡠࠫ䟿")
	menuItemsLIST[:] = l1l11lllll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l11l1ll1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1ll1_l1_)
	menuItemsLIST[:] = l1l11l1lll11_l1_+menuItemsLIST
	return
def l1l1l11ll1ll_l1_(l1l11ll1lll1_l1_,options):
	l1l11ll1lll1_l1_ = l1l11ll1lll1_l1_.replace(l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䠀"),l1l111_l1_ (u"ࠩࠪ䠁"))
	options = options.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠂"),l1l111_l1_ (u"ࠫࠬ䠃")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠄"),l1l111_l1_ (u"࠭ࠧ䠅"))
	l1l1l111111l_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䠆") in options:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠇"),l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䠈")+l1l11ll1lll1_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭䠉"),l1l11ll1lll1_l1_,166,l1l111_l1_ (u"ࠫࠬ䠊"),l1l111_l1_ (u"ࠬ࠭䠋"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠌")+options)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠍"),l1l111_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䠎"),l1l11ll1lll1_l1_,166,l1l111_l1_ (u"ࠩࠪ䠏"),l1l111_l1_ (u"ࠪࠫ䠐"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠑")+options)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䠒"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䠓"),l1l111_l1_ (u"ࠧࠨ䠔"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l11ll1lll1_l1_].keys())):
		type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = contentsDICT[l1l11ll1lll1_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䠕") in options or len(contentsDICT[l1l11ll1lll1_l1_])==1:
			l1ll1l11l11l_l1_(type,l1l111_l1_ (u"ࠩࠪ䠖"),url,l1ll1ll1lll1_l1_,l1l111_l1_ (u"ࠪࠫ䠗"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠫࠬ䠘"),l1l111_l1_ (u"ࠬ࠭䠙"))
			menuItemsLIST[:] = l1l11lllll11_l1_(menuItemsLIST)
			l1l11ll111l1_l1_,l111l1l1ll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1l1ll_l1_)
			if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䠚") in options: menuItemsLIST[:] = l1l11ll111l1_l1_+l111l1l1ll_l1_[:l1l1l11l1ll1_l1_]
			else: menuItemsLIST[:] = l1l11ll111l1_l1_+l111l1l1ll_l1_
		elif l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䠛") in options: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠜"),l1l11l11_l1_,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
	return
def l1l11llll11l_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠝"),l1l111_l1_ (u"ࠪࠫ䠞")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠟"),l1l111_l1_ (u"ࠬ࠭䠠"))
	name,l1l11lll1l11_l1_ = l1l111_l1_ (u"࠭ࠧ䠡"),[]
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠢"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䠣")+name+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䠤"),l1l111_l1_ (u"ࠪࠫ䠥"),mode,l1l111_l1_ (u"ࠫࠬ䠦"),l1l111_l1_ (u"ࠬ࠭䠧"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠨")+options)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠩"),l1l111_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨ䠪"),l1l111_l1_ (u"ࠩࠪ䠫"),mode,l1l111_l1_ (u"ࠪࠫ䠬"),l1l111_l1_ (u"ࠫࠬ䠭"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䠮")+options)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䠯"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䠰"),l1l111_l1_ (u"ࠨࠩ䠱"),9999)
	l1l11ll111l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䠲") in options:
		l1l1l111111l_l1_(False)
		if contentsDICT=={}: return
		l1l11llll1ll_l1_ = list(contentsDICT.keys())
		l1l11ll1lll1_l1_ = random.sample(l1l11llll1ll_l1_,1)[0]
		l1l1l11lll1l_l1_ = list(contentsDICT[l1l11ll1lll1_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1l11lll1l_l1_,1)[0]
		type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = contentsDICT[l1l11ll1lll1_l1_][l1l11l11_l1_]
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䠳"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧ䠴")+l1l11l11_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䠵")+name+l1l111_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䠶")+url+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䠷")+str(l1ll1ll1lll1_l1_))
	elif l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䠸") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䠹"),True): return
		for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11lll1ll1_l1_(str(l1l1l11111ll_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䠺"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䠻")+name+l1l111_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䠼")+url+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䠽")+str(l1ll1ll1lll1_l1_))
	elif l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䠾") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䠿"),True): return
		for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1l1111l1l_l1_(str(l1l1l11111ll_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䡀"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䡁")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䡂")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䡃")+str(l1ll1ll1lll1_l1_))
	l1l1l111ll11_l1_ = name
	l1l11llllll1_l1_ = []
	for i in range(0,10):
		if i>0: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䡄"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䡅")+name+l1l111_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䡆")+url+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䡇")+str(l1ll1ll1lll1_l1_))
		menuItemsLIST[:] = []
		if l1ll1ll1lll1_l1_==234 and l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡈") in text: l1ll1ll1lll1_l1_ = 233
		if l1ll1ll1lll1_l1_==714 and l1l111_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡉") in text: l1ll1ll1lll1_l1_ = 713
		if l1ll1ll1lll1_l1_==144: l1ll1ll1lll1_l1_ = 291
		dummy = l1ll1l11l11l_l1_(type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
		if l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䡊") in options and l1ll1ll1lll1_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䡋") in options and l1ll1ll1lll1_l1_==168: del menuItemsLIST[:3]
		l1l11lll1l11_l1_[:] = l1l11lllll11_l1_(menuItemsLIST)
		if l1l11llllll1_l1_ and l111ll11lll_l1_(l1l111_l1_ (u"ࡵࠨฯ็ๆฮ࠭䡌")) in str(l1l11lll1l11_l1_) or l111ll11lll_l1_(l1l111_l1_ (u"ࡶࠩะ่็ํࠧ䡍")) in str(l1l11lll1l11_l1_):
			name = l1l1l111ll11_l1_
			l1l11lll1l11_l1_[:] = l1l11llllll1_l1_
			break
		l1l1l111ll11_l1_ = name
		l1l11llllll1_l1_ = l1l11lll1l11_l1_
		if str(l1l11lll1l11_l1_).count(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䡎"))>0: break
		if str(l1l11lll1l11_l1_).count(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䡏"))>0: break
		if l1ll1ll1lll1_l1_==233: break
		if l1ll1ll1lll1_l1_==713: break
		if l1ll1ll1lll1_l1_==291: break
		if l1l11lll1l11_l1_: type,name,url,l1ll1ll1lll1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1l11lll1l11_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠫ࠳࠴࠮࠯ࠩ䡐")
	elif name.count(l1l111_l1_ (u"ࠬࡥࠧ䡑"))>1: name = name.split(l1l111_l1_ (u"࠭࡟ࠨ䡒"),2)[2]
	name = name.replace(l1l111_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎ࠻ࠢࠪ䡓"),l1l111_l1_ (u"ࠨࠩ䡔"))
	name = name.replace(l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䡕"),l1l111_l1_ (u"ࠪࠫ䡖"))
	l1l11ll111l1_l1_[0][1] = l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䡗")+name+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䡘")
	for i in range(9): random.shuffle(l1l11lll1l11_l1_)
	if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䡙") in options: menuItemsLIST[:] = l1l11ll111l1_l1_+l1l11lll1l11_l1_[:l1l1l11l1ll1_l1_]
	else: menuItemsLIST[:] = l1l11ll111l1_l1_+l1l11lll1l11_l1_
	return
def l1l11ll1ll11_l1_(l1l11l1llll1_l1_,l1l1l11l1l1l_l1_):
	l1l1l11l1l1l_l1_ = l1l1l11l1l1l_l1_.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡚"),l1l111_l1_ (u"ࠨࠩ䡛")).replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䡜"),l1l111_l1_ (u"ࠪࠫ䡝"))
	l1l11llll1l1_l1_ = l1l1l11l1l1l_l1_
	if l1l111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䡞") in l1l1l11l1l1l_l1_:
		l1l11llll1l1_l1_ = l1l1l11l1l1l_l1_.split(l1l111_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡟"))[0]
		type = l1l111_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ䡠")
	elif l1l111_l1_ (u"ࠧࡗࡑࡇࠫ䡡") in l1l11l1llll1_l1_: type = l1l111_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ䡢")
	elif l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䡣") in l1l11l1llll1_l1_: type = l1l111_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ䡤")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡥"),l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䡦")+type+l1l11llll1l1_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ䡧"),l1l11l1llll1_l1_,167,l1l111_l1_ (u"ࠧࠨ䡨"),l1l111_l1_ (u"ࠨࠩ䡩"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡪")+l1l1l11l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䡫"),l1l111_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䡬"),l1l11l1llll1_l1_,167,l1l111_l1_ (u"ࠬ࠭䡭"),l1l111_l1_ (u"࠭ࠧ䡮"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡯")+l1l1l11l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䡰"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䡱"),l1l111_l1_ (u"ࠪࠫ䡲"),9999)
	import IPTV
	for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䡳") in l1l1l11l1l1l_l1_: IPTV.GROUPS(str(l1l1l11111ll_l1_),l1l11l1llll1_l1_,l1l1l11l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭䡴"),False)
		else: IPTV.ITEMS(str(l1l1l11111ll_l1_),l1l11l1llll1_l1_,l1l1l11l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ䡵"),False)
	menuItemsLIST[:] = l1l11lllll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1ll1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1ll1_l1_)
	return
def l1l11ll1111l_l1_(l1l11l1llll1_l1_,l1l1l11l1l1l_l1_):
	l1l1l11l1l1l_l1_ = l1l1l11l1l1l_l1_.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡶"),l1l111_l1_ (u"ࠨࠩ䡷")).replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䡸"),l1l111_l1_ (u"ࠪࠫ䡹"))
	l1l11llll1l1_l1_ = l1l1l11l1l1l_l1_
	if l1l111_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡺") in l1l1l11l1l1l_l1_:
		l1l11llll1l1_l1_ = l1l1l11l1l1l_l1_.split(l1l111_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ䡻"))[0]
		type = l1l111_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ䡼")
	elif l1l111_l1_ (u"ࠧࡗࡑࡇࠫ䡽") in l1l11l1llll1_l1_: type = l1l111_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ䡾")
	elif l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䡿") in l1l11l1llll1_l1_: type = l1l111_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ䢀")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䢁"),l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䢂")+type+l1l11llll1l1_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ䢃"),l1l11l1llll1_l1_,168,l1l111_l1_ (u"ࠧࠨ䢄"),l1l111_l1_ (u"ࠨࠩ䢅"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䢆")+l1l1l11l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢇"),l1l111_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䢈"),l1l11l1llll1_l1_,168,l1l111_l1_ (u"ࠬ࠭䢉"),l1l111_l1_ (u"࠭ࠧ䢊"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䢋")+l1l1l11l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䢌"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䢍"),l1l111_l1_ (u"ࠪࠫ䢎"),9999)
	import M3U
	for l1l1l11111ll_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䢏") in l1l1l11l1l1l_l1_: M3U.GROUPS(str(l1l1l11111ll_l1_),l1l11l1llll1_l1_,l1l1l11l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭䢐"),False)
		else: M3U.ITEMS(str(l1l1l11111ll_l1_),l1l11l1llll1_l1_,l1l1l11l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ䢑"),False)
	menuItemsLIST[:] = l1l11lllll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1ll1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1ll1_l1_)
	return
def l1l11lllll11_l1_(menuItemsLIST):
	l1l11lll1l11_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ࠧึใะอࠬ䢒") in name or l1l111_l1_ (u"ࠨืไั์࠭䢓") in name or l1l111_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ䢔") in name.lower(): continue
		l1l11lll1l11_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_])
	return l1l11lll1l11_l1_
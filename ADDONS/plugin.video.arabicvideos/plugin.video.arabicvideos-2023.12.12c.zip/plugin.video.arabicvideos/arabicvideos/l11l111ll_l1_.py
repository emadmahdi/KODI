# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩᎏ")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᎐"):l1l111_l1_ (u"ࠫࠬ᎑")}
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡃ࠵ࡗࡢࠫ᎒")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ᎓"),l1l111_l1_ (u"ࠧศะิ๎ࠬ᎔"),l1l111_l1_ (u"ࠨษัี๎࠭᎕"),l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ᎖"),l1l111_l1_ (u"ࠪฬิ๎ๆࠡวัฮ๏อัࠨ᎗"),l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ᎘"),l1l111_l1_ (u"๋ࠬำๅี็หฯ࠭᎙")]
def l11l1ll_l1_(mode,url,text):
	if   mode==420: l1lll_l1_ = l1l1l11_l1_()
	elif mode==421: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==422: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==423: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==424: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ᎚")+text)
	elif mode==425: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭᎛")+text)
	elif mode==426: l1lll_l1_ = PLAY(url)
	elif mode==427: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==429: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ᎜"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ᎝"),l1l111_l1_ (u"ࠪࠫ᎞"),l1l111_l1_ (u"ࠫࠬ᎟"),l1l111_l1_ (u"ࠬ࠭Ꭰ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᎡ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ꭲ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠨ࠱ࠪᎣ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭Ꭴ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎥ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᎦ"),l1l111_l1_ (u"ࠬ࠭Ꭷ"),429,l1l111_l1_ (u"࠭ࠧᎨ"),l1l111_l1_ (u"ࠧࠨᎩ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᎪ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎫ"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭Ꭼ"),l1l11ll_l1_,425)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎭ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᎮ"),l1l11ll_l1_,424)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᎯ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᎰ"),l1l111_l1_ (u"ࠨࠩᎱ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎲ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᎳ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭Ꮄ"),l1l11ll_l1_,421)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᎵ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᎶ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳࠨᎷ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠨลไ่ฬ๋ࠠศๆ้ะํ๋ࠧᎸ")
		elif l1l111_l1_ (u"ࠩ࠲ࡲࡪࡺࡦ࡭࡫ࡻࠫᎹ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠪวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๋๐สโๆๆืࠬᎺ")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎻ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᎼ")+l1lllll_l1_+title,l1ll1ll_l1_,421)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮍ"),l1lllll_l1_+l1l111_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧᎾ"),l1l11ll_l1_,427)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠨࠩᎿ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭Ꮐ"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫᏁ"),l1l111_l1_ (u"ࠫࠬᏂ"),l1l111_l1_ (u"ࠬ࠭Ꮓ"),l1l111_l1_ (u"࠭ࠧᏄ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᏅ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡘ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᏆ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᏇ"),block,re.DOTALL)
	for category,id,l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻ࠱ࡲࡵࡶࡪࡧࡶࠫᏈ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫᏉ")
		elif l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠲ࡴࡥࡵࡨ࡯࡭ࡽ࠭Ꮚ") in l1ll1ll_l1_: title = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᏋ")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏌ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᏍ")+l1lllll_l1_+title,l1ll1ll_l1_,421,l1l111_l1_ (u"ࠩࠪᏎ"),l1l111_l1_ (u"ࠪࠫᏏ"),category+l1l111_l1_ (u"ࠫࢁ࠭Ꮠ")+id)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠬ࠭Ꮡ")):
	if l1l111_l1_ (u"࠭࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᏒ") in url: url = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩᏓ"))+l1l111_l1_ (u"ࠨ࠱ࡰࡴࡦࡧ࠯ࡧࡣࡰ࡭ࡱࡿ࠯ࠨᏔ")
	items = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭Ꮥ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᏖ"),url,l1l111_l1_ (u"ࠫࠬᏗ"),headers,l1l111_l1_ (u"ࠬ࠭Ꮨ"),l1l111_l1_ (u"࠭ࠧᏙ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᏚ"))
	html = response.content
	if not l111l1l1l_l1_ or l1l111_l1_ (u"ࠨࡾࠪᏛ") in l111l1l1l_l1_:
		if l1l111_l1_ (u"ࠩࡿࠫᏜ") not in l111l1l1l_l1_: l111l1ll1_l1_ = l1l111_l1_ (u"ࠪࠫᏝ")
		else: l111l1ll1_l1_ = l1l111_l1_ (u"ࠫ࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠵ࠧᏞ")+l111l1l1l_l1_
		l111ll11l_l1_ = False
		if l1l111_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠨᏟ") in html:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮰ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨᏡ"),url,421,l1l111_l1_ (u"ࠨࠩᏢ"),l1l111_l1_ (u"ࠩࠪᏣ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᏤ"))
			l111ll11l_l1_ = True
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩᏥ"),html,re.DOTALL)
		if l11llll_l1_:
			l1l1l1l_l1_ = l11llll_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡨ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᏦ"),l1l1l1l_l1_,re.DOTALL)
			for l11l1111l_l1_,l1lllllll_l1_ in l1l1111_l1_:
				l111lllll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡨ࡫࡮ࡵࡧࡵ࠳ࡦࡩࡴࡪࡱࡱ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴ࡺࡡࡣ࠱ࠪᏧ")+l11l1111l_l1_+l111l1ll1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩᏨ")
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᏩ"),l1lllll_l1_+l1lllllll_l1_,l111lllll_l1_,421)
				l111ll11l_l1_ = True
		if l111ll11l_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᏪ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᏫ"),l1l111_l1_ (u"ࠫࠬᏬ"),9999)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᏭ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶ࡮ࡷ࡭ࡋ࡯࡬ࡵࡧࡵࠫᏮ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪᏯ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠨࠩᏰ")
	elif l1l111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᏱ") in url or l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡧࡪࡴࡴࡦࡴ࠲ࠫᏲ") in url:
		block = html
	elif l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭Ᏻ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡖࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠫࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠰ࠧᏴ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷࡹࠧᏵ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࠭ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠫࠩ᏶"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᏷"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡆ࡭ࡲࡧ࠴ࡶࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩᏸ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠪࠫᏹ")
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࠯ࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠭࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠲࠯ࡅࡂࡰࡺࡗ࡭ࡹࡲࡥࡊࡰࡩࡳ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬᏺ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᏻ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if not title: continue
		if l1l111_l1_ (u"࠭࠿࡯ࡧࡺࡷࡂ࠭ᏼ") in l1ll1ll_l1_: continue
		title = title.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠠࠨᏽ"),l1l111_l1_ (u"ࠨࠩ᏾"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ᏿"),title,re.DOTALL)
		if l1l1lll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨ᐀") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᐁ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐂ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧᐃ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),l1lllll_l1_+title,l1ll1ll_l1_,421,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐅ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᐆ"),html,re.DOTALL)
	if l11llll_l1_ and l111l1l1l_l1_!=l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᐇ"):
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࡠࠬࡢࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩ࡟ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᐈ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭ᐉ"),l1l111_l1_ (u"࠭ࠧᐊ"))
			if title!=l1l111_l1_ (u"ࠧࠨᐋ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐌ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨᐍ")+title,l1ll1ll_l1_,421)
	l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࠴ࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᐎ"),html,re.DOTALL)
	if l111llll1_l1_:
		l1ll1ll_l1_,title = l111llll1_l1_[0]
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐏ"),l1lllll_l1_+title,l1ll1ll_l1_,421)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᐐ"),url,l1l111_l1_ (u"࠭ࠧᐑ"),l1l111_l1_ (u"ࠧࠨᐒ"),l1l111_l1_ (u"ࠨࠩᐓ"),l1l111_l1_ (u"ࠩࠪᐔ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨᐕ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡑࡳࡼࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᐖ"),html,re.DOTALL)
	if l11llll_l1_:
		url = l11llll_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᐗ"),url,l1l111_l1_ (u"࠭ࠧᐘ"),l1l111_l1_ (u"ࠧࠨᐙ"),l1l111_l1_ (u"ࠨࠩᐚ"),l1l111_l1_ (u"ࠩࠪᐛ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠷ࡴࡤࠨᐜ"))
		html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘ࡫ࡡࡴࡱࡱࡷࡘ࡫ࡣࡵ࡫ࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨᐝ"),html,re.DOTALL)
	if l1l111_l1_ (u"ࠬ࠵ࡴࡢࡩ࠲ࠫᐞ") in url or l1l111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠭ᐟ") in url:
		l1lll11_l1_(url)
	elif l11llll_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨᐠ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢᐡ"),block,re.DOTALL)
		l11l11l11_l1_ = [l1l111_l1_ (u"่ࠩืู้ไࠨᐢ"),l1l111_l1_ (u"้ࠪํูๅࠨᐣ"),l1l111_l1_ (u"ࠫอืๆศ็ฯࠫᐤ"),l1l111_l1_ (u"ࠬำไใหࠪᐥ")]
		for l1ll1ll_l1_,title in items:
			if any(value in title for value in l11l11l11_l1_):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐦ"),l1lllll_l1_+title,l1ll1ll_l1_,423,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᐧ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᐨ"),url,l1l111_l1_ (u"ࠩࠪᐩ"),l1l111_l1_ (u"ࠪࠫᐪ"),l1l111_l1_ (u"ࠫࠬᐫ"),l1l111_l1_ (u"ࠬ࠭ᐬ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᐭ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᐮ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩᐯ")
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᐰ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᐱ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠫࠥ࠭ᐲ")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᐳ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᐴ"),l1lllll_l1_+l1l111_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭ᐵ"),url,426,l1ll1l_l1_)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᐶ"),url,l1l111_l1_ (u"ࠩࠪᐷ"),headers,l1l111_l1_ (u"ࠪࠫᐸ"),l1l111_l1_ (u"ࠫࠬᐹ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᐺ"))
	html = response.content
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᐻ"))
	l1l11ll_l1_ = l1l111l_l1_(newurl,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᐼ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡙ࡤࡸࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪᐽ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢ࠲ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᐾ"),block,re.DOTALL)
		for l11l1lll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᐿ"))
			if l1l111_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪᑀ") in title.lower(): title = l1l111_l1_ (u"ࠬิวึࠢࠪᑁ")+title
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡴࡶࡵࡹࡨࡺࡵࡳࡧ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫᑂ")+l11l1lll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᑃ")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᑄ")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬᑅ"),l1l111_l1_ (u"ࠪࠫᑆ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩᑇ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠ࠰ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᑈ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨᑉ"))
			if l1l111_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭ᑊ") in title.lower(): l1lllllll_l1_ = l1l111_l1_ (u"ࠨࡡࡢาฬ฻ࠧᑋ")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࠪᑌ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᑍ")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᑎ")+l1lllllll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢࡲࠨᑏ"),l1l111_l1_ (u"࠭ࠧᑐ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᑑ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩᑒ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪᑓ"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬᑔ"),l1l111_l1_ (u"ࠫ࠰࠭ᑕ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡓࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩᑖ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᑗ"))
	return
def l11l111l1_l1_(url):
	if l1l111_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩᑘ") not in url: url = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᑙ"))
	else: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᑚ"))[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᑛ"),url,l1l111_l1_ (u"ࠫࠬᑜ"),l1l111_l1_ (u"ࠬ࠭ᑝ"),l1l111_l1_ (u"࠭ࠧᑞ"),l1l111_l1_ (u"ࠧࠨᑟ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪᑠ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᑡ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑢ"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᑣ"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᑤ"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᑥ"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᑦ"),l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᑧ"))
	url = url.replace(l1l111_l1_ (u"ࠩࡀࠫᑨ"),l1l111_l1_ (u"ࠪ࠳ࠬᑩ")).replace(l1l111_l1_ (u"ࠫࠫ࠭ᑪ"),l1l111_l1_ (u"ࠬ࠵ࠧᑫ"))
	url = url+l1l111_l1_ (u"࠭࠯ࠨᑬ")
	return url
l1l11111_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᑭ"),l1l111_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧᑮ"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᑯ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᑰ"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᑱ"),l1l111_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᑲ"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᑳ")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠧࡀࠩᑴ") in url: url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᑵ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ᑶ"),1)
	if filter==l1l111_l1_ (u"ࠪࠫᑷ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬᑸ"),l1l111_l1_ (u"ࠬ࠭ᑹ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪᑺ"))
	if type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᑻ"):
		if l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬᑼ") in url:
			global l1l11111_l1_
			l1l11111_l1_ = l1l11111_l1_[1:]
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫᑽ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬᑾ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᑿ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨᒀ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨᒁ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪᒂ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᒃ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ᒄ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᒅ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᒆ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᒇ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩᒈ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᒉ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩᒊ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᒋ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫᒌ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᒍ")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒎ"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩᒏ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠧࠨᒐ"),l1l111_l1_ (u"ࠨࠩᒑ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᒒ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒓ"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫᒔ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫᒕ"),l1lllll1_l1_,421,l1l111_l1_ (u"࠭ࠧᒖ"),l1l111_l1_ (u"ࠧࠨᒗ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨᒘ"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᒙ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᒚ"),l1l111_l1_ (u"ࠫࠬᒛ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		if l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᒜ") in url and l1l111ll_l1_==l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᒝ"): continue
		name = name.replace(l1l111_l1_ (u"ࠧ࠮࠯ࠪᒞ"),l1l111_l1_ (u"ࠨࠩᒟ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫᒠ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᒡ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᒢ")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒣ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭ᒤ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠧࠨᒥ"),l1l111_l1_ (u"ࠨࠩᒦ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᒧ"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒨ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫᒩ"),l1lllll1_l1_,425,l1l111_l1_ (u"ࠬ࠭ᒪ"),l1l111_l1_ (u"࠭ࠧᒫ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᒬ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪᒭ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬᒮ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬᒯ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧᒰ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᒱ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒲ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩᒳ")+name,l1lllll1_l1_,424,l1l111_l1_ (u"ࠨࠩᒴ"),l1l111_l1_ (u"ࠩࠪᒵ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠵ࠪᒶ"): option = l1l111_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫᒷ")
			elif value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠵ࠬᒸ"): option = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᒹ")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᒺ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪᒻ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᒼ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬᒽ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᒾ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨᒿ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨᓀ")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪᓁ")+name
			if type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᓂ"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓃ"),l1lllll_l1_+title,url,424,l1l111_l1_ (u"ࠪࠫᓄ"),l1l111_l1_ (u"ࠫࠬᓅ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᓆ") and l1l11111_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨᓇ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᓈ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᓉ")+l11ll111_l1_
				l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓊ"),l1lllll_l1_+title,l1llllll_l1_,421,l1l111_l1_ (u"ࠪࠫᓋ"),l1l111_l1_ (u"ࠫࠬᓌ"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᓍ"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓎ"),l1lllll_l1_+title,url,425,l1l111_l1_ (u"ࠧࠨᓏ"),l1l111_l1_ (u"ࠨࠩᓐ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬᓑ"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧᓒ"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭ᓓ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧᓔ") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨᓕ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩᓖ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩᓗ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫᓘ")
		if l1l111_l1_ (u"ࠪࠩࠬᓙ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᓚ") and value!=l1l111_l1_ (u"ࠬ࠶ࠧᓛ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪᓜ")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᓝ") and value!=l1l111_l1_ (u"ࠨ࠲ࠪᓞ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫᓟ")+key+l1l111_l1_ (u"ࠪࡁࠬᓠ")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨᓡ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧᓢ")+key+l1l111_l1_ (u"࠭࠽ࠨᓣ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫᓤ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᓥ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠩࡀ࠴ࠬᓦ"),l1l111_l1_ (u"ࠪࡁࠬᓧ"))
	return l1l1l111_l1_
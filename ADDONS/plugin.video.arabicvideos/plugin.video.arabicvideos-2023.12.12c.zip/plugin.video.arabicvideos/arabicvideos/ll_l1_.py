# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䢕")
l1l1111111ll_l1_ = []
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䢖"):l1l111_l1_ (u"ࠬ࠭䢗")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䢘"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ䢙")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ䢚")+type+l1l111_l1_ (u"ࠩࠣࡡࠬ䢛"))
		l11lll1111ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䢜"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䢝"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䢞"))
		datetime = time.strftime(l1l111_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ䢟"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ䢠")+l1l11l1llll_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭䢡")+str(kodi_version)
		message = l1l111_l1_ (u"ࠩࠪ䢢")
		if key not in list(l11lll1111ll_l1_.keys()): l11lll1111ll_l1_[key] = [line]
		else:
			if url not in str(l11lll1111ll_l1_[key]): l11lll1111ll_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠪࡠࡳࠦ็ัษࠣห้็๊ะ์๋ࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣฮ฾๋ไࠨ䢣")
		total = 0
		for key in list(l11lll1111ll_l1_.keys()):
			l11lll1111ll_l1_[key] = list(set(l11lll1111ll_l1_[key]))
			total += len(l11lll1111ll_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䢤"),l1l111_l1_ (u"ࠬ࠭䢥"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䢦"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ䢧")+message+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠧ䢨")+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䢩")+l1l111_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠศๆๅหห๋ษࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥ࠭䢪")+str(total))
		if total>=5:
			l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠫࠬ䢫"),l1l111_l1_ (u"ࠬ࠭䢬"),l1l111_l1_ (u"࠭ࠧ䢭"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䢮"),l1l111_l1_ (u"ࠨษ็ฬึ์วๆฮࠣะ๊฿ࠠใษษ้ฮࠦแ๋้สࠤ࠺ࠦแ๋ัํ์์อสࠡๆ่ࠤ๏าฯࠡษ็ฬึ์วๆฮ่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬู๊อ้ࠡำ๋ࠥอไใษษ้ฮࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥหัิษ็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢๅฬ้ࠦๅิฯ๊หࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไๆสิ้ัࠦศโฯุࠤ์ึ็ࠡษ็ๅ๏ี๊้้สฮࠥลࠡࠢࠩ䢯"))
			if l1llll1l11_l1_==1:
				l11lll111l1l_l1_ = l1l111_l1_ (u"ࠩࠪ䢰")
				for key in list(l11lll1111ll_l1_.keys()):
					l11lll111l1l_l1_ += l1l111_l1_ (u"ࠪࡠࡳ࠭䢱")+key
					l1l111ll1lll_l1_ = sorted(l11lll1111ll_l1_[key],reverse=False,key=lambda l11ll1ll1lll_l1_: l11ll1ll1lll_l1_[0])
					for datetime,url in l1l111ll1lll_l1_:
						l11lll111l1l_l1_ += l1l111_l1_ (u"ࠫࡡࡴࠧ䢲")+datetime+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ䢳")+l111l11_l1_(url)
					l11lll111l1l_l1_ += l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ䢴")
				import l1l1l11l1ll_l1_
				succeeded = l1l1l11l1ll_l1_.l11l1l11lll_l1_(l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡹࠧ䢵"),l1l111_l1_ (u"ࠨࠩ䢶"),False,l1l111_l1_ (u"ࠩࠪ䢷"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䢸"),l1l111_l1_ (u"ࠫࠬ䢹"),l11lll111l1l_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䢺"),l1l111_l1_ (u"࠭ࠧ䢻"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䢼"),l1l111_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫ䢽"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䢾"),l1l111_l1_ (u"ࠪࠫ䢿"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䣀"),l1l111_l1_ (u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪ䣁"))
			if l1llll1l11_l1_!=-1:
				l11lll1111ll_l1_ = {}
				l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䣂"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䣃"))
		if l11lll1111ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䣄"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ䣅"),l11lll1111ll_l1_,l1ll111l1l1_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11ll1l1ll1l_l1_(l1ll11l1_l1_,source)
	l1l111l1lll1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䣆"))
	l11ll1ll1l11_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䣇"))
	l1l111lll1l1_l1_ = len(l1llll_l1_)-l1l111l1lll1_l1_-l11ll1ll1l11_l1_
	l11lll11l1l1_l1_ = l1l111_l1_ (u"๋ࠬิศ้าอ࠿࠭䣈")+str(l1l111l1lll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࠣฮา๋๊ๅ࠼ࠪ䣉")+str(l11ll1ll1l11_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࠤศิั๊࠼ࠪ䣊")+str(l1l111lll1l1_l1_)
	if not l1llll_l1_: result,l1l111llll11_l1_ = l1l111_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䣋"),l1l111_l1_ (u"ࠩࠪ䣌")
	else:
		while True:
			l1l111llll11_l1_ = l1l111_l1_ (u"ࠪࠫ䣍")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l11lll11l1l1_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ䣎")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ู๊ࠬาใิࠫ䣏") in title and l1l111_l1_ (u"࠭࠲ๆฮ๊์้࠸ࠧ䣐") in title:
					l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䣑"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭䣒")+title+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䣓")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭䣔"))
					import l1l1l11l1ll_l1_
					l1l1l11l1ll_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䣕")
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䣖"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡗࡪࡲࡥࡤࡶࡨࡨ࡙ࠥࡥࡳࡸࡨࡶࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䣗")+title+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䣘")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ䣙"))
					result,l1l111llll11_l1_,l1l1l1l1lll1_l1_ = l11lllll11l1_l1_(l1ll1ll_l1_,source,type)
			if l1l111_l1_ (u"ࠩ࡟ࡲࠬ䣚") not in l1l111llll11_l1_: l11lllll1111_l1_,l11ll11lll1_l1_ = l1l111llll11_l1_,l1l111_l1_ (u"ࠪࠫ䣛")
			else: l11lllll1111_l1_,l11ll11lll1_l1_ = l1l111llll11_l1_.split(l1l111_l1_ (u"ࠫࡡࡴࠧ䣜"),1)
			if result in [l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䣝"),l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䣞"),l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ䣟"),l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ䣠"),l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠶ࡹࡴࡠ࡯ࡨࡲࡺ࠭䣡")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ䣢"),l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ䣣"),l1l111_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ䣤")]: break
			elif result not in [l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䣥"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䣦")]: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䣧"),l1l111_l1_ (u"ࠩࠪ䣨"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䣩"),l1l111_l1_ (u"ࠫฬ๊ำ๋ำไี๊ࠥๅࠡ์฼้้ࠦฬาสࠣื๏ืแาࠢ฽๎ึํࠧ䣪")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣫")+l11lllll1111_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ䣬")+l11ll11lll1_l1_)
	if result==l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䣭") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䣮"),l1l111_l1_ (u"ࠩࠪ䣯"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䣰"),l1l111_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ䣱")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣲")+l1l111llll11_l1_)
	elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䣳"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䣴")] and l1l111llll11_l1_!=l1l111_l1_ (u"ࠨࠩ䣵"): l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䣶"),l1l111_l1_ (u"ࠪࠫ䣷"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䣸"),l1l111llll11_l1_)
	return result
def l11lllll11l1_l1_(url,source,type=l1l111_l1_ (u"ࠬ࠭䣹")):
	url = url.strip(l1l111_l1_ (u"࠭ࠠࠨ䣺")).strip(l1l111_l1_ (u"ࠧࠧࠩ䣻")).strip(l1l111_l1_ (u"ࠨࡁࠪ䣼")).strip(l1l111_l1_ (u"ࠩ࠲ࠫ䣽"))
	l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1ll1l_l1_(url,source)
	if l1l111llll11_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䣾"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䣿"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ䤀")
			else:
				l1l11l1l1l1l_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䤁"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭䤂")+title+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䤃")+str(l1l11l1l1l1l_l1_)+l1l111_l1_ (u"ࠩࠣࡡࠬ䤄"))
				if l1l111_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䤅") in l1l11l1l1l1l_l1_ and l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ䤆") in l1l11l1l1l1l_l1_:
					l1l11l1ll111_l1_,l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = l11lll1l1lll_l1_(l1l11l1l1l1l_l1_)
					if l1l1l1l1lll1_l1_: l1l11l1l1l1l_l1_ = l1l1l1l1lll1_l1_[0]
					else: l1l11l1l1l1l_l1_ = l1l111_l1_ (u"ࠬ࠭䤇")
				if not l1l11l1l1l1l_l1_: result = l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䤈")
				else: result = l1llll111_l1_(l1l11l1l1l1l_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ䤉"),l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ䤊"),l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭䤋")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ䤌"),l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ䤍"),l1l111_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ䤎")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䤏"),l1l111_l1_ (u"ࠧࠨ䤐"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䤑"),l1l111_l1_ (u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨ䤒"))
	else:
		result = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䤓")
		l11ll1l11l_l1_ = l1l111ll1l_l1_(url)
		if l11ll1l11l_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l111llll11_l1_,l1llll_l1_
def l11llll1l1l1_l1_(url,source):
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠫࠬ䤔"),l1l111_l1_ (u"ࠬ࠭䤕"),l1l111_l1_ (u"࠭ࠧ䤖"),l1l111_l1_ (u"ࠧࠨ䤗"),l1l111_l1_ (u"ࠨࠩ䤘"),l1l111_l1_ (u"ࠩࠪ䤙"),l1l111_l1_ (u"ࠪࠫ䤚")
	if l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䤛") in url:
		l1lllll1_l1_,l11lllll1l11_l1_ = url.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䤜"),1)
		l11lllll1l11_l1_ = l11lllll1l11_l1_+l1l111_l1_ (u"࠭࡟ࡠࠩ䤝")+l1l111_l1_ (u"ࠧࡠࡡࠪ䤞")+l1l111_l1_ (u"ࠨࡡࡢࠫ䤟")+l1l111_l1_ (u"ࠩࡢࡣࠬ䤠")
		l11lllll1l11_l1_ = l11lllll1l11_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1ll1l1ll1ll_l1_ = l11lllll1l11_l1_.split(l1l111_l1_ (u"ࠪࡣࡤ࠭䤡"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠫࠬ䤢"): l111l1ll_l1_ = l1l111_l1_ (u"ࠬ࠶ࠧ䤣")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"࠭ࡰࠨ䤤"),l1l111_l1_ (u"ࠧࠨ䤥")).replace(l1l111_l1_ (u"ࠨࠢࠪ䤦"),l1l111_l1_ (u"ࠩࠪ䤧"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠪࡃࠬ䤨")).strip(l1l111_l1_ (u"ࠫ࠴࠭䤩")).strip(l1l111_l1_ (u"ࠬࠬࠧ䤪"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡨࡰࡵࡷࠫ䤫"))
	if name: l11ll1lll111_l1_ = name
	else: l11ll1lll111_l1_ = server
	l11ll1lll111_l1_ = l1l111l_l1_(l11ll1lll111_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䤬"))
	name = name.replace(l1l111_l1_ (u"ࠨ็หหูืࠧ䤭"),l1l111_l1_ (u"ࠩࠪ䤮")).replace(l1l111_l1_ (u"ࠪื๏ืแาࠩ䤯"),l1l111_l1_ (u"ࠫࠬ䤰")).replace(l1l111_l1_ (u"ࠬอไࠡࠩ䤱"),l1l111_l1_ (u"࠭ࠠࠨ䤲")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䤳"),l1l111_l1_ (u"ࠨࠢࠪ䤴"))
	l11lllll1l11_l1_ = l11lllll1l11_l1_.replace(l1l111_l1_ (u"่ࠩฬฬฺัࠨ䤵"),l1l111_l1_ (u"ࠪࠫ䤶")).replace(l1l111_l1_ (u"ุࠫ๐ัโำࠪ䤷"),l1l111_l1_ (u"ࠬ࠭䤸")).replace(l1l111_l1_ (u"࠭วๅࠢࠪ䤹"),l1l111_l1_ (u"ࠧࠡࠩ䤺")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䤻"),l1l111_l1_ (u"ࠩࠣࠫ䤼"))
	l11ll1lll111_l1_ = l11ll1lll111_l1_.replace(l1l111_l1_ (u"้ࠪออิาࠩ䤽"),l1l111_l1_ (u"ࠫࠬ䤾")).replace(l1l111_l1_ (u"ู๊ࠬาใิࠫ䤿"),l1l111_l1_ (u"࠭ࠧ䥀")).replace(l1l111_l1_ (u"ࠧศๆࠣࠫ䥁"),l1l111_l1_ (u"ࠨࠢࠪ䥂")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䥃"),l1l111_l1_ (u"ࠪࠤࠬ䥄"))
	return l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l111l1llll_l1_(url,source):
	l1l11l111l11_l1_,name,l11ll1111l1_l1_,l11llll1l1ll_l1_,l11llll1ll11_l1_,l1l111111l11_l1_,l1l11l111111_l1_ = l1l111_l1_ (u"ࠫࠬ䥅"),l1l111_l1_ (u"ࠬ࠭䥆"),None,None,None,None,None
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll1l1l1_l1_(url,source)
	if l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䥇") in url:
		if   type==l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠭䥈"): type = l1l111_l1_ (u"ࠨࠢࠪ䥉")+l1l111_l1_ (u"่ࠩๅ฻๊ࠧ䥊")
		elif type==l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䥋"): type = l1l111_l1_ (u"ࠫࠥ࠭䥌")+l1l111_l1_ (u"ࠬࠫๅีษ๊ำฮ࠭䥍")
		elif type==l1l111_l1_ (u"࠭ࡢࡰࡶ࡫ࠫ䥎"): type = l1l111_l1_ (u"ࠧࠡࠩ䥏")+l1l111_l1_ (u"ࠨࠧࠨู้อ็ะหࠣ์ฯำๅ๋ๆࠪ䥐")
		elif type==l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䥑"): type = l1l111_l1_ (u"ࠪࠤࠬ䥒")+l1l111_l1_ (u"ࠫࠪࠫࠥหฯ่๎้࠭䥓")
		elif type==l1l111_l1_ (u"ࠬ࠭䥔"): type = l1l111_l1_ (u"࠭ࠠࠨ䥕")+l1l111_l1_ (u"ࠧࠦࠧࠨࠩࠬ䥖")
		if l111lll_l1_!=l1l111_l1_ (u"ࠨࠩ䥗"):
			if l1l111_l1_ (u"ࠩࡰࡴ࠹࠭䥘") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠪࠩࠬ䥙")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠫࠥ࠭䥚")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠬ࠭䥛"):
			l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠥࠦࠧࠨࠩࠪࠫࠥࠦࠩ䥜")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠡࠩ䥝")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䥞")		in source: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ䥟")		in source: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ䥠")
	elif l1l111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䥡")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ䥢")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ䥣")	in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ䥤")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ䥥")
	elif l1l111_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ䥦")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ䥧")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮ࠪ䥨")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡺ࠷࡮ࡧࡨࡰࠬ䥩")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭䥪")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ䥫")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䥬")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩไะึ࠭䥭")			in name:   l11ll1111l1_l1_	= l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䥮")
	elif l1l111_l1_ (u"ࠫๆ๊ำุ์้ࠫ䥯")		in name:   l11ll1111l1_l1_	= l1l111_l1_ (u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨ䥰")
	elif l1l111_l1_ (u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭䥱")		in l1lllll1_l1_:   l11ll1111l1_l1_	= l1l111_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ䥲")
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䥳")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ䥴")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䥵")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬ䥶")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䥷")	in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ䥸")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭䥹")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ䥺")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪ䥻")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䥼")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭䥽")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ䥾")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭䥿")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ䦀")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ䦁")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䦂")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࠩ䦃")	 	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ䦄")
	elif l1l111_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ䦅")	 	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ䦆")
	elif l1l111_l1_ (u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ䦇")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ䦈")
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ䦉")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬ䦊")
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䦋")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ䦌")
	elif l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䦍")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䦎")
	elif l1l111_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ䦏")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ䦐")
	elif l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭䦑")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ䦒")
	elif l1l111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䦓")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ䦔")
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䦕")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䦖")
	elif l1l111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䦗")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䦘")
	elif l1l111_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭䦙")	 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫ࠫ䦚")
	elif l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䦛")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ䦜")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ䦝")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䦞")
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ䦟")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ䦠")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ䦡")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䦢")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ䦣")
	elif l1l111_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ䦤")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䦥")
	elif l1l111_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ䦦") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭䦧")
	elif l1l111_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ䦨")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䦩")
	elif l1l111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ䦪")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭䦫")
	elif l1l111_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䦬") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䦭")
	elif l1l111_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䦮")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䦯")
	elif l1l111_l1_ (u"࠭ࡵࡱࡲࠪ䦰") 			in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭䦱")
	elif l1l111_l1_ (u"ࠨࡷࡳࡦࠬ䦲") 			in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ䦳")
	elif l1l111_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ䦴") 		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䦵")
	elif l1l111_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ䦶") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䦷")
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䦸")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䦹")
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ䦺") 		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䦻")
	elif l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䦼") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䦽")
	elif l1l111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䦾")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䦿")
	elif l1l111_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䧀")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭䧁")
	if   l11ll1111l1_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠪาฬ฻ࠧ䧂"),l11ll1111l1_l1_
	elif l1l111111l11_l1_:		l1l11l111l11_l1_,name = l1l111_l1_ (u"๋ࠫࠪอะัࠪ䧃"),l1l111111l11_l1_
	elif l11llll1l1ll_l1_:		l1l11l111l11_l1_,name = l1l111_l1_ (u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪ䧄"),l11llll1l1ll_l1_
	elif l11llll1ll11_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ䧅"),l11llll1ll11_l1_
	elif l1l11l111111_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧ䧆"),l11ll1lll111_l1_
	else:			l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩ䧇"),l11ll1lll111_l1_
	return l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l11llllll1ll_l1_(url,source):
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll1l1l1_l1_(url,source)
	if   l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䧈")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䧉")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭䧊")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ䧋")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ䧌")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111llll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ䧍")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫ䧎")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ䧏")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ䧐")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭䧑")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ䧒")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ䧓")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭䧔")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡶࡹ࠱࡫࠴ࡣࡰ࡯ࠪ䧕")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ䧖")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ䧗")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭䧘")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll111lll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ䧙")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡶࡴ࠶ࡸࠫ䧚")			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1ll11lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭䧛")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1lll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䧜")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪ䧝")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧ䧞")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ䧟")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ䧠")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1l11l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭䧡")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䧢")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭䧣")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䧤")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ䧥")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡸࡪࡩࡨࠨ䧦")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡭ࡵ࡭ࡨࡷࡩࡨ࡮ࠧ䧧")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ䧨")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡱࡥࡵࡩࡻ࡯ࡥࡸࠩ䧩")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࠨ䧪")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫ䧫")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ䧬")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ䧭"),[l1l111_l1_ (u"ࠬ࠭䧮")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ䧯")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll11_l1_(url)
	elif l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ䧰")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧ䧱")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111lllllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䧲") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䧳"),[l1l111_l1_ (u"ࠫࠬ䧴")],[l1lllll1_l1_]
	else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䧵"),[l1l111_l1_ (u"࠭ࠧ䧶")],[l1lllll1_l1_]
	return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11llll11ll1_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䧷"))
	l11llllll1l1_l1_ = False
	if   l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࠧ䧸")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ䧹")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺࠧ䧺") in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1111l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࠪ䧻")	in url: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111ll1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䧼")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ䧽")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䧾")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11l1l_l1_(url)
	elif l1l111_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䧿")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1lll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ䨀")		in url   : l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭䨁")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11l1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䨂")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111l11_l1_(url)
	elif l1l111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䨃")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1ll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭䨄")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭䨅")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ䨆")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ䨇")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䨈")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ䨉")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ䨊")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䨋")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠧ࡭࡫࡬࡭ࡻ࡯ࡤࡦࡱࠪ䨌")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡴࡨࡡࠨ䨍")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡹࡰࡦࡧࡧࠫ䨎")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ䨏") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ䨐"),[l1l111_l1_ (u"ࠬ࠭䨑")],[url]
	elif l1l111_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䨒") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllllll1l_l1_(url)
	elif l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ䨓")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111lll1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࡮࡯ࠨ䨔")in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䨕") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11ll11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ䨖")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l11l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡺࡶࡢࠨ䨗") 			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠬࡻࡰࡱࠩ䨘") 			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭䨙") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111l1l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ䨚") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䨛")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l111l_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ䨜") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111ll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ䨝") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ䨞")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l1llll_l1_(url)
	elif l1l111_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ䨟")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1ll1_l1_(url)
	else: l11llllll1l1_l1_ = True
	if l11llllll1l1_l1_ or l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䨠") in l1l111llll11_l1_:
		l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶ࠦࡆࡢ࡫࡯ࡩࡩ࠭䨡"),[],[]
	return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll1llll1_l1_(l1l1l1l1ll11_l1_):
	if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䨢") in str(type(l1l1l1l1ll11_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
			if l1l111_l1_ (u"ࠩࡶࡸࡷ࠭䨣") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡷ࠭䨤"),l1l111_l1_ (u"ࠫࠬ䨥")).replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ䨦"),l1l111_l1_ (u"࠭ࠧ䨧")).strip(l1l111_l1_ (u"ࠧࠡࠩ䨨"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1l1l1ll11_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䨩"),l1l111_l1_ (u"ࠩࠪ䨪")).replace(l1l111_l1_ (u"ࠪࡠࡳ࠭䨫"),l1l111_l1_ (u"ࠫࠬ䨬")).strip(l1l111_l1_ (u"ࠬࠦࠧ䨭"))
	return l1ll_l1_
def l1l111l1ll1l_l1_(url,source):
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䨮"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡵࡣࡵࡸࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䨯")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ䨰"))
	l1l11l111111_l1_,l1ll1ll_l1_,l11lll1lllll_l1_ = l1l111_l1_ (u"ࠩࡌࡒ࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭䨱"),l1l111_l1_ (u"ࠪࠫ䨲"),l1l111_l1_ (u"ࠫࠬ䨳")
	l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll1ll_l1_(url,source)
	l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
	if l1l111llll11_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䨴"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_: l1ll1ll_l1_ = l1llll_l1_[0]
	if l1l111llll11_l1_==l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䨵"):
		l1l11l111111_l1_ = l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶࠭䨶")
		l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11ll1_l1_(l1ll1ll_l1_,source)
		l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
		if l1l111llll11_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨷"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ䨸") in l1l111llll11_l1_:
			l11lll1lllll_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠫ䨹")+l1l111llll11_l1_
			l1l11l111111_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䨺")
			l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11l1l_l1_(l1ll1ll_l1_,source)
			l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
			if l1l111llll11_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䨻"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ䨼") in l1l111llll11_l1_:
				l11lll1lllll_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠨ䨽")+l1l111llll11_l1_
				l1l11l111111_l1_ = l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ䨾")
				l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11l11_l1_(l1ll1ll_l1_,source)
				l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
				if l1l111llll11_l1_==l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䨿"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䩀") in l1l111llll11_l1_:
					l11lll1lllll_l1_ += l1l111_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠤࠬ䩁")+l1l111llll11_l1_
	elif l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ䩂") in l1l111llll11_l1_: l11lll1lllll_l1_ = l1l111_l1_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠲࠽ࠤࠬ䩃")+l1l111llll11_l1_
	if l1llll_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䩄"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䩅")+l1l11l111111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䩆")+url+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䩇")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡻ࡬ࡵࡵ࠽ࠤࡠࠦࠧ䩈")+str(l1llll_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䩉"))
	else: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䩊"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䩋")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䩌")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡆࡴࡵࡳࡷࡹ࠺ࠡ࡝ࠣࠫ䩍")+l11lll1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭䩎"))
	l11lll1lllll_l1_ = l111l11_l1_(l11lll1lllll_l1_)
	return l11lll1lllll_l1_,l1l1lll1_l1_,l1llll_l1_
def l11ll1l1ll1l_l1_(l1l1l1l1lll1_l1_,source):
	l1l1l1llll1_l1_ = l1ll1ll1_l1_
	data = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䩏"),l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䩐"),l1l1l1l1lll1_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l111ll1l1l_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1l1l1l1lll1_l1_:
		if l1l111_l1_ (u"࠭࠯࠰ࠩ䩑") not in l1ll1ll_l1_: continue
		l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111l1llll_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ䩒"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䩓"))
		l1l111ll1l1l_l1_.append([l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l111ll1l1l_l1_:
		l11llll1111l_l1_ = sorted(l1l111ll1l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11ll1_l1_ = []
		for line in l11llll1111l_l1_:
			if line not in l11ll11ll1_l1_:
				l11ll11ll1_l1_.append(line)
		for l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11ll1_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䩔")
			title = l1l111_l1_ (u"ࠪื๏ืแาࠩ䩕")+l1l111_l1_ (u"ࠫࠥ࠭䩖")+type+l1l111_l1_ (u"ࠬࠦࠧ䩗")+l1l11l111l11_l1_+l1l111_l1_ (u"࠭ࠠࠨ䩘")+l111l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䩙")+l111lll_l1_+l1l111_l1_ (u"ࠨࠢࠪ䩚")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠩࠣࠫ䩛")+server
			title = title.replace(l1l111_l1_ (u"ࠪࠩࠬ䩜"),l1l111_l1_ (u"ࠫࠬ䩝")).strip(l1l111_l1_ (u"ࠬࠦࠧ䩞")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䩟"),l1l111_l1_ (u"ࠧࠡࠩ䩠")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䩡"),l1l111_l1_ (u"ࠩࠣࠫ䩢")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䩣"),l1l111_l1_ (u"ࠫࠥ࠭䩤"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䩥"),l1l1l1l1lll1_l1_,data,l1l1l1llll1_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l11llll11l1l_l1_(url,source):
	l1111llll11_l1_ = l1l111_l1_ (u"࠭ࠧ䩦")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l1111llll11_l1_ = str(error)
	if not l1lll_l1_:
		if l1111llll11_l1_==l1l111_l1_ (u"ࠧࠨ䩧"):
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		l1l111llll11_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠠࡇࡣ࡬ࡰࡪࡪࠧ䩨")
		l1l111llll11_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䩩")+l1111llll11_l1_.splitlines()[-1]
		return l1l111llll11_l1_,[],[]
	return l1l111_l1_ (u"ࠪࠫ䩪"),[l1l111_l1_ (u"ࠫࠬ䩫")],[l1lll_l1_]
def l11llll11l11_l1_(url,source):
	l1111llll11_l1_ = l1l111_l1_ (u"ࠬ࠭䩬")
	l1lll_l1_ = False
	try:
		import youtube_dl
		l1l1111lll1l_l1_ = youtube_dl.YoutubeDL({l1l111_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ䩭"): True})
		l1lll_l1_ = l1l1111lll1l_l1_.extract_info(url,download=False)
	except Exception as error: l1111llll11_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䩮") not in list(l1lll_l1_.keys()):
		if l1111llll11_l1_==l1l111_l1_ (u"ࠨࠩ䩯"):
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		l1l111llll11_l1_ = l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䩰")
		l1l111llll11_l1_ += l1l111_l1_ (u"ࠪࠤࠬ䩱")+l1111llll11_l1_.splitlines()[-1]
		return l1l111llll11_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ䩲")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬ䩳")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䩴")])
		return l1l111_l1_ (u"ࠧࠨ䩵"),l1l1lll1_l1_,l1llll_l1_
def l1l1111ll1l1_l1_(url):
	if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䩶") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠩࠪ䩷"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡌࡂࡔࡄࡆࠬ䩸"),[],[]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䩹"),[l1l111_l1_ (u"ࠬ࠭䩺")],[url]
def l1ll11ll1ll_l1_(url):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	if l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩ䩻") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䩼"),url,l1l111_l1_ (u"ࠨࠩ䩽"),l1l111_l1_ (u"ࠩࠪ䩾"),False,l1l111_l1_ (u"ࠪࠫ䩿"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭䪀"))
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪁") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪂")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䪃"))
			l111lll1ll_l1_.append(server)
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ䪄") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䪅"),url,l1l111_l1_ (u"ࠪࠫ䪆"),l1l111_l1_ (u"ࠫࠬ䪇"),l1l111_l1_ (u"ࠬ࠭䪈"),l1l111_l1_ (u"࠭ࠧ䪉"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ䪊"))
		html = response.content
		l1111111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ䪋"),html,re.DOTALL)
		if l1111111l1l_l1_:
			l1111111l1l_l1_ = l1111111l1l_l1_[0]
			l1ll1l1ll111_l1_ = l1ll1llll11l_l1_(l1111111l1l_l1_)
			l1ll1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠲ࠧ䪌"),l1ll1l1ll111_l1_,re.DOTALL)
			if l1ll1l11l1l1_l1_:
				l1ll1l11l1l1_l1_ = l1ll1l11l1l1_l1_[0]
				l1ll1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䪍"),l1ll1l11l1l1_l1_)
				for dict in l1ll1l11l1l1_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࠩ䪎")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ䪏")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪐"))
					l111lll1ll_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䪑")+server)
		elif l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䪒") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䪓")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䪔"))
			l111lll1ll_l1_.append(server)
		if l1l111_l1_ (u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫ䪕") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠬࡅࡵࡳ࡮ࡀࠫ䪖"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦࠨ䪗"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111lll1ll_l1_.append(l1l111_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧ䪘"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䪙"))
		l111lll1ll_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭䪚"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ䪛"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䪜"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䪝"),[l1l111_l1_ (u"࠭ࠧ䪞")],[l1ll1ll_l1_]
def l11lll1111l1_l1_(url):
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䪟"):l1l111_l1_ (u"ࠨࡍࡲࡨ࡮࠵ࠧ䪠")+str(kodi_version)}
	for l1l11l111l_l1_ in range(50):
		time.sleep(0.100)
		response = l1111llllll_l1_(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䪡"),url,l1l111_l1_ (u"ࠪࠫ䪢"),headers,False,l1l111_l1_ (u"ࠫࠬ䪣"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ䪤"))
		if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪥") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪦")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ䪧")+headers[l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䪨")]
			return l1l111_l1_ (u"ࠪࠫ䪩"),[l1l111_l1_ (u"ࠫࠬ䪪")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫ䪫"),[],[]
def l1l111111ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䪬"),url,l1l111_l1_ (u"ࠧࠨ䪭"),l1l111_l1_ (u"ࠨࠩ䪮"),l1l111_l1_ (u"ࠩࠪ䪯"),l1l111_l1_ (u"ࠪࠫ䪰"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪ䪱"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩ䪲"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"࠭ࠧ䪳"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ䪴"),[],[]
def l1llll1l1l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪵"),url,l1l111_l1_ (u"ࠩࠪ䪶"),l1l111_l1_ (u"ࠪࠫ䪷"),l1l111_l1_ (u"ࠫࠬ䪸"),l1l111_l1_ (u"ࠬ࠭䪹"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨ䪺"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䪻"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ䪼"),[l1l111_l1_ (u"ࠩࠪ䪽")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ䪾"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ䪿") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䫀"),url,l1l111_l1_ (u"࠭ࠧ䫁"),l1l111_l1_ (u"ࠧࠨ䫂"),l1l111_l1_ (u"ࠨࠩ䫃"),l1l111_l1_ (u"ࠩࠪ䫄"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪ䫅"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫆"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䫇") in l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䫈"),[l1l111_l1_ (u"ࠧࠨ䫉")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪ䫊"),[],[]
	else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䫋"),[l1l111_l1_ (u"ࠪࠫ䫌")],[url]
def l111l111l1_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䫍"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䫎"),l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䫏"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䫐")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䫑"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䫒"),l1l111_l1_ (u"ࠪࠫ䫓"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫ䫔"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䫕"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨ䫖"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䫗"),[l1l111_l1_ (u"ࠨࠩ䫘")],[l1ll1ll_l1_]
def l1ll111lll11_l1_(url):
	headers = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䫙"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䫚")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䫛"),url,l1l111_l1_ (u"ࠬ࠭䫜"),headers,l1l111_l1_ (u"࠭ࠧ䫝"),l1l111_l1_ (u"ࠧࠨ䫞"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪ䫟"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䫠"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧ䫡"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䫢"),[l1l111_l1_ (u"ࠬ࠭䫣")],[l1ll1ll_l1_]
def l1ll1lll111_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䫤"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䫥")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䫦"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䫧"),l1l111_l1_ (u"ࠪࠫ䫨"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭䫩"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ䫪"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪ䫫"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䫬") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䫭")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䫮"),[l1l111_l1_ (u"ࠪࠫ䫯")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䫰"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䫱")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䫲"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䫳"),l1l111_l1_ (u"ࠨࠩ䫴"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫ䫵"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ䫶"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡅࡇࡊࡏࠨ䫷"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫸"),[l1l111_l1_ (u"࠭ࠧ䫹")],[l1ll1ll_l1_]
def l11111l1ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䫺"),url,l1l111_l1_ (u"ࠨࠩ䫻"),l1l111_l1_ (u"ࠩࠪ䫼"),l1l111_l1_ (u"ࠪࠫ䫽"),l1l111_l1_ (u"ࠫࠬ䫾"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫ䫿"))
	html = response.content
	l11ll1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䬀"),html,re.DOTALL|re.IGNORECASE)
	if l11ll1lll1l1_l1_:
		l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_[0][2:]
		l11ll1lll1l1_l1_ = base64.b64decode(l11ll1lll1l1_l1_)
		if kodi_version>18.99: l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䬁"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬂"),l11ll1lll1l1_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䬃")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫ䬄"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䬅") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ䬆")+l1ll1ll_l1_
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䬇"),[l1l111_l1_ (u"ࠧࠨ䬈")],[l1ll1ll_l1_]
def l1l111lll1ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䬉"),url,l1l111_l1_ (u"ࠩࠪ䬊"),l1l111_l1_ (u"ࠪࠫ䬋"),l1l111_l1_ (u"ࠫࠬ䬌"),l1l111_l1_ (u"ࠬ࠭䬍"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨ䬎"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬏"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬ䬐"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䬑"),[l1l111_l1_ (u"ࠪࠫ䬒")],[l1ll1ll_l1_]
def l1l1l11l1l_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭䬓"))[-1]
	if l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ䬔") in url: url = url.replace(l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭䬕"),l1l111_l1_ (u"ࠧࠨ䬖"))
	url = url.replace(l1l111_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࠧ䬗"),l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪ䬘"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䬙"),url,l1l111_l1_ (u"ࠫࠬ䬚"),l1l111_l1_ (u"ࠬ࠭䬛"),l1l111_l1_ (u"࠭ࠧ䬜"),l1l111_l1_ (u"ࠧࠨ䬝"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭䬞"))
	html = response.content
	l1l111llll11_l1_ = l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ䬟")
	error = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬠"),html,re.DOTALL)
	if error: l1l111llll11_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬡"),html,re.DOTALL)
	if not url and l1l111llll11_l1_:
		return l1l111llll11_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ䬢"),l1l111_l1_ (u"࠭ࠧ䬣"))
	l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻ࡽࠥ࡭ࡩࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬤"),html,re.DOTALL)
	if owner: l1l1111llll1_l1_,l1l1111lll11_l1_,l1l11l11ll1l_l1_ = owner[0]
	else: l1l1111llll1_l1_,l1l1111lll11_l1_,l1l11l11ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ䬥"),l1l111_l1_ (u"ࠩࠪ䬦"),l1l111_l1_ (u"ࠪࠫ䬧")
	l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ䬨"),l1l111_l1_ (u"ࠬ࠵ࠧ䬩"))
	l1l1111lll11_l1_ = escapeUNICODE(l1l1111lll11_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ䬪")+l1l1111lll11_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䬫")]+l1l1l1l1l111_l1_
	l1llll_l1_ = [l1l11l11ll1l_l1_]+l1l1l1l1lll1_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ䬬")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"้้ࠩࠣ็ࠩࠨ䬭"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䬮"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿ࠪ䬯")+l1l11l11ll1l_l1_+l1l111_l1_ (u"ࠬࠬࡴࡦࡺࡷࡁࠬ䬰")+l1l1111lll11_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ䬱")+new_path+l1l111_l1_ (u"ࠢࠪࠤ䬲"))
		return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䬳"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠩࠪ䬴"),[l1l111_l1_ (u"ࠪࠫ䬵")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䬶"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䬷"),l1l111_l1_ (u"࠭ࠧ䬸"),l1l111_l1_ (u"ࠧࠨ䬹"),l1l111_l1_ (u"ࠨࠩ䬺"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨ䬻"))
	html = response.content
	if l1l111_l1_ (u"ࠪ࠲࡯ࡹ࡯࡯ࠩ䬼") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䬽"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬾"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧ䬿"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䭀") not in url: url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䭁")+url
	return l1l111_l1_ (u"ࠩࠪ䭂"),[l1l111_l1_ (u"ࠪࠫ䭃")],[url]
def l11lll1l1lll_l1_(url):
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䭄") : l1l111_l1_ (u"ࠬ࠭䭅") }
	if l1l111_l1_ (u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ䭆") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䭇"),headers,l1l111_l1_ (u"ࠨࠩ䭈"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫ䭉"))
		items = re.findall(l1l111_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䭊"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠫࠬ䭋"),[l1l111_l1_ (u"ࠬ࠭䭌")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䭍"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䭎"),l1l111_l1_ (u"ࠨࠩ䭏"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊วึๆํࠫ䭐"),message[0])
				return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࠫ䭑")+message[0],[],[]
	else:
		l1lllllllll_l1_ = l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧ䭒")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䭓"),headers,l1l111_l1_ (u"࠭ࠧ䭔"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩ䭕"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ䭖"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䭗"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠪ࠲ࡷࡧࡲࠨ䭘") in block or l1l111_l1_ (u"ࠫ࠳ࢀࡩࡱࠩ䭙") in block: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ䭚"),[],[]
		items = re.findall(l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䭛"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠧࠨ䭜"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ䭝"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧ䭞"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䭟"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫ䭠"),block,re.DOTALL)
		l1l111lll111_l1_,l1l1lll1_l1_,l11lllll111l_l1_,l1llll_l1_,l11llll1ll1l_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䭡") in l1ll1ll_l1_:
				l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lllll111l_l1_
				if l1l111lll111_l1_[0]==l1l111_l1_ (u"࠭࠭࠲ࠩ䭢"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䭣")+l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䭤")+l1lllllllll_l1_)
				else:
					for title in l1l111lll111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ䭥")+l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ䭦")+l1lllllllll_l1_+l1l111_l1_ (u"ࠫࠥ࠭䭧")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧ䭨"),l1l111_l1_ (u"࠭ࠧ䭩"))
				title = title.strip(l1l111_l1_ (u"ࠧࠣࠩ䭪"))
				title = l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧ䭫")+l1l111_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ䭬")+l1lllllllll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䭭")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭䭮") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䭯"),headers,l1l111_l1_ (u"࠭ࠧ䭰"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠻ࡴࡩࠩ䭱"))
		items = re.findall(l1l111_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰ࠧ䭲"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠩࠣื๏ืแาࠢอั๊๐ไࠡะสูࠥ࠭䭳")+l1l111_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ䭴")+l1lllllllll_l1_+l1l111_l1_ (u"ࠫࠥ࠭䭵")+resolution.split(l1l111_l1_ (u"ࠬࡾࠧ䭶"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ䭷")+id+l1l111_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ䭸")+mode+l1l111_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ䭹")+hash
			l11llll1ll1l_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l11llll1ll1l_l1_ = set(l11llll1ll1l_l1_)
		l1l11111l111_l1_,l1l11l1l11ll_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤ䭺"),title+l1l111_l1_ (u"ࠪࠪࠫ࠭䭻"),re.DOTALL)
			for resolution in l11llll1ll1l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠫࡽ࠭䭼"))[1])
			l1l11111l111_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨ䭽"),l1l111_l1_ (u"࠭ࠦࠧࠩ䭾")+l1l11111l111_l1_[i]+l1l111_l1_ (u"ࠧࠧࠨࠪ䭿"),re.DOTALL)
			l1l11l1l11ll_l1_.append( [l1l11111l111_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l11l1l11ll_l1_ = sorted(l1l11l1l11ll_l1_, key=lambda x: x[3], reverse=True)
		l1l11l1l11ll_l1_ = sorted(l1l11l1l11ll_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l11l1l11ll_l1_)):
			l1l1lll1_l1_.append(l1l11l1l11ll_l1_[i][0])
			l1llll_l1_.append(l1l11l1l11ll_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䮀"),[],[]
	return l1l111_l1_ (u"ࠩࠪ䮁"),l1l1lll1_l1_,l1llll_l1_
def l11ll1ll1111_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠪࡃࠬ䮂"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䮃") : l1l111_l1_ (u"ࠬ࠭䮄") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䮅"),headers,l1l111_l1_ (u"ࠧࠨ䮆"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨ䮇"))
	items = re.findall(l1l111_l1_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ䮈"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䮉"),[l1l111_l1_ (u"ࠫࠬ䮊")],[url]
def l1l1111ll1ll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䮋") : l1l111_l1_ (u"࠭ࠧ䮌") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䮍"),headers,l1l111_l1_ (u"ࠨࠩ䮎"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䮏"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䮐"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠫࠬ䮑"),[l1l111_l1_ (u"ࠬ࠭䮒")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩ䮓"),[],[]
def l11ll1ll1ll1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䮔") : l1l111_l1_ (u"ࠨࠩ䮕") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ䮖"),headers,l1l111_l1_ (u"ࠪࠫ䮗"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ䮘"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠥ࠰ࠧ࠮ࡨࡵࡶ࠱࠮ࡄ࠯ࠢࠨ䮙"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"࠭ࠧ䮚"),[l1l111_l1_ (u"ࠧࠨ䮛")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩ䮜"),[],[]
def l1llll1lll1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠩࠪ䮝")
	if l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ䮞") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䮟"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䮠")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䮡"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䮢"),l1l111_l1_ (u"ࠨࠩ䮣"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬ䮤"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䮥")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬ䮦"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬࠨࠬ䮧"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"࠭ࠧ䮨"),[l1l111_l1_ (u"ࠧࠨ䮩")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩ䮪") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䮫"),url,l1l111_l1_ (u"ࠪࠫ䮬"),l1l111_l1_ (u"ࠫࠬ䮭"),True,l1l111_l1_ (u"ࠬ࠭䮮"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ䮯"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䮰") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䮱")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䮲"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䮳") in l1lllll1_l1_ or l1l111_l1_ (u"ࠫ࠴࡬࠯ࠨ䮴") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䮵"),l1l111_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䮶"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䮷"),l1l111_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ䮸"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䮹"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䮺"),l1l111_l1_ (u"ࠫࠬ䮻"),l1l111_l1_ (u"ࠬ࠭䮼"),l1l111_l1_ (u"࠭ࠧ䮽"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪ䮾"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䮿"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ䯀"),l1l111_l1_ (u"ࠪࠫ䯁"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䯂"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ䯃"),l1l111_l1_ (u"࠭ࠧ䯄"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠨ䯅"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䯆"),[l1l111_l1_ (u"ࠩࠪ䯇")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ䯈"),[],[]
	return l1l111_l1_ (u"ࠫࠬ䯉"),l1l1lll1_l1_,l1llll_l1_
def l1ll1ll11lll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䯊"),url,l1l111_l1_ (u"࠭ࠧ䯋"),l1l111_l1_ (u"ࠧࠨ䯌"),l1l111_l1_ (u"ࠨࠩ䯍"),l1l111_l1_ (u"ࠩࠪ䯎"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪ䯏"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠫࠬ䯐")
	if l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ䯑") in url or l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ䯒") in url:
		if l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ䯓") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䯔"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ䯕") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䯖"),[l1l111_l1_ (u"ࠫࠬ䯗")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䯘"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䯙"),l1l111_l1_ (u"ࠧࠨ䯚"),l1l111_l1_ (u"ࠨࠩ䯛"),l1l111_l1_ (u"ࠩࠪ䯜"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪ䯝"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧ䯞"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䯟"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1lll1lllll1_l1_ in items:
				l1l1lll1_l1_.append(l1lll1lllll1_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨ䯠") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫ䯡"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯢"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䯣"),l1l111_l1_ (u"ࠪࠫ䯤"),l1l111_l1_ (u"ࠫࠬ䯥"),l1l111_l1_ (u"ࠬ࠭䯦"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠶ࡶࡩ࠭䯧"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䯨"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨࠩ䯩"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡱ࡯࡮࡬ࠩ䯪") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡨ࡫࡮ࡵࡧࡵࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䯫"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䯬"),[l1l111_l1_ (u"ࠬ࠭䯭")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒ࡚ࡘ࠺ࡕࠨ䯮"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䯯"),l1l1lll1_l1_,l1llll_l1_
def l1111llll_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ䯰")][0]
	headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䯱"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䯲"),url,l1l111_l1_ (u"ࠫࠬ䯳"),headers,l1l111_l1_ (u"ࠬ࠭䯴"),l1l111_l1_ (u"࠭ࠧ䯵"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡆ࠲࠸࡮ࡥࠩ䯶"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䯷"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䯸"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䯹"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦ࡫࡯࡬ࡦ࠼ࠪࠬ࠳࠰࠿ࠪࠩࠥ䯺"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䯻")+l1l11l11_l1_
		return l1l111_l1_ (u"࠭ࠧ䯼"),[l1l111_l1_ (u"ࠧࠨ䯽")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠨ䯾") in html:
		l1l11111llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯿"),html,re.DOTALL)
		if l1l11111llll_l1_:
			l1ll1ll_l1_ = l1l11111llll_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if kodi_version>18.99: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䰀"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ䰁"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࠭ࠩ䰂"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䰃")+l1l11l11_l1_
				return l1l111_l1_ (u"ࠧࠨ䰄"),[l1l111_l1_ (u"ࠨࠩ䰅")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䰆"),[l1l111_l1_ (u"ࠪࠫ䰇")],[url]
def l111llll11_l1_(url):
	l111lll1ll_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠫ࠴࠷࠯ࠨ䰈") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵࠱࠰ࠩ䰉"),l1l111_l1_ (u"࠭࠯࠵࠱ࠪ䰊"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䰋"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䰌"),l1l111_l1_ (u"ࠩࠪ䰍"),False,l1l111_l1_ (u"ࠪࠫ䰎"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭䰏"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫ䰐"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰑"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䰒"))
					l111lll1ll_l1_.append(server+l1l111_l1_ (u"ࠨࠢࠣࠫ䰓")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠩࠪ䰔"),l111lll1ll_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠪ࠳ࡩ࠵ࠧ䰕") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䰖"),url,l1l111_l1_ (u"ࠬ࠭䰗"),l1l111_l1_ (u"࠭ࠧ䰘"),l1l111_l1_ (u"ࠧࠨ䰙"),l1l111_l1_ (u"ࠨࠩ䰚"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫ䰛"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰜"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠫ࠴࠷࠯ࠨ䰝"),l1l111_l1_ (u"ࠬ࠵࠴࠰ࠩ䰞"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰟"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䰠"),l1l111_l1_ (u"ࠨࠩ䰡"),False,l1l111_l1_ (u"ࠩࠪ䰢"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࠬ䰣"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰤"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䰥"),[l1l111_l1_ (u"࠭ࠧ䰦")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ䰧"),[],[]
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䰨"),url,l1l111_l1_ (u"ࠩࠪ䰩"),l1l111_l1_ (u"ࠪࠫ䰪"),l1l111_l1_ (u"ࠫࠬ䰫"),l1l111_l1_ (u"ࠬ࠭䰬"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠶ࡹࡴࠨ䰭"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠧࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䰮"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠨࡱࡳࡁࠬ䰯")+op+l1l111_l1_ (u"ࠩࠩ࡭ࡩࡃࠧ䰰")+id+l1l111_l1_ (u"ࠪࠪ࡫ࡴࡡ࡮ࡧࡀࠫ䰱")+fname
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䰲"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䰳")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䰴"),url,data,headers,l1l111_l1_ (u"ࠧࠨ䰵"),l1l111_l1_ (u"ࠨࠩ䰶"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠳ࡰࡧࠫ䰷"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷ࡫ࡦࡦࡴࡨࡶࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰸"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䰹"),[l1l111_l1_ (u"ࠬ࠭䰺")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ䰻"),[],[]
def l11l11l1ll_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䰼"),1)[0].strip(l1l111_l1_ (u"ࠨࡁࠪ䰽")).strip(l1l111_l1_ (u"ࠩ࠲ࠫ䰾")).strip(l1l111_l1_ (u"ࠪࠪࠬ䰿"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠫࠬ䱀")
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䱁"):l1l111_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭䱂") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱃"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䱄"),headers,True,l1l111_l1_ (u"ࠩࠪ䱅"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫ䱆"))
	if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䱇") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䱈")]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䱉") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ䱊") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡩ࠳ࠬ䱋"),l1l111_l1_ (u"ࠩ࠲ࡺ࠴࠭䱌"))
		l1l11111ll11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬ䱍"))[1]
		headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱎"):headers[l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䱏")] , l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䱐"):l1l111_l1_ (u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨ䱑")+l1l11111ll11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䱒"),l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ䱓"),headers,False,l1l111_l1_ (u"ࠪࠫ䱔"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ䱕"))
		html = response.content
		if l1l111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䱖") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱗"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䱘") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱙"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠩࠪ䱚")],[ items[0] ]
		elif l1l111_l1_ (u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩ䱛") in html:
			return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧ䱜"),[],[]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨ䱝"),[],[]
def l111lllllll_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䱞"),l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䱟"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䱠")+l11l1l11_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭䱡")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䱢"):l1l111_l1_ (u"ࠫࠬ䱣") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䱤"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䱥") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䱦"),headers,l1l111_l1_ (u"ࠨࠩ䱧"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ䱨"))
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䱩"),[l1l111_l1_ (u"ࠫࠬ䱪")],[l1lllll1_l1_]
def l1lll1l11l11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䱫"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䱬"):server,l1l111_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ䱭"):l1l111_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨ䱮")}
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䱯"),url,l1l111_l1_ (u"ࠪࠫ䱰"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ䱱"),l1l111_l1_ (u"ࠬ࠭䱲"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭䱳"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨ䱴"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠨࠩ䱵")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱶"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ䱷"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠫࠬ䱸"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱹"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨ䱺"),[],[]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䱻"),[l1l111_l1_ (u"ࠨࠩ䱼")],[l1lllll1_l1_]
def l1ll1l1111ll_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䱽"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䱾"):server,l1l111_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䱿"):l1l111_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䲀")}
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲁"),url,l1l111_l1_ (u"ࠧࠨ䲂"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䲃"),l1l111_l1_ (u"ࠩࠪ䲄"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䲅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ䲆"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࠭䲇")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䲈"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ䲉"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࠩ䲊"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䲋"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡅࡄࡋࡐࡅࠬ䲌"),[],[]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䲍"),[l1l111_l1_ (u"ࠬ࠭䲎")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䲏"),l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䲐"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩ䲑"):l11l1l11_l1_,l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ䲒"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䲓"),url,data,l1l111_l1_ (u"ࠫࠬ䲔"),l1l111_l1_ (u"ࠬ࠭䲕"),l1l111_l1_ (u"࠭ࠧ䲖"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩ䲗"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲘"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䲙"),[l1l111_l1_ (u"ࠪࠫ䲚")],[l1lllll1_l1_]
def l111111ll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䲛"),url,l1l111_l1_ (u"ࠬ࠭䲜"),l1l111_l1_ (u"࠭ࠧ䲝"),l1l111_l1_ (u"ࠧࠨ䲞"),l1l111_l1_ (u"ࠨࠩ䲟"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮࠳ࡶࡸࠬ䲠"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲡"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䲢"),[l1l111_l1_ (u"ࠬ࠭䲣")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ䲤"),[],[]
def l1111l111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䲥"),url,l1l111_l1_ (u"ࠨࠩ䲦"),l1l111_l1_ (u"ࠩࠪ䲧"),l1l111_l1_ (u"ࠪࠫ䲨"),l1l111_l1_ (u"ࠫࠬ䲩"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡒ࠰࠵ࡸࡺࠧ䲪"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡊࡈࡕࡅࡒࡋࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲫"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䲬"),[l1l111_l1_ (u"ࠨࠩ䲭")],[l1ll1ll_l1_]
def l1111111l_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䲮"))
	if l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ䲯") in url:
		headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䲰"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲱"),url,l1l111_l1_ (u"࠭ࠧ䲲"),headers,l1l111_l1_ (u"ࠧࠨ䲳"),l1l111_l1_ (u"ࠨࠩ䲴"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ䲵"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䲶"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䲷") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ䲸"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ䲹"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䲺"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䲻"),headers,l1l111_l1_ (u"ࠩࠪ䲼"),l1l111_l1_ (u"ࠪࠫ䲽"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ䲾"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲿"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳀"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䳁")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠨࠩ䳂"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䳃"),[l1l111_l1_ (u"ࠪࠫ䳄")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䳅")+l11l11111_l1_
	return l1l111_l1_ (u"ࠬ࠭䳆"),[l1l111_l1_ (u"࠭ࠧ䳇")],[l1lllll1_l1_]
def l1l11111111l_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䳈"))
	if l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ䳉") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䳊"),l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䳋"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠫ࡮ࡪࠧ䳌"):l11l1l11_l1_,l1l111_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬ䳍"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䳎"),url,data,l1l111_l1_ (u"ࠧࠨ䳏"),l1l111_l1_ (u"ࠨࠩ䳐"),l1l111_l1_ (u"ࠩࠪ䳑"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ䳒"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䳓"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭䳔") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䳕"):l11l11111_l1_,l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䳖"):l1l111_l1_ (u"ࠨࠩ䳗")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䳘"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䳙"),headers,l1l111_l1_ (u"ࠫࠬ䳚"),l1l111_l1_ (u"ࠬ࠭䳛"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ䳜"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䳝"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䳞"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䳟")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠪࠫ䳠"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䳡"),[l1l111_l1_ (u"ࠬ࠭䳢")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䳣")+l11l11111_l1_
		return l1l111_l1_ (u"ࠧࠨ䳤"),[l1l111_l1_ (u"ࠨࠩ䳥")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ䳦") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䳧"),l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䳨"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䳩"))
		url = host+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ䳪")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ䳫")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䳬"):l1l111_l1_ (u"ࠩࠪ䳭") , l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䳮"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䳯") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䳰"),headers,l1l111_l1_ (u"࠭ࠧ䳱"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠷ࡳࡵࠩ䳲"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䳳"),l1l111_l1_ (u"ࠩࠪ䳴")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭䳵"),l1l111_l1_ (u"ࠫࠬ䳶"))
		return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䳷"),[l1l111_l1_ (u"࠭ࠧ䳸")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ䳹") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ䳺") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䳻"),l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䳼"),l1l111_l1_ (u"ࠫࠬ䳽"),l1l111_l1_ (u"ࠬ࠭䳾"),l1l111_l1_ (u"࠭ࠧ䳿"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩ䴀"))
			if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䴁") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䴂")]
			counts += 1
		return l1l111_l1_ (u"ࠪࠫ䴃"),[l1l111_l1_ (u"ࠫࠬ䴄")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ䴅"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䴆"))
	if l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡲࡢࡶࡨࠫ䴇") in url and l1l111_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ䴈") not in url: url = server+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ䴉")+url.split(l1l111_l1_ (u"ࠪ࠳ࠬ䴊"))[-1]+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ䴋")
	headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䴌"):server,l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䴍"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠧ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䴎") in url:
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䴏"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ䴐")}
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䴑"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠫࠬ䴒"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠵ࡸࡺࠧ䴓"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴔"),html,re.DOTALL|re.IGNORECASE)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ䴕"),[l1l111_l1_ (u"ࠨࠩ䴖")],[l1ll1ll_l1_[0]]
	elif l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ䴗") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䴘"),headers,l1l111_l1_ (u"ࠫࠬ䴙"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧ䴚"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䴛"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䴜"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䴝"))
			return l1l111_l1_ (u"ࠩࠪ䴞"),[l1l111_l1_ (u"ࠪࠫ䴟")],[l1ll1ll_l1_]
	else:
		l1l111ll111l_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䴠"),url,l1l111_l1_ (u"ࠬ࠭䴡"),headers,l1l111_l1_ (u"࠭ࠧ䴢"),l1l111_l1_ (u"ࠧࠨ䴣"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪ䴤"))
		html = l1l111ll111l_l1_.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䴥"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠪࠪࡩࡃ࠱ࠨ䴦")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䴧"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䴨"),headers,l1l111_l1_ (u"࠭ࠧ䴩"),l1l111_l1_ (u"ࠧࠨ䴪"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪ䴫"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䴬"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠪࠫ䴭"),[l1l111_l1_ (u"ࠫࠬ䴮")],[l1ll1ll_l1_]
		if l1l111_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ䴯") in list(l1l111ll111l_l1_.headers.keys()):
			cookies = l1l111ll111l_l1_.headers[l1l111_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ䴰")]
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠴ࠪࡀ࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ䴱"),cookies,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䴲"),[l1l111_l1_ (u"ࠩࠪ䴳")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧ䴴"),[],[]
def l1ll11lll1ll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠫࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠨ䴵") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䴶"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䴷")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䴸"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䴹"),headers,l1l111_l1_ (u"ࠩࠪ䴺"),l1l111_l1_ (u"ࠪࠫ䴻"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭䴼"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䴽"),[l1l111_l1_ (u"࠭ࠧ䴾")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䴿"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ䵀"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䵁"))
		url = server+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䵂")
		data = {l1l111_l1_ (u"ࠫ࡮ࡪࠧ䵃"):l11l1l11_l1_,l1l111_l1_ (u"ࠬ࡯ࠧ䵄"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䵅"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䵆"),l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䵇"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䵈"),url,data,headers,l1l111_l1_ (u"ࠪࠫ䵉"),l1l111_l1_ (u"ࠫࠬ䵊"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ䵋"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䵌"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䵍"),[l1l111_l1_ (u"ࠨࠩ䵎")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭䵏"),[],[]
def l1l111l1l1l1_l1_(l11ll1llll11_l1_):
	l1l1111l1l1l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡷࡹࡸࠧ䵐"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䵑"),l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࡣ࡛ࡋࡒࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠪ䵒"))
	headers = {l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䵓"):l1l1111l1l1l_l1_} if l1l1111l1l1l_l1_ else l1l111_l1_ (u"ࠧࠨ䵔")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䵕"),l11ll1llll11_l1_,l1l111_l1_ (u"ࠩࠪ䵖"),headers,l1l111_l1_ (u"ࠪࠫ䵗"),l1l111_l1_ (u"ࠫࠬ䵘"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠳ࡶࡸࠬ䵙"))
	l11lllll1lll_l1_ = response.content
	l1l111llllll_l1_ = str(response.headers)
	l11ll1ll111l_l1_ = l1l111llllll_l1_+l11lllll1lll_l1_
	if l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䵚") in l11ll1ll111l_l1_: found = True
	else:
		l11lll1ll1ll_l1_,token,l11ll1ll1l1l_l1_,l11llll1l11l_l1_,found = l1l111_l1_ (u"ࠧࠨ䵛"),l1l111_l1_ (u"ࠨࠩ䵜"),l1l111_l1_ (u"ࠩࠪ䵝"),l1l111_l1_ (u"ࠪࠫ䵞"),False
		l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䵟"),l11lllll1lll_l1_,re.DOTALL)
		if l11lll1l1l1l_l1_: l11ll1ll1l1l_l1_,l11llll1l11l_l1_ = l11lll1l1l1l_l1_[0]
		l11lll1l1ll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ䵠")][7]
		user = l1l1ll1l11l_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䵡"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䵢"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵣"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䵤"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䵥"):l1l111_l1_ (u"ࠫࠬ䵦"),l1l111_l1_ (u"ࠬࡰ࡯ࡣࠩ䵧"):l1l111_l1_ (u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧ䵨")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䵩"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠨࠩ䵪"),l1l111_l1_ (u"ࠩࠪ䵫"),l1l111_l1_ (u"ࠪࠫ䵬"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠳ࡰࡧࠫ䵭"))
			html = response.content
		html = l1l111_l1_ (u"ࠬ࠭䵮")
		if html.startswith(l1l111_l1_ (u"࠭ࡕࡓࡎࡖࡁࠬ䵯")):
			l1l1l1l1ll11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䵰"),html.split(l1l111_l1_ (u"ࠨࡗࡕࡐࡘࡃࠧ䵱"),1)[1])
			for request in l1l1l1l1ll11_l1_:
				url = request[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䵲")]
				method = request[l1l111_l1_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪ䵳")]
				data = request[l1l111_l1_ (u"ࠫࡩࡧࡴࡢࠩ䵴")]
				headers = request[l1l111_l1_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭䵵")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"࠭ࠧ䵶"),l1l111_l1_ (u"ࠧࠨ䵷"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ䵸"))
				l11lllll1lll_l1_ = response.content
				if l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ䵹") in l11lllll1lll_l1_:
					found = True
					break
				l1l111llllll_l1_ = str(response.headers)
				l11ll1ll111l_l1_ = l1l111llllll_l1_+l11lllll1lll_l1_
				l11lll1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫ䵺"),l11ll1ll111l_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬ䵻"),l11ll1ll111l_l1_,re.DOTALL)
				if token: token = token[0]
				if l11lll1ll1ll_l1_ or token: break
		if not found:
			if not l11lll1ll1ll_l1_:
				if not token and l11lll1l1l1l_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠬࡏࡄ࠾ࠩ䵼")):
						data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䵽"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䵾"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵿"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䶀"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䶁"):l1l111_l1_ (u"ࠫࠬ䶂"),l1l111_l1_ (u"ࠬࡰ࡯ࡣࠩ䶃"):l1l111_l1_ (u"࠭ࡧࡦࡶ࡬ࡨࠬ䶄")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䶅"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠨࠩ䶆"),l1l111_l1_ (u"ࠩࠪ䶇"),l1l111_l1_ (u"ࠪࠫ䶈"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠵ࡶ࡫ࠫ䶉"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠬࡏࡄ࠾࠳࠵࠷࠹ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀ࠸࠺࠭䶊")
					if html.startswith(l1l111_l1_ (u"࠭ࡉࡅ࠿ࠪ䶋")):
						l11ll1lll11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡊࡆࡀࠬ࠳࠰࠿ࠪ࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃࠨ࠯ࠬࡂ࠭ࠩ࠭䶌"),html,re.DOTALL)
						l1l11l11llll_l1_,l1l111ll11l_l1_ = l11ll1lll11l_l1_[0]
						message = l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ๎โห่๊ࠢࠥ࠷࠰ࠡว็ํࠥ࠭䶍")+l1l111ll11l_l1_+l1l111_l1_ (u"ࠩࠣฯฬ์๊สࠩ䶎")
						l1l111l111_l1_ = l1l11l1111_l1_()
						l1l111l111_l1_.create(l1l111_l1_ (u"้ࠪาอ่ๅหࠣฮัอ่ำࠢไัฺࠦร็ษࠣวู๋ว็ุ๋่ࠢะࠠษำ้ห๊าࠠไ๊่ฬ๏๎สาࠩ䶏"),message)
						t1 = time.time()
						l11lllllll11_l1_,l11lll11l11l_l1_ = 0,0
						while l11lllllll11_l1_<int(l1l111ll11l_l1_):
							l1l1111l11_l1_(l1l111l111_l1_,int(l11lllllll11_l1_/int(l1l111ll11l_l1_)*100),message,l1l111_l1_ (u"ࠫࠬ䶐"),l1l111ll11l_l1_+l1l111_l1_ (u"ࠬࠦ࠯ࠡࠩ䶑")+str(int(l11lllllll11_l1_))+l1l111_l1_ (u"࠭ࠠࠡอส๊๏ฯࠧ䶒"))
							if l11lllllll11_l1_>l11lll11l11l_l1_+10:
								data = {l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ䶓"):user,l1l111_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ䶔"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䶕"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠪ࡯ࡪࡿࠧ䶖"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠫ࡮ࡪࠧ䶗"):l1l11l11llll_l1_,l1l111_l1_ (u"ࠬࡰ࡯ࡣࠩ䶘"):l1l111_l1_ (u"࠭ࡧࡦࡶࡷࡳࡰ࡫࡮ࠨ䶙")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䶚"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠨࠩ䶛"),l1l111_l1_ (u"ࠩࠪ䶜"),l1l111_l1_ (u"ࠪࠫ䶝"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫ䶞"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ䶟")):
									token = html.split(l1l111_l1_ (u"࠭ࡔࡐࡍࡈࡒࡂ࠭䶠"),1)[1]
									break
								l11lll11l11l_l1_ = l11lllllll11_l1_
							else: time.sleep(1)
							l11lllllll11_l1_ = time.time()-t1
						l1l111l111_l1_.close()
				if token:
					l11ll1lll1ll_l1_ = response.cookies
					l1l1ll11lll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧ䶡"),l11ll1ll111l_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ䶢") in list(l11ll1lll1ll_l1_.keys()): l1l1ll11lll1_l1_ = l11ll1lll1ll_l1_[l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ䶣")]
					elif l1l1ll11lll1_l1_: l1l1ll11lll1_l1_ = l1l1ll11lll1_l1_[0]
					l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䶤"),l11lllll1lll_l1_,re.DOTALL)
					if l11lll1l1l1l_l1_: l11ll1ll1l1l_l1_,l11llll1l11l_l1_ = l11lll1l1l1l_l1_[0]
					if l1l1ll11lll1_l1_ and l11lll1l1l1l_l1_:
						headers = {l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䶥"):l1l111_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭䶦")+l1l1ll11lll1_l1_,l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䶧"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䶨"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䶩")}
						data = l1l111_l1_ (u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠪ䶪")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䶫"),l11ll1ll1l1l_l1_,data,headers,False,l1l111_l1_ (u"ࠫࠬ䶬"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬ䶭"))
						l11lllll1lll_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11lll1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ䶮"),str(cookies),re.DOTALL)
			if l11lll1ll1ll_l1_:
				name,l11lll1ll1ll_l1_ = l11lll1ll1ll_l1_[0]
				l1l1111l1l1l_l1_ = name+l1l111_l1_ (u"ࠧ࠾ࠩ䶯")+l11lll1ll1ll_l1_
				l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䶰"),l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࡠࡘࡈࡖࡎࡌࡉࡄࡃࡗࡍࡔࡔࠧ䶱"),l1l1111l1l1l_l1_,l1ll111l1l1_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䶲"),l1l111_l1_ (u"ࠫࠬ䶳"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䶴"),l1l111_l1_ (u"࠭ๆอฯอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤส์ำศ่ࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ๋ะววฮ๋ࠣีอࠠศๆไัฺࠦไไ์ࠣ๎ุะฮะ็๊ห๊ࠥวฮไสࠤ࠳࠴้ࠠๆสࠤฯ๎ฬะࠢะหัฯࠠๅว฼หิฯ่ࠠาสࠤฬ๊แฮื่ࠣ฾ีษࠡลื๋ึࠦ࡜࡯࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่ๆำีࠡี๋ๅࠥ๐สไำิࠤๆ๐ࠠฮษ็อࠥะฺ๋ำࠣีอ฽ࠠศๆฯ๋ฬุࠠษษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฻ๆอมࠡำส์ฯืࠠศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡใุู่ࠥไไࠢส่ึอ่หำࠣ࠲࠳ࠦร้ࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣฬึ๎ใิ์ࠪ䶵"))
				if l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ䶶") not in l11lllll1lll_l1_:
					headers = {l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䶷"):l1l1111l1l1l_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䶸"),l11ll1llll11_l1_,l1l111_l1_ (u"ࠪࠫ䶹"),headers,l1l111_l1_ (u"ࠫࠬ䶺"),l1l111_l1_ (u"ࠬ࠭䶻"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭䶼"))
					l11lllll1lll_l1_ = response.content
	if not found and not l1l1111l1l1l_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䶽"),l1l111_l1_ (u"ࠨࠩ䶾"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䶿"),l1l111_l1_ (u"ࠪ฽๊๊๊สࠢไัฺࠦร็ษࠣวู๋ว็ࠢไุ้ะࠠ࠯࠰ࠣัฬ๎ไࠡว฼หิฯࠠศๆ฼้้๐ษࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัส้ࠥ์แิࠢส่ๆ๐ฯ๋๊ࠣวํࠦแ๋ัํ์ࠥเ๊า้้๋ࠣࠦๆโีࠣห้๋่ใ฻ࠪ䷀"))
	return l11lllll1lll_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䷁"),url,l1l111_l1_ (u"ࠬ࠭䷂"),l1l111_l1_ (u"࠭ࠧ䷃"),l1l111_l1_ (u"ࠧࠨ䷄"),l1l111_l1_ (u"ࠨࠩ䷅"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨ䷆"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠾࠲ࡥࡃ࠭䷇"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ䷈"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭䷉") not in l1ll1ll_l1_ and l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ䷊") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨ䷋"),l1l111_l1_ (u"ࠨࠩ䷌")).replace(l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䷍"),l1l111_l1_ (u"ࠪࠫ䷎")).strip(l1l111_l1_ (u"ࠫࠥ࠭䷏")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䷐"),l1l111_l1_ (u"࠭ࠠࠨ䷑"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111lll1ll_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧษ฻ู๋ฬ๊ࠦฮฬสะࠥ࠼࠰ࠡอส๊๏ฯࠧ䷒"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ䷓"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ䷔"),[],[]
	l11ll1llll11_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l11lllll1lll_l1_ = l1l111l1l1l1_l1_(l11ll1llll11_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䷕"):
		l1l111l1111l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡧࡺ࡮࠮࡮ࡲࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷖"),l11lllll1lll_l1_,re.DOTALL)
		if l1l111l1111l_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l111l1111l_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䷗"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷘"),l11lllll1lll_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䷙"),[],[]
	return l1l111_l1_ (u"ࠨࠩ䷚"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䷛"),url,l1l111_l1_ (u"ࠪࠫ䷜"),l1l111_l1_ (u"ࠫࠬ䷝"),True,l1l111_l1_ (u"ࠬ࠭䷞"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ䷟"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ䷠") in list(cookies.keys()):
		l1l1111l1l1l_l1_ = cookies[l1l111_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ䷡")]
		l1l1111l1l1l_l1_ = l111l11_l1_(escapeUNICODE(l1l1111l1l1l_l1_))
		items = re.findall(l1l111_l1_ (u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䷢"),l1l1111l1l1l_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠪࡠ࠴࠭䷣"),l1l111_l1_ (u"ࠫ࠴࠭䷤"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䷥") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"࠭ࠥ࠳ࡈࠪ䷦"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ䷧")+id
		return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䷨"),[l1l111_l1_ (u"ࠩࠪ䷩")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䷪")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䷫"),l1l11l11_l1_,l1l111_l1_ (u"ࠬ࠭䷬"),l1l111_l1_ (u"࠭ࠧ䷭"),True,l1l111_l1_ (u"ࠧࠨ䷮"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ䷯"))
		l11llll1l111_l1_ = response.url
		l1l11l11ll11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䷰"))[2]
		l1l11l1ll11l_l1_ = l11llll1l111_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ䷱"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l11l11ll11_l1_,l1l11l1ll11l_l1_)
		headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䷲"):l1l111_l1_ (u"ࠬ࠭䷳") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䷴"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䷵") , l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䷶"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䷷"), l1llllll_l1_, l1l111_l1_ (u"ࠪࠫ䷸"), headers, False,l1l111_l1_ (u"ࠫࠬ䷹"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫ䷺"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷻"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷼"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷽"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䷾"),l1l111_l1_ (u"ࠪ࠳ࠬ䷿"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠫ࠴࠭一"))
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ丁") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ丂") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ七"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ丄"))
			if name==l1l111_l1_ (u"ࠩࠪ丅"): l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ丆"),[l1l111_l1_ (u"ࠫࠬ万")],[l1ll1ll_l1_]
			else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ丈"),[l1l111_l1_ (u"࠭ࠧ三")],[l1ll1ll_l1_]
		else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏࡔࡇࡍࠨ上"),[],[]
		return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll11ll11_l1_(url):
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ下") : l1l111_l1_ (u"ࠩࠪ丌") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ不"),headers,l1l111_l1_ (u"ࠫࠬ与"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ丏"))
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ丐"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠧࠨ丑")
	if items:
		for l1ll1ll_l1_,l1lll1lllll1_l1_ in items:
			l1l1lll1_l1_.append(l1lll1lllll1_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧ丒"),[],[]
	return l1l111_l1_ (u"ࠩࠪ专"),l1l1lll1_l1_,l1llll_l1_
def l1l111111l1l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ且"),l1l111_l1_ (u"ࠫࠬ丕"))
	headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ世"):l1l111_l1_ (u"࠭ࠧ丗")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ丘"),headers,l1l111_l1_ (u"ࠨࠩ丙"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ业"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ丛"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ东")+url
		return l1l111_l1_ (u"ࠬ࠭丝"),[l1l111_l1_ (u"࠭ࠧ丞")],[url]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩ丟"),[],[]
def l11lllll1l1l_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠨ࠱ࠪ丠"))
	if l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ両") in url: id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ丢"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠫ࠴࠭丣"))[-1]
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩ两") + id
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ严") : l1l111_l1_ (u"ࠧࠨ並") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ丧"),headers,l1l111_l1_ (u"ࠩࠪ丨"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡄࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ丩"))
	html = html.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ个"),l1l111_l1_ (u"ࠬ࠭丫"))
	items = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丬"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ中"),[l1l111_l1_ (u"ࠨࠩ丮")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭丯"),[],[]
def l11llll111ll_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ丰"),l1l111_l1_ (u"ࠫࠬ丱"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭串"),l1l111_l1_ (u"࠭ࠧ丳"),l1l111_l1_ (u"ࠧࠨ临"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡐ࡜ࡄ࠱࠶ࡹࡴࠨ丵"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࡷ࡫ࡳ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ丶"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1lll1lllll1_l1_,res in items:
		l1l1lll1_l1_.append(l1lll1lllll1_l1_+l1l111_l1_ (u"ࠪࠤࠬ丷")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭丸"),[],[]
	return l1l111_l1_ (u"ࠬ࠭丹"),l1l1lll1_l1_,l1llll_l1_
def l1l11111ll1l_l1_(url):
	url = url.replace(l1l111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭为"),l1l111_l1_ (u"ࠧࠨ主"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ丼"),l1l111_l1_ (u"ࠩࠪ丽"),l1l111_l1_ (u"ࠪࠫ举"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ丿"))
	items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥ乀"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1lll1lllll1_l1_,res in items:
		url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ乁")+id+l1l111_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ乂")+mode+l1l111_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ乃")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ乄"),l1l111_l1_ (u"ࠪࠫ久"),l1l111_l1_ (u"ࠫࠬ乆"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ乇"))
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ么"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1lll1lllll1_l1_+l1l111_l1_ (u"ࠧࠡࠩ义")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧ乊"),[],[]
	return l1l111_l1_ (u"ࠩࠪ之"),l1l1lll1_l1_,l1llll_l1_
def l11lll1l1l11_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠪࠫ乌")
	if 1 or l1l111_l1_ (u"ࠫࡐ࡫ࡹ࠾ࠩ乍") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩ乎"),l1l111_l1_ (u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪ乏"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ乐"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠨ࠱ࠪ乑").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠩ࡬ࡨࠬ乒"):id,l1l111_l1_ (u"ࠪࡳࡵ࠭乓"):l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ乔"),l1l111_l1_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ乕"):l1l111_l1_ (u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭乖")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ乗"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠨࠩ乘"),l1l111_l1_ (u"ࠩࠪ乙"),l1l111_l1_ (u"ࠪࠫ乚"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ乛"))
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ乜") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ九")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ乞"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ也"),url,l1l111_l1_ (u"ࠩࠪ习"),l1l111_l1_ (u"ࠪࠫ乡"),l1l111_l1_ (u"ࠫࠬ乢"),l1l111_l1_ (u"ࠬ࠭乣"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ乤"))
		if l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ乥") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ书")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࠪ乧"),[l1l111_l1_ (u"ࠪࠫ乨")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ乩"),[],[]
def l11lllllll1l_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ乪") : l1l111_l1_ (u"࠭ࠧ乫") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ乬"),headers,l1l111_l1_ (u"ࠨࠩ乭"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ乮"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩ乯"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠨ买"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ乱"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"࠭ࠧ乲"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫ乳"),[],[]
def l11lll1l1ll_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ乴"))[-1]
	id = id.split(l1l111_l1_ (u"ࠩࠩࠫ乵"))[0]
	id = id.replace(l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ乶"),l1l111_l1_ (u"ࠫࠬ乷"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭乸")][0]+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ乹")+id
	l11lll1ll1l1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ乺")+id
	l1l111l1ll11_l1_,l11llll11111_l1_,l1l1111l1l11_l1_,l11lllll1ll1_l1_ = l1l111_l1_ (u"ࠨࠩ乻"),l1l111_l1_ (u"ࠩࠪ乼"),l1l111_l1_ (u"ࠪࠫ乽"),l1l111_l1_ (u"ࠫࠬ乾")
	for l1l11l111l_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ乿"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ亀"),l1l111_l1_ (u"ࠧࠨ亁"),l1l111_l1_ (u"ࠨࠩ亂"),l1l111_l1_ (u"ࠩࠪ亃"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ亄"))
		html = response.content
		if l1l111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ亅") in html: break
		time.sleep(2)
	l1l1l111l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ了"),html,re.DOTALL)
	if l1l1l111l1_l1_: l1l1l111l1_l1_ = l1l1l111l1_l1_[0]
	else: l1l1l111l1_l1_ = html
	l1l1l111l1_l1_ = l1l1l111l1_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ亇"),l1l111_l1_ (u"ࠧࠧࠩ予"))
	l1l111llll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭争"),l1l1l111l1_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭亊")],[l1l111_l1_ (u"ࠪࠫ事")]
	try:
		l1l11l1l1lll_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭二")][l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ亍")][l1l111_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭于")]
		for l1l11111l1ll_l1_ in l1l11l1l1lll_l1_:
			l1ll1ll_l1_ = l1l11111l1ll_l1_[l1l111_l1_ (u"ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠨ亏")]
			try: title = l1l11111l1ll_l1_[l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭亐")][l1l111_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭云")]
			except: title = l1l11111l1ll_l1_[l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ互")][l1l111_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ亓")][0][l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ五")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨ井"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ亖"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠨࠨࠪ亗")
			l1l111111111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠩࠬ࡫ࡳࡴ࠾࠰࠭ࡃ࠮ࠬࠧ亘"),l1ll1ll_l1_)
			if l1l111111111_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111111111_l1_[0],l1l111_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ亙"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ亚")
			l1l111l1ll11_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ些"))
	formats,l1l111lllll1_l1_,l11lll1l1111_l1_,l11lll1l111l_l1_,l11lll11llll_l1_ = [],[],[],[],[]
	try: l11llll11111_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭亜")][l1l111_l1_ (u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ亝")]
	except: pass
	try: l1l1111l1l11_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ亞")][l1l111_l1_ (u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ亟")]
	except: pass
	try: formats = l1l111llll1l_l1_[l1l111_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ亠")][l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ亡")]
	except: pass
	try: l1l111lllll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ亢")][l1l111_l1_ (u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨ亣")]
	except: pass
	l1l111l1l1ll_l1_ = formats+l1l111lllll1_l1_
	for dict in l1l111l1l1ll_l1_:
		if l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ交") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭亥")] = str(dict[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ亦")])
		if l1l111_l1_ (u"ࠪࡪࡵࡹࠧ产") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ亨")] = str(dict[l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ亩")])
		if l1l111_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ亪") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ享")] = dict[l1l111_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ京")]
		if l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ亭") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ亮")] = str(dict[l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭亯")])
		if l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ亰") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ亱")] = str(dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ亲")])
		if l1l111_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ亳") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ亴")] = str(dict[l1l111_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ亵")])+l1l111_l1_ (u"ࠫࡽ࠭亶")+str(dict[l1l111_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ亷")])
		if l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ亸") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ亹")] = dict[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ人")][l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ亻")]+l1l111_l1_ (u"ࠪ࠱ࠬ亼")+dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ亽")][l1l111_l1_ (u"ࠬ࡫࡮ࡥࠩ亾")]
		if l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ亿") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭什")] = dict[l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ仁")][l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ仂")]+l1l111_l1_ (u"ࠪ࠱ࠬ仃")+dict[l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ仄")][l1l111_l1_ (u"ࠬ࡫࡮ࡥࠩ仅")]
		if l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ仆") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仇")] = dict[l1l111_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ仈")]
		if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ仉") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ今")])>111222333: del dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ介")]
		if l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ仌") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ仍")].split(l1l111_l1_ (u"ࠧࠧࠩ从"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ仏"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仐") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ仑")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ仒")])
		l11lll1l1111_l1_.append(dict)
	l1l1111ll111_l1_ = l1l111_l1_ (u"ࠬ࠭仓")
	if l1l111_l1_ (u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭仔") in l1l1l111l1_l1_:
		l1l111ll1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭仕"),html,re.DOTALL)
		if l1l111ll1l11_l1_:
			l1l111ll1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ他")][0]+l1l111ll1l11_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭仗"),l1l111ll1l11_l1_,l1l111_l1_ (u"ࠪࠫ付"),l1l111_l1_ (u"ࠫࠬ仙"),l1l111_l1_ (u"ࠬ࠭仚"),l1l111_l1_ (u"࠭ࠧ仛"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨ仜"))
			l1l1111ll111_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11ll1lllll1_l1_ = cipher._load_javascript(l1l1111ll111_l1_)
			l11lll1lll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ仝"),str(l11ll1lllll1_l1_))
			l11lll111111_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11lll1lll1l_l1_)
	for dict in l11lll1l1111_l1_:
		url = dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仞")]
		if l1l111_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧ仟") in url or url.count(l1l111_l1_ (u"ࠫࡸ࡯ࡧ࠾ࠩ仠"))>1:
			l11lll1l111l_l1_.append(dict)
		elif l1l1111ll111_l1_ and l1l111_l1_ (u"ࠬࡹࠧ仡") in list(dict.keys()) and l1l111_l1_ (u"࠭ࡳࡱࠩ仢") in list(dict.keys()):
			l1l11111l11l_l1_ = l11lll111111_l1_.execute(dict[l1l111_l1_ (u"ࠧࡴࠩ代")])
			if l1l11111l11l_l1_!=dict[l1l111_l1_ (u"ࠨࡵࠪ令")]:
				dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭以")] = url+l1l111_l1_ (u"ࠪࠪࠬ仦")+dict[l1l111_l1_ (u"ࠫࡸࡶࠧ仧")]+l1l111_l1_ (u"ࠬࡃࠧ仨")+l1l11111l11l_l1_
				l11lll1l111l_l1_.append(dict)
	for dict in l11lll1l111l_l1_:
		l111lll_l1_,l11lll111ll1_l1_,l1l11l1l1l11_l1_,l1l1l1ll1_l1_,codecs,l11ll1l11ll_l1_ = l1l111_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ仩"),l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ仪"),l1l111_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ仫"),l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ们"),l1l111_l1_ (u"ࠪࠫ仭"),l1l111_l1_ (u"ࠫ࠵࠭仮")
		try:
			l11lll1l11l1_l1_ = dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪ仯")]
			l11lll1l11l1_l1_ = l11lll1l11l1_l1_.replace(l1l111_l1_ (u"࠭ࠫࠨ仰"),l1l111_l1_ (u"ࠧࠨ仱"))
			items = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ仲"),l11lll1l11l1_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l111ll11l1_l1_ = codecs.split(l1l111_l1_ (u"ࠩ࠯ࠫ仳"))
			l11lll111ll1_l1_ = l1l111_l1_ (u"ࠪࠫ仴")
			for item in l1l111ll11l1_l1_: l11lll111ll1_l1_ += item.split(l1l111_l1_ (u"ࠫ࠳࠭仵"))[0]+l1l111_l1_ (u"ࠬ࠲ࠧ件")
			l11lll111ll1_l1_ = l11lll111ll1_l1_.strip(l1l111_l1_ (u"࠭ࠬࠨ价"))
			if l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仸") in list(dict.keys()): l11ll1l11ll_l1_ = str(float(dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ仹")]*10)//1024/10)+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ仺")
			else: l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠪࠫ任")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ仼"): continue
			elif l1l111_l1_ (u"ࠬ࠲ࠧ份") in l11lll1l11l1_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ仾")
				l1l11l1l1l11_l1_ = l111lll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪ仿")+l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭伀")].split(l1l111_l1_ (u"ࠩࡻࠫ企"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ伂"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ伃")
				l1l11l1l1l11_l1_ = l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ伄")].split(l1l111_l1_ (u"࠭ࡸࠨ伅"))[1]+l1l111_l1_ (u"ࠧࠡࠢࠪ伆")+dict[l1l111_l1_ (u"ࠨࡨࡳࡷࠬ伇")]+l1l111_l1_ (u"ࠩࡩࡴࡸ࠭伈")+l1l111_l1_ (u"ࠪࠤࠥ࠭伉")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ伊"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ伋")
				l1l11l1l1l11_l1_ = l11ll1l11ll_l1_+str(int(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ伌")])/1000)+l1l111_l1_ (u"ࠧ࡬ࡪࡽࠤࠥ࠭伍")+dict[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ伎")]+l1l111_l1_ (u"ࠩࡦ࡬ࠬ伏")+l1l111_l1_ (u"ࠪࠤࠥ࠭伐")+l111lll_l1_
		except:
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		if l1l111_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ休") in dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ伒")]: l1l1lll1ll_l1_ = round(0.5+float(dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ伓")].split(l1l111_l1_ (u"ࠧࡥࡷࡵࡁࠬ伔"),1)[1].split(l1l111_l1_ (u"ࠨࠨࠪ伕"),1)[0]))
		elif l1l111_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ伖") in list(dict.keys()): l1l1lll1ll_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭众")])/1000)
		else: l1l1lll1ll_l1_ = l1l111_l1_ (u"ࠫ࠵࠭优")
		if l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伙") not in list(dict.keys()): l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"࠭ࡳࡪࡼࡨࠫ会")].split(l1l111_l1_ (u"ࠧࡹࠩ伛"))[1]
		else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伜")]
		if l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ伝") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ伞")] = l1l111_l1_ (u"ࠫ࠵࠳࠰ࠨ伟")
		dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ传")] = l1l1l1ll1_l1_+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ伡")+l1l11l1l1l11_l1_+l1l111_l1_ (u"ࠧࠡࠢࠫࠫ伢")+l11lll111ll1_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ伣")+dict[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ伤")]+l1l111_l1_ (u"ࠪ࠭ࠬ伥")
		dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ伦")] = l1l11l1l1l11_l1_.split(l1l111_l1_ (u"ࠬࠦࠠࠨ伧"))[0].split(l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ伨"))[0]
		dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭伩")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伪")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ伫")] = codecs
		dict[l1l111_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ伬")] = l1l1lll1ll_l1_
		dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伭")] = l11ll1l11ll_l1_
		l11lll11llll_l1_.append(dict)
	l1l111l1l111_l1_,l11llllllll1_l1_,l1l11l11l1l1_l1_,l1l11l1l1111_l1_,l11ll1ll11l1_l1_ = [],[],[],[],[]
	l1l111ll11ll_l1_,l11lll1ll11l_l1_,l11lll1lll11_l1_,l1l111ll1111_l1_,l1l11l1111ll_l1_ = [],[],[],[],[]
	if l11llll11111_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ伮")] = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ伯")
		dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ估")] = l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ伱")
		dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ伲")] = dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ伳")]+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ伴")+dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ伵")]+l1l111_l1_ (u"࠭ࠠࠡࠩ伶")+l1l111_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ伷")
		dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ伸")] = l11llll11111_l1_
		dict[l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ伹")] = l1l111_l1_ (u"ࠪ࠴ࠬ伺")
		dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伻")] = l1l111_l1_ (u"ࠬ࠿࠸࠸࠸࠸࠸࠸࠸࠱࠱ࠩ似")
		l11lll11llll_l1_.append(dict)
	if l1l1111l1l11_l1_:
		l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1l1111l1l11_l1_)
		l1l1111l1111_l1_ = list(zip(l1l111lll111_l1_,l11lllll111l_l1_))
		for title,l1ll1ll_l1_ in l1l1111l1111_l1_:
			dict = {}
			dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伽")] = l1l111_l1_ (u"ࠧࡂ࡙࠭ࠫ伾")
			dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伿")] = l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ佀")
			dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ佁")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠩ佂") in title: dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佃")] = title.split(l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ佄"))[0].rsplit(l1l111_l1_ (u"ࠧࠡࠢࠪ佅"))[-1]
			else: dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ但")] = l1l111_l1_ (u"ࠩ࠴࠴ࠬ佇")
			if title.count(l1l111_l1_ (u"ࠪࠤࠥ࠭佈"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠫࠥࠦࠧ佉"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭佊")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ佋")] = l1l111_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ佌")
			if title==l1l111_l1_ (u"ࠨ࠯࠴ࠫ位"): dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ低")] = dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ住")]+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ佐")+dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ佑")]+l1l111_l1_ (u"࠭ࠠࠡࠩ佒")+l1l111_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ体")
			else: dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ佔")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ何")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ佖")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佗")]+l1l111_l1_ (u"ࠬࠦࠠࠨ佘")+dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ余")]+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ佚")+dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ佛")]
			l11lll11llll_l1_.append(dict)
	l11lll11llll_l1_ = sorted(l11lll11llll_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ作")]))
	if not l11lll11llll_l1_:
		l1lll1l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡹࡳࡢࡩࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ佝"),html,re.DOTALL)
		l1lll1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࡢࡻࠣࡴࡸࡲࡸࠨ࠺࡝࡝࡟ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ佞"),html,re.DOTALL)
		l1l111l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ佟"),html,re.DOTALL)
		l1l111l11l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ你"),html,re.DOTALL)
		try: l11ll1l1lll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ佡")][l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭佢")][l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ佣")][l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ佤")][l1l111_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ佥")][0][l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ佦")]
		except: l11ll1l1lll1_l1_ = l1l111_l1_ (u"࠭ࠧ佧")
		try: l1l111l11ll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ佨")][l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭佩")][l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ佪")][l1l111_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡐࡩࡸࡹࡡࡨࡧࡶࠫ佫")][0][l1l111_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ佬")][0][l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ佭")]
		except: l1l111l11ll1_l1_ = l1l111_l1_ (u"࠭ࠧ佮")
		try: l1l111l11lll_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ佯")][l1l111_l1_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨ佰")]
		except: l1l111l11lll_l1_ = l1l111_l1_ (u"ࠩࠪ佱")
		if l1lll1l1ll1_l1_ or l1lll1l1lll_l1_ or l1l111l111ll_l1_ or l1l111l11l11_l1_ or l11ll1l1lll1_l1_ or l1l111l11ll1_l1_ or l1l111l11lll_l1_:
			if   l1lll1l1ll1_l1_: message = l1lll1l1ll1_l1_[0]
			elif l1lll1l1lll_l1_: message = l1lll1l1lll_l1_[0]
			elif l1l111l111ll_l1_: message = l1l111l111ll_l1_[0]
			elif l1l111l11l11_l1_: message = l1l111l11l11_l1_[0]
			elif l11ll1l1lll1_l1_: message = l11ll1l1lll1_l1_
			elif l1l111l11ll1_l1_: message = l1l111l11ll1_l1_
			elif l1l111l11lll_l1_: message = l1l111l11lll_l1_
			l1l11l1l11l1_l1_ = message.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭佲"),l1l111_l1_ (u"ࠫࠬ佳")).strip(l1l111_l1_ (u"ࠬࠦࠧ佴"))
			l1l11l1l111l_l1_ = l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้ำหࠥอไโ์า๎ํࠦแู๋้้้ࠣไส๋ࠢๆิ๊ࠦไ๊้ࠤ฿๐ัࠡ็็หห๋ࠠๅส฼ฺࠥอไๆีอาิ๋๊็ࠢฦ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ併")
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ佶"),l1l111_l1_ (u"ࠨࠩ佷"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭佸"),l1l11l1l111l_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ佹")+l1l11l1l11l1_l1_)
			return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧ࠾ࠥ࠭佺")+l1l11l1l11l1_l1_,[],[]
		else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ佻"),[],[]
	l11lll111lll_l1_,l11lll11l111_l1_,l1l1111111l1_l1_ = [],[],[]
	for dict in l11lll11llll_l1_:
		if dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ佼")]==l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭佽"):
			l1l111l1l111_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ佾")])
			l1l111ll11ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ使")]==l1l111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ侀"):
			l11llllllll1_l1_.append(dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ侁")])
			l11lll1ll11l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侂")]==l1l111_l1_ (u"࠭࡭ࡱࡦࠪ侃"):
			title = dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭侄")].replace(l1l111_l1_ (u"ࠨࡃ࠮࡚࠿ࠦࠠࠨ侅"),l1l111_l1_ (u"ࠩࠪ來"))
			if l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ侇") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠫ࠵࠭侈")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭侉")]
			l11lll111lll_l1_.append([dict,{},title,l11ll1l11ll_l1_])
		else:
			title = dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侊")].replace(l1l111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ例"),l1l111_l1_ (u"ࠨࠩ侌"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ侍") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ侎")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ侏")]
			l11lll111lll_l1_.append([dict,{},title,l11ll1l11ll_l1_])
			l1l11l11l1l1_l1_.append(title)
			l11lll1lll11_l1_.append(dict)
		l1l1111ll11l_l1_ = True
		if l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ侐") in list(dict.keys()):
			if l1l111_l1_ (u"࠭ࡡࡷ࠲ࠪ侑") in dict[l1l111_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ侒")]: l1l1111ll11l_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠨࡣࡹࡧࠬ侓") not in dict[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ侔")] and l1l111_l1_ (u"ࠪࡱࡵ࠺ࡡࠨ侕") not in dict[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ侖")]: l1l1111ll11l_l1_ = False
		if dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ侗")]==l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ侘") and dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ侙")]!=l1l111_l1_ (u"ࠨ࠲࠰࠴ࠬ侚") and l1l1111ll11l_l1_==True:
			l11ll1ll11l1_l1_.append(dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ供")])
			l1l11l1111ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ侜")]==l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ依") and dict[l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ侞")]!=l1l111_l1_ (u"࠭࠰࠮࠲ࠪ侟") and l1l1111ll11l_l1_==True:
			l1l11l1l1111_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭侠")])
			l1l111ll1111_l1_.append(dict)
	for l1l1111l1ll1_l1_ in l1l111ll1111_l1_:
		l1l11l1l1ll1_l1_ = l1l1111l1ll1_l1_[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ価")]
		for l1l111l111l1_l1_ in l1l11l1111ll_l1_:
			l1l11l1ll1ll_l1_ = l1l111l111l1_l1_[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ侢")]
			l11ll1l11ll_l1_ = l1l11l1ll1ll_l1_+l1l11l1l1ll1_l1_
			title = l1l111l111l1_l1_[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ侣")].replace(l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠥ࠭侤"),l1l111_l1_ (u"ࠬࡳࡰࡥࠢࠣࠫ侥"))
			title = title.replace(l1l111l111l1_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ侦")]+l1l111_l1_ (u"ࠧࠡࠢࠪ侧"),l1l111_l1_ (u"ࠨࠩ侨"))
			title = title.replace(str((float(l1l11l1ll1ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ侩"),str((float(l11ll1l11ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ侪"))
			title = title+l1l111_l1_ (u"ࠫ࠭࠭侫")+l1l1111l1ll1_l1_[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ侬")].split(l1l111_l1_ (u"࠭ࠨࠨ侭"),1)[1]
			l11lll111lll_l1_.append([l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_])
	l11lll111lll_l1_ = sorted(l11lll111lll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_ in l11lll111lll_l1_:
		l11lll11l1ll_l1_ = l1l111l111l1_l1_[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ侮")]
		if l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ侯") in list(l1l1111l1ll1_l1_.keys()):
			l11lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡰࡴࡩ࠭侰")
		if l11lll11l1ll_l1_ not in l1l1111111l1_l1_:
			l1l1111111l1_l1_.append(l11lll11l1ll_l1_)
			l11lll11l111_l1_.append([l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_])
	l11ll1llll1l_l1_,l1l111lll11l_l1_,shift = [],[],0
	l1l1111lll11_l1_,l1l11l1111l1_l1_ = l1l111_l1_ (u"ࠪࠫ侱"),l1l111_l1_ (u"ࠫࠬ侲")
	try: l1l1111lll11_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ侳")][l1l111_l1_ (u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭侴")]
	except: l1l1111lll11_l1_ = l1l111_l1_ (u"ࠧࠨ侵")
	try: l11llllll11l_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ侶")][l1l111_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ侷")]
	except: l11llllll11l_l1_ = l1l111_l1_ (u"ࠪࠫ侸")
	if l1l1111lll11_l1_ and l11llllll11l_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ侹")+l1l1111lll11_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ侺")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ侻")][0]+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ侼")+l11llllll11l_l1_
		l11ll1llll1l_l1_.append(title)
		l1l111lll11l_l1_.append(l1ll1ll_l1_)
		try: l1l11l1111l1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ侽")][l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ侾")][l1l111_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ便")][-1][l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俀")]
		except: pass
	for l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_ in l11lll11l111_l1_:
		l11ll1llll1l_l1_.append(title) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭俁"))
	if l1l11l11l1l1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"࠭ี้ำฬࠤํ฻่ห่ࠢัิีษࠨ係")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭促"))
	if l11lll111lll_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤฬ๊ๅห๊ไีࠬ俄")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠩࡤࡰࡱ࠭俅"))
	if l11ll1ll11l1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠪࡱࡵࡪࠠศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬ俆")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠫࡲࡶࡤࠨ俇"))
	if l1l111l1l111_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣฬิ๎ๆࠡื๋ฮࠬ俈")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ俉"))
	if l11llllllll1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠧึ๊อࠤอี่็ุࠢ์ึฯࠧ俊")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ俋"))
	l1l11l11lll1_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l11lll1ll1l1_l1_, l11ll1llll1l_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ俌"),[],[]
		elif l11l11l_l1_==0 and l1l1111lll11_l1_:
			l1ll1ll_l1_ = l1l111lll11l_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠲࠶࠴ࠪࡳࡧ࡭ࡦ࠿ࠪ俍")+QUOTE(l1l1111lll11_l1_)+l1l111_l1_ (u"ࠫࠫࡻࡲ࡭࠿ࠪ俎")+l1ll1ll_l1_
			if l1l11l1111l1_l1_: new_path = new_path+l1l111_l1_ (u"ࠬࠬࡩ࡮ࡣࡪࡩࡂ࠭俏")+QUOTE(l1l11l1111l1_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ俐")+new_path+l1l111_l1_ (u"ࠢࠪࠤ俑"))
			return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭俒"),[],[]
		choice = l1l111lll11l_l1_[l11l11l_l1_]
		l1l111l1l11l_l1_ = l11ll1llll1l_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠩࡧࡥࡸ࡮ࠧ俓"):
			l11lllll1ll1_l1_ = l11llll11111_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ俔"),l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ俕"),l1l111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ俖")]:
			if choice==l1l111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ俗"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l1l11l11l1l1_l1_,l11lll1lll11_l1_
			elif choice==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭俘"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l1l111l1l111_l1_,l1l111ll11ll_l1_
			elif choice==l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ俙"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l11llllllll1_l1_,l11lll1ll11l_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ俚"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l11lllll1ll1_l1_ = l1l1111l1lll_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俛")]
				l1l111l1l11l_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠫࡲࡶࡤࠨ俜"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํืษ࠻ࠩ保"), l11ll1ll11l1_l1_)
			if l11l11l_l1_!=-1:
				l1l111l1l11l_l1_ = l11ll1ll11l1_l1_[l11l11l_l1_]
				l11ll1llllll_l1_ = l1l11l1111ll_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ส࠻ࠩ俞"), l1l11l1l1111_l1_)
				if l11l11l_l1_!=-1:
					l1l111l1l11l_l1_ += l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ俟")+l1l11l1l1111_l1_[l11l11l_l1_]
					l1l11111l1l1_l1_ = l1l111ll1111_l1_[l11l11l_l1_]
					l1l11l11lll1_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ俠"):
			l11llll11lll_l1_,l11ll1ll11ll_l1_,l11lll1l11ll_l1_,l1l11l11l1ll_l1_ = list(zip(*l11lll111lll_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ信"), l11lll1l11ll_l1_)
			if l11l11l_l1_!=-1:
				l1l111l1l11l_l1_ = l11lll1l11ll_l1_[l11l11l_l1_]
				l11ll1llllll_l1_ = l11llll11lll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俢") in l11lll1l11ll_l1_[l11l11l_l1_] and l11ll1llllll_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俣")]!=l11llll11111_l1_:
					l1l11111l1l1_l1_ = l11ll1ll11ll_l1_[l11l11l_l1_]
					l1l11l11lll1_l1_ = True
				else: l11lllll1ll1_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俤")]
				break
		elif choice==l1l111_l1_ (u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧ俥"):
			l11llll11lll_l1_,l11ll1ll11ll_l1_,l11lll1l11ll_l1_,l1l11l11l1ll_l1_ = list(zip(*l11lll11l111_l1_))
			l11ll1llllll_l1_ = l11llll11lll_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ俦") in l11lll1l11ll_l1_[l11l11l_l1_-shift] and l11ll1llllll_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俧")]!=l11llll11111_l1_:
				l1l11111l1l1_l1_ = l11ll1ll11ll_l1_[l11l11l_l1_-shift]
				l1l11l11lll1_l1_ = True
			else: l11lllll1ll1_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俨")]
			l1l111l1l11l_l1_ = l11lll1l11ll_l1_[l11l11l_l1_-shift]
			break
	if not l1l11l11lll1_l1_: l11lllll11ll_l1_ = l11lllll1ll1_l1_
	else: l11lllll11ll_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠫ俩")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俪")]+l1l111_l1_ (u"ࠬࠦࠫࠡࡃࡸࡨ࡮ࡵ࠺ࠡࠩ俫")+l1l11111l1l1_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ俬")]
	if l1l11l11lll1_l1_:
		l1l11l11111l_l1_ = int(l11ll1llllll_l1_[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ俭")])
		l11llllll111_l1_ = int(l1l11111l1l1_l1_[l1l111_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ修")])
		l1l1lll1ll_l1_ = str(max(l1l11l11111l_l1_,l11llllll111_l1_))
		l11lll1ll111_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俯")].replace(l1l111_l1_ (u"ࠪࠪࠬ俰"),l1l111_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ俱"))
		l11lllllllll_l1_ = l1l11111l1l1_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俲")].replace(l1l111_l1_ (u"࠭ࠦࠨ俳"),l1l111_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭俴"))
		l1l11l111lll_l1_ = l1l111_l1_ (u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ俵")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪ俶")+l1l1lll1ll_l1_+l1l111_l1_ (u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩ俷")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ俸")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩ俹")+l11ll1llllll_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ俺")]+l1l111_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ俻")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭俼")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ俽")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ俾")]+l1l111_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ俿")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ倀")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ倁")+str(l11ll1llllll_l1_[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ倂")])+l1l111_l1_ (u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ倃")+str(l11ll1llllll_l1_[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ倄")])+l1l111_l1_ (u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ倅")+str(l11ll1llllll_l1_[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ倆")])+l1l111_l1_ (u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬ倇")+l11ll1llllll_l1_[l1l111_l1_ (u"࠭ࡦࡱࡵࠪ倈")]+l1l111_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ倉")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ倊")+l11lll1ll111_l1_+l1l111_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ個")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ倌")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ倍")]+l1l111_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ倎")
		l1l11l111lll_l1_ += l1l111_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ倏")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ倐")]+l1l111_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ們")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ倒")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ倓")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ倔")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠵ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡤࡹࡩ࡯࡯࠰ࠩ倕")+l1l11111l1l1_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ倖")]+l1l111_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ倗")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭倘")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ候")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ倚")]+l1l111_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ倛")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ倜")]+l1l111_l1_ (u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩ倝")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭倞")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ借")]+l1l111_l1_ (u"ࠩࠥ࠳ࡃࡢ࡮ࠨ倠")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭倡")+l11lllllllll_l1_+l1l111_l1_ (u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ倢")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ倣")+l1l11111l1l1_l1_[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ値")]+l1l111_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ倥")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ倦")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ倧")]+l1l111_l1_ (u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ倨")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ倩")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ倪")
		l1l11l111lll_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ倫")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ倬")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪ倭")
		if kodi_version>18.99:
			import http.server as l11llll1lll1_l1_
			import http.client as l1l111111lll_l1_
		else:
			import BaseHTTPServer as l11llll1lll1_l1_
			import httplib as l1l111111lll_l1_
		class l1l111l11111_l1_(l11llll1lll1_l1_.HTTPServer):
			def __init__(self,l1ll1lll11ll_l1_=l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ倮"),port=55055,l1l11l111lll_l1_=l1l111_l1_ (u"ࠪࡀࡃ࠭倯")):
				self.l1ll1lll11ll_l1_ = l1ll1lll11ll_l1_
				self.port = port
				self.l1l11l111lll_l1_ = l1l11l111lll_l1_
				l11llll1lll1_l1_.HTTPServer.__init__(self,(self.l1ll1lll11ll_l1_,self.port),l1l11l111l1l_l1_)
				self.l1l1111l11ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ倰")+l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠬࡀࠧ倱")+str(port)+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ倲")
			def start(self):
				self.threads = l11l11ll111_l1_(False)
				self.threads.start_new_thread(1,self.l11llll1llll_l1_)
			def l11llll1llll_l1_(self):
				self.l11lll11111l_l1_ = True
				while self.l11lll11111l_l1_:
					self.handle_request()
			def stop(self):
				self.l11lll11111l_l1_ = False
				self.l1l1111lllll_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l11l111lll_l1_):
				self.l1l11l111lll_l1_ = l1l11l111lll_l1_
			def l1l1111lllll_l1_(self):
				conn = l1l111111lll_l1_.HTTPConnection(self.l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠧ࠻ࠩ倳")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠣࡊࡈࡅࡉࠨ倴"), l1l111_l1_ (u"ࠤ࠲ࠦ倵"))
		class l1l11l111l1l_l1_(l11llll1lll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ倶"),l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ倷"))
				self.end_headers()
				self.wfile.write(self.server.l1l11l111lll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ倸")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ倹"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ债"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l111l11111_l1_(l1l111_l1_ (u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫ倻"),55055,l1l11l111lll_l1_)
		l11lllll1ll1_l1_ = httpd.l1l1111l11ll_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠩࠪ值")
	if not l11lllll1ll1_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ倽"),[],[]
	return l1l111_l1_ (u"ࠫࠬ倾"),[l1l111_l1_ (u"ࠬ࠭倿")],[[l11lllll1ll1_l1_,l1l111l1ll11_l1_,httpd]]
def l1l1111l111l_l1_(url):
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ偀") : l1l111_l1_ (u"ࠧࠨ偁") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ偂"),headers,l1l111_l1_ (u"ࠩࠪ偃"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡅࡓࡇ࠳࠱ࡴࡶࠪ偄"))
	items = re.findall(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࢀ࠮ࡢࡽࠨ偅"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l111lll111_l1_,l1l1lll1_l1_,l11lllll111l_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1ll1ll_l1_,dummy,l1lll1lllll1_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ偆"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ假"))
			if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭偈") in l1ll1ll_l1_:
				l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lllll111l_l1_
				if l1l111lll111_l1_[0]==l1l111_l1_ (u"ࠨ࠯࠴ࠫ偉"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ偊")+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ偋"))
				else:
					for title in l1l111lll111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ偌")+l1l111_l1_ (u"ࠬࠦࠠࠡࠩ偍")+title)
			else:
				title = l1l111_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ偎")+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ偏")+l1lll1lllll1_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
				l1l1lll1_l1_.append(title)
		return l1l111_l1_ (u"ࠨࠩ偐"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ偑"),[],[]
def l11llll111l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ偒"),url,l1l111_l1_ (u"ࠫࠬ偓"),l1l111_l1_ (u"ࠬ࠭偔"),l1l111_l1_ (u"࠭ࠧ偕"),l1l111_l1_ (u"ࠧࠨ偖"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡜ࡉࡅࡇࡒࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ偗"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ偘"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		return l1l111_l1_ (u"ࠪࠫ偙"),[l1l111_l1_ (u"ࠫࠬ做")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠬ࠭偛"),[],[]
def l11lll11lll1_l1_(url):
	url = url.replace(l1l111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭停"),l1l111_l1_ (u"ࠧࠨ偝")).replace(l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ偞"),l1l111_l1_ (u"ࠩࠪ偟"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ偠"),url,l1l111_l1_ (u"ࠫࠬ偡"),l1l111_l1_ (u"ࠬ࠭偢"),l1l111_l1_ (u"࠭ࠧ偣"),l1l111_l1_ (u"ࠧࠨ偤"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ健"))
	html = response.content
	l1111111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠨ偦"),html,re.DOTALL)
	if l1111111l1l_l1_:
		l1111111l1l_l1_ = l1111111l1l_l1_[0]
		l1ll1l1ll111_l1_ = l1ll1llll11l_l1_(l1111111l1l_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ偧"),l1ll1l1ll111_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠭ࢂ࠭偨"),l1ll1l1ll111_l1_,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_,title in l1ll_l1_:
			if not title: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠬ࠴ࠧ偩"),1)[1]
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		return l1l111_l1_ (u"࠭ࠧ偪"),l1l1lll1_l1_,l1llll_l1_
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ偫"))[3]
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ偬"):l1l111_l1_ (u"ࠩࠪ偭") , l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ偮"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ偯") }
	payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ偰"):id , l1l111_l1_ (u"࠭࡯ࡱࠩ偱"):l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ偲") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭偳"),url,payload,headers,l1l111_l1_ (u"ࠩࠪ側"),l1l111_l1_ (u"ࠪࠫ偵"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ偶"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ偷"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ偸"),[l1l111_l1_ (u"ࠧࠨ偹")],[ items[0] ]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈࠩ偺"),[],[]
def l1l111l11l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ偻"),l1l111_l1_ (u"ࠪࠫ偼"),l1l111_l1_ (u"ࠫࠬ偽"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ偾"))
	items = re.findall(l1l111_l1_ (u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ偿"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ傀"),[l1l111_l1_ (u"ࠨࠩ傁")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧ傂"),[],[]
def l1l1111l11l1_l1_(url):
	return l1l111_l1_ (u"ࠪࠫ傃"),[l1l111_l1_ (u"ࠫࠬ傄")],[ url ]
def l1l111ll1ll1_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ傅"))
	basename = l1l111_l1_ (u"࠭࠯ࠨ傆").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ傇"),l1l111_l1_ (u"ࠨࠩ傈"),l1l111_l1_ (u"ࠩࠪ傉"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧ傊"))
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭傋"),html,re.DOTALL)
	if items:
		l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_,l1l11l11l111_l1_,l1l11l11l11l_l1_,l1l11l111ll1_l1_ = items[0]
		var = int(l1l1l1ll111l_l1_) % int(l1l1l1ll11l1_l1_) + int(l1l11l11l111_l1_) % int(l1l11l11l11l_l1_)
		url = basename + l1l1l1l1l11l_l1_ + str(var) + l1l11l111ll1_l1_
		return l1l111_l1_ (u"ࠬ࠭傌"),[l1l111_l1_ (u"࠭ࠧ傍")],[url]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢ࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠭傎"),[],[]
def l1l11111lll1_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ傏"),l1l111_l1_ (u"ࠩࠪ傐"))
	url = url.replace(l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ傑"),l1l111_l1_ (u"ࠫࠬ傒"))
	id = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ傓"))[-1]
	headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ傔") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭傕") }
	payload = { l1l111_l1_ (u"ࠣ࡫ࡧࠦ傖"):id , l1l111_l1_ (u"ࠤࡲࡴࠧ傗"):l1l111_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷ࠨ傘") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ備"), url, payload, headers, l1l111_l1_ (u"ࠬ࠭傚"),l1l111_l1_ (u"࠭ࠧ傛"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ傜"))
	if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ傝") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ傞")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࠫ傟"),[l1l111_l1_ (u"ࠫࠬ傠")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡒ࠷࡙ࡕࡒࡏࡂࡆࠪ傡"),[],[]
def l11ll1l1llll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ傢"),l1l111_l1_ (u"ࠧࠨ傣"),l1l111_l1_ (u"ࠨࠩ傤"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ傥"))
	items = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺ࠡ࡞࡞ࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭傦"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ傧"),[l1l111_l1_ (u"ࠬ࠭储")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡌࡒ࡙࡜ࡌࡊࡘࡈࠫ傩"),[],[]
def l11lll111l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ傪"),l1l111_l1_ (u"ࠨࠩ傫"),l1l111_l1_ (u"ࠩࠪ催"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡅࡋࡍ࡛ࡋ࠭࠲ࡵࡷࠫ傭"))
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ傮"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ傯") + items[0]
		return l1l111_l1_ (u"࠭ࠧ傰"),[l1l111_l1_ (u"ࠧࠨ傱")],[ url ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ傲"),[],[]
def l1l11l1ll1l1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ傳"),l1l111_l1_ (u"ࠪࠫ傴"),l1l111_l1_ (u"ࠫࠬ債"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖ࠰࠵ࡸࡺࠧ傶"))
	items = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭傷"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ傸"),[l1l111_l1_ (u"ࠨࠩ傹")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡕ࡛ࡂࡍࡋࡆ࡚ࡎࡊࡅࡐࡊࡒࡗ࡙࠭傺"),[],[]
def l11lll11ll1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ傻"),l1l111_l1_ (u"ࠫࠬ傼"),l1l111_l1_ (u"ࠬ࠭傽"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ傾"))
	items = re.findall(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ傿"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠨࠩ僀"),[l1l111_l1_ (u"ࠩࠪ僁")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡓࡕࡔࡈࡅࡒ࠭僂"),[],[]
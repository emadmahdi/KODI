# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪဎ")
headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ဏ") : l1l111_l1_ (u"ࠪࠫတ") }
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡇࡒࡍࡡࠪထ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼อࠬဒ"),l1l111_l1_ (u"࠭วๅๅ็ࠫဓ"),l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩန"),l1l111_l1_ (u"ࠨษ็฽ฬฮࠧပ"),l1l111_l1_ (u"ࠩหีฬ๋ฬࠡๅ่ฬ๏๎สาࠩဖ"),l1l111_l1_ (u"้ࠪํฮว๋ๆࠣ์ࠥา่ศๆࠪဗ"),l1l111_l1_ (u"ࠫฬ๊โิ็ࠣห้อำๅษ่๎ࠬဘ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==200: l1lll_l1_ = l1l1l11_l1_()
	elif mode==201: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==202: l1lll_l1_ = PLAY(url)
	elif mode==203: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==204: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩမ")+text)
	elif mode==205: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ယ")+text)
	elif mode==209: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧရ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨလ"),l1l111_l1_ (u"ࠩࠪဝ"),209,l1l111_l1_ (u"ࠪࠫသ"),l1l111_l1_ (u"ࠫࠬဟ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩဠ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭အ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪဢ"),l111l1_l1_,205)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဣ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬဤ"),l111l1_l1_,204)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨဥ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫဦ"),l1l111_l1_ (u"ࠬ࠭ဧ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ဨ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩဩ")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็่๎ืฯࠧဪ"),l111l1_l1_+l1l111_l1_ (u"ࠩࡂࡃࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭ါ"),201)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪာ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ိ")+l1lllll_l1_+l1l111_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪီ"),l111l1_l1_+l1l111_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡱࡴࡼࡩࡦࡵࠪု"),201)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧူ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪေ")+l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩဲ"),l111l1_l1_+l1l111_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟ࡴࡧࡵ࡭ࡪࡹࠧဳ"),201)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫဴ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧဵ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨံ"),l111l1_l1_+l1l111_l1_ (u"ࠧࡀࡁࡰࡥ࡮ࡴࡰࡢࡩࡨ့ࠫ"),201)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬး"),l111l1_l1_,l1l111_l1_ (u"္ࠩࠪ"),headers,True,l1l111_l1_ (u"်ࠪࠫ"),l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨျ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡷࡥࡧࡹࠨ࠯ࠬࡂ࠭ࡒࡧࡩ࡯ࡔࡲࡻࠬြ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨွ"),block,re.DOTALL)
		for filter,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡨࡰ࡯ࡨ࠳ࡲࡵࡲࡦࡁࡩ࡭ࡱࡺࡥࡳ࠿ࠪှ")+filter
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဿ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ၀")+l1lllll_l1_+title,l1ll1ll_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ၁"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ၂"),l1l111_l1_ (u"ࠬ࠭၃"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ၄"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ၅"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭၆") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ၇"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ၈"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭၉")+l1lllll_l1_+title,l1ll1ll_l1_,201)
	return html
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠬࡅ࠿ࠨ၊") in url: url,type = url.split(l1l111_l1_ (u"࠭࠿ࡀࠩ။"))
	else: type = l1l111_l1_ (u"ࠧࠨ၌")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ၍"),url,l1l111_l1_ (u"ࠩࠪ၎"),headers,True,l1l111_l1_ (u"ࠪࠫ၏"),l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪၐ"))
	html = response.content
	if l1l111_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧၑ") in url: l11llll_l1_ = [html]
	elif type==l1l111_l1_ (u"࠭ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨၒ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡣࡶࡸࡪࡸࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃࡢ࡮ࠡࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩၓ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡱࡴࡼࡩࡦࡵࠪၔ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡡ࠴ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨၕ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࡤࡹࡥࡳ࡫ࡨࡷࠬၖ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘࡲࡩࡥࡧࡵࡣ࠷࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪၗ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬ࠷࠱࠲࡯ࡤ࡭ࡳࡶࡡࡨࡧࠪၘ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠢࡳࡥ࡬࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡴࡢࡤࡶࠦࠬၙ"),html,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡱࡦ࡯࡮࠮ࡨࡲࡳࡹ࡫ࡲࠨၚ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l111111_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨၛ"),l1l111_l1_ (u"ࠩไ๎้๋ࠧၜ"),l1l111_l1_ (u"ࠪห฿์๊สࠩၝ"),l1l111_l1_ (u"่๊๊ࠫษࠩၞ"),l1l111_l1_ (u"ࠬอูๅษ้ࠫၟ"),l1l111_l1_ (u"࠭็ะษไࠫၠ"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧၡ"),l1l111_l1_ (u"ࠨ฻ิฺࠬၢ"),l1l111_l1_ (u"่๋ࠩึาว็ࠩၣ"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩၤ")]
	items = re.findall(l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡨ࡯ࡹࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪၥ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l111_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡎࡺࡥ࡮ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫၦ"),block,re.DOTALL)
		l1ll_l1_,l11ll1l11_l1_,l11l11_l1_ = zip(*items)
		items = zip(l11ll1l11_l1_,l1ll_l1_,l11l11_l1_)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨၧ") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩၨ"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪၩ"))
		if l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩၪ") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩၫ"),l1lllll_l1_+title,l1ll1ll_l1_,202,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧၬ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬၭ") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩၮ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ၯ") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨၰ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡴࡦࡩ࡫࠰ࠩၱ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪၲ"),l1lllll_l1_+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫၳ"),201,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬၴ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"࠭ࠧၵ"),l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡵࡧࡧࡦࠩၶ")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩၷ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩၸ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫၹ"),l1l111_l1_ (u"ࠫࠬၺ"))
				if l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨၻ") in url:
					l11ll11ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬၼ"))[1]
					l11lll1ll_l1_ = url.split(l1l111_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭ၽ"))[1]
					l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧၾ")+l11lll1ll_l1_,l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨၿ")+l11ll11ll_l1_)
				if title!=l1l111_l1_ (u"ࠪࠫႀ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫႁ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫႂ")+title,l1ll1ll_l1_,201)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪႃ"),url,l1l111_l1_ (u"ࠧࠨႄ"),headers,True,l1l111_l1_ (u"ࠨࠩႅ"),l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪႆ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪႇ"),html,re.DOTALL)
	if l11llll_l1_:
		l11111ll_l1_ = []
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠫࠬႈ").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫႉ"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨႊ"))
		title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ႋ") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪႌ"))[-1].replace(l1l111_l1_ (u"ࠩ࠰ႍࠫ"),l1l111_l1_ (u"ࠪࠤࠬႎ"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫฬ๊อๅไฬ࠱࠭ࡢࡤࠬࠫࠪႏ"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ႐"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"࠭࠰ࠨ႑")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ႒"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ႓"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ႔") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ႕") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ႖"),l1lllll_l1_+title,l1ll1ll_l1_,203)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ႗") not in l1ll1ll_l1_:
				title = l111l11_l1_(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ႘"),l1lllll_l1_+title,l1ll1ll_l1_,202)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ႙"))
	hostname = l111l1_l1_
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬႚ"),url,l1l111_l1_ (u"ࠩࠪႛ"),headers,True,True,l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧႜ"))
	html = response.content
	id = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡋࡧ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬႝ"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭႞"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ႟"),html,re.DOTALL)
	if id: id = id[0]
	if l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨႠ") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧႡ"))
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭Ⴂ"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫႣ"),headers,True,True,l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨႤ"))
		l11l1ll1_l1_ = response.content
		l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫႥ"),l11l1ll1_l1_,re.DOTALL)
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧႦ"),l11l1ll1_l1_,re.DOTALL)
		l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫႧ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࡝ࡰ࠭࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩႨ"),l11l1ll1_l1_)
		l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႩ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬႪ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l11ll111l_l1_+l1l1111_l1_+l11ll11l1_l1_+l11l1llll_l1_+l11l1lll1_l1_+l11ll1111_l1_
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႫ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l111_l1_ (u"ࠬ࠴ࡰ࡯ࡩࠪႬ") in server: continue
			if l1l111_l1_ (u"࠭࠮࡫ࡲࡪࠫႭ") in server: continue
			if l1l111_l1_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧႮ") in server: continue
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩႯ"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l111l1ll_l1_[0]
				if l111l1ll_l1_ in title: title = title.replace(l111l1ll_l1_+l1l111_l1_ (u"ࠩࡳࠫႰ"),l1l111_l1_ (u"ࠪࠫႱ")).replace(l111l1ll_l1_,l1l111_l1_ (u"ࠫࠬႲ")).strip(l1l111_l1_ (u"ࠬࠦࠧႳ"))
				l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫႴ")+l111l1ll_l1_
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨႵ")
			if server.isdigit():
				l1ll1ll_l1_ = hostname+l1l111_l1_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫႶ")+id+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭Ⴗ")+server+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫႸ")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬႹ")+l111l1ll_l1_
			else:
				if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪႺ") not in server: server = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬႻ")+server
				l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨႼ"),title,re.DOTALL)
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭Ⴝ")+l111l1ll_l1_[0]
				else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪႾ")
				l1ll1ll_l1_ = server+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫႿ")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࡔ࡯ࡸࠩჀ") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫჁ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭Ⴢ") }
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪჃ")
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬჄ"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪჅ"),l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠪࠫ჆"),l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨჇ"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭჈"),l11l1ll1_l1_,re.DOTALL)
		for block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ჉"),block,re.DOTALL)
			for l1ll1ll_l1_,name,l111l1ll_l1_ in items:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ჊")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ჋")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ჌")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧჍ") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ჎"):l1l111_l1_ (u"ࠬ࠭჏") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩა"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨბ") }
		l1lllll1_l1_ = hostname + l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫგ")+id
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭დ"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫე"),l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨვ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡣࡶࡱࡷࠬზ") in l11l1ll1_l1_:
			l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬთ"),l11l1ll1_l1_,re.DOTALL)
			for l1llllll_l1_ in l11ll11l1_l1_:
				if l1l111_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧი") not in l1llllll_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭კ") in l1llllll_l1_:
					l1llllll_l1_ = l1llllll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ლ")
					l1llll_l1_.append(l1llllll_l1_)
				elif l1l111_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪმ") in l1llllll_l1_:
					l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠬნ")
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩო"),l1llllll_l1_,l1l111_l1_ (u"࠭ࠧპ"),headers,True,True,l1l111_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫჟ"))
					l11ll1l1l_l1_ = response.content
					l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭რ"),l11ll1l1l_l1_,re.DOTALL)
					for l1l1111l1_l1_ in l1lll1l1_l1_:
						l11ll1lll_l1_ = l1l111_l1_ (u"ࠩࠪს")
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬტ"),l1l1111l1_l1_,re.DOTALL)
						for l11llll11_l1_ in l11l1llll_l1_:
							item = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬუ"),l11llll11_l1_,re.DOTALL)
							if item:
								l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪფ")+item[0]
								break
						for l11llll11_l1_ in reversed(l11l1llll_l1_):
							item = re.findall(l1l111_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬქ"),l11llll11_l1_,re.DOTALL)
							if item:
								l11ll1lll_l1_ = item[0]
								break
						l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ღ"),l1l1111l1_l1_,re.DOTALL)
						for l11lll11l_l1_ in l11l1lll1_l1_:
							l11lll11l_l1_ = l11lll11l_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩყ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭შ")+l111l1ll_l1_
							l1llll_l1_.append(l11lll11l_l1_)
		elif l1l111_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠨჩ") in l11l1ll1_l1_:
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"ࠫࡁ࡮࠶ࠡࠩც"),l1l111_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩძ"))+l1l111_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧწ")
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"ࠧ࠽ࡪ࠶ࠤࠬჭ"),l1l111_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬხ"))+l1l111_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪჯ")
			l11lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠮࠮ࠫࡁࠬࡁࡂࡋࡎࡅ࠿ࡀࠫჰ"),l11l1ll1_l1_,re.DOTALL)
			if l11lll1l1_l1_:
				for l1l1111l1_l1_ in l11lll1l1_l1_:
					if l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪჱ") not in l1l1111l1_l1_: continue
					l11llll1l_l1_ = l1l111_l1_ (u"ࠬ࠭ჲ")
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬჳ"),l1l1111l1_l1_,re.DOTALL)
					for l11llll11_l1_ in l11l1llll_l1_:
						item = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨჴ"),l11llll11_l1_,re.DOTALL)
						if item:
							l11llll1l_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭ჵ")+item[0]
							break
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨჶ"),l1l1111l1_l1_,re.DOTALL)
					if l11l1llll_l1_:
						for l11ll1lll_l1_,l11lll111_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫჷ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨჸ")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
					else:
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬჹ"),l1l1111l1_l1_,re.DOTALL)
						for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨჺ"))+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ჻")+l11ll1lll_l1_+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬჼ")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
			else:
				l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭ࡢࡷࠬࠫ࠿ࠫჽ"),l11l1ll1_l1_,re.DOTALL)
				for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
					l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬჾ"))+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬჿ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᄀ")
					l1llll_l1_.append(l11lll111_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᄁ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨᄂ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩᄃ"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫᄄ"),l1l111_l1_ (u"ࠪ࠯ࠬᄅ"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᄆ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡭ࡼࠪᄇ"),l1l111_l1_ (u"࠭ࠧᄈ"),headers,True,l1l111_l1_ (u"ࠧࠨᄉ"),l1l111_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧᄊ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᄋ"),html,re.DOTALL)
	if l11_l1_ and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄌ"),block,re.DOTALL)
		l11lllll1_l1_,l11ll1ll1_l1_ = [],[]
		for category,title in items:
			l11lllll1_l1_.append(category)
			l11ll1ll1_l1_.append(title)
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫᄍ"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠬ࠭ᄎ")
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪᄏ")+search+l1l111_l1_ (u"ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫᄐ")+category+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽࠲ࠩᄑ")
	l1lll11_l1_(url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᄒ"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᄓ"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪᄔ"),l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ᄕ")]
	if l1l111_l1_ (u"࠭࠿ࠨᄖ") in url: url = url.split(l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫᄗ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬᄘ"),1)
	if filter==l1l111_l1_ (u"ࠩࠪᄙ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫᄚ"),l1l111_l1_ (u"ࠫࠬᄛ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᄜ"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪᄝ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩᄞ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪᄟ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫᄠ")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ᄡ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᄢ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨᄣ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨᄤ"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᄥ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᄦ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᄧ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࠧᄨ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬᄩ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᄪ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧᄫ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᄬ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩᄭ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᄮ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄯ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧᄰ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᄱ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ᄲ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ᄳ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᄴ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᄵ"),l1l111_l1_ (u"ࠪࠫᄶ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩᄷ"),l1l111_l1_ (u"ࠬ࠭ᄸ"),headers,l1l111_l1_ (u"࠭ࠧᄹ"),l1l111_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᄺ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥ࠭࠴ࠪࡀࠫࡉ࡭ࡱࡺࡥࡳ࡙ࡲࡶࡩ࠭ᄻ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡦࡰࡴࡗࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࡮࠲ࠨᄼ"),block,re.DOTALL)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠪหำะ๊ศำࠣࠫᄽ"),l1l111_l1_ (u"ࠫࠬᄾ"))
		name = name.replace(l1l111_l1_ (u"ูࠬๆสࠢส่ส์สศฮࠪᄿ"),l1l111_l1_ (u"࠭วๅี้อࠬᅀ"))
		items = re.findall(l1l111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᅁ"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࠿ࠪᅂ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ᅃ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪᅄ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅅ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ᅆ"),l1lllll1_l1_,201)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅇ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨᅈ"),l1lllll1_l1_,205,l1l111_l1_ (u"ࠨࠩᅉ"),l1l111_l1_ (u"ࠩࠪᅊ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᅋ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᅌ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨᅍ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨᅎ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪᅏ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬᅐ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅑ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᅒ")+name,l1lllll1_l1_,204,l1l111_l1_ (u"ࠫࠬᅓ"),l1l111_l1_ (u"ࠬ࠭ᅔ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			option = option.replace(l1l111_l1_ (u"࠭࡜࡯ࠩᅕ"),l1l111_l1_ (u"ࠧࠨᅖ"))
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪᅗ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫᅘ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬᅙ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭ᅚ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᅛ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩᅜ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩᅝ")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫᅞ")+name
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪᅟ"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅠ"),l1lllll_l1_+title,url,204,l1l111_l1_ (u"ࠫࠬᅡ"),l1l111_l1_ (u"ࠬ࠭ᅢ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪᅣ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩᅤ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᅥ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᅦ")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅧ"),l1lllll_l1_+title,l1llllll_l1_,201)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅨ"),l1lllll_l1_+title,url,205,l1l111_l1_ (u"ࠬ࠭ᅩ"),l1l111_l1_ (u"࠭ࠧᅪ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠧ࠾ࠨࠪᅫ"),l1l111_l1_ (u"ࠨ࠿࠳ࠪࠬᅬ"))
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫᅭ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬᅮ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭ᅯ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧᅰ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧᅱ")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᅲ"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᅳ"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᅴ"),l1l111_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᅵ")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭ᅶ")
		if l1l111_l1_ (u"ࠬࠫࠧᅷ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᅸ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩᅹ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬᅺ")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᅻ") and value!=l1l111_l1_ (u"ࠪ࠴ࠬᅼ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᅽ")+key+l1l111_l1_ (u"ࠬࡃࠧᅾ")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪᅿ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩᆀ")+key+l1l111_l1_ (u"ࠨ࠿ࠪᆁ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭ᆂ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᆃ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧᆄ"),l1l111_l1_ (u"ࠬࡃࠧᆅ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧᆆ"),l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᆇ"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䕅"):l1l111_l1_ (u"ࠪࠫ䕆")}
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ䕇")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ䕈")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"࠭࠳ࠨ䕉"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠧ࠲ࠩ䕊"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠨ࠴ࠪ䕋"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠩ࠷ࠫ䕌"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䕍"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䕎")+l1lllll_l1_+l1l111_l1_ (u"่ࠬๆศห๋้ࠣอࠠๆ่้ࠣํู่ࠡสส๊๏ะࠧ䕏"),l1l111_l1_ (u"࠭ࠧ䕐"),38)
	return l1l111_l1_ (u"ࠧࠨ䕑")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠨࠩ䕒")):
	type = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䕓"))[3]
	if type==l1l111_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䕔"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ䕕"),headers,l1l111_l1_ (u"ࠬ࠭䕖"),l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹ࠭䕗"))
		if select==l1l111_l1_ (u"ࠧ࠴ࠩ䕘"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯ࡳࡦࡴ࡬ࡩࡸࡌ࡯ࡳ࡯ࠪ䕙"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䕚"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"ࠪ็้๐ศศฬ้ࠣ฻ำใสࠩ䕛") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䕜"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕝"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"࠭࠴ࠨ䕞"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡤࡦࡶࡤ࡭ࡱࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡺࡃࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䕟"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕠"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ䕡"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕢"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ䕣"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭䕤"),headers,l1l111_l1_ (u"࠭ࠧ䕥"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠶ࡳࡪࠧ䕦"))
		if select==l1l111_l1_ (u"ࠨ࠳ࠪ䕧"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡉࡨࡲࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡥ࡭ࡧࡦࡸࠬ䕨"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕩"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳ࠬ䕪") + value
				name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ䕫"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕬"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠧ࠳ࠩ䕭"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡂࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ䕮"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕯"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ䕰"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴ࡧࡣࡵࡱࡵ࠳ࠬ䕱") + value
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕲"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"࠭࠯ࠨ䕳"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ䕴"),headers,l1l111_l1_ (u"ࠨࠩ䕵"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䕶"))
	if l1l111_l1_ (u"ࠪ࡬ࡴࡳࡥࠨ䕷") in url: type=l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䕸")
	if type==l1l111_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ䕹"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠪ࠱࠮ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ䕺"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䕻"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ䕼"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕽"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䕾"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ䕿"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠰ࡅࠩࠣࠩ䖀"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䖁"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖂"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䖃"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䖄"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠪ࠵ࠬ䖅"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠩ䖆"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻ࠭䖇"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ䖈") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖉"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠳࠰࠿ࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䖊"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࠪ䖋"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ䖌"))
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭䖍"))
			name = title + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䖎") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䖏"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡨ࡮ࡼࡴ࡭࡯ࡣࡰࡰ࠰ࡧ࡭࡫ࡶࡳࡱࡱ࠱ࡷ࡯ࡧࡩࡶࠫ࠲࠰ࡅࠩࡥࡣࡷࡥ࠲ࡸࡥࡷ࡫ࡹࡩ࠲ࢀ࡯࡯ࡧ࡬ࡨࡂࠨ࠴ࠣࠩ䖐"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䖑"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ุࠩๅาฯࠠࠨ䖒") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䖓"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䖔") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࡺ࠶࠵ࡳࡦࡴ࡬ࡩࡸࡒࡩ࡯࡭࠲ࠫ䖕") + url.split(l1l111_l1_ (u"࠭࠯ࠨ䖖"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䖗"),url,l1l111_l1_ (u"ࠨࠩ䖘"),headers,l1l111_l1_ (u"ࠩࠪ䖙"),l1l111_l1_ (u"ࠪࠫ䖚"),l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䖛"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠬࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䖜"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"࠭࡜࠰ࠩ䖝"),l1l111_l1_ (u"ࠧ࠰ࠩ䖞"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䖟"),url,l1l111_l1_ (u"ࠩࠪ䖠"),headers,l1l111_l1_ (u"ࠪࠫ䖡"),l1l111_l1_ (u"ࠫࠬ䖢"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭䖣"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡕࡓࡎࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䖤"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖥"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠨࠩ䖦")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ䖧"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ䖨"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ䖩"),l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䖪")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"࠭࠱ࠨ䖫")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䖬"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠨสะฯࠥ฿ๆࠡษไ่ฬ๋ࠧ䖭") , l1l111_l1_ (u"ࠩหัะูࠦ็่ࠢืู้ไศฬࠪ䖮")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠠ࠮ࠢสาฯืࠠศๆหัะ࠭䖯"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࡣࠬ䖰") in options: type = l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䖱")
		elif l1l111_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧ䖲") in options: type = l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䖳")
		else: return
	headers[l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䖴")] = l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䖵")
	data = {l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࠩ䖶"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡈࡴࡳࡡࡪࡰࠪ䖷"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠬ࠷ࠧ䖸"): data[l1l111_l1_ (u"࠭ࡦࡳࡱࡰࠫ䖹")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䖺"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ䖻"),data,headers,l1l111_l1_ (u"ࠩࠪ䖼"),l1l111_l1_ (u"ࠪࠫ䖽"),l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䖾"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䖿"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࠰ࠩ䗀"),l1l111_l1_ (u"ࠧ࠰ࠩ䗁"))
			if l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䗂") in url: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䗃"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ๏๊ๅࠡࠩ䗄")+title,url,33)
			elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䗅") in url:
				url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䗆"),l1l111_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷ࠳ࠬ䗇"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗈"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊ࠠࠨ䗉")+title,url+l1l111_l1_ (u"ࠩ࠲࠵ࠬ䗊"),32)
	count=re.findall(l1l111_l1_ (u"ࠪࠦࡹࡵࡴࡢ࡮ࠥ࠾࠭࠴ࠪࡀࠫࢀࠫ䗋"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗌"),l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䗍")+l1lll1l1l_l1_,l1l111_l1_ (u"࠭ࠧ䗎"),39,l1l111_l1_ (u"ࠧࠨ䗏"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ䗐")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࡤࡌࡗ࠶ࡣࡅࡱࡹࡐ࠷ࡪࡺࡥࡊࡍࡰ࡞࡝࠰࠱ࡎࡱࡆ࡭ࡨ࡭ࡗ࠲ࡏࡱࡓࡼࡌ࡮࡮ࡶࡐ࠷࡜࡫࡛࠴࡙ࡪ࡞࡝ࡊࡺࡎ࠵࡬࡭ࡨࡇࡇࡗ࡙࡭࠾ࡽࡢࡈࡈ࠸ࡦࡌࡲࡺࡥࡅ࠸ࡸࡒ࠹ࡕ࠵ࠩ䗑")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䗒"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䗓"))
	return
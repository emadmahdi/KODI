# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫビ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡌࡓ࡜ࡢࠫピ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨフ"),l1l111_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨブ"),l1l111_l1_ (u"ࠨษ็ห็ูวๆࠩプ"),l1l111_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭ヘ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==700: l1lll_l1_ = l1l1l11_l1_()
	elif mode==701: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==702: l1lll_l1_ = PLAY(url)
	elif mode==703: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==704: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==709: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡿ࡯࡫ࡢ࠰࠼ࠫベ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨペ"),l1l11ll_l1_,l1l111_l1_ (u"ࠬ࠭ホ"),l1l111_l1_ (u"࠭ࠧボ"),l1l111_l1_ (u"ࠧࠨポ"),l1l111_l1_ (u"ࠨࠩマ"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫミ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪム"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫメ"),l1l111_l1_ (u"ࠬ࠭モ"),709,l1l111_l1_ (u"࠭ࠧャ"),l1l111_l1_ (u"ࠧࠨヤ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬュ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧユ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪョ"),l1l111_l1_ (u"ࠫࠬヨ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬラ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨリ")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆ็ํึࠬル"),l1l11ll_l1_,701,l1l111_l1_ (u"ࠨࠩレ"),l1l111_l1_ (u"ࠩࠪロ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬヮ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡳ࠭ࡵࡱࡳ࠱ࡳࡧࡶࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡨࡪࡦࡧࡩࡳ࠭ワ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬヰ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"࠭࠼ࡣࡀࠪヱ"),l1l111_l1_ (u"ࠧࠨヲ")).strip(l1l111_l1_ (u"ࠨࠢࠪン"))
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠨヴ")): continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪヵ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ヶ")+l1lllll_l1_+title,l1ll1ll_l1_,704)
	return
def l11ll1_l1_(url):
	found = False
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩヷ"),url,l1l111_l1_ (u"࠭ࠧヸ"),l1l111_l1_ (u"ࠧࠨヹ"),l1l111_l1_ (u"ࠨࠩヺ"),l1l111_l1_ (u"ࠩࠪ・"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨー"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡷࡵ࡬ࡦ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬヽ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ヾ"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬヿ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㄀"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ㄁"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㄂"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㄃"),l1l111_l1_ (u"ࠫࠬ㄄"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㄅ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩㄆ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄇ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄈ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫㄉ"),block,re.DOTALL)
		if len(items)<30:
			if found: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㄊ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㄋ"),l1l111_l1_ (u"ࠬ࠭ㄌ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄍ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡪࡴࡵࡴࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧㄎ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㄏ"),block,re.DOTALL)
		if 1:
			if found: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧㄐ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪㄑ"),l1l111_l1_ (u"ࠫࠬㄒ"),9999)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧㄓ"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄔ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	if not found: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨㄕ")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ㄖ"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫㄗ"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩㄘ")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪㄙ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬㄚ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫㄛ"),url,data,headers,l1l111_l1_ (u"ࠧࠨㄜ"),l1l111_l1_ (u"ࠨࠩㄝ"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ㄞ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧㄟ"),url,l1l111_l1_ (u"ࠫࠬㄠ"),l1l111_l1_ (u"ࠬ࠭ㄡ"),l1l111_l1_ (u"࠭ࠧㄢ"),l1l111_l1_ (u"ࠧࠨㄣ"),l1l111_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬㄤ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪㄥ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧㄦ"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩㄧ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧㄨ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧㄩ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩㄪ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄫ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㄬ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄭ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨㄮ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄯ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ㄰"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡤࡤࠤࡲ࡭ࡢࠡࡶࡤࡦࡱ࡫ࠠࡧࡷ࡯ࡰࠧ࠮࠮ࠫࡁࠬࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧㄱ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧㄲ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪㄳ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㄴ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬㄵ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬㄶ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫㄷ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ㄸ"),l1l111_l1_ (u"ࠨๅ็๎อ࠭ㄹ"),l1l111_l1_ (u"ࠩส฽้อๆࠨㄺ"),l1l111_l1_ (u"๋ࠪิอแࠨㄻ"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫㄼ"),l1l111_l1_ (u"ࠬ฿ัืࠩㄽ"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭ㄾ"),l1l111_l1_ (u"ࠧศๆห์๊࠭ㄿ"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨㅀ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧㅁ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬㅂ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ㅃ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨㅄ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㅅ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ㅆ"):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㅇ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨㅈ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅉ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅊ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㅋ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫㅌ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩㅍ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪㅎ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫㅏ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅐ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪㅑ")+title,l1ll1ll_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩㅒ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪㅓ"),url,l1l111_l1_ (u"ࠧࠨㅔ"),l1l111_l1_ (u"ࠨࠩㅕ"),l1l111_l1_ (u"ࠩࠪㅖ"),l1l111_l1_ (u"ࠪࠫㅗ"),l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪㅘ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨㅙ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅚ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࠨㅛ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸ࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩㅜ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬㅝ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠪࠧࠬㅞ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅟ"),l1lllll_l1_+title,url,703,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭ㅠ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠮࠮ࠫࡁࠬࡀࡸࡩࡲࡪࡲࡷࡂࠬㅡ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࠬㅢ")+l1l11_l1_+l1l111_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㅣ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨㅤ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩㅥ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡕࡨࡥࡸࡵ࡮ࠨㅦ")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㅧ"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧㅨ"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫㅩ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧㅪ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠱࠳ࠬㅫ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬㅬ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ㅭ"))
			title = title.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪㅮ"),l1l111_l1_ (u"࠭ࠠࠨㅯ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㅰ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬㅱ"),l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬㅲ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧㅳ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬㅴ"),l1l111_l1_ (u"ࠬ࠭ㅵ"),l1l111_l1_ (u"࠭ࠧㅶ"),l1l111_l1_ (u"ࠧࠨㅷ"),l1l111_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪㅸ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧㅹ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫㅺ"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬㅻ"))
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ㅼ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨㅽ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨㅾ")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩㅿ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩㆀ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫㆁ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				title = title.strip(l1l111_l1_ (u"ࠫࡡࡴࠧㆂ"))
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ㆃ")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪㆄ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㆅ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩㆆ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪㆇ"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬㆈ"),l1l111_l1_ (u"ࠫ࠰࠭ㆉ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ㆊ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ㆋ"))
	return
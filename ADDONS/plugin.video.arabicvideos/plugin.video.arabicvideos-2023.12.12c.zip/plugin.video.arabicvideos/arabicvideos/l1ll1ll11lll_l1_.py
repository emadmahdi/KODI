# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ䍤")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡍ࠵ࡗࡢࠫ䍥")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ว็๊ส฽ࠥอแๅษ่ࠫ䍦"),l1l111_l1_ (u"ࠧอ๊าหฯࠦวโๆส้ࠬ䍧")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍨"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䍩"),l1l111_l1_ (u"ࠪࠫ䍪"),389,l1l111_l1_ (u"ࠫࠬ䍫"),l1l111_l1_ (u"ࠬ࠭䍬"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䍭"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䍮"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䍯"),l1l111_l1_ (u"ࠩࠪ䍰"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䍱"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䍲")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭䍳"),l111l1_l1_,381,l1l111_l1_ (u"࠭ࠧ䍴"),l1l111_l1_ (u"ࠧࠨ䍵"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䍶"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䍷"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䍸")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬศ่ห๎ฮ࠭䍹"),l111l1_l1_,381,l1l111_l1_ (u"ࠬ࠭䍺"),l1l111_l1_ (u"࠭ࠧ䍻"),l1l111_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭䍼"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䍽"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ䍾"),l1l111_l1_ (u"ࠪࠫ䍿"),l1l111_l1_ (u"ࠫࠬ䎀"),l1l111_l1_ (u"ࠬ࠭䎁"),l1l111_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䎂"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎃"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎄"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䎅")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"ࠪࠫ䎆"),l1l111_l1_ (u"ࠫࠬ䎇"),l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䎈")+str(seq))
	block = l1l111_l1_ (u"࠭ࠧ䎉")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡥࡥࡱࡵࠦࠬ䎊"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡡࡴ࡫ࡧࡩࠬ䎋"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎌"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䎍"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䎎"),l1l111_l1_ (u"ࠬ࠭䎏"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"࠭วๅล฼่๎ࠦๅีษ๊ำฮ࠭䎐"):
			if first:
				title = l1l111_l1_ (u"ࠧศๆสๅ้อๅࠡࠩ䎑")+title
				first = False
			else: title = l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤࠬ䎒")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎓"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䎔")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䎕"),url,l1l111_l1_ (u"ࠬ࠭䎖"),l1l111_l1_ (u"࠭ࠧ䎗"),l1l111_l1_ (u"ࠧࠨ䎘"),l1l111_l1_ (u"ࠨࠩ䎙"),l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䎚"))
	html = response.content
	if type==l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ䎛"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䎜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎝"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ䎞"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ䎟"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䎠"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䎡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ䎢"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䎣"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䎤") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ䎥"),l1l111_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭䎦"))
		html = html.replace(l1l111_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ䎧"),l1l111_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭䎨"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ䎩"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎪"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ䎫"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ䎬") in url:
				items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䎭"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ䎮") in url:
				items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎯"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䎰"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࠪ䎱") in title:
			title = re.findall(l1l111_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡨࡶ࡮࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎲"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䎳")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼ࠨ䎴"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࠫ䎵") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎶"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䎷") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎸"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡹ࠯ࠨ䎹") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎺"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭䎻") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎼"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䎽"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡔࡦ࡭ࡥࠡࠪ࠱࠮ࡄ࠯ࠠࡰࡨࠣࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䎾"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨ䎿"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠬ࠭䏀") or title==last: continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䏁"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭䏂")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠨࠩ䏃"),l1l111_l1_ (u"ࠩࠪ䏄"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪ䏅")+title+l1l111_l1_ (u"ࠫ࠴࠭䏆"),l1l111_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ䏇")+last+l1l111_l1_ (u"࠭࠯ࠨ䏈"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏉"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัีࠥ฻แฮหࠣࠫ䏊")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠩࠪ䏋"),l1l111_l1_ (u"ࠪࠫ䏌"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䏍"),url,l1l111_l1_ (u"ࠬ࠭䏎"),l1l111_l1_ (u"࠭ࠧ䏏"),l1l111_l1_ (u"ࠧࠨ䏐"),l1l111_l1_ (u"ࠨࠩ䏑"),l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䏒"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䏓"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䏔"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆี็ื้ࠦไๅๅหหึ่ࠦศๆ่ฬึ๋ฬࠡ็้฽์࠭䏕"),l1l111_l1_ (u"࠭ࠧ䏖"),9999)
		return
	if l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䏗") in url or l1l111_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࠫ䏘") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡨࡲࡡࡴࡵࡀࠫ࡮ࡺࡥ࡮ࠩࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧ䏙"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡫ࡰࡪࡵࡲࡨ࡮ࡵࡳࠨࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡦࡹࡴࠣࠩࠪࠫ䏚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂ࠭࡮ࡶ࡯ࡨࡶࡦࡴࡤࡰࠩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠫࠬ࠭䏛"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"ࠬࠦ࠺ࠡࠩ䏜")+name+l1l111_l1_ (u"࠭ࠠศๆะ่็ฯࠧ䏝")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䏞"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䏟"),url,l1l111_l1_ (u"ࠩࠪ䏠"),l1l111_l1_ (u"ࠪࠫ䏡"),l1l111_l1_ (u"ࠫࠬ䏢"),l1l111_l1_ (u"ࠬ࠭䏣"),l1l111_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䏤"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䏥"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪ࡭ࡩࡃࠧࡱ࡮ࡤࡽࡪࡸ࠭ࡰࡲࡷ࡭ࡴࡴ࠭࠲ࠩࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠨࠣࡵ࡫ࡩࡦࡪࡥࡳࠤࡿࠫࡵࡧࡧࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ࠭ࠬ࠭ࠧ䏦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠤࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧࡴࡧࡵࡺࡪࡸࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ䏧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䏨")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䏩")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡮ࡱࡧࡥࡱࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡭ࡰࡦࡤࡰ࠲ࡩ࡬ࡰࡵࡨࠦࠬ䏪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡟ࡠࡡࡧࡰࡤ࡭ࡤࡳ࡫ࡹࡩ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䏫"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䏬")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䏭")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䏮"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ䏯"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ䏰"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ䏱"),l1l111_l1_ (u"࠭ࠫࠨ䏲"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䏳")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ䏴"))
	return
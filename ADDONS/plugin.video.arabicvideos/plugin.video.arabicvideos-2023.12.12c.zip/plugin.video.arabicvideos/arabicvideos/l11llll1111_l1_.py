# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ寊")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠ࡛ࡔࡘࡤ࠭寋")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ富"),l1l111_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ寍"),l1l111_l1_ (u"ࠪฮุา๊ๅࠩ寎"),l1l111_l1_ (u"ࠫฯูฬ๋ๆࠣห้ีฮ้ๆࠪ寏"),l1l111_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩ寐")]
def l11l1ll_l1_(mode,url,text):
	if   mode==660: l1lll_l1_ = l1l1l11_l1_()
	elif mode==661: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==662: l1lll_l1_ = PLAY(url)
	elif mode==663: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==664: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==669: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ寑"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ寒"),l1l111_l1_ (u"ࠨࠩ寓"),l1l111_l1_ (u"ࠩࠪ寔"),l1l111_l1_ (u"ࠪࠫ寕"),l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ寖"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寗"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭寘"),l1l111_l1_ (u"ࠧࠨ寙"),669,l1l111_l1_ (u"ࠨࠩ寚"),l1l111_l1_ (u"ࠩࠪ寛"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ寜"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ寝"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ寞"),l1l111_l1_ (u"࠭ࠧ察"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寠"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ寡")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨ寢"),l111l1_l1_,661,l1l111_l1_ (u"ࠪࠫ寣"),l1l111_l1_ (u"ࠫࠬ寤"),l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ寥"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ實"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ寧"),l1l111_l1_ (u"ࠨࠩ寨"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭審"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ寪"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠫࠬ寫"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ寬"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"࠭࠼ࡣࡀࠪ寭"),l1l111_l1_ (u"ࠧࠨ寮")).replace(l1l111_l1_ (u"ࠨ࠾࠲ࡦࡃ࠭寯"),l1l111_l1_ (u"ࠩࠪ寰")).replace(l1l111_l1_ (u"ࠪࡀࡧࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡴࡨࡸࠧࡄࠧ寱"),l1l111_l1_ (u"ࠫࠬ寲")).replace(l1l111_l1_ (u"ࠬࡂࡢ࠿ࠩ寳"),l1l111_l1_ (u"࠭ࠧ寴")).strip(l1l111_l1_ (u"ࠧࠡࠩ寵"))
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ寶"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ寷")+l1lllll_l1_+title,l1ll1ll_l1_,664)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ寸"),url,l1l111_l1_ (u"ࠫࠬ对"),l1l111_l1_ (u"ࠬ࠭寺"),l1l111_l1_ (u"࠭ࠧ寻"),l1l111_l1_ (u"ࠧࠨ导"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ寽"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ対"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ寿"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ尀"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ封"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧ専"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ尃"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭射"),l1l111_l1_ (u"ࠩࠪ尅"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ将"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧ將")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ專"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ尉"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ尊"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭尋"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ尌"),l1l111_l1_ (u"ࠪࠫ對"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ導"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭小")):
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ尐"):
		url,search = url.split(l1l111_l1_ (u"ࠧࡀࠩ少"),1)
		data = l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ尒")+search
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ尓"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ尔")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ尕"),url,data,headers,l1l111_l1_ (u"ࠬ࠭尖"),l1l111_l1_ (u"࠭ࠧ尗"),l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ尘"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ尙"),url,l1l111_l1_ (u"ࠩࠪ尚"),l1l111_l1_ (u"ࠪࠫ尛"),l1l111_l1_ (u"ࠫࠬ尜"),l1l111_l1_ (u"ࠬ࠭尝"),l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ尞"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠧࠨ尟"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ尠"))
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ尡"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ尢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬ尣"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ尤"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ尥"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭尦"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ尧"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭尨"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ尩"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭尪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ尫"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ尬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨ尭"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ尮"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ尯"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ尰"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ就"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ尲"),l1l111_l1_ (u"࠭ใๅ์หࠫ尳"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭尴"),l1l111_l1_ (u"ࠨ้าหๆ࠭尵"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ尶"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ尷"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ尸"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ尹"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭尺")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠧศ๊้ࠤ้อ๊็ࠢࠪ尻"),l1l111_l1_ (u"ࠨࠩ尼")).replace(l1l111_l1_ (u"ࠩส์๋๊ว๋่ࠣࠫ尽"),l1l111_l1_ (u"ࠪࠫ尾")).replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ尿"),l1l111_l1_ (u"ࠬ࠭局"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ屁"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭层"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ屃"):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ屄"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ居") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屆"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屇"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ屈"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ屉"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ届"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ屋")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ屌"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屍"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ屎")+title,l1ll1ll_l1_,661)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ屏"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ屐"),url,l1l111_l1_ (u"ࠨࠩ屑"),l1l111_l1_ (u"ࠩࠪ屒"),l1l111_l1_ (u"ࠪࠫ屓"),l1l111_l1_ (u"ࠫࠬ屔"),l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ展"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ屖"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ屗"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ屘")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ屙"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠪࠧࠬ屚"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屛"),l1lllll_l1_+title,url,663,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭屜"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠧ屝")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭属"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ屟"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ屠")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠲࠴࠭屡"))
			title = title.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ屢"),l1l111_l1_ (u"ࠬࠦࠧ屣"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ層"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ履"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫ屦"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭屧"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ屨"),l1l111_l1_ (u"ࠫࠬ屩"),l1l111_l1_ (u"ࠬ࠭屪"),l1l111_l1_ (u"࠭ࠧ屫"),l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ屬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ屭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ屮"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ屯"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭屰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩ山"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ屲")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ屳"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ屴"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ屵"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ屶"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭屷"),l1l111_l1_ (u"ࠬ࠱ࠧ屸"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ屹")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ屺"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ媗")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ媘"):l1l111_l1_ (u"ࠩࠪ媙")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ媚")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ媛"),l1l111_l1_ (u"ࠬࡽࡷࡦࠩ媜")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭媝")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ媞")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媟"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ媠"),l111l1_l1_,569,l1l111_l1_ (u"ࠪࠫ媡"),l1l111_l1_ (u"ࠫࠬ媢"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ媣"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媤"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ媥"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ媦"),564)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媧"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭媨"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ媩"),565)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ媪"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媫"),l1l111_l1_ (u"ࠧࠨ媬"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ媭"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ媮"),l1l111_l1_ (u"ࠪࠫ媯"),l1l111_l1_ (u"ࠫࠬ媰"),l1l111_l1_ (u"ࠬ࠭媱"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ媲"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ媳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ媴"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠩࠪ媵"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媶"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭媷")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ媸"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媹"),l1l111_l1_ (u"ࠧࠨ媺"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ媻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ媼"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媽"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭媾")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ媿"),url,l1l111_l1_ (u"࠭ࠧ嫀"),l1l111_l1_ (u"ࠧࠨ嫁"),l1l111_l1_ (u"ࠨࠩ嫂"),l1l111_l1_ (u"ࠩࠪ嫃"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嫄"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ嫅") in html:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫆"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ嫇"),url,561,l1l111_l1_ (u"ࠧࠨ嫈"),l1l111_l1_ (u"ࠨࠩ嫉"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嫊"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ嫋"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫌"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫍"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1lll1lll11l_l1_,type=l1l111_l1_ (u"࠭ࠧ嫎")):
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ嫏") in l1lll1lll11l_l1_:
		l1llllll_l1_,url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嫐"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭嫑"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1lll11l_l1_,l1lll1lll11l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嫒"),url,l1l111_l1_ (u"ࠫࠬ嫓"),l1l111_l1_ (u"ࠬ࠭嫔"),l1l111_l1_ (u"࠭ࠧ嫕"),l1l111_l1_ (u"ࠧࠨ嫖"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ嫗"))
	html = response.content
	if type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嫘"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ嫙"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ嫚"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ嫛"),l1l111_l1_ (u"࠭࠯ࠨ嫜")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ嫝"),l1l111_l1_ (u"ࠨࠤࠪ嫞"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡋࡷ࡯ࡤ࠮࠯࡚ࡩࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡒࡪࡩ࡫ࡸ࡚ࡏࠢࠨ嫟"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࡙ࠪࠦ࡮ࡵ࡮ࡤ࠰࠱ࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ嫠"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ嫡"),l1l111_l1_ (u"ࠬ࠭嫢"))
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ嫣") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫤"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠨฯ็ๆฮ࠭嫥") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ嫦"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ嫧") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫨"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嫩"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ嫪"):
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ嫫"),block,re.DOTALL)
			if l111l1lll1_l1_:
				count = l111l1lll1_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ嫬")+count
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫭"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭嫮"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠫࠬ嫯"),l1l111_l1_ (u"ࠬ࠭嫰"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ嫱"))
		elif type==l1l111_l1_ (u"ࠧࠨ嫲"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ嫳"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嫴"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ูࠪๆำษࠡࠩ嫵")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫶"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭嫷")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嫸"),url,l1l111_l1_ (u"ࠧࠨ嫹"),l1l111_l1_ (u"ࠨࠩ嫺"),l1l111_l1_ (u"ࠩࠪ嫻"),l1l111_l1_ (u"ࠪࠫ嫼"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ嫽"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嫾"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ嫿"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬀"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠨࠩ嬁"),l1l111_l1_ (u"ࠩࠪ嬂"),l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ嬃"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡊࡶࡩࡴࡱࡧࡩࡸ࠳࠭ࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷ࡮ࡴࡧ࡭ࡧࡶࡩࡨࡺࡩࡰࡰࡶࡂࠬ嬄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭嬅"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ嬆"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嬇"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬈"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ嬉"),l1l111_l1_ (u"ࠪࠫ嬊")).replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ嬋"),l1l111_l1_ (u"ࠬ࠭嬌"))
		else: title = l1l111_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ嬍")
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嬎"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嬏"),url,l1l111_l1_ (u"ࠩࠪ嬐"),l1l111_l1_ (u"ࠪࠫ嬑"),l1l111_l1_ (u"ࠫࠬ嬒"),l1l111_l1_ (u"ࠬ࠭嬓"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ嬔"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嬕"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ嬖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嬗"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嬘") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ุࠫ๐ัโำࠣ์๏ࠦำ๋็สࠫ嬙"): name = l1l111_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ嬚")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ嬛")+name+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ嬜")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嬝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嬞"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嬟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ嬠"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ嬡")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ嬢")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡸࡧࡦ࡭ࡲࡧࠧ嬣")+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ嬤")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嬥"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠪࠫ嬦")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ嬧"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭嬨"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ嬩"),l1l111_l1_ (u"ࠧࠬࠩ嬪"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠨ࠱ࠪ嬫"),l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡵࡨࡶ࡮࡫ࡳࠨ嬬"),l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡤࡲ࡮ࡳࡥࠨ嬭"),l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡸࡻ࠭嬮"),l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嬯")]
	l1ll11111_l1_ = [l1l111_l1_ (u"࠭รโๆส้ࠬ嬰"),l1l111_l1_ (u"ࠧๆี็ื้อสࠨ嬱"),l1l111_l1_ (u"ࠨล้๎๊๐้ࠠๅิฮํ์ࠧ嬲"),l1l111_l1_ (u"ࠩหีฬ๋ฬࠡฬ็๎ๆุ๊้่ࠪ嬳"),l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤํษๆ๋็ํࠫ嬴")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ嬵"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ嬶")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1lll11l_l1_,filter):
	if l1l111_l1_ (u"࠭࠿ࡀࠩ嬷") in l1lll1lll11l_l1_: url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭嬸"))[0]
	else: url = l1lll1lll11l_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ嬹"),l1l111_l1_ (u"ࠩࠪ嬺"))
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ嬻"),1)
	if filter==l1l111_l1_ (u"ࠫࠬ嬼"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭嬽"),l1l111_l1_ (u"࠭ࠧ嬾")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嬿"))
	if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ孀"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠩࡀࡁࠬ孁") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠪࡁࡂ࠭孂") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ孃")+category+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ孄")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ孅")+category+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ孆")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ孇"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭孈")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭孉"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ孊"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ孋")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ孌"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ孍"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩ孎"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ孏"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫ子"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ孑")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孒"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ孓"),l1111111_l1_,561,l1l111_l1_ (u"ࠧࠨ孔"),l1l111_l1_ (u"ࠨࠩ孕"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ孖"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ字"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ存")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ孙"),l1111111_l1_,561,l1l111_l1_ (u"࠭ࠧ孚"),l1l111_l1_ (u"ࠧࠨ孛"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ孜"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ孝"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ孞"),l1l111_l1_ (u"ࠫࠬ孟"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ孠"),url,l1l111_l1_ (u"࠭ࠧ孡"),l1l111_l1_ (u"ࠧࠨ孢"),l1l111_l1_ (u"ࠨࠩ季"),l1l111_l1_ (u"ࠩࠪ孤"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭孥"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ学"),l1l111_l1_ (u"ࠬࠨࠧ孧")).replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ孨"),l1l111_l1_ (u"ࠧ࠰ࠩ孩"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡺࡩࡨ࡯࡭ࡢ࠯࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡺࡩࡨ࡯࡭ࡢ࠯࠰ࡪ࡮ࡲࡴࡦࡴࡁࠫ孪"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡷࡥࡽࡵ࡮ࡰ࡯ࡼࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࡫࡯࡬ࡵࡧࡵࡦࡴࡾࠧ孫"),block+l1l111_l1_ (u"ࠪࡀ࡫࡯࡬ࡵࡧࡵࡦࡴࡾࠧ孬"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭孭") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡺࡸࡵࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡼࡹࡄࠧ孮"),block,re.DOTALL)
		if l1l111_l1_ (u"࠭࠽࠾ࠩ孯") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ孰"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ孱")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ孲"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ孳"),l1111111_l1_,561,l1l111_l1_ (u"ࠫࠬ孴"),l1l111_l1_ (u"ࠬ࠭孵"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ孶"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孷"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ學"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠩࠪ孹"),l1l111_l1_ (u"ࠪࠫ孺"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ孻"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ孼")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ孽")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ孾")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ孿")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭宀")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宁"),l1lllll_l1_+name+l1l111_l1_ (u"ࠫ࠿ࠦวๅฮ่๎฾࠭宂"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠬ࠭它"),l1l111_l1_ (u"࠭ࠧ宄"),l1l111l1_l1_+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ宅"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠨࡴࠪ宆") or value==l1l111_l1_ (u"ࠩࡱࡧ࠲࠷࠷ࠨ宇"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ守") in option: continue
			if l1l111_l1_ (u"ࠫฬ๊ใๅࠩ安") in option: continue
			if l1l111_l1_ (u"ࠬࡴ࠭ࡢࠩ宊") in value: continue
			if option==l1l111_l1_ (u"࠭ࠧ宋"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ完"),option,re.DOTALL)
			if l1ll1l11l11_l1_: l1l11l1ll_l1_ = l1ll1l11l11_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠨ࠼ࠣࠫ宍")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ宎")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠭宏")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ宐")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨ宑")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ宒")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ宓"):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宔"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠩࠪ宕"),l1l111_l1_ (u"ࠪࠫ宖"),l1l1l11l_l1_+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭宗"))
			elif type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ官") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"࠭࠽࠾ࠩ宙") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ定"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ宛")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1lll11l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宜"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠪࠫ宝"),l1l111_l1_ (u"ࠫࠬ实"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭実"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宠"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠧࠨ审"),l1l111_l1_ (u"ࠨࠩ客"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ宣"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ室"),l1l111_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ宥")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠬࡳࡰࡢࡣࠪ宦"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ宧"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭宨"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ宩"),l1l111_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ宪"),l1l111_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ宫"),l1l111_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ宬"),l1l111_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ宭")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭宮") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ宯"),l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ宰"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ宱"),l1l111_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ宲"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫࡂࡃࠧ害"),l1l111_l1_ (u"ࠬ࠵ࠧ宴"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭ࠦࠧࠩ宵"),l1l111_l1_ (u"ࠧ࠰ࠩ家"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ宷"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠩࠪ宸")
	if l1l111_l1_ (u"ࠪࡁࡂ࠭容") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫࠬࠧ宺"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃ࠽ࠨ宻"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨ宼")
		if l1l111_l1_ (u"ࠧࠦࠩ宽") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ宾") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ宿"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ寀")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ寁") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ寂"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ寃")+key+l1l111_l1_ (u"ࠧ࠾࠿ࠪ寄")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ寅"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ密")+key+l1l111_l1_ (u"ࠪࡁࡂ࠭寇")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ寈"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ寉"))
	return l1l1l111_l1_
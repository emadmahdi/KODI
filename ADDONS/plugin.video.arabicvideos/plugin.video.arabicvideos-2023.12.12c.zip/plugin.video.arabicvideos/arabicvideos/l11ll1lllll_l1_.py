# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ囍")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡙ࡈࡏࡡࠪ囎")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"่ࠬๆ้ษอࠤๆ฼วว์ฬࠫ囏"),l1l111_l1_ (u"࠭แศำึ็ํ࠭囐"),l1l111_l1_ (u"ࠧࡔࡪࡲࡻࠥࡳ࡯ࡳࡧࠪ囑")]
def l11l1ll_l1_(mode,url,text):
	if   mode==580: l1lll_l1_ = l1l1l11_l1_()
	elif mode==581: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==582: l1lll_l1_ = PLAY(url)
	elif mode==583: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==584: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==589: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ囒"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ囓"),l1l111_l1_ (u"ࠪࠫ囔"),l1l111_l1_ (u"ࠫࠬ囕"),l1l111_l1_ (u"ࠬ࠭囖"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ囗"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囘"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ囙"),l1l111_l1_ (u"ࠩࠪ囚"),589,l1l111_l1_ (u"ࠪࠫ四"),l1l111_l1_ (u"ࠫࠬ囜"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ囝"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ回"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ囟"),l1l111_l1_ (u"ࠨࠩ因"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭囡"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ团"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠫࠬ団"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ囤"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囥"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ囦")+l1lllll_l1_+title,l1ll1ll_l1_,584)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ囧"),url,l1l111_l1_ (u"ࠩࠪ囨"),l1l111_l1_ (u"ࠪࠫ囩"),l1l111_l1_ (u"ࠫࠬ囪"),l1l111_l1_ (u"ࠬ࠭囫"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ囬"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ园"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ囮"),l1l111_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ囯"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ困"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠫࠬ囱"),block)]
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ囲"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ図"),l1l111_l1_ (u"ࠧࠨ围"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭囵"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠩ࠽ࠤࠬ囶")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囷"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ囸"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ囹"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ固"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ囻"),l1l111_l1_ (u"ࠨࠩ囼"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ国"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠪࠫ图")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ囿"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ圀"),url,l1l111_l1_ (u"࠭ࠧ圁"),l1l111_l1_ (u"ࠧࠨ圂"),l1l111_l1_ (u"ࠨࠩ圃"),l1l111_l1_ (u"ࠩࠪ圄"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ圅"))
	html = response.content
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圆"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬ圇"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ圈"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圉"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ圊"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ國"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ圌"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ圍"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ圎"),l1l111_l1_ (u"࠭ใๅ์หࠫ圏"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭圐"),l1l111_l1_ (u"ࠨ้าหๆ࠭圑"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ園"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ圓"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ圔"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ圕"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭圖")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩ圗"))
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭團") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ圙")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ圚"))
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ圛") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ圜")+l1ll1l_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ圝"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ圞"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ土"),l1lllll_l1_+title,l1ll1ll_l1_,582,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ圠") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ圡") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圢"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ圣") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圤"),l1lllll_l1_+title,l1ll1ll_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ圥"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ圦"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ圧")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ在"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ圩"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ圪"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ圫")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ圬"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圭"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ圮")+title,l1ll1ll_l1_,581)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷ࡭ࡵࡷ࡮ࡱࡵࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ圯"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ地"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬิศ้าอࠥอไๆิํำࠬ圱"),l1ll1ll_l1_,581)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ圲"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ圳"),url,l1l111_l1_ (u"ࠨࠩ圴"),l1l111_l1_ (u"ࠩࠪ圵"),l1l111_l1_ (u"ࠪࠫ圶"),l1l111_l1_ (u"ࠫࠬ圷"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ圸"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭࡮ࡢࡸ࠰ࡷࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ圹"),html,re.DOTALL)
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ场"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠨࠥࠪ圻"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ圼"),l1lllll_l1_+title,url,583,l1l111_l1_ (u"ࠪࠫ圽"),l1l111_l1_ (u"ࠫࠬ圾"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ圿")+l1l11_l1_+l1l111_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ址"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭坁"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ坂")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ坃"))
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ坄"),l1lllll_l1_+title,l1ll1ll_l1_,582)
		else:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ坅"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ坆") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ均")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ坈"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ坉"),l1lllll_l1_+title,l1ll1ll_l1_,582)
	return
def PLAY(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭坊"))
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ坋"),url,l1l111_l1_ (u"ࠫࠬ坌"),l1l111_l1_ (u"ࠬ࠭坍"),l1l111_l1_ (u"࠭ࠧ坎"),l1l111_l1_ (u"ࠧࠨ坏"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ坐"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ坑"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ坒") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ坓")+l1ll1ll_l1_
	hash = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࡮ࡡࡴࡪࡀࠫ坔"))[1]
	parts = hash.split(l1l111_l1_ (u"࠭࡟ࡠࠩ坕"))
	l1l1lllllll1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l111_l1_ (u"ࠧ࠾ࠩ坖"))
			if kodi_version>18.99: part = part.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭块"))
			l1l1lllllll1_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l111_l1_ (u"ࠩࡁࠫ坘").join(l1l1lllllll1_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	if l1l111_l1_ (u"ࠪࡪࡦࡸࡳࡰ࡮ࠪ坙") not in str(l1ll_l1_):
		for l1ll1ll_l1_ in l1ll_l1_:
			title,l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠥࡃ࠾ࠡࠩ坚"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭坛")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ坜")
			l1llll_l1_.append(l1ll1ll_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭坝"),url)
	else:
		title,l1ll1ll_l1_ = l1ll_l1_[0].split(l1l111_l1_ (u"ࠨࠢࡀࡂࠥ࠭坞"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ坟"),l1l111_l1_ (u"ࠪࠫ坠"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ坡"),l1l111_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫ坢")+l1l111_l1_ (u"࠭࡜࡯ࠩ坣")+l1l111_l1_ (u"๋ࠧำฯํࠥอไๆฯส์้ฯࠠๅษะๆฬ࠭坤")+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭坥")+title)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ坦"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ坧"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭坨"),l1l111_l1_ (u"ࠬ࠱ࠧ坩"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ坪")+search
	l1lll11_l1_(url)
	return
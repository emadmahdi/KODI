# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ椝")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ椞")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠪࠫ椟")
#headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ椠"):l11ll1_l1_ (u"ࠬ࠭椡")}
l1ll1l1ll1ll1_l1_ = 0
def MAIN(mode,url,text,type,l1l1111_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1l1ll1l11_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11111_l1_(url,l1l1111_l1_,text)
	elif mode==145: results = l1ll1ll1llll1_l1_(url,l1l1111_l1_)
	elif mode==147: results = l1ll1ll11l1l1_l1_()
	elif mode==148: results = l1ll1ll11ll11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭椢"),l111l1_l1_+l11ll1_l1_ (u"ࠧใษษ้ฮ࠭椣"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡆࡰ࠵ࡈࡵ࠻ࡊࡍ࠾࡚࡯ࡗࡥࡊ࠵ࡘࡖ࠮࠹ࡊ࠷ࡇࡵࡱࡊࡻ࡝ࡅ࠹ࡻࡓࡂࠩ椤"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ椥"),l111l1_l1_+l11ll1_l1_ (u"ุࠪำ฻ࠧ椦"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࡘࡈࡔ࡯ࡧࡨ࡬ࡧ࡮ࡧ࡬ࠨ椧"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椨"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅ้ไ฼ࠫ椩"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡶ࠻࠹ࡢࡉࡑࡷࡶ࠿ࡢࡣࡪࡺ࡚࡙ࡷ࠱ࡖࡶࡹ࡫ࡼ࠭椪"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ椫"),l111l1_l1_+l11ll1_l1_ (u"ࠩะืฬฮࠧ椬"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡅ࡚ࡨࡦࡕࡲࡧ࡮ࡧ࡬ࡄࡖ࡙ࠫ椭"),144)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ椮"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไฺษหࠫ椯"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ椰"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ椱"),l111l1_l1_+l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠧ椲"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ椳"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ椴"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫิสศำสฮࠬ椵"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ椶"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭椷"),l111l1_l1_+l11ll1_l1_ (u"ࠧใืํีฮ࠭椸"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ椹"),144,l11ll1_l1_ (u"ࠩࠪ椺"),l11ll1_l1_ (u"ࠪࠫ椻"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ椼"))
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椽"),l111l1_l1_+l11ll1_l1_ (u"࠭สึใะࠫ椾"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ椿"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楀"),l111l1_l1_+l11ll1_l1_ (u"ࠩิส๏ู๊สࠩ楁"),l11l1l_l1_+l11ll1_l1_ (u"ࠪࠫ楂"),144)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ楃"),l111l1_l1_+l11ll1_l1_ (u"ࠬืววฮࠪ楄"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠿ࡣࡲࡀࠫ楅"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ楆"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ楇"),l11ll1_l1_ (u"ࠩࠪ楈"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楉"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ楊"),l11ll1_l1_ (u"ࠬ࠭楋"),149,l11ll1_l1_ (u"࠭ࠧ楌"),l11ll1_l1_ (u"ࠧࠨ楍"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ楎"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ楏"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ楐"),l11ll1_l1_ (u"ࠫࠬ楑"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ楒"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ楓"),l11l1l_l1_+l11ll1_l1_ (u"ࠧࠨ楔"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楕"),l111l1_l1_+l11ll1_l1_ (u"ࠩส่ึอฦอหࠪ楖"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ楗"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ楘"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไหืไัࠬ楙"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ楚"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ楛"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ๆฺ๐ัสࠩ楜"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ楝"),144,l11ll1_l1_ (u"ࠪࠫ楞"),l11ll1_l1_ (u"ࠫࠬ楟"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ楠"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭楡"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆะอหึอสࠡ์๋ฮ๏๎ศࠨ楢"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ楣"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ楤"),l111l1_l1_+l11ll1_l1_ (u"้ࠪำะวาษอࠤฬ๊ศา่ส้ั࠭楥"),l11ll1_l1_ (u"ࠫࠬ楦"),290)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ楧"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭楨"),l11ll1_l1_ (u"ࠧࠨ楩"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楪"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ楫"),l11ll1_l1_ (u"ࠪࠫ楬"),147)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ業"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢฦะ๋ฮ๊สࠩ楮"),l11ll1_l1_ (u"࠭ࠧ楯"),148)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ楰"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ楱"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ楲"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楳"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ楴"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ極"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭楶"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾๋ࠥำาฯํหฯูࠦาสํอࠬ楷"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืึำ๊สࠩ楸"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ楹"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ楺"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ楻"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ楼"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ楽"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭楾"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楿"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ榀"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ榁"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ概"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣา฼ฮษࠡษ็้ึาู๋หࠪ榃"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰้ัษๆสล࠰อไโุสส๏ฯࠫฯูหอ࠰อไอ็฼อࠫࡹࡰ࠾ࡅࡄࡍࡘࡇࡨࡂࡄࠪ榄"),144)
	return
def l1ll1l1ll1l11_l1_(url,name,l111_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ榅"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡅࡋࡒࡑࡀࠠࠡࠩ榆")+name,url,144,l111_l1_)
	return
def l1ll1ll11l1l1_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬสฮࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ榇"))
	return
def l1ll1ll11ll11_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡹࡼࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ榈"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ榉"),l11ll1_l1_ (u"ࠬ࠭榊"),l11ll1_l1_ (u"࠭ࠧ榋"),url)
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩ榌")
	#items = re.findall(l11ll1_l1_ (u"ࠨࡸࡀࠬ࠳࠰࠿ࠪࠦࠪ榍"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭榎")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ榏"))
	#return
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡰࡴࡴࡸࡴࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖࠎࠎࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧࠋࠋࡨࡶࡷࡵࡲࡴ࠮ࡷ࡭ࡹࡲࡥࡴ࠮࡯࡭ࡳࡱࡳࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶࠭ࡻࡲ࡭ࠫࠍࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࠭࠮࠯࠰࠱ࠫࠡࠢࠪ࠯ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩࠪࠌࠌࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕࠨ࡭࡫ࡱ࡯ࡸࡡ࠰࡞࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠬࡵࡻࡳࡩ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠊࠤࠥࠦ榐")
	url = url.split(l11ll1_l1_ (u"ࠬࠬࠧ榑"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1ll1111l1_l1_(cc,url,index):
	level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = index.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ榒"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ榓"),l11ll1_l1_ (u"ࠨࠩ榔"),index,l11ll1_l1_ (u"ࠩࡉࡍࡗ࡙ࡔࠨ榕")+l11ll1_l1_ (u"ࠪࡠࡳ࠭榖")+url)
	l1ll1l1ll111l_l1_,l1ll1l1ll11ll_l1_ = [],[]
	# l1l1111lll1_l1_ l11l111l111l_l1_    should be the first item in the l1ll1l1ll111l_l1_ list
	if l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ榗") in url: l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞ࠤ榘"))
	# l1l1111lll1_l1_ search l1ll1lll1111l_l1_      should be the first item in the l1ll1l1ll111l_l1_ list
	if l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ榙") in url: l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࠧ榚"))
	# main l1l1111_l1_
	if level==l11ll1_l1_ (u"ࠨ࠳ࠪ榛"): l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡧࡧࡨࡨࡋ࡯࡬ࡵࡧࡵࡇ࡭࡯ࡰࡃࡣࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ榜"))
	# search results
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ榝"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࠧ榞"))
	# l1ll1ll11lll1_l1_ l1ll1ll11l11l_l1_ & main l1l1111_l1_ l1ll1ll11l11l_l1_ l1ll1lll1111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡨࡲࡹࡸࡩࡦࡵࠪࡡࠧ榟"))
	# l1ll1ll1111ll_l1_ menu
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠ࡟࠸ࡣ࡛ࠨࡩࡸ࡭ࡩ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ榠"))
	l1ll1ll1l1111_l1_,dd,l1ll1l1l1l1ll_l1_ = l1ll1l1l1llll_l1_(cc,l11ll1_l1_ (u"ࠧࠨ榡"),l1ll1l1ll111l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ榢"),str(dd))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ榣"),l11ll1_l1_ (u"ࠪࠫ榤"),l11ll1_l1_ (u"ࠫࠬ榥"),str(len(dd)))
	if level==l11ll1_l1_ (u"ࠬ࠷ࠧ榦") and l1ll1ll1l1111_l1_:
		if len(dd)>1 and l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ榧") not in url:
			for zz in range(len(dd)):
				l1ll1l1lll1ll_l1_ = str(zz)
				l1ll1l1ll111l_l1_ = []
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞ࠦ榨")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ榩"))
				# l1ll1ll11lll1_l1_ l1ll1ll11l11l_l1_
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠࠨ榪")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࠧ࡞ࠤ榫"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ榬")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠧࡣࠢ榭"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1l1llll_l1_(dd,l11ll1_l1_ (u"࠭ࠧ榮"),l1ll1l1ll111l_l1_)
				if succeeded: l1ll1l1ll11ll_l1_.append([item,url,l11ll1_l1_ (u"ࠧ࠳࠼࠽ࠫ榯")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ榰")])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll11l_l1_(item,url,l11ll1_l1_ (u"ࠩ࠵࠾࠿࠭榱")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ榲"))
				#if l1l1l1l1lll1_l1_: l1ll11l1l1_l1_ += 1
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token = l1ll1lll111l1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ榳"),l111l1_l1_+title,l1lllll_l1_,144,l11ll1_l1_ (u"ࠬ࠭榴"),l11ll1_l1_ (u"࠭࠲࠻࠼ࠪ榵")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ榶"))
				#l1ll11l1l1_l1_ += 1
			# main l1l1111_l1_ l1ll1ll11l11l_l1_ l1ll1lll1111l_l1_
			l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣࠢ榷"))
			succeeded,item,l111l1ll_l1_ = l1ll1l1l1llll_l1_(cc,l11ll1_l1_ (u"ࠩࠪ榸"),l1ll1l1ll111l_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ榹"),str(cc))
			if succeeded and l1ll1l1ll11ll_l1_ and l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪ榺") in list(item.keys()):
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ榻")
				l1ll1l1ll11ll_l1_.append([item,l1lllll_l1_,l11ll1_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ榼")])
	return dd,l1ll1ll1l1111_l1_,l1ll1l1ll11ll_l1_,l1ll1l1l1l1ll_l1_
def l1ll1l1l1ll11_l1_(cc,dd,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ榽"),l11ll1_l1_ (u"ࠨࠩ榾"),index,l11ll1_l1_ (u"ࠩࡖࡉࡈࡕࡎࡅࠩ榿")+l11ll1_l1_ (u"ࠪࡠࡳ࠭槀")+url)
	level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = index.split(l11ll1_l1_ (u"ࠫ࠿ࡀࠧ槁"))
	l1ll1l1ll111l_l1_,l1ll1ll111l11_l1_ = [],[]
	# search results
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ槂"))
	# main l1l1111_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ槃")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ槄"))
	# l11ll111111l_l1_ l1ll1ll11l11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟࠶ࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ槅"))
	# l1l1111lll1_l1_ search & l11l111l111l_l1_ & l1ll1lll1111l_l1_
	if l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ槆") in url: l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ槇"))
	elif l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ槈") in url: l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ槉"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ槊")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ構"))
	# l11ll111111l_l1_ l11ll11ll1_l1_ & l1ll1ll11l11l_l1_ filters
	if l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ槌") in url or (l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ槍") in url and l11ll1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ槎") not in url):
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ槏")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ槐"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ槑")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ槒"))
	# l1ll1ll11lll1_l1_ search
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ槓")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ槔"))
	# main l1l1111_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡࠢ槕")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ槖"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ槗")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠨ࡝ࠣ様"))
	l1ll1ll11ll1l_l1_,ee,l1ll1ll111111_l1_ = l1ll1l1l1llll_l1_(dd,l11ll1_l1_ (u"ࠧࠨ槙"),l1ll1l1ll111l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ槚"),str(ee))
	#DIALOG_OK()
	if level==l11ll1_l1_ (u"ࠩ࠵ࠫ槛") and l1ll1ll11ll1l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll1l1ll111l_l1_ = []
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ槜")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ槝"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ槞")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ槟"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ槠")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ槡"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ槢")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ槣"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ槤")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ槥"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ槦")+index2+l11ll1_l1_ (u"ࠢ࡞ࠤ槧"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1l1llll_l1_(ee,l11ll1_l1_ (u"ࠨࠩ槨"),l1ll1l1ll111l_l1_)
				if succeeded: l1ll1ll111l11_l1_.append([item,url,l11ll1_l1_ (u"ࠩ࠶࠾࠿࠭槩")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭槪")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀ࠰ࠨ槫")])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll11l_l1_(item,url,l11ll1_l1_ (u"ࠬ࠹࠺࠻ࠩ槬")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"࠭࠺࠻ࠩ槭")+index2+l11ll1_l1_ (u"ࠧ࠻࠼࠳ࠫ槮"))
				#if l1l1l1l1lll1_l1_: l1l1l11l11_l1_ += 1
				#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ槯"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭槰")+str(item))
				#l1l1l11l11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token = l1ll1lll111l1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槱"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,l11ll1_l1_ (u"ࠫ࠸ࡀ࠺ࠨ槲")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ槳")+index2+l11ll1_l1_ (u"࠭࠺࠻࠲ࠪ槴"))
			# search l1ll1lll1111l_l1_
			l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠶ࡣࠢ槵"))
			# search l1ll1lll1111l_l1_
			l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟࠶ࡣࠢ槶"))
			succeeded,item,l111l1ll_l1_ = l1ll1l1l1llll_l1_(dd,l11ll1_l1_ (u"ࠩࠪ槷"),l1ll1l1ll111l_l1_)
			if succeeded and l1ll1ll111l11_l1_ and l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ槸") in list(item.keys()):
				l1ll1ll111l11_l1_.append([item,url,l11ll1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ槹")])
			#l1l1l1l1lll1_l1_ = l1ll1ll1ll11l_l1_(item,url,l11ll1_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ槺"))
			#if l1l1l1l1lll1_l1_: l1l1l11l11_l1_ += 1
			#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ槻"),str(item))
			#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ槼"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ槽")+token)
	return ee,l1ll1ll11ll1l_l1_,l1ll1ll111l11_l1_,l1ll1ll111111_l1_
def l1ll1l1ll1l1l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ槾"),l11ll1_l1_ (u"ࠪࠫ槿"),index,l11ll1_l1_ (u"࡙ࠫࡎࡉࡓࡆࠪ樀")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ樁")+url)
	level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = index.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ樂"))
	l1ll1l1ll111l_l1_,l1ll1l1lll111_l1_ = [],[]
	# search results
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ樃")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡻ࡫ࡲࡵ࡫ࡦࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ樄"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ樅")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ樆"))
	# l1ll1ll1ll111_l1_ menu l1ll1ll11l11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ樇")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ樈"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ樉")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ樊"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ樋")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ樌"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ樍")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ樎"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ樏")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ樐"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ樑")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ樒"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ樓"))
	# l1ll1ll11lll1_l1_ l1ll1lll111ll_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ樔"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ樕"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ樖")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ樗"))
	# main l1l1111_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ樘")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ標"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࠧ樚"))
	l1ll1ll1l11l1_l1_,ff,l1ll1lll11111_l1_ = l1ll1l1l1llll_l1_(ee,l11ll1_l1_ (u"ࠪࠫ樛"),l1ll1l1ll111l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ樜"),str(ff))
	if level==l11ll1_l1_ (u"ࠬ࠹ࠧ樝") and l1ll1ll1l11l1_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1ll1ll11l111_l1_ = str(zz)
				#DIALOG_OK()
				l1ll1l1ll111l_l1_ = []
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠥ樞")+l1ll1ll11l111_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ樟"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠧ樠")+l1ll1ll11l111_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ模"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠢ樢")+l1ll1ll11l111_l1_+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ樣"))
				l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠤ樤")+l1ll1ll11l111_l1_+l11ll1_l1_ (u"ࠨ࡝ࠣ樥"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1l1llll_l1_(ff,l11ll1_l1_ (u"ࠧࠨ樦"),l1ll1l1ll111l_l1_)
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token = l1ll1lll111l1_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ樧"),l111l1_l1_+l1lllll_l1_,l1lllll_l1_,143,l1lll1_l1_)
				if succeeded: l1ll1l1lll111_l1_.append([item,url,l11ll1_l1_ (u"ࠩ࠷࠾࠿࠭樨")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭権")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ横")+l1ll1ll11l111_l1_])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll11l_l1_(item,url,l11ll1_l1_ (u"ࠬ࠺࠺࠻ࠩ樫")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"࠭࠺࠻ࠩ樬")+index2+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ樭")+l1ll1ll11l111_l1_)
				#if l1l1l1l1lll1_l1_: l1l1l11l1l_l1_ += 1
	return ff,l1ll1ll1l11l1_l1_,l1ll1l1lll111_l1_,l1ll1lll11111_l1_
def l1ll1l1l1llll_l1_(l11ll111ll1l_l1_,l11ll11ll11l_l1_,l1ll1l1lll1l1_l1_):
	cc,l11ll11ll11l_l1_ = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	dd,l11ll11ll11l_l1_ = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	ee,l11ll11ll11l_l1_ = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	ff,l11ll11ll11l_l1_ = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	item,render = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	count = len(l1ll1l1lll1l1_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1l1lll1l1_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠨࠩ樮")
			return True,out,l11ll11111_l1_+1
		except: pass
	return False,l11ll1_l1_ (u"ࠩࠪ樯"),0
def l11111_l1_(url,index=l11ll1_l1_ (u"ࠪࠫ樰"),data=l11ll1_l1_ (u"ࠫࠬ樱")):
	l1ll1l1ll11ll_l1_,l1ll1ll111l11_l1_,l1ll1l1lll111_l1_ = [],[],[]
	if l11ll1_l1_ (u"ࠬࡀ࠺ࠨ樲") not in index: index = l11ll1_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ樳")
	level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = index.split(l11ll1_l1_ (u"ࠧ࠻࠼ࠪ樴"))
	if level==l11ll1_l1_ (u"ࠨ࠶ࠪ樵"): level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ樶"),l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ樷"),l11ll1_l1_ (u"ࠫࠬ樸"),index,url)
	data = data.replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ樹"),l11ll1_l1_ (u"࠭ࠧ樺"))
	html,cc,l11ll11l1_l1_ = l1ll1ll111l1l_l1_(url,data)
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍ࡮࡬ࠠࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰࠥࡵࡲࠡࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࠣࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡰࡹࡱࡩࡷࡔࡡ࡮ࡧࠥ࠲࠯ࡅࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦ࡭࡫ࠦ࡮ࡰࡶࠣࡳࡼࡴࡥࡳ࠼ࠣࠎࠎࠏ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡴ࡯ࡵࠢࡲࡻࡳ࡫ࡲ࠻ࠢࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡹ࡭ࡩ࡫࡯ࡐࡹࡱࡩࡷࠨ࠮ࠫࡁࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶ࠿ࠐࠉࠊࠋࡲࡻࡳ࡫ࡲࡏࡃࡐࡉࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠳ࡡ࠮ࠐࠉࠊࠋࡲࡻࡳ࡫ࡲࡏࡃࡐࡉࠥࡃࠠࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ࠰ࡵࡷ࡯ࡧࡵࡒࡆࡓࡅࠬࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠵ࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡨࡵࡶࡳࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡱ࡯࡮࡬ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫ࡭࡫ࡱ࡯ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠬ࡭࡫ࡱ࡯࠱࠷࠴࠵ࠫࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡲࡩ࡯࡭ࠪ࠰ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠲ࠧࠨ࠮࠼࠽࠾࠿ࠩࠋࠋࠥࠦࠧ樻")
	index = level+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ樼")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ樽")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭樾")+l1ll1ll11l111_l1_
	if level in [l11ll1_l1_ (u"ࠫ࠶࠭樿"),l11ll1_l1_ (u"ࠬ࠸ࠧ橀"),l11ll1_l1_ (u"࠭࠳ࠨ橁")]:
		dd,l1ll1ll1l1111_l1_,l1ll1l1ll11ll_l1_,l1ll1l1l1l1ll_l1_ = l1ll1ll1111l1_l1_(cc,url,index)
		if not l1ll1ll1l1111_l1_: return
		l1ll11l1l1_l1_ = len(l1ll1l1ll11ll_l1_)
		if l1ll11l1l1_l1_<2:
			if level==l11ll1_l1_ (u"ࠧ࠲ࠩ橂"): level = l11ll1_l1_ (u"ࠨ࠴ࠪ橃")
			l1ll1l1ll11ll_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ橄"),l11ll1_l1_ (u"ࠪࠫ橅"),index,l11ll1_l1_ (u"ࠫࡱ࡫ࡶࡦ࡮࠽ࠤ࠶ࡢ࡮ࠨ橆")+l11ll1_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ橇")+str(l1ll1l1l1l1ll_l1_)+l11ll1_l1_ (u"࠭࡜࡯ࠩ橈")+l11ll1_l1_ (u"ࠧ࡭ࡧࡱ࡫ࡹ࡮࠺ࠡࠩ橉")+str(len(dd))+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ橊")+l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴ࠻ࠢࠪ橋")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠪࡠࡳ࠭橌")+url)
	index = level+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ橍")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ橎")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ橏")+l1ll1ll11l111_l1_
	if level in [l11ll1_l1_ (u"ࠧ࠳ࠩ橐"),l11ll1_l1_ (u"ࠨ࠵ࠪ橑")]:
		ee,l1ll1ll11ll1l_l1_,l1ll1ll111l11_l1_,l1ll1ll111111_l1_ = l1ll1l1l1ll11_l1_(cc,dd,url,index)
		if not l1ll1ll11ll1l_l1_: return
		l1l1l11l11_l1_ = len(l1ll1ll111l11_l1_)
		if l1l1l11l11_l1_<2:
			if level==l11ll1_l1_ (u"ࠩ࠵ࠫ橒"): level = l11ll1_l1_ (u"ࠪ࠷ࠬ橓")
			l1ll1ll111l11_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ橔"),l11ll1_l1_ (u"ࠬ࠭橕"),index,l11ll1_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠲࡝ࡰࠪ橖")+l11ll1_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ橗")+str(l1ll1ll111111_l1_)+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ橘")+l11ll1_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ橙")+str(len(ee))+l11ll1_l1_ (u"ࠪࡠࡳ࠭橚")+l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ橛")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ橜")+url)
	index = level+l11ll1_l1_ (u"࠭࠺࠻ࠩ橝")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ橞")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ機")+l1ll1ll11l111_l1_
	if level in [l11ll1_l1_ (u"ࠩ࠶ࠫ橠")]:
		ff,l1ll1ll1l11l1_l1_,l1ll1l1lll111_l1_,l1ll1lll11111_l1_ = l1ll1l1ll1l1l_l1_(cc,ee,url,index)
		if not l1ll1ll1l11l1_l1_: return
		l1l1l11l1l_l1_ = len(l1ll1l1lll111_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ橡"),l11ll1_l1_ (u"ࠫࠬ橢"),index,l11ll1_l1_ (u"ࠬࡲࡥࡷࡧ࡯࠾ࠥ࠹࡜࡯ࠩ橣")+l11ll1_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥ࠻ࠢࠪ橤")+str(l1ll1lll11111_l1_)+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ橥")+l11ll1_l1_ (u"ࠨ࡮ࡨࡲ࡬ࡺࡨ࠻ࠢࠪ橦")+str(len(ff))+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ橧")+l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵ࠼ࠣࠫ橨")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠫࡡࡴࠧ橩")+url)
	for item,url,index in l1ll1l1ll11ll_l1_+l1ll1ll111l11_l1_+l1ll1l1lll111_l1_:
		l1l1l1l1lll1_l1_ = l1ll1ll1ll11l_l1_(item,url,index)
	return
def l1ll1ll1ll11l_l1_(item,url=l11ll1_l1_ (u"ࠬ࠭橪"),index=l11ll1_l1_ (u"࠭ࠧ橫")):
	if l11ll1_l1_ (u"ࠧ࠻࠼ࠪ橬") in index: level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = index.split(l11ll1_l1_ (u"ࠨ࠼࠽ࠫ橭"))
	else: level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ橮"),l11ll1_l1_ (u"ࠪ࠴ࠬ橯"),l11ll1_l1_ (u"ࠫ࠵࠭橰"),l11ll1_l1_ (u"ࠬ࠶ࠧ橱")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,l1ll1ll1lll11_l1_ = l1ll1lll111l1_l1_(item)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ橲"),url)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ橳"),l1lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ橴"),l1lllll_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥ࠭橵")+title)
	# needed for l1ll1ll11lll1_l1_ l1ll1lll111ll_l1_ next l1l1111_l1_
	# and needed for l1ll1ll11lll1_l1_ l1ll1lll111ll_l1_ sub-menu
	#if (l11ll1_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾࠷࠳ࠫ橶") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿࠷࠽ࠬ橷") in l1lllll_l1_) and (l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࡁࠪ橸") in l1lllll_l1_ or l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࡁࠪ橹") in l1lllll_l1_): l1lllll_l1_ = url
	l1ll1ll1l1ll_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࡀࠩ橺") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡶࡸࡷ࡫ࡡ࡮ࡵࡂࠫ橻") in l1lllll_l1_ or l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸࡅࠧ橼") in l1lllll_l1_
	l1ll1ll1l11l_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࡅࠧ橽") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࡄ࠭橾") in l1lllll_l1_
	if l1ll1ll1l1ll_l1_ or l1ll1ll1l11l_l1_: l1lllll_l1_ = url
	l1ll1ll1l1ll_l1_ = l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ橿") not in l1lllll_l1_ and l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ檀") not in l1lllll_l1_
	l1ll1ll1l11l_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡩࡤࡱ࡮ࡴࡧࠨ檁") not in l1lllll_l1_  and l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡴࡶࡲࡶࡪ࡬ࡲࡰࡰࡷࠫ檂") not in l1lllll_l1_
	if index[0:5]==l11ll1_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻ࠩ檃") and l1ll1ll1l1ll_l1_ and l1ll1ll1l11l_l1_: l1lllll_l1_ = url
	if l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭檄") in url or l11ll1_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ檅") in l1lllll_l1_:
		level,l1ll1l1lll1ll_l1_,index2,l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ檆"),l11ll1_l1_ (u"࠭࠰ࠨ檇"),l11ll1_l1_ (u"ࠧ࠱ࠩ檈"),l11ll1_l1_ (u"ࠨ࠲ࠪ檉")
		index = l11ll1_l1_ (u"ࠩࠪ檊")
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠪࠫ檋")
	if l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ檌") in l1lllll_l1_ or l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ檍") in l1lllll_l1_ or l11ll1_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ檎") in url:
		data = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ檏"))
		if data.count(l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ檐"))==4:
			l1ll1ll1l111l_l1_,key,l1ll1ll11l1ll_l1_,l1ll1l1llll1l_l1_,token = data.split(l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭檑"))
			l11ll11l1_l1_ = l1ll1ll1l111l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ檒")+key+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ檓")+l1ll1ll11l1ll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ檔")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ檕")+l1ll1ll1lll11_l1_
			if l11ll1_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ檖") in url and not l1lllll_l1_: l1lllll_l1_ = url
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁ࡮ࡩࡾࡃࠧ檗")+key
	if not title:
		global l1ll1l1ll1ll1_l1_
		l1ll1l1ll1ll1_l1_ += 1
		title = l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࠬ檘")+str(l1ll1l1ll1ll1_l1_)
		index = l11ll1_l1_ (u"ࠪ࠷ࠬ檙")+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ檚")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ檛")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ檜")+l1ll1ll11l111_l1_
	#if l11ll1_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭檝") in url: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ檞"),l11ll1_l1_ (u"ࠩࠪ檟"),title,index+l11ll1_l1_ (u"ࠪࡠࡳ࠭檠")+l1lllll_l1_)
	#if not l1lllll_l1_: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ檡"),l11ll1_l1_ (u"ࠬ࠭檢"),str(succeeded),title+l11ll1_l1_ (u"࠭ࠠ࠻࠼࠽ࠤࠬ檣")+l1lllll_l1_)
	#if l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭檤") in url and index==l11ll1_l1_ (u"ࠨ࠲ࠪ檥"):
	#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ檦"),l111l1_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ檧") in str(item): return False			# l1ll1ll1l1lll_l1_ not items
	elif l11ll1_l1_ (u"ࠫ࠴ࡧࡢࡰࡷࡷࠫ檨") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠬ࠵ࡣࡰ࡯ࡰࡹࡳ࡯ࡴࡺࠩ檩") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ檪") in list(item.keys()) or l11ll1_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭檫") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ檬")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ檭")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭檮")+l1ll1ll11l111_l1_
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ檯"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠡࠩ檰")+l11ll1_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ檱"),l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ檲") in l1lllll_l1_:
		title = l11ll1_l1_ (u"ࠨ࠼࠽ࠤࠬ檳")+title
		index = l11ll1_l1_ (u"ࠩ࠶ࠫ檴")+l11ll1_l1_ (u"ࠪ࠾࠿࠭檵")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ檶")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ檷")+l1ll1ll11l111_l1_
		url = url.replace(l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ檸"),l11ll1_l1_ (u"ࠧࠨ檹"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檺"),l111l1_l1_+title,url,145,l11ll1_l1_ (u"ࠩࠪ檻"),index,l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ檼"))
	elif l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ檽") in url and not l1lllll_l1_:
		index = l11ll1_l1_ (u"ࠬ࠹ࠧ檾")+l11ll1_l1_ (u"࠭࠺࠻ࠩ檿")+l1ll1l1lll1ll_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ櫀")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ櫁")+l1ll1ll11l111_l1_
		title = l11ll1_l1_ (u"ࠩ࠽࠾ࠥ࠭櫂")+title
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ櫃"),l111l1_l1_+title,url,144,l1lll1_l1_,index,l11ll11l1_l1_)
	#elif l11ll1_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ櫄") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪ࠭櫅") in l1lllll_l1_ and url==l11l1l_l1_:
		title = l11ll1_l1_ (u"࠭࠺࠻ࠢࠪ櫆")+title
		index = l11ll1_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ櫇")
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ櫈"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ櫉") in str(item):
		title = l11ll1_l1_ (u"ࠪ࠾࠿ࠦࠧ櫊")+title
		index = l11ll1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ櫋")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ櫌"),l111l1_l1_+title,url,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ櫍") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ櫎"),l111l1_l1_+title,l11ll1_l1_ (u"ࠨࠩ櫏"),9999)
	#elif l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ櫐") in l1lllll_l1_ and l11ll1_l1_ (u"ࠪࡦࡵࡃࠧ櫑") not in l1lllll_l1_:
	#	title = l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ櫒")+title
	#	index = l11ll1_l1_ (u"ࠬ࠸࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ櫓")
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭櫔"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l111lll11ll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ櫕"),l111l1_l1_+l111lll11ll_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ櫖") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ櫗"),l111l1_l1_+l11ll1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ櫘")+count+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ櫙")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	#elif l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ櫚") in l1lllll_l1_ and l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭櫛") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡵ࠿࠳ࠫ櫜") not in l1lllll_l1_:
	#	l1ll1ll111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠨ࠯ࠬࡂ࠭ࠩ࠭櫝"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ櫞")+l1ll1ll111lll_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ櫟"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡑࡏࡓࡕࠩ櫠")+count+l11ll1_l1_ (u"ࠬࡀࠠࠡࠩ櫡")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ櫢") in l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ櫣"),1)[0]
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ櫤"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ櫥") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ櫦") in l1lllll_l1_ and count:
			l1ll1ll111lll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ櫧"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ櫨")+l1ll1ll111lll_l1_
			index = l11ll1_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ櫩")
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ櫪"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡎࡌࡗ࡙࠭櫫")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭櫬")+title,l1lllll_l1_,144,l1lll1_l1_,index)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ櫭"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ櫮"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ櫯") in l1lllll_l1_ or l11ll1_l1_ (u"࠭࠯ࡤ࠱ࠪ櫰") in l1lllll_l1_ or (l11ll1_l1_ (u"ࠧ࠰ࡂࠪ櫱") in l1lllll_l1_ and l1lllll_l1_.count(l11ll1_l1_ (u"ࠨ࠱ࠪ櫲"))==3):
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ櫳"),l111l1_l1_+l11ll1_l1_ (u"ࠪࡇࡍࡔࡌࠨ櫴")+count+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ櫵")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ櫶") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭櫷"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡖࡕࡈࡖࠬ櫸")+count+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ櫹")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	else:
		if not l1lllll_l1_: l1lllll_l1_ = url
		title = l11ll1_l1_ (u"ࠩ࠽࠾ࠥ࠭櫺")+title
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ櫻"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	return True
def l1ll1lll111l1_l1_(item):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token = False,l11ll1_l1_ (u"ࠫࠬ櫼"),l11ll1_l1_ (u"ࠬ࠭櫽"),l11ll1_l1_ (u"࠭ࠧ櫾"),l11ll1_l1_ (u"ࠧࠨ櫿"),l11ll1_l1_ (u"ࠨࠩ欀"),l11ll1_l1_ (u"ࠩࠪ欁"),l11ll1_l1_ (u"ࠪࠫ欂"),l11ll1_l1_ (u"ࠫࠬ欃")
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭欄"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token
	for l1ll1ll1l1l1l_l1_ in list(item.keys()):
		render = item[l1ll1ll1l1l1l_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧ欅"),str(render))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ欆"),str(render))
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ欇"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡐ࡮ࡹࡴࡉࡧࡤࡨࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ欈"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥ࡮࡬ࡲࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ欉"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡻ࡮ࡱ࡮ࡤࡽࡦࡨ࡬ࡦࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ權"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡦࡰࡴࡰࡥࡹࡺࡥࡥࡖ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ欋"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ欌"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ欍"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ欎"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ欏"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ欐"))
	# required for l11ll111111l_l1_ l1ll1ll11111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ欑"))
	# l1ll1ll11lll1_l1_ l1ll1ll11l11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡷ࡫ࡥ࡭࡙ࡤࡸࡨ࡮ࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡻ࡯ࡤࡦࡱࡌࡨࠬࡣࠢ欒"))
	succeeded,title,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ欓"),l11ll1_l1_ (u"ࠧࠨ欔"),l11ll1_l1_ (u"ࠨࠩ欕"),str(l111l1ll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ欖"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠧ欗")+str(title))
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ欘"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ欙"))
	# l1ll1lll1111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡤࡴ࡮࡛ࡲ࡭ࠩࡠࠦ欚"))
	# header feed
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡣࡳ࡭࡚ࡸ࡬ࠨ࡟ࠥ欛"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ欜"))
	# required for l11ll111111l_l1_ l1ll1l1lll11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ欝"))
	# l1ll1ll11lll1_l1_ l1ll1ll11l11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ欞"))
	succeeded,l1lllll_l1_,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ欟"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ欠"))
	# l1ll1ll11lll1_l1_ l1ll1ll11l11l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡸࡥࡦ࡮࡚ࡥࡹࡩࡨࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ次"))
	succeeded,l1lll1_l1_,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ欢"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ欣")+l1lll1_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ欤"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ欥"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ欦"))
	succeeded,count,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ欧"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ欨"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ欩"))
	# l1ll1ll1l1l11_l1_ l1ll1ll11lll1_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࠭࡝࡜ࠩ࡬ࡧࡴࡴࡔࡺࡲࡨࠫࡢࠨ欪"))
	# l1ll1ll1l1l11_l1_ l1ll1ll11lll1_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡸࡾࡲࡥࠨ࡟ࠥ欫"))
	succeeded,l1l11lll1_l1_,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	#l1ll1l1ll111l_l1_ = []
	# l1ll1lll1111l_l1_
	#l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤ࡮࡬ࡧࡰ࡚ࡲࡢࡥ࡮࡭ࡳ࡭ࡐࡢࡴࡤࡱࡸ࠭࡝ࠣ欬"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	#l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡴࡳࡣࡦ࡯࡮ࡴࡧࡑࡣࡵࡥࡲࡹࠧ࡞ࠤ欭"))
	#succeeded,l1ll1l1ll1lll_l1_,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡷࡳࡰ࡫࡮ࠨ࡟ࠥ欮"))
	# l1ll1lll1111l_l1_
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡺ࡯࡬ࡧࡱࠫࡢࠨ欯"))
	succeeded,token,l111l1ll_l1_ = l1ll1l1l1llll_l1_(item,render,l1ll1l1ll111l_l1_)
	if l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ欰") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11ll_l1_ = l11ll1_l1_ (u"ࠨࠩ欱"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ欲")
	if l11ll1_l1_ (u"้ࠪออิาࠩ欳") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11ll_l1_ = l11ll1_l1_ (u"ࠫࠬ欴"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭欵")
	if l11ll1_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭欶") in list(render.keys()):
		l1ll1ll1ll1l1_l1_ = str(render[l11ll1_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ欷")])
		if l11ll1_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ欸") in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠩࠧ࠾ࠥࠦࠧ欹")
		if l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ欺") in l1ll1ll1ll1l1_l1_: l111lll11ll_l1_ = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ欻")
		if l11ll1_l1_ (u"ࠬࡈࡵࡺࠩ欼") in l1ll1ll1ll1l1_l1_ or l11ll1_l1_ (u"࠭ࡒࡦࡰࡷࠫ欽") in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭款")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶ่ࠩฬฬฺัࠨ欿")) in l1ll1ll1ll1l1_l1_: l111lll11ll_l1_ = l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ歀")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡸูࠫืวยࠩ歁")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ歂")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡺ࠭วิฬษะฬืࠧ歃")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ歄")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ歅")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭歆")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ歇") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠪࡃࠬ歈"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ歉") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ歊")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll111ll1_l1_: title = l1ll1ll111ll1_l1_+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"࠭ࠬࠨ歋"),l11ll1_l1_ (u"ࠧࠨ歌"))
	count = count.replace(l11ll1_l1_ (u"ࠨ࠮ࠪ歍"),l11ll1_l1_ (u"ࠩࠪ歎"))
	count = re.findall(l11ll1_l1_ (u"ࠪࡠࡩ࠱ࠧ歏"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠫࠬ歐")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_,token
def l1ll1ll111l1l_l1_(url,data=l11ll1_l1_ (u"ࠬ࠭歑"),request=l11ll1_l1_ (u"࠭ࠧ歒")):
	if request==l11ll1_l1_ (u"ࠧࠨ歓"): request = l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ歔")
	#if l11ll1_l1_ (u"ࠩࡢࡣࠬ歕") in l1ll1ll11llll_l1_: l1ll1ll11llll_l1_ = l11ll1_l1_ (u"ࠪࠫ歖")
	#if l11ll1_l1_ (u"ࠫࡸࡹ࠽ࠨ歗") in url: url = url.split(l11ll1_l1_ (u"ࠬࡹࡳ࠾ࠩ歘"))[0]
	l111lll1ll_l1_ = l11llllll_l1_()
	#l111lll1ll_l1_ = l11ll1_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠵࠵࠿࠮࠱࠰࠳࠲࠵ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻ࠦࡅࡥࡩ࠲࠵࠵࠿࠮࠱࠰࠴࠹࠶࠾࠮࠸࠲ࠪ歙")
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ歚"):l111lll1ll_l1_,l11ll1_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ歛"):l11ll1_l1_ (u"ࠩࡓࡖࡊࡌ࠽ࡩ࡮ࡀࡥࡷ࠭歜")}
	#l1l1ll11l_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ歝"))
	if data.count(l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ歞"))==4: l1ll1ll1l111l_l1_,key,l1ll1ll11l1ll_l1_,l1ll1l1llll1l_l1_,token = data.split(l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ歟"))
	else: l1ll1ll1l111l_l1_,key,l1ll1ll11l1ll_l1_,l1ll1l1llll1l_l1_,token = l11ll1_l1_ (u"࠭ࠧ歠"),l11ll1_l1_ (u"ࠧࠨ歡"),l11ll1_l1_ (u"ࠨࠩ止"),l11ll1_l1_ (u"ࠩࠪ正"),l11ll1_l1_ (u"ࠪࠫ此")
	l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠦࡨࡵ࡮ࡵࡧࡻࡸࠧ步"):{l11ll1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࠧ武"):{l11ll1_l1_ (u"ࠨࡨ࡭ࠤ歧"):l11ll1_l1_ (u"ࠢࡢࡴࠥ歨"),l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ歩"):l11ll1_l1_ (u"ࠤ࡚ࡉࡇࠨ歪"),l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ歫"):l1ll1ll11l1ll_l1_}}}
	if url==l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ歬") or l11ll1_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ歭") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡸࡥࡦ࡮࠲ࡶࡪ࡫࡬ࡠࡹࡤࡸࡨ࡮࡟ࡴࡧࡴࡹࡪࡴࡣࡦࠩ歮")+l11ll1_l1_ (u"ࠧࡀ࡭ࡨࡽࡂ࠭歯")+key
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࡓࡥࡷࡧ࡭ࡴࠩ歰")] = l1ll1ll1l111l_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ歱"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ歲"))
	elif l11ll1_l1_ (u"ࠫ࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ歳") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ歴")+key
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ歵"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ歶"))
	elif l11ll1_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭歷") in url and l1ll1ll1l111l_l1_:
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ歸")] = token
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ歹")][l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࠫ歺")][l11ll1_l1_ (u"ࠬࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠪ死")] = l1ll1ll1l111l_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ歼"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ歽"))
	elif l11ll1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ歾") in url and l1ll1l1llll1l_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ歿"):l11ll1_l1_ (u"ࠪ࠵ࠬ殀"),l11ll1_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ殁"):l1ll1ll11l1ll_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ殂"):l11ll1_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࡁࠬ殃")+l1ll1l1llll1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ殄"),url,l11ll1_l1_ (u"ࠨࠩ殅"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ殆"),l11ll1_l1_ (u"ࠪࠫ殇"),l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠻ࡴࡩࠩ殈"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ殉"),url,l11ll1_l1_ (u"࠭ࠧ殊"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ残"),l11ll1_l1_ (u"ࠨࠩ殌"),l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠺ࡹ࡮ࠧ殍"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ殎"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡶࡦࡴࠥ࠲࠯ࡅࠢࡷࡣ࡯ࡹࡪࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ殏"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll11l1ll_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ殐"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll1l111l_l1_ = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ殑"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ殒"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠣ࠼ࡾࠦࡹࡵ࡫ࡦࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ殓"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ殔"),l11ll1_l1_ (u"ࠪࠫ殕"),l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ殖"),str(len(tmp)))
	#if tmp: l1ll1lll1111l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ殗") in list(cookies.keys()): l1ll1l1llll1l_l1_ = cookies[l11ll1_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ殘")]
	l11ll11ll_l1_ = l1ll1ll1l111l_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ殙")+key+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ殚")+l1ll1ll11l1ll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭殛")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ殜")+token
	if request==l11ll1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ殝") and l11ll1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ殞") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ殟"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ殠"),html,re.DOTALL)
		l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ殡"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ殢") and l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ殣") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ殤"),html,re.DOTALL)
		l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ殥"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ殦") not in html: l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ殧"),html)
	else: l1ll1l1ll11l1_l1_ = l11ll1_l1_ (u"ࠨࠩ殨")
	if 0:
		cc = str(l1ll1l1ll11l1_l1_)
		if kodi_version>18.99: cc = cc.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ殩"))
		open(l11ll1_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰ࡧࡥࡹ࠭殪"),l11ll1_l1_ (u"ࠫࡼࡨࠧ殫")).write(cc)
		#open(l11ll1_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ殬"),l11ll1_l1_ (u"࠭ࡷࠨ殭")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ殮"),l11ll11ll_l1_)
	return html,l1ll1l1ll11l1_l1_,l11ll11ll_l1_
def l1ll1ll1llll1_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ殯"),l11ll1_l1_ (u"ࠩ࠮ࠫ殰"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡻࡥࡳࡻࡀࠫ殱")+search
	l11111_l1_(l111lll_l1_,index)
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ殲")+l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࠪ殳")+l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ殴")+l11ll1_l1_ (u"ࠧࡠࠩ段")+search
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ殶"),l11ll1_l1_ (u"ࠩࠪ殷"),l11ll1_l1_ (u"ࠪࠫ殸"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ殹"),l11ll1_l1_ (u"ࠬ࠭殺"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ殻"),l11ll1_l1_ (u"ࠧࠬࠩ殼"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࠪ殽")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ殾") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡗࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ殿")
		elif l11ll1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪ毀") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ毁")
		elif l11ll1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ毂") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡪࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ毃")
		else: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠨࠩ毄")
		l11l111_l1_ = l111lll_l1_+l1ll1l1llllll_l1_
	else:
		l1ll1l1lllll1_l1_,l1ll1l1l1lll1_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠩࠪ毅")
		l1ll1l1ll1111_l1_ = [l11ll1_l1_ (u"ࠪฬิ๎ๆࠡฬิฮ๏ฮࠧ毆"),l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮࠠๆั์ࠤฬ๊ีๅหࠪ毇"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡฬสี๏ิࠠศๆอั๊๐ไࠨ毈"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษࠢ฼ำิࠦวๅ็ืห์ีวหࠩ毉"),l11ll1_l1_ (u"ࠧหำอ๎อࠦอิสࠣห้ะโ๋์่ࠫ毊")]
		l1ll1ll1l1ll1_l1_ = [l11ll1_l1_ (u"ࠨࠩ毋"),l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡃࠨ࠶࠺࠹ࡄࠨ毌"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡌࠩ࠷࠻࠳ࡅࠩ母"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡑࠪ࠸࠵࠴ࡆࠪ毎"),l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡊࠫ࠲࠶࠵ࡇࠫ每")]
		l1ll1ll1ll1ll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊สาฬํฬࠬ毐"),l1ll1l1ll1111_l1_)
		if l1ll1ll1ll1ll_l1_ == -1: return
		l1ll1l1llll11_l1_ = l1ll1ll1l1ll1_l1_[l1ll1ll1ll1ll_l1_]
		html,c,data = l1ll1ll111l1l_l1_(l111lll_l1_+l1ll1l1llll11_l1_)
		if c:
			try:
				d = c[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ毑")][l11ll1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ毒")][l11ll1_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ毓")][l11ll1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ比")][l11ll1_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ毕")][l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭毖")][l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࡸ࠭毗")]
				for l1ll1l1l1ll1l_l1_ in range(len(d)):
					group = d[l1ll1l1l1ll1l_l1_][l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡍࡲࡰࡷࡳࡖࡪࡴࡤࡦࡴࡨࡶࠬ毘")][l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ毙")]
					for l1ll1ll1lllll_l1_ in range(len(group)):
						render = group[l1ll1ll1lllll_l1_][l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩ毚")]
						if l11ll1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ毛") in list(render.keys()):
							l1lllll_l1_ = render[l11ll1_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ毜")][l11ll1_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ毝")][l11ll1_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ毞")][l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ毟")]
							l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡸ࠴࠵࠸࠶ࠨ毠"),l11ll1_l1_ (u"ࠩࠩࠫ毡"))
							title = render[l11ll1_l1_ (u"ࠪࡸࡴࡵ࡬ࡵ࡫ࡳࠫ毢")]
							title = title.replace(l11ll1_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦࠧ毣"),l11ll1_l1_ (u"ࠬ࠭毤"))
							if l11ll1_l1_ (u"࠭ลำษ็อࠥอไโๆอีࠬ毥") in title: continue
							if l11ll1_l1_ (u"ࠧใษษ้ฮࠦสี฼ํ่ࠬ毦") in title:
								title = l11ll1_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ毧")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠬ毨") in title: continue
							title = title.replace(l11ll1_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠠࠨ毩"),l11ll1_l1_ (u"ࠫࠬ毪"))
							if l11ll1_l1_ (u"ࠬࡘࡥ࡮ࡱࡹࡩࠬ毫") in title: continue
							if l11ll1_l1_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ毬") in title:
								title = l11ll1_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ毭")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠨࡕࡲࡶࡹࠦࡢࡺࠩ毮") in title: continue
							l1ll1l1lllll1_l1_.append(escapeUNICODE(title))
							l1ll1l1l1lll1_l1_.append(l1lllll_l1_)
			except: pass
		if not l1lll1l1l_l1_: l1ll1ll1l11ll_l1_ = l11ll1_l1_ (u"ࠩࠪ毯")
		else:
			l1ll1l1lllll1_l1_ = [l11ll1_l1_ (u"ࠪฬิ๎ๆࠡใ็ฮึ࠭毰"),l1lll1l1l_l1_]+l1ll1l1lllll1_l1_
			l1ll1l1l1lll1_l1_ = [l11ll1_l1_ (u"ࠫࠬ毱"),l1lllll11l_l1_]+l1ll1l1l1lll1_l1_
			l1ll1ll1lll1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้็ไหำࠪ毲"),l1ll1l1lllll1_l1_)
			if l1ll1ll1lll1l_l1_ == -1: return
			l1ll1ll1l11ll_l1_ = l1ll1l1l1lll1_l1_[l1ll1ll1lll1l_l1_]
		if l1ll1ll1l11ll_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1ll1l11ll_l1_
		elif l1ll1l1llll11_l1_: l11l111_l1_ = l111lll_l1_+l1ll1l1llll11_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡫࡯࡬ࡵࡧࡵ࠱ࡩࡸ࡯ࡱࡦࡲࡻࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡹ࡫࡭࠮ࡵࡨࡧࡹ࡯࡯࡯ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡪࡨࠣࠫࡗ࡫࡭ࡰࡸࡨࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷ࠭ࠬࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡳࡷࡺࠠࡣࡻࠪ࠰࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠬࠎࠎࠏࠉࠊ࡫ࡩࠤࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹࡥࡢࡴࡦ࡬࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠉࠊ࡫ࡩࠤ࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡳࡷࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠣࠤࠥ毳")
	#DIALOG_OK()
	l11111_l1_(l11l111_l1_)
	return
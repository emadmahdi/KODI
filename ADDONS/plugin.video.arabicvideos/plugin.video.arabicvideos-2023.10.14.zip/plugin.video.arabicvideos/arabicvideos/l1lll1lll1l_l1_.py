# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ⌕")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡈࡋࡉࡥࠧ⌖")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ู่ࠩฬืูสࠩ⌗"),l11ll1_l1_ (u"ࠪหาีหࠡษ็ฬึอๅอࠩ⌘"),l11ll1_l1_ (u"ࠫฬำฯฬࠢส่ฬู๊ศสࠪ⌙"),l11ll1_l1_ (u"ࠬอไาศํื๏ฯࠧ⌚"),l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬ⌛")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l11111_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l1llll1l_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⌜"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ⌝"),l11ll1_l1_ (u"ࠩࠪ⌞"),l11ll1_l1_ (u"ࠪࠫ⌟"),l11ll1_l1_ (u"ࠫࠬ⌠"),l11ll1_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⌡"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ⌢"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌣"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⌤"),l11ll1_l1_ (u"ࠩࠪ⌥"),449,l11ll1_l1_ (u"ࠪࠫ⌦"),l11ll1_l1_ (u"ࠫࠬ⌧"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⌨"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭〈"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ〉")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⌫"),l11l1l_l1_,441)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⌬"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⌭"),l11ll1_l1_ (u"ࠫࠬ⌮"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡣࡲ࡫࡮ࡶࡡࡵ࡭࡬࡮ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⌯"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⌰"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ⌱"): continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌲"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⌳")+l111l1_l1_+title,l1lllll_l1_,441)
	return
def l11111_l1_(url,l111l1ll_l1_=l11ll1_l1_ (u"ࠪࠫ⌴")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ⌵"),url,l11ll1_l1_ (u"ࠬ࠭⌶"),l11ll1_l1_ (u"࠭ࠧ⌷"),l11ll1_l1_ (u"ࠧࠨ⌸"),l11ll1_l1_ (u"ࠨࠩ⌹"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⌺"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⌻"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⌼"),block,re.DOTALL)
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		if l11ll1_l1_ (u"ࠬ࠵ࡵࡳ࡮࠲ࠫ⌽") in l1lllll_l1_: continue
		elif l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ⌾") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌿"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ⍀") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍁"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⍂"),l111l1_l1_+title,l1lllll_l1_,442,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⍃"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⍄"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⍅"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭⍆")+title,l1lllll_l1_,441)
	return
l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡷ࡫ࡧࡩࡴࡒࡉࡔࡖࠣࡁࠥࡡࠧๆึส๋ิฯࠧ࠭ࠩไ๎้๋ࠧ࠭ࠩส฾๋๐ษࠨ࠮ࠪ็้๐ศࠨ࠮ࠪห฾๊ว็ࠩ࠯ࠫ์ีวโࠩ࠯๊ࠫฮวาษฬࠫ࠱ู࠭าุࠪ࠰๋ࠬ็าฮส๊ࠬ࠲ࠧศๆห์๊࠭࡝ࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧ࠯࡭ࡲ࡭ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡵ࡯ࡧࡶࡧࡦࡶࡥࡉࡖࡐࡐ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡰ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧ࠰ࠩࠬࠎࠎࠏࡥࡱ࡫ࡶࡳࡩ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥࡧ࡮ࡺࠪࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࠣࡪࡴࡸࠠࡷࡣ࡯ࡹࡪࠦࡩ࡯ࠢࡹ࡭ࡩ࡫࡯ࡍࡋࡖࡘ࠮ࡀࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠷࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࡪࡶࡩࡴࡱࡧࡩࠥࡧ࡮ࡥࠢࠪห้ำไใหࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡥࡍࡐࡆࡢࠫࠥ࠱ࠠࡦࡲ࡬ࡷࡴࡪࡥ࡜࠲ࡠࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࠢࡱࡳࡹࠦࡩ࡯ࠢࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠿ࠐࠉࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠊࠋࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡢࡵࡶࡩࡲࡨ࡬ࡺ࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠷ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠷࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠳࠭࡫ࡰ࡫࠮ࠐࠉࡪࡨࠣࡷࡪࡷࡵࡦࡰࡦࡩࡂࡃࠧࠨ࠼ࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ⍇")
def l1llll1l_l1_(url):
	data = {l11ll1_l1_ (u"࡙ࠩ࡭ࡪࡽࠧ⍈"):1}
	headers = {l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⍉"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⍊")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ⍋"),url,data,headers,l11ll1_l1_ (u"࠭ࠧ⍌"),l11ll1_l1_ (u"ࠧࠨ⍍"),l11ll1_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⍎"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧ⍏"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ⍐"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⍑"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⍒"),l111l1_l1_+title,l1lllll_l1_,443,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡰࡩ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⍓"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⍔"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ⍕"),l11ll1_l1_ (u"ࠩࠪ⍖")).strip(l11ll1_l1_ (u"ࠪࠤࠬ⍗"))
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⍘"),l111l1_l1_+title,l1lllll_l1_,442,l1lll1_l1_)
	return
def PLAY(url):
	data = {l11ll1_l1_ (u"ࠬ࡜ࡩࡦࡹࠪ⍙"):1}
	headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⍚"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⍛")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭⍜"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ⍝"),l11ll1_l1_ (u"ࠪࠫ⍞"),l11ll1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⍟"))
	html = response.content
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⍠"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ⍡"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ⍢"),l11ll1_l1_ (u"ࠨࠩ⍣")).strip(l11ll1_l1_ (u"ࠩࠣࠫ⍤"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⍥")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⍦")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⍧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⍨"),block,re.DOTALL)
		for title,l111llll_l1_,l1lllll_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ⍩"),l11ll1_l1_ (u"ࠨࠩ⍪"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⍫")+title+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⍬")+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ⍭")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⍮"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⍯"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⍰"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⍱"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⍲"),l11ll1_l1_ (u"ࠪ࠯ࠬ⍳"))
	#search = unescapeHTML(search)
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⍴")+search
	l11111_l1_(url)
	return
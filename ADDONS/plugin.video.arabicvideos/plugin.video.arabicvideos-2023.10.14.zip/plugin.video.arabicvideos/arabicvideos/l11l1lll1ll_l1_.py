# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ摾")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ摿")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l11l_l1_ = l1l1lll_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11111_l1_(url)
	elif mode==52: results = l1llll1l_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1ll1llll1ll1_l1_()
	elif mode==56: results = l1ll1llll11l1_l1_()
	elif mode==57: results = l1ll1llll11ll_l1_(url,1)
	elif mode==58: results = l1ll1llll11ll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撀"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ撁"),l11ll1_l1_ (u"ࠬ࠭撂"),59,l11ll1_l1_ (u"࠭ࠧ撃"),l11ll1_l1_ (u"ࠧࠨ撄"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ撅"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ撆"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ撇"),l11ll1_l1_ (u"ࠫࠬ撈"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撉"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ撊")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ撋"),l11ll1_l1_ (u"ࠨࠩ撌"),56)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撍"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ撎")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊วโๆส้ࠬ撏"),l11ll1_l1_ (u"ࠬ࠭撐"),55)
	return l11ll1_l1_ (u"࠭ࠧ撑")
def l1ll1llll1ll1_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ撒"),l111l1_l1_+l11ll1_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ撓"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ撔"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撕"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ撖"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ撗"),51)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭撘"),l111l1_l1_+l11ll1_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ撙"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ撚"),51)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撛"),l111l1_l1_+l11ll1_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ撜"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ撝"),51)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ撞"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭撟"),l11ll1_l1_ (u"ࠧࠨ撠"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撡"),l111l1_l1_+l11ll1_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭撢"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ撣"),57)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ撤"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ撥"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ撦"),57)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ撧"),l111l1_l1_+l11ll1_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ撨"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ撩"),57)
	return
def l1ll1llll11l1_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撪"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ撫"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ撬"),51)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭播"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ撮"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ撯"),51)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撰"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ撱"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ撲"),51)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撳"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ撴"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ撵"),51)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭撶"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ撷"),l11ll1_l1_ (u"ࠪࠫ撸"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ撹"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ撺"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭撻"),57)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ撼"),l111l1_l1_+l11ll1_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ撽"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ撾"),57)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撿"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ擀"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ擁"),57)
	return
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ擂"),l11ll1_l1_ (u"ࠧࠨ擃"),url,url)
	if l11ll1_l1_ (u"ࠨࡁࠪ擄") in url:
		parts = url.split(l11ll1_l1_ (u"ࠩࡂࠫ擅"))
		url = parts[0]
		filter = l11ll1_l1_ (u"ࠪࡃࠬ擆") + QUOTE(parts[1],l11ll1_l1_ (u"ࠫࡂࠬ࠺࠰ࠧࠪ擇"))
	else: filter = l11ll1_l1_ (u"ࠬ࠭擈")
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ擉"),l11ll1_l1_ (u"ࠧࠨ擊"),filter,l11ll1_l1_ (u"ࠨࠩ擋"))
	parts = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ擌"))
	sort,l1l1111_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11ll1_l1_ (u"ࠪࡽࡴࡶࠧ操"),l11ll1_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ擎"),l11ll1_l1_ (u"ࠬࡼࡩࡦࡹࡶࠫ擏")]:
		if type==l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ擐"): l11lll111_l1_=l11ll1_l1_ (u"ࠧโ์็้ࠬ擑")
		elif type==l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ擒"): l11lll111_l1_=l11ll1_l1_ (u"่ࠩืู้ไࠨ擓")
		#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ擔") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠫ࠴࠭擕") + l1l1111_l1_ + l11ll1_l1_ (u"ࠬ࠵ࠧ擖") + sort + filter
		url = l11l1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ擗") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠧ࠰ࠩ擘") + l1l1111_l1_ + l11ll1_l1_ (u"ࠨ࠱ࠪ擙") + sort + filter
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ據"),l11ll1_l1_ (u"ࠪࠫ擛"),l11ll1_l1_ (u"ࠫࠬ擜"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠬ࠭擝"),l11ll1_l1_ (u"࠭ࠧ擞"),l11ll1_l1_ (u"ࠧࠨ擟"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ擠"))
		#items = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿ࠣࡰࡸࡱࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡴࡨࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ擡"),html,re.DOTALL)
		items = re.findall(l11ll1_l1_ (u"ࠪࠦࡵ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡶࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡴࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡱࡴࡨࡷࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ擢"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,title,l1ll1lll1lll1_l1_,l1lll1_l1_ in items:
			l1l1l1llll1_l1_ += 1
			#l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠫ࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ擣") + l1lll1_l1_ + l11ll1_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ擤")
			l1lll1_l1_ = l1l1ll1l11l_l1_ + l11ll1_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ擥") + l1lll1_l1_ + l11ll1_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ擦")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ擧") + id
			if type==l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ擨"): addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ擩"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			if type==l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ擪"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ擫"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ࠥ࠭擬")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡧࡳࡁࠬ擭")+l1ll1lll1lll1_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ擮")+title+l11ll1_l1_ (u"ࠩࡀࠫ擯")+l1lll1_l1_,52,l1lll1_l1_)
	else:
		if type==l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ擰"): l11lll111_l1_=l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ擱")
		elif type==l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ擲"): l11lll111_l1_=l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭擳")
		url = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ擴") + sort + l11ll1_l1_ (u"ࠨ࠯ࠪ擵") + l11lll111_l1_ + l11ll1_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ擶")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ擷"),l11ll1_l1_ (u"ࠫࠬ擸"),l11ll1_l1_ (u"ࠬ࠭擹"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ擺"))
		items = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ擻"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,l1ll1lll1lll1_l1_,l1lll1_l1_,title in items:
			l1l1l1llll1_l1_ += 1
			l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ擼") + l1lll1_l1_ + l11ll1_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ擽")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭擾") + id
			if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ擿"): addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ攀"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			elif type==l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭攁"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ攂"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊ࠠࠨ攃")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡩࡵࡃࠧ攄")+l1ll1lll1lll1_l1_+l11ll1_l1_ (u"ࠪࡁࠬ攅")+title+l11ll1_l1_ (u"ࠫࡂ࠭攆")+l1lll1_l1_,52,l1lll1_l1_)
	title=l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ攇")
	if l1l1l1llll1_l1_==16:
		for l1l1ll1l1l1_l1_ in range(1,13) :
			if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
				#url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠭ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪ攈")+type+l11ll1_l1_ (u"ࠧ࠰ࠩ攉")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠨ࠱ࠪ攊")+sort + filter
				url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ攋")+type+l11ll1_l1_ (u"ࠪ࠳ࠬ攌")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠫ࠴࠭攍")+sort + filter
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ攎"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,51)
	return
def l1llll1l_l1_(url):
	parts = url.split(l11ll1_l1_ (u"࠭࠽ࠨ攏"))
	l1ll1lll1lll1_l1_ = int(parts[1])
	name = l1111_l1_(parts[2])
	name = name.replace(l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ攐"),l11ll1_l1_ (u"ࠨࠩ攑"))
	l1lll1_l1_ = parts[3]
	url = url.split(l11ll1_l1_ (u"ࠩࡂࠫ攒"))[0]
	if l1ll1lll1lll1_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ攓"),l11ll1_l1_ (u"ࠫࠬ攔"),l11ll1_l1_ (u"ࠬ࠭攕"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ攖"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨ攗"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ攘"),block,re.DOTALL)
		l1ll1lll1lll1_l1_ = int(items[-1])
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ攙"),l11ll1_l1_ (u"ࠪࠫ攚"),l1ll1lll1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ攛"))
	#name = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕ࡫ࡷࡰࡪࠨ攜") )
	#l1lll1_l1_ = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠢ攝") )
	for l1ll1l1_l1_ in range(l1ll1lll1lll1_l1_,0,-1):
		l1lllll_l1_ = url + l11ll1_l1_ (u"ࠧࡀࡧࡳࡁࠬ攞") + str(l1ll1l1_l1_)
		title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭攟")+name+l11ll1_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭攠")+str(l1ll1l1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ攡"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬ攢"),l11ll1_l1_ (u"ࠬ࠭攣"),l11ll1_l1_ (u"࠭ࠧ攤"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ攥"))
	l1ll1llll111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ攦"),html,re.DOTALL)
	if l1ll1llll111l_l1_:
		time = l1ll1llll111l_l1_[1].replace(l11ll1_l1_ (u"ࠩࡗࠫ攧"),l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠨ攨"))
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ攩"),l11ll1_l1_ (u"ࠬ࠭攪"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ攫"),l11ll1_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ攬")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ攭")+time)
		return
	#if l11ll1_l1_ (u"้ࠩ฽ฯึัࠡ฻็ํࠥ๎โ้฻ࠣา฼ษࠧ攮") in html:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ支"),l11ll1_l1_ (u"ࠫࠬ攰"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ攱"),l11ll1_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ攲"))
	#	return
	l1ll1lll1ll11_l1_,l1ll1llll1l11_l1_ = [],[]
	l1ll1llll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡷࡣࡵࠤࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ攳"),html,re.DOTALL)[0]
	l1ll1llll1111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡶࠥࡨࡡࡤ࡭ࡸࡴࡤࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭攴"),html,re.DOTALL)[0]
	# l1llll111_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡰࡸࡀࠠࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭攵"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		if l11ll1_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ收") in server:
			server = l11ll1_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ攷")
			url = l1ll1llll1111_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ攸")
			url = l1ll1llll1l1l_l1_ + l1lllll_l1_
		if l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ改") in url:
			l1ll1lll1ll11_l1_.append(url)
			l1ll1llll1l11_l1_.append(l11ll1_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥࠦࠧ攺")+server)
		l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡ࠰࡞࠿ࡀࠫ࠲࠷ࠧ࠻ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠯ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡰ࠷ࡺ࠾ࠠࠡࠩ࠮ࡷࡪࡸࡶࡦࡴࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡱ࡫࡮ࠩࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭࠮ࡀࠊࠊࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡺࡸ࡬࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞࡭ࡢ࠯ࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࠪ࠭ࡠ࠶࡝ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࡭ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࡧ࡫࡯ࡩࡹࡿࡰࡦ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠠࠡࠩ࠯ࠫࠥࠦࠧࠪࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥ࡮ࡢ࡯ࡨ࠲ࡦࡶࡰࡦࡰࡧࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠱ࠧࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠯ࠬࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠧࠨࠢ攻")
	# l1111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ攼"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11ll1_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ攽"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		filename = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭放"))[-1]
		filename = filename.replace(l11ll1_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ政"),l11ll1_l1_ (u"࠭ࠧ敀"))
		filename = filename.replace(l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ敁"),l11ll1_l1_ (u"ࠨࠩ敂"))
		filename = filename.replace(l11ll1_l1_ (u"ࠩ࠰ࠫ敃"),l11ll1_l1_ (u"ࠪࠫ敄"))
		if l11ll1_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ故") in server:
			server = l11ll1_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ敆")
			url = l1ll1llll1111_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ敇")
			url = l1ll1llll1l1l_l1_ + l1lllll_l1_
		l1ll1lll1ll11_l1_.append(url)
		l1ll1llll1l11_l1_.append(l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭效")+server+l11ll1_l1_ (u"ࠨࠢࠣࠫ敉")+filename)
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ敊"), l1ll1llll1l11_l1_)
	if l1l_l1_ == -1 : return
	url = l1ll1lll1ll11_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ敋"))
	return
def l1ll1llll11ll_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ敌"),l11ll1_l1_ (u"ࠬ࠭敍"),url,url)
	if l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭敎") in url: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ๆี็ื้࠭敏")
	else: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ใํ่๊࠭敐")
	l111lll_l1_ = QUOTE(l111lll_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ救"),l11ll1_l1_ (u"ࠪࠫ敒"),l11ll1_l1_ (u"ࠫࠬ敓"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡇࡋࡏࡘࡊࡘࡓ࠮࠳ࡶࡸࠬ敔"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ敕"),l11ll1_l1_ (u"ࠧࠨ敖"),url,html)
	if type==1: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ敗"),html,re.DOTALL)
	elif type==2: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ敘"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ教"),block,re.DOTALL)
	if type==1:
		for l1ll1lll1ll1l_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ敚"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ敛")+l1ll1lll1ll1l_l1_,58)
	elif type==2:
		url,l1ll1lll1ll1l_l1_ = url.split(l11ll1_l1_ (u"࠭࠿ࠨ敜"))
		for l1ll1l1111ll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ敝"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ敞")+l1ll1l1111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ敟")+l1ll1lll1ll1l_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ敠"),l11ll1_l1_ (u"ࠫࠬ敡"),search,search)
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ敢"),l11ll1_l1_ (u"࠭ࠥ࠳࠲ࠪ散"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ敤"), l11l1l_l1_, l11ll1_l1_ (u"ࠨࠩ敥"), l11ll1_l1_ (u"ࠩࠪ敦"), True,l11ll1_l1_ (u"ࠪࠫ敧"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ敨"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l1l111_l1_ = cookies[l11ll1_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳ࠭敩")]
	#l1ll1lll1llll_l1_ = re.findall(l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡣࡴࡴࡩࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭敪"),html,re.DOTALL)
	#l1ll1lll1llll_l1_ = l1ll1lll1llll_l1_[0]
	#payload = l11ll1_l1_ (u"ࠧࡠࡥࡶࡶ࡫ࡃࠧ敫") + l1ll1lll1llll_l1_ + l11ll1_l1_ (u"ࠨࠨࡴࡁࠬ敬") + QUOTE(l1111ll_l1_)
	#headers = { l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ敭"):l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ敮") , l11ll1_l1_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ敯"):l11ll1_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ数")+l11l1l111_l1_ }
	#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠯ࡴࡧࡤࡶࡨ࡮ࠢ敱")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ敲"), url, payload, headers, True,l11ll1_l1_ (u"ࠨࠩ敳"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ整"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ敵")+l1111ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ敶"),url,l11ll1_l1_ (u"ࠬ࠭敷"),l11ll1_l1_ (u"࠭ࠧ數"),True,l11ll1_l1_ (u"ࠧࠨ敹"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧ敺"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡪࡩࡳ࡫ࡲࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡹࡥࡢࡴࡦ࡬࠲ࡨ࡯ࡵࡶࡲࡱ࠲ࡶࡡࡥࡦ࡬ࡲ࡬࠭敻"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ敼"),block,re.DOTALL)
	if items:
		for l1lllll_l1_,l1lll1_l1_,title in items:
			#title = title.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ敽")).encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ敾"))
			url = l11l1l_l1_ + l1lllll_l1_
			if l11ll1_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ敿") in url:
				if l11ll1_l1_ (u"ࠧࡀࡧࡳࡁࠬ斀") in url:
					title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭斁")+title
					url = url.replace(l11ll1_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ斂"),l11ll1_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ斃"))
					url = url+l11ll1_l1_ (u"ࠫࡂ࠭斄")+QUOTE(title)+l11ll1_l1_ (u"ࠬࡃࠧ斅")+l1lll1_l1_
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭斆"),l111l1_l1_+title,url,52,l1lll1_l1_)
				else:
					title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ文")+title
					addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ斈"),l111l1_l1_+title,url,53,l1lll1_l1_)
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ斉"),l11ll1_l1_ (u"ࠪࠫ斊"),l11ll1_l1_ (u"ࠫࡳࡵࠠࡳࡧࡶࡹࡱࡺࡳࠨ斋"),l11ll1_l1_ (u"๊ࠬวࠡฬ๋ะิࠦๆหษษะ๊ࠥไษฯฮࠫ斌"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11lll1l1ll_l1_ import *
script_name = l11ll1_l1_ (u"ࠩࡌࡒࡎ࡚ࠧ煵")
LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ煶"),l11ll1_l1_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠩ煷"))
l1ll1111l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
l1l1lllll1ll_l1_ = int(mode)
l1ll1l1l1lll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭煸"))
l1ll1l1l1lll_l1_ = l1ll1l1l1lll_l1_.replace(ltr,l11ll1_l1_ (u"࠭ࠧ煹")).replace(rtl,l11ll1_l1_ (u"ࠧࠨ煺"))
if l1l1lllll1ll_l1_==260: message = l11ll1_l1_ (u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩ煻")+l11llll11l1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩ煼")+l1l111l1l1l_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭煽")
else:
	l1ll1l11l1ll1_l1_ = l1111_l1_(addon_path).replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ煾"),l11ll1_l1_ (u"ࠬ࠭煿")).replace(l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ熀"),l11ll1_l1_ (u"ࠧࠨ熁"))
	l1ll1l11l1ll1_l1_ = l1ll1l11l1ll1_l1_.replace(l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ熂"),l11ll1_l1_ (u"ࠩࠪ熃")).strip(l11ll1_l1_ (u"ࠪࠤࠬ熄"))
	l1ll1l11l1ll1_l1_ = l1ll1l11l1ll1_l1_.replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ熅"),l11ll1_l1_ (u"ࠬࠦࠧ熆")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ熇"),l11ll1_l1_ (u"ࠧࠡࠩ熈")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ熉"),l11ll1_l1_ (u"ࠩࠣࠫ熊"))
	message = l11ll1_l1_ (u"ࠪࠤࠥࠦࡌࡢࡤࡨࡰ࠿࡛ࠦࠡࠩ熋")+l1ll1l1l1lll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡳࡩ࡫࠺ࠡ࡝ࠣࠫ熌")+mode+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ熍")+l1ll1l11l1ll1_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ熎")
LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ熏"),LOGGING(script_name)+message)
l1l1lll11l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ熐"))
l1111111111_l1_ = True if l1l1lll11l1l_l1_==l11llll11l1_l1_ else False
if not l1111111111_l1_ and l1l1lllll1ll_l1_ in [235,715]:
	l1lll111l1l1_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ熑")])
	script_name = l11ll1_l1_ (u"ࠪ࡭ࡵࡺࡶࠨ熒") if l1l1lllll1ll_l1_==235 else l11ll1_l1_ (u"ࠫࡲ࠹ࡵࠨ熓")
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࠩ熔")+script_name+l11ll1_l1_ (u"࠭࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ熕")+l1lll111l1l1_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࠫ熖")+script_name+l11ll1_l1_ (u"ࠨ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫ熗")+l1lll111l1l1_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠩࡿࠫ熘")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ熙")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧ熚")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"ࠬࢂࠦࠨ熛"),l11ll1_l1_ (u"࠭ࡼࠨ熜"))
	l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࠫ熝")+script_name+l11ll1_l1_ (u"ࠨ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ熞")+l1lll111l1l1_l1_)
	if l1111l1l11_l1_:
		l1l111111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬ熟"),url,re.DOTALL)
		url = url.replace(l1l111111l11_l1_[0],l1111l1l11_l1_)
	script_name = script_name.upper()
	l1l11l11l11_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lllll1llll_l1_ = l11ll1_l1_ (u"ࠪࠫ熠")
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ熡"))
	try: l1lll1lllll1_l1_(l1ll1111l1l_l1_,l1ll1l1l1lll_l1_)
	except Exception as error: l1lllll1llll_l1_ = traceback.format_exc()
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠬࡹࡴࡰࡲࠪ熢"))
	l1ll1111llll_l1_(l1lllll1llll_l1_)
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫぽ")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩま")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭み"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭む"),l11ll1_l1_ (u"࠭วๅลๅืฬ๋ࠧめ")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l11111_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l1llll1_l1_(url,text)
	elif mode==674: results = l1l111_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫも"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩゃ"),l11ll1_l1_ (u"ࠩࠪや"),l11ll1_l1_ (u"ࠪࠫゅ"),l11ll1_l1_ (u"ࠫࠬゆ"),l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩょ"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭よ"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧら"),l11ll1_l1_ (u"ࠨࠩり"),679,l11ll1_l1_ (u"ࠩࠪる"),l11ll1_l1_ (u"ࠪࠫれ"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨろ"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪゎ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭わ"),l11ll1_l1_ (u"ࠧࠨゐ"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨゑ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫを")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫん"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠫࠬゔ"),l11ll1_l1_ (u"ࠬ࠭ゕ"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨゖ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ゗"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ゘")+l111l1_l1_+l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨ゙"),l11l1l_l1_,671,l11ll1_l1_ (u"゚ࠪࠫ"),l11ll1_l1_ (u"ࠫࠬ゛"),l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ゜"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ゝ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩゞ")+l111l1_l1_+l11ll1_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧゟ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠩࠪ゠"),l11ll1_l1_ (u"ࠪࠫァ"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨア"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬィ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨイ")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫゥ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠨࠩウ"),l11ll1_l1_ (u"ࠩࠪェ"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬエ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩォ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬオ"),l11ll1_l1_ (u"࠭ࠧカ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨガ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪキ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			if title==l11ll1_l1_ (u"ࠩส่ศ่ำศ็ࠪギ"): mode = 675
			else: mode = 674
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪク"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭グ")+l111l1_l1_+title,l1lllll_l1_,mode)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪケ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ゲ"),l11ll1_l1_ (u"ࠧࠨコ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬゴ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢサ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠪࠫザ"))
	#items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩシ"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬジ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨス")+l111l1_l1_+title,l1lllll_l1_,674)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬズ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨセ"),l11ll1_l1_ (u"ࠩࠪゼ"),9999)
	items = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࡦࡷࡵࡷࡴࡧ࠱࡬ࡹࡳ࡬ࠨソ"))
	for l1lllll_l1_,l1lll1_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫゾ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧタ")+l111l1_l1_+title,l1lllll_l1_,674,l1lll1_l1_)
	return
def CATEGORIES(url):
	l1ll1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫダ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩチ"),l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬヂ"))
	if l1ll1l1111_l1_: return l1ll1l1111_l1_
	#DIALOG_OK()
	l1ll1l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ッ"),url,l11ll1_l1_ (u"ࠪࠫツ"),l11ll1_l1_ (u"ࠫࠬヅ"),l11ll1_l1_ (u"ࠬ࠭テ"),l11ll1_l1_ (u"࠭ࠧデ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪト"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱࡭࡫ࡡࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࡁࠫド"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1ll1l1111_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ナ"),block,re.DOTALL)
		if l1ll1l1111_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬニ"),l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨヌ"),l1ll1l1111_l1_,l1llllll_l1_)
	return l1ll1l1111_l1_
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩネ"),url,l11ll1_l1_ (u"࠭ࠧノ"),l11ll1_l1_ (u"ࠧࠨハ"),l11ll1_l1_ (u"ࠨࠩバ"),l11ll1_l1_ (u"ࠩࠪパ"),l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪヒ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨビ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ピ"),l11ll1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬフ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫブ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠨࠩプ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧヘ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨベ"),l11ll1_l1_ (u"ࠫࠬペ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪホ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"࠭࠺ࠡࠩボ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧポ"),l111l1_l1_+title,l1lllll_l1_,671)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬマ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫミ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨム"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫメ"),l11ll1_l1_ (u"ࠬ࠭モ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ャ"),l111l1_l1_+title,l1lllll_l1_,671)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠧࠨヤ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩュ"),l11ll1_l1_ (u"ࠩࠪユ"),request,url)
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨョ"):
		url,search = url.split(l11ll1_l1_ (u"ࠫࡄ࠭ヨ"),1)
		data = l11ll1_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫラ")+search
		headers = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬリ"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧル")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭レ"),url,data,headers,l11ll1_l1_ (u"ࠩࠪロ"),l11ll1_l1_ (u"ࠪࠫヮ"),l11ll1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪワ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩヰ"),url,l11ll1_l1_ (u"࠭ࠧヱ"),l11ll1_l1_ (u"ࠧࠨヲ"),l11ll1_l1_ (u"ࠨࠩン"),l11ll1_l1_ (u"ࠩࠪヴ"),l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩヵ"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠫࠬヶ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩヷ"))
	if request==l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫヸ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩヹ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩヺ"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ・"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫー"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪヽ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬヾ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪヿ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㄀"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ㄁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ㄂"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㄃"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠫࠬ㄄"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㄅ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧㄆ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧㄇ"),l11ll1_l1_ (u"ࠨใํ่๊࠭ㄈ"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨㄉ"),l11ll1_l1_ (u"ࠪ็้๐ศࠨㄊ"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪㄋ"),l11ll1_l1_ (u"ࠬํฯศใࠪㄌ"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭ㄍ"),l11ll1_l1_ (u"ฺࠧำูࠫㄎ"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨㄏ"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨㄐ"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪㄑ"),l11ll1_l1_ (u"ࠫๆ๊ๅࠨㄒ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧㄓ"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫㄔ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩㄕ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪㄖ"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧㄗ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬㄘ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭ㄙ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧㄚ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩㄛ"),title,re.DOTALL)
		#addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㄜ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㄝ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㄞ"):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄟ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪㄠ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄡ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫㄢ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄣ"),l111l1_l1_+title,l1lllll_l1_,671,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄤ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄥ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨㄦ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭ㄧ"): continue
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪㄨ") not in l1lllll_l1_:
				l111lll_l1_ = url.rsplit(l11ll1_l1_ (u"࠭࠯ࠨㄩ"),1)[0]
				l1lllll_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩㄪ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪㄫ"))
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄬ"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩㄭ")+title,l1lllll_l1_,671,l11ll1_l1_ (u"ࠫࠬㄮ"),l11ll1_l1_ (u"ࠬ࠭ㄯ"),request)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㄰"),l11ll1_l1_ (u"ࠧࠨㄱ"),l1l1l_l1_,url)
	addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㄲ"),l111l1_l1_+l11ll1_l1_ (u"ࠩอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩㄳ"),url,672)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㄴ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㄵ"),l11ll1_l1_ (u"ࠬ࠭ㄶ"),9999)
	l1ll1l1111_l1_ = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡢࡳࡱࡺࡷࡪ࠴ࡨࡵ࡯࡯ࠫㄷ"))
	l1l1l1l1l1l_l1_,l1l1l1l1l11_l1_,l1l1l1ll1ll_l1_ = zip(*l1ll1l1111_l1_)
	l1l1l1l1lll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫㄸ"),url,l11ll1_l1_ (u"ࠨࠩㄹ"),l11ll1_l1_ (u"ࠩࠪㄺ"),l11ll1_l1_ (u"ࠪࠫㄻ"),l11ll1_l1_ (u"ࠫࠬㄼ"),l11ll1_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ㄽ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠪㄾ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡻࡅࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽ࠩㄿ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1l1l1l1l1l_l1_:
				item = (l1lllll_l1_,title)
				l1l1l1l1lll_l1_.append(item)
		if len(l1l1l1l1lll_l1_)==1:
			l1lllll_l1_,title = l1l1l1l1lll_l1_[0]
			l11111_l1_(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㅀ"))
			return
		else:
			for l1lllll_l1_,title in l1l1l1l1lll_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅁ"),l111l1_l1_+title,l1lllll_l1_,671,l11ll1_l1_ (u"ࠪࠫㅂ"),l11ll1_l1_ (u"ࠫࠬㅃ"),l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫㅄ"))
	if not l1l1l1l1lll_l1_: l11111_l1_(url,l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬㅅ"))
	return
#https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1l1l1ll11l_l1_
#https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1l1l1ll11l_l1_
def PLAY(url):
	l1llll11_l1_ = []
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩ࠱ไ๎้๋࠭ไำอ์๋࠳ศศำห๎࠲็๊࠮็฽ห๊ืษ࠮็อ่ศ๊ฦส࠯่ำอࡥࡤ࠺࠹࠸ࡧࡧ࠽࠵࠴࠰࡫ࡸࡲࡲࠧㅆ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬㅇ"),url,l11ll1_l1_ (u"ࠩࠪㅈ"),l11ll1_l1_ (u"ࠪࠫㅉ"),l11ll1_l1_ (u"ࠫࠬㅊ"),l11ll1_l1_ (u"ࠬ࠭ㅋ"),l11ll1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪㅌ"))
	html = response.content
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡦ࡭ࡣࡶ࡬ࡵࡲࡡࡺࡧࡵࠫㅍ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫㅎ"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࡢࡣࠬㅏ")+l111llll_l1_
			l1llll11_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㅐ"),html,re.DOTALL)
	if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠦ࡫࡯࡬ࡦ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦㅑ"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪㅒ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬㅓ")+l1lllll_l1_
		l1llll11_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨㅔ"))
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ㅕ"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㅖ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫㅗ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬㅘ"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧㅙ"),l11ll1_l1_ (u"࠭ࠫࠨㅚ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧㅛ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨㅜ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭ㅝ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨㅞ"))
	return
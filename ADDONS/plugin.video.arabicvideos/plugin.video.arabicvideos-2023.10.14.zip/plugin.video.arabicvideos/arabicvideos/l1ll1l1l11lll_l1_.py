# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ毴")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ毵")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠩࠪ毶")
#headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ毷"):l11ll1_l1_ (u"ࠫࠬ毸")}
def MAIN(mode,url,text,type,l1l1111_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11111ll_l1_(url)
	#elif mode==142: results = l1ll1l1l111ll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l1111_l1_)
	elif mode==145: results = l1ll1ll1llll1_l1_(url)
	elif mode==146: results = l1ll1l11lll1l_l1_(url)
	elif mode==147: results = l1ll1ll11l1l1_l1_()
	elif mode==148: results = l1ll1ll11ll11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࡒࡏࡈ࠸࡞ࡣ࡙ࡍࡅ࡙ࡸࢀ࡬ࡃࡶࡐࡗࡼࡌࡦ࡛࡜࡙ࡘࡑࡖࡋࡻࡼࡳࡶࡽࡕࡓࠨ毹")
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭毺"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡕࡇࡖࡘࠥ࡟ࡏࡖࡖࡘࡆࡊ࠭毻"),url,144)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毼"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡲࡰࡩ࡫ࡲࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࠣࡲࡴࡺࠠ࡭࡫ࡶࡸ࡮ࡴࡧࠡࡰࡨࡻࡪࡸࠠࡱ࡮ࡼࡥࡱ࡯ࡳࡵࠩ毽"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࡙ࡈࡳࡵࡪ࡟ࡺ࡙࡜ࡩ࡯ࠫࡲࡩࡴࡶࡀࡖࡉࡗࡍ࠷࠵ࡹࡌ࡯ࡖ࠰ࡩࡧࡗࡷࠬ毾"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毿"),l111l1_l1_+l11ll1_l1_ (u"๋่ࠬใ฻ࠣๅฬืฺࠨ氀"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡗࡆࡸࡔࡼ࡯࡯࡬࠷ࡋࡾࡵࡰࡎࡖࡐࡆࡦ࠸࠳ࡲࡗࡦࡻࠬ氁"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氂"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ氃"),l11ll1_l1_ (u"ࠩࠪ氄"),149,l11ll1_l1_ (u"ࠪࠫ氅"),l11ll1_l1_ (u"ࠫࠬ氆"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ氇"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭氈"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ氉")+l11ll1_l1_ (u"ࠨࡡ࡜ࡘࡈࡥࠧ氊")+l11ll1_l1_ (u"่ࠩ์ฬู่ࠡษัฮฬื็ศࠢส่๊ฮัๆฮࠪ氋"),l11ll1_l1_ (u"ࠪࠫ氌"),290)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ氍"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ氎")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬ๊้ࠦฬํ์อ࠭氏"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭氐"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ民"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ氒")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ氓"),l11l1l_l1_,144,l11ll1_l1_ (u"ࠫࠬ气"),l11ll1_l1_ (u"ࠬ࠭氕"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ氖"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ気"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ氘")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊ำส้๋ࠣห้ืววฮࠪ氙"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ氚"),146)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ氛"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ氜"),l11ll1_l1_ (u"࠭ࠧ氝"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氞"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ氟")+l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ氠"),l11ll1_l1_ (u"ࠪࠫ氡"),147)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ氢"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ氣")+l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣวั์ศ๋หࠪ氤"),l11ll1_l1_ (u"ࠧࠨ氥"),148)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ氦"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ氧")+l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭氨"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ氩"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ氪"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ氫")+l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤฬาๆษ์ฬࠫ氬"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡰࡳࡻ࡯ࡥࠨ氭"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ氮"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ氯")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ氰"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭氱"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭氲"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ氳")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะฺࠠำห๎ฮ࠭水"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้๊ำๅࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ氵"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ氶"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭氷")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ永"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ氹"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氺"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ氻")+l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ氼"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ氽"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ氾"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ氿")+l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ汀"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ใาส็หฦ࠱วๅใูหห๐ษࠬะฺฬฮ࠱วๅฮ่฽ฮࠬࡳࡱ࠿ࡆࡅࡎ࡙ࡁࡩࡃࡅࠫ汁"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ求"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ汃")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้฿ัศไࠣา฼ฮษࠡษ็้ึาู๋หࠪ汄"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌ࠵࡬ࡘࡵ࠻ࡶ࡮ࡈ࠵࠹ࡕ࡯ࡻࡘࡅࡪࡑࡲࡎࡲࡲࡪࡷࡽࡶࡴ࡚ࡆࡵ࡯ࡩࡶࠬ汅"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ汆"),l111l1_l1_+l11ll1_l1_ (u"࠭วฺัสำฬะࠠศุสๅฮ๊้ࠦฬํ์อ࠭汇"),l11ll1_l1_ (u"ࠧࠨ汈"),144)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ汉"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ汊"),l11ll1_l1_ (u"๋ࠪีอࠠศๆสาฯ๐วาࠢึ์ๆ๊ࠦฯำฯ็๋ࠥๆࠡษ็ฬึ์วๆฮࠪ汋"),l11ll1_l1_ (u"้ࠫษๆ่ࠢึ์ๆ๊ࠦใ๊่ࠤอะิ฻์็ࠤอืๆศ็ฯࠤ๏๎ส๋๊หࠫ汌"))
	#if l1ll111ll1_l1_==1:
	#	url = l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ汍")
	#	xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭ࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠫࠪ汎"))
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡓࡧࡳࡰࡦࡩࡥࡘ࡫ࡱࡨࡴࡽࠨࡷ࡫ࡧࡩࡴࡹࠬࠨ汏")+url+l11ll1_l1_ (u"ࠨࠫࠪ汐"))
	#	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡕࡹࡳࡇࡤࡥࡱࡱࠬࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠭ࠬ汑"))
	return
l11ll1_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡑࡆࡏࡎࡑࡃࡊࡉ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎ࡮ࡴ࡮࡮࠯ࡧࡨ࠲ࡤࡢࡶࡤࠤࡂࠦࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠮ࡵࡳ࡮ࠬࠎࠎ࡯ࡦࠡࠩࡕࡩ࡫ࡧࡡࡵࠢࡄࡰ࠲ࡍࡡ࡮࡯ࡤࡰࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠡࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡷࡲࠬࠨࡻࡨࡷࠬ࠯ࠊࠊࡦࡧࠤࡂࠦࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠌࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸ࡮ࡢࡩࡨࠬࡱ࡫࡮ࠩࡦࡧ࠭࠮ࡀࠊࠊࠋ࡬ࡸࡪࡳࠠ࠾ࠢࡧࡨࡠ࡯࡝ࠋࠋࠌࡍࡓ࡙ࡅࡓࡖࡢࡍ࡙ࡋࡍࡠࡖࡒࡣࡒࡋࡎࡖࠪ࡬ࡸࡪࡳࠩࠋࠋࡌࡘࡊࡓࡓࠩࡷࡵࡰ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠣࠤࠥ汒")
def l1ll1ll11l1l1_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ汓"))
	return
def l1ll1ll11ll11_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ汔"))
	return
def PLAY(url,type):
	#url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨ汕")
	#items = re.findall(l11ll1_l1_ (u"ࠧࡷ࠿ࠫ࠲࠯ࡅࠩࠥࠩ汖"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ汗")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ汘"))
	#return
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡪ࡯ࡳࡳࡷࡺࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠬࡺࡸ࡬ࠪࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠨࡶࡴ࡯࠭ࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࠱ࠫࠬ࠭࠮࠯ࠥࠦࠧࠬࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠮ࠐࠉࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒࠬࡱ࡯࡮࡬ࡵ࡞࠴ࡢ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࡹࡿࡰࡦࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࠨࠢࠣ汙")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1l11lll1l_l1_(url):
	html,cc,data = l1ll1ll111l1l_l1_(url)
	dd = cc[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭汚")][l11ll1_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ汛")][l11ll1_l1_ (u"࠭ࡴࡢࡤࡶࠫ汜")]
	for l11ll11111_l1_ in range(len(dd)):
		item = dd[l11ll11111_l1_]
		l1ll1ll1ll11l_l1_(item,url,str(l11ll11111_l1_))
	ee = dd[0][l11ll1_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ汝")][l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ汞")][l11ll1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ江")][l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ池")]
	s = 0
	for l11ll11111_l1_ in range(len(ee)):
		item = ee[l11ll11111_l1_][l11ll1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ污")][l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ汢")][0]
		if list(item[l11ll1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭汣")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ汤")].keys())[0]==l11ll1_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ汥"): continue
		succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_ = l1ll1lll111l1_l1_(item)
		if not title:
			s += 1
			title = l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤึอฦอหࠣࠫ汦")+str(s)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ汧"),l111l1_l1_+title,url,144,l11ll1_l1_ (u"ࠫࠬ汨"),str(l11ll11111_l1_))
	key = re.findall(l11ll1_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ汩"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ汪")+key[0]
	html,cc,l11ll11l1_l1_ = l1ll1ll111l1l_l1_(l111lll_l1_)
	for l1ll1l111lll_l1_ in range(3,4):
		dd = cc[l11ll1_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭汫")][l1ll1l111lll_l1_][l11ll1_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ汬")][l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ汭")]
		for l11ll11111_l1_ in range(len(dd)):
			item = dd[l11ll11111_l1_]
			if l11ll1_l1_ (u"ࠪ࡝ࡴࡻࡔࡶࡤࡨࠤࡕࡸࡥ࡮࡫ࡸࡱࠬ汮") in str(item): continue
			l1ll1ll1ll11l_l1_(item)
	return
def ITEMS(url,data=l11ll1_l1_ (u"ࠫࠬ汯"),index=0):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ汰"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ汱"),l11ll1_l1_ (u"ࠧࠨ汲"))
	html,cc,l11ll11l1_l1_ = l1ll1ll111l1l_l1_(url,data)
	l1l1111111_l1_,ff = l11ll1_l1_ (u"ࠨࠩ汳"),l11ll1_l1_ (u"ࠩࠪ汴")
	#if l11ll1_l1_ (u"ࠪࡳࡼࡴࡥࡳࠩ汵") in html.lower(): DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ汶"),l11ll1_l1_ (u"ࠬ࠭汷"),l11ll1_l1_ (u"࠭࡯ࡸࡰࡨࡶࠥ࡫ࡸࡪࡵࡷࠫ汸"),l11ll1_l1_ (u"ࠧࡪࡰࠣ࡬ࡹࡳ࡬ࠨ汹"))
	owner = re.findall(l11ll1_l1_ (u"ࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭決"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠩࠥࡺ࡮ࡪࡥࡰࡑࡺࡲࡪࡸࠢ࠯ࠬࡂࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭汻"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠪࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡒ࡫ࡴࡢࡦࡤࡸࡦࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡱࡺࡲࡪࡸࡕࡳ࡮ࡶࠦ࠿ࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ汼"),html,re.DOTALL)
	if owner:
		l1l1111111_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ汽")+owner[0][0]+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ汾")
		l1lllll_l1_ = owner[0][1]
		if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ汿") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		#if l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ沀") in url and l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ沁") not in url and l11ll1_l1_ (u"ࠩ࠲ࡧ࠴࠭沂") not in url and l11ll1_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ沃") not in url:
		if l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ沄") in url: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ沅"),l111l1_l1_+l1l1111111_l1_,l1lllll_l1_,144)
	#if cc==l11ll1_l1_ (u"࠭ࠧ沆"): l1ll1l1l111l1_l1_(url,html) ; return
	l1ll1l1l11111_l1_ = [l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ沇"),l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ沈"),l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ沉"),l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ沊"),l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ沋"),l11ll1_l1_ (u"ࠬࡹࡳ࠾ࠩ沌"),l11ll1_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ沍"),l11ll1_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ沎"),l11ll1_l1_ (u"ࠨࡤࡳࡁࠬ沏"),l11ll1_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ沐")]
	l1ll1l11ll1ll_l1_ = not any(value in url for value in l1ll1l1l11111_l1_)
	if l1ll1l11ll1ll_l1_ and l1l1111111_l1_:
		l11l1l1l1_l1_ = l11ll1_l1_ (u"ࠪห้ฮอฬࠩ沑")
		l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠫ็๎วว็ࠣห้ะิ฻์็ࠫ沒")
		l11l1l11l_l1_ = l11ll1_l1_ (u"ࠬอไโ์า๎ํํวหࠩ沓")
		l1ll1l11lll11_l1_ = l11ll1_l1_ (u"࠭วๅไ้์ฬะࠧ沔")
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ沕"),l111l1_l1_+l1l1111111_l1_,url,9999)
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥฬาัࠢࠨ沖") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ沗"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠪࠫ沘"),l11ll1_l1_ (u"ࠫࠬ沙"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ沚"))
		if l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ沛") in html: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沜"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ沝"),144)
		if l11ll1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ沞") in html: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ沟"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ沠"),144)
		if l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ没") in html: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭沢"),l111l1_l1_+l1ll1l11lll11_l1_,url+l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ沣"),144)
		if l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡗࡪࡧࡲࡤࡪࠥࠫ沤") in html: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ沥"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠪࠫ沦"),l11ll1_l1_ (u"ࠫࠬ沧"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ沨"))
		if l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ沩") in html: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沪"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ沫"),144)
		if l11ll1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ沬") in html: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ沭"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ沮"),144)
		if l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡄࡪࡤࡲࡳ࡫࡬ࡴࠤࠪ沯") in html: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭沰"),l111l1_l1_+l1ll1l11lll11_l1_,url+l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ沱"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭沲"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ河"),l11ll1_l1_ (u"ࠪࠫ沴"),9999)
	if l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ沵") in url:
		dd = cc[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ沶")][l11ll1_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ沷")][l11ll1_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ沸")][l11ll1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ油")][l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ沺")]
		l1ll1l11ll1l1_l1_ = 0
		for i in range(len(dd)):
			if l11ll1_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ治") in list(dd[i].keys()):
				l1ll1l11ll11l_l1_ = dd[i][l11ll1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ沼")]
				length = len(str(l1ll1l11ll11l_l1_))
				if length>l1ll1l11ll1l1_l1_:
					l1ll1l11ll1l1_l1_ = length
					ff = l1ll1l11ll11l_l1_
		if l1ll1l11ll1l1_l1_==0: return
	elif l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ沽") in url or l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ沾") in url or l11ll1_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭沿") in url or l11ll1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ泀") in url or l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ況") in url or url==l11l1l_l1_:
		l1ll1l1ll111l_l1_ = []
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ泂"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ泃"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ泄"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡨࡴ࡬ࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ泅"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠧ泆"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠰࠵ࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ泇"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ泈"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡘࡣࡷࡧ࡭ࡔࡥࡹࡶࡕࡩࡸࡻ࡬ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝ࠣ泉"))
		l1ll1l11lllll_l1_,ff = l1ll1l1l11ll1_l1_(cc,l11ll1_l1_ (u"ࠫࠬ泊"),l1ll1l1ll111l_l1_)
	if not ff:
		try:
			dd = cc[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ泋")][l11ll1_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ泌")][l11ll1_l1_ (u"ࠧࡵࡣࡥࡷࠬ泍")]
			l1ll1ll1l1ll_l1_ = l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ泎") in url or l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭泏") in url or l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭泐") in url
			l1ll1l1l1l1l1_l1_ = l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ泑") in html or l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ泒") in html or l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๆ๋๎วหࠤࠪ泓") in html
			l1ll1l1l1l11l_l1_ = l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ泔") in html or l11ll1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ法") in html or l11ll1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ泖") in html
			if l1ll1ll1l1ll_l1_ and (l1ll1l1l1l1l1_l1_ or l1ll1l1l1l11l_l1_):
				for l11ll11111_l1_ in range(len(dd)):
					if l11ll1_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ泗") not in list(dd[l11ll11111_l1_].keys()): continue
					ee = dd[l11ll11111_l1_][l11ll1_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ泘")]
					try: gg = ee[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭泙")][l11ll1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ泚")][l11ll1_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ泛")][l11ll1_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ泜")][l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬ泝")][l11ll11111_l1_]
					except: gg = ee
					try: l1lllll_l1_ = gg[l11ll1_l1_ (u"ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬ泞")][l11ll1_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭泟")][l11ll1_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ泠")][l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ泡")]
					except: continue
					if   l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ波")		in l1lllll_l1_	and l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ泣")		in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭泤")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ泥")	in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ泦")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ泧")		in url: ee = dd[l11ll11111_l1_] ; break
					else: ee = dd[0]
			elif l11ll1_l1_ (u"࠭ࡢࡱ࠿ࠪ注") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11ll1_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ泩")][l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ泪")]
		except: pass
	if not ff: return
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ泫"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ泬"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ泭"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ泮"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ泯"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ泰"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ泱"))
	if l11ll1_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ泲") not in url: l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪࡡࡠ࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ࡞ࠤ泳"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ泴"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ泵"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ泶"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ泷"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ泸"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ泹"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ泺"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ泻"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦࠣ泼"))
	l111l1l1l11_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡻࠧไๆࠣๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ泽"))
	l111l1l1l1l_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡵࠨๅ็ࠤฬ๊แ๋ัํ์์อสࠨ泾"))
	l1ll1l11llll1_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶࠩๆ่ࠥอไใ่๋หฯ࠭泿"))
	l11l1ll11ll1_l1_ = [l111l1l1l11_l1_,l111l1l1l1l_l1_,l1ll1l11llll1_l1_,l11ll1_l1_ (u"ࠩࡄࡰࡱࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ洀"),l11ll1_l1_ (u"ࠪࡅࡱࡲࠠࡷ࡫ࡧࡩࡴࡹࠧ洁"),l11ll1_l1_ (u"ࠫࡆࡲ࡬ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ洂")]
	l1ll1l1l1111l_l1_,gg = l1ll1l1l11ll1_l1_(ff,index,l1ll1l1ll111l_l1_)
	if l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ洃") in str(type(gg)) and any(value in str(gg[0]) for value in l11l1ll11ll1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll1l1ll111l_l1_ = []
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ洄"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ洅"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ洆"))
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ洇"))		#4
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ洈"))		#7
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ洉"))		#6
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ洊"))		#5
		l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟ࠥ洋"))
		l1ll1l11lllll_l1_,item = l1ll1l1l11ll1_l1_(gg,index2,l1ll1l1ll111l_l1_)
		#if l1ll1l11lllll_l1_ not in [l11ll1_l1_ (u"ࠧ࠳ࠩ洌"),l11ll1_l1_ (u"ࠨ࠶ࠪ洍"),l11ll1_l1_ (u"ࠩ࠸ࠫ洎")]: l1ll1ll1ll11l_l1_(item)		# 2,4,7
		#else: l1ll1ll1ll11l_l1_(item,url,str(index2))
		l1ll1ll1ll11l_l1_(item,url,str(index2))
		if l1ll1l11lllll_l1_==l11ll1_l1_ (u"ࠪ࠸ࠬ洏"):
			try:
				hh = item[l11ll1_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫ洐")][l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭洑")][l11ll1_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭洒")][l11ll1_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭洓")]
				for l1ll1ll11l111_l1_ in range(len(hh)):
					l1ll1l1l11l11_l1_ = hh[l1ll1ll11l111_l1_]
					l1ll1ll1ll11l_l1_(l1ll1l1l11l11_l1_)
			except: pass
	l1ll1l1lll11l_l1_ = False
	if l11ll1_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ洔") not in url and l1ll1l1l1111l_l1_==l11ll1_l1_ (u"ࠩ࠻ࠫ洕"): l1ll1l1lll11l_l1_ = True
	if l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ洖") in l11ll11l1_l1_: l1ll1ll1l111l_l1_,key,l1ll1lll1111l_l1_,l1ll1ll11l1ll_l1_,token,l1ll1l1llll1l_l1_ = l11ll11l1_l1_.split(l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ洗"))
	else: l1ll1ll1l111l_l1_,key,l1ll1lll1111l_l1_,l1ll1ll11l1ll_l1_,token,l1ll1l1llll1l_l1_ = l11ll1_l1_ (u"ࠬ࠭洘"),l11ll1_l1_ (u"࠭ࠧ洙"),l11ll1_l1_ (u"ࠧࠨ洚"),l11ll1_l1_ (u"ࠨࠩ洛"),l11ll1_l1_ (u"ࠩࠪ洜"),l11ll1_l1_ (u"ࠪࠫ洝")
	l111lll_l1_,l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠫࠬ洞"),l11ll1_l1_ (u"ࠬ࠭洟")
	if menuItemsLIST:
		l1ll1l1l1l111_l1_ = str(menuItemsLIST[-1][1])
		if   l111l1_l1_+l11ll1_l1_ (u"࠭ࡃࡉࡐࡏࠫ洠") in l1ll1l1l1l111_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ洡")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠨࡗࡖࡉࡗ࠭洢") in l1ll1l1l1l111_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ洣")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ洤") in l1ll1l1l1l111_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠫࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ津")
	if l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡸࠨࠧ洦") in html and l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭洧") not in url and not l1ll1l1lll11l_l1_ and l11ll1_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥࠩ洨") not in url:	# and (index!=l11ll1_l1_ (u"ࠨࠩ洩") or l11ll1_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ洪") in url or l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ洫") in url or l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡻࡥࡳࡻࡀࠫ洬") in url or l11ll1_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ洭") in url):
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࡟ࡢ࡬ࡤࡼࡄࡩࡴࡰ࡭ࡨࡲࡂ࠭洮")+l1ll1lll1111l_l1_
	elif l11ll1_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ洯") in html and l11ll1_l1_ (u"ࠨࡤࡳࡁࠬ洰") not in url and l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ洱") in url or l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ洲") in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ洳")+key
	elif l11ll1_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭洴") in html and l11ll1_l1_ (u"࠭ࡢࡱ࠿ࠪ洵") not in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ洶")+key
	if l111lll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ洷"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ洸"),l111lll_l1_,144,l1ll1l111l1_l1_,l11ll1_l1_ (u"ࠪࠫ洹"),l11ll11l1_l1_)
	return
def l1ll1l1l11ll1_l1_(l11ll111ll1l_l1_,l11ll11ll11l_l1_,l1ll1l1lll1l1_l1_):
	cc = l11ll111ll1l_l1_
	ff,index = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	gg,index2 = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	item,render = l11ll111ll1l_l1_,l11ll11ll11l_l1_
	count = len(l1ll1l1lll1l1_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1l1lll1l1_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠫࠬ洺")
			return str(l11ll11111_l1_+1),out
		except: pass
	return l11ll1_l1_ (u"ࠬ࠭活"),l11ll1_l1_ (u"࠭ࠧ洼")
def l1ll1lll111l1_l1_(item):
	try: l1ll1ll1l1l1l_l1_ = list(item.keys())[0]
	except: return False,l11ll1_l1_ (u"ࠧࠨ洽"),l11ll1_l1_ (u"ࠨࠩ派"),l11ll1_l1_ (u"ࠩࠪ洿"),l11ll1_l1_ (u"ࠪࠫ浀"),l11ll1_l1_ (u"ࠫࠬ流"),l11ll1_l1_ (u"ࠬ࠭浂"),l11ll1_l1_ (u"࠭ࠧ浃")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_ = False,l11ll1_l1_ (u"ࠧࠨ浄"),l11ll1_l1_ (u"ࠨࠩ浅"),l11ll1_l1_ (u"ࠩࠪ浆"),l11ll1_l1_ (u"ࠪࠫ浇"),l11ll1_l1_ (u"ࠫࠬ浈"),l11ll1_l1_ (u"ࠬ࠭浉"),l11ll1_l1_ (u"࠭ࠧ浊")
	#WRITE_THIS(l11ll1_l1_ (u"ࠧࠨ测"),str(item))
	render = item[l1ll1ll1l1l1l_l1_]
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ浌"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ浍"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ济"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ浏"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ浐"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ浑"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ浒"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ浓"))
	l1ll1l11lllll_l1_,title = l1ll1l1l11ll1_l1_(item,render,l1ll1l1ll111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ浔"),l11ll1_l1_ (u"ࠪࠫ浕"),l11ll1_l1_ (u"ࠫࠬ浖"),title)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ浗"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ浘"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ浙"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ浚")) # required for l11ll111111l_l1_ l1ll1l1lll11l_l1_
	l1ll1l11lllll_l1_,l1lllll_l1_ = l1ll1l1l11ll1_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ浛"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ浜"))
	l1ll1l11lllll_l1_,l1lll1_l1_ = l1ll1l1l11ll1_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ浝"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ浞"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ浟"))
	l1ll1l11lllll_l1_,count = l1ll1l1l11ll1_l1_(item,render,l1ll1l1ll111l_l1_)
	l1ll1l1ll111l_l1_ = []
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ浠"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ浡"))
	l1ll1l1ll111l_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ浢"))
	l1ll1l11lllll_l1_,l1l11lll1_l1_ = l1ll1l1l11ll1_l1_(item,render,l1ll1l1ll111l_l1_)
	if l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ浣") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11ll_l1_ = l11ll1_l1_ (u"ࠫࠬ浤"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭浥")
	if l11ll1_l1_ (u"࠭ๅษษืีࠬ浦") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11ll_l1_ = l11ll1_l1_ (u"ࠧࠨ浧"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ浨")
	if l11ll1_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ浩") in list(render.keys()):
		l1ll1ll1ll1l1_l1_ = str(render[l11ll1_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ浪")])
		if l11ll1_l1_ (u"ࠫࡋࡸࡥࡦࠢࡺ࡭ࡹ࡮ࠠࡂࡦࡶࠫ浫") in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠬࠪ࠺ࠨ浬")
		if l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠤࡓࡕࡗࠨ浭") in l1ll1ll1ll1l1_l1_: l111lll11ll_l1_ = l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ浮")
		if l11ll1_l1_ (u"ࠨࡄࡸࡽࠬ浯") in l1ll1ll1ll1l1_l1_ or l11ll1_l1_ (u"ࠩࡕࡩࡳࡺࠧ浰") in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠪࠨࠩࡀࠧ浱")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡹ๋ࠬศศึิࠫ浲")) in l1ll1ll1ll1l1_l1_: l111lll11ll_l1_ = l11ll1_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭浳")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡻࠧีำสลࠬ浴")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠧࠥࠦ࠽ࠫ浵")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶࠩสืฯฬฬศำࠪ浶")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠩࠧࠨ࠿࠭海")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡸࠫส฿ไศ่สฮࠬ浸")) in l1ll1ll1ll1l1_l1_: l1ll1ll111ll1_l1_ = l11ll1_l1_ (u"ࠫࠩࡀࠧ浹")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ浺") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"࠭࠿ࠨ浻"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ浼") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ浽")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll111ll1_l1_: title = l1ll1ll111ll1_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠬ浾")+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠪ࠰ࠬ浿"),l11ll1_l1_ (u"ࠫࠬ涀"))
	count = count.replace(l11ll1_l1_ (u"ࠬ࠲ࠧ涁"),l11ll1_l1_ (u"࠭ࠧ涂"))
	count = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࠮ࠫ涃"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠨࠩ涄")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_
def l1ll1ll1ll11l_l1_(item,url=l11ll1_l1_ (u"ࠩࠪ涅"),index=l11ll1_l1_ (u"ࠪࠫ涆")):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11ll_l1_,l1ll1ll111ll1_l1_ = l1ll1lll111l1_l1_(item)
	#if l11ll1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ涇") in url and index==l11ll1_l1_ (u"ࠬ࠶ࠧ消"):
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涉"),l111l1_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11ll1_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ涊") in str(item): return	# l1ll1lll1111l_l1_ not items
	elif l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡑࡻࡹࡖࡪࡴࡤࡦࡴࡨࡶࠬ涋") in str(item): return			# l1ll1ll1l1lll_l1_ not items
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ涌") in url: return			# separator l1ll1l11ll111_l1_ list not items
	elif title and not l1lllll_l1_ and (l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ涍") in url or l11ll1_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ涎") in str(item) or url==l11l1l_l1_):
		title = l11ll1_l1_ (u"ࠬࡃ࠽࠾ࠢࠪ涏")+title+l11ll1_l1_ (u"࠭ࠠ࠾࠿ࡀࠫ涐")
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ涑"),l111l1_l1_+title,l11ll1_l1_ (u"ࠨࠩ涒"),9999)
	elif title and l11ll1_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠫ涓") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ涔"),l111l1_l1_+title,l11ll1_l1_ (u"ࠫࠬ涕"),9999)
	elif l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭涖") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涗"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif not title: return
	elif l111lll11ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ涘"),l111l1_l1_+l111lll11ll_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	#elif l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ涙") in l1lllll_l1_ and l11ll1_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ涚") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠪࡸࡂ࠶ࠧ涛") not in l1lllll_l1_:
	#	l1ll1ll111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠫ࠲࠯ࡅࠩࠥࠩ涜"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ涝")+l1ll1ll111lll_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涞"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡍࡋࡖࡘࠬ涟")+count+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ涠")+title,l1lllll_l1_,144,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ涡") in l1lllll_l1_ or l11ll1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ涢") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ涣") in l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ涤") not in l1lllll_l1_:
			l1ll1ll111lll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭涥"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ润")+l1ll1ll111lll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ涧"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ涨")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ涩")+title,l1lllll_l1_,144,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ涪"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ涫"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	else:
		type = l11ll1_l1_ (u"࠭ࠧ涬")
		if not l1lllll_l1_: l1lllll_l1_ = url
		#if l11ll1_l1_ (u"ࠧࡴࡵࡀࠫ涭") in l1lllll_l1_: l1lllll_l1_ = url
		#elif l11ll1_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ涮") in l1lllll_l1_: l1lllll_l1_ = url		# not needed it will stop l1ll1l1l11l1l_l1_ l11ll111111l_l1_ l1ll1l1lll11l_l1_
		elif not any(value in l1lllll_l1_ for value in [l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ涯"),l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ涰"),l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ涱"),l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ液"),l11ll1_l1_ (u"࠭ࡳࡴ࠿ࠪ涳"),l11ll1_l1_ (u"ࠧࡣࡲࡀࠫ涴")]):
			if l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ涵")	in l1lllll_l1_ or l11ll1_l1_ (u"ࠩ࠲ࡧ࠴࠭涶") in l1lllll_l1_: type = l11ll1_l1_ (u"ࠪࡇࡍࡔࡌࠨ涷")+count+l11ll1_l1_ (u"ࠫ࠿ࠦࠠࠨ涸")
			if l11ll1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ涹") in l1lllll_l1_: type = l11ll1_l1_ (u"࠭ࡕࡔࡇࡕࠫ涺")+count+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ涻")
			index,l1ll1ll11llll_l1_ = l11ll1_l1_ (u"ࠨࠩ涼"),l11ll1_l1_ (u"ࠩࠪ涽")
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ涾"),l111l1_l1_+type+title,l1lllll_l1_,144,l1lll1_l1_,index)
	return
def l1ll1ll111l1l_l1_(url,data=l11ll1_l1_ (u"ࠫࠬ涿"),request=l11ll1_l1_ (u"ࠬ࠭淀")):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ淁"))
	#if l11ll1_l1_ (u"ࠧࡠࡡࠪ淂") in l1ll1ll11llll_l1_: l1ll1ll11llll_l1_ = l11ll1_l1_ (u"ࠨࠩ淃")
	#if l11ll1_l1_ (u"ࠩࡶࡷࡂ࠭淄") in url: url = url.split(l11ll1_l1_ (u"ࠪࡷࡸࡃࠧ淅"))[0]
	if request==l11ll1_l1_ (u"ࠫࠬ淆"): request = l11ll1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ淇")
	l111lll1ll_l1_ = l11llllll_l1_()
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ淈"):l111lll1ll_l1_,l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ淉"):l11ll1_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ淊")}
	#l1l1ll11l_l1_ = headers.copy()
	if l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭淋") in data: l1ll1ll1l111l_l1_,key,l1ll1lll1111l_l1_,l1ll1ll11l1ll_l1_,token,l1ll1l1llll1l_l1_ = data.split(l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ淌"))
	else: l1ll1ll1l111l_l1_,key,l1ll1lll1111l_l1_,l1ll1ll11l1ll_l1_,token,l1ll1l1llll1l_l1_ = l11ll1_l1_ (u"ࠫࠬ淍"),l11ll1_l1_ (u"ࠬ࠭淎"),l11ll1_l1_ (u"࠭ࠧ淏"),l11ll1_l1_ (u"ࠧࠨ淐"),l11ll1_l1_ (u"ࠨࠩ淑"),l11ll1_l1_ (u"ࠩࠪ淒")
	if l11ll1_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ淓") in url:
		l11ll11l1_l1_ = {}
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ淔")] = {l11ll1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࠧ淕"):{l11ll1_l1_ (u"ࠨࡨ࡭ࠤ淖"):l11ll1_l1_ (u"ࠢࡢࡴࠥ淗"),l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ淘"):l11ll1_l1_ (u"ࠤ࡚ࡉࡇࠨ淙"),l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ淚"):l1ll1ll11l1ll_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ淛"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ淜"))
	elif l11ll1_l1_ (u"࠭࡫ࡦࡻࡀࠫ淝") in url and l1ll1ll1l111l_l1_:
		l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭淞"):token}
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ淟")] = {l11ll1_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ淠"):{l11ll1_l1_ (u"ࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ淡"):l1ll1ll1l111l_l1_,l11ll1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ淢"):l11ll1_l1_ (u"ࠧ࡝ࡅࡃࠤ淣"),l11ll1_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ淤"):l1ll1ll11l1ll_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ淥"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠵ࡲࡩ࠭淦"))
	elif l11ll1_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ淧") in url and l1ll1l1llll1l_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡎࡢ࡯ࡨࠫ淨"):l11ll1_l1_ (u"ࠫ࠶࠭淩"),l11ll1_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡘࡨࡶࡸ࡯࡯࡯ࠩ淪"):l1ll1ll11l1ll_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭淫"):l11ll1_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࡂ࠭淬")+l1ll1l1llll1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ淭"),url,l11ll1_l1_ (u"ࠩࠪ淮"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠪࠫ淯"),l11ll1_l1_ (u"ࠫࠬ淰"),l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ深"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ淲"),url,l11ll1_l1_ (u"ࠧࠨ淳"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠨࠩ淴"),l11ll1_l1_ (u"ࠩࠪ淵"),l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠹ࡺࡨࠨ淶"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ混"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡷࡧࡵࠦ࠳࠰࠿ࠣࡸࡤࡰࡺ࡫ࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ淸"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll11l1ll_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ淹"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ淺"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll1l111l_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ添"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll1111l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ淼") in list(cookies.keys()): l1ll1l1llll1l_l1_ = cookies[l11ll1_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ淽")]
	data = l1ll1ll1l111l_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ淾")+key+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ淿")+l1ll1lll1111l_l1_+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ渀")+l1ll1ll11l1ll_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ渁")+token+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ渂")+l1ll1l1llll1l_l1_
	if request==l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ渃") and l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ渄") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡠࡠࠨࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠨ࡜࡞ࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭清"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭渆"),html,re.DOTALL)
		l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"࠭ࡳࡵࡴࠪ渇"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ済") and l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭渉") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ渊"),html,re.DOTALL)
		l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ渋"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"ࠫࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ渌") not in html: l1ll1l1ll11l1_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ渍"),html)
	else: l1ll1l1ll11l1_l1_ = l11ll1_l1_ (u"࠭ࠧ渎")
	#open(l11ll1_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡪࡴࡱࡱࠫ渏"),l11ll1_l1_ (u"ࠨࡹࠪ渐")).write(str(l1ll1l1ll11l1_l1_))
	#open(l11ll1_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭渑"),l11ll1_l1_ (u"ࠪࡻࠬ渒")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭渓"),data)
	return html,l1ll1l1ll11l1_l1_,data
def l1ll1ll1llll1_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ渔"),l11ll1_l1_ (u"࠭ࠫࠨ渕"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ渖")+search
	ITEMS(l111lll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ渗"),l11ll1_l1_ (u"ࠩ࠮ࠫ渘"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ渙")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ渚") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ減")
		elif l11ll1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ渜") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ渝")
		elif l11ll1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭渞") in options: l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ渟")
		l11l111_l1_ = l111lll_l1_+l1ll1l1llllll_l1_
	else:
		l1ll1l1lllll1_l1_,l1ll1l1l1lll1_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠪࠫ渠")
		l1ll1l1ll1111_l1_ = [l11ll1_l1_ (u"ࠫอี่็ࠢอีฯ๐ศࠨ渡"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡ็าํࠥอไึๆฬࠫ渢"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษࠢอหึ๐ฮࠡษ็ฮา๋๊ๅࠩ渣"),l11ll1_l1_ (u"ࠧหำอ๎อࠦอิสࠣ฽ิีࠠศๆุ่ฬํฯศฬࠪ渤"),l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฬ๊สใ์ํ้ࠬ渥")]
		l1ll1ll1l1ll1_l1_ = [l11ll1_l1_ (u"ࠩࠪ渦"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡄࠩ࠷࠻࠳ࡅࠩ渧"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡍࠪ࠸࠵࠴ࡆࠪ渨"),l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡒࠫ࠲࠶࠵ࡇࠫ温"),l11ll1_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡋࠥ࠳࠷࠶ࡈࠬ渪")]
		l1ll1ll1ll1ll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไหำอ๎อ࠭渫"),l1ll1l1ll1111_l1_)
		if l1ll1ll1ll1ll_l1_ == -1: return
		l1ll1l1llll11_l1_ = l1ll1ll1l1ll1_l1_[l1ll1ll1ll1ll_l1_]
		html,c,data = l1ll1ll111l1l_l1_(l111lll_l1_+l1ll1l1llll11_l1_)
		if c:
			d = c[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ測")][l11ll1_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ渭")][l11ll1_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ渮")][l11ll1_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ港")][l11ll1_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭渰")][l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ渱")][l11ll1_l1_ (u"ࠧࡨࡴࡲࡹࡵࡹࠧ渲")]
			for l1ll1l1l1ll1l_l1_ in range(len(d)):
				group = d[l1ll1l1l1ll1l_l1_][l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡇࡳࡱࡸࡴࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭渳")][l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ渴")]
				for l1ll1ll1lllll_l1_ in range(len(group)):
					render = group[l1ll1ll1lllll_l1_][l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ渵")]
					if l11ll1_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ渶") in list(render.keys()):
						l1lllll_l1_ = render[l11ll1_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ渷")][l11ll1_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ游")][l11ll1_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ渹")][l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ渺")]
						l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡹ࠵࠶࠲࠷ࠩ渻"),l11ll1_l1_ (u"ࠪࠪࠬ渼"))
						title = render[l11ll1_l1_ (u"ࠫࡹࡵ࡯࡭ࡶ࡬ࡴࠬ渽")]
						title = title.replace(l11ll1_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠࠨ渾"),l11ll1_l1_ (u"࠭ࠧ渿"))
						if l11ll1_l1_ (u"ࠧฦิส่ฮࠦวๅใ็ฮึ࠭湀") in title: continue
						if l11ll1_l1_ (u"ࠨไสส๊ฯࠠหึ฽๎้࠭湁") in title:
							title = l11ll1_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ湂")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠪฮึะ๊ษࠢะือ࠭湃") in title: continue
						title = title.replace(l11ll1_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠡࠩ湄"),l11ll1_l1_ (u"ࠬ࠭湅"))
						if l11ll1_l1_ (u"࠭ࡒࡦ࡯ࡲࡺࡪ࠭湆") in title: continue
						if l11ll1_l1_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩ湇") in title:
							title = l11ll1_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ湈")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠩࡖࡳࡷࡺࠠࡣࡻࠪ湉") in title: continue
						l1ll1l1lllll1_l1_.append(escapeUNICODE(title))
						l1ll1l1l1lll1_l1_.append(l1lllll_l1_)
		if not l1lll1l1l_l1_: l1ll1ll1l11ll_l1_ = l11ll1_l1_ (u"ࠪࠫ湊")
		else:
			l1ll1l1lllll1_l1_ = [l11ll1_l1_ (u"ࠫอี่็ࠢไ่ฯืࠧ湋"),l1lll1l1l_l1_]+l1ll1l1lllll1_l1_
			l1ll1l1l1lll1_l1_ = [l11ll1_l1_ (u"ࠬ࠭湌"),l1lllll11l_l1_]+l1ll1l1l1lll1_l1_
			l1ll1ll1lll1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊แๅฬิࠫ湍"),l1ll1l1lllll1_l1_)
			if l1ll1ll1lll1l_l1_ == -1: return
			l1ll1ll1l11ll_l1_ = l1ll1l1l1lll1_l1_[l1ll1ll1lll1l_l1_]
		if l1ll1ll1l11ll_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1ll1l11ll_l1_
		elif l1ll1l1llll11_l1_: l11l111_l1_ = l111lll_l1_+l1ll1l1llll11_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡬ࡩ࡭ࡶࡨࡶ࠲ࡪࡲࡰࡲࡧࡳࡼࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡶࡩࡨࡺࡩࡰࡰࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡫ࡩࠤࠬࡘࡥ࡮ࡱࡹࡩࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠧ࠭ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠬࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡗࡴࡸࡴࠡࡤࡼࠫ࠱࠭ࡓࡰࡴࡷࠤࡧࡿ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡺࡩࡵ࡮ࡨࠤࡂࠦࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢࡵ࠱࠲࠵࠺ࠬ࠲ࠧࠧࠩࠬࠎࠎࠏࠉࠊ࡫ࡩࠤ࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹࡥࡢࡴࡦ࡬࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡰࡴࡷࠤࡧࡿ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩࠪࠌࠌࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࡡࡶࡳࡷࡺ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠤࠥࠦ湎")
	ITEMS(l11l111_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ拳")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬ拴")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ拵"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11111_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1ll1lllll111_l1_(url)
	elif mode==314: results = l1llll1ll_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ拶"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ拷"),l11ll1_l1_ (u"ࠪࠫ拸"),319,l11ll1_l1_ (u"ࠫࠬ拹"),l11ll1_l1_ (u"ࠬ࠭拺"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ拻"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拼"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึ࠭拽"),l11ll1_l1_ (u"ࠩࠪ拾"),114,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ拿"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ挀"),l11ll1_l1_ (u"ࠬ࠭持"),l11ll1_l1_ (u"࠭ࠧ挂"),l11ll1_l1_ (u"ࠧࠨ挃"),l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭挄"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡦࡰࡸࡰ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭挅"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ挆"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ指"),l11ll1_l1_ (u"ࠬ࠭挈"),9999)
	items = re.findall(l11ll1_l1_ (u"࠭࠼ࡩ࠷ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠺ࡄࠧ按"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11ll1_l1_ (u"ࠧࠡࠩ挊"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ挋"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ挌")+l111l1_l1_+title,l11l1l_l1_,314,l11ll1_l1_ (u"ࠪࠫ挍"),l11ll1_l1_ (u"ࠫࠬ挎"),str(seq+1))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ挏"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ挐")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆไส฻฾ࠦิ่ำࠪ挑"),l11l1l_l1_,314,l11ll1_l1_ (u"ࠨࠩ挒"),l11ll1_l1_ (u"ࠩࠪ挓"),l11ll1_l1_ (u"ࠪ࠴ࠬ挔"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ挕"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挖"),l11ll1_l1_ (u"࠭ࠧ挗"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡅࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡇࡄࠧ挘"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ挙")+l1lllll_l1_
		#title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ挚"))
		#url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡅ࡬ࡱࡦࡔ࡯ࡸ࠱ࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠳ࡶࡨࡱࠩ挛")
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ挜"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ挝")+l111l1_l1_+title,l1lllll_l1_,311)
	return html
def l1llll1ll_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ挞"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ挟"),l11ll1_l1_ (u"ࠨࠩ挠"),l11ll1_l1_ (u"ࠩࠪ挡"),l11ll1_l1_ (u"ࠪࠫ挢"),l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡍࡃࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ挣"))
	html = response.content
	if seq==l11ll1_l1_ (u"ࠬ࠶ࠧ挤"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡢࡤ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ挥"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ挦"),block,re.DOTALL)
		for l1lllll_l1_,name,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ挧")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ挨"))
			name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ挩"))
			title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ挪")+name+l11ll1_l1_ (u"ࠬ࠯ࠧ挫")
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ挬"),l111l1_l1_+title,l1lllll_l1_,312)
	elif seq in [l11ll1_l1_ (u"ࠧ࠲ࠩ挭"),l11ll1_l1_ (u"ࠨ࠴ࠪ挮"),l11ll1_l1_ (u"ࠩ࠶ࠫ振")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡁ࡮࠵࠿࠰࠭ࡃ࠮ࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡭ࡩࠪ挰"),html,re.DOTALL)
		l1ll1llll1lll_l1_ = int(seq)-1
		block = l1l1l11_l1_[l1ll1llll1lll_l1_]
		if seq==l11ll1_l1_ (u"ࠫ࠶࠭挱"): items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭挲"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ挳"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,name in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ挴")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ挵")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ挶"))
			name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ挷"))
			title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ挸")+name+l11ll1_l1_ (u"ࠬ࠯ࠧ挹")
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭挺"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	elif seq in [l11ll1_l1_ (u"ࠧ࠵ࠩ挻"),l11ll1_l1_ (u"ࠨ࠷ࠪ挼"),l11ll1_l1_ (u"ࠩ࠹ࠫ挽")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡁ࡮࠵࠿࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ挾"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1l11_l1_[seq]
		items = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿࠮ࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ挿"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,l1l1ll1111l_l1_,title,l1ll1lll1l1_l1_ in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ捀")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ捁")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ捂"))
			l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ捃"))
			l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.strip(l11ll1_l1_ (u"ࠩࠣࠫ捄"))
			if l1l1ll1111l_l1_: name = l1l1ll1111l_l1_
			else: name = l1ll1lll1l1_l1_
			title = title+l11ll1_l1_ (u"ࠪࠤ࠭࠭捅")+name+l11ll1_l1_ (u"ࠫ࠮࠭捆")
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ捇"),l111l1_l1_+title,l1lllll_l1_,312,l1lll1_l1_)
	return
def l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ捈"),url,l11ll1_l1_ (u"ࠧࠨ捉"),l11ll1_l1_ (u"ࠨࠩ捊"),l11ll1_l1_ (u"ࠩࠪ捋"),l11ll1_l1_ (u"ࠪࠫ捌"),l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ捍"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡢࡰࡺ࠰࡬ࡪࡧࡤࡪࡰࡪࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡰࡴࡧࡴ࠮ࡴ࡬࡫࡭ࡺࠧ捎"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	if l11ll1_l1_ (u"࠭ࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪ࠭捏") in block:
		items = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄࡩࡡࡵࡵࡸࡱ࠲ࡳ࡯ࡣ࡫࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭捐"),block,re.DOTALL)
		if items:
			for l1lll1_l1_,l1lllll_l1_,title,count in items:
				l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ捑")+l1lll1_l1_
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ捒")+l1lllll_l1_
				count = count.replace(l11ll1_l1_ (u"ࠪࠤฬ๊ี้ฬํอ࠿ࠦࠧ捓"),l11ll1_l1_ (u"ࠫ࠿࠭捔"))
				title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ捕"))
				title = title+l11ll1_l1_ (u"࠭ࠠࠩࠩ捖")+count+l11ll1_l1_ (u"ࠧࠪࠩ捗")
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ捘"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	else:
		items = re.findall(l11ll1_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ捙"),block,re.DOTALL)
		for l1lllll_l1_,title,l1ll1lllll11l_l1_,l1l11lll1_l1_ in items:
			if title==l11ll1_l1_ (u"ࠪࠫ捚") or l1ll1lllll11l_l1_==l11ll1_l1_ (u"ࠫࠬ捛"): continue
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ捜")+l1lllll_l1_
			title = title+l11ll1_l1_ (u"࠭ࠠࠩࠩ捝")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠧࠪࠩ捞")
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ损"),l111l1_l1_+title,l1lllll_l1_,312)
	if not items: l1llll1l_l1_(html)
	return
def l1llll1l_l1_(html):
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ捠"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ捡"),block,re.DOTALL)
	for l1lllll_l1_,title,name,count,l1l11lll1_l1_ in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࠭换")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ捣"))
		name = name.strip(l11ll1_l1_ (u"࠭ࠠࠨ捤"))
		title = title+l11ll1_l1_ (u"ࠧࠡࠪࠪ捥")+name+l11ll1_l1_ (u"ࠨࠫࠪ捦")
		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ捧"),l111l1_l1_+title,l1lllll_l1_,312,l11ll1_l1_ (u"ࠪࠫ捨"),l1l11lll1_l1_)
	return
def l1ll1lllll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ捩"),url,l11ll1_l1_ (u"ࠬ࠭捪"),l11ll1_l1_ (u"࠭ࠧ捫"),l11ll1_l1_ (u"ࠧࠨ捬"),l11ll1_l1_ (u"ࠨࠩ捭"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡙ࡅࡂࡔࡆࡌࡤࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ据"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡳ࠱࠶ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ捯"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l11111_l1_(url)
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭捰"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ捱")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ捲"))
		if l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠳ࠧ捳") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ捴"),l111l1_l1_+title,l1lllll_l1_,312)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ捵"),l111l1_l1_+title,l1lllll_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ捶"),url,l11ll1_l1_ (u"ࠫࠬ捷"),l11ll1_l1_ (u"ࠬ࠭捸"),l11ll1_l1_ (u"࠭ࠧ捹"),l11ll1_l1_ (u"ࠧࠨ捺"),l11ll1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭捻"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡥࡺࡪࡩࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ捼"),html,re.DOTALL)
	if not l1lllll_l1_: l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ捽"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ捾"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭捿"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ掀"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ掁"),l11ll1_l1_ (u"ࠨ࠭ࠪ掂"))
	l11llll1l1ll_l1_ = [l11ll1_l1_ (u"ࠩࠩࡸࡂࡧࠧ掃"),l11ll1_l1_ (u"ࠪࠪࡹࡃࡣࠨ掄"),l11ll1_l1_ (u"ࠫࠫࡺ࠽ࡴࠩ掅")]
	if l1ll_l1_:
		l1l11111l1l1_l1_ = [l11ll1_l1_ (u"่ࠬวาศࠪ掆"),l11ll1_l1_ (u"࠭ลึัสีࠥ࠵ࠠๆฮ็ำࠬ掇"),l11ll1_l1_ (u"ࠧๆไฺ฽ࠥอไึ๊อ๎ࠬ授")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣ࠱ࠥษฮหำࠣห้ฮอฬࠩ掉"), l1l11111l1l1_l1_)
		if l1l_l1_ == -1: return
	elif l11ll1_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙࡟ࠨ掊") in options: l1l_l1_ = 0
	elif l11ll1_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙࡟ࠨ掋") in options: l1l_l1_ = 1
	elif l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࡠࠩ掌") in options: l1l_l1_ = 2
	else: return
	type = l11llll1l1ll_l1_[l1l_l1_]
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭掍")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ掎"),url,l11ll1_l1_ (u"ࠧࠨ掏"),l11ll1_l1_ (u"ࠨࠩ掐"),l11ll1_l1_ (u"ࠩࠪ掑"),l11ll1_l1_ (u"ࠪࠫ排"),l11ll1_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ掓"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ掔"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ掕"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ掖"))
				name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ掗"))
				title = title+l11ll1_l1_ (u"ࠩࠣࠬࠬ掘")+name+l11ll1_l1_ (u"ࠪ࠭ࠬ掙")
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ掚"),l111l1_l1_+title,l1lllll_l1_,313,l1lll1_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡹࡪ࠾࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿ࠫ掛"),block,re.DOTALL)
			for l1lllll_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ掜"))
				name = name.strip(l11ll1_l1_ (u"ࠧࠡࠩ掝"))
				title = title+l11ll1_l1_ (u"ࠨࠢࠫࠫ掞")+name+l11ll1_l1_ (u"ࠩࠬࠫ掟")
				addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ掠"),l111l1_l1_+title,l1lllll_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ⺯")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ⺰")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l11l_l1_ = l1l1lll_l1_[script_name][2]
l1l1ll1l1ll_l1_ = l1l1lll_l1_[script_name][3]
#l1l1lll111l_l1_  = l1l1lll_l1_[script_name][4]
#l1l1lll111l_l1_  = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==20: results = l1l1ll1ll11_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l11111_l1_(url,l1l1111_l1_)
	elif mode==23: results = l1llll1l_l1_(url,l1l1111_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l1ll11111_l1_(url)
	elif mode==27: results = l1l1ll1ll_l1_(url)
	elif mode==28: results = l1l1ll1llll_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l1ll1ll11_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺱"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฿ัษ์ࠪ⺲"),l11l1l_l1_,21,l11ll1_l1_ (u"࠭ࠧ⺳"),l11ll1_l1_ (u"ࠧ࠲࠲࠴ࠫ⺴"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⺵"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠪ⺶"),l11lllll1l_l1_,21,l11ll1_l1_ (u"ࠪࠫ⺷"),l11ll1_l1_ (u"ࠫ࠶࠶࠱ࠨ⺸"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺹"),l111l1_l1_+l11ll1_l1_ (u"࠭แศำึํࠬ⺺"),l1l1ll1l11l_l1_,21,l11ll1_l1_ (u"ࠧࠨ⺻"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⺼"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺽"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⺾"),l1l1ll1l1ll_l1_,21,l11ll1_l1_ (u"ࠫࠬ⺿"),l11ll1_l1_ (u"ࠬ࠷࠰࠲ࠩ⻀"))
	return
def l1l1ll1llll_l1_():
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ⻁"),l111l1_l1_+l11ll1_l1_ (u"ฺࠧำห๎ࠬ⻂"),l11l1l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⻃"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠪ⻄"),l11lllll1l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⻅"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆอัิ๋ࠪ⻆"),l1l1ll1l11l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ⻇"),l111l1_l1_+l11ll1_l1_ (u"࠭แศำึํࠥ࠸ࠧ⻈"),l1l1ll1l1ll_l1_,27)
	return
def MENU(l1l1lll1111_l1_):
	script_name = l1l1lll1111_l1_
	if l1l1lll1111_l1_==l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⻉"): l1l1lll1111_l1_ = l11l1l_l1_
	elif l1l1lll1111_l1_==l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⻊"): l1l1lll1111_l1_ = l11lllll1l_l1_
	else: script_name = l11ll1_l1_ (u"ࠩࠪ⻋")
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(l1l1lll1111_l1_)
	if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡥࡷ࠭⻌") or script_name==l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⻍"):
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⻎")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢะห้๐ษࠨ⻏")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣวาีหࠨ⻐")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศฮฬะ์ࠪ⻑")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"ࠩหฯࠥำ๊ࠡฤํࠤๆ๐ไๆࠩ⻒")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"ࠪวๆ๊วๆࠩ⻓")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ⻔")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"ࠬฮัศ็ฯࠫ⻕")
	elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡥ࡯ࠩ⻖") or script_name==l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⻗"):
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡ࡫ࡱࠤࡸ࡯ࡴࡦࠩ⻘")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡈࡻࡲࡳࡧࡱࡸࠬ⻙")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡒࡡࡵࡧࡶࡸࠬ⻚")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡁ࡭ࡲ࡫ࡥࡧ࡫ࡴࠨ⻛")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"ࠬࡒࡩࡷࡧࠣ࡭ࡋ࡯࡬࡮ࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪ⻜")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"࠭ࡍࡰࡸ࡬ࡩࡸ࠭⻝")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⻞")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"ࠨࡕ࡫ࡳࡼࡹࠧ⻟")
	elif l1ll1l1ll11_l1_ in [l11ll1_l1_ (u"ࠩࡩࡥࠬ⻠"),l11ll1_l1_ (u"ࠪࡪࡦ࠸ࠧ⻡")]:
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"ࠫัูสอ๊ࠣำึࠦำศ໎อࠫ⻢")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦฬศำ໏ࠫ⻣")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠระิ໐๋࠭⻤")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"ࠧิำํห้ࠦ࠭ࠡษ็ๅออࠧ⻥")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"ࠨ຀ัุุࠥๆะ้ࠣห๏ࠦแ๋ๆ่ࠫ⻦")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"ࠩไ๎้๋ࠧ⻧")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"้ࠪํู๊ใ๋ࠪ⻨")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠧ⻩")
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻪"),l111l1_l1_+l1l1ll111l1_l1_,l1l1lll1111_l1_,29,l11ll1_l1_ (u"࠭ࠧ⻫"),l11ll1_l1_ (u"ࠧࠨ⻬"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⻭"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⻮"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⻯")+l111l1_l1_+l1l1ll11l1l_l1_,l1l1lll1111_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⻰"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⻱"),l11ll1_l1_ (u"࠭ࠧ⻲"),9999)
	menu = [l11ll1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⻳"),l11ll1_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⻴"),l11ll1_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⻵")]
	html = OPENURL_CACHED(l1llllll_l1_,l1l1lll1111_l1_+l11ll1_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩ⻶"),l11ll1_l1_ (u"ࠫࠬ⻷"),l11ll1_l1_ (u"ࠬ࠭⻸"),l11ll1_l1_ (u"࠭ࠧ⻹"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⻺"))
	l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠨࡤࡸࡸࡹࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬ࠳ࡈࡵ࡮ࡵࡣࡦࡸࠬ⻻"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⻼"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if any(value in l1lllll_l1_ for value in menu):
				url = l1l1lll1111_l1_+l1lllll_l1_
				if l11ll1_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⻽") in l1lllll_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻾"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⻿")+l111l1_l1_+l1l1ll1111l_l1_,url,22,l11ll1_l1_ (u"࠭ࠧ⼀"),l11ll1_l1_ (u"ࠧ࠲࠲࠳ࠫ⼁"))
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼂"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⼃")+l111l1_l1_+l1ll1lll1l1_l1_,url,22,l11ll1_l1_ (u"ࠪࠫ⼄"),l11ll1_l1_ (u"ࠫ࠶࠶࠱ࠨ⼅"))
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼆"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼇")+l111l1_l1_+l1l1ll111ll_l1_,url,22,l11ll1_l1_ (u"ࠧࠨ⼈"),l11ll1_l1_ (u"ࠨ࠴࠳࠵ࠬ⼉"))
				elif l11ll1_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⼊") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼋"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⼌")+l111l1_l1_+l1l1ll11l11_l1_,url,22,l11ll1_l1_ (u"ࠬ࠭⼍"),l11ll1_l1_ (u"࠭࠱࠱࠲ࠪ⼎"))
				elif l11ll1_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⼏") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼐"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⼑")+l111l1_l1_+l1l1ll11lll_l1_,url,25,l11ll1_l1_ (u"ࠪࠫ⼒"),l11ll1_l1_ (u"ࠫ࠶࠶࠱ࠨ⼓"))
				elif l11ll1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⼔") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼕"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⼖")+l111l1_l1_+l1l1ll11ll1_l1_,url,22,l11ll1_l1_ (u"ࠨࠩ⼗"),l11ll1_l1_ (u"ࠩ࠴࠴࠶࠭⼘"))
	return html
def l1l1ll11111_l1_(url):
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠪࠫ⼙"),l11ll1_l1_ (u"ࠫࠬ⼚"),l11ll1_l1_ (u"ࠬ࠭⼛"),l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡕࡔࡋࡆࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⼜"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠳ࡴࡰࡱ࡯ࡷ࠲࡮ࡥࡢࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡸ࡯ࡣ࠮ࡤࡲࡨࡾ࠭⼝"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	title = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ⼞"),block,re.DOTALL)[0]
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼟"),l111l1_l1_+title,url,22,l11ll1_l1_ (u"ࠪࠫ⼠"),l11ll1_l1_ (u"ࠫ࠶࠶࠱ࠨ⼡"))
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⼢"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼣"),l111l1_l1_+title,l1lllll_l1_,23,l11ll1_l1_ (u"ࠧࠨ⼤"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⼥"))
	return
def l11111_l1_(url,l1l1111_l1_):
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	type = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ⼦"))[-1]
	l1l1l1lll1l_l1_ = str(int(l1l1111_l1_)//100)
	l1l1111_l1_ = str(int(l1l1111_l1_)%100)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⼧"),l11ll1_l1_ (u"ࠫࠬ⼨"),url, type)
	if type==l11ll1_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⼩") and l1l1111_l1_==l11ll1_l1_ (u"࠭࠰ࠨ⼪"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠧࠨ⼫"),l11ll1_l1_ (u"ࠨࠩ⼬"),l11ll1_l1_ (u"ࠩࠪ⼭"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⼮"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯࠱ࡧࡵࡤࡺࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠪ⼯"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠬ࠳࠰࠿ࠪࡀ࠱࠮ࡄ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⼰"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
			l1lll1_l1_ = l1l1lll1111_l1_ + QUOTE(l1lll1_l1_)
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼱"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠧ࠱࠳ࠪ⼲"))
	l1l1l1llll1_l1_=0
	if type==l11ll1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⼳"): category=l11ll1_l1_ (u"ࠩ࠶ࠫ⼴")
	if type==l11ll1_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⼵"): category=l11ll1_l1_ (u"ࠫ࠺࠭⼶")
	if type==l11ll1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⼷"): category=l11ll1_l1_ (u"࠭࠷ࠨ⼸")
	if type in [l11ll1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⼹"),l11ll1_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⼺"),l11ll1_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⼻")] and l1l1111_l1_!=l11ll1_l1_ (u"ࠪ࠴ࠬ⼼"):
		l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧ࠲ࡔࡦ࡭ࡥࡪࡰࡪࡍࡹ࡫࡭ࡀࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⼽")+category+l11ll1_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⼾")+l1l1111_l1_+l11ll1_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡱࡵࡨࡪࡸࡢࡺ࠿ࠪ⼿")+l1l1l1lll1l_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ⽀"),l11ll1_l1_ (u"ࠨࠩ⽁"),l11ll1_l1_ (u"ࠩࠪ⽂"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⽃"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⽄"),l11ll1_l1_ (u"ࠬ࠭⽅"),l111lll_l1_, html)
		items = re.findall(l11ll1_l1_ (u"࠭ࠢࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠰ࡅࠢࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⽆"),html,re.DOTALL)
		for id,title,l1lll1_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠪ⽇"),l11ll1_l1_ (u"ࠨࠩ⽈"))
			title = title.replace(l11ll1_l1_ (u"ࠩࠥࠫ⽉"),l11ll1_l1_ (u"ࠪࠫ⽊"))
			l1l1l1llll1_l1_ += 1
			l1lllll_l1_ = l1l1lll1111_l1_ + l11ll1_l1_ (u"ࠫ࠴࠭⽋") + type + l11ll1_l1_ (u"ࠬ࠵ࡃࡰࡰࡷࡩࡳࡺ࠯ࠨ⽌") + id
			l1lll1_l1_ = l1l1lll1111_l1_ + QUOTE(l1lll1_l1_)
			if type==l11ll1_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⽍"): addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⽎"),l111l1_l1_+title,l1lllll_l1_,24,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠨ࠲࠴ࠫ⽏"))
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽐"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠪ࠴࠶࠭⽑"))
	if type==l11ll1_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⽒"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l1lll1111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡏ࡮ࡥࡧࡻࡃࡵࡧࡧࡦ࠿ࠪ⽓")+l1l1111_l1_,l11ll1_l1_ (u"࠭ࠧ⽔"),l11ll1_l1_ (u"ࠧࠨ⽕"),l11ll1_l1_ (u"ࠨࠩ⽖"),l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠵ࡵࡨࠬ⽗"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࠭ࡥࡧࡰࡳ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠳ࡤࡦ࡯ࡲࠫ⽘"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭⽙"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1l1l1llll1_l1_ += 1
			l1lll1_l1_ = l1l1lll1111_l1_ + l1lll1_l1_
			l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⽚"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l11ll1_l1_ (u"࠭࠱࠱࠳ࠪ⽛"))
	if l1l1l1llll1_l1_>20:
		title=l11ll1_l1_ (u"ࠧึใะอࠥ࠭⽜")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡧࡱࠫ⽝"): title = l11ll1_l1_ (u"ࠩࡓࡥ࡬࡫ࠠࠨ⽞")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡪࡦ࠭⽟"): title = l11ll1_l1_ (u"ฺࠫ็อ่ࠢࠪ⽠")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⽡"): title = l11ll1_l1_ (u"࠭ีโฯ๊ࠤࠬ⽢")
		for l1l1ll1l1l1_l1_ in range(1,11) :
			if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
				l1l1l1lllll_l1_ = l11ll1_l1_ (u"ࠧ࠱ࠩ⽣")+str(l1l1ll1l1l1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⽤"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,22,l11ll1_l1_ (u"ࠩࠪ⽥"),l1l1l1lll1l_l1_+l1l1l1lllll_l1_[-2:])
	return
def l1llll1l_l1_(url,l1l1111_l1_):
	if not l1l1111_l1_: l1l1111_l1_ = 0
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	l1l1lll111l_l1_ = l1l1ll1l111_l1_(url)
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	parts = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ⽦"))
	id,type = parts[-1],parts[3]
	l1l1l1lll1l_l1_ = str(int(l1l1111_l1_)//100)
	l1l1111_l1_ = str(int(l1l1111_l1_)%100)
	l1l1l1llll1_l1_ = 0
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⽧"),l11ll1_l1_ (u"ࠬ࠭⽨"),url, type)
	if type==l11ll1_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⽩"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠧࠨ⽪"),l11ll1_l1_ (u"ࠨࠩ⽫"),l11ll1_l1_ (u"ࠩࠪ⽬"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⽭"))
		items = re.findall(l11ll1_l1_ (u"ࠫࡈࡵ࡭࡮ࡧࡱࡸࡤࡶࡡ࡯ࡧ࡯ࡣࡎࡺࡥ࡮࠰࠭ࡃࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࡯࠮ࠬࡁࡹࡥࡷࠦࡩ࡯ࡶࡨࡶࡤࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࡢࠧࠨ⽮"),html,re.DOTALL)
		title = l11ll1_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ⽯")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡥ࡯ࠩ⽰"): title = l11ll1_l1_ (u"ࠧࠡ࠯ࠣࡉࡵ࡯ࡳࡰࡦࡨࠤࠬ⽱")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡨࡤࠫ⽲"): title = l11ll1_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ⽳")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡪࡦ࠸ࠧ⽴"): title = l11ll1_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⽵")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡࠨ⽶"): l1l1ll1ll1l_l1_ = l11ll1_l1_ (u"࠭ࠧ⽷")
		else: l1l1ll1ll1l_l1_ = l1ll1l1ll11_l1_
		l1l1lll11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲࡁࠧ࠮࠮ࠫࡁࠬࠬࡡ࠭࠮ࠫࡁ࡟ࠫࡤ࠯ࠨ࠯ࠬࡂ࠭ࠧࡄࠧ⽸"),html,re.DOTALL)
		for name,count,l1lll1_l1_,l1lllll_l1_ in items:
			for l1ll1l1_l1_ in range(int(count),0,-1):
				l1l11ll11_l1_ = l1lll1_l1_ + l1l1ll1ll1l_l1_ + id + l11ll1_l1_ (u"ࠨ࠱ࠪ⽹") + str(l1ll1l1_l1_) + l11ll1_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ⽺")
				#l1lll11111l_l1_ = l1l1lll11ll_l1_[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"ࠪ࠳࠱࠭⽻")+str(l1ll1l1_l1_)+l11ll1_l1_ (u"ࠫ࠱࠭⽼")+str(l1ll1l1_l1_)+l11ll1_l1_ (u"ࠬࡥࠧ⽽")+l1l1lll11ll_l1_[0][2]
				l1l1ll1111l_l1_ = name + title + str(l1ll1l1_l1_)
				l1l1ll1111l_l1_ = unescapeHTML(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⽾"),l111l1_l1_+l1l1ll1111l_l1_,url,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠧࠨ⽿"),str(l1ll1l1_l1_))
	elif type==l11ll1_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⾀"):
		l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡒࡤ࡫ࡪ࡯࡮ࡨࡃࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡎࡺࡥ࡮ࡁ࡬ࡨࡂ࠭⾁")+str(id)+l11ll1_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⾂")+l1l1111_l1_+l11ll1_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬ࡯ࡳࡦࡨࡶࡧࡿ࠽࠲ࠩ⾃")
		html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭⾄"),l11ll1_l1_ (u"࠭ࠧ⾅"),l11ll1_l1_ (u"ࠧࠨ⾆"),l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭⾇"))
		items = re.findall(l11ll1_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛࡯ࡤࡦࡱࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡅ࡫ࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⾈"),html,re.DOTALL)
		title = l11ll1_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦࠧ⾉")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫࡪࡴࠧ⾊"): title = l11ll1_l1_ (u"ࠬࠦ࠭ࠡࡇࡳ࡭ࡸࡵࡤࡦࠢࠪ⾋")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡦࡢࠩ⾌"): title = l11ll1_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ⾍")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡨࡤ࠶ࠬ⾎"): title = l11ll1_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ⾏")
		for l1ll1l1_l1_,l1lll1_l1_,l1lllll_l1_,desc,name in items:
			l1l1l1llll1_l1_ += 1
			l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
			#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
			name = escapeUNICODE(name)
			l1l1ll1111l_l1_ = name + title + str(l1ll1l1_l1_)
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⾐"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠫࠬ⾑"),str(l1l1l1llll1_l1_))
	elif type==l11ll1_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⾒"):
		if l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺࠧ⾓") in url and l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⾔") not in url:
			l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿ࠪ⾕")+str(id)+l11ll1_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ⾖")+l1l1111_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠴ࠬ⾗")
			html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⾘"),l11ll1_l1_ (u"ࠬ࠭⾙"),l11ll1_l1_ (u"࠭ࠧ⾚"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠵ࡵࡨࠬ⾛"))
			items = re.findall(l11ll1_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⾜"),html,re.DOTALL)
			for l1lll1_l1_,l1lllll_l1_,name,title in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = name + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭⾝") + title
				l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ⾞"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⾟"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠬ࠭⾠"),str(l1l1l1llll1_l1_))
		elif l11ll1_l1_ (u"࠭ࡃ࡭࡫ࡳࡷࠬ⾡") in url:
			l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾࠲ࠩࡴࡦ࡭ࡥ࠾ࠩ⾢")+l1l1111_l1_+l11ll1_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠳࠸ࠫ⾣")
			html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ⾤"),l11ll1_l1_ (u"ࠪࠫ⾥"),l11ll1_l1_ (u"ࠫࠬ⾦"),l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠴ࡵࡪࠪ⾧"))
			items = re.findall(l11ll1_l1_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⾨"),html,re.DOTALL)
			for l1lll1_l1_,title,l1lllll_l1_ in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ⾩"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⾪"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠩࠪ⾫"),str(l1l1l1llll1_l1_))
		elif l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⾬") in url:
			if l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠶ࠨ⾭") in url:
				l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ⾮")+l1l1111_l1_+l11ll1_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠶ࠨ⾯")
				html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ⾰"),l11ll1_l1_ (u"ࠨࠩ⾱"),l11ll1_l1_ (u"ࠩࠪ⾲"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠺ࡺࡨࠨ⾳"))
			elif l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠴ࠨ⾴") in url:
				l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ⾵")+l1l1111_l1_+l11ll1_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠴ࠨ⾶")
				html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ⾷"),l11ll1_l1_ (u"ࠨࠩ⾸"),l11ll1_l1_ (u"ࠩࠪ⾹"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠻ࡺࡨࠨ⾺"))
			items = re.findall(l11ll1_l1_ (u"ࠫࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙ࡳ࡮ࡩࡥࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⾻"),html,re.DOTALL)
			for l1lll1_l1_,l1lllll_l1_,name,title in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = name + l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ⾼") + title
				l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ⾽"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⾾"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠨࠩ⾿"),str(l1l1l1llll1_l1_))
	if type==l11ll1_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⿀") or type==l11ll1_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⿁"):
		if l1l1l1llll1_l1_>25:
			title=l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ⿂")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡫࡮ࠨ⿃"): title = l11ll1_l1_ (u"࠭ࠠࡑࡣࡪࡩࠥ࠭⿄")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡧࡣࠪ⿅"): title = l11ll1_l1_ (u"ࠨุࠢๅาํࠠࠨ⿆")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡩࡥ࠷࠭⿇"): title = l11ll1_l1_ (u"ࠪࠤฺ็อ่ࠢࠪ⿈")
			for l1l1ll1l1l1_l1_ in range(1,11):
				if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
					l1l1l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࠵࠭⿉")+str(l1l1ll1l1l1_l1_)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿊"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,23,l11ll1_l1_ (u"࠭ࠧ⿋"),l1l1l1lll1l_l1_+l1l1l1lllll_l1_[-2:])
	return
def PLAY(url,l1ll1l1_l1_):
	l1l1lll111l_l1_ = l1l1ll1l111_l1_(url)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠧࠨ⿌"),l11ll1_l1_ (u"ࠨࠩ⿍"),l11ll1_l1_ (u"ࠩࠪ⿎"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⿏"))
	# l1l11_l1_ l1llll111_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩ࡫࡯࠾ࠤࠫ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࡡࠬࠬ࠳࠰࠿ࠪࠤࡁࠫ⿐"),html,re.DOTALL)
	if items:
		l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
		parts = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ⿑"))
		id,type = parts[-1],parts[3]
		l1lllll_l1_ = items[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"࠭࠯࠭ࠩ⿒")+l1ll1l1_l1_+l11ll1_l1_ (u"ࠧ࠭ࠩ⿓")+l1ll1l1_l1_+l11ll1_l1_ (u"ࠨࡡࠪ⿔")+items[0][2]
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ⿕"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l11_l1_ l1111l1l_l1_ url
	items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࠬࠬࡡ࠴࠮ࠫࡁࠬࠦࠬ⿖"),html,re.DOTALL)
	if items:
		l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
		parts = url.split(l11ll1_l1_ (u"ࠫ࠴࠭⿗"))
		id,type = parts[-1],parts[3]
		l1lllll_l1_ = items[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"ࠬ࠵ࠧ⿘")+l1ll1l1_l1_+items[0][2]
		l1lll11l_l1_.append(l11ll1_l1_ (u"࠭࡭ࡱ࠶ࠣࡹࡷࡲࠧ⿙"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l11_l1_ l1111l1l_l1_ src
	items = re.findall(l11ll1_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⿚"),html,re.DOTALL)
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࠱࠲ࠫ⿛"),l11ll1_l1_ (u"ࠩ࠲ࠫ⿜"))
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪࡱࡵ࠺ࠠࡴࡴࡦࠫ⿝"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l1ll1lll1_l1_ l1111l1l_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⿞"),html,re.DOTALL)
	if items:
		l1lllll_l1_ = items[int(l1ll1l1_l1_)-1]
		l1lllll_l1_ = l1l1lll111l_l1_+QUOTE(l1lllll_l1_)
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠬࡳࡰ࠵ࠢࡤࡨࡩࡸࡥࡴࡵࠪ⿟"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l1ll1lll1_l1_ l1l1lll1l11_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"࠭ࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿠"),html,re.DOTALL)
	if items:
		l1lllll_l1_ = items[int(l1ll1l1_l1_)-1]
		l1lllll_l1_ = l1l1lll111l_l1_+QUOTE(l1lllll_l1_)
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠧ࡮ࡲ࠶ࠤࡦࡪࡤࡳࡧࡶࡷࠬ⿡"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l_l1_
	if len(l1llll_l1_)==1: l1lllll_l1_ = l1llll_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ⿢"), l1lll11l_l1_)
		if l1l_l1_ == -1 : return
		l1lllll_l1_ = l1llll_l1_[l1l_l1_]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⿣"))
	return
def l1l1ll1l111_l1_(url):
	if l11l1l_l1_ in url: l1ll111l111_l1_ = l11l1l_l1_
	elif l11lllll1l_l1_ in url: l1ll111l111_l1_ = l11lllll1l_l1_
	elif l1l1ll1l11l_l1_ in url: l1ll111l111_l1_ = l1l1ll1l11l_l1_
	elif l1l1ll1l1ll_l1_ in url: l1ll111l111_l1_ = l1l1ll1l1ll_l1_
	else: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࠫ⿤")
	return l1ll111l111_l1_
def l1l1lll11l1_l1_(url):
	if   l11l1l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠫࡦࡸࠧ⿥")
	elif l11lllll1l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠬ࡫࡮ࠨ⿦")
	elif l1l1ll1l11l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"࠭ࡦࡢࠩ⿧")
	elif l1l1ll1l1ll_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠧࡧࡣ࠵ࠫ⿨")
	else: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠨࠩ⿩")
	return l1ll1l1ll11_l1_
def l1l1ll1ll_l1_(url):
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	l111lll_l1_ = url + l11ll1_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡎ࡬ࡺࡪ࠭⿪")
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⿫"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⿬"),l11ll1_l1_ (u"ࠬ࠭⿭"),l11ll1_l1_ (u"࠭ࠧ⿮"),l11ll1_l1_ (u"ࠧࠨ⿯"),l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ⿰"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿱"),html,re.DOTALL)
	l11l111_l1_ = items[0]
	PLAY_VIDEO(l11l111_l1_,script_name,l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⿲"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭⿳"),l11ll1_l1_ (u"ࠬ࠱ࠧ⿴"))
	if l1ll_l1_:
		l1ll1ll1l1_l1_ = [ l11l1l_l1_ , l11lllll1l_l1_ , l1l1ll1l11l_l1_ , l1l1ll1l1ll_l1_ ]
		l1l11l11l_l1_ = [ l11ll1_l1_ (u"ู࠭าสํࠫ⿵") , l11ll1_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ⿶") , l11ll1_l1_ (u"ࠨใสีุ๏ࠧ⿷") , l11ll1_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ⿸") ]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็่฿ฯࠠศๆ่๊ฬูศส࠼ࠪ⿹"), l1l11l11l_l1_)
		if l1l_l1_ == -1 : return
		l1l1l1l1_l1_ = l1ll1ll1l1_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠫࡤࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࡣࠬ⿺") in options: l1l1l1l1_l1_ = l11l1l_l1_
		elif l11ll1_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍࡥࠧ⿻") in options: l1l1l1l1_l1_ = l11lllll1l_l1_
		else: l1l1l1l1_l1_ = l11ll1_l1_ (u"࠭ࠧ⿼")
	if not l1l1l1l1_l1_: return
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(l1l1l1l1_l1_)
	l111lll_l1_ = l1l1l1l1_l1_ + l11ll1_l1_ (u"ࠢ࠰ࡊࡲࡱࡪ࠵ࡓࡦࡣࡵࡧ࡭ࡅࡳࡦࡣࡵࡧ࡭ࡹࡴࡳ࡫ࡱ࡫ࡂࠨ⿽") + l1111ll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⿾"),l11ll1_l1_ (u"ࠩࠪ⿿"),l1ll1l1ll11_l1_,l111lll_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ　"),l11ll1_l1_ (u"ࠫࠬ、"),l11ll1_l1_ (u"ࠬ࠭。"),l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ〃"))
	items = re.findall(l11ll1_l1_ (u"ࠧࠣࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡄࡣࡷࡩ࡬ࡵࡲࡺࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠫ〄"),html,re.DOTALL)
	if items:
		for l1lll1_l1_,category,id,title in items:
			#if category in [l11ll1_l1_ (u"ࠨ࠵ࠪ々"),l11ll1_l1_ (u"ࠩ࠸ࠫ〆"),l11ll1_l1_ (u"ࠪ࠻ࠬ〇")]:
			if category in [l11ll1_l1_ (u"ࠫ࠸࠭〈"),l11ll1_l1_ (u"ࠬ࠽ࠧ〉")]:
				title = title.replace(l11ll1_l1_ (u"࠭࡜࡝ࠩ《"),l11ll1_l1_ (u"ࠧࠨ》"))
				title = title.replace(l11ll1_l1_ (u"ࠨࠤࠪ「"),l11ll1_l1_ (u"ࠩࠪ」"))
				if category==l11ll1_l1_ (u"ࠪ࠷ࠬ『"):
					type = l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ』")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬࡧࡲࠨ【"): name = l11ll1_l1_ (u"࠭ๅิๆึ่ࠥࡀࠠࠨ】")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡦࡰࠪ〒"): name = l11ll1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠼ࠣࠫ〓")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡩࡥࠬ〔"): name = l11ll1_l1_ (u"ࠪืึ๐วๅ๊ࠢหࠥࡀࠠࠨ〕")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫ࡫ࡧ࠲ࠨ〖"): name = l11ll1_l1_ (u"ูࠬั๋ษ็ࠤ์อࠠ࠻ࠢࠪ〗")
				elif category==l11ll1_l1_ (u"࠭࠵ࠨ〘"):
					type = l11ll1_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ〙")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡣࡵࠫ〚"): name = l11ll1_l1_ (u"ࠩไ๎้๋ࠠ࠻ࠢࠪ〛")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡩࡳ࠭〜"): name = l11ll1_l1_ (u"ࠫࡒࡵࡶࡪࡧࠣ࠾ࠥ࠭〝")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡࠨ〞"): name = l11ll1_l1_ (u"࠭แ๋ๆ่ࠤ࠿ࠦࠧ〟")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡧࡣ࠵ࠫ〠"): name = l11ll1_l1_ (u"ࠨใ็้ࠥํวࠡ࠼ࠣࠫ〡")
				elif category==l11ll1_l1_ (u"ࠩ࠺ࠫ〢"):
					type = l11ll1_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ〣")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫࡦࡸࠧ〤"): name = l11ll1_l1_ (u"ࠬฮั็ษ่ะࠥࡀࠠࠨ〥")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡥ࡯ࠩ〦"): name = l11ll1_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠡ࠼ࠣࠫ〧")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡨࡤࠫ〨"): name = l11ll1_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠥࡀࠠࠨ〩")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡪࡦ࠸〪ࠧ"): name = l11ll1_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠠ࠻〫ࠢࠪ")
				title = name + title
				l1lllll_l1_ = l1l1l1l1_l1_ + l11ll1_l1_ (u"ࠬ࠵ࠧ〬") + type + l11ll1_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰〭ࠩ") + id
				l1lll1_l1_ = QUOTE(l1lll1_l1_)
				l1lll1_l1_ = l1l1l1l1_l1_+l1lll1_l1_
				#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ〮"),l1lll1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ〯"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l11ll1_l1_ (u"ࠩ࠴࠴࠶࠭〰"))
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ〱"),l11ll1_l1_ (u"ࠫࠬ〲"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ〳"),,لا توجد نتائج للبحث')
	return
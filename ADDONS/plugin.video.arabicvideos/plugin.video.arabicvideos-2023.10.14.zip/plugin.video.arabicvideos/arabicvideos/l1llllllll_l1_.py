# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬᓡ")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡃ࠵ࡊࡢࠫᓢ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨᓣ"),l11ll1_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨᓤ"),l11ll1_l1_ (u"ࠨษ็ห็ูวๆࠩᓥ"),l11ll1_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭ᓦ"),l11ll1_l1_ (u"ࠪࡇࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧᓧ"),l11ll1_l1_ (u"ࠫࠬᓨ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l11111_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l1llll1_l1_(url,text)
	elif mode==694: results = l1l111_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᓩ"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧᓪ"),l11ll1_l1_ (u"ࠧࠨᓫ"),l11ll1_l1_ (u"ࠨࠩᓬ"),l11ll1_l1_ (u"ࠩࠪᓭ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᓮ"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓯ"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᓰ"),l11ll1_l1_ (u"࠭ࠧᓱ"),699,l11ll1_l1_ (u"ࠧࠨᓲ"),l11ll1_l1_ (u"ࠨࠩᓳ"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᓴ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᓵ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᓶ"),l11ll1_l1_ (u"ࠬ࠭ᓷ"),9999)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓸ"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᓹ")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩᓺ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠩࠪᓻ"),l11ll1_l1_ (u"ࠪࠫᓼ"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᓽ"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓾ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᓿ")+l111l1_l1_+l11ll1_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ᔀ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠨࠩᔁ"),l11ll1_l1_ (u"ࠩࠪᔂ"),l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᔃ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔄ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᔅ")+l111l1_l1_+l11ll1_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬᔆ"),l11l1l_l1_,691,l11ll1_l1_ (u"ࠧࠨᔇ"),l11ll1_l1_ (u"ࠨࠩᔈ"),l11ll1_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᔉ"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔊ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᔋ")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬᔌ"),l11l1l_l1_,691,l11ll1_l1_ (u"࠭ࠧᔍ"),l11ll1_l1_ (u"ࠧࠨᔎ"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᔏ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔐ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔑ"),l11ll1_l1_ (u"ࠫࠬᔒ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡹࡵࡥࡵࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᔓ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔔ"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔕ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᔖ")+l111l1_l1_+title,l1lllll_l1_,694)
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔗ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔘ"),l11ll1_l1_ (u"ࠫࠬᔙ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬᔚ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦᔛ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠧࠨᔜ"))
	#block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫᔝ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		title = title.replace(l11ll1_l1_ (u"ࠩ࠿ࡦࡃ࠭ᔞ"),l11ll1_l1_ (u"ࠪࠫᔟ")).strip(l11ll1_l1_ (u"ࠫࠥ࠭ᔠ"))
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔡ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔢ")+l111l1_l1_+title,l1lllll_l1_,694)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᔣ"),url,l11ll1_l1_ (u"ࠨࠩᔤ"),l11ll1_l1_ (u"ࠩࠪᔥ"),l11ll1_l1_ (u"ࠪࠫᔦ"),l11ll1_l1_ (u"ࠫࠬᔧ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᔨ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᔩ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨᔪ"),l11ll1_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧᔫ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᔬ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠪࠫᔭ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᔮ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔯ"),l11ll1_l1_ (u"࠭ࠧᔰ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᔱ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣࠫᔲ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔳ"),l111l1_l1_+title,l1lllll_l1_,691)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔴ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔵ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᔶ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᔷ"),l11ll1_l1_ (u"ࠧࠨᔸ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔹ"),l111l1_l1_+title,l1lllll_l1_,691)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠩࠪᔺ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᔻ"),l11ll1_l1_ (u"ࠫࠬᔼ"),request,url)
	if request==l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᔽ"):
		url,search = url.split(l11ll1_l1_ (u"࠭࠿ࠨᔾ"),1)
		data = l11ll1_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ᔿ")+search
		headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᕀ"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᕁ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᕂ"),url,data,headers,l11ll1_l1_ (u"ࠫࠬᕃ"),l11ll1_l1_ (u"ࠬ࠭ᕄ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᕅ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᕆ"),url,l11ll1_l1_ (u"ࠨࠩᕇ"),l11ll1_l1_ (u"ࠩࠪᕈ"),l11ll1_l1_ (u"ࠪࠫᕉ"),l11ll1_l1_ (u"ࠫࠬᕊ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᕋ"))
	html = response.content
	block,items = l11ll1_l1_ (u"࠭ࠧᕌ"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫᕍ"))
	if request==l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᕎ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᕏ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠪࠫᕐ"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᕑ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕒ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᕓ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕔ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬᕕ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕖ"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᕗ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡨࡡࠡ࡯ࡪࡦࠥࡺࡡࡣ࡮ࡨࠤ࡫ࡻ࡬࡭ࠤࠫ࠲࠯ࡅࠩࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫᕘ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᕙ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"࠭ࠧᕚ"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕛ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᕜ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ุ่ࠩฬํฯสࠩᕝ"),l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨᕞ"),l11ll1_l1_ (u"ࠫฬเๆ๋หࠪᕟ"),l11ll1_l1_ (u"้ࠬไ๋สࠪᕠ"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬᕡ"),l11ll1_l1_ (u"่ࠧัสๅࠬᕢ"),l11ll1_l1_ (u"ࠨ็หหึอษࠨᕣ"),l11ll1_l1_ (u"ࠩ฼ี฻࠭ᕤ"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪᕥ"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪᕦ"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬᕧ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"࠭࠯ࠨᕨ"))
		#if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬᕩ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪᕪ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫᕫ"))
		#if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᕬ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭ᕭ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧᕮ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨᕯ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪᕰ"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᕱ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᕲ"):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᕳ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᕴ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕵ"),l111l1_l1_+title,l1lllll_l1_,693,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫᕶ") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕷ"),l111l1_l1_+title,l1lllll_l1_,691,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕸ"),l111l1_l1_+title,l1lllll_l1_,693,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᕹ"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᕺ")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᕻ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᕼ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"࠭ࠣࠨᕽ"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩᕾ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᕿ"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖀ"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩᖁ")+title,l1lllll_l1_,691)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᖂ"),l11ll1_l1_ (u"ࠬ࠭ᖃ"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᖄ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᖅ"),url,l11ll1_l1_ (u"ࠨࠩᖆ"),l11ll1_l1_ (u"ࠩࠪᖇ"),l11ll1_l1_ (u"ࠪࠫᖈ"),l11ll1_l1_ (u"ࠫࠬᖉ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᖊ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩᖋ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᖌ"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩᖍ")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪᖎ"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ᖏ"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠫࠨ࠭ᖐ"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖑ"),l111l1_l1_+title,url,693,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧᖒ"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᖓ"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩᖔ"),str(l1l1l11_l1_))
	block = l1l1l11_l1_[0]
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࠧᖕ")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖖ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪᖗ")+l1l1l_l1_+l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᖘ"),block,re.DOTALL)
	if not l1l111l_l1_: l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪᖙ")+l1l1l_l1_+l11ll1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᖚ"),block,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢᖛ"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᖜ"),l11ll1_l1_ (u"ࠪࠫᖝ"),l11ll1_l1_ (u"ࠫࠬᖞ"),l11ll1_l1_ (u"ࠬ࠸࠲࠳࠴࠵ࠫᖟ"))
		if not l1l1l1l_l1_: l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪᖠ"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖡ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠰࠲ࠫᖢ"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫᖣ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬᖤ"))
			title = title.replace(l11ll1_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩᖥ"),l11ll1_l1_ (u"ࠬࠦࠧᖦ"))
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᖧ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᖨ"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᖩ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫᖪ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬᖫ"))
		#		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᖬ"),l111l1_l1_+title,l1lllll_l1_,692,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l11l_l1_,l1llll11_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᖭ"),l11ll1_l1_ (u"࠭࠯ࡴࡧࡨ࠲ࡵ࡮ࡰࠨᖮ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᖯ"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩᖰ"),l11ll1_l1_ (u"ࠩࠪᖱ"),l11ll1_l1_ (u"ࠪࠫᖲ"),l11ll1_l1_ (u"ࠫࠬᖳ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᖴ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭ࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨᖵ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l1l_l1_ l1lllll_l1_
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖶ"),block,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1lllll_l1_[0]
			l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩᖷ"))
			l1llll_l1_.append(l1lllll_l1_)
		# l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡯࡯ࡥ࡯࡭ࡨࡱ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖸ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬᖹ"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᖺ")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᖻ"))
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᖼ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				title = title.strip(l11ll1_l1_ (u"ࠧ࡝ࡰࠪᖽ"))
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᖾ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᖿ"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l11l_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1llll11_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᗀ"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗁ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ᗂ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧᗃ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩᗄ"),l11ll1_l1_ (u"ࠨ࠭ࠪᗅ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪᗆ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪᗇ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨᗈ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᗉ"))
	return
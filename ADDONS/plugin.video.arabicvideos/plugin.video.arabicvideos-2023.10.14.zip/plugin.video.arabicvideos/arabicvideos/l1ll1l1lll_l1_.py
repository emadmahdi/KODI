# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᨰ")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡄࡏࡏࡣࠬᨱ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧใ่๋หฯࠦแืษษ๎ฮ࠭ᨲ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l11111_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l1llll1l_l1_(url,text)
	elif mode==474: results = l1l111_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᨳ"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪᨴ"),l11ll1_l1_ (u"ࠪࠫᨵ"),l11ll1_l1_ (u"ࠫࠬᨶ"),l11ll1_l1_ (u"ࠬ࠭ᨷ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᨸ"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡷࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᨹ"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠨ࠱ࠪᨺ"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭ᨻ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨼ"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᨽ"),l11ll1_l1_ (u"ࠬ࠭ᨾ"),479,l11ll1_l1_ (u"࠭ࠧᨿ"),l11ll1_l1_ (u"ࠧࠨᩀ"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᩁ"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩂ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᩃ"),l11ll1_l1_ (u"ࠫࠬᩄ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩅ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᩆ")+l111l1_l1_+l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬᩇ"),l1ll111_l1_,471,l11ll1_l1_ (u"ࠨࠩᩈ"),l11ll1_l1_ (u"ࠩࠪᩉ"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬᩊ"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᩋ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᩌ")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᩍ"),l1ll111_l1_,471,l11ll1_l1_ (u"ࠧࠨᩎ"),l11ll1_l1_ (u"ࠨࠩᩏ"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᩐ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᩑ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᩒ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧᩓ"))
		#if title in l1l11l_l1_: continue
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭ࡣࡢࡶࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡱࡴࡼࡩࡦࡵ࠴ࠫᩔ"),l11ll1_l1_ (u"ࠧࡤࡣࡷࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶࠫᩕ"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩖ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᩗ")+l111l1_l1_+title,l1lllll_l1_,474)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩘ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᩙ"),l11ll1_l1_ (u"ࠬ࠭ᩚ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᩛ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᩜ"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_:
		block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠨࠩᩝ"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᩞ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		#l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧ᩟")+category+l11ll1_l1_ (u"ࠫࡂ᩠࠭")+value
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩡ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᩢ")+l111l1_l1_+title,l1lllll_l1_,474)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᩣ"),url,l11ll1_l1_ (u"ࠨࠩᩤ"),l11ll1_l1_ (u"ࠩࠪᩥ"),l11ll1_l1_ (u"ࠪࠫᩦ"),l11ll1_l1_ (u"ࠫࠬᩧ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᩨ"))
	html = response.content
	if l11ll1_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵ࠭ᩩ") in url: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡱ࠲࡭ࡲࡪࡦࠥࠫᩪ"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᩫ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᩬ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪᩭ") in l1lllll_l1_:
				if l11ll1_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃࡥ࡯ࡩ࡯࡭ࡸ࡮࠭࡮ࡱࡹ࡭ࡪࡹࠧᩮ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹ࠱ࠨᩯ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾࡯࡬ࡷࡨ࠭ᩰ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡷࡺ࠲ࡩࡨࡢࡰࡱࡩࡱ࠭ᩱ") in l1lllll_l1_: continue
				if l11ll1_l1_ (u"ࠨ็้ิࠥอไษัส๎ฮ࠭ᩲ") in title and l11ll1_l1_ (u"ࠩࡧࡳࡂࡸࡡࡵ࡫ࡱ࡫ࠬᩳ") not in l1lllll_l1_: continue
			else: title = l11ll1_l1_ (u"ࠪฮึะ๊ษࠢหหุะฮะษ่࠾ࠥࠦࠧᩴ")+title
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᩵"),l111l1_l1_+title,l1lllll_l1_,471)
	else: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠬ࠭᩶")):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ᩷"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ᩸"),url,l11ll1_l1_ (u"ࠨࠩ᩹"),l11ll1_l1_ (u"ࠩࠪ᩺"),l11ll1_l1_ (u"ࠪࠫ᩻"),l11ll1_l1_ (u"ࠫࠬ᩼"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ᩽"))
	html = response.content
	items = []
	if request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨ᩾"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡫ࡲࡵࡪࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ᩿ࠧ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠬ᪀"),block,re.DOTALL)
		l1l1_l1_,l11lll_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,l1l1_l1_,l11lll_l1_)
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ᪁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬ᪂"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠩ᪃"),block,re.DOTALL)
		l1l1_l1_,l11lll_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,l1l1_l1_,l11lll_l1_)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᪄"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭᪅"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᪆"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᪇"),html,re.DOTALL)
		if not l1l1l11_l1_: return
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᪈"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ᪉"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ᪊"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ᪋"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ᪌"),l11ll1_l1_ (u"ࠧไๆํฬࠬ᪍"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ᪎"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ᪏"),l11ll1_l1_ (u"้ࠪออัศหࠪ᪐"),l11ll1_l1_ (u"ࠫ฾ืึࠨ᪑"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ᪒"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ᪓"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧ᪔")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ᪕"))
		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ᪖") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ᪗")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭᪘"))
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᪙") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ᪚")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ᪛"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ᪜"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ᪝"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᪞"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠫฬ๊อๅไฬࠫ᪟") in title:
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ᪠") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪡"),l111l1_l1_+title,l1lllll_l1_,473,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ᪢") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪣"),l111l1_l1_+title,l1lllll_l1_,471,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᪤"),l111l1_l1_+title,l1lllll_l1_,473,l1lll1_l1_)
	if request not in [l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬ᪥"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭᪦")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᪧ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᪨"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ᪩"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ᪪")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ᪫"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪬"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ᪭")+title,l1lllll_l1_,471)
		l1llll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᪮"),html,re.DOTALL)
		if l1llll1ll1_l1_:
			l1lllll_l1_ = l1llll1ll1_l1_[0]
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪯"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ᪰"),l1lllll_l1_,471)
	return
def l1llll1l_l1_(url,l1l1l_l1_):
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ᪱"),l11ll1_l1_ (u"ࠩ࠴࠵࠶࠷ࠠࠡࠩ᪲")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ᪳"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ᪴"),url,l11ll1_l1_ (u"᪵ࠬ࠭"),l11ll1_l1_ (u"᪶࠭ࠧ"),l11ll1_l1_ (u"ࠧࠨ᪷"),l11ll1_l1_ (u"ࠨ᪸ࠩ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧ᪹ࠫ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ᪺࠭"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩ᪻")+l1l1l_l1_+l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᪼"),html,re.DOTALL)
	items = []
	# l1lll1l_l1_
	if l1l11l1_l1_ and not l1l1l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪽"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࡞࠯ࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ᪾"),block,re.DOTALL)
		for l1l1l_l1_,title in items: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᪿ"),l111l1_l1_+title,url,473,l1lll1_l1_,l11ll1_l1_ (u"ᫀࠩࠪ"),l1l1l_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		#l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ᫁"))
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᫂"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡺࡩࡵ࡮ࡨࡁࠬ࠮࠮ࠫࡁࠬࠫࠥ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀ᫃ࠫࠪࠦ"),block,re.DOTALL)
		if items:
			for title,l1lllll_l1_ in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ᫄")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ᫅"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᫆"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ᫇"),block,re.DOTALL)
			for l1lllll_l1_,title,l1lll1_l1_ in items:
				if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ᫈") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭᫉")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵᫊ࠧ"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᫋"),l111l1_l1_+title,l1lllll_l1_,472,l1lll1_l1_)
	if l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩᫌ") in html:
		if items: addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᫍ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᫎ"),l11ll1_l1_ (u"ࠪࠫ᫏"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᫐"),l111l1_l1_+l11ll1_l1_ (u"๋่ࠬศุํ฽ࠥึวหุ่ࠢฮ࠭᫑"),url,471)
	#else: l11111_l1_(url)
	return
def PLAY(url):
	#l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ᫒"))
	l1llll_l1_ = []
	# l1ll1ll111_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ᫓"),url,l11ll1_l1_ (u"ࠨࠩ᫔"),l11ll1_l1_ (u"ࠩࠪ᫕"),l11ll1_l1_ (u"ࠪࠫ᫖"),l11ll1_l1_ (u"ࠫࠬ᫗"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ᫘"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡥ࡫ࡹࠤ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠧࡄࠨ࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠪ᫙"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭᫚"),block,re.DOTALL)
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,True): return
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬ᫛"),l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬ᫜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ᫝"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ᫞"),l11ll1_l1_ (u"ࠬ࠭᫟"),l11ll1_l1_ (u"࠭ࠧ᫠"),l11ll1_l1_ (u"ࠧࠨ᫡"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭᫢"))
	html = response.content
	l1ll1l1ll1_l1_ = []
	# l1l111l1l_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡗࡕࡐࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᫣"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]
		if l1lllll_l1_ and l1lllll_l1_ not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(l1lllll_l1_)
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ᫤")
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᫥") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᫦")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"ࠨ࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠤ᫧"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_ not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(l1lllll_l1_)
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᫨")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᫩")
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ᫪") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ᫫")+l1lllll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ᫬"),l11ll1_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰ࡳ࡬ࡵ࠭᫭"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ᫮"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ᫯"),l11ll1_l1_ (u"ࠨࠩ᫰"),l11ll1_l1_ (u"ࠩࠪ᫱"),l11ll1_l1_ (u"ࠪࠫ᫲"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ᫳"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᫴"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩ᫵"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_ not in l1ll1l1ll1_l1_:
				l1ll1l1ll1_l1_.append(l1lllll_l1_)
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᫶")+title+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ᫷")
				if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ᫸") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ᫹")+l1lllll_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ᫺"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᫻"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧ᫼"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ᫽"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ᫾"),l11ll1_l1_ (u"ࠩ࠮ࠫ᫿"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᬀ")+search
	l11111_l1_(url)
	return
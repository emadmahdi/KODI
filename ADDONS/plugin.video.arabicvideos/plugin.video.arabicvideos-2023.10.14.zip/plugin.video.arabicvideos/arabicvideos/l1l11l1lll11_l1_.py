# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ䯛")
headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䯜") : l11ll1_l1_ (u"ࠪࠫ䯝") }
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓࡖ࡛ࡡࠪ䯞")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11111_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llll1l_l1_(url)
	elif mode==188: results = l11ll11ll111_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11ll11ll111_l1_():
	message = l11ll1_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠡ࠰࠱࠲ࠥ๎ศฮษฯอࠥอไ๊ࠢส฽ฬีษࠡสิ้ัฯࠠๆ่ࠣห้฻แาࠢ࠱࠲࠳่ࠦศๆ่ฬึ๋ฬࠡฯส่๏อࠠๆึ฽์้่๋ࠦ฻ส๊๏ࠦๅ็๋ࠢ฽่ฯࠠึฯํอࠥ࠴࠮࠯๋่ࠢ์ึวࠡี๋ๅࠥ๐ศใ๋ࠣห้๋่ใ฻้ࠣ฿๊โࠡษ็ํ๋ࠥวࠡึสลࠥอไๅ้ࠪ䯟")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䯠"),l11ll1_l1_ (u"ࠧࠨ䯡"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䯢"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䯣"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䯤"),l11ll1_l1_ (u"ࠫࠬ䯥"),189,l11ll1_l1_ (u"ࠬ࠭䯦"),l11ll1_l1_ (u"࠭ࠧ䯧"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䯨"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯩"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䯪")+l111l1_l1_+l11ll1_l1_ (u"ࠪฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࠫ䯫"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠫࠬ䯬"),l11ll1_l1_ (u"ࠬ࠭䯭"),l11ll1_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ䯮"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䯯"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䯰")+l111l1_l1_+l11ll1_l1_ (u"ࠩฦัิัࠠศๆสๅ้อๅࠨ䯱"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠪࠫ䯲"),l11ll1_l1_ (u"ࠫࠬ䯳"),l11ll1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䯴"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯵"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䯶")+l111l1_l1_+l11ll1_l1_ (u"ࠨฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ีࠧ䯷"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠩࠪ䯸"),l11ll1_l1_ (u"ࠪࠫ䯹"),l11ll1_l1_ (u"ࠫࡹࡼࠧ䯺"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䯻"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䯼")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧ䯽"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠨࠩ䯾"),l11ll1_l1_ (u"ࠩࠪ䯿"),l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䰀"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䰁"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䰂")+l111l1_l1_+l11ll1_l1_ (u"࠭รใ๊์ࠤฬ๊วโๆส้ࠥอไฮษ็๎ฮ࠭䰃"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠧࠨ䰄"),l11ll1_l1_ (u"ࠨࠩ䰅"),l11ll1_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䰆"))
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䰇"),headers,l11ll1_l1_ (u"ࠫࠬ䰈"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䰉"))
	items = re.findall(l11ll1_l1_ (u"࠭࠼ࡩ࠴ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䰊"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䰋"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䰌")+l111l1_l1_+title,l1lllll_l1_,181)
	return html
def l11111_l1_(url,type=l11ll1_l1_ (u"ࠩࠪ䰍")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ䰎"),headers,l11ll1_l1_ (u"ࠫࠬ䰏"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䰐"))
	if type==l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䰑"): block = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ฤฯาฯࠥอไฤใ็ห๊ࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ䰒"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬ䰓"): block = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀห์ู่ࠠศ๊ไ๎ุࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ䰔"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䰕"): block = re.findall(l11ll1_l1_ (u"ࠫࡧࡺ࡮࠮࠴࠰ࡳࡻ࡫ࡲ࡭ࡣࡼࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩ䰖"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䰗"): block = re.findall(l11ll1_l1_ (u"࠭ࡢࡵࡰ࠰࠵ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠪ࠱࠮ࡄ࠯ࡢࡵࡰ࠰࠶ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠩ䰘"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠧࡵࡸࠪ䰙"): block = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡨࠤࠪ䰚"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11ll1_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䰛"),l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䰜")]:
		items = re.findall(l11ll1_l1_ (u"ࠫࡸࡺࡹ࡭ࡧࡀࠦࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䰝"),block,re.DOTALL)
	else: items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࡂࠨ࠳࡜࠲࠰࠽ࡢ࠱ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰞"),block,re.DOTALL)
	l11l_l1_ = []
	l111lll11_l1_ = [l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ䰟"),l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ䰠"),l11ll1_l1_ (u"ࠨษ็ั้่็ࠨ䰡"),l11ll1_l1_ (u"ࠩ฼ี฻࠭䰢"),l11ll1_l1_ (u"ࠪࡖࡦࡽࠧ䰣"),l11ll1_l1_ (u"ࠫࡘࡳࡡࡤ࡭ࡇࡳࡼࡴࠧ䰤"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ䰥"),l11ll1_l1_ (u"࠭วอิสลࠬ䰦")]
	for l1lll1_l1_,l11ll111ll1l_l1_,l11ll11ll11l_l1_,l11ll11ll1l1_l1_ in items:
		if type in [l11ll1_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䰧"),l11ll1_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䰨")]:
			l1lll1_l1_,l1lllll_l1_,l1lllll11l_l1_,title = l1lll1_l1_,l11ll111ll1l_l1_,l11ll11ll11l_l1_,l11ll11ll1l1_l1_
		else: l1lll1_l1_,title,l1lllll_l1_,l1lllll11l_l1_ = l1lll1_l1_,l11ll111ll1l_l1_,l11ll11ll11l_l1_,l11ll11ll1l1_l1_
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩࡂࡺ࡮࡫ࡷ࠾ࡶࡵࡹࡪ࠭䰩"),l11ll1_l1_ (u"ࠪࠫ䰪"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䰫"),l11ll1_l1_ (u"ࠬ࠭䰬"),l1lllll_l1_,l1lllll11l_l1_)
		title = unescapeHTML(title)
		#l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭࠭ฮฬ้ัฬࢀอา่ะ้ࠬࠫ䰭"),title,re.DOTALL)
		#if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0][0]
		if l11ll1_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䰮") in title or l11ll1_l1_ (u"ࠨสฯ์ิํࠠࠨ䰯") in title:
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䰰") + title.replace(l11ll1_l1_ (u"ࠪฬั๎ฯสࠢࠪ䰱"),l11ll1_l1_ (u"ࠫࠬ䰲")).replace(l11ll1_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䰳"),l11ll1_l1_ (u"࠭ࠧ䰴"))
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ䰵"))
		if l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ䰶") in title or l11ll1_l1_ (u"ࠩส่า๊โ่ࠩ䰷") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡡࡪࠫࠨ䰸"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䰹") + l1ll1l1_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䰺"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111lll11_l1_):
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䰻") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䰼"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䰽") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䰾"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠪࠫ䰿"):
		items = re.findall(l11ll1_l1_ (u"ࠫࡡࡴ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䱀"),html,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠬอไึใะอࠥ࠭䱁"),l11ll1_l1_ (u"࠭ࠧ䱂"))
			if title!=l11ll1_l1_ (u"ࠧࠨ䱃"):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䱄"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ䱅")+title,l1lllll_l1_,181)
	return
def l1llll1l_l1_(url):
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭䱆"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ䱇"),headers,l11ll1_l1_ (u"ࠬ࠭䱈"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䱉"))
	block = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵ࡫ࡷࡰࡪࡄ࠮ࠫࡁ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠬࡠ࠶࠭࠺࡟࠮࠭ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱊"),html,re.DOTALL)
	title,dummy,l1lll1_l1_ = block[0]
	name = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡞࠴࠲࠿࡝ࠬࠩ䱋"),title,re.DOTALL)
	if name: name = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䱌") + name[0][0]
	else: name = title
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷࡓࡻ࡭ࡣࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䱍"),html,re.DOTALL)
	if l1l1l11_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䱎"),l11ll1_l1_ (u"ࠬ࠭䱏"),l111lll_l1_,str(l1l1l11_l1_))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱐"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			title = re.findall(l11ll1_l1_ (u"ࠧࠩษ็ั้่ษࡽษ็ั้่็ࠪ࠯ࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ䱑"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ䱒"))[-2],re.DOTALL)
			if not title: title = re.findall(l11ll1_l1_ (u"ࠩࠫ࠭࠲࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ䱓"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ䱔"))[-2],re.DOTALL)
			if title: title = l11ll1_l1_ (u"ࠫࠥ࠭䱕") + title[0][1]
			else: title = l11ll1_l1_ (u"ࠬ࠭䱖")
			title = name + l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪ䱗") + l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ䱘") + title
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䱙"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠩหะํีษࠡࠩ䱚") in title or l11ll1_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䱛") in title:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䱜") + title.replace(l11ll1_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䱝"),l11ll1_l1_ (u"࠭ࠧ䱞")).replace(l11ll1_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ䱟"),l11ll1_l1_ (u"ࠨࠩ䱠"))
		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䱡"),l111l1_l1_+title,url,182,l1lll1_l1_)
	return
def PLAY(url):
	l11ll11ll1ll_l1_ = url.split(l11ll1_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭䱢"))
	l111lll_l1_ = l11ll11ll1ll_l1_[0]
	del l11ll11ll1ll_l1_[0]
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ䱣"),headers,l11ll1_l1_ (u"ࠬ࠭䱤"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䱥"))
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡧࡱࡱࡸ࠲ࡹࡩࡻࡧ࠽ࠤ࠷࠻ࡰࡹ࠽ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱦"),html,re.DOTALL)[0]
	if l1lllll_l1_ not in l11ll11ll1ll_l1_: l11ll11ll1ll_l1_.append(l1lllll_l1_)
	l1llll_l1_ = []
	# l11ll11l1l1l_l1_
	for l1lllll_l1_ in l11ll11ll1ll_l1_:
		if l11ll1_l1_ (u"ࠨ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ䱧") in l1lllll_l1_:
			l11ll11l1l1l_l1_ = l1lllll_l1_
			l1llll_l1_.append(l11ll11l1l1l_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡐࡥ࡮ࡴࠧ䱨"))
	# l11ll11l1l11_l1_
	for l1lllll_l1_ in l11ll11ll1ll_l1_:
		if l11ll1_l1_ (u"ࠪ࠾࠴࠵ࡶࡣ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠭䱩") in l1lllll_l1_:
			html = OPENURL_CACHED(l1llllll_l1_,l1lllll_l1_,l11ll1_l1_ (u"ࠫࠬ䱪"),headers,l11ll1_l1_ (u"ࠬ࠭䱫"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䱬"))
			html = html.decode(l11ll1_l1_ (u"ࠧࡸ࡫ࡱࡨࡴࡽࡳ࠮࠳࠵࠹࠻࠭䱭")).encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭䱮"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11ll111ll11_l1_><l11ll11l1111_l1_ /><l11ll111ll11_l1_ l11ll11l1lll_l1_=l11ll1_l1_ (u"ࠤࡦࡩࡳࡺࡥࡳࠤ䱯")>(\*\*\*\*\*\*\*\*|13721411411.l11ll111l1l1_l1_|)
			html = html.replace(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䱰"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䱱"))
			html = html.replace(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䱲"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䱳"))
			html = html.replace(l11ll1_l1_ (u"ࠧ࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࡀࡧࡸࠠ࠰ࡀ࠿ࡨ࡮ࡼࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢ࠿ࠩ䱴"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䱵"))
			html = html.replace(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡦࡴࡸࡤࡦࡴࠥࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠬ䱶"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䱷"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䱸"),html,re.DOTALL)
			if l1l1l11_l1_:
				#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䱹"),l11ll1_l1_ (u"࠭ࠧ䱺"),url,str(len(l1l1l11_l1_)))
				l11ll111l1ll_l1_,l11ll11l11ll_l1_ = [],[]
				if len(l1l1l11_l1_)==1:
					title = l11ll1_l1_ (u"ࠧࠨ䱻")
					block = html
				else:
					for block in l1l1l11_l1_:
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠴ࠪࡀ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࠭ࠫ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䱼"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ䱽") + l111l_l1_[0][1]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀ࠾࡫ࡶࠥࡹࡩࡻࡧࡀࠦ࠶ࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࠨࠠ࠰ࡀࠫ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ䱾"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䱿") + l111l_l1_[0]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࠫ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹ࠢࠡ࠱ࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䲀"),block,re.DOTALL)
						if l111l_l1_: block = l111l_l1_[0] + l11ll1_l1_ (u"࠭ࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䲁")
						l11ll11l1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࠪ࠱࠮ࡄ࠯ࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠭䲂"),block,re.DOTALL)
						title = re.findall(l11ll1_l1_ (u"ࠨࡀࠣ࠮࠭ࡡ࡞࠽ࡀࡠ࠯࠮ࠦࠪ࠽ࠩ䲃"),l11ll11l1ll1_l1_[0][0],re.DOTALL)
						title = l11ll1_l1_ (u"ࠩࠣࠫ䲄").join(title)
						title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ䲅"))
						title = title.replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䲆"),l11ll1_l1_ (u"ࠬࠦࠧ䲇")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䲈"),l11ll1_l1_ (u"ࠧࠡࠩ䲉")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䲊"),l11ll1_l1_ (u"ࠩࠣࠫ䲋")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭䲌"),l11ll1_l1_ (u"ࠫࠥ࠭䲍")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䲎"),l11ll1_l1_ (u"࠭ࠠࠨ䲏"))
						l11ll111l1ll_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮ࠺ࠨ䲐"), l11ll111l1ll_l1_)
					if l1l_l1_ == -1 : return
					title = l11ll111l1ll_l1_[l1l_l1_]
					block = l1l1l11_l1_[l1l_l1_]
				l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠬࠦࠬ䲑"),block,re.DOTALL)
				l11ll11l111l_l1_ = l1lllll_l1_[0]
				l1llll_l1_.append(l11ll11l111l_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡉࡳࡷࡻ࡭ࠨ䲒"))
				block = block.replace(l11ll1_l1_ (u"ࠪไࠬ䲓"),l11ll1_l1_ (u"ࠫࠬ䲔"))
				block = block.replace(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ䲕"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ䲖"))
				block = block.replace(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡨࡵ࡭࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠹࠶࠽࠴࠲࠴࠴࠻࠺࠸࠹࠷࠰ࡳࡲ࡬ࠨࠧ䲗"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䲘"))
				block = block.replace(l11ll1_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้ะอๆ์็ࠫ䲙"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ䲚"))
				block = block.replace(l11ll1_l1_ (u"ࠫึ๎วษูࠣห้ะอๆ์็ࠫ䲛"),l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ䲜"))
				block = block.replace(l11ll1_l1_ (u"࠭ำ๋ำไีฬะࠠศๆุ่ฬํฯࠨ䲝"),l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䲞"))
				block = block.replace(l11ll1_l1_ (u"ࠨำ๋หอ฽ࠠศๆุ่ฬํฯࠨ䲟"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䲠"))
				l11ll111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴ࡢࡤࠬࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䲡"),block,re.DOTALL)
				for l11ll11l11l1_l1_ in l11ll111lll1_l1_:
					#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䲢"),l11ll1_l1_ (u"ࠬ࠭䲣"),l11ll1_l1_ (u"࠭ࠧ䲤"),str(l11ll11l11l1_l1_))
					type = re.findall(l11ll1_l1_ (u"ࠧࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࠬ䲥"),l11ll11l11l1_l1_)
					if type:
						if type[0]!=l11ll1_l1_ (u"ࠨࡤࡲࡸ࡭࠭䲦"): type = l11ll1_l1_ (u"ࠩࡢࡣࠬ䲧")+type[0]
						else: type = l11ll1_l1_ (u"ࠪࠫ䲨")
					items = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡅ࠼ࠢࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴࠯ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿࠳࡫ࡵ࡮ࡵࡀ࠱࠮ࡄࢂ࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾ࡥࡶࠥ࠵࠾࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࠰࠭ࡃ࠮ࠨࠧ䲩"),l11ll11l11l1_l1_,re.DOTALL)
					for l11ll111llll_l1_,l1lllll_l1_ in items:
						title = re.findall(l11ll1_l1_ (u"ࠬ࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫࠫ࠿ࠫ䲪"),l11ll111llll_l1_)
						title = title[-1]
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䲫") + title + type
						l1llll_l1_.append(l1lllll_l1_)
	# l11ll11lll11_l1_
	l11l111_l1_ = l111lll_l1_.replace(l11l1l_l1_,l11lllll1l_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠧࠨ䲬"),headers,l11ll1_l1_ (u"ࠨࠩ䲭"),l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ䲮"))
	items = re.findall(l11ll1_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲯"),html,re.DOTALL)
	#l11lll1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵ࡥ࡮ࡤࡨࡨࡒ࠳ࠨ࡝ࡹ࠮࠭࠲࠴ࠪࡀ࠰࡫ࡸࡲࡲࠩࠨ䲰"),html,re.DOTALL)
	#if l11lll1l11_l1_:
	if items:
		#l11ll11lll11_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ䲱") + l11lll1l11_l1_[-1] + l11ll1_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ䲲")
		l11ll11lll11_l1_ = items[-1]
		l1llll_l1_.append(l11ll11lll11_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡱࡥ࡭ࡱ࡫ࠧ䲳"))
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䲴"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ䲵"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ䲶"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭䲷"),l11ll1_l1_ (u"ࠬ࠱ࠧ䲸"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ䲹"),headers,l11ll1_l1_ (u"ࠧࠨ䲺"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ䲻"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࡁࠫ䲼"),html,re.DOTALL)
	l111ll1l1_l1_ = [ l11ll1_l1_ (u"ࠪࠫ䲽") ]
	l111l11l1_l1_ = [ l11ll1_l1_ (u"ࠫฬ๊ใๅ๋ࠢฬิ๎ๆࠡใ็ฮึ࠭䲾") ]
	for category,title in items:
		l111ll1l1_l1_.append(category)
		l111l11l1_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ䲿"), l111l11l1_l1_)
		if l1l_l1_ == -1 : return
		category = l111ll1l1_l1_[l1l_l1_]
	else: category = l11ll1_l1_ (u"࠭ࠧ䳀")
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䳁")+search+l11ll1_l1_ (u"ࠨࠨࡰࡧࡦࡺ࠽ࠨ䳂")+category
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䳃"),l11ll1_l1_ (u"ࠪࠫ䳄"),url,url)
	l11111_l1_(url)
	return
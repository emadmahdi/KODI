# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ昲")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ昳")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠬฮหࠡ็หหูืࠧ昴")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l11111_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llll1l_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ昵"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ昶"),l11ll1_l1_ (u"ࠨࠩ昷"),l11ll1_l1_ (u"ࠩࠪ昸"),l11ll1_l1_ (u"ࠪࠫ昹"),l11ll1_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ昺"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ昻"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭昼"),l11ll1_l1_ (u"ࠧࠨ昽"),469,l11ll1_l1_ (u"ࠨࠩ显"),l11ll1_l1_ (u"ࠩࠪ昿"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ晀"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ晁"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ時")+l111l1_l1_+l11ll1_l1_ (u"࠭รฯำࠣห้ำไใษอࠫ晃"),l11l1l_l1_,461,l11ll1_l1_ (u"ࠧࠨ晄"),l11ll1_l1_ (u"ࠨࠩ晅"),l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ晆"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ晇"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ晈"),l11ll1_l1_ (u"ࠬ࠭晉"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡮ࡧࡱࡹ࠲ࡨࡴ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭晊"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭晋"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ晌"): continue
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ晍") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if title==l11ll1_l1_ (u"ࠪห้ืฦ๋ีํอࠬ晎"): title = l11ll1_l1_ (u"ࠫัี๊ะࠢะ่็อสࠡฬํๅ๏ࠦแศ่ࠪ晏")
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ晐"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ晑")+l111l1_l1_+title,l1lllll_l1_,461)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡈࡲࡳࡹ࡫ࡲࡄࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ晒"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ晓"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晔"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ晕")+l111l1_l1_+title,l1lllll_l1_,461)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬ晖")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭晗"),l11ll1_l1_ (u"࠭ࠧ晘"),l1lll1l1l1_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ晙"),url,l11ll1_l1_ (u"ࠨࠩ晚"),l11ll1_l1_ (u"ࠩࠪ晛"),l11ll1_l1_ (u"ࠪࠫ晜"),l11ll1_l1_ (u"ࠫࠬ晝"),l11ll1_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ晞"))
	html = response.content
	#if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭晟"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧฤะิࠤฬ๊อๅไสฮ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ晠"),html,re.DOTALL)
	#else:
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡧࡱࡲࡸࡪࡸࠢࠨ晡"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ晢"),block,re.DOTALL)
		l11l_l1_ = []
		l1ll1l_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ晣"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ晤"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫ晥"),l11ll1_l1_ (u"࠭ใๅ์หࠫ晦"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭晧"),l11ll1_l1_ (u"ࠨ้าหๆ࠭晨"),l11ll1_l1_ (u"่ࠩฬฬืวสࠩ晩"),l11ll1_l1_ (u"ࠪ฽ึ฼ࠧ晪"),l11ll1_l1_ (u"๊ࠫํัอษ้ࠫ晫"),l11ll1_l1_ (u"ࠬอไษ๊่ࠫ晬")]
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ晭") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)	#.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ普"))
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ景"),title,re.DOTALL)
			if any(value in title for value in l1ll1l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ晰"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪห้ำไใหࠪ晱") in title:
				title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ晲") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ晳"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭晴"),l111l1_l1_+title,l1lllll_l1_,463,l1lll1_l1_)
	if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ晵"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ晶"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ晷"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ晸"))
				if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ晹"): continue
				if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ智") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"࠭ࠧ晻"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ晼"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ晽")+title,l1lllll_l1_,461)
	return
def l1llll1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ晾"),l11ll1_l1_ (u"ࠪࠫ晿"),l11ll1_l1_ (u"ࠫࡊࡖࡉࡔࡑࡇࡉࡘ࠭暀"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ暁"),url,l11ll1_l1_ (u"࠭ࠧ暂"),l11ll1_l1_ (u"ࠧࠨ暃"),l11ll1_l1_ (u"ࠨࠩ暄"),l11ll1_l1_ (u"ࠩࠪ暅"),l11ll1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ暆"))
	html = response.content
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥ࠯ࡷ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠥࠫ暇"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭暈"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ暉") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭暊"),l111l1_l1_+title,l1lllll_l1_,462,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ暋"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ暌"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ暍"))
			if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ暎"): continue
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ暏") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			#title = unescapeHTML(title)
			if title!=l11ll1_l1_ (u"࠭ࠧ暐"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ暑"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ暒")+title,l1lllll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭暓"),url,l11ll1_l1_ (u"ࠪࠫ暔"),l11ll1_l1_ (u"ࠫࠬ暕"),l11ll1_l1_ (u"ࠬ࠭暖"),l11ll1_l1_ (u"࠭ࠧ暗"),l11ll1_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ暘"))
	html = response.content
	# l1l111l1l_l1_ l1lllll_l1_
	l1111l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡖࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ暙"),html,re.DOTALL)
	if l1111l11l1_l1_:
		l1111l11l1_l1_ = l1111l11l1_l1_[0]
		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ暚") not in l1111l11l1_l1_:
			if l11ll1_l1_ (u"ࠪ࠳࠴࠭暛") in l1111l11l1_l1_: l1111l11l1_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ暜")+l1111l11l1_l1_
			else: l1111l11l1_l1_ = l11l1l_l1_+l1111l11l1_l1_
		l1111l11l1_l1_ = l1111l11l1_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭暝")
		l1llll_l1_.append(l1111l11l1_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡢ࠲࠷࠽ࡦࡪ࡬࡯ࡳࡧࠫ࠲࠯ࡅࠩࡴ࡯ࡤࡰࡱ࠴ࠪࡀࠤ࡙࡭ࡩ࡫࡯ࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡑ࡮ࡤࡽࠧ࠭暞"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1ll1lll11l1l_l1_,l1ll1lll11ll1_l1_ = l1l1l11_l1_[0]
		names = re.findall(l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ暟"),l1ll1lll11l1l_l1_,re.DOTALL)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡵࡨࡸ࡛࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ暠"),l1ll1lll11ll1_l1_,re.DOTALL)
		l1ll1lll11l11_l1_ = zip(names,l1l1_l1_)
		for name,l1llllll1111l_l1_ in l1ll1lll11l11_l1_:
			l1llllll1111l_l1_ = l1llllll1111l_l1_[2:]
			if kodi_version<19: l1llllll1111l_l1_ = l1llllll1111l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ暡"))
			l1llllll1111l_l1_ = base64.b64decode(l1llllll1111l_l1_)
			if kodi_version>18.99: l1llllll1111l_l1_ = l1llllll1111l_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ暢"))
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ暣"),l1llllll1111l_l1_,re.DOTALL)
			l1lllll_l1_ = l1lllll_l1_[0]
			if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ暤") not in l1lllll_l1_:
				if l11ll1_l1_ (u"࠭࠯࠰ࠩ暥") in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭暦")+l1lllll_l1_
				else: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ暧")+name+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ暨")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ暩"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ暪"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11ll1_l1_ (u"ࠬࠦࠧ暫") in search:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ暬"),l11ll1_l1_ (u"ࠧࠨ暭"),l11ll1_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ暮"),l11ll1_l1_ (u"ࠩ็่ศูแࠡษ็ฬาัࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠๅษࠣ๎฾๋ไࠡ฻้ำࠥ฽ไษࠢฦ็ะืࠠๆ่ࠣ็้๋ษ๊ࠡสัิฯࠠ࠯࠰࠱ࠤ๏ืฬ๊ࠢส่อำหࠡ฻้ࠤ่๊ๅส๋ࠢหาีษࠡใๅ฻ࠬ暯"))
		return
	#search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ暰"),l11ll1_l1_ (u"ࠫ࠲࠭暱"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭暲")+search
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡲ࠱ࠪ暳")+search+l11ll1_l1_ (u"ࠧ࠰ࠩ暴")
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ斍")
#headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ斎"):l11ll1_l1_ (u"ࠨࠩ斏")}
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨ斐")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ฺ้ࠪอัฺหࠪ斑"),l11ll1_l1_ (u"ࠫอัࠠๆสสุึ࠭斒")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11111_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llll1l_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ斓"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ斔"),l11ll1_l1_ (u"ࠧࠨ斕"),l11ll1_l1_ (u"ࠨࠩ斖"),l11ll1_l1_ (u"ࠩࠪ斗"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ斘"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ料"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠬ࠵ࠧ斚"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ斛"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斜"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ斝"),l1ll111_l1_,489,l11ll1_l1_ (u"ࠩࠪ斞"),l11ll1_l1_ (u"ࠪࠫ斟"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ斠"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ斡"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭斢"),l11ll1_l1_ (u"ࠧࠨ斣"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ斤"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ斥")+l111l1_l1_+l11ll1_l1_ (u"ࠪวาีหࠡษ็้ํอึ๋฻ࠪ斦"),l1ll111_l1_,481)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩࠣ࡯ࡼࡅࡨࡩ࡯ࡶࡰࡷࠦࠬ斧"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭斨"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"࠭ࠣࠨ斩"): continue
		if title in l1l11l_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斪"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ斫")+l111l1_l1_+title,l1lllll_l1_,481)
	return html
def l11111_l1_(url,l1ll1lll1l11l_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭斬"),url,l11ll1_l1_ (u"ࠪࠫ断"),l11ll1_l1_ (u"ࠫࠬ斮"),l11ll1_l1_ (u"ࠬ࠭斯"),l11ll1_l1_ (u"࠭ࠧ新"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭斱"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡳࡸࡺࠨ࠯ࠬࡂ࠭ࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭斲"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ斳"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ斴"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ斵"),l11ll1_l1_ (u"ࠬอฺ็์ฬࠫ斶"),l11ll1_l1_ (u"࠭ร฻่ํอࠬ斷"),l11ll1_l1_ (u"ࠧไๆํฬࠬ斸"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ方"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ斺"),l11ll1_l1_ (u"้ࠪออัศหࠪ斻"),l11ll1_l1_ (u"ࠫ฾ืึࠨ於"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ施"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ斾"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧ斿")]
	l1ll1lll1l1l1_l1_ = l11ll1_l1_ (u"ࠨ࠱ࠪ旀").join(l1ll1lll1l11l_l1_.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ旁")).split(l11ll1_l1_ (u"ࠪ࠳ࠬ旂"))[4:]).split(l11ll1_l1_ (u"ࠫ࠲࠭旃"))
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭旄"),title,re.DOTALL)
		if l1ll1lll1l11l_l1_:
			l1lllll11l_l1_ = l11ll1_l1_ (u"࠭࠯ࠨ旅").join(l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ旆")).split(l11ll1_l1_ (u"ࠨ࠱ࠪ旇"))[4:]).split(l11ll1_l1_ (u"ࠩ࠰ࠫ旈"))
			l1ll1lll1l1ll_l1_ = len([x for x in l1ll1lll1l1l1_l1_ if x in l1lllll11l_l1_])
			if l1ll1lll1l1ll_l1_>2 and l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ旉") in l1lllll_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ旊"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
		else:
			if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ旋"),title,re.DOTALL)
			#if any(value in title for value in l1ll1l_l1_):
			if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"࠭ๅิๆึ่ࠬ旌") not in title:
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭旍"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭旎") in title:
				title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ族") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ旐"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ旑"),url)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ旒"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ旓"),url)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠢࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠥ旔"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ旕"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠩสฺ่็อสࠢࠪ旖"),l11ll1_l1_ (u"ࠪࠫ旗"))
			if title!=l11ll1_l1_ (u"ࠫࠬ旘"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ旙"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ旚")+title,l1lllll_l1_,481,l11ll1_l1_ (u"ࠧࠨ旛"),l11ll1_l1_ (u"ࠨࠩ旜"),l1ll1lll1l11l_l1_)
	return
def l1llll1l_l1_(url,l111lll_l1_):
	headers = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ旝"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ旞")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ旟"),url,l11ll1_l1_ (u"ࠬ࠭无"),headers,l11ll1_l1_ (u"࠭ࠧ旡"),l11ll1_l1_ (u"ࠧࠨ既"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ旣"))
	html = response.content
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭旤"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡳࡧ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ日"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ旦"))
	l1ll1lll1l111_l1_ = True
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡬ࡪࡵࡷࡗࡪࡧࡳࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ旧"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠭旨") not in url:
		block = l1l11l1_l1_[0]
		count = block.count(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠫ早"))
		if count==0: count = block.count(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠧ旪"))
		if count>1:
			l1ll1lll1l111_l1_ = False
			if l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂࠨࠧ旫") in block:
				items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ旬"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠸࠮ࡱࡪࡳࡃࡸࡲࡵࡨ࠿ࠪ旭")+id
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ旮"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
			else:
				items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ旯"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠰ࡳ࡬ࡵࡅࡳࡦࡴ࡬ࡩࡸࡏࡄ࠾ࠩ旰")+id
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ旱"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
	# l1l11_l1_
	if l1ll1lll1l111_l1_:
		block = l11ll1_l1_ (u"ࠩࠪ旲")
		if l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ旳") in url: block = html
		else:
			l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡫ࡰ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ旴"),html,re.DOTALL)
			if l1l111l_l1_: block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ旵"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ时"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭旷"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
	if not menuItemsLIST: l11111_l1_(l111lll_l1_,url)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ旸"))+l11ll1_l1_ (u"ࠩ࠲ࡃࡩࡵ࠽ࡸࡣࡷࡧ࡭࠭旹")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ旺"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ旻"),l11ll1_l1_ (u"ࠬ࠭旼"),l11ll1_l1_ (u"࠭ࠧ旽"),l11ll1_l1_ (u"ࠧࠨ旾"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ旿"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭昀"))
	l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡺࡴࡥࡰࡰࡵࡷࡍࡉࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ昁"),html,re.DOTALL)
	if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡ࠮ࡴࡩ࡫ࡶࡠ࠳࡯ࡤ࡝࠮࠳ࡠ࠱࠮࠮ࠫࡁࠬࡠ࠮࠭昂"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ昃"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ昄"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ昅"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱࡬ࡪࡷࡧ࡭ࡦ࠴࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ昆")+l1ll1llll1_l1_+l11ll1_l1_ (u"ࠩࠩࡺ࡮ࡪࡥࡰ࠿ࠪ昇")+l1lll111l1_l1_[2:]+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ昈")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ昉")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l11l1l1ll_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡧࡦࡶࡈࡱࡧ࡫ࡤࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ昊"),html,re.DOTALL)
	if l1lllll_l1_:
		title = SERVER(l1lllll_l1_[0],l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ昋"))
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ昌")+title+l11ll1_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ昍")
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ明"))+l11ll1_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ昏")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ昐"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭昑"),l11ll1_l1_ (u"࠭ࠧ昒"),l11ll1_l1_ (u"ࠧࠨ易"),l11ll1_l1_ (u"ࠨࠩ昔"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭昕"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡹࡧࡢ࡭ࡧ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ昖"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭昗"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ昘"))
			if l11ll1_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ昙") in l1lllll_l1_: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠧࡠࡡัหฺ࠭昚")
			else: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠨࠩ昛")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ昜")+title+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ昝")+l1lll1l1l_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ昞"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ星"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"࠭ࠧ映")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ昡"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ昢"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ昣"),l11ll1_l1_ (u"ࠪ࠯ࠬ昤"))
	if l1ll111_l1_==l11ll1_l1_ (u"ࠫࠬ春"): l1ll111_l1_ = l11l1l_l1_
	url = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ昦")+search+l11ll1_l1_ (u"࠭࠯ࠨ昧")
	l11111_l1_(url,l11ll1_l1_ (u"ࠧࠨ昨"))
	return
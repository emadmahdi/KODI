# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ仭")
headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ仮"):l11ll1_l1_ (u"ࠬ࠭仯")}
script_name = l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ仰")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭仱")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11ll1_l1_ (u"ࠨ࠵ࠪ仲"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11ll1_l1_ (u"ࠩ࠴ࠫ仳"))
	elif mode==36: results = CATEGORIES(url,l11ll1_l1_ (u"ࠪ࠶ࠬ仴"))
	elif mode==37: results = CATEGORIES(url,l11ll1_l1_ (u"ࠫ࠹࠭仵"))
	elif mode==38: results = l1l1ll1ll_l1_()
	elif mode==39: results = SEARCH(text,l1l1111_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ件"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭价"),l11ll1_l1_ (u"ࠧࠨ仸"),39,l11ll1_l1_ (u"ࠨࠩ仹"),l11ll1_l1_ (u"ࠩࠪ仺"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ任"))
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ仼"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ份"),l11ll1_l1_ (u"࠭ࠧ仾"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ仿"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ伀")+l111l1_l1_+l11ll1_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ企"),l11ll1_l1_ (u"ࠪࠫ伂"),38)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伃"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ伄")+l111l1_l1_+l11ll1_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠสิห๊าࠧ伅"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ伆"),31)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ伇"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ伈")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅษๆฯึࠦๅีษ๊ำฮ࠭伉"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ伊"),37)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伋"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ伌")+l111l1_l1_+l11ll1_l1_ (u"ࠧศใ็ห๊ࠦอิสࠣห้์ฺ่ࠩ伍"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ伎"),35)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伏"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ伐")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ็ไศ็ࠣัุฮࠠศๆ่้ะ๊ࠧ休"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭伒"),36)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭伓"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ伔")+l111l1_l1_+l11ll1_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ伕"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ伖"),32)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ众"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭优")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬำาฯํหฯ࠭伙"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࡨࡧࡱࡶࡪ࠵࠴࠰࠳ࠪ会"),32)
	return l11ll1_l1_ (u"ࠧࠨ伛")
def CATEGORIES(url,select=l11ll1_l1_ (u"ࠨࠩ伜")):
	type = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ伝"))[3]
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ伞"),l11ll1_l1_ (u"ࠫࠬ伟"),type, url)
	if type==l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ传"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"࠭ࠧ伡"),headers,l11ll1_l1_ (u"ࠧࠨ伢"),l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨ伣"))
		if select==l11ll1_l1_ (u"ࠩ࠶ࠫ伤"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࡍࡦࡰࡸࠬ࠳࠰࠿ࠪࡵࡨࡶ࡮࡫ࡳࡇࡱࡵࡱࠬ伥"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ伦"),block,re.DOTALL)
			for l1lllll_l1_,name in items:
				if l11ll1_l1_ (u"้ࠬไ๋สสฮ๋ࠥึฮๅฬࠫ伧") in name: continue
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"࠭ࠠࠨ伨"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ伩"),l111l1_l1_+name,url,32)
		if select==l11ll1_l1_ (u"ࠨ࠶ࠪ伪"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡦࡨࡸࡦ࡯࡬ࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡼ࠾࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࠫ伫"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ伬"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title in items:
				url = l11l1l_l1_ + l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭伭"))
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伮"),l111l1_l1_+title,url,32,l1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ伯"),l11ll1_l1_ (u"ࠧࠨ估"),url,l11ll1_l1_ (u"ࠨࠩ伱"))
	if type==l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ伲"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠪࠫ伳"),headers,l11ll1_l1_ (u"ࠫࠬ伴"),l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠴ࡱࡨࠬ伵"))
		if select==l11ll1_l1_ (u"࠭࠱ࠨ伶"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡇࡦࡰࡧࡩࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ伷"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ伸"),block,re.DOTALL)
			for value,name in items:
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱ࠪ伹") + value
				name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ伺"))
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伻"),l111l1_l1_+name,url,32)
		elif select==l11ll1_l1_ (u"ࠬ࠸ࠧ似"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡇࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ伽"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ伾"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ伿"))
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ佀") + value
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ佁"),l111l1_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ佂"),l11ll1_l1_ (u"ࠬ࠭佃"),url,l11ll1_l1_ (u"࠭ࠧ佄"))
	type = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ佅"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨࠩ但"),headers,l11ll1_l1_ (u"ࠩࠪ佇"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ佈"))
	if l11ll1_l1_ (u"ࠫ࡭ࡵ࡭ࡦࠩ佉") in url: type=l11ll1_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ佊")
	if type==l11ll1_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ佋"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠫ࠲࠯ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ佌"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ位"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,name in items:
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ低"))
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ住"),l111l1_l1_+name,url,32,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ佐"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ佑"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠱࠿ࠪࠤࠪ佒"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,name in items:
			name = name.strip(l11ll1_l1_ (u"ࠧࠡࠩ体"))
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ佔"),l111l1_l1_+name,url,33,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ何"):
		l1l1111_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ佖"))[-1]
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ佗"),l11ll1_l1_ (u"ࠬ࠭佘"),url,l11ll1_l1_ (u"࠭ࠧ余"))
		if l1l1111_l1_==l11ll1_l1_ (u"ࠧ࠲ࠩ佚"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠭࠴ࠫࡀࠫࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠭佛"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࠪ作"),block,re.DOTALL)
			count = 0
			for l1lllll_l1_,l1lll1_l1_,l1ll1l1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧ佝") + l1ll1l1_l1_
				url = l11l1l_l1_ + l1lllll_l1_
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ佞"),l111l1_l1_+name,url,33,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴ࠰࠭ࡃࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ佟"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸ࠧ你"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,l1ll1l1_l1_ in items:
			l1ll1l1_l1_ = l1ll1l1_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ佡"))
			title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ佢"))
			name = title + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭佣") + l1ll1l1_l1_
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ佤"),l111l1_l1_+name,url,33,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡬ࡲࡹࡱࡪ࡬ࡧࡴࡴ࠭ࡤࡪࡨࡺࡷࡵ࡮࠮ࡴ࡬࡫࡭ࡺࠨ࠯࠭ࡂ࠭ࡩࡧࡴࡢ࠯ࡵࡩࡻ࡯ࡶࡦ࠯ࡽࡳࡳ࡫ࡩࡥ࠿ࠥ࠸ࠧ࠭佥"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ佦"),block,re.DOTALL)
	for l1lllll_l1_,l1l1111_l1_ in items:
		url = l11l1l_l1_ + l1lllll_l1_
		name = l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ佧") + l1l1111_l1_
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ佨"),l111l1_l1_+name,url,32)
	return
def PLAY(url):
	if l11ll1_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ佩") in url:
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࡷ࠳࠲ࡷࡪࡸࡩࡦࡵࡏ࡭ࡳࡱ࠯ࠨ佪") + url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ佫"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ佬"),url,l11ll1_l1_ (u"ࠬ࠭佭"),headers,l11ll1_l1_ (u"࠭ࠧ佮"),l11ll1_l1_ (u"ࠧࠨ佯"),l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ佰"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠩࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ佱"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭佲"),l11ll1_l1_ (u"ࠫ࠴࠭佳"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ佴"),url,l11ll1_l1_ (u"࠭ࠧ併"),headers,l11ll1_l1_ (u"ࠧࠨ佶"),l11ll1_l1_ (u"ࠨࠩ佷"),l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ佸"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࡙ࡗࡒࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ佹"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ佺"))
	return
def SEARCH(search,l1l1111_l1_=l11ll1_l1_ (u"ࠬ࠭佻")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ佼"),l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫ佽"))
	l1l1lllll_l1_ = [l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ佾"),l11ll1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ使")]
	if not l1l1111_l1_: l1l1111_l1_ = l11ll1_l1_ (u"ࠪ࠵ࠬ侀")
	else: l1l1111_l1_,type = l1l1111_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭侁"))
	if l1ll_l1_:
		l1l11l11l_l1_ = [ l11ll1_l1_ (u"ࠬฮอฬࠢ฼๊ࠥอแๅษ่ࠫ侂") , l11ll1_l1_ (u"࠭ศฮอࠣ฽๋ࠦๅิๆึ่ฬะࠧ侃")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤ࠲ࠦวฯฬิࠤฬ๊ศฮอࠪ侄"), l1l11l11l_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lllll_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࡠࠩ侅") in options: type = l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ來")
		elif l11ll1_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࡢࠫ侇") in options: type = l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ侈")
		else: return
	headers[l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ侉")] = l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭侊")
	data = {l11ll1_l1_ (u"ࠧࡲࡷࡨࡶࡾ࠭例"):l1111ll_l1_ , l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡅࡱࡰࡥ࡮ࡴࠧ侌"):type}
	if l1l1111_l1_!=l11ll1_l1_ (u"ࠩ࠴ࠫ侍"): data[l11ll1_l1_ (u"ࠪࡪࡷࡵ࡭ࠨ侎")] = l1l1111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ侏"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭侐"),data,headers,l11ll1_l1_ (u"࠭ࠧ侑"),l11ll1_l1_ (u"ࠧࠨ侒"),l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ侓"))
	html = response.content
	items=re.findall(l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ侔"),html,re.DOTALL)
	if items:
		for title,l1lllll_l1_ in items:
			url = l11l1l_l1_ + l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭侕"),l11ll1_l1_ (u"ࠫ࠴࠭侖"))
			if l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ侗") in url: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ侘"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์็้ࠥ࠭侙")+title,url,33)
			elif l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ侚") in url:
				url = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ供"),l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࠩ侜"))
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ依"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำๅี็ࠤࠬ侞")+title,url+l11ll1_l1_ (u"࠭࠯࠲ࠩ侟"),32)
	count=re.findall(l11ll1_l1_ (u"ࠧࠣࡶࡲࡸࡦࡲࠢ࠻ࠪ࠱࠮ࡄ࠯ࡽࠨ侠"),html,re.DOTALL)
	if count:
		l1l1l1lll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll111ll_l1_ in range(1,l1l1l1lll_l1_):
			l1ll111ll_l1_ = str(l1ll111ll_l1_)
			if l1ll111ll_l1_!=l1l1111_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ価"),l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ侢")+l1ll111ll_l1_,l11ll1_l1_ (u"ࠪࠫ侣"),39,l11ll1_l1_ (u"ࠫࠬ侤"),l1ll111ll_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ侥")+type,search)
	return
def l1l1ll1ll_l1_():
	l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡡࡉࡔ࠳ࡧࡉࡵࡶࡍ࠴ࡧࡾࡩࡎࡊ࡭࡛࡚࠴࠵ࡒ࡮ࡃࡪࡥࡱ࡛࠶ࡌ࡮ࡐࡹࡐࡲࡲࡳࡍ࠴࡙࡯࡟࠸ࡖࡧ࡛࡚ࡎࡾࡒ࠲ࡩࡪࡥࡋࡋ࡛ࡖࡪ࠻ࡺࡦࡌࡌ࠵ࡣࡉ࡯ࡾࡩࡉ࠵ࡵࡏ࠶࡙࠹࠭侦")
	l1lllll_l1_ = base64.b64decode(l1lllll_l1_)
	l1lllll_l1_ = l1lllll_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ侧"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭侨"))
	return
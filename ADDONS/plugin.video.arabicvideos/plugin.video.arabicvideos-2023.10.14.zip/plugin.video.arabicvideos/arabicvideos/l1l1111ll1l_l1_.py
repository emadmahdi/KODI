# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨ屁")
def MAIN(mode,text=l11ll1_l1_ (u"ࠧࠨ层")):
	if   mode==  0: l1lll1l1l1ll1_l1_(text)
	elif mode==  2: l1ll111l1111_l1_(text)
	elif mode==  3: l1llll111l11l_l1_()
	elif mode==  4: l1lll1l1ll1l_l1_(text)
	elif mode==  5: l1lll1l1l11l1_l1_()
	elif mode==  6: l1llll111lll1_l1_()
	elif mode==  7: l1ll1l11ll1l_l1_()
	elif mode==  8: l1lll1l11l1ll_l1_()
	elif mode==  9: l1lll1l11ll1l_l1_()
	elif mode==150: l1lll11llllll_l1_()
	elif mode==151: l1lll1111l111_l1_()
	elif mode==152: l1lll1ll1l11l_l1_()
	elif mode==153: l1llll1l1ll1l_l1_()
	elif mode==154: l1llll11ll111_l1_()
	elif mode==155: l1lll1l1ll1l1_l1_()
	elif mode==156: l1lll11111l1l_l1_()
	elif mode==157: l1llll111llll_l1_()
	elif mode==158: l1lll1ll1l1ll_l1_()
	elif mode==159: l1lll11lll111_l1_(True)
	elif mode==170: l1lll11lll11l_l1_()
	elif mode==171: l1lll1llll111_l1_()
	elif mode==172: l1lll11l1l11l_l1_(text,True,True)
	elif mode==173: l11l11lll11_l1_(l11ll1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ屃"),True)
	elif mode==174: l11l11lll11_l1_(l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ屄"),True)
	elif mode==175: l1lll1ll1111l_l1_()
	elif mode==176: l1lll11l1l1l1_l1_()
	elif mode==177: l1llll11l1l1l_l1_(l11ll1_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ居"))
	elif mode==178: l1llll11l1l1l_l1_(l11ll1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ屆"))
	elif mode==179: l1llll11l1l1l_l1_(l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ屇"))
	elif mode==190: l1lll1l1l1l1l_l1_()
	elif mode==191: l1lll111llll1_l1_()
	elif mode==192: l1lll11l1l1ll_l1_()
	elif mode==193: l1lll1llll1l1_l1_()
	elif mode==194: l1lll11l11ll1_l1_()
	elif mode==195: l1lll11lllll1_l1_()
	elif mode==196: l1lll1l1l111l_l1_()
	elif mode==197: l1lll1l111l1l_l1_()
	elif mode==198: l1lll1lll1ll1_l1_()
	elif mode==199: l1lll1l1111ll_l1_()
	elif mode==340: l1lll111ll111_l1_(text)
	elif mode==341: l1l1l1ll111l_l1_()
	elif mode==342: l1lll1l1lll1l_l1_()
	elif mode==343: l1lll1l111ll1_l1_()
	elif mode==344: l1lll111lllll_l1_(True)
	elif mode==345: l1lll1ll1llll_l1_()
	elif mode==346: l1l111ll1ll_l1_(False)
	elif mode==347: l1l1l1l11l1l_l1_(True)
	elif mode==348: l1lll1llll11l_l1_()
	elif mode==349: l1llll1111lll_l1_(l1l11l11ll1l_l1_)
	elif mode==500: l1lll11l11111_l1_()
	elif mode==501: l1lll111l111l_l1_()
	elif mode==502: l1lll1lll1l1l_l1_(l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ屈"),True)
	elif mode==503: l1llll1111lll_l1_(l1l111l11l1_l1_)
	elif mode==504: l1llll1111lll_l1_(favoritesfile)
	elif mode==505: l1lll1l1lllll_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1l1llll_l1_(text,l11ll1_l1_ (u"ࠧࠨ屉"),True)
	elif mode==508: l1lll1lll1lll_l1_()
	elif mode==509: l1llll1l1l1l1_l1_()
	return
def l1llll1l1l1l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ届"),l11ll1_l1_ (u"ࠩࠪ屋"),l11ll1_l1_ (u"ࠪࠫ屌"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ屍"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧ屎"))
	if l1ll111ll1_l1_:
		l1lll111lllll_l1_(False)
		l1ll11l1ll_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ屏"),l11ll1_l1_ (u"ࠧࠨ屐"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ屑"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤฬ๊ๅึ่฼ࠫ屒"))
	return
def l1l1l1l1llll_l1_(addon_id,function,l1ll_l1_):
	# function: l11ll1_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ屓"),l11ll1_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࠬ屔"),l11ll1_l1_ (u"ࠬ࠭展")
	conn = sqlite3.connect(l1l1ll111ll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1lll11l1lll1_l1_ = l11ll1_l1_ (u"࠭ࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠩ屖")
	else: l1lll11l1lll1_l1_ = l11ll1_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸ࠭屗")
	cc.execute(l11ll1_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩ屘")+l1lll11l1lll1_l1_+l11ll1_l1_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ屙")+addon_id+l11ll1_l1_ (u"ࠪࠦࠥࡁࠧ屚"))
	l1l1111l1ll_l1_ = cc.fetchall()
	if l1l1111l1ll_l1_ and function in [l11ll1_l1_ (u"ࠫࠬ屛"),l11ll1_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ屜")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ屝"),l11ll1_l1_ (u"ࠧࠨ属"),l11ll1_l1_ (u"ࠨࠩ屟"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ屠"),l11ll1_l1_ (u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧ屡")+addon_id+l11ll1_l1_ (u"ࠫࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦๅห๊ๅๅࠥ๎ไศࠢํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ็ู๋ๆ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ屢"))
		if l1ll111ll1_l1_!=1: return
		cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫ屣")+l1lll11l1lll1_l1_+l11ll1_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ層")+addon_id+l11ll1_l1_ (u"ࠧࠣࠢ࠾ࠫ履"))
	elif function in [l11ll1_l1_ (u"ࠨࠩ屦"),l11ll1_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ屧")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ屨"),l11ll1_l1_ (u"ࠫࠬ屩"),l11ll1_l1_ (u"ࠬ࠭屪"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ屫"),l11ll1_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ屬")+addon_id+l11ll1_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣๆ฿ไ๊ࠡํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦสโ฻ํ่์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ屭"))
		if l1ll111ll1_l1_!=1: return
		if kodi_version<19: cc.execute(l11ll1_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ屮")+addon_id+l11ll1_l1_ (u"ࠪࠦ࠮ࠦ࠻ࠨ屯"))
		else: cc.execute(l11ll1_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫ屰")+addon_id+l11ll1_l1_ (u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬ山"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ屲"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ屳"),l11ll1_l1_ (u"ࠨࠩ屴"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ屵"),l11ll1_l1_ (u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧ屶"))
	if function in [l11ll1_l1_ (u"ࠫࠬ屷"),l11ll1_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ屸")]: l1lll11lll111_l1_(l1ll_l1_)
	return
def l1lll1l1lllll_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ屹"),l11ll1_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ屺"))
	l1l1ll11ll1l_l1_ = l11l1lll11l_l1_(False)
	l1lllllll1l1_l1_ = l11ll1_l1_ (u"ࠨ࡞ࡱࠫ屻")
	l1llll1ll111l_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ屼")
	l1llll1l1lll1_l1_ = l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ屽")
	for id,l1l11l11l1l1_l1_,l1l11lll111l_l1_,l111l11llll_l1_,l111l111lll_l1_,reason in reversed(l1l1ll11ll1l_l1_):
		if id==l11ll1_l1_ (u"ࠫ࠵࠭屾"):
			l1llll1lll1l_l1_,l1llll1llll1_l1_ = l111l11llll_l1_.split(l11ll1_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ屿"))
			continue
		if l1lllllll1l1_l1_!=l11ll1_l1_ (u"࠭࡜࡯ࠩ岀"): l1lllllll1l1_l1_ += l1llll1l1lll1_l1_
		l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ岁")+id+l11ll1_l1_ (u"ࠨࠢ࠽ࠤࠬ岂")+l11ll1_l1_ (u"ࠩสุ่สวๅࠢ࠽ࠤࠬ岃")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ岄")+l1l11lll111l_l1_
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅฮ๋หอࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ岅")+l111l11llll_l1_
		l111l1lll11l_l1_ = l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ岆")+l111l111lll_l1_
		l111l1lll1l1_l1_ = l11ll1_l1_ (u"࠭࡜࡯࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ือฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ岇")+reason
		l1lllllll1l1_l1_ += l1ll11l11ll_l1_+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ岈")+l1llll1ll111l_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ岉")+l111l1lll11l_l1_+l111l1lll1l1_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ岊")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ岋"),l1llll1llll1_l1_,l1lllllll1l1_l1_,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ岌"))
	return
def l1llll1111lll_l1_(file):
	if file==favoritesfile: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"่่ࠬศศ่ࠤฬ๊ๅโุ็อࠬ岍")
	elif file==l1l11l11ll1l_l1_: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"࠭วๅำึหห๊ࠧ岎")
	elif file==l1l111l11l1_l1_: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"ࠧใ๊สส๊ࠦยฯำࠣห้็๊ะ์๋๋ฬะࠧ岏")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ岐"),l11ll1_l1_ (u"่ࠩืา࠭岑"),l11ll1_l1_ (u"ࠪษฺ๊วฮࠩ岒"),l11ll1_l1_ (u"ࠫำื่อࠩ岓"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ岔"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ岕")+l1lll1ll11l11_l1_+l11ll1_l1_ (u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ岖"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岗"),l11ll1_l1_ (u"ࠩࠪ岘"),l11ll1_l1_ (u"ࠪࠫ岙"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ岚"),l11ll1_l1_ (u"ࠬ࠭岛"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ岜"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠๆๆไࠤࠬ岝")+l1lll1ll11l11_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岞"),l11ll1_l1_ (u"ࠩࠪ岟"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭岠"),l11ll1_l1_ (u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫ岡")+l1lll1ll11l11_l1_)
	return
def l1lll111l111l_l1_():
	if kodi_version<18:
		message = l11ll1_l1_ (u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨ岢")+str(kodi_version)+l11ll1_l1_ (u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧ岣")
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ岤"),l11ll1_l1_ (u"ࠨࠩ岥"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ岦"),message)
		return
	l111l1l1111_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭岧"))
	l1l11l1lllll_l1_ = l1lll1l11l1l_l1_([l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ岨")])
	l1l11l11111l_l1_,l1llll1111l11_l1_,l1llll1111ll1_l1_,l1llll1111l1l_l1_,l1llll11111l1_l1_,l1lll111l1lll_l1_,l1llll11111ll_l1_ = l1l11l1lllll_l1_[l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ岩")]
	if l1l11l11111l_l1_ or l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ岪") not in str(l111l1l1111_l1_):
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ岫"),l11ll1_l1_ (u"ࠨࠩ岬"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ岭"),l11ll1_l1_ (u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ岮"))
		succeeded = l1lll1lll1l1l_l1_(l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ岯"),True)
		if not succeeded: return
	l11l1l11l1l_l1_(True)
	return
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠭ࠩࠋࠋ࡬ࡪࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅ࠿ࡀࠫ࠺࠺࠴ࠨ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨࠌࠌࡩࡱ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠷࠸ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้฻่าࠩࠍࠍࡪࡲࡳࡦ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠๆฮ๊์้ฯࠧࠋࠋ࡬ࡪࠥࡩࡨࡰ࡫ࡦࡩࡂࡃ࠰࠻ࠋࠌࠧࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠭ࠊࠊࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡸ࡬ࡩࡼࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࠊࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧࡼࡩࡦࡹࠥࠤ࡜ࡎࡅࡓࡇࠣࡺ࡮࡫ࡷࡎࡱࡧࡩࠥࡃࠠ࠲࠻࠺࠵࠶࠽ࠠ࠼ࠩࠬࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠼࠶࠱࠺࠳ࠤࡀ࠭ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎ࡫࡬ࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠶ࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࠧ࠶࠶࠷ࠫࠎࠩࠠࠣࡎ࡬ࡷࡹࠦࡅ࡮ࡣࡧࠦࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠳࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠺࠻ࠧࠊࠥࠣࠦࡌࡧ࡬࡭ࡧࡵࡽࡤࡋ࡭ࡢࡦࠥࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠬ࠲ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠬࠎࠎࠨࠢࠣ岰")
def l11l1l11l1l_l1_(l1ll_l1_=True):
	l111l1l1111_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ岱"))
	if l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭岲") not in str(l111l1l1111_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岳"),l11ll1_l1_ (u"ࠩࠪ岴"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭岵"),l11ll1_l1_ (u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ岶"))
		return
	l1llll111ll11_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ岷"),l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ岸"),l11ll1_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ岹"),l11ll1_l1_ (u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩ岺"))
	if not os.path.exists(l1llll111ll11_l1_): return
	l1l1111111l_l1_ = open(l1llll111ll11_l1_,l11ll1_l1_ (u"ࠩࡵࡦࠬ岻")).read()
	if kodi_version>18.99: l1l1111111l_l1_ = l1l1111111l_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ岼"))
	l1lll1111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ岽"),l1l1111111l_l1_,re.DOTALL)
	l1lll111ll1l1_l1_,l1llll1l1ll11_l1_ = l1lll1111lll1_l1_[0]
	l1llll11ll1ll_l1_ = l11ll1_l1_ (u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭岾")+l1lll111ll1l1_l1_+l11ll1_l1_ (u"࠭ࠬࠨ岿")+l1llll1l1ll11_l1_+l11ll1_l1_ (u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ峀")
	if l1ll_l1_:
		l1llll11lll11_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭峁"))
		if l1llll11lll11_l1_==l11ll1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ峂"): l11l1llllll_l1_ = l11ll1_l1_ (u"ࠪๆํอฦๆࠢส่่ะวษหࠪ峃")
		elif l1llll11lll11_l1_==l11ll1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ峄"): l11l1llllll_l1_ = l11ll1_l1_ (u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ峅")
		else: l11l1llllll_l1_ = l11ll1_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ峆")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ峇"),l11ll1_l1_ (u"ࠨไ๋หห๋ࠠฤะิํࠬ峈"),l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ峉"),l11ll1_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ峊"),l11ll1_l1_ (u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ峋")+l11l1llllll_l1_,l11ll1_l1_ (u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ峌"))
		if choice==1: l1lll1ll111l1_l1_ = l11ll1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ峍")
		elif choice==2: l1lll1ll111l1_l1_ = l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭峎")
		else: l1lll1ll111l1_l1_ = l11ll1_l1_ (u"ࠨࠩ峏")
	else:
		l1llll11lll11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ峐"))
		if   l1llll11lll11_l1_==l11ll1_l1_ (u"ࠪࠫ峑"): choice = 0
		elif l1llll11lll11_l1_==l11ll1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ峒"): choice = 1
		elif l1llll11lll11_l1_==l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ峓"): choice = 2
		l1lll1ll111l1_l1_ = l1llll11lll11_l1_
	if   choice==0: l1lll1l1l1l11_l1_ = l11ll1_l1_ (u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪ峔")
	elif choice==1: l1lll1l1l1l11_l1_ = l11ll1_l1_ (u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫ峕")
	elif choice==2: l1lll1l1l1l11_l1_ = l11ll1_l1_ (u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬ峖")
	else: return
	settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ峗"),l1lll1ll111l1_l1_)
	l1lll11l111l1_l1_ = l11ll1_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ峘")+l1lll1l1l1l11_l1_+l11ll1_l1_ (u"ࠫ࠱࠭峙")+l1llll1l1ll11_l1_+l11ll1_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ峚")
	l11llll11ll_l1_ = l1l1111111l_l1_.replace(l1llll11ll1ll_l1_,l1lll11l111l1_l1_)
	if kodi_version>18.99: l11llll11ll_l1_ = l11llll11ll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ峛"))
	open(l1llll111ll11_l1_,l11ll1_l1_ (u"ࠧࡸࡤࠪ峜")).write(l11llll11ll_l1_)
	LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ峝"),l11ll1_l1_ (u"ࠩ࠱ࠤ࡙ࠥ࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧ峞")+l1lll1l1l1l11_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭峟"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪ峠"))
	return
def l1lll11l11111_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭峡"),l11ll1_l1_ (u"࠭ใๅษࠪ峢"),l11ll1_l1_ (u"ࠧ็฻่ࠫ峣"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ峤"),l11ll1_l1_ (u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ峥"))
	if l1ll111ll1_l1_==1: l1ll1l11ll1l_l1_()
	return
def l1lll1l11l1ll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ峦"),l11ll1_l1_ (u"ࠫࠬ峧"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ峨"),l11ll1_l1_ (u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩ峩"))
	return
def l1lll1llll11l_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ峪")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧ峫")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ峬")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ峭")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨ峮")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ峯")
	message = l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ峰")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬ峱")+l1ll11l1l11_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ峲"),l11ll1_l1_ (u"ࠩࠪ峳"),message)
	return
def l1l111ll1ll_l1_(l1l11l1llll_l1_):
	try: status = l111l11l11l_l1_(l1l11l1llll_l1_,False)
	except: pass
	l1l1ll11ll1l_l1_ = l11l1lll11l_l1_(l1l11l1llll_l1_)
	id,l1l11l11l1l1_l1_,l1l11lll111l_l1_,l111l11llll_l1_,l111l111lll_l1_,reason = l1l1ll11ll1l_l1_[0]
	l1llll1lll1l_l1_,l1llll1llll1_l1_ = l111l11llll_l1_.split(l11ll1_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ峴"))
	l1ll11l1l11_l1_,l111l1lll11l_l1_,l111l1lll1l1_l1_ = l111l111lll_l1_.split(l11ll1_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ峵"))
	l1l11l111lll_l1_ = True
	while l1l11l111lll_l1_:
		l1lll1l11llll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭島"),l11ll1_l1_ (u"࠭ฮา๊ฯࠫ峷"),l11ll1_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ峸"),l11ll1_l1_ (u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩ峹"),l11ll1_l1_ (u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮ่ࠥๅࠡสส่ฯฮัฺࠢฦ์ࠥอๅิฯࠣห้ฮั็ษ่ะ๋ࠥๆࠡฮ๊หื้ࠧ峺"),l1ll11l1l11_l1_)
		if l1lll1l11llll_l1_==2: l1lll1l11lll1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ峻"),l11ll1_l1_ (u"ࠫࠬ峼"),l11ll1_l1_ (u"ࠬ฿่ะหࠪ峽"),l11ll1_l1_ (u"࠭ࠧ峾"),l11ll1_l1_ (u"ࠧศๆส฽ฯืวืࠢ฼่๎ࠦๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭峿"),l111l1lll11l_l1_,l11ll1_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ崀"))
		elif l1lll1l11llll_l1_==1: l1ll111l1111_l1_()
		else: l1l11l111lll_l1_ = False
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭崁"))
	return
def l1lll111lllll_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ崂"),l11ll1_l1_ (u"ࠫࠬ崃"),l11ll1_l1_ (u"ࠬ࠭崄"),l11ll1_l1_ (u"࠭ำลษ็ࠫ崅"),l11ll1_l1_ (u"่ࠧๆࠣว๋ะࠠๆฬฦ็ิ่ࠦหำํำ๋ࠥำฮ๋ࠢฮฺ็๊าࠢฯ้๏฿ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦอ๋อࠣฮ฾๎ฯࠡฮ่๎฾ࠦวๅว฼ำฬีวหࠢศ่๎่ࠦื฻ํอࠥะหษ์อࠤฬ๊ศา่ส้ัࠦฟࠨ崆"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_:
		succeeded = True
		if os.path.exists(l1ll1111111l_l1_):
			try: os.remove(l1ll1111111l_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ崇"),l11ll1_l1_ (u"ࠩࠪ崈"),l11ll1_l1_ (u"ࠪࠫ崉"),l11ll1_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ崊"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭崋"),l11ll1_l1_ (u"࠭ࠧ崌"),l11ll1_l1_ (u"ࠧࠨ崍"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨ崎"))
	return
def l1lll1ll1llll_l1_():
	l1lll1l1l1l1l_l1_()
	l1llll1l1111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ崏"))
	message = {}
	message[l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ崐")] = l11ll1_l1_ (u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪ崑")
	message[l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ崒")] = l11ll1_l1_ (u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ崓")
	message[l11ll1_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ崔")] = l11ll1_l1_ (u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩ崕")+str(l11llll111l_l1_/60)+l11ll1_l1_ (u"ࠩࠣำ็๐โสࠢไๆ฼࠭崖")
	l1lll11ll1lll_l1_ = message[l1llll1l1111l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ崗"),l11ll1_l1_ (u"่ࠫอิࠡࠩ崘")+str(l11llll111l_l1_/60)+l11ll1_l1_ (u"ࠬࠦฯใ์ๅอࠬ崙"),l11ll1_l1_ (u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ崚"),l11ll1_l1_ (u"ࠧฦ์ๅหๆࠦใศ็็ࠫ崛"),l1lll11ll1lll_l1_,l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫ崜"))
	if choice==0: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ崝")
	elif choice==1: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ崞")
	elif choice==2: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ崟")
	else: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠬ࠭崠")
	if l1lll11ll1l11_l1_:
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ崡"),l1lll11ll1l11_l1_)
		l1lll11l1l111_l1_ = message[l1lll11ll1l11_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ崢"),l11ll1_l1_ (u"ࠨࠩ崣"),l11ll1_l1_ (u"ࠩࠪ崤"),l1lll11l1l111_l1_)
	return
def l1lll1l111ll1_l1_():
	message = {}
	message[l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ崥")] = l11ll1_l1_ (u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩ崦")
	message[l11ll1_l1_ (u"ࠬࡇࡓࡌࠩ崧")] = l11ll1_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪ崨")
	message[l11ll1_l1_ (u"ࠧࡔࡖࡒࡔࠬ崩")] = l11ll1_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ崪")
	l1llll11l111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ崫"))
	l1llll1l1111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ崬"))
	l1lll11ll1lll_l1_ = message[l1llll1l1111l_l1_]+l1llll11l111l_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ崭"),l11ll1_l1_ (u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ崮"),l11ll1_l1_ (u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ崯"),l11ll1_l1_ (u"ࠧฦ์ๅหๆࠦใศ็็ࠫ崰"),l1lll11ll1lll_l1_,l11ll1_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬ崱"))
	if choice==0: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭崲")
	elif choice==1: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ崳")
	elif choice==2: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ崴")
	if choice in [0,1]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ崵"),l11ll1_l1_ (u"࠭ำ๋ำไี࠿ࠦࠧ崶")+l1llll1l1lll_l1_[1],l11ll1_l1_ (u"ࠧิ์ิๅึࡀࠠࠨ崷")+l1llll1l1lll_l1_[0],l11ll1_l1_ (u"ࠨࠩ崸"),l11ll1_l1_ (u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨ崹"))
		if l1ll111ll1_l1_==1: l111ll11111_l1_ = l1llll1l1lll_l1_[0]
		else: l111ll11111_l1_ = l1llll1l1lll_l1_[1]
	elif choice==2: l111ll11111_l1_ = l11ll1_l1_ (u"ࠪࠫ崺")
	else: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠫࠬ崻")
	if l1lll11ll1l11_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ崼"),l1lll11ll1l11_l1_)
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭崽"),l111ll11111_l1_)
		l1lll11l1l111_l1_ = message[l1lll11ll1l11_l1_]+l111ll11111_l1_
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ崾"),l11ll1_l1_ (u"ࠨࠩ崿"),l11ll1_l1_ (u"ࠩࠪ嵀"),l1lll11l1l111_l1_)
	return
def l1lll1l1lll1l_l1_():
	l1llll1l1111l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ嵁"))
	message = {}
	message[l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ嵂")] = l11ll1_l1_ (u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭嵃")
	message[l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ嵄")] = l11ll1_l1_ (u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨ嵅")
	message[l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭嵆")] = l11ll1_l1_ (u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ嵇")
	l1lll11ll1lll_l1_ = message[l1llll1l1111l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ嵈"),l11ll1_l1_ (u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩ嵉"),l11ll1_l1_ (u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ嵊"),l11ll1_l1_ (u"࠭ล๋ไสๅ้ࠥวๆๆࠪ嵋"),l1lll11ll1lll_l1_,l11ll1_l1_ (u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪ嵌"))
	if choice==0: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠨࡃࡖࡏࠬ嵍")
	elif choice==1: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ嵎")
	elif choice==2: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ嵏")
	else: l1lll11ll1l11_l1_ = l11ll1_l1_ (u"ࠫࠬ嵐")
	if l1lll11ll1l11_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ嵑"),l1lll11ll1l11_l1_)
		l1lll11l1l111_l1_ = message[l1lll11ll1l11_l1_]
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嵒"),l11ll1_l1_ (u"ࠧࠨ嵓"),l11ll1_l1_ (u"ࠨࠩ嵔"),l1lll11l1l111_l1_)
	return
def l1lll1lll1lll_l1_():
	l1l11l1l11l1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ嵕"))
	if l1l11l1l11l1_l1_==l11ll1_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ嵖"): header = l11ll1_l1_ (u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪ嵗")
	else: header = l11ll1_l1_ (u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪ嵘")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ嵙"),l11ll1_l1_ (u"ࠧฦ์ๅหๆ࠭嵚"),l11ll1_l1_ (u"ࠨฬไ฽๏๊ࠧ嵛"),header,l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠหใ฼๎้ࠦรๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡมࠤࠥࠬ嵜"))
	if l1ll111ll1_l1_==-1: return
	elif l1ll111ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ嵝"),l11ll1_l1_ (u"ࠫࠬ嵞"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嵟"),l11ll1_l1_ (u"࠭ࠧ嵠"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嵡"),l11ll1_l1_ (u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪ嵢"))
	else:
		settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ嵣"),l11ll1_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ嵤"))
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嵥"),l11ll1_l1_ (u"ࠬ࠭嵦"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嵧"),l11ll1_l1_ (u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩ嵨"))
	return
def l1lll1l1l1ll1_l1_(text):
	if text!=l11ll1_l1_ (u"ࠨࠩ嵩"):
		text = l1l1l11ll1l_l1_(text)
		text = text.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ嵪")).encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ嵫"))
		l1l1l1l1111_l1_ = 10103
		l1l1l11lll1_l1_ = xbmcgui.l1l1l111ll1_l1_(l1l1l1l1111_l1_)
		l1l1l11lll1_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l1111l11_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡏࡪࡿࡢࡰࡣࡵࡨ࠷࠸࠮ࡹ࡯࡯ࠫ嵬"), xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠬࡶࡡࡵࡪࠪ嵭")).decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ嵮")),l11ll1_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ嵯"),l11ll1_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭嵰"))
		#l1l1l1111l11_l1_.show()
		#l1l1l1111l11_l1_.getControl(99991).setPosition(0,0)
		#l1l1l1111l11_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l1111l11_l1_.getControl(5).l1lll11lllll_l1_(l1llll111ll1l_l1_)
		#width = xbmcgui.l1lll11ll1111_l1_()
		#l1ll11ll1l1l_l1_ = xbmcgui.l1lll1ll1l111_l1_()
		#resolution = (0.0+width)/l1ll11ll1l1l_l1_
		#l1l1l1111l11_l1_.getControl(5).l1l11lll1ll1_l1_(width-180)
		#l1l1l1111l11_l1_.getControl(5).setHeight(l1ll11ll1l1l_l1_-180)
		#l1l1l1111l11_l1_.doModal()
		#del l1l1l1111l11_l1_
	return
l1lll111lll11_l1_ = [
			 l11ll1_l1_ (u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࠭ࠧࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢ嵱")
			,l11ll1_l1_ (u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭嵲")
			,l11ll1_l1_ (u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭嵳")
			,l11ll1_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧ嵴")
			,l11ll1_l1_ (u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧ嵵")
			,l11ll1_l1_ (u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩ嵶")
			,l11ll1_l1_ (u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠣࡴࡵ࡯࠱ࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠭嵷")
			,l11ll1_l1_ (u"ࠩࡌࡲࡸ࡫ࡣࡶࡴࡨࡖࡪࡷࡵࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪ࠰ࠬ嵸")
			,l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࠳ࡄࡳ࡯ࡥࡧࡀ࠴ࠫࡺࡥࡹࡶࡀࠫ嵹")
			,l11ll1_l1_ (u"ࠫࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠴ࡷࡢࡴࡱࠬࠬ嵺")
			,l11ll1_l1_ (u"ࠬࡤ࡞࡟ࡠࡡࠫ嵻")
			,l11ll1_l1_ (u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫ嵼")
			]
def l1lll1l11l11l_l1_(line):
	if l11ll1_l1_ (u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬ嵽") in line and l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭嵾") in line: return True
	for text in l1lll111lll11_l1_:
		if text in line: return True
	return False
def l1lll1111l1ll_l1_(data):
	data = data.replace(l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ嵿")+51*l11ll1_l1_ (u"ࠪࠤࠬ嶀")+l11ll1_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ嶁"),l11ll1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ嶂"))
	data = data.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ嶃")+51*l11ll1_l1_ (u"ࠧࠡࠩ嶄")+l11ll1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭嶅"),l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ嶆"))
	data = data.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭嶇")+51*l11ll1_l1_ (u"ࠫࠥ࠭嶈")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ嶉"),l11ll1_l1_ (u"࠭࡜࡯ࠩ嶊"))
	data = data.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嶋")+51*l11ll1_l1_ (u"ࠨࠢࠪ嶌"),l11ll1_l1_ (u"ࠩ࡟ࡲࠬ嶍")+31*l11ll1_l1_ (u"ࠪࠤࠬ嶎"))
	#data = data.replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣ࠱ࡶࡸࡴࡸࡡࡨࡧ࠲ࡩࡲࡻ࡬ࡢࡶࡨࡨ࠴࠶࠯ࡂࡰࡧࡶࡴ࡯ࡤ࠰ࡦࡤࡸࡦ࠵࡯ࡳࡩ࠱ࡼࡧࡳࡣ࠯࡭ࡲࡨ࡮࠵ࡦࡪ࡮ࡨࡷ࠴࠴࡫ࡰࡦ࡬࠳ࡦࡪࡤࡰࡰࡶ࠳ࠬ嶏"),l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠪ嶐"))
	data = data.replace(l11ll1_l1_ (u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬ嶑"),l11ll1_l1_ (u"ࠧ࠻ࠢࠪ嶒"))
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠨࠩ嶓")
	for line in data.splitlines():
		delete = re.findall(l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠯ࠫࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ嶔"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11ll1_l1_ (u"ࠪࠫ嶕"))
		l11ll11l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ嶖")+line
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭嶗"),l11ll11l1_l1_)
	return l11ll11l1_l1_
def l1lll111ll111_l1_(l1lll1ll111ll_l1_):
	if l11ll1_l1_ (u"࠭ࡏࡍࡆࠪ嶘") in l1lll1ll111ll_l1_:
		l1llll11l11l1_l1_ = l1lll1l1l11l_l1_
		header = l11ll1_l1_ (u"ࠧใำสลฮࠦวๅีฯ่ࠥอไใัํ้ࠥลࠧ嶙")
	else:
		l1llll11l11l1_l1_ = l1ll1lllll11_l1_
		header = l11ll1_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅฯส่๏ࠦฟࠨ嶚")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ嶛"),l11ll1_l1_ (u"ࠪࠫ嶜"),l11ll1_l1_ (u"ࠫࠬ嶝"),header,l11ll1_l1_ (u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ嶞"))
	if l1ll111ll1_l1_!=1: return
	l1lll1111llll_l1_,counts = [],0
	size,count = l1l1l11ll1_l1_(l1llll11l11l1_l1_)
	#size = os.path.getsize(l1llll11l11l1_l1_)
	file = open(l1llll11l11l1_l1_,l11ll1_l1_ (u"࠭ࡲࡣࠩ嶟"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嶠"))
	data = l1lll1111l1ll_l1_(data)
	lines = data.split(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ嶡"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ嶢"))
		#if line.strip(l11ll1_l1_ (u"ࠪࠤࠬ嶣"))==l11ll1_l1_ (u"ࠫࠬ嶤"): continue
		ignore = l1lll1l11l11l_l1_(line)
		if ignore: continue
		line = line.replace(l11ll1_l1_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡣࠬ嶥"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶦"))
		line = line.replace(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡀࠧ嶧"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋ࠶࠰࠱࠲ࡠࡉࡗࡘࡏࡓ࠼࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嶨"))
		l1lll1ll11l1l_l1_ = l11ll1_l1_ (u"ࠩࠪ嶩")
		l1lll111ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ嶪"),line,re.DOTALL)
		if l1lll111ll1ll_l1_:
			line = line.replace(l1lll111ll1ll_l1_[0][0],l1lll111ll1ll_l1_[0][1]).replace(l1lll111ll1ll_l1_[0][2],l11ll1_l1_ (u"ࠫࠬ嶫"))
			l1lll1ll11l1l_l1_ = l1lll111ll1ll_l1_[0][1]
		else:
			l1lll111ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ嶬"),line,re.DOTALL)
			if l1lll111ll1ll_l1_:
				line = line.replace(l1lll111ll1ll_l1_[0][1],l11ll1_l1_ (u"࠭ࠧ嶭"))
				l1lll1ll11l1l_l1_ = l1lll111ll1ll_l1_[0][0]
		if l1lll1ll11l1l_l1_: line = line.replace(l1lll1ll11l1l_l1_,l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ嶮")+l1lll1ll11l1l_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嶯"))
		l1lll1111llll_l1_.append(line)
		if len(str(l1lll1111llll_l1_))>50100: break
	l1lll1111llll_l1_ = reversed(l1lll1111llll_l1_)
	l1llll111ll1l_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡲࠬ嶰").join(l1lll1111llll_l1_)
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ嶱"),l11ll1_l1_ (u"ࠫวิัࠡลึ฻ึࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠨ嶲"),l1llll111ll1l_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ嶳"))
	return
def l1lll1l1111ll_l1_():
	l1llll11l11ll_l1_ = open(l1ll1111lll1_l1_,l11ll1_l1_ (u"࠭ࡲࡣࠩ嶴")).read()
	if kodi_version>18.99: l1llll11l11ll_l1_ = l1llll11l11ll_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嶵"))
	l1llll11l11ll_l1_ = l1llll11l11ll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡷࠫ嶶"),l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠠࠡࠢࠣࠫ嶷"))
	l1l11l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡻࡢࡤ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠫ嶸"),l1llll11l11ll_l1_,re.DOTALL)
	for line in l1l11l1lllll_l1_:
		l1llll11l11ll_l1_ = l1llll11l11ll_l1_.replace(line,l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ嶹")+line+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶺"))
	DIALOG_TEXTVIEWER(l11ll1_l1_ (u"࠭วๅฬ฽๎๏ืวหࠢส่ศิ๊าหࠣๅ๏ࠦวๅสิห๊าࠧ嶻"),l1llll11l11ll_l1_)
	return
def l1lll1lll1ll1_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠧษ฻ูࠤฬ๊รำำสีࠥ฿ไ๊ࠢส่ึ๐ๅ้ฬࠣ็ํ์สา๊็ࠤฯ๎แาࠢศ้่อๆ๋หࠣฮ็ี๊ๆ๋ࠢฮศิ๊าࠢส่ๆ๐ฯ๋๊ࠣ์์ึ็ࠡษ็วืืวา๊ࠢ๎ࠥอไฤี๊้ࠥ๎วๅลิๆฬ๋ࠠๆ฻ࠣฬ฾฼้ࠠๅส่ฯอไ๋ࠩ嶼")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠨๆอๆิ๐ๅࠡษ็ๅ๏ี๊้ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎๊๐ๆ๊ࠡ็ฮศิ๊า้ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏ูวาࠢ࠱ࠤศ๋วࠡ฻าอࠥอำ่็้ࠣฯะวๅ์ฬࠤๆํะ่ࠢอๆํ๋ࠠษฬะี๏้ࠠศๆไ๎ิ๐่ࠡส๋ๆฯࠦวไสิࠤ๊์้ࠠไอࠤฬ๊ำ่็ࠣห้๎วฮัࠣ࠲ࠥษๅศࠢสุ่ํๅࠡษ็ว฾๊้๊ࠡส่ศูแๅࠢไ๋ํ๊ࠦฮำๆࠤฬ๊แ๋ัํ์ࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวย๋่่ࠢ์ࠠษไไึฮࠦใษ์ิอࠬ嶽")
	l111l1lll11l_l1_ = l11ll1_l1_ (u"ࠩฦ้ฬࠦวๅลิๆฬ๋ࠠโ้ํࠤฯูสฯั่ࠤ้๊สใัํ้ࠥ๎วๅฬฦา๏ื้ࠠๆๆ๊ࠥฮๅใัสีࠥ฿ฯะࠢส่ะ๎ว็์ࠣ์ฬ๊ฯใษษๆࠥ࠴ࠠๆอ็หࠥืโๆࠢ࠸࠸࠹ࠦสฺ่ํࠤ࠺ࠦฯใษษๆࠥ๎ࠠ࠵࠶ࠣฯฬ์๊สࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦࠦศฮีหࠤฬูสฯัส้่ࠦไๅี๊้ࠥอไ๋็ํ๊ࠥษ่ࠡี๊้ࠥอไ๋ีสีࠬ嶾")
	message = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭嶿")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠫࠥ࠴ࠠࠨ巀")+l111l1lll11l_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ巁"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ巂"),message,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ巃"))
	return
def l111ll1111l_l1_(type,message,l1ll_l1_=True,url=l11ll1_l1_ (u"ࠨࠩ巄"),source=l11ll1_l1_ (u"ࠩࠪ巅"),text=l11ll1_l1_ (u"ࠪࠫ巆"),l111lll1llll_l1_=l11ll1_l1_ (u"ࠫࠬ巇")):
	l1lll11111ll1_l1_ = True
	if not l11lll1llll_l1_(l11ll1_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭巈")):
		if l1ll_l1_:
			#if message.count(l11ll1_l1_ (u"࠭࡜࡝ࡰࠪ巉"))>1: l1ll11l11l1l_l1_ = l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭巊")
			#else: l1ll11l11l1l_l1_ = l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ巋")
			l1lll11l111ll_l1_ = (l11ll1_l1_ (u"ࠩสุ่฽ั࠻ࠩ巌") in message and l11ll1_l1_ (u"ࠪห้๋ใศ่࠽ࠫ巍") in message and l11ll1_l1_ (u"ࠫฬ๊ๅๅใ࠽ࠫ巎") in message and l11ll1_l1_ (u"ࠬอไฯูฦࠫ巏") in message and l11ll1_l1_ (u"࠭วๅ็ุำึࡀࠧ巐") in message)
			if not l1lll11l111ll_l1_: l1lll11111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ巑"),l11ll1_l1_ (u"ࠨࠩ巒"),l11ll1_l1_ (u"ࠩࠪ巓"),l11ll1_l1_ (u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧ巔"),message.replace(l11ll1_l1_ (u"ࠫࡡࡢ࡮ࠨ巕"),l11ll1_l1_ (u"ࠬࡢ࡮ࠨ巖")))
	elif l1ll_l1_:
		message = l11ll1_l1_ (u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭巗")
		l1llll1l11l11_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ巘"),l11ll1_l1_ (u"ࠨࠩ巙"),l11ll1_l1_ (u"ࠩࠪ巚"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ巛")+l11ll1_l1_ (u"ࠫࠥࠦ࠱࠰࠷ࠪ巜"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ川"))
		l1llll1l111ll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭州"),l11ll1_l1_ (u"ࠧࠨ巟"),l11ll1_l1_ (u"ࠨࠩ巠"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ巡")+l11ll1_l1_ (u"ࠪࠤࠥ࠸࠯࠶ࠩ巢"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ巣"))
		l1llll1l111l1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ巤"),l11ll1_l1_ (u"࠭ࠧ工"),l11ll1_l1_ (u"ࠧࠨ左"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ巧")+l11ll1_l1_ (u"ࠩࠣࠤ࠸࠵࠵ࠨ巨"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ巩"))
		l1llll1l11lll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ巪"),l11ll1_l1_ (u"ࠬ࠭巫"),l11ll1_l1_ (u"࠭ࠧ巬"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ巭")+l11ll1_l1_ (u"ࠨࠢࠣ࠸࠴࠻ࠧ差"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ巯"))
		l1lll11111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ巰"),l11ll1_l1_ (u"ࠫࠬ己"),l11ll1_l1_ (u"ࠬ࠭已"),l11ll1_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭巳")+l11ll1_l1_ (u"ࠧࠡࠢ࠸࠳࠺࠭巴"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭巵"))
	user = l1l11l111ll_l1_(32,False)
	l1llll111111l_l1_ = l11ll1_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ巶")+user+l11ll1_l1_ (u"ࠪ࠱ࠬ巷")+type
	l1l11l1ll11l_l1_ = True if l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ巸") in text else False
	if not l1lll11111ll1_l1_:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭巹"),l11ll1_l1_ (u"࠭ࠧ巺"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ巻"),l11ll1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫ巼"))
		return False
	l1llll1l1l111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨ巽"))
	message += l11ll1_l1_ (u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ巾")+l11llll11l1_l1_+l11ll1_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ巿")
	message += l11ll1_l1_ (u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭帀")+user+l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ币")+l1l111l1l1l_l1_+l11ll1_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭市")
	message += l11ll1_l1_ (u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭布")+l1llll1l1l111_l1_
	#l1l111l1111_l1_ = l11lll111l1_l1_(l11ll1_l1_ (u"ࠩ࠺࠺࠳࠼࠵࠯࠳࠶࠼࠳࠸࠳࠱ࠩ帄"))
	l1lllll1l111_l1_ = l11lll111l1_l1_()
	l1lllll1l111_l1_ = QUOTE(l1lllll1l111_l1_)
	if l1lllll1l111_l1_: message += l11ll1_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬ帅")+l1lllll1l111_l1_
	if url: message += l11ll1_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨ帆")+url
	if source: message += l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬ帇")+source
	message += l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ师")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠧอษิ๎ࠥอไฦำึห้࠭帉"),l11ll1_l1_ (u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪ帊"))
	if l111lll1llll_l1_:
		l1llll111ll1l_l1_ = l111lll1llll_l1_
		if kodi_version>18.99: l1llll111ll1l_l1_ = l1llll111ll1l_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ帋"))
		l1llll111ll1l_l1_ = base64.b64encode(l1llll111ll1l_l1_)
	elif l1l11l1ll11l_l1_:
		if l11ll1_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ希") in text: l1llll1l11111_l1_ = l1lll1l1l11l_l1_
		else: l1llll1l11111_l1_ = l1ll1lllll11_l1_
		if not os.path.exists(l1llll1l11111_l1_):
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ帍"),l11ll1_l1_ (u"ࠬ࠭帎"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ帏"),l11ll1_l1_ (u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬ帐"))
			return False
		l1lll1111llll_l1_,counts = [],0
		size,count = l1l1l11ll1_l1_(l1llll1l11111_l1_)
		#size = os.path.getsize(l1llll1l11111_l1_)
		file = open(l1llll1l11111_l1_,l11ll1_l1_ (u"ࠨࡴࡥࠫ帑"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ帒"))
		data = l1lll1111l1ll_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ帓"))
			ignore = l1lll1l11l11l_l1_(line)
			if ignore: continue
			l1lll111ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ帔"),line,re.DOTALL)
			if l1lll111ll1ll_l1_:
				line = line.replace(l1lll111ll1ll_l1_[0][0],l1lll111ll1ll_l1_[0][1]).replace(l1lll111ll1ll_l1_[0][2],l11ll1_l1_ (u"ࠬ࠭帕"))
			else:
				l1lll111ll1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭帖"),line,re.DOTALL)
				if l1lll111ll1ll_l1_: line = line.replace(l1lll111ll1ll_l1_[0][1],l11ll1_l1_ (u"ࠧࠨ帗"))
			l1lll1111llll_l1_.append(line)
			if len(str(l1lll1111llll_l1_))>121000: break
		l1lll1111llll_l1_ = reversed(l1lll1111llll_l1_)
		l1llll111ll1l_l1_ = l11ll1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭帘").join(l1lll1111llll_l1_)
		l1llll111ll1l_l1_ = l1llll111ll1l_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ帙"))
		l1llll111ll1l_l1_ = base64.b64encode(l1llll111ll1l_l1_)
	else: l1llll111ll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ帚")
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ帛")][2]
	payload = {l11ll1_l1_ (u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭帜"):l1llll111111l_l1_,l11ll1_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧ帝"):message,l11ll1_l1_ (u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ帞"):l1llll111ll1l_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭帟"),url,payload,l11ll1_l1_ (u"ࠩࠪ帠"),l11ll1_l1_ (u"ࠪࠫ帡"),l11ll1_l1_ (u"ࠫࠬ帢"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨ帣"))
	#succeeded = response.succeeded
	html = response.content
	if l11ll1_l1_ (u"࠭ࠢࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠥ࠾ࠥ࠷ࠬࠨ帤") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠧห็ࠣห้หัิษ็ࠫ帥"),l11ll1_l1_ (u"ࠨส้ะฬำࠧ带"))
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ帧"),l11ll1_l1_ (u"ࠪࠫ帨"),l11ll1_l1_ (u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪ帩"),l11ll1_l1_ (u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧ帪"))
		else:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"࠭ไๅลึๅࠬ師"),l11ll1_l1_ (u"ࠧโึ็ࠤๆ๐ࠠศๆศีุอไࠨ帬"))
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ席"),l11ll1_l1_ (u"ࠩࠪ帮"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭帯"),l11ll1_l1_ (u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩ帰"))
	return succeeded
def l1lll1111l111_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪ帱")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡษ็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ帲")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ帳"),l11ll1_l1_ (u"ࠨࠩ帴"),l11ll1_l1_ (u"ࠩࡄࡶࡦࡨࡩࡤࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪ帵"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ帶")+l1ll11l1l11_l1_)
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠫ࠷࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡡ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠪ帷")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠬ࠸࠮ࠡࠢࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแใ็ࠣฬฯเ๊๋ำࠣห้าไะࠢฮ้่ࠥๅࠡสอ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠศๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬ常")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ帹"),l11ll1_l1_ (u"ࠧࠨ帺"),l11ll1_l1_ (u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧ帻"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ帼")+l1ll11l1l11_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ帽"),l11ll1_l1_ (u"ࠫࠬ帾"),l11ll1_l1_ (u"ࠬ࠭帿"),l11ll1_l1_ (u"࠭ࡆࡰࡰࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭幀"),l11ll1_l1_ (u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡴ࡯ࡸࠢࡂࠫ幁")+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭幂")+l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ึ็ศสࠣษ้๏ࠠๅ๊ะอࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣว้ศๆภࠩ幃"))
	if l1ll111ll1_l1_==1: l1llll111lll1_l1_()
	return
def l1llll1l1ll1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ幄"),l11ll1_l1_ (u"ࠫࠬ幅"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ幆"),l11ll1_l1_ (u"ฺ࠭ศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠥ๎ไๅฬฦ็ิࠦโๆࠢหฮูเ๊ๅࠢส่ึอศุࠢส่ี๐ࠠๅษࠣ๎฾๋ไࠡอ่ࠤ็๋ࠠษวิืฬ๊ࠠๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠศๆๅหห๋ษࠡษ็ีห๐ำ๋ห่้ࠣฮั็ษ่ะࠬ幇"))
	return
def l1llll11ll111_l1_():
	message = l11ll1_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ัࠦๅฯืุࠤๆ่ืࠡๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠๆๆ๊ࠥํะศࠢ็หࠥ๐ๅ็฻ࠣ์ั๎ฯࠡ็๋ห็฿ࠠโ์๊หࠥษแๅษ่ࠤํ๋ำๅี็หฯࠦๅหำฯ้ฮࠦร้่ࠢำอ๊ฬสࠢศ่๎ࠦวๅๆ฽อࠥอไฺำห๎ฮ่ࠦศๆ์ࠤ้เวหࠢสาึ๏้ࠠๆสࠤ๏๎ฬะࠢึฬอࠦไๅฬๆีฬืࠧ幈")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ幉"),l11ll1_l1_ (u"ࠩࠪ幊"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幋"),message)
	return
def l1lll1l1ll1l1_l1_():
	message = l11ll1_l1_ (u"ࠫฬ๊ั้ษห฻ࠥอไษูํสฮࠦไศࠢ฼่ฬ่ษࠡๆ๊หࠥฮวๅสิ๊ฬ๋ฬ๊ࠡ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬࠨ幌")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭幍"),l11ll1_l1_ (u"࠭ࠧ幎"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ幏"),message)
	return
def l1lll11111l1l_l1_():
	message = l11ll1_l1_ (u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬ幐")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ幑"),l11ll1_l1_ (u"ࠪࠫ幒"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ幓"),l11ll1_l1_ (u"ู๊ࠬาใิหฯࠦำ๋ศฬࠤศ๎ࠠๆฮ๊์้ฯࠧ幔"),message)
	return
def l1llll111llll_l1_():
	message = l11ll1_l1_ (u"࠭วๅีํีๆืวหࠢส่฾อๅส๊ࠢ๎ู๊ࠥาใิหฯࠦฮศำฯ๎ฮ่ࠦ฻์ิࠤฯอศฺห่้๋่ࠣใ฻ࠣห้ษีๅ์ࠣ์ัฺ๋๊ࠢส่๊๎วใ฻ࠣฮุะฮะ็๊หࠥ๎ูศัฬࠤฯ้่็่ࠢะฬ์๊สู๋้ࠢอใๅ้สࠤ่ั๊าห่ࠣฬ์ࠠศๆไ๎ิ๐่่ษอࠤๆ๐็ศࠢศ้ฬࠦศุ์ษอࠥษ่ࠡ็่๊ํ฿ษࠡล๋ࠤ๊ำะ้ใฬࠤศ๎ࠠโ์๊ห๋ࠥิไๆฬࠤา่่ใࠢส่๊๊ใ๋ห࡟ࡲࡡࡴ࡜࡯ษ็ื๏ืแาษอࠤฬ๊ฮศืฬࠤ์๐ࠠิ์ิๅึอสࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠ็ึฮำีๅสࠢไ๎๋่ࠥศไ฼ࠤ็๊๊ๅหࠣะิอ้ࠠ฻สำฮࠦสไ๊้ࠤ๊ีแ้฻ฬࠤฬ๊รอำࠣวํ๊ࠦๆๆๆ๋ฬࠦวๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๅ้ำหࠥ็็๋ࠢฯ๎ิฯࠠ็ีห๎ฬ่ࠦิำํ฽ฮ่ࠦๆึส็้ํวࠡไ็๎้ฯࠠอัสࠫ幕")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ幖"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ幗"),message,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ幘"))
	return
def l1lll1ll1l1ll_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊ฯใหࠣห้฿วๅ์ฬࠫ幙")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥษไࠡ࡯࠶ࡹ࠽࠭幚")
	l111l1lll11l_l1_ = l11ll1_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅฬะ้๏๊้ࠠษ็ำฬ๎ๆๅ๊าࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭幛")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ幜"),l11ll1_l1_ (u"ࠧࠨ幝"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ幞"),l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111l1lll11l_l1_)
	return
def l1lll1l1l1l1l_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪ幟")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ幠") + l11ll1_l1_ (u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪ幡") + str(PERMANENT_CACHE/60/60/24/30) + l11ll1_l1_ (u"ࠬࠦิ่ำࠪ幢")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࠩ幣") + l11ll1_l1_ (u"ࠧ࠳࠰ࠣะิอุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไๆใิ์฻ࠦร็้สࠤ้อࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭幤") + str(VERYLONG_CACHE/60/60/24) + l11ll1_l1_ (u"ࠨࠢํ์๊࠭幥")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ幦") + l11ll1_l1_ (u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ幧") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"ࠫࠥ๐่ๆࠩ幨")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ幩") + l11ll1_l1_ (u"࠭࠴࠯่ࠢฮํูืࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦโะࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ幪") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ࠧࠡีส฽ฮ࠭幫")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ幬") + l11ll1_l1_ (u"ࠩ࠸࠲่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠะษษ้ฬ่ࠦๆัอ๋ࠥ࠭幭") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ࠪࠤุอูสࠩ幮")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ幯") + l11ll1_l1_ (u"ࠬ࠼࠮ࠡฮาห่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠไอํีฬ่ࠦๆัอ๋ࠥ࠭幰") + str(l1ll11ll11l1_l1_/60) + l11ll1_l1_ (u"࠭ࠠะไํๆฮ࠭幱")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ干") + l11ll1_l1_ (u"ࠨ࠹࠱ࠤอี่็ࠢๆหูࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤอูัฺหࠣ์๊ีส่ࠢࠪ平") + str(NO_CACHE) + l11ll1_l1_ (u"ࠩࠣำ็๐โสࠩ年")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ幵") + l11ll1_l1_ (u"๊ࠫัไศ࠼ูࠣๆำวหࠢๅ์ฬฬๅࠡษ็วๆ๊วๆ๋ࠢห้๋ำๅี็หฯ่ࠦศๆะ่็อสࠡ฻่ี์อࠠࠨ并") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ࠬࠦำศ฻ฬࠤ࠳ࠦรๆษࠣๆํอฦๆࠢฦ๊ํอูࠡษ็ๅ๏ี๊้้สฮࠥ็ูๆำ๊หࠥ࠭幷") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"࠭ࠠฤ์ส้ࠥ࠴ࠠฤ็สࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤๆ฿ๅา้สࠤࠬ幸") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ࠧࠡีส฽ฮࠦแใูࠣ࠲ࠥษๅศࠢไัฺࠦัใ็ࠣห้หีะษิࠤๆ฿ๅา้ࠣࠫ幹") + str(l1ll11ll11l1_l1_/60) + l11ll1_l1_ (u"ࠨࠢาๆ๏่ษࠡ࠰ࠣว๊อࠠโฯุࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠣๅ฾๋ั่ࠢࠪ幺") + str(NO_CACHE) + l11ll1_l1_ (u"ࠩࠣำ็๐โสࠩ幻")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ幼"),l11ll1_l1_ (u"๊ࠫอ่๊ࠠࠣห้้วีࠢสู่๊สฯั่ࠤๆ๐ࠠศๆหี๋อๅอࠩ幽"),l1ll11l1l11_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ幾"))
	return
def l1lll111llll1_l1_():
	message = l11ll1_l1_ (u"࠭วๅใสู้ฯࠠห฻้๎๋ࠥฬๅัࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏่ࠦศๆ้ๆ฼ฯࠠห฻้๎ࠥษๆࠡษ็หุ๋ࠠศๆฦู้๐ࠠห็ࠣฮ฾ี๊ๅ้ࠣ์ๆอีๅหࠣ์๋่ืสࠢอ฽๋๏ࠠๆฮ็ำࠥ๎สๆࠢอ฽ิ๐ไࠡษึ้์่ࠦษั๋๊ࠥ฿ไศ็ฬࠤฯ฿ๆ๋่่ࠢๆࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋ࠩ广")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ庀"),l11ll1_l1_ (u"ࠨࠩ庁"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庂"),message)
	return
def l1lll11l1l1ll_l1_():
	message = l11ll1_l1_ (u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫ広")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ庄"),l11ll1_l1_ (u"ࠬ࠭庅"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ庆"),message)
	return
def l1lll1llll1l1_l1_():
	message = l11ll1_l1_ (u"ࠧศๆ฽ี฻ࠦๅ็ࠢื๋ฬีษࠡษ็ฮู็๊า๊ࠢ์ࠥ฼ๅศู่ࠣาฯ้ࠠีิ๎ฮࠦวๅ็฼่ํ๋วหࠢส่๊ะศศั็อࠥฮ๊็ࠢส่อืๆศ็ฯࠤํอไๆ๊ๅ฽ࠥอไๆึไีࠥ๎็ัษࠣห้฼ๅศ่ࠣ฾๏ืࠠๆู็์อ่ࠦๅษࠣัฬาษࠡๆ๊ࠤ฾์ฯࠡษ็หฯ฻วๅࠢส์ࠥอไาสฺࠤ๊฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎็ศฬࠣห้๋ิโำฬࠫ庇")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ庈"),l11ll1_l1_ (u"ࠩࠪ庉"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭床"),message)
	return
def l1lll11l11ll1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ庋"),l11ll1_l1_ (u"ࠬ࠭庌"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ庍"),l11ll1_l1_ (u"ࠧๅๅํࠤ๏฿ๅๅ๊ࠢิฬࠦวๅ่๋฽๋ࠥๆࠡษ็ๅ๏ี๊้้สฮࠥࡢ࡮ࠡ์ฯฬࠥะแฺ์็ࠤส฼วโหࠣหุ๋็ศࠢ࡟ࡲࠥ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ庎"))
	l11l11lll11_l1_(l11ll1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ序"),True)
	return
def l1lll11lllll1_l1_():
	message  = l11ll1_l1_ (u"่ࠩศำืวࠡไส้ฯࠦศฺุุࠣึ้วหࠢส่ส์สา่อࠤฬ๊ฯ้ๆํࠤอ๎ึฺࠢ฼หห่ࠠืัࠣห้ฮัศ็ฯࠤ๊ัไࠡๅ๋ำ๏ࠦไหี่ัࠥ็โุࠢ็ฬ฾฼ࠠๆีอาิ๋๊ࠡษ็้ฯ฻แฮࠢหห้ีฮ้ๆ่๊ࠣ๎วใ฻ࠣห้็๊ะ์๋ࠫ庐")
	#message += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝้้ำหࠥอไฺษษๆࠥํ่ࠡࡴࡨࡇࡆࡖࡔࡄࡊࡄࠤฬ๊ฮศืࠣฬูืใสࠢฯ์ั๊࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰࠪ庑")
	#message += l11ll1_l1_ (u"ࠫํอไั์ู๋ࠣ฿ส่ࠢืี่ฯࠠอ๊ฯ่ࠥิี๋ืสࠤ้๋ๆฺࠢหีฬ๋ฬࠡ็ฮ่้่ࠥะ์้๋ࠣࠦสึใะࠤฬ๊ล็ฬิ๊ฯ࠭庒")
	message += l11ll1_l1_ (u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬ库")
	message += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠไࠥࠦࡖࡑࡐࠣࠤศ๎ࠠࠡࡒࡵࡳࡽࡿࠠࠡล๋ࠤࠥࡊࡎࡔࠢࠣวํࠦร๋ࠢะ่ࠥฮำู๋ࠣฦำื࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰࠪ应")
	message += l11ll1_l1_ (u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧ底")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ庖"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ店"),message,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭庘"))
	message = l11ll1_l1_ (u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ庙")
	message += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ庚")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡣ࡮ࡳࡦࡳࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠠࠡ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠤࠥࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠤࠥࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ庛")
	message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ府")+l11ll1_l1_ (u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩ庝")
	message += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ庞")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋ีาࠢࠣห้้่๋ฬࠣࠤศ๋๊าๅสࠤ้ࠥๆะษࠣࠤๆืๆิษࠣࠤฬ๊๊้่ส๊ࠥࠦศา์ฺห๋๐วࠡษ็ษ๊อัศฬࠣว้๋ว็์สࠤึ๎ำ๋ษࠣห้๐วษษ้ࠤฬ๊ำฺ๊า๎ฮࠦั้็ส๊๏อ่๊ࠠ็๊ิอ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ废")
	message += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ庠")+l11ll1_l1_ (u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭庡")
	message += l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ษิื้ࠦัิษ็อ๋ࠥฤะสฬࠤส๊้ࠡษ็้อืๅอ๋ࠢห่ะศࠡใํ๋ฬࠦวิ็ࠣฬ้ีใ๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮุะื๋฻ࠣำำ๎ไ่ษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ庢")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭庣"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ庤"),message,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ庥"))
	#l1ll111l1111_l1_(l11ll1_l1_ (u"ࠪࡍࡸࡖࡲࡰࡤ࡯ࡩࡲࡃࡆࡢ࡮ࡶࡩࠬ度"))
	#message = l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ座")+l11ll1_l1_ (u"ࠬ๎ไใั่ࠣฬำุ็ษࠣห๏฼วࠡล้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦสฯฬ็ๅࠥฮวฯฬ็หๆࠦวๅส็ำࠥ๎สฯฬ็ๅࠥฮวฯฬ็หๆࠦิาๅฬࠤฬ๊ว็ฬิ๊๏ะࠠโ์ࠣิ้้ࠠศๆห่ิ่่ࠦาสࠤ๊฿ๆศ้ࠣห๋ํࠠฮฬ์ࠤ้๎ࠠห็ࠣหุะฮะษ่ࠤ࡛ࡖࡎࠡล๋ࠤࡕࡸ࡯ࡹࡻࠣวํࠦร๋๋ࠢื๏๊ษࠡษัี๎ࠦแศ่ࠣห้๋่ศไ฼ࠤฬ๊ๅฺษๅอู่ࠥโࠢอาฯ๊แ๊ࠡ็็๋ํวࠡๆ้ࠤฯ฿ๅๅࠢฯ้๏฿็ศࠩ庨")
	#message += l11ll1_l1_ (u"࠭ไฮๆࠣห้๋ิไๆฬࠤ็๋ࠠษ฻่่๏์࠺ࠡࠢࠣࠤฬ๊ร้ๆ࠽ࠤศืำๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอ้๋ࠢࠫࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠯้ࠠษๆฮอࠦๅฺ้ࠣหุ๋ࠠษๆา็ࠥ๎วิ็ุࠣึ้ษࠡษ็ษ๋ะั็์อࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสฺ็็ࠤ฾์ฯไࠩ庩")
	#message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ庪")+l11ll1_l1_ (u"ࠨ๊ส่ะอๆ๋࠼ࠣะึฮࠠศีอาิอๅࠡࡘࡓࡒࠥ๎ู็ัࠣห้ฮูืࠢๅำࠥะอหษฯࠤๆ่ืࠡฬ฽๎๏ืࠠࡅࡐࡖࠤํอไฤฯึ๊ࠥษๆࠡ์ๆ์๋ࠦแ๋ࠢห่ิࠦวฯำࠣ฽้๋วࠡษ้ࠤฬูสฯัส้ࠥࡖࡲࡰࡺࡼࠤ็ี๋ࠠฯ็ࠤฺ๊ใๅหࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡ็็๋ࠦไ๋ีࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ฯ้ๆࠪ庫")
	#DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ุ่่๊ࠩษࠡ฻้ำࠥฮูืࠢส่๋อำࠨ庬"),message)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ庭"),l11ll1_l1_ (u"ࠫๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠧ庮"),l11ll1_l1_ (u"ࠬํะศࠢส่ๆำี้๋ࠡࠤู้๋าใฬࠤ์๊ࠠศๆุ่่๊ษࠡ็้ࠤ฾์ฯไࠢส้๋ࠥๆࠡษ็ฬึ์วๆฮ࠱ࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬๆำีࠡ็๋ห็฿็ࠡ็ิฮ๏์ࠠศๆฦ์้๏ࠠษู๊฽่ࠦวๅูห๎฾๐้ࠠษ็ฯฬ์๊สࠢหหุะฮะษ่ࠤอื่ไีํࠤ๊าว็์ࠣห๋ะࠠหะอหึํࠠๆ่ࠣห้่วว็ฬࠤฬ๊ส๋ࠢึฮ฽ํัࠡๆสั็อ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีฤ࠭庯"),l11ll1_l1_ (u"࠭ࠧ庰"),l11ll1_l1_ (u"ࠧࠨ庱"),l11ll1_l1_ (u"ࠨๅ็หࠬ庲"),l11ll1_l1_ (u"้ࠩ฽๊࠭庳"))
	#if l1ll111ll1_l1_==1:
	#l1lll1ll1111l_l1_()
	return
def l1lll1l1l111l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ庴"),l11ll1_l1_ (u"ࠫࠬ庵"),l11ll1_l1_ (u"ࠬัไศอࠣ฻ึ่ࠠๅๆอ์ฬ฻ไࠡ็฼ࠤฬ๊ๅษำ่ะࠬ庶"),l11ll1_l1_ (u"࠭ราี็ࠤึูวๅหࠣวํࠦๅีๅ็อ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦ็ัษࠣห้ฮั็ษ่ะࡡࡴ࡜࡯ล๋ࠤออำหะาห๊ࠦวๅใํือ๎ใࠡลา๊ฬํ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭康"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ庸"),l11ll1_l1_ (u"ࠨࠩ庹"),l11ll1_l1_ (u"ࠩࡅࡆࡇࡈࡂࡃࡄࡅࡆࡇࠦࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ庺"),l11ll1_l1_ (u"ࠪ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࡢ࡮࡝ࡰ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࡥ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ庻"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ庼"),l11ll1_l1_ (u"ࠬ࠭庽"),l11ll1_l1_ (u"࠭ࡂࡃࡄࡅࡆࡇࡈࡂࡃࡄࠣࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庾"),l11ll1_l1_ (u"ࠧ࠱ࠢ࠳ࠤ࠵ࠦ࠰ࠡ࠲ࠣ࠵ࠥ࠷ࠠ࠲ࠢ࠴ࠤ࠶ࠦ࠲ࠡ࠴ࠣ࠶ࠥ࠸ࠠ࠳ࠢ࠶ࠤ࠸ࠦ࠳ࠡ࠵ࠣ࠷ࠥ࠺ࠠ࠵ࠢ࠷ࠤ࠹ࠦ࠴ࠡ࠷ࠣ࠹ࠥ࠻ࠠ࠶ࠢ࠸ࠤ࠻ࠦ࠶ࠡ࠸ࠣ࠺ࠥ࠼ࠠ࠸ࠢ࠺ࠤ࠼ࠦ࠷ࠡ࠹ࠣ࠼ࠥ࠾ࠠ࠹ࠢ࠻ࠤ࠽ࠦ࠹ࠡ࠻ࠣ࠽ࠥ࠿ࠠ࠺ࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࡡࡍࡎࡏࡐࡊ࠲ࡡࡎࡏࡐࡑࡋ࠲ࡡࡏࡐࡑࡒࡌ࠲ࡡࡐࡑࡒࡓࡍ࠲ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤࡆࡇࡁࡂࡃ࠵ࡣࡇࡈࡂࡃࡄ࠵ࡣࡈࡉࡃࡄࡅ࠵ࡣࡉࡊࡄࡅࡆ࠵ࡣࡊࡋࡅࡆࡇ࠵ࡣࡋࡌࡆࡇࡈ࠵ࡣࡌࡍࡇࡈࡉ࠵ࡣࡍࡎࡈࡉࡊ࠵ࡣࡎࡏࡉࡊࡋ࠵ࡣࡏࡐࡊࡋࡌ࠵ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࠤ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇࠠࡃࡄࡅࡆࡇ࠭庿"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ廀"),l11ll1_l1_ (u"ࠩࠪ廁"),l11ll1_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ廂"),l11ll1_l1_ (u"ࠫ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠪ廃"))
	#text = l11ll1_l1_ (u"ࠬ࠮ࠠࡂࡃࡄࡅࡆ࠷࡟ࡃࡄࡅࡆࡇ࠷࡟ࡄࡅࡆࡇࡈ࠷࡟ࡅࡆࡇࡈࡉ࠷࡟ࡆࡇࡈࡉࡊ࠷࡟ࡇࡈࡉࡊࡋ࠷࡟ࡈࡉࡊࡋࡌ࠷࡟ࡉࡊࡋࡌࡍ࠷࡟ࡊࡋࡌࡍࡎ࠷ࠠࠪࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࠣࡳࠥࡶࠠࡲࠢࡵࠤࡸࠦࡴࠡࡷࠣࡺࠥࡽࠠࡹࠢࡼࠤࡿࠦ࠰ࠡ࠳ࠣ࠶ࠥ࠹ࠠ࠵ࠢ࠸ࠤ࠻ࠦ࠷ࠡ࠺ࠣ࠽ࠥࡧࠠࡣࠢࡦࠤࡩࠦࡥࠡࡨࠣ࡫ࠥ࡮ࠠࡪࠢ࡭ࠤࡰࠦ࡬ࠡ࡯ࠣࡲࠥࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠥࡼࠠࡸࠢࡻࠤࡾࠦࡺࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠨ廄")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ廅"),l11ll1_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ廆"),l11ll1_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ廇"),l11ll1_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ廈"),l11ll1_l1_ (u"ࠪ࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷࠸࠲࠳࠴࠵ࠫ廉"),text,l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭廊"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭廋"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭廌"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ廍"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ廎"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭廏"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ廐"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ廑"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廒"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭廓"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ廔"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廕"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ廖"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ廗"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ廘"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廙"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭廚"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廛"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廜"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࠪ廝"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ廞"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ廟"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ廠"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉ࡞ࡱࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭廡"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ廢"))
	return
def l1lll1l11ll1l_l1_():
	l1lll1l1l1l1l_l1_()
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ廣"),l11ll1_l1_ (u"ࠩࠪ廤"),l11ll1_l1_ (u"ࠪࠫ廥"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠศๆๆหูࠦฟࠨ廦"),l11ll1_l1_ (u"ࠬอไไษืࠤ๏ูัฺࠢ฼้้ࠦวๅสิ๊ฬ๋ฬ๊่ࠡืาํ๋ࠠ฻ํำูࠥอษࠢสฺ่็อศฬ้๋ࠣࠦวๅว้ฮึ์สࠡ฻้ำࠥอไฮษฯอࠥหไ๋้สࠤํอไๆีะࠤ๏ะๅࠡฬ็ๆฬฬ๊ศࠢ฼๊ิࠦว็ฬ๊หฦูࠦๆำࠣห้฻แฮษอࠤํอไๆีะࠤ้อุ๋ࠠิࠤํ๋ๅไ่ࠣ๎า๊ࠠษ฻ูࠤฬ๊ๅีษๆ่ࠬ廧"))
	if l1ll111ll1_l1_==1:
		l11l1111111_l1_(True)
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ廨"),l11ll1_l1_ (u"ࠧࠨ廩"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠษษ็็ฬ๋ไࠨ廪"),l11ll1_l1_ (u"ࠩศิฬࠦใศ่อࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬำฯࠡษ็้ํอโฺࠢไะึฮࠠศๆ่์็฿ࠠศๆล๊ࠥ࠴࠮࠯๋ࠢวีอࠠศๆุ่่๊ษࠡ็ึฮ๊ืษࠡใศิ๋ࠦวาี็ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ廫"))
	return l1ll111ll1_l1_
def l1lll1l1ll1l_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ廬"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪ廭"),l11ll1_l1_ (u"ࠬ࠭廮"),l11ll1_l1_ (u"࠭ࠧ廯"),False,l11ll1_l1_ (u"ࠧࠨ廰"),l11ll1_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ廱"))
	#html = response.content
	if not response.succeeded:
		l1lll11lll1ll_l1_ = False
		l11l1lll1l_l1_ = l11l1l1ll1_l1_()
		LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ廲"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨ廳")+l11l1lll1l_l1_+l11ll1_l1_ (u"ࠫࡢ࠭廴"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭廵"),l11ll1_l1_ (u"࠭ࠧ延"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ廷"),l11ll1_l1_ (u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ廸"))
	else:
		l1lll11lll1ll_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ廹"),l11ll1_l1_ (u"ࠪࠫ建"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ廻"),l11ll1_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ廼"))
	if not l1lll11lll1ll_l1_ and l1ll_l1_: l1lll1ll1l11l_l1_()
	return l1lll11lll1ll_l1_
def l1lll1ll1l11l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ廽"),l11ll1_l1_ (u"ࠧࠨ廾"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ廿"),l11ll1_l1_ (u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨ开"))
	#l1ll11l1l11_l1_ = l11ll1_l1_ (u"ุࠪ์อฯสࠢส่ฯฺแ๋ำ๋ࠣ๏ࠦๅๅใࠣ๎าะ่๋ࠢ฼่๎ࠦิโำฬࠤำอีสࠢฦ์ࠥะ่ศไํ฽ࠥิวึหู่ࠣืใศฬ้ࠣ฾ื่โหࠣ์้ํࠠหษิ๎ำࠦีๅษะ๎ฮ่ࠦ็ใสิࠥ๎วๅ฼ิฺ๋ࠥๆ่๊ࠢ์ࠥะศศั็ࠤฬ๊ๅฺๆ๋้ฬะࠠษูิ๎็ฯࠠๆึไีฮ๊ࠦึ฻หࠤฬิสาษๅ๋ฬ่ࠦโ้่๋ฬ࠭弁")
	l1lll1llll1ll_l1_()
	return
def l1ll111l1111_l1_(text=l11ll1_l1_ (u"ࠫࠬ异")):
	l1l11l1ll11l_l1_ = True
	if l11ll1_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ弃") not in text:
		l1l11l1ll11l_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭弄"),l11ll1_l1_ (u"ࠧฯำ๋ะࠬ弅"),l11ll1_l1_ (u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭弆"),l11ll1_l1_ (u"ࠩศีุอไࠡำึห้ฯࠧ弇"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭弈"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧ弉"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l11l1ll11l_l1_ = True
			text = l11ll1_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ弊")
	if l1l11l1ll11l_l1_:
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭弋"),l11ll1_l1_ (u"ࠧࠨ弌"),l11ll1_l1_ (u"ࠨࠩ弍"),l11ll1_l1_ (u"ࠩศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪ弎"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠีอ฻๏฿ࠠศๆ่ฬึ๋ฬࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡศู้ออ่ษࠪ式"))
		#if not l1ll111ll1_l1_:
		#	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ弐"),l11ll1_l1_ (u"ࠬ࠭弑"),l11ll1_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠩ弒"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦศะ๊้ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦวๅ็หี๊าࠠๅษࠣ๎ุะื๋฻้ࠣ฾ืแสࠢสฺ่๊ใๅหࠣ์้อࠠฮๆ๊ห๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ弓"))
		#	return
		l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡶࡨࡼࡹࠦࠫ࠾ࠢࠪࡰࡴ࡭ࡳ࠾ࡻࡨࡷࠬࠐࠉࠊࠋࡼࡩࡸࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠ࡛ࡈࡗࡓࡕࠨࠨࡥࡨࡲࡹ࡫ࡲࠨ࠮๋้ࠪࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ࠯ࠫ็ฮไࠡษิืฬ๊ࠠิฮ็ࠤฬ๊วฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าฺࠠๆํ็ࠥอๆࠡฬๅ์๊ࠦศหึ฽๎้ࠦวๅใํำ๏๎ࠠศ๊ࠣห้ืวษูࠣห้ึ๊ࠡ์฼฻๏้ࠠศๆุ่่๊ษࠡๆๆ๎ࠥ๐สๆࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ฬิืศรࠣ์ฬ๊วิฬัำฬ๋࠮้ࠡ็ࠤฯื๊ะࠢส่ฬืำศๆࠣห้อๆࠡมࠪ࠰ࠬ࠭ࠬࠨࠩ࠯่๊ࠫวࠨ࠮๊ࠪ฾๋ࠧࠪࠌࠌࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠰࠻ࠌࠌࠍࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬะๅࠡษ็฾ฬวࠠศๆสีุอไࠨࠫࠍࠍࠎࠏࠉࡳࡧࡷࡹࡷࡴࠠࠨࠩࠍࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ࠯ࠫฬึวࠡๅส๊ฯࠦไะ์ๆࠤฺ๊ใๅหࠣๅฬ๊ัอษฤࠤ็ืวยหࠣๆุ๋ࠠศๆุ่ฬ้ไ๊ࠡส่ฬูฦๅหࠣ์ฬึวࠡๆ่ࠤฯาฯࠡษ็ั้ࠦ็็ษๆࠤๆำว้ๆࠣ็ฯอศสࠢฯ้๏฿ࠠหใสู๏๊ࠠศๆุ่่๊ษࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠩࠋࠋࠌࠦࠧࠨ弔")
		if l11ll1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩ引") not in text:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ弖"),l11ll1_l1_ (u"ࠫࠬ弗"),l11ll1_l1_ (u"ࠬ࠭弘"),l11ll1_l1_ (u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭弙"),l11ll1_l1_ (u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧ弚"))
			if l1ll111ll1_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ弛"),l11ll1_l1_ (u"ࠩࠪ弜"),l11ll1_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭弝"),l11ll1_l1_ (u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ弞"))
				return
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭弟"),l11ll1_l1_ (u"࠭ࠧ张"),l11ll1_l1_ (u"ࠧไฬสฬฮ่ࠦีำะࠤฬ๊ๅุ้๋฽๊ࠥไๆสิ้ั࠭弡"),l11ll1_l1_ (u"ࠨใํࠤฬ๊ิศึฬࠤฬ๊โศั่อࠥำว้ๆࠣว๋ࠦสไฬหࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡสุึำࠠโ์๊หࠥอไๆึๆ่ฮࠦร้ࠢส่๊๎ึ้฻ࠣ์สึวࠡลิำฯࠦฬ้ษหࠤ๊์ࠠศๆ่ฬึ๋ฬࠡใศิ๋ࠦรไฬหࠤ฾์่ศ่ࠣฬึ๐ฯไࠢฦ่ส๊ใหำ๋๊๏ࠦวๅษํ้๏๊้ࠠฬำ็ึ่ࠦๅษࠣฮู๋้ࠡล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ弢"))
	search = OPEN_KEYBOARD(header=l11ll1_l1_ (u"࡚ࠩࡶ࡮ࡺࡥࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࠤࠥࠦวไฬหࠤึูวๅหࠪ弣"),source=script_name)
	if not search: return
	message = search
	if l1l11l1ll11l_l1_: type = l11ll1_l1_ (u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠫ弤")
	else: type = l11ll1_l1_ (u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠬ弥")
	succeeded = l111ll1111l_l1_(type,message,True,l11ll1_l1_ (u"ࠬ࠭弦"),l11ll1_l1_ (u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩ弧"),text)
	#	url = l11ll1_l1_ (u"ࠧ࡮ࡻࠣࡅࡕࡏࠠࡢࡰࡧ࠳ࡴࡸࠠࡔࡏࡗࡔࠥࡹࡥࡳࡸࡨࡶࠬ弨")
	#	payload = l11ll1_l1_ (u"ࠨࡽࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ࠿ࠨࡍ࡚ࠢࡄࡔࡎࠦࡋࡆ࡛ࠥ࠰ࠧࡺ࡯ࠣ࠼࡞ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥࡡ࠱ࠨࡳࡦࡰࡧࡩࡷࠨ࠺ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࠭ࠤࡶࡹࡧࡰࡥࡤࡶࠥ࠾ࠧࡌࡲࡰ࡯ࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥ࠰ࠧࡺࡥࡹࡶࡢࡦࡴࡪࡹࠣ࠼ࠥࠫ弩")+message+l11ll1_l1_ (u"ࠩࠥࢁࠬ弪")
	#	#auth=(l11ll1_l1_ (u"ࠥࡥࡵ࡯ࠢ弫"), l11ll1_l1_ (u"ࠦࡲࡿࠠࡱࡧࡵࡷࡴࡴࡡ࡭ࠢࡤࡴ࡮ࠦ࡫ࡦࡻࠥ弬")),
	#	import requests
	#	response = requests.request(l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ弭"),url, data=payload, headers=l11ll1_l1_ (u"࠭ࠧ弮"), auth=l11ll1_l1_ (u"ࠧࠨ弯"))
	#	response = requests.post(url, data=payload, headers=l11ll1_l1_ (u"ࠨࠩ弰"), auth=l11ll1_l1_ (u"ࠩࠪ弱"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ弲"),l11ll1_l1_ (u"ࠫࠬ弳"),l11ll1_l1_ (u"ࠬ࠭弴"),l11ll1_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ張"))
	#	else:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ弶"),l11ll1_l1_ (u"ࠨࠩ強"),l11ll1_l1_ (u"ࠩั฻ศࠦแ๋ࠢส่สืำศๆࠪ弸"),l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡾࢁ࠿ࠦࡻࠢࡴࢀࠫ弹").format(response.status_code, response.content))
	#	l1lll11ll1l1l_l1_ = l11ll1_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ强")
	#	l1lll1l1l1111_l1_ = l11ll1_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ弻")
	#	header = l11ll1_l1_ (u"࠭ࠧ弼")
	#	#header += l11ll1_l1_ (u"ࠧࡇࡴࡲࡱ࠿ࠦࠧ弽") + l1lll11ll1l1l_l1_
	#	#header += l11ll1_l1_ (u"ࠨ࡞ࡱࡘࡴࡀࠠࠨ弾") + l1lll11111l11_l1_
	#	#header += l11ll1_l1_ (u"ࠩ࡟ࡲࡈࡩ࠺ࠡࠩ弿") + l1lll11111l11_l1_
	#	header += l11ll1_l1_ (u"ࠪࡠࡳ࡙ࡵࡣ࡬ࡨࡧࡹࡀࠠๆ่ࠣ็ํี๊ࠡษ็ๅ๏ี๊้ࠢส่฾ืศ๋ࠩ彀")
	#	server = l1llll11lll1l_l1_.l1lll1l111111_l1_(l11ll1_l1_ (u"ࠫࡸࡳࡴࡱ࠯ࡶࡩࡷࡼࡥࡳࠩ彁"),25)
	#	#server.l1lll1l1lll11_l1_()
	#	server.l1lll1ll11111_l1_(l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ彂"),l11ll1_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ彃"))
	#	response = server.l1lll1lll111l_l1_(l1lll11ll1l1l_l1_,l1lll1l1l1111_l1_, header + l11ll1_l1_ (u"ࠧ࡝ࡰࠪ彄") + message)
	#	server.quit()
	return
def l1llll111l11l_l1_():
	text = l11ll1_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ彅")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ彆"),l11ll1_l1_ (u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ彇"),text,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ彈"))
	text = l11ll1_l1_ (u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨ彉")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭࡬ࡦࡨࡷࠫ彊"),l11ll1_l1_ (u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬ彋"),text,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ彌"))
	return
def l1lll1l1llll1_l1_(addon_id):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ彍"),l11ll1_l1_ (u"ࠪࠫ彎"),l11ll1_l1_ (u"ࠫࠬ彏"),addon_id)
	result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ彐")+addon_id+l11ll1_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬ彑"))
	l1l11llll1_l1_ = True
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡸ࡮ࡵࡵ࡫࡯ࠎࠎࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡺࡥࡱࡨ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࡶࡵࡨࡶ࡫࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡹࡸ࡫ࡲࡧࡱ࡯ࡨࡪࡸࠬࠨࡣࡧࡨࡴࡴࡳࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠏࠏࡩࡧࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࡀࠊࠊࠋࡶ࡬ࡺࡺࡩ࡭࠰ࡵࡱࡹࡸࡥࡦࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡳࡧࡩࡶࡪࡹࡨࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨࡢࡦࡧࡳࡳࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡣࡧࡨࡴࡴࡳ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࠦࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡲࡦࡲࡲࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠣࠤࠥ归")
	if l1l11llll1_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ当"))
		time.sleep(1)
	return
def l1lll1llll111_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ彔"),l11ll1_l1_ (u"ࠪࠫ录"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ彖"),l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪ彗"))
	l1lll1llll1l1_l1_()
	return
def l1lll1llll1ll_l1_():
	#	https://l111ll11l1l_l1_.tv/download/849
	#   https://play.google.com/l1lll1l11l111_l1_/l1lll1l1ll1ll_l1_/details?id=l1llll111ll_l1_.xbmc.l111ll11l1l_l1_
	#	http://mirror.l1lll1lll1l11_l1_.l1lll11ll1ll1_l1_.l1llll1l1l1ll_l1_/l1lll1ll1lll1_l1_/xbmc/l1lll1l111l11_l1_/l1lll1111l1l1_l1_/l1lll1lll1111_l1_
	#	http://l1lll11l11lll_l1_.l1lll111l1l1l_l1_.l1llll1l1l1ll_l1_/l111ll11l1l_l1_/l1lll1l111l11_l1_/l1lll1111l1l1_l1_/l1lll1lll1111_l1_
	url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫ彘")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ彙"),url,l11ll1_l1_ (u"ࠨࠩ彚"),l11ll1_l1_ (u"ࠩࠪ彛"),l11ll1_l1_ (u"ࠪࠫ彜"),l11ll1_l1_ (u"ࠫࠬ彝"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨ彞"))
	html = response.content
	l1lll111l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬ彟"),html,re.DOTALL)
	l1lll111l11l1_l1_ = l1lll111l11l1_l1_[0].split(l11ll1_l1_ (u"ࠧ࠮ࠩ彠"))[0]
	l1llll1l11ll1_l1_ = str(kodi_version)
	#l111l1lll1l1_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ彡")+l11ll1_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠ฻ู่่๋ࠥࠡๅ๋ำ๏ࠦลึัสีࠥ࠷࠹๊่ࠡหࠥฮูะ้ࠪ形")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ彣")
	l111l1lll1l1_l1_ = l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭彤")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ彥")+l1lll111l11l1_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ彦")
	l111l1lll1l1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ彧")+l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ彨")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ彩")+l1llll1l11ll1_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ彪")
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ彫"),l11ll1_l1_ (u"ࠬ࠭彬"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ彭"),l111l1lll1l1_l1_)
	return
def l1lll11l1l1l1_l1_():
	# https://l11l1l1lll1_l1_-l111ll111l1_l1_-l111llllll1_l1_.l1llll1ll11ll_l1_.com/request-l1lll1l1l1lll_l1_
	# https://l11l1l1lll1_l1_-l111ll111l1_l1_-l111llllll1_l1_.l1llll1ll11ll_l1_.com/query-l1lll111l11ll_l1_
	l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111l1lll11l_l1_,l111l1lll1l1_l1_,l1lll1lllll1l_l1_,l1lll1111l11l_l1_,l1lll1l11111l_l1_ = l11ll1_l1_ (u"ࠧࠨ彮"),l11ll1_l1_ (u"ࠨࠩ彯"),l11ll1_l1_ (u"ࠩࠪ彰"),l11ll1_l1_ (u"ࠪࠫ影"),l11ll1_l1_ (u"ࠫࠬ彲"),l11ll1_l1_ (u"ࠬ࠭彳"),l11ll1_l1_ (u"࠭ࠧ彴")
	payload,l1lll111l1l11_l1_,l1lll1ll1ll1l_l1_,l1lll1111ll11_l1_ = {l11ll1_l1_ (u"ࠧࡢࠩ彵"):l11ll1_l1_ (u"ࠨࡣࠪ彶")},{},[],{}
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ彷")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ彸"),url,payload,l11ll1_l1_ (u"ࠫࠬ役"),l11ll1_l1_ (u"ࠬ࠭彺"),l11ll1_l1_ (u"࠭ࠧ彻"),l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ彼"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨ彽"),l11ll1_l1_ (u"ࠩࡘࡗࡆ࠭彾"))
	html = html.replace(l11ll1_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ彿"),l11ll1_l1_ (u"࡚ࠫࡑࠧ往"))
	html = html.replace(l11ll1_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ征"),l11ll1_l1_ (u"࠭ࡕࡂࡇࠪ徂"))
	html = html.replace(l11ll1_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭徃"),l11ll1_l1_ (u"ࠨࡍࡖࡅࠬ径"))
	html = html.replace(l11ll1_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ待"),l11ll1_l1_ (u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ徆"))
	html = html.replace(l11ll1_l1_ (u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ徇"),l11ll1_l1_ (u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ很"))
	html = html.replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ徉"),l11ll1_l1_ (u"ࠧࠡࠢࠪ徊"))
	try: l1lll1ll1ll11_l1_ = EVAL(l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭律"),html)
	except:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ後"),l11ll1_l1_ (u"ࠪࠫ徍"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ徎"),l11ll1_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ徏"))
		return
	l1llll11l1ll1_l1_,l1llll1l1l11l_l1_,l1lll1l1l11ll_l1_ = l1lll1ll1ll11_l1_
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ徐"),str(l1llll11l1ll1_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ徑"),str(l1llll1l1l11l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ徒"),str(l1lll1l1l11ll_l1_))
	l1lll1111ll11_l1_ = {}
	l1llll1ll1l11_l1_ = [l11ll1_l1_ (u"ࠩࡄࡐࡑ࠭従"),l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ徔"),l11ll1_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ徕"),l11ll1_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ徖"),l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ得")]+l1llllll11ll_l1_+l111l1ll111_l1_
	for l1ll111l111_l1_,l1llll11llll1_l1_,l1llll11l1l11_l1_ in l1llll1l1l11l_l1_:
		l1llll11l1l11_l1_ = escapeUNICODE(l1llll11l1l11_l1_)
		l1llll11l1l11_l1_ = l1llll11l1l11_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ徘")).strip(l11ll1_l1_ (u"ࠨࠢ࠱ࠫ徙"))
		l111l1lll1l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ徚")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ徛")+l1llll11l1l11_l1_+l11ll1_l1_ (u"ࠫࡡࡴࠧ徜")
		if l1llll11llll1_l1_.isdigit():
			l1lll1111ll11_l1_[l1ll111l111_l1_] = int(l1llll11llll1_l1_)
			if int(l1llll11llll1_l1_)>100: l1llll11llll1_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ徝")
			else: l1llll11llll1_l1_ = l11ll1_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ從")
		if l1ll111l111_l1_ not in l1llll1ll1l11_l1_:
			if   l1llll11llll1_l1_==l11ll1_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ徟"): l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠫ徠")+l1ll111l111_l1_
			elif l1llll11llll1_l1_==l11ll1_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ御"): l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࠤࠥ࠭徢")+l1ll111l111_l1_
	l1llll1ll11l1_l1_,l1lll11llll11_l1_,l1lll1l1111l1_l1_ = list(zip(*l1llll1l1l11l_l1_))
	for l1ll111l111_l1_ in sorted(l1l1llll1ll1_l1_):
		if l1ll111l111_l1_ not in l1llll1ll11l1_l1_:
			l111l1lll1l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ徣")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ徤")+l11ll1_l1_ (u"࠭ไศࠢํ์ัีࠧ徥")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ徦")
			if l1ll111l111_l1_ not in l1llll1ll1l11_l1_: l111l1lll11l_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠫ徧")+l1ll111l111_l1_
	for l1llll11l1l11_l1_,counts in l1llll11l1ll1_l1_:
		l1llll11l1l11_l1_ = escapeUNICODE(l1llll11l1l11_l1_)
		l1lll1lllll1l_l1_ += l1llll11l1l11_l1_+l11ll1_l1_ (u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ徨")+str(counts)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨ復")
	l1ll11l11ll_l1_ = l1ll11l11ll_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠭循"))
	l1ll11l1l11_l1_ = l1ll11l1l11_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ徫"))
	l111l1lll11l_l1_ = l111l1lll11l_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ徬"))
	l111l1llll11_l1_ = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ徭")+l1ll11l1l11_l1_
	#l11111l1l1ll_l1_  = l11ll1_l1_ (u"ࠨ࡞ࡱࡌ࡮࡭ࡨࡖࡵࡤ࡫ࡪࡀࠠ࡜ࠢࠪ微")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ徯")
	#l11111l1l1ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡒ࡯ࡸࡗࡶࡥ࡬࡫ࠠ࠻ࠢ࡞ࠤࠬ徰")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ徱")
	#l11111l1l1ll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࡏࡱࡘࡷࡦ࡭ࡥࠡࠢ࠽ࠤࡠࠦࠧ徲")+l111l1lll11l_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ徳")
	l111l1lll1ll_l1_  = l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦิ฻ๆ้๋ࠣํวࠡษ็ฬึ์วๆฮࠣห้ฮวาฯฬࠤ࠭๐่ๆࠢฦุ้࠯ࠠโ์า๎ํํวหࠢหำํ์ࠠๆึส็้࠭徴")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ徵")+l11ll1_l1_ (u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧ徶")+l11ll1_l1_ (u"ࠪࡠࡳ࠭德")
	l111l1lll1ll_l1_ += l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ徸")+l111l1llll11_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ徹")
	l111l1lll1ll_l1_ += l11ll1_l1_ (u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣว๏ࠦแ๋ัํ์์อสࠨ徺")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ徻")+l11ll1_l1_ (u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ徼")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ徽")
	l111l1lll1ll_l1_ += l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭徾")+l111l1lll11l_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徿")
	l1111l11l1l_l1_,l1lll11l1ll11_l1_,l1lll1lll11ll_l1_,l1lll11l11l1l_l1_ = 0,0,0,0
	all = l1lll1111ll11_l1_[l11ll1_l1_ (u"ࠬࡇࡌࡍࠩ忀")]
	if l11ll1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭忁") in list(l1lll1111ll11_l1_.keys()): l1111l11l1l_l1_ = l1lll1111ll11_l1_[l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ忂")]
	if l11ll1_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ心") in list(l1lll1111ll11_l1_.keys()): l1lll11l1ll11_l1_ = l1lll1111ll11_l1_[l11ll1_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ忄")]
	if l11ll1_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ必") in list(l1lll1111ll11_l1_.keys()): l1lll1lll11ll_l1_ = l1lll1111ll11_l1_[l11ll1_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ忆")]
	if l11ll1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ忇") in list(l1lll1111ll11_l1_.keys()): l1lll11l11l1l_l1_ = l1lll1111ll11_l1_[l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ忈")]
	l11ll1lll1ll_l1_ = all-l1111l11l1l_l1_-l1lll11l1ll11_l1_-l1lll1lll11ll_l1_-l1lll11l11l1l_l1_
	dummy,l1lll1ll11lll_l1_ = l1lll1l1l11ll_l1_[0]
	dummy,l1lll111lll1l_l1_ = l1lll1l1l11ll_l1_[1]
	l1lll11ll11l1_l1_ = l1lll1ll11lll_l1_-l1lll111lll1l_l1_
	l1lll1l11111l_l1_ += l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忉")+str(l1lll111lll1l_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ忊")+l11ll1_l1_ (u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭忋")
	l1lll1l11111l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ忌")+str(l1lll11ll11l1_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭忍")+l11ll1_l1_ (u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ忎")
	l1lll1l11111l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ忏")+str(l1lll1ll11lll_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ忐")+l11ll1_l1_ (u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩ忑")
	l1lll1l11111l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ忒")+str(len(l1lll1l1l11ll_l1_[2:]))+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ忓")+l11ll1_l1_ (u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩ忔")
	for l1ll1l1111ll_l1_,l1l11l11l1l1_l1_ in l1lll1l1l11ll_l1_[2:]:
		l1ll1l1111ll_l1_ = escapeUNICODE(l1ll1l1111ll_l1_)
		l1ll1l1111ll_l1_ = l1ll1l1111ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ忕")).strip(l11ll1_l1_ (u"࠭ࠠ࠯ࠩ忖"))
		l1lll1l11111l_l1_ += l1ll1l1111ll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ志")+str(l1l11l11l1l1_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭忘")
	#l1lll1l11111l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲ࠳࠭忙")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭忚")+str(l11ll1lll1ll_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭忛")+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪ応")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ忝")+str(l1111l11l1l_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ忞")+l11ll1_l1_ (u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩ忟")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ忠")+str(l1lll11l11l1l_l1_)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ忡")+l11ll1_l1_ (u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼หฯࠦ࠺ࠡࠩ忢")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忣")+str(l1lll11l1ll11_l1_)+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ忤")+l11ll1_l1_ (u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫ忥")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭忦")+str(l1lll1lll11ll_l1_)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ忧")+l11ll1_l1_ (u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩ忨")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ忩")+str(len(l1llll11l1ll1_l1_))+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ忪")+l11ll1_l1_ (u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭快")
	#l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ忬")+l11ll1_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡษ็฽ฬ๊ๅࠡ์๋้ࠥษๅิࠢࠫห้ฮวาฯฬ࠭ࠬ忭")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ忮")
	l1lll1111l11l_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ忯")+l1lll1lllll1l_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ忰"),l11ll1_l1_ (u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ忱"),l1lll1l11111l_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ忲"))
	#l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ忳"),l11ll1_l1_ (u"ࠨฮ่๎฾ࠦ็ั้ࠣห้ษัใษ่ࠤฯิีࠡลึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡࠢไๆ฼๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ忴"),l1lll1111l11l_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ念"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ忶"),l11ll1_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ忷"),l1lll1111l11l_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ忸"))
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭忹"),l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ忺"),l111l1lll1ll_l1_,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ忻"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ忼"),l11ll1_l1_ (u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥอไษษิัฮࠦࠨ๋๊่ࠤศ๋ำࠪࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬ忽"),l111l1lll1l1_l1_,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ忾"))
	return
def l1lll1l111l1l_l1_():
	message = l11ll1_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫ忿")
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭怀"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ态"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ怂"))
	return
def l1l1l1ll111l_l1_():
	message = l11ll1_l1_ (u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧ怃")+l11ll1_l1_ (u"ࠪࡠࡳ࠭怄")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ怅")+l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ怆")][0]+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ怇")+l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭怈")][1]+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ怉")
	message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ怊")+l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ怋")][1]+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭怌")
	message += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ怍")+l11ll1_l1_ (u"࠭࡜࡯ࠩ怎")+l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ怏")+l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ怐")][2]+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ怑")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ怒"),l11ll1_l1_ (u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ怓"),message,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ怔"))
	return
def l1llll11l1l1l_l1_(l1llll11l1lll_l1_):
	xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬ怕")+l1llll11l1lll_l1_+l11ll1_l1_ (u"ࠧࠪࠩ怖"), True)
	return
def l1llll111lll1_l1_():
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠨࡵࡷࡳࡵ࠭怗"))
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣ怘"))
	return
def l1lll1l1l11l1_l1_():
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩ怙"), True)
	return
def l1lll11lll111_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111ll1_l1_ = True
	else: l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ怚"),l11ll1_l1_ (u"ࠬ࠭怛"),l11ll1_l1_ (u"࠭ࠧ怜"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ思"),l11ll1_l1_ (u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨ怞"))
	if l1ll111ll1_l1_==1:
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬ怟"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ怠"),l11ll1_l1_ (u"ࠫࠬ怡"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ怢"),l11ll1_l1_ (u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭怣"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ怤"))
	return
def l1lll11lll11l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ急"),l11ll1_l1_ (u"ࠩࠪ怦"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭性"),l11ll1_l1_ (u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫ怨"))
	return
def l1lll11llllll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭怩"),l11ll1_l1_ (u"࠭ࠧ怪"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ怫"),l11ll1_l1_ (u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ怬"))
	return
#l1llll11ll11l_l1_ 	  required	and l1llll11ll11l_l1_     installed	and		not l1l11l11111l_l1_		ignore
#l1llll11ll11l_l1_ not required	and	l1llll11ll11l_l1_ not installed 	and 	    l1l11l11111l_l1_		ignore
#l1llll11ll11l_l1_ not required	and	l1llll11ll11l_l1_ not installed 	and 	not l1l11l11111l_l1_		ignore
#l1llll11ll11l_l1_ not required	and	l1llll11ll11l_l1_     installed 	and 	not l1l11l11111l_l1_		ignore
#l1llll11ll11l_l1_     required	and	l1llll11ll11l_l1_ not installed 	and 	    l1l11l11111l_l1_		l111111lll_l1_ l1lll11l1ll11_l1_	l1lll1llllll1_l1_
#l1llll11ll11l_l1_     required	and	l1llll11ll11l_l1_ not installed 	and 	not l1l11l11111l_l1_		l111111lll_l1_ l1lll11l1ll11_l1_	l1lll1llllll1_l1_
#l1llll11ll11l_l1_     required 	and l1llll11ll11l_l1_     installed 	and 	    l1l11l11111l_l1_		l111111lll_l1_ l1llll1l11l1l_l1_	l1lll1llllll1_l1_
#l1llll11ll11l_l1_ not required	and	l1llll11ll11l_l1_     installed 	and 	    l1l11l11111l_l1_		l111111lll_l1_ l1llll1l11l1l_l1_	l1lll1llllll1_l1_
#l1ll1ll1l1ll_l1_: required and not installed: l111111lll_l1_ l1lll11l1ll11_l1_
#l1ll1ll1l11l_l1_: installed and l111111lll_l1_ update: l111111lll_l1_ l1llll1l11l1l_l1_
def l1l1l1l11l1l_l1_(l1ll_l1_=True):
	l1l11l1lllll_l1_ = l1lll1l11l1l_l1_([l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ怭")])
	l1lll1lll11l1_l1_ = []
	for addon_id in [l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ怮")]:
		if addon_id not in list(l1l11l1lllll_l1_.keys()): continue
		l1l11l11111l_l1_,l1llllll111l_l1_,l1llll1111ll1_l1_,l1llll1111l1l_l1_,l1llll11111l1_l1_,l1lll111l1lll_l1_,l1llll11111ll_l1_ = l1l11l1lllll_l1_[addon_id]
		if not l1llllll111l_l1_ or (l1llllll111l_l1_ and l1l11l11111l_l1_): l1lll1lll11l1_l1_.append(addon_id)
	l1lll11111lll_l1_ = len(l1lll1lll11l1_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1ll111ll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1llll111l1ll_l1_ = []
	for addon_id in l11ll1ll1l1_l1_:
		cc.execute(l11ll1_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࠥ࠵ࠧࠦࡡ࡯ࡦࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ怯")+addon_id+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ怰"))
		l1l1111l1ll_l1_ = cc.fetchall()
		if l1l1111l1ll_l1_: l1llll111l1ll_l1_.append(addon_id)
	l1lll1l11ll11_l1_ = len(l1llll111l1ll_l1_)>0
	for addon_id in l1lllllllll1_l1_:
		cc.execute(l11ll1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ怱")+addon_id+l11ll1_l1_ (u"ࠧࠣࠢ࠾ࠫ怲"))
		l1llll1ll1l1l_l1_ = cc.fetchall()
		if l1llll1ll1l1l_l1_ and l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ怳") not in str(l1llll1ll1l1l_l1_): l1lll1lll11l1_l1_.append(addon_id)
	l1lll11l1llll_l1_ = len(l1lll1lll11l1_l1_)>0
	l1lll1lll11l1_l1_ = list(set(l1lll1lll11l1_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ怴"),l11ll1_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡨ࡬ࡼ࡮ࡴࡧࡠࡴࡨࡴࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠣࠫ怵")+str(l1lll11111lll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ怶"),l11ll1_l1_ (u"ࠬࡴࡥࡦࡦࡢࡨࡪࡲࡥࡵ࡫ࡱ࡫ࡤࡵ࡬ࡥࡡࡤࡨࡩࡵ࡮ࡴ࠼ࠣࠤࠬ怷")+str(l1lll1l11ll11_l1_))
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ怸"),l11ll1_l1_ (u"ࠧ࡯ࡧࡨࡨࡤ࡬ࡩࡹ࡫ࡱ࡫ࡤࡵࡲࡪࡩ࡬ࡲ࠿ࠦࠠࠨ怹")+str(l1lll11l1llll_l1_))
	l1l11l11111l_l1_ = False
	if l1lll1l11ll11_l1_ or l1lll11l1llll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ怺"),l11ll1_l1_ (u"ࠩࠪ总"),l11ll1_l1_ (u"ࠪࠫ怼"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ怽"),l11ll1_l1_ (u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦๅิฬ๋ำ฾อสࠡ฻่หิࠦรุ้่่๊ࠢษࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥอไร่ࠣรࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭怾"))
		if l1ll111ll1_l1_==1:
			l1llll11lllll_l1_ = True
			if l1lll11111lll_l1_:
				l1llll11lllll_l1_ = l1lll11l1l11l_l1_(l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ怿"),False,False)
			l1lll1ll1l1l1_l1_ = True
			if l1lll1l11ll11_l1_:
				for addon_id in l1llll111l1ll_l1_: l1lll1l1llll1_l1_(addon_id)
				l1lll1ll1l1l1_l1_ = True
			l1lll11l11l11_l1_ = True
			if l1lll11l1llll_l1_:
				conn = sqlite3.connect(l1l1ll111ll1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1lll1lll11l1_l1_:
					if l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࠪ恀") in addon_id: l1llll1ll1l1l_l1_ = addon_id
					else: l1llll1ll1l1l_l1_ = l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ恁")
					try: cc.execute(l11ll1_l1_ (u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭恂")+l1llll1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ恃")+addon_id+l11ll1_l1_ (u"ࠫࠧࠦ࠻ࠨ恄"))
					except: l1lll11l11l11_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ恅"))
			time.sleep(1)
			if l1llll11lllll_l1_ or l1lll1ll1l1l1_l1_ or l1lll11l11l11_l1_:
				l1l11l11111l_l1_ = False
				DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ恆"),l11ll1_l1_ (u"ࠧࠨ恇"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ恈"),l11ll1_l1_ (u"ࠩฯ๎ิࠦ࠮࠯ࠢอ้ࠥฮๆอษะࠤฯ็ู๋ๆࠣ์ส฻ไศฯࠣห้๋ำห๊า฽ฬะ้ࠠษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้าๅ๋฻ࠣษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ恉"))
			else:
				l1l11l11111l_l1_ = True
				DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ恊"),l11ll1_l1_ (u"ࠫࠬ恋"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ恌"),l11ll1_l1_ (u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหีๅษะࠤู๊ส้ั฼หฯูࠦๆษาࠤํหีๅษะࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭恍"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ恎"),l11ll1_l1_ (u"ࠨࠩ恏"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ恐"),l11ll1_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼หฯูࠦๆษาࠤศ๎ࠠโ์ࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬ恑"))
	return l1l11l11111l_l1_
def l1lll11l1ll1l_l1_():
	l1lll1111ll1l_l1_,l1llll111l111_l1_,l1lll1lllllll_l1_ = False,l11ll1_l1_ (u"ࠫࠬ恒"),l11ll1_l1_ (u"ࠬ࠭恓")
	l1llll11ll1l1_l1_,l1lll1l1ll11l_l1_,l1lll1ll11ll1_l1_ = False,l11ll1_l1_ (u"࠭ࠧ恔"),l11ll1_l1_ (u"ࠧࠨ恕")
	l1l11l1lllll_l1_ = l1lll1l11l1l_l1_([l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭恖"),l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ恗"),l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ恘")])
	for addon_id in [l11ll1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ恙"),l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ恚"),l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ恛")]:
		if addon_id not in list(l1l11l1lllll_l1_.keys()): continue
		l1l11l11111l_l1_,l1llllll111l_l1_,l1111llllll_l1_,l1ll1lll1lll_l1_,l11l1l11l11_l1_,l11ll1l11l1_l1_,l1l111llllll_l1_ = l1l11l1lllll_l1_[addon_id]
		if addon_id==l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ恜"):
			l1llll11ll1l1_l1_ = l1l11l11111l_l1_
			l1lll1l1ll11l_l1_ = l11ll1_l1_ (u"ࠨࠪࠪ恝")+l1llllll111l_l1_+l11ll1_l1_ (u"ࠩࠣࠫ恞")+TRANSLATE(l11ll1l11l1_l1_)+l11ll1_l1_ (u"ࠪ࠭ࠬ恟")
			l1lll1ll11ll1_l1_ = l1ll1lll1lll_l1_
		elif addon_id==l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭恠"):
			l1lll1111ll1l_l1_ = l1lll1111ll1l_l1_ or l1l11l11111l_l1_
			l1llll111l111_l1_ += l11ll1_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠬࠬ恡")+l1llllll111l_l1_+l11ll1_l1_ (u"࠭ࠠࠨ恢")+TRANSLATE(l11ll1l11l1_l1_)+l11ll1_l1_ (u"ࠧࠪࠩ恣")
			l1lll1lllllll_l1_ += l11ll1_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ恤")+l1ll1lll1lll_l1_
		elif addon_id==l11ll1_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ恥"):
			l1lll1l111lll_l1_ = l1l11l11111l_l1_
			l1lll11llll1l_l1_ = l11ll1_l1_ (u"ࠪࠬࠬ恦")+l1llllll111l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭恧")+TRANSLATE(l11ll1l11l1_l1_)+l11ll1_l1_ (u"ࠬ࠯ࠧ恨")
			l1lll1lllll11_l1_ = l1ll1lll1lll_l1_
	l1llll111l111_l1_ = l1llll111l111_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ恩"))
	l1lll1lllllll_l1_ = l1lll1lllllll_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭恪"))
	l1l11ll1l1_l1_  = l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ恫")+l1lll1ll11ll1_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ恬")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭恭")+l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไษำ้ห๊าฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ恮")+l1lll1l1ll11l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ息")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ恰")+l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ恱")+l1lll1lllllll_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恲")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ恳")+l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ恴")+l1llll111l111_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭恵")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ恶")+l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ恷")+l1lll1lllll11_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ恸")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ恹")+l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ恺")+l1lll11llll1l_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ恻")
	l1l11l11111l_l1_ = (l1llll11ll1l1_l1_ or l1lll1111ll1l_l1_)
	if l1l11l11111l_l1_:
		header = l11ll1_l1_ (u"ࠫฬ๊ัอษฤࠤฯำฯ๋อࠣษ฻อแศฬࠣ็ํี๊ࠡๆะ่ࠥอไๆึส็้࠭恼")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠬอๆหࠢหัฬาษࠡๆอัิ๐หࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร้ࠢอัิ๐หࠡ็ึฮํีูࠡ฻่หิ࠭恽")
	else:
		header = l11ll1_l1_ (u"࠭อศๆํห๊ࠥวࠡ์๋ะิࠦสฮัํฯฬะࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦร้่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧ恾")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠧศๆิะฬวࠠฦส็ห฿ࠦวๅ็หี๊าฺ่ࠠࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอ์ฬา็ไࠩ恿")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆࠣ฽๋ีใࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ๏าศࠡล้ࠤ๏้่็ࠢ็ำ๏้ࠠโ์ࠣ็ํี๊࡝ࡰ่ืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩ悀")
	l1ll11ll1l_l1_ = l1l11ll1l1_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ悁")+l1l1l1ll11_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ悂")+l1l1l1l1ll_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ悃"),header,l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ悄"))
	return
def l1ll1l11ll1l_l1_(l1ll_l1_=True,l1lll11ll11ll_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ悅"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭悆"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ悇"),l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ悈"))
	if l1ll_l1_:
		l1lll11l1ll1l_l1_()
		l1lll1llll1ll_l1_()
	if l1lll11ll11ll_l1_:
		l1l1l1l11l1l_l1_(False)
		l1llll1l1llll_l1_,l1lll11l1111l_l1_,l1lll11ll111l_l1_ = l1lll11l1l11l_l1_(l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ悉"),True,False)
		l1llll1ll1111_l1_,l1lll11l1111l_l1_,l1llll111l1l1_l1_ = l1lll11l1l11l_l1_(l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭悊"),True,False)
		l1lll11lll111_l1_(l1ll_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ悋"))
	return
def l1lll1lll1l1l_l1_(l1llll11l1111_l1_=l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ悌"),l1ll_l1_=True):
	l111l1l1111_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ悍"))
	import json
	data = json.loads(l111l1l1111_l1_)
	l1lll111l1ll1_l1_ = data[l11ll1_l1_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ悎")][l11ll1_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ悏")]
	if kodi_version<19: l1lll111l1ll1_l1_ = l1lll111l1ll1_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ悐"))
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ悑"),l11ll1_l1_ (u"ࠬ࠭悒"),l11ll1_l1_ (u"࠭ࠧ悓"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悔"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭悕")+l1lll111l1ll1_l1_+l11ll1_l1_ (u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫ悖")+l1llll11l1111_l1_+l11ll1_l1_ (u"ࠪࠤฤࠧࠧ悗"))
		if l1ll111ll1_l1_!=1: return False
	succeeded,l1llll1111111_l1_,l1lll111ll11l_l1_ = l1lll11l1l11l_l1_(l1llll11l1111_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ悘"),l11ll1_l1_ (u"ࠬ࠭悙"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ悚"),l11ll1_l1_ (u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩ悛"))
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬ悜")+l1llll11l1111_l1_+l11ll1_l1_ (u"ࠩࠥࢁࢂ࠭悝"))
		if l11ll1_l1_ (u"ࠪࡓࡐ࠭悞") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ悟"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭悠"),l11ll1_l1_ (u"࠭ࠧ悡"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悢"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪ患"))
	return succeeded
def l11l11lll11_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11ll1_l1_ (u"ࠩࠪ悤"): l1ll_l1_ = True
	#l1lll1111lll_l1_ = xbmc.getCondVisibility(l11ll1_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭࠭悥")+addon_id+l11ll1_l1_ (u"ࠫ࠮࠭悦"))
	l11l1l1llll_l1_ = l1ll1111l111_l1_([addon_id])
	l11l111111l_l1_,l1lll1111lll_l1_ = l11l1l1llll_l1_[addon_id]
	if l1lll1111lll_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭悧"),l11ll1_l1_ (u"࠭ࠧ您"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悩"),l11ll1_l1_ (u"ࠨใะูࠥอไฦุสๅฮࠦ࡜࡯ࠢࠪ悪")+addon_id+l11ll1_l1_ (u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬ悫"))
	else:
		succeeded = False
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ悬"),l11ll1_l1_ (u"ࠫࠬ悭"),l11ll1_l1_ (u"ࠬ࠭悮"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ悯"),l11ll1_l1_ (u"ࠧࠨ悰")+addon_id+l11ll1_l1_ (u"ࠨࠢ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ฼ํี๋ࠥแฺๆฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠤ࠳๊ࠦอสࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦไไ์ࠣ๎฾๋ไࠡษ็ฬึ์วๆฮࠣ฽๋ีใࠡสุ์ึฯࠠึฯํัฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢอฯอ๐ส๊ࠡอๅ฾๐ไ้ࠡำ๋ࠥอไฦุสๅฮࠦวๅฤ้ࠤฤ࠭悱"))
		if l1ll111ll1_l1_==1:
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡌࡲࡸࡺࡡ࡭࡮ࡄࡨࡩࡵ࡮ࠩࠩ悲")+addon_id+l11ll1_l1_ (u"ࠪ࠭ࠬ悳"))
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ悴"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11ll1_l1_ (u"ࠬ࡝ࡩ࡯ࡦࡲࡻ࠳ࡏࡳࡂࡥࡷ࡭ࡻ࡫ࠨࡱࡴࡲ࡫ࡷ࡫ࡳࡴࡦ࡬ࡥࡱࡵࡧࠪࠩ悵")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ悶")+addon_id+l11ll1_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ悷"))
			if l11ll1_l1_ (u"ࠨࡑࡎࠫ悸") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ悹"),l11ll1_l1_ (u"ࠪࠫ悺"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ悻"),l11ll1_l1_ (u"ࠬะๅࠡใะูࠥษ่ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫ悼"))
			elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ悽"),l11ll1_l1_ (u"ࠧࠨ悾"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ悿"),l11ll1_l1_ (u"ࠩไุ้ࠦแ๋ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡ࠰ࠣ์ฬ๊อๅ๊ࠢ์ࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡ็้ࠤำอัอࠢส่อืๆศ็ฯࠫ惀"))
	return succeeded
def l1lll11lll1l1_l1_(addon_id,l1l111llllll_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ惁"),l11ll1_l1_ (u"ࠫࠬ惂"),l11ll1_l1_ (u"ࠬ࠭惃"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ惄"),l11ll1_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฼ฺู้่้ࠣหึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦไไ์ࠣ๎ฯ๋ࠠหอห๎ฯํฺࠠๆ์ࠤ่๎ฯ๋ࠢ࠱ࠤฬ๊ๅๅใࠣๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢส่ว์ࠠภࠣࠪ情"))
		if l1ll111ll1_l1_!=1: return False
	l1lll111l1111_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l111llllll_l1_,{},l1ll_l1_)
	if l1lll111l1111_l1_:
		l1l11l11l1ll_l1_ = os.path.join(l1ll11llll_l1_,addon_id)
		l1ll11l1ll_l1_(l1l11l11l1ll_l1_,True,False)
		import zipfile,io
		l1lll1l1ll111_l1_ = io.BytesIO(l1lll111l1111_l1_)
		zf = zipfile.ZipFile(l1lll1l1ll111_l1_)
		zf.extractall(l1ll11llll_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ惆"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ惇")+addon_id+l11ll1_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ惈"))
		if l11ll1_l1_ (u"ࠫࡔࡑࠧ惉") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ惊"),l11ll1_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ惋"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ惌"),l11ll1_l1_ (u"ࠨࠩ惍"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ惎"),l11ll1_l1_ (u"ࠪฮ๊ࠦศ็ฮสัࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ惏"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ惐"),l11ll1_l1_ (u"ࠬ࠭惑"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ惒"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬ惓"))
	return succeeded
def l1lll11l1l11l_l1_(addon_id,l1ll_l1_,l1lll1l11l1l1_l1_):
	l1ll111ll1_l1_,succeeded,l1llll1111111_l1_,l1llllll111l_l1_ = True,False,l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ惔"),l11ll1_l1_ (u"ࠩࠪ惕")
	l1l11l1lllll_l1_ = l1lll1l11l1l_l1_([addon_id])
	if addon_id in list(l1l11l1lllll_l1_.keys()):
		l1l11l11111l_l1_,l1llllll111l_l1_,l1111llllll_l1_,l1ll1lll1lll_l1_,l11l1l11l11_l1_,l11ll1l11l1_l1_,l1l111llllll_l1_ = l1l11l1lllll_l1_[addon_id]
		if l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ惖"):
			succeeded,l1llll1111111_l1_ = True,l11ll1_l1_ (u"ࠫࡳࡵࡴࡩ࡫ࡱ࡫ࠬ惗")
			if l1lll1l11l1l1_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭惘"),l11ll1_l1_ (u"࠭ࠧ惙"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ惚"),l11ll1_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ惛")+addon_id)
		else:
			if l1ll_l1_:
				if l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ惜"): message = l11ll1_l1_ (u"้ࠪฯ๎โโหࠪ惝")
				elif l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠫࡴࡲࡤࠨ惞"): message = l11ll1_l1_ (u"่ࠬฯ๋็ฬࠫ惟")
				elif l11ll1l11l1_l1_==l11ll1_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ惠"): message = l11ll1_l1_ (u"ࠧ฻์ิࠤ๊ัศหหࠪ惡")
				l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ惢"),l11ll1_l1_ (u"ࠩࠪ惣"),l11ll1_l1_ (u"ࠪࠫ惤"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ惥"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ส฼วโหࠣࠫ惦")+message+l11ll1_l1_ (u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨ惧")+addon_id)
			if not l1ll111ll1_l1_: l1llll1111111_l1_ = l11ll1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩ惨")
			else:
				if l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ惩"):
					results = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ惪")+addon_id+l11ll1_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ惫"))
					if l11ll1_l1_ (u"ࠫࡔࡑࠧ惬") in results:
						succeeded,l1llll1111111_l1_ = True,l11ll1_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭惭")
						if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ惮"),l11ll1_l1_ (u"ࠧࠨ惯"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ惰"),l11ll1_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧ惱")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ惲"),l11ll1_l1_ (u"ࠫࠬ想"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ惴"),l11ll1_l1_ (u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ษ฻อแส่ࠢฮํ่แสࠢ࠱࠲ࠥ๎ไๆࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩ惵")+addon_id)
				elif l11ll1l11l1_l1_ in [l11ll1_l1_ (u"ࠧࡰ࡮ࡧࠫ惶"),l11ll1_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ惷")]:
					succeeded = l1lll11lll1l1_l1_(addon_id,l1l111llllll_l1_,False)
					if succeeded:
						if l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠩࡲࡰࡩ࠭惸"): l1llll1111111_l1_ = l11ll1_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫ惹")
						elif l11ll1l11l1_l1_==l11ll1_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ惺"): l1llll1111111_l1_ = l11ll1_l1_ (u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨ惻")
						l1llllll111l_l1_ = l1ll1lll1lll_l1_
						if l1ll_l1_:
							if l1llll1111111_l1_==l11ll1_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧ惼"): DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ惽"),l11ll1_l1_ (u"ࠨࠩ惾"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ惿"),l11ll1_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦโะ์่อࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอัิ๐ห่ษ࡟ࡲࡡࡴࠧ愀")+addon_id)
							elif l1llll1111111_l1_==l11ll1_l1_ (u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧ愁"): DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭愂"),l11ll1_l1_ (u"࠭ࠧ愃"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ愄"),l11ll1_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩ愅")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ愆"),l11ll1_l1_ (u"ࠪࠫ愇"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ愈"),l11ll1_l1_ (u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥะอะ์ฮࠤศ๎ࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ愉")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ愊"),l11ll1_l1_ (u"ࠧࠨ愋"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ愌"),l11ll1_l1_ (u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭愍")+addon_id)
	return succeeded,l1llll1111111_l1_,l1llllll111l_l1_
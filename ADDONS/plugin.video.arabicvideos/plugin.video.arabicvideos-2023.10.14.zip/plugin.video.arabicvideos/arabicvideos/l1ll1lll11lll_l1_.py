# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨࡖࡈࡗ࡙࠭昩"),l11ll1_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ昪"))
#url = l11ll1_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡑࡱࡵࡸࡦࡨ࡬ࡦࠢࡓࡶࡴ࡭ࡲࡢ࡯ࡶࡠࡡࡑࡏࡅࡋࡢࡺ࠶࠾࡟࠷࠶ࡥ࡭ࡹࡢ࡜ࡌࡱࡧ࡭ࡡࡢࡰࡰࡴࡷࡥࡧࡲࡥࡠࡦࡤࡸࡦࡢ࡜ࡤࡣࡦ࡬ࡪࡢ࡜ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࡡࡢࡦࡪ࡮ࡨࡣ࠵࠾࠹࠷ࡡࡖࡌ࡛ࡥา๋ษิอࡤอไาี๋่ࡤอไฤ฻฻้ࡤ࠮ีࠪࡡࠫวออะาࡡส่า๊่ศฮํ࠭࠳ࡳࡰ࠴ࠩ昫")
#url = l11ll1_l1_ (u"ࠫࡨࡀ࡜࡝ࡣࡶࡨ࡫࠴࡭ࡱ࠵ࠪ昬")
#url = l11ll1_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ昭")
#url = l11ll1_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡣࡶࡨ࡫࠴࡭ࡱ࠵ࠪ昮")
url = l11ll1_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ไัฺ࠴࡭ࡱ࠵ࠪ是")
url = l11ll1_l1_ (u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ࡪ࡮ࡲࡥࡠ࠶࠻࠷࠹ࡥࡓࡉࡘࡢึ๏อัสࡡส่ึู่ๅࡡส่ศ฿ุๆࡡูࠫ࠮ࡥࠨฤสสิึࡥวๅฯ็์ฬา๊ࠪ࠰ࡰࡴ࠸࠭昰")
#url = url.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ昱"))
xbmc.Player().play(url)
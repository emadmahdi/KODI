# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪᾞ")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡉࡘ࠷ࡠࠩᾟ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭ᾠ"),l11ll1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭ᾡ"),l11ll1_l1_ (u"࠭สิฮํ่ࠬᾢ")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l11111_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l1llll1_l1_(url,text)
	elif mode==684: results = l1l111_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᾣ"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩᾤ"),l11ll1_l1_ (u"ࠩࠪᾥ"),l11ll1_l1_ (u"ࠪࠫᾦ"),l11ll1_l1_ (u"ࠫࠬᾧ"),l11ll1_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᾨ"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾩ"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᾪ"),l11ll1_l1_ (u"ࠨࠩᾫ"),689,l11ll1_l1_ (u"ࠩࠪᾬ"),l11ll1_l1_ (u"ࠪࠫᾭ"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᾮ"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᾯ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᾰ"),l11ll1_l1_ (u"ࠧࠨᾱ"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᾲ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᾳ")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᾴ"),l11l1l_l1_,681,l11ll1_l1_ (u"ࠫࠬ᾵"),l11ll1_l1_ (u"ࠬ࠭ᾶ"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᾷ"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᾸ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᾹ")+l111l1_l1_+l11ll1_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨᾺ"),l11l1l_l1_,681,l11ll1_l1_ (u"ࠪࠫΆ"),l11ll1_l1_ (u"ࠫࠬᾼ"),l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ᾽"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ι"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᾿")+l111l1_l1_+l11ll1_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ῀"),l11l1l_l1_,681,l11ll1_l1_ (u"ࠩࠪ῁"),l11ll1_l1_ (u"ࠪࠫῂ"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪῃ"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬῄ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ῅")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫῆ"),l11l1l_l1_,681,l11ll1_l1_ (u"ࠨࠩῇ"),l11ll1_l1_ (u"ࠩࠪῈ"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬΈ"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῊ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬΉ"),l11ll1_l1_ (u"࠭ࠧῌ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡻࡷࡧࡰࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ῍"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ῎"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ῏"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬῐ")+l111l1_l1_+title,l1lllll_l1_,684)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῑ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῒ"),l11ll1_l1_ (u"࠭ࠧΐ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ῔"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ῕"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠩࠪῖ"))
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨῗ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫῘ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧῙ")+l111l1_l1_+title,l1lllll_l1_,684)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪῚ"),url,l11ll1_l1_ (u"ࠧࠨΊ"),l11ll1_l1_ (u"ࠨࠩ῜"),l11ll1_l1_ (u"ࠩࠪ῝"),l11ll1_l1_ (u"ࠪࠫ῞"),l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ῟"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩῠ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧῡ"),l11ll1_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ῢ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬΰ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠩࠪῤ"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨῥ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩῦ"),l11ll1_l1_ (u"ࠬ࠭ῧ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫῨ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢࠪῩ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨῪ"),l111l1_l1_+title,l1lllll_l1_,681)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭Ύ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬῬ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ῭"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ΅"),l11ll1_l1_ (u"࠭ࠧ`"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ῰"),l111l1_l1_+title,l1lllll_l1_,681)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠨࠩ῱")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪῲ"),l11ll1_l1_ (u"ࠪࠫῳ"),request,url)
	if request==l11ll1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩῴ"):
		url,search = url.split(l11ll1_l1_ (u"ࠬࡅࠧ῵"),1)
		data = l11ll1_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬῶ")+search
		headers = {l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ῷ"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨῸ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧΌ"),url,data,headers,l11ll1_l1_ (u"ࠪࠫῺ"),l11ll1_l1_ (u"ࠫࠬΏ"),l11ll1_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪῼ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ´"),url,l11ll1_l1_ (u"ࠧࠨ῾"),l11ll1_l1_ (u"ࠨࠩ῿"),l11ll1_l1_ (u"ࠩࠪ "),l11ll1_l1_ (u"ࠪࠫ "),l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ "))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠬ࠭ "),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ "))
	if request==l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ "):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ "),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠩࠪ "),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ "):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ "),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ "):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭​"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ‌"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ‍"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ‎"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ‏"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭‐"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠬ࠭‑"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ‒"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ–"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ—"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ―"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ‖"),l11ll1_l1_ (u"่๊๊ࠫษࠩ‗"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ‘"),l11ll1_l1_ (u"࠭็ะษไࠫ’"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ‚"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ‛"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ“"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ”"),l11ll1_l1_ (u"ู๊ࠫัฮ์ฬࠫ„")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ‟"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ†") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ‡")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ•"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ‣") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ․")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭‥"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ…"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ‧"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ "),l111l1_l1_+title,l1lllll_l1_,682,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ "):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ‪"),l111l1_l1_+title,l1lllll_l1_,682,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ‫") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ‬"),l111l1_l1_+title,l1lllll_l1_,683,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ‭") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭‮"),l111l1_l1_+title,l1lllll_l1_,681,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ "),l111l1_l1_+title,l1lllll_l1_,683,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ‰"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ‱")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ′"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ″"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧ‴"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ‵")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ‶"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ‷"),l111l1_l1_+l11ll1_l1_ (u"ุࠩๅาฯࠠࠨ‸")+title,l1lllll_l1_,681)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ‹"),l11ll1_l1_ (u"ࠫࠬ›"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ※"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ‼"),url,l11ll1_l1_ (u"ࠧࠨ‽"),l11ll1_l1_ (u"ࠨࠩ‾"),l11ll1_l1_ (u"ࠩࠪ‿"),l11ll1_l1_ (u"ࠪࠫ⁀"),l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ⁁"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ⁂"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⁃"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ⁄")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ⁅"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩࠦࠫ⁆"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⁇"),l111l1_l1_+title,url,683,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ⁈"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ⁉")+l1l1l_l1_+l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⁊"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨ⁋"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⁌"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ⁍")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ⁎"))
			title = title.replace(l11ll1_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ⁏"),l11ll1_l1_ (u"ࠬࠦࠧ⁐"))
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⁑"),l111l1_l1_+title,l1lllll_l1_,682,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ⁒"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭⁓") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ⁔")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ⁕"))
		#		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⁖"),l111l1_l1_+title,l1lllll_l1_,682,l1lll1_l1_)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⁗"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⁘"),url,l11ll1_l1_ (u"ࠧࠨ⁙"),l11ll1_l1_ (u"ࠨࠩ⁚"),l11ll1_l1_ (u"ࠩࠪ⁛"),l11ll1_l1_ (u"ࠪࠫ⁜"),l11ll1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⁝"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⁞"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	post = l1lllll_l1_.split(l11ll1_l1_ (u"࠭ࡰࡰࡵࡷࡁࠬ "))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⁠"))
	post = EVAL(l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭⁡"),post)
	l1l1_l1_ = post[l11ll1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵࠪ⁢")]
	l11lll_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l1111l_l1_ = zip(l11lll_l1_,l1l1_l1_)
	for title,l1lllll_l1_ in l1111l_l1_:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⁣")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⁤")
		l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠦ࡭࡫ࠦ࡬ࡪࡰ࡮ࠤࡦࡴࡤࠡࠩ࡫ࡸࡹࡶࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠ࡭࡫ࡱ࡯ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠬ࡮࡬ࡲࡰࠐࠉࡩࡣࡶ࡬ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࡮ࡡࡴࡪࡀࠫ࠮ࡡ࠱࡞ࠌࠌࡴࡦࡸࡴࡴࠢࡀࠤ࡭ࡧࡳࡩ࠰ࡶࡴࡱ࡯ࡴࠩࠩࡢࡣࠬ࠯ࠊࠊࡰࡨࡻࡤࡶࡡࡳࡶࡶࠤࡂ࡛ࠦ࡞ࠌࠌࡪࡴࡸࠠࡱࡣࡵࡸࠥ࡯࡮ࠡࡲࡤࡶࡹࡹ࠺ࠋࠋࠌࡸࡷࡿ࠺ࠋࠋࠌࠍࡵࡧࡲࡵࠢࡀࠤࡧࡧࡳࡦ࠸࠷࠲ࡧ࠼࠴ࡥࡧࡦࡳࡩ࡫ࠨࡱࡣࡵࡸ࠰࠭࠽ࠨࠫࠍࠍࠎࠏࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠿࠳࠻࠲࠾࠿࠺ࠡࡲࡤࡶࡹࠦ࠽ࠡࡲࡤࡶࡹ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࠋࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡰࡢࡴࡷ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࠩࡁࠫ࠳ࡰ࡯ࡪࡰࠫࡲࡪࡽ࡟ࡱࡣࡵࡸࡸ࠯ࠊࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢ࡯࡭ࡳࡱࡳ࠯ࡵࡳࡰ࡮ࡺ࡬ࡪࡰࡨࡷ࠭࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠵ࠤ࡮ࡴࠠࡻࡼࡽ࠾ࠏࠏࠉࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠶࠳ࡹࡰ࡭࡫ࡷࠬࠬࠦ࠽࠿ࠢࠪ࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ⁥")
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ⁦"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⁧"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ⁨"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ⁩"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ⁪"),l11ll1_l1_ (u"ࠫ࠰࠭⁫"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭⁬")+search
	l11111_l1_(url,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭⁭"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫ⁮")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭⁯"))
	return
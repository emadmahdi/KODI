# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕࠪ侩")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡑ࡙ࡔࡠࠩ侪")
l11l1lllll11_l1_ = 5
l11l1lll1111_l1_ = 10
def MAIN(mode,url,text,l1l1111_l1_,l1ll1ll1l11_l1_):
	try: l1lll111l1l1_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侫")])
	except: l1lll111l1l1_l1_ = l11ll1_l1_ (u"ࠬ࠭侬")
	if   mode==160: results = MENU()
	elif mode==161: results = l11ll111l11l_l1_(text)
	elif mode==162: results = l11l1ll11l11_l1_(text,162)
	elif mode==163: results = l11l1ll11l11_l1_(text,163)
	elif mode==164: results = l11ll1111lll_l1_(text)
	elif mode==165: results = l11l1llll1ll_l1_(l1lll111l1l1_l1_,text,l1l1111_l1_)
	elif mode==166: results = l11ll1111111_l1_(url,text)
	elif mode==167: results = l11l1l1ll1l1_l1_(url,text)
	elif mode==168: results = l11l1l11llll_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侭"),l11ll1_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨ侮"),l11ll1_l1_ (u"ࠨࠩ侯"),161,l11ll1_l1_ (u"ࠩࠪ侰"),l11ll1_l1_ (u"ࠪࠫ侱"),l11ll1_l1_ (u"ࠫࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ侲"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侳"),l11ll1_l1_ (u"࠭โิ็ࠣ฽ู๎วว์ࠪ侴"),l11ll1_l1_ (u"ࠧࠨ侵"),162,l11ll1_l1_ (u"ࠨࠩ侶"),l11ll1_l1_ (u"ࠩࠪ侷"),l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ侸"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侹"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠨ侺"),l11ll1_l1_ (u"࠭ࠧ侻"),163,l11ll1_l1_ (u"ࠧࠨ侼"),l11ll1_l1_ (u"ࠨࠩ侽"),l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ侾"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ便"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪ俀"),l11ll1_l1_ (u"ࠬ࠭俁"),164,l11ll1_l1_ (u"࠭ࠧ係"),l11ll1_l1_ (u"ࠧࠨ促"),l11ll1_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俄"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俅"),l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭俆"),l11ll1_l1_ (u"ࠫࠬ俇"),165,l11ll1_l1_ (u"ࠬ࠭俈"),l11ll1_l1_ (u"࠭ࠧ俉"),l11ll1_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ俊"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭俋"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ俌"),l11ll1_l1_ (u"ࠪࠫ俍"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ俎"),l11ll1_l1_ (u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ俏"),l11ll1_l1_ (u"࠭ࠧ俐"),163,l11ll1_l1_ (u"ࠧࠨ俑"),l11ll1_l1_ (u"ࠨࠩ俒"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俓"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俔"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ俕"),l11ll1_l1_ (u"ࠬ࠭俖"),163,l11ll1_l1_ (u"࠭ࠧ俗"),l11ll1_l1_ (u"ࠧࠨ俘"),l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ俙"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俚"),l11ll1_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ俛"),l11ll1_l1_ (u"ࠫࠬ俜"),162,l11ll1_l1_ (u"ࠬ࠭保"),l11ll1_l1_ (u"࠭ࠧ俞"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俟"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俠"),l11ll1_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ信"),l11ll1_l1_ (u"ࠪࠫ俢"),162,l11ll1_l1_ (u"ࠫࠬ俣"),l11ll1_l1_ (u"ࠬ࠭俤"),l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俥"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ俦"),l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸࡛ࠠษฯฮࠤ฾ฺ่ศศํࠫ俧"),l11ll1_l1_ (u"ࠩࠪ俨"),164,l11ll1_l1_ (u"ࠪࠫ俩"),l11ll1_l1_ (u"ࠫࠬ俪"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俫"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俬"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ俭"),l11ll1_l1_ (u"ࠨࠩ修"),165,l11ll1_l1_ (u"ࠩࠪ俯"),l11ll1_l1_ (u"ࠪࠫ俰"),l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ俱"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ俲"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭俳"),l11ll1_l1_ (u"ࠧࠨ俴"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俵"),l11ll1_l1_ (u"ࠩๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ俶"),l11ll1_l1_ (u"ࠪࠫ俷"),163,l11ll1_l1_ (u"ࠫࠬ俸"),l11ll1_l1_ (u"ࠬ࠭俹"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ俺"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ俻"),l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ俼"),l11ll1_l1_ (u"ࠩࠪ俽"),163,l11ll1_l1_ (u"ࠪࠫ俾"),l11ll1_l1_ (u"ࠫࠬ俿"),l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ倀"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭倁"),l11ll1_l1_ (u"ࠧใี่ࠤ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ倂"),l11ll1_l1_ (u"ࠨࠩ倃"),162,l11ll1_l1_ (u"ࠩࠪ倄"),l11ll1_l1_ (u"ࠪࠫ倅"),l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倆"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ倇"),l11ll1_l1_ (u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ倈"),l11ll1_l1_ (u"ࠧࠨ倉"),162,l11ll1_l1_ (u"ࠨࠩ倊"),l11ll1_l1_ (u"ࠩࠪ個"),l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ倌"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ倍"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥฮอฬࠢ฼ุํอฦ๋ࠩ倎"),l11ll1_l1_ (u"࠭ࠧ倏"),164,l11ll1_l1_ (u"ࠧࠨ倐"),l11ll1_l1_ (u"ࠨࠩ們"),l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倒"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倓"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ倔"),l11ll1_l1_ (u"ࠬ࠭倕"),165,l11ll1_l1_ (u"࠭ࠧ倖"),l11ll1_l1_ (u"ࠧࠨ倗"),l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倘"))
	return
def l11ll111l11l_l1_(options):
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ候"),l11ll1_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭倚"),l11ll1_l1_ (u"ࠫࠬ倛"),161,l11ll1_l1_ (u"ࠬ࠭倜"),l11ll1_l1_ (u"࠭ࠧ倝"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ倞"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭借"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倠"),l11ll1_l1_ (u"ࠪࠫ倡"),9999)
	l1l1ll11l111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ倢"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倣")+l11ll1_l1_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ値"),l11ll1_l1_ (u"ࠧࠨ倥"),147)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倦"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ࡟ࡕࡕࠢࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倧")+l11ll1_l1_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ倨"),l11ll1_l1_ (u"ࠫࠬ倩"),148)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ倪"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡌࡊࡑࠦࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ倫")+l11ll1_l1_ (u"ࠧใ่สอࠥศ๊ࠡใํ่๊ࠦๅ็่ࠢ์็฿็ๆࠩ倬"),l11ll1_l1_ (u"ࠨࠩ倭"),28)
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ倮"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡍࡓࡈࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倯")+l11ll1_l1_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭倰"),l11ll1_l1_ (u"ࠬ࠭倱"),41)
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ倲"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡏ࡜࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ倳")+l11ll1_l1_ (u"ࠨไ้หฮࠦวๅๅ๋ฯึࠦๅ็่ࠢ์็฿็ๆࠩ倴"),l11ll1_l1_ (u"ࠩࠪ倵"),135)
	import l1ll1l1l1l1l_l1_
	l1ll1l1l1l1l_l1_.ITEMS(l11ll1_l1_ (u"ࠪ࠴ࠬ倶"),False)
	l1ll1l1l1l1l_l1_.ITEMS(l11ll1_l1_ (u"ࠫ࠶࠭倷"),False)
	l1ll1l1l1l1l_l1_.ITEMS(l11ll1_l1_ (u"ࠬ࠸ࠧ倸"),False)
	#l1ll1l1l1l1l_l1_.ITEMS(l11ll1_l1_ (u"࠭࠳ࠨ倹"),False)
	if l11ll1_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ债") in options:
		menuItemsLIST[:] = l11l1ll11lll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11l1lllll11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1lllll11_l1_)
	menuItemsLIST[:] = l1l1ll11l111_l1_+menuItemsLIST
	return
def l11ll1111lll_l1_(options):
	options = options.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ倻"),l11ll1_l1_ (u"ࠩࠪ值")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ倽"),l11ll1_l1_ (u"ࠫࠬ倾"))
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ倿") : l11ll1_l1_ (u"࠭ࠧ偀") }
	url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭偁")
	payload = { l11ll1_l1_ (u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪ偂") : l11ll1_l1_ (u"ࠩ࠸࠴ࠬ偃") }
	data = l1ll1l11l_l1_(payload)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ偄"),l11ll1_l1_ (u"ࠫࠬ偅"),l11ll1_l1_ (u"ࠬ࠭偆"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ假"),url,data,headers,l11ll1_l1_ (u"ࠧࠨ偈"),l11ll1_l1_ (u"ࠨࠩ偉"),l11ll1_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕࡢࡊࡗࡕࡍࡠ࡙ࡒࡖࡉ࡙࠭࠲ࡵࡷࠫ偊"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬ偋"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ偌"),block,re.DOTALL)
	l11l1l11ll11_l1_,l11l1l1ll111_l1_ = list(zip(*items))
	l11ll11111l1_l1_ = []
	l11ll1111ll1_l1_ = [l11ll1_l1_ (u"ࠬࠦࠧ偍"),l11ll1_l1_ (u"࠭ࠢࠨ偎"),l11ll1_l1_ (u"ࠧࡡࠩ偏"),l11ll1_l1_ (u"ࠨ࠮ࠪ偐"),l11ll1_l1_ (u"ࠩ࠱ࠫ偑"),l11ll1_l1_ (u"ࠪ࠾ࠬ偒"),l11ll1_l1_ (u"ࠫࡀ࠭偓"),l11ll1_l1_ (u"ࠧ࠭ࠢ偔"),l11ll1_l1_ (u"࠭࠭ࠨ偕")]
	l11l1llll11l_l1_ = l11l1l1ll111_l1_+l11l1l11ll11_l1_
	for word in l11l1llll11l_l1_:
		if word in l11l1l1ll111_l1_: l11l1lll11ll_l1_ = 2
		if word in l11l1l11ll11_l1_: l11l1lll11ll_l1_ = 4
		l11ll11111ll_l1_ = [i in word for i in l11ll1111ll1_l1_]
		if any(l11ll11111ll_l1_):
			index = l11ll11111ll_l1_.index(True)
			l11l1l1lll1l_l1_ = l11ll1111ll1_l1_[index]
			l11l1llllll1_l1_ = l11ll1_l1_ (u"ࠧࠨ偖")
			if word.count(l11l1l1lll1l_l1_)>1: l11l1lllllll_l1_,l11l1lllll1l_l1_,l11l1llllll1_l1_ = word.split(l11l1l1lll1l_l1_,2)
			else: l11l1lllllll_l1_,l11l1lllll1l_l1_ = word.split(l11l1l1lll1l_l1_,1)
			if len(l11l1lllllll_l1_)>l11l1lll11ll_l1_: l11ll11111l1_l1_.append(l11l1lllllll_l1_.lower())
			if len(l11l1lllll1l_l1_)>l11l1lll11ll_l1_: l11ll11111l1_l1_.append(l11l1lllll1l_l1_.lower())
			if len(l11l1llllll1_l1_)>l11l1lll11ll_l1_: l11ll11111l1_l1_.append(l11l1llllll1_l1_.lower())
		elif len(word)>l11l1lll11ll_l1_: l11ll11111l1_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11ll11111l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll11111l1_l1_)),l11ll11111l1_l1_)
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡲࡩࡴࡶࠣࡁࠥࡡࠧไๆ่หฯูࠦี๊สส๏ฯฺࠠำห๎ฮ࠭ࠬࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡว้็้๐า๋หࠪࡡࠏࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤ่๊ๅสࠢ็่อำหࠡ฻้๋ฬࡀࠧ࠭ࠢ࡯࡭ࡸࡺ࠲ࠪࠌࠌࡰ࡮ࡹࡴ࠲ࠢࡀࠤࡠࡣࠊࠊࡥࡲࡹࡳࡺࡳࠡ࠿ࠣࡰࡪࡴࠨ࡭࡫ࡶࡸ࠷࠯ࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪࡦࡳࡺࡴࡴࡴࠬ࠸࠭࠿ࠦࡲࡢࡰࡧࡳࡲ࠴ࡳࡩࡷࡩࡪࡱ࡫ࠨ࡭࡫ࡶࡸ࠷࠯ࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࡯ࡩࡳ࡭ࡴࡩࠫ࠽ࠤࡱ࡯ࡳࡵ࠳࠱ࡥࡵࡶࡥ࡯ࡦ่๊ࠫࠫๅสࠢ฼ุํอฦ๋หࠣี็๋ࠠࠨ࠭ࡶࡸࡷ࠮ࡩࠪࠫࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠌࠌࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่้เษ࠻ࠩ࠯ࠤࡱ࡯ࡳࡵࠫࠍࠍࠎࠩࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࠉࠤࡧ࡯࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࠿ࡀ࠴࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡢࡴࡥࡐࡎ࡙ࡔࠋࠋࠌࠧࡪࡲࡳࡦ࠼ࠣࡰ࡮ࡹࡴ࠳ࠢࡀࠤࡪࡴࡧࡍࡋࡖࡘࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤ่๊ๅสࠢ็่อำหࠡ฻้๋ฬࡀࠧ࠭ࠢ࡯࡭ࡸࡺ࠱ࠪࠌࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࠥࡂࠦ࠭࠲࠼ࠣࡦࡷ࡫ࡡ࡬ࠌࠌࠍࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࡳࡦࡣࡵࡧ࡭ࠦ࠽ࠡ࡮࡬ࡷࡹ࠸࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎࠨࠢࠣ偗")
	if l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ偘") in options:
		l11l1ll1l1ll_l1_ = l1l1llll1ll1_l1_
	elif l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ偙") in options:
		l11l1ll1l1ll_l1_ = [l11ll1_l1_ (u"ࠫࡎࡖࡔࡗࠩ做")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠬ࠭偛"),True): return
	elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ停") in options:
		l11l1ll1l1ll_l1_ = [l11ll1_l1_ (u"ࠧࡎ࠵ࡘࠫ偝")]
		import l1l1l1111lll_l1_
		if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠨࠩ偞"),True): return
	count,l11l1l11ll1l_l1_ = 0,0
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偟"),l11ll1_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥࡀࠠ࡜ࠢࠣࡡࠬ偠"),l11ll1_l1_ (u"ࠫࠬ偡"),164,l11ll1_l1_ (u"ࠬ࠭偢"),l11ll1_l1_ (u"࠭ࠧ偣"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ偤")+options)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ健"),l11ll1_l1_ (u"ࠩศ฽ฬีษࠡษ็ฬาัࠠศๆ฼ุํอฦ๋ࠩ偦"),l11ll1_l1_ (u"ࠪࠫ偧"),164,l11ll1_l1_ (u"ࠫࠬ偨"),l11ll1_l1_ (u"ࠬ࠭偩"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ偪")+options)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ偫"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ偬"),l11ll1_l1_ (u"ࠩࠪ偭"),9999)
	l11l1l11l1ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11ll1111l1l_l1_ = []
	for word in l11ll11111l1_l1_:
		l11l1lllll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂ࡟ࠧࡡࠪ࡜ࠦ࡞ࡡࡠࠫࡢࠪ࡝ࡡ࡟ࡀࡡࡄ࡝ࠨ偮"),word,re.DOTALL)
		if l11l1lllll1l_l1_: word = word.split(l11l1lllll1l_l1_[0],1)[0]
		l11l1llll111_l1_ = word.replace(l11ll1_l1_ (u"ࠫ๖࠭偯"),l11ll1_l1_ (u"ࠬ࠭偰")).replace(l11ll1_l1_ (u"࠭๎ࠨ偱"),l11ll1_l1_ (u"ࠧࠨ偲")).replace(l11ll1_l1_ (u"ࠨํࠪ偳"),l11ll1_l1_ (u"ࠩࠪ側")).replace(l11ll1_l1_ (u"ࠪ๓ࠬ偵"),l11ll1_l1_ (u"ࠫࠬ偶")).replace(l11ll1_l1_ (u"ࠬ๒ࠧ偷"),l11ll1_l1_ (u"࠭ࠧ偸"))
		l11l1llll111_l1_ = l11l1llll111_l1_.replace(l11ll1_l1_ (u"ࠧ๑ࠩ偹"),l11ll1_l1_ (u"ࠨࠩ偺")).replace(l11ll1_l1_ (u"ࠩ๐ࠫ偻"),l11ll1_l1_ (u"ࠪࠫ偼")).replace(l11ll1_l1_ (u"ࠫ๗࠭偽"),l11ll1_l1_ (u"ࠬ࠭偾")).replace(l11ll1_l1_ (u"࠭ฌࠨ偿"),l11ll1_l1_ (u"ࠧࠨ傀")).replace(l11ll1_l1_ (u"ࠨโࠪ傁"),l11ll1_l1_ (u"ࠩࠪ傂"))
		if l11l1llll111_l1_: l11ll1111l1l_l1_.append(l11l1llll111_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll1111l1l_l1_)),l11ll1111l1l_l1_)
	l11l1lll1ll1_l1_ = []
	for l11ll11111_l1_ in range(0,20):
		search = random.sample(l11ll1111l1l_l1_,1)[0]
		if search in l11l1lll1ll1_l1_: continue
		l11l1lll1ll1_l1_.append(search)
		l1ll111l111_l1_ = random.sample(l11l1ll1l1ll_l1_,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ傃"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧ傄")+str(l1ll111l111_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨ傅")+search)
		#results = l1l1ll11lll1_l1_(l11ll1_l1_ (u"࠭ࠧ傆"),l11ll1_l1_ (u"ࠧࠨ傇"),l11ll1_l1_ (u"ࠨࠩ傈"),l1ll111l111_l1_,l11ll1_l1_ (u"ࠩࠪ傉"),l11ll1_l1_ (u"ࠪࠫ傊"),search+l11ll1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ傋"),l11ll1_l1_ (u"ࠬ࠭傌"),l11ll1_l1_ (u"࠭ࠧ傍"))
		l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
		l1ll1111lll_l1_(search+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ傎"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ傏"),l11ll1_l1_ (u"ࠩࠪ傐"))
	l11l1l11l1ll_l1_[0][1] = l11ll1_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ傑")+search+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅสะฯࠥ฿ๆࠡ࠼ࠣ࡟ࠥ࠭傒")
	menuItemsLIST[:] = l11l1ll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11l1lllll11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1lllll11_l1_)
	menuItemsLIST[:] = l11l1l11l1ll_l1_+menuItemsLIST
	#import l1lll11ll1l_l1_
	#l1lll11ll1l_l1_.SEARCH(search)
	return
def l11ll1111l11_l1_(l1ll111l111_l1_):
	l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
	try:
		if l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ傓") in l1ll111l111_l1_: l1l1lllllll_l1_(l1ll111l111_l1_)
		else: l1l1lllllll_l1_()
		l11l1lll1l1l_l1_ = False
	except: l11l1lll1l1l_l1_ = True
	l1ll111l111_l1_ = TRANSLATE(l1ll111l111_l1_)
	if l11l1lll1l1l_l1_: DIALOG_NOTIFICATION(l1ll111l111_l1_,l11ll1_l1_ (u"࠭แีๆࠣฬ์ึวࠡษ็้ํู่ࠨ傔"),time=2000)
	else: DIALOG_NOTIFICATION(l1ll111l111_l1_,l11ll1_l1_ (u"ࠧห็ࠣะ้ฮࠠศๆฦๆุอๅࠨ傕"),time=2000)
	return l11l1lll1l1l_l1_
def l11l1l1l11l1_l1_(l11l1lll111l_l1_=True):
	if not l11l1lll111l_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭傖"),l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ傗"),l11ll1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ傘"))
		if results:
			contentsDICT = results
			return
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ備"),l11ll1_l1_ (u"ࠬ࠭傚"),l11ll1_l1_ (u"࠭ࠧ傛"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ傜"),l11ll1_l1_ (u"ࠨๆๆ๎ࠥะๅๅศ๋ࠣีํࠠศๆๅหห๋ษࠡ࠰ࠣห้ฮั็ษ่ะࠥ๐อหษฯࠤศ์๋ࠠใะูࠥาๅ๋฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡใํࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎ุะฮาฮ้๋ࠣํวࠡใๅ฻ࠥอไฤไึห๊ࠦวๅำษ๎ุ๐ษࠡ࠰ࠣฯ๊๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ์ึ็ࠡษ็ว็ูวๆࠢะฮ๎ࠦไศࠢอัฯอฬࠡล้ࠤฯ๋ไว้สࠤ๊ืษࠡลัี๎ࠦ࠮ࠡ฻่่๏ฯࠠๆๆษࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣฮาะวอࠢ฼หิฯࠠฤไ็ࠤ๊์ࠠ࠴ࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬ傝"))
	if l1ll111ll1_l1_!=1: return
	l11l1l1l1l11_l1_ = menuItemsLIST[:]
	l11l1ll1l1l1_l1_,l11l1ll1l111_l1_ = 0,l11ll1_l1_ (u"ࠩࠪ傞")
	for l1ll111l111_l1_ in l11ll1ll111_l1_:
		l11l1lll1l1l_l1_ = l11ll1111l11_l1_(l1ll111l111_l1_)
		if l11l1lll1l1l_l1_:
			l11l1ll1l1l1_l1_ += 1
			l11l1ll1l111_l1_ += l11ll1_l1_ (u"ࠪࠤࠬ傟")+l1ll111l111_l1_
			if l11l1ll1l1l1_l1_>=l11l1lll1111_l1_: break
	menuItemsLIST[:] = l11l1l1l1l11_l1_
	if l11l1ll1l1l1_l1_>=l11l1lll1111_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ傠"),l11ll1_l1_ (u"ࠬ࠭傡"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ傢"),l11ll1_l1_ (u"ࠧๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠࠨ傣")+str(l11l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠨ่ࠢ์ฬู่ࠡ็้ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯๋ࠢือฮ็ศࠢๅำࠥ๐ใ้่ࠣ฽ิ๋้ࠠฮ๋ำࠥหๆหำ้๎ฯࠦแ๋ࠢฯ๋ฬุใ๊๊ࠡ๎࠿࠭傤")+l11l1ll1l111_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ傥"),l11ll1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ傦"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ傧"),l11ll1_l1_ (u"ࠬ࠭储"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ傩"),l11ll1_l1_ (u"ࠧห็ࠣะ้ฮࠠอ็ํ฽ࠥอไฤไึห๊ࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ศา่ส้ั࠭傪"))
	return
def l11l1ll111l1_l1_(l1lll111l1l1_l1_,options):
	if l11ll1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭傫") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ催"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭傭"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ傮")+l1lll111l1l1_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ傯")
	import IPTV
	if l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭傰") in options and l11ll1_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ傱") not in options:
		try: IPTV.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ傲"),l11ll1_l1_ (u"ࠩࠪ傳"),l11ll1_l1_ (u"ࠪࠫ傴"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ債"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭傶"),l11ll1_l1_ (u"࠭ࠧ傷"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ傸"),message)
		try: IPTV.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭傹"),l11ll1_l1_ (u"ࠩࠪ傺"),l11ll1_l1_ (u"ࠪࠫ傻"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傼"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭傽"),l11ll1_l1_ (u"࠭ࠧ傾"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ傿"),message)
		try: IPTV.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭僀"),l11ll1_l1_ (u"ࠩࠪ僁"),l11ll1_l1_ (u"ࠪࠫ僂"),options+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ僃"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭僄"),l11ll1_l1_ (u"࠭ࠧ僅"),l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ僆"),message)
	if l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ僇") in options and l11ll1_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ僈") not in options:
		try: IPTV.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ僉"),l11ll1_l1_ (u"ࠫࠬ僊"),l11ll1_l1_ (u"ࠬ࠭僋"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ僌"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ働"),l11ll1_l1_ (u"ࠨࠩ僎"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ像"),message)
		try: IPTV.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ僐"),l11ll1_l1_ (u"ࠫࠬ僑"),l11ll1_l1_ (u"ࠬ࠭僒"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ僓"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ僔"),l11ll1_l1_ (u"ࠨࠩ僕"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ僖"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭僗"),l11ll1_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ僘")+l1lll111l1l1_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11l1ll1lll1_l1_(l1lll111l1l1_l1_,options):
	if l11ll1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ僙") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ僚"),l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ僛"),l11ll1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ僜")+l1lll111l1l1_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ僝")
	import l1l1l1111lll_l1_
	if l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ僞") in options and l11ll1_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ僟") not in options:
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ僠"),l11ll1_l1_ (u"࠭ࠧ僡"),l11ll1_l1_ (u"ࠧࠨ僢"),options+l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僣"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ僤"),l11ll1_l1_ (u"ࠪࠫ僥"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ僦"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ僧"),l11ll1_l1_ (u"࠭ࠧ僨"),l11ll1_l1_ (u"ࠧࠨ僩"),options+l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僪"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ僫"),l11ll1_l1_ (u"ࠪࠫ僬"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ僭"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ僮"),l11ll1_l1_ (u"࠭ࠧ僯"),l11ll1_l1_ (u"ࠧࠨ僰"),options+l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僱"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ僲"),l11ll1_l1_ (u"ࠪࠫ僳"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ僴"),message)
	if l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ僵") in options and l11ll1_l1_ (u"࠭࡟ࡗࡑࡇࡣࠬ僶") not in options:
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ僷"),l11ll1_l1_ (u"ࠨࠩ僸"),l11ll1_l1_ (u"ࠩࠪ價"),options+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僺"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ僻"),l11ll1_l1_ (u"ࠬ࠭僼"),l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪ僽"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭僾"),l11ll1_l1_ (u"ࠨࠩ僿"),l11ll1_l1_ (u"ࠩࠪ儀"),options+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ儁"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ儂"),l11ll1_l1_ (u"ࠬ࠭儃"),l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪ億"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ儅"),l11ll1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ儆")+l1lll111l1l1_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11l1llll1ll_l1_(l1lll111l1l1_l1_,options,l11l1l1lll11_l1_):
	if l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ儇") in options:
		if l11ll1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ儈") in options and l11l1l1lll11_l1_==l11ll1_l1_ (u"ࠫࠬ儉"): l11l1l1l11l1_l1_(True)
		elif l11l1l1lll11_l1_: l11l1l1l11l1_l1_(False)
		#if contentsDICT=={}: return
	l11l1lll11l1_l1_ = options.replace(l11ll1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ儊"),l11ll1_l1_ (u"࠭ࠧ儋")).replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ儌"),l11ll1_l1_ (u"ࠨࠩ儍")).replace(l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭儎"),l11ll1_l1_ (u"ࠪࠫ儏"))
	if not l11l1l1lll11_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ儐"),l11ll1_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ儑"),l11ll1_l1_ (u"࠭ࠧ儒"),165,l11ll1_l1_ (u"ࠧࠨ儓"),l11ll1_l1_ (u"ࠨࠩ儔"),l11ll1_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ儕")+l11l1lll11l1_l1_,l11ll1_l1_ (u"ࠪࠫ儖"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ儗"):l1lll111l1l1_l1_})
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ儘"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭儙"),l11ll1_l1_ (u"ࠧࠨ儚"),9999)
	if l11ll1_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ儛") in options:
		l1ll1l1111_l1_ = [l11ll1_l1_ (u"ࠩฦๅ้อๅࠨ儜"),l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠫ儝"),l11ll1_l1_ (u"ู๊ࠫัฮ์สฮࠬ儞"),l11ll1_l1_ (u"ࠬฮัศ็ฯࠫ償"),l11ll1_l1_ (u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬ儠"),l11ll1_l1_ (u"ࠧา็ูห๋࠭儡"),l11ll1_l1_ (u"ࠨละำะ࠳รฯำࠪ儢"),l11ll1_l1_ (u"ࠩึ่ฬูไࠨ儣"),l11ll1_l1_ (u"้ࠪํู๊ใ๋ࠪ儤"),l11ll1_l1_ (u"ࠫศฺ็า࠯ฦ็ะืࠧ儥"),l11ll1_l1_ (u"ࠬอไร่ࠪ儦"),l11ll1_l1_ (u"࠭ึฮๅࠪ儧"),l11ll1_l1_ (u"ࠧา์สฺฮ࠭儨"),l11ll1_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ儩"),l11ll1_l1_ (u"่้ࠩะ๊๊็ࠩ優"),l11ll1_l1_ (u"ࠪฬะࠦอ๋ࠩ儫"),l11ll1_l1_ (u"ࠫิ๐ๆ๋หࠪ儬"),l11ll1_l1_ (u"ูࠬๆ้ษอࠫ儭"),l11ll1_l1_ (u"࠭รฯำ์ࠫ儮")]
		l11l1l1l1l1l_l1_ = [l11ll1_l1_ (u"ࠧศใ็ห๊࠭儯"),l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ儰"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ儱"),l11ll1_l1_ (u"ࠪๅ้๋ࠧ儲")]
		l11l1l1lllll_l1_ = [l11ll1_l1_ (u"ู๊ࠫไิๆࠪ儳"),l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ儴")]
		l11ll111l111_l1_ = [l11ll1_l1_ (u"࠭ๅิษิัࠬ儵"),l11ll1_l1_ (u"ࠧๆีิั๏อสࠨ儶")]
		l11l1l1llll1_l1_ = [l11ll1_l1_ (u"ࠨสิห๊าࠧ儷"),l11ll1_l1_ (u"ࠩࡶ࡬ࡴࡽࠧ儸"),l11ll1_l1_ (u"ࠪฮ้็า๋๊้ࠫ儹"),l11ll1_l1_ (u"ࠫฯ๊๊โิํ์๋࠭儺")]
		l11l1lll1lll_l1_ = [l11ll1_l1_ (u"ࠬอๆๆ์ࠪ儻"),l11ll1_l1_ (u"࠭ใาฬ๋๊ࠬ儼"),l11ll1_l1_ (u"ࠧไษิฮํ์ࠧ儽"),l11ll1_l1_ (u"ࠨ࡭࡬ࡨࡸ࠭儾"),l11ll1_l1_ (u"ฺࠩๅ้࠭儿"),l11ll1_l1_ (u"ࠪห฼็วๅࠩ兀")]
		l1111ll1_l1_ = [l11ll1_l1_ (u"ࠫึ๋ึศ่ࠪ允")]
		l1llll1ll_l1_ = [l11ll1_l1_ (u"ࠬออะอࠪ兂"),l11ll1_l1_ (u"࠭วฯำࠪ元"),l11ll1_l1_ (u"ࠧๆ๊ัีࠬ兄"),l11ll1_l1_ (u"ࠨฮา๎ิ࠭充"),l11ll1_l1_ (u"ฺ่ࠩฬ็ࠧ兆"),l11ll1_l1_ (u"ࠪัิ๐หࠨ兇")]
		l11l1ll111ll_l1_ = [l11ll1_l1_ (u"ุ๊ࠫวิๆࠪ先"),l11ll1_l1_ (u"ูࠬไิๆ๊ࠫ光")]
		l11l1l11lll1_l1_ = [l11ll1_l1_ (u"࠭ว฻ษ้๎ࠬ兊"),l11ll1_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ克"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭兌"),l11ll1_l1_ (u"ࠩะๅ้࠭免"),l11ll1_l1_ (u"ࠪࡱࡺࡹࡩࡤࠩ兎")]
		l111111l1_l1_ = [l11ll1_l1_ (u"ࠫฬ้หาࠩ兏"),l11ll1_l1_ (u"ࠬอิ่ำࠪ児"),l11ll1_l1_ (u"࠭ๅๆ์ี๋ࠬ兑"),l11ll1_l1_ (u"ࠧศ฻็ํࠬ兒"),l11ll1_l1_ (u"ࠨ็ัฮฬื็ࠨ兓"),l11ll1_l1_ (u"่ࠩาฯอัศฬࠪ兔"),l11ll1_l1_ (u"ࠪห็๎้ࠨ兕")]
		l11l1l1l11ll_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ว็ࠩ兖"),l11ll1_l1_ (u"ࠬำวๅ์ࠪ兗"),l11ll1_l1_ (u"࠭ๅฬสอࠫ兘"),l11ll1_l1_ (u"ࠧาษษะࠬ兙")]
		l11l1l1l111l_l1_ = [l11ll1_l1_ (u"ࠨุะ็ࠬ党"),l11ll1_l1_ (u"ࠩๆ์๊๐ฯ๋ࠩ兛")]
		l11l1l1l1ll1_l1_ = [l11ll1_l1_ (u"ࠪี๏อึ่ࠩ兜"),l11ll1_l1_ (u"่ࠫ๎ั่ࠩ兝"),l11ll1_l1_ (u"๋ࠬีศำ฼๋ࠬ兞"),l11ll1_l1_ (u"࠭ิ้ฬࠪ兟"),l11ll1_l1_ (u"ࠧา์สฺฮ࠭兠")]
		l11l1lll1l11_l1_ = [l11ll1_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ兡"),l11ll1_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ兢"),l11ll1_l1_ (u"๊ࠪ๏ะแๅ์ๆืࠬ兣")]
		l11l1ll1ll1l_l1_ = [l11ll1_l1_ (u"๊๋ࠫหๅ์้ࠫ兤"),l11ll1_l1_ (u"ࠬอิฯษุࠫ入"),l11ll1_l1_ (u"࠭ๆอ๊่ࠫ兦")]
		l1l1ll1ll_l1_ = [l11ll1_l1_ (u"ࠧษอࠣั๏࠭內"),l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭全"),l11ll1_l1_ (u"ࠩๅ๊ฬํࠧ兩"),l11ll1_l1_ (u"ࠪๆ๋๎วหࠩ兪")]
		l11l1ll1llll_l1_ = [l11ll1_l1_ (u"ࠫิ๐ๆࠨ八"),l11ll1_l1_ (u"ࠬอฯฺ์๊ࠫ公"),l11ll1_l1_ (u"࠭า๋ษิหฯ࠭六"),l11ll1_l1_ (u"ࠧๅู่๎ฬะࠧ兮"),l11ll1_l1_ (u"ࠨั฼หฦ࠭兯"),l11ll1_l1_ (u"ࠩๅีฬ์ࠧ兰"),l11ll1_l1_ (u"ࠪๆฺอฦะࠩ共"),l11ll1_l1_ (u"ࠫึัวยࠩ兲"),l11ll1_l1_ (u"๋ࠬัอ฻ํ๋ࠬ关"),l11ll1_l1_ (u"࠭วัษ้ࠫ兴"),l11ll1_l1_ (u"ࠧศี็ห๊࠭兵"),l11ll1_l1_ (u"ࠨฬ๋หู๐อࠨ其"),l11ll1_l1_ (u"ࠩั฻อ࠭具"),l11ll1_l1_ (u"ࠪัํุ่๋ࠩ典"),l11ll1_l1_ (u"ࠫ฾ะศศฬࠪ兹"),l11ll1_l1_ (u"๋่ࠬศๆํำࠬ兺"),l11ll1_l1_ (u"࠭ๆ้ษ฼๎ࠬ养"),l11ll1_l1_ (u"ฺࠧไสสิ࠭兼"),l11ll1_l1_ (u"ࠨษ้หู๐ฯࠨ兽")]
		l11l1llll1l1_l1_ = [l11ll1_l1_ (u"ࠩ࠴࠽ࠬ兾"),l11ll1_l1_ (u"ࠪ࠶࠵࠭兿"),l11ll1_l1_ (u"ࠫ࠷࠷ࠧ冀"),l11ll1_l1_ (u"ࠬ࠸࠲ࠨ冁"),l11ll1_l1_ (u"࠭࠲࠴ࠩ冂"),l11ll1_l1_ (u"ࠧ࠳࠶ࠪ冃"),l11ll1_l1_ (u"ࠨ࠴࠸ࠫ冄"),l11ll1_l1_ (u"ࠩ࠵࠺ࠬ内")]
		if not l11l1l1lll11_l1_:
			l11l1l1lll11_l1_ = 0
			for l11l1ll1ll11_l1_ in l1ll1l1111_l1_:
				l11l1l1lll11_l1_ += 1
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ円"),l111l1_l1_+l11l1ll1ll11_l1_,l11ll1_l1_ (u"ࠫࠬ冇"),165,l11ll1_l1_ (u"ࠬ࠭冈"),str(l11l1l1lll11_l1_),l11l1lll11l1_l1_,l11ll1_l1_ (u"࠭ࠧ冉"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冊"):l1lll111l1l1_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1lll1l1_l1_ = name.lower()
				category = []
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l1l1l_l1_): category.append(1)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1lllll_l1_): category.append(2)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll111l111_l1_): category.append(3)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1llll1_l1_): category.append(4)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll1lll_l1_): category.append(5)
				if any(value in l1ll1lll1l1_l1_ for value in l1111ll1_l1_): category.append(6)
				if any(value in l1ll1lll1l1_l1_ for value in l1llll1ll_l1_) and l1ll1lll1l1_l1_ not in [l11ll1_l1_ (u"ࠨษัี๎࠭冋")]: category.append(7)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll111ll_l1_): category.append(8)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l11lll1_l1_): category.append(9)
				if any(value in l1ll1lll1l1_l1_ for value in l111111l1_l1_): category.append(10)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l11ll_l1_): category.append(11)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l111l_l1_): category.append(12)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l1ll1_l1_): category.append(13)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll1l11_l1_): category.append(14)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1ll1l_l1_): category.append(15)
				if any(value in l1ll1lll1l1_l1_ for value in l1l1ll1ll_l1_): category.append(16)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1llll_l1_): category.append(17)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1llll1l1_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l11l1l1lll11_l1_:
						addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ册"),l111l1_l1_+name,name,166,l11ll1_l1_ (u"ࠪࠫ再"),l11ll1_l1_ (u"ࠫࠬ冎"),l11l1lll11l1_l1_+l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ冏"))
	elif l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭冐") in options:
		import IPTV
		#if l11ll1_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ冑") in options:
		l11l1l1l1111_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111l1l1_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True): return
			l11l1ll111l1_l1_(l1lll111l1l1_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠨࠩ冒"),True): return
			for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
				l11l1ll111l1_l1_(str(l1lll111l1l1_l1_),options)
			#else: l11l1l1l1111_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1l1111_l1_+menuItemsLIST[:]
	elif l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ冓") in options:
		import l1l1l1111lll_l1_
		#if l11ll1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ冔") in options:
		l11l1l1l1111_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111l1l1_l1_:
			if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True): return
			l11l1ll1lll1_l1_(l1lll111l1l1_l1_,options)
		else:
			if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠫࠬ冕"),True): return
			for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
				l11l1ll1lll1_l1_(str(l1lll111l1l1_l1_),options)
			#else: l11l1l1l1111_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1l1111_l1_+menuItemsLIST[:]
	return
def l11ll1111111_l1_(l11l1l1ll1ll_l1_,options):
	l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_.replace(l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ冖"),l11ll1_l1_ (u"࠭ࠧ冗"))
	options = options.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ冘"),l11ll1_l1_ (u"ࠨࠩ写")).replace(l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭冚"),l11ll1_l1_ (u"ࠪࠫ军"))
	l11l1l1l11l1_l1_(False)
	if contentsDICT=={}: return
	if l11ll1_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭农") in options:
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冝"),l11ll1_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ冞")+l11l1l1ll1ll_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭冟"),l11l1l1ll1ll_l1_,166,l11ll1_l1_ (u"ࠨࠩ冠"),l11ll1_l1_ (u"ࠩࠪ冡"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ冢")+options)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ冣"),l11ll1_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ冤"),l11l1l1ll1ll_l1_,166,l11ll1_l1_ (u"࠭ࠧ冥"),l11ll1_l1_ (u"ࠧࠨ冦"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭冧")+options)
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ冨"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ冩"),l11ll1_l1_ (u"ࠫࠬ冪"),9999)
	for l1l1l1l1_l1_ in sorted(list(contentsDICT[l11l1l1ll1ll_l1_].keys())):
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1l1ll1ll_l1_][l1l1l1l1_l1_]
		if l11ll1_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ冫") in options or len(contentsDICT[l11l1l1ll1ll_l1_])==1:
			l1l1ll11lll1_l1_(type,l11ll1_l1_ (u"࠭ࠧ冬"),url,l1l1llllll11_l1_,l11ll1_l1_ (u"ࠧࠨ冭"),l1l1111_l1_,text,l11ll1_l1_ (u"ࠨࠩ冮"),l11ll1_l1_ (u"ࠩࠪ冯"))
			menuItemsLIST[:] = l11l1ll11lll_l1_(menuItemsLIST)
			l11l1l1l1111_l1_,l1llll11ll1_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1llll11ll1_l1_)
			if l11ll1_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ冰") in options: menuItemsLIST[:] = l11l1l1l1111_l1_+l1llll11ll1_l1_[:l11l1lllll11_l1_]
			else: menuItemsLIST[:] = l11l1l1l1111_l1_+l1llll11ll1_l1_
		elif l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ冱") in options: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冲"),l1l1l1l1_l1_,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_)
	return
def l11l1ll11l11_l1_(options,mode):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ决"),l11ll1_l1_ (u"ࠧࠨ冴"),str(mode),options)
	options = options.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ况"),l11ll1_l1_ (u"ࠩࠪ冶")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ冷"),l11ll1_l1_ (u"ࠫࠬ冸"))
	name,l11l1ll1111l_l1_ = l11ll1_l1_ (u"ࠬ࠭冹"),[]
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭冺"),l11ll1_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ冻")+name+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ冼"),l11ll1_l1_ (u"ࠩࠪ冽"),mode,l11ll1_l1_ (u"ࠪࠫ冾"),l11ll1_l1_ (u"ࠫࠬ冿"),l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ净")+options)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭凁"),l11ll1_l1_ (u"ࠧฦ฻สำฮࠦืๅสࠣๆฺุ๋ࠠึ๋หห๐ࠧ凂"),l11ll1_l1_ (u"ࠨࠩ凃"),mode,l11ll1_l1_ (u"ࠩࠪ凄"),l11ll1_l1_ (u"ࠪࠫ凅"),l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ准")+options)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ凇"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭凈"),l11ll1_l1_ (u"ࠧࠨ凉"),9999)
	l11l1l1l1111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11ll1_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ凊") in options:
		l11l1l1l11l1_l1_(False)
		if contentsDICT=={}: return
		l11l1ll11ll1_l1_ = list(contentsDICT.keys())
		l11l1l1ll1ll_l1_ = random.sample(l11l1ll11ll1_l1_,1)[0]
		l11ll11111l1_l1_ = list(contentsDICT[l11l1l1ll1ll_l1_].keys())
		l1l1l1l1_l1_ = random.sample(l11ll11111l1_l1_,1)[0]
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1l1ll1ll_l1_][l1l1l1l1_l1_]
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ凋"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡻࡪࡨࡳࡪࡶࡨ࠾ࠥ࠭凌")+l1l1l1l1_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ凍")+name+l11ll1_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ凎")+url+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ减")+str(l1l1llllll11_l1_))
	elif l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ凐") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠨࠩ凑"),True): return
		for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
			l11l1ll111l1_l1_(str(l1lll111l1l1_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ凒"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ凓")+name+l11ll1_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭凔")+url+l11ll1_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ凕")+str(l1l1llllll11_l1_))
	elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ凖") in options:
		import l1l1l1111lll_l1_
		if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠧࠨ凗"),True): return
		for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
			l11l1ll1lll1_l1_(str(l1lll111l1l1_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ凘"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ凙")+name+l11ll1_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ凚")+url+l11ll1_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ凛")+str(l1l1llllll11_l1_))
	l11l1ll11111_l1_ = name
	l11l1ll1l11l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ凜"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭凝")+name+l11ll1_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ凞")+url+l11ll1_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ凟")+str(l1l1llllll11_l1_))
		menuItemsLIST[:] = []
		if l1l1llllll11_l1_==234 and l11ll1_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ几") in text: l1l1llllll11_l1_ = 233
		if l1l1llllll11_l1_==714 and l11ll1_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ凡") in text: l1l1llllll11_l1_ = 713
		if l1l1llllll11_l1_==144: l1l1llllll11_l1_ = 291
		html = l1l1ll11lll1_l1_(type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_)
		#if l11ll1_l1_ (u"ࠫࡤࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࡠࠩ凢") in html: l11l1ll11l11_l1_(options,mode)
		if l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ凣") in options and l1l1llllll11_l1_==167: del menuItemsLIST[:3]
		if l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ凤") in options and l1l1llllll11_l1_==168: del menuItemsLIST[:3]
		l11l1ll1111l_l1_[:] = l11l1ll11lll_l1_(menuItemsLIST)
		if l11l1ll1l11l_l1_ and l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡵࠨฯ็ๆฮ࠭凥")) in str(l11l1ll1111l_l1_) or l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶࠩะ่็ํࠧ処")) in str(l11l1ll1111l_l1_):
			name = l11l1ll11111_l1_
			l11l1ll1111l_l1_[:] = l11l1ll1l11l_l1_
			break
		l11l1ll11111_l1_ = name
		l11l1ll1l11l_l1_ = l11l1ll1111l_l1_[:]
		if str(l11l1ll1111l_l1_).count(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ凧"))>0: break
		if str(l11l1ll1111l_l1_).count(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ凨"))>0: break
		if l1l1llllll11_l1_==233: break	# iptv l111l1l1_l1_ names l11lll1ll11_l1_ of l1l11_l1_ name
		if l1l1llllll11_l1_==713: break	# l11l1l1ll11l_l1_ l111l1l1_l1_ names l11lll1ll11_l1_ of l1l11_l1_ name
		if l1l1llllll11_l1_==291: break	# l1ll1ll1l_l1_ l11ll111111l_l1_ names l11lll1ll11_l1_ of l1ll1ll1l_l1_ l11ll111111l_l1_ contents
		if l11l1ll1111l_l1_: type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ = random.sample(l11l1ll1111l_l1_,1)[0]
	if not name: name = l11ll1_l1_ (u"ࠫ࠳࠴࠮࠯ࠩ凩")
	elif name.count(l11ll1_l1_ (u"ࠬࡥࠧ凪"))>1: name = name.split(l11ll1_l1_ (u"࠭࡟ࠨ凫"),2)[2]
	name = name.replace(l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎ࠻ࠢࠪ凬"),l11ll1_l1_ (u"ࠨࠩ凭"))#.replace(l11ll1_l1_ (u"ࠩ࠯ࡑࡔ࡜ࡉࡆࡕ࠽ࠤࠬ凮"),l11ll1_l1_ (u"ࠪࠫ凯")).replace(l11ll1_l1_ (u"ࠫ࠱࡙ࡅࡓࡋࡈࡗ࠿ࠦࠧ凰"),l11ll1_l1_ (u"ࠬ࠭凱")).replace(l11ll1_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ凲"),l11ll1_l1_ (u"ࠧࠨ凳"))
	name = name.replace(l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ凴"),l11ll1_l1_ (u"ࠩࠪ凵"))
	l11l1l1l1111_l1_[0][1] = l11ll1_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ凶")+name+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅไึ้ࠥࡀࠠ࡜ࠢࠪ凷")
	for i in range(9): random.shuffle(l11l1ll1111l_l1_)
	if l11ll1_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ凸") in options: menuItemsLIST[:] = l11l1l1l1111_l1_+l11l1ll1111l_l1_[:l11l1lllll11_l1_]
	else: menuItemsLIST[:] = l11l1l1l1111_l1_+l11l1ll1111l_l1_
	return
def l11l1l1ll1l1_l1_(l11llllll1l1_l1_,l1l1111ll111_l1_):
	l1l1111ll111_l1_ = l1l1111ll111_l1_.replace(l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ凹"),l11ll1_l1_ (u"ࠧࠨ出")).replace(l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ击"),l11ll1_l1_ (u"ࠩࠪ凼"))
	l11l1ll11l1l_l1_ = l1l1111ll111_l1_
	if l11ll1_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ函") in l1l1111ll111_l1_:
		l11l1ll11l1l_l1_ = l1l1111ll111_l1_.split(l11ll1_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ凾"))[0]
		type = l11ll1_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ凿")
	elif l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ刀") in l11llllll1l1_l1_: type = l11ll1_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ刁")
	elif l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭刂") in l11llllll1l1_l1_: type = l11ll1_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ刃")
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ刄"),l11ll1_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ刅")+type+l11l1ll11l1l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ分"),l11llllll1l1_l1_,167,l11ll1_l1_ (u"࠭ࠧ切"),l11ll1_l1_ (u"ࠧࠨ刈"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭刉")+l1l1111ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ刊"),l11ll1_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ刋"),l11llllll1l1_l1_,167,l11ll1_l1_ (u"ࠫࠬ刌"),l11ll1_l1_ (u"ࠬ࠭刍"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ刎")+l1l1111ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ刏"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ刐"),l11ll1_l1_ (u"ࠩࠪ刑"),9999)
	import IPTV
	for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ划") in l1l1111ll111_l1_: IPTV.GROUPS(str(l1lll111l1l1_l1_),l11llllll1l1_l1_,l1l1111ll111_l1_,l11ll1_l1_ (u"ࠫࠬ刓"),False)
		else: IPTV.ITEMS(str(l1lll111l1l1_l1_),l11llllll1l1_l1_,l1l1111ll111_l1_,l11ll1_l1_ (u"ࠬ࠭刔"),False)
	menuItemsLIST[:] = l11l1ll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1lllll11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1lllll11_l1_)
	return
def l11l1l11llll_l1_(l11llllll1l1_l1_,l1l1111ll111_l1_):
	l1l1111ll111_l1_ = l1l1111ll111_l1_.replace(l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ刕"),l11ll1_l1_ (u"ࠧࠨ刖")).replace(l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ列"),l11ll1_l1_ (u"ࠩࠪ刘"))
	l11l1ll11l1l_l1_ = l1l1111ll111_l1_
	if l11ll1_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ则") in l1l1111ll111_l1_:
		l11l1ll11l1l_l1_ = l1l1111ll111_l1_.split(l11ll1_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ刚"))[0]
		type = l11ll1_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ创")
	elif l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ刜") in l11llllll1l1_l1_: type = l11ll1_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ初")
	elif l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭刞") in l11llllll1l1_l1_: type = l11ll1_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ刟")
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ删"),l11ll1_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ刡")+type+l11l1ll11l1l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ刢"),l11llllll1l1_l1_,168,l11ll1_l1_ (u"࠭ࠧ刣"),l11ll1_l1_ (u"ࠧࠨ判"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭別")+l1l1111ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ刦"),l11ll1_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ刧"),l11llllll1l1_l1_,168,l11ll1_l1_ (u"ࠫࠬ刨"),l11ll1_l1_ (u"ࠬ࠭利"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ刪")+l1l1111ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ别"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ刬"),l11ll1_l1_ (u"ࠩࠪ刭"),9999)
	import l1l1l1111lll_l1_
	for l1lll111l1l1_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ刮") in l1l1111ll111_l1_: l1l1l1111lll_l1_.GROUPS(str(l1lll111l1l1_l1_),l11llllll1l1_l1_,l1l1111ll111_l1_,l11ll1_l1_ (u"ࠫࠬ刯"),False)
		else: l1l1l1111lll_l1_.ITEMS(str(l1lll111l1l1_l1_),l11llllll1l1_l1_,l1l1111ll111_l1_,l11ll1_l1_ (u"ࠬ࠭到"),False)
	menuItemsLIST[:] = l11l1ll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1lllll11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1lllll11_l1_)
	return
def l11l1ll11lll_l1_(menuItemsLIST):
	l11l1ll1111l_l1_ = []
	for type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_ in menuItemsLIST:
		if l11ll1_l1_ (u"࠭ีโฯฬࠫ刱") in name or l11ll1_l1_ (u"ࠧึใะ๋ࠬ刲") in name or l11ll1_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭刳") in name.lower(): continue
		l11l1ll1111l_l1_.append([type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1l1lll_l1_,l1ll1ll1l11_l1_])
	return l11l1ll1111l_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙ࠫ㺛")
l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㺜")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11ll1_l1_ (u"࠭࠰ࠨ㺝"),True)
	elif mode==102: results = ITEMS(l11ll1_l1_ (u"ࠧ࠲ࠩ㺞"),True)
	elif mode==103: results = ITEMS(l11ll1_l1_ (u"ࠨ࠴ࠪ㺟"),True)
	elif mode==104: results = ITEMS(l11ll1_l1_ (u"ࠩ࠶ࠫ㺠"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11ll1_l1_ (u"ࠪ࠸ࠬ㺡"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺢"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ㺣")+l11ll1_l1_ (u"࠭ไๅ็ืฮึ้๊็ࠢหาิ๋ษࠡࡏ࠶࡙ࠬ㺤"),l11ll1_l1_ (u"ࠧࠨ㺥"),710)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㺦"),l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ㺧")+l11ll1_l1_ (u"่้๋ࠪิหำๆ๎๋ࠦศฯั่อࠥࡏࡐࡕࡘࠪ㺨"),l11ll1_l1_ (u"ࠫࠬ㺩"),230)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺪"),l11ll1_l1_ (u"࠭࡟ࡕࡘ࠳ࡣࠬ㺫")+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅ็่ࠢ์ฬู่่ษࠣห้ษีๅ์ฬࠫ㺬"),l11ll1_l1_ (u"ࠨࠩ㺭"),101)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺮"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠴ࡠࠩ㺯")+l11ll1_l1_ (u"ࠫ็์่ศฬ้ࠣำะวาห้๋๊้ࠣࠦฬํ์อ࠭㺰"),l11ll1_l1_ (u"ࠬ࠭㺱"),106)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺲"),l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㺳")+l11ll1_l1_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㺴"),l11ll1_l1_ (u"ࠩࠪ㺵"),147)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺶"),l11ll1_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㺷")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㺸"),l11ll1_l1_ (u"࠭ࠧ㺹"),148)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㺺"),l11ll1_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ㺻")+l11ll1_l1_ (u"ࠩࠣࠤ็์วสࠢล๎ࠥ็๊ๅ็้๋ࠣࠦๅ้ไ฼๋๊ࠦࠠࠨ㺼"),l11ll1_l1_ (u"ࠪࠫ㺽"),28)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㺾"),l11ll1_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ㺿")+l11ll1_l1_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㻀"),l11ll1_l1_ (u"ࠧࠨ㻁"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㻂"),l11ll1_l1_ (u"ࠩࡢࡏ࡜࡚࡟ࠨ㻃")+l11ll1_l1_ (u"ࠪๆ๋อษࠡษ็็ํััࠡ็้ࠤ๊๎โฺ้่ࠫ㻄"),l11ll1_l1_ (u"ࠫࠬ㻅"),135)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㻆"),l11ll1_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ㻇")+l11ll1_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ㻈"),l11ll1_l1_ (u"ࠨࠩ㻉"),38)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㻊"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㻋"),l11ll1_l1_ (u"ࠫࠬ㻌"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㻍"),l11ll1_l1_ (u"࠭࡟ࡕࡘ࠴ࡣࠬ㻎")+l11ll1_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ฼ห๊ฯࠧ㻏"),l11ll1_l1_ (u"ࠨࠩ㻐"),102)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻑"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠲ࡠࠩ㻒")+l11ll1_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦฮศืฬࠫ㻓"),l11ll1_l1_ (u"ࠬ࠭㻔"),103)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㻕"),l11ll1_l1_ (u"ࠧࡠࡖ࡙࠷ࡤ࠭㻖")+l11ll1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋ห่้ࠣ็อึࠩ㻗"),l11ll1_l1_ (u"ࠩࠪ㻘"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣ࡙࡜ࠧ㻙")+menu+l11ll1_l1_ (u"ࠫࡤ࠭㻚")
	user = l1l11l111ll_l1_(32)
	payload = {l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㻛"):l11ll1_l1_ (u"࠭ࠧ㻜"),l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࠬ㻝"):user,l11ll1_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㻞"):l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㻟"),l11ll1_l1_ (u"ࠪࡱࡪࡴࡵࠨ㻠"):menu}
	#data = l1ll1l11l_l1_(payload)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㻡"),str(payload))
	#LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㻢"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㻣"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠧࠨ㻤"), True,l11ll1_l1_ (u"ࠨࠩ㻥"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㻦"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㻧"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠫࠬ㻨"),l11ll1_l1_ (u"ࠬ࠭㻩"),l11ll1_l1_ (u"࠭ࠧ㻪"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ㻫"))
	html = response.content
	#html = html.replace(l11ll1_l1_ (u"ࠨ࡞ࡵࠫ㻬"),l11ll1_l1_ (u"ࠩࠪ㻭"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ㻮"),l11ll1_l1_ (u"ࠫࠬ㻯"),html,html)
	#file = open(l11ll1_l1_ (u"ࠬࡹ࠺࠰ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ㻰"), l11ll1_l1_ (u"࠭ࡷࠨ㻱"))
	#file.write(html)
	#file.close()
	items = re.findall(l11ll1_l1_ (u"ࠧࠩ࡝ࡡ࠿ࡡࡸ࡜࡯࡟࠮ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠩ࠰࠭ࡃ࠮ࡁ࠻ࠨ㻲"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11ll1_l1_ (u"ࠨࡣ࡯ࠫ㻳"),l11ll1_l1_ (u"ࠩࡄࡰࠬ㻴"))
			start = start.replace(l11ll1_l1_ (u"ࠪࡉࡱ࠭㻵"),l11ll1_l1_ (u"ࠫࡆࡲࠧ㻶"))
			start = start.replace(l11ll1_l1_ (u"ࠬࡇࡌࠨ㻷"),l11ll1_l1_ (u"࠭ࡁ࡭ࠩ㻸"))
			start = start.replace(l11ll1_l1_ (u"ࠧࡆࡎࠪ㻹"),l11ll1_l1_ (u"ࠨࡃ࡯ࠫ㻺"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11ll1_l1_ (u"ࠩࡄࡰ࠲࠭㻻"),l11ll1_l1_ (u"ࠪࡅࡱ࠭㻼"))
			start = start.replace(l11ll1_l1_ (u"ࠫࡆࡲࠠࠨ㻽"),l11ll1_l1_ (u"ࠬࡇ࡬ࠨ㻾"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1l11_l1_,name,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"࠭ࠣࠨ㻿") in source: continue
			#if source in [l11ll1_l1_ (u"ࠧࡏࡖࠪ㼀"),l11ll1_l1_ (u"ࠨ࡛ࡘࠫ㼁"),l11ll1_l1_ (u"࡚ࠩࡗ࠵࠭㼂"),l11ll1_l1_ (u"ࠪࡖࡑ࠷ࠧ㼃"),l11ll1_l1_ (u"ࠫࡗࡒ࠲ࠨ㼄")]: continue
			if source!=l11ll1_l1_ (u"࡛ࠬࡒࡍࠩ㼅"): name = name+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࠣࠤࠬ㼆")+source+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㼇")
			url = source+l11ll1_l1_ (u"ࠨ࠽࠾ࠫ㼈")+server+l11ll1_l1_ (u"ࠩ࠾࠿ࠬ㼉")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠪ࠿ࡀ࠭㼊")+menu
			addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㼋"),l111l1_l1_+l11ll1_l1_ (u"ࠬ࠭㼌")+name,url,105,l1lll1_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㼍"),l111l1_l1_+l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㼎"),l11ll1_l1_ (u"ࠨࠩ㼏"),9999)
		#if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㼐"),l11ll1_l1_ (u"ࠪࠫ㼑"),l11ll1_l1_ (u"ࠫࠬ㼒"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㼓"))
		#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㼔"),l111l1_l1_+l11ll1_l1_ (u"ࠧๅๆฦืๆࠦไศࠢอ์ัีࠠใ่๋หฯࠦสๅใี์๋๐ษࠡๆๆࠫ㼕"),l11ll1_l1_ (u"ࠨࠩ㼖"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㼗"),l111l1_l1_+l11ll1_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅษๅีออม๊ࠡส่ฬ฻ฯใษฤࠤๆ่ืࠨ㼘"),l11ll1_l1_ (u"ࠫࠬ㼙"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㼚"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㼛"),l11ll1_l1_ (u"ࠧࠨ㼜"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㼝"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡘࡲ࡫ࡵࡲࡵࡷࡱࡥࡹ࡫࡬ࡺ࠮ࠣࡲࡴࠦࡔࡗࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠤ࡫ࡵࡲࠡࡻࡲࡹࠬ㼞"),l11ll1_l1_ (u"ࠪࠫ㼟"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㼠"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡏࡴࠡ࡫ࡶࠤ࡫ࡵࡲࠡࡴࡨࡰࡦࡺࡩࡷࡧࡶࠤࠫࠦࡦࡳ࡫ࡨࡲࡩࡹࠠࡰࡰ࡯ࡽࠬ㼡"),l11ll1_l1_ (u"࠭ࠧ㼢"),9999)
	return
def PLAY(id):
	source,server,l11lll1l11_l1_,menu = id.split(l11ll1_l1_ (u"ࠧ࠼࠽ࠪ㼣"))
	url = l11ll1_l1_ (u"ࠨࠩ㼤")
	user = l1l11l111ll_l1_(32)
	if source==l11ll1_l1_ (u"ࠩࡘࡖࡑ࠭㼥"): url = l11lll1l11_l1_
	elif source==l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㼦"):
		url = l1l1lll_l1_[l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㼧")][0]+l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㼨")+l11lll1l11_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ㼩"),url)
		return
	elif source==l11ll1_l1_ (u"ࠧࡈࡃࠪ㼪"):
		payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ㼫") : l11ll1_l1_ (u"ࠩࠪ㼬"), l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㼭") : user , l11ll1_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㼮") : l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠶࠭㼯") , l11ll1_l1_ (u"࠭࡭ࡦࡰࡸࠫ㼰") : l11ll1_l1_ (u"ࠧࠨ㼱") }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㼲"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠩࠪ㼳"),False,l11ll1_l1_ (u"ࠪࠫ㼴"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㼵"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㼶"),l11ll1_l1_ (u"࠭ࠧ㼷"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㼸"),l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㼹"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l111llll1l_l1_ = cookies[l11ll1_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩ࠭㼺")]
		url = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㼻")]
		payload = { l11ll1_l1_ (u"ࠫ࡮ࡪࠧ㼼") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࠪ㼽") : user , l11ll1_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㼾") : l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠲ࠨ㼿") , l11ll1_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㽀") : l11ll1_l1_ (u"ࠩࠪ㽁") }
		headers = { l11ll1_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ㽂") : l11ll1_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤ࠾ࠩ㽃")+l1l111llll1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㽄"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"࠭ࠧ㽅"),l11ll1_l1_ (u"ࠧࠨ㽆"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㽇"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㽈"),l11ll1_l1_ (u"ࠪࠫ㽉"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㽊"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㽋"))
			return
		html = response.content
		url = re.findall(l11ll1_l1_ (u"࠭ࡲࡦࡵࡳࠦ࠿ࠨࠨࡩࡶࡷࡴ࠳࠰࠿࡮࠵ࡸ࠼࠮࠮࠮ࠫࡁࠬࠦࠬ㽌"),html,re.DOTALL)
		l1lllll_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ㽍"),l11ll1_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠡࠩ㽎")+l1lllll_l1_)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ㽏"),l11ll1_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠫ㽐")+params)
		l1l111llll11_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠸࠾࠮ࠨ㽑")+server+l11ll1_l1_ (u"ࠬ࠽࠷࠸࠱ࠪ㽒")+l11lll1l11_l1_+l11ll1_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㽓")+params
		l1l111lll1ll_l1_ = l1l111llll11_l1_.replace(l11ll1_l1_ (u"ࠧ࠴࠸࠽࠻ࠬ㽔"),l11ll1_l1_ (u"ࠨ࠶࠳࠾࠼࠭㽕")).replace(l11ll1_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㽖"),l11ll1_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㽗"))
		l1l111lllll1_l1_ = l1l111llll11_l1_.replace(l11ll1_l1_ (u"ࠫ࠸࠼࠺࠸ࠩ㽘"),l11ll1_l1_ (u"ࠬ࠺࠲࠻࠹ࠪ㽙")).replace(l11ll1_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㽚"),l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㽛"))
		l1lll11l_l1_ = [l11ll1_l1_ (u"ࠨࡊࡇࠫ㽜"),l11ll1_l1_ (u"ࠩࡖࡈ࠶࠭㽝"),l11ll1_l1_ (u"ࠪࡗࡉ࠸ࠧ㽞")]
		l1llll_l1_ = [l1l111llll11_l1_,l1l111lll1ll_l1_,l1l111lllll1_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㽟"), l1lll11l_l1_)
		if l1l_l1_ == -1: return
		else: url = l1llll_l1_[l1l_l1_]
	elif source==l11ll1_l1_ (u"ࠬࡔࡔࠨ㽠"):
		headers = { l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㽡") : l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㽢") }
		payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ㽣") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㽤") : user , l11ll1_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㽥") : l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡐࡗࠫ㽦") , l11ll1_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㽧") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㽨"), l11l1l_l1_, payload, headers, False,l11ll1_l1_ (u"ࠧࠨ㽩"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㽪"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㽫"),l11ll1_l1_ (u"ࠪࠫ㽬"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㽭"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㽮"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㽯")]
		url = url.replace(l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫ㽰"),l11ll1_l1_ (u"ࠨࠢࠪ㽱"))
		url = url.replace(l11ll1_l1_ (u"ࠩࠨ࠷ࡉ࠭㽲"),l11ll1_l1_ (u"ࠪࡁࠬ㽳"))
		if l11ll1_l1_ (u"ࠫࡑ࡫ࡡࡳࡰࠪ㽴") in l11lll1l11_l1_:
			url = url.replace(l11ll1_l1_ (u"ࠬࡔࡔࡏࡐ࡬ࡰࡪ࠭㽵"),l11ll1_l1_ (u"࠭ࠧ㽶"))
			url = url.replace(l11ll1_l1_ (u"ࠧ࡭ࡧࡤࡶࡳ࡯࡮ࡨ࠳ࠪ㽷"),l11ll1_l1_ (u"ࠨࡎࡨࡥࡷࡴࡩ࡯ࡩࠪ㽸"))
	elif source==l11ll1_l1_ (u"ࠩࡓࡐࠬ㽹"):
		#headers = { l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㽺") : l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㽻") }
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㽼") : l11lll1l11_l1_ , l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㽽") : user , l11ll1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㽾") : l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾࡖࡌࠨ㽿") , l11ll1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㾀") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㾁"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠫࠬ㾂"),False,l11ll1_l1_ (u"ࠬ࠭㾃"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ㾄"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㾅"),l11ll1_l1_ (u"ࠨࠩ㾆"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㾇"),l11ll1_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㾈"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㾉")]
		headers = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㾊"):response.headers[l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㾋")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㾌"),url, l11ll1_l1_ (u"ࠨࠩ㾍"),headers , l11ll1_l1_ (u"ࠩࠪ㾎"),l11ll1_l1_ (u"ࠪࠫ㾏"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭㾐"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㾑"),l11ll1_l1_ (u"࠭ࠧ㾒"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㾓"),l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㾔"))
			return
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㾕"),html,re.DOTALL)
		url = items[0]
	elif source in [l11ll1_l1_ (u"ࠪࡘࡆ࠭㾖"),l11ll1_l1_ (u"ࠫࡋࡓࠧ㾗"),l11ll1_l1_ (u"ࠬ࡟ࡕࠨ㾘"),l11ll1_l1_ (u"࠭ࡗࡔ࠳ࠪ㾙"),l11ll1_l1_ (u"ࠧࡘࡕ࠵ࠫ㾚"),l11ll1_l1_ (u"ࠨࡔࡏ࠵ࠬ㾛"),l11ll1_l1_ (u"ࠩࡕࡐ࠷࠭㾜")]:
		if source==l11ll1_l1_ (u"ࠪࡘࡆ࠭㾝"): l11lll1l11_l1_ = id
		headers = { l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㾞") : l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㾟") }
		payload = { l11ll1_l1_ (u"࠭ࡩࡥࠩ㾠") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࠬ㾡") : user , l11ll1_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㾢") : l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࠧ㾣")+source , l11ll1_l1_ (u"ࠪࡱࡪࡴࡵࠨ㾤") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㾥"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠬ࠭㾦"),l11ll1_l1_ (u"࠭ࠧ㾧"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ㾨"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㾩"),l11ll1_l1_ (u"ࠩࠪ㾪"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㾫"),l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㾬"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㾭")]
		if source==l11ll1_l1_ (u"࠭ࡆࡎࠩ㾮"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㾯"), url, l11ll1_l1_ (u"ࠨࠩ㾰"), l11ll1_l1_ (u"ࠩࠪ㾱"), False,l11ll1_l1_ (u"ࠪࠫ㾲"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠺ࡸ࡭࠭㾳"))
			url = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㾴")]
			url = url.replace(l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ㾵"),l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ㾶"))
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㾷"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬඵ")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩබ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==130: results = MENU()
	elif mode==131: results = l11111_l1_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l1llll1l_l1_(url,l1l1111_l1_)
	elif mode==134: results = PLAY(url)
	elif mode==135: results = l1l1ll1ll_l1_()
	elif mode==139: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩභ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไษอࠣห้ำ๊ࠡๆๅ๊ฬฯࠠศๆๆ์ะืࠧම"),l11ll1_l1_ (u"࠭ࠧඹ"),135)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧය"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨර"),l11ll1_l1_ (u"ࠩࠪ඼"),139,l11ll1_l1_ (u"ࠪࠫල"),l11ll1_l1_ (u"ࠫࠬ඾"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ඿"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫව"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧශ"),l11ll1_l1_ (u"ࠨࠩෂ"),9999)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪස"),l11ll1_l1_ (u"ࠪࠫහ"),True,l11ll1_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩළ"))
	l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡹࡵࡧࡨ࡮ࡨࠫෆ"),html,re.DOTALL)
	block = l1l1l11_l1_[1]
	items=re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ෇"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠧ࠰ࡥࡲࡲࡩࡻࡣࡵࡱࡵࠫ෈") in l1lllll_l1_: continue
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ෉"))
		#l1l1lllll_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡲࡩࡨ࡫ࡲࡹࡸ්࠭"),l11ll1_l1_ (u"ࠪ࠳ࡸࡵࡣࡪࡣ࡯ࠫ෋"),l11ll1_l1_ (u"ࠫ࠴ࡶ࡯࡭࡫ࡷ࡭ࡨࡧ࡬ࠨ෌")]
		#if any(value in l1lllll_l1_ for value in l1l1lllll_l1_):
		#	title = l11ll1_l1_ (u"ࠬอไษำส้ัࠦࠧ෍")+title
		url = l11l1l_l1_+l1lllll_l1_
		if l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪ෎") in url: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧා"),l111l1_l1_+title,url,132)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨැ"),l111l1_l1_+title,url,131)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧෑ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪි"),l11ll1_l1_ (u"ࠫࠬී"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬු"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ෕")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠪූ"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠺࠳ࠨ෗"),132,l11ll1_l1_ (u"ࠩࠪෘ"),l11ll1_l1_ (u"ࠪ࠵ࠬෙ"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫේ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧෛ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅลไ่ฬ๋ࠧො"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠺࠷࠾ࠧෝ"),132,l11ll1_l1_ (u"ࠨࠩෞ"),l11ll1_l1_ (u"ࠩ࠴ࠫෟ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෠"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭෡")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮัศ็ฯࠤฬ๊ี฻ษิࠤํอไีสสฬࠬ෢"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠸࠵࠼࠭෣"),132,l11ll1_l1_ (u"ࠧࠨ෤"),l11ll1_l1_ (u"ࠨ࠳ࠪ෥"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ෦"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ෧")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬฮัำࠢส่อืวๆฮࠪ෨"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠳࠺࠺࠸࠭෩"),132,l11ll1_l1_ (u"࠭ࠧ෪"),l11ll1_l1_ (u"ࠧ࠲ࠩ෫"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ෬"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ෭")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋อศุิหฯ࠭෮"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠺࠶࠶ࠫ෯"),132,l11ll1_l1_ (u"ࠬ࠭෰"),l11ll1_l1_ (u"࠭࠱ࠨ෱"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧෲ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪෳ")+l111l1_l1_+l11ll1_l1_ (u"ࠩ฼หู๎ัศรࠪ෴"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠱࠴࠷࠶ࠫ෵"),132,l11ll1_l1_ (u"ࠫࠬ෶"),l11ll1_l1_ (u"ࠬ࠷ࠧ෷"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෸"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ෹")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ฬึอๅอࠢส่ฬาสๆษ฼๎ฮ࠭෺"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠰࠲ࠩ෻"),132,l11ll1_l1_ (u"ࠪࠫ෼"),l11ll1_l1_ (u"ࠫ࠶࠭෽"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෾"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ෿")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็ำ๏์๊สࠩ฀"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠶࠹ࠨก"),132,l11ll1_l1_ (u"ࠩࠪข"),l11ll1_l1_ (u"ࠪ࠵ࠬฃ"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫค"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧฅ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅสิห๊าࠠศๆ๋ฯฬฬโ๋หࠪฆ"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠺࠹ࠧง"),132,l11ll1_l1_ (u"ࠨࠩจ"),l11ll1_l1_ (u"ࠩ࠴ࠫฉ"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪช"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ซ")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไษำส้ัࠦวๅีํหุ๐ษࠨฌ"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠸࠸࠺࠭ญ"),132,l11ll1_l1_ (u"ࠧࠨฎ"),l11ll1_l1_ (u"ࠨ࠳ࠪฏ"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩฐ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬฑ")+l111l1_l1_+l11ll1_l1_ (u"่ࠫะศࠨฒ"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠴࠼࠵ࠬณ"),132,l11ll1_l1_ (u"࠭ࠧด"),l11ll1_l1_ (u"ࠧ࠲ࠩต"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨถ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫท")+l111l1_l1_+l11ll1_l1_ (u"ࠪฮ฾๊ๅࠡษ็ๅฬืำ๋หࠪธ"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠹࠺ࠪน"),132,l11ll1_l1_ (u"ࠬ࠭บ"),l11ll1_l1_ (u"࠭࠱ࠨป"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧผ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪฝ")+l111l1_l1_+l11ll1_l1_ (u"ࠩฦีู๐แࠡษ็ฬึอๅอࠩพ"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠱࠳࠹࠼ࠫฟ"),132,l11ll1_l1_ (u"ࠫࠬภ"),l11ll1_l1_ (u"ࠬ࠷ࠧม"))
	return
def l11111_l1_(url):
	l1l1lllll_l1_ = [l11ll1_l1_ (u"࠭࠯ࡳࡧ࡯࡭࡬࡯࡯ࡶࡵࠪย"),l11ll1_l1_ (u"ࠧ࠰ࡵࡲࡧ࡮ࡧ࡬ࠨร"),l11ll1_l1_ (u"ࠨ࠱ࡳࡳࡱ࡯ࡴࡪࡥࡤࡰࠬฤ"),l11ll1_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴࠩล"),l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶࠫฦ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬว"),l11ll1_l1_ (u"ࠬ࠭ศ"),True,l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ษ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡴࡪࡶ࡯ࡩࡧࡧࡲࠨส"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	if any(value in url for value in l1l1lllll_l1_):
		items = re.findall(l11ll1_l1_ (u"ࠣࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥห"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫฬ"))
			l1lllll_l1_ = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪอ"),l111l1_l1_+title,l1lllll_l1_,133,l1lll1_l1_,l11ll1_l1_ (u"ࠫ࠶࠭ฮ"))
	elif l11ll1_l1_ (u"ࠬ࠵ࡤࡰࡥࡶࠫฯ") in url:
		items = re.findall(l11ll1_l1_ (u"ࠨࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧࠣะ"),block,re.DOTALL)
		for l1lll1_l1_,title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩั"))
			l1lllll_l1_ = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨา"),l111l1_l1_+title,l1lllll_l1_,133,l1lll1_l1_,l11ll1_l1_ (u"ࠩ࠴ࠫำ"))
	return
def CATEGORIES(url):
	category = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬิ"))[-1]
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬี"),l11ll1_l1_ (u"ࠬ࠭ึ"),True,l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪื"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡵࡩࡳࡺࡣࡢࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄุࠧ"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l1llll1l_l1_(url,l11ll1_l1_ (u"ࠨ࠳ูࠪ"))
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ฺࠦ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		#l1l1llll1_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ฻"))[-1]
		#if category==l1l1llll1_l1_: continue
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭฼"))
		l1lllll_l1_ = l11l1l_l1_ + l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ฽"),l111l1_l1_+title,l1lllll_l1_,132,l11ll1_l1_ (u"࠭ࠧ฾"),l11ll1_l1_ (u"ࠧ࠲ࠩ฿"))
	return
def l1llll1l_l1_(url,l1l1111_l1_):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠨࠩเ"),l11ll1_l1_ (u"ࠩࠪแ"),True,l11ll1_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬโ"))
	items = re.findall(l11ll1_l1_ (u"ࠫࡹࡵࡴࡢ࡮ࡳࡥ࡬࡫ࡣࡰࡷࡱࡸࡂࡡ࡜ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣࠧใ"),html,re.DOTALL)
	if not items:
		url = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡴࡥࡸࡵ࠰ࡨࡪࡺࡡࡪ࡮࠰ࡦࡴࡪࡹࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪไ"),html,re.DOTALL)
		url = url[0]
		title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬๅ") + l11ll1_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬๆ")
		if url: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ็"),l111l1_l1_+title,url,134)
		else: DIALOG_OK(l11ll1_l1_ (u"่ࠩࠪ"),l11ll1_l1_ (u"้ࠪࠫ"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า๊ࠧ"),l11ll1_l1_ (u"๊ࠬวࠡ์๋ะิࠦอศๆํห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣๅ๏ࠦ็ัษࠣห้็ัฺ๋ࠩ"))
		return
	l1l1lll11_l1_ = int(items[0])
	name = re.findall(l11ll1_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࡂ࠯ࡢࡀࠣࡂ࠭࠴ࠪࡀࠫ࠿ࠫ์"),html,re.DOTALL)
	if name: name = name[0].strip(l11ll1_l1_ (u"ࠧࠡࠩํ"))
	else: name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ๎"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ๏"),l11ll1_l1_ (u"ࠪࠫ๐"),name, str(l11ll1_l1_ (u"ࠫࠬ๑")))
	if l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ๒") in url or l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ๓") in url:
		category = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ๔"))[-1]
		if l1l1111_l1_==l11ll1_l1_ (u"ࠨࠩ๕"): l111lll_l1_ = url
		else: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭๖") + category + l11ll1_l1_ (u"ࠪ࠳ࠬ๗") + l1l1111_l1_
		l11ll1ll_l1_ = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ๘"),l11ll1_l1_ (u"ࠬ࠭๙"),True,l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ๚"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡱࡣࡪࡩࡳࡻ࡭ࡣࡧࡵࠬ࠳࠰࠿ࠪࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ๛"),l11ll1ll_l1_,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡨࡸࡰࡱ࠮࠮ࠫࡁࠬࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ๜"),block,re.DOTALL)
		for l1lll1_l1_,type,l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๝") not in type: continue
			if l11ll1_l1_ (u"ุ้๊ࠪำๅࠩ๞") in title and l11ll1_l1_ (u"ࠫา๊โสࠩ๟") not in title: continue
			title = title.replace(l11ll1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ๠"),l11ll1_l1_ (u"࠭ࠧ๡"))
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ๢"))
			if l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ๣") in name and l11ll1_l1_ (u"ࠩะ่็ฯࠧ๤") in title and l11ll1_l1_ (u"ุ้๊ࠪำๅࠩ๥") not in title:
				title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ๦") + name + l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ๧") + title
			l1lllll_l1_ = l11l1l_l1_ + l1lllll_l1_
			if category==l11ll1_l1_ (u"࠭࠶࠳࠺ࠪ๨"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ๩"),l111l1_l1_+title,l1lllll_l1_,133,l1lll1_l1_,l11ll1_l1_ (u"ࠨ࠳ࠪ๪"))
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๫"),l111l1_l1_+title,l1lllll_l1_,134,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭๬") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡧࡴࡲ࠭࡮ࡦ࠰࠵࠷࠭๭"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡼࡩࡥࡧࡲ࠱ࡹࡸࡡࡤ࡭࠰ࡸࡪࡾࡴ࠯ࠬࡂࡰࡴࡧࡤࡗ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ๮"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ๯"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭๰"),l111l1_l1_+title,l1lllll_l1_,134,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠻࠸࠸ࠨ๱") in html:
				title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ๲") + l11ll1_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ๳")
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๴"),l111l1_l1_+title,url,134)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡆࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ๵"),html,re.DOTALL)
			category = items[0].split(l11ll1_l1_ (u"࠭࠯ࠨ๶"))[-1]
			url = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫ๷") + category
			CATEGORIES(url)
			return
		l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡴࡰࡶࡤࡰࡵࡧࡧࡦࡵࠣࡁࠥ࠶ࠊࠊࠋࠌࡩࡵ࡯ࡳࡰࡦࡨࡍࡉࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪ࡝࠰࠵ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡉࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟࠱ࡷࡵࡲࡩࡵࠪࠪ࠳ࠬ࠯࡛࠮࠳ࡠࠎࠎࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡢ࡬ࡤࡼ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨࠢ࠮ࠤࡨࡧࡴࡦࡩࡲࡶࡾࠦࠫࠡࠩ࠲ࠫࠥ࠱ࠠࡱࡣࡪࡩࠏࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠸ࠬࠨࠩ࠯ࠫࠬ࠲ࡔࡳࡷࡨ࠰ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠷ࡷࡪࠧࠪࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠤࡁ࡮࠵࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡳࡧ࠭࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࡏࡄ࡯ࡧࡺࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠴࠭ࠩ࡜࠯࠴ࡡࠏࠏࠉࠊࠋ࡬ࡪࠥ࡫ࡰࡪࡵࡲࡨࡪࡏࡄ࡯ࡧࡺࡁࡂ࡫ࡰࡪࡵࡲࡨࡪࡏࡄ࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡸ࡬ࡨࡪࡵࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠳࠶࠸࠱࡯࡭ࡨࠫࠍࠍࠎࠨࠢࠣ๸")
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠲࠮࠴࠯ࡹࡵࡴࡢ࡮ࡳࡥ࡬࡫ࡳࠪ࠼ࠍࠍࠎ࡯ࡦࠡࡲࡤ࡫ࡪࠧ࠽ࡴࡶࡵࠬ࡮࠯࠺ࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨืไัฮࠦࠧࠬࡵࡷࡶ࠭࡯ࠩ࠭ࡷࡵࡰ࠱࠷࠳࠴࠮ࠪࠫ࠱ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࠣࠤࠥ๹")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ๺"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1l1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭๻"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1lll_l1_:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫ๼"),l11ll1_l1_ (u"࠭ࠦࠨ๽"))
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ๾"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ๿")+title,l1lllll_l1_,133)
	return
def PLAY(url):
	if l11ll1_l1_ (u"ࠩ࠲ࡲࡪࡽࡳ࠰ࠩ຀") in url or l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ກ") in url:
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠫࠬຂ"),l11ll1_l1_ (u"ࠬ࠭຃"),True,l11ll1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫຄ"))
		items = re.findall(l11ll1_l1_ (u"ࠢ࡮ࡱࡥ࡭ࡱ࡫ࡶࡪࡦࡨࡳࡵࡧࡴࡩ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠫ࠭࠴ࠪࡀࠫࠪࠦ຅"),html,re.DOTALL)
		if items: url = items[0]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧຆ"))
	return
def l1l1ll1ll_l1_():
	#l1ll111l1_l1_(l11ll1_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨງ"))
	#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠪะฬื๊ࠡฬื฾๏๊ࠠศๆๅ๊ฬฯࠧຈ"),l11ll1_l1_ (u"ࠫࠬຉ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡸࡨࠫຊ")
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"࠭ࠧ຋"),l11ll1_l1_ (u"ࠧࠨຌ"),True,l11ll1_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭ຍ"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪຎ"),html,re.DOTALL)
	l111lll_l1_ = l111lll_l1_[0]
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫຏ"):l11l1l_l1_}
	l1ll1111l_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨຐ"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭ຑ"),l1l1ll11l_l1_,l11ll1_l1_ (u"࠭ࠧຒ"),True,l11ll1_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡐࡎ࡜ࡅ࠮࠴ࡱࡨࠬຓ"))
	l11ll1ll_l1_ = l1ll1111l_l1_.content
	token = re.findall(l11ll1_l1_ (u"ࠨࡥࡶࡶ࡫࠳ࡴࡰ࡭ࡨࡲࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨດ"),l11ll1ll_l1_,re.DOTALL)
	token = token[0]
	l1l1lll1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭ຕ"))
	l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡴࡱࡧࡹࡖࡴ࡯ࠤࡂࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢຖ"),l11ll1ll_l1_,re.DOTALL)
	l11l111_l1_ = l1l1lll1l_l1_+l11l111_l1_[0]
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬທ"),l11l111_l1_)
	l1l1ll111_l1_ = {l11ll1_l1_ (u"ࠬ࡞࠭ࡄࡕࡕࡊ࠲࡚ࡏࡌࡇࡑࠫຘ"):token}
	l1ll11111_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫນ"),l11l111_l1_,l11ll1_l1_ (u"ࠧࠨບ"),l1l1ll111_l1_,False,True,l11ll1_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡑࡏࡖࡆ࠯࠶ࡶࡩ࠭ປ"))
	l1l1ll1l1_l1_ = l1ll11111_l1_.content
	l1llllll1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪຜ"),l1l1ll1l1_l1_,re.DOTALL)
	l1llllll1_l1_ = l1llllll1_l1_[0].replace(l11ll1_l1_ (u"ࠪࡠ࠴࠭ຝ"),l11ll1_l1_ (u"ࠫ࠴࠭ພ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ຟ"),l11ll1_l1_ (u"࠭ࠧຠ"),url,html)
	#l1ll111l1_l1_(l11ll1_l1_ (u"ࠧࡴࡶࡲࡴࠬມ"))
	PLAY_VIDEO(l1llllll1_l1_,script_name,l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭ຢ"))
	return
def SEARCH(search,url=l11ll1_l1_ (u"ࠩࠪຣ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if url==l11ll1_l1_ (u"ࠪࠫ຤"):
		if search==l11ll1_l1_ (u"ࠫࠬລ"): search = OPEN_KEYBOARD()
		if search==l11ll1_l1_ (u"ࠬ࠭຦"): return
		#search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨວ"),l11ll1_l1_ (u"ࠧࠬࠩຨ"))
		#search = l11ll1_l1_ (u"ࠨ࠯ࡷࡥ࡬ࠦࡤࡰࡥࡶࠤࡔࡘࠠࡧ࡫࡯ࡱࡸࠦࡏࡓࠢࡶࡩࡷ࡯ࡥࡴࠢࡒࡖࠥ࡫ࡰࡪࡵࡲࡨࡪࠦࡏࡓࠢࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠤࡔࡘࠠࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡒࡖࠥࡴࡥࡸࡵࠣࡱࡵ࠺ࠠࠨຩ")+search
		#search = l11ll1_l1_ (u"ࠩࠥࡱࡵ࠺ࠢࠡࠩສ")+search
		search = QUOTE(search)
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧຫ")+search
		l1llll1l_l1_(url,l11ll1_l1_ (u"ࠫࠬຬ"))
		return
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࡚ࡲࡶࡧ࠯ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࡥࡻࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠦࡻࡧࡲࠡࡥࡻࠤࡂࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࡞࠴ࡢࠐࠉࠊࡷࡵࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠧ࡭ࡣࡴࡧ࠱ࡷࡷࡩࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࡡ࠰࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡹࡷࡲࠫࡤࡺࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࡕࡴࡸࡩ࠱࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌࡧࡸ࡫࡟ࡵࡱ࡮ࡩࡳࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡴࡧࡢࡸࡴࡱࡥ࡯ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠࠎࠎࠏࡣࡴࡧ࡯࡭ࡧ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡴࡧ࡯࡭ࡧ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࡠ࠶࡝ࠋࠋࠌࡶࡦࡴࡤࡰ࡯ࡄࡔࡎࠦ࠽ࠡࡵࡷࡶ࠭ࡸࡡ࡯ࡦࡲࡱ࠳ࡸࡡ࡯ࡦ࡬ࡲࡹ࠮࠱࠲࠳࠴࠰࠾࠿࠹࠺ࠫࠬࠎࠎࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡵࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡥࡶࡩ࠴࡫࡬ࡦ࡯ࡨࡲࡹ࠵ࡶ࠲ࡁࡵࡷࡿࡃࡦࡪ࡮ࡷࡩࡷ࡫ࡤࡠࡥࡶࡩࠫࡴࡵ࡮࠿࠴࠴ࠫ࡮࡬࠾ࡣࡵࠪࡸࡵࡵࡳࡥࡨࡁ࡬ࡩࡳࡤࠨࡪࡷࡸࡃ࠮ࡤࡱࡰࠪࡨࡹࡥ࡭࡫ࡥࡺࡂ࠭ࠫࡤࡵࡨࡰ࡮ࡨࡖࡦࡴࡶ࡭ࡴࡴࠫࠨࠨࡦࡼࡂ࠭ࠫࡤࡺ࠮ࠫࠫࡷ࠽ࠨ࠭ࡶࡩࡦࡸࡣࡩ࠭ࠪࠪࡸࡧࡦࡦ࠿ࡲࡪ࡫ࠬࡣࡴࡧࡢࡸࡴࡱ࠽ࠨ࠭ࡦࡷࡪࡥࡴࡰ࡭ࡨࡲ࠰࠭ࠦࡴࡱࡵࡸࡂࠬࡥࡹࡲࡀࡧࡸࡷࡲ࠭ࡥࡦࠪࡨࡧ࡬࡭ࡤࡤࡧࡰࡃࡧࡰࡱࡪࡰࡪ࠴ࡳࡦࡣࡵࡧ࡭࠴ࡣࡴࡧ࠱ࡥࡵ࡯ࠧࠬࡴࡤࡲࡩࡵ࡭ࡂࡒࡌ࠯ࠬࠬࡳࡵࡣࡵࡸࡂ࠶ࠧࠋࠋࡸࡷࡪࡸࡡࡨࡧࡱࡸࠥࡃࠠࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠫ࠭ࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾ࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࠼ࡸࡷࡪࡸࡡࡨࡧࡱࡸࢂࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࡕࡴࡸࡩ࠱࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡖࡉࡆࡘࡃࡉ࠯࠶ࡶࡩ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡤࡧ࡭࡫ࡕࡳ࡮ࠥ࠾࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡰࡩࡹࡧࡴࡢࡩࡶࠦ࠿ࠦࡻࠩ࠰࠭ࡃ࠮ࢃࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱ࡺࡡࡨࡵࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࠬࡼࡩࡥࡧࡲࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡺࡡࡨࡵ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡸࡲࡪࡹࡣࡢࡲࡨࡌ࡙ࡓࡌࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢࡵ࠱࠲࠶ࡧࠬ࠲ࠧ࠽ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠷ࡪ࠭ࠬࠨࡀࠪ࠭ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿ࡦࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰ࡤࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠥࠦࠧ࠭ࠩࠣࠫ࠮ࠐࠉࠊ࡫ࡩࠤࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠎࠩࠠࡰࡴࠣࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠍࠍࠎࠏࡶࡢࡴࡶࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠴࠭ࠩࠋࠋࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡࡸࡤࡶࡸࡡ࠴࡞ࠌࠌࠍࠎࡻࡲ࡭ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠࠬࠢࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧࠡ࠭ࠣࡧࡦࡺࡥࡨࡱࡵࡽࠏࠏࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡸࡤࡶࡸ࠯࠾࠶࠼ࠍࠍࠎࠏࠉࡱࡣࡪࡩ࠶ࠦ࠽ࠡࡸࡤࡶࡸࡡ࠵࡞ࠌࠌࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭ࡷࡵࡰ࠱࠷࠳࠴࠮ࠪࠫ࠱ࡶࡡࡨࡧ࠴࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮ࡸࡶࡱ࠲࠱࠴࠴ࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠳࠭ࠩࠪ࠰ࠬ࠷ࠧࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠴࠷࠹࠯ࠊࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡹࡴࡢࡴࡷࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡦࡹࡷࡸࡥ࡯ࡶࡓࡥ࡬࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥࡸࡶࡷ࡫࡮ࡵࡒࡤ࡫ࡪࡏ࡮ࡥࡧࡻࠦ࠿ࠦࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦࠢࡀࠤࡸࡺࡲࠩ࡫ࡱࡸ࠭ࡩࡵࡳࡴࡨࡲࡹࡖࡡࡨࡧ࡞࠴ࡢ࠯ࠫ࠲ࠫࠍࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥ࠭ࡵࡷࡥࡷࡺࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥ࠾࠿ࡦࡹࡷࡸࡥ࡯ࡶࡓࡥ࡬࡫࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࡵࡳ࡮ࠣࡁࠥࡻࡲ࡭࠰ࡶࡴࡱ࡯ࡴࠩࠩࡶࡸࡦࡸࡴ࠾ࠩࠬ࡟࠵ࡣࠫࠨࡵࡷࡥࡷࡺ࠽ࠨ࠭ࡶࡸࡦࡸࡴࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨืไัฮࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠬࡶࡴ࡯࠰࠶࠹࠹ࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠍࠧࠨࠢອ")
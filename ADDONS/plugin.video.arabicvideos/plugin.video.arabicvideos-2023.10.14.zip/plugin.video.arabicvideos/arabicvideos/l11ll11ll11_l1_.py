# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㾸")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ㾹")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㾺"),l11ll1_l1_ (u"ࠬอำหใึหึะใๆ๋ࠢࠤฬ๊ืๅสสฮࠬ㾻")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l11111_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1ll1l_l1_(url)
	elif mode==454: results = l1llll1l_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ㾼"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ㾽"),l11ll1_l1_ (u"ࠨࠩ㾾"),l11ll1_l1_ (u"ࠩࠪ㾿"),l11ll1_l1_ (u"ࠪࠫ㿀"),l11ll1_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㿁"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ㿂"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿃"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㿄"),l11ll1_l1_ (u"ࠨࠩ㿅"),459,l11ll1_l1_ (u"ࠩࠪ㿆"),l11ll1_l1_ (u"ࠪࠫ㿇"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㿈"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿉"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㿊")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆอหฮฬะࠠๅ๊า๎ࠥ์สࠨ㿋"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠨࠩ㿌"),l11ll1_l1_ (u"ࠩࠪ㿍"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㿎"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㿏"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㿐")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ㿑"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠧࠨ㿒"),l11ll1_l1_ (u"ࠨࠩ㿓"),l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㿔"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㿕"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㿖")+l111l1_l1_+l11ll1_l1_ (u"๋ࠬๅฬๆํ๊ࠬ㿗"),l1ll111_l1_,451,l11ll1_l1_ (u"࠭ࠧ㿘"),l11ll1_l1_ (u"ࠧࠨ㿙"),l11ll1_l1_ (u"ࠨࡣࡦࡸࡴࡸࡳࠨ㿚"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㿛"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㿜")+l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥํๆะ์ฬࠫ㿝"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠬ࠭㿞"),l11ll1_l1_ (u"࠭ࠧ㿟"),l11ll1_l1_ (u"ࠧ࠱ࠩ㿠"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿡"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㿢")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ์์ฯ๋ห้ࠣิฮไอหࠪ㿣"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠫࠬ㿤"),l11ll1_l1_ (u"ࠬ࠭㿥"),l11ll1_l1_ (u"࠭࠱ࠨ㿦"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿧"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㿨")+l111l1_l1_+l11ll1_l1_ (u"ࠩสๅ้อๅ้้ࠡำ๏ฯࠧ㿩"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠪࠫ㿪"),l11ll1_l1_ (u"ࠫࠬ㿫"),l11ll1_l1_ (u"ࠬ࠸ࠧ㿬"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㿭"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㿮"),l11ll1_l1_ (u"ࠨࠩ㿯"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠩ㿰"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㿱"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠫࠨ࠭㿲"): continue
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿳"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㿴")+l111l1_l1_+title,l1lllll_l1_,451)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠧࠨ㿵")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㿶"),l11ll1_l1_ (u"ࠩࠪ㿷"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㿸"),url,l11ll1_l1_ (u"ࠫࠬ㿹"),l11ll1_l1_ (u"ࠬ࠭㿺"),l11ll1_l1_ (u"࠭ࠧ㿻"),l11ll1_l1_ (u"ࠧࠨ㿼"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭㿽"))
	html = response.content
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㿾"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡸࡣࡹࡩࡸࠨࠧ㿿"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䀀"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡒࡦࡥࡨࡲࡹࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ䀁"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ䀂") in html:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ䀃"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࠧࡇࡣࡵࡱࡵࡒࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䀄"),block,re.DOTALL)
	elif l1lll1l1l1_l1_ in [l11ll1_l1_ (u"ࠩ࠳ࠫ䀅"),l11ll1_l1_ (u"ࠪ࠵ࠬ䀆"),l11ll1_l1_ (u"ࠫ࠷࠭䀇")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩ䀈"),html,re.DOTALL)
		block = l1l1l11_l1_[int(l1lll1l1l1_l1_)]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭䀉"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ䀊"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ䀋"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ䀌"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ䀍"),l11ll1_l1_ (u"ࠫศเๆ๋หࠪ䀎"),l11ll1_l1_ (u"้ࠬไ๋สࠪ䀏"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ䀐"),l11ll1_l1_ (u"่ࠧัสๅࠬ䀑"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ䀒"),l11ll1_l1_ (u"ࠩ฼ี฻࠭䀓"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ䀔"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ䀕")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠫ䀖") in html and l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠫ䀗") in l1lll1_l1_:
			l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䀘"),l1lll1_l1_,re.DOTALL)
			l1lll1_l1_ = l1lll1_l1_[0]
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ䀙"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ䀚"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭䀛"),title,re.DOTALL)
		#if any(value in title for value in l1ll1l_l1_):
		if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ู๊ࠫไิๆࠪ䀜") not in title:
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䀝"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"࠭อๅไฬࠫ䀞") in title:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䀟") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䀠"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀡"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
	if l1lll1l1l1_l1_ in [l11ll1_l1_ (u"ࠪࠫ䀢"),l11ll1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䀣")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䀤"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䀥"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠢࠣ䀦"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠨࠩ䀧"):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀨"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䀩")+title,l1lllll_l1_,451)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䀪"),url,l11ll1_l1_ (u"ࠬ࠭䀫"),l11ll1_l1_ (u"࠭ࠧ䀬"),l11ll1_l1_ (u"ࠧࠨ䀭"),l11ll1_l1_ (u"ࠨࠩ䀮"),l11ll1_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨ䀯"))
	html = response.content
	# l1lll1l_l1_
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡈࡧࡴࡦࡩࡲࡶࡾ࡙ࡵࡣࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䀰"),html,re.DOTALL)
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ䀱") in str(l1l11l1_l1_):
		title = re.findall(l11ll1_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬ࠱ࠬ䀲"),html,re.DOTALL)
		title = title[0].strip(l11ll1_l1_ (u"࠭ࠠࠨ䀳"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䀴"),l111l1_l1_+title,url,454)
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䀵"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀶"),l111l1_l1_+title,l1lllll_l1_,454)
	else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䀷"),url,l11ll1_l1_ (u"ࠫࠬ䀸"),l11ll1_l1_ (u"ࠬ࠭䀹"),l11ll1_l1_ (u"࠭ࠧ䀺"),l11ll1_l1_ (u"ࠧࠨ䀻"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䀼"))
	html = response.content
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡄࡶࡪࡧࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ䀽"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂࠬ䀾"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䀿"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䁀"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䁁"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠢࠣ䁂"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠨࠩ䁃"):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䁄"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䁅")+title,l1lllll_l1_,454)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭䁆"),l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤࡳ࡯ࡷ࡫ࡨࡷ࠴࠭䁇"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䁈"),l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䁉"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䁊"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ䁋"),l11ll1_l1_ (u"ࠪࠫ䁌"),l11ll1_l1_ (u"ࠫࠬ䁍"),l11ll1_l1_ (u"ࠬ࠭䁎"),l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䁏"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ䁐"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡕ࡫ࡷࡰࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࡴ࡫ࡧࡩࡃ࠭䁑"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ䁒"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䁓")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䁔")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡹࡥ࡭ࡣࡵࡽࠧ࠭䁕"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ䁖"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			name = unescapeHTML(name)
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ䁗"),name,re.DOTALL)
			if l111llll_l1_:
				l111llll_l1_ = l11ll1_l1_ (u"ࠨࡡࡢࡣࡤ࠭䁘")+l111llll_l1_[0]
				name = l11ll1_l1_ (u"ࠩࠪ䁙")
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠪࠫ䁚")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䁛")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䁜")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䁝"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䁞"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ䁟"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ䁠"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ䁡"),l11ll1_l1_ (u"ࠫ࠰࠭䁢"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ䁣")+search
	l11111_l1_(url)
	return
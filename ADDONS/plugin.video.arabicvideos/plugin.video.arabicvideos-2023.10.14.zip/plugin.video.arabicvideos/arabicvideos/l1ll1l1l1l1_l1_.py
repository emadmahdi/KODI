# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ⠳")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨ⠴")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠪห้ะี็์ไหฯ࠭⠵"),l11ll1_l1_ (u"ࠫฬ์ิศรࠣัุอศࠨ⠶"),l11ll1_l1_ (u"ࠬ฽ไษษอࠤฬ๊า้๓สีࠬ⠷")]
#headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⠸"):l11ll1_l1_ (u"ࠧࠨ⠹")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l11111_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llll1l_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⠺"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⠻"),l11ll1_l1_ (u"ࠪࠫ⠼"),399,l11ll1_l1_ (u"ࠫࠬ⠽"),l11ll1_l1_ (u"ࠬ࠭⠾"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⠿"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⡀"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⡁"),l11ll1_l1_ (u"ࠩࠪ⡂"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⡃"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ⡄"),l11ll1_l1_ (u"ࠬ࠭⡅"),l11ll1_l1_ (u"࠭ࠧ⡆"),l11ll1_l1_ (u"ࠧࠨ⡇"),l11ll1_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⡈"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⡉"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡊"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⡋")+l111l1_l1_+title,l11l1l_l1_,391,l11ll1_l1_ (u"ࠬ࠭⡌"),l11ll1_l1_ (u"࠭ࠧ⡍"),l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⡎")+str(seq))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡏"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡐")+l111l1_l1_+l11ll1_l1_ (u"้ࠪำะวาษอࠤ฾ฺ่ศศํอࠬ⡑"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠫࠬ⡒"),l11ll1_l1_ (u"ࠬ࠭⡓"),l11ll1_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧ⡔"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⡕"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⡖")+l111l1_l1_+l11ll1_l1_ (u"ࠩฦ฽้๏ࠠศๆฦๅ้อๅࠡฬๅ๎๏๋ว์ࠩ⡗"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠪࠫ⡘"),l11ll1_l1_ (u"ࠫࠬ⡙"),l11ll1_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⡚"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⡛"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⡜")+l111l1_l1_+l11ll1_l1_ (u"ࠨล฼่๎ࠦวๅ็ึุ่๊วหࠢอๆ๏๐ๅศํࠪ⡝"),l11l1l_l1_,391,l11ll1_l1_ (u"ࠩࠪ⡞"),l11ll1_l1_ (u"ࠪࠫ⡟"),l11ll1_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥࡳࡦࡴ࡬ࡩࡸ࠭⡠"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡡"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡢")+l111l1_l1_+l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬ⡣"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⡤"),391,l11ll1_l1_ (u"ࠩࠪ⡥"),l11ll1_l1_ (u"ࠪࠫ⡦"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⡧"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡨"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡩")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧ⡪"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵࠪ⡫"),391,l11ll1_l1_ (u"ࠩࠪ⡬"),l11ll1_l1_ (u"ࠪࠫ⡭"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡴࡷࡵ࡫ࡳࡼࡹࠧ⡮"))
	block = l11ll1_l1_ (u"ࠬ࠭⡯")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫ⡰"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⡱"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⡲"),l11ll1_l1_ (u"ࠩࠪ⡳"),l11ll1_l1_ (u"ࠪࠫ⡴"),l11ll1_l1_ (u"ࠫࠬ⡵"),l11ll1_l1_ (u"ࠬ࠭⡶"),l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ⡷"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧ࡯ࡩࡦࡹࡥࡴࠤࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭⡸"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⡹"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⡺"),l11ll1_l1_ (u"ࠪࠫ⡻"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⡼"),block,re.DOTALL)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬ⡽"):
			if first:
				title = l11ll1_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨ⡾")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫ⡿")+title
		if title not in l1l11l_l1_:
			if title==l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠧ⢀"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⢁"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⢂")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⢃"),391,l11ll1_l1_ (u"ࠬ࠭⢄"),l11ll1_l1_ (u"࠭ࠧ⢅"),l11ll1_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⢆"))
			elif title==l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠩ⢇"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⢈"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⢉")+l111l1_l1_+title,l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭⢊"),391,l11ll1_l1_ (u"ࠬ࠭⢋"),l11ll1_l1_ (u"࠭ࠧ⢌"),l11ll1_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⢍"))
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢎"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⢏")+l111l1_l1_+title,l1lllll_l1_,391)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⢐"),l11ll1_l1_ (u"ࠫࠬ⢑"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⢒"),url,l11ll1_l1_ (u"࠭ࠧ⢓"),l11ll1_l1_ (u"ࠧࠨ⢔"),l11ll1_l1_ (u"ࠨࠩ⢕"),l11ll1_l1_ (u"ࠩࠪ⢖"),l11ll1_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⢗"))
	html = response.content
	if type in [l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⢘"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⢙")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ⢚"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⢛"),l11ll1_l1_ (u"ࠨࠩ⢜"),url,block)
	elif type==l11ll1_l1_ (u"ࠩࡤࡰࡱࡥ࡭ࡰࡸ࡬ࡩࡸࡥࡴࡷࡵ࡫ࡳࡼࡹࠧ⢝"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⢞"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif type==l11ll1_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⢟"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡺ࡯ࡱ࠯࡬ࡱࡩࡨ࠭࡭࡫ࡶࡸࠥࡺ࡬ࡦࡨࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠣ⢠"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⢡"),l11ll1_l1_ (u"ࠧࠨ⢢"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⢣"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫ⢤"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡷ࡯ࡧࡩࡶࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸࠢ⢥"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⢦"),l11ll1_l1_ (u"ࠬ࠭⢧"),str(len(block)),type)
			items = re.findall(l11ll1_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⢨"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⢩"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡷࡩࡨ࠮ࡲࡤ࡫ࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ⢪"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⢫"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ⢬"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠨ⢭"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢮"),block,re.DOTALL)
		l1llll_l1_,l1l1111l1_l1_,l1lll11l_l1_ = zip(*l1111l_l1_)
		items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	elif type==l11ll1_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧ⢯"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࡶ࠱ࡹࡼࡳࡩࡱࡺࡷࠧ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⢰"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢱"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⢲") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⢳"),l11ll1_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡷࡹࡧࡲࡵࡀࠪ⢴"))
		html = html.replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⢵"),l11ll1_l1_ (u"࠭࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀࡪࡴࡤ࠿ࠩ⢶"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡷࡥࡷࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡯ࡦࡁࠫ⢷"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==6:
			l1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⢸"),block,re.DOTALL)
			l1l1111l1_l1_,l1lll11l_l1_,l1llll_l1_ = zip(*l1111l_l1_)
			items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࢂࡳࡪࡦࡨࡦࡦࡸࠩࠨ⢹"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⢺") in url:
				items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢻"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠬ࠵ࡱࡶࡣ࡯࡭ࡹࡿ࠯ࠨ⢼") in url:
				items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⢽"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⢾"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠨࡵࡵࡧࡂ࠭⢿") in title: continue
		if l11ll1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࠨ⣀") in title:
			title = re.findall(l11ll1_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⣁"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ⣂")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⣃")+title
		l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂࠧ⣄"),title,re.DOTALL)
		if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ⣅") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣆"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⣇") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣈"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ⣉") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣊"),l111l1_l1_+title,l1lllll_l1_,393,l1lll1_l1_)
		elif l11ll1_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ⣋") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣌"),l111l1_l1_+title,l1lllll_l1_,391,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⣍"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	if type not in [l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ⣎"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭⣏")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⣐"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⣑"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣒"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭⣓")+title,l1lllll_l1_,391,l11ll1_l1_ (u"ࠨࠩ⣔"),l11ll1_l1_ (u"ࠩࠪ⣕"),type)
	return
def l1llll1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ⣖"),l11ll1_l1_ (u"ࠫࠬ⣗"),l11ll1_l1_ (u"ࠬ࠭⣘"),url)
	server = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ⣙"))
	url = url.replace(server,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⣚"),url,l11ll1_l1_ (u"ࠨࠩ⣛"),l11ll1_l1_ (u"ࠩࠪ⣜"),l11ll1_l1_ (u"ࠪࠫ⣝"),l11ll1_l1_ (u"ࠫࠬ⣞"),l11ll1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⣟"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⣠"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ⣡"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⣢"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⣣"),l111l1_l1_+title,l1lllll_l1_,392,l1lll1_l1_)
	return
def PLAY(url):
	html = l1ll1l11l1_l1_(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⣤"),url,l11ll1_l1_ (u"ࠫࠬ⣥"),l11ll1_l1_ (u"ࠬ࠭⣦"),l11ll1_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⣧"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⣨"),url,l11ll1_l1_ (u"ࠨࠩ⣩"),l11ll1_l1_ (u"ࠩࠪ⣪"),l11ll1_l1_ (u"ࠪࠫ⣫"),l11ll1_l1_ (u"ࠫࠬ⣬"),l11ll1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⣭"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⣮"),l11ll1_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ⣯"))
		except: pass
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⣰"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࡡࠢࡽ࡞ࠪࡡ࠭ࡹࡨࡦࡣࡧࡩࡷࢂࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠮ࡡࠢࡽ࡞ࠪࡡࠬ⣱"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡶ࡯ࡴࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡹࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪ࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⣲"),block,re.DOTALL)
		for type,post,l1ll1l1l1ll_l1_,title in items:
			#l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡹ࠱ࡥࡱ࡬ࡡ࡫ࡧࡵࡸࡻ࠴ࡣࡰ࡯࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵ࠭⣳")
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡧࡳࡴࡥࡰ࡭ࡣࡼࡩࡷࡥࡡ࡫ࡣࡻࠪࡵࡵࡳࡵ࠿ࠪ⣴")+post+l11ll1_l1_ (u"࠭ࠦ࡯ࡷࡰࡩࡂ࠭⣵")+l1ll1l1l1ll_l1_+l11ll1_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧ⣶")+type
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⣷")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⣸")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	#WRITE_THIS(html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠫࠬ࡯ࡤ࠾࡝ࠥࠫࡢࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡛ࠣࠩࡠࠤࡨࡲࡡࡴࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃ࡛ࠣࠩࡠࡷࡧࡵࡸ࡜ࠤࠪࡡࠬ࠭ࠧ⣹"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࠬ࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣ࠮ࠫࡁ࡞ࠦࠬࡣࡱࡶࡣ࡯࡭ࡹࡿ࡛ࠣࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ⣺"),block,re.DOTALL)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⣻"),l11ll1_l1_ (u"࠭ࠧ⣼"),str(items),str(block))
		for l1lll1_l1_,l1lllll_l1_,l111llll_l1_,l1ll1l1ll11_l1_ in items:
			if l11ll1_l1_ (u"ࠧ࠾ࠩ⣽") in l1lll1_l1_:
				host = l1lll1_l1_.split(l11ll1_l1_ (u"ࠨ࠿ࠪ⣾"))[1]
				title = SERVER(host,l11ll1_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ⣿"))
			else: title = l11ll1_l1_ (u"ࠪࠫ⤀")
			title = l1ll1l1ll11_l1_+l11ll1_l1_ (u"ࠫࠥ࠭⤁")+title
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⤂")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡤࡥࠧ⤃")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⤄"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⤅"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ⤆"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ⤇"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭⤈"),l11ll1_l1_ (u"ࠬ࠱ࠧ⤉"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡀࡵࡀࠫ⤊")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⤋"))
	return
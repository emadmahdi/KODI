# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ⸎")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩ⸏")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๊ࠫ฻วา฻ฬࠫ⸐"),l11ll1_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫ⸑"),l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬ⸒"),l11ll1_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭⸓")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l11111_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l1llll1l_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⸔"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ⸕"),l11ll1_l1_ (u"ࠪࠫ⸖"),l11ll1_l1_ (u"ࠫࠬ⸗"),l11ll1_l1_ (u"ࠬ࠭⸘"),l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⸙"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ⸚"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸛"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⸜"),l11ll1_l1_ (u"ࠪࠫ⸝"),89,l11ll1_l1_ (u"ࠫࠬ⸞"),l11ll1_l1_ (u"ࠬ࠭⸟"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⸠"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⸡"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⸢"),l11ll1_l1_ (u"ࠩࠪ⸣"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸤"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬิสา่สࠤ้้ࠧ⸥"),l1ll111_l1_,81,l11ll1_l1_ (u"ࠬ࠭⸦"),l11ll1_l1_ (u"࠭ࠧ⸧"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⸨"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⸩"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ⸪"),block,re.DOTALL)
	for l1lll1l1l1_l1_,title in items:
		l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࡂ࡭ࡹ࡫࡭࠾ࠩ⸫")+l1lll1l1l1_l1_+l11ll1_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬ⸬")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸭"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⸮")+l111l1_l1_+title,l1lllll_l1_,81)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⸯ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⸰"),l11ll1_l1_ (u"ࠩࠪ⸱"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶ࠮࡯ࡤ࡭ࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢࡸࡁࠫ⸲"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⸳"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠬࠩࠧ⸴"): continue
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸵"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⸶")+l111l1_l1_+title,l1lllll_l1_,81)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠨࠩ⸷")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ⸸"),l11ll1_l1_ (u"ࠪࠫ⸹"),url)
	items = []
	# l1lll11lll_l1_ l1lll1l111_l1_
	if l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ⸺") in url or l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭⸻") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⸼"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ⸽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭⸾"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ⸿"),l11ll1_l1_ (u"ࠪࠫ⹀"),l11ll1_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⹁"))
		html = response.content
		l1l1l11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ⹂"),url,l11ll1_l1_ (u"࠭ࠧ⹃"),l11ll1_l1_ (u"ࠧࠨ⹄"),l11ll1_l1_ (u"ࠨࠩ⹅"),l11ll1_l1_ (u"ࠩࠪ⹆"),l11ll1_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⹇"))
		html = response.content
		# l1lll1l1l1_l1_ items
		if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⹈"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⹉"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⹊"),block,re.DOTALL)
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⹋"),l11ll1_l1_ (u"ࠨࠩ⹌"),l11ll1_l1_ (u"ࠩࠪ⹍"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠪ⹎") in html:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭⹏"),html,re.DOTALL)
		else:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ⹐"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items:
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⹑"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⹒"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ⹓"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ⹔"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ⹕"),l11ll1_l1_ (u"่๊๊ࠫษࠩ⹖"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ⹗"),l11ll1_l1_ (u"࠭็ะษไࠫ⹘"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ⹙"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ⹚"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ⹛"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ⹜")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭⹝"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ⹞"),title,re.DOTALL)
		if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⹟") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹠"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨี็หุ๊ࠧ⹡") not in url and any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⹢"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪห้ำไใหࠪ⹣") in title:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⹤") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹥"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ⹦") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹧"),l111l1_l1_+title,l1lllll_l1_,81,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹨"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠩࠪ⹩"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸࠧ⹪"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⹫"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠨ⹬"): continue
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"࠭ࠧ⹭"): addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹮"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ⹯")+title,l1lllll_l1_,81)
	if l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩ⹰") in url or l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫ⹱") in url:
		if l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ⹲") in url:
			url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ⹳"),l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧ⹴"))+l11ll1_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾࠴࠳ࠫ⹵")
		elif l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩ⹶") in url:
			url,offset = url.split(l11ll1_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫ⹷"))
			offset = int(offset)+20
			url = url+l11ll1_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬ⹸")+str(offset)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹹"),l111l1_l1_+l11ll1_l1_ (u"ࠬํๆศๅࠣห้๋า๋ัࠪ⹺"),url,81)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⹻"),url,l11ll1_l1_ (u"ࠧࠨ⹼"),l11ll1_l1_ (u"ࠨࠩ⹽"),l11ll1_l1_ (u"ࠩࠪ⹾"),l11ll1_l1_ (u"ࠪࠫ⹿"),l11ll1_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⺀"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࡅࡽࡘ࡫ࡲࡪࡧࡶࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭⺁"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡭࡫ࡶࡸ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⺂"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⺃") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⺄"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺅"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡳࡡࡨࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⺆"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⺇"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#title = title.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ⺈"),l11ll1_l1_ (u"࠭ࠧ⺉")).strip(l11ll1_l1_ (u"ࠧࠡࠩ⺊"))
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⺋"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ⺌"),l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫ⺍"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⺎"),l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⺏"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⺐"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ⺑"),l11ll1_l1_ (u"ࠨࠩ⺒"),l11ll1_l1_ (u"ࠩࠪ⺓"),l11ll1_l1_ (u"ࠪࠫ⺔"),l11ll1_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⺕"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⺖"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⺗"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ⺘"),html,re.DOTALL)
		l11lll11_l1_ = l11lll11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ⺙"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ⺚"),l11ll1_l1_ (u"ࠪࠫ⺛")).strip(l11ll1_l1_ (u"ࠫࠥ࠭⺜"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ⺝")+server+l11ll1_l1_ (u"࠭ࠦࡱࡱࡶࡸࡎࡊ࠽ࠨ⺞")+l11lll11_l1_+l11ll1_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨ⺟")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⺠")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⺡")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡩࡵࡷ࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⺢"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⺣"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⺤")+name+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⺥")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⺦"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⺧"),url)
	return
l11ll1_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡓࡐࡆ࡟࡟ࡐࡎࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࡩࡧࡴࡢࠢࡀࠤࢀ࠭ࡖࡪࡧࡺࠫ࠿࠷ࡽࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࠺ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࡹࡷࡲࠬࡥࡣࡷࡥ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟ࠍࠍࠨࠦࡷࡢࡶࡦ࡬ࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥ࠭ࡳࡸࡥࡱ࡯ࡴࡺ࠮࡯࡭ࡳࡱࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠭ࠪࡣࡤࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠍࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯࠽࠾࠲࠽ࠤࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬอไาษห฻๊๊ࠥิࠢไ๎์ࠦแ๋ัํ์ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࠉࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡔࡑࡇ࡙ࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࠬࡼࡩࡥࡧࡲࠫ࠱ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ⺨")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ⺩"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ⺪"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ⺫"),l11ll1_l1_ (u"࠭࠭ࠨ⺬"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⺭")+search+l11ll1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ⺮")
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡍ࠴ࡗࠪ䁤")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䁥")
l11lllll11l1_l1_ = [
		 l11ll1_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࠩ䁦")
		,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䁧"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䁨")
		,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䁩"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䁪")
		#,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䁫"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䁬"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䁭")
		,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䁮"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䁯")
		,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䁰"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ䁱"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ䁲")
		,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ䁳"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䁴")
		,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䁵"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䁶")
		,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䁷"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭䁸"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭䁹")
		]
l11llll1ll1l_l1_ = 4
def MAIN(mode,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_):
	global l111l1_l1_
	try:
		l1lll111l1l1_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁺")])
		l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡐ࡙ࠬ䁻")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䁼")
	except: l1lll111l1l1_l1_ = l11ll1_l1_ (u"ࠪࠫ䁽")
	try: l111l1ll_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭䁾")])
	except: l111l1ll_l1_ = l11ll1_l1_ (u"ࠬ࠭䁿")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1lll111l1l1_l1_,l111l1ll_l1_)
	elif mode==712: results = l1l1111l1lll_l1_(l1lll111l1l1_l1_)
	elif mode==713: results = GROUPS(l1lll111l1l1_l1_,url,text,l1l1111_l1_)
	elif mode==714: results = ITEMS(l1lll111l1l1_l1_,url,text,l1l1111_l1_)
	elif mode==715: results = PLAY(l1lll111l1l1_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1lll111l1l1_l1_,True)
	elif mode==717: results = l1l111l1lll1_l1_(l1lll111l1l1_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1lll111l1l1_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1lll111l1l1_l1_,url,l1l1111_l1_)
	elif mode==720: results = MENU(l1lll111l1l1_l1_)
	elif mode==721: results = l1l111111ll1_l1_(l1lll111l1l1_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1lll111l1l1_l1_)
	elif mode==723: results = ADD_USERAGENT(l1lll111l1l1_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==726: results = ADD_REFERER(l1lll111l1l1_l1_)
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1lll111l1l1_l1_,url,l1l1111_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1lll111l1l1_l1_ in range(1,FOLDERS_COUNT+1):
		l11lllll11ll_l1_ = l11ll1_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ䂀")+str(l1lll111l1l1_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡏࡘࠫ䂁")+str(l1lll111l1l1_l1_)+l11ll1_l1_ (u"ࠨࡡࠪ䂂")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䂃"),l111l1_l1_+l11ll1_l1_ (u"้ࠪั๊ฯࠡࠩ䂄")+text_numbers[l1lll111l1l1_l1_]+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠫࠬ䂅"),720,l11ll1_l1_ (u"ࠬ࠭䂆"),l11ll1_l1_ (u"࠭ࠧ䂇"),l11ll1_l1_ (u"ࠧࠨ䂈"),l11ll1_l1_ (u"ࠨࠩ䂉"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䂊"):l1lll111l1l1_l1_})
	return
def SECTIONS_MENU():
	global l111l1_l1_
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂋"),l111l1_l1_+l11ll1_l1_ (u"ࠫัฺ๋๊ࠢฦๆุอๅࠨ䂌"),l11ll1_l1_ (u"ࠬ࠭䂍"),165,l11ll1_l1_ (u"࠭ࠧ䂎"),l11ll1_l1_ (u"ࠧࠨ䂏"),l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䂐"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䂑"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䂒"),l11ll1_l1_ (u"ࠫࠬ䂓"),9999)
	for l1lll111l1l1_l1_ in range(1,FOLDERS_COUNT+1):
		l11lllll11ll_l1_ = l11ll1_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ䂔")+str(l1lll111l1l1_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡎࡗࠪ䂕")+str(l1lll111l1l1_l1_)+l11ll1_l1_ (u"ࠧࡠࠩ䂖")
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂗"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦๆุอๅࠡ็ฯ่ิࠦࠧ䂘")+text_numbers[l1lll111l1l1_l1_]+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࠫ䂙"),165,l11ll1_l1_ (u"ࠫࠬ䂚"),l11ll1_l1_ (u"ࠬ࠭䂛"),l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䂜"),l11ll1_l1_ (u"ࠧࠨ䂝"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂞"):l1lll111l1l1_l1_})
	return
def MENU(l1lll111l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ䂟")):
	if l1lll111l1l1_l1_:
		l11lll1l1lll_l1_ = {l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂠"):l1lll111l1l1_l1_}
		l11lllll11ll_l1_ = l11ll1_l1_ (u"ࠫࠬ䂡")  # l11ll1_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ䂢")+str(l1lll111l1l1_l1_)
	else:
		l11lll1l1lll_l1_ = l11ll1_l1_ (u"࠭ࠧ䂣")
		l11lllll11ll_l1_ = l11ll1_l1_ (u"ࠧࠨ䂤")
	if CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True):
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂥"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๊แศฬࠪ䂦")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࠫ䂧"),729,l11ll1_l1_ (u"ࠫࠬ䂨"),l11ll1_l1_ (u"ࠬ࠭䂩"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䂪"),l11ll1_l1_ (u"ࠧࠨ䂫"),l11lll1l1lll_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂬"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅหห๋ษࠡลๅืฬ๋ࠧ䂭")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࠫ䂮"),165,l11ll1_l1_ (u"ࠫࠬ䂯"),l11ll1_l1_ (u"ࠬ࠭䂰"),l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䂱"),l11ll1_l1_ (u"ࠧࠨ䂲"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䂳"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䂴"),l11ll1_l1_ (u"ࠪࠫ䂵"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂶"),l111l1_l1_+l11ll1_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโห้๋ࠣࠦริ็สส์อࠧ䂷")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ䂸"),713,l11ll1_l1_ (u"ࠧࠨ䂹"),l11ll1_l1_ (u"ࠨࠩ䂺"),l11ll1_l1_ (u"ࠩࠪ䂻"),l11ll1_l1_ (u"ࠪࠫ䂼"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂽"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢฦื๊อฦ่ษࠪ䂾")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭䂿"),713,l11ll1_l1_ (u"ࠧࠨ䃀"),l11ll1_l1_ (u"ࠨࠩ䃁"),l11ll1_l1_ (u"ࠩࠪ䃂"),l11ll1_l1_ (u"ࠪࠫ䃃"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䃄"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䃅"),l11ll1_l1_ (u"࠭ࠧ䃆"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃇"),l111l1_l1_+l11ll1_l1_ (u"ࠨไ้์ฬะࠠๆื้ๅฮࠦๅ็ࠢฦๆุอๅ่ษࠪ䃈")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ䃉"),713,l11ll1_l1_ (u"ࠪࠫ䃊"),l11ll1_l1_ (u"ࠫࠬ䃋"),l11ll1_l1_ (u"ࠬ࠭䃌"),l11ll1_l1_ (u"࠭ࠧ䃍"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃎"),l111l1_l1_+l11ll1_l1_ (u"ࠨใํำ๏๎็ศฬฺ้ࠣ์แส่๊ࠢࠥษโิษ่๋ฬ࠭䃏")+l11lllll11ll_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ䃐"),713,l11ll1_l1_ (u"ࠪࠫ䃑"),l11ll1_l1_ (u"ࠫࠬ䃒"),l11ll1_l1_ (u"ࠬ࠭䃓"),l11ll1_l1_ (u"࠭ࠧ䃔"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䃕"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䃖"),l11ll1_l1_ (u"ࠩࠪ䃗"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃘"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊โ็๊สฮࠥอไฤื็๎ฮ࠭䃙")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭䃚"),713,l11ll1_l1_ (u"࠭ࠧ䃛"),l11ll1_l1_ (u"ࠧࠨ䃜"),l11ll1_l1_ (u"ࠨࠩ䃝"),l11ll1_l1_ (u"ࠩࠪ䃞"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃟"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠡษ็วฺ๊๊สࠩ䃠")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䃡"),713,l11ll1_l1_ (u"࠭ࠧ䃢"),l11ll1_l1_ (u"ࠧࠨ䃣"),l11ll1_l1_ (u"ࠨࠩ䃤"),l11ll1_l1_ (u"ࠩࠪ䃥"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䃦"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䃧"),l11ll1_l1_ (u"ࠬ࠭䃨"),9999)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃩"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอࠬ䃪")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䃫"),713,l11ll1_l1_ (u"ࠩࠪ䃬"),l11ll1_l1_ (u"ࠪࠫ䃭"),l11ll1_l1_ (u"ࠫࠬ䃮"),l11ll1_l1_ (u"ࠬ࠭䃯"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃰"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠨ䃱")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䃲"),713,l11ll1_l1_ (u"ࠩࠪ䃳"),l11ll1_l1_ (u"ࠪࠫ䃴"),l11ll1_l1_ (u"ࠫࠬ䃵"),l11ll1_l1_ (u"ࠬ࠭䃶"),l11lll1l1lll_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃷"),l111l1_l1_+l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๅึ่ไอࠬ䃸")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䃹"),713,l11ll1_l1_ (u"ࠩࠪ䃺"),l11ll1_l1_ (u"ࠪࠫ䃻"),l11ll1_l1_ (u"ࠫࠬ䃼"),l11ll1_l1_ (u"ࠬ࠭䃽"),l11lll1l1lll_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃾"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡ็ุ๊ๆฯࠧ䃿")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䄀"),713,l11ll1_l1_ (u"ࠩࠪ䄁"),l11ll1_l1_ (u"ࠪࠫ䄂"),l11ll1_l1_ (u"ࠫࠬ䄃"),l11ll1_l1_ (u"ࠬ࠭䄄"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄅"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ䄆")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䄇"),713,l11ll1_l1_ (u"ࠩࠪ䄈"),l11ll1_l1_ (u"ࠪࠫ䄉"),l11ll1_l1_ (u"ࠫࠬ䄊"),l11ll1_l1_ (u"ࠬ࠭䄋"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄌"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ࠭䄍")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䄎"),713,l11ll1_l1_ (u"ࠩࠪ䄏"),l11ll1_l1_ (u"ࠪࠫ䄐"),l11ll1_l1_ (u"ࠫࠬ䄑"),l11ll1_l1_ (u"ࠬ࠭䄒"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䄓"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䄔"),l11ll1_l1_ (u"ࠨࠩ䄕"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄖"),l111l1_l1_+l11ll1_l1_ (u"ࠪๆ๋๎วหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ䄗")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䄘"),713,l11ll1_l1_ (u"ࠬ࠭䄙"),l11ll1_l1_ (u"࠭ࠧ䄚"),l11ll1_l1_ (u"ࠧࠨ䄛"),l11ll1_l1_ (u"ࠨࠩ䄜"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄝"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥี็ใฬࠤํ๋ัหสฬࠫ䄞")+l11lllll11ll_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䄟"),713,l11ll1_l1_ (u"ࠬ࠭䄠"),l11ll1_l1_ (u"࠭ࠧ䄡"),l11ll1_l1_ (u"ࠧࠨ䄢"),l11ll1_l1_ (u"ࠨࠩ䄣"),l11lll1l1lll_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄤"),l111l1_l1_+l11ll1_l1_ (u"ࠪวๆ๊วๆู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ䄥")+l11lllll11ll_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䄦"),713,l11ll1_l1_ (u"ࠬ࠭䄧"),l11ll1_l1_ (u"࠭ࠧ䄨"),l11ll1_l1_ (u"ࠧࠨ䄩"),l11ll1_l1_ (u"ࠨࠩ䄪"),l11lll1l1lll_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄫"),l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊฻ๆโหࠣ์๊ืสษหࠪ䄬")+l11lllll11ll_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䄭"),713,l11ll1_l1_ (u"ࠬ࠭䄮"),l11ll1_l1_ (u"࠭ࠧ䄯"),l11ll1_l1_ (u"ࠧࠨ䄰"),l11ll1_l1_ (u"ࠨࠩ䄱"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄲"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥฬ่๊็อࠥ๎ๅาฬหอࠬ䄳")+l11lllll11ll_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䄴"),713,l11ll1_l1_ (u"ࠬ࠭䄵"),l11ll1_l1_ (u"࠭ࠧ䄶"),l11ll1_l1_ (u"ࠧࠨ䄷"),l11ll1_l1_ (u"ࠨࠩ䄸"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄹"),l111l1_l1_+l11ll1_l1_ (u"ࠪๆ๋๎วห่ࠢะ์๎ไส๋้ࠢึะศสࠩ䄺")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䄻"),713,l11ll1_l1_ (u"ࠬ࠭䄼"),l11ll1_l1_ (u"࠭ࠧ䄽"),l11ll1_l1_ (u"ࠧࠨ䄾"),l11ll1_l1_ (u"ࠨࠩ䄿"),l11lll1l1lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䅀"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䅁"),l11ll1_l1_ (u"ࠫࠬ䅂"),9999)
	for seq in range(1,l11llll1ll1l_l1_+1):
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䅃"),l111l1_l1_+l11ll1_l1_ (u"࠭ลืษไอࠥ๎ส฻์ํีࠥืวษูࠪ䅄")+l11lllll11ll_l1_+l11ll1_l1_ (u"ࠧࠡࠩ䅅")+text_numbers[seq],l11ll1_l1_ (u"ࠨࠩ䅆"),711,l11ll1_l1_ (u"ࠩࠪ䅇"),l11ll1_l1_ (u"ࠪࠫ䅈"),l11ll1_l1_ (u"ࠫࠬ䅉"),l11ll1_l1_ (u"ࠬ࠭䅊"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅋"):l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࠩ䅌"):seq})
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅍"),l111l1_l1_+l11ll1_l1_ (u"ࠩหีฬ๋ฬࠡษ็ๆ๋๎วหࠢࠫะิ๎ไࠡใๅ฻࠮࠭䅎")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡇࡓࡋࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䅏"),713,l11ll1_l1_ (u"ࠫࠬ䅐"),l11ll1_l1_ (u"ࠬ࠭䅑"),l11ll1_l1_ (u"࠭ࠧ䅒"),l11ll1_l1_ (u"ࠧࠨ䅓"),l11lll1l1lll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅔"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦีู๐แࠡษ็ๆ๋๎วหࠢ็่ศ๐วๆࠢส่๊อึ๋หࠪ䅕")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䅖"),713,l11ll1_l1_ (u"ࠫࠬ䅗"),l11ll1_l1_ (u"ࠬ࠭䅘"),l11ll1_l1_ (u"࠭ࠧ䅙"),l11ll1_l1_ (u"ࠧࠨ䅚"),l11lll1l1lll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅛"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦีู๐แࠡสิห๊าࠠศๆๅ๊ํอสࠡๆ็ว๏อๅࠡษ็้ฬ฼๊สࠩ䅜")+l11lllll11ll_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䅝"),713,l11ll1_l1_ (u"ࠫࠬ䅞"),l11ll1_l1_ (u"ࠬ࠭䅟"),l11ll1_l1_ (u"࠭ࠧ䅠"),l11ll1_l1_ (u"ࠧࠨ䅡"),l11lll1l1lll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅢"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䅣"),l11ll1_l1_ (u"ࠪࠫ䅤"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䅥"),l111l1_l1_+l11ll1_l1_ (u"ࠬหึศใฬࠤศ๎ࠠห฼ํ๎ึࠦวีฬิห่࠭䅦")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䅧"),711,l11ll1_l1_ (u"ࠧࠨ䅨"),l11ll1_l1_ (u"ࠨࠩ䅩"),l11ll1_l1_ (u"ࠩࠪ䅪"),l11ll1_l1_ (u"ࠪࠫ䅫"),l11lll1l1lll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䅬"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฿ฯะࠢไ๎ิ๐่่ษอࠫ䅭")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䅮"),721,l11ll1_l1_ (u"ࠧࠨ䅯"),l11ll1_l1_ (u"ࠨࠩ䅰"),l11ll1_l1_ (u"ࠩࠪ䅱"),l11ll1_l1_ (u"ࠪࠫ䅲"),l11lll1l1lll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䅳"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็อึࠢสุฯืวไࠩ䅴")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䅵"),716,l11ll1_l1_ (u"ࠧࠨ䅶"),l11ll1_l1_ (u"ࠨࠩ䅷"),l11ll1_l1_ (u"ࠩࠪ䅸"),l11ll1_l1_ (u"ࠪࠫ䅹"),l11lll1l1lll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䅺"),l111l1_l1_+l11ll1_l1_ (u"ࠬาไษ่่ࠢๆอสࠨ䅻")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䅼"),712,l11ll1_l1_ (u"ࠧࠨ䅽"),l11ll1_l1_ (u"ࠨࠩ䅾"),l11ll1_l1_ (u"ࠩࠪ䅿"),l11ll1_l1_ (u"ࠪࠫ䆀"),l11lll1l1lll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䆁"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠨ䆂")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䆃"),717,l11ll1_l1_ (u"ࠧࠨ䆄"),l11ll1_l1_ (u"ࠨࠩ䆅"),l11ll1_l1_ (u"ࠩࠪ䆆"),l11ll1_l1_ (u"ࠪࠫ䆇"),l11lll1l1lll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䆈"),l111l1_l1_+l11ll1_l1_ (u"ࠬอำหะาห๊ࠦวๅีํีๆืࠠศๆฦืึ฿ࠧ䆉")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䆊"),722,l11ll1_l1_ (u"ࠧࠨ䆋"),l11ll1_l1_ (u"ࠨࠩ䆌"),l11ll1_l1_ (u"ࠩࠪ䆍"),l11ll1_l1_ (u"ࠪࠫ䆎"),l11lll1l1lll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䆏"),l111l1_l1_+l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠢอ฾๏๐ัࠨ䆐")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䆑"),723,l11ll1_l1_ (u"ࠧࠨ䆒"),l11ll1_l1_ (u"ࠨࠩ䆓"),l11ll1_l1_ (u"ࠩࠪ䆔"),l11ll1_l1_ (u"ࠪࠫ䆕"),l11lll1l1lll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䆖"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࠦส฻์ํีࠬ䆗")+l11lllll11ll_l1_,l11ll1_l1_ (u"࠭ࠧ䆘"),726,l11ll1_l1_ (u"ࠧࠨ䆙"),l11ll1_l1_ (u"ࠨࠩ䆚"),l11ll1_l1_ (u"ࠩࠪ䆛"),l11ll1_l1_ (u"ࠪࠫ䆜"),l11lll1l1lll_l1_)
	return
def CHECK_ACCOUNT(l1lll111l1l1_l1_,l1ll_l1_=True):
	ok,status = False,l11ll1_l1_ (u"ࠫࠬ䆝")
	l11lll1l1l1l_l1_,l1l111ll1111_l1_ = l11ll1_l1_ (u"ࠬ࠭䆞"),l11ll1_l1_ (u"࠭ࠧ䆟")
	l1l111lll111_l1_,l11llll1llll_l1_,server,username,password = GET_URL(l1lll111l1l1_l1_)
	if username==l11ll1_l1_ (u"ࠧࠨ䆠"): return
	headers = GET_HEADERS(l1lll111l1l1_l1_)
	if l1l111lll111_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䆡"),l1l111lll111_l1_,l11ll1_l1_ (u"ࠩࠪ䆢"),headers,False,l11ll1_l1_ (u"ࠪࠫ䆣"),l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ䆤"))
		html = response.content
		if response.succeeded:
			timestamp,l11lll1l1111_l1_,l11lll11l1ll_l1_,l11ll1lll1l1_l1_,l11lllll111l_l1_ = 0,0,l11ll1_l1_ (u"ࠬ࠭䆥"),l11ll1_l1_ (u"࠭ࠧ䆦"),l11ll1_l1_ (u"ࠧࠨ䆧")
			try:
				dict = EVAL(l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䆨"),html)
				status = dict[l11ll1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ䆩")][l11ll1_l1_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ䆪")]
				ok = True
				l11lll11l1ll_l1_ = dict[l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡴࡦࡰࠩ䆫")][l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࡢࡲࡴࡽࠧ䆬")]
			except: pass
			if l11lll11l1ll_l1_:
				try:
					struct = time.strptime(l11lll11l1ll_l1_,l11ll1_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ䆭"))
					timestamp = int(time.mktime(struct))
					l11lll1l1111_l1_ = int(now-timestamp)
					l11lll1l1111_l1_ = int((l11lll1l1111_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䆮")][l11ll1_l1_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬ䆯")]))
					l11ll1lll1l1_l1_ = time.strftime(l11ll1_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭䆰"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䆱")][l11ll1_l1_ (u"ࠫࡪࡾࡰࡠࡦࡤࡸࡪ࠭䆲")]))
					l11lllll111l_l1_ = time.strftime(l11ll1_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ䆳"),struct)
				except: pass
			settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡡࠪ䆴")+l1lll111l1l1_l1_,str(now))
			settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡩ࡯ࡦࡧࡡࠪ䆵")+l1lll111l1l1_l1_,str(l11lll1l1111_l1_))
			try:
				l11llllll111_l1_ = l11ll1_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡡ࡬ࡲ࡫ࡵࠢ࠻ࠩ䆶")+html.split(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡢ࡭ࡳ࡬࡯ࠣ࠼ࠪ䆷"))[1]
				l11llllll111_l1_ = l11llllll111_l1_.replace(l11ll1_l1_ (u"ࠪ࠾ࠬ䆸"),l11ll1_l1_ (u"ࠫ࠿ࠦࠧ䆹")).replace(l11ll1_l1_ (u"ࠬ࠲ࠧ䆺"),l11ll1_l1_ (u"࠭ࠬࠡࠩ䆻")).replace(l11ll1_l1_ (u"ࠧࡾࡿࠪ䆼"),l11ll1_l1_ (u"ࠨࡿࠪ䆽"))
				new = re.findall(l11ll1_l1_ (u"ࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࠧࡶ࡯ࡳࡶࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䆾"),l11llllll111_l1_,re.DOTALL)
				l11lll1l1l1l_l1_,l1l111ll1111_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䆿")][l11ll1_l1_ (u"ࠫࡲࡧࡸࡠࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࡸ࠭䇀")]
				l11lllllllll_l1_ = dict[l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ䇁")][l11ll1_l1_ (u"࠭ࡡࡤࡶ࡬ࡺࡪࡥࡣࡰࡰࡶࠫ䇂")]
				l1l11111lll1_l1_ = dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䇃")][l11ll1_l1_ (u"ࠨ࡫ࡶࡣࡹࡸࡩࡢ࡮ࠪ䇄")]
				parts = l1l111lll111_l1_.split(l11ll1_l1_ (u"ࠩࡂࠫ䇅"),1)
				message = l11ll1_l1_ (u"࡙ࠪࡗࡒ࠺ࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䇆")+l1l111lll111_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䇇")
				message += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࡖࡸࡦࡺࡵࡴ࠼ࠣࠤࠬ䇈")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䇉")+status+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䇊")
				message += l11ll1_l1_ (u"ࠨ࡞ࡱࡘࡷ࡯ࡡ࡭࠼ࠣࠤࠥࠦࠧ䇋")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䇌")+str(l1l11111lll1_l1_==l11ll1_l1_ (u"ࠪ࠵ࠬ䇍"))+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䇎")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠡࠢࡄࡸ࠿ࠦࠠࠨ䇏")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䇐")+l11ll1lll1l1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䇑")
				message += l11ll1_l1_ (u"ࠨ࡞ࡱࡉࡽࡶࡩࡳࡻࠣࡈࡦࡺࡥ࠻ࠢࠣࠫ䇒")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䇓")+l11lllll111l_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䇔")
				message += l11ll1_l1_ (u"ࠫࡡࡴࡃࡰࡰࡱࡩࡨࡺࡩࡰࡰࡶࠤࠥࠦࠨࠡࡃࡦࡸ࡮ࡼࡥࠡ࠱ࠣࡑࡦࡾࡩ࡮ࡷࡰࠤ࠮ࠦ࠺ࠡࠢࠪ䇕")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䇖")+l11lllllllll_l1_+l11ll1_l1_ (u"࠭ࠠ࠰ࠢࠪ䇗")+max+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䇘")
				message += l11ll1_l1_ (u"ࠨ࡞ࡱࡅࡱࡲ࡯ࡸࡧࡧࠤࡔࡻࡴࡱࡷࡷࡷ࠿ࠦࠠࠡࠩ䇙")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䇚")+l11ll1_l1_ (u"ࠥࠤ࠱ࠦࠢ䇛").join(dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䇜")][l11ll1_l1_ (u"ࠬࡧ࡬࡭ࡱࡺࡩࡩࡥ࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡹࠧ䇝")])+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䇞")
				message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䇟")+l11llllll111_l1_
				if status==l11ll1_l1_ (u"ࠨࡃࡦࡸ࡮ࡼࡥࠨ䇠"): DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠩส่ฬฺสาษๆࠤ๏฿ๅๅࠢหำํ์ࠠๆึส็้࠭䇡"),message)
				else: DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠪ๎อี่ࠡล้ࠤ์์วไุ่่๊ࠢษࠡใํࠤฬ๊วีฬิห่࠭䇢"),message)
	if l1l111lll111_l1_ and ok and status==l11ll1_l1_ (u"ࠫࡆࡩࡴࡪࡸࡨࠫ䇣"):
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䇤"),l11ll1_l1_ (u"࠭࠮ࠡࠢࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤࡒ࠹ࡕࠡࡗࡕࡐࠥࠦࠠ࡜ࠢࡐ࠷࡚ࠦࡡࡤࡥࡲࡹࡳࡺࠠࡪࡵࠣࡓࡐࠦ࡝ࠡࠢࠣ࡟ࠥ࠭䇥")+l1l111lll111_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ䇦"))
		succeeded = True
	else:
		LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䇧"),l11ll1_l1_ (u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤࡒ࠹ࡕࠡࡗࡕࡐࠥࠦࠠ࡜ࠢࡇࡳࡪࡹࠠ࡯ࡱࡷࠤࡼࡵࡲ࡬ࠢࡠࠤ࡛ࠥࠦࠡࠩ䇨")+l1l111lll111_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭䇩"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䇪"),l11ll1_l1_ (u"ࠬ࠭䇫"),l11ll1_l1_ (u"࠭แฮืࠣหูะัศๅࠣไࡒ࠹ࡕࠨ䇬"),l11ll1_l1_ (u"ࠧาษห฻ࠥอิหำส็ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡไ่ฮࠥอๆหࠢหษ฻อแห้ࠣษ้๏ࠠศๆหี๋อๅอࠢ็หࠥ๐ูๆๆࠣวํࠦวๅำสฬ฼ฺ๋ࠦำ้ࠣํา่ะࠢไ๎ࠥอไษำ้ห๊าࠠ࠯ࠢฦิ์ฮࠠฦๆ์ࠤ็อฦๆหࠣหูะัศๅࠣไࡒ࠹ࡕ๊ࠡๅ้ࠥฮลืษไอࠥืวษูࠣไࡒ࠹ࡕࠡฮา๎ิࠦร้ࠢๅ้ࠥฮลึๆสัࠥอไาษห฻ࠥอไใัํ้ࠬ䇭"))
		succeeded = False
	return succeeded,l11lll1l1l1l_l1_,l1l111ll1111_l1_
def ITEMS(l1lll111l1l1_l1_,l11llllll1l1_l1_,l1l1111ll111_l1_,l11lll1ll1l1_l1_,l1ll_l1_=True):
	if not l11lll1ll1l1_l1_: l11lll1ll1l1_l1_ = l11ll1_l1_ (u"ࠨ࠳ࠪ䇮")
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,l1ll_l1_): return
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11llllll1l1_l1_)
	l1ll11llllll_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䇯"),l11llllll1l1_l1_,l1l1111ll111_l1_)
	end = int(l11lll1ll1l1_l1_)*100
	start = end-100
	for context,title,url,l1lll1_l1_ in l1ll11llllll_l1_[start:end]:
		l1ll1ll1l1ll_l1_ = (l11ll1_l1_ (u"ࠪࡋࡗࡕࡕࡑࡇࡇࠫ䇰") in l11llllll1l1_l1_ or l11llllll1l1_l1_==l11ll1_l1_ (u"ࠫࡆࡒࡌࠨ䇱"))
		l1ll1ll1l11l_l1_ = (l11ll1_l1_ (u"ࠬࡍࡒࡐࡗࡓࡉࡉ࠭䇲") not in l11llllll1l1_l1_ and l11llllll1l1_l1_!=l11ll1_l1_ (u"࠭ࡁࡍࡎࠪ䇳"))
		if l1ll1ll1l1ll_l1_ or l1ll1ll1l11l_l1_:
			if   l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䇴")  in l11llllll1l1_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇵"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䇶"),l11ll1_l1_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬ䇷"),l11ll1_l1_ (u"ࠫࠬ䇸"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇹"):l1lll111l1l1_l1_}])
			elif l11ll1_l1_ (u"࠭ࡅࡑࡉࠪ䇺") 		 in l11llllll1l1_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇻"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ䇼"),l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ䇽"),l11ll1_l1_ (u"ࠪࠫ䇾"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇿"):l1lll111l1l1_l1_}])
			elif l11ll1_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ䈀") in l11llllll1l1_l1_: menuItemsLIST.append([l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈁"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䈂"),l11ll1_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䈃"),l11ll1_l1_ (u"ࠩࠪ䈄"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䈅"):l1lll111l1l1_l1_}])
			elif l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ䈆") 	 in l11llllll1l1_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ䈇"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䈈"),l11ll1_l1_ (u"ࠧࠨ䈉"),context,{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈊"):l1lll111l1l1_l1_}])
			else: menuItemsLIST.append([l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䈋"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ䈌"),l11ll1_l1_ (u"ࠫࠬ䈍"),l11ll1_l1_ (u"ࠬ࠭䈎"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈏"):l1lll111l1l1_l1_}])
	total = len(l1ll11llllll_l1_)
	PAGINATION(l1lll111l1l1_l1_,l11lll1ll1l1_l1_,l11llllll1l1_l1_,714,total,l1l1111ll111_l1_)
	return
def SHOW_EMPTY(l11lll11l11l_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䈐"),l11lll11l11l_l1_+l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไใษษ้ฮࠦลๆษࠣๅฬืฺสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠩ䈑"),l11ll1_l1_ (u"ࠩࠪ䈒"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䈓"),l11lll11l11l_l1_+l11ll1_l1_ (u"ࠫศ๎ࠠศๆัำ๊ฯࠠ฻์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศึอีฬ้ใࠨ䈔"),l11ll1_l1_ (u"ࠬ࠭䈕"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䈖"),l11lll11l11l_l1_+l11ll1_l1_ (u"ࠧฤ๊ࠣีฬฮืࠡࡏ࠶࡙ๅࠦวๅาํࠤศ์สࠡลูๅฯํࠠ฻์ิࠤฺำ๊ฮࠩ䈗"),l11ll1_l1_ (u"ࠨࠩ䈘"),9999)
	return
def GROUPS(l1lll111l1l1_l1_,l11llllll1l1_l1_,l1l1111ll111_l1_,l11lll1ll1l1_l1_,l1l1l1l1_l1_=l11ll1_l1_ (u"ࠩࠪ䈙"),l1ll_l1_=True):
	if not l11lll1ll1l1_l1_: l11lll1ll1l1_l1_ = l11ll1_l1_ (u"ࠪ࠵ࠬ䈚")
	l11lll11l11l_l1_ = l111l1_l1_
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,l1ll_l1_): return False
	if l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䈛") in l1l1111ll111_l1_: l11lll1llll1_l1_,l11lll111l1l_l1_ = l1l1111ll111_l1_.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䈜"))
	else: l11lll1llll1_l1_,l11lll111l1l_l1_ = l1l1111ll111_l1_,l11ll1_l1_ (u"࠭ࠧ䈝")
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11llllll1l1_l1_)
	l1l1111111l1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䈞"),l11llllll1l1_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ䈟"))
	if not l1l1111111l1_l1_: return False
	l1l111l11l11_l1_ = []
	for group,l1lll1_l1_ in l1l1111111l1_l1_:
		if l1l1l1l1_l1_:
			if l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䈠") in group: l11lll11l11l_l1_ = l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ䈡")
			elif l11ll1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡢࠥࠦ࠭䈢") in group: l11lll11l11l_l1_ = l11ll1_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓ࠭䈣")
			elif l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䈤") in l11llllll1l1_l1_: l11lll11l11l_l1_ = l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䈥")
			else: l11lll11l11l_l1_ = l11ll1_l1_ (u"ࠨࡘࡌࡈࡊࡕࡓࠨ䈦")
			l11lll11l11l_l1_ = l11ll1_l1_ (u"ࠩ࠯࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䈧")+l11lll11l11l_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䈨")
		if l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䈩") in group: l1l1111l1l11_l1_,l11ll1ll1l1l_l1_ = group.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䈪"))
		else: l1l1111l1l11_l1_,l11ll1ll1l1l_l1_ = group,l11ll1_l1_ (u"࠭ࠧ䈫")
		if not l1l1111ll111_l1_:
			if l1l1111l1l11_l1_ in l1l111l11l11_l1_: continue
			l1l111l11l11_l1_.append(l1l1111l1l11_l1_)
			if l11ll1_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࠧ䈬") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈭"),l11lll11l11l_l1_+l1l1111l1l11_l1_,l11llllll1l1_l1_,168,l11ll1_l1_ (u"ࠩࠪ䈮"),l11ll1_l1_ (u"ࠪ࠵ࠬ䈯"),group,l11ll1_l1_ (u"ࠫࠬ䈰"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈱"):l1lll111l1l1_l1_})
			elif l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䈲") in group: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䈳"),l11lll11l11l_l1_+l1l1111l1l11_l1_,l11llllll1l1_l1_,713,l11ll1_l1_ (u"ࠨࠩ䈴"),l11ll1_l1_ (u"ࠩ࠴ࠫ䈵"),group,l11ll1_l1_ (u"ࠪࠫ䈶"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䈷"):l1lll111l1l1_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈸"),l11lll11l11l_l1_+l1l1111l1l11_l1_,l11llllll1l1_l1_,714,l11ll1_l1_ (u"࠭ࠧ䈹"),l11ll1_l1_ (u"ࠧ࠲ࠩ䈺"),group,l11ll1_l1_ (u"ࠨࠩ䈻"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈼"):l1lll111l1l1_l1_})
		elif l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䈽") in group and l1l1111l1l11_l1_==l11lll1llll1_l1_:
			if l11ll1ll1l1l_l1_ in l1l111l11l11_l1_: continue
			l1l111l11l11_l1_.append(l11ll1ll1l1l_l1_)
			if l11ll1_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࠫ䈾") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈿"),l11lll11l11l_l1_+l11ll1ll1l1l_l1_,l11llllll1l1_l1_,168,l11ll1_l1_ (u"࠭ࠧ䉀"),l11ll1_l1_ (u"ࠧ࠲ࠩ䉁"),group,l11ll1_l1_ (u"ࠨࠩ䉂"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉃"):l1lll111l1l1_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉄"),l11lll11l11l_l1_+l11ll1ll1l1l_l1_,l11llllll1l1_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠫ࠶࠭䉅"),group,l11ll1_l1_ (u"ࠬ࠭䉆"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䉇"):l1lll111l1l1_l1_})
	#if l11ll1_l1_ (u"ࠧࡔࡑࡕࡘࡊࡊࠧ䉈") in l11llllll1l1_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1l1l1_l1_:
		end = int(l11lll1ll1l1_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1lll111l1l1_l1_,l11lll1ll1l1_l1_,l11llllll1l1_l1_,713,total,l1l1111ll111_l1_)
	return True
def EPG_ITEMS(l1lll111l1l1_l1_,url,function):
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True): return
	headers = GET_HEADERS(l1lll111l1l1_l1_)
	timestamp = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࡣࠬ䉉")+l1lll111l1l1_l1_)
	if not timestamp or now-int(timestamp)>24*l11lll111lll_l1_:
		succeeded,l11lll1l1l1l_l1_,l1l111ll1111_l1_ = CHECK_ACCOUNT(l1lll111l1l1_l1_,False)
		if not succeeded: return
	l11lll1l1111_l1_ = int(settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡷ࡭ࡲ࡫ࡤࡪࡨࡩࡣࠬ䉊")+l1lll111l1l1_l1_))
	server = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡷࡪࡸࡶࡦࡴࡢࠫ䉋")+l1lll111l1l1_l1_)
	username = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡰࡤࡱࡪࡥࠧ䉌")+l1lll111l1l1_l1_)
	password = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡶࡡࡴࡵࡺࡳࡷࡪ࡟ࠨ䉍")+l1lll111l1l1_l1_)
	l11lll1l11ll_l1_ = url.split(l11ll1_l1_ (u"࠭࠯ࠨ䉎"))
	l11ll1lll111_l1_ = l11lll1l11ll_l1_[-1].replace(l11ll1_l1_ (u"ࠧ࠯ࡶࡶࠫ䉏"),l11ll1_l1_ (u"ࠨࠩ䉐")).replace(l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䉑"),l11ll1_l1_ (u"ࠪࠫ䉒"))
	if function==l11ll1_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ䉓"): l1l111l1l1l1_l1_ = l11ll1_l1_ (u"ࠬ࡭ࡥࡵࡡࡶ࡬ࡴࡸࡴࡠࡧࡳ࡫ࠬ䉔")
	else: l1l111l1l1l1_l1_ = l11ll1_l1_ (u"࠭ࡧࡦࡶࡢࡷ࡮ࡳࡰ࡭ࡧࡢࡨࡦࡺࡡࡠࡶࡤࡦࡱ࡫ࠧ䉕")
	l1l111lll111_l1_,l11llll1llll_l1_,server,username,password = GET_URL(l1lll111l1l1_l1_)
	if not username: return
	l11llll1111l_l1_ = l1l111lll111_l1_+l11ll1_l1_ (u"ࠧࠧࡣࡦࡸ࡮ࡵ࡮࠾ࠩ䉖")+l1l111l1l1l1_l1_+l11ll1_l1_ (u"ࠨࠨࡶࡸࡷ࡫ࡡ࡮ࡡ࡬ࡨࡂ࠭䉗")+l11ll1lll111_l1_
	html = OPENURL_CACHED(NO_CACHE,l11llll1111l_l1_,l11ll1_l1_ (u"ࠩࠪ䉘"),headers,l11ll1_l1_ (u"ࠪࠫ䉙"),l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡇࡓࡋࡤࡏࡔࡆࡏࡖ࠱࠷ࡴࡤࠨ䉚"))
	l11lllll1lll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ䉛"),html)
	l11lll1111ll_l1_ = l11lllll1lll_l1_[l11ll1_l1_ (u"࠭ࡥࡱࡩࡢࡰ࡮ࡹࡴࡪࡰࡪࡷࠬ䉜")]
	l11llll1l111_l1_ = []
	if function in [l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䉝"),l11ll1_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䉞")]:
		for dict in l11lll1111ll_l1_:
			if dict[l11ll1_l1_ (u"ࠩ࡫ࡥࡸࡥࡡࡳࡥ࡫࡭ࡻ࡫ࠧ䉟")]==1:
				l11llll1l111_l1_.append(dict)
				if function in [l11ll1_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭䉠")]: break
		if not l11llll1l111_l1_: return
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䉡"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ศๆ่่ๆอสࠡษ็วํ๊๊ࠡส๊ิ์ࠦวๅไสส๊ฯࠠใั่ࠣฬࠦสฺ็็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䉢"),l11ll1_l1_ (u"࠭ࠧ䉣"),9999)
		if function in [l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䉤")]:
			l1l111l1ll1l_l1_ = 2
			l11lll111ll1_l1_ = l1l111l1ll1l_l1_*l11lll111lll_l1_
			l11llll1l111_l1_ = []
			l1l111ll1ll1_l1_ = int(int(dict[l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺ࡟ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ䉥")])/l11lll111ll1_l1_)*l11lll111ll1_l1_
			l1l1111l11l1_l1_ = now+l11lll111ll1_l1_
			l11ll1lll1ll_l1_ = int((l1l1111l11l1_l1_-l1l111ll1ll1_l1_)/l11lll111lll_l1_)
			for count in range(l11ll1lll1ll_l1_):
				if count>=6:
					if count%l1l111l1ll1l_l1_!=0: continue
					l1l11lll1_l1_ = l11lll111ll1_l1_
				else: l1l11lll1_l1_ = l11lll111ll1_l1_//2
				l11ll1lllll1_l1_ = l1l111ll1ll1_l1_+count*l11lll111lll_l1_
				dict = {}
				dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䉦")] = l11ll1_l1_ (u"ࠪࠫ䉧")
				struct = time.localtime(l11ll1lllll1_l1_-l11lll1l1111_l1_-l11lll111lll_l1_)
				dict[l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ䉨")] = time.strftime(l11ll1_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ䉩"),struct)
				dict[l11ll1_l1_ (u"࠭ࡳࡵࡣࡵࡸࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ䉪")] = str(l11ll1lllll1_l1_)
				dict[l11ll1_l1_ (u"ࠧࡴࡶࡲࡴࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ䉫")] = str(l11ll1lllll1_l1_+l1l11lll1_l1_)
				l11llll1l111_l1_.append(dict)
	elif function in [l11ll1_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ䉬"),l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ䉭")]: l11llll1l111_l1_ = l11lll1111ll_l1_
	if function==l11ll1_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ䉮") and len(l11llll1l111_l1_)>0:
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䉯"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่า๊ࠤ็อฦๆหࠣฬึอๅอࠢส่็์่ศฬࠣࠬัี่ๅࠢไๆ฼࠯เ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䉰"),l11ll1_l1_ (u"࠭ࠧ䉱"),9999)
	l11llll11l1l_l1_ = []
	l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ䉲"))
	for dict in l11llll1l111_l1_:
		title = base64.b64decode(dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䉳")])
		if kodi_version>18.99: title = title.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䉴"))
		l11ll1lllll1_l1_ = int(dict[l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䉵")])
		l1l1111ll1l1_l1_ = int(dict[l11ll1_l1_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䉶")])
		l1l1111l1l1l_l1_ = str(int((l1l1111ll1l1_l1_-l11ll1lllll1_l1_+59)/60))
		l1l111lll1l1_l1_ = dict[l11ll1_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ䉷")].replace(l11ll1_l1_ (u"࠭ࠠࠨ䉸"),l11ll1_l1_ (u"ࠧ࠻ࠩ䉹"))
		struct = time.localtime(l11ll1lllll1_l1_-l11lll111lll_l1_)
		l1l11111l1ll_l1_ = time.strftime(l11ll1_l1_ (u"ࠨࠧࡋ࠾ࠪࡓࠧ䉺"),struct)
		l1l1111l1ll1_l1_ = time.strftime(l11ll1_l1_ (u"ࠩࠨࡥࠬ䉻"),struct)
		if function==l11ll1_l1_ (u"ࠪࡗࡍࡕࡒࡕࡡࡈࡔࡌ࠭䉼"): title = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䉽")+l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠬࠦเࠡࠩ䉾")+title+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䉿")
		elif function==l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䊀"): title = l1l1111l1ll1_l1_+l11ll1_l1_ (u"ࠨࠢࠪ䊁")+l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠩࠣࠬࠬ䊂")+l1l1111l1l1l_l1_+l11ll1_l1_ (u"ࠪࡱ࡮ࡴࠩࠨ䊃")
		else: title = l1l1111l1ll1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭䊄")+l1l11111l1ll_l1_+l11ll1_l1_ (u"ࠬࠦࠨࠨ䊅")+l1l1111l1l1l_l1_+l11ll1_l1_ (u"࠭࡭ࡪࡰࠬࠤࠥࠦࠧ䊆")+title+l11ll1_l1_ (u"ࠧࠡโࠪ䊇")
		if function in [l11ll1_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ䊈"),l11ll1_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡆࡒࡊࠫ䊉"),l11ll1_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭䊊")]:
			l11lll111111_l1_ = server+l11ll1_l1_ (u"ࠫ࠴ࡺࡩ࡮ࡧࡶ࡬࡮࡬ࡴ࠰ࠩ䊋")+username+l11ll1_l1_ (u"ࠬ࠵ࠧ䊌")+password+l11ll1_l1_ (u"࠭࠯ࠨ䊍")+l1l1111l1l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ䊎")+l1l111lll1l1_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ䊏")+l11ll1lll111_l1_+l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䊐")
			if function==l11ll1_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ䊑"): addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䊒"),l111l1_l1_+title,l11lll111111_l1_,9999,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭䊓"),l11ll1_l1_ (u"࠭ࠧ䊔"),l11ll1_l1_ (u"ࠧࠨ䊕"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"):l1lll111l1l1_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䊗"),l111l1_l1_+title,l11lll111111_l1_,235,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ䊘"),l11ll1_l1_ (u"ࠫࠬ䊙"),l11ll1_l1_ (u"ࠬ࠭䊚"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊛"):l1lll111l1l1_l1_})
		l11llll11l1l_l1_.append(title)
	if function==l11ll1_l1_ (u"ࠧࡔࡊࡒࡖ࡙ࡥࡅࡑࡉࠪ䊜") and l11llll11l1l_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11llll11l1l_l1_)
	return l11llll11l1l_l1_
def USE_FASTER_SERVER(l1lll111l1l1_l1_):
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True): return
	server,l11lll1l1l11_l1_,l11lll11ll11_l1_ = l11ll1_l1_ (u"ࠨࠩ䊝"),0,0
	succeeded,l11lll1l1l1l_l1_,l1l111ll1111_l1_ = CHECK_ACCOUNT(l1lll111l1l1_l1_,False)
	if succeeded:
		l1l111l1l11l_l1_ = DNS_RESOLVER(l11lll1l1l1l_l1_)
		l11lll1l1l11_l1_ = PING(l1l111l1l11l_l1_[0],int(l1l111ll1111_l1_))
		l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䊞"))
		groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䊟"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䊠"))
		l1ll11llllll_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ䊡"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䊢"),groups[1])
		url = l1ll11llllll_l1_[0][2]
		l1l11111ll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ䊣"),url,re.DOTALL)
		l1l11111ll1l_l1_ = l1l11111ll1l_l1_[0]
		if l11ll1_l1_ (u"ࠨ࠼ࠪ䊤") in l1l11111ll1l_l1_: l11llllll1ll_l1_,l1l111l11111_l1_ = l1l11111ll1l_l1_.split(l11ll1_l1_ (u"ࠩ࠽ࠫ䊥"))
		else: l11llllll1ll_l1_,l1l111l11111_l1_ = l1l11111ll1l_l1_,l11ll1_l1_ (u"ࠪ࠼࠵࠭䊦")
		l11ll1llll11_l1_ = DNS_RESOLVER(l11llllll1ll_l1_)
		l11lll11ll11_l1_ = PING(l11ll1llll11_l1_[0],int(l1l111l11111_l1_))
	if l11lll1l1l11_l1_ and l11lll11ll11_l1_:
		message = l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅีํีๆืࠠศๆฦู้๐ࠠฤ็ࠣหู้๊าใิࠤฬ๊ริำ฼ࠤฤࠧࠡࠨ䊧")
		message += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䊨")+l11ll1_l1_ (u"่࠭ใฬฺࠣฬฬูࠡใํࠤฬ๊ำ๋ำไีࠥอไฤื็๎ࠬ䊩")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ䊪")+str(int(l11lll11ll11_l1_*1000))+l11ll1_l1_ (u"ࠨ่่ࠢ๏ࠦหศ่ํอࠬ䊫")
		message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䊬")+l11ll1_l1_ (u"ࠪ์็ะࠠืษษ฽ࠥ็๊ࠡษ็ื๏ืแาࠢส่อี๊ๅࠩ䊭")+l11ll1_l1_ (u"ࠫࡡࡴࠧ䊮")+str(int(l11lll1l1l11_l1_*1000))+l11ll1_l1_ (u"ࠬࠦๅๅ์ࠣฯฬ์๊สࠩ䊯")
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䊰"),l11ll1_l1_ (u"ࠧศๆึ๎ึ็ัࠡษ็วฺ๊๊ࠨ䊱"),l11ll1_l1_ (u"ࠨษ็ื๏ืแาࠢส่ศูัฺࠩ䊲"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䊳"),message)
		if l1ll111ll1_l1_==1 and l11lll1l1l11_l1_<l11lll11ll11_l1_: server = l11lll1l1l1l_l1_+l11ll1_l1_ (u"ࠪ࠾ࠬ䊴")+l1l111ll1111_l1_
	else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䊵"),l11ll1_l1_ (u"ࠬ࠭䊶"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䊷"),l11ll1_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐ฬะࠢสุ่๐ัโำࠣห้ฮฯ๋ๆࠪ䊸"))
	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ䊹")+l1lll111l1l1_l1_,server)
	return
def PLAY(l1lll111l1l1_l1_,url,type):
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭䊺")+l1lll111l1l1_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ䊻")+l1lll111l1l1_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠫࢁ࠭䊼")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ䊽")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䊾")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"ࠧࡽࠨࠪ䊿"),l11ll1_l1_ (u"ࠨࡾࠪ䋀"))
	#l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ䋁")+l1lll111l1l1_l1_)
	#if l1111l1l11_l1_:
	#	l1l111111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭䋂"),url,re.DOTALL)
	#	url = url.replace(l1l111111l11_l1_[0],l1111l1l11_l1_)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(l1lll111l1l1_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䋃"),l11ll1_l1_ (u"ࠬ࠭䋄"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䋅"),l11ll1_l1_ (u"ࠧหฯำ๎ึࠦๅ่็ࠣ์์อๅࠡฮาหࠥ࠴๋ࠠำฯํࠥ฿ฯๆࠢอ฾๏๐ั่ࠢศิฬࠦใ็ฬ่ࠣฬࠦสฺำไࠤ๊อ่๊ࠠࠣ࠲ฺ่ࠥࠦั่ࠤฯเ๊๋ำ๊ࠤส๊วࠡ฻้ำࠥอไืำ๋ีฮࠦวๅไุ์๎ࠦ࠮ࠡษ็ัฬาษࠡๆ๊ิฬࠦวๅฬ฽๎๏ื่ࠠ์ࠣๅ็฽ࠠฦาสࠤ฼๊ศห่๊่ࠢࠦิาๅฬࠤๅࡓ࠳ࡖࠢฦ๊ࠥะูๆๆ๋ࠣีอࠠศๆอ฾๏๐ัࠡ࠰ࠣ์ๆ่ืࠡ฻้ำ๊อࠠหีอาิ๋ࠠฯั่อࠥๆࡍ࠴ࡗࠣฮาะวอࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠฯษุࠫ䋆"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䋇")+l1lll111l1l1_l1_)
	l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䋈"),l11ll1_l1_ (u"ࠪหุะฮะษ่ࠤฬ๊รึๆํࠫ䋉"),l11ll1_l1_ (u"ࠫฯ฿ฯ๋ๆࠣห้่ฯ๋็ࠪ䋊"),l111lll1ll_l1_,l11ll1_l1_ (u"ࠬํะศ๊ࠢ์ࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣห้๋ำหะา้ࠥำวๅ์สࠤ๊฿ࠠแࡏ࠶࡙ࠥอไั์ࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฼ำ๏๊็ࠡล่ࠤฯื๊ะࠢศ฽ฬีส่ࠢศ่๎่ࠦื฻ํอࠥอไหอห๎ฯࠦวๅลุ่๏่ࠦศๆอ๎ࠥะโา์หหࠥะๆศีหࠤัฺ๋๊ࠢืี่อสࠡโࡐ࠷࡚ࠦฟࠢࠩ䋋"))
	if l111l11llll_l1_==1: l111lll1ll_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"࠭รไฬหࠤๅࡓ࠳ࡖࠢࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฬะ์าࠫ䋌"),l111lll1ll_l1_,True)
	else: l111lll1ll_l1_ = l11ll1_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ䋍")
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠨࠢࠪ䋎"):
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䋏"),l11ll1_l1_ (u"ࠪࠫ䋐"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䋑"),l11ll1_l1_ (u"ࠬเ๊า่ࠢื๊๎อࠡลึฮำีวๆࠢไีฬเࠠๅ๊ะำ์ࠦร้ࠢ฼ำฮࠦแาษ฽หฯࠦไ้ฯา๋ฬࠦ࠮࠯࠰ࠣ๎ัฮࠠฦ็สࠤฯืใ่ࠢไหึเࠠห็ส้ฬࠦร้ࠢศฺฬ็ษࠡฯิๅࠥษ่ࠡลํࠤู๐ࠠระิࠤ๊฿็ศࠩ䋒"))
		return
	l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䋓"),l11ll1_l1_ (u"ࠧࠨ䋔"),l11ll1_l1_ (u"ࠨࠩ䋕"),l111lll1ll_l1_,l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤ์ึวࠡโࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦศะๆสࠤ๊์ࠠࠡษ็ๆิ๐ๅࠡมࠪ䋖"))
	if l111l11llll_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䋗"),l11ll1_l1_ (u"ࠫࠬ䋘"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䋙"),l11ll1_l1_ (u"࠭สๆࠢส่สฺ๊ศรࠪ䋚"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ䋛")+l1lll111l1l1_l1_,l111lll1ll_l1_)
	#l1l1111l1lll_l1_(l1lll111l1l1_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_)
	return
def ADD_REFERER(l1lll111l1l1_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䋜"),l11ll1_l1_ (u"ࠩࠪ䋝"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䋞"),l11ll1_l1_ (u"ࠫฯำะ๋ำ้ࠣ์๋้้ࠠส้ࠥาฯศࠢ࠱ࠤ๏ืฬ๊ࠢ฼ำ๊ࠦส฻์ํี์ࠦลัษࠣ็๋ะࠠๅษࠣฮ฾ืแࠡ็สࠤ์๎ࠠ࠯ࠢࠣ์฾ีๅࠡฬ฽๎๏ื็ࠡว็หࠥ฿ๆะࠢส่฻ื่าหࠣห้่ี้๋ࠣ࠲ࠥอไฮษฯอ๊ࠥ็ัษࠣห้ะฺ๋์ิࠤ์๐ࠠโไฺࠤสึวูࠡ็ฬฯࠦๅ็ๅุࠣึ้ษࠡโࡐ࠷࡚ࠦร็ࠢอ฽๊๊่ࠠาสࠤฬ๊ส฻์ํีࠥ࠴้ࠠใๅ฻ࠥ฿ๆะ็สࠤฯูสฯั่ࠤำีๅสࠢใࡑ࠸࡛ࠠหฯอหัࠦเࡓࡧࡩࡩࡷ࡫ࡲࠡะสูࠬ䋟"))
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧ䋠")+l1lll111l1l1_l1_)
	l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䋡"),l11ll1_l1_ (u"ࠧศีอาิอๅࠡษ็วฺ๊๊ࠨ䋢"),l11ll1_l1_ (u"ࠨฬ฼ำ๏๊ࠠศๆๅำ๏๋ࠧ䋣"),l11l111lll_l1_,l11ll1_l1_ (u"๊ࠩิฬࠦ็้ࠢใࡖࡪ࡬ࡥࡳࡧࡵࠤฬ๊ๅิฬัำ๊ࠦอศๆํหู๋ࠥࠡโࡐ࠷࡚ࠦวๅาํࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢอ฽ิ๐ไ่ࠢฦ้ࠥะั๋ัࠣษ฾อฯห้ࠣษ้๏ุ้ࠠ฼๎ฮࠦวๅฬฮฬ๏ะࠠศๆฦู้๐้ࠠษ็ฮ๏ࠦสใำํฬฬࠦส็ษึฬࠥาๅ๋฻ุࠣึ้วหࠢใࡑ࠸࡛ࠠภࠣࠪ䋤"))
	if l111l11llll_l1_==1: refererr = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠪว่ะศࠡโࡐ࠷࡚ࠦࡒࡦࡨࡨࡶࡪࡸࠠอัํำࠬ䋥"),l11l111lll_l1_,True)
	else: l11l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ䋦")
	if l11l111lll_l1_==l11ll1_l1_ (u"ࠬࠦࠧ䋧"):
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䋨"),l11ll1_l1_ (u"ࠧࠨ䋩"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䋪"),l11ll1_l1_ (u"ࠩ฽๎ึࠦๅิ็๋ัࠥษำหะาห๊ࠦแาษ฽ࠤ้๎อะ้ࠣวํูࠦะหࠣๅึอฺศฬ่ࠣํำฯ่ษࠣ࠲࠳࠴๋ࠠฮหࠤส๋วࠡฬิ็์ࠦแศำ฽ࠤฯ๋วๆษࠣวํࠦลืษไอࠥำัโࠢฦ์ࠥษ๊ࠡึํࠤวิัࠡ็฼๋ฬ࠭䋫"))
		return
	l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䋬"),l11ll1_l1_ (u"ࠫࠬ䋭"),l11ll1_l1_ (u"ࠬ࠭䋮"),l11l111lll_l1_,l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅ้ࠡำหࠥๆࡒࡦࡨࡨࡶࡪࡸࠠษั็ห๋ࠥๆࠡࠢส่็ี๊ๆࠢยࠫ䋯"))
	if l111l11llll_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䋰"),l11ll1_l1_ (u"ࠨࠩ䋱"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䋲"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧ䋳"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭䋴")+l1lll111l1l1_l1_,l11l111lll_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_)
	return
def GET_URL(l1lll111l1l1_l1_,l11lll111l11_l1_=l11ll1_l1_ (u"ࠬ࠭䋵")):
	if not l11lll111l11_l1_: l11lll111l11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ䋶")+l1lll111l1l1_l1_)
	server = SERVER(l11lll111l11_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ䋷"))
	username = re.findall(l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠬ࠳࠰࠿ࠪࠨࠪ䋸"),l11lll111l11_l1_+l11ll1_l1_ (u"ࠩࠩࠫ䋹"),re.DOTALL)
	password = re.findall(l11ll1_l1_ (u"ࠪࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠮࠮ࠫࡁࠬࠪࠬ䋺"),l11lll111l11_l1_+l11ll1_l1_ (u"ࠫࠫ࠭䋻"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䋼"),l11ll1_l1_ (u"࠭ࠧ䋽"),l11ll1_l1_ (u"ࠧโฯุࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠩ䋾"),l11ll1_l1_ (u"ࠨำสฬ฼ࠦวีฬิห่ࠦเࡎ࠵ࡘࠤฬ๊ะ๋ࠢๅ้ฯࠦว็ฬࠣฬส฼วโฬ๊ࠤส๊้ࠡษ็ฬึ์วๆฮ่ࠣฬฺ๊ࠦ็็ࠤศ๎ࠠศๆิหอ฽ࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣวีํศࠡว็ํ่ࠥวว็ฬࠤฬฺสาษๆࠤๅࡓ࠳ࡖ๋ࠢๆ๊ࠦศฦุสๅฮࠦัศสฺࠤๅࡓ࠳ࡖࠢฯำ๏ีࠠฤ๊ࠣๆ๊ࠦศฦื็หาࠦวๅำสฬ฼ࠦวๅไา๎๊࠭䋿"))
		return l11ll1_l1_ (u"ࠩࠪ䌀"),l11ll1_l1_ (u"ࠪࠫ䌁"),l11ll1_l1_ (u"ࠫࠬ䌂"),l11ll1_l1_ (u"ࠬ࠭䌃"),l11ll1_l1_ (u"࠭ࠧ䌄")
	username = username[0]
	password = password[0]
	l1l111lll111_l1_ = server+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࡫ࡲࡠࡣࡳ࡭࠳ࡶࡨࡱࡁࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬ䌅")+username+l11ll1_l1_ (u"ࠨࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁࠬ䌆")+password
	l11llll1llll_l1_ = server+l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡺ࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧ䌇")+username+l11ll1_l1_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧ䌈")+password+l11ll1_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡱ࠸ࡻ࡟ࡱ࡮ࡸࡷࠬ䌉")
	return l1l111lll111_l1_,l11llll1llll_l1_,server,username,password
def GET_FILENAME(l1lll111l1l1_l1_,l1l111l1l111_l1_=l11ll1_l1_ (u"ࠬ࠭䌊")):
	l11llllllll1_l1_ = l1l111l1l111_l1_.replace(l11ll1_l1_ (u"࠭࠯ࠨ䌋"),l11ll1_l1_ (u"ࠧࡠࠩ䌌")).replace(l11ll1_l1_ (u"ࠨ࠼ࠪ䌍"),l11ll1_l1_ (u"ࠩࡢࠫ䌎")).replace(l11ll1_l1_ (u"ࠪ࠲ࠬ䌏"),l11ll1_l1_ (u"ࠫࡤ࠭䌐"))
	l11llllllll1_l1_ = l11llllllll1_l1_.replace(l11ll1_l1_ (u"ࠬࡅࠧ䌑"),l11ll1_l1_ (u"࠭࡟ࠨ䌒")).replace(l11ll1_l1_ (u"ࠧ࠾ࠩ䌓"),l11ll1_l1_ (u"ࠨࡡࠪ䌔")).replace(l11ll1_l1_ (u"ࠩࠩࠫ䌕"),l11ll1_l1_ (u"ࠪࡣࠬ䌖"))
	l11llllllll1_l1_ = os.path.join(addoncachefolder,l11llllllll1_l1_).strip(l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶࠩ䌗"))+l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷࠪ䌘")
	return l11llllllll1_l1_
def ADD_ACCOUNT(l1lll111l1l1_l1_,l111l1ll_l1_):
	l1l1111l111l_l1_ = l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䌙")
	if l111l1ll_l1_: l1l1111l111l_l1_ = l11ll1_l1_ (u"ࠧฦุสๅฮ่ࠦห฼ํ๎ึࠦัศสฺࠤࠬ䌚")+text_numbers[int(l111l1ll_l1_)]
	l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䌛"),l11ll1_l1_ (u"ࠩࠪ䌜"),l11ll1_l1_ (u"ࠪࠫ䌝"),l1l1111l111l_l1_,l11ll1_l1_ (u"ࠫ์ึวࠡษ็ะืวࠠๆ่ࠣห้ฮั็ษ่ะࠥ๐อหษฯࠤึอศุࠢไ๎ิ๐่่ษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢฦ์ࠥอิหำส็๋ࠥฯโ๊฼ࠤ๊์ࠠศๆืี่อสࠡษ็ฮ๏ࠦสษ์฼๋ࠥ๎วๅำสฬ฼ࠦๆ้฻๊ࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡰ࠷ࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡝ࡰ࡟ࡲࠥ๎ระ่ส๋๋ࠥหศๆ่ࠣฯ๎ึ๋ฯุ่๊่ࠣࠠาสࠤฬ๊ัศสฺࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡹࡼ࠭ࡰࡴࡪ࠲࡬࡯ࡴࡩࡷࡥ࠲࡮ࡵ࠯ࡪࡲࡷࡺ࠴ࡲࡡ࡯ࡩࡸࡥ࡬࡫ࡳ࠰ࡣࡵࡥ࠳ࡳ࠳ࡶ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡠࡳࠦ็ๅࠢอี๏ีࠠฦุสๅฮࠦร้ࠢอ฾๏๐ัࠡล๋ࠤู๊อࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠢࠩ䌞"))
	if l111l11llll_l1_!=1: return
	l1l111l11l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ䌟")+l1lll111l1l1_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䌠")+l111l1ll_l1_)
	l11lll11l111_l1_ = True
	if l1l111l11l1l_l1_:
		l111l11llll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䌡"),l11ll1_l1_ (u"ࠨๅอหอฯࠠอัํำࠬ䌢"),l11ll1_l1_ (u"ࠩอ฽ิ๐ไࠡษ็ๆิ๐ๅࠨ䌣"),l11ll1_l1_ (u"ุ้ࠪำࠠศๆๅำ๏๋ࠧ䌤"),l11ll1_l1_ (u"ࠫฬ๊ัศสฺࠤฬ๊อศๆํࠤ์๎࠺ࠨ䌥"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䌦")+l1l111l11l1l_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䌧")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠥํะศ๊ࠢ์ࠥืวษูࠣไࡒ࠹ࡕࠡษ็ุ้าไࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯ࠢࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴ࠥํไࠡฬิ๎ิࠦสฺัํ่์ࠦรๆࠢอี๏ีࠠไฬสฬฮࠦัศสฺࠤัี๊ะࠢยࠥࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䌨"))
		if l111l11llll_l1_==-1: return
		elif l111l11llll_l1_==0: l1l111l11l1l_l1_ = l11ll1_l1_ (u"ࠨࠩ䌩")
		elif l111l11llll_l1_==2:
			l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䌪"),l11ll1_l1_ (u"ࠪࠫ䌫"),l11ll1_l1_ (u"ࠫࠬ䌬"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䌭"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ัศสฺࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠬ䌮"))
			if l111l11llll_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䌯"),l11ll1_l1_ (u"ࠨࠩ䌰"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䌱"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣห้ืวษูࠪ䌲"))
			l11lll11l111_l1_ = False
			l11llll11ll1_l1_ = l11ll1_l1_ (u"ࠫࠬ䌳")
	if l11lll11l111_l1_:
		l11llll11ll1_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠬอใหสࠣีฬฮืࠡโࡐ࠷࡚ࠦใศ็็หࠬ䌴"),l1l111l11l1l_l1_)
		l11llll11ll1_l1_ = l11llll11ll1_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ䌵"))
		if not l11llll11ll1_l1_:
			l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䌶"),l11ll1_l1_ (u"ࠨࠩ䌷"),l11ll1_l1_ (u"ࠩࠪ䌸"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䌹"),l11ll1_l1_ (u"้่ࠫฯࠡไ่ฮࠥฮละะส่ࠥืวษูࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำ๋ࠥำฮࠢส่ึอศุࠢสู่๊ฬๅࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠪ䌺"))
			if l111l11llll_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䌻"),l11ll1_l1_ (u"࠭ࠧ䌼"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䌽"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡษ็ีฬฮืࠨ䌾"))
		else:
			#l1l111lll111_l1_,l11llll1llll_l1_,server,username,password = GET_URL(l1lll111l1l1_l1_)
			#if not username: return
			message = l11ll1_l1_ (u"๊ࠩิ์ࠦวๅ็฼่ํ๋วหࠢอ้ࠥษฮั้สࠤ๊์ࠠาษห฻ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡษ้ฮ้ࠥสษฬ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ษࠣรࠦࡢ࡮ࠨ䌿")
			#message += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䍀")+server+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ฿ๆ้ษ้ࠤฬ๊ำ๋ำไี࠿ࠦࠧ䍁")
			#message += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䍂")+username+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ศี่ࠤฬ๊ๅิฬัำ๊ࡀࠠࠨ䍃")
			#message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䍄")+password+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ๆ่๊ฯࠠศๆึี࠿ࠦࠧ䍅")
			l111l11llll_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ䍆"),l11ll1_l1_ (u"ࠪࠫ䍇"),l11ll1_l1_ (u"ࠫࠬ䍈"),l11ll1_l1_ (u"ࠬอไาษห฻ࠥอไอัํำࠥํ่࠻ࠩ䍉"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䍊")+l11llll11ll1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䍋")+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䍌")+message)
			if l111l11llll_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䍍"),l11ll1_l1_ (u"ࠪࠫ䍎"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䍏"),l11ll1_l1_ (u"ࠬะๅࠡษ็ษ้เวยࠩ䍐"))
				return
	settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ䍑")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䍒")+l111l1ll_l1_,l11llll11ll1_l1_)
	#settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࡣࠬ䍓")+l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠩࠪ䍔"))
	#settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡸ࡮ࡳࡥࡥ࡫ࡩࡪࡤ࠭䍕")+l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠫࠬ䍖"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䍗")+l1lll111l1l1_l1_)
	if not l111lll1ll_l1_: settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䍘")+l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ䍙"))
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䍚"),l11ll1_l1_ (u"ࠩࠪ䍛"),l11ll1_l1_ (u"ࠪࠫ䍜"),l11ll1_l1_ (u"ࠫࠬ䍝"),l11llll11ll1_l1_+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰอ้ࠥะฺ๋ำࠣีฬฮืࠡษืฮึอใࠡโࡐ࠷࡚ࠦลๅ๋๋ࠣีอࠠศๆิหอ฽ࠠศๆฯำ๏ีࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึ๊ࠢิฬࠦวๅำสฬ฼ࠦวๅฤ้ࠤฤ࠭䍞"))
	#if l1ll111ll1_l1_==1: ok,l11lll1l1l1l_l1_,l1l111ll1111_l1_ = CHECK_ACCOUNT(l1lll111l1l1_l1_,True)
	#l1l1111l1lll_l1_(l1lll111l1l1_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_)
	return
def READ_ALL_LINES(lines,l1l111l11lll_l1_,l11lllllll11_l1_,l11l1l1lll_l1_,length,l1ll1l111lll_l1_,l11llll1llll_l1_):
	l1ll11llllll_l1_,l11lll1111l1_l1_ = [],[]
	l11lll11ll1l_l1_ = [l11ll1_l1_ (u"࠭࠮ࡢࡸ࡬ࠫ䍟"),l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ䍠"),l11ll1_l1_ (u"ࠨ࠰ࡰ࡯ࡻ࠭䍡"),l11ll1_l1_ (u"ࠩ࠱ࡪࡱࡼࠧ䍢"),l11ll1_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ䍣"),l11ll1_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ䍤")]
	for line in lines:
		if l1ll1l111lll_l1_%473==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,40+int(10*l1ll1l111lll_l1_/length),l11ll1_l1_ (u"่ࠬัศรฬࠤฬ๊แ๋ัํ์์อสࠨ䍥"),l11ll1_l1_ (u"࠭วๅใํำ๏๎ࠠาไ่࠾࠲࠭䍦"),str(l1ll1l111lll_l1_)+l11ll1_l1_ (u"ࠧࠡ࠱ࠣࠫ䍧")+str(length))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None,None
		url = re.findall(l11ll1_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࡝ࡰ࠮ࠬ࠭࡮ࡴࡵࡲࡿ࡬ࡹࡺࡰࡴࡾࡵࡸࡲࡶࠩ࠯ࠬࡂ࠭ࠩ࠭䍨"),line,re.DOTALL)
		if url:
			line,url,dummy = url[0]
			url = url.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ䍩"),l11ll1_l1_ (u"ࠪࠫ䍪"))
			line = line.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ䍫"),l11ll1_l1_ (u"ࠬ࠭䍬"))
		else:
			l11lll1111l1_l1_.append({l11ll1_l1_ (u"࠭࡬ࡪࡰࡨࠫ䍭"):line})
			continue
		l1l11111llll_l1_,context,group,title,type,l1l11111l111_l1_ = {},l11ll1_l1_ (u"ࠧࠨ䍮"),l11ll1_l1_ (u"ࠨࠩ䍯"),l11ll1_l1_ (u"ࠩࠪ䍰"),l11ll1_l1_ (u"ࠪࠫ䍱"),False
		try:
			line,title = line.rsplit(l11ll1_l1_ (u"ࠫࠧ࠲ࠧ䍲"),1)
			line = line+l11ll1_l1_ (u"ࠬࠨࠧ䍳")
		except:
			try: line,title = line.rsplit(l11ll1_l1_ (u"࠭࠱࠭ࠩ䍴"),1)
			except: title = l11ll1_l1_ (u"ࠧࠨ䍵")
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ䍶")] = url
		params = re.findall(l11ll1_l1_ (u"ࠩࠣࠬ࠳࠰࠿ࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䍷"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11ll1_l1_ (u"ࠪࠦࠬ䍸"),l11ll1_l1_ (u"ࠫࠬ䍹")).strip(l11ll1_l1_ (u"ࠬࠦࠧ䍺"))
			l1l11111llll_l1_[key] = value.strip(l11ll1_l1_ (u"࠭ࠠࠨ䍻"))
		keys = list(l1l11111llll_l1_.keys())
		if not title:
			if l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䍼") in keys and l1l11111llll_l1_[l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭䍽")]: title = l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䍾")]
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䍿")] = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭䎀")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䎁"),l11ll1_l1_ (u"࠭ࠠࠨ䎂")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䎃"),l11ll1_l1_ (u"ࠨࠢࠪ䎄"))
		if l11ll1_l1_ (u"ࠩ࡯ࡳ࡬ࡵࠧ䎅") in keys:
			l1l11111llll_l1_[l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ䎆")] = l1l11111llll_l1_[l11ll1_l1_ (u"ࠫࡱࡵࡧࡰࠩ䎇")]
			del l1l11111llll_l1_[l11ll1_l1_ (u"ࠬࡲ࡯ࡨࡱࠪ䎈")]
		else: l1l11111llll_l1_[l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠪ䎉")] = l11ll1_l1_ (u"ࠧࠨ䎊")
		if l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䎋") in keys and l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ䎌")]: group = l1l11111llll_l1_[l11ll1_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࠩ䎍")]
		if any(value in url.lower() for value in l11lll11ll1l_l1_): l1l11111l111_l1_ = True
		if l1l11111l111_l1_ or l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䎎") in group or l11ll1_l1_ (u"ࠬࡥ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡠࠩ䎏") in group:
			type = l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ䎐")
			if l11ll1_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䎑") in group: type = type+l11ll1_l1_ (u"ࠨࡡࡖࡉࡗࡏࡅࡔࠩ䎒")
			elif l11ll1_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭䎓") in group: type = type+l11ll1_l1_ (u"ࠪࡣࡒࡕࡖࡊࡇࡖࠫ䎔")
			else: type = type+l11ll1_l1_ (u"ࠫࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭䎕")
			group = group.replace(l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䎖"),l11ll1_l1_ (u"࠭ࠧ䎗")).replace(l11ll1_l1_ (u"ࠧࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ䎘"),l11ll1_l1_ (u"ࠨࠩ䎙"))
		else:
			type = l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䎚")
			if title in l1l111l11lll_l1_: context = context+l11ll1_l1_ (u"ࠪࡣࡊࡖࡇࠨ䎛")
			if title in l11lllllll11_l1_: context = context+l11ll1_l1_ (u"ࠫࡤࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ䎜")
			if not group: type = type+l11ll1_l1_ (u"ࠬࡥࡕࡏࡍࡑࡓ࡜ࡔࠧ䎝")
			else: type = type+context
		group = group.strip(l11ll1_l1_ (u"࠭ࠠࠨ䎞")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䎟"),l11ll1_l1_ (u"ࠨࠢࠪ䎠")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䎡"),l11ll1_l1_ (u"ࠪࠤࠬ䎢"))
		if l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࠪ䎣") in type: group = l11ll1_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡐࡎ࡜ࡅࡠࡡࠤࠥࠬ䎤")
		elif l11ll1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ䎥") in type: group = l11ll1_l1_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤ࡜ࡏࡅࡡࡢࠥࠦ࠭䎦")
		elif l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࠬ䎧") in type:
			l1l111l111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࡝ࡖࡷࡢࡢࡤࠬࠢ࠮࡟ࡊ࡫࡝࡝ࡦ࠮ࠫ䎨"),l1l11111llll_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䎩")],re.DOTALL)
			if l1l111l111ll_l1_: l1l111l111ll_l1_ = l1l111l111ll_l1_[0]
			else: l1l111l111ll_l1_ = l11ll1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡖࡉࡗࡏࡅࡔࡡࡢࠥࠦ࠭䎪")
			group = group+l11ll1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䎫")+l1l111l111ll_l1_
		l11lll1l11_l1_ = l11ll1_l1_ (u"࠭ࠧ䎬")
		if l11ll1_l1_ (u"ࠧࡪࡦࠪ䎭") in keys:
			l11lll1l11_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠨ࡫ࡧࠫ䎮")]
			del l1l11111llll_l1_[l11ll1_l1_ (u"ࠩ࡬ࡨࠬ䎯")]
		if l11ll1_l1_ (u"ࠪࡍࡉ࠭䎰") in keys:
			l11lll1l11_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠫࡎࡊࠧ䎱")]
			del l1l11111llll_l1_[l11ll1_l1_ (u"ࠬࡏࡄࠨ䎲")]
		if l11ll1_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡴࡸࡧࠨ䎳") in l11llll1llll_l1_ and l11ll1_l1_ (u"ࠧ࠯ࠩ䎴") in l11lll1l11_l1_:
			l11lll1l11_l1_ = l11lll1l11_l1_.rsplit(l11ll1_l1_ (u"ࠨ࠰ࠪ䎵"),1)[1]
			l11lll1l11_l1_ = l11ll1_l1_ (u"ࠩࡿࠫ䎶")+l11lll1l11_l1_.upper()+l11ll1_l1_ (u"ࠪࢀࠥ࠭䎷")
		if l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䎸") in keys: del l1l11111llll_l1_[l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䎹")]
		title = l11lll1l11_l1_+l1l11111llll_l1_[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䎺")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l1ll1l1111ll_l1_,title = SPLIT_NAME(title)
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ䎻")] = type
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ䎼")] = context
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ䎽")] = group.upper()
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䎾")] = title.upper()
		try: l1l11111llll_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ䎿")] = COUNTRIES_CODES[l1ll1l1111ll_l1_.upper()]
		except: l1l11111llll_l1_[l11ll1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䏀")] = l1ll1l1111ll_l1_.upper()
		#dictt1[l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ䏁")] = countryy.upper()
		l1l11111llll_l1_[l11ll1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䏂")] = language.upper()
		l1ll11llllll_l1_.append(l1l11111llll_l1_)
		l1ll1l111lll_l1_ += 1
	return l1ll11llllll_l1_,l1ll1l111lll_l1_,l11lll1111l1_l1_
def CLEAN_NAME(title):
	title = title.replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䏃"),l11ll1_l1_ (u"ࠩࠣࠫ䏄")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭䏅"),l11ll1_l1_ (u"ࠫࠥ࠭䏆")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䏇"),l11ll1_l1_ (u"࠭ࠠࠨ䏈"))
	title = title.replace(l11ll1_l1_ (u"ࠧࡽࡾࠪ䏉"),l11ll1_l1_ (u"ࠨࡾࠪ䏊")).replace(l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭䏋"),l11ll1_l1_ (u"ࠪ࠾ࠬ䏌")).replace(l11ll1_l1_ (u"ࠫ࠲࠳ࠧ䏍"),l11ll1_l1_ (u"ࠬ࠳ࠧ䏎"))
	title = title.replace(l11ll1_l1_ (u"࡛࠭࡜ࠩ䏏"),l11ll1_l1_ (u"ࠧ࡜ࠩ䏐")).replace(l11ll1_l1_ (u"ࠨ࡟ࡠࠫ䏑"),l11ll1_l1_ (u"ࠩࡠࠫ䏒"))
	title = title.replace(l11ll1_l1_ (u"ࠪࠬ࠭࠭䏓"),l11ll1_l1_ (u"ࠫ࠭࠭䏔")).replace(l11ll1_l1_ (u"ࠬ࠯ࠩࠨ䏕"),l11ll1_l1_ (u"࠭ࠩࠨ䏖"))
	title = title.replace(l11ll1_l1_ (u"ࠧ࠽࠾ࠪ䏗"),l11ll1_l1_ (u"ࠨ࠾ࠪ䏘")).replace(l11ll1_l1_ (u"ࠩࡁࡂࠬ䏙"),l11ll1_l1_ (u"ࠪࡂࠬ䏚"))
	title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭䏛"))
	return title
def CREATE_GROUPED_STREAMS(l11llll1l11l_l1_,l11l1l1lll_l1_,l111l1ll_l1_):
	l11lllllll1l_l1_ = {}
	for l11lll111_l1_ in l11lllll11l1_l1_: l11lllllll1l_l1_[l11lll111_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䏜")+l111l1ll_l1_] = []
	length = len(l11llll1l11l_l1_)
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l111lll_l1_ = 0
	l11lll1111l1_l1_ = []
	for l1l11111llll_l1_ in l11llll1l11l_l1_:
		if l1ll1l111lll_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,50+int(5*l1ll1l111lll_l1_/length),l11ll1_l1_ (u"࠭สึ่ํๅࠥอไโ์า๎ํํวหࠢส่฿๐ัࠡ็ิฮอฯࠧ䏝"),l11ll1_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ䏞"),str(l1ll1l111lll_l1_)+l11ll1_l1_ (u"ࠨࠢ࠲ࠤࠬ䏟")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		group,context,title,url,l1lll1_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ䏠")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ䏡")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䏢")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ䏣")],l1l11111llll_l1_[l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠪ䏤")]
		l1ll1l1111ll_l1_,language,l11lll111_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ䏥")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ䏦")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ䏧")]
		l1l1111llll1_l1_ = (group,context,title,url,l1lll1_l1_)
		l1lll1l111l_l1_ = False
		if l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䏨") in l11lll111_l1_:
			if l11ll1_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ䏩") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭䏪")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			elif l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䏫") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䏬")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			else: l1lll1l111l_l1_ = True
			l11lllllll1l_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䏭")+l111l1ll_l1_].append(l1l1111llll1_l1_)
		elif l11ll1_l1_ (u"࡙ࠩࡓࡉ࠭䏮") in l11lll111_l1_:
			if l11ll1_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ䏯") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䏰")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			elif l11ll1_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ䏱") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ䏲")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			elif l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ䏳") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䏴")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			else: l1lll1l111l_l1_ = True
			l11lllllll1l_l1_[l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䏵")+l111l1ll_l1_].append(l1l1111llll1_l1_)
		else: l1lll1l111l_l1_ = True
		if l1lll1l111l_l1_: l11lll1111l1_l1_.append(l1l11111llll_l1_)
		l1ll1l111lll_l1_ += 1
	l11lllll1ll1_l1_ = sorted(l11llll1l11l_l1_,reverse=False,key=lambda key: key[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䏶")].lower())
	del l11llll1l11l_l1_
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l111lll_l1_ = 0
	for l1l11111llll_l1_ in l11lllll1ll1_l1_:
		l1ll1l111lll_l1_ += 1
		if l1ll1l111lll_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,55+int(5*l1ll1l111lll_l1_/length),l11ll1_l1_ (u"ࠫฯ฻ๆ๋ใࠣห้็๊ะ์๋๋ฬะࠠศๆ่ีฯฮษࠨ䏷"),l11ll1_l1_ (u"ࠬอไโ์า๎ํࠦัใ็࠽࠱ࠬ䏸"),str(l1ll1l111lll_l1_)+l11ll1_l1_ (u"࠭ࠠ࠰ࠢࠪ䏹")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		l11lll111_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ䏺")]
		group,context,title,url,l1lll1_l1_ = l1l11111llll_l1_[l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䏻")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䏼")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䏽")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䏾")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ䏿")]
		l1ll1l1111ll_l1_,language = l1l11111llll_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ䐀")],l1l11111llll_l1_[l11ll1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䐁")]
		l1l1111lllll_l1_ = (group,context+l11ll1_l1_ (u"ࠨࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䐂"),title,url,l1lll1_l1_)
		l1l1111llll1_l1_ = (group,context,title,url,l1lll1_l1_)
		l1l1111lll1l_l1_ = (l1ll1l1111ll_l1_,context,title,url,l1lll1_l1_)
		l1l1111lll11_l1_ = (language,context,title,url,l1lll1_l1_)
		if l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䐃") in l11lll111_l1_:
			if l11ll1_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ䐄") in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ䐅")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			else: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ䐆")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			if l11ll1_l1_ (u"࠭ࡅࡑࡉࠪ䐇")		in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䐈")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			if l11ll1_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ䐉")	in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡂࡔࡆࡌࡎ࡜ࡅࡅࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䐊")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			if l11ll1_l1_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬ䐋")	in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ䐌")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			l11lllllll1l_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉࡥࠧ䐍")+l111l1ll_l1_].append(l1l1111lll1l_l1_)
			l11lllllll1l_l1_[l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䐎")+l111l1ll_l1_].append(l1l1111lll11_l1_)
		elif l11ll1_l1_ (u"ࠧࡗࡑࡇࠫ䐏") in l11lll111_l1_:
			if   l11ll1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ䐐")	in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䐑")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			elif l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪ䐒")	in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䐓")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			elif l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ䐔")	in l11lll111_l1_: l11lllllll1l_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ䐕")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			l11lllllll1l_l1_[l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䐖")+l111l1ll_l1_].append(l1l1111lll1l_l1_)
			l11lllllll1l_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䐗")+l111l1ll_l1_].append(l1l1111lll11_l1_)
	return l11lllllll1l_l1_,l11lll1111l1_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l1ll11_l1_,sep = l11ll1_l1_ (u"ࠩࠪ䐘"),l11ll1_l1_ (u"ࠪࠫ䐙")
	l1lll1l1l_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11ll1_l1_ (u"ࠫ࠭࠭䐚"): sep = l11ll1_l1_ (u"ࠬ࠯ࠧ䐛")
	elif first==l11ll1_l1_ (u"࡛࠭ࠨ䐜"): sep = l11ll1_l1_ (u"ࠧ࡞ࠩ䐝")
	elif first==l11ll1_l1_ (u"ࠨ࠾ࠪ䐞"): sep = l11ll1_l1_ (u"ࠩࡁࠫ䐟")
	elif first==l11ll1_l1_ (u"ࠪࢀࠬ䐠"): sep = l11ll1_l1_ (u"ࠫࢁ࠭䐡")
	if sep and (sep in rest):
		l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = rest.split(sep,1)
		l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
		l1lll1l1l_l1_ = first+l1l1ll1lllll_l1_+sep+l11ll1_l1_ (u"ࠬࠦࠧ䐢")+l1l1ll1llll1_l1_
	elif title.count(l11ll1_l1_ (u"࠭ࡼࠨ䐣"))>=2:
		l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = title.split(l11ll1_l1_ (u"ࠧࡽࠩ䐤"),1)
		l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
		l1lll1l1l_l1_ = l1l1ll1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡿࠫ䐥")+l1l1ll1llll1_l1_
	else:
		sep = re.findall(l11ll1_l1_ (u"ࠩࡡࡠࡼࢁ࠲ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ䐦"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠪࡢࡡࡽࡻ࠴ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬ䐧"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠫࡣࡢࡷࡼ࠶ࢀࠬࠥࢂ࡜࠻ࡾ࡟࠱ࢁࡢࡼࡽ࡞ࡠࢀࡡ࠯ࡼ࡝ࠥࡿࡠ࠳ࢂ࡜࠭ࡾ࡟ࠨࢁࡢࠧࡽ࡞ࠤࢀࡡࡆࡼ࡝ࠧࡿࡠࠫࢂ࡜ࠫࡾ࡟ࡢ࠮࠭䐨"),title,re.DOTALL)
		if sep:
			l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = title.split(sep[0],1)
			l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
			l1lll1l1l_l1_ = l1l1ll1lllll_l1_+l11ll1_l1_ (u"ࠬࠦࠧ䐩")+sep[0]+l11ll1_l1_ (u"࠭ࠠࠨ䐪")+l1l1ll1llll1_l1_
	l1lll1l1l_l1_ = l1lll1l1l_l1_.replace(l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ䐫"),l11ll1_l1_ (u"ࠨࠢࠪ䐬")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䐭"),l11ll1_l1_ (u"ࠪࠤࠬ䐮"))
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䐯"),l11ll1_l1_ (u"ࠬࠦࠧ䐰"))
	if not l1ll1l1ll11_l1_: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡤࠧࠡࠨ䐱")
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ䐲"))
	l1lll1l1l_l1_ = l1lll1l1l_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ䐳"))
	return l1ll1l1ll11_l1_,l1lll1l1l_l1_
def GET_HEADERS(l1lll111l1l1_l1_):
	headers = {}
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭䐴")+l1lll111l1l1_l1_)
	if l111lll1ll_l1_: headers[l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䐵")] = l111lll1ll_l1_
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭䐶")+l1lll111l1l1_l1_)
	if l11l111lll_l1_: headers[l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䐷")] = l11l111lll_l1_
	return headers
def CREATE_STREAMS(l1lll111l1l1_l1_,l111l1ll_l1_):
	global l11l1l1lll_l1_,l11lllllll1l_l1_,l11ll1ll1lll_l1_,l1l111ll111l_l1_,l1l111l1ll11_l1_,groups,l11lll11lll1_l1_,l11lll1lllll_l1_,l1l111l1l1ll_l1_
	l11llll1llll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ䐸")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䐹")+l111l1ll_l1_)
	#l1l111lll111_l1_,l11llll1llll_l1_,server,username,password = GET_URL(l1lll111l1l1_l1_)
	#if not username: return
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䐺")+l1lll111l1l1_l1_)
	headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䐻"):l111lll1ll_l1_}
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䐼"),l11ll1_l1_ (u"ࠫࠬ䐽"),l11ll1_l1_ (u"ࠬ࠭䐾"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䐿"),l11ll1_l1_ (u"ฺࠧ็็๎ฮࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮࠦโะࠢอัฯอฬࠡ฻าอࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮั๊ศࠡษ็้้็วหࠢส่ว์ࠠภࠩ䑀"))
	#if l1ll111ll1_l1_!=1: return
	l11llllllll1_l1_ = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䑁"),l11ll1_l1_ (u"ࠩࡢࠫ䑂")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䑃")+l111l1ll_l1_)
	if 1:
		succeeded,l11lll1l1l1l_l1_,l1l111ll1111_l1_ = True,l11ll1_l1_ (u"ࠫࠬ䑄"),l11ll1_l1_ (u"ࠬ࠭䑅")
		if not succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䑆"),l11ll1_l1_ (u"ࠧࠨ䑇"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䑈"),l11ll1_l1_ (u"ࠩไุ้ࠦศิฯหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡ࠰ࠣวาะๅศๆࠣีฬฮืࠡโࡐ࠷ฺ๋࡚ࠦำูࠣา๐อࠡล๋ࠤ็ี๊ๆࠢฦ์๊ࠥวࠡ์฼้้ࠦ࠮࠯ࠢ฼่๊อࠠฤ่๋ࠣีํࠠศๆัำ๊ฯࠠหฯอหัࠦวีฬิห่ࠦๅะใ๋฽ࠥ๎ีฮ์ะࠤํ๐ฬษࠢฦ๊ࠥะึ๋ใࠣีฬฮืࠡษ็หูะัศๅࠣฬ๋็ำไࠢ็่อืๆศ็ฯࠤออำหะาห๊ࠦโศศ่อࠥๆࡍ࠴ࡗࠣห้๋่อ๊าอࠥฮ็ัษࠣห้ฮั็ษ่ะࠬ䑉"))
			if not l11llll1llll_l1_: LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䑊"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡏࡱࠣࡑ࠸࡛ࠠࡖࡔࡏࠤ࡫ࡵࡵ࡯ࡦࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡏ࠶࡙ࠥ࡬ࡩ࡭ࡧࡶࠫ䑋"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䑌"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࡵࠪ䑍"))
			return
		l1l111lll11l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11llll1llll_l1_,headers,True)
		if not l1l111lll11l_l1_: return
		open(l11llllllll1_l1_,l11ll1_l1_ (u"ࠧࡸࡤࠪ䑎")).write(l1l111lll11l_l1_)
	else: l1l111lll11l_l1_ = open(l11llllllll1_l1_,l11ll1_l1_ (u"ࠨࡴࡥࠫ䑏")).read()
	if kodi_version>18.99 and l1l111lll11l_l1_: l1l111lll11l_l1_ = l1l111lll11l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䑐"))
	#l1l111lll11l_l1_ = l1l111lll11l_l1_[33000111:77000111]
	l11l1l1lll_l1_ = DIALOG_PROGRESS()
	l11l1l1lll_l1_.create(l11ll1_l1_ (u"ࠪะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ䑑"),l11ll1_l1_ (u"ࠫࠬ䑒"))
	PROGRESS_UPDATE(l11l1l1lll_l1_,15,l11ll1_l1_ (u"ࠬะๆู์ไࠤฬ๊ๅๅใࠣห้ืฦ๋ีํࠫ䑓"),l11ll1_l1_ (u"࠭ࠧ䑔"))
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l11ll1_l1_ (u"ࠧࠣࡶࡹ࡫࠲࠭䑕"),l11ll1_l1_ (u"ࠨࠤࠣࡸࡻ࡭࠭ࠨ䑖"))
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l11ll1_l1_ (u"ࠩ๑ࠫ䑗"),l11ll1_l1_ (u"ࠪࠫ䑘")).replace(l11ll1_l1_ (u"ࠫ๐࠭䑙"),l11ll1_l1_ (u"ࠬ࠭䑚")).replace(l11ll1_l1_ (u"࠭๏ࠨ䑛"),l11ll1_l1_ (u"ࠧࠨ䑜")).replace(l11ll1_l1_ (u"ࠨ๎ࠪ䑝"),l11ll1_l1_ (u"ࠩࠪ䑞"))
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l11ll1_l1_ (u"ࠪ๕ࠬ䑟"),l11ll1_l1_ (u"ࠫࠬ䑠")).replace(l11ll1_l1_ (u"ࠬ๖ࠧ䑡"),l11ll1_l1_ (u"࠭ࠧ䑢")).replace(l11ll1_l1_ (u"ࠧ๎ࠩ䑣"),l11ll1_l1_ (u"ࠨࠩ䑤")).replace(l11ll1_l1_ (u"ࠩ๕ࠫ䑥"),l11ll1_l1_ (u"ࠪࠫ䑦"))
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l11ll1_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲ࠰ࡸ࡮ࡺ࡬ࡦ࠿ࠪ䑧"),l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡁࠬ䑨")).replace(l11ll1_l1_ (u"࠭ࡴࡷࡩ࠰ࠫ䑩"),l11ll1_l1_ (u"ࠧࠨ䑪"))
	l11lllllll11_l1_,l1l111l11lll_l1_ = [],[]
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡖࡒࡐࡉࡕࡉࡘ࡙࡟ࡖࡒࡇࡅ࡙ࡋࠨࡱࡆ࡬ࡥࡱࡵࡧ࠭࠴࠳࠰ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ࠲ࠧศๆ่่ๆࠦัใ็࠽࠱ࠬ࠲ࠧ࠲ࠢ࠲ࠤ࠸࠭ࠩࠋࠋ࡬ࡪࠥࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡩࡴࡥࡤࡲࡨ࡫࡬ࡦࡦࠫ࠭࠿ࠐࠉࠊࡲࡇ࡭ࡦࡲ࡯ࡨ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠏࠏࡵࡳ࡮ࠣࡁ࡛ࠥࡒࡍࡡࡳࡰࡦࡿࡥࡳ࠭ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠࡵࡨࡶ࡮࡫ࡳࡠࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠬࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡎ࠵ࡘ࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩࠋࠋࡶࡩࡷ࡯ࡥࡴࡡࡪࡶࡴࡻࡰࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡩࡵࡳࡺࡶࠠࡪࡰࠣࡷࡪࡸࡩࡦࡵࡢ࡫ࡷࡵࡵࡱࡵ࠽ࠎࠎࠏࡧࡳࡱࡸࡴࠥࡃࠠࡨࡴࡲࡹࡵ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠼࠲࠻࠽ࠤ࡬ࡸ࡯ࡶࡲࠣࡁࠥ࡭ࡲࡰࡷࡳ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭࠳࡫࡮ࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊ࡯࠶ࡹࡤࡺࡥࡹࡶࠣࡁࠥࡳ࠳ࡶࡡࡷࡩࡽࡺ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡪࡶࡴࡻࡰ࠾ࠤࠪ࠯࡬ࡸ࡯ࡶࡲ࠮ࠫࠧ࠭ࠬࠨࡩࡵࡳࡺࡶ࠽ࠣࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ࠱ࡧࡳࡱࡸࡴ࠰࠭ࠢࠨࠫࠍࠍࡩ࡫࡬ࠡࡵࡨࡶ࡮࡫ࡳࡠࡩࡵࡳࡺࡶࡳࠋࠋࡓࡖࡔࡍࡒࡆࡕࡖࡣ࡚ࡖࡄࡂࡖࡈࠬࡵࡊࡩࡢ࡮ࡲ࡫࠱࠸࠵࠭ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊สࠩ࠯ࠫฬ๊ๅๅใࠣี็๋࠺࠮ࠩ࠯ࠫ࠷ࠦ࠯ࠡ࠵ࠪ࠭ࠏࠏࡩࡧࠢࡳࡈ࡮ࡧ࡬ࡰࡩ࠱࡭ࡸࡩࡡ࡯ࡥࡨࡰࡪࡪࠨࠪ࠼ࠍࠍࠎࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࡹࡷࡲࠠ࠾ࠢࡘࡖࡑࡥࡰ࡭ࡣࡼࡩࡷ࠱ࠧࠧࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡤࡼ࡯ࡥࡡࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠭ࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡏ࠶࡙࠲ࡉࡒࡆࡃࡗࡉࡤ࡙ࡔࡓࡇࡄࡑࡘ࠳࠲࡯ࡦࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫ࡬ࡹࡳ࡬ࠪࠌࠌࡺࡴࡪ࡟ࡨࡴࡲࡹࡵࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࡡࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡤࡦ࡮ࠣ࡬ࡹࡳ࡬ࠋࠋࡩࡳࡷࠦࡧࡳࡱࡸࡴࠥ࡯࡮ࠡࡸࡲࡨࡤ࡭ࡲࡰࡷࡳࡷ࠿ࠐࠉࠊࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯࠾࠴࠽࠿ࠦࡧࡳࡱࡸࡴࠥࡃࠠࡨࡴࡲࡹࡵ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯࠮ࡦࡰࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠋࠋࠌࡱ࠸ࡻ࡟ࡵࡧࡻࡸࠥࡃࠠ࡮࠵ࡸࡣࡹ࡫ࡸࡵ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࡬ࡸ࡯ࡶࡲࡀࠦࠬ࠱ࡧࡳࡱࡸࡴ࠰࠭ࠢࠨ࠮ࠪ࡫ࡷࡵࡵࡱ࠿ࠥࡣࡤࡓࡏࡗࡋࡈࡗࡤࡥࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠭ࠏࠏࡤࡦ࡮ࠣࡺࡴࡪ࡟ࡨࡴࡲࡹࡵࡹࠊࠊࡒࡕࡓࡌࡘࡅࡔࡕࡢ࡙ࡕࡊࡁࡕࡇࠫࡴࡉ࡯ࡡ࡭ࡱࡪ࠰࠸࠶ࠬࠨฮ็ฬࠥอไๆๆไหฯࠦวๅอส๊ํ๐ษࠨ࠮ࠪห้๋ไโࠢิๆ๊ࡀ࠭ࠨ࠮ࠪ࠷ࠥ࠵ࠠ࠴ࠩࠬࠎࠎ࡯ࡦࠡࡲࡇ࡭ࡦࡲ࡯ࡨ࠰࡬ࡷࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠮ࠩ࠻ࠌࠌࠍࡵࡊࡩࡢ࡮ࡲ࡫࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࡸࡶࡱࠦ࠽ࠡࡗࡕࡐࡤࡶ࡬ࡢࡻࡨࡶ࠰࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡱ࡯ࡶࡦࡡࡶࡸࡷ࡫ࡡ࡮ࡵࠪࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡓ࠳ࡖ࠯ࡆࡖࡊࡇࡔࡆࡡࡖࡘࡗࡋࡁࡎࡕ࠰࠷ࡷࡪࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮ࠐࠉ࡭࡫ࡹࡩࡤࡧࡲࡤࡪ࡬ࡺࡪࡪࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹࡼ࡟ࡢࡴࡦ࡬࡮ࡼࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡲࡦࡳࡥ࠭ࡣࡵࡧ࡭࡯ࡶࡦࡦࠣ࡭ࡳࠦ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࡀࠊࠊࠋ࡬ࡪࠥࡧࡲࡤࡪ࡬ࡺࡪࡪ࠽࠾ࠩ࠴ࠫ࠿ࠦ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࡥࡣࡩࡣࡱࡲࡪࡲࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡰࡤࡱࡪ࠯ࠊࠊࡦࡨࡰࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨࠏࠏ࡬ࡪࡸࡨࡣࡪࡶࡧࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧ࡫ࡰࡨࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢ࡭ࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡩ࡫࡬ࠡࡪࡷࡱࡱࠐࠉࡧࡱࡵࠤࡳࡧ࡭ࡦ࠮ࡨࡴ࡬ࠦࡩ࡯ࠢ࡯࡭ࡻ࡫࡟ࡦࡲࡪ࠾ࠏࠏࠉࡪࡨࠣࡩࡵ࡭ࠡ࠾ࠩࡱࡹࡱࡲࠧ࠻ࠢ࡯࡭ࡻ࡫࡟ࡦࡲࡪࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡮ࡢ࡯ࡨ࠭ࠏࠏࡤࡦ࡮ࠣࡰ࡮ࡼࡥࡠࡧࡳ࡫ࠏࠏࠢࠣࠤ䑫")
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡶࠬ䑬"),l11ll1_l1_ (u"ࠪࡠࡳ࠭䑭"))
	lines = re.findall(l11ll1_l1_ (u"ࠫࡓࡌ࠺ࠩ࠰࠮ࡃ࠮ࠩࡅ࡙ࡖࡌࠫ䑮"),l1l111lll11l_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠤࡇ࡛ࡘࡎࡔࡆ࠻ࠩ䑯"),re.DOTALL)
	if not lines:
		LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䑰"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡊࡴࡲࡤࡦࡴ࠽ࠫ䑱")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠣࡗࡪࡷࡵࡦࡰࡦࡩ࠿࠭䑲")+l111l1ll_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡔ࡯ࠡࡸ࡬ࡨࡪࡵࠠ࡭࡫ࡱ࡯ࡸࠦࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡏ࠶࡙ࠥ࡬ࡩ࡭ࡧࠪ䑳"))
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䑴"),l11ll1_l1_ (u"ࠫࠬ䑵"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䑶"),l11ll1_l1_ (u"࠭ัศสฺࠤๅࡓ࠳ࡖࠢส่ี๐ࠠฤ่อࠤศ฼แห้่ࠣฬࠦส้ฮาࠤๆ๐็ࠡใํำ๏๎็ศฬࠣ࠲࠳ࠦวฮฬ่ห้ࠦัศสฺࠤๅࡓ࠳ࡖࠢ฽๎ึࠦีฮ์ะࠫ䑷")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ䑸")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䑹")+l11ll1_l1_ (u"ࠩิหอ฽ࠠาไ่ࠤࠬ䑺")+str(int(l111l1ll_l1_)+1)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䑻"))
		l11l1l1lll_l1_.close()
		return
	l11ll11l11_l1_ = 1024*1024
	l1l11l1l1l11_l1_ = 1+len(l1l111lll11l_l1_)//l11ll11l11_l1_//10
	del l1l111lll11l_l1_
	l11ll1lll11l_l1_ = len(lines)
	l11lll11111l_l1_ = SPLIT_BIGLIST(lines,l1l11l1l1l11_l1_)
	del lines
	for l11ll11111_l1_ in range(l1l11l1l1l11_l1_):
		PROGRESS_UPDATE(l11l1l1lll_l1_,35+int(5*l11ll11111_l1_/l1l11l1l1l11_l1_),l11ll1_l1_ (u"ࠫฯ่ื๋฻ࠣห้๋ไโࠢส่ึฬ๊ิ์ࠪ䑼"),l11ll1_l1_ (u"ࠬอไอิฤࠤึ่ๅ࠻࠯ࠪ䑽"),str(l11ll11111_l1_+1)+l11ll1_l1_ (u"࠭ࠠ࠰ࠢࠪ䑾")+str(l1l11l1l1l11_l1_))
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l11lllll1l1l_l1_ = str(l11lll11111l_l1_[l11ll11111_l1_])
		if kodi_version>18.99: l11lllll1l1l_l1_ = l11lllll1l1l_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䑿"))
		open(l11llllllll1_l1_+l11ll1_l1_ (u"ࠨ࠰࠳࠴ࠬ䒀")+str(l11ll11111_l1_),l11ll1_l1_ (u"ࠩࡺࡦࠬ䒁")).write(l11lllll1l1l_l1_)
	del l11lll11111l_l1_,l11lllll1l1l_l1_
	l11ll1llll1l_l1_,l11llll1l11l_l1_,l1ll1l111lll_l1_ = [],[],0
	for l11ll11111_l1_ in range(l1l11l1l1l11_l1_):
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l11lllll1l1l_l1_ = open(l11llllllll1_l1_+l11ll1_l1_ (u"ࠪ࠲࠵࠶ࠧ䒂")+str(l11ll11111_l1_),l11ll1_l1_ (u"ࠫࡷࡨࠧ䒃")).read()
		time.sleep(1)
		try: os.remove(l11llllllll1_l1_+l11ll1_l1_ (u"ࠬ࠴࠰࠱ࠩ䒄")+str(l11ll11111_l1_))
		except: pass
		if kodi_version>18.99: l11lllll1l1l_l1_ = l11lllll1l1l_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䒅"))
		lines = EVAL(l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䒆"),l11lllll1l1l_l1_)
		del l11lllll1l1l_l1_
		l1ll11llllll_l1_,l1ll1l111lll_l1_,l11lll1111l1_l1_ = READ_ALL_LINES(lines,l1l111l11lll_l1_,l11lllllll11_l1_,l11l1l1lll_l1_,l11ll1lll11l_l1_,l1ll1l111lll_l1_,l11llll1llll_l1_)
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		if not l1ll11llllll_l1_:
			l11l1l1lll_l1_.close()
			return
		l11llll1l11l_l1_ += l1ll11llllll_l1_
		l11ll1llll1l_l1_ += l11lll1111l1_l1_
	del lines,l1ll11llllll_l1_
	l11lllllll1l_l1_,l11lll1111l1_l1_ = CREATE_GROUPED_STREAMS(l11llll1l11l_l1_,l11l1l1lll_l1_,l111l1ll_l1_)
	if l11l1l1lll_l1_.iscanceled():
		l11l1l1lll_l1_.close()
		return
	l11ll1llll1l_l1_ += l11lll1111l1_l1_
	del l11llll1l11l_l1_,l11lll1111l1_l1_
	l1l111ll111l_l1_,l1l111l1ll11_l1_,groups,l11lll11lll1_l1_,l11lll1lllll_l1_ = {},{},{},0,0
	l11lll1l11l1_l1_ = list(l11lllllll1l_l1_.keys())
	l1l111l1l1ll_l1_ = len(l11lll1l11l1_l1_)*3
	import threading
	if 1:
		threads = {}
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			threads[l11llllll1l1_l1_] = threading.Thread(target=CREATE_MENUS,args=(l11llllll1l1_l1_,))
			threads[l11llllll1l1_l1_].start()
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			threads[l11llllll1l1_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			CREATE_MENUS(l11llllll1l1_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	DELETE_FILES(l1lll111l1l1_l1_,l111l1ll_l1_,False)
	l11lll1l11l1_l1_ = list(l1l111ll111l_l1_.keys())
	l11ll1ll1lll_l1_ = 0
	if 1:
		threads = {}
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			threads[l11llllll1l1_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1lll111l1l1_l1_,l11llllll1l1_l1_))
			threads[l11llllll1l1_l1_].start()
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			threads[l11llllll1l1_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l11llllll1l1_l1_ in l11lll1l11l1_l1_:
			SAVE_MENUS(l1lll111l1l1_l1_,l11llllll1l1_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	l11ll11111_l1_ = 0
	l1l111ll11ll_l1_ = len(l11ll1llll1l_l1_)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࠩ䒇"))
	for stream in l11ll1llll1l_l1_:
		if l11ll11111_l1_%27==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,95+int(5*l11ll11111_l1_//l1l111ll11ll_l1_),l11ll1_l1_ (u"ࠩอาื๐ๆࠡษ็้์๋ไสࠩ䒈"),l11ll1_l1_ (u"ࠪห้็๊ะ์๋ࠤึ่ๅ࠻࠯ࠪ䒉"),str(l11ll11111_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ䒊")+str(l1l111ll11ll_l1_))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉࡥࠧ䒋")+l111l1ll_l1_,str(stream),l11ll1_l1_ (u"࠭ࠧ䒌"),PERMANENT_CACHE)
		l11ll11111_l1_ += 1
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧࡊࡉࡑࡓࡗࡋࡄࡠࠩ䒍")+l111l1ll_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䒎"),str(l1l111ll11ll_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࡠࠩ䒏")+l111l1ll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡊࡕࡎࡏ࡜ࡣࡤ࠭䒐"),l11ll1_l1_ (u"ࠫ࠶࠭䒑"),PERMANENT_CACHE)
	#open(l1lllll11111_l1_,l11ll1_l1_ (u"ࠬࡽࠧ䒒")).write(l11ll1_l1_ (u"࠭ࠧ䒓"))
	l11l1l1lll_l1_.close()
	time.sleep(1)
	#l11lll1ll1ll_l1_ = COUNTS(l1lll111l1l1_l1_,l111l1ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䒔"),l11ll1_l1_ (u"ࠨࠩ䒕"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䒖"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䒗")+l11ll1_l1_ (u"ࠫฯ๋ࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ䒘")+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䒙")+l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ䒚")+l11lll1ll1ll_l1_)
	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ䒛"))
	DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_)
	return
def CREATE_MENUS(l11llllll1l1_l1_):
	global l11l1l1lll_l1_,l11lllllll1l_l1_,l11ll1ll1lll_l1_,l1l111ll111l_l1_,l1l111l1ll11_l1_,groups,l11lll11lll1_l1_,l11lll1lllll_l1_,l1l111l1l1ll_l1_
	l1l111ll111l_l1_[l11llllll1l1_l1_] = {}
	l11lll1ll111_l1_,l1l11111ll11_l1_ = {},[]
	l11ll1llllll_l1_ = len(l11lllllll1l_l1_[l11llllll1l1_l1_])
	l1l111ll111l_l1_[l11llllll1l1_l1_][l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䒜")] = l11ll1llllll_l1_
	if l11ll1llllll_l1_>0:
		l1l1111ll11l_l1_,l1l111ll1lll_l1_,l11ll1ll11ll_l1_,l1l111ll1l11_l1_,l1l1111111ll_l1_ = zip(*l11lllllll1l_l1_[l11llllll1l1_l1_])
		del l1l111ll1lll_l1_,l11ll1ll11ll_l1_,l1l111ll1l11_l1_
		l11llll1l1l1_l1_ = list(set(l1l1111ll11l_l1_))
		for group in l11llll1l1l1_l1_:
			l11lll1ll111_l1_[group] = l11ll1_l1_ (u"ࠩࠪ䒝")
			l1l111ll111l_l1_[l11llllll1l1_l1_][group] = []
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11lll1lllll_l1_//l1l111l1l1ll_l1_),l11ll1_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่็๎วว็ࠪ䒞"),l11ll1_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ䒟"),str(l11lll1lllll_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䒠")+str(l1l111l1l1ll_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11lll1lllll_l1_ += 1
		l11lll1l111l_l1_ = len(l11llll1l1l1_l1_)
		del l11llll1l1l1_l1_
		l1l11111ll11_l1_ = list(set(zip(l1l1111ll11l_l1_,l1l1111111ll_l1_)))
		del l1l1111ll11l_l1_,l1l1111111ll_l1_
		for group,l111_l1_ in l1l11111ll11_l1_:
			if not l11lll1ll111_l1_[group] and l111_l1_: l11lll1ll111_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11lll1lllll_l1_//l1l111l1l1ll_l1_),l11ll1_l1_ (u"࠭สึ่ํ฽ࠥอไใ๊สส๊࠭䒡"),l11ll1_l1_ (u"ࠧศๆฯึฦࠦัใ็࠽࠱ࠬ䒢"),str(l11lll1lllll_l1_)+l11ll1_l1_ (u"ࠨࠢ࠲ࠤࠬ䒣")+str(l1l111l1l1ll_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11lll1lllll_l1_ += 1
		l11llll11l11_l1_ = list(l11lll1ll111_l1_.keys())
		l11lll11llll_l1_ = list(l11lll1ll111_l1_.values())
		del l11lll1ll111_l1_
		l1l11111ll11_l1_ = list(zip(l11llll11l11_l1_,l11lll11llll_l1_))
		del l11llll11l11_l1_,l11lll11llll_l1_
		l1l11111ll11_l1_ = sorted(l1l11111ll11_l1_)
	else: l11lll1lllll_l1_ += 2
	l1l111ll111l_l1_[l11llllll1l1_l1_][l11ll1_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭䒤")] = l1l11111ll11_l1_
	del l1l11111ll11_l1_
	for group,context,title,url,l1lll1_l1_ in l11lllllll1l_l1_[l11llllll1l1_l1_]:
		l1l111ll111l_l1_[l11llllll1l1_l1_][group].append((context,title,url,l1lll1_l1_))
	PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11lll1lllll_l1_//l1l111l1l1ll_l1_),l11ll1_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่็๎วว็ࠪ䒥"),l11ll1_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ䒦"),str(l11lll1lllll_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䒧")+str(l1l111l1l1ll_l1_))
	if l11l1l1lll_l1_.iscanceled(): return
	l11lll1lllll_l1_ += 1
	del l11lllllll1l_l1_[l11llllll1l1_l1_]
	groups[l11llllll1l1_l1_] = list(l1l111ll111l_l1_[l11llllll1l1_l1_].keys())
	l1l111l1ll11_l1_[l11llllll1l1_l1_] = len(groups[l11llllll1l1_l1_])
	l11lll11lll1_l1_ += l1l111l1ll11_l1_[l11llllll1l1_l1_]
	return
def SAVE_MENUS(l1lll111l1l1_l1_,l11llllll1l1_l1_):
	global l11l1l1lll_l1_,l11lllllll1l_l1_,l11ll1ll1lll_l1_,l1l111ll111l_l1_,l1l111l1ll11_l1_,groups,l11lll11lll1_l1_,l11lll1lllll_l1_,l1l111l1l1ll_l1_
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11llllll1l1_l1_)
	for l1ll1l111lll_l1_ in range(1+l1l111l1ll11_l1_[l11llllll1l1_l1_]//173):
		l11lll11l1l1_l1_ = []
		l1l1111l1111_l1_ = groups[l11llllll1l1_l1_][0:273]
		for group in l1l1111l1111_l1_:
			l11lll11l1l1_l1_.append(l1l111ll111l_l1_[l11llllll1l1_l1_][group])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1l1_l1_,l1l1111l1111_l1_,l11lll11l1l1_l1_,PERMANENT_CACHE,True)
		l11ll1ll1lll_l1_ += len(l1l1111l1111_l1_)
		PROGRESS_UPDATE(l11l1l1lll_l1_,75+int(20*l11ll1ll1lll_l1_//l11lll11lll1_l1_),l11ll1_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊࠭䒨"),l11ll1_l1_ (u"ࠧศๆๅหห๋ษࠡำๅ้࠿࠳ࠧ䒩"),str(l11ll1ll1lll_l1_)+l11ll1_l1_ (u"ࠨࠢ࠲ࠤࠬ䒪")+str(l11lll11lll1_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		del groups[l11llllll1l1_l1_][0:273]
	del l1l111ll111l_l1_[l11llllll1l1_l1_],groups[l11llllll1l1_l1_],l1l111l1ll11_l1_[l11llllll1l1_l1_]
	return
def COUNTS(l1lll111l1l1_l1_,l111l1ll_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,l1ll_l1_): return
	l1l1111l111l_l1_ = l11ll1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠡฮ่๎฾ࠦวๅำ๋หอ฽ࠧ䒫")
	l11lll1lll11_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒬"))
	l1l111111111_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒭"))
	if l111l1ll_l1_:
		l1l1111l111l_l1_ = l11ll1_l1_ (u"ࠬ฿ฯะࠢไ๎ิ๐่่ษอࠤึอศุࠢࠪ䒮")+text_numbers[int(l111l1ll_l1_)]
		l111l1ll_l1_ = l11ll1_l1_ (u"࠭࡟ࠨ䒯")+l111l1ll_l1_
	l1l111ll11ll_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ䒰"),l11ll1_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࠩ䒱")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䒲"))
	l1l111111lll_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠪ࡭ࡳࡺࠧ䒳"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䒴")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䒵"))
	l11ll1ll1l11_l1_ = READ_FROM_SQL3(l1l111111111_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ䒶"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ䒷")+l111l1ll_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䒸"))
	l11llllll11l_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࠭䒹"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䒺")+l111l1ll_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䒻"))
	l11lll1l1ll1_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠬ࡯࡮ࡵࠩ䒼"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䒽")+l111l1ll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䒾"))
	l1l1111ll1ll_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠨ࡫ࡱࡸࠬ䒿"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䓀")+l111l1ll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䓁"))
	l1l111ll11l1_l1_ = READ_FROM_SQL3(l1l111111111_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䓂"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䓃")+l111l1ll_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䓄"))
	l11llll111ll_l1_ = READ_FROM_SQL3(l11lll1lll11_l1_,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ䓅"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䓆")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䓇"))
	groups = READ_FROM_SQL3(l1l111111111_l1_,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䓈"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䓉")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䓊"))
	l11lllll1111_l1_ = []
	for group,l1lll1_l1_ in groups:
		l11llll1ll11_l1_ = group.split(l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䓋"))[1]
		l11lllll1111_l1_.append(l11llll1ll11_l1_)
	l1l11111111l_l1_ = len(l11lllll1111_l1_)
	total = int(l1l1111ll1ll_l1_)+int(l1l111ll11l1_l1_)+int(l11llll111ll_l1_)+int(l11lll1l1ll1_l1_)+int(l11llllll11l_l1_)
	l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠧࠨ䓌")
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠨไ้์ฬะ࠺ࠡࠩ䓍")+str(l11llllll11l_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢฦๅ้อๅ࠻ࠢࠪ䓎")+str(l1l1111ll1ll_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ๋ำๅี็หฯࡀࠠࠨ䓏")+str(l1l11111111l_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤา๊โศฬ࠽ࠤࠬ䓐")+str(l1l111ll11l1_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ใ่๋หฯࠦๅอ้๋่ฮࡀࠠࠨ䓑")+str(l11lll1l1ll1_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦแ๋ั๋๋ฬะࠠๆฮ๊์้ฯ࠺ࠡࠩ䓒")+str(l11llll111ll_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ่ะ๊๎ูࠡษ็ๆ๋๎วห࠼ࠣࠫ䓓")+str(l1l111111lll_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡ็ฯ้ํ฿ࠠศๆไ๎ิ๐่่ษอ࠾ࠥ࠭䓔")+str(l11ll1ll1l11_l1_)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴๅอ็๋฽ࠥอไๆุสๅฮࡀࠠࠨ䓕")+str(total)
	l11lll1ll1ll_l1_ += l11ll1_l1_ (u"ࠪࠤࠥࠦ࠮้ࠡࠢࠣัฺ๋่ࠢส่๊ํๅๅห࠽ࠤࠬ䓖")+str(l1l111ll11ll_l1_)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䓗"),l11ll1_l1_ (u"ࠬ࠭䓘"),l1l1111l111l_l1_,l11lll1ll1ll_l1_)
	l11llll111l1_l1_ = l11lll1ll1ll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ䓙"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ䓚"))
	if not l111l1ll_l1_: l111l1ll_l1_ = l11ll1_l1_ (u"ࠨࡃ࡯ࡰࠬ䓛")
	else: l111l1ll_l1_ = l111l1ll_l1_[1]
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䓜"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࡃࡰࡷࡱࡸࡸࠦ࡯ࡧࠢࡐ࠷࡚ࠦࡶࡪࡦࡨࡳࡸࠦࠠࠡࡈࡲࡰࡩ࡫ࡲ࠻ࠢࠪ䓝")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ䓞")+l111l1ll_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ䓟")+l11llll111l1_l1_)
	return l11lll1ll1ll_l1_
def DELETE_FILES(l1lll111l1l1_l1_,l111l1ll_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䓠"),l11ll1_l1_ (u"ࠧࠨ䓡"),l11ll1_l1_ (u"ࠨࠩ䓢"),l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ䓣"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭䓤"))
		if l1ll111ll1_l1_!=1: return
		file = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ䓥"),l11ll1_l1_ (u"ࠬࡥࠧ䓦")+l1lll111l1l1_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䓧")+l111l1ll_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l11111l11l_l1_)
	#except: pass
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࠨ䓨"))
	if l111l1ll_l1_:
		l11lllll1l11_l1_ = []
		for l11ll1l11_l1_ in l11lllll11l1_l1_:
			l11lllll1l11_l1_.append(l11ll1l11_l1_+l11ll1_l1_ (u"ࠨࡡࠪ䓩")+l111l1ll_l1_)
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡏࡍࡓࡑ࡟ࠨ䓪")+l111l1ll_l1_)
	else:
		l11lllll1l11_l1_ = l11lllll11l1_l1_
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䓫"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡌࡘࡏࡖࡒࡖࠫ䓬"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡏࡔࡆࡏࡖࠫ䓭"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡓࡆࡃࡕࡇࡍ࠭䓮"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䓯"),l11ll1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ䓰")+l1lll111l1l1_l1_)
	for l11llllll1l1_l1_ in l11lllll1l11_l1_:
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11llllll1l1_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䓱"),l11ll1_l1_ (u"ࠪࠫ䓲"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䓳"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䓴"))
	DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_)
	return
def CHECK_TABLES_EXIST(l1lll111l1l1_l1_=l11ll1_l1_ (u"࠭ࠧ䓵"),l1ll_l1_=True):
	if l1lll111l1l1_l1_:
		l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll111l1l1_l1_),l11ll1_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭䓶"))
		dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ䓷"),l11ll1_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࠨ䓸"),l11ll1_l1_ (u"ࠪࡣࡤࡊࡕࡎࡏ࡜ࡣࡤ࠭䓹"))
		if dummy: return True
	else:
		for l1lll111l1l1_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll111l1l1_l1_),l11ll1_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ䓺"))
			dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ䓻"),l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䓼"),l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䓽"))
			if dummy: return True
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ䓾"),l11ll1_l1_ (u"ࠩࠪ䓿"),l11ll1_l1_ (u"ࠪࠫ䔀"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䔁"),l11ll1_l1_ (u"ࠬอๆหࠢอัฯอฬࠡล้ࠤฯ็สฮࠢๅหห๋ษࠡࡏ࠶࡙ࠥัๅࠡฬ้ๆึูࠦๅ๋ࠣࠦส฼วโหࠣีฬฮืࠡล๋ࠤฬฺสาษๆࠤࡒ࠹ࡕࠣࠢ࠱࠲ࠥํะ่ࠢส่ึ๎วษูࠣฮัี็ศࠢไ๎ࠥอไฦ่อี๋ะࠠฤ๊ࠣฮูะั๋้สࠤ๊์ࠠีำๆอࠥ็๊ะ์๋๋ฬะࠠ࡝ࡰ࡟ࡲࠥ๎ลัษࠣๆ๊ะࠠษวูหๆฯࠠาษห฻ࠥ็ลั่ࠣว๋ะࠠหฯอหัࠦร็ࠢอะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤํึไไࠢหๅฯำࠠใษษ้ฮࠦเࡎ࠵ࡘࠤะ๋ࠠห่ๅีࠥ฿ไ๊ࠢࠥะ้ฮࠠๆๆไหฯࠨࠠ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ็ๅࠢอี๏ีࠠฦุสๅฮࠦัศสฺࠤࡒ࠹ࡕࠡษ็ฦ๋ࠦฟࠢࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䔂"))
		if l1ll111ll1_l1_: ADD_ACCOUNT(l1lll111l1l1_l1_,l11ll1_l1_ (u"࠭࠱ࠨ䔃"))
	#SHOW_EMPTY(l111l1_l1_)
	return False
def SEARCH(l1ll11111ll_l1_,l1lll111l1l1_l1_=l11ll1_l1_ (u"ࠧࠨ䔄"),l11llllll1l1_l1_=l11ll1_l1_ (u"ࠨࠩ䔅"),l11lll1ll1l1_l1_=l11ll1_l1_ (u"ࠩࠪ䔆")):
	if not l11lll1ll1l1_l1_: l11lll1ll1l1_l1_ = l11ll1_l1_ (u"ࠪ࠵ࠬ䔇")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llll1l1ll_l1_ = [l11ll1_l1_ (u"ࠫࠬ䔈"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䔉"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䔊"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䔋"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䔌"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䔍")]
	if not l11llllll1l1_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊࡥࠧ䔎") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[1]
			elif l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ䔏") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[2]
			elif l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ䔐") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[3]
			else: l11llllll1l1_l1_ = l11llll1l1ll_l1_[0]
		else:
			l1l11111l1l1_l1_ = [l11ll1_l1_ (u"࠭วๅๅ็ࠫ䔑"),l11ll1_l1_ (u"ࠧใ่๋หฯ࠭䔒"),l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠧ䔓"),l11ll1_l1_ (u"่ࠩืู้ไศฬࠪ䔔"),l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥฬ่๊็อࠬ䔕"),l11ll1_l1_ (u"ࠫ็์่ศฬ้ࠣัํ่ๅหࠪ䔖")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䔗"), l1l11111l1l1_l1_)
			if choice==-1: return
			l11llllll1l1_l1_ = l11llll1l1ll_l1_[choice]
	search = search+l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ䔘")
	if l1lll111l1l1_l1_: SEARCH_ONE_FOLDER(search,l1lll111l1l1_l1_,l11llllll1l1_l1_,l11lll1ll1l1_l1_)
	else:
		for l1lll111l1l1_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1lll111l1l1_l1_),l11llllll1l1_l1_,l11lll1ll1l1_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1ll11111ll_l1_,l1lll111l1l1_l1_,l11llllll1l1_l1_=l11ll1_l1_ (u"ࠧࠨ䔙"),l11lll1ll1l1_l1_=l11ll1_l1_ (u"ࠨࠩ䔚")):
	if not l11lll1ll1l1_l1_: l11lll1ll1l1_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ䔛")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not l1lll111l1l1_l1_: return
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llll1l1ll_l1_ = [l11ll1_l1_ (u"ࠪࠫ䔜"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䔝"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䔞"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䔟"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䔠"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䔡")]
	if not l11llllll1l1_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡍࡋ࡙ࡉࡤ࠭䔢") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[1]
			elif l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ䔣") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[2]
			elif l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ䔤") in options: l11llllll1l1_l1_ = l11llll1l1ll_l1_[3]
			else: l11llllll1l1_l1_ = l11llll1l1ll_l1_[0]
		else:
			l1l11111l1l1_l1_ = [l11ll1_l1_ (u"ࠬอไไๆࠪ䔥"),l11ll1_l1_ (u"࠭โ็๊สฮࠬ䔦"),l11ll1_l1_ (u"ࠧฤใ็ห๊࠭䔧"),l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠩ䔨"),l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠫ䔩"),l11ll1_l1_ (u"ࠪๆ๋๎วห่ࠢะ์๎ไสࠩ䔪")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ䔫"), l1l11111l1l1_l1_)
			if choice==-1: return
			l11llllll1l1_l1_ = l11llll1l1ll_l1_[choice]
	l11ll1ll1ll1_l1_ = search.lower()
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࠬ䔬"))
	results = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ䔭"),l11ll1_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ䔮"),(l11llllll1l1_l1_,l11ll1ll1ll1_l1_))
	if not results:
		l1l111l11ll1_l1_,l11llll1lll1_l1_ = [],[]
		if not l11llllll1l1_l1_: l11llll11111_l1_ = [1,2,3,4,5]
		else: l11llll11111_l1_ = [l11llll1l1ll_l1_.index(l11llllll1l1_l1_)]
		for l11ll11111_l1_ in l11llll11111_l1_:
			#l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11llll1l1ll_l1_[l11ll11111_l1_])
			if l11ll11111_l1_!=3:
				l1ll11llllll_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䔯"),l11llll1l1ll_l1_[l11ll11111_l1_])
				del l1ll11llllll_l1_[l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䔰")]
				del l1ll11llllll_l1_[l11ll1_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䔱")]
				del l1ll11llllll_l1_[l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬ䔲")]
				groups = list(l1ll11llllll_l1_.keys())
				for group in groups:
					for context,title,url,l1lll1_l1_ in l1ll11llllll_l1_[group]:
						if l11ll1ll1ll1_l1_ in title.lower(): l11llll1lll1_l1_.append((title,url,l1lll1_l1_))
					del l1ll11llllll_l1_[group]
				del l1ll11llllll_l1_
			else: groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ䔳"),l11llll1l1ll_l1_[l11ll11111_l1_],l11ll1_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ䔴"))
			for group in groups:
				try: group,l1lll1_l1_ = group
				except: l1lll1_l1_ = l11ll1_l1_ (u"ࠧࠨ䔵")
				if l11ll1ll1ll1_l1_ in group.lower():
					if l11ll11111_l1_!=3: l1l1111l11ll_l1_ = group
					else:
						l1l1111l1l11_l1_,l11ll1ll1l1l_l1_ = group.split(l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䔶"))
						if l11ll1ll1ll1_l1_ in l1l1111l1l11_l1_.lower(): l1l1111l11ll_l1_ = l1l1111l1l11_l1_
						else: l1l1111l11ll_l1_ = l11ll1ll1l1l_l1_
					l1l111l11ll1_l1_.append((group,l1l1111l11ll_l1_,l11llll1l1ll_l1_[l11ll11111_l1_],l1lll1_l1_))
			del groups
		l1l111l11ll1_l1_ = set(l1l111l11ll1_l1_)
		l11llll1lll1_l1_ = set(l11llll1lll1_l1_)
		l1l111l11ll1_l1_ = sorted(l1l111l11ll1_l1_,reverse=False,key=lambda key: key[1])
		l11llll1lll1_l1_ = sorted(l11llll1lll1_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ䔷"),(l11llllll1l1_l1_,l11ll1ll1ll1_l1_),(l1l111l11ll1_l1_,l11llll1lll1_l1_),PERMANENT_CACHE)
	else: l1l111l11ll1_l1_,l11llll1lll1_l1_ = results
	groups = len(l1l111l11ll1_l1_)
	l11lll_l1_ = len(l11llll1lll1_l1_)
	l1l1111_l1_ = int(l11lll1ll1l1_l1_)
	s1 = max(0,(l1l1111_l1_-1)*100)
	e1 = max(0,l1l1111_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l1111l11ll_l1_,l1l111l111l1_l1_,l1lll1_l1_ in l1l111l11ll1_l1_[s1:e1]:
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔸"),l111l1_l1_+l1l1111l11ll_l1_,l1l111l111l1_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠫ࠶࠭䔹"),group,l11ll1_l1_ (u"ࠬ࠭䔺"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔻"):l1lll111l1l1_l1_})
	del l1l111l11ll1_l1_
	for title,url,l1lll1_l1_ in l11llll1lll1_l1_[s2:e2]:
		l1l111l1111l_l1_ = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ䔼"))[-1]
		if l11ll1_l1_ (u"ࠨ࠰ࠪ䔽") in l1l111l1111l_l1_ and l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䔾") not in l1l111l1111l_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䔿"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䕀"),l11ll1_l1_ (u"ࠬ࠭䕁"),l11ll1_l1_ (u"࠭ࠧ䕂"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕃"):l1lll111l1l1_l1_})
		else: addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䕄"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䕅"),l11ll1_l1_ (u"ࠪࠫ䕆"),l11ll1_l1_ (u"ࠫࠬ䕇"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕈"):l1lll111l1l1_l1_})
	del l11llll1lll1_l1_
	PAGINATION(l1lll111l1l1_l1_,l11lll1ll1l1_l1_,l11llllll1l1_l1_,719,groups+l11lll_l1_,search+l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ䕉"))
	return
def PAGINATION(l1lll111l1l1_l1_,l11lll1ll1l1_l1_,l11llllll1l1_l1_,mode,total,text):
	if not l11lll1ll1l1_l1_: l11lll1ll1l1_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ䕊")
	if l11lll1ll1l1_l1_!=l11ll1_l1_ (u"ࠨ࠳ࠪ䕋"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕌"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䕍")+str(1),l11llllll1l1_l1_,mode,l11ll1_l1_ (u"ࠫࠬ䕎"),str(1),text,l11ll1_l1_ (u"ࠬ࠭䕏"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕐"):l1lll111l1l1_l1_})
	if not total: total = 0
	l1l1l1lll_l1_ = int(total/100)+1
	for l1l1111_l1_ in range(2,l1l1l1lll_l1_):
		l1ll1ll1l1ll_l1_ = (l1l1111_l1_%10==0 or int(l11lll1ll1l1_l1_)-4<l1l1111_l1_<int(l11lll1ll1l1_l1_)+4)
		l1ll1ll1l11l_l1_ = (l1ll1ll1l1ll_l1_ and int(l11lll1ll1l1_l1_)-40<l1l1111_l1_<int(l11lll1ll1l1_l1_)+40)
		if str(l1l1111_l1_)!=l11lll1ll1l1_l1_ and (l1l1111_l1_%100==0 or l1ll1ll1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕑"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦࠧ䕒")+str(l1l1111_l1_),l11llllll1l1_l1_,mode,l11ll1_l1_ (u"ࠩࠪ䕓"),str(l1l1111_l1_),text,l11ll1_l1_ (u"ࠪࠫ䕔"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕕"):l1lll111l1l1_l1_})
	if str(l1l1l1lll_l1_)!=l11lll1ll1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕖"),l111l1_l1_+l11ll1_l1_ (u"࠭รฯำูࠣๆำษࠡࠩ䕗")+str(l1l1l1lll_l1_),l11llllll1l1_l1_,mode,l11ll1_l1_ (u"ࠧࠨ䕘"),str(l1l1l1lll_l1_),text,l11ll1_l1_ (u"ࠨࠩ䕙"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕚"):l1lll111l1l1_l1_})
	return
def GET_DBFILE_NAME(l1lll111l1l1_l1_,l11llllll1l1_l1_):
	#if l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ䕛") in l11llllll1l1_l1_ or l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࠪ䕜") in l11llllll1l1_l1_: l1l1ll111l_l1_ = l1l1lll1l11l_l1_
	#else: l1l1ll111l_l1_ = l1l1lll1l11l_l1_
	l1l1ll111l_l1_ = l1l1lll1l11l_l1_.replace(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ䕝"),l11ll1_l1_ (u"࠭࡟ࠨ䕞")+l1lll111l1l1_l1_)
	return l1l1ll111l_l1_
def l1l1111l1lll_l1_(l1lll111l1l1_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠧࠨ䕟"))
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䕠"),l11ll1_l1_ (u"ࠩࠪ䕡"),l11ll1_l1_ (u"ࠪࠫ䕢"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕣"),l11ll1_l1_ (u"ࠬ฿ๅๅ์ฬࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠤ็ีࠠหฯอหัูࠦะหࠣำ็อฦใࠢ࠱ࠤ์๊ࠠหำํำࠥษๆࠡฬฯ่อࠦวๅ็็ๅฬะࠠศๆล๊ࠥลࠧ䕤"))
	if l1ll111ll1_l1_!=1: return
	l1l111l1lll1_l1_(l1lll111l1l1_l1_,False)
	counts = [0]
	for seq in range(1,l11llll1ll1l_l1_+1):
		l1l111l1l111_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ䕥")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䕦")+str(seq))
		if l1l111l1l111_l1_: CREATE_STREAMS(l1lll111l1l1_l1_,str(seq))
		counts.append(0)
	for l11llllll1l1_l1_ in l11lllll11l1_l1_:
		l11lll1ll11l_l1_,l11lll1lll1l_l1_,l1l111ll1l1l_l1_,l11llll11lll_l1_,l11lll1ll111_l1_ = 0,{},[],[],[]
		for seq in range(1,l11llll1ll1l_l1_+1):
			l1l111l111l1_l1_ = l11llllll1l1_l1_+l11ll1_l1_ (u"ࠨࡡࠪ䕧")+str(seq)
			l11lllllll1l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䕨"),l1l111l111l1_l1_)
			try:
				l1l111l1llll_l1_ = l11lllllll1l_l1_[l11ll1_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䕩")]
				count = l11lllllll1l_l1_[l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䕪")]
			except:
				l1l111l1llll_l1_ = []
				count = l11ll1_l1_ (u"ࠬ࠶ࠧ䕫")
			for tuple in l1l111l1llll_l1_:
				group,l111_l1_ = tuple
				l1ll11llllll_l1_ = l11lllllll1l_l1_[group]
				if group not in l11llll11lll_l1_:
					l11llll11lll_l1_.append(group)
					l11lll1ll111_l1_.append(tuple)
					l11lll1lll1l_l1_[group] = []
				l11lll1lll1l_l1_[group] += l1ll11llllll_l1_
			DELETE_FROM_SQL3(l1l1ll111l_l1_,l1l111l111l1_l1_)
			WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111l111l1_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䕬"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11llll11lll_l1_:
			l1ll11llllll_l1_ = list(set(l11lll1lll1l_l1_[group]))
			l11lll1ll11l_l1_ += len(l1ll11llllll_l1_)
			l1l111ll1l1l_l1_.append(l1ll11llllll_l1_)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1l1_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䕭"),str(l11lll1ll11l_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1l1_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ䕮"),l11lll1ll111_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1l1_l1_,l11llll11lll_l1_,l1l111ll1l1l_l1_,PERMANENT_CACHE,True)
	l1l111111l1l_l1_ = False
	for seq in range(1,l11llll1ll1l_l1_+1):
		if int(counts[seq])>0:
			l1l111l1l111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ䕯")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䕰")+str(seq))
			WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡑࡏࡎࡌࡡࠪ䕱")+str(seq),l11ll1_l1_ (u"ࠬࡥ࡟ࡍࡋࡑࡏࡤࡥࠧ䕲"),l1l111l1l111_l1_,PERMANENT_CACHE)
			l1l111111l1l_l1_ = True
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䕳"),l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䕴"),l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䕵"),PERMANENT_CACHE)
	if l1l111111l1l_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䕶"),l11ll1_l1_ (u"ࠪࠫ䕷"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕸"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䕹")+l11ll1_l1_ (u"࠭สๆࠢฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠩ䕺")+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䕻"))
		l1l111111ll1_l1_(l1lll111l1l1_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䕼"))
	else: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䕽"),l11ll1_l1_ (u"ࠪࠫ䕾"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕿"),l11ll1_l1_ (u"ࠬ็ิๅࠢหืาฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤ࠳ࠦรฮฬ่ห้ࠦั้ษห฻ࠥๆࡍ࠴ࡗࠣห้ะ๊ࠡล้ฮࠥษึโฬ๊ห๊ࠥไษำ้ห๊าࠠ฻์ิࠤฺำ๊ฮหࠣ࠲࠳ูࠦๅ็สࠤศ์่ࠠา๊ࠤฬ๊ฮะ็ฬࠤฯำสศฮ้๋้ࠣࠠฤ่ࠣฮ฻๐แࠡษ็ีฬฮืࠡส้ๅุ้ࠠๅๆหี๋อๅอࠢหหุะฮะษ่ࠤ็อฦๆหࠣไࡒ࠹ࡕࠡษ็้ํา่ะหࠣฬ์ึวࠡษ็ฬึ์วๆฮࠪ䖀"))
	return
def l1l111111ll1_l1_(l1lll111l1l1_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"࠭ࠧ䖁"))
	if not CHECK_TABLES_EXIST(l1lll111l1l1_l1_,True): return
	for seq in range(1,l11llll1ll1l_l1_+1):
		l1l111l1l111_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ䖂"),l11ll1_l1_ (u"ࠨࡎࡌࡒࡐࡥࠧ䖃")+str(seq),l11ll1_l1_ (u"ࠩࡢࡣࡑࡏࡎࡌࡡࡢࠫ䖄"))
		if l1l111l1l111_l1_: l11lll1ll1ll_l1_ = COUNTS(l1lll111l1l1_l1_,str(seq))
	COUNTS(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠪࠫ䖅"))
	return
def l1l111l1lll1_l1_(l1lll111l1l1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䖆"),l11ll1_l1_ (u"ࠬ࠭䖇"),l11ll1_l1_ (u"࠭ࠧ䖈"),l11ll1_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣไࡒ࠹ࡕࠨ䖉"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ว์ࠠๆีะࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠡ࠰࠱ࠤ฾๊ๅศࠢส๊่ࠦสิฬฺ๎฾ࠦแ๋ࠢฦ๎ࠥ๎โหࠢส่ิิ่ๅࠢศ่๎ࠦโศศ่อࠥๆࡍ࠴ࡗࠣ์ั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ䖊"))
		if l1ll111ll1_l1_!=1: return
	#for seq in range(1,l11llll1ll1l_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11ll1_l1_ (u"ࠩࠪ䖋"),False)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l1l1_l1_,l11ll1_l1_ (u"ࠪࠫ䖌"))
	try: os.remove(l1l1ll111l_l1_)
	except: pass
	for seq in range(1,l11llll1ll1l_l1_+1):
		filename = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ䖍"),l11ll1_l1_ (u"ࠬࡥࠧ䖎")+l1lll111l1l1_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䖏")+str(seq))
		l1lll111ll11_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1lll111ll11_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䖐"),l11ll1_l1_ (u"ࠨࠩ䖑"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䖒"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠแࡏ࠶࡙ࠬ䖓"))
	return
def DELETE_OLD_MENUS_CACHE(l1lll111l1l1_l1_):
	trans_provider = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡳࡶࡴࡼࡩࡥࡧࡵࠫ䖔"))
	trans_code = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ䖕"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ䖖")+trans_provider+l11ll1_l1_ (u"ࠧࡠࠩ䖗")+trans_code,l11ll1_l1_ (u"ࠨࠧࡢࡑ࡚࠭䖘")+l1lll111l1l1_l1_+l11ll1_l1_ (u"ࠩࡢࠩࠬ䖙"))
	return
COUNTRIES_CODES = {
		 l11ll1_l1_ (u"ࠪࡅࡋ࠭䖚"):l11ll1_l1_ (u"ࠫࡆ࡬ࡧࡩࡣࡱ࡭ࡸࡺࡡ࡯ࠩ䖛")
		,l11ll1_l1_ (u"ࠬࡇࡌࠨ䖜"):l11ll1_l1_ (u"࠭ࡁ࡭ࡤࡤࡲ࡮ࡧࠧ䖝")
		,l11ll1_l1_ (u"ࠧࡅ࡜ࠪ䖞"):l11ll1_l1_ (u"ࠨࡃ࡯࡫ࡪࡸࡩࡢࠩ䖟")
		,l11ll1_l1_ (u"ࠩࡄࡗࠬ䖠"):l11ll1_l1_ (u"ࠪࡅࡲ࡫ࡲࡪࡥࡤࡲ࡙ࠥࡡ࡮ࡱࡤࠫ䖡")
		,l11ll1_l1_ (u"ࠫࡆࡊࠧ䖢"):l11ll1_l1_ (u"ࠬࡇ࡮ࡥࡱࡵࡶࡦ࠭䖣")
		,l11ll1_l1_ (u"࠭ࡁࡐࠩ䖤"):l11ll1_l1_ (u"ࠧࡂࡰࡪࡳࡱࡧࠧ䖥")
		,l11ll1_l1_ (u"ࠨࡃࡌࠫ䖦"):l11ll1_l1_ (u"ࠩࡄࡲ࡬ࡻࡩ࡭࡮ࡤࠫ䖧")
		,l11ll1_l1_ (u"ࠪࡅࡖ࠭䖨"):l11ll1_l1_ (u"ࠫࡆࡴࡴࡢࡴࡦࡸ࡮ࡩࡡࠨ䖩")
		,l11ll1_l1_ (u"ࠬࡇࡇࠨ䖪"):l11ll1_l1_ (u"࠭ࡁ࡯ࡶ࡬࡫ࡺࡧࠠࡢࡰࡧࠤࡇࡧࡲࡣࡷࡧࡥࠬ䖫")
		,l11ll1_l1_ (u"ࠧࡂࡔࠪ䖬"):l11ll1_l1_ (u"ࠨࡃࡵ࡫ࡪࡴࡴࡪࡰࡤࠫ䖭")
		,l11ll1_l1_ (u"ࠩࡄࡑࠬ䖮"):l11ll1_l1_ (u"ࠪࡅࡷࡳࡥ࡯࡫ࡤࠫ䖯")
		,l11ll1_l1_ (u"ࠫࡆ࡝ࠧ䖰"):l11ll1_l1_ (u"ࠬࡇࡲࡶࡤࡤࠫ䖱")
		,l11ll1_l1_ (u"࠭ࡁࡖࠩ䖲"):l11ll1_l1_ (u"ࠧࡂࡷࡶࡸࡷࡧ࡬ࡪࡣࠪ䖳")
		,l11ll1_l1_ (u"ࠨࡃࡗࠫ䖴"):l11ll1_l1_ (u"ࠩࡄࡹࡸࡺࡲࡪࡣࠪ䖵")
		,l11ll1_l1_ (u"ࠪࡅ࡟࠭䖶"):l11ll1_l1_ (u"ࠫࡆࢀࡥࡳࡤࡤ࡭࡯ࡧ࡮ࠨ䖷")
		,l11ll1_l1_ (u"ࠬࡈࡓࠨ䖸"):l11ll1_l1_ (u"࠭ࡂࡢࡪࡤࡱࡦࡹࠧ䖹")
		,l11ll1_l1_ (u"ࠧࡃࡊࠪ䖺"):l11ll1_l1_ (u"ࠨࡄࡤ࡬ࡷࡧࡩ࡯ࠩ䖻")
		,l11ll1_l1_ (u"ࠩࡅࡈࠬ䖼"):l11ll1_l1_ (u"ࠪࡆࡦࡴࡧ࡭ࡣࡧࡩࡸ࡮ࠧ䖽")
		,l11ll1_l1_ (u"ࠫࡇࡈࠧ䖾"):l11ll1_l1_ (u"ࠬࡈࡡࡳࡤࡤࡨࡴࡹࠧ䖿")
		,l11ll1_l1_ (u"࠭ࡂ࡚ࠩ䗀"):l11ll1_l1_ (u"ࠧࡃࡧ࡯ࡥࡷࡻࡳࠨ䗁")
		,l11ll1_l1_ (u"ࠨࡄࡈࠫ䗂"):l11ll1_l1_ (u"ࠩࡅࡩࡱ࡭ࡩࡶ࡯ࠪ䗃")
		,l11ll1_l1_ (u"ࠪࡆ࡟࠭䗄"):l11ll1_l1_ (u"ࠫࡇ࡫࡬ࡪࡼࡨࠫ䗅")
		,l11ll1_l1_ (u"ࠬࡈࡊࠨ䗆"):l11ll1_l1_ (u"࠭ࡂࡦࡰ࡬ࡲࠬ䗇")
		,l11ll1_l1_ (u"ࠧࡃࡏࠪ䗈"):l11ll1_l1_ (u"ࠨࡄࡨࡶࡲࡻࡤࡢࠩ䗉")
		,l11ll1_l1_ (u"ࠩࡅࡘࠬ䗊"):l11ll1_l1_ (u"ࠪࡆ࡭ࡻࡴࡢࡰࠪ䗋")
		,l11ll1_l1_ (u"ࠫࡇࡕࠧ䗌"):l11ll1_l1_ (u"ࠬࡈ࡯࡭࡫ࡹ࡭ࡦ࠭䗍")
		,l11ll1_l1_ (u"࠭ࡂࡒࠩ䗎"):l11ll1_l1_ (u"ࠧࡃࡱࡱࡥ࡮ࡸࡥࠨ䗏")
		,l11ll1_l1_ (u"ࠨࡄࡄࠫ䗐"):l11ll1_l1_ (u"ࠩࡅࡳࡸࡴࡩࡢࠢࡤࡲࡩࠦࡈࡦࡴࡽࡩ࡬ࡵࡶࡪࡰࡤࠫ䗑")
		,l11ll1_l1_ (u"ࠪࡆ࡜࠭䗒"):l11ll1_l1_ (u"ࠫࡇࡵࡴࡴࡹࡤࡲࡦ࠭䗓")
		,l11ll1_l1_ (u"ࠬࡈࡖࠨ䗔"):l11ll1_l1_ (u"࠭ࡂࡰࡷࡹࡩࡹࠦࡉࡴ࡮ࡤࡲࡩ࠭䗕")
		,l11ll1_l1_ (u"ࠧࡃࡔࠪ䗖"):l11ll1_l1_ (u"ࠨࡄࡵࡥࡿ࡯࡬ࠨ䗗")
		,l11ll1_l1_ (u"ࠩࡌࡓࠬ䗘"):l11ll1_l1_ (u"ࠪࡆࡷ࡯ࡴࡪࡵ࡫ࠤࡎࡴࡤࡪࡣࡱࠤࡔࡩࡥࡢࡰࠣࡘࡪࡸࡲࡪࡶࡲࡶࡾ࠭䗙")
		,l11ll1_l1_ (u"࡛ࠫࡍࠧ䗚"):l11ll1_l1_ (u"ࠬࡈࡲࡪࡶ࡬ࡷ࡭ࠦࡖࡪࡴࡪ࡭ࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䗛")
		,l11ll1_l1_ (u"࠭ࡂࡏࠩ䗜"):l11ll1_l1_ (u"ࠧࡃࡴࡸࡲࡪ࡯ࠧ䗝")
		,l11ll1_l1_ (u"ࠨࡄࡊࠫ䗞"):l11ll1_l1_ (u"ࠩࡅࡹࡱ࡭ࡡࡳ࡫ࡤࠫ䗟")
		,l11ll1_l1_ (u"ࠪࡆࡋ࠭䗠"):l11ll1_l1_ (u"ࠫࡇࡻࡲ࡬࡫ࡱࡥࠥࡌࡡࡴࡱࠪ䗡")
		,l11ll1_l1_ (u"ࠬࡈࡉࠨ䗢"):l11ll1_l1_ (u"࠭ࡂࡶࡴࡸࡲࡩ࡯ࠧ䗣")
		,l11ll1_l1_ (u"ࠧࡌࡊࠪ䗤"):l11ll1_l1_ (u"ࠨࡅࡤࡱࡧࡵࡤࡪࡣࠪ䗥")
		,l11ll1_l1_ (u"ࠩࡆࡑࠬ䗦"):l11ll1_l1_ (u"ࠪࡇࡦࡳࡥࡳࡱࡲࡲࠬ䗧")
		,l11ll1_l1_ (u"ࠫࡈࡇࠧ䗨"):l11ll1_l1_ (u"ࠬࡉࡡ࡯ࡣࡧࡥࠬ䗩")
		,l11ll1_l1_ (u"࠭ࡃࡗࠩ䗪"):l11ll1_l1_ (u"ࠧࡄࡣࡳࡩࠥ࡜ࡥࡳࡦࡨࠫ䗫")
		,l11ll1_l1_ (u"ࠨࡍ࡜ࠫ䗬"):l11ll1_l1_ (u"ࠩࡆࡥࡾࡳࡡ࡯ࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ䗭")
		,l11ll1_l1_ (u"ࠪࡇࡋ࠭䗮"):l11ll1_l1_ (u"ࠫࡈ࡫࡮ࡵࡴࡤࡰࠥࡇࡦࡳ࡫ࡦࡥࡳࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠨ䗯")
		,l11ll1_l1_ (u"࡚ࠬࡄࠨ䗰"):l11ll1_l1_ (u"࠭ࡃࡩࡣࡧࠫ䗱")
		,l11ll1_l1_ (u"ࠧࡄࡎࠪ䗲"):l11ll1_l1_ (u"ࠨࡅ࡫࡭ࡱ࡫ࠧ䗳")
		,l11ll1_l1_ (u"ࠩࡆࡒࠬ䗴"):l11ll1_l1_ (u"ࠪࡇ࡭࡯࡮ࡢࠩ䗵")
		,l11ll1_l1_ (u"ࠫࡈ࡞ࠧ䗶"):l11ll1_l1_ (u"ࠬࡉࡨࡳ࡫ࡶࡸࡲࡧࡳࠡࡋࡶࡰࡦࡴࡤࠨ䗷")
		,l11ll1_l1_ (u"࠭ࡃࡄࠩ䗸"):l11ll1_l1_ (u"ࠧࡄࡱࡦࡳࡸࠦࠨࡌࡧࡨࡰ࡮ࡴࡧࠪࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ䗹")
		,l11ll1_l1_ (u"ࠨࡅࡒࠫ䗺"):l11ll1_l1_ (u"ࠩࡆࡳࡱࡵ࡭ࡣ࡫ࡤࠫ䗻")
		,l11ll1_l1_ (u"ࠪࡏࡒ࠭䗼"):l11ll1_l1_ (u"ࠫࡈࡵ࡭ࡰࡴࡲࡷࠬ䗽")
		,l11ll1_l1_ (u"ࠬࡉࡋࠨ䗾"):l11ll1_l1_ (u"࠭ࡃࡰࡱ࡮ࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䗿")
		,l11ll1_l1_ (u"ࠧࡄࡔࠪ䘀"):l11ll1_l1_ (u"ࠨࡅࡲࡷࡹࡧࠠࡓ࡫ࡦࡥࠬ䘁")
		,l11ll1_l1_ (u"ࠩࡋࡖࠬ䘂"):l11ll1_l1_ (u"ࠪࡇࡷࡵࡡࡵ࡫ࡤࠫ䘃")
		,l11ll1_l1_ (u"ࠫࡈ࡛ࠧ䘄"):l11ll1_l1_ (u"ࠬࡉࡵࡣࡣࠪ䘅")
		,l11ll1_l1_ (u"࠭ࡃࡘࠩ䘆"):l11ll1_l1_ (u"ࠧࡄࡷࡵࡥࡨࡧ࡯ࠨ䘇")
		,l11ll1_l1_ (u"ࠨࡅ࡜ࠫ䘈"):l11ll1_l1_ (u"ࠩࡆࡽࡵࡸࡵࡴࠩ䘉")
		,l11ll1_l1_ (u"ࠪࡇ࡟࠭䘊"):l11ll1_l1_ (u"ࠫࡈࢀࡥࡤࡪࠣࡖࡪࡶࡵࡣ࡮࡬ࡧࠬ䘋")
		,l11ll1_l1_ (u"ࠬࡉࡄࠨ䘌"):l11ll1_l1_ (u"࠭ࡄࡦ࡯ࡲࡧࡷࡧࡴࡪࡥࠣࡖࡪࡶࡵࡣ࡮࡬ࡧࠥࡵࡦࠡࡶ࡫ࡩࠥࡉ࡯࡯ࡩࡲࠫ䘍")
		,l11ll1_l1_ (u"ࠧࡅࡍࠪ䘎"):l11ll1_l1_ (u"ࠨࡆࡨࡲࡲࡧࡲ࡬ࠩ䘏")
		,l11ll1_l1_ (u"ࠩࡇࡎࠬ䘐"):l11ll1_l1_ (u"ࠪࡈ࡯࡯ࡢࡰࡷࡷ࡭ࠬ䘑")
		,l11ll1_l1_ (u"ࠫࡉࡓࠧ䘒"):l11ll1_l1_ (u"ࠬࡊ࡯࡮࡫ࡱ࡭ࡨࡧࠧ䘓")
		,l11ll1_l1_ (u"࠭ࡄࡐࠩ䘔"):l11ll1_l1_ (u"ࠧࡅࡱࡰ࡭ࡳ࡯ࡣࡢࡰࠣࡖࡪࡶࡵࡣ࡮࡬ࡧࠬ䘕")
		,l11ll1_l1_ (u"ࠨࡖࡏࠫ䘖"):l11ll1_l1_ (u"ࠩࡈࡥࡸࡺࠠࡕ࡫ࡰࡳࡷ࠭䘗")
		,l11ll1_l1_ (u"ࠪࡉࡈ࠭䘘"):l11ll1_l1_ (u"ࠫࡊࡩࡵࡢࡦࡲࡶࠬ䘙")
		,l11ll1_l1_ (u"ࠬࡋࡇࠨ䘚"):l11ll1_l1_ (u"࠭ࡅࡨࡻࡳࡸࠬ䘛")
		,l11ll1_l1_ (u"ࠧࡔࡘࠪ䘜"):l11ll1_l1_ (u"ࠨࡇ࡯ࠤࡘࡧ࡬ࡷࡣࡧࡳࡷ࠭䘝")
		,l11ll1_l1_ (u"ࠩࡊࡕࠬ䘞"):l11ll1_l1_ (u"ࠪࡉࡶࡻࡡࡵࡱࡵ࡭ࡦࡲࠠࡈࡷ࡬ࡲࡪࡧࠧ䘟")
		,l11ll1_l1_ (u"ࠫࡊࡘࠧ䘠"):l11ll1_l1_ (u"ࠬࡋࡲࡪࡶࡵࡩࡦ࠭䘡")
		,l11ll1_l1_ (u"࠭ࡅࡆࠩ䘢"):l11ll1_l1_ (u"ࠧࡆࡵࡷࡳࡳ࡯ࡡࠨ䘣")
		,l11ll1_l1_ (u"ࠨࡇࡗࠫ䘤"):l11ll1_l1_ (u"ࠩࡈࡸ࡭࡯࡯ࡱ࡫ࡤࠫ䘥")
		,l11ll1_l1_ (u"ࠪࡊࡐ࠭䘦"):l11ll1_l1_ (u"ࠫࡋࡧ࡬࡬࡮ࡤࡲࡩࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䘧")
		,l11ll1_l1_ (u"ࠬࡌࡏࠨ䘨"):l11ll1_l1_ (u"࠭ࡆࡢࡴࡲࡩࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䘩")
		,l11ll1_l1_ (u"ࠧࡇࡌࠪ䘪"):l11ll1_l1_ (u"ࠨࡈ࡬࡮࡮࠭䘫")
		,l11ll1_l1_ (u"ࠩࡉࡍࠬ䘬"):l11ll1_l1_ (u"ࠪࡊ࡮ࡴ࡬ࡢࡰࡧࠫ䘭")
		,l11ll1_l1_ (u"ࠫࡋࡘࠧ䘮"):l11ll1_l1_ (u"ࠬࡌࡲࡢࡰࡦࡩࠬ䘯")
		,l11ll1_l1_ (u"࠭ࡇࡇࠩ䘰"):l11ll1_l1_ (u"ࠧࡇࡴࡨࡲࡨ࡮ࠠࡈࡷ࡬ࡥࡳࡧࠧ䘱")
		,l11ll1_l1_ (u"ࠨࡒࡉࠫ䘲"):l11ll1_l1_ (u"ࠩࡉࡶࡪࡴࡣࡩࠢࡓࡳࡱࡿ࡮ࡦࡵ࡬ࡥࠬ䘳")
		,l11ll1_l1_ (u"ࠪࡘࡋ࠭䘴"):l11ll1_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡘࡵࡵࡵࡪࡨࡶࡳࠦࡔࡦࡴࡵ࡭ࡹࡵࡲࡪࡧࡶࠫ䘵")
		,l11ll1_l1_ (u"ࠬࡍࡁࠨ䘶"):l11ll1_l1_ (u"࠭ࡇࡢࡤࡲࡲࠬ䘷")
		,l11ll1_l1_ (u"ࠧࡈࡏࠪ䘸"):l11ll1_l1_ (u"ࠨࡉࡤࡱࡧ࡯ࡡࠨ䘹")
		,l11ll1_l1_ (u"ࠩࡊࡉࠬ䘺"):l11ll1_l1_ (u"ࠪࡋࡪࡵࡲࡨ࡫ࡤࠫ䘻")
		,l11ll1_l1_ (u"ࠫࡉࡋࠧ䘼"):l11ll1_l1_ (u"ࠬࡍࡥࡳ࡯ࡤࡲࡾ࠭䘽")
		,l11ll1_l1_ (u"࠭ࡇࡉࠩ䘾"):l11ll1_l1_ (u"ࠧࡈࡪࡤࡲࡦ࠭䘿")
		,l11ll1_l1_ (u"ࠨࡉࡌࠫ䙀"):l11ll1_l1_ (u"ࠩࡊ࡭ࡧࡸࡡ࡭ࡶࡤࡶࠬ䙁")
		,l11ll1_l1_ (u"ࠪࡋࡗ࠭䙂"):l11ll1_l1_ (u"ࠫࡌࡸࡥࡦࡥࡨࠫ䙃")
		,l11ll1_l1_ (u"ࠬࡍࡌࠨ䙄"):l11ll1_l1_ (u"࠭ࡇࡳࡧࡨࡲࡱࡧ࡮ࡥࠩ䙅")
		,l11ll1_l1_ (u"ࠧࡈࡆࠪ䙆"):l11ll1_l1_ (u"ࠨࡉࡵࡩࡳࡧࡤࡢࠩ䙇")
		,l11ll1_l1_ (u"ࠩࡊࡔࠬ䙈"):l11ll1_l1_ (u"ࠪࡋࡺࡧࡤࡦ࡮ࡲࡹࡵ࡫ࠧ䙉")
		,l11ll1_l1_ (u"ࠫࡌ࡛ࠧ䙊"):l11ll1_l1_ (u"ࠬࡍࡵࡢ࡯ࠪ䙋")
		,l11ll1_l1_ (u"࠭ࡇࡕࠩ䙌"):l11ll1_l1_ (u"ࠧࡈࡷࡤࡸࡪࡳࡡ࡭ࡣࠪ䙍")
		,l11ll1_l1_ (u"ࠨࡉࡊࠫ䙎"):l11ll1_l1_ (u"ࠩࡊࡹࡪࡸ࡮ࡴࡧࡼࠫ䙏")
		,l11ll1_l1_ (u"ࠪࡋࡓ࠭䙐"):l11ll1_l1_ (u"ࠫࡌࡻࡩ࡯ࡧࡤࠫ䙑")
		,l11ll1_l1_ (u"ࠬࡍࡗࠨ䙒"):l11ll1_l1_ (u"࠭ࡇࡶ࡫ࡱࡩࡦ࠳ࡂࡪࡵࡶࡥࡺ࠭䙓")
		,l11ll1_l1_ (u"ࠧࡈ࡛ࠪ䙔"):l11ll1_l1_ (u"ࠨࡉࡸࡽࡦࡴࡡࠨ䙕")
		,l11ll1_l1_ (u"ࠩࡋࡘࠬ䙖"):l11ll1_l1_ (u"ࠪࡌࡦ࡯ࡴࡪࠩ䙗")
		,l11ll1_l1_ (u"ࠫࡍࡓࠧ䙘"):l11ll1_l1_ (u"ࠬࡎࡥࡢࡴࡧࠤࡎࡹ࡬ࡢࡰࡧࠤࡦࡴࡤࠡࡏࡦࡈࡴࡴࡡ࡭ࡦࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䙙")
		,l11ll1_l1_ (u"࠭ࡈࡏࠩ䙚"):l11ll1_l1_ (u"ࠧࡉࡱࡱࡨࡺࡸࡡࡴࠩ䙛")
		,l11ll1_l1_ (u"ࠨࡊࡎࠫ䙜"):l11ll1_l1_ (u"ࠩࡋࡳࡳ࡭ࠠࡌࡱࡱ࡫ࠬ䙝")
		,l11ll1_l1_ (u"ࠪࡌ࡚࠭䙞"):l11ll1_l1_ (u"ࠫࡍࡻ࡮ࡨࡣࡵࡽࠬ䙟")
		,l11ll1_l1_ (u"ࠬࡏࡓࠨ䙠"):l11ll1_l1_ (u"࠭ࡉࡤࡧ࡯ࡥࡳࡪࠧ䙡")
		,l11ll1_l1_ (u"ࠧࡊࡐࠪ䙢"):l11ll1_l1_ (u"ࠨࡋࡱࡨ࡮ࡧࠧ䙣")
		,l11ll1_l1_ (u"ࠩࡌࡈࠬ䙤"):l11ll1_l1_ (u"ࠪࡍࡳࡪ࡯࡯ࡧࡶ࡭ࡦ࠭䙥")
		,l11ll1_l1_ (u"ࠫࡎࡘࠧ䙦"):l11ll1_l1_ (u"ࠬࡏࡲࡢࡰࠪ䙧")
		,l11ll1_l1_ (u"࠭ࡉࡒࠩ䙨"):l11ll1_l1_ (u"ࠧࡊࡴࡤࡵࠬ䙩")
		,l11ll1_l1_ (u"ࠨࡋࡈࠫ䙪"):l11ll1_l1_ (u"ࠩࡌࡶࡪࡲࡡ࡯ࡦࠪ䙫")
		,l11ll1_l1_ (u"ࠪࡍࡒ࠭䙬"):l11ll1_l1_ (u"ࠫࡎࡹ࡬ࡦࠢࡲࡪࠥࡓࡡ࡯ࠩ䙭")
		,l11ll1_l1_ (u"ࠬࡏࡌࠨ䙮"):l11ll1_l1_ (u"࠭ࡉࡴࡴࡤࡩࡱ࠭䙯")
		,l11ll1_l1_ (u"ࠧࡊࡖࠪ䙰"):l11ll1_l1_ (u"ࠨࡋࡷࡥࡱࡿࠧ䙱")
		,l11ll1_l1_ (u"ࠩࡆࡍࠬ䙲"):l11ll1_l1_ (u"ࠪࡍࡻࡵࡲࡺࠢࡆࡳࡦࡹࡴࠨ䙳")
		,l11ll1_l1_ (u"ࠫࡏࡓࠧ䙴"):l11ll1_l1_ (u"ࠬࡐࡡ࡮ࡣ࡬ࡧࡦ࠭䙵")
		,l11ll1_l1_ (u"࠭ࡊࡑࠩ䙶"):l11ll1_l1_ (u"ࠧࡋࡣࡳࡥࡳ࠭䙷")
		,l11ll1_l1_ (u"ࠨࡌࡈࠫ䙸"):l11ll1_l1_ (u"ࠩࡍࡩࡷࡹࡥࡺࠩ䙹")
		,l11ll1_l1_ (u"ࠪࡎࡔ࠭䙺"):l11ll1_l1_ (u"ࠫࡏࡵࡲࡥࡣࡱࠫ䙻")
		,l11ll1_l1_ (u"ࠬࡑ࡚ࠨ䙼"):l11ll1_l1_ (u"࠭ࡋࡢࡼࡤ࡯࡭ࡹࡴࡢࡰࠪ䙽")
		,l11ll1_l1_ (u"ࠧࡌࡇࠪ䙾"):l11ll1_l1_ (u"ࠨࡍࡨࡲࡾࡧࠧ䙿")
		,l11ll1_l1_ (u"ࠩࡎࡍࠬ䚀"):l11ll1_l1_ (u"ࠪࡏ࡮ࡸࡩࡣࡣࡷ࡭ࠬ䚁")
		,l11ll1_l1_ (u"ࠫ࡝ࡑࠧ䚂"):l11ll1_l1_ (u"ࠬࡑ࡯ࡴࡱࡹࡳࠬ䚃")
		,l11ll1_l1_ (u"࠭ࡋࡘࠩ䚄"):l11ll1_l1_ (u"ࠧࡌࡷࡺࡥ࡮ࡺࠧ䚅")
		,l11ll1_l1_ (u"ࠨࡍࡊࠫ䚆"):l11ll1_l1_ (u"ࠩࡎࡽࡷ࡭ࡹࡻࡵࡷࡥࡳ࠭䚇")
		,l11ll1_l1_ (u"ࠪࡐࡆ࠭䚈"):l11ll1_l1_ (u"ࠫࡑࡧ࡯ࡴࠩ䚉")
		,l11ll1_l1_ (u"ࠬࡒࡖࠨ䚊"):l11ll1_l1_ (u"࠭ࡌࡢࡶࡹ࡭ࡦ࠭䚋")
		,l11ll1_l1_ (u"ࠧࡍࡄࠪ䚌"):l11ll1_l1_ (u"ࠨࡎࡨࡦࡦࡴ࡯࡯ࠩ䚍")
		,l11ll1_l1_ (u"ࠩࡏࡗࠬ䚎"):l11ll1_l1_ (u"ࠪࡐࡪࡹ࡯ࡵࡪࡲࠫ䚏")
		,l11ll1_l1_ (u"ࠫࡑࡘࠧ䚐"):l11ll1_l1_ (u"ࠬࡒࡩࡣࡧࡵ࡭ࡦ࠭䚑")
		,l11ll1_l1_ (u"࠭ࡌ࡚ࠩ䚒"):l11ll1_l1_ (u"ࠧࡍ࡫ࡥࡽࡦ࠭䚓")
		,l11ll1_l1_ (u"ࠨࡎࡌࠫ䚔"):l11ll1_l1_ (u"ࠩࡏ࡭ࡪࡩࡨࡵࡧࡱࡷࡹ࡫ࡩ࡯ࠩ䚕")
		,l11ll1_l1_ (u"ࠪࡐ࡙࠭䚖"):l11ll1_l1_ (u"ࠫࡑ࡯ࡴࡩࡷࡤࡲ࡮ࡧࠧ䚗")
		,l11ll1_l1_ (u"ࠬࡒࡕࠨ䚘"):l11ll1_l1_ (u"࠭ࡌࡶࡺࡨࡱࡧࡵࡵࡳࡩࠪ䚙")
		,l11ll1_l1_ (u"ࠧࡎࡑࠪ䚚"):l11ll1_l1_ (u"ࠨࡏࡤࡧࡦࡵࠧ䚛")
		,l11ll1_l1_ (u"ࠩࡐࡋࠬ䚜"):l11ll1_l1_ (u"ࠪࡑࡦࡪࡡࡨࡣࡶࡧࡦࡸࠧ䚝")
		,l11ll1_l1_ (u"ࠫࡒ࡝ࠧ䚞"):l11ll1_l1_ (u"ࠬࡓࡡ࡭ࡣࡺ࡭ࠬ䚟")
		,l11ll1_l1_ (u"࠭ࡍ࡚ࠩ䚠"):l11ll1_l1_ (u"ࠧࡎࡣ࡯ࡥࡾࡹࡩࡢࠩ䚡")
		,l11ll1_l1_ (u"ࠨࡏ࡙ࠫ䚢"):l11ll1_l1_ (u"ࠩࡐࡥࡱࡪࡩࡷࡧࡶࠫ䚣")
		,l11ll1_l1_ (u"ࠪࡑࡑ࠭䚤"):l11ll1_l1_ (u"ࠫࡒࡧ࡬ࡪࠩ䚥")
		,l11ll1_l1_ (u"ࠬࡓࡔࠨ䚦"):l11ll1_l1_ (u"࠭ࡍࡢ࡮ࡷࡥࠬ䚧")
		,l11ll1_l1_ (u"ࠧࡎࡊࠪ䚨"):l11ll1_l1_ (u"ࠨࡏࡤࡶࡸ࡮ࡡ࡭࡮ࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䚩")
		,l11ll1_l1_ (u"ࠩࡐࡕࠬ䚪"):l11ll1_l1_ (u"ࠪࡑࡦࡸࡴࡪࡰ࡬ࡵࡺ࡫ࠧ䚫")
		,l11ll1_l1_ (u"ࠫࡒࡘࠧ䚬"):l11ll1_l1_ (u"ࠬࡓࡡࡶࡴ࡬ࡸࡦࡴࡩࡢࠩ䚭")
		,l11ll1_l1_ (u"࠭ࡍࡖࠩ䚮"):l11ll1_l1_ (u"ࠧࡎࡣࡸࡶ࡮ࡺࡩࡶࡵࠪ䚯")
		,l11ll1_l1_ (u"ࠨ࡛ࡗࠫ䚰"):l11ll1_l1_ (u"ࠩࡐࡥࡾࡵࡴࡵࡧࠪ䚱")
		,l11ll1_l1_ (u"ࠪࡑ࡝࠭䚲"):l11ll1_l1_ (u"ࠫࡒ࡫ࡸࡪࡥࡲࠫ䚳")
		,l11ll1_l1_ (u"ࠬࡌࡍࠨ䚴"):l11ll1_l1_ (u"࠭ࡍࡪࡥࡵࡳࡳ࡫ࡳࡪࡣࠪ䚵")
		,l11ll1_l1_ (u"ࠧࡎࡆࠪ䚶"):l11ll1_l1_ (u"ࠨࡏࡲࡰࡩࡵࡶࡢࠩ䚷")
		,l11ll1_l1_ (u"ࠩࡐࡇࠬ䚸"):l11ll1_l1_ (u"ࠪࡑࡴࡴࡡࡤࡱࠪ䚹")
		,l11ll1_l1_ (u"ࠫࡒࡔࠧ䚺"):l11ll1_l1_ (u"ࠬࡓ࡯࡯ࡩࡲࡰ࡮ࡧࠧ䚻")
		,l11ll1_l1_ (u"࠭ࡍࡆࠩ䚼"):l11ll1_l1_ (u"ࠧࡎࡱࡱࡸࡪࡴࡥࡨࡴࡲࠫ䚽")
		,l11ll1_l1_ (u"ࠨࡏࡖࠫ䚾"):l11ll1_l1_ (u"ࠩࡐࡳࡳࡺࡳࡦࡴࡵࡥࡹ࠭䚿")
		,l11ll1_l1_ (u"ࠪࡑࡆ࠭䛀"):l11ll1_l1_ (u"ࠫࡒࡵࡲࡰࡥࡦࡳࠬ䛁")
		,l11ll1_l1_ (u"ࠬࡓ࡚ࠨ䛂"):l11ll1_l1_ (u"࠭ࡍࡰࡼࡤࡱࡧ࡯ࡱࡶࡧࠪ䛃")
		,l11ll1_l1_ (u"ࠧࡎࡏࠪ䛄"):l11ll1_l1_ (u"ࠨࡏࡼࡥࡳࡳࡡࡳࠢࠫࡆࡺࡸ࡭ࡢࠫࠪ䛅")
		,l11ll1_l1_ (u"ࠩࡑࡅࠬ䛆"):l11ll1_l1_ (u"ࠪࡒࡦࡳࡩࡣ࡫ࡤࠫ䛇")
		,l11ll1_l1_ (u"ࠫࡓࡘࠧ䛈"):l11ll1_l1_ (u"ࠬࡔࡡࡶࡴࡸࠫ䛉")
		,l11ll1_l1_ (u"࠭ࡎࡑࠩ䛊"):l11ll1_l1_ (u"ࠧࡏࡧࡳࡥࡱ࠭䛋")
		,l11ll1_l1_ (u"ࠨࡐࡏࠫ䛌"):l11ll1_l1_ (u"ࠩࡑࡩࡹ࡮ࡥࡳ࡮ࡤࡲࡩࡹࠧ䛍")
		,l11ll1_l1_ (u"ࠪࡒࡈ࠭䛎"):l11ll1_l1_ (u"ࠫࡓ࡫ࡷࠡࡅࡤࡰࡪࡪ࡯࡯࡫ࡤࠫ䛏")
		,l11ll1_l1_ (u"ࠬࡔ࡚ࠨ䛐"):l11ll1_l1_ (u"࠭ࡎࡦࡹࠣ࡞ࡪࡧ࡬ࡢࡰࡧࠫ䛑")
		,l11ll1_l1_ (u"ࠧࡏࡋࠪ䛒"):l11ll1_l1_ (u"ࠨࡐ࡬ࡧࡦࡸࡡࡨࡷࡤࠫ䛓")
		,l11ll1_l1_ (u"ࠩࡑࡉࠬ䛔"):l11ll1_l1_ (u"ࠪࡒ࡮࡭ࡥࡳࠩ䛕")
		,l11ll1_l1_ (u"ࠫࡓࡍࠧ䛖"):l11ll1_l1_ (u"ࠬࡔࡩࡨࡧࡵ࡭ࡦ࠭䛗")
		,l11ll1_l1_ (u"࠭ࡎࡖࠩ䛘"):l11ll1_l1_ (u"ࠧࡏ࡫ࡸࡩࠬ䛙")
		,l11ll1_l1_ (u"ࠨࡐࡉࠫ䛚"):l11ll1_l1_ (u"ࠩࡑࡳࡷ࡬࡯࡭࡭ࠣࡍࡸࡲࡡ࡯ࡦࠪ䛛")
		,l11ll1_l1_ (u"ࠪࡏࡕ࠭䛜"):l11ll1_l1_ (u"ࠫࡓࡵࡲࡵࡪࠣࡏࡴࡸࡥࡢࠩ䛝")
		,l11ll1_l1_ (u"ࠬࡓࡋࠨ䛞"):l11ll1_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ䛟")
		,l11ll1_l1_ (u"ࠧࡎࡒࠪ䛠"):l11ll1_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࡥࡳࡰࠣࡑࡦࡸࡩࡢࡰࡤࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䛡")
		,l11ll1_l1_ (u"ࠩࡑࡓࠬ䛢"):l11ll1_l1_ (u"ࠪࡒࡴࡸࡷࡢࡻࠪ䛣")
		,l11ll1_l1_ (u"ࠫࡔࡓࠧ䛤"):l11ll1_l1_ (u"ࠬࡕ࡭ࡢࡰࠪ䛥")
		,l11ll1_l1_ (u"࠭ࡐࡌࠩ䛦"):l11ll1_l1_ (u"ࠧࡑࡣ࡮࡭ࡸࡺࡡ࡯ࠩ䛧")
		,l11ll1_l1_ (u"ࠨࡒ࡚ࠫ䛨"):l11ll1_l1_ (u"ࠩࡓࡥࡱࡧࡵࠨ䛩")
		,l11ll1_l1_ (u"ࠪࡔࡘ࠭䛪"):l11ll1_l1_ (u"ࠫࡕࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧ䛫")
		,l11ll1_l1_ (u"ࠬࡖࡁࠨ䛬"):l11ll1_l1_ (u"࠭ࡐࡢࡰࡤࡱࡦ࠭䛭")
		,l11ll1_l1_ (u"ࠧࡑࡉࠪ䛮"):l11ll1_l1_ (u"ࠨࡒࡤࡴࡺࡧࠠࡏࡧࡺࠤࡌࡻࡩ࡯ࡧࡤࠫ䛯")
		,l11ll1_l1_ (u"ࠩࡓ࡝ࠬ䛰"):l11ll1_l1_ (u"ࠪࡔࡦࡸࡡࡨࡷࡤࡽࠬ䛱")
		,l11ll1_l1_ (u"ࠫࡕࡋࠧ䛲"):l11ll1_l1_ (u"ࠬࡖࡥࡳࡷࠪ䛳")
		,l11ll1_l1_ (u"࠭ࡐࡉࠩ䛴"):l11ll1_l1_ (u"ࠧࡑࡪ࡬ࡰ࡮ࡶࡰࡪࡰࡨࡷࠬ䛵")
		,l11ll1_l1_ (u"ࠨࡒࡑࠫ䛶"):l11ll1_l1_ (u"ࠩࡓ࡭ࡹࡩࡡࡪࡴࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䛷")
		,l11ll1_l1_ (u"ࠪࡔࡑ࠭䛸"):l11ll1_l1_ (u"ࠫࡕࡵ࡬ࡢࡰࡧࠫ䛹")
		,l11ll1_l1_ (u"ࠬࡖࡔࠨ䛺"):l11ll1_l1_ (u"࠭ࡐࡰࡴࡷࡹ࡬ࡧ࡬ࠨ䛻")
		,l11ll1_l1_ (u"ࠧࡑࡔࠪ䛼"):l11ll1_l1_ (u"ࠨࡒࡸࡩࡷࡺ࡯ࠡࡔ࡬ࡧࡴ࠭䛽")
		,l11ll1_l1_ (u"ࠩࡔࡅࠬ䛾"):l11ll1_l1_ (u"ࠪࡕࡦࡺࡡࡳࠩ䛿")
		,l11ll1_l1_ (u"ࠫࡈࡍࠧ䜀"):l11ll1_l1_ (u"ࠬࡘࡥࡱࡷࡥࡰ࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡄࡱࡱ࡫ࡴ࠭䜁")
		,l11ll1_l1_ (u"࠭ࡒࡐࠩ䜂"):l11ll1_l1_ (u"ࠧࡓࡱࡰࡥࡳ࡯ࡡࠨ䜃")
		,l11ll1_l1_ (u"ࠨࡔࡘࠫ䜄"):l11ll1_l1_ (u"ࠩࡕࡹࡸࡹࡩࡢࠩ䜅")
		,l11ll1_l1_ (u"ࠪࡖ࡜࠭䜆"):l11ll1_l1_ (u"ࠫࡗࡽࡡ࡯ࡦࡤࠫ䜇")
		,l11ll1_l1_ (u"ࠬࡘࡅࠨ䜈"):l11ll1_l1_ (u"࠭ࡒ࣪ࡷࡱ࡭ࡴࡴࠧ䜉")
		,l11ll1_l1_ (u"ࠧࡃࡎࠪ䜊"):l11ll1_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡃࡣࡵࡸ࡭࣯࡬ࡦ࡯ࡼࠫ䜋")
		,l11ll1_l1_ (u"ࠩࡖࡌࠬ䜌"):l11ll1_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡋࡩࡱ࡫࡮ࡢࠩ䜍")
		,l11ll1_l1_ (u"ࠫࡐࡔࠧ䜎"):l11ll1_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡐ࡯ࡴࡵࡵࠣࡥࡳࡪࠠࡏࡧࡹ࡭ࡸ࠭䜏")
		,l11ll1_l1_ (u"࠭ࡌࡄࠩ䜐"):l11ll1_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡌࡶࡥ࡬ࡥࠬ䜑")
		,l11ll1_l1_ (u"ࠨࡏࡉࠫ䜒"):l11ll1_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡏࡤࡶࡹ࡯࡮ࠨ䜓")
		,l11ll1_l1_ (u"ࠪࡔࡒ࠭䜔"):l11ll1_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡔ࡮࡫ࡲࡳࡧࠣࡥࡳࡪࠠࡎ࡫ࡴࡹࡪࡲ࡯࡯ࠩ䜕")
		,l11ll1_l1_ (u"ࠬ࡜ࡃࠨ䜖"):l11ll1_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥ࡜ࡩ࡯ࡥࡨࡲࡹࠦࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡈࡴࡨࡲࡦࡪࡩ࡯ࡧࡶࠫ䜗")
		,l11ll1_l1_ (u"ࠧࡘࡕࠪ䜘"):l11ll1_l1_ (u"ࠨࡕࡤࡱࡴࡧࠧ䜙")
		,l11ll1_l1_ (u"ࠩࡖࡑࠬ䜚"):l11ll1_l1_ (u"ࠪࡗࡦࡴࠠࡎࡣࡵ࡭ࡳࡵࠧ䜛")
		,l11ll1_l1_ (u"ࠫࡘࡇࠧ䜜"):l11ll1_l1_ (u"࡙ࠬࡡࡶࡦ࡬ࠤࡆࡸࡡࡣ࡫ࡤࠫ䜝")
		,l11ll1_l1_ (u"࠭ࡓࡏࠩ䜞"):l11ll1_l1_ (u"ࠧࡔࡧࡱࡩ࡬ࡧ࡬ࠨ䜟")
		,l11ll1_l1_ (u"ࠨࡔࡖࠫ䜠"):l11ll1_l1_ (u"ࠩࡖࡩࡷࡨࡩࡢࠩ䜡")
		,l11ll1_l1_ (u"ࠪࡗࡈ࠭䜢"):l11ll1_l1_ (u"ࠫࡘ࡫ࡹࡤࡪࡨࡰࡱ࡫ࡳࠨ䜣")
		,l11ll1_l1_ (u"࡙ࠬࡌࠨ䜤"):l11ll1_l1_ (u"࠭ࡓࡪࡧࡵࡶࡦࠦࡌࡦࡱࡱࡩࠬ䜥")
		,l11ll1_l1_ (u"ࠧࡔࡉࠪ䜦"):l11ll1_l1_ (u"ࠨࡕ࡬ࡲ࡬ࡧࡰࡰࡴࡨࠫ䜧")
		,l11ll1_l1_ (u"ࠩࡖ࡜ࠬ䜨"):l11ll1_l1_ (u"ࠪࡗ࡮ࡴࡴࠡࡏࡤࡥࡷࡺࡥ࡯ࠩ䜩")
		,l11ll1_l1_ (u"ࠫࡘࡑࠧ䜪"):l11ll1_l1_ (u"࡙ࠬ࡬ࡰࡸࡤ࡯࡮ࡧࠧ䜫")
		,l11ll1_l1_ (u"࠭ࡓࡊࠩ䜬"):l11ll1_l1_ (u"ࠧࡔ࡮ࡲࡺࡪࡴࡩࡢࠩ䜭")
		,l11ll1_l1_ (u"ࠨࡕࡅࠫ䜮"):l11ll1_l1_ (u"ࠩࡖࡳࡱࡵ࡭ࡰࡰࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䜯")
		,l11ll1_l1_ (u"ࠪࡗࡔ࠭䜰"):l11ll1_l1_ (u"ࠫࡘࡵ࡭ࡢ࡮࡬ࡥࠬ䜱")
		,l11ll1_l1_ (u"ࠬࡠࡁࠨ䜲"):l11ll1_l1_ (u"࠭ࡓࡰࡷࡷ࡬ࠥࡇࡦࡳ࡫ࡦࡥࠬ䜳")
		,l11ll1_l1_ (u"ࠧࡈࡕࠪ䜴"):l11ll1_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡈࡧࡲࡶ࡬࡯ࡡࠡࡣࡱࡨࠥࡺࡨࡦࠢࡖࡳࡺࡺࡨࠡࡕࡤࡲࡩࡽࡩࡤࡪࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䜵")
		,l11ll1_l1_ (u"ࠩࡎࡖࠬ䜶"):l11ll1_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡎࡳࡷ࡫ࡡࠨ䜷")
		,l11ll1_l1_ (u"ࠫࡘ࡙ࠧ䜸"):l11ll1_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡘࡻࡤࡢࡰࠪ䜹")
		,l11ll1_l1_ (u"࠭ࡅࡔࠩ䜺"):l11ll1_l1_ (u"ࠧࡔࡲࡤ࡭ࡳ࠭䜻")
		,l11ll1_l1_ (u"ࠨࡎࡎࠫ䜼"):l11ll1_l1_ (u"ࠩࡖࡶ࡮ࠦࡌࡢࡰ࡮ࡥࠬ䜽")
		,l11ll1_l1_ (u"ࠪࡗࡉ࠭䜾"):l11ll1_l1_ (u"ࠫࡘࡻࡤࡢࡰࠪ䜿")
		,l11ll1_l1_ (u"࡙ࠬࡒࠨ䝀"):l11ll1_l1_ (u"࠭ࡓࡶࡴ࡬ࡲࡦࡳࡥࠨ䝁")
		,l11ll1_l1_ (u"ࠧࡔࡌࠪ䝂"):l11ll1_l1_ (u"ࠨࡕࡹࡥࡱࡨࡡࡳࡦࠣࡥࡳࡪࠠࡋࡣࡱࠤࡒࡧࡹࡦࡰࠪ䝃")
		,l11ll1_l1_ (u"ࠩࡖ࡞ࠬ䝄"):l11ll1_l1_ (u"ࠪࡗࡼࡧࡺࡪ࡮ࡤࡲࡩ࠭䝅")
		,l11ll1_l1_ (u"ࠫࡘࡋࠧ䝆"):l11ll1_l1_ (u"࡙ࠬࡷࡦࡦࡨࡲࠬ䝇")
		,l11ll1_l1_ (u"࠭ࡃࡉࠩ䝈"):l11ll1_l1_ (u"ࠧࡔࡹ࡬ࡸࡿ࡫ࡲ࡭ࡣࡱࡨࠬ䝉")
		,l11ll1_l1_ (u"ࠨࡕ࡜ࠫ䝊"):l11ll1_l1_ (u"ࠩࡖࡽࡷ࡯ࡡࠨ䝋")
		,l11ll1_l1_ (u"ࠪࡗ࡙࠭䝌"):l11ll1_l1_ (u"ࠫࡘࣩ࡯ࠡࡖࡲࡱ࣮ࠦࡡ࡯ࡦࠣࡔࡷࣳ࡮ࡤ࡫ࡳࡩࠬ䝍")
		,l11ll1_l1_ (u"࡚ࠬࡗࠨ䝎"):l11ll1_l1_ (u"࠭ࡔࡢ࡫ࡺࡥࡳ࠭䝏")
		,l11ll1_l1_ (u"ࠧࡕࡌࠪ䝐"):l11ll1_l1_ (u"ࠨࡖࡤ࡮࡮ࡱࡩࡴࡶࡤࡲࠬ䝑")
		,l11ll1_l1_ (u"ࠩࡗ࡞ࠬ䝒"):l11ll1_l1_ (u"ࠪࡘࡦࡴࡺࡢࡰ࡬ࡥࠬ䝓")
		,l11ll1_l1_ (u"࡙ࠫࡎࠧ䝔"):l11ll1_l1_ (u"࡚ࠬࡨࡢ࡫࡯ࡥࡳࡪࠧ䝕")
		,l11ll1_l1_ (u"࠭ࡔࡈࠩ䝖"):l11ll1_l1_ (u"ࠧࡕࡱࡪࡳࠬ䝗")
		,l11ll1_l1_ (u"ࠨࡖࡎࠫ䝘"):l11ll1_l1_ (u"ࠩࡗࡳࡰ࡫࡬ࡢࡷࠪ䝙")
		,l11ll1_l1_ (u"ࠪࡘࡔ࠭䝚"):l11ll1_l1_ (u"࡙ࠫࡵ࡮ࡨࡣࠪ䝛")
		,l11ll1_l1_ (u"࡚ࠬࡔࠨ䝜"):l11ll1_l1_ (u"࠭ࡔࡳ࡫ࡱ࡭ࡩࡧࡤࠡࡣࡱࡨ࡚ࠥ࡯ࡣࡣࡪࡳࠬ䝝")
		,l11ll1_l1_ (u"ࠧࡕࡐࠪ䝞"):l11ll1_l1_ (u"ࠨࡖࡸࡲ࡮ࡹࡩࡢࠩ䝟")
		,l11ll1_l1_ (u"ࠩࡗࡖࠬ䝠"):l11ll1_l1_ (u"ࠪࡘࡺࡸ࡫ࡦࡻࠪ䝡")
		,l11ll1_l1_ (u"࡙ࠫࡓࠧ䝢"):l11ll1_l1_ (u"࡚ࠬࡵࡳ࡭ࡰࡩࡳ࡯ࡳࡵࡣࡱࠫ䝣")
		,l11ll1_l1_ (u"࠭ࡔࡄࠩ䝤"):l11ll1_l1_ (u"ࠧࡕࡷࡵ࡯ࡸࠦࡡ࡯ࡦࠣࡇࡦ࡯ࡣࡰࡵࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䝥")
		,l11ll1_l1_ (u"ࠨࡖ࡙ࠫ䝦"):l11ll1_l1_ (u"ࠩࡗࡹࡻࡧ࡬ࡶࠩ䝧")
		,l11ll1_l1_ (u"࡙ࠪࡒ࠭䝨"):l11ll1_l1_ (u"࡚ࠫ࠴ࡓ࠯ࠢࡐ࡭ࡳࡵࡲࠡࡑࡸࡸࡱࡿࡩ࡯ࡩࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ䝩")
		,l11ll1_l1_ (u"ࠬ࡜ࡉࠨ䝪"):l11ll1_l1_ (u"࠭ࡕ࠯ࡕ࠱ࠤ࡛࡯ࡲࡨ࡫ࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䝫")
		,l11ll1_l1_ (u"ࠧࡖࡉࠪ䝬"):l11ll1_l1_ (u"ࠨࡗࡪࡥࡳࡪࡡࠨ䝭")
		,l11ll1_l1_ (u"ࠩࡘࡅࠬ䝮"):l11ll1_l1_ (u"࡙ࠪࡰࡸࡡࡪࡰࡨࠫ䝯")
		,l11ll1_l1_ (u"ࠫࡆࡋࠧ䝰"):l11ll1_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ䝱")
		,l11ll1_l1_ (u"࠭ࡕࡌࠩ䝲"):l11ll1_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨ䝳")
		,l11ll1_l1_ (u"ࠨࡗࡖࠫ䝴"):l11ll1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩ䝵")
		,l11ll1_l1_ (u"࡙ࠪ࡞࠭䝶"):l11ll1_l1_ (u"࡚ࠫࡸࡵࡨࡷࡤࡽࠬ䝷")
		,l11ll1_l1_ (u"࡛࡚ࠬࠨ䝸"):l11ll1_l1_ (u"࠭ࡕࡻࡤࡨ࡯࡮ࡹࡴࡢࡰࠪ䝹")
		,l11ll1_l1_ (u"ࠧࡗࡗࠪ䝺"):l11ll1_l1_ (u"ࠨࡘࡤࡲࡺࡧࡴࡶࠩ䝻")
		,l11ll1_l1_ (u"࡙ࠩࡅࠬ䝼"):l11ll1_l1_ (u"࡚ࠪࡦࡺࡩࡤࡣࡱࠤࡈ࡯ࡴࡺࠩ䝽")
		,l11ll1_l1_ (u"࡛ࠫࡋࠧ䝾"):l11ll1_l1_ (u"ࠬ࡜ࡥ࡯ࡧࡽࡹࡪࡲࡡࠨ䝿")
		,l11ll1_l1_ (u"࠭ࡖࡏࠩ䞀"):l11ll1_l1_ (u"ࠧࡗ࡫ࡨࡸࡳࡧ࡭ࠨ䞁")
		,l11ll1_l1_ (u"ࠨ࡙ࡉࠫ䞂"):l11ll1_l1_ (u"࡚ࠩࡥࡱࡲࡩࡴࠢࡤࡲࡩࠦࡆࡶࡶࡸࡲࡦ࠭䞃")
		,l11ll1_l1_ (u"ࠪࡉࡍ࠭䞄"):l11ll1_l1_ (u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ䞅")
		,l11ll1_l1_ (u"ࠬ࡟ࡅࠨ䞆"):l11ll1_l1_ (u"࡙࠭ࡦ࡯ࡨࡲࠬ䞇")
		,l11ll1_l1_ (u"࡛ࠧࡏࠪ䞈"):l11ll1_l1_ (u"ࠨ࡜ࡤࡱࡧ࡯ࡡࠨ䞉")
		,l11ll1_l1_ (u"ࠩ࡝࡛ࠬ䞊"):l11ll1_l1_ (u"ࠪ࡞࡮ࡳࡢࡢࡤࡺࡩࠬ䞋")
		,l11ll1_l1_ (u"ࠫࡆ࡞ࠧ䞌"):l11ll1_l1_ (u"ࠬ࣋࡬ࡢࡰࡧࠫ䞍")
		}
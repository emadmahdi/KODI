﻿# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#import unicodedata,simplejson
def MAIN(mode,l1l1l1l111l_l1_):
	if l1l1l1l111l_l1_==l11ll1_l1_ (u"ࠫࠬㅟ"): return
	if mode==1:
		l1l1l1l1111_l1_ = xbmcgui.l1l1l11llll_l1_()
		l1l1l11lll1_l1_ = xbmcgui.l1l1l111ll1_l1_(l1l1l1l1111_l1_)
		l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		l1l1l11lll1_l1_.getControl(311).l1l1l1l11ll_l1_(l1l1l1l111l_l1_)
	if mode==0:
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ㅠ"))
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫㅡ"))
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㅢ"))
		l1l1l11l111_l1_=l11ll1_l1_ (u"ࠨ࡚ࠪㅣ")
		if kodi_version>18.99: check = isinstance(l1l1l1l111l_l1_,str)
		else: check = isinstance(l1l1l1l111l_l1_,unicode)
		if check==True: l1l1l11l111_l1_=l11ll1_l1_ (u"ࠩࡘࠫㅤ")
		l1l1l111lll_l1_=str(type(l1l1l1l111l_l1_))+l11ll1_l1_ (u"ࠪࠤࠬㅥ")+l1l1l1l111l_l1_+l11ll1_l1_ (u"ࠫࠥ࠭ㅦ")+l1l1l11l111_l1_+l11ll1_l1_ (u"ࠬࠦࠧㅧ")
		for i in range(0,len(l1l1l1l111l_l1_),1):
			l1l1l111lll_l1_ += hex(ord(l1l1l1l111l_l1_[i])).replace(l11ll1_l1_ (u"࠭࠰ࡹࠩㅨ"),l11ll1_l1_ (u"ࠧࠨㅩ"))+l11ll1_l1_ (u"ࠨࠢࠪㅪ")
		l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㅫ"))
		l1l1l11l111_l1_=l11ll1_l1_ (u"ࠪ࡜ࠬㅬ")
		if kodi_version>18.99: check = isinstance(l1l1l1l111l_l1_, str)
		else: check = isinstance(l1l1l1l111l_l1_, unicode)
		if check==True: l1l1l11l111_l1_=l11ll1_l1_ (u"࡚ࠫ࠭ㅭ")
		l1l1l11l11l_l1_=str(type(l1l1l1l111l_l1_))+l11ll1_l1_ (u"ࠬࠦࠧㅮ")+l1l1l1l111l_l1_+l11ll1_l1_ (u"࠭ࠠࠨㅯ")+l1l1l11l111_l1_+l11ll1_l1_ (u"ࠧࠡࠩㅰ")
		for i in range(0,len(l1l1l1l111l_l1_),1):
			l1l1l11l11l_l1_ += hex(ord(l1l1l1l111l_l1_[i])).replace(l11ll1_l1_ (u"ࠨ࠲ࡻࠫㅱ"),l11ll1_l1_ (u"ࠩࠪㅲ"))+l11ll1_l1_ (u"ࠪࠤࠬㅳ")
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬㅴ"),l11ll1_l1_ (u"ࠬ࠭ㅵ"),l1l1l111lll_l1_,l1l1l11l11l_l1_)
	return
	#for i in range(0,len(l1l1l1l111l_l1_)-2,3):
	#	string=hex(ord(l1l1l1l111l_l1_[i+0]))+l11ll1_l1_ (u"࠭ࠠࠡࠩㅶ")+hex(ord(l1l1l1l111l_l1_[i+1]))+l11ll1_l1_ (u"ࠧࠡࠢࠪㅷ")+hex(ord(l1l1l1l111l_l1_[i+2]))
	#	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㅸ"),l11ll1_l1_ (u"ࠩࠪㅹ"),l11ll1_l1_ (u"ࠪࠫㅺ"),string)
	#return
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㅻ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ㅼ"),l11ll1_l1_ (u"࠭ࠧㅽ"),l11ll1_l1_ (u"ࠧࠨㅾ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㅿ"))
	#l1l1l1l111l_l1_ = unicodedata.normalize(l11ll1_l1_ (u"ࠩࡑࡊࡐࡊࠧㆀ"),l1l1l1l111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㆁ"),l11ll1_l1_ (u"ࠫࠬㆂ"),l11ll1_l1_ (u"ࠬ࠭ㆃ"),   hex(  unicodedata.combining(l1l1l1l111l_l1_[0])  )   )
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧㆄ"),l11ll1_l1_ (u"ࠧࠨㆅ"),l1l1l1l111l_l1_,   hex(ord(  l1l1l1l111l_l1_[0]  ))   )
	#new = l11ll1_l1_ (u"ࠨࠩㆆ")
	#for l1l1l11l1ll_l1_ in l1l1l1l111l_l1_:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪㆇ"),l11ll1_l1_ (u"ࠪࠫㆈ"),l11ll1_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫㆉ"),unicodedata.decomposition(l1l1l11l1ll_l1_) )
	#	new += l11ll1_l1_ (u"ࠬࡢࡵ࠱ࠩㆊ") + hex(ord(l1l1l11l1ll_l1_)).replace(l11ll1_l1_ (u"࠭࠰ࡹࠩㆋ"),l11ll1_l1_ (u"ࠧࠨㆌ"))
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㆍ"),l11ll1_l1_ (u"ࠩࠪㆎ"),l11ll1_l1_ (u"ࠪࠫ㆏"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"ࠫࠬ㆐")
	#for i in range(len(l1l1l1l111l_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㆑"),l11ll1_l1_ (u"࠭ࠧ㆒"),l11ll1_l1_ (u"ࠧࠨ㆓"),str(i))
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1] + l1l1l1l111l_l1_[i+2] + l1l1l1l111l_l1_[i+3] + l1l1l1l111l_l1_[i+4] + l1l1l1l111l_l1_[i+5]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㆔"),l11ll1_l1_ (u"ࠩࠪ㆕"),l11ll1_l1_ (u"ࠪࠫ㆖"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㆗"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㆘"),l11ll1_l1_ (u"࠭ࠧ㆙"),l11ll1_l1_ (u"ࠧࠨ㆚"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㆛"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㆜"),l11ll1_l1_ (u"ࠪࠫ㆝"),l11ll1_l1_ (u"ࠫࠬ㆞"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l11ll1_l1_ (u"ࠬ࡫࡭ࡢࡦࠪ㆟")
	#l1l1l11ll11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠬㆠ")+l1l1l1l111l_l1_+l11ll1_l1_ (u"ࠧࠣ࠮ࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪㆡ"))
	#simplejson.loads(l1l1l11ll11_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㆢ"))
	#new = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪㆣ"))
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㆤ"),l11ll1_l1_ (u"ࠫࠬㆥ"),l11ll1_l1_ (u"ࠬ࠭ㆦ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧㆧ"),l11ll1_l1_ (u"ࠧࠨㆨ"),l11ll1_l1_ (u"ࠨࠩㆩ"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"ࠩࠪㆪ")
	#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㆫ"),l11ll1_l1_ (u"ࠫࠬㆬ"),l11ll1_l1_ (u"ࠬ࠭ㆭ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫㆮ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨㆯ"),l11ll1_l1_ (u"ࠨࠩㆰ"),l11ll1_l1_ (u"ࠩࠪㆱ"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"ࠪࠫㆲ")
	#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬㆳ"),l11ll1_l1_ (u"ࠬ࠭ㆴ"),l11ll1_l1_ (u"࠭ࠧㆵ"),l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.replace(l11ll1_l1_ (u"ࠧࠡࠩㆶ"),l11ll1_l1_ (u"ࠨࠩㆷ"))
		#new = l11ll1_l1_ (u"ࠩࠪㆸ")
		#for i in range(len(l1l1l1l111l_l1_)-3,-2,-3):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1] + l1l1l1l111l_l1_[i+2]
		#l1l1l1l111l_l1_ = new
		#new = l11ll1_l1_ (u"ࠪࠫㆹ")
		#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
		#l1l1l1l111l_l1_ = new
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬㆺ"),l11ll1_l1_ (u"ࠬ࠭ㆻ"),l11ll1_l1_ (u"࠭ࠧㆼ"),l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.l1l1l1l11l1_l1_(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㆽ"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㆾ"),l11ll1_l1_ (u"ࠩࠪㆿ"),str(ord(l1l1l1l111l_l1_[0]))+l11ll1_l1_ (u"ࠪࠤࠬ㇀")+str(ord(l1l1l1l111l_l1_[1]))+l11ll1_l1_ (u"ࠫࠥ࠭㇁")+str(ord(l1l1l1l111l_l1_[2])),str(len(l1l1l1l111l_l1_)))
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㇂"),l11ll1_l1_ (u"࠭ࠧ㇃"),l11ll1_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠠࡍࡧࡷࡸࡪࡸࡳࠨ㇄"),l1l1l1l111l_l1_)
		#new = l11ll1_l1_ (u"ࠨࠩ㇅")
		#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
		#l1l1l1l111l_l1_ = new
		#new = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㇆"))
		#new = new.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇇"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㇈"),l11ll1_l1_ (u"ࠬ࠭㇉"),l11ll1_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭㇊"),new )
		#l1l1l111lll_l1_ = l11ll1_l1_ (u"ࠧࠨ㇋")
		#for l1l1l11l1ll_l1_ in new:
		#	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㇌"),l11ll1_l1_ (u"ࠩࠪ㇍"),l11ll1_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㇎"),unicodedata.decomposition(l1l1l11l1ll_l1_) )
		#	l1l1l111lll_l1_ += l11ll1_l1_ (u"ࠫࡡࡻࠧ㇏") + hex(ord(l1l1l11l1ll_l1_)).replace(l11ll1_l1_ (u"ࠬࡾࠧ㇐"),l11ll1_l1_ (u"࠭ࠧ㇑"))
		#l1l1l111lll_l1_ = l1l1l111lll_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㇒"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㇓"),l11ll1_l1_ (u"ࠩࠪ㇔"),l11ll1_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㇕"),l1l1l111lll_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l1l11ll1l_l1_(new)
		#l1l1l1l111l_l1_ = new.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇖"))
		#new = new.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇗")) #.decode(l11ll1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㇘"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㇙"),l11ll1_l1_ (u"ࠨࠩ㇚"),l11ll1_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ㇛"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇜")))   )
		#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(new)
		#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		#method=l11ll1_l1_ (u"ࠦࡎࡴࡰࡶࡶ࠱ࡗࡪࡴࡤࡕࡧࡻࡸࠧ㇝")
		#params=l11ll1_l1_ (u"ࠬࢁࠢࡵࡧࡻࡸࠧࡀࠢࠦࡵࠥ࠰ࠥࠨࡤࡰࡰࡨࠦ࠿࡬ࡡ࡭ࡵࡨࢁࠬ㇞") % l1l1l1l111l_l1_
		#l1l1l11ll11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠤࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠠࠣࠧࡶࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࠢࠨࡷ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ㇟") % (method, params))
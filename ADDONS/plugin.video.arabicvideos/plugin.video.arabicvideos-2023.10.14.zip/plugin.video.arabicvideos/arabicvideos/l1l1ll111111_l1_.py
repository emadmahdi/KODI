# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ愎")
headers = l11ll1_l1_ (u"ࠫࠬ意") #{ l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ愐") : l11ll1_l1_ (u"࠭ࠧ愑") }
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭愒")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭愓"),l11ll1_l1_ (u"ࠩส่่๊ࠧ愔"),l11ll1_l1_ (u"ࠪหๆ๊วๆࠩ愕"),l11ll1_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ愖"),l11ll1_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ愗")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11111_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llll1l_l1_(url,True)
	elif mode==114: results = l1lll111_l1_(url,l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ愘")+text)
	elif mode==115: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ愙")+text)
	elif mode==116: results = l1llll1l_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1lll1_l1_(l11l1l_l1_,l11ll1_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ愚"),l11ll1_l1_ (u"ࠩืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤࠡ࠶ࡸࠫ愛"),l11ll1_l1_ (u"ࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪ愜"),headers)
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ愝"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ愞"),l11ll1_l1_ (u"࠭ࠧ感"),119,l11ll1_l1_ (u"ࠧࠨ愠"),l11ll1_l1_ (u"ࠨࠩ愡"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭愢"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愣"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ愤"),l1ll111_l1_,115)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ愥"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ愦"),l1ll111_l1_,114)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ愧"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ愨"),l11ll1_l1_ (u"ࠩࠪ愩"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愪"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ愫"),l1ll111_l1_,111,l11ll1_l1_ (u"ࠬ࠭愬"),l11ll1_l1_ (u"࠭ࠧ愭"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ愮"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥ࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠩ愯"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ愰"),l11ll1_l1_ (u"ࠪࠫ愱"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭愲"),l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ愳"))
		return
	else:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ愴"),block,re.DOTALL)
		for filter,l1lll1_l1_,title in items:
			url = l1ll111_l1_+filter
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ愵"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ愶")+l111l1_l1_+title,url,111,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ愷"),filter)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ愸"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ愹"),l11ll1_l1_ (u"ࠬ࠭愺"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ愻"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ愼"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ愽"),l11ll1_l1_ (u"ࠩࠪ愾")).replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭愿"),l11ll1_l1_ (u"ࠫࠬ慀")).strip(l11ll1_l1_ (u"ࠬࠦࠧ慁"))
			if title in l1l11l_l1_: continue
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ慂") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
			if l11ll1_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ慃") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ慄")
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ慅"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ慆")+l111l1_l1_+title,l1lllll_l1_,111)
	return html
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬ慇"),response=l11ll1_l1_ (u"ࠬ࠭慈")):
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ慉"):l11ll1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ慊")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ態"),url,l11ll1_l1_ (u"ࠩࠪ慌"),headers,l11ll1_l1_ (u"ࠪࠫ慍"),l11ll1_l1_ (u"ࠫࠬ慎"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ慏"))
	html = response.content
	l1l1l11_l1_,items,l11l_l1_ = [],[],[]
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ慐"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡨ࡮࡬ࡨࡪࡥ࡟ࡴ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ慑"),html,re.DOTALL)
	#elif l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ慒"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡐࡩࡩ࡯ࡡࡈࡴ࡬ࡨ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭慓"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷ࡭ࡵࡷࡴ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭慔"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	#if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ慕"): items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ慖"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭慗"),block,re.DOTALL)
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧ慘"),l11ll1_l1_ (u"ࠨใํ่๊࠭慙"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨ慚"),l11ll1_l1_ (u"ࠪ็้๐ศࠨ慛"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪ慜"),l11ll1_l1_ (u"ࠬํฯศใࠪ慝"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭慞"),l11ll1_l1_ (u"ฺࠧำูࠫ慟"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨ慠"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨ慡")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ慢") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭慣") in l1lllll_l1_: continue
		#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࠬࠣ࠱࠵࠻࠿ࠬ慤"),l11ll1_l1_ (u"࠭ࠦࠨ慥"))
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠧ࠰ࠩ慦"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ慧"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ慨"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠪๅ๏๊ๅࠨ慩") in l1lllll_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ慪"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠬอไฮๆๅอࠬ慫") in title and l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ慬") not in url:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭慭") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ慮"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ慯") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ慰"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭慱") in l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ慲") not in url:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ慳")
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ慴"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ慵") in url and l11ll1_l1_ (u"ࠩะ่็ฯࠧ慶") in title:
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ慷"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ慸"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ慹"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1lll1l1l1_l1_!=l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭慺"): items = re.findall(l11ll1_l1_ (u"ࠧࠩࡷࡳࡨࡦࡺࡥࡒࡷࡨࡶࡾ࠯࠮ࠫࡁࡁࠬ࠳࠱࠿ࠪ࠾ࠪ慻"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡯࡭ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ慼"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ慽"):
				title = title.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭慾"),l11ll1_l1_ (u"ࠫࠬ慿")).replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ憀"),l11ll1_l1_ (u"࠭ࠧ憁"))
				if l11ll1_l1_ (u"ࠧࡀࠩ憂") in url: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ憃")+title
				else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩ憄")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ憅"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ憆")+title,l1lllll_l1_,111,l11ll1_l1_ (u"ࠬ࠭憇"),l11ll1_l1_ (u"࠭ࠧ憈"),l1lll1l1l1_l1_)
	return
def l1llll1l_l1_(url,l1lll111111ll_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ憉"),url,l11ll1_l1_ (u"ࠨࠩ憊"),headers,l11ll1_l1_ (u"ࠩࠪ憋"),l11ll1_l1_ (u"ࠪࠫ憌"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ憍"))
	html = response.content
	# l1lll1l_l1_ & l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠤࡩ࠳ࡦ࡭ࡧࡻࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ憎"),html,re.DOTALL)
	if len(l1l1l11_l1_)>1:
		if l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ憏") in l1l1l11_l1_[0]: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[1]
		else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[1],l1l1l11_l1_[0]
	else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[0]
	for l11ll11111_l1_ in range(2):
		if l1lll111111ll_l1_: mode,type,block = 116,l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ憐"),l1lll1l_l1_
		else: mode,type,block = 112,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ憑"),l1l11_l1_
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ憒"),block,re.DOTALL)
		if l1lll111111ll_l1_ and len(items)<2:
			l1lll111111ll_l1_ = False
			continue
		for l1lllll_l1_,l11l1l1l1_l1_,l1lll1l1l_l1_ in items:
			title = l11l1l1l1_l1_+l11ll1_l1_ (u"ࠪࠤࠬ憓")+l1lll1l1l_l1_
			addMenuItem(type,l111l1_l1_+title,l1lllll_l1_,mode)
		break
	# l1l11_l1_ l11l1l11_l1_
	if not items and l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹࠧ憔") in html:
		l1l11llll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡲࡦࡣࡧࡧࡷࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ憕"),html,re.DOTALL)
		if l1l11llll_l1_:
			block = l1l11llll_l1_[0]
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ憖"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1lllll_l1_ = l1l1_l1_[2]+l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ憗")
				l11111_l1_(l1lllll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ憘"),url,l11ll1_l1_ (u"ࠩࠪ憙"),headers,l11ll1_l1_ (u"ࠪࠫ憚"),l11ll1_l1_ (u"ࠫࠬ憛"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ憜"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡡࡤࡶ࡬ࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ憝"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭憞"),block,re.DOTALL)
	l11l1l1ll_l1_ = l11ll1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ憟") in block
	download = l11ll1_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭憠") in block
	if   l11l1l1ll_l1_ and not download: l1ll1llllllll_l1_,l111ll1l1ll1_l1_ = l1l1_l1_[0],l11ll1_l1_ (u"ࠪࠫ憡")
	elif not l11l1l1ll_l1_ and download: l1ll1llllllll_l1_,l111ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠫࠬ憢"),l1l1_l1_[0]
	elif l11l1l1ll_l1_ and download: l1ll1llllllll_l1_,l111ll1l1ll1_l1_ = l1l1_l1_[0],l1l1_l1_[1]
	else: l1ll1llllllll_l1_,l111ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭憣"),l11ll1_l1_ (u"࠭ࠧ憤")
	# l11l1l1ll_l1_
	if l11l1l1ll_l1_:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ憥"),l1ll1llllllll_l1_,l11ll1_l1_ (u"ࠨࠩ憦"),headers,l11ll1_l1_ (u"ࠩࠪ憧"),l11ll1_l1_ (u"ࠪࠫ憨"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ憩"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡲࡥࡵࠢࡶࡩࡷࡼࡥࡳࡵࠫ࠲࠯ࡅࠩࡱ࡮ࡤࡽࡪࡸࠧ憪"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ憫"),l111l_l1_,re.DOTALL)
			for title,l1lllll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࡝࡞࠲ࠫ憬"),l11ll1_l1_ (u"ࠨ࠱ࠪ憭"))
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ憮")+title+l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ憯")
				l1llll_l1_.append(l1lllll_l1_)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ憰"),l111ll1l1ll1_l1_,l11ll1_l1_ (u"ࠬ࠭憱"),headers,l11ll1_l1_ (u"࠭ࠧ憲"),l11ll1_l1_ (u"ࠧࠨ憳"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ憴"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࡬ࡲ࡫ࡵ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪ憵"),l11ll1ll_l1_,re.DOTALL)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ憶"),l111l_l1_,re.DOTALL)
			for l1lllll_l1_,title,l111llll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ憷")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ憸")+l11ll1_l1_ (u"࠭࡟ࡠࡡࡢࠫ憹")+l111llll_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ憺"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ憻"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ憼"),l11ll1_l1_ (u"ࠪ࠯ࠬ憽"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ憾")+search
	l1ll111_l1_,l111lll_l1_,l1ll1111l_l1_ = l1ll1l1lll1_l1_(url,l11ll1_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ憿"),l11ll1_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ懀"),l11ll1_l1_ (u"ࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧ懁"),headers)
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ懂"),l1ll1111l_l1_)
	return
# ===========================================
#     l1lll1llll_l1_ l1lll1lll1_l1_ l1llll1111_l1_
# ===========================================
def l1llllll11_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭懃"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ懄"),url,l11ll1_l1_ (u"ࠫࠬ懅"),headers,l11ll1_l1_ (u"ࠬ࠭懆"),l11ll1_l1_ (u"࠭ࠧ懇"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ懈"))
	html = response.content
	l1ll1lll_l1_ = []
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡣࡧࡺ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡶ࡬ࡴࡽࡳ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫ應"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# name & category & options block
		l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡸࡴࡩࡧࡴࡦࡓࡸࡩࡷࡿ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺࠧ懊"),block,re.DOTALL)
		l1lll1111111l_l1_,names,l1111l1_l1_ = zip(*l1ll1lll_l1_)
		l1ll1lll_l1_ = zip(names,l1lll1111111l_l1_,l1111l1_l1_)
	return l1ll1lll_l1_
def l1llll11ll_l1_(block):
	# id & title
	items = re.findall(l11ll1_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄ࡜ࡴࠬࠫ࠲࠯ࡅࠩ࡝ࡵ࠭ࡀࠬ懋"),block,re.DOTALL)
	return items
def l1ll1lllllll1_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ懌"),l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ懍"))
	if l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ懎") not in url: url = url+l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ懏")
	l1lllll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ懐"))[0]
	l1llll1l1l_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭懑"))
	url = url.replace(l1lllll1l1_l1_,l1llll1l1l_l1_)
	#url = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ懒"),l11ll1_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ懓"))
	url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ懔"),l11ll1_l1_ (u"࠭࠯ࡀࠩ懕"))
	return url
l1lll11111111_l1_ = [l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ懖"),l11ll1_l1_ (u"ࠨࡻࡨࡥࡷ࠭懗"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ懘"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ懙")]
l1lll111111l1_l1_ = [l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭懚"),l11ll1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ懛"),l11ll1_l1_ (u"࠭ࡹࡦࡣࡵࠫ懜")]
def l1lll111_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ懝"),l11ll1_l1_ (u"ࠨࠩ懞"))
	url = url.split(l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭懟"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ懠"),1)
	if filter==l11ll1_l1_ (u"ࠫࠬ懡"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠬ࠭懢"),l11ll1_l1_ (u"࠭ࠧ懣")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ懤"))
	if type==l11ll1_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ懥"):
		if l1lll111111l1_l1_[0]+l11ll1_l1_ (u"ࠩࡀࠫ懦") not in l1l111ll_l1_: category = l1lll111111l1_l1_[0]
		for i in range(len(l1lll111111l1_l1_[0:-1])):
			if l1lll111111l1_l1_[i]+l11ll1_l1_ (u"ࠪࡁࠬ懧") in l1l111ll_l1_: category = l1lll111111l1_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫ࠭懨")+category+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ懩")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ懪")+category+l11ll1_l1_ (u"ࠧ࠾࠲ࠪ懫")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪ懬"))+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭懭")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠪࠪࠬ懮"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ懯"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ懰")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ懱"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ懲"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠨࠩ懳"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ懴"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠪࠫ懵"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ懶")+l1l111l1_l1_
		l11l111_l1_ = l1ll1lllllll1_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懷"),l111l1_l1_+l11ll1_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ懸"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ懹"),l111l1_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ懺")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ懻"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ懼"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ懽"),l11ll1_l1_ (u"ࠬ࠭懾"),9999)
	l1ll1lll_l1_ = l1llllll11_l1_(url)
	dict = {}
	for name,l1ll1l1l_l1_,block in l1ll1lll_l1_:
		name = name.replace(l11ll1_l1_ (u"࠭ใๅࠢࠪ懿"),l11ll1_l1_ (u"ࠧࠨ戀"))
		items = l1llll11ll_l1_(block)
		if l11ll1_l1_ (u"ࠨ࠿ࠪ戁") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ戂"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<2:
				if l1ll1l1l_l1_==l1lll111111l1_l1_[-1]:
					l11l111_l1_ = l1ll1lllllll1_l1_(l111lll_l1_)
					l11111_l1_(l11l111_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ戃")+l1l11lll_l1_)
				return
			else:
				if l1ll1l1l_l1_==l1lll111111l1_l1_[-1]:
					l11l111_l1_ = l1ll1lllllll1_l1_(l111lll_l1_)
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ戄"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭戅"),l11l111_l1_,111)
				else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭戆"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ戇"),l111lll_l1_,115,l11ll1_l1_ (u"ࠨࠩ戈"),l11ll1_l1_ (u"ࠩࠪ戉"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ戊"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫ࠭戋")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ戌")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ戍")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾࠲ࠪ戎")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ戏")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ成"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ我")+name,l111lll_l1_,114,l11ll1_l1_ (u"ࠫࠬ戒"),l11ll1_l1_ (u"ࠬ࠭戓"),l1l11lll_l1_)		# +l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ戔"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ戕"): option = l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ或")
			elif value==l11ll1_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ戗"): option = l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ战")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ戙") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭戚"),value,re.DOTALL)[0]
			dict[l1ll1l1l_l1_][value] = option
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"࠭ࠦࠨ戛")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾ࠩ戜")+option
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠨࠨࠪ戝")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠩࡀࠫ戞")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ戟")+l1l1ll1l_l1_
			title = option+l11ll1_l1_ (u"ࠫࠥࡀࠧ戠")#+dict[l1ll1l1l_l1_][l11ll1_l1_ (u"ࠬ࠶ࠧ戡")]
			title = option+l11ll1_l1_ (u"࠭ࠠ࠻ࠩ戢")+name
			if type==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ戣"): addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ戤"),l111l1_l1_+title,url,114,l11ll1_l1_ (u"ࠩࠪ戥"),l11ll1_l1_ (u"ࠪࠫ戦"),l1ll1l11_l1_)		# +l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭戧"))
			elif type==l11ll1_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭戨") and l1lll111111l1_l1_[-2]+l11ll1_l1_ (u"࠭࠽ࠨ戩") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ截"))
				l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ戫")+l11lllll_l1_
				l11l111_l1_ = l1ll1lllllll1_l1_(l111lll_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ戬"),l111l1_l1_+title,l11l111_l1_,111)
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ戭"),l111l1_l1_+title,url,115,l11ll1_l1_ (u"ࠫࠬ戮"),l11ll1_l1_ (u"ࠬ࠭戯"),l1ll1l11_l1_)
	return
def l1l11111_l1_(filters,mode):
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ戰")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ戱")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ戲")					all l1l1l1ll_l1_ & l1lllll111_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠩࡀࠪࠬ戳"),l11ll1_l1_ (u"ࠪࡁ࠵ࠬࠧ戴"))
	filters = filters.strip(l11ll1_l1_ (u"ࠫࠫ࠭戵"))
	l1l11l11_l1_ = {}
	if l11ll1_l1_ (u"ࠬࡃࠧ戶") in filters:
		items = filters.split(l11ll1_l1_ (u"࠭ࠦࠨ户"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠧ࠾ࠩ戸"))
			l1l11l11_l1_[var] = value
	l1ll11ll_l1_ = l11ll1_l1_ (u"ࠨࠩ戹")
	for key in l1lll11111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠩ࠳ࠫ戺")
		if l11ll1_l1_ (u"ࠪࠩࠬ戻") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭戼") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧ戽"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠠࠬࠢࠪ戾")+value
		elif mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ房") and value!=l11ll1_l1_ (u"ࠨ࠲ࠪ所"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ扁")+key+l11ll1_l1_ (u"ࠪࡁࠬ扂")+value
		elif mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ扃"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠬࠧ扄")+key+l11ll1_l1_ (u"࠭࠽ࠨ扅")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ扆"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪ扇"))
	l1ll11ll_l1_ = l1ll11ll_l1_.replace(l11ll1_l1_ (u"ࠩࡀ࠴ࠬ扈"),l11ll1_l1_ (u"ࠪࡁࠬ扉"))
	return l1ll11ll_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ暵")
headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭暶"):l11ll1_l1_ (u"ࠪࠫ暷")}
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ暸")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ暹"),l11ll1_l1_ (u"࠭ࡷࡸࡧࠪ暺")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11111_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llll1l_l1_(url,text)
	elif mode==564: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ暻")+text)
	elif mode==565: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ暼")+text)
	elif mode==566: results = l1l111_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭暽"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ暾"),l11ll1_l1_ (u"ࠫࠬ暿"),False,l11ll1_l1_ (u"ࠬ࠭曀"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ曁"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ曂")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ曃"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ曄")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ曅"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ曆"),l11ll1_l1_ (u"ࠬ࠭曇"),l11ll1_l1_ (u"࠭ࠧ曈"),l11ll1_l1_ (u"ࠧࠨ曉"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ曊"))
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ曋"),l111l1_l1_+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ曌"),l11ll1_l1_ (u"ࠫࠬ曍"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ曎"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭曏"),l11ll1_l1_ (u"ࠧࠨ曐"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ曑"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ曒"),l11l1l_l1_,569,l11ll1_l1_ (u"ࠪࠫ曓"),l11ll1_l1_ (u"ࠫࠬ曔"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ曕"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曖"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ曗"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ曘"),564)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ曙"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭曚"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ曛"),565)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ曜"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭曝"),l11ll1_l1_ (u"ࠧࠨ曞"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ曟"):hostname,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭曠"):l11ll1_l1_ (u"ࠪࠫ曡")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ曢"),l11ll1_l1_ (u"ࠬ࠵ࠧ曣"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ曤"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭曥"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ曦") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ曧"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ曨")+l111l1_l1_+title,l1lllll_l1_,566)
	#	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ曩"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ曪"),l11ll1_l1_ (u"࠭ࠧ曫"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ曬"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ曭"),l11ll1_l1_ (u"ࠩࠪ曮"),l11ll1_l1_ (u"ࠪࠫ曯"),l11ll1_l1_ (u"ࠫࠬ曰"),l11ll1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ曱"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ曲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ曳"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭更") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭曵"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠪࠫ曶"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ曷"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ書")+l111l1_l1_+title,l1lllll_l1_,566)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ曹"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ曺"),l11ll1_l1_ (u"ࠨࠩ曻"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ曼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ曽"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ曾"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ替")+l111l1_l1_+title,l1lllll_l1_,566,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ最"),l11ll1_l1_ (u"ࠧࠨ朁"),url,l11ll1_l1_ (u"ࠨࠩ朂"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ會"):url,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ朄"):l11ll1_l1_ (u"ࠫࠬ朅")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ朆"),url,l11ll1_l1_ (u"࠭ࠧ朇"),l11ll1_l1_ (u"ࠧࠨ月"),l11ll1_l1_ (u"ࠨࠩ有"),l11ll1_l1_ (u"ࠩࠪ朊"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ朋"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朌"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ服"),url,564)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭朎"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ朏"),url,565)
	if l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ朐") in html:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ朑"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ朒"),url,561,l11ll1_l1_ (u"ࠫࠬ朓"),l11ll1_l1_ (u"ࠬ࠭朔"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ朕"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ朖"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ朗"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ朘"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l11111_l1_(l1ll1l1l111l_l1_,type=l11ll1_l1_ (u"ࠪࠫ朙")):
	if l11ll1_l1_ (u"ࠫ࠿ࡀࠧ朚") in l1ll1l1l111l_l1_:
		l11l111_l1_,url = l1ll1l1l111l_l1_.split(l11ll1_l1_ (u"ࠬࡀ࠺ࠨ望"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ朜"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l111l_l1_,l1ll1l1l111l_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ朝"):l11l111_l1_,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ朞"):l11ll1_l1_ (u"ࠩࠪ期")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ朠"),url,l11ll1_l1_ (u"ࠫࠬ朡"),l11ll1_l1_ (u"ࠬ࠭朢"),l11ll1_l1_ (u"࠭ࠧ朣"),l11ll1_l1_ (u"ࠧࠨ朤"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ朥"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ朦"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ朧"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ木"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠬࡢ࡜࠰ࠩ朩"),l11ll1_l1_ (u"࠭࠯ࠨ未")).replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠥࠫ末"),l11ll1_l1_ (u"ࠨࠤࠪ本"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮࡙ࡨࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭札"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ朮"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ术"),l11ll1_l1_ (u"ࠬ࠭朰"))
			if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ朱") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ朲"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭朳") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ朴"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ朵") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ朶"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ朷"),l111l1_l1_+title,l1lllll_l1_,562,l1lll1_l1_)
		if type==l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ朸"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ朹"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ机")+count
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ朻"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡลัี๎࠭朼"),l1lllll_l1_,561,l11ll1_l1_ (u"ࠫࠬ朽"),l11ll1_l1_ (u"ࠬ࠭朾"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ朿"))
		elif type==l11ll1_l1_ (u"ࠧࠨ杀"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ杁"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ杂"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ูࠪๆำษࠡࠩ权")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ杄"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"ࠬ࠭杅")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ杆"),l11ll1_l1_ (u"ࠧࠨ杇"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ杈"),url,l11ll1_l1_ (u"ࠩࠪ杉"),l11ll1_l1_ (u"ࠪࠫ杊"),l11ll1_l1_ (u"ࠫࠬ杋"),l11ll1_l1_ (u"ࠬ࠭杌"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ杍"))
	html = response.content
	html = l1111_l1_(html)
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࡟࠲࠷࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠱ࠬ࠲ࠧࠡࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫ࠴࠭ࠩࠋࠋ࡬ࡪࠥ࠭ๅ้ี่ࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡵࡻࡳࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ๅ้ี่ࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭อๅไฬࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࡀࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧฮๆๅอࠬ࠯࡛࠱࡟ࠍࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ๋ࠬࠬิศ้าอࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠤࠥࠦ李")
	# l1lll1l_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ杏"),html,re.DOTALL)
	if not type and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ材"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧ村")+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ杒"),l111l1_l1_+title,l1lllll_l1_,563,l11ll1_l1_ (u"ࠬ࠭杓"),l11ll1_l1_ (u"࠭ࠧ杔"),l11ll1_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ杕"))
			return
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ杖"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ杗"),block)
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠫ杘"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ杙"),str(items))
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ杚"))
			#title = name+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪ杛")+title
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭杜"),l111l1_l1_+title,l1lllll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ杝"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ杞"),l11ll1_l1_ (u"ࠪࠫ束")).replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ杠"),l11ll1_l1_ (u"ࠬ࠭条"))
		else: title = l11ll1_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ杢")
		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭杣"),l111l1_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ杤"),url,l11ll1_l1_ (u"ࠩࠪ来"),l11ll1_l1_ (u"ࠪࠫ杦"),l11ll1_l1_ (u"ࠫࠬ杧"),l11ll1_l1_ (u"ࠬ࠭杨"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ杩"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ杪"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ杫"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ杬"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ杭") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ุࠫ๐ัโำࠣ์๏ࠦำ๋็สࠫ杮"): name = l11ll1_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ杯")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ杰")+name+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ東")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭杲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ杳"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ杴") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ杵"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ杶")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"࠭ࠧ杷")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡸࡧࡦ࡭ࡲࡧࠧ杸")+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ杹")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ杺"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ杻"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠫࠬ杼")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭杽"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ松"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ板"),l11ll1_l1_ (u"ࠨ࠭ࠪ枀"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࠫ极"),l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ枂"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ枃"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ构"),l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ枅")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"ࠧฤใ็ห๊࠭枆"),l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠩ枇"),l11ll1_l1_ (u"ࠩฦ๊๏๋๊๊ࠡๆีฯ๎ๆࠨ枈"),l11ll1_l1_ (u"ࠪฬึอๅอࠢอ่๏็า๋๊้ࠫ枉"),l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ร็์่๎ࠬ枊")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ枋"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l1l_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ枌"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ枍"),l11ll1_l1_ (u"ࠨࠩ枎"),False,l11ll1_l1_ (u"ࠩࠪ枏"),l11ll1_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ析"))
		#hostname = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭枑")]
		#hostname = response.url
		#hostname = hostname.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ枒"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ枓")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l111l_l1_,filter):
	if l11ll1_l1_ (u"ࠧࡀࡁࠪ枔") in l1ll1l1l111l_l1_: url = l1ll1l1l111l_l1_.split(l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ枕"))[0]
	else: url = l1ll1l1l111l_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ枖"):l1ll1l1l111l_l1_,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ林"):l11ll1_l1_ (u"ࠫࠬ枘")}
	filter = filter.replace(l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ枙"),l11ll1_l1_ (u"࠭ࠧ枚"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ枛"),1)
	if filter==l11ll1_l1_ (u"ࠨࠩ果"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠩࠪ枝"),l11ll1_l1_ (u"ࠪࠫ枞")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ枟"))
	if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ枠"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"࠭࠽࠾ࠩ枡") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ枢") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ枣")+category+l11ll1_l1_ (u"ࠩࡀࡁ࠵࠭枤")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭枥")+category+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ枦")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠦࠨ枧"))+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ枨")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ枩"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ枪"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ枫")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ枬"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭枭"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠬ࠭枮"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ枯"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠧࠨ枰"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ枱")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l111l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ枲"),l111l1_l1_+l11ll1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭枳"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠫࠬ枴"),l11ll1_l1_ (u"ࠬ࠭枵"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ架"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ枷"),l111l1_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ枸")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ枹"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠪࠫ枺"),l11ll1_l1_ (u"ࠫࠬ枻"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭枼"))
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ枽"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ枾"),l11ll1_l1_ (u"ࠨࠩ枿"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭柀"),url,l11ll1_l1_ (u"ࠪࠫ柁"),l11ll1_l1_ (u"ࠫࠬ柂"),l11ll1_l1_ (u"ࠬ࠭柃"),l11ll1_l1_ (u"࠭ࠧ柄"),l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ柅"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠦࠬ柆"),l11ll1_l1_ (u"ࠩࠥࠫ柇")).replace(l11ll1_l1_ (u"ࠪࡠࡡ࠵ࠧ柈"),l11ll1_l1_ (u"ࠫ࠴࠭柉"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ柊"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ柋"),block+l11ll1_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ柌"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ柍") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ柎"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠪࡁࡂ࠭柏") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ某"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ柑")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l111l_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭柒"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆฯ้๏฿ࠧ染"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠨࠩ柔"),l11ll1_l1_ (u"ࠩࠪ柕"),l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ柖"))
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ柗"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬ柘"),l111lll_l1_,564,l11ll1_l1_ (u"࠭ࠧ柙"),l11ll1_l1_ (u"ࠧࠨ柚"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ柛"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ柜")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ柝")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ柞")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ柟")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ柠")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ柡"),l111l1_l1_+name+l11ll1_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ柢"),l111lll_l1_,565,l11ll1_l1_ (u"ࠩࠪ柣"),l11ll1_l1_ (u"ࠪࠫ柤"),l1l11lll_l1_+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭查"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠬࡸࠧ柦") or value==l11ll1_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ柧"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ柨") in option: continue
			if l11ll1_l1_ (u"ࠨษ็็้࠭柩") in option: continue
			if l11ll1_l1_ (u"ࠩࡱ࠱ࡦ࠭柪") in value: continue
			#if value in [l11ll1_l1_ (u"ࠪࡶࠬ柫"),l11ll1_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ柬"),l11ll1_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ柭")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ柮"): option = value
			if option==l11ll1_l1_ (u"ࠧࠨ柯"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭柰"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l1l1_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠩ࠽ࠤࠬ柱")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭柲")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃࠧ柳")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ柴")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠾ࠩ柵")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ柶")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ柷"):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ柸"),l111l1_l1_+l1lll1l1l_l1_,url,565,l11ll1_l1_ (u"ࠪࠫ柹"),l11ll1_l1_ (u"ࠫࠬ柺"),l1ll1l11_l1_+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ査"))
			elif type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ柼") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ柽") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ柾"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ柿"),l11ll1_l1_ (u"ࠪࠫ栀"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ栁")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ栂"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,561,l11ll1_l1_ (u"࠭ࠧ栃"),l11ll1_l1_ (u"ࠧࠨ栄"),l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ栅"))
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ栆"),l111l1_l1_+l1lll1l1l_l1_,url,564,l11ll1_l1_ (u"ࠪࠫ标"),l11ll1_l1_ (u"ࠫࠬ栈"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ栉"),l11ll1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ栊"),l11ll1_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ栋")]
l1l111111_l1_ = [l11ll1_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭栌"),l11ll1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ栍"),l11ll1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ栎"),l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭栏"),l11ll1_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭栐"),l11ll1_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ树"),l11ll1_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ栒"),l11ll1_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ栓")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ栔") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ栕"),l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ栖"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ栗"),l11ll1_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ栘"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠧ࠾࠿ࠪ栙"),l11ll1_l1_ (u"ࠨ࠱ࠪ栚"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩࠩࠪࠬ栛"),l11ll1_l1_ (u"ࠪ࠳ࠬ栜"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ栝"),l11ll1_l1_ (u"ࠬ࠭栞"),filters,l11ll1_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭栟")+mode)
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ栠")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ校")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭栢")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠪࠪࠫ࠭栣"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠫࠬ栤")
	if l11ll1_l1_ (u"ࠬࡃ࠽ࠨ栥") in filters:
		items = filters.split(l11ll1_l1_ (u"࠭ࠦࠧࠩ栦"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠧ࠾࠿ࠪ栧"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠨ࠲ࠪ栨")
		if l11ll1_l1_ (u"ࠩࠨࠫ栩") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ株") and value!=l11ll1_l1_ (u"ࠫ࠵࠭栫"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ栬")+value
		elif mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ栭") and value!=l11ll1_l1_ (u"ࠧ࠱ࠩ栮"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ栯")+key+l11ll1_l1_ (u"ࠩࡀࡁࠬ栰")+value
		elif mode==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ栱"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ栲")+key+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ栳")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠬࠢࠪ栴"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠨࠪ栵"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ栶"),l11ll1_l1_ (u"ࠩࠪ样"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠪࡓ࡚࡚ࠧ核"))
	return l1ll11ll_l1_
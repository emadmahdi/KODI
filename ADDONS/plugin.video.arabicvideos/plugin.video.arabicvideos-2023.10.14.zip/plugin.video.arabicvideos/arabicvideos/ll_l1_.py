# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ刴")
#l111l1l1l111_l1_ = [ l11ll1_l1_ (u"ࠪࡱࡾࡹࡴࡳࡧࡤࡱࠬ刵"),l11ll1_l1_ (u"ࠫࡻ࡯࡭ࡱ࡮ࡨࠫ制"),l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡲࡱࠬ刷"),l11ll1_l1_ (u"࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫ券") ]
l111l1l1l111_l1_ = []
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ刹"):l11ll1_l1_ (u"ࠨࠩ刺")}
def l11_l1_(l1llll11_l1_,source,type,url):
	#DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆิหอ฽ࠠศๆ่๊ฬูศࠨ刻"),l1llll11_l1_)
	if not l1llll11_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ刼"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡧ࡫ࡱࡨ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࡸࠦࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫ刽")+source+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࠤ࡙ࡿࡰࡦ࠼ࠣ࡟ࠥ࠭刾")+type+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ刿"))
		l111lll1ll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ剀"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ剁"),l11ll1_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ剂"))
		datetime = time.strftime(l11ll1_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐࠫ剃"),time.gmtime(now))
		line = datetime,url
		key = source+l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ剄")+l11llll11l1_l1_+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠪ剅")+str(kodi_version)
		message = l11ll1_l1_ (u"࠭ࠧ剆")
		if key not in list(l111lll1ll1l_l1_.keys()): l111lll1ll1l_l1_[key] = [line]
		else:
			if url not in str(l111lll1ll1l_l1_[key]): l111lll1ll1l_l1_[key].append(line)
			else: message = l11ll1_l1_ (u"ࠧ࡝ࡰ๋ࠣีอࠠศๆไ๎ิ๐่ࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋ࠠห฻่่ࠬ則")
		total = 0
		for key in list(l111lll1ll1l_l1_.keys()):
			l111lll1ll1l_l1_[key] = list(set(l111lll1ll1l_l1_[key]))
			total += len(l111lll1ll1l_l1_[key])
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ剈"),l11ll1_l1_ (u"ࠩࠪ剉"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭削"),l11ll1_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬ剋")+message+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰ่้ࠣ฿ไๆࠢส่อืๆศ็ฯࠤ๏่่ๆࠢหะ๊฿ࠠใษษ้ฮࠦศศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥ๐ฬะࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤํู่โࠢํ฽ึ฼ฺࠠๆํ็ࠥอไษำ้ห๊าࠠฤ่ࠣฮึูไ้ࠡำ๋ࠥอไใษษ้ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾์ฯๆษࠣ๎ฺฮอࠡ฻าำ์อࠠ࠶ࠢไ๎ิ๐่่ษอࠫ剌")+l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ前")+l11ll1_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪ剎")+str(total))
		if total>=5:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩ剏"),l11ll1_l1_ (u"ࠩࠪ剐"),l11ll1_l1_ (u"ࠪࠫ剑"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ剒"),l11ll1_l1_ (u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠷ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭剓"))
			if l1ll111ll1_l1_==1:
				l111lll1llll_l1_ = l11ll1_l1_ (u"࠭ࠧ剔")
				for key in list(l111lll1ll1l_l1_.keys()):
					l111lll1llll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ剕")+key
					l1111111l11l_l1_ = sorted(l111lll1ll1l_l1_[key],reverse=False,key=lambda l11lll1lllll_l1_: l11lll1lllll_l1_[0])
					for datetime,url in l1111111l11l_l1_:
						l111lll1llll_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ剖")+datetime+l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ剗")+l1111_l1_(url)
					l111lll1llll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ剘")
				import l1l1111ll1l_l1_
				succeeded = l1l1111ll1l_l1_.l111ll1111l_l1_(l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࡶࠫ剙"),l11ll1_l1_ (u"ࠬ࠭剚"),False,l11ll1_l1_ (u"࠭ࠧ剛"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔࡑࡇ࡙ࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ剜"),l11ll1_l1_ (u"ࠨࠩ剝"),l111lll1llll_l1_)
				if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ剞"),l11ll1_l1_ (u"ࠪࠫ剟"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ剠"),l11ll1_l1_ (u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ剡"))
				else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ剢"),l11ll1_l1_ (u"ࠧࠨ剣"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ剤"),l11ll1_l1_ (u"ࠩไุ้ะฺࠠ็็๎ฮࠦวๅวิืฬ๊ࠧ剥"))
			if l1ll111ll1_l1_!=-1:
				l111lll1ll1l_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭剦"),l11ll1_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ剧"))
		if l111lll1ll1l_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ剨"),l11ll1_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ剩"),l111lll1ll1l_l1_,PERMANENT_CACHE)
		return
	l1llll11_l1_ = list(set(l1llll11_l1_))
	l1lll11l_l1_,l1llll_l1_ = l11111l11111_l1_(l1llll11_l1_,source)
	l11111111lll_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ剪"))
	l11111l11l1l_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ剫"))
	l1111111l1ll_l1_ = len(l1llll_l1_)-l11111111lll_l1_-l11111l11l1l_l1_
	l11111l1llll_l1_ = l11ll1_l1_ (u"ุ่ࠩฬํฯส࠼ࠪ剬")+str(l11111111lll_l1_)+l11ll1_l1_ (u"ࠪࠤࠥࠦࠠหฯ่๎้ࡀࠧ剭")+str(l11111l11l1l_l1_)+l11ll1_l1_ (u"ࠫࠥࠦࠠࠡลัี๎ࡀࠧ剮")+str(l1111111l1ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭副"),l11ll1_l1_ (u"࠭ࠧ剰"),str(l11111111lll_l1_),str(l11111l11l1l_l1_))
	#l1l_l1_ = DIALOG_SELECT(l11111l1llll_l1_, l1llll_l1_)
	if not l1llll_l1_: result,l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ剱"),l11ll1_l1_ (u"ࠨࠩ割")
	else:
		while True:
			l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠩࠪ剳")
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11111l1llll_l1_,l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠷ࡳࡵࡡࡰࡩࡳࡻࠧ剴")
			else:
				title = l1lll11l_l1_[l1l_l1_]
				l1lllll_l1_ = l1llll_l1_[l1l_l1_]
				#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ創"),l11ll1_l1_ (u"ࠬ࠭剶"),title,l1lllll_l1_)
				if l11ll1_l1_ (u"࠭ำ๋ำไีࠬ剷") in title and l11ll1_l1_ (u"ࠧ࠳็ฯ๋ํ๊࠲ࠨ剸") in title:
					LOG_THIS(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭剹"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ剺")+title+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ剻")+l1lllll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ剼"))
					import l1l1111ll1l_l1_
					l1l1111ll1l_l1_.MAIN(156)
					result = l11ll1_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ剽")
				else:
					LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭剾"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࡓࡦࡴࡹࡩࡷࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ剿")+title+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ劀")+l1lllll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ劁"))
					result,l11l11ll1l1l_l1_,l11ll11l11ll_l1_ = l11111lll1ll_l1_(l1lllll_l1_,source,type)
					#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ劂"),l11ll1_l1_ (u"ࠫࠬ劃"),result,l11l11ll1l1l_l1_)
			if l11ll1_l1_ (u"ࠬࡢ࡮ࠨ劄") not in l11l11ll1l1l_l1_: l11l111llll1_l1_,l11l111lll1_l1_ = l11l11ll1l1l_l1_,l11ll1_l1_ (u"࠭ࠧ劅")
			else: l11l111llll1_l1_,l11l111lll1_l1_ = l11l11ll1l1l_l1_.split(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ劆"),1)
			if result in [l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭劇"),l11ll1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ劈"),l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ劉"),l11ll1_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ劊")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ劋"),l11ll1_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ劌"),l11ll1_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭劍")]: break
			elif result not in [l11ll1_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ劎"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ劏")]: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ劐"),l11ll1_l1_ (u"ࠫࠬ劑"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ劒"),l11ll1_l1_ (u"࠭วๅีํีๆืࠠๅ็ࠣ๎฾๋ไࠡฮิฬู๊ࠥาใิࠤ฿๐ั่ࠩ劓")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ劔")+l11l111llll1_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ劕")+l11l111lll1_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ劖"),l11ll1_l1_ (u"ࠪࠫ劗"),l11ll1_l1_ (u"ࠫࠬ劘"),str(l11ll11l11ll_l1_))
	if result==l11ll1_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ劙") and len(l1lll11l_l1_)>0: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ劚"),l11ll1_l1_ (u"ࠧࠨ力"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ劜"),l11ll1_l1_ (u"ࠩึ๎ึ็ั้ࠡำหࠥอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠠอำหࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠨ劝")+l11ll1_l1_ (u"ࠪࡠࡳ࠭办")+l11l11ll1l1l_l1_)
	elif result in [l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ功"),l11ll1_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭加")] and l11l11ll1l1l_l1_!=l11ll1_l1_ (u"࠭ࠧ务"): DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ劢"),l11ll1_l1_ (u"ࠨࠩ劣"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劤"),l11l11ll1l1l_l1_)
	#elif l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠪࡖࡊ࡚ࡕࡓࡐࡢࡘࡔࡥ࡙ࡐࡗࡗ࡙ࡇࡋࠧ劥"): result = l11ll11l11ll_l1_
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࡲࡦࡵࡸࡰࡹࠦࡩ࡯ࠢ࡞ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ࠮ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ࡞࠼ࠍࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࡐࡔࡍࡇࡊࡐࡊࠬࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠫ࠮ࠫࠥࠦࠠࡕࡧࡶࡸ࠿ࠦࠠࠡࠩ࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠶࡝ࠬࡵࡼࡷ࠳ࡧࡲࡨࡸ࡞࠶ࡢ࠯ࠊࠊࠋࡻࡦࡲࡩࡰ࡭ࡷࡪ࡭ࡳ࠴ࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࡢࡦࡧࡳࡳࡥࡨࡢࡰࡧࡰࡪ࠲ࠠࡇࡣ࡯ࡷࡪ࠲ࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫ࠭࠮ࠐࠉࠊࡲ࡯ࡥࡾࡥࡩࡵࡧࡰࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡍ࡫ࡶࡸࡎࡺࡥ࡮ࠪࡳࡥࡹ࡮࠽ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠰ࡁࡰࡳࡩ࡫࠽࠲࠶࠶ࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࠨ࠷ࡋࡼࠥ࠴ࡆࡪࡻࡧ࠷ࡰࡹࡘࡷࡻ࠾ࡗࠧࠪࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡵࡲࡡࡺࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡲࡶ࠲࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠵ࡩࡱࡪࡲࡲࡪ࠵࠱࠳࠵࠷࠸࠼࠴࡭ࡱ࠶ࠪ࠰ࡵࡲࡡࡺࡡ࡬ࡸࡪࡳࠩࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧห็ࠣห้อไ฻ษฤࠫ࠱࠭ࠧࠪࠌࠌࠦࠧࠨ劦")
	return result
	#if source==l11ll1_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ劧"): l111l1_l1_ = l11ll1_l1_ (u"࠭ࡈࡍࡃࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ动")
	#elif source==l11ll1_l1_ (u"ࠧ࠵ࡊࡈࡐࡆࡒࠧ助"): l111l1_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡌࡊࡒࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ努")
	#elif source==l11ll1_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ劫"): l111l1_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡇࡋࡎࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ劬")
	#elif source==l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭劭"): l111l1_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡔࡊ࠷ࠤࠬ劮")
	#size = len(l1ll1ll1l1_l1_)
	#for i in range(0,size):
	#	title = l11l11ll11ll_l1_[i]
	#	l1lllll_l1_ = l1ll1ll1l1_l1_[i]
	#	addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ劯"),l111l1_l1_+title,l1lllll_l1_,160,l11ll1_l1_ (u"ࠧࠨ劰"),l11ll1_l1_ (u"ࠨࠩ励"),source)
def l11111lll1ll_l1_(url,source,type=l11ll1_l1_ (u"ࠩࠪ劲")):
	url = url.strip(l11ll1_l1_ (u"ࠪࠤࠬ劳")).strip(l11ll1_l1_ (u"ࠫࠫ࠭労")).strip(l11ll1_l1_ (u"ࠬࡅࠧ劵")).strip(l11ll1_l1_ (u"࠭࠯ࠨ劶"))
	l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllll1lll_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ劷"),l11ll1_l1_ (u"ࠨࠩ劸"),url,l11l11ll1l1l_l1_)
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ効"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ劺"), l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ劻")
			else:
				l1111lllll11_l1_ = l1llll_l1_[l1l_l1_]
				title = l1lll11l_l1_[l1l_l1_]
				LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ劼"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡪࡲࡥࡤࡶࡨࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬ劽")+title+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭劾")+str(l1111lllll11_l1_)+l11ll1_l1_ (u"ࠨࠢࡠࠫ势"))
				if l11ll1_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ勀") in l1111lllll11_l1_ and l11ll1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ勁") in l1111lllll11_l1_:
					l111l11ll1ll_l1_,l11ll111l1ll_l1_,l11ll11l11ll_l1_ = l111llllll1l_l1_(l1111lllll11_l1_)
					if l11ll11l11ll_l1_: l1111lllll11_l1_ = l11ll11l11ll_l1_[0]
					else: l1111lllll11_l1_ = l11ll1_l1_ (u"ࠫࠬ勂")
				if not l1111lllll11_l1_: result = l11ll1_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ勃")
				else: result = PLAY_VIDEO(l1111lllll11_l1_,source,type)
			if result in [l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ勄"),l11ll1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ勅")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ勆"),l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ勇"),l11ll1_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ勈")]: break
			else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ勉"),l11ll1_l1_ (u"ࠬ࠭勊"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ勋"),l11ll1_l1_ (u"ࠧศๆ่่ๆࠦไๆࠢํ฽๊๊ࠠอำหࠤ๊๊แࠡ฼ํี์࠭勌"))
	else:
		result = l11ll1_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ勍")
		l111lll1l1_l1_ = l11l1lll11_l1_(url)
		if l111lll1l1_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11l11ll1l1l_l1_,l1llll_l1_
	#title = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠥ勎") )
	#if l11ll1_l1_ (u"ࠪื๏ืแาࠢ฼ห๊ࠦๅอ้๋่ࠬ勏") in title:
	#	import l1l1111ll1l_l1_
	#	l1l1111ll1l_l1_.MAIN(156)
	#	return l11ll1_l1_ (u"ࠫࠬ勐")
def l1lllll1lllll_l1_(url,source):
	# url = url+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭勑")+name+l11ll1_l1_ (u"࠭࡟ࡠࠩ勒")+type+l11ll1_l1_ (u"ࠧࡠࡡࠪ勓")+l11lll1_l1_+l11ll1_l1_ (u"ࠨࡡࡢࠫ勔")+l111llll_l1_
	# url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸࡄࡴࡡ࡮ࡧࡧࡁࡦࡱࡷࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲࡶ࠴ࡠࡡ࠺࠶࠵࠭動")
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111ll1_l1_,name,type,l11lll1_l1_,l111llll_l1_ = url,l11ll1_l1_ (u"ࠪࠫ勖"),l11ll1_l1_ (u"ࠫࠬ勗"),l11ll1_l1_ (u"ࠬ࠭勘"),l11ll1_l1_ (u"࠭ࠧ務"),l11ll1_l1_ (u"ࠧࠨ勚"),l11ll1_l1_ (u"ࠨࠩ勛"),l11ll1_l1_ (u"ࠩࠪ勜")
	#source = source.lower()
	if l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ勝") in url:
		l111lll_l1_,l11l1111l1l1_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ勞"),1)
		l11l1111l1l1_l1_ = l11l1111l1l1_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࠨ募")+l11ll1_l1_ (u"࠭࡟ࡠࠩ勠")+l11ll1_l1_ (u"ࠧࡠࡡࠪ勡")+l11ll1_l1_ (u"ࠨࡡࡢࠫ勢")
		l11l1111l1l1_l1_ = l11l1111l1l1_l1_.lower()
		name,type,l11lll1_l1_,l111llll_l1_,l1llll1l1111_l1_ = l11l1111l1l1_l1_.split(l11ll1_l1_ (u"ࠩࡢࡣࠬ勣"))[:5]
	if l111llll_l1_==l11ll1_l1_ (u"ࠪࠫ勤"): l111llll_l1_ = l11ll1_l1_ (u"ࠫ࠵࠭勥")
	else: l111llll_l1_ = l111llll_l1_.replace(l11ll1_l1_ (u"ࠬࡶࠧ勦"),l11ll1_l1_ (u"࠭ࠧ勧")).replace(l11ll1_l1_ (u"ࠧࠡࠩ勨"),l11ll1_l1_ (u"ࠨࠩ勩"))
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠩࡂࠫ勪")).strip(l11ll1_l1_ (u"ࠪ࠳ࠬ勫")).strip(l11ll1_l1_ (u"ࠫࠫ࠭勬"))
	server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ勭"))
	if name: l111l1111ll1_l1_ = name
	#elif source: l111l1111ll1_l1_ = source
	else: l111l1111ll1_l1_ = server
	l111l1111ll1_l1_ = SERVER(l111l1111ll1_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ勮"))
	name = name.replace(l11ll1_l1_ (u"ࠧๆสสุึ࠭勯"),l11ll1_l1_ (u"ࠨࠩ勰")).replace(l11ll1_l1_ (u"ࠩึ๎ึ็ัࠨ勱"),l11ll1_l1_ (u"ࠪࠫ勲")).replace(l11ll1_l1_ (u"ࠫฬ๊ࠠࠨ勳"),l11ll1_l1_ (u"ࠬࠦࠧ勴")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ勵"),l11ll1_l1_ (u"ࠧࠡࠩ勶"))
	l11l1111l1l1_l1_ = l11l1111l1l1_l1_.replace(l11ll1_l1_ (u"ࠨ็หหูืࠧ勷"),l11ll1_l1_ (u"ࠩࠪ勸")).replace(l11ll1_l1_ (u"ࠪื๏ืแาࠩ勹"),l11ll1_l1_ (u"ࠫࠬ勺")).replace(l11ll1_l1_ (u"ࠬอไࠡࠩ勻"),l11ll1_l1_ (u"࠭ࠠࠨ勼")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ勽"),l11ll1_l1_ (u"ࠨࠢࠪ勾"))
	l111l1111ll1_l1_ = l111l1111ll1_l1_.replace(l11ll1_l1_ (u"่ࠩฬฬฺัࠨ勿"),l11ll1_l1_ (u"ࠪࠫ匀")).replace(l11ll1_l1_ (u"ุࠫ๐ัโำࠪ匁"),l11ll1_l1_ (u"ࠬ࠭匂")).replace(l11ll1_l1_ (u"࠭วๅࠢࠪ匃"),l11ll1_l1_ (u"ࠧࠡࠩ匄")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ包"),l11ll1_l1_ (u"ࠩࠣࠫ匆"))
	return l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111ll1_l1_,name,type,l11lll1_l1_,l111llll_l1_
def l11l11l1ll1l_l1_(url,source):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ匇"),l11ll1_l1_ (u"ࠫࠬ匈"),url,l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡆࡈࡌࡆࠩ匉"))
	# l1lll1l11_l1_	: سيرفر خاص
	# l11l111l1lll_l1_		: سيرفر محدد
	# l11l1111l111_l1_		: سيرفر عام معروف
	# l1ll1l1l1_l1_	: سيرفر عام خارجي
	# l1111111llll_l1_	: سيرفر عام خارجي
	l1111lll11l1_l1_,name,l1lll1l11_l1_,l11l1111l111_l1_,l1ll1l1l1_l1_,l11l111l1lll_l1_,l1111111llll_l1_ = l11ll1_l1_ (u"࠭ࠧ匊"),l11ll1_l1_ (u"ࠧࠨ匋"),None,None,None,None,None
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111ll1_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1lllll1lllll_l1_(url,source)
	if l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ匌") in url:
		if   type==l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤࠨ匍"): type = l11ll1_l1_ (u"ࠪࠤࠬ匎")+l11ll1_l1_ (u"๊ࠫ็ึๅࠩ匏")
		elif type==l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ匐"): type = l11ll1_l1_ (u"࠭ࠠࠨ匑")+l11ll1_l1_ (u"ࠧࠦ็ืห์ีษࠨ匒")
		elif type==l11ll1_l1_ (u"ࠨࡤࡲࡸ࡭࠭匓"): type = l11ll1_l1_ (u"ࠩࠣࠫ匔")+l11ll1_l1_ (u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬ匕")
		elif type==l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭化"): type = l11ll1_l1_ (u"ࠬࠦࠧ北")+l11ll1_l1_ (u"࠭ࠥࠦࠧอั๊๐ไࠨ匘")
		elif type==l11ll1_l1_ (u"ࠧࠨ匙"): type = l11ll1_l1_ (u"ࠨࠢࠪ匚")+l11ll1_l1_ (u"ࠩࠨࠩࠪࠫࠧ匛")
		if l11lll1_l1_!=l11ll1_l1_ (u"ࠪࠫ匜"):
			if l11ll1_l1_ (u"ࠫࡲࡶ࠴ࠨ匝") not in l11lll1_l1_: l11lll1_l1_ = l11ll1_l1_ (u"ࠬࠫࠧ匞")+l11lll1_l1_
			l11lll1_l1_ = l11ll1_l1_ (u"࠭ࠠࠨ匟")+l11lll1_l1_
		if l111llll_l1_!=l11ll1_l1_ (u"ࠧࠨ匠"):
			l111llll_l1_ = l11ll1_l1_ (u"ࠨࠧࠨࠩࠪࠫࠥࠦࠧࠨࠫ匡")+l111llll_l1_
			l111llll_l1_ = l11ll1_l1_ (u"ࠩࠣࠫ匢")+l111llll_l1_[-9:]
	#if any(value in server for value in l111l1l1l111_l1_): return l11ll1_l1_ (u"ࠪࠫ匣")
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ匤"),l11ll1_l1_ (u"ࠬ࠭匥"),name,l111l1111ll1_l1_)
	if   l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ匦")		in source: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭匧")		in source: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨࡣ࡮ࡻࡦࡳࠧ匨")
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ匩")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ匪")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠫࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࠪ匫")	in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ匬")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ匭")
	#elif l11ll1_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡳࡵࡣࡷ࡭ࡴࡴࠧ匮") in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ匯")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ匰")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	#elif l11ll1_l1_ (u"ࠪࡴࡨࡸࡥࡷ࡫ࡨࡻࠬ匱")	in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨࠬ匲")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠬࡺ࠷࡮ࡧࡨࡰࠬ匳")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭匴")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ匵")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ匶")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦࠬ匷")	in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬ匸")
	elif l11ll1_l1_ (u"ࠫๆาัࠨ匹")			in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ区")
	elif l11ll1_l1_ (u"࠭แๅีฺ๎๋࠭医")		in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪ匼")
	elif l11ll1_l1_ (u"ࠨࡩࡧࡶ࡮ࡼࡥࠨ匽")		in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࠩ匾")
	elif l11ll1_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ匿")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ區")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭十")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧ卂")		in name:   l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ千")	in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ卄")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ卅")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠪࡸࡻࡱࡳࡢࠩ卆")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ升")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ午")		in server: l1lll1l11_l1_	= l111l1111ll1_l1_
	#elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽ࠮࡯ࡧࡷࠫ卉")	in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࠡࠩ半")
	elif l11ll1_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ卋")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ卌")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ卍")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ华")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ协")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ卐")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭卑")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ卒")
	elif l11ll1_l1_ (u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ卓")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ協")
	elif l11ll1_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ单")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩ卖")
	elif l11ll1_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ南")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ単")
	elif l11ll1_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ卙")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ博")
	elif l11ll1_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ卛")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ卜")
	elif l11ll1_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ卝")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠭卞")
	elif l11ll1_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ卟")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ占")
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ卡")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭卢")
	elif l11ll1_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ卣")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭卤")
	elif l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ卥")	 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠭卦")
	elif l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ卧")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ卨")
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ卩")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ卪")
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ卫")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬ卬")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠧ࡮ࡻࡹ࡭࡮ࡪࠧ卭")		in server: l11l111l1lll_l1_	= l111l1111ll1_l1_
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ卮")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ卯")
	elif l11ll1_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ印")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ危")
	elif l11ll1_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ卲") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ即")
	elif l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ却")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ卵")
	elif l11ll1_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ卶")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨ卷")
	elif l11ll1_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ卸") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ卹")
	elif l11ll1_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ卺")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ卻")
	elif l11ll1_l1_ (u"ࠨࡷࡳࡴࠬ卼") 			in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ卽")
	elif l11ll1_l1_ (u"ࠪࡹࡵࡨࠧ卾") 			in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ卿")
	elif l11ll1_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ厀") 		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭厁")
	elif l11ll1_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ厂") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ厃")
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ厄")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ厅")
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ历") 		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ厇")
	elif l11ll1_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ厈") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ厉")
	elif l11ll1_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ厊")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭压")
	elif l11ll1_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ厌")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ厍")
	#elif l11ll1_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭厎") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ厏")
	#elif l11ll1_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ厐")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ厑")
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡻࡲ࡭࠭ࠪࡁࡂࡃࠧࠬࡷࡵࡰ࠷࠯ࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠊࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯࠲ࡍࡵࡳࡵࡧࡧࡑࡪࡪࡩࡢࡈ࡬ࡰࡪ࠮ࡵࡳ࡮࠵࠭࠳ࡼࡡ࡭࡫ࡧࡣࡺࡸ࡬ࠩࠫࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠌࠌࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠶࠷࠱࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨࠫࠍࠍࠎࠏࡲࡦࡵࡲࡰࡻ࡫ࡲࠡ࠿ࠣࡊࡦࡲࡳࡦࠌࠌࠍࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡧࡰ࠳ࡵࡲࡨࠌࠌࠍࠎࡲࡩࡴࡶࡢࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡺࡤ࡭࠯ࡲࡶ࡬࠴ࡧࡪࡶ࡫ࡹࡧ࠴ࡩࡰ࠱ࡼࡳࡺࡺࡵࡣࡧ࠰ࡨࡱ࠵ࡳࡶࡲࡳࡳࡷࡺࡥࡥࡵ࡬ࡸࡪࡹ࠮ࡩࡶࡰࡰࠬࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬ࡭࡫ࡶࡸࡤࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡗࡔࡒࡖࡂࡄࡏࡉ࠲࠷ࡳࡵࠩࠬࠎࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡂࡵ࡭ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡯ࡦࠡࡪࡷࡱࡱࡀࠊࠊࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࡝࠳ࡡ࠳ࡲ࡯ࡸࡧࡵࠬ࠮ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾ࡥࡂࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽࠱࡯࡭ࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰ࡤࡁࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࠬ࠸࠲࠳࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩࠬࠎࠎࠏࠉࠊࡲࡤࡶࡹࡹࠠ࠾ࠢࡶࡩࡷࡼࡥࡳ࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠱ࠫ࠮ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡱࡣࡵࡸࠥ࡯࡮ࠡࡲࡤࡶࡹࡹ࠺ࠋࠋࠌࠍࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡰࡢࡴࡷ࠭ࡁ࠺࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࠉࠊࡧ࡯࡭࡫ࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠐࠉࠊࠋࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࠋࠌࠍࠎࠏࡢࡳࡧࡤ࡯ࠏࠏࠢࠣࠤ厒")
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ厓"),l11ll1_l1_ (u"ࠫࠬ厔"),url,l111lll_l1_)
	if   l1lll1l11_l1_:	l1111lll11l1_l1_,name = l11ll1_l1_ (u"ࠬิวึࠩ厕"),l1lll1l11_l1_
	elif l11l111l1lll_l1_:		l1111lll11l1_l1_,name = l11ll1_l1_ (u"࠭ࠥๆฯาำࠬ厖"),l11l111l1lll_l1_
	elif l11l1111l111_l1_:		l1111lll11l1_l1_,name = l11ll1_l1_ (u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ厗"),l11l1111l111_l1_
	elif l1ll1l1l1_l1_:	l1111lll11l1_l1_,name = l11ll1_l1_ (u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ厘"),l1ll1l1l1_l1_
	elif l1111111llll_l1_:	l1111lll11l1_l1_,name = l11ll1_l1_ (u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ厙"),l111l1111ll1_l1_
	else:			l1111lll11l1_l1_,name = l11ll1_l1_ (u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫ厚"),l111l1111ll1_l1_
	return l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡱ࡮ࡤࡽࡷ࠴࠴ࡩࡧ࡯ࡥࡱ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡶࡲࡪࡸࡤࡸࡪࠦ࠽ࠡࠩ࡫ࡩࡱࡧ࡬ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡨࡷࡹࡸࡥࡢ࡯ࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡩ࡯ࡶࡲࡹࡵࡲ࡯ࡢࡦࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡦࡸࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡶ࡬ࡦࡸࡥࠨࠌࠌࠦࠧࠨ厛")
def l1111l11l11l_l1_(url,source):
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111ll1_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1lllll1lllll_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭厜"),l11ll1_l1_ (u"࠭ࠧ厝"),l11l111l1lll_l1_,server)
	#if l11ll1_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ厞")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ原"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ厠"))
	#if any(value in server for value in l111l1l1l111_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡊ࡙ࡏࡍࡘࡈࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࠠࡵࡪ࡬ࡷࠥࡹࡥࡳࡸࡨࡶࠬ厡")],[]
	if   l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ厢")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11llll_l1_(l111lll_l1_,name)
	elif l11ll1_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ厣")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1_l1_(l111lll_l1_,type,l111llll_l1_)
	elif l11ll1_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ厤")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ厥")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ厦")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ厧")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ厨")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11l11l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭厩")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ厪")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣࠩ厫")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll111ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ厬")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll1lll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ厭")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡷࡺࡰࡹࡡࠨ厮")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡸࡻ࠳ࡦ࠯ࡥࡲࡱࠬ厯")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭厰")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1lll1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ厱")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ厲")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l11ll11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ厳")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111111111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡸࡶ࠸ࡺ࠭厴")			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1llll1l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ厵")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ厶")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬ厷")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡰ࡮࡭ࡨࡵࠩ厸")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ厹")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ厺")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll11lll1l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ去")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ厼")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ厽")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭厾")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ县")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡺࡥࡤࡪࠪ叀")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡨࡷ࡯ࡪࡹ࡫ࡣࡩࠩ叁")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡳࡣࡷࡩࠬ参")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡳࡧࡷ࡫ࡶࡪࡧࡺࠫ參")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ叄")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll1ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ叅")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬ࠭叆"),[l11ll1_l1_ (u"࠭ࠧ叇")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ又")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧ叉")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ及") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠪࠫ友"),[l11ll1_l1_ (u"ࠫࠬ双")],[l111lll_l1_]
	else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ反"),[l11ll1_l1_ (u"࠭ࠧ収")],[l111lll_l1_]
	return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
def l11l11111ll1_l1_(url,source):
	server = SERVER(url,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ叏"))
	#if l11ll1_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭叐")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ发"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ叒"))
	#if any(value in server for value in l111l1l1l111_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗࡋࡓࡐࡎ࡙ࡉࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡦࡴࡹࡩࡷ࠭叓")],[]
	l1111l11l111_l1_ = False
	if   l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ叔")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1ll11_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭叕")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1ll11_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷࠫ取") in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l111l1l1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ受")	in url: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1l1l1l1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ变")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ叙")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ叚")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ叛")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llllll1l_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ叜")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l111_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ叝")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1lll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ叞")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll111ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ叟")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1lll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ叠")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll1111l_l1_(url)
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ叡")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll11l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ叢")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll11l1l_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ口")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ古")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ句")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡮ࡤࠨ另")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ叧")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡪࡸ࡬ࡨࡪࡵࠧ叨")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡱࡥࡥࠬ叩")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1lll11_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡶࡴࡪ࡫ࡤࠨ只")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1lll11_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡶࡲࡥࡥࡲ࠭叫") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࠩ召"),[l11ll1_l1_ (u"ࠩࠪ叭")],[url]
	#elif l11ll1_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ叮")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll111l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭可") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1l11l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ台")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll111ll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲ࡬ࡴ࠭叱")in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l111111l_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ史") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llll11ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ右")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1l11l1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧ࠭叴") 			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll1lll1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡹࡵࡶࠧ叵") 			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll1lll1ll_l1_(url)
	#elif l11ll1_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ叶") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1l11l_l1_(url)
	#elif l11ll1_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ号")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1l11l_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭司") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111lllll_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ叹") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l11llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ叺")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1111ll_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ叻") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111ll1l11_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ叼") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1llll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ叽")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111l111ll_l1_(url)
	elif l11ll1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ叾")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1ll1l_l1_(url)
	else: l1111l11l111_l1_ = True
	if l1111l11l111_l1_ or l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ叿") in l11l11ll1l1l_l1_:
		l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶ࠦࡆࡢ࡫࡯ࡩࡩ࠭吀"),[],[]
	return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆࡕࡗࡖࡊࡇࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡌࡕࡕࡏࡎࡌࡑࡎ࡚ࡅࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡏࡎࡕࡑࡘࡔࡑࡕࡁࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡘࡍࡋࡖࡊࡆࡈࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡅࡗࡋࡒࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡊࡈࡐࡆࡒࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡤࡲࡱࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡅࡓࡒ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡩࡦࠪࠤࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡊࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡕࡋࡅࡗࡋࠨࡶࡴ࡯࠭ࠏࠏࠢࠣࠤ吁")
def	l111l11l1lll_l1_(l11ll11ll1ll_l1_):
	if l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ吂") in str(type(l11ll11ll1ll_l1_)):
		l1l1_l1_ = []
		for l1lllll_l1_ in l11ll11ll1ll_l1_:
			if l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ吃") in str(type(l1lllll_l1_)):
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡸࠧ各"),l11ll1_l1_ (u"ࠬ࠭吅")).replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ吆"),l11ll1_l1_ (u"ࠧࠨ吇")).strip(l11ll1_l1_ (u"ࠨࠢࠪ合"))
			l1l1_l1_.append(l1lllll_l1_)
	else: l1l1_l1_ = l11ll11ll1ll_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡶࠬ吉"),l11ll1_l1_ (u"ࠪࠫ吊")).replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ吋"),l11ll1_l1_ (u"ࠬ࠭同")).strip(l11ll1_l1_ (u"࠭ࠠࠨ名"))
	return l1l1_l1_
def l1lllllll1lll_l1_(url,source):
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ后"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ吏")+url+l11ll1_l1_ (u"ࠩࠣࡡࠬ吐"))
	l1111111llll_l1_,l1lllll_l1_,l111l11ll111_l1_ = l11ll1_l1_ (u"ࠪࡍࡓ࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠧ向"),l11ll1_l1_ (u"ࠫࠬ吒"),l11ll1_l1_ (u"ࠬ࠭吓")
	l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l11l11l_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ吔"),l11ll1_l1_ (u"ࠧࠨ吕"),l11ll1_l1_ (u"ࠨࠩ吖"),l11l11ll1l1l_l1_)
	l1llll_l1_ = l111l11l1lll_l1_(l1llll_l1_)
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ吗"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_: l1lllll_l1_ = l1llll_l1_[0]
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭吘"):
		#l11l11ll1l1l_l1_ = l11l11ll1l1l_l1_.replace(l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ吙"),l11ll1_l1_ (u"ࠬ࠭吚"))
		l1111111llll_l1_ = l11ll1_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠬ君")
		l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111ll1_l1_(l1lllll_l1_,source)
		l1llll_l1_ = l111l11l1lll_l1_(l1llll_l1_)
		if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ吜"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
		elif l11ll1_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ吝") in l11l11ll1l1l_l1_:
			l111l11ll111_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠪ吞")+l11l11ll1l1l_l1_
			l1111111llll_l1_ = l11ll1_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ吟")
			l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111l1l_l1_(l1lllll_l1_,source)
			l1llll_l1_ = l111l11l1lll_l1_(l1llll_l1_)
			if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ吠"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
			elif l11ll1_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ吡") in l11l11ll1l1l_l1_:
				l111l11ll111_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ吢")+l11l11ll1l1l_l1_
				l1111111llll_l1_ = l11ll1_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭吣")
				l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111l11_l1_(l1lllll_l1_,source)
				l1llll_l1_ = l111l11l1lll_l1_(l1llll_l1_)
				if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭吤"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
				elif l11ll1_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ吥") in l11l11ll1l1l_l1_:
					l111l11ll111_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠫ否")+l11l11ll1l1l_l1_
	elif l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭吧") in l11l11ll1l1l_l1_: l111l11ll111_l1_ = l11ll1_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ吨")+l11l11ll1l1l_l1_
	if l1llll_l1_: LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭吩"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ吪")+l1111111llll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ含")+url+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ听")+l1lllll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭吭")+str(l1llll_l1_)+l11ll1_l1_ (u"ࠫࠥࡣࠧ吮"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ启"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭吰")+url+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ吱")+l1lllll_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ吲")+l111l11ll111_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ吳"))
	l111l11ll111_l1_ = l1111_l1_(l111l11ll111_l1_)
	return l111l11ll111_l1_,l1lll11l_l1_,l1llll_l1_
def l11111l11111_l1_(l11ll11l11ll_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ吴"),l11ll11l11ll_l1_)
	l1l111llll1_l1_ = l1llllll_l1_
	data = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ吵"),l11ll1_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭吶"),l11ll11l11ll_l1_)
	if data:
		l1lll11l_l1_,l1llll_l1_ = list(zip(*data))
		return l1lll11l_l1_,l1llll_l1_
	l1lll11l_l1_,l1llll_l1_,l11l11ll11ll_l1_ = [],[],[]
	for l1lllll_l1_ in l11ll11l11ll_l1_:
		if l11ll1_l1_ (u"࠭࠯࠰ࠩ吷") not in l1lllll_l1_: continue
		l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l11l11l1ll1l_l1_(l1lllll_l1_,source)
		l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࠮ࠫ吸"),l111llll_l1_,re.DOTALL)
		if l111llll_l1_: l111llll_l1_ = int(l111llll_l1_[0])
		else: l111llll_l1_ = 0
		#if l111llll_l1_:
		#	l111lllll1l1_l1_ = sorted(l111llll_l1_,reverse=True,key=lambda key: int(key))
		#	l111llll_l1_ = int(l111lllll1l1_l1_[0])
		#else: l111llll_l1_ = 0
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭吹"))
		l11l11ll11ll_l1_.append([l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server])
	if l11l11ll11ll_l1_:
		#l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_ = zip(*l11l11ll11ll_l1_)
		#name = reversed(name)
		#l11l11ll11ll_l1_ = zip(l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_)
		l1llll11l1ll_l1_ = sorted(l11l11ll11ll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111l11l111l_l1_ = []
		for line in l1llll11l1ll_l1_:
			if line not in l111l11l111l_l1_:
				l111l11l111l_l1_.append(line)
				#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ吺"),str(line))
		for l1111lll11l1_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server in l111l11l111l_l1_:
			if l111llll_l1_: l111llll_l1_ = str(l111llll_l1_)
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠪࠫ吻")
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ吼"),l11ll1_l1_ (u"ࠬ࠭吽"),name,l1lllll_l1_)
			title = l11ll1_l1_ (u"࠭ำ๋ำไีࠬ吾")+l11ll1_l1_ (u"ࠧࠡࠩ吿")+type+l11ll1_l1_ (u"ࠨࠢࠪ呀")+l1111lll11l1_l1_+l11ll1_l1_ (u"ࠩࠣࠫ呁")+l111llll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ呂")+l11lll1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭呃")+name
			if server not in title: title = title+l11ll1_l1_ (u"ࠬࠦࠧ呄")+server
			title = title.replace(l11ll1_l1_ (u"࠭ࠥࠨ呅"),l11ll1_l1_ (u"ࠧࠨ呆")).strip(l11ll1_l1_ (u"ࠨࠢࠪ呇")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ呈"),l11ll1_l1_ (u"ࠪࠤࠬ呉")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ告"),l11ll1_l1_ (u"ࠬࠦࠧ呋")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ呌"),l11ll1_l1_ (u"ࠧࠡࠩ呍"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		if l1llll_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭呎"),l1llll_l1_)
			data = list(zip(l1lll11l_l1_,l1llll_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪ呏"),l11ll11l11ll_l1_,data,l1l111llll1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ呐"),l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠼࠵࠾ࠥࠦࠠࠨ呑")+str(data))
	return l1lll11l_l1_,l1llll_l1_
def	l11l11111l1l_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡄࡤ࡛ࡤࡰࡥ࡯ࡱࡽࡏࡨ࠭呒")
	l1lllll1llll_l1_ = l11ll1_l1_ (u"࠭ࠧ呓")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l111ll111_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lllll1llll_l1_ = str(error)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ呔"),l11ll1_l1_ (u"ࠨࠩ呕"),l11ll1_l1_ (u"ࠩࠪ呖"),str(results))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ呗"),l11ll1_l1_ (u"ࠫࠬ员"),l11ll1_l1_ (u"ࠬ࠭呙"),str(l1lllll1llll_l1_))
	# resolveurl l1111l1l1l_l1_ l1lll1l111l_l1_ l1111llll1ll_l1_ with l1lllll1l11ll_l1_ error or l111l11lll1l_l1_ value False
	if not results:
		if l1lllll1llll_l1_==l11ll1_l1_ (u"࠭ࠧ呚"):
			l1lllll1llll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1llll_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ呛"),l11ll1_l1_ (u"ࠨࠩ呜"),l11ll1_l1_ (u"ࠩࠪ呝"),str(l1lllll1llll_l1_))
		l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠢࡉࡥ࡮ࡲࡥࡥࠩ呞")
		l11l11ll1l1l_l1_ += l11ll1_l1_ (u"ࠫࠥ࠭呟")+l1lllll1llll_l1_.splitlines()[-1]
		return l11l11ll1l1l_l1_,[],[]
	return l11ll1_l1_ (u"ࠬ࠭呠"),[l11ll1_l1_ (u"࠭ࠧ呡")],[results]
def	l11l11111l11_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ呢")
	#url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭࠰ࡸ࡬ࡨࡪࡵ࠯ࡹ࠹ࡼࡽ࠹࠷ࡳࠨ呣")
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ呤"),l11ll1_l1_ (u"ࠪࠫ呥"),url,l11ll1_l1_ (u"ࠫࠬ呦"))
	#return l11ll1_l1_ (u"ࠬ࠭呧"),[],[]
	l1lllll1llll_l1_ = l11ll1_l1_ (u"࠭ࠧ周")
	results = False
	try:
		import youtube_dl
		l11l11l11ll1_l1_ = youtube_dl.YoutubeDL({l11ll1_l1_ (u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩ呩"): True})
		results = l11l11l11ll1_l1_.extract_info(url,download=False)
	except Exception as error: l1lllll1llll_l1_ = str(error)
	# youtube_dl l1111l1l1l_l1_ l1lll1l111l_l1_ l1111llll1ll_l1_ with l1lllll1l11ll_l1_ error or l111l11lll1l_l1_ value False
	if not results or l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ呪") not in list(results.keys()):
		if l1lllll1llll_l1_==l11ll1_l1_ (u"ࠩࠪ呫"):
			l1lllll1llll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1llll_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ呬"),l11ll1_l1_ (u"ࠫࠬ呭"),l11ll1_l1_ (u"ࠬ࠭呮"),l1lllll1llll_l1_)
		l11l11ll1l1l_l1_ = l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠥࡌࡡࡪ࡮ࡨࡨࠬ呯")
		l11l11ll1l1l_l1_ += l11ll1_l1_ (u"ࠧࠡࠩ呰")+l1lllll1llll_l1_.splitlines()[-1]
		return l11l11ll1l1l_l1_,[],[]
	else:
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_ in results[l11ll1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ呱")]:
			l1lll11l_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࠩ呲")])
			l1llll_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ味")])
		return l11ll1_l1_ (u"ࠫࠬ呴"),l1lll11l_l1_,l1llll_l1_
def l11l11l11l11_l1_(url):
	if l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ呵") in url:
		l1lll11l_l1_,l1llll_l1_ = l11ll11l1l_l1_(url)
		if l1llll_l1_: return l11ll1_l1_ (u"࠭ࠧ呶"),l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡐࡆࡘࡁࡃࠩ呷"),[],[]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ呸"),[l11ll1_l1_ (u"ࠩࠪ呹")],[url]
def l1l1l1l1ll1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ呺"),l11ll1_l1_ (u"ࠫࠬ呻"),l11ll1_l1_ (u"ࠬ࠭呼"),url)
	l1llll11_l1_,l1111llll111_l1_ = [],[]
	if l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩ命") in url:
		# l111ll1111ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_111111l111l_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1111l1l_l1_?l1l1l1ll1l1_l1_=49e3a27b4
		# l1111ll111l1_l1_: https://l111l1l1111l_l1_.l1lll1lllll_l1_.l1lllll11ll11_l1_.l1llll111ll_l1_/15/items/40animeHD/l111l11ll11l_l1_.l1111l1l_l1_
		# l111ll1111ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l11111ll1l1l_l1_-l111l1ll111l_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1111l1l_l1_?l1l1l1ll1l1_l1_=l1llllll1l11l_l1_
		# l1111ll111l1_l1_: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l11ll11ll1_l1_/l111l111ll11_l1_%20.l1111l1l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ呾"),url,l11ll1_l1_ (u"ࠨࠩ呿"),l11ll1_l1_ (u"ࠩࠪ咀"),False,l11ll1_l1_ (u"ࠪࠫ咁"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭咂"))
		if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咃") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ咄")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ咅"))
			l1111llll111_l1_.append(server)
	elif l11ll1_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ咆") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111ll1111ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l111lll1l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1111ll1l_l1_&l1llllll111l1_l1_=
		# l111ll1111ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?url=l1lllll1l1ll1_l1_==&sub=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111ll11l11l_l1_/l1lllll1l1l11_l1_.l1llllll1llll_l1_&l1llllll111l1_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111111ll1l1_l1_/l1llll1llllll_l1_-1.l11111ll111l_l1_
		# l111ll1111ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l111l111_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l1111ll1llll_l1_/?url=https://photos.l11l1111l11_l1_.l111l1llllll_l1_.l11l1l11l11l_l1_/l111l1l11111_l1_&sub=&l1llllll111l1_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111111ll1l1_l1_/4723b8ebe-1.l11111ll111l_l1_
		# l111ll1111ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l11l111l1_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://l1l11ll1l11_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1111ll1l_l1_&sub=&l1llllll111l1_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111111ll1l1_l1_/2e8bc4c34-1.l11111ll111l_l1_
		# l111ll1111ll_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1111l111l1l_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1111llll_l1_=l11l1111ll11_l1_&l1llllll111l1_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111111ll1l1_l1_/l111ll1111l1_l1_-1.l11111ll111l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭咇"),url,l11ll1_l1_ (u"ࠪࠫ咈"),l11ll1_l1_ (u"ࠫࠬ咉"),l11ll1_l1_ (u"ࠬ࠭咊"),l11ll1_l1_ (u"࠭ࠧ咋"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ和"))
		html = response.content
		l1ll1l1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ咍"),html,re.DOTALL)
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ咎"),str(l1ll1l1lll1l_l1_))
		if l1ll1l1lll1l_l1_:
			l1ll1l1lll1l_l1_ = l1ll1l1lll1l_l1_[0]
			l1l1lll1111l_l1_ = l1ll1111ll11_l1_(l1ll1l1lll1l_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ咏"),str(l1l1lll1111l_l1_))
			l1l1ll11llll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࡜࡜࠰࠭ࡃࡡࡣࠩ࠭ࠩ咐"),l1l1lll1111l_l1_,re.DOTALL)
			if l1l1ll11llll_l1_:
				l1l1ll11llll_l1_ = l1l1ll11llll_l1_[0]
				l1l1ll11llll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ咑"),l1l1ll11llll_l1_)
				for dict in l1l1ll11llll_l1_:
					l1lllll_l1_ = dict[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࠫ咒")]
					l111llll_l1_ = dict[l11ll1_l1_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭咓")]
					#l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࡡࡢࠫ咔")+l111llll_l1_
					l1llll11_l1_.append(l1lllll_l1_)
					server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ咕"))
					l1111llll111_l1_.append(l111llll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ咖")+server)
		elif l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咗") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咘")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ咙"))
			l1111llll111_l1_.append(server)
		# l111ll1111ll_l1_: 5
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l111l111_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l111_l1_/l1111ll1llll_l1_/?url=https://photos.l11l1111l11_l1_.l111l1llllll_l1_.l11l1l11l11l_l1_/l111l1l11111_l1_&sub=&l1llllll111l1_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll11l_l1_/l111111ll1l1_l1_/4723b8ebe-1.l11111ll111l_l1_
		if l11ll1_l1_ (u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧ咚") in url:
			l1lllll_l1_ = url.split(l11ll1_l1_ (u"ࠨࡁࡸࡶࡱࡃࠧ咛"))[1]
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࠫ咜"))[0]
			if l1lllll_l1_:
				l1llll11_l1_.append(l1lllll_l1_)
				l1111llll111_l1_.append(l11ll1_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪ咝"))
	else:
		# l111ll1111ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1llllll11111_l1_.html
		# l1lllll_l1_: http://ok.l111ll111111_l1_/l111ll1lll1l_l1_/1676019108395
		# l111ll1111ll_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1llllll11lll_l1_.html
		# l1lllll_l1_: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1111ll1l_l1_
		l1llll11_l1_.append(url)
		server = SERVER(url,l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ咞"))
		l1111llll111_l1_.append(server)
	if not l1llll11_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ咟"),[],[]
	elif len(l1llll11_l1_)==1: l1lllll_l1_ = l1llll11_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ咠"),l1111llll111_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ咡"),[],[]
		l1lllll_l1_ = l1llll11_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ咢"),[l11ll1_l1_ (u"ࠩࠪ咣")],[l1lllll_l1_]
def l111l111l1l1_l1_(url):
	# test from: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11l111l111l_l1_-l111l111ll1l_l1_-l1111ll111ll_l1_-l11111l1l111_l1_-l11111ll1111_l1_-l11ll11ll1_l1_-1-date.html
	# url = https://l111llll1111_l1_.l1lllll111111_l1_.com/l1111l1lll11_l1_=l111l1l1lll1_l1_
	headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ咤"):l11ll1_l1_ (u"ࠫࡐࡵࡤࡪ࠱ࠪ咥")+str(kodi_version)}
	for l11ll11111_l1_ in range(50):
		time.sleep(0.100)
		response = l1l111l1ll1_l1_(l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ咦"),url,l11ll1_l1_ (u"࠭ࠧ咧"),headers,False,l11ll1_l1_ (u"ࠧࠨ咨"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ咩"))
		if l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ咪") in list(response.headers.keys()):
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ咫")]
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ咬")+headers[l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ咭")]
			return l11ll1_l1_ (u"࠭ࠧ咮"),[l11ll1_l1_ (u"ࠧࠨ咯")],[l1lllll_l1_]
		if response.code!=429: break
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚ࠧ咰"),[],[]
def l111l1l1l1l1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ咱"),l11ll1_l1_ (u"ࠪࠫ咲"),l11ll1_l1_ (u"ࠫࠬ咳"),url)
	# https://photos.l11l1111l11_l1_.l111l1llllll_l1_.l11l1l11l11l_l1_/l111l1l11111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ咴"),url,l11ll1_l1_ (u"࠭ࠧ咵"),l11ll1_l1_ (u"ࠧࠨ咶"),l11ll1_l1_ (u"ࠨࠩ咷"),l11ll1_l1_ (u"ࠩࠪ咸"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩ咹"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨ咺"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_,l111llll_l1_ = l1lllll_l1_[0]
		return l11ll1_l1_ (u"ࠬ࠭咻"),[l111llll_l1_],[l1lllll_l1_]
	return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ咼"),[],[]
def l1ll1l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ咽"),l11ll1_l1_ (u"ࠨࠩ咾"),l11ll1_l1_ (u"ࠩࠪ咿"),url)
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡲࡲࡪ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡨࡩࡦ࠼࠶࠸ࡤ࠳࠼࠶ࡨ࠸࠸ࡥ࠳࠴࠶࠵࠸ࡡࡥ࠳࠻ࡨࡩ࠷࠲ࡤ࠸࠻࠴࠻࠭哀")
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡴࡧ࡯࡬ࡩ࠳ࡥ࡮ࡤࡨࡨ࠳ࡹࡣࡥࡰ࠱ࡸࡴ࠵ࡶࡪࡦࡨࡳࡤࡶ࡬ࡢࡻࡨࡶࡄࡻࡩࡥ࠿࠳ࠪࡻ࡯ࡤ࠾ࡤ࠳࠵࠺࠿࠰࠵ࡣ࠻ࡥࡨ࡬࠷࠺࠷࠹ࡨ࠶࡫࠷࠷࠵࠳ࡦࡪ࠷࠷࠷࠷࠻࠻࠸࠭品")
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ哂"),url,l11ll1_l1_ (u"࠭ࠧ哃"),l11ll1_l1_ (u"ࠧࠨ哄"),l11ll1_l1_ (u"ࠨࠩ哅"),l11ll1_l1_ (u"ࠩࠪ哆"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸࠬ哇"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬ哈"),html)
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭哉"),html,re.DOTALL)
	if l1lllll_l1_: return l11ll1_l1_ (u"࠭ࠧ哊"),[l11ll1_l1_ (u"ࠧࠨ哋")],[l1lllll_l1_[0]]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ哌"),[],[]
def l1llllll1l_l1_(url):
	if l11ll1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭响") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ哎"),url,l11ll1_l1_ (u"ࠫࠬ哏"),l11ll1_l1_ (u"ࠬ࠭哐"),l11ll1_l1_ (u"࠭ࠧ哑"),l11ll1_l1_ (u"ࠧࠨ哒"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨ哓"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ哔"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ哕") in l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ哖"),[l11ll1_l1_ (u"ࠬ࠭哗")],[l1lllll_l1_]
		return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ哘"),[],[]
	else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ哙"),[l11ll1_l1_ (u"ࠨࠩ哚")],[url]
def l1lll1lll11_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ哛"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ哜"),l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ哝"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ哞")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ哟"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ哠"),l11ll1_l1_ (u"ࠨࠩ員"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩ哢"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ哣"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭哤"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ哥"),[l11ll1_l1_ (u"࠭ࠧ哦")],[l1lllll_l1_]
def l1l1l11ll11l_l1_(url):
	headers = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ哧"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ哨")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭哩"),url,l11ll1_l1_ (u"ࠪࠫ哪"),headers,l11ll1_l1_ (u"ࠫࠬ哫"),l11ll1_l1_ (u"ࠬ࠭哬"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ哭"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ哮"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ哯"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ哰"),[l11ll1_l1_ (u"ࠪࠫ哱")],[l1lllll_l1_]
def l1l1lll1ll1_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ哲"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ哳")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ哴"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ哵"),l11ll1_l1_ (u"ࠨࠩ哶"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ哷"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ哸"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ哹"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ哺") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ哻")+l1lllll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ哼"),l11ll1_l1_ (u"ࠨࠩ哽"),l11ll1_l1_ (u"ࠩࠪ哾"),l1lllll_l1_)
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭哿"),[l11ll1_l1_ (u"ࠫࠬ唀")],[l1lllll_l1_]
def l1lll11ll1_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ唁"):l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭唂")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ唃"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠨࠩ唄"),l11ll1_l1_ (u"ࠩࠪ唅"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬ唆"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ唇"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡆࡈࡄࡐࠩ唈"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ唉"),[l11ll1_l1_ (u"ࠧࠨ唊")],[l1lllll_l1_]
def l1llll111l1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ唋"),l11ll1_l1_ (u"ࠩࠪ唌"),l11ll1_l1_ (u"ࠪࠫ唍"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ唎"),url,l11ll1_l1_ (u"ࠬ࠭唏"),l11ll1_l1_ (u"࠭ࠧ唐"),l11ll1_l1_ (u"ࠧࠨ唑"),l11ll1_l1_ (u"ࠨࠩ唒"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡚ࡖࡇࡗࡑ࠱࠶ࡹࡴࠨ唓"))
	html = response.content
	l1llllll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡺࡦࡸࠠࡧࡵࡨࡶࡻࠦ࠽࠯ࠬࡂࠫ࠭࠴ࠪࡀࠫࠪࠦ唔"),html,re.DOTALL|re.IGNORECASE)
	if l1llllll1111l_l1_:
		l1llllll1111l_l1_ = l1llllll1111l_l1_[0][2:]
		#l1llllll1111l_l1_ = l1llllll1111l_l1_.decode(l11ll1_l1_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ唕"))
		l1llllll1111l_l1_ = base64.b64decode(l1llllll1111l_l1_)
		if kodi_version>18.99: l1llllll1111l_l1_ = l1llllll1111l_l1_.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ唖"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ唗"),l1llllll1111l_l1_,re.DOTALL)
	else: l1lllll_l1_ = l11ll1_l1_ (u"ࠧࠨ唘")
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡘ࡛ࡌࡕࡏࠩ唙"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ唚") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ唛")+l1lllll_l1_
	return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ唜"),[l11ll1_l1_ (u"ࠬ࠭唝")],[l1lllll_l1_]
def l11111111111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ唞"),url,l11ll1_l1_ (u"ࠧࠨ唟"),l11ll1_l1_ (u"ࠨࠩ唠"),l11ll1_l1_ (u"ࠩࠪ唡"),l11ll1_l1_ (u"ࠪࠫ唢"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭唣"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ唤"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪ唥"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ唦"),[l11ll1_l1_ (u"ࠨࠩ唧")],[l1lllll_l1_]
def l11lll1l1l_l1_(url):
	id = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ唨"))[-1]
	if l11ll1_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ唩") in url: url = url.replace(l11ll1_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ唪"),l11ll1_l1_ (u"ࠬ࠭唫"))
	url = url.replace(l11ll1_l1_ (u"࠭࠮ࡤࡱࡰ࠳ࠬ唬"),l11ll1_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡳࡥࡵࡣࡧࡥࡹࡧ࠯ࠨ唭"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ售"),url,l11ll1_l1_ (u"ࠩࠪ唯"),l11ll1_l1_ (u"ࠪࠫ唰"),l11ll1_l1_ (u"ࠫࠬ唱"),l11ll1_l1_ (u"ࠬ࠭唲"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ唳"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ唴"),url)
	l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ唵")
	error = re.findall(l11ll1_l1_ (u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ唶"),html,re.DOTALL)
	if error: l11l11ll1l1l_l1_ = error[0]
	url = re.findall(l11ll1_l1_ (u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ唷"),html,re.DOTALL)
	if not url and l11l11ll1l1l_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ唸"),l11ll1_l1_ (u"ࠬ࠭唹"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠨ唺"),l11l11ll1l1l_l1_)
		return l11l11ll1l1l_l1_,[],[]
	l1lllll_l1_ = url[0].replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠪ唻"),l11ll1_l1_ (u"ࠨࠩ唼"))
	l11ll111l1ll_l1_,l11ll11l11ll_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
	owner = re.findall(l11ll1_l1_ (u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡸࡩࡲࡦࡧࡱࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ唽"),html,re.DOTALL)
	if owner: l1111l1ll1l1_l1_,l11l11l11l1l_l1_,l111ll1l1l1l_l1_ = owner[0]
	else: l1111l1ll1l1_l1_,l11l11l11l1l_l1_,l111ll1l1l1l_l1_ = l11ll1_l1_ (u"ࠪࠫ唾"),l11ll1_l1_ (u"ࠫࠬ唿"),l11ll1_l1_ (u"ࠬ࠭啀")
	l111ll1l1l1l_l1_ = l111ll1l1l1l_l1_.replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ啁"),l11ll1_l1_ (u"ࠧ࠰ࠩ啂"))
	l11l11l11l1l_l1_ = escapeUNICODE(l11l11l11l1l_l1_)
	l1lll11l_l1_ = [l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ啃")+l11l11l11l1l_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ啄")]+l11ll111l1ll_l1_
	l1llll_l1_ = [l111ll1l1l1l_l1_]+l11ll11l11ll_l1_
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ啅")+str(len(l1llll_l1_)-1)+l11ll1_l1_ (u"๋ࠫࠥไโࠫࠪ商"),l1lll11l_l1_)
	if l1l_l1_==-1: return l11ll1_l1_ (u"ࠬࡋࡘࡊࡖࠪ啇"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11ll1_l1_ (u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠸࠵࠸ࠦࡶࡴ࡯ࡁࠬ啈")+l111ll1l1l1l_l1_+l11ll1_l1_ (u"ࠧࠧࡶࡨࡼࡹࡃࠧ啉")+l11l11l11l1l_l1_
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ啊")+new_path+l11ll1_l1_ (u"ࠤࠬࠦ啋"))
		return l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ啌"),[],[]
	l1lllll_l1_ =  l1llll_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠫࠬ啍"),[l11ll1_l1_ (u"ࠬ࠭啎")],[l1lllll_l1_]
def l11111lll_l1_(l1lllll_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ問"),l1lllll_l1_,l11ll1_l1_ (u"ࠧࠨ啐"),l11ll1_l1_ (u"ࠨࠩ啑"),l11ll1_l1_ (u"ࠩࠪ啒"),l11ll1_l1_ (u"ࠪࠫ啓"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃࡑࡎࡖࡆ࠳࠱ࡴࡶࠪ啔"))
	html = response.content
	if l11ll1_l1_ (u"ࠬ࠴ࡪࡴࡱࡱࠫ啕") in l1lllll_l1_: url = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭啖"),html,re.DOTALL)
	else: url = re.findall(l11ll1_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ啗"),html,re.DOTALL)
	if not url: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆࡔࡑࡒࡂࠩ啘"),[],[]
	url = url[0]
	if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ啙") not in url: url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ啚")+url
	return l11ll1_l1_ (u"ࠫࠬ啛"),[l11ll1_l1_ (u"ࠬ࠭啜")],[url]
def l111llllll1l_l1_(url):
	# http://l1111l11l1ll_l1_.l1lll1ll111l_l1_/l11l11l1ll11_l1_.html?l11l111l1lll_l1_=l111l111llll_l1_
	# http://l1111l11l1ll_l1_.l1lll1ll111l_l1_/l111llllll11_l1_?op=l1lllll11llll_l1_&id=l11l11l1ll11_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ啝") : l11ll1_l1_ (u"ࠧࠨ啞") }
	if l11ll1_l1_ (u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ啟") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ啠"),headers,l11ll1_l1_ (u"ࠪࠫ啡"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࠭啢"))
		#xbmc.log(html)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭啣"),l11ll1_l1_ (u"࠭ࠧ啤"),url,html)
		items = re.findall(l11ll1_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭啥"),html,re.DOTALL)
		if items: return l11ll1_l1_ (u"ࠨࠩ啦"),[l11ll1_l1_ (u"ࠩࠪ啧")],[items[0]]
		else:
			message = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡷࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ啨"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ啩"),l11ll1_l1_ (u"ࠬ࠭啪"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨ啫"),message[0])
				return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࠨ啬")+message[0],[],[]
	else:
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ啭"),l11ll1_l1_ (u"ࠩࠪ啮"),l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ啯"))
		#url,l1ll1lll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ啰"))
		#l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.lower()
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠨ啱")
		# l11l1l1ll_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ啲"),headers,l11ll1_l1_ (u"ࠧࠨ啳"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦࠪ啴"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ啵"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ啶"),[],[]
		l1lllll11l_l1_ = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		if l11ll1_l1_ (u"ࠫ࠳ࡸࡡࡳࠩ啷") in block or l11ll1_l1_ (u"ࠬ࠴ࡺࡪࡲࠪ啸") in block: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫ啹"),[],[]
		items = re.findall(l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ啺"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l11l_l1_(payload)
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll11l_l1_,data,headers,l11ll1_l1_ (u"ࠨࠩ啻"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫ啼"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨ啽"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ啾"),[],[]
		download = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬ啿"),block,re.DOTALL)
		l1111111l1l1_l1_,l1lll11l_l1_,l11l1111l1ll_l1_,l1llll_l1_,l11111lll111_l1_ = [],[],[],[],[]
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ喀") in l1lllll_l1_:
				l1111111l1l1_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11l1111l1ll_l1_
				if l1111111l1l1_l1_[0]==l11ll1_l1_ (u"ࠧ࠮࠳ࠪ喁"): l1lll11l_l1_.append(l11ll1_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭喂")+l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ喃")+l1ll1lll1l1_l1_)
				else:
					for title in l1111111l1l1_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ善")+l11ll1_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ喅")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠬࠦࠧ喆")+title)
			else:
				title = title.replace(l11ll1_l1_ (u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨ喇"),l11ll1_l1_ (u"ࠧࠨ喈"))
				title = title.strip(l11ll1_l1_ (u"ࠨࠤࠪ喉"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ喊"),l11ll1_l1_ (u"ࠪࠫ喋"),title,str(l11111lll111_l1_))
				title = l11ll1_l1_ (u"ู๊ࠫࠥาใิࠤࠥิวึࠢࠪ喌")+l11ll1_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ喍")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"࠭ࠠࠨ喎")+title
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦࠩ喏") + download
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll_l1_,l11ll1_l1_ (u"ࠨࠩ喐"),headers,l11ll1_l1_ (u"ࠩࠪ喑"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬ喒"))
		items = re.findall(l11ll1_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣ喓"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11ll1_l1_ (u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩ喔")+l11ll1_l1_ (u"࠭ࠠ࡮ࡲ࠷ࠤࠬ喕")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠩ喖")+resolution.split(l11ll1_l1_ (u"ࠨࡺࠪ喗"))[1]
			l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ喘")+id+l11ll1_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ喙")+mode+l11ll1_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ喚")+hash
			l11111lll111_l1_.append(resolution)
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		l11111lll111_l1_ = set(l11111lll111_l1_)
		l1111l11llll_l1_,l111ll1ll11l_l1_ = [],[]
		for title in l1lll11l_l1_:
			#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭喛"),l11ll1_l1_ (u"࠭ࠧ喜"),title,l11ll1_l1_ (u"ࠧࠨ喝"))
			res = re.findall(l11ll1_l1_ (u"ࠣࠢࠫࡠࡩ࠰ࡸࡽ࡞ࡧ࠮࠮ࠬࠦࠣ喞"),title+l11ll1_l1_ (u"ࠩࠩࠪࠬ喟"),re.DOTALL)
			for resolution in l11111lll111_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11ll1_l1_ (u"ࠪࡼࠬ喠"))[1])
			l1111l11llll_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1llll_l1_)):
			items = re.findall(l11ll1_l1_ (u"ࠦࠫࠬࠨ࠯ࠬࡂ࠭࠭ࡢࡤࠫࠫࠩࠪࠧ喡"),l11ll1_l1_ (u"ࠬࠬࠦࠨ喢")+l1111l11llll_l1_[i]+l11ll1_l1_ (u"࠭ࠦࠧࠩ喣"),re.DOTALL)
			l111ll1ll11l_l1_.append( [l1111l11llll_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l111ll1ll11l_l1_ = sorted(l111ll1ll11l_l1_, key=lambda x: x[3], reverse=True)
		l111ll1ll11l_l1_ = sorted(l111ll1ll11l_l1_, key=lambda x: x[2], reverse=False)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for i in range(len(l111ll1ll11l_l1_)):
			l1lll11l_l1_.append(l111ll1ll11l_l1_[i][0])
			l1llll_l1_.append(l111ll1ll11l_l1_[i][1])
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ喤"),[],[]
	return l11ll1_l1_ (u"ࠨࠩ喥"),l1lll11l_l1_,l1llll_l1_
def l111lll1111l_l1_(url):
	# http://l1lllll11lll1_l1_.com/717254
	parts = url.split(l11ll1_l1_ (u"ࠩࡂࠫ喦"))
	l111lll_l1_ = parts[0]
	headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ喧") : l11ll1_l1_ (u"ࠫࠬ喨") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭喩"),headers,l11ll1_l1_ (u"࠭ࠧ喪"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺࠧ喫"))
	items = re.findall(l11ll1_l1_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ喬"),html,re.DOTALL)
	url = items[0]
	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllll1l_l1_(url)
	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ喭"),[l11ll1_l1_ (u"ࠪࠫ單")],[url]
def l1111ll1lll1_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ喯") : l11ll1_l1_ (u"ࠬ࠭喰") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"࠭ࠧ喱"),headers,l11ll1_l1_ (u"ࠧࠨ喲"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ喳"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡺࡸ࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ喴"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠪࠫ喵"),[l11ll1_l1_ (u"ࠫࠬ営")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨ喷"),[],[]
def l111lll11l1l_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ喸") : l11ll1_l1_ (u"ࠧࠨ喹") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠨࠩ喺"),headers,l11ll1_l1_ (u"ࠩࠪ喻"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ喼"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧࠤ࠯ࠦ࠭࡮ࡴࡵ࠰࠭ࡃ࠮ࠨࠧ喽"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠬ࠭喾"),[l11ll1_l1_ (u"࠭ࠧ喿")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨ嗀"),[],[]
def l1ll1l1l1l1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嗁"),l11ll1_l1_ (u"ࠩࠪ嗂"),l11ll1_l1_ (u"ࠪࠫ嗃"),url)
	# l11l1l1ll_l1_    https://show.l1111l1llll1_l1_.com/l1111l1l1l11_l1_-l1111l1l1111_l1_/l1111l1l1111_l1_-l111l1ll11ll_l1_.l1ll1lll1l_l1_?action=l11111lll11l_l1_&post=32513&l1ll1l1l1ll_l1_=1&type=l1lllll111l_l1_
	# download https://show.l1111l1llll1_l1_.com/l1l1_l1_/l1llllllll1l1_l1_
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠫࠬ嗄")
	# l11l1l1ll_l1_
	if l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩ嗅") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ嗆"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ嗇")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭嗈"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ嗉"),l11ll1_l1_ (u"ࠪࠫ嗊"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠶ࡳࡪࠧ嗋"))
		l11ll1ll_l1_ = response.content
		if l11ll1ll_l1_.startswith(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ嗌")): l111lll_l1_ = l11ll1ll_l1_
		else:
			l11l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠧࠨࡵࡵࡧࡂࡡࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜ࠩࠥࡡࠬ࠭ࠧ嗍"),l11ll1ll_l1_,re.DOTALL)
			if l11l111_l1_:
				l111lll_l1_ = l11l111_l1_[0]
				l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ嗎"),l111lll_l1_,re.DOTALL)
				if l11l111_l1_:
					l111lll_l1_ = l1111_l1_(l11l111_l1_[0])
					return l11ll1_l1_ (u"ࠨࠩ嗏"),[l11ll1_l1_ (u"ࠩࠪ嗐")],[l111lll_l1_]
	# download
	elif l11ll1_l1_ (u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫ嗑") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嗒"),url,l11ll1_l1_ (u"ࠬ࠭嗓"),l11ll1_l1_ (u"࠭ࠧ嗔"),True,l11ll1_l1_ (u"ࠧࠨ嗕"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠲ࡵࡷࠫ嗖"))
		l11ll1ll_l1_ = response.content
		if l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ嗗") in list(response.headers.keys()): l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ嗘")]
		else: l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗙"),l11ll1ll_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嗚"),l11ll1_l1_ (u"࠭ࠧ嗛"),l111lll_l1_,str(2222))
	if l11ll1_l1_ (u"ࠧ࠰ࡸ࠲ࠫ嗜") in l111lll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡩ࠳ࠬ嗝") in l111lll_l1_:
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡪ࠴࠭嗞"),l11ll1_l1_ (u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ嗟"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴ࡼ࠯ࠨ嗠"),l11ll1_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ嗡"))
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嗢"),l11ll1_l1_ (u"ࠧࠨ嗣"),l111lll_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭嗤"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ嗥"),l11ll1_l1_ (u"ࠪࠫ嗦"),l11ll1_l1_ (u"ࠫࠬ嗧"),l11ll1_l1_ (u"ࠬ࠭嗨"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠹ࡲࡥࠩ嗩"))
		l11ll1ll_l1_ = response.content
		items = re.findall(l11ll1_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤ࡯ࡥࡧ࡫࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ嗪"),l11ll1ll_l1_,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠫ嗫"),l11ll1_l1_ (u"ࠩࠪ嗬"))
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嗭"),l11ll1ll_l1_,re.DOTALL)
			if items:
				l1lllll_l1_ = items[0]
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡢࠧ嗮"),l11ll1_l1_ (u"ࠬ࠭嗯"))
				l1lll11l_l1_.append(l11ll1_l1_ (u"࠭ࠧ嗰"))
				l1llll_l1_.append(l1lllll_l1_)
	else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嗱"),[l11ll1_l1_ (u"ࠨࠩ嗲")],[l111lll_l1_]
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嗳"),l11ll1_l1_ (u"ࠪࠫ嗴"),str(l11ll11l1_l1_),l111lll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ嗵"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭嗶"),l1lll11l_l1_,l1llll_l1_
def l1l1llll1l11_l1_(url):
	# l11l1l1ll_l1_ l1111l1l_l1_  https://l111l1111l1l_l1_.l11l1111l11l_l1_.l1llll111ll_l1_/l11llll1l1l_l1_/l1llll1llll11_l1_.l1ll1lll1l_l1_?s=07&id=l11l11lll111_l1_,&l1lll1_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l11111ll111l_l1_&l111ll11llll_l1_=l1lllll1llll1_l1_&l1111ll1l111_l1_=l1lllll111lll_l1_
	# l11l1l1ll_l1_ l1llll111_l1_ https://l11l1111lll1_l1_.l11l1111l11l_l1_.l1llll111ll_l1_/l11llll1l1l_l1_/l1llllll1ll11_l1_.l1ll1lll1l_l1_?l111lll1lll1_l1_=l1111l11ll11_l1_&l111l11ll1l1_l1_=8a26a6cc61a884e89076504130c71626&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111ll111l_l1_&l111ll11llll_l1_=l1lllll1llll1_l1_&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111ll111l_l1_&l111ll11llll_l1_=l1lllll1llll1_l1_&l1111ll1l111_l1_=l1111l11ll1l_l1_
	# download https://www.l111lllll1ll_l1_.l1111l1l1l1l_l1_/l111ll1l1ll1_l1_?server=l1llllll1l1l1_l1_&id=l111l1l1ll11_l1_,,
	# l1l111l1l_l1_ https://l111lllll1ll_l1_.l1lll1111l_l1_/l1l111l1l_l1_/l111ll11l111_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ嗷"),url,l11ll1_l1_ (u"ࠧࠨ嗸"),l11ll1_l1_ (u"ࠨࠩ嗹"),l11ll1_l1_ (u"ࠩࠪ嗺"),l11ll1_l1_ (u"ࠪࠫ嗻"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠲ࡵࡷࠫ嗼"))
	html = response.content
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠬ࠭嗽")
	if l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ嗾") in url or l11ll1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ嗿") in url:
		if l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ嘀") in url:
			l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘁"),html,re.DOTALL)
			l111lll_l1_ = l111lll_l1_[0]
		else: l111lll_l1_ = url
		if l11ll1_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ嘂") not in l111lll_l1_: return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ嘃"),[l11ll1_l1_ (u"ࠬ࠭嘄")],[l111lll_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ嘅"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ嘆"),l11ll1_l1_ (u"ࠨࠩ嘇"),l11ll1_l1_ (u"ࠩࠪ嘈"),l11ll1_l1_ (u"ࠪࠫ嘉"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠳ࡰࡧࠫ嘊"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴࡰࡳࠨ嘋"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘌"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1ll1l1l1lll_l1_ in items:
				l1lll11l_l1_.append(l1ll1l1l1lll_l1_)
				l1llll_l1_.append(l1lllll_l1_)
	elif l11ll1_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡤࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩ嘍") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬ嘎"),html,re.DOTALL)
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嘏"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ嘐"),l11ll1_l1_ (u"ࠫࠬ嘑"),l11ll1_l1_ (u"ࠬ࠭嘒"),l11ll1_l1_ (u"࠭ࠧ嘓"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠷ࡷࡪࠧ嘔"))
		html = response.content
		l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ嘕"),html,re.DOTALL)
		l11l111_l1_ = l11l111_l1_[0]
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠩࠪ嘖"))
		l1llll_l1_.append(l11l111_l1_)
	elif l11ll1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡲࡩ࡯࡭ࠪ嘗") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡩࡥ࡯ࡶࡨࡶࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘘"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嘙"),[l11ll1_l1_ (u"࠭ࠧ嘚")],[l111lll_l1_]
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓ࡛࡙࠴ࡖࠩ嘛"),[],[]
	return l11ll1_l1_ (u"ࠨࠩ嘜"),l1lll11l_l1_,l1llll_l1_
def l11111l1ll_l1_(url):
	# https://l111lll11lll_l1_.l1111ll11111_l1_/l1l1111lll1_l1_?call=l111ll11l1ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111l1lll_l1_=l111l111l1ll_l1_
	# https://l111lll11lll_l1_.l1111ll11111_l1_/l1l1111lll1_l1_?call=l111ll11l1ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111l1lll_l1_=l1111l1l11ll_l1_
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ嘝"),1)[0].strip(l11ll1_l1_ (u"ࠪࡃࠬ嘞")).strip(l11ll1_l1_ (u"ࠫ࠴࠭嘟")).strip(l11ll1_l1_ (u"ࠬࠬࠧ嘠"))
	l1lll11l_l1_,l1llll_l1_,items,l11l111_l1_ = [],[],[],l11ll1_l1_ (u"࠭ࠧ嘡")
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嘢"):l11ll1_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨ嘣") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嘤"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ嘥"),headers,True,l11ll1_l1_ (u"ࠫࠬ嘦"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠴ࡷࡹ࠭嘧"))
	if l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ嘨") in list(response.headers.keys()): l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ嘩")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ嘪"),l11l111_l1_,l11ll1_l1_ (u"ࠩࠪ嘫"),headers,False,l11ll1_l1_ (u"ࠪࠫ嘬"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠴ࡱࡨࠬ嘭"))
	#if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ嘮") in response.headers: l11l111_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ嘯")]
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ嘰"),l11ll1_l1_ (u"ࠨࠩ嘱"),l11l111_l1_,response.content)
	if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嘲") in l11l111_l1_:
		# https://l1111l111l_l1_.top/f/l111l1lll111_l1_/?l111ll1111_l1_=l11l1l111l11_l1_
		# https://l1111l111l_l1_.top/v/l111l1lll111_l1_/?l111ll1111_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11ll1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ嘳") in url: l11l111_l1_ = l11l111_l1_.replace(l11ll1_l1_ (u"ࠫ࠴࡬࠯ࠨ嘴"),l11ll1_l1_ (u"ࠬ࠵ࡶ࠰ࠩ嘵"))
		l11l111lll11_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"࠭࠿ࡑࡊࡓࡗࡎࡊ࠽ࠨ嘶"))[1]
		headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嘷"):headers[l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嘸")] , l11ll1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ嘹"):l11ll1_l1_ (u"ࠪࡔࡍࡖࡓࡊࡆࡀࠫ嘺")+l11l111lll11_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嘻"),l11l111_l1_,l11ll1_l1_ (u"ࠬ࠭嘼"),headers,False,l11ll1_l1_ (u"࠭ࠧ嘽"),l11ll1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ嘾"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1lll1_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠨࠩ嘿"),headers,l11ll1_l1_ (u"ࠩࠪ噀"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠴ࡴࡧࠫ噁"))
		if l11ll1_l1_ (u"ࠫ࠴࡬࠯ࠨ噂") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠬࡂࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噃"),html,re.DOTALL)
		elif l11ll1_l1_ (u"࠭࠯ࡷ࠱ࠪ噄") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噅"),html,re.DOTALL)
		if items: return [],[l11ll1_l1_ (u"ࠨࠩ噆")],[ items[0] ]
		elif l11ll1_l1_ (u"ࠩ࠿࡬࠶ࡄ࠴࠱࠶࠿࠳࡭࠷࠾ࠨ噇") in html:
			return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣื๏ืแาࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎ࠥ๎ๅึัิ๋๋ࠥๆࠡษ็ษ๋ะั็ฬࠣห้ิวึหࠣฬ่࠭噈"),[],[]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚ࠧ噉"),[],[]
	#xbmc.log(html)
def l1111ll1ll1_l1_(l1lllll_l1_):
	# https://l11l1l111lll_l1_.net/?l11lll11_l1_=147043&l11llll1_l1_=5
	parts = re.findall(l11ll1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ噊"),l1lllll_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ噋"),re.DOTALL|re.IGNORECASE)
	l11lll11_l1_,l11llll1_l1_ = parts[0]
	url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮࠮࡯ࡧࡷ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ噌")+l11lll11_l1_+l11ll1_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ噍")+l11llll1_l1_
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭噎"):l11ll1_l1_ (u"ࠪࠫ噏") , l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ噐"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭噑") }
	l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ噒"),headers,l11ll1_l1_ (u"ࠧࠨ噓"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧ噔"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ噕"),l11ll1_l1_ (u"ࠪࠫ噖"),url,l111lll_l1_)
	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllll1l_l1_(l111lll_l1_)
	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ噗"),[l11ll1_l1_ (u"ࠬ࠭噘")],[l111lll_l1_]
def l1ll11lll1l1_l1_(url):
	# https://l1lllll11l1ll_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111l1ll1lll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111ll1lllll_l1_=1608181746
	server = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ噙"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ噚"):server,l11ll1_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ噛"):l11ll1_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ噜")}
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ噝"),url,l11ll1_l1_ (u"ࠫࠬ噞"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠬ࠭噟"),l11ll1_l1_ (u"࠭ࠧ噠"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ噡"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ噢"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠩࠪ噣")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ噤"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ噥"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠬ࠭噦"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噧"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡈࡏࡍࡂࠩ器"),[],[]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ噩"),[l11ll1_l1_ (u"ࠩࠪ噪")],[l111lll_l1_]
def l1l1ll111lll_l1_(url):
	# https://l11l1l11l111_l1_.l1lllllllllll_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111l1ll1lll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111ll1lllll_l1_=1608181746
	# https://l11l1l11l111_l1_.l1111ll11111_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111l1ll1lll_l1_=l11l11l1llll_l1_&l111ll1lllll_l1_=1684182121
	server = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ噫"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ噬"):server,l11ll1_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ噭"):l11ll1_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭噮")}
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ噯"),url,l11ll1_l1_ (u"ࠨࠩ噰"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ噱"),l11ll1_l1_ (u"ࠪࠫ噲"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡇࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ噳"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭噴"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"࠭ࠧ噵")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噶"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭噷"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠩࠪ噸"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	if not l111lll_l1_:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ噹"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡆࡅࡌࡑࡆ࠭噺"),[],[]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ噻"),[l11ll1_l1_ (u"࠭ࠧ噼")],[l111lll_l1_]
def l1l11ll1_l1_(l1lllll_l1_):
	# https://w.l1111l111l11_l1_.l11l1111111l_l1_/l1111l1l1l11_l1_-content/l11l11ll1lll_l1_/l11111llllll_l1_/l111llllllll_l1_/l11111lllll1_l1_/l111l1111l11_l1_/l1111l1l1lll_l1_.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ噽"),l11ll1_l1_ (u"ࠨࠩ噾"),l1lllll_l1_,html)
	parts = re.findall(l11ll1_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ噿"),l1lllll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭嚀"),re.DOTALL)
	url,l11lll11_l1_,l11llll1_l1_ = parts[0]
	data = {l11ll1_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬ嚁"):l11lll11_l1_,l11ll1_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬ嚂"):l11llll1_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ嚃"),url,data,l11ll1_l1_ (u"ࠧࠨ嚄"),l11ll1_l1_ (u"ࠨࠩ嚅"),l11ll1_l1_ (u"ࠩࠪ嚆"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑࡈࡇࡍ࠮࠳ࡶࡸࠬ嚇"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚈"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嚉"),[l11ll1_l1_ (u"࠭ࠧ嚊")],[l111lll_l1_]
def l1ll1l1lll_l1_(url):
	# https://l111ll1ll1ll_l1_.l1lll11111_l1_-l111lll11ll1_l1_.com/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1111ll1l1l1_l1_
	# https://l.l1111l1ll111_l1_.l1111l1l1l1l_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ嚋"),url,l11ll1_l1_ (u"ࠨࠩ嚌"),l11ll1_l1_ (u"ࠩࠪ嚍"),l11ll1_l1_ (u"ࠪࠫ嚎"),l11ll1_l1_ (u"ࠫࠬ嚏"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࠶ࡹࡴࠨ嚐"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚑"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嚒"),[l11ll1_l1_ (u"ࠨࠩ嚓")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ嚔"),[],[]
def l1lll111ll_l1_(url):
	# https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/l1111l1l1l11_l1_-content/l11l11ll1lll_l1_/old/l1lll11_l1_/server.l1ll1lll1l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嚕"),url,l11ll1_l1_ (u"ࠫࠬ嚖"),l11ll1_l1_ (u"ࠬ࠭嚗"),l11ll1_l1_ (u"࠭ࠧ嚘"),l11ll1_l1_ (u"ࠧࠨ嚙"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪ嚚"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嚛"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嚜"),[l11ll1_l1_ (u"ࠫࠬ嚝")],[l1lllll_l1_]
def l1ll1l1l1l_l1_(url):
	# https://l1l11l1l111_l1_.l1l11ll1l111_l1_.cc/l1111l1l1l11_l1_-content/l11l11ll1lll_l1_/l111111l11ll_l1_%20Now%20New/l1llllllll111_l1_.l1ll1lll1l_l1_?action=l111lll111l1_l1_&index=00&id=58504
	# https://l111l1ll1ll1_l1_.l1l11ll1l111_l1_.net/l1llllllll11l_l1_/2021/04/05/_1111ll1ll11_l1_-l11l1l1111l1_l1_.l1llll1lllll1_l1_ 200.l1lllllll1111_l1_.2020.l111111111ll_l1_/[l111111l11ll_l1_-l11l1l1111l1_l1_.l11111l111l1_l1_] 200.l1lllllll1111_l1_.2020.l111111111ll_l1_-360p.l1111l1l_l1_
	l1lllll1l1_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ嚞"))
	if l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭嚟") in url:
		headers = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ嚠"):l1lllll1l1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ嚡"),url,l11ll1_l1_ (u"ࠩࠪ嚢"),headers,l11ll1_l1_ (u"ࠪࠫ嚣"),l11ll1_l1_ (u"ࠫࠬ嚤"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭嚥"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚦"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			if l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ嚧") in l111lll_l1_:
				l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ嚨"),l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ嚩"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嚪"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ嚫"),headers,l11ll1_l1_ (u"ࠬ࠭嚬"),l11ll1_l1_ (u"࠭ࠧ嚭"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ嚮"))
				l11ll1ll_l1_ = response.content
				items = re.findall(l11ll1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚯"),l11ll1ll_l1_,re.DOTALL)
				l1lll11l_l1_,l1llll_l1_ = [],[]
				l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭嚰"))
				for l1lllll_l1_,l111llll_l1_ in reversed(items):
					l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭嚱")+l1llll1l1l_l1_
					l1lll11l_l1_.append(l111llll_l1_)
					l1llll_l1_.append(l1lllll_l1_)
				return l11ll1_l1_ (u"ࠫࠬ嚲"),l1lll11l_l1_,l1llll_l1_
			else: return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嚳"),[l11ll1_l1_ (u"࠭ࠧ嚴")],[l111lll_l1_]
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ嚵")+l1lllll1l1_l1_
	return l11ll1_l1_ (u"ࠨࠩ嚶"),[l11ll1_l1_ (u"ࠩࠪ嚷")],[l111lll_l1_]
def l111l11l1ll1_l1_(l1lllll_l1_):
	# https://l1l11ll1l111_l1_.l11l1111111l_l1_/l1111l1l1l11_l1_-content/l11l11ll1lll_l1_/l111lll11111_l1_/l1llllllll1ll_l1_/server.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	# https://l11l111l1111_l1_.l1l11ll1l111_l1_.net/l1llllllll11l_l1_/2020/08/14/_1111ll1ll11_l1_-l11l1l1111l1_l1_.l1llll1lllll1_l1_ l111111l1111_l1_.l111l111lll1_l1_.2020.l1111lll1l1l_l1_-l111l11l11ll_l1_/[l111111l11ll_l1_-l11l1l1111l1_l1_.l11111l111l1_l1_] l111111l1111_l1_.l111l111lll1_l1_.2020.l1111lll1l1l_l1_-l111l11l11ll_l1_-1080p.l1111l1l_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ嚸"),l11ll1_l1_ (u"ࠫࠬ嚹"),url,html)
	l1lllll1l1_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ嚺"))
	if l11ll1_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭嚻") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭嚼"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ嚽"),re.DOTALL)
		url,l11lll11_l1_,l11llll1_l1_ = parts[0]
		data = {l11ll1_l1_ (u"ࠩ࡬ࡨࠬ嚾"):l11lll11_l1_,l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ嚿"):l11llll1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ囀"),url,data,l11ll1_l1_ (u"ࠬ࠭囁"),l11ll1_l1_ (u"࠭ࠧ囂"),l11ll1_l1_ (u"ࠧࠨ囃"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ囄"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ囅"),html,re.DOTALL)[0]
		if l11ll1_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ囆") in l111lll_l1_:
			headers = {l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ囇"):l1lllll1l1_l1_,l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ囈"):l11ll1_l1_ (u"࠭ࠧ囉")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ囊"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ囋"),headers,l11ll1_l1_ (u"ࠩࠪ囌"),l11ll1_l1_ (u"ࠪࠫ囍"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ囎"))
			l11ll1ll_l1_ = response.content
			items = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ囏"),l11ll1ll_l1_,re.DOTALL)
			l1lll11l_l1_,l1llll_l1_ = [],[]
			l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ囐"))
			for l1lllll_l1_,l111llll_l1_ in reversed(items):
				l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ囑")+l1llll1l1l_l1_
				l1lll11l_l1_.append(l111llll_l1_)
				l1llll_l1_.append(l1lllll_l1_)
			return l11ll1_l1_ (u"ࠨࠩ囒"),l1lll11l_l1_,l1llll_l1_
		else: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ囓"),[l11ll1_l1_ (u"ࠪࠫ囔")],[l111lll_l1_]
	else:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ囕")+l1lllll1l1_l1_
		return l11ll1_l1_ (u"ࠬ࠭囖"),[l11ll1_l1_ (u"࠭ࠧ囗")],[l1lllll_l1_]
def l111ll1ll_l1_(l1lllll_l1_):
	# http://l11l11l1l1ll_l1_.tv/?l11lll11_l1_=159485&l11llll1_l1_=0
	if l11ll1_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ囘") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ囙"),l1lllll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ囚"),re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		host = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ四"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ囜"),l11ll1_l1_ (u"ࠬ࠭囝"),l1lllll_l1_,host)
		url = host+l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ回")+l11lll11_l1_+l11ll1_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ囟")+l11llll1_l1_
		headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ因"):l11ll1_l1_ (u"ࠩࠪ囡") , l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭团"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ団") }
		l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭囤"),headers,l11ll1_l1_ (u"࠭ࠧ囥"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠷ࡳࡵࠩ囦"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ囧"),l11ll1_l1_ (u"ࠩࠪ囨")).replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭囩"),l11ll1_l1_ (u"ࠫࠬ囪"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭囫"),l11ll1_l1_ (u"࠭ࠧ囬"),url,l111lll_l1_)
		#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllll1l_l1_(l111lll_l1_)
		#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ园"),[l11ll1_l1_ (u"ࠨࠩ囮")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭囯") in l1lllll_l1_:
		counts = 0
		while l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ困") in l1lllll_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ囱"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭囲"),l11ll1_l1_ (u"࠭ࠧ図"),l11ll1_l1_ (u"ࠧࠨ围"),l11ll1_l1_ (u"ࠨࠩ囵"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫ囶"))
			if l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ囷") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭囸")]
			counts += 1
		return l11ll1_l1_ (u"ࠬ࠭囹"),[l11ll1_l1_ (u"࠭ࠧ固")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ囻"),[],[]
def l11l11ll1_l1_(url):
	# https://l1111ll1111l_l1_.l111111llll1_l1_.me/l/l11l11ll11l1_l1_=
	# https://l111ll11ll1l_l1_.l11111111l1l_l1_.net/l1l111l1l_l1_-l1l111l1l_l1_-l1111111ll11_l1_.html
	# https://m.l11111111l1l_l1_.net/l1111111ll11_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ囼"),l11ll1_l1_ (u"ࠩࠪ国"),l11ll1_l1_ (u"ࠪࠫ图"),url)
	server = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ囿"))
	if l11ll1_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ圀") in url and l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭圁") not in url: url = server+l11ll1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ圂")+url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ圃"))[-1]+l11ll1_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ圄")
	headers = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ圅"):server,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ圆"):l11llllll_l1_()}
	if l11ll1_l1_ (u"ࠬ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ圇") in url:
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ圈"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭圉")}
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭圊"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,True,l11ll1_l1_ (u"ࠩࠪ國"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠳ࡶࡸࠬ圌"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ圍"),html,re.DOTALL|re.IGNORECASE)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠬ࠭圎"),[l11ll1_l1_ (u"࠭ࠧ圏")],[l1lllll_l1_[0]]
	elif l11ll1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ圐") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ圑"),headers,l11ll1_l1_ (u"ࠩࠪ園"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ圓"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圔"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0].replace(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ圕"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ圖"))
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠧࠨ圗"),[l11ll1_l1_ (u"ࠨࠩ團")],[l1lllll_l1_]
	else:
		l1111ll11l11_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭圙"),url,l11ll1_l1_ (u"ࠪࠫ圚"),headers,l11ll1_l1_ (u"ࠫࠬ圛"),l11ll1_l1_ (u"ࠬ࠭圜"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨ圝"))
		html = l1111ll11l11_l1_.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯࠳࡮ࡲࡦࡨࠣࡁࠥࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ圞"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])+l11ll1_l1_ (u"ࠨࠨࡧࡁ࠶࠭土")
			l1ll1111l_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭圠"),l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ圡"),headers,l11ll1_l1_ (u"ࠫࠬ圢"),l11ll1_l1_ (u"ࠬ࠭圣"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠹ࡺࡨࠨ圤"))
			html = l1ll1111l_l1_.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡧࡺ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圥"),html,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠨࠩ圦"),[l11ll1_l1_ (u"ࠩࠪ圧")],[l1lllll_l1_]
		if l11ll1_l1_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧ在") in list(l1111ll11l11_l1_.headers.keys()):
			cookies = l1111ll11l11_l1_.headers[l11ll1_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ圩")]
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡥ࡬࡯࡭ࡢ࠲࠯ࡅ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧ圪"),cookies,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ圫"),[l11ll1_l1_ (u"ࠧࠨ圬")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡔࡇࡈࡈࠬ圭"),[],[]
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠤࠢࡱࡳࡹࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠊࠊࠋࠦࠤ࡮ࡺࠠ࡯ࡧࡨࡨࡸࠦࡣࡰࡱ࡮࡭ࡪࠦࡦࡳࡱࡰࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠋࠋࠌࠧࠥࡉ࡯ࡰ࡭࡬ࡩ࠿ࠦࡣࡧࡡࡦࡰࡪࡧࡲࡢࡰࡦࡩࡂࡉࡍࡦ࠰ࡋࡏࡌࡗ࡫࡮ࡹࡱࡗ࡛ࡻ࡮ࡻࡘࡌࡴࡶࡵࡷࡲࡕࡄ࡞ࡨࡶ࡮ࡇ࠹࡭ࡆࡕ࡛ࡏࡒࡤ࡜ࡆࡋ࠶࠭࠲࠸࠹࠷࠶࠷࠲࠱࠲࠹࠱࠵࠳࠲࠶࠲ࠍࠍࠎࡹࡥࡳࡸࡨࡶࠥࡃࠠࡔࡇࡕ࡚ࡊࡘࠨࡶࡴ࡯࠰ࠬࡻࡲ࡭ࠩࠬࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾ࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࠼ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠭࠯ࠬࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡷࡪࡸࡶࡦࡴࢀࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࡼࡳࡧ࠱ࡍࡌࡔࡏࡓࡇࡆࡅࡘࡋࠩࠋࠋࠌ࡭࡫ࠦ࡬ࡪࡰ࡮ࡷ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡪࡨࠣࠫࡪࡳࡢࡦࡦ࠰ࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠬ࡜ࠩࠪࡡ࠱ࡡ࡬ࡪࡰ࡮ࡡࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠠࡶࡴ࡯ࠤࡂࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠲ࡨࡵ࡯࡯࠭ࠏࠏࠉࠤ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌࠍࠨ࡯ࡦࠡࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠎࠎࠏࠣࠊࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠩࠉࡳࡧࡷࡹࡷࡴࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࠋࠦࡩࡱࡹࡥ࠻ࠢࡸࡶࡱࠦ࠽ࠡ࡮࡬ࡲࡰࠐࠉࠣࠤࠥ圮")
	#if l11ll1_l1_ (u"ࠪ࠲ࡲࡶ࠴࠯ࡪࡷࡱࡱ࠭圯") in url:
	#	l1ll1ll11111_l1_ = url.split(l11ll1_l1_ (u"ࠫ࠴࠭地"))
	#	url = l11ll1_l1_ (u"ࠬ࠵ࠧ圱").join(l1ll1ll11111_l1_[:4])
	#	tmp = re.findall(l11ll1_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿࠰࠱࠱࠮ࡄ࠵ࠩࠩ࠰࠭ࡃ࠮ࠪࠧ圲"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11ll1_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ圳")+tmp[0][1]+l11ll1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ圴")
	#	#return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ圵"),[l11ll1_l1_ (u"ࠪࠫ圶")],[url]
	#	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11l11_l1_(url)
	#	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	# l1l111l1l_l1_ l1lllll_l1_
	#return l11ll1_l1_ (u"ࠫࠬ圷"),[l11ll1_l1_ (u"ࠬ࠭圸")],[l1lllll_l1_]
def l1l1ll111111_l1_(l1lllll_l1_):
	# https://l1111llllll1_l1_.l111l11l1l1l_l1_/l1llll1lll11l_l1_?_11111l11ll1_l1_=l1lllll1l1l1l_l1_&_11111llll11_l1_=86046&l11llll1_l1_=0
	if l11ll1_l1_ (u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪ圹") in l1lllll_l1_:
		headers = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ场"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ圻")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭圼"),l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ圽"),headers,l11ll1_l1_ (u"ࠫࠬ圾"),l11ll1_l1_ (u"ࠬ࠭圿"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠶ࡹࡴࠨ址"))
		url = response.content
		if url: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ坁"),[l11ll1_l1_ (u"ࠨࠩ坂")],[url]
	else:
		# https://l11111111ll1_l1_.net/?l11lll11_l1_=142302&l11llll1_l1_=4
		parts = re.findall(l11ll1_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪ坃"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11ll1_l1_ (u"ࠪࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭坄"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ坅"))
		#url = server+l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡗ࡭ࡧࡨࡪࡦ࠷ࡹ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ坆")
		url = server+l11ll1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ均")
		#url = server+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ坈")+l11lll11_l1_+l11ll1_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ坉")+l11llll1_l1_
		#data = {l11ll1_l1_ (u"ࠩ࡬ࡨࠬ坊"):l11lll11_l1_,l11ll1_l1_ (u"ࠪ࡭ࠬ坋"):l11llll1_l1_,l11ll1_l1_ (u"ࠫࡲ࡫ࡴࡢࠩ坌"):l11ll1_l1_ (u"ࠬࡵ࡬ࡥࡡࡶࡩࡷࡼࡥࡳࡵࠪ坍"),l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ坎"):l11ll1_l1_ (u"ࠧࡰ࡮ࡧࠫ坏")}
		data = {l11ll1_l1_ (u"ࠨ࡫ࡧࠫ坐"):l11lll11_l1_,l11ll1_l1_ (u"ࠩ࡬ࠫ坑"):l11llll1_l1_}
		headers = {l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭坒"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ坓"),l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭坔"):l1lllll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ坕"),url,data,headers,l11ll1_l1_ (u"ࠧࠨ坖"),l11ll1_l1_ (u"ࠨࠩ块"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫ坘"))
		l11ll1ll_l1_ = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坙"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ坚"),[l11ll1_l1_ (u"ࠬ࠭坛")],[l111lll_l1_]
	return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ坜"),[],[]
def l111l1l111ll_l1_(l1llllll1lll1_l1_):
	l11l1l111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡴࡶࡵࠫ坝"),l11ll1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ坞"),l11ll1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࡠࡘࡈࡖࡎࡌࡉࡄࡃࡗࡍࡔࡔࠧ坟"))
	headers = {l11ll1_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ坠"):l11l1l111_l1_} if l11l1l111_l1_ else l11ll1_l1_ (u"ࠫࠬ坡")
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ坢"),l1llllll1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ坣"),headers,l11ll1_l1_ (u"ࠧࠨ坤"),l11ll1_l1_ (u"ࠨࠩ坥"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠷ࡳࡵࠩ坦"))
	l1lllllll11ll_l1_ = response.content
	l1111111lll1_l1_ = str(response.headers)
	l11111l11l11_l1_ = l1111111lll1_l1_+l1lllllll11ll_l1_
	if l11ll1_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ坧") in l11111l11l11_l1_: l1ll1l1ll_l1_ = True
	else:
		l1lllll1ll111_l1_,token,l111lll11l11_l1_,l11111ll1lll_l1_,l1ll1l1ll_l1_ = l11ll1_l1_ (u"ࠫࠬ坨"),l11ll1_l1_ (u"ࠬ࠭坩"),l11ll1_l1_ (u"࠭ࠧ坪"),l11ll1_l1_ (u"ࠧࠨ坫"),False
		l111lllll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭坬"),l1lllllll11ll_l1_,re.DOTALL)
		if l111lllll11l_l1_: l111lll11l11_l1_,l11111ll1lll_l1_ = l111lllll11l_l1_[0]
		l1111lll1l11_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ坭")][7]
		user = l1l11l111ll_l1_(32)
		if 0:
			data = {l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ坮"):user,l11ll1_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ坯"):l11llll11l1_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ坰"):l1llllll1lll1_l1_,l11ll1_l1_ (u"࠭࡫ࡦࡻࠪ坱"):l11111ll1lll_l1_,l11ll1_l1_ (u"ࠧࡪࡦࠪ坲"):l11ll1_l1_ (u"ࠨࠩ坳"),l11ll1_l1_ (u"ࠩ࡭ࡳࡧ࠭坴"):l11ll1_l1_ (u"ࠪ࡫ࡪࡺࡵࡳ࡮ࡶࠫ坵")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ坶"),l1111lll1l11_l1_,data,l11ll1_l1_ (u"ࠬ࠭坷"),l11ll1_l1_ (u"࠭ࠧ坸"),l11ll1_l1_ (u"ࠧࠨ坹"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨ坺"))
			html = response.content
		html = l11ll1_l1_ (u"ࠩࠪ坻")
		if html.startswith(l11ll1_l1_ (u"࡙ࠪࡗࡒࡓ࠾ࠩ坼")):
			l11ll11ll1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ坽"),html.split(l11ll1_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ坾"),1)[1])
			for request in l11ll11ll1ll_l1_:
				url = request[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ坿")]
				method = request[l11ll1_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪࠧ垀")]
				data = request[l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠭垁")]
				headers = request[l11ll1_l1_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ垂")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11ll1_l1_ (u"ࠪࠫ垃"),l11ll1_l1_ (u"ࠫࠬ垄"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬ垅"))
				l1lllllll11ll_l1_ = response.content
				if l11ll1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ垆") in l1lllllll11ll_l1_:
					l1ll1l1ll_l1_ = True
					break
				l1111111lll1_l1_ = str(response.headers)
				l11111l11l11_l1_ = l1111111lll1_l1_+l1lllllll11ll_l1_
				l1lllll1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡽࠫࠪ࠰࠭ࡃࠧ࠮ࡥࡺࡌ࠱࠮ࡄ࠯ࠢࠨ垇"),l11111l11l11_l1_,re.DOTALL)
				token = re.findall(l11ll1_l1_ (u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰ࠱࠮ࡄࠨࠨ࠱࠵ࡄ࠲࠯ࡅࠩࠣࠩ垈"),l11111l11l11_l1_,re.DOTALL)
				if token: token = token[0]
				if l1lllll1ll111_l1_ or token: break
		if not l1ll1l1ll_l1_:
			if not l1lllll1ll111_l1_:
				if not token and l111lllll11l_l1_:
					if 1 and not html.startswith(l11ll1_l1_ (u"ࠩࡌࡈࡂ࠭垉")):
						data = {l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ垊"):user,l11ll1_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ型"):l11llll11l1_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ垌"):l1llllll1lll1_l1_,l11ll1_l1_ (u"࠭࡫ࡦࡻࠪ垍"):l11111ll1lll_l1_,l11ll1_l1_ (u"ࠧࡪࡦࠪ垎"):l11ll1_l1_ (u"ࠨࠩ垏"),l11ll1_l1_ (u"ࠩ࡭ࡳࡧ࠭垐"):l11ll1_l1_ (u"ࠪ࡫ࡪࡺࡩࡥࠩ垑")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ垒"),l1111lll1l11_l1_,data,l11ll1_l1_ (u"ࠬ࠭垓"),l11ll1_l1_ (u"࠭ࠧ垔"),l11ll1_l1_ (u"ࠧࠨ垕"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨ垖"))
						html = response.content
					else: html = l11ll1_l1_ (u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪ垗")
					if html.startswith(l11ll1_l1_ (u"ࠪࡍࡉࡃࠧ垘")):
						l11111l11lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪ垙"),html,re.DOTALL)
						l11111lll1l1_l1_,timeout = l11111l11lll_l1_[0]
						message = l11ll1_l1_ (u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪ垚")+timeout+l11ll1_l1_ (u"࠭ࠠฬษ้๎ฮ࠭垛")
						l11l1l1lll_l1_ = DIALOG_PROGRESS()
						l11l1l1lll_l1_.create(l11ll1_l1_ (u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭垜"),message)
						t1 = time.time()
						l11l111l11l1_l1_,l111llll111l_l1_ = 0,0
						while l11l111l11l1_l1_<int(timeout):
							PROGRESS_UPDATE(l11l1l1lll_l1_,int(l11l111l11l1_l1_/int(timeout)*100),message,l11ll1_l1_ (u"ࠨࠩ垝"),timeout+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭垞")+str(int(l11l111l11l1_l1_))+l11ll1_l1_ (u"ࠪࠤࠥัว็์ฬࠫ垟"))
							#if l11l1l1lll_l1_.iscanceled(): break
							if l11l111l11l1_l1_>l111llll111l_l1_+10:
								data = {l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ垠"):user,l11ll1_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭垡"):l11llll11l1_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ垢"):l1llllll1lll1_l1_,l11ll1_l1_ (u"ࠧ࡬ࡧࡼࠫ垣"):l11111ll1lll_l1_,l11ll1_l1_ (u"ࠨ࡫ࡧࠫ垤"):l11111lll1l1_l1_,l11ll1_l1_ (u"ࠩ࡭ࡳࡧ࠭垥"):l11ll1_l1_ (u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬ垦")}
								response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ垧"),l1111lll1l11_l1_,data,l11ll1_l1_ (u"ࠬ࠭垨"),l11ll1_l1_ (u"࠭ࠧ垩"),l11ll1_l1_ (u"ࠧࠨ垪"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨ垫"))
								html = response.content
								if html.startswith(l11ll1_l1_ (u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ垬")):
									token = html.split(l11ll1_l1_ (u"ࠪࡘࡔࡑࡅࡏ࠿ࠪ垭"),1)[1]
									break
								l111llll111l_l1_ = l11l111l11l1_l1_
							else: time.sleep(1)
							l11l111l11l1_l1_ = time.time()-t1
						l11l1l1lll_l1_.close()
				if token:
					l111lll1l111_l1_ = response.cookies.get_dict()
					l1l111llll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ࠭࠴ࠪࡀࠫ࠾ࠫ垮"),l11111l11l11_l1_,re.DOTALL)
					if l11ll1_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ垯") in list(l111lll1l111_l1_.keys()): l1l111llll1l_l1_ = l111lll1l111_l1_[l11ll1_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭垰")]
					elif l1l111llll1l_l1_: l1l111llll1l_l1_ = l1l111llll1l_l1_[0]
					l111lllll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ垱"),l1lllllll11ll_l1_,re.DOTALL)
					if l111lllll11l_l1_: l111lll11l11_l1_,l11111ll1lll_l1_ = l111lllll11l_l1_[0]
					if l1l111llll1l_l1_ and l111lllll11l_l1_:
						headers = {l11ll1_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ垲"):l11ll1_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࠪ垳")+l1l111llll1l_l1_,l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ垴"):l1llllll1lll1_l1_,l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ垵"):l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ垶")}
						data = l11ll1_l1_ (u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡃࠧ垷")+token
						response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ垸"),l111lll11l11_l1_,data,headers,False,l11ll1_l1_ (u"ࠨࠩ垹"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠼ࡴࡩࠩ垺"))
						l1lllllll11ll_l1_ = response.content
						try: cookies = response.cookies.get_dict()
						except: cookies = {}
						l1lllll1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠥࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࠰࠭ࡃ࠮࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ垻"),str(cookies),re.DOTALL)
			if l1lllll1ll111_l1_:
				name,l1lllll1ll111_l1_ = l1lllll1ll111_l1_[0]
				l11l1l111_l1_ = name+l11ll1_l1_ (u"ࠫࡂ࠭垼")+l1lllll1ll111_l1_
				WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ垽"),l11ll1_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࡤ࡜ࡅࡓࡋࡉࡍࡈࡇࡔࡊࡑࡑࠫ垾"),l11l1l111_l1_,PERMANENT_CACHE)
				if l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ垿") not in l1lllllll11ll_l1_:
					headers = {l11ll1_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ埀"):l11l1l111_l1_}
					response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭埁"),l1llllll1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ埂"),headers,l11ll1_l1_ (u"ࠫࠬ埃"),l11ll1_l1_ (u"ࠬ࠭埄"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭埅"))
					l1lllllll11ll_l1_ = response.content
	if not l1ll1l1ll_l1_ and not l11l1l111_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ埆"),l11ll1_l1_ (u"ࠨࠩ埇"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ埈"),l11ll1_l1_ (u"ࠪ฽๊๊๊สࠢไัฺࠦร็ษࠣวู๋ว็ࠢไุ้ะࠠ࠯࠰ࠣัฬ๎ไࠡว฼หิฯࠠศๆ฼้้๐ษࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัส้ࠥ์แิࠢส่ๆ๐ฯ๋๊ࠣวํࠦแ๋ัํ์ࠥเ๊า้้๋ࠣࠦๆโีࠣห้๋่ใ฻ࠪ埉"))
	return l1lllllll11ll_l1_
def l1lllll1_l1_(url,type,l111llll_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ埊"),l11ll1_l1_ (u"ࠬ࠭埋"),url,type)
	# http://l1111l1lllll_l1_.l11l111ll1ll_l1_.io/l1lllll_l1_/136530
	l1llll11_l1_,l1111llll111_l1_ = [],[]
	#l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"࠭ࠧ埌"),l11ll1_l1_ (u"ࠧࠨ埍"),True,l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ城"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭埏"),url,l11ll1_l1_ (u"ࠪࠫ埐"),l11ll1_l1_ (u"ࠫࠬ埑"),l11ll1_l1_ (u"ࠬ࠭埒"),l11ll1_l1_ (u"࠭ࠧ埓"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭埔"))
	l11ll1ll_l1_ = response.content
	l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ埕"),l11ll1ll_l1_,re.DOTALL)
	for block in l1111l1_l1_:
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭埖"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ in l1llll11_l1_: continue
			if l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ埗") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ埘") not in l1lllll_l1_: continue
			title = title.replace(l11ll1_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭埙"),l11ll1_l1_ (u"࠭ࠧ埚")).replace(l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ埛"),l11ll1_l1_ (u"ࠨࠩ埜")).strip(l11ll1_l1_ (u"ࠩࠣࠫ埝")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭埞"),l11ll1_l1_ (u"ࠫࠥ࠭域"))
			l1llll11_l1_.append(l1lllll_l1_)
			l1111llll111_l1_.append(title)
	if len(l1llll11_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬ埠"),l1111llll111_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ埡"),[],[]
	elif len(l1llll11_l1_)==1: l1l_l1_ = 0
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ埢"),[],[]
	l1llllll1lll1_l1_ = l1llll11_l1_[l1l_l1_]
	l1lllllll11ll_l1_ = l111l1l111ll_l1_(l1llllll1lll1_l1_)
	l1llll_l1_,l1lll11l_l1_ = [],[]
	if type==l11ll1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ埣"):
		l1111l1ll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埤"),l1lllllll11ll_l1_,re.DOTALL)
		if l1111l1ll1ll_l1_:
			l1lllll_l1_ = l1111_l1_(l1111l1ll1ll_l1_[0])
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(l111llll_l1_)
	elif type==l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ埥"):
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭埦"),l1lllllll11ll_l1_,re.DOTALL)
		for l1lllll_l1_,size in l1l1_l1_:
			if not l1lllll_l1_: continue
			if l111llll_l1_ in size:
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
				break
		if not l1llll_l1_:
			for l1lllll_l1_,size in l1l1_l1_:
				if not l1lllll_l1_: continue
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࡚ࠬࡅࡔࡖࠪ埧"),l1llll_l1_)
	if not l1llll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ埨"),[],[]
	return l11ll1_l1_ (u"ࠧࠨ埩"),l1lll11l_l1_,l1llll_l1_
def l11llll_l1_(url,name):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ埪"),l11ll1_l1_ (u"ࠩࠪ埫"),url,l11l111l1lll_l1_)
	# http://l11ll1l11ll_l1_.l1111l111l11_l1_.net/5cf68c23e6e79			?l11l111l1lll_l1_=			__11l11llllll_l1_
	# http://w.l11ll111_l1_.l1llll111ll_l1_/5e14fd0a2806e			?l11l111l1lll_l1_=			ok.l1111ll11lll_l1_
	#l11l111l1lll_l1_ = l11l111l1lll_l1_.replace(l11ll1_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࡡࡢࠫ埬"),l11ll1_l1_ (u"ࠫࠬ埭")).split(l11ll1_l1_ (u"ࠬࡥ࡟ࠨ埮"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ埯"),url,l11ll1_l1_ (u"ࠧࠨ埰"),l11ll1_l1_ (u"ࠨࠩ埱"),True,l11ll1_l1_ (u"ࠩࠪ埲"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩ埳"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ埴") in list(cookies.keys()):
		l11l1l111_l1_ = cookies[l11ll1_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ埵")]
		l11l1l111_l1_ = l1111_l1_(escapeUNICODE(l11l1l111_l1_))
		items = re.findall(l11ll1_l1_ (u"࠭ࡲࡰࡷࡷࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埶"),l11l1l111_l1_,re.DOTALL)
		l111lll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠧ࡝࠱ࠪ執"),l11ll1_l1_ (u"ࠨ࠱ࠪ埸"))
		l111lll_l1_ = escapeUNICODE(l111lll_l1_)
	else: l111lll_l1_ = url
	if l11ll1_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ培") in l111lll_l1_:
		id = l111lll_l1_.split(l11ll1_l1_ (u"ࠪࠩ࠷ࡌࠧ基"))[-1]
		l111lll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡧࡴࡤࡪ࠱࡭ࡸ࠵ࠧ埻")+id
		return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ埼"),[l11ll1_l1_ (u"࠭ࠧ埽")],[l111lll_l1_]
	else:
		l1l1l1l1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭埾")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ埿"),l1l1l1l1_l1_,l11ll1_l1_ (u"ࠩࠪ堀"),l11ll1_l1_ (u"ࠪࠫ堁"),True,l11ll1_l1_ (u"ࠫࠬ堂"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫ堃"))
		l11l111l1l1l_l1_ = response.url
		#l11l111l1l1l_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ堄")]
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ堅"),l11ll1_l1_ (u"ࠨࠩ堆"),response.url,l1l1l1l1_l1_)
		l1111lll1ll1_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠩ࠲ࠫ堇"))[2]#.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ堈"))
		l11l1l11l1l1_l1_ = l11l111l1l1l_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭堉"))[2]#.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ堊"))
		l11l111_l1_ = l111lll_l1_.replace(l1111lll1ll1_l1_,l11l1l11l1l1_l1_)
		headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ堋"):l11ll1_l1_ (u"ࠧࠨ堌") , l11ll1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ堍"):l11ll1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ堎") , l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ堏"):l11l111_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ堐"), l11l111_l1_, l11ll1_l1_ (u"ࠬ࠭堑"), headers, False,l11ll1_l1_ (u"࠭ࠧ堒"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭堓"))
		html = response.content
		#xbmc.log(str(l11l111_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11ll1_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ堔"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11ll1_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ堕"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11ll1_l1_ (u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ堖"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ堗"),l11ll1_l1_ (u"ࠬ࠭堘"),str(items),html)
		if items:
			l1lllll_l1_ = items[0].replace(l11ll1_l1_ (u"࠭࡜࠰ࠩ堙"),l11ll1_l1_ (u"ࠧ࠰ࠩ堚"))
			l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠨ࠱ࠪ堛"))
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ堜") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ堝") + l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ堞"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ堟"))
			if name==l11ll1_l1_ (u"࠭ࠧ堠"): l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࠨ堡"),[l11ll1_l1_ (u"ࠨࠩ堢")],[l1lllll_l1_]
			else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ堣"),[l11ll1_l1_ (u"ࠪࠫ堤")],[l1lllll_l1_]
		else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬ堥"),[],[]
		return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
def l111llll11ll_l1_(url):
	# https://www.l11l111111ll_l1_.com/e/l1111111ll1l_l1_
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ堦") : l11ll1_l1_ (u"࠭ࠧ堧") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ堨"),headers,l11ll1_l1_ (u"ࠨࠩ堩"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭堪"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ堫"),l11ll1_l1_ (u"ࠫࠬ堬"),url,html)
	items = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堭"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"࠭ࠧ堮")
	if items:
		for l1lllll_l1_,l1ll1l1l1lll_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1l1lll_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭堯"),[],[]
	return l11ll1_l1_ (u"ࠨࠩ堰"),l1lll11l_l1_,l1llll_l1_
def l111111lllll_l1_(url):
	# https://l1111l11lll1_l1_.io/l1l111l1l_l1_-l11111l1111l_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ報"),l11ll1_l1_ (u"ࠪࠫ堲"))
	headers = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ堳"):l11ll1_l1_ (u"ࠬ࠭場")}
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ堵"),headers,l11ll1_l1_ (u"ࠧࠨ堶"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ堷"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堸"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ堹"),l11ll1_l1_ (u"ࠫࠬ堺"),url,items[0])
	if items:
		url = items[0]+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ堻")+url
		return l11ll1_l1_ (u"࠭ࠧ堼"),[l11ll1_l1_ (u"ࠧࠨ堽")],[url]
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪ堾"),[],[]
def l111l11llll1_l1_(url):
	# https://l1llll1lll1l1_l1_.to/l1l111l1l_l1_/5c83f14297d62
	url = url.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ堿"))
	if l11ll1_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ塀") in url: id = url.split(l11ll1_l1_ (u"ࠫ࠴࠭塁"))[4]
	else: id = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ塂"))[-1]
	url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪ塃") + id
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ塄") : l11ll1_l1_ (u"ࠨࠩ塅") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ塆"),headers,l11ll1_l1_ (u"ࠪࠫ塇"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡅࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭塈"))
	html = html.replace(l11ll1_l1_ (u"ࠬࡢ࡜ࠨ塉"),l11ll1_l1_ (u"࠭ࠧ塊"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ塋"),l11ll1_l1_ (u"ࠨࠩ塌"),url,html)
	items = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ塍"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠪࠫ塎"),[l11ll1_l1_ (u"ࠫࠬ塏")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡅࡖࡘࡗࡋࡁࡎࠩ塐"),[],[]
def l11111ll1l11_l1_(url):
	# https://l11l11l1l111_l1_.net/l1l111l1l_l1_-l111ll1llll1_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭塑"),l11ll1_l1_ (u"ࠧࠨ塒"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ塓"),l11ll1_l1_ (u"ࠩࠪ塔"),l11ll1_l1_ (u"ࠪࠫ塕"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫ塖"))
	items = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ塗"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for l1lllll_l1_,l1ll1l1l1lll_l1_,res in items:
		l1lll11l_l1_.append(l1ll1l1l1lll_l1_+l11ll1_l1_ (u"࠭ࠠࠨ塘")+res)
		l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡕ࡚ࡂࠩ塙"),[],[]
	return l11ll1_l1_ (u"ࠨࠩ塚"),l1lll11l_l1_,l1llll_l1_
def l111l1llll1l_l1_(url):
	# https://l11l11ll1ll1_l1_.l1lll1lllll_l1_/l1l111l1l_l1_-l1111l1111l1_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ塛"),l11ll1_l1_ (u"ࠪࠫ塜"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ塝"),l11ll1_l1_ (u"ࠬ࠭塞"),l11ll1_l1_ (u"࠭ࠧ塟"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ塠"))
	items = re.findall(l11ll1_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ塡"),html,re.DOTALL)
	items = set(items)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1ll1l1l1lll_l1_,res in items:
		url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭塢")+id+l11ll1_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ塣")+mode+l11ll1_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ塤")+hash
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭塥"),l11ll1_l1_ (u"࠭ࠧ塦"),l11ll1_l1_ (u"ࠧࠨ塧"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠴ࡱࡨࠬ塨"))
		items = re.findall(l11ll1_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塩"),html,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1l1lll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ塪")+res)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑࠪ填"),[],[]
	return l11ll1_l1_ (u"ࠬ࠭塬"),l1lll11l_l1_,l1llll_l1_
def l1llll1lll1ll_l1_(url):
	# https://l1lllll1l1lll_l1_.com:2053/l1lllll1ll1ll_l1_/l11111llll1l_l1_.l111ll11l1l1_l1_.l11l1l111l1l_l1_.1080p.l11l11llll1l_l1_.l11l111l1ll1_l1_.l1lllll11l1l1_l1_.l1111l1l_l1_.html?l111l1ll1lll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111ll1lllll_l1_=1624070560
	# http://l1lllllll1l1l_l1_.l111lll11ll_l1_/l111ll111l11_l1_/l111ll11lll1_l1_.l111l1111lll_l1_.l111ll1ll1l1_l1_.2018.1080p.l1111lll1l1l_l1_-l111l11l11ll_l1_.l1lllllll11l1_l1_.l1111l1l_l1_.html
	l1lllll_l1_ = l11ll1_l1_ (u"࠭ࠧ塭")
	if 1 or l11ll1_l1_ (u"ࠧࡌࡧࡼࡁࠬ塮") not in url:
		l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ塯"),l11ll1_l1_ (u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭塰"))
		l111lll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ塱"))
		id = l111lll_l1_[3]
		l111lll_l1_ = l11ll1_l1_ (u"ࠫ࠴࠭塲").join(l111lll_l1_[0:4])
		#headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ塳"):l11llllll_l1_(),l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ塴"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭塵")}
		payload = {l11ll1_l1_ (u"ࠨ࡫ࡧࠫ塶"):id,l11ll1_l1_ (u"ࠩࡲࡴࠬ塷"):l11ll1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭塸"),l11ll1_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ塹"):l11ll1_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ塺")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ塻"),l111lll_l1_,payload,l11ll1_l1_ (u"ࠧࠨ塼"),l11ll1_l1_ (u"ࠨࠩ塽"),l11ll1_l1_ (u"ࠩࠪ塾"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ塿"))
		if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭墀") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ墁")]
		if not l1lllll_l1_ and response.succeeded:
			html = response.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ墂"),html,re.DOTALL)
			if l1lllll_l1_: l1lllll_l1_ = l1lllll_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ境"),url,l11ll1_l1_ (u"ࠨࠩ墄"),l11ll1_l1_ (u"ࠩࠪ墅"),l11ll1_l1_ (u"ࠪࠫ墆"),l11ll1_l1_ (u"ࠫࠬ墇"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ墈"))
		if l11ll1_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ墉") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ墊")]
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠨࠩ墋"),[l11ll1_l1_ (u"ࠩࠪ墌")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ墍"),[],[]
def l111l1l11l1l_l1_(url):
	# https://www.l111l1111111_l1_.com/012ocyw9li6g.html
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ墎") : l11ll1_l1_ (u"ࠬ࠭墏") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ墐"),headers,l11ll1_l1_ (u"ࠧࠨ墑"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ墒"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ墓"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	if items:
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪࡱࡵ࠺ࠧ墔"))
		l1llll_l1_.append(items[0][1])
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ墕"))
		l1llll_l1_.append(items[0][0])
		return l11ll1_l1_ (u"ࠬ࠭墖"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ増"),[],[]
def l11l1l1ll11_l1_(url):
	# l111ll11l11l_l1_ l11l11111111_l1_			url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡞࠽ࡗ࠵࠳࡙ࡑࡽࡿࡑࡆࠩ墘")
	# l1llllll11l1l_l1_ .l11l1l111111_l1_ l11l11111111_l1_		url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡞ࡶ࡮ࡕࡑࡅࡾ࡫ࡹࡇࡋࠪ墙")
	# l111ll111l1l_l1_ l11l1l1l1l_l1_ .l1llll111_l1_ l11l11111111_l1_		url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡇࡧ࠴࠰ࡒࡘࡺࡓࡴࡐࡺࠫ墚")
	# l111l1l1l1ll_l1_ l11l11111111_l1_			url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡦࡡࡖ࠽࡛ࡼࡊࡎ࠳ࡓࡍࠬ墛")
	# l111l11l1l_l1_ files have l111l11lllll_l1_ l1l11l1ll11l_l1_		url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࠳ࡺࡈࡗ࡛ࡖࡤࡕࡼࡣࡖ࠭墜")
	# url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࡧࡇࡰ࡟࠻ࡶࡂࡐࡔ࡙࡬࠭墝")
	# url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹ࠳ࡷ࠱ࡦࡪ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ增")
	# url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡩࡲࡨࡥࡥ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ墟")
	# url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ墠")
	# url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡰࡇࡇ࡯࡯࡮ࡥࡊ࠲࡛࡮ࠪࡦࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬࠾ࡉࡲࡰࡩ࡫࡮ࡍ࡫ࡱࡩ࡫ࡵࡲࡕࡘࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡧ࡮ࡥࡆ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴ࠿ࡴࡻࡱࡨ࡮ࡩࡡࡵ࡫ࡲࡲࡂ࠸࠷࠸࠷࠺࠹ࠬ墡")
	# l1ll1ll1l_l1_ l111111ll1ll_l1_ details   https://l1111l11111l_l1_.me/l1lllll1l11l1_l1_/l1lllll1111ll_l1_-l1lllll1l111l_l1_-l111111ll111_l1_
	id = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ墢"))[-1]
	id = id.split(l11ll1_l1_ (u"ࠫࠫ࠭墣"))[0]
	id = id.replace(l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ墤"),l11ll1_l1_ (u"࠭ࠧ墥"))
	#id = l11ll1_l1_ (u"ࠧࡦࡡࡖ࠽࡛ࡼࡊࡎ࠳ࡓࡍࠬ墦")
	#url = l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ墧")+id
	#return l11ll1_l1_ (u"ࠩࠪ墨"),[l11ll1_l1_ (u"ࠪࠫ墩")],[url]
	l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ墪")][0]+l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ墫")+id
	l1llll1llll1l_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ墬")+id
	l111l111l11l_l1_,l1lllll1ll1l1_l1_,l11l1l111ll1_l1_,l1llllll1l1ll_l1_ = l11ll1_l1_ (u"ࠧࠨ墭"),l11ll1_l1_ (u"ࠨࠩ墮"),l11ll1_l1_ (u"ࠩࠪ墯"),l11ll1_l1_ (u"ࠪࠫ墰")
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠫ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡ࠭ࠬࠨࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠨ࠯ࠬࡂ࠭ࡩ࡫ࡦࡢࡷ࡯ࡸࡆࡻࡤࡪࡱࡗࡶࡦࡩ࡫ࡊࡰࡧࡩࡽ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠦࠨࠫࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࢀࠨ࡬ࡢࡰࡪࡹࡦ࡭ࡥࡄࡱࡧࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬࡣࠬ࡜ࠩࠪࡡࠏࠏࠉࠊࡨࡲࡶࠥࡲࡡ࡯ࡩ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱࡧ࡮ࡨࠫࠍࠍࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ࠭ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡰࡲࡸࠥ࡯࡮ࠡ࡝࠳࠰࠲࠷࡝࠻ࠌࠌࠍࠎࠏࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡧࡧࡳࡦࡗࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࠦ࠽ࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࡡ࠰࡞࠭ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠫࡺࡹࡱࡧࡀࡸࡷࡧࡣ࡬ࠨࡷࡰࡦࡴࡧ࠾ࠩ࠮ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡩࡧࠢࠪ࠳ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠯ࠨࠢ࡬ࡲࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࡀࠠࡥࡣࡶ࡬࡚ࡘࡌࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡪࡡࡴࡪࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡹ࠯ࠨ࠮ࠪ࠳ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠯ࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡨ࡭ࡵࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠨ࡮ࡴ࡮࡮࠵ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࡮࡬ࡴࡗࡕࡐ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩࠬࠎࠎࠏࠣࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡘ࠮ࡏࡈࡈࡎࡇ࠺ࡖࡔࡌࡁࠧ࠮࠮ࠫࡁࠬࠦ࠱࡚࡙ࡑࡇࡀࡗ࡚ࡈࡔࡊࡖࡏࡉࡘ࠲ࡇࡓࡑࡘࡔ࠲ࡏࡄ࠾ࠤࡹࡸࡹ࠭ࠬࡩࡶࡰࡰ࠷࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠢࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠧ࠰࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬࠐࠉࡣ࡮ࡲࡧࡰࡹࠬࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠬࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝࠭ࡽࢀࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡹࡷࡲ࡟ࡦࡰࡦࡳࡩ࡫ࡤࡠࡨࡰࡸࡤࡹࡴࡳࡧࡤࡱࡤࡳࡡࡱࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡥࡦ࡮ࡶࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊ࡫ࡩࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡬࡭ࡵࡡ࡯࡭ࡸࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡࡣࡱࡨࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠤࡁࡠ࠭ࠧ࡞࠼ࠍࠍࠎࠏࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡧ࡯ࡷࡣ࡮ࡺࡡࡨࡵࠣࡁࠥ࡬࡭ࡵࡡ࡯࡭ࡸࡺ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠭ࠩࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡬࡭ࡵࡡ࡬ࡸࡦ࡭ࡳ࠻ࠌࠌࠍࠎࠏࡩࡵࡣࡪ࠰ࡸ࡯ࡺࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠲ࠫ࠮ࠐࠉࠊࠋࠌࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࡞࡭ࡹࡧࡧ࡞ࠢࡀࠤࡸ࡯ࡺࡦࠌࠌࡪࡴࡸࠠࡣ࡮ࡲࡧࡰࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡨ࡬ࡰࡥ࡮࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋ࡯࡭ࡳ࡫ࡳࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠯ࠫ࠮ࠐࠉࠊࡨࡲࡶࠥࡲࡩ࡯ࡧࠣ࡭ࡳࠦ࡬ࡪࡰࡨࡷ࠿ࠐࠉࠊࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨ࠮࡯ࡩࡻ࡫࡬࠾ࡺࡥࡱࡨ࠴ࡌࡐࡉࡑࡓ࡙ࡏࡃࡆࠫࠍࠍࠎࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪ࡯࡭ࡳ࡫ࠬ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋࠌࠍࡱ࡯࡮ࡦࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡲࡩ࡯ࡧࠬࠎࠎࠏࠉࡥ࡫ࡦࡸࠥࡃࠠࡼࡿࠍࠍࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠ࡭࡫ࡱࡩ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠬࠦࠨࠫࠍࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡭ࡨࡽ࠱ࡼࡡ࡭ࡷࡨࠤࡂࠦࡩࡵࡧࡰ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡂ࠭ࠬ࠲ࠫࠍࠍࠎࠏࠉࡥ࡫ࡦࡸࡠࡱࡥࡺ࡟ࠣࡁࠥࡼࡡ࡭ࡷࡨࠎࠎࠏࠉࡪࡨࠣࠫࡸ࡯ࡺࡦࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯ࠠࡢࡰࡧࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠐࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩࡶ࡭ࡿ࡫ࠧ࡞ࠢࡀࠤ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࡟ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࡠࠎࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠮ࠐࠉࡣ࡮ࡲࡧࡰࡹࠬࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡨࡲࡶࡲࡧࡴࡴࠤ࠽ࡠࡠ࠮࠮ࠫࡁࠬࡠࡢ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠤ࠽ࡠࡠ࠮࠮ࠫࡁࠬࡠࡢ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊࡨࡲࡶࠥࡨ࡬ࡰࡥ࡮ࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠬࠦࠨ࠮ࠪࠪࠬ࠯ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂࠨࠧ࠭ࠩࡀࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠤࠥࠫ࠱࠭ࠢࠨࠫࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠻ࡶࡵࡹࡪ࠭ࠬࠨ࠼ࡗࡶࡺ࡫ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠿࡬ࡡ࡭ࡵࡨࠫ࠱࠭࠺ࡇࡣ࡯ࡷࡪ࠭ࠩࠋࠋࠌ࡭࡫ࠦࠧ࡜ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡦࡱࡵࡣ࡬࠼ࠣࡦࡱࡵࡣ࡬ࠢࡀࠤࠬࡡࠧࠬࡤ࡯ࡳࡨࡱࠫࠨ࡟ࠪࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡆࡘࡄࡐ࠭࠭࡬ࡪࡵࡷࠫ࠱ࡨ࡬ࡰࡥ࡮࠭ࠏࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮࠾ࠏࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡ࠮ࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨࡶࡼࡴࡪ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠿ࠪ࠰ࠬࡃࠢࠨࠫ࠮ࠫࠧ࠭ࠊࠊࠋࠌ࡭࡫ࠦࠧࡧࡲࡶࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡬ࡰࡴࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡩࡴࡸ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡽࡩࡥࡶ࡫ࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡹࡩࡻࡧࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡻ࡮ࡪࡴࡩࠩࡠ࠭࠰࠭ࡸࠨ࠭ࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡮ࡥࡪࡩ࡫ࡸࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࡠ࡟ࠬࡹࡴࡢࡴࡷࠫࡢ࠱ࠧ࠮ࠩ࠮ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡧࡱࡨࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡴࡶࡤࡶࡹ࠭࡝ࠬࠩ࠰ࠫ࠰ࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡪࡴࡤࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡨࡩࡵࡴࡤࡸࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯ࠠࡢࡰࡧࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࡄ࠱࠲࠳࠵࠶࠷࠹࠳࠴࠼ࠣࡨࡪࡲࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠐࠉࠊࠋࠌࡧ࡮ࡶࡨࡦࡴࠣࡁࠥࡪࡩࡤࡶ࡞ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠨࠪ࠭ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡤ࡫ࡳ࡬ࡪࡸ࠺ࠋࠋࠌࠍࠎࠏ࡫ࡦࡻ࠯ࡺࡦࡲࡵࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩࡀࠫ࠱࠷ࠩࠋࠋࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࡰ࡫ࡹ࡞ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡼࡡ࡭ࡷࡨ࠭ࠏࠏࠉࠊࠥ࡬ࡪࠥ࠭ࡵࡳ࡮ࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡺࡸ࡬ࠨ࡟ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡤࡪࡥࡷ࡟ࠬࡻࡲ࡭ࠩࡠ࠭ࠏࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠯ࠊࠊࡷࡵࡰࡤࡲࡩࡴࡶ࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠴࠱ࡹࡴࡳࡧࡤࡱࡸ࠷ࠬࡴࡶࡵࡩࡦࡳࡳ࠳ࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌ࡭࡫ࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶ࠦࡡ࡯ࡦࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴࠽ࠎࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴ࠲ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠿ࠐࠉࠊࠋࡸࡶࡱ࠷ࠠ࠾ࠢࡧ࡭ࡨࡺ࠱࡜ࠩࡸࡶࡱ࠭࡝࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠧࡺࡸ࡬࠲ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࡛࠭ࡎࡒࡗࡒࡘࡊ࠮ࡤࡪࡥࡷ࠵ࡠ࠭ࡵࡳ࡮ࠪࡡ࠮࠯࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷ࠶ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠻ࠌࠌࠍࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡤࡪࡥࡷ࠶ࡠ࠭ࡵࡳ࡮ࠪࡡࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠊࠥࡸࡶࡱ࠸ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇ࡙ࠫࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࠴࡞ࠫࡺࡸ࡬ࠨ࡟ࠬ࠭ࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠊ࡫ࡩࠤࡺࡸ࡬࠲࠿ࡀࡹࡷࡲ࠲ࠡࡣࡱࡨࠥࡻࡲ࡭࠳ࠣࡲࡴࡺࠠࡪࡰࠣࡹࡷࡲ࡟࡭࡫ࡶࡸ࠿ࠐࠉࠊࠋࠌࠍࡺࡸ࡬ࡠ࡮࡬ࡷࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮࠴࠭ࠏࠏࠉࠊࠋࠌࡨ࡮ࡩࡴ࠲࠰ࡸࡴࡩࡧࡴࡦࠪࡧ࡭ࡨࡺ࠲ࠪࠌࠌࠍࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳ࠱࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺ࠱ࠪࠌࠌࡩࡱࡹࡥ࠻ࠢࡶࡸࡷ࡫ࡡ࡮ࡵ࠳ࠤࡂࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠱ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࠐࠉࠣࠤࠥ墱")
	# l1lllllll111l_l1_ json data
	# l1l111l1l_l1_ url l11l11111111_l1_:    https://www.l1ll1ll1l_l1_.com/l1l111l1l_l1_/l111ll1ll111_l1_
	# list of l11l111111l1_l1_ & l1l11l1lllll_l1_
	# https://github.com/l111111l1lll_l1_-l1111llll1l1_l1_/l111111l1lll_l1_-l1111llll1l1_l1_/blob/master/l111llll1l11_l1_/l111l11111l1_l1_/l1ll1ll1l_l1_.py
	# all the below l11111ll11l1_l1_ were l111l1l11l11_l1_ using:	https://www.l1ll1ll1l_l1_.com/l11l111lllll_l1_/l1l1lll1l1l1_l1_/l11llll1l1l_l1_?l1lllll1111l1_l1_=l1lllll1llll1_l1_	&	l111lll1l1l1_l1_ = l111ll1ll111_l1_
	# 3 l1ll11llllll_l1_:	13KB:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ墲"): l11ll1_l1_ (u"࠭ࡉࡐࡕࡢࡇࡗࡋࡁࡕࡑࡕࠫ墳"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ墴"): l11ll1_l1_ (u"ࠨ࠴࠵࠲࠸࠹࠮࠲࠲࠴ࠫ墵")
	# 7 l1ll11llllll_l1_		44KB:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭墶"): l11ll1_l1_ (u"ࠪࡍࡔ࡙࡟ࡎࡇࡖࡗࡆࡍࡅࡔࡡࡈ࡜࡙ࡋࡎࡔࡋࡒࡒࠬ墷"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ墸"): l11ll1_l1_ (u"ࠬ࠷࠷࠯࠵࠶࠲࠷࠭墹")
	# 7 l1ll11llllll_l1_		58KB:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ墺"): l11ll1_l1_ (u"ࠧࡊࡑࡖࠫ墻"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ墼"): l11ll1_l1_ (u"ࠩ࠴࠻࠳࠹࠳࠯࠴ࠪ墽")
	# 9 l1ll11llllll_l1_		24KB:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ墾"): l11ll1_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡉࡒࡆࡃࡗࡓࡗ࠭墿"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ壀"): l11ll1_l1_ (u"࠭࠲࠳࠰࠶࠴࠳࠷࠰࠱ࠩ壁")
	# no json file:		21 l1ll11llllll_l1_	95KB:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ壂"): l11ll1_l1_ (u"ࠨ࡙ࡈࡆࡤࡉࡒࡆࡃࡗࡓࡗ࠭壃"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ壄"): l11ll1_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠷࠼࠮࠱࠲࠱࠴࠵࠭壅")
	# no json file:		21 l1ll11llllll_l1_	121KB:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ壆"): l11ll1_l1_ (u"ࠬ࡝ࡅࡃࠩ壇"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭壈"): l11ll1_l1_ (u"ࠧ࠳࠰࠵࠴࠷࠸࠰࠹࠲࠴࠲࠵࠶࠮࠱࠲ࠪ壉")
	# no json file: 	26 l1ll11llllll_l1_	115KB:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ壊"): l11ll1_l1_ (u"ࠩࡐ࡛ࡊࡈࠧ壋"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ壌"): l11ll1_l1_ (u"ࠫ࠷࠴࠲࠱࠴࠵࠴࠽࠶࠱࠯࠲࠳࠲࠵࠶ࠧ壍")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ壎"): l11ll1_l1_ (u"࠭ࡁࡏࡆࡕࡓࡎࡊࠧ壏"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ壐"): l11ll1_l1_ (u"ࠨ࠳࠺࠲࠸࠷࠮࠴࠷ࠪ壑")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭壒"): l11ll1_l1_ (u"࡛ࠪࡊࡈ࡟ࡓࡇࡐࡍ࡝࠭壓"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ壔"): l11ll1_l1_ (u"ࠬ࠷࠮࠳࠲࠵࠶࠵࠽࠲࠸࠰࠳࠵࠳࠶࠰ࠨ壕")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ壖"): l11ll1_l1_ (u"ࠧࡘࡇࡅࡣࡊࡓࡂࡆࡆࡇࡉࡉࡥࡐࡍࡃ࡜ࡉࡗ࠭壗"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ壘"): l11ll1_l1_ (u"ࠩ࠴࠲࠷࠶࠲࠳࠲࠺࠷࠶࠴࠰࠱࠰࠳࠴ࠬ壙")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ壚"): l11ll1_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ壛"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ壜"): l11ll1_l1_ (u"࠭࠱࠸࠰࠶࠵࠳࠹࠵ࠨ壝")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ壞"): l11ll1_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡐ࡙ࡘࡏࡃࠨ壟"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ壠"): l11ll1_l1_ (u"ࠪ࠹࠳࠷࠶࠯࠷࠴ࠫ壡")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ壢"): l11ll1_l1_ (u"࡚ࠬࡖࡉࡖࡐࡐ࠺ࡥࡓࡊࡏࡓࡐ࡞ࡥࡅࡎࡄࡈࡈࡉࡋࡄࡠࡒࡏࡅ࡞ࡋࡒࠨ壣"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭壤"): l11ll1_l1_ (u"ࠧ࠳࠰࠳ࠫ壥")
	# l11l1lll1l1l_l1_:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ壦"): l11ll1_l1_ (u"ࠩࡌࡓࡘࡥࡍࡖࡕࡌࡇࠬ壧"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ壨"): l11ll1_l1_ (u"ࠫ࠺࠴࠲࠲ࠩ壩")
	# l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭壪")][0]+l11ll1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡶ࡬ࡢࡻࡨࡶࡄࡶࡲࡦࡶࡷࡽࡕࡸࡩ࡯ࡶࡀࡸࡷࡻࡥࠨ士")  # l1lllll1llll1_l1_ l1lll1111ll1_l1_ l1lllll1lll1l_l1_ and l111111lll1l_l1_ l1ll1l1ll1ll_l1_ l1l1l1ll1l_l1_ l11111111l11_l1_ file size
	#l11ll11l1_l1_ = l11ll1_l1_ (u"ࠧࡼࠩ壬")l1lllll11111l_l1_ (u"ࠨ࠼࡬ࡨ࠱࠭壭")l1111lll1lll_l1_ (u"ࠩ࠽ࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠢࡂࡐࡇࡖࡔࡏࡄࠣ࠮ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠧ࠷࠷࠯࠵࠴࠲࠸࠻ࠢࡾࡿࢀࠫ壮")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ壯"),l111lll_l1_,l11ll11l1_l1_,l11ll1_l1_ (u"ࠫࠬ声"),l11ll1_l1_ (u"ࠬ࠭壱"),l11ll1_l1_ (u"࠭ࠧ売"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ壳"))
	#html = response.content
	for l11ll11111_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨษ็้าอ่ๅหࠣี็๋࠺ࠡࠢࠪ壴")+str(l11ll11111_l1_+1),l11ll1_l1_ (u"ࠩࠪ壵"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ壶"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ壷"),l11ll1_l1_ (u"ࠬ࠭壸"),l11ll1_l1_ (u"࠭ࠧ壹"),l11ll1_l1_ (u"ࠧࠨ壺"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩ壻"))
		html = response.content
		if l11ll1_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ壼") in html: break
		time.sleep(2)
	#WRITE_THIS(l11ll1_l1_ (u"ࠪࠫ壽"),html)
	l11lll11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ壾"),html,re.DOTALL)
	if l11lll11l1_l1_: l11lll11l1_l1_ = l11lll11l1_l1_[0]
	else: l11lll11l1_l1_ = html
	l11lll11l1_l1_ = l11lll11l1_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭壿"),l11ll1_l1_ (u"࠭ࠦࠨ夀"))
	l111111l1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ夁"),l11lll11l1_l1_)
	#WRITE_THIS(l11ll1_l1_ (u"ࠨࠩ夂"),str(l111111l1l11_l1_))
	# l1lllllll111l_l1_ l111ll1lll11_l1_ & l11l11lll1ll_l1_
	# l1ll1ll1l_l1_ l111ll11l11l_l1_ l1lllll_l1_ l11lll1ll_l1_ l11ll1_l1_ (u"ࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠫ夃") to l111l1l111_l1_ on l111ll11l1l_l1_
	l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧ处")],[l11ll1_l1_ (u"ࠫࠬ夅")]
	try:
		l111ll1lll11_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳࡹࠧ夆")][l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ备")][l11ll1_l1_ (u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡕࡴࡤࡧࡰࡹࠧ夈")]
		for l111l1l1ll1l_l1_ in l111ll1lll11_l1_:
			l1lllll_l1_ = l111l1l1ll1l_l1_[l11ll1_l1_ (u"ࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠩ変")]
			try: title = l111l1l1ll1l_l1_[l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ夊")][l11ll1_l1_ (u"ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ夋")]
			except: title = l111l1l1ll1l_l1_[l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ夌")][l11ll1_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ复")][0][l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࠫ夎")]
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(title)
	except: pass
	if len(l1lll11l_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไหำฯ้ฮࠦวๅ็้หุฮษ࠻ࠩ夏"), l1lll11l_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭夐"),[],[]
		elif l1l_l1_!=0:
			l1lllll_l1_ = l1llll_l1_[l1l_l1_]+l11ll1_l1_ (u"ࠩࠩࠫ夑")
			l1111l11l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠪ࠭࡬࡭ࡵ࠿࠱࠮ࡄ࠯ࠦࠨ夒"),l1lllll_l1_)
			if l1111l11l1l1_l1_: l1lllll_l1_ = l1lllll_l1_.replace(l1111l11l1l1_l1_[0],l11ll1_l1_ (u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ夓"))
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭夔")
			l111l111l11l_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨ夕"))
	formats,l11l11lll11l_l1_,l111llll1ll1_l1_,l111llll1lll_l1_,l111llll1l1l_l1_ = [],[],[],[],[]
	# l1lllllll111l_l1_ l111l11l1111_l1_ l1ll11llllll_l1_
	try: l1lllll1ll1l1_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ外")][l11ll1_l1_ (u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ夗")]
	except: pass
	# l1lllllll111l_l1_ l111ll111l1l_l1_ stream
	try: l11l1l111ll1_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ夘")][l11ll1_l1_ (u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ夙")]
	except: pass
	# l1lllllll111l_l1_ l1ll1l11ll_l1_ l1111l1l_l1_ l1ll11llllll_l1_
	try: formats = l111111l1l11_l1_[l11ll1_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ多")][l11ll1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭夛")]
	except: pass
	# l1lllllll111l_l1_ l1ll1l11ll_l1_ l11l1l111111_l1_ l1ll11llllll_l1_
	try: l11l11lll11l_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭夜")][l11ll1_l1_ (u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩ夝")]
	except: pass
	l111ll11111l_l1_ = formats+l11l11lll11l_l1_
	for dict in l111ll11111l_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ夞"),str(dict))
		if l11ll1_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ够") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ夠")] = str(dict[l11ll1_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ夡")])
		if l11ll1_l1_ (u"ࠬ࡬ࡰࡴࠩ夢") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡦࡱࡵࠪ夣")] = str(dict[l11ll1_l1_ (u"ࠧࡧࡲࡶࠫ夤")])
		if l11ll1_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ夥") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ夦")] = dict[l11ll1_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ大")]		#.replace(l11ll1_l1_ (u"ࠫࡂ࠭夨"),l11ll1_l1_ (u"ࠬࡃࠧ天"))+l11ll1_l1_ (u"࠭ࠢࠨ太")
		if l11ll1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ夫") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬ夬")] = str(dict[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ夭")])
		if l11ll1_l1_ (u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ央") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ夯")] = str(dict[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ夰")])
		if l11ll1_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ失") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ夲")] = str(dict[l11ll1_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ夳")])+l11ll1_l1_ (u"ࠩࡻࠫ头")+str(dict[l11ll1_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ夵")])
		if l11ll1_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ夶") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ夷")] = dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ夸")][l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭夹")]+l11ll1_l1_ (u"ࠨ࠯ࠪ夺")+dict[l11ll1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ夻")][l11ll1_l1_ (u"ࠪࡩࡳࡪࠧ夼")]
		if l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ夽") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ夾")] = dict[l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ夿")][l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭奀")]+l11ll1_l1_ (u"ࠨ࠯ࠪ奁")+dict[l11ll1_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭奂")][l11ll1_l1_ (u"ࠪࡩࡳࡪࠧ奃")]
		if l11ll1_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬ奄") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭奅")] = dict[l11ll1_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ奆")]
		if l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ奇") in list(dict.keys()) and int(dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ奈")])>111222333: del dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ奉")]
		if l11ll1_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬ奊") in list(dict.keys()):
			cipher = dict[l11ll1_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭奋")].split(l11ll1_l1_ (u"ࠬࠬࠧ奌"))
			for item in cipher:
				key,value = item.split(l11ll1_l1_ (u"࠭࠽ࠨ奍"),1)
				dict[key] = l1111_l1_(value)
		if l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ奎") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ奏")] = l1111_l1_(dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭奐")])
		#if l11ll1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࡀࠫ契") in dict[l11ll1_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭奒")]: dict[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ奓")] = dict[l11ll1_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ奔")].split(l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹ࠽࡝ࠤࠪ奕"))[1].strip(l11ll1_l1_ (u"ࠨ࡞ࠥࠫ奖"))
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ套"),dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ奘")]+l11ll1_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤࠬ奙")+dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧࠪ奚")])
		l111llll1ll1_l1_.append(dict)
	l11l1ll11_l1_ = l11ll1_l1_ (u"࠭ࠧ奛")
	if l11ll1_l1_ (u"ࠧࡴࡲࡀࡷ࡮࡭ࠧ奜") in l11lll11l1_l1_:
		#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡻࡷࡷ࠴ࡰࡳࡣ࡫ࡱ࠳ࡵࡲࡡࡺࡧࡵࡣ࠳࠰࠿ࠪࠤࠪ奝"),html,re.DOTALL)
		# l11l11111111_l1_:	/s/l11llll1l1l_l1_/6dde7fb4/l111111111l1_l1_.l1111lll111l_l1_/l111l11l1l11_l1_/base.l1llllllllll1_l1_
		#l1111111l111_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡪ࠸࠸ࡦ࠸࠼࠶࡬࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟ࡖࡕ࠲ࡦࡦࡹࡥ࠯࡬ࡶࠫ奞")]
		l1111111l111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩ奟"),html,re.DOTALL)
		if l1111111l111_l1_:
			l1111111l111_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ奠")][0]+l1111111l111_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ奡"),l1111111l111_l1_,l11ll1_l1_ (u"࠭ࠧ奢"),l11ll1_l1_ (u"ࠧࠨ奣"),l11ll1_l1_ (u"ࠨࠩ奤"),l11ll1_l1_ (u"ࠩࠪ奥"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫ奦"))
			l11l1ll11_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1lllllll1ll1_l1_ = cipher._load_javascript(l11l1ll11_l1_)
			l1lllll1ll11l_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ奧"),str(l1lllllll1ll1_l1_))
			l11111l1ll11_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1lllll1ll11l_l1_)
	for dict in l111llll1ll1_l1_:
		url = dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ奨")]
		if l11ll1_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪ奩") in url or url.count(l11ll1_l1_ (u"ࠧࡴ࡫ࡪࡁࠬ奪"))>1:
			l111llll1lll_l1_.append(dict)
		elif l11l1ll11_l1_ and l11ll1_l1_ (u"ࠨࡵࠪ奫") in list(dict.keys()) and l11ll1_l1_ (u"ࠩࡶࡴࠬ奬") in list(dict.keys()):
			l111l1l1l1ll_l1_ = l11111l1ll11_l1_.execute(dict[l11ll1_l1_ (u"ࠪࡷࠬ奭")])
			if l111l1l1l1ll_l1_!=dict[l11ll1_l1_ (u"ࠫࡸ࠭奮")]:
				dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ奯")] = url+l11ll1_l1_ (u"࠭ࠦࠨ奰")+dict[l11ll1_l1_ (u"ࠧࡴࡲࠪ奱")]+l11ll1_l1_ (u"ࠨ࠿ࠪ奲")+l111l1l1l1ll_l1_
				l111llll1lll_l1_.append(dict)
	for dict in l111llll1lll_l1_:
		l11lll1_l1_,l111111l1l1l_l1_,l111111ll11l_l1_,l11ll1l11_l1_,codecs,l11l11l11l1_l1_ = l11ll1_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ女"),l11ll1_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ奴"),l11ll1_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ奵"),l11ll1_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭奶"),l11ll1_l1_ (u"࠭ࠧ奷"),l11ll1_l1_ (u"ࠧ࠱ࠩ奸")
		try:
			l111lllll111_l1_ = dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠭她")]
			l111lllll111_l1_ = l111lllll111_l1_.replace(l11ll1_l1_ (u"ࠩ࠮ࠫ奺"),l11ll1_l1_ (u"ࠪࠫ奻"))
			items = re.findall(l11ll1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奼"),l111lllll111_l1_,re.DOTALL)
			l11ll1l11_l1_,l11lll1_l1_,codecs = items[0]
			l11l11ll1111_l1_ = codecs.split(l11ll1_l1_ (u"ࠬ࠲ࠧ好"))
			l111111l1l1l_l1_ = l11ll1_l1_ (u"࠭ࠧ奾")
			for item in l11l11ll1111_l1_: l111111l1l1l_l1_ += item.split(l11ll1_l1_ (u"ࠧ࠯ࠩ奿"))[0]+l11ll1_l1_ (u"ࠨ࠮ࠪ妀")
			l111111l1l1l_l1_ = l111111l1l1l_l1_.strip(l11ll1_l1_ (u"ࠩ࠯ࠫ妁"))
			if l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ如") in list(dict.keys()): l11l11l11l1_l1_ = str(float(dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ妃")]*10)//1024/10)+l11ll1_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ妄")
			else: l11l11l11l1_l1_ = l11ll1_l1_ (u"࠭ࠧ妅")
			if l11ll1l11_l1_==l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ妆"): continue
			elif l11ll1_l1_ (u"ࠨ࠮ࠪ妇") in l111lllll111_l1_:
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠩࡄ࠯࡛࠭妈")
				l111111ll11l_l1_ = l11lll1_l1_+l11ll1_l1_ (u"ࠪࠤࠥ࠭妉")+l11l11l11l1_l1_+dict[l11ll1_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ妊")].split(l11ll1_l1_ (u"ࠬࡾࠧ妋"))[1]
			elif l11ll1l11_l1_==l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ妌"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭妍")
				l111111ll11l_l1_ = l11l11l11l1_l1_+dict[l11ll1_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭妎")].split(l11ll1_l1_ (u"ࠩࡻࠫ妏"))[1]+l11ll1_l1_ (u"ࠪࠤࠥ࠭妐")+dict[l11ll1_l1_ (u"ࠫ࡫ࡶࡳࠨ妑")]+l11ll1_l1_ (u"ࠬ࡬ࡰࡴࠩ妒")+l11ll1_l1_ (u"࠭ࠠࠡࠩ妓")+l11lll1_l1_
			elif l11ll1l11_l1_==l11ll1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭妔"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ妕")
				l111111ll11l_l1_ = l11l11l11l1_l1_+str(int(dict[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭妖")])/1000)+l11ll1_l1_ (u"ࠪ࡯࡭ࢀࠠࠡࠩ妗")+dict[l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ妘")]+l11ll1_l1_ (u"ࠬࡩࡨࠨ妙")+l11ll1_l1_ (u"࠭ࠠࠡࠩ妚")+l11lll1_l1_
		except:
			l1lllll1llll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1llll_l1_)
		if l11ll1_l1_ (u"ࠧࡥࡷࡵࡁࠬ妛") in dict[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ妜")]: l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭妝")].split(l11ll1_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ妞"),1)[1].split(l11ll1_l1_ (u"ࠫࠫ࠭妟"),1)[0]))
		elif l11ll1_l1_ (u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ妠") in list(dict.keys()): l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ妡")])/1000)
		else: l1l11lll1_l1_ = l11ll1_l1_ (u"ࠧ࠱ࠩ妢")
		if l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ妣") not in list(dict.keys()): l11l11l11l1_l1_ = dict[l11ll1_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ妤")].split(l11ll1_l1_ (u"ࠪࡼࠬ妥"))[1]
		else: l11l11l11l1_l1_ = dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ妦")]
		if l11ll1_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ妧") not in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ妨")] = l11ll1_l1_ (u"ࠧ࠱࠯࠳ࠫ妩")
		dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ妪")] = l11ll1l11_l1_+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭妫")+l111111ll11l_l1_+l11ll1_l1_ (u"ࠪࠤࠥ࠮ࠧ妬")+l111111l1l1l_l1_+l11ll1_l1_ (u"ࠫ࠱࠭妭")+dict[l11ll1_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ妮")]+l11ll1_l1_ (u"࠭ࠩࠨ妯")
		dict[l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ妰")] = l111111ll11l_l1_.split(l11ll1_l1_ (u"ࠨࠢࠣࠫ妱"))[0].split(l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ妲"))[0]
		dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ妳")] = l11ll1l11_l1_
		dict[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭妴")] = l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ妵")] = codecs
		dict[l11ll1_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ妶")] = l1l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ妷")] = l11l11l11l1_l1_
		l111llll1l1l_l1_.append(dict)
	l111l1lllll1_l1_,l11l111l11ll_l1_,l11l1l11111l_l1_,l1111llll11l_l1_,l111lll111ll_l1_ = [],[],[],[],[]
	l1111ll11ll1_l1_,l111lllllll1_l1_,l1111l1l111l_l1_,l11l11l1lll1_l1_,l11l11llll11_l1_ = [],[],[],[],[]
	if l1lllll1ll1l1_l1_:
		dict = {}
		dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ妸")] = l11ll1_l1_ (u"ࠩࡄ࠯࡛࠭妹")
		dict[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ妺")] = l11ll1_l1_ (u"ࠫࡲࡶࡤࠨ妻")
		dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ妼")] = dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ妽")]+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ妾")+dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ妿")]+l11ll1_l1_ (u"ࠩࠣࠤࠬ姀")+l11ll1_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭姁")
		dict[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ姂")] = l1lllll1ll1l1_l1_
		dict[l11ll1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭姃")] = l11ll1_l1_ (u"࠭࠰ࠨ姄") # for l11l1l11l1_l1_ l1lllll1ll1l1_l1_ any l1l111lll_l1_ will l111lll1l11l_l1_ l11111l1lll1_l1_ sort l1l1l1lll1l_l1_
		dict[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ姅")] = l11ll1_l1_ (u"ࠨ࠻࠻࠻࠻࠻࠴࠴࠴࠴࠴ࠬ姆") # 20
		l111llll1l1l_l1_.append(dict)
	if l11l1l111ll1_l1_:
		l1111111l1l1_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l11l1l111ll1_l1_)
		l11l11l11111_l1_ = list(zip(l1111111l1l1_l1_,l11l1111l1ll_l1_))
		for title,l1lllll_l1_ in l11l11l11111_l1_:
			dict = {}
			dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ姇")] = l11ll1_l1_ (u"ࠪࡅ࠰࡜ࠧ姈")
			dict[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭姉")] = l11ll1_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ姊")
			dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ始")] = l1lllll_l1_
			#if l11ll1_l1_ (u"ࠧࡃ࡙࠽ࠤࠬ姌") in title: dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ姍")] = title.split(l11ll1_l1_ (u"ࠩࠣࠤࠬ姎"))[1].split(l11ll1_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ姏"))[0]
			#if l11ll1_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ姐") in title: dict[l11ll1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭姑")] = title.split(l11ll1_l1_ (u"࠭ࡒࡦࡵ࠽ࠤࠬ姒"))[1]
			# title = l11ll1_l1_ (u"ࠢ࠵࠴࠹࠻ࡰࡨࡰࡴࠢࠣ࠻࠷࠶ࠠࠡ࠰ࡰ࠷ࡺ࠾ࠢ姓")
			if l11ll1_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭委") in title: dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ姕")] = title.split(l11ll1_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ姖"))[0].rsplit(l11ll1_l1_ (u"ࠫࠥࠦࠧ姗"))[-1]
			else: dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭姘")] = l11ll1_l1_ (u"࠭࠱࠱ࠩ姙")
			if title.count(l11ll1_l1_ (u"ࠧࠡࠢࠪ姚"))>1:
				l111llll_l1_ = title.rsplit(l11ll1_l1_ (u"ࠨࠢࠣࠫ姛"))[-3]
				if l111llll_l1_.isdigit(): dict[l11ll1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ姜")] = l111llll_l1_
				else: dict[l11ll1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ姝")] = l11ll1_l1_ (u"ࠫ࠵࠶࠰࠱ࠩ姞")
			#dict[l11ll1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭姟")] = title
			if title==l11ll1_l1_ (u"࠭࠭࠲ࠩ姠"): dict[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭姡")] = dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ姢")]+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭姣")+dict[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ姤")]+l11ll1_l1_ (u"ࠫࠥࠦࠧ姥")+l11ll1_l1_ (u"ࠬา่ะหࠣิ่๐ษࠨ姦")
			else: dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ姧")] = dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭姨")]+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ姩")+dict[l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ姪")]+l11ll1_l1_ (u"ࠪࠤࠥ࠭姫")+dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ姬")]+l11ll1_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ姭")+dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ姮")]
			l111llll1l1l_l1_.append(dict)
	l111llll1l1l_l1_ = sorted(l111llll1l1l_l1_,reverse=True,key=lambda key: float(key[l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ姯")]))
	if not l111llll1l1l_l1_:
		l1ll11l11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ姰"),html,re.DOTALL)
		l1ll11l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ姱"),html,re.DOTALL)
		l111l1lll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ姲"),html,re.DOTALL)
		l111l1lll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭姳"),html,re.DOTALL)
		try: l111l1lll1ll_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ姴")][l11ll1_l1_ (u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ姵")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ姶")][l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ姷")][l11ll1_l1_ (u"ࠩࡵࡹࡳࡹࠧ姸")][0][l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࠨ姹")]
		except: l111l1lll1ll_l1_ = l11ll1_l1_ (u"ࠫࠬ姺")
		try: l111l1llll11_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ姻")][l11ll1_l1_ (u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ姼")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ姽")][l11ll1_l1_ (u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩ姾")][0][l11ll1_l1_ (u"ࠩࡵࡹࡳࡹࠧ姿")][0][l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࠨ娀")]
		except: l111l1llll11_l1_ = l11ll1_l1_ (u"ࠫࠬ威")
		try: l11111l1l1ll_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ娂")][l11ll1_l1_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭娃")]
		except: l11111l1l1ll_l1_ = l11ll1_l1_ (u"ࠧࠨ娄")
		if l1ll11l11ll_l1_ or l1ll11l1l11_l1_ or l111l1lll11l_l1_ or l111l1lll1l1_l1_ or l111l1lll1ll_l1_ or l111l1llll11_l1_ or l11111l1l1ll_l1_:
			if   l1ll11l11ll_l1_: message = l1ll11l11ll_l1_[0]
			elif l1ll11l1l11_l1_: message = l1ll11l1l11_l1_[0]
			elif l111l1lll11l_l1_: message = l111l1lll11l_l1_[0]
			elif l111l1lll1l1_l1_: message = l111l1lll1l1_l1_[0]
			elif l111l1lll1ll_l1_: message = l111l1lll1ll_l1_
			elif l111l1llll11_l1_: message = l111l1llll11_l1_
			elif l11111l1l1ll_l1_: message = l11111l1l1ll_l1_
			l1111l111ll1_l1_ = message.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ娅"),l11ll1_l1_ (u"ࠩࠪ娆")).strip(l11ll1_l1_ (u"ࠪࠤࠬ娇"))
			l111ll1l1lll_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ัษࠣห้็๊ะ์๋ࠤๆ๐็ࠡ็ื็้ฯ้ࠠไาࠤ๏้่็ࠢ฽๎ึࠦๅๅษษ้๊ࠥศฺุࠣห้๋ำหะา้๏์ࠠฤ๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้࡟࠴ࡉࡏࡍࡑࡕࡡࠬ娈")
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭娉"),l11ll1_l1_ (u"࠭ࠧ娊"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺ๋ࠢห้๋ศา็ฯࠫ娋"),l111ll1l1lll_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭娌")+l1111l111ll1_l1_)
			return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠫ娍")+l1111l111ll1_l1_,[],[]
		else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ娎"),[],[]
	l11111l1ll1l_l1_,l1lllll11l111_l1_,l111l1l11lll_l1_ = [],[],[]
	for dict in l111llll1l1l_l1_:
		if dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ娏")]==l11ll1_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ娐"):
			l111l1lllll1_l1_.append(dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ娑")])
			l1111ll11ll1_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭娒")]==l11ll1_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ娓"):
			l11l111l11ll_l1_.append(dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ娔")])
			l111lllllll1_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ娕")]==l11ll1_l1_ (u"ࠫࡲࡶࡤࠨ娖"):
			title = dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ娗")].replace(l11ll1_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭娘"),l11ll1_l1_ (u"ࠧࠨ娙"))
			if l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ娚") not in list(dict.keys()): l11l11l11l1_l1_ = l11ll1_l1_ (u"ࠩ࠳ࠫ娛")
			else: l11l11l11l1_l1_ = dict[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ娜")]
			l11111l1ll1l_l1_.append([dict,{},title,l11l11l11l1_l1_])
		else:
			title = dict[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ娝")].replace(l11ll1_l1_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ娞"),l11ll1_l1_ (u"࠭ࠧ娟"))
			if l11ll1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ娠") not in list(dict.keys()): l11l11l11l1_l1_ = l11ll1_l1_ (u"ࠨ࠲ࠪ娡")
			else: l11l11l11l1_l1_ = dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ娢")]
			l11111l1ll1l_l1_.append([dict,{},title,l11l11l11l1_l1_])
			l11l1l11111l_l1_.append(title)
			l1111l1l111l_l1_.append(dict)
		l11l11l111ll_l1_ = True
		if l11ll1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ娣") in list(dict.keys()):
			if l11ll1_l1_ (u"ࠫࡦࡼ࠰ࠨ娤") in dict[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ娥")]: l11l11l111ll_l1_ = False
			elif kodi_version<18:
				if l11ll1_l1_ (u"࠭ࡡࡷࡥࠪ娦") not in dict[l11ll1_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ娧")] and l11ll1_l1_ (u"ࠨ࡯ࡳ࠸ࡦ࠭娨") not in dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ娩")]: l11l11l111ll_l1_ = False
		if dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ娪")]==l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ娫") and dict[l11ll1_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ娬")]!=l11ll1_l1_ (u"࠭࠰࠮࠲ࠪ娭") and l11l11l111ll_l1_==True:
			l111lll111ll_l1_.append(dict[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭娮")])
			l11l11llll11_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ娯")]==l11ll1_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ娰") and dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ娱")]!=l11ll1_l1_ (u"ࠫ࠵࠳࠰ࠨ娲") and l11l11l111ll_l1_==True:
			l1111llll11l_l1_.append(dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ娳")])
			l11l11l1lll1_l1_.append(dict)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ娴"),l11ll1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ娵")+dict[l11ll1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ娶")])
	for l11l111ll1l1_l1_ in l11l11l1lll1_l1_:
		l1111lllll1l_l1_ = l11l111ll1l1_l1_[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ娷")]
		for l111l1ll1l11_l1_ in l11l11llll11_l1_:
			l111111lll11_l1_ = l111l1ll1l11_l1_[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ娸")]
			l11l11l11l1_l1_ = l111111lll11_l1_+l1111lllll1l_l1_
			title = l111l1ll1l11_l1_[l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ娹")].replace(l11ll1_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧ娺"),l11ll1_l1_ (u"࠭࡭ࡱࡦࠣࠤࠬ娻"))
			title = title.replace(l111l1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ娼")]+l11ll1_l1_ (u"ࠨࠢࠣࠫ娽"),l11ll1_l1_ (u"ࠩࠪ娾"))
			title = title.replace(str((float(l111111lll11_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ娿"),str((float(l11l11l11l1_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠫࡰࡨࡰࡴࠩ婀"))
			title = title+l11ll1_l1_ (u"ࠬ࠮ࠧ婁")+l11l111ll1l1_l1_[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ婂")].split(l11ll1_l1_ (u"ࠧࠩࠩ婃"),1)[1]
			l11111l1ll1l_l1_.append([l111l1ll1l11_l1_,l11l111ll1l1_l1_,title,l11l11l11l1_l1_])
	l11111l1ll1l_l1_ = sorted(l11111l1ll1l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111l1ll1l11_l1_,l11l111ll1l1_l1_,title,l11l11l11l1_l1_ in l11111l1ll1l_l1_:
		l111llll11l1_l1_ = l111l1ll1l11_l1_[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ婄")]
		if l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ婅") in list(l11l111ll1l1_l1_.keys()):
			l111llll11l1_l1_ = l11ll1_l1_ (u"ࠪࡱࡵࡪࠧ婆")
			#l111llll11l1_l1_ = l111llll11l1_l1_+l11l111ll1l1_l1_[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭婇")]
		if l111llll11l1_l1_ not in l111l1l11lll_l1_:
			l111l1l11lll_l1_.append(l111llll11l1_l1_)
			l1lllll11l111_l1_.append([l111l1ll1l11_l1_,l11l111ll1l1_l1_,title,l11l11l11l1_l1_])
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭婈"),str(l11l11l11l1_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ婉")+title)
	#l1lllll11l111_l1_ = sorted(l1lllll11l111_l1_, reverse=True, key=lambda key: int(key[3]))
	l11111l1l1l1_l1_,l1111lll1111_l1_,shift = [],[],0
	l11ll1_l1_ (u"ࠢࠣࠤࠍࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡳࡼࡴࡥࡳ࠼ࠍࠍࠎࡹࡨࡪࡨࡷࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ࠯ࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠰࡞࠭ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠵ࡢࠐࠉࠊࡵࡨࡰࡪࡩࡴࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡤࡪࡲ࡭ࡨ࡫ࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠧࠨࠢ婊")
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࡣࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡣࡩࡣࡱࡲࡪࡲࡉࡥࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯ࡣ࡯ࡹ࡯࡯࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡧࡵࡵࡪࡲࡶࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲ࡟࡫ࡵࡲࡲ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶࡤࡴࡡ࡮ࡧ࠽ࠎࠎࠏࡩ࡮ࡣࡪࡩࡸࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠦ࠭࠴ࠪࡀࠫࠥࡥࡱࡲ࡯ࡸࡔࡤࡸ࡮ࡴࡧࡴࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࠊ࡫ࡰࡥ࡬࡫ࡳࡠࡷࡵࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌ࡭࡫ࠦࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮࠽ࠤ࡮ࡳࡡࡨࡧࠣࡁࠥ࡯࡭ࡢࡩࡨࡷࡤࡻࡲ࡭࡝࠰࠵ࡢࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡲࡻࡳ࡫ࡲࡠࡰࡤࡱࡪࡡ࠰࡞ࠌࠌࠍࡸ࡮ࡩࡧࡶࠣ࠯ࡂࠦ࠱ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ࠮ࡳࡼࡴࡥࡳ࠭ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽࡙ࠡࡈࡆࡘࡏࡔࡆࡕ࡞ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬࡣ࡛࠱࡟࠮ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧࠬࡱࡺࡲࡪࡸ࡟ࡤࡪࡤࡲࡳ࡫࡬࡜࠲ࡠࠎࠎࠏࡳࡦ࡮ࡨࡧࡹࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡩࡨࡰ࡫ࡦࡩࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ婋")
	l11l11l11l1l_l1_,l111lll1l1ll_l1_ = l11ll1_l1_ (u"ࠩࠪ婌"),l11ll1_l1_ (u"ࠪࠫ婍")
	try: l11l11l11l1l_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ婎")][l11ll1_l1_ (u"ࠬࡧࡵࡵࡪࡲࡶࠬ婏")]
	except: l11l11l11l1l_l1_ = l11ll1_l1_ (u"࠭ࠧ婐")
	try: l1111l111lll_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭婑")][l11ll1_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ婒")]
	except: l1111l111lll_l1_ = l11ll1_l1_ (u"ࠩࠪ婓")
	if l11l11l11l1l_l1_ and l1111l111lll_l1_:
		shift += 1
		title = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ婔")+l11l11l11l1l_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭婕")
		l1lllll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭婖")][0]+l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ婗")+l1111l111lll_l1_
		l11111l1l1l1_l1_.append(title)
		l1111lll1111_l1_.append(l1lllll_l1_)
		try: l111lll1l1ll_l1_ = l111111l1l11_l1_[l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭婘")][l11ll1_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ婙")][l11ll1_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭婚")][-1][l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ婛")]
		except: pass
	#if l1lllll1ll1l1_l1_:
	#	shift += 1
	#	l11111l1l1l1_l1_.append(l11ll1_l1_ (u"ࠫࡲࡶࡤࠡฮ๋ำฮࠦะไ์ฬࠫ婜")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠬࡪࡡࡴࡪࠪ婝"))
	for l111l1ll1l11_l1_,l11l111ll1l1_l1_,title,l11l11l11l1_l1_ in l1lllll11l111_l1_:
		l11111l1l1l1_l1_.append(title) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧ婞"))
	if l11l1l11111l_l1_: l11111l1l1l1_l1_.append(l11ll1_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩ婟")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ婠"))
	if l11111l1ll1l_l1_: l11111l1l1l1_l1_.append(l11ll1_l1_ (u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭婡")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ婢"))
	if l111lll111ll_l1_: l11111l1l1l1_l1_.append(l11ll1_l1_ (u"ࠫࡲࡶࡤࠡษัฮึࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭婣")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ婤"))
	if l111l1lllll1_l1_: l11111l1l1l1_l1_.append(l11ll1_l1_ (u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭婥")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婦"))
	if l11l111l11ll_l1_: l11111l1l1l1_l1_.append(l11ll1_l1_ (u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨ婧")) ; l1111lll1111_l1_.append(l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ婨"))
	l11l1l1111ll_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1llll1llll1l_l1_, l11111l1l1l1_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ婩"),[],[]
		elif l1l_l1_==0 and l11l11l11l1l_l1_:
			l1lllll_l1_ = l1111lll1111_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11ll1_l1_ (u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫ婪")+QUOTE(l11l11l11l1l_l1_)+l11ll1_l1_ (u"ࠬࠬࡵࡳ࡮ࡀࠫ婫")+l1lllll_l1_
			if l111lll1l1ll_l1_: new_path = new_path+l11ll1_l1_ (u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧ婬")+QUOTE(l111lll1l1ll_l1_)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ婭")+new_path+l11ll1_l1_ (u"ࠣࠫࠥ婮"))
			return l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ婯"),[],[]
		choice = l1111lll1111_l1_[l1l_l1_]
		l1111111111l_l1_ = l11111l1l1l1_l1_[l1l_l1_]
		if choice==l11ll1_l1_ (u"ࠪࡨࡦࡹࡨࠨ婰"):
			l1llllll1l1ll_l1_ = l1lllll1ll1l1_l1_
			break
		elif choice in [l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ婱"),l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ婲"),l11ll1_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ婳")]:
			if choice==l11ll1_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭婴"): l1lll11l_l1_,l1111l1l1ll1_l1_ = l11l1l11111l_l1_,l1111l1l111l_l1_
			elif choice==l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婵"): l1lll11l_l1_,l1111l1l1ll1_l1_ = l111l1lllll1_l1_,l1111ll11ll1_l1_
			elif choice==l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ婶"): l1lll11l_l1_,l1111l1l1ll1_l1_ = l11l111l11ll_l1_,l111lllllll1_l1_
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ婷"), l1lll11l_l1_)
			if l1l_l1_!=-1:
				l1llllll1l1ll_l1_ = l1111l1l1ll1_l1_[l1l_l1_][l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ婸")]
				l1111111111l_l1_ = l1lll11l_l1_[l1l_l1_]
				break
		elif choice==l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ婹"):
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ัส࠼ࠪ婺"), l111lll111ll_l1_)
			if l1l_l1_!=-1:
				l1111111111l_l1_ = l111lll111ll_l1_[l1l_l1_]
				l111lll1ll11_l1_ = l11l11llll11_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่ห࠼ࠪ婻"), l1111llll11l_l1_)
				if l1l_l1_!=-1:
					l1111111111l_l1_ += l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ婼")+l1111llll11l_l1_[l1l_l1_]
					l111l1ll11l1_l1_ = l11l11l1lll1_l1_[l1l_l1_]
					l11l1l1111ll_l1_ = True
					break
		elif choice==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭婽"):
			l11l11111lll_l1_,l111l11111ll_l1_,l1lllll11ll1l_l1_,l111ll1l11ll_l1_ = list(zip(*l11111l1ll1l_l1_))
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ婾"), l1lllll11ll1l_l1_)
			if l1l_l1_!=-1:
				l1111111111l_l1_ = l1lllll11ll1l_l1_[l1l_l1_]
				l111lll1ll11_l1_ = l11l11111lll_l1_[l1l_l1_]
				if l11ll1_l1_ (u"ࠫࡲࡶࡤࠨ婿") in l1lllll11ll1l_l1_[l1l_l1_] and l111lll1ll11_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ媀")]!=l1lllll1ll1l1_l1_:
					l111l1ll11l1_l1_ = l111l11111ll_l1_[l1l_l1_]
					l11l1l1111ll_l1_ = True
				else: l1llllll1l1ll_l1_ = l111lll1ll11_l1_[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ媁")]
				break
		elif choice==l11ll1_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ媂"):
			#shift += 1
			l11l11111lll_l1_,l111l11111ll_l1_,l1lllll11ll1l_l1_,l111ll1l11ll_l1_ = list(zip(*l1lllll11l111_l1_))
			l111lll1ll11_l1_ = l11l11111lll_l1_[l1l_l1_-shift]
			if l11ll1_l1_ (u"ࠨ࡯ࡳࡨࠬ媃") in l1lllll11ll1l_l1_[l1l_l1_-shift] and l111lll1ll11_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭媄")]!=l1lllll1ll1l1_l1_:
				l111l1ll11l1_l1_ = l111l11111ll_l1_[l1l_l1_-shift]
				l11l1l1111ll_l1_ = True
			else: l1llllll1l1ll_l1_ = l111lll1ll11_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ媅")]
			l1111111111l_l1_ = l1lllll11ll1l_l1_[l1l_l1_-shift]
			break
	if not l11l1l1111ll_l1_: l1llllll11ll1_l1_ = l1llllll1l1ll_l1_
	else: l1llllll11ll1_l1_ = l11ll1_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠬ媆")+l111lll1ll11_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ媇")]+l11ll1_l1_ (u"࠭ࠠࠬࠢࡄࡹࡩ࡯࡯࠻ࠢࠪ媈")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ媉")]
	if l11l1l1111ll_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ媊"),l11ll1_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭媋")+str(l111lll1ll11_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ媌"),l11ll1_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮࠯ࠥࠦࠠࠨ媍")+str(l111l1ll11l1_l1_))
		#if l11l11lll1l1_l1_>l111l1l111l1_l1_: l1l11lll1_l1_ = str(l11l11lll1l1_l1_)
		#else: l1l11lll1_l1_ = str(l111l1l111l1_l1_)
		#l1l11lll1_l1_ = str(l11l11lll1l1_l1_) if l11l11lll1l1_l1_>l111l1l111l1_l1_ else str(l111l1l111l1_l1_)
		l11l11lll1l1_l1_ = int(l111lll1ll11_l1_[l11ll1_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ媎")])
		l111l1l111l1_l1_ = int(l111l1ll11l1_l1_[l11ll1_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ媏")])
		l1l11lll1_l1_ = str(max(l11l11lll1l1_l1_,l111l1l111l1_l1_))
		l111l11l11l1_l1_ = l111lll1ll11_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ媐")].replace(l11ll1_l1_ (u"ࠨࠨࠪ媑"),l11ll1_l1_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ媒"))		# +l11ll1_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠰࠱࠲࠳࠴࠵࠶ࠧ媓")
		l11l111l1l11_l1_ = l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ媔")].replace(l11ll1_l1_ (u"ࠬࠬࠧ媕"),l11ll1_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ媖"))		# +l11ll1_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ媗")
		l11l1l111111_l1_ = l11ll1_l1_ (u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ媘")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪ媙")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩ媚")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ媛")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩ媜")+l111lll1ll11_l1_[l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ媝")]+l11ll1_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ媞")		# l111l1l1l11l_l1_=l11ll1_l1_ (u"ࠣ࠳ࠥ媟") l11l11lllll1_l1_=l11ll1_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ媠") default=l11ll1_l1_ (u"ࠥࡸࡷࡻࡥࠣ媡")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ媢")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ媣")+l111lll1ll11_l1_[l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ媤")]+l11ll1_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ媥")+l111lll1ll11_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ媦")]+l11ll1_l1_ (u"ࠩࠥࠤࡸࡺࡡࡳࡶ࡚࡭ࡹ࡮ࡓࡂࡒࡀࠦ࠶ࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦࠬ媧")+str(l111lll1ll11_l1_[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ媨")])+l11ll1_l1_ (u"ࠫࠧࠦࡷࡪࡦࡷ࡬ࡂࠨࠧ媩")+str(l111lll1ll11_l1_[l11ll1_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ媪")])+l11ll1_l1_ (u"࠭ࠢࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠪ媫")+str(l111lll1ll11_l1_[l11ll1_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ媬")])+l11ll1_l1_ (u"ࠨࠤࠣࡪࡷࡧ࡭ࡦࡔࡤࡸࡪࡃࠢࠨ媭")+l111lll1ll11_l1_[l11ll1_l1_ (u"ࠩࡩࡴࡸ࠭媮")]+l11ll1_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ媯")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ媰")+l111l11l11l1_l1_+l11ll1_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ媱")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ媲")+l111lll1ll11_l1_[l11ll1_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭媳")]+l11ll1_l1_ (u"ࠨࠤࡁࡠࡳ࠭媴")	# l1lllll11l11l_l1_=l11ll1_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ媵")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭媶")+l111lll1ll11_l1_[l11ll1_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ媷")]+l11ll1_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ媸")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ媹")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭媺")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭媻")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠲ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡡࡶࡦ࡬ࡳ࠴࠭媼")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ媽")]+l11ll1_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ媾")		# l111l1l1l11l_l1_=l11ll1_l1_ (u"ࠧ࠷ࠢ媿") l11l11lllll1_l1_=l11ll1_l1_ (u"ࠨࡴࡳࡷࡨࠦ嫀") default=l11ll1_l1_ (u"ࠢࡵࡴࡸࡩࠧ嫁")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭嫂")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ嫃")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ嫄")]+l11ll1_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ嫅")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ嫆")]+l11ll1_l1_ (u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩ嫇")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭嫈")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ嫉")]+l11ll1_l1_ (u"ࠩࠥ࠳ࡃࡢ࡮ࠨ嫊")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭嫋")+l11l111l1l11_l1_+l11ll1_l1_ (u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ嫌")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ嫍")+l111l1ll11l1_l1_[l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ嫎")]+l11ll1_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ嫏")	# l1lllll11l11l_l1_=l11ll1_l1_ (u"ࠣࡶࡵࡹࡪࠨ嫐")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ嫑")+l111l1ll11l1_l1_[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ嫒")]+l11ll1_l1_ (u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ嫓")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ嫔")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ嫕")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ嫖")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭嫗")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ嫘")
		#open(l11ll1_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ嫙"),l11ll1_l1_ (u"ࠫࡼࡨࠧ嫚")).write(l11l1l111111_l1_)
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭嫛"),l11l1l111111_l1_)
		#l11l1l111111_l1_ = OPENURL_CACHED(NO_CACHE,l1lllll1ll1l1_l1_,l11ll1_l1_ (u"࠭ࠧ嫜"),l11ll1_l1_ (u"ࠧࠨ嫝"),l11ll1_l1_ (u"ࠨࠩ嫞"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠹ࡵࡪࠪ嫟"))
		if kodi_version>18.99:
			import http.server as l111ll111lll_l1_
			import http.client as l11111l1l11l_l1_
		else:
			import BaseHTTPServer as l111ll111lll_l1_
			import httplib as l11111l1l11l_l1_
		class l1lllllllll11_l1_(l111ll111lll_l1_.HTTPServer):
			#l11l1l111111_l1_ = l11ll1_l1_ (u"ࠪࡀࡃ࠭嫠")
			def __init__(self,l1ll11111l1l_l1_=l11ll1_l1_ (u"ࠫࡱࡵࡣࡢ࡮࡫ࡳࡸࡺࠧ嫡"),port=55055,l11l1l111111_l1_=l11ll1_l1_ (u"ࠬࡂ࠾ࠨ嫢")):
				self.l1ll11111l1l_l1_ = l1ll11111l1l_l1_
				self.port = port
				self.l11l1l111111_l1_ = l11l1l111111_l1_
				l111ll111lll_l1_.HTTPServer.__init__(self,(self.l1ll11111l1l_l1_,self.port),l1111lll11ll_l1_)
				self.l1lllllll1l11_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ嫣")+l1ll11111l1l_l1_+l11ll1_l1_ (u"ࠧ࠻ࠩ嫤")+str(port)+l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ嫥")
				#print(l11ll1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡻࡰࠡࡰࡲࡻࠥࡲࡩࡴࡶࡨࡲ࡮ࡴࡧࠡࡱࡱࠤࡵࡵࡲࡵ࠼ࠣࠫ嫦")+str(port))
			def start(self):
				self.threads = l111l1l11l1_l1_(False)
				self.threads.start_new_thread(1,self.l111l11lll11_l1_)
			def l111l11lll11_l1_(self):
				#print(l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡣࡵࡸࡪࡪࠧ嫧"))
				self.l1lllll111l11_l1_ = True
				#l1l1l1lllll_l1_ = 0
				while self.l1lllll111l11_l1_:
					#l1l1l1lllll_l1_ += 1
					#print(l11ll1_l1_ (u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠥࡧࠠࡴ࡫ࡱ࡫ࡱ࡫ࠠࡩࡣࡱࡨࡱ࡫࡟ࡳࡧࡴࡹࡪࡹࡴࠩࠫࠣࡲࡴࡽ࠺ࠡࠩ嫨")+str(l1l1l1lllll_l1_)+l11ll1_l1_ (u"ࠬ࠭嫩"))
					#settimeout l1111ll1ll_l1_ not l111l1l111_l1_ l1111l111111_l1_ to error message if it l111111l11l1_l1_ l1lllll1l11ll_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111l11lll11_l1_ l111l1l11ll1_l1_ request l1llllll1ll1l_l1_ 60 seconds)
					self.handle_request()
				#print(l11ll1_l1_ (u"࠭ࡳࡦࡴࡹ࡭ࡳ࡭ࠠࡳࡧࡴࡹࡪࡹࡴࡴࠢࡶࡸࡴࡶࡰࡦࡦ࡟ࡲࠬ嫪"))
			def stop(self):
				self.l1lllll111l11_l1_ = False
				self.l111l1ll1l1l_l1_()	# needed to l11l11ll111l_l1_ self.handle_request() to l111l11lll11_l1_ l1111l1lll1_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11ll1_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡨࡴࡽ࡮ࠡࡰࡲࡻࡡࡴࠧ嫫"))
			def load(self,l11l1l111111_l1_):
				self.l11l1l111111_l1_ = l11l1l111111_l1_
			def l111l1ll1l1l_l1_(self):
				conn = l11111l1l11l_l1_.HTTPConnection(self.l1ll11111l1l_l1_+l11ll1_l1_ (u"ࠨ࠼ࠪ嫬")+str(self.port))
				conn.request(l11ll1_l1_ (u"ࠤࡋࡉࡆࡊࠢ嫭"), l11ll1_l1_ (u"ࠥ࠳ࠧ嫮"))
		class l1111lll11ll_l1_(l111ll111lll_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11ll1_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡋࡊ࡚ࠠࠡࠩ嫯")+self.path)
				self.send_response(200)
				self.send_header(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ嫰"),l11ll1_l1_ (u"࠭ࡴࡦࡺࡷ࠳ࡵࡲࡡࡪࡰࠪ嫱"))
				self.end_headers()
				#self.wfile.write(self.path+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嫲"))
				self.wfile.write(self.server.l11l1l111111_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭嫳")))
				time.sleep(1)
				if self.path==l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ嫴"): self.server.shutdown()
				if self.path==l11ll1_l1_ (u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭嫵"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11ll1_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡌࡊࡇࡄࠡࠢࠪ嫶")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1lllllllll11_l1_(l11ll1_l1_ (u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ嫷"),55055,l11l1l111111_l1_)
		#httpd.load(l11l1l111111_l1_)
		l1llllll1l1ll_l1_ = httpd.l1lllllll1l11_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1llllll1l1ll_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭࡫ࡹࡩࡸ࡯࡭࠯ࡦࡤࡷ࡭࡯ࡦ࠯ࡱࡵ࡫࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠵ࡣࡩࡷࡱ࡯ࡩࡻࡲࡠ࠳࠲ࡥࡹࡵ࡟࠸࠱ࡷࡩࡸࡺࡰࡪࡥ࠷ࡣ࠽ࡹ࠯ࡎࡣࡱ࡭࡫࡫ࡳࡵ࠰ࡰࡴࡩ࠭嫸")
		#l1llllll1l1ll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡤࡷ࡭࠴ࡡ࡬ࡣࡰࡥ࡮ࢀࡥࡥ࠰ࡱࡩࡹ࠵ࡤࡢࡵ࡫࠶࠻࠺࠯ࡕࡧࡶࡸࡈࡧࡳࡦࡵ࠲࠶ࡨ࠵ࡱࡶࡣ࡯ࡧࡴࡳ࡭࠰࠳࠲ࡑࡺࡲࡴࡪࡔࡨࡷࡒࡖࡅࡈ࠴࠱ࡱࡵࡪࠧ嫹")
		#l1llllll1l1ll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸࡸ࡯࠮ࡵࡧ࡯ࡩࡨࡵ࡭࠮ࡲࡤࡶ࡮ࡹࡴࡦࡥ࡫࠲࡫ࡸ࠯ࡨࡲࡤࡧ࠴ࡊࡁࡔࡊࡢࡇࡔࡔࡆࡐࡔࡐࡅࡓࡉࡅ࠰ࡖࡨࡰࡪࡩ࡯࡮ࡒࡤࡶ࡮ࡹࡔࡦࡥ࡫࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠵࡭ࡱ࠶࠰ࡰ࡮ࡼࡥ࠮࡯ࡳࡨ࠲ࡇࡖ࠮ࡄࡖ࠲ࡲࡶࡤࠨ嫺")
		#l1llllll1l1ll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡨࡲ࡫ࡤࡪࡣ࠱ࡦࡧࡩ࠮ࡤࡱ࠱ࡹࡰ࠵ࡤࡢࡵ࡫࠳ࡴࡴࡤࡦ࡯ࡤࡲࡩ࠵ࡴࡦࡵࡷࡧࡦࡸࡤ࠰࠳࠲ࡧࡱ࡯ࡥ࡯ࡶࡢࡱࡦࡴࡩࡧࡧࡶࡸ࠲࡫ࡶࡦࡰࡷࡷ࠲ࡳࡵ࡭ࡶ࡬ࡰࡦࡴࡧ࠯࡯ࡳࡨࠬ嫻")
		#l1llllll1l1ll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ嫼")
	else: httpd = l11ll1_l1_ (u"ࠫࠬ嫽")
	if not l1llllll1l1ll_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ嫾"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ嫿"),[l11ll1_l1_ (u"ࠧࠨ嬀")],[[l1llllll1l1ll_l1_,l111l111l11l_l1_,httpd]]
def l1111l1111ll_l1_(url):
	# https://l11l11l1l1l1_l1_.com/l1111ll11l1l_l1_
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嬁") : l11ll1_l1_ (u"ࠩࠪ嬂") }
	#url = url.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ嬃"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ嬄"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭嬅"),headers,l11ll1_l1_ (u"࠭ࠧ嬆"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ嬇"))
	items = re.findall(l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ嬈"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1111111l1l1_l1_,l1lll11l_l1_,l11l1111l1ll_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1lllll_l1_,dummy,l1ll1l1l1lll_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ嬉"),l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ嬊"))
			if l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ嬋") in l1lllll_l1_:
				l1111111l1l1_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嬌"),l11ll1_l1_ (u"࠭ࠧ嬍"),str(l1llll_l1_),str(l11l1111l1ll_l1_))
				l1llll_l1_ = l1llll_l1_ + l11l1111l1ll_l1_
				if l1111111l1l1_l1_[0]==l11ll1_l1_ (u"ࠧ࠮࠳ࠪ嬎"): l1lll11l_l1_.append(l11ll1_l1_ (u"ࠨีํีๆืࠠฯษุࠫ嬏")+l11ll1_l1_ (u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ嬐"))
				else:
					for title in l1111111l1l1_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭嬑")+l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ嬒")+title)
			else:
				title = l11ll1_l1_ (u"ู๊ࠬาใิࠤำอีࠨ嬓")+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩ嬔")+l1ll1l1l1lll_l1_
				l1llll_l1_.append(l1lllll_l1_)
				l1lll11l_l1_.append(title)
		return l11ll1_l1_ (u"ࠧࠨ嬕"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ嬖"),[],[]
def	l1lllll1lll11_l1_(url):
	# https://l11l11ll1l11_l1_.cc/l1l111l1l_l1_-1qrpoobdg7bu.html
	# https://l111l1ll1111_l1_.cc//l1l111l1l_l1_-l111ll1l1l11_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嬗"),url,l11ll1_l1_ (u"ࠪࠫ嬘"),l11ll1_l1_ (u"ࠫࠬ嬙"),l11ll1_l1_ (u"ࠬ࠭嬚"),l11ll1_l1_ (u"࠭ࠧ嬛"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜࡛ࡏࡄࡆࡑࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ嬜"))
	html = response.content
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嬝"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		return l11ll1_l1_ (u"ࠩࠪ嬞"),[l11ll1_l1_ (u"ࠪࠫ嬟")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠫࠬ嬠"),[],[]
def	l1llllll11l11_l1_(url):
	# https://l1llllll111ll_l1_.in/l111111l1ll1_l1_
	# https://l1llllll111ll_l1_.in/l1l111l1l_l1_-l111111l1ll1_l1_.html
	# https://l111ll11ll11_l1_.l11111ll11ll_l1_/l11l11l1111l_l1_
	# https://l111ll11ll11_l1_.l11111ll11ll_l1_/l1l111l1l_l1_-l11l11l1111l_l1_.html
	# https://www.l11l11l11lll_l1_.com/l1l111l1l_l1_-l1111lllllll_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ嬡"),l11ll1_l1_ (u"࠭ࠧ嬢")).replace(l11ll1_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭嬣"),l11ll1_l1_ (u"ࠨࠩ嬤"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嬥"),url,l11ll1_l1_ (u"ࠪࠫ嬦"),l11ll1_l1_ (u"ࠫࠬ嬧"),l11ll1_l1_ (u"ࠬ࠭嬨"),l11ll1_l1_ (u"࠭ࠧ嬩"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭嬪"))
	html = response.content
	l1ll1l1lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ嬫"),html,re.DOTALL)
	if l1ll1l1lll1l_l1_:
		l1ll1l1lll1l_l1_ = l1ll1l1lll1l_l1_[0]
		l1l1lll1111l_l1_ = l1ll1111ll11_l1_(l1ll1l1lll1l_l1_)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嬬"),l1l1lll1111l_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪࠬࢁࠬ嬭"),l1l1lll1111l_l1_,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_,title in l1l1_l1_:
			if not title: title = l1lllll_l1_.rsplit(l11ll1_l1_ (u"ࠫ࠳࠭嬮"),1)[1]
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		return l11ll1_l1_ (u"ࠬ࠭嬯"),l1lll11l_l1_,l1llll_l1_
	id = url.split(l11ll1_l1_ (u"࠭࠯ࠨ嬰"))[3]
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嬱"):l11ll1_l1_ (u"ࠨࠩ嬲") , l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ嬳"):l11ll1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ嬴") }
	payload = { l11ll1_l1_ (u"ࠫ࡮ࡪࠧ嬵"):id , l11ll1_l1_ (u"ࠬࡵࡰࠨ嬶"):l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ嬷") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ嬸"),url,payload,headers,l11ll1_l1_ (u"ࠨࠩ嬹"),l11ll1_l1_ (u"ࠩࠪ嬺"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ嬻"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嬼"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠬ࠭嬽"),[l11ll1_l1_ (u"࠭ࠧ嬾")],[ items[0] ]
	return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡛ࠢࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇࠨ嬿"),[],[]
l11ll1_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡉࡒ࡚ࡎࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡼࡩࡥࡧࡲ࠳ࡵࡲࡡࡺ࠱ࡄࡅ࡛ࡋࡎࡥࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠡࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࠠ࠻ࠢࠪࠫࠥࢃࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔ࡜ࡉࡅ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࡟࠵ࡣ࠽࠾ࠩ࠰࠵ࠬࡀࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠽ࠎࠎࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰࡴ࠹࠭ࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓ࡛ࡏࡄࠨ࠮࡞ࡡ࠱ࡡ࡝ࠋࠋࠦࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠱࡮࠰ࡪࡳࡻ࡯ࡤ࠯ࡥࡲ࠳ࡸࡺࡲࡦࡣࡰ࠳࠷࠸࠹࠯࡯࠶ࡹ࠽ࠐࠢࠣࠤ孀")
#####################################################
#    l11l111ll11l_l1_ l1111ll1l1ll_l1_ l11111ll1ll1_l1_
#    16-06-2019
#####################################################
def l1111l1lll1l_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ孁"),l11ll1_l1_ (u"ࠪࠫ孂"),l11ll1_l1_ (u"ࠫࠬ孃"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ孄"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ孅"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠧࠨ孆"),[l11ll1_l1_ (u"ࠨࠩ孇")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧ孈"),[],[]
def l1111l1l11l1_l1_(url):
	return l11ll1_l1_ (u"ࠪࠫ孉"),[l11ll1_l1_ (u"ࠫࠬ孊")],[ url ]
def l1111ll1ll1l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭孋"),l11ll1_l1_ (u"࠭ࠧ孌"),url,l11ll1_l1_ (u"ࠧࠨ孍"))
	server = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ孎"))
	basename = l11ll1_l1_ (u"ࠩ࠲ࠫ孏").join(server[0:3])
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ子"),l11ll1_l1_ (u"ࠫࠬ孑"),l11ll1_l1_ (u"ࠬ࠭孒"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪ孓"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ孔"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ孕"),l11ll1_l1_ (u"ࠩࠪ孖"),url,str(var))
	if items:
		l11ll111ll1l_l1_,l11ll11ll11l_l1_,l11ll11ll1l1_l1_,l111ll1l111l_l1_,l111ll1l11l1_l1_,l111ll1l1111_l1_ = items[0]
		var = int(l11ll11ll11l_l1_) % int(l11ll11ll1l1_l1_) + int(l111ll1l111l_l1_) % int(l111ll1l11l1_l1_)
		url = basename + l11ll111ll1l_l1_ + str(var) + l111ll1l1111_l1_
		return l11ll1_l1_ (u"ࠪࠫ字"),[l11ll1_l1_ (u"ࠫࠬ存")],[url]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫ孙"),[],[]
def l111ll111ll1_l1_(url):
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭孚"),l11ll1_l1_ (u"ࠧࠨ孛"))
	url = url.replace(l11ll1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ孜"),l11ll1_l1_ (u"ࠩࠪ孝"))
	id = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ孞"))[-1]
	headers = { l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ孟") : l11ll1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ孠") }
	payload = { l11ll1_l1_ (u"ࠨࡩࡥࠤ孡"):id , l11ll1_l1_ (u"ࠢࡰࡲࠥ孢"):l11ll1_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦ季") }
	request = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ孤"), url, payload, headers, l11ll1_l1_ (u"ࠪࠫ孥"),l11ll1_l1_ (u"ࠫࠬ学"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡓ࠸࡚ࡖࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ孧"))
	if l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ孨") in list(request.headers.keys()): l1lllll_l1_ = request.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ孩")]
	else: l1lllll_l1_ = url
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠨࠩ孪"),[l11ll1_l1_ (u"ࠩࠪ孫")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡐ࠵ࡗࡓࡐࡔࡇࡄࠨ孬"),[],[]
def l11111l111ll_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ孭"),l11ll1_l1_ (u"ࠬ࠭孮"),l11ll1_l1_ (u"࠭ࠧ孯"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡎࡔࡔࡗࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ孰"))
	items = re.findall(l11ll1_l1_ (u"ࠨ࡯ࡳ࠸࠿ࠦ࡜࡜࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ孱"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠩࠪ孲"),[l11ll1_l1_ (u"ࠪࠫ孳")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡊࡐࡗ࡚ࡑࡏࡖࡆࠩ孴"),[],[]
def l1lllll111ll1_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭孵"),l11ll1_l1_ (u"࠭ࠧ孶"),l11ll1_l1_ (u"ࠧࠨ孷"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡃࡉࡋ࡙ࡉ࠲࠷ࡳࡵࠩ學"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ孹"),html,re.DOTALL)
	#l111l1l1llll_l1_.l1lllll1l1111_l1_(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠳ࡵࡲࡨࠩ孺") + items[0])
	if items:
		url = url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ孻") + items[0]
		return l11ll1_l1_ (u"ࠬ࠭孼"),[l11ll1_l1_ (u"࠭ࠧ孽")],[ url ]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ孾"),[],[]
def l111l111111l_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ孿"),l11ll1_l1_ (u"ࠩࠪ宀"),l11ll1_l1_ (u"ࠪࠫ宁"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡗࡅࡐࡎࡉࡖࡊࡆࡈࡓࡍࡕࡓࡕ࠯࠴ࡷࡹ࠭宂"))
	items = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ它"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ宄"),l11ll1_l1_ (u"ࠧࠨ宅"),str(items),html)
	if items: return l11ll1_l1_ (u"ࠨࠩ宆"),[l11ll1_l1_ (u"ࠩࠪ宇")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚ࠧ守"),[],[]
def l1111l1ll11l_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ安"),l11ll1_l1_ (u"ࠬ࠭宊"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ宋"),l11ll1_l1_ (u"ࠧࠨ完"),l11ll1_l1_ (u"ࠨࠩ宍"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ宎"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ宏"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ宐"),l11ll1_l1_ (u"ࠬ࠭宑"),items[0],items[0])
	if items: return l11ll1_l1_ (u"࠭ࠧ宒"),[l11ll1_l1_ (u"ࠧࠨ宓")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫ宔"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪᣱ")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡇࡒࡉ࡟ࠨᣲ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"้ࠪํู่่ࠡอๅ้๐ใิࠩᣳ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l11111_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l1llll1l_l1_(url)
	elif mode==494: results = l1l111_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᣴ"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭ᣵ"),l11ll1_l1_ (u"࠭ࠧ᣶"),l11ll1_l1_ (u"ࠧࠨ᣷"),l11ll1_l1_ (u"ࠨࠩ᣸"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᣹"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᣺"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠫ࠴࠭᣻"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ᣼"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᣽"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ᣾"),l1ll111_l1_,499,l11ll1_l1_ (u"ࠨࠩ᣿"),l11ll1_l1_ (u"ࠩࠪᤀ"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᤁ"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤂ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᤃ")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬᤄ"),l1ll111_l1_,491,l11ll1_l1_ (u"ࠧࠨᤅ"),l11ll1_l1_ (u"ࠨࠩᤆ"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᤇ"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᤈ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᤉ"),l11ll1_l1_ (u"ࠬ࠭ᤊ"),9999)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠠࡂ࡬ࡤࡼ࡮࡬ࡹࡇ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᤋ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡬ࡩ࡭ࡶࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᤌ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵࡯࡭ࡦ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫᤍ")+l1lllll_l1_+l11ll1_l1_ (u"ࠩ࠱ࡴ࡭ࡶࠧᤎ")
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᤏ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᤐ")+l111l1_l1_+title,l1lllll_l1_,491)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᤑ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᤒ"),l11ll1_l1_ (u"ࠧࠨᤓ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤔ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᤕ")+l111l1_l1_+l11ll1_l1_ (u"ࠪวๆ๊วๆࠩᤖ"),l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศใ็ห๊࠳࡭ࡰࡸ࡬ࡩࡸ࠳ࡦࡪ࡮ࡰࡩ࠴࡬࡯ࡳࡧ࡬࡫ࡳ࠳ࡨࡥ࠯สๅ้อๅ࠮ษฯ๊อ๏࠭࠳ࠩᤗ"),494,l11ll1_l1_ (u"ࠬ࠭ᤘ"),l11ll1_l1_ (u"࠭ࠧᤙ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᤚ"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤛ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᤜ")+l111l1_l1_+l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠫᤝ"),l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ๆี็ื้อส࠰็ึุ่๊วห࠯สะ๋ฮ้ࠨᤞ"),494,l11ll1_l1_ (u"ࠬ࠭᤟"),l11ll1_l1_ (u"࠭ࠧᤠ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᤡ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᤢ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᤣ"),l11ll1_l1_ (u"ࠪࠫᤤ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᤥ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᤦ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"࠭࠯ࠨᤧ"): continue
		if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬᤨ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤩ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᤪ")+l111l1_l1_+title,l1lllll_l1_,491)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᤫ"),l11ll1_l1_ (u"ࠫࠬ᤬"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ᤭"),url,l11ll1_l1_ (u"࠭ࠧ᤮"),l11ll1_l1_ (u"ࠧࠨ᤯"),l11ll1_l1_ (u"ࠨࠩᤰ"),l11ll1_l1_ (u"ࠩࠪᤱ"),l11ll1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᤲ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᤳ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᤴ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤵ"),l111l1_l1_+title,l1lllll_l1_,491)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠧࠨᤶ")):
	items = []
	#l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᤷ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᤸ"),url,l11ll1_l1_ (u"᤹ࠪࠫ"),l11ll1_l1_ (u"ࠫࠬ᤺"),l11ll1_l1_ (u"᤻ࠬ࠭"),l11ll1_l1_ (u"࠭ࠧ᤼"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭᤽"))
	html = response.content
	block = l11ll1_l1_ (u"ࠨࠩ᤾")
	if l11ll1_l1_ (u"ࠩ࠱ࡴ࡭ࡶࠧ᤿") in url: block = html
	elif l11ll1_l1_ (u"ࠪࡃࡸࡃࠧ᥀") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡨ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࠥࡱࡦࡴࡩࡧࡧࡶࡸࠧ࠭᥁"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᥂"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࠧࡳࡡ࡯࡫ࡩࡩࡸࡺࠢࠨ᥃"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
	if not block: return
	#if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࡜࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡦࡴࡾࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᥄"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ᥅"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ᥆"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ᥇"),l11ll1_l1_ (u"ࠫศเๆ๋หࠪ᥈"),l11ll1_l1_ (u"้ࠬไ๋สࠪ᥉"),l11ll1_l1_ (u"࠭วฺๆส๊ࠬ᥊"),l11ll1_l1_ (u"่ࠧัสๅࠬ᥋"),l11ll1_l1_ (u"ࠨ็หหึอษࠨ᥌"),l11ll1_l1_ (u"ࠩ฼ี฻࠭᥍"),l11ll1_l1_ (u"้ࠪ์ืฬศ่ࠪ᥎"),l11ll1_l1_ (u"ࠫฬ๊ศ้็ࠪ᥏"),l11ll1_l1_ (u"๋ࠬำาฯํอࠬᥐ")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧᥑ"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᥒ"),title,re.DOTALL)
		if not l1ll1l1_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᥓ"),l111l1_l1_+title,l1lllll_l1_,492,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠩะ่็ฯࠧᥔ") in title:
			title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᥕ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥖ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥗ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᥘ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᥙ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠨษ็ูๆำษࠡࠩᥚ"),l11ll1_l1_ (u"ࠩࠪᥛ"))
			if title!=l11ll1_l1_ (u"ࠪࠫᥜ"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥝ"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫᥞ")+title,l1lllll_l1_,491)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᥟ"),url,l11ll1_l1_ (u"ࠧࠨᥠ"),l11ll1_l1_ (u"ࠨࠩᥡ"),l11ll1_l1_ (u"ࠩࠪᥢ"),l11ll1_l1_ (u"ࠪࠫᥣ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᥤ"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡂࡶࡶࡷࡳࡳࡹࡂࡢࡴࡆࡳࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᥥ"),html,re.DOTALL)
	if l111lll_l1_:
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᥦ"),l111lll_l1_,l11ll1_l1_ (u"ࠧࠨᥧ"),l11ll1_l1_ (u"ࠨࠩᥨ"),l11ll1_l1_ (u"ࠩࠪᥩ"),l11ll1_l1_ (u"ࠪࠫᥪ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᥫ"))
		html = response.content
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᥬ"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᥭ"))
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᥮"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ᥯"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᥰ") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᥱ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥲ"),l111l1_l1_+title,l1lllll_l1_,493,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩࡡࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡤࡲࡼࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᥳ"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1lll1_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨᥴ"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᥵"),l111l1_l1_+title,l1lllll_l1_,492,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᥶"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᥷"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l11ll1_l1_ (u"ࠪห้฻แฮหࠣࠫ᥸"),l11ll1_l1_ (u"ࠫࠬ᥹"))
				if title!=l11ll1_l1_ (u"ࠬ࠭᥺"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᥻"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭᥼")+title,l1lllll_l1_,491)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ᥽"))+l11ll1_l1_ (u"ࠩ࠲ࡃࡻ࡯ࡥࡸ࠿࠴ࠫ᥾")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ᥿"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬᦀ"),l11ll1_l1_ (u"ࠬ࠭ᦁ"),l11ll1_l1_ (u"࠭ࠧᦂ"),l11ll1_l1_ (u"ࠧࠨᦃ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᦄ"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭ᦅ"))
	l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠥࡨࡦࡺࡡ࠻ࠢࠪࡵࡂ࠮࠮ࠫࡁࠬࠪࠧᦆ"),html,re.DOTALL)
	#if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡ࠮ࡴࡩ࡫ࡶࡠ࠳࡯ࡤ࡝࠮࠳ࡠ࠱࠮࠮ࠫࡁࠬࡠ࠮࠭ᦇ"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᦈ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩᦉ"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩᦊ"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵࡯࡭ࡦ࠲ࡷࡪࡸࡶࡦࡴࡶ࠳ࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡳࡀࠫᦋ")+l1ll1llll1_l1_+l11ll1_l1_ (u"ࠩࠩ࡭ࡂ࠭ᦌ")+l1lll111l1_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᦍ")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᦎ")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l11l1l1ll_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡘ࡫ࡲࡷࡧࡵࠦ࠳࠰࠿ࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᦏ"),html,re.DOTALL)
	if l1lllll_l1_:
		title = l11ll1_l1_ (u"࠭ๅโุ็ࠫᦐ")
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࠪᦑ")+title
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	#l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠨ࠱ࠪᦒ"))+l11ll1_l1_ (u"ࠩ࠲ࡃࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠱ࠨᦓ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᦔ"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬᦕ"),l11ll1_l1_ (u"ࠬ࠭ᦖ"),l11ll1_l1_ (u"࠭ࠧᦗ"),l11ll1_l1_ (u"ࠧࠨᦘ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᦙ"))
	#html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᦚ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᦛ"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᦜ"))
			if l11ll1_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭ᦝ") in l1lllll_l1_: l1lll1l1l_l1_ = l11ll1_l1_ (u"࠭࡟ࡠะสูࠬᦞ")
			else: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠧࠨᦟ")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᦠ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᦡ")+l1lll1l1l_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᦢ"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᦣ"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"ࠬ࠭ᦤ")):
	if not l1ll111_l1_: l1ll111_l1_ = l11l1l_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨᦥ"),l11ll1_l1_ (u"ࠧࠬࠩᦦ"))
	url = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠯ࡲ࡫ࡴࡄࡹ࠽ࠨᦧ")+search
	l11111_l1_(url)
	return
#   search is l11l1llll_l1_ l11lll1l1_l1_ in l11111_l1_()
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/?s=the+l1ll1lll11_l1_
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/search/the+l1ll1lll11_l1_/
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
#	https://l1lll11111_l1_-l1lll1111l_l1_.io/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭䵚")
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䵛"):l11ll1_l1_ (u"ࠨࠩ䵜")}
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡑࡈࡓ࡟ࠨ䵝")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ䵞"),l11ll1_l1_ (u"ࠫࡼࡽࡥࠨ䵟")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11111_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llll1l_l1_(url,text)
	elif mode==364: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ䵠")+text)
	elif mode==365: results = l1lll111_l1_(url,l11ll1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ䵡")+text)
	elif mode==366: results = l1l111_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䵢"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ䵣"),l11ll1_l1_ (u"ࠩࠪ䵤"),False,l11ll1_l1_ (u"ࠪࠫ䵥"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䵦"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䵧")]
	#hostname = hostname.strip(l11ll1_l1_ (u"࠭࠯ࠨ䵨"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䵩")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䵪"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䵫"),l11ll1_l1_ (u"ࠪࠫ䵬"),l11ll1_l1_ (u"ࠫࠬ䵭"),l11ll1_l1_ (u"ࠬ࠭䵮"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䵯"))
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䵰"),l111l1_l1_+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋ีอࠠศๆ่์็฿ࠠๆ฼็ๆࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䵱"),l11ll1_l1_ (u"ࠩࠪ䵲"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䵳"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䵴"),l11ll1_l1_ (u"ࠬ࠭䵵"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䵶"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䵷"),l11l1l_l1_,369,l11ll1_l1_ (u"ࠨࠩ䵸"),l11ll1_l1_ (u"ࠩࠪ䵹"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䵺"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵻"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ䵼"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䵽"),364)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䵾"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䵿"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䶀"),365)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䶁"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䶂"),l11ll1_l1_ (u"ࠬ࠭䶃"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䶄"):hostname,l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䶅"):l11ll1_l1_ (u"ࠨࠩ䶆")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠩ࡟࠳ࠬ䶇"),l11ll1_l1_ (u"ࠪ࠳ࠬ䶈"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࡥࡥࡷ࠮࠮ࠫࡁࠬࡪ࡮ࡲࡴࡦࡴࠪ䶉"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶊"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"࠭ࠥࡥ࠻ࠨ࠼࠺ࠫࡤ࠹ࠧࡥ࠹ࠪࡪ࠸ࠦࡣ࠺ࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡢ࠺ࠧࡧ࠼ࠪࡧ࠹࠮ࠧࡧ࠼ࠪࡧࡤࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡥ࠾࠭䶋") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶌"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䶍")+l111l1_l1_+title,l1lllll_l1_,366)
	#	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䶎"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䶏"),l11ll1_l1_ (u"ࠫࠬ䶐"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䶑"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ䶒"),l11ll1_l1_ (u"ࠧࠨ䶓"),l11ll1_l1_ (u"ࠨࠩ䶔"),l11ll1_l1_ (u"ࠩࠪ䶕"),l11ll1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ䶖"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡳࡍ࡫ࡶࡸࡇࡻࡴࡵࡱࡱࠦࠬ䶗"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䶘"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ䶙") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ䶚"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠨࠩ䶛"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶜"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䶝")+l111l1_l1_+title,l1lllll_l1_,366)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䶞"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䶟"),l11ll1_l1_ (u"࠭ࠧ䶠"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠮࠮ࠫࡁࠬ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠩ䶡"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䶢"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶣"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䶤")+l111l1_l1_+title,l1lllll_l1_,366,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䶥"),l11ll1_l1_ (u"ࠬ࠭䶦"),url,l11ll1_l1_ (u"࠭ࠧ䶧"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䶨"):url,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䶩"):l11ll1_l1_ (u"ࠩࠪ䶪")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䶫"),url,l11ll1_l1_ (u"ࠫࠬ䶬"),l11ll1_l1_ (u"ࠬ࠭䶭"),l11ll1_l1_ (u"࠭ࠧ䶮"),l11ll1_l1_ (u"ࠧࠨ䶯"),l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䶰"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶱"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭䶲"),url,364)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶳"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ䶴"),url,365)
	if l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠭䶵") in html:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶶"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็้๊๐าสࠩ䶷"),url,361,l11ll1_l1_ (u"ࠩࠪ䶸"),l11ll1_l1_ (u"ࠪࠫ䶹"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䶺"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭䶻"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䶼"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶽"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l11111_l1_(l1ll1l1l111l_l1_,type=l11ll1_l1_ (u"ࠨࠩ䶾")):
	if l11ll1_l1_ (u"ࠩ࠽࠾ࠬ䶿") in l1ll1l1l111l_l1_:
		l11l111_l1_,url = l1ll1l1l111l_l1_.split(l11ll1_l1_ (u"ࠪ࠾࠿࠭䷀"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䷁"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l111l_l1_,l1ll1l1l111l_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䷂"):l11l111_l1_,l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䷃"):l11ll1_l1_ (u"ࠧࠨ䷄")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䷅"),url,l11ll1_l1_ (u"ࠩࠪ䷆"),l11ll1_l1_ (u"ࠪࠫ䷇"),l11ll1_l1_ (u"ࠫࠬ䷈"),l11ll1_l1_ (u"ࠬ࠭䷉"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䷊"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䷋"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ䷌"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䷍"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠪࡠࡡ࠵ࠧ䷎"),l11ll1_l1_ (u"ࠫ࠴࠭䷏")).replace(l11ll1_l1_ (u"ࠬࡢ࡜ࠣࠩ䷐"),l11ll1_l1_ (u"࠭ࠢࠨ䷑"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡈࡴ࡬ࡨ࠲࠳ࡍࡺࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ䷒"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ䷓"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ุ่ࠩฬํฯสࠢࠪ䷔"),l11ll1_l1_ (u"ࠪࠫ䷕"))
			if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䷖") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷗"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			elif l11ll1_l1_ (u"࠭อๅไฬࠫ䷘") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ䷙"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䷚") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䷛"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䷜"),l111l1_l1_+title,l1lllll_l1_,362,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䷝"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ䷞"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ䷟")+count
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䷠"),l111l1_l1_+l11ll1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ䷡"),l1lllll_l1_,361,l11ll1_l1_ (u"ࠩࠪ䷢"),l11ll1_l1_ (u"ࠪࠫ䷣"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䷤"))
		elif type==l11ll1_l1_ (u"ࠬ࠭䷥"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䷦"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䷧"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ࠨืไัฮࠦࠧ䷨")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䷩"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"ࠪࠫ䷪")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䷫"),url,l11ll1_l1_ (u"ࠬ࠭䷬"),l11ll1_l1_ (u"࠭ࠧ䷭"),l11ll1_l1_ (u"ࠧࠨ䷮"),l11ll1_l1_ (u"ࠨࠩ䷯"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䷰"))
	html = response.content
	html = l1111_l1_(html)
	name = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡩࡵࡧࡰࠦࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠪ࠱࠮ࡄ࠯ࠢࠨ䷱"),html,re.DOTALL)
	if name: name = name[-1].replace(l11ll1_l1_ (u"ࠫ࠲࠭䷲"),l11ll1_l1_ (u"ࠬࠦࠧ䷳")).strip(l11ll1_l1_ (u"࠭࠯ࠨ䷴"))
	if l11ll1_l1_ (u"ࠧๆ๊ึ้ࠬ䷵") in name and type==l11ll1_l1_ (u"ࠨࠩ䷶"):
		name = name.split(l11ll1_l1_ (u"่ࠩ์ุ๋ࠧ䷷"))[0]
		name = name.replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ䷸"),l11ll1_l1_ (u"ࠫࠬ䷹")).strip(l11ll1_l1_ (u"ࠬࠦࠧ䷺"))
	elif l11ll1_l1_ (u"࠭อๅไฬࠫ䷻") in name:
		name = name.split(l11ll1_l1_ (u"ࠧฮๆๅอࠬ䷼"))[0]
		name = name.replace(l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ䷽"),l11ll1_l1_ (u"ࠩࠪ䷾")).strip(l11ll1_l1_ (u"ࠪࠤࠬ䷿"))
	else: name = name
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵ࡬ࡲ࡬ࡲࡥࡴࡧࡦࡸ࡮ࡵ࡮ࠨ一"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if type==l11ll1_l1_ (u"ࠬ࠭丁"):
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ丂"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭七") in title: continue
				if l11ll1_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩ丄") in title: continue
				title = name+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭丅")+title
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丆"),l111l1_l1_+title,l1lllll_l1_,363,l11ll1_l1_ (u"ࠫࠬ万"),l11ll1_l1_ (u"ࠬ࠭丈"),l11ll1_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ三"))
		if len(menuItemsLIST)==0:
			l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠬࠦࠨ上"),block+l11ll1_l1_ (u"ࠨࠨࠩࠫ下"),re.DOTALL)
			if l111l_l1_: block = l111l_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ丌"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ不"))
				title = name+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ与")+title
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ丏"),l111l1_l1_+title,l1lllll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11ll1_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭丐"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠧࠡ࠯้ࠣฬ๐ࠠิ์่หࠬ丑"),l11ll1_l1_ (u"ࠨࠩ丒")).replace(l11ll1_l1_ (u"ุ่ࠩฬํฯสࠢࠪ专"),l11ll1_l1_ (u"ࠪࠫ且"))
		else: title = l11ll1_l1_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ丕")
		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ世"),l111l1_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ丗"),url,l11ll1_l1_ (u"ࠧࠨ丘"),l11ll1_l1_ (u"ࠨࠩ丙"),l11ll1_l1_ (u"ࠩࠪ业"),l11ll1_l1_ (u"ࠪࠫ丛"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭东"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂฬ๊สึ่ํๅࡁ࠴ࠪࡀ࠾ࡤ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ丝"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡋ࡭ࡣࡧࡧࠦࠬ丞"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ丟"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭丠") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡ็ส๎ู๊ࠥๆษࠪ両"): name = l11ll1_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ丢")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ丣")+name+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭两")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ严"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ並"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭丧") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ丨"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ丩")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠫࠬ个")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡳࡹࡤ࡫ࡰࡥࠬ丫")+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ丬")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ中"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ丮"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠩࠪ丯")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠪࠫ丰"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠫࠬ丱"): return
	search = search.replace(l11ll1_l1_ (u"ࠬࠦࠧ串"),l11ll1_l1_ (u"࠭ࠫࠨ丳"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭临"),l11ll1_l1_ (u"ࠨ࠱ࠪ丵"),l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡵࡨࡶ࡮࡫ࡳࠨ丶"),l11ll1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡤࡲ࡮ࡳࡥࠨ丷"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡸࡻ࠭丸")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"ࠬอไไๆࠪ丹"),l11ll1_l1_ (u"࠭วๅลไ่ฬ๋ࠧ为"),l11ll1_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ主"),l11ll1_l1_ (u"ࠨษ็ห๋๐ๅ๋๋ࠢࠤฬ๊ใาฬ๋๊ࠬ丼"),l11ll1_l1_ (u"ࠩส่อืวๆฮࠣฮ้๐แำ์๋๊๏ฯࠧ丽")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪหำะัࠡษ็๊ํ฿ࠠศๆ่฻้๎ศ࠻ࠩ举"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11ll1_l1_ (u"ࠫࠬ丿"):
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ乀"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧ乁"),l11ll1_l1_ (u"ࠧࠨ乂"),False,l11ll1_l1_ (u"ࠨࠩ乃"),l11ll1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭乄"))
		hostname = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ久")]
		hostname = hostname.strip(l11ll1_l1_ (u"ࠫ࠴࠭乆"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ乇")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l111l_l1_,filter):
	if l11ll1_l1_ (u"࠭࠿ࡀࠩ么") in l1ll1l1l111l_l1_: url = l1ll1l1l111l_l1_.split(l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭义"))[0]
	else: url = l1ll1l1l111l_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ乊"):l1ll1l1l111l_l1_,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭之"):l11ll1_l1_ (u"ࠪࠫ乌")}
	filter = filter.replace(l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭乍"),l11ll1_l1_ (u"ࠬ࠭乎"))
	type,filter = filter.split(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ乏"),1)
	if filter==l11ll1_l1_ (u"ࠧࠨ乐"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠨࠩ乑"),l11ll1_l1_ (u"ࠩࠪ乒")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ乓"))
	if type==l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ乔"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ乕") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"࠭࠽࠾ࠩ乖") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ乗")+category+l11ll1_l1_ (u"ࠨ࠿ࡀ࠴ࠬ乘")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ乙")+category+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ乚")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠫࠫࠬࠧ乛"))+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ乜")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠧࠩ九"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ乞"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ也")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ习"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ乡"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠫࠬ乢"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ乣"))
		if l1l111l1_l1_==l11ll1_l1_ (u"࠭ࠧ乤"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭乥")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l111l_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ书"),l111l1_l1_+l11ll1_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ乧"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠪࠫ乨"),l11ll1_l1_ (u"ࠫࠬ乩"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭乪"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭乫"),l111l1_l1_+l11ll1_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ乬")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ乭"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠩࠪ乮"),l11ll1_l1_ (u"ࠪࠫ乯"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ买"))
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ乱"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭乲"),l11ll1_l1_ (u"ࠧࠨ乳"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ乴"),url,l11ll1_l1_ (u"ࠩࠪ乵"),l11ll1_l1_ (u"ࠪࠫ乶"),l11ll1_l1_ (u"ࠫࠬ乷"),l11ll1_l1_ (u"ࠬ࠭乸"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ乹"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠥࠫ乺"),l11ll1_l1_ (u"ࠨࠤࠪ乻")).replace(l11ll1_l1_ (u"ࠩ࡟ࡠ࠴࠭乼"),l11ll1_l1_ (u"ࠪ࠳ࠬ乽"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡳࡹࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ乾"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ乿"),block+l11ll1_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ亀"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ亁") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ亂"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠩࡀࡁࠬ亃") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ亄"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ亅")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l111l_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ了"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾࠭亇"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠧࠨ予"),l11ll1_l1_ (u"ࠨࠩ争"),l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ亊"))
				else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ事"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ二"),l111lll_l1_,364,l11ll1_l1_ (u"ࠬ࠭亍"),l11ll1_l1_ (u"࠭ࠧ于"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ亏"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ亐")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠩࡀࡁ࠵࠭云")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭互")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ亓")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ五")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭井"),l111l1_l1_+name+l11ll1_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ亖"),l111lll_l1_,365,l11ll1_l1_ (u"ࠨࠩ亗"),l11ll1_l1_ (u"ࠩࠪ亘"),l1l11lll_l1_+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ亙"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"ࠫࡷ࠭亚") or value==l11ll1_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ些"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ亜") in option: continue
			if l11ll1_l1_ (u"ࠧศๆๆ่ࠬ亝") in option: continue
			if l11ll1_l1_ (u"ࠨࡰ࠰ࡥࠬ亞") in value: continue
			#if value in [l11ll1_l1_ (u"ࠩࡵࠫ亟"),l11ll1_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ亠"),l11ll1_l1_ (u"ࠫࡹࡼ࠭࡮ࡣࠪ亡")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ亢"): option = value
			if option==l11ll1_l1_ (u"࠭ࠧ亣"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ交"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l1l1_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠨ࠼ࠣࠫ亥")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ亦")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࡂ࠭产")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ亨")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ亩")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ亪")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ享"):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ京"),l111l1_l1_+l1lll1l1l_l1_,url,365,l11ll1_l1_ (u"ࠩࠪ亭"),l11ll1_l1_ (u"ࠪࠫ亮"),l1ll1l11_l1_+l11ll1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭亯"))
			elif type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ亰") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"࠭࠽࠾ࠩ亱") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ亲"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ亳"),l11ll1_l1_ (u"ࠩࠪ亴"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ亵")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亶"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,361,l11ll1_l1_ (u"ࠬ࠭亷"),l11ll1_l1_ (u"࠭ࠧ亸"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ亹"))
			else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ人"),l111l1_l1_+l1lll1l1l_l1_,url,364,l11ll1_l1_ (u"ࠩࠪ亻"),l11ll1_l1_ (u"ࠪࠫ亼"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ亽"),l11ll1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ亾"),l11ll1_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭亿")]
l1l111111_l1_ = [l11ll1_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ什"),l11ll1_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ仁"),l11ll1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ仂"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ仃"),l11ll1_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ仄"),l11ll1_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ仅"),l11ll1_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭仆"),l11ll1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ仇")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ仈") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ仉"),l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ今"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ介"),l11ll1_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ仌"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠽࠾ࠩ仍"),l11ll1_l1_ (u"ࠧ࠰ࠩ从"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨࠨࠩࠫ仏"),l11ll1_l1_ (u"ࠩ࠲ࠫ仐"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ仑"),l11ll1_l1_ (u"ࠫࠬ仒"),filters,l11ll1_l1_ (u"ࠬࡏࡎࠡࠢࠣࠤࠬ仓")+mode)
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ仔")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ仕")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ他")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠩࠩࠪࠬ仗"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠪࠫ付")
	if l11ll1_l1_ (u"ࠫࡂࡃࠧ仙") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠬࠬࠦࠨ仚"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"࠭࠽࠾ࠩ仛"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠧ࠱ࠩ仜")
		if l11ll1_l1_ (u"ࠨࠧࠪ仝") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ仞") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬ仟"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨ仠")+value
		elif mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ仡") and value!=l11ll1_l1_ (u"࠭࠰ࠨ仢"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࠧࠨࠪ代")+key+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ令")+value
		elif mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭以"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭仦")+key+l11ll1_l1_ (u"ࠫࡂࡃࠧ仧")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ仨"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠧࠩ仩"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ仪"),l11ll1_l1_ (u"ࠨࠩ仫"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠩࡒ࡙࡙࠭们"))
	return l1ll11ll_l1_
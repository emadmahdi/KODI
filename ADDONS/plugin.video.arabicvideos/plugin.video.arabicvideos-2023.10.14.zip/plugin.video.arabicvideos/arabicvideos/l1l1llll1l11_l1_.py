# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ䳅")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍ࠵ࡗࡢࠫ䳆")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭ว็๊ส฽ࠥอแๅษ่ࠫ䳇"),l11ll1_l1_ (u"ࠧอ๊าหฯࠦวโๆส้ࠬ䳈")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11111_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llll1l_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䳉"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䳊"),l11ll1_l1_ (u"ࠪࠫ䳋"),389,l11ll1_l1_ (u"ࠫࠬ䳌"),l11ll1_l1_ (u"ࠬ࠭䳍"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䳎"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䳏"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䳐"),l11ll1_l1_ (u"ࠩࠪ䳑"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳒"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䳓")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭䳔"),l11l1l_l1_,381,l11ll1_l1_ (u"࠭ࠧ䳕"),l11ll1_l1_ (u"ࠧࠨ䳖"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䳗"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳘"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䳙")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬศ่ห๎ฮ࠭䳚"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠬ࠭䳛"),l11ll1_l1_ (u"࠭ࠧ䳜"),l11ll1_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭䳝"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䳞"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ䳟"),l11ll1_l1_ (u"ࠪࠫ䳠"),l11ll1_l1_ (u"ࠫࠬ䳡"),l11ll1_l1_ (u"ࠬ࠭䳢"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䳣"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䳤"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䳥"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䳦")+l111l1_l1_+title,l11l1l_l1_,381,l11ll1_l1_ (u"ࠪࠫ䳧"),l11ll1_l1_ (u"ࠫࠬ䳨"),l11ll1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䳩")+str(seq))
	block = l11ll1_l1_ (u"࠭ࠧ䳪")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡥࡥࡱࡵࠦࠬ䳫"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡡࡴ࡫ࡧࡩࠬ䳬"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䳭"),block,re.DOTALL)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䳮"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䳯"),l11ll1_l1_ (u"ࠬ࠭䳰"),9999)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"࠭วๅล฼่๎ࠦๅีษ๊ำฮ࠭䳱"):
			if first:
				title = l11ll1_l1_ (u"ࠧศๆสๅ้อๅࠡࠩ䳲")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤࠬ䳳")+title
		if title not in l1l11l_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳴"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䳵")+l111l1_l1_+title,l1lllll_l1_,381)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䳶"),l11ll1_l1_ (u"ࠬ࠭䳷"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ䳸"),url,l11ll1_l1_ (u"ࠧࠨ䳹"),l11ll1_l1_ (u"ࠨࠩ䳺"),l11ll1_l1_ (u"ࠩࠪ䳻"),l11ll1_l1_ (u"ࠪࠫ䳼"),l11ll1_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䳽"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ䳾"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䳿"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴀"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ䴁"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭䴂"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		z = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ䴃"),block,re.DOTALL)
		l1llll_l1_,l1l1111l1_l1_,l1lll11l_l1_ = zip(*z)
		items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	elif type==l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䴄"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ䴅"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䴆"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ䴇") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ䴈"),l11ll1_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ䴉"))
		html = html.replace(l11ll1_l1_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䴊"),l11ll1_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䴋"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ䴌"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==2: items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴍"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭䴎"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ䴏") in url:
				items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䴐"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭䴑") in url:
				items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴒"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䴓"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࠬ䴔") in title:
			title = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡪࡸࡩࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴕"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬ䴖")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䴗")+title
		l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿ࠫ䴘"),title,re.DOTALL)
		if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ䴙") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴚"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䴛") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴜"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ䴝") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䴞"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ䴟") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䴠"),l111l1_l1_+title,l1lllll_l1_,381,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䴡"),l111l1_l1_+title,l1lllll_l1_,382,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࡐࡢࡩࡨࠤ࠭࠴ࠪࡀࠫࠣࡳ࡫ࠦࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䴢"),html,re.DOTALL)
	if l1l1l11_l1_:
		current = l1l1l11_l1_[0][0]
		last = l1l1l11_l1_[0][1]
		block = l1l1l11_l1_[0][2]
		items = re.findall(l11ll1_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ䴣"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title==l11ll1_l1_ (u"ࠨࠩ䴤") or title==last: continue
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䴥"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䴦")+title,l1lllll_l1_,381,l11ll1_l1_ (u"ࠫࠬ䴧"),l11ll1_l1_ (u"ࠬ࠭䴨"),type)
		#if title==last:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭䴩")+title+l11ll1_l1_ (u"ࠧ࠰ࠩ䴪"),l11ll1_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䴫")+last+l11ll1_l1_ (u"ࠩ࠲ࠫ䴬"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䴭"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬิัࠡืไัฮࠦࠧ䴮")+last,l1lllll_l1_,381,l11ll1_l1_ (u"ࠬ࠭䴯"),l11ll1_l1_ (u"࠭ࠧ䴰"),type)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䴱"),url,l11ll1_l1_ (u"ࠨࠩ䴲"),l11ll1_l1_ (u"ࠩࠪ䴳"),l11ll1_l1_ (u"ࠪࠫ䴴"),l11ll1_l1_ (u"ࠫࠬ䴵"),l11ll1_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䴶"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䴷"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,False):
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䴸"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ุ้๊ำๅࠢ็่่ฮวา๋ࠢห้๋ศา็ฯࠤ๊์ู่ࠩ䴹"),l11ll1_l1_ (u"ࠩࠪ䴺"),9999)
		return
	if l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䴻") in url or l11ll1_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ䴼") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡪࡶࡨࡱࠬࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ䴽"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[1]
			l1llll1l_l1_(l111lll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨࡧࡳ࡭ࡸࡵࡤࡪࡱࡶࠫ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡢࡵࡷࠦࠬ࠭ࠧ䴾"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡱࡹࡲ࡫ࡲࡢࡰࡧࡳࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ䴿"),block,re.DOTALL)
		for l1lll1_l1_,l1ll1l1_l1_,l1lllll_l1_,name in items:
			title = l1ll1l1_l1_+l11ll1_l1_ (u"ࠨࠢ࠽ࠤࠬ䵀")+name+l11ll1_l1_ (u"ࠩࠣห้ำไใหࠪ䵁")
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䵂"),l111l1_l1_+title,l1lllll_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ䵃"),url,l11ll1_l1_ (u"ࠬ࠭䵄"),l11ll1_l1_ (u"࠭ࠧ䵅"),l11ll1_l1_ (u"ࠧࠨ䵆"),l11ll1_l1_ (u"ࠨࠩ䵇"),l11ll1_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䵈"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䵉"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠧࠨࡩࡥ࠿ࠪࡴࡱࡧࡹࡦࡴ࠰ࡳࡵࡺࡩࡰࡰ࠰࠵ࠬ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠫࠦࡸ࡮ࡥࡢࡦࡨࡶࠧࢂࠧࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ࠩࠣࠤࠥ䵊"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡷࡪࡸࡶࡦࡴࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ䵋"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䵌")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ䵍")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬࠮ࡥ࡯ࡳࡸ࡫ࠢࠨ䵎"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡢࡣࡤࡪ࡬ࡠࡩࡧࡶ࡮ࡼࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䵏"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䵐")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䵑")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䵒"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䵓"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ䵔"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ䵕"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ䵖"),l11ll1_l1_ (u"ࠪ࠯ࠬ䵗"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ䵘")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ䵙"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭塃")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭塄")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ塅"),l1l111_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ塆"),l1l111_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭塇")]
def l11l1ll_l1_(mode,url,text):
	if   mode==640: l1lll_l1_ = l1l1l11_l1_()
	elif mode==641: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==642: l1lll_l1_ = PLAY(url)
	elif mode==643: l1lll_l1_ = l11l1l11ll11_l1_(url,text)
	elif mode==644: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==645: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==649: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ塈"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭塉"),l1l111_l1_ (u"࠭ࠧ塊"),l1l111_l1_ (u"ࠧࠨ塋"),l1l111_l1_ (u"ࠨࠩ塌"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ塍"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塎"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ塏"),l1l111_l1_ (u"ࠬ࠭塐"),649,l1l111_l1_ (u"࠭ࠧ塑"),l1l111_l1_ (u"ࠧࠨ塒"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ塓"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ塔"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ塕"),l1l111_l1_ (u"ࠫࠬ塖"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ塗"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ塘"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠧࠨ塙"))
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭塚"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ塛"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ塜")+l1lllll_l1_+title,l1ll1ll_l1_,644)
	return
def l11ll1_l1_(url):
	l11ll111l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ塝"),url,l1l111_l1_ (u"ࠬ࠭塞"),l1l111_l1_ (u"࠭ࠧ塟"),l1l111_l1_ (u"ࠧࠨ塠"),l1l111_l1_ (u"ࠨࠩ塡"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ塢"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ塣"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ塤"),l1l111_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ塥"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ塦"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠧࠨ塧"),block)]
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭塨"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ塩"),l1l111_l1_ (u"ࠪࠫ塪"),9999)
		for l11111_l1_,block in l11llll_l1_:
			l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ填"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠬࡀࠠࠨ塬")
			for l1ll1ll_l1_,title in l11ll111l_l1_:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭塭"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ塮"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ塯"),block,re.DOTALL)
		if len(l1l1111_l1_)<30:
			if l11ll111l_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ塰"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ塱"),l1l111_l1_ (u"ࠫࠬ塲"),9999)
			for l1ll1ll_l1_,title in l1l1111_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ塳"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧ塴")):
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ塵"):
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࠪ塶"),1)
		data = l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ塷")+search
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ塸"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ塹")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ塺"),url,data,headers,l1l111_l1_ (u"࠭ࠧ塻"),l1l111_l1_ (u"ࠧࠨ塼"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ塽"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭塾"),url,l1l111_l1_ (u"ࠪࠫ塿"),l1l111_l1_ (u"ࠫࠬ墀"),l1l111_l1_ (u"ࠬ࠭墁"),l1l111_l1_ (u"࠭ࠧ墂"),l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ境"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠨࠩ墄"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭墅"))
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ墆"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭墇"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭墈"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ墉"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ墊"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ墋"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ墌"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ墍"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ墎"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ墏"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ墐"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ墑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩ墒"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ墓"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ墔"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ墕"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ墖"),l1l111_l1_ (u"࠭ว฻่ํอࠬ増"),l1l111_l1_ (u"ࠧไๆํฬࠬ墘"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ墙"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ墚"),l1l111_l1_ (u"้ࠪออัศหࠪ墛"),l1l111_l1_ (u"ࠫ฾ืึࠨ墜"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ墝"),l1l111_l1_ (u"࠭วๅส๋้ࠬ增"),l1l111_l1_ (u"ࠧๆีิั๏ฯࠧ墟")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ墠"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ墡"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ墢"):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ墣"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ墤") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭墥"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墦"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ墧"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ墨"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ墩"): continue
				if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ墪") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ墫")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ墬"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墭"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ墮")+title,l1ll1ll_l1_,641)
	return
def l11l1l11ll11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭墯"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ墰"),url,l1l111_l1_ (u"ࠫࠬ墱"),l1l111_l1_ (u"ࠬ࠭墲"),l1l111_l1_ (u"࠭ࠧ墳"),l1l111_l1_ (u"ࠧࠨ墴"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ墵"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ墶"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ墷"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ墸")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ墹"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"࠭ࠣࠨ墺"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墻"),l1lllll_l1_+title,url,645,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ墼"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ墽")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ墾"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭墿"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ壀") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ壁")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ壂"))
			title = title.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿࠾ࡨࡱࡃ࠭壃"),l1l111_l1_ (u"ࠩࠣࠫ壄"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ壅"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ壆"),url,l1l111_l1_ (u"ࠬ࠭壇"),l1l111_l1_ (u"࠭ࠧ壈"),l1l111_l1_ (u"ࠧࠨ壉"),l1l111_l1_ (u"ࠨࠩ壊"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ壋"))
	html = response.content
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡴ࡭࠺ࡪ࡯ࡤ࡫ࡪࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ壌"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ壍")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡔࡵ࡮ࡤࡨࡶ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ壎"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ壏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ壐"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ壑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀ࠿ࡩࡲࡄࠧ壒"),l1l111_l1_ (u"ࠪࠤࠬ壓"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ壔"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ壕"),url,l1l111_l1_ (u"࠭ࠧ壖"),l1l111_l1_ (u"ࠧࠨ壗"),l1l111_l1_ (u"ࠨࠩ壘"),l1l111_l1_ (u"ࠩࠪ壙"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ壚"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺ࠲ࡱࡵࡣࡢࡶ࡬ࡳࡳ࠴ࡲࡦࡲ࡯ࡥࡨ࡫࡜ࠩࠤࠫ࠲࠯ࡅࠩࠣࠩ壛"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ壜"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ壝"),l1l111_l1_ (u"ࠧࠨ壞"),l1l111_l1_ (u"ࠨࠩ壟"),l1l111_l1_ (u"ࠩࠪ壠"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ壡"))
	html = response.content
	l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ壢"),html,re.DOTALL)
	l11l1l11_l1_ = l11l1l11_l1_[0]
	l1l11ll_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ壣"))
	l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࡤࡨࡲ࡯࡮࠮ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡺ࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ壤")+l11l1l11_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ壥"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ壦"),l1l111_l1_ (u"ࠩࠪ壧"),l1l111_l1_ (u"ࠪࠫ壨"),l1l111_l1_ (u"ࠫࠬ壩"),l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ壪"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ士"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		title = escapeUNICODE(title)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ壬"),l1l111_l1_ (u"ࠨࠩ壭"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ壮")+title+l1l111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ壯"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ声"),url)
	return
def l11l1l11ll1l_l1_(url):
	l1ll11l1_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩ壱"),l1l111_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠳ࡶࡨࡱࠩ売"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ壳"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ壴"),l1l111_l1_ (u"ࠩࠪ壵"),l1l111_l1_ (u"ࠪࠫ壶"),l1l111_l1_ (u"ࠫࠬ壷"),l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ壸"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩࡪࡥࡥ࠯ࡹ࡭ࡩ࡫࡯ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭壹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ壺"),block,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_ = l1ll_l1_[0]
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ壻"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ壼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪ壽"),block,re.DOTALL)
		block = block.replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ壾"),l1l111_l1_ (u"ࠬࠨࠧ壿")).replace(l1l111_l1_ (u"࠭࡜࠰ࠩ夀"),l1l111_l1_ (u"ࠧ࠰ࠩ夁"))
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࠿࡭࡫ࡸࡡ࡮ࡧ࠱ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ夂"),block,re.DOTALL)
		if len(l11l1l1l1_l1_)==len(l1ll_l1_):
			for id,title in l11l1l1l1_l1_:
				l1ll1ll_l1_ = l1ll_l1_[int(id)]
				if l1ll1ll_l1_ not in l1llll_l1_:
					l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ夃")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ处"))
					l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡓࡦࡴࡹࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ夅"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭夆"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ备")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ夈"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ変"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ夊"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ夋"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭夌"),l1l111_l1_ (u"ࠬ࠱ࠧ复"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ夎")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ夏"))
	return
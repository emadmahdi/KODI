# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ⸦")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬ⸧")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll1ll1111_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll1ll111l_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll1l11l1l_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll1ll11ll_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll1ll111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸨"),l1lllll_l1_+l1l111_l1_ (u"ࠨ฻ิฬ๏࠭⸩"),l111l1_l1_,21,l1l111_l1_ (u"ࠩࠪ⸪"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⸫"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸬"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡋ࡮ࡨ࡮࡬ࡷ࡭࠭⸭"),l1l1l1l1l1_l1_,21,l1l111_l1_ (u"࠭ࠧ⸮"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫⸯ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸰"),l1lllll_l1_+l1l111_l1_ (u"ࠩไหึู้ࠨ⸱"),l1ll1l1lll1_l1_,21,l1l111_l1_ (u"ࠪࠫ⸲"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⸳"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸴"),l1lllll_l1_+l1l111_l1_ (u"࠭แศำึํࠥ࠸ࠧ⸵"),l1ll1ll1111_l1_,21,l1l111_l1_ (u"ࠧࠨ⸶"),l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⸷"))
	return
def l1ll1ll11ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⸸"),l1lllll_l1_+l1l111_l1_ (u"ࠪ฽ึฮ๊ࠨ⸹"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⸺"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡋ࡮ࡨ࡮࡬ࡷ࡭࠭⸻"),l1l1l1l1l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ⸼"),l1lllll_l1_+l1l111_l1_ (u"ࠧโษิื๎࠭⸽"),l1ll1l1lll1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⸾"),l1lllll_l1_+l1l111_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ⸿"),l1ll1ll1111_l1_,27)
	return
def l1l1l11_l1_(l1ll1ll1l11_l1_):
	l1ll1_l1_ = l1ll1ll1l11_l1_
	if l1ll1ll1l11_l1_==l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⹀"): l1ll1ll1l11_l1_ = l111l1_l1_
	elif l1ll1ll1l11_l1_==l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ⹁"): l1ll1ll1l11_l1_ = l1l1l1l1l1_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠬ࠭⹂")
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(l1ll1ll1l11_l1_)
	if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡡࡳࠩ⹃") or l1ll1_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⹄"):
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⹅")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥำวๅ์ฬࠫ⹆")
		l11111111l_l1_ = l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ࠲ࠦรฮัฮࠫ⹇")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥ࠳ࠠฤสฯำ๏࠭⹈")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠬฮหࠡฯํࠤว๐ࠠโ์็้ࠬ⹉")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"࠭รโๆส้ࠬ⹊")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ⹋")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠨสิห๊าࠧ⹌")
	elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⹍") or l1ll1_l1_==l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⹎"):
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡮ࡴࠠࡴ࡫ࡷࡩࠬ⹏")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡄࡷࡵࡶࡪࡴࡴࠨ⹐")
		l11111111l_l1_ = l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠭ࠡࡎࡤࡸࡪࡹࡴࠨ⹑")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠮ࠢࡄࡰࡵ࡮ࡡࡣࡧࡷࠫ⹒")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠨࡎ࡬ࡺࡪࠦࡩࡇ࡫࡯ࡱࠥࡩࡨࡢࡰࡱࡩࡱ࠭⹓")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠩࡐࡳࡻ࡯ࡥࡴࠩ⹔")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⹕")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠫࡘ࡮࡯ࡸࡵࠪ⹖")
	elif l1lllll11ll_l1_ in [l1l111_l1_ (u"ࠬ࡬ࡡࠨ⹗"),l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⹘")]:
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠧอีอะํࠦฯาࠢึห໑ะࠧ⹙")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢฯหึ໒ࠧ⹚")
		l11111111l_l1_ = l1l111_l1_ (u"ࠩึี๏อไࠡ࠯ࠣฦำื໌็ࠩ⹛")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠪืึ๐วๅࠢ࠰ࠤฬ๊แษษࠪ⹜")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠫ຃ิิࠡิ้ำ์ࠦว๋ࠢไ๎้๋ࠧ⹝")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ⹞")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"࠭ๅ้ีํๆ๎࠭⹟")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠧษำ้ห๊ํ่ࠠษࠪ⹠")
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹡"),l1lllll_l1_+l1ll1l11lll_l1_,l1ll1ll1l11_l1_,29,l1l111_l1_ (u"ࠩࠪ⹢"),l1l111_l1_ (u"ࠪࠫ⹣"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⹤"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⹥"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⹦")+l1lllll_l1_+l1ll1l1l1l1_l1_,l1ll1ll1l11_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⹧"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⹨"),l1l111_l1_ (u"ࠩࠪ⹩"),9999)
	l1llll1llll_l1_ = [l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⹪"),l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⹫"),l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⹬")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll1l11_l1_+l1l111_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬ⹭"),l1l111_l1_ (u"ࠧࠨ⹮"),l1l111_l1_ (u"ࠨࠩ⹯"),l1l111_l1_ (u"ࠩࠪ⹰"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⹱"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡧࡻࡴࡵࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠯ࡄࡱࡱࡸࡦࡩࡴࠨ⹲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⹳"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1llll1llll_l1_):
				url = l1ll1ll1l11_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⹴") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹵"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹶")+l1lllll_l1_+l1ll1l11ll1_l1_,url,22,l1l111_l1_ (u"ࠩࠪ⹷"),l1l111_l1_ (u"ࠪ࠵࠵࠶ࠧ⹸"))
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹹"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⹺")+l1lllll_l1_+l11111111l_l1_,url,22,l1l111_l1_ (u"࠭ࠧ⹻"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⹼"))
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹽"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⹾")+l1lllll_l1_+l1ll1l1l111_l1_,url,22,l1l111_l1_ (u"ࠪࠫ⹿"),l1l111_l1_ (u"ࠫ࠷࠶࠱ࠨ⺀"))
				elif l1l111_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ⺁") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺂"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⺃")+l1lllll_l1_+l1ll1l1l11l_l1_,url,22,l1l111_l1_ (u"ࠨࠩ⺄"),l1l111_l1_ (u"ࠩ࠴࠴࠵࠭⺅"))
				elif l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⺆") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺇"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⺈")+l1lllll_l1_+l1ll1l1ll11_l1_,url,25,l1l111_l1_ (u"࠭ࠧ⺉"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⺊"))
				elif l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⺋") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺌"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⺍")+l1lllll_l1_+l1ll1l1l1ll_l1_,url,22,l1l111_l1_ (u"ࠫࠬ⺎"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⺏"))
	return html
def l1ll1l11l1l_l1_(url):
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ⺐"),l1l111_l1_ (u"ࠧࠨ⺑"),l1l111_l1_ (u"ࠨࠩ⺒"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡏࡘࡗࡎࡉ࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⺓"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤ࠯ࡷࡳࡴࡲࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡓࡵࡴ࡫ࡦ࠱ࡧࡵࡤࡺࠩ⺔"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"ࠫࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ⺕"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺖"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"࠭ࠧ⺗"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⺘"))
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⺙"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺚"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"ࠪࠫ⺛"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⺜"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ⺝"))[-1]
	l1ll1l111l1_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⺞") and l1llllll1_l1_==l1l111_l1_ (u"ࠧ࠱ࠩ⺟"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ⺠"),l1l111_l1_ (u"ࠩࠪ⺡"),l1l111_l1_ (u"ࠪࠫ⺢"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⺣"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫ⺤"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠭࠴ࠪࡀࠫࡁ࠲࠯ࡅࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⺥"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺦"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"ࠨ࠲࠴ࠫ⺧"))
	l1ll1l111ll_l1_=0
	if type==l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⺨"): category=l1l111_l1_ (u"ࠪ࠷ࠬ⺩")
	if type==l1l111_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⺪"): category=l1l111_l1_ (u"ࠬ࠻ࠧ⺫")
	if type==l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⺬"): category=l1l111_l1_ (u"ࠧ࠸ࠩ⺭")
	if type in [l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⺮"),l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⺯"),l1l111_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⺰")] and l1llllll1_l1_!=l1l111_l1_ (u"ࠫ࠵࠭⺱"):
		l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡕࡧࡧࡦ࡫ࡱ࡫ࡎࡺࡥ࡮ࡁࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ⺲")+category+l1l111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⺳")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡲࡶࡩ࡫ࡲࡣࡻࡀࠫ⺴")+l1ll1l111l1_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⺵"),l1l111_l1_ (u"ࠩࠪ⺶"),l1l111_l1_ (u"ࠪࠫ⺷"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⺸"))
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠯ࡄࠨࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⺹"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ⺺"),l1l111_l1_ (u"ࠧࠨ⺻"))
			title = title.replace(l1l111_l1_ (u"ࠨࠤࠪ⺼"),l1l111_l1_ (u"ࠩࠪ⺽"))
			l1ll1l111ll_l1_ += 1
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1l111_l1_ (u"ࠪ࠳ࠬ⺾") + type + l1l111_l1_ (u"ࠫ࠴ࡉ࡯࡯ࡶࡨࡲࡹ࠵ࠧ⺿") + id
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ⻀"): addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⻁"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"ࠧ࠱࠳ࠪ⻂"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⻃"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"ࠩ࠳࠵ࠬ⻄"))
	if type==l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⻅"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡎࡴࡤࡦࡺࡂࡴࡦ࡭ࡥ࠾ࠩ⻆")+l1llllll1_l1_,l1l111_l1_ (u"ࠬ࠭⻇"),l1l111_l1_ (u"࠭ࠧ⻈"),l1l111_l1_ (u"ࠧࠨ⻉"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠴ࡴࡧࠫ⻊"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠳ࡤࡦ࡯ࡲࠬ࠳࠰࠿ࠪࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠲ࡪࡥ࡮ࡱࠪ⻋"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ⻌"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻍"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⻎"))
	if l1ll1l111ll_l1_>20:
		title=l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⻏")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⻐"): title = l1l111_l1_ (u"ࠨࡒࡤ࡫ࡪࠦࠧ⻑")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⻒"): title = l1l111_l1_ (u"ูࠪๆำ็ࠡࠩ⻓")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⻔"): title = l1l111_l1_ (u"ࠬ฻แฮ้ࠣࠫ⻕")
		for l1ll1l1llll_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
				l1ll1l11l11_l1_ = l1l111_l1_ (u"࠭࠰ࠨ⻖")+str(l1ll1l1llll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻗"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,22,l1l111_l1_ (u"ࠨࠩ⻘"),l1ll1l111l1_l1_+l1ll1l11l11_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	l1ll1ll1l1l_l1_ = l1ll1l1ll1l_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ⻙"))
	id,type = parts[-1],parts[3]
	l1ll1l111l1_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll1l111ll_l1_ = 0
	if type==l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⻚"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ⻛"),l1l111_l1_ (u"ࠬ࠭⻜"),l1l111_l1_ (u"࠭ࠧ⻝"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⻞"))
		items = re.findall(l1l111_l1_ (u"ࠨࡅࡲࡱࡲ࡫࡮ࡵࡡࡳࡥࡳ࡫࡬ࡠࡋࡷࡩࡲ࠴ࠪࡀࡲࡁࠬ࠳࠰࠿ࠪ࠾࡬࠲࠰ࡅࡶࡢࡴࠣ࡭ࡳࡺࡥࡳࡡࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫ࡟ࠫࠬ⻟"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭⻠")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⻡"): title = l1l111_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ⻢")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⻣"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⻤")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⻥"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⻦")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⻧"): l1ll1ll11l1_l1_ = l1l111_l1_ (u"ࠪࠫ⻨")
		else: l1ll1ll11l1_l1_ = l1lllll11ll_l1_
		l1ll1lll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩ࡫࡯࠾ࠤࠫ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࡡࠬࠬ࠳࠰࠿ࠪࠤࡁࠫ⻩"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1ll1lll_l1_ = l1ll1l_l1_ + l1ll1ll11l1_l1_ + id + l1l111_l1_ (u"ࠬ࠵ࠧ⻪") + str(l1l1lll_l1_) + l1l111_l1_ (u"࠭࠮ࡱࡰࡪࠫ⻫")
				l1ll1l11ll1_l1_ = name + title + str(l1l1lll_l1_)
				l1ll1l11ll1_l1_ = unescapeHTML(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⻬"),l1lllll_l1_+l1ll1l11ll1_l1_,url,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠨࠩ⻭"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⻮"):
		l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡄࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡏࡴࡦ࡯ࡂ࡭ࡩࡃࠧ⻯")+str(id)+l1l111_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ⻰")+l1llllll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾࠳ࠪ⻱")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⻲"),l1l111_l1_ (u"ࠧࠨ⻳"),l1l111_l1_ (u"ࠨࠩ⻴"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ⻵"))
		items = re.findall(l1l111_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡆ࡬ࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⻶"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ⻷")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⻸"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ⻹")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⻺"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⻻")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⻼"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⻽")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll1l111ll_l1_ += 1
			l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll1l11ll1_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⻾"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠬ࠭⻿"),str(l1ll1l111ll_l1_))
	elif type==l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⼀"):
		if l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴࠨ⼁") in url and l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⼂") not in url:
			l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀࠫ⼃")+str(id)+l1l111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⼄")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠵࠭⼅")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⼆"),l1l111_l1_ (u"࠭ࠧ⼇"),l1l111_l1_ (u"ࠧࠨ⼈"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠶ࡶࡩ࠭⼉"))
			items = re.findall(l1l111_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⼊"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = name + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ⼋") + title
				l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭⼌"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⼍"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"࠭ࠧ⼎"),str(l1ll1l111ll_l1_))
		elif l1l111_l1_ (u"ࠧࡄ࡮࡬ࡴࡸ࠭⼏") in url:
			l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ⼐")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠴࠹ࠬ⼑")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⼒"),l1l111_l1_ (u"ࠫࠬ⼓"),l1l111_l1_ (u"ࠬ࠭⼔"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠵ࡶ࡫ࠫ⼕"))
			items = re.findall(l1l111_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⼖"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⼗"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⼘"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠪࠫ⼙"),str(l1ll1l111ll_l1_))
		elif l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⼚") in url:
			if l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠷ࠩ⼛") in url:
				l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⼜")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠷ࠩ⼝")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⼞"),l1l111_l1_ (u"ࠩࠪ⼟"),l1l111_l1_ (u"ࠪࠫ⼠"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠻ࡴࡩࠩ⼡"))
			elif l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠵ࠩ⼢") in url:
				l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⼣")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠵ࠩ⼤")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⼥"),l1l111_l1_ (u"ࠩࠪ⼦"),l1l111_l1_ (u"ࠪࠫ⼧"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠼ࡴࡩࠩ⼨"))
			items = re.findall(l1l111_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⼩"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = name + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ⼪") + title
				l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ⼫"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⼬"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠩࠪ⼭"),str(l1ll1l111ll_l1_))
	if type==l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⼮") or type==l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⼯"):
		if l1ll1l111ll_l1_>25:
			title=l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⼰")
			if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⼱"): title = l1l111_l1_ (u"ࠧࠡࡒࡤ࡫ࡪࠦࠧ⼲")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⼳"): title = l1l111_l1_ (u"ูࠩࠣๆำ็ࠡࠩ⼴")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⼵"): title = l1l111_l1_ (u"ࠫࠥ฻แฮ้ࠣࠫ⼶")
			for l1ll1l1llll_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
					l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠬ࠶ࠧ⼷")+str(l1ll1l1llll_l1_)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼸"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,23,l1l111_l1_ (u"ࠧࠨ⼹"),l1ll1l111l1_l1_+l1ll1l11l11_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll1ll1l1l_l1_ = l1ll1l1ll1l_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ⼺"),l1l111_l1_ (u"ࠩࠪ⼻"),l1l111_l1_ (u"ࠪࠫ⼼"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⼽"))
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࡢ࠭࠭࠴ࠪࡀࠫࠥࡂࠬ⼾"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
		parts = url.split(l1l111_l1_ (u"࠭࠯ࠨ⼿"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"ࠧ࠰࠮ࠪ⽀")+l1l1lll_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ⽁")+l1l1lll_l1_+l1l111_l1_ (u"ࠩࡢࠫ⽂")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ⽃"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪ࠭࠭ࡢ࠮࠯ࠬࡂ࠭ࠧ࠭⽄"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ⽅"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"࠭࠯ࠨ⽆")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡺࡸ࡬ࠨ⽇"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⽈"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࠲࠳ࠬ⽉"),l1l111_l1_ (u"ࠪ࠳ࠬ⽊"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠡࡵࡵࡧࠬ⽋"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⽌"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l1l_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠶ࠣࡥࡩࡪࡲࡦࡵࡶࠫ⽍"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠧࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⽎"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l1l_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠷ࠥࡧࡤࡥࡴࡨࡷࡸ࠭⽏"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ⽐"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⽑"))
	return
def l1ll1l1ll1l_l1_(url):
	if l111l1_l1_ in url: l1lll11ll1l_l1_ = l111l1_l1_
	elif l1l1l1l1l1_l1_ in url: l1lll11ll1l_l1_ = l1l1l1l1l1_l1_
	elif l1ll1l1lll1_l1_ in url: l1lll11ll1l_l1_ = l1ll1l1lll1_l1_
	elif l1ll1ll1111_l1_ in url: l1lll11ll1l_l1_ = l1ll1ll1111_l1_
	else: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ⽒")
	return l1lll11ll1l_l1_
def l1ll1ll1ll1_l1_(url):
	if   l111l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠬࡧࡲࠨ⽓")
	elif l1l1l1l1l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"࠭ࡥ࡯ࠩ⽔")
	elif l1ll1l1lll1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠧࡧࡣࠪ⽕")
	elif l1ll1ll1111_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⽖")
	else: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠩࠪ⽗")
	return l1lllll11ll_l1_
def l1ll1llll_l1_(url):
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡏ࡭ࡻ࡫ࠧ⽘")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⽙"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⽚"),l1l111_l1_ (u"࠭ࠧ⽛"),l1l111_l1_ (u"ࠧࠨ⽜"),l1l111_l1_ (u"ࠨࠩ⽝"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ⽞"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⽟"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⽠"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⽡"),l1l111_l1_ (u"࠭ࠫࠨ⽢"))
	if l11_l1_:
		l1111111l_l1_ = [ l111l1_l1_ , l1l1l1l1l1_l1_ , l1ll1l1lll1_l1_ , l1ll1ll1111_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ฺࠧำห๎ࠬ⽣") , l1l111_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ⽤") , l1l111_l1_ (u"ࠩไหึู้ࠨ⽥") , l1l111_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⽦") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่้เษࠡษ็้๋อำษห࠽ࠫ⽧"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l1111111l_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭⽨") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"࠭࡟ࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎ࡟ࠨ⽩") in options: l1l11l11_l1_ = l1l1l1l1l1_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"ࠧࠨ⽪")
	if not l1l11l11_l1_: return
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠣ࠱ࡋࡳࡲ࡫࠯ࡔࡧࡤࡶࡨ࡮࠿ࡴࡧࡤࡶࡨ࡮ࡳࡵࡴ࡬ࡲ࡬ࡃࠢ⽫") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⽬"),l1l111_l1_ (u"ࠪࠫ⽭"),l1l111_l1_ (u"ࠫࠬ⽮"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ⽯"))
	items = re.findall(l1l111_l1_ (u"࠭ࠢࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠪ⽰"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"ࠧ࠴ࠩ⽱"),l1l111_l1_ (u"ࠨ࠹ࠪ⽲")]:
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ⽳"),l1l111_l1_ (u"ࠪࠫ⽴"))
				title = title.replace(l1l111_l1_ (u"ࠫࠧ࠭⽵"),l1l111_l1_ (u"ࠬ࠭⽶"))
				if category==l1l111_l1_ (u"࠭࠳ࠨ⽷"):
					type = l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⽸")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡣࡵࠫ⽹"): name = l1l111_l1_ (u"่ࠩืู้ไࠡ࠼ࠣࠫ⽺")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⽻"): name = l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠿ࠦࠧ⽼")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⽽"): name = l1l111_l1_ (u"࠭ำา์ส่ࠥํวࠡ࠼ࠣࠫ⽾")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⽿"): name = l1l111_l1_ (u"ࠨีิ๎ฬ๊่ࠠษࠣ࠾ࠥ࠭⾀")
				elif category==l1l111_l1_ (u"ࠩ࠸ࠫ⾁"):
					type = l1l111_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⾂")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫࡦࡸࠧ⾃"): name = l1l111_l1_ (u"ࠬ็๊ๅ็ࠣ࠾ࠥ࠭⾄")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⾅"): name = l1l111_l1_ (u"ࠧࡎࡱࡹ࡭ࡪࠦ࠺ࠡࠩ⾆")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⾇"): name = l1l111_l1_ (u"ࠩไ๎้๋ࠠ࠻ࠢࠪ⾈")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⾉"): name = l1l111_l1_ (u"ࠫๆ๊ๅ้ࠡสࠤ࠿ࠦࠧ⾊")
				elif category==l1l111_l1_ (u"ࠬ࠽ࠧ⾋"):
					type = l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⾌")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡢࡴࠪ⾍"): name = l1l111_l1_ (u"ࠨสิ๊ฬ๋ฬࠡ࠼ࠣࠫ⾎")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⾏"): name = l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠤ࠿ࠦࠧ⾐")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⾑"): name = l1l111_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠡ࠼ࠣࠫ⾒")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⾓"): name = l1l111_l1_ (u"ࠧษำ้ห๊ํ่ࠠษࠣ࠾ࠥ࠭⾔")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠨ࠱ࠪ⾕") + type + l1l111_l1_ (u"ࠩ࠲ࡇࡴࡴࡴࡦࡰࡷ࠳ࠬ⾖") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⾗"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⾘"))
	return
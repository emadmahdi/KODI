# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫ䗋")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡒࡓࡕࡡࠪ䗌")
l1l1lll11lll_l1_ = 4
l1l1lll111ll_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll1ll_l1_):
	try: l1l1ll1l1l11_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗍")])
	except: l1l1ll1l1l11_l1_ = l1l111_l1_ (u"࠭ࠧ䗎")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1llll1ll1_l1_(text)
	elif mode==162: l1lll_l1_ = l1l1ll11l1l1_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l1ll11l1l1_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1llll1l11_l1_(text)
	elif mode==165: l1lll_l1_ = l1l1l1lllll1_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1lll1ll11_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l1l1llll1l_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l1l1ll11l1_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1llll111l_l1_()
	elif mode==762: l1lll_l1_ = l1l1ll1ll11l_l1_()
	elif mode==763: l1lll_l1_ = l1l1ll1l1lll_l1_(l1l1ll1l1l11_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1lll11l1l_l1_(l1l1ll1l1l11_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1lll1llll_l1_(l1l1ll1l1l11_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗏"),l1l111_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆࠡ฻ื์ฬฬ๊สࠩ䗐"),l1l111_l1_ (u"ࠩࠪ䗑"),161,l1l111_l1_ (u"ࠪࠫ䗒"),l1l111_l1_ (u"ࠫࠬ䗓"),l1l111_l1_ (u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䗔"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗕"),l1l111_l1_ (u"ࠧใี่ࠤ฾ฺ่ศศํࠫ䗖"),l1l111_l1_ (u"ࠨࠩ䗗"),162,l1l111_l1_ (u"ࠩࠪ䗘"),l1l111_l1_ (u"ࠪࠫ䗙"),l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䗚"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗛"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩ䗜"),l1l111_l1_ (u"ࠧࠨ䗝"),163,l1l111_l1_ (u"ࠨࠩ䗞"),l1l111_l1_ (u"ࠩࠪ䗟"),l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䗠"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗡"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํࠫ䗢"),l1l111_l1_ (u"࠭ࠧ䗣"),164,l1l111_l1_ (u"ࠧࠨ䗤"),l1l111_l1_ (u"ࠨࠩ䗥"),l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗦"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗧"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ䗨"),l1l111_l1_ (u"ࠬ࠭䗩"),763,l1l111_l1_ (u"࠭ࠧ䗪"),l1l111_l1_ (u"ࠧࠨ䗫"),l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ䗬"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䗭"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䗮"),l1l111_l1_ (u"ࠫࠬ䗯"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗰"),l1l111_l1_ (u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ䗱"),l1l111_l1_ (u"ࠧࠨ䗲"),163,l1l111_l1_ (u"ࠨࠩ䗳"),l1l111_l1_ (u"ࠩࠪ䗴"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗵"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗶"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ䗷"),l1l111_l1_ (u"࠭ࠧ䗸"),163,l1l111_l1_ (u"ࠧࠨ䗹"),l1l111_l1_ (u"ࠨࠩ䗺"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䗻"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗼"),l1l111_l1_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ䗽"),l1l111_l1_ (u"ࠬ࠭䗾"),162,l1l111_l1_ (u"࠭ࠧ䗿"),l1l111_l1_ (u"ࠧࠨ䘀"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘁"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘂"),l1l111_l1_ (u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ䘃"),l1l111_l1_ (u"ࠫࠬ䘄"),162,l1l111_l1_ (u"ࠬ࠭䘅"),l1l111_l1_ (u"࠭ࠧ䘆"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘇"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘈"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡสะฯࠥ฿ิ้ษษ๎ࠬ䘉"),l1l111_l1_ (u"ࠪࠫ䘊"),164,l1l111_l1_ (u"ࠫࠬ䘋"),l1l111_l1_ (u"ࠬ࠭䘌"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘍"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘎"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ䘏"),l1l111_l1_ (u"ࠩࠪ䘐"),765,l1l111_l1_ (u"ࠪࠫ䘑"),l1l111_l1_ (u"ࠫࠬ䘒"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘓"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䘔"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䘕"),l1l111_l1_ (u"ࠨࠩ䘖"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘗"),l1l111_l1_ (u"ࠪๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ䘘"),l1l111_l1_ (u"ࠫࠬ䘙"),163,l1l111_l1_ (u"ࠬ࠭䘚"),l1l111_l1_ (u"࠭ࠧ䘛"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘜"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘝"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ䘞"),l1l111_l1_ (u"ࠪࠫ䘟"),163,l1l111_l1_ (u"ࠫࠬ䘠"),l1l111_l1_ (u"ࠬ࠭䘡"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘢"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘣"),l1l111_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ䘤"),l1l111_l1_ (u"ࠩࠪ䘥"),162,l1l111_l1_ (u"ࠪࠫ䘦"),l1l111_l1_ (u"ࠫࠬ䘧"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘨"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘩"),l1l111_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ䘪"),l1l111_l1_ (u"ࠨࠩ䘫"),162,l1l111_l1_ (u"ࠩࠪ䘬"),l1l111_l1_ (u"ࠪࠫ䘭"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘮"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘯"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘ࡛ࠦศฮอࠣ฽ู๎วว์ࠪ䘰"),l1l111_l1_ (u"ࠧࠨ䘱"),164,l1l111_l1_ (u"ࠨࠩ䘲"),l1l111_l1_ (u"ࠩࠪ䘳"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘴"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘵"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭䘶"),l1l111_l1_ (u"࠭ࠧ䘷"),764,l1l111_l1_ (u"ࠧࠨ䘸"),l1l111_l1_ (u"ࠨࠩ䘹"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘺"))
	return
def l1l1llll111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘻"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪ䘼")+l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪ䘽"),l1l111_l1_ (u"࠭ࠧ䘾"),764)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䘿"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䙀"),l1l111_l1_ (u"ࠩࠪ䙁"),9999)
	for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡎࡖࠧ䙂")+str(l1l1ll1l1l11_l1_)+l1l111_l1_ (u"ࠫࡤ࠭䙃")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙄"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨ䙅")+NUMBERS_SEQ_NAME[l1l1ll1l1l11_l1_],l1l111_l1_ (u"ࠧࠨ䙆"),764,l1l111_l1_ (u"ࠨࠩ䙇"),l1l111_l1_ (u"ࠩࠪ䙈"),l1l111_l1_ (u"ࠪࠫ䙉"),l1l111_l1_ (u"ࠫࠬ䙊"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙋"):l1l1ll1l1l11_l1_})
	return
def l1l1ll1ll11l_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙌"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䙍")+l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬ䙎"),l1l111_l1_ (u"ࠩࠪ䙏"),765)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䙐"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䙑"),l1l111_l1_ (u"ࠬ࠭䙒"),9999)
	for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡎࡗࠪ䙓")+str(l1l1ll1l1l11_l1_)+l1l111_l1_ (u"ࠧࡠࠩ䙔")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙕"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫ䙖")+NUMBERS_SEQ_NAME[l1l1ll1l1l11_l1_],l1l111_l1_ (u"ࠪࠫ䙗"),765,l1l111_l1_ (u"ࠫࠬ䙘"),l1l111_l1_ (u"ࠬ࠭䙙"),l1l111_l1_ (u"࠭ࠧ䙚"),l1l111_l1_ (u"ࠧࠨ䙛"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙜"):l1l1ll1l1l11_l1_})
	return
def l1l1llll1111_l1_(l1lll11ll1l_l1_):
	global l1l1ll1l1111_l1_,l1l1ll11lll1_l1_
	l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
	try:
		if l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ䙝") in l1lll11ll1l_l1_: l1lll111l11_l1_(l1lll11ll1l_l1_)
		else: l1lll111l11_l1_()
		l1l1ll1ll111_l1_ = False
	except:
		l11ll111111_l1_()
		l1l1ll1ll111_l1_ = True
	l1lll11ll1l_l1_ = TRANSLATE(l1lll11ll1l_l1_)
	if l1l1ll1ll111_l1_:
		l1ll1lll_l1_(l1lll11ll1l_l1_,l1l111_l1_ (u"ࠪๅู๊ࠠๅๆฦืๆ࠭䙞"),time=2000)
		l1l1ll1l1111_l1_ += 1
		l1l1ll11lll1_l1_ += l1l111_l1_ (u"ࠫࠥ࠭䙟")+l1lll11ll1l_l1_
	else: l1ll1lll_l1_(l1lll11ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䙠"),time=1000)
	return
def l1l1ll1l11l1_l1_(l1l1ll1ll1l1_l1_=True):
	global l1l1ll1l1111_l1_,l1l1ll11lll1_l1_
	if not l1l1ll1ll1l1_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ䙡"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ䙢"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭䙣"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䙤"),l1l111_l1_ (u"ࠪࠫ䙥"),l1l111_l1_ (u"ࠫࠬ䙦"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䙧"),l1l111_l1_ (u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ䙨"))
	if l1llll111l_l1_!=1: return
	l1l1l1ll1lll_l1_ = menuItemsLIST
	l1l1ll1l1111_l1_,l1l1ll11lll1_l1_,threads = 0,l1l111_l1_ (u"ࠧࠨ䙩"),{}
	for l1lll11ll1l_l1_ in l1l1111111l_l1_:
		time.sleep(0.5)
		threads[l1lll11ll1l_l1_] = threading.Thread(target=l1l1llll1111_l1_,args=(l1lll11ll1l_l1_,))
		threads[l1lll11ll1l_l1_].start()
		if l1l1ll1l1111_l1_>=l1l1lll111ll_l1_: break
	else:
		for l1lll11ll1l_l1_ in list(threads.keys()):
			threads[l1lll11ll1l_l1_].join()
	menuItemsLIST[:] = l1l1l1ll1lll_l1_
	if l1l1ll1l1111_l1_>=l1l1lll111ll_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙪"),l1l111_l1_ (u"ࠩࠪ䙫"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䙬"),l1l111_l1_ (u"้ࠫี๊ไุ่่๊ࠢษࠡใํࠤࠬ䙭")+str(l1l1ll1l1111_l1_)+l1l111_l1_ (u"ࠬࠦๅ้ษๅ฽๋ࠥๆࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢ࠱࠲࠳่ࠦิสห๋ฬࠦโะࠢํ็ํ์ฺࠠั่ࠤํา่ะࠢศ๊ฯืๆ๋ฬࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋࠼ࠪ䙮")+l1l1ll11lll1_l1_)
	else:
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ䙯"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬ䙰"),contentsDICT,l1ll111ll11_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙱"),l1l111_l1_ (u"ࠩࠪ䙲"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䙳"),l1l111_l1_ (u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪ䙴"))
	return
def l1l1ll111lll_l1_(l1l1ll1l1l11_l1_,options):
	l111lll11l1_l1_ = False
	l1l1l1ll11ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111lll11l1_l1_ and l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䙵") not in options:
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䙶"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧ䙷"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩ䙸")+l1l1ll1l1l11_l1_)
	elif l1l111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䙹") not in options or l1l111_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ䙺") not in options:
		import IPTV
		message = l1l111_l1_ (u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ䙻")
		if l1l111_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䙼") not in options:
			try: IPTV.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䙽"),l1l111_l1_ (u"ࠧࠨ䙾"),l1l111_l1_ (u"ࠨࠩ䙿"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚀"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚁"),l1l111_l1_ (u"ࠫࠬ䚂"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚃"),message)
			try: IPTV.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚄"),l1l111_l1_ (u"ࠧࠨ䚅"),l1l111_l1_ (u"ࠨࠩ䚆"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚇"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚈"),l1l111_l1_ (u"ࠫࠬ䚉"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚊"),message)
			try: IPTV.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚋"),l1l111_l1_ (u"ࠧࠨ䚌"),l1l111_l1_ (u"ࠨࠩ䚍"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚎"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚏"),l1l111_l1_ (u"ࠫࠬ䚐"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚑"),message)
		if l1l111_l1_ (u"࠭࡟ࡗࡑࡇࡣࠬ䚒") not in options:
			try: IPTV.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚓"),l1l111_l1_ (u"ࠨࠩ䚔"),l1l111_l1_ (u"ࠩࠪ䚕"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚖"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚗"),l1l111_l1_ (u"ࠬ࠭䚘"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫ䚙"),message)
			try: IPTV.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚚"),l1l111_l1_ (u"ࠨࠩ䚛"),l1l111_l1_ (u"ࠩࠪ䚜"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚝"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚞"),l1l111_l1_ (u"ࠬ࠭䚟"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫ䚠"),message)
		l1lll_l1_ = menuItemsLIST
		if l111lll11l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧ䚡"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩ䚢")+l1l1ll1l1l11_l1_,l1lll_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1l1ll11ll_l1_
	return l1lll_l1_
def l1l1ll1l1ll1_l1_(l1l1ll1l1l11_l1_,options):
	l111lll11l1_l1_ = False
	l1l1l1ll11ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111lll11l1_l1_ and l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䚣") not in options:
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䚤"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ䚥"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ䚦")+l1l1ll1l1l11_l1_)
	elif l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭䚧") not in options or l1l111_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䚨") not in options:
		import M3U
		message = l1l111_l1_ (u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭䚩")
		if l1l111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䚪") not in options:
			try: M3U.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚫"),l1l111_l1_ (u"ࠫࠬ䚬"),l1l111_l1_ (u"ࠬ࠭䚭"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚮"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䚯"),l1l111_l1_ (u"ࠨࠩ䚰"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䚱"),message)
			try: M3U.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚲"),l1l111_l1_ (u"ࠫࠬ䚳"),l1l111_l1_ (u"ࠬ࠭䚴"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚵"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䚶"),l1l111_l1_ (u"ࠨࠩ䚷"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䚸"),message)
			try: M3U.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚹"),l1l111_l1_ (u"ࠫࠬ䚺"),l1l111_l1_ (u"ࠬ࠭䚻"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚼"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䚽"),l1l111_l1_ (u"ࠨࠩ䚾"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䚿"),message)
		if l1l111_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ䛀") not in options:
			try: M3U.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䛁"),l1l111_l1_ (u"ࠬ࠭䛂"),l1l111_l1_ (u"࠭ࠧ䛃"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛄"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛅"),l1l111_l1_ (u"ࠩࠪ䛆"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅไ้์ฬะࠧ䛇"),message)
			try: M3U.GROUPS(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䛈"),l1l111_l1_ (u"ࠬ࠭䛉"),l1l111_l1_ (u"࠭ࠧ䛊"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛋"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛌"),l1l111_l1_ (u"ࠩࠪ䛍"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅไ้์ฬะࠧ䛎"),message)
		l1lll_l1_ = menuItemsLIST
		if l111lll11l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ䛏"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ䛐")+l1l1ll1l1l11_l1_,l1lll_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1l1ll11ll_l1_
	return l1lll_l1_
def l1l1ll1l1lll_l1_(l1l1ll1l1l11_l1_,options,l1l1ll111111_l1_):
	if l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䛑") in options and l1l1ll111111_l1_==l1l111_l1_ (u"ࠧࠨ䛒"): l1l1ll1l11l1_l1_(True)
	elif l1l1ll111111_l1_: l1l1ll1l11l1_l1_(False)
	l1l1ll1111ll_l1_ = options.replace(l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䛓"),l1l111_l1_ (u"ࠩࠪ䛔")).replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛕"),l1l111_l1_ (u"ࠫࠬ䛖")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛗"),l1l111_l1_ (u"࠭ࠧ䛘"))
	if not l1l1ll111111_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䛙"),l1l111_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ䛚"),l1l111_l1_ (u"ࠩࠪ䛛"),763,l1l111_l1_ (u"ࠪࠫ䛜"),l1l111_l1_ (u"ࠫࠬ䛝"),l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䛞")+l1l1ll1111ll_l1_,l1l111_l1_ (u"࠭ࠧ䛟"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䛠"):l1l1ll1l1l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䛡"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䛢"),l1l111_l1_ (u"ࠪࠫ䛣"),9999)
	l1llllll11_l1_ = [l1l111_l1_ (u"ࠫศ็ไศ็ࠪ䛤"),l1l111_l1_ (u"๋ࠬำๅี็หฯ࠭䛥"),l1l111_l1_ (u"࠭ๅิำะ๎ฬะࠧ䛦"),l1l111_l1_ (u"ࠧษำส้ั࠭䛧"),l1l111_l1_ (u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧ䛨"),l1l111_l1_ (u"ࠩิ้฻อๆࠨ䛩"),l1l111_l1_ (u"ࠪวาีห࠮ลัีࠬ䛪"),l1l111_l1_ (u"ุ๊ࠫวิๆࠪ䛫"),l1l111_l1_ (u"๋่ࠬิ์ๅํࠬ䛬"),l1l111_l1_ (u"࠭รี้ิ࠱ศ้หาࠩ䛭"),l1l111_l1_ (u"ࠧศๆล๊ࠬ䛮"),l1l111_l1_ (u"ࠨุะ็ࠬ䛯"),l1l111_l1_ (u"ࠩิ๎ฬ฼ษࠨ䛰"),l1l111_l1_ (u"๊ࠪ๏ะแๅๅึࠫ䛱"),l1l111_l1_ (u"๊๋ࠫหๅ์้ࠫ䛲"),l1l111_l1_ (u"ࠬฮหࠡฯํࠫ䛳"),l1l111_l1_ (u"࠭ฯ๋่ํอࠬ䛴"),l1l111_l1_ (u"ࠧิ่๋หฯ࠭䛵"),l1l111_l1_ (u"ࠨลัี๎࠭䛶")]
	l1l1l1lll111_l1_ = [l1l111_l1_ (u"ࠩสๅ้อๅࠨ䛷"),l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ䛸"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ䛹"),l1l111_l1_ (u"ࠬ็ไๆࠩ䛺")]
	l1ll11lllll_l1_ = [l1l111_l1_ (u"࠭ๅิๆึ่ࠬ䛻"),l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䛼")]
	l1l1llll1l1l_l1_ = [l1l111_l1_ (u"ࠨ็ึหึำࠧ䛽"),l1l111_l1_ (u"่ࠩืึำ๊ศฬࠪ䛾")]
	l1l1ll1111l1_l1_ = [l1l111_l1_ (u"ࠪฬึอๅอࠩ䛿"),l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸࠩ䜀"),l1l111_l1_ (u"ࠬะไโิํ์๋࠭䜁"),l1l111_l1_ (u"࠭สๅ์ไึ๏๎ๆࠨ䜂")]
	l1l1lll1111l_l1_ = [l1l111_l1_ (u"ࠧศ่่๎ࠬ䜃"),l1l111_l1_ (u"ࠨๅิฮํ์ࠧ䜄"),l1l111_l1_ (u"ࠩๆหึะ่็ࠩ䜅"),l1l111_l1_ (u"ࠪ࡯࡮ࡪࡳࠨ䜆"),l1l111_l1_ (u"ࠫ฼็ไࠨ䜇"),l1l111_l1_ (u"ࠬอืโษ็ࠫ䜈")]
	l11111l1_l1_ = [l1l111_l1_ (u"࠭ัๆุส๊ࠬ䜉")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠧศฯาฯࠬ䜊"),l1l111_l1_ (u"ࠨษัีࠬ䜋"),l1l111_l1_ (u"่ࠩ์ำืࠧ䜌"),l1l111_l1_ (u"ࠪะิ๐ฯࠨ䜍"),l1l111_l1_ (u"๊ࠫ฼วโࠩ䜎"),l1l111_l1_ (u"ࠬำฯ๋อࠪ䜏")]
	l1l1ll11l111_l1_ = [l1l111_l1_ (u"࠭ำๅษึ่ࠬ䜐"),l1l111_l1_ (u"ࠧิๆึ่์࠭䜑")]
	l1l1l1ll111l_l1_ = [l1l111_l1_ (u"ࠨษ฽ห๋๐ࠧ䜒"),l1l111_l1_ (u"่ࠩ์ุ๐โ๊ࠩ䜓"),l1l111_l1_ (u"ࠪ็้๐ศࠨ䜔"),l1l111_l1_ (u"ࠫา็ไࠨ䜕"),l1l111_l1_ (u"ࠬࡳࡵࡴ࡫ࡦࠫ䜖")]
	l11l1l111_l1_ = [l1l111_l1_ (u"࠭วไอิࠫ䜗"),l1l111_l1_ (u"ࠧศึ๊ีࠬ䜘"),l1l111_l1_ (u"ࠨ็่๎ืํࠧ䜙"),l1l111_l1_ (u"ࠩส฽้๏ࠧ䜚"),l1l111_l1_ (u"้ࠪำะวา้ࠪ䜛"),l1l111_l1_ (u"๊ࠫิสศำสฮࠬ䜜"),l1l111_l1_ (u"ࠬอโ้๋ࠪ䜝")]
	l1l1l1ll1111_l1_ = [l1l111_l1_ (u"࠭วๅษ้ࠫ䜞"),l1l111_l1_ (u"ࠧฮษ็๎ࠬ䜟"),l1l111_l1_ (u"ࠨ็ฮฬฯ࠭䜠"),l1l111_l1_ (u"ࠩิหหาࠧ䜡")]
	l1l1l1ll1l11_l1_ = [l1l111_l1_ (u"ฺࠪา้ࠧ䜢"),l1l111_l1_ (u"่ࠫ๎ๅ๋ัํࠫ䜣")]
	l1l1lll1l1ll_l1_ = [l1l111_l1_ (u"ࠬื๊ศุ๊ࠫ䜤"),l1l111_l1_ (u"࠭ใ้ำ๊ࠫ䜥"),l1l111_l1_ (u"ࠧๆืสี฾ํࠧ䜦"),l1l111_l1_ (u"ࠨึ๋ฮࠬ䜧"),l1l111_l1_ (u"ࠩิ๎ฬ฼ษࠨ䜨")]
	l1l1ll1lll11_l1_ = [l1l111_l1_ (u"๊ࠪ๏ะแๅๅึࠫ䜩"),l1l111_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬ䜪"),l1l111_l1_ (u"ࠬ์๊หใ็๎ู่ࠧ䜫")]
	l1l1l1ll1ll1_l1_ = [l1l111_l1_ (u"࠭ๅๆอ็๎๋࠭䜬"),l1l111_l1_ (u"ࠧศึัหฺ࠭䜭"),l1l111_l1_ (u"ࠨ่ฯ์๊࠭䜮")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠩหฯࠥำ๊ࠨ䜯"),l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䜰"),l1l111_l1_ (u"ࠫ็์ว่ࠩ䜱"),l1l111_l1_ (u"่ࠬๆ้ษอࠫ䜲")]
	l1l1ll1lllll_l1_ = [l1l111_l1_ (u"࠭ฯ๋่ࠪ䜳"),l1l111_l1_ (u"ࠧศั฼๎์࠭䜴"),l1l111_l1_ (u"ࠨิํหึอสࠨ䜵"),l1l111_l1_ (u"ࠩ็฻๊๐วหࠩ䜶"),l1l111_l1_ (u"ࠪำ฾อมࠨ䜷"),l1l111_l1_ (u"ࠫ็ืว็ࠩ䜸"),l1l111_l1_ (u"่ࠬีศศาࠫ䜹"),l1l111_l1_ (u"࠭ัฬษฤࠫ䜺"),l1l111_l1_ (u"ࠧๆำฯ฽๏ํࠧ䜻"),l1l111_l1_ (u"ࠨษำห๋࠭䜼"),l1l111_l1_ (u"ࠩสื้อๅࠨ䜽"),l1l111_l1_ (u"ࠪฮํอิ๋ฯࠪ䜾"),l1l111_l1_ (u"ࠫำ฽ศࠨ䜿"),l1l111_l1_ (u"ࠬำ่ำ๊ํࠫ䝀"),l1l111_l1_ (u"ู࠭หสสฮࠬ䝁"),l1l111_l1_ (u"ࠧๆ๊ส่๏ีࠧ䝂"),l1l111_l1_ (u"ࠨ่๋ห฾๐ࠧ䝃"),l1l111_l1_ (u"ࠩ฼ๆฬฬฯࠨ䝄"),l1l111_l1_ (u"ࠪห๋อิ๋ัࠪ䝅")]
	l1l1l1lll11l_l1_ = [l1l111_l1_ (u"ࠫ࠶࠿ࠧ䝆"),l1l111_l1_ (u"ࠬ࠸࠰ࠨ䝇"),l1l111_l1_ (u"࠭࠲࠲ࠩ䝈"),l1l111_l1_ (u"ࠧ࠳࠴ࠪ䝉"),l1l111_l1_ (u"ࠨ࠴࠶ࠫ䝊"),l1l111_l1_ (u"ࠩ࠵࠸ࠬ䝋"),l1l111_l1_ (u"ࠪ࠶࠺࠭䝌"),l1l111_l1_ (u"ࠫ࠷࠼ࠧ䝍")]
	if not l1l1ll111111_l1_:
		l1l1ll111111_l1_ = 0
		for l1l1ll1l11ll_l1_ in l1llllll11_l1_:
			l1l1ll111111_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䝎"),l1lllll_l1_+l1l1ll1l11ll_l1_,l1l111_l1_ (u"࠭ࠧ䝏"),763,l1l111_l1_ (u"ࠧࠨ䝐"),str(l1l1ll111111_l1_),l1l1ll1111ll_l1_,l1l111_l1_ (u"ࠨࠩ䝑"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝒"):l1l1ll1l1l11_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l11111111l_l1_ = name.lower()
			category = []
			if any(value in l11111111l_l1_ for value in l1l1l1lll111_l1_): category.append(1)
			if any(value in l11111111l_l1_ for value in l1ll11lllll_l1_): category.append(2)
			if any(value in l11111111l_l1_ for value in l1l1llll1l1l_l1_): category.append(3)
			if any(value in l11111111l_l1_ for value in l1l1ll1111l1_l1_): category.append(4)
			if any(value in l11111111l_l1_ for value in l1l1lll1111l_l1_): category.append(5)
			if any(value in l11111111l_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l11111111l_l1_ for value in l1lllll1l_l1_) and l11111111l_l1_ not in [l1l111_l1_ (u"ࠪหำื้ࠨ䝓")]: category.append(7)
			if any(value in l11111111l_l1_ for value in l1l1ll11l111_l1_): category.append(8)
			if any(value in l11111111l_l1_ for value in l1l1l1ll111l_l1_): category.append(9)
			if any(value in l11111111l_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l11111111l_l1_ for value in l1l1l1ll1111_l1_): category.append(11)
			if any(value in l11111111l_l1_ for value in l1l1l1ll1l11_l1_): category.append(12)
			if any(value in l11111111l_l1_ for value in l1l1lll1l1ll_l1_): category.append(13)
			if any(value in l11111111l_l1_ for value in l1l1ll1lll11_l1_): category.append(14)
			if any(value in l11111111l_l1_ for value in l1l1l1ll1ll1_l1_): category.append(15)
			if any(value in l11111111l_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l11111111l_l1_ for value in l1l1ll1lllll_l1_): category.append(17)
			if any(value in l11111111l_l1_ for value in l1l1l1lll11l_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l1ll111111_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝔"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠬ࠭䝕"),l1l111_l1_ (u"࠭ࠧ䝖"),l1l1ll1111ll_l1_+l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䝗"))
	return
def l1l1lll11l1l_l1_(l1l1ll1l1l11_l1_,options):
	l111lll11l1_l1_ = False
	if l111lll11l1_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䝘"),l1l111_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭䝙"),l1l111_l1_ (u"ࠪࠫ䝚"),764,l1l111_l1_ (u"ࠫࠬ䝛"),l1l111_l1_ (u"ࠬ࠭䝜"),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䝝"),l1l111_l1_ (u"ࠧࠨ䝞"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝟"):l1l1ll1l1l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝠"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䝡"),l1l111_l1_ (u"ࠫࠬ䝢"),9999)
	l1l1l1ll11ll_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1ll1l1l11_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1ll1l1l11_l1_,True): return
		l1l1ll11l11l_l1_ = l1l1ll111lll_l1_(l1l1ll1l1l11_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll11l11l_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䝣"),True): return
		if l111lll11l1_l1_ and l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䝤") not in options:
			l111l1ll11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䝥"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䝦"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭䝧"))
		else:
			l1l1l1lll1l1_l1_,l111l1ll11_l1_,l1l1ll11l11l_l1_ = [],[],[]
			for l1l1ll1l111l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1ll111lll_l1_(str(l1l1ll1l111l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1l1lll1l1_l1_:
					l1l1l1lll1l1_l1_.append(text)
					l1l1lll1ll1l_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll11l11l_l1_.append(l1l1lll1ll1l_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll11l11l_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111lll11l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ䝨"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨ䝩"),l111l1ll11_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1l1ll11ll_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䝪"))
	return
def l1l1lll1llll_l1_(l1l1ll1l1l11_l1_,options):
	l111lll11l1_l1_ = False
	if l111lll11l1_l1_:
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䝫"),l1l111_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ䝬"),l1l111_l1_ (u"ࠨࠩ䝭"),765,l1l111_l1_ (u"ࠩࠪ䝮"),l1l111_l1_ (u"ࠪࠫ䝯"),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝰"),l1l111_l1_ (u"ࠬ࠭䝱"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝲"):l1l1ll1l1l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䝳"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䝴"),l1l111_l1_ (u"ࠩࠪ䝵"),9999)
	l1l1l1ll11ll_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1ll1l1l11_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1ll1l1l11_l1_,True): return
		l1l1ll11l11l_l1_ = l1l1ll1l1ll1_l1_(l1l1ll1l1l11_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll11l11l_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䝶"),True): return
		if l111lll11l1_l1_ and l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝷") not in options:
			l111l1ll11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䝸"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ䝹"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪ䝺"))
		else:
			l1l1l1lll1l1_l1_,l111l1ll11_l1_,l1l1ll11l11l_l1_ = [],[],[]
			for l1l1ll1l111l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1ll1l1ll1_l1_(str(l1l1ll1l111l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1l1lll1l1_l1_:
					l1l1l1lll1l1_l1_.append(text)
					l1l1lll1ll1l_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll11l11l_l1_.append(l1l1lll1ll1l_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll11l11l_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111lll11l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ䝻"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬ䝼"),l111l1ll11_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1l1ll11ll_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䝽"))
	return
def l1l1l1lllll1_l1_(group,options):
	l111lll11l1_l1_ = False
	l1lll_l1_ = []
	l1l1ll1l1l1l_l1_ = l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䝾") if l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ䝿") in options else l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䞀")
	if l111lll11l1_l1_: l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䞁"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䞂")+l1l1ll1l1l1l_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
			if l111lll11l1_l1_: l1lll_l1_ += l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䞃"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ䞄")+l1l1ll1l1l1l_l1_[:-1],l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䞅")+l1l1ll1l1l1l_l1_+str(l1l1ll1l1l11_l1_))
			elif l1l1ll1l1l1l_l1_==l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䞆"): l1lll_l1_ += l1l1ll111lll_l1_(str(l1l1ll1l1l11_l1_),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䞇"))
			elif l1l1ll1l1l1l_l1_==l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䞈"): l1lll_l1_ += l1l1ll1l1ll1_l1_(str(l1l1ll1l1l11_l1_),l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䞉"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll_l1_:
			if text==group: l1lll1111l11_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
			l1l1ll1llll1_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠩࠪ䞊")
			if l1l1ll1llll1_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1ll1llll1_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l111lll11l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ䞋")+l1l1ll1l1l1l_l1_[:-1],group,l1lll_l1_,l1ll111ll11_l1_)
	if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䞌") in options and len(l1lll_l1_)>l1l1lll11lll_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䞍"),l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䞎")+group+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ䞏"),group,165,l1l111_l1_ (u"ࠨࠩ䞐"),l1l111_l1_ (u"ࠩࠪ䞑"),l1l1ll1l1l1l_l1_+l1l111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞒"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䞓"),l1l111_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ䞔"),group,165,l1l111_l1_ (u"࠭ࠧ䞕"),l1l111_l1_ (u"ࠧࠨ䞖"),l1l1ll1l1l1l_l1_+l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䞗"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䞘"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䞙"),l1l111_l1_ (u"ࠫࠬ䞚"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1lll11lll_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䞛"))
	return
def l1l1llll1ll1_l1_(options):
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䞜"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦืๅสࠣๆ๋๎วหࠢ฼ุํอฦ๋หࠪ䞝"),l1l111_l1_ (u"ࠨࠩ䞞"),161,l1l111_l1_ (u"ࠩࠪ䞟"),l1l111_l1_ (u"ࠪࠫ䞠"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫ䞡"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䞢"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䞣"),l1l111_l1_ (u"ࠧࠨ䞤"),9999)
	l1l1lll11l11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1llll1lllll_l1_
	l1llll1lllll_l1_.ITEMS(l1l111_l1_ (u"ࠨ࠲ࠪ䞥"),False)
	l1llll1lllll_l1_.ITEMS(l1l111_l1_ (u"ࠩ࠴ࠫ䞦"),False)
	l1llll1lllll_l1_.ITEMS(l1l111_l1_ (u"ࠪ࠶ࠬ䞧"),False)
	if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䞨") in options:
		menuItemsLIST[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1lll11lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lll11lll_l1_)
	menuItemsLIST[:] = l1l1lll11l11_l1_+menuItemsLIST
	return
def l1l1llll1l11_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䞩"),l1l111_l1_ (u"࠭ࠧ䞪")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䞫"),l1l111_l1_ (u"ࠨࠩ䞬"))
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䞭") : l1l111_l1_ (u"ࠪࠫ䞮") }
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡩࡸࡺࡲࡢࡰࡧࡳࡲࡹ࠮ࡤࡱࡰ࠳ࡷࡧ࡮ࡥࡱࡰ࠱ࡦࡸࡡࡣ࡫ࡦ࠱ࡼࡵࡲࡥࡵࠪ䞯")
	data = {l1l111_l1_ (u"ࠬࡷࡵࡢࡰࡷ࡭ࡹࡿࠧ䞰"):l1l111_l1_ (u"࠭࠵࠱ࠩ䞱")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1llll11l111_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䞲"),url,data,headers,l1l111_l1_ (u"ࠨࠩ䞳"),l1l111_l1_ (u"ࠩࠪ䞴"),l1l111_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖ࠱ࡗࡇࡎࡅࡑࡐࡣ࡛ࡏࡄࡆࡑࡖࡣࡋࡘࡏࡎࡡ࡚ࡓࡗࡊࡓ࠮࠳ࡶࡸࠬ䞵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭䞶"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ䞷"),block,re.DOTALL)
	l1l1l1l1lll1_l1_,l1l1l1lll1ll_l1_ = list(zip(*items))
	l1l1lll1lll1_l1_ = []
	l1l1llll11ll_l1_ = [l1l111_l1_ (u"࠭ࠠࠨ䞸"),l1l111_l1_ (u"ࠧࠣࠩ䞹"),l1l111_l1_ (u"ࠨࡢࠪ䞺"),l1l111_l1_ (u"ࠩ࠯ࠫ䞻"),l1l111_l1_ (u"ࠪ࠲ࠬ䞼"),l1l111_l1_ (u"ࠫ࠿࠭䞽"),l1l111_l1_ (u"ࠬࡁࠧ䞾"),l1l111_l1_ (u"ࠨࠧࠣ䞿"),l1l111_l1_ (u"ࠧ࠮ࠩ䟀")]
	l1l1ll111l11_l1_ = l1l1l1lll1ll_l1_+l1l1l1l1lll1_l1_
	for word in l1l1ll111l11_l1_:
		if word in l1l1l1lll1ll_l1_: l1l1ll1ll1ll_l1_ = 2
		if word in l1l1l1l1lll1_l1_: l1l1ll1ll1ll_l1_ = 4
		l1l1ll111ll1_l1_ = [i in word for i in l1l1llll11ll_l1_]
		if any(l1l1ll111ll1_l1_):
			index = l1l1ll111ll1_l1_.index(True)
			l1l1ll11111l_l1_ = l1l1llll11ll_l1_[index]
			l1l1lll1l11l_l1_ = l1l111_l1_ (u"ࠨࠩ䟁")
			if word.count(l1l1ll11111l_l1_)>1: l1l1lll1l1l1_l1_,l1l1lll1l111_l1_,l1l1lll1l11l_l1_ = word.split(l1l1ll11111l_l1_,2)
			else: l1l1lll1l1l1_l1_,l1l1lll1l111_l1_ = word.split(l1l1ll11111l_l1_,1)
			if len(l1l1lll1l1l1_l1_)>l1l1ll1ll1ll_l1_: l1l1lll1lll1_l1_.append(l1l1lll1l1l1_l1_.lower())
			if len(l1l1lll1l111_l1_)>l1l1ll1ll1ll_l1_: l1l1lll1lll1_l1_.append(l1l1lll1l111_l1_.lower())
			if len(l1l1lll1l11l_l1_)>l1l1ll1ll1ll_l1_: l1l1lll1lll1_l1_.append(l1l1lll1l11l_l1_.lower())
		elif len(word)>l1l1ll1ll1ll_l1_: l1l1lll1lll1_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1lll1lll1_l1_)
	if l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䟂") in options:
		l1l1l1ll1l1l_l1_ = l1lll11lll11_l1_
	elif l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䟃") in options:
		l1l1l1ll1l1l_l1_ = [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ䟄")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䟅"),True): return
	elif l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䟆") in options:
		l1l1l1ll1l1l_l1_ = [l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ䟇")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䟈"),True): return
	count,l1l1l1llll11_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟉"),l1l111_l1_ (u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫ䟊"),l1l111_l1_ (u"ࠫࠬ䟋"),164,l1l111_l1_ (u"ࠬ࠭䟌"),l1l111_l1_ (u"࠭ࠧ䟍"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟎")+options)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䟏"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡษ็ฬาัࠠศๆ฼ุํอฦ๋ࠩ䟐"),l1l111_l1_ (u"ࠪࠫ䟑"),164,l1l111_l1_ (u"ࠫࠬ䟒"),l1l111_l1_ (u"ࠬ࠭䟓"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䟔")+options)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䟕"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䟖"),l1l111_l1_ (u"ࠩࠪ䟗"),9999)
	l1l1l1l1ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1llll11l1_l1_ = []
	for word in l1l1lll1lll1_l1_:
		l1l1lll1l111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪ䟘")+l1l111_l1_ (u"ࠫࠨ࠭䟙")+l1l111_l1_ (u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩ䟚"),word,re.DOTALL)
		if l1l1lll1l111_l1_: word = word.split(l1l1lll1l111_l1_[0],1)[0]
		l1l1lll111l1_l1_ = word.replace(l1l111_l1_ (u"࠭๑ࠨ䟛"),l1l111_l1_ (u"ࠧࠨ䟜")).replace(l1l111_l1_ (u"ࠨ๐ࠪ䟝"),l1l111_l1_ (u"ࠩࠪ䟞")).replace(l1l111_l1_ (u"ࠪ๏ࠬ䟟"),l1l111_l1_ (u"ࠫࠬ䟠")).replace(l1l111_l1_ (u"ࠬ๕ࠧ䟡"),l1l111_l1_ (u"࠭ࠧ䟢")).replace(l1l111_l1_ (u"ࠧํࠩ䟣"),l1l111_l1_ (u"ࠨࠩ䟤"))
		l1l1lll111l1_l1_ = l1l1lll111l1_l1_.replace(l1l111_l1_ (u"ࠩ๓ࠫ䟥"),l1l111_l1_ (u"ࠪࠫ䟦")).replace(l1l111_l1_ (u"ࠫ๒࠭䟧"),l1l111_l1_ (u"ࠬ࠭䟨")).replace(l1l111_l1_ (u"࠭๒ࠨ䟩"),l1l111_l1_ (u"ࠧࠨ䟪")).replace(l1l111_l1_ (u"ࠨฎࠪ䟫"),l1l111_l1_ (u"ࠩࠪ䟬")).replace(l1l111_l1_ (u"ࠪไࠬ䟭"),l1l111_l1_ (u"ࠫࠬ䟮"))
		if l1l1lll111l1_l1_: l1l1llll11l1_l1_.append(l1l1lll111l1_l1_)
	l1l1lll11111_l1_ = []
	for l1l111llll_l1_ in range(0,20):
		search = random.sample(l1l1llll11l1_l1_,1)[0]
		if search in l1l1lll11111_l1_: continue
		l1l1lll11111_l1_.append(search)
		l1lll11ll1l_l1_ = random.sample(l1l1l1ll1l1l_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䟯"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩ䟰")+str(l1lll11ll1l_l1_)+l1l111_l1_ (u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪ䟱")+search)
		l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
		l1lll11ll11_l1_(search+l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䟲"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䟳"),l1l111_l1_ (u"ࠪࠫ䟴"))
	l1l1l1l1ll1l_l1_[0][1] = l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䟵")+search+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻สะฯࠥ฿ๆ࡞ࠩ䟶")
	menuItemsLIST[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1lll11lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lll11lll_l1_)
	menuItemsLIST[:] = l1l1l1l1ll1l_l1_+menuItemsLIST
	return
def l1l1lll1ll11_l1_(l1l1l1llllll_l1_,options):
	l1l1l1llllll_l1_ = l1l1l1llllll_l1_.replace(l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䟷"),l1l111_l1_ (u"ࠧࠨ䟸"))
	options = options.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟹"),l1l111_l1_ (u"ࠩࠪ䟺")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䟻"),l1l111_l1_ (u"ࠫࠬ䟼"))
	l1l1ll1l11l1_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䟽") in options:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟾"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䟿")+l1l1l1llllll_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䠀"),l1l1l1llllll_l1_,166,l1l111_l1_ (u"ࠩࠪ䠁"),l1l111_l1_ (u"ࠪࠫ䠂"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠃")+options)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䠄"),l1l111_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䠅"),l1l1l1llllll_l1_,166,l1l111_l1_ (u"ࠧࠨ䠆"),l1l111_l1_ (u"ࠨࠩ䠇"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠈")+options)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䠉"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䠊"),l1l111_l1_ (u"ࠬ࠭䠋"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l1l1llllll_l1_].keys())):
		type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1l1llllll_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䠌") in options or len(contentsDICT[l1l1l1llllll_l1_])==1:
			l1lll1111l11_l1_(type,l1l111_l1_ (u"ࠧࠨ䠍"),url,l1lll1l1111l_l1_,l1l111_l1_ (u"ࠨࠩ䠎"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠩࠪ䠏"),l1l111_l1_ (u"ࠪࠫ䠐"))
			menuItemsLIST[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
			l1l1l1ll11ll_l1_,l111l1ll11_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1ll11_l1_)
			if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䠑") in options: menuItemsLIST[:] = l1l1l1ll11ll_l1_+l111l1ll11_l1_[:l1l1lll11lll_l1_]
			else: menuItemsLIST[:] = l1l1l1ll11ll_l1_+l111l1ll11_l1_
		elif l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䠒") in options: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䠓"),l1l11l11_l1_,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	return
def l1l1ll11l1l1_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠔"),l1l111_l1_ (u"ࠨࠩ䠕")).replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䠖"),l1l111_l1_ (u"ࠪࠫ䠗"))
	name,l1l1ll111l1l_l1_ = l1l111_l1_ (u"ࠫࠬ䠘"),[]
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䠙"),l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䠚")+name+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ䠛"),l1l111_l1_ (u"ࠨࠩ䠜"),mode,l1l111_l1_ (u"ࠩࠪ䠝"),l1l111_l1_ (u"ࠪࠫ䠞"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠟")+options)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䠠"),l1l111_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅืู๊ࠦี๊สส๏࠭䠡"),l1l111_l1_ (u"ࠧࠨ䠢"),mode,l1l111_l1_ (u"ࠨࠩ䠣"),l1l111_l1_ (u"ࠩࠪ䠤"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠥")+options)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䠦"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䠧"),l1l111_l1_ (u"࠭ࠧ䠨"),9999)
	l1l1l1ll11ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䠩") in options:
		l1l1ll1l11l1_l1_(False)
		if contentsDICT=={}: return
		l1l1ll11ll11_l1_ = list(contentsDICT.keys())
		l1l1l1llllll_l1_ = random.sample(l1l1ll11ll11_l1_,1)[0]
		l1l1lll1lll1_l1_ = list(contentsDICT[l1l1l1llllll_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1lll1lll1_l1_,1)[0]
		type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1l1llllll_l1_][l1l11l11_l1_]
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䠪"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤࠬ䠫")+l1l11l11_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䠬")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䠭")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䠮")+str(l1lll1l1111l_l1_))
	elif l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䠯") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䠰"),True): return
		for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll111lll_l1_(str(l1l1ll1l1l11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䠱"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䠲")+name+l1l111_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䠳")+url+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䠴")+str(l1lll1l1111l_l1_))
	elif l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䠵") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䠶"),True): return
		for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll1l1ll1_l1_(str(l1l1ll1l1l11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䠷"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䠸")+name+l1l111_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䠹")+url+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䠺")+str(l1lll1l1111l_l1_))
	l1l1ll1lll1l_l1_ = name
	l1l1ll11llll_l1_ = []
	for i in range(0,10):
		if i>0: l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䠻"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䠼")+name+l1l111_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䠽")+url+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䠾")+str(l1lll1l1111l_l1_))
		menuItemsLIST[:] = []
		if l1lll1l1111l_l1_==234 and l1l111_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䠿") in text: l1lll1l1111l_l1_ = 233
		if l1lll1l1111l_l1_==714 and l1l111_l1_ (u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䡀") in text: l1lll1l1111l_l1_ = 713
		if l1lll1l1111l_l1_==144: l1lll1l1111l_l1_ = 291
		dummy = l1lll1111l11_l1_(type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		if l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䡁") in options and l1lll1l1111l_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䡂") in options and l1lll1l1111l_l1_==168: del menuItemsLIST[:3]
		l1l1ll111l1l_l1_[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
		if l1l1ll11llll_l1_ and l111lll111l_l1_(l1l111_l1_ (u"ࡺ࠭อๅไฬࠫ䡃")) in str(l1l1ll111l1l_l1_) or l111lll111l_l1_(l1l111_l1_ (u"ࡻࠧฮๆๅ๋ࠬ䡄")) in str(l1l1ll111l1l_l1_):
			name = l1l1ll1lll1l_l1_
			l1l1ll111l1l_l1_[:] = l1l1ll11llll_l1_
			break
		l1l1ll1lll1l_l1_ = name
		l1l1ll11llll_l1_ = l1l1ll111l1l_l1_
		if str(l1l1ll111l1l_l1_).count(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䡅"))>0: break
		if str(l1l1ll111l1l_l1_).count(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䡆"))>0: break
		if l1lll1l1111l_l1_==233: break
		if l1lll1l1111l_l1_==713: break
		if l1lll1l1111l_l1_==291: break
		if l1l1ll111l1l_l1_: type,name,url,l1lll1l1111l_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1l1ll111l1l_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠩ࠱࠲࠳࠴ࠧ䡇")
	elif name.count(l1l111_l1_ (u"ࠪࡣࠬ䡈"))>1: name = name.split(l1l111_l1_ (u"ࠫࡤ࠭䡉"),2)[2]
	name = name.replace(l1l111_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨ䡊"),l1l111_l1_ (u"࠭ࠧ䡋"))
	name = name.replace(l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䡌"),l1l111_l1_ (u"ࠨࠩ䡍"))
	l1l1l1ll11ll_l1_[0][1] = l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䡎")+name+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭䡏")
	for i in range(9): random.shuffle(l1l1ll111l1l_l1_)
	if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䡐") in options: menuItemsLIST[:] = l1l1l1ll11ll_l1_+l1l1ll111l1l_l1_[:l1l1lll11lll_l1_]
	else: menuItemsLIST[:] = l1l1l1ll11ll_l1_+l1l1ll111l1l_l1_
	return
def l1l1l1llll1l_l1_(l1l1l1l1llll_l1_,l1l1lll11ll1_l1_):
	l1l1lll11ll1_l1_ = l1l1lll11ll1_l1_.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡑"),l1l111_l1_ (u"࠭ࠧ䡒")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䡓"),l1l111_l1_ (u"ࠨࠩ䡔"))
	l1l1ll11l1ll_l1_ = l1l1lll11ll1_l1_
	if l1l111_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡕") in l1l1lll11ll1_l1_:
		l1l1ll11l1ll_l1_ = l1l1lll11ll1_l1_.split(l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡖"))[0]
		type = l1l111_l1_ (u"ࠫ࠱࡙ࡅࡓࡋࡈࡗ࠿ࠦࠧ䡗")
	elif l1l111_l1_ (u"ࠬ࡜ࡏࡅࠩ䡘") in l1l1l1l1llll_l1_: type = l1l111_l1_ (u"࠭ࠬࡗࡋࡇࡉࡔ࡙࠺ࠡࠩ䡙")
	elif l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䡚") in l1l1l1l1llll_l1_: type = l1l111_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ䡛")
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡜"),l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䡝")+type+l1l1ll11l1ll_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䡞"),l1l1l1l1llll_l1_,167,l1l111_l1_ (u"ࠬ࠭䡟"),l1l111_l1_ (u"࠭ࠧ䡠"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡡")+l1l1lll11ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䡢"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ䡣"),l1l1l1l1llll_l1_,167,l1l111_l1_ (u"ࠪࠫ䡤"),l1l111_l1_ (u"ࠫࠬ䡥"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡦")+l1l1lll11ll1_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䡧"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䡨"),l1l111_l1_ (u"ࠨࠩ䡩"),9999)
	import IPTV
	for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡪") in l1l1lll11ll1_l1_: IPTV.GROUPS(str(l1l1ll1l1l11_l1_),l1l1l1l1llll_l1_,l1l1lll11ll1_l1_,l1l111_l1_ (u"ࠪࠫ䡫"),False)
		else: IPTV.ITEMS(str(l1l1ll1l1l11_l1_),l1l1l1l1llll_l1_,l1l1lll11ll1_l1_,l1l111_l1_ (u"ࠫࠬ䡬"),False)
	menuItemsLIST[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lll11lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lll11lll_l1_)
	return
def l1l1l1ll11l1_l1_(l1l1l1l1llll_l1_,l1l1lll11ll1_l1_):
	l1l1lll11ll1_l1_ = l1l1lll11ll1_l1_.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡭"),l1l111_l1_ (u"࠭ࠧ䡮")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䡯"),l1l111_l1_ (u"ࠨࠩ䡰"))
	l1l1ll11l1ll_l1_ = l1l1lll11ll1_l1_
	if l1l111_l1_ (u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䡱") in l1l1lll11ll1_l1_:
		l1l1ll11l1ll_l1_ = l1l1lll11ll1_l1_.split(l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡲"))[0]
		type = l1l111_l1_ (u"ࠫ࠱࡙ࡅࡓࡋࡈࡗ࠿ࠦࠧ䡳")
	elif l1l111_l1_ (u"ࠬ࡜ࡏࡅࠩ䡴") in l1l1l1l1llll_l1_: type = l1l111_l1_ (u"࠭ࠬࡗࡋࡇࡉࡔ࡙࠺ࠡࠩ䡵")
	elif l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䡶") in l1l1l1l1llll_l1_: type = l1l111_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ䡷")
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡸"),l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䡹")+type+l1l1ll11l1ll_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䡺"),l1l1l1l1llll_l1_,168,l1l111_l1_ (u"ࠬ࠭䡻"),l1l111_l1_ (u"࠭ࠧ䡼"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡽")+l1l1lll11ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䡾"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ䡿"),l1l1l1l1llll_l1_,168,l1l111_l1_ (u"ࠪࠫ䢀"),l1l111_l1_ (u"ࠫࠬ䢁"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䢂")+l1l1lll11ll1_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䢃"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䢄"),l1l111_l1_ (u"ࠨࠩ䢅"),9999)
	import M3U
	for l1l1ll1l1l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䢆") in l1l1lll11ll1_l1_: M3U.GROUPS(str(l1l1ll1l1l11_l1_),l1l1l1l1llll_l1_,l1l1lll11ll1_l1_,l1l111_l1_ (u"ࠪࠫ䢇"),False)
		else: M3U.ITEMS(str(l1l1ll1l1l11_l1_),l1l1l1l1llll_l1_,l1l1lll11ll1_l1_,l1l111_l1_ (u"ࠫࠬ䢈"),False)
	menuItemsLIST[:] = l1l1ll11ll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lll11lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lll11lll_l1_)
	return
def l1l1ll11ll1l_l1_(menuItemsLIST):
	l1l1ll111l1l_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ࠬ฻แฮหࠪ䢉") in name or l1l111_l1_ (u"࠭ีโฯ๊ࠫ䢊") in name or l1l111_l1_ (u"ࠧࡱࡣࡪࡩࠬ䢋") in name.lower(): continue
		l1l1ll111l1l_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_])
	return l1l1ll111l1l_l1_
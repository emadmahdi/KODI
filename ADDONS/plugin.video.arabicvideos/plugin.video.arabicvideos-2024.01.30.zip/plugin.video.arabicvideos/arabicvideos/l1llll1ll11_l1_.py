# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ⦌")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⦍"):l1l111_l1_ (u"ࠬ࠭⦎")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡇࡊ࠴ࡣࠬ⦏")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧอ๊สสืࠦวๅล๋ื่อัࠨ⦐"),l1l111_l1_ (u"ࠨษ็้ึอฬฺษอࠫ⦑"),l1l111_l1_ (u"ࠩࡺࡻࡪ࠭⦒")]
def l11l1ll_l1_(mode,url,text):
	if   mode==570: l1lll_l1_ = l1l1l11_l1_()
	elif mode==571: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==572: l1lll_l1_ = PLAY(url)
	elif mode==573: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==576: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==579: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⦓"),l1lllll_l1_+l1l111_l1_ (u"้๋ࠫวัษࠣห้๋่ใ฻ࠣฬ฼๐มࠨ⦔"),l1l111_l1_ (u"ࠬ࠭⦕"),576)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⦖"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⦗"),l1l111_l1_ (u"ࠨࠩ⦘"),9999)
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⦙"),l111l1_l1_,l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ⦚"),l1l111_l1_ (u"ࠫๆอีๅࠢศ฽้อๆ๋ࠩ⦛"),l1l111_l1_ (u"ࠬࡪࡵࡣࡤࡨࡨ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ⦜"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⦝"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⦞"),l1l11ll_l1_,579,l1l111_l1_ (u"ࠨࠩ⦟"),l1l111_l1_ (u"ࠩࠪ⦠"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⦡"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⦢"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⦣"),l1l111_l1_ (u"࠭ࠧ⦤"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦥"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ⦦"),l1l11ll_l1_,571,l1l111_l1_ (u"ࠩࠪ⦧"),l1l111_l1_ (u"ࠪࠫ⦨"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⦩"))
	items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠳ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⦪"),html,re.DOTALL)
	if not items:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ⦫"),l1l111_l1_ (u"ࠧࠨ⦬"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬาࠠะ์ࠣ์ฬำฯࠨ⦭"),l1l111_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬ⦮"))
		return
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦯"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⦰")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⦱"),l1l111_l1_ (u"࠭ࠧ⦲"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠲ࠩ⦳"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡱࡴ࡬ࡱࡦࡸࡹࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⦴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࠦࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ⦵"),block,re.DOTALL)
		l1llll1l11l_l1_ = [l1l111_l1_ (u"ࠪࠫ⦶"),l1l111_l1_ (u"ࠫศ็ไศ็࠽ࠤࠬ⦷"),l1l111_l1_ (u"๋ࠬำๅี็หฯࡀࠠࠨ⦸"),l1l111_l1_ (u"࠭ศาษ่ะ࠿ࠦࠧ⦹"),l1l111_l1_ (u"ࠧรีํ์๏ࡀࠠࠨ⦺"),l1l111_l1_ (u"ࠨล้้๏ࡀࠠࠨ⦻")]
		l1l111llll_l1_ = 0
		for l1llll1llll_l1_ in l1llll1ll1l_l1_:
			if l1l111llll_l1_>0: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⦼"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⦽"),l1l111_l1_ (u"ࠫࠬ⦾"),9999)
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⦿"),l1llll1llll_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ⧀"): continue
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ⧁") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				if title==l1l111_l1_ (u"ࠨࠩ⧂"): continue
				if any(value in title.lower() for value in l11lll_l1_): continue
				title = l1llll1l11l_l1_[l1l111llll_l1_]+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⧃"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⧄")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠫࠬ⧅"),l1l111_l1_ (u"ࠬ࠭⧆"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨ⧇"))
			l1l111llll_l1_ += 1
	return
def l1llllll1l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ⧈"),l1l111_l1_ (u"ࠨࠩ⧉"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⧊"),l1l111_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠥฮื๋ร้๋ࠣࠦวๅ็ุำึࠦ࠮࠯ࠢหือฮࠠใ์ส้ࠥษีฮษหࠤฬ๊ๅ้ไ฼ࠤอหึศใฬࠤๆำี๊ࠡอั็่ࠠฤ็้๎ࠥ฼ฯ้ࠡฯ์๊ࠦวๅสิห๊า้้ࠠฯ์๊ࠦวๅไิหฺ์ษࠡ฻็ํࠥ฻แฮษอࠤฬ๊ๅ้ไ฼ࠤ࠳࠴้ࠠษ็์็ะࠠศๆูหห฿๋ࠠา๊ฬࠥ็๊ࠡ็ะหํ๊ษࠡฬฯหํุ่ࠠาสࠤฬ๊แฮืࠣ์ฬัศศฬࠣว๋ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡ็ฯีิࠦๅหืไั๊ࠥไๆ๊สๆ฾่ࠦๅษࠣ๎็๎ๅࠡสส่์า่ๆࠢ฼่๎ࠦวๅ็๋ห็฿ࠧ⧋"))
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ⧌")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⧍"),url,l1l111_l1_ (u"࠭ࠧ⧎"),l1l111_l1_ (u"ࠧࠨ⧏"),l1l111_l1_ (u"ࠨࠩ⧐"),l1l111_l1_ (u"ࠩࠪ⧑"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⧒"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࠺ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⧓"),html,re.DOTALL)
	if not l11ll11_l1_: return
	if type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⧔"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ⧕"),l1l111_l1_ (u"ࠧ࠰ࠩ⧖")).replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ⧗"),l1l111_l1_ (u"ࠩࠥࠫ⧘"))]
	elif type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⧙"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡮࡯࡮ࡧࡖࡰ࡮ࡪࡥࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⧚"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⧛"),block,re.DOTALL)
		l11ll1l11_l1_,l1ll_l1_,l11l11_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⧜"):
		title,block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⧝"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠴ࠪ⧞") and len(l11ll11_l1_)>1:
		title = l11ll11_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⧟"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠪࠫ⧠"),l1l111_l1_ (u"ࠫࠬ⧡"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨ⧢"))
		title = l11ll11_l1_[1][0]
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧣"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠧࠨ⧤"),l1l111_l1_ (u"ࠨࠩ⧥"),l1l111_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠶ࠫ⧦"))
		return
	else:
		title,block = l11ll11_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦ࡭࠷ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⧧"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
		l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠫࡄࡸࡥࡴ࡫ࡽࡩࡂ࠭⧨"))[0]
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⧩"),title,re.DOTALL)
		if l1l111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷ࠴࠭⧪") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧫"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠨࠩ⧬"):
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⧭")+l1l1lll_l1_[0][0]
			title = title.strip(l1l111_l1_ (u"ࠪࠤ⠘࠭⧮"))
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⧯"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⧰") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ⧱") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧࡩ࡫ࡱࡨ࡮࠵ࠧ⧲") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⧳"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⧴"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⧵"):
		l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ⧶"),block,re.DOTALL)
		if l111l1llll_l1_:
			count = l111l1llll_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ⧷")+count
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧸"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ⧹"),l1ll1ll_l1_,571,l1l111_l1_ (u"ࠨࠩ⧺"),l1l111_l1_ (u"ࠩࠪ⧻"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⧼"))
	elif l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷࠬ⧽") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࠨ⧾"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ⧿"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ࠧึใะอࠥ࠭⨀")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨁"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠩࠪ⨂"),l1l111_l1_ (u"ࠪࠫ⨃"),l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠹࠭⨄"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⨅")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⨆"),url,l1l111_l1_ (u"ࠧࠨ⨇"),l1l111_l1_ (u"ࠨࠩ⨈"),l1l111_l1_ (u"ࠩࠪ⨉"),l1l111_l1_ (u"ࠪࠫ⨊"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⨋"))
	html = response.content
	l111lllll1_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭⨌"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠤࡂࠦ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⨍"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ⨎"))
				l111lllll1_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,name,title in items:
					name = unescapeHTML(name)
					if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭⨏") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
					title = name+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭⨐")+title
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨑"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ⨒"),l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⨓"))
	if type==l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⨔") or not l111lllll1_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡲࡷࡹ࡫ࡲࡊ࡯ࡪࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⨕"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ⨖")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵࡇ࡬࡭ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⨗"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⨘"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⨙"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⨚"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l1ll_l1_,l1llll1lll1_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⨛"),url,l1l111_l1_ (u"ࠧࠨ⨜"),l1l111_l1_ (u"ࠨࠩ⨝"),l1l111_l1_ (u"ࠩࠪ⨞"),l1l111_l1_ (u"ࠪࠫ⨟"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⨠"))
	html = response.content
	l1llll1l111_l1_ = re.findall(l1l111_l1_ (u"๋ࠬำห๊์ࠤฬ๊ๅีษ๊ำฮ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⨡"),html,re.DOTALL)
	if l1llll1l111_l1_:
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡵࡣࡪࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⨢"),html,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡒࡰࡹࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⨣"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⨤"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩ࡭ࡲ࡭࠽ࠨ⨥"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ⨦"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸࡺࡲࡦࡣࡰࡌࡪࡧࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⨧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ⨨"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦࡪ࡯ࡪࡁࠬ⨩"))[0]
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ⨪"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⨫")+name+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⨬"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠫ࠲࠯ࡅࠩࡣ࡮ࡤࡧࡰࡽࡩ࡯ࡦࡲࡻࠬ⨭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⨮"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬࡩ࡮ࡩࡀࠫ⨯"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⨰")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⨱"))
	for l1llll1l1l1_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l1l1_l1_.split(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤࠨ⨲"))
		if l1ll1ll_l1_ not in l1llll1l1ll_l1_:
			l1llll1l1ll_l1_.append(l1ll1ll_l1_)
			l1llll1lll1_l1_.append(l1llll1l1l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1lll1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⨳"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⨴"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⨵"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⨶"),l1l111_l1_ (u"࠭ࠫࠨ⨷"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⨸")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⨹"),url,l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ⨺"),l1l111_l1_ (u"ࠪๅฬ฻ไࠡว฼่ฬ์๊ࠨ⨻"),l1l111_l1_ (u"ࠫࡩࡻࡢࡣࡧࡧ࠱ࡲࡵࡶࡪࡧࡶࠫ⨼"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠻ࠧ⨽"))
	return
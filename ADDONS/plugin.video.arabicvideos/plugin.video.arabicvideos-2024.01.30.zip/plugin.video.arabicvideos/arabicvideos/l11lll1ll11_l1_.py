# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ夐")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ夑")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1l11l1ll_l1_()
	elif mode==56: l1lll_l1_ = l11l1l111ll1_l1_()
	elif mode==57: l1lll_l1_ = l111ll11l1_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll11l1_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ夒"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ夓"),l1l111_l1_ (u"ࠬ࠭夔"),59,l1l111_l1_ (u"࠭ࠧ夕"),l1l111_l1_ (u"ࠧࠨ外"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ夗"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ夘"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ夙"),l1l111_l1_ (u"ࠫࠬ多"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ夛"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ夜")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ夝"),l1l111_l1_ (u"ࠨࠩ夞"),56)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ够"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ夠")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วโๆส้ࠬ夡"),l1l111_l1_ (u"ࠬ࠭夢"),55)
	return l1l111_l1_ (u"࠭ࠧ夣")
def l11l1l11l1ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ夤"),l1lllll_l1_+l1l111_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ夥"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ夦"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ大"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ夨"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ天"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭太"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ夫"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ夬"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ夭"),l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ央"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ夯"),51)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ夰"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ失"),l1l111_l1_ (u"ࠧࠨ夲"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夳"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭头"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ夵"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夶"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ夷"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ夸"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ夹"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ夺"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ夻"),57)
	return
def l11l1l111ll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ夼"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ夽"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ夾"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夿"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ奀"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ奁"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奂"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ奃"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ奄"),51)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奅"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ奆"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ奇"),51)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭奈"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ奉"),l1l111_l1_ (u"ࠪࠫ奊"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奋"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ奌"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭奍"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奎"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ奏"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ奐"),57)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ契"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ奒"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ奓"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"࠭࠿ࠨ奔") in url:
		parts = url.split(l1l111_l1_ (u"ࠧࡀࠩ奕"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠨࡁࠪ奖") + QUOTE(parts[1],l1l111_l1_ (u"ࠩࡀࠪ࠿࠵ࠥࠨ套"))
	else: filter = l1l111_l1_ (u"ࠪࠫ奘")
	parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭奙"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠬࡿ࡯ࡱࠩ奚"),l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭奛"),l1l111_l1_ (u"ࠧࡷ࡫ࡨࡻࡸ࠭奜")]:
		if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ奝"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠩไ๎้๋ࠧ奞")
		elif type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ奟"): l1l1l1lll_l1_=l1l111_l1_ (u"ู๊ࠫไิๆࠪ奠")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭奡") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"࠭࠯ࠨ奢") + l1llllll1_l1_ + l1l111_l1_ (u"ࠧ࠰ࠩ奣") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ奤"),l1l111_l1_ (u"ࠩࠪ奥"),l1l111_l1_ (u"ࠪࠫ奦"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ奧"))
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡱࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡶࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡳࡶࡪࡹࡢࡢࡵࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奨"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,title,l11l1l111l1l_l1_,l1ll1l_l1_ in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1ll1l1lll1_l1_ + l1l111_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ奩") + l1ll1l_l1_ + l1l111_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ奪")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ奫") + id
			if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ奬"): addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ奭"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ奮"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奯"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ࠥ࠭奰")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ奱")+l11l1l111l1l_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ奲")+title+l1l111_l1_ (u"ࠩࡀࠫ女")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ奴"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ奵")
		elif type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ奶"): l1l1l1lll_l1_=l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭奷")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ奸") + sort + l1l111_l1_ (u"ࠨ࠯ࠪ她") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ奺")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ奻"),l1l111_l1_ (u"ࠫࠬ奼"),l1l111_l1_ (u"ࠬ࠭好"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ奾"))
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ奿"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,l11l1l111l1l_l1_,l1ll1l_l1_,title in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ妀") + l1ll1l_l1_ + l1l111_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ妁")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭如") + id
			if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ妃"): addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ妄"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭妅"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妆"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊ࠠࠨ妇")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡩࡵࡃࠧ妈")+l11l1l111l1l_l1_+l1l111_l1_ (u"ࠪࡁࠬ妉")+title+l1l111_l1_ (u"ࠫࡂ࠭妊")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ妋")
	if l1ll1l111ll_l1_==16:
		for l1ll1l1llll_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ妌")+type+l1l111_l1_ (u"ࠧ࠰ࠩ妍")+str(l1ll1l1llll_l1_)+l1l111_l1_ (u"ࠨ࠱ࠪ妎")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妏"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠪࡁࠬ妐"))
	l11l1l111l1l_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ妑"),l1l111_l1_ (u"ࠬ࠭妒"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"࠭࠿ࠨ妓"))[0]
	if l11l1l111l1l_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ妔"),l1l111_l1_ (u"ࠨࠩ妕"),l1l111_l1_ (u"ࠩࠪ妖"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ妗"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬ妘"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ妙"),block,re.DOTALL)
		l11l1l111l1l_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l1l111l1l_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"࠭࠿ࡦࡲࡀࠫ妚") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ妛")+name+l1l111_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ妜")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ妝"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ妞"),l1l111_l1_ (u"ࠫࠬ妟"),l1l111_l1_ (u"ࠬ࠭妠"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ妡"))
	l11l1l111lll_l1_ = re.findall(l1l111_l1_ (u"ࠧๆฬ๋ๅึูࠦๅุ๋ࠣํ็ࠠๆษๆืࠥฮูะ࠰࠭ࡃࡲࡵ࡭ࡦࡰࡷࡠ࠭ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妢"),html,re.DOTALL)
	if l11l1l111lll_l1_:
		time = l11l1l111lll_l1_[1].replace(l1l111_l1_ (u"ࠨࡖࠪ妣"),l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ妤"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ妥"),l1l111_l1_ (u"ࠫࠬ妦"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ妧"),l1l111_l1_ (u"࠭็ัษࠣห้็๊ะ์๋ࠤุ๐ใ้่้ࠣฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำࠥํะศࠢส่ํ่สࠨ妨")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ妩")+time)
		return
	l11l1l1111ll_l1_,l11l1l11l11l_l1_ = [],[]
	l11l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妪"),html,re.DOTALL)[0]
	l11l1l11l111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡢࡢࡥ࡮ࡹࡵࡥ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妫"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡱࡹ࠺ࠡࠪ࠱࠮ࡄ࠯࡟࡭࡫ࡱ࡯ࡡ࠱ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妬"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ妭") in server:
			server = l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ妮")
			url = l11l1l11l111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ妯")
			url = l11l1l11l1l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭妰") in url:
			l11l1l1111ll_l1_.append(url)
			l11l1l11l11l_l1_.append(l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠠࠨ妱")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ妲"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ妳"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭妴"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ妵"),l1l111_l1_ (u"࠭ࠧ妶"))
		filename = filename.replace(l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ妷"),l1l111_l1_ (u"ࠨࠩ妸"))
		filename = filename.replace(l1l111_l1_ (u"ࠩ࠰ࠫ妹"),l1l111_l1_ (u"ࠪࠫ妺"))
		if l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ妻") in server:
			server = l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ妼")
			url = l11l1l11l111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ妽")
			url = l11l1l11l1l1_l1_ + l1ll1ll_l1_
		l11l1l1111ll_l1_.append(url)
		l11l1l11l11l_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭妾")+server+l1l111_l1_ (u"ࠨࠢࠣࠫ妿")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ姀"), l11l1l11l11l_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l1l1111ll_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ姁"))
	return
def l111ll11l1_l1_(url,type):
	if l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ姂") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴๋ำๅี็ࠫ姃")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵แ๋ๆ่ࠫ姄")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ姅"),l1l111_l1_ (u"ࠨࠩ姆"),l1l111_l1_ (u"ࠩࠪ姇"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡌࡉࡍࡖࡈࡖࡘ࠳࠱ࡴࡶࠪ姈"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡻࡢࡨࡧࡱࡶࡪ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ姉"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ姊"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳ࠭始"),block,re.DOTALL)
	if type==1:
		for l11l1l111l11_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ姌"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠨࡁࡶࡹࡧ࡭ࡥ࡯ࡴࡨࡁࠬ姍")+l11l1l111l11_l1_,58)
	elif type==2:
		url,l11l1l111l11_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࠫ姎"))
		for l1llll1l11l1_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姏"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠫࡄࡩ࡯ࡶࡰࡷࡶࡾࡃࠧ姐")+l1llll1l11l1_l1_+l1l111_l1_ (u"ࠬࠬࠧ姑")+l11l1l111l11_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"࠭ࠠࠨ姒"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ姓"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ委")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭姕"),url,l1l111_l1_ (u"ࠪࠫ姖"),l1l111_l1_ (u"ࠫࠬ姗"),True,l1l111_l1_ (u"ࠬ࠭姘"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ姙"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡨࡧࡱࡩࡷࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡷࡪࡧࡲࡤࡪ࠰ࡦࡴࡺࡴࡰ࡯࠰ࡴࡦࡪࡤࡪࡰࡪࠫ姚"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ姛"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ姜") in url:
				if l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ姝") in url:
					title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ姞")+title
					url = url.replace(l1l111_l1_ (u"ࠬࡅࡥࡱ࠿࠴ࠫ姟"),l1l111_l1_ (u"࠭࠿ࡦࡲࡀ࠴ࠬ姠"))
					url = url+l1l111_l1_ (u"ࠧ࠾ࠩ姡")+QUOTE(title)+l1l111_l1_ (u"ࠨ࠿ࠪ姢")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姣"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠใํ่๊ࠦࠧ姤")+title
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姥"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
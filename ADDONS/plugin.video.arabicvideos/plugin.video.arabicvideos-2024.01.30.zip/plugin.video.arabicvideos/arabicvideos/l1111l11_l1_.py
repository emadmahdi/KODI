# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩஅ")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧஆ"):l1l111_l1_ (u"ࠫࠬஇ")}
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫஈ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==10: l1lll_l1_ = l1l1l11_l1_()
	elif mode==11: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==12: l1lll_l1_ = PLAY(url)
	elif mode==13: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==14: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==15: l1lll_l1_ = l111111l_l1_()
	elif mode==16: l1lll_l1_ = l11111l1_l1_()
	elif mode==19: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭உ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧஊ"),l1l111_l1_ (u"ࠨࠩ஋"),19,l1l111_l1_ (u"ࠩࠪ஌"),l1l111_l1_ (u"ࠪࠫ஍"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨஎ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪஏ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨஐ"),l1l111_l1_ (u"ࠧࠨ஑"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨஒ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫஓ")+l1lllll_l1_+l1l111_l1_ (u"ࠪฦำืࠠศๆศฺฬ็วหࠩஔ"),l1l111_l1_ (u"ࠫࠬக"),14)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ஖"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ஗")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠧ஘"),l1l111_l1_ (u"ࠨࠩங"),15)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪச"),headers,l1l111_l1_ (u"ࠪࠫ஛"),l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ஜ"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡱࡥࡻ࠳ࡳ࡭࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ஝"),html,re.DOTALL)
	l1111lll_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨஞ"),l1111lll_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩட"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஠"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ஡")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ஢"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ண"),l1l111_l1_ (u"ࠬ࠭த"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡲࡦࡼࡢࡢࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ஥"),html,re.DOTALL)
	l1l1l1l_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ஦"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஧"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫந")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	return html
def l111111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪன"),l1lllll_l1_+l1l111_l1_ (u"ࠫัฺ๋๊ࠢสู่๊ไิๆสฮࠥอไฺำห๎ฮ࠭ப"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠱࠽࠵ๅิๆึ่ฬะฺ࠭ำห๎ฮ࠭஫"),11)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭஬"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡษ็ื๋ฯࠠศๆฦา๏ืษࠨ஭"),l1l111_l1_ (u"ࠨࠩம"),16)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩய"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣห้ษฮ๋ำฬࠤ࠶࠭ர"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡦࡹ࠰࠼࠴๋ำๅี็หฯ࠳ัๆุส๊࠲࠸࠰࠳࠴ࠪற"),11)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬல"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦวๅลั๎ึฯࠠ࠳ࠩள"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠳࠸࠰็ึุ่๊วห࠯ิ้฻อๆ࠮࠴࠳࠶࠸࠭ழ"),11)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨவ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠷࠹ࠧஶ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠲࠴࠱ู่ึ๐ษࠨஷ"),11)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫஸ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠳࠴ࠪஹ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠵࠶࠴๋ีา์ฬࠫ஺"),11)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஻"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠶࠶࠭஼"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠸࠱࠰็ุี๏ฯࠧ஽"),11)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪா"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠲࠱ࠩி"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠴࠳࠳๊฻ั๋หࠪீ"),11)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ு"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠴࠽ࠬூ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠶࠿࠯ๆืิ๎ฮ࠭௃"),11)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ௄"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠷࠸ࠨ௅"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠲࠺࠲ฺ้ื๊สࠩெ"),11)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬே"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠳࠺ࠫை"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠵࠼࠵ๅึำํอࠬ௉"),11)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨொ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠶࠼ࠧோ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠱࠷࠱ู่ึ๐ษࠨௌ"),11)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"்ࠫࠬ"),headers,True,l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ௎"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡨࡦࡣࡧ࡭ࡳ࡭࠭ࡵࡱࡳࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠬ௏"),html,re.DOTALL)
	block = l11llll_l1_[0]+l11llll_l1_[1]
	items=re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩௐ"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ௑") in url: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ௒"),l1lllll_l1_+title,url,11,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ௓"),l1lllll_l1_+title,url,12,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ௔"),url,l1l111_l1_ (u"ࠬ࠭௕"),headers,True,True,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ௖"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹࠩ࠰࠭ࡃ࠮ࡸࡩࡨࡪࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠬௗ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	found = False
	items = re.findall(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡣࡱࡻ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௘"),block,re.DOTALL)
	l1l1_l1_,l11111ll_l1_ = [],[]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if title==l1l111_l1_ (u"ࠩࠪ௙"): title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ௚"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭௛"),l1l111_l1_ (u"ࠬࠦࠧ௜"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࡝ࡦ࠮࠭ࠬ௝"),title,re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = int(l1111ll1_l1_[0])
		else: l1111ll1_l1_ = 0
		l11111ll_l1_.append([l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_])
	l11111ll_l1_ = sorted(l11111ll_l1_, reverse=True, key=lambda key: key[3])
	for l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_ in l11111ll_l1_:
		l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
		title = title.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠠๆี็ื้࠭௞"),l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ௟"))
		title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢสู่๊ไิๆࠪ௠"),l1l111_l1_ (u"ࠪห้๋ำๅี็ࠫ௡"))
		title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤๆ๐ไๆࠩ௢"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ௣"))
		title = title.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦวๅใํ่๊࠭௤"),l1l111_l1_ (u"ࠧศๆไ๎้๋ࠧ௥"))
		title = title.replace(l1l111_l1_ (u"ࠨ็หหูืษࠡๅ๋ห้๐ส๋ࠩ௦"),l1l111_l1_ (u"ࠩࠪ௧"))
		title = title.replace(l1l111_l1_ (u"ࠪ฽ฬ๊๊สࠢ฼่๎ࠦวๅ฻ิฬࠬ௨"),l1l111_l1_ (u"ࠫࠬ௩"))
		title = title.replace(l1l111_l1_ (u"๋ࠬิศ้าอ๋ࠥศศึิอࠬ௪"),l1l111_l1_ (u"࠭ࠧ௫"))
		title = title.replace(l1l111_l1_ (u"ࠧศ๊้ࠤ้อ๊็ࠩ௬"),l1l111_l1_ (u"ࠨࠩ௭"))
		title = title.replace(l1l111_l1_ (u"ࠩส์๋๊ว๋่ࠪ௮"),l1l111_l1_ (u"ࠪࠫ௯"))
		title = title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣ฽ฬ๊๊สࠩ௰"),l1l111_l1_ (u"ࠬ࠭௱"))
		title = title.replace(l1l111_l1_ (u"࠭ฬ้ัฬࠤ฾อไ๋หࠪ௲"),l1l111_l1_ (u"ࠧࠨ௳"))
		title = title.replace(l1l111_l1_ (u"ࠨสา์๋ࠦสฮ็ํ่ࠬ௴"),l1l111_l1_ (u"ࠩࠪ௵"))
		title = title.replace(l1l111_l1_ (u"ࠪ฽้๏ࠠศๆ฼ีอ࠭௶"),l1l111_l1_ (u"ࠫࠬ௷"))
		title = title.replace(l1l111_l1_ (u"๋ࠬศศึิอࠬ௸"),l1l111_l1_ (u"࠭ࠧ௹"))
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ௺")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ௻"),l1l111_l1_ (u"ࠩࠣࠫ௼")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭௽"),l1l111_l1_ (u"ࠫࠥ࠭௾"))
		title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ௿")+title
		l1lllllll_l1_ = title
		if l1l111_l1_ (u"࠭࠯ࡲ࠱ࠪఀ") in url and (l1l111_l1_ (u"ࠧศๆะ่็ฯࠧఁ") in title or l1l111_l1_ (u"ࠨษ็ั้่็ࠨం") in title):
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬః"),title,re.DOTALL)
			if l1l1lll_l1_: l1lllllll_l1_ = l1l1lll_l1_[0]
		if l1lllllll_l1_ not in l1l1_l1_:
			l1l1_l1_.append(l1lllllll_l1_)
			if l1l111_l1_ (u"ࠪ࠳ࡶ࠵ࠧఄ") in url and (l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫఅ") in title or l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬఆ") in title):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ఇ"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,13,l1ll1l_l1_)
				found = True
			elif l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧఈ") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨఉ"),l1lllll_l1_+title,l1ll1ll_l1_,11,l1ll1l_l1_)
				found = True
			else:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨఊ"),l1lllll_l1_+title,l1ll1ll_l1_,12,l1ll1l_l1_)
				found = True
	if found:
		items = re.findall(l1l111_l1_ (u"ࠪࡸࡸࡩ࡟࠴ࡦࡢࡦࡺࡺࡴࡰࡰࠣࡶࡪࡪ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఋ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1llllll1_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఌ"),l1lllll_l1_+l1llllll1_l1_,url,11)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭఍"),headers,True,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬఎ"))
	l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠰ࡵࡨࡶ࡮࡫ࡳ࠯ࠬࡂ࠭ࠧ࠭ఏ"),html,re.DOTALL)
	l1lllll1_l1_ = l111l1_l1_+l1111l1l_l1_[0]
	l1lll_l1_ = l1lll11_l1_(l1lllll1_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩఐ"),headers,True,l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ఑"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡹࡰ࠮࡫ࡩࡶࡦࡳࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧఒ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡣ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠧࠫఓ"),l1lllll1_l1_,re.DOTALL)
		if l1ll_l1_:
			first = l1ll_l1_[0][0]
			second,l111l111_l1_ = l1ll_l1_[0][1].rsplit(l1l111_l1_ (u"ࠬ࠵ࠧఔ"),1)
			l1llllll_l1_ = second+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧక")
			l1llll_l1_.append(l1llllll_l1_)
			l1111111_l1_ = first+l111l111_l1_
		else:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨఖ"),headers,False,l1l111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪగ"))
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡷࡩࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪఘ"),l11l1ll1_l1_,re.DOTALL)
			if l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳ࠳ࡶ࠺ࠪఙ")
				l1llll_l1_.append(l1lllll1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡆࡴࡾࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬచ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫఛ"),block,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧజ")
			l1llll_l1_.append(l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ఝ"),url)
	return
def l11111l1_l1_():
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩఞ"),headers,True,l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡕࡅࡒࡇࡄࡂࡐ࠰࠵ࡸࡺࠧట"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡴࡠࡵࡨࡧࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢ࡭ࡧࡩࡸࡤࡩ࡯࡯ࡶࡨࡲࡹࠨࠧఠ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭డ"),block,re.DOTALL)
	year = re.findall(l1l111_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴࠨ࡜࠲࠰࠽ࡢ࠱ࠩ࠰ࠩఢ"),str(items),re.DOTALL)
	year = year[0]
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨణ"))+l1l111_l1_ (u"ࠧࠡࠩత")+year
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨథ"),l1lllll_l1_+title,url,11)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪద"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫధ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭న"),l1l111_l1_ (u"ࠬ࠱ࠧ఩"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠯ࡲ࠱ࠥప") + l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
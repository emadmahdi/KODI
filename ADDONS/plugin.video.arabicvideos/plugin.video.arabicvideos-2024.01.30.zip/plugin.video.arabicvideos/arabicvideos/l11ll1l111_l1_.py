# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫᶧ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡊࡒ࠸ࡡࠪᶨ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧᶩ"),l1l111_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧᶪ"),l1l111_l1_ (u"ࠧหีฯ๎้࠭ᶫ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==680: l1lll_l1_ = l1l1l11_l1_()
	elif mode==681: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==682: l1lll_l1_ = PLAY(url)
	elif mode==683: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==684: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==689: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᶬ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪᶭ"),l1l111_l1_ (u"ࠪࠫᶮ"),l1l111_l1_ (u"ࠫࠬᶯ"),l1l111_l1_ (u"ࠬ࠭ᶰ"),l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᶱ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶲ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᶳ"),l1l111_l1_ (u"ࠩࠪᶴ"),689,l1l111_l1_ (u"ࠪࠫᶵ"),l1l111_l1_ (u"ࠫࠬᶶ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶷ"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᶸ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᶹ"),l1l111_l1_ (u"ࠨࠩᶺ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᶻ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᶼ")+l1lllll_l1_+l1l111_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪᶽ"),l111l1_l1_,681,l1l111_l1_ (u"ࠬ࠭ᶾ"),l1l111_l1_ (u"࠭ࠧᶿ"),l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭᷀"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷁"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ᷂ࠫ")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧ᷃"),l111l1_l1_,681,l1l111_l1_ (u"ࠫࠬ᷄"),l1l111_l1_ (u"ࠬ࠭᷅"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ᷆"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᷇"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᷈"),l1l111_l1_ (u"ࠩࠪ᷉"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨ᷊ࠧ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ᷋"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭᷌"))
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᷍"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ᷎ࠧ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡ᷏ࠪ")+l1lllll_l1_+title,l1ll1ll_l1_,684)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ᷐࡙࠭"),url,l1l111_l1_ (u"ࠪࠫ᷑"),l1l111_l1_ (u"ࠫࠬ᷒"),l1l111_l1_ (u"ࠬ࠭ᷓ"),l1l111_l1_ (u"࠭ࠧᷔ"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᷕ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᷖ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪᷗ"),l1l111_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩᷘ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᷙ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠬ࠭ᷚ"),block)]
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᷛ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᷜ"),l1l111_l1_ (u"ࠨࠩᷝ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᷞ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠪ࠾ࠥ࠭ᷟ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᷠ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᷡ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᷢ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᷣ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᷤ"),l1l111_l1_ (u"ࠩࠪᷥ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᷦ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠫࠬᷧ")):
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᷨ"):
		url,search = url.split(l1l111_l1_ (u"࠭࠿ࠨᷩ"),1)
		data = l1l111_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ᷪ")+search
		headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᷫ"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᷬ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᷭ"),url,data,headers,l1l111_l1_ (u"ࠫࠬᷮ"),l1l111_l1_ (u"ࠬ࠭ᷯ"),l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᷰ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᷱ"),url,l1l111_l1_ (u"ࠨࠩᷲ"),l1l111_l1_ (u"ࠩࠪᷳ"),l1l111_l1_ (u"ࠪࠫᷴ"),l1l111_l1_ (u"ࠫࠬ᷵"),l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ᷶"))
	html = response.content
	block,items = l1l111_l1_ (u"᷷࠭ࠧ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯᷸ࠫ"))
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭᷹࠭"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ᷺ࠫ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠪࠫ᷻"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭᷼"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ᷽࠭"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ᷾"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ᷿ࠧ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬḀ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩḁ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬḂ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ḃ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧḄ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧḅ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨḆ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩḇ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩḈ"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨḉ"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪḊ"),l1l111_l1_ (u"้ࠬไ๋สࠪḋ"),l1l111_l1_ (u"࠭วฺๆส๊ࠬḌ"),l1l111_l1_ (u"่ࠧัสๅࠬḍ"),l1l111_l1_ (u"ࠨ็หหึอษࠨḎ"),l1l111_l1_ (u"ࠩ฼ี฻࠭ḏ"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪḐ"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪḑ"),l1l111_l1_ (u"๋ࠬำาฯํอࠬḒ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩḓ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ḕ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧḕ"):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨḖ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩḗ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḘ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḙ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧḚ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬḛ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪḜ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫḝ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬḞ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḟ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫḠ")+title,l1ll1ll_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪḡ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫḢ"),url,l1l111_l1_ (u"ࠨࠩḣ"),l1l111_l1_ (u"ࠩࠪḤ"),l1l111_l1_ (u"ࠪࠫḥ"),l1l111_l1_ (u"ࠫࠬḦ"),l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬḧ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩḨ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḩ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩḪ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩḫ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠪࠧࠬḬ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḭ"),l1lllll_l1_+title,url,683,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭Ḯ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࠫḯ")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬḰ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢḱ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨḲ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬḳ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭Ḵ"))
			title = title.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪḵ"),l1l111_l1_ (u"࠭ࠠࠨḶ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ḷ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l11ll11lll_l1_ = [],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫḸ"),l1l111_l1_ (u"ࠩࡳࡰࡦࡿ࠮ࡱࡪࡳࠫḹ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧḺ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬḻ"),l1l111_l1_ (u"ࠬ࠭Ḽ"),l1l111_l1_ (u"࠭ࠧḽ"),l1l111_l1_ (u"ࠧࠨḾ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫḿ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪṀ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫṁ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩṂ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ṃ")+server+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧṄ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ṅ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l11ll11lll_l1_:
			l11ll11lll_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭Ṇ"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪṇ")+server+l1l111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫṈ")
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨṉ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩṊ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫṋ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨṌ")+server+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬṍ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨṎ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫṏ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬṐ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧṑ"),l1l111_l1_ (u"࠭ࠫࠨṒ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨṓ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨṔ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࠫ⮢")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡈࡎࡖࡣࠬ⮣")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1lll_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll11l1l1_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮤"),l1l111_l1_ (u"ࠨสะฯࠥาฯ๋ัࠪ⮥"),l1l111_l1_ (u"ࠩࠪ⮦"),549)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⮧"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࠤ่๊ๅศฬ้ࠣำุๆสࠢࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⮨"),l1l111_l1_ (u"ࠬ࠭⮩"),9999)
	l1lll1l11ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ⮪"),l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮫"))
	if l1lll1l11ll_l1_:
		l1lll1l11ll_l1_ = l1lll1l11ll_l1_[l1l111_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ⮬")]
		for search in reversed(l1lll1l11ll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮭"),search,l1l111_l1_ (u"ࠪࠫ⮮"),549,l1l111_l1_ (u"ࠫࠬ⮯"),l1l111_l1_ (u"ࠬ࠭⮰"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111ll11l_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"࠭ࠧ⮱"))
	l1lll1111l1_l1_(l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⮲"),l1l111_l1_ (u"ࠨ฻่่ࠥฮอฬࠢฯ้ฬ฿๊ࠡ࠯ࠣࠫ⮳")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⮴"),542,l1l111_l1_ (u"ࠪࠫ⮵"),l1l111_l1_ (u"ࠫࠬ⮶"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⮷"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⮸"),l1l111_l1_ (u"ࠧࠨ⮹"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮺"),l1l111_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆใุ่ฮࠦ࠭ࠡࠩ⮻")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮼"),542,l1l111_l1_ (u"ࠫࠬ⮽"),l1l111_l1_ (u"ࠬ࠭⮾"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⮿"),l1l111_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥโิ็ฬࠤ࠲ࠦࠧ⯀")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⯁"),542,l1l111_l1_ (u"ࠩࠪ⯂"),l1l111_l1_ (u"ࠪࠫ⯃"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯄"),l1l111_l1_ (u"ࠬฮอฬ่๊ࠢๆืฯࠡ࠯ࠣࠫ⯅")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⯆"),541,l1l111_l1_ (u"ࠧࠨ⯇"),l1l111_l1_ (u"ࠨࠩ⯈"),l1111ll11l_l1_)
	return
def l1lll1111l1_l1_(l1lll1lll1l_l1_):
	l1lll1lllll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⯉"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⯊"),l1lll1lll1l_l1_)
	l1lll1llll1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⯋"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⯌"),l1lllll_l1_+l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯍"),l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⯎"),l1lllll_l1_+l1lll1lll1l_l1_)
	old_value = l1lll1lllll_l1_+l1lll1llll1_l1_
	if old_value: l1lll1lll1l_l1_ = l1lllll_l1_+l1lll1lll1l_l1_
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⯏"),l1lll1lll1l_l1_,old_value,l1lll11lll1_l1_)
	return
def l1lll111ll1_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ⯐"),l1l111_l1_ (u"ࠪࠫ⯑"),l1l111_l1_ (u"ࠫࠬ⯒"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⯓"),l1l111_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪ⯔"))
	if l1llll111l_l1_!=1: return
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⯕"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⯖"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨ⯗"))
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ⯘"),l1l111_l1_ (u"ࠫࠬ⯙"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⯚"),l1l111_l1_ (u"࠭สๆࠢห๊ัออࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠧ⯛"))
	return
def l1lll11l1l1_l1_(l1lll111lll_l1_,action,l1lll11ll1l_l1_=l1l111_l1_ (u"ࠧࠨ⯜")):
	l1lll11llll_l1_,l1lll1l1111_l1_,l1lll1l1l11_l1_,l1ll1lll1ll_l1_,l1ll1lllll1_l1_,l1ll1llll1l_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⯝"):
		if action==l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯞"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯟"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⯠"),l1lllll_l1_+l1lll111lll_l1_)
		elif action==l1l111_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⯡"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ⯢"),l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⯣"),l1lll111lll_l1_)
		elif action==l1l111_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⯤"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⯥"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⯦"),(l1lll11ll1l_l1_,l1lll111lll_l1_))
	if not l1lll1l1l11_l1_:
		l1lll1ll111_l1_ = l1l111_l1_ (u"ࠫ์ึวࠡษ็ฬาัࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰ࡟ࡲࠬ⯧")
		l1lll1ll11l_l1_ = l1l111_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤฬ๊ศฮอࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥ฿ๆࠡ࡞ࡱࠤࠧࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡࠩ⯨")+l1lll111lll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠣࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊ศฮอࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠨ⯩")
		if action==l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⯪"): message = l1lll1ll11l_l1_
		else: message = l1lll1ll111_l1_+l1lll1ll11l_l1_
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࠩ⯫"),l1l111_l1_ (u"ࠩࠪ⯬"),l1l111_l1_ (u"ࠪࠫ⯭"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⯮"),message)
		if l1llll111l_l1_!=1: return
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⯯"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪ⯰")+l1lll111lll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ⯱"))
		l1llll11l11_l1_ = 1
		for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
			l1ll1lll1ll_l1_[l1lll11ll1l_l1_] = []
			options = l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭⯲")
			if l1l111_l1_ (u"ࠩ࠰ࠫ⯳") in l1lll11ll1l_l1_: options = options+l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ⯴")+l1lll11ll1l_l1_+l1l111_l1_ (u"ࠫࡤ࠭⯵")
			l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
			if l1llll11l11_l1_:
				time.sleep(0.5)
				threads[l1lll11ll1l_l1_] = threading.Thread(target=l1lll11ll11_l1_,args=(l1lll111lll_l1_+options,))
				threads[l1lll11ll1l_l1_].start()
			else: l1lll11ll11_l1_(l1lll111lll_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11ll1l_l1_),l1l111_l1_ (u"ࠬ࠭⯶"),time=1000)
		if l1llll11l11_l1_:
			time.sleep(2)
			for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
				threads[l1lll11ll1l_l1_].join(10)
			time.sleep(2)
		for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
			l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
			for l1lll11l11l_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
				if l1llll111ll_l1_ in name:
					if l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࠬ⯷") in l1lll11ll1l_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ⯸")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⯹")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯺")]: continue
						if l1l111_l1_ (u"ูࠪๆำษࠨ⯻") not in name:
							if   type==l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⯼"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯽")
							elif type==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⯾"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⯿")
							elif type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰀ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧⰁ")
						else:
							if   l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨⰂ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧⰃ")
							elif l1l111_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬⰄ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫⰅ")
							elif l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧⰆ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭Ⰷ")
					elif l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࠧⰈ") in l1lll11ll1l_l1_ and 729>=mode>=710:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬⰉ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰊ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩⰋ")]: continue
						if l1l111_l1_ (u"࠭ีโฯฬࠫⰌ") not in name:
							if   type==l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬⰍ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪⰎ")
							elif type==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⰏ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰐ")
							elif type==l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰑ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩⰒ")
						else:
							if   l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠫⰓ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩⰔ")
							elif l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨⰕ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭Ⱆ")
							elif l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪⰗ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨⰘ")
					elif l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࠧⰙ") in l1lll11ll1l_l1_ and 149>=mode>=140:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩⰚ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫⰛ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩⰜ")]: continue
						if l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬⰝ") in name or l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧⰞ") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩⰟ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨⰠ")
							elif mode==144 and l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫⰡ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪⰢ")
							elif mode==144 and l1l111_l1_ (u"ࠨࡎࡌࡗ࡙࠭Ⱓ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭Ⱔ")
							elif mode==143: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫⰥ")
							else: continue
					elif l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࠪⰦ") in l1lll11ll1l_l1_ and 419>=mode>=400:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭Ⱗ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭Ⱘ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬⰩ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭Ⱚ")]: continue
						if   mode in [401,405]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪⰫ")
						elif mode in [402,406]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪⰬ")
						elif mode in [403,404]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩⰭ")
						elif mode in [412,413]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪⰮ")
					elif l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࠭Ⱟ") in l1lll11ll1l_l1_ and 39>=mode>=30:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭ⰰ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰱ")]: continue
						if   mode in [32,39]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨⰲ")
						elif mode in [33,39]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩⰳ")
					elif l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࠫⰴ") in l1lll11ll1l_l1_ and 29>=mode>=20:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫⰵ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ⰶ")]: continue
						if   l1l111_l1_ (u"ࠧ࠰ࡣࡵ࠲ࠬⰷ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧⰸ")
						elif l1l111_l1_ (u"ࠩ࠲ࡩࡳ࠴ࠧⰹ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪⰺ")
					l1ll1lll1ll_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
		menuItemsLIST[:] = []
		for l1lll11ll1l_l1_ in list(l1ll1lll1ll_l1_.keys()):
			l1ll1lllll1_l1_[l1lll11ll1l_l1_] = []
			l1ll1llll1l_l1_[l1lll11ll1l_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1ll1lll1ll_l1_[l1lll11ll1l_l1_]:
				l1lll11l11l_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
				if l1l111_l1_ (u"ฺࠫ็อสࠩⰻ") in name and type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰼ"): l1ll1llll1l_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
				else: l1ll1lllll1_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
		l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰽ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰾ"),l1l111_l1_ (u"ࠨࠩⰿ"),157,l1l111_l1_ (u"ࠩࠪⱀ"),l1l111_l1_ (u"ࠪࠫⱁ"),l1l111_l1_ (u"ࠫࠬⱂ"),l1l111_l1_ (u"ࠬ࠭ⱃ"),l1l111_l1_ (u"࠭ࠧⱄ"))]
		for l1lll11ll1l_l1_ in l1lll1l111l_l1_:
			if l1lll11ll1l_l1_==l1lll111l1l_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⱅ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⱆ"),l1l111_l1_ (u"ࠩࠪⱇ"),157,l1l111_l1_ (u"ࠪࠫⱈ"),l1l111_l1_ (u"ࠫࠬⱉ"),l1l111_l1_ (u"ࠬ࠭ⱊ"),l1l111_l1_ (u"࠭ࠧⱋ"),l1l111_l1_ (u"ࠧࠨⱌ"))]
			elif l1lll11ll1l_l1_==l1llll11111_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⱍ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⱎ"),l1l111_l1_ (u"ࠪࠫⱏ"),157,l1l111_l1_ (u"ࠫࠬⱐ"),l1l111_l1_ (u"ࠬ࠭ⱑ"),l1l111_l1_ (u"࠭ࠧⱒ"),l1l111_l1_ (u"ࠧࠨⱓ"),l1l111_l1_ (u"ࠨࠩⱔ"))]
			elif l1lll11ll1l_l1_==l1ll1llll11_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱕ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⱖ"),l1l111_l1_ (u"ࠫࠬⱗ"),157,l1l111_l1_ (u"ࠬ࠭ⱘ"),l1l111_l1_ (u"࠭ࠧⱙ"),l1l111_l1_ (u"ࠧࠨⱚ"),l1l111_l1_ (u"ࠨࠩⱛ"),l1l111_l1_ (u"ࠩࠪⱜ"))]
			if l1lll11ll1l_l1_ not in l1ll1lllll1_l1_.keys(): continue
			if l1ll1lllll1_l1_[l1lll11ll1l_l1_]:
				l1lll11111l_l1_ = TRANSLATE(l1lll11ll1l_l1_)
				l1lll11l111_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱝ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭ⱞ")+l1lll11111l_l1_+l1l111_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⱟ"),l1l111_l1_ (u"࠭ࠧⱠ"),9999,l1l111_l1_ (u"ࠧࠨⱡ"),l1l111_l1_ (u"ࠨࠩⱢ"),l1l111_l1_ (u"ࠩࠪⱣ"),l1l111_l1_ (u"ࠪࠫⱤ"),l1l111_l1_ (u"ࠫࠬⱥ"))]
				if 0:
					l1llll1111l_l1_ = l1lll111lll_l1_+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩⱦ")+l1l111_l1_ (u"࠭ศฮอࠪⱧ")+l1l111_l1_ (u"ࠧࠡࠩⱨ")+l1lll11111l_l1_
				else:
					l1llll1111l_l1_ = l1l111_l1_ (u"ࠨสะฯࠬⱩ")+l1l111_l1_ (u"ࠩࠣࠫⱪ")+l1lll11111l_l1_+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⱫ")+l1lll111lll_l1_
				if len(l1ll1lllll1_l1_[l1lll11ll1l_l1_])<8: l1lll1l1l1l_l1_ = []
				else:
					l1llll111l1_l1_ = l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧⱬ")+l1llll1111l_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱭ")
					l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ɱ"),l1lllll_l1_+l1llll111l1_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ɐ"),542,l1l111_l1_ (u"ࠨࠩⱰ"),l1lll11ll1l_l1_,l1lll111lll_l1_,l1l111_l1_ (u"ࠩࠪⱱ"),l1l111_l1_ (u"ࠪࠫⱲ"))]
				l1lll1ll1ll_l1_ = l1ll1lllll1_l1_[l1lll11ll1l_l1_]+l1ll1llll1l_l1_[l1lll11ll1l_l1_]
				l1lll1l1111_l1_ += l1lll1l1ll1_l1_+l1lll11l111_l1_+l1lll1ll1ll_l1_[:7]+l1lll1l1l1l_l1_
				l1lll111111_l1_ = [(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱳ"),l1lllll_l1_+l1llll1111l_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⱴ"),542,l1l111_l1_ (u"࠭ࠧⱵ"),l1lll11ll1l_l1_,l1lll111lll_l1_,l1l111_l1_ (u"ࠧࠨⱶ"),l1l111_l1_ (u"ࠨࠩⱷ"))]
				l1lll11llll_l1_ += l1lll1l1ll1_l1_+l1lll111111_l1_
				l1lll1l1ll1_l1_ = []
				l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⱸ"),(l1lll11ll1l_l1_,l1lll111lll_l1_),l1lll1ll1ll_l1_,l1lll11lll1_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩⱹ"),l1lll111lll_l1_,l1lll1l1111_l1_,l1lll11lll1_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩⱺ"),l1lll111lll_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱻ"),l1lllll_l1_+l1lll111lll_l1_,l1lll11llll_l1_,l1lll11lll1_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧⱼ"),l1l111_l1_ (u"ࠧࠨⱽ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⱾ"),l1l111_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬⱿ"))
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⲀ") and l1lll11llll_l1_: l1lll1l1l11_l1_ = l1lll11llll_l1_
		else: l1lll1l1l11_l1_ = l1lll1l1111_l1_
	if action!=l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪⲁ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll1l1l11_l1_:
			if action in [l1l111_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⲂ"),l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬⲃ")] and l1l111_l1_ (u"ࠧึใะอࠬⲄ") in name and type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲅ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	return
def l1lll1l1lll_l1_(l1lll111lll_l1_=l1l111_l1_ (u"ࠩࠪⲆ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111lll_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪⲇ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨⲈ")+search+l1l111_l1_ (u"ࠬࠦ࡝ࠨⲉ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1lll11_l1_,l1111ll11l_l1_ = search+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪⲊ"),l1l111_l1_ (u"ࠧࠨⲋ")
	else: l1lll1lll11_l1_,l1111ll11l_l1_ = l1l111_l1_ (u"ࠨࠩⲌ"),l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ⲍ")+search
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⲎ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⲏ"),l1l111_l1_ (u"ࠬ࠭Ⲑ"),157)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭Ⲓ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯࠥࡓ࠳ࡖࠩⲓ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⲔ"),719,l1l111_l1_ (u"ࠪࠫⲕ"),l1l111_l1_ (u"ࠫࠬⲖ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲗ"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬⲘ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤࡎࡖࡔࡗࠩⲙ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⲚ"),239,l1l111_l1_ (u"ࠩࠪⲛ"),l1l111_l1_ (u"ࠪࠫⲜ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲝ"),l1l111_l1_ (u"ࠬࡥࡂࡌࡔࡢࠫⲞ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสๆีฬ࠭ⲟ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⲠ"),379,l1l111_l1_ (u"ࠨࠩⲡ"),l1l111_l1_ (u"ࠩࠪⲢ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲣ"),l1l111_l1_ (u"ࠫࡤࡑࡌࡂࡡࠪⲤ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠไๆࠣห้฿ัษࠩⲥ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⲦ"),19,l1l111_l1_ (u"ࠧࠨⲧ"),l1l111_l1_ (u"ࠨࠩⲨ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲩ"),l1l111_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩⲪ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪⲫ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭Ⲭ"),739,l1l111_l1_ (u"࠭ࠧⲭ"),l1l111_l1_ (u"ࠧࠨⲮ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲯ"),l1l111_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨⲰ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪⲱ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⲲ"),329,l1l111_l1_ (u"ࠬ࠭ⲳ"),l1l111_l1_ (u"࠭ࠧⲴ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲵ"),l1l111_l1_ (u"ࠨࡡࡉࡌ࠶ࡥࠧⲶ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨⲷ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⲸ"),579,l1l111_l1_ (u"ࠫࠬⲹ"),l1l111_l1_ (u"ࠬ࠭Ⲻ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲻ"),l1l111_l1_ (u"ࠧࡠࡍࡗ࡚ࡤ࠭Ⲽ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧⲽ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⲾ"),819,l1l111_l1_ (u"ࠪࠫⲿ"),l1l111_l1_ (u"ࠫࠬⳀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳁ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠴ࡣࠬⳂ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠷ࠧⳃ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⳄ"),779,l1l111_l1_ (u"ࠩࠪⳅ"),l1l111_l1_ (u"ࠪࠫⳆ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳇ"),l1l111_l1_ (u"ࠬࡥࡅࡃ࠴ࡢࠫⳈ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭ⳉ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⳊ"),789,l1l111_l1_ (u"ࠨࠩⳋ"),l1l111_l1_ (u"ࠩࠪⳌ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳍ"),l1l111_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪⳎ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬࠦࠠษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨⳏ")+l1111ll11l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩⳐ"),l1l111_l1_ (u"ࠧࠨⳑ"),29,l1l111_l1_ (u"ࠨࠩⳒ"),l1l111_l1_ (u"ࠩࠪⳓ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳔ"),l1l111_l1_ (u"ࠫࡤࡇࡋࡐࡡࠪⳕ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅไา๎๊࠭Ⳗ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⳗ"),79,l1l111_l1_ (u"ࠧࠨⳘ"),l1l111_l1_ (u"ࠨࠩⳙ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳚ"),l1l111_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩⳛ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬⳜ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⳝ"),249,l1l111_l1_ (u"࠭ࠧⳞ"),l1l111_l1_ (u"ࠧࠨⳟ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳠ"),l1l111_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨⳡ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫⳢ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⳣ"),49,l1l111_l1_ (u"ࠬ࠭ⳤ"),l1l111_l1_ (u"࠭ࠧ⳥"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳦"),l1l111_l1_ (u"ࠨࡡࡖࡌࡒࡥࠧ⳧")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭⳨")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫ⳩"),59,l1l111_l1_ (u"ࠫࠬ⳪"),l1l111_l1_ (u"ࠬ࠭Ⳬ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳬ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⳭ"),l1l111_l1_ (u"ࠨࠩⳮ"),157)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳯"),l1l111_l1_ (u"ࠪࡣࡋࡐࡓࡠࠩ⳰")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫࠥฮอฬ่ࠢ์็฿ࠠโฮิࠤู๎ࠧ⳱")+l1111ll11l_l1_+l1l111_l1_ (u"ࠬࠦࠧⳲ"),l1l111_l1_ (u"࠭ࠧⳳ"),399,l1l111_l1_ (u"ࠧࠨ⳴"),l1l111_l1_ (u"ࠨࠩ⳵"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),l1l111_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ⳷")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ⳸")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭⳹"),469,l1l111_l1_ (u"࠭ࠧ⳺"),l1l111_l1_ (u"ࠧࠨ⳻"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳼"),l1l111_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨ⳽")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭⳾")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⳿"),459,l1l111_l1_ (u"ࠬ࠭ⴀ"),l1l111_l1_ (u"࠭ࠧⴁ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴂ"),l1l111_l1_ (u"ࠨࡡࡆࡑࡓࡥࠧⴃ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭ⴄ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⴅ"),309,l1l111_l1_ (u"ࠫࠬⴆ"),l1l111_l1_ (u"ࠬ࠭ⴇ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴈ"),l1l111_l1_ (u"ࠧࡠ࡙ࡆࡑࡤ࠭ⴉ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ์๏ࠦำ๋็สࠫⴊ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⴋ"),569,l1l111_l1_ (u"ࠪࠫⴌ"),l1l111_l1_ (u"ࠫࠬⴍ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴎ"),l1l111_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬⴏ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢืห์ีࠠ็์๋ึࠬⴐ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴑ"),589,l1l111_l1_ (u"ࠩࠪⴒ"),l1l111_l1_ (u"ࠪࠫⴓ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩⴔ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),l1l111_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬⴖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦำ๋์าࠫⴗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴘ"),259,l1l111_l1_ (u"ࠩࠪⴙ"),l1l111_l1_ (u"ࠪࠫⴚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴛ"),l1l111_l1_ (u"ࠬࡥࡃࡄࡄࡢࠫⴜ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫⴝ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴞ"),829,l1l111_l1_ (u"ࠨࠩⴟ"),l1l111_l1_ (u"ࠩࠪⴠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴡ"),l1l111_l1_ (u"ࠫࡤ࡙ࡈ࠵ࡡࠪⴢ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫⴣ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⴤ"),119,l1l111_l1_ (u"ࠧࠨⴥ"),l1l111_l1_ (u"ࠨࠩ⴦"),l1lll1ll_l1_+l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧⴧ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l1l111_l1_ (u"ࠫࡤ࡙ࡈࡕࡡࠪ⴩")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ⴪")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⴫"),649,l1l111_l1_ (u"ࠧࠨ⴬"),l1l111_l1_ (u"ࠨࠩⴭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l1l111_l1_ (u"ࠪࡣࡊࡈ࠳ࡠࠩ⴯")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫⴰ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⴱ"),799,l1l111_l1_ (u"࠭ࠧⴲ"),l1l111_l1_ (u"ࠧࠨⴳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴴ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⴵ"),l1l111_l1_ (u"ࠪࠫⴶ"),157)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴷ"),l1l111_l1_ (u"ࠬࡥࡆࡔࡖࡢࠫⴸ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใ๋ืฯอࠧⴹ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴺ"),609,l1l111_l1_ (u"ࠨࠩⴻ"),l1l111_l1_ (u"ࠩࠪⴼ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴽ"),l1l111_l1_ (u"ࠫࡤࡌࡂࡌࡡࠪⴾ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโสิ็ฮ࠭ⴿ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⵀ"),629,l1l111_l1_ (u"ࠧࠨⵁ"),l1l111_l1_ (u"ࠨࠩⵂ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵃ"),l1l111_l1_ (u"ࠪࡣ࡞ࡗࡔࡠࠩⵄ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊ࠦศไ๋ฮࠬⵅ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⵆ"),669,l1l111_l1_ (u"࠭ࠧⵇ"),l1l111_l1_ (u"ࠧࠨⵈ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵉ"),l1l111_l1_ (u"ࠩࡢࡆࡗ࡙࡟ࠨⵊ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥฮัิฬํะࠬⵋ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⵌ"),659,l1l111_l1_ (u"ࠬ࠭ⵍ"),l1l111_l1_ (u"࠭ࠧⵎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵏ"),l1l111_l1_ (u"ࠨࡡࡋࡐࡈࡥࠧⵐ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ⵑ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⵒ"),89,l1l111_l1_ (u"ࠫࠬⵓ"),l1l111_l1_ (u"ࠬ࠭ⵔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵕ"),l1l111_l1_ (u"ࠧࡠࡆࡕ࠻ࡤ࠭ⵖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำึอๅศุࠢัࠬⵗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⵘ"),689,l1l111_l1_ (u"ࠪࠫⵙ"),l1l111_l1_ (u"ࠫࠬⵚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵛ"),l1l111_l1_ (u"࠭࡟ࡄࡏࡉࡣࠬⵜ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠโษ้ึࠬⵝ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⵞ"),99,l1l111_l1_ (u"ࠩࠪⵟ"),l1l111_l1_ (u"ࠪࠫⵠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵡ"),l1l111_l1_ (u"ࠬࡥࡃࡎࡎࡢࠫⵢ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦไศ์อࠫⵣ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⵤ"),479,l1l111_l1_ (u"ࠨࠩⵥ"),l1l111_l1_ (u"ࠩࠪⵦ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵧ"),l1l111_l1_ (u"ࠫࡤࡇࡂࡅࡡࠪ⵨")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪ⵩")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⵪"),559,l1l111_l1_ (u"ࠧࠨ⵫"),l1l111_l1_ (u"ࠨࠩ⵬"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵭"),l1l111_l1_ (u"ࠪࡣࡈ࠺ࡈࡠࠩ⵮")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨⵯ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭⵰"),699,l1l111_l1_ (u"࠭ࠧ⵱"),l1l111_l1_ (u"ࠧࠨ⵲"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵳"),l1l111_l1_ (u"ࠩࡢࡅࡍࡑ࡟ࠨ⵴")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩ⵵")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⵶"),619,l1l111_l1_ (u"ࠬ࠭⵷"),l1l111_l1_ (u"࠭ࠧ⵸"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⵹"),l1l111_l1_ (u"ࠨࡡࡈࡆ࠹ࡥࠧ⵺")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩ⵻")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫ⵼"),809,l1l111_l1_ (u"ࠫࠬ⵽"),l1l111_l1_ (u"ࠬ࠭⵾"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ⵿࠭"),l1l111_l1_ (u"ࠧࡠࡅࡆ࡛ࡤ࠭ⶀ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪⶁ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⶂ"),639,l1l111_l1_ (u"ࠪࠫⶃ"),l1l111_l1_ (u"ࠫࠬⶄ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⶅ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⶆ"),l1l111_l1_ (u"ࠧࠨⶇ"),157)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶈ"),l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨⶉ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬⶊ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⶋ"),149,l1l111_l1_ (u"ࠬ࠭ⶌ"),l1l111_l1_ (u"࠭ࠧⶍ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶎ"),l1l111_l1_ (u"ࠨࡡࡇࡐࡒࡥࠧⶏ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧⶐ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⶑ"),409,l1l111_l1_ (u"ࠫࠬⶒ"),l1l111_l1_ (u"ࠬ࠭ⶓ"),l1lll1ll_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll1l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡉࡏࡋࡗࠫ搶")
l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ搷"),l1l111_l1_ (u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨ搸"))
l1lll11l11l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
l1lll1l11111_l1_ = int(mode)
l1lllll11111_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ搹"))
l1lllll11111_l1_ = l1lllll11111_l1_.replace(ltr,l1l111_l1_ (u"ࠪࠫ携")).replace(rtl,l1l111_l1_ (u"ࠫࠬ搻"))
if l1lll1l11111_l1_==260: message = l1l111_l1_ (u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭搼")+l1l11l111l1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭搽")+l1l1l11l11l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ搾")
else:
	l111llll1ll1_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ搿"),l1l111_l1_ (u"ࠩࠪ摀")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭摁"),l1l111_l1_ (u"ࠫࠬ摂"))
	l111llll1ll1_l1_ = l111llll1ll1_l1_.replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ摃"),l1l111_l1_ (u"࠭ࠧ摄")).strip(l1l111_l1_ (u"ࠧࠡࠩ摅"))
	l111llll1ll1_l1_ = l111llll1ll1_l1_.replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭摆"),l1l111_l1_ (u"ࠩࠣࠫ摇")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ摈"),l1l111_l1_ (u"ࠫࠥ࠭摉")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ摊"),l1l111_l1_ (u"࠭ࠠࠨ摋"))
	message = l1l111_l1_ (u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭摌")+l1lllll11111_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨ摍")+mode+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ摎")+l111llll1ll1_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭摏")
l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ摐"),l11lllll1l_l1_(l1ll1_l1_)+message)
l1lll11l111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ摑"))
l111l1ll1l1_l1_ = False if l1lll11l111l_l1_==l1l11l111l1_l1_ else True
if not l111l1ll1l1_l1_ and l1lll1l11111_l1_ in [235,715]:
	l1l1ll1l1l11_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭摒")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ摓") if l1lll1l11111_l1_==235 else l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ摔")
	l11ll1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࠭摕")+l1ll1_l1_+l1l111_l1_ (u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ摖")+l1l1ll1l1l11_l1_)
	l11lll1lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࠨ摗")+l1ll1_l1_+l1l111_l1_ (u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨ摘")+l1l1ll1l1l11_l1_)
	if l11ll1l1ll_l1_ or l11lll1lll_l1_:
		url += l1l111_l1_ (u"࠭ࡼࠨ摙")
		if l11ll1l1ll_l1_: url += l1l111_l1_ (u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭摚")+l11ll1l1ll_l1_
		if l11lll1lll_l1_: url += l1l111_l1_ (u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ摛")+l11lll1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠩࡿࠪࠬ摜"),l1l111_l1_ (u"ࠪࢀࠬ摝"))
	l11l11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࠨ摞")+l1ll1_l1_+l1l111_l1_ (u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ摟")+l1l1ll1l1l11_l1_)
	if l11l11ll1l_l1_:
		l111llll1lll_l1_ = re.findall(l1l111_l1_ (u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩ摠"),url,re.DOTALL)
		url = url.replace(l111llll1lll_l1_[0],l11l11ll1l_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll11lll1_l1_,l1111l1l1ll_l1_,l1lll1l1lll1_l1_
	l111l11ll11_l1_ = l1l111_l1_ (u"ࠧࠨ摡")
	l11ll11lll1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ摢"))
	try: l1111l1l1ll_l1_(l1lll11l11l_l1_,l1lllll11111_l1_)
	except Exception as error: l111l11ll11_l1_ = traceback.format_exc()
	l1lll1l1lll1_l1_(l111l11ll11_l1_)
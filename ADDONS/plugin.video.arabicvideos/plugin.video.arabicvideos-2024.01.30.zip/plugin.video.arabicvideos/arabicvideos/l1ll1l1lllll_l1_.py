# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ姦")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ姧")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠧ姨"),l1l111_l1_ (u"ࠨสฮࠤ๊ฮวีำࠪ姩")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭姪"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ姫"),l1l111_l1_ (u"ࠫࠬ姬"),l1l111_l1_ (u"ࠬ࠭姭"),l1l111_l1_ (u"࠭ࠧ姮"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ姯"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姰"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠲ࠫ姱"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ姲"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姳"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ姴"),l1l11ll_l1_,489,l1l111_l1_ (u"࠭ࠧ姵"),l1l111_l1_ (u"ࠧࠨ姶"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ姷"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ姸"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ姹"),l1l111_l1_ (u"ࠫࠬ姺"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ姻"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ姼")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤฯาฯࠥอไๆ๊สฺ๏฿ࠧ姽"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࠧࡳࡹࡂࡥࡦࡳࡺࡴࡴࠣࠩ姾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ姿"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ娀"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ威"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ娂")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l11l1l111111_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ娃"),url,l1l111_l1_ (u"ࠧࠨ娄"),l1l111_l1_ (u"ࠨࠩ娅"),l1l111_l1_ (u"ࠩࠪ娆"),l1l111_l1_ (u"ࠪࠫ娇"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ娈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡰࡵࡷࠬ࠳࠰࠿ࠪࠤࡩࡳࡴࡺࡥࡳࠤࠪ娉"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ娊"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ娋"),l1l111_l1_ (u"ࠨใํ่๊࠭娌"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ娍"),l1l111_l1_ (u"ࠪว฿์๊สࠩ娎"),l1l111_l1_ (u"่๊๊ࠫษࠩ娏"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ娐"),l1l111_l1_ (u"࠭็ะษไࠫ娑"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ娒"),l1l111_l1_ (u"ࠨ฻ิฺࠬ娓"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ娔"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ娕"),l1l111_l1_ (u"ู๊ࠫัฮ์ฬࠫ娖")]
	l11l1l11111l_l1_ = l1l111_l1_ (u"ࠬ࠵ࠧ娗").join(l11l1l111111_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ娘")).split(l1l111_l1_ (u"ࠧ࠰ࠩ娙"))[4:]).split(l1l111_l1_ (u"ࠨ࠯ࠪ娚"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ娛"),title,re.DOTALL)
		if l11l1l111111_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ娜").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭娝")).split(l1l111_l1_ (u"ࠬ࠵ࠧ娞"))[4:]).split(l1l111_l1_ (u"࠭࠭ࠨ娟"))
			l11l1l1111l1_l1_ = len([x for x in l11l1l11111l_l1_ if x in l111lllll_l1_])
			if l11l1l1111l1_l1_>2 and l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ娠") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ娡"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ娢"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ุ้๊ࠪำๅࠩ娣") not in title:
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ娤"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬำไใหࠪ娥") in title:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ娦") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ娧"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ娨"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娩"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ娪"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ娫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ娬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ娭"),l1l111_l1_ (u"ࠧࠨ娮"))
			if title!=l1l111_l1_ (u"ࠨࠩ娯"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娰"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ娱")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠫࠬ娲"),l1l111_l1_ (u"ࠬ࠭娳"),l11l1l111111_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ娴"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ娵")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ娶"),url,l1l111_l1_ (u"ࠩࠪ娷"),headers,l1l111_l1_ (u"ࠪࠫ娸"),l1l111_l1_ (u"ࠫࠬ娹"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭娺"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ娻"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ娼"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ娽"))
	l11l11llllll_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡰ࡮ࡹࡴࡔࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ娾"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ娿") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠨ婀"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠫ婁"))
		if count>1:
			l11l11llllll_l1_ = False
			if l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠫ婂") in block:
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ婃"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠵࠲ࡵ࡮ࡰࡀࡵ࡯ࡹ࡬ࡃࠧ婄")+id
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婅"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭婆"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠴ࡰࡩࡲࡂࡷࡪࡸࡩࡦࡵࡌࡈࡂ࠭婇")+id
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婈"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l11l11llllll_l1_:
		block = l1l111_l1_ (u"࠭ࠧ婉")
		if l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ婊") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡴࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭婋"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ婌"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ婍"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ婎"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ婏"))+l1l111_l1_ (u"࠭࠯ࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ婐")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ婑"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ婒"),l1l111_l1_ (u"ࠩࠪ婓"),l1l111_l1_ (u"ࠪࠫ婔"),l1l111_l1_ (u"ࠫࠬ婕"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ婖"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ婗"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡱࡢࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭婘"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ婙"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ婚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ婛"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭婜"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡩࡧࡴࡤࡱࡪ࠸࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ婝")+l11111l11_l1_+l1l111_l1_ (u"࠭ࠦࡷ࡫ࡧࡩࡴࡃࠧ婞")+l111111ll_l1_[2:]+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ婟")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ婠")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡫ࡪࡺࡅ࡮ࡤࡨࡨࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭婡"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠪࡹࡷࡲࠧ婢"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ婣")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭婤")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ婥"))+l1l111_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ婦")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ婧"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ婨"),l1l111_l1_ (u"ࠪࠫ婩"),l1l111_l1_ (u"ࠫࠬ婪"),l1l111_l1_ (u"ࠬ࠭婫"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ婬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡶࡤࡦࡱ࡫࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ婭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ婮"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ婯"))
			if l1l111_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ婰") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠫࡤࡥฮศืࠪ婱")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠬ࠭婲")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ婳")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ婴")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婵"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠩࠪ婶")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ婷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ婸"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ婹"),l1l111_l1_ (u"࠭ࠫࠨ婺"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠧࠨ婻"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ婼")+search+l1l111_l1_ (u"ࠩ࠲ࠫ婽")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࠫ婾"))
	return
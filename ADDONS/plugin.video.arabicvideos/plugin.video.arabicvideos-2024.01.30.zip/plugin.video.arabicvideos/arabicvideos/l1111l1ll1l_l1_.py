# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ媅")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ媆")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬฮหࠡ็หหูืࠧ媇")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ媈"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ媉"),l1l111_l1_ (u"ࠨࠩ媊"),l1l111_l1_ (u"ࠩࠪ媋"),l1l111_l1_ (u"ࠪࠫ媌"),l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ媍"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媎"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭媏"),l1l111_l1_ (u"ࠧࠨ媐"),469,l1l111_l1_ (u"ࠨࠩ媑"),l1l111_l1_ (u"ࠩࠪ媒"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ媓"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ媔"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ媕"),l1l111_l1_ (u"࠭ࠧ媖"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡨࡲࡺ࠳ࡢࡵࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ媗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ媘"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ媙") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ媚"): title = l1l111_l1_ (u"ࠫัี๊ะࠢะ่็อสࠡฬํๅ๏ࠦแศ่ࠪ媛")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媜"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ媝")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨ媞")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ媟"),url,l1l111_l1_ (u"ࠩࠪ媠"),l1l111_l1_ (u"ࠪࠫ媡"),l1l111_l1_ (u"ࠫࠬ媢"),l1l111_l1_ (u"ࠬ࠭媣"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ媤"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ媥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ媦"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ媧"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ媨"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ媩"),l1l111_l1_ (u"้ࠬไ๋สࠪ媪"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ媫"),l1l111_l1_ (u"่ࠧัสๅࠬ媬"),l1l111_l1_ (u"ࠨ็หหึอษࠨ媭"),l1l111_l1_ (u"ࠩ฼ี฻࠭媮"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ媯"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ媰")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ媱") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ媲"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭媳"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨษ็ั้่ษࠨ媴") in title:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ媵") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媶"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媷"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ媸"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ媹"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ媺"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ媻"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠤࠥ媼"): continue
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ媽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠫࠬ媾"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媿"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ嫀")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嫁"),url,l1l111_l1_ (u"ࠨࠩ嫂"),l1l111_l1_ (u"ࠩࠪ嫃"),l1l111_l1_ (u"ࠪࠫ嫄"),l1l111_l1_ (u"ࠫࠬ嫅"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ嫆"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭嫇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嫈"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭嫉") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嫊"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ嫋"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嫌"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ嫍"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢ嫎"): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫏") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠨࠩ嫐"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫑"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ嫒")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嫓"),url,l1l111_l1_ (u"ࠬ࠭嫔"),l1l111_l1_ (u"࠭ࠧ嫕"),l1l111_l1_ (u"ࠧࠨ嫖"),l1l111_l1_ (u"ࠨࠩ嫗"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ嫘"))
	html = response.content
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ嫙"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = l11l1l11l1_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嫚") not in l11l1l11l1_l1_:
			if l1l111_l1_ (u"ࠬ࠵࠯ࠨ嫛") in l11l1l11l1_l1_: l11l1l11l1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ嫜")+l11l1l11l1_l1_
			else: l11l1l11l1_l1_ = l111l1_l1_+l11l1l11l1_l1_
		l11l1l11l1_l1_ = l11l1l11l1_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ嫝")
		l1llll_l1_.append(l11l1l11l1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ嫞"),html,re.DOTALL)
	if l11llll_l1_:
		l11l11llll11_l1_,l11l11llll1l_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ嫟"),l11l11llll11_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ嫠"),l11l11llll1l_l1_,re.DOTALL)
		l11l11lll1ll_l1_ = zip(names,l1ll_l1_)
		for name,l11lllllllll_l1_ in l11l11lll1ll_l1_:
			l11lllllllll_l1_ = l11lllllllll_l1_[2:]
			if PY2: l11lllllllll_l1_ = l11lllllllll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嫡"))
			l11lllllllll_l1_ = base64.b64decode(l11lllllllll_l1_)
			if PY3: l11lllllllll_l1_ = l11lllllllll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ嫢"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嫣"),l11lllllllll_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫤") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠨ࠱࠲ࠫ嫥") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ嫦")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ嫧")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ嫨")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嫩"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"࠭ࠠࠨ嫪") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ嫫"),l1l111_l1_ (u"ࠨࠩ嫬"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ嫭"),l1l111_l1_ (u"่้ࠪษำโࠢส่อำหࠡใํࠤ์ึวࠡษ็้ํู่ࠡๆสࠤ๏฿ๅๅࠢ฼๊ิࠦืๅสࠣว่ััࠡ็้ࠤ่๊ๅส๋ࠢหาีษࠡ࠰࠱࠲ࠥ๐ัอ๋ࠣห้ฮอฬࠢ฼๊้ࠥไๆหࠣ์ฬำฯสࠢไๆ฼࠭嫮"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡷ࠯ࠨ嫯")+search+l1l111_l1_ (u"ࠬ࠵ࠧ嫰")
	l1lll11_l1_(url)
	return
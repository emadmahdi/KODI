# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ垚")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬ垛")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ垜"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1l11llll_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垝"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ垞"),l1l111_l1_ (u"ࠪࠫ垟"),319,l1l111_l1_ (u"ࠫࠬ垠"),l1l111_l1_ (u"ࠬ࠭垡"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ垢"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ垣"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ垤"),l1l111_l1_ (u"ࠩࠪ垥"),l1l111_l1_ (u"ࠪࠫ垦"),l1l111_l1_ (u"ࠫࠬ垧"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ垨"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡪࡴࡵ࡭࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ垩"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ垪"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ垫"),l1l111_l1_ (u"ࠩࠪ垬"),9999)
	items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠻࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠷ࡁࠫ垭"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠫࠥ࠭垮"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垯"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ垰")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠧࠨ垱"),l1l111_l1_ (u"ࠨࠩ垲"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垳"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ垴")+l1lllll_l1_+l1l111_l1_ (u"๊่ࠫวุ฻ุࠣ์ืࠧ垵"),l111l1_l1_,314,l1l111_l1_ (u"ࠬ࠭垶"),l1l111_l1_ (u"࠭ࠧ垷"),l1l111_l1_ (u"ࠧ࠱ࠩ垸"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭垹"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ垺"),l1l111_l1_ (u"ࠪࠫ垻"),9999)
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡂ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡄࡁࠫ垼"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垽")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垾"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ垿")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ埀"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ埁"),l1l111_l1_ (u"ࠪࠫ埂"),l1l111_l1_ (u"ࠫࠬ埃"),l1l111_l1_ (u"ࠬ࠭埄"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭埅"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠧ࠱ࠩ埆"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭埇"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埈"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埉")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭埊"))
			name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ埋"))
			title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ埌")+name+l1l111_l1_ (u"ࠧࠪࠩ埍")
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ城"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠩ࠴ࠫ埏"),l1l111_l1_ (u"ࠪ࠶ࠬ埐"),l1l111_l1_ (u"ࠫ࠸࠭埑")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ埒"),html,re.DOTALL)
		l11l1l1l1111_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1l1l1111_l1_]
		if seq==l1l111_l1_ (u"࠭࠱ࠨ埓"): items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ埔"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埕"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埖")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埗")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭埘"))
			name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ埙"))
			title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ埚")+name+l1l111_l1_ (u"ࠧࠪࠩ埛")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ埜"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠩ࠷ࠫ埝"),l1l111_l1_ (u"ࠪ࠹ࠬ埞"),l1l111_l1_ (u"ࠫ࠻࠭域")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ埠"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埡"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11ll1_l1_,title,l11111111l_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ埢")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埣")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埤"))
			l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ埥"))
			l11111111l_l1_ = l11111111l_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭埦"))
			if l1ll1l11ll1_l1_: name = l1ll1l11ll1_l1_
			else: name = l11111111l_l1_
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ埧")+name+l1l111_l1_ (u"࠭ࠩࠨ埨")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭埩"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ埪"),url,l1l111_l1_ (u"ࠩࠪ埫"),l1l111_l1_ (u"ࠪࠫ埬"),l1l111_l1_ (u"ࠫࠬ埭"),l1l111_l1_ (u"ࠬ࠭埮"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭埯"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ埰"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ埱") in block:
		items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ埲"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埳")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭埴")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ埵"),l1l111_l1_ (u"࠭࠺ࠨ埶"))
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ執"))
				title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ埸")+count+l1l111_l1_ (u"ࠩࠬࠫ培")
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ基"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ埻"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1l1l111l_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"ࠬ࠭埼") or l11l1l1l111l_l1_==l1l111_l1_ (u"࠭ࠧ埽"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ埾")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ埿")+l1l1lll111_l1_+l1l111_l1_ (u"ࠩࠬࠫ堀")
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ堁"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ堂"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ堃"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ堄")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ堅"))
		name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ堆"))
		title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ堇")+name+l1l111_l1_ (u"ࠪ࠭ࠬ堈")
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ堉"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠬ࠭堊"),l1l1lll111_l1_)
	return
def l11l1l11llll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堋"),url,l1l111_l1_ (u"ࠧࠨ堌"),l1l111_l1_ (u"ࠨࠩ堍"),l1l111_l1_ (u"ࠩࠪ堎"),l1l111_l1_ (u"ࠪࠫ堏"),l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ堐"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭堑"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ堒"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ堓")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ堔"))
		if l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ堕") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ堖"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堗"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ堘"),url,l1l111_l1_ (u"࠭ࠧ堙"),l1l111_l1_ (u"ࠧࠨ堚"),l1l111_l1_ (u"ࠨࠩ堛"),l1l111_l1_ (u"ࠩࠪ堜"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ堝"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ堞"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ堟"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ堠"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ堡"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ堢"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ堣"),l1l111_l1_ (u"ࠪ࠯ࠬ堤"))
	l11l1l1l11l1_l1_ = [l1l111_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ堥"),l1l111_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ堦"),l1l111_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ堧")]
	if l11_l1_:
		l11l1l11lll1_l1_ = [l1l111_l1_ (u"ࠧใษิสࠬ堨"),l1l111_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ堩"),l1l111_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ堪")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ堫"), l11l1l11lll1_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ堬") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ堭") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ堮") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1l1l11l1_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ堯")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ堰"),url,l1l111_l1_ (u"ࠩࠪ報"),l1l111_l1_ (u"ࠪࠫ堲"),l1l111_l1_ (u"ࠫࠬ堳"),l1l111_l1_ (u"ࠬ࠭場"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭堵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ堶"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ堷"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ堸"))
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ堹"))
				title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ堺")+name+l1l111_l1_ (u"ࠬ࠯ࠧ堻")
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭堼"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭堽"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ堾"))
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ堿"))
				title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭塀")+name+l1l111_l1_ (u"ࠫ࠮࠭塁")
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ塂"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
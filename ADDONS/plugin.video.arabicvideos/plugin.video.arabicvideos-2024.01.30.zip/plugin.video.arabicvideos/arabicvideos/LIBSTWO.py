# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll1l1_l1_ import *
import bidi.algorithm,base64,requests
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ㍩")
contentsDICT = {}
menuItemsLIST = []
if PY3:
	l111ll1l11l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ㍪"))
	l1ll11ll11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ㍫"))
	l11l1l1l11l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ㍬"))
	l111ll11l1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍭"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍮"),l1l111_l1_ (u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ㍯"))
	l11l1llll1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍰"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍱"),l1l111_l1_ (u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ㍲"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍳"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍴"),l1l111_l1_ (u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭㍵"))
	half_triangular_colon = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ㍶")
	from urllib.parse import quote as _1lllllll1ll_l1_
else:
	l111ll1l11l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ㍷"))
	l1ll11ll11_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ㍸"))
	l11l1l1l11l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ㍹"))
	l111ll11l1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍺"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍻"),l1l111_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ㍼"))
	l11l1llll1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㍽"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㍾"),l1l111_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ㍿"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㎀"),l1l111_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㎁"),l1l111_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ㎂"))
	half_triangular_colon = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ㎃").encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㎄"))
	from urllib import quote as _1lllllll1ll_l1_
l111llll1l1_l1_ = os.path.join(l11l1l1l11l_l1_,l1l111_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ㎅"))
l11111ll1l1_l1_ = os.path.join(l11l1l1l11l_l1_,l1l111_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ㎆"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㎇"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㎈"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㎉"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ㎊"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㎋"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㎌"))
l1ll11l1l1l1_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡩࡧࡴࠨ㎍"))
addonimagesfolder = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࡵࠪ㎎"))
l1ll1lll11ll_l1_ = os.path.join(addonimagesfolder,l1l111_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬ㎏"))
l1ll1l111111_l1_ = os.path.join(l1ll1lll11ll_l1_,l1l111_l1_ (u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨ㎐"))
l1l1l1l1l11_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ㎑"))
defaulticon = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩ㎒"))
defaultthumb = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫ㎓"))
defaultfanart = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭㎔"))
defaultbanner = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ㎕"))
defaultlandscape = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫ㎖"))
defaultposter = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩ㎗"))
defaultclearlogo = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭㎘"))
defaultclearart = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭㎙"))
defaultmenu = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠴ࡰ࡯ࡩࠪ㎚"))
l1lll1l1ll1l_l1_ = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩ㎛"))
l1lllll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㎜"))
l1lll1l111ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㎝"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㎞"),addon_id,l1l111_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ㎟"))
fontfile = os.path.join(l111ll1l11l_l1_,l1l111_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭㎠"),l1l111_l1_ (u"ࠨࡈࡲࡲࡹࡹࠧ㎡"),l1l111_l1_ (u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬ㎢"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ูࠪๆืࠧ㎣"),l1l111_l1_ (u"ࠫศ๎ไࠨ㎤"),l1l111_l1_ (u"ࠬัว็์ࠪ㎥"),l1l111_l1_ (u"࠭หศๆฮࠫ㎦"),l1l111_l1_ (u"ࠧาษห฽ࠬ㎧"),l1l111_l1_ (u"ࠨะสุ้࠭㎨"),l1l111_l1_ (u"ࠩึหิูࠧ㎩"),l1l111_l1_ (u"ࠪืฬฮูࠨ㎪"),l1l111_l1_ (u"ࠫะอๅ็ࠩ㎫"),l1l111_l1_ (u"ࠬะวิ฻ࠪ㎬"),l1l111_l1_ (u"ู࠭ศึิࠫ㎭")]
l11111ll111_l1_ = l1l111_l1_ (u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ㎮")
l11ll11l_l1_ = 0
l1llll11l111_l1_ = 30*l1l1ll1lll1_l1_
l111l11l_l1_ = 2*l1l11llll11_l1_
l1lll11lll1_l1_ = 30*l1l11lll11l_l1_
l1l11l1111l_l1_ = 1*l1l11llll11_l1_
l1ll1l11llll_l1_ = [l1l111_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㎯")]
l1111ll1111_l1_ = [l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ㎰"),l1l111_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㎱"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㎲"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭㎳"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ㎴"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㎵"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㎶"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㎷"),l1l111_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㎸"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㎹")]
l1111ll1111_l1_ += [l1l111_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ㎺"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ㎻"),l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㎼"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㎽"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ㎾"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ㎿"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭㏀"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㏁")]
l1ll11l1ll1l_l1_ = [l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㏂"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ㏃"),l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭㏄"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ㏅")]
l1ll11l1ll1l_l1_ += [l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㏆"),l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭㏇"),l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㏈"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ㏉")]
l1ll11l1ll1l_l1_ += [l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭㏊"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ㏋"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ㏌")]
l1ll11l1ll1l_l1_ += [l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㏍"),l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㏎"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㏏"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㏐"),l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㏑"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㏒")]
l1ll11l1ll1l_l1_ += [l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㏓"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㏔"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㏕"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㏖"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㏗"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㏘")]
l1ll1llll11_l1_ = [l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㏙"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ㏚"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ㏛"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㏜")]
l1ll1llll11_l1_ += [l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㏝"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ㏞"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ㏟"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ㏠"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ㏡")]
l1lll111l1l_l1_ = [l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㏢"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㏣"),l1l111_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㏤"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㏥"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㏦"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㏧")]
l1lll111l1l_l1_ += [l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㏨"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㏩"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㏪"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㏫"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㏬")]
l1llll11111_l1_ = [l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㏭"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㏮"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㏯"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㏰"),l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㏱"),l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㏲"),l1l111_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㏳")]
l1llll11111_l1_ += [l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㏴"),l1l111_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㏵"),l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㏶"),l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㏷"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㏸"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㏹")]
l1lll1ll11ll_l1_  = [l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㏺"),l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㏻"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㏼"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㏽"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㏾"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㏿"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ㐀"),l1l111_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㐁")]
l1lll1ll11ll_l1_ += [l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ㐂"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㐃"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㐄"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ㐅"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㐆"),l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㐇"),l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㐈")]
l1lll1ll11ll_l1_ += [l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㐉"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㐊"),l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㐋"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㐌"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㐍"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㐎"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㐏")]
l1lll1ll11ll_l1_ += [l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㐐"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㐑"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㐒"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㐓"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㐔"),l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㐕"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㐖")]
l1lll1ll11ll_l1_ += [l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㐗"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㐘"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㐙"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㐚"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㐛"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㐜"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ㐝")]
l1ll1ll11l11_l1_  = [l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㐞"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㐟"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㐠"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㐡")]
l1ll1ll11l11_l1_ += [l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㐢"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㐣")]
l1ll1ll11l11_l1_ += [l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㐤"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㐥"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㐦")]
l1ll1ll11l11_l1_ += [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㐧"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㐨"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㐩")]
l1ll1ll11l11_l1_ += [l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ㐪"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㐫"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㐬")]
l1ll1lllll11_l1_ = [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㐭"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㐮"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㐯"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㐰"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㐱")]
l1lll1l11l1_l1_ = l1lll1ll11ll_l1_+l1ll1ll11l11_l1_
l1lll11lll11_l1_ = l1lll1ll11ll_l1_+l1ll1lllll11_l1_
l1l1111111l_l1_ = l1lll1ll11ll_l1_+l1ll1ll11l11_l1_
l1lll1l111l_l1_ = l1ll11l1ll1l_l1_+l1lll111l1l_l1_+l1llll11111_l1_+l1ll1llll11_l1_
l1lll111ll11_l1_ = [
						l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ㐲")
						,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ㐳")
						,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ㐴")
						]
l111111llll_l1_ = [
						l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ㐵")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ㐶")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ㐷")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭㐸")
						,l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ㐹")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ㐺")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬ㐻")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭㐼")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㐽")
						,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ㐾")
						,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬ㐿")
						,l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠸ࡸ࡭࠭㑀")
						,l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㑁")
						]
l11l1ll1111_l1_ = l111111llll_l1_+[
				 l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㑂")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㑃")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭㑄")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧ㑅")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ㑆")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ㑇")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ㑈")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪ㑉")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫ㑊")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㑋")
				,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ㑌")
				,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ㑍")
				,l1l111_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ㑎")
				,l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ㑏")
				,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ㑐")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㑑")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ㑒")
				]
l1111llll11_l1_ = [l1l111_l1_ (u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬ㑓"),l1l111_l1_ (u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭㑔"),l1l111_l1_ (u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧ㑕"),l1l111_l1_ (u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨ㑖"),l1l111_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩ㑗"),l1l111_l1_ (u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪ㑘")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㑙")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫ࡰࡣࡰ࠲ࡳ࡫ࡴࠨ㑚")]
			,l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㑛")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨ㑜")]
			,l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㑝")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸࠬ㑞")]
			,l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㑟")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡵࡤ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬ㑠")]
			,l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭㑡")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬ࡧࡣࡷ࡭ࡲ࡯࠮ࡵࡸࠪ㑢")]
			,l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㑣")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭㑤")]
			,l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㑥")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩ㑦")]
			,l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㑧")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫ㑨")]
			,l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㑩")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩࡱࡲࡪࡻࡵࡤ࠯ࡥࡲࡱࠬ㑪")]
			,l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㑫")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡶࡸࡺࡥ࡫࠰ࡦࡳࡲ࠭㑬")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㑭")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠶࠳࠴࠳ࡩ࡯࡮ࠩ㑮")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㑯")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫ㑰")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㑱")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠹ࡢࡥࡱ࠱ࡧࡴࡳࠧ㑲")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㑳")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹ࡫ࡪࡰࠪ㑴")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩ㑵")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡴࡪࡲࡴࠬ㑶")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㑷")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰ࡯ࠪ㑸")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㑹")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠻࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷࠫ㑺")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㑻")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡩࡣࠨ㑼")]
			,l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㑽")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ㑾"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ㑿")]
			,l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㒀")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡧ࠳ࡪࡲࡢ࡯ࡤࡷ࠼࠴ࡣࡰ࡯ࠪ㒁")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㒂")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳ࠳ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ㒃")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㒄")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡤࡨࡷࡹ࠴ࡳࡵࡱࡵࡩࠬ㒅")]
			,l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㒆")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧ㒇")]
			,l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㒈")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ㒉")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㒊")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ㒋")]
			,l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ㒌")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭㒍")]
			,l1l111_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㒎")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭㒏")]
			,l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㒐")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ㒑")]
			,l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㒒")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡱ࡯࡮࡬ࠩ㒓")]
			,l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㒔")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭㒕")]
			,l1l111_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㒖")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭㒗")]
			,l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㒘")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭㒙")]
			,l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㒚")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㒛"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㒜"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㒝"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㒞"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ㒟")]
			,l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㒠")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭㒡")]
			,l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ㒢")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡲࡳ࠳ࡱࡩࡵ࡭ࡲࡸ࠳ࡺࡶࠨ㒣")]
			,l1l111_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ㒤")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭㒥"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ㒦")]
			,l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㒧")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮ࡤࡣࡰࠫ㒨")]
			,l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ㒩")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ㒪")]
			,l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㒫")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡡ࠯ࡥࡤࡱࠬ㒬")]
			,l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㒭")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪ㒮")]
			,l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㒯")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧ࠲ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧ㒰")]
			,l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㒱")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ㒲"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㒳"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭㒴")]
			,l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㒵")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪ㒶")]
			,l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㒷")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡺࡱ࠱࠲࠳࠭࠮࠯ࡱࡾࡪࡨࡣࡢ࠷ࡪࡨ࠼ࡵࡤࡦ࠲ࡥ࡭࡬ࡲࡨ࠯࡯ࡼࡧ࡮࡯࡭ࡢ࠯ࡺࡩࡨ࡯ࡩ࡮ࡣ࠱ࡷ࡭ࡵࡰࠨ㒸")]
			,l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㒹")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ㒺")]
			,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㒻")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ㒼")]
			,l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㒽")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㒾"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ㒿"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ㓀")]
			,l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ㓁")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ㓂"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭㓃"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ㓄")]
			,l1l111_l1_ (u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ㓅")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡮ࡳࡩ࡯ࠧ㓆"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡸࡻࡲࡨࡧ࠱ࡷ࡭࠭㓇"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓࠬ㓈")]
			}
if 1:
	l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㓉")] = [l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㓊"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㓋"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㓌"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㓍"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㓎"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㓏"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㓐"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㓑"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭㓒")]
	l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ㓓")] = [l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㓔"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㓕"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㓖"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㓗"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㓘"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㓙"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㓚"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩ㓛"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ㓜")]
else:
	l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㓝")] = [l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㓞"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㓟"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㓠"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㓡"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㓢"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㓣"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㓤"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㓥"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭㓦")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ㓧")] = [l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㓨"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㓩"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㓪"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㓫"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㓬"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㓭"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㓮"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㓯"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ㓰")]
l111l11llll_l1_ = [l1l111_l1_ (u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪ㓱"),l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡒࡕࡕࠪ㓲"),l1l111_l1_ (u"ࠪࡉࡒࡇࡉࡍࡕࠪ㓳"),l1l111_l1_ (u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭㓴"),l1l111_l1_ (u"ࠬࡏࡓࡍࡃࡐࡍࡈ࡙ࠧ㓵"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㓶"),l1l111_l1_ (u"ࠧࡌࡐࡒ࡛ࡓࡋࡒࡓࡑࡕࡗࠬ㓷"),l1l111_l1_ (u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩ㓸"),l1l111_l1_ (u"ࠩࡗࡉࡘ࡚ࡉࡏࡉࠪ㓹")]
l11l11llll1_l1_ = [l1l111_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࠪ㓺"),l1l111_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭㓻"),l1l111_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ㓼")]
class l1ll1llllll1_l1_(l1l1l1lllll_l1_):
	def __init__(self,*args,**kwargs):
		self.l11llll1ll1_l1_ = -1
	def onClick(self,l1111llllll_l1_):
		if l1111llllll_l1_>=9010: self.l11llll1ll1_l1_ = l1111llllll_l1_-9010
		self.delete()
	def l11l11ll1ll_l1_(self,*args):
		self.l111l1lll1l_l1_,self.l1ll1lll11l1_l1_,self.l1lllllll111_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll1lll1ll_l1_ = args[5],args[6]
		self.l1ll11l11ll1_l1_,self.l1ll1l1l1lll_l1_ = args[7],args[8]
		if self.l1ll11l11ll1_l1_>0 or self.l1ll1l1l1lll_l1_>0: self.l1lll1l11ll1_l1_ = True
		else: self.l1lll1l11ll1_l1_ = False
		self.l11111lll1l_l1_ = l1ll1l111111_l1_.replace(l1l111_l1_ (u"࠭࡟࠱࠲࠳࠴ࡤ࠭㓽"),l1l111_l1_ (u"ࠧࡠࠩ㓾")+str(time.time())+l1l111_l1_ (u"ࠨࡡࠪ㓿"))
		self.l11111lll1l_l1_ = self.l11111lll1l_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ㔀"),l1l111_l1_ (u"ࠪࡠࡡࡢ࡜ࠨ㔁")).replace(l1l111_l1_ (u"ࠫ࠴࠵ࠧ㔂"),l1l111_l1_ (u"ࠬ࠵࠯࠰࠱ࠪ㔃"))
		self.l11l111l111_l1_ = CREATE_IMAGE(self.l111l1lll1l_l1_,self.l1ll1lll11l1_l1_,self.l1lllllll111_l1_,self.header,self.text,self.profile,self.l1lll1lll1ll_l1_,self.l1lll1l11ll1_l1_,self.l11111lll1l_l1_)
		self.show()
		self.getControl(9050).setImage(self.l11111lll1l_l1_)
		self.getControl(9050).setHeight(self.l11l111l111_l1_)
		if not self.l1ll1lll11l1_l1_ and self.l111l1lll1l_l1_ and self.l1lllllll111_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l11111lll1l_l1_,self.l11l111l111_l1_
	def l11llll11ll_l1_(self):
		if self.l1ll11l11ll1_l1_:
			self.l1lll11ll1l1_l1_ = threading.Thread(target=self.l1llll11llll_l1_,args=())
			self.l1lll11ll1l1_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1llll11llll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l111llll_l1_ in range(1,self.l1ll11l11ll1_l1_+1):
			time.sleep(1)
			l1ll11l1l1ll_l1_ = int(100*l1l111llll_l1_/self.l1ll11l11ll1_l1_)
			self.l1ll1l111l1l_l1_(l1ll11l1l1ll_l1_)
			if self.l11llll1ll1_l1_>0: break
		self.l11l11l1ll1_l1_()
	def l11ll1llll1_l1_(self):
		if self.l1ll1l1l1lll_l1_:
			self.l1lll11ll1ll_l1_ = threading.Thread(target=self.l1111l11111_l1_,args=())
			self.l1lll11ll1ll_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1111l11111_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll11l11ll1_l1_)
		for l1l111llll_l1_ in range(self.l1ll1l1l1lll_l1_-1,-1,-1):
			time.sleep(1)
			l1ll11l1l1ll_l1_ = int(100*l1l111llll_l1_/self.l1ll1l1l1lll_l1_)
			self.l1ll1l111l1l_l1_(l1ll11l1l1ll_l1_)
			if self.l11llll1ll1_l1_>0: break
		if self.l1ll1l1l1lll_l1_>0: self.l11llll1ll1_l1_ = 10
		self.delete()
	def l1ll1l111l1l_l1_(self,l1ll11l1l1ll_l1_):
		self.l11111ll11l_l1_ = l1ll11l1l1ll_l1_
		self.getControl(9020).setPercent(self.l11111ll11l_l1_)
	def l11l11l1ll1_l1_(self):
		if self.l111l1lll1l_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll1lll11l1_l1_: self.getControl(9011).setEnabled(True)
		if self.l1lllllll111_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l11111lll1l_l1_)
		except: pass
class l11l11ll111_l1_():
	def __init__(self,l11_l1_=False,l1lll1l1l11l_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1lll1l1l11l_l1_ = l1lll1l1l11l_l1_
		self.l11l1l1l1l1_l1_,self.l1l11111111_l1_ = [],[]
		self.l111l111111_l1_,self.l1111ll1lll_l1_ = {},{}
		self.l111lll1l1l_l1_ = []
		self.l1ll1l111ll1_l1_,self.l11111l1l11_l1_,self.l11lll1ll1l_l1_ = {},{},{}
	def l11l111llll_l1_(self,id,func,*args):
		id = str(id)
		self.l111l111111_l1_[id] = l1l111_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㔄")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧࠨ㔅"),id)
		l11lllll111_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l111lll1l1l_l1_.append(l11lllll111_l1_)
		return l11lllll111_l1_
	def start_new_thread(self,id,func,*args):
		l11lllll111_l1_ = self.l11l111llll_l1_(id,func,*args)
		l11lllll111_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1ll1l111ll1_l1_[id] = time.time()
		try:
			self.l1111ll1lll_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ㔆") in str(func) and not self.l1111ll1lll_l1_[id].succeeded:
				l1111l1ll11_l1_(l1l111_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠࡵࡪࡵࡩࡦࡪࡥࡥࠢࡒࡔࡊࡔࡕࡓࡎࠣࡪࡦ࡯࡬ࠨ㔇"))
			self.l11l1l1l1l1_l1_.append(id)
			self.l111l111111_l1_[id] = l1l111_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ㔈")
		except Exception as err:
			if self.l1lll1l1l11l_l1_:
				l111l11ll11_l1_ = traceback.format_exc()
				if l111l11ll11_l1_!=l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ㔉"): sys.stderr.write(l111l11ll11_l1_)
			self.l1l11111111_l1_.append(id)
			self.l111l111111_l1_[id] = l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㔊")
		self.l11111l1l11_l1_[id] = time.time()
		self.l11lll1ll1l_l1_[id] = self.l11111l1l11_l1_[id] - self.l1ll1l111ll1_l1_[id]
	def l1lll1l1l111_l1_(self):
		for proc in self.l111lll1l1l_l1_:
			proc.start()
	def l1ll11l1llll_l1_(self):
		while l1l111_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㔋") in list(self.l111l111111_l1_.values()): time.sleep(1.000)
def l1lll1lll111_l1_():
	l1lll11l111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㔌"))
	if l1lll11l111l_l1_==l1l11l111l1_l1_:
		status,l111l1ll1l1_l1_ = l1l111_l1_ (u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫ㔍"),False
		return status,l111l1ll1l1_l1_
	try: os.makedirs(addoncachefolder)
	except: pass
	status,l111l1ll1l1_l1_ = l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㔎"),True
	l11l1lll1l1_l1_ = [l1l111_l1_ (u"ࠪ࠼࠳࠻࠮࠱ࠩ㔏"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠴࠳࠷࠹ࠨ㔐"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠶࠴࠲࠵ࡣࠪ㔑"),l1l111_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠸࠮࠴࠲ࠪ㔒"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠶࠳࠶࠲࠯࠲࠵ࠫ㔓"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠱࠱࠰࠵࠶ࠬ㔔"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠵࠱࠴࠻࠭㔕"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠸࠲࠶࠼ࠧ㔖"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠺࠳࠶࠶ࠨ㔗"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠵࠵࠴࠲࠹ࠩ㔘"),l1l111_l1_ (u"࠭࠲࠱࠴࠷࠲࠵࠷࠮࠲࠶ࠪ㔙")]
	l1111111111_l1_ = l11l1lll1l1_l1_[-1]
	l111ll11l11_l1_ = l1ll11l1l11l_l1_(l1111111111_l1_)
	l1lllll11l1l_l1_ = l1ll11l1l11l_l1_(l1l11l111l1_l1_)
	if l1lllll11l1l_l1_>l111ll11l11_l1_:
		status = l1l111_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㔚")
	return status,l111l1ll1l1_l1_
def l11111l1111_l1_():
	l11ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡪ࡯ࡤ࡫ࡪࡹࠧ㔛"))
	if not l11ll11l1l1_l1_: l1lll1lll1_l1_ = 5001
	else:
		l1lll1lll1_l1_ = 0
		for root,dirs,l1l1111111_l1_ in os.walk(addonimagesfolder,topdown=False):
			l1lll1lll1_l1_ += len(l1l1111111_l1_)
	if l1lll1lll1_l1_>5000: l1llll1ll1_l1_(addonimagesfolder,True,False)
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡫ࡰࡥ࡬࡫ࡳࠨ㔜"),str(now))
	return
def l1111l1l1ll_l1_(l1lll11l11l_l1_,l1lllll11111_l1_):
	succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_ = True,False,False
	type,name,l1l1l11llll_l1_,mode,l1l1ll1111l_l1_,l1l1111l1l1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
	l1ll1l11lll1_l1_ = type,name,l1l1l11llll_l1_,mode,l1l1ll1111l_l1_,l1l1111l1l1_l1_,text,l1l111_l1_ (u"ࠪࠫ㔝"),l1llllll1ll_l1_
	l1lll1l11111_l1_ = int(mode)
	l1lll11lllll_l1_ = int(l1lll1l11111_l1_%10)
	l1lll1l1111l_l1_ = int(l1lll1l11111_l1_/10)
	l1ll11l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫ㔞"))
	if not l1ll11l1lll1_l1_: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ㔟"),l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㔠"))
	l11l11l111l_l1_,l111l1ll1l1_l1_ = l1lll1lll111_l1_()
	if l111l1ll1l1_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㔡"),l1l111_l1_ (u"ࠨࠩ㔢"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㔣"),l1l111_l1_ (u"ࠪฮ๊ࠦสฮัํฯࠥอไษำ้ห๊าࠠโ์ࠣะ์อาไ࡞ࡱษ้๏ࠠศๆศูิอัࠡำๅ้࠿ࡢ࡮࡝ࡰࠪ㔤")+l1l11l111l1_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㔥"),l1l111_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㔦"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㔧"),l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ㔨"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㔩"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧ㔪"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㔫"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ㔬"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㔭"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ㔮"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧ㔯"),l1l111_l1_ (u"ࠨࠩ㔰"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫ㔱"),l1l111_l1_ (u"ࠪࠫ㔲"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳ࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㔳"),l1l111_l1_ (u"ࠬ࠭㔴"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩ㔵"),l1l111_l1_ (u"ࠧࠨ㔶"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡳࡳࡸ࠭㔷"),l1l111_l1_ (u"ࠩࠪ㔸"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡬ࡱࡦ࡭ࡥࡴࠩ㔹"),l1l111_l1_ (u"ࠫࠬ㔺"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㔻"),l1l111_l1_ (u"࠭ࠧ㔼"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㔽"),l1l111_l1_ (u"ࠨࠩ㔾"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶࠫ㔿"),l1l111_l1_ (u"ࠪࠫ㕀"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭㕁"),l1l111_l1_ (u"ࠬ࠭㕂"))
		import l1l11llllll_l1_
		if l11l11l111l_l1_==l1l111_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㕃"):
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㕄"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㕅")+addon_path+l1l111_l1_ (u"ࠩࠣࡡࠬ㕆"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ㕇"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ㕈"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ㕉"))
			l11l1lll1ll_l1_(True,[main_dbfile])
		else:
			l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㕊"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ㕋")+addon_path+l1l111_l1_ (u"ࠨࠢࡠࠫ㕌"))
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㕍"),l1l111_l1_ (u"ࠪࠫ㕎"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㕏"),l1l111_l1_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ㕐"))
			l11l1lll1ll_l1_()
			FIX_ALL_DATABASES(False)
			l1l11llllll_l1_.l1ll1ll1llll_l1_()
			l1l11llllll_l1_.l1l1l1llll1_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㕑"),False)
			l1l11llllll_l1_.l1l1l1llll1_l1_(l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ㕒"),False)
			l1l11llllll_l1_.l11111lll11_l1_(False)
			l1l11llllll_l1_.l1ll1ll1l111_l1_(False)
			l1l11llllll_l1_.l111ll1llll_l1_(l1l111_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㕓"),l1l111_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ㕔"),False)
			try:
				l11l1ll1ll1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㕕"),l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ㕖"),l1l111_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ㕗"),l1l111_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ㕘"))
				l1111lll1ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ㕙"))
				l1111lll1ll_l1_.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧ㕚"),l1l111_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ㕛"))
			except: pass
			try:
				l11l1ll1ll1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㕜"),l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ㕝"),l1l111_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ㕞"),l1l111_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ㕟"))
				l1111lll1ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ㕠"))
				l1111lll1ll_l1_.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫ㕡"),l1l111_l1_ (u"ࠩ࠶ࠫ㕢"))
			except: pass
			try:
				l11l1ll1ll1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㕣"),l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ㕤"),l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㕥"),l1l111_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ㕦"))
				l1111lll1ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㕧"))
				l1111lll1ll_l1_.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭㕨"),l1l111_l1_ (u"ࠩ࠵ࠫ㕩"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l1111ll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll11l1l1l1_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㕪"),l1l11l111l1_l1_)
		l1l11llllll_l1_.l11ll1ll111_l1_(False)
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㕫"))
	l1l111ll11_l1_ = l11lll111l1_l1_(l1lllll11111_l1_)
	l1l11ll1lll_l1_ = l11lll111l1_l1_(name)
	l1111llll1l_l1_ = [0,15,17,19,26,34,50,53]
	l1lll1lllll1_l1_ = [0,15,17,19,26,34,50,53]
	l11llll111l_l1_ = l1lll1l1111l_l1_ not in l1lll1lllll1_l1_
	l1ll11ll111l_l1_ = l1lll1l1111l_l1_ in [23,28,71,72]
	l1llll1lll11_l1_ = l1lll1l11111_l1_ in [265,270]
	l111111l1ll_l1_ = (l11llll111l_l1_ or l1ll11ll111l_l1_) and not l1llll1lll11_l1_
	l11l1lll111_l1_ = l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㕬") and (l1ll11l1l1_l1_!=l1l111_l1_ (u"࠭ࠧ㕭") or context==l1l111_l1_ (u"ࠧࠨ㕮"))
	l1lll1l11l11_l1_ = l1l111_l1_ (u"ࠨࡶࡼࡴࡪࡃࠧ㕯") in l1ll11l1l1_l1_
	l1ll1ll1l1ll_l1_ = l1lll1l11111_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1lll11lllll_l1_==9 or l1lll1l11111_l1_ in [145,516,523,45]
	l11lll1111l_l1_ = not l1ll1ll1l1ll_l1_
	l11l1l11lll_l1_ = not l1lll1_l1_
	l1lllll111ll_l1_ = l1l111ll11_l1_ in [l1l111_l1_ (u"ࠩࠪ㕰"),l1l111_l1_ (u"ࠪ࠲࠳࠭㕱")]
	l111ll1111l_l1_ = l1lllll111ll_l1_ or l11lll1111l_l1_
	l1111l1lll1_l1_ = l1lllll111ll_l1_ or l11l1l11lll_l1_ or l1lll1l11l11_l1_
	l1ll1l1l111l_l1_ = l1lll1l11111_l1_ not in [260,261,265,270,330,540]
	if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㕲"): l111l1llll1_l1_ = l1lll1_l1_ or l1ll1ll1l1ll_l1_
	else: l111l1llll1_l1_ = True
	l1ll1ll1ll_l1_ = l1lll1l1111l_l1_ in [74,75]
	l1111l111l1_l1_ = l1lll1l11111_l1_ in [280,720]
	l111ll1ll1l_l1_ = not l1ll1ll1ll_l1_ and not l1111l111l1_l1_
	l1ll11ll1l11_l1_ = l111ll1111l_l1_ and l1111l1lll1_l1_ and l1ll1l1l111l_l1_ and l111l1llll1_l1_ and l111ll1ll1l_l1_
	l11l1l1111l_l1_ = l1ll1l1l111l_l1_ and l111l1llll1_l1_ and l111ll1ll1l_l1_
	l11l1l111ll_l1_ = l11l1l1111l_l1_
	l1l111111ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ㕳"))
	l111lllll1l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ㕴"))
	if 1 and l11l1lll111_l1_ and l1ll11ll1l11_l1_:
		l1111111lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㕵"),l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㕶")+l1l111111ll_l1_+l1l111_l1_ (u"ࠩࡢࠫ㕷")+l111lllll1l_l1_,l1ll1l11lll1_l1_)
		if l1111111lll_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࠫ㕸"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㕹")+l1l111111ll_l1_+l1l111_l1_ (u"ࠬࡥࠧ㕺")+l111lllll1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ㕻"))
			if 1 and l1lll1l11l11_l1_:
				l11ll1ll1ll_l1_ = []
				from l1ll1l1ll1l1_l1_ import l11111111ll_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1lllll1111l_l1_ = l11111111ll_l1_
				l11ll1l1l1l_l1_ = GET_ALL_FAVORITES()
				l111l1111ll_l1_ = l1ll11l1l1_l1_
				l11l11lllll_l1_,l11l1l1l1ll_l1_,l1llll1lll1l_l1_,l1lll11ll11l_l1_,l11ll11111l_l1_,l1111l11lll_l1_,l11l1l1ll11_l1_,l1llll111l1l_l1_,l1111l1llll_l1_ = EXTRACT_KODI_PATH(l111l1111ll_l1_)
				l1lllll111l1_l1_ = l11l11lllll_l1_,l11l1l1l1ll_l1_,l1llll1lll1l_l1_,l1lll11ll11l_l1_,l11ll11111l_l1_,l1111l11lll_l1_,l11l1l1ll11_l1_,l1l111_l1_ (u"ࠧࠨ㕼"),l1111l1llll_l1_
				for l1l11111l11_l1_ in l1111111lll_l1_:
					l1lll11111l1_l1_ = l1l11111l11_l1_[l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ㕽")]
					if l1lll11111l1_l1_==l1lllll111l1_l1_ or l1l11111l11_l1_[l1l111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㕾")] in [265,270]:
						l1l11111l11_l1_ = GET_LIST_ITEM(l1lll11111l1_l1_,l1lllll1111l_l1_,l11ll1l1l1l_l1_)
						if l1l11111l11_l1_[l1l111_l1_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭㕿")]:
							l1lll11l11l1_l1_ = GET_FAVORITES_CONTEXT_MENU(l11ll1l1l1l_l1_,l1lll11111l1_l1_,l1l11111l11_l1_[l1l111_l1_ (u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬ㖀")])
							l1l11111l11_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㖁")] = l1lll11l11l1_l1_+l1l11111l11_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㖂")]
					l11ll1ll1ll_l1_.append(l1l11111l11_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㖃"),l1l111_l1_ (u"ࠨࠩ㖄"))
				if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖅"): l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㖆")+l1l111111ll_l1_+l1l111_l1_ (u"ࠫࡤ࠭㖇")+l111lllll1l_l1_,l1ll1l11lll1_l1_,l11ll1ll1ll_l1_,l11l1l1_l1_)
			else: l11ll1ll1ll_l1_ = l1111111lll_l1_
			if type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㖈") and l1l111ll11_l1_!=l1l111_l1_ (u"࠭࠮࠯ࠩ㖉") and l111111l1ll_l1_: l1l1l1lll11_l1_()
			l11l1ll1l11_l1_ = CREATE_KODI_MENU(l1ll1l11lll1_l1_,l11ll1ll1ll_l1_,succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_)
			return
	elif type==l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖊") and l1ll11l1l1_l1_==l1l111_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ㖋") and l11l1l1111l_l1_:
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㖌")+l1l111111ll_l1_+l1l111_l1_ (u"ࠪࡣࠬ㖍")+l111lllll1l_l1_,l1ll1l11lll1_l1_)
	if l1l111_l1_ (u"ࠫࡤ࠭㖎") in context: l1llll111111_l1_,l1llll11111l_l1_ = context.split(l1l111_l1_ (u"ࠬࡥࠧ㖏"),1)
	else: l1llll111111_l1_,l1llll11111l_l1_ = context,l1l111_l1_ (u"࠭ࠧ㖐")
	if l1llll111111_l1_ in [l1l111_l1_ (u"ࠧ࠲ࠩ㖑"),l1l111_l1_ (u"ࠨ࠴ࠪ㖒"),l1l111_l1_ (u"ࠩ࠶ࠫ㖓"),l1l111_l1_ (u"ࠪ࠸ࠬ㖔"),l1l111_l1_ (u"ࠫ࠺࠭㖕")] and l1llll11111l_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㖖"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㖗"))
		return
	elif l1llll111111_l1_==l1l111_l1_ (u"ࠧ࠷ࠩ㖘"):
		if l1llll11111l_l1_==l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㖙"): l1ll1lll_l1_(l1l111_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ㖚"),l1l111_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ㖛"))
		elif l1llll11111l_l1_==l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ㖜"): l1lll1l11111_l1_ = 334
		l1lll_l1_ = l1lll1111l11_l1_(type,l1l11ll1lll_l1_,l1l1l11llll_l1_,l1lll1l11111_l1_,l1l1ll1111l_l1_,l1l1111l1l1_l1_,text,context,l1llllll1ll_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㖝"))
		return
	elif context==l1l111_l1_ (u"࠭࠷ࠨ㖞"):
		from l1111l1l11_l1_ import l1lll111ll1_l1_
		l1lll111ll1_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㖟"))
		return
	elif context==l1l111_l1_ (u"ࠨ࠺ࠪ㖠"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㖡")+addon_id+l1l111_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ㖢")+str(mode)+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ㖣"))
		return
	elif context==l1l111_l1_ (u"ࠬ࠿ࠧ㖤"):
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㖥"),l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㖦"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㖧"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ㖨")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㖩"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㖪"),l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㖫")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ㖬"),l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㖭"))
	if not settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳࠨ㖮")): settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩ㖯"),l1111llll11_l1_[0])
	l11ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡬ࡱࡦ࡭ࡥࡴࠩ㖰"))
	l11ll11l1l1_l1_ = 0 if not l11ll11l1l1_l1_ else int(l11ll11l1l1_l1_)
	if not l11ll11l1l1_l1_ or now-l11ll11l1l1_l1_<=0 or now-l11ll11l1l1_l1_>l11l1l1_l1_:
		l11lllll111_l1_ = threading.Thread(target=l11111l1111_l1_)
		l11lllll111_l1_.start()
	l1ll11llll1l_l1_ = False if l1l11l11111_l1_(l1l111_l1_ (u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬ㖱")) else True
	l11llll1l1l_l1_ = l111l11l_l1_ if l1ll11llll1l_l1_ else l11l1l1_l1_
	l11lll11l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㖲"))
	l1ll1l1l11l1_l1_ = l1111l1l1l1_l1_(settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㖳")))
	l1ll1l1l11l1_l1_ = 0 if not l1ll1l1l11l1_l1_ else int(l1ll1l1l11l1_l1_)
	if l11lll11l11_l1_ in [l1l111_l1_ (u"ࠧࠨ㖴"),l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘࠧ㖵")] or not l11llll1l1l_l1_ or not l1ll1l1l11l1_l1_ or now-l1ll1l1l11l1_l1_<0 or now-l1ll1l1l11l1_l1_>l11llll1l1l_l1_:
		l11lll11l11_l1_ = l1ll1l1l1l1l_l1_(True,False)
	l11lll1lll1_l1_ = l1111l1l1l1_l1_(settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫ㖶")))
	l11lll1lll1_l1_ = 0 if not l11lll1lll1_l1_ else int(l11lll1lll1_l1_)
	l11l1l1l111_l1_ = l1111l1l1l1_l1_(settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㖷")))
	l11l1l1l111_l1_ = 0 if not l11l1l1l111_l1_ else int(l11l1l1l111_l1_)
	if not l11lll1lll1_l1_ or not l11l1l1l111_l1_ or now-l11l1l1l111_l1_<0 or now-l11l1l1l111_l1_>l11lll1lll1_l1_:
		l1lll111lll1_l1_ = 1
		if l1ll11llll1l_l1_:
			l1lll11111ll_l1_ = l11lll1l1l1_l1_(True)
			if len(l1lll11111ll_l1_)>1:
				l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㖸"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㖹")+addon_path+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㖺"))
				id,l1ll11l11lll_l1_,l111l111lll_l1_,l11l11l1l11_l1_,l11l11l1111_l1_,reason = l1lll11111ll_l1_[0]
				l111l11111l_l1_,l111l1111l1_l1_ = l11l11l1l11_l1_.split(l1l111_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㖻"))
				del l1lll11111ll_l1_[0]
				l1lll1l111l1_l1_ = random.sample(l1lll11111ll_l1_,1)
				id,l1ll11l11lll_l1_,l111l111lll_l1_,l11l11l1l11_l1_,l11l11l1111_l1_,reason = l1lll1l111l1_l1_[0]
				l111l111lll_l1_ = l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ㖼")+id+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㖽")+l111l111lll_l1_
				l11l11l1111_l1_ = l1l111_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩ㖾")
				l11111ll111_l1_ = l1l111_l1_ (u"ࠫฬ๊สษำ฼หฯ࠭㖿")
				l111l1lll1l_l1_,l1ll1lll11l1_l1_ = l11l11l1l11_l1_,l11l11l1111_l1_
				l111llll_l1_ = [l111l1lll1l_l1_,l1ll1lll11l1_l1_,l11111ll111_l1_]
				l11l1111l1l_l1_ = 1 if l1l11l11111_l1_(l1l111_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㗀")) else 10
				l11l1111ll1_l1_ = -9
				while l11l1111ll1_l1_<0:
					l11l1l1llll_l1_ = random.sample(l111llll_l1_,3)
					l11l1111ll1_l1_ = l1ll11ll1l1l_l1_(l1l111_l1_ (u"࠭ࠧ㗁"),l11l1l1llll_l1_[0],l11l1l1llll_l1_[1],l11l1l1llll_l1_[2],l111l11111l_l1_,l111l111lll_l1_,l1l111_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㗂"),l11l1111l1l_l1_,60)
					if l11l1111ll1_l1_==10: break
					from l1l11llllll_l1_ import l1lll1l1llll_l1_,l1l1l1l11l1_l1_
					if l11l1111ll1_l1_>=0 and l11l1l1llll_l1_[l11l1111ll1_l1_]==l111llll_l1_[1]:
						l1lll1l1llll_l1_()
						if l11l1111ll1_l1_>=0: l11l1111ll1_l1_ = -9
					elif l11l1111ll1_l1_>=0 and l11l1l1llll_l1_[l11l1111ll1_l1_]==l111llll_l1_[2]:
						l1l1l1l11l1_l1_(False)
					if l11l1111ll1_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㗃"),l1l111_l1_ (u"ࠩࠪ㗄"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㗅"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭㗆"))
				l1lll111lll1_l1_ = 1
			else: l1lll111lll1_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㗇"),l1lll1ll11l1_l1_(now))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㗈"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ㗉"),l1lll111lll1_l1_,l1ll111ll11_l1_)
	l1lll_l1_ = l1lll1111l11_l1_(type,l1l11ll1lll_l1_,l1l1l11llll_l1_,mode,l1l1ll1111l_l1_,l1l1111l1l1_l1_,text,context,l1llllll1ll_l1_)
	if l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㗊") in text: l111l11l1l1_l1_ = True
	if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㗋"):
		if l1l111ll11_l1_!=l1l111_l1_ (u"ࠪ࠲࠳࠭㗌") and l111111l1ll_l1_: l1l1l1lll11_l1_()
		if addon_handle>-1:
			if (l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫ࡮ࡴࡴࠨ㗍"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㗎"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ㗏")) or l1lll1l11111_l1_ not in l1111llll1l_l1_) and not l1l11l11111_l1_(l1l111_l1_ (u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ㗐")):
				from l1ll1l1ll1l1_l1_ import l11111111ll_l1_
				l1111111lll_l1_ = GET_ALL_LIST_ITEMS(l11111111ll_l1_)
				l11l1ll1l11_l1_ = CREATE_KODI_MENU(l1ll1l11lll1_l1_,l1111111lll_l1_,succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_)
				if 1 and l1111111lll_l1_ and l11l1l111ll_l1_:
					l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㗑")+l1l111111ll_l1_+l1l111_l1_ (u"ࠩࡢࠫ㗒")+l111lllll1l_l1_,l1ll1l11lll1_l1_,l1111111lll_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㗓")+addon_id+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㗔"),xbmcgui.ListItem(l1l111_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫ㗕")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㗖")+addon_id+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㗗"),xbmcgui.ListItem(l1l111_l1_ (u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ㗘")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_)
	return
def l1lll1111l11_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_):
	l1lll1l11111_l1_ = int(mode)
	l1lll1l1111l_l1_ = int(l1lll1l11111_l1_//10)
	if   l1lll1l1111l_l1_==0:  from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==2:  from l1ll1lll11l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==3:  from l11l11lll11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,l1llllll1_l1_)
	elif l1lll1l1111l_l1_==5:  from l11lll1ll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==8:  from l1ll1lll1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==9:  from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==10: from l1llll1lllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url)
	elif l1lll1l1111l_l1_==11: from l1ll1llll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==12: from l11l11ll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==14: from l11ll1lllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1lll1l1111l_l1_==15: from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==16: from l1ll1ll1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==17: from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==18: from l1ll11lll111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==19: from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==21: from l11l1111l11_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==22: from l111l1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==26: from l1ll1l1ll1l1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1lll1l11111_l1_,context)
	elif l1lll1l1111l_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==29: from l11ll111lll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==30: from l1lllllll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==31: from l11l1l111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==32: from l1ll1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==33: from l11lll1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url)
	elif l1lll1l1111l_l1_==34: from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==36: from l1llll11ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==38: from l11l1l11l1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==39: from l1lllll1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==40: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1l1111l_l1_==41: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1l1111l_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==43: from l111l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==44: from l111l11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==45: from l11lllll1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==46: from l1111l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==47: from l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==48: from l1ll1l1lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==49: from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==50: from l1l11llllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,text)
	elif l1lll1l1111l_l1_==51: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==52: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==53: from l1ll1l1ll1l1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==54: from l1111l1l11_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,l1llllll1_l1_)
	elif l1lll1l1111l_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==56: from l1ll1lllllll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==57: from l1llll1ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==58: from l11ll1l11ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==59: from l1llll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==60: from l1llll11l1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==62: from l1lllll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==63: from l11111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==64: from l111l11l11l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==66: from l11lll111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==67: from l1ll11lll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==68: from l11ll1l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==70: from l1ll111lll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll1l11111_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==74: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_)
	elif l1lll1l1111l_l1_==75: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_)
	elif l1lll1l1111l_l1_==76: from l1ll1ll1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l1111l_l1_==77: from l111llll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==78: from l111ll1l1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==79: from l111ll11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==80: from l111l1lll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l1111l_l1_==81: from l1ll1l11111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,text)
	elif l1lll1l1111l_l1_==82: from l1111ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1l11111_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1111111l11_l1_(code,reason,source,l11_l1_):
	l1111l1111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㗙"))
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㗚"),l1l111_l1_ (u"ࠫࠬ㗛"))
	if l1l111_l1_ (u"ࠬ࠳ࠧ㗜") in source: l1lll11ll1l_l1_ = source.split(l1l111_l1_ (u"࠭࠭ࠨ㗝"),1)[0]
	else: l1lll11ll1l_l1_ = source
	l11l1ll1l1l_l1_ = code in [7,11001,11002,10054]
	l1ll11ll11ll_l1_ = reason.lower()
	l111ll111l1_l1_ = code in [0,104,10061,111]
	l1llllll1lll_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㗞") in l1ll11ll11ll_l1_
	l1llllll1ll1_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㗟") in l1ll11ll11ll_l1_
	l1llllll1l1l_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㗠") in l1ll11ll11ll_l1_
	l1llllll1l11_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㗡") in l1ll11ll11ll_l1_
	l1ll1ll1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ㗢"))
	l1ll1l1lll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ㗣"))
	l1111ll1l1l_l1_ = l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ㗤")
	l1111l1l111_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠧ㗥")+str(code)+l1l111_l1_ (u"ࠨ࠼ࠣࠫ㗦")+reason
	l1111l1l111_l1_ = l111l11_l1_(l1111l1l111_l1_)
	if l111ll111l1_l1_ or l1llllll1lll_l1_ or l1llllll1ll1_l1_ or l1llllll1l1l_l1_ or l1llllll1l11_l1_:
		l1111ll1l1l_l1_ += l1l111_l1_ (u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ㗧")
	if l11l1ll1l1l_l1_: l1111ll1l1l_l1_ += l1l111_l1_ (u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ㗨")
	l1111l1l111_l1_ = l1l111_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㗩")+l1111l1l111_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㗪")
	if l1ll1ll1lll1_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㗫") or l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㗬"):
		l1111ll1l1l_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗭")
	l11lll11ll1_l1_ = False
	if l11_l1_ and source not in l111111llll_l1_:
		if l1ll1ll1lll1_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㗮") or l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㗯"):
			l11l1111ll1_l1_ = l1ll11ll1l1l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㗰"),l1l111_l1_ (u"ࠬิั้ฮࠪ㗱"),l1l111_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬ㗲"),l1l111_l1_ (u"ࠧฦื็หาࠦวๅ็ื็้ฯࠧ㗳"),l1lll11ll1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠬ㗴")+TRANSLATE(l1lll11ll1l_l1_),l1111ll1l1l_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㗵")+l1111l1l111_l1_)
			if l11l1111ll1_l1_==1:
				from l1l11llllll_l1_ import l1lll1l1llll_l1_
				l1lll1l1llll_l1_()
			elif l11l1111ll1_l1_==2: l11lll11ll1_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㗶"),l1l111_l1_ (u"ࠫࠬ㗷"),l1lll11ll1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㗸")+TRANSLATE(l1lll11ll1l_l1_),l1111ll1l1l_l1_,l1111l1l111_l1_)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㗹"),l1111l1111l_l1_)
	return l11lll11ll1_l1_
def l11l1lll1ll_l1_(l1ll1l1ll111_l1_=False,l1ll1ll1l1l1_l1_=[]):
	l1111lll111_l1_ = [l1l1l1111ll_l1_,favoritesfile,l1ll11l1l1l1_l1_]+l1ll1ll1l1l1_l1_
	for filename in os.listdir(addoncachefolder):
		if l1ll1l1ll111_l1_ and (filename.startswith(l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ㗺")) or filename.startswith(l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ㗻"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ㗼")): continue
		l111111l1l1_l1_ = os.path.join(addoncachefolder,filename)
		if l111111l1l1_l1_ in l1111lll111_l1_: continue
		try: os.remove(l111111l1l1_l1_)
		except: pass
	if addonimagesfolder not in l1111lll111_l1_: l1llll1ll1_l1_(addonimagesfolder,True,False)
	time.sleep(1)
	return
def l1llll1l1ll1_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll1l_l1_=True,l1lll1ll1ll1_l1_=True):
	url = url+l1l111_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ㗽")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll1l_l1_,l1lll1ll1ll1_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l1111l1ll11_l1_(l1l111_l1_ (u"ࠫࡍ࡚ࡔࡑࠢࡕࡩࡶࡻࡥࡴࡶࠣࡊࡦ࡯࡬ࡶࡴࡨࠫ㗾"))
	return response
def l1ll1l1ll1ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㗿"),url,l1l111_l1_ (u"࠭ࠧ㘀"),l1l111_l1_ (u"ࠧࠨ㘁"),True,l1l111_l1_ (u"ࠨࠩ㘂"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㘃"),True,False)
	l111l1lllll_l1_ = []
	if response.succeeded:
		html = response.content
		l1lll1ll1111_l1_ = re.findall(l1l111_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭㘄"),html)
		if l1lll1ll1111_l1_: html = l1l111_l1_ (u"ࠫࡡࡴࠧ㘅").join(l1lll1ll1111_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㘆"),l1l111_l1_ (u"࠭ࠧ㘇")).strip(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㘈")).split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㘉"))
		l111l1lllll_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠩ࠱ࠫ㘊"))==3: l111l1lllll_l1_.append(proxy)
	return l111l1lllll_l1_
def l11ll11llll_l1_(*args):
	l11lll1llll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ㘋")
	l1llllllll11_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨ㘌")
	l111ll11111_l1_ = l1ll1l1ll1ll_l1_(l1llllllll11_l1_)
	l111l1lllll_l1_ = l1ll1l1ll1ll_l1_(l11lll1llll_l1_)
	l11lllll1ll_l1_ = l111ll11111_l1_+l111l1lllll_l1_
	l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㘍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬ㘎")+str(len(l111ll11111_l1_))+l1l111_l1_ (u"ࠧࠬࠩ㘏")+str(len(l111l1lllll_l1_))+l1l111_l1_ (u"ࠨࠢࡠࠫ㘐"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㘑"))
	response = l1l1lllll1l_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ㘒"),l1l111_l1_ (u"ࠫࠬ㘓"))
	if proxy or l11lllll1ll_l1_:
		id,l1l1111l111_l1_ = 0,10
		l111lll1111_l1_ = len(l11lllll1ll_l1_)
		l11l111111l_l1_ = l1l1111l111_l1_
		if l111lll1111_l1_>l11l111111l_l1_: counts = l11l111111l_l1_
		else: counts = l111lll1111_l1_
		l11l1l1lll1_l1_ = random.sample(l11lllll1ll_l1_,counts)
		if proxy: l11l1l1lll1_l1_ = [proxy]+l11l1l1lll1_l1_
		threads = l11l11ll111_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l1111l111_l1_ and not threads.l11l1l1l1l1_l1_:
			if id<counts:
				proxy = l11l1l1lll1_l1_[id]
				threads.start_new_thread(id,l1llll1l1ll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㘔"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㘕")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㘖"))
		l11l1l1l1l1_l1_ = threads.l11l1l1l1l1_l1_
		if l11l1l1l1l1_l1_:
			l1111ll1lll_l1_ = threads.l1111ll1lll_l1_
			l1111l11ll1_l1_ = l11l1l1l1l1_l1_[0]
			response = l1111ll1lll_l1_[l1111l11ll1_l1_]
			proxy = l11l1l1lll1_l1_[int(l1111l11ll1_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㘗"),proxy)
			if l1111l11ll1_l1_!=0: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㘘"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㘙")+proxy+l1l111_l1_ (u"ࠫࠥࡣࠧ㘚"))
			else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㘛"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㘜")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㘝"))
	return response
def l1ll1l11ll11_l1_(connection,l1ll11llll11_l1_):
	l11l11l11l1_l1_ = connection.create_connection
	def l1lll1111lll_l1_(address,*args,**kwargs):
		host,port = address
		l1lll1l11l1l_l1_ = DNS_RESOLVER(host,l1ll11llll11_l1_)
		if l1lll1l11l1l_l1_: host = l1lll1l11l1l_l1_[0]
		else:
			if l1ll11llll11_l1_ in l1111llll11_l1_: l1111llll11_l1_.remove(l1ll11llll11_l1_)
			if l1111llll11_l1_:
				l111lll1lll_l1_ = l1111llll11_l1_[0]
				l1lll1l11l1l_l1_ = DNS_RESOLVER(host,l111lll1lll_l1_)
				if l1lll1l11l1l_l1_: host = l1lll1l11l1l_l1_[0]
		address = (host,port)
		return l11l11l11l1_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll1111lll_l1_
	return l11l11l11l1_l1_
def l1ll11ll1lll_l1_(url):
	l11l1lll11l_l1_,l111l1l1l1l_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ㘞"))[2],80
	if l1l111_l1_ (u"ࠩ࠽ࠫ㘟") in l11l1lll11l_l1_: l11l1lll11l_l1_,l111l1l1l1l_l1_ = l11l1lll11l_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬ㘠"))
	l1111ll111l_l1_ = l1l111_l1_ (u"ࠫ࠴࠭㘡")+l1l111_l1_ (u"ࠬ࠵ࠧ㘢").join(url.split(l1l111_l1_ (u"࠭࠯ࠨ㘣"))[3:])
	request = l1l111_l1_ (u"ࠧࡈࡇࡗࠤࠬ㘤")+l1111ll111l_l1_+l1l111_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ㘥")
	request += l1l111_l1_ (u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ㘦")+l11l1lll11l_l1_+l1l111_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㘧")
	request += l1l111_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㘨")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1lll11l_l1_,l111l1l1l1l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠬ࠭㘩")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"࠭࠮ࠨ㘪") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ㘫")
	l1111l111ll_l1_,l1lll111l1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠰ࠪ㘬"),1)
	l1lll111l1l1_l1_,l1lll111l11l_l1_ = l1lll111l1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ㘭"),1)
	server = l1111l111ll_l1_+l1l111_l1_ (u"ࠪ࠲ࠬ㘮")+l1lll111l1l1_l1_
	if type in [l1l111_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ㘯"),l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㘰")] and l1l111_l1_ (u"࠭࠯ࠨ㘱") in server: server = server.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩ㘲"),1)[1]
	if type==l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㘳") and l1l111_l1_ (u"ࠩ࠱ࠫ㘴") in server:
		l1lll1llll11_l1_ = server.split(l1l111_l1_ (u"ࠪ࠲ࠬ㘵"))
		l1l1l11ll1l_l1_ = len(l1lll1llll11_l1_)
		if l1l1l11ll1l_l1_<=2 or l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㘶") in server: l1lll1llll11_l1_ = l1lll1llll11_l1_[0]
		elif l1l1l11ll1l_l1_>=3: l1lll1llll11_l1_ = l1lll1llll11_l1_[1]
		if len(l1lll1llll11_l1_)>1: server = l1lll1llll11_l1_
	return server
def l111lll111l_l1_(l11l11ll1l1_l1_):
	l11l1111lll_l1_ = repr(l11l11ll1l1_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㘷"))).replace(l1l111_l1_ (u"ࠨࠧࠣ㘸"),l1l111_l1_ (u"ࠧࠨ㘹"))
	return l11l1111lll_l1_
def l1ll11l11ll_l1_(string):
	l1ll1l11ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ㘺")
	if PY2: string = string.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㘻"))
	from unicodedata import decomposition
	for l11111l1l1l_l1_ in string:
		if   l11111l1l1l_l1_==l1l111_l1_ (u"ࡸࠫว࠭㘼"): l11l111l1l1_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ㘽")
		elif l11111l1l1l_l1_==l1l111_l1_ (u"ࡺ࠭รࠨ㘾"): l11l111l1l1_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ㘿")
		elif l11111l1l1l_l1_==l1l111_l1_ (u"ࡵࠨฦࠪ㙀"): l11l111l1l1_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ㙁")
		elif l11111l1l1l_l1_==l1l111_l1_ (u"ࡷࠪษࠬ㙂"): l11l111l1l1_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ㙃")
		elif l11111l1l1l_l1_==l1l111_l1_ (u"ࡹࠬฬࠧ㙄"): l11l111l1l1_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭㙅")
		else:
			l1ll11l111l1_l1_ = decomposition(l11111l1l1l_l1_)
			if l1l111_l1_ (u"࠭ࠠࠨ㙆") in l1ll11l111l1_l1_: l11l111l1l1_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸࠫ㙇")+l1ll11l111l1_l1_.split(l1l111_l1_ (u"ࠨࠢࠪ㙈"),1)[1]
			else:
				l11l111l1l1_l1_ = l1l111_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ㙉")+hex(ord(l11111l1l1l_l1_)).replace(l1l111_l1_ (u"ࠪ࠴ࡽ࠭㙊"),l1l111_l1_ (u"ࠫࠬ㙋"))
				l11l111l1l1_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶࠩ㙌")+l11l111l1l1_l1_[-4:]
		l1ll1l11ll1l_l1_ += l11l111l1l1_l1_
	l1ll1l11ll1l_l1_ = l1ll1l11ll1l_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ㙍"),l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ㙎"))
	if PY2: l1ll1l11ll1l_l1_ = l1ll1l11ll1l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㙏")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㙐"))
	else: l1ll1l11ll1l_l1_ = l1ll1l11ll1l_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㙑")).decode(l1l111_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㙒"))
	return l1ll1l11ll1l_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ㙓"),default=l1l111_l1_ (u"࠭ࠧ㙔"),l111lllllll_l1_=False,source=l1l111_l1_ (u"ࠧࠨ㙕")):
	text = l1lll1l1l1l1_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ㙖"),l1l111_l1_ (u"ࠩࠣࠫ㙗")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭㙘"),l1l111_l1_ (u"ࠫࠥ࠭㙙")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ㙚"),l1l111_l1_ (u"࠭ࠠࠨ㙛"))
	if not text and not l111lllllll_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㙜"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ㙝")+text+l1l111_l1_ (u"ࠩࠥࠫ㙞"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㙟"),l1l111_l1_ (u"ࠫࠬ㙠"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㙡"),l1l111_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩ㙢"))
		return l1l111_l1_ (u"ࠧࠨ㙣")
	if text not in [l1l111_l1_ (u"ࠨࠩ㙤"),l1l111_l1_ (u"ࠩࠣࠫ㙥")]:
		text = text.strip(l1l111_l1_ (u"ࠪࠤࠬ㙦"))
		text = l1ll11l11ll_l1_(text)
	if source!=l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭㙧") and l11111l_l1_(l1l111_l1_ (u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧ㙨"),l1l111_l1_ (u"࠭ࠧ㙩"),[text],False):
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㙪"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ㙫")+text+l1l111_l1_ (u"ࠩࠥࠫ㙬"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㙭"),l1l111_l1_ (u"ࠫࠬ㙮"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㙯"),l1l111_l1_ (u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨ㙰"))
		return l1l111_l1_ (u"ࠧࠨ㙱")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㙲"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ㙳")+text+l1l111_l1_ (u"ࠪࠦࠬ㙴"))
	return text
def l1l11l11ll_l1_(l1lllll1_l1_,l1ll1ll1l_l1_={}):
	url,l11111l11ll_l1_,l1ll1ll11_l1_,l111llll111_l1_ = l1lllll1_l1_,{},{},l1l111_l1_ (u"ࠫࠬ㙵")
	if l1l111_l1_ (u"ࠬࢂࠧ㙶") in l1lllll1_l1_: url,l11111l11ll_l1_ = l1ll11ll1_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡼࠨ㙷"))
	l1lll11llll1_l1_ = list(set(list(l1ll1ll1l_l1_.keys())+list(l11111l11ll_l1_.keys())))
	for key in l1lll11llll1_l1_:
		if key in list(l11111l11ll_l1_.keys()): l1ll1ll11_l1_[key] = l11111l11ll_l1_[key]
		else: l1ll1ll11_l1_[key] = l1ll1ll1l_l1_[key]
	if l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㙸") not in l1lll11llll1_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㙹")] = l1l1ll11l_l1_()
	if l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㙺") not in l1lll11llll1_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㙻")] = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㙼"))
	for key in list(l1ll1ll11_l1_.keys()): l111llll111_l1_ += l1l111_l1_ (u"ࠬࠬࠧ㙽")+key+l1l111_l1_ (u"࠭࠽ࠨ㙾")+l1ll1ll11_l1_[key]
	if l111llll111_l1_: l111llll111_l1_ = l1l111_l1_ (u"ࠧࡽࠩ㙿")+l111llll111_l1_[1:]
	response = l11l1l_l1_(l1llll11l111_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㚀"),url,l1l111_l1_ (u"ࠩࠪ㚁"),l1ll1ll11_l1_,l1l111_l1_ (u"ࠪࠫ㚂"),l1l111_l1_ (u"ࠫࠬ㚃"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ㚄"),False,False)
	html = response.content
	if l1l111_l1_ (u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ㚅") not in html: return [l1l111_l1_ (u"ࠧ࠮࠳ࠪ㚆")],[url+l111llll111_l1_]
	if l1l111_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ㚇") in html: return [l1l111_l1_ (u"ࠩ࠰࠵ࠬ㚈")],[url+l111llll111_l1_]
	if l1l111_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ㚉") in html: return [l1l111_l1_ (u"ࠫ࠲࠷ࠧ㚊")],[url+l111llll111_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111ll1l111_l1_,l1lll1lll1l1_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠲ࡏࡎࡇ࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭㚋"),html+l1l111_l1_ (u"࠭࡜࡯ࠩ㚌"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠧ࠮࠳ࠪ㚍")],[url+l111llll111_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1ll1l111lll_l1_,l11ll11l111_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠨࠩ㚎")
		items = line.split(l1l111_l1_ (u"ࠩ࠯ࠫ㚏"))
		for item in items:
			if l1l111_l1_ (u"ࠪࡁࠬ㚐") in item:
				key,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭㚑"),1)
				l1ll1l111lll_l1_[key.lower()] = value
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㚒") in line.lower():
			l11ll11l111_l1_ = int(l1ll1l111lll_l1_[l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㚓")])//1024
			title += str(l11ll11l111_l1_)+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㚔")
		elif l1l111_l1_ (u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㚕") in line.lower():
			l11ll11l111_l1_ = int(l1ll1l111lll_l1_[l1l111_l1_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㚖")])//1024
			title += str(l11ll11l111_l1_)+l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㚗")
		if l1l111_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㚘") in line.lower():
			l111l1ll_l1_ = int(l1ll1l111lll_l1_[l1l111_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㚙")].split(l1l111_l1_ (u"࠭ࡸࠨ㚚"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠪ㚛")
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠣࠫ㚜"))
		if not title: title = l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ㚝")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㚞")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࠴࠵ࠧ㚟")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠬࡀࠧ㚠"),1)[0]+l1l111_l1_ (u"࠭࠺ࠨ㚡")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠰ࠩ㚢")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㚣"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ㚤"),1)[0]+l1l111_l1_ (u"ࠪ࠳ࠬ㚥")+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭㚦") in list(l1ll1l111lll_l1_.keys()):
			l111lllll_l1_ = l1ll1l111lll_l1_[l1l111_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㚧")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"࠭ࠢࠨ㚨"),l1l111_l1_ (u"ࠧࠨ㚩")).replace(l1l111_l1_ (u"ࠣࠩࠥ㚪"),l1l111_l1_ (u"ࠩࠪ㚫")).split(l1l111_l1_ (u"ࠪࠧࠬ㚬"),1)[0]
			l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l111lllll_l1_)
			if l11ll1l1l1_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠫࠥࠦࠧ㚭")+l11ll1l1l1_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠬࠦࠠࡑࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩࠬ㚮")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ㚯")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㚰"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111ll1l111_l1_.append(l111l1ll_l1_)
			l1lll1lll1l1_l1_.append(l11ll11l111_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠥࠪ㚱"),1)[0]
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l1l1_l1_: title = title+l1l111_l1_ (u"ࠩࠣࠤࠬ㚲")+l11ll1l1l1_l1_
		title = title+l1l111_l1_ (u"ࠪࠤࠥ࠭㚳")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㚴"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111ll1l111_l1_.append(l111l1ll_l1_)
		l1lll1lll1l1_l1_.append(l11ll11l111_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111ll1l111_l1_,l1lll1lll1l1_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111ll1l111_l1_,l1lll1lll1l1_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	l1ll11l11l1l_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_: l1ll11l11l1l_l1_.append(l1ll1ll_l1_+l111llll111_l1_)
	return l1l1lll1_l1_,l1ll11l11l1l_l1_
def DNS_RESOLVER(host,l1ll11llll11_l1_=l1l111_l1_ (u"ࠬ࠭㚵")):
	if not l1ll11llll11_l1_: l1ll11llll11_l1_ = l1111llll11_l1_[0]
	if host.replace(l1l111_l1_ (u"࠭࠮ࠨ㚶"),l1l111_l1_ (u"ࠧࠨ㚷")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1lllll1l11l_l1_ = pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚸"), 12049)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚹"), 256)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㚺"), 1)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㚻"), 0)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚼"), 0)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㚽"), 0)
		if PY3: l11111111l1_l1_ = host.split(l1l111_l1_ (u"ࠧ࠯ࠩ㚾"))
		else: l11111111l1_l1_ = host.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㚿")).split(l1l111_l1_ (u"ࠩ࠱ࠫ㛀"))
		for part in l11111111l1_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛁"))
			l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠦࡇࠨ㛂"), len(part))
			for l111l1l11l1_l1_ in part:
				l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠧࡩࠢ㛃"), l111l1l11l1_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㛄")))
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠢࡃࠤ㛅"), 0)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㛆"), 1)
		l1lllll1l11l_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㛇"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1lllll1l11l_l1_), (l1ll11llll11_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1ll11ll_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ㛈"), data, 0)
		l111lll1l11_l1_ = l11l1ll11ll_l1_[3]
		offset = len(host)+18
		l11l11l1l11_l1_ = []
		for _ in range(l111lll1l11_l1_):
			l111ll11ll1_l1_ = offset
			l1llll1llll1_l1_ = 1
			l1111ll1l11_l1_ = False
			while True:
				l111l1l11l1_l1_ = unpack_from(l1l111_l1_ (u"ࠦࡃࡈࠢ㛉"), data, l111ll11ll1_l1_)[0]
				if l111l1l11l1_l1_ == 0:
					l111ll11ll1_l1_ += 1
					break
				if l111l1l11l1_l1_ >= 192:
					l111l11l1ll_l1_ = unpack_from(l1l111_l1_ (u"ࠧࡄࡂࠣ㛊"), data, l111ll11ll1_l1_ + 1)[0]
					l111ll11ll1_l1_ = ((l111l1l11l1_l1_ << 8) + l111l11l1ll_l1_ - 0xc000) - 1
					l1111ll1l11_l1_ = True
				l111ll11ll1_l1_ += 1
				if l1111ll1l11_l1_ == False: l1llll1llll1_l1_ += 1
			if l1111ll1l11_l1_ == True: l1llll1llll1_l1_ += 1
			offset = offset + l1llll1llll1_l1_
			l11llll1lll_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࡉࡊࡌࡌࠧ㛋"), data, offset)
			offset = offset + 10
			l11l1ll1lll_l1_ = l11llll1lll_l1_[0]
			l1111ll1ll1_l1_ = l11llll1lll_l1_[3]
			if l11l1ll1lll_l1_ == 1:
				l111l1l1l11_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࠤ㛌")+l1l111_l1_ (u"ࠣࡄࠥ㛍")*l1111ll1ll1_l1_, data, offset)
				l1lll1l11l1l_l1_ = l1l111_l1_ (u"ࠩࠪ㛎")
				for l111l1l11l1_l1_ in l111l1l1l11_l1_: l1lll1l11l1l_l1_ += str(l111l1l11l1_l1_) + l1l111_l1_ (u"ࠪ࠲ࠬ㛏")
				l1lll1l11l1l_l1_ = l1lll1l11l1l_l1_[0:-1]
				l11l11l1l11_l1_.append(l1lll1l11l1l_l1_)
			if l11l1ll1lll_l1_ in [1,2,5,6,15,28]: offset = offset + l1111ll1ll1_l1_
	except: l11l11l1l11_l1_ = []
	if not l11l11l1l11_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㛐"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ㛑")+host+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㛒"))
	return l11l11l1l11_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1ll11l1_l1_ = [l1l111_l1_ (u"ࠧไสสีࠬ㛓"),l1l111_l1_ (u"ࠨสส่฿࠭㛔"),l1l111_l1_ (u"ࠩࡤࡨࡺࡲࡴࠨ㛕"),l1l111_l1_ (u"ࠪࡼࡽ࠭㛖"),l1l111_l1_ (u"ࠫࡸ࡫ࡸࠨ㛗")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㛘"):
			l11l1ll11l1_l1_ += [l1l111_l1_ (u"࠭ࡲ࠻ࠩ㛙"),l1l111_l1_ (u"ࠧࡳ࠯ࠪ㛚"),l1l111_l1_ (u"ࠨ࠯ࡰࡥࠬ㛛")]
			l11l1ll11l1_l1_ += [l1l111_l1_ (u"ࠩ࠽ࡶࠬ㛜"),l1l111_l1_ (u"ࠪ࠱ࡷ࠭㛝"),l1l111_l1_ (u"ࠫࡲࡧ࠭ࠨ㛞")]
		for l1111lllll_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ㛟") in l1111lllll_l1_: continue
			if l1l111_l1_ (u"࠭อๅไฬࠫ㛠") in l1111lllll_l1_: continue
			l1111lllll_l1_ = l1111lllll_l1_.lower()
			if PY2: l1111lllll_l1_ = l1111lllll_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㛡")).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㛢"))
			l1111lllll_l1_ = l1111lllll_l1_.replace(l1l111_l1_ (u"ࠩ࠽ࠫ㛣"),l1l111_l1_ (u"ࠪࠫ㛤"))
			l111l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ㛥"),l1111lllll_l1_,re.DOTALL)
			l1lll1llll1l_l1_ = False
			for digits in l111l1l1111_l1_:
				if len(digits)==2:
					l1lll1llll1l_l1_ = True
					break
			if l1l111_l1_ (u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ㛦") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ㛧") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"ࠧ฻์ิࠤ๊฻ๆโࠩ㛨") in l1111lllll_l1_: continue
			elif l1l11l11111_l1_(l1l111_l1_ (u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ㛩")): continue
			elif l1111lllll_l1_ in [l1l111_l1_ (u"ࠩࡵࠫ㛪")] or l1lll1llll1l_l1_ or any(value in l1111lllll_l1_ for value in l11l1ll11l1_l1_):
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㛫"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㛬")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㛭"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㛮"),l1l111_l1_ (u"ࠧศๆไ๎ิ๐่ࠡๆ็็ออัࠡใๅ฻ࠥ๎ร็ษ้๋ࠣ฿ส่ࠩ㛯"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll1lll1ll_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㛰")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠩสืฯ๋ัศำࠪ㛱")
		header = args[2]
		text = l1l111_l1_ (u"ࠪࡠࡳ࠭㛲").join(args[3:])
	else: l1lll1lll1ll_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠫࠬ㛳"),l1l111_l1_ (u"ࠬࡕࡋࠨ㛴"),l1l111_l1_ (u"࠭ࠧ㛵"),l1l111_l1_ (u"ࠧࠨ㛶")
	l1ll11ll1l1l_l1_(l1lll1lll1ll_l1_,l1l111_l1_ (u"ࠨࠩ㛷"),l11l111l_l1_,l1l111_l1_ (u"ࠩࠪ㛸"),header,text,**kwargs)
	return
def l1ll11ll1l_l1_(*args,**kwargs):
	l1lll1lll1ll_l1_ = args[0]
	l1lllll1l1l1_l1_ = args[1]
	l1llll1ll1l1_l1_ = args[2]
	if l1llll1ll1l1_l1_ or l1lllll1l1l1_l1_: l1lllll11ll1_l1_ = True
	else: l1lllll11ll1_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㛹")
	if not l1lllll1l1l1_l1_: l1lllll1l1l1_l1_ = l1l111_l1_ (u"่๊ࠫวࠡࠢࡑࡳࠬ㛺")
	if not l1llll1ll1l1_l1_: l1llll1ll1l1_l1_ = l1l111_l1_ (u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ㛻")
	if len(args)>=6: text += l1l111_l1_ (u"࠭࡜࡯ࠩ㛼")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠧ࡝ࡰࠪ㛽")+args[6]
	l11l1111ll1_l1_ = l1ll11ll1l1l_l1_(l1lll1lll1ll_l1_,l1lllll1l1l1_l1_,l1l111_l1_ (u"ࠨࠩ㛾"),l1llll1ll1l1_l1_,header,text,**kwargs)
	if l11l1111ll1_l1_==-1 and l1lllll11ll1_l1_: l11l1111ll1_l1_ = -1
	elif l11l1111ll1_l1_==-1 and not l1lllll11ll1_l1_: l11l1111ll1_l1_ = False
	elif l11l1111ll1_l1_==0: l11l1111ll1_l1_ = False
	elif l11l1111ll1_l1_==2: l11l1111ll1_l1_ = True
	return l11l1111ll1_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㛿") in list(kwargs.keys()): l11llllllll_l1_ = kwargs[l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㜀")]
	else: l11llllllll_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ㜁") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ㜂")
	l1ll1l1l1ll1_l1_ = l1l1l1lllll_l1_(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭㜃"),l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㜄"),l1l111_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㜅"))
	l11111lll1l_l1_ = l1ll1l111111_l1_.replace(l1l111_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ㜆"),l1l111_l1_ (u"ࠪࡣࠬ㜇")+str(time.time())+l1l111_l1_ (u"ࠫࡤ࠭㜈"))
	l11111lll1l_l1_ = l11111lll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㜉"),l1l111_l1_ (u"࠭࡜࡝࡞࡟ࠫ㜊")).replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪ㜋"),l1l111_l1_ (u"ࠨ࠱࠲࠳࠴࠭㜌"))
	l11l111l111_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠩࠪ㜍"),l1l111_l1_ (u"ࠪࠫ㜎"),l1l111_l1_ (u"ࠫࠬ㜏"),header,text,profile,l1l111_l1_ (u"ࠬࡲࡥࡧࡶࠪ㜐"),False,l11111lll1l_l1_)
	l1ll1l1l1ll1_l1_.show()
	if profile==l1l111_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ㜑"):
		l1ll1l1l1ll1_l1_.getControl(9040).setHeight(215)
		l1ll1l1l1ll1_l1_.getControl(9040).setPosition(55,-80)
		l1ll1l1l1ll1_l1_.getControl(9050).setPosition(120,-60)
		l1ll1l1l1ll1_l1_.getControl(400).setPosition(90,-35)
	l1ll1l1l1ll1_l1_.getControl(401).setVisible(False)
	l1ll1l1l1ll1_l1_.getControl(402).setVisible(False)
	l1ll1l1l1ll1_l1_.getControl(9050).setImage(l11111lll1l_l1_)
	l1ll1l1l1ll1_l1_.getControl(9050).setHeight(l11l111l111_l1_)
	l11lllll111_l1_ = threading.Thread(target=l1ll11l11l11_l1_,args=(l1ll1l1l1ll1_l1_,l11111lll1l_l1_,l11llllllll_l1_))
	l11lllll111_l1_.start()
	return
def l1ll11l11l11_l1_(l1ll1l1l1ll1_l1_,l11111lll1l_l1_,l11llllllll_l1_):
	time.sleep(l11llllllll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l11111lll1l_l1_):
		try: os.remove(l11111lll1l_l1_)
		except: pass
	return
def l1ll1ll11l1l_l1_(*args,**kwargs):
	header,text,profile,l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠧࠨ㜒"),l1l111_l1_ (u"ࠨࠩ㜓"),l1l111_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㜔"),l1l111_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㜕")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll1lll1ll_l1_ = args[3]
	return l1l11l1l1l_l1_(l1lll1lll1ll_l1_,header,text,profile)
def l11ll1111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1lll111llll_l1_(*args,**kwargs)
def l1l11111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1lll1l1l1l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l111lll1_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll11lll1_l1_(l1llll1l1lll_l1_):
	if kodi_version>17.99: l1ll1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩ㜖")
	else: l1ll1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩ㜗")
	l1llll1l1lll_l1_ = l1llll1l1lll_l1_.lower()
	if l1llll1l1lll_l1_==l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㜘"): xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩ㜙")+l1ll1l1l1ll1_l1_+l1l111_l1_ (u"ࠨࠫࠪ㜚"))
	elif l1llll1l1lll_l1_==l1l111_l1_ (u"ࠩࡶࡸࡴࡶࠧ㜛"): xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪ㜜")+l1ll1l1l1ll1_l1_+l1l111_l1_ (u"ࠫ࠮࠭㜝"))
	return
def l1ll11ll1l1l_l1_(l1lll1lll1ll_l1_,l111l1lll1l_l1_=l1l111_l1_ (u"ࠬ࠭㜞"),l1ll1lll11l1_l1_=l1l111_l1_ (u"࠭ࠧ㜟"),l1lllllll111_l1_=l1l111_l1_ (u"ࠧࠨ㜠"),header=l1l111_l1_ (u"ࠨࠩ㜡"),text=l1l111_l1_ (u"ࠩࠪ㜢"),profile=l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㜣"),l1lllll11l11_l1_=0,l1lll11lll1l_l1_=0):
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㜤")
	l1ll1l1l1ll1_l1_ = l1ll1llllll1_l1_(l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㜥"),l1l1l1l1l11_l1_,l1l111_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㜦"),l1l111_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㜧"))
	l1ll1l1l1ll1_l1_.l11l11ll1ll_l1_(l111l1lll1l_l1_,l1ll1lll11l1_l1_,l1lllllll111_l1_,header,text,profile,l1lll1lll1ll_l1_,l1lllll11l11_l1_,l1lll11lll1l_l1_)
	if l1lllll11l11_l1_>0: l1ll1l1l1ll1_l1_.l11llll11ll_l1_()
	if l1lll11lll1l_l1_>0: l1ll1l1l1ll1_l1_.l11ll1llll1_l1_()
	if l1lllll11l11_l1_==0 and l1lll11lll1l_l1_==0: l1ll1l1l1ll1_l1_.l11l11l1ll1_l1_()
	l1ll1l1l1ll1_l1_.doModal()
	l11l1111ll1_l1_ = l1ll1l1l1ll1_l1_.l11llll1ll1_l1_
	return l11l1111ll1_l1_
def l1l11l1l1l_l1_(l1lll1lll1ll_l1_,header,text,profile=l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㜨")):
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㜩")
	l1ll1l1l1ll1_l1_ = l1l1l1lllll_l1_(l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭㜪"),l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㜫"),l1l111_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㜬"))
	l11111lll1l_l1_ = l1ll1l111111_l1_.replace(l1l111_l1_ (u"࠭࡟࠱࠲࠳࠴ࡤ࠭㜭"),l1l111_l1_ (u"ࠧࡠࠩ㜮")+str(time.time())+l1l111_l1_ (u"ࠨࡡࠪ㜯"))
	l11111lll1l_l1_ = l11111lll1l_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ㜰"),l1l111_l1_ (u"ࠪࡠࡡࡢ࡜ࠨ㜱")).replace(l1l111_l1_ (u"ࠫ࠴࠵ࠧ㜲"),l1l111_l1_ (u"ࠬ࠵࠯࠰࠱ࠪ㜳"))
	l11l111l111_l1_ = CREATE_IMAGE(l1l111_l1_ (u"࠭ࠧ㜴"),l1l111_l1_ (u"ࠧࠨ㜵"),l1l111_l1_ (u"ࠨࠩ㜶"),header,text,profile,l1lll1lll1ll_l1_,False,l11111lll1l_l1_)
	l1ll1l1l1ll1_l1_.show()
	l1ll1l1l1ll1_l1_.getControl(9050).setHeight(l11l111l111_l1_)
	l1ll1l1l1ll1_l1_.getControl(9050).setImage(l11111lll1l_l1_)
	result = l1ll1l1l1ll1_l1_.doModal()
	try: os.remove(l11111lll1l_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1lll11l11ll_l1_=True):
	if l1lll11l11ll_l1_:
		l11ll1l1ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡶࡸࡷ࠭㜷"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㜸"),l1l111_l1_ (u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧ㜹"))
		if l11ll1l1ll_l1_: return l11ll1l1ll_l1_
	text = l1l111_l1_ (u"ࠬ࠭㜺")
	if 0 and response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧ㜻"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㜼"),html,re.DOTALL)
			text = text[0]
	if not text:
		l111111111l_l1_ = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㜽"),l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶࠪ㜾"))
		text = open(l111111111l_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㜿")).read()
		if PY3: text = text.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㝀"))
		text = text.replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㝁"),l1l111_l1_ (u"࠭ࠧ㝂"))
	l11111l111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨ㝃"),text,re.DOTALL)
	l11ll11ll11_l1_ = []
	for line in l11111l111l_l1_:
		l1llll1l1l11_l1_ = line.lower()
		if l1l111_l1_ (u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩ㝄") in l1llll1l1l11_l1_: continue
		if l1l111_l1_ (u"ࠩࡸࡦࡺࡴࡴࡶࠩ㝅") in l1llll1l1l11_l1_: continue
		if l1l111_l1_ (u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪ㝆") in l1llll1l1l11_l1_: continue
		if l1l111_l1_ (u"ࠫࡨࡸ࡯ࡴࠩ㝇") in l1llll1l1l11_l1_: continue
		l11ll11ll11_l1_.append(line)
	l11ll1l1ll_l1_ = random.sample(l11ll11ll11_l1_,1)
	l11ll1l1ll_l1_ = l11ll1l1ll_l1_[0]
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㝈"),l1l111_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㝉"),l11ll1l1ll_l1_,l11l1l1_l1_)
	return l11ll1l1ll_l1_
def l11ll111111_l1_(l111l11ll11_l1_=l1l111_l1_ (u"ࠧࠨ㝊")):
	if not l111l11ll11_l1_: l111l11ll11_l1_ = traceback.format_exc()
	if l111l11ll11_l1_!=l1l111_l1_ (u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ㝋"): sys.stderr.write(l111l11ll11_l1_)
	lines = l111l11ll11_l1_.splitlines()
	error = lines[-1]
	l111ll11lll_l1_ = open(l111llll1l1_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㝌")).read()
	if PY3: l111ll11lll_l1_ = l111ll11lll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㝍"))
	l111ll11lll_l1_ = l111ll11lll_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠫࡂ࠭㝎")*100
	if sep in l111ll11lll_l1_: l111ll11lll_l1_ = l111ll11lll_l1_.rsplit(sep,1)[1]
	if error in l111ll11lll_l1_: l111ll11lll_l1_ = l111ll11lll_l1_.rsplit(error,1)[0]
	l1lll1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫ㝏"),l111ll11lll_l1_,re.DOTALL)
	for typ,source in reversed(l1lll1111l1l_l1_):
		if source: break
	else: source = l1l111_l1_ (u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭㝐")
	file,line,func = l1l111_l1_ (u"ࠧࠨ㝑"),l1l111_l1_ (u"ࠨࠩ㝒"),l1l111_l1_ (u"ࠩࠪ㝓")
	l11ll111l11_l1_ = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㝔")+error
	l1lll11l1111_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅึัิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㝕")+source
	for l1lllll1l111_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦࠬ㝖") in l1lllll1l111_l1_ and l1l111_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㝗") in l1lllll1l111_l1_: break
	l1lllll1l111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪ㝘"),l1lllll1l111_l1_,re.DOTALL)
	if l1lllll1l111_l1_:
		file,line,func = l1lllll1l111_l1_[0]
		if l1l111_l1_ (u"ࠨ࠱ࠪ㝙") in file: file = file.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ㝚"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠪࡠࡡ࠭㝛"),1)[1]
		l1ll1l1l1111_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅๅใ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝜")+file
		line2 = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิูิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㝝")+line
		l11llll1l11_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ๆห๋ࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㝞")+func
		l1lllll11lll_l1_ = l1ll1l1l1111_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㝟")+line2+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝠")+l11llll1l11_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝡")+l1lll11l1111_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㝢")+l11ll111l11_l1_
		l1llll11l1l1_l1_ = line2+l1l111_l1_ (u"ࠫࡡࡴࠧ㝣")+l1lll11l1111_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝤")+l11ll111l11_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㝥")+l1ll1l1l1111_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㝦")+l11llll1l11_l1_
		l111111l111_l1_ = line2+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝧")+l11ll111l11_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝨")+l1ll1l1l1111_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㝩")+l11llll1l11_l1_
	else:
		l1ll1l1l1111_l1_,line2,l11llll1l11_l1_ = l1l111_l1_ (u"ࠫࠬ㝪"),l1l111_l1_ (u"ࠬ࠭㝫"),l1l111_l1_ (u"࠭ࠧ㝬")
		l1lllll11lll_l1_ = l1lll11l1111_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㝭")+l11ll111l11_l1_
		l1llll11l1l1_l1_ = l1lll11l1111_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㝮")+l11ll111l11_l1_
		l111111l111_l1_ = l11ll111l11_l1_
	l11l11lll1l_l1_ = l1l111_l1_ (u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭㝯")+l1l111_l1_ (u"ࠪࡠࡳ࠭㝰")
	l1ll1l1l1l11_l1_ = l111llllll1_l1_()
	l1lllllll1l1_l1_ = []
	l1lll_l1_ = l1ll1l1l1l11_l1_[l1l111_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㝱")]
	l1lllll11l1l_l1_ = l1ll11l1l11l_l1_(l1l11l111l1_l1_)
	if l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㝲") in list(l1ll1l1l1l11_l1_.keys()):
		for l1lll11l111l_l1_,l111l111ll1_l1_,l11ll111ll1_l1_ in l1lll_l1_: l1lllllll1l1_l1_ = max(l1lllllll1l1_l1_,l111l111ll1_l1_)
		if l1lllll11l1l_l1_<l1lllllll1l1_l1_:
			header = l1l111_l1_ (u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ㝳")
			l11l1111ll1_l1_ = l1ll11ll1l1l_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㝴"),l1l111_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㝵"),l1l111_l1_ (u"ࠩอัิ๐หࠨ㝶"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㝷"),l11l11lll1l_l1_+header,l1lllll11lll_l1_)
			if l11l1111ll1_l1_==0:
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㝸"),l1l111_l1_ (u"ࠬิั้ฮࠪ㝹"),l1l111_l1_ (u"࠭สฮัํฯࠬ㝺"),l1l111_l1_ (u"ࠧࠨ㝻"),header)
				if l1llll111l_l1_==1: l11l1111ll1_l1_ = 1
			if l11l1111ll1_l1_==1:
				from l1l11llllll_l1_ import l1llll1ll11l_l1_
				l1llll1ll11l_l1_()
			return
	l1ll11l111ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㝼"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㝽"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㝾"))
	if not l1ll11l111ll_l1_: l1ll11l111ll_l1_ = []
	l1llll11l1l1_l1_ = l1llll11l1l1_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㝿"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㞀")).replace(l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ㞁"),l1l111_l1_ (u"ࠧࠨ㞂")).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㞃"),l1l111_l1_ (u"ࠩࠪ㞄")).replace(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㞅"),l1l111_l1_ (u"ࠫࠬ㞆"))
	l111111l111_l1_ = l111111l111_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㞇"),l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㞈")).replace(l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㞉"),l1l111_l1_ (u"ࠨࠩ㞊")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㞋"),l1l111_l1_ (u"ࠪࠫ㞌")).replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㞍"),l1l111_l1_ (u"ࠬ࠭㞎"))
	l1ll11ll11l1_l1_ = l1l11l111l1_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ㞏")+l111111l111_l1_
	if l1ll11ll11l1_l1_ in l1ll11l111ll_l1_:
		header = l1l111_l1_ (u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㞐")
		l1111l1_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㞑"),l1l111_l1_ (u"ࠩࠪ㞒"),l11l11lll1l_l1_+header,l1lllll11lll_l1_)
		return
	l1ll11lll1ll_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠪ࠲ࠬ㞓"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㞔")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㞕"),url,l1l111_l1_ (u"࠭ࠧ㞖"),l1l111_l1_ (u"ࠧࠨ㞗"),l1l111_l1_ (u"ࠨࠩ㞘"),l1l111_l1_ (u"ࠩࠪ㞙"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ㞚"),False,False)
	html = response.content
	l11ll1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫ㞛"),html,re.DOTALL)
	for l11l11ll11l_l1_,l11ll1111ll_l1_,l1111l11l11_l1_,l1llll11l11l_l1_ in l11ll1lll1l_l1_:
		l11l11ll11l_l1_ = l11l11ll11l_l1_.split(l1l111_l1_ (u"ࠬ࠱ࠧ㞜"))
		l1111l11l11_l1_ = l1111l11l11_l1_.split(l1l111_l1_ (u"࠭ࠫࠨ㞝"))
		l1llll11l11l_l1_ = l1llll11l11l_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㞞"))
		if line in l11l11ll11l_l1_ and error==l11ll1111ll_l1_ and l1l11l111l1_l1_ in l1111l11l11_l1_ and l1ll11lll1ll_l1_ in l1llll11l11l_l1_:
			header = l1l111_l1_ (u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭㞟")
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㞠"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㞡"),l1l111_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㞢"),l11l11lll1l_l1_+header,l1lllll11lll_l1_)
			if l1llll111l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㞣"),l1l111_l1_ (u"࠭ࠧ㞤"),l1l111_l1_ (u"ࠧࠨ㞥"),header)
			return
	header = l1l111_l1_ (u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㞦")
	l1111l1_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㞧"),l1l111_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㞨"),l11l11lll1l_l1_+header,l1lllll11lll_l1_)
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㞩"),l1l111_l1_ (u"ࠬ࠭㞪"),l1l111_l1_ (u"࠭ࠧ㞫"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㞬"),l1l111_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩ㞭"))
	if l1llll111l_l1_==1: l1ll11ll1ll1_l1_ = l1l111_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ㞮")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㞯"),l1l111_l1_ (u"ࠫࠬ㞰"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㞱"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫ㞲"))
		return
	message = l1llll11l1l1_l1_
	from l1l11llllll_l1_ import l11l1l11ll1_l1_
	succeeded = l11l1l11ll1_l1_(l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡹࠧ㞳"),message,True,l1l111_l1_ (u"ࠨࠩ㞴"),l1l111_l1_ (u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ㞵"),l1ll11ll1ll1_l1_)
	if succeeded and l1ll11ll1ll1_l1_:
		l1ll11l111ll_l1_.append(l1ll11ll11l1_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㞶"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㞷"),l1ll11l111ll_l1_,l1ll111ll11_l1_)
	return
def l1lll11l1l11_l1_(data):
	if PY3: data = data.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㞸"))
	filename = l1l111_l1_ (u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭㞹")+str(time.time())+l1l111_l1_ (u"ࠧ࠯ࡦࡤࡸࠬ㞺")
	open(filename,l1l111_l1_ (u"ࠨࡹࡥࠫ㞻")).write(data)
	return
def l11lll1l1l1_l1_(l111lll11l1_l1_):
	if l111lll11l1_l1_:
		l1lll11111ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㞼"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㞽"),l1l111_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㞾"))
		if l1lll11111ll_l1_: return l1lll11111ll_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㞿")][5]
	l1ll11l11lll_l1_ = l1l11l1ll11_l1_(32,l111lll11l1_l1_)
	l1ll1l11l11l_l1_ = l1111lll1l1_l1_()
	l1llll1l11l1_l1_ = l1ll1l11l11l_l1_.split(l1l111_l1_ (u"࠭ࠬࠨ㟀"))[2]
	l1ll1lll1lll_l1_ = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㟁"))
	l111111ll1l_l1_ = l1ll1l11l1ll_l1_()
	payload = {l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㟂"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ㟃"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㟄"):l1llll1l11l1_l1_,l1l111_l1_ (u"ࠫ࡮ࡪࡳࠨ㟅"):l1lll1ll11l1_l1_(l111111ll1l_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㟆"),url,payload,l1l111_l1_ (u"࠭ࠧ㟇"),l1l111_l1_ (u"ࠧࠨ㟈"),l1l111_l1_ (u"ࠨࠩ㟉"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ㟊"))
	if not response.succeeded: return []
	html = response.content
	l1lll11111ll_l1_ = html.replace(l1l111_l1_ (u"ࠪࡠࡡࡸࠧ㟋"),l1l111_l1_ (u"ࠫࡡࡴࠧ㟌")).replace(l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㟍"),l1l111_l1_ (u"࠭࡜࡯ࠩ㟎")).replace(l1l111_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㟏"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㟐")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ㟑"),l1l111_l1_ (u"ࠪࡠࡳ࠭㟒"))
	l1lll11111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧ㟓"),l1lll11111ll_l1_,re.DOTALL)
	if not l1lll11111ll_l1_: return []
	l1lll11111ll_l1_ = sorted(l1lll11111ll_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1ll11l11lll_l1_,l111l111lll_l1_,l11l11l1l11_l1_,l11l11l1111_l1_,reason = l1lll11111ll_l1_[0]
	l1llll11ll11_l1_ = reason if l1l11l11111_l1_(l1l111_l1_ (u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ㟔")) else l111l111lll_l1_
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ㟕"),l1llll11ll11_l1_)
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㟖"),l1l111_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㟗"),l1lll11111ll_l1_,l11l1l1_l1_)
	return l1lll11111ll_l1_
def SPLIT_BIGLIST(items,l1ll11ll1111_l1_=0,l111111l11l_l1_=0):
	if l1ll11ll1111_l1_ and not l111111l11l_l1_: l111111l11l_l1_ = len(items)//l1ll11ll1111_l1_
	l1lll1ll1l11_l1_,l1l111llll_l1_,l1llll1l1l1l_l1_ = [],-1,0
	for item in items:
		if l1llll1l1l1l_l1_%l111111l11l_l1_==0:
			l1l111llll_l1_ += 1
			l1lll1ll1l11_l1_.append([])
		l1lll1ll1l11_l1_[l1l111llll_l1_].append(item)
		l1llll1l1l1l_l1_ += 1
	return l1lll1ll1l11_l1_
def l111llll11l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࠨ㟘") not in filename or l1l111_l1_ (u"ࠪࡑ࠸࡛࡟ࠨ㟙") not in filename: text = str(data)
	else:
		l1lll1ll1l11_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠫࠬ㟚")
		for split in l1lll1ll1l11_l1_:
			text += str(split)+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㟛")
		text = text.strip(l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㟜"))
	l1l1l1l111l_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠧࡸࡤࠪ㟝")).write(l1l1l1l111l_l1_)
	return
def l11ll11l1ll_l1_(l1l1l1ll11l_l1_,filename):
	if l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㟞"): data = {}
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㟟"): data = []
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㟠"): data = l1l111_l1_ (u"ࠫࠬ㟡")
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠬ࡯࡮ࡵࠩ㟢"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1l111l_l1_ = open(filepath,l1l111_l1_ (u"࠭ࡲࡣࠩ㟣")).read()
	text = zlib.decompress(l1l1l1l111l_l1_)
	if l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㟤") not in text: data = eval(text)
	else:
		l1lll1ll1l11_l1_ = text.split(l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㟥"))
		del text
		data = []
		l11l1l1ll1l_l1_ = l11l11ll111_l1_()
		id = 0
		for split in l1lll1ll1l11_l1_:
			l11l1l1ll1l_l1_.l11l111llll_l1_(str(id),eval,split)
			id += 1
		del l1lll1ll1l11_l1_
		l11l1l1ll1l_l1_.l1lll1l1l111_l1_()
		l11l1l1ll1l_l1_.l1ll11l1llll_l1_()
		l1ll1l11l111_l1_ = list(l11l1l1ll1l_l1_.l1111ll1lll_l1_.keys())
		l1ll1ll11lll_l1_ = sorted(l1ll1l11l111_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll1ll11lll_l1_:
			data += l11l1l1ll1l_l1_.l1111ll1lll_l1_[id]
	return data
def l1ll1lllll1l_l1_(addon_id):
	l11l1llllll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ㟦"),addon_id,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭㟧"))
	try: l1l111111l1_l1_ = open(l11l1llllll_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㟨")).read()
	except:
		l1llll1l11ll_l1_ = os.path.join(l111ll1l11l_l1_,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ㟩"),addon_id,l1l111_l1_ (u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩ㟪"))
		try: l1l111111l1_l1_ = open(l1llll1l11ll_l1_,l1l111_l1_ (u"ࠧࡳࡤࠪ㟫")).read()
		except: return l1l111_l1_ (u"ࠨࠩ㟬"),[]
	if PY3: l1l111111l1_l1_ = l1l111111l1_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㟭"))
	version = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧ㟮"),l1l111111l1_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠫࠬ㟯"),[]
	l11llllll11_l1_,l11l111ll1l_l1_ = version[0],l1ll11l1l11l_l1_(version[0])
	return l11llllll11_l1_,l11l111ll1l_l1_
def l111llllll1_l1_():
	l111l1ll1ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㟰"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㟱"),l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ㟲"))
	if l111l1ll1ll_l1_: return l111l1ll1ll_l1_
	l1ll1l1l1l11_l1_,l111l1ll1ll_l1_ = {},{}
	l1lll1111l1l_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㟳")][0]]
	if kodi_version>17.99: l1lll1111l1l_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㟴")][1])
	if PY3: l1lll1111l1l_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㟵")][2])
	for l1ll1lll1111_l1_ in l1lll1111l1l_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㟶"),l1ll1lll1111_l1_,l1l111_l1_ (u"ࠬ࠭㟷"),l1l111_l1_ (u"࠭ࠧ㟸"),l1l111_l1_ (u"ࠧࠨ㟹"),l1l111_l1_ (u"ࠨࠩ㟺"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭㟻"))
		if response.succeeded:
			html = response.content
			l1ll11lll11l_l1_ = l1ll1lll1111_l1_.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㟼"),1)[0]
			l111l1lll11_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㟽"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111lll1ll1_l1_ in l111l1lll11_l1_:
				l11l111lll1_l1_ = l1ll11lll11l_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ㟾")+addon_id+l1l111_l1_ (u"࠭࠯ࠨ㟿")+addon_id+l1l111_l1_ (u"ࠧ࠮ࠩ㠀")+l111lll1ll1_l1_+l1l111_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠭㠁")
				if addon_id not in list(l1ll1l1l1l11_l1_.keys()):
					l1ll1l1l1l11_l1_[addon_id] = []
					l111l1ll1ll_l1_[addon_id] = []
				l1llll1ll1ll_l1_ = l1ll11l1l11l_l1_(l111lll1ll1_l1_)
				l1ll1l1l1l11_l1_[addon_id].append((l111lll1ll1_l1_,l1llll1ll1ll_l1_,l11l111lll1_l1_))
	for addon_id in list(l1ll1l1l1l11_l1_.keys()):
		l111l1ll1ll_l1_[addon_id] = sorted(l1ll1l1l1l11_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㠂"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㠃"),l111l1ll1ll_l1_,l11l1l1_l1_)
	return l111l1ll1ll_l1_
def l1ll11l1l11l_l1_(l111lll1ll1_l1_):
	l1llll1ll1ll_l1_ = []
	l1llll1l11l_l1_ = l111lll1ll1_l1_.split(l1l111_l1_ (u"ࠫ࠳࠭㠄"))
	for l1l1ll11l1_l1_ in l1llll1l11l_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ㠅"),l1l1ll11l1_l1_,re.DOTALL)
		l1ll1l11l1l1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1ll1l11l1l1_l1_.append(part)
		l1llll1ll1ll_l1_.append(l1ll1l11l1l1_l1_)
	return l1llll1ll1ll_l1_
def l1llll1111l1_l1_(l1llll1ll1ll_l1_):
	l111lll1ll1_l1_ = l1l111_l1_ (u"࠭ࠧ㠆")
	for l1l1ll11l1_l1_ in l1llll1ll1ll_l1_:
		for part in l1l1ll11l1_l1_: l111lll1ll1_l1_ += str(part)
		l111lll1ll1_l1_ += l1l111_l1_ (u"ࠧ࠯ࠩ㠇")
	l111lll1ll1_l1_ = l111lll1ll1_l1_.strip(l1l111_l1_ (u"ࠨ࠰ࠪ㠈"))
	return l111lll1ll1_l1_
def l11111l1ll1_l1_(l11ll11l11l_l1_):
	l1ll11lll1l1_l1_ = {}
	l1ll1l1l1l11_l1_ = l111llllll1_l1_()
	l11lll11111_l1_ = l1lll1l11lll_l1_(l11ll11l11l_l1_)
	for addon_id in l11ll11l11l_l1_:
		if addon_id not in list(l1ll1l1l1l11_l1_.keys()): continue
		l111l1ll1ll_l1_ = l1ll1l1l1l11_l1_[addon_id]
		l11ll1ll11l_l1_,l11ll1l1lll_l1_,l1ll111lllll_l1_ = l111l1ll1ll_l1_[0]
		l1llllll11l1_l1_,l11l111l1ll_l1_ = l1ll1lllll1l_l1_(addon_id)
		l11l1llll11_l1_,l1111111ll1_l1_ = l11lll11111_l1_[addon_id]
		l11lll1l1ll_l1_ = l11ll1l1lll_l1_>l11l111l1ll_l1_ and l11l1llll11_l1_
		l1ll11l1111l_l1_ = True
		if not l11l1llll11_l1_: l11llllll1l_l1_ = l1l111_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㠉")
		elif not l1111111ll1_l1_: l11llllll1l_l1_ = l1l111_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ㠊")
		elif l11lll1l1ll_l1_: l11llllll1l_l1_ = l1l111_l1_ (u"ࠫࡴࡲࡤࠨ㠋")
		else:
			l11llllll1l_l1_ = l1l111_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ㠌")
			l1ll11l1111l_l1_ = False
		l1ll11lll1l1_l1_[addon_id] = (l1ll11l1111l_l1_,l1llllll11l1_l1_,l11l111l1ll_l1_,l11ll1ll11l_l1_,l11ll1l1lll_l1_,l11llllll1l_l1_,l1ll111lllll_l1_)
	return l1ll11lll1l1_l1_
def l1l1111l11_l1_(l1l1111lll_l1_,l1111lllll1_l1_,l11l11l1lll_l1_=l1l111_l1_ (u"࠭ࠧ㠍"),line2=l1l111_l1_ (u"ࠧࠨ㠎"),l11l11ll11l_l1_=l1l111_l1_ (u"ࠨࠩ㠏")):
	if PY2: l1l1111lll_l1_.update(l1111lllll1_l1_,l11l11l1lll_l1_,line2,l11l11ll11l_l1_)
	else: l1l1111lll_l1_.update(l1111lllll1_l1_,l11l11l1lll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㠐")+line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㠑")+l11l11ll11l_l1_)
	return
def l1lll1l1l1ll_l1_(l11111lllll_l1_):
	def l111111ll11_l1_(num,b,l1lll11l1ll1_l1_=l1l111_l1_ (u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦ㠒")):
		return ((num == 0) and l1lll11l1ll1_l1_[0]) or (l111111ll11_l1_(num // b, b, l1lll11l1ll1_l1_).lstrip(l1lll11l1ll1_l1_[0]) + l1lll11l1ll1_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠧࡢ࡜ࡣࠤ㠓") + l111111ll11_l1_(c, a) + l1l111_l1_ (u"ࠨ࡜࡝ࡤࠥ㠔"),  k[c], p)
		return p
	l11111lllll_l1_ = l11111lllll_l1_.split(l1l111_l1_ (u"ࠧࡾࠪࠪ㠕"))[1][:-1]
	l1lll111ll1l_l1_ = eval(l1l111_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ㠖")+l11111lllll_l1_,{l1l111_l1_ (u"ࠩࡥࡥࡸ࡫ࡎࠨ㠗"):l111111ll11_l1_,l1l111_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ㠘"):unpack})
	return l1lll111ll1l_l1_
def l111llll1ll_l1_(url,l1lll1ll1l1l_l1_=l1l111_l1_ (u"ࠫࠬ㠙")):
	if l1lll1ll1l1l_l1_==l1l111_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ㠚"): url = re.sub(l1l111_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭㠛"),lambda l11llll11l1_l1_: l11llll11l1_l1_.group(0).lower(),url)
	elif l1lll1ll1l1l_l1_==l1l111_l1_ (u"ࠧࡶࡲࡳࡩࡷ࠭㠜"): url = re.sub(l1l111_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ㠝"),lambda l11llll11l1_l1_: l11llll11l1_l1_.group(0).upper(),url)
	return url
def l1lll1l11lll_l1_(l11ll11l11l_l1_):
	l1llllllll1l_l1_,l1111ll11l1_l1_ = False,False
	conn = sqlite3.connect(l111ll11l1l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	if len(l11ll11l11l_l1_)==1: l11l11111l1_l1_ = l1l111_l1_ (u"ࠩࠫࠦࠬ㠞")+l11ll11l11l_l1_[0]+l1l111_l1_ (u"ࠪࠦ࠮࠭㠟")
	else: l11l11111l1_l1_ = str(tuple(l11ll11l11l_l1_))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ㠠")+l11l11111l1_l1_+l1l111_l1_ (u"ࠬࠦ࠻ࠨ㠡"))
	l1l11llll1l_l1_ = l1llll1lll_l1_.fetchall()
	l11lll11111_l1_ = {}
	for addon_id in l11ll11l11l_l1_: l11lll11111_l1_[addon_id] = (False,False)
	for addon_id,l1111ll11l1_l1_ in l1l11llll1l_l1_:
		l1llllllll1l_l1_ = True
		l1111ll11l1_l1_ = l1111ll11l1_l1_==1
		l11lll11111_l1_[addon_id] = (l1llllllll1l_l1_,l1111ll11l1_l1_)
	conn.close()
	return l11lll11111_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"࠭ࠧ㠢")
	if file==l1ll11l1l1l1_l1_: status = l1ll1l1l1l1l_l1_(True,False)
	if os.path.exists(file):
		l1l11ll111l_l1_ = open(file,l1l111_l1_ (u"ࠧࡳࡤࠪ㠣")).read()
		if PY3: l1l11ll111l_l1_ = l1l11ll111l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㠤"))
		if file==l1ll11l1l1l1_l1_: l1lll_l1_ = l1l11ll111l_l1_
		else:
			l111l1l111l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㠥"),l1l11ll111l_l1_)
			if l111l1l111l_l1_:
				l1lll_l1_ = {}
				for key in l111l1l111l_l1_.keys():
					l1lll_l1_[key] = []
					for l11111l1lll_l1_ in l111l1l111l_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1l111_l1_ (u"ࠪࠫ㠦"),l1l111_l1_ (u"ࠫࠬ㠧"),l1l111_l1_ (u"ࠬ࠭㠨"),l1l111_l1_ (u"࠭ࠧ㠩"),l1l111_l1_ (u"ࠧࠨ㠪"),l1l111_l1_ (u"ࠨࠩ㠫"),l1l111_l1_ (u"ࠩࠪ㠬"),l1l111_l1_ (u"ࠪࠫ㠭"),l1l111_l1_ (u"ࠫࠬ㠮")
						type = l11111l1lll_l1_[0]
						name = l11111l1lll_l1_[1]
						name = l11lll111l1_l1_(name)
						url = l11111l1lll_l1_[2]
						mode = l11111l1lll_l1_[3]
						l11l_l1_ = l11111l1lll_l1_[4]
						l1llllll1_l1_ = l11111l1lll_l1_[5]
						if len(l11111l1lll_l1_)>6: text = l11111l1lll_l1_[6]
						if len(l11111l1lll_l1_)>7: context = l11111l1lll_l1_[7]
						if len(l11111l1lll_l1_)>8: l1llllll1ll_l1_ = l11111l1lll_l1_[8]
						if file==favoritesfile: l1ll1l1111ll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠬ࠭㠯"),l1llllll1ll_l1_
						else: l1ll1l1111ll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
						l1lll_l1_[key].append(l1ll1l1111ll_l1_)
			l1l11l111ll_l1_ = str(l1lll_l1_)
			if PY3: l1l11l111ll_l1_ = l1l11l111ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㠰"))
			open(file,l1l111_l1_ (u"ࠧࡸࡤࠪ㠱")).write(l1l11l111ll_l1_)
	return l1lll_l1_
def l1ll1llllll_l1_(l1lll11ll1l_l1_):
	l1llll1l1111_l1_ = l1lll11ll1l_l1_.split(l1l111_l1_ (u"ࠨ࠯ࠪ㠲"),1)[0]
	l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1l111_l1_ (u"ࠩࠪ㠳"),l1l111_l1_ (u"ࠪࠫ㠴"),l1l111_l1_ (u"ࠫࠬ㠵")
	if   l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㠶")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㠷")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㠸")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㠹")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㠺")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㠻")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㠼")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㠽")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㠾"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㠿")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㡀")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ㡁")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㡂")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㡃")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㡄")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㡅"):	from l11111ll1_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ㡆"):		from l1111ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㡇")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㡈")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㡉")	:	from l11111111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㡊")	:	from l1lllllll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㡋"):	from l1l1l111l1_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ㡌")	:	from l11ll1l111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ㡍")	:	from l11l11ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ㡎")	:	from l111llll1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ㡏")	:	from l111ll1l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㡐")	:	from l111ll11ll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭㡑")	:	from l111l1lll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭㡒")	:	from l111l11l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㡓")	:	from l111l111ll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㡔")	:	from l1lllll1l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㡕")	:	from l1lllll1111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㡖")	:	from l1llll1ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㡗")	:	from l1llll11lll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㡘")		:	from l1llll11l1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㡙")	:	from l1ll1lll1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㡚")		:	from l1ll1lll11l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㡛")		:	from IPTV			import MENUu as l1lll111l11_l1_,SEARCHh as l1lll11ll11_l1_,menu_namee as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ㡜")	:	from l1ll1l1111l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ㡝")	:	from l1ll1l11111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㡞")	:	from l1ll11lll1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ㡟")	:	from l1ll111lll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㡠")	:	from l11lllll1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㡡")		:	from M3U			import MENUu as l1lll111l11_l1_,SEARCHh as l1lll11ll11_l1_,menu_namee as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㡢")	:	from l11l1l11l1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㡣")	:	from l1llll11ll1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ㡤")		:	from l11l11lll11_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㡥")	:	from l1ll1llll11l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㡦"):	from l11ll1l11ll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㡧")	:	from l11l1l111l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㡨")	:	from l111l11l11l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㡩")	:	from l11lll1ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ㡪")	:	from l1ll1l1lllll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㡫")		:	from l1111l1ll1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ㡬")	:	from l1ll1lllllll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㡭")		:	from l11lll111ll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㡮")	:	from l11ll1lllll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll1l1111_l1_==l1l111_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ㡯"):	from l11ll111lll_l1_	import l1l1l11_l1_ as l1lll111l11_l1_
	return l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_
def l1llllll111l_l1_(l1ll11l11111_l1_,headers,l11_l1_):
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㡰"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨ࠼ࠣ࡟ࠥ࠭㡱")+l1ll11l11111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ㡲")+str(headers)+l1l111_l1_ (u"ࠪࠤࡢ࠭㡳"))
	l1l1111lll_l1_ = l1l111lll1_l1_()
	l1l1111lll_l1_.create(l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㡴"),l1l111_l1_ (u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧ㡵"))
	l1l11l11l1_l1_ = 1024*1024
	chunksize = 1*l1l11l11l1_l1_
	response = requests.get(l1ll11l11111_l1_,stream=True,headers=headers)
	l1ll1l1llll1_l1_ = response.headers
	response.close()
	l1ll1l1ll11l_l1_ = bytes()
	if not l1ll1l1llll1_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㡶"),l1l111_l1_ (u"ࠧࠨ㡷"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㡸"),l1l111_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฬ่็๋ࠦๅ็ࠢอั๊๐ไࠡษ็้้็ࠠศๆ่฻้๎ศ๊ࠡสุ่ฮศࠡไาࠤ๏้่็ࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮ࠡฮิฬࠥะอๆ์็ࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠬ㡹"))
		l1l1111lll_l1_.close()
	else:
		if l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ㡺") not in list(l1ll1l1llll1_l1_.keys()): filesize = 0
		else: filesize = int(l1ll1l1llll1_l1_[l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬ㡻")])
		l1l111ll1l_l1_ = str(int(1000*filesize/l1l11l11l1_l1_)/1000.0)
		l11llll11l_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬ㡼") in list(l1ll1l1llll1_l1_.keys()) and filesize>l1l11l11l1_l1_:
			l1ll1lll111l_l1_ = True
			ranges = []
			l1ll1l11111l_l1_ = 10
			ranges.append(str(0*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㡽")+str(1*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(1*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㡾")+str(2*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(2*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡿")+str(3*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(3*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㢀")+str(4*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(4*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㢁")+str(5*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(5*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㢂")+str(6*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(6*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㢃")+str(7*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(7*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㢄")+str(8*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(8*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㢅")+str(9*filesize//l1ll1l11111l_l1_-1))
			ranges.append(str(9*filesize//l1ll1l11111l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㢆"))
			l11ll1l111l_l1_ = float(l11llll11l_l1_)/l1ll1l11111l_l1_
			l1111l11l1l_l1_ = l11ll1l111l_l1_/int(1+l11ll1l111l_l1_)
		else:
			l1ll1lll111l_l1_ = False
			l1ll1l11111l_l1_ = 1
			l1111l11l1l_l1_ = 1
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㢇"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡳࡣࡱ࡫ࡪࡹ࠺ࠡ࡝ࠣࠫ㢈")+str(l1ll1lll111l_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭㢉")+str(filesize)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㢊"))
		l1l111llll_l1_,l1ll1llll1l1_l1_ = 0,0
		for l1llll1l1l1l_l1_ in range(l1ll1l11111l_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll1lll111l_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"࠭ࡒࡢࡰࡪࡩࠬ㢋")] = l1l111_l1_ (u"ࠧࡣࡻࡷࡩࡸࡃࠧ㢌")+ranges[l1llll1l1l1l_l1_]
			response = requests.get(l1ll11l11111_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l1111lll_l1_.iscanceled():
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㢍"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡄࡣࡱࡧࡪࡲࡥࡥࠩ㢎"))
					break
				l1l111llll_l1_ += l1111l11l1l_l1_
				l1ll1l1ll11l_l1_ += chunk
				if not l1ll1llll1l1_l1_: l1ll1llll1l1_l1_ = len(chunk)
				if filesize: l1l1111l11_l1_(l1l1111lll_l1_,100*l1l111llll_l1_//l11llll11l_l1_,l1l111_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ㢏"),str(100.0*l1ll1llll1l1_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠫࠥ࠵ࠠࠨ㢐")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠬࠦࡍࡃࠩ㢑"))
				else: l1l1111l11_l1_(l1l1111lll_l1_,l1ll1llll1l1_l1_*l1l111llll_l1_//chunksize,l1l111_l1_ (u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠫ㢒"),str(100.0*l1ll1llll1l1_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠧࠡࡏࡅࠫ㢓"))
			response.close()
		l1l1111lll_l1_.close()
		if len(l1ll1l1ll11l_l1_)<filesize and filesize>0:
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㢔"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡰࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡧࡴ࠻ࠢ࡞ࠤࠬ㢕")+str(len(l1ll1l1ll11l_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨ㢖")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ㢗"))
			l11l1111ll1_l1_ = l1ll11ll1l1l_l1_(l1l111_l1_ (u"ࠬ࠭㢘"),l1l111_l1_ (u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫ㢙"),l1l111_l1_ (u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧ㢚"),l1l111_l1_ (u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪ㢛"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㢜"),l1l111_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧ㢝")+str(len(l1ll1l1ll11l_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪ㢞")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧ㢟"))
			if l11l1111ll1_l1_==2: l1ll1l1ll11l_l1_ = l1llllll111l_l1_(l1ll11l11111_l1_,headers,l11_l1_)
			elif l11l1111ll1_l1_==1: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㢠"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭㢡"))
			else: return l1l111_l1_ (u"ࠨࠩ㢢")
			if not l1ll1l1ll11l_l1_: return l1l111_l1_ (u"ࠩࠪ㢣")
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㢤"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠳ࠦࠠࠡࡈ࡬ࡰࡪࠦࡓࡪࡼࡨ࠾ࠥࡡࠠࠨ㢥")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ㢦"))
	return l1ll1l1ll11l_l1_
def l1111l1l11l_l1_(l1ll1_l1_):
	return response
def l1111lll1l1_l1_(l1lll1l11l1l_l1_=l1l111_l1_ (u"࠭ࠧ㢧")):
	l1ll1llll111_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡴࡶࡵࠫ㢨"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㢩"),l1l111_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭㢪"))
	if l1ll1llll111_l1_: return l1ll1llll111_l1_
	l1lll1l11l1l_l1_,l1lll1111111_l1_,l1llll1l11l1_l1_,l11lllllll1_l1_,l1llll1l111l_l1_,l111l111l1l_l1_,timezone = l1l111_l1_ (u"ࠪࠫ㢫"),l1l111_l1_ (u"ࠫࠬ㢬"),l1l111_l1_ (u"ࠬ࠭㢭"),l1l111_l1_ (u"࠭ࠧ㢮"),l1l111_l1_ (u"ࠧࠨ㢯"),l1l111_l1_ (u"ࠨࠩ㢰"),l1l111_l1_ (u"ࠩࠪ㢱")
	url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭㢲")+l1lll1l11l1l_l1_+l1l111_l1_ (u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ㢳")
	headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㢴"):l1l111_l1_ (u"࠭ࠧ㢵")}
	response = l111l11lll1_l1_(l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㢶"),url,l1l111_l1_ (u"ࠨࠩ㢷"),headers,l1l111_l1_ (u"ࠩࠪ㢸"),l1l111_l1_ (u"ࠪࠫ㢹"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㢺"))
	if not response.succeeded: l1ll1l11l11l_l1_ = l1lll1l11l1l_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㢻")+l1lll1111111_l1_+l1l111_l1_ (u"࠭ࠬࠨ㢼")+l1llll1l11l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢽")+l1llll1l111l_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㢾")+l111l111l1l_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㢿")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠪࡠࢀ࠴ࠪࡀ࡞ࢀࡠࢂ࠭㣀"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l11l11ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㣁"),html)
			if l1l111_l1_ (u"ࠬ࡯ࡰࠨ㣂") in list(l11l11l11ll_l1_.keys()): l1lll1l11l1l_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"࠭ࡩࡱࠩ㣃")]
			if l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ㣄") in list(l11l11l11ll_l1_.keys()): l1lll1111111_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ㣅")]
			if l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㣆") in list(l11l11l11ll_l1_.keys()): l1llll1l11l1_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㣇")]
			if l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ㣈") in list(l11l11l11ll_l1_.keys()): l11lllllll1_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ㣉")]
			if l1l111_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭㣊") in list(l11l11l11ll_l1_.keys()): l1llll1l111l_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ㣋")]
			if l1l111_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭㣌") in list(l11l11l11ll_l1_.keys()): l111l111l1l_l1_ = l11l11l11ll_l1_[l1l111_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ㣍")]
			if l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㣎") in list(l11l11l11ll_l1_.keys()):
				timezone = l11l11l11ll_l1_[l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭㣏")][l1l111_l1_ (u"ࠬࡻࡴࡤࠩ㣐")]
				if timezone[0] not in [l1l111_l1_ (u"࠭࠭ࠨ㣑"),l1l111_l1_ (u"ࠧࠬࠩ㣒")]: timezone = l1l111_l1_ (u"ࠨ࠭ࠪ㣓")+timezone
			l1ll1l11l11l_l1_ = l1lll1l11l1l_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㣔")+l1lll1111111_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㣕")+l1llll1l11l1_l1_+l1l111_l1_ (u"ࠫ࠱࠭㣖")+l1llll1l111l_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㣗")+l111l111l1l_l1_+l1l111_l1_ (u"࠭ࠬࠨ㣘")+timezone
			if PY3: l1ll1l11l11l_l1_ = l1ll1l11l11l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㣙")).decode(l1l111_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㣚"))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㣛"),l1l111_l1_ (u"ࠪࡍࡕࡒࡏࡄࡃࡗࡍࡔࡔࠧ㣜"),l1ll1l11l11l_l1_,l111l11l_l1_)
	l1ll1l11l11l_l1_ = escapeUNICODE(l1ll1l11l11l_l1_)
	return l1ll1l11l11l_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"ࠫࠬ㣝"),True
	if search.count(l1l111_l1_ (u"ࠬࡥࠧ㣞"))>=2:
		search,options = search.split(l1l111_l1_ (u"࠭࡟ࠨ㣟"),1)
		options = l1l111_l1_ (u"ࠧࡠࠩ㣠")+options
		if l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㣡") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1ll1l11l1ll_l1_():
	l1ll1lll1lll_l1_ = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㣢"))
	l111111ll1l_l1_ = 0
	if os.path.exists(l1ll1lll1lll_l1_):
		for filename in os.listdir(l1ll1lll1lll_l1_):
			if l1l111_l1_ (u"ࠪ࠲ࡵࡿ࡯ࠨ㣣") in filename: continue
			if l1l111_l1_ (u"ࠫࡤࡥࡰࡺࡥࡤࡧ࡭࡫࡟ࡠࠩ㣤") in filename: continue
			l1ll111111_l1_ = os.path.join(l1ll1lll1lll_l1_,filename)
			size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
			l111111ll1l_l1_ += size
	return l111111ll1l_l1_
def l1ll1l1l1l1l_l1_(l111lll11l1_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㣥")][3]
	l1ll11l11lll_l1_ = l1l11l1ll11_l1_(32,l111lll11l1_l1_)
	l1ll1l11l11l_l1_ = l1111lll1l1_l1_()
	l1llll1l11l1_l1_ = l1ll1l11l11l_l1_.split(l1l111_l1_ (u"࠭ࠬࠨ㣦"))[2]
	l111111ll1l_l1_ = l1ll1l11l1ll_l1_()
	payload = {l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㣧"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ㣨"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㣩"):l1llll1l11l1_l1_,l1l111_l1_ (u"ࠪ࡭ࡩࡹࠧ㣪"):l1lll1ll11l1_l1_(l111111ll1l_l1_)}
	if not l111lll11l1_l1_: l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧ㣫"),(l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㣬"),url,payload,l1l111_l1_ (u"࠭ࠧ㣭"),l1l111_l1_ (u"ࠧࠨ㣮")))
	l1111ll11ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪ㣯"))
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶࠫ㣰"),l1l111_l1_ (u"ࠪࠫ㣱"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㣲"),url,payload,l1l111_l1_ (u"ࠬ࠭㣳"),l1l111_l1_ (u"࠭ࠧ㣴"),l1l111_l1_ (u"ࠧࠨ㣵"),l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ㣶"),True,True)
	l11lll1l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㣷"))
	if not l11lll1l11l_l1_: l11lll1l11l_l1_ = l1l111_l1_ (u"ࠪࡒࡊ࡝ࠧ㣸")
	l1llll111ll1_l1_ = l11lll1l11l_l1_
	l11ll1lll11_l1_ = l1l111_l1_ (u"ࠫࠬ㣹")
	if not response.succeeded: l1llll111ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㣺")
	else:
		l111l11ll1l_l1_,l111l1l1lll_l1_,l11l1l11111_l1_ = l1l111_l1_ (u"࠭ࠧ㣻"),l1l111_l1_ (u"ࠧࠨ㣼"),[]
		newfile = response.content
		if newfile:
			l11l1l11111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㣽"),newfile)
			for l1llllllllll_l1_,l1lll1111ll1_l1_,message in l11l1l11111_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠩࡵࡥࡼࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㣾")).decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㣿"))
				if l1llllllllll_l1_==l1l111_l1_ (u"ࠫ࠵࠭㤀"): l11ll1lll11_l1_ += message+l1l111_l1_ (u"ࠬࡀ࠺ࠨ㤁")
				else: l111l11ll1l_l1_ += message+l1l111_l1_ (u"࠭࡜࡯ࠩ㤂")
			l111l11ll1l_l1_ = l111l11ll1l_l1_.strip(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㤃"))
			l11ll1lll11_l1_ = l11ll1lll11_l1_.strip(l1l111_l1_ (u"ࠨ࠼࠽ࠫ㤄"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶࠫ㤅"),l11ll1lll11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ㤆"),l1lll1ll11l1_l1_(now))
		if os.path.exists(l1ll11l1l1l1_l1_): l111l1l1lll_l1_ = open(l1ll11l1l1l1_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㤇")).read()
		if PY3: l111l11ll1l_l1_ = l111l11ll1l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤈"))
		if l111l11ll1l_l1_!=l111l1l1lll_l1_:
			l1llll111ll1_l1_ = l1l111_l1_ (u"࠭ࡎࡆ࡙ࠪ㤉")
			try: open(l1ll11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡸࡤࠪ㤊")).write(l111l11ll1l_l1_)
			except: pass
		if l11_l1_:
			l11l1l11111_l1_ = sorted(l11l1l11111_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l1l1ll1_l1_ = l1l111_l1_ (u"ࠨࠩ㤋")
			for l1llllllllll_l1_,l1lll1111ll1_l1_,message in l11l1l11111_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠩࡵࡥࡼࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㤌")).decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㤍"))
				if l111l1l1ll1_l1_: l111l1l1ll1_l1_ += l1l111_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ㤎")
				if l1llllllllll_l1_==l1l111_l1_ (u"ࠬ࠶ࠧ㤏"): continue
				date = message.split(l1l111_l1_ (u"࠭࡜࡯ࠩ㤐"))[0]
				l11l1lllll1_l1_ = l1l111_l1_ (u"ࠧࠨ㤑")
				if l1lll1111ll1_l1_:
					l11l1lllll1_l1_ = l1l111_l1_ (u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬ㤒")
					if PY3: l11l1lllll1_l1_ = l11l1lllll1_l1_.encode(l1l111_l1_ (u"ࠩࡵࡥࡼࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㤓")).decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㤔"))
				l111l1l1ll1_l1_ += message.replace(date,l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㤕")+date+l11l1lllll1_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㤖"))+l1l111_l1_ (u"࠭࡜࡯ࠩ㤗")
			l111l1l1ll1_l1_ = escapeUNICODE(l111l1l1ll1_l1_)
			l1l11l1l1l_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㤘"),l1l111_l1_ (u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫ㤙"),l111l1l1ll1_l1_,l1l111_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㤚"))
			l1llll111ll1_l1_ = l1l111_l1_ (u"ࠪࡓࡑࡊࠧ㤛")
		if l1llll111ll1_l1_!=l11lll1l11l_l1_:
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㤜"),l1llll111ll1_l1_)
	if l11_l1_: xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㤝"))
	if l1111ll11ll_l1_!=l11ll1lll11_l1_:
		if not l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ฬาส้ࠣึฯࠠฤะิํࠬ㤞"),l1l111_l1_ (u"ࠧࡕࡴࡼࠤࡦ࡭ࡡࡪࡰࠪ㤟"),time=2000)
		l1111l1ll11_l1_(l1l111_l1_ (u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹࠦࡴࡰࠢࡤࡴࡵࡲࡹࠡࡰࡨࡻࠥࡶࡲࡪࡸ࡬ࡰࡪ࡭ࡥࡴࠩ㤠"))
	return l1llll111ll1_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll1ll1ll1l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll1ll1ll1l_l1_ = False
	l11lll1111_l1_ = time.time()
	if l1ll1ll1ll1l_l1_: resp = l11lll1111_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ㤡"),l1l111_l1_ (u"ࠪࠫ㤢"),l1l111_l1_ (u"ࠫࠬ㤣"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㤤"),l1l111_l1_ (u"࠭ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤ฾๋ไ๋หࠣห้ะๆู์ไࠤฬ๊ย็ࠢยࠥࠬ㤥"))
	else: l1llll111l_l1_ = True
	if l1llll111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠧ࠯ࡦࡥࠫ㤦")) and l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠭㤧") in filename:
				l1ll1lll1l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1llll1lll_l1_ = l1l1llll1l1_l1_(l1ll1lll1l_l1_)
				except: return
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬ㤨"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭㤩"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬ㤪"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㤫"),l1l111_l1_ (u"࠭ࠧ㤬"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㤭"),l1l111_l1_ (u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩ㤮"))
	return
def l111l11lll1_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll1l_l1_=l1l111_l1_ (u"ࠩࠪ㤯"),l1lll1ll1ll1_l1_=l1l111_l1_ (u"ࠪࠫ㤰")):
	if l11_l1_==l1l111_l1_ (u"ࠫࠬ㤱"): l11_l1_ = True
	if l11ll11ll1l_l1_==l1l111_l1_ (u"ࠬ࠭㤲"): l11ll11ll1l_l1_ = True
	if l1lll1ll1ll1_l1_==l1l111_l1_ (u"࠭ࠧ㤳"): l1lll1ll1ll1_l1_ = True
	if allow_redirects==l1l111_l1_ (u"ࠧࠨ㤴"): l1ll1lll1l11_l1_ = True
	else: l1ll1lll1l11_l1_ = allow_redirects
	if data==None: l1l11llll_l1_ = None
	elif data==l1l111_l1_ (u"ࠨࠩ㤵"): l1l11llll_l1_ = {}
	else: l1l11llll_l1_ = data
	if headers==None: l1ll1ll1l_l1_ = None
	elif headers==l1l111_l1_ (u"ࠩࠪ㤶"): l1ll1ll1l_l1_ = {}
	else: l1ll1ll1l_l1_ = headers
	l1llll11lll1_l1_ = list(l1ll1ll1l_l1_.keys())
	if l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㤷") not in l1llll11lll1_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㤸")] = l1l111_l1_ (u"ࠬࡆࡀࡁࡕࡎࡍࡕࡥࡈࡆࡃࡇࡉࡗࡆࡀࡁࠩ㤹")
	l1lllll1_l1_,l1ll1ll11ll1_l1_,l1lll1lll11l_l1_,l1llll1111ll_l1_ = l1ll1l1l11ll_l1_(url)
	l1ll11llll11_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭㤺"))
	l1ll1l1lll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ㤻"))
	l1ll1ll1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭㤼"))
	l1ll1lll1ll1_l1_ = (l1ll1ll11ll1_l1_==None and l1lll1lll11l_l1_==None)
	l111lll11ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㤽")]
	l1ll1l1lll11_l1_ = l1lllll1_l1_ in l111lll11ll_l1_
	l111lllll11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㤾")]
	l11ll1l11l1_l1_ = l1lllll1_l1_ in l111lllll11_l1_
	l11l1111111_l1_ = l1ll1l1lll11_l1_ or l11ll1l11l1_l1_
	if l1ll1lll1ll1_l1_ and l11l1111111_l1_:
		if l1ll1l1lll11_l1_:
			l11111l11l1_l1_ = l111lll11ll_l1_.index(l1lllll1_l1_)
			l111l11l111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㤿")][l11111l11l1_l1_]
			l111ll111ll_l1_ = l111l11llll_l1_[l11111l11l1_l1_]
		elif l11ll1l11l1_l1_:
			l11111l11l1_l1_ = l111lllll11_l1_.index(l1lllll1_l1_)
			l111l11l111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨ㥀")][l11111l11l1_l1_]
			l111ll111ll_l1_ = l11l11llll1_l1_[l11111l11l1_l1_]
	if l1lll1lll11l_l1_==l1l111_l1_ (u"࠭ࠧ㥁"): l1lll1lll11l_l1_ = l1ll11llll11_l1_
	elif l1lll1lll11l_l1_==None and l1ll1l1lll1l_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㥂"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㥃")] and l11ll11ll1l_l1_: l1lll1lll11l_l1_ = l1ll11llll11_l1_
	l1lll1ll1lll_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㥄")][7]
	l1ll1llll1ll_l1_ = l1ll1ll11ll1_l1_ and l1l111_l1_ (u"ࠪࡷࡨࡸࡡࡱࡧࠪ㥅") in l1ll1ll11ll1_l1_
	if l1ll1llll1ll_l1_: l1l1111l111_l1_ = 60
	elif l1ll1l1lll11_l1_ or l11ll1l11l1_l1_: l1l1111l111_l1_ = 15
	elif source in l111111llll_l1_: l1l1111l111_l1_ = 10
	elif source==l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ㥆"): l1l1111l111_l1_ = 120
	elif source==l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㥇"): l1l1111l111_l1_ = 20
	elif source==l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㥈"): l1l1111l111_l1_ = 20
	elif l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎࠩ㥉") in source: l1l1111l111_l1_ = 70
	elif l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㥊") in source: l1l1111l111_l1_ = 75
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㥋") in source: l1l1111l111_l1_ = 25
	elif l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㥌") in source: l1l1111l111_l1_ = 20
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㥍") in source: l1l1111l111_l1_ = 20
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ㥎") in source: l1l1111l111_l1_ = 30
	elif l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㥏") in source: l1l1111l111_l1_ = 25
	elif l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㥐") in source: l1l1111l111_l1_ = 30
	elif l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㥑") in source: l1l1111l111_l1_ = 20
	elif l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㥒") in source: l1l1111l111_l1_ = 60
	else: l1l1111l111_l1_ = 15
	if l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㥓") in source and not l1l11llll_l1_ and l1l111_l1_ (u"ࠫࠫ࠭㥔") not in l1lllll1_l1_ and l1l111_l1_ (u"ࠬࡅࠧ㥕") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨ㥖"))+l1l111_l1_ (u"ࠧ࠰ࠩ㥗")
	l11ll1l1ll1_l1_ = (l1ll1ll11ll1_l1_!=None)
	l1lll1ll111l_l1_ = (l1lll1lll11l_l1_!=None and l1ll1l1lll1l_l1_!=l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㥘"))
	if l11ll1l1ll1_l1_ and not l1ll1llll1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡสิ์ู่๊ࠡำๅ้ࠬ㥙"),l1ll1ll11ll1_l1_)
	elif l1lll1ll111l_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢࡇࡒࡘࠦัใ็ࠪ㥚"),l1lll1lll11l_l1_)
	if l11ll1l1ll1_l1_:
		proxies = {l1l111_l1_ (u"ࠦ࡭ࡺࡴࡱࠤ㥛"):l1ll1ll11ll1_l1_,l1l111_l1_ (u"ࠧ࡮ࡴࡵࡲࡶࠦ㥜"):l1ll1ll11ll1_l1_}
		l11111ll1ll_l1_ = l1ll1ll11ll1_l1_
	else: proxies,l11111ll1ll_l1_ = {},l1l111_l1_ (u"࠭ࠧ㥝")
	if l1lll1ll111l_l1_:
		import urllib3.util.connection as connection
		l11l11l11l1_l1_ = l1ll1l11ll11_l1_(connection,l1ll11llll11_l1_)
	l1ll1lll1l1l_l1_,l1lll11l1111_l1_,l1l11lll1_l1_,l11lll11l1l_l1_,l11ll1l1l11_l1_,verify = l1ll1lll1l11_l1_,source,method,False,False,l1llll1111ll_l1_
	if l1lll1ll1lll_l1_: l11ll1l1l11_l1_ = True
	if l11l1111111_l1_ or l1ll1lll1l11_l1_: l1ll1lll1l1l_l1_ = False
	if l1ll1l1lll11_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㥞")
	code,reason = -1,l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ㥟")
	for l1l111llll_l1_ in range(9):
		l1lllllllll1_l1_ = True
		succeeded = False
		try:
			if l1l111llll_l1_: l1lll11l1111_l1_ = l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠱ࡴࡶࠪ㥠")
			if l1ll1llll1ll_l1_ or not l11ll1l1ll1_l1_: l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡏࡑࡇࡑࡣ࡚ࡘࡌࠨ㥡"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1lll11l1111_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=l1l11llll_l1_,headers=l1ll1ll1l_l1_,verify=verify,allow_redirects=l1ll1lll1l1l_l1_,timeout=l1l1111l111_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11lll11l1l_l1_:
					l11111llll1_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㥢") in l11111llll1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㥣")]
					elif l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㥤") in l11111llll1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㥥")]
					else: l11lll11l1l_l1_ = True
					if not l11lll11l1l_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩ㥦"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ㥧")).decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㥨"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㥩"))
					if l11l1111111_l1_ and response.status_code==307:
						l1ll1lll1l1l_l1_ = l1ll1lll1l11_l1_
						l1l11lll1_l1_ = method
						l11lll11l1l_l1_ = True
						l1llll11l1ll_l1_
				if not l11lll11l1l_l1_ or l1ll1lll1l11_l1_:
					if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㥪") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㥫"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠧ࠰ࠩ㥬")+l1lllll1_l1_.lstrip(l1l111_l1_ (u"ࠨ࠱ࠪ㥭"))
				if not l11lll11l1l_l1_ and l1ll1lll1l11_l1_:
					l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1lllll1_l1_)
					if l11ll1l1l1_l1_ not in [l1l111_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㥮"),l1l111_l1_ (u"ࠪ࠲ࡹࡹࠧ㥯"),l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㥰"),l1l111_l1_ (u"ࠬ࠴ࡡࡢࡥࠪ㥱"),l1l111_l1_ (u"࠭࠮࡮࡭ࡹࠫ㥲"),l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ㥳"),l1l111_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ㥴")]: l1llll11l1ll_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll1l1l11_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if PY2: reason = str(err.message).split(l1l111_l1_ (u"ࠩ࠽ࠤࠬ㥵"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠪ࠾ࠥ࠭㥶"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠫࡊࡸࡲ࡯ࡱࠪ㥷") in error: code,reason = re.findall(l1l111_l1_ (u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢ㥸"),error)[0]
				elif l1l111_l1_ (u"࠭ࠬࠡࡧࡵࡶࡴࡸࠨࠨ㥹") in error: code,reason = re.findall(l1l111_l1_ (u"ࠢ࠭ࠢࡨࡶࡷࡵࡲ࡝ࠪࠫࡠࡩ࠱ࠩ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ㥺"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠨ࠼ࠪ㥻"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠩ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭ࠬ㥼"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if PY2: reason = err.message
			else: reason = str(err)
		except:
			l1lllllllll1_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㥽"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ㥾")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㥿")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㦀")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㦁")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㦂"))
		if l1ll1lll1ll1_l1_ and l11l1111111_l1_ and l1lllllllll1_l1_ and not l11ll1l1l11_l1_ and code!=200:
			l1lllll1_l1_ = l111l11l111_l1_
			l11ll1l1l11_l1_ = True
			continue
		if l1lllllllll1_l1_: break
	if l1lll1lll11l_l1_!=None and l1ll1l1lll1l_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㦃"): connection.create_connection = l11l11l11l1_l1_
	if l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ㦄") and l11ll11ll1l_l1_: l1lll1lll11l_l1_ = None
	if not succeeded and l1ll1ll11ll1_l1_==None and source not in l111111llll_l1_:
		l111l11ll11_l1_ = traceback.format_exc()
		if l111l11ll11_l1_!=l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ㦅"): sys.stderr.write(l111l11ll11_l1_)
	l1lll1l11_l1_ = l1l1lllll1l_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠬ࠭㦆")
	try: l1ll1ll11_l1_ = response.headers
	except: l1ll1ll11_l1_ = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if PY3:
		try: content = content.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㦇"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = l1ll1ll11_l1_
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if PY2 or isinstance(l1lll1l11_l1_.content,str): l111ll1ll11_l1_ = l1lll1l11_l1_.content.lower()
	else: l111ll1ll11_l1_ = l1l111_l1_ (u"ࠧࠨ㦈")
	l1lllll1ll1l_l1_ = (l1l111_l1_ (u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㦉") in l111ll1ll11_l1_ or l1l111_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࠩ㦊") in l111ll1ll11_l1_) and l111ll1ll11_l1_.count(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭㦋"))>2 and l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㦌") not in source and l1l111_l1_ (u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴࠧ㦍") not in l111ll1ll11_l1_ and not l1ll1llll1ll_l1_
	if code==200 and l1lllll1ll1l_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1ll1lll1ll1_l1_ and l11l1111111_l1_:
		if l1lll1ll1lll_l1_: l111ll111ll_l1_ = l1l111_l1_ (u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ㦎")+l1l11llll_l1_[l1l111_l1_ (u"ࠧ࡫ࡱࡥࠫ㦏")].upper().replace(l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㦐"),l1l111_l1_ (u"ࠩࠪ㦑"))
		l1lll11ll_l1_ = l1l1lllllll_l1_(l111ll111ll_l1_)
	if not l1lll1l11_l1_.succeeded and l1ll1lll1ll1_l1_:
		l1lllll1l1ll_l1_ = (l1l111_l1_ (u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㦒") in l111ll1ll11_l1_ and l1l111_l1_ (u"ࠫࡷࡧࡹࠡ࡫ࡧ࠾ࠥ࠭㦓") in l111ll1ll11_l1_)
		l1lllll1ll11_l1_ = (l1l111_l1_ (u"ࠬ࠻ࠠࡴࡧࡦࠫ㦔") in l111ll1ll11_l1_ and l1l111_l1_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧ㦕") in l111ll1ll11_l1_)
		l1lllll1llll_l1_ = (code in [403] and l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠾ࠥ࠷࠰࠳࠲ࠪ㦖") in l111ll1ll11_l1_)
		l1llllll1111_l1_ = (l1l111_l1_ (u"ࠨࡡࡦࡪࡤࡩࡨ࡭ࡡࠪ㦗") in l111ll1ll11_l1_ and l1l111_l1_ (u"ࠩࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࠭㦘") in l111ll1ll11_l1_)
		if   l1lllll1ll1l_l1_: reason = l1l111_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ㦙")
		elif l1lllll1l1ll_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㦚")
		elif l1lllll1ll11_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ㦛")
		elif l1lllll1llll_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡢࡥࡦࡩࡸࡹࠠࡥࡧࡱ࡭ࡪࡪࠧ㦜")
		elif l1llllll1111_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ㦝")
		else: reason = str(reason)
		if source in l1lll111ll11_l1_: pass
		elif source in l111111llll_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㦞"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㦟")+str(code)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㦠")+reason+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㦡")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㦢")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㦣"))
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㦤"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㦥")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㦦")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㦧")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㦨")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㦩"))
		l1111lll11l_l1_ = l111l11_l1_(l1lllll1_l1_)
		if PY2 and isinstance(l1111lll11l_l1_,unicode): l1111lll11l_l1_ = l1111lll11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㦪"))
		if l11l1111111_l1_: l1111lll11l_l1_ = l1111lll11l_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ㦫"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠨ࡞ࡱࠬࠥ࠭㦬")+l1111lll11l_l1_+l1l111_l1_ (u"ࠩࠣ࠭ࠬ㦭")
		if l1lllll1ll1l_l1_ or l1lllll1l1ll_l1_ or l1lllll1ll11_l1_ or l1lllll1llll_l1_ or l1llllll1111_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
			if 1:
				l1ll1lll_l1_(l1l111_l1_ (u"้ࠪาอ่ๅหࠣฮัอ่ำࠩ㦮"),l1l111_l1_ (u"ࠫฬ๊แฮืࠣห้ษๅ็์ࠪ㦯"),time=1500)
				l1ll1ll1111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠳ࠪ㦰"))
				l1ll1ll111l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠵ࠫ㦱"))
				l1ll1ll1111l_l1_ = 9999 if not l1ll1ll1111l_l1_ else int(l1ll1ll1111l_l1_)
				l1ll1ll111l1_l1_ = 9999 if not l1ll1ll111l1_l1_ else int(l1ll1ll111l1_l1_)
				l11lll11lll_l1_ = []
				if l1ll1ll1111l_l1_>10: l11lll11lll_l1_.append(1)
				if l1ll1ll111l1_l1_>10: l11lll11lll_l1_.append(2)
				l11lll11lll_l1_.append(3)
				l11ll1ll1l1_l1_ = random.sample(l11lll11lll_l1_,1)[0]
				if l11ll1ll1l1_l1_==1:
					l1111111l1l_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪ㦲")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㦳")+l1111111l1l_l1_+l1l111_l1_ (u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ㦴")
					l1lllll1lll1_l1_ = l111l11lll1_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠳ࡰࡧࠫ㦵"),False,False)
				elif l11ll1ll1l1_l1_==2:
					l1111111l1l_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧ㦶")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ㦷")+l1111111l1l_l1_+l1l111_l1_ (u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭㦸")
					l1lllll1lll1_l1_ = l111l11lll1_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠸ࡸࡤࠨ㦹"),False,False)
				elif l11ll1ll1l1_l1_==3:
					l1111111l1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠿࠽࠶ࡣ࠶ࡩࡧ࠸࠺ࡦࡤࡦ࠴࠽ࡩ࠿ࡣ࠶࠷ࡤ࠵࠺࡬࠳࠷࠲࠷ࡧࡩ࠿࠱࠵ࡥࡃࡴࡷࡵࡸࡺ࠯ࡶࡩࡷࡼࡥࡳ࠰ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴ࡣࡰ࡯࠽࠼࠵࠶࠱ࠨ㦺")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㦻")+l1111111l1l_l1_+l1l111_l1_ (u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ㦼")
					l1lllll1lll1_l1_ = l111l11lll1_l1_(method,l1111111_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠶ࡷ࡬ࠬ㦽"),False,False)
				else: l1lllll1lll1_l1_ = l1lll1l11_l1_
				if l1lllll1lll1_l1_.succeeded:
					if l11ll1ll1l1_l1_ in [1,2]:
						l1ll11lllll1_l1_ = l1lllll1lll1_l1_.headers[l1l111_l1_ (u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬ㦾")]
						if l11ll1ll1l1_l1_==1: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫ㦿"),l1ll11lllll1_l1_)
						if l11ll1ll1l1_l1_==2: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬ㧀"),l1ll11lllll1_l1_)
					l1ll1lll_l1_(l1l111_l1_ (u"ࠨ่ฯัࠥอไโฯุࠤฬ๊รๆ่ํࠫ㧁"),l1l111_l1_ (u"ࠩ๐ࡗࡺࡩࡣࡦࡵࡶࠫ㧂"),time=2000)
					return l1lllll1lll1_l1_
				l1ll1lll_l1_(l1l111_l1_ (u"่้ࠪษำโࠢไุ้ࠦวๅใะูࠥอไฤ็้๎ࠬ㧃"),l1l111_l1_ (u"ࠫัืศࠡ็ิอࠥษฮา๋ࠪ㧄"),time=2000)
		l1llll111l_l1_ = True
		if (l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㧅") or l1ll1ll1lll1_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㧆")) and (l11ll11ll1l_l1_ or l1lll1ll1ll1_l1_):
			l1llll111l_l1_ = l1111111l11_l1_(code,reason,source,l11_l1_)
			if l1llll111l_l1_ and l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧇"): l1ll1l1lll1l_l1_ = l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧈")
			else: l1ll1l1lll1l_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㧉")
			if l1llll111l_l1_ and l1ll1ll1lll1_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㧊"): l1ll1ll1lll1_l1_ = l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㧋")
			else: l1ll1ll1lll1_l1_ = l1l111_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㧌")
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ㧍"),l1ll1l1lll1l_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ㧎"),l1ll1ll1lll1_l1_)
		if l1llll111l_l1_:
			l1ll1l1111l1_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㧏") in l1lllll1_l1_ and l1ll1l1111l1_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ㧐"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧑"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ㧒")
				l1lll11ll_l1_ = l111l11lll1_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠸ࡸ࡭࠭㧓"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧔"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧕")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧖")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㧗"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧ㧘"),l1l111_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㧙"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㧚"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧛")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧜")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㧝"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬ㧞"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧟"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1ll1lll1_l1_ in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㧠"),l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㧡")] and l1lll1ll1ll1_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭㧢"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧣"),time=2000)
				l1lll11ll_l1_ = l11ll11llll_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠼ࡴࡩࠩ㧤"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㧥"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡐࡳࡱࡻ࡭ࡪࡹࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧦")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧧")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧨"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㧩"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧪"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧫"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㧬")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧭")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧮"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ㧯"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧰"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1l1lll1l_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㧱"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧲")] and l11ll11ll1l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืࠠࡅࡐࡖࠫ㧳"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧴"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩ㧵")
				l1lll11ll_l1_ = l111l11lll1_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠺ࡸ࡭࠭㧶"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧷"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ㧸")+l1ll11llll11_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧹")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧺")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧻"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㧼"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧽"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㧾"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ㧿")+l1ll11llll11_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㨀")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㨁")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㨂"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫ㨃"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㨄"),time=2000)
		if l1ll1ll1lll1_l1_==l1l111_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㨅") or l1ll1l1lll1l_l1_==l1l111_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㨆"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11lll11ll1_l1_ = l1111111l11_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1ll1111_l1_ and l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬ㨇") not in source:
				l1111l1ll11_l1_(l1l111_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡹ࡬ࡸ࡭ࡀࠠࠨ㨈")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭㨉")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㨊"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㨋"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㨌")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ㨍"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㨎"))
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㨏")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㨐"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㨑"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㨒")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ㨓"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㨔"))
	return l1lll1l11_l1_
def l11l1l_l1_(cache,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll1l_l1_=True,l1lll1ll1ll1_l1_=True):
	l1lllll1_l1_,l1ll1ll11ll1_l1_,l1lll1lll11l_l1_,l1llll1111ll_l1_ = l1ll1l1l11ll_l1_(url)
	item = method,l1lllll1_l1_,data,headers,allow_redirects
	if cache:
		response = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ㨕"),l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㨖"),item)
		if response.succeeded:
			l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ㨗"),l1lllll1_l1_,data,headers,source,method)
			return response
	response = l111l11lll1_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll1l_l1_,l1lll1ll1ll1_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㨘") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if cache: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ㨙"),item,response,cache)
	return response
def l1l1llll_l1_(cache,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㨚")
	else:
		method = l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㨛")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(cache,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1l1l11ll_l1_(url):
	l1ll1ll1ll11_l1_ = url.split(l1l111_l1_ (u"ࠨࡾࡿࠫ㨜"))
	l1lllll1_l1_,l1ll1ll11ll1_l1_,l1lll1lll11l_l1_,l1llll1111ll_l1_ = l1ll1ll1ll11_l1_[0],None,None,True
	for item in l1ll1ll1ll11_l1_:
		if l1l111_l1_ (u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㨝") in item: l1ll1ll11ll1_l1_ = item.split(l1l111_l1_ (u"ࠪࡁࠬ㨞"))[1]
		elif l1l111_l1_ (u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ㨟") in item: l1lll1lll11l_l1_ = item.split(l1l111_l1_ (u"ࠬࡃࠧ㨠"))[1]
		elif l1l111_l1_ (u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ㨡") in item: l1llll1111ll_l1_ = False
	return l1lllll1_l1_,l1ll1ll11ll1_l1_,l1lll1lll11l_l1_,l1llll1111ll_l1_
def l11lll111l1_l1_(name):
	start,l1lll11ll1l_l1_,modified = l1l111_l1_ (u"ࠧࠨ㨢"),l1l111_l1_ (u"ࠨࠩ㨣"),l1l111_l1_ (u"ࠩࠪ㨤")
	name = name.replace(ltr,l1l111_l1_ (u"ࠪࠫ㨥")).replace(rtl,l1l111_l1_ (u"ࠫࠬ㨦"))
	tmp = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠪ࡞࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡠࡢ࠮࡜ࡸ࡞ࡺࡠࡼ࠯ࠠࠬ࡞࡞ࡠ࠴ࡉࡏࡍࡑࡕࡠࡢ࠮࠮ࠫࡁࠬࠨࠬ㨧"),name,re.DOTALL)
	if tmp: start,l1lll11ll1l_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"࠭ࠠࠨ㨨"),l1l111_l1_ (u"ࠧ࠭ࠩ㨩"),l1l111_l1_ (u"ࠨࠩ㨪")]: modified = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㨫")
	if l1lll11ll1l_l1_: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡣࠬ㨬")+l1lll11ll1l_l1_+l1l111_l1_ (u"ࠫࡤ࠭㨭")
	name = l1lll11ll1l_l1_+modified+name
	return name
def l1lllll1l1l_l1_(cache,method,url,l11l111l11l_l1_,l1lll1l1ll11_l1_,l111111lll1_l1_,headers=l1l111_l1_ (u"ࠬ࠭㨮")):
	l1ll11l1ll11_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㨯"))
	l11l1l11l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㨰")+l11l111l11l_l1_)
	if l1ll11l1ll11_l1_==l11l1l11l11_l1_: settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ㨱")+l11l111l11l_l1_,l1l111_l1_ (u"ࠩࠪ㨲"))
	if l11l1l11l11_l1_: l1llllll_l1_ = url.replace(l1ll11l1ll11_l1_,l11l1l11l11_l1_)
	else:
		l1llllll_l1_ = url
		l11l1l11l11_l1_ = l1ll11l1ll11_l1_
	l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ㨳"),headers,l1l111_l1_ (u"ࠫࠬ㨴"),l1l111_l1_ (u"ࠬ࠭㨵"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ㨶"))
	html = l1lll11ll_l1_.content
	if PY3:
		try: html = html.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㨷"),l1l111_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ㨸"))
		except: pass
	code = l1lll11ll_l1_.code
	if code!=-2 and (not l1lll11ll_l1_.succeeded or l111111lll1_l1_ not in html):
		l1lll1l1ll11_l1_ = l1lll1l1ll11_l1_.replace(l1l111_l1_ (u"ࠩࠣࠫ㨹"),l1l111_l1_ (u"ࠪ࠯ࠬ㨺"))
		l1lllll1_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ㨻")+l1lll1l1ll11_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㨼"):l1l111_l1_ (u"࠭ࠧ㨽")}
		l1lll1l11_l1_ = l11l1l_l1_(cache,method,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㨾"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ㨿"),l1l111_l1_ (u"ࠩࠪ㩀"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧ㩁"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if PY3:
				try: html = html.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㩂"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㩃"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱࡟ࡻ࠯ࡢ࠿࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ㩄"),html,re.DOTALL)
			l111l111l11_l1_ = [l11l1l11l11_l1_]
			l111l1ll11l_l1_ = [l1l111_l1_ (u"ࠧࡢࡲ࡮ࠫ㩅"),l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㩆"),l1l111_l1_ (u"ࠩࡷࡻ࡮ࡺࡴࡦࡴࠪ㩇"),l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ㩈"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭㩉"),l1l111_l1_ (u"ࠬࡶࡨࡱࠩ㩊"),l1l111_l1_ (u"࠭ࡡࡵ࡮ࡤࡵࠬ㩋"),l1l111_l1_ (u"ࠧࡴ࡫ࡷࡩ࡮ࡴࡤࡪࡥࡨࡷࠬ㩌"),l1l111_l1_ (u"ࠨࡵࡸࡶ࠳ࡲࡹࠨ㩍"),l1l111_l1_ (u"ࠩࡥࡰࡴ࡭ࡳࡱࡱࡷࠫ㩎"),l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡳ࡯ࡨࡶࠬ㩏"),l1l111_l1_ (u"ࠫࡸ࡯ࡴࡦ࡮࡬࡯ࡪ࠭㩐"),l1l111_l1_ (u"ࠬ࡯࡮ࡴࡶࡤ࡫ࡷࡧ࡭ࠨ㩑"),l1l111_l1_ (u"࠭ࡳ࡯ࡣࡳࡧ࡭ࡧࡴࠨ㩒"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠲࡫ࡱࡶ࡫ࡹࠫ㩓"),l1l111_l1_ (u"ࠨࡨࡤࡷࡪࡲࡰ࡭ࡷࡶࠫ㩔")]
			for l1ll1ll_l1_ in l1ll_l1_:
				if any(value in l1ll1ll_l1_ for value in l111l1ll11l_l1_): continue
				l11l1l11l11_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭㩕"))
				if l11l1l11l11_l1_ in l111l111l11_l1_: continue
				if len(l111l111l11_l1_)==9:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㩖"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫ㩗")+l11l111l11l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪ㩘")+l1ll11l1ll11_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㩙"))
					settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㩚")+l11l111l11l_l1_,l1l111_l1_ (u"ࠨࠩ㩛"))
					break
				l111l111l11_l1_.append(l11l1l11l11_l1_)
				l1llllll_l1_ = url.replace(l1ll11l1ll11_l1_,l11l1l11l11_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㩜"),headers,l1l111_l1_ (u"ࠪࠫ㩝"),l1l111_l1_ (u"ࠫࠬ㩞"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ㩟"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l111111lll1_l1_ in html:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㩠"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡤࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ㩡")+l11l111l11l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ㩢")+l11l1l11l11_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ㩣")+l1ll11l1ll11_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㩤"))
					settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭㩥")+l11l111l11l_l1_,l11l1l11l11_l1_)
					break
	return l11l1l11l11_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠬࡵ࡬ࡥࠩ㩦")			:l1l111_l1_ (u"࠭โะ์่ࠫ㩧")
	,l1l111_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㩨")		:l1l111_l1_ (u"ࠨ็อ์็็ࠧ㩩")
	,l1l111_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㩪")		:l1l111_l1_ (u"้ࠪๆ่่ะࠩ㩫")
	,l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ㩬")			:l1l111_l1_ (u"ࠬา๊ะࠩ㩭")
	,l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㩮")		:l1l111_l1_ (u"ࠧโึ็ࠫ㩯")
	,l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㩰")		:l1l111_l1_ (u"่ࠩะ้ีࠧ㩱")
	,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㩲")		:l1l111_l1_ (u"ࠫๆ๐ฯ๋๊ࠪ㩳")
	,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㩴")			:l1l111_l1_ (u"࠭โ็ษฬࠫ㩵")
	,l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠭㩶")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ㩷")
	,l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㩸")		:l1l111_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ㩹")
	,l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭㩺")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭㩻")
	,l1l111_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭㩼")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ㩽")
	,l1l111_l1_ (u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ㩾")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ㩿")
	,l1l111_l1_ (u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭㪀")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ㪁")
	,l1l111_l1_ (u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ㪂")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ㪃")
	,l1l111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㪄")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ㪅")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭㪆")	:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ㪇")
	,l1l111_l1_ (u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭㪈")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣหู้๊็็สࠫ㪉")
	,l1l111_l1_ (u"࠭ࡨࡦ࡮ࡤࡰࠬ㪊")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ㪋")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ㪌")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ㪍")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ㪎")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭㪏")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧ㪐")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭㪑")
	,l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ㪒")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ㪓")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㪔")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ㪕")
	,l1l111_l1_ (u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧ㪖")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ㪗")
	,l1l111_l1_ (u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㪘")	:l1l111_l1_ (u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭㪙")
	,l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㪚")		:l1l111_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ㪛")
	,l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㪜")		:l1l111_l1_ (u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪ㪝")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㪞")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ㪟")
	,l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ㪠")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ㪡")
	,l1l111_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ㪢")		:l1l111_l1_ (u"้ࠪํู่ࠡสๆีฬ࠭㪣")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭㪤")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭㪥")
	,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠭㪦")		:l1l111_l1_ (u"ࠧๆๆไࠫ㪧")
	,l1l111_l1_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩ㪨")		:l1l111_l1_ (u"่่ࠩๆ࠭㪩")
	,l1l111_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ㪪")		:l1l111_l1_ (u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭㪫")
	,l1l111_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨ㪬")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫ㪭")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ㪮")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ㪯")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ㪰")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭㪱")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭㪲")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨ㪳")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ㪴")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪ㪵")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪ㪶")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬ㪷")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ㪸")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㪹")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ㪺")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭㪻")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨ㪼")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨ㪽")
	,l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ㪾")		:l1l111_l1_ (u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪ㪿")
	,l1l111_l1_ (u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬ㫀")		:l1l111_l1_ (u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ㫁")
	,l1l111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ㫂")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ㫃")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㫄")	:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㫅")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧ㫆")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬ㫇")
	,l1l111_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ㫈")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ㫉")
	,l1l111_l1_ (u"ࠧࡢࡪࡺࡥࡰ࠭㫊")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ㫋")
	,l1l111_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ㫌")		:l1l111_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ㫍")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪ㫎")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪ㫏")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨ㫐")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ㫑")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨ㫒")		:l1l111_l1_ (u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ㫓")
	,l1l111_l1_ (u"ࠪࡦࡷࡹࡴࡦ࡬ࠪ㫔")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢหีุะ๊อࠩ㫕")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷࠴࠵࠭㫖")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭㫗")
	,l1l111_l1_ (u"ࠧ࡭ࡣࡵࡳࡿࡧࠧ㫘")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭㫙")
	,l1l111_l1_ (u"ࠩࡼࡥࡶࡵࡴࠨ㫚")		:l1l111_l1_ (u"้ࠪํู่ࠡ์สๆํะࠧ㫛")
	,l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭㫜")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠩ㫝")
	,l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨ㫞")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩ㫟")
	,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭㫠")	:l1l111_l1_ (u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫ㫡")
	,l1l111_l1_ (u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ㫢")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ㫣")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ㫤")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬ㫥")
	,l1l111_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠭㫦")				:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ㫧")
	,l1l111_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨ㫨")			:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬ㫩")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫ㫪")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪ㫫")
	,l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸࠬ㫬")				:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫ㫭")
	,l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㫮")			:l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ㫯")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩ㫰")			:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩ㫱")
	,l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭㫲")				:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ㫳")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨ㫴")		:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ㫵")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭㫶")	:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧ㫷")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧ㫸")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩ㫹")
	,l1l111_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩ㫺")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩ㫻")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬ㫼")	:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩ㫽")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭㫾")		:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬ㫿")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨ㬀")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨ㬁")
	,l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㬂")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ㬃")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧ㬄")	:l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭㬅")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ㬆"):l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬ㬇")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭㬈")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧ㬉")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭㬊")	:l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪ㬋")
	,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶࠨ㬌")					:l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㬍")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨ㬎")			:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪ㬏")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬐")			:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬ㬑")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬒")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩ㬓")
	,l1l111_l1_ (u"ࠫࡲ࠹ࡵࠨ㬔")					:l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㬕")
	,l1l111_l1_ (u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨ㬖")				:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪ㬗")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬘")			:l1l111_l1_ (u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬ㬙")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬚")			:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩ㬛")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠬ࠭㬜")
	return result
def l1111l1ll11_l1_(message=l1l111_l1_ (u"࠭ࠧ㬝")):
	l1lll1l1lll1_l1_()
	if not message: message = l1l111_l1_ (u"ࠧࡇࡱࡵࡧࡪࡪࠠࡆࡺ࡬ࡸࠬ㬞")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࠩ㬟"),l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㬠")+message+l1l111_l1_ (u"ࠪࡠࡳ࠭㬡"))
	try: sys.exit()
	except: pass
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠫ࠿࠵ࠧ㬢")):
	return _1lllllll1ll_l1_(urll,exceptions)
def l11l111ll11_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠬ࠭㬣"),l1l111_l1_ (u"࠭࠰ࠨ㬤"),0]: return l1l111_l1_ (u"ࠧࠨ㬥")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1ll111l_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1lll1_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll111l_l1_)+str(l111ll1lll1_l1_)+str(l111l111_l1_)
	return result
def l1ll1ll1l11l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㬦"),l1l111_l1_ (u"ࠩ࠳ࠫ㬧"),0]: return l1l111_l1_ (u"ࠪࠫ㬨")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠫࠬ㬩")
	if len(l1l1llll1_l1_)==15:
		l11l1ll111l_l1_,l111ll1lll1_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1ll111l_l1_ = int(l11l1ll111l_l1_)^l111l11l_l1_
		l111ll1lll1_l1_ = int(l111ll1lll1_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1ll111l_l1_==l111ll1lll1_l1_==l111l111_l1_: result = str(l11l1ll111l_l1_*60)
	return result
def l1lll1ll11l1_l1_(l1l1llll1_l1_,l1lll1llllll_l1_=l1l111_l1_ (u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ㬪")):
	if l1l1llll1_l1_==l1l111_l1_ (u"࠭ࠧ㬫"): return l1l111_l1_ (u"ࠧࠨ㬬")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll1llllll_l1_)
	l11l1ll111l_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1lll1_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll111l_l1_)+str(l111ll1lll1_l1_)+str(l111l111_l1_)
	return result
def l1111l1l1l1_l1_(l1l1llll1_l1_,l1lll1llllll_l1_=l1l111_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ㬭")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠩࠪ㬮"): return l1l111_l1_ (u"ࠪࠫ㬯")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l11ll1l_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1ll111l_l1_ = int(l1l1llll1_l1_[0:l1l1l11ll1l_l1_])^l1ll1ll1_l1_
	l111ll1lll1_l1_ = int(l1l1llll1_l1_[l1l1l11ll1l_l1_:2*l1l1l11ll1l_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l11ll1l_l1_:3*l1l1l11ll1l_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠫࠬ㬰")
	if l11l1ll111l_l1_==l111ll1lll1_l1_==l111l111_l1_: result = str(int(l11l1ll111l_l1_)-int(l1lll1llllll_l1_))
	return result
def l1l1ll111l1_l1_(l1l11l1l11l_l1_):
	l1llllll11ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬱")][8]
	l1lll11l1l1l_l1_ = l1l11l1ll11_l1_(32)
	l1lll11ll111_l1_ = os.path.join(l1l1l1l1l11_l1_,l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ㬲"),l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲࡸ࠭㬳"),l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㬴"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㬵"),l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㬶"))
	l11ll111l1l_l1_,l11l11111ll_l1_ = l1ll1l11ll_l1_(l1lll11ll111_l1_)
	l11ll111l1l_l1_ = l1lll1ll11l1_l1_(l11ll111l1l_l1_,l1l111_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ㬷"))
	l111ll1l1l1_l1_ = {l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㬸"):l1l111_l1_ (u"࠭ࡄࡊࡃࡏࡓࡌ࠭㬹"),l1l111_l1_ (u"ࠧࡶࡵࡵࠫ㬺"):l1lll11l1l1l_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࠬ㬻"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠩࡶࡧࡷ࠭㬼"):l1l11l1l11l_l1_,l1l111_l1_ (u"ࠪࡷ࡮ࢀࠧ㬽"):l11ll111l1l_l1_}
	l1llll111lll_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㬾"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㬿")}
	l1lllllll11l_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㭀"),l1llllll11ll_l1_,l111ll1l1l1_l1_,l1llll111lll_l1_,l1l111_l1_ (u"ࠧࠨ㭁"),l1l111_l1_ (u"ࠨࠩ㭂"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪ㭃"))
	l1ll1l111l11_l1_ = l1lllllll11l_l1_.content
	try:
		if not l1ll1l111l11_l1_: l1ll1ll11111_l1_
		l1llll111l11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㭄"),l1ll1l111l11_l1_)
		l1ll11llllll_l1_ = l1llll111l11_l1_[l1l111_l1_ (u"ࠫࡲࡹࡧࠨ㭅")]
		l1ll1ll111ll_l1_ = l1llll111l11_l1_[l1l111_l1_ (u"ࠬࡹࡥࡤࠩ㭆")]
		l1llll1ll111_l1_ = l1llll111l11_l1_[l1l111_l1_ (u"࠭ࡳࡵࡲࠪ㭇")]
		l1ll1ll111ll_l1_ = int(l1111l1l1l1_l1_(l1ll1ll111ll_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㭈")))
		l1llll1ll111_l1_ = int(l1111l1l1l1_l1_(l1llll1ll111_l1_,l1l111_l1_ (u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ㭉")))
		for l111l1l11ll_l1_ in range(l1ll1ll111ll_l1_,0,-l1llll1ll111_l1_):
			if not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㭊")): l1ll1ll11111_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩ㭋"),str(l111l1l11ll_l1_)+l1l111_l1_ (u"ࠫࠥࠦหศ่ํอࠬ㭌"),time=300*l1llll1ll111_l1_)
			xbmc.sleep(1000*l1llll1ll111_l1_)
		if eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㭍")):
			l111ll1l1ll_l1_ = l1l111_l1_ (u"ࠨࡄࡊࡃࡏࡓࡌ࡭࡟ࡐࡍࠫࠫࠬ࠲ࠧฯำ๋ะࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬࠨ㭎")+l1ll11llllll_l1_+l1l111_l1_ (u"ࠢࠨࠫࠥ㭏")
			l111ll1l1ll_l1_ = l111ll1l1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㭐"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㭑")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㭒"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㭓"))
			exec(l111ll1l1ll_l1_)
		l1ll1ll11111_l1_
	except: exec(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ㭔"))
	return
def l1l1111l1ll_l1_():
	exec(l1l111_l1_ (u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫ㭕"))
	return
def l1ll1l11ll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1llll1ll1_l1_(l1lll111l111_l1_,l1lll111111l_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ㭖"),l1l111_l1_ (u"ࠨࠩ㭗"),l1l111_l1_ (u"ࠩࠪ㭘"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭙"),l1lll111l111_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㭚")+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㭛"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1lll111l111_l1_):
		for root,dirs,l1l1111111_l1_ in os.walk(l1lll111l111_l1_,topdown=False):
			for file in l1l1111111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㭜"),l1l111_l1_ (u"ࠧࠨ㭝"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㭞"),str(err))
					error = True
			if l1lll111111l_l1_:
				for dir in dirs:
					l1ll11l1l111_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1ll11l1l111_l1_)
					except: pass
		if l1lll111111l_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㭟"),l1l111_l1_ (u"ࠪࠫ㭠"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㭡"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭㭢"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭣"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ㭤"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㭥"))
	return
def l1lll1l1lll1_l1_(l111l11ll11_l1_=l1l111_l1_ (u"ࠩࠪ㭦")):
	l11ll11lll1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡵࡰࠨ㭧"))
	if l111l11ll11_l1_:
		l1111l1111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㭨"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㭩"),l1l111_l1_ (u"࠭ࠧ㭪"))
		l11ll111111_l1_(l111l11ll11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㭫"),l1111l1111l_l1_)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭬"))
	if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ㭭"): settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㭮"),l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㭯"))
	elif l1ll11l1l1_l1_==l1l111_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㭰"): settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭱"),l1l111_l1_ (u"ࠧࠨ㭲"))
	if settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ㭳")) not in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㭴"),l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㭵"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㭶")]: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ㭷"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㭸"))
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ㭹")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㭺"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㭻"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㭼")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ㭽"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㭾"))
	l11llll1111_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ㭿"))
	l11l11l1l1l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ㮀"))
	if l1l111_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ㮁") in str(l11l11l1l1l_l1_) and l11llll1111_l1_ in [l1l111_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ㮂"),l1l111_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ㮃")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨ㮄"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l11l1l1_l1_,l11ll1l1111_l1_)
	return
def l1lllll111l_l1_(cache,method,url,data,headers,source):
	l1lllll1_l1_,l1ll1ll11ll1_l1_,l1lll1lll11l_l1_,l1llll1111ll_l1_ = l1ll1l1l11ll_l1_(url)
	item = method,l1lllll1_l1_,data,headers
	if cache:
		html = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㮅"),l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ㮆"),item)
		if html:
			l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬ㮇"),url,data,headers,source,method)
			return html
	html = l1l1111ll11_l1_(method,url,data,headers,source)
	if html and cache: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㮈"),item,html,cache)
	return html
DIALOGg_OK = l1111l1_l1_
l11lllll11l_l1_ = l11ll11lll1_l1_
l11lll1l111_l1_ = l1lll1l1l1l1_l1_
DIALOGg_YESNO = l1ll11ll1l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l111lll1_l1_
DIALOGg_TEXTVIEWER = l1ll1ll11l1l_l1_
DIALOGg_CONTEXTMENU = l11ll1111l1_l1_
l111l1ll111_l1_ = l1l11111l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1ll11ll1l1l_l1_
l1lll11l1lll_l1_ = l1l11l1l1l_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l1111l11_l1_
DOWNLOADd_USING_PROGRESSBAR = l1llllll111l_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l11llll11_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11lll1_l1_
PERMANENT_CACHEe = l1ll111ll11_l1_
from EXCLUDES import *
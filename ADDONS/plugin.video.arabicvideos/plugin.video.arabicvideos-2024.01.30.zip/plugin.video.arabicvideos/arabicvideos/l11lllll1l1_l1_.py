# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㱷")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ㱸")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㱹"),l1l111_l1_ (u"ࠬอำหใึหึะใๆ๋ࠢࠤฬ๊ืๅสสฮࠬ㱺")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㱻"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ㱼"),l1l111_l1_ (u"ࠨࠩ㱽"),l1l111_l1_ (u"ࠩࠪ㱾"),l1l111_l1_ (u"ࠪࠫ㱿"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㲀"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㲁"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲂"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㲃"),l1l111_l1_ (u"ࠨࠩ㲄"),459,l1l111_l1_ (u"ࠩࠪ㲅"),l1l111_l1_ (u"ࠪࠫ㲆"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㲇"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲈"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㲉")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆอหฮฬะࠠๅ๊า๎ࠥ์สࠨ㲊"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠨࠩ㲋"),l1l111_l1_ (u"ࠩࠪ㲌"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㲍"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲎"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㲏")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ㲐"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠧࠨ㲑"),l1l111_l1_ (u"ࠨࠩ㲒"),l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㲓"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㲔"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㲕"),l1l111_l1_ (u"ࠬ࠭㲖"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠭㲗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㲘"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ㲙"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲚"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㲛")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ㲜")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㲝"),url,l1l111_l1_ (u"࠭ࠧ㲞"),l1l111_l1_ (u"ࠧࠨ㲟"),l1l111_l1_ (u"ࠨࠩ㲠"),l1l111_l1_ (u"ࠩࠪ㲡"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㲢"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㲣"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡺࡥࡻ࡫ࡳࠣࠩ㲤"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㲥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡔࡨࡧࡪࡴࡴࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ㲦"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠧ㲧") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㲨"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࠢࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㲩"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠫ࠵࠭㲪"),l1l111_l1_ (u"ࠬ࠷ࠧ㲫"),l1l111_l1_ (u"࠭࠲ࠨ㲬")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫ㲭"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㲮"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㲯"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ㲰"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ㲱"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ㲲"),l1l111_l1_ (u"࠭ร฻่ํอࠬ㲳"),l1l111_l1_ (u"ࠧไๆํฬࠬ㲴"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ㲵"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ㲶"),l1l111_l1_ (u"้ࠪออัศหࠪ㲷"),l1l111_l1_ (u"ࠫ฾ืึࠨ㲸"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ㲹"),l1l111_l1_ (u"࠭วๅส๋้ࠬ㲺")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㲻") in html and l1l111_l1_ (u"ࠨࡵࡵࡧࡂ࠭㲼") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㲽"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬ㲾"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ㲿"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ㳀"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"࠭ๅิๆึ่ࠬ㳁") not in title:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㳂"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭㳃") in title:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㳄") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㳅"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㳆"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠬ࠭㳇"),l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㳈")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㳉"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㳊"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳋"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ㳌")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㳍"),url,l1l111_l1_ (u"ࠬ࠭㳎"),l1l111_l1_ (u"࠭ࠧ㳏"),l1l111_l1_ (u"ࠧࠨ㳐"),l1l111_l1_ (u"ࠨࠩ㳑"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨ㳒"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡈࡧࡴࡦࡩࡲࡶࡾ࡙ࡵࡣࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㳓"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ㳔") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬ࠱ࠬ㳕"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"࠭ࠠࠨ㳖"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳗"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㳘"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳙"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㳚"),url,l1l111_l1_ (u"ࠫࠬ㳛"),l1l111_l1_ (u"ࠬ࠭㳜"),l1l111_l1_ (u"࠭ࠧ㳝"),l1l111_l1_ (u"ࠧࠨ㳞"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㳟"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡄࡶࡪࡧࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㳠"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂࠬ㳡"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳢"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㳣"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㳤"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳥"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ㳦")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ㳧"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫ㳨"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㳩"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㳪"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㳫"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㳬"),l1l111_l1_ (u"ࠨࠩ㳭"),l1l111_l1_ (u"ࠩࠪ㳮"),l1l111_l1_ (u"ࠪࠫ㳯"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㳰"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㳱"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡚ࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡹࡩࡥࡧࡁࠫ㳲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ㳳"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㳴")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ㳵")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫࠥࡷࡪࡲࡡࡳࡻࠥࠫ㳶"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㳷"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭㳸"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ㳹")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"ࠧࠨ㳺")
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㳻")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㳼")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㳽")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳾"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭㳿"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ㴀"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ㴁"),l1l111_l1_ (u"ࠨ࠭ࠪ㴂"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ㴃")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨⶔ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭ⶕ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠨⶖ"),l1l111_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨ⶗"),l1l111_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩ⶘"),l1l111_l1_ (u"ࠫฬำฯฬࠢส่ฬเว็๋ࠪ⶙")]
def l11l1ll_l1_(mode,url,text):
	if   mode==80: l1lll_l1_ = l1l1l11_l1_()
	elif mode==81: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==82: l1lll_l1_ = PLAY(url)
	elif mode==83: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==89: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⶚"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ⶛"),l1l111_l1_ (u"ࠧࠨ⶜"),l1l111_l1_ (u"ࠨࠩ⶝"),l1l111_l1_ (u"ࠩࠪ⶞"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⶟"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨⶠ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶡ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ⶢ"),l1l111_l1_ (u"ࠧࠨⶣ"),89,l1l111_l1_ (u"ࠨࠩⶤ"),l1l111_l1_ (u"ࠩࠪⶥ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧⶦ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⶧"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⶨ"),l1l111_l1_ (u"࠭ࠧⶩ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩⶪ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫⶫ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࡁ࡬ࡸࡪࡳ࠽ࠨⶬ")+l111l1l1l_l1_+l1l111_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫⶭ")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶮ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⶯")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⶰ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⶱ"),l1l111_l1_ (u"ࠨࠩⶲ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼ࠭࡮ࡣ࡬ࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡࡷࡀࠪⶳ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩⶴ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭ⶵ"): continue
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶶ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⶷")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨⶸ")):
	items = []
	if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨⶹ") in url or l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪⶺ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩⶻ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫⶼ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪⶽ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧⶾ"),l1l111_l1_ (u"ࠧࠨ⶿"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧⷀ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ⷁ"),url,l1l111_l1_ (u"ࠪࠫⷂ"),l1l111_l1_ (u"ࠫࠬⷃ"),l1l111_l1_ (u"ࠬ࠭ⷄ"),l1l111_l1_ (u"࠭ࠧⷅ"),l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ⷆ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⷇"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩⷈ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⷉ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠫⷊ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧⷋ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫⷌ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⷍ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⷎ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ⷏"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨⷐ"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪⷑ"),l1l111_l1_ (u"้ࠬไ๋สࠪⷒ"),l1l111_l1_ (u"࠭วฺๆส๊ࠬⷓ"),l1l111_l1_ (u"่ࠧัสๅࠬⷔ"),l1l111_l1_ (u"ࠨ็หหึอษࠨⷕ"),l1l111_l1_ (u"ࠩ฼ี฻࠭ⷖ"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ⷗"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪⷘ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧⷙ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩⷚ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩⷛ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷜ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩึ่ฬูไࠨⷝ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⷞ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ⷟") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫⷠ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷡ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩⷢ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷣ"),l1lllll_l1_+title,l1ll1ll_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷤ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࠫⷥ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲࠨⷦ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⷧ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢⷨ"): continue
				if title!=l1l111_l1_ (u"ࠧࠨⷩ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷪ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨⷫ")+title,l1ll1ll_l1_,81)
	if l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪⷬ") in url or l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬⷭ") in url:
		if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬⷮ") in url:
			url = url.replace(l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ⷯ"),l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨⷰ"))+l1l111_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿࠵࠴ࠬⷱ")
		elif l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪⷲ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬⷳ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭ⷴ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷵ"),l1lllll_l1_+l1l111_l1_ (u"࠭็็ษๆࠤฬ๊ๅำ์าࠫⷶ"),url,81)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⷷ"),url,l1l111_l1_ (u"ࠨࠩⷸ"),l1l111_l1_ (u"ࠩࠪⷹ"),l1l111_l1_ (u"ࠪࠫⷺ"),l1l111_l1_ (u"ࠫࠬⷻ"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ⷼ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࡆࡾ࡙ࡥࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧⷽ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫⷾ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪⷿ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⸀"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸁"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡭ࡢࡩࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⸂"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⸃"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⸄"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⸅"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⸆"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⸇"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⸈"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⸉"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⸊"),l1l111_l1_ (u"࠭ࠧ⸋"),l1l111_l1_ (u"ࠧࠨ⸌"),l1l111_l1_ (u"ࠨࠩ⸍"),l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⸎"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ⸏"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⸐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⸑"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ⸒"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ⸓"),l1l111_l1_ (u"ࠨࠩ⸔")).strip(l1l111_l1_ (u"ࠩࠣࠫ⸕"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭⸖")+server+l1l111_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭⸗")+l11l1l11_l1_+l1l111_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭⸘")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⸙")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⸚")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡳࡼࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⸛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⸜"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⸝")+name+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⸞")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⸟"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ⸠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ⸡"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⸢"),l1l111_l1_ (u"ࠩ࠰ࠫ⸣"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⸤")+search+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ⸥")
	l1lll11_l1_(url)
	return
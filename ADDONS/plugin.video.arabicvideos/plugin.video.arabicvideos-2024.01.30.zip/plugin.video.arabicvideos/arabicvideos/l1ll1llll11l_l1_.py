# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ嗖")
headers = l1l111_l1_ (u"ࠩࠪ嗗")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩ嗘")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩ嗙"),l1l111_l1_ (u"ࠬอไไๆࠪ嗚"),l1l111_l1_ (u"࠭วโๆส้ࠬ嗛"),l1l111_l1_ (u"ࠧ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠫ嗜"),l1l111_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ嗝")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ嗞")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ嗟")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嗠"),l111l1_l1_,l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ嗡"),l1l111_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ嗢"),l1l111_l1_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯ࡰࡨࡸࠬ嗣"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嗤"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ嗥"),l1l111_l1_ (u"ࠪࠫ嗦"),119,l1l111_l1_ (u"ࠫࠬ嗧"),l1l111_l1_ (u"ࠬ࠭嗨"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ嗩"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗪"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ嗫"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗬"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭嗭"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嗮"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嗯"),l1l111_l1_ (u"࠭ࠧ嗰"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗱"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ嗲"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠩࠪ嗳"),l1l111_l1_ (u"ࠪࠫ嗴"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭嗵"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡤࡨࡻ࠳ࡦࡪ࡮ࡷࡩࡷ࠭嗶"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ嗷"),l1l111_l1_ (u"ࠧࠨ嗸"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ嗹"),l1l111_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬ嗺"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡃࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嗻"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗼"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ嗽")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ嗾"),filter)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嗿"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嘀"),l1l111_l1_ (u"ࠩࠪ嘁"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡷࡵࡰࡥࡱࡺࡲࠧ࠮࠮ࠫࡁࠬࡀࡸࡩࡲࡪࡲࡷࡂࠬ嘂"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嘃"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ嘄"),l1l111_l1_ (u"࠭ࠧ嘅")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ嘆"),l1l111_l1_ (u"ࠨࠩ嘇")).strip(l1l111_l1_ (u"ࠩࠣࠫ嘈"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嘉") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬ嘊") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠬ์๊หใ็็ุ࠭嘋")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘌"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嘍")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠨࠩ嘎"),response=l1l111_l1_ (u"ࠩࠪ嘏")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嘐"),url,l1l111_l1_ (u"ࠫࠬ嘑"),headers,l1l111_l1_ (u"ࠬ࠭嘒"),l1l111_l1_ (u"࠭ࠧ嘓"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭嘔"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ嘕"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡪࡰ࡮ࡪࡥࡠࡡࡶࡰ࡮ࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ嘖"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷ࡭ࡵࡷࡴ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭嘗"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫ嘘"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ嘙"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ嘚"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭嘛"),l1l111_l1_ (u"ࠨๅ็๎อ࠭嘜"),l1l111_l1_ (u"ࠩส฽้อๆࠨ嘝"),l1l111_l1_ (u"๋ࠪิอแࠨ嘞"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ嘟"),l1l111_l1_ (u"ࠬ฿ัืࠩ嘠"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭嘡"),l1l111_l1_ (u"ࠧศๆห์๊࠭嘢")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ嘣") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ嘤"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ嘥"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ嘦"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬ嘧") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭แ๋ๆ่ࠫ嘨") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嘩"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨษ็ั้่ษࠨ嘪") in title and l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ嘫") not in url:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ嘬") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嘭"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶ࠴࠭嘮") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘯"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ嘰") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嘱") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ嘲")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘳"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嘴") in url and l1l111_l1_ (u"ࠬำไใหࠪ嘵") in title:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嘶"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘷"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ嘸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ嘹"): items = re.findall(l1l111_l1_ (u"ࠪࠬࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺࠫ࠱࠮ࡄࡄࠨ࠯࠭ࡂ࠭ࡁ࠭嘺"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嘻"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嘼"):
				title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ嘽"),l1l111_l1_ (u"ࠧࠨ嘾")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ嘿"),l1l111_l1_ (u"ࠩࠪ噀"))
				if l1l111_l1_ (u"ࠪࡃࠬ噁") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ噂")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬࡅࡰࡢࡩࡨࡁࠬ噃")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭噄"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭噅")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠨࠩ噆"),l1l111_l1_ (u"ࠩࠪ噇"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1l1l1l11_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ噈"),url,l1l111_l1_ (u"ࠫࠬ噉"),headers,l1l111_l1_ (u"ࠬ࠭噊"),l1l111_l1_ (u"࠭ࠧ噋"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ噌"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠠࡥ࠯ࡩࡰࡪࡾࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ噍"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ噎") in l11llll_l1_[0]: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111llll_l1_ in range(2):
		if l11l1l1l1l11_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噏"),l111lllll1_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ噐"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ噑"),block,re.DOTALL)
		if l11l1l1l1l11_l1_ and len(items)<2:
			l11l1l1l1l11_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ噒")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ噓") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡵࡩࡦࡪࡣࡳࡷࡰࡦࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ噔"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ噕"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ噖")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ噗"),url,l1l111_l1_ (u"ࠬ࠭噘"),headers,l1l111_l1_ (u"࠭ࠧ噙"),l1l111_l1_ (u"ࠧࠨ噚"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ噛"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡤࡧࡹ࡯࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ噜"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ噝"),block,re.DOTALL)
	l11l1l1l1l1l_l1_ = l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ噞") in block
	download = l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ噟") in block
	if   l11l1l1l1l1l_l1_ and not download: l11l1l1l1ll1_l1_,l11l1l1l11ll_l1_ = l1ll_l1_[0],l1l111_l1_ (u"࠭ࠧ噠")
	elif not l11l1l1l1l1l_l1_ and download: l11l1l1l1ll1_l1_,l11l1l1l11ll_l1_ = l1l111_l1_ (u"ࠧࠨ噡"),l1ll_l1_[0]
	elif l11l1l1l1l1l_l1_ and download: l11l1l1l1ll1_l1_,l11l1l1l11ll_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l1l1l1ll1_l1_,l11l1l1l11ll_l1_ = l1l111_l1_ (u"ࠨࠩ噢"),l1l111_l1_ (u"ࠩࠪ噣")
	if l11l1l1l1l1l_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ噤"),l11l1l1l1ll1_l1_,l1l111_l1_ (u"ࠫࠬ噥"),headers,l1l111_l1_ (u"ࠬ࠭噦"),l1l111_l1_ (u"࠭ࠧ噧"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ器"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮ࡨࡸࠥࡹࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡴࡱࡧࡹࡦࡴࠪ噩"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ噪"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ噫"),l1l111_l1_ (u"ࠫ࠴࠭噬"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭噭")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ噮")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ噯"),l11l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࠩ噰"),headers,l1l111_l1_ (u"ࠩࠪ噱"),l1l111_l1_ (u"ࠪࠫ噲"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ噳"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮࡯࡮ࡧࡱ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭噴"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ噵"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ噶")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ噷")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ噸")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ噹"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭噺"),l1l111_l1_ (u"ࠬ࠱ࠧ噻"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ噼")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ噽"),url,l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ噾"),l1l111_l1_ (u"ࠩืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤࠡ࠶ࡸࠫ噿"),l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠲ࡳ࡫ࡴࠨ嚀"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ嚁"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嚂"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嚃"),url,l1l111_l1_ (u"ࠧࠨ嚄"),headers,l1l111_l1_ (u"ࠨࠩ嚅"),l1l111_l1_ (u"ࠩࠪ嚆"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ嚇"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶ࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡨࡰࡹࡶ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠧ嚈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡖࡻࡥࡳࡻ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࠪ嚉"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀ࡟ࡷ࠯࠮࠮ࠫࡁࠬࡠࡸ࠰࠼ࠨ嚊"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ嚋") not in url: url = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嚌")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭嚍"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ嚎"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ嚏"),l1l111_l1_ (u"ࠬ࠵࠿ࠨ嚐"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ嚑"),l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ嚒"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ嚓"),l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ嚔")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ嚕"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ嚖"),l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ嚗")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ嚘"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嚙"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ嚚"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ嚛"),l1l111_l1_ (u"ࠪࠫ嚜")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ嚝"))
	if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭嚞"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨ嚟") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩ嚠") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ嚡")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ嚢")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚣")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ嚤")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ嚥"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嚦")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ嚧"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嚨"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭嚩")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ嚪"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭嚫"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭嚬"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嚭"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨ嚮"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嚯")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嚰"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭嚱"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚲"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ嚳")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ嚴"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嚵"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嚶"),l1l111_l1_ (u"ࠩࠪ嚷"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠪ็้ࠦࠧ嚸"),l1l111_l1_ (u"ࠫࠬ嚹"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠬࡃࠧ嚺") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ嚻"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ嚼")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚽"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ嚾"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚿"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ囀"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠬ࠭囁"),l1l111_l1_ (u"࠭ࠧ囂"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ囃"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ囄")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ囅")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ囆")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ囇")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ囈")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囉"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ囊")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠨࠩ囋"),l1l111_l1_ (u"ࠩࠪ囌"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠵ࠪ囍"): option = l1l111_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫ囎")
			elif value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠵ࠬ囏"): option = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨ囐")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ囑")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ囒")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ囓")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ囔")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ囕")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨ囖")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨ囗")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ囘")+name
			if type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭囙"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囚"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠪࠫ四"),l1l111_l1_ (u"ࠫࠬ囜"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭囝") and l111l111l_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨ回") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ囟"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ因")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囡"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ团"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠫࠬ団"),l1l111_l1_ (u"ࠬ࠭囤"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"࠭࠽ࠧࠩ囥"),l1l111_l1_ (u"ࠧ࠾࠲ࠩࠫ囦"))
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠪ囧"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠩࡀࠫ囨") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠬ囩"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭囪"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭囫")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨ囬")
		if l1l111_l1_ (u"ࠧࠦࠩ园") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ囮") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ囯"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ困")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ囱") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ囲"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ図")+key+l1l111_l1_ (u"ࠧ࠾ࠩ围")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ囵"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ囶")+key+l1l111_l1_ (u"ࠪࡁࠬ囷")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ囸"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ囹"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭࠽࠱ࠩ固"),l1l111_l1_ (u"ࠧ࠾ࠩ囻"))
	return l1l1l111_l1_
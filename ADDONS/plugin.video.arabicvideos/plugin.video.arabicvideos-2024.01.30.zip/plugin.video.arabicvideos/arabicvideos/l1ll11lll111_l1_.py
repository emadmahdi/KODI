# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ䉹")
headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䉺") : l1l111_l1_ (u"ࠩࠪ䉻") }
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡒ࡜࡚ࡠࠩ䉼")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1ll11111111_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll11111111_l1_():
	message = l1l111_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ䉽")
	l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䉾"),l1l111_l1_ (u"࠭ࠧ䉿"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䊀"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊁"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䊂"),l1l111_l1_ (u"ࠪࠫ䊃"),189,l1l111_l1_ (u"ࠫࠬ䊄"),l1l111_l1_ (u"ࠬ࠭䊅"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䊆"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊇"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䊈")+l1lllll_l1_+l1l111_l1_ (u"ࠩห์ู่ࠠศ๊ไ๎ุࠦๅ้ใํึ๊ࠥว็ัࠪ䊉"),l111l1_l1_,181,l1l111_l1_ (u"ࠪࠫ䊊"),l1l111_l1_ (u"ࠫࠬ䊋"),l1l111_l1_ (u"ࠬࡨ࡯ࡹ࠯ࡲࡪ࡫࡯ࡣࡦࠩ䊌"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊍"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䊎")+l1lllll_l1_+l1l111_l1_ (u"ࠨละำะࠦวๅษไ่ฬ๋ࠧ䊏"),l111l1_l1_,181,l1l111_l1_ (u"ࠩࠪ䊐"),l1l111_l1_ (u"ࠪࠫ䊑"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ䊒"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊓"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䊔")+l1lllll_l1_+l1l111_l1_ (u"ࠧหๆํๅื๐่็่ࠢ์ๆ๐าࠡๆส๊ิ࠭䊕"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䊖"),l1l111_l1_ (u"ࠩࠪ䊗"),l1l111_l1_ (u"ࠪࡸࡻ࠭䊘"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊙"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊚")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅษๆฯึࠦๅีษ๊ำฮ࠭䊛"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䊜"),l1l111_l1_ (u"ࠨࠩ䊝"),l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䊞"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊟"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䊠")+l1lllll_l1_+l1l111_l1_ (u"ࠬษโ้๋ࠣห้อแๅษ่ࠤฬ๊อศๆํอࠬ䊡"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䊢"),l1l111_l1_ (u"ࠧࠨ䊣"),l1l111_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䊤"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪ䊥"),headers,l1l111_l1_ (u"ࠪࠫ䊦"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䊧"))
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠳ࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䊨"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊩"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䊪")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩ䊫")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ䊬"),headers,l1l111_l1_ (u"ࠪࠫ䊭"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ䊮"))
	if type==l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䊯"): block = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄรฮัฮࠤฬ๊รโๆส้ࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࡪ࠴ࠫ䊰"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ䊱"): block = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ส๋็ุࠦว้ใํื๋่ࠥโ์ีࠤ้อๆะ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࡮࠱ࠨ䊲"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䊳"): block = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࠳࠯ࡲࡺࡪࡸ࡬ࡢࡻࠫ࠲࠯ࡅࠩ࠽ࡵࡷࡽࡱ࡫࠾ࠨ䊴"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䊵"): block = re.findall(l1l111_l1_ (u"ࠬࡨࡴ࡯࠯࠴ࠤࡧࡺ࡮࠮ࡣࡥࡷࡴࡲࡹࠩ࠰࠭ࡃ࠮ࡨࡴ࡯࠯࠵ࠤࡧࡺ࡮࠮ࡣࡥࡷࡴࡲࡹࠨ䊶"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"࠭ࡴࡷࠩ䊷"): block = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾หๆํๅื๐่็่ࠢ์ๆ๐าࠡๆส๊ิࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡧࠣࠩ䊸"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䊹"),l1l111_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䊺")]:
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡹࡿ࡬ࡦ࠿ࠥࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵࡴࡵࡱࡰ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䊻"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࡁࠧ࠹࡛࠱࠯࠼ࡡ࠰ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡱࡷࡸࡴࡳ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䊼"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ䊽"),l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭䊾"),l1l111_l1_ (u"ࠧศๆะ่็ํࠧ䊿"),l1l111_l1_ (u"ࠨ฻ิฺࠬ䋀"),l1l111_l1_ (u"ࠩࡕࡥࡼ࠭䋁"),l1l111_l1_ (u"ࠪࡗࡲࡧࡣ࡬ࡆࡲࡻࡳ࠭䋂"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ䋃"),l1l111_l1_ (u"ࠬอฬำษฤࠫ䋄")]
	for l1ll1l_l1_,l1l1lllll1l1_l1_,l1ll1111111l_l1_,l1ll111111l1_l1_ in items:
		if type in [l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䋅"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䋆")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1lllll1l1_l1_,l1ll1111111l_l1_,l1ll111111l1_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1lllll1l1_l1_,l1ll1111111l_l1_,l1ll111111l1_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨࡁࡹ࡭ࡪࡽ࠽ࡵࡴࡸࡩࠬ䋇"),l1l111_l1_ (u"ࠩࠪ䋈"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠪฬั๎ฯสࠢࠪ䋉") in title or l1l111_l1_ (u"ࠫอา่ะ้ࠣࠫ䋊") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䋋") + title.replace(l1l111_l1_ (u"࠭ศอ๊าอࠥ࠭䋌"),l1l111_l1_ (u"ࠧࠨ䋍")).replace(l1l111_l1_ (u"ࠨสฯ์ิํࠠࠨ䋎"),l1l111_l1_ (u"ࠩࠪ䋏"))
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䋐"))
		if l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ䋑") in title or l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬ䋒") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡝ࡦ࠮ࠫ䋓"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䋔") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䋕"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䋖") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䋗"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䋘") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䋙"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭ࠧ䋚"):
		items = re.findall(l1l111_l1_ (u"ࠧ࡝ࡰ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䋛"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠨษ็ูๆำษࠡࠩ䋜"),l1l111_l1_ (u"ࠩࠪ䋝"))
			if title!=l1l111_l1_ (u"ࠪࠫ䋞"):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋟"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䋠")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䋡"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䋢"),headers,l1l111_l1_ (u"ࠨࠩ䋣"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䋤"))
	block = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡺ࡬ࡦࡀ࠱࠮ࡄ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䋥"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡡ࠰࠮࠻ࡠ࠯ࠬ䋦"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䋧") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳࡏࡷࡰࡦࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䋨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䋩"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"ࠨࠪส่า๊โสࡾส่า๊โ่ࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ䋪"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䋫"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠪࠬ࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ䋬"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭䋭"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠬࠦࠧ䋮") + title[0][1]
			else: title = l1l111_l1_ (u"࠭ࠧ䋯")
			title = name + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䋰") + l1l111_l1_ (u"ࠨษ็ั้่ษࠨ䋱") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䋲"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠪฬั๎ฯสࠢࠪ䋳") in title or l1l111_l1_ (u"ࠫอา่ะ้ࠣࠫ䋴") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䋵") + title.replace(l1l111_l1_ (u"࠭ศอ๊าอࠥ࠭䋶"),l1l111_l1_ (u"ࠧࠨ䋷")).replace(l1l111_l1_ (u"ࠨสฯ์ิํࠠࠨ䋸"),l1l111_l1_ (u"ࠩࠪ䋹"))
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䋺"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1llllll1l_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䋻"))
	l1lllll1_l1_ = l1l1llllll1l_l1_[0]
	del l1l1llllll1l_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䋼"),headers,l1l111_l1_ (u"࠭ࠧ䋽"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䋾"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨࡲࡲࡹ࠳ࡳࡪࡼࡨ࠾ࠥ࠸࠵ࡱࡺ࠾ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䋿"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1llllll1l_l1_: l1l1llllll1l_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1llllll1l_l1_:
		if l1l111_l1_ (u"ࠩ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䌀") in l1ll1ll_l1_:
			l1l1lllll111_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1lllll111_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡦ࡯࡮ࠨ䌁"))
	for l1ll1ll_l1_ in l1l1llllll1l_l1_:
		if l1l111_l1_ (u"ࠫ࠿࠵࠯ࡷࡤ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠧ䌂") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䌃"),headers,l1l111_l1_ (u"࠭ࠧ䌄"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䌅"))
			html = html.decode(l1l111_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴ࠯࠴࠶࠺࠼ࠧ䌆")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䌇"))
			html = html.replace(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌈"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌉"))
			html = html.replace(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌊"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䌋"))
			html = html.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࡀࡧࡸࠠ࠰ࡀ࠿ࡨ࡮ࡼࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢ࠿ࠩ䌌"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌍"))
			html = html.replace(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡦࡴࡸࡤࡦࡴࠥࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠬ䌎"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌏"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䌐"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1lllll11l_l1_,l1ll11l11l1l_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠬ࠭䌑")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠲࠯ࡅ࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰ࠫࠩ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䌒"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ䌓") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅ࠼ࡩࡴࠣࡷ࡮ࢀࡥ࠾ࠤ࠴ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠬ䌔")+l1l111_l1_ (u"ࠩࠦࠫ䌕")+l1l111_l1_ (u"ࠪ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠬ䌖")+l1l111_l1_ (u"ࠫࠨ࠭䌗")+l1l111_l1_ (u"ࠬ࠹࠳࠴ࠤࠣ࠳ࡃ࠮࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䌘"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࠨ䌙") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂ࠭ࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠪ䌚")+l1l111_l1_ (u"ࠨࠥࠪ䌛")+l1l111_l1_ (u"ࠩ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠫ䌜")+l1l111_l1_ (u"ࠪࠧࠬ䌝")+l1l111_l1_ (u"ࠫ࠸࠹࠳ࠣࠢ࠲ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䌞"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠬࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䌟")
						l1l1llllllll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࠩ࠰࠭ࡃ࠮࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲࠭ࡵ࡮࡭࡫ࡱࡩࢁࡩ࡯࡮ࠫ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳ࠬ䌠"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠧ࠿ࠢ࠭ࠬࡠࡤ࠼࠿࡟࠮࠭ࠥ࠰࠼ࠨ䌡"),l1l1llllllll_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"ࠨࠢࠪ䌢").join(title)
						title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ䌣"))
						title = title.replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䌤"),l1l111_l1_ (u"ࠫࠥ࠭䌥")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌦"),l1l111_l1_ (u"࠭ࠠࠨ䌧")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䌨"),l1l111_l1_ (u"ࠨࠢࠪ䌩")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䌪"),l1l111_l1_ (u"ࠪࠤࠬ䌫")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䌬"),l1l111_l1_ (u"ࠬࠦࠧ䌭"))
						l1l1lllll11l_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭รฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆู็์อࡀࠧ䌮"), l1l1lllll11l_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1lllll11l_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠫࠥࠫ䌯"),block,re.DOTALL)
				l1l1llll1lll_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1llll1lll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡈࡲࡶࡺࡳࠧ䌰"))
				block = block.replace(l1l111_l1_ (u"ࠩใࠫ䌱"),l1l111_l1_ (u"ࠪࠫ䌲"))
				block = block.replace(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠹࠶࠽࠴࠲࠴࠴࠻࠺࠸࠹࠷࠰ࡳࡲ࡬ࠨࠧ䌳"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡦࡴࡺࡨࠣࠢࠣࡠࡳࠦࠠࠨ䌴"))
				block = block.replace(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡧࡴࡳ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠸࠵࠼࠺࠱࠳࠳࠺࠹࠷࠿࠶࠯ࡲࡱ࡫ࠧ࠭䌵"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䌶"))
				block = block.replace(l1l111_l1_ (u"ࠨีํีๆืวหࠢส่ฯำๅ๋ๆࠪ䌷"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠣࠤࡡࡴࠠࠡࠩ䌸"))
				block = block.replace(l1l111_l1_ (u"ࠪีํอศุࠢส่ฯำๅ๋ๆࠪ䌹"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ䌺"))
				block = block.replace(l1l111_l1_ (u"ู๊ࠬาใิหฯࠦวๅ็ืห์ีࠧ䌻"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡼࡧࡴࡤࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䌼"))
				block = block.replace(l1l111_l1_ (u"ࠧา๊สฬ฼ࠦวๅ็ืห์ีࠧ䌽"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䌾"))
				l1l1lllll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳ࡡࡪࠫࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䌿"),block,re.DOTALL)
				for l1l1lllllll1_l1_ in l1l1lllll1ll_l1_:
					type = re.findall(l1l111_l1_ (u"ࠪࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࠨ䍀"),l1l1lllllll1_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠫࡧࡵࡴࡩࠩ䍁"): type = l1l111_l1_ (u"ࠬࡥ࡟ࠨ䍂")+type[0]
						else: type = l1l111_l1_ (u"࠭ࠧ䍃")
					items = re.findall(l1l111_l1_ (u"ࠧࠩࡁ࠿ࠥ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰ࠫࠫࡠࡼ࠱࡛ࠡ࡞ࡺࡡ࠯ࡂ࠯ࡧࡱࡱࡸࡃ࠴ࠪࡀࡾ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮ࡁࡨࡲࠡ࠱ࡁ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳࠳࠰࠿ࠪࠤࠪ䍄"),l1l1lllllll1_l1_,re.DOTALL)
					for l1l1llllll11_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"ࠨࠪ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮࠮ࡂࠧ䍅"),l1l1llllll11_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䍆") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1l1l1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ䍇"),headers,l1l111_l1_ (u"ࠫࠬ䍈"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ䍉"))
	items = re.findall(l1l111_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䍊"),html,re.DOTALL)
	if items:
		l1ll111111ll_l1_ = items[-1]
		l1llll_l1_.append(l1ll111111ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡱࡥ࡭ࡱ࡫ࠧ䍋"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䍌"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ䍍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ䍎"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭䍏"),l1l111_l1_ (u"ࠬ࠱ࠧ䍐"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ䍑"),headers,l1l111_l1_ (u"ࠧࠨ䍒"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ䍓"))
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࡁࠫ䍔"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠪࠫ䍕") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠫฬ๊ใๅ๋ࠢฬิ๎ๆࠡใ็ฮึ࠭䍖") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ䍗"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"࠭ࠧ䍘")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䍙")+search+l1l111_l1_ (u"ࠨࠨࡰࡧࡦࡺ࠽ࠨ䍚")+category
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ⋍")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡄ࠷ࡣࠬ⋎")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠩ⋏"),l1l111_l1_ (u"ࠨษอู้ࠦศ็ษࠪ⋐"),l1l111_l1_ (u"ࠩส๎ั๐ࠠษีอࠤฬ๊วึๆํࠫ⋑"),l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠥอไอัํำࠬ⋒"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅสา๎้࠭⋓"),l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭⋔"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢหืฯ࠭⋕")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==800: l1lll_l1_ = l1l1l11_l1_()
	elif mode==801: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==802: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==803: l1lll_l1_ = PLAY(url)
	elif mode==804: l1lll_l1_ = l111ll11l1_l1_(url)
	elif mode==806: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==809: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋖"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⋗"),l1l111_l1_ (u"ࠩࠪ⋘"),809,l1l111_l1_ (u"ࠪࠫ⋙"),l1l111_l1_ (u"ࠫࠬ⋚"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⋛"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋜"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอีࠬ⋝"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ⋞"),804,l1l111_l1_ (u"ࠩࠪ⋟"),l1l111_l1_ (u"ࠪࠫ⋠"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⋡"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⋢"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⋣"),l1l111_l1_ (u"ࠧࠨ⋤"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⋥"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ⋦"),l1l111_l1_ (u"ࠪࠫ⋧"),l1l111_l1_ (u"ࠫࠬ⋨"),l1l111_l1_ (u"ࠬ࠭⋩"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⋪"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡹ࠱ࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⋫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⋬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ⋭"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⋮") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋯"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⋰")+l1lllll_l1_+title,l1ll1ll_l1_,801)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⋱"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⋲"),l1l111_l1_ (u"ࠨࠩ⋳"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࡃ࠭⋴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࡕ࡫ࡷࡰࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⋵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⋶"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⋷") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋸"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⋹")+l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠨࠩ⋺"),l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠫ⋻"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⋼"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⋽"),l1l111_l1_ (u"ࠬ࠭⋾"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⋿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⌀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⌁"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⌂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌃"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⌄")+l1lllll_l1_+title,l1ll1ll_l1_,801)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⌅")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⌆"),url,l1l111_l1_ (u"ࠧࠨ⌇"),l1l111_l1_ (u"ࠨࠩ⌈"),l1l111_l1_ (u"ࠩࠪ⌉"),l1l111_l1_ (u"ࠪࠫ⌊"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⌋"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡗ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡲࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠭⌌"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"࠭ࠧ⌍"),l1l111_l1_ (u"ࠧࠨ⌎"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠨฯ็ๆฬะࠧ⌏") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"่ࠩ์ฬูๅࠨ⌐") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⌑"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌒"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⌓"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⌔"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⌕"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⌖"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⌗"),l1lllll_l1_+title,l1ll1ll_l1_,803)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ⌘")):
	limit,start,l1l1l1ll1_l1_,select,l111ll111l_l1_ = 0,0,l1l111_l1_ (u"ࠫࠬ⌙"),l1l111_l1_ (u"ࠬ࠭⌚"),l1l111_l1_ (u"࠭ࠧ⌛")
	if l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ⌜") in type:
		l111ll1l11_l1_,l1l11llll_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡱࡩࡽࡺ࠽ࡱࡣࡪࡩࠫ࠭⌝"))
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⌞"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⌟")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ⌠"),l111ll1l11_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭⌡"),l1l111_l1_ (u"࠭ࠧ⌢"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⌣"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠨࡵࡨࡧࡈࡵ࡮ࡵࡧࡱࡸࠬ⌤")+html+l1l111_l1_ (u"ࠩ࠿ࡪࡴࡵࡴࡦࡴࡁࠫ⌥")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⌦"),url,l1l111_l1_ (u"ࠫࠬ⌧"),l1l111_l1_ (u"ࠬ࠭⌨"),l1l111_l1_ (u"࠭ࠧ〈"),l1l111_l1_ (u"ࠧࠨ〉"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⌫"))
		html = response.content
		l11l1ll1_l1_ = html
	items,l111llllll_l1_,filters = [],False,False
	if not type and l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳࠨ⌬") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⌭"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⌮"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⌯"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⌰"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠧࠨ⌱"),l1l111_l1_ (u"ࠨࡵࡸࡦࡲ࡫࡮ࡶࠩ⌲"))
				l111llllll_l1_ = True
	if not l111llllll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡨࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡱࡦ࡯࡮ࡄࡱࡱࡸࡪࡴࡴࠨ⌳"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⌴"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠫࡡࡴࠧ⌵"))
				title = unescapeHTML(title)
				if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⌶") in l1ll1ll_l1_ and type==l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⌷"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌸"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⌹"))
				elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⌺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌻"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ⌼") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⌽"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⌾"))
				elif l1l111_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲࡸ࠭⌿") in url: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍀"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠩࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡹࠧ⍁"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⍂"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡱࡵࡡࡥࡏࡲࡶࡪࡖࡡࡳࡣࡰࡷࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁࠧ⍃"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			params = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ⍄"),block)
			l111ll111l_l1_ = params[l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻࡹࡷࡲࠧ⍅")]
			l111l1llll_l1_ = int(params[l1l111_l1_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡲࡤ࡫ࡪ࠭⍆")])+1
			l111ll1111_l1_ = int(params[l1l111_l1_ (u"ࠨ࡯ࡤࡼࡤࡶࡡࡨࡧࠪ⍇")])
			query = params[l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡳࠨ⍈")].replace(l1l111_l1_ (u"ࠪࡊࡦࡲࡳࡦࠩ⍉"),l1l111_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ⍊")).replace(l1l111_l1_ (u"࡚ࠬࡲࡶࡧࠪ⍋"),l1l111_l1_ (u"࠭ࡴࡳࡷࡨࠫ⍌")).replace(l1l111_l1_ (u"ࠧࡏࡱࡱࡩࠬ⍍"),l1l111_l1_ (u"ࠨࡰࡸࡰࡱ࠭⍎"))
			if l111l1llll_l1_<l111ll1111_l1_:
				l1l11llll_l1_ = l1l111_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯࠿࡯ࡳࡦࡪ࡭ࡰࡴࡨࠪࡶࡻࡥࡳࡻࡀࠫ⍏")+QUOTE(query,l1l111_l1_ (u"ࠪࠫ⍐"))+l1l111_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ⍑")+str(l111l1llll_l1_)
				l1lllll1_l1_ = l111ll111l_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡦࡺࡷࡁࡵࡧࡧࡦࠨࠪ⍒")+l1l11llll_l1_
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⍓"),l1lllll_l1_+l1l111_l1_ (u"ࠧอๆหࠤฬ๊ๅำ์าࠫ⍔"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠨࠩ⍕"),l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡥࠧ⍖")+type)
		elif l1l111_l1_ (u"ࠪࡃࡳ࡫ࡸࡵ࠿ࡳࡥ࡬࡫ࠦࠨ⍗") in url:
			l1l11llll_l1_,l1lll1l1l_l1_ = l1l11llll_l1_.rsplit(l1l111_l1_ (u"ࠫࡂ࠭⍘"),1)
			l1lll1l1l_l1_ = int(l1lll1l1l_l1_)+1
			l1lllll1_l1_ = l111ll1l11_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡦࡺࡷࡁࡵࡧࡧࡦࠨࠪ⍙")+l1l11llll_l1_+l1l111_l1_ (u"࠭࠽ࠨ⍚")+str(l1lll1l1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⍛"),l1lllll_l1_+l1l111_l1_ (u"ࠨฮ็ฬࠥอไๆิํำࠬ⍜"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠩࠪ⍝"),l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࡟ࠨ⍞")+type)
	return
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⍟"),url,l1l111_l1_ (u"ࠬ࠭⍠"),l1l111_l1_ (u"࠭ࠧ⍡"),l1l111_l1_ (u"ࠧࠨ⍢"),l1l111_l1_ (u"ࠨࠩ⍣"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱ࡋࡏࡌࡕࡇࡕࡗ࠲࠷ࡳࡵࠩ⍤"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡺࡨ࡟࡯ࡣࡹࠬ࠳࠰࠿ࠪࡵࡨࡧࡈࡵ࡮ࡵࡧࡱࡸࠥ࠭⍥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡵࡳࡴࡨࡲࡹࡥ࡯ࡱࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⍦"),block,re.DOTALL)
		for name,block in l1lll1l1_l1_:
			if l1l111_l1_ (u"ࠬอไหื้๎ๆ࠭⍧") in name: continue
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ⍨"))
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⍩"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ⍪")+value
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍫"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠪࠫ⍬"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⍭"))
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⍮"),url,l1l111_l1_ (u"࠭ࠧ⍯"),l1l111_l1_ (u"ࠧࠨ⍰"),l1l111_l1_ (u"ࠨࠩ⍱"),l1l111_l1_ (u"ࠩࠪ⍲"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⍳"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡤ࠿ษ็ฮฺ์๊โ࠾࠲ࡸࡩࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⍴"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l111ll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡈࡱࡧ࡫ࡤ࠯ࠬࡂࡴࡴࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ⍵"),html,re.DOTALL)
	if l111ll1ll1_l1_:
		l1ll_l1_ = base64.b64decode(l111ll1ll1_l1_[0])
		if PY3: l1ll_l1_ = l1ll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⍶"))
		l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⍷"),l1ll_l1_)
		l1ll_l1_ = list(l1ll_l1_.values())
		for l1ll1ll_l1_ in l1ll_l1_:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭⍸"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⍹")+server+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⍺"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࡆࡲࡻࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ⍻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡳࡀ࠱࠮ࡄࡂࡴࡥࡀ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯࠮࡜ࡥࡽ࠶࠰࠹ࢃࠩ࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⍼"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"࠭࠯ࡀࡷࡵࡰࡂ࠭⍽") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࡁࡸࡶࡱࡃࠧ⍾"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭⍿"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⎀")+server+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ⎁")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⎂"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⎃"),l1l111_l1_ (u"࠭ࠫࠨ⎄"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⎅")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⎆"))
	return
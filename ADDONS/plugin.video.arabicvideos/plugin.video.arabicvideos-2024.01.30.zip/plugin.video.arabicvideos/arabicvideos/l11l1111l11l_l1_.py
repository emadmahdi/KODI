# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ弔")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ引")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l11l11ll1ll1_l1_(url)
	elif mode==146: l1lll_l1_ = l11l11111111_l1_(url)
	elif mode==147: l1lll_l1_ = l11l11l11lll_l1_()
	elif mode==148: l1lll_l1_ = l11l11l1l11l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弖"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ弗"),l1l111_l1_ (u"ࠬ࠭弘"),149,l1l111_l1_ (u"࠭ࠧ弙"),l1l111_l1_ (u"ࠧࠨ弚"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ弛"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弜"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ弝")+l1l111_l1_ (u"ࠫࡤ࡟ࡔࡄࡡࠪ弞")+l1l111_l1_ (u"๋่ࠬศไ฼ࠤฬิสศำ๊หࠥอไๆสิ้ั࠭弟"),l1l111_l1_ (u"࠭ࠧ张"),290)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弡"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ弢")+l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ฬู่ࠡษัฮฬื็ศࠢํ์ฯ๐่ษࠩ弣"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ弤"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弥"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弦")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨ弧"),l111l1_l1_,144,l1l111_l1_ (u"ࠧࠨ弨"),l1l111_l1_ (u"ࠨࠩ弩"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭弪"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弫"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭弬")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆฯอ์๎ࠦวๅำสสั࠭弭"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ弮"),146)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ弯"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ弰"),l1l111_l1_ (u"ࠩࠪ弱"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弲"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭弳")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢ฼ีอ๐ษࠨ弴"),l1l111_l1_ (u"࠭ࠧ張"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弶"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ強")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯࠦรอ่ห๎ฮ࠭弸"),l1l111_l1_ (u"ࠪࠫ弹"),148)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ强"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弻")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣ฽ึฮ๊สࠩ弼"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ใํ่๊࠭弽"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弾"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弿")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ彀"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ彁"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彂"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ彃")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำาฯํหฯูࠦาสํอࠬ彄"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืึำ๊สࠩ彅"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彆"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ彇")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ฽ึฮ๊สࠩ彈"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิๆึ่ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ彉"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彊"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ彋")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ彌"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ彍"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭彏")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ่อัห๊้ࠫ彐"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ไษิฮํ์ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ彑"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ归"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ当")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ彔"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭ๆีอ๊วย࠭ส่ๆ฼วว์ฬ࠯ำ฽ศส࠭ส่ัู๋สࠨࡶࡴࡂࡉࡁࡊࡕࡄ࡬ࡆࡈࠧ录"),144)
	return
def l11l11l11lll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ彖"))
	return
def l11l11l1l11l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ彗"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11111111_l1_(url):
	html,l1llll1lll_l1_,data = l11l11l111ll_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彘")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彙")][l1l111_l1_ (u"ࠨࡶࡤࡦࡸ࠭彚")]
	for l1l111llll_l1_ in range(len(dd)):
		item = dd[l1l111llll_l1_]
		l11l111l11ll_l1_(item,url,str(l1l111llll_l1_))
	l11l11111lll_l1_ = dd[0][l1l111_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彛")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ彜")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彝")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ彞")]
	s = 0
	for l1l111llll_l1_ in range(len(l11l11111lll_l1_)):
		item = l11l11111lll_l1_[l1l111llll_l1_][l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ彟")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ彠")][0]
		if list(item[l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彡")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ形")].keys())[0]==l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ彣"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_ = l11l11lll1l1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭彤")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彥"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"࠭ࠧ彦"),str(l1l111llll_l1_))
	key = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ彧"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭彨")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11l111ll_l1_(l1lllll1_l1_)
	for l1llll1l1l1l_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ彩")][l1llll1l1l1l_l1_][l1l111_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彪")][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ彫")]
		for l1l111llll_l1_ in range(len(dd)):
			item = dd[l1l111llll_l1_]
			if l1l111_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ彬") in str(item): continue
			l11l111l11ll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"࠭ࠧ彭"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ彮"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ彯"),l1l111_l1_ (u"ࠩࠪ彰"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11l111ll_l1_(url,data)
	l1l11ll11l_l1_,l111lllllll1_l1_ = l1l111_l1_ (u"ࠪࠫ影"),l1l111_l1_ (u"ࠫࠬ彲")
	owner = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ彳"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ彴"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ彵"),html,re.DOTALL)
	if owner:
		l1l11ll11l_l1_ = l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ彶")+owner[0][0]+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ彷")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ彸") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ役") in url: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彺"),l1lllll_l1_+l1l11ll11l_l1_,l1ll1ll_l1_,144)
	l11l11111l11_l1_ = [l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ彻"),l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ彼"),l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ彽"),l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭彾"),l1l111_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭彿"),l1l111_l1_ (u"ࠫࡸࡹ࠽ࠨ往"),l1l111_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭征"),l1l111_l1_ (u"࠭࡫ࡦࡻࡀࠫ徂"),l1l111_l1_ (u"ࠧࡣࡲࡀࠫ徃"),l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ径")]
	l111llllll1l_l1_ = not any(value in url for value in l11l11111l11_l1_)
	if l111llllll1l_l1_ and l1l11ll11l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠩส่อำหࠨ待")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠪๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ徆")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠨ徇")
		l111llllllll_l1_ = l1l111_l1_ (u"ࠬอไใ่๋หฯ࠭很")
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ徉"),l1lllll_l1_+l1l11ll11l_l1_,url,9999)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤหัะࠨࠧ徊") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ律"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠩࠪ後"),l1l111_l1_ (u"ࠪࠫ徍"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ徎"))
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ徏") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徐"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ徑"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ徒") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ従"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ徔"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ徕") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ徖"),l1lllll_l1_+l111llllllll_l1_,url+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ得"),144)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡖࡩࡦࡸࡣࡩࠤࠪ徘") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ徙"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠩࠪ徚"),l1l111_l1_ (u"ࠪࠫ徛"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ徜"))
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ徝") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭從"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ徟"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ徠") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ御"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ徢"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ徣") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ徤"),l1lllll_l1_+l111llllllll_l1_,url+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ徥"),144)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ徦"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ徧"),l1l111_l1_ (u"ࠩࠪ徨"),9999)
	if l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ復") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭循")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ徫")][l1l111_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ徬")][l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭徭")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ微")]
		l111lllll1ll_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ徯") in list(dd[i].keys()):
				l111lllll1l1_l1_ = dd[i][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ徰")]
				length = len(str(l111lllll1l1_l1_))
				if length>l111lllll1ll_l1_:
					l111lllll1ll_l1_ = length
					l111lllllll1_l1_ = l111lllll1l1_l1_
		if l111lllll1ll_l1_==0: return
	elif l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ徱") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ徲") in url or l1l111_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ徳") in url or l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ徴") in url or l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ徵") in url or url==l111l1_l1_:
		l11l111l11l1_l1_ = []
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ徶"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ德"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ徸"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ徹"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ徺"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠯࠴ࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ徻"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ徼"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡗࡢࡶࡦ࡬ࡓ࡫ࡸࡵࡔࡨࡷࡺࡲࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣࠢ徽"))
		l11l111111ll_l1_,l111lllllll1_l1_ = l111lllll11l_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠪࠫ徾"),l11l111l11l1_l1_)
	if not l111lllllll1_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭徿")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ忀")][l1l111_l1_ (u"࠭ࡴࡢࡤࡶࠫ忁")]
			l1lllll1ll1l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ忂") in url or l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ心") in url or l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ忄") in url
			l11l1111ll11_l1_ = l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ必") in html or l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ忆") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ忇") in html
			l11l1111l1ll_l1_ = l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ忈") in html or l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭忉") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭忊") in html
			if l1lllll1ll1l_l1_ and (l11l1111ll11_l1_ or l11l1111l1ll_l1_):
				for l1l111llll_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忋") not in list(dd[l1l111llll_l1_].keys()): continue
					l11l11111lll_l1_ = dd[l1l111llll_l1_][l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ忌")]
					try: l11l111111l1_l1_ = l11l11111lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ忍")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ忎")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ忏")][l1l111_l1_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ忐")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫ忑")][l1l111llll_l1_]
					except: l11l111111l1_l1_ = l11l11111lll_l1_
					try: l1ll1ll_l1_ = l11l111111l1_l1_[l1l111_l1_ (u"ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫ忒")][l1l111_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ忓")][l1l111_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ忔")][l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ忕")]
					except: continue
					if   l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ忖")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ志")		in url: l11l11111lll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ忘")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭忙")	in url: l11l11111lll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭忚")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ忛")		in url: l11l11111lll_l1_ = dd[l1l111llll_l1_] ; break
					else: l11l11111lll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ応") in url: l11l11111lll_l1_ = dd[index]
			else: l11l11111lll_l1_ = dd[0]
			l111lllllll1_l1_ = l11l11111lll_l1_[l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ忝")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ忞")]
		except: pass
	if not l111lllllll1_l1_: return
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ忟"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ忠"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ忡"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ忢"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ忣"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ忤"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ忥"))
	if l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ忦") not in url: l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩࡠ࡟ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭࡝ࠣ忧"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ忨"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ忩"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ忪"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ快"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ忬"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ忭"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ忮"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ忯"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬ࠢ忰"))
	l11l11ll1l1_l1_ = l111lll111l_l1_(l1l111_l1_ (u"ࡺ࠭ใๅࠢๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ忱"))
	l11l1111lll_l1_ = l111lll111l_l1_(l1l111_l1_ (u"ࡻࠧไๆࠣห้็๊ะ์๋๋ฬะࠧ忲"))
	l11l1111111l_l1_ = l111lll111l_l1_(l1l111_l1_ (u"ࡵࠨๅ็ࠤฬ๊โ็๊สฮࠬ忳"))
	l1l1ll11ll11_l1_ = [l11l11ll1l1_l1_,l11l1111lll_l1_,l11l1111111l_l1_,l1l111_l1_ (u"ࠨࡃ࡯ࡰࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ忴"),l1l111_l1_ (u"ࠩࡄࡰࡱࠦࡶࡪࡦࡨࡳࡸ࠭念"),l1l111_l1_ (u"ࠪࡅࡱࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ忶")]
	l11l11111l1l_l1_,l11l111111l1_l1_ = l111lllll11l_l1_(l111lllllll1_l1_,index,l11l111l11l1_l1_)
	if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ忷") in str(type(l11l111111l1_l1_)) and any(value in str(l11l111111l1_l1_[0]) for value in l1l1ll11ll11_l1_): del l11l111111l1_l1_[0]
	for index2 in range(len(l11l111111l1_l1_)):
		l11l111l11l1_l1_ = []
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ忸"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ忹"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ忺"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ忻"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ忼"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ忽"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ忾"))
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞ࠤ忿"))
		l11l111111ll_l1_,item = l111lllll11l_l1_(l11l111111l1_l1_,index2,l11l111l11l1_l1_)
		l11l111l11ll_l1_(item,url,str(index2))
		if l11l111111ll_l1_==l1l111_l1_ (u"࠭࠴ࠨ怀"):
			try:
				hh = item[l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ态")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ怂")][l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ怃")][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ怄")]
				for l11l111ll1ll_l1_ in range(len(hh)):
					l1l1ll1llll1_l1_ = hh[l11l111ll1ll_l1_]
					l11l111l11ll_l1_(l1l1ll1llll1_l1_)
			except: pass
	l111llllll_l1_ = False
	if l1l111_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ怅") not in url and l11l11111l1l_l1_==l1l111_l1_ (u"ࠬ࠾ࠧ怆"): l111llllll_l1_ = True
	if l1l111_l1_ (u"࠭࠺࠻࠼ࠪ怇") in l1l11llll_l1_: l11l11l1ll1l_l1_,key,l111llllll11_l1_,l11l11l1l111_l1_,token,l11l11l11l1l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ怈"))
	else: l11l11l1ll1l_l1_,key,l111llllll11_l1_,l11l11l1l111_l1_,token,l11l11l11l1l_l1_ = l1l111_l1_ (u"ࠨࠩ怉"),l1l111_l1_ (u"ࠩࠪ怊"),l1l111_l1_ (u"ࠪࠫ怋"),l1l111_l1_ (u"ࠫࠬ怌"),l1l111_l1_ (u"ࠬ࠭怍"),l1l111_l1_ (u"࠭ࠧ怎")
	l1lllll1_l1_,l111l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ怏"),l1l111_l1_ (u"ࠨࠩ怐")
	if menuItemsLIST:
		l11l1111l1l1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠩࡆࡌࡓࡒࠧ怑") in l11l1111l1l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ怒")
		elif l1lllll_l1_+l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩ怓") in l11l1111l1l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ怔")
		elif l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ怕") in l11l1111l1l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠧࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ怖")
	if l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡴࠤࠪ怗") in html and l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ怘") not in url and not l111llllll_l1_ and l1l111_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࠬ怙") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡤࡧࡪࡢࡺࡂࡧࡹࡵ࡫ࡦࡰࡀࠫ怚")+l111llllll11_l1_
	elif l1l111_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭怛") in html and l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ怜") not in url and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭思") in url or l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭怞") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭怟")+key
	elif l1l111_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥࠫ怠") in html and l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ怡") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ怢")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怣"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ怤"),l1lllll1_l1_,144,l111l1llll_l1_,l1l111_l1_ (u"ࠨࠩ急"),l1l11llll_l1_)
	return
def l111lllll11l_l1_(l1l1lllll1l1_l1_,l1ll1111111l_l1_,l11l111ll111_l1_):
	l1llll1lll_l1_ = l1l1lllll1l1_l1_
	l111lllllll1_l1_,index = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	l11l111111l1_l1_,index2 = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	item,l11l1111l111_l1_ = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	count = len(l11l111ll111_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l111ll111_l1_[l1l111llll_l1_])
			return str(l1l111llll_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠩࠪ怦"),l1l111_l1_ (u"ࠪࠫ性")
def l11l11lll1l1_l1_(item):
	try: l11l11l11ll1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠫࠬ怨"),l1l111_l1_ (u"ࠬ࠭怩"),l1l111_l1_ (u"࠭ࠧ怪"),l1l111_l1_ (u"ࠧࠨ怫"),l1l111_l1_ (u"ࠨࠩ怬"),l1l111_l1_ (u"ࠩࠪ怭"),l1l111_l1_ (u"ࠪࠫ怮")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_ = False,l1l111_l1_ (u"ࠫࠬ怯"),l1l111_l1_ (u"ࠬ࠭怰"),l1l111_l1_ (u"࠭ࠧ怱"),l1l111_l1_ (u"ࠧࠨ怲"),l1l111_l1_ (u"ࠨࠩ怳"),l1l111_l1_ (u"ࠩࠪ怴"),l1l111_l1_ (u"ࠪࠫ怵")
	l11l1111l111_l1_ = item[l11l11l11ll1_l1_]
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡻ࡮ࡱ࡮ࡤࡽࡦࡨ࡬ࡦࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ怶"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡦࡰࡴࡰࡥࡹࡺࡥࡥࡖ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ怷"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ怸"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ怹"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ怺"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ总"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ怼"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ怽"))
	l11l111111ll_l1_,title = l111lllll11l_l1_(item,l11l1111l111_l1_,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ怾"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ怿"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ恀"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ恁"))
	l11l111111ll_l1_,l1ll1ll_l1_ = l111lllll11l_l1_(item,l11l1111l111_l1_,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ恂"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ恃"))
	l11l111111ll_l1_,l1ll1l_l1_ = l111lllll11l_l1_(item,l11l1111l111_l1_,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ恄"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ恅"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ恆"))
	l11l111111ll_l1_,count = l111lllll11l_l1_(item,l11l1111l111_l1_,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ恇"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ恈"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ恉"))
	l11l111111ll_l1_,l1l1lll111_l1_ = l111lllll11l_l1_(item,l11l1111l111_l1_,l11l111l11l1_l1_)
	if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ恊") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ恋"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭恌")
	if l1l111_l1_ (u"࠭ๅษษืีࠬ恍") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ恎"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ恏")
	if l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ恐") in list(l11l1111l111_l1_.keys()):
		l11l11ll11ll_l1_ = str(l11l1111l111_l1_[l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ恑")])
		if l1l111_l1_ (u"ࠫࡋࡸࡥࡦࠢࡺ࡭ࡹ࡮ࠠࡂࡦࡶࠫ恒") in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠨ恓")
		if l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠤࡓࡕࡗࠨ恔") in l11l11ll11ll_l1_: l11l11l1llll_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ恕")
		if l1l111_l1_ (u"ࠨࡄࡸࡽࠬ恖") in l11l11ll11ll_l1_ or l1l111_l1_ (u"ࠩࡕࡩࡳࡺࠧ恗") in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠧ恘")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡹ๋ࠬศศึิࠫ恙")) in l11l11ll11ll_l1_: l11l11l1llll_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭恚")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡻࠧีำสลࠬ恛")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠫ恜")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡶࠩสืฯฬฬศำࠪ恝")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿࠭恞")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡸࠫส฿ไศ่สฮࠬ恟")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠧ恠")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ恡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"࠭࠿ࠨ恢"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ恣") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ恤")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l11l11l11_l1_: title = l11l11l11l11_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ恥")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠪ࠰ࠬ恦"),l1l111_l1_ (u"ࠫࠬ恧"))
	count = count.replace(l1l111_l1_ (u"ࠬ࠲ࠧ恨"),l1l111_l1_ (u"࠭ࠧ恩"))
	count = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ恪"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠨࠩ恫")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_
def l11l111l11ll_l1_(item,url=l1l111_l1_ (u"ࠩࠪ恬"),index=l1l111_l1_ (u"ࠪࠫ恭")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_ = l11l11lll1l1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ恮") in str(item): return
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ息") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ恰") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭恱") in url or l1l111_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ恲") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠩࡀࡁࡂࠦࠧ恳")+title+l1l111_l1_ (u"ࠪࠤࡂࡃ࠽ࠨ恴")
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ恵"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭恶"),9999)
	elif title and l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ恷") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ恸"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ恹"),9999)
	elif l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ恺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ恻"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l11l11l1llll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ恼"),l1lllll_l1_+l11l11l1llll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ恽") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ恾") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ恿") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ悀") not in l1ll1ll_l1_:
			l11l11l1l1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ悁"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ悂")+l11l11l1l1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ悃"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡒࡉࡔࡖࠪ悄")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ悅")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ悆"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ悇"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"ࠩࠪ悈")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ悉"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ悊"),l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ悋"),l1l111_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ悌"),l1l111_l1_ (u"ࠧࡴࡵࡀࠫ悍"),l1l111_l1_ (u"ࠨࡤࡳࡁࠬ悎")]):
			if l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ悏")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡨ࠵ࠧ悐") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ悑")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ悒")
			if l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭悓") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠧࡖࡕࡈࡖࠬ悔")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ悕")
			index,l11l11111ll1_l1_ = l1l111_l1_ (u"ࠩࠪ悖"),l1l111_l1_ (u"ࠪࠫ悗")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ悘"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l11l11l111ll_l1_(url,data=l1l111_l1_ (u"ࠬ࠭悙"),request=l1l111_l1_ (u"࠭ࠧ悚")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ悛"))
	if request==l1l111_l1_ (u"ࠨࠩ悜"): request = l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ悝")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ悞"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ悟"):l1l111_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ悠")}
	if l1l111_l1_ (u"࠭࠺࠻࠼ࠪ悡") in data: l11l11l1ll1l_l1_,key,l111llllll11_l1_,l11l11l1l111_l1_,token,l11l11l11l1l_l1_ = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ悢"))
	else: l11l11l1ll1l_l1_,key,l111llllll11_l1_,l11l11l1l111_l1_,token,l11l11l11l1l_l1_ = l1l111_l1_ (u"ࠨࠩ患"),l1l111_l1_ (u"ࠩࠪ悤"),l1l111_l1_ (u"ࠪࠫ悥"),l1l111_l1_ (u"ࠫࠬ悦"),l1l111_l1_ (u"ࠬ࠭悧"),l1l111_l1_ (u"࠭ࠧ您")
	if l1l111_l1_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ悩") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ悪")] = {l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ悫"):{l1l111_l1_ (u"ࠥ࡬ࡱࠨ悬"):l1l111_l1_ (u"ࠦࡦࡸࠢ悭"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ悮"):l1l111_l1_ (u"ࠨࡗࡆࡄࠥ悯"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ悰"):l11l11l1l111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭悱"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ悲"))
	elif l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ悳") in url and l11l11l1ll1l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ悴"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭悵")] = {l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ悶"):{l1l111_l1_ (u"ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ悷"):l11l11l1ll1l_l1_,l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ悸"):l1l111_l1_ (u"ࠤ࡚ࡉࡇࠨ悹"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ悺"):l11l11l1l111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ悻"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ悼"))
	elif l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ悽") in url and l11l11l11l1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ悾"):l1l111_l1_ (u"ࠨ࠳ࠪ悿"),l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭惀"):l11l11l1l111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ惁"):l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ惂")+l11l11l11l1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ惃"),url,l1l111_l1_ (u"࠭ࠧ惄"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ情"),l1l111_l1_ (u"ࠨࠩ惆"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ惇"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ惈"),url,l1l111_l1_ (u"ࠫࠬ惉"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭惊"),l1l111_l1_ (u"࠭ࠧ惋"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ惌"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惍"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惎"),html,re.DOTALL|re.I)
	if tmp: l11l11l1l111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ惏"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ惐"),html,re.DOTALL|re.I)
	if tmp: l11l11l1ll1l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ惑"),html,re.DOTALL|re.I)
	if tmp: l111llllll11_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ惒") in list(cookies.keys()): l11l11l11l1l_l1_ = cookies[l1l111_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ惓")]
	data = l11l11l1ll1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ惔")+key+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭惕")+l111llllll11_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ惖")+l11l11l1l111_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ惗")+token+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ惘")+l11l11l11l1l_l1_
	if request==l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭惙") and l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ惚") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ惛"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ惜"),html,re.DOTALL)
		l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ惝"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ惞") and l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ惟") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ惠"),html,re.DOTALL)
		l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ惡"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ惢") not in html: l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭惣"),html)
	else: l11l11ll11l1_l1_ = l1l111_l1_ (u"ࠪࠫ惤")
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭惥"),data)
	return html,l11l11ll11l1_l1_,data
def l11l11ll1ll1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ惦"),l1l111_l1_ (u"࠭ࠫࠨ惧"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ惨")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ惩"),l1l111_l1_ (u"ࠩ࠮ࠫ惪"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ惫")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ惬") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ惭")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ惮") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ惯")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭惰") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ惱")
		l1llllll_l1_ = l1lllll1_l1_+l11l111lll1l_l1_
	else:
		l11l111lll11_l1_,l11l1111llll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠪࠫ惲")
		l11l111l111l_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢอีฯ๐ศࠨ想"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ็าํࠥอไึๆฬࠫ惴"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢอหึ๐ฮࠡษ็ฮา๋๊ๅࠩ惵"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣ฽ิีࠠศๆุ่ฬํฯศฬࠪ惶"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฬ๊สใ์ํ้ࠬ惷")]
		l11l11ll111l_l1_ = [l1l111_l1_ (u"ࠩࠪ惸"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡄࠩ࠷࠻࠳ࡅࠩ惹"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡍࠪ࠸࠵࠴ࡆࠪ惺"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡒࠫ࠲࠶࠵ࡇࠫ惻"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡋࠥ࠳࠷࠶ࡈࠬ惼")]
		l11l11ll1l11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไหำอ๎อ࠭惽"),l11l111l111l_l1_)
		if l11l11ll1l11_l1_ == -1: return
		l11l111ll1l1_l1_ = l11l11ll111l_l1_[l11l11ll1l11_l1_]
		html,c,data = l11l11l111ll_l1_(l1lllll1_l1_+l11l111ll1l1_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ惾")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ惿")][l1l111_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ愀")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ愁")][l1l111_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭愂")][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ愃")][l1l111_l1_ (u"ࠧࡨࡴࡲࡹࡵࡹࠧ愄")]
			for l11l1111lll1_l1_ in range(len(d)):
				group = d[l11l1111lll1_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡇࡳࡱࡸࡴࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭愅")][l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ愆")]
				for l11l11ll1lll_l1_ in range(len(group)):
					l11l1111l111_l1_ = group[l11l11ll1lll_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ愇")]
					if l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ愈") in list(l11l1111l111_l1_.keys()):
						l1ll1ll_l1_ = l11l1111l111_l1_[l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ愉")][l1l111_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ愊")][l1l111_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ愋")][l1l111_l1_ (u"ࠨࡷࡵࡰࠬ愌")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡹ࠵࠶࠲࠷ࠩ愍"),l1l111_l1_ (u"ࠪࠪࠬ愎"))
						title = l11l1111l111_l1_[l1l111_l1_ (u"ࠫࡹࡵ࡯࡭ࡶ࡬ࡴࠬ意")]
						title = title.replace(l1l111_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠࠨ愐"),l1l111_l1_ (u"࠭ࠧ愑"))
						if l1l111_l1_ (u"ࠧฦิส่ฮࠦวๅใ็ฮึ࠭愒") in title: continue
						if l1l111_l1_ (u"ࠨไสส๊ฯࠠหึ฽๎้࠭愓") in title:
							title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ愔")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือ࠭愕") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠡࠩ愖"),l1l111_l1_ (u"ࠬ࠭愗"))
						if l1l111_l1_ (u"࠭ࡒࡦ࡯ࡲࡺࡪ࠭愘") in title: continue
						if l1l111_l1_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩ愙") in title:
							title = l1l111_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ愚")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠩࡖࡳࡷࡺࠠࡣࡻࠪ愛") in title: continue
						l11l111lll11_l1_.append(escapeUNICODE(title))
						l11l1111llll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l11l11ll1111_l1_ = l1l111_l1_ (u"ࠪࠫ愜")
		else:
			l11l111lll11_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢไ่ฯืࠧ愝"),l1lllllll_l1_]+l11l111lll11_l1_
			l11l1111llll_l1_ = [l1l111_l1_ (u"ࠬ࠭愞"),l111lllll_l1_]+l11l1111llll_l1_
			l11l11lll11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊แๅฬิࠫ感"),l11l111lll11_l1_)
			if l11l11lll11l_l1_ == -1: return
			l11l11ll1111_l1_ = l11l1111llll_l1_[l11l11lll11l_l1_]
		if l11l11ll1111_l1_: l1llllll_l1_ = l111l1_l1_+l11l11ll1111_l1_
		elif l11l111ll1l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l111ll1l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ䏬")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䏭"):l1l111_l1_ (u"ࠩࠪ䏮")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩ䏯")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ䏰"),l1l111_l1_ (u"ࠬࡽࡷࡦࠩ䏱")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭䏲")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ䏳")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䏴"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䏵"),l111l1_l1_,369,l1l111_l1_ (u"ࠪࠫ䏶"),l1l111_l1_ (u"ࠫࠬ䏷"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䏸"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䏹"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ䏺"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䏻"),364)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏼"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭䏽"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䏾"),365)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䏿"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐀"),l1l111_l1_ (u"ࠧࠨ䐁"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䐂"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ䐃"),l1l111_l1_ (u"ࠪࠫ䐄"),l1l111_l1_ (u"ࠫࠬ䐅"),l1l111_l1_ (u"ࠬ࠭䐆"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ䐇"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ䐈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䐉"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠩࠪ䐊"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐋"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䐌")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䐍"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐎"),l1l111_l1_ (u"ࠧࠨ䐏"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ䐐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐑"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐒"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䐓")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䐔"),url,l1l111_l1_ (u"࠭ࠧ䐕"),l1l111_l1_ (u"ࠧࠨ䐖"),l1l111_l1_ (u"ࠨࠩ䐗"),l1l111_l1_ (u"ࠩࠪ䐘"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䐙"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ䐚") in html:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐛"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ䐜"),url,361,l1l111_l1_ (u"ࠧࠨ䐝"),l1l111_l1_ (u"ࠨࠩ䐞"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䐟"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䐠"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䐡"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐢"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1llll1lll1l_l1_,type=l1l111_l1_ (u"࠭ࠧ䐣")):
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ䐤") in l1llll1lll1l_l1_:
		l1llllll_l1_,url = l1llll1lll1l_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ䐥"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䐦"))
		url = server+url
	else: url,l1llllll_l1_ = l1llll1lll1l_l1_,l1llll1lll1l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䐧"),url,l1l111_l1_ (u"ࠫࠬ䐨"),l1l111_l1_ (u"ࠬ࠭䐩"),l1l111_l1_ (u"࠭ࠧ䐪"),l1l111_l1_ (u"ࠧࠨ䐫"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䐬"))
	html = response.content
	if type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䐭"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ䐮"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䐯"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ䐰"),l1l111_l1_ (u"࠭࠯ࠨ䐱")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ䐲"),l1l111_l1_ (u"ࠨࠤࠪ䐳"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮ࡏࡼࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭䐴"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ䐵"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ䐶"),l1l111_l1_ (u"ࠬ࠭䐷"))
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䐸") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐹"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠨฯ็ๆฮ࠭䐺") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ䐻"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䐼") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐽"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䐾"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䐿"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ䑀"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ䑁")+count
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑂"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭䑃"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠫࠬ䑄"),l1l111_l1_ (u"ࠬ࠭䑅"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䑆"))
		elif type==l1l111_l1_ (u"ࠧࠨ䑇"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䑈"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䑉"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ูࠪๆำษࠡࠩ䑊")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑋"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭䑌")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䑍"),url,l1l111_l1_ (u"ࠧࠨ䑎"),l1l111_l1_ (u"ࠨࠩ䑏"),l1l111_l1_ (u"ࠩࠪ䑐"),l1l111_l1_ (u"ࠪࠫ䑑"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䑒"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣ࡫ࡷࡩࡲࠨࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠬ࠳࠰࠿ࠪࠤࠪ䑓"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"࠭࠭ࠨ䑔"),l1l111_l1_ (u"ࠧࠡࠩ䑕")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䑖"))
	if l1l111_l1_ (u"่ࠩ์ุ๋ࠧ䑗") in name and type==l1l111_l1_ (u"ࠪࠫ䑘"):
		name = name.split(l1l111_l1_ (u"๊ࠫ๎ำๆࠩ䑙"))[0]
		name = name.replace(l1l111_l1_ (u"๋ࠬิศ้าอࠬ䑚"),l1l111_l1_ (u"࠭ࠧ䑛")).strip(l1l111_l1_ (u"ࠧࠡࠩ䑜"))
	elif l1l111_l1_ (u"ࠨฯ็ๆฮ࠭䑝") in name:
		name = name.split(l1l111_l1_ (u"ࠩะ่็ฯࠧ䑞"))[0]
		name = name.replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠪ䑟"),l1l111_l1_ (u"ࠫࠬ䑠")).strip(l1l111_l1_ (u"ࠬࠦࠧ䑡"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷ࡮ࡴࡧ࡭ࡧࡶࡩࡨࡺࡩࡰࡰࠪ䑢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠧࠨ䑣"):
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ䑤"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳࠨ䑥") in title: continue
				if l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࠫ䑦") in title: continue
				title = name+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䑧")+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑨"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"࠭ࠧ䑩"),l1l111_l1_ (u"ࠧࠨ䑪"),l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䑫"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠱࠲࡙ࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩࠧࠨࠪ䑬"),block+l1l111_l1_ (u"ࠪࠪࠫ࠭䑭"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ䑮"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䑯"))
				title = name+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ䑰")+title
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䑱"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䑲"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ䑳"),l1l111_l1_ (u"ࠪࠫ䑴")).replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ䑵"),l1l111_l1_ (u"ࠬ࠭䑶"))
		else: title = l1l111_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ䑷")
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䑸"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䑹"),url,l1l111_l1_ (u"ࠩࠪ䑺"),l1l111_l1_ (u"ࠪࠫ䑻"),l1l111_l1_ (u"ࠫࠬ䑼"),l1l111_l1_ (u"ࠬ࠭䑽"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䑾"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䑿"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ䒀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䒁"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䒂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ุࠫ๐ัโำ้ࠣฬ๐ࠠิ์่หࠬ䒃"): name = l1l111_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ䒄")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䒅")+name+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ䒆")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䒇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䒈"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䒉") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䒊"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䒋")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ䒌")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽࡮ࡻࡦ࡭ࡲࡧࠧ䒍")+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䒎")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䒏"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠪࠫ䒐")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ䒑"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭䒒"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ䒓"),l1l111_l1_ (u"ࠧࠬࠩ䒔"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ䒕"),l1l111_l1_ (u"ࠩ࠲ࠫ䒖"),l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ䒗"),l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ䒘"),l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ䒙")]
	l1ll11111_l1_ = [l1l111_l1_ (u"࠭วๅๅ็ࠫ䒚"),l1l111_l1_ (u"ࠧศๆฦๅ้อๅࠨ䒛"),l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ䒜"),l1l111_l1_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭䒝"),l1l111_l1_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ䒞")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ䒟"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠬ࠭䒠"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䒡"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䒢"),l1l111_l1_ (u"ࠨࠩ䒣"),False,l1l111_l1_ (u"ࠩࠪ䒤"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䒥"))
		hostname = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䒦")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠬ࠵ࠧ䒧"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ䒨")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1llll1lll1l_l1_,filter):
	if l1l111_l1_ (u"ࠧࡀࡁࠪ䒩") in l1llll1lll1l_l1_: url = l1llll1lll1l_l1_.split(l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䒪"))[0]
	else: url = l1llll1lll1l_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䒫"),l1l111_l1_ (u"ࠪࠫ䒬"))
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ䒭"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭䒮"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧ䒯"),l1l111_l1_ (u"ࠧࠨ䒰")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䒱"))
	if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䒲"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠪࡁࡂ࠭䒳") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠫࡂࡃࠧ䒴") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䒵")+category+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ䒶")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䒷")+category+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䒸")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ䒹"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ䒺")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ䒻"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䒼"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䒽")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䒾"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䒿"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ䓀"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓁"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬ䓂"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䓃")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll1l_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓄"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ䓅"),l1111111_l1_,361,l1l111_l1_ (u"ࠨࠩ䓆"),l1l111_l1_ (u"ࠩࠪ䓇"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䓈"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓉"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ䓊")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ䓋"),l1111111_l1_,361,l1l111_l1_ (u"ࠧࠨ䓌"),l1l111_l1_ (u"ࠨࠩ䓍"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䓎"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䓏"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓐"),l1l111_l1_ (u"ࠬ࠭䓑"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䓒"),url,l1l111_l1_ (u"ࠧࠨ䓓"),l1l111_l1_ (u"ࠨࠩ䓔"),l1l111_l1_ (u"ࠩࠪ䓕"),l1l111_l1_ (u"ࠪࠫ䓖"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䓗"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ䓘"),l1l111_l1_ (u"࠭ࠢࠨ䓙")).replace(l1l111_l1_ (u"ࠧ࡝࡞࠲ࠫ䓚"),l1l111_l1_ (u"ࠨ࠱ࠪ䓛"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ䓜"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䓝"),block+l1l111_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䓞"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ䓟") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ䓠"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠧ࠾࠿ࠪ䓡") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䓢"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ䓣")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll1l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓤"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ䓥"),l1111111_l1_,361,l1l111_l1_ (u"ࠬ࠭䓦"),l1l111_l1_ (u"࠭ࠧ䓧"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䓨"))
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓩"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ䓪"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠪࠫ䓫"),l1l111_l1_ (u"ࠫࠬ䓬"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䓭"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䓮")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ䓯")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䓰")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭䓱")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ䓲")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓳"),l1lllll_l1_+name+l1l111_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ䓴"),l1lllll1_l1_,365,l1l111_l1_ (u"࠭ࠧ䓵"),l1l111_l1_ (u"ࠧࠨ䓶"),l1l111l1_l1_+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䓷"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠩࡵࠫ䓸") or value==l1l111_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ䓹"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䓺") in option: continue
			if l1l111_l1_ (u"ࠬอไไๆࠪ䓻") in option: continue
			if l1l111_l1_ (u"࠭࡮࠮ࡣࠪ䓼") in value: continue
			if option==l1l111_l1_ (u"ࠧࠨ䓽"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭䓾"),option,re.DOTALL)
			if l1ll1l11ll1_l1_: l1l11l1ll_l1_ = l1ll1l11ll1_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠩ࠽ࠤࠬ䓿")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䔀")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃࠧ䔁")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䔂")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩ䔃")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ䔄")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䔅"):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔆"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠪࠫ䔇"),l1l111_l1_ (u"ࠫࠬ䔈"),l1l1l11l_l1_+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䔉"))
			elif type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䔊") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔋") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䔌"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䔍")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1llll1lll1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔎"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠫࠬ䔏"),l1l111_l1_ (u"ࠬ࠭䔐"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䔑"))
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔒"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"ࠨࠩ䔓"),l1l111_l1_ (u"ࠩࠪ䔔"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ䔕"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ䔖"),l1l111_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ䔗")]
l1l1ll111_l1_ = [l1l111_l1_ (u"࠭࡭ࡱࡣࡤࠫ䔘"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䔙"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䔚"),l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ䔛"),l1l111_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫ䔜"),l1l111_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭䔝"),l1l111_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ䔞"),l1l111_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䔟")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䔠") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䔡"),l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࠪ䔢"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䔣"),l1l111_l1_ (u"ࠫ࠿ࡀ࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭࠯ࠨ䔤"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔥"),l1l111_l1_ (u"࠭࠯ࠨ䔦"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧࠧࠨࠪ䔧"),l1l111_l1_ (u"ࠨ࠱ࠪ䔨"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ䔩"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠪࠫ䔪")
	if l1l111_l1_ (u"ࠫࡂࡃࠧ䔫") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠦࠨ䔬"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽࠾ࠩ䔭"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ䔮")
		if l1l111_l1_ (u"ࠨࠧࠪ䔯") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䔰") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ䔱"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ䔲")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䔳") and value!=l1l111_l1_ (u"࠭࠰ࠨ䔴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䔵")+key+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔶")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱ࠭䔷"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䔸")+key+l1l111_l1_ (u"ࠫࡂࡃࠧ䔹")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ䔺"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ䔻"))
	return l1l1l111_l1_
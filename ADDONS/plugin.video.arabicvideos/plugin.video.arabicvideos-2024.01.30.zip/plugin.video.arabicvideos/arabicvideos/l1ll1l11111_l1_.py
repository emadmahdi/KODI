# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ⿜")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡐ࡚ࡖࡠࠩ⿝")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==810: l1lll_l1_ = l1l1l11_l1_()
	elif mode==811: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==812: l1lll_l1_ = PLAY(url)
	elif mode==813: l1lll_l1_ = l1ll11lllll_l1_(url)
	elif mode==819: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⿞"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭⿟"),l1l111_l1_ (u"࠭ࠧ⿠"),l1l111_l1_ (u"ࠧࠨ⿡"),l1l111_l1_ (u"ࠨࠩ⿢"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⿣"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⿤"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⿥"),l1l111_l1_ (u"ࠬ࠭⿦"),819,l1l111_l1_ (u"࠭ࠧ⿧"),l1l111_l1_ (u"ࠧࠨ⿨"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⿩"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⿪"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⿫"),l1l111_l1_ (u"ࠫࠬ⿬"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡳ࡫ࡰࡥࡷࡿ࠭࡭࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡳ࡯ࡴࡶ࠰ࡺ࡮࡫ࡷࡦࡦࠥࠫ⿭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⿮"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿯"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⿰")+l1lllll_l1_+title,l1ll1ll_l1_,811)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ⿱")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⿲"),url,l1l111_l1_ (u"ࠫࠬ⿳"),l1l111_l1_ (u"ࠬ࠭⿴"),l1l111_l1_ (u"࠭ࠧ⿵"),l1l111_l1_ (u"ࠧࠨ⿶"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⿷"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ⿸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⿹"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧ⿺"),title,re.DOTALL)
			if l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⿻") not in type and l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⿼") + l1l1lll_l1_[0][0]
				title = title.replace(l1l111_l1_ (u"ࠧศ๊้ࠤ้อ๊็ࠩ⿽"),l1l111_l1_ (u"ࠨࠩ⿾"))
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿿"),l1lllll_l1_+title,l1ll1ll_l1_,813,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ　"),l1lllll_l1_+title,l1ll1ll_l1_,812,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸࠢ、"),html,re.DOTALL)
	if l11llll_l1_:
		type = l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹ࡟ࡱࡣࡪࡩࡸ࠭。") if l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ〃") in type else l1l111_l1_ (u"ࠧࡱࡣࡪࡩࡸ࠭〄")
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ々"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〆"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ〇")+title,l1ll1ll_l1_,811,l1l111_l1_ (u"ࠫࠬ〈"),l1l111_l1_ (u"ࠬ࠭〉"),type)
	return
def l1ll11lllll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ《"),url,l1l111_l1_ (u"ࠧࠨ》"),l1l111_l1_ (u"ࠨࠩ「"),l1l111_l1_ (u"ࠩࠪ」"),l1l111_l1_ (u"ࠪࠫ『"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠳࠱ࡴࡶࠪ』"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡶࡨ࡫ࡴࡸࡹࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ【"),html,re.DOTALL)
	if l1ll1ll_l1_: l1lll11_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ】"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ〒")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ〓"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ〔"),l1l111_l1_ (u"ࠪࠫ〕"),l1l111_l1_ (u"ࠫࠬ〖"),l1l111_l1_ (u"ࠬ࠭〗"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ〘"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ〙"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ〚"),url,l1l111_l1_ (u"ࠩࠪ〛"),l1l111_l1_ (u"ࠪࠫ〜"),l1l111_l1_ (u"ࠫࠬ〝"),l1l111_l1_ (u"ࠬ࠭〞"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ〟"))
		html = response.content
		l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡂ࠮࠮ࠫࡁࠬࠦࠬ〠"),html,re.DOTALL)
		if l1ll11l_l1_:
			l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
			if PY3: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭〡"))
			l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ〢"),l1ll11l_l1_)
			l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡶࠫ〣")]
			l11l11_l1_ = list(l1ll_l1_.keys())
			l1ll_l1_ = list(l1ll_l1_.values())
			l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
			for title,l1ll1ll_l1_ in l1lll1l_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ〤")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭〥")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ〦"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ〧"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ〨"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ〩"),l1l111_l1_ (u"ࠪ࠯〪ࠬ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾〫ࠩ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ〬"))
	return
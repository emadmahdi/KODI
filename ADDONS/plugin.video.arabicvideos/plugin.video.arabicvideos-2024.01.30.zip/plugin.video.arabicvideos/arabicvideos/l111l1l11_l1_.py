# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᓪ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ᓫ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪᓬ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==550: l1lll_l1_ = l1l1l11_l1_()
	elif mode==551: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==552: l1lll_l1_ = PLAY(url)
	elif mode==553: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==559: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᓭ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᓮ"),l1l111_l1_ (u"ࠫࠬᓯ"),l1l111_l1_ (u"ࠬ࠭ᓰ"),l1l111_l1_ (u"࠭ࠧᓱ"),l1l111_l1_ (u"ࠧࠨᓲ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᓳ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᓴ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓵ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᓶ"),l1l111_l1_ (u"ࠬ࠭ᓷ"),559,l1l111_l1_ (u"࠭ࠧᓸ"),l1l111_l1_ (u"ࠧࠨᓹ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᓺ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᓻ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓼ"),l1l111_l1_ (u"ࠫࠬᓽ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓾ"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬิ๊ฬࠦไไࠩᓿ"),l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭ᔀ"),551,l1l111_l1_ (u"ࠨࠩᔁ"),l1l111_l1_ (u"ࠩࠪᔂ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᔃ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᔄ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᔅ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲࡅࡩࡵࡧࡰࡁࠬᔆ")+l111l1l1l_l1_+l1l111_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨᔇ")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔈ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔉ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡳࡧࡶ࠮࡯ࡤ࡭ࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢࡸࡁࠫᔊ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᔋ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧᔌ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"࠭ๅิๆึ่ࠥ࠭ᔍ") in title: continue
		if l1l111_l1_ (u"ࠧฤฯาฯࠬᔎ") in title: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔏ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔐ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔑ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᔒ"),l1l111_l1_ (u"ࠬ࠭ᔓ"),9999)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨᔔ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧᔕ") in title: continue
		if l1l111_l1_ (u"ࠨละำะ࠭ᔖ") not in title: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔗ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᔘ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬᔙ")):
	items = []
	if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬᔚ") in url or l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧᔛ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᔜ"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨᔝ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧᔞ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫᔟ"),l1l111_l1_ (u"ࠫࠬᔠ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᔡ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᔢ"),url,l1l111_l1_ (u"ࠧࠨᔣ"),l1l111_l1_ (u"ࠨࠩᔤ"),l1l111_l1_ (u"ࠩࠪᔥ"),l1l111_l1_ (u"ࠪࠫᔦ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᔧ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᔨ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᔩ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᔪ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠨᔫ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᔬ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨᔭ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡳࡷ࡯ࡧࡪࡰࡤࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᔮ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔯ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ᔰ"),l1l111_l1_ (u"ࠧโ์็้ࠬᔱ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧᔲ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧᔳ"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩᔴ"),l1l111_l1_ (u"ࠫ์ีวโࠩᔵ"),l1l111_l1_ (u"๋ࠬศศำสอࠬᔶ"),l1l111_l1_ (u"ู࠭าุࠪᔷ"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧᔸ"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧᔹ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫᔺ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᔻ"),title,re.DOTALL)
		if l1l111_l1_ (u"ุ๊ࠫวิๆࠪᔼ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᔽ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭ᔾ") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᔿ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕀ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫᕁ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕂ"),l1lllll_l1_+title,l1ll1ll_l1_,551,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᕃ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࠭ᕄ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࠪᕅ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᕆ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠣࠤᕇ"): continue
				if title!=l1l111_l1_ (u"ࠩࠪᕈ"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕉ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪᕊ")+title,l1ll1ll_l1_,551)
	if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬᕋ") in url or l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧᕌ") in url:
		if l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧᕍ") in url:
			url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨᕎ"),l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪᕏ"))+l1l111_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁ࠷࠶ࠧᕐ")
		elif l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᕑ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧᕒ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨᕓ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕔ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ้้ห่ࠦวๅ็ี๎ิ࠭ᕕ"),url,551)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᕖ"),url,l1l111_l1_ (u"ࠪࠫᕗ"),l1l111_l1_ (u"ࠫࠬᕘ"),l1l111_l1_ (u"ࠬ࠭ᕙ"),l1l111_l1_ (u"࠭ࠧᕚ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᕛ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸࡈࡹࡔࡧࡵ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩᕜ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡰ࡮ࡹࡴ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᕝ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᕞ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᕟ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕠ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡪ࡯ࡤ࡫ࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕡ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᕢ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᕣ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫᕤ"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫᕥ"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨᕦ"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨᕧ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᕨ"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨᕩ"),l1l111_l1_ (u"ࠨࠩᕪ"),l1l111_l1_ (u"ࠩࠪᕫ"),l1l111_l1_ (u"ࠪࠫᕬ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᕭ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩᕮ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᕯ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᕰ"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣᕱ"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬᕲ"),l1l111_l1_ (u"ࠪࠫᕳ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᕴ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨᕵ")+server+l1l111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡎࡊ࠽ࠨᕶ")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨᕷ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᕸ")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᕹ")
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠥ࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡈࡹࡏࡣࡰࡩࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡠࠧࡹࡥࡳࡸࡨࡶࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥᕺ"),block,re.DOTALL)
			for server,l111l11ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧᕻ"),l1l111_l1_ (u"ࠬ࠭ᕼ")).strip(l1l111_l1_ (u"࠭ࠠࠨᕽ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡓࡰࡦࡿࡥࡳࡄࡼࡒࡦࡳࡥࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩᕾ")+server+l1l111_l1_ (u"ࠨࠨࡰࡹࡱࡺࡩࡱ࡮ࡨࡗࡪࡸࡶࡦࡴࡶࡁࠬᕿ")+l111l11ll_l1_+l1l111_l1_ (u"ࠩࠩࡴࡴࡹࡴࡊࡆࡀࠫᖀ")+l11l1l11_l1_+l1l111_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫᖁ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᖂ")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᖃ")
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡱࡺࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᖄ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖅ"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᖆ")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᖇ")
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᖈ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᖉ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖊ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧᖋ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨᖌ"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪᖍ"),l1l111_l1_ (u"ࠩ࠰ࠫᖎ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬᖏ")+search+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪᖐ")
	l1lll11_l1_(url)
	return
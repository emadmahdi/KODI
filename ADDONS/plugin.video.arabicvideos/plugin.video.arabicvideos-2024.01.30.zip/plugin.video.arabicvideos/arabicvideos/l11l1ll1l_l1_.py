# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩᆊ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡈࡋࡓࡡࠪᆋ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᆌ"):l1l111_l1_ (u"࠭ࠧᆍ")}
l11lll_l1_ = [l1l111_l1_ (u"ࠧศใ็ห๊ࠦไๅๅหหึ࠭ᆎ"),l1l111_l1_ (u"ࠨสๆีฬࠦࡔࡗࠩᆏ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==370: l1lll_l1_ = l1l1l11_l1_()
	elif mode==371: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==372: l1lll_l1_ = PLAY(url)
	elif mode==374: l1lll_l1_ = l11l1ll11_l1_(url)
	elif mode==375: l1lll_l1_ = l11l1l111_l1_(url)
	elif mode==376: l1lll_l1_ = l11l1l11l_l1_(0,url)
	elif mode==377: l1lll_l1_ = l11l1l11l_l1_(1,url)
	elif mode==379: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᆐ"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫᆑ"),l1l111_l1_ (u"ࠫࠬᆒ"),l1l111_l1_ (u"ࠬ࠭ᆓ"),l1l111_l1_ (u"࠭ࠧᆔ"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᆕ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆖ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᆗ"),l1l111_l1_ (u"ࠪࠫᆘ"),379,l1l111_l1_ (u"ࠫࠬᆙ"),l1l111_l1_ (u"ࠬ࠭ᆚ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᆛ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᆜ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᆝ"),l1l111_l1_ (u"ࠩࠪᆞ"),9999)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵ࠯ࡶ࡭ࡩ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᆟ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᆠ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆡ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆢ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆣ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᆤ")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪᆥ"),l111l1_l1_,375)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆦ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᆧ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤฯาฯࠬᆨ"),l111l1_l1_,376)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆩ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆪ")+l1lllll_l1_+l1l111_l1_ (u"ࠨไสส๊ฯࠠศๆ่้ะ๊๊็ࠩᆫ"),l111l1_l1_,374)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᆬ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᆭ"),l1l111_l1_ (u"ࠫࠬᆮ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡴࡰࡲ࠰ࡱࡪࡴࡵࠨᆯ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᆰ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items[7:]:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩᆱ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆲ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᆳ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
		for l1ll1ll_l1_,title in items[0:7]:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᆴ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆵ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᆶ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1ll11_l1_(l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧᆷ")):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᆸ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩᆹ"),l1l111_l1_ (u"ࠩࠪᆺ"),l1l111_l1_ (u"ࠪࠫᆻ"),l1l111_l1_ (u"ࠫࠬᆼ"),l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡆࡉࡔࡐࡔࡖࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᆽ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠣࡧࡦࡺࠠࡕࡣࡪࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᆾ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᆿ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᇀ") in l1ll1ll_l1_: continue
			else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇁ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᇂ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1l111_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬᇃ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᇄ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᇅ"),l1l111_l1_ (u"ࠧࠨᇆ"),l1l111_l1_ (u"ࠨࠩᇇ"),l1l111_l1_ (u"ࠩࠪᇈ"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡉࡉࡆ࡚ࡕࡓࡇࡇ࠱࠶ࡹࡴࠨᇉ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡓࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠷࠭ᇊ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡶࡪࡦࡳࡥ࡬࡫࡟࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪᇋ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"࠭࠺࠰࠱ࠪᇌ"),l1l111_l1_ (u"ࠧ࠻࠱࠲࠳ࠬᇍ")).replace(l1l111_l1_ (u"ࠨ࠱࠲ࠫᇎ"),l1l111_l1_ (u"ࠩ࠲ࠫᇏ")).replace(l1l111_l1_ (u"ࠪࠤࠬᇐ"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨᇑ"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᇒ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᇓ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l11l1l11l_l1_(id,l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨᇔ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᇕ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪᇖ"),l1l111_l1_ (u"ࠪࠫᇗ"),l1l111_l1_ (u"ࠫࠬᇘ"),l1l111_l1_ (u"ࠬ࠭ᇙ"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡝ࡁࡕࡅࡋࡍࡓࡍࡎࡐ࡙࠰࠵ࡸࡺࠧᇚ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠶࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡳࡼ࠭ᇛ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[id]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫᇜ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠩ࠽࠳࠴࠭ᇝ"),l1l111_l1_ (u"ࠪ࠾࠴࠵࠯ࠨᇞ")).replace(l1l111_l1_ (u"ࠫ࠴࠵ࠧᇟ"),l1l111_l1_ (u"ࠬ࠵ࠧᇠ")).replace(l1l111_l1_ (u"࠭ࠠࠨᇡ"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫᇢ"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᇣ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᇤ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l1lll11_l1_(url,l1l1l1lll_l1_=l1l111_l1_ (u"ࠪࠫᇥ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᇦ"),url,l1l111_l1_ (u"ࠬ࠭ᇧ"),l1l111_l1_ (u"࠭ࠧᇨ"),l1l111_l1_ (u"ࠧࠨᇩ"),l1l111_l1_ (u"ࠨࠩᇪ"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᇫ"))
	html = response.content
	if l1l111_l1_ (u"ࠪࡺ࡮ࡪࡰࡢࡩࡨࡣࠬᇬ") in url:
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡇ࡬ࡣࡷࡰ࠱࠳࠰࠿ࠪࠤࠪᇭ"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࠦࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡰࡨ࠲࠹ࠧᇮ"),html,re.DOTALL)
	if l1l1l1lll_l1_==l1l111_l1_ (u"࠭ࠧᇯ") and l11llll_l1_ and l11llll_l1_[0].count(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬᇰ"))>1:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇱ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩᇲ"),url,371,l1l111_l1_ (u"ࠪࠫᇳ"),l1l111_l1_ (u"ࠫࠬᇴ"),l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡷࠬᇵ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᇶ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩᇷ")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᇸ"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇹ"),l1lllll_l1_+title,l1ll1ll_l1_,371)
	else:
		l1l1_l1_ = []
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡮ࡦ࠰࠷࠭࠴ࠪࡀࠫࡦࡳࡱ࠳ࡸࡴ࠯࠴࠶ࠬᇺ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡵࡰ࠱࠽ࠨࠨ࠯ࠬࡂ࠭ࡨࡵ࡬࠮ࡺࡶ࠱࠶࠸ࠧᇻ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄࠧᇼ"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨᇽ"))
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠧ࠻࠱࠲ࠫᇾ"),l1l111_l1_ (u"ࠨ࠼࠲࠳࠴࠭ᇿ")).replace(l1l111_l1_ (u"ࠩ࠲࠳ࠬሀ"),l1l111_l1_ (u"ࠪ࠳ࠬሁ")).replace(l1l111_l1_ (u"ࠫࠥ࠭ሂ"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩሃ"))
				if l1l111_l1_ (u"࠭࠯ࡢ࡮ࡢࠫሄ") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧህ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠨษ็ั้่ษࠨሆ") in title and (l1l111_l1_ (u"ࠩ࠲ࡇࡦࡺ࠭ࠨሇ") in url or l1l111_l1_ (u"ࠪ࠳ࡘ࡫ࡡࡳࡥ࡫࠳ࠬለ") in url):
					l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠱ࠥ࠱วๅฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫሉ"),title,re.DOTALL)
					if l1l1lll_l1_: title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪሊ")+l1l1lll_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ላ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ሌ"),l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩል"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬሎ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = l1l111_l1_ (u"ูࠪๆำษࠡࠩሏ")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሐ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1l111_l1_ (u"ࠬ࠭ሑ"),l1l111_l1_ (u"࠭ࠧሒ"),l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࡹࠧሓ"))
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬሔ"),url,l1l111_l1_ (u"ࠩࠪሕ"),l1l111_l1_ (u"ࠪࠫሖ"),l1l111_l1_ (u"ࠫࠬሗ"),l1l111_l1_ (u"ࠬ࠭መ"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧሙ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡭ࡣࡥࡩࡱ࠳ࡳࡶࡥࡦࡩࡸࡹࠠ࡮ࡴࡪ࠱ࡧࡺ࡭࠮࠷ࠣࠦࡃ࠮࠮ࠫࡁࠬࡀࠬሚ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llllll_l1_ = l1l111_l1_ (u"ࠨࠩማ")
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡵࡳ࡮ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሜ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡱࡣࡪࡩࡤ࠭ም"),l1l111_l1_ (u"ࠫ࠴ࡖ࡬ࡢࡻ࠲ࠫሞ"))
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪሟ") not in l1lllll1_l1_: l1lllll1_l1_ = l111l1_l1_+l1lllll1_l1_
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"࠭࠭ࠨሠ"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫሡ"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩሢ"),l1l111_l1_ (u"ࠩࠪሣ"),l1l111_l1_ (u"ࠪࠫሤ"),l1l111_l1_ (u"ࠫࠬሥ"),l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ሦ"))
	l11l1ll1_l1_ = response.content
	l1llllll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫሧ"),l11l1ll1_l1_,re.DOTALL)
	if l1llllll_l1_:
		l1llllll_l1_ = l1llllll_l1_[-1]
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬረ") not in l1llllll_l1_: l1llllll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧሩ")+l1llllll_l1_
		if l1l111_l1_ (u"ࠩ࠲ࡔࡑࡇ࡙࠰ࠩሪ") not in l1lllll1_l1_:
			if l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠰ࡰ࡭ࡳ࠴ࡪࡴࠩራ") in l1llllll_l1_:
				l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡳࡹࡧࡲࡩࡴࡪࡨࡶ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡷ࡫ࡧࡩࡴ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪሬ"),l11l1ll1_l1_,re.DOTALL)
				if l11l1l1l1_l1_:
					l11l11lll_l1_, l11l1l1ll_l1_ = l11l1l1l1_l1_[0]
					l1llllll_l1_ = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩር"))+l1l111_l1_ (u"࠭࠯ࡷ࠴࠲ࠫሮ")+l11l11lll_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡲࡲ࡫࡯ࡧ࠰ࠩሯ")+l11l1l1ll_l1_+l1l111_l1_ (u"ࠨ࠰࡭ࡷࡴࡴࠧሰ")
		import ll_l1_
		ll_l1_.l1l_l1_([l1llllll_l1_],l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨሱ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫሲ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬሳ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧሴ"),l1l111_l1_ (u"࠭ࠫࠨስ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡕࡨࡥࡷࡩࡨ࠰ࠩሶ")+search
	l1lll11_l1_(url)
	return
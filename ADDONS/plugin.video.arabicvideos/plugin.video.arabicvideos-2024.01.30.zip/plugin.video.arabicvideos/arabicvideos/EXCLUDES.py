# -*- coding: utf-8 -*-
from LIBSTWO import *
from PIL import ImageDraw,ImageFont,Image
#import PIL.ImageDraw,PIL.ImageFont,PIL.Image
from arabic_reshaper import ArabicReshaper

script_namee = 'EXCLUDES'

def FIX_ARABIC_KODI_MENU_ITEM(namee,sitee):
	sitee = sitee.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	found_englishh = re.findall('[a-zA-Z]',namee,re.DOTALL)
	if 'بحث IPTV - ' in namee: namee = namee.replace('بحث IPTV - ',rtl+'بحث IPTV - '+rtl)
	elif ' IPTV' in namee and sitee=='IPT': namee = rtl+namee
	elif 'بحث M3U - ' in namee: namee = namee.replace('بحث M3U - ',rtl+'بحث M3U - '+rtl)
	elif ' M3U' in namee and sitee=='M3U': namee = rtl+namee
	elif 'بحث ' in namee and ' - ' in namee: namee = rtl+namee
	elif not found_englishh:
		splitterr = re.findall('^( *?)(.*?)( *?)$',namee)
		left_spacess,middlee,right_spacess = splitterr[0]
		punct_charr = re.findall('^([!-~])',middlee)
		if punct_charr: namee = left_spacess+ltr+middlee+right_spacess
		else: namee = right_spacess+rtl+middlee+left_spacess
	else:
		if 1:
			namee_1 = namee
			namee_2 = bidi.algorithm.get_display(namee,base_dir='L')
			if PY2: namee_1 = namee_1.decode('utf8')
			if PY2: namee_2 = namee_2.decode('utf8')
			wordss_1 = namee_1.split(' ')
			wordss_2 = namee_2.split(' ')
			englishh,arabicc,sentencee,prev_langg = [],[],'',''
			zzzz = zip(wordss_1,wordss_2)
			for wordd_1,wordd_2 in zzzz:
				if wordd_1==wordd_2=='' and prev_langg:
					sentencee += ' '
					continue
				if wordd_1==wordd_2:
					langg = 'EN'
					if prev_langg==langg: sentencee += ' '+wordd_1
					elif wordd_1:
						if sentencee:
							arabicc.append(sentencee)
							englishh.append('')
						sentencee = wordd_1
				else:
					langg = 'AR'
					if prev_langg==langg: sentencee += ' '+wordd_1
					elif wordd_1:
						if sentencee:
							englishh.append(sentencee)
							arabicc.append('')
						sentencee = wordd_1
				prev_langg = langg
			if langg=='EN':
				englishh.append(sentencee)
				arabicc.append('')
			else:
				arabicc.append(sentencee)
				englishh.append('')
			new_namee = ''
			zzzz = zip(englishh,arabicc)
			for engg,arbb in zzzz:
				if engg: new_namee += ' '+engg
				else:
					punct_charr = re.findall('([!-~]) *$',arbb)
					if punct_charr:
						punct_charr = punct_charr[0]
						try:
							puct_char_mirroredd = bidi.mirror.MIRRORED[punct_charr]
							splitterr = re.findall('^( *?)(.*?)( *?)$',arbb)
							if splitterr: left_spacess,arbb,right_spacess = splitterr[0]
							arbb = left_spacess+puct_char_mirroredd+arbb[:-1]+right_spacess
						except: pass
					new_namee += ' '+arbb
			namee = new_namee[1:]
			if PY2: namee = namee.encode('utf8')
		else:
			if PY2: namee = namee.decode('utf8')
			namee = bidi.algorithm.get_display(namee)
			namee_1,namee_2 = namee,namee
			#"""
			#arabicc = re.findall('[^!-~]',letterr)
			#englishh = re.findall('[a-zA-Z]',letterr)
			#ara_puncc = re.findall('[^a-z^A-Z]',letterr)
			#eng_puncc = re.findall('[!-~]',letterr)
			#arabicc = arabicc[0] if arabicc else ''
			#englishh = englishh[0] if englishh else ''
			#ara_puncc = ara_puncc[0] if ara_puncc else ''
			#eng_puncc = eng_puncc[0] if eng_puncc else ''
			#punctuationn = eng_puncc if eng_puncc and not englishh else ''
			#"""
			if 1:
				prev_langg,sentencess = '',[]
				wordss = namee.split(' ')
				for wordd in wordss:
					if not wordd:
						if sentencess: sentencess[-1] += ' '
						else: sentencess.append('')
						continue
					first_letter_english_or_punctt = re.findall('[!-~]',wordd[0])
					if first_letter_english_or_punctt==prev_langg and sentencess: sentencess[-1] += ' '+wordd
					else:
						if sentencess:
							found_arabicc = re.findall('[^!-~]',sentencess[-1])
							if found_arabicc:
								sentencess[-1] = bidi.algorithm.get_display(sentencess[-1])
								spacess = re.findall('^ +',sentencess[-1])
								if spacess: sentencess[-1] = sentencess[-1].lstrip(' ')+spacess[0]
						sentencess.append(wordd)
					prev_langg = first_letter_english_or_punctt
				if sentencess: sentencess[-1] = bidi.algorithm.get_display(sentencess[-1])
				namee = ' '.join(sentencess)
			if PY2: namee = namee.encode('utf8')
	return namee

def GET_LIST_ITEM(menuItemm,MENUS__LAST_VIDEOS_MENUu,FAVORITES_FILE_DICTt):
	typee,namee,urll,modee,imagee,textt1,textt2,contextt,infodictt = menuItemm
	modee = int(modee)
	datetimee = re.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',namee,re.DOTALL)
	if datetimee:
		datetimee,datee,timee = datetimee[0]
		namee = namee.replace(datetimee,'')
	name_for_pathh = namee
	sitee = re.findall('^_(\w\w\w)_(.*?)$',namee,re.DOTALL)
	if sitee:
		sitee,namee = sitee[0]
		modifiedd = '_MOD_' in namee
		folderr = typee=='folder'
		if modifiedd and folderr: startt = ';'
		elif modifiedd and not folderr: startt = half_triangular_colon
		elif not modifiedd and folderr: startt = ','
		elif not modifiedd and not folderr: startt = ' '
		namee = namee.replace('_MOD_','')
		sitee = startt+'[COLOR FFC89008]'+sitee+' [/COLOR]'
	else: sitee = ''
	if datetimee:
		if PY2:
			datetimee = '[COLOR FFFFFF00]'+datee+' '+timee+'[/COLOR]'
			if sitee: namee = datetimee+' '+rtl+sitee+namee    #  datetimee+' '+sitee+rtl+namee
			else: namee = datetimee+rtl+namee+' '
		elif PY3:
			if sitee:
				datetimee = '[COLOR FFFFFF00]'+datee+' '+timee+'[/COLOR]'
				namee = datetimee+' '+sitee+namee
			else:
				datetimee = '[COLOR FFFFFF00]'+timee+' '+datee+'[/COLOR]'
				namee = namee+' '+rtl+datetimee
	elif sitee:
		namee = FIX_ARABIC_KODI_MENU_ITEM(namee,sitee)
		namee = sitee+namee
	menuItemm = typee,name_for_pathh,urll,str(modee),imagee,textt1,textt2,contextt,infodictt
	newpath_dictt = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	newpath_dictt['name'] = QUOTE(name_for_pathh)
	newpath_dictt['type'] = typee.strip(' ')
	newpath_dictt['mode'] = str(modee).strip(' ')
	if typee=='folder' and textt1: newpath_dictt['page'] = QUOTE(textt1.strip(' '))
	if contextt: newpath_dictt['context'] = contextt.strip(' ')
	if textt2: newpath_dictt['text'] = QUOTE(textt2.strip(' '))
	if imagee: newpath_dictt['image'] = QUOTE(imagee.strip(' '))
	if infodictt:
		infodictt = str(infodictt)
		newpath_dictt['infodict'] = QUOTE(infodictt.strip(' '))
		infodictt = eval(infodictt)
	else: infodictt = {}
	if urll: newpath_dictt['url'] = QUOTE(urll.strip(' '))
	list_itemm = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	context_menuu = []
	newpathh = 'plugin://'+addon_id+'/?type='+newpath_dictt['type']+'&mode='+newpath_dictt['mode']
	if newpath_dictt['page']: newpathh += '&page='+newpath_dictt['page']
	if newpath_dictt['name']: newpathh += '&name='+newpath_dictt['name']
	if newpath_dictt['text']: newpathh += '&text='+newpath_dictt['text']
	if newpath_dictt['infodict']: newpathh += '&infodict='+newpath_dictt['infodict']
	if newpath_dictt['image']: newpathh += '&image='+newpath_dictt['image']
	if newpath_dictt['url']: newpathh += '&url='+newpath_dictt['url']
	if modee!=265: list_itemm['favorites'] = True
	else: list_itemm['favorites'] = False
	if newpath_dictt['context']: newpathh += '&context='+newpath_dictt['context']
	if modee in [235,238] and typee=='live' and 'EPG' in contextt:
		run_pathh = 'plugin://'+addon_id+'?mode=238&text=SHORT_EPG&url='+urll
		run_textt = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if modee==265:
		lengthh = MENUS__LAST_VIDEOS_MENUu(textt2,True)
		if lengthh>0:
			run_pathh = 'plugin://'+addon_id+'?mode=266&text='+textt2
			run_textt = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+TRANSLATE(textt2)+'[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	if typee=='video' and modee!=331:
		run_pathh = newpathh+'&context=6_DOWNLOAD'
		run_textt = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if modee==331:
		run_pathh = newpathh+'&context=6_DELETE'
		run_textt = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if typee=='folder' and modee==540:
		all_wordss = READ_FROM_sSQL3(main_dbfile,'list','GLOBALSEARCH_SITES')
		if all_wordss:
			run_pathh = 'plugin://'+addon_id+'?context=7'
			run_textt = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	MAIN_MENU_MODESs = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if modee not in MAIN_MENU_MODESs:
		run_pathh = 'plugin://'+addon_id+'?context=8&mode=260'
		run_textt = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	NON_SITES_MENUSs = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if modee%10 and modee!=9990:
		site_modee = modee-modee%10
		if site_modee==280: site_modee = 230
		if site_modee==410: site_modee = 400
		if site_modee==520: site_modee = 510
		if site_modee not in NON_SITES_MENUSs:
			run_pathh = 'plugin://'+addon_id+'?context=8&mode='+str(site_modee)
			run_textt = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	run_pathh = newpathh+'&context=9'
	run_textt = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
	context_menuu.append(run_itemm)
	if typee in ['link','video','live']: isFolderr = False
	elif typee=='folder': isFolderr = True
	list_itemm['name'] = namee
	list_itemm['context_menu'] = context_menuu
	if 'plot' in list(infodictt.keys()): list_itemm['plot'] = infodictt['plot']
	if 'stars' in list(infodictt.keys()): list_itemm['stars'] = infodictt['stars']
	if imagee: list_itemm['image'] = imagee
	if typee=='video' and textt1:
		durationn = re.findall('[\d:]+',textt1,re.DOTALL)
		if durationn:
			durationn = '0:0:0:0:0:'+durationn[0]
			dummyy,dayss,hourss,minutess,secondss = durationn.rsplit(':',4)
			durationn2 = int(dayss)*24*HOURr+int(hourss)*HOURr+int(minutess)*60+int(secondss)
			list_itemm['duration'] = durationn2
	list_itemm['type'] = typee
	list_itemm['isFolder'] = isFolderr
	list_itemm['newpath'] = newpathh
	list_itemm['menuItem'] = menuItemm
	list_itemm['mode'] = modee
	return list_itemm

def GET_ALL_LIST_ITEMS(MENUS__LAST_VIDEOS_MENUu):
	DirectoryItems_Listt = []
	from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
	FAVORITES_FILE_DICTt = GET_ALL_FAVORITES()
	for menuItemm in menuItemsLIST:
		list_itemm = GET_LIST_ITEM(menuItemm,MENUS__LAST_VIDEOS_MENUu,FAVORITES_FILE_DICTt)
		if list_itemm['favorites']:
			fav_context_menuu = GET_FAVORITES_CONTEXT_MENU(FAVORITES_FILE_DICTt,list_itemm['menuItem'],list_itemm['newpath'])
			list_itemm['context_menu'] = fav_context_menuu+list_itemm['context_menu']
		DirectoryItems_Listt.append(list_itemm)
	return DirectoryItems_Listt

#"""
## freetranslations.org
## good but not always correct
#trans_codee = settings.getSetting('av.language.code')
#for iiii in range(len(namess)):
#	new_namess = ':::'.join(namess[iiii])
#	new_namess = new_namess.replace('ˑ','').replace(',','')
#	urll = 'https://t7.freetranslations.org/freetranslationsorg.php?p1='+src_langg+'&p2='+trans_codee+'&p3='+QUOTE(new_namess,'')
#	responsee = OPENURLl_REQUESTS_CACHED(VERYLONG_CACHEe,'GET',urll,'','','','','LIBRARY-CREATE_KODI_MENU-1st')
#	htmll = responsee.content
#	htmll = htmll.replace('] /','[/')
#	htmll = re.sub('\[ */ *C *O *L *O *R','[/COLOR',htmll)
#	htmll = re.sub('\[ *C *O *L *O *R','[COLOR',htmll)
#	htmll = re.sub(' *: *: *: *',':::',htmll)
#	htmll = htmll.replace('COLORE','COLOR')
#	translationn += htmll.split(':::')
##LOGg_THIS('',str(translationn))
#"""
#"""
## microsoft using paralink
## textt is not complete
#for iiii in range(len(namess)):
#	new_namess = ':::'.join(namess[iiii])
#	#new_namess = new_namess.replace('ˑ','').replace(',','')
#	headerss = {'Content-Type':'application/x-www-form-urlencoded'}
#	urll = 'https://translation2.paralink.com/do.asp'
#	#new_namess = new_namess.replace(' ','+')
#	dataa = 'src='+QUOTE(new_namess,'')+'+&dir=ar/en&provider=microsoft'
#	responsee = OPENURLl_REQUESTS_CACHED(VERYLONG_CACHEe,'GET',urll,dataa,headerss,'','','LIBRARY-CREATE_KODI_MENU-1st')
#	htmll = responsee.content
#	#htmll = htmll.replace('] /','[/')
#	#htmll = re.sub('\[ */ *C *O *L *O *R','[/COLOR',htmll)
#	#htmll = re.sub('\[ *C *O *L *O *R','[COLOR',htmll)
#	htmll = re.sub(' *: *: *: *',':::',htmll)
#	htmll = htmll.replace('\\','')
#	if modee==260: htmll = htmll.replace('Language_','اللغة_')
#	textt = re.findall('value="(.*?)"',htmll,re.DOTALL)
#	translationn += textt[0].split(':::')
#"""

# from https://translate.glosbe.com
def GLOSBE_TRANSLATE(liness):
	startt,resultt, = [],''
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\n\n\n\n'.join(liness)
	textt = textt.replace('===== ===== =====','000001')
	textt = textt.replace('[COLOR FFC89008]','000002')
	textt = textt.replace('[COLOR FFFFFF00]','000003')
	textt = textt.replace('[/COLOR]','000004')
	textt = textt.replace('[RIGHT]','000005')
	seqq = 100000
	linksListt = {}
	linkss = re.findall('http.*?[\r\n ]',textt,re.DOTALL)
	for linkk in linkss:
		seqq += 1
		textt = textt.replace(linkk,str(seqq))
		linksListt[str(seqq)] = linkk
	#"""
	#textt = textt.replace('كلا','no')
	#textt = textt.replace('استمرار','continue')
	#textt = textt.replace('[CENTER]','000006')
	#textt = textt.replace('[RTL]','000007')
	#textt = textt.replace("'","\\\\\\'")
	#textt = textt.replace('"','\\\\\\"')
	#textt = textt.replace('\n','\\n')
	#textt = textt.replace('\r','\\\\r')
	#"""
	for iiii in range(0,len(textt),4800):
		splitt = textt[iiii:iiii+4800]
		trans_codee = settings.getSetting('av.language.code')
		urll = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+trans_codee
		headerss = {'Content-Type':'text/plain'}
		dataa = splitt.encode('utf8')
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			###htmll = htmll.decode('utf8')
			#htmll = htmll.split('\n')[-1]
			new_namess = EVALl('str',htmll)
			if new_namess:
				new_namess = new_namess['translation']
				new_namess = escapeUNICODE(new_namess)
				for jjjj in range(len(new_namess)):
					resultt += new_namess[jjjj][0]
	resultt = resultt.replace('000001','===== ===== =====')
	resultt = resultt.replace('000002','[COLOR FFC89008]')
	resultt = resultt.replace('000003','[COLOR FFFFFF00]')
	resultt = resultt.replace('000004','[/COLOR]')
	resultt = resultt.replace('000005','[RIGHT]')
	for seqq in list(linksListt.keys()):
		linkk = linksListt[seqq]
		resultt = resultt.replace(seqq,linkk)
	#"""
	#resultt = resultt.replace('00000','0000').replace('0000','000')
	#resultt = resultt.replace('0006','[CENTER]')
	#resultt = resultt.replace('0007','[RTL]')
	#resultt = re.sub('\s*n\s*','n',resultt)
	#resultt = resultt.replace('\\n','\n')
	#resultt = resultt.replace('\\r','\r')
	#resultt = resultt.replace('\n\n\n\ ','\n\n\n\n')
	#"""
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

# from http://translate.google.com
# textt is not complete when using ':::' as separator
# it is good when using '\n' as separator
def GOOGLE_TRANSLATE(liness):
	startt,resultt, = [],''
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\\n\\n\\n\\n'.join(liness)
	textt = textt.replace('كلا','no')
	textt = textt.replace('استمرار','continue')
	textt = textt.replace('===== ===== =====','000001')
	textt = textt.replace('[COLOR FFC89008]','000002')
	textt = textt.replace('[COLOR FFFFFF00]','000003')
	textt = textt.replace('[/COLOR]','000004')
	textt = textt.replace('[RIGHT]','000005')
	textt = textt.replace('[CENTER]','000006')
	textt = textt.replace('[RTL]','000007')
	textt = textt.replace("'","\\\\\\'")
	textt = textt.replace('"','\\\\\\"')
	textt = textt.replace('\n','\\n')
	textt = textt.replace('\r','\\\\r')
	for iiii in range(0,len(textt),4800):
		splitt = textt[iiii:iiii+4800]
		#"""
		#urll = 'https://translate.googleapis.com/translate_a/single'
		#headerss = {'Content-Type':'application/x-www-form-urlencoded'}
		#trans_codee = settings.getSetting('av.language.code')
		#dataa = 'client=gtx&sl=ar&tl=en&dt=t&q='+QUOTE(splitt)
		#responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		#if responsee.succeeded:
		#	htmll = responsee.content
		#	#htmll = htmll.decode('utf8')
		#	htmll = htmll.split('\n')[-1]
		#	new_namess = EVALl('str',htmll)[0]
		#"""
		urll = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		headerss = {'Content-Type':'application/x-www-form-urlencoded'}
		trans_codee = settings.getSetting('av.language.code')
		dataa = 'f.req='+QUOTE('[[["MkEWBc","[[\\"'+splitt+'\\",\\"ar\\",\\"'+trans_codee+'\\",1],[]]",null,"generic"]]]','')
		#import json
		#dataa = [[["MkEWBc",'[["'+QUOTE(textt,'')+'","ar","'+trans_codee+'",1],[]]',None,"generic"]]]
		#dataa = 'f.req='+json.dumps(dataa)
		dataa = dataa.replace('%5Cn','%5C%5Cn')
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			#htmll = htmll.decode('utf8')
			htmll = htmll.split('\n')[-1]
			new_namess = EVALl('str',htmll)[0][2]
			if new_namess:
				new_namess = EVALl('str',new_namess)[1][0][0][5]
				new_namess = escapeUNICODE(new_namess)
				for jjjj in range(len(new_namess)):
					resultt += new_namess[jjjj][0]
	resultt = resultt.replace('00000','0000').replace('0000','000')
	resultt = resultt.replace('0001','===== ===== =====')
	resultt = resultt.replace('0002','[COLOR FFC89008]')
	resultt = resultt.replace('0003','[COLOR FFFFFF00]')
	resultt = resultt.replace('0004','[/COLOR]')
	resultt = resultt.replace('0005','[RIGHT]')
	resultt = resultt.replace('0006','[CENTER]')
	resultt = resultt.replace('0007','[RTL]')
	#"""
	#resultt = re.sub('\s*n\s*','n',resultt)
	#resultt = resultt.replace('\\n','\n')
	#resultt = resultt.replace('\\r','\r')
	#resultt = resultt.replace('\n\n\n\ ','\n\n\n\n')
	#"""
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

# from http://reverso.net
# textt is not complete when using ':::' as separator and resultt is textt
# it is good when using '\n' as separator and resultss will be list not textt
def REVERSO_TRANSLATE(liness):
	startt,new_liness = [],[]
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\n\n\n\n'.join(liness)
	textt = textt.replace('كلا','no')
	textt = textt.replace('استمرار','continue')
	textt = textt.replace('أدناه','below')
	textt = textt.replace('[COLOR FFC89008]','00001')
	textt = textt.replace('[COLOR FFFFFF00]','00002')
	textt = textt.replace('[/COLOR]','00003')
	textt = textt.replace('=====','00004')
	textt = textt.replace(',','00005')
	#textt = textt.replace('=====','00006')
	#textt = textt.replace('\n','00007')
	textt = textt.replace('[RTL]','00009')
	textt = textt.replace('[CENTER]','0000A')
	textt = textt.replace('\r','0000B')
	liness = textt.split('\n')
	textt,resultt = '',''
	for linee in liness:
		if len(textt+linee)<1800: textt += '\n'+linee
		else:
			new_liness.append(textt)
			textt = linee
	new_liness.append(textt)
	from json import dumps
	for linee in new_liness:
		headerss = {'Content-Type':'application/json','User-Agent':''}
		urll = 'https://api.reverso.net/translate/v1/translation'
		trans_codee = settings.getSetting('av.language.code')
		dataa = {"format":"text","from":"ara","to":trans_codee,"input":linee,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		dataa = dumps(dataa)
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			#htmll = htmll.replace('\\n','')
			htmll = EVALl('dict',htmll)
			resultt += '\n'+''.join(htmll['translation'])
	resultt = resultt[2:]
	resultt = resultt.replace('000000','00000').replace('00000','0000').replace('0000','000')
	resultt = resultt.replace('0001','[COLOR FFC89008]')
	resultt = resultt.replace('0002','[COLOR FFFFFF00]')
	resultt = resultt.replace('0003','[/COLOR]')
	resultt = resultt.replace('0004','=====')
	resultt = resultt.replace('0005',',')
	#resultt = resultt.replace('0006','=====')
	#resultt = resultt.replace('0007','\n')
	#resultt = resultt.replace('007','\n')
	resultt = resultt.replace('0009','[RTL]')
	resultt = resultt.replace('000A','[CENTER]')
	resultt = resultt.replace('000B','\r')
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

def LANGUAGE_TRANSLATE(liness):
	do_transs = settings.getSetting('av.language.translate')
	if not do_transs or not liness: return liness
	trans_providerr = settings.getSetting('av.language.provider')
	trans_codee = settings.getSetting('av.language.code')
	table_keyy = trans_codee+'__'+str(liness)
	settings.setSetting('av.language.translate','')
	resultt = READ_FROM_sSQL3(main_dbfile,'list','TRANSLATE_'+trans_providerr,table_keyy)
	if not resultt:
		if trans_providerr=='GOOGLE': resultt = GOOGLE_TRANSLATE(liness)
		elif trans_providerr=='REVERSO': resultt = REVERSO_TRANSLATE(liness)
		elif trans_providerr=='GLOSBE': resultt = GLOSBE_TRANSLATE(liness)
		if len(liness)==len(resultt):   #  and liness!=resultt:
			WRITE_TO_sSQL3(main_dbfile,'TRANSLATE_'+trans_providerr,table_keyy,resultt,VERYLONG_CACHEe)
		else:
			resultt = liness
			DIALOGg_NOTIFICATION('الترجمة فشلت','Translation Failed')
	settings.setSetting('av.language.translate','1')
	return resultt

def CREATE_KODI_MENU(menuItemm,DirectoryItems_Listt,succeededd,updateListingg,cacheToDiscc):
	#DirectoryItems_Objectss = READ_FROM_sSQL3(main_dbfile,'list','MENUS_OBJECTS',addon_path)
	#if not DirectoryItems_Objectss:
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = menuItemm
	new_DirectoryItems_Listt = []
	do_transs = settings.getSetting('av.language.translate')
	if do_transs:
		sitess,namess,transs = [],[],[]
		if not new_DirectoryItems_Listt:
			for list_itemm in DirectoryItems_Listt:
				namee = list_itemm['name'].replace(rtl,'').replace(ltr,'')
				datetimee = re.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',namee,re.DOTALL)
				if datetimee:
					startt,datee,timee,endd,namee = datetimee[0]
					datetimee = startt+datee+' '+timee+endd+' '
				else:
					datetimee = re.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',namee,re.DOTALL)
					if datetimee:
						namee,startt,timee,datee,endd = datetimee[0]
						datetimee = startt+datee+' '+timee+endd+' '
					else: datetimee = ''
				sitee = re.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',namee,re.DOTALL)
				if sitee: sitee,namee = sitee[0]
				else: sitee = ''
				sitess.append(datetimee+sitee)
				namess.append(namee)
			transs = LANGUAGE_TRANSLATE(namess)
			if transs:
				for iiii in range(len(DirectoryItems_Listt)):
					list_itemm = DirectoryItems_Listt[iiii]
					list_itemm['name'] = sitess[iiii]+transs[iiii]
					new_DirectoryItems_Listt.append(list_itemm)
	if new_DirectoryItems_Listt: DirectoryItems_Listt = new_DirectoryItems_Listt
	DirectoryItems_Objectss,images_createdd,images_failedd = [],0,0
	images_folderr = os.path.join(addonimagesfolder,modee)
	try: saved_imagess = os.listdir(images_folderr)
	except:
		try: os.makedirs(images_folderr)
		except: pass
		saved_imagess = []
	profile_varss = CREATE_IMAGE_PROFILE('menu_item')
	for list_itemm in DirectoryItems_Listt:
		namee = list_itemm['name']
		context_menuu = list_itemm['context_menu']
		plott = list_itemm['plot']
		starss = list_itemm['stars']
		imagee = list_itemm['image']
		typee = list_itemm['type']
		durationn = list_itemm['duration']
		isFolderr = list_itemm['isFolder']
		newpathh = list_itemm['newpath']
		listitemm = xbmcgui.ListItem(namee)
		listitemm.addContextMenuItems(context_menuu)
		if imagee: listitemm.setArt({'icon':imagee,'thumb':imagee,'fanart':imagee,'banner':imagee,'clearart':imagee,'poster':imagee,'clearlogo':imagee,'landscape':imagee})
		else:
			namee = CLEAN_MENU_LABEL(namee)
			namee = WINDOWS_FILENAME(namee)
			namee2 = namee+'.png'
			default = True
			if namee2 in saved_imagess:
				imagee2 = os.path.join(images_folderr,namee2)
				listitemm.setArt({'icon':imagee2,'thumb':imagee2,'fanart':imagee2,'banner':imagee2,'clearart':imagee2,'poster':imagee2,'clearlogo':imagee2,'landscape':imagee2})			
				default = False
			elif images_createdd<70 and images_failedd<5:
				imagee2 = os.path.join(images_folderr,namee2)
				try:
					image_heightt = CREATE_IMAGE_FILE(profile_varss,'','','','',namee,'menu_item','center',False,imagee2)
					listitemm.setArt({'icon':imagee2,'thumb':imagee2,'fanart':imagee2,'banner':imagee2,'clearart':imagee2,'poster':imagee2,'clearlogo':imagee2,'landscape':imagee2})
					images_createdd += 1
					default = False
				except: images_failedd += 1
			if default: listitemm.setArt({'icon':defaulticon,'thumb':defaultthumb,'fanart':defaultfanart,'banner':defaultbanner,'clearart':defaultclearart,'poster':defaultposter,'clearlogo':defaultclearlogo,'landscape':defaultlandscape})
		if kodi_version<20:
			if plott: listitemm.setInfo('video',{'Plot':plott,'PlotOutline':plott})
			if starss: listitemm.setInfo('video',{'Rating':starss})
			if not imagee:
				# needed for my skin photos menu
				listitemm.setInfo('video',{'Title':namee})
			if typee=='video':
				listitemm.setInfo('video',{'mediatype':'movie'})
				if durationn: listitemm.setInfo('video',{'duration':durationn})
				listitemm.setProperty('IsPlayable','true')
		else:
			videoinfoo = listitemm.getVideoInfoTag()
			#if plott:
			#	videoinfoo.setPlot(plott)
			#	videoinfoo.setPlotOutline(plott)
			if starss: videoinfoo.setRating(float(starss))
			if not imagee:
				# needed for my skin photos menu
				videoinfoo.setTitle(namee)
			if typee=='video':
				videoinfoo.setMediaType('tvshow')
				if durationn: videoinfoo.setDuration(durationn)
				listitemm.setProperty('IsPlayable','true')
		DirectoryItems_Objectss.append((newpathh,listitemm,isFolderr))
	xbmcplugin.setContent(addon_handle,'tvshows')
	addItems_succeededd = xbmcplugin.addDirectoryItems(addon_handle,DirectoryItems_Objectss)
	xbmcplugin.endOfDirectory(addon_handle,succeededd,updateListingg,cacheToDiscc)
	#WRITE_TO_sSQL3(main_dbfile,'MENUS_OBJECTS',[addon_path],DirectoryItems_Objectss,REGULAR_CACHEe)
	return addItems_succeededd

def addMenuItem(typee,namee,urll,modee,imagee='',pagee='',textt='',contextt='',infodictt={}):
	namee = namee.replace('\r','').replace('\n','').replace('\t','')
	urll = urll.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in namee: script_namee,namee = namee.split('_SCRIPT_',1)
	else: script_namee,namee = '',namee
	if script_namee:
		nameonlyy = namee
		if not nameonlyy: nameonlyy = '....'
		elif nameonlyy.count('_')>1: nameonlyy = nameonlyy.split('_',2)[2]
		nameonlyy = nameonlyy.replace(' ','')
		nameonlyy = nameonlyy.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		nameonlyy = nameonlyy.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		nameonlyy = nameonlyy.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		nameonlyy = nameonlyy.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		nameonlyy = nameonlyy.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		nameonlyy = nameonlyy.replace('|','').replace('~','')
		nameonlyy = nameonlyy.replace('اون لاين','').replace('سيما لايت','')
		exceptionsLISTt = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(valuee in nameonlyy for valuee in exceptionsLISTt): nameonlyy = nameonlyy.replace('ال','')
		nameonlyy = nameonlyy.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		nameonlyy = nameonlyy.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		nameonlyy = nameonlyy.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		nameonlyy = nameonlyy.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		nameonlyy = nameonlyy.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		nameonlyy = nameonlyy.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		nameonlyy = nameonlyy.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		nameonlyy = nameonlyy.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		nameonlyy = nameonlyy.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		nameonlyy = nameonlyy.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		nameonlyy = nameonlyy.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		nameonlyy = nameonlyy.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		nameonlyy = nameonlyy.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		nameonlyy = nameonlyy.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		nameonlyy = nameonlyy.replace('  ',' ').strip(' ')
		script_namee = '_LST_'+TRANSLATE(script_namee)
		if nameonlyy not in list(contentsDICT.keys()): contentsDICT[nameonlyy] = {}
		contentsDICT[nameonlyy][script_namee] = [typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt]
	menuItemsLIST.append([typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt])
	return

def unescapeHTML(stringg):
	if PY3: from html import unescape as _unescapeHTML
	else:
		from HTMLParser import HTMLParser
		_unescapeHTML = HTMLParser().unescape
	if '&' in stringg and ';' in stringg:
		if PY2: stringg = stringg.decode('utf8')
		stringg = _unescapeHTML(stringg)
		if PY2: stringg = stringg.encode('utf8')
	return stringg

def escapeUNICODE(stringg):
	#decode('raw_unicode_escape')
	if '\\u' in stringg:
		if PY2: stringg = stringg.decode('unicode_escape','ignore').encode('utf8')
		elif PY3: stringg = stringg.encode('utf8').decode('unicode_escape','ignore')
	return stringg

def CREATE_IMAGE(buttonn0,buttonn1,buttonn2,headerr,textt,profilee,text_directionn,enable_progressbarr,image_fullpathh):
	varss = CREATE_IMAGE_PROFILE(profilee)
	image_heightt = CREATE_IMAGE_FILE(varss,buttonn0,buttonn1,buttonn2,headerr,textt,profilee,text_directionn,enable_progressbarr,image_fullpathh)
	return image_heightt

def CREATE_IMAGE_PROFILE(profilee):
	header_posxx = 5
	header_upper_marginn = 20
	header_sides_marginn = 20
	header_lines_spacingg = 0
	header_directionn = 'center'
	text_posxx = 0
	text_upper_marginn = 19
	text_sides_marginn = 30
	text_lines_spacingg = 8
	text_wrapp = True
	progressbar_posyy = 375
	buttons_posyy = 410
	buttons_heightt = 50
	buttons_widthh = 280
	buttons_text_posxx = 28
	buttons_spacingg = 5
	bottom_upper_marginn = 0
	bottom_lower_marginn = 31
	font_sizee = [36,32,28]
	if profilee in ['notification','notification_twohalfs']:
		if profilee=='notification_twohalfs':
			dialog_heightt,image_widthh = 'UPPER',720
			header_directionn = 'right'
			text_wrapp = True
			header_lines_spacingg = 10
		else:
			dialog_heightt,image_widthh = 97+20,720
			header_directionn = 'left'
			text_wrapp = False
		font_sizee = [33,33,33]
		header_sides_marginn = 20
		header_upper_marginn = 0
		text_sides_marginn = 20
		text_upper_marginn = 25+10
	elif profilee=='menu_item':
		font_sizee,dialog_heightt,image_widthh = [48,44,40],200,400
		text_sides_marginn,text_upper_marginn,header_upper_marginn = 0,0,-16
		backgroundd = Image.open(defaultmenu)
		maskk = Image.new('RGBA',(200,200),(255,0,0,255))
	elif profilee=='confirm_smallfont': font_sizee,dialog_heightt,image_widthh = [28,24,20],500,900
	elif profilee=='confirm_mediumfont': font_sizee,dialog_heightt,image_widthh = [32,28,24],500,900
	elif profilee=='confirm_bigfont': font_sizee,dialog_heightt,image_widthh = [36,32,28],500,900
	elif profilee=='textview_bigfont': dialog_heightt,image_widthh = 740,1270
	elif profilee=='textview_bigfont_long': dialog_heightt,image_widthh = 'UPPER',1270
	elif profilee=='textview_smallfont': font_sizee,dialog_heightt,image_widthh = [28,23,18],740,1270
	elif profilee=='textview_smallfont_long': font_sizee,dialog_heightt,image_widthh = [28,23,18],'UPPER',1270
	header_fontsizee = font_sizee[0]
	text_fontsizee = font_sizee[1]
	buttons_fontsizee = font_sizee[2]
	header_fontt = ImageFont.truetype(fontfile,size=header_fontsizee)
	text_fontt = ImageFont.truetype(fontfile,size=text_fontsizee)
	buttons_fontt = ImageFont.truetype(fontfile,size=buttons_fontsizee)
	txtt = Image.new('RGBA',(100,100),(255,255,255,0))
	writingg = ImageDraw.Draw(txtt)
	text_line_widthh,text_line_heightt = writingg.textsize('HHH BBB 888 000',font=text_fontt)
	header_line_widthh,header_line_heightt = writingg.textsize('HHH BBB 888 000',font=header_fontt)
	arabic_configg = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	reshaperr = ArabicReshaper(configuration=arabic_configg)
	varss = {}
	varss2 = locals()
	for key in varss2: varss[key] = varss2[key]
	return varss

def CREATE_IMAGE_FILE(varss,buttonn0,buttonn1,buttonn2,headerr,textt,profilee,text_directionn,enable_progressbarr,image_fullpathh):
	for key in varss: globals()[key] = varss[key]
	global buttons_text_posxx,buttons_spacingg
	do_transs = settings.getSetting('av.language.translate')
	if do_transs:
		if buttonn0=='نعم  Yes': buttonn0 = 'Yes'
		elif buttonn0=='كلا  No': buttonn0 = 'No'
		if buttonn1=='نعم  Yes': buttonn1 = 'Yes'
		elif buttonn1=='كلا  No': buttonn1 = 'No'
		if buttonn2=='نعم  Yes': buttonn2 = 'Yes'
		elif buttonn2=='كلا  No': buttonn2 = 'No'
		resultss = LANGUAGE_TRANSLATE([buttonn0,buttonn1,buttonn2,headerr,textt])
		if resultss: buttonn0,buttonn1,buttonn2,headerr,textt = resultss
	if PY2:
		textt = textt.decode('utf8')
		headerr = headerr.decode('utf8')
		buttonn0 = buttonn0.decode('utf8')
		buttonn1 = buttonn1.decode('utf8')
		buttonn2 = buttonn2.decode('utf8')
	header_lines_countt = headerr.count('\n')+1
	header_total_heightt = header_upper_marginn+header_lines_countt*(header_line_heightt+header_lines_spacingg)-header_lines_spacingg
	if textt:
		text_max_widthh = image_widthh-text_sides_marginn*2
		text_line_height_with_spacingg = text_line_heightt+text_lines_spacingg
		textreshapedd = reshaperr.reshape(textt)
		if text_wrapp:
			text_with_tagss = WRAP_THIS_TEXT(textreshapedd,text_fontsizee,text_max_widthh,text_line_height_with_spacingg)
			text_with_notagss = REMOVE_TAGS(text_with_tagss)
			text_lines_countt = text_with_notagss.count('\n')+1
			if text_lines_countt<6:
				#new_text_max_widthh = int(0.8*text_max_widthh) if text_lines_countt<4 else int(0.9*text_max_widthh)
				new_text_max_widthh = text_max_widthh
				text_with_tagss = WRAP_THIS_TEXT(textreshapedd,text_fontsizee,new_text_max_widthh,text_line_height_with_spacingg)
				text_with_notagss = REMOVE_TAGS(text_with_tagss)
				text_lines_countt = text_with_notagss.count('\n')+1
			text_total_heightt = text_upper_marginn+text_lines_countt*text_line_height_with_spacingg-text_lines_spacingg
		else:
			text_total_heightt = text_upper_marginn+text_line_heightt
			text_with_notagss = textreshapedd.split('\n')[0]
			text_with_tagss = textreshapedd.split('\n')[0]
	else: text_total_heightt = text_upper_marginn
	bottom_total_heightt = bottom_upper_marginn+bottom_lower_marginn
	if enable_progressbarr:
		progressbar_with_spacing_heightt = buttons_posyy-progressbar_posyy
		bottom_total_heightt += progressbar_with_spacing_heightt
	else: progressbar_with_spacing_heightt = 0
	if buttonn0 or buttonn1 or buttonn2: bottom_total_heightt += buttons_heightt
	if dialog_heightt!='UPPER': image_heightt = dialog_heightt
	else: image_heightt = header_total_heightt+text_total_heightt+bottom_total_heightt
	text_available_heightt = image_heightt-header_total_heightt-bottom_total_heightt-text_upper_marginn
	txtt = Image.new('RGBA',(image_widthh,image_heightt),(255,255,255,0))
	writingg = ImageDraw.Draw(txtt)
	if not buttonn1 and buttonn0 and buttonn2:
		buttons_text_posxx += 105
		buttons_spacingg -= 110
	if headerr:
		header_posyy = header_upper_marginn
		headerr = bidi.algorithm.get_display(reshaperr.reshape(headerr))
		liness = headerr.splitlines()
		for linee in liness:
			if linee:
				widthh,heightt = writingg.textsize(linee,font=header_fontt)
				if header_directionn=='center': header_posxx2 = header_posxx+(image_widthh-widthh)/2
				elif header_directionn=='right': header_posxx2 = header_posxx+image_widthh-widthh-header_sides_marginn
				elif header_directionn=='left': header_posxx2 = header_posxx+header_sides_marginn
				writingg.text((header_posxx2,header_posyy),linee,font=header_fontt,fill='yellow')
			header_posyy += header_fontsizee+header_lines_spacingg
	if buttonn0 or buttonn1 or buttonn2:
		buttons_text_posyy = header_total_heightt+text_available_heightt+text_upper_marginn+progressbar_with_spacing_heightt+bottom_upper_marginn
		if buttonn0:
			buttonn0 = bidi.algorithm.get_display(reshaperr.reshape(buttonn0))
			button0_widthh,button0_heightt = writingg.textsize(buttonn0,font=buttons_fontt)
			button0_text_posxx = buttons_text_posxx+0*(buttons_spacingg+buttons_widthh)+(buttons_widthh-button0_widthh)/2
			writingg.text((button0_text_posxx,buttons_text_posyy),buttonn0,font=buttons_fontt,fill='yellow')
		if buttonn1:
			buttonn1 = bidi.algorithm.get_display(reshaperr.reshape(buttonn1))
			button1_widthh,button1_heightt = writingg.textsize(buttonn1,font=buttons_fontt)
			button1_text_posxx = buttons_text_posxx+1*(buttons_spacingg+buttons_widthh)+(buttons_widthh-button1_widthh)/2
			writingg.text((button1_text_posxx,buttons_text_posyy),buttonn1,font=buttons_fontt,fill='yellow')
		if buttonn2:
			buttonn2 = bidi.algorithm.get_display(reshaperr.reshape(buttonn2))
			button2_widthh,button2_heightt = writingg.textsize(buttonn2,font=buttons_fontt)
			button2_text_posxx = buttons_text_posxx+2*(buttons_spacingg+buttons_widthh)+(buttons_widthh-button2_widthh)/2
			writingg.text((button2_text_posxx,buttons_text_posyy),buttonn2,font=buttons_fontt,fill='yellow')
	if textt:
		lines_posxx,lines_widthh = [],[]
		text_with_tagss = FORMAT_IMAGE_TEXT(text_with_tagss)
		splitted_liness = text_with_tagss.split('_sss__newline_')
		for line_and_styless in splitted_liness:
			line_directionn = text_directionn
			if   '_sss__lineleft_' in line_and_styless: line_directionn = 'left'
			elif '_sss__lineright_' in line_and_styless: line_directionn = 'right'
			elif '_sss__linecenter_' in line_and_styless: line_directionn = 'center'
			line_no_styless = line_and_styless
			tagss = re.findall('_sss__.*?_',line_and_styless,re.DOTALL)
			for tagg in tagss: line_no_styless = line_no_styless.replace(tagg,'')
			if line_no_styless=='': widthh,heightt = 0,text_line_height_with_spacingg
			else: widthh,heightt = writingg.textsize(line_no_styless,font=text_fontt)
			if   line_directionn=='left': text_posxx2 = text_posxx+text_sides_marginn
			elif line_directionn=='right': text_posxx2 = text_posxx+text_sides_marginn+text_max_widthh-widthh
			elif line_directionn=='center': text_posxx2 = text_posxx+text_sides_marginn+(text_max_widthh-widthh)/2
			if text_posxx2<text_sides_marginn: text_posxx2 = text_posxx+text_sides_marginn
			lines_posxx.append(text_posxx2)
			lines_widthh.append(widthh)
		text_posxx2 = lines_posxx[0]
		splitted_textt = text_with_tagss.split('_sss_')
		default_colorr = (255,255,255,255)
		colorr3 = default_colorr
		add_to_posxx1,add_to_posyy = 0,0
		text_rtll = False
		line_seqq = 0
		text_posyy = header_total_heightt+text_upper_marginn/2
		if text_total_heightt<(text_available_heightt+text_upper_marginn):
			text_half_heightt = (text_available_heightt+text_upper_marginn-text_total_heightt)/2
			text_posyy = header_total_heightt+text_upper_marginn+text_half_heightt-text_line_heightt/2
		for linee in splitted_textt:
			if not linee or (linee and ord(linee[0])==65279): continue
			stylee1 = linee.split('_newline_',1)
			stylee2 = linee.split('_newcolor',1)
			stylee3 = linee.split('_endcolor_',1)
			stylee4 = linee.split('_linertl_',1)
			stylee5 = linee.split('_lineleft_',1)
			stylee6 = linee.split('_lineright_',1)
			stylee7 = linee.split('_linecenter_',1)
			if len(stylee1)>1:
				line_seqq += 1
				linee = stylee1[1]
				add_to_posxx1 = 0
				text_posxx2 = lines_posxx[line_seqq]
				add_to_posyy += text_line_height_with_spacingg
				text_rtll = False
			elif len(stylee2)>1:
				linee = stylee2[1]
				colorr3 = linee[0:8]
				colorr3 = '#'+colorr3[2:]
				linee = linee[9:]
			elif len(stylee3)>1:
				linee = stylee3[1]
				colorr3 = default_colorr
			elif len(stylee4)>1:
				linee = stylee4[1]
				text_rtll = True
				add_to_posxx1 = lines_widthh[line_seqq]
			elif len(stylee5)>1: linee = stylee5[1]
			elif len(stylee6)>1: linee = stylee6[1]
			elif len(stylee7)>1: linee = stylee7[1]
			if linee:
				text_posyy2 = text_posyy+add_to_posyy
				linee = bidi.algorithm.get_display(linee)
				widthh,heightt = writingg.textsize(linee,font=text_fontt)
				if text_rtll: add_to_posxx1 -= widthh
				text_posxx3 = text_posxx2+add_to_posxx1
				writingg.text((text_posxx3,text_posyy2),linee,font=text_fontt,fill=colorr3)
				if profilee=='menu_item':
					writingg.text((text_posxx3+1,text_posyy2+1),linee,font=text_fontt,fill=colorr3)
				if not text_rtll: add_to_posxx1 += widthh
				if text_posyy2>text_available_heightt+text_line_height_with_spacingg: break
	if profilee=='menu_item':
		#txtt.thumbnail((50,100),Image.LANCZOS)
		#final_imagee = Image.composite(maskk,backgroundd,txtt)
		txtt = txtt.resize((200,200))
		final_imagee = backgroundd.copy()
		final_imagee.paste(maskk,(0,0),mask=txtt)
	else: final_imagee = txtt
	if PY2: image_fullpathh = image_fullpathh.decode('utf8')
	try: final_imagee.save(image_fullpathh)
	except:
		image_folderr = os.path.dirname(image_fullpathh)
		try: os.makedirs(image_folderr)
		except: pass
		final_imagee.save(image_fullpathh)
	#LOG_THIS('',image_fullpathh)
	return image_heightt

def WRAP_THIS_TEXT(oldtextt,fontsizee,max_dialog_widthh,line_heightt):
	newtextt,total_heightt,max_heightt = '',0,15000
	oldtextt = oldtextt.replace('[COLOR ','[COLOR:::')
	textfontt = ImageFont.truetype(fontfile,size=fontsizee)
	max_dialog_widthh -= fontsizee*2
	txtt = Image.new('RGBA',(max_dialog_widthh,99),(255,255,255,0))
	writingg = ImageDraw.Draw(txtt)
	for oldlinee in oldtextt.splitlines():
		total_heightt += line_heightt
		newline_widthh,newlinee = 0,''
		for wordd in oldlinee.split(' '):
			word_notagss = REMOVE_TAGS(' '+wordd)
			word_widthh,word_heightt = writingg.textsize(word_notagss,font=textfontt)
			if newline_widthh+word_widthh<max_dialog_widthh:
				if not newlinee: newlinee += wordd
				else: newlinee += ' '+wordd
				newline_widthh += word_widthh
			else:
				if word_widthh<max_dialog_widthh:
					newlinee += '\n '+wordd
					total_heightt += line_heightt
					newline_widthh = word_widthh
				else:
					while word_widthh>max_dialog_widthh:
						for iiii in range(1,len(' '+wordd),1):
							beforee = ' '+wordd[:iiii]
							afterr = wordd[iiii:]
							before_notagss = REMOVE_TAGS(beforee)
							before_widthh,before_heightt = writingg.textsize(before_notagss,font=textfontt)
							if newline_widthh+before_widthh>max_dialog_widthh:
								after_widthh = word_widthh-before_widthh
								newlinee += beforee+'\n'
								total_heightt += line_heightt
								word_widthh = after_widthh
								if after_widthh>max_dialog_widthh:
									newline_widthh = 0
									wordd = afterr
								else:
									newline_widthh = after_widthh
									newlinee += afterr
								break
				if total_heightt>max_heightt: break
		newtextt += '\n'+newlinee
		if total_heightt>max_heightt: break
	newtextt = newtextt[1:]
	newtextt = newtextt.replace('[COLOR:::','[COLOR ')
	return newtextt

def REMOVE_TAGS(wordd):
	if '[' in wordd and ']' in wordd:
		tagss = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		colorss1 = re.findall('\[COLOR .*?\]',wordd,re.DOTALL)
		colorss2 = re.findall('\[COLOR:::.*?\]',wordd,re.DOTALL)
		all_tagss = tagss+colorss1+colorss2
		for tagg in all_tagss: wordd = wordd.replace(tagg,'')
	return wordd

def FORMAT_IMAGE_TEXT(textt):
	textt = textt.replace('\n','_sss__newline_')
	textt = textt.replace('[RTL]','_sss__linertl_')
	textt = textt.replace('[LEFT]','_sss__lineleft_')
	textt = textt.replace('[RIGHT]','_sss__lineright_')
	textt = textt.replace('[CENTER]','_sss__linecenter_')
	textt = textt.replace('[/COLOR]','_sss__endcolor_')
	colorss = re.findall('\[COLOR (.*?)\]',textt,re.DOTALL)
	for colorr in colorss: textt = textt.replace('[COLOR '+colorr+']','_sss__newcolor'+colorr+'_')
	return textt

def CLEAN_MENU_LABEL(namee=''):
	if not namee: namee = xbmc.getInfoLabel('ListItem.Label')
	namee = namee.replace('[/COLOR]','')
	namee = namee.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	namee = namee.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	tmpp = re.findall('\d\d:\d\d ',namee,re.DOTALL)
	if tmpp: namee = namee.split(tmpp[0],1)[1]
	if not namee: namee = 'Main Menu'
	return namee

def WINDOWS_FILENAME(filenamee):
	filenamee2 = ''.join(iiii for iiii in filenamee if iiii not in '\/":*?<>|'+half_triangular_colon)
	return filenamee2

#=================================================================================
# the below function were added from:
# https://gitlab.com/Rgysoft/iptv-host-e2iplayer/-/blob/master/IPTVPlayer/tsiplayer/host_faselhd.py
# https://github.com/zombiB/zombi-addons/blob/master/plugin.video.matrix/resources/hosters/faselhd.py
# Thanks to the author "Rgysoft"
#=================================================================================

def DECODE_ADILBO_HTML(dataa):
	pagee = dataa
	if 'adilbo_HTML_encoder' in dataa:
		t_scriptt = re.findall('<script.*?;.*?\'(.*?);', dataa, re.S)
		t_intt = re.findall('/g.....(.*?)\)', dataa, re.S)
		if t_scriptt and t_intt:
			scriptt = t_scriptt[0].replace("'",'')
			scriptt = scriptt.replace("+",'')
			scriptt = scriptt.replace("\n",'')
			scc = scriptt.split('.')
			pagee = ''
			for elmm in scc:
				c_elmm = base64.b64decode(elmm+'==').decode("utf-8")
				t_chh = re.findall('\d+', c_elmm, re.S)
				if t_chh:
					nbb = int(t_chh[0])+int(t_intt[0])
					pagee = pagee + chr(nbb)
			if PY3: pagee = pagee.encode('iso-8859-1').decode('utf8')
	return pagee

#"""
## should be in exclude because it contains lots of single/double quotes
#def FIX_JSON_1(jsonStr):
#	# Remove all empty spaces to make things easier bellow
#	jsonStr = jsonStr.replace('" :','":').replace(': "',':"').replace('"\n','"').replace('" ,','",').replace(', "',',"')
#	# First remove the " from where it is supposed to be.
#	jsonStr = re.sub(r'\\"', '"', jsonStr)
#	jsonStr = re.sub(r'{"', '{`', jsonStr)
#	jsonStr = re.sub(r'"}', '`}', jsonStr)
#	jsonStr = re.sub(r'":"', '`:`', jsonStr)
#	jsonStr = re.sub(r'":\[', '`:[', jsonStr)
#	jsonStr = re.sub(r'":\{', '`:{', jsonStr)
#	#jsonStr = re.sub(r'":([0-9]+)', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'":([\+\-\.0-9]+)', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'":([null|true|false])', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'","', '`,`', jsonStr)
#	jsonStr = re.sub(r'",\[', '`,[', jsonStr)
#	jsonStr = re.sub(r'",\{', '`,{', jsonStr)
#	jsonStr = re.sub(r',"', ',`', jsonStr)
#	jsonStr = re.sub(r'\["', '[`', jsonStr)
#	jsonStr = re.sub(r'"\]', '`]', jsonStr)
#	# Backslash all double quotes (")
#	jsonStr = re.sub(r'"','\\"', jsonStr)
#	# Put back all the " where it is supposed to be.
#	jsonStr = re.sub(r'\`','\"', jsonStr)
#	return jsonStr
#
## should be in exclude because it contains lots of single/double quotes
#def FIX_JSON_2(s):
#	import ast
#	import json
#	while True:
#		try:
#			#jsonStr = ast.literal_eval(s)
#			jsonStr = json.loads(s)   # try to parse...
#			break                    # parsing worked -> exit loop
#		except Exception as e:
#			# "Expecting , delimiter: line 34 column 54 (char 1158)"
#			# position of unexpected character after '"'
#			unexp = int(re.findall(r'\(char (\d+)\)', str(e))[0])
#			# position of unescaped '"' before that
#			unesc = s.rfind(r'"', 0, unexp)
#			s = s[:unesc] + r'\"' + s[unesc+1:]
#			# position of correspondig closing '"' (+2 for inserted '\')
#			closg = s.find(r'"', unesc + 2)
#			s = s[:closg] + r'\"' + s[closg+1:]
#	return jsonStr
#"""



# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭嫱")
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嫲"):l1l111_l1_ (u"ࠨࠩ嫳")}
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢ࡛ࡈࡓ࡟ࠨ嫴")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ嫵"),l1l111_l1_ (u"ࠫࡼࡽࡥࠨ嫶")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ嫷")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ嫸")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫹"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ嫺"),l111l1_l1_,569,l1l111_l1_ (u"ࠩࠪ嫻"),l1l111_l1_ (u"ࠪࠫ嫼"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ嫽"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫾"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ嫿"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ嬀"),564)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬁"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ嬂"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ嬃"),565)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嬄"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嬅"),l1l111_l1_ (u"࠭ࠧ嬆"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嬇"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ嬈"),l1l111_l1_ (u"ࠩࠪ嬉"),l1l111_l1_ (u"ࠪࠫ嬊"),l1l111_l1_ (u"ࠫࠬ嬋"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ嬌"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ嬍"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嬎"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠨࠩ嬏"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬐"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嬑")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嬒"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嬓"),l1l111_l1_ (u"࠭ࠧ嬔"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠮࠮ࠫࡁࠬ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠩ嬕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬖"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬗"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嬘")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嬙"),url,l1l111_l1_ (u"ࠬ࠭嬚"),l1l111_l1_ (u"࠭ࠧ嬛"),l1l111_l1_ (u"ࠧࠨ嬜"),l1l111_l1_ (u"ࠨࠩ嬝"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ嬞"))
	html = response.content
	if l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ嬟") in html:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嬠"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭嬡"),url,561,l1l111_l1_ (u"࠭ࠧ嬢"),l1l111_l1_ (u"ࠧࠨ嬣"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ嬤"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ嬥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嬧"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1llll1lll1l_l1_,type=l1l111_l1_ (u"ࠬ࠭嬨")):
	if l1l111_l1_ (u"࠭࠺࠻ࠩ嬩") in l1llll1lll1l_l1_:
		l1llllll_l1_,url = l1llll1lll1l_l1_.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ嬪"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ嬫"))
		url = server+url
	else: url,l1llllll_l1_ = l1llll1lll1l_l1_,l1llll1lll1l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭嬬"),url,l1l111_l1_ (u"ࠪࠫ嬭"),l1l111_l1_ (u"ࠫࠬ嬮"),l1l111_l1_ (u"ࠬ࠭嬯"),l1l111_l1_ (u"࠭ࠧ嬰"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ嬱"))
	html = response.content
	if type==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ嬲"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭嬳"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ嬴"),l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ嬵")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ嬶"),l1l111_l1_ (u"࠭࠯ࠨ嬷")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ嬸"),l1l111_l1_ (u"ࠨࠤࠪ嬹"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡋࡷ࡯ࡤ࠮࠯࡚ࡩࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡒࡪࡩ࡫ࡸ࡚ࡏࠢࠨ嬺"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࡙ࠪࠦ࡮ࡵ࡮ࡤ࠰࠱ࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ嬻"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ嬼"),l1l111_l1_ (u"ࠬ࠭嬽"))
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ嬾") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬿"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠨฯ็ๆฮ࠭孀") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ孁"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ孂") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ孃"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ孄"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ孅"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ孆"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ孇")+count
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ孈"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭孉"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠫࠬ孊"),l1l111_l1_ (u"ࠬ࠭孋"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ孌"))
		elif type==l1l111_l1_ (u"ࠧࠨ孍"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ孎"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ孏"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ูࠪๆำษࠡࠩ子")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ孑"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭孒")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ孓"),url,l1l111_l1_ (u"ࠧࠨ孔"),l1l111_l1_ (u"ࠨࠩ孕"),l1l111_l1_ (u"ࠩࠪ孖"),l1l111_l1_ (u"ࠪࠫ字"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ存"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ孙"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ孚"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孛"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠨࠩ孜"),l1l111_l1_ (u"ࠩࠪ孝"),l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ孞"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡊࡶࡩࡴࡱࡧࡩࡸ࠳࠭ࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷ࡮ࡴࡧ࡭ࡧࡶࡩࡨࡺࡩࡰࡰࡶࡂࠬ孟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭孠"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ孡"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭孢"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ季"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ孤"),l1l111_l1_ (u"ࠪࠫ孥")).replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ学"),l1l111_l1_ (u"ࠬ࠭孧"))
		else: title = l1l111_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ孨")
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭孩"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ孪"),url,l1l111_l1_ (u"ࠩࠪ孫"),l1l111_l1_ (u"ࠪࠫ孬"),l1l111_l1_ (u"ࠫࠬ孭"),l1l111_l1_ (u"ࠬ࠭孮"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ孯"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ孰"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ孱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ孲"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ孳") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ุࠫ๐ัโำࠣ์๏ࠦำ๋็สࠫ孴"): name = l1l111_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ孵")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ孶")+name+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ孷")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ學"),l1l111_l1_ (u"ࠩࠪ孹")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭孺"),l1l111_l1_ (u"ࠫࠬ孻"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ孼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ孽"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ孾") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ孿"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ宀")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫ宁")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡼ࡫ࡣࡪ࡯ࡤࠫ宂")+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ它")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ宄"),l1l111_l1_ (u"ࠧࠨ宅")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ宆"),l1l111_l1_ (u"ࠩࠪ宇"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ守"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠫࠬ安")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭宊"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ宋"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ完"),l1l111_l1_ (u"ࠨ࠭ࠪ宍"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭宎")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ宏"))
	return
def l1l1ll1l_l1_(l1llll1lll1l_l1_,filter):
	if l1l111_l1_ (u"ࠫࡄࡅࠧ宐") in l1llll1lll1l_l1_: url = l1llll1lll1l_l1_.split(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ宑"))[0]
	else: url = l1llll1lll1l_l1_
	filter = filter.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ宒"),l1l111_l1_ (u"ࠧࠨ宓"))
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ宔"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ宕"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ宖"),l1l111_l1_ (u"ࠫࠬ宗")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ官"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ宙"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ定") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ宛") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ宜")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ宝")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ实")+category+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ実")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ宠"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ审")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ客"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ宣"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ室")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ宥"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ宦"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ宧"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ宨"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ宩"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ宪")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll1l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宫"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ宬"),l1111111_l1_,561,l1l111_l1_ (u"ࠬ࠭宭"),l1l111_l1_ (u"࠭ࠧ宮"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ宯"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宰"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ宱")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ宲"),l1111111_l1_,561,l1l111_l1_ (u"ࠫࠬ害"),l1l111_l1_ (u"ࠬ࠭宴"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ宵"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ家"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ宷"),l1l111_l1_ (u"ࠩࠪ宸"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ容"),url,l1l111_l1_ (u"ࠫࠬ宺"),l1l111_l1_ (u"ࠬ࠭宻"),l1l111_l1_ (u"࠭ࠧ宼"),l1l111_l1_ (u"ࠧࠨ宽"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ宾"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠧ࠭宿"),l1l111_l1_ (u"ࠪࠦࠬ寀")).replace(l1l111_l1_ (u"ࠫࡡࡢ࠯ࠨ寁"),l1l111_l1_ (u"ࠬ࠵ࠧ寂"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ寃"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ寄"),block+l1l111_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ寅"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ密") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ寇"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠫࡂࡃࠧ寈") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ寉"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭寊")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll1l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寋"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ富"),l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ寍"),l1l111_l1_ (u"ࠪࠫ寎"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ寏"))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寐"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭寑"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠧࠨ寒"),l1l111_l1_ (u"ࠨࠩ寓"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ寔"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭寕")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ寖")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ寗")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ寘")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ寙")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ寚"),l1lllll_l1_+name+l1l111_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ寛"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠪࠫ寜"),l1l111_l1_ (u"ࠫࠬ寝"),l1l111l1_l1_+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ寞"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"࠭ࡲࠨ察") or value==l1l111_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭寠"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭寡") in option: continue
			if l1l111_l1_ (u"ࠩส่่๊ࠧ寢") in option: continue
			if l1l111_l1_ (u"ࠪࡲ࠲ࡧࠧ寣") in value: continue
			if option==l1l111_l1_ (u"ࠫࠬ寤"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ寥"),option,re.DOTALL)
			if l1ll1l11ll1_l1_: l1l11l1ll_l1_ = l1ll1l11ll1_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"࠭࠺ࠡࠩ實")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ寧")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ寨")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ審")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠭寪")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ寫")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭寬"):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭寭"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠧࠨ寮"),l1l111_l1_ (u"ࠨࠩ寯"),l1l1l11l_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ寰"))
			elif type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ寱") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠫࡂࡃࠧ寲") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ寳"))
				l1llllll_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ寴")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1llll1lll1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寵"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠨࠩ寶"),l1l111_l1_ (u"ࠩࠪ寷"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ寸"))
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ对"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠬ࠭寺"),l1l111_l1_ (u"࠭ࠧ寻"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭导"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ寽"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ対")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠪࡱࡵࡧࡡࠨ寿"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ尀"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ封"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ専"),l1l111_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ尃"),l1l111_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ射"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ尅"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ将")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ將") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ專"),l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ尉"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭尊"),l1l111_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ尋"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩࡀࡁࠬ尌"),l1l111_l1_ (u"ࠪ࠳ࠬ對"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ導"),l1l111_l1_ (u"ࠬ࠵ࠧ小"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ尐"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠧࠨ少")
	if l1l111_l1_ (u"ࠨ࠿ࡀࠫ尒") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠪࠬ尓"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࡂ࠭尔"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭尕")
		if l1l111_l1_ (u"ࠬࠫࠧ尖") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ尗") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ尘"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ尙")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ尚") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ尛"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ尜")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ尝")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ尞"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ尟")+key+l1l111_l1_ (u"ࠨ࠿ࡀࠫ尠")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭尡"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭尢"))
	return l1l1l111_l1_
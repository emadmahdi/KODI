# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ峔")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭峕")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11l111l1ll1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l11l111l1l11_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l11l11ll1ll1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l11l11l11lll_l1_()
	elif mode==148: l1lll_l1_ = l11l11l1l11l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峖"),l1lllll_l1_+l1l111_l1_ (u"ࠩๅหห๋ษࠨ峗"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ峘"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峙"),l1lllll_l1_+l1l111_l1_ (u"ฺࠬฮึࠩ峚"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ峛"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峜"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ๆ฾࠭峝"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ峞"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峟"),l1lllll_l1_+l1l111_l1_ (u"ࠫาูวษࠩ峠"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭峡"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峢"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ฼หอ࠭峣"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ峤"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峥"),l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠩ峦"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ峧"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峨"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะࠧ峩"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭峪"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峫"),l1lllll_l1_+l1l111_l1_ (u"ࠩๅู๏ืษࠨ峬"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ峭"),144,l1l111_l1_ (u"ࠫࠬ峮"),l1l111_l1_ (u"ࠬ࠭峯"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ峰"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峱"),l1lllll_l1_+l1l111_l1_ (u"ࠨฬุๅา࠭峲"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ峳"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峴"),l1lllll_l1_+l1l111_l1_ (u"ࠫึฬ๊ิ์ฬࠫ峵"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠭島"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峷"),l1lllll_l1_+l1l111_l1_ (u"ࠧาษษะࠬ峸"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭峹"),144)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ峺"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ峻"),l1l111_l1_ (u"ࠫࠬ峼"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峽"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭峾"),l1l111_l1_ (u"ࠧࠨ峿"),149,l1l111_l1_ (u"ࠨࠩ崀"),l1l111_l1_ (u"ࠩࠪ崁"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ崂"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ崃"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ崄"),l1l111_l1_ (u"࠭ࠧ崅"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崆"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ崇"),l111l1_l1_+l1l111_l1_ (u"ࠩࠪ崈"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崉"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ัศศฯอࠬ崊"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭崋"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崌"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆอูๆำࠧ崍"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ崎"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崏"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้่ี๋ำฬࠫ崐"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ崑"),144,l1l111_l1_ (u"ࠬ࠭崒"),l1l111_l1_ (u"࠭ࠧ崓"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ崔"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崕"),l1lllll_l1_+l1l111_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ崖"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ崗"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崘"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ崙"),l1l111_l1_ (u"࠭ࠧ崚"),290)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ崛"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ崜"),l1l111_l1_ (u"ࠩࠪ崝"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崞"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ崟"),l1l111_l1_ (u"ࠬ࠭崠"),147)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崡"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ崢"),l1l111_l1_ (u"ࠨࠩ崣"),148)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崤"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭崥"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ崦"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ崧"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ崨"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ崩"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崪"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ崫"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ崬"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崭"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ崮"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ崯"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崰"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ崱"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ崲"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崳"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ崴"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ崵"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崶"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ崷"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ崸"),144)
	return
def l11l111l1l11_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崹"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ崺")+name,url,144,l11l_l1_)
	return
def l11l11l11lll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ崻"))
	return
def l11l11l1l11l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ崼"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"࠭ࠦࠨ崽"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11l11111_l1_(yccc,url,index):
	level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ崾"))
	l11l111l11l1_l1_,l11l11l1111l_l1_ = [],[]
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ崿") in url: l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝ࠣ嵀"))
	if l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ嵁") in url: l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠࠦ嵂"))
	if level==l1l111_l1_ (u"ࠬ࠷ࠧ嵃"): l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ嵄"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嵅"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠࠦ嵆"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡧࡱࡸࡷ࡯ࡥࡴࠩࡠࠦ嵇"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟࡞࠷ࡢࡡࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嵈"))
	l11l11l1ll11_l1_,yddd,l11l111lllll_l1_ = l11l111l1111_l1_(yccc,l1l111_l1_ (u"ࠫࠬ嵉"),l11l111l11l1_l1_)
	if level==l1l111_l1_ (u"ࠬ࠷ࠧ嵊") and l11l11l1ll11_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ嵋") not in url:
			for zz in range(len(yddd)):
				l11l111ll11l_l1_ = str(zz)
				l11l111l11l1_l1_ = []
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ嵌")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ嵍"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ嵎")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࠧ࡞ࠤ嵏"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ嵐")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠧࡣࠢ嵑"))
				succeeded,item,l1111ll1_l1_ = l11l111l1111_l1_(yddd,l1l111_l1_ (u"࠭ࠧ嵒"),l11l111l11l1_l1_)
				if succeeded: l11l11l1111l_l1_.append([item,url,l1l111_l1_ (u"ࠧ࠳࠼࠽ࠫ嵓")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ嵔")])
			l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟ࠥ嵕"))
			succeeded,item,l1111ll1_l1_ = l11l111l1111_l1_(yccc,l1l111_l1_ (u"ࠪࠫ嵖"),l11l111l11l1_l1_)
			if succeeded and l11l11l1111l_l1_ and l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪ嵗") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ嵘")
				l11l11l1111l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嵙")])
	return yddd,l11l11l1ll11_l1_,l11l11l1111l_l1_,l11l111lllll_l1_
def l11l1111ll1l_l1_(yccc,yddd,url,index):
	level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵚"))
	l11l111l11l1_l1_,l11l11l111l1_l1_ = [],[]
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ嵛"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ嵜")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ嵝"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝࠴ࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ嵞"))
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ嵟") in url: l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ嵠"))
	elif l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭嵡") in url: l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵢"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ嵣")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵤"))
	if l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ嵥") in url or (l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭嵦") in url and l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ嵧") not in url):
		l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ嵨")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ嵩"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ嵪")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嵫"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ嵬")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡢࡤ࡯ࡩ࡙ࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嵭"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ嵮")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嵯"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ嵰")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠤࡠࠦ嵱"))
	l11l11l1l1l1_l1_,yeee,l11l111llll1_l1_ = l11l111l1111_l1_(yddd,l1l111_l1_ (u"ࠪࠫ嵲"),l11l111l11l1_l1_)
	if level==l1l111_l1_ (u"ࠫ࠷࠭嵳") and l11l11l1l1l1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l11l111l11l1_l1_ = []
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嵴")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ嵵"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嵶")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ嵷"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ嵸")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ嵹"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嵺")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ嵻"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嵼")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ嵽"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嵾")+index2+l1l111_l1_ (u"ࠤࡠࠦ嵿"))
				succeeded,item,l1111ll1_l1_ = l11l111l1111_l1_(yeee,l1l111_l1_ (u"ࠪࠫ嶀"),l11l111l11l1_l1_)
				if succeeded: l11l11l111l1_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠸ࡀ࠺ࠨ嶁")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶂")+index2+l1l111_l1_ (u"࠭࠺࠻࠲ࠪ嶃")])
			l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ嶄"))
			l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠱࡞ࠤ嶅"))
			succeeded,item,l1111ll1_l1_ = l11l111l1111_l1_(yddd,l1l111_l1_ (u"ࠩࠪ嶆"),l11l111l11l1_l1_)
			if succeeded and l11l11l111l1_l1_ and l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶇") in list(item.keys()):
				l11l11l111l1_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ嶈")])
	return yeee,l11l11l1l1l1_l1_,l11l11l111l1_l1_,l11l111llll1_l1_
def l11l111l1l1l_l1_(yccc,yeee,url,index):
	level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶉"))
	l11l111l11l1_l1_,l11l111l1lll_l1_ = [],[]
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嶊")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡺࡪࡸࡴࡪࡥࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ嶋"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嶌")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ嶍"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ嶎")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嶏"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嶐")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嶑"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嶒")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ嶓"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ嶔")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嶕"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嶖")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ嶗"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嶘")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嶙"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嶚"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嶛"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嶜"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嶝")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嶞"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嶟")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嶠"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࠨ嶡"))
	l11l11l1lll1_l1_,yfff,l11l11lll111_l1_ = l11l111l1111_l1_(yeee,l1l111_l1_ (u"ࠩࠪ嶢"),l11l111l11l1_l1_)
	if level==l1l111_l1_ (u"ࠪ࠷ࠬ嶣") and l11l11l1lll1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l11l111ll1ll_l1_ = str(zz)
				l11l111l11l1_l1_ = []
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡬ࡦࡧ࡝ࠥ嶤")+l11l111ll1ll_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ嶥"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡧࡨࡩ࡟ࠧ嶦")+l11l111ll1ll_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ嶧"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ嶨")+l11l111ll1ll_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ嶩"))
				l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ嶪")+l11l111ll1ll_l1_+l1l111_l1_ (u"ࠦࡢࠨ嶫"))
				succeeded,item,l1111ll1_l1_ = l11l111l1111_l1_(yfff,l1l111_l1_ (u"ࠬ࠭嶬"),l11l111l11l1_l1_)
				if succeeded: l11l111l1lll_l1_.append([item,url,l1l111_l1_ (u"࠭࠴࠻࠼ࠪ嶭")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶮")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶯")+l11l111ll1ll_l1_])
	return yfff,l11l11l1lll1_l1_,l11l111l1lll_l1_,l11l11lll111_l1_
def l11l111l1111_l1_(l1l1lllll1l1_l1_,l1ll1111111l_l1_,l11l111ll111_l1_):
	yccc,l1ll1111111l_l1_ = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	yddd,l1ll1111111l_l1_ = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	yeee,l1ll1111111l_l1_ = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	yfff,l1ll1111111l_l1_ = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	item,yrender = l1l1lllll1l1_l1_,l1ll1111111l_l1_
	count = len(l11l111ll111_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l111ll111_l1_[l1l111llll_l1_])
			return True,out,l1l111llll_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠩࠪ嶰"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠪࠫ嶱"),data=l1l111_l1_ (u"ࠫࠬ嶲")):
	l11l11l1111l_l1_,l11l11l111l1_l1_,l11l111l1lll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶳") not in index: index = l1l111_l1_ (u"࠭࠱࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嶴")
	level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶵"))
	if level==l1l111_l1_ (u"ࠨ࠶ࠪ嶶"): level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ嶷"),l11l111ll11l_l1_,index2,l11l111ll1ll_l1_
	data = data.replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嶸"),l1l111_l1_ (u"ࠫࠬ嶹"))
	html,yccc,l1l11llll_l1_ = l11l11l111ll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶺")+l11l111ll11l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嶻")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶼")+l11l111ll1ll_l1_
	if level in [l1l111_l1_ (u"ࠨ࠳ࠪ嶽"),l1l111_l1_ (u"ࠩ࠵ࠫ嶾"),l1l111_l1_ (u"ࠪ࠷ࠬ嶿")]:
		yddd,l11l11l1ll11_l1_,l11l11l1111l_l1_,l11l111lllll_l1_ = l11l11l11111_l1_(yccc,url,index)
		if not l11l11l1ll11_l1_: return
		l1llll1l1l_l1_ = len(l11l11l1111l_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠫ࠶࠭巀"): level = l1l111_l1_ (u"ࠬ࠸ࠧ巁")
			l11l11l1111l_l1_ = []
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ巂")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ巃")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巄")+l11l111ll1ll_l1_
	if level in [l1l111_l1_ (u"ࠩ࠵ࠫ巅"),l1l111_l1_ (u"ࠪ࠷ࠬ巆")]:
		yeee,l11l11l1l1l1_l1_,l11l11l111l1_l1_,l11l111llll1_l1_ = l11l1111ll1l_l1_(yccc,yddd,url,index)
		if not l11l11l1l1l1_l1_: return
		l1ll1l111l_l1_ = len(l11l11l111l1_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠫ࠷࠭巇"): level = l1l111_l1_ (u"ࠬ࠹ࠧ巈")
			l11l11l111l1_l1_ = []
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ巉")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ巊")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巋")+l11l111ll1ll_l1_
	if level in [l1l111_l1_ (u"ࠩ࠶ࠫ巌")]:
		yfff,l11l11l1lll1_l1_,l11l111l1lll_l1_,l11l11lll111_l1_ = l11l111l1l1l_l1_(yccc,yeee,url,index)
		if not l11l11l1lll1_l1_: return
		l1ll1l11l1_l1_ = len(l11l111l1lll_l1_)
	for item,url,index in l11l11l1111l_l1_+l11l11l111l1_l1_+l11l111l1lll_l1_:
		l1ll1ll1ll1l_l1_ = l11l111l11ll_l1_(item,url,index)
	return
def l11l111l11ll_l1_(item,url=l1l111_l1_ (u"ࠪࠫ巍"),index=l1l111_l1_ (u"ࠫࠬ巎")):
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ巏") in index: level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ巐"))
	else: level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ巑"),l1l111_l1_ (u"ࠨ࠲ࠪ巒"),l1l111_l1_ (u"ࠩ࠳ࠫ巓"),l1l111_l1_ (u"ࠪ࠴ࠬ巔")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_,l11l11ll1l1l_l1_ = l11l11lll1l1_l1_(item)
	l1lllll1ll1l_l1_ = l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࡄ࠭巕") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡳࡵࡴࡨࡥࡲࡹ࠿ࠨ巖") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࡂࠫ巗") in l1ll1ll_l1_
	l1lllll1l1ll_l1_ = l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡂࠫ巘") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࡁࠪ巙") in l1ll1ll_l1_
	if l1lllll1ll1l_l1_ or l1lllll1l1ll_l1_: l1ll1ll_l1_ = url
	l1lllll1ll1l_l1_ = l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ巚") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ巛") not in l1ll1ll_l1_
	l1lllll1l1ll_l1_ = l1l111_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ巜") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ川") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠭州") and l1lllll1ll1l_l1_ and l1lllll1l1ll_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ巟") in url or l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ巠") in l1ll1ll_l1_:
		level,l11l111ll11l_l1_,index2,l11l111ll1ll_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ巡"),l1l111_l1_ (u"ࠪ࠴ࠬ巢"),l1l111_l1_ (u"ࠫ࠵࠭巣"),l1l111_l1_ (u"ࠬ࠶ࠧ巤")
		index = l1l111_l1_ (u"࠭ࠧ工")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠧࠨ左")
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ巧") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ巨") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ巩") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭巪"))
		if data.count(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ巫"))==4:
			l11l11l1ll1l_l1_,key,l11l11l1l111_l1_,l11l11l11l1l_l1_,token = data.split(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ巬"))
			l1l11llll_l1_ = l11l11l1ll1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ巭")+key+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ差")+l11l11l1l111_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭巯")+l11l11l11l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ巰")+l11l11ll1l1l_l1_
			if l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ己") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ已")+key
	if not title:
		global l11l111l1ll1_l1_
		l11l111l1ll1_l1_ += 1
		title = l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࠩ巳")+str(l11l111l1ll1_l1_)
		index = l1l111_l1_ (u"ࠧ࠴ࠩ巴")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巵")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巶")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭巷")+l11l111ll1ll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡔࡾࡼࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ巸") in str(item): return False
	elif l1l111_l1_ (u"ࠬ࠵ࡡࡣࡱࡸࡸࠬ巹") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"࠭࠯ࡤࡱࡰࡱࡺࡴࡩࡵࡻࠪ巺") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ巻") in list(item.keys()) or l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ巼") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巽")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭巾")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ巿")+l11l111ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ帀"),l1lllll_l1_+l1l111_l1_ (u"࠭࠺࠻ࠢࠪ币")+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ市"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ布") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭帄")+title
		index = l1l111_l1_ (u"ࠪ࠷ࠬ帅")+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帆")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ帇")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ师")+l11l111ll1ll_l1_
		url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ帉"),l1l111_l1_ (u"ࠨࠩ帊"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ帋"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠪࠫ希"),index,l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ帍"))
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ帎") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"࠭࠳ࠨ帏")+l1l111_l1_ (u"ࠧ࠻࠼ࠪ帐")+l11l111ll11l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ帑")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ帒")+l11l111ll1ll_l1_
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ帓")+title
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ帔"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪ࠭帕") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"࠭࠺࠻ࠢࠪ帖")+title
		index = l1l111_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ帗")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ帘"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ帙") in str(item):
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ帚")+title
		index = l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ帛")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ帜"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ帝") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ帞"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ帟"),9999)
	elif l11l11l1llll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ帠"),l1lllll_l1_+l11l11l1llll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ帡") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ帢"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡒࡉࡔࡖࠪ帣")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ帤")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ帥") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ带"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ帧"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭帨") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ帩") in l1ll1ll_l1_ and count:
			l11l11l1l1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ帪"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ師")+l11l11l1l1ll_l1_
			index = l1l111_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ帬")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ席"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ帮")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ帯")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ帰"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ帱"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ帲") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡥ࠲ࠫ帳") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠨ࠱ࡃࠫ帴") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠩ࠲ࠫ帵"))==3):
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ帶"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ帷")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ常")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭帹") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ帺"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭帻")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭帼")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ帽")+title
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ帾"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l11l11lll1l1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_,token = False,l1l111_l1_ (u"ࠬ࠭帿"),l1l111_l1_ (u"࠭ࠧ幀"),l1l111_l1_ (u"ࠧࠨ幁"),l1l111_l1_ (u"ࠨࠩ幂"),l1l111_l1_ (u"ࠩࠪ幃"),l1l111_l1_ (u"ࠪࠫ幄"),l1l111_l1_ (u"ࠫࠬ幅"),l1l111_l1_ (u"ࠬ࠭幆")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_,token
	for l11l11l11ll1_l1_ in list(item.keys()):
		yrender = item[l11l11l11ll1_l1_]
		if isinstance(yrender,dict): break
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ幇"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ幈"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤ࡭࡫ࡱࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ幉"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ幊"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ幋"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ幌"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ幍"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ幎"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ幏"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ幐"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ幑"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪࡡࠧ幒"))
	succeeded,title,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ幓"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ幔"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ幕"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡤࡴ࡮࡛ࡲ࡭ࠩࡠࠦ幖"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ幗"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ幘"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ幙"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ幚"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ幛"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡸࡥࡦ࡮࡚ࡥࡹࡩࡨࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ幜"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ幝"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ幞"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ幟"))
	succeeded,count,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ幠"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ幡"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ幢"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡥࡲࡲࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࡚ࡹࡱࡧࠪࡡࠧ幣"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡷࡽࡱ࡫ࠧ࡞ࠤ幤"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	l11l111l11l1_l1_ = []
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ幥"))
	l11l111l11l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡷࡳࡰ࡫࡮ࠨ࡟ࠥ幦"))
	succeeded,token,l1111ll1_l1_ = l11l111l1111_l1_(item,yrender,l11l111l11l1_l1_)
	if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ幧") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ幨"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭幩")
	if l1l111_l1_ (u"࠭ๅษษืีࠬ幪") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ幫"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ幬")
	if l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ幭") in list(yrender.keys()):
		l11l11ll11ll_l1_ = str(yrender[l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ幮")])
		if l1l111_l1_ (u"ࠫࡋࡸࡥࡦࠢࡺ࡭ࡹ࡮ࠠࡂࡦࡶࠫ幯") in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ幰")
		if l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠫ幱") in l11l11ll11ll_l1_: l11l11l1llll_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ干")
		if l1l111_l1_ (u"ࠨࡄࡸࡽࠬ平") in l11l11ll11ll_l1_ or l1l111_l1_ (u"ࠩࡕࡩࡳࡺࠧ年") in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ幵")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡹ๋ࠬศศึิࠫ并")) in l11l11ll11ll_l1_: l11l11l1llll_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭幷")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡻࠧีำสลࠬ幸")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭幹")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡶࠩสืฯฬฬศำࠪ幺")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ幻")
		if l111lll111l_l1_(l1l111_l1_ (u"ࡸࠫส฿ไศ่สฮࠬ幼")) in l11l11ll11ll_l1_: l11l11l11l11_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠠࠡࠩ幽")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ幾") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"࠭࠿ࠨ广"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ庀") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ庁")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l11l11l11_l1_: title = l11l11l11l11_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠩ࠯ࠫ庂"),l1l111_l1_ (u"ࠪࠫ広"))
	count = count.replace(l1l111_l1_ (u"ࠫ࠱࠭庄"),l1l111_l1_ (u"ࠬ࠭庅"))
	count = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ庆"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠧࠨ庇")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1llll_l1_,l11l11l11l11_l1_,token
def l11l11l111ll_l1_(url,data=l1l111_l1_ (u"ࠨࠩ庈"),request=l1l111_l1_ (u"ࠩࠪ庉")):
	if request==l1l111_l1_ (u"ࠪࠫ床"): request = l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ庋")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ庌"):l11ll1l1ll_l1_,l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭庍"):l1l111_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ庎")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ序"))
	if data.count(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭庐"))==4: l11l11l1ll1l_l1_,key,l11l11l1l111_l1_,l11l11l11l1l_l1_,token = data.split(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ庑"))
	else: l11l11l1ll1l_l1_,key,l11l11l1l111_l1_,l11l11l11l1l_l1_,token = l1l111_l1_ (u"ࠫࠬ庒"),l1l111_l1_ (u"ࠬ࠭库"),l1l111_l1_ (u"࠭ࠧ应"),l1l111_l1_ (u"ࠧࠨ底"),l1l111_l1_ (u"ࠨࠩ庖")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠤࡦࡳࡳࡺࡥࡹࡶࠥ店"):{l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ庘"):{l1l111_l1_ (u"ࠦ࡭ࡲࠢ庙"):l1l111_l1_ (u"ࠧࡧࡲࠣ庚"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ庛"):l1l111_l1_ (u"ࠢࡘࡇࡅࠦ府"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ庝"):l11l11l1l111_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ庞") or l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ废") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡶࡪ࡫࡬࠰ࡴࡨࡩࡱࡥࡷࡢࡶࡦ࡬ࡤࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ庠")+l1l111_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ庡")+key
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࡑࡣࡵࡥࡲࡹࠧ庢")] = l11l11l1ll1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ庣"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭庤"))
	elif l1l111_l1_ (u"ࠩ࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ庥") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭度")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ座"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ庨"))
	elif l1l111_l1_ (u"࠭࡫ࡦࡻࡀࠫ庩") in url and l11l11l1ll1l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭庪")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ庫")][l1l111_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࠩ庬")][l1l111_l1_ (u"ࠪࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ庭")] = l11l11l1ll1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ庮"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ庯"))
	elif l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ庰") in url and l11l11l11l1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ庱"):l1l111_l1_ (u"ࠨ࠳ࠪ庲"),l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭庳"):l11l11l1l111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ庴"):l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ庵")+l11l11l11l1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ庶"),url,l1l111_l1_ (u"࠭ࠧ康"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ庸"),l1l111_l1_ (u"ࠨࠩ庹"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠹ࡹ࡮ࠧ庺"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ庻"),url,l1l111_l1_ (u"ࠫࠬ庼"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭庽"),l1l111_l1_ (u"࠭ࠧ庾"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠸ࡷ࡬ࠬ庿"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ廀"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ廁"),html,re.DOTALL|re.I)
	if tmp: l11l11l1l111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭廂"),html,re.DOTALL|re.I)
	if tmp: l11l11l1ll1l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ廃") in list(cookies.keys()): l11l11l11l1l_l1_ = cookies[l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ廄")]
	l1l1l1111_l1_ = l11l11l1ll1l_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ廅")+key+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ廆")+l11l11l1l111_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ廇")+l11l11l11l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭廈")+token
	if request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ廉") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ廊") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ廋"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ廌"),html,re.DOTALL)
		l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ廍"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭廎") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ廏") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ廐"),html,re.DOTALL)
		l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ廑"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ廒") not in html: l11l11ll11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ廓"),html)
	else: l11l11ll11l1_l1_ = l1l111_l1_ (u"ࠧࠨ廔")
	if 0:
		yccc = str(l11l11ll11l1_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭廕"))
		open(l1l111_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ廖"),l1l111_l1_ (u"ࠪࡻࡧ࠭廗")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭廘"),l1l1l1111_l1_)
	return html,l11l11ll11l1_l1_,l1l1l1111_l1_
def l11l11ll1ll1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ廙"),l1l111_l1_ (u"࠭ࠫࠨ廚"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ廛")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ廜"),l1l111_l1_ (u"ࠩ࠮ࠫ廝"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ廞")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ廟") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ廠")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ廡") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ廢")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭廣") in options: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ廤")
		else: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠪࠫ廥")
		l1llllll_l1_ = l1lllll1_l1_+l11l111lll1l_l1_
	else:
		l11l111lll11_l1_,l11l1111llll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠫࠬ廦")
		l11l111l111l_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ廧"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ廨"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ廩"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ廪"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭廫")]
		l11l11ll111l_l1_ = [l1l111_l1_ (u"ࠪࠫ廬"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ廭"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ廮"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ廯"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭廰")]
		l11l11ll1l11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ廱"),l11l111l111l_l1_)
		if l11l11ll1l11_l1_ == -1: return
		l11l111ll1l1_l1_ = l11l11ll111l_l1_[l11l11ll1l11_l1_]
		html,c,data = l11l11l111ll_l1_(l1lllll1_l1_+l11l111ll1l1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ廲")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廳")][l1l111_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭廴")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ廵")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ延")][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ廷")][l1l111_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ廸")]
				for l11l1111lll1_l1_ in range(len(d)):
					group = d[l11l1111lll1_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ廹")][l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ建")]
					for l11l11ll1lll_l1_ in range(len(group)):
						yrender = group[l11l11ll1lll_l1_][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ廻")]
						if l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ廼") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ廽")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ廾")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭廿")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭开")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ弁"),l1l111_l1_ (u"ࠫࠫ࠭异"))
							title = yrender[l1l111_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭弃")]
							title = title.replace(l1l111_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ弄"),l1l111_l1_ (u"ࠧࠨ弅"))
							if l1l111_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ弆") in title: continue
							if l1l111_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ弇") in title:
								title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ弈")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ弉") in title: continue
							title = title.replace(l1l111_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ弊"),l1l111_l1_ (u"࠭ࠧ弋"))
							if l1l111_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ弌") in title: continue
							if l1l111_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ弍") in title:
								title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ弎")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ式") in title: continue
							l11l111lll11_l1_.append(escapeUNICODE(title))
							l11l1111llll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l11l11ll1111_l1_ = l1l111_l1_ (u"ࠫࠬ弐")
		else:
			l11l111lll11_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ弑"),l1lllllll_l1_]+l11l111lll11_l1_
			l11l1111llll_l1_ = [l1l111_l1_ (u"࠭ࠧ弒"),l111lllll_l1_]+l11l1111llll_l1_
			l11l11lll11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ弓"),l11l111lll11_l1_)
			if l11l11lll11l_l1_ == -1: return
			l11l11ll1111_l1_ = l11l1111llll_l1_[l11l11lll11l_l1_]
		if l11l11ll1111_l1_: l1llllll_l1_ = l111l1_l1_+l11l11ll1111_l1_
		elif l11l111ll1l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l111ll1l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
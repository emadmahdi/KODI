# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1lll_l1_(l1l111_l1_ (u"࡙ࠫࡋࡓࡕࠩ婿"),l1l111_l1_ (u"࡚ࠬࡅࡔࡖࠪ媀"))
l1ll11l11111_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡸ࠷࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡩ࡫ࡱ࡯ࡧࡸ࡯ࡢࡦࡥࡥࡳࡪ࠮ࡤࡱࡰ࠳࠶࠶ࡍࡃ࠰ࡽ࡭ࡵ࠭媁")
l1ll11l11111_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡨࡩࡩࡺࡥࡴࡶ࠱ࡪࡹࡶ࠮ࡰࡶࡨࡲࡪࡺ࠮ࡨࡴ࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡩࡸࡺ࠱࠱࠲࡮࠲ࡩࡨࠧ媂")
l1llllll111l_l1_(l1ll11l11111_l1_,{},True)
url = l1l111_l1_ (u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ๅา฻࠮࡮ࡲ࠶ࠫ媃")
url = l1l111_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠ࡫࡯࡬ࡦࡡ࠷࠼࠸࠺࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧ媄")
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
import bs4
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ●")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡎࡆࡣࠬ◐")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ◑"):l111l1_l1_}
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==510: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==511: l1lll_l1_ = l1llllll1l1_l1_(url)
	elif mode==512: l1lll_l1_ = l1111llll1_l1_(url)
	elif mode==513: l1lll_l1_ = l1111lll1l_l1_(url)
	elif mode==514: l1lll_l1_ = l1lllllll11_l1_(url,l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ◒")+text)
	elif mode==515: l1lll_l1_ = l1lllllll11_l1_(url,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ◓")+text)
	elif mode==516: l1lll_l1_ = l11111lll1_l1_(text)
	elif mode==517: l1lll_l1_ = l1111l1ll1_l1_(url)
	elif mode==518: l1lll_l1_ = l1111l1lll_l1_(url)
	elif mode==519: l1lll_l1_ = l1lll1_l1_(text)
	elif mode==520: l1lll_l1_ = l1111l111l_l1_(url)
	elif mode==521: l1lll_l1_ = l1llllll11l_l1_(url)
	elif mode==522: l1lll_l1_ = PLAY(url)
	elif mode==523: l1lll_l1_ = l1lllllllll_l1_(text)
	elif mode==524: l1lll_l1_ = l1111111l1_l1_()
	elif mode==525: l1lll_l1_ = l1111lll11_l1_()
	elif mode==526: l1lll_l1_ = l1111l1111_l1_()
	elif mode==527: l1lll_l1_ = l1111111ll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫ◔")):
	if not l1l11l11_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◕"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢห้ํฺู่หࠣหู้๊็็สࠫ◖"),l1l111_l1_ (u"࠭ࠧ◗"),519)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ◘"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ◙"),l1l111_l1_ (u"ࠩࠪ◚"),9999)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◛"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊รฺ็ส่ࠬ◜"),l1l111_l1_ (u"ࠬ࠭◝"),525)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◞"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆฦุำอีࠨ◟"),l1l111_l1_ (u"ࠨࠩ◠"),526)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◡"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํฺู่หࠣห้๋ี็ใสฮࠬ◢"),l1l111_l1_ (u"ࠫࠬ◣"),527)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◤"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅ็้์฾อสࠨ◥"),l1l111_l1_ (u"ࠧࠨ◦"),524)
	return
def l1111111l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◧"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣๅ๏ี๊้้สฮࠥ࠳ࠠฯษุอࠬ◨"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࠪ◩"),520)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◪"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦัิัࠧ◫"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵࡬ࡢࡶࡨࡷࡹ࠭◬"),521)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◭"),l1lllll_l1_+l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษโะ็ࠪ◮"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࡲࡰࡩ࡫ࡳࡵࠩ◯"),521)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◰"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡลๆฯึࠦๅีษ๊ำฮ࠭◱"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡼࡩࡦࡹࡶࠫ◲"),521)
	return
def l1111lll11_l1_():
	l1lllllll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨ◳")
	l11111l1l1_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪ◴")
	l1111ll1ll_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫ◵")
	l111111l11_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫ◶")
	l111111l1l_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬ◷")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◸"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥษแๅษ่ࠤ฾ืศ๋ࠩ◹"),l11111l1l1_l1_,511)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◺"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠๆี็ื้อสࠡ฻ิฬ๏࠭◻"),l1111ll1ll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◼"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢฦๅ้อๅࠡษฯ๊อ๐ࠧ◽"),l111111l11_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◾"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤู๊ไิๆสฮࠥอฬ็สํࠫ◿"),l111111l1l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ☀"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ☁"),l1l111_l1_ (u"ࠧࠨ☂"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☃"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๋ึูࠠฤ฻่ห้ࠦรษฮา๎ࠬ☄"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪ★"),517)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☆"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีࠣࠤอ๊ฯࠡษ็ษ๋ะวอࠩ☇"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡨࡵࡵ࡯ࡶࡵࡽࠬ☈"),517)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☉"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦวๅๆ฽อࠬ☊"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ☋"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☌"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิู่๋ࠢ็วหࠢส่฾๋ไࠨ☍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲࡫ࡪࡴࡲࡦࠩ☎"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☏"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืูࠥๆสࠢส่ส฻ฯศำࠪ☐"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࡟ࡺࡧࡤࡶࠬ☑"),517)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ☒"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ☓"),l1l111_l1_ (u"ࠫࠬ☔"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☕"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ษึ้ࠥ࠳ࠠโๆอี๋ࠥอะัࠪ☖"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ☗"),515)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☘"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ฬูๅࠡ࠯ࠣๅ้ะัࠡๅส้้࠭☙"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ☚"),514)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ☛"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☜"),l1l111_l1_ (u"࠭ࠧ☝"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☞"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭☟"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ☠"),515)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☡"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ☢"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭☣"),514)
	return
def l1111111ll_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ☤"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ☥"),l1l111_l1_ (u"ࠨࠩ☦"),headers,l1l111_l1_ (u"ࠩࠪ☧"),l1l111_l1_ (u"ࠪࠫ☨"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ☩"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ☪"),multi_valued_attributes=None)
	block = l1llllll111_l1_.find(l1l111_l1_ (u"࠭ࡳࡦ࡮ࡨࡧࡹ࠭☫"),attrs={l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ☬"):l1l111_l1_ (u"ࠨࡶࡤ࡫ࠬ☭")})
	options = block.find_all(l1l111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠩ☮"))
	for option in options:
		value = option.get(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ☯"))
		if not value: continue
		title = option.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ☰"))
			value = value.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ☱"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࡶࡼࡴࡪࡃࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠩࡪࡴࡸࡥࡪࡩࡱࡁࠫࡺࡡࡨ࠿ࠪ☲")+value
		title = title.replace(l1l111_l1_ (u"ࠧใษษ้ฮࠦࠧ☳"),l1l111_l1_ (u"ࠨࠩ☴"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☵"),l1lllll_l1_+title,l1ll1ll_l1_,511)
	return
def l1111l1111_l1_():
	l1lllllll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠬ☶")
	l11111l11l_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨ☷")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☸"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅึ่ไหฯࠦรีะสูࠬ☹"),l11111l11l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ☺"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ☻"),l1l111_l1_ (u"ࠩࠪ☼"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☽"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิࠢฦุำอีࠡลหะิ๐ࠧ☾"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡧ࡬ࡱࡪࡤࡦࡪࡺࠧ☿"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♀"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืุ๋่่ࠥࠪ♁"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡰࡤࡸ࡮ࡵ࡮ࡢ࡮࡬ࡸࡾ࠭♂"),517)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♃"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡࠢอหึ๐ฮࠡษ็้๏๊วะࠩ♄"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡧ࡯ࡲࡵࡪࡢࡽࡪࡧࡲࠨ♅"),517)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♆"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤࠥะวา์ัࠤฬ๊่โษฬࠫ♇"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯ࡥࡧࡤࡸ࡭ࡥࡹࡦࡣࡵࠫ♈"),517)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭♉"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ♊"),l1l111_l1_ (u"ࠪࠫ♋"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♌"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี๋ࠥอะัࠪ♍"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ♎"),515)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♏"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡๅส้้࠭♐"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ♑"),514)
	return
def l1llllll1l1_l1_(url):
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ♒") in url: index = 0
	elif l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ♓") in url: index = 1
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ♔"),url,l1l111_l1_ (u"࠭ࠧ♕"),headers,l1l111_l1_ (u"ࠧࠨ♖"),l1l111_l1_ (u"ࠨࠩ♗"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ♘"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ♙"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠫ࡯ࡻ࡭ࡣࡱ࠰ࡸ࡭࡫ࡡࡵࡧࡵࠤࡨࡲࡥࡢࡴࡩ࡭ࡽ࠭♚"))
	for block in l1lll1l1_l1_:
		title = block.find_all(l1l111_l1_ (u"ࠬࡧࠧ♛"))[index].text
		l1ll1ll_l1_ = l111l1_l1_+block.find_all(l1l111_l1_ (u"࠭ࡡࠨ♜"))[index].get(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ♝"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭♞"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♟"))
		if not l1lll1l1_l1_:
			l1111llll1_l1_(l1ll1ll_l1_)
			return
		else:
			title = title.replace(l1l111_l1_ (u"ࠪๆฬฬๅสࠢࠪ♠"),l1l111_l1_ (u"ࠫࠬ♡"))
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♢"),l1lllll_l1_+title,l1ll1ll_l1_,512)
	PAGINATION(l1llllll111_l1_,511)
	return
def PAGINATION(l1llllll111_l1_,mode):
	block = l1llllll111_l1_.find(class_=l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ♣"))
	if block:
		l1ll1l1ll_l1_ = block.find_all(l1l111_l1_ (u"ࠧࡢࠩ♤"))
		l1lllll1lll_l1_ = block.find_all(l1l111_l1_ (u"ࠨ࡮࡬ࠫ♥"))
		l11111llll_l1_ = list(zip(l1ll1l1ll_l1_,l1lllll1lll_l1_))
		l1l111llll_l1_ = -1
		length = len(l11111llll_l1_)
		for l1lll1l1l_l1_,l1llllllll1_l1_ in l11111llll_l1_:
			l1l111llll_l1_ += 1
			l1llllllll1_l1_ = l1llllllll1_l1_[l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳࠨ♦")]
			if l1l111_l1_ (u"ࠪࡹࡳࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࠨ♧") in l1llllllll1_l1_ or l1l111_l1_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࠬ♨") in l1llllllll1_l1_: continue
			l11111111l_l1_ = l1lll1l1l_l1_.text
			l111lllll_l1_ = l111l1_l1_+l1lll1l1l_l1_.get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ♩"))
			if PY2:
				l11111111l_l1_ = l11111111l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♪"))
				l111lllll_l1_ = l111lllll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♫"))
			if   l1l111llll_l1_==0: l11111111l_l1_ = l1l111_l1_ (u"ࠨล๋่๎࠭♬")
			elif l1l111llll_l1_==1: l11111111l_l1_ = l1l111_l1_ (u"ࠩึหอ่ษࠨ♭")
			elif l1l111llll_l1_==length-2: l11111111l_l1_ = l1l111_l1_ (u"่ࠪฬำโสࠩ♮")
			elif l1l111llll_l1_==length-1: l11111111l_l1_ = l1l111_l1_ (u"ࠫศิ๊าหࠪ♯")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♰"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ♱")+l11111111l_l1_,l111lllll_l1_,mode)
	return
def l1111llll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ♲"),url,l1l111_l1_ (u"ࠨࠩ♳"),headers,l1l111_l1_ (u"ࠩࠪ♴"),l1l111_l1_ (u"ࠪࠫ♵"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠷࠭࠲ࡵࡷࠫ♶"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ♷"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"࠭ࡲࡰࡹࠪ♸"))
	items,first = [],True
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫ♹")): continue
		if first: first = False ; continue
		l111111ll1_l1_ = []
		l1lllll1ll1_l1_ = block.find_all(class_=[l1l111_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡸࡥࡥࠩ♺"),l1l111_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡰࡶࡴࡳࡰࡪ࠭♻")])
		for l111111111_l1_ in l1lllll1ll1_l1_:
			l1111lllll_l1_ = l111111111_l1_.find_all(l1l111_l1_ (u"ࠪࡰ࡮࠭♼"))[1].text
			if PY2:
				l1111lllll_l1_ = l1111lllll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♽"))
			l111111ll1_l1_.append(l1111lllll_l1_)
		if not l11111l_l1_(l1ll1_l1_,l1l111_l1_ (u"ࠬ࠭♾"),l111111ll1_l1_,False):
			l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ♿")).get(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ⚀"))
			title = block.find(l1l111_l1_ (u"ࠨࡪ࠶ࠫ⚁"))
			name = title.find(l1l111_l1_ (u"ࠩࡤࠫ⚂")).text
			l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠪࡥࠬ⚃")).get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⚄"))
			l1111l1l1l_l1_ = block.find(class_=l1l111_l1_ (u"ࠬࡴ࡯࠮࡯ࡤࡶ࡬࡯࡮ࠨ⚅"))
			l11111l111_l1_ = block.find(class_=l1l111_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭⚆"))
			if l1111l1l1l_l1_: l1111l1l1l_l1_ = l1111l1l1l_l1_.text
			if l11111l111_l1_: l11111l111_l1_ = l11111l111_l1_.text
			if PY2:
				l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚇"))
				name = name.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚈"))
				l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚉"))
				if l1111l1l1l_l1_: l1111l1l1l_l1_ = l1111l1l1l_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚊"))
			l1llllll1ll_l1_ = {}
			if l11111l111_l1_: l1llllll1ll_l1_[l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡵࠪ⚋")] = l11111l111_l1_
			if l1111l1l1l_l1_:
				l1111l1l1l_l1_ = l1111l1l1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⚌"),l1l111_l1_ (u"࠭ࠠ࠯࠰ࠣࠫ⚍"))
				l1llllll1ll_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡲࡸࠬ⚎")] = l1111l1l1l_l1_.replace(l1l111_l1_ (u"ࠨ࠰࠱࠲ฬ่ัฤࠢสุ่๊๊ะࠩ⚏"),l1l111_l1_ (u"ࠩࠪ⚐"))
			if l1l111_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪ⚑") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚒"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠬ࠭⚓"),name,l1l111_l1_ (u"࠭ࠧ⚔"),l1llllll1ll_l1_)
			elif l1l111_l1_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⚕") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚖"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠩࠪ⚗"),name,l1l111_l1_ (u"ࠪࠫ⚘"),l1llllll1ll_l1_)
	PAGINATION(l1llllll111_l1_,512)
	return
def l1111lll1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⚙"),url,l1l111_l1_ (u"ࠬ࠭⚚"),headers,l1l111_l1_ (u"࠭ࠧ⚛"),l1l111_l1_ (u"ࠧࠨ⚜"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠵࠱࠶ࡹࡴࠨ⚝"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ⚞"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(l1l111_l1_ (u"ࠪࡰ࡮࠭⚟"))
	names,items = [],[]
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠭ࡸࡴࡤࡴࡵ࡫ࡲࠨ⚠")): continue
		if not block.find(class_=[l1l111_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠧ⚡"),l1l111_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠡࡶࡨࡼࡹ࠳ࡣࡦࡰࡷࡩࡷ࠭⚢")]): continue
		if block.find(class_=l1l111_l1_ (u"ࠧࡩ࡫ࡧࡩࠬ⚣")): continue
		title = block.find(class_=[l1l111_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠪ⚤"),l1l111_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠤࡹ࡫ࡸࡵ࠯ࡦࡩࡳࡺࡥࡳࠩ⚥")])
		name = title.find(l1l111_l1_ (u"ࠪࡥࠬ⚦")).text
		if name in names: continue
		names.append(name)
		l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠫࡦ࠭⚧")).get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ⚨"))
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡸࡱࡵ࡯࠴࠭⚩") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ⚪")).get(l1l111_l1_ (u"ࠨࡵࡵࡧࠬ⚫"))
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⚬") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ⚭")).get(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭⚮"))
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⚯") in url: l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ⚰")).get(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ⚱"))
		else: l11l_l1_ = block.find(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⚲")).get(l1l111_l1_ (u"ࠩࡶࡶࡨ࠭⚳"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚴"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚵"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚶"))
		name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ⚷"))
		items.append((name,l1ll1ll_l1_,l11l_l1_))
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⚸") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1ll1ll_l1_,l11l_l1_ in items:
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ⚹") in url: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⚺"),l1lllll_l1_+name,l1ll1ll_l1_,522,l11l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⚻") in url: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚼"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠬ࠭⚽"),name)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⚾"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠧࠨ⚿"),name)
	return
def l11111lll1_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠨษ็ษ฾๊ว็ࠩ⛀"),l1l111_l1_ (u"ࠩࠪ⛁")).replace(l1l111_l1_ (u"่ࠪๆ๐ไๆࠩ⛂"),l1l111_l1_ (u"ࠫࠬ⛃")).replace(l1l111_l1_ (u"ࠬอไาี่๎ࠬ⛄"),l1l111_l1_ (u"࠭ࠧ⛅"))
	text = text.replace(l1l111_l1_ (u"ࠧฦ฻็ห๋࠭⛆"),l1l111_l1_ (u"ࠨࠩ⛇")).replace(l1l111_l1_ (u"ࠩไ๎้๋ࠧ⛈"),l1l111_l1_ (u"ࠪࠫ⛉")).replace(l1l111_l1_ (u"ࠫฬ๊ศา๊่์ࠬ⛊"),l1l111_l1_ (u"ࠬ࠭⛋"))
	text = text.replace(l1l111_l1_ (u"࠭วๅฬื์๏่๊ࠨ⛌"),l1l111_l1_ (u"ࠧࠨ⛍")).replace(l1l111_l1_ (u"ࠨๆ่ืู้ไࠨ⛎"),l1l111_l1_ (u"ࠩࠪ⛏")).replace(l1l111_l1_ (u"ุ้๊ࠪำๅࠩ⛐"),l1l111_l1_ (u"ࠫࠬ⛑"))
	text = text.replace(l1l111_l1_ (u"ࠬࡀࠧ⛒"),l1l111_l1_ (u"࠭ࠧ⛓")).replace(l1l111_l1_ (u"ࠧࠪࠩ⛔"),l1l111_l1_ (u"ࠨࠩ⛕")).replace(l1l111_l1_ (u"ࠩࠫࠫ⛖"),l1l111_l1_ (u"ࠪࠫ⛗")).replace(l1l111_l1_ (u"ࠫ࠱࠭⛘"),l1l111_l1_ (u"ࠬ࠭⛙"))
	text = text.replace(l1l111_l1_ (u"࠭࡟ࠨ⛚"),l1l111_l1_ (u"ࠧࠨ⛛")).replace(l1l111_l1_ (u"ࠨ࠽ࠪ⛜"),l1l111_l1_ (u"ࠩࠪ⛝")).replace(l1l111_l1_ (u"ࠪ࠱ࠬ⛞"),l1l111_l1_ (u"ࠫࠬ⛟")).replace(l1l111_l1_ (u"ࠬ࠴ࠧ⛠"),l1l111_l1_ (u"࠭ࠧ⛡"))
	text = text.replace(l1l111_l1_ (u"ࠧ࡝ࠩࠪ⛢"),l1l111_l1_ (u"ࠨࠩ⛣")).replace(l1l111_l1_ (u"ࠩ࡟ࠦࠬ⛤"),l1l111_l1_ (u"ࠪࠫ⛥"))
	text = text.replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ⛦"),l1l111_l1_ (u"ࠬࠦࠧ⛧")).replace(l1l111_l1_ (u"࠭ࠠࠡࠢࠪ⛨"),l1l111_l1_ (u"ࠧࠡࠩ⛩")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ⛪"),l1l111_l1_ (u"ࠩࠣࠫ⛫"))
	text = text.strip(l1l111_l1_ (u"ࠪࠤࠬ⛬"))
	l1111ll111_l1_ = text.count(l1l111_l1_ (u"ࠫࠥ࠭⛭"))+1
	if l1111ll111_l1_==1:
		l1lllllllll_l1_(text)
		return
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⛮"),l1lllll_l1_+l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࠦใๅ็สฮ๊ࠥไษฯฮࠤࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⛯"),l1l111_l1_ (u"ࠧࠨ⛰"),9999)
	l11111ll11_l1_ = text.split(l1l111_l1_ (u"ࠨࠢࠪ⛱"))
	l1111ll1l1_l1_ = pow(2,l1111ll111_l1_)
	l111l1111_l1_ = []
	def l11111l1ll_l1_(a,b):
		if a==l1l111_l1_ (u"ࠩ࠴ࠫ⛲"): return b
		return l1l111_l1_ (u"ࠪࠫ⛳")
	for l1l111llll_l1_ in range(l1111ll1l1_l1_,0,-1):
		l1111l11l1_l1_ = list(l1111ll111_l1_*l1l111_l1_ (u"ࠫ࠵࠭⛴")+bin(l1l111llll_l1_)[2:])[-l1111ll111_l1_:]
		l1111l11l1_l1_ = reversed(l1111l11l1_l1_)
		result = map(l11111l1ll_l1_,l1111l11l1_l1_,l11111ll11_l1_)
		title = l1l111_l1_ (u"ࠬࠦࠧ⛵").join(filter(None,result))
		if PY2: l1lllllll_l1_ = title.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⛶"))
		else: l1lllllll_l1_ = title
		if len(l1lllllll_l1_)>2 and title not in l111l1111_l1_:
			l111l1111_l1_.append(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⛷"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ⛸"),523,l1l111_l1_ (u"ࠩࠪ⛹"),l1l111_l1_ (u"ࠪࠫ⛺"),title)
	return
def l1lllllllll_l1_(l1111ll11l_l1_):
	if PY2:
		l1111ll11l_l1_ = l1111ll11l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⛻"))
		import arabic_reshaper
		l1111ll11l_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111ll11l_l1_)
		l1111ll11l_l1_ = bidi.algorithm.get_display(l1111ll11l_l1_)
	import l1111l1l11_l1_
	l1111ll11l_l1_ = l1llll1_l1_(default=l1111ll11l_l1_)
	l1111l1l11_l1_.l1lll1_l1_(l1111ll11l_l1_)
	return
def l1111l1ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⛼"),url,l1l111_l1_ (u"࠭ࠧ⛽"),headers,l1l111_l1_ (u"ࠧࠨ⛾"),l1l111_l1_ (u"ࠨࠩ⛿"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡎࡔࡄࡆ࡚ࡈࡗࡤࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨ✀"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ✁"),multi_valued_attributes=None)
	block = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵ࠯ࡶࡩࡵࡧࡲࡢࡶࡲࡶࠥࡲࡩࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠩ✂"))
	l11l11_l1_ = block.find_all(l1l111_l1_ (u"ࠬࡧࠧ✃"))
	items = []
	for title in l11l11_l1_:
		name = title.text
		l1ll1ll_l1_ = l111l1_l1_+title.get(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ✄"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✅"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✆"))
		if l1l111_l1_ (u"ࠩࠦࠫ✇") not in l1ll1ll_l1_: items.append((name,l1ll1ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1ll1ll_l1_ = item
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ✈"),l1lllll_l1_+name,l1ll1ll_l1_,518)
	return
def l1111l1lll_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ✉"),url,l1l111_l1_ (u"ࠬ࠭✊"),headers,l1l111_l1_ (u"࠭ࠧ✋"),l1l111_l1_ (u"ࠧࠨ✌"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡍࡓࡊࡅ࡙ࡇࡖࡣ࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ✍"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ✎"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠪࡩࡽࡶࡡ࡯ࡦࠪ✏")).find_all(l1l111_l1_ (u"ࠫࡹࡸࠧ✐"))
	for block in l1lll1l1_l1_:
		l11111ll1l_l1_ = block.find_all(l1l111_l1_ (u"ࠬࡧࠧ✑"))
		if not l11111ll1l_l1_: continue
		l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ✒")).get(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ✓"))
		name = l11111ll1l_l1_[1].text
		l1ll1ll_l1_ = l111l1_l1_+l11111ll1l_l1_[1].get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭✔"))
		l11111l111_l1_ = block.find(class_=l1l111_l1_ (u"ࠩ࡯ࡩ࡬࡫࡮ࡥࠩ✕"))
		if l11111l111_l1_: l11111l111_l1_ = l11111l111_l1_.text
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✖"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✗"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✘"))
		l1llllll1ll_l1_ = {}
		if l11111l111_l1_: l1llllll1ll_l1_[l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡷࠬ✙")] = l11111l111_l1_
		if l1l111_l1_ (u"ࠧ࠰ࡹࡲࡶࡰ࠵ࠧ✚") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✛"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠩࠪ✜"),name,l1l111_l1_ (u"ࠪࠫ✝"),l1llllll1ll_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡶࡥࡳࡵࡲࡲ࠴࠭✞") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✟"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"࠭ࠧ✠"),name,l1l111_l1_ (u"ࠧࠨ✡"),l1llllll1ll_l1_)
	PAGINATION(l1llllll111_l1_,518)
	return
def l1111l111l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ✢"),url,l1l111_l1_ (u"ࠩࠪ✣"),headers,l1l111_l1_ (u"ࠪࠫ✤"),l1l111_l1_ (u"ࠫࠬ✥"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡗࡋࡇࡉࡔ࡙࡟ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪ✦"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ✧"),multi_valued_attributes=None)
	l11l11_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡶ࡬ࡸࡱ࡫ࠠࡪࡰ࡯࡭ࡳ࡫ࠧ✨"))
	l1ll_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠨࡤࡸࡸࡹࡵ࡮ࠡࡩࡵࡩࡪࡴࠠࡴ࡯ࡤࡰࡱࠦࡲࡪࡩ࡫ࡸࠬ✩"))
	items = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in items:
		title = title.text
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ✪"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✫"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✬"))
		title = title.replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ✭"),l1l111_l1_ (u"࠭ࠠࠨ✮")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ✯"),l1l111_l1_ (u"ࠨࠢࠪ✰")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ✱"),l1l111_l1_ (u"ࠪࠤࠬ✲"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✳"),l1lllll_l1_+title,l1ll1ll_l1_,521)
	return
def l1llllll11l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ✴"),url,l1l111_l1_ (u"࠭ࠧ✵"),headers,l1l111_l1_ (u"ࠧࠨ✶"),l1l111_l1_ (u"ࠨࠩ✷"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡛ࡏࡄࡆࡑࡖࡣ࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ✸"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ✹"),multi_valued_attributes=None)
	l111l11111_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠫࡱࡧࡲࡨࡧ࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠵ࠢࡰࡩࡩ࡯ࡵ࡮࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡࡵࡰࡥࡱࡲ࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠷࠭✺"))
	l1lll1l1_l1_ = l111l11111_l1_.find_all(l1l111_l1_ (u"ࠬࡲࡩࠨ✻"))
	for block in l1lll1l1_l1_:
		title = block.find(class_=l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ✼")).text
		l1ll1ll_l1_ = l111l1_l1_+block.find(l1l111_l1_ (u"ࠧࡢࠩ✽")).get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭✾"))
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭✿")).get(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ❀"))
		l1l1lll111_l1_ = block.find(class_=l1l111_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭❁")).text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ❂"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ❃"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ❄"))
			l1l1lll111_l1_ = l1l1lll111_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭❅"))
		l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ❆"),l1l111_l1_ (u"ࠪࠫ❇")).strip(l1l111_l1_ (u"ࠫࠥ࠭❈"))
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ❉"),l1lllll_l1_+title,l1ll1ll_l1_,522,l11l_l1_,l1l1lll111_l1_)
	PAGINATION(l1llllll111_l1_,521)
	return
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ❊"),url,l1l111_l1_ (u"ࠧࠨ❋"),headers,l1l111_l1_ (u"ࠨࠩ❌"),l1l111_l1_ (u"ࠩࠪ❍"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ❎"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ❏"),multi_valued_attributes=None)
	l1ll1ll_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠬ࡬࡬ࡦࡺ࠰ࡺ࡮ࡪࡥࡰࠩ❐")).find(l1l111_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪ࠭❑")).get(l1l111_l1_ (u"ࠧࡴࡴࡦࠫ❒"))
	if PY2: l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭❓"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ❔"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ❕"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ❖"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ❗"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ❘"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡁࡴࡁࠬ❙")+search
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ❚"),url,l1l111_l1_ (u"ࠩࠪ❛"),headers,l1l111_l1_ (u"ࠪࠫ❜"),l1l111_l1_ (u"ࠫࠬ❝"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ❞"))
	if not response.succeeded:
		l11111l11l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࡟ࡦࡰࡷ࡭ࡹࡿ࠯ࡀࡳࡀࠫ❟")+search+l1l111_l1_ (u"ࠧࠧࡧࡱࡸ࡮ࡺࡹ࠾ࡹࡲࡶࡰ࠭❠")
		l111lllll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡡࡨࡲࡹ࡯ࡴࡺ࠱ࡂࡵࡂ࠭❡")+search+l1l111_l1_ (u"ࠩࠩࡩࡳࡺࡩࡵࡻࡀࡴࡪࡸࡳࡰࡰࠪ❢")
		l111111lll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡣࡪࡴࡴࡪࡶࡼ࠳ࡄࡷ࠽ࠨ❣")+search+l1l111_l1_ (u"ࠫࠫ࡫࡮ࡵ࡫ࡷࡽࡂࡼࡩࡥࡧࡲࠫ❤")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❥"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣ฽๋ࠦรฺ็ส่ࠬ❦"),l11111l11l_l1_,513,l1l111_l1_ (u"ࠧࠨ❧"),search)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❨"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะูࠦ็ࠢฦุำอีࠨ❩"),l111lllll_l1_,513,l1l111_l1_ (u"ࠪࠫ❪"),search)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❫"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢ฼๊ࠥ็๊ะ์๋๋ฬะࠧ❬"),l111111lll_l1_,513,l1l111_l1_ (u"࠭ࠧ❭"),search)
		return
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ❮"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡮ࡨࡪࡹ࠭❯"))
	for block in l1lll1l1_l1_:
		title = block.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ❰"))
		title = title.split(l1l111_l1_ (u"ࠪࠬࠬ❱"),1)[0].strip(l1l111_l1_ (u"ࠫࠥ࠭❲"))
		if   l1l111_l1_ (u"ࠬษูๆษ็ࠫ❳") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ❴"),l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ❵"))
		elif l1l111_l1_ (u"ࠨลืาฬ฻ࠧ❶") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ❷"),l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ❸"))
		elif l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯ࠭❹") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ❺"),l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ❻"))
		else: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❼"),l1lllll_l1_+title,l1ll1ll_l1_,513)
	return
def l1lllllll11_l1_(url,text):
	global l1l11111_l1_,l1l11lll_l1_
	if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ❽") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ❾"),l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨ❿"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭➀")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ➁"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ➂"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ➃")]
	elif l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ➄") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ➅"),l1l111_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ➆"),l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ➇")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ➈"),l1l111_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ➉"),l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ➊")]
	l1l1ll1l_l1_(url,text)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ➋"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭➌"),url,l1l111_l1_ (u"ࠪࠫ➍"),headers,l1l111_l1_ (u"ࠫࠬ➎"),l1l111_l1_ (u"ࠬ࠭➏"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ➐"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡧࡱࡵࡱࠥࡧࡣࡵ࡫ࡲࡲࡂࠨ࠯ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭➑"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠢࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭➒"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ➓"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ➔"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ➕"))
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ➖"),l1l111_l1_ (u"࠭࠯ࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠨࠪ➗"))
	return url
def l11l1l11ll_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ➘"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ➙")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠩࡂࠫ➚") in url: url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ➛"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ➜"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭➝"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧ➞"),l1l111_l1_ (u"ࠧࠨ➟")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ➠"))
	if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ➡"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬ➢") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭➣") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ➤")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ➥")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ➦")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ➧")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ➨"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ➩")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭➪"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ➫"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ➬")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ➭"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ➮"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ➯"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭➰"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬ➱"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ➲")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➳"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ➴"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➵"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ➶")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ➷"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ➸"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➹"),l1l111_l1_ (u"࠭ࠧ➺"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧ࠮࠯ࠪ➻"),l1l111_l1_ (u"ࠨࠩ➼"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫ➽") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭➾"):
			if l1l111ll_l1_ not in l1l11111_l1_: continue
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1111llll1_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ➿")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟀"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭⟁"),l1lllll1_l1_,511)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟂"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ⟃"),l1lllll1_l1_,515,l1l111_l1_ (u"ࠩࠪ⟄"),l1l111_l1_ (u"ࠪࠫ⟅"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ⟆"):
			if l1l111ll_l1_ not in l1l11lll_l1_: continue
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ⟇")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ⟈")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ⟉")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ⟊")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭⟋")+l1l1ll11_l1_
			if   name==l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ⟌"): name = l1l111_l1_ (u"ࠫฬ๊ๆ้฻ࠪ⟍")
			elif name==l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⟎"): name = l1l111_l1_ (u"࠭วๅ฻่่ࠬ⟏")
			elif name==l1l111_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ⟐"): name = l1l111_l1_ (u"ࠨษ็่฿ฯࠧ⟑")
			elif name==l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ⟒"): name = l1l111_l1_ (u"ࠪหู้ๆสࠩ⟓")
			elif name==l1l111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⟔"): name = l1l111_l1_ (u"ࠬอไๆ๊ึ้ࠬ⟕")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟖"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿࠺ࠡࠩ⟗")+name,l1lllll1_l1_,514,l1l111_l1_ (u"ࠨࠩ⟘"),l1l111_l1_ (u"ࠩࠪ⟙"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ฺ้ࠪ์แศฬࠣวำื้ࠨ⟚") in option: continue
			if l1l111_l1_ (u"ࠫฬ๊ใๅࠩ⟛") in option: continue
			if l1l111_l1_ (u"ࠬอไๅ฼ฬࠫ⟜") in option: continue
			option = option.replace(l1l111_l1_ (u"࠭โศศ่อࠥ࠭⟝"),l1l111_l1_ (u"ࠧࠨ⟞"))
			if   name==l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠭⟟"): name = l1l111_l1_ (u"ࠩส่๋๎ูࠨ⟠")
			elif name==l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⟡"): name = l1l111_l1_ (u"ࠫฬู๊ๆๆࠪ⟢")
			elif name==l1l111_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭⟣"): name = l1l111_l1_ (u"࠭วๅๆ฽อࠬ⟤")
			elif name==l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ⟥"): name = l1l111_l1_ (u"ࠨษ็ื๋ฯࠧ⟦")
			elif name==l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ⟧"): name = l1l111_l1_ (u"ࠪห้๋่ิ็ࠪ⟨")
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭⟩")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ⟪")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ⟫")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ⟬")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ⟭")+l1l1ll11_l1_
			if name: title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ⟮")+name
			else: title = option
			if type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⟯"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟰"),l1lllll_l1_+title,url,514,l1l111_l1_ (u"ࠬ࠭⟱"),l1l111_l1_ (u"࠭ࠧ⟲"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⟳") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ⟴") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11ll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⟵"),l1lllll_l1_+title,l1llllll_l1_,511)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟶"),l1lllll_l1_+title,url,515,l1l111_l1_ (u"ࠫࠬ⟷"),l1l111_l1_ (u"ࠬ࠭⟸"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"࠭࠽ࠧࠩ⟹"),l1l111_l1_ (u"ࠧ࠾࠲ࠩࠫ⟺"))
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠪ⟻"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠩࡀࠫ⟼") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠬ⟽"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭⟾"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭⟿")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨ⠀")
		if l1l111_l1_ (u"ࠧࠦࠩ⠁") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⠂") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ⠃"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ⠄")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⠅") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ⠆"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ⠇")+key+l1l111_l1_ (u"ࠧ࠾ࠩ⠈")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⠉"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ⠊")+key+l1l111_l1_ (u"ࠪࡁࠬ⠋")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ⠌"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ⠍"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭࠽࠱ࠩ⠎"),l1l111_l1_ (u"ࠧ࠾ࠩ⠏"))
	return l1l1l111_l1_
l1l11111_l1_ = []
l1l11lll_l1_ = []
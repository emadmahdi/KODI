# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗࠩ㮉")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㮊")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠵࠭㮋"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠷ࠧ㮌"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠲ࠨ㮍"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠴ࠩ㮎"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠨ࠶ࠪ㮏"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮐"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ㮑")+l1l111_l1_ (u"ࠫ็๎วว็ࠣๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠩ㮒"),l1l111_l1_ (u"ࠬ࠭㮓"),762)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮔"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭㮕")+l1l111_l1_ (u"ࠨไ๋หห๋ࠠโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠧ㮖"),l1l111_l1_ (u"ࠩࠪ㮗"),761)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮘"),l1l111_l1_ (u"ࠫࡤ࡚ࡖ࠱ࡡࠪ㮙")+l1l111_l1_ (u"่ࠬๆ้ษอࠤ๊์ࠠๆ๊สๆ฾ํวࠡษ็วฺ๊๊สࠩ㮚"),l1l111_l1_ (u"࠭ࠧ㮛"),101)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮜"),l1l111_l1_ (u"ࠨࡡࡗ࡚࠹ࡥࠧ㮝")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡ็ัฮฬืษࠡ็้ࠤ๏๎ส๋๊หࠫ㮞"),l1l111_l1_ (u"ࠪࠫ㮟"),106)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮠"),l1l111_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ㮡")+l1l111_l1_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㮢"),l1l111_l1_ (u"ࠧࠨ㮣"),147)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮤"),l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ㮥")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ㮦"),l1l111_l1_ (u"ࠫࠬ㮧"),148)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮨"),l1l111_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬ㮩")+l1l111_l1_ (u"ࠧࠡࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ็้ࠤ๊๎โฺ้่ࠤࠥ࠭㮪"),l1l111_l1_ (u"ࠨࠩ㮫"),28)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㮬"),l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩ㮭")+l1l111_l1_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭㮮"),l1l111_l1_ (u"ࠬ࠭㮯"),41)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㮰"),l1l111_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭㮱")+l1l111_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ㮲"),l1l111_l1_ (u"ࠩࠪ㮳"),38)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㮴"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮵"),l1l111_l1_ (u"ࠬ࠭㮶"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮷"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭㮸")+l1l111_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨ㮹"),l1l111_l1_ (u"ࠩࠪ㮺"),102)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮻"),l1l111_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪ㮼")+l1l111_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬ㮽"),l1l111_l1_ (u"࠭ࠧ㮾"),103)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮿"),l1l111_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ㯀")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪ㯁"),l1l111_l1_ (u"ࠪࠫ㯂"),104)
	return
def ITEMS(l1llll1llll_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡚ࡖࠨ㯃")+l1llll1llll_l1_+l1l111_l1_ (u"ࠬࡥࠧ㯄")
	l1ll11l11lll_l1_ = l1l11l1ll11_l1_(32)
	payload = {l1l111_l1_ (u"࠭ࡩࡥࠩ㯅"):l1l111_l1_ (u"ࠧࠨ㯆"),l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㯇"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㯈"):l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㯉"),l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㯊"):l1llll1llll_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㯋"),l111l1_l1_,payload,l1l111_l1_ (u"࠭ࠧ㯌"),l1l111_l1_ (u"ࠧࠨ㯍"),l1l111_l1_ (u"ࠨࠩ㯎"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㯏"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠪࠬࡠࡤ࠻࡝ࡴ࡟ࡲࡢ࠱࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠫ㯐"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠫࡦࡲࠧ㯑"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㯒"))
			start = start.replace(l1l111_l1_ (u"࠭ࡅ࡭ࠩ㯓"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯔"))
			start = start.replace(l1l111_l1_ (u"ࠨࡃࡏࠫ㯕"),l1l111_l1_ (u"ࠩࡄࡰࠬ㯖"))
			start = start.replace(l1l111_l1_ (u"ࠪࡉࡑ࠭㯗"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯘"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠬࡇ࡬࠮ࠩ㯙"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯚"))
			start = start.replace(l1l111_l1_ (u"ࠧࡂ࡮ࠣࠫ㯛"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㯜"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l1111l_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩࠦࠫ㯝") in source: continue
			if source!=l1l111_l1_ (u"࡙ࠪࡗࡒࠧ㯞"): name = name+l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࠡࠢࠪ㯟")+source+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㯠")
			url = source+l1l111_l1_ (u"࠭࠻࠼ࠩ㯡")+server+l1l111_l1_ (u"ࠧ࠼࠽ࠪ㯢")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠨ࠽࠾ࠫ㯣")+l1llll1llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㯤"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠫ㯥")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㯦"),l1lllll_l1_+l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㯧"),l1l111_l1_ (u"࠭ࠧ㯨"),9999)
	return
def PLAY(id):
	source,server,l1l1l1111l_l1_,l1llll1llll_l1_ = id.split(l1l111_l1_ (u"ࠧ࠼࠽ࠪ㯩"))
	url = l1l111_l1_ (u"ࠨࠩ㯪")
	l1ll11l11lll_l1_ = l1l11l1ll11_l1_(32)
	if source==l1l111_l1_ (u"ࠩࡘࡖࡑ࠭㯫"): url = l1l1l1111l_l1_
	elif source==l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㯬"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㯭")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㯮")+l1l1l1111l_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㯯"),url)
		return
	elif source==l1l111_l1_ (u"ࠧࡈࡃࠪ㯰"):
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㯱") : l1l111_l1_ (u"ࠩࠪ㯲"), l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㯳") : l1ll11l11lll_l1_ , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㯴") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠶࠭㯵") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㯶") : l1l111_l1_ (u"ࠧࠨ㯷") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㯸"),l111l1_l1_,payload,l1l111_l1_ (u"ࠩࠪ㯹"),False,l1l111_l1_ (u"ࠪࠫ㯺"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㯻"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㯼"),l1l111_l1_ (u"࠭ࠧ㯽"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㯾"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㯿"))
			return
		html = response.content
		cookies = response.cookies
		l1ll111lll1l_l1_ = cookies[l1l111_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩ࠭㰀")]
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㰁")]
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㰂") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㰃") : l1ll11l11lll_l1_ , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㰄") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠲ࠨ㰅") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㰆") : l1l111_l1_ (u"ࠩࠪ㰇") }
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ㰈") : l1l111_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤ࠾ࠩ㰉")+l1ll111lll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㰊"),l111l1_l1_,payload,headers,l1l111_l1_ (u"࠭ࠧ㰋"),l1l111_l1_ (u"ࠧࠨ㰌"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㰍"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㰎"),l1l111_l1_ (u"ࠪࠫ㰏"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㰐"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㰑"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"࠭ࡲࡦࡵࡳࠦ࠿ࠨࠨࡩࡶࡷࡴ࠳࠰࠿࡮࠵ࡸ࠼࠮࠮࠮ࠫࡁࠬࠦࠬ㰒"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1ll111lll11_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠴࠺࠱ࠫ㰓")+server+l1l111_l1_ (u"ࠨ࠹࠺࠻࠴࠭㰔")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㰕")+params
		l1ll111ll1ll_l1_ = l1ll111lll11_l1_.replace(l1l111_l1_ (u"ࠪ࠷࠻ࡀ࠷ࠨ㰖"),l1l111_l1_ (u"ࠫ࠹࠶࠺࠸ࠩ㰗")).replace(l1l111_l1_ (u"ࠬࡥࡈࡅ࠰ࡰ࠷ࡺ࠾ࠧ㰘"),l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㰙"))
		l1ll111llll1_l1_ = l1ll111lll11_l1_.replace(l1l111_l1_ (u"ࠧ࠴࠸࠽࠻ࠬ㰚"),l1l111_l1_ (u"ࠨ࠶࠵࠾࠼࠭㰛")).replace(l1l111_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㰜"),l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㰝"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠫࡍࡊࠧ㰞"),l1l111_l1_ (u"࡙ࠬࡄ࠲ࠩ㰟"),l1l111_l1_ (u"࠭ࡓࡅ࠴ࠪ㰠")]
		l1llll_l1_ = [l1ll111lll11_l1_,l1ll111ll1ll_l1_,l1ll111llll1_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠧࡏࡖࠪ㰡"):
		headers = { l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㰢") : l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㰣") }
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㰤") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㰥") : l1ll11l11lll_l1_ , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㰦") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡒ࡙࠭㰧") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㰨") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㰩"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠩࠪ㰪"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㰫"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㰬"),l1l111_l1_ (u"ࠬ࠭㰭"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㰮"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㰯"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㰰")]
		url = url.replace(l1l111_l1_ (u"ࠩࠨ࠶࠵࠭㰱"),l1l111_l1_ (u"ࠪࠤࠬ㰲"))
		url = url.replace(l1l111_l1_ (u"ࠫࠪ࠹ࡄࠨ㰳"),l1l111_l1_ (u"ࠬࡃࠧ㰴"))
		if l1l111_l1_ (u"࠭ࡌࡦࡣࡵࡲࠬ㰵") in l1l1l1111l_l1_:
			url = url.replace(l1l111_l1_ (u"ࠧࡏࡖࡑࡒ࡮ࡲࡥࠨ㰶"),l1l111_l1_ (u"ࠨࠩ㰷"))
			url = url.replace(l1l111_l1_ (u"ࠩ࡯ࡩࡦࡸ࡮ࡪࡰࡪ࠵ࠬ㰸"),l1l111_l1_ (u"ࠪࡐࡪࡧࡲ࡯࡫ࡱ࡫ࠬ㰹"))
	elif source==l1l111_l1_ (u"ࠫࡕࡒࠧ㰺"):
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㰻") : l1l1l1111l_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰼") : l1ll11l11lll_l1_ , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰽") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡖࡌࠨ㰾") , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰿") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㱀"), l111l1_l1_, payload, l1l111_l1_ (u"ࠫࠬ㱁"),False,l1l111_l1_ (u"ࠬ࠭㱂"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ㱃"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㱄"),l1l111_l1_ (u"ࠨࠩ㱅"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱆"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱇"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㱈")]
		headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㱉"):response.headers[l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㱊")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㱋"),url, l1l111_l1_ (u"ࠨࠩ㱌"),headers , l1l111_l1_ (u"ࠩࠪ㱍"),l1l111_l1_ (u"ࠪࠫ㱎"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭㱏"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㱐"),l1l111_l1_ (u"࠭ࠧ㱑"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㱒"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㱓"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㱔"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠪࡘࡆ࠭㱕"),l1l111_l1_ (u"ࠫࡋࡓࠧ㱖"),l1l111_l1_ (u"ࠬ࡟ࡕࠨ㱗"),l1l111_l1_ (u"࠭ࡗࡔ࠳ࠪ㱘"),l1l111_l1_ (u"ࠧࡘࡕ࠵ࠫ㱙"),l1l111_l1_ (u"ࠨࡔࡏ࠵ࠬ㱚"),l1l111_l1_ (u"ࠩࡕࡐ࠷࠭㱛")]:
		if source==l1l111_l1_ (u"ࠪࡘࡆ࠭㱜"): l1l1l1111l_l1_ = id
		headers = { l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㱝") : l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㱞") }
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㱟") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㱠") : l1ll11l11lll_l1_ , l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㱡") : l1l111_l1_ (u"ࠩࡳࡰࡦࡿࠧ㱢")+source , l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㱣") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㱤"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠬ࠭㱥"),l1l111_l1_ (u"࠭ࠧ㱦"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ㱧"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㱨"),l1l111_l1_ (u"ࠩࠪ㱩"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㱪"),l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㱫"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㱬")]
		if source==l1l111_l1_ (u"࠭ࡆࡎࠩ㱭"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㱮"), url, l1l111_l1_ (u"ࠨࠩ㱯"), l1l111_l1_ (u"ࠩࠪ㱰"), False,l1l111_l1_ (u"ࠪࠫ㱱"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠺ࡸ࡭࠭㱲"))
			url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㱳")]
			url = url.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ㱴"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㱵"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㱶"))
	return
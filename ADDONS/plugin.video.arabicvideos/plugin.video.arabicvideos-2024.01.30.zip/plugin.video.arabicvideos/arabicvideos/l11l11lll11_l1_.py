# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䔼"):l1l111_l1_ (u"ࠨࠩ䔽")}
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ䔾")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ䔿")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠫ࠸࠭䕀"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠬ࠷ࠧ䕁"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"࠭࠲ࠨ䕂"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠧ࠵ࠩ䕃"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䕄"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䕅")+l1lllll_l1_+l1l111_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ䕆"),l1l111_l1_ (u"ࠫࠬ䕇"),38)
	return l1l111_l1_ (u"ࠬ࠭䕈")
def CATEGORIES(url,select=l1l111_l1_ (u"࠭ࠧ䕉")):
	type = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䕊"))[3]
	if type==l1l111_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䕋"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ䕌"),headers,l1l111_l1_ (u"ࠪࠫ䕍"),l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫ䕎"))
		if select==l1l111_l1_ (u"ࠬ࠹ࠧ䕏"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡸ࡫ࡲࡪࡧࡶࡊࡴࡸ࡭ࠨ䕐"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕑"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"ࠨๅ็๎ออสࠡ็ูั่ฯࠧ䕒") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ䕓"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕔"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠫ࠹࠭䕕"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡩ࡫ࡴࡢ࡫࡯ࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡸࡁࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䕖"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䕗"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䕘"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕙"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䕚"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ䕛"),headers,l1l111_l1_ (u"ࠫࠬ䕜"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠴ࡱࡨࠬ䕝"))
		if select==l1l111_l1_ (u"࠭࠱ࠨ䕞"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡇࡦࡰࡧࡩࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ䕟"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕠"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱ࠪ䕡") + value
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ䕢"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕣"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠬ࠸ࠧ䕤"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡇࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ䕥"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䕦"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ䕧"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ䕨") + value
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕩"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠫ࠴࠭䕪"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭䕫"),headers,l1l111_l1_ (u"࠭ࠧ䕬"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ䕭"))
	if l1l111_l1_ (u"ࠨࡪࡲࡱࡪ࠭䕮") in url: type=l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ䕯")
	if type==l1l111_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䕰"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠨ࠯ࠬࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䕱"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕲"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䕳"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕴"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䕵"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䕶"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠮ࡃ࠮ࠨࠧ䕷"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䕸"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䕹"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䕺"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䕻"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠨ࠳ࠪ䕼"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠧ䕽"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࠫ䕾"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䕿") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䖀"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵ࠱࠮ࡄࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ䖁"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲ࠨ䖂"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ䖃"))
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ䖄"))
			name = title + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ䖅") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䖆"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡵ࡭࡬࡮ࡴࠩ࠰࠮ࡃ࠮ࡪࡡࡵࡣ࠰ࡶࡪࡼࡩࡷࡧ࠰ࡾࡴࡴࡥࡪࡦࡀࠦ࠹ࠨࠧ䖇"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䖈"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ࠧึใะอࠥ࠭䖉") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䖊"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䖋") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࡸ࠴࠳ࡸ࡫ࡲࡪࡧࡶࡐ࡮ࡴ࡫࠰ࠩ䖌") + url.split(l1l111_l1_ (u"ࠫ࠴࠭䖍"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䖎"),url,l1l111_l1_ (u"࠭ࠧ䖏"),headers,l1l111_l1_ (u"ࠧࠨ䖐"),l1l111_l1_ (u"ࠨࠩ䖑"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䖒"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠪࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䖓"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ䖔"),l1l111_l1_ (u"ࠬ࠵ࠧ䖕"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䖖"),url,l1l111_l1_ (u"ࠧࠨ䖗"),headers,l1l111_l1_ (u"ࠨࠩ䖘"),l1l111_l1_ (u"ࠩࠪ䖙"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䖚"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䖛"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䖜"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"࠭ࠧ䖝")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ䖞"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ䖟"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䖠"),l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䖡")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠫ࠶࠭䖢")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ䖣"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"࠭ศฮอࠣ฽๋ࠦวโๆส้ࠬ䖤") , l1l111_l1_ (u"ࠧษฯฮࠤ฾์ࠠๆี็ื้อสࠨ䖥")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥ࠳ࠠศะอีࠥอไษฯฮࠫ䖦"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࡡࠪ䖧") in options: type = l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䖨")
		elif l1l111_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࡣࠬ䖩") in options: type = l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䖪")
		else: return
	headers[l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䖫")] = l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䖬")
	data = {l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࠧ䖭"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡆࡲࡱࡦ࡯࡮ࠨ䖮"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠪ࠵ࠬ䖯"): data[l1l111_l1_ (u"ࠫ࡫ࡸ࡯࡮ࠩ䖰")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䖱"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ䖲"),data,headers,l1l111_l1_ (u"ࠧࠨ䖳"),l1l111_l1_ (u"ࠨࠩ䖴"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䖵"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䖶"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ䖷"),l1l111_l1_ (u"ࠬ࠵ࠧ䖸"))
			if l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䖹") in url: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖺"),l1lllll_l1_+l1l111_l1_ (u"ࠨใํ่๊ࠦࠧ䖻")+title,url,33)
			elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䖼") in url:
				url = url.replace(l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䖽"),l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࠪ䖾"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䖿"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ࠥ࠭䗀")+title,url+l1l111_l1_ (u"ࠧ࠰࠳ࠪ䗁"),32)
	count=re.findall(l1l111_l1_ (u"ࠨࠤࡷࡳࡹࡧ࡬ࠣ࠼ࠫ࠲࠯ࡅࠩࡾࠩ䗂"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗃"),l1l111_l1_ (u"ูࠪๆำษࠡࠩ䗄")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠫࠬ䗅"),39,l1l111_l1_ (u"ࠬ࠭䗆"),l1lll1l1l_l1_+l1l111_l1_ (u"࠭࠯ࠨ䗇")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡢࡊࡕ࠴ࡨࡊ࡯ࡷࡎ࠵ࡨࡿࡪࡈࡋ࡮࡜࡛࠵࠶ࡌ࡯ࡄ࡫ࡦࡲ࡜࠰ࡍ࡯ࡑࡺࡑࡳ࡬ࡴࡎ࠵࡚ࡰࡠ࠲ࡗࡨ࡜࡛ࡏࡿࡌ࠳ࡪ࡫ࡦࡌࡌࡕࡗ࡫࠼ࡻࡧࡍࡆ࠶ࡤࡊࡰࡿࡪࡃ࠶ࡶࡐ࠷࡚࠺ࠧ䗈")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䗉"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䗊"))
	return
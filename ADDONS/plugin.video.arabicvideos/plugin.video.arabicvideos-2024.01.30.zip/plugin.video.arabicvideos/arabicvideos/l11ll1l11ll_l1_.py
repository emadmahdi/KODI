# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ囼")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍࡔ࡟ࠨ国")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪๆ๋๎วหࠢไฺฬฬ๊สࠩ图"),l1l111_l1_ (u"ࠫๆอัิๅ๋ࠫ囿"),l1l111_l1_ (u"࡙ࠬࡨࡰࡹࠣࡱࡴࡸࡥࠨ圀")]
def l11l1ll_l1_(mode,url,text):
	if   mode==580: l1lll_l1_ = l1l1l11_l1_()
	elif mode==581: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==582: l1lll_l1_ = PLAY(url)
	elif mode==583: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==584: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==589: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ圁"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ圂"),l1l111_l1_ (u"ࠨࠩ圃"),l1l111_l1_ (u"ࠩࠪ圄"),l1l111_l1_ (u"ࠪࠫ圅"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ圆"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圇"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭圈"),l1l111_l1_ (u"ࠧࠨ圉"),589,l1l111_l1_ (u"ࠨࠩ圊"),l1l111_l1_ (u"ࠩࠪ國"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ圌"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ圍"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圎"),l1l111_l1_ (u"࠭ࠧ圏"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ圐"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ圑"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠩࠪ園"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ圓"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圔"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ圕")+l1lllll_l1_+title,l1ll1ll_l1_,584)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ圖"),url,l1l111_l1_ (u"ࠧࠨ圗"),l1l111_l1_ (u"ࠨࠩ團"),l1l111_l1_ (u"ࠩࠪ圙"),l1l111_l1_ (u"ࠪࠫ圚"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭圛"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ圜"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ圝"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭圞"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ土"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪ圠"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ圡"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ圢"),l1l111_l1_ (u"ࠬ࠭圣"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ圤"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪ圥")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圦"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭圧"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ在"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ圩"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圪"),l1l111_l1_ (u"࠭ࠧ圫"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ圬"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩ圭")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭圮"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ圯"),url,l1l111_l1_ (u"ࠫࠬ地"),l1l111_l1_ (u"ࠬ࠭圱"),l1l111_l1_ (u"࠭ࠧ圲"),l1l111_l1_ (u"ࠧࠨ圳"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ圴"))
	html = response.content
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ圵"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪ圶"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭圷"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ圸"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ圹"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ场"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ圻"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ圼"),l1l111_l1_ (u"ࠪห฿์๊สࠩ圽"),l1l111_l1_ (u"่๊๊ࠫษࠩ圾"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ圿"),l1l111_l1_ (u"࠭็ะษไࠫ址"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ坁"),l1l111_l1_ (u"ࠨ฻ิฺࠬ坂"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ坃"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ坄"),l1l111_l1_ (u"ู๊ࠫัฮ์ฬࠫ坅")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧ坆"))
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ均") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ坈")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ坉"))
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ坊") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ坋")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭坌"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ坍"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ坎"),l1lllll_l1_+title,l1ll1ll_l1_,582,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ坏") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ坐") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坑"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ坒") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坓"),l1lllll_l1_+title,l1ll1ll_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ坔"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨ坕"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ坖")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ块"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ坘"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ坙"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭坚")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ坛"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭坜"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭坝")+title,l1ll1ll_l1_,581)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵ࡫ࡳࡼࡳ࡯ࡳࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ坞"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坟"),l1lllll_l1_+l1l111_l1_ (u"ู้ࠪอ็ะหࠣห้๋า๋ัࠪ坠"),l1ll1ll_l1_,581)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ坡"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ坢"),url,l1l111_l1_ (u"࠭ࠧ坣"),l1l111_l1_ (u"ࠧࠨ坤"),l1l111_l1_ (u"ࠨࠩ坥"),l1l111_l1_ (u"ࠩࠪ坦"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭坧"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡳࡧࡶ࠮ࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭坨"),html,re.DOTALL)
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ坩"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"࠭ࠣࠨ坪"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坫"),l1lllll_l1_+title,url,583,l1l111_l1_ (u"ࠨࠩ坬"),l1l111_l1_ (u"ࠩࠪ坭"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ坮")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ坯"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ坰"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ坱")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ坲"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ坳"),l1lllll_l1_+title,l1ll1ll_l1_,582)
		else:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ坴"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ坵") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭坶")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ坷"))
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ坸"),l1lllll_l1_+title,l1ll1ll_l1_,582)
	return
def PLAY(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ坹"))
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ坺"),url,l1l111_l1_ (u"ࠩࠪ坻"),l1l111_l1_ (u"ࠪࠫ坼"),l1l111_l1_ (u"ࠫࠬ坽"),l1l111_l1_ (u"ࠬ࠭坾"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ坿"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ垀"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭垁") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ垂")+l1ll1ll_l1_
	hash = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࡬ࡦࡹࡨ࠾ࠩ垃"))[1]
	parts = hash.split(l1l111_l1_ (u"ࠫࡤࡥࠧ垄"))
	l1ll1l11l1l1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l111_l1_ (u"ࠬࡃࠧ垅"))
			if PY3: part = part.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ垆"))
			l1ll1l11l1l1_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l111_l1_ (u"ࠧ࠿ࠩ垇").join(l1ll1l11l1l1_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	if l1l111_l1_ (u"ࠨࡨࡤࡶࡸࡵ࡬ࠨ垈") not in str(l1ll_l1_):
		for l1ll1ll_l1_ in l1ll_l1_:
			title,l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠣࡁࡃࠦࠧ垉"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ垊")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ型")
			l1llll_l1_.append(l1ll1ll_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ垌"),url)
	else:
		title,l1ll1ll_l1_ = l1ll_l1_[0].split(l1l111_l1_ (u"࠭ࠠ࠾ࡀࠣࠫ垍"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ垎"),l1l111_l1_ (u"ࠨࠩ垏"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ垐"),l1l111_l1_ (u"๋ࠪีอࠠศๆไ๎ิ๐่ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็ࠩ垑")+l1l111_l1_ (u"ࠫࡡࡴࠧ垒")+l1l111_l1_ (u"ࠬ๐ัอ๋ࠣห้๋อศ๊็อ๊ࠥวฮไสࠫ垓")+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ垔")+title)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ垕"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ垖"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ垗"),l1l111_l1_ (u"ࠪ࠯ࠬ垘"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ垙")+search
	l1lll11_l1_(url)
	return
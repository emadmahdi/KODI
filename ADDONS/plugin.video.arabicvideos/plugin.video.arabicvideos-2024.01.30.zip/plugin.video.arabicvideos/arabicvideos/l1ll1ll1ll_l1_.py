# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡃࡍࡇࡄࡒࡊࡘࠧᨇ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡅࡏࡒࡤ࠭ᨈ")
l1lll11l11_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠨࡶࡨࡱࡵ࠭ᨉ"))
l1ll1111ll_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫᨊ"))
l1lll111l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬᨋ"),l1l111_l1_ (u"࡙ࠫ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨᨌ"))
l1ll11lll1_l1_ = l1llll11l1_l1_
l1ll111l11_l1_ = l1l111_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡸࡿࡳࡵࡧࡰ࠳ࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠨᨍ")
l1ll111l1l_l1_ = l1l111_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡹࡹࡴࡶࡨࡱ࠴ࡪࡲࡰࡲࡥࡳࡽ࠭ᨎ")
l1lll1111l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪᨏ")
l1lll11l1l_l1_ = l1l111_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯࡭ࡱࡪ࡫ࡪࡸࠧᨐ")
l1ll11l111_l1_ = l1l111_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰࡮ࡲ࡫ࠬᨑ")
l1ll11l11l_l1_ = l1l111_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡤࡲࡷ࠭ᨒ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1lllll1l1_l1_()
	elif mode==741: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l11_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1llll1ll1_l1_(l1ll1111ll_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1llll1ll1_l1_(l1lll111l1_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11l1ll_l1_(l1ll11lll1_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll11111l_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1ll1l1_l1_()
	elif mode==751: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l11_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l1l_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1llll1ll1_l1_(l1lll1111l_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l1l_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l111_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l11l_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1ll1lll11_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1l1lll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lllll1l1_l1_():
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1lll11l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll1111ll_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll111l1_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll1l11ll_l1_(l1ll11lll1_l1_)
	l1lll1ll11_l1_ -= 36864
	l1ll11llll_l1_ -= 1
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨓ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᨔ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᨕ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᨖ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᨗ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴᨘࠫࠪ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨙ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨚ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨛ")
	l1lllll11l_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩ᨜")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠧࠪࠩ᨝")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_
	text = l1l111_l1_ (u"ࠨࠢࠫࠫ᨞")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭᨟")+str(count)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᨠ")
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨡ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮࠢส่ัฺ๋๊ࠩᨢ")+text,l1l111_l1_ (u"࠭ࠧᨣ"),745)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨤ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᨥ"),l1l111_l1_ (u"ࠩࠪᨦ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨧ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡษ็้้็วหࠢส่๊สโหหࠪᨨ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠬ࠭ᨩ"),741)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨪ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠧᨫ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠨࠩᨬ"),742)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᨭ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠศๆุ์ึࠦวๅไา๎๊ฯࠧᨮ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠫࠬᨯ"),743)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨰ"),l1lllll_l1_+l1l111_l1_ (u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨᨱ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠧࠨᨲ"),744)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᨳ"),l1l111_l1_ (u"ࠩࠪᨴ"))
	return
def l1ll1ll1l1_l1_():
	l1llll1l11_l1_ = True if l1l111_l1_ (u"ࠪ࠳ࠬᨵ") in l1ll11ll11_l1_ else False
	if not l1llll1l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᨶ"),l1l111_l1_ (u"ࠬ࠭ᨷ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᨸ"),l1l111_l1_ (u"ฺࠧ็็๎ฮࠦส็ฺํๅࠥอไอ้สึ๋ࠥส้ใิอࠥ็โุࠢ็วัําสࠢํ์๋้ำࠡ࠰࠱ࠤํา็ศิๆࠤ้๐ำࠡ็้ࠤ๋๎ูࠡ์ู๋๊่ࠧᨹ"))
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᨺ"))
	if not l1ll11l1l1_l1_: l1ll1l1lll_l1_()
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1ll111l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll111l1l_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll1111l_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll111ll1_l1_(l1lll11l1l_l1_)
	l1lll1l1ll_l1_,l1ll1l1111_l1_ = l1ll111ll1_l1_(l1ll11l111_l1_)
	l1lll1l1l1_l1_,l1lll11ll1_l1_ = l1ll111ll1_l1_(l1ll11l11l_l1_)
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᨻ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨼ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨽ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨾ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨿ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩀ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᩁ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᩂ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᩃ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᩄ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᩅ")+str(l1ll11llll_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᩆ")
	l1ll1l1l11_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᩇ")+l1lllll111_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᩈ")+str(l1ll1l1111_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᩉ")
	l1ll1l1ll1_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᩊ")+l1lllll111_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᩋ")+str(l1lll11ll1_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᩌ")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_+l1ll1l1111_l1_+l1lll11ll1_l1_
	text = l1l111_l1_ (u"࠭ࠠࠩࠩᩍ")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᩎ")+str(count)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᩏ")
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩐ"),l1lllll_l1_+l1l111_l1_ (u"ࠪษ฾฽วยࠢิาฺฯࠠใำสลฮ่ࠦไฬสฬฮ࠭ᩑ"),l1l111_l1_ (u"ࠫࠬᩒ"),758)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩓ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯࠣห้าๅ๋฻ࠪᩔ")+text,l1l111_l1_ (u"ࠧࠨᩕ"),757)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩖ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᩗ"),l1l111_l1_ (u"ࠪࠫᩘ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩙ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬᩚ")+l1ll111lll_l1_,l1l111_l1_ (u"࠭ࠧᩛ"),751)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩜ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬᩝ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠩࠪᩞ"),752)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᩟"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ᩠ࠫ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠬ࠭ᩡ"),753)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩢ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࡧࡦࡴࠪᩣ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠨࠩᩤ"),754)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩥ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦ࡬ࡰࡩࠪᩦ")+l1ll1l1l11_l1_,l1l111_l1_ (u"ࠫࠬᩧ"),755)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩨ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡤࡲࡷ࠭ᩩ")+l1ll1l1ll1_l1_,l1l111_l1_ (u"ࠧࠨᩪ"),756)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᩫ"),l1l111_l1_ (u"ࠩࠪᩬ"))
	return
def l1ll1l1lll_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫᩭ"),l1l111_l1_ (u"ࠫࠬᩮ"),l1l111_l1_ (u"ࠬ࠭ᩯ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᩰ"),l1l111_l1_ (u"ࠧๅๅํࠤ๏฿ๅๅࠢส่ฯ์ุ๋ใࠣ฽๋ีใࠡ࠰࠱ࠤอืๆศ็ฯࠤ฾๋วะࠢหัฬาษࠡว็ํࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอ๊ࠥไๆๆไหฯ่ࠦศๆ่ะ้ีวหࠢส่ฯ๐ࠠิ๊ไࠤ๏๋ำฮ้สࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ฾฽วย๊ࠢิ์ࠦวๅำัูฮࠦวๅฤ้ࠤฤࠧࠧᩱ"))
	if l1llll111l_l1_==-1: return
	if l1llll111l_l1_:
		import subprocess
		try:
			subprocess.Popen(l1l111_l1_ (u"ࠨࡵࡸࠫᩲ"))
			l1llll11ll_l1_ = True
		except: l1llll11ll_l1_ = False
		if l1llll11ll_l1_:
			l1ll1llll1_l1_ = l1ll111l11_l1_+l1l111_l1_ (u"ࠩࠣࠫᩳ")+l1ll111l1l_l1_+l1l111_l1_ (u"ࠪࠤࠬᩴ")+l1lll1111l_l1_+l1l111_l1_ (u"ࠫࠥ࠭᩵")+l1lll11l1l_l1_+l1l111_l1_ (u"ࠬࠦࠧ᩶")+l1ll11l111_l1_+l1l111_l1_ (u"࠭ࠠࠨ᩷")+l1ll11l11l_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"ࠧࡴࡷࠣ࠱ࡨࠦࠢࡤࡪࡰࡳࡩࠦ࠭ࡓࠢ࠳࠻࠼࠽ࠠࠨ᩸")+l1ll1llll1_l1_+l1l111_l1_ (u"ࠨࠤࠪ᩹"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᩺"),l1l111_l1_ (u"ࠪࠫ᩻"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᩼"),l1l111_l1_ (u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨ᩽"))
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ᩾"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉ᩿ࠪ"))
			xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ᪀"))
		else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᪁"),l1l111_l1_ (u"ࠪࠫ᪂"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪃"),l1l111_l1_ (u"ࠬ฿ๅๅ์ฬࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤฯำสศฮࠣฬึ์วๆฮࠣࠤࡷࡵ࡯ࡵࠢࠣวํࠦࠠࡴࡷࡳࡩࡷࡻࡳࡦࡴࠣࠤศ๎ࠠࠡࡵࡸࠤࠥ๎ฬ่ษี็๊ࠥวࠡ์๋ะิࠦแ๋้๋ࠣีอࠠศๆหี๋อๅอࠢ࠱࠲ࠥษ่ࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠬ᪄"))
	return
def l1lllll111_l1_(size):
	for x in [l1l111_l1_ (u"࠭ࡂࠨ᪅"),l1l111_l1_ (u"ࠧࡌࡄࠪ᪆"),l1l111_l1_ (u"ࠨࡏࡅࠫ᪇"),l1l111_l1_ (u"ࠩࡊࡆࠬ᪈"),l1l111_l1_ (u"ࠪࡘࡇ࠭᪉")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠦࠪ࠹࠮࠲ࡨࠣࠩࡸࠨ᪊")%(size,x)
	return text
def l1ll111ll1_l1_(l1llll1111_l1_=l1l111_l1_ (u"ࠬ࠴ࠧ᪋")):
	global l1lll11111_l1_,l1lll1lll1_l1_
	l1lll11111_l1_,l1lll1lll1_l1_ = 0,0
	def l1lll111ll_l1_(l1llll1111_l1_):
		global l1lll11111_l1_,l1lll1lll1_l1_
		if os.path.exists(l1llll1111_l1_):
			if 0 and l1l111_l1_ (u"࠭ࡳࡤࡣࡱࡨ࡮ࡸࠧ᪌") in dir(os):
				for l1ll1111l1_l1_ in os.scandir(l1llll1111_l1_):
					if l1ll1111l1_l1_.l1lll1llll_l1_(follow_symlinks=False):
						l1lll111ll_l1_(l1ll1111l1_l1_.path)
					elif l1ll1111l1_l1_.l1ll1l1l1l_l1_(follow_symlinks=False):
						l1lll11111_l1_ += l1ll1111l1_l1_.stat().st_size
						l1lll1lll1_l1_ += 1
			else:
				for l1ll1111l1_l1_ in os.listdir(l1llll1111_l1_):
					l1ll111111_l1_ = os.path.abspath(os.path.join(l1llll1111_l1_,l1ll1111l1_l1_))
					if os.path.isdir(l1ll111111_l1_):
						l1lll111ll_l1_(l1ll111111_l1_)
					elif os.path.isfile(l1ll111111_l1_):
						size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
						l1lll11111_l1_ += size
						l1lll1lll1_l1_ += count
		return
	try: l1lll111ll_l1_(l1llll1111_l1_)
	except: pass
	return l1lll11111_l1_,l1lll1lll1_l1_
def l1lll1ll1l_l1_(l1ll1lllll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ᪍"),l1l111_l1_ (u"ࠨࠩ᪎"),l1l111_l1_ (u"ࠩࠪ᪏"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪐"),l1ll1lllll_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ᪑")+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊๊แࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᪒"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1ll1lllll_l1_):
		try: os.remove(l1ll1lllll_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᪓"),l1l111_l1_ (u"ࠧࠨ᪔"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪕"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᪖"),l1l111_l1_ (u"ࠪࠫ᪗"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪘"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭᪙"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ᪚"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ᪛"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ᪜"))
	return
def l1ll11111l_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ᪝"),l1l111_l1_ (u"ࠪࠫ᪞"),l1l111_l1_ (u"ࠫࠬ᪟"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪠"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืา࠭᪡")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ᪢")+l1l111_l1_ (u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧ᪣")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ᪤")+l1l111_l1_ (u"ࠪรࠦࠧࠧ᪥")+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᪦"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1lll11l11_l1_,True,False)
	l1llll1ll1_l1_(l1ll1111ll_l1_,True,False)
	l1llll1ll1_l1_(l1lll111l1_l1_,False,False)
	l1ll11l1ll_l1_(l1ll11lll1_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᪧ"),l1l111_l1_ (u"࠭ࠧ᪨"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᪩"),l1l111_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ᪪"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭᪫"),l1l111_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭᪬"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ᪭"))
	return
def l1ll1lll11_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬ࠭᪮"),l1l111_l1_ (u"࠭ࠧ᪯"),l1l111_l1_ (u"ࠧࠨ᪰"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪱"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠨ᪲")+l1l111_l1_ (u"ࠪࡠࡳ࠭᪳")+l1l111_l1_ (u"ࠫࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠡ࠰࠱ࠤࡩࡸ࡯ࡱࡤࡲࡼࠥ࠴࠮ࠡࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠥ࠴࠮ࠡ࡮ࡲ࡫࡬࡫ࡲࠡ࠰࠱ࠤࡱࡵࡧࠡ࠰࠱ࠤࡦࡴࡲࠨ᪴")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ᪵")+l1l111_l1_ (u"࠭࠿᪶ࠢࠣࠪ")+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞᪷ࠩ"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1ll111l11_l1_,False,False)
	l1llll1ll1_l1_(l1ll111l1l_l1_,False,False)
	l1llll1ll1_l1_(l1lll1111l_l1_,False,False)
	l1llll1ll1_l1_(l1lll11l1l_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l111_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l11l_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠨ᪸ࠩ"),l1l111_l1_ (u"᪹ࠩࠪ"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั᪺࠭"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ᪻"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ᪼"),l1l111_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈ᪽ࠩ"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ᪾"))
	return
def l1ll11l1ll_l1_(l1ll1lll1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨᪿࠩ"),l1l111_l1_ (u"ᫀࠩࠪ"),l1l111_l1_ (u"ࠪࠫ᫁"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᫂"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึั๋ࠥอห๊ํหฯࠦๅๅใูࠣํืࠠศๆฯ่ิࠦฟ᫃ࠢࠣࠪ")+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ᫄"))
		if l1llll111l_l1_!=1: return
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡶࡡࡵࡪ࠾ࠫ᫅"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡳࡪࡼࡨࡷࡀ࠭᫆"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡵࡧࡻࡸࡺࡸࡥ࠼ࠩ᫇"))
	conn.commit()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫ᫈"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ᫉"),l1l111_l1_ (u"᫊ࠬ࠭"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᫋"),l1l111_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᫌ"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᫍ"),l1l111_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᫎ"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ᫏"))
	return
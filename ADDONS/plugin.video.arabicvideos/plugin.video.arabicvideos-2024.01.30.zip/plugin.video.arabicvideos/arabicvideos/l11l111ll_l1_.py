# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ᎑")
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᎒"):l1l111_l1_ (u"࠭ࠧ᎓")}
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡅ࠷࡙ࡤ࠭᎔")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ᎕"),l1l111_l1_ (u"ࠩสาึ๐ࠧ᎖"),l1l111_l1_ (u"ࠪหำื้ࠨ᎗"),l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭᎘"),l1l111_l1_ (u"ࠬฮฯ้่ࠣษำะ๊ศำࠪ᎙"),l1l111_l1_ (u"࠭วโๆส้ࠬ᎚"),l1l111_l1_ (u"ࠧๆี็ื้อสࠨ᎛")]
def l11l1ll_l1_(mode,url,text):
	if   mode==420: l1lll_l1_ = l1l1l11_l1_()
	elif mode==421: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==422: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==423: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==424: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ᎜")+text)
	elif mode==425: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ᎝")+text)
	elif mode==426: l1lll_l1_ = PLAY(url)
	elif mode==427: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==429: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ᎞"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ᎟"),l1l111_l1_ (u"ࠬ࠭Ꭰ"),l1l111_l1_ (u"࠭ࠧᎡ"),l1l111_l1_ (u"ࠧࠨᎢ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᎣ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᎤ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬᎥ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᎦ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᎧ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭Ꭸ"),l1l111_l1_ (u"ࠧࠨᎩ"),429,l1l111_l1_ (u"ࠨࠩᎪ"),l1l111_l1_ (u"ࠩࠪᎫ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᎬ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎭ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨᎮ"),l1l11ll_l1_,425)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꭿ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪᎰ"),l1l11ll_l1_,424)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ꮁ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᎲ"),l1l111_l1_ (u"ࠪࠫᎳ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎴ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᎵ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᎶ"),l1l11ll_l1_,421)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᎷ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯ࠢࠫࡀࠫ࠲࠯ࡅࠩ࠽ࠩᎸ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵࠪᎹ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠪวๆ๊วๆࠢส่๋า่ๆࠩᎺ")
		elif l1l111_l1_ (u"ࠫ࠴ࡴࡥࡵࡨ࡯࡭ࡽ࠭Ꮋ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠬษแๅษ่ࠤํ๋ำๅี็หฯࠦๆ๋ฬไู่่ࠧᎼ")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮍ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᎾ")+l1lllll_l1_+title,l1ll1ll_l1_,421)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎿ"),l1lllll_l1_+l1l111_l1_ (u"ࠩๅหห๋ษࠡฬไู๏๊๊สࠩᏀ"),l1l11ll_l1_,427)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫᏁ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᏂ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭Ꮓ"),l1l111_l1_ (u"࠭ࠧᏄ"),l1l111_l1_ (u"ࠧࠨᏅ"),l1l111_l1_ (u"ࠨࠩᏆ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᏇ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࡚ࡩࡵ࡮ࡨࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠫᏈ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠫࠪ࠱࠮ࡄ࠯ࠢࠫࠢࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠫ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠫ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩᏉ"),block,re.DOTALL)
	for category,id,l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠳࡭ࡰࡸ࡬ࡩࡸ࠭Ꮚ") in l1ll1ll_l1_: title = l1l111_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭Ꮛ")
		elif l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹ࠭࡯ࡧࡷࡪࡱ࡯ࡸࠨᏌ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪᏍ")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏎ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᏏ")+l1lllll_l1_+title,l1ll1ll_l1_,421,l1l111_l1_ (u"ࠫࠬᏐ"),l1l111_l1_ (u"ࠬ࠭Ꮡ"),category+l1l111_l1_ (u"࠭ࡼࠨᏒ")+id)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨᏓ")):
	if l1l111_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫᏔ") in url: url = url.strip(l1l111_l1_ (u"ࠩ࠲ࠫᏕ"))+l1l111_l1_ (u"ࠪ࠳ࡲࡶࡡࡢ࠱ࡩࡥࡲ࡯࡬ࡺ࠱ࠪᏖ")
	items = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᏗ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᏘ"),url,l1l111_l1_ (u"࠭ࠧᏙ"),headers,l1l111_l1_ (u"ࠧࠨᏚ"),l1l111_l1_ (u"ࠨࠩᏛ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭Ꮬ"))
	html = response.content
	if not l111l1l1l_l1_ or l1l111_l1_ (u"ࠪࢀࠬᏝ") in l111l1l1l_l1_:
		if l1l111_l1_ (u"ࠫࢁ࠭Ꮮ") not in l111l1l1l_l1_: l111l1ll1_l1_ = l1l111_l1_ (u"ࠬ࠭Ꮯ")
		else: l111l1ll1_l1_ = l1l111_l1_ (u"࠭࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠰ࠩᏠ")+l111l1l1l_l1_
		l111ll11l_l1_ = False
		if l1l111_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠪᏡ") in html:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᏢ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪᏣ"),url,421,l1l111_l1_ (u"ࠪࠫᏤ"),l1l111_l1_ (u"ࠫࠬᏥ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᏦ"))
			l111ll11l_l1_ = True
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡇࡴࡴࡴࡦࡰࡷࠫᏧ"),html,re.DOTALL)
		if l11llll_l1_:
			l1l1l1l_l1_ = l11llll_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡣ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏨ"),l1l1l1l_l1_,re.DOTALL)
			for l11l1111l_l1_,l1lllllll_l1_ in l1l1111_l1_:
				l111lllll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࡵࡣࡥ࠳ࠬᏩ")+l11l1111l_l1_+l111l1ll1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫᏪ")
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏫ"),l1lllll_l1_+l1lllllll_l1_,l111lllll_l1_,421)
				l111ll11l_l1_ = True
		if l111ll11l_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᏬ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᏭ"),l1l111_l1_ (u"࠭ࠧᏮ"),9999)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᏯ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡒ࡬ࡲࡘࡲࡩࡥࡧࡵࠬ࠳࠰࠿ࠪࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠭Ᏸ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶ࠭࠴ࠪࡀࠫࡓࡥ࡬࡫ࡔࡪࡶ࡯ࡩࠬᏱ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠪࠫᏲ")
	elif l1l111_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧᏳ") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡩࡥ࡯ࡶࡨࡶ࠴࠭Ᏼ") in url:
		block = html
	elif l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨᏵ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࠭ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠫࠩ᏶"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴࠩ᏷") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡓࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠯ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠭ࠫᏸ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡄࡧࡹࡵࡲࡏࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᏹ"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡈ࡯࡭ࡢ࠶ࡸࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫᏺ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠬ࠭ᏻ")
	if not items: items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࠪࡎࡱࡹ࡭ࡪࡈ࡬ࡰࡥ࡮ࠦ࠯࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡪ࡯ࡤ࡫ࡪ࠴ࠪࡀࡄࡲࡼ࡙࡯ࡴ࡭ࡧࡌࡲ࡫ࡵ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᏼ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡱࡹ࡭ࡪࡈ࡬ࡰࡥ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩ࡮ࡣࡪࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᏽ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if not title: continue
		if l1l111_l1_ (u"ࠨࡁࡱࡩࡼࡹ࠽ࠨ᏾") in l1ll1ll_l1_: continue
		title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ᏿"),l1l111_l1_ (u"ࠪࠫ᐀"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬᐁ"),title,re.DOTALL)
		if l1l1lll_l1_ and l1l111_l1_ (u"ࠬำไใหࠪᐂ") in title:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᐃ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲ࠰ࠩᐅ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᐆ"),l1lllll_l1_+title,l1ll1ll_l1_,421,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐇ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐈ"),html,re.DOTALL)
	if l11llll_l1_ and l111l1l1l_l1_!=l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᐉ"):
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࡢࠧ࡝ࠤࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠫࡡࠨ࡝࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᐊ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨᐋ"),l1l111_l1_ (u"ࠨࠩᐌ"))
			if title!=l1l111_l1_ (u"ࠩࠪᐍ"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐎ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪᐏ")+title,l1ll1ll_l1_,421)
	l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࠯࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᐐ"),html,re.DOTALL)
	if l111llll1_l1_:
		l1ll1ll_l1_,title = l111llll1_l1_[0]
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐑ"),l1lllll_l1_+title,l1ll1ll_l1_,421)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᐒ"),url,l1l111_l1_ (u"ࠨࠩᐓ"),l1l111_l1_ (u"ࠩࠪᐔ"),l1l111_l1_ (u"ࠪࠫᐕ"),l1l111_l1_ (u"ࠫࠬᐖ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪᐗ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡓࡵࡷࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᐘ"),html,re.DOTALL)
	if l11llll_l1_:
		url = l11llll_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᐙ"),url,l1l111_l1_ (u"ࠨࠩᐚ"),l1l111_l1_ (u"ࠩࠪᐛ"),l1l111_l1_ (u"ࠪࠫᐜ"),l1l111_l1_ (u"ࠫࠬᐝ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠲࡯ࡦࠪᐞ"))
		html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡦࡣࡶࡳࡳࡹࡓࡦࡥࡷ࡭ࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪᐟ"),html,re.DOTALL)
	if l1l111_l1_ (u"ࠧ࠰ࡶࡤ࡫࠴࠭ᐠ") in url or l1l111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࠨᐡ") in url:
		l1lll11_l1_(url)
	elif l11llll_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪᐢ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤᐣ"),block,re.DOTALL)
		l11l11l11_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆࠪᐤ"),l1l111_l1_ (u"๋่ࠬิ็ࠪᐥ"),l1l111_l1_ (u"࠭ศา่ส้ั࠭ᐦ"),l1l111_l1_ (u"ࠧฮๆๅอࠬᐧ")]
		for l1ll1ll_l1_,title in items:
			if any(value in title for value in l11l11l11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐨ"),l1lllll_l1_+title,l1ll1ll_l1_,423,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᐩ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᐪ"),url,l1l111_l1_ (u"ࠫࠬᐫ"),l1l111_l1_ (u"ࠬ࠭ᐬ"),l1l111_l1_ (u"࠭ࠧᐭ"),l1l111_l1_ (u"ࠧࠨᐮ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᐯ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬᐰ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫᐱ")
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࡸ࡙ࡥࡤࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᐲ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᐳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"࠭ࠠࠨᐴ")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᐵ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᐶ"),l1lllll_l1_+l1l111_l1_ (u"ࠩิหอ฽ࠠศๆอุ฿๐ไࠨᐷ"),url,426,l1ll1l_l1_)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᐸ"),url,l1l111_l1_ (u"ࠫࠬᐹ"),headers,l1l111_l1_ (u"ࠬ࠭ᐺ"),l1l111_l1_ (u"࠭ࠧᐻ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᐼ"))
	html = response.content
	newurl = response.url
	if PY2: newurl = newurl.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᐽ"))
	l1l11ll_l1_ = l1l111l_l1_(newurl,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᐾ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡛ࠪࡦࡺࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬᐿ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤ࠴ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᑀ"),block,re.DOTALL)
		for l11l1lll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᑁ"))
			if l1l111_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬᑂ") in title.lower(): title = l1l111_l1_ (u"ࠧฯษุࠤࠬᑃ")+title
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡸࡷࡻࡣࡵࡷࡵࡩ࠴ࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ᑄ")+l11l1lll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᑅ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᑆ")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡸࠧᑇ"),l1l111_l1_ (u"ࠬ࠭ᑈ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫᑉ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢ࠲ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᑊ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᑋ"))
			if l1l111_l1_ (u"ࠩࡰࡽࡻ࡯ࡤࠨᑌ") in title.lower(): l1lllllll_l1_ = l1l111_l1_ (u"ࠪࡣࡤิวึࠩᑍ")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠫࠬᑎ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᑏ")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᑐ")+l1lllllll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪᑑ"),l1l111_l1_ (u"ࠨࠩᑒ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᑓ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫᑔ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬᑕ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧᑖ"),l1l111_l1_ (u"࠭ࠫࠨᑗ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡕࡨࡥࡷࡩࡨࡀࡳࡀࠫᑘ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨᑙ"))
	return
def l11l111l1_l1_(url):
	if l1l111_l1_ (u"ࠩࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࠫᑚ") not in url: url = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧᑛ"))
	else: url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᑜ"))[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᑝ"),url,l1l111_l1_ (u"࠭ࠧᑞ"),l1l111_l1_ (u"ࠧࠨᑟ"),l1l111_l1_ (u"ࠨࠩᑠ"),l1l111_l1_ (u"ࠩࠪᑡ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬᑢ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡒࡻ࡬ࡵ࡫ࡉ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᑣ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡎ࡯ࡷࡧࡵࡥࡧࡲࡥ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࠦࡦࡲ࡬ࠣ࠰࠭ࡃ࠭ࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᑤ"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᑥ"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᑦ"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᑧ"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᑨ"),l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡥࡨࡲࡹ࡫ࡲ࠰ࡣࡦࡸ࡮ࡵ࡮࠰ࡊࡲࡱࡪࡶࡡࡨࡧࡏࡳࡦࡪࡥࡳ࠱ࠪᑩ"))
	url = url.replace(l1l111_l1_ (u"ࠫࡂ࠭ᑪ"),l1l111_l1_ (u"ࠬ࠵ࠧᑫ")).replace(l1l111_l1_ (u"࠭ࠦࠨᑬ"),l1l111_l1_ (u"ࠧ࠰ࠩᑭ"))
	url = url+l1l111_l1_ (u"ࠨ࠱ࠪᑮ")
	return url
l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᑯ"),l1l111_l1_ (u"ࠪࡸࡾࡶࡥࡴࠩᑰ"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᑱ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ᑲ"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᑳ"),l1l111_l1_ (u"ࠧࡵࡻࡳࡩࡸ࠭ᑴ"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᑵ")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠩࡂࠫᑶ") in url: url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᑷ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᑸ"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭ᑹ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧᑺ"),l1l111_l1_ (u"ࠧࠨᑻ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬᑼ"))
	if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬᑽ"):
		if l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧᑾ") in url:
			global l1l11111_l1_
			l1l11111_l1_ = l1l11111_l1_[1:]
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠫࡂ࠭ᑿ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠬࡃࠧᒀ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨᒁ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪᒂ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪᒃ")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬᒄ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᒅ"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᒆ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧᒇ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᒈ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᒉ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᒊ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫᒋ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠪࠫᒌ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᒍ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠬ࠭ᒎ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᒏ")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᒐ"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫᒑ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠩࠪᒒ"),l1l111_l1_ (u"ࠪࠫᒓ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᒔ"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒕ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ᒖ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ᒗ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠨࠩᒘ"),l1l111_l1_ (u"ࠩࠪᒙ"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᒚ"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᒛ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒜ"),l1l111_l1_ (u"࠭ࠧᒝ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		if l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫᒞ") in url and l1l111ll_l1_==l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᒟ"): continue
		name = name.replace(l1l111_l1_ (u"ࠩ࠰࠱ࠬᒠ"),l1l111_l1_ (u"ࠪࠫᒡ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭ᒢ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᒣ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬᒤ")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᒥ"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨᒦ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠩࠪᒧ"),l1l111_l1_ (u"ࠪࠫᒨ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᒩ"))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒪ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭ᒫ"),l1lllll1_l1_,425,l1l111_l1_ (u"ࠧࠨᒬ"),l1l111_l1_ (u"ࠨࠩᒭ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬᒮ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᒯ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧᒰ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᒱ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩᒲ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᒳ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒴ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᒵ")+name,l1lllll1_l1_,424,l1l111_l1_ (u"ࠪࠫᒶ"),l1l111_l1_ (u"ࠫࠬᒷ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬᒸ"): option = l1l111_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭ᒹ")
			elif value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧᒺ"): option = l1l111_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪᒻ")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫᒼ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬᒽ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᒾ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧᒿ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪᓀ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪᓁ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪᓂ")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬᓃ")+name
			if type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᓄ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓅ"),l1lllll_l1_+title,url,424,l1l111_l1_ (u"ࠬ࠭ᓆ"),l1l111_l1_ (u"࠭ࠧᓇ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᓈ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪᓉ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᓊ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᓋ")+l11ll111_l1_
				l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓌ"),l1lllll_l1_+title,l1llllll_l1_,421,l1l111_l1_ (u"ࠬ࠭ᓍ"),l1l111_l1_ (u"࠭ࠧᓎ"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᓏ"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓐ"),l1lllll_l1_+title,url,425,l1l111_l1_ (u"ࠩࠪᓑ"),l1l111_l1_ (u"ࠪࠫᓒ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠫࡂࠬࠧᓓ"),l1l111_l1_ (u"ࠬࡃ࠰ࠧࠩᓔ"))
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠨᓕ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠧ࠾ࠩᓖ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠪᓗ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࠫᓘ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠪࠫᓙ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭ᓚ")
		if l1l111_l1_ (u"ࠬࠫࠧᓛ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᓜ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩᓝ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬᓞ")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᓟ") and value!=l1l111_l1_ (u"ࠪ࠴ࠬᓠ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᓡ")+key+l1l111_l1_ (u"ࠬࡃࠧᓢ")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪᓣ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩᓤ")+key+l1l111_l1_ (u"ࠨ࠿ࠪᓥ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭ᓦ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᓧ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧᓨ"),l1l111_l1_ (u"ࠬࡃࠧᓩ"))
	return l1l1l111_l1_
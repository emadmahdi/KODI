# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ१") : l1l111_l1_ (u"ࠧࠨ२") }
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ३")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡅࡐࡉ࡟ࠨ४")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺ้ࠪอัฺหࠪ५")]
def l11l1ll_l1_(mode,url,text):
	if   mode==350: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==351: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==352: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==353: l1lll_l1_ = PLAY(url)
	elif mode==354: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ६")+text)
	elif mode==355: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ७")+text)
	elif mode==356: l1lll_l1_ = l11llll1_l1_(url)
	elif mode==357: l1lll_l1_ = l11l11ll_l1_(url)
	elif mode==359: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_(l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧ८")):
	if l1l11l11_l1_==l1l111_l1_ (u"ࠧࠨ९"):
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭॰"),l1lllll_l1_+l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧॱ"),l1l111_l1_ (u"ࠪࠫॲ"),8)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩॳ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧॴ"),l1l111_l1_ (u"࠭ࠧॵ"),9999)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧॶ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨॷ"),l1l111_l1_ (u"ࠩࠪॸ"),359,l1l111_l1_ (u"ࠪࠫॹ"),l1l111_l1_ (u"ࠫࠬॺ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩॻ"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ॼ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪॽ"),l111l1_l1_,356)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨॾ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬॿ"),l111l1_l1_,357)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨঀ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ঁ"),l1l111_l1_ (u"ࠬ࠭ং"),9999)
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧঃ"),headers,l1l111_l1_ (u"ࠧࠨ঄"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬঅ"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࡮ࡼ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨআ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = l111l1_l1_
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪই"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ঈ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอึ๋ใࠣัิ๐หศࠩউ"),l1lllll1_l1_,351)
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡀࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬঊ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = l111l1_l1_
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧঋ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪঌ")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ঍"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠪࠫ঎"),l1l111_l1_ (u"ࠫࠬএ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧঐ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡱࡦ࡯࡮࠮ࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠪ঑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡲࡲࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ঒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨও"),l1lllll_l1_+title,l1ll1ll_l1_,351)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠩࠪঔ"): addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨক"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭খ"),l1l111_l1_ (u"ࠬ࠭গ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡦࡴࡾࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬঘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪঙ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			if title not in l11lll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨচ"),l1lllll_l1_+title,l1ll1ll_l1_,351)
	return html
def l11llll1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠩࠪছ")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠪࠫজ"),headers,l1l111_l1_ (u"ࠫࠬঝ"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩঞ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾ࡱࡥࡻ࠭ট"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧঠ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"ࠨู่๋ࠢ็ษࠨড")
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩঢ"),l1lllll_l1_+title,l1ll1ll_l1_,355)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠪࠫণ"): addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩত"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧথ"),l1l111_l1_ (u"࠭ࠧদ"),9999)
	return html
def l11l11ll_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨধ")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩন"),headers,l1l111_l1_ (u"ࠩࠪ঩"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧপ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࡯ࡣࡹࠫফ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬব"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"࠭ࠠๆใ็ฮึฯࠧভ")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧম"),l1lllll_l1_+title,l1ll1ll_l1_,354)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠨࠩয"): addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧর"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ঱"),l1l111_l1_ (u"ࠫࠬল"),9999)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭঳")):
	html = l1l1llll_l1_(l11ll11l_l1_,url,l1l111_l1_ (u"࠭ࠧ঴"),headers,True,l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭঵"))
	if type==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪশ"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧষ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩস"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡽࡲࡩ࡯࡭࠽࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪহ"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			if l1l111_l1_ (u"ࠬอไฮๆๅอࠬ঺") in title or l1l111_l1_ (u"࠭วๅฯ็ๆ์࠭঻") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡞ࡧ࠯়ࠬ"),title,re.DOTALL)
				if l1l1lll_l1_:
					title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧঽ") + l1l1lll_l1_[0][0]
					if title not in l1l1_l1_:
						addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩা"),l1lllll_l1_+title,l1ll1ll_l1_,352,l1ll1l_l1_)
						l1l1_l1_.append(title)
			elif l1l111_l1_ (u"ุ้๊ࠪำๅࠩি") in title:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫী"),l1lllll_l1_+title,l1ll1ll_l1_,352,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫু"),l1lllll_l1_+title,l1ll1ll_l1_,353,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧূ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪৃ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨৄ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ৅")+title,l1ll1ll_l1_,351)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ৆"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬে"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧৈ"),l1l111_l1_ (u"࠭ࠫࠨ৉"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ৊")+l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩো"),headers,True,l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪৌ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ษ็ั้่วหࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ্ࠧ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧৎ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in l1l1l1l1_l1_:
			if l1l111_l1_ (u"ࠬอไฮๆๅอࠬ৏") in title or l1l111_l1_ (u"࠭วๅฯ็ๆ์࠭৐") in title: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭৑"),l1lllll_l1_+title,l1ll1ll_l1_,353,l1ll1l_l1_)
	else:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡍࡨࡵ࡮ࠨ৒"))
		if html.count(l1l111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠪ৓"))>1: title = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ৔"),html,re.DOTALL)[1]
		else: title = l1l111_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪ৕")
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ৖"),l1lllll_l1_+title,url,353,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	l1l1l1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪৗ"),url,l1l111_l1_ (u"ࠧࠨ৘"),l1l111_l1_ (u"ࠨࠩ৙"),l1l111_l1_ (u"ࠩࠪ৚"),l1l111_l1_ (u"ࠪࠫ৛"),l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨড়"))
	html = l1l1l1ll_l1_.content
	l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭ঢ়"),html,re.DOTALL)
	if l11l1l11_l1_:
		l11l1l11_l1_ = l11l1l11_l1_[0]
		headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ৞"):l1l111_l1_ (u"ࠧࠨয়"),l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧৠ"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨৡ")}
		data = {l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫৢ"):l11l1l11_l1_}
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡤࡪࡱࡧ࡭࠹࡭࡮࡯࠴ࡏ࡮ࡤ࠱ࡄ࡮ࡦࡾ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡘࡣࡷࡧ࡭࠴ࡰࡩࡲࠪৣ")
		l11ll1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ৤"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"࠭ࠧ৥"),l1l111_l1_ (u"ࠧࠨ০"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ১"))
		l11l1ll1_l1_ = l11ll1ll_l1_.content
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡸࡪࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ২"),l11l1ll1_l1_,re.DOTALL)
		for l11l1lll_l1_,name in items:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ৩")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭৪")+l11l1l11_l1_+l1l111_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ৫")+l11l1lll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ৬")+name+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ৭")
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(name)
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪ৮")
		l11ll1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ৯"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠪࠫৰ"),l1l111_l1_ (u"ࠫࠬৱ"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ৲"))
		l11l1ll1_l1_ = l11ll1ll_l1_.content
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭৳"),l11l1ll1_l1_,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ৴"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ৵")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭৶")
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ৷"),url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࠨ৸"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ৹"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ৺"),l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ৻"),l1l111_l1_ (u"ࠨࡱࡵࡨࡪࡸࡢࡺࠩৼ")]
	if l1l111_l1_ (u"ࠩࡂࠫ৽") in url: url = url.split(l1l111_l1_ (u"ࠪࡃࠬ৾"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ৿"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭਀"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧਁ"),l1l111_l1_ (u"ࠧࠨਂ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬਃ"))
	if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭਄"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬਅ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭ਆ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧਇ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩਈ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩਉ")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫਊ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ਋"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ਌")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭਍"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ਎"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠿ࠨਏ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨਐ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ਑"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ਒"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡥࡱࡲࠧਓ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬਔ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬࡅࠧਕ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਖ"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠩਗ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠨࠩਘ"),l1l111_l1_ (u"ࠩ࠴ࠫਙ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪਚ"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫਛ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫਜ"),l1lllll1_l1_,351,l1l111_l1_ (u"࠭ࠧਝ"),l1l111_l1_ (u"ࠧ࠲ࠩਞ"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ਟ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫਠ"),l1l111_l1_ (u"ࠪࠫਡ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬਢ"),headers,True,l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪਣ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡧࡱࡵࡱࠥ࡯ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭ਤ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴ࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ਥ"),block,re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧਦ"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠩࡀࠫਧ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧਨ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ਩")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਪ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭ਫ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠧࠨਬ"),l1l111_l1_ (u"ࠨ࠳ࠪਭ"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਮ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪਯ"),l1lllll1_l1_,355,l1l111_l1_ (u"ࠫࠬਰ"),l1l111_l1_ (u"ࠬ࠭਱"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧਲ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩਲ਼")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ਴")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫਵ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭ਸ਼")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ਷")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਸ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠡࠩਹ")+name,l1lllll1_l1_,354,l1l111_l1_ (u"ࠧࠨ਺"),l1l111_l1_ (u"ࠨࠩ਻"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ਼") not in value: value = option
			else: value = re.findall(l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ਽"),value,re.DOTALL)[0]
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ਾ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧਿ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨੀ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩੁ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬੂ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠥ࠭੃")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠪ࠴ࠬ੄")]
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠠࠨ੅")+name
			if type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭੆"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ੇ"),l1lllll_l1_+title,url,354,l1l111_l1_ (u"ࠧࠨੈ"),l1l111_l1_ (u"ࠨࠩ੉"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭੊") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬੋ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨੌ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠬࡅ੍ࠧ")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੎"),l1lllll_l1_+title,l1llllll_l1_,351,l1l111_l1_ (u"ࠧࠨ੏"),l1l111_l1_ (u"ࠨ࠳ࠪ੐"))
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩੑ"),l1lllll_l1_+title,url,355,l1l111_l1_ (u"ࠪࠫ੒"),l1l111_l1_ (u"ࠫࠬ੓"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ੔"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ੕") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ੖"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ੗"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ੘")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠪࡧࡦࡺࠧਖ਼"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪਗ਼"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫਜ਼"),l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧੜ"),l1l111_l1_ (u"ࠧࡰࡴࡧࡩࡷࡨࡹࠨ੝")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪਫ਼")
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ੟") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ੠"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ੡")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ੢") and value!=l1l111_l1_ (u"࠭࠰ࠨ੣"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ੤")+key+l1l111_l1_ (u"ࠨ࠿ࠪ੥")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱ࠭੦"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ੧")+key+l1l111_l1_ (u"ࠫࡂ࠭੨")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ੩"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ੪"))
	return l1l1l111_l1_
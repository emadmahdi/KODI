# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ僫")
headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ僬") : l1l111_l1_ (u"ࠫࠬ僭") }
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡓࡇ࡙ࡢࠫ僮")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11lllll111l_l1_(url)
	elif mode==215: l1lll_l1_ = l11lllll11l1_l1_(url)
	elif mode==218: l1lll_l1_ = l1ll11111111_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll11111111_l1_():
	message = l1l111_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ僯")
	l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ僰"),l1l111_l1_ (u"ࠨࠩ僱"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ僲"),l1l111_l1_ (u"ࠪห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠩ僳"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僴"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ僵"),l1l111_l1_ (u"࠭ࠧ僶"),219,l1l111_l1_ (u"ࠧࠨ僷"),l1l111_l1_ (u"ࠨࠩ僸"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭價"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡖࡩ࡯ࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࡳ࡭ࡳࠬ࡬ࡪ࡯࡬ࡸࡂ࠸࠵ࠨ僺")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僻"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ僼")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ僽"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ僾"),headers,l1l111_l1_ (u"ࠨࠩ僿"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ儀"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡊ࡮ࡲࡴࡦࡴࡶࡆࡺࡺࡴࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ儁"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡪࡩࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭儂"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࠩ儃")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭億"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ儅")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ儆"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ儇"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩ儈"),l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭儉")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ儊"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭儋"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ儌")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ儍"),headers,l1l111_l1_ (u"ࠩࠪ儎"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭儏"))
	if l1l111_l1_ (u"ࠫ࡬࡫ࡴࡱࡱࡶࡸࡸ࠭儐") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ儑") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡍࡦࡦ࡬ࡥࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ儒"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ儓"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ儔"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ儕"),l1l111_l1_ (u"ࠪห฿์๊สࠩ儖"),l1l111_l1_ (u"่๊๊ࠫษࠩ儗"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ儘"),l1l111_l1_ (u"࠭็ะษไࠫ儙"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ儚"),l1l111_l1_ (u"ࠨ฻ิฺࠬ儛"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ儜"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ儝")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭儞") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧ償"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ儠"))
		if l1l111_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲ࠵ࠧ儡") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ儢"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ儣") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪห้ำไใหࠪ儤") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ儥"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ儦") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭儧"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儨"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ儩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ優"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫ儫"),l1l111_l1_ (u"ࠫࠬ儬"))
			if title!=l1l111_l1_ (u"ࠬ࠭儭"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭儮"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭儯")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ儰"),headers,l1l111_l1_ (u"ࠩࠪ儱"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ儲"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ儳"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠬ࠭儴").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ儵"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ儶"))
		title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ儷") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ儸"))[-1].replace(l1l111_l1_ (u"ࠪ࠱ࠬ儹"),l1l111_l1_ (u"ࠫࠥ࠭儺"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫ儻"),l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ儼"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ儽")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ儾"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ儿"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ兀") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭允") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ兂"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ元") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭兄"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ充"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ兆"),headers,l1l111_l1_ (u"ࠪࠫ兇"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ先"))
	if l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭光") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ兊"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ克"),headers,l1l111_l1_ (u"ࠨࠩ兌"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ免"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭兎"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ兏"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭児"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l1111l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩ兑")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ兒")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ兓")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ兔")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ兕"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ兖") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ兗"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ兘"),headers,l1l111_l1_ (u"ࠧࠨ兙"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ党"))
		id = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ兛"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l1111l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ兜"):l1l111_l1_ (u"ࠫࠬ兝") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ兞"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ兟") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪ兠")+l1l1l1111l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ兡"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ兢"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ兣"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭兤"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ入"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ兦")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ內")+l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭全")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡬࠻࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ兩"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠪࠫ兪")
					items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ八"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"ࠬࠬࠦࠨ公") + l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ六"))[2].lower() + l1l111_l1_ (u"ࠧࠧࠨࠪ兮")
						server = server.replace(l1l111_l1_ (u"ࠨ࠰ࡦࡳࡲࠬࠦࠨ兯"),l1l111_l1_ (u"ࠩࠪ兰")).replace(l1l111_l1_ (u"ࠪ࠲ࡨࡵࠦࠧࠩ共"),l1l111_l1_ (u"ࠫࠬ兲"))
						server = server.replace(l1l111_l1_ (u"ࠬ࠴࡮ࡦࡶࠩࠪࠬ关"),l1l111_l1_ (u"࠭ࠧ兴")).replace(l1l111_l1_ (u"ࠧ࠯ࡱࡵ࡫ࠫࠬࠧ兵"),l1l111_l1_ (u"ࠨࠩ其"))
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡰ࡮ࡼࡥࠧࠨࠪ具"),l1l111_l1_ (u"ࠪࠫ典")).replace(l1l111_l1_ (u"ࠫ࠳ࡵ࡮࡭࡫ࡱࡩࠫࠬࠧ兹"),l1l111_l1_ (u"ࠬ࠭兺"))
						server = server.replace(l1l111_l1_ (u"࠭ࠦࠧࡪࡧ࠲ࠬ养"),l1l111_l1_ (u"ࠧࠨ兼")).replace(l1l111_l1_ (u"ࠨࠨࠩࡻࡼࡽ࠮ࠨ兽"),l1l111_l1_ (u"ࠩࠪ兾"))
						server = server.replace(l1l111_l1_ (u"ࠪࠪࠫ࠭兿"),l1l111_l1_ (u"ࠫࠬ冀"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭冁") + name + server + l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ冂")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭冃"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ冄"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ内"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ円"),l1l111_l1_ (u"ࠫ࠰࠭冇"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ冈")+search
	l1lll11_l1_(url)
	return
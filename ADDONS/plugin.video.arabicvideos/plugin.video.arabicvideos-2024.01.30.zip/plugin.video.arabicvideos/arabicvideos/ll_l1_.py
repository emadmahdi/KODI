# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䢌")
l1l11l11l1l1_l1_ = []
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䢍"):l1l111_l1_ (u"ࠪࠫ䢎")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䢏"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ䢐")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ䢑")+type+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䢒"))
		l1l11111l1l1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䢓"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䢔"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䢕"))
		datetime = time.strftime(l1l111_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ䢖"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ䢗")+l1l11l111l1_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ䢘")+str(kodi_version)
		message = l1l111_l1_ (u"ࠧࠨ䢙")
		if key not in list(l1l11111l1l1_l1_.keys()): l1l11111l1l1_l1_[key] = [line]
		else:
			if url not in str(l1l11111l1l1_l1_[key]): l1l11111l1l1_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭䢚")
		total = 0
		for key in list(l1l11111l1l1_l1_.keys()):
			l1l11111l1l1_l1_[key] = list(set(l1l11111l1l1_l1_[key]))
			total += len(l1l11111l1l1_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䢛"),l1l111_l1_ (u"ࠪࠫ䢜"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䢝"),l1l111_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํ࠭䢞")+message+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠷ࠣๅ๏ี๊้้สฮࠬ䢟")+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䢠")+l1l111_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢไ๎ࠥอไใษษ้ฮࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠫ䢡")+str(total))
		if total>=5:
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ䢢"),l1l111_l1_ (u"ࠪࠫ䢣"),l1l111_l1_ (u"ࠫࠬ䢤"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢥"),l1l111_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧ䢦"))
			if l1llll111l_l1_==1:
				l1l11111ll11_l1_ = l1l111_l1_ (u"ࠧࠨ䢧")
				for key in list(l1l11111l1l1_l1_.keys()):
					l1l11111ll11_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱࠫ䢨")+key
					l1l11ll11l1l_l1_ = sorted(l1l11111l1l1_l1_[key],reverse=False,key=lambda l11lllllll11_l1_: l11lllllll11_l1_[0])
					for datetime,url in l1l11ll11l1l_l1_:
						l1l11111ll11_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࠬ䢩")+datetime+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ䢪")+l111l11_l1_(url)
					l1l11111ll11_l1_ += l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䢫")
				import l1l11llllll_l1_
				succeeded = l1l11llllll_l1_.l11l1l11ll1_l1_(l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡷࠬ䢬"),l1l111_l1_ (u"࠭ࠧ䢭"),False,l1l111_l1_ (u"ࠧࠨ䢮"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䢯"),l1l111_l1_ (u"ࠩࠪ䢰"),l1l11111ll11_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䢱"),l1l111_l1_ (u"ࠫࠬ䢲"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢳"),l1l111_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ䢴"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䢵"),l1l111_l1_ (u"ࠨࠩ䢶"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䢷"),l1l111_l1_ (u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨ䢸"))
			if l1llll111l_l1_!=-1:
				l1l11111l1l1_l1_ = {}
				l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䢹"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䢺"))
		if l1l11111l1l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䢻"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䢼"),l1l11111l1l1_l1_,l1ll111ll11_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11lllll11ll_l1_(l1ll11l1_l1_,source)
	l1l11lllll1l_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䢽"))
	l11llllll11l_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䢾"))
	l1l1l111l1l1_l1_ = len(l1llll_l1_)-l1l11lllll1l_l1_-l11llllll11l_l1_
	l1l1111l111l_l1_ = l1l111_l1_ (u"ู้ࠪอ็ะห࠽ࠫ䢿")+str(l1l11lllll1l_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨ䣀")+str(l11llllll11l_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨ䣁")+str(l1l1l111l1l1_l1_)
	if not l1llll_l1_: result,l1l1l111ll11_l1_ = l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䣂"),l1l111_l1_ (u"ࠧࠨ䣃")
	else:
		while True:
			l1l1l111ll11_l1_ = l1l111_l1_ (u"ࠨࠩ䣄")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l1111l111l_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠶ࡹࡴࡠ࡯ࡨࡲࡺ࠭䣅")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠪื๏ืแาࠩ䣆") in title and l1l111_l1_ (u"ࠫ࠷๋ฬ่๊็࠶ࠬ䣇") in title:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䣈"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡪࡲࡥࡤࡶࡨࡨ࡙ࠥࡥࡳࡸࡨࡶࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䣉")+title+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䣊")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ䣋"))
					import l1l11llllll_l1_
					l1l11llllll_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䣌")
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䣍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ䣎")+title+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ䣏")+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䣐"))
					result,l1l1l111ll11_l1_,l1ll11l11l1l_l1_ = l1l111lll1l1_l1_(l1ll1ll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䣑"),l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䣒"),l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䣓"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ䣔"),l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ䣕")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䣖"),l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ䣗"),l1l111_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭䣘")]: break
			elif result not in [l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䣙"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ䣚")]:
				if l1l111_l1_ (u"ࠪࡠࡳ࠭䣛") in l1l1l111ll11_l1_: l1l1l111ll11_l1_ = l1l111_l1_ (u"ࠫࡠࡒࡅࡇࡖࡠࠫ䣜")+l1l1l111ll11_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣝"),l1l111_l1_ (u"࠭࡜࡯࡝ࡏࡉࡋ࡚࡝ࠨ䣞"))
				l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣟"),l1l111_l1_ (u"ࠨࠩ䣠"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣡"),l1l111_l1_ (u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์࠭䣢")+l1l111_l1_ (u"ࠫࡡࡴࠧ䣣")+l1l1l111ll11_l1_,profile=l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪ䣤"))
	if result==l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䣥") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣦"),l1l111_l1_ (u"ࠨࠩ䣧"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣨"),l1l111_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ䣩")+l1l111_l1_ (u"ࠫࡡࡴࠧ䣪")+l1l1l111ll11_l1_,profile=l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪ䣫"))
	elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䣬"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䣭")] and l1l1l111ll11_l1_!=l1l111_l1_ (u"ࠨࠩ䣮"): l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䣯"),l1l111_l1_ (u"ࠪࠫ䣰"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䣱"),l1l1l111ll11_l1_,profile=l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪ䣲"))
	return result
def l1l111lll1l1_l1_(url,source,type=l1l111_l1_ (u"࠭ࠧ䣳")):
	url = url.strip(l1l111_l1_ (u"ࠧࠡࠩ䣴")).strip(l1l111_l1_ (u"ࠨࠨࠪ䣵")).strip(l1l111_l1_ (u"ࠩࡂࠫ䣶")).strip(l1l111_l1_ (u"ࠪ࠳ࠬ䣷"))
	l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lllll11_l1_(url,source)
	if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䣸"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ䣹"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䣺")
			else:
				l1l1l1l11ll1_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䣻"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡥ࡭ࡧࡦࡸࡪࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ䣼")+title+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ䣽")+str(l1l1l1l11ll1_l1_)+l1l111_l1_ (u"ࠪࠤࡢ࠭䣾"))
				if l1l111_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ䣿") in l1l1l1l11ll1_l1_ and l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ䤀") in l1l1l1l11ll1_l1_:
					l1l1l1l1l11l_l1_,l1l1lllll11l_l1_,l1ll11l11l1l_l1_ = l1l1111llll1_l1_(l1l1l1l11ll1_l1_)
					if l1ll11l11l1l_l1_: l1l1l1l11ll1_l1_ = l1ll11l11l1l_l1_[0]
					else: l1l1l1l11ll1_l1_ = l1l111_l1_ (u"࠭ࠧ䤁")
				if not l1l1l1l11ll1_l1_: result = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䤂")
				else: result = l1llll111_l1_(l1l1l1l11ll1_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ䤃"),l1l111_l1_ (u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ䤄"),l1l111_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ䤅")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䤆"),l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭䤇"),l1l111_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ䤈")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䤉"),l1l111_l1_ (u"ࠨࠩ䤊"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䤋"),l1l111_l1_ (u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩ䤌"))
	else:
		result = l1l111_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䤍")
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(url)
		if l11ll1l1l1_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l1l111ll11_l1_,l1llll_l1_
def l1l111ll111l_l1_(url,source):
	l1lllll1_l1_,l1l11l1ll11l_l1_,server,l11lllllll1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠬ࠭䤎"),l1l111_l1_ (u"࠭ࠧ䤏"),l1l111_l1_ (u"ࠧࠨ䤐"),l1l111_l1_ (u"ࠨࠩ䤑"),l1l111_l1_ (u"ࠩࠪ䤒"),l1l111_l1_ (u"ࠪࠫ䤓"),l1l111_l1_ (u"ࠫࠬ䤔")
	if l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䤕") in url:
		l1lllll1_l1_,l1l11l1ll11l_l1_ = url.split(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䤖"),1)
		l1l11l1ll11l_l1_ = l1l11l1ll11l_l1_+l1l111_l1_ (u"ࠧࡠࡡࠪ䤗")+l1l111_l1_ (u"ࠨࡡࡢࠫ䤘")+l1l111_l1_ (u"ࠩࡢࡣࠬ䤙")+l1l111_l1_ (u"ࠪࡣࡤ࠭䤚")
		l1l11l1ll11l_l1_ = l1l11l1ll11l_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1lll11l1111_l1_ = l1l11l1ll11l_l1_.split(l1l111_l1_ (u"ࠫࡤࡥࠧ䤛"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠬ࠭䤜"): l111l1ll_l1_ = l1l111_l1_ (u"࠭࠰ࠨ䤝")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠧࡱࠩ䤞"),l1l111_l1_ (u"ࠨࠩ䤟")).replace(l1l111_l1_ (u"ࠩࠣࠫ䤠"),l1l111_l1_ (u"ࠪࠫ䤡"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠫࡄ࠭䤢")).strip(l1l111_l1_ (u"ࠬ࠵ࠧ䤣")).strip(l1l111_l1_ (u"࠭ࠦࠨ䤤"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡩࡱࡶࡸࠬ䤥"))
	if name: l11lllllll1l_l1_ = name
	else: l11lllllll1l_l1_ = server
	l11lllllll1l_l1_ = l1l111l_l1_(l11lllllll1l_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䤦"))
	name = name.replace(l1l111_l1_ (u"่ࠩฬฬฺัࠨ䤧"),l1l111_l1_ (u"ࠪࠫ䤨")).replace(l1l111_l1_ (u"ุࠫ๐ัโำࠪ䤩"),l1l111_l1_ (u"ࠬ࠭䤪")).replace(l1l111_l1_ (u"࠭วๅࠢࠪ䤫"),l1l111_l1_ (u"ࠧࠡࠩ䤬")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䤭"),l1l111_l1_ (u"ࠩࠣࠫ䤮"))
	l1l11l1ll11l_l1_ = l1l11l1ll11l_l1_.replace(l1l111_l1_ (u"้ࠪออิาࠩ䤯"),l1l111_l1_ (u"ࠫࠬ䤰")).replace(l1l111_l1_ (u"ู๊ࠬาใิࠫ䤱"),l1l111_l1_ (u"࠭ࠧ䤲")).replace(l1l111_l1_ (u"ࠧศๆࠣࠫ䤳"),l1l111_l1_ (u"ࠨࠢࠪ䤴")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䤵"),l1l111_l1_ (u"ࠪࠤࠬ䤶"))
	l11lllllll1l_l1_ = l11lllllll1l_l1_.replace(l1l111_l1_ (u"๊ࠫฮวีำࠪ䤷"),l1l111_l1_ (u"ࠬ࠭䤸")).replace(l1l111_l1_ (u"࠭ำ๋ำไีࠬ䤹"),l1l111_l1_ (u"ࠧࠨ䤺")).replace(l1l111_l1_ (u"ࠨษ็ࠤࠬ䤻"),l1l111_l1_ (u"ࠩࠣࠫ䤼")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䤽"),l1l111_l1_ (u"ࠫࠥ࠭䤾"))
	return l1lllll1_l1_,l1l11l1ll11l_l1_,server,l11lllllll1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11llllll1_l1_(url,source):
	l1l1l11l1l1l_l1_,name,l11l1lllll1_l1_,l1l111ll11l1_l1_,l1l111ll11ll_l1_,l1l11l11l1ll_l1_,l1l1l11l111l_l1_ = l1l111_l1_ (u"ࠬ࠭䤿"),l1l111_l1_ (u"࠭ࠧ䥀"),None,None,None,None,None
	l1lllll1_l1_,l1l11l1ll11l_l1_,server,l11lllllll1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111ll111l_l1_(url,source)
	if l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䥁") in url:
		if   type==l1l111_l1_ (u"ࠨࡧࡰࡦࡪࡪࠧ䥂"): type = l1l111_l1_ (u"ࠩࠣࠫ䥃")+l1l111_l1_ (u"้ࠪๆ฼ไࠨ䥄")
		elif type==l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䥅"): type = l1l111_l1_ (u"ࠬࠦࠧ䥆")+l1l111_l1_ (u"࠭ࠥๆึส๋ิฯࠧ䥇")
		elif type==l1l111_l1_ (u"ࠧࡣࡱࡷ࡬ࠬ䥈"): type = l1l111_l1_ (u"ࠨࠢࠪ䥉")+l1l111_l1_ (u"ࠩࠨฺ๊ࠩว่ัฬࠤํะอๆ์็ࠫ䥊")
		elif type==l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䥋"): type = l1l111_l1_ (u"ࠫࠥ࠭䥌")+l1l111_l1_ (u"ࠬࠫࠥࠦฬะ้๏๊ࠧ䥍")
		elif type==l1l111_l1_ (u"࠭ࠧ䥎"): type = l1l111_l1_ (u"ࠧࠡࠩ䥏")+l1l111_l1_ (u"ࠨࠧࠨࠩࠪ࠭䥐")
		if l111lll_l1_!=l1l111_l1_ (u"ࠩࠪ䥑"):
			if l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ䥒") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠫࠪ࠭䥓")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠬࠦࠧ䥔")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"࠭ࠧ䥕"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠦࠧࠨࠩࠪࠫࠥࠦࠧࠪ䥖")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠢࠪ䥗")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䥘")		in source: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䥙")		in source: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ䥚")
	elif l1l111_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ䥛")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ䥜")	in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䥝")		in source: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ䥞")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࠨ䥟")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠪࡸ࠼ࡳࡥࡦ࡮ࠪ䥠")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ䥡")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ䥢")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ䥣")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠧโฮิࠫ䥤")			in name:   l11l1lllll1_l1_	= l1l111_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䥥")
	elif l1l111_l1_ (u"ࠩไุ่฽๊็ࠩ䥦")		in name:   l11l1lllll1_l1_	= l1l111_l1_ (u"ࠪࡴࡦࡲࡥࡴࡶ࡬ࡲࡪ࠭䥧")
	elif l1l111_l1_ (u"ࠫ࡬ࡪࡲࡪࡸࡨࠫ䥨")		in l1lllll1_l1_:   l11l1lllll1_l1_	= l1l111_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬ䥩")
	elif l1l111_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䥪")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ䥫")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䥬")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪ䥭")		in name:   l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䥮")	in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ䥯")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ䥰")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ䥱")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ䥲")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ䥳")		in server: l11l1lllll1_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ䥴")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬ䥵")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫ䥶")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ䥷")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ䥸")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ䥹")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࠧ䥺")	 	in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ䥻")
	elif l1l111_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ䥼")	 	in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ䥽")
	elif l1l111_l1_ (u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪ䥾")	in server: l11l1lllll1_l1_	= l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪ䥿")
	elif l1l111_l1_ (u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ䦀")		in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪ䦁")
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ䦂")		in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ䦃")
	elif l1l111_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䦄")		in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ䦅")
	elif l1l111_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䦆")	in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭䦇")
	elif l1l111_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ䦈")	in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩ䦉")
	elif l1l111_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䦊")		in server: l11l1lllll1_l1_	= l1l111_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ䦋")
	elif l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ䦌")	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ䦍")
	elif l1l111_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䦎")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ䦏")
	elif l1l111_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ䦐")	 	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠪࡧࡦࡺࡣࡩࠩ䦑")
	elif l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ䦒")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭䦓")
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ䦔")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭䦕")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨ࡭ࡪࠧ䦖")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠩࡰࡽࡻ࡯ࡤࠨ䦗")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠪࡱࡾࡼࡩࡪࡦࠪ䦘")		in server: l1l11l11l1ll_l1_	= l11lllllll1l_l1_
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䦙")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ䦚")
	elif l1l111_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ䦛")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠧࡨࡱࡹ࡭ࡩ࠭䦜")
	elif l1l111_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ䦝") 	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ䦞")
	elif l1l111_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䦟")	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ䦠")
	elif l1l111_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ䦡")	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫ䦢")
	elif l1l111_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ䦣") 	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䦤")
	elif l1l111_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䦥")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ䦦")
	elif l1l111_l1_ (u"ࠫࡺࡶࡰࠨ䦧") 			in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠬࡻࡰࡣࡱࡰࠫ䦨")
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࠪ䦩") 			in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭䦪")
	elif l1l111_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䦫") 		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ䦬")
	elif l1l111_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䦭") 	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭䦮")
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ䦯")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"࠭ࡶࡪࡦࡥࡳࡧ࠭䦰")
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ䦱") 		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ䦲")
	elif l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䦳") 	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ䦴")
	elif l1l111_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ䦵")	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ䦶")
	elif l1l111_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䦷")	in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ䦸")
	elif l1l111_l1_ (u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨ䦹")		in server: l1l111ll11l1_l1_	= l1l111_l1_ (u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩ䦺")
	if   l11l1lllll1_l1_:	l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"ࠪาฬ฻ࠧ䦻"),l11l1lllll1_l1_
	elif l1l11l11l1ll_l1_:		l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"๋ࠫࠪอะัࠪ䦼"),l1l11l11l1ll_l1_
	elif l1l111ll11l1_l1_:		l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪ䦽"),l1l111ll11l1_l1_
	elif l1l111ll11ll_l1_:	l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ䦾"),l1l111ll11ll_l1_
	elif l1l1l11l111l_l1_:	l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧ䦿"),l11lllllll1l_l1_
	else:			l1l1l11l1l1l_l1_,name = l1l111_l1_ (u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩ䧀"),l11lllllll1l_l1_
	return l1l1l11l1l1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11l1111ll_l1_(url,source):
	l1lllll1_l1_,l1l11l11l1ll_l1_,server,l11lllllll1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111ll111l_l1_(url,source)
	if   l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䧁")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䧂")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭䧃")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ䧄")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ䧅")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ䧆")		in source: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ䧇")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ䧈")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ䧉")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll11l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭䧊")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ䧋")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭䧌")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭䧍")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ䧎")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫ䧏")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ䧐")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭䧑")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ䧒")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1lllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ䧓")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡷࡵ࠷ࡹࠬ䧔")			in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1l11l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䧕")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllll1111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䧖")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ䧗")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨ䧘")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨ䧙")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䧚")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll11ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ䧛")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lllllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ䧜")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ䧝")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ䧞")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ䧟")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬ࠭䧠"),[l1l111_l1_ (u"࠭ࠧ䧡")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ䧢")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll1l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ䧣")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ䧤")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ䧥") 		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ䧦"),[l1l111_l1_ (u"ࠬ࠭䧧")],[l1lllll1_l1_]
	else: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䧨"),[l1l111_l1_ (u"ࠧࠨ䧩")],[l1lllll1_l1_]
	return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l1ll1l_l1_(url,source):
	l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1111_l1_(url)
	if l1llll_l1_: return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠠࡇࡣ࡬ࡰࡪࡪࠧ䧪"),[],[]
def l1l111l1ll11_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䧫"))
	l1llll_l1_ = []
	if   l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࠩ䧬")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lllll_l1_(url)
	elif l1l111_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ䧭")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lllll_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࡺࡹࡥࡳࡥࡲࠫ䧮") in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111l11l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ䧯")	in url   : l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䧰")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(url)
	elif l1l111_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䧱")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111llll1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ䧲")		in url   : l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭䧳")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䧴")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䧵")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111lll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭䧶")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭䧷")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ䧸")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䧹") 		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䧺"),[l1l111_l1_ (u"ࠫࠬ䧻")],[url]
	elif l1l111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䧼") 	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111l1l_l1_(url)
	elif l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䧽")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111l1l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ䧾") 	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l11ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ䧿")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1lll11_l1_(url)
	elif l1l111_l1_ (u"ࠩࡸࡴࡧ࠭䨀") 			in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡹࡵࡶࠧ䨁") 			in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䨂") 		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ䨃") 	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111llllll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡥࡳࡧ࠭䨄")		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ䨅") 		in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ䨆") 	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭䨇")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ䨈")	in server: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111ll1_l1_(url)
	if l1llll_l1_: return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠣࡊࡦ࡯࡬ࡦࡦࠪ䨉"),[],[]
def l1l111ll1l1l_l1_(l1l111l1l11l_l1_,url,source):
	l1l1l11l111l_l1_ = l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ䨊")
	try: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1ll1l_l1_(url,source)
	except: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࠧ䨋"),[],[]
	l1llll_l1_ = l1l111l1l111_l1_(l1llll_l1_)
	if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䨌"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ䨍") in l1l1l111ll11_l1_:
		l1l111l1l11l_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠤࠬ䨎")+l1l1l111ll11_l1_
		l1l1l11l111l_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䨏")
		try: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1ll11_l1_(url,source)
		except: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ䨐"),[],[]
		l1llll_l1_ = l1l111l1l111_l1_(l1llll_l1_)
		if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䨑"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬ䨒") in l1l1l111ll11_l1_:
			l1l111l1l11l_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠹࠺ࠡࠢࠪ䨓")+l1l1l111ll11_l1_
			l1l1l11l111l_l1_ = l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠺ࠧ䨔")
			try: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1111_l1_(url,source)
			except: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ䨕"),[],[]
			l1llll_l1_ = l1l111l1l111_l1_(l1llll_l1_)
			if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䨖"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪ䨗") in l1l1l111ll11_l1_:
				l1l111l1l11l_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠸࠿ࠦࠠࠨ䨘")+l1l1l111ll11_l1_
				l1l1l11l111l_l1_ = l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠹ࠬ䨙")
				try: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1llll_l1_(url,source)
				except: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䨚"),[],[]
				l1llll_l1_ = l1l111l1l111_l1_(l1llll_l1_)
				if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨛"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨ䨜") in l1l1l111ll11_l1_:
					l1l111l1l11l_l1_ += l1l111_l1_ (u"ࠪࡠࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠷࠽ࠤࠥ࠭䨝")+l1l1l111ll11_l1_
	return l1l1l11l111l_l1_,l1l111l1l11l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l1l111_l1_(l1l1llllll1l_l1_):
	if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䨞") in str(type(l1l1llllll1l_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1llllll1l_l1_:
			if l1l111_l1_ (u"ࠬࡹࡴࡳࠩ䨟") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ䨠"),l1l111_l1_ (u"ࠧࠨ䨡")).replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䨢"),l1l111_l1_ (u"ࠩࠪ䨣")).strip(l1l111_l1_ (u"ࠪࠤࠬ䨤"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1llllll1l_l1_.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ䨥"),l1l111_l1_ (u"ࠬ࠭䨦")).replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䨧"),l1l111_l1_ (u"ࠧࠨ䨨")).strip(l1l111_l1_ (u"ࠨࠢࠪ䨩"))
	return l1ll_l1_
def l1l11lllll11_l1_(url,source):
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䨪"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䨫")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ䨬"))
	l1ll1ll_l1_,l1l111l1l11l_l1_ = url,l1l111_l1_ (u"ࠬ࠭䨭")
	l1l1l11l111l_l1_ = l1l111_l1_ (u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䨮")
	try: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1111ll_l1_(url,source)
	except: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䨯"),[l1l111_l1_ (u"ࠨࠩ䨰")],[url]
	if l1l1l111ll11_l1_==l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䨱"): return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l1l111ll11_l1_==l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䨲"):
		l1l111l1l11l_l1_ = l1l111_l1_ (u"ࠫࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭䨳")
		l1ll1ll_l1_ = l1l111l1l111_l1_(l1llll_l1_)[0]
		l1l1l11l111l_l1_,l1l111l1l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1l1l_l1_(l1l111l1l11l_l1_,l1ll1ll_l1_,source)
	elif l1l1l111ll11_l1_: l1l111l1l11l_l1_ = l1l111_l1_ (u"ࠬࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥ࠭䨴")+l1l1l111ll11_l1_
	if l1llll_l1_:
		l1llll_l1_ = l1l111l1l111_l1_(l1llll_l1_)
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䨵"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ䨶")+l1l1l11l111l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䨷")+url+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䨸")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭䨹")+str(l1llll_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠧ䨺"))
	else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䨻"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䨼")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䨽")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ䨾")+l1l111l1l11l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䨿"))
	l1l111l1l11l_l1_ = l111l11_l1_(l1l111l1l11l_l1_)
	return l1l111l1l11l_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lllll11ll_l1_(l1ll11l11l1l_l1_,source):
	l1l1l1l1ll1_l1_ = l1ll1ll1_l1_
	data = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䩀"),l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩁"),l1ll11l11l1l_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l11l1ll111_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1ll11l11l1l_l1_:
		if l1l111_l1_ (u"ࠬ࠵࠯ࠨ䩂") not in l1ll1ll_l1_: continue
		l1l1l11l1l1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l11llllll1_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ䩃"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䩄"))
		l1l11l1ll111_l1_.append([l1l1l11l1l1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l11l1ll111_l1_:
		l1l111l1l1ll_l1_ = sorted(l1l11l1ll111_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11lll_l1_ = []
		for line in l1l111l1l1ll_l1_:
			if line not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(line)
		for l1l1l11l1l1l_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11lll_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䩅")
			title = l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䩆")+l1l111_l1_ (u"ࠪࠤࠬ䩇")+type+l1l111_l1_ (u"ࠫࠥ࠭䩈")+l1l1l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠧ䩉")+l111l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䩊")+l111lll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䩋")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠨࠢࠪ䩌")+server
			title = title.replace(l1l111_l1_ (u"ࠩࠨࠫ䩍"),l1l111_l1_ (u"ࠪࠫ䩎")).strip(l1l111_l1_ (u"ࠫࠥ࠭䩏")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䩐"),l1l111_l1_ (u"࠭ࠠࠨ䩑")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䩒"),l1l111_l1_ (u"ࠨࠢࠪ䩓")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䩔"),l1l111_l1_ (u"ࠪࠤࠬ䩕"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩖"),l1ll11l11l1l_l1_,data,l1l1l1l1ll1_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l1l111ll1111_l1_(url,source):
	l111l11ll11_l1_ = l1l111_l1_ (u"ࠬ࠭䩗")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l111l11ll11_l1_ = str(error)
	if not l1lll_l1_:
		if l111l11ll11_l1_==l1l111_l1_ (u"࠭ࠧ䩘"):
			l111l11ll11_l1_ = traceback.format_exc()
			if l111l11ll11_l1_!=l1l111_l1_ (u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ䩙"): sys.stderr.write(l111l11ll11_l1_)
		l1l1l111ll11_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠺ࠠࡇࡣ࡬ࡰࡪࡪࠧ䩚")
		l1l1l111ll11_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䩛")+l111l11ll11_l1_.splitlines()[-1]
		return l1l1l111ll11_l1_,[],[]
	return l1l111_l1_ (u"ࠪࠫ䩜"),[l1l111_l1_ (u"ࠫࠬ䩝")],[l1lll_l1_]
def l1l111l1llll_l1_(url,source):
	l111l11ll11_l1_ = l1l111_l1_ (u"ࠬ࠭䩞")
	l1lll_l1_ = False
	try:
		import youtube_dl as l1l1111lllll_l1_
		l1l11ll1l111_l1_ = l1l1111lllll_l1_.YoutubeDL({l1l111_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ䩟"): True})
		l1lll_l1_ = l1l11ll1l111_l1_.extract_info(url,download=False)
	except Exception as error: l111l11ll11_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䩠") not in list(l1lll_l1_.keys()):
		if l111l11ll11_l1_==l1l111_l1_ (u"ࠨࠩ䩡"):
			l111l11ll11_l1_ = traceback.format_exc()
			if l111l11ll11_l1_!=l1l111_l1_ (u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ䩢"): sys.stderr.write(l111l11ll11_l1_)
		l1l1l111ll11_l1_ = l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠶ࠢࡉࡥ࡮ࡲࡥࡥࠩ䩣")
		l1l1l111ll11_l1_ += l1l111_l1_ (u"ࠫࠥ࠭䩤")+l111l11ll11_l1_.splitlines()[-1]
		return l1l1l111ll11_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭䩥")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹ࠭䩦")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䩧")])
		return l1l111_l1_ (u"ࠨࠩ䩨"),l1l1lll1_l1_,l1llll_l1_
def l1l11ll11l11_l1_(url):
	if l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䩩") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠪࠫ䩪"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࠴ࡗ࠻ࠫ䩫"),[],[]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䩬"),[l1l111_l1_ (u"࠭ࠧ䩭")],[url]
def l1ll11lll1l_l1_(url):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪ䩮") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䩯"),url,l1l111_l1_ (u"ࠩࠪ䩰"),l1l111_l1_ (u"ࠪࠫ䩱"),False,l1l111_l1_ (u"ࠫࠬ䩲"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧ䩳"))
		if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䩴") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䩵")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䩶"))
			l111llll11_l1_.append(server)
	elif l1l111_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ䩷") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䩸"),url,l1l111_l1_ (u"ࠫࠬ䩹"),l1l111_l1_ (u"ࠬ࠭䩺"),l1l111_l1_ (u"࠭ࠧ䩻"),l1l111_l1_ (u"ࠧࠨ䩼"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪ䩽"))
		html = response.content
		l11111lllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ䩾"),html,re.DOTALL)
		if l11111lllll_l1_:
			l11111lllll_l1_ = l11111lllll_l1_[0]
			l1lll111ll1l_l1_ = l1lll1l1l1ll_l1_(l11111lllll_l1_)
			l1lll1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨ䩿"),l1lll111ll1l_l1_,re.DOTALL)
			if l1lll1111l1l_l1_:
				l1lll1111l1l_l1_ = l1lll1111l1l_l1_[0]
				l1lll1111l1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䪀"),l1lll1111l1l_l1_)
				for dict in l1lll1111l1l_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠪ䪁")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"࠭࡬ࡢࡤࡨࡰࠬ䪂")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䪃"))
					l111llll11_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠨࠢࠪ䪄")+server)
		elif l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䪅") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䪆")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䪇"))
			l111llll11_l1_.append(server)
		if l1l111_l1_ (u"ࠬࡅࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࡲࡳࠬ䪈") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"࠭࠿ࡶࡴ࡯ࡁࠬ䪉"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧࠩ䪊"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111llll11_l1_.append(l1l111_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳࠡࡩࡲࡳ࡬ࡲࡥࠨ䪋"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䪌"))
		l111llll11_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ䪍"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ䪎"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䪏"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䪐"),[l1l111_l1_ (u"ࠧࠨ䪑")],[l1ll1ll_l1_]
def l1l11111l11l_l1_(url):
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䪒"):l1l111_l1_ (u"ࠩࡎࡳࡩ࡯࠯ࠨ䪓")+str(kodi_version)}
	for l1l111llll_l1_ in range(50):
		time.sleep(0.100)
		response = l111l11lll1_l1_(l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䪔"),url,l1l111_l1_ (u"ࠫࠬ䪕"),headers,False,l1l111_l1_ (u"ࠬ࠭䪖"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪ䪗"))
		if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪘") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䪙")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ䪚")+headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䪛")]
			return l1l111_l1_ (u"ࠫࠬ䪜"),[l1l111_l1_ (u"ࠬ࠭䪝")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘࠬ䪞"),[],[]
def l1l11l11lll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪟"),url,l1l111_l1_ (u"ࠨࠩ䪠"),l1l111_l1_ (u"ࠩࠪ䪡"),l1l111_l1_ (u"ࠪࠫ䪢"),l1l111_l1_ (u"ࠫࠬ䪣"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫ䪤"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ䪥"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠧࠨ䪦"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩ䪧"),[],[]
def l1llll1ll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䪨"),url,l1l111_l1_ (u"ࠪࠫ䪩"),l1l111_l1_ (u"ࠫࠬ䪪"),l1l111_l1_ (u"ࠬ࠭䪫"),l1l111_l1_ (u"࠭ࠧ䪬"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࠷ࡳࡵࠩ䪭"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䪮"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࠪ䪯"),[l1l111_l1_ (u"ࠪࠫ䪰")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ䪱"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ䪲") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䪳"),url,l1l111_l1_ (u"ࠧࠨ䪴"),l1l111_l1_ (u"ࠨࠩ䪵"),l1l111_l1_ (u"ࠩࠪ䪶"),l1l111_l1_ (u"ࠪࠫ䪷"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅ࠹࡛࠭࠲ࡵࡷࠫ䪸"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䪹"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䪺") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䪻"),[l1l111_l1_ (u"ࠨࠩ䪼")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂ࠶ࡘࠫ䪽"),[],[]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪾"),[l1l111_l1_ (u"ࠫࠬ䪿")],[url]
def l111l111ll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䫀"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䫁"),l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䫂"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䫃")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䫄"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䫅"),l1l111_l1_ (u"ࠫࠬ䫆"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡓࡕࡗ࠮࠳ࡶࡸࠬ䫇"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䫈"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡔࡏࡘࠩ䫉"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫊"),[l1l111_l1_ (u"ࠩࠪ䫋")],[l1ll1ll_l1_]
def l1ll1l1lllll_l1_(url):
	headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䫌"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䫍")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䫎"),url,l1l111_l1_ (u"࠭ࠧ䫏"),headers,l1l111_l1_ (u"ࠧࠨ䫐"),l1l111_l1_ (u"ࠨࠩ䫑"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡑࡉࡔࡗࡕ࠭࠲ࡵࡷࠫ䫒"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫓"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡑࡒࡊࡕࡘࡏࠨ䫔"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫕"),[l1l111_l1_ (u"࠭ࠧ䫖")],[l1ll1ll_l1_]
def l1ll1lll1l1_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䫗"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䫘")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䫙"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䫚"),l1l111_l1_ (u"ࠫࠬ䫛"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡊࡄࡐࡆࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ䫜"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ䫝"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡋࡅࡑࡇࡃࡊࡏࡄࠫ䫞"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䫟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䫠")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䫡"),[l1l111_l1_ (u"ࠫࠬ䫢")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䫣"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䫤")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫥"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䫦"),l1l111_l1_ (u"ࠩࠪ䫧"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬ䫨"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ䫩"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡆࡈࡄࡐࠩ䫪"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䫫"),[l1l111_l1_ (u"ࠧࠨ䫬")],[l1ll1ll_l1_]
def l1111l1ll1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䫭"),url,l1l111_l1_ (u"ࠩࠪ䫮"),l1l111_l1_ (u"ࠪࠫ䫯"),l1l111_l1_ (u"ࠫࠬ䫰"),l1l111_l1_ (u"ࠬ࠭䫱"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬ䫲"))
	html = response.content
	l11lllllllll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䫳"),html,re.DOTALL|re.IGNORECASE)
	if l11lllllllll_l1_:
		l11lllllllll_l1_ = l11lllllllll_l1_[0][2:]
		l11lllllllll_l1_ = base64.b64decode(l11lllllllll_l1_)
		if PY3: l11lllllllll_l1_ = l11lllllllll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䫴"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䫵"),l11lllllllll_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪࠫ䫶")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡔࡗࡈࡘࡒࠬ䫷"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䫸") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䫹")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䫺"),[l1l111_l1_ (u"ࠨࠩ䫻")],[l1ll1ll_l1_]
def l1l1l111l1ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䫼"),url,l1l111_l1_ (u"ࠪࠫ䫽"),l1l111_l1_ (u"ࠫࠬ䫾"),l1l111_l1_ (u"ࠬ࠭䫿"),l1l111_l1_ (u"࠭ࠧ䬀"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩ䬁"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬂"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭䬃"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䬄"),[l1l111_l1_ (u"ࠫࠬ䬅")],[l1ll1ll_l1_]
def l1l1l111l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䬆"))[-1]
	if l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭䬇") in url: url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ䬈"),l1l111_l1_ (u"ࠨࠩ䬉"))
	url = url.replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࠨ䬊"),l1l111_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡯ࡨࡸࡦࡪࡡࡵࡣ࠲ࠫ䬋"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䬌"),url,l1l111_l1_ (u"ࠬ࠭䬍"),l1l111_l1_ (u"࠭ࠧ䬎"),l1l111_l1_ (u"ࠧࠨ䬏"),l1l111_l1_ (u"ࠨࠩ䬐"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ䬑"))
	html = response.content
	l1l1l111ll11_l1_ = l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ䬒")
	error = re.findall(l1l111_l1_ (u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䬓"),html,re.DOTALL)
	if error: l1l1l111ll11_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬔"),html,re.DOTALL)
	if not url and l1l1l111ll11_l1_:
		return l1l1l111ll11_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"࠭࡜࡝ࠩ䬕"),l1l111_l1_ (u"ࠧࠨ䬖"))
	l1l1lllll11l_l1_,l1ll11l11l1l_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼ࡾࠦ࡮ࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡷࡨࡸࡥࡦࡰࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬗"),html,re.DOTALL)
	if owner: l1l11ll1l11l_l1_,l1l11ll11lll_l1_,l1l1l11llll1_l1_ = owner[0]
	else: l1l11ll1l11l_l1_,l1l11ll11lll_l1_,l1l1l11llll1_l1_ = l1l111_l1_ (u"ࠩࠪ䬘"),l1l111_l1_ (u"ࠪࠫ䬙"),l1l111_l1_ (u"ࠫࠬ䬚")
	l1l1l11llll1_l1_ = l1l1l11llll1_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ䬛"),l1l111_l1_ (u"࠭࠯ࠨ䬜"))
	l1l11ll11lll_l1_ = escapeUNICODE(l1l11ll11lll_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ䬝")+l1l11ll11lll_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䬞")]+l1l1lllll11l_l1_
	l1llll_l1_ = [l1l1l11llll1_l1_]+l1ll11l11l1l_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪ䬟")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠪࠤ๊๊แࠪࠩ䬠"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䬡"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠷࠴࠷ࠬࡵࡳ࡮ࡀࠫ䬢")+l1l1l11llll1_l1_+l1l111_l1_ (u"࠭ࠦࡵࡧࡻࡸࡂ࠭䬣")+l1l11ll11lll_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ䬤")+new_path+l1l111_l1_ (u"ࠣࠫࠥ䬥"))
		return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䬦"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠪࠫ䬧"),[l1l111_l1_ (u"ࠫࠬ䬨")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䬩"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䬪"),l1l111_l1_ (u"ࠧࠨ䬫"),l1l111_l1_ (u"ࠨࠩ䬬"),l1l111_l1_ (u"ࠩࠪ䬭"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩ䬮"))
	html = response.content
	if l1l111_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪ䬯") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䬰"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䬱"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨ䬲"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䬳") not in url: url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䬴")+url
	return l1l111_l1_ (u"ࠪࠫ䬵"),[l1l111_l1_ (u"ࠫࠬ䬶")],[url]
def l1l1111llll1_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䬷") : l1l111_l1_ (u"࠭ࠧ䬸") }
	if l1l111_l1_ (u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ䬹") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䬺"),headers,l1l111_l1_ (u"ࠩࠪ䬻"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ䬼"))
		items = re.findall(l1l111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬽"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠬ࠭䬾"),[l1l111_l1_ (u"࠭ࠧ䬿")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䭀"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䭁"),l1l111_l1_ (u"ࠩࠪ䭂"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไศื็๎ࠬ䭃"),message[0])
				return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࠬ䭄")+message[0],[],[]
	else:
		l11111111l_l1_ = l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠨ䭅")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䭆"),headers,l1l111_l1_ (u"ࠧࠨ䭇"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦࠪ䭈"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䭉"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䭊"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠫ࠳ࡸࡡࡳࠩ䭋") in block or l1l111_l1_ (u"ࠬ࠴ࡺࡪࡲࠪ䭌") in block: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫ䭍"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䭎"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠨࠩ䭏"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫ䭐"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨ䭑"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ䭒"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬ䭓"),block,re.DOTALL)
		l1l1l111l111_l1_,l1l1lll1_l1_,l1l111lll11l_l1_,l1llll_l1_,l1l111ll1l11_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䭔") in l1ll1ll_l1_:
				l1l1l111l111_l1_,l1l111lll11l_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l1l111lll11l_l1_
				if l1l1l111l111_l1_[0]==l1l111_l1_ (u"ࠧ࠮࠳ࠪ䭕"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭䭖")+l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ䭗")+l11111111l_l1_)
				else:
					for title in l1l1l111l111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ䭘")+l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ䭙")+l11111111l_l1_+l1l111_l1_ (u"ࠬࠦࠧ䭚")+title)
			else:
				title = title.replace(l1l111_l1_ (u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨ䭛"),l1l111_l1_ (u"ࠧࠨ䭜"))
				title = title.strip(l1l111_l1_ (u"ࠨࠤࠪ䭝"))
				title = l1l111_l1_ (u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨ䭞")+l1l111_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ䭟")+l11111111l_l1_+l1l111_l1_ (u"ࠫࠥ࠭䭠")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ䭡") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䭢"),headers,l1l111_l1_ (u"ࠧࠨ䭣"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪ䭤"))
		items = re.findall(l1l111_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨ䭥"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧ䭦")+l1l111_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ䭧")+l11111111l_l1_+l1l111_l1_ (u"ࠬࠦࠧ䭨")+resolution.split(l1l111_l1_ (u"࠭ࡸࠨ䭩"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ䭪")+id+l1l111_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ䭫")+mode+l1l111_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ䭬")+hash
			l1l111ll1l11_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l1l111ll1l11_l1_ = set(l1l111ll1l11_l1_)
		l1l11l1l111l_l1_,l1l1l1l11l11_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥ䭭"),title+l1l111_l1_ (u"ࠫࠫࠬࠧ䭮"),re.DOTALL)
			for resolution in l1l111ll1l11_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠬࡾࠧ䭯"))[1])
			l1l11l1l111l_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢ䭰"),l1l111_l1_ (u"ࠧࠧࠨࠪ䭱")+l1l11l1l111l_l1_[i]+l1l111_l1_ (u"ࠨࠨࠩࠫ䭲"),re.DOTALL)
			l1l1l1l11l11_l1_.append( [l1l11l1l111l_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l1l1l11l11_l1_ = sorted(l1l1l1l11l11_l1_, key=lambda x: x[3], reverse=True)
		l1l1l1l11l11_l1_ = sorted(l1l1l1l11l11_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l1l1l11l11_l1_)):
			l1l1lll1_l1_.append(l1l1l1l11l11_l1_[i][0])
			l1llll_l1_.append(l1l1l1l11l11_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䭳"),[],[]
	return l1l111_l1_ (u"ࠪࠫ䭴"),l1l1lll1_l1_,l1llll_l1_
def l11lllll1ll1_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠫࡄ࠭䭵"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䭶") : l1l111_l1_ (u"࠭ࠧ䭷") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䭸"),headers,l1l111_l1_ (u"ࠨࠩ䭹"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩ䭺"))
	items = re.findall(l1l111_l1_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ䭻"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䭼"),[l1l111_l1_ (u"ࠬ࠭䭽")],[url]
def l1l1l1111lll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䭾") : l1l111_l1_ (u"ࠧࠨ䭿") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ䮀"),headers,l1l111_l1_ (u"ࠩࠪ䮁"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ䮂"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䮃"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠬ࠭䮄"),[l1l111_l1_ (u"࠭ࠧ䮅")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪ䮆"),[],[]
def l11llllll1ll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䮇") : l1l111_l1_ (u"ࠩࠪ䮈") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ䮉"),headers,l1l111_l1_ (u"ࠫࠬ䮊"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ䮋"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩ䮌"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠧࠨ䮍"),[l1l111_l1_ (u"ࠨࠩ䮎")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ䮏"),[],[]
def l1lllll1111_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠪࠫ䮐")
	if l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ䮑") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䮒"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䮓")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䮔"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䮕"),l1l111_l1_ (u"ࠩࠪ䮖"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠵ࡲࡩ࠭䮗"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䮘")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࡠ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛ࠨࠤࡠࠫࠬ࠭䮙"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡃࠨ࠯ࠬࡂ࠭ࡠࠬࠤ࡞ࠩ䮚"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠧࠨ䮛"),[l1l111_l1_ (u"ࠨࠩ䮜")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴ࡫ࡴ࠱ࠪ䮝") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䮞"),url,l1l111_l1_ (u"ࠫࠬ䮟"),l1l111_l1_ (u"ࠬ࠭䮠"),True,l1l111_l1_ (u"࠭ࠧ䮡"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠱ࡴࡶࠪ䮢"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䮣") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䮤")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䮥"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠫ࠴ࡼ࠯ࠨ䮦") in l1lllll1_l1_ or l1l111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䮧") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡧ࠱ࠪ䮨"),l1l111_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭䮩"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䮪"),l1l111_l1_ (u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ䮫"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䮬"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䮭"),l1l111_l1_ (u"ࠬ࠭䮮"),l1l111_l1_ (u"࠭ࠧ䮯"),l1l111_l1_ (u"ࠧࠨ䮰"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ䮱"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䮲"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭䮳"),l1l111_l1_ (u"ࠫࠬ䮴"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䮵"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ䮶"),l1l111_l1_ (u"ࠧࠨ䮷"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨࠩ䮸"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䮹"),[l1l111_l1_ (u"ࠪࠫ䮺")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ䮻"),[],[]
	return l1l111_l1_ (u"ࠬ࠭䮼"),l1l1lll1_l1_,l1llll_l1_
def l11l1l11l1l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䮽"),url,l1l111_l1_ (u"ࠧࠨ䮾"),l1l111_l1_ (u"ࠨࠩ䮿"),l1l111_l1_ (u"ࠩࠪ䯀"),l1l111_l1_ (u"ࠪࠫ䯁"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠲ࡵࡷࠫ䯂"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠬ࠭䯃")
	if l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ䯄") in url or l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ䯅") in url:
		if l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ䯆") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯇"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ䯈") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䯉"),[l1l111_l1_ (u"ࠬ࠭䯊")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䯋"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䯌"),l1l111_l1_ (u"ࠨࠩ䯍"),l1l111_l1_ (u"ࠩࠪ䯎"),l1l111_l1_ (u"ࠪࠫ䯏"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠳ࡰࡧࠫ䯐"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴࡰࡳࠨ䯑"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯒"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1lllll11111_l1_ in items:
				l1l1lll1_l1_.append(l1lllll11111_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡤࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩ䯓") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬ䯔"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䯕"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䯖"),l1l111_l1_ (u"ࠫࠬ䯗"),l1l111_l1_ (u"ࠬ࠭䯘"),l1l111_l1_ (u"࠭ࠧ䯙"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠷ࡷࡪࠧ䯚"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䯛"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࠪ䯜"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡲࡩ࡯࡭ࠪ䯝") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡩࡥ࡯ࡶࡨࡶࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯞"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䯟"),[l1l111_l1_ (u"࠭ࠧ䯠")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓ࡛࡙࠴ࡖࠩ䯡"),[],[]
	return l1l111_l1_ (u"ࠨࠩ䯢"),l1l1lll1_l1_,l1llll_l1_
def l1111ll11_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ䯣")][0]
	headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䯤"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯥"),url,l1l111_l1_ (u"ࠬ࠭䯦"),headers,l1l111_l1_ (u"࠭ࠧ䯧"),l1l111_l1_ (u"ࠧࠨ䯨"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠲࡯ࡦࠪ䯩"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䯪"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯫"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠩࠫ࠲࠯ࡅࠩࠨࠤ䯬"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦ䯭"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䯮")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠧࠨ䯯"),[l1l111_l1_ (u"ࠨࠩ䯰")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠩ䯱") in html:
		l1l11ll1111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯲"),html,re.DOTALL)
		if l1l11ll1111l_l1_:
			l1ll1ll_l1_ = l1l11ll1111l_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䯳"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ䯴"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࠮ࠪ䯵"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䯶")+l1l11l11_l1_
				return l1l111_l1_ (u"ࠨࠩ䯷"),[l1l111_l1_ (u"ࠩࠪ䯸")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䯹"),[l1l111_l1_ (u"ࠫࠬ䯺")],[url]
def l111llll1l_l1_(url):
	l111llll11_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠬ࠵࠱࠰ࠩ䯻") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"࠭࠯࠲࠱ࠪ䯼"),l1l111_l1_ (u"ࠧ࠰࠶࠲ࠫ䯽"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯾"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䯿"),l1l111_l1_ (u"ࠪࠫ䰀"),False,l1l111_l1_ (u"ࠫࠬ䰁"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠵ࡸࡺࠧ䰂"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡥࡧࡲࡂࠬ䰃"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰄"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䰅"))
					l111llll11_l1_.append(server+l1l111_l1_ (u"ࠩࠣࠤࠬ䰆")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠪࠫ䰇"),l111llll11_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠫ࠴ࡪ࠯ࠨ䰈") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰉"),url,l1l111_l1_ (u"࠭ࠧ䰊"),l1l111_l1_ (u"ࠧࠨ䰋"),l1l111_l1_ (u"ࠨࠩ䰌"),l1l111_l1_ (u"ࠩࠪ䰍"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠴ࡱࡨࠬ䰎"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰏"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠬ࠵࠱࠰ࠩ䰐"),l1l111_l1_ (u"࠭࠯࠵࠱ࠪ䰑"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䰒"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䰓"),l1l111_l1_ (u"ࠩࠪ䰔"),False,l1l111_l1_ (u"ࠪࠫ䰕"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠶ࡶࡩ࠭䰖"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰗"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䰘"),[l1l111_l1_ (u"ࠧࠨ䰙")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ䰚"),[],[]
def l111ll11ll_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䰛"),url,l1l111_l1_ (u"ࠪࠫ䰜"),l1l111_l1_ (u"ࠫࠬ䰝"),l1l111_l1_ (u"ࠬ࠭䰞"),l1l111_l1_ (u"࠭ࠧ䰟"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠷ࡳࡵࠩ䰠"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠨࠤࡤࡧࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰡"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠩࡲࡴࡂ࠭䰢")+op+l1l111_l1_ (u"ࠪࠪ࡮ࡪ࠽ࠨ䰣")+id+l1l111_l1_ (u"ࠫࠫ࡬࡮ࡢ࡯ࡨࡁࠬ䰤")+fname
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䰥"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䰦")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䰧"),url,data,headers,l1l111_l1_ (u"ࠨࠩ䰨"),l1l111_l1_ (u"ࠩࠪ䰩"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠴ࡱࡨࠬ䰪"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸࡥࡧࡧࡵࡩࡷࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰫"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䰬"),[l1l111_l1_ (u"࠭ࠧ䰭")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ䰮"),[],[]
def l11l11ll11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䰯"),1)[0].strip(l1l111_l1_ (u"ࠩࡂࠫ䰰")).strip(l1l111_l1_ (u"ࠪ࠳ࠬ䰱")).strip(l1l111_l1_ (u"ࠫࠫ࠭䰲"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠬ࠭䰳")
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䰴"):l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠧ䰵") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䰶"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䰷"),headers,True,l1l111_l1_ (u"ࠪࠫ䰸"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠳ࡶࡸࠬ䰹"))
	if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䰺") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䰻")]
	if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䰼") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䰽") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡪ࠴࠭䰾"),l1l111_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䰿"))
		l1l11l1l1ll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭䱀"))[1]
		headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䱁"):headers[l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䱂")] , l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ䱃"):l1l111_l1_ (u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩ䱄")+l1l11l1l1ll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䱅"),l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ䱆"),headers,False,l1l111_l1_ (u"ࠫࠬ䱇"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䱈"))
		html = response.content
		if l1l111_l1_ (u"࠭࠯ࡧ࠱ࠪ䱉") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠵ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱊"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䱋") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱌"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠪࠫ䱍")],[ items[0] ]
		elif l1l111_l1_ (u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪ䱎") in html:
			return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้หๆหำ้ฮࠥอไฯษุอࠥฮใࠨ䱏"),[],[]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕࠩ䱐"),[],[]
def l11l1111l11_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䱑"),l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䱒"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䱓")+l11l1l11_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ䱔")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱕"):l1l111_l1_ (u"ࠬ࠭䱖") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䱗"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䱘") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䱙"),headers,l1l111_l1_ (u"ࠩࠪ䱚"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩ䱛"))
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䱜"),[l1l111_l1_ (u"ࠬ࠭䱝")],[l1lllll1_l1_]
def l1llll11ll1l_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䱞"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䱟"):server,l1l111_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ䱠"):l1l111_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ䱡")}
	response = l11l1l_l1_(l1llll11l111_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䱢"),url,l1l111_l1_ (u"ࠫࠬ䱣"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䱤"),l1l111_l1_ (u"࠭ࠧ䱥"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ䱦"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ䱧"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠩࠪ䱨")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䱩"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ䱪"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬ࠭䱫"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱬"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡈࡏࡍࡂࠩ䱭"),[],[]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䱮"),[l1l111_l1_ (u"ࠩࠪ䱯")],[l1lllll1_l1_]
def l1ll1lllllll_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䱰"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䱱"):server,l1l111_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䱲"):l1l111_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭䱳")}
	response = l11l1l_l1_(l1llll11l111_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱴"),url,l1l111_l1_ (u"ࠨࠩ䱵"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䱶"),l1l111_l1_ (u"ࠪࠫ䱷"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡇࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ䱸"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭䱹"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"࠭ࠧ䱺")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱻"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䱼"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࠪ䱽"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱾"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡆࡅࡌࡑࡆ࠭䱿"),[],[]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䲀"),[l1l111_l1_ (u"࠭ࠧ䲁")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䲂"),l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䲃"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ䲄"):l11l1l11_l1_,l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ䲅"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䲆"),url,data,l1l111_l1_ (u"ࠬ࠭䲇"),l1l111_l1_ (u"࠭ࠧ䲈"),l1l111_l1_ (u"ࠧࠨ䲉"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪ䲊"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䲋"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲌"),[l1l111_l1_ (u"ࠫࠬ䲍")],[l1lllll1_l1_]
def l11111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲎"),url,l1l111_l1_ (u"࠭ࠧ䲏"),l1l111_l1_ (u"ࠧࠨ䲐"),l1l111_l1_ (u"ࠨࠩ䲑"),l1l111_l1_ (u"ࠩࠪ䲒"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭䲓"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲔"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䲕"),[l1l111_l1_ (u"࠭ࠧ䲖")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ䲗"),[],[]
def l11111l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䲘"),url,l1l111_l1_ (u"ࠩࠪ䲙"),l1l111_l1_ (u"ࠪࠫ䲚"),l1l111_l1_ (u"ࠫࠬ䲛"),l1l111_l1_ (u"ࠬ࠭䲜"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ䲝"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲞"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䲟"),[l1l111_l1_ (u"ࠩࠪ䲠")],[l1ll1ll_l1_]
def l1lllllll1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䲡"))
	if l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ䲢") in url:
		headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䲣"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲤"),url,l1l111_l1_ (u"ࠧࠨ䲥"),headers,l1l111_l1_ (u"ࠨࠩ䲦"),l1l111_l1_ (u"ࠩࠪ䲧"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ䲨"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䲩"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭䲪") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䲫"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䲬"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䲭"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䲮"),headers,l1l111_l1_ (u"ࠪࠫ䲯"),l1l111_l1_ (u"ࠫࠬ䲰"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䲱"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲲"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䲳"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䲴")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠩࠪ䲵"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲶"),[l1l111_l1_ (u"ࠫࠬ䲷")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䲸")+l11l11111_l1_
	return l1l111_l1_ (u"࠭ࠧ䲹"),[l1l111_l1_ (u"ࠧࠨ䲺")],[l1lllll1_l1_]
def l1l111l11lll_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䲻"))
	if l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ䲼") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䲽"),l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䲾"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ䲿"):l11l1l11_l1_,l1l111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭䳀"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䳁"),url,data,l1l111_l1_ (u"ࠨࠩ䳂"),l1l111_l1_ (u"ࠩࠪ䳃"),l1l111_l1_ (u"ࠪࠫ䳄"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ䳅"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䳆"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䳇") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䳈"):l11l11111_l1_,l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䳉"):l1l111_l1_ (u"ࠩࠪ䳊")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䳋"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䳌"),headers,l1l111_l1_ (u"ࠬ࠭䳍"),l1l111_l1_ (u"࠭ࠧ䳎"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ䳏"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳐"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䳑"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䳒")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠫࠬ䳓"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䳔"),[l1l111_l1_ (u"࠭ࠧ䳕")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䳖")+l11l11111_l1_
		return l1l111_l1_ (u"ࠨࠩ䳗"),[l1l111_l1_ (u"ࠩࠪ䳘")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ䳙") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䳚"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䳛"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳜"))
		url = host+l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ䳝")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ䳞")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䳟"):l1l111_l1_ (u"ࠪࠫ䳠") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䳡"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䳢") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䳣"),headers,l1l111_l1_ (u"ࠧࠨ䳤"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ䳥"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ䳦"),l1l111_l1_ (u"ࠪࠫ䳧")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ䳨"),l1l111_l1_ (u"ࠬ࠭䳩"))
		return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䳪"),[l1l111_l1_ (u"ࠧࠨ䳫")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ䳬") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭䳭") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䳮"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䳯"),l1l111_l1_ (u"ࠬ࠭䳰"),l1l111_l1_ (u"࠭ࠧ䳱"),l1l111_l1_ (u"ࠧࠨ䳲"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪ䳳"))
			if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䳴") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䳵")]
			counts += 1
		return l1l111_l1_ (u"ࠫࠬ䳶"),[l1l111_l1_ (u"ࠬ࠭䳷")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ䳸"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䳹"))
	headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䳺"):server,l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䳻"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ䳼") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䳽"),headers,l1l111_l1_ (u"ࠬ࠭䳾"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨ䳿"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䴀"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䴁"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䴂"))
			return l1l111_l1_ (u"ࠪࠫ䴃"),[l1l111_l1_ (u"ࠫࠬ䴄")],[l1ll1ll_l1_]
	else:
		l1l1l1111111_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䴅"),url,l1l111_l1_ (u"࠭ࠧ䴆"),headers,l1l111_l1_ (u"ࠧࠨ䴇"),l1l111_l1_ (u"ࠨࠩ䴈"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ䴉"))
		html = l1l1l1111111_l1_.content
		l1ll1ll1l_l1_ = headers.copy()
		if l1l111_l1_ (u"ࠪࡣࡱࡴ࡫ࡠࠩ䴊") in str(l1l1l1111111_l1_.cookies):
			cookies = l1l1l1111111_l1_.cookies
			l1ll1ll1l_l1_[l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䴋")] = l111l11_l1_(l1lllll11_l1_(cookies))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ䴌"),html,re.DOTALL)
		if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䴍"),[l1l111_l1_ (u"ࠧࠨ䴎")],[url]
		else:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠨࠨࡧࡁ࠶࠭䴏")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䴐"),l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䴑"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ䴒"),l1l111_l1_ (u"ࠬ࠭䴓"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠹ࡺࡨࠨ䴔"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡧࡺ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䴕"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				if l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠬ䴖") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࠲ࡨ࠴࠭䴗") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࠫ䴘"),[l1l111_l1_ (u"ࠫࠬ䴙")],[l1ll1ll_l1_]
				else: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䴚"),[l1l111_l1_ (u"࠭ࠧ䴛")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫ䴜"),[],[]
def l1ll1llll11l_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬ䴝") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䴞"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䴟")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䴠"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䴡"),headers,l1l111_l1_ (u"࠭ࠧ䴢"),l1l111_l1_ (u"ࠧࠨ䴣"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪ䴤"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䴥"),[l1l111_l1_ (u"ࠪࠫ䴦")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ䴧"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠬࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䴨"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䴩"))
		url = server+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ䴪")
		data = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ䴫"):l11l1l11_l1_,l1l111_l1_ (u"ࠩ࡬ࠫ䴬"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䴭"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䴮"),l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䴯"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䴰"),url,data,headers,l1l111_l1_ (u"ࠧࠨ䴱"),l1l111_l1_ (u"ࠨࠩ䴲"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫ䴳"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴴"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴵"),[l1l111_l1_ (u"ࠬ࠭䴶")],[l1lllll1_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ䴷"),[],[]
def l1l11l1111l1_l1_(l1l11111111l_l1_):
	l1l11l1lllll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ䴸"))
	headers = {l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䴹"):l1l11l1lllll_l1_} if l1l11l1lllll_l1_ else l1l111_l1_ (u"ࠩࠪ䴺")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䴻"),l1l11111111l_l1_,l1l111_l1_ (u"ࠫࠬ䴼"),headers,l1l111_l1_ (u"ࠬ࠭䴽"),l1l111_l1_ (u"࠭ࠧ䴾"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠵ࡸࡺࠧ䴿"))
	l1l11ll11ll1_l1_ = response.content
	l1l1l11l1111_l1_ = str(response.headers)
	l11lllll1lll_l1_ = l1l1l11l1111_l1_+l1l11ll11ll1_l1_
	if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䵀") in l11lllll1lll_l1_: found = True
	else:
		l1l111l11ll1_l1_,token,l11llllll1l1_l1_,l1l111lll111_l1_,found = l1l111_l1_ (u"ࠩࠪ䵁"),l1l111_l1_ (u"ࠪࠫ䵂"),l1l111_l1_ (u"ࠫࠬ䵃"),l1l111_l1_ (u"ࠬ࠭䵄"),False
		l1l1111lll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠴ࠪࡀࡣࡦࡸ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶ࡭ࡹ࡫࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䵅"),l1l11ll11ll1_l1_,re.DOTALL)
		if l1l1111lll11_l1_: l11llllll1l1_l1_,l1l111lll111_l1_ = l1l1111lll11_l1_[0]
		l1l1111lll1l_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ䵆")][7]
		l1ll11l11lll_l1_ = l1l11l1ll11_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭䵇"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ䵈"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䵉"):l1l11111111l_l1_,l1l111_l1_ (u"ࠫࡰ࡫ࡹࠨ䵊"):l1l111lll111_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࠨ䵋"):l1l111_l1_ (u"࠭ࠧ䵌"),l1l111_l1_ (u"ࠧ࡫ࡱࡥࠫ䵍"):l1l111_l1_ (u"ࠨࡩࡨࡸࡺࡸ࡬ࡴࠩ䵎")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䵏"),l1l1111lll1l_l1_,data,l1l111_l1_ (u"ࠪࠫ䵐"),l1l111_l1_ (u"ࠫࠬ䵑"),l1l111_l1_ (u"ࠬ࠭䵒"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭䵓"))
			html = response.content
		html = l1l111_l1_ (u"ࠧࠨ䵔")
		if html.startswith(l1l111_l1_ (u"ࠨࡗࡕࡐࡘࡃࠧ䵕")):
			l1l1llllll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䵖"),html.split(l1l111_l1_ (u"࡙ࠪࡗࡒࡓ࠾ࠩ䵗"),1)[1])
			for request in l1l1llllll1l_l1_:
				url = request[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䵘")]
				method = request[l1l111_l1_ (u"ࠬࡳࡥࡵࡪࡲࡨࠬ䵙")]
				data = request[l1l111_l1_ (u"࠭ࡤࡢࡶࡤࠫ䵚")]
				headers = request[l1l111_l1_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨ䵛")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠨࠩ䵜"),l1l111_l1_ (u"ࠩࠪ䵝"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪ䵞"))
				l1l11ll11ll1_l1_ = response.content
				if l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䵟") in l1l11ll11ll1_l1_:
					found = True
					break
				l1l1l11l1111_l1_ = str(response.headers)
				l11lllll1lll_l1_ = l1l1l11l1111_l1_+l1l11ll11ll1_l1_
				l1l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࡟ࡻ࠰࠯࠮ࠫࡁࠥࠬࡪࡿࡊ࠯ࠬࡂ࠭ࠧ࠭䵠"),l11lllll1lll_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮࠯ࠬࡂࠦ࠭࠶࠳ࡂ࠰࠭ࡃ࠮ࠨࠧ䵡"),l11lllll1lll_l1_,re.DOTALL)
				if token: token = token[0]
				if l1l111l11ll1_l1_ or token: break
		if not found:
			if not l1l111l11ll1_l1_:
				if not token and l1l1111lll11_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠧࡊࡆࡀࠫ䵢")):
						data = {l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭䵣"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ䵤"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䵥"):l1l11111111l_l1_,l1l111_l1_ (u"ࠫࡰ࡫ࡹࠨ䵦"):l1l111lll111_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࠨ䵧"):l1l111_l1_ (u"࠭ࠧ䵨"),l1l111_l1_ (u"ࠧ࡫ࡱࡥࠫ䵩"):l1l111_l1_ (u"ࠨࡩࡨࡸ࡮ࡪࠧ䵪")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䵫"),l1l1111lll1l_l1_,data,l1l111_l1_ (u"ࠪࠫ䵬"),l1l111_l1_ (u"ࠫࠬ䵭"),l1l111_l1_ (u"ࠬ࠭䵮"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠷ࡸ࡭࠭䵯"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠧࡊࡆࡀ࠵࠷࠹࠴࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠺࠵ࠨ䵰")
					if html.startswith(l1l111_l1_ (u"ࠨࡋࡇࡁࠬ䵱")):
						l11llllllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡌࡈࡂ࠮࠮ࠫࡁࠬ࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䵲"),html,re.DOTALL)
						l1l1l1l11111_l1_,l1l1111l111_l1_ = l11llllllll1_l1_[0]
						message = l1l111_l1_ (u"๋ࠪีํࠠศๆ฼้้๐ษࠡฬะฮฬา้ࠠไอࠤ๊์ࠠ࠲࠲ࠣษ้๏ࠠࠨ䵳")+l1l1111l111_l1_+l1l111_l1_ (u"ࠫࠥัว็์ฬࠫ䵴")
						l1l1111lll_l1_ = l1l111lll1_l1_()
						l1l1111lll_l1_.create(l1l111_l1_ (u"๋ࠬอศ๊็อࠥะฬศ๊ีࠤๆำีࠡล้หࠥษๆิษ้ࠤํ๊ำหࠢหี๋อๅอࠢๆ์๊ฮ๊้ฬิࠫ䵵"),message)
						t1 = time.time()
						l1l11l111l11_l1_,l1l1l1l11lll_l1_ = 0,0
						while l1l11l111l11_l1_<int(l1l1111l111_l1_):
							l1l1111l11_l1_(l1l1111lll_l1_,int(l1l11l111l11_l1_/int(l1l1111l111_l1_)*100),message,l1l111_l1_ (u"࠭ࠧ䵶"),l1l1111l111_l1_+l1l111_l1_ (u"ࠧࠡ࠱ࠣࠫ䵷")+str(int(l1l11l111l11_l1_))+l1l111_l1_ (u"ࠨࠢࠣฯฬ์๊สࠩ䵸"))
							if l1l11l111l11_l1_>l1l1l1l11lll_l1_+10:
								data = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ䵹"):l1ll11l11lll_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ䵺"):l1l11l111l1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䵻"):l1l11111111l_l1_,l1l111_l1_ (u"ࠬࡱࡥࡺࠩ䵼"):l1l111lll111_l1_,l1l111_l1_ (u"࠭ࡩࡥࠩ䵽"):l1l1l1l11111_l1_,l1l111_l1_ (u"ࠧ࡫ࡱࡥࠫ䵾"):l1l111_l1_ (u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪ䵿")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䶀"),l1l1111lll1l_l1_,data,l1l111_l1_ (u"ࠪࠫ䶁"),l1l111_l1_ (u"ࠫࠬ䶂"),l1l111_l1_ (u"ࠬ࠭䶃"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠸ࡸ࡭࠭䶄"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"ࠧࡕࡑࡎࡉࡓࡃࠧ䶅")):
									token = html.split(l1l111_l1_ (u"ࠨࡖࡒࡏࡊࡔ࠽ࠨ䶆"),1)[1]
									break
								l1l1l1l11lll_l1_ = l1l11l111l11_l1_
							else: time.sleep(1)
							l1l11l111l11_l1_ = time.time()-t1
						l1l1111lll_l1_.close()
				if token:
					l1l111111111_l1_ = response.cookies
					l1ll111lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ䶇"),l11lllll1lll_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪ䶈") in list(l1l111111111_l1_.keys()): l1ll111lll1l_l1_ = l1l111111111_l1_[l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࠫ䶉")]
					elif l1ll111lll1l_l1_: l1ll111lll1l_l1_ = l1ll111lll1l_l1_[0]
					l1l1111lll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨࡧ࠰ࡶࡪࡪࡩࡳࡧࡦࡸ࠳࠰࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵ࡬ࡸࡪࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䶊"),l1l11ll11ll1_l1_,re.DOTALL)
					if l1l1111lll11_l1_: l11llllll1l1_l1_,l1l111lll111_l1_ = l1l1111lll11_l1_[0]
					if l1ll111lll1l_l1_ and l1l1111lll11_l1_:
						headers = {l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䶋"):l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠨ䶌")+l1ll111lll1l_l1_,l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䶍"):l1l11111111l_l1_,l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䶎"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䶏")}
						data = l1l111_l1_ (u"ࠫ࡬࠳ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡵࡩࡸࡶ࡯࡯ࡵࡨࡁࠬ䶐")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䶑"),l11llllll1l1_l1_,data,headers,False,l1l111_l1_ (u"࠭ࠧ䶒"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠺ࡹ࡮ࠧ䶓"))
						l1l11ll11ll1_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l1l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࠮ࠫࡁࠬࠫ࠿ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䶔"),str(cookies),re.DOTALL)
			if l1l111l11ll1_l1_:
				name,l1l111l11ll1_l1_ = l1l111l11ll1_l1_[0]
				l1l11l1lllll_l1_ = name+l1l111_l1_ (u"ࠩࡀࠫ䶕")+l1l111l11ll1_l1_
				settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡡ࡬ࡹࡤࡱ࠳ࡼࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ䶖"),l1l11l1lllll_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䶗"),l1l111_l1_ (u"ࠬ࠭䶘"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䶙"),l1l111_l1_ (u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥหๆิษ้ࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษะี๊ࠥ์สศศฯࠤ์ึวࠡษ็ๅา฻ࠠๅๅํࠤ๏ูสฯั่๋ฬࠦไศฯๅหࠥ࠴࠮๊ࠡ็หࠥะ่อัࠣัฬาษࠡๆศ฽ฬีษ้ࠡำหࠥอไโฯุࠤ้฿ฯสࠢฦุ์ืࠠ࡝ࡰ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้็อึࠢึ์ๆ๊ࠦหๅิีࠥ็๊ࠡฯส่ฮࠦส฻์ิࠤึฮืࠡษ็ะ์อาࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣษ฼็วยࠢิหํะัࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢไู้ࠦำๅๅࠣห้ืว้ฬิࠤ࠳࠴ࠠฤ๊ࠣหุะฮะษ่ࠤ࡛ࡖࡎࠡล๋ࠤอื่ไีํࠫ䶚"))
				if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䶛") not in l1l11ll11ll1_l1_:
					headers = {l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ䶜"):l1l11l1lllll_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䶝"),l1l11111111l_l1_,l1l111_l1_ (u"ࠫࠬ䶞"),headers,l1l111_l1_ (u"ࠬ࠭䶟"),l1l111_l1_ (u"࠭ࠧ䶠"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠻ࡹ࡮ࠧ䶡"))
					l1l11ll11ll1_l1_ = response.content
	if not found and not l1l11l1lllll_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䶢"),l1l111_l1_ (u"ࠩࠪ䶣"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䶤"),l1l111_l1_ (u"ࠫ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣๅู๊สࠡ࠰࠱ࠤาอ่ๅࠢศ฽ฬีษࠡษ็฽๊๊๊ส่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦๆโีࠣห้็๊ะ์๋ࠤศ๎ࠠโ์า๎ํฺ๋ࠦำ๊ࠤ๊์ࠠ็ใึࠤฬ๊ๅ้ไ฼ࠫ䶥"))
	return l1l11ll11ll1_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䶦"),url,l1l111_l1_ (u"࠭ࠧ䶧"),l1l111_l1_ (u"ࠧࠨ䶨"),l1l111_l1_ (u"ࠨࠩ䶩"),l1l111_l1_ (u"ࠩࠪ䶪"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠷ࡳࡵࠩ䶫"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁ࠿࠳ࡦࡄࠧ䶬"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ䶭"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ䶮") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ䶯") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩ䶰"),l1l111_l1_ (u"ࠩࠪ䶱")).replace(l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ䶲"),l1l111_l1_ (u"ࠫࠬ䶳")).strip(l1l111_l1_ (u"ࠬࠦࠧ䶴")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䶵"),l1l111_l1_ (u"ࠧࠡࠩ䶶"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111llll11_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨส฼ฺ์อ๋ࠠฯอหัࠦ࠶࠱ࠢฮห๋๐ษࠨ䶷"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ䶸"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ䶹"),[],[]
	l1l11111111l_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l1l11ll11ll1_l1_ = l1l11l1111l1_l1_(l1l11111111l_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䶺"):
		l1l11ll1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡨࡴ࡯࠯࡯ࡳࡦࡪࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䶻"),l1l11ll11ll1_l1_,re.DOTALL)
		if l1l11ll1ll1l_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l11ll1ll1l_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ䶼"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䶽"),l1l11ll11ll1_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ䶾"),[],[]
	return l1l111_l1_ (u"ࠩࠪ䶿"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䷀"),url,l1l111_l1_ (u"ࠫࠬ䷁"),l1l111_l1_ (u"ࠬ࠭䷂"),True,l1l111_l1_ (u"࠭ࠧ䷃"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭䷄"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ䷅") in list(cookies.keys()):
		l1l11l1lllll_l1_ = cookies[l1l111_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ䷆")]
		l1l11l1lllll_l1_ = l111l11_l1_(escapeUNICODE(l1l11l1lllll_l1_))
		items = re.findall(l1l111_l1_ (u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷇"),l1l11l1lllll_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ䷈"),l1l111_l1_ (u"ࠬ࠵ࠧ䷉"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ䷊") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧࠦ࠴ࡉࠫ䷋"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫ䷌")+id
		return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䷍"),[l1l111_l1_ (u"ࠪࠫ䷎")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䷏")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䷐"),l1l11l11_l1_,l1l111_l1_ (u"࠭ࠧ䷑"),l1l111_l1_ (u"ࠧࠨ䷒"),True,l1l111_l1_ (u"ࠨࠩ䷓"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠷ࡴࡤࠨ䷔"))
		l1l1l111ll1l_l1_ = response.url
		l1l1l11lll1l_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ䷕"))[2]
		l1l1l1l1l1l1_l1_ = l1l1l111ll1l_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭䷖"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l1l11lll1l_l1_,l1l1l1l1l1l1_l1_)
		headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䷗"):l1l111_l1_ (u"࠭ࠧ䷘") , l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䷙"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䷚") , l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䷛"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷜"), l1llllll_l1_, l1l111_l1_ (u"ࠫࠬ䷝"), headers, False,l1l111_l1_ (u"ࠬ࠭䷞"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬ䷟"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷠"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷡"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷢"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠪࡠ࠴࠭䷣"),l1l111_l1_ (u"ࠫ࠴࠭䷤"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠬ࠵ࠧ䷥"))
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䷦") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䷧") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ䷨"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ䷩"))
			if name==l1l111_l1_ (u"ࠪࠫ䷪"): l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ䷫"),[l1l111_l1_ (u"ࠬ࠭䷬")],[l1ll1ll_l1_]
			else: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䷭"),[l1l111_l1_ (u"ࠧࠨ䷮")],[l1ll1ll_l1_]
		else: l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐࡕࡁࡎࠩ䷯"),[],[]
		return l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l1111l11ll_l1_(url):
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䷰") : l1l111_l1_ (u"ࠪࠫ䷱") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䷲"),headers,l1l111_l1_ (u"ࠬ࠭䷳"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ䷴"))
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷵"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠨࠩ䷶")
	if items:
		for l1ll1ll_l1_,l1lllll11111_l1_ in items:
			l1l1lll1_l1_.append(l1lllll11111_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏࠨ䷷"),[],[]
	return l1l111_l1_ (u"ࠪࠫ䷸"),l1l1lll1_l1_,l1llll_l1_
def l1l11l11ll1l_l1_(url):
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䷹"):l1l111_l1_ (u"ࠬ࠭䷺")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䷻"),headers,l1l111_l1_ (u"ࠧࠨ䷼"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ䷽"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷾"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䷿")+url
		return l1l111_l1_ (u"ࠫࠬ一"),[l1l111_l1_ (u"ࠬ࠭丁")],[url]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨ丂"),[],[]
def l1l111llllll_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ七"))
	if l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ丄") in url: id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ丅"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ丆"))[-1]
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ万") + id
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ丈") : l1l111_l1_ (u"࠭ࠧ三") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ上"),headers,l1l111_l1_ (u"ࠨࠩ下"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡃࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ丌"))
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭不"),l1l111_l1_ (u"ࠫࠬ与"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ丏"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ丐"),[l1l111_l1_ (u"ࠧࠨ丑")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ丒"),[],[]
def l1l111lll1ll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ专"),l1l111_l1_ (u"ࠪࠫ且"),l1l111_l1_ (u"ࠫࠬ丕"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬ世"))
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丗"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1lllll11111_l1_,res in items:
		l1l1lll1_l1_.append(l1lllll11111_l1_+l1l111_l1_ (u"ࠧࠡࠩ丘")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡏ࡛ࡃࠪ丙"),[],[]
	return l1l111_l1_ (u"ࠩࠪ业"),l1l1lll1_l1_,l1llll_l1_
def l1l11lll1l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ丛"),l1l111_l1_ (u"ࠫࠬ东"),l1l111_l1_ (u"ࠬ࠭丝"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ丞"))
	items = re.findall(l1l111_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ丟"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1lllll11111_l1_,res in items:
		url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ丠")+id+l1l111_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ両")+mode+l1l111_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ丢")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ丣"),l1l111_l1_ (u"ࠬ࠭两"),l1l111_l1_ (u"࠭ࠧ严"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠳ࡰࡧࠫ並"))
		items = re.findall(l1l111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ丧"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1lllll11111_l1_+l1l111_l1_ (u"ࠩࠣࠫ丨")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐࠩ丩"),[],[]
	return l1l111_l1_ (u"ࠫࠬ个"),l1l1lll1_l1_,l1llll_l1_
def l1l1111ll1ll_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࠭丫")
	if 1 or l1l111_l1_ (u"࠭ࡋࡦࡻࡀࠫ丬") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠴࡬ࡪࡸࡨࠫ中"),l1l111_l1_ (u"ࠨࡷࡳࡴࡴࡳ࠮࡭࡫ࡹࡩࠬ丮"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ丯"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ丰").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠫ࡮ࡪࠧ丱"):id,l1l111_l1_ (u"ࠬࡵࡰࠨ串"):l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ丳"),l1l111_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ临"):l1l111_l1_ (u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ丵")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ丶"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠪࠫ丷"),l1l111_l1_ (u"ࠫࠬ丸"),l1l111_l1_ (u"ࠬ࠭丹"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬ为"))
		if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ主") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ丼")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丽"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ举"),url,l1l111_l1_ (u"ࠫࠬ丿"),l1l111_l1_ (u"ࠬ࠭乀"),l1l111_l1_ (u"࠭ࠧ乁"),l1l111_l1_ (u"ࠧࠨ乂"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ乃"))
		if l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ乄") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ久")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࠬ乆"),[l1l111_l1_ (u"ࠬ࠭乇")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧ么"),[],[]
def l1l11l111l1l_l1_(url):
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ义") : l1l111_l1_ (u"ࠨࠩ乊") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ之"),headers,l1l111_l1_ (u"ࠪࠫ乌"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡋࡌ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭乍"))
	items = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦ࠭࠴ࠪࡀࠫࠥࠫ乎"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠶ࠪ乏"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ乐"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠨࠩ乑"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡏࡉࡗࡋࡇࡉࡔ࠭乒"),[],[]
def l11ll1lllll_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ乓"))[-1]
	id = id.split(l1l111_l1_ (u"ࠫࠫ࠭乔"))[0]
	id = id.replace(l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ乕"),l1l111_l1_ (u"࠭ࠧ乖"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ乗")][0]+l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ乘")+id
	l1l111l111ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬ乙")+id
	l1l11llll1l1_l1_,l1l11llll111_l1_,l1l11l1llll1_l1_,l1l111llll1l_l1_ = l1l111_l1_ (u"ࠪࠫ乚"),l1l111_l1_ (u"ࠫࠬ乛"),l1l111_l1_ (u"ࠬ࠭乜"),l1l111_l1_ (u"࠭ࠧ九")
	for l1l111llll_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ乞"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ也"),l1l111_l1_ (u"ࠩࠪ习"),l1l111_l1_ (u"ࠪࠫ乡"),l1l111_l1_ (u"ࠫࠬ乢"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭乣"))
		html = response.content
		if l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ乤") in html: break
		time.sleep(2)
	l1l11lllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ乥"),html,re.DOTALL)
	if l1l11lllll_l1_: l1l11lllll_l1_ = l1l11lllll_l1_[0]
	else: l1l11lllll_l1_ = html
	l1l11lllll_l1_ = l1l11lllll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ书"),l1l111_l1_ (u"ࠩࠩࠫ乧"))
	l1l1l111lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ乨"),l1l11lllll_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ乩")],[l1l111_l1_ (u"ࠬ࠭乪")]
	try:
		l1l1l1l1l111_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ乫")][l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ乬")][l1l111_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ乭")]
		for l1l11l1l1l1l_l1_ in l1l1l1l1l111_l1_:
			l1ll1ll_l1_ = l1l11l1l1l1l_l1_[l1l111_l1_ (u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ乮")]
			try: title = l1l11l1l1l1l_l1_[l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ乯")][l1l111_l1_ (u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ买")]
			except: title = l1l11l1l1l1l_l1_[l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ乱")][l1l111_l1_ (u"࠭ࡲࡶࡰࡶࠫ乲")][0][l1l111_l1_ (u"ࠧࡵࡧࡻࡸࠬ乳")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ乴"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ乵"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠪࠪࠬ乶")
			l1l11l11l111_l1_ = re.findall(l1l111_l1_ (u"ࠫࠫ࠮ࡦ࡮ࡶࡀ࠲࠯ࡅࠩࠧࠩ乷"),l1ll1ll_l1_)
			if l1l11l11l111_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l11l11l111_l1_[0],l1l111_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭乸"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ乹")
			l1l11llll1l1_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ乺"))
	formats,l1l1l111llll_l1_,l1l1111l1ll1_l1_,l1l1111l1lll_l1_,l1l1111l1l1l_l1_ = [],[],[],[],[]
	try: l1l11llll111_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ乻")][l1l111_l1_ (u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ乼")]
	except: pass
	try: l1l11l1llll1_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ乽")][l1l111_l1_ (u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ乾")]
	except: pass
	try: formats = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ乿")][l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ亀")]
	except: pass
	try: l1l1l111llll_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ亁")][l1l111_l1_ (u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪ亂")]
	except: pass
	l1l11llll11l_l1_ = formats+l1l1l111llll_l1_
	for dict in l1l11llll11l_l1_:
		if l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ亃") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ亄")] = str(dict[l1l111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ亅")])
		if l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ了") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡦࡱࡵࠪ亇")] = str(dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ予")])
		if l1l111_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ争") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ亊")] = dict[l1l111_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ事")]
		if l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭二") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ亍")] = str(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ于")])
		if l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ亏") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ亐")] = str(dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ云")])
		if l1l111_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ互") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ亓")] = str(dict[l1l111_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ五")])+l1l111_l1_ (u"࠭ࡸࠨ井")+str(dict[l1l111_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ亖")])
		if l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ亗") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ亘")] = dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭亙")][l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ亚")]+l1l111_l1_ (u"ࠬ࠳ࠧ些")+dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ亜")][l1l111_l1_ (u"ࠧࡦࡰࡧࠫ亝")]
		if l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ亞") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ亟")] = dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ亠")][l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ亡")]+l1l111_l1_ (u"ࠬ࠳ࠧ亢")+dict[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ亣")][l1l111_l1_ (u"ࠧࡦࡰࡧࠫ交")]
		if l1l111_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ亥") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ亦")] = dict[l1l111_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ产")]
		if l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ亨") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭亩")])>111222333: del dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ亪")]
		if l1l111_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ享") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ京")].split(l1l111_l1_ (u"ࠩࠩࠫ亭"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ亮"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ亯") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ亰")] = l111l11_l1_(dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ亱")])
		l1l1111l1ll1_l1_.append(dict)
	l1l11ll111l1_l1_ = l1l111_l1_ (u"ࠧࠨ亲")
	if l1l111_l1_ (u"ࠨࡵࡳࡁࡸ࡯ࡧࠨ亳") in l1l11lllll_l1_:
		l1l1l1111l11_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨ亴"),html,re.DOTALL)
		if l1l1l1111l11_l1_:
			l1l1l1111l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ亵")][0]+l1l1l1111l11_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ亶"),l1l1l1111l11_l1_,l1l111_l1_ (u"ࠬ࠭亷"),l1l111_l1_ (u"࠭ࠧ亸"),l1l111_l1_ (u"ࠧࠨ亹"),l1l111_l1_ (u"ࠨࠩ人"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ亻"))
			l1l11ll111l1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1l111111l11_l1_ = cipher._load_javascript(l1l11ll111l1_l1_)
			l1l11l11llll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ亼"),str(l1l111111l11_l1_))
			l1l111111lll_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l11l11llll_l1_)
	for dict in l1l1111l1ll1_l1_:
		url = dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ亽")]
		if l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠾ࠩ亾") in url or url.count(l1l111_l1_ (u"࠭ࡳࡪࡩࡀࠫ亿"))>1:
			l1l1111l1lll_l1_.append(dict)
		elif l1l11ll111l1_l1_ and l1l111_l1_ (u"ࠧࡴࠩ什") in list(dict.keys()) and l1l111_l1_ (u"ࠨࡵࡳࠫ仁") in list(dict.keys()):
			l1l11l1l11l1_l1_ = l1l111111lll_l1_.execute(dict[l1l111_l1_ (u"ࠩࡶࠫ仂")])
			if l1l11l1l11l1_l1_!=dict[l1l111_l1_ (u"ࠪࡷࠬ仃")]:
				dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ仄")] = url+l1l111_l1_ (u"ࠬࠬࠧ仅")+dict[l1l111_l1_ (u"࠭ࡳࡱࠩ仆")]+l1l111_l1_ (u"ࠧ࠾ࠩ仇")+l1l11l1l11l1_l1_
				l1l1111l1lll_l1_.append(dict)
	for dict in l1l1111l1lll_l1_:
		l111lll_l1_,l1l11111ll1l_l1_,l1l1l1l11l1l_l1_,l1l1l1ll1_l1_,codecs,l11ll11l111_l1_ = l1l111_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ仈"),l1l111_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ仉"),l1l111_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ今"),l1l111_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ介"),l1l111_l1_ (u"ࠬ࠭仌"),l1l111_l1_ (u"࠭࠰ࠨ仍")
		try:
			l1l1111ll111_l1_ = dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ从")]
			l1l1111ll111_l1_ = l1l1111ll111_l1_.replace(l1l111_l1_ (u"ࠨ࠭ࠪ仏"),l1l111_l1_ (u"ࠩࠪ仐"))
			items = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ仑"),l1l1111ll111_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l1l111111l_l1_ = codecs.split(l1l111_l1_ (u"ࠫ࠱࠭仒"))
			l1l11111ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭仓")
			for item in l1l1l111111l_l1_: l1l11111ll1l_l1_ += item.split(l1l111_l1_ (u"࠭࠮ࠨ仔"))[0]+l1l111_l1_ (u"ࠧ࠭ࠩ仕")
			l1l11111ll1l_l1_ = l1l11111ll1l_l1_.strip(l1l111_l1_ (u"ࠨ࠮ࠪ他"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ仗") in list(dict.keys()): l11ll11l111_l1_ = str(float(dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ付")]*10)//1024/10)+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ仙")
			else: l11ll11l111_l1_ = l1l111_l1_ (u"ࠬ࠭仚")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"࠭ࡴࡦࡺࡷࠫ仛"): continue
			elif l1l111_l1_ (u"ࠧ࠭ࠩ仜") in l1l1111ll111_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃ࠮࡚ࠬ仝")
				l1l1l1l11l1l_l1_ = l111lll_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ仞")+l11ll11l111_l1_+dict[l1l111_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ仟")].split(l1l111_l1_ (u"ࠫࡽ࠭仠"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ仡"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ仢")
				l1l1l1l11l1l_l1_ = l11ll11l111_l1_+dict[l1l111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ代")].split(l1l111_l1_ (u"ࠨࡺࠪ令"))[1]+l1l111_l1_ (u"ࠩࠣࠤࠬ以")+dict[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ仦")]+l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ仧")+l1l111_l1_ (u"ࠬࠦࠠࠨ仨")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ仩"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭仪")
				l1l1l1l11l1l_l1_ = l11ll11l111_l1_+str(int(dict[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬ仫")])/1000)+l1l111_l1_ (u"ࠩ࡮࡬ࡿࠦࠠࠨ们")+dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ仭")]+l1l111_l1_ (u"ࠫࡨ࡮ࠧ仮")+l1l111_l1_ (u"ࠬࠦࠠࠨ仯")+l111lll_l1_
		except:
			l111l11ll11_l1_ = traceback.format_exc()
			if l111l11ll11_l1_!=l1l111_l1_ (u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩ仰"): sys.stderr.write(l111l11ll11_l1_)
		if l1l111_l1_ (u"ࠧࡥࡷࡵࡁࠬ仱") in dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仲")]: l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仳")].split(l1l111_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ仴"),1)[1].split(l1l111_l1_ (u"ࠫࠫ࠭仵"),1)[0]))
		elif l1l111_l1_ (u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ件") in list(dict.keys()): l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ价")])/1000)
		else: l1l1lll111_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ仸")
		if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ仹") not in list(dict.keys()): l11ll11l111_l1_ = dict[l1l111_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ仺")].split(l1l111_l1_ (u"ࠪࡼࠬ任"))[1]
		else: l11ll11l111_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ仼")]
		if l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ份") not in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ仾")] = l1l111_l1_ (u"ࠧ࠱࠯࠳ࠫ仿")
		dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ伀")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭企")+l1l1l1l11l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥ࠮ࠧ伂")+l1l11111ll1l_l1_+l1l111_l1_ (u"ࠫ࠱࠭伃")+dict[l1l111_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ伄")]+l1l111_l1_ (u"࠭ࠩࠨ伅")
		dict[l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ伆")] = l1l1l1l11l1l_l1_.split(l1l111_l1_ (u"ࠨࠢࠣࠫ伇"))[0].split(l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ伈"))[0]
		dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ伉")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭伊")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ伋")] = codecs
		dict[l1l111_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ伌")] = l1l1lll111_l1_
		dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伍")] = l11ll11l111_l1_
		l1l1111l1l1l_l1_.append(dict)
	l1l11lll1ll1_l1_,l1l11l111ll1_l1_,l1l1l11ll1ll_l1_,l1l1l1l1111l_l1_,l11llllll111_l1_ = [],[],[],[],[]
	l1l1l11111l1_l1_,l1l111l111l1_l1_,l1l111lllll1_l1_,l1l11lllllll_l1_,l1l1l11l1l11_l1_ = [],[],[],[],[]
	if l1l11llll111_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ伎")] = l1l111_l1_ (u"ࠩࡄ࠯࡛࠭伏")
		dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ伐")] = l1l111_l1_ (u"ࠫࡲࡶࡤࠨ休")
		dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ伒")] = dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伓")]+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ伔")+dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伕")]+l1l111_l1_ (u"ࠩࠣࠤࠬ伖")+l1l111_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭众")
		dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ优")] = l1l11llll111_l1_
		dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭伙")] = l1l111_l1_ (u"࠭࠰ࠨ会")
		dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伛")] = l1l111_l1_ (u"ࠨ࠻࠻࠻࠻࠻࠴࠴࠴࠴࠴ࠬ伜")
		l1l1111l1l1l_l1_.append(dict)
	if l1l11l1llll1_l1_:
		l1l1l111l111_l1_,l1l111lll11l_l1_ = l1l11l11ll_l1_(l1l11l1llll1_l1_)
		l1l11l1ll1l1_l1_ = list(zip(l1l1l111l111_l1_,l1l111lll11l_l1_))
		for title,l1ll1ll_l1_ in l1l11l1ll1l1_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ伝")] = l1l111_l1_ (u"ࠪࡅ࠰࡜ࠧ伞")
			dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭伟")] = l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ传")
			dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ伡")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ伢") in title: dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伣")] = title.split(l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ伤"))[0].rsplit(l1l111_l1_ (u"ࠪࠤࠥ࠭伥"))[-1]
			else: dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伦")] = l1l111_l1_ (u"ࠬ࠷࠰ࠨ伧")
			if title.count(l1l111_l1_ (u"࠭ࠠࠡࠩ伨"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠧࠡࠢࠪ伩"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ伪")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ伫")] = l1l111_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ伬")
			if title==l1l111_l1_ (u"ࠫ࠲࠷ࠧ伭"): dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ伮")] = dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伯")]+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ估")+dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伱")]+l1l111_l1_ (u"ࠩࠣࠤࠬ伲")+l1l111_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭伳")
			else: dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ伴")] = dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ伵")]+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ伶")+dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伷")]+l1l111_l1_ (u"ࠨࠢࠣࠫ伸")+dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ伹")]+l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ伺")+dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ伻")]
			l1l1111l1l1l_l1_.append(dict)
	l1l1111l1l1l_l1_ = sorted(l1l1111l1l1l_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭似")]))
	if not l1l1111l1l1l_l1_:
		l1lll1ll111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ伽"),html,re.DOTALL)
		l1lll1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻࡞ࡾࠦࡷࡻ࡮ࡴࠤ࠽ࡠࡠࡢࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ伾"),html,re.DOTALL)
		l1l11lll111l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ伿"),html,re.DOTALL)
		l1l11lll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ佀"),html,re.DOTALL)
		try: l1l11lll11ll_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ佁")][l1l111_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ佂")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭佃")][l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ佄")][l1l111_l1_ (u"ࠧࡳࡷࡱࡷࠬ佅")][0][l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭但")]
		except: l1l11lll11ll_l1_ = l1l111_l1_ (u"ࠩࠪ佇")
		try: l1l11lll1l11_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ佈")][l1l111_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ佉")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭佊")][l1l111_l1_ (u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ佋")][0][l1l111_l1_ (u"ࠧࡳࡷࡱࡷࠬ佌")][0][l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭位")]
		except: l1l11lll1l11_l1_ = l1l111_l1_ (u"ࠩࠪ低")
		try: l1l111111l1l_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ住")][l1l111_l1_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ佐")]
		except: l1l111111l1l_l1_ = l1l111_l1_ (u"ࠬ࠭佑")
		if l1lll1ll111_l1_ or l1lll1ll11l_l1_ or l1l11lll111l_l1_ or l1l11lll11l1_l1_ or l1l11lll11ll_l1_ or l1l11lll1l11_l1_ or l1l111111l1l_l1_:
			if   l1lll1ll111_l1_: message = l1lll1ll111_l1_[0]
			elif l1lll1ll11l_l1_: message = l1lll1ll11l_l1_[0]
			elif l1l11lll111l_l1_: message = l1l11lll111l_l1_[0]
			elif l1l11lll11l1_l1_: message = l1l11lll11l1_l1_[0]
			elif l1l11lll11ll_l1_: message = l1l11lll11ll_l1_
			elif l1l11lll1l11_l1_: message = l1l11lll1l11_l1_
			elif l1l111111l1l_l1_: message = l1l111111l1l_l1_
			l1l1l1l111ll_l1_ = message.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ佒"),l1l111_l1_ (u"ࠧࠨ体")).strip(l1l111_l1_ (u"ࠨࠢࠪ佔"))
			l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦๅีๅ็อࠥ๎โะࠢํ็ํ์ࠠ฻์ิࠤ๊๊วว็่ࠣอ฿ึࠡษ็ุ้ะฮะ็ํ๊ࠥษ่ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ何")
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ佖"),l1l111_l1_ (u"ࠫࠬ佗"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿้ࠠษ็้อืๅอࠩ佘"),l1l1l1l111l1_l1_+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ余")+l1l1l1l111ll_l1_)
			return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠩ佚")+l1l1l1l111ll_l1_,[],[]
		else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ佛"),[],[]
	l1l11111lll1_l1_,l1l11111llll_l1_,l1l11l11l11l_l1_ = [],[],[]
	for dict in l1l1111l1l1l_l1_:
		if dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ作")]==l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ佝"):
			l1l11lll1ll1_l1_.append(dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ佞")])
			l1l1l11111l1_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ佟")]==l1l111_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ你"):
			l1l11l111ll1_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佡")])
			l1l111l111l1_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ佢")]==l1l111_l1_ (u"ࠩࡰࡴࡩ࠭佣"):
			title = dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ佤")].replace(l1l111_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ佥"),l1l111_l1_ (u"ࠬ࠭佦"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ佧") not in list(dict.keys()): l11ll11l111_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ佨")
			else: l11ll11l111_l1_ = dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佩")]
			l1l11111lll1_l1_.append([dict,{},title,l11ll11l111_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佪")].replace(l1l111_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ佫"),l1l111_l1_ (u"ࠫࠬ佬"))
			if l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佭") not in list(dict.keys()): l11ll11l111_l1_ = l1l111_l1_ (u"࠭࠰ࠨ佮")
			else: l11ll11l111_l1_ = dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ佯")]
			l1l11111lll1_l1_.append([dict,{},title,l11ll11l111_l1_])
			l1l1l11ll1ll_l1_.append(title)
			l1l111lllll1_l1_.append(dict)
		l1l11ll111ll_l1_ = True
		if l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ佰") in list(dict.keys()):
			if l1l111_l1_ (u"ࠩࡤࡺ࠵࠭佱") in dict[l1l111_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ佲")]: l1l11ll111ll_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠫࡦࡼࡣࠨ佳") not in dict[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ佴")] and l1l111_l1_ (u"࠭࡭ࡱ࠶ࡤࠫ併") not in dict[l1l111_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ佶")]: l1l11ll111ll_l1_ = False
		if dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ佷")]==l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ佸") and dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ佹")]!=l1l111_l1_ (u"ࠫ࠵࠳࠰ࠨ佺") and l1l11ll111ll_l1_==True:
			l11llllll111_l1_.append(dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ佻")])
			l1l1l11l1l11_l1_.append(dict)
		elif dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ佼")]==l1l111_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭佽") and dict[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭佾")]!=l1l111_l1_ (u"ࠩ࠳࠱࠵࠭使") and l1l11ll111ll_l1_==True:
			l1l1l1l1111l_l1_.append(dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ侀")])
			l1l11lllllll_l1_.append(dict)
	for l1l11ll11111_l1_ in l1l11lllllll_l1_:
		l1l111l1111l_l1_ = l1l11ll11111_l1_[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ侁")]
		for l1l11ll1lll1_l1_ in l1l1l11l1l11_l1_:
			l1l1l1l1l1ll_l1_ = l1l11ll1lll1_l1_[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭侂")]
			l11ll11l111_l1_ = l1l1l1l1l1ll_l1_+l1l111l1111l_l1_
			title = l1l11ll1lll1_l1_[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侃")].replace(l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠡࠩ侄"),l1l111_l1_ (u"ࠨ࡯ࡳࡨࠥࠦࠧ侅"))
			title = title.replace(l1l11ll1lll1_l1_[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ來")]+l1l111_l1_ (u"ࠪࠤࠥ࠭侇"),l1l111_l1_ (u"ࠫࠬ侈"))
			title = title.replace(str((float(l1l1l1l1l1ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ侉"),str((float(l11ll11l111_l1_*10)//1024/10))+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ侊"))
			title = title+l1l111_l1_ (u"ࠧࠩࠩ例")+l1l11ll11111_l1_[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ侌")].split(l1l111_l1_ (u"ࠩࠫࠫ侍"),1)[1]
			l1l11111lll1_l1_.append([l1l11ll1lll1_l1_,l1l11ll11111_l1_,title,l11ll11l111_l1_])
	l1l11111lll1_l1_ = sorted(l1l11111lll1_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l11ll1lll1_l1_,l1l11ll11111_l1_,title,l11ll11l111_l1_ in l1l11111lll1_l1_:
		l1l1111l11l1_l1_ = l1l11ll1lll1_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ侎")]
		if l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭侏") in list(l1l11ll11111_l1_.keys()):
			l1l1111l11l1_l1_ = l1l111_l1_ (u"ࠬࡳࡰࡥࠩ侐")
		if l1l1111l11l1_l1_ not in l1l11l11l11l_l1_:
			l1l11l11l11l_l1_.append(l1l1111l11l1_l1_)
			l1l11111llll_l1_.append([l1l11ll1lll1_l1_,l1l11ll11111_l1_,title,l11ll11l111_l1_])
	l1l11l1l11ll_l1_,l1l1l111l11l_l1_,shift = [],[],0
	l1l11ll11lll_l1_,l1l1l11l11ll_l1_ = l1l111_l1_ (u"࠭ࠧ侑"),l1l111_l1_ (u"ࠧࠨ侒")
	try: l1l11ll11lll_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ侓")][l1l111_l1_ (u"ࠩࡤࡹࡹ࡮࡯ࡳࠩ侔")]
	except: l1l11ll11lll_l1_ = l1l111_l1_ (u"ࠪࠫ侕")
	try: l1l11l11111l_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ侖")][l1l111_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨ侗")]
	except: l1l11l11111l_l1_ = l1l111_l1_ (u"࠭ࠧ侘")
	if l1l11ll11lll_l1_ and l1l11l11111l_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ侙")+l1l11ll11lll_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ侚")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ供")][0]+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭侜")+l1l11l11111l_l1_
		l1l11l1l11ll_l1_.append(title)
		l1l1l111l11l_l1_.append(l1ll1ll_l1_)
		try: l1l1l11l11ll_l1_ = l1l1l111lll1_l1_[l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ依")][l1l111_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ侞")][l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ侟")][-1][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ侠")]
		except: pass
	for l1l11ll1lll1_l1_,l1l11ll11111_l1_,title,l11ll11l111_l1_ in l1l11111llll_l1_:
		l1l11l1l11ll_l1_.append(title) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ価"))
	if l1l1l11ll1ll_l1_: l1l11l1l11ll_l1_.append(l1l111_l1_ (u"ุࠩ์ึฯ้ࠠื๋ฮ๋ࠥอะัฬࠫ侢")) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ侣"))
	if l1l11111lll1_l1_: l1l11l1l11ll_l1_.append(l1l111_l1_ (u"ฺࠫ๎ัสู๋ࠢํะࠠศๆ่ฮํ็ัࠨ侤")) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ侥"))
	if l11llllll111_l1_: l1l11l1l11ll_l1_.append(l1l111_l1_ (u"࠭࡭ࡱࡦࠣหำะัࠡษ็ูํืษ๊ࠡสฺ่๎สࠨ侦")) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ侧"))
	if l1l11lll1ll1_l1_: l1l11l1l11ll_l1_.append(l1l111_l1_ (u"ࠨื๋ีฮࠦศะ๊้ࠤฺ๎สࠨ侨")) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ侩"))
	if l1l11l111ll1_l1_: l1l11l1l11ll_l1_.append(l1l111_l1_ (u"ูࠪํะࠠษั๋๊ࠥ฻่าหࠪ侪")) ; l1l1l111l11l_l1_.append(l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ侫"))
	l1l1l11lllll_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111l111ll_l1_, l1l11l1l11ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ侬"),[],[]
		elif l11l11l_l1_==0 and l1l11ll11lll_l1_:
			l1ll1ll_l1_ = l1l1l111l11l_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠵࠹࠷ࠦ࡯ࡣࡰࡩࡂ࠭侭")+QUOTE(l1l11ll11lll_l1_)+l1l111_l1_ (u"ࠧࠧࡷࡵࡰࡂ࠭侮")+l1ll1ll_l1_
			if l1l1l11l11ll_l1_: new_path = new_path+l1l111_l1_ (u"ࠨࠨ࡬ࡱࡦ࡭ࡥ࠾ࠩ侯")+QUOTE(l1l1l11l11ll_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ侰")+new_path+l1l111_l1_ (u"ࠥ࠭ࠧ侱"))
			return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ侲"),[],[]
		choice = l1l1l111l11l_l1_[l11l11l_l1_]
		l1l11lll1lll_l1_ = l1l11l1l11ll_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠬࡪࡡࡴࡪࠪ侳"):
			l1l111llll1l_l1_ = l1l11llll111_l1_
			break
		elif choice in [l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ侴"),l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭侵"),l1l111_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ侶")]:
			if choice==l1l111_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ侷"): l1l1lll1_l1_,l1l11ll1l1ll_l1_ = l1l1l11ll1ll_l1_,l1l111lllll1_l1_
			elif choice==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ侸"): l1l1lll1_l1_,l1l11ll1l1ll_l1_ = l1l11lll1ll1_l1_,l1l1l11111l1_l1_
			elif choice==l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ侹"): l1l1lll1_l1_,l1l11ll1l1ll_l1_ = l1l11l111ll1_l1_,l1l111l111l1_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ侺"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l1l111llll1l_l1_ = l1l11ll1l1ll_l1_[l11l11l_l1_][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ侻")]
				l1l11lll1lll_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ侼"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ำฬ࠾ࠬ侽"), l11llllll111_l1_)
			if l11l11l_l1_!=-1:
				l1l11lll1lll_l1_ = l11llllll111_l1_[l11l11l_l1_]
				l1l111111ll1_l1_ = l1l1l11l1l11_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠอ๊าอࠥอไึ๊อ࠾ࠬ侾"), l1l1l1l1111l_l1_)
				if l11l11l_l1_!=-1:
					l1l11lll1lll_l1_ += l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ便")+l1l1l1l1111l_l1_[l11l11l_l1_]
					l1l11l1l1l11_l1_ = l1l11lllllll_l1_[l11l11l_l1_]
					l1l1l11lllll_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ俀"):
			l1l111l1lll1_l1_,l11lllll1l11_l1_,l1l1111ll11l_l1_,l1l1l11lll11_l1_ = list(zip(*l1l11111lll1_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ俁"), l1l1111ll11l_l1_)
			if l11l11l_l1_!=-1:
				l1l11lll1lll_l1_ = l1l1111ll11l_l1_[l11l11l_l1_]
				l1l111111ll1_l1_ = l1l111l1lll1_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"࠭࡭ࡱࡦࠪ係") in l1l1111ll11l_l1_[l11l11l_l1_] and l1l111111ll1_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ促")]!=l1l11llll111_l1_:
					l1l11l1l1l11_l1_ = l11lllll1l11_l1_[l11l11l_l1_]
					l1l1l11lllll_l1_ = True
				else: l1l111llll1l_l1_ = l1l111111ll1_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俄")]
				break
		elif choice==l1l111_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ俅"):
			l1l111l1lll1_l1_,l11lllll1l11_l1_,l1l1111ll11l_l1_,l1l1l11lll11_l1_ = list(zip(*l1l11111llll_l1_))
			l1l111111ll1_l1_ = l1l111l1lll1_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俆") in l1l1111ll11l_l1_[l11l11l_l1_-shift] and l1l111111ll1_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俇")]!=l1l11llll111_l1_:
				l1l11l1l1l11_l1_ = l11lllll1l11_l1_[l11l11l_l1_-shift]
				l1l1l11lllll_l1_ = True
			else: l1l111llll1l_l1_ = l1l111111ll1_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俈")]
			l1l11lll1lll_l1_ = l1l1111ll11l_l1_[l11l11l_l1_-shift]
			break
	if not l1l1l11lllll_l1_: l1l111l11l1l_l1_ = l1l111llll1l_l1_
	else: l1l111l11l1l_l1_ = l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠧ俉")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ俊")]+l1l111_l1_ (u"ࠨࠢ࠮ࠤࡆࡻࡤࡪࡱ࠽ࠤࠬ俋")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俌")]
	if l1l1l11lllll_l1_:
		l1l1l11l11l1_l1_ = int(l1l111111ll1_l1_[l1l111_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ俍")])
		l1l11l111111_l1_ = int(l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭俎")])
		l1l1lll111_l1_ = str(max(l1l1l11l11l1_l1_,l1l11l111111_l1_))
		l1l111l11111_l1_ = l1l111111ll1_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俏")].replace(l1l111_l1_ (u"࠭ࠦࠨ俐"),l1l111_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭俑"))
		l1l11l111lll_l1_ = l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俒")].replace(l1l111_l1_ (u"ࠩࠩࠫ俓"),l1l111_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ俔"))
		l1l1l11ll111_l1_ = l1l111_l1_ (u"ࠫࡁࡅࡸ࡮࡮ࠣࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠷࠮࠱ࠤࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࡂࠨࡕࡕࡈ࠰࠼ࠧࡅ࠾࡝ࡰࠪ俕")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠬࡂࡍࡑࡆࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡷ࡮ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠷࠶࠰࠲࠱࡛ࡑࡑ࡙ࡣࡩࡧࡰࡥ࠲࡯࡮ࡴࡶࡤࡲࡨ࡫ࠢࠡࡺࡰࡰࡳࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠥࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡱ࡯࡮࡬࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠲࠻࠼࠽࠴ࡾ࡬ࡪࡰ࡮ࠦࠥࡾࡳࡪ࠼ࡶࡧ࡭࡫࡭ࡢࡎࡲࡧࡦࡺࡩࡰࡰࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠦࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡱࡨࡦࡸࡤࡴ࠰࡬ࡷࡴ࠴࡯ࡳࡩ࠲࡭ࡹࡺࡦ࠰ࡒࡸࡦࡱ࡯ࡣ࡭ࡻࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡘࡺࡡ࡯ࡦࡤࡶࡩࡹ࠯ࡎࡒࡈࡋ࠲ࡊࡁࡔࡊࡢࡷࡨ࡮ࡥ࡮ࡣࡢࡪ࡮ࡲࡥࡴ࠱ࡇࡅࡘࡎ࠭ࡎࡒࡇ࠲ࡽࡹࡤࠣࠢࡰ࡭ࡳࡈࡵࡧࡨࡨࡶ࡙࡯࡭ࡦ࠿ࠥࡔ࡙࠷࠮࠶ࡕࠥࠤࡲ࡫ࡤࡪࡣࡓࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࡅࡷࡵࡥࡹ࡯࡯࡯࠿ࠥࡔ࡙࠭俖")+l1l1lll111_l1_+l1l111_l1_ (u"࠭ࡓࠣࠢࡷࡽࡵ࡫࠽ࠣࡵࡷࡥࡹ࡯ࡣࠣࠢࡳࡶࡴ࡬ࡩ࡭ࡧࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡶࡲࡰࡨ࡬ࡰࡪࡀࡩࡴࡱࡩࡪ࠲ࡳࡡࡪࡰ࠽࠶࠵࠷࠱ࠣࡀ࡟ࡲࠬ俗")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ俘")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠰ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬ俙")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ俚")]+l1l111_l1_ (u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁࠧࡺࡲࡶࡧࠥࡂࡡࡴࠧ俛")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ俜")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ保")+l1l111111ll1_l1_[l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ俞")]+l1l111_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ俟")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ俠")]+l1l111_l1_ (u"ࠩࠥࠤࡸࡺࡡࡳࡶ࡚࡭ࡹ࡮ࡓࡂࡒࡀࠦ࠶ࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦࠬ信")+str(l1l111111ll1_l1_[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ俢")])+l1l111_l1_ (u"ࠫࠧࠦࡷࡪࡦࡷ࡬ࡂࠨࠧ俣")+str(l1l111111ll1_l1_[l1l111_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ俤")])+l1l111_l1_ (u"࠭ࠢࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠪ俥")+str(l1l111111ll1_l1_[l1l111_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ俦")])+l1l111_l1_ (u"ࠨࠤࠣࡪࡷࡧ࡭ࡦࡔࡤࡸࡪࡃࠢࠨ俧")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠩࡩࡴࡸ࠭俨")]+l1l111_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ俩")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ俪")+l1l111l11111_l1_+l1l111_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ俫")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ俬")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭俭")]+l1l111_l1_ (u"ࠨࠤࡁࡠࡳ࠭修")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ俯")+l1l111111ll1_l1_[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ俰")]+l1l111_l1_ (u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ俱")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ俲")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ俳")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ俴")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠱ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡧࡵࡥ࡫ࡲ࠳ࠬ俵")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ俶")]+l1l111_l1_ (u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁࠧࡺࡲࡶࡧࠥࡂࡡࡴࠧ俷")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ俸")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ俹")+l1l11l1l1l11_l1_[l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ俺")]+l1l111_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ俻")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ俼")]+l1l111_l1_ (u"ࠩࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣ࠳࠶࠴࠹࠽࠵ࠣࡀ࡟ࡲࠬ俽")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠪࡀࡆࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻࠴࠶࠴࠵࠹࠺࠴࠼ࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠩ俾")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ俿")]+l1l111_l1_ (u"ࠬࠨ࠯࠿࡞ࡱࠫ倀")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩ倁")+l1l11l111lll_l1_+l1l111_l1_ (u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭倂")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭倃")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ倄")]+l1l111_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ倅")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ倆")+l1l11l1l1l11_l1_[l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ倇")]+l1l111_l1_ (u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭倈")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ倉")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ倊")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ個")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ倌")
		l1l1l11ll111_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡍࡑࡆࡁࡠࡳ࠭倍")
		if PY3:
			import http.server as l1l111ll1ll1_l1_
			import http.client as l1l11l1l1111_l1_
		else:
			import BaseHTTPServer as l1l111ll1ll1_l1_
			import httplib as l1l11l1l1111_l1_
		class l1l11ll1ll11_l1_(l1l111ll1ll1_l1_.HTTPServer):
			def __init__(self,l1lll1l11l1l_l1_=l1l111_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ倎"),port=55055,l1l1l11ll111_l1_=l1l111_l1_ (u"࠭࠼࠿ࠩ倏")):
				self.l1lll1l11l1l_l1_ = l1lll1l11l1l_l1_
				self.port = port
				self.l1l1l11ll111_l1_ = l1l1l11ll111_l1_
				l1l111ll1ll1_l1_.HTTPServer.__init__(self,(self.l1lll1l11l1l_l1_,self.port),l1l1l11l1ll1_l1_)
				self.l1l11l1lll1l_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ倐")+l1lll1l11l1l_l1_+l1l111_l1_ (u"ࠨ࠼ࠪ們")+str(port)+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ倒")
			def start(self):
				self.threads = l11l11ll111_l1_(False)
				self.threads.start_new_thread(1,self.l1l111ll1lll_l1_)
			def l1l111ll1lll_l1_(self):
				self.l1l11111l111_l1_ = True
				while self.l1l11111l111_l1_:
					self.handle_request()
			def stop(self):
				self.l1l11111l111_l1_ = False
				self.l1l11ll1l1l1_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l1l11ll111_l1_):
				self.l1l1l11ll111_l1_ = l1l1l11ll111_l1_
			def l1l11ll1l1l1_l1_(self):
				conn = l1l11l1l1111_l1_.HTTPConnection(self.l1lll1l11l1l_l1_+l1l111_l1_ (u"ࠪ࠾ࠬ倓")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠦࡍࡋࡁࡅࠤ倔"), l1l111_l1_ (u"ࠧ࠵ࠢ倕"))
		class l1l1l11l1ll1_l1_(l1l111ll1ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ倖"),l1l111_l1_ (u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ倗"))
				self.end_headers()
				self.wfile.write(self.server.l1l1l11ll111_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭倘")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ候"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭倚"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l11ll1ll11_l1_(l1l111_l1_ (u"ࠫ࠶࠸࠷࠯࠲࠱࠴࠳࠷ࠧ倛"),55055,l1l1l11ll111_l1_)
		l1l111llll1l_l1_ = httpd.l1l11l1lll1l_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠬ࠭倜")
	if not l1l111llll1l_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭倝"),[],[]
	return l1l111_l1_ (u"ࠧࠨ倞"),[l1l111_l1_ (u"ࠨࠩ借")],[[l1l111llll1l_l1_,l1l11llll1l1_l1_,httpd]]
def l1l11l1ll1ll_l1_(url):
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭倠") : l1l111_l1_ (u"ࠪࠫ倡") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ倢"),headers,l1l111_l1_ (u"ࠬ࠭倣"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡈࡏࡃ࠯࠴ࡷࡹ࠭値"))
	items = re.findall(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࡼࠪ࡞ࢀࠫ倥"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l1l111l111_l1_,l1l1lll1_l1_,l1l111lll11l_l1_,l1llll_l1_ = [],[],[],[]
	if not items: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ倦"),[],[]
	for l1ll1ll_l1_,dummy,l1lllll11111_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ倧"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ倨"))
		if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ倩") in l1ll1ll_l1_:
			l1l1l111l111_l1_,l1l111lll11l_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
			l1llll_l1_ = l1llll_l1_ + l1l111lll11l_l1_
			if l1l1l111l111_l1_[0]==l1l111_l1_ (u"ࠬ࠳࠱ࠨ倪"): l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ倫")+l1l111_l1_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ倬"))
			else:
				for title in l1l1l111l111_l1_:
					l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨีํีๆืࠠฯษุࠫ倭")+l1l111_l1_ (u"ࠩࠣࠤࠥ࠭倮")+title)
		else:
			title = l1l111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭倯")+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ倰")+l1lllll11111_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	return l1l111_l1_ (u"ࠬ࠭倱"),l1l1lll1_l1_,l1llll_l1_
def l1l111llll11_l1_(url,html):
	l111llll11_l1_,l1ll11l1_l1_,l1l1111111ll_l1_,l1llll1lll1_l1_,l1ll_l1_ = [],[],[],[],[]
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ倲"),html,re.DOTALL)
	if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡸࡵࡵࡳࡥࡨࡷࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ倳"),html,re.DOTALL)
	if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡶ࡬ࡢࡻࡨࡶࠥࡃࠠ࠯ࠬࡂࡠ࠭࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩ࡝ࠫࠪ倴"),html,re.DOTALL)
	if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡪࡸࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧ倵"),html,re.DOTALL)
	if l1lll1l1_l1_:
		l1lll1l1_l1_ = l1lll1l1_l1_[0]
		l1l11llll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡟࠱ࡢࡻ࡞ࠢ࠭ࠬࡡࡽࠫࠪ࠼ࠪ倶"),l1lll1l1_l1_,re.DOTALL)
		for key in list(set(l1l11llll1ll_l1_)): l1lll1l1_l1_ = l1lll1l1_l1_.replace(key+l1l111_l1_ (u"ࠫ࠿࠭倷"),l1l111_l1_ (u"ࠬࠨࠧ倸")+key+l1l111_l1_ (u"࠭ࠢ࠻ࠩ倹"))
		l1lll1l1_l1_ = eval(l1lll1l1_l1_)
		if isinstance(l1lll1l1_l1_,dict): l1lll1l1_l1_ = [l1lll1l1_l1_]
		for block in l1lll1l1_l1_:
			if isinstance(block,dict):
				keys = list(block.keys())
				if l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࠬ债") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪ࠭倻")]
				elif l1l111_l1_ (u"ࠩ࡫ࡰࡸ࠭值") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"ࠪ࡬ࡱࡹࠧ倽")]
				if l1l111_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ倾") in keys: title = str(block[l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ倿")])
				elif l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬ偀") in keys: title = str(block[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭偁")])
				else: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠨ࠰ࠪ偂"),1)[1]
			elif isinstance(block,str):
				l1ll1ll_l1_ = block
				title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠩ࠱ࠫ偃"),1)[1]
			l111llll11_l1_.append(title)
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	for l1ll1ll_l1_,title in zip(l1ll11l1_l1_,l111llll11_l1_):
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ偄"),l1l111_l1_ (u"ࠫ࠴࠭偅"))
		l11lll1lll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ偆"))
		l11ll1l1ll_l1_ = l1l1ll11l_l1_()
		if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ假") in l1ll1ll_l1_:
			headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ偈"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ偉"):l11lll1lll_l1_}
			l1l1111111l1_l1_,l1l11l1l1lll_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_,headers)
			l1llll1lll1_l1_ += l1l11l1l1lll_l1_
			l1l1111111ll_l1_ += l1l1111111l1_l1_
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ偊")+l11ll1l1ll_l1_+l1l111_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭偋")+l11lll1lll_l1_
			l1llll1lll1_l1_.append(l1ll1ll_l1_)
			l1l1111111ll_l1_.append(title)
	if l1llll1lll1_l1_: return l1l111_l1_ (u"ࠫࠬ偌"),l1l1111111ll_l1_,l1llll1lll1_l1_
	return l1l111_l1_ (u"ࠬ࠭偍"),[],[]
def l1l1l1l1ll11_l1_(seq,url):
	global l1lll_l1_
	url = url.strip(l1l111_l1_ (u"࠭࠯ࠨ偎"))
	l1lll111ll1l_l1_,payload = l1l111_l1_ (u"ࠧࠨ偏"),{}
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ偐"):l1l1ll11l_l1_()}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭偑"),url,l1l111_l1_ (u"ࠪࠫ偒"),headers,l1l111_l1_ (u"ࠫࠬ偓"),False,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ偔"))
	html = response.content
	if l1l111_l1_ (u"࠭ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦࠩ偕") in html:
		l11111lllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲࡛ࡥࡴࡠ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ偖"),html,re.DOTALL)
		if l11111lllll_l1_:
			try: l1lll111ll1l_l1_ = l1lll1l1l1ll_l1_(l11111lllll_l1_[0])
			except: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ偗")
	l11l1ll1_l1_ = html+l1lll111ll1l_l1_
	if l1l111_l1_ (u"ࠩࠥ࡭ࡩ࠸ࠢࠨ偘") in l11l1ll1_l1_ or l1l111_l1_ (u"ࠪࠦ࡮ࡪࠢࠨ偙") in l11l1ll1_l1_:
		l1l11lll1111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴࠭做"))[3].replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ偛"),l1l111_l1_ (u"࠭ࠧ停")).replace(l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭偝"),l1l111_l1_ (u"ࠨࠩ偞"))
		if l1l111_l1_ (u"ࠩࠥ࡭ࡩ࠸ࠢࠨ偟") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠪ࡭ࡩ࠸ࠧ偠"):l1l11lll1111_l1_,l1l111_l1_ (u"ࠫࡴࡶࠧ偡"):l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨ偢")}
		elif l1l111_l1_ (u"࠭ࠢࡪࡦࠥࠫ偣") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠧࡪࡦࠪ偤"):l1l11lll1111_l1_,l1l111_l1_ (u"ࠨࡱࡳࠫ健"):l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ偦")}
		l1ll1ll1l_l1_ = headers.copy()
		l1ll1ll1l_l1_[l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ偧")] = l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ偨")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ偩"),url,payload,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ偪"),False,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ偫"))
		l1ll1lll1_l1_ = response.content
		l1l111l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ偬"),l1ll1lll1_l1_,re.DOTALL)
		if l1l111l11l11_l1_:
			l1lll_l1_[seq] = l1l111_l1_ (u"ࠩࠪ偭"),[l1l111_l1_ (u"ࠪࠫ偮")],[l1l111l11l11_l1_[0]]
			return
	l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111llll11_l1_(url,l11l1ll1_l1_)
	if l1llll_l1_:
		l1lll_l1_[seq] = l1l1l111ll11_l1_,l1l1lll1_l1_,l1llll_l1_
		return
	l1lll_l1_[seq] = l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡘࡔࡊࡄࡖࡎࡔࡇࠨ偯"),[],[]
	return
def l1l1111l1111_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ偰"))
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ偱"):l1l1ll11l_l1_()}
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ偲"),l1l11ll_l1_,l1l111_l1_ (u"ࠨࠩ偳"),headers,l1l111_l1_ (u"ࠩࠪ側"),False,l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡖࡎࡗࡍࡤ࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ偵"))
	if not response.succeeded: return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ偶"),[],[]
	global l1lll_l1_
	l1lll_l1_ = {}
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭偷"),l1l111_l1_ (u"࠭࠯ࠨ偸"))
	parts = re.findall(l1l111_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄࡀ࠯࠰࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬࠨࠬ偹"),url+l1l111_l1_ (u"ࠨ࠱ࠪ偺"),re.DOTALL)
	start,l1l111l1l1l1_l1_,end = parts[0]
	end = end.strip(l1l111_l1_ (u"ࠩ࠲ࠫ偻"))
	l1l11l11ll11_l1_ = len(l1l111l1l1l1_l1_)<4 or l1l111l1l1l1_l1_ in [l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࠨ偼"),l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ偽"),l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡩࡲࡨࡥࡥࠩ偾")]
	l1ll_l1_,seq = [],0
	l1ll_l1_.append([0,start+l1l111_l1_ (u"࠭࠯ࠨ偿")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ傀")+end])
	if not l1l11l11ll11_l1_: l1ll_l1_.append([1,start+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ傁")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ傂")+end])
	if end: l1ll_l1_.append([2,start+l1l111_l1_ (u"ࠪ࠳ࠬ傃")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ傄")+end])
	if l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ傅") in l1l111l1l1l1_l1_:
		l1l11ll1llll_l1_ = l1l111l1l1l1_l1_.replace(l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ傆"),l1l111_l1_ (u"ࠧࠨ傇"))
		l1ll_l1_.append([3,start+l1l111_l1_ (u"ࠨ࠱ࠪ傈")+l1l11ll1llll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ傉")+end])
		l1ll_l1_.append([4,start+l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ傊")+l1l11ll1llll_l1_+l1l111_l1_ (u"ࠫ࠴࠭傋")+end])
		if end: l1ll_l1_.append([5,start+l1l111_l1_ (u"ࠬ࠵ࠧ傌")+l1l11ll1llll_l1_+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ傍")+end])
	elif l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭傎") in end:
		l1l1l11111ll_l1_ = end.replace(l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ傏"),l1l111_l1_ (u"ࠩࠪ傐"))
		l1ll_l1_.append([6,start+l1l111_l1_ (u"ࠪ࠳ࠬ傑")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭傒")+l1l1l11111ll_l1_])
		if not l1l11l11ll11_l1_: l1ll_l1_.append([7,start+l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭傓")+l1l111l1l1l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ傔")+l1l1l11111ll_l1_])
		l1ll_l1_.append([8,start+l1l111_l1_ (u"ࠧ࠰ࠩ傕")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ傖")+l1l1l11111ll_l1_])
	else:
		if not l1l11l11ll11_l1_: l1ll_l1_.append([9,start+l1l111_l1_ (u"ࠩ࠲ࠫ傗")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ傘")])
		if not l1l11l11ll11_l1_: l1ll_l1_.append([10,start+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ備")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ傚")])
		if end: l1ll_l1_.append([11,start+l1l111_l1_ (u"࠭࠯ࠨ傛")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ傜")+end+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ傝")])
		if end: l1ll_l1_.append([12,start+l1l111_l1_ (u"ࠩ࠲ࠫ傞")+l1l111l1l1l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ傟")+end+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ傠")])
	if l1l11l11ll11_l1_ and end:
		end = end.replace(l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭傡"),l1l111_l1_ (u"࠭࠯ࠨ傢"))
		l1ll_l1_.append([13,start+l1l111_l1_ (u"ࠧ࠰ࠩ傣")+end])
		l1ll_l1_.append([14,start+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ傤")+end])
		if l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ傥") in end:
			l1l1l11111ll_l1_ = end.replace(l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ傦"),l1l111_l1_ (u"ࠫࠬ傧"))
			l1ll_l1_.append([15,start+l1l111_l1_ (u"ࠬ࠵ࠧ储")+l1l1l11111ll_l1_])
			l1ll_l1_.append([16,start+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ傩")+l1l1l11111ll_l1_])
		else:
			l1ll_l1_.append([17,start+l1l111_l1_ (u"ࠧ࠰ࠩ傪")+end+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ傫")])
			l1ll_l1_.append([18,start+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ催")+end+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ傭")])
	for l1l1l1111l_l1_,l1ll1ll_l1_ in l1ll_l1_:
		l1lll_l1_[l1l1l1111l_l1_] = [None,None,None]
		threading.Thread(target=l1l1l1l1ll11_l1_,args=(l1l1l1111l_l1_,l1ll1ll_l1_,)).start()
	timeout = 5
	for l1l11l1lll1_l1_ in range(timeout):
		for l1l1l1111l_l1_,l1ll1ll_l1_ in l1ll_l1_:
			if l1lll_l1_[l1l1l1111l_l1_][2]: return l1lll_l1_[l1l1l1111l_l1_]
		time.sleep(1)
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡖࡎࡗࡍࡤ࡞ࡓࡉࡃࡕࡍࡓࡍࠧ傮"),[],[]
def l1l1111ll1l1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭傯"),l1l111_l1_ (u"࠭ࠧ傰"),l1l111_l1_ (u"ࠧࠨ傱"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡎࡒࡅࡉ࡙࠭࠲ࡵࡷࠫ傲"))
	items = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ傳"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ傴"),[l1l111_l1_ (u"ࠫࠬ債")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪ傶"),[],[]
def l1l11l1lll11_l1_(url):
	return l1l111_l1_ (u"࠭ࠧ傷"),[l1l111_l1_ (u"ࠧࠨ傸")],[ url ]
def l1l1l1111ll1_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ傹"))
	basename = l1l111_l1_ (u"ࠩ࠲ࠫ傺").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ傻"),l1l111_l1_ (u"ࠫࠬ傼"),l1l111_l1_ (u"ࠬ࠭傽"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪ傾"))
	items = re.findall(l1l111_l1_ (u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ傿"),html,re.DOTALL)
	if items:
		l1l1lllll1l1_l1_,l1ll1111111l_l1_,l1ll111111l1_l1_,l1l1l11ll11l_l1_,l1l1l11ll1l1_l1_,l1l1l11l1lll_l1_ = items[0]
		var = int(l1ll1111111l_l1_) % int(l1ll111111l1_l1_) + int(l1l1l11ll11l_l1_) % int(l1l1l11ll1l1_l1_)
		url = basename + l1l1lllll1l1_l1_ + str(var) + l1l1l11l1lll_l1_
		return l1l111_l1_ (u"ࠨࠩ僀"),[l1l111_l1_ (u"ࠩࠪ僁")],[url]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ僂"),[],[]
def l1l1l1111l1l_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭僃"))[-1]
	headers = { l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ僄") : l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ僅") }
	payload = { l1l111_l1_ (u"ࠢࡪࡦࠥ僆"):id , l1l111_l1_ (u"ࠣࡱࡳࠦ僇"):l1l111_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ僈") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ僉"), url, payload, headers, l1l111_l1_ (u"ࠫࠬ僊"),l1l111_l1_ (u"ࠬ࠭僋"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ僌"))
	if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ働") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ僎")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࠪ像"),[l1l111_l1_ (u"ࠪࠫ僐")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ僑"),[],[]
def l11lllll1l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭僒"),l1l111_l1_ (u"࠭ࠧ僓"),l1l111_l1_ (u"ࠧࠨ僔"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ僕"))
	items = re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ僖"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ僗"),[l1l111_l1_ (u"ࠫࠬ僘")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ僙"),[],[]
def l1l11111l1ll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ僚"),l1l111_l1_ (u"ࠧࠨ僛"),l1l111_l1_ (u"ࠨࠩ僜"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ僝"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ僞"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ僟") + items[0]
		return l1l111_l1_ (u"ࠬ࠭僠"),[l1l111_l1_ (u"࠭ࠧ僡")],[ url ]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ僢"),[],[]
def l1l1111l1l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ僣"),l1l111_l1_ (u"ࠩࠪ僤"),l1l111_l1_ (u"ࠪࠫ僥"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ僦"))
	items = re.findall(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ僧"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ僨"),[l1l111_l1_ (u"ࠧࠨ僩")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫ僪"),[],[]
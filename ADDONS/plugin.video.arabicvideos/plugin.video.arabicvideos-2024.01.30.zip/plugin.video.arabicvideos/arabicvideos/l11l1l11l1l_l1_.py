# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ䍛")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩ䍜")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ์่ศ฻ࠣหๆ๊วๆࠩ䍝"),l1l111_l1_ (u"ࠬา่ะษอࠤฬ็ไศ็ࠪ䍞")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䍟"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䍠"),l1l111_l1_ (u"ࠨࠩ䍡"),389,l1l111_l1_ (u"ࠩࠪ䍢"),l1l111_l1_ (u"ࠪࠫ䍣"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䍤"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䍥"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䍦"),l1l111_l1_ (u"ࠧࠨ䍧"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍨"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䍩")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ䍪"),l111l1_l1_,381,l1l111_l1_ (u"ࠫࠬ䍫"),l1l111_l1_ (u"ࠬ࠭䍬"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䍭"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍮"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䍯")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัอๆษ์ฬࠫ䍰"),l111l1_l1_,381,l1l111_l1_ (u"ࠪࠫ䍱"),l1l111_l1_ (u"ࠫࠬ䍲"),l1l111_l1_ (u"ࠬࡹࡩࡥࡧࡵࠫ䍳"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䍴"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䍵"),l1l111_l1_ (u"ࠨࠩ䍶"),l1l111_l1_ (u"ࠩࠪ䍷"),l1l111_l1_ (u"ࠪࠫ䍸"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䍹"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䍺"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䍻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䍼")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"ࠨࠩ䍽"),l1l111_l1_ (u"ࠩࠪ䍾"),l1l111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䍿")+str(seq))
	block = l1l111_l1_ (u"ࠫࠬ䎀")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪ䎁"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ䎂"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎃"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䎄"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䎅"),l1l111_l1_ (u"ࠪࠫ䎆"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫ䎇"):
			if first:
				title = l1l111_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ䎈")+title
				first = False
			else: title = l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ䎉")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎊"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䎋")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䎌"),url,l1l111_l1_ (u"ࠪࠫ䎍"),l1l111_l1_ (u"ࠫࠬ䎎"),l1l111_l1_ (u"ࠬ࠭䎏"),l1l111_l1_ (u"࠭ࠧ䎐"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䎑"))
	html = response.content
	if type==l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ䎒"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡦࡸࡣࡩ࠯ࡳࡥ࡬࡫ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭䎓"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎔"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫࡸ࡯ࡤࡦࡴࠪ䎕"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠩ䎖"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎗"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䎘"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡹ࡬ࡪࡦࡨࡶ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲ࡺࡶࡴࡪࡲࡻࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭䎙"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎚"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䎛") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠫࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭䎜"),l1l111_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡸࡺࡡࡳࡶࡁࠫ䎝"))
		html = html.replace(l1l111_l1_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ䎞"),l1l111_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䎟"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡸࡦࡸࡴ࠿ࠪ࠱࠮ࡄ࠯࠼ࡦࡰࡧࡂࠬ䎠"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䎡"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࠫࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࡼࡴ࡫ࡧࡩࡧࡧࡲࠪࠩ䎢"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ䎣") in url:
				items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎤"),block,re.DOTALL)
			elif l1l111_l1_ (u"࠭࠯ࡲࡷࡤࡰ࡮ࡺࡹ࠰ࠩ䎥") in url:
				items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎦"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䎧"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࠨ䎨") in title:
			title = re.findall(l1l111_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎩"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䎪")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠭䎫"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ䎬") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎭"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䎮") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎯"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭䎰") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎱"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ䎲") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎳"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䎴"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡒࡤ࡫ࡪࠦࠨ࠯ࠬࡂ࠭ࠥࡵࡦࠡࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䎵"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦ䎶"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠪࠫ䎷") or title==last: continue
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎸"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䎹")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"࠭ࠧ䎺"),l1l111_l1_ (u"ࠧࠨ䎻"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䎼")+title+l1l111_l1_ (u"ࠩ࠲ࠫ䎽"),l1l111_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪ䎾")+last+l1l111_l1_ (u"ࠫ࠴࠭䎿"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䏀"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯำูࠣๆำษࠡࠩ䏁")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠧࠨ䏂"),l1l111_l1_ (u"ࠨࠩ䏃"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䏄"),url,l1l111_l1_ (u"ࠪࠫ䏅"),l1l111_l1_ (u"ࠫࠬ䏆"),l1l111_l1_ (u"ࠬ࠭䏇"),l1l111_l1_ (u"࠭ࠧ䏈"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䏉"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䏊"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䏋"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ำๅี็ࠤ้๊ใษษิࠤํอไๆสิ้ัࠦๅ็฻๊ࠫ䏌"),l1l111_l1_ (u"ࠫࠬ䏍"),9999)
		return
	if l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ䏎") in url or l1l111_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ䏏") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩ࡬ࡸࡪࡳࠧ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬ䏐"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸ࠭ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡤࡷࡹࠨࠧࠨࠩ䏑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡳࡻ࡭ࡦࡴࡤࡲࡩࡵࠧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫ䏒"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"ࠪࠤ࠿ࠦࠧ䏓")+name+l1l111_l1_ (u"ࠫࠥอไฮๆๅอࠬ䏔")
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䏕"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䏖"),url,l1l111_l1_ (u"ࠧࠨ䏗"),l1l111_l1_ (u"ࠨࠩ䏘"),l1l111_l1_ (u"ࠩࠪ䏙"),l1l111_l1_ (u"ࠪࠫ䏚"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䏛"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䏜"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠧࠨ࡫ࡧࡁࠬࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠧࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁ࠭ࠨࡳࡩࡧࡤࡨࡪࡸࠢࡽࠩࡳࡥ࡬ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࠫࠪࠫࠬ䏝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠢࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡹࡥࡳࡸࡨࡶࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨ䏞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䏟")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䏠")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮࠰ࡧࡱࡵࡳࡦࠤࠪ䏡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡤࡥ࡟ࡥ࡮ࡢ࡫ࡩࡸࡩࡷࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䏢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䏣")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䏤")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䏥"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ䏦"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ䏧"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ䏨"),l1l111_l1_ (u"ࠫ࠰࠭䏩"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䏪")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䏫"))
	return
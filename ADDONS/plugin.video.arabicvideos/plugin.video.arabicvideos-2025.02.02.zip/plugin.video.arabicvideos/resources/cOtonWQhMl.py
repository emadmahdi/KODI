# -*- coding: utf-8 -*-
import sys as IJ97PuaH5Tpj6lcXZNFtCbBoeLG0g
Rol7Avq9zjch2M3KpXk = IJ97PuaH5Tpj6lcXZNFtCbBoeLG0g.version_info [0] == 2
mmEhCU6bBvVf7TMtkFJl1ZQ = 2048
b6bfQWLkMiS5dEmI8rOG2KThHp1xtD = 7
def WIksVNf9AzCJumMXaTdSjPpgo (i5sYxKED7VWXMZScL8Hf):
	global NrXs2gOj8Wmkq9ZSHK3GaL
	XXbwJfg6Lxl = ord (i5sYxKED7VWXMZScL8Hf [-1])
	XX9MfgEsZFmLt2lvb1a3dixC = i5sYxKED7VWXMZScL8Hf [:-1]
	aaUkrXSt8hI = XXbwJfg6Lxl % len (XX9MfgEsZFmLt2lvb1a3dixC)
	G0294RZohqm8QwpKB7cN = XX9MfgEsZFmLt2lvb1a3dixC [:aaUkrXSt8hI] + XX9MfgEsZFmLt2lvb1a3dixC [aaUkrXSt8hI:]
	if Rol7Avq9zjch2M3KpXk:
		UetwvghyK06cpi1fbFMEB8lds3AjY9 = unicode () .join ([unichr (ord (v7SQfpFzx4R6A8bGL0Edsun) - mmEhCU6bBvVf7TMtkFJl1ZQ - (TvChw64caMBjfQmNdesuVPr + XXbwJfg6Lxl) % b6bfQWLkMiS5dEmI8rOG2KThHp1xtD) for TvChw64caMBjfQmNdesuVPr, v7SQfpFzx4R6A8bGL0Edsun in enumerate (G0294RZohqm8QwpKB7cN)])
	else:
		UetwvghyK06cpi1fbFMEB8lds3AjY9 = str () .join ([chr (ord (v7SQfpFzx4R6A8bGL0Edsun) - mmEhCU6bBvVf7TMtkFJl1ZQ - (TvChw64caMBjfQmNdesuVPr + XXbwJfg6Lxl) % b6bfQWLkMiS5dEmI8rOG2KThHp1xtD) for TvChw64caMBjfQmNdesuVPr, v7SQfpFzx4R6A8bGL0Edsun in enumerate (G0294RZohqm8QwpKB7cN)])
	return eval (UetwvghyK06cpi1fbFMEB8lds3AjY9)
M8VAdF5wnUghlODX1jp9BPy,Jv7IT0sq2GljMhLukO4ndambgRBfU,QdlWniS8TFDNoIeB6uh3vzgjGU=WIksVNf9AzCJumMXaTdSjPpgo,WIksVNf9AzCJumMXaTdSjPpgo,WIksVNf9AzCJumMXaTdSjPpgo
Ii6b2t8TNH0CoQ31fJGzuVgWLe,PPTinQrACzxvgFy,CC98gKOXmGvRpIecY=QdlWniS8TFDNoIeB6uh3vzgjGU,Jv7IT0sq2GljMhLukO4ndambgRBfU,M8VAdF5wnUghlODX1jp9BPy
y9ZkPxoregcF,pLxwsUezoI9TEmMCy0Ff2G,xNIebcAmgosqXrpG=CC98gKOXmGvRpIecY,PPTinQrACzxvgFy,Ii6b2t8TNH0CoQ31fJGzuVgWLe
u8kz7oTYIyl,a4R3XTswDnxv,EGa7DUhXBOg4r59Zz8AyY=xNIebcAmgosqXrpG,pLxwsUezoI9TEmMCy0Ff2G,y9ZkPxoregcF
K6BLYDNPkr58OjxaFUnC,wPf4mjbRq7UClhr2kQX,YvkybSZBD1KpLCHgTxm0MeR4c6V7=EGa7DUhXBOg4r59Zz8AyY,a4R3XTswDnxv,u8kz7oTYIyl
NoteTb9ES5Uu,linfXyZe4G2BILPvu1FhAscSo3kKM,LfwOPXR7tIyAV0Wdb5JoqaQlZ4s=YvkybSZBD1KpLCHgTxm0MeR4c6V7,wPf4mjbRq7UClhr2kQX,K6BLYDNPkr58OjxaFUnC
ccenzyb1XxUgVBJ0YlCiWFjkTu,Uvk7PCuSXVdxn0b9I15gERj,WCNeGay0jsdfD=LfwOPXR7tIyAV0Wdb5JoqaQlZ4s,linfXyZe4G2BILPvu1FhAscSo3kKM,NoteTb9ES5Uu
Cx1yiL8mblEBHGO,v3vYTbBsNqxr,hZACVeYiMyUx43LTD=WCNeGay0jsdfD,Uvk7PCuSXVdxn0b9I15gERj,ccenzyb1XxUgVBJ0YlCiWFjkTu
H4HVEQu7gcs2M6N1FGCdflk9xSBat,eCgkbN1foJDhjKB9nuLVptF3Hd,KKR8IWHSvU1pawTsMVQx3CBuJbgy=hZACVeYiMyUx43LTD,v3vYTbBsNqxr,Cx1yiL8mblEBHGO
f96ygTvwCMi8jNlhEmq,ZflQNpykSKmACDad,RZuQlSBep2iaCUjb1vVd9m5n=KKR8IWHSvU1pawTsMVQx3CBuJbgy,eCgkbN1foJDhjKB9nuLVptF3Hd,H4HVEQu7gcs2M6N1FGCdflk9xSBat
qLN0ra3J1u5TtYsFo,dZr9YabfwoWJlHqEx8zjiV65M,ZPjWNALI9ynfcDlevimzSr8hx6025=RZuQlSBep2iaCUjb1vVd9m5n,ZflQNpykSKmACDad,f96ygTvwCMi8jNlhEmq
import xbmc as xawFWLnf2XRdDpMJ10KY3HISUzsAGq,xbmcgui as LWoqdsV4De7TktjRlrK236HSnN,sys as IJ97PuaH5Tpj6lcXZNFtCbBoeLG0g,os as wanjFkGeLvYftcSBU1boQp,requests as FYCl2RSrvwJ3n1o9xp0NGL5ePbDt7,re as gNQ6TI8KXoMqJj5lemBC2D90Uyp,xbmcvfs as UyIGVF8XNg3b1wfDvk4Hr2cnWTx,base64 as UC1fD4BGF52NZeH,time as q67kFEeCOazyL
def yO6zeTHlxQf1ZwKbNV(request):
	zkPcjFQtXe = qLN0ra3J1u5TtYsFo(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩࠀ")
	if request==f96ygTvwCMi8jNlhEmq(u"ࠬࡹࡴࡢࡴࡷࠫࠁ"): xawFWLnf2XRdDpMJ10KY3HISUzsAGq.executebuiltin(hZACVeYiMyUx43LTD(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨࠂ")+zkPcjFQtXe+f96ygTvwCMi8jNlhEmq(u"ࠧࠪࠩࠃ"))
	elif request==hZACVeYiMyUx43LTD(u"ࠨࡵࡷࡳࡵ࠭ࠄ"): xawFWLnf2XRdDpMJ10KY3HISUzsAGq.executebuiltin(EGa7DUhXBOg4r59Zz8AyY(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩࠅ")+zkPcjFQtXe+H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠪ࠭ࠬࠆ"))
	return
def ftCvPcU0JsR9Fhj5qOArmZEVeI(text,hr4A0CSEKxX3y=RZuQlSBep2iaCUjb1vVd9m5n(u"่๊ࠫวࠨࠇ"),cXE76FNMzRjoVO3ri9laD=H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠬ์ูๆࠩࠈ")):
	hhwQ6O34MpGK9bDrzFtdjWf1LHyT = xNIebcAmgosqXrpG(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠉ")
	if npCDhW82JolmS3: NPRzuld05bG8LWHv = LWoqdsV4De7TktjRlrK236HSnN.Dialog().yesno(hhwQ6O34MpGK9bDrzFtdjWf1LHyT,text,Uvk7PCuSXVdxn0b9I15gERj(u"ࠧࠨࠊ"),RZuQlSBep2iaCUjb1vVd9m5n(u"ࠨࠩࠋ"),hr4A0CSEKxX3y,cXE76FNMzRjoVO3ri9laD)
	else: NPRzuld05bG8LWHv = LWoqdsV4De7TktjRlrK236HSnN.Dialog().yesno(hhwQ6O34MpGK9bDrzFtdjWf1LHyT,text,hr4A0CSEKxX3y,cXE76FNMzRjoVO3ri9laD)
	return NPRzuld05bG8LWHv
def EYbGA0FRVlfPahtmdMkcz5JnCH4(*aargs,**kkwargs):
	hhwQ6O34MpGK9bDrzFtdjWf1LHyT = eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠌ")
	return LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(*aargs,**kkwargs)
def ppPvTF2yDVG4b1fLJRUtNm(hhwQ6O34MpGK9bDrzFtdjWf1LHyT=RZuQlSBep2iaCUjb1vVd9m5n(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪࠍ"),rPjd23RX1mw7i=qLN0ra3J1u5TtYsFo(u"ࠫࠬࠎ")):
	Xbk1fQW4d0F = LWoqdsV4De7TktjRlrK236HSnN.Dialog().input(hhwQ6O34MpGK9bDrzFtdjWf1LHyT,rPjd23RX1mw7i,type=LWoqdsV4De7TktjRlrK236HSnN.INPUT_ALPHANUM)
	Xbk1fQW4d0F = Xbk1fQW4d0F.strip(a4R3XTswDnxv(u"ࠬࠦࠧࠏ")).replace(a4R3XTswDnxv(u"࠭ࠠࠡࠢࠣࠫࠐ"),Ii6b2t8TNH0CoQ31fJGzuVgWLe(u"ࠧࠡࠩࠑ")).replace(u8kz7oTYIyl(u"ࠨࠢࠣࠤࠬࠒ"),a4R3XTswDnxv(u"ࠩࠣࠫࠓ")).replace(H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠪࠤࠥ࠭ࠔ"),v3vYTbBsNqxr(u"ࠫࠥ࠭ࠕ"))
	return Xbk1fQW4d0F
def D2DpWx3SvAqrshyk1(ih7XxpHsufPymBbcGrFOnWDRqN):
	NPRzuld05bG8LWHv = ftCvPcU0JsR9Fhj5qOArmZEVeI(Ii6b2t8TNH0CoQ31fJGzuVgWLe(u"่ࠬศๅࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ๊ࠦอสࠣว๋ࠦสี฼็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢฮ๋ะุาࠢะฮ๎ࠦสู้ิࠤ้้ࠠศๆุ่ฬ้ไ๊ࠡส่ศิืศรࠣ࠲࠳ูࠦ็ั๊หู๊ࠥใ๊่ࠤ่๎ฯ๋ࠢหฮุา๊ๅ๊ࠢิ์ࠦวๅ็ืห่๊้ࠠษ็วำ฽วยࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ࠲࠳่ࠦษ฻า๋ฬࠦโๆࠢหษึูวๅࠢึะ้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬวࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠨࠖ"))
	if NPRzuld05bG8LWHv==RZuQlSBep2iaCUjb1vVd9m5n(u"࠵࢚") and wanjFkGeLvYftcSBU1boQp.path.exists(ih7XxpHsufPymBbcGrFOnWDRqN):
		message = ppPvTF2yDVG4b1fLJRUtNm(H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"࠭รไฬหࠤึูวๅฬๆࠤฬ๊ส๋ࠢอี๏ีࠠฦำึห้ํวࠡ็฼ࠤุาไࠡษ็วำ฽วยࠩࠗ"))
		GGFTWRUzt3EIO6P9D71q8pj4NhBc = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.getInfoLabel(v3vYTbBsNqxr(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧ࠘")+ggBU0AuyNl9YJK3WkTHjhd+YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠨࠫࠪ࠙"))
		file = open(ih7XxpHsufPymBbcGrFOnWDRqN,LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠩࡵࡦࠬࠚ"))
		s8YucGb5Kwd = wanjFkGeLvYftcSBU1boQp.path.getsize(ih7XxpHsufPymBbcGrFOnWDRqN)
		if s8YucGb5Kwd>Cx1yiL8mblEBHGO(u"࠸࠶࠱࠱࠲࠳࢛"): file.seek(-Cx1yiL8mblEBHGO(u"࠸࠶࠱࠱࠲࠳࢛"),wanjFkGeLvYftcSBU1boQp.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(ZflQNpykSKmACDad(u"ࠪࡹࡹ࡬࠸ࠨࠛ"))
		I5Ljk0M4orlSizUpTah = gNQ6TI8KXoMqJj5lemBC2D90Uyp.findall(eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠦࠬࡻࡳࡦࡴࡢ࡭ࡩ࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤࠜ"),data,gNQ6TI8KXoMqJj5lemBC2D90Uyp.DOTALL)
		if not I5Ljk0M4orlSizUpTah: I5Ljk0M4orlSizUpTah = gNQ6TI8KXoMqJj5lemBC2D90Uyp.findall(NoteTb9ES5Uu(u"ࠧ࠭ࡵࡴࡧࡵࠫ࠿ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢࠝ"),data,gNQ6TI8KXoMqJj5lemBC2D90Uyp.DOTALL)
		if not I5Ljk0M4orlSizUpTah: I5Ljk0M4orlSizUpTah = gNQ6TI8KXoMqJj5lemBC2D90Uyp.findall(CC98gKOXmGvRpIecY(u"࠭࡜ࡥࡽ࠷ࢁ࠲ࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽࠨࠞ"),data,gNQ6TI8KXoMqJj5lemBC2D90Uyp.DOTALL)
		I5Ljk0M4orlSizUpTah = I5Ljk0M4orlSizUpTah[f96ygTvwCMi8jNlhEmq(u"࠶࢜")] if I5Ljk0M4orlSizUpTah else NoteTb9ES5Uu(u"ࠧ࠱࠲࠳࠴ࠬࠟ")
		I5Ljk0M4orlSizUpTah = I5Ljk0M4orlSizUpTah.split(ZflQNpykSKmACDad(u"ࠨ࡞ࡱࠫࠠ"),v3vYTbBsNqxr(u"࠱࢝"))[EGa7DUhXBOg4r59Zz8AyY(u"࠱࢞")]
		if npCDhW82JolmS3: I5Ljk0M4orlSizUpTah = I5Ljk0M4orlSizUpTah.encode(EGa7DUhXBOg4r59Zz8AyY(u"ࠩࡸࡸ࡫࠾ࠧࠡ"))
		MkQWDI4O0PLy = eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠪࡅ࡛ࡀࠠࠨࠢ")+I5Ljk0M4orlSizUpTah+y9ZkPxoregcF(u"ࠫ࠲ࡋ࡭ࡦࡴࡪࡩࡳࡩࡹࠨࠣ")
		message += Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿࡟ࡲࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬࠤ")+I5Ljk0M4orlSizUpTah+hZACVeYiMyUx43LTD(u"࠭ࠠ࠻ࠩࠥ")+Cx1yiL8mblEBHGO(u"ࠧ࡝ࡰࠪࠦ")+QdlWniS8TFDNoIeB6uh3vzgjGU(u"ࠨࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪࠧ")+GGFTWRUzt3EIO6P9D71q8pj4NhBc+LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠩࠣ࠾ࡡࡴࠧࠨ")
		data = data.encode(QdlWniS8TFDNoIeB6uh3vzgjGU(u"ࠪࡹࡹ࡬࠸ࠨࠩ"))
		eD6OJGc4k8Z5y = UC1fD4BGF52NZeH.b64encode(data)
		fhOJyVYXBraGkWRgtK3c = {v3vYTbBsNqxr(u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬࠪ"):MkQWDI4O0PLy,QdlWniS8TFDNoIeB6uh3vzgjGU(u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ࠫ"):message,ZflQNpykSKmACDad(u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧࠬ"):eD6OJGc4k8Z5y}
		ZcKFsagnjtw1Q5VPfDTHN2 = H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ࠭")
		Gsa37yE2YW4fn = FYCl2RSrvwJ3n1o9xp0NGL5ePbDt7.request(ZflQNpykSKmACDad(u"ࠨࡒࡒࡗ࡙࠭࠮"),ZcKFsagnjtw1Q5VPfDTHN2,data=fhOJyVYXBraGkWRgtK3c)
		if Gsa37yE2YW4fn.status_code==ZflQNpykSKmACDad(u"࠴࠳࠴࢟"): LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(xNIebcAmgosqXrpG(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࠯"),wPf4mjbRq7UClhr2kQX(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠫ࠰"))
		else: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(Uvk7PCuSXVdxn0b9I15gERj(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),ZflQNpykSKmACDad(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤสืำศๆࠣืั๊ࠠศๆฦา฼อมࠨ࠲"))
	return
def cfx12n5JQTY6lHmSy():
	NPRzuld05bG8LWHv = ftCvPcU0JsR9Fhj5qOArmZEVeI(H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"࠭ๅๅใࠣษ฾ีวะษอࠤฬ๊ศา่ส้ั๊ࠦฮฬ๋๎ࠥ฿ไ๊่ࠢ฽้๎ๅศฬࠣฮำ฻ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬ๊ࠡอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้้็ࠠิ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสั่็ࠦๅๅใࠣะิ๐ฯࠡใสี฿ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠳"))
	if NPRzuld05bG8LWHv==M8VAdF5wnUghlODX1jp9BPy(u"࠴ࢠ"):
		Vrd7OB5XDiy3uWPtoRlCLZxcNf = qLN0ra3J1u5TtYsFo(u"ࡘࡷࡻࡥࢯ")
		Y3IkfFegDy = wanjFkGeLvYftcSBU1boQp.path.join(Yv1nbD8pwSmekui,hZACVeYiMyUx43LTD(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࠴"),WCNeGay0jsdfD(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ࠵"),ggBU0AuyNl9YJK3WkTHjhd)
		hsZXLSDxpB68UmdHJqRl4QFCy = wanjFkGeLvYftcSBU1boQp.path.join(Y3IkfFegDy,Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ࠶"))
		if wanjFkGeLvYftcSBU1boQp.path.exists(hsZXLSDxpB68UmdHJqRl4QFCy):
			try: wanjFkGeLvYftcSBU1boQp.remove(hsZXLSDxpB68UmdHJqRl4QFCy)
			except Exception as yB2NkfLFa4Vj: Vrd7OB5XDiy3uWPtoRlCLZxcNf = PPTinQrACzxvgFy(u"ࡋࡧ࡬ࡴࡧࢰ")
		if Vrd7OB5XDiy3uWPtoRlCLZxcNf: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(dZr9YabfwoWJlHqEx8zjiV65M(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࠷"),wPf4mjbRq7UClhr2kQX(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึัࠥอไๆๆไࠫ࠸"))
		else: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠹"),xNIebcAmgosqXrpG(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอ๋ࠥำฮࠢส่๊๊แࠨ࠺"))
	return
def poPKzDJvL9wC8R3NIj1cSduUXn6FHg():
	NPRzuld05bG8LWHv = ftCvPcU0JsR9Fhj5qOArmZEVeI(Uvk7PCuSXVdxn0b9I15gERj(u"ࠧๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤ๏ำส้์ࠣ฽้๏ࠠๆๆไหฯࠦสฯืࠣฮ๋฾๊ๆࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡ็ฮ่๋ࠥไโษอࠤฬ๊ๅโุ็อࠥ๎ๅๅใสฮࠥࡏࡐࡕࡘࠣ์ࠥࡓ࠳ࡖู๋ࠢํืࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢึ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬำ๊โࠡ็ฯ่ิࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠥลࠡࠨ࠻"))
	if NPRzuld05bG8LWHv==YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"࠵ࢡ"):
		if uosmbYLdiRl8aBK7zTyXg: ToARiNupvJqWwKaOb6IB = UyIGVF8XNg3b1wfDvk4Hr2cnWTx.translatePath(Uvk7PCuSXVdxn0b9I15gERj(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩ࠼"))
		else: ToARiNupvJqWwKaOb6IB = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.translatePath(Cx1yiL8mblEBHGO(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ࠽"))
		ezhUkS3I8gRtAK45OMXvs1apDnZL = wanjFkGeLvYftcSBU1boQp.path.join(ToARiNupvJqWwKaOb6IB,ggBU0AuyNl9YJK3WkTHjhd)
		Vrd7OB5XDiy3uWPtoRlCLZxcNf = ddiMuQmPywpNgOkxq9jn60JT1(ezhUkS3I8gRtAK45OMXvs1apDnZL,u8kz7oTYIyl(u"ࡔࡳࡷࡨࢲ"),CC98gKOXmGvRpIecY(u"ࡌࡡ࡭ࡵࡨࢱ"))
		if Vrd7OB5XDiy3uWPtoRlCLZxcNf: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(xNIebcAmgosqXrpG(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࠾"),EGa7DUhXBOg4r59Zz8AyY(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠿"))
		else: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(K6BLYDNPkr58OjxaFUnC(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡀ"),M8VAdF5wnUghlODX1jp9BPy(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่ࠢะ้ีࠠไษืࠤฬ๊ศา่ส้ั࠭ࡁ"))
	return
def ddiMuQmPywpNgOkxq9jn60JT1(AWeu9q8c4NUTtSxy,h2mXcZYkfJW3FioC90E4nT,ZmtHQ4lLj8nhdKRq9FeP):
	if ZmtHQ4lLj8nhdKRq9FeP:
		NPRzuld05bG8LWHv = ftCvPcU0JsR9Fhj5qOArmZEVeI(Uvk7PCuSXVdxn0b9I15gERj(u"ࠧࠨࡂ"),Uvk7PCuSXVdxn0b9I15gERj(u"ࠨࠩࡃ"),ccenzyb1XxUgVBJ0YlCiWFjkTu(u"ࠩࠪࡄ"),LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡅ"),AWeu9q8c4NUTtSxy+WCNeGay0jsdfD(u"ࠫࡡࡴ࡜࡯้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ฬๅัࠣรࠦ࠭ࡆ"))
		if NPRzuld05bG8LWHv!=vvu4xf0iEDYOdNoQBjS: return
	Vrd7OB5XDiy3uWPtoRlCLZxcNf = RZuQlSBep2iaCUjb1vVd9m5n(u"ࡕࡴࡸࡩࢳ")
	if wanjFkGeLvYftcSBU1boQp.path.exists(AWeu9q8c4NUTtSxy):
		for ZZbywuHkB3t41zQATLJisKergE7FlG,c5cK4Gv3uEUIQyH67pmskO2ZiBxrPJ,k1Gv7Woi9Ag2VUEeFLN0 in wanjFkGeLvYftcSBU1boQp.walk(AWeu9q8c4NUTtSxy,topdown=YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࡈࡤࡰࡸ࡫ࢴ")):
			for djxNsJnveWZVtgqY5 in k1Gv7Woi9Ag2VUEeFLN0:
				odY28REUWsFQ6wJhktL5NrC9OK = wanjFkGeLvYftcSBU1boQp.path.join(ZZbywuHkB3t41zQATLJisKergE7FlG,djxNsJnveWZVtgqY5)
				try: wanjFkGeLvYftcSBU1boQp.remove(odY28REUWsFQ6wJhktL5NrC9OK)
				except Exception as MrGeN7AOg4kZ3cWLK:
					if ZmtHQ4lLj8nhdKRq9FeP and Vrd7OB5XDiy3uWPtoRlCLZxcNf: EYbGA0FRVlfPahtmdMkcz5JnCH4(pLxwsUezoI9TEmMCy0Ff2G(u"ࠬ࠭ࡇ"),NoteTb9ES5Uu(u"࠭ࠧࡈ"),YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࡉ"),str(MrGeN7AOg4kZ3cWLK))
					Vrd7OB5XDiy3uWPtoRlCLZxcNf = ZPjWNALI9ynfcDlevimzSr8hx6025(u"ࡉࡥࡱࡹࡥࢵ")
			if h2mXcZYkfJW3FioC90E4nT:
				for SSuxJVw0soR3qQ7aMz in c5cK4Gv3uEUIQyH67pmskO2ZiBxrPJ:
					Rqv7C04iyD2 = wanjFkGeLvYftcSBU1boQp.path.join(ZZbywuHkB3t41zQATLJisKergE7FlG,SSuxJVw0soR3qQ7aMz)
					try: wanjFkGeLvYftcSBU1boQp.rmdir(Rqv7C04iyD2)
					except: pass
		if h2mXcZYkfJW3FioC90E4nT:
			try: wanjFkGeLvYftcSBU1boQp.rmdir(ZZbywuHkB3t41zQATLJisKergE7FlG)
			except: pass
	if ZmtHQ4lLj8nhdKRq9FeP and Vrd7OB5XDiy3uWPtoRlCLZxcNf: EYbGA0FRVlfPahtmdMkcz5JnCH4(qLN0ra3J1u5TtYsFo(u"ࠨࠩࡊ"),dZr9YabfwoWJlHqEx8zjiV65M(u"ࠩࠪࡋ"),KKR8IWHSvU1pawTsMVQx3CBuJbgy(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡌ"),LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡍ"))
	return Vrd7OB5XDiy3uWPtoRlCLZxcNf
def uRs48dC0EraiztHBjIyJx5ewG3Vq():
	ZcKFsagnjtw1Q5VPfDTHN2 = M8VAdF5wnUghlODX1jp9BPy(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ࡎ")
	Gsa37yE2YW4fn = FYCl2RSrvwJ3n1o9xp0NGL5ePbDt7.request(QdlWniS8TFDNoIeB6uh3vzgjGU(u"࠭ࡇࡆࡖࠪࡏ"),ZcKFsagnjtw1Q5VPfDTHN2)
	g3aDnMSAxQyL = Gsa37yE2YW4fn.content
	g3aDnMSAxQyL = g3aDnMSAxQyL.decode(linfXyZe4G2BILPvu1FhAscSo3kKM(u"ࠧࡶࡶࡩ࠼ࠬࡐ"))
	k1Gv7Woi9Ag2VUEeFLN0 = gNQ6TI8KXoMqJj5lemBC2D90Uyp.findall(Ii6b2t8TNH0CoQ31fJGzuVgWLe(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨ࠯ࠬࡂ࠭࠳ࢀࡩࡱࠤࠪࡑ"),g3aDnMSAxQyL,gNQ6TI8KXoMqJj5lemBC2D90Uyp.DOTALL)
	k1Gv7Woi9Ag2VUEeFLN0 = sorted(k1Gv7Woi9Ag2VUEeFLN0,reverse=WCNeGay0jsdfD(u"ࡘࡷࡻࡥࢶ"))
	uq1ilx2cR49fLpE0SwJ8j = LWoqdsV4De7TktjRlrK236HSnN.Dialog().select(ZflQNpykSKmACDad(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫࡒ"),k1Gv7Woi9Ag2VUEeFLN0)
	if uq1ilx2cR49fLpE0SwJ8j==-EGa7DUhXBOg4r59Zz8AyY(u"࠶ࢢ"): return
	filename = k1Gv7Woi9Ag2VUEeFLN0[uq1ilx2cR49fLpE0SwJ8j]
	if npCDhW82JolmS3: filename = filename.encode(YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠪࡹࡹ࡬࠸ࠨࡓ"))
	HA1R6enGFzp0J5fhykqirjdW = ZcKFsagnjtw1Q5VPfDTHN2.rsplit(y9ZkPxoregcF(u"ࠫ࠴࠭ࡔ"),KKR8IWHSvU1pawTsMVQx3CBuJbgy(u"࠷ࢣ"))[LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"࠰ࢤ")]+f96ygTvwCMi8jNlhEmq(u"ࠬ࠵ࠧࡕ")+pLxwsUezoI9TEmMCy0Ff2G(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠭ࡖ")+filename+eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠧ࠯ࡼ࡬ࡴࠬࡗ")
	Vrd7OB5XDiy3uWPtoRlCLZxcNf = WCNeGay0jsdfD(u"ࡋࡧ࡬ࡴࡧࢷ")
	Gsa37yE2YW4fn = FYCl2RSrvwJ3n1o9xp0NGL5ePbDt7.request(v3vYTbBsNqxr(u"ࠨࡉࡈࡘࠬࡘ"),HA1R6enGFzp0J5fhykqirjdW)
	if Gsa37yE2YW4fn.status_code==WCNeGay0jsdfD(u"࠳࠲࠳ࢥ"):
		uuqOfYMhUpGeLJ = Gsa37yE2YW4fn.content
		import zipfile as UOa4XipnVjNZ,io as ihmuM7Pc4SLq1O2Gewn9Y35
		WsMopR9gOP5TkK21jZ = ihmuM7Pc4SLq1O2Gewn9Y35.BytesIO(uuqOfYMhUpGeLJ)
		euyhbakOP6B1WdGf7iDpX4xRrnT = wanjFkGeLvYftcSBU1boQp.path.join(Yv1nbD8pwSmekui,ccenzyb1XxUgVBJ0YlCiWFjkTu(u"ࠩࡤࡨࡩࡵ࡮ࡴ࡙ࠩ"))
		ssEcH1yC3l4xWqSR2oLJaTve = wanjFkGeLvYftcSBU1boQp.path.join(euyhbakOP6B1WdGf7iDpX4xRrnT,ggBU0AuyNl9YJK3WkTHjhd)
		ddiMuQmPywpNgOkxq9jn60JT1(ssEcH1yC3l4xWqSR2oLJaTve,ccenzyb1XxUgVBJ0YlCiWFjkTu(u"ࡔࡳࡷࡨࢹ"),M8VAdF5wnUghlODX1jp9BPy(u"ࡌࡡ࡭ࡵࡨࢸ"))
		AkuaR0jNsUXHmF64nM19opy = UOa4XipnVjNZ.ZipFile(WsMopR9gOP5TkK21jZ)
		AkuaR0jNsUXHmF64nM19opy.extractall(euyhbakOP6B1WdGf7iDpX4xRrnT)
		q67kFEeCOazyL.sleep(y9ZkPxoregcF(u"࠳ࢦ"))
		xawFWLnf2XRdDpMJ10KY3HISUzsAGq.executebuiltin(WCNeGay0jsdfD(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹ࡚ࠧ"))
		q67kFEeCOazyL.sleep(WCNeGay0jsdfD(u"࠴ࢧ"))
		KsG1fiqVlR = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.executeJSONRPC(v3vYTbBsNqxr(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨ࡛ࠧ")+ggBU0AuyNl9YJK3WkTHjhd+hZACVeYiMyUx43LTD(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ࡜"))
		if K6BLYDNPkr58OjxaFUnC(u"࠭ࡏࡌࠩ࡝") in KsG1fiqVlR: Vrd7OB5XDiy3uWPtoRlCLZxcNf = LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࡕࡴࡸࡩࢺ")
	if Vrd7OB5XDiy3uWPtoRlCLZxcNf:
		LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࡞"),xNIebcAmgosqXrpG(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลึัสีࠥอไใัํ้ࠥࡢ࡮࡝ࡰࠣࠫ࡟")+filename)
		msg = ZPjWNALI9ynfcDlevimzSr8hx6025(u"ࠩะฮ๎๊ࠦษไ์ࠤฬ๊ลึัสีࠥอไใัํ้ࠥ็๊ࠡฮ๊หื้้ࠠๆสࠤ๏ะๅࠡฬะำ๏ั็ࠡล๋ฮํ๋วห์ๆ๎ฬࠦ࠮࠯ࠢํะอࠦร็ࠢอๆํ๋ࠠษวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ็ฬึ์วๆฮࠣรࠦ࠭ࡠ")
		uhf85yabqtFZlmX6iWAC4LRE(msg)
	else: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(Uvk7PCuSXVdxn0b9I15gERj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡡ"),ccenzyb1XxUgVBJ0YlCiWFjkTu(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฻ฯศำࠣห้่ฯ๋็ࠣࡠࡳࡢ࡮ࠡࠩࡢ")+filename)
	return
def uhf85yabqtFZlmX6iWAC4LRE(msg=M8VAdF5wnUghlODX1jp9BPy(u"ࠬํไࠡฬิ๎ิࠦสี฼ํ่ࠥษ่ࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅๆหี๋อๅอࠢยࠥࠬࡣ")):
	NPRzuld05bG8LWHv = ftCvPcU0JsR9Fhj5qOArmZEVeI(msg,ZflQNpykSKmACDad(u"࠭ล๋ไสๅࠥอไหฯา๎ะ࠭ࡤ"),KKR8IWHSvU1pawTsMVQx3CBuJbgy(u"ࠧหฯา๎ะࠦร้ฬ๋้ฬะ๊ไ์ࠪࡥ"))
	if NPRzuld05bG8LWHv==-KKR8IWHSvU1pawTsMVQx3CBuJbgy(u"࠵ࢨ"): return
	Hn3r5GcNWlMJxSAsXREm = a4R3XTswDnxv(u"ࠨࡧࡱࡥࡧࡲࡥࠨࡦ") if NPRzuld05bG8LWHv else YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪࡧ")
	if uosmbYLdiRl8aBK7zTyXg: cU0ryVMp8WKDmldRsFzBb2uqIe9NSg = wanjFkGeLvYftcSBU1boQp.path.join(Yv1nbD8pwSmekui,f96ygTvwCMi8jNlhEmq(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࡨ"),Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ࡩ"),EGa7DUhXBOg4r59Zz8AyY(u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪࡪ"))
	else: cU0ryVMp8WKDmldRsFzBb2uqIe9NSg = wanjFkGeLvYftcSBU1boQp.path.join(Yv1nbD8pwSmekui,ccenzyb1XxUgVBJ0YlCiWFjkTu(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ࡫"),eCgkbN1foJDhjKB9nuLVptF3Hd(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ࡬"),linfXyZe4G2BILPvu1FhAscSo3kKM(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭࡭"))
	import sqlite3 as LrbhTz9Z5aK
	Vrd7OB5XDiy3uWPtoRlCLZxcNf = y9ZkPxoregcF(u"ࡈࡤࡰࡸ࡫ࢻ")
	i0iA2qhv6rpBJbcRDsZ3 = YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ࡮")
	cJpGUPTC6X1ayIkx2B = u8kz7oTYIyl(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭࡯") if npCDhW82JolmS3 else H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪࡰ")
	try:
		HOQREMj9SToV6Uh = LrbhTz9Z5aK.connect(cU0ryVMp8WKDmldRsFzBb2uqIe9NSg)
		HOQREMj9SToV6Uh.text_factory = str
		MySnND5VXHqTPE = HOQREMj9SToV6Uh.cursor()
		MySnND5VXHqTPE.execute(WCNeGay0jsdfD(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡱ")+ggBU0AuyNl9YJK3WkTHjhd+EGa7DUhXBOg4r59Zz8AyY(u"࠭ࠢࠡ࠽ࠪࡲ"))
		NN1JaMfdn7ZwrDsxuY = MySnND5VXHqTPE.fetchall()
		if NN1JaMfdn7ZwrDsxuY and i0iA2qhv6rpBJbcRDsZ3 not in str(NN1JaMfdn7ZwrDsxuY): MySnND5VXHqTPE.execute(Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫࡳ")+i0iA2qhv6rpBJbcRDsZ3+WCNeGay0jsdfD(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࡴ")+ggBU0AuyNl9YJK3WkTHjhd+LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠩࠥࠤࡀ࠭ࡵ"))
		MySnND5VXHqTPE.execute(KKR8IWHSvU1pawTsMVQx3CBuJbgy(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫࡶ")+cJpGUPTC6X1ayIkx2B+YvkybSZBD1KpLCHgTxm0MeR4c6V7(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩࡷ")+ggBU0AuyNl9YJK3WkTHjhd+QdlWniS8TFDNoIeB6uh3vzgjGU(u"ࠬࠨࠠ࠼ࠩࡸ"))
		NN1JaMfdn7ZwrDsxuY = MySnND5VXHqTPE.fetchall()
		W43VS0sPmpj2wfHJOzMFDN = f96ygTvwCMi8jNlhEmq(u"ࡊࡦࡲࡳࡦࢽ") if NN1JaMfdn7ZwrDsxuY else y9ZkPxoregcF(u"ࡗࡶࡺ࡫ࢼ")
		if not W43VS0sPmpj2wfHJOzMFDN and qLN0ra3J1u5TtYsFo(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭ࡹ") in Hn3r5GcNWlMJxSAsXREm: MySnND5VXHqTPE.execute(wPf4mjbRq7UClhr2kQX(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࠭ࡺ")+cJpGUPTC6X1ayIkx2B+hZACVeYiMyUx43LTD(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࡻ")+ggBU0AuyNl9YJK3WkTHjhd+xNIebcAmgosqXrpG(u"ࠩࠥࠤࡀ࠭ࡼ"))
		elif W43VS0sPmpj2wfHJOzMFDN and M8VAdF5wnUghlODX1jp9BPy(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࠫࡽ") in Hn3r5GcNWlMJxSAsXREm:
			if npCDhW82JolmS3: MySnND5VXHqTPE.execute(QdlWniS8TFDNoIeB6uh3vzgjGU(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡾ")+cJpGUPTC6X1ayIkx2B+H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬࡿ")+ggBU0AuyNl9YJK3WkTHjhd+ccenzyb1XxUgVBJ0YlCiWFjkTu(u"࠭ࠢࠪࠢ࠾ࠫࢀ"))
			else: MySnND5VXHqTPE.execute(M8VAdF5wnUghlODX1jp9BPy(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ࢁ")+cJpGUPTC6X1ayIkx2B+Ii6b2t8TNH0CoQ31fJGzuVgWLe(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬࢂ")+ggBU0AuyNl9YJK3WkTHjhd+ccenzyb1XxUgVBJ0YlCiWFjkTu(u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩࢃ"))
		HOQREMj9SToV6Uh.commit()
		HOQREMj9SToV6Uh.close()
		Vrd7OB5XDiy3uWPtoRlCLZxcNf = M8VAdF5wnUghlODX1jp9BPy(u"࡙ࡸࡵࡦࢾ")
	except: pass
	if Vrd7OB5XDiy3uWPtoRlCLZxcNf:
		q67kFEeCOazyL.sleep(PPTinQrACzxvgFy(u"࠶ࢩ"))
		xawFWLnf2XRdDpMJ10KY3HISUzsAGq.executebuiltin(H4HVEQu7gcs2M6N1FGCdflk9xSBat(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧࢄ"))
		q67kFEeCOazyL.sleep(CC98gKOXmGvRpIecY(u"࠷ࢪ"))
		LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢅ"),a4R3XTswDnxv(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣห้฿ๅๅ์ฬࠫࢆ"))
	else: LWoqdsV4De7TktjRlrK236HSnN.Dialog().ok(Uvk7PCuSXVdxn0b9I15gERj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢇ"),xNIebcAmgosqXrpG(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะࠠศๆ฼้้๐ษࠨ࢈"))
	return
yO6zeTHlxQf1ZwKbNV(u8kz7oTYIyl(u"ࠨࡵࡷࡥࡷࡺࠧࢉ"))
Ty2DR6vSdlMr = IJ97PuaH5Tpj6lcXZNFtCbBoeLG0g.argv[RZuQlSBep2iaCUjb1vVd9m5n(u"࠱ࢫ")]
ggBU0AuyNl9YJK3WkTHjhd = EGa7DUhXBOg4r59Zz8AyY(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧࢊ")
s3seiDFQ5P = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.getInfoLabel(PPTinQrACzxvgFy(u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤࢋ"))
KoNQIRJ4i57sUedVl9ZvX6bmP = gNQ6TI8KXoMqJj5lemBC2D90Uyp.findall(a4R3XTswDnxv(u"ࠫ࠭ࡢࡤ࡝ࡦ࡟࠲ࡡࡪࠩࠨࢌ"),s3seiDFQ5P,gNQ6TI8KXoMqJj5lemBC2D90Uyp.DOTALL)
KoNQIRJ4i57sUedVl9ZvX6bmP = float(KoNQIRJ4i57sUedVl9ZvX6bmP[v3vYTbBsNqxr(u"࠱ࢬ")])
npCDhW82JolmS3 = KoNQIRJ4i57sUedVl9ZvX6bmP<K6BLYDNPkr58OjxaFUnC(u"࠳࠼ࢭ")
uosmbYLdiRl8aBK7zTyXg = KoNQIRJ4i57sUedVl9ZvX6bmP>NoteTb9ES5Uu(u"࠴࠼࠳࠿࠹ࢮ")
if uosmbYLdiRl8aBK7zTyXg:
	PPvtgxfbEV9LHpnZj = UyIGVF8XNg3b1wfDvk4Hr2cnWTx.translatePath(EGa7DUhXBOg4r59Zz8AyY(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	Yv1nbD8pwSmekui = UyIGVF8XNg3b1wfDvk4Hr2cnWTx.translatePath(ccenzyb1XxUgVBJ0YlCiWFjkTu(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
else:
	PPvtgxfbEV9LHpnZj = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.translatePath(LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫ࢏"))
	Yv1nbD8pwSmekui = xawFWLnf2XRdDpMJ10KY3HISUzsAGq.translatePath(f96ygTvwCMi8jNlhEmq(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ࢐"))
TLZd74QR1Dyob2Iu9PzSeEtfmcixO5 = wanjFkGeLvYftcSBU1boQp.path.join(PPvtgxfbEV9LHpnZj,y9ZkPxoregcF(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢑"))
b2hf4eJDkvGWp9dmBLNuoj = wanjFkGeLvYftcSBU1boQp.path.join(PPvtgxfbEV9LHpnZj,RZuQlSBep2iaCUjb1vVd9m5n(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ࢒"))
if   Ty2DR6vSdlMr==y9ZkPxoregcF(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪ࢓")		: D2DpWx3SvAqrshyk1(TLZd74QR1Dyob2Iu9PzSeEtfmcixO5)
elif Ty2DR6vSdlMr==wPf4mjbRq7UClhr2kQX(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨ࢔")	: D2DpWx3SvAqrshyk1(b2hf4eJDkvGWp9dmBLNuoj)
elif Ty2DR6vSdlMr==M8VAdF5wnUghlODX1jp9BPy(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ࢕")		: cfx12n5JQTY6lHmSy()
elif Ty2DR6vSdlMr==Jv7IT0sq2GljMhLukO4ndambgRBfU(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭࢖")		: poPKzDJvL9wC8R3NIj1cSduUXn6FHg()
elif Ty2DR6vSdlMr==LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡡࡲࡰࡩࡥࡶࡦࡴࡶ࡭ࡴࡴࠧࢗ")	: uRs48dC0EraiztHBjIyJx5ewG3Vq()
elif Ty2DR6vSdlMr==NoteTb9ES5Uu(u"ࠩࡰࡳࡩ࡯ࡦࡺࡡࡤࡹࡹࡵࡵࡱࡦࡤࡸࡪ࠭࢘")	: uhf85yabqtFZlmX6iWAC4LRE()
yO6zeTHlxQf1ZwKbNV(LfwOPXR7tIyAV0Wdb5JoqaQlZ4s(u"ࠪࡷࡹࡵࡰࠨ࢙"))
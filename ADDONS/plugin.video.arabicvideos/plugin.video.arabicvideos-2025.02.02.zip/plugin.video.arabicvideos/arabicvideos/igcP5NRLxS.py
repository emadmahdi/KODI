# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'CIMANOW'
LJfTAEQPv9h4BXdwUp = '_CMN_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['قائمتي']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==300: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==301: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==302: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==303: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = fxdz47XjOWTDnGJ6Zw1cvItbm(url)
	elif mode==304: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==305: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==306: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = FVCR1rfbYZHGLBP()
	elif mode==309: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,309,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/home',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<header>(.*?)</header>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('<li><a href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,301)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/home',LMKFcEkU1Q7R80yt4OsgvwxbfP)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def FVCR1rfbYZHGLBP():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url,LMKFcEkU1Q7R80yt4OsgvwxbfP=NdKhAS6MXVEORLTwob92pxlZ):
	if not LMKFcEkU1Q7R80yt4OsgvwxbfP:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-SUBMENU-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	rAknWUHpDyi4IuGPfl2QYR = 0
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(<section>.*?</section>)',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		for AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			rAknWUHpDyi4IuGPfl2QYR += 1
			items = YYqECUofyi7wFrW.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for title,bbLNUlgcd6H0rF9xji5pPD1JKE,zehVcU893FC6LEd1Aij in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				if title==NdKhAS6MXVEORLTwob92pxlZ: title = 'بووووو'
				if 'em><a' not in bbLNUlgcd6H0rF9xji5pPD1JKE:
					if AAMHoYxRCmt2D6ph89W.count('/category/')>0:
						y9yRCdrFtNfpULEqWQiGBK5HTI2JVu = YYqECUofyi7wFrW.findall('href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						for zehVcU893FC6LEd1Aij in y9yRCdrFtNfpULEqWQiGBK5HTI2JVu:
							title = zehVcU893FC6LEd1Aij.split('/')[-2]
							ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,301)
						continue
					else: zehVcU893FC6LEd1Aij = url+'?sequence='+str(rAknWUHpDyi4IuGPfl2QYR)
				if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,302)
	else: hGJKk8tAiC3XFufEpqavQWmwTHdL(url,LMKFcEkU1Q7R80yt4OsgvwxbfP)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,LMKFcEkU1Q7R80yt4OsgvwxbfP=NdKhAS6MXVEORLTwob92pxlZ):
	if LMKFcEkU1Q7R80yt4OsgvwxbfP==NdKhAS6MXVEORLTwob92pxlZ:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-TITLES-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if '?sequence=' in url:
		url,rAknWUHpDyi4IuGPfl2QYR = url.split('?sequence=')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(<section>.*?</section>)',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[int(rAknWUHpDyi4IuGPfl2QYR)-1]
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"posts"(.*?)</body>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for zehVcU893FC6LEd1Aij,data,TTuPH708dUNnjlG3oQpkZsi in items:
		title = YYqECUofyi7wFrW.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,YYqECUofyi7wFrW.DOTALL)
		if title: title = title[0][2].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if not title or title==NdKhAS6MXVEORLTwob92pxlZ:
			title = YYqECUofyi7wFrW.findall('title">.*?</em>(.*?)<',data,YYqECUofyi7wFrW.DOTALL)
			if title: title = title[0].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if not title or title==NdKhAS6MXVEORLTwob92pxlZ:
				title = YYqECUofyi7wFrW.findall('title">(.*?)<',data,YYqECUofyi7wFrW.DOTALL)
				title = title[0].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		title = title.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if title not in zIDPZSNn1OuweLHvmMKb6d:
			zIDPZSNn1OuweLHvmMKb6d.append(title)
			zyoNRs5F72Bkr0JYfGh6PULju4bO = zehVcU893FC6LEd1Aij+data+TTuPH708dUNnjlG3oQpkZsi
			if '/selary/' in zyoNRs5F72Bkr0JYfGh6PULju4bO or 'مسلسل' in zyoNRs5F72Bkr0JYfGh6PULju4bO or '"episode"' in zyoNRs5F72Bkr0JYfGh6PULju4bO:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,303,TTuPH708dUNnjlG3oQpkZsi)
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,305,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('<li><a href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,302)
	return
def fxdz47XjOWTDnGJ6Zw1cvItbm(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-SEASONS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	name = YYqECUofyi7wFrW.findall('<title>(.*?)</title>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	name = name[0].replace('| سيما ناو',NdKhAS6MXVEORLTwob92pxlZ).replace('Cima Now',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	name = name.split('الحلقة')[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<section(.*?)</section>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if len(items)>1:
			for zehVcU893FC6LEd1Aij,title in items:
				title = name+' - '+title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,304)
		else: vl57jIYC4a(url)
	return
def vl57jIYC4a(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if '/selary/' not in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"episodes"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			title = 'الحلقة '+title
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,305)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"details"(.*?)"related"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,305,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url+'watching/'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMANOW-PLAY-5th')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	UTwH7zjZOrmFl = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"download"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			a0ao2jdlt4r9nhHwpvSgOVGA = YYqECUofyi7wFrW.findall('\d\d\d+',title,YYqECUofyi7wFrW.DOTALL)
			if a0ao2jdlt4r9nhHwpvSgOVGA:
				a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA[0]
				title = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
			else: a0ao2jdlt4r9nhHwpvSgOVGA = NdKhAS6MXVEORLTwob92pxlZ
			xKXbWz9coR7jUfil45aQENr0ICBJg = zehVcU893FC6LEd1Aij+'?named='+title+'__download'+a0ao2jdlt4r9nhHwpvSgOVGA
			UTwH7zjZOrmFl.append(xKXbWz9coR7jUfil45aQENr0ICBJg)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"watch"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('"embed".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij in oDhlaxn0EqyYikcHrmZBN8uv:
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
			title = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__embed'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		oDhlaxn0EqyYikcHrmZBN8uv = [qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/wp-content/themes/Cima%20Now%20New/core.php']
		if oDhlaxn0EqyYikcHrmZBN8uv:
			items = YYqECUofyi7wFrW.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for Xd8PpnWk1RlgzSmuNjtK3,id,title in items:
				title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[0]+'?action=switch&index='+Xd8PpnWk1RlgzSmuNjtK3+'&id='+id+'?named='+title+'__watch'
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
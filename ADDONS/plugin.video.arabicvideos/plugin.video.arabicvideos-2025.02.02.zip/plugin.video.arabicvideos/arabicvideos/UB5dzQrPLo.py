﻿# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ALMAAREF'
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
LJfTAEQPv9h4BXdwUp = '_MRF_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def QGLoruqnmiAel7Op(mode,url,text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	if   mode==40: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==41: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dbe3CzcI4ywG0jDmfY8HSxsqp()
	elif mode==42: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = aZ3fE5iR2r0dncpLwPvbWXhoMkuAIy(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==43: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==44: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==49: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,49)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'البث الحي لقناة المعارف',NdKhAS6MXVEORLTwob92pxlZ,41)
	aZ3fE5iR2r0dncpLwPvbWXhoMkuAIy(NdKhAS6MXVEORLTwob92pxlZ,'1')
	return
def nZwGQHStp65q3smAeFLB(LM1WpcGdrz8QtHV0i53k,SYnTs3f05cOUIC2kdmPoM8KeZ):
	search,sort,ggEX5wBNHj4F,II4s1CdgcbN6BSvWPnHtz,QjAdrV4gsFyubOChw = NdKhAS6MXVEORLTwob92pxlZ,[],[],[],[]
	gHbS3MaYo0j6uTdm2qyQnKP,QKIvlfAUdsmnFt2 = muYp09a1NhMo7cZng5IOXyTSKt4qv2(LM1WpcGdrz8QtHV0i53k)
	for X9dRM31pz6y in list(QKIvlfAUdsmnFt2.keys()):
		K6KbZDHncNizQgl1fr59XV0 = QKIvlfAUdsmnFt2[X9dRM31pz6y]
		if not K6KbZDHncNizQgl1fr59XV0: continue
		if   X9dRM31pz6y=='sort': sort = [K6KbZDHncNizQgl1fr59XV0]
		elif X9dRM31pz6y=='series': ggEX5wBNHj4F = [K6KbZDHncNizQgl1fr59XV0]
		elif X9dRM31pz6y=='search': search = K6KbZDHncNizQgl1fr59XV0
		elif X9dRM31pz6y=='category': II4s1CdgcbN6BSvWPnHtz = [K6KbZDHncNizQgl1fr59XV0]
		elif X9dRM31pz6y=='specialist': QjAdrV4gsFyubOChw = [K6KbZDHncNizQgl1fr59XV0]
	YWsjNtDXPAgCya = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":II4s1CdgcbN6BSvWPnHtz,"specialist":QjAdrV4gsFyubOChw,"series":ggEX5wBNHj4F,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(SYnTs3f05cOUIC2kdmPoM8KeZ)}}
	YWsjNtDXPAgCya = O3OogF1l5reuQ.dumps(YWsjNtDXPAgCya)
	zehVcU893FC6LEd1Aij = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',zehVcU893FC6LEd1Aij,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	data = BdnA8WwtJeKUVvE('dict',LMKFcEkU1Q7R80yt4OsgvwxbfP)
	return data
def aZ3fE5iR2r0dncpLwPvbWXhoMkuAIy(LM1WpcGdrz8QtHV0i53k,level):
	sCRbZp6Irl17v = nZwGQHStp65q3smAeFLB(LM1WpcGdrz8QtHV0i53k,'1')
	AAMHoYxRCmt2D6ph89W = sCRbZp6Irl17v['facets']
	if level=='1':
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W['video_categories']
		items = YYqECUofyi7wFrW.findall('<div(.*?)/div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for rMOG2USkPesYZD9KNAVqpc in items:
			ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',rMOG2USkPesYZD9KNAVqpc+'<',YYqECUofyi7wFrW.DOTALL)
			if not ekmszoF6UQAbHp9r0ug: ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall('data-value=\\"(.*?)\\">(.*?)<',rMOG2USkPesYZD9KNAVqpc+'<',YYqECUofyi7wFrW.DOTALL)
			II4s1CdgcbN6BSvWPnHtz,title = ekmszoF6UQAbHp9r0ug[0]
			if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
			if not LM1WpcGdrz8QtHV0i53k: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,42,NdKhAS6MXVEORLTwob92pxlZ,'2','?category='+II4s1CdgcbN6BSvWPnHtz)
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,42,NdKhAS6MXVEORLTwob92pxlZ,'2',LM1WpcGdrz8QtHV0i53k+'&category='+II4s1CdgcbN6BSvWPnHtz)
	if level=='2':
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W['specialist']
		items = YYqECUofyi7wFrW.findall('value="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for QjAdrV4gsFyubOChw,title in items:
			if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
			if not QjAdrV4gsFyubOChw: title = title = 'الجميع'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,42,NdKhAS6MXVEORLTwob92pxlZ,'3',LM1WpcGdrz8QtHV0i53k+'&specialist='+QjAdrV4gsFyubOChw)
	elif level=='3':
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W['series']
		items = YYqECUofyi7wFrW.findall('value="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for ggEX5wBNHj4F,title in items:
			if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
			if not ggEX5wBNHj4F: title = title = 'الجميع'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,42,NdKhAS6MXVEORLTwob92pxlZ,'4',LM1WpcGdrz8QtHV0i53k+'&series='+ggEX5wBNHj4F)
	elif level=='4':
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W['sort_video']
		items = YYqECUofyi7wFrW.findall('value="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for sort,title in items:
			if not sort: continue
			if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,44,NdKhAS6MXVEORLTwob92pxlZ,'1',LM1WpcGdrz8QtHV0i53k+'&sort='+sort)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(LM1WpcGdrz8QtHV0i53k,SYnTs3f05cOUIC2kdmPoM8KeZ):
	sCRbZp6Irl17v = nZwGQHStp65q3smAeFLB(LM1WpcGdrz8QtHV0i53k,SYnTs3f05cOUIC2kdmPoM8KeZ)
	AAMHoYxRCmt2D6ph89W = sCRbZp6Irl17v['template']
	items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,43,TTuPH708dUNnjlG3oQpkZsi)
	AAMHoYxRCmt2D6ph89W = sCRbZp6Irl17v['facets']['pagination']
	items = YYqECUofyi7wFrW.findall('data-page="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for jNgDBqeKyZ4zSkGv8ROMA70aIYcC,title in items:
		if SYnTs3f05cOUIC2kdmPoM8KeZ==jNgDBqeKyZ4zSkGv8ROMA70aIYcC: continue
		if QBp28giCnayJzmZH6vYO: title = L5xKSr96JmaX7N(title)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,NdKhAS6MXVEORLTwob92pxlZ,44,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,LM1WpcGdrz8QtHV0i53k)
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ALMAAREF-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<video src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('youtube_url.*?(http.*?)&',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	Pj8lY4doOfxiFMuNLhv3tnp = []
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0].replace('\/','/')
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def dbe3CzcI4ywG0jDmfY8HSxsqp():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/بث-مباشر',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ALMAAREF-LIVE-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	url = YYqECUofyi7wFrW.findall('"svpPlayer".*?(http.*?)&',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	url = url[0].replace('\\',NdKhAS6MXVEORLTwob92pxlZ)
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(url,yNIDEX5hU4G769,'live')
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	h0UZJVNR3b = False
	if search==NdKhAS6MXVEORLTwob92pxlZ:
		search = Z6GiHgnz0jNytc()
		h0UZJVNR3b = True
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	if not h0UZJVNR3b: hGJKk8tAiC3XFufEpqavQWmwTHdL('?search='+search,'1')
	else: aZ3fE5iR2r0dncpLwPvbWXhoMkuAIy('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
yNIDEX5hU4G769 = 'AKOAMCAM'
LJfTAEQPv9h4BXdwUp = '_AKC_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['مصارعة']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==350: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==351: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==352: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==353: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==354: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'FILTERS___'+text)
	elif mode==355: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'CATEGORIES___'+text)
	elif mode==356: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mMycZCEBSPKHD45Y39hdL8xRs(url)
	elif mode==357: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = yswS0fnYxlrocVB7(url)
	elif mode==359: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+D7INg5kyRjwf4ZtoePVUrb1h2SJ+'هذا الموقع مغلق'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,8)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,359,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,356)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,357)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-MENU-1st')
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('recently-container.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
	else: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'اضيف حديثا',BfjcMoqOsmdUvZVCHWIyQKi,351)
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('@id":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
	else: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المميزة',BfjcMoqOsmdUvZVCHWIyQKi,351,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('main-categories-list(.*?)main-categories-list',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?class="font.*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,351)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="categories-box(.*?)<footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,351)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def mMycZCEBSPKHD45Y39hdL8xRs(website=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="menu(.*?)<nav',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?text">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
				title = title+' مصنفة'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,355)
		if website==NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def yswS0fnYxlrocVB7(website=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="menu(.*?)<nav',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?text">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
				title = title+' مفلترة'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,354)
		if website==NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('swiper-container(.*?)swiper-button-prev',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="container"(.*?)main-footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		zIDPZSNn1OuweLHvmMKb6d = []
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|الحلقه) \d+',title,YYqECUofyi7wFrW.DOTALL)
				if N1VjdbtuO3z:
					title = '_MOD_' + N1VjdbtuO3z[0][0]
					if title not in zIDPZSNn1OuweLHvmMKb6d:
						ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,352,TTuPH708dUNnjlG3oQpkZsi)
						zIDPZSNn1OuweLHvmMKb6d.append(title)
			elif 'مسلسل' in title:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,352,TTuPH708dUNnjlG3oQpkZsi)
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,353,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href=["\'](.*?)["\'].*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,351)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/?s='+n5pZARB2X0x8abLPeywMuHkqV
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def vl57jIYC4a(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAMCAM-EPISODES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('text-white">الحلقات(.*?)<header',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		EIPXmH9BMs54SqTFjgrfzLnt = YYqECUofyi7wFrW.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in EIPXmH9BMs54SqTFjgrfzLnt:
			if 'الحلقة' in title or 'الحلقه' in title: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,353,TTuPH708dUNnjlG3oQpkZsi)
	else:
		TTuPH708dUNnjlG3oQpkZsi = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Icon')
		if LMKFcEkU1Q7R80yt4OsgvwxbfP.count('<title>')>1: title = YYqECUofyi7wFrW.findall('<title>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[1]
		else: title = 'رابط التشغيل'
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,353,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl,IGEpKNCaiLMT = [],[]
	ssMHf9na3RXh6EDviV7G2 = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = ssMHf9na3RXh6EDviV7G2.content
	hCjvUfTn43KDe2BdlYZH6PVFyIuOb = YYqECUofyi7wFrW.findall('post_id=(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if hCjvUfTn43KDe2BdlYZH6PVFyIuOb:
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb = hCjvUfTn43KDe2BdlYZH6PVFyIuOb[0]
		headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':hCjvUfTn43KDe2BdlYZH6PVFyIuOb}
		BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		bRYLOEav43r0lnoghHUW2pswAVemQ = cJaAB4uQyp(OewIv05xGhKQpFf,'POST',BfjcMoqOsmdUvZVCHWIyQKi,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-PLAY-1st')
		HeFB5x2wED = bRYLOEav43r0lnoghHUW2pswAVemQ.content
		items = YYqECUofyi7wFrW.findall('data-server="(.*?)".*?class="text">(.*?)<',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		for PCdTnUSfhk5x,name in items:
			zehVcU893FC6LEd1Aij = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?postid='+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+'&serverid='+PCdTnUSfhk5x+'?named='+name+'__watch'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			IGEpKNCaiLMT.append(name)
		BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		bRYLOEav43r0lnoghHUW2pswAVemQ = cJaAB4uQyp(OewIv05xGhKQpFf,'POST',BfjcMoqOsmdUvZVCHWIyQKi,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'AKOAMCAM-PLAY-1st')
		HeFB5x2wED = bRYLOEav43r0lnoghHUW2pswAVemQ.content
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?class="text">(.*?)<',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			IGEpKNCaiLMT.append(title)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	axsbpdckhGP127u5wEgnZtV4LWvzli = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='CATEGORIES':
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'all')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='FILTERS':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'all')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'?'+Jv2yebcHLo5GCrXZlw
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها',BfjcMoqOsmdUvZVCHWIyQKi,351,NdKhAS6MXVEORLTwob92pxlZ,'1')
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,351,NdKhAS6MXVEORLTwob92pxlZ,'1')
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<form id(.*?)</form>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	dict = {}
	for zZ0VrYRv6m8,name,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		items = YYqECUofyi7wFrW.findall('<option(.*?)>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='CATEGORIES':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<=1:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'CATEGORIES___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,351,NdKhAS6MXVEORLTwob92pxlZ,'1')
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,355,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='FILTERS':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع : '+name,BfjcMoqOsmdUvZVCHWIyQKi,354,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			if 'value' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = X9dRM31pz6y
			else: K6KbZDHncNizQgl1fr59XV0 = YYqECUofyi7wFrW.findall('"(.*?)"',K6KbZDHncNizQgl1fr59XV0,YYqECUofyi7wFrW.DOTALL)[0]
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' : '#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' : '+name
			if type=='FILTERS': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,354,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='CATEGORIES' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'all')
				Afey3cL4ojzg = url+'?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,351,NdKhAS6MXVEORLTwob92pxlZ,'1')
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,355,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	dW42o7vIOrS9wu = ['cat','genre','release-year','quality','orderby']
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	return LaGtUDiK2xnfz
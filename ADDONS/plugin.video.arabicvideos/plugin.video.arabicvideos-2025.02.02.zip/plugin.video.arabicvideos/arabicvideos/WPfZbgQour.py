# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
import bs4 as kPncaWsrBFKhNX19
yNIDEX5hU4G769 = 'ELCINEMA'
LJfTAEQPv9h4BXdwUp = '_ELC_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
headers = {'Referer':qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN}
Kdr54yMqbjTSX7piWREfPtZ2em = []
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==510: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==511: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = klotHUF5CYAe26SRWnBIm4zgsQ8(url)
	elif mode==512: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = AHa6TBktM7RbC4Kw83smy1VPzlhjNL(url)
	elif mode==513: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ZOEKhASG9LmYxHqRzwa384uXD(url)
	elif mode==514: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = KWS3dT7ag59XmiV6p4MLD(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = KWS3dT7ag59XmiV6p4MLD(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mZKxfcnodEVSbYA(text)
	elif mode==517: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = cqZd1okzewRAJG98N0BhHp(url)
	elif mode==518: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = yutXlYoOkzLTBU49qe8h1iM(url)
	elif mode==519: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	elif mode==520: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = WEgcmaeXn804PVKub6ZIY(url)
	elif mode==521: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Oze7Yi8TLwNdZ4BUItyh2(url)
	elif mode==522: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==523: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = eusYki0PpZ32gAl(text)
	elif mode==524: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = eiG1LKmp6lH3MhwsgJkD8B()
	elif mode==525: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = p2PSK6AWwfxC3ughyJYbcE7vB0()
	elif mode==526: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ijGL8m67IxNhtvCq()
	elif mode==527: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LPQpx01gZF39mCf()
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث بموسوعة السينما',NdKhAS6MXVEORLTwob92pxlZ,519)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'موسوعة الأعمال',NdKhAS6MXVEORLTwob92pxlZ,525)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'موسوعة الأشخاص',NdKhAS6MXVEORLTwob92pxlZ,526)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'موسوعة المصنفات',NdKhAS6MXVEORLTwob92pxlZ,527)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'موسوعة المنوعات',NdKhAS6MXVEORLTwob92pxlZ,524)
	return
def eiG1LKmp6lH3MhwsgJkD8B():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' فيديوهات - خاصة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video',520)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فيديوهات - أحدث',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/latest',521)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فيديوهات - أقدم',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/oldest',521)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فيديوهات - أكثر مشاهدة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/views',521)
	return
def p2PSK6AWwfxC3ughyJYbcE7vB0():
	ZeHfgDwo6071kPXh3JtnOLiU4YNx = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup?utf8=%E2%9C%93'
	R5TZ8FtEKMiLPDIAHacCklGhe9J = ZeHfgDwo6071kPXh3JtnOLiU4YNx+'&type=2&category=1&foreign=false&tag='
	otgXyx8B7kSAbs = ZeHfgDwo6071kPXh3JtnOLiU4YNx+'&type=2&category=3&foreign=false&tag='
	ffpnUE3yj1bhAX6aYzd = ZeHfgDwo6071kPXh3JtnOLiU4YNx+'&type=2&category=1&foreign=true&tag='
	Tq1tsohFPO7p50 = ZeHfgDwo6071kPXh3JtnOLiU4YNx+'&type=2&category=3&foreign=true&tag='
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات أفلام عربي',R5TZ8FtEKMiLPDIAHacCklGhe9J,511)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات مسلسلات عربي',otgXyx8B7kSAbs,511)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات أفلام اجنبي',ffpnUE3yj1bhAX6aYzd,511)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات مسلسلات اجنبي',Tq1tsohFPO7p50,511)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس أعمال أبجدي',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/work/alphabet',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس  بلد الإنتاج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/work/country',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس اللغة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/work/language',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس مصنفات العمل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/work/genre',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس سنة الإصدار',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/work/release_year',517)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مواسم - فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/seasonals',515)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مواسم - فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/seasonals',514)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات - فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup',515)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات - فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup',514)
	return
def LPQpx01gZF39mCf():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup',NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	AAMHoYxRCmt2D6ph89W = esgcqyrWCozau6wF.find('select',attrs={'name':'tag'})
	LM1WpcGdrz8QtHV0i53k = AAMHoYxRCmt2D6ph89W.find_all('option')
	for X9dRM31pz6y in LM1WpcGdrz8QtHV0i53k:
		K6KbZDHncNizQgl1fr59XV0 = X9dRM31pz6y.get('value')
		if not K6KbZDHncNizQgl1fr59XV0: continue
		title = X9dRM31pz6y.text
		if QBp28giCnayJzmZH6vYO:
			title = title.encode(YRvPKe2zMTDs8UCkr)
			K6KbZDHncNizQgl1fr59XV0 = K6KbZDHncNizQgl1fr59XV0.encode(YRvPKe2zMTDs8UCkr)
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+K6KbZDHncNizQgl1fr59XV0
		title = title.replace('قائمة ',NdKhAS6MXVEORLTwob92pxlZ)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,511)
	return
def ijGL8m67IxNhtvCq():
	ZeHfgDwo6071kPXh3JtnOLiU4YNx = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup?utf8=%E2%9C%93'
	XmQUz51EvhsOJioPldRK = ZeHfgDwo6071kPXh3JtnOLiU4YNx+'&type=1&category=&foreign=&tag='
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات أشخاص',XmQUz51EvhsOJioPldRK,511)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس أشخاص أبجدي',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/person/alphabet',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس موطن',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/person/nationality',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس  تاريخ الميلاد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/person/birth_year',517)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فهرس  تاريخ الوفاة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/index/person/death_year',517)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات - فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup',515)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مصنفات - فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/lineup',514)
	return
def klotHUF5CYAe26SRWnBIm4zgsQ8(url):
	if '/seasonals' in url: Xd8PpnWk1RlgzSmuNjtK3 = 0
	elif '/lineup' in url: Xd8PpnWk1RlgzSmuNjtK3 = 1
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-LISTS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	sCRbZp6Irl17v = esgcqyrWCozau6wF.find_all(class_='jumbo-theater clearfix')
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		title = AAMHoYxRCmt2D6ph89W.find_all('a')[Xd8PpnWk1RlgzSmuNjtK3].text
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+AAMHoYxRCmt2D6ph89W.find_all('a')[Xd8PpnWk1RlgzSmuNjtK3].get('href')
		if QBp28giCnayJzmZH6vYO:
			title = title.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
		if not sCRbZp6Irl17v:
			AHa6TBktM7RbC4Kw83smy1VPzlhjNL(zehVcU893FC6LEd1Aij)
			return
		else:
			title = title.replace('قائمة ',NdKhAS6MXVEORLTwob92pxlZ)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,512)
	vBGAzWDix8LQoFljXCIpw3uKVZ(esgcqyrWCozau6wF,511)
	return
def vBGAzWDix8LQoFljXCIpw3uKVZ(esgcqyrWCozau6wF,mode):
	AAMHoYxRCmt2D6ph89W = esgcqyrWCozau6wF.find(class_='pagination')
	if AAMHoYxRCmt2D6ph89W:
		N1IHg6C3SQBU = AAMHoYxRCmt2D6ph89W.find_all('a')
		bbECKg1QYpF0 = AAMHoYxRCmt2D6ph89W.find_all('li')
		ZNMeB7Xc1o9zA8rqQyJfuLFljb0p = list(zip(N1IHg6C3SQBU,bbECKg1QYpF0))
		XW2Opt4RQsVihunCylz6j = -1
		C46lKH0Xv2ujFSZfry = len(ZNMeB7Xc1o9zA8rqQyJfuLFljb0p)
		for P3BtEb8xUT7MCi,ILVJq0ekjwaMR1iBnTrH9PU2dSxsW in ZNMeB7Xc1o9zA8rqQyJfuLFljb0p:
			XW2Opt4RQsVihunCylz6j += 1
			ILVJq0ekjwaMR1iBnTrH9PU2dSxsW = ILVJq0ekjwaMR1iBnTrH9PU2dSxsW['class']
			if 'unavailable' in ILVJq0ekjwaMR1iBnTrH9PU2dSxsW or 'current' in ILVJq0ekjwaMR1iBnTrH9PU2dSxsW: continue
			RoDOya8x9mcMLZduGkX7YJUQTqI = P3BtEb8xUT7MCi.text
			xKXbWz9coR7jUfil45aQENr0ICBJg = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+P3BtEb8xUT7MCi.get('href')
			if QBp28giCnayJzmZH6vYO:
				RoDOya8x9mcMLZduGkX7YJUQTqI = RoDOya8x9mcMLZduGkX7YJUQTqI.encode(YRvPKe2zMTDs8UCkr)
				xKXbWz9coR7jUfil45aQENr0ICBJg = xKXbWz9coR7jUfil45aQENr0ICBJg.encode(YRvPKe2zMTDs8UCkr)
			if   XW2Opt4RQsVihunCylz6j==0: RoDOya8x9mcMLZduGkX7YJUQTqI = 'أولى'
			elif XW2Opt4RQsVihunCylz6j==1: RoDOya8x9mcMLZduGkX7YJUQTqI = 'سابقة'
			elif XW2Opt4RQsVihunCylz6j==C46lKH0Xv2ujFSZfry-2: RoDOya8x9mcMLZduGkX7YJUQTqI = 'لاحقة'
			elif XW2Opt4RQsVihunCylz6j==C46lKH0Xv2ujFSZfry-1: RoDOya8x9mcMLZduGkX7YJUQTqI = 'أخيرة'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+RoDOya8x9mcMLZduGkX7YJUQTqI,xKXbWz9coR7jUfil45aQENr0ICBJg,mode)
	return
def AHa6TBktM7RbC4Kw83smy1VPzlhjNL(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-TITLES1-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	sCRbZp6Irl17v = esgcqyrWCozau6wF.find_all(class_='row')
	items,D1BVdF2w4cm8fbTIv6AhjtNkPHx = [],True
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		if not AAMHoYxRCmt2D6ph89W.find(class_='thumbnail-wrapper'): continue
		if D1BVdF2w4cm8fbTIv6AhjtNkPHx: D1BVdF2w4cm8fbTIv6AhjtNkPHx = False ; continue
		cXq6PJLHANwl = []
		Th59msKF407 = AAMHoYxRCmt2D6ph89W.find_all(class_=['censorship red','censorship purple'])
		for uesU2K0GNI in Th59msKF407:
			j7q5bhLFizsntMYOd = uesU2K0GNI.find_all('li')[1].text
			if QBp28giCnayJzmZH6vYO:
				j7q5bhLFizsntMYOd = j7q5bhLFizsntMYOd.encode(YRvPKe2zMTDs8UCkr)
			cXq6PJLHANwl.append(j7q5bhLFizsntMYOd)
		if not ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,NdKhAS6MXVEORLTwob92pxlZ,cXq6PJLHANwl,False):
			k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('data-src')
			title = AAMHoYxRCmt2D6ph89W.find('h3')
			name = title.find('a').text
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+title.find('a').get('href')
			IlWoNpVv7yZKiQAhMSnUq10EtG = AAMHoYxRCmt2D6ph89W.find(class_='no-margin')
			gj8DGxqXcVI0i3v1MFzRCnKtu = AAMHoYxRCmt2D6ph89W.find(class_='legend')
			if IlWoNpVv7yZKiQAhMSnUq10EtG: IlWoNpVv7yZKiQAhMSnUq10EtG = IlWoNpVv7yZKiQAhMSnUq10EtG.text
			if gj8DGxqXcVI0i3v1MFzRCnKtu: gj8DGxqXcVI0i3v1MFzRCnKtu = gj8DGxqXcVI0i3v1MFzRCnKtu.text
			if QBp28giCnayJzmZH6vYO:
				k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.encode(YRvPKe2zMTDs8UCkr)
				name = name.encode(YRvPKe2zMTDs8UCkr)
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
				if IlWoNpVv7yZKiQAhMSnUq10EtG: IlWoNpVv7yZKiQAhMSnUq10EtG = IlWoNpVv7yZKiQAhMSnUq10EtG.encode(YRvPKe2zMTDs8UCkr)
			BIlmnRhJjQAFyoeNYOzT67pHDrG = {}
			if gj8DGxqXcVI0i3v1MFzRCnKtu: BIlmnRhJjQAFyoeNYOzT67pHDrG['stars'] = gj8DGxqXcVI0i3v1MFzRCnKtu
			if IlWoNpVv7yZKiQAhMSnUq10EtG:
				IlWoNpVv7yZKiQAhMSnUq10EtG = IlWoNpVv7yZKiQAhMSnUq10EtG.replace(B6IrC7zEHlw1oaeWf,' .. ')
				BIlmnRhJjQAFyoeNYOzT67pHDrG['plot'] = IlWoNpVv7yZKiQAhMSnUq10EtG.replace('...اقرأ المزيد',NdKhAS6MXVEORLTwob92pxlZ)
			if '/work/' in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,516,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG)
			elif '/person/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,513,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	vBGAzWDix8LQoFljXCIpw3uKVZ(esgcqyrWCozau6wF,512)
	return
def ZOEKhASG9LmYxHqRzwa384uXD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-TITLES2-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	sCRbZp6Irl17v = esgcqyrWCozau6wF.find_all('li')
	NNsAI58HYxeWb2d3it,items = [],[]
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		if not AAMHoYxRCmt2D6ph89W.find(class_='thumbnail-wrapper'): continue
		if not AAMHoYxRCmt2D6ph89W.find(class_=['unstyled','unstyled text-center']): continue
		if AAMHoYxRCmt2D6ph89W.find(class_='hide'): continue
		title = AAMHoYxRCmt2D6ph89W.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in NNsAI58HYxeWb2d3it: continue
		NNsAI58HYxeWb2d3it.append(name)
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+title.find('a').get('href')
		if '/search/work/' in url: k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('src')
		elif '/search/person/' in url: k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('data-src')
		elif '/search/video/' in url: k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('data-src')
		else: k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('src')
		if QBp28giCnayJzmZH6vYO:
			name = name.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
			k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.encode(YRvPKe2zMTDs8UCkr)
		name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		items.append((name,zehVcU893FC6LEd1Aij,k1ChwgueU5nbDX6K0BOEGx))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,zehVcU893FC6LEd1Aij,k1ChwgueU5nbDX6K0BOEGx in items:
		if '/search/video/' in url: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,522,k1ChwgueU5nbDX6K0BOEGx)
		elif '/search/person/' in url: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,513,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,516,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name)
	return
def mZKxfcnodEVSbYA(text):
	text = text.replace('الإعلان',NdKhAS6MXVEORLTwob92pxlZ).replace('لفيلم',NdKhAS6MXVEORLTwob92pxlZ).replace('الرسمي',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace('إعلان',NdKhAS6MXVEORLTwob92pxlZ).replace('فيلم',NdKhAS6MXVEORLTwob92pxlZ).replace('البرومو',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace('التشويقي',NdKhAS6MXVEORLTwob92pxlZ).replace('لمسلسل',NdKhAS6MXVEORLTwob92pxlZ).replace('مسلسل',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace(':',NdKhAS6MXVEORLTwob92pxlZ).replace(')',NdKhAS6MXVEORLTwob92pxlZ).replace('(',NdKhAS6MXVEORLTwob92pxlZ).replace(',',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace('_',NdKhAS6MXVEORLTwob92pxlZ).replace(';',NdKhAS6MXVEORLTwob92pxlZ).replace('-',NdKhAS6MXVEORLTwob92pxlZ).replace('.',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace('\'',NdKhAS6MXVEORLTwob92pxlZ).replace('\"',NdKhAS6MXVEORLTwob92pxlZ)
	text = text.replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	text = text.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	LrXnfP1oapqNh3EzVbw = text.count(Vwgflszp4WRA93kx6hvdua21HX5cOb)+1
	if LrXnfP1oapqNh3EzVbw==1:
		eusYki0PpZ32gAl(text)
		return
	ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+Whef0cxB2iR93SC5IwUtk+'==== كلمات للبحث ===='+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	BxZ7iYUVr2nLyIHPovMXu1l3 = text.split(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	aU0L1WNvmIAs9KuC3VqkHBxEhX = pow(2,LrXnfP1oapqNh3EzVbw)
	lrqXoAUv3CcSiR8T6mFGHKzWu0D7 = []
	def lriPnbUMaf1ZE(AvBYdKXjCz4FST,G98UeJVjr7isaZyoAfSw625mnKQNl0):
		if AvBYdKXjCz4FST=='1': return G98UeJVjr7isaZyoAfSw625mnKQNl0
		return NdKhAS6MXVEORLTwob92pxlZ
	for XW2Opt4RQsVihunCylz6j in range(aU0L1WNvmIAs9KuC3VqkHBxEhX,0,-1):
		HrNMKocjGuZq = list(LrXnfP1oapqNh3EzVbw*'0'+bin(XW2Opt4RQsVihunCylz6j)[2:])[-LrXnfP1oapqNh3EzVbw:]
		HrNMKocjGuZq = reversed(HrNMKocjGuZq)
		ZB3WgSanUwV = map(lriPnbUMaf1ZE,HrNMKocjGuZq,BxZ7iYUVr2nLyIHPovMXu1l3)
		title = Vwgflszp4WRA93kx6hvdua21HX5cOb.join(filter(None,ZB3WgSanUwV))
		if QBp28giCnayJzmZH6vYO: PJN58A9SFZTwi6uLMB73m = title.decode(YRvPKe2zMTDs8UCkr)
		else: PJN58A9SFZTwi6uLMB73m = title
		if len(PJN58A9SFZTwi6uLMB73m)>2 and title not in lrqXoAUv3CcSiR8T6mFGHKzWu0D7:
			lrqXoAUv3CcSiR8T6mFGHKzWu0D7.append(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,523,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,title)
	return
def eusYki0PpZ32gAl(w3SqvRknuD6rTAx):
	if QBp28giCnayJzmZH6vYO:
		w3SqvRknuD6rTAx = w3SqvRknuD6rTAx.decode(YRvPKe2zMTDs8UCkr)
		import arabic_reshaper as W8di2ykzVTw1UegJ,bidi.algorithm as q2o5GXsuaJxkjU
		w3SqvRknuD6rTAx = W8di2ykzVTw1UegJ.ArabicReshaper().reshape(w3SqvRknuD6rTAx)
		w3SqvRknuD6rTAx = q2o5GXsuaJxkjU.get_display(w3SqvRknuD6rTAx)
	import ddml0DI2qy
	w3SqvRknuD6rTAx = Z6GiHgnz0jNytc(qk0vxP27rbfuOwcgEtl3mUB1IDNWS=w3SqvRknuD6rTAx)
	ddml0DI2qy.tTIQWSbOEqHJ4(w3SqvRknuD6rTAx)
	return
def cqZd1okzewRAJG98N0BhHp(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-INDEXES_LISTS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	AAMHoYxRCmt2D6ph89W = esgcqyrWCozau6wF.find(class_='list-separator list-title')
	DDviHT4pFVhgwaL = AAMHoYxRCmt2D6ph89W.find_all('a')
	items = []
	for title in DDviHT4pFVhgwaL:
		name = title.text
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+title.get('href')
		if QBp28giCnayJzmZH6vYO:
			name = name.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
		if '#' not in zehVcU893FC6LEd1Aij: items.append((name,zehVcU893FC6LEd1Aij))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for rMOG2USkPesYZD9KNAVqpc in items:
		name,zehVcU893FC6LEd1Aij = rMOG2USkPesYZD9KNAVqpc
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,518)
	return
def yutXlYoOkzLTBU49qe8h1iM(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-INDEXES_TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	sCRbZp6Irl17v = esgcqyrWCozau6wF.find(class_='expand').find_all('tr')
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		mTdQcO6y4xPSo2LIv = AAMHoYxRCmt2D6ph89W.find_all('a')
		if not mTdQcO6y4xPSo2LIv: continue
		k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('data-src')
		name = mTdQcO6y4xPSo2LIv[1].text
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+mTdQcO6y4xPSo2LIv[1].get('href')
		gj8DGxqXcVI0i3v1MFzRCnKtu = AAMHoYxRCmt2D6ph89W.find(class_='legend')
		if gj8DGxqXcVI0i3v1MFzRCnKtu: gj8DGxqXcVI0i3v1MFzRCnKtu = gj8DGxqXcVI0i3v1MFzRCnKtu.text
		if QBp28giCnayJzmZH6vYO:
			name = name.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
			k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.encode(YRvPKe2zMTDs8UCkr)
		BIlmnRhJjQAFyoeNYOzT67pHDrG = {}
		if gj8DGxqXcVI0i3v1MFzRCnKtu: BIlmnRhJjQAFyoeNYOzT67pHDrG['stars'] = gj8DGxqXcVI0i3v1MFzRCnKtu
		if '/work/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,516,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG)
		elif '/person/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,513,k1ChwgueU5nbDX6K0BOEGx,NdKhAS6MXVEORLTwob92pxlZ,name,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	vBGAzWDix8LQoFljXCIpw3uKVZ(esgcqyrWCozau6wF,518)
	return
def WEgcmaeXn804PVKub6ZIY(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-VIDEOS_LISTS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	DDviHT4pFVhgwaL = esgcqyrWCozau6wF.find_all(class_='section-title inline')
	oDhlaxn0EqyYikcHrmZBN8uv = esgcqyrWCozau6wF.find_all(class_='button green small right')
	items = zip(DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv)
	for title,zehVcU893FC6LEd1Aij in items:
		title = title.text
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij.get('href')
		if QBp28giCnayJzmZH6vYO:
			title = title.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
		title = title.replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,521)
	return
def Oze7Yi8TLwNdZ4BUItyh2(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-VIDEOS_TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	MDyombi4e76dO3Vr8cYpLFJUhqZl2E = esgcqyrWCozau6wF.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	sCRbZp6Irl17v = MDyombi4e76dO3Vr8cYpLFJUhqZl2E.find_all('li')
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		title = AAMHoYxRCmt2D6ph89W.find(class_='title').text
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+AAMHoYxRCmt2D6ph89W.find('a').get('href')
		k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W.find('img').get('data-src')
		TLrSzM98nc2H3VODdyhpQI = AAMHoYxRCmt2D6ph89W.find(class_='duration').text
		if QBp28giCnayJzmZH6vYO:
			title = title.encode(YRvPKe2zMTDs8UCkr)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
			k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.encode(YRvPKe2zMTDs8UCkr)
			TLrSzM98nc2H3VODdyhpQI = TLrSzM98nc2H3VODdyhpQI.encode(YRvPKe2zMTDs8UCkr)
		TLrSzM98nc2H3VODdyhpQI = TLrSzM98nc2H3VODdyhpQI.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,522,k1ChwgueU5nbDX6K0BOEGx,TLrSzM98nc2H3VODdyhpQI)
	vBGAzWDix8LQoFljXCIpw3uKVZ(esgcqyrWCozau6wF,521)
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	zehVcU893FC6LEd1Aij = esgcqyrWCozau6wF.find(class_='flex-video').find('iframe').get('src')
	if QBp28giCnayJzmZH6vYO: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.encode(YRvPKe2zMTDs8UCkr)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx([zehVcU893FC6LEd1Aij],yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/?q='+search
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-SEARCH-1st')
	if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
		XmQUz51EvhsOJioPldRK = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search_entity/?q='+search+'&entity=work'
		xKXbWz9coR7jUfil45aQENr0ICBJg = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search_entity/?q='+search+'&entity=person'
		hhTD8OKNiVaj2ySZdUfBx6uIR5P = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search_entity/?q='+search+'&entity=video'
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن أعمال',XmQUz51EvhsOJioPldRK,513,NdKhAS6MXVEORLTwob92pxlZ,search)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن أشخاص',xKXbWz9coR7jUfil45aQENr0ICBJg,513,NdKhAS6MXVEORLTwob92pxlZ,search)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن فيديوهات',hhTD8OKNiVaj2ySZdUfBx6uIR5P,513,NdKhAS6MXVEORLTwob92pxlZ,search)
		return
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	esgcqyrWCozau6wF = kPncaWsrBFKhNX19.BeautifulSoup(LMKFcEkU1Q7R80yt4OsgvwxbfP,'html.parser',multi_valued_attributes=None)
	sCRbZp6Irl17v = esgcqyrWCozau6wF.find_all(class_='section-title left')
	for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
		title = AAMHoYxRCmt2D6ph89W.text
		if QBp28giCnayJzmZH6vYO:
			title = title.encode(YRvPKe2zMTDs8UCkr)
		title = title.split('(',1)[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if   'أعمال' in title: zehVcU893FC6LEd1Aij = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: zehVcU893FC6LEd1Aij = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: zehVcU893FC6LEd1Aij = url.replace('/search/','/search/video/')
		else: continue
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,513)
	return
def KWS3dT7ag59XmiV6p4MLD(url,text):
	global axsbpdckhGP127u5wEgnZtV4LWvzli,dW42o7vIOrS9wu
	if '/seasonals' in url:
		axsbpdckhGP127u5wEgnZtV4LWvzli = ['seasonal','year','category']
		dW42o7vIOrS9wu = ['seasonal','year','category']
	elif '/lineup' in url:
		axsbpdckhGP127u5wEgnZtV4LWvzli = ['category','foreign','type']
		dW42o7vIOrS9wu = ['category','foreign','type']
	Xi3ZCagjOpSAvB1rlnE6(url,text)
	return
def oDejqO6uYrsWp5ym9TQtEdV(url):
	url = url.split('/smartemadfilter?')[0]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('form action="/(.*?)</form>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return Hk9cy1IL0PXCw3OgYE5nr
def nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W):
	items = YYqECUofyi7wFrW.findall('<option value="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return items
def WW6XmdChlOPbY(url):
	p9pPoLdYMbqwXz1FQraUxKNv35 = url.split('/smartemadfilter?')[0]
	Q5Jbsopg4HhxqTY = msbTrJW03xuvA(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def kvKDm7w8xgYXfN4Wq(g7jQ4ZX1quCJ,url):
	AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'all_filters')
	Afey3cL4ojzg = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	Afey3cL4ojzg = WW6XmdChlOPbY(Afey3cL4ojzg)
	return Afey3cL4ojzg
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='ALL_ITEMS_FILTER':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+Jv2yebcHLo5GCrXZlw
		BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',BfjcMoqOsmdUvZVCHWIyQKi,511)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,511)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Hk9cy1IL0PXCw3OgYE5nr = oDejqO6uYrsWp5ym9TQtEdV(url)
	dict = {}
	for name,zZ0VrYRv6m8,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		name = name.replace('--',NdKhAS6MXVEORLTwob92pxlZ)
		items = nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='SPECIFIED_FILTER':
			if zZ0VrYRv6m8 not in axsbpdckhGP127u5wEgnZtV4LWvzli: continue
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<2:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]:
					url = WW6XmdChlOPbY(url)
					AHa6TBktM7RbC4Kw83smy1VPzlhjNL(url)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'SPECIFIED_FILTER___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,511)
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,515,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='ALL_ITEMS_FILTER':
			if zZ0VrYRv6m8 not in dW42o7vIOrS9wu: continue
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع: '+name,BfjcMoqOsmdUvZVCHWIyQKi,514,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			if 'مصنفات أخرى' in X9dRM31pz6y: continue
			if 'الكل' in X9dRM31pz6y: continue
			if 'اللغة' in X9dRM31pz6y: continue
			X9dRM31pz6y = X9dRM31pz6y.replace('قائمة ',NdKhAS6MXVEORLTwob92pxlZ)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			if name: title = X9dRM31pz6y+' :'+name
			else: title = X9dRM31pz6y
			if type=='ALL_ITEMS_FILTER': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,514,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='SPECIFIED_FILTER' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				Afey3cL4ojzg = kvKDm7w8xgYXfN4Wq(g7jQ4ZX1quCJ,url)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,511)
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,515,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.replace('=&','=0&')
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all_filters': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('=0','=')
	return LaGtUDiK2xnfz
axsbpdckhGP127u5wEgnZtV4LWvzli = []
dW42o7vIOrS9wu = []
# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'CIMAABDO'
LJfTAEQPv9h4BXdwUp = '_ABD_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الرئيسية']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==550: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==551: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==552: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==553: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==559: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/home',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,559,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'اخترنا لك',REGxsWAoilB7dCFNgMhz0V98bcm+'/home',551,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('main-content(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-name="(.*?)".*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for mfVtpzhI3WGnAx0,title in items:
		zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajax/getItem?item='+mfVtpzhI3WGnAx0+'&Ajax=1'
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,551)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"nav-main"(.*?)</nav>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if zehVcU893FC6LEd1Aij=='#': continue
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,551)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	for zehVcU893FC6LEd1Aij,title in items:
		if zehVcU893FC6LEd1Aij=='#': continue
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,551)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-TITLES-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP]
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-TITLES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		if mfVtpzhI3WGnAx0=='featured':
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"container"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		elif '"section-post mb-10"' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"section-post mb-10"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		else:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<article(.*?)"pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items:
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not items: items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if 'سلاسل' not in url and any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,552,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'الحلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,553,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/movies/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,551,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,553,TTuPH708dUNnjlG3oQpkZsi)
	if mfVtpzhI3WGnAx0==NdKhAS6MXVEORLTwob92pxlZ:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)<footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=="": continue
				if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'هناك المزيد',url,551)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"getSeasonsBySeries(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"list-episodes"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b and '/series/' not in url:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,553,TTuPH708dUNnjlG3oQpkZsi)
	elif gcBxGPatZIzQ1:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"image" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,552,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Afey3cL4ojzg = url.replace('/movies/','/watch_movies/')
	Afey3cL4ojzg = Afey3cL4ojzg.replace('/episodes/','/watch_episodes/')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(Afey3cL4ojzg,'url')
	Pj8lY4doOfxiFMuNLhv3tnp = []
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('''<iframe.*?src=["'](.*?)["']''',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
		oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'url')
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+oikt6P0hOAD5IvnlMpxf1+'__embed')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"servers"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb = YYqECUofyi7wFrW.findall('postID = "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb = hCjvUfTn43KDe2BdlYZH6PVFyIuOb[0]
		items = YYqECUofyi7wFrW.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if items:
			for oikt6P0hOAD5IvnlMpxf1,title in items:
				title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajax/getPlayer?server='+oikt6P0hOAD5IvnlMpxf1+'&postID='+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+'&Ajax=1'
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
				Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
		else:
			items = YYqECUofyi7wFrW.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if items:
				oikt6P0hOAD5IvnlMpxf1,B59tKCSAQioDber4ph2jXFW,title = items[0]
				zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajax/getPlayerByName?server='+oikt6P0hOAD5IvnlMpxf1+'&multipleServers='+B59tKCSAQioDber4ph2jXFW+'&postID='+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+'&Ajax=1'
				BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(zehVcU893FC6LEd1Aij)
				omrd89nv0PGKFpL3TxfAXt = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-PLAY-2nd')
				LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
				n5w3CRodyczAelGWjuNHm2ZV = YYqECUofyi7wFrW.findall('''<iframe src=["'](.*?)["']''',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
				xKXbWz9coR7jUfil45aQENr0ICBJg = n5w3CRodyczAelGWjuNHm2ZV[0] if n5w3CRodyczAelGWjuNHm2ZV else NdKhAS6MXVEORLTwob92pxlZ
				if '/iframe/' in xKXbWz9coR7jUfil45aQENr0ICBJg:
					VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',xKXbWz9coR7jUfil45aQENr0ICBJg,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-PLAY-3rd')
					LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
					g8wcakUMh19uGWZqFjSfJvB7tp = YYqECUofyi7wFrW.findall('version&quot;:&quot;(.*?)&',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
					g8wcakUMh19uGWZqFjSfJvB7tp = g8wcakUMh19uGWZqFjSfJvB7tp[0]
					omrd89nv0PGKFpL3TxfAXt = {}
					omrd89nv0PGKFpL3TxfAXt['X-Inertia-Partial-Component'] = 'files/mirror/video'
					omrd89nv0PGKFpL3TxfAXt['X-Inertia'] = 'true'
					omrd89nv0PGKFpL3TxfAXt['X-Inertia-Partial-Data'] = 'streams'
					omrd89nv0PGKFpL3TxfAXt['X-Inertia-Version'] = g8wcakUMh19uGWZqFjSfJvB7tp
					VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',xKXbWz9coR7jUfil45aQENr0ICBJg,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMAABDO-PLAY-4th')
					LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
					ccLNmRfl0Z = BdnA8WwtJeKUVvE('dict',LMKFcEkU1Q7R80yt4OsgvwxbfP)
					groups = ccLNmRfl0Z['props']['streams']['data']
					for group in groups:
						a0ao2jdlt4r9nhHwpvSgOVGA = group['label'].replace(' (source)',NdKhAS6MXVEORLTwob92pxlZ)
						jj6bVvdoYIDckstzS2MPOyJ9HpLCu = group['mirrors']
						for Lnk0xzvZahcE in jj6bVvdoYIDckstzS2MPOyJ9HpLCu:
							oikt6P0hOAD5IvnlMpxf1 = Lnk0xzvZahcE['driver']
							zehVcU893FC6LEd1Aij = 'http:'+Lnk0xzvZahcE['link']+'?named='+oikt6P0hOAD5IvnlMpxf1+'__watch____'+a0ao2jdlt4r9nhHwpvSgOVGA
							Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"downs"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__download'
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'-')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'.html'
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
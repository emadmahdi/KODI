# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = lRP6GTaZJA1Xw3egLM4(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭᩽")
LJfTAEQPv9h4BXdwUp = fOc18oTm5hsdD4pVZQj(u"࠭࡟ࡍࡕࡗࡣࠬ᩾")
YwrpxbQCTn = TQNS6YMKAqnilsVObLpDRX
psFTrwMitcBbJhPnR = R3lezw8h407ZvrAFxT(u"࠴࠴ᳪ")
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,url,ui7N5YGR9KdslpEbQkVTwFqDgI,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG):
	try: ODnPkfW6des = str(BIlmnRhJjQAFyoeNYOzT67pHDrG[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡧࡱ࡯ࡨࡪࡸ᩿ࠧ")])
	except: ODnPkfW6des = NdKhAS6MXVEORLTwob92pxlZ
	if   pPrvqm3tjuXLTgw1==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠵࠻࠶ᳫ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif pPrvqm3tjuXLTgw1==V0VZk9763fusTReHFo4(u"࠶࠼࠱ᳬ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = lR3fdT4ZC15ucAwsbe02a9hrH8PWyO(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠷࠶࠳᳭"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = CDBuKYygJSWr(ui7N5YGR9KdslpEbQkVTwFqDgI,HVmIrFwau90jQsgiWzExk(u"࠷࠶࠳᳭"))
	elif pPrvqm3tjuXLTgw1==JGwsL21ZRlqSrWxEmF(u"࠱࠷࠵ᳮ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = CDBuKYygJSWr(ui7N5YGR9KdslpEbQkVTwFqDgI,JGwsL21ZRlqSrWxEmF(u"࠱࠷࠵ᳮ"))
	elif pPrvqm3tjuXLTgw1==HHvYL68lbJVZWM7tQEzSex3(u"࠲࠸࠷ᳯ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = P2seICdOBvZy7iFcXSDEMja5G(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==xY4icgQUj6mPVs73CTKu(u"࠳࠹࠹ᳰ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = pXbwCvriMQjZIAH9kae(url,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==hCm2fnEXs6Zt(u"࠴࠺࠻ᳱ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = HPm5g7Aa8bvLZF9Kcfqk(url,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==rNyT0edugn(u"࠵࠻࠽ᳲ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QZSsYmu9WE(url,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==HHvYL68lbJVZWM7tQEzSex3(u"࠶࠼࠸ᳳ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = NI50pK7kOvDUldLZrm(url,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠽࠶࠲᳴"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = m27LTrXAGZE0xkNQbdsR8()
	elif pPrvqm3tjuXLTgw1==xY4icgQUj6mPVs73CTKu(u"࠷࠷࠴ᳵ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = rrEl8cBwXWso()
	elif pPrvqm3tjuXLTgw1==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠸࠸࠶ᳶ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vqjFgs3e8U0K2DpdEitVr(ODnPkfW6des,ui7N5YGR9KdslpEbQkVTwFqDgI,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif pPrvqm3tjuXLTgw1==rNyT0edugn(u"࠹࠹࠸᳷"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = gaDnVje0lx2bEy3AkBHoUWMYJiG5z(ODnPkfW6des,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==JGwsL21ZRlqSrWxEmF(u"࠺࠺࠺᳸"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Tuc6H0ltQ1P2oF3ZIazr(ODnPkfW6des,ui7N5YGR9KdslpEbQkVTwFqDgI)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = PzIpQnUXxRwNCivDhdakWTE(u"ࡇࡣ࡯ࡷࡪᵑ")
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp(NeU6uRGpECkvMV5jf(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪀"),rNyT0edugn(u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪ᪁"),NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠵࠻࠷᳹"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᪂"))
	ZI51XvE8YatWCmNdrp(NeU6uRGpECkvMV5jf(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪃"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ᪄"),NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠶࠼࠲ᳺ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᪅"))
	ZI51XvE8YatWCmNdrp(V0VZk9763fusTReHFo4(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪆"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ᪇"),NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"࠷࠶࠴᳻"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᪈"))
	ZI51XvE8YatWCmNdrp(V0VZk9763fusTReHFo4(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪉"),rNyT0edugn(u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪ᪊"),NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠱࠷࠶᳼"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᪋"))
	ZI51XvE8YatWCmNdrp(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪌"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ᪍"),NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"࠸࠸࠶᳽"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ᪎"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ࡯࡭ࡳࡱࠧ᪏"),Whef0cxB2iR93SC5IwUtk+lNTJCZeBicWEz0Mg(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᪐")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"࠻࠼࠽࠾᳾"))
	ZI51XvE8YatWCmNdrp(QQHFtjcaR2VpnSyTIv(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪑"),lrtFSogC8Nh9(u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ᪒"),NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"࠴࠺࠸᳿"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᪓"))
	ZI51XvE8YatWCmNdrp(kb2icmDGVUZfW1OFz7sv(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪔"),xY4icgQUj6mPVs73CTKu(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ᪕"),NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠵࠻࠹ᴀ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᪖"))
	ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪗"),IlL8ZnX74Yvep(u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ᪘"),NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"࠶࠼࠲ᴁ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᪙"))
	ZI51XvE8YatWCmNdrp(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪚"),lrtFSogC8Nh9(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ᪛"),NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"࠷࠶࠳ᴂ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᪜"))
	ZI51XvE8YatWCmNdrp(gniNItGL6bKwpEW(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᪝"),lRP6GTaZJA1Xw3egLM4(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭᪞"),NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠱࠷࠶ᴃ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᪟"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪠"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᪡"),NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"࠸࠸࠸ᴄ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᪢"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨ࡮࡬ࡲࡰ࠭᪣"),Whef0cxB2iR93SC5IwUtk+Hlp3z0APt1GR4kMYK5xST(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᪤")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"࠻࠼࠽࠾ᴅ"))
	ZI51XvE8YatWCmNdrp(kb2icmDGVUZfW1OFz7sv(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪥"),fOc18oTm5hsdD4pVZQj(u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ᪦"),NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"࠴࠺࠸ᴆ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᪧ"))
	ZI51XvE8YatWCmNdrp(LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪨"),lRP6GTaZJA1Xw3egLM4(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ᪩"),NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"࠵࠻࠹ᴇ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᪪"))
	ZI51XvE8YatWCmNdrp(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᪫"),R3lezw8h407ZvrAFxT(u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ᪬"),NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠶࠼࠲ᴈ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᪭"))
	ZI51XvE8YatWCmNdrp(QQHFtjcaR2VpnSyTIv(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪮"),kb2icmDGVUZfW1OFz7sv(u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ᪯"),NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"࠷࠶࠳ᴉ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᪰"))
	ZI51XvE8YatWCmNdrp(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪱"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏࠭᪲"),NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"࠱࠷࠶ᴊ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᪳"))
	ZI51XvE8YatWCmNdrp(HHvYL68lbJVZWM7tQEzSex3(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪴"),kb2icmDGVUZfW1OFz7sv(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊᪵࠭"),NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"࠸࠸࠷ᴋ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᪶ࠪ"))
	return
def m27LTrXAGZE0xkNQbdsR8():
	ZI51XvE8YatWCmNdrp(fOc18oTm5hsdD4pVZQj(u"ࠧࡧࡱ࡯ࡨࡪࡸ᪷ࠧ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡡࡌࡔ࡙ࡥ᪸ࠧ")+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜᪹ࠧ"),NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠹࠹࠸ᴌ"))
	ZI51XvE8YatWCmNdrp(QQHFtjcaR2VpnSyTIv(u"ࠪࡰ࡮ࡴ࡫ࠨ᪺"),Whef0cxB2iR93SC5IwUtk+IlL8ZnX74Yvep(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᪻")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"࠼࠽࠾࠿ᴍ"))
	for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
		LJfTAEQPv9h4BXdwUp = NOrchaEV1iIZ87Uzlwgum(u"ࠬࡥࡉࡑࠩ᪼")+str(ODnPkfW6des)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭࡟ࠨ᪽")
		ZI51XvE8YatWCmNdrp(gniNItGL6bKwpEW(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪾"),LJfTAEQPv9h4BXdwUp+gniNItGL6bKwpEW(u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะᪿࠢࠪ")+omh6YcDWKgIBkNG3[ODnPkfW6des],NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"࠻࠻࠺ᴎ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡩࡳࡱࡪࡥࡳᫀࠩ"):ODnPkfW6des})
	return
def rrEl8cBwXWso():
	ZI51XvE8YatWCmNdrp(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᫁"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡤࡓ࠳ࡖࡡࠪ᫂")+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖ᫃ࠩ"),NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠼࠼࠵ᴏ"))
	ZI51XvE8YatWCmNdrp(V0VZk9763fusTReHFo4(u"࠭࡬ࡪࡰ࡮᫄ࠫ"),Whef0cxB2iR93SC5IwUtk+IlL8ZnX74Yvep(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᫅")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"࠿࠹࠺࠻ᴐ"))
	for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
		LJfTAEQPv9h4BXdwUp = OOkmZiVcfqlEurM1dHGb(u"ࠨࡡࡐ࡙ࠬ᫆")+str(ODnPkfW6des)+HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡢࠫ᫇")
		ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᫈"),LJfTAEQPv9h4BXdwUp+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭᫉")+omh6YcDWKgIBkNG3[ODnPkfW6des],NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠷࠷࠷ᴑ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{V0VZk9763fusTReHFo4(u"ࠬ࡬࡯࡭ࡦࡨࡶ᫊ࠬ"):ODnPkfW6des})
	return
def tkSKJUBa16Fh(mAH4aPy8q1w):
	global rEb7uD63cqAHS9VaIMg5Jv,hfHzwKeTuIakFxGq
	QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
	try:
		if NeU6uRGpECkvMV5jf(u"࠭ࡉࡇࡋࡏࡑࠬ᫋") in mAH4aPy8q1w: QQYZ7KIqVTxw(mAH4aPy8q1w)
		else: QQYZ7KIqVTxw()
		VVpCqWnb6okcNFwhK7mGd = Tzx81Wb0RZC4ID5AyiU2(u"ࡈࡤࡰࡸ࡫ᵒ")
	except:
		ZeaDz4KMlg5bSRBfT1tnVCGH()
		VVpCqWnb6okcNFwhK7mGd = gniNItGL6bKwpEW(u"ࡗࡶࡺ࡫ᵓ")
	mAH4aPy8q1w = P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w)
	if VVpCqWnb6okcNFwhK7mGd:
		kkDz5sdaPteM(mAH4aPy8q1w,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧโึ็ࠤ้๊ริใࠪᫌ"),XJ62UBRmIqFvfiNTQj=LtGoXlQ2IYxqTJRySE6udfW98(u"࠳࠲࠳࠴ᴒ"))
		rEb7uD63cqAHS9VaIMg5Jv += llxMLe4gobHhsj1WGvd7qmIU
		hfHzwKeTuIakFxGq += Vwgflszp4WRA93kx6hvdua21HX5cOb+mAH4aPy8q1w
	else: kkDz5sdaPteM(mAH4aPy8q1w,NdKhAS6MXVEORLTwob92pxlZ,XJ62UBRmIqFvfiNTQj=LtGoXlQ2IYxqTJRySE6udfW98(u"࠳࠳࠴࠵ᴓ"))
	return
def FFJgfRUhiXunyS80(qpF0NAeKhc=gniNItGL6bKwpEW(u"ࡘࡷࡻࡥᵔ")):
	global rEb7uD63cqAHS9VaIMg5Jv,hfHzwKeTuIakFxGq,BDG2gRTNFL37J6P5i
	if not qpF0NAeKhc:
		BDG2gRTNFL37J6P5i = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡦ࡬ࡧࡹ࠭ᫍ"),JGwsL21ZRlqSrWxEmF(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪᫎ"),rNyT0edugn(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࡣࡆࡒࡌࠨ᫏"))
		if BDG2gRTNFL37J6P5i: return
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(hCm2fnEXs6Zt(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ᫐"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᫑"),PzIpQnUXxRwNCivDhdakWTE(u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ᫒"))
	if TT32BcvomhVewpgMSWkEb46y7xqO!=llxMLe4gobHhsj1WGvd7qmIU: return
	f2cgzj0TovI9YVl7tan1QkMS8(OOkmZiVcfqlEurM1dHGb(u"ࡋࡧ࡬ࡴࡧᵕ"),OOkmZiVcfqlEurM1dHGb(u"ࡋࡧ࡬ࡴࡧᵕ"),OOkmZiVcfqlEurM1dHGb(u"ࡋࡧ࡬ࡴࡧᵕ"))
	MSaY1Esdz4DgTHRQ59ZJf6 = emiIH49XT6jzOQrw
	rEb7uD63cqAHS9VaIMg5Jv,hfHzwKeTuIakFxGq,threads = e8XhbyuzvjYkIsJUtB5w,NdKhAS6MXVEORLTwob92pxlZ,{}
	for mAH4aPy8q1w in n1tdI8Kf4R5ovCZEJVP:
		XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
		threads[mAH4aPy8q1w] = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=tkSKJUBa16Fh,args=(mAH4aPy8q1w,))
		threads[mAH4aPy8q1w].start()
		if rEb7uD63cqAHS9VaIMg5Jv>=psFTrwMitcBbJhPnR: break
	else:
		for mAH4aPy8q1w in list(threads.keys()): threads[mAH4aPy8q1w].join()
	emiIH49XT6jzOQrw[:] = MSaY1Esdz4DgTHRQ59ZJf6
	if rEb7uD63cqAHS9VaIMg5Jv>=psFTrwMitcBbJhPnR: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᫓"),gniNItGL6bKwpEW(u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡࠩ᫔")+str(rEb7uD63cqAHS9VaIMg5Jv)+ggWEFaH6fcVIO9SzRZLiuxo7P(u"้ࠩࠣํอโฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์ุฮศ่ษࠣๆิ๊ࠦไ๊้ࠤ฾ีๅ๊ࠡฯ์ิࠦล็ฬิ๊๏ะࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࡀࠧ᫕")+hfHzwKeTuIakFxGq)
	else:
		BDG2gRTNFL37J6P5i = {}
		for mAH4aPy8q1w in list(threads.keys()):
			try: syecSAbvf17 = yZLFCImoREnkBv[mAH4aPy8q1w]
			except: continue
			mAH4aPy8q1w = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡣࡑ࡙ࡔࡠࠩ᫖")+P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w)
			for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd in syecSAbvf17:
				if not JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = lRP6GTaZJA1Xw3egLM4(u"ࠫ࠳࠴࠮࠯ࠩ᫗")
				else:
					if JHKDFe6Am0ruz8.count(V0VZk9763fusTReHFo4(u"ࠬࡥࠧ᫘"))>llxMLe4gobHhsj1WGvd7qmIU: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.split(HHvYL68lbJVZWM7tQEzSex3(u"࠭࡟ࠨ᫙"),cCRvAuJQfjBpTg0PbYiaNO87)[cCRvAuJQfjBpTg0PbYiaNO87]
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࢡࠩ᫚"),NdKhAS6MXVEORLTwob92pxlZ).replace(R3lezw8h407ZvrAFxT(u"ࠨࠢࡋࡈࠬ᫛"),NdKhAS6MXVEORLTwob92pxlZ).replace(PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡋࡈࠥ࠭᫜"),NdKhAS6MXVEORLTwob92pxlZ)
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪไࠬ᫝"),NdKhAS6MXVEORLTwob92pxlZ).replace(NOrchaEV1iIZ87Uzlwgum(u"ࠫฮ࠭᫞"),NeU6uRGpECkvMV5jf(u"ࠬํࠧ᫟")).replace(fOc18oTm5hsdD4pVZQj(u"࠭ฤࠨ᫠"),NOrchaEV1iIZ87Uzlwgum(u"้ࠧࠩ᫡"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(HVmIrFwau90jQsgiWzExk(u"ࠨลࠪ᫢"),hCm2fnEXs6Zt(u"ࠩสࠫ᫣")).replace(xY4icgQUj6mPVs73CTKu(u"ࠪษࠬ᫤"),kb2icmDGVUZfW1OFz7sv(u"ࠫฬ࠭᫥")).replace(rNyT0edugn(u"ࠬศࠧ᫦"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠭วࠨ᫧"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(hCm2fnEXs6Zt(u"ࠧๅลࠪ᫨"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨๆสࠫ᫩")).replace(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ็ษࠬ᫪"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"่ࠪฬ࠭᫫")).replace(kb2icmDGVUZfW1OFz7sv(u"้ࠫศࠧ᫬"),eGW7cI6aQhr0(u"๊ࠬวࠨ᫭"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(IlL8ZnX74Yvep(u"࠭๎ࠨ᫮"),NdKhAS6MXVEORLTwob92pxlZ).replace(R3lezw8h407ZvrAFxT(u"ࠧ์ࠩ᫯"),NdKhAS6MXVEORLTwob92pxlZ).replace(Hlp3z0APt1GR4kMYK5xST(u"ࠨ๑ࠪ᫰"),NdKhAS6MXVEORLTwob92pxlZ).replace(QQHFtjcaR2VpnSyTIv(u"ࠩ๏ࠫ᫱"),NdKhAS6MXVEORLTwob92pxlZ)
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(V0VZk9763fusTReHFo4(u"ࠪ๔ࠬ᫲"),NdKhAS6MXVEORLTwob92pxlZ).replace(lrtFSogC8Nh9(u"ࠫ๒࠭᫳"),NdKhAS6MXVEORLTwob92pxlZ).replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠬ๘ࠧ᫴"),NdKhAS6MXVEORLTwob92pxlZ).replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭๑ࠨ᫵"),NdKhAS6MXVEORLTwob92pxlZ)
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(QQHFtjcaR2VpnSyTIv(u"ࠧࡽࠩ᫶"),NdKhAS6MXVEORLTwob92pxlZ).replace(eGW7cI6aQhr0(u"ࠨࢀࠪ᫷"),NdKhAS6MXVEORLTwob92pxlZ)
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(hCm2fnEXs6Zt(u"ࠩส์๋ࠦไศ์้ࠫ᫸"),NdKhAS6MXVEORLTwob92pxlZ).replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪื๏๋วࠡๆส๎ฯ࠭᫹"),NdKhAS6MXVEORLTwob92pxlZ)
					jZ8EiGtDmF7cVnJ = [Tzx81Wb0RZC4ID5AyiU2(u"ࠫฬู๊ศสࠪ᫺"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬิ๊ศๆࠪ᫻"),R3lezw8h407ZvrAFxT(u"࠭วๅส๋้ࠬ᫼"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧศๆส๊ࠬ᫽"),NOrchaEV1iIZ87Uzlwgum(u"ࠨษฺๅฬ๊ࠧ᫾"),R3lezw8h407ZvrAFxT(u"ࠩะห้๐็ࠨ᫿"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪห้เวำࠩᬀ"),Tzx81Wb0RZC4ID5AyiU2(u"ฺࠫอไฮࠩᬁ"),IlL8ZnX74Yvep(u"ࠬอไะ์้ࠫᬂ"),Tzx81Wb0RZC4ID5AyiU2(u"࠭ๅ้ษ็๎ิ࠭ᬃ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠧศๆ฼ห้๋ࠧᬄ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨษ฼้ฬ๊ࠧᬅ")]
					if not any(TTc4QGeF0UH in JHKDFe6Am0ruz8 for TTc4QGeF0UH in jZ8EiGtDmF7cVnJ): JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩส่ࠬᬆ"),NdKhAS6MXVEORLTwob92pxlZ)
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪหำื๊ࠨᬇ"),xY4icgQUj6mPVs73CTKu(u"ࠫฬิั๊ࠩᬈ")).replace(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬอฬ็ส์ࠫᬉ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭วอ่ห๎ࠬᬊ")).replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ฺࠧษษ่๏ํࠧᬋ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ฻สส้๐ࠧᬌ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩสะ๋ฮ๊่ࠩᬍ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪหั์ศ๋ࠩᬎ")).replace(QQHFtjcaR2VpnSyTIv(u"ࠫ฾ืศ๋้ࠪᬏ"),IlL8ZnX74Yvep(u"ࠬ฿ัษ์ࠪᬐ")).replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ั้็สุ๊๐็ࠨᬑ"),JGwsL21ZRlqSrWxEmF(u"ࠧา๊่หู๋๊ࠨᬒ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠨ฼ิฬ๏ํࠧᬓ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩ฽ีอ๐ࠧᬔ")).replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ์๋ࠥำๅี็หฯ࠭ᬕ"),lRP6GTaZJA1Xw3egLM4(u"ู๊ࠫไิๆสฮࠬᬖ")).replace(JGwsL21ZRlqSrWxEmF(u"ࠬอฺศ่์ࠫᬗ"),R3lezw8h407ZvrAFxT(u"࠭ว฻ษ้๎ࠬᬘ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧหษิ๎ำ๐ࠧᬙ"),fOc18oTm5hsdD4pVZQj(u"ࠨฬสี๏ิࠧᬚ")).replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠩั๎ฬฺ๊ࠠๆ่๎ࠬᬛ"),lRP6GTaZJA1Xw3egLM4(u"ࠪา๏อไࠨᬜ")).replace(Hlp3z0APt1GR4kMYK5xST(u"๊ࠫ๎ำ๋ไํ๋ࠬᬝ"),PzIpQnUXxRwNCivDhdakWTE(u"๋่ࠬิ์ๅํࠬᬞ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(HVmIrFwau90jQsgiWzExk(u"࠭็็ั์ࠫᬟ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"่่ࠧา๎ࠬᬠ")).replace(lrtFSogC8Nh9(u"ࠨ้้ำ๏ํࠧᬡ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"๊๊ࠩิ๐ࠧᬢ")).replace(hCm2fnEXs6Zt(u"ࠪ์ะอฦใ์๊ࠫᬣ"),QQHFtjcaR2VpnSyTIv(u"ࠫํัววไํࠫᬤ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(V0VZk9763fusTReHFo4(u"ࠬะไ๋ใี๎ํ์๊่ࠩᬥ"),HVmIrFwau90jQsgiWzExk(u"࠭สๅใี๎ํ์ࠧᬦ")).replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧหๆไึ๏๎ๆ๋้ࠪᬧ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨฬ็ๅื๐่็ࠩᬨ")).replace(hCm2fnEXs6Zt(u"๋ࠩࠤ่ืส้่ࠪᬩ"),xY4icgQUj6mPVs73CTKu(u"ࠪ์่ืส้่ࠪᬪ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫฬ๊อศๆํ๋ࠬᬫ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬำวๅ์๊ࠫᬬ")).replace(rNyT0edugn(u"࠭ๅ้ี໏ๆ๏࠭ᬭ"),JGwsL21ZRlqSrWxEmF(u"ࠧๆ๊ึ๎็๏ࠧᬮ")).replace(HVmIrFwau90jQsgiWzExk(u"ࠨษ็ห๋๋๊ࠨᬯ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩส๊๊๐ࠧᬰ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(eGW7cI6aQhr0(u"ࠪห้๋ำๅี็หฯ࠭ᬱ"),NeU6uRGpECkvMV5jf(u"ู๊ࠫไิๆสฮࠬᬲ")).replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬอไษำส้ั࠭ᬳ"),R3lezw8h407ZvrAFxT(u"࠭ศาษ่ะ᬴ࠬ")).replace(lrtFSogC8Nh9(u"ࠧไษิฮํ์ࠧᬵ"),rNyT0edugn(u"ࠨๅิฮํ์ࠧᬶ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩะีํฮࠧᬷ"),gniNItGL6bKwpEW(u"ࠪัึฮࠧᬸ")).replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫฬ๊ว็ษื๎ิ࠭ᬹ"),fOc18oTm5hsdD4pVZQj(u"ࠬอๆศึํำࠬᬺ")).replace(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭วิ์๋๎์࠭ᬻ"),lrtFSogC8Nh9(u"ࠧศีํ์๏࠭ᬼ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(QQHFtjcaR2VpnSyTIv(u"ࠨ฻ิฬ๎࠭ᬽ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ฼ีอ๐ࠧᬾ")).replace(eGW7cI6aQhr0(u"ࠪฮึ้้ࠨᬿ"),lNTJCZeBicWEz0Mg(u"ࠫฯืใ๋ࠩᭀ")).replace(fOc18oTm5hsdD4pVZQj(u"ࠬะัไ์๊ࠫᭁ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭สาๅํࠫᭂ")).replace(lNTJCZeBicWEz0Mg(u"ࠧศๆฺ่ฬ็ࠧᭃ"),gniNItGL6bKwpEW(u"ࠨ็ูหๆ᭄࠭"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(Hlp3z0APt1GR4kMYK5xST(u"ࠩิ๎ฬ฼๊ࠨᭅ"),eGW7cI6aQhr0(u"ࠪี๏อึสࠩᭆ")).replace(NOrchaEV1iIZ87Uzlwgum(u"ࠫึ๐วื้ࠪᭇ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬื๊ศุฬࠫᭈ")).replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭วิ์๋๎์࠭ᭉ"),HVmIrFwau90jQsgiWzExk(u"ࠧศีํ์๏࠭ᭊ"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(eGW7cI6aQhr0(u"ࠨๅ๋้๏ี้ࠨᭋ"),lNTJCZeBicWEz0Mg(u"ࠩๆ์๊๐ฯ๋ࠩᭌ")).replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪ็ํ๋๊ะ์๊ࠫ᭍"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"่ࠫ๎ๅ๋ัํࠫ᭎")).replace(NOrchaEV1iIZ87Uzlwgum(u"ࠬอๆ๋็ํࠫ᭏"),fOc18oTm5hsdD4pVZQj(u"࠭ว็็ํࠫ᭐"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(V0VZk9763fusTReHFo4(u"ࠧศ่ํ้๏ฺๆࠨ᭑"),kb2icmDGVUZfW1OFz7sv(u"ࠨษ้้๏ฺๆࠨ᭒")).replace(rNyT0edugn(u"ࠩส๊๊๏ࠧ᭓"),eGW7cI6aQhr0(u"ࠪห๋๋๊ี่ࠪ᭔")).replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫฬ์ๅ๋ࠩ᭕"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬอๆๆ์ื๊ࠬ᭖"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(QQHFtjcaR2VpnSyTIv(u"࠭ว็็ํฺุ๋ๆࠨ᭗"),Tzx81Wb0RZC4ID5AyiU2(u"ࠧศ่่๎ู์ࠧ᭘")).replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨษ็ห๋๋๊ี่ࠪ᭙"),Tzx81Wb0RZC4ID5AyiU2(u"ࠩส๊๊๐ิ็ࠩ᭚")).replace(R3lezw8h407ZvrAFxT(u"ࠪหๆ๊วๆ่ࠢืู้ไศฬࠪ᭛"),Hlp3z0APt1GR4kMYK5xST(u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬ᭜"))
					JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(OOkmZiVcfqlEurM1dHGb(u"ࠬ࠳ࠧ᭝")).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				if JHKDFe6Am0ruz8 not in list(BDG2gRTNFL37J6P5i.keys()): BDG2gRTNFL37J6P5i[JHKDFe6Am0ruz8] = {}
				BDG2gRTNFL37J6P5i[JHKDFe6Am0ruz8][mAH4aPy8q1w] = [oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd]
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ᭞"),HVmIrFwau90jQsgiWzExk(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬ᭟"),BDG2gRTNFL37J6P5i,hzP83xLawFqYneDtHGmSriWE)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᭠"),xY4icgQUj6mPVs73CTKu(u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ᭡"))
	f2cgzj0TovI9YVl7tan1QkMS8(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
	yyTm3OqzGEYApS()
	return
def b4SyKm2NREiu9ftVvXw5sZzLDnc(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc):
	pma7xfu1g43KVTMFQ = Tzx81Wb0RZC4ID5AyiU2(u"ࡌࡡ࡭ࡵࡨᵖ")
	eutCMzlLsmdypFwU = emiIH49XT6jzOQrw
	emiIH49XT6jzOQrw[:] = []
	if pma7xfu1g43KVTMFQ and lrtFSogC8Nh9(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ᭢") not in aPC0mLklY6jIUypFAwKbc:
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡱ࡯ࡳࡵࠩ᭣"),HVmIrFwau90jQsgiWzExk(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ᭤"),HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ᭥")+ODnPkfW6des)
	elif hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ᭦") not in aPC0mLklY6jIUypFAwKbc or gniNItGL6bKwpEW(u"ࠨࡡ࡙ࡓࡉࡥࠧ᭧") not in aPC0mLklY6jIUypFAwKbc:
		import dduW7Cg5Fx
		JzNoqV8ClRD6O = JGwsL21ZRlqSrWxEmF(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ᭨")
		if IlL8ZnX74Yvep(u"ࠪࡣࡑࡏࡖࡆࡡࠪ᭩") not in aPC0mLklY6jIUypFAwKbc:
			try: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,lNTJCZeBicWEz0Mg(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ᭪"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᭫"),JGwsL21ZRlqSrWxEmF(u"ࡆࡢ࡮ࡶࡩᵗ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะ᭬ࠧ"),JzNoqV8ClRD6O)
			try: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,rNyT0edugn(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᭭"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭮"),QQHFtjcaR2VpnSyTIv(u"ࡇࡣ࡯ࡷࡪᵘ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ᭯"),JzNoqV8ClRD6O)
			try: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,OOkmZiVcfqlEurM1dHGb(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᭰"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᭱"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࡈࡤࡰࡸ࡫ᵙ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭᭲"),JzNoqV8ClRD6O)
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭࡟ࡗࡑࡇࡣࠬ᭳") not in aPC0mLklY6jIUypFAwKbc:
			try: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,hCm2fnEXs6Zt(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᭴"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+IlL8ZnX74Yvep(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭵"),fOc18oTm5hsdD4pVZQj(u"ࡉࡥࡱࡹࡥᵚ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ᭶"),JzNoqV8ClRD6O)
			try: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ᭷"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+lRP6GTaZJA1Xw3egLM4(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᭸"),V0VZk9763fusTReHFo4(u"ࡊࡦࡲࡳࡦᵛ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ᭹"),JzNoqV8ClRD6O)
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = emiIH49XT6jzOQrw
		if pma7xfu1g43KVTMFQ: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭᭺"),Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ᭻")+ODnPkfW6des,UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,hzP83xLawFqYneDtHGmSriWE)
	emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def P89MA7akmxvOcU0IdG(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc):
	pma7xfu1g43KVTMFQ = rNyT0edugn(u"ࡋࡧ࡬ࡴࡧᵜ")
	eutCMzlLsmdypFwU = emiIH49XT6jzOQrw
	emiIH49XT6jzOQrw[:] = []
	if pma7xfu1g43KVTMFQ and Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭᭼") not in aPC0mLklY6jIUypFAwKbc:
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࡯࡭ࡸࡺࠧ᭽"),fOc18oTm5hsdD4pVZQj(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ᭾"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ᭿")+ODnPkfW6des)
	elif IlL8ZnX74Yvep(u"ࠬࡥࡌࡊࡘࡈࡣࠬᮀ") not in aPC0mLklY6jIUypFAwKbc or pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭࡟ࡗࡑࡇࡣࠬᮁ") not in aPC0mLklY6jIUypFAwKbc:
		import ws4trNj60m
		JzNoqV8ClRD6O = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬᮂ")
		if WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨᮃ") not in aPC0mLklY6jIUypFAwKbc:
			try: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,lNTJCZeBicWEz0Mg(u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᮄ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+hCm2fnEXs6Zt(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᮅ"),kb2icmDGVUZfW1OFz7sv(u"ࡌࡡ࡭ࡵࡨᵝ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᮆ"),JzNoqV8ClRD6O)
			try: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,eGW7cI6aQhr0(u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᮇ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+lNTJCZeBicWEz0Mg(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮈ"),PzIpQnUXxRwNCivDhdakWTE(u"ࡆࡢ࡮ࡶࡩᵞ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᮉ"),JzNoqV8ClRD6O)
			try: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,eGW7cI6aQhr0(u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᮊ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᮋ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࡇࡣ࡯ࡷࡪᵟ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᮌ"),JzNoqV8ClRD6O)
		if kb2icmDGVUZfW1OFz7sv(u"ࠫࡤ࡜ࡏࡅࡡࠪᮍ") not in aPC0mLklY6jIUypFAwKbc:
			try: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,IlL8ZnX74Yvep(u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᮎ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+JGwsL21ZRlqSrWxEmF(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮏ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࡈࡤࡰࡸ࡫ᵠ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᮐ"),JzNoqV8ClRD6O)
			try: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(ODnPkfW6des,QQHFtjcaR2VpnSyTIv(u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᮑ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,aPC0mLklY6jIUypFAwKbc+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᮒ"),NeU6uRGpECkvMV5jf(u"ࡉࡥࡱࡹࡥᵡ"))
			except: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅไ้์ฬะࠧᮓ"),JzNoqV8ClRD6O)
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = emiIH49XT6jzOQrw
		if pma7xfu1g43KVTMFQ: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,lrtFSogC8Nh9(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᮔ"),NeU6uRGpECkvMV5jf(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬᮕ")+ODnPkfW6des,UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,hzP83xLawFqYneDtHGmSriWE)
	emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def vqjFgs3e8U0K2DpdEitVr(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc,Vy6u2L8jhEnapr1QgUTXZewAWbMk7):
	f2cgzj0TovI9YVl7tan1QkMS8(None,None,LtGoXlQ2IYxqTJRySE6udfW98(u"ࡊࡦࡲࡳࡦᵢ"))
	if Vy6u2L8jhEnapr1QgUTXZewAWbMk7: FFJgfRUhiXunyS80(f4vncKMRlXG9s)
	elif OOkmZiVcfqlEurM1dHGb(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᮖ") in aPC0mLklY6jIUypFAwKbc and not Vy6u2L8jhEnapr1QgUTXZewAWbMk7: FFJgfRUhiXunyS80(k6apiPAlLKM1ed8J42RjHh0o)
	t0oxhvzm2RQU = aPC0mLklY6jIUypFAwKbc.replace(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᮗ"),NdKhAS6MXVEORLTwob92pxlZ).replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᮘ"),NdKhAS6MXVEORLTwob92pxlZ).replace(NOrchaEV1iIZ87Uzlwgum(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᮙ"),NdKhAS6MXVEORLTwob92pxlZ)
	if not Vy6u2L8jhEnapr1QgUTXZewAWbMk7:
		ZI51XvE8YatWCmNdrp(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡰ࡮ࡴ࡫ࠨᮚ"),rNyT0edugn(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢส่ศ่ำศ็ࠪᮛ"),NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"࠺࠺࠸ᴔ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᮜ")+t0oxhvzm2RQU,NdKhAS6MXVEORLTwob92pxlZ,{lRP6GTaZJA1Xw3egLM4(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮝ"):ODnPkfW6des})
		ZI51XvE8YatWCmNdrp(rNyT0edugn(u"ࠧ࡭࡫ࡱ࡯ࠬᮞ"),Whef0cxB2iR93SC5IwUtk+QQHFtjcaR2VpnSyTIv(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᮟ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠽࠾࠿࠹ᴕ"))
		y9yRCdrFtNfpULEqWQiGBK5HTI2JVu = [IlL8ZnX74Yvep(u"ࠩฦๅ้อๅࠨᮠ"),V0VZk9763fusTReHFo4(u"ุ้๊ࠪำๅษอࠫᮡ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ู๊ࠫัฮ์สฮࠬᮢ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬฮัศ็ฯࠫᮣ"),JGwsL21ZRlqSrWxEmF(u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬᮤ"),kb2icmDGVUZfW1OFz7sv(u"ࠧา็ูห๋࠭ᮥ"),hCm2fnEXs6Zt(u"ࠨละำะ࠳รฯำࠪᮦ"),Hlp3z0APt1GR4kMYK5xST(u"ࠩึ่ฬูไࠨᮧ"),eGW7cI6aQhr0(u"้ࠪํู๊ใ๋ࠪᮨ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠫศฺ็า࠯ฦ็ะืࠧᮩ"),HVmIrFwau90jQsgiWzExk(u"ࠬอไร᮪่ࠪ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ึฮๅ᮫ࠪ"),JGwsL21ZRlqSrWxEmF(u"ࠧา์สฺฮ࠭ᮬ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨ่ํฮๆ๊ใิࠩᮭ"),hCm2fnEXs6Zt(u"่้ࠩะ๊๊็ࠩᮮ"),eGW7cI6aQhr0(u"ࠪฬะࠦอ๋ࠩᮯ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠫิ๐ๆ๋หࠪ᮰"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ูࠬๆ้ษอࠫ᮱"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭รฯำ์ࠫ᮲")]
		Vy6u2L8jhEnapr1QgUTXZewAWbMk7 = e8XhbyuzvjYkIsJUtB5w
		for nn32Wmjyz4GQbE0sJe in y9yRCdrFtNfpULEqWQiGBK5HTI2JVu:
			Vy6u2L8jhEnapr1QgUTXZewAWbMk7 += llxMLe4gobHhsj1WGvd7qmIU
			ZI51XvE8YatWCmNdrp(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᮳"),LJfTAEQPv9h4BXdwUp+nn32Wmjyz4GQbE0sJe,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"࠼࠼࠳ᴖ"),NdKhAS6MXVEORLTwob92pxlZ,str(Vy6u2L8jhEnapr1QgUTXZewAWbMk7),t0oxhvzm2RQU,NdKhAS6MXVEORLTwob92pxlZ,{wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᮴"):ODnPkfW6des})
	else:
		ooSpuPgxX4BAHlLzecR2t6YCj = [HVmIrFwau90jQsgiWzExk(u"ࠩสๅ้อๅࠨ᮵"),eGW7cI6aQhr0(u"ࠪࡱࡴࡼࡩࡦࠩ᮶"),gniNItGL6bKwpEW(u"ࠫๆ๐ไๆࠩ᮷"),lRP6GTaZJA1Xw3egLM4(u"ࠬ็ไๆࠩ᮸")]
		yioznSRMK8cYFU2l = [OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ๅิๆึ่ࠬ᮹"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡴࡧࡵ࡭ࡪࡹࠧᮺ")]
		HHz1JtEwDWvS4pj8dsObLTBn3ru = [JGwsL21ZRlqSrWxEmF(u"ࠨ็ึหึำࠧᮻ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"่ࠩืึำ๊ศฬࠪᮼ")]
		jjKXRU6O5Yh = [lRP6GTaZJA1Xw3egLM4(u"ࠪฬึอๅอࠩᮽ"),gniNItGL6bKwpEW(u"ࠫࡸ࡮࡯ࡸࠩᮾ"),JGwsL21ZRlqSrWxEmF(u"ࠬะไโิํ์๋࠭ᮿ"),NeU6uRGpECkvMV5jf(u"࠭สๅ์ไึ๏๎ๆࠨᯀ")]
		UHNlLvK0WPfC3td = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧศ่่๎ࠬᯁ"),QQHFtjcaR2VpnSyTIv(u"ࠨๅิฮํ์ࠧᯂ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩๆหึะ่็ࠩᯃ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪ࡯࡮ࡪࡳࠨᯄ"),lrtFSogC8Nh9(u"ࠫ฼็ไࠨᯅ"),xY4icgQUj6mPVs73CTKu(u"ࠬอืโษ็ࠫᯆ")]
		WLsp05OGi6tADXoE4R = [JGwsL21ZRlqSrWxEmF(u"࠭ัๆุส๊ࠬᯇ")]
		qahUFzc8EDsd0PfVruTSOMKyCoLl1 = [NeU6uRGpECkvMV5jf(u"ࠧศฯาฯࠬᯈ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠨษัีࠬᯉ"),gniNItGL6bKwpEW(u"่ࠩ์ำืࠧᯊ"),Hlp3z0APt1GR4kMYK5xST(u"ࠪะิ๐ฯࠨᯋ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"๊ࠫ฼วโࠩᯌ"),OOkmZiVcfqlEurM1dHGb(u"ࠬำฯ๋อࠪᯍ")]
		Rz79mxS4UOkehEGBucHtLQ8qC = [vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ำๅษึ่ࠬᯎ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧิๆึ่์࠭ᯏ")]
		z8mQytHe73Mvh6rZ09RdEgbaw = [rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨษ฽ห๋๐ࠧᯐ"),NeU6uRGpECkvMV5jf(u"่ࠩ์ุ๐โ๊ࠩᯑ"),xY4icgQUj6mPVs73CTKu(u"ࠪ็้๐ศࠨᯒ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫา็ไࠨᯓ"),IlL8ZnX74Yvep(u"ࠬࡳࡵࡴ࡫ࡦࠫᯔ")]
		OvnDmPcHJjYV = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭วไอิࠫᯕ"),V0VZk9763fusTReHFo4(u"ࠧศึ๊ีࠬᯖ"),fOc18oTm5hsdD4pVZQj(u"ࠨ็่๎ืํࠧᯗ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩส฽้๏ࠧᯘ"),QQHFtjcaR2VpnSyTIv(u"้ࠪำะวา้ࠪᯙ"),Tzx81Wb0RZC4ID5AyiU2(u"๊ࠫิสศำสฮࠬᯚ"),JGwsL21ZRlqSrWxEmF(u"ࠬอโ้๋ࠪᯛ")]
		jeTEkUwtcxXK6 = [PzIpQnUXxRwNCivDhdakWTE(u"࠭วๅษ้ࠫᯜ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧฮษ็๎ࠬᯝ"),gniNItGL6bKwpEW(u"ࠨ็ฮฬฯ࠭ᯞ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠩิหหาࠧᯟ")]
		ITHvg1i374oSWzJx5U0LYf = [rtUJso6d7iaNf1yWejxnc5DEXFg(u"ฺࠪา้ࠧᯠ"),fOc18oTm5hsdD4pVZQj(u"่ࠫ๎ๅ๋ัํࠫᯡ")]
		bhDkmzV0udGCLM98joAY = [V0VZk9763fusTReHFo4(u"ࠬื๊ศุ๊ࠫᯢ"),V0VZk9763fusTReHFo4(u"࠭ใ้ำ๊ࠫᯣ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧๆืสี฾ํࠧᯤ"),lRP6GTaZJA1Xw3egLM4(u"ࠨึ๋ฮࠬᯥ"),JGwsL21ZRlqSrWxEmF(u"ࠩิ๎ฬ฼ษࠨ᯦")]
		X58DcACrGxOsMndSJVNjkTeW0KU = [eGW7cI6aQhr0(u"๊ࠪ๏ะแๅๅึࠫᯧ"),eGW7cI6aQhr0(u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬᯨ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬ์๊หใ็๎ู่ࠧᯩ")]
		X97R8rgujJqa = [NOrchaEV1iIZ87Uzlwgum(u"࠭ๅๆอ็๎๋࠭ᯪ"),IlL8ZnX74Yvep(u"ࠧศึัหฺ࠭ᯫ"),rNyT0edugn(u"ࠨ่ฯ์๊࠭ᯬ")]
		dbe3CzcI4ywG0jDmfY8HSxsqp = [xY4icgQUj6mPVs73CTKu(u"ࠩหฯࠥำ๊ࠨᯭ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡰ࡮ࡼࡥࠨᯮ"),gniNItGL6bKwpEW(u"ࠫ็์ว่ࠩᯯ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"่ࠬๆ้ษอࠫᯰ")]
		zNRTigtEeOhx53JAsGCmWHQ2nV = [hCm2fnEXs6Zt(u"࠭ฯ๋่ࠪᯱ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧศั฼๎์᯲࠭"),eGW7cI6aQhr0(u"ࠨิํหึอสࠨ᯳"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ็฻๊๐วหࠩ᯴"),lRP6GTaZJA1Xw3egLM4(u"ࠪำ฾อมࠨ᯵"),R3lezw8h407ZvrAFxT(u"ࠫ็ืว็ࠩ᯶"),gniNItGL6bKwpEW(u"่ࠬีศศาࠫ᯷"),xY4icgQUj6mPVs73CTKu(u"࠭ัฬษฤࠫ᯸"),hCm2fnEXs6Zt(u"ࠧๆำฯ฽๏ํࠧ᯹"),JGwsL21ZRlqSrWxEmF(u"ࠨษำห๋࠭᯺"),fOc18oTm5hsdD4pVZQj(u"ࠩสื้อๅࠨ᯻"),fOc18oTm5hsdD4pVZQj(u"ࠪฮํอิ๋ฯࠪ᯼"),xY4icgQUj6mPVs73CTKu(u"ࠫำ฽ศࠨ᯽"),kb2icmDGVUZfW1OFz7sv(u"ࠬำ่ำ๊ํࠫ᯾"),gniNItGL6bKwpEW(u"ู࠭หสสฮࠬ᯿"),hCm2fnEXs6Zt(u"ࠧๆ๊ส่๏ีࠧᰀ"),xY4icgQUj6mPVs73CTKu(u"ࠨ่๋ห฾๐ࠧᰁ"),R3lezw8h407ZvrAFxT(u"ࠩ฼ๆฬฬฯࠨᰂ"),OOkmZiVcfqlEurM1dHGb(u"ࠪห๋อิ๋ัࠪᰃ")]
		ngcib0XJ5pfUCTLvZW4zSMx = [vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ࠷࠶࠱࠱ࠩᰄ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࠸࠰࠲࠳ࠪᰅ"),HVmIrFwau90jQsgiWzExk(u"࠭࠲࠱࠳࠵ࠫᰆ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠳࠲࠴࠷ࠬᰇ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠴࠳࠵࠹࠭ᰈ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࠵࠴࠶࠻ࠧᰉ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪ࠶࠵࠷࠶ࠨᰊ"),OOkmZiVcfqlEurM1dHGb(u"ࠫ࠷࠶࠱࠸ࠩᰋ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࠸࠰࠲࠺ࠪᰌ"),fOc18oTm5hsdD4pVZQj(u"࠭࠲࠱࠳࠼ࠫᰍ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧ࠳࠲࠵࠴ࠬᰎ"),lRP6GTaZJA1Xw3egLM4(u"ࠨ࠴࠳࠶࠶࠭ᰏ"),NeU6uRGpECkvMV5jf(u"ࠩ࠵࠴࠷࠸ࠧᰐ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࠶࠵࠸࠳ࠨᰑ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫ࠷࠶࠲࠵ࠩᰒ"),JGwsL21ZRlqSrWxEmF(u"ࠬ࠸࠰࠳࠷ࠪᰓ"),PzIpQnUXxRwNCivDhdakWTE(u"࠭࠲࠱࠴࠹ࠫᰔ"),V0VZk9763fusTReHFo4(u"ࠧ࠳࠲࠵࠻ࠬᰕ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨ࠴࠳࠶࠽࠭ᰖ")]
		for JHKDFe6Am0ruz8 in sorted(list(BDG2gRTNFL37J6P5i.keys())):
			RoDOya8x9mcMLZduGkX7YJUQTqI = JHKDFe6Am0ruz8.lower()
			II4s1CdgcbN6BSvWPnHtz = []
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in ooSpuPgxX4BAHlLzecR2t6YCj): II4s1CdgcbN6BSvWPnHtz.append(llxMLe4gobHhsj1WGvd7qmIU)
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in yioznSRMK8cYFU2l): II4s1CdgcbN6BSvWPnHtz.append(cCRvAuJQfjBpTg0PbYiaNO87)
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in HHz1JtEwDWvS4pj8dsObLTBn3ru): II4s1CdgcbN6BSvWPnHtz.append(uL69vJOU7xN0hGnZf2islDqk)
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in jjKXRU6O5Yh): II4s1CdgcbN6BSvWPnHtz.append(TQNS6YMKAqnilsVObLpDRX)
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in UHNlLvK0WPfC3td): II4s1CdgcbN6BSvWPnHtz.append(NOrchaEV1iIZ87Uzlwgum(u"࠻ᴗ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in WLsp05OGi6tADXoE4R): II4s1CdgcbN6BSvWPnHtz.append(lrtFSogC8Nh9(u"࠶ᴘ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in qahUFzc8EDsd0PfVruTSOMKyCoLl1) and RoDOya8x9mcMLZduGkX7YJUQTqI not in [lRP6GTaZJA1Xw3egLM4(u"ࠩสาึ๏ࠧᰗ")]: II4s1CdgcbN6BSvWPnHtz.append(Tzx81Wb0RZC4ID5AyiU2(u"࠸ᴙ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in Rz79mxS4UOkehEGBucHtLQ8qC): II4s1CdgcbN6BSvWPnHtz.append(LtGoXlQ2IYxqTJRySE6udfW98(u"࠺ᴚ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in z8mQytHe73Mvh6rZ09RdEgbaw): II4s1CdgcbN6BSvWPnHtz.append(IlL8ZnX74Yvep(u"࠼ᴛ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in OvnDmPcHJjYV): II4s1CdgcbN6BSvWPnHtz.append(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵࠵ᴜ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in jeTEkUwtcxXK6): II4s1CdgcbN6BSvWPnHtz.append(lNTJCZeBicWEz0Mg(u"࠶࠷ᴝ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in ITHvg1i374oSWzJx5U0LYf): II4s1CdgcbN6BSvWPnHtz.append(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠷࠲ᴞ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in bhDkmzV0udGCLM98joAY): II4s1CdgcbN6BSvWPnHtz.append(HHvYL68lbJVZWM7tQEzSex3(u"࠱࠴ᴟ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in X58DcACrGxOsMndSJVNjkTeW0KU): II4s1CdgcbN6BSvWPnHtz.append(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠲࠶ᴠ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in X97R8rgujJqa): II4s1CdgcbN6BSvWPnHtz.append(HVmIrFwau90jQsgiWzExk(u"࠳࠸ᴡ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in dbe3CzcI4ywG0jDmfY8HSxsqp): II4s1CdgcbN6BSvWPnHtz.append(fOc18oTm5hsdD4pVZQj(u"࠴࠺ᴢ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in zNRTigtEeOhx53JAsGCmWHQ2nV): II4s1CdgcbN6BSvWPnHtz.append(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠵࠼ᴣ"))
			if any(K6KbZDHncNizQgl1fr59XV0 in RoDOya8x9mcMLZduGkX7YJUQTqI for K6KbZDHncNizQgl1fr59XV0 in ngcib0XJ5pfUCTLvZW4zSMx): II4s1CdgcbN6BSvWPnHtz.append(NOrchaEV1iIZ87Uzlwgum(u"࠶࠾ᴤ"))
			if not II4s1CdgcbN6BSvWPnHtz: II4s1CdgcbN6BSvWPnHtz = [NeU6uRGpECkvMV5jf(u"࠷࠹ᴥ")]
			for kvB1AdWwKOg3XJVquF in II4s1CdgcbN6BSvWPnHtz:
				if str(kvB1AdWwKOg3XJVquF)==Vy6u2L8jhEnapr1QgUTXZewAWbMk7:
					ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡪࡴࡲࡤࡦࡴࠪᰘ"),LJfTAEQPv9h4BXdwUp+JHKDFe6Am0ruz8,JHKDFe6Am0ruz8,lRP6GTaZJA1Xw3egLM4(u"࠱࠷࠸ᴦ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,t0oxhvzm2RQU+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰙ"))
	f2cgzj0TovI9YVl7tan1QkMS8(None,None,NdKhAS6MXVEORLTwob92pxlZ)
	return
def gaDnVje0lx2bEy3AkBHoUWMYJiG5z(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc):
	pma7xfu1g43KVTMFQ = lRP6GTaZJA1Xw3egLM4(u"ࡋࡧ࡬ࡴࡧᵣ")
	if pma7xfu1g43KVTMFQ:
		ZI51XvE8YatWCmNdrp(PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡲࡩ࡯࡭ࠪᰚ"),fOc18oTm5hsdD4pVZQj(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡍࡕ࡚ࡖࠨᰛ"),NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠸࠸࠷ᴧ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᰜ"),NdKhAS6MXVEORLTwob92pxlZ,{V0VZk9763fusTReHFo4(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰝ"):ODnPkfW6des})
		ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ࡯࡭ࡳࡱࠧᰞ"),Whef0cxB2iR93SC5IwUtk+fOc18oTm5hsdD4pVZQj(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᰟ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠻࠼࠽࠾ᴨ"))
	eutCMzlLsmdypFwU = emiIH49XT6jzOQrw[:]
	import dduW7Cg5Fx
	if ODnPkfW6des:
		if not dduW7Cg5Fx.vUGsjuw7mN8TFakprdZXV(ODnPkfW6des,vju3SZDWL4ENYelmBOzUqrogp2(u"࡚ࡲࡶࡧᵤ")): return
		KBm4FRbOfeX6hSadvPHCgc = b4SyKm2NREiu9ftVvXw5sZzLDnc(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc)
		RKFv4AP3fDzwtisg6V1nGCQyjbu = sorted(KBm4FRbOfeX6hSadvPHCgc,reverse=kb2icmDGVUZfW1OFz7sv(u"ࡆࡢ࡮ࡶࡩᵥ"),key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU].lower())
	else:
		if not dduW7Cg5Fx.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࡕࡴࡸࡩᵦ")): return
		if pma7xfu1g43KVTMFQ and gniNItGL6bKwpEW(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᰠ") not in aPC0mLklY6jIUypFAwKbc:
			RKFv4AP3fDzwtisg6V1nGCQyjbu = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡲࡩࡴࡶࠪᰡ"),OOkmZiVcfqlEurM1dHGb(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ᰢ"),IlL8ZnX74Yvep(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫᰣ"))
		else:
			II3HJQdYbxseXtSy82nhvUaqliEGm,RKFv4AP3fDzwtisg6V1nGCQyjbu,KBm4FRbOfeX6hSadvPHCgc = [],[],[]
			for seQZ7FIlGq in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
				RKFv4AP3fDzwtisg6V1nGCQyjbu += b4SyKm2NREiu9ftVvXw5sZzLDnc(str(seQZ7FIlGq),aPC0mLklY6jIUypFAwKbc)
			for type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in RKFv4AP3fDzwtisg6V1nGCQyjbu:
				if ui7N5YGR9KdslpEbQkVTwFqDgI not in II3HJQdYbxseXtSy82nhvUaqliEGm:
					II3HJQdYbxseXtSy82nhvUaqliEGm.append(ui7N5YGR9KdslpEbQkVTwFqDgI)
					brEjQosMt2FLVpqTACKPxW519 = type,JHKDFe6Am0ruz8,ui7N5YGR9KdslpEbQkVTwFqDgI,Tzx81Wb0RZC4ID5AyiU2(u"࠴࠺࠺ᴩ"),k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,aPC0mLklY6jIUypFAwKbc,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG
					KBm4FRbOfeX6hSadvPHCgc.append(brEjQosMt2FLVpqTACKPxW519)
			RKFv4AP3fDzwtisg6V1nGCQyjbu = sorted(KBm4FRbOfeX6hSadvPHCgc,reverse=gniNItGL6bKwpEW(u"ࡈࡤࡰࡸ࡫ᵧ"),key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU].lower())
			if pma7xfu1g43KVTMFQ: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,gniNItGL6bKwpEW(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᰤ"),HVmIrFwau90jQsgiWzExk(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭ᰥ"),RKFv4AP3fDzwtisg6V1nGCQyjbu,hzP83xLawFqYneDtHGmSriWE)
	emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu
	MIjcStaDWnv(LtGoXlQ2IYxqTJRySE6udfW98(u"ࡉࡥࡱࡹࡥᵨ"))
	return
def Tuc6H0ltQ1P2oF3ZIazr(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc):
	pma7xfu1g43KVTMFQ = fOc18oTm5hsdD4pVZQj(u"ࡊࡦࡲࡳࡦᵩ")
	if pma7xfu1g43KVTMFQ:
		ZI51XvE8YatWCmNdrp(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡰ࡮ࡴ࡫ࠨᰦ"),HVmIrFwau90jQsgiWzExk(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢฦๆุอๅࠡࡏ࠶࡙ࠬᰧ"),NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"࠻࠻࠻ᴪ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᰨ"),NdKhAS6MXVEORLTwob92pxlZ,{xY4icgQUj6mPVs73CTKu(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰩ"):ODnPkfW6des})
		ZI51XvE8YatWCmNdrp(lRP6GTaZJA1Xw3egLM4(u"ࠧ࡭࡫ࡱ࡯ࠬᰪ"),Whef0cxB2iR93SC5IwUtk+fOc18oTm5hsdD4pVZQj(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᰫ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"࠾࠿࠹࠺ᴫ"))
	eutCMzlLsmdypFwU = emiIH49XT6jzOQrw[:]
	import ws4trNj60m
	if ODnPkfW6des:
		if not ws4trNj60m.vUGsjuw7mN8TFakprdZXV(ODnPkfW6des,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࡙ࡸࡵࡦᵪ")): return
		KBm4FRbOfeX6hSadvPHCgc = P89MA7akmxvOcU0IdG(ODnPkfW6des,aPC0mLklY6jIUypFAwKbc)
		RKFv4AP3fDzwtisg6V1nGCQyjbu = sorted(KBm4FRbOfeX6hSadvPHCgc,reverse=NOrchaEV1iIZ87Uzlwgum(u"ࡌࡡ࡭ࡵࡨᵫ"),key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU].lower())
	else:
		if not ws4trNj60m.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࡔࡳࡷࡨᵬ")): return
		if pma7xfu1g43KVTMFQ and V0VZk9763fusTReHFo4(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᰬ") not in aPC0mLklY6jIUypFAwKbc:
			RKFv4AP3fDzwtisg6V1nGCQyjbu = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,NeU6uRGpECkvMV5jf(u"ࠪࡰ࡮ࡹࡴࠨᰭ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᰮ"),R3lezw8h407ZvrAFxT(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨᰯ"))
		else:
			II3HJQdYbxseXtSy82nhvUaqliEGm,RKFv4AP3fDzwtisg6V1nGCQyjbu,KBm4FRbOfeX6hSadvPHCgc = [],[],[]
			for seQZ7FIlGq in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
				RKFv4AP3fDzwtisg6V1nGCQyjbu += P89MA7akmxvOcU0IdG(str(seQZ7FIlGq),aPC0mLklY6jIUypFAwKbc)
			for type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in RKFv4AP3fDzwtisg6V1nGCQyjbu:
				if ui7N5YGR9KdslpEbQkVTwFqDgI not in II3HJQdYbxseXtSy82nhvUaqliEGm:
					II3HJQdYbxseXtSy82nhvUaqliEGm.append(ui7N5YGR9KdslpEbQkVTwFqDgI)
					brEjQosMt2FLVpqTACKPxW519 = type,JHKDFe6Am0ruz8,ui7N5YGR9KdslpEbQkVTwFqDgI,lrtFSogC8Nh9(u"࠷࠶࠶ᴬ"),k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,aPC0mLklY6jIUypFAwKbc,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG
					KBm4FRbOfeX6hSadvPHCgc.append(brEjQosMt2FLVpqTACKPxW519)
			RKFv4AP3fDzwtisg6V1nGCQyjbu = sorted(KBm4FRbOfeX6hSadvPHCgc,reverse=fOc18oTm5hsdD4pVZQj(u"ࡇࡣ࡯ࡷࡪᵭ"),key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU].lower())
			if pma7xfu1g43KVTMFQ: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᰰ"),lNTJCZeBicWEz0Mg(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᰱ"),RKFv4AP3fDzwtisg6V1nGCQyjbu,hzP83xLawFqYneDtHGmSriWE)
	emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu
	MIjcStaDWnv(eGW7cI6aQhr0(u"ࡈࡤࡰࡸ࡫ᵮ"))
	return
def pXbwCvriMQjZIAH9kae(group,aPC0mLklY6jIUypFAwKbc):
	pma7xfu1g43KVTMFQ = IlL8ZnX74Yvep(u"ࡉࡥࡱࡹࡥᵯ")
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = []
	mD5OIdgoTAaW9 = Hlp3z0APt1GR4kMYK5xST(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨᰲ") if fOc18oTm5hsdD4pVZQj(u"ࠩࡌࡔ࡙࡜ࠧᰳ") in aPC0mLklY6jIUypFAwKbc else lRP6GTaZJA1Xw3egLM4(u"ࠪࡣࡒ࠹ࡕࡠࠩᰴ")
	if pma7xfu1g43KVTMFQ: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠫࡱ࡯ࡳࡵࠩᰵ"),lNTJCZeBicWEz0Mg(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧᰶ")+mD5OIdgoTAaW9[:-V0VZk9763fusTReHFo4(u"࠱ᴭ")],group)
	if not UEsxyfd8rZMLOHgzc6emSFKD0ktYiT:
		for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
			if pma7xfu1g43KVTMFQ: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT += hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,eGW7cI6aQhr0(u"࠭࡬ࡪࡵࡷ᰷ࠫ"),R3lezw8h407ZvrAFxT(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ᰸")+mD5OIdgoTAaW9[:-llxMLe4gobHhsj1WGvd7qmIU],WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ᰹")+mD5OIdgoTAaW9+str(ODnPkfW6des))
			elif mD5OIdgoTAaW9==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ᰺"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT += b4SyKm2NREiu9ftVvXw5sZzLDnc(str(ODnPkfW6des),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ᰻"))
			elif mD5OIdgoTAaW9==lRP6GTaZJA1Xw3egLM4(u"ࠫࡤࡓ࠳ࡖࡡࠪ᰼"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT += P89MA7akmxvOcU0IdG(str(ODnPkfW6des),Hlp3z0APt1GR4kMYK5xST(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᰽"))
		for type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in UEsxyfd8rZMLOHgzc6emSFKD0ktYiT:
			if ui7N5YGR9KdslpEbQkVTwFqDgI==group: kqLBiwGX3V8P4SOmrNI1F7AMU(type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
		items,APRuYMmlIVGTX = [],[]
		for type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in emiIH49XT6jzOQrw:
			QNK6mr81UL0ZtX = type,JHKDFe6Am0ruz8[TQNS6YMKAqnilsVObLpDRX:],url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,NdKhAS6MXVEORLTwob92pxlZ
			if QNK6mr81UL0ZtX not in APRuYMmlIVGTX:
				APRuYMmlIVGTX.append(QNK6mr81UL0ZtX)
				rMOG2USkPesYZD9KNAVqpc = type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG
				items.append(rMOG2USkPesYZD9KNAVqpc)
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = sorted(items,reverse=lrtFSogC8Nh9(u"ࡊࡦࡲࡳࡦᵰ"),key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU].lower()[R3lezw8h407ZvrAFxT(u"࠶ᴮ"):])
		if pma7xfu1g43KVTMFQ: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ᰾")+mD5OIdgoTAaW9[:-llxMLe4gobHhsj1WGvd7qmIU],group,UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,hzP83xLawFqYneDtHGmSriWE)
	if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ᰿") in aPC0mLklY6jIUypFAwKbc and len(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT)>YwrpxbQCTn:
		emiIH49XT6jzOQrw[:] = []
		ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᱀"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩ࡞ࠫ᱁")+Whef0cxB2iR93SC5IwUtk+group+kjd9LyNqQHMUevZiRI7OlBGF1h+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࠤ࠿อไใี่ࡡࠬ᱂"),group,kb2icmDGVUZfW1OFz7sv(u"࠳࠹࠹ᴯ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,mD5OIdgoTAaW9+HVmIrFwau90jQsgiWzExk(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᱃"))
		ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᱄"),HVmIrFwau90jQsgiWzExk(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ᱅"),group,gniNItGL6bKwpEW(u"࠴࠺࠺ᴰ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,mD5OIdgoTAaW9+V0VZk9763fusTReHFo4(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱆"))
		ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࡮࡬ࡲࡰ࠭᱇"),Whef0cxB2iR93SC5IwUtk+lRP6GTaZJA1Xw3egLM4(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ᱈")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠽࠾࠿࠹ᴱ"))
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = emiIH49XT6jzOQrw+Ijo3hy7zQO5x8aU9vAZDMV.sample(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,YwrpxbQCTn)
	emiIH49XT6jzOQrw[:] = UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
	MIjcStaDWnv(NOrchaEV1iIZ87Uzlwgum(u"ࡋࡧ࡬ࡴࡧᵱ"))
	return
def lR3fdT4ZC15ucAwsbe02a9hrH8PWyO(aPC0mLklY6jIUypFAwKbc):
	ZI51XvE8YatWCmNdrp(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱉"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ᱊"),NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"࠶࠼࠱ᴲ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ᱋"))
	ZI51XvE8YatWCmNdrp(JGwsL21ZRlqSrWxEmF(u"࠭࡬ࡪࡰ࡮ࠫ᱌"),Whef0cxB2iR93SC5IwUtk+lRP6GTaZJA1Xw3egLM4(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᱍ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"࠿࠹࠺࠻ᴳ"))
	vLHYb9MdWB4RhVDJp = emiIH49XT6jzOQrw[:]
	emiIH49XT6jzOQrw[:] = []
	import nnVfdXFC9O
	nnVfdXFC9O.Hn70PSCVdsEvRXKz(hCm2fnEXs6Zt(u"ࠨ࠲ࠪᱎ"),IlL8ZnX74Yvep(u"ࡌࡡ࡭ࡵࡨᵲ"))
	nnVfdXFC9O.Hn70PSCVdsEvRXKz(Hlp3z0APt1GR4kMYK5xST(u"ࠩ࠴ࠫᱏ"),lRP6GTaZJA1Xw3egLM4(u"ࡆࡢ࡮ࡶࡩᵳ"))
	nnVfdXFC9O.Hn70PSCVdsEvRXKz(lRP6GTaZJA1Xw3egLM4(u"ࠪ࠶ࠬ᱐"),QQHFtjcaR2VpnSyTIv(u"ࡇࡣ࡯ࡷࡪᵴ"))
	if OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭᱑") in aPC0mLklY6jIUypFAwKbc:
		emiIH49XT6jzOQrw[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
		if len(emiIH49XT6jzOQrw)>YwrpxbQCTn: emiIH49XT6jzOQrw[:] = Ijo3hy7zQO5x8aU9vAZDMV.sample(emiIH49XT6jzOQrw,YwrpxbQCTn)
	emiIH49XT6jzOQrw[:] = vLHYb9MdWB4RhVDJp+emiIH49XT6jzOQrw
	return
def P2seICdOBvZy7iFcXSDEMja5G(aPC0mLklY6jIUypFAwKbc):
	aPC0mLklY6jIUypFAwKbc = aPC0mLklY6jIUypFAwKbc.replace(OOkmZiVcfqlEurM1dHGb(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ᱒"),NdKhAS6MXVEORLTwob92pxlZ).replace(HHvYL68lbJVZWM7tQEzSex3(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᱓"),NdKhAS6MXVEORLTwob92pxlZ)
	headers = { rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᱔") : NdKhAS6MXVEORLTwob92pxlZ }
	url = Hlp3z0APt1GR4kMYK5xST(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ᱕")
	data = {V0VZk9763fusTReHFo4(u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ᱖"):lRP6GTaZJA1Xw3egLM4(u"ࠪ࠹࠵࠭᱗")}
	data = g1Vmb5T39C(data)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(MIT0n79k8beo26aJHW,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡌࡋࡔࠨ᱘"),url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧ᱙"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(eGW7cI6aQhr0(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨᱚ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
	items = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᱛ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	RRaYF7SBdyHNtkWPEvCM591X,WVaFules5DJBkiLKdrC0XNon9f6G2Y = list(zip(*items))
	OOuT2fpzxCbymIPeQU6na5JNq7AsE = []
	Av52CkETaKN = [Vwgflszp4WRA93kx6hvdua21HX5cOb,HHvYL68lbJVZWM7tQEzSex3(u"ࠨࠤࠪᱜ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡣࠫᱝ"),lrtFSogC8Nh9(u"ࠪ࠰ࠬᱞ"),NeU6uRGpECkvMV5jf(u"ࠫ࠳࠭ᱟ"),R3lezw8h407ZvrAFxT(u"ࠬࡀࠧᱠ"),QQHFtjcaR2VpnSyTIv(u"࠭࠻ࠨᱡ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠢࠨࠤᱢ"),lRP6GTaZJA1Xw3egLM4(u"ࠨ࠯ࠪᱣ")]
	MMBqbQDnkGv21cwI = WVaFules5DJBkiLKdrC0XNon9f6G2Y+RRaYF7SBdyHNtkWPEvCM591X
	for Td7hCvctwSosx3nXrJaq9U in MMBqbQDnkGv21cwI:
		if Td7hCvctwSosx3nXrJaq9U in WVaFules5DJBkiLKdrC0XNon9f6G2Y: iiZgCVdhT1HKYNn8ztkMpDjR3 = cCRvAuJQfjBpTg0PbYiaNO87
		if Td7hCvctwSosx3nXrJaq9U in RRaYF7SBdyHNtkWPEvCM591X: iiZgCVdhT1HKYNn8ztkMpDjR3 = TQNS6YMKAqnilsVObLpDRX
		krqzMWuL8PZi = [xX6zt5oS08TO29CUhYJa1K in Td7hCvctwSosx3nXrJaq9U for xX6zt5oS08TO29CUhYJa1K in Av52CkETaKN]
		if any(krqzMWuL8PZi):
			Xd8PpnWk1RlgzSmuNjtK3 = krqzMWuL8PZi.index(eGW7cI6aQhr0(u"ࡖࡵࡹࡪᵵ"))
			jx08XmiVLkdyEUPzS = Av52CkETaKN[Xd8PpnWk1RlgzSmuNjtK3]
			f3nWBHZ4Fk1v5jNQRiszPXJyehgd = NdKhAS6MXVEORLTwob92pxlZ
			if Td7hCvctwSosx3nXrJaq9U.count(jx08XmiVLkdyEUPzS)>llxMLe4gobHhsj1WGvd7qmIU: P5ZH1QeqczLBki9V,JJVwtRsmDICazvyeu3WFpNKiMESn9,f3nWBHZ4Fk1v5jNQRiszPXJyehgd = Td7hCvctwSosx3nXrJaq9U.split(jx08XmiVLkdyEUPzS,cCRvAuJQfjBpTg0PbYiaNO87)
			else: P5ZH1QeqczLBki9V,JJVwtRsmDICazvyeu3WFpNKiMESn9 = Td7hCvctwSosx3nXrJaq9U.split(jx08XmiVLkdyEUPzS,llxMLe4gobHhsj1WGvd7qmIU)
			if len(P5ZH1QeqczLBki9V)>iiZgCVdhT1HKYNn8ztkMpDjR3: OOuT2fpzxCbymIPeQU6na5JNq7AsE.append(P5ZH1QeqczLBki9V.lower())
			if len(JJVwtRsmDICazvyeu3WFpNKiMESn9)>iiZgCVdhT1HKYNn8ztkMpDjR3: OOuT2fpzxCbymIPeQU6na5JNq7AsE.append(JJVwtRsmDICazvyeu3WFpNKiMESn9.lower())
			if len(f3nWBHZ4Fk1v5jNQRiszPXJyehgd)>iiZgCVdhT1HKYNn8ztkMpDjR3: OOuT2fpzxCbymIPeQU6na5JNq7AsE.append(f3nWBHZ4Fk1v5jNQRiszPXJyehgd.lower())
		elif len(Td7hCvctwSosx3nXrJaq9U)>iiZgCVdhT1HKYNn8ztkMpDjR3: OOuT2fpzxCbymIPeQU6na5JNq7AsE.append(Td7hCvctwSosx3nXrJaq9U.lower())
	for xX6zt5oS08TO29CUhYJa1K in range(IlL8ZnX74Yvep(u"࠹ᴴ")): Ijo3hy7zQO5x8aU9vAZDMV.shuffle(OOuT2fpzxCbymIPeQU6na5JNq7AsE)
	if kb2icmDGVUZfW1OFz7sv(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪᱤ") in aPC0mLklY6jIUypFAwKbc:
		AYCJD58IT1mOw = V0fxhGR6MoiWNebgd7yS4jvE
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡣࡎࡖࡔࡗࡡࠪᱥ") in aPC0mLklY6jIUypFAwKbc:
		AYCJD58IT1mOw = [kb2icmDGVUZfW1OFz7sv(u"ࠫࡎࡖࡔࡗࠩᱦ")]
		import dduW7Cg5Fx
		if not dduW7Cg5Fx.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࡗࡶࡺ࡫ᵶ")): return
	elif JGwsL21ZRlqSrWxEmF(u"ࠬࡥࡍ࠴ࡗࡢࠫᱧ") in aPC0mLklY6jIUypFAwKbc:
		AYCJD58IT1mOw = [kb2icmDGVUZfW1OFz7sv(u"࠭ࡍ࠴ࡗࠪᱨ")]
		import ws4trNj60m
		if not ws4trNj60m.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࡘࡷࡻࡥᵷ")): return
	count,VV3fqASmdsTYPp7c = e8XhbyuzvjYkIsJUtB5w,e8XhbyuzvjYkIsJUtB5w
	ZI51XvE8YatWCmNdrp(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱩ"),R3lezw8h407ZvrAFxT(u"ࠨ࡝ࠣࠤࡢࠦ࠺ศๆหัะูࠦ็ࠩᱪ"),NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠲࠸࠷ᴵ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᱫ")+aPC0mLklY6jIUypFAwKbc)
	ZI51XvE8YatWCmNdrp(IlL8ZnX74Yvep(u"ࠪࡪࡴࡲࡤࡦࡴࠪᱬ"),lRP6GTaZJA1Xw3egLM4(u"ࠫส฿วะหࠣห้ฮอฬࠢส่฾ฺ่ศศํࠫᱭ"),NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"࠳࠹࠸ᴶ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱮ")+aPC0mLklY6jIUypFAwKbc)
	ZI51XvE8YatWCmNdrp(R3lezw8h407ZvrAFxT(u"࠭࡬ࡪࡰ࡮ࠫᱯ"),Whef0cxB2iR93SC5IwUtk+rNyT0edugn(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᱰ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"࠼࠽࠾࠿ᴷ"))
	E5ud6qaxeSL2z1UBHKjfcO = emiIH49XT6jzOQrw[:]
	emiIH49XT6jzOQrw[:] = []
	qTIxglyKPG3i4ZNt7fu8RMv0LD = []
	for Td7hCvctwSosx3nXrJaq9U in OOuT2fpzxCbymIPeQU6na5JNq7AsE:
		JJVwtRsmDICazvyeu3WFpNKiMESn9 = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀࠨᱱ")+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࠦࠫᱲ")+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧᱳ"),Td7hCvctwSosx3nXrJaq9U,YYqECUofyi7wFrW.DOTALL)
		if JJVwtRsmDICazvyeu3WFpNKiMESn9: Td7hCvctwSosx3nXrJaq9U = Td7hCvctwSosx3nXrJaq9U.split(JJVwtRsmDICazvyeu3WFpNKiMESn9[e8XhbyuzvjYkIsJUtB5w],llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		ZZScNar0w6KnuXCMqHtoDEjyB = Td7hCvctwSosx3nXrJaq9U.replace(V0VZk9763fusTReHFo4(u"ࠫ๖࠭ᱴ"),NdKhAS6MXVEORLTwob92pxlZ).replace(OOkmZiVcfqlEurM1dHGb(u"ࠬ๔ࠧᱵ"),NdKhAS6MXVEORLTwob92pxlZ).replace(rNyT0edugn(u"๋࠭ࠨᱶ"),NdKhAS6MXVEORLTwob92pxlZ).replace(JGwsL21ZRlqSrWxEmF(u"ࠧ๐ࠩᱷ"),NdKhAS6MXVEORLTwob92pxlZ).replace(NOrchaEV1iIZ87Uzlwgum(u"ࠨ๎ࠪᱸ"),NdKhAS6MXVEORLTwob92pxlZ)
		ZZScNar0w6KnuXCMqHtoDEjyB = ZZScNar0w6KnuXCMqHtoDEjyB.replace(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ๓ࠫᱹ"),NdKhAS6MXVEORLTwob92pxlZ).replace(hCm2fnEXs6Zt(u"ࠪ๑ࠬᱺ"),NdKhAS6MXVEORLTwob92pxlZ).replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ๗࠭ᱻ"),NdKhAS6MXVEORLTwob92pxlZ).replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠬฒࠧᱼ"),NdKhAS6MXVEORLTwob92pxlZ).replace(xY4icgQUj6mPVs73CTKu(u"࠭เࠨᱽ"),NdKhAS6MXVEORLTwob92pxlZ)
		if ZZScNar0w6KnuXCMqHtoDEjyB: qTIxglyKPG3i4ZNt7fu8RMv0LD.append(ZZScNar0w6KnuXCMqHtoDEjyB)
	p2mJ0OMsDY = []
	for XW2Opt4RQsVihunCylz6j in range(e8XhbyuzvjYkIsJUtB5w,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠶࠵ᴸ")):
		search = Ijo3hy7zQO5x8aU9vAZDMV.sample(qTIxglyKPG3i4ZNt7fu8RMv0LD,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		if search in p2mJ0OMsDY: continue
		p2mJ0OMsDY.append(search)
		mAH4aPy8q1w = Ijo3hy7zQO5x8aU9vAZDMV.sample(AYCJD58IT1mOw,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NeU6uRGpECkvMV5jf(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ᱾")+str(mAH4aPy8q1w)+QQHFtjcaR2VpnSyTIv(u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ᱿")+search)
		QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
		vbpSAKljzB4xR8UPkyY2whrVG(search+IlL8ZnX74Yvep(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧᲀ"))
		if len(emiIH49XT6jzOQrw)>e8XhbyuzvjYkIsJUtB5w: break
	search = search.replace(lNTJCZeBicWEz0Mg(u"ࠪࡣࡒࡕࡄࡠࠩᲁ"),NdKhAS6MXVEORLTwob92pxlZ)
	E5ud6qaxeSL2z1UBHKjfcO[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU] = QQHFtjcaR2VpnSyTIv(u"ࠫࡠ࠭ᲂ")+Whef0cxB2iR93SC5IwUtk+search+kjd9LyNqQHMUevZiRI7OlBGF1h+PzIpQnUXxRwNCivDhdakWTE(u"ࠬࠦ࠺ษฯฮࠤ฾์࡝ࠨᲃ")
	emiIH49XT6jzOQrw[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
	if len(emiIH49XT6jzOQrw)>YwrpxbQCTn: emiIH49XT6jzOQrw[:] = Ijo3hy7zQO5x8aU9vAZDMV.sample(emiIH49XT6jzOQrw,YwrpxbQCTn)
	emiIH49XT6jzOQrw[:] = E5ud6qaxeSL2z1UBHKjfcO+emiIH49XT6jzOQrw
	return
def HPm5g7Aa8bvLZF9Kcfqk(v3xo7brKtVkc8,aPC0mLklY6jIUypFAwKbc):
	v3xo7brKtVkc8 = v3xo7brKtVkc8.replace(HVmIrFwau90jQsgiWzExk(u"࠭࡟ࡎࡑࡇࡣࠬᲄ"),NdKhAS6MXVEORLTwob92pxlZ)
	aPC0mLklY6jIUypFAwKbc = aPC0mLklY6jIUypFAwKbc.replace(V0VZk9763fusTReHFo4(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲅ"),NdKhAS6MXVEORLTwob92pxlZ).replace(V0VZk9763fusTReHFo4(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲆ"),NdKhAS6MXVEORLTwob92pxlZ)
	FFJgfRUhiXunyS80(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࡋࡧ࡬ࡴࡧᵸ"))
	if not BDG2gRTNFL37J6P5i: return
	if Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᲇ") in aPC0mLklY6jIUypFAwKbc:
		ZI51XvE8YatWCmNdrp(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲈ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡠ࠭Ᲊ")+Whef0cxB2iR93SC5IwUtk+v3xo7brKtVkc8+kjd9LyNqQHMUevZiRI7OlBGF1h+lRP6GTaZJA1Xw3egLM4(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᲊ"),v3xo7brKtVkc8,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠶࠼࠶ᴹ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᲋")+aPC0mLklY6jIUypFAwKbc)
		ZI51XvE8YatWCmNdrp(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᲌"),lrtFSogC8Nh9(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ᲍"),v3xo7brKtVkc8,fOc18oTm5hsdD4pVZQj(u"࠷࠶࠷ᴺ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᲎")+aPC0mLklY6jIUypFAwKbc)
		ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡰ࡮ࡴ࡫ࠨ᲏"),Whef0cxB2iR93SC5IwUtk+HVmIrFwau90jQsgiWzExk(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᲐ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"࠹࠺࠻࠼ᴻ"))
	for website in sorted(list(BDG2gRTNFL37J6P5i[v3xo7brKtVkc8].keys())):
		type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = BDG2gRTNFL37J6P5i[v3xo7brKtVkc8][website]
		if PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᲑ") in aPC0mLklY6jIUypFAwKbc or len(BDG2gRTNFL37J6P5i[v3xo7brKtVkc8])==llxMLe4gobHhsj1WGvd7qmIU:
			kqLBiwGX3V8P4SOmrNI1F7AMU(type,NdKhAS6MXVEORLTwob92pxlZ,url,wnBVNedG0L9m,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
			emiIH49XT6jzOQrw[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
			eutCMzlLsmdypFwU,RKFv4AP3fDzwtisg6V1nGCQyjbu = emiIH49XT6jzOQrw[:uL69vJOU7xN0hGnZf2islDqk],emiIH49XT6jzOQrw[uL69vJOU7xN0hGnZf2islDqk:]
			if JGwsL21ZRlqSrWxEmF(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᲒ") in aPC0mLklY6jIUypFAwKbc:
				for xX6zt5oS08TO29CUhYJa1K in range(eGW7cI6aQhr0(u"࠺ᴼ")): Ijo3hy7zQO5x8aU9vAZDMV.shuffle(RKFv4AP3fDzwtisg6V1nGCQyjbu)
				emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu[:YwrpxbQCTn]
			else: emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu
		elif xY4icgQUj6mPVs73CTKu(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨᲓ") in aPC0mLklY6jIUypFAwKbc: ZI51XvE8YatWCmNdrp(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲔ"),website,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	return
def CDBuKYygJSWr(aPC0mLklY6jIUypFAwKbc,pPrvqm3tjuXLTgw1):
	aPC0mLklY6jIUypFAwKbc = aPC0mLklY6jIUypFAwKbc.replace(hCm2fnEXs6Zt(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᲕ"),NdKhAS6MXVEORLTwob92pxlZ).replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᲖ"),NdKhAS6MXVEORLTwob92pxlZ)
	JHKDFe6Am0ruz8,RKFv4AP3fDzwtisg6V1nGCQyjbu = NdKhAS6MXVEORLTwob92pxlZ,[]
	ZI51XvE8YatWCmNdrp(Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲗ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡡࠧᲘ")+Whef0cxB2iR93SC5IwUtk+JHKDFe6Am0ruz8+kjd9LyNqQHMUevZiRI7OlBGF1h+NOrchaEV1iIZ87Uzlwgum(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨᲙ"),NdKhAS6MXVEORLTwob92pxlZ,pPrvqm3tjuXLTgw1,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲚ")+aPC0mLklY6jIUypFAwKbc)
	ZI51XvE8YatWCmNdrp(hCm2fnEXs6Zt(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲛ"),kb2icmDGVUZfW1OFz7sv(u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩᲜ"),NdKhAS6MXVEORLTwob92pxlZ,pPrvqm3tjuXLTgw1,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲝ")+aPC0mLklY6jIUypFAwKbc)
	ZI51XvE8YatWCmNdrp(lrtFSogC8Nh9(u"ࠫࡱ࡯࡮࡬ࠩᲞ"),Whef0cxB2iR93SC5IwUtk+Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᲟ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠻࠼࠽࠾ᴽ"))
	eutCMzlLsmdypFwU = emiIH49XT6jzOQrw[:]
	emiIH49XT6jzOQrw[:] = []
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = []
	if gniNItGL6bKwpEW(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧᲠ") in aPC0mLklY6jIUypFAwKbc:
		FFJgfRUhiXunyS80(rNyT0edugn(u"ࡌࡡ࡭ࡵࡨᵹ"))
		if not BDG2gRTNFL37J6P5i: return
		ZPdnGV3yMNJWQsk9wK4cSUr2f8 = list(BDG2gRTNFL37J6P5i.keys())
		v3xo7brKtVkc8 = Ijo3hy7zQO5x8aU9vAZDMV.sample(ZPdnGV3yMNJWQsk9wK4cSUr2f8,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		OOuT2fpzxCbymIPeQU6na5JNq7AsE = list(BDG2gRTNFL37J6P5i[v3xo7brKtVkc8].keys())
		website = Ijo3hy7zQO5x8aU9vAZDMV.sample(OOuT2fpzxCbymIPeQU6na5JNq7AsE,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = BDG2gRTNFL37J6P5i[v3xo7brKtVkc8][website]
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+rNyT0edugn(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪᲡ")+website+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫᲢ")+JHKDFe6Am0ruz8+NOrchaEV1iIZ87Uzlwgum(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫᲣ")+url+V0VZk9763fusTReHFo4(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭Ფ")+str(wnBVNedG0L9m))
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠫࡤࡏࡐࡕࡘࡢࠫᲥ") in aPC0mLklY6jIUypFAwKbc:
		import dduW7Cg5Fx
		if not dduW7Cg5Fx.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࡔࡳࡷࡨᵺ")): return
		for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
			UEsxyfd8rZMLOHgzc6emSFKD0ktYiT += b4SyKm2NREiu9ftVvXw5sZzLDnc(str(ODnPkfW6des),aPC0mLklY6jIUypFAwKbc)
		if not UEsxyfd8rZMLOHgzc6emSFKD0ktYiT: return
		type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = Ijo3hy7zQO5x8aU9vAZDMV.sample(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NeU6uRGpECkvMV5jf(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬᲦ")+JHKDFe6Am0ruz8+xY4icgQUj6mPVs73CTKu(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨᲧ")+url+IlL8ZnX74Yvep(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪᲨ")+str(wnBVNedG0L9m))
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠨࡡࡐ࠷࡚ࡥࠧᲩ") in aPC0mLklY6jIUypFAwKbc:
		import ws4trNj60m
		if not ws4trNj60m.vUGsjuw7mN8TFakprdZXV(NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࡕࡴࡸࡩᵻ")): return
		for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
			UEsxyfd8rZMLOHgzc6emSFKD0ktYiT += P89MA7akmxvOcU0IdG(str(ODnPkfW6des),aPC0mLklY6jIUypFAwKbc)
		if not UEsxyfd8rZMLOHgzc6emSFKD0ktYiT: return
		type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = Ijo3hy7zQO5x8aU9vAZDMV.sample(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Hlp3z0APt1GR4kMYK5xST(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩᲪ")+JHKDFe6Am0ruz8+lrtFSogC8Nh9(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬᲫ")+url+NOrchaEV1iIZ87Uzlwgum(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧᲬ")+str(wnBVNedG0L9m))
	y3YCh0HFIsA1k = JHKDFe6Am0ruz8
	vlQWXwHa3iPE7486c = []
	for xX6zt5oS08TO29CUhYJa1K in range(e8XhbyuzvjYkIsJUtB5w,eGW7cI6aQhr0(u"࠴࠴ᴾ")):
		if xX6zt5oS08TO29CUhYJa1K>e8XhbyuzvjYkIsJUtB5w: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬᲭ")+JHKDFe6Am0ruz8+pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨᲮ")+url+eGW7cI6aQhr0(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪᲯ")+str(wnBVNedG0L9m))
		emiIH49XT6jzOQrw[:] = []
		if wnBVNedG0L9m==JGwsL21ZRlqSrWxEmF(u"࠶࠸࠺ᴿ") and IlL8ZnX74Yvep(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᲰ") in ui7N5YGR9KdslpEbQkVTwFqDgI: wnBVNedG0L9m = V0VZk9763fusTReHFo4(u"࠷࠹࠳ᵀ")
		if wnBVNedG0L9m==OOkmZiVcfqlEurM1dHGb(u"࠽࠱࠵ᵁ") and lRP6GTaZJA1Xw3egLM4(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᲱ") in ui7N5YGR9KdslpEbQkVTwFqDgI: wnBVNedG0L9m = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠷࠲࠵ᵂ")
		if wnBVNedG0L9m==PzIpQnUXxRwNCivDhdakWTE(u"࠲࠶࠷ᵃ"): wnBVNedG0L9m = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠴࠼࠵ᵄ")
		gHbS3MaYo0j6uTdm2qyQnKP = kqLBiwGX3V8P4SOmrNI1F7AMU(type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
		if lRP6GTaZJA1Xw3egLM4(u"ࠪࡣࡎࡖࡔࡗࡡࠪᲲ") in aPC0mLklY6jIUypFAwKbc and wnBVNedG0L9m==kb2icmDGVUZfW1OFz7sv(u"࠴࠺࠼ᵅ"): del emiIH49XT6jzOQrw[:uL69vJOU7xN0hGnZf2islDqk]
		if Hlp3z0APt1GR4kMYK5xST(u"ࠫࡤࡓ࠳ࡖࡡࠪᲳ") in aPC0mLklY6jIUypFAwKbc and wnBVNedG0L9m==xY4icgQUj6mPVs73CTKu(u"࠵࠻࠾ᵆ"): del emiIH49XT6jzOQrw[:uL69vJOU7xN0hGnZf2islDqk]
		RKFv4AP3fDzwtisg6V1nGCQyjbu[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
		if vlQWXwHa3iPE7486c and jBwT7etlxOuUgakyX6CL(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࡺ࠭อๅไฬࠫᲴ")) in str(RKFv4AP3fDzwtisg6V1nGCQyjbu) or jBwT7etlxOuUgakyX6CL(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࡻࠧฮๆๅ๋ࠬᲵ")) in str(RKFv4AP3fDzwtisg6V1nGCQyjbu):
			JHKDFe6Am0ruz8 = y3YCh0HFIsA1k
			RKFv4AP3fDzwtisg6V1nGCQyjbu[:] = vlQWXwHa3iPE7486c
			break
		y3YCh0HFIsA1k = JHKDFe6Am0ruz8
		vlQWXwHa3iPE7486c = RKFv4AP3fDzwtisg6V1nGCQyjbu
		if str(RKFv4AP3fDzwtisg6V1nGCQyjbu).count(eGW7cI6aQhr0(u"ࠧࡷ࡫ࡧࡩࡴ࠭Ჶ"))>e8XhbyuzvjYkIsJUtB5w: break
		if str(RKFv4AP3fDzwtisg6V1nGCQyjbu).count(V0VZk9763fusTReHFo4(u"ࠨ࡮࡬ࡺࡪ࠭Ჷ"))>e8XhbyuzvjYkIsJUtB5w: break
		if wnBVNedG0L9m==lRP6GTaZJA1Xw3egLM4(u"࠷࠹࠳ᵇ"): break
		if wnBVNedG0L9m==V0VZk9763fusTReHFo4(u"࠽࠱࠴ᵈ"): break
		if wnBVNedG0L9m==NOrchaEV1iIZ87Uzlwgum(u"࠲࠺࠳ᵉ"): break
		if lNTJCZeBicWEz0Mg(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᲸ") in aPC0mLklY6jIUypFAwKbc and RKFv4AP3fDzwtisg6V1nGCQyjbu: type,JHKDFe6Am0ruz8,url,wnBVNedG0L9m,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = Ijo3hy7zQO5x8aU9vAZDMV.sample(RKFv4AP3fDzwtisg6V1nGCQyjbu,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
	if not JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = fOc18oTm5hsdD4pVZQj(u"ࠪ࠲࠳࠴࠮ࠨᲹ")
	elif JHKDFe6Am0ruz8.count(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡤ࠭Ჺ"))>llxMLe4gobHhsj1WGvd7qmIU: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.split(lRP6GTaZJA1Xw3egLM4(u"ࠬࡥࠧ᲻"),cCRvAuJQfjBpTg0PbYiaNO87)[cCRvAuJQfjBpTg0PbYiaNO87]
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(hCm2fnEXs6Zt(u"࠭ࡕࡏࡍࡑࡓ࡜ࡔ࠺ࠡࠩ᲼"),NdKhAS6MXVEORLTwob92pxlZ)
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡠࡏࡒࡈࡤ࠭Ჽ"),NdKhAS6MXVEORLTwob92pxlZ)
	eutCMzlLsmdypFwU[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU] = lNTJCZeBicWEz0Mg(u"ࠨ࡝ࠪᲾ")+Whef0cxB2iR93SC5IwUtk+JHKDFe6Am0ruz8+kjd9LyNqQHMUevZiRI7OlBGF1h+R3lezw8h407ZvrAFxT(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫᲿ")
	if pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ᳀") in aPC0mLklY6jIUypFAwKbc:
		for xX6zt5oS08TO29CUhYJa1K in range(fOc18oTm5hsdD4pVZQj(u"࠺ᵊ")): Ijo3hy7zQO5x8aU9vAZDMV.shuffle(RKFv4AP3fDzwtisg6V1nGCQyjbu)
		emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu[:YwrpxbQCTn]
	else: emiIH49XT6jzOQrw[:] = eutCMzlLsmdypFwU+RKFv4AP3fDzwtisg6V1nGCQyjbu
	return
def QZSsYmu9WE(idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi):
	jUqrGPQ5yZCYFi = jUqrGPQ5yZCYFi.replace(hCm2fnEXs6Zt(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳁"),NdKhAS6MXVEORLTwob92pxlZ).replace(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᳂"),NdKhAS6MXVEORLTwob92pxlZ)
	knu67Khesfvr40YSjVaiobg52 = jUqrGPQ5yZCYFi
	if vju3SZDWL4ENYelmBOzUqrogp2(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ᳃") in jUqrGPQ5yZCYFi:
		knu67Khesfvr40YSjVaiobg52 = jUqrGPQ5yZCYFi.split(kb2icmDGVUZfW1OFz7sv(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ᳄"))[e8XhbyuzvjYkIsJUtB5w]
		type = Hlp3z0APt1GR4kMYK5xST(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ᳅")
	elif lNTJCZeBicWEz0Mg(u"࡙ࠩࡓࡉ࠭᳆") in idUOP3c7JeGNCVr1XukBn: type = rNyT0edugn(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭᳇")
	elif WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡑࡏࡖࡆࠩ᳈") in idUOP3c7JeGNCVr1XukBn: type = HVmIrFwau90jQsgiWzExk(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭᳉")
	ZI51XvE8YatWCmNdrp(xY4icgQUj6mPVs73CTKu(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳊"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧ࡜ࠩ᳋")+Whef0cxB2iR93SC5IwUtk+type+knu67Khesfvr40YSjVaiobg52+kjd9LyNqQHMUevZiRI7OlBGF1h+kb2icmDGVUZfW1OFz7sv(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪ᳌"),idUOP3c7JeGNCVr1XukBn,R3lezw8h407ZvrAFxT(u"࠳࠹࠻ᵋ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳍")+jUqrGPQ5yZCYFi)
	ZI51XvE8YatWCmNdrp(kb2icmDGVUZfW1OFz7sv(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳎"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ᳏"),idUOP3c7JeGNCVr1XukBn,gniNItGL6bKwpEW(u"࠴࠺࠼ᵌ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳐")+jUqrGPQ5yZCYFi)
	ZI51XvE8YatWCmNdrp(V0VZk9763fusTReHFo4(u"࠭࡬ࡪࡰ࡮ࠫ᳑"),Whef0cxB2iR93SC5IwUtk+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᳒")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"࠽࠾࠿࠹ᵍ"))
	import dduW7Cg5Fx
	for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
		if IlL8ZnX74Yvep(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ᳓") in jUqrGPQ5yZCYFi: dduW7Cg5Fx.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(str(ODnPkfW6des),idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࡈࡤࡰࡸ࡫ᵼ"))
		else: dduW7Cg5Fx.Hn70PSCVdsEvRXKz(str(ODnPkfW6des),idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࡉࡥࡱࡹࡥᵽ"))
	emiIH49XT6jzOQrw[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
	if len(emiIH49XT6jzOQrw)>(YwrpxbQCTn+uL69vJOU7xN0hGnZf2islDqk): emiIH49XT6jzOQrw[:] = emiIH49XT6jzOQrw[:uL69vJOU7xN0hGnZf2islDqk]+Ijo3hy7zQO5x8aU9vAZDMV.sample(emiIH49XT6jzOQrw[uL69vJOU7xN0hGnZf2islDqk:],YwrpxbQCTn)
	return
def NI50pK7kOvDUldLZrm(idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi):
	jUqrGPQ5yZCYFi = jUqrGPQ5yZCYFi.replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢ᳔ࠫ"),NdKhAS6MXVEORLTwob92pxlZ).replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳕ࠧ"),NdKhAS6MXVEORLTwob92pxlZ)
	knu67Khesfvr40YSjVaiobg52 = jUqrGPQ5yZCYFi
	if lRP6GTaZJA1Xw3egLM4(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢ᳖ࠫ") in jUqrGPQ5yZCYFi:
		knu67Khesfvr40YSjVaiobg52 = jUqrGPQ5yZCYFi.split(PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣ᳗ࠬ"))[e8XhbyuzvjYkIsJUtB5w]
		type = HHvYL68lbJVZWM7tQEzSex3(u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺᳘ࠡࠩ")
	elif lNTJCZeBicWEz0Mg(u"ࠧࡗࡑࡇ᳙ࠫ") in idUOP3c7JeGNCVr1XukBn: type = Hlp3z0APt1GR4kMYK5xST(u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ᳚")
	elif fOc18oTm5hsdD4pVZQj(u"ࠩࡏࡍ࡛ࡋࠧ᳛") in idUOP3c7JeGNCVr1XukBn: type = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪ࠰ࡑࡏࡖࡆ࠼᳜ࠣࠫ")
	ZI51XvE8YatWCmNdrp(NOrchaEV1iIZ87Uzlwgum(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡡ᳞ࠧ")+Whef0cxB2iR93SC5IwUtk+type+knu67Khesfvr40YSjVaiobg52+kjd9LyNqQHMUevZiRI7OlBGF1h+IlL8ZnX74Yvep(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨ᳟"),idUOP3c7JeGNCVr1XukBn,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠶࠼࠸ᵎ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᳠")+jUqrGPQ5yZCYFi)
	ZI51XvE8YatWCmNdrp(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳡"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ᳢"),idUOP3c7JeGNCVr1XukBn,lNTJCZeBicWEz0Mg(u"࠷࠶࠹ᵏ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳣")+jUqrGPQ5yZCYFi)
	ZI51XvE8YatWCmNdrp(V0VZk9763fusTReHFo4(u"ࠫࡱ࡯࡮࡬᳤ࠩ"),Whef0cxB2iR93SC5IwUtk+R3lezw8h407ZvrAFxT(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾᳥ࠢࠪ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"࠹࠺࠻࠼ᵐ"))
	import ws4trNj60m
	for ODnPkfW6des in range(llxMLe4gobHhsj1WGvd7qmIU,zWinZrBTwI3stoS7+llxMLe4gobHhsj1WGvd7qmIU):
		if HHvYL68lbJVZWM7tQEzSex3(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ᳦࠭") in jUqrGPQ5yZCYFi: ws4trNj60m.RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(str(ODnPkfW6des),idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࡊࡦࡲࡳࡦᵾ"))
		else: ws4trNj60m.Hn70PSCVdsEvRXKz(str(ODnPkfW6des),idUOP3c7JeGNCVr1XukBn,jUqrGPQ5yZCYFi,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࡋࡧ࡬ࡴࡧᵿ"))
	emiIH49XT6jzOQrw[:] = LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw)
	if len(emiIH49XT6jzOQrw)>(YwrpxbQCTn+uL69vJOU7xN0hGnZf2islDqk): emiIH49XT6jzOQrw[:] = emiIH49XT6jzOQrw[:uL69vJOU7xN0hGnZf2islDqk]+Ijo3hy7zQO5x8aU9vAZDMV.sample(emiIH49XT6jzOQrw[uL69vJOU7xN0hGnZf2islDqk:],YwrpxbQCTn)
	return
def LYmIkCVlzjAMUQu0KvXTb2PWBp(emiIH49XT6jzOQrw):
	jbJ7WONEa2Ki3qcZVw = []
	for type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in emiIH49XT6jzOQrw:
		if lRP6GTaZJA1Xw3egLM4(u"ࠧึใะอ᳧ࠬ") in JHKDFe6Am0ruz8 or gniNItGL6bKwpEW(u"ࠨืไั์᳨࠭") in JHKDFe6Am0ruz8 or rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡳࡥ࡬࡫ࠧᳩ") in JHKDFe6Am0ruz8.lower(): continue
		jbJ7WONEa2Ki3qcZVw.append([type,JHKDFe6Am0ruz8,url,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG])
	return jbJ7WONEa2Ki3qcZVw
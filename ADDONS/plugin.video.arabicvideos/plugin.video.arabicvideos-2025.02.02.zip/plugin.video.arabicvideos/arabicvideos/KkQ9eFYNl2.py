# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'CIMALIGHT'
LJfTAEQPv9h4BXdwUp = '_CML_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['قنوات فضائية']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==470: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==471: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==472: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==473: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = o2XkvGWlaVzsUjdDLbQpg8(url,text)
	elif mode==474: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==479: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = YYqECUofyi7wFrW.findall('"url": "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	REGxsWAoilB7dCFNgMhz0V98bcm = REGxsWAoilB7dCFNgMhz0V98bcm[0].strip('/')
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(REGxsWAoilB7dCFNgMhz0V98bcm,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,479,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"content"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		title = title.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('cat=online-movies1','cat=online-movies')
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,474)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('/category.php">(.*?)"navslide-divider"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("'dropdown-menu'(.*?)</ul>",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,474)
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if 'topvideos.php' in url: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"caret"(.*?)id="pm-grid"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"caret"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if 'topvideos.php' in zehVcU893FC6LEd1Aij:
				if 'topvideos.php?c=english-movies' in zehVcU893FC6LEd1Aij: continue
				if 'topvideos.php?c=online-movies1' in zehVcU893FC6LEd1Aij: continue
				if 'topvideos.php?c=misc' in zehVcU893FC6LEd1Aij: continue
				if 'topvideos.php?c=tv-channel' in zehVcU893FC6LEd1Aij: continue
				if 'منذ البداية' in title and 'do=rating' not in zehVcU893FC6LEd1Aij: continue
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,471)
	else: hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = []
	if kF13d0oJXn4xKH=='featured_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"container-fluid"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL,qPEWyfuGbLYxSa5eRmVC4OrpA = zip(*items)
		items = zip(qPEWyfuGbLYxSa5eRmVC4OrpA,oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL)
	elif kF13d0oJXn4xKH=='featured_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('المسلسلات المميزة(.*?)<style>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL,qPEWyfuGbLYxSa5eRmVC4OrpA = zip(*items)
		items = zip(qPEWyfuGbLYxSa5eRmVC4OrpA,oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(data-echo=".*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"BlocksList"(.*?)"titleSectionCon"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="pm-grid"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="pm-related"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pm-ul-browse-videos(.*?)clearfix',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items: items = YYqECUofyi7wFrW.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items: items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		title = title.replace('ماي سيما',NdKhAS6MXVEORLTwob92pxlZ).replace('مشاهدة',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
		if 'http' not in TTuPH708dUNnjlG3oQpkZsi: TTuPH708dUNnjlG3oQpkZsi = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+TTuPH708dUNnjlG3oQpkZsi.strip('/')
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة) \d+',title,YYqECUofyi7wFrW.DOTALL)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			title = '_MOD_'+title
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,472,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'حلقة' in title:
			title = '_MOD_'+N1VjdbtuO3z[0][0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,473,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/movseries/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,471,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,473,TTuPH708dUNnjlG3oQpkZsi)
	if kF13d0oJXn4xKH not in ['featured_movies','featured_series']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=='#': continue
				zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,471)
		ZZvTe8pmBr1buPwaj9N = YYqECUofyi7wFrW.findall('showmore" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if ZZvTe8pmBr1buPwaj9N:
			zehVcU893FC6LEd1Aij = ZZvTe8pmBr1buPwaj9N[0]
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مشاهدة المزيد',zehVcU893FC6LEd1Aij,471)
	return
def o2XkvGWlaVzsUjdDLbQpg8(url,ck82Wb9aGlYMsEImj):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-EPISODES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"SeasonsBox"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	items = []
	if yyuOVAGPZijetcaNz0b and not ck82Wb9aGlYMsEImj:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"series-header".*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0] if TTuPH708dUNnjlG3oQpkZsi else NdKhAS6MXVEORLTwob92pxlZ
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if len(items)==1: ck82Wb9aGlYMsEImj = items[0][0]
		elif len(items)>1:
			for ck82Wb9aGlYMsEImj,title in items: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,473,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,ck82Wb9aGlYMsEImj)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('id="'+ck82Wb9aGlYMsEImj+'"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1 and len(items)<2:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"series-header".*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0] if TTuPH708dUNnjlG3oQpkZsi else NdKhAS6MXVEORLTwob92pxlZ
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if items:
			for zehVcU893FC6LEd1Aij,title in items:
				title = title.replace('ماي سيما',NdKhAS6MXVEORLTwob92pxlZ).replace('مسلسل',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,472,TTuPH708dUNnjlG3oQpkZsi)
		else:
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,472,TTuPH708dUNnjlG3oQpkZsi)
	if 'id="pm-related"' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		if items: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مواضيع ذات صلة',url,471)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl = []
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<div itemprop="description">(.*?)href=',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('<p>(.*?)</p>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA,True): return
	BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/watch.php','/play.php')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-PLAY-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	xD7svMcqe5NrRVIUSOgiAy = []
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('"embedURL" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
		if zehVcU893FC6LEd1Aij and zehVcU893FC6LEd1Aij not in xD7svMcqe5NrRVIUSOgiAy:
			xD7svMcqe5NrRVIUSOgiAy.append(zehVcU893FC6LEd1Aij)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named=__embed'
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	items = YYqECUofyi7wFrW.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if zehVcU893FC6LEd1Aij not in xD7svMcqe5NrRVIUSOgiAy:
			xD7svMcqe5NrRVIUSOgiAy.append(zehVcU893FC6LEd1Aij)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/watch.php','/downloads.php')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMALIGHT-PLAY-3rd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"downloadlist"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<strong>(.*?)</strong>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if zehVcU893FC6LEd1Aij not in xD7svMcqe5NrRVIUSOgiAy:
				xD7svMcqe5NrRVIUSOgiAy.append(zehVcU893FC6LEd1Aij)
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'url')
	url = oikt6P0hOAD5IvnlMpxf1+'/search.php?keywords='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
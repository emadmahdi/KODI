# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'FAJERSHOW'
LJfTAEQPv9h4BXdwUp = '_FJS_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==390: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==391: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==392: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==393: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==399: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,399,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FAJERSHOW-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = YYqECUofyi7wFrW.findall('<header>.*?<h2>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for rAknWUHpDyi4IuGPfl2QYR in range(len(items)):
		title = items[rAknWUHpDyi4IuGPfl2QYR]
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'latest'+str(rAknWUHpDyi4IuGPfl2QYR))
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مختارات عشوائية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'randoms')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أعلى الأفلام تقييماً',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'top_imdb_movies')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أعلى المسلسلات تقييماً',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'top_imdb_series')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أفلام مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movies',391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured_movies')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/tvshows',391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured_tvshows')
	AAMHoYxRCmt2D6ph89W = NdKhAS6MXVEORLTwob92pxlZ
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="menu"(.*?)id="contenedor"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W += bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movies',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FAJERSHOW-MENU-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="releases"(.*?)aside',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W += bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	D1BVdF2w4cm8fbTIv6AhjtNkPHx = True
	for zehVcU893FC6LEd1Aij,title in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if title=='الأعلى مشاهدة':
			if D1BVdF2w4cm8fbTIv6AhjtNkPHx:
				title = 'الافلام '+title
				D1BVdF2w4cm8fbTIv6AhjtNkPHx = False
			else: title = 'المسلسلات '+title
		if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
			if title=='أفلام': ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movies',391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'all_movies_tvshows')
			elif title=='مسلسلات': ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/tvshows',391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'all_movies_tvshows')
			else: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,391)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type):
	AAMHoYxRCmt2D6ph89W,items = [],[]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FAJERSHOW-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if type in ['featured_movies','featured_tvshows']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="content"(.*?)id="archive-content"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif type=='all_movies_tvshows':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="archive-content"(.*?)class="pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif type=='top_imdb_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='top_imdb_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("class='top-imdb-list tright(.*?)footer",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='search':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="search-page"(.*?)class="sidebar',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='sider':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="widget(.*?)class="widget',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		hRfSE2oyUgL1XIAws49p8O3aWl = YYqECUofyi7wFrW.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		UTwH7zjZOrmFl,fmACYDaEFetdVr,IGEpKNCaiLMT = zip(*hRfSE2oyUgL1XIAws49p8O3aWl)
		items = zip(fmACYDaEFetdVr,UTwH7zjZOrmFl,IGEpKNCaiLMT)
	elif type=='randoms':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="slider-movies-tvshows"(.*?)<header>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif 'latest' in type:
		rAknWUHpDyi4IuGPfl2QYR = int(type[-1:])
		LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('<header>','<end><start>')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('</div></div></div>','</div></div></div><end>')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<start>(.*?)<end>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[rAknWUHpDyi4IuGPfl2QYR]
		if rAknWUHpDyi4IuGPfl2QYR==6:
			hRfSE2oyUgL1XIAws49p8O3aWl = YYqECUofyi7wFrW.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			fmACYDaEFetdVr,IGEpKNCaiLMT,UTwH7zjZOrmFl = zip(*hRfSE2oyUgL1XIAws49p8O3aWl)
			items = zip(fmACYDaEFetdVr,UTwH7zjZOrmFl,IGEpKNCaiLMT)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="content"(.*?)class="(pagination|sidebar)',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0][0]
			if '/collection/' in url:
				items = YYqECUofyi7wFrW.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			elif '/quality/' in url:
				items = YYqECUofyi7wFrW.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items and AAMHoYxRCmt2D6ph89W:
		items = YYqECUofyi7wFrW.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = YYqECUofyi7wFrW.findall('^(.*?)<.*?serie">(.*?)<',title,YYqECUofyi7wFrW.DOTALL)
			title = title[0][1]
			if title in zIDPZSNn1OuweLHvmMKb6d: continue
			zIDPZSNn1OuweLHvmMKb6d.append(title)
			title = '_MOD_'+title
		PJN58A9SFZTwi6uLMB73m = YYqECUofyi7wFrW.findall('^(.*?)<',title,YYqECUofyi7wFrW.DOTALL)
		if PJN58A9SFZTwi6uLMB73m: title = PJN58A9SFZTwi6uLMB73m[0]
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if '/tvshows/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,393,TTuPH708dUNnjlG3oQpkZsi)
		elif '/episodes/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,393,TTuPH708dUNnjlG3oQpkZsi)
		elif '/seasons/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,393,TTuPH708dUNnjlG3oQpkZsi)
		elif '/collection/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,391,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,392,TTuPH708dUNnjlG3oQpkZsi)
	if type not in ['featured_movies','featured_tvshows']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,391,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,type)
	return
def vl57jIYC4a(url):
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,'url')
	url = url.replace(oikt6P0hOAD5IvnlMpxf1,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FAJERSHOW-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('class="C rated".*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<ul class="episodios">(.*?)</ul></div></div></div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,392,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = MKsaBZtpJ9uR2D(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FAJERSHOW-PLAY-1st')
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('class="C rated".*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	UTwH7zjZOrmFl = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0][0]
		items = YYqECUofyi7wFrW.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for type,bbxoFf2lTX1SYcVELZB8pWIsiCr,Acb6i1Sxm8Z20FfuLeKMpj7Rzvwg,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+bbxoFf2lTX1SYcVELZB8pWIsiCr+'&nume='+Acb6i1Sxm8Z20FfuLeKMpj7Rzvwg+'&type='+type
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA,lzWinvL53T2D0cGawRBPqm9FMAU7kQ in items:
			if '=' in TTuPH708dUNnjlG3oQpkZsi:
				hJwkd3LAI12PUQtin04 = TTuPH708dUNnjlG3oQpkZsi.split('=')[1]
				title = msbTrJW03xuvA(hJwkd3LAI12PUQtin04,'host')
			else: title = NdKhAS6MXVEORLTwob92pxlZ
			title = lzWinvL53T2D0cGawRBPqm9FMAU7kQ+Vwgflszp4WRA93kx6hvdua21HX5cOb+title
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download____'+a0ao2jdlt4r9nhHwpvSgOVGA
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
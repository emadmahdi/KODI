# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ALARAB'
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
LJfTAEQPv9h4BXdwUp = '_KLA_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==10: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==11: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==12: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==13: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==14: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = qahUFzc8EDsd0PfVruTSOMKyCoLl1()
	elif mode==15: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = JLo3ZhfO68()
	elif mode==16: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = WLsp05OGi6tADXoE4R()
	elif mode==19: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,19,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'آخر الإضافات',NdKhAS6MXVEORLTwob92pxlZ,14)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان',NdKhAS6MXVEORLTwob92pxlZ,15)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'ALARAB-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('id="nav-slider"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	SUMFabg7J9f6WGI8m = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',SUMFabg7J9f6WGI8m,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,11)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="navbar"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	zyoNRs5F72Bkr0JYfGh6PULju4bO = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,11)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def JLo3ZhfO68():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'جميع المسلسلات العربية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/view-8/مسلسلات-عربية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات السنة الأخيرة',NdKhAS6MXVEORLTwob92pxlZ,16)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان الأخيرة 1',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/view-8/مسلسلات-رمضان-2022',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان الأخيرة 2',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/view-8/مسلسلات-رمضان-2023',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2023',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2023/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2022',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2022/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2021',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2021/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2020',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2020/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2019',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2019/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2018',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2018/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2017',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2017/مصرية',11)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات رمضان 2016',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ramadan2016/مصرية',11)
	return
def qahUFzc8EDsd0PfVruTSOMKyCoLl1():
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'ALARAB-LATEST-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('heading-top(.*?)div class=',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]+bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	items=YYqECUofyi7wFrW.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
		if 'series' in url: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,11,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,12,TTuPH708dUNnjlG3oQpkZsi)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,True,'ALARAB-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('video-category(.*?)right_content',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	NElpa837fkWBKeqY = False
	items = YYqECUofyi7wFrW.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d,NlnQdZwm4j = [],[]
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if title==NdKhAS6MXVEORLTwob92pxlZ: title = zehVcU893FC6LEd1Aij.split('/')[-1].replace('-',Vwgflszp4WRA93kx6hvdua21HX5cOb)
		oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = YYqECUofyi7wFrW.findall('(\d+)',title,YYqECUofyi7wFrW.DOTALL)
		if oLQuxeSOY6A0fq2kF3TZnbGgw7Dc: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = int(oLQuxeSOY6A0fq2kF3TZnbGgw7Dc[0])
		else: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = 0
		NlnQdZwm4j.append([TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc])
	NlnQdZwm4j = sorted(NlnQdZwm4j, reverse=True, key=lambda key: key[3])
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc in NlnQdZwm4j:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('عالية على العرب',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('مشاهدة مباشرة',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('اون لاين',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('اونلاين',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('بجودة عالية',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('جودة عالية',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('بدون تحميل',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('على العرب',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.replace('مباشرة',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		title = '_MOD_'+title
		PJN58A9SFZTwi6uLMB73m = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
			if N1VjdbtuO3z: PJN58A9SFZTwi6uLMB73m = N1VjdbtuO3z[0]
		if PJN58A9SFZTwi6uLMB73m not in zIDPZSNn1OuweLHvmMKb6d:
			zIDPZSNn1OuweLHvmMKb6d.append(PJN58A9SFZTwi6uLMB73m)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,zehVcU893FC6LEd1Aij,13,TTuPH708dUNnjlG3oQpkZsi)
				NElpa837fkWBKeqY = True
			elif 'series' in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,11,TTuPH708dUNnjlG3oQpkZsi)
				NElpa837fkWBKeqY = True
			else:
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,12,TTuPH708dUNnjlG3oQpkZsi)
				NElpa837fkWBKeqY = True
	if NElpa837fkWBKeqY:
		items = YYqECUofyi7wFrW.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,jNgDBqeKyZ4zSkGv8ROMA70aIYcC in items:
			url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,11)
	return
def vl57jIYC4a(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'ALARAB-EPISODES-1st')
	ggEX5wBNHj4F = YYqECUofyi7wFrW.findall('href="(/series.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+ggEX5wBNHj4F[0]
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl = []
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'ALARAB-PLAY-1st')
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('class="resp-iframe" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi:
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('^(http.*?)(http.*?)$',BfjcMoqOsmdUvZVCHWIyQKi,YYqECUofyi7wFrW.DOTALL)
		if oDhlaxn0EqyYikcHrmZBN8uv:
			D1BVdF2w4cm8fbTIv6AhjtNkPHx = oDhlaxn0EqyYikcHrmZBN8uv[0][0]
			cRr1xpSasHG5FWPIbYy,lqQ4xNyVgF689JOu7dwzItGb = oDhlaxn0EqyYikcHrmZBN8uv[0][1].rsplit('/',1)
			Afey3cL4ojzg = cRr1xpSasHG5FWPIbYy+'?named=__watch'
			UTwH7zjZOrmFl.append(Afey3cL4ojzg)
			pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = D1BVdF2w4cm8fbTIv6AhjtNkPHx+lqQ4xNyVgF689JOu7dwzItGb
		else:
			HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,False,'ALARAB-PLAY-2nd')
			BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('"src": "(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if BfjcMoqOsmdUvZVCHWIyQKi:
				BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]+'?named=__watch__m3u8'
				UTwH7zjZOrmFl.append(BfjcMoqOsmdUvZVCHWIyQKi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('searchBox(.*?)<style>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if BfjcMoqOsmdUvZVCHWIyQKi:
			BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]+'?named=__watch'
			UTwH7zjZOrmFl.append(BfjcMoqOsmdUvZVCHWIyQKi)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def WLsp05OGi6tADXoE4R():
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'ALARAB-RAMADAN-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="content_sec"(.*?)id="left_content"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	ZwVlbGzT3D5RJEBihrX2Np9 = YYqECUofyi7wFrW.findall('/ramadan([0-9]+)/',str(items),YYqECUofyi7wFrW.DOTALL)
	ZwVlbGzT3D5RJEBihrX2Np9 = ZwVlbGzT3D5RJEBihrX2Np9[0]
	for zehVcU893FC6LEd1Aij,title in items:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)+Vwgflszp4WRA93kx6hvdua21HX5cOb+ZwVlbGzT3D5RJEBihrX2Np9
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,11)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + "/q/" + n5pZARB2X0x8abLPeywMuHkqV
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
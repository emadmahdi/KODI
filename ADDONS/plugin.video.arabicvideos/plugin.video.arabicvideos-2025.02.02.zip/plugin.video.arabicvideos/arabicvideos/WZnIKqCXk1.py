# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ALKAWTHAR'
LJfTAEQPv9h4BXdwUp = '_KWT_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
def QGLoruqnmiAel7Op(mode,url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,text):
	if   mode==130: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==131: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==132: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = VebtvXQp8SCg52Jkxmi4OoqK(url)
	elif mode==133: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==134: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==135: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dbe3CzcI4ywG0jDmfY8HSxsqp()
	elif mode==139: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text,url)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,139,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('dropdown-menu(.*?)dropdown-toggle',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	items=YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if '/conductor' in zehVcU893FC6LEd1Aij: continue
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
		if '/category/' in url: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,132)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,131)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المسلسلات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/543',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الأفلام',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/628',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'برامج الصغار والشباب',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/517',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'ابرز البرامج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/1763',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المحاضرات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/943',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'عاشوراء',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/1353',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'البرامج الاجتماعية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/501',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'البرامج الدينية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/509',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'البرامج الوثائقية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/553',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'البرامج السياسية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/545',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'كتب',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/291',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'تعلم الفارسية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/88',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أرشيف البرامج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/1279',132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	aa1js4fDGYm5k2xCQLvnFIABNZ = ['/religious','/social','/political','/films','/series']
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-TITLES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('titlebar(.*?)titlebar',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if any(K6KbZDHncNizQgl1fr59XV0 in url for K6KbZDHncNizQgl1fr59XV0 in aa1js4fDGYm5k2xCQLvnFIABNZ):
		items = YYqECUofyi7wFrW.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,133,TTuPH708dUNnjlG3oQpkZsi,'1')
	elif '/docs' in url:
		items = YYqECUofyi7wFrW.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,title,zehVcU893FC6LEd1Aij in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,133,TTuPH708dUNnjlG3oQpkZsi,'1')
	return
def VebtvXQp8SCg52Jkxmi4OoqK(url):
	II4s1CdgcbN6BSvWPnHtz = url.split('/')[-1]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-CATEGORIES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('parentcat(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		vl57jIYC4a(url,'1')
		return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall("href='(.*?)'.*?>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,132,NdKhAS6MXVEORLTwob92pxlZ,'1')
	return
def vl57jIYC4a(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-EPISODES-1st')
	items = YYqECUofyi7wFrW.findall('totalpagecount=[\'"](.*?)[\'"]',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not items:
		url = YYqECUofyi7wFrW.findall('class="news-detail-body".*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,134)
		else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	OxiPSHG36XWrRwjVzsnTpULIcCJBal = int(items[0])
	name = YYqECUofyi7wFrW.findall('main-title.*?</a> >(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if name: name = name[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	else: name = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		II4s1CdgcbN6BSvWPnHtz = url.split('/')[-1]
		if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/category/' + II4s1CdgcbN6BSvWPnHtz + '/' + jNgDBqeKyZ4zSkGv8ROMA70aIYcC
		HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-EPISODES-2nd')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('currentpagenumber(.*?)pagination',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,type,zehVcU893FC6LEd1Aij,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',NdKhAS6MXVEORLTwob92pxlZ)
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
			if II4s1CdgcbN6BSvWPnHtz=='628': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,133,TTuPH708dUNnjlG3oQpkZsi,'1')
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,134,TTuPH708dUNnjlG3oQpkZsi)
	elif '/episode/' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('playlist(.*?)col-md-12',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,134,TTuPH708dUNnjlG3oQpkZsi)
		elif '/category/628' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
				title = '_MOD_' + 'ملف التشغيل'
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,134)
		else:
			items = YYqECUofyi7wFrW.findall('id="Categories.*?href=\'(.*?)\'',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			II4s1CdgcbN6BSvWPnHtz = items[0].split('/')[-1]
			url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/category/' + II4s1CdgcbN6BSvWPnHtz
			VebtvXQp8SCg52Jkxmi4OoqK(url)
			return
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		N1IHg6C3SQBU = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in N1IHg6C3SQBU:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('&amp;','&')
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,133)
	return
def uuvhoSanB2TWD(url):
	if '/news/' in url or '/episode/' in url:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-PLAY-1st')
		items = YYqECUofyi7wFrW.findall("mobilevideopath.*?value='(.*?)'",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if items: url = items[0]
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(url,yNIDEX5hU4G769,'video')
	return
def dbe3CzcI4ywG0jDmfY8HSxsqp():
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/live'
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-LIVE-1st')
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('live-container.*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
	omrd89nv0PGKFpL3TxfAXt = {'Referer':qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN}
	HYfNLiDK3yRF7 = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,True,'ALKAWTHAR-LIVE-2nd')
	HeFB5x2wED = HYfNLiDK3yRF7.content
	JMox3q27Fi1Rd468Z = YYqECUofyi7wFrW.findall('csrf-token" content="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
	JMox3q27Fi1Rd468Z = JMox3q27Fi1Rd468Z[0]
	dFjp1SrVAb2XtIDaLQBJylsM0 = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,'url')
	Afey3cL4ojzg = YYqECUofyi7wFrW.findall("playUrl = '(.*?)'",HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
	Afey3cL4ojzg = dFjp1SrVAb2XtIDaLQBJylsM0+Afey3cL4ojzg[0]
	UNZ5JYoADPigf8Cn4FbBch = {'X-CSRF-TOKEN':JMox3q27Fi1Rd468Z}
	ROC7WiSmuMYvFayLc5Ed = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'POST',Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,UNZ5JYoADPigf8Cn4FbBch,False,True,'ALKAWTHAR-LIVE-3rd')
	UvnhwJrA4QTXWis95H = ROC7WiSmuMYvFayLc5Ed.content
	pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = YYqECUofyi7wFrW.findall('"(.*?)"',UvnhwJrA4QTXWis95H,YYqECUofyi7wFrW.DOTALL)
	pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = pYGHPzT0Ma7vQBe42SiWOnoEsdJ1[0].replace('\/','/')
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,yNIDEX5hU4G769,'live')
	return
def tTIQWSbOEqHJ4(search,url=NdKhAS6MXVEORLTwob92pxlZ):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if url==NdKhAS6MXVEORLTwob92pxlZ:
		if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
		if search==NdKhAS6MXVEORLTwob92pxlZ: return
		search = YUkzG2ymNSqdon(search)
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search?q='+search
		vl57jIYC4a(url,NdKhAS6MXVEORLTwob92pxlZ)
		return
# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
qaD1Jv7VWbMoI04Bx8UkrC9XQOh = 'EXCLUDES'
def vNhC1pOQjbW0szuk36mrADVe9fi(JHKDFe6Am0ruz8,f21fbCHXEIZ):
	f21fbCHXEIZ = f21fbCHXEIZ.replace(Whef0cxB2iR93SC5IwUtk,NdKhAS6MXVEORLTwob92pxlZ).replace(' '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)[1:]
	OOXoNK2ig0GdRwra4kB15LEy73 = YYqECUofyi7wFrW.findall('[a-zA-Z]',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
	if 'بحث IPTV - ' in JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace('بحث IPTV - ',iy0rIHuvaAgpbjRKnTQcJwLVs+'بحث IPTV - '+iy0rIHuvaAgpbjRKnTQcJwLVs)
	elif ' IPTV' in JHKDFe6Am0ruz8 and f21fbCHXEIZ=='IPT': JHKDFe6Am0ruz8 = iy0rIHuvaAgpbjRKnTQcJwLVs+JHKDFe6Am0ruz8
	elif 'بحث M3U - ' in JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace('بحث M3U - ',iy0rIHuvaAgpbjRKnTQcJwLVs+'بحث M3U - '+iy0rIHuvaAgpbjRKnTQcJwLVs)
	elif ' M3U' in JHKDFe6Am0ruz8 and f21fbCHXEIZ=='M3U': JHKDFe6Am0ruz8 = iy0rIHuvaAgpbjRKnTQcJwLVs+JHKDFe6Am0ruz8
	elif 'بحث ' in JHKDFe6Am0ruz8 and ' - ' in JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = iy0rIHuvaAgpbjRKnTQcJwLVs+JHKDFe6Am0ruz8
	elif not OOXoNK2ig0GdRwra4kB15LEy73:
		gtENxOj0Ie = YYqECUofyi7wFrW.findall('^( *?)(.*?)( *?)$',JHKDFe6Am0ruz8)
		YqIvKoGM20ygV,PiEnldO5NhXcLrfGJ4oDTHeYBR,ciGYgnEj59Q4Mqe0TBz1tDL8Pv = gtENxOj0Ie[0]
		CCmr2zSIdTtHKPy = YYqECUofyi7wFrW.findall('^([!-~])',PiEnldO5NhXcLrfGJ4oDTHeYBR)
		if CCmr2zSIdTtHKPy: JHKDFe6Am0ruz8 = YqIvKoGM20ygV+MgDNZ1f34w+PiEnldO5NhXcLrfGJ4oDTHeYBR+ciGYgnEj59Q4Mqe0TBz1tDL8Pv
		else: JHKDFe6Am0ruz8 = ciGYgnEj59Q4Mqe0TBz1tDL8Pv+iy0rIHuvaAgpbjRKnTQcJwLVs+PiEnldO5NhXcLrfGJ4oDTHeYBR+YqIvKoGM20ygV
	else:
		import bidi.algorithm as q2o5GXsuaJxkjU
		if 1:
			fciuhjTwxy1ClSX = JHKDFe6Am0ruz8
			abI9rZSp24TOXCfBkmy6 = q2o5GXsuaJxkjU.get_display(JHKDFe6Am0ruz8,base_dir='L')
			if QBp28giCnayJzmZH6vYO: fciuhjTwxy1ClSX = fciuhjTwxy1ClSX.decode(YRvPKe2zMTDs8UCkr)
			if QBp28giCnayJzmZH6vYO: abI9rZSp24TOXCfBkmy6 = abI9rZSp24TOXCfBkmy6.decode(YRvPKe2zMTDs8UCkr)
			JjvQ8N7Y06a = fciuhjTwxy1ClSX.split(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			s4AVvL1lDQ3PnYcxdy = abI9rZSp24TOXCfBkmy6.split(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			LCbephKjnHtc2wq,l9vfMLZ7y1m,lX9EaphRKWdNQj3UT5zibMnm,Jma2A8eGLwD3Zkvs0cTHNzBrS = [],[],NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
			zYIrj1DuLsP = zip(JjvQ8N7Y06a,s4AVvL1lDQ3PnYcxdy)
			for veCNHxqLM61WZDn2QkS4poGa3bAX,i04grEzTp321BS in zYIrj1DuLsP:
				if veCNHxqLM61WZDn2QkS4poGa3bAX==i04grEzTp321BS==NdKhAS6MXVEORLTwob92pxlZ and Jma2A8eGLwD3Zkvs0cTHNzBrS:
					lX9EaphRKWdNQj3UT5zibMnm += Vwgflszp4WRA93kx6hvdua21HX5cOb
					continue
				if veCNHxqLM61WZDn2QkS4poGa3bAX==i04grEzTp321BS:
					zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = 'EN'
					if Jma2A8eGLwD3Zkvs0cTHNzBrS==zlEG2fKPoTeaL6hM0CsIyRwQXgVB1: lX9EaphRKWdNQj3UT5zibMnm += Vwgflszp4WRA93kx6hvdua21HX5cOb+veCNHxqLM61WZDn2QkS4poGa3bAX
					elif veCNHxqLM61WZDn2QkS4poGa3bAX:
						if lX9EaphRKWdNQj3UT5zibMnm:
							l9vfMLZ7y1m.append(lX9EaphRKWdNQj3UT5zibMnm)
							LCbephKjnHtc2wq.append(NdKhAS6MXVEORLTwob92pxlZ)
						lX9EaphRKWdNQj3UT5zibMnm = veCNHxqLM61WZDn2QkS4poGa3bAX
				else:
					zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = 'AR'
					if Jma2A8eGLwD3Zkvs0cTHNzBrS==zlEG2fKPoTeaL6hM0CsIyRwQXgVB1: lX9EaphRKWdNQj3UT5zibMnm += Vwgflszp4WRA93kx6hvdua21HX5cOb+veCNHxqLM61WZDn2QkS4poGa3bAX
					elif veCNHxqLM61WZDn2QkS4poGa3bAX:
						if lX9EaphRKWdNQj3UT5zibMnm:
							LCbephKjnHtc2wq.append(lX9EaphRKWdNQj3UT5zibMnm)
							l9vfMLZ7y1m.append(NdKhAS6MXVEORLTwob92pxlZ)
						lX9EaphRKWdNQj3UT5zibMnm = veCNHxqLM61WZDn2QkS4poGa3bAX
				Jma2A8eGLwD3Zkvs0cTHNzBrS = zlEG2fKPoTeaL6hM0CsIyRwQXgVB1
			if zlEG2fKPoTeaL6hM0CsIyRwQXgVB1=='EN':
				LCbephKjnHtc2wq.append(lX9EaphRKWdNQj3UT5zibMnm)
				l9vfMLZ7y1m.append(NdKhAS6MXVEORLTwob92pxlZ)
			else:
				l9vfMLZ7y1m.append(lX9EaphRKWdNQj3UT5zibMnm)
				LCbephKjnHtc2wq.append(NdKhAS6MXVEORLTwob92pxlZ)
			KFeJSXIiRjWs6aBohYlg18pE = NdKhAS6MXVEORLTwob92pxlZ
			zYIrj1DuLsP = zip(LCbephKjnHtc2wq,l9vfMLZ7y1m)
			import bidi.mirror as KftFhXGgUJSuxH35OQcv
			for ibuLUdYZx4rPcSE,ifKOFWQ9I8BHDdxLeZat in zYIrj1DuLsP:
				if ibuLUdYZx4rPcSE: KFeJSXIiRjWs6aBohYlg18pE += Vwgflszp4WRA93kx6hvdua21HX5cOb+ibuLUdYZx4rPcSE
				else:
					CCmr2zSIdTtHKPy = YYqECUofyi7wFrW.findall('([!-~]) *$',ifKOFWQ9I8BHDdxLeZat)
					if CCmr2zSIdTtHKPy:
						CCmr2zSIdTtHKPy = CCmr2zSIdTtHKPy[0]
						try:
							GYjV9I1fTNqWg5pUvKemBtu = KftFhXGgUJSuxH35OQcv.MIRRORED[CCmr2zSIdTtHKPy]
							gtENxOj0Ie = YYqECUofyi7wFrW.findall('^( *?)(.*?)( *?)$',ifKOFWQ9I8BHDdxLeZat)
							if gtENxOj0Ie: YqIvKoGM20ygV,ifKOFWQ9I8BHDdxLeZat,ciGYgnEj59Q4Mqe0TBz1tDL8Pv = gtENxOj0Ie[0]
							ifKOFWQ9I8BHDdxLeZat = YqIvKoGM20ygV+GYjV9I1fTNqWg5pUvKemBtu+ifKOFWQ9I8BHDdxLeZat[:-1]+ciGYgnEj59Q4Mqe0TBz1tDL8Pv
						except: pass
					KFeJSXIiRjWs6aBohYlg18pE += Vwgflszp4WRA93kx6hvdua21HX5cOb+ifKOFWQ9I8BHDdxLeZat
			JHKDFe6Am0ruz8 = KFeJSXIiRjWs6aBohYlg18pE[1:]
			if QBp28giCnayJzmZH6vYO: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.encode(YRvPKe2zMTDs8UCkr)
		else:
			if QBp28giCnayJzmZH6vYO: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.decode(YRvPKe2zMTDs8UCkr)
			JHKDFe6Am0ruz8 = q2o5GXsuaJxkjU.get_display(JHKDFe6Am0ruz8)
			fciuhjTwxy1ClSX,abI9rZSp24TOXCfBkmy6 = JHKDFe6Am0ruz8,JHKDFe6Am0ruz8
			if 1:
				Jma2A8eGLwD3Zkvs0cTHNzBrS,bixS5GNm2IECzYwco49QL1D0ugtZX = NdKhAS6MXVEORLTwob92pxlZ,[]
				RKpesA95iJa0FvBk = JHKDFe6Am0ruz8.split(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				for GGrw1F8KVRfjtDyTEuvaze6P3LU in RKpesA95iJa0FvBk:
					if not GGrw1F8KVRfjtDyTEuvaze6P3LU:
						if bixS5GNm2IECzYwco49QL1D0ugtZX: bixS5GNm2IECzYwco49QL1D0ugtZX[-1] += Vwgflszp4WRA93kx6hvdua21HX5cOb
						else: bixS5GNm2IECzYwco49QL1D0ugtZX.append(NdKhAS6MXVEORLTwob92pxlZ)
						continue
					Jpq6TUVdRFyDAtQIHX = YYqECUofyi7wFrW.findall('[!-~]',GGrw1F8KVRfjtDyTEuvaze6P3LU[0])
					if Jpq6TUVdRFyDAtQIHX==Jma2A8eGLwD3Zkvs0cTHNzBrS and bixS5GNm2IECzYwco49QL1D0ugtZX: bixS5GNm2IECzYwco49QL1D0ugtZX[-1] += Vwgflszp4WRA93kx6hvdua21HX5cOb+GGrw1F8KVRfjtDyTEuvaze6P3LU
					else:
						if bixS5GNm2IECzYwco49QL1D0ugtZX:
							rEpXnv9b2P = YYqECUofyi7wFrW.findall('[^!-~]',bixS5GNm2IECzYwco49QL1D0ugtZX[-1])
							if rEpXnv9b2P:
								bixS5GNm2IECzYwco49QL1D0ugtZX[-1] = q2o5GXsuaJxkjU.get_display(bixS5GNm2IECzYwco49QL1D0ugtZX[-1])
								T3SEzCtVXIgMkqB6sQxfZ9OAimN = YYqECUofyi7wFrW.findall('^ +',bixS5GNm2IECzYwco49QL1D0ugtZX[-1])
								if T3SEzCtVXIgMkqB6sQxfZ9OAimN: bixS5GNm2IECzYwco49QL1D0ugtZX[-1] = bixS5GNm2IECzYwco49QL1D0ugtZX[-1].lstrip(Vwgflszp4WRA93kx6hvdua21HX5cOb)+T3SEzCtVXIgMkqB6sQxfZ9OAimN[0]
						bixS5GNm2IECzYwco49QL1D0ugtZX.append(GGrw1F8KVRfjtDyTEuvaze6P3LU)
					Jma2A8eGLwD3Zkvs0cTHNzBrS = Jpq6TUVdRFyDAtQIHX
				if bixS5GNm2IECzYwco49QL1D0ugtZX: bixS5GNm2IECzYwco49QL1D0ugtZX[-1] = q2o5GXsuaJxkjU.get_display(bixS5GNm2IECzYwco49QL1D0ugtZX[-1])
				JHKDFe6Am0ruz8 = Vwgflszp4WRA93kx6hvdua21HX5cOb.join(bixS5GNm2IECzYwco49QL1D0ugtZX)
			if QBp28giCnayJzmZH6vYO: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.encode(YRvPKe2zMTDs8UCkr)
	return JHKDFe6Am0ruz8
def dsb4pfE08WoitQA1B5eZcrUlP7(X32lUyoDBqp14T,PjiYxNdelO5fv8Sc,HbjiUGkBeSFL70vpM6YQwd):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,qtWlS6fnLH0I,IP3MShzbfpDUCuBjmn81tlJi,ueFHThK2pDYc,ww1lsWcSe2Cd = X32lUyoDBqp14T
	pPrvqm3tjuXLTgw1 = int(pPrvqm3tjuXLTgw1)
	wUqlzC43fuXNOtpYaFTxd = YYqECUofyi7wFrW.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
	if wUqlzC43fuXNOtpYaFTxd:
		wUqlzC43fuXNOtpYaFTxd,jHhn7qeMDPCAd9Eo5UBr8s,TTNOYS6I0AnsRX7QHGa = wUqlzC43fuXNOtpYaFTxd[0]
		JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(wUqlzC43fuXNOtpYaFTxd,NdKhAS6MXVEORLTwob92pxlZ)
	EhqWeunzUP = JHKDFe6Am0ruz8
	f21fbCHXEIZ = YYqECUofyi7wFrW.findall('^_(\w\w\w)_(.*?)$',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
	if f21fbCHXEIZ:
		f21fbCHXEIZ,JHKDFe6Am0ruz8 = f21fbCHXEIZ[0]
		LKlGycqDVRktdpUPBa6j = '_MOD_' in JHKDFe6Am0ruz8
		n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 = oJeO8LqTXi7W=='folder'
		if LKlGycqDVRktdpUPBa6j and n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: wajml8bIqCJShpkB6uiWM4tdE2D53Z = ';'
		elif LKlGycqDVRktdpUPBa6j and not n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: wajml8bIqCJShpkB6uiWM4tdE2D53Z = xDC7Nk52nKePfXhVRr
		elif not LKlGycqDVRktdpUPBa6j and n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: wajml8bIqCJShpkB6uiWM4tdE2D53Z = ','
		elif not LKlGycqDVRktdpUPBa6j and not n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: wajml8bIqCJShpkB6uiWM4tdE2D53Z = Vwgflszp4WRA93kx6hvdua21HX5cOb
		JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace('_MOD_',NdKhAS6MXVEORLTwob92pxlZ)
		f21fbCHXEIZ = wajml8bIqCJShpkB6uiWM4tdE2D53Z+Whef0cxB2iR93SC5IwUtk+f21fbCHXEIZ+' '+kjd9LyNqQHMUevZiRI7OlBGF1h
	else: f21fbCHXEIZ = NdKhAS6MXVEORLTwob92pxlZ
	if wUqlzC43fuXNOtpYaFTxd:
		if QBp28giCnayJzmZH6vYO:
			wUqlzC43fuXNOtpYaFTxd = D7INg5kyRjwf4ZtoePVUrb1h2SJ+jHhn7qeMDPCAd9Eo5UBr8s+Vwgflszp4WRA93kx6hvdua21HX5cOb+TTNOYS6I0AnsRX7QHGa+kjd9LyNqQHMUevZiRI7OlBGF1h
			if f21fbCHXEIZ: JHKDFe6Am0ruz8 = wUqlzC43fuXNOtpYaFTxd+Vwgflszp4WRA93kx6hvdua21HX5cOb+iy0rIHuvaAgpbjRKnTQcJwLVs+f21fbCHXEIZ+JHKDFe6Am0ruz8
			else: JHKDFe6Am0ruz8 = wUqlzC43fuXNOtpYaFTxd+iy0rIHuvaAgpbjRKnTQcJwLVs+JHKDFe6Am0ruz8+Vwgflszp4WRA93kx6hvdua21HX5cOb
		elif J92gCnbGWidQV70lBteTwU6D8uyzL:
			if f21fbCHXEIZ:
				wUqlzC43fuXNOtpYaFTxd = D7INg5kyRjwf4ZtoePVUrb1h2SJ+jHhn7qeMDPCAd9Eo5UBr8s+Vwgflszp4WRA93kx6hvdua21HX5cOb+TTNOYS6I0AnsRX7QHGa+kjd9LyNqQHMUevZiRI7OlBGF1h
				JHKDFe6Am0ruz8 = wUqlzC43fuXNOtpYaFTxd+Vwgflszp4WRA93kx6hvdua21HX5cOb+f21fbCHXEIZ+JHKDFe6Am0ruz8
			else:
				wUqlzC43fuXNOtpYaFTxd = D7INg5kyRjwf4ZtoePVUrb1h2SJ+TTNOYS6I0AnsRX7QHGa+Vwgflszp4WRA93kx6hvdua21HX5cOb+jHhn7qeMDPCAd9Eo5UBr8s+kjd9LyNqQHMUevZiRI7OlBGF1h
				JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8+Vwgflszp4WRA93kx6hvdua21HX5cOb+iy0rIHuvaAgpbjRKnTQcJwLVs+wUqlzC43fuXNOtpYaFTxd
	elif f21fbCHXEIZ:
		JHKDFe6Am0ruz8 = vNhC1pOQjbW0szuk36mrADVe9fi(JHKDFe6Am0ruz8,f21fbCHXEIZ)
		JHKDFe6Am0ruz8 = f21fbCHXEIZ+JHKDFe6Am0ruz8
	X32lUyoDBqp14T = oJeO8LqTXi7W,EhqWeunzUP,TixSXhpW69Uba4f1NPqzYE7JcZ,str(pPrvqm3tjuXLTgw1),nnQPgrIaSEN09T5hf4sx,qtWlS6fnLH0I,IP3MShzbfpDUCuBjmn81tlJi,ueFHThK2pDYc,ww1lsWcSe2Cd
	NNWtZEeDKiXTywsh2g8qSkHQLnv = {'type':NdKhAS6MXVEORLTwob92pxlZ,'mode':NdKhAS6MXVEORLTwob92pxlZ,'url':NdKhAS6MXVEORLTwob92pxlZ,'text':NdKhAS6MXVEORLTwob92pxlZ,'page':NdKhAS6MXVEORLTwob92pxlZ,'name':NdKhAS6MXVEORLTwob92pxlZ,'image':NdKhAS6MXVEORLTwob92pxlZ,'context':NdKhAS6MXVEORLTwob92pxlZ,'infodict':NdKhAS6MXVEORLTwob92pxlZ}
	if J92gCnbGWidQV70lBteTwU6D8uyzL: EhqWeunzUP = EhqWeunzUP.encode(YRvPKe2zMTDs8UCkr,'ignore').decode(YRvPKe2zMTDs8UCkr)
	NNWtZEeDKiXTywsh2g8qSkHQLnv['name'] = YUkzG2ymNSqdon(EhqWeunzUP)
	NNWtZEeDKiXTywsh2g8qSkHQLnv['type'] = oJeO8LqTXi7W.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	NNWtZEeDKiXTywsh2g8qSkHQLnv['mode'] = str(pPrvqm3tjuXLTgw1).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if oJeO8LqTXi7W=='folder' and qtWlS6fnLH0I: NNWtZEeDKiXTywsh2g8qSkHQLnv['page'] = YUkzG2ymNSqdon(qtWlS6fnLH0I.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb))
	if ueFHThK2pDYc: NNWtZEeDKiXTywsh2g8qSkHQLnv['context'] = ueFHThK2pDYc.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if IP3MShzbfpDUCuBjmn81tlJi: NNWtZEeDKiXTywsh2g8qSkHQLnv['text'] = YUkzG2ymNSqdon(IP3MShzbfpDUCuBjmn81tlJi.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb))
	if nnQPgrIaSEN09T5hf4sx: NNWtZEeDKiXTywsh2g8qSkHQLnv['image'] = YUkzG2ymNSqdon(nnQPgrIaSEN09T5hf4sx.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb))
	if ww1lsWcSe2Cd:
		ww1lsWcSe2Cd = str(ww1lsWcSe2Cd)
		NNWtZEeDKiXTywsh2g8qSkHQLnv['infodict'] = YUkzG2ymNSqdon(ww1lsWcSe2Cd.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb))
		ww1lsWcSe2Cd = eval(ww1lsWcSe2Cd)
	else: ww1lsWcSe2Cd = {}
	if TixSXhpW69Uba4f1NPqzYE7JcZ: NNWtZEeDKiXTywsh2g8qSkHQLnv['url'] = YUkzG2ymNSqdon(TixSXhpW69Uba4f1NPqzYE7JcZ.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb))
	NKxnhpYvgf = {'name':NdKhAS6MXVEORLTwob92pxlZ,'context_menu':NdKhAS6MXVEORLTwob92pxlZ,'plot':NdKhAS6MXVEORLTwob92pxlZ,'stars':NdKhAS6MXVEORLTwob92pxlZ,'image':NdKhAS6MXVEORLTwob92pxlZ,'type':NdKhAS6MXVEORLTwob92pxlZ,'isFolder':NdKhAS6MXVEORLTwob92pxlZ,'newpath':NdKhAS6MXVEORLTwob92pxlZ,'duration':NdKhAS6MXVEORLTwob92pxlZ}
	j8Zrmbxpe12oHMQugPNFBlkRLS = []
	lXfUH38a5OkeZWQPxnDTsyBqSG0 = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'/?type='+NNWtZEeDKiXTywsh2g8qSkHQLnv['type']+'&mode='+NNWtZEeDKiXTywsh2g8qSkHQLnv['mode']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['page']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&page='+NNWtZEeDKiXTywsh2g8qSkHQLnv['page']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['name']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&name='+NNWtZEeDKiXTywsh2g8qSkHQLnv['name']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['text']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&text='+NNWtZEeDKiXTywsh2g8qSkHQLnv['text']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['infodict']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&infodict='+NNWtZEeDKiXTywsh2g8qSkHQLnv['infodict']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['image']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&image='+NNWtZEeDKiXTywsh2g8qSkHQLnv['image']
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['url']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&url='+NNWtZEeDKiXTywsh2g8qSkHQLnv['url']
	if pPrvqm3tjuXLTgw1!=265: NKxnhpYvgf['favorites'] = True
	else: NKxnhpYvgf['favorites'] = False
	if NNWtZEeDKiXTywsh2g8qSkHQLnv['context']: lXfUH38a5OkeZWQPxnDTsyBqSG0 += '&context='+NNWtZEeDKiXTywsh2g8qSkHQLnv['context']
	if pPrvqm3tjuXLTgw1 in [235,238] and oJeO8LqTXi7W=='live' and 'EPG' in ueFHThK2pDYc:
		xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?mode=238&text=SHORT_EPG&url='+TixSXhpW69Uba4f1NPqzYE7JcZ
		Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'البرامج القادمة'+kjd9LyNqQHMUevZiRI7OlBGF1h
		NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
		j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if pPrvqm3tjuXLTgw1==265:
		jpGSFfu5zemrJv3xWTE = PjiYxNdelO5fv8Sc(IP3MShzbfpDUCuBjmn81tlJi,True)
		if jpGSFfu5zemrJv3xWTE>0:
			xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?mode=266&text='+IP3MShzbfpDUCuBjmn81tlJi
			Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'مسح قائمة آخر 50 '+P02oGj7X8m5uMz6VUCScZbDnLp4fR(IP3MShzbfpDUCuBjmn81tlJi)+kjd9LyNqQHMUevZiRI7OlBGF1h
			NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
			j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if oJeO8LqTXi7W=='video' and pPrvqm3tjuXLTgw1!=331:
		xD592hJSBTWbk84Qf6mOn = lXfUH38a5OkeZWQPxnDTsyBqSG0+'&context=6_DOWNLOAD'
		Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'تحميل ملف الفيديو'+kjd9LyNqQHMUevZiRI7OlBGF1h
		NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
		j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if pPrvqm3tjuXLTgw1==331:
		xD592hJSBTWbk84Qf6mOn = lXfUH38a5OkeZWQPxnDTsyBqSG0+'&context=6_DELETE'
		Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'حذف ملف الفيديو'+kjd9LyNqQHMUevZiRI7OlBGF1h
		NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
		j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if oJeO8LqTXi7W=='folder' and pPrvqm3tjuXLTgw1==540:
		LSaF2orDfBT85nj3Xsqtbi = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_SPLITTED_ALL')
		if LSaF2orDfBT85nj3Xsqtbi:
			xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?context=7'
			Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'مسح كلمات بحث المواقع'+kjd9LyNqQHMUevZiRI7OlBGF1h
			NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
			j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if oJeO8LqTXi7W=='folder' and pPrvqm3tjuXLTgw1==1010:
		LSaF2orDfBT85nj3Xsqtbi = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if LSaF2orDfBT85nj3Xsqtbi:
			xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?context=10'
			Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'مسح كلمات بحث جوجل'+kjd9LyNqQHMUevZiRI7OlBGF1h
			NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
			j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	hdc9XZTObsIojLHxB = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if pPrvqm3tjuXLTgw1 not in hdc9XZTObsIojLHxB:
		xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?context=8&mode=260'
		Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'القائمة الرئيسية'+kjd9LyNqQHMUevZiRI7OlBGF1h
		NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
		j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	EV5wX9dbJQWqGD4Nci8stfxR7onA01 = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	mmYWKbBvGfsQTSC5Pz = pPrvqm3tjuXLTgw1-pPrvqm3tjuXLTgw1%10
	if pPrvqm3tjuXLTgw1%10:
		if mmYWKbBvGfsQTSC5Pz==280: mmYWKbBvGfsQTSC5Pz = 230
		if mmYWKbBvGfsQTSC5Pz==410: mmYWKbBvGfsQTSC5Pz = 400
		if mmYWKbBvGfsQTSC5Pz==520: mmYWKbBvGfsQTSC5Pz = 510
		if mmYWKbBvGfsQTSC5Pz not in EV5wX9dbJQWqGD4Nci8stfxR7onA01:
			xD592hJSBTWbk84Qf6mOn = 'plugin://'+b0VaRYkgC4iOvHpmdeyzcQISJEsx+'?context=8&mode='+str(mmYWKbBvGfsQTSC5Pz)
			Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'قائمة الموقع'+kjd9LyNqQHMUevZiRI7OlBGF1h
			NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
			j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	xD592hJSBTWbk84Qf6mOn = lXfUH38a5OkeZWQPxnDTsyBqSG0+'&context=9'
	Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'تحديث القائمة'+kjd9LyNqQHMUevZiRI7OlBGF1h
	NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
	j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if oJeO8LqTXi7W in ['video','live']:
		xD592hJSBTWbk84Qf6mOn = lXfUH38a5OkeZWQPxnDTsyBqSG0+'&context=18'
		Z8YzVylde5Q = D7INg5kyRjwf4ZtoePVUrb1h2SJ+'إظهار قوائم الجودة'+kjd9LyNqQHMUevZiRI7OlBGF1h
		NODazr7thvEl = (Z8YzVylde5Q,'RunPlugin('+xD592hJSBTWbk84Qf6mOn+')')
		j8Zrmbxpe12oHMQugPNFBlkRLS.append(NODazr7thvEl)
	if oJeO8LqTXi7W in ['link','video','live']: qUzRHrWJtZe = False
	elif oJeO8LqTXi7W=='folder': qUzRHrWJtZe = True
	NKxnhpYvgf['name'] = JHKDFe6Am0ruz8
	NKxnhpYvgf['context_menu'] = j8Zrmbxpe12oHMQugPNFBlkRLS
	if 'plot' in list(ww1lsWcSe2Cd.keys()): NKxnhpYvgf['plot'] = ww1lsWcSe2Cd['plot']
	if 'stars' in list(ww1lsWcSe2Cd.keys()): NKxnhpYvgf['stars'] = ww1lsWcSe2Cd['stars']
	if nnQPgrIaSEN09T5hf4sx: NKxnhpYvgf['image'] = nnQPgrIaSEN09T5hf4sx
	if oJeO8LqTXi7W=='video' and qtWlS6fnLH0I:
		OJGK8zCMqWQ = YYqECUofyi7wFrW.findall('[\d:]+',qtWlS6fnLH0I,YYqECUofyi7wFrW.DOTALL)
		if OJGK8zCMqWQ:
			OJGK8zCMqWQ = '0:0:0:0:0:'+OJGK8zCMqWQ[0]
			iCmkXMpWGzVKxSTU0L8NE,RjxrYkMZ64pXQSVJINTtbwC2P7u1,BxlcNyQeUCoq,L5Mt3QyXaYP8k,cLJiuYgProQM8nKO2CNx7 = OJGK8zCMqWQ.rsplit(':',4)
			orpNfWksTvDbyU9HQ1weFS3BEh = int(RjxrYkMZ64pXQSVJINTtbwC2P7u1)*24*lvmy4BZ6Reqb+int(BxlcNyQeUCoq)*lvmy4BZ6Reqb+int(L5Mt3QyXaYP8k)*60+int(cLJiuYgProQM8nKO2CNx7)
			NKxnhpYvgf['duration'] = orpNfWksTvDbyU9HQ1weFS3BEh
	NKxnhpYvgf['type'] = oJeO8LqTXi7W
	NKxnhpYvgf['isFolder'] = qUzRHrWJtZe
	NKxnhpYvgf['newpath'] = lXfUH38a5OkeZWQPxnDTsyBqSG0
	NKxnhpYvgf['menuItem'] = X32lUyoDBqp14T
	NKxnhpYvgf['mode'] = pPrvqm3tjuXLTgw1
	return NKxnhpYvgf
def tH7NMszRwQD0ICL6A1B(PjiYxNdelO5fv8Sc):
	da5vH2OR1SEiVPwebLrCDj3cu,kLsEevcNpM2dy9mVFljGW = [],NdKhAS6MXVEORLTwob92pxlZ
	from LSQvu5zPa6 import yWbk3mQft0RzghLlCHBudcsYGr,DO4B07vQ5KhVk6Jns1fmIzre
	HbjiUGkBeSFL70vpM6YQwd = yWbk3mQft0RzghLlCHBudcsYGr()
	xmYofc7HByzQqEh81L2b6V = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.refresh')
	if RAHOMksyDUV3w7T1QjqKNX and (not xmYofc7HByzQqEh81L2b6V or xmYofc7HByzQqEh81L2b6V=='REFRESH_CACHE'): xmYofc7HByzQqEh81L2b6V = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'str','FOLDERS_SORT',RAHOMksyDUV3w7T1QjqKNX)
	if xmYofc7HByzQqEh81L2b6V:
		if   '_PERM' in xmYofc7HByzQqEh81L2b6V: kLsEevcNpM2dy9mVFljGW = 'دائمي'
		elif '_TEMP' in xmYofc7HByzQqEh81L2b6V: kLsEevcNpM2dy9mVFljGW = 'مؤقت'
		if   '_REVERSED_' in xmYofc7HByzQqEh81L2b6V: RoDOya8x9mcMLZduGkX7YJUQTqI = 'عكسي' ; emiIH49XT6jzOQrw[:] = reversed(emiIH49XT6jzOQrw)
		elif '_ASCENDED_' in xmYofc7HByzQqEh81L2b6V: RoDOya8x9mcMLZduGkX7YJUQTqI = 'تصاعدي' ; emiIH49XT6jzOQrw[:] = sorted(emiIH49XT6jzOQrw,reverse=f4vncKMRlXG9s,key=lambda key:key[llxMLe4gobHhsj1WGvd7qmIU])
		elif '_DESCENDED_' in xmYofc7HByzQqEh81L2b6V: RoDOya8x9mcMLZduGkX7YJUQTqI = 'تنازلي' ; emiIH49XT6jzOQrw[:] = sorted(emiIH49XT6jzOQrw,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key:key[llxMLe4gobHhsj1WGvd7qmIU])
		elif '_RANDOMIZED_' in xmYofc7HByzQqEh81L2b6V: RoDOya8x9mcMLZduGkX7YJUQTqI = 'عشوائي' ; Ijo3hy7zQO5x8aU9vAZDMV.shuffle(emiIH49XT6jzOQrw)
	name = 'ترتيب '+RoDOya8x9mcMLZduGkX7YJUQTqI+Vwgflszp4WRA93kx6hvdua21HX5cOb+kLsEevcNpM2dy9mVFljGW if kLsEevcNpM2dy9mVFljGW else 'بدون ترتيب (أصلي)'
	name = D7INg5kyRjwf4ZtoePVUrb1h2SJ+name+kjd9LyNqQHMUevZiRI7OlBGF1h
	if xmYofc7HByzQqEh81L2b6V in B0vJILKy1FphGiXmwonQ: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.refresh',NdKhAS6MXVEORLTwob92pxlZ)
	GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	EV5wX9dbJQWqGD4Nci8stfxR7onA01 = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	pPrvqm3tjuXLTgw1 = int(DDq6xNzlMYK)
	mmYWKbBvGfsQTSC5Pz = pPrvqm3tjuXLTgw1-pPrvqm3tjuXLTgw1%10
	if pPrvqm3tjuXLTgw1%10 and mmYWKbBvGfsQTSC5Pz not in EV5wX9dbJQWqGD4Nci8stfxR7onA01 and len(emiIH49XT6jzOQrw)>1:
		emiIH49XT6jzOQrw[:] = [('link',name,'',533,'','',RAHOMksyDUV3w7T1QjqKNX,'','')]+emiIH49XT6jzOQrw
	for X32lUyoDBqp14T in emiIH49XT6jzOQrw:
		NKxnhpYvgf = dsb4pfE08WoitQA1B5eZcrUlP7(X32lUyoDBqp14T,PjiYxNdelO5fv8Sc,HbjiUGkBeSFL70vpM6YQwd)
		if NKxnhpYvgf['favorites']:
			K8KGbNLrYJZSqclvs7uXx9QzR2 = DO4B07vQ5KhVk6Jns1fmIzre(HbjiUGkBeSFL70vpM6YQwd,NKxnhpYvgf['menuItem'],NKxnhpYvgf['newpath'])
			NKxnhpYvgf['context_menu'] = K8KGbNLrYJZSqclvs7uXx9QzR2+NKxnhpYvgf['context_menu']
		da5vH2OR1SEiVPwebLrCDj3cu.append(NKxnhpYvgf)
	return da5vH2OR1SEiVPwebLrCDj3cu
def ViwhjZQkqICsOd(hyRfxjI9ruDPkHwcA5vbg):
	wajml8bIqCJShpkB6uiWM4tdE2D53Z,usytqWehEnV4Cl0mBoRfFQ67MTxGa, = [],NdKhAS6MXVEORLTwob92pxlZ
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		if not WEPkgTHGs46itVBLn5fZb21QSIvC: wajml8bIqCJShpkB6uiWM4tdE2D53Z.append(NdKhAS6MXVEORLTwob92pxlZ)
		else: break
	hyRfxjI9ruDPkHwcA5vbg = hyRfxjI9ruDPkHwcA5vbg[len(wajml8bIqCJShpkB6uiWM4tdE2D53Z):]
	ui7N5YGR9KdslpEbQkVTwFqDgI = '\n\n\n\n'.join(hyRfxjI9ruDPkHwcA5vbg)
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('===== ===== =====','000001')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(Whef0cxB2iR93SC5IwUtk,'000002')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,'000003')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(kjd9LyNqQHMUevZiRI7OlBGF1h,'000004')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RIGHT]','000005')
	UfsQbH5JM7vg32G1lX8EN = 100000
	LNhVZpyu1RQYwTrSl = {}
	KLJyEORwCf8WBFeMzvShUH1s = YYqECUofyi7wFrW.findall('http.*?[\r\n ]',ui7N5YGR9KdslpEbQkVTwFqDgI,YYqECUofyi7wFrW.DOTALL)
	for ppAzqnLefgwRxVlSHPBJ in KLJyEORwCf8WBFeMzvShUH1s:
		UfsQbH5JM7vg32G1lX8EN += 1
		ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(ppAzqnLefgwRxVlSHPBJ,str(UfsQbH5JM7vg32G1lX8EN))
		LNhVZpyu1RQYwTrSl[str(UfsQbH5JM7vg32G1lX8EN)] = ppAzqnLefgwRxVlSHPBJ
	for zG37PsWCeVZ4aYtmkE2DTowqBF in range(0,len(ui7N5YGR9KdslpEbQkVTwFqDgI),4800):
		ZVps6TlH2NEYACJRvxjDuP5K = ui7N5YGR9KdslpEbQkVTwFqDgI[zG37PsWCeVZ4aYtmkE2DTowqBF:zG37PsWCeVZ4aYtmkE2DTowqBF+4800]
		kDQWK1Rs84qiHO9fFmVGJILNpb = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
		TixSXhpW69Uba4f1NPqzYE7JcZ = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+kDQWK1Rs84qiHO9fFmVGJILNpb
		RpYN2DWoKIbUHuL = {'Content-Type':'text/plain'}
		eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = ZVps6TlH2NEYACJRvxjDuP5K.encode(YRvPKe2zMTDs8UCkr)
		KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'POST',TixSXhpW69Uba4f1NPqzYE7JcZ,eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if KgjQPrdmkW0pZfiwx9e6qL.succeeded:
			JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
			WWtorp2GavhxwfdH6s1V9lR3ASyYe = BdnA8WwtJeKUVvE('str',JIVXou7hYWQ6CKDsPOUytnml3e9)
			if WWtorp2GavhxwfdH6s1V9lR3ASyYe:
				WWtorp2GavhxwfdH6s1V9lR3ASyYe = WWtorp2GavhxwfdH6s1V9lR3ASyYe['translation']
				WWtorp2GavhxwfdH6s1V9lR3ASyYe = L5xKSr96JmaX7N(WWtorp2GavhxwfdH6s1V9lR3ASyYe)
				for lH2Tk5x7UqJ6W in range(len(WWtorp2GavhxwfdH6s1V9lR3ASyYe)):
					usytqWehEnV4Cl0mBoRfFQ67MTxGa += WWtorp2GavhxwfdH6s1V9lR3ASyYe[lH2Tk5x7UqJ6W][0]
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000001','===== ===== =====')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000002',Whef0cxB2iR93SC5IwUtk)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000003',D7INg5kyRjwf4ZtoePVUrb1h2SJ)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000004',kjd9LyNqQHMUevZiRI7OlBGF1h)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000005','[RIGHT]')
	for UfsQbH5JM7vg32G1lX8EN in list(LNhVZpyu1RQYwTrSl.keys()):
		ppAzqnLefgwRxVlSHPBJ = LNhVZpyu1RQYwTrSl[UfsQbH5JM7vg32G1lX8EN]
		usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace(UfsQbH5JM7vg32G1lX8EN,ppAzqnLefgwRxVlSHPBJ)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.split('\n\n\n\n')
	return wajml8bIqCJShpkB6uiWM4tdE2D53Z+usytqWehEnV4Cl0mBoRfFQ67MTxGa
def iI1V05hRQEX7N(hyRfxjI9ruDPkHwcA5vbg):
	wajml8bIqCJShpkB6uiWM4tdE2D53Z,usytqWehEnV4Cl0mBoRfFQ67MTxGa, = [],NdKhAS6MXVEORLTwob92pxlZ
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		if not WEPkgTHGs46itVBLn5fZb21QSIvC: wajml8bIqCJShpkB6uiWM4tdE2D53Z.append(NdKhAS6MXVEORLTwob92pxlZ)
		else: break
	hyRfxjI9ruDPkHwcA5vbg = hyRfxjI9ruDPkHwcA5vbg[len(wajml8bIqCJShpkB6uiWM4tdE2D53Z):]
	ui7N5YGR9KdslpEbQkVTwFqDgI = '\\n\\n\\n\\n'.join(hyRfxjI9ruDPkHwcA5vbg)
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('كلا','no')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('استمرار','continue')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('===== ===== =====','000001')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(Whef0cxB2iR93SC5IwUtk,'000002')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,'000003')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(kjd9LyNqQHMUevZiRI7OlBGF1h,'000004')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RIGHT]','000005')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[CENTER]','000006')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RTL]','000007')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace("'","\\\\\\'")
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('"','\\\\\\"')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(B6IrC7zEHlw1oaeWf,'\\n')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,'\\\\r')
	for zG37PsWCeVZ4aYtmkE2DTowqBF in range(0,len(ui7N5YGR9KdslpEbQkVTwFqDgI),4800):
		ZVps6TlH2NEYACJRvxjDuP5K = ui7N5YGR9KdslpEbQkVTwFqDgI[zG37PsWCeVZ4aYtmkE2DTowqBF:zG37PsWCeVZ4aYtmkE2DTowqBF+4800]
		TixSXhpW69Uba4f1NPqzYE7JcZ = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		RpYN2DWoKIbUHuL = {'Content-Type':'application/x-www-form-urlencoded'}
		kDQWK1Rs84qiHO9fFmVGJILNpb = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
		eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = 'f.req='+YUkzG2ymNSqdon('[[["MkEWBc","[[\\"'+ZVps6TlH2NEYACJRvxjDuP5K+'\\",\\"ar\\",\\"'+kDQWK1Rs84qiHO9fFmVGJILNpb+'\\",1],[]]",null,"generic"]]]',NdKhAS6MXVEORLTwob92pxlZ)
		eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ.replace('%5Cn','%5C%5Cn')
		KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'POST',TixSXhpW69Uba4f1NPqzYE7JcZ,eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if KgjQPrdmkW0pZfiwx9e6qL.succeeded:
			JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
			JIVXou7hYWQ6CKDsPOUytnml3e9 = JIVXou7hYWQ6CKDsPOUytnml3e9.split(B6IrC7zEHlw1oaeWf)[-1]
			WWtorp2GavhxwfdH6s1V9lR3ASyYe = BdnA8WwtJeKUVvE('str',JIVXou7hYWQ6CKDsPOUytnml3e9)[0][2]
			if WWtorp2GavhxwfdH6s1V9lR3ASyYe:
				WWtorp2GavhxwfdH6s1V9lR3ASyYe = BdnA8WwtJeKUVvE('str',WWtorp2GavhxwfdH6s1V9lR3ASyYe)[1][0][0][5]
				WWtorp2GavhxwfdH6s1V9lR3ASyYe = L5xKSr96JmaX7N(WWtorp2GavhxwfdH6s1V9lR3ASyYe)
				for lH2Tk5x7UqJ6W in range(len(WWtorp2GavhxwfdH6s1V9lR3ASyYe)):
					usytqWehEnV4Cl0mBoRfFQ67MTxGa += WWtorp2GavhxwfdH6s1V9lR3ASyYe[lH2Tk5x7UqJ6W][0]
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('00000','0000').replace('0000','000')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0001','===== ===== =====')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0002',Whef0cxB2iR93SC5IwUtk)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0003',D7INg5kyRjwf4ZtoePVUrb1h2SJ)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0004',kjd9LyNqQHMUevZiRI7OlBGF1h)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0005','[RIGHT]')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0006','[CENTER]')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0007','[RTL]')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.split('\n\n\n\n')
	return wajml8bIqCJShpkB6uiWM4tdE2D53Z+usytqWehEnV4Cl0mBoRfFQ67MTxGa
def kqdOmuQ8AeRJxH2ahF4B5ptNP(hyRfxjI9ruDPkHwcA5vbg):
	wajml8bIqCJShpkB6uiWM4tdE2D53Z,OEFg9SwDzBvH3d5fU8lGrPeC7TLxXh = [],[]
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		if not WEPkgTHGs46itVBLn5fZb21QSIvC: wajml8bIqCJShpkB6uiWM4tdE2D53Z.append(NdKhAS6MXVEORLTwob92pxlZ)
		else: break
	hyRfxjI9ruDPkHwcA5vbg = hyRfxjI9ruDPkHwcA5vbg[len(wajml8bIqCJShpkB6uiWM4tdE2D53Z):]
	ui7N5YGR9KdslpEbQkVTwFqDgI = '\n\n\n\n'.join(hyRfxjI9ruDPkHwcA5vbg)
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('كلا','no')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('استمرار','continue')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('أدناه','below')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(Whef0cxB2iR93SC5IwUtk,'00001')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,'00002')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(kjd9LyNqQHMUevZiRI7OlBGF1h,'00003')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('=====','00004')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(',','00005')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RTL]','00009')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[CENTER]','0000A')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,'0000B')
	hyRfxjI9ruDPkHwcA5vbg = ui7N5YGR9KdslpEbQkVTwFqDgI.split(B6IrC7zEHlw1oaeWf)
	ui7N5YGR9KdslpEbQkVTwFqDgI,usytqWehEnV4Cl0mBoRfFQ67MTxGa = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		if len(ui7N5YGR9KdslpEbQkVTwFqDgI+WEPkgTHGs46itVBLn5fZb21QSIvC)<1800: ui7N5YGR9KdslpEbQkVTwFqDgI += B6IrC7zEHlw1oaeWf+WEPkgTHGs46itVBLn5fZb21QSIvC
		else:
			OEFg9SwDzBvH3d5fU8lGrPeC7TLxXh.append(ui7N5YGR9KdslpEbQkVTwFqDgI)
			ui7N5YGR9KdslpEbQkVTwFqDgI = WEPkgTHGs46itVBLn5fZb21QSIvC
	OEFg9SwDzBvH3d5fU8lGrPeC7TLxXh.append(ui7N5YGR9KdslpEbQkVTwFqDgI)
	for WEPkgTHGs46itVBLn5fZb21QSIvC in OEFg9SwDzBvH3d5fU8lGrPeC7TLxXh:
		RpYN2DWoKIbUHuL = {'Content-Type':'application/json','User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
		TixSXhpW69Uba4f1NPqzYE7JcZ = 'https://api.reverso.net/translate/v1/translation'
		kDQWK1Rs84qiHO9fFmVGJILNpb = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
		eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = {"format":"text","from":"ara","to":kDQWK1Rs84qiHO9fFmVGJILNpb,"input":WEPkgTHGs46itVBLn5fZb21QSIvC,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = O3OogF1l5reuQ.dumps(eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ)
		KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'POST',TixSXhpW69Uba4f1NPqzYE7JcZ,eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIBRARY-REVERSO_TRANSLATE-1st')
		if KgjQPrdmkW0pZfiwx9e6qL.succeeded:
			JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
			JIVXou7hYWQ6CKDsPOUytnml3e9 = BdnA8WwtJeKUVvE('dict',JIVXou7hYWQ6CKDsPOUytnml3e9)
			usytqWehEnV4Cl0mBoRfFQ67MTxGa += B6IrC7zEHlw1oaeWf+NdKhAS6MXVEORLTwob92pxlZ.join(JIVXou7hYWQ6CKDsPOUytnml3e9['translation'])
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa[2:]
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000000','00000').replace('00000','0000').replace('0000','000')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0001',Whef0cxB2iR93SC5IwUtk)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0002',D7INg5kyRjwf4ZtoePVUrb1h2SJ)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0003',kjd9LyNqQHMUevZiRI7OlBGF1h)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0004','=====')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0005',',')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('0009','[RTL]')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000A','[CENTER]')
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.replace('000B',SSDnd9QAUwo86G7eurKlaPikE3qsv)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = usytqWehEnV4Cl0mBoRfFQ67MTxGa.split('\n\n\n\n')
	return wajml8bIqCJShpkB6uiWM4tdE2D53Z+usytqWehEnV4Cl0mBoRfFQ67MTxGa
def oDkgHWqy8Nen9M0h3O2Q(hyRfxjI9ruDPkHwcA5vbg):
	zyqawo7pjkfXGx02vMPUTN3VJ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.translate')
	if not zyqawo7pjkfXGx02vMPUTN3VJ or not hyRfxjI9ruDPkHwcA5vbg: return hyRfxjI9ruDPkHwcA5vbg
	lDY2Q5J4IA = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.provider')
	kDQWK1Rs84qiHO9fFmVGJILNpb = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
	YawWFJyEVC = kDQWK1Rs84qiHO9fFmVGJILNpb+'__'+str(hyRfxjI9ruDPkHwcA5vbg)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.language.translate',NdKhAS6MXVEORLTwob92pxlZ)
	usytqWehEnV4Cl0mBoRfFQ67MTxGa = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','TRANSLATE_'+lDY2Q5J4IA,YawWFJyEVC)
	if not usytqWehEnV4Cl0mBoRfFQ67MTxGa:
		if lDY2Q5J4IA=='GOOGLE': usytqWehEnV4Cl0mBoRfFQ67MTxGa = iI1V05hRQEX7N(hyRfxjI9ruDPkHwcA5vbg)
		elif lDY2Q5J4IA=='REVERSO': usytqWehEnV4Cl0mBoRfFQ67MTxGa = kqdOmuQ8AeRJxH2ahF4B5ptNP(hyRfxjI9ruDPkHwcA5vbg)
		elif lDY2Q5J4IA=='GLOSBE': usytqWehEnV4Cl0mBoRfFQ67MTxGa = ViwhjZQkqICsOd(hyRfxjI9ruDPkHwcA5vbg)
		if len(hyRfxjI9ruDPkHwcA5vbg)==len(usytqWehEnV4Cl0mBoRfFQ67MTxGa):
			eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'TRANSLATE_'+lDY2Q5J4IA,YawWFJyEVC,usytqWehEnV4Cl0mBoRfFQ67MTxGa,KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
		else:
			usytqWehEnV4Cl0mBoRfFQ67MTxGa = hyRfxjI9ruDPkHwcA5vbg
			kkDz5sdaPteM('الترجمة فشلت','Translation Failed')
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.language.translate','1')
	return usytqWehEnV4Cl0mBoRfFQ67MTxGa
def LLAlKs5Tbw1chPn(X32lUyoDBqp14T,da5vH2OR1SEiVPwebLrCDj3cu,wylQWMjqTHrgxz,d8k6HX0v5StZjQR,zeILMstvGy8CJQXR4):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd = X32lUyoDBqp14T
	mYBnSvCEfckbPN9hZ1AIH = []
	zyqawo7pjkfXGx02vMPUTN3VJ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.translate')
	if zyqawo7pjkfXGx02vMPUTN3VJ:
		QQtfF6H4xgpdBlILvPuKeGChNmcXD,yhct2uaXjmQ,oWaf0Cej5T84XLG7bY = [],[],[]
		if not mYBnSvCEfckbPN9hZ1AIH:
			for NKxnhpYvgf in da5vH2OR1SEiVPwebLrCDj3cu:
				JHKDFe6Am0ruz8 = NKxnhpYvgf['name'].replace(iy0rIHuvaAgpbjRKnTQcJwLVs,NdKhAS6MXVEORLTwob92pxlZ).replace(MgDNZ1f34w,NdKhAS6MXVEORLTwob92pxlZ)
				wUqlzC43fuXNOtpYaFTxd = YYqECUofyi7wFrW.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
				if wUqlzC43fuXNOtpYaFTxd:
					wajml8bIqCJShpkB6uiWM4tdE2D53Z,jHhn7qeMDPCAd9Eo5UBr8s,TTNOYS6I0AnsRX7QHGa,cv7noMaZA1xyfGqU,JHKDFe6Am0ruz8 = wUqlzC43fuXNOtpYaFTxd[0]
					wUqlzC43fuXNOtpYaFTxd = wajml8bIqCJShpkB6uiWM4tdE2D53Z+jHhn7qeMDPCAd9Eo5UBr8s+Vwgflszp4WRA93kx6hvdua21HX5cOb+TTNOYS6I0AnsRX7QHGa+cv7noMaZA1xyfGqU+Vwgflszp4WRA93kx6hvdua21HX5cOb
				else:
					wUqlzC43fuXNOtpYaFTxd = YYqECUofyi7wFrW.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
					if wUqlzC43fuXNOtpYaFTxd:
						JHKDFe6Am0ruz8,wajml8bIqCJShpkB6uiWM4tdE2D53Z,TTNOYS6I0AnsRX7QHGa,jHhn7qeMDPCAd9Eo5UBr8s,cv7noMaZA1xyfGqU = wUqlzC43fuXNOtpYaFTxd[0]
						wUqlzC43fuXNOtpYaFTxd = wajml8bIqCJShpkB6uiWM4tdE2D53Z+jHhn7qeMDPCAd9Eo5UBr8s+Vwgflszp4WRA93kx6hvdua21HX5cOb+TTNOYS6I0AnsRX7QHGa+cv7noMaZA1xyfGqU+Vwgflszp4WRA93kx6hvdua21HX5cOb
					else: wUqlzC43fuXNOtpYaFTxd = NdKhAS6MXVEORLTwob92pxlZ
				f21fbCHXEIZ = YYqECUofyi7wFrW.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
				if f21fbCHXEIZ: f21fbCHXEIZ,JHKDFe6Am0ruz8 = f21fbCHXEIZ[0]
				else: f21fbCHXEIZ = NdKhAS6MXVEORLTwob92pxlZ
				QQtfF6H4xgpdBlILvPuKeGChNmcXD.append(wUqlzC43fuXNOtpYaFTxd+f21fbCHXEIZ)
				yhct2uaXjmQ.append(JHKDFe6Am0ruz8)
			oWaf0Cej5T84XLG7bY = oDkgHWqy8Nen9M0h3O2Q(yhct2uaXjmQ)
			if oWaf0Cej5T84XLG7bY:
				for zG37PsWCeVZ4aYtmkE2DTowqBF in range(len(da5vH2OR1SEiVPwebLrCDj3cu)):
					NKxnhpYvgf = da5vH2OR1SEiVPwebLrCDj3cu[zG37PsWCeVZ4aYtmkE2DTowqBF]
					NKxnhpYvgf['name'] = QQtfF6H4xgpdBlILvPuKeGChNmcXD[zG37PsWCeVZ4aYtmkE2DTowqBF]+oWaf0Cej5T84XLG7bY[zG37PsWCeVZ4aYtmkE2DTowqBF]
					mYBnSvCEfckbPN9hZ1AIH.append(NKxnhpYvgf)
	if mYBnSvCEfckbPN9hZ1AIH: da5vH2OR1SEiVPwebLrCDj3cu = mYBnSvCEfckbPN9hZ1AIH
	jXznFHM7KqNQ2rG1lPI8EmOb4,a7DMHJnfuTU9AeOrj1LsIGdN2gzQ,jS0iIK6CmAxov9TrgdeJf71kzhLn = [],0,0
	oZJvXDV2kBycdnUPAu9Q4 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.menusimages')
	xtB8UfoRDjOsXFc5 = oZJvXDV2kBycdnUPAu9Q4!='STOP'
	T0JV6ezRfOZF5W4 = []
	if xtB8UfoRDjOsXFc5:
		w26SxTNg0JzrYij = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YyHUiEXh8NQAvCf,pPrvqm3tjuXLTgw1)
		try: T0JV6ezRfOZF5W4 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(w26SxTNg0JzrYij)
		except:
			if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(w26SxTNg0JzrYij):
				try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.makedirs(w26SxTNg0JzrYij)
				except: pass
	NqYyJSfcOTQ5Bt0XnFwRV = RDLFVhWGp9dwoPrbylTcSku036('menu_item')
	ynC5SZ0aiYVlI7HmR9TbkP = T0JV6ezRfOZF5W4
	if QBp28giCnayJzmZH6vYO and hnu0oKAvsG4PaX6yxiTj2eftY.platform=='win32':
		ynC5SZ0aiYVlI7HmR9TbkP = []
		for Qkohfe3YBdDuRZgz7twIrx8jO in T0JV6ezRfOZF5W4:
			Qkohfe3YBdDuRZgz7twIrx8jO = Qkohfe3YBdDuRZgz7twIrx8jO.decode('windows-1256').encode(YRvPKe2zMTDs8UCkr)
			ynC5SZ0aiYVlI7HmR9TbkP.append(Qkohfe3YBdDuRZgz7twIrx8jO)
	for NKxnhpYvgf in da5vH2OR1SEiVPwebLrCDj3cu:
		JHKDFe6Am0ruz8 = NKxnhpYvgf['name']
		if J92gCnbGWidQV70lBteTwU6D8uyzL: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.encode(YRvPKe2zMTDs8UCkr,'ignore').decode(YRvPKe2zMTDs8UCkr)
		j8Zrmbxpe12oHMQugPNFBlkRLS = NKxnhpYvgf['context_menu']
		AADw4KHigrudJ8MRpFmtISaY = NKxnhpYvgf['plot']
		tc53XJaAOE7sgnKo9I = NKxnhpYvgf['stars']
		nnQPgrIaSEN09T5hf4sx = NKxnhpYvgf['image']
		oJeO8LqTXi7W = NKxnhpYvgf['type']
		OJGK8zCMqWQ = NKxnhpYvgf['duration']
		qUzRHrWJtZe = NKxnhpYvgf['isFolder']
		lXfUH38a5OkeZWQPxnDTsyBqSG0 = NKxnhpYvgf['newpath']
		zX5w2r8WbvkgcH3PxUN = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ListItem(JHKDFe6Am0ruz8)
		zX5w2r8WbvkgcH3PxUN.addContextMenuItems(j8Zrmbxpe12oHMQugPNFBlkRLS)
		hhW9ojDaifZgUHnOxcCBst8 = False if xtB8UfoRDjOsXFc5 else True
		if nnQPgrIaSEN09T5hf4sx:
			zX5w2r8WbvkgcH3PxUN.setArt({'icon':nnQPgrIaSEN09T5hf4sx,'thumb':nnQPgrIaSEN09T5hf4sx,'fanart':nnQPgrIaSEN09T5hf4sx,'banner':nnQPgrIaSEN09T5hf4sx,'clearart':nnQPgrIaSEN09T5hf4sx,'poster':nnQPgrIaSEN09T5hf4sx,'clearlogo':nnQPgrIaSEN09T5hf4sx,'landscape':nnQPgrIaSEN09T5hf4sx})
			hhW9ojDaifZgUHnOxcCBst8 = False
		elif not hhW9ojDaifZgUHnOxcCBst8:
			hhW9ojDaifZgUHnOxcCBst8 = True
			JHKDFe6Am0ruz8 = LeIEtX7A6J(f4vncKMRlXG9s,JHKDFe6Am0ruz8)
			JHKDFe6Am0ruz8 = UryVN9KOA5tuqi(JHKDFe6Am0ruz8)
			Y2Zxt1RKhojiJAmfUlnqb8uFH = JHKDFe6Am0ruz8+'.png'
			gT8daB6wcR4XIt1YlfALxsSNGWkKU = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(w26SxTNg0JzrYij,Y2Zxt1RKhojiJAmfUlnqb8uFH)
			if Y2Zxt1RKhojiJAmfUlnqb8uFH in ynC5SZ0aiYVlI7HmR9TbkP:
				zX5w2r8WbvkgcH3PxUN.setArt({'icon':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'thumb':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'fanart':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'banner':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'clearart':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'poster':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'clearlogo':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'landscape':gT8daB6wcR4XIt1YlfALxsSNGWkKU})
				hhW9ojDaifZgUHnOxcCBst8 = False
			elif a7DMHJnfuTU9AeOrj1LsIGdN2gzQ<40 and jS0iIK6CmAxov9TrgdeJf71kzhLn<=3:
				try:
					wkUj71oTODcXSKsHvYl8MLpbdf5ZC = y0TJA64nkQYLCvrU9t1gqPcb(NqYyJSfcOTQ5Bt0XnFwRV,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JHKDFe6Am0ruz8,'menu_item','center',False,gT8daB6wcR4XIt1YlfALxsSNGWkKU)
					zX5w2r8WbvkgcH3PxUN.setArt({'icon':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'thumb':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'fanart':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'banner':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'clearart':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'poster':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'clearlogo':gT8daB6wcR4XIt1YlfALxsSNGWkKU,'landscape':gT8daB6wcR4XIt1YlfALxsSNGWkKU})
					a7DMHJnfuTU9AeOrj1LsIGdN2gzQ += 1
					hhW9ojDaifZgUHnOxcCBst8 = False
					ynC5SZ0aiYVlI7HmR9TbkP.append(Y2Zxt1RKhojiJAmfUlnqb8uFH)
					if a7DMHJnfuTU9AeOrj1LsIGdN2gzQ==5: kkDz5sdaPteM('إضافة الكتابة لصور القائمة','انتظار',XJ62UBRmIqFvfiNTQj=500)
				except: jS0iIK6CmAxov9TrgdeJf71kzhLn += 1
		if hhW9ojDaifZgUHnOxcCBst8:
			zX5w2r8WbvkgcH3PxUN.setArt({'icon':Mlx2ijKJHNy9,'thumb':Mlx2ijKJHNy9,'fanart':Mlx2ijKJHNy9,'banner':Mlx2ijKJHNy9,'clearart':Mlx2ijKJHNy9,'poster':Mlx2ijKJHNy9,'clearlogo':Mlx2ijKJHNy9,'landscape':Mlx2ijKJHNy9})
		if kQI947MebLovYyVE08F5qPi6fj3<20:
			if AADw4KHigrudJ8MRpFmtISaY: zX5w2r8WbvkgcH3PxUN.setInfo('video',{'Plot':AADw4KHigrudJ8MRpFmtISaY,'PlotOutline':AADw4KHigrudJ8MRpFmtISaY})
			if tc53XJaAOE7sgnKo9I: zX5w2r8WbvkgcH3PxUN.setInfo('video',{'Rating':tc53XJaAOE7sgnKo9I})
			if not nnQPgrIaSEN09T5hf4sx:
				zX5w2r8WbvkgcH3PxUN.setInfo('video',{'Title':JHKDFe6Am0ruz8})
			if oJeO8LqTXi7W=='video':
				zX5w2r8WbvkgcH3PxUN.setInfo('video',{'mediatype':'tvshow'})
				if OJGK8zCMqWQ: zX5w2r8WbvkgcH3PxUN.setInfo('video',{'duration':OJGK8zCMqWQ})
				zX5w2r8WbvkgcH3PxUN.setProperty('IsPlayable','true')
		else:
			XXIeOSd4zZpuKArmM = zX5w2r8WbvkgcH3PxUN.getVideoInfoTag()
			if tc53XJaAOE7sgnKo9I: XXIeOSd4zZpuKArmM.setRating(float(tc53XJaAOE7sgnKo9I))
			if not nnQPgrIaSEN09T5hf4sx:
				XXIeOSd4zZpuKArmM.setTitle(JHKDFe6Am0ruz8)
			if oJeO8LqTXi7W=='video':
				XXIeOSd4zZpuKArmM.setMediaType('tvshow')
				if OJGK8zCMqWQ: XXIeOSd4zZpuKArmM.setDuration(OJGK8zCMqWQ)
				zX5w2r8WbvkgcH3PxUN.setProperty('IsPlayable','true')
		jXznFHM7KqNQ2rG1lPI8EmOb4.append((lXfUH38a5OkeZWQPxnDTsyBqSG0,zX5w2r8WbvkgcH3PxUN,qUzRHrWJtZe))
	vI4DUTHAYrjBPOXwu9nas.setContent(oo2RYcTAqyksN1DHG7gLCaZJ,'tvshows')
	aBKduWFi89k = vI4DUTHAYrjBPOXwu9nas.addDirectoryItems(oo2RYcTAqyksN1DHG7gLCaZJ,jXznFHM7KqNQ2rG1lPI8EmOb4)
	vI4DUTHAYrjBPOXwu9nas.endOfDirectory(oo2RYcTAqyksN1DHG7gLCaZJ,wylQWMjqTHrgxz,d8k6HX0v5StZjQR,zeILMstvGy8CJQXR4)
	return aBKduWFi89k
def ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx=NdKhAS6MXVEORLTwob92pxlZ,nnkBNQrAK1SmzpfYD0j=NdKhAS6MXVEORLTwob92pxlZ,ui7N5YGR9KdslpEbQkVTwFqDgI=NdKhAS6MXVEORLTwob92pxlZ,ueFHThK2pDYc=NdKhAS6MXVEORLTwob92pxlZ,ww1lsWcSe2Cd={}):
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace('\t',NdKhAS6MXVEORLTwob92pxlZ)
	TixSXhpW69Uba4f1NPqzYE7JcZ = TixSXhpW69Uba4f1NPqzYE7JcZ.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace('\t',NdKhAS6MXVEORLTwob92pxlZ)
	if '_SCRIPT_' in JHKDFe6Am0ruz8:
		qaD1Jv7VWbMoI04Bx8UkrC9XQOh,JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.split('_SCRIPT_',llxMLe4gobHhsj1WGvd7qmIU)
		if qaD1Jv7VWbMoI04Bx8UkrC9XQOh not in list(yZLFCImoREnkBv.keys()): yZLFCImoREnkBv[qaD1Jv7VWbMoI04Bx8UkrC9XQOh] = []
		yZLFCImoREnkBv[qaD1Jv7VWbMoI04Bx8UkrC9XQOh].append([oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd])
	emiIH49XT6jzOQrw.append([oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd])
	return
def Pr4ubLdO7Z1qjKFaMIy3H(M9ofknp2qBmuEj4UYd6esZaWKy3S1O):
	if J92gCnbGWidQV70lBteTwU6D8uyzL: from html import unescape as _9Gp4hsSWM2i8Q7gIkvNrROTf0Z
	else:
		from HTMLParser import HTMLParser as v0f38JUZTgq5r2c1xKVikteNIbCoOP
		_9Gp4hsSWM2i8Q7gIkvNrROTf0Z = v0f38JUZTgq5r2c1xKVikteNIbCoOP().unescape
	if '&' in M9ofknp2qBmuEj4UYd6esZaWKy3S1O and ';' in M9ofknp2qBmuEj4UYd6esZaWKy3S1O:
		if QBp28giCnayJzmZH6vYO: M9ofknp2qBmuEj4UYd6esZaWKy3S1O = M9ofknp2qBmuEj4UYd6esZaWKy3S1O.decode(YRvPKe2zMTDs8UCkr)
		M9ofknp2qBmuEj4UYd6esZaWKy3S1O = _9Gp4hsSWM2i8Q7gIkvNrROTf0Z(M9ofknp2qBmuEj4UYd6esZaWKy3S1O)
		if QBp28giCnayJzmZH6vYO: M9ofknp2qBmuEj4UYd6esZaWKy3S1O = M9ofknp2qBmuEj4UYd6esZaWKy3S1O.encode(YRvPKe2zMTDs8UCkr)
	return M9ofknp2qBmuEj4UYd6esZaWKy3S1O
def L5xKSr96JmaX7N(M9ofknp2qBmuEj4UYd6esZaWKy3S1O):
	if '\\u' in M9ofknp2qBmuEj4UYd6esZaWKy3S1O:
		if QBp28giCnayJzmZH6vYO: M9ofknp2qBmuEj4UYd6esZaWKy3S1O = M9ofknp2qBmuEj4UYd6esZaWKy3S1O.decode('unicode_escape','ignore').encode(YRvPKe2zMTDs8UCkr)
		elif J92gCnbGWidQV70lBteTwU6D8uyzL: M9ofknp2qBmuEj4UYd6esZaWKy3S1O = M9ofknp2qBmuEj4UYd6esZaWKy3S1O.encode(YRvPKe2zMTDs8UCkr).decode('unicode_escape','ignore')
	return M9ofknp2qBmuEj4UYd6esZaWKy3S1O
def XlvB7rxiTQZs6FJKPfOn(TrN7JUP0OsH3a1oELjt,eD2VOom9BvwZFTx6XHPJ,DDU5sw9izd2JF4jWa7BZSkrLe,AJaj1pkFywoKm3ZRxH9z7uC0Sf,ui7N5YGR9KdslpEbQkVTwFqDgI,Z8eQjYFdi312lIV,GyMvoIhtzm,Kqd6E7IiCeRa9Bv,Zp45WHmewoCYNR):
	CBwPOXvRYsjWc5NtS9I7D = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.dirname(Zp45WHmewoCYNR)
	if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(CBwPOXvRYsjWc5NtS9I7D):
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.makedirs(CBwPOXvRYsjWc5NtS9I7D)
		except: pass
	BrpA21N7OjamwfndbGFH = RDLFVhWGp9dwoPrbylTcSku036(Z8eQjYFdi312lIV)
	wkUj71oTODcXSKsHvYl8MLpbdf5ZC = y0TJA64nkQYLCvrU9t1gqPcb(BrpA21N7OjamwfndbGFH,TrN7JUP0OsH3a1oELjt,eD2VOom9BvwZFTx6XHPJ,DDU5sw9izd2JF4jWa7BZSkrLe,AJaj1pkFywoKm3ZRxH9z7uC0Sf,ui7N5YGR9KdslpEbQkVTwFqDgI,Z8eQjYFdi312lIV,GyMvoIhtzm,Kqd6E7IiCeRa9Bv,Zp45WHmewoCYNR)
	return wkUj71oTODcXSKsHvYl8MLpbdf5ZC
def RDLFVhWGp9dwoPrbylTcSku036(Z8eQjYFdi312lIV):
	W9WTMR1nZOL6V0C8IlFdiHomNgvJ = 5
	WJa5ubj06LsFlvr1n384kqVgxPZQT = 20
	cR1taXIfWAv27rdN9nSHsDhbx = 20
	AIwbHRWKVuoeXgh1JSyfnU3POQ = 0
	gVxY32G1E9sRrQap = 'center'
	n3awVe9jMqvOS6cXbZJgQH8 = 0
	QamkCNWFHe4R0JwbKgD1d7OMsq = 19
	qVEpa6yY4GWu3Z8 = 30
	VDhQe0b2Xxjp = 8
	s6CIMB0u4P7xWrFqY5Z2az = True
	OLtHfyczjI = 375
	Xd4a5r8WtS70I9PmvjwGLyhHlb = 410
	QhaY8169FJu2XnA = 50
	NbtJXHua2EoqUjCLgd3 = 280
	tie0bpTjha = 28
	Z4rgMkH7NFV6UD = 5
	QtAjBnVCcDYIMHs751NahJubZPET9 = 0
	WMXPtDLfhx2CZGwk0N9UF1oEY = 31
	ww4jPOleHzhM = [36,32,28]
	from PIL import ImageDraw as iZJKAR5qgr624HQ,ImageFont as yV0sLZKX8gqDRA5ueOQtjd2S,Image as ut7T1EbDyrg8dRVOI
	if 'notification' in Z8eQjYFdi312lIV:
		if Z8eQjYFdi312lIV=='notification_regular':
			gHWf5jUp7MTAJxaKdO = 117
			gVxY32G1E9sRrQap = 'left'
			s6CIMB0u4P7xWrFqY5Z2az = False
		elif Z8eQjYFdi312lIV=='notification_auto':
			gHWf5jUp7MTAJxaKdO = 'UPPER'
			gVxY32G1E9sRrQap = 'right'
			AIwbHRWKVuoeXgh1JSyfnU3POQ = 10
		POoVGHE8k4STLu5csgAZIlR1j37f = 720
		ww4jPOleHzhM = [33,33,33]
		cR1taXIfWAv27rdN9nSHsDhbx = 20
		WJa5ubj06LsFlvr1n384kqVgxPZQT = 0
		qVEpa6yY4GWu3Z8 = 20
		QamkCNWFHe4R0JwbKgD1d7OMsq = 35
	elif Z8eQjYFdi312lIV=='menu_item':
		ww4jPOleHzhM,POoVGHE8k4STLu5csgAZIlR1j37f,gHWf5jUp7MTAJxaKdO = [28,28,28],200,250
		n3awVe9jMqvOS6cXbZJgQH8,qVEpa6yY4GWu3Z8,QamkCNWFHe4R0JwbKgD1d7OMsq, = 0,-12,-30
		WJa5ubj06LsFlvr1n384kqVgxPZQT = 0
		OC6VWLbi5m921UDPgRFyG4TvI = ut7T1EbDyrg8dRVOI.open(Mlx2ijKJHNy9)
		t6YA9vPNyHk7eJ2LSxCaTjdbBmVzo = ut7T1EbDyrg8dRVOI.new('RGBA',(POoVGHE8k4STLu5csgAZIlR1j37f,gHWf5jUp7MTAJxaKdO),(255,0,0,255))
	elif Z8eQjYFdi312lIV=='confirm_smallfont': ww4jPOleHzhM,gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = [28,24,20],500,900
	elif Z8eQjYFdi312lIV=='confirm_mediumfont': ww4jPOleHzhM,gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = [32,28,24],500,900
	elif Z8eQjYFdi312lIV=='confirm_bigfont': ww4jPOleHzhM,gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = [36,32,28],500,900
	elif Z8eQjYFdi312lIV=='textview_bigfont': gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = 740,1270
	elif Z8eQjYFdi312lIV=='textview_bigfont_long': gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = 'UPPER',1270
	elif Z8eQjYFdi312lIV=='textview_smallfont': ww4jPOleHzhM,gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = [28,23,18],740,1270
	elif Z8eQjYFdi312lIV=='textview_smallfont_long': ww4jPOleHzhM,gHWf5jUp7MTAJxaKdO,POoVGHE8k4STLu5csgAZIlR1j37f = [28,23,18],'UPPER',1270
	v0XBJSgY5ZlecszfQ27GH6KmT,jiCETfZAR2P0SxDmHW,Xsag1hdHe0RYWb = ww4jPOleHzhM
	Oea76UEHMj9foND = yV0sLZKX8gqDRA5ueOQtjd2S.truetype(XJ7ya50xLRCME2TNHbAfPQhDqj,size=v0XBJSgY5ZlecszfQ27GH6KmT)
	NublS0p2UOf = yV0sLZKX8gqDRA5ueOQtjd2S.truetype(XJ7ya50xLRCME2TNHbAfPQhDqj,size=jiCETfZAR2P0SxDmHW)
	i48T2je6mpa = yV0sLZKX8gqDRA5ueOQtjd2S.truetype(XJ7ya50xLRCME2TNHbAfPQhDqj,size=Xsag1hdHe0RYWb)
	Bp90fnIwMoY = POoVGHE8k4STLu5csgAZIlR1j37f-qVEpa6yY4GWu3Z8*2
	KDTfZNYqG98x = ut7T1EbDyrg8dRVOI.new('RGBA',(Bp90fnIwMoY,100),(255,255,255,0))
	CPIqX58kncg = iZJKAR5qgr624HQ.Draw(KDTfZNYqG98x)
	vAOEp5qytzPhC,Ol6xWuQDYwTqEoSmvM57Ha = CPIqX58kncg.textsize('HHH BBB 888 000',font=Oea76UEHMj9foND)
	rxH2oiCUbhX7s3LRM6DF,GeJ0rRjyZPLWF = CPIqX58kncg.textsize('HHH BBB 888 000',font=NublS0p2UOf)
	bbU6HXGeqOFtZac1JSgKrLNIko7nDQ = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as bg0YhtjCENeam9pHB25FoyXGcfuO
	lih90NxMRsnGEPrV1Z = bg0YhtjCENeam9pHB25FoyXGcfuO(configuration=bbU6HXGeqOFtZac1JSgKrLNIko7nDQ)
	BrpA21N7OjamwfndbGFH = {}
	a1Q0ZLOXDYSwrF = locals()
	for GWkcLexzmpJyl7nYq in a1Q0ZLOXDYSwrF: BrpA21N7OjamwfndbGFH[GWkcLexzmpJyl7nYq] = a1Q0ZLOXDYSwrF[GWkcLexzmpJyl7nYq]
	return BrpA21N7OjamwfndbGFH
def y0TJA64nkQYLCvrU9t1gqPcb(BrpA21N7OjamwfndbGFH,TrN7JUP0OsH3a1oELjt,eD2VOom9BvwZFTx6XHPJ,DDU5sw9izd2JF4jWa7BZSkrLe,AJaj1pkFywoKm3ZRxH9z7uC0Sf,ui7N5YGR9KdslpEbQkVTwFqDgI,Z8eQjYFdi312lIV,GyMvoIhtzm,Kqd6E7IiCeRa9Bv,Zp45WHmewoCYNR):
	for GWkcLexzmpJyl7nYq in BrpA21N7OjamwfndbGFH: globals()[GWkcLexzmpJyl7nYq] = BrpA21N7OjamwfndbGFH[GWkcLexzmpJyl7nYq]
	global tie0bpTjha,Z4rgMkH7NFV6UD
	if Z8eQjYFdi312lIV!='menu_item':
		zyqawo7pjkfXGx02vMPUTN3VJ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.translate')
		if zyqawo7pjkfXGx02vMPUTN3VJ:
			if TrN7JUP0OsH3a1oELjt=='نعم  Yes': TrN7JUP0OsH3a1oELjt = 'Yes'
			elif TrN7JUP0OsH3a1oELjt=='كلا  No': TrN7JUP0OsH3a1oELjt = 'No'
			if eD2VOom9BvwZFTx6XHPJ=='نعم  Yes': eD2VOom9BvwZFTx6XHPJ = 'Yes'
			elif eD2VOom9BvwZFTx6XHPJ=='كلا  No': eD2VOom9BvwZFTx6XHPJ = 'No'
			if DDU5sw9izd2JF4jWa7BZSkrLe=='نعم  Yes': DDU5sw9izd2JF4jWa7BZSkrLe = 'Yes'
			elif DDU5sw9izd2JF4jWa7BZSkrLe=='كلا  No': DDU5sw9izd2JF4jWa7BZSkrLe = 'No'
			CCXjewWZpg = oDkgHWqy8Nen9M0h3O2Q([TrN7JUP0OsH3a1oELjt,eD2VOom9BvwZFTx6XHPJ,DDU5sw9izd2JF4jWa7BZSkrLe,AJaj1pkFywoKm3ZRxH9z7uC0Sf,ui7N5YGR9KdslpEbQkVTwFqDgI])
			if CCXjewWZpg: TrN7JUP0OsH3a1oELjt,eD2VOom9BvwZFTx6XHPJ,DDU5sw9izd2JF4jWa7BZSkrLe,AJaj1pkFywoKm3ZRxH9z7uC0Sf,ui7N5YGR9KdslpEbQkVTwFqDgI = CCXjewWZpg
	if QBp28giCnayJzmZH6vYO:
		ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.decode(YRvPKe2zMTDs8UCkr)
		AJaj1pkFywoKm3ZRxH9z7uC0Sf = AJaj1pkFywoKm3ZRxH9z7uC0Sf.decode(YRvPKe2zMTDs8UCkr)
		TrN7JUP0OsH3a1oELjt = TrN7JUP0OsH3a1oELjt.decode(YRvPKe2zMTDs8UCkr)
		eD2VOom9BvwZFTx6XHPJ = eD2VOom9BvwZFTx6XHPJ.decode(YRvPKe2zMTDs8UCkr)
		DDU5sw9izd2JF4jWa7BZSkrLe = DDU5sw9izd2JF4jWa7BZSkrLe.decode(YRvPKe2zMTDs8UCkr)
	U527UYdoQn8RKOkaJz1fZh = AJaj1pkFywoKm3ZRxH9z7uC0Sf.count(B6IrC7zEHlw1oaeWf)+1
	BcvR9OdLXo56aDNgVqxMtU3iZH = WJa5ubj06LsFlvr1n384kqVgxPZQT+U527UYdoQn8RKOkaJz1fZh*(Ol6xWuQDYwTqEoSmvM57Ha+AIwbHRWKVuoeXgh1JSyfnU3POQ)-AIwbHRWKVuoeXgh1JSyfnU3POQ
	if ui7N5YGR9KdslpEbQkVTwFqDgI:
		kkl7iJe48XB95KZQdSpcO1wWM = GeJ0rRjyZPLWF+VDhQe0b2Xxjp
		gpuHGWDrBqoAkM40ntIvO1 = lih90NxMRsnGEPrV1Z.reshape(ui7N5YGR9KdslpEbQkVTwFqDgI)
		if s6CIMB0u4P7xWrFqY5Z2az:
			UwWrMIPdpzF02LiK3hJuSxBXN = eMdmHuksbLGthDj3CSVf0OxgTa2RA(CPIqX58kncg,NublS0p2UOf,gpuHGWDrBqoAkM40ntIvO1,jiCETfZAR2P0SxDmHW,Bp90fnIwMoY,kkl7iJe48XB95KZQdSpcO1wWM)
			k9dvCU6gQtOs7X = t5SdpGnOZa8hP3H(UwWrMIPdpzF02LiK3hJuSxBXN)
			j7YmI9rLQ3qCpvnMVXJlFRAf1NBze = k9dvCU6gQtOs7X.count(B6IrC7zEHlw1oaeWf)+1
			k8kEWSmRN4CwVBFavfGOTdKp9 = QamkCNWFHe4R0JwbKgD1d7OMsq+j7YmI9rLQ3qCpvnMVXJlFRAf1NBze*kkl7iJe48XB95KZQdSpcO1wWM-VDhQe0b2Xxjp
		else:
			k8kEWSmRN4CwVBFavfGOTdKp9 = QamkCNWFHe4R0JwbKgD1d7OMsq+GeJ0rRjyZPLWF
			k9dvCU6gQtOs7X = gpuHGWDrBqoAkM40ntIvO1.split(B6IrC7zEHlw1oaeWf)[0]
			UwWrMIPdpzF02LiK3hJuSxBXN = gpuHGWDrBqoAkM40ntIvO1.split(B6IrC7zEHlw1oaeWf)[0]
	else: k8kEWSmRN4CwVBFavfGOTdKp9 = QamkCNWFHe4R0JwbKgD1d7OMsq
	a1TXZoVn46FOszWIfSD3g57i = QtAjBnVCcDYIMHs751NahJubZPET9+WMXPtDLfhx2CZGwk0N9UF1oEY
	if Kqd6E7IiCeRa9Bv:
		HmQKSewE20qIPljs37NGoxhpUy1FgA = Xd4a5r8WtS70I9PmvjwGLyhHlb-OLtHfyczjI
		a1TXZoVn46FOszWIfSD3g57i += HmQKSewE20qIPljs37NGoxhpUy1FgA
	else: HmQKSewE20qIPljs37NGoxhpUy1FgA = 0
	if TrN7JUP0OsH3a1oELjt or eD2VOom9BvwZFTx6XHPJ or DDU5sw9izd2JF4jWa7BZSkrLe: a1TXZoVn46FOszWIfSD3g57i += QhaY8169FJu2XnA
	wkUj71oTODcXSKsHvYl8MLpbdf5ZC = gHWf5jUp7MTAJxaKdO if gHWf5jUp7MTAJxaKdO!='UPPER' else BcvR9OdLXo56aDNgVqxMtU3iZH+k8kEWSmRN4CwVBFavfGOTdKp9+a1TXZoVn46FOszWIfSD3g57i
	KDTfZNYqG98x = ut7T1EbDyrg8dRVOI.new('RGBA',(POoVGHE8k4STLu5csgAZIlR1j37f,wkUj71oTODcXSKsHvYl8MLpbdf5ZC),(255,255,255,0))
	g1RNC8Zcmiq2YrIXMTlp5 = iZJKAR5qgr624HQ.Draw(KDTfZNYqG98x)
	h2cAoegKQI6Lx4pqRJs9 = wkUj71oTODcXSKsHvYl8MLpbdf5ZC-BcvR9OdLXo56aDNgVqxMtU3iZH-a1TXZoVn46FOszWIfSD3g57i-QamkCNWFHe4R0JwbKgD1d7OMsq
	if not eD2VOom9BvwZFTx6XHPJ and TrN7JUP0OsH3a1oELjt and DDU5sw9izd2JF4jWa7BZSkrLe:
		tie0bpTjha += 105
		Z4rgMkH7NFV6UD -= 110
	import bidi.algorithm as q2o5GXsuaJxkjU
	if AJaj1pkFywoKm3ZRxH9z7uC0Sf:
		eGmVS852K9XNvlYRhPq1CWo = WJa5ubj06LsFlvr1n384kqVgxPZQT
		AJaj1pkFywoKm3ZRxH9z7uC0Sf = q2o5GXsuaJxkjU.get_display(lih90NxMRsnGEPrV1Z.reshape(AJaj1pkFywoKm3ZRxH9z7uC0Sf))
		hyRfxjI9ruDPkHwcA5vbg = AJaj1pkFywoKm3ZRxH9z7uC0Sf.splitlines()
		for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
			if WEPkgTHGs46itVBLn5fZb21QSIvC:
				n9OAiTUFBxRNC1Mc,D3spP5q1y4Mmr = g1RNC8Zcmiq2YrIXMTlp5.textsize(WEPkgTHGs46itVBLn5fZb21QSIvC,font=Oea76UEHMj9foND)
				if gVxY32G1E9sRrQap=='center': sXiWSbIk7Dy0wgThaoV1c = W9WTMR1nZOL6V0C8IlFdiHomNgvJ+(POoVGHE8k4STLu5csgAZIlR1j37f-n9OAiTUFBxRNC1Mc)/2
				elif gVxY32G1E9sRrQap=='right': sXiWSbIk7Dy0wgThaoV1c = W9WTMR1nZOL6V0C8IlFdiHomNgvJ+POoVGHE8k4STLu5csgAZIlR1j37f-n9OAiTUFBxRNC1Mc-cR1taXIfWAv27rdN9nSHsDhbx
				elif gVxY32G1E9sRrQap=='left': sXiWSbIk7Dy0wgThaoV1c = W9WTMR1nZOL6V0C8IlFdiHomNgvJ+cR1taXIfWAv27rdN9nSHsDhbx
				g1RNC8Zcmiq2YrIXMTlp5.text((sXiWSbIk7Dy0wgThaoV1c,eGmVS852K9XNvlYRhPq1CWo),WEPkgTHGs46itVBLn5fZb21QSIvC,font=Oea76UEHMj9foND,fill='yellow')
			eGmVS852K9XNvlYRhPq1CWo += v0XBJSgY5ZlecszfQ27GH6KmT+AIwbHRWKVuoeXgh1JSyfnU3POQ
	if TrN7JUP0OsH3a1oELjt or eD2VOom9BvwZFTx6XHPJ or DDU5sw9izd2JF4jWa7BZSkrLe:
		yWP2dq8tYjZTarbfMDkgswAUmR76 = BcvR9OdLXo56aDNgVqxMtU3iZH+h2cAoegKQI6Lx4pqRJs9+QamkCNWFHe4R0JwbKgD1d7OMsq+HmQKSewE20qIPljs37NGoxhpUy1FgA+QtAjBnVCcDYIMHs751NahJubZPET9
		if TrN7JUP0OsH3a1oELjt:
			TrN7JUP0OsH3a1oELjt = q2o5GXsuaJxkjU.get_display(lih90NxMRsnGEPrV1Z.reshape(TrN7JUP0OsH3a1oELjt))
			GtjprwYXn3vShH7xyR,gydBImEiKwkxtOjuT736e5aDGJpbM = g1RNC8Zcmiq2YrIXMTlp5.textsize(TrN7JUP0OsH3a1oELjt,font=i48T2je6mpa)
			WWF2iE4LQuUPDJtCjfI1g0 = tie0bpTjha+0*(Z4rgMkH7NFV6UD+NbtJXHua2EoqUjCLgd3)+(NbtJXHua2EoqUjCLgd3-GtjprwYXn3vShH7xyR)/2
			g1RNC8Zcmiq2YrIXMTlp5.text((WWF2iE4LQuUPDJtCjfI1g0,yWP2dq8tYjZTarbfMDkgswAUmR76),TrN7JUP0OsH3a1oELjt,font=i48T2je6mpa,fill='yellow')
		if eD2VOom9BvwZFTx6XHPJ:
			eD2VOom9BvwZFTx6XHPJ = q2o5GXsuaJxkjU.get_display(lih90NxMRsnGEPrV1Z.reshape(eD2VOom9BvwZFTx6XHPJ))
			J1h2WfyZinqudHvcl,OJne2V3z9aT = g1RNC8Zcmiq2YrIXMTlp5.textsize(eD2VOom9BvwZFTx6XHPJ,font=i48T2je6mpa)
			VfFerEZxTLYbuG3Bi0Pq = tie0bpTjha+1*(Z4rgMkH7NFV6UD+NbtJXHua2EoqUjCLgd3)+(NbtJXHua2EoqUjCLgd3-J1h2WfyZinqudHvcl)/2
			g1RNC8Zcmiq2YrIXMTlp5.text((VfFerEZxTLYbuG3Bi0Pq,yWP2dq8tYjZTarbfMDkgswAUmR76),eD2VOom9BvwZFTx6XHPJ,font=i48T2je6mpa,fill='yellow')
		if DDU5sw9izd2JF4jWa7BZSkrLe:
			DDU5sw9izd2JF4jWa7BZSkrLe = q2o5GXsuaJxkjU.get_display(lih90NxMRsnGEPrV1Z.reshape(DDU5sw9izd2JF4jWa7BZSkrLe))
			ftHQBSi9EKa5CmPd4o,OoM2DSuJAehxsZ = g1RNC8Zcmiq2YrIXMTlp5.textsize(DDU5sw9izd2JF4jWa7BZSkrLe,font=i48T2je6mpa)
			AO5i6FBJX3RdC = tie0bpTjha+2*(Z4rgMkH7NFV6UD+NbtJXHua2EoqUjCLgd3)+(NbtJXHua2EoqUjCLgd3-ftHQBSi9EKa5CmPd4o)/2
			g1RNC8Zcmiq2YrIXMTlp5.text((AO5i6FBJX3RdC,yWP2dq8tYjZTarbfMDkgswAUmR76),DDU5sw9izd2JF4jWa7BZSkrLe,font=i48T2je6mpa,fill='yellow')
	if ui7N5YGR9KdslpEbQkVTwFqDgI:
		lls5MBbx0ge6qwHQYSTzhcr4nfWKd,wuYTQJcOXSaZz4m1 = [],[]
		UwWrMIPdpzF02LiK3hJuSxBXN = WX79lUztLm5PEOfTvxyJZMsbI4B(UwWrMIPdpzF02LiK3hJuSxBXN)
		CbAxwnvHSWzUo5K = UwWrMIPdpzF02LiK3hJuSxBXN.split('_sss__newline_')
		for RdArFQZ0JnlD in CbAxwnvHSWzUo5K:
			Wl7pRiQtMUBVg = GyMvoIhtzm
			if   '_sss__lineleft_' in RdArFQZ0JnlD: Wl7pRiQtMUBVg = 'left'
			elif '_sss__lineright_' in RdArFQZ0JnlD: Wl7pRiQtMUBVg = 'right'
			elif '_sss__linecenter_' in RdArFQZ0JnlD: Wl7pRiQtMUBVg = 'center'
			ClS1Dh0vo4xKea5yn6k = RdArFQZ0JnlD
			OOzgidYJaj3kl1LpF5cH = YYqECUofyi7wFrW.findall('_sss__.*?_',RdArFQZ0JnlD,YYqECUofyi7wFrW.DOTALL)
			for oocADgqCr8G03XyYUFeks in OOzgidYJaj3kl1LpF5cH: ClS1Dh0vo4xKea5yn6k = ClS1Dh0vo4xKea5yn6k.replace(oocADgqCr8G03XyYUFeks,NdKhAS6MXVEORLTwob92pxlZ)
			if ClS1Dh0vo4xKea5yn6k==NdKhAS6MXVEORLTwob92pxlZ: n9OAiTUFBxRNC1Mc,D3spP5q1y4Mmr = 0,kkl7iJe48XB95KZQdSpcO1wWM
			else: n9OAiTUFBxRNC1Mc,D3spP5q1y4Mmr = g1RNC8Zcmiq2YrIXMTlp5.textsize(ClS1Dh0vo4xKea5yn6k,font=NublS0p2UOf)
			if   Wl7pRiQtMUBVg=='left': ZEjCORhl7WpnB = n3awVe9jMqvOS6cXbZJgQH8+qVEpa6yY4GWu3Z8
			elif Wl7pRiQtMUBVg=='right': ZEjCORhl7WpnB = n3awVe9jMqvOS6cXbZJgQH8+qVEpa6yY4GWu3Z8+Bp90fnIwMoY-n9OAiTUFBxRNC1Mc
			elif Wl7pRiQtMUBVg=='center': ZEjCORhl7WpnB = n3awVe9jMqvOS6cXbZJgQH8+qVEpa6yY4GWu3Z8+(Bp90fnIwMoY-n9OAiTUFBxRNC1Mc)/2
			if ZEjCORhl7WpnB<qVEpa6yY4GWu3Z8: ZEjCORhl7WpnB = n3awVe9jMqvOS6cXbZJgQH8+qVEpa6yY4GWu3Z8
			lls5MBbx0ge6qwHQYSTzhcr4nfWKd.append(ZEjCORhl7WpnB)
			wuYTQJcOXSaZz4m1.append(n9OAiTUFBxRNC1Mc)
		ZEjCORhl7WpnB = lls5MBbx0ge6qwHQYSTzhcr4nfWKd[0]
		dY9NviZGBcP4qDLr5Vp8H = UwWrMIPdpzF02LiK3hJuSxBXN.split('_sss_')
		envtCdcRT8KI1U4lNQ53Vj = (255,255,255,255)
		MhiBpkKdv5WnUySmuVxAaX7o3N0q9 = envtCdcRT8KI1U4lNQ53Vj
		rOcgvhT9tJ6ZB,XXMdsqyFU567LtKHB = 0,0
		U2gRPo8ybwWH6JN5AcEZSz4xl = False
		OUklLzBn2M07SsbAhPX15 = 0
		A8k1KBFmLONEx6XQun = BcvR9OdLXo56aDNgVqxMtU3iZH+QamkCNWFHe4R0JwbKgD1d7OMsq/2
		if k8kEWSmRN4CwVBFavfGOTdKp9<(h2cAoegKQI6Lx4pqRJs9+QamkCNWFHe4R0JwbKgD1d7OMsq):
			wWHkvU9Ejtm = (h2cAoegKQI6Lx4pqRJs9+QamkCNWFHe4R0JwbKgD1d7OMsq-k8kEWSmRN4CwVBFavfGOTdKp9)/2
			A8k1KBFmLONEx6XQun = BcvR9OdLXo56aDNgVqxMtU3iZH+QamkCNWFHe4R0JwbKgD1d7OMsq+wWHkvU9Ejtm-GeJ0rRjyZPLWF/2
		for WEPkgTHGs46itVBLn5fZb21QSIvC in dY9NviZGBcP4qDLr5Vp8H:
			if not WEPkgTHGs46itVBLn5fZb21QSIvC or (WEPkgTHGs46itVBLn5fZb21QSIvC and ord(WEPkgTHGs46itVBLn5fZb21QSIvC[0])==65279): continue
			QuCPtyDeTbcV6nRB5p = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_newline_',1)
			gcPTXs8B123GkZLJMYIjnofe7A = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_newcolor',1)
			cJ0aSOpq4V1YX59vFmM = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_endcolor_',1)
			GMNgydouWliqXB = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_linertl_',1)
			kkZShir25GxmsJ = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_lineleft_',1)
			zIYDJn8Zx2GuXAFehUylw = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_lineright_',1)
			ed4FzZl9msYTfa2HPiKu0h1qw = WEPkgTHGs46itVBLn5fZb21QSIvC.split('_linecenter_',1)
			if len(QuCPtyDeTbcV6nRB5p)>1:
				OUklLzBn2M07SsbAhPX15 += 1
				WEPkgTHGs46itVBLn5fZb21QSIvC = QuCPtyDeTbcV6nRB5p[1]
				rOcgvhT9tJ6ZB = 0
				ZEjCORhl7WpnB = lls5MBbx0ge6qwHQYSTzhcr4nfWKd[OUklLzBn2M07SsbAhPX15]
				XXMdsqyFU567LtKHB += kkl7iJe48XB95KZQdSpcO1wWM
				U2gRPo8ybwWH6JN5AcEZSz4xl = False
			elif len(gcPTXs8B123GkZLJMYIjnofe7A)>1:
				WEPkgTHGs46itVBLn5fZb21QSIvC = gcPTXs8B123GkZLJMYIjnofe7A[1]
				MhiBpkKdv5WnUySmuVxAaX7o3N0q9 = WEPkgTHGs46itVBLn5fZb21QSIvC[0:8]
				MhiBpkKdv5WnUySmuVxAaX7o3N0q9 = '#'+MhiBpkKdv5WnUySmuVxAaX7o3N0q9[2:]
				WEPkgTHGs46itVBLn5fZb21QSIvC = WEPkgTHGs46itVBLn5fZb21QSIvC[9:]
			elif len(cJ0aSOpq4V1YX59vFmM)>1:
				WEPkgTHGs46itVBLn5fZb21QSIvC = cJ0aSOpq4V1YX59vFmM[1]
				MhiBpkKdv5WnUySmuVxAaX7o3N0q9 = envtCdcRT8KI1U4lNQ53Vj
			elif len(GMNgydouWliqXB)>1:
				WEPkgTHGs46itVBLn5fZb21QSIvC = GMNgydouWliqXB[1]
				U2gRPo8ybwWH6JN5AcEZSz4xl = True
				rOcgvhT9tJ6ZB = wuYTQJcOXSaZz4m1[OUklLzBn2M07SsbAhPX15]
			elif len(kkZShir25GxmsJ)>1: WEPkgTHGs46itVBLn5fZb21QSIvC = kkZShir25GxmsJ[1]
			elif len(zIYDJn8Zx2GuXAFehUylw)>1: WEPkgTHGs46itVBLn5fZb21QSIvC = zIYDJn8Zx2GuXAFehUylw[1]
			elif len(ed4FzZl9msYTfa2HPiKu0h1qw)>1: WEPkgTHGs46itVBLn5fZb21QSIvC = ed4FzZl9msYTfa2HPiKu0h1qw[1]
			if WEPkgTHGs46itVBLn5fZb21QSIvC:
				sM5e0ODwZup3WaPYgt9 = A8k1KBFmLONEx6XQun+XXMdsqyFU567LtKHB
				WEPkgTHGs46itVBLn5fZb21QSIvC = q2o5GXsuaJxkjU.get_display(WEPkgTHGs46itVBLn5fZb21QSIvC)
				n9OAiTUFBxRNC1Mc,D3spP5q1y4Mmr = g1RNC8Zcmiq2YrIXMTlp5.textsize(WEPkgTHGs46itVBLn5fZb21QSIvC,font=NublS0p2UOf)
				if U2gRPo8ybwWH6JN5AcEZSz4xl: rOcgvhT9tJ6ZB -= n9OAiTUFBxRNC1Mc
				swZ6bkM4Om38pRLf5Fdl9haq2XxjAC = ZEjCORhl7WpnB+rOcgvhT9tJ6ZB
				g1RNC8Zcmiq2YrIXMTlp5.text((swZ6bkM4Om38pRLf5Fdl9haq2XxjAC,sM5e0ODwZup3WaPYgt9),WEPkgTHGs46itVBLn5fZb21QSIvC,font=NublS0p2UOf,fill=MhiBpkKdv5WnUySmuVxAaX7o3N0q9)
				if Z8eQjYFdi312lIV=='menu_item': g1RNC8Zcmiq2YrIXMTlp5.text((swZ6bkM4Om38pRLf5Fdl9haq2XxjAC+1,sM5e0ODwZup3WaPYgt9+1),WEPkgTHGs46itVBLn5fZb21QSIvC,font=NublS0p2UOf,fill=MhiBpkKdv5WnUySmuVxAaX7o3N0q9)
				if not U2gRPo8ybwWH6JN5AcEZSz4xl: rOcgvhT9tJ6ZB += n9OAiTUFBxRNC1Mc
				if sM5e0ODwZup3WaPYgt9>h2cAoegKQI6Lx4pqRJs9+kkl7iJe48XB95KZQdSpcO1wWM: break
	if Z8eQjYFdi312lIV=='menu_item':
		b68IuV3XKDFo05nsc1P = OC6VWLbi5m921UDPgRFyG4TvI.copy()
		XJ62UBRmIqFvfiNTQj.sleep(0.05)
		b68IuV3XKDFo05nsc1P.paste(t6YA9vPNyHk7eJ2LSxCaTjdbBmVzo,(0,0),mask=KDTfZNYqG98x)
	else: b68IuV3XKDFo05nsc1P = KDTfZNYqG98x
	if QBp28giCnayJzmZH6vYO: Zp45WHmewoCYNR = Zp45WHmewoCYNR.decode(YRvPKe2zMTDs8UCkr)
	try: b68IuV3XKDFo05nsc1P.save(Zp45WHmewoCYNR)
	except UnicodeError:
		if QBp28giCnayJzmZH6vYO:
			Zp45WHmewoCYNR = Zp45WHmewoCYNR.encode(YRvPKe2zMTDs8UCkr)
			b68IuV3XKDFo05nsc1P.save(Zp45WHmewoCYNR)
	return wkUj71oTODcXSKsHvYl8MLpbdf5ZC
def eMdmHuksbLGthDj3CSVf0OxgTa2RA(CPIqX58kncg,NublS0p2UOf,X0pBfL4Zd3vSo28YCV,pptNMriKh5FubfBP,Bp90fnIwMoY,FRS2bEjyKO7sr0Zq):
	HS038BcWVg1auIr6TJY7,y6yCrvbUBalipNI,aa1cViDdPAM6 = NdKhAS6MXVEORLTwob92pxlZ,0,15000
	X0pBfL4Zd3vSo28YCV = X0pBfL4Zd3vSo28YCV.replace('[COLOR ','[COLOR:::')
	IOFLdmxWYloNKS = Bp90fnIwMoY-pptNMriKh5FubfBP*2
	for sKA7bBW4mVr5E3L9O in X0pBfL4Zd3vSo28YCV.splitlines():
		y6yCrvbUBalipNI += FRS2bEjyKO7sr0Zq
		zz8S0w9aoCDTgy74nAY1dQilIq,N6NKPATLCJIf2d = 0,NdKhAS6MXVEORLTwob92pxlZ
		for GGrw1F8KVRfjtDyTEuvaze6P3LU in sKA7bBW4mVr5E3L9O.split(Vwgflszp4WRA93kx6hvdua21HX5cOb):
			WiQX6xk9PbS8RsGDdoTErNjAf = t5SdpGnOZa8hP3H(Vwgflszp4WRA93kx6hvdua21HX5cOb+GGrw1F8KVRfjtDyTEuvaze6P3LU)
			EVAOFj6isB3cxKY,ZfHU7GdFPbEOyRvj8iM1pmxutJl = CPIqX58kncg.textsize(WiQX6xk9PbS8RsGDdoTErNjAf,font=NublS0p2UOf)
			if zz8S0w9aoCDTgy74nAY1dQilIq+EVAOFj6isB3cxKY<IOFLdmxWYloNKS:
				if not N6NKPATLCJIf2d: N6NKPATLCJIf2d += GGrw1F8KVRfjtDyTEuvaze6P3LU
				else: N6NKPATLCJIf2d += Vwgflszp4WRA93kx6hvdua21HX5cOb+GGrw1F8KVRfjtDyTEuvaze6P3LU
				zz8S0w9aoCDTgy74nAY1dQilIq += EVAOFj6isB3cxKY
			else:
				if EVAOFj6isB3cxKY<IOFLdmxWYloNKS:
					N6NKPATLCJIf2d += '\n '+GGrw1F8KVRfjtDyTEuvaze6P3LU
					y6yCrvbUBalipNI += FRS2bEjyKO7sr0Zq
					zz8S0w9aoCDTgy74nAY1dQilIq = EVAOFj6isB3cxKY
				else:
					while EVAOFj6isB3cxKY>IOFLdmxWYloNKS:
						for zG37PsWCeVZ4aYtmkE2DTowqBF in range(1,len(Vwgflszp4WRA93kx6hvdua21HX5cOb+GGrw1F8KVRfjtDyTEuvaze6P3LU),1):
							g1sOb8cmXarznothw7fGv45W = Vwgflszp4WRA93kx6hvdua21HX5cOb+GGrw1F8KVRfjtDyTEuvaze6P3LU[:zG37PsWCeVZ4aYtmkE2DTowqBF]
							cFCtPRHdK2Js4BNaDObr0xXzYWw = GGrw1F8KVRfjtDyTEuvaze6P3LU[zG37PsWCeVZ4aYtmkE2DTowqBF:]
							TqLMnWhw7INgJPAb = t5SdpGnOZa8hP3H(g1sOb8cmXarznothw7fGv45W)
							nByHRmuAqhkEDZd0LK,ryxbqgeGc492 = CPIqX58kncg.textsize(TqLMnWhw7INgJPAb,font=NublS0p2UOf)
							if zz8S0w9aoCDTgy74nAY1dQilIq+nByHRmuAqhkEDZd0LK>IOFLdmxWYloNKS:
								ls67vyngi9duBpam3IrCWOtXQz = EVAOFj6isB3cxKY-nByHRmuAqhkEDZd0LK
								N6NKPATLCJIf2d += g1sOb8cmXarznothw7fGv45W+B6IrC7zEHlw1oaeWf
								y6yCrvbUBalipNI += FRS2bEjyKO7sr0Zq
								EVAOFj6isB3cxKY = ls67vyngi9duBpam3IrCWOtXQz
								if ls67vyngi9duBpam3IrCWOtXQz>IOFLdmxWYloNKS:
									zz8S0w9aoCDTgy74nAY1dQilIq = 0
									GGrw1F8KVRfjtDyTEuvaze6P3LU = cFCtPRHdK2Js4BNaDObr0xXzYWw
								else:
									zz8S0w9aoCDTgy74nAY1dQilIq = ls67vyngi9duBpam3IrCWOtXQz
									N6NKPATLCJIf2d += cFCtPRHdK2Js4BNaDObr0xXzYWw
								break
				if y6yCrvbUBalipNI>aa1cViDdPAM6: break
		HS038BcWVg1auIr6TJY7 += B6IrC7zEHlw1oaeWf+N6NKPATLCJIf2d
		if y6yCrvbUBalipNI>aa1cViDdPAM6: break
	HS038BcWVg1auIr6TJY7 = HS038BcWVg1auIr6TJY7[1:]
	HS038BcWVg1auIr6TJY7 = HS038BcWVg1auIr6TJY7.replace('[COLOR:::','[COLOR ')
	return HS038BcWVg1auIr6TJY7
def t5SdpGnOZa8hP3H(GGrw1F8KVRfjtDyTEuvaze6P3LU):
	if '[' in GGrw1F8KVRfjtDyTEuvaze6P3LU and ']' in GGrw1F8KVRfjtDyTEuvaze6P3LU:
		OOzgidYJaj3kl1LpF5cH = [kjd9LyNqQHMUevZiRI7OlBGF1h,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		OP97RLZafMDpuJz6EjI = YYqECUofyi7wFrW.findall('\[COLOR .*?\]',GGrw1F8KVRfjtDyTEuvaze6P3LU,YYqECUofyi7wFrW.DOTALL)
		CFnrlaUO8q9DLwkzGW4H1oPhN635uY = YYqECUofyi7wFrW.findall('\[COLOR:::.*?\]',GGrw1F8KVRfjtDyTEuvaze6P3LU,YYqECUofyi7wFrW.DOTALL)
		Jzsd7VaY4p26M3KAybfGgx5QOSrwqB = OOzgidYJaj3kl1LpF5cH+OP97RLZafMDpuJz6EjI+CFnrlaUO8q9DLwkzGW4H1oPhN635uY
		for oocADgqCr8G03XyYUFeks in Jzsd7VaY4p26M3KAybfGgx5QOSrwqB: GGrw1F8KVRfjtDyTEuvaze6P3LU = GGrw1F8KVRfjtDyTEuvaze6P3LU.replace(oocADgqCr8G03XyYUFeks,NdKhAS6MXVEORLTwob92pxlZ)
	return GGrw1F8KVRfjtDyTEuvaze6P3LU
def WX79lUztLm5PEOfTvxyJZMsbI4B(ui7N5YGR9KdslpEbQkVTwFqDgI):
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(B6IrC7zEHlw1oaeWf,'_sss__newline_')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RTL]','_sss__linertl_')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[LEFT]','_sss__lineleft_')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[RIGHT]','_sss__lineright_')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[CENTER]','_sss__linecenter_')
	ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace(kjd9LyNqQHMUevZiRI7OlBGF1h,'_sss__endcolor_')
	mmdK1aRQexJBZjnNsCXl = YYqECUofyi7wFrW.findall('\[COLOR (.*?)\]',ui7N5YGR9KdslpEbQkVTwFqDgI,YYqECUofyi7wFrW.DOTALL)
	for tJ0rAwsfPS36z2avmEB5nN71ycTYHk in mmdK1aRQexJBZjnNsCXl: ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.replace('[COLOR '+tJ0rAwsfPS36z2avmEB5nN71ycTYHk+']','_sss__newcolor'+tJ0rAwsfPS36z2avmEB5nN71ycTYHk+'_')
	return ui7N5YGR9KdslpEbQkVTwFqDgI
def LeIEtX7A6J(TwAEik98UYSsDMGJuFjON,JHKDFe6Am0ruz8=NdKhAS6MXVEORLTwob92pxlZ):
	if not JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Label')
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if TwAEik98UYSsDMGJuFjON: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace('[COLOR ',NdKhAS6MXVEORLTwob92pxlZ).replace(']',NdKhAS6MXVEORLTwob92pxlZ)
	else: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,NdKhAS6MXVEORLTwob92pxlZ).replace(Whef0cxB2iR93SC5IwUtk,NdKhAS6MXVEORLTwob92pxlZ).replace(kRJIE1KlPjZyAbQ73aHGFo24w6Ld9,NdKhAS6MXVEORLTwob92pxlZ).replace(lePmOJq9GZw1AD,NdKhAS6MXVEORLTwob92pxlZ)
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(iy0rIHuvaAgpbjRKnTQcJwLVs,NdKhAS6MXVEORLTwob92pxlZ).replace(MgDNZ1f34w,NdKhAS6MXVEORLTwob92pxlZ)
	h032V5HxLnqfKUXbkjBMlZt = YYqECUofyi7wFrW.findall('\d\d:\d\d ',JHKDFe6Am0ruz8,YYqECUofyi7wFrW.DOTALL)
	if h032V5HxLnqfKUXbkjBMlZt: JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.split(h032V5HxLnqfKUXbkjBMlZt[0],1)[1]
	if not JHKDFe6Am0ruz8: JHKDFe6Am0ruz8 = 'Main Menu'
	return JHKDFe6Am0ruz8
def UryVN9KOA5tuqi(Ibt19xdJGMVu34OyQRZAWTF):
	vvZ86Dpx3hQRHTKgEf2 = NdKhAS6MXVEORLTwob92pxlZ.join(zG37PsWCeVZ4aYtmkE2DTowqBF for zG37PsWCeVZ4aYtmkE2DTowqBF in Ibt19xdJGMVu34OyQRZAWTF if zG37PsWCeVZ4aYtmkE2DTowqBF not in '\/":*?<>|'+xDC7Nk52nKePfXhVRr)
	return vvZ86Dpx3hQRHTKgEf2
def CP2rKkbdyhaxvmuU89TOAec(nnkBNQrAK1SmzpfYD0j):
	eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ = YYqECUofyi7wFrW.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",nnkBNQrAK1SmzpfYD0j,YYqECUofyi7wFrW.S)
	if eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ:
		dbK2XvJmiyBeOIcY,ge1UTmn40pRN6 = eVBRFrnCc6g21pSaDPMxvdAfQyz0IZ[0]
		dbK2XvJmiyBeOIcY = YYqECUofyi7wFrW.findall("=[\r\n\s\t]+'(.*?)';", dbK2XvJmiyBeOIcY, YYqECUofyi7wFrW.S)[0]
		if dbK2XvJmiyBeOIcY and ge1UTmn40pRN6:
			wbKdUqgIAFRVn71C6 = dbK2XvJmiyBeOIcY.replace("'",NdKhAS6MXVEORLTwob92pxlZ).replace("+",NdKhAS6MXVEORLTwob92pxlZ).replace("\n",NdKhAS6MXVEORLTwob92pxlZ).replace("\r",NdKhAS6MXVEORLTwob92pxlZ)
			L5L0qRQOP14C8cYKg2jzdmx = wbKdUqgIAFRVn71C6.split('.')
			nnkBNQrAK1SmzpfYD0j = NdKhAS6MXVEORLTwob92pxlZ
			for ZdWyhiM8mcAPj in L5L0qRQOP14C8cYKg2jzdmx:
				DYBztJQA5f4ynFTRepK2o = NHsYdVBpXn.b64decode(ZdWyhiM8mcAPj+'==').decode(YRvPKe2zMTDs8UCkr)
				IVRuAy8EFkwK2TdZXPH4blGgO9t5r = YYqECUofyi7wFrW.findall('\d+', DYBztJQA5f4ynFTRepK2o, YYqECUofyi7wFrW.S)
				if IVRuAy8EFkwK2TdZXPH4blGgO9t5r:
					nZJsXKy9Ac2LkDu086RT = int(IVRuAy8EFkwK2TdZXPH4blGgO9t5r[0])
					nZJsXKy9Ac2LkDu086RT += int(ge1UTmn40pRN6)
					nnkBNQrAK1SmzpfYD0j = nnkBNQrAK1SmzpfYD0j + chr(nZJsXKy9Ac2LkDu086RT)
			if J92gCnbGWidQV70lBteTwU6D8uyzL: nnkBNQrAK1SmzpfYD0j = nnkBNQrAK1SmzpfYD0j.encode('iso-8859-1').decode(YRvPKe2zMTDs8UCkr)
	return nnkBNQrAK1SmzpfYD0j
def cJaAB4uQyp(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved=NdKhAS6MXVEORLTwob92pxlZ,UPu1AiwY6GOH5Xyk97vfSC2Jq=NdKhAS6MXVEORLTwob92pxlZ):
	if '::' in fiuheaxH14ZML0: fiuheaxH14ZML0,GY9jgon6yhP0IvtCBEJu3 = fiuheaxH14ZML0.split('::')
	else: fiuheaxH14ZML0,GY9jgon6yhP0IvtCBEJu3 = fiuheaxH14ZML0,''
	BfjcMoqOsmdUvZVCHWIyQKi,ekC5B0cLVoOYiQJbKv43sTMWXtn,gWPvSYDsxc,thQS25UGHN9I0ywmbvWM4gCrOVp = ubz0qK9aRUNEQj6HrvF2OpCGLS47(ZZT6GLaHQ1)
	try: No9g1hT57FOnGAPIcCyVqz3M = JoWX5If80G.copy()
	except: No9g1hT57FOnGAPIcCyVqz3M = JoWX5If80G
	KiBecyPA5WSGXCQu38h1F4n = fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,dJC476xoE1ecpm0,No9g1hT57FOnGAPIcCyVqz3M,FBZQcNT8PedGlMC
	if CSHxmGj6O01AWEXVoRcK<0:
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'OPENURL_REQUESTS',KiBecyPA5WSGXCQu38h1F4n)
		CSHxmGj6O01AWEXVoRcK = -CSHxmGj6O01AWEXVoRcK
	if CSHxmGj6O01AWEXVoRcK>0:
		MmDs0fWOCc3Bg = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'response','OPENURL_REQUESTS',KiBecyPA5WSGXCQu38h1F4n)
		if MmDs0fWOCc3Bg.succeeded:
			hhM2Wn1045PDsl6p8VLA7vIN('REQUESTS  READ_CACHE',BfjcMoqOsmdUvZVCHWIyQKi,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI,fiuheaxH14ZML0)
			return MmDs0fWOCc3Bg
	if GY9jgon6yhP0IvtCBEJu3=='SCRAPERS': MmDs0fWOCc3Bg = mHdRh8KCp01I45v(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI)
	else: MmDs0fWOCc3Bg = W1nrEA8Xg3(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved,UPu1AiwY6GOH5Xyk97vfSC2Jq)
	if MmDs0fWOCc3Bg.succeeded:
		if 'CIMANOW' in xmezOWMyhSXRGHlEk2JnsI: MmDs0fWOCc3Bg.content = CP2rKkbdyhaxvmuU89TOAec(MmDs0fWOCc3Bg.content)
		if MmDs0fWOCc3Bg.scrape: CSHxmGj6O01AWEXVoRcK = OewIv05xGhKQpFf
		if CSHxmGj6O01AWEXVoRcK and MmDs0fWOCc3Bg.content: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'OPENURL_REQUESTS',KiBecyPA5WSGXCQu38h1F4n,MmDs0fWOCc3Bg,CSHxmGj6O01AWEXVoRcK)
	return MmDs0fWOCc3Bg
def ZZDo23tRb0mpfcsMj6(fiuheaxH14ZML0,ZZT6GLaHQ1,data,headers,allow_redirects,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved,UPu1AiwY6GOH5Xyk97vfSC2Jq):
	if showDialogs==NdKhAS6MXVEORLTwob92pxlZ: wmDAkp0iLt = k6apiPAlLKM1ed8J42RjHh0o if OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX==NdKhAS6MXVEORLTwob92pxlZ else OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX
	else: wmDAkp0iLt = k6apiPAlLKM1ed8J42RjHh0o if showDialogs else f4vncKMRlXG9s
	if UPu1AiwY6GOH5Xyk97vfSC2Jq==NdKhAS6MXVEORLTwob92pxlZ: GGj9lzFA4RJLsig71pMwrY6Tk = k6apiPAlLKM1ed8J42RjHh0o if OMNiY8joQx.ALLOW_PROXY_FIX==NdKhAS6MXVEORLTwob92pxlZ else OMNiY8joQx.ALLOW_PROXY_FIX
	else: GGj9lzFA4RJLsig71pMwrY6Tk = k6apiPAlLKM1ed8J42RjHh0o if UPu1AiwY6GOH5Xyk97vfSC2Jq else f4vncKMRlXG9s
	if aY7nZxP3iCWE5s6DMJOBUv8Ved==NdKhAS6MXVEORLTwob92pxlZ: O5Q2j3Wi1JSZurkYbI0 = k6apiPAlLKM1ed8J42RjHh0o if OMNiY8joQx.ALLOW_DNS_FIX==NdKhAS6MXVEORLTwob92pxlZ else OMNiY8joQx.ALLOW_DNS_FIX
	else: O5Q2j3Wi1JSZurkYbI0 = k6apiPAlLKM1ed8J42RjHh0o if aY7nZxP3iCWE5s6DMJOBUv8Ved else f4vncKMRlXG9s
	if allow_redirects==NdKhAS6MXVEORLTwob92pxlZ: QTJoMqgAIvF8OzRVn = k6apiPAlLKM1ed8J42RjHh0o
	else: QTJoMqgAIvF8OzRVn = k6apiPAlLKM1ed8J42RjHh0o if allow_redirects else f4vncKMRlXG9s
	omrd89nv0PGKFpL3TxfAXt = {} if headers==NdKhAS6MXVEORLTwob92pxlZ else headers
	OzUD8iTmGp15Sn9VINMHq = {} if data==NdKhAS6MXVEORLTwob92pxlZ else data
	if xmezOWMyhSXRGHlEk2JnsI=='SERVICES-INSTALL_OLD_RELEASE-1st': omrd89nv0PGKFpL3TxfAXt = {}
	else:
		kkVoecYW2jStRF = list(omrd89nv0PGKFpL3TxfAXt.keys())
		if 'Referer' not in kkVoecYW2jStRF: omrd89nv0PGKFpL3TxfAXt['Referer'] = 'http'
		if 'User-Agent' not in kkVoecYW2jStRF: omrd89nv0PGKFpL3TxfAXt['User-Agent'] = kkCjlxiynwT34GVFc(k6apiPAlLKM1ed8J42RjHh0o)
	return fiuheaxH14ZML0,ZZT6GLaHQ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,O5Q2j3Wi1JSZurkYbI0,GGj9lzFA4RJLsig71pMwrY6Tk
def W1nrEA8Xg3(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved=NdKhAS6MXVEORLTwob92pxlZ,UPu1AiwY6GOH5Xyk97vfSC2Jq=NdKhAS6MXVEORLTwob92pxlZ):
	e3suhJiZytU7c = ZZDo23tRb0mpfcsMj6(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved,UPu1AiwY6GOH5Xyk97vfSC2Jq)
	fiuheaxH14ZML0,ZZT6GLaHQ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,O5Q2j3Wi1JSZurkYbI0,GGj9lzFA4RJLsig71pMwrY6Tk = e3suhJiZytU7c
	BfjcMoqOsmdUvZVCHWIyQKi,ekC5B0cLVoOYiQJbKv43sTMWXtn,gWPvSYDsxc,thQS25UGHN9I0ywmbvWM4gCrOVp = ubz0qK9aRUNEQj6HrvF2OpCGLS47(ZZT6GLaHQ1)
	fbEu6LMqO9iKR5jaG0tIe = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.dns')
	gxDTdfjnIKspHLWz9a12FmBke = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.usedns')
	nFCAMOipWNJ3fc8BRev1xyU = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.useproxy')
	S4EOzTvfQ317abKA5kYZGx = ['scrapeops','scraperapi','scrapingant','scrapingrobot','scrapeup','scrape.do']
	ssvCJXKpVgaULDhrGw2xmZ4 = k6apiPAlLKM1ed8J42RjHh0o if any(K6KbZDHncNizQgl1fr59XV0 in ZZT6GLaHQ1 for K6KbZDHncNizQgl1fr59XV0 in S4EOzTvfQ317abKA5kYZGx) else f4vncKMRlXG9s
	if '&url=' in BfjcMoqOsmdUvZVCHWIyQKi and ssvCJXKpVgaULDhrGw2xmZ4: Ly6gqD8jB5I9tp2MY3ncEsJ = BfjcMoqOsmdUvZVCHWIyQKi.rsplit('&url=',1)[llxMLe4gobHhsj1WGvd7qmIU]
	else: Ly6gqD8jB5I9tp2MY3ncEsJ = NdKhAS6MXVEORLTwob92pxlZ
	hhtgHR5ivXAL9okpjGPEn8K = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON']
	f1kUIA6ndptORqMcaZusGVw3 = BfjcMoqOsmdUvZVCHWIyQKi in hhtgHR5ivXAL9okpjGPEn8K or Ly6gqD8jB5I9tp2MY3ncEsJ in hhtgHR5ivXAL9okpjGPEn8K
	PqZAgIysiukFjtTKQn6pWowYDHB = xKp3jkIvM09AZ4euXa87i5TVtfUD['REPOS']
	tAOCzrTnyMbuRjm8lZ7NUYxhef0 = BfjcMoqOsmdUvZVCHWIyQKi in PqZAgIysiukFjtTKQn6pWowYDHB or Ly6gqD8jB5I9tp2MY3ncEsJ in PqZAgIysiukFjtTKQn6pWowYDHB
	HlyLbmTSOgG = f1kUIA6ndptORqMcaZusGVw3 or tAOCzrTnyMbuRjm8lZ7NUYxhef0
	Q9HovK2zhCrYPS8 = f4vncKMRlXG9s
	PNflraOcX07mvz8SEQ = k6apiPAlLKM1ed8J42RjHh0o
	LLgTAcZKsOznYk97r06pvMFeyEmQi = ekC5B0cLVoOYiQJbKv43sTMWXtn==None and gWPvSYDsxc==None and not ssvCJXKpVgaULDhrGw2xmZ4
	if LLgTAcZKsOznYk97r06pvMFeyEmQi and HlyLbmTSOgG:
		if f1kUIA6ndptORqMcaZusGVw3:
			f53YIXVCTWcHuyewon = hhtgHR5ivXAL9okpjGPEn8K.index(BfjcMoqOsmdUvZVCHWIyQKi)
			Qd8z243rYFxGsMjaK = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON_BKP1'][f53YIXVCTWcHuyewon]
			vE7Sygzt2ZwxCfY3 = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON_BKP2'][f53YIXVCTWcHuyewon]
			ExRLHomhKq4uw3OTkvVcbFNAf9 = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON_BKP3'][f53YIXVCTWcHuyewon]
			J2bWNij3HmU1R9P5ItnxXBd7pSZA = yy0zIog9KDlfOQ[f53YIXVCTWcHuyewon]
			if J2bWNij3HmU1R9P5ItnxXBd7pSZA=='LISTPLAY': O5Q2j3Wi1JSZurkYbI0,GGj9lzFA4RJLsig71pMwrY6Tk,PNflraOcX07mvz8SEQ = f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s
			elif J2bWNij3HmU1R9P5ItnxXBd7pSZA=='CAPTCHA': Q9HovK2zhCrYPS8 = k6apiPAlLKM1ed8J42RjHh0o
		elif tAOCzrTnyMbuRjm8lZ7NUYxhef0:
			f53YIXVCTWcHuyewon = PqZAgIysiukFjtTKQn6pWowYDHB.index(BfjcMoqOsmdUvZVCHWIyQKi)
			Qd8z243rYFxGsMjaK = xKp3jkIvM09AZ4euXa87i5TVtfUD['REPOS_BKP1'][f53YIXVCTWcHuyewon]
			vE7Sygzt2ZwxCfY3 = xKp3jkIvM09AZ4euXa87i5TVtfUD['REPOS_BKP2'][f53YIXVCTWcHuyewon]
			ExRLHomhKq4uw3OTkvVcbFNAf9 = xKp3jkIvM09AZ4euXa87i5TVtfUD['REPOS_BKP3'][f53YIXVCTWcHuyewon]
			J2bWNij3HmU1R9P5ItnxXBd7pSZA = EIVDQBT4RprwKAlaHd5t1LcgemqP[f53YIXVCTWcHuyewon]
	if gWPvSYDsxc==NdKhAS6MXVEORLTwob92pxlZ: gWPvSYDsxc = fbEu6LMqO9iKR5jaG0tIe
	elif gWPvSYDsxc==None and gxDTdfjnIKspHLWz9a12FmBke in ['AUTO','ACCEPTED'] and O5Q2j3Wi1JSZurkYbI0: gWPvSYDsxc = fbEu6LMqO9iKR5jaG0tIe
	if f1kUIA6ndptORqMcaZusGVw3 or tAOCzrTnyMbuRjm8lZ7NUYxhef0: t7GucK3fAw = 15
	elif ssvCJXKpVgaULDhrGw2xmZ4: t7GucK3fAw = 60
	elif xmezOWMyhSXRGHlEk2JnsI in JSX5Fx4zOwR: t7GucK3fAw = 10
	elif xmezOWMyhSXRGHlEk2JnsI=='LIBRARY-REVERSO_TRANSLATE-1st': t7GucK3fAw = 20
	elif xmezOWMyhSXRGHlEk2JnsI=='LIBRARY-GOOGLE_TRANSLATE-1st': t7GucK3fAw = 20
	elif 'RESOLVERS-AKWAM' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 70
	elif 'SHOFHA' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 75
	elif 'CIMA4U' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 25
	elif 'AHWAK' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 20
	elif 'CIMALIGHT' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 20
	elif 'CIMACLUBWORK' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 30
	elif 'AKOAM' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 25
	elif 'AKWAM' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 30
	elif 'FASELHD1' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 20
	elif 'EGYBEST3' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 60
	elif 'HALACIMA' in xmezOWMyhSXRGHlEk2JnsI: t7GucK3fAw = 40
	else: t7GucK3fAw = 15
	BxLklT9Cudsra3t5GZv0AUR8c = (ekC5B0cLVoOYiQJbKv43sTMWXtn!=None)
	bVq1tuBUCvSworIsnXexKm8T3G2 = (gWPvSYDsxc!=None and gxDTdfjnIKspHLWz9a12FmBke!='STOP')
	if BxLklT9Cudsra3t5GZv0AUR8c and not ssvCJXKpVgaULDhrGw2xmZ4: kkDz5sdaPteM('تفعيل بروكسي رقم',ekC5B0cLVoOYiQJbKv43sTMWXtn)
	elif bVq1tuBUCvSworIsnXexKm8T3G2: kkDz5sdaPteM('تفعيل DNS رقم',gWPvSYDsxc)
	if BxLklT9Cudsra3t5GZv0AUR8c:
		fV4v8socx0KTtmgbZFBDjap = {"http":ekC5B0cLVoOYiQJbKv43sTMWXtn,"https":ekC5B0cLVoOYiQJbKv43sTMWXtn}
		XGwz5oLiVxnWq8cJNRH9g = ekC5B0cLVoOYiQJbKv43sTMWXtn
	else: fV4v8socx0KTtmgbZFBDjap,XGwz5oLiVxnWq8cJNRH9g = {},NdKhAS6MXVEORLTwob92pxlZ
	if bVq1tuBUCvSworIsnXexKm8T3G2:
		import urllib3.util.connection as r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ
		CXEbBhLqfU30jNFAQswH7pPcG = bLOpXQMenuTIhZ95dF8f3(r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ,fbEu6LMqO9iKR5jaG0tIe)
	j9xDtbs3kwWJr7ypNz,ueCnDqN7ymJKgjcFRvA,VjFRLekX4tfA,oofdj9MRmtL3,zTcDWYCo7j03QbOryvPBn,verify = QTJoMqgAIvF8OzRVn,xmezOWMyhSXRGHlEk2JnsI,fiuheaxH14ZML0,f4vncKMRlXG9s,f4vncKMRlXG9s,thQS25UGHN9I0ywmbvWM4gCrOVp
	if Q9HovK2zhCrYPS8: zTcDWYCo7j03QbOryvPBn = k6apiPAlLKM1ed8J42RjHh0o
	if HlyLbmTSOgG or QTJoMqgAIvF8OzRVn: j9xDtbs3kwWJr7ypNz = f4vncKMRlXG9s
	if f1kUIA6ndptORqMcaZusGVw3: VjFRLekX4tfA = 'POST'
	e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = -llxMLe4gobHhsj1WGvd7qmIU,'Unknown Error'
	qphErSToy02I3A4ekMCs5aJg1OHWQ = f4vncKMRlXG9s
	if not OMNiY8joQx.FORWARDS_HOSTNAMES: OMNiY8joQx.FORWARDS_HOSTNAMES = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'dict','MISC_TEMP','FORWARDS')
	gsLBFXZKJVEYcbu = []
	while BfjcMoqOsmdUvZVCHWIyQKi not in gsLBFXZKJVEYcbu and BfjcMoqOsmdUvZVCHWIyQKi in list(OMNiY8joQx.FORWARDS_HOSTNAMES.keys()):
		gsLBFXZKJVEYcbu.append(BfjcMoqOsmdUvZVCHWIyQKi)
		BfjcMoqOsmdUvZVCHWIyQKi = OMNiY8joQx.FORWARDS_HOSTNAMES[BfjcMoqOsmdUvZVCHWIyQKi]
	import requests as HnCNqGOWBc0tZViv
	for XW2Opt4RQsVihunCylz6j in range(9):
		X58RDonOy7HSW2acg6 = k6apiPAlLKM1ed8J42RjHh0o
		PsKJk8XRHAQM = f4vncKMRlXG9s
		try:
			if XW2Opt4RQsVihunCylz6j: ueCnDqN7ymJKgjcFRvA = 'LIBRARY-OPENURL_REQUESTS-1st'
			if ssvCJXKpVgaULDhrGw2xmZ4 or not BxLklT9Cudsra3t5GZv0AUR8c: hhM2Wn1045PDsl6p8VLA7vIN('REQUESTS\tOPEN_URL',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,ueCnDqN7ymJKgjcFRvA,VjFRLekX4tfA)
			try: MmDs0fWOCc3Bg.close()
			except: pass
			Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi
			MmDs0fWOCc3Bg = HnCNqGOWBc0tZViv.request(VjFRLekX4tfA,BfjcMoqOsmdUvZVCHWIyQKi,data=OzUD8iTmGp15Sn9VINMHq,headers=omrd89nv0PGKFpL3TxfAXt,verify=verify,allow_redirects=j9xDtbs3kwWJr7ypNz,timeout=t7GucK3fAw,proxies=fV4v8socx0KTtmgbZFBDjap)
			if 300<=MmDs0fWOCc3Bg.status_code<=399:
				if not oofdj9MRmtL3:
					NH082lOCUX = list(MmDs0fWOCc3Bg.headers.keys())
					if 'Location' in NH082lOCUX: BfjcMoqOsmdUvZVCHWIyQKi = MmDs0fWOCc3Bg.headers['Location']
					elif 'location' in NH082lOCUX: BfjcMoqOsmdUvZVCHWIyQKi = MmDs0fWOCc3Bg.headers['location']
					else: oofdj9MRmtL3 = k6apiPAlLKM1ed8J42RjHh0o
					if not oofdj9MRmtL3: BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.encode('latin-1','ignore').decode(YRvPKe2zMTDs8UCkr,'ignore')
					if HlyLbmTSOgG and MmDs0fWOCc3Bg.status_code==307:
						j9xDtbs3kwWJr7ypNz = QTJoMqgAIvF8OzRVn
						VjFRLekX4tfA = fiuheaxH14ZML0
						oofdj9MRmtL3 = k6apiPAlLKM1ed8J42RjHh0o
						IDOVHYfi8w
				if not oofdj9MRmtL3 or QTJoMqgAIvF8OzRVn:
					if 'http' not in BfjcMoqOsmdUvZVCHWIyQKi:
						XZiY3U1MTqN5HtW0co = msbTrJW03xuvA(Afey3cL4ojzg,'url')
						BfjcMoqOsmdUvZVCHWIyQKi = XZiY3U1MTqN5HtW0co+'/'+BfjcMoqOsmdUvZVCHWIyQKi.lstrip('/')
				if BfjcMoqOsmdUvZVCHWIyQKi!=Afey3cL4ojzg:
					OMNiY8joQx.FORWARDS_HOSTNAMES[Afey3cL4ojzg] = BfjcMoqOsmdUvZVCHWIyQKi
					qphErSToy02I3A4ekMCs5aJg1OHWQ = k6apiPAlLKM1ed8J42RjHh0o
				if not oofdj9MRmtL3 and QTJoMqgAIvF8OzRVn and not atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(BfjcMoqOsmdUvZVCHWIyQKi): IDOVHYfi8w
			elif 550<=MmDs0fWOCc3Bg.status_code<=599:
				MmDs0fWOCc3Bg.reason = MmDs0fWOCc3Bg.content
				zTcDWYCo7j03QbOryvPBn = k6apiPAlLKM1ed8J42RjHh0o
			Afey3cL4ojzg = MmDs0fWOCc3Bg.url
			e5DznyEKA9hMcN3jX4Ou271gptkr = MmDs0fWOCc3Bg.status_code
			wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = MmDs0fWOCc3Bg.reason
			MmDs0fWOCc3Bg.raise_for_status()
			PsKJk8XRHAQM = k6apiPAlLKM1ed8J42RjHh0o
		except HnCNqGOWBc0tZViv.exceptions.HTTPError as BBNRYIkquhmv2w5GasF:
			pass
		except HnCNqGOWBc0tZViv.exceptions.Timeout as BBNRYIkquhmv2w5GasF:
			if QBp28giCnayJzmZH6vYO: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = str(BBNRYIkquhmv2w5GasF.message).split(': ')[llxMLe4gobHhsj1WGvd7qmIU]
			else: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = str(BBNRYIkquhmv2w5GasF).split(': ')[llxMLe4gobHhsj1WGvd7qmIU]
		except HnCNqGOWBc0tZViv.exceptions.ConnectionError as BBNRYIkquhmv2w5GasF:
			try: XvUfhH2qm6TMaw5bl9WVO1B = BBNRYIkquhmv2w5GasF.message[e8XhbyuzvjYkIsJUtB5w]
			except: XvUfhH2qm6TMaw5bl9WVO1B = str(BBNRYIkquhmv2w5GasF)
			rz7SNWoa1wd6v0XMGH = YYqECUofyi7wFrW.findall("\[Errno (\d+)\] (.*?)'",XvUfhH2qm6TMaw5bl9WVO1B)
			if not rz7SNWoa1wd6v0XMGH: rz7SNWoa1wd6v0XMGH = YYqECUofyi7wFrW.findall(", error\((\d+), '(.*?)'",XvUfhH2qm6TMaw5bl9WVO1B)
			if not rz7SNWoa1wd6v0XMGH:
				qJIStnU3dE58QZcF67Hbhugjk = YYqECUofyi7wFrW.findall(": (.*?):.*?(\d+):",XvUfhH2qm6TMaw5bl9WVO1B)
				if qJIStnU3dE58QZcF67Hbhugjk: rz7SNWoa1wd6v0XMGH = [qJIStnU3dE58QZcF67Hbhugjk[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU],qJIStnU3dE58QZcF67Hbhugjk[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w]]
			if not rz7SNWoa1wd6v0XMGH: rz7SNWoa1wd6v0XMGH = YYqECUofyi7wFrW.findall(":(\d+): (.*?)'",XvUfhH2qm6TMaw5bl9WVO1B)
			if not rz7SNWoa1wd6v0XMGH: rz7SNWoa1wd6v0XMGH = YYqECUofyi7wFrW.findall(" (\d+)] (.*?)'",XvUfhH2qm6TMaw5bl9WVO1B)
			try: e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = rz7SNWoa1wd6v0XMGH[e8XhbyuzvjYkIsJUtB5w]
			except: e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = -2,XvUfhH2qm6TMaw5bl9WVO1B
		except HnCNqGOWBc0tZViv.exceptions.RequestException as BBNRYIkquhmv2w5GasF:
			if QBp28giCnayJzmZH6vYO: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = BBNRYIkquhmv2w5GasF.message
			else: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = str(BBNRYIkquhmv2w5GasF)
		except:
			X58RDonOy7HSW2acg6 = f4vncKMRlXG9s
			try: e5DznyEKA9hMcN3jX4Ou271gptkr = MmDs0fWOCc3Bg.status_code
			except: pass
			try: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = MmDs0fWOCc3Bg.reason
			except: pass
		wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = str(wNiDIHWX0BOk7ezTgfPx1RtVMvuKy)
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,'OPENURL_REQUESTS\tRESPONSE  Code: [ '+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+' ]   Reason: [ '+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy+' ]   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
		if LLgTAcZKsOznYk97r06pvMFeyEmQi and HlyLbmTSOgG and X58RDonOy7HSW2acg6 and not zTcDWYCo7j03QbOryvPBn and e5DznyEKA9hMcN3jX4Ou271gptkr!=200:
			if BfjcMoqOsmdUvZVCHWIyQKi not in [Qd8z243rYFxGsMjaK,vE7Sygzt2ZwxCfY3,ExRLHomhKq4uw3OTkvVcbFNAf9]: BfjcMoqOsmdUvZVCHWIyQKi,zTcDWYCo7j03QbOryvPBn = Qd8z243rYFxGsMjaK,f4vncKMRlXG9s
			elif BfjcMoqOsmdUvZVCHWIyQKi==Qd8z243rYFxGsMjaK: BfjcMoqOsmdUvZVCHWIyQKi,zTcDWYCo7j03QbOryvPBn = vE7Sygzt2ZwxCfY3,f4vncKMRlXG9s
			elif BfjcMoqOsmdUvZVCHWIyQKi==vE7Sygzt2ZwxCfY3: BfjcMoqOsmdUvZVCHWIyQKi,zTcDWYCo7j03QbOryvPBn = ExRLHomhKq4uw3OTkvVcbFNAf9,k6apiPAlLKM1ed8J42RjHh0o
			continue
		if X58RDonOy7HSW2acg6: break
	if not PsKJk8XRHAQM and gsLBFXZKJVEYcbu:
		for url in gsLBFXZKJVEYcbu:
			if url in list(OMNiY8joQx.FORWARDS_HOSTNAMES.keys()):
				del OMNiY8joQx.FORWARDS_HOSTNAMES[url]
				qphErSToy02I3A4ekMCs5aJg1OHWQ = k6apiPAlLKM1ed8J42RjHh0o
	if qphErSToy02I3A4ekMCs5aJg1OHWQ:
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'MISC_TEMP','FORWARDS',OMNiY8joQx.FORWARDS_HOSTNAMES,OewIv05xGhKQpFf)
		OMNiY8joQx.FORWARDS_HOSTNAMES = {}
	if gWPvSYDsxc!=None and gxDTdfjnIKspHLWz9a12FmBke!='STOP': r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ.create_connection = CXEbBhLqfU30jNFAQswH7pPcG
	if gxDTdfjnIKspHLWz9a12FmBke=='ALWAYS' and O5Q2j3Wi1JSZurkYbI0: gWPvSYDsxc = None
	if not PsKJk8XRHAQM and ekC5B0cLVoOYiQJbKv43sTMWXtn==None and xmezOWMyhSXRGHlEk2JnsI not in JSX5Fx4zOwR:
		ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
		if ihuUeAVfaSbXMNn!='NoneType: None\n': hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
	HYfNLiDK3yRF7 = CDtdAcPSKah()
	if ssvCJXKpVgaULDhrGw2xmZ4: Afey3cL4ojzg = Ly6gqD8jB5I9tp2MY3ncEsJ
	if not Afey3cL4ojzg: Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi
	HYfNLiDK3yRF7.url = Afey3cL4ojzg
	HYfNLiDK3yRF7.scrape = ssvCJXKpVgaULDhrGw2xmZ4
	try: hoBRaHZ7W9dK = MmDs0fWOCc3Bg.content
	except: hoBRaHZ7W9dK = NdKhAS6MXVEORLTwob92pxlZ
	try: UNZ5JYoADPigf8Cn4FbBch = MmDs0fWOCc3Bg.headers
	except: UNZ5JYoADPigf8Cn4FbBch = {}
	try: NeqM02nFd75hizYsKxWJrODUgPXpa = MmDs0fWOCc3Bg.cookies.get_dict()
	except: NeqM02nFd75hizYsKxWJrODUgPXpa = {}
	try: MmDs0fWOCc3Bg.close()
	except: pass
	if J92gCnbGWidQV70lBteTwU6D8uyzL:
		try: hoBRaHZ7W9dK = hoBRaHZ7W9dK.decode(YRvPKe2zMTDs8UCkr)
		except: pass
	e5DznyEKA9hMcN3jX4Ou271gptkr = int(e5DznyEKA9hMcN3jX4Ou271gptkr)
	HYfNLiDK3yRF7.code = e5DznyEKA9hMcN3jX4Ou271gptkr
	HYfNLiDK3yRF7.reason = wNiDIHWX0BOk7ezTgfPx1RtVMvuKy
	HYfNLiDK3yRF7.content = hoBRaHZ7W9dK
	HYfNLiDK3yRF7.headers = UNZ5JYoADPigf8Cn4FbBch
	HYfNLiDK3yRF7.cookies = NeqM02nFd75hizYsKxWJrODUgPXpa
	HYfNLiDK3yRF7.succeeded = PsKJk8XRHAQM
	HYfNLiDK3yRF7.scrapernumber = NdKhAS6MXVEORLTwob92pxlZ
	HYfNLiDK3yRF7.scraperserver = NdKhAS6MXVEORLTwob92pxlZ
	HYfNLiDK3yRF7.scraperurl = NdKhAS6MXVEORLTwob92pxlZ
	if QBp28giCnayJzmZH6vYO or isinstance(HYfNLiDK3yRF7.content,str): xsKgPGOHWlT93YCSQkpvo = HYfNLiDK3yRF7.content.lower()
	else: xsKgPGOHWlT93YCSQkpvo = NdKhAS6MXVEORLTwob92pxlZ
	O7TLdNZjpW = ('cloudflare' in xsKgPGOHWlT93YCSQkpvo or 'google' in xsKgPGOHWlT93YCSQkpvo) and xsKgPGOHWlT93YCSQkpvo.count('recaptcha')>2 and 'FASELHD1' not in xmezOWMyhSXRGHlEk2JnsI and 'recaptcha-token' not in xsKgPGOHWlT93YCSQkpvo and not ssvCJXKpVgaULDhrGw2xmZ4
	if e5DznyEKA9hMcN3jX4Ou271gptkr==200 and O7TLdNZjpW: HYfNLiDK3yRF7.succeeded = f4vncKMRlXG9s
	if HYfNLiDK3yRF7.succeeded and LLgTAcZKsOznYk97r06pvMFeyEmQi and HlyLbmTSOgG:
		CaSFdiZ0mT = 'CAPTCHA'+OzUD8iTmGp15Sn9VINMHq['job'].upper().replace('GET',NdKhAS6MXVEORLTwob92pxlZ) if Q9HovK2zhCrYPS8 else J2bWNij3HmU1R9P5ItnxXBd7pSZA
		c2JF3xijoWuSgAVvLaRz(CaSFdiZ0mT)
	if not HYfNLiDK3yRF7.succeeded and LLgTAcZKsOznYk97r06pvMFeyEmQi:
		K0TXmdZiEoGayp7L6 = ('cloudflare' in xsKgPGOHWlT93YCSQkpvo and 'ray id: ' in xsKgPGOHWlT93YCSQkpvo)
		mJ6iS0BAe8dTROL2nP = ('5 sec' in xsKgPGOHWlT93YCSQkpvo and 'browser' in xsKgPGOHWlT93YCSQkpvo)
		EEkpH9eqthTNnWjM4 = (e5DznyEKA9hMcN3jX4Ou271gptkr in [403] and 'error code: 1020' in xsKgPGOHWlT93YCSQkpvo)
		BGw7HzLackWmqV2rxO3oPf59bN4 = ('_cf_chl_' in xsKgPGOHWlT93YCSQkpvo and 'challenge-' in xsKgPGOHWlT93YCSQkpvo)
		if   O7TLdNZjpW: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = 'Blocked by recaptcha'
		elif K0TXmdZiEoGayp7L6: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = 'Blocked by cloudflare'
		elif mJ6iS0BAe8dTROL2nP: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = 'Blocked by 5 seconds browser check'
		elif EEkpH9eqthTNnWjM4: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = 'Blocked by cloudflare access denied'
		elif BGw7HzLackWmqV2rxO3oPf59bN4: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = 'Blocked by cloudflare security check'
		else: wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = str(wNiDIHWX0BOk7ezTgfPx1RtVMvuKy)
		if xmezOWMyhSXRGHlEk2JnsI in WTSe9tBI8iEX1Z60MaGsqnL4xyV: pass
		elif xmezOWMyhSXRGHlEk2JnsI in JSX5Fx4zOwR:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'  Direct connection failed   Code: [ '+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+' ]   Reason: [ '+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy+' ]   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+BfjcMoqOsmdUvZVCHWIyQKi+' ]')
		else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Direct connection failed   Code: [ '+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+' ]   Reason: [ '+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy+' ]   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+BfjcMoqOsmdUvZVCHWIyQKi+' ]')
		TPDhOSYcNy0Ugz9arsVpn = Ly6gqD8jB5I9tp2MY3ncEsJ if ssvCJXKpVgaULDhrGw2xmZ4 else OOFEmwq2GkTz93WXy1Nj(BfjcMoqOsmdUvZVCHWIyQKi)
		if QBp28giCnayJzmZH6vYO and isinstance(TPDhOSYcNy0Ugz9arsVpn,unicode): TPDhOSYcNy0Ugz9arsVpn = TPDhOSYcNy0Ugz9arsVpn.encode(YRvPKe2zMTDs8UCkr)
		if HlyLbmTSOgG: TPDhOSYcNy0Ugz9arsVpn = TPDhOSYcNy0Ugz9arsVpn.split('/')[-llxMLe4gobHhsj1WGvd7qmIU]
		KDZYCzhrs4U89XGwHkWpbnvade = str(wNiDIHWX0BOk7ezTgfPx1RtVMvuKy)+'\n( '+TPDhOSYcNy0Ugz9arsVpn+' )'
		if e5DznyEKA9hMcN3jX4Ou271gptkr in [-llxMLe4gobHhsj1WGvd7qmIU,-cCRvAuJQfjBpTg0PbYiaNO87] or O7TLdNZjpW or K0TXmdZiEoGayp7L6 or mJ6iS0BAe8dTROL2nP or EEkpH9eqthTNnWjM4 or BGw7HzLackWmqV2rxO3oPf59bN4:
			HYfNLiDK3yRF7.code = -uL69vJOU7xN0hGnZf2islDqk
			HYfNLiDK3yRF7.reason = wNiDIHWX0BOk7ezTgfPx1RtVMvuKy
			if GGj9lzFA4RJLsig71pMwrY6Tk:
				wNeWBx39UjiCf6GFrV7obLmk = mHdRh8KCp01I45v(fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy)
				if wNeWBx39UjiCf6GFrV7obLmk.succeeded: return wNeWBx39UjiCf6GFrV7obLmk
		TT32BcvomhVewpgMSWkEb46y7xqO = k6apiPAlLKM1ed8J42RjHh0o
		if (gxDTdfjnIKspHLWz9a12FmBke=='ASK' or nFCAMOipWNJ3fc8BRev1xyU=='ASK') and (O5Q2j3Wi1JSZurkYbI0 or GGj9lzFA4RJLsig71pMwrY6Tk):
			TT32BcvomhVewpgMSWkEb46y7xqO = cJiwqfuC1HlD4Z(e5DznyEKA9hMcN3jX4Ou271gptkr,KDZYCzhrs4U89XGwHkWpbnvade,xmezOWMyhSXRGHlEk2JnsI,wmDAkp0iLt)
			if TT32BcvomhVewpgMSWkEb46y7xqO and gxDTdfjnIKspHLWz9a12FmBke=='ASK': gxDTdfjnIKspHLWz9a12FmBke = 'ACCEPTED'
			else: gxDTdfjnIKspHLWz9a12FmBke = 'REJECTED'
			if TT32BcvomhVewpgMSWkEb46y7xqO and nFCAMOipWNJ3fc8BRev1xyU=='ASK': nFCAMOipWNJ3fc8BRev1xyU = 'ACCEPTED'
			else: nFCAMOipWNJ3fc8BRev1xyU = 'REJECTED'
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.usedns',gxDTdfjnIKspHLWz9a12FmBke)
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.useproxy',nFCAMOipWNJ3fc8BRev1xyU)
		if TT32BcvomhVewpgMSWkEb46y7xqO:
			if e5DznyEKA9hMcN3jX4Ou271gptkr==8 and 'https' in BfjcMoqOsmdUvZVCHWIyQKi and PNflraOcX07mvz8SEQ:
				if wmDAkp0iLt: kkDz5sdaPteM('تفعيل فحص شهادة التشفير SSL','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi+'||NoVerifySSL'
				ROC7WiSmuMYvFayLc5Ed = W1nrEA8Xg3(fiuheaxH14ZML0,Afey3cL4ojzg,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,wmDAkp0iLt,'LIBRARY-OPENURL_REQUESTS-2nd')
				if ROC7WiSmuMYvFayLc5Ed.succeeded:
					HYfNLiDK3yRF7 = ROC7WiSmuMYvFayLc5Ed
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Succeeded using SSL:   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('نجاح باستخدام SSL','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				else:
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Failed using SSL:   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('فشل باستخدام SSL','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
			if not HYfNLiDK3yRF7.succeeded and nFCAMOipWNJ3fc8BRev1xyU in ['AUTO','ACCEPTED'] and GGj9lzFA4RJLsig71pMwrY6Tk:
				if wmDAkp0iLt: kkDz5sdaPteM('تفعيل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				ROC7WiSmuMYvFayLc5Ed = O1ARy2cjnu(fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI)
				if ROC7WiSmuMYvFayLc5Ed.succeeded:
					HYfNLiDK3yRF7 = ROC7WiSmuMYvFayLc5Ed
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Proxies succeeded:   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('نجاح سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				else:
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Proxies failed:   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('فشل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
			if not HYfNLiDK3yRF7.succeeded and gxDTdfjnIKspHLWz9a12FmBke in ['AUTO','ACCEPTED'] and O5Q2j3Wi1JSZurkYbI0:
				if wmDAkp0iLt: kkDz5sdaPteM('تفعيل سيرفر DNS','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi+'||MyDNSUrl='
				ROC7WiSmuMYvFayLc5Ed = W1nrEA8Xg3(fiuheaxH14ZML0,Afey3cL4ojzg,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,wmDAkp0iLt,'LIBRARY-OPENURL_REQUESTS-4th')
				if ROC7WiSmuMYvFayLc5Ed.succeeded:
					HYfNLiDK3yRF7 = ROC7WiSmuMYvFayLc5Ed
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   DNS succeeded:   DNS: [ '+fbEu6LMqO9iKR5jaG0tIe+' ]   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('نجاح سيرفر DNS','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
				else:
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   DNS failed:   DNS: [ '+fbEu6LMqO9iKR5jaG0tIe+' ]   Source: [ '+xmezOWMyhSXRGHlEk2JnsI+' ]   URL: [ '+ZZT6GLaHQ1+' ]')
					if wmDAkp0iLt: kkDz5sdaPteM('فشل سيرفر DNS','لإصلاح مشكلة الإنترنيت',XJ62UBRmIqFvfiNTQj=2000)
		if nFCAMOipWNJ3fc8BRev1xyU=='REJECTED' or gxDTdfjnIKspHLWz9a12FmBke=='REJECTED': wmDAkp0iLt = f4vncKMRlXG9s
		if not HYfNLiDK3yRF7.succeeded:
			if wmDAkp0iLt: srSail8ZMo23 = cJiwqfuC1HlD4Z(e5DznyEKA9hMcN3jX4Ou271gptkr,KDZYCzhrs4U89XGwHkWpbnvade,xmezOWMyhSXRGHlEk2JnsI,wmDAkp0iLt)
			if e5DznyEKA9hMcN3jX4Ou271gptkr!=200 and xmezOWMyhSXRGHlEk2JnsI not in t1raHhyD46KUw and 'RESOLVERS-' not in xmezOWMyhSXRGHlEk2JnsI: kaZwJ6ofBcYmeD()
	if ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.usedns') not in ['AUTO','STOP','ASK']: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.usedns','ASK')
	if ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.useproxy') not in ['AUTO','STOP','ASK']: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.useproxy','ASK')
	return HYfNLiDK3yRF7
def Y6N8DUvSxeBFnKz(pma7xfu1g43KVTMFQ):
	if 'EXTRAPYTHONCODE' in str(sevfFTR5mNndl): return
	global ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8
	if not pma7xfu1g43KVTMFQ: ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8 = NdKhAS6MXVEORLTwob92pxlZ
	global xKp3jkIvM09AZ4euXa87i5TVtfUD,L0FAgEfwqWl5PUDhIzpi8J9KNm23o6,LcdEWz9BRiQlr8MxgCHeuX,skKcVTiAr3QgdYDCbNGuER
	if not ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8:
		ZZT6GLaHQ1 = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON'][9]
		EEbWxcT86wIO54GFZgmoveXC = {'user':lop0ZwWYLmxOPAaErzF6cQvDkVR,'version':lvsJ2jaZktmNO6PbdXS}
		ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8 = KJz9WRbX2g0LeCD('POST',ZZT6GLaHQ1,EEbWxcT86wIO54GFZgmoveXC,NdKhAS6MXVEORLTwob92pxlZ,'LIBRARY-EXTRA_PYTHON_CODE-1st')
		c2JF3xijoWuSgAVvLaRz(yy0zIog9KDlfOQ[9])
		if ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'MISC_TEMP','EXTRAPYTHONCODE',ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8,hzP83xLawFqYneDtHGmSriWE)
		exec(ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8,globals(),locals())
	if ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8:
		xKp3jkIvM09AZ4euXa87i5TVtfUD.update(NEW_SITESURLS)
		L0FAgEfwqWl5PUDhIzpi8J9KNm23o6 = list(set(L0FAgEfwqWl5PUDhIzpi8J9KNm23o6+NEW_BADSCRAPERS))
		skKcVTiAr3QgdYDCbNGuER = list(set(skKcVTiAr3QgdYDCbNGuER+NEW_BADCOMMONIDS))
		if lvsJ2jaZktmNO6PbdXS in list(NEW_BADWEBSITES.keys()): LcdEWz9BRiQlr8MxgCHeuX += NEW_BADWEBSITES[lvsJ2jaZktmNO6PbdXS]
	return
def o6pkns2UGWqbh(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,TWqGAlsD0bpihcwOB3FLfYKMdxgC,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V):
	Got6cjmbzLUwS1ePpaMTd = int(iy8Ymsp0GMPVdSWTBR%10)
	wnBVNedG0L9m = int(iy8Ymsp0GMPVdSWTBR/10)
	TNKZOBc0gpyvdk7q3mFCP4WVDJ = GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG
	urvcNGnLMSXRd = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.menuscache')
	if not urvcNGnLMSXRd: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.menuscache','AUTO')
	xmYofc7HByzQqEh81L2b6V = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.status.refresh')
	cfGPeIbDgox07mQ = x5lwbtumkO6X2TgFoVh(TWqGAlsD0bpihcwOB3FLfYKMdxgC)
	uAOWphoNvDwi1JG = [e8XhbyuzvjYkIsJUtB5w,15,17,19,26,34,50,53]
	c7lnkKyPQeqa05oi1ImBGTDSb9 = wnBVNedG0L9m not in uAOWphoNvDwi1JG
	b9nqIweNcjT8Sv3u6FhpgJ = wnBVNedG0L9m in [23,28,71,72]
	uujLe62RABInU = iy8Ymsp0GMPVdSWTBR in [265,270]
	rcFdCsmDMPgVAv02WfzTI = (c7lnkKyPQeqa05oi1ImBGTDSb9 or b9nqIweNcjT8Sv3u6FhpgJ) and not uujLe62RABInU
	a8c1fWoTrtbu = (xmYofc7HByzQqEh81L2b6V or not IGar1Z3F8lNX) and xmYofc7HByzQqEh81L2b6V not in ['REFRESH_CACHE']+B0vJILKy1FphGiXmwonQ
	D06owhs9OV8YQ3BCe = 'type=' in xmYofc7HByzQqEh81L2b6V
	NkUh5lW09q = iy8Ymsp0GMPVdSWTBR in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	tTIQWSbOEqHJ4 = Got6cjmbzLUwS1ePpaMTd==9 or iy8Ymsp0GMPVdSWTBR in [145,516,523,45]
	jdgLYsfhloICbUrWm = not NkUh5lW09q
	ZSJe30qxVsz8PI4T = not tTIQWSbOEqHJ4
	M7IwiCUnNGEB = cfGPeIbDgox07mQ in [NdKhAS6MXVEORLTwob92pxlZ,'..']
	m458K1Y0lkF2PBMWUN6Awn9Rq = M7IwiCUnNGEB or jdgLYsfhloICbUrWm
	NFSHOKou3Ah95gv = M7IwiCUnNGEB or ZSJe30qxVsz8PI4T or D06owhs9OV8YQ3BCe
	fivOXIDurKpeQTyq = iy8Ymsp0GMPVdSWTBR not in [260,261,265,270,330,540,1010]
	if urvcNGnLMSXRd=='STOP': VlPo9OCHesSREm = tTIQWSbOEqHJ4 or NkUh5lW09q
	else: VlPo9OCHesSREm = k6apiPAlLKM1ed8J42RjHh0o
	sfSRMHzBi5p = wnBVNedG0L9m in [74,75]
	XvaejUgrwnFdqzcYoKG84PIOsD = iy8Ymsp0GMPVdSWTBR in [280,720]
	SSqN79mYWbZ4McujJH8xvRPCInAl = not sfSRMHzBi5p and not XvaejUgrwnFdqzcYoKG84PIOsD
	mbkKnhdWIytTL = m458K1Y0lkF2PBMWUN6Awn9Rq and NFSHOKou3Ah95gv and fivOXIDurKpeQTyq and VlPo9OCHesSREm and SSqN79mYWbZ4McujJH8xvRPCInAl
	PuNCS06XtsdgV8WAozBUpinejHKMk = fivOXIDurKpeQTyq and VlPo9OCHesSREm and SSqN79mYWbZ4McujJH8xvRPCInAl
	DCOsArKQ0f3w6ViGUx = PuNCS06XtsdgV8WAozBUpinejHKMk
	z67QrXv9GugIx2AkWRFP35 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.provider')
	bbcnJVQUh97HxztuDZe6ai2v = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
	KTzV0ixwbQtB1Y23ynGsF7HIgZkU = f4vncKMRlXG9s
	if a8c1fWoTrtbu and mbkKnhdWIytTL:
		Da4GbdZXqmfC = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','MENUS_CACHE_'+z67QrXv9GugIx2AkWRFP35+'_'+bbcnJVQUh97HxztuDZe6ai2v,TNKZOBc0gpyvdk7q3mFCP4WVDJ)
		if Da4GbdZXqmfC:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(NdKhAS6MXVEORLTwob92pxlZ,'.\tMENUS_CACHE_'+z67QrXv9GugIx2AkWRFP35+'_'+bbcnJVQUh97HxztuDZe6ai2v+'   Loading menu from cache')
			if D06owhs9OV8YQ3BCe:
				BZ84AcITVPnU = []
				from md4vN8TBez import jOc8u6yzE2wIPRxrK7eni
				from LSQvu5zPa6 import yWbk3mQft0RzghLlCHBudcsYGr,DO4B07vQ5KhVk6Jns1fmIzre
				EkAeNSda3GvU = jOc8u6yzE2wIPRxrK7eni
				X5SjOnzeFDhVd31oiHE4fp6 = yWbk3mQft0RzghLlCHBudcsYGr()
				ZMfcV2rObnaEjgFJvtsYuPoKwq89mk = xmYofc7HByzQqEh81L2b6V
				q3G8oDaNc2rQ6R0xI,O1IAgd9clyD37CvYWwBLzkKq6n,JlX9mhqYApvNkODTQ4HBwgUCKiW,E9BDAoadg3LVxTf,AArj18pYnvoFZw7qIVLEXbd,xLKktZjs0mEaH2gNb6,iPCYB3MfWtKwD9OuLUN,ppgcFs1nKIoJdb2ZakSrfAOqCit9,S6seLv7GZo = W17Zj6mXnvxLdM50cPA(ZMfcV2rObnaEjgFJvtsYuPoKwq89mk)
				pMlBDsd0zZQON7gLvaPW = q3G8oDaNc2rQ6R0xI,O1IAgd9clyD37CvYWwBLzkKq6n,JlX9mhqYApvNkODTQ4HBwgUCKiW,E9BDAoadg3LVxTf,AArj18pYnvoFZw7qIVLEXbd,xLKktZjs0mEaH2gNb6,iPCYB3MfWtKwD9OuLUN,NdKhAS6MXVEORLTwob92pxlZ,S6seLv7GZo
				for u2zdGHcmYrqLMviNsARgjPC6fZI in Da4GbdZXqmfC:
					e8HyRdnzojF = u2zdGHcmYrqLMviNsARgjPC6fZI['menuItem']
					if e8HyRdnzojF==pMlBDsd0zZQON7gLvaPW or u2zdGHcmYrqLMviNsARgjPC6fZI['mode'] in [265,270]:
						u2zdGHcmYrqLMviNsARgjPC6fZI = dsb4pfE08WoitQA1B5eZcrUlP7(e8HyRdnzojF,EkAeNSda3GvU,X5SjOnzeFDhVd31oiHE4fp6)
						if u2zdGHcmYrqLMviNsARgjPC6fZI['favorites']:
							BcWYgxV46KTLF83JMDftC7bjpah = DO4B07vQ5KhVk6Jns1fmIzre(X5SjOnzeFDhVd31oiHE4fp6,e8HyRdnzojF,u2zdGHcmYrqLMviNsARgjPC6fZI['newpath'])
							u2zdGHcmYrqLMviNsARgjPC6fZI['context_menu'] = BcWYgxV46KTLF83JMDftC7bjpah+u2zdGHcmYrqLMviNsARgjPC6fZI['context_menu']
					BZ84AcITVPnU.append(u2zdGHcmYrqLMviNsARgjPC6fZI)
				ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.status.refresh',NdKhAS6MXVEORLTwob92pxlZ)
				if GY9jgon6yhP0IvtCBEJu3=='folder': eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'MENUS_CACHE_'+z67QrXv9GugIx2AkWRFP35+'_'+bbcnJVQUh97HxztuDZe6ai2v,TNKZOBc0gpyvdk7q3mFCP4WVDJ,BZ84AcITVPnU,h1dnE0q2zFHjXlvyGuLZxw)
			else: BZ84AcITVPnU = Da4GbdZXqmfC
			if GY9jgon6yhP0IvtCBEJu3=='folder' and cfGPeIbDgox07mQ!='..' and rcFdCsmDMPgVAv02WfzTI: E2OlWsLqp5d78iQMmc3uzD()
			KTzV0ixwbQtB1Y23ynGsF7HIgZkU = LLAlKs5Tbw1chPn(TNKZOBc0gpyvdk7q3mFCP4WVDJ,BZ84AcITVPnU,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V)
	elif GY9jgon6yhP0IvtCBEJu3=='folder' and xmYofc7HByzQqEh81L2b6V not in ['REFRESH_CACHE']+B0vJILKy1FphGiXmwonQ and PuNCS06XtsdgV8WAozBUpinejHKMk:
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'MENUS_CACHE_'+z67QrXv9GugIx2AkWRFP35+'_'+bbcnJVQUh97HxztuDZe6ai2v,TNKZOBc0gpyvdk7q3mFCP4WVDJ)
	return KTzV0ixwbQtB1Y23ynGsF7HIgZkU,xmYofc7HByzQqEh81L2b6V,TNKZOBc0gpyvdk7q3mFCP4WVDJ,cfGPeIbDgox07mQ,rcFdCsmDMPgVAv02WfzTI,DCOsArKQ0f3w6ViGUx,z67QrXv9GugIx2AkWRFP35,bbcnJVQUh97HxztuDZe6ai2v
def kqLBiwGX3V8P4SOmrNI1F7AMU(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG):
	iy8Ymsp0GMPVdSWTBR = int(DDq6xNzlMYK)
	wnBVNedG0L9m = int(iy8Ymsp0GMPVdSWTBR//10)
	if   wnBVNedG0L9m==e8XhbyuzvjYkIsJUtB5w:  from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==llxMLe4gobHhsj1WGvd7qmIU:  from fSyDaLbhPV 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==cCRvAuJQfjBpTg0PbYiaNO87:  from PH6RWpv5DK 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==uL69vJOU7xN0hGnZf2islDqk:  from d9huMaXpyx 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==TQNS6YMKAqnilsVObLpDRX:  from UB5dzQrPLo 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif wnBVNedG0L9m==5:  from x95LPSfncN 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==6:  from FBVhCy8bmu 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==7:  from Nbylaq3nUL 			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==8:  from tBpA6DSOTz 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==9:  from ww9nK7YSqW		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==10: from nnVfdXFC9O 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1)
	elif wnBVNedG0L9m==11: from WrGxOkJPCN 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==12: from aajQ2ou438 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==13: from WZnIKqCXk1		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==14: from jdhuexnA5b 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,vczZTnVU6PuaFG5EeALl4MKOj0,k1ChwgueU5nbDX6K0BOEGx)
	elif wnBVNedG0L9m==15: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==16: from NkUh5lW09q		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==17: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==18: from G5GiXtmDjO		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==19: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==20: from qqUfHpWYb2		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==21: from Y2SNCRe4AX	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==22: from mhaCrMDp9A		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==23: from dduW7Cg5Fx			import mxnEVjz6b3v; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mxnEVjz6b3v(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==24: from dKusGQWL0z 			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==25: from TsmavPO7dc 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==26: from md4vN8TBez 			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==27: from LSQvu5zPa6		import mxnEVjz6b3v; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mxnEVjz6b3v(iy8Ymsp0GMPVdSWTBR,IGar1Z3F8lNX)
	elif wnBVNedG0L9m==28: from dduW7Cg5Fx			import mxnEVjz6b3v; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mxnEVjz6b3v(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==29: from mm48iVRB7K	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==30: from igcP5NRLxS		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==31: from EJie7xtBG0		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==32: from PzTe9tjNfS		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==33: from Po3kCjO4aN		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1)
	elif wnBVNedG0L9m==34: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==35: from er3kMPhVNc		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==36: from Mv1S0NnoLc			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==37: from gg34ZwSuqD			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==38: from ggaX57uqsJ 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==39: from jTdEqINm1i		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==40: from rkeSbyBcK6	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif wnBVNedG0L9m==41: from rkeSbyBcK6	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif wnBVNedG0L9m==42: from IOY8EXZopF			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==43: from NNqGlbdzVE			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==44: from OO6PpsFrJ5		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==45: from K16TpUji7C		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==46: from zJrlt5mZ9w			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==47: from KkQ9eFYNl2		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==48: from T3TQo2Fr5e		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==49: from zd351qvLMF		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==50: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==51: from WPfZbgQour 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==52: from WPfZbgQour 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==53: from md4vN8TBez 			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==54: from ddml0DI2qy	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif wnBVNedG0L9m==55: from ElC38ro1qU 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==56: from xemC84so16		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==57: from xVDPCTs6jX		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==58: from t81t4mpBRk		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==59: from VV4pcXHnJF		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==60: from FOonXswmBg			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==61: from cYq2KbBZWE			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==62: from Fm1zcZNQ3B		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==63: from K9gHSUpl7R	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==64: from fx0PH6CZqm			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==65: from JOWH78lStd			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==66: from vAy1deOHbh			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==67: from RQzfIOVrm3		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==68: from c5v7rxYBim		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==69: from QsVPk2WXEd		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==70: from ss7D4f8nvo			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==71: from ws4trNj60m			import mxnEVjz6b3v; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mxnEVjz6b3v(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==72: from ws4trNj60m			import mxnEVjz6b3v; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mxnEVjz6b3v(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,GY9jgon6yhP0IvtCBEJu3,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==73: from fe0RVyc76O	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==74: from tCMyTYS48c		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR)
	elif wnBVNedG0L9m==75: from tCMyTYS48c		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR)
	elif wnBVNedG0L9m==76: from NkUh5lW09q		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	elif wnBVNedG0L9m==77: from zhlqBY1Ev2 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==78: from y36qAHGaVj 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==79: from duEz093LZo 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==80: from WMNy1hKjbO 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==81: from hRQNHY5VxL 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==82: from H6HiytTblh		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==83: from VrFUbL8Mao		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==84: from KoUb7iamN5		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==85: from qqleA1jS6x		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==86: from cvyMs6YGTC		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==87: from nk1erWgiOG			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==88: from zMPF5YBk81			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==89: from QdC0V9SAYs		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==90: from ccv5OBnlYI	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==91: from ppeikWrXIE		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==92: from f1zHIw6gOU		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==93: from OL4sqv3XwG		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==94: from EvGdcZ5yHS			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==95: from DowJ4kLM2h			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==96: from d3ugQCBmVX		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==97: from QcOfGXA9Cm		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==98: from ZEQvGmABjy		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==99: from F1gOKUowiN		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==100: from heCY5Ecfio		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==101: from PdOcXS3g6n	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==102: from oMV3OL4Bzl 		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==103: from VhwdoC7WQ4	import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==104: from ZGB3i4C59P		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==105: from Im6ndcfLAp			import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==106: from JhUEHLwq3p		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	elif wnBVNedG0L9m==107: from nny96FkWMw		import QGLoruqnmiAel7Op	; UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QGLoruqnmiAel7Op(iy8Ymsp0GMPVdSWTBR,ZZT6GLaHQ1,HSb5r1Di9I8eKTtAyuNZdC4W)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = None
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
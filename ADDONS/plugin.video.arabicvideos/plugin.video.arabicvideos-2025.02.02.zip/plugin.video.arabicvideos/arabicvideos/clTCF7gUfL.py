# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
import xbmc as ACOWB6GRmIbDKyl3Zn,re as YYqECUofyi7wFrW,sys as hnu0oKAvsG4PaX6yxiTj2eftY,xbmcaddon as bbo54rteSTAMHmaq3Jwsd,random as Ijo3hy7zQO5x8aU9vAZDMV,os as IIPNcsCvQnOZk0yejJKl4BtgSrMw,xbmcvfs as ArK8Tohfy6wG,time as XJ62UBRmIqFvfiNTQj,pickle as Q4V2fcRKHG,zlib as fvrhqAQLpuFMS9CctkRsIwPBxgEj5,xbmcgui as JTIdpcz98k7RyxHOX5EnqD6L1vKe04,xbmcplugin as vI4DUTHAYrjBPOXwu9nas,sqlite3 as moKCtu35ZJgji1UXIS0srpELB,traceback as gg5FIJdLzZY4MCfxiTAswNp,threading as ayQ463vhoOT2NqWjkX7fLFuKJ,hashlib as f6ZTNntQrRHd,json as O3OogF1l5reuQ
import OMNiY8joQx
yNIDEX5hU4G769 = rNyT0edugn(u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩॢ")
NdKhAS6MXVEORLTwob92pxlZ = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࠪॣ")
Vwgflszp4WRA93kx6hvdua21HX5cOb = NeU6uRGpECkvMV5jf(u"ࠪࠤࠬ।")
Uv7MkgVGyEbAlfFP0S8Zjqp2J = Vwgflszp4WRA93kx6hvdua21HX5cOb*wP4kpvXoDHq3hs7TFLyr2COn8(u"࠸ୃ")
H9cMF21gLJSv3tA5CPYXza = Vwgflszp4WRA93kx6hvdua21HX5cOb*fOc18oTm5hsdD4pVZQj(u"࠳ୄ")
mrgzi2ktB4WS06QHPf5ZJE1Kv = Vwgflszp4WRA93kx6hvdua21HX5cOb*HVmIrFwau90jQsgiWzExk(u"࠵୅")
k6apiPAlLKM1ed8J42RjHh0o = R3lezw8h407ZvrAFxT(u"ࡘࡷࡻࡥக")
f4vncKMRlXG9s = eGW7cI6aQhr0(u"ࡋࡧ࡬ࡴࡧ஖")
e8XhbyuzvjYkIsJUtB5w = rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠲୆")
llxMLe4gobHhsj1WGvd7qmIU = lrtFSogC8Nh9(u"࠴େ")
cCRvAuJQfjBpTg0PbYiaNO87 = eGW7cI6aQhr0(u"࠶ୈ")
uL69vJOU7xN0hGnZf2islDqk = Hlp3z0APt1GR4kMYK5xST(u"࠸୉")
TQNS6YMKAqnilsVObLpDRX = rNyT0edugn(u"࠺୊")
Whef0cxB2iR93SC5IwUtk = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡄ࠸࠶ࡋࡣࠧ॥")
D7INg5kyRjwf4ZtoePVUrb1h2SJ = eGW7cI6aQhr0(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ०")
kRJIE1KlPjZyAbQ73aHGFo24w6Ld9 = rtUJso6d7iaNf1yWejxnc5DEXFg(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇ࠵࠶ࡉ࠹࠹࠳࡞ࠩ१")
lePmOJq9GZw1AD = NeU6uRGpECkvMV5jf(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈ࠴ࡊ࠺࠷ࡆࡇ࡟ࠪ२")
kjd9LyNqQHMUevZiRI7OlBGF1h = hCm2fnEXs6Zt(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ३")
YRvPKe2zMTDs8UCkr = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡸࡸ࡫࠾ࠧ४")
Ng4e6LpJBxa5rlI = fOc18oTm5hsdD4pVZQj(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५")
CSF2xtI1Yg5baHPJqZdOj9Ah = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ६")
CB2TcZaokLhA3dQOgjPywzGuxXq7EI = hCm2fnEXs6Zt(u"ࠬࡋࡒࡓࡑࡕࠫ७")
sSHvJFeTkhoE8KnuNWwljAg3mX16 = lNTJCZeBicWEz0Mg(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ८")
B6IrC7zEHlw1oaeWf = hCm2fnEXs6Zt(u"ࠧ࡝ࡰࠪ९")
SSDnd9QAUwo86G7eurKlaPikE3qsv = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࡞ࡵࠫ॰")
VAzvLnYQrdktx75g = bbo54rteSTAMHmaq3Jwsd.Addon().getAddonInfo(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡳࡥࡹ࡮ࠧॱ"))
m4mg0hfSWGJnFCya8sItHqeXKp = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,NOrchaEV1iIZ87Uzlwgum(u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬॲ"))
hnu0oKAvsG4PaX6yxiTj2eftY.path.append(m4mg0hfSWGJnFCya8sItHqeXKp)
dor6Z1x9CvBpQgKTG38bYtJ = ACOWB6GRmIbDKyl3Zn.getInfoLabel(NOrchaEV1iIZ87Uzlwgum(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥॳ"))
kQI947MebLovYyVE08F5qPi6fj3 = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩॴ"),dor6Z1x9CvBpQgKTG38bYtJ,YYqECUofyi7wFrW.DOTALL)
kQI947MebLovYyVE08F5qPi6fj3 = float(kQI947MebLovYyVE08F5qPi6fj3[e8XhbyuzvjYkIsJUtB5w])
qep24AhtFvKTGMkDfl6YmLiVSyo = ACOWB6GRmIbDKyl3Zn.Player
Kb4rUJvNhY = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.WindowXMLDialog
QBp28giCnayJzmZH6vYO = kQI947MebLovYyVE08F5qPi6fj3<Hlp3z0APt1GR4kMYK5xST(u"࠱࠺ୋ")
J92gCnbGWidQV70lBteTwU6D8uyzL = kQI947MebLovYyVE08F5qPi6fj3>LtGoXlQ2IYxqTJRySE6udfW98(u"࠲࠺࠱࠽࠾ୌ")
if J92gCnbGWidQV70lBteTwU6D8uyzL:
	WLUldVujmP3sA9pJ = ACOWB6GRmIbDKyl3Zn.LOGINFO
	MgDNZ1f34w,iy0rIHuvaAgpbjRKnTQcJwLVs = QQHFtjcaR2VpnSyTIv(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧॵ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨॶ")
	x9VF6mXyt3NB = ArK8Tohfy6wG.translatePath(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩॷ"))
	from urllib.parse import unquote as _HXr2teyzGw1U6ME
else:
	WLUldVujmP3sA9pJ = ACOWB6GRmIbDKyl3Zn.LOGNOTICE
	MgDNZ1f34w,iy0rIHuvaAgpbjRKnTQcJwLVs = eGW7cI6aQhr0(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪॸ").encode(YRvPKe2zMTDs8UCkr),eGW7cI6aQhr0(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫॹ").encode(YRvPKe2zMTDs8UCkr)
	x9VF6mXyt3NB = ACOWB6GRmIbDKyl3Zn.translatePath(HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬॺ"))
	from urllib import unquote as _HXr2teyzGw1U6ME
ajsOmb2ExgfiYSW = pnHgvFOCBZzc08yULQJGIqw9bf(u"࠸࠳୍")
lvmy4BZ6Reqb = R3lezw8h407ZvrAFxT(u"࠹࠴୎")*ajsOmb2ExgfiYSW
vvgEtaduGZLspwRN9CYmyiefl1QA = V0VZk9763fusTReHFo4(u"࠶࠹୏")*lvmy4BZ6Reqb
V6Lc2i1mIafFvwznQ7 = eGW7cI6aQhr0(u"࠸࠶୐")*vvgEtaduGZLspwRN9CYmyiefl1QA
ee2SDNw9sRVdhxmioTIkZGj6FqzrBE = e8XhbyuzvjYkIsJUtB5w
MIT0n79k8beo26aJHW = kb2icmDGVUZfW1OFz7sv(u"࠹࠰୑")*ajsOmb2ExgfiYSW
NXpO8DrVmeE = cCRvAuJQfjBpTg0PbYiaNO87*lvmy4BZ6Reqb
h1dnE0q2zFHjXlvyGuLZxw = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠱࠷୒")*lvmy4BZ6Reqb
OewIv05xGhKQpFf = uL69vJOU7xN0hGnZf2islDqk*vvgEtaduGZLspwRN9CYmyiefl1QA
KxC8ewP4yTmq3lLj6voVfh7WNOX5H = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠴࠲୓")*vvgEtaduGZLspwRN9CYmyiefl1QA
hzP83xLawFqYneDtHGmSriWE = JGwsL21ZRlqSrWxEmF(u"࠳࠵୔")*V6Lc2i1mIafFvwznQ7
iiNnbh6pks9GFul0UJvaAMjq8DLCO = lvmy4BZ6Reqb
b0VaRYkgC4iOvHpmdeyzcQISJEsx = hnu0oKAvsG4PaX6yxiTj2eftY.argv[e8XhbyuzvjYkIsJUtB5w].split(HVmIrFwau90jQsgiWzExk(u"ࠬ࠵ࠧॻ"))[cCRvAuJQfjBpTg0PbYiaNO87]
oo2RYcTAqyksN1DHG7gLCaZJ = int(hnu0oKAvsG4PaX6yxiTj2eftY.argv[llxMLe4gobHhsj1WGvd7qmIU])
RAHOMksyDUV3w7T1QjqKNX = hnu0oKAvsG4PaX6yxiTj2eftY.argv[cCRvAuJQfjBpTg0PbYiaNO87]
apxMzQgiqn0oLd9fsW8P6u1C = b0VaRYkgC4iOvHpmdeyzcQISJEsx.split(hCm2fnEXs6Zt(u"࠭࠮ࠨॼ"))[cCRvAuJQfjBpTg0PbYiaNO87]
lvsJ2jaZktmNO6PbdXS = ACOWB6GRmIbDKyl3Zn.getInfoLabel(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧॽ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+NOrchaEV1iIZ87Uzlwgum(u"ࠨࠫࠪॾ"))
vJQYPbL42F013CRoqtEUI = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(x9VF6mXyt3NB,b0VaRYkgC4iOvHpmdeyzcQISJEsx)
ZFMPvkNQbT2cHiUj = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,lRP6GTaZJA1Xw3egLM4(u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤ࠲ࡩࡨࠧॿ"))
LKitvZysHM = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,NeU6uRGpECkvMV5jf(u"ࠪࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮ࡥࡣࡷࠫঀ"))
MMQhDpyCenmO350aBAKVYk = int(XJ62UBRmIqFvfiNTQj.time())
ptbWxl0eDEwc5PQaKR3XHzn4fF = bbo54rteSTAMHmaq3Jwsd.Addon(id=b0VaRYkgC4iOvHpmdeyzcQISJEsx)
IIrhNlSeJAw1yCTs7RX0BVE9WobKm = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨঁ"))
INCQEvfcLSX3ah7V4WHilmdZKGB = f4vncKMRlXG9s if IIrhNlSeJAw1yCTs7RX0BVE9WobKm==lvsJ2jaZktmNO6PbdXS else k6apiPAlLKM1ed8J42RjHh0o
XZDTo3UC1RgVSdGFwlqx = f4vncKMRlXG9s
def muYp09a1NhMo7cZng5IOXyTSKt4qv2(ZZT6GLaHQ1,mqgWoY2a3fw9MUB=lRP6GTaZJA1Xw3egLM4(u"ࠬࡅࠧং")):
	if vju3SZDWL4ENYelmBOzUqrogp2(u"࠭࠽ࠨঃ") in ZZT6GLaHQ1:
		if mqgWoY2a3fw9MUB in ZZT6GLaHQ1: BfjcMoqOsmdUvZVCHWIyQKi,hh4HVjmgwkdKb3MpXrIC2xOTSYoDs9 = ZZT6GLaHQ1.split(mqgWoY2a3fw9MUB,ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠴୕"))
		else: BfjcMoqOsmdUvZVCHWIyQKi,hh4HVjmgwkdKb3MpXrIC2xOTSYoDs9 = NdKhAS6MXVEORLTwob92pxlZ,ZZT6GLaHQ1
		hh4HVjmgwkdKb3MpXrIC2xOTSYoDs9 = hh4HVjmgwkdKb3MpXrIC2xOTSYoDs9.split(NeU6uRGpECkvMV5jf(u"ࠧࠧࠩ঄"))
		OzUD8iTmGp15Sn9VINMHq = {}
		for cyp8zRODA9gUlm5Vr2xM in hh4HVjmgwkdKb3MpXrIC2xOTSYoDs9:
			V9fBFLnGeItlHmYgE1Xi0xvWPz,m6I48ydkMWlQN = cyp8zRODA9gUlm5Vr2xM.split(NeU6uRGpECkvMV5jf(u"ࠨ࠿ࠪঅ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠵ୖ"))
			OzUD8iTmGp15Sn9VINMHq[V9fBFLnGeItlHmYgE1Xi0xvWPz] = m6I48ydkMWlQN
	else: BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = ZZT6GLaHQ1,{}
	return BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq
def x5lwbtumkO6X2TgFoVh(vczZTnVU6PuaFG5EeALl4MKOj0):
	SIeX2BqzJUgAFL593fwYpt4EG8iv,mAH4aPy8q1w,Es4rtL91KxZyIhPv258npa06uGmMiW = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	vczZTnVU6PuaFG5EeALl4MKOj0 = vczZTnVU6PuaFG5EeALl4MKOj0.replace(MgDNZ1f34w,NdKhAS6MXVEORLTwob92pxlZ).replace(iy0rIHuvaAgpbjRKnTQcJwLVs,NdKhAS6MXVEORLTwob92pxlZ)
	ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠩࠫ࠲࠮ࡢ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈ࠳࠼ࡈ࠷ࡆ࡝࡟ࠫࡠࡼࡢࡷ࡝ࡹࠬࠤ࠰ࡢ࡛࡝࠱ࡆࡓࡑࡕࡒ࡝࡟ࠫ࠲࠯ࡅࠩࠥࠩআ"),vczZTnVU6PuaFG5EeALl4MKOj0,YYqECUofyi7wFrW.DOTALL)
	if ekmszoF6UQAbHp9r0ug: SIeX2BqzJUgAFL593fwYpt4EG8iv,mAH4aPy8q1w,vczZTnVU6PuaFG5EeALl4MKOj0 = ekmszoF6UQAbHp9r0ug[e8XhbyuzvjYkIsJUtB5w]
	if SIeX2BqzJUgAFL593fwYpt4EG8iv not in [Vwgflszp4WRA93kx6hvdua21HX5cOb,lrtFSogC8Nh9(u"ࠪ࠰ࠬই"),NdKhAS6MXVEORLTwob92pxlZ]: Es4rtL91KxZyIhPv258npa06uGmMiW = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡤࡓࡏࡅࡡࠪঈ")
	if mAH4aPy8q1w: mAH4aPy8q1w = JGwsL21ZRlqSrWxEmF(u"ࠬࡥࠧউ")+mAH4aPy8q1w+rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭࡟ࠨঊ")
	vczZTnVU6PuaFG5EeALl4MKOj0 = mAH4aPy8q1w+Es4rtL91KxZyIhPv258npa06uGmMiW+vczZTnVU6PuaFG5EeALl4MKOj0
	return vczZTnVU6PuaFG5EeALl4MKOj0
def OOFEmwq2GkTz93WXy1Nj(ZZT6GLaHQ1):
	return _HXr2teyzGw1U6ME(ZZT6GLaHQ1)
def W17Zj6mXnvxLdM50cPA(kyNT0RxQH4z6cC1):
	NN2Vc7rpAdsS58Pb9WRHx0Fz = {kb2icmDGVUZfW1OFz7sv(u"ࠧࡵࡻࡳࡩࠬঋ"):NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࡯ࡲࡨࡪ࠭ঌ"):NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠩࡸࡶࡱ࠭঍"):NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡸࡪࡾࡴࠨ঎"):NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡵࡧࡧࡦࠩএ"):NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡴࡡ࡮ࡧࠪঐ"):NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"࠭ࡩ࡮ࡣࡪࡩࠬ঑"):NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ঒"):NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪও"):NdKhAS6MXVEORLTwob92pxlZ}
	if Hlp3z0APt1GR4kMYK5xST(u"ࠩࡂࠫঔ") in kyNT0RxQH4z6cC1: kyNT0RxQH4z6cC1 = kyNT0RxQH4z6cC1.split(R3lezw8h407ZvrAFxT(u"ࠪࡃࠬক"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
	BfjcMoqOsmdUvZVCHWIyQKi,eXG6uD3wqrRxL1zAEYy7Ph2 = muYp09a1NhMo7cZng5IOXyTSKt4qv2(kyNT0RxQH4z6cC1)
	aargs = dict(list(NN2Vc7rpAdsS58Pb9WRHx0Fz.items())+list(eXG6uD3wqrRxL1zAEYy7Ph2.items()))
	Yrq4u3gv9WTSL = aargs[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡲࡵࡤࡦࠩখ")]
	T4JCqSH3x5BiWNhI0 = OOFEmwq2GkTz93WXy1Nj(aargs[xY4icgQUj6mPVs73CTKu(u"ࠬࡻࡲ࡭ࠩগ")])
	p8pD6rTHEdCIsMnWijukwS9zYqcZm = OOFEmwq2GkTz93WXy1Nj(aargs[eGW7cI6aQhr0(u"࠭ࡴࡦࡺࡷࠫঘ")])
	sawplH5BqyAfbIgiLnh3J = OOFEmwq2GkTz93WXy1Nj(aargs[JGwsL21ZRlqSrWxEmF(u"ࠧࡱࡣࡪࡩࠬঙ")])
	OH8t94DKxE0LYI3XmfPBj7ReU = OOFEmwq2GkTz93WXy1Nj(aargs[Hlp3z0APt1GR4kMYK5xST(u"ࠨࡶࡼࡴࡪ࠭চ")])
	WdC7ZebIlsKGu = OOFEmwq2GkTz93WXy1Nj(aargs[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡱࡥࡲ࡫ࠧছ")])
	NNP0lcpCTdo = OOFEmwq2GkTz93WXy1Nj(aargs[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࡭ࡲࡧࡧࡦࠩজ")])
	bPuifnrSBO6ZzDQN4yY7eVTl = aargs[PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬঝ")]
	qt2mdMSsIo = OOFEmwq2GkTz93WXy1Nj(aargs[NeU6uRGpECkvMV5jf(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧঞ")])
	if qt2mdMSsIo: qt2mdMSsIo = eval(qt2mdMSsIo)
	else: qt2mdMSsIo = {}
	if not Yrq4u3gv9WTSL: OH8t94DKxE0LYI3XmfPBj7ReU = wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ট") ; Yrq4u3gv9WTSL = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠳࠸࠳ࠫঠ")
	return OH8t94DKxE0LYI3XmfPBj7ReU,WdC7ZebIlsKGu,T4JCqSH3x5BiWNhI0,Yrq4u3gv9WTSL,NNP0lcpCTdo,sawplH5BqyAfbIgiLnh3J,p8pD6rTHEdCIsMnWijukwS9zYqcZm,bPuifnrSBO6ZzDQN4yY7eVTl,qt2mdMSsIo
def BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769):
	CkzD47tK0ViHIhANxnp5P32SW1f6B = hnu0oKAvsG4PaX6yxiTj2eftY._getframe(llxMLe4gobHhsj1WGvd7qmIU).f_code.co_name
	if not yNIDEX5hU4G769 or not CkzD47tK0ViHIhANxnp5P32SW1f6B or CkzD47tK0ViHIhANxnp5P32SW1f6B==hCm2fnEXs6Zt(u"ࠨ࠾ࡰࡳࡩࡻ࡬ࡦࡀࠪড"):
		return lNTJCZeBicWEz0Mg(u"ࠩ࡞ࠤࠬঢ")+apxMzQgiqn0oLd9fsW8P6u1C.upper()+lNTJCZeBicWEz0Mg(u"ࠪࡣࠬণ")+lvsJ2jaZktmNO6PbdXS+NOrchaEV1iIZ87Uzlwgum(u"ࠫࡤ࠭ত")+str(kQI947MebLovYyVE08F5qPi6fj3)+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦ࡝ࠨথ")
	return eGW7cI6aQhr0(u"࠭࠮࡝ࡶࠪদ")+CkzD47tK0ViHIhANxnp5P32SW1f6B
def LlDhFpn5VqN6KJdy4HboeZ7YjcMC(bLw0V1a5WfHd4uzQR2iv,ntDbV4lpe3WzTJ):
	if QBp28giCnayJzmZH6vYO: ntDbV4lpe3WzTJ = ntDbV4lpe3WzTJ.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
	k02Re7AMjyXgBsI5iKTmr = WLUldVujmP3sA9pJ
	aLZSGBw7NhXtCuDWgJR = [NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ]
	if bLw0V1a5WfHd4uzQR2iv: ntDbV4lpe3WzTJ = ntDbV4lpe3WzTJ.replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,NdKhAS6MXVEORLTwob92pxlZ).replace(Whef0cxB2iR93SC5IwUtk,NdKhAS6MXVEORLTwob92pxlZ).replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)
	else: bLw0V1a5WfHd4uzQR2iv = Ng4e6LpJBxa5rlI
	Y4v6B0mMGkrxzOJ,mqgWoY2a3fw9MUB = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧ࡝ࡶࠪধ"),H9cMF21gLJSv3tA5CPYXza
	jDmwtZLPpTQKboI = pnHgvFOCBZzc08yULQJGIqw9bf(u"࠺࠲୘")*Vwgflszp4WRA93kx6hvdua21HX5cOb if J92gCnbGWidQV70lBteTwU6D8uyzL else IlL8ZnX74Yvep(u"࠸࠷ୗ")*Vwgflszp4WRA93kx6hvdua21HX5cOb
	WbDdM9mFnYRZzpkI5aoqKeUfXB7 = TQNS6YMKAqnilsVObLpDRX*Y4v6B0mMGkrxzOJ
	if ntDbV4lpe3WzTJ.startswith(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩন")): ntDbV4lpe3WzTJ = kb2icmDGVUZfW1OFz7sv(u"ࠩ࠱ࡠࡹ࠭঩")+ntDbV4lpe3WzTJ
	if CB2TcZaokLhA3dQOgjPywzGuxXq7EI in bLw0V1a5WfHd4uzQR2iv: k02Re7AMjyXgBsI5iKTmr = ACOWB6GRmIbDKyl3Zn.LOGERROR
	if bLw0V1a5WfHd4uzQR2iv in [Ng4e6LpJBxa5rlI,CB2TcZaokLhA3dQOgjPywzGuxXq7EI]: aLZSGBw7NhXtCuDWgJR = [ntDbV4lpe3WzTJ]
	elif bLw0V1a5WfHd4uzQR2iv==sSHvJFeTkhoE8KnuNWwljAg3mX16: aLZSGBw7NhXtCuDWgJR = ntDbV4lpe3WzTJ.split(mqgWoY2a3fw9MUB)
	elif bLw0V1a5WfHd4uzQR2iv==CSF2xtI1Yg5baHPJqZdOj9Ah:
		n5w3CRodyczAelGWjuNHm2ZV = ntDbV4lpe3WzTJ.split(mqgWoY2a3fw9MUB)
		aLZSGBw7NhXtCuDWgJR = [n5w3CRodyczAelGWjuNHm2ZV[e8XhbyuzvjYkIsJUtB5w]]
		for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(llxMLe4gobHhsj1WGvd7qmIU,len(n5w3CRodyczAelGWjuNHm2ZV),cCRvAuJQfjBpTg0PbYiaNO87):
			try: GObkRFtLCBIdpAScVJH01vue = n5w3CRodyczAelGWjuNHm2ZV[Lw25iFJMOgNEora84dkT0Hx7Zcpj]+mqgWoY2a3fw9MUB+n5w3CRodyczAelGWjuNHm2ZV[Lw25iFJMOgNEora84dkT0Hx7Zcpj+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠱୙")]
			except: GObkRFtLCBIdpAScVJH01vue = n5w3CRodyczAelGWjuNHm2ZV[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
			aLZSGBw7NhXtCuDWgJR.append(GObkRFtLCBIdpAScVJH01vue)
	jWiZCPdGvY9Hptfbecxmy5EN = aLZSGBw7NhXtCuDWgJR[e8XhbyuzvjYkIsJUtB5w]
	for HR3U1ZcNgzoIifnu5tBA in aLZSGBw7NhXtCuDWgJR[llxMLe4gobHhsj1WGvd7qmIU:]:
		if bLw0V1a5WfHd4uzQR2iv in [sSHvJFeTkhoE8KnuNWwljAg3mX16,CSF2xtI1Yg5baHPJqZdOj9Ah]: WbDdM9mFnYRZzpkI5aoqKeUfXB7 += Y4v6B0mMGkrxzOJ
		jWiZCPdGvY9Hptfbecxmy5EN += SSDnd9QAUwo86G7eurKlaPikE3qsv+jDmwtZLPpTQKboI+WbDdM9mFnYRZzpkI5aoqKeUfXB7+HR3U1ZcNgzoIifnu5tBA
	jWiZCPdGvY9Hptfbecxmy5EN += WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࠤࡤ࠭প")
	if gniNItGL6bKwpEW(u"ࠫࠪ࠭ফ") in jWiZCPdGvY9Hptfbecxmy5EN: jWiZCPdGvY9Hptfbecxmy5EN = OOFEmwq2GkTz93WXy1Nj(jWiZCPdGvY9Hptfbecxmy5EN)
	ACOWB6GRmIbDKyl3Zn.log(jWiZCPdGvY9Hptfbecxmy5EN,level=k02Re7AMjyXgBsI5iKTmr)
	return
def WEABULZXvMdCTxicg3(BhYaS5uGWnLvfAE3t82e):
	try: Yo5K7kXcjOVq2SiTvludJ48f = moKCtu35ZJgji1UXIS0srpELB.connect(BhYaS5uGWnLvfAE3t82e,check_same_thread=hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࡌࡡ࡭ࡵࡨ஗"))
	except:
		if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(vJQYPbL42F013CRoqtEUI):
			IIPNcsCvQnOZk0yejJKl4BtgSrMw.makedirs(vJQYPbL42F013CRoqtEUI)
			Yo5K7kXcjOVq2SiTvludJ48f = moKCtu35ZJgji1UXIS0srpELB.connect(BhYaS5uGWnLvfAE3t82e,check_same_thread=lRP6GTaZJA1Xw3egLM4(u"ࡆࡢ࡮ࡶࡩ஘"))
	Yo5K7kXcjOVq2SiTvludJ48f.text_factory = str
	ODXQpWsKqya39FEctSmlRJ84rkM7vI = Yo5K7kXcjOVq2SiTvludJ48f.cursor()
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(IlL8ZnX74Yvep(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫব"))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(lrtFSogC8Nh9(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩࡨࡰࡲࡶࡪࡥࡣࡩࡧࡦ࡯ࡤࡩ࡯࡯ࡵࡷࡶࡦ࡯࡮ࡵࡵࡀࡽࡪࡹ࠻ࠨভ"))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(NOrchaEV1iIZ87Uzlwgum(u"ࠧࡑࡔࡄࡋࡒࡇࠠ࡫ࡱࡸࡶࡳࡧ࡬ࡠ࡯ࡲࡨࡪࡃࡏࡇࡈ࠾ࠫম"))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(V0VZk9763fusTReHFo4(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫয"))
	eyscIJr8U9dTtFVbhPx5 = FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,OOkmZiVcfqlEurM1dHGb(u"ࠩࡅࡉࡌࡏࡎࠡࡋࡐࡑࡊࡊࡉࡂࡖࡈࠤ࡙ࡘࡁࡏࡕࡄࡇ࡙ࡏࡏࡏࠢ࠾ࠫর"))
	if eyscIJr8U9dTtFVbhPx5: Yo5K7kXcjOVq2SiTvludJ48f.commit()
	else:
		kaZwJ6ofBcYmeD()
	return Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI
def FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,jTesSiJA1u7EWlaOD,IRXuPmjEGH0bnti1y,UkpR586ibCXhaVmS4N=()):
	try:
		if jTesSiJA1u7EWlaOD: ODXQpWsKqya39FEctSmlRJ84rkM7vI.executemany(IRXuPmjEGH0bnti1y,UkpR586ibCXhaVmS4N)
		else: ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(IRXuPmjEGH0bnti1y,UkpR586ibCXhaVmS4N)
		Yo5K7kXcjOVq2SiTvludJ48f.commit()
		eyscIJr8U9dTtFVbhPx5 = k6apiPAlLKM1ed8J42RjHh0o
	except:
		eyscIJr8U9dTtFVbhPx5,timeout = f4vncKMRlXG9s,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠲࠲୚")
		PlmANRecw7HQu3K1UzJ = XJ62UBRmIqFvfiNTQj.time()
		while XJ62UBRmIqFvfiNTQj.time()-PlmANRecw7HQu3K1UzJ<timeout and not eyscIJr8U9dTtFVbhPx5:
			try:
				if jTesSiJA1u7EWlaOD: ODXQpWsKqya39FEctSmlRJ84rkM7vI.executemany(IRXuPmjEGH0bnti1y,UkpR586ibCXhaVmS4N)
				else: ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(IRXuPmjEGH0bnti1y,UkpR586ibCXhaVmS4N)
				Yo5K7kXcjOVq2SiTvludJ48f.commit()
				eyscIJr8U9dTtFVbhPx5 = k6apiPAlLKM1ed8J42RjHh0o
			except: XJ62UBRmIqFvfiNTQj.sleep(pnHgvFOCBZzc08yULQJGIqw9bf(u"࠲࠱࠹୛"))
		if not eyscIJr8U9dTtFVbhPx5:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,rNyT0edugn(u"ࠪ࠲ࡡࡺࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡺࡶ࡮ࡺࡥࠡࡶࡲࠤࡹ࡮ࡥࠡࡦࡤࡸࡦࡨࡡࡴࡧࠣࡪ࡮ࡲࡥࠡࠢࠣࠫ঱")+BhYaS5uGWnLvfAE3t82e+gniNItGL6bKwpEW(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡸࡪࡨࡲࠥ࡫ࡸࡦࡥࡸࡸ࡮ࡴࡧࠡࡶ࡫࡭ࡸࠦࡳࡵࡣࡷࡩࡲ࡫࡮ࡵࠢࠣࠤࠬল")+IRXuPmjEGH0bnti1y+B6IrC7zEHlw1oaeWf)
			import PNC7bFKMI6
			PNC7bFKMI6.kkDz5sdaPteM(gniNItGL6bKwpEW(u"ࠬ็ิๅࠢไ๎่ࠥวฺัฬࠤฬ๊ศ๋ษ้หฯ࠭঳"),PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧ঴"))
	return eyscIJr8U9dTtFVbhPx5
def hVmfOZ06UbnD2odNq(BhYaS5uGWnLvfAE3t82e,DD6cpk8Q1ryURVAtg7N9OHu,RqHScxuyQDweA,JBRVe7WO26yLdgnSs=None):
	dJC476xoE1ecpm0 = nbMFEayeDC1S3UVq7oid8(DD6cpk8Q1ryURVAtg7N9OHu)
	CSHxmGj6O01AWEXVoRcK = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(lrtFSogC8Nh9(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭঵"))
	if RqHScxuyQDweA not in [OOkmZiVcfqlEurM1dHGb(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫশ"),xY4icgQUj6mPVs73CTKu(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡅࡑࡒࠧষ"),lRP6GTaZJA1Xw3egLM4(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡌࡕࡏࡈࡎࡈࠫস")] and BhYaS5uGWnLvfAE3t82e==ZFMPvkNQbT2cHiUj and JBRVe7WO26yLdgnSs!=NOrchaEV1iIZ87Uzlwgum(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭হ"):
		if CSHxmGj6O01AWEXVoRcK==xY4icgQUj6mPVs73CTKu(u"࡙ࠬࡔࡐࡒࠪ঺"): return dJC476xoE1ecpm0
		xmYofc7HByzQqEh81L2b6V = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OOkmZiVcfqlEurM1dHGb(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ঻"))
		if xmYofc7HByzQqEh81L2b6V==gniNItGL6bKwpEW(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋ়ࠧ"):
			WUM9Xg1RHz(BhYaS5uGWnLvfAE3t82e,RqHScxuyQDweA,JBRVe7WO26yLdgnSs)
			return dJC476xoE1ecpm0
	UBMWbspGt7gX5nDkyrSAR3lN6vIi = e8XhbyuzvjYkIsJUtB5w
	if CSHxmGj6O01AWEXVoRcK==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩঽ"): UBMWbspGt7gX5nDkyrSAR3lN6vIi = iiNnbh6pks9GFul0UJvaAMjq8DLCO
	Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(BhYaS5uGWnLvfAE3t82e)
	Ip9AaYd2qlbMoefD3TO5v0gXc8 = ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(V0VZk9763fusTReHFo4(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡱࡥࡲ࡫ࠠࡇࡔࡒࡑࠥࡹࡱ࡭࡫ࡷࡩࡤࡳࡡࡴࡶࡨࡶࠥ࡝ࡈࡆࡔࡈࠤࡹࡿࡰࡦ࠿ࠥࡸࡦࡨ࡬ࡦࠤࠣࡅࡓࡊࠠ࡯ࡣࡰࡩࡂࠨࠧা")+RqHScxuyQDweA+kb2icmDGVUZfW1OFz7sv(u"ࠪࠦࠥࡁࠧি")).fetchall()
	if Ip9AaYd2qlbMoefD3TO5v0gXc8:
		if UBMWbspGt7gX5nDkyrSAR3lN6vIi: FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫী")+RqHScxuyQDweA+PzIpQnUXxRwNCivDhdakWTE(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡄࠧু")+str(MMQhDpyCenmO350aBAKVYk+UBMWbspGt7gX5nDkyrSAR3lN6vIi)+Hlp3z0APt1GR4kMYK5xST(u"࠭ࠠ࠼ࠩূ"))
		FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,fOc18oTm5hsdD4pVZQj(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧৃ")+RqHScxuyQDweA+lRP6GTaZJA1Xw3egLM4(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺ࠾ࠪৄ")+str(MMQhDpyCenmO350aBAKVYk)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࠣ࠿ࠬ৅"))
		if JBRVe7WO26yLdgnSs:
			VGWN7mTCwUs8p0LuR = (str(JBRVe7WO26yLdgnSs),)
			ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ৆")+RqHScxuyQDweA+hCm2fnEXs6Zt(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫে"),VGWN7mTCwUs8p0LuR)
			r2EUDqT1KdNxH = ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()
			if r2EUDqT1KdNxH:
				try:
					HSb5r1Di9I8eKTtAyuNZdC4W = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.decompress(r2EUDqT1KdNxH[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w])
					dJC476xoE1ecpm0 = Q4V2fcRKHG.loads(HSb5r1Di9I8eKTtAyuNZdC4W)
				except: pass
		else:
			ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(gniNItGL6bKwpEW(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠤࠪৈ")+RqHScxuyQDweA+NeU6uRGpECkvMV5jf(u"࠭ࠢࠡ࠽ࠪ৉"))
			r2EUDqT1KdNxH = ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()
			if r2EUDqT1KdNxH:
				dJC476xoE1ecpm0,c8kgU9IKShml3JWZ6j = {},[]
				for ooPXd6jmKGCWp7s3FLSfncklUJ8D,OzUD8iTmGp15Sn9VINMHq in r2EUDqT1KdNxH:
					RM17uFVste3pJLBhjcn = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.decompress(OzUD8iTmGp15Sn9VINMHq)
					OzUD8iTmGp15Sn9VINMHq = Q4V2fcRKHG.loads(RM17uFVste3pJLBhjcn)
					dJC476xoE1ecpm0[ooPXd6jmKGCWp7s3FLSfncklUJ8D] = OzUD8iTmGp15Sn9VINMHq
					c8kgU9IKShml3JWZ6j.append(ooPXd6jmKGCWp7s3FLSfncklUJ8D)
				if c8kgU9IKShml3JWZ6j:
					dJC476xoE1ecpm0[lrtFSogC8Nh9(u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ৊")] = c8kgU9IKShml3JWZ6j
					if DD6cpk8Q1ryURVAtg7N9OHu==IlL8ZnX74Yvep(u"ࠨ࡮࡬ࡷࡹ࠭ো"): dJC476xoE1ecpm0 = c8kgU9IKShml3JWZ6j
	Yo5K7kXcjOVq2SiTvludJ48f.close()
	return dJC476xoE1ecpm0
def eMN9D4l8hbiKFyLPHIVkAmB7Jvt(BhYaS5uGWnLvfAE3t82e,RqHScxuyQDweA,JBRVe7WO26yLdgnSs,dJC476xoE1ecpm0,LHdSri9vTneoc4,LV6jAIXRk70x8q=f4vncKMRlXG9s):
	CSHxmGj6O01AWEXVoRcK = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(xY4icgQUj6mPVs73CTKu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨৌ"))
	if CSHxmGj6O01AWEXVoRcK==OOkmZiVcfqlEurM1dHGb(u"ࠪࡐࡎࡓࡉࡕࡇࡇ্ࠫ") and LHdSri9vTneoc4>iiNnbh6pks9GFul0UJvaAMjq8DLCO: LHdSri9vTneoc4 = iiNnbh6pks9GFul0UJvaAMjq8DLCO
	if LV6jAIXRk70x8q:
		nDW6hxsUyd5NtALZ,xIUmE83YCoqO = [],[]
		for XW2Opt4RQsVihunCylz6j in range(len(JBRVe7WO26yLdgnSs)):
			HSb5r1Di9I8eKTtAyuNZdC4W = Q4V2fcRKHG.dumps(dJC476xoE1ecpm0[XW2Opt4RQsVihunCylz6j])
			xvinhNfSWPUJVasrgO7Ro103 = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.compress(HSb5r1Di9I8eKTtAyuNZdC4W)
			nDW6hxsUyd5NtALZ.append((JBRVe7WO26yLdgnSs[XW2Opt4RQsVihunCylz6j],))
			xIUmE83YCoqO.append((LHdSri9vTneoc4+MMQhDpyCenmO350aBAKVYk,str(JBRVe7WO26yLdgnSs[XW2Opt4RQsVihunCylz6j]),xvinhNfSWPUJVasrgO7Ro103))
	else:
		HSb5r1Di9I8eKTtAyuNZdC4W = Q4V2fcRKHG.dumps(dJC476xoE1ecpm0)
		PPu5tl4CMcbgDVWHRBQS = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.compress(HSb5r1Di9I8eKTtAyuNZdC4W)
	Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(BhYaS5uGWnLvfAE3t82e)
	FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,Hlp3z0APt1GR4kMYK5xST(u"ࠫࡈࡘࡅࡂࡖࡈࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡎࡐࡖࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬৎ")+RqHScxuyQDweA+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࠨࠠࠩࡧࡻࡴ࡮ࡸࡹ࠭ࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦ࠯ࠠ࠼ࠩ৏"))
	if LV6jAIXRk70x8q:
		FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,k6apiPAlLKM1ed8J42RjHh0o,fOc18oTm5hsdD4pVZQj(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৐")+RqHScxuyQDweA+HVmIrFwau90jQsgiWzExk(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ৑"),nDW6hxsUyd5NtALZ)
		FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,k6apiPAlLKM1ed8J42RjHh0o,JGwsL21ZRlqSrWxEmF(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ৒")+RqHScxuyQDweA+lNTJCZeBicWEz0Mg(u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ৓"),xIUmE83YCoqO)
	else:
		if LHdSri9vTneoc4:
			VGWN7mTCwUs8p0LuR = (str(JBRVe7WO26yLdgnSs),)
			FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ৔")+RqHScxuyQDweA+IlL8ZnX74Yvep(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ৕"),VGWN7mTCwUs8p0LuR)
			VGWN7mTCwUs8p0LuR = (LHdSri9vTneoc4+MMQhDpyCenmO350aBAKVYk,str(JBRVe7WO26yLdgnSs),PPu5tl4CMcbgDVWHRBQS)
			FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,Hlp3z0APt1GR4kMYK5xST(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ৖")+RqHScxuyQDweA+PzIpQnUXxRwNCivDhdakWTE(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫৗ"),VGWN7mTCwUs8p0LuR)
		else:
			VGWN7mTCwUs8p0LuR = (PPu5tl4CMcbgDVWHRBQS,str(JBRVe7WO26yLdgnSs))
			FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࠣࠩ৘")+RqHScxuyQDweA+PzIpQnUXxRwNCivDhdakWTE(u"ࠨࠤࠣࡗࡊ࡚ࠠࡥࡣࡷࡥࠥࡃࠠࡀ࡚ࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ৙"),VGWN7mTCwUs8p0LuR)
	Yo5K7kXcjOVq2SiTvludJ48f.close()
	return
def WUM9Xg1RHz(BhYaS5uGWnLvfAE3t82e,RqHScxuyQDweA,JBRVe7WO26yLdgnSs=None):
	Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(BhYaS5uGWnLvfAE3t82e)
	if JBRVe7WO26yLdgnSs==None: FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,lrtFSogC8Nh9(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ৚")+RqHScxuyQDweA+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࠦࠥࡁࠧ৛"))
	else:
		Ip9AaYd2qlbMoefD3TO5v0gXc8 = ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(kb2icmDGVUZfW1OFz7sv(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡳࡧ࡭ࡦࠢࡉࡖࡔࡓࠠࡴࡳ࡯࡭ࡹ࡫࡟࡮ࡣࡶࡸࡪࡸࠠࡘࡊࡈࡖࡊࠦࡴࡺࡲࡨࡁࠧࡺࡡࡣ࡮ࡨࠦࠥࡇࡎࡅࠢࡱࡥࡲ࡫࠽ࠣࠩড়")+RqHScxuyQDweA+eGW7cI6aQhr0(u"ࠬࠨࠠ࠼ࠩঢ়")).fetchall()
		if Ip9AaYd2qlbMoefD3TO5v0gXc8:
			VGWN7mTCwUs8p0LuR = (str(JBRVe7WO26yLdgnSs),)
			if fOc18oTm5hsdD4pVZQj(u"࠭ࠥࠨ৞") in JBRVe7WO26yLdgnSs: FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,lNTJCZeBicWEz0Mg(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧয়")+RqHScxuyQDweA+fOc18oTm5hsdD4pVZQj(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫৠ"),VGWN7mTCwUs8p0LuR)
			else: FTyrf7ZzDNBLQo8KVgmds6JAieku(BhYaS5uGWnLvfAE3t82e,Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI,f4vncKMRlXG9s,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩৡ")+RqHScxuyQDweA+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪৢ"),VGWN7mTCwUs8p0LuR)
	Yo5K7kXcjOVq2SiTvludJ48f.close()
	return
class ROiFkL1eHKz2n8x0(): pass
class CDtdAcPSKah(ROiFkL1eHKz2n8x0):
	def __init__(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.url = NdKhAS6MXVEORLTwob92pxlZ
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.code = -rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠼࠽ଡ଼")
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.reason = NdKhAS6MXVEORLTwob92pxlZ
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.content = NdKhAS6MXVEORLTwob92pxlZ
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.headers = {}
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.cookies = {}
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.succeeded = f4vncKMRlXG9s
def nbMFEayeDC1S3UVq7oid8(GY9jgon6yhP0IvtCBEJu3):
	if GY9jgon6yhP0IvtCBEJu3==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡩ࡯ࡣࡵࠩৣ"): dJC476xoE1ecpm0 = {}
	elif GY9jgon6yhP0IvtCBEJu3==fOc18oTm5hsdD4pVZQj(u"ࠬࡲࡩࡴࡶࠪ৤"): dJC476xoE1ecpm0 = []
	elif GY9jgon6yhP0IvtCBEJu3==R3lezw8h407ZvrAFxT(u"࠭ࡴࡶࡲ࡯ࡩࠬ৥"): dJC476xoE1ecpm0 = ()
	elif GY9jgon6yhP0IvtCBEJu3==HVmIrFwau90jQsgiWzExk(u"ࠧࡴࡶࡵࠫ০"): dJC476xoE1ecpm0 = NdKhAS6MXVEORLTwob92pxlZ
	elif GY9jgon6yhP0IvtCBEJu3==lRP6GTaZJA1Xw3egLM4(u"ࠨ࡫ࡱࡸࠬ১"): dJC476xoE1ecpm0 = e8XhbyuzvjYkIsJUtB5w
	elif GY9jgon6yhP0IvtCBEJu3==wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ২"): dJC476xoE1ecpm0 = CDtdAcPSKah()
	elif not GY9jgon6yhP0IvtCBEJu3: dJC476xoE1ecpm0 = None
	else: dJC476xoE1ecpm0 = None
	return dJC476xoE1ecpm0
def JcQtOuhMdvYSyLNCw(VVKnuIpqewFGJMRlC7L):
	vmT7Wn3GhHXQcf8ZRbVA = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭৩"))
	PPUtBrAcTHC56ypsVgaQ7JGeRl3LF = lop0ZwWYLmxOPAaErzF6cQvDkVR.splitlines()
	hRCWslpkZva = e8XhbyuzvjYkIsJUtB5w
	C46lKH0Xv2ujFSZfry = len(VVKnuIpqewFGJMRlC7L)
	E0R3FKYyUxO4gfwe = [f4vncKMRlXG9s]*C46lKH0Xv2ujFSZfry
	for IINSgkbFRmaQUcxlpeOGus in [MMQhDpyCenmO350aBAKVYk,MMQhDpyCenmO350aBAKVYk-NXpO8DrVmeE]:
		MGemRJ3OUKCYj671DXr8zPZ = str(IINSgkbFRmaQUcxlpeOGus*QQHFtjcaR2VpnSyTIv(u"࠶࠶࠰࠱࠲࠳࠲࠵୞")/OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠸࠸࠸࠰࠱࠲ଢ଼"))[e8XhbyuzvjYkIsJUtB5w:ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠺ୟ")]
		if MGemRJ3OUKCYj671DXr8zPZ!=hRCWslpkZva:
			for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(C46lKH0Xv2ujFSZfry):
				if not E0R3FKYyUxO4gfwe[Lw25iFJMOgNEora84dkT0Hx7Zcpj]:
					zPhBukdGmV03IW = f4vncKMRlXG9s
					for CCqTLebP1Z9XQdA in PPUtBrAcTHC56ypsVgaQ7JGeRl3LF:
						NlOWPvzYkn7J3qa0gwFe6DdKu = NOrchaEV1iIZ87Uzlwgum(u"ࠫ࡝࠷࠹ࠨ৪")+VVKnuIpqewFGJMRlC7L[Lw25iFJMOgNEora84dkT0Hx7Zcpj]+lrtFSogC8Nh9(u"ࠬ࠷࠸࠾ࠩ৫")+CCqTLebP1Z9XQdA[-NeU6uRGpECkvMV5jf(u"࠲࠵ୠ"):]+lvsJ2jaZktmNO6PbdXS+MGemRJ3OUKCYj671DXr8zPZ
						NlOWPvzYkn7J3qa0gwFe6DdKu = f6ZTNntQrRHd.md5(NlOWPvzYkn7J3qa0gwFe6DdKu.encode(YRvPKe2zMTDs8UCkr)).hexdigest()[:WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠴࠴ୡ")]
						if NlOWPvzYkn7J3qa0gwFe6DdKu in vmT7Wn3GhHXQcf8ZRbVA:
							zPhBukdGmV03IW = k6apiPAlLKM1ed8J42RjHh0o
							break
					E0R3FKYyUxO4gfwe[Lw25iFJMOgNEora84dkT0Hx7Zcpj] = zPhBukdGmV03IW
		hRCWslpkZva = MGemRJ3OUKCYj671DXr8zPZ
	return E0R3FKYyUxO4gfwe
class hsYPN5GySKWZJoQdrkqARljF0TD(qep24AhtFvKTGMkDfl6YmLiVSyo):
	def __init__(amPWXzZ9NCIHtDSfeOGiwxrK8Moc): pass
	def d97bAUB5nJYN2xap03LqQ1tjIDcGPW(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,fmuMAVvP58kJ):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = Hlp3z0APt1GR4kMYK5xST(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ৬") if OMNiY8joQx.HHqA8u41iPZ else NdKhAS6MXVEORLTwob92pxlZ
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.fmuMAVvP58kJ = fmuMAVvP58kJ
		if not OMNiY8joQx.WiJPMTZvOLGsV0xB8al:
			import PNC7bFKMI6
			PNC7bFKMI6.kyCTNqxg9hBKocfXW(MIT0n79k8beo26aJHW)
	def onPlayBackStopped(amPWXzZ9NCIHtDSfeOGiwxrK8Moc): amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ৭")
	def onPlayBackError(amPWXzZ9NCIHtDSfeOGiwxrK8Moc): amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = xY4icgQUj6mPVs73CTKu(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ৮")
	def onPlayBackEnded(amPWXzZ9NCIHtDSfeOGiwxrK8Moc): amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = hCm2fnEXs6Zt(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ৯")
	def onPlayBackStarted(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = eGW7cI6aQhr0(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫৰ")
		yRFzaHWohjCieIG2gv5J7mc3kAKOVf = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=amPWXzZ9NCIHtDSfeOGiwxrK8Moc.HTzjpu6SRivdB9qU8,args=())
		yRFzaHWohjCieIG2gv5J7mc3kAKOVf.start()
	def onAVStarted(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		if OMNiY8joQx.WiJPMTZvOLGsV0xB8al: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = fOc18oTm5hsdD4pVZQj(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬৱ")
		else: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭৲")
	def HTzjpu6SRivdB9qU8(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		vyQfmxGsUX5BSM7Hzq2lEdb6j(gniNItGL6bKwpEW(u"࠭ࡳࡵࡱࡳࠫ৳"))
		WpzKmaJwVo7YGClFS = e8XhbyuzvjYkIsJUtB5w
		while not eval(R3lezw8h407ZvrAFxT(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬ৴"),{JGwsL21ZRlqSrWxEmF(u"ࠨࡺࡥࡱࡨ࠭৵"):ACOWB6GRmIbDKyl3Zn}) and amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47==eGW7cI6aQhr0(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ৶"):
			ACOWB6GRmIbDKyl3Zn.sleep(LtGoXlQ2IYxqTJRySE6udfW98(u"࠳࠳࠴࠵ୢ"))
			WpzKmaJwVo7YGClFS += llxMLe4gobHhsj1WGvd7qmIU
			if WpzKmaJwVo7YGClFS>fOc18oTm5hsdD4pVZQj(u"࠹࠴ୣ"): return
		if OMNiY8joQx.HHqA8u41iPZ: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৷")
		elif OMNiY8joQx.WiJPMTZvOLGsV0xB8al: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ৸")
		elif OMNiY8joQx.ZIWy6VLs8hNkbrExYSjM3OXDUaRGmo:
			import PNC7bFKMI6
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭৹")
			qmW74EDsgIkbfFKXPv86i10 = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=PNC7bFKMI6.XXaQrd76gFzMAPNGycuUHtK9pk,args=(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.fmuMAVvP58kJ,))
			qmW74EDsgIkbfFKXPv86i10.start()
			tMGHB4xZrUFgc7hCVAN = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=PNC7bFKMI6.FVab3jTRmkLU8e,args=())
			tMGHB4xZrUFgc7hCVAN.start()
		else: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.w6skcmfJ47 = NeU6uRGpECkvMV5jf(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ৺")
def Vu5pagTPrJDscLdNkUCy79KfS16():
	Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	mXb5uJg3KpRiNvL49o = ACOWB6GRmIbDKyl3Zn.getInfoLabel(HVmIrFwau90jQsgiWzExk(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭৻"))
	try:
		ccF5pPU6AbG8esN409DKSihX = open(hCm2fnEXs6Zt(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨৼ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡵࡦࠬ৽")).read()
		if J92gCnbGWidQV70lBteTwU6D8uyzL: ccF5pPU6AbG8esN409DKSihX = ccF5pPU6AbG8esN409DKSihX.decode(YRvPKe2zMTDs8UCkr)
		sxfVnWS3B1mgewHzoFMYJ = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧ৾"),ccF5pPU6AbG8esN409DKSihX,YYqECUofyi7wFrW.IGNORECASE)
		if sxfVnWS3B1mgewHzoFMYJ: Fc5A1JmGIobRjiEuZxyngDkh3KQ = sxfVnWS3B1mgewHzoFMYJ[e8XhbyuzvjYkIsJUtB5w]
	except: pass
	try:
		import subprocess as AkxWe21r8J4R
		hAYrRbmFzE = AkxWe21r8J4R.Popen(NeU6uRGpECkvMV5jf(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩ৿"),shell=k6apiPAlLKM1ed8J42RjHh0o,stdin=AkxWe21r8J4R.PIPE,stdout=AkxWe21r8J4R.PIPE,stderr=AkxWe21r8J4R.PIPE)
		RlxVbn3Mfg = hAYrRbmFzE.stdout.read()
		if RlxVbn3Mfg:
			if J92gCnbGWidQV70lBteTwU6D8uyzL:
				RlxVbn3Mfg = RlxVbn3Mfg.decode(YRvPKe2zMTDs8UCkr,gniNItGL6bKwpEW(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ਀"))
			FF0BSCWUwhYGPVvOD1H7b5y8L = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"࠭ࠠࠩ࡞ࡧࡿ࠶࠶ࡽࠪࠢࠪਁ"),RlxVbn3Mfg,YYqECUofyi7wFrW.IGNORECASE)
			if FF0BSCWUwhYGPVvOD1H7b5y8L: KKS3p7OEJiWlDUHj = min(FF0BSCWUwhYGPVvOD1H7b5y8L)
	except: pass
	return mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj
def nvHz4MPEfa6Q1D5cydq(c29x6E7e8pYaXk=k6apiPAlLKM1ed8J42RjHh0o,oyKXHTUM7ra=LtGoXlQ2IYxqTJRySE6udfW98(u"࠷࠷୤")):
	YnwFOKub5D0MkVxvBlEsR7d2g1f = k6apiPAlLKM1ed8J42RjHh0o
	if c29x6E7e8pYaXk:
		bQDhzHVCdFmtckRxiqOs3 = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,hCm2fnEXs6Zt(u"ࠧ࡭࡫ࡶࡸࠬਂ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਃ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ਄"))
		if bQDhzHVCdFmtckRxiqOs3:
			AVfOuvBzyP1,W0ORwsexyiFh,AcxpR485tmHvub3OkI,PpMKQ5xCUt = bQDhzHVCdFmtckRxiqOs3
			YnwFOKub5D0MkVxvBlEsR7d2g1f = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,lrtFSogC8Nh9(u"ࠪࡰ࡮ࡹࡴࠨਅ"),gniNItGL6bKwpEW(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧਆ"),JGwsL21ZRlqSrWxEmF(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫਇ"))
			if YnwFOKub5D0MkVxvBlEsR7d2g1f: mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj = YnwFOKub5D0MkVxvBlEsR7d2g1f
			else: mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj = Vu5pagTPrJDscLdNkUCy79KfS16()
			if (W0ORwsexyiFh,AcxpR485tmHvub3OkI,PpMKQ5xCUt)==(mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj):
				AFhqO14UzYdBK8bZfxcNkTsg = B6IrC7zEHlw1oaeWf.join(AVfOuvBzyP1)
				return AFhqO14UzYdBK8bZfxcNkTsg
	if YnwFOKub5D0MkVxvBlEsR7d2g1f: mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj = Vu5pagTPrJDscLdNkUCy79KfS16()
	global W7TauAif06OobrStYxUmjGNQ8v,Pui4RUfJcrI3T0kdHxvBQZhpe
	W7TauAif06OobrStYxUmjGNQ8v,Pui4RUfJcrI3T0kdHxvBQZhpe,sEJDRH2wG1cS = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	oyKXHTUM7ra = oyKXHTUM7ra//cCRvAuJQfjBpTg0PbYiaNO87
	ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=qiLe7GHDBCkPg).start()
	ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=DPa9g78Qvm4RkinTBWNjX26xYK).start()
	for XW2Opt4RQsVihunCylz6j in range(Tzx81Wb0RZC4ID5AyiU2(u"࠶࠶୥")):
		XJ62UBRmIqFvfiNTQj.sleep(kb2icmDGVUZfW1OFz7sv(u"࠶࠮࠶୦"))
		if not sEJDRH2wG1cS:
			try:
				vv1C2IMruSmf8RBNaXVPbGYzK = ACOWB6GRmIbDKyl3Zn.getInfoLabel(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡎࡣࡦࡅࡩࡪࡲࡦࡵࡶࠫਈ"))
				if vv1C2IMruSmf8RBNaXVPbGYzK.count(NeU6uRGpECkvMV5jf(u"ࠧ࠻ࠩਉ"))==lRP6GTaZJA1Xw3egLM4(u"࠶୨") and vv1C2IMruSmf8RBNaXVPbGYzK.count(R3lezw8h407ZvrAFxT(u"ࠨ࠲ࠪਊ"))<lNTJCZeBicWEz0Mg(u"࠹୧"):
					vv1C2IMruSmf8RBNaXVPbGYzK = vv1C2IMruSmf8RBNaXVPbGYzK.lower().replace(V0VZk9763fusTReHFo4(u"ࠩ࠽ࠫ਋"),NdKhAS6MXVEORLTwob92pxlZ)
					sEJDRH2wG1cS = str(int(vv1C2IMruSmf8RBNaXVPbGYzK,lrtFSogC8Nh9(u"࠳࠹୩")))
			except: pass
		if W7TauAif06OobrStYxUmjGNQ8v and Pui4RUfJcrI3T0kdHxvBQZhpe and sEJDRH2wG1cS: break
	adpl3RZkg8rjxz4u6hFoM7v = [Pui4RUfJcrI3T0kdHxvBQZhpe,W7TauAif06OobrStYxUmjGNQ8v,sEJDRH2wG1cS,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭਌")]
	if Fc5A1JmGIobRjiEuZxyngDkh3KQ or KKS3p7OEJiWlDUHj:
		JHYgNDaUV3CzF8 = [(TQNS6YMKAqnilsVObLpDRX,Fc5A1JmGIobRjiEuZxyngDkh3KQ),(lrtFSogC8Nh9(u"࠸୪"),KKS3p7OEJiWlDUHj)]
		for V9fBFLnGeItlHmYgE1Xi0xvWPz,m6I48ydkMWlQN in JHYgNDaUV3CzF8:
			m6I48ydkMWlQN = m6I48ydkMWlQN.strip(IlL8ZnX74Yvep(u"ࠫ࠵࠭਍"))
			if m6I48ydkMWlQN:
				if J92gCnbGWidQV70lBteTwU6D8uyzL: m6I48ydkMWlQN = m6I48ydkMWlQN.encode(YRvPKe2zMTDs8UCkr)
				m6I48ydkMWlQN = str(int(f6ZTNntQrRHd.md5(m6I48ydkMWlQN).hexdigest(),R3lezw8h407ZvrAFxT(u"࠷࠻୫")))
				O4IsMzYKuUFdSn1abVD25Axy0H = [int(m6I48ydkMWlQN[dCY5i6qRPtXBwAxrMyh32W1:dCY5i6qRPtXBwAxrMyh32W1+wP4kpvXoDHq3hs7TFLyr2COn8(u"࠷࠵୭")]) for dCY5i6qRPtXBwAxrMyh32W1 in range(len(m6I48ydkMWlQN)) if dCY5i6qRPtXBwAxrMyh32W1%wP4kpvXoDHq3hs7TFLyr2COn8(u"࠷࠵୭")==HVmIrFwau90jQsgiWzExk(u"࠵୬")]
				adpl3RZkg8rjxz4u6hFoM7v[V9fBFLnGeItlHmYgE1Xi0xvWPz-llxMLe4gobHhsj1WGvd7qmIU] = str(sum(O4IsMzYKuUFdSn1abVD25Axy0H))
	PPUtBrAcTHC56ypsVgaQ7JGeRl3LF,hN2Tn4UbpFv135 = [],f4vncKMRlXG9s
	for C0ygbXYVOjscP5M781kdWUN2SGEru,O4IsMzYKuUFdSn1abVD25Axy0H in enumerate(adpl3RZkg8rjxz4u6hFoM7v):
		if not O4IsMzYKuUFdSn1abVD25Axy0H: continue
		if hN2Tn4UbpFv135 and O4IsMzYKuUFdSn1abVD25Axy0H==adpl3RZkg8rjxz4u6hFoM7v[-llxMLe4gobHhsj1WGvd7qmIU]: continue
		hN2Tn4UbpFv135 = k6apiPAlLKM1ed8J42RjHh0o
		O4IsMzYKuUFdSn1abVD25Axy0H = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࠶ࠧ਎")*oyKXHTUM7ra+O4IsMzYKuUFdSn1abVD25Axy0H
		O4IsMzYKuUFdSn1abVD25Axy0H = O4IsMzYKuUFdSn1abVD25Axy0H[-oyKXHTUM7ra:]
		WOQdbg1RrFD2k97vE,K7KECbXx09TwqId = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		f1Jk4I3ORepnryKBMWE8z = str(int(V0VZk9763fusTReHFo4(u"࠭࠹ࠨਏ")*(oyKXHTUM7ra+llxMLe4gobHhsj1WGvd7qmIU))-int(O4IsMzYKuUFdSn1abVD25Axy0H))[-oyKXHTUM7ra:]
		for Lw25iFJMOgNEora84dkT0Hx7Zcpj in list(range(e8XhbyuzvjYkIsJUtB5w,oyKXHTUM7ra,TQNS6YMKAqnilsVObLpDRX)):
			WOQdbg1RrFD2k97vE += f1Jk4I3ORepnryKBMWE8z[Lw25iFJMOgNEora84dkT0Hx7Zcpj:Lw25iFJMOgNEora84dkT0Hx7Zcpj+TQNS6YMKAqnilsVObLpDRX]+rNyT0edugn(u"ࠧ࠮ࠩਐ")
			K7KECbXx09TwqId += str(sum(map(int,O4IsMzYKuUFdSn1abVD25Axy0H[Lw25iFJMOgNEora84dkT0Hx7Zcpj:Lw25iFJMOgNEora84dkT0Hx7Zcpj+TQNS6YMKAqnilsVObLpDRX]))%NeU6uRGpECkvMV5jf(u"࠱࠱୮"))
		CCqTLebP1Z9XQdA = str(C0ygbXYVOjscP5M781kdWUN2SGEru)+WOQdbg1RrFD2k97vE+K7KECbXx09TwqId
		PPUtBrAcTHC56ypsVgaQ7JGeRl3LF.append(CCqTLebP1Z9XQdA)
	T9TGyiQosKECPx,AVfOuvBzyP1 = [],[]
	for user in PPUtBrAcTHC56ypsVgaQ7JGeRl3LF:
		count = str(str(PPUtBrAcTHC56ypsVgaQ7JGeRl3LF).count(user[lRP6GTaZJA1Xw3egLM4(u"࠲୯"):]))
		T9TGyiQosKECPx.append(count+user)
	T9TGyiQosKECPx = sorted(T9TGyiQosKECPx,reverse=rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࡕࡴࡸࡩங"),key=lambda key: key[kb2icmDGVUZfW1OFz7sv(u"࠲୰")])
	for user in T9TGyiQosKECPx: AVfOuvBzyP1.append(user[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠴ୱ"):])
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,rNyT0edugn(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ਑"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ਒"),[mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj],h1dnE0q2zFHjXlvyGuLZxw)
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,hCm2fnEXs6Zt(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ਓ"),V0VZk9763fusTReHFo4(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩਔ"),[AVfOuvBzyP1,mXb5uJg3KpRiNvL49o,Fc5A1JmGIobRjiEuZxyngDkh3KQ,KKS3p7OEJiWlDUHj],h1dnE0q2zFHjXlvyGuLZxw)
	for user in skKcVTiAr3QgdYDCbNGuER:
		if user in AVfOuvBzyP1: AVfOuvBzyP1.remove(user)
	AFhqO14UzYdBK8bZfxcNkTsg = B6IrC7zEHlw1oaeWf.join(AVfOuvBzyP1)
	return AFhqO14UzYdBK8bZfxcNkTsg
def qiLe7GHDBCkPg():
	global W7TauAif06OobrStYxUmjGNQ8v
	import getmac82 as k7NiZarsIWx
	try:
		A2kVrRHgPUpq6odj5b = k7NiZarsIWx.get_mac_address()
		if A2kVrRHgPUpq6odj5b.count(lNTJCZeBicWEz0Mg(u"ࠬࡀࠧਕ"))==IlL8ZnX74Yvep(u"࠺୳") and A2kVrRHgPUpq6odj5b.count(gniNItGL6bKwpEW(u"࠭࠰ࠨਖ"))<QQHFtjcaR2VpnSyTIv(u"࠽୲"):
			A2kVrRHgPUpq6odj5b = A2kVrRHgPUpq6odj5b.lower().replace(hCm2fnEXs6Zt(u"ࠧ࠻ࠩਗ"),NdKhAS6MXVEORLTwob92pxlZ)
			W7TauAif06OobrStYxUmjGNQ8v = str(int(A2kVrRHgPUpq6odj5b,NeU6uRGpECkvMV5jf(u"࠷࠶୴")))
	except: pass
	return
def DPa9g78Qvm4RkinTBWNjX26xYK():
	global Pui4RUfJcrI3T0kdHxvBQZhpe
	import getmac94 as NNyoeTfjInJ
	try:
		j2j0VNiCD7h1xBIRtL3PcKyAOWde = NNyoeTfjInJ.get_mac_address()
		if j2j0VNiCD7h1xBIRtL3PcKyAOWde.count(PzIpQnUXxRwNCivDhdakWTE(u"ࠨ࠼ࠪਘ"))==QQHFtjcaR2VpnSyTIv(u"࠶୶") and j2j0VNiCD7h1xBIRtL3PcKyAOWde.count(NOrchaEV1iIZ87Uzlwgum(u"ࠩ࠳ࠫਙ"))<rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠹୵"):
			j2j0VNiCD7h1xBIRtL3PcKyAOWde = j2j0VNiCD7h1xBIRtL3PcKyAOWde.lower().replace(HVmIrFwau90jQsgiWzExk(u"ࠪ࠾ࠬਚ"),NdKhAS6MXVEORLTwob92pxlZ)
			Pui4RUfJcrI3T0kdHxvBQZhpe = str(int(j2j0VNiCD7h1xBIRtL3PcKyAOWde,IlL8ZnX74Yvep(u"࠳࠹୷")))
	except: pass
	return
def hhM2Wn1045PDsl6p8VLA7vIN(GY9jgon6yhP0IvtCBEJu3,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI,fiuheaxH14ZML0):
	omrd89nv0PGKFpL3TxfAXt = str(JoWX5If80G)[e8XhbyuzvjYkIsJUtB5w:R3lezw8h407ZvrAFxT(u"࠵࠹࠵୸")].replace(B6IrC7zEHlw1oaeWf,rNyT0edugn(u"ࠫࡡࡢ࡮ࠨਛ")).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡢ࡜ࡳࠩਜ")).replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if len(str(JoWX5If80G))>IlL8ZnX74Yvep(u"࠶࠺࠶୹"): omrd89nv0PGKFpL3TxfAXt = omrd89nv0PGKFpL3TxfAXt+LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࠠ࠯࠰࠱ࠫਝ")
	OzUD8iTmGp15Sn9VINMHq = str(dJC476xoE1ecpm0)[e8XhbyuzvjYkIsJUtB5w:hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠷࠻࠰୺")].replace(B6IrC7zEHlw1oaeWf,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࡝࡞ࡱࠫਞ")).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NeU6uRGpECkvMV5jf(u"ࠨ࡞࡟ࡶࠬਟ")).replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if len(str(dJC476xoE1ecpm0))>V0VZk9763fusTReHFo4(u"࠸࠵࠱୻"): OzUD8iTmGp15Sn9VINMHq = OzUD8iTmGp15Sn9VINMHq+lNTJCZeBicWEz0Mg(u"ࠩࠣ࠲࠳࠴ࠧਠ")
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,hCm2fnEXs6Zt(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࠬਡ")+GY9jgon6yhP0IvtCBEJu3+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧਢ")+ZZT6GLaHQ1+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧਣ")+xmezOWMyhSXRGHlEk2JnsI+lRP6GTaZJA1Xw3egLM4(u"࠭ࠠ࡞ࠢࠣࠤࡒ࡫ࡴࡩࡱࡧ࠾ࠥࡡࠠࠨਤ")+fiuheaxH14ZML0+kb2icmDGVUZfW1OFz7sv(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪਥ")+str(omrd89nv0PGKFpL3TxfAXt)+V0VZk9763fusTReHFo4(u"ࠨࠢࡠࠤࠥࠦࡄࡢࡶࡤ࠾ࠥࡡࠠࠨਦ")+OzUD8iTmGp15Sn9VINMHq+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࠣࡡࠬਧ"))
	return
def Sn9YGahzUq4b6okfOv0AHEQdtVujNg(ZZT6GLaHQ1):
	S4EOzTvfQ317abKA5kYZGx = [R3lezw8h407ZvrAFxT(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠭ਨ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩࠨ਩"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠪਪ"),HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠭ਫ"),V0VZk9763fusTReHFo4(u"ࠧࡴࡥࡵࡥࡵ࡫ࡵࡱࠩਬ"),HVmIrFwau90jQsgiWzExk(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲࠫਭ")]
	ssvCJXKpVgaULDhrGw2xmZ4 = k6apiPAlLKM1ed8J42RjHh0o if any(K6KbZDHncNizQgl1fr59XV0 in ZZT6GLaHQ1 for K6KbZDHncNizQgl1fr59XV0 in S4EOzTvfQ317abKA5kYZGx) else f4vncKMRlXG9s
	if JGwsL21ZRlqSrWxEmF(u"ࠩࠩࡹࡷࡲ࠽ࠨਮ") in ZZT6GLaHQ1 and ssvCJXKpVgaULDhrGw2xmZ4: Ly6gqD8jB5I9tp2MY3ncEsJ = ZZT6GLaHQ1.rsplit(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࠪࡺࡸ࡬࠾ࠩਯ"),OOkmZiVcfqlEurM1dHGb(u"࠱୼"))[llxMLe4gobHhsj1WGvd7qmIU]
	else: Ly6gqD8jB5I9tp2MY3ncEsJ = NdKhAS6MXVEORLTwob92pxlZ
	hhtgHR5ivXAL9okpjGPEn8K = xKp3jkIvM09AZ4euXa87i5TVtfUD[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫਰ")]
	f1kUIA6ndptORqMcaZusGVw3 = ZZT6GLaHQ1 in hhtgHR5ivXAL9okpjGPEn8K or Ly6gqD8jB5I9tp2MY3ncEsJ in hhtgHR5ivXAL9okpjGPEn8K
	PqZAgIysiukFjtTKQn6pWowYDHB = xKp3jkIvM09AZ4euXa87i5TVtfUD[HVmIrFwau90jQsgiWzExk(u"ࠬࡘࡅࡑࡑࡖࠫ਱")]
	tAOCzrTnyMbuRjm8lZ7NUYxhef0 = ZZT6GLaHQ1 in PqZAgIysiukFjtTKQn6pWowYDHB or Ly6gqD8jB5I9tp2MY3ncEsJ in PqZAgIysiukFjtTKQn6pWowYDHB
	if f1kUIA6ndptORqMcaZusGVw3:
		f53YIXVCTWcHuyewon = hhtgHR5ivXAL9okpjGPEn8K.index(ZZT6GLaHQ1)
		J2bWNij3HmU1R9P5ItnxXBd7pSZA = yy0zIog9KDlfOQ[f53YIXVCTWcHuyewon]
	elif tAOCzrTnyMbuRjm8lZ7NUYxhef0:
		f53YIXVCTWcHuyewon = PqZAgIysiukFjtTKQn6pWowYDHB.index(ZZT6GLaHQ1)
		J2bWNij3HmU1R9P5ItnxXBd7pSZA = EIVDQBT4RprwKAlaHd5t1LcgemqP[f53YIXVCTWcHuyewon]
	else: J2bWNij3HmU1R9P5ItnxXBd7pSZA = eGW7cI6aQhr0(u"࠭ࠧਲ")
	return J2bWNij3HmU1R9P5ItnxXBd7pSZA
def KJz9WRbX2g0LeCD(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0=NdKhAS6MXVEORLTwob92pxlZ,JoWX5If80G=NdKhAS6MXVEORLTwob92pxlZ,xmezOWMyhSXRGHlEk2JnsI=NdKhAS6MXVEORLTwob92pxlZ):
	hhM2Wn1045PDsl6p8VLA7vIN(IlL8ZnX74Yvep(u"ࠧࡖࡔࡏࡐࡎࡈ࡜ࡵ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬਲ਼"),ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI,fiuheaxH14ZML0)
	if J92gCnbGWidQV70lBteTwU6D8uyzL: import urllib.request as wz4ml2cjXIuBMGDJdEFayOs
	else: import urllib2 as wz4ml2cjXIuBMGDJdEFayOs
	if not JoWX5If80G: JoWX5If80G = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ਴"):NdKhAS6MXVEORLTwob92pxlZ}
	if not dJC476xoE1ecpm0: dJC476xoE1ecpm0 = {}
	l3M4EtrOH7bKa5RLwnXB6ADy1 = ZZT6GLaHQ1
	if fiuheaxH14ZML0==JGwsL21ZRlqSrWxEmF(u"ࠩࡊࡉ࡙࠭ਵ"):
		l3M4EtrOH7bKa5RLwnXB6ADy1 = ZZT6GLaHQ1+OOkmZiVcfqlEurM1dHGb(u"ࠪࡃࠬਸ਼")+g1Vmb5T39C(dJC476xoE1ecpm0)
		dJC476xoE1ecpm0 = None
	elif fiuheaxH14ZML0==V0VZk9763fusTReHFo4(u"ࠫࡕࡕࡓࡕࠩ਷") and PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡰࡳࡰࡰࠪਸ") in str(JoWX5If80G):
		dJC476xoE1ecpm0 = O3OogF1l5reuQ.dumps(dJC476xoE1ecpm0)
		dJC476xoE1ecpm0 = str(dJC476xoE1ecpm0).encode(YRvPKe2zMTDs8UCkr)
	elif fiuheaxH14ZML0==PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡐࡐࡕࡗࠫਹ"):
		dJC476xoE1ecpm0 = g1Vmb5T39C(dJC476xoE1ecpm0)
		dJC476xoE1ecpm0 = dJC476xoE1ecpm0.encode(YRvPKe2zMTDs8UCkr)
	try:
		RiTmJh3UALkP4NgMz05Gc = wz4ml2cjXIuBMGDJdEFayOs.Request(l3M4EtrOH7bKa5RLwnXB6ADy1,headers=JoWX5If80G,data=dJC476xoE1ecpm0)
		MmDs0fWOCc3Bg = wz4ml2cjXIuBMGDJdEFayOs.urlopen(RiTmJh3UALkP4NgMz05Gc)
		tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.read()
		e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = LtGoXlQ2IYxqTJRySE6udfW98(u"࠳࠲࠳୽"),QQHFtjcaR2VpnSyTIv(u"ࠧࡐࡍࠪ਺")
	except:
		tWcXU498FSdjKl2Iw7M = NdKhAS6MXVEORLTwob92pxlZ
		e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = -llxMLe4gobHhsj1WGvd7qmIU,eGW7cI6aQhr0(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ਻")
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝਼ࠣࠫ")+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ਽")+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy+HVmIrFwau90jQsgiWzExk(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ਾ")+xmezOWMyhSXRGHlEk2JnsI+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫਿ")+l3M4EtrOH7bKa5RLwnXB6ADy1+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࠠ࡞ࠩੀ"))
	if tWcXU498FSdjKl2Iw7M and J92gCnbGWidQV70lBteTwU6D8uyzL: tWcXU498FSdjKl2Iw7M = tWcXU498FSdjKl2Iw7M.decode(YRvPKe2zMTDs8UCkr)
	return tWcXU498FSdjKl2Iw7M
def SEYpo9cGaTR8Dv360nNrylMHBmJ4uU(TPM4KyX39tcgBYuvf):
	dIXeAasq7hyl4owvjN1ZU = {
		V0VZk9763fusTReHFo4(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣੁ"):gVXbksjWZ2Y3por5yQd8wCufUzMm7T,
		NOrchaEV1iIZ87Uzlwgum(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧੂ"):str(kQI947MebLovYyVE08F5qPi6fj3),
		pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ੃"):lvsJ2jaZktmNO6PbdXS,
		JGwsL21ZRlqSrWxEmF(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥ੄"):lvsJ2jaZktmNO6PbdXS,
		rNyT0edugn(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ੅"): lvsJ2jaZktmNO6PbdXS,
		Hlp3z0APt1GR4kMYK5xST(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨ੆"):PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨੇ"),
		NOrchaEV1iIZ87Uzlwgum(u"ࠢࡪࡲࠥੈ"): OOkmZiVcfqlEurM1dHGb(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ੉"),
		hCm2fnEXs6Zt(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣ੊"):f4vncKMRlXG9s
	}
	Lat0nRd3GMBfb792C6uHFIO1sw = []
	for J2bWNij3HmU1R9P5ItnxXBd7pSZA in TPM4KyX39tcgBYuvf:
		CaSFdiZ0mT = dIXeAasq7hyl4owvjN1ZU.copy()
		CaSFdiZ0mT[OOkmZiVcfqlEurM1dHGb(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧੋ")] = J2bWNij3HmU1R9P5ItnxXBd7pSZA
		CaSFdiZ0mT[R3lezw8h407ZvrAFxT(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧੌ")] = {OOkmZiVcfqlEurM1dHGb(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ੍"):J2bWNij3HmU1R9P5ItnxXBd7pSZA}
		CaSFdiZ0mT[NeU6uRGpECkvMV5jf(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ੎")] = {eGW7cI6aQhr0(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ੏"):J2bWNij3HmU1R9P5ItnxXBd7pSZA}
		Lat0nRd3GMBfb792C6uHFIO1sw.append(CaSFdiZ0mT)
	gmdT0aMXkplZe1zWFHjqESB6V2 = str(Ijo3hy7zQO5x8aU9vAZDMV.randrange(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷୾"),HHvYL68lbJVZWM7tQEzSex3(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹୿")))
	dJC476xoE1ecpm0 = {
		V0VZk9763fusTReHFo4(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ੐"):hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧੑ"),
		lRP6GTaZJA1Xw3egLM4(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ੒"):gmdT0aMXkplZe1zWFHjqESB6V2,
		V0VZk9763fusTReHFo4(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ੓"): Lat0nRd3GMBfb792C6uHFIO1sw
	}
	JoWX5If80G = {WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ੔"):NOrchaEV1iIZ87Uzlwgum(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ੕")}
	ZZT6GLaHQ1 = Hlp3z0APt1GR4kMYK5xST(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩ੖")
	tWcXU498FSdjKl2Iw7M = KJz9WRbX2g0LeCD(HVmIrFwau90jQsgiWzExk(u"ࠨࡒࡒࡗ࡙࠭੗"),ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,Hlp3z0APt1GR4kMYK5xST(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ੘"))
	return tWcXU498FSdjKl2Iw7M
def BdnA8WwtJeKUVvE(DD6cpk8Q1ryURVAtg7N9OHu,HSb5r1Di9I8eKTtAyuNZdC4W):
	HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡲࡺࡲ࡬ࠨਖ਼"),fOc18oTm5hsdD4pVZQj(u"ࠫࡓࡵ࡮ࡦࠩਗ਼"))
	HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.replace(xY4icgQUj6mPVs73CTKu(u"ࠬࡺࡲࡶࡧࠪਜ਼"),HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡔࡳࡷࡨࠫੜ"))
	HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.replace(lRP6GTaZJA1Xw3egLM4(u"ࠧࡧࡣ࡯ࡷࡪ࠭੝"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡈࡤࡰࡸ࡫ࠧਫ਼"))
	HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.replace(NeU6uRGpECkvMV5jf(u"ࠩ࡟࠳ࠬ੟"),Hlp3z0APt1GR4kMYK5xST(u"ࠪ࠳ࠬ੠"))
	try: RM17uFVste3pJLBhjcn = eval(HSb5r1Di9I8eKTtAyuNZdC4W)
	except: RM17uFVste3pJLBhjcn = nbMFEayeDC1S3UVq7oid8(DD6cpk8Q1ryURVAtg7N9OHu)
	return RM17uFVste3pJLBhjcn
def E2OlWsLqp5d78iQMmc3uzD():
	GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠ࡝࡝࠲ࡇࡔࡒࡏࡓ࡞ࡠࠫ੡"),vczZTnVU6PuaFG5EeALl4MKOj0,YYqECUofyi7wFrW.DOTALL)
	if ekmszoF6UQAbHp9r0ug: vczZTnVU6PuaFG5EeALl4MKOj0 = vczZTnVU6PuaFG5EeALl4MKOj0.split(ekmszoF6UQAbHp9r0ug[e8XhbyuzvjYkIsJUtB5w],IlL8ZnX74Yvep(u"࠵஀"))[llxMLe4gobHhsj1WGvd7qmIU]
	ssPwFfnphBNO6rAcEWuaH = XJ62UBRmIqFvfiNTQj.strftime(lNTJCZeBicWEz0Mg(u"ࠬࡥࠥ࡮࠰ࠨࡨࡤࠫࡈ࠻ࠧࡐࡣࠬ੢"),XJ62UBRmIqFvfiNTQj.localtime(MMQhDpyCenmO350aBAKVYk))
	vczZTnVU6PuaFG5EeALl4MKOj0 = vczZTnVU6PuaFG5EeALl4MKOj0+ssPwFfnphBNO6rAcEWuaH
	gnmMTs3ArWXNhk1YP = GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(LKitvZysHM):
		HHVF24kQUwi3XSegWCu7x9 = open(LKitvZysHM,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡲࡣࠩ੣")).read()
		if J92gCnbGWidQV70lBteTwU6D8uyzL: HHVF24kQUwi3XSegWCu7x9 = HHVF24kQUwi3XSegWCu7x9.decode(YRvPKe2zMTDs8UCkr)
		HHVF24kQUwi3XSegWCu7x9 = BdnA8WwtJeKUVvE(lRP6GTaZJA1Xw3egLM4(u"ࠧࡥ࡫ࡦࡸࠬ੤"),HHVF24kQUwi3XSegWCu7x9)
	else: HHVF24kQUwi3XSegWCu7x9 = {}
	bQrogdaYD9T7jeNuXGML = {}
	for Y4S7MU9QC35 in list(HHVF24kQUwi3XSegWCu7x9.keys()):
		if Y4S7MU9QC35!=GY9jgon6yhP0IvtCBEJu3: bQrogdaYD9T7jeNuXGML[Y4S7MU9QC35] = HHVF24kQUwi3XSegWCu7x9[Y4S7MU9QC35]
		else:
			if vczZTnVU6PuaFG5EeALl4MKOj0 and vczZTnVU6PuaFG5EeALl4MKOj0!=rNyT0edugn(u"ࠨ࠰࠱ࠫ੥"):
				zQSf8kjs1TW35munlyMHNxOrGXPZD = HHVF24kQUwi3XSegWCu7x9[Y4S7MU9QC35]
				if gnmMTs3ArWXNhk1YP in zQSf8kjs1TW35munlyMHNxOrGXPZD:
					Xd8PpnWk1RlgzSmuNjtK3 = zQSf8kjs1TW35munlyMHNxOrGXPZD.index(gnmMTs3ArWXNhk1YP)
					del zQSf8kjs1TW35munlyMHNxOrGXPZD[Xd8PpnWk1RlgzSmuNjtK3]
				RKFv4AP3fDzwtisg6V1nGCQyjbu = [gnmMTs3ArWXNhk1YP]+zQSf8kjs1TW35munlyMHNxOrGXPZD
				RKFv4AP3fDzwtisg6V1nGCQyjbu = RKFv4AP3fDzwtisg6V1nGCQyjbu[:lrtFSogC8Nh9(u"࠺࠶஁")]
				bQrogdaYD9T7jeNuXGML[Y4S7MU9QC35] = RKFv4AP3fDzwtisg6V1nGCQyjbu
			else: bQrogdaYD9T7jeNuXGML[Y4S7MU9QC35] = HHVF24kQUwi3XSegWCu7x9[Y4S7MU9QC35]
	if GY9jgon6yhP0IvtCBEJu3 not in list(bQrogdaYD9T7jeNuXGML.keys()): bQrogdaYD9T7jeNuXGML[GY9jgon6yhP0IvtCBEJu3] = [gnmMTs3ArWXNhk1YP]
	bQrogdaYD9T7jeNuXGML = str(bQrogdaYD9T7jeNuXGML)
	if J92gCnbGWidQV70lBteTwU6D8uyzL: bQrogdaYD9T7jeNuXGML = bQrogdaYD9T7jeNuXGML.encode(YRvPKe2zMTDs8UCkr)
	open(LKitvZysHM,IlL8ZnX74Yvep(u"ࠩࡺࡦࠬ੦")).write(bQrogdaYD9T7jeNuXGML)
	return
def g1Vmb5T39C(dJC476xoE1ecpm0):
	if J92gCnbGWidQV70lBteTwU6D8uyzL: import urllib.parse as wnvGbhuKPk1HoS2VyFB
	else: import urllib as wnvGbhuKPk1HoS2VyFB
	QARp1EKko7Ief6NZ9PzVJH5LjtTgU = wnvGbhuKPk1HoS2VyFB.urlencode(dJC476xoE1ecpm0)
	return QARp1EKko7Ief6NZ9PzVJH5LjtTgU
def llQB96aRtAXDdJyW3IkgfOMcKrF8w4(Afey3cL4ojzg,O35s8zKmnrf71PcDCShyR2gaM=NdKhAS6MXVEORLTwob92pxlZ,OH8t94DKxE0LYI3XmfPBj7ReU=NdKhAS6MXVEORLTwob92pxlZ):
	B7wFsCk25VKRGnNJXZpiH = O35s8zKmnrf71PcDCShyR2gaM not in [Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡑ࠸࡛ࠧ੧"),NOrchaEV1iIZ87Uzlwgum(u"ࠫࡎࡖࡔࡗࠩ੨")]
	if not OH8t94DKxE0LYI3XmfPBj7ReU: OH8t94DKxE0LYI3XmfPBj7ReU = V0VZk9763fusTReHFo4(u"ࠬࡼࡩࡥࡧࡲࠫ੩")
	NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5,Xy23oznVZR,ImG7FH0jCdSgtc = PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨ੪"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	if len(Afey3cL4ojzg)==uL69vJOU7xN0hGnZf2islDqk:
		ZZT6GLaHQ1,N8B5COZ2YEs,ImG7FH0jCdSgtc = Afey3cL4ojzg
		if N8B5COZ2YEs: Xy23oznVZR = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ੫")+N8B5COZ2YEs+NeU6uRGpECkvMV5jf(u"ࠨࠢࡠࠫ੬")
	else: ZZT6GLaHQ1,N8B5COZ2YEs,ImG7FH0jCdSgtc = Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	ZZT6GLaHQ1 = ZZT6GLaHQ1.replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࠨ࠶࠵࠭੭"),Vwgflszp4WRA93kx6hvdua21HX5cOb)
	F8ipzId7PMgj = atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(ZZT6GLaHQ1)
	if O35s8zKmnrf71PcDCShyR2gaM not in [IlL8ZnX74Yvep(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ੮"),eGW7cI6aQhr0(u"ࠫࡎࡖࡔࡗࠩ੯")]:
		if O35s8zKmnrf71PcDCShyR2gaM!=WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧੰ"): ZZT6GLaHQ1 = ZZT6GLaHQ1.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,HVmIrFwau90jQsgiWzExk(u"࠭ࠥ࠳࠲ࠪੱ"))
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lrtFSogC8Nh9(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡳࡰࡦࡿ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࠢࡹ࡭ࡩ࡫࡯࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ੲ")+ZZT6GLaHQ1+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࠢࡠࠫੳ")+Xy23oznVZR)
		if F8ipzId7PMgj==HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨੴ") and O35s8zKmnrf71PcDCShyR2gaM not in [V0VZk9763fusTReHFo4(u"ࠪࡍࡕ࡚ࡖࠨੵ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ੶")]:
			import PNC7bFKMI6
			IGEpKNCaiLMT,UTwH7zjZOrmFl = PNC7bFKMI6.Ijx8kSvADOboa4E52zrfu9UteF(O35s8zKmnrf71PcDCShyR2gaM,ZZT6GLaHQ1)
			ZZiHOu2GRo5SrgImeL34 = len(UTwH7zjZOrmFl)
			if ZZiHOu2GRo5SrgImeL34>llxMLe4gobHhsj1WGvd7qmIU:
				rRfpvbZojlygET5JL87wdzIPGe = PNC7bFKMI6.cCanV8J9iKuojqe5v4(HVmIrFwau90jQsgiWzExk(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭੷")+str(ZZiHOu2GRo5SrgImeL34)+rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠠๆๆไ࠭ࠬ੸"), IGEpKNCaiLMT)
				if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU:
					PNC7bFKMI6.kkDz5sdaPteM(eGW7cI6aQhr0(u"ࠧฦๆ฽หฦูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ੹"),IlL8ZnX74Yvep(u"ࠨࡅࡤࡲࡨ࡫࡬ࠨ੺"))
					return NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5
			else: rRfpvbZojlygET5JL87wdzIPGe = e8XhbyuzvjYkIsJUtB5w
			ZZT6GLaHQ1 = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
			if IGEpKNCaiLMT[e8XhbyuzvjYkIsJUtB5w]!=kb2icmDGVUZfW1OFz7sv(u"ࠩ࠰࠵ࠬ੻"):
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lrtFSogC8Nh9(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠿࡛ࠦࠡࠩ੼")+IGEpKNCaiLMT[rRfpvbZojlygET5JL87wdzIPGe]+OOkmZiVcfqlEurM1dHGb(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ੽")+ZZT6GLaHQ1+V0VZk9763fusTReHFo4(u"ࠬࠦ࡝ࠨ੾"))
		if fOc18oTm5hsdD4pVZQj(u"࠭࠯ࡪࡨ࡬ࡰࡲ࠵ࠧ੿") in ZZT6GLaHQ1: ZZT6GLaHQ1 = ZZT6GLaHQ1+OOkmZiVcfqlEurM1dHGb(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ઀")
		elif pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡪࡷࡸࡵ࠭ઁ") in ZZT6GLaHQ1.lower() and NeU6uRGpECkvMV5jf(u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩં") not in ZZT6GLaHQ1 and rNyT0edugn(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨઃ") not in ZZT6GLaHQ1:
			ZZT6GLaHQ1 = ZZT6GLaHQ1+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࢁ࠭઄") if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࢂࠧઅ") not in ZZT6GLaHQ1 else ZZT6GLaHQ1+xY4icgQUj6mPVs73CTKu(u"࠭ࠦࠨઆ")
			if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬઇ") not in ZZT6GLaHQ1 and WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪઈ") in ZZT6GLaHQ1.lower(): ZZT6GLaHQ1 += Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠫ࠭ઉ")
			if eGW7cI6aQhr0(u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺ࠽ࠨઊ") not in ZZT6GLaHQ1.lower() and O35s8zKmnrf71PcDCShyR2gaM not in [HVmIrFwau90jQsgiWzExk(u"ࠫࡎࡖࡔࡗࠩઋ"),JGwsL21ZRlqSrWxEmF(u"ࠬࡓ࠳ࡖࠩઌ")]: ZZT6GLaHQ1 += PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬઍ")
			if OOkmZiVcfqlEurM1dHGb(u"ࠧࡳࡧࡩࡩࡷ࡫ࡲ࠾ࠩ઎") not in ZZT6GLaHQ1.lower(): ZZT6GLaHQ1 += ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶࠦࠨએ")
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lRP6GTaZJA1Xw3egLM4(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡩ࡭ࡳࡧ࡬ࠡࡷࡵࡰࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪઐ")+ZZT6GLaHQ1+R3lezw8h407ZvrAFxT(u"ࠪࠤࡢ࠭ઑ"))
	wEYlOJh9KQtg = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ListItem()
	OH8t94DKxE0LYI3XmfPBj7ReU,WdC7ZebIlsKGu,T4JCqSH3x5BiWNhI0,Yrq4u3gv9WTSL,NNP0lcpCTdo,sawplH5BqyAfbIgiLnh3J,p8pD6rTHEdCIsMnWijukwS9zYqcZm,bPuifnrSBO6ZzDQN4yY7eVTl,qt2mdMSsIo = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	if O35s8zKmnrf71PcDCShyR2gaM not in [QQHFtjcaR2VpnSyTIv(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭઒"),gniNItGL6bKwpEW(u"ࠬࡏࡐࡕࡘࠪઓ")]:
		if QBp28giCnayJzmZH6vYO: NNsqiatOuK2yeJF9vBQ8CfgPow1V = hCm2fnEXs6Zt(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩઔ")
		else: NNsqiatOuK2yeJF9vBQ8CfgPow1V = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬક")
		wEYlOJh9KQtg.setProperty(NNsqiatOuK2yeJF9vBQ8CfgPow1V, NdKhAS6MXVEORLTwob92pxlZ)
		wEYlOJh9KQtg.setMimeType(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ࡯࡬ࡱࡪ࠵ࡸ࠮ࡶࡼࡴࡪ࠭ખ"))
		if kQI947MebLovYyVE08F5qPi6fj3<Tzx81Wb0RZC4ID5AyiU2(u"࠸࠰ஂ"): wEYlOJh9KQtg.setInfo(V0VZk9763fusTReHFo4(u"ࠩࡹ࡭ࡩ࡫࡯ࠨગ"),{ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭ઘ"):eGW7cI6aQhr0(u"ࠫࡲࡵࡶࡪࡧࠪઙ")})
		else:
			xKFoVtqzUw0MkdNTfyljD7 = wEYlOJh9KQtg.getVideoInfoTag()
			xKFoVtqzUw0MkdNTfyljD7.setMediaType(Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡳ࡯ࡷ࡫ࡨࠫચ"))
		wEYlOJh9KQtg.setArt({OOkmZiVcfqlEurM1dHGb(u"࠭ࡴࡩࡷࡰࡦࠬછ"):NNP0lcpCTdo,Hlp3z0APt1GR4kMYK5xST(u"ࠧࡱࡱࡶࡸࡪࡸࠧજ"):NNP0lcpCTdo,IlL8ZnX74Yvep(u"ࠨࡤࡤࡲࡳ࡫ࡲࠨઝ"):NNP0lcpCTdo,OOkmZiVcfqlEurM1dHGb(u"ࠩࡩࡥࡳࡧࡲࡵࠩઞ"):NNP0lcpCTdo,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬટ"):NNP0lcpCTdo,rNyT0edugn(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧઠ"):NNP0lcpCTdo,HVmIrFwau90jQsgiWzExk(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨડ"):NNP0lcpCTdo,rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡩࡤࡱࡱࠫઢ"):NNP0lcpCTdo})
		if F8ipzId7PMgj in [V0VZk9763fusTReHFo4(u"ࠧ࠯࡯ࡳࡨࠬણ"),V0VZk9763fusTReHFo4(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧત")]: wEYlOJh9KQtg.setContentLookup(k6apiPAlLKM1ed8J42RjHh0o)
		else: wEYlOJh9KQtg.setContentLookup(f4vncKMRlXG9s)
		from oMV3OL4Bzl import aV1HYqMRxUA3vmOr8LnGofj0FI5C7
		if NeU6uRGpECkvMV5jf(u"ࠩࡵࡸࡲࡶࠧથ") in ZZT6GLaHQ1:
			aV1HYqMRxUA3vmOr8LnGofj0FI5C7(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭દ"),f4vncKMRlXG9s)
		elif F8ipzId7PMgj==HHvYL68lbJVZWM7tQEzSex3(u"ࠫ࠳ࡳࡰࡥࠩધ") or rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬન") in ZZT6GLaHQ1:
			aV1HYqMRxUA3vmOr8LnGofj0FI5C7(NOrchaEV1iIZ87Uzlwgum(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭઩"),f4vncKMRlXG9s)
			wEYlOJh9KQtg.setProperty(NNsqiatOuK2yeJF9vBQ8CfgPow1V,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧપ"))
			wEYlOJh9KQtg.setProperty(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨફ"),QQHFtjcaR2VpnSyTIv(u"ࠩࡰࡴࡩ࠭બ"))
		if N8B5COZ2YEs:
			wEYlOJh9KQtg.setSubtitles([N8B5COZ2YEs])
	if OH8t94DKxE0LYI3XmfPBj7ReU==lrtFSogC8Nh9(u"ࠪࡺ࡮ࡪࡥࡰࠩભ") and O35s8zKmnrf71PcDCShyR2gaM==V0VZk9763fusTReHFo4(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭મ"):
		NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 = xY4icgQUj6mPVs73CTKu(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬય")
		O35s8zKmnrf71PcDCShyR2gaM = JGwsL21ZRlqSrWxEmF(u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭ર")
	elif OH8t94DKxE0LYI3XmfPBj7ReU==HVmIrFwau90jQsgiWzExk(u"ࠧࡷ࡫ࡧࡩࡴ࠭઱") and bPuifnrSBO6ZzDQN4yY7eVTl.startswith(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨ࠸ࠪલ")):
		NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 = Hlp3z0APt1GR4kMYK5xST(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧળ")
		O35s8zKmnrf71PcDCShyR2gaM = O35s8zKmnrf71PcDCShyR2gaM+HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡣࡉࡒࠧ઴")
	if NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5!=rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩવ"): E2OlWsLqp5d78iQMmc3uzD()
	eq7falVhHs4ZUy6k9.d97bAUB5nJYN2xap03LqQ1tjIDcGPW(O35s8zKmnrf71PcDCShyR2gaM)
	if eq7falVhHs4ZUy6k9.w6skcmfJ47: return YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭શ")
	if OH8t94DKxE0LYI3XmfPBj7ReU==xY4icgQUj6mPVs73CTKu(u"࠭ࡶࡪࡦࡨࡳࠬષ") and not bPuifnrSBO6ZzDQN4yY7eVTl.startswith(Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࠷ࠩસ")):
		wEYlOJh9KQtg.setPath(ZZT6GLaHQ1)
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+JGwsL21ZRlqSrWxEmF(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨહ")+ZZT6GLaHQ1+V0VZk9763fusTReHFo4(u"ࠩࠣࡡࠬ઺"))
		vI4DUTHAYrjBPOXwu9nas.setResolvedUrl(oo2RYcTAqyksN1DHG7gLCaZJ,k6apiPAlLKM1ed8J42RjHh0o,wEYlOJh9KQtg)
	elif OH8t94DKxE0LYI3XmfPBj7ReU==LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡰ࡮ࡼࡥࠨ઻"):
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠ઼ࠦࠧ")+ZZT6GLaHQ1+QQHFtjcaR2VpnSyTIv(u"ࠬࠦ࡝ࠨઽ"))
		eq7falVhHs4ZUy6k9.play(ZZT6GLaHQ1,wEYlOJh9KQtg)
	PsKJk8XRHAQM = f4vncKMRlXG9s
	if NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5==PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫા"):
		from Po3kCjO4aN import o1OSHpxKtczW05Ig
		PsKJk8XRHAQM = o1OSHpxKtczW05Ig(ZZT6GLaHQ1,F8ipzId7PMgj,O35s8zKmnrf71PcDCShyR2gaM)
		if PsKJk8XRHAQM: E2OlWsLqp5d78iQMmc3uzD()
	else:
		t7GucK3fAw,NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5,aaoXh0WjMcrC9sx4Q8Uvl,NhijMRuetbAydr,BU1Gbei53FsWnzmh0PZElo7NS2V = e8XhbyuzvjYkIsJUtB5w,lrtFSogC8Nh9(u"ࠧࡵࡴ࡬ࡩࡩ࠭િ"),f4vncKMRlXG9s,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠲࠲࠳࠴஄"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠴࠶࠲࠳࠴ஃ")
		if B7wFsCk25VKRGnNJXZpiH: import PNC7bFKMI6
		while t7GucK3fAw<BU1Gbei53FsWnzmh0PZElo7NS2V:
			ACOWB6GRmIbDKyl3Zn.sleep(NhijMRuetbAydr)
			t7GucK3fAw += NhijMRuetbAydr
			if eq7falVhHs4ZUy6k9.w6skcmfJ47==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી") and not aaoXh0WjMcrC9sx4Q8Uvl:
				if B7wFsCk25VKRGnNJXZpiH: PNC7bFKMI6.kkDz5sdaPteM(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ฮสำࠥอไโ์า๎ํ࠭ુ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫૂ"),XJ62UBRmIqFvfiNTQj=HVmIrFwau90jQsgiWzExk(u"࠹࠸࠴அ"))
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+hCm2fnEXs6Zt(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨૃ")+ZZT6GLaHQ1+JGwsL21ZRlqSrWxEmF(u"ࠬࠦ࡝ࠨૄ")+Xy23oznVZR)
				aaoXh0WjMcrC9sx4Q8Uvl = k6apiPAlLKM1ed8J42RjHh0o
			elif eq7falVhHs4ZUy6k9.w6skcmfJ47 in [vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧૅ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ૆")]:
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+rNyT0edugn(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼ࡭ࡳ࡭࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬે")+ZZT6GLaHQ1+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࠣࡡࠬૈ")+Xy23oznVZR)
				break
			elif eq7falVhHs4ZUy6k9.w6skcmfJ47==R3lezw8h407ZvrAFxT(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪૉ"):
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+eGW7cI6aQhr0(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ૊")+ZZT6GLaHQ1+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࠦ࡝ࠨો")+Xy23oznVZR)
				if B7wFsCk25VKRGnNJXZpiH: PNC7bFKMI6.kkDz5sdaPteM(gniNItGL6bKwpEW(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪૌ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡇࡣ࡬ࡰࡺࡸࡥࠨ્"),XJ62UBRmIqFvfiNTQj=lNTJCZeBicWEz0Mg(u"࠺࠹࠵ஆ"))
				break
			elif eq7falVhHs4ZUy6k9.w6skcmfJ47==JGwsL21ZRlqSrWxEmF(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ૎"):
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CB2TcZaokLhA3dQOgjPywzGuxXq7EI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NOrchaEV1iIZ87Uzlwgum(u"ࠩࠣࠤࠥࡊࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡤ࡯ࡳࡨࡱࡥࡥࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ૏")+ZZT6GLaHQ1+HVmIrFwau90jQsgiWzExk(u"ࠪࠤࡢ࠭ૐ"))
				break
		else: NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 = Hlp3z0APt1GR4kMYK5xST(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ૑")
	if NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 in [IlL8ZnX74Yvep(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ૒")] or eq7falVhHs4ZUy6k9.w6skcmfJ47 in [LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ૓"),lNTJCZeBicWEz0Mg(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ૔")] or PsKJk8XRHAQM: c2JF3xijoWuSgAVvLaRz(O35s8zKmnrf71PcDCShyR2gaM)
	else: exec(hCm2fnEXs6Zt(u"ࠨ࡫ࡰࡴࡴࡸࡴࠡࡺࡥࡱࡨࡁࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭૕"))
	UvRCkP3SHzQ2lat4qo69s1VMTdiYF = ACOWB6GRmIbDKyl3Zn.Player().isPlaying()
	if not UvRCkP3SHzQ2lat4qo69s1VMTdiYF and NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 not in [eGW7cI6aQhr0(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧ૖")]:
		msg = lRP6GTaZJA1Xw3egLM4(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫ૗") if NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ૘") else gniNItGL6bKwpEW(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭૙")
		if B7wFsCk25VKRGnNJXZpiH: PNC7bFKMI6.kkDz5sdaPteM(vju3SZDWL4ENYelmBOzUqrogp2(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ૚"),msg,XJ62UBRmIqFvfiNTQj=wP4kpvXoDHq3hs7TFLyr2COn8(u"࠻࠺࠶இ"))
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lNTJCZeBicWEz0Mg(u"ࠧࠡࠢࠣࠫ૛")+msg+QQHFtjcaR2VpnSyTIv(u"ࠨ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ૜")+ZZT6GLaHQ1+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࠣࡡࠬ૝")+Xy23oznVZR)
	return eq7falVhHs4ZUy6k9.w6skcmfJ47
def atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(ZZT6GLaHQ1):
	if eGW7cI6aQhr0(u"ࠪࡃࠬ૞") in ZZT6GLaHQ1: ZZT6GLaHQ1 = ZZT6GLaHQ1.split(QQHFtjcaR2VpnSyTIv(u"ࠫࡄ࠭૟"))[e8XhbyuzvjYkIsJUtB5w]
	if OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࢂࠧૠ") in ZZT6GLaHQ1: ZZT6GLaHQ1 = ZZT6GLaHQ1.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡼࠨૡ"))[e8XhbyuzvjYkIsJUtB5w]
	path = fOc18oTm5hsdD4pVZQj(u"ࠧ࠰ࠩૢ").join(ZZT6GLaHQ1.split(V0VZk9763fusTReHFo4(u"ࠨ࠱ࠪૣ"))[PzIpQnUXxRwNCivDhdakWTE(u"࠸ஈ"):]) if NeU6uRGpECkvMV5jf(u"ࠩ࠽࠳࠴࠭૤") in ZZT6GLaHQ1 else ZZT6GLaHQ1
	x9lIQDh8TfRHpWXdO0 = YYqECUofyi7wFrW.findall(JGwsL21ZRlqSrWxEmF(u"ࠪࡠ࠳࠮࡛ࡢ࠯ࡽ࠴࠲࠿࡝ࡼ࠴࠯࠸ࢂ࠯ࠧ૥"),path,YYqECUofyi7wFrW.DOTALL)
	if x9lIQDh8TfRHpWXdO0:
		x9lIQDh8TfRHpWXdO0 = x9lIQDh8TfRHpWXdO0[-llxMLe4gobHhsj1WGvd7qmIU]
		EImMFvbUzL7p4dYTCNkoOh2qGP8jt5 = [hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡲ࠹ࡵ࠹ࠩ૦"),PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡳࡰ࠵ࠩ૧"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࡭ࡱࡦࠪ૨"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡸࡧࡥࡱࠬ૩"),QQHFtjcaR2VpnSyTIv(u"ࠨࡣࡹ࡭ࠬ૪"),IlL8ZnX74Yvep(u"ࠩࡤࡥࡨ࠭૫"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡱ࠸ࡻࠧ૬"),V0VZk9763fusTReHFo4(u"ࠫࡲࡱࡶࠨ૭"),R3lezw8h407ZvrAFxT(u"ࠬ࡬࡬ࡷࠩ૮"),hCm2fnEXs6Zt(u"࠭࡭ࡱ࠵ࠪ૯"),JGwsL21ZRlqSrWxEmF(u"ࠧࡵࡵࠪ૰")]
		if x9lIQDh8TfRHpWXdO0 in EImMFvbUzL7p4dYTCNkoOh2qGP8jt5: return lrtFSogC8Nh9(u"ࠨ࠰ࠪ૱")+x9lIQDh8TfRHpWXdO0
	return NdKhAS6MXVEORLTwob92pxlZ
def c2JF3xijoWuSgAVvLaRz(CaSFdiZ0mT):
	if not OMNiY8joQx.WiJPMTZvOLGsV0xB8al: CaSFdiZ0mT += OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡢࡘࡘ࠭૲")
	sevfFTR5mNndl.append(CaSFdiZ0mT)
	return
def kaZwJ6ofBcYmeD(sGEPOZup3k5VSq=f4vncKMRlXG9s):
	DG54yfbLoBUCISVh6FkXmvtK9rzQjn(sGEPOZup3k5VSq,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭૳"))
	hnu0oKAvsG4PaX6yxiTj2eftY.exit()
def DG54yfbLoBUCISVh6FkXmvtK9rzQjn(sGEPOZup3k5VSq,ihuUeAVfaSbXMNn):
	if ihuUeAVfaSbXMNn:
		if NeU6uRGpECkvMV5jf(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧ૴") in ihuUeAVfaSbXMNn: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨ૵"))
		else:
			eFxB9v7dgAo4 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(xY4icgQUj6mPVs73CTKu(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ૶"))
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ૷"),NdKhAS6MXVEORLTwob92pxlZ)
			import PNC7bFKMI6
			PNC7bFKMI6.ZeaDz4KMlg5bSRBfT1tnVCGH(ihuUeAVfaSbXMNn)
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(hCm2fnEXs6Zt(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ૸"),eFxB9v7dgAo4)
	vyQfmxGsUX5BSM7Hzq2lEdb6j(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡶࡸࡴࡶࠧૹ"))
	xmYofc7HByzQqEh81L2b6V = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧૺ"))
	if xmYofc7HByzQqEh81L2b6V==lrtFSogC8Nh9(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡤࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬૻ"): ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩૼ"),IlL8ZnX74Yvep(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭૽"))
	elif xmYofc7HByzQqEh81L2b6V==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧ૾"): ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ૿"),NdKhAS6MXVEORLTwob92pxlZ)
	if ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ଀")) not in [hCm2fnEXs6Zt(u"ࠪࡅ࡚࡚ࡏࠨଁ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡘ࡚ࡏࡑࠩଂ"),IlL8ZnX74Yvep(u"ࠬࡇࡓࡌࠩଃ")]: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ଄"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡂࡕࡎࠫଅ"))
	if ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(gniNItGL6bKwpEW(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ଆ")) not in [JGwsL21ZRlqSrWxEmF(u"ࠩࡄ࡙࡙ࡕࠧଇ"),lNTJCZeBicWEz0Mg(u"ࠪࡗ࡙ࡕࡐࠨଈ"),lNTJCZeBicWEz0Mg(u"ࠫࡆ࡙ࡋࠨଉ")]: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(Hlp3z0APt1GR4kMYK5xST(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪଊ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡁࡔࡍࠪଋ"))
	hZVOfz9TwS = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬଌ"))
	F5cKwEogkz64f0 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ଍"))
	if V0VZk9763fusTReHFo4(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ଎") in str(F5cKwEogkz64f0) and hZVOfz9TwS in [OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ଏ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪଐ")]:
		XJ62UBRmIqFvfiNTQj.sleep(fOc18oTm5hsdD4pVZQj(u"࠶࠮࠲࠲࠳உ"))
		ACOWB6GRmIbDKyl3Zn.executebuiltin(eGW7cI6aQhr0(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩ଑"))
	if e8XhbyuzvjYkIsJUtB5w and oo2RYcTAqyksN1DHG7gLCaZJ>-llxMLe4gobHhsj1WGvd7qmIU:
		vI4DUTHAYrjBPOXwu9nas.setResolvedUrl(oo2RYcTAqyksN1DHG7gLCaZJ,f4vncKMRlXG9s,JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ListItem())
		PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V = f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s
		vI4DUTHAYrjBPOXwu9nas.endOfDirectory(oo2RYcTAqyksN1DHG7gLCaZJ,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V)
	if sevfFTR5mNndl:
		qmW74EDsgIkbfFKXPv86i10 = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=SEYpo9cGaTR8Dv360nNrylMHBmJ4uU,args=(sevfFTR5mNndl,))
		qmW74EDsgIkbfFKXPv86i10.start()
	PHxOvqnUsIgtdLTlJF0piM51War = brXPy5wmjqZ7YN01fRGoLaUgiQ()
	if PHxOvqnUsIgtdLTlJF0piM51War and not OMNiY8joQx.resolveonly:
		OMNiY8joQx.resolveonly = k6apiPAlLKM1ed8J42RjHh0o
		UvRCkP3SHzQ2lat4qo69s1VMTdiYF = ACOWB6GRmIbDKyl3Zn.Player().isPlaying()
		if not UvRCkP3SHzQ2lat4qo69s1VMTdiYF: eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭଒"))
		else:
			RR0cbpOGrgfJVs2MlezmSAuTF7 = PPw8FVgWohGqE3iTQD4ebl2J9Lr1()
			if RR0cbpOGrgfJVs2MlezmSAuTF7:
				import PNC7bFKMI6
				for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(lrtFSogC8Nh9(u"࠱஋"),PzIpQnUXxRwNCivDhdakWTE(u"࠱࠳࠲ஊ"),PzIpQnUXxRwNCivDhdakWTE(u"࠵஌")):
					XJ62UBRmIqFvfiNTQj.sleep(rNyT0edugn(u"࠶஍"))
					UvRCkP3SHzQ2lat4qo69s1VMTdiYF = ACOWB6GRmIbDKyl3Zn.Player().isPlaying()
					if not UvRCkP3SHzQ2lat4qo69s1VMTdiYF:
						PNC7bFKMI6.kkDz5sdaPteM(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧศๆไ๎ิ๐่ࠡษ็่ฬำโࠨଓ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠨว็฾ฬวࠠโฯุࠤฬ๊ำ๋ำไีฬะࠧଔ"),XJ62UBRmIqFvfiNTQj=LtGoXlQ2IYxqTJRySE6udfW98(u"࠵࠵࠶࠰எ"))
						break
				else:
					GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = W17Zj6mXnvxLdM50cPA(RR0cbpOGrgfJVs2MlezmSAuTF7)
					if not any(K6KbZDHncNizQgl1fr59XV0 in vczZTnVU6PuaFG5EeALl4MKOj0 for K6KbZDHncNizQgl1fr59XV0 in PNC7bFKMI6.NOT_TO_TEST_ALL_SERVERS):
						PNC7bFKMI6.kkDz5sdaPteM(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪକ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨଖ"),XJ62UBRmIqFvfiNTQj=YJpWv4QzC7sx8INVPukeZiOD03K(u"࠶࠶࠰࠱ஏ"))
						XJ62UBRmIqFvfiNTQj.sleep(hCm2fnEXs6Zt(u"࠸ஐ"))
						if QBp28giCnayJzmZH6vYO:
							ZZT6GLaHQ1 = ZZT6GLaHQ1.encode(YRvPKe2zMTDs8UCkr)
						PNC7bFKMI6.f2cgzj0TovI9YVl7tan1QkMS8(f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s)
						UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = PNC7bFKMI6.kqLBiwGX3V8P4SOmrNI1F7AMU(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
						PNC7bFKMI6.f2cgzj0TovI9YVl7tan1QkMS8(k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
						PNC7bFKMI6.kkDz5sdaPteM(lrtFSogC8Nh9(u"ࠫฬ๊แ๋ัํ์ࠥอไๅษะๆࠬଗ"),JGwsL21ZRlqSrWxEmF(u"ࠬอๆห้์ࠤๆำีࠡษ็ื๏ืแาษอࠫଘ"),XJ62UBRmIqFvfiNTQj=NeU6uRGpECkvMV5jf(u"࠱࠱࠲࠳஑"))
						sGEPOZup3k5VSq = f4vncKMRlXG9s
	ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪଙ"))
	if Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࠮ࠩଚ") in ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB:
		ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB = ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB.replace(QQHFtjcaR2VpnSyTIv(u"ࠨ࠯ࠪଛ"),NdKhAS6MXVEORLTwob92pxlZ)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(Hlp3z0APt1GR4kMYK5xST(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ଜ"),ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB)
	if sGEPOZup3k5VSq: ACOWB6GRmIbDKyl3Zn.executebuiltin(hCm2fnEXs6Zt(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧଝ"))
	return
def PPw8FVgWohGqE3iTQD4ebl2J9Lr1():
	SSyKPQBeRgho = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(lrtFSogC8Nh9(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡍࡥࡵࡋࡷࡩࡲࡹࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵࠱ࠨࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ࠾ࡠࠨࡴࡪࡶ࡯ࡩࠧ࠲ࠢࡧ࡫࡯ࡩࠧ࠲ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࡡࢂ࠲ࠢࡪࡦࠥ࠾࠶ࢃࠧଞ"))
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = O3OogF1l5reuQ.loads(SSyKPQBeRgho)[V0VZk9763fusTReHFo4(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬଟ")]
	RR0cbpOGrgfJVs2MlezmSAuTF7 = NdKhAS6MXVEORLTwob92pxlZ
	try: items = UEsxyfd8rZMLOHgzc6emSFKD0ktYiT[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡩࡵࡧࡰࡷࠬଠ")]
	except: return NdKhAS6MXVEORLTwob92pxlZ
	if items:
		for rAknWUHpDyi4IuGPfl2QYR,file in enumerate(items):
			path = file[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡧ࡫࡯ࡩࠬଡ")]
			if b0VaRYkgC4iOvHpmdeyzcQISJEsx not in path: continue
			path = path.split(b0VaRYkgC4iOvHpmdeyzcQISJEsx)[llxMLe4gobHhsj1WGvd7qmIU][llxMLe4gobHhsj1WGvd7qmIU:]
			if path==RAHOMksyDUV3w7T1QjqKNX: break
		count = UEsxyfd8rZMLOHgzc6emSFKD0ktYiT[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ࡮࡬ࡱ࡮ࡺࡳࠨଢ")][ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡷࡳࡹࡧ࡬ࠨଣ")]
		if rAknWUHpDyi4IuGPfl2QYR+llxMLe4gobHhsj1WGvd7qmIU<count: RR0cbpOGrgfJVs2MlezmSAuTF7 = items[rAknWUHpDyi4IuGPfl2QYR+llxMLe4gobHhsj1WGvd7qmIU][ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡪ࡮ࡲࡥࠨତ")]
	return RR0cbpOGrgfJVs2MlezmSAuTF7
def brXPy5wmjqZ7YN01fRGoLaUgiQ():
	eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(V0VZk9763fusTReHFo4(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥࢁࢂ࠭ଥ"))
	iTPbIQcJuMxr4 = f4vncKMRlXG9s if lrtFSogC8Nh9(u"ࠬࡡ࡝ࠨଦ") in str(eyscIJr8U9dTtFVbhPx5) else k6apiPAlLKM1ed8J42RjHh0o
	return iTPbIQcJuMxr4
def vyQfmxGsUX5BSM7Hzq2lEdb6j(VzqmQG02DtvB6aWcfENJ):
	global XZDTo3UC1RgVSdGFwlqx
	if XZDTo3UC1RgVSdGFwlqx:
		if VzqmQG02DtvB6aWcfENJ==lrtFSogC8Nh9(u"࠭ࡳࡵࡱࡳࠫଧ"):
			eDUSkwbMiCGRgN = kb2icmDGVUZfW1OFz7sv(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬନ") if kQI947MebLovYyVE08F5qPi6fj3>eGW7cI6aQhr0(u"࠲࠹࠱࠽࠾ஒ") else pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬ଩")
			ACOWB6GRmIbDKyl3Zn.executebuiltin(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩପ")+eDUSkwbMiCGRgN+Hlp3z0APt1GR4kMYK5xST(u"ࠪ࠭ࠬଫ"))
			XZDTo3UC1RgVSdGFwlqx = f4vncKMRlXG9s
	else:
		if VzqmQG02DtvB6aWcfENJ==rNyT0edugn(u"ࠫࡸࡺࡡࡳࡶࠪବ"):
			eDUSkwbMiCGRgN = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪଭ") if kQI947MebLovYyVE08F5qPi6fj3>V0VZk9763fusTReHFo4(u"࠳࠺࠲࠾࠿ஓ") else ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪମ")
			ACOWB6GRmIbDKyl3Zn.executebuiltin(lRP6GTaZJA1Xw3egLM4(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩଯ")+eDUSkwbMiCGRgN+fOc18oTm5hsdD4pVZQj(u"ࠨࠫࠪର"))
			XZDTo3UC1RgVSdGFwlqx = k6apiPAlLKM1ed8J42RjHh0o
	return
xKp3jkIvM09AZ4euXa87i5TVtfUD = {}
L0FAgEfwqWl5PUDhIzpi8J9KNm23o6 = []
LcdEWz9BRiQlr8MxgCHeuX = [OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ଱"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ଲ"),lRP6GTaZJA1Xw3egLM4(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬଳ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ଴"),NeU6uRGpECkvMV5jf(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ଵ"),Hlp3z0APt1GR4kMYK5xST(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩଶ")]
skKcVTiAr3QgdYDCbNGuER = [lrtFSogC8Nh9(u"ࠨ࠻࠼࠽࠾࠳࠹࠺࠻࠼࠱࠾࠿࠹࠺࠯࠼࠽࠾࠿࠭࠱࠲࠳࠴ࠬଷ"),gniNItGL6bKwpEW(u"ࠩ࠼࠽࠽࠾࠭࠸࠹࠹࠺࠲࠻࠵࠵࠶࠰࠷࠸࠸࠲࠮࠴࠳࠼࠻࠭ସ")]
sevfFTR5mNndl = []
q24qAUj8wQEsorTlkI = NdKhAS6MXVEORLTwob92pxlZ
AAQshG4L7n8oHUxjOdauJg,qJgRT4j0VChN3nDSd6 = None,None
OMNiY8joQx.showDialogs = k6apiPAlLKM1ed8J42RjHh0o
OMNiY8joQx.resolveonly = f4vncKMRlXG9s
ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8,lop0ZwWYLmxOPAaErzF6cQvDkVR = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8 = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,rNyT0edugn(u"ࠪࡷࡹࡸࠧହ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ଺"),OOkmZiVcfqlEurM1dHGb(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧ଻"))
if ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8:
	NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
	exec(ZZVglr6NxsRnpPOT0Be1GFCtwKv4o8,globals(),locals())
	skKcVTiAr3QgdYDCbNGuER = list(set(skKcVTiAr3QgdYDCbNGuER+NEW_BADCOMMONIDS))
else:
	PPUtBrAcTHC56ypsVgaQ7JGeRl3LF = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭࡬ࡪࡵࡷ଼ࠫ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪଽ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ା"))
	if PPUtBrAcTHC56ypsVgaQ7JGeRl3LF:
		AVfOuvBzyP1,W0ORwsexyiFh,AcxpR485tmHvub3OkI,PpMKQ5xCUt = PPUtBrAcTHC56ypsVgaQ7JGeRl3LF
		lop0ZwWYLmxOPAaErzF6cQvDkVR = B6IrC7zEHlw1oaeWf.join(AVfOuvBzyP1)
if not lop0ZwWYLmxOPAaErzF6cQvDkVR: lop0ZwWYLmxOPAaErzF6cQvDkVR = nvHz4MPEfa6Q1D5cydq()
eq7falVhHs4ZUy6k9 = hsYPN5GySKWZJoQdrkqARljF0TD()
OMNiY8joQx.HHqA8u41iPZ,OMNiY8joQx.WiJPMTZvOLGsV0xB8al,OMNiY8joQx.ZIWy6VLs8hNkbrExYSjM3OXDUaRGmo,OMNiY8joQx.mmjbEaLDvxXGOsyo627 = JcQtOuhMdvYSyLNCw([gniNItGL6bKwpEW(u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪି"),NeU6uRGpECkvMV5jf(u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫୀ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡛ࡒࡗࡐࡘࡗ࡚࠻ࡈ࡙ࠩୁ"),lrtFSogC8Nh9(u"ࠬࡕࡔ࠲࠻ࡍ࡙࠵ࡾࡂࡕࡗ࡯ࡈ࡝࠭ୂ")])
gVXbksjWZ2Y3por5yQd8wCufUzMm7T = lop0ZwWYLmxOPAaErzF6cQvDkVR.splitlines()[e8XhbyuzvjYkIsJUtB5w][-WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵࠸ஔ"):]
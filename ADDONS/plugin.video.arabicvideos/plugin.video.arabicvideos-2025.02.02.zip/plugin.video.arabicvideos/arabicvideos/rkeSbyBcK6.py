# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'DAILYMOTION'
LJfTAEQPv9h4BXdwUp = '_DLM_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
PPma30ybADqJNu = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][1]
def QGLoruqnmiAel7Op(mode,url,text,type,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	if	 mode==400: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==401: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dGcrJjBIE25mP(url,text)
	elif mode==402: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ooHOKSsxGaIg6(url,text)
	elif mode==403: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url,text)
	elif mode==404: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = t29OGaCZm65YhwKzFePv8dJ(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==405: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LSjI7YxezqHd(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==406: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = SCa0JV4WgwBplA(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==407: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Sq1thdw489E6e0sPz(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==408: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tCeASMDcmuNQZ6rPbFyE(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==409: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==411: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = cFE1vkXMhnDb6TBVO0gSyZYR3uWQ7(url,text)
	elif mode==414: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ee4wu2nEQBA5O03(text)
	elif mode==415: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = K7KeBbisCMNOcfHuUXW42JpZjPd(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==416: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = rr4CO1UcJtkvz(text,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==417: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = yXvDtGbIsS6jHE8(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الرئيسية',NdKhAS6MXVEORLTwob92pxlZ,414)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن فيديوهات',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'videos?sortBy=','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن آخر الفيديوهات',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن الفيديوهات الأكثر مشاهدة',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن قوائم التشغيل',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'playlists','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن مستخدم',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'channels','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن بث حي',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'lives','_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث عن هاشتاك',NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,'hashtags','_REMEMBERRESULTS_')
	return
def ooHOKSsxGaIg6(url,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn):
	if '/dm_' in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,False,NdKhAS6MXVEORLTwob92pxlZ,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = VNc1u4edS90FK5W6bsMgQC2B.headers
		if 'Location' in list(headers.keys()): url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+headers['Location']
	Uj1qwJ0AelZRxCaGEHgfc6NvuTIn = Whef0cxB2iR93SC5IwUtk+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn+kjd9LyNqQHMUevZiRI7OlBGF1h
	Uj1qwJ0AelZRxCaGEHgfc6NvuTIn = gOXAQy5jBNMx0rYn7CuT1JozZ(Uj1qwJ0AelZRxCaGEHgfc6NvuTIn)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: بث حي',url,411,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'channel_lives_now')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: آخر الفيديوهات',url+'/videos',408)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: المميزة',url,411,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'channel_featured_videos')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: قوائم التشغيل',url+'/playlists',407)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: قنوات ذات صلة',url,411,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'channel_related_channel')
	return
def gOXAQy5jBNMx0rYn7CuT1JozZ(title):
	title = title.rstrip('\\').strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace('\\\\','\\')
	title = L5xKSr96JmaX7N(title)
	return title
def uuvhoSanB2TWD(url,Y8jOherRiQumx0Ay):
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx([url],yNIDEX5hU4G769,'video',url)
	return
def t29OGaCZm65YhwKzFePv8dJ(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = NdKhAS6MXVEORLTwob92pxlZ
	search = search.split('/videos')[0]
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	if sort==NdKhAS6MXVEORLTwob92pxlZ: kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysortmethod',NdKhAS6MXVEORLTwob92pxlZ)
	else: kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/videos'
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"videos"(.*?)"VideoConnection"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for id,title,BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn,TLrSzM98nc2H3VODdyhpQI,TTuPH708dUNnjlG3oQpkZsi in items:
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+id
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			Y8jOherRiQumx0Ay = BsvSJC6MfbZlHmPdpXIuo+'::'+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI,Y8jOherRiQumx0Ay)
		if '"hasNextPage":true' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,404,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def LSjI7YxezqHd(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/playlists'
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	items = YYqECUofyi7wFrW.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for id,name,TdPaHnw8407jiuIMpXebmQAD,BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn,TTuPH708dUNnjlG3oQpkZsi,count in items:
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
		Y8jOherRiQumx0Ay = BsvSJC6MfbZlHmPdpXIuo+'::'+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,401,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,Y8jOherRiQumx0Ay)
	if '"hasNextPage":true' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,405,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def SCa0JV4WgwBplA(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/channels'
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"channels"(.*?)"ChannelConnection"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for id,name,TTuPH708dUNnjlG3oQpkZsi in items:
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+id
			title = 'USER:  '+name
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,402,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,name)
		if '"hasNextPage":true' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,406,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def ee4wu2nEQBA5O03(vB21qFxKM8bt4Lc65dEOfIAR7Qgah):
	kF13d0oJXn4xKH = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['home']['neon']['sections']['edges']
		if not vB21qFxKM8bt4Lc65dEOfIAR7Qgah:
			qvIpM5nBraQeA6Pk7Ny2T1HW = []
			for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
				QQbv0MHY9BcAgeDVLjxk = JApNH5rUtbSfxwmiZMcG61PX['node']['title']
				if QQbv0MHY9BcAgeDVLjxk not in qvIpM5nBraQeA6Pk7Ny2T1HW: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+QQbv0MHY9BcAgeDVLjxk,NdKhAS6MXVEORLTwob92pxlZ,414,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQbv0MHY9BcAgeDVLjxk)
				qvIpM5nBraQeA6Pk7Ny2T1HW.append(QQbv0MHY9BcAgeDVLjxk)
		else:
			for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
				QQbv0MHY9BcAgeDVLjxk = JApNH5rUtbSfxwmiZMcG61PX['node']['title']
				if QQbv0MHY9BcAgeDVLjxk==vB21qFxKM8bt4Lc65dEOfIAR7Qgah:
					hw8QZ9zyNoIDX2k4LUru0ndSxH = JApNH5rUtbSfxwmiZMcG61PX['node']['components']['edges']
					for agD8NL3OMXU in hw8QZ9zyNoIDX2k4LUru0ndSxH:
						TLrSzM98nc2H3VODdyhpQI = str(agD8NL3OMXU['node']['duration'])
						title = L5xKSr96JmaX7N(agD8NL3OMXU['node']['title'])
						title = title.replace('\/','/')
						j48S0sNOKYDM7iPmGBW1X = agD8NL3OMXU['node']['xid']
						TTuPH708dUNnjlG3oQpkZsi = agD8NL3OMXU['node']['thumbnailx480']
						TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
						zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+j48S0sNOKYDM7iPmGBW1X
						ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI)
	return
def K7KeBbisCMNOcfHuUXW42JpZjPd(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/lives'
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		try: yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['search']['lives']['edges']
		except: yyZSuRvz7PC9b6dDOxpBU = []
		for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
			name = JApNH5rUtbSfxwmiZMcG61PX['node']['title']
			name = L5xKSr96JmaX7N(name)
			j48S0sNOKYDM7iPmGBW1X = JApNH5rUtbSfxwmiZMcG61PX['node']['xid']
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+j48S0sNOKYDM7iPmGBW1X
			ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'LIVE: '+name,zehVcU893FC6LEd1Aij,403)
		if '"hasNextPage":true' in KDQ9VLgNcxFOE8jt2h:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,415,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def N6uZ53MJrAShQkYIHwTnsLy7U0(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/topics'
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		try: yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['search']['topics']['edges']
		except: yyZSuRvz7PC9b6dDOxpBU = []
		for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
			name = JApNH5rUtbSfxwmiZMcG61PX['node']['name']
			j48S0sNOKYDM7iPmGBW1X = JApNH5rUtbSfxwmiZMcG61PX['node']['xid']
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/topic/'+j48S0sNOKYDM7iPmGBW1X
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'TOPIC: '+name,zehVcU893FC6LEd1Aij,413)
		if '"hasNextPage":true' in KDQ9VLgNcxFOE8jt2h:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,412,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def J9zKfEuplg7TZPd8Vh(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	j48S0sNOKYDM7iPmGBW1X = url.split('/')[-1]
	kF13d0oJXn4xKH = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mytopicid',j48S0sNOKYDM7iPmGBW1X)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['topic']['videos']['edges']
		for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
			TLrSzM98nc2H3VODdyhpQI = str(JApNH5rUtbSfxwmiZMcG61PX['node']['duration'])
			title = L5xKSr96JmaX7N(JApNH5rUtbSfxwmiZMcG61PX['node']['title'])
			title = title.replace('\/','/')
			j48S0sNOKYDM7iPmGBW1X = JApNH5rUtbSfxwmiZMcG61PX['node']['xid']
			TTuPH708dUNnjlG3oQpkZsi = JApNH5rUtbSfxwmiZMcG61PX['node']['thumbnailx480']
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+j48S0sNOKYDM7iPmGBW1X
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI)
		if '"hasNextPage":true' in KDQ9VLgNcxFOE8jt2h:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,413,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	return
def dGcrJjBIE25mP(url,Y8jOherRiQumx0Ay):
	id = url.split('/')[-1]
	BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn = Y8jOherRiQumx0Ay.split('::',1)
	zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+BsvSJC6MfbZlHmPdpXIuo
	Uj1qwJ0AelZRxCaGEHgfc6NvuTIn = gOXAQy5jBNMx0rYn7CuT1JozZ(Uj1qwJ0AelZRxCaGEHgfc6NvuTIn)
	title = Whef0cxB2iR93SC5IwUtk+'OWNER:  '+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn+kjd9LyNqQHMUevZiRI7OlBGF1h
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,402,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn)
	kF13d0oJXn4xKH = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('myplaylistid',id)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"collection_videos"(.*?)"SectionEdge"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for id,title,TLrSzM98nc2H3VODdyhpQI,TTuPH708dUNnjlG3oQpkZsi,BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn in items:
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+id
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			Y8jOherRiQumx0Ay = BsvSJC6MfbZlHmPdpXIuo+'::'+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI,Y8jOherRiQumx0Ay)
	return
def tCeASMDcmuNQZ6rPbFyE(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	f1BA08uJ2nePQcdCHRqNEZKoGM = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	kF13d0oJXn4xKH = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mychannelid',f1BA08uJ2nePQcdCHRqNEZKoGM)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysortmethod',sort)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for id,title,TLrSzM98nc2H3VODdyhpQI,BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn,TTuPH708dUNnjlG3oQpkZsi in items:
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+id
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			Y8jOherRiQumx0Ay = BsvSJC6MfbZlHmPdpXIuo+'::'+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI,Y8jOherRiQumx0Ay)
		if '"hasNextPage":true' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,408,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	return
def Sq1thdw489E6e0sPz(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	f1BA08uJ2nePQcdCHRqNEZKoGM = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	kF13d0oJXn4xKH = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mychannelid',f1BA08uJ2nePQcdCHRqNEZKoGM)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysortmethod',sort)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for id,name,TTuPH708dUNnjlG3oQpkZsi,count,TdPaHnw8407jiuIMpXebmQAD,BsvSJC6MfbZlHmPdpXIuo,Uj1qwJ0AelZRxCaGEHgfc6NvuTIn in items:
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			Y8jOherRiQumx0Ay = BsvSJC6MfbZlHmPdpXIuo+'::'+Uj1qwJ0AelZRxCaGEHgfc6NvuTIn
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,401,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,Y8jOherRiQumx0Ay)
		if '"hasNextPage":true' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,407,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	return
def cFE1vkXMhnDb6TBVO0gSyZYR3uWQ7(url,ttU9xC6zlH7IsaRqBoiEZG5bh2Y):
	f1BA08uJ2nePQcdCHRqNEZKoGM = url.split('/')[3]
	kF13d0oJXn4xKH = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mychannelid',f1BA08uJ2nePQcdCHRqNEZKoGM)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	oC5cWGY1efnEkuaRQ = O3OogF1l5reuQ.loads(LMKFcEkU1Q7R80yt4OsgvwxbfP)
	try: items = oC5cWGY1efnEkuaRQ['data']['channel'][ttU9xC6zlH7IsaRqBoiEZG5bh2Y]['edges']
	except: items = []
	if not items: ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+'لا توجد نتائج',NdKhAS6MXVEORLTwob92pxlZ,9999)
	else:
		for rMOG2USkPesYZD9KNAVqpc in items:
			f5cCB4QLWbKr01a = rMOG2USkPesYZD9KNAVqpc['node']
			j48S0sNOKYDM7iPmGBW1X = f5cCB4QLWbKr01a['xid']
			keys = list(f5cCB4QLWbKr01a.keys())
			i0zj7rTqgnPBh91fWNKl = f5cCB4QLWbKr01a['__typename'].lower()
			if i0zj7rTqgnPBh91fWNKl=='channel':
				name = f5cCB4QLWbKr01a['name']
				r72rgqUMvH = f5cCB4QLWbKr01a['displayName']
				title = 'USER:  '+r72rgqUMvH
				TTuPH708dUNnjlG3oQpkZsi = f5cCB4QLWbKr01a['coverURLx375']
			else:
				name = f5cCB4QLWbKr01a['channel']['name']
				r72rgqUMvH = f5cCB4QLWbKr01a['channel']['displayName']
				title = f5cCB4QLWbKr01a['title']
				TTuPH708dUNnjlG3oQpkZsi = f5cCB4QLWbKr01a['thumbnailx360']
				if i0zj7rTqgnPBh91fWNKl=='live': title = 'LIVE:  '+title
			title = gOXAQy5jBNMx0rYn7CuT1JozZ(title)
			Y8jOherRiQumx0Ay = name+'::'+r72rgqUMvH
			if QBp28giCnayJzmZH6vYO:
				title = title.encode(YRvPKe2zMTDs8UCkr)
				Y8jOherRiQumx0Ay = Y8jOherRiQumx0Ay.encode(YRvPKe2zMTDs8UCkr)
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			if i0zj7rTqgnPBh91fWNKl=='channel':
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+j48S0sNOKYDM7iPmGBW1X
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,402,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,Y8jOherRiQumx0Ay)
			else:
				if i0zj7rTqgnPBh91fWNKl=='video': TLrSzM98nc2H3VODdyhpQI = str(f5cCB4QLWbKr01a['duration'])
				else: TLrSzM98nc2H3VODdyhpQI = NdKhAS6MXVEORLTwob92pxlZ
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+j48S0sNOKYDM7iPmGBW1X
				ZI51XvE8YatWCmNdrp(i0zj7rTqgnPBh91fWNKl,LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI,Y8jOherRiQumx0Ay)
	return
def rr4CO1UcJtkvz(search,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	kF13d0oJXn4xKH = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mysearchwords',search)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagelimit','40')
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'/hashtags'
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		try: yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['search']['hashtags']['edges']
		except: yyZSuRvz7PC9b6dDOxpBU = []
		for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
			name = JApNH5rUtbSfxwmiZMcG61PX['node']['name']
			name = L5xKSr96JmaX7N(name)
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/hashtag/'+name[1:]
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'HSHTG: '+name,zehVcU893FC6LEd1Aij,417)
		if '"hasNextPage":true' in KDQ9VLgNcxFOE8jt2h:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,416,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,search)
	return
def yXvDtGbIsS6jHE8(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC=NdKhAS6MXVEORLTwob92pxlZ):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	name = url.split('/')[-1]
	kF13d0oJXn4xKH = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('myhashtagname',name)
	kF13d0oJXn4xKH = kF13d0oJXn4xKH.replace('mypagenumber',jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	KDQ9VLgNcxFOE8jt2h = AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH)
	if KDQ9VLgNcxFOE8jt2h:
		wZ1yGC4gPfqSNXaETQoLD = BdnA8WwtJeKUVvE('dict',KDQ9VLgNcxFOE8jt2h)
		yyZSuRvz7PC9b6dDOxpBU = wZ1yGC4gPfqSNXaETQoLD['data']['contentFeed']['edges']
		for JApNH5rUtbSfxwmiZMcG61PX in yyZSuRvz7PC9b6dDOxpBU:
			TLrSzM98nc2H3VODdyhpQI = str(JApNH5rUtbSfxwmiZMcG61PX['node']['post']['duration'])
			title = L5xKSr96JmaX7N(JApNH5rUtbSfxwmiZMcG61PX['node']['post']['title'])
			title = title.replace('\/','/')
			j48S0sNOKYDM7iPmGBW1X = JApNH5rUtbSfxwmiZMcG61PX['node']['post']['xid']
			TTuPH708dUNnjlG3oQpkZsi = JApNH5rUtbSfxwmiZMcG61PX['node']['post']['thumbnailx480']
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('\/','/')
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/video/'+j48S0sNOKYDM7iPmGBW1X
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,403,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI)
		if '"hasNextPage":true' in KDQ9VLgNcxFOE8jt2h:
			jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)+1)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,url,416,NdKhAS6MXVEORLTwob92pxlZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	return
def AQq8nClMiNcDuvgKZhHb5EwpXRx6(kF13d0oJXn4xKH,search=NdKhAS6MXVEORLTwob92pxlZ):
	if J92gCnbGWidQV70lBteTwU6D8uyzL: kF13d0oJXn4xKH = kF13d0oJXn4xKH.encode(YRvPKe2zMTDs8UCkr)
	H6Co4YkQ182Nx7 = Y4biQv7yf62hajGdmlJ()
	headers = {"Authorization":H6Co4YkQ182Nx7,"Origin":qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'Content-Type':'text/plain; charset=utf-8'}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',PPma30ybADqJNu,kF13d0oJXn4xKH,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'DAILYMOTION-GET_PAGEDATA-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def Y4biQv7yf62hajGdmlJ():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'DAILYMOTION-GET_AUTHINTICATION-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	GGJRWS6MFKEQTx = YYqECUofyi7wFrW.findall('var r="(.*?)",o="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	mOBkiT7zv9UncQ0Ie3gYpuS,h1ABl83noEeR6HJMrQvkO7jzfusI = GGJRWS6MFKEQTx[-1]
	V9lY3RcEGvLuI = 'https://graphql.api.dailymotion.com/oauth/token'
	XDqRCjJLQFOHlKzS3up78ifrn = 'client_credentials'
	data = {'client_id':mOBkiT7zv9UncQ0Ie3gYpuS,'client_secret':h1ABl83noEeR6HJMrQvkO7jzfusI,'grant_type':XDqRCjJLQFOHlKzS3up78ifrn}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',V9lY3RcEGvLuI,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	GGJRWS6MFKEQTx = YYqECUofyi7wFrW.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	VUcHPbvxXF3hBCTpinf6y4dwrsguLt,Ob31RhCHfi29NaplZKEoVqBJ4Aw = GGJRWS6MFKEQTx[0]
	H6Co4YkQ182Nx7 = Ob31RhCHfi29NaplZKEoVqBJ4Aw+" "+VUcHPbvxXF3hBCTpinf6y4dwrsguLt
	return H6Co4YkQ182Nx7
def tTIQWSbOEqHJ4(search,iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z=NdKhAS6MXVEORLTwob92pxlZ):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z and showDialogs:
		WNdDwIAUiPOB0CLRaqlQvK = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('موقع ديلي موشن - اختر البحث',WNdDwIAUiPOB0CLRaqlQvK)
		if rRfpvbZojlygET5JL87wdzIPGe==-1: return
		elif rRfpvbZojlygET5JL87wdzIPGe==0: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'videos?sortBy='
		elif rRfpvbZojlygET5JL87wdzIPGe==1: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'videos?sortBy=RECENT'
		elif rRfpvbZojlygET5JL87wdzIPGe==2: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'videos?sortBy=VIEW_COUNT'
		elif rRfpvbZojlygET5JL87wdzIPGe==3: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'playlists'
		elif rRfpvbZojlygET5JL87wdzIPGe==4: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'channels'
		elif rRfpvbZojlygET5JL87wdzIPGe==5: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'lives'
		elif rRfpvbZojlygET5JL87wdzIPGe==6: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in LM1WpcGdrz8QtHV0i53k: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in LM1WpcGdrz8QtHV0i53k: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in LM1WpcGdrz8QtHV0i53k: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'channels'
	elif '_DAILYMOTION-LIVES_' in LM1WpcGdrz8QtHV0i53k: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in LM1WpcGdrz8QtHV0i53k: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'hashtags'
	elif not iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = 'videos?sortBy='
	if not search:
		search = Z6GiHgnz0jNytc()
		if not search: return
	if 'videos' in iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: t29OGaCZm65YhwKzFePv8dJ(search+'/'+iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z)
	elif 'playlists' in iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: LSjI7YxezqHd(search)
	elif 'channels' in iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: SCa0JV4WgwBplA(search)
	elif 'lives' in iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: K7KeBbisCMNOcfHuUXW42JpZjPd(search)
	elif 'hashtags' in iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z: rr4CO1UcJtkvz(search)
	return
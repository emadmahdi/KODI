# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬൔ")
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,ui7N5YGR9KdslpEbQkVTwFqDgI=NdKhAS6MXVEORLTwob92pxlZ):
	if   pPrvqm3tjuXLTgw1==IlL8ZnX74Yvep(u"࠵႐"): zu3pLr0gqTPDd(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==V0VZk9763fusTReHFo4(u"࠷႑"): pass
	elif pPrvqm3tjuXLTgw1==OOkmZiVcfqlEurM1dHGb(u"࠲႒"): AWxD1rw2o6EeF(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==pnHgvFOCBZzc08yULQJGIqw9bf(u"࠴႓"): Jou4KX8bw3eOn5fxzayWFAN()
	elif pPrvqm3tjuXLTgw1==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠶႔"): evDOF2iEbqN5txMnVoXRSsgd8c(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==Hlp3z0APt1GR4kMYK5xST(u"࠸႕"): Rt6YElvDOzxp0UqJIo5cXNFmdL()
	elif pPrvqm3tjuXLTgw1==lNTJCZeBicWEz0Mg(u"࠺႖"): mgwjkqxKZcSa2Ofd5EJ()
	elif pPrvqm3tjuXLTgw1==rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠼႗"): PaA9seqk5wpFI1lDKtonb8h2()
	elif pPrvqm3tjuXLTgw1==hCm2fnEXs6Zt(u"࠾႘"): nRljB9zWcSh()
	elif pPrvqm3tjuXLTgw1==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠹႙"): KeJF5gduqhEoy0WmIbC2val74OX()
	elif pPrvqm3tjuXLTgw1==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠲࠷࠳ႚ"): TTqocZXWd73KGkb()
	elif pPrvqm3tjuXLTgw1==PzIpQnUXxRwNCivDhdakWTE(u"࠳࠸࠵ႛ"): eNcfBX4sLpyQmxa8S()
	elif pPrvqm3tjuXLTgw1==rNyT0edugn(u"࠴࠹࠷ႜ"): GMd87U3cxOjgXb()
	elif pPrvqm3tjuXLTgw1==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵࠺࠹ႝ"): faQSprgwXs2vVIFP4dAiT5NmhjE07()
	elif pPrvqm3tjuXLTgw1==hCm2fnEXs6Zt(u"࠶࠻࠴႞"): ye6Yf3kJxS4h1ZDsKE()
	elif pPrvqm3tjuXLTgw1==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠷࠵࠶႟"): aV4j9FvDb3HyT8iLJ()
	elif pPrvqm3tjuXLTgw1==eGW7cI6aQhr0(u"࠱࠶࠸Ⴀ"): l5pmuBR3nSzT()
	elif pPrvqm3tjuXLTgw1==V0VZk9763fusTReHFo4(u"࠲࠷࠺Ⴁ"): TamyBH0gDMKWsOZ3IxrnwFNh()
	elif pPrvqm3tjuXLTgw1==lRP6GTaZJA1Xw3egLM4(u"࠳࠸࠼Ⴂ"): lAUv3LZEsaG05SXOnboNfh()
	elif pPrvqm3tjuXLTgw1==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠴࠹࠾Ⴃ"): vvgOIsoaZnwEXKRh29ui(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==eGW7cI6aQhr0(u"࠵࠼࠶Ⴄ"): FOadCTG5zvKu9()
	elif pPrvqm3tjuXLTgw1==pnHgvFOCBZzc08yULQJGIqw9bf(u"࠶࠽࠱Ⴅ"): j1DR9NEu3oGU8xi()
	elif pPrvqm3tjuXLTgw1==lrtFSogC8Nh9(u"࠷࠷࠳Ⴆ"): ij5kzycSfln3WRu71XerIm4([ui7N5YGR9KdslpEbQkVTwFqDgI],k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
	elif pPrvqm3tjuXLTgw1==R3lezw8h407ZvrAFxT(u"࠱࠸࠵Ⴇ"): aV1HYqMRxUA3vmOr8LnGofj0FI5C7(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫൕ"),k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠲࠹࠷Ⴈ"): aV1HYqMRxUA3vmOr8LnGofj0FI5C7(rNyT0edugn(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨൖ"),k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠳࠺࠹Ⴉ"): DBqX9KAv7rR6U8IncMQfgT()
	elif pPrvqm3tjuXLTgw1==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠴࠻࠻Ⴊ"): uVIiT3vFU2nhwk4jagcN()
	elif pPrvqm3tjuXLTgw1==IlL8ZnX74Yvep(u"࠵࠼࠽Ⴋ"): bQ7JWcP6NYfAXo9shkDUgK3S(lRP6GTaZJA1Xw3egLM4(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪൗ"))
	elif pPrvqm3tjuXLTgw1==pnHgvFOCBZzc08yULQJGIqw9bf(u"࠶࠽࠹Ⴌ"): bQ7JWcP6NYfAXo9shkDUgK3S(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ൘"))
	elif pPrvqm3tjuXLTgw1==gniNItGL6bKwpEW(u"࠷࠹࠱Ⴍ"): sBJb1NZASzY()
	elif pPrvqm3tjuXLTgw1==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠱࠺࠳Ⴎ"): zCgP09WFRJukoB2N4Dhab1rj6y()
	elif pPrvqm3tjuXLTgw1==IlL8ZnX74Yvep(u"࠲࠻࠵Ⴏ"): D23q8QTREuvAFJnm4B7cKroHyS()
	elif pPrvqm3tjuXLTgw1==rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠳࠼࠷Ⴐ"): yfMVixNbRGoH8m9()
	elif pPrvqm3tjuXLTgw1==LtGoXlQ2IYxqTJRySE6udfW98(u"࠴࠽࠹Ⴑ"): xo2Sme8a4DOw0()
	elif pPrvqm3tjuXLTgw1==kb2icmDGVUZfW1OFz7sv(u"࠵࠾࠻Ⴒ"): EEWbtr1wNXc9l()
	elif pPrvqm3tjuXLTgw1==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠶࠿࠶Ⴓ"): REH4tT9sJOf5xw1BkiZ()
	elif pPrvqm3tjuXLTgw1==NOrchaEV1iIZ87Uzlwgum(u"࠷࠹࠸Ⴔ"): ZI1SjsYWefGiqXaVRm3AN()
	elif pPrvqm3tjuXLTgw1==kb2icmDGVUZfW1OFz7sv(u"࠱࠺࠺Ⴕ"): l8EOZCSWVNJL97HieFrkwxyU()
	elif pPrvqm3tjuXLTgw1==xY4icgQUj6mPVs73CTKu(u"࠲࠻࠼Ⴖ"): yRPY5kWzacJK2GX()
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠵࠷࠴Ⴗ"): NKylfkLxoedgn(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==JGwsL21ZRlqSrWxEmF(u"࠶࠸࠶Ⴘ"): AqZG1KQcdsrR9zo4OgextNwM()
	elif pPrvqm3tjuXLTgw1==lRP6GTaZJA1Xw3egLM4(u"࠷࠹࠸Ⴙ"): mNFrKu8AlMow7O1YgQZEkBxzn()
	elif pPrvqm3tjuXLTgw1==pnHgvFOCBZzc08yULQJGIqw9bf(u"࠸࠺࠳Ⴚ"): hhq6teVbDwp9B5oniyuPvjQEGKJ()
	elif pPrvqm3tjuXLTgw1==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠹࠴࠵Ⴛ"): tQgd8Fu5lKb(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==QQHFtjcaR2VpnSyTIv(u"࠳࠵࠷Ⴜ"): k95kFoB8VTuAHYlp()
	elif pPrvqm3tjuXLTgw1==R3lezw8h407ZvrAFxT(u"࠴࠶࠹Ⴝ"): V57ovgQhPbWzRZO6jxU0(f4vncKMRlXG9s)
	elif pPrvqm3tjuXLTgw1==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵࠷࠻Ⴞ"): uuKwU7AkCmnMylP8gqsdeHxLb5i(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠶࠸࠽Ⴟ"): yHXsFlfdoE9GCkPM5I0baA()
	elif pPrvqm3tjuXLTgw1==NeU6uRGpECkvMV5jf(u"࠷࠹࠿Ⴠ"): T5BXLUGacv4KuN1oHf0Swe(NeU6uRGpECkvMV5jf(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭൙"),k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==OOkmZiVcfqlEurM1dHGb(u"࠺࠶࠰Ⴡ"): dm1rJV8XK60NynfsIRH7UztqQMT4e()
	elif pPrvqm3tjuXLTgw1==lRP6GTaZJA1Xw3egLM4(u"࠻࠰࠲Ⴢ"): WAF7mMUpoN5Okjlzdcef2QxG()
	elif pPrvqm3tjuXLTgw1==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠵࠱࠴Ⴣ"): TAayl1jpmQFwCienqZcV8hJ2t()
	elif pPrvqm3tjuXLTgw1==hCm2fnEXs6Zt(u"࠶࠲࠶Ⴤ"): eeHBsW5xzSijdF2k36qCbp(LKitvZysHM)
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠷࠳࠸Ⴥ"): eeHBsW5xzSijdF2k36qCbp(cXO4eSZFqrbYPotf)
	elif pPrvqm3tjuXLTgw1==eGW7cI6aQhr0(u"࠸࠴࠺჆"): JiP0jZO9kYfo8sVv()
	elif pPrvqm3tjuXLTgw1==YJpWv4QzC7sx8INVPukeZiOD03K(u"࠹࠵࠼Ⴧ"): fPhA8zJWjpb19U(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==Tzx81Wb0RZC4ID5AyiU2(u"࠺࠶࠷჈"): Mqt5IxvRGwjPeUHfkSaOnT()
	elif pPrvqm3tjuXLTgw1==gniNItGL6bKwpEW(u"࠻࠰࠹჉"): r5cSE6D89t2R1WbxidOGofa()
	elif pPrvqm3tjuXLTgw1==eGW7cI6aQhr0(u"࠵࠱࠻჊"): G2bJyDmxeYP50RXlSnLgU9cOtw7s1v()
	elif pPrvqm3tjuXLTgw1==LtGoXlQ2IYxqTJRySE6udfW98(u"࠲࠲࠵࠴჋"): kwhm7U0qtFi4DeX2Qj6bpELnTB()
	elif pPrvqm3tjuXLTgw1==rNyT0edugn(u"࠳࠳࠶࠶჌"): c5NTxnAdsB()
	elif pPrvqm3tjuXLTgw1==kb2icmDGVUZfW1OFz7sv(u"࠴࠴࠷࠸Ⴭ"): bQ7JWcP6NYfAXo9shkDUgK3S(HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ൚"))
	elif pPrvqm3tjuXLTgw1==Hlp3z0APt1GR4kMYK5xST(u"࠵࠵࠸࠳჎"): LGnsmF5tf7BEPCvI()
	return
def LGnsmF5tf7BEPCvI():
	rFSUYwTohtsByX4HJ0qElMD8nuk = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ൛"))
	message = lNTJCZeBicWEz0Mg(u"ࠫฬ๊ัใ็ࠣห้๋อะัࠣัฬ๊๊ศ๊ࠢ์ࠥࡀࠠࠡࠢࠪ൜")+str(rFSUYwTohtsByX4HJ0qElMD8nuk)+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦ࡫ࡣࡲࡶࠫ൝") if rFSUYwTohtsByX4HJ0qElMD8nuk else xY4icgQUj6mPVs73CTKu(u"࠭วๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࠦๅห๊ๅๅฮࠦอศๆํหࠬ൞")
	message = Whef0cxB2iR93SC5IwUtk+message+QQHFtjcaR2VpnSyTIv(u"ࠧ࡝ࡰ๊่ࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊ࠠฤ๊ࠣฮ฿๐๊าࠢิๆ๊ࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮ࠭ൟ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(fOc18oTm5hsdD4pVZQj(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨൠ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩัีําࠧൡ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠪษ๏่วโࠩൢ"),V0VZk9763fusTReHFo4(u"ࠫฯฺฺ๋ๆࠪൣ"),gniNItGL6bKwpEW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ൤"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭วๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࠦ็๋ࠢ฼้้๐ษࠡ์ๅ์๊ࠦศ่ษࠣห้ฮั็ษ่ะࠥฮวฯฬํหึࠦรฺๆ์ࠤั๎ฯส่ࠢฮํ็ัสࠢ็ี็๋ࠠศๆฯ์ิฯࠠศๆำ๎ࠥอๆหࠢอัิี็ࠡใํࠤ์ึ็ࠡษ็ุฬฺษࠡ࠰࠱ࠤํํะศ่ࠢ฽๋อ็ࠡ฻้ำ๊อࠠหไ๋้ࠥอๆหࠢหฮูเ๊ๅࠢไ๎ิ๐่ࠡใส๊ࠥอไษำ้ห๊าࠠๅ่ࠣ๎ุษไไࠢ฼๊ࠥอไอ๊าอࠥอไห์ࠣฮึ๐ฯ่ษ่ࠣศ์ࠠศๆหี๋อๅอࠢึ์ๆ๊ࠦฯฬสีࠥอไอ๊าอࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳ูࠦๅ็สࠤฬ์็ࠡ์ฯฬࠥอฮห์สีࠥืโๆࠢฯ์ิฯࠠึ฼ํีࠥหะศࠢๆห๋ะࠠศๆศ๊ฯืๆหࠢ฼๊ิ้ࠠษูํสฮࠦร้ࠢๅ่๏๊ษ࡝ࡰ࡟ࡲࠬ൥")+message)
	if us7rL1qZAJURmQjPTtIhGN0daXf869 in [-pnHgvFOCBZzc08yULQJGIqw9bf(u"࠶჏"),IlL8ZnX74Yvep(u"࠶ა")]: return
	if us7rL1qZAJURmQjPTtIhGN0daXf869==R3lezw8h407ZvrAFxT(u"࠱ბ"):
		rFSUYwTohtsByX4HJ0qElMD8nuk = NdKhAS6MXVEORLTwob92pxlZ
		ZaUVqChKHwRLYbeiOv(eGW7cI6aQhr0(u"ࠧࠨ൦"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࠩ൧"),fOc18oTm5hsdD4pVZQj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ൨"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ์ๅหๆࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮ࠭൩"))
	else:
		items = [WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫ࠷࠻࠰ࠡ࡭ࡥࡴࡸ࠭൪"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬ࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧ൫"),JGwsL21ZRlqSrWxEmF(u"࠭࠷࠶࠲ࠣ࡯ࡧࡶࡳࠨ൬"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧ࠲࠲࠳࠴ࠥࡱࡢࡱࡵࠪ൭"),hCm2fnEXs6Zt(u"ࠨ࠳࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫ൮"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠴࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ൯"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࠵࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭൰"),rNyT0edugn(u"ࠫ࠷࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ൱"),lRP6GTaZJA1Xw3egLM4(u"ࠬ࠸࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ൲"),QQHFtjcaR2VpnSyTIv(u"࠭࠳࠱࠲࠳ࠤࡰࡨࡰࡴࠩ൳"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧ࠴࠷࠳࠴ࠥࡱࡢࡱࡵࠪ൴"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨ࠶࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ൵"),JGwsL21ZRlqSrWxEmF(u"ࠩ࠷࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ൶"),lrtFSogC8Nh9(u"ࠪ࠹࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭൷"),OOkmZiVcfqlEurM1dHGb(u"ࠫ࠻࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ൸"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬ࠽࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ൹"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭࠸࠱࠲࠳ࠤࡰࡨࡰࡴࠩൺ"),NeU6uRGpECkvMV5jf(u"ࠧ࠺࠲࠳࠴ࠥࡱࡢࡱࡵࠪൻ"),hCm2fnEXs6Zt(u"ࠨ࠳࠳࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬർ"),R3lezw8h407ZvrAFxT(u"ࠩ࠴࠵࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ൽ"),V0VZk9763fusTReHFo4(u"ࠪ࠵࠷࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧൾ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫ࠾࠿࠹࠺࠻ࠣ࡯ࡧࡶࡳࠨൿ")]
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(NOrchaEV1iIZ87Uzlwgum(u"ࠬอฮหำࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠣห้๋ๆศีหอࠬ඀"),items)
		if rRfpvbZojlygET5JL87wdzIPGe==-fOc18oTm5hsdD4pVZQj(u"࠲გ"): return
		rFSUYwTohtsByX4HJ0qElMD8nuk = str(items[rRfpvbZojlygET5JL87wdzIPGe][:-QQHFtjcaR2VpnSyTIv(u"࠷დ")])
		ZaUVqChKHwRLYbeiOv(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠧඁ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠧࠨං"),Hlp3z0APt1GR4kMYK5xST(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫඃ"),lNTJCZeBicWEz0Mg(u"้ࠩะาะฺࠠ็็๎ฮࠦสี฼ํ่ࠥ๎สฮัํำࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส࡞ࡱࡠࡳ࠭඄")+Whef0cxB2iR93SC5IwUtk+rFSUYwTohtsByX4HJ0qElMD8nuk+HHvYL68lbJVZWM7tQEzSex3(u"ࠪࠤࡰࡨࡰࡴࠩඅ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(QQHFtjcaR2VpnSyTIv(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨආ"),rFSUYwTohtsByX4HJ0qElMD8nuk)
	return
def c5NTxnAdsB(Bj6sntVgZdPu8RXFLAW5NiQl=f4vncKMRlXG9s):
	iTPbIQcJuMxr4 = brXPy5wmjqZ7YN01fRGoLaUgiQ()
	D3koGH7Y9w4Q512cPCIvrZUhtpR = PzIpQnUXxRwNCivDhdakWTE(u"ࠬอไหึ฽๎้ࠦวๅๆสั็ฺ๊ࠦ็็ࠫඇ") if iTPbIQcJuMxr4 else NeU6uRGpECkvMV5jf(u"࠭วๅฬื฾๏๊ࠠศๆ็หา่ࠠๆฬ๋ๆๆ࠭ඈ")
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡤࡧࡱࡸࡪࡸࠧඉ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨะิ์ั࠭ඊ"),HVmIrFwau90jQsgiWzExk(u"ࠩศ๎็อแࠨඋ"),lNTJCZeBicWEz0Mg(u"ࠪฮูเ๊ๅࠩඌ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧඍ"),Whef0cxB2iR93SC5IwUtk+D3koGH7Y9w4Q512cPCIvrZUhtpR+kjd9LyNqQHMUevZiRI7OlBGF1h+B6IrC7zEHlw1oaeWf+V0VZk9763fusTReHFo4(u"ࠬํะ่ࠢส่ํ฾๊โหࠣฮั฿ไࠡๅ๋ำ๏ࠦร้ฬ๋้ฬะ๊ไ์สࠤ๏่่ๆࠢหฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠣ࠲࠳ࠦลๆษࠣฬ฾ีࠠศ่อ๋ฬวࠠศๆไ๎ิ๐่ࠡษ็ัฬ๊๊ࠡสฦ็๊๊็ࠡ࠰࠱ࠤศ๎ࠠษ฻าࠤฬ๊ๆใำࠣ฽้๏ࠠำำࠣࠦฯาว้ิࠣษ้๏ࠠศๆ็หา่ࠢࠡ࠰࠱ࠤํษ๊ืษ้๊้ࠣๆࠡว็฾ฬวࠠศๆอุ฿๐ไࠡษ็่ฬำโࠡสส่๋่ัࠡ฻็ํุࠥัࠡࠤศ๎็อแࠡษ็ๅ๏ี๊้ࠤࠣ࠲࠳่ࠦฤ์ูห๋ࠥๅไ่ࠣห้อำหใสำฮࠦๅ็ࠢอ฾๏๐ัࠡฬิฮ๏ฮࠠๆฯอ์๏อสࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎ฮศืฬࠤฯืส๋สࠣั้่วหࠢสู่๊ไิๆสฮࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦ็ั้ࠣห้๎ุ๋ใฬࠤศ๋ࠠฦ์ๅหๆํวࠡมࠤࠥࠬඎ"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869==llxMLe4gobHhsj1WGvd7qmIU: eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(JGwsL21ZRlqSrWxEmF(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀ࡛࡞ࡿࢀࠫඏ"))
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==cCRvAuJQfjBpTg0PbYiaNO87: eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(OOkmZiVcfqlEurM1dHGb(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࠳ࡠࢁࢂ࠭ඐ"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869 in [llxMLe4gobHhsj1WGvd7qmIU,cCRvAuJQfjBpTg0PbYiaNO87]:
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡶࡵࡹࡪ࠭එ") in str(eyscIJr8U9dTtFVbhPx5): ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬඒ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧඓ"))
		else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧඔ"),Hlp3z0APt1GR4kMYK5xST(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪඕ"))
	return
def kwhm7U0qtFi4DeX2Qj6bpELnTB():
	url = xKp3jkIvM09AZ4euXa87i5TVtfUD[R3lezw8h407ZvrAFxT(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨඖ")][OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠳ე")]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,rNyT0edugn(u"ࠧࡈࡇࡗࠫ඗"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭඘"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	tm1yhwbq8vSjXE6dnYk0P = YYqECUofyi7wFrW.findall(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࠩࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩ඙"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	tm1yhwbq8vSjXE6dnYk0P = sorted(tm1yhwbq8vSjXE6dnYk0P,reverse=k6apiPAlLKM1ed8J42RjHh0o)
	rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(hCm2fnEXs6Zt(u"ࠪหำะัࠡษ็ษฺีวาࠢส่ี๐ࠠหำํำࠥะหษ์อ๋ࠬක"),tm1yhwbq8vSjXE6dnYk0P)
	if rRfpvbZojlygET5JL87wdzIPGe>=lrtFSogC8Nh9(u"࠴ვ"):
		qqfy6YCUAzholrBI5Fj1 = url.rsplit(xY4icgQUj6mPVs73CTKu(u"ࠫ࠴࠭ඛ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠶ზ"))[HVmIrFwau90jQsgiWzExk(u"࠶თ")]+IlL8ZnX74Yvep(u"ࠬ࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠭ග")+tm1yhwbq8vSjXE6dnYk0P[rRfpvbZojlygET5JL87wdzIPGe]+lrtFSogC8Nh9(u"࠭࠮ࡻ࡫ࡳࠫඝ")
		succeeded = ePcCVZf6n5m(rNyT0edugn(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬඞ"),qqfy6YCUAzholrBI5Fj1,rNyT0edugn(u"࡚ࡲࡶࡧᄫ"))
		if succeeded:
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬඟ"),NdKhAS6MXVEORLTwob92pxlZ)
			TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬච"),hCm2fnEXs6Zt(u"ࠪฮ๊ࠦสฬสํฮࠥหีะษิࠤ็ี๊ๆࠢ็่อืๆศ็ฯࠤ࠳࠴ࠠๅๅ้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠฤ๊อ์๊อส๋ๅํหࠥฮสฮัํฯࠥาๅ๋฻ࠣห้ฮัศ็ฯࠤออำหะาห๊ࠦยฯำࠣษฺีวา่ࠢฮํ็ัࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣษ๏่วโࠢส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็๋ีอࠠศๆหี๋อๅอࠢยࠥࠦ࠭ඡ"))
			if TT32BcvomhVewpgMSWkEb46y7xqO: T5BXLUGacv4KuN1oHf0Swe(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩජ"),k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o)
	return
def Mqt5IxvRGwjPeUHfkSaOnT():
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨඣ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳ࠦ็ัษࠣห้๋ำฮࠢึ์ๆ๊ࠦิสหࠤฯำฯ๋อࠣๅํื๊ࠡๆฯ้๏฿ฺ้ࠠสสๆࠦวๅสิ๊ฬ๋ฬࠡษ็ฮ๏ࠦสฺฬ่ำࠥ฿ไ๊่ࠢีํื้ࠠไอࠤ๊฿๊็ࠩඤ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(xY4icgQUj6mPVs73CTKu(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬඥ"),NdKhAS6MXVEORLTwob92pxlZ)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OOkmZiVcfqlEurM1dHGb(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨඦ"),NdKhAS6MXVEORLTwob92pxlZ)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ට"),NdKhAS6MXVEORLTwob92pxlZ)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫඨ"),NdKhAS6MXVEORLTwob92pxlZ)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(R3lezw8h407ZvrAFxT(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ඩ"),NdKhAS6MXVEORLTwob92pxlZ)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨඪ"),NOrchaEV1iIZ87Uzlwgum(u"࠭สๆ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰ࠣ์ุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศหฯา๎ะࠦ็ั้ࠣห้หูะษาหฯࠦ࠮࠯๋ࠢว๏฼วࠡฬะำ๏ัฺ้ࠠสสๆࠦวๅสิ๊ฬ๋ฬࠡษ็ฮ๏ࠦสฺฬ่ำࠥ฿ไ๊ࠢส่ํ่สࠨණ"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def G2bJyDmxeYP50RXlSnLgU9cOtw7s1v():
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪඬ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥ࠴࠮๊่ࠡืาࠦฬๆ์฼ࠤ๊๊แศฬࠣห้ฮั็ษ่ะࠥอไใัํ้ฮࠦ࠮࠯ࠢ็็๏ฺ๊๊ࠦาࠤฬ๊ศา่ส้ัࠦลๅ๋ࠣัฬ๊ษࠡษ็ูๆืࠠ࠯࠰ࠣ๎฾์๊ࠡฬฯำ๏ีࠠศๆหี๋อๅอ๋ࠢฮฺ็๊า้ࠣ์ํ฼ู่ࠢหัฬ๊ษࠡษ็ฺ้์ูࠡษ็ฮ๏่ࠦื฻๊หࠥอไๆสิ้ัࠦฟࠢࠣࠪත"))
	if TT32BcvomhVewpgMSWkEb46y7xqO:
		tQgd8Fu5lKb(f4vncKMRlXG9s)
		vWN2YePRikAXEFO6dQ8CT51bz(vJQYPbL42F013CRoqtEUI,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬථ"),V0VZk9763fusTReHFo4(u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬද"))
	return
def JiP0jZO9kYfo8sVv():
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧධ"),rNyT0edugn(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨන"))
	oo8Tv5VBQAZbptxl = igNr4jWHh8eIS0bM(f4vncKMRlXG9s)
	ZcB27T4auFqptXL = B6IrC7zEHlw1oaeWf
	mfEtxWA0Tcrbdp45 = D7INg5kyRjwf4ZtoePVUrb1h2SJ+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢࠪ඲")+kjd9LyNqQHMUevZiRI7OlBGF1h
	ttkT9EoOxgPWXDeR = B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+PzIpQnUXxRwNCivDhdakWTE(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫඳ")+kjd9LyNqQHMUevZiRI7OlBGF1h+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࡞ࡱࡠࡳ࠭ප")
	for id,gMXJ1uE2flZASBm6jYhspTnIe,dhfVevor7I2tWBm,VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2,reason in reversed(oo8Tv5VBQAZbptxl):
		if id==lRP6GTaZJA1Xw3egLM4(u"ࠩ࠳ࠫඵ"):
			Bj9EMHUr2wftyvR,JFTMsjhRbzieXp2x = VXdz0nyjQHPLeE.split(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡠࡳࡁ࠻ࠨබ"))
			continue
		if ZcB27T4auFqptXL!=B6IrC7zEHlw1oaeWf: ZcB27T4auFqptXL += ttkT9EoOxgPWXDeR
		ZLI75sAmWojzUYJtluw8h6H4reCf = xY4icgQUj6mPVs73CTKu(u"ࠫࡠࡘࡔࡍ࡟ࠪභ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+id+xY4icgQUj6mPVs73CTKu(u"ࠬࠦ࠺ࠡࠩම")+rNyT0edugn(u"࠭วๅีวห้ࠦ࠺ࠡࠩඹ")+kjd9LyNqQHMUevZiRI7OlBGF1h+dhfVevor7I2tWBm
		XXnFpTZ9ksicAKzg1lMCP5Dtq = HVmIrFwau90jQsgiWzExk(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨය")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+IlL8ZnX74Yvep(u"ࠨษ็ะํอศࠡ࠼ࠣࠫර")+kjd9LyNqQHMUevZiRI7OlBGF1h+VXdz0nyjQHPLeE
		mbzrpYR0ZBMvjxJ2eDS = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ඼")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪห้ิืฤࠢ࠽ࠤࠬල")+kjd9LyNqQHMUevZiRI7OlBGF1h+jjpbVgW3hUw7XMyFI50N9ismLlGv2
		MWX39d1VjgqPaftLAwUD8orJc = lrtFSogC8Nh9(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬ඾")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬอไิสหࠤ࠿ࠦࠧ඿")+kjd9LyNqQHMUevZiRI7OlBGF1h+reason
		ZcB27T4auFqptXL += ZLI75sAmWojzUYJtluw8h6H4reCf+XXnFpTZ9ksicAKzg1lMCP5Dtq+B6IrC7zEHlw1oaeWf+mfEtxWA0Tcrbdp45+B6IrC7zEHlw1oaeWf+mbzrpYR0ZBMvjxJ2eDS+MWX39d1VjgqPaftLAwUD8orJc+B6IrC7zEHlw1oaeWf
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(OOkmZiVcfqlEurM1dHGb(u"࠭ࡲࡪࡩ࡫ࡸࠬව"),JFTMsjhRbzieXp2x,ZcB27T4auFqptXL,HVmIrFwau90jQsgiWzExk(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨශ"))
	return
def eeHBsW5xzSijdF2k36qCbp(file):
	if file==cXO4eSZFqrbYPotf: uAEC7e8dgoDw14 = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨෂ")
	elif file==LKitvZysHM: uAEC7e8dgoDw14 = lRP6GTaZJA1Xw3egLM4(u"ࠩๅ์ฬฬๅࠡฤัีࠥอไโ์า๎ํํวหࠩස")
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡧࡪࡴࡴࡦࡴࠪහ"),OOkmZiVcfqlEurM1dHGb(u"ู๊ࠫอࠨළ"),Hlp3z0APt1GR4kMYK5xST(u"ࠬหีๅษะࠫෆ"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ฮา๊ฯࠫ෇"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ෈"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ้็ࠤฯื๊ะࠢศู้ออࠡ็็ๅࠥ࠭෉")+uAEC7e8dgoDw14+OOkmZiVcfqlEurM1dHGb(u"ࠩࠣว๊ࠦสา์าࠤู๊อࠡษ็้้็ࠠภ්ࠩ"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869==rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠰ი"):
		if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(file):
			try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(file)
			except: pass
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭෋"),eGW7cI6aQhr0(u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩ෌")+uAEC7e8dgoDw14)
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==xY4icgQUj6mPVs73CTKu(u"࠲კ"):
		data = kNavZsXiUlWP5o4(file)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ෍"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠭สๆࠢศู้ออࠡ็็ๅࠥ࠭෎")+uAEC7e8dgoDw14)
	return
def WAF7mMUpoN5Okjlzdcef2QxG():
	if kQI947MebLovYyVE08F5qPi6fj3<lrtFSogC8Nh9(u"࠳࠻ლ"):
		JzNoqV8ClRD6O = Hlp3z0APt1GR4kMYK5xST(u"ࠧๅๆฦืๆࠦร็ฬࠣฮุะฮะ็ࠣษฺีวาࠢๆ์ิ๐ࠠใัํ้ࠥืโๆࠢࠪා")+str(kQI947MebLovYyVE08F5qPi6fj3)+kb2icmDGVUZfW1OFz7sv(u"ࠨ๋่ࠢ์ึวࠡษ็ๆํอฦๆࠢส่๊฻่าห่ࠣฬࠦสฺ็็ࠤ฾์ฯไࠢ࠱ࠤ์ึ็ࠡษ็้๏ุษࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠศๆไ๎ิ๐่่ษอࠤๆ๐ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠢ࠱ࠤ้หีๅษะࠤฬ๊ๅีๅ็อ่ࠥๅࠡสอัิ๐หࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦลๅ๋ࠣษ๏ࠦลึัสีࠥืโๆ้ࠣว฾๊้ࠡ็้ࠤ࠶࠾࠮࠱ࠩැ")
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬෑ"),JzNoqV8ClRD6O)
		return
	F5cKwEogkz64f0 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(lNTJCZeBicWEz0Mg(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ි"))
	YYrKb4X8nZvo93BqaeJDt17 = E59vQkcMrwq0sBoeDUYClgG2St1([Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪී")])
	ll83YbWxpZUkyBCnqeAv,yBUWwqi7c3NVZM1mprgkanH8RxQzf,LLeI68SWjDsUXxNFA,KKPn0EtNkA5ZyHFW1GVrQlDY,WLBJFGVI71wjbEd328NQOlcAYx,QusPVla1k0H7Zd,wH5YQDlzxudEvWbOK73s1gckotM = YYrKb4X8nZvo93BqaeJDt17[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫු")]
	if ll83YbWxpZUkyBCnqeAv or lRP6GTaZJA1Xw3egLM4(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ෕") not in str(F5cKwEogkz64f0):
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪූ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭෗"))
		PsKJk8XRHAQM = TAayl1jpmQFwCienqZcV8hJ2t()
		if not PsKJk8XRHAQM: return
	dwOKloTVHgZY8vJFrQazpD0BU6Stb(k6apiPAlLKM1ed8J42RjHh0o)
	return
def dwOKloTVHgZY8vJFrQazpD0BU6Stb(showDialogs=k6apiPAlLKM1ed8J42RjHh0o):
	F5cKwEogkz64f0 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(hCm2fnEXs6Zt(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬෘ"))
	if HVmIrFwau90jQsgiWzExk(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩෙ") not in str(F5cKwEogkz64f0):
		if showDialogs:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧේ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪෛ"))
		return
	xaOUZ7vLTVzWFN8pnmJPIjgC = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ො"),HVmIrFwau90jQsgiWzExk(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ෝ"),rNyT0edugn(u"ࠨ࠹࠵࠴ࡵ࠭ෞ"),R3lezw8h407ZvrAFxT(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪෟ"))
	if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(xaOUZ7vLTVzWFN8pnmJPIjgC): return
	HHVF24kQUwi3XSegWCu7x9 = open(xaOUZ7vLTVzWFN8pnmJPIjgC,fOc18oTm5hsdD4pVZQj(u"ࠪࡶࡧ࠭෠")).read()
	if J92gCnbGWidQV70lBteTwU6D8uyzL: HHVF24kQUwi3XSegWCu7x9 = HHVF24kQUwi3XSegWCu7x9.decode(YRvPKe2zMTDs8UCkr)
	UuqW5SIvg6Jr = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ෡"),HHVF24kQUwi3XSegWCu7x9,YYqECUofyi7wFrW.DOTALL)
	xygFiwpJXUWz,KWasVcnoAOyRw2fbHMvF9Slz = UuqW5SIvg6Jr[e8XhbyuzvjYkIsJUtB5w]
	gRyQ9e7ckX0uNGmCV = NeU6uRGpECkvMV5jf(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭෢")+xygFiwpJXUWz+pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࠬࠨ෣")+KWasVcnoAOyRw2fbHMvF9Slz+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ෤")
	if showDialogs:
		LyH1jFYqKosumMDd3AvNicn846QlP = ACOWB6GRmIbDKyl3Zn.getInfoLabel(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭෥"))
		if LyH1jFYqKosumMDd3AvNicn846QlP==hCm2fnEXs6Zt(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ෦"): hZVOfz9TwS = lRP6GTaZJA1Xw3egLM4(u"ࠪๆํอฦๆࠢส่่ะวษหࠪ෧")
		elif LyH1jFYqKosumMDd3AvNicn846QlP==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ෨"): hZVOfz9TwS = PzIpQnUXxRwNCivDhdakWTE(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ෩")
		else: hZVOfz9TwS = NOrchaEV1iIZ87Uzlwgum(u"࠭โ้ษษ้ࠥษฮา๋ࠪ෪")
		us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(R3lezw8h407ZvrAFxT(u"ࠧࡤࡧࡱࡸࡪࡸࠧ෫"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨไ๋หห๋ࠠฤะิํࠬ෬"),lRP6GTaZJA1Xw3egLM4(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ෭"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ෮"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ෯")+hZVOfz9TwS,xY4icgQUj6mPVs73CTKu(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨ෰")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪ෱")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if us7rL1qZAJURmQjPTtIhGN0daXf869==kb2icmDGVUZfW1OFz7sv(u"࠴მ"): EN9XFJ2Oem = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪෲ")
		elif us7rL1qZAJURmQjPTtIhGN0daXf869==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠶ნ"): EN9XFJ2Oem = QQHFtjcaR2VpnSyTIv(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧෳ")
		else: EN9XFJ2Oem = NdKhAS6MXVEORLTwob92pxlZ
	else:
		LyH1jFYqKosumMDd3AvNicn846QlP = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(lRP6GTaZJA1Xw3egLM4(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ෴"))
		if   LyH1jFYqKosumMDd3AvNicn846QlP==NdKhAS6MXVEORLTwob92pxlZ: us7rL1qZAJURmQjPTtIhGN0daXf869 = xY4icgQUj6mPVs73CTKu(u"࠵ო")
		elif LyH1jFYqKosumMDd3AvNicn846QlP==IlL8ZnX74Yvep(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭෵"): us7rL1qZAJURmQjPTtIhGN0daXf869 = NOrchaEV1iIZ87Uzlwgum(u"࠷პ")
		elif LyH1jFYqKosumMDd3AvNicn846QlP==NeU6uRGpECkvMV5jf(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ෶"): us7rL1qZAJURmQjPTtIhGN0daXf869 = wP4kpvXoDHq3hs7TFLyr2COn8(u"࠲ჟ")
		EN9XFJ2Oem = LyH1jFYqKosumMDd3AvNicn846QlP
	if   us7rL1qZAJURmQjPTtIhGN0daXf869==fOc18oTm5hsdD4pVZQj(u"࠱რ"): spK26LczW7IvJEe4wh8H = R3lezw8h407ZvrAFxT(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩ෷")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==LtGoXlQ2IYxqTJRySE6udfW98(u"࠳ს"): spK26LczW7IvJEe4wh8H = fOc18oTm5hsdD4pVZQj(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪ෸")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵ტ"): spK26LczW7IvJEe4wh8H = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫ෹")
	else: return
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NeU6uRGpECkvMV5jf(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭෺"),EN9XFJ2Oem)
	XjHKTnm6NuJa35WtboPBwcEiqQ = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ෻")+spK26LczW7IvJEe4wh8H+fOc18oTm5hsdD4pVZQj(u"ࠪ࠰ࠬ෼")+KWasVcnoAOyRw2fbHMvF9Slz+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭෽")
	bQrogdaYD9T7jeNuXGML = HHVF24kQUwi3XSegWCu7x9.replace(gRyQ9e7ckX0uNGmCV,XjHKTnm6NuJa35WtboPBwcEiqQ)
	if J92gCnbGWidQV70lBteTwU6D8uyzL: bQrogdaYD9T7jeNuXGML = bQrogdaYD9T7jeNuXGML.encode(YRvPKe2zMTDs8UCkr)
	open(xaOUZ7vLTVzWFN8pnmJPIjgC,rNyT0edugn(u"ࠬࡽࡢࠨ෾")).write(bQrogdaYD9T7jeNuXGML)
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,eGW7cI6aQhr0(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ෿")+spK26LczW7IvJEe4wh8H+OOkmZiVcfqlEurM1dHGb(u"ࠧࠡ࡟ࠪ฀"))
	if showDialogs: ACOWB6GRmIbDKyl3Zn.executebuiltin(NOrchaEV1iIZ87Uzlwgum(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧก"))
	return
def dm1rJV8XK60NynfsIRH7UztqQMT4e():
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬข"),lrtFSogC8Nh9(u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨฃ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==kb2icmDGVUZfW1OFz7sv(u"࠵უ"): PaA9seqk5wpFI1lDKtonb8h2()
	return
def nRljB9zWcSh():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧค"),IlL8ZnX74Yvep(u"ࠬํะศࠢส่๊๎โฺ่ࠢ฾้่ࠠๆ่ࠣห้๋ีะำࠣ์฿๐ัࠡ็฼ีํ็ࠠๆฬํࠤ๏ืฬฺࠢ็่฾๋ไࠨฅ"))
	return
def yHXsFlfdoE9GCkPM5I0baA():
	ZLI75sAmWojzUYJtluw8h6H4reCf = D7INg5kyRjwf4ZtoePVUrb1h2SJ+JGwsL21ZRlqSrWxEmF(u"࠭สฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢࠪฆ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	ZLI75sAmWojzUYJtluw8h6H4reCf += lRP6GTaZJA1Xw3egLM4(u"ࠧศๆ่์็฿ࠠฤั้ห์ࠦแ๋้ࠣษา฻วว์ฬࠤ้฿ฯะࠢสู่๐ูสࠢไ๎ࠥอไฺษ็้ࠥะๅࠡฮ่฽์อࠠๆ่ࠣะ๊๐ูࠡษ็ฺ้อฯาࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่็ี๊ๆหࠣ์ฬ๊ฬะ์าอࠥอไฮๅ๋้๏ฯ้ࠠษ็฾๏ืࠠฮๅ๋้๏ฯ้ࠠ็้ࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊ࠦหๆࠢอ้ࠥะ่ฮ์า๋ฬ่ࠦฮีสฬࠥอไๆ฻า่ࠥำำษࠢึ็ฬ์ࠠะ๊็ࠤฬู๊ศๆ่ࠤู้ๆสࠢ࠵࠴࠷࠷้้ࠠํࠤฬ๊ลฮืสส๏ฯࠠศๆฦัิั้ࠠษ็วู๋ไࠡษ็ฮ๏ࠦสๆࠢ฼้้ํวࠡใํࠤฬ๊ำ็๊สฮࠥอไฺึิอࠥอไๆษู๎ฮ࠭ง")
	ZLI75sAmWojzUYJtluw8h6H4reCf += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+lRP6GTaZJA1Xw3egLM4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡷ࡭࡯ࡡࡤࡱࡸࡲࡹ࠭จ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	XXnFpTZ9ksicAKzg1lMCP5Dtq = D7INg5kyRjwf4ZtoePVUrb1h2SJ+QQHFtjcaR2VpnSyTIv(u"ࠩหี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢࠪฉ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	XXnFpTZ9ksicAKzg1lMCP5Dtq += NOrchaEV1iIZ87Uzlwgum(u"๋ࠪํูࠦษษิอࠥ฿ๆࠡสิ๊ฬ๋ฬࠡ์๋ๅึࠦๅฺๆ๋้ฬะࠠฮีสฬ๏ฯࠠไอํีฮࠦส่็ࠣะ๊๐ูࠡษ็ุ้๊ๅ๋่้ࠣะ๊ࠠฤ๊ๅหฯࠦวๅื็หฮ่ࠦฤ๊ๅหฯࠦวๅๅึ์ๆ่ࠦศๆัืํ็้ࠠึๆ่ࠥอไใ็ิࠤํษ่ใษอࠤฬ๊โๆำࠣ์ศ๐ึศࠢํ์ๆืࠠาฦํอࠥอไ่ๆส่ࠥ็๊ࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣ์ศ๐ึศࠢไ๎์ࠦสใ๊ํ้๋๊ࠥๅษา๎ࠥ๎็อำํࠤํ็๊่ࠢฦ๎฻อࠠษฯฮࠤํ่ัศรฬࠤฬ๊โาฤ้ࠤํษ๊ืษࠣๅ๏ํࠠศีอาฬืษ๊ࠡอๅฬสไ๊ࠡไ๎์ࠦรใ๊ส่๋ࠥๆิ๊หอ๊ࠥไฤ็ส้ࠥ฿ไ๋๋ࠢว๊๎ัࠡลัี๎ࠦส่็ࠣ็้ࠦๅิๆ่ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ็ๆฮํฮࠠษๆ฽อࠥาวโษࠣื่ืศห๋ࠢ๎ุะฮะ็๊ࠣ฽อๅ๊ࠡํ๊ิ๎าࠡฬะฮࠥฮ๊วหࠣ์๏์ฯ้ิࠣ็ฬา๊ห๋้ࠢำ฻ีࠡใๅ฻๊ࠥรอ้ีอࠥอไ้์้ำํุࠠ࠯ࠢส่๊๎โฺࠢส่ึูๅ๋ࠢ็่อืๆศ็ฯࠤ์๎ࠧช")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+gniNItGL6bKwpEW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡭ࡶࡵ࡯࡭ࡲࡸࡵ࡭ࡧࡵࠫซ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	JzNoqV8ClRD6O = PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡡࡒࡕࡎࡠࠫฌ")+ZLI75sAmWojzUYJtluw8h6H4reCf+NOrchaEV1iIZ87Uzlwgum(u"࠭࡜࡯࡞ࡱࡠࡳࡡࡒࡕࡎࡠࠫญ")+XXnFpTZ9ksicAKzg1lMCP5Dtq
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(eGW7cI6aQhr0(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ฎ"),NdKhAS6MXVEORLTwob92pxlZ,JzNoqV8ClRD6O)
	return
def V57ovgQhPbWzRZO6jxU0(pma7xfu1g43KVTMFQ):
	kyCTNqxg9hBKocfXW(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE)
	oo8Tv5VBQAZbptxl = igNr4jWHh8eIS0bM(pma7xfu1g43KVTMFQ)
	for CaSFdiZ0mT in [rNyT0edugn(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪฏ"),NOrchaEV1iIZ87Uzlwgum(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬฐ"),rNyT0edugn(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨฑ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࡟ࡕࡕࠪฒ")]:
		if CaSFdiZ0mT in sevfFTR5mNndl: sevfFTR5mNndl.remove(CaSFdiZ0mT)
	c2JF3xijoWuSgAVvLaRz(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡊࡏࡏࡃࡗࡍࡔࡔࡓࠨณ"))
	id,gMXJ1uE2flZASBm6jYhspTnIe,dhfVevor7I2tWBm,VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2,reason = oo8Tv5VBQAZbptxl[e8XhbyuzvjYkIsJUtB5w]
	Bj9EMHUr2wftyvR,JFTMsjhRbzieXp2x = VXdz0nyjQHPLeE.split(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭࡜࡯࠽࠾ࠫด"))
	XXnFpTZ9ksicAKzg1lMCP5Dtq,mbzrpYR0ZBMvjxJ2eDS,MWX39d1VjgqPaftLAwUD8orJc = jjpbVgW3hUw7XMyFI50N9ismLlGv2.split(NeU6uRGpECkvMV5jf(u"ࠧ࡝ࡰ࠾࠿ࠬต"))
	cXioWwJz8ku01 = k6apiPAlLKM1ed8J42RjHh0o
	while cXioWwJz8ku01:
		abG815wk0LYijMS6JWz2q = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨะิ์ั࠭ถ"),IlL8ZnX74Yvep(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨท"),lNTJCZeBicWEz0Mg(u"ࠪๆฬฬๅสࠢส่ฯฮัฺษอࠫธ"),Hlp3z0APt1GR4kMYK5xST(u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠ࠻ࠢࠣฮอืูࠡล๋ࠤฬ๋ำฮࠢส่อืๆศ็ฯࠫน"),XXnFpTZ9ksicAKzg1lMCP5Dtq)
		if abG815wk0LYijMS6JWz2q==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠷ფ"): wFea2SrVkb4KCo0YjduLmBPf9sl = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠬ฿่ะหࠪบ"),NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭ป"),mbzrpYR0ZBMvjxJ2eDS,IlL8ZnX74Yvep(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫผ"))
		elif abG815wk0LYijMS6JWz2q==IlL8ZnX74Yvep(u"࠷ქ"): AWxD1rw2o6EeF()
		else: cXioWwJz8ku01 = f4vncKMRlXG9s
	if pma7xfu1g43KVTMFQ: MIjcStaDWnv(f4vncKMRlXG9s)
	return
def tQgd8Fu5lKb(showDialogs):
	TT32BcvomhVewpgMSWkEb46y7xqO = k6apiPAlLKM1ed8J42RjHh0o
	if showDialogs: TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨฝ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠩึศฬ๊ࠧพ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"๋้ࠪࠦร็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡ็ึัࠥ๎สึใํีࠥาๅ๋฻ࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢะ๎ะࠦสฺ๊าࠤัฺ๋๊ࠢส่ส฿ฯศัสฮࠥหไฺ๊๋ࠢ฾๐ษࠡฬฮฬ๏ะࠠศๆหี๋อๅอࠢยࠫฟ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO:
		PsKJk8XRHAQM = k6apiPAlLKM1ed8J42RjHh0o
		if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(vPnhV2qXEHQ9bpJl56gfc0wImNRyx):
			try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(vPnhV2qXEHQ9bpJl56gfc0wImNRyx)
			except: PsKJk8XRHAQM = f4vncKMRlXG9s
		if showDialogs:
			if PsKJk8XRHAQM: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫภ"))
			else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬม"))
	return
def k95kFoB8VTuAHYlp():
	sBJb1NZASzY()
	NzIh2PO4pbW1TKZ87 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(Hlp3z0APt1GR4kMYK5xST(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬย"))
	JzNoqV8ClRD6O = {}
	JzNoqV8ClRD6O[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡂࡗࡗࡓࠬร")] = JGwsL21ZRlqSrWxEmF(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧฤ")
	JzNoqV8ClRD6O[HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡖࡘࡔࡖࠧล")] = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩฦ")
	JzNoqV8ClRD6O[eGW7cI6aQhr0(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬว")] = lrtFSogC8Nh9(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ศ")+str(iiNnbh6pks9GFul0UJvaAMjq8DLCO/YJpWv4QzC7sx8INVPukeZiOD03K(u"࠶࠱ღ"))+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࠠะไํๆฮࠦแใูࠪษ")
	tls8FvkLjp = JzNoqV8ClRD6O[NzIh2PO4pbW1TKZ87]
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠧไษืࠤࠬส")+str(iiNnbh6pks9GFul0UJvaAMjq8DLCO/pnHgvFOCBZzc08yULQJGIqw9bf(u"࠷࠲ყ"))+NeU6uRGpECkvMV5jf(u"ࠨࠢาๆ๏่ษࠨห"),HVmIrFwau90jQsgiWzExk(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨฬ"),xY4icgQUj6mPVs73CTKu(u"ࠪษ๏่วโࠢๆห๊๊ࠧอ"),tls8FvkLjp,kb2icmDGVUZfW1OFz7sv(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧฮ"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869==YJpWv4QzC7sx8INVPukeZiOD03K(u"࠲შ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ฯ")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==NOrchaEV1iIZ87Uzlwgum(u"࠴ჩ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡁࡖࡖࡒࠫะ")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==xY4icgQUj6mPVs73CTKu(u"࠶ც"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = rNyT0edugn(u"ࠧࡔࡖࡒࡔࠬั")
	else: kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = NdKhAS6MXVEORLTwob92pxlZ
	if kUa7sLhxe6wWEPgiOv9ZcIoR4Dl:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(IlL8ZnX74Yvep(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧา"),kUa7sLhxe6wWEPgiOv9ZcIoR4Dl)
		ptmuIrL0KlkHxa2v = JzNoqV8ClRD6O[kUa7sLhxe6wWEPgiOv9ZcIoR4Dl]
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ptmuIrL0KlkHxa2v)
	return
def hhq6teVbDwp9B5oniyuPvjQEGKJ():
	JzNoqV8ClRD6O = {}
	JzNoqV8ClRD6O[R3lezw8h407ZvrAFxT(u"ࠩࡄ࡙࡙ࡕࠧำ")] = xY4icgQUj6mPVs73CTKu(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨิ")
	JzNoqV8ClRD6O[V0VZk9763fusTReHFo4(u"ࠫࡆ࡙ࡋࠨี")] = V0VZk9763fusTReHFo4(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩึ")
	JzNoqV8ClRD6O[V0VZk9763fusTReHFo4(u"࠭ࡓࡕࡑࡓࠫื")] = Tzx81Wb0RZC4ID5AyiU2(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆุࠪ")
	Eaic19WC63XMvsmo5FOePbhr = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(QQHFtjcaR2VpnSyTIv(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨู"))
	NzIh2PO4pbW1TKZ87 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(xY4icgQUj6mPVs73CTKu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷฺࠬ"))
	tls8FvkLjp = JzNoqV8ClRD6O[NzIh2PO4pbW1TKZ87]+Eaic19WC63XMvsmo5FOePbhr
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ฻"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ฼"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬห๊ใษไࠤ่อๅๅࠩ฽"),tls8FvkLjp,Tzx81Wb0RZC4ID5AyiU2(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ฾"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869==lRP6GTaZJA1Xw3egLM4(u"࠵ძ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = lrtFSogC8Nh9(u"ࠧࡂࡕࡎࠫ฿")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==V0VZk9763fusTReHFo4(u"࠷წ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = QQHFtjcaR2VpnSyTIv(u"ࠨࡃࡘࡘࡔ࠭เ")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==lrtFSogC8Nh9(u"࠲ჭ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = lRP6GTaZJA1Xw3egLM4(u"ࠩࡖࡘࡔࡖࠧแ")
	if us7rL1qZAJURmQjPTtIhGN0daXf869 in [R3lezw8h407ZvrAFxT(u"࠲ჯ"),V0VZk9763fusTReHFo4(u"࠲ხ")]:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡧࡪࡴࡴࡦࡴࠪโ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ุࠫ๐ัโำ࠽ࠤࠬใ")+OOc1n5zLYbujBI[llxMLe4gobHhsj1WGvd7qmIU],Hlp3z0APt1GR4kMYK5xST(u"ู๊ࠬาใิ࠾ࠥ࠭ไ")+OOc1n5zLYbujBI[e8XhbyuzvjYkIsJUtB5w],NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬๅ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO==JGwsL21ZRlqSrWxEmF(u"࠴ჰ"): W9g3i4X1RSway = OOc1n5zLYbujBI[e8XhbyuzvjYkIsJUtB5w]
		else: W9g3i4X1RSway = OOc1n5zLYbujBI[llxMLe4gobHhsj1WGvd7qmIU]
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==xY4icgQUj6mPVs73CTKu(u"࠶ჱ"): W9g3i4X1RSway = NdKhAS6MXVEORLTwob92pxlZ
	else: kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = NdKhAS6MXVEORLTwob92pxlZ
	if kUa7sLhxe6wWEPgiOv9ZcIoR4Dl:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(R3lezw8h407ZvrAFxT(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪๆ"),kUa7sLhxe6wWEPgiOv9ZcIoR4Dl)
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ็"),W9g3i4X1RSway)
		ptmuIrL0KlkHxa2v = JzNoqV8ClRD6O[kUa7sLhxe6wWEPgiOv9ZcIoR4Dl]+W9g3i4X1RSway
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ptmuIrL0KlkHxa2v)
	return
def mNFrKu8AlMow7O1YgQZEkBxzn():
	NzIh2PO4pbW1TKZ87 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(QQHFtjcaR2VpnSyTIv(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿ่ࠧ"))
	JzNoqV8ClRD6O = {}
	JzNoqV8ClRD6O[fOc18oTm5hsdD4pVZQj(u"ࠪࡅ࡚࡚ࡏࠨ้")] = IlL8ZnX74Yvep(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่๊ࠬ")
	JzNoqV8ClRD6O[V0VZk9763fusTReHFo4(u"ࠬࡇࡓࡌ๋ࠩ")] = xY4icgQUj6mPVs73CTKu(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧ์")
	JzNoqV8ClRD6O[lNTJCZeBicWEz0Mg(u"ࠧࡔࡖࡒࡔࠬํ")] = lNTJCZeBicWEz0Mg(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ๎")
	tls8FvkLjp = JzNoqV8ClRD6O[NzIh2PO4pbW1TKZ87]
	us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ๏"),lNTJCZeBicWEz0Mg(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ๐"),V0VZk9763fusTReHFo4(u"ࠫส๐โศใࠣ็ฬ๋ไࠨ๑"),tls8FvkLjp,fOc18oTm5hsdD4pVZQj(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨ๒"))
	if us7rL1qZAJURmQjPTtIhGN0daXf869==YJpWv4QzC7sx8INVPukeZiOD03K(u"࠵ჲ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡁࡔࡍࠪ๓")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==lRP6GTaZJA1Xw3egLM4(u"࠷ჳ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡂࡗࡗࡓࠬ๔")
	elif us7rL1qZAJURmQjPTtIhGN0daXf869==NeU6uRGpECkvMV5jf(u"࠲ჴ"): kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = fOc18oTm5hsdD4pVZQj(u"ࠨࡕࡗࡓࡕ࠭๕")
	else: kUa7sLhxe6wWEPgiOv9ZcIoR4Dl = NdKhAS6MXVEORLTwob92pxlZ
	if kUa7sLhxe6wWEPgiOv9ZcIoR4Dl:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ๖"),kUa7sLhxe6wWEPgiOv9ZcIoR4Dl)
		ptmuIrL0KlkHxa2v = JzNoqV8ClRD6O[kUa7sLhxe6wWEPgiOv9ZcIoR4Dl]
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ptmuIrL0KlkHxa2v)
	return
def r5cSE6D89t2R1WbxidOGofa():
	urvcNGnLMSXRd = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ๗"))
	if urvcNGnLMSXRd==OOkmZiVcfqlEurM1dHGb(u"ࠫࡘ࡚ࡏࡑࠩ๘"): header = rNyT0edugn(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ๙")
	else: header = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ๚")
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠧฦ์ๅหๆ࠭๛"),fOc18oTm5hsdD4pVZQj(u"ࠨฬไ฽๏๊ࠧ๜"),header,fOc18oTm5hsdD4pVZQj(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭๝"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==-YJpWv4QzC7sx8INVPukeZiOD03K(u"࠲ჵ"): return
	elif TT32BcvomhVewpgMSWkEb46y7xqO:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ๞"),V0VZk9763fusTReHFo4(u"ࠫࡆ࡛ࡔࡐࠩ๟"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๠"),PzIpQnUXxRwNCivDhdakWTE(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ๡"))
	else:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ๢"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡕࡗࡓࡕ࠭๣"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ๤"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪฮ๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬ๥"))
	return
def zu3pLr0gqTPDd(ui7N5YGR9KdslpEbQkVTwFqDgI):
	if ui7N5YGR9KdslpEbQkVTwFqDgI!=NdKhAS6MXVEORLTwob92pxlZ:
		ui7N5YGR9KdslpEbQkVTwFqDgI = kdNDPcUObAMs9Kz(ui7N5YGR9KdslpEbQkVTwFqDgI)
		ui7N5YGR9KdslpEbQkVTwFqDgI = ui7N5YGR9KdslpEbQkVTwFqDgI.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
		I1bOcNok6WCfmK0U7 = NOrchaEV1iIZ87Uzlwgum(u"࠳࠳࠵࠵࠹ჶ")
		uuVmFR6ObHinQ4kqjS0 = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Window(I1bOcNok6WCfmK0U7)
		uuVmFR6ObHinQ4kqjS0.getControl(vju3SZDWL4ENYelmBOzUqrogp2(u"࠶࠵࠶ჷ")).setLabel(ui7N5YGR9KdslpEbQkVTwFqDgI)
	return
XC85lhftPj = [
			 JGwsL21ZRlqSrWxEmF(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤ๦")
			,OOkmZiVcfqlEurM1dHGb(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨ๧")
			,eGW7cI6aQhr0(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨ๨")
			,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩ๩")
			,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩ๪")
			,HVmIrFwau90jQsgiWzExk(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫ๫")
			,xY4icgQUj6mPVs73CTKu(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩ๬")+QQHFtjcaR2VpnSyTIv(u"ࠫࠨ࠭๭")+QQHFtjcaR2VpnSyTIv(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫ๮")
			,ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ๯")
			,R3lezw8h407ZvrAFxT(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪ๰")
			,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ๱")
			,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡡࡢࡣࡤ࡞ࠨ๲")
			,OOkmZiVcfqlEurM1dHGb(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ๳")
			]
def XiudasZV1rYAbLw5tD(iJbFcE2OQWRykXNMUlfrCv918SqpD):
	if hCm2fnEXs6Zt(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ๴") in iJbFcE2OQWRykXNMUlfrCv918SqpD and OOkmZiVcfqlEurM1dHGb(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ๵") in iJbFcE2OQWRykXNMUlfrCv918SqpD: return k6apiPAlLKM1ed8J42RjHh0o
	for ui7N5YGR9KdslpEbQkVTwFqDgI in XC85lhftPj:
		if ui7N5YGR9KdslpEbQkVTwFqDgI in iJbFcE2OQWRykXNMUlfrCv918SqpD: return k6apiPAlLKM1ed8J42RjHh0o
	return f4vncKMRlXG9s
def ULJNHjGxD0YS3AXblRE4Pq8gp2QCFZ(data):
	WpSgV2lbMQxzne0qGIY = LtGoXlQ2IYxqTJRySE6udfW98(u"࠼ჹ") if J92gCnbGWidQV70lBteTwU6D8uyzL else OOkmZiVcfqlEurM1dHGb(u"࠵࠺ჸ")
	data = data.replace(eGW7cI6aQhr0(u"࠹࠰ჺ")*Vwgflszp4WRA93kx6hvdua21HX5cOb,WpSgV2lbMQxzne0qGIY*Vwgflszp4WRA93kx6hvdua21HX5cOb)
	data = data.replace(OOkmZiVcfqlEurM1dHGb(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬ๶"),lRP6GTaZJA1Xw3egLM4(u"ࠧ࠻ࠢࠪ๷"))
	OzUD8iTmGp15Sn9VINMHq = NdKhAS6MXVEORLTwob92pxlZ
	for iJbFcE2OQWRykXNMUlfrCv918SqpD in data.splitlines():
		UdHQNzo61bGwasLJZIA = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ๸"),iJbFcE2OQWRykXNMUlfrCv918SqpD,YYqECUofyi7wFrW.DOTALL)
		if UdHQNzo61bGwasLJZIA: iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(UdHQNzo61bGwasLJZIA[e8XhbyuzvjYkIsJUtB5w],NdKhAS6MXVEORLTwob92pxlZ)
		OzUD8iTmGp15Sn9VINMHq += B6IrC7zEHlw1oaeWf+iJbFcE2OQWRykXNMUlfrCv918SqpD
	return OzUD8iTmGp15Sn9VINMHq
def NKylfkLxoedgn(AasBodlDFyvxXEnIhZ9gGz4w23):
	if gniNItGL6bKwpEW(u"ࠩࡒࡐࡉ࠭๹") in AasBodlDFyvxXEnIhZ9gGz4w23:
		Zfixn0L7vaVlQ53 = tHLwPKXACG5B2deoiup
		header = gniNItGL6bKwpEW(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪ๺")
	else:
		Zfixn0L7vaVlQ53 = ASInatQNLOxmbF
		header = OOkmZiVcfqlEurM1dHGb(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫ๻")
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,header,rNyT0edugn(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ๼"))
	if TT32BcvomhVewpgMSWkEb46y7xqO!=NeU6uRGpECkvMV5jf(u"࠱჻"): return
	E7rIbVtD3GSKTxfON,SyTm6WjEM0P1ApXuNlixtwOqRkLQ = [],Hlp3z0APt1GR4kMYK5xST(u"࠱ჼ")
	size,count = TGNwJtqvjZCnUhHKEXoep8xBbk(Zfixn0L7vaVlQ53)
	file = open(Zfixn0L7vaVlQ53,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡲࡣࠩ๽"))
	if size>vju3SZDWL4ENYelmBOzUqrogp2(u"࠴࠴࠵࠸࠰࠱ჾ"): file.seek(-Tzx81Wb0RZC4ID5AyiU2(u"࠳࠳࠴࠶࠶࠰ჽ"),IIPNcsCvQnOZk0yejJKl4BtgSrMw.SEEK_END)
	data = file.read()
	file.close()
	if J92gCnbGWidQV70lBteTwU6D8uyzL: data = data.decode(YRvPKe2zMTDs8UCkr)
	data = ULJNHjGxD0YS3AXblRE4Pq8gp2QCFZ(data)
	aLZSGBw7NhXtCuDWgJR = data.split(B6IrC7zEHlw1oaeWf)
	for iJbFcE2OQWRykXNMUlfrCv918SqpD in reversed(aLZSGBw7NhXtCuDWgJR):
		kXS3g75vnt = XiudasZV1rYAbLw5tD(iJbFcE2OQWRykXNMUlfrCv918SqpD)
		if kXS3g75vnt: continue
		iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(QQHFtjcaR2VpnSyTIv(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩ๾"),D7INg5kyRjwf4ZtoePVUrb1h2SJ+HVmIrFwau90jQsgiWzExk(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ๿")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ຀"),QQHFtjcaR2VpnSyTIv(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ກ")+lRP6GTaZJA1Xw3egLM4(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫຂ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		dzpfPkwEU4l2x = NdKhAS6MXVEORLTwob92pxlZ
		cjZnrbaYq7tOC3L50h = YYqECUofyi7wFrW.findall(fOc18oTm5hsdD4pVZQj(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ຃"),iJbFcE2OQWRykXNMUlfrCv918SqpD,YYqECUofyi7wFrW.DOTALL)
		if cjZnrbaYq7tOC3L50h:
			iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w],cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]).replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][cCRvAuJQfjBpTg0PbYiaNO87],NdKhAS6MXVEORLTwob92pxlZ)
			dzpfPkwEU4l2x = cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]
		else:
			cjZnrbaYq7tOC3L50h = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ຄ"),iJbFcE2OQWRykXNMUlfrCv918SqpD,YYqECUofyi7wFrW.DOTALL)
			if cjZnrbaYq7tOC3L50h:
				iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU],NdKhAS6MXVEORLTwob92pxlZ)
				dzpfPkwEU4l2x = cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w]
		if dzpfPkwEU4l2x: iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(dzpfPkwEU4l2x,Whef0cxB2iR93SC5IwUtk+dzpfPkwEU4l2x+kjd9LyNqQHMUevZiRI7OlBGF1h)
		E7rIbVtD3GSKTxfON.append(iJbFcE2OQWRykXNMUlfrCv918SqpD)
		if len(str(E7rIbVtD3GSKTxfON))>NeU6uRGpECkvMV5jf(u"࠹࠵࠷࠰࠱ჿ"): break
	E7rIbVtD3GSKTxfON = reversed(E7rIbVtD3GSKTxfON)
	euVlSpIGib2TqQULCaXR9xhgZ = B6IrC7zEHlw1oaeWf.join(E7rIbVtD3GSKTxfON)
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧ࡭ࡧࡩࡸࠬ຅"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬຆ"),euVlSpIGib2TqQULCaXR9xhgZ,IlL8ZnX74Yvep(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬງ"))
	return
def yRPY5kWzacJK2GX():
	buLSvKq5JUWcZfzVEI64AwaH9 = open(U0UT1PijZEFheu6zWg92CrpHsmA,NeU6uRGpECkvMV5jf(u"ࠪࡶࡧ࠭ຈ")).read()
	if J92gCnbGWidQV70lBteTwU6D8uyzL: buLSvKq5JUWcZfzVEI64AwaH9 = buLSvKq5JUWcZfzVEI64AwaH9.decode(YRvPKe2zMTDs8UCkr)
	buLSvKq5JUWcZfzVEI64AwaH9 = buLSvKq5JUWcZfzVEI64AwaH9.replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡡࡺࠧຉ"),gniNItGL6bKwpEW(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧຊ"))
	YYrKb4X8nZvo93BqaeJDt17 = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ຋"),buLSvKq5JUWcZfzVEI64AwaH9,YYqECUofyi7wFrW.DOTALL)
	for iJbFcE2OQWRykXNMUlfrCv918SqpD in YYrKb4X8nZvo93BqaeJDt17:
		buLSvKq5JUWcZfzVEI64AwaH9 = buLSvKq5JUWcZfzVEI64AwaH9.replace(iJbFcE2OQWRykXNMUlfrCv918SqpD,D7INg5kyRjwf4ZtoePVUrb1h2SJ+iJbFcE2OQWRykXNMUlfrCv918SqpD+kjd9LyNqQHMUevZiRI7OlBGF1h)
	AGLwyhimZ4uT5qjd0K(IlL8ZnX74Yvep(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨຌ"),buLSvKq5JUWcZfzVEI64AwaH9)
	return
def l8EOZCSWVNJL97HieFrkwxyU():
	ZLI75sAmWojzUYJtluw8h6H4reCf = Tzx81Wb0RZC4ID5AyiU2(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪຍ")
	XXnFpTZ9ksicAKzg1lMCP5Dtq = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ຎ")
	mbzrpYR0ZBMvjxJ2eDS = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ຏ")
	JzNoqV8ClRD6O = ZLI75sAmWojzUYJtluw8h6H4reCf+JGwsL21ZRlqSrWxEmF(u"ࠫ࠿ࠦࠧຐ")+XXnFpTZ9ksicAKzg1lMCP5Dtq+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࠦ࠮ࠡࠩຑ")+mbzrpYR0ZBMvjxJ2eDS
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ຒ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪຓ"),JzNoqV8ClRD6O,lNTJCZeBicWEz0Mg(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫດ"))
	return
def TM3EgsyYRtVxA9i(type,JzNoqV8ClRD6O,showDialogs=k6apiPAlLKM1ed8J42RjHh0o,url=NdKhAS6MXVEORLTwob92pxlZ,xmezOWMyhSXRGHlEk2JnsI=NdKhAS6MXVEORLTwob92pxlZ,ui7N5YGR9KdslpEbQkVTwFqDgI=NdKhAS6MXVEORLTwob92pxlZ,yrPG7D3t9Wsg0I1CE8m4UuM=NdKhAS6MXVEORLTwob92pxlZ):
	KxuNPa1XHctJeDZbAvqMSkE = k6apiPAlLKM1ed8J42RjHh0o
	if not OMNiY8joQx.HHqA8u41iPZ:
		if showDialogs:
			yeBTHqdCEAs94MF3wk2xU0Ga = (ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩสุ่฽ั࠻ࠩຕ") in JzNoqV8ClRD6O and eGW7cI6aQhr0(u"ࠪห้๋ใศ่࠽ࠫຖ") in JzNoqV8ClRD6O and gniNItGL6bKwpEW(u"ࠫฬ๊ๅๅใ࠽ࠫທ") in JzNoqV8ClRD6O and PzIpQnUXxRwNCivDhdakWTE(u"ࠬอไฯูฦࠫຘ") in JzNoqV8ClRD6O and wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭วๅ็ุำึࡀࠧນ") in JzNoqV8ClRD6O)
			if not yeBTHqdCEAs94MF3wk2xU0Ga: KxuNPa1XHctJeDZbAvqMSkE = ggJvHnLYzmlj3Z(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡤࡧࡱࡸࡪࡸࠧບ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ้็ࠤฯืำๅ๊ࠢิ์ࠦวๅำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬປ"),JzNoqV8ClRD6O.replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩ࡟ࡠࡳ࠭ຜ"),B6IrC7zEHlw1oaeWf))
	elif showDialogs:
		JzNoqV8ClRD6O = IlL8ZnX74Yvep(u"ࠪࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅหࠪຝ")
		OCsZDVl7NQ1xjdBJ = ggJvHnLYzmlj3Z(kb2icmDGVUZfW1OFz7sv(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫພ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬຟ")+NeU6uRGpECkvMV5jf(u"࠭ࠠࠡ࠳࠲࠹ࠬຠ"),IlL8ZnX74Yvep(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬມ"))
		F2FOujxCh9G7IafX = ggJvHnLYzmlj3Z(NeU6uRGpECkvMV5jf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨຢ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩຣ")+HHvYL68lbJVZWM7tQEzSex3(u"ࠪࠤࠥ࠸࠯࠶ࠩ຤"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩລ"))
		GMoXWqOV0eg4JkcAbzLrxli = ggJvHnLYzmlj3Z(rNyT0edugn(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ຦"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ວ")+OOkmZiVcfqlEurM1dHGb(u"ࠧࠡࠢ࠶࠳࠺࠭ຨ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ຩ"))
		Y7thO0VZRbusqAPKW = ggJvHnLYzmlj3Z(R3lezw8h407ZvrAFxT(u"ࠩࡦࡩࡳࡺࡥࡳࠩສ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪຫ")+QQHFtjcaR2VpnSyTIv(u"ࠫࠥࠦ࠴࠰࠷ࠪຬ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪອ"))
		KxuNPa1XHctJeDZbAvqMSkE = ggJvHnLYzmlj3Z(NeU6uRGpECkvMV5jf(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ຮ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧຯ")+kb2icmDGVUZfW1OFz7sv(u"ࠨࠢࠣ࠹࠴࠻ࠧະ"),eGW7cI6aQhr0(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧັ"))
	gMXJ1uE2flZASBm6jYhspTnIe = nvHz4MPEfa6Q1D5cydq(f4vncKMRlXG9s)
	W3tVArvwOi20fXUyTS = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡅ࡛ࡀࠠࠨາ")+gMXJ1uE2flZASBm6jYhspTnIe+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫ࠲࠭ຳ")+type
	AL5hPfTU9Dmuy1VwxOvX7o0KN4 = k6apiPAlLKM1ed8J42RjHh0o if rNyT0edugn(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨິ") in ui7N5YGR9KdslpEbQkVTwFqDgI else f4vncKMRlXG9s
	if not KxuNPa1XHctJeDZbAvqMSkE:
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩີ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪຶ"))
		return f4vncKMRlXG9s
	EoutP0VyIGqS4OCY8N9deXWTcs = ACOWB6GRmIbDKyl3Zn.getInfoLabel(fOc18oTm5hsdD4pVZQj(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧື"))
	JzNoqV8ClRD6O += NOrchaEV1iIZ87Uzlwgum(u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨຸ")+lvsJ2jaZktmNO6PbdXS+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࠤ࠿ࡢ࡜࡯ູࠩ")
	JzNoqV8ClRD6O += NOrchaEV1iIZ87Uzlwgum(u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤ຺ࠬ")+gMXJ1uE2flZASBm6jYhspTnIe+HVmIrFwau90jQsgiWzExk(u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫົ")+dor6Z1x9CvBpQgKTG38bYtJ+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࠠ࠻࡞࡟ࡲࠬຼ")
	JzNoqV8ClRD6O += rNyT0edugn(u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬຽ")+EoutP0VyIGqS4OCY8N9deXWTcs
	HMpc7T2lNkGV3CEyPFI8hvq9aS = Fa1ehN3qiLZ8tfwj()
	HMpc7T2lNkGV3CEyPFI8hvq9aS = YUkzG2ymNSqdon(HMpc7T2lNkGV3CEyPFI8hvq9aS)
	if HMpc7T2lNkGV3CEyPFI8hvq9aS: JzNoqV8ClRD6O += V0VZk9763fusTReHFo4(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪ຾")+HMpc7T2lNkGV3CEyPFI8hvq9aS
	if url: JzNoqV8ClRD6O += pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭຿")+url
	if xmezOWMyhSXRGHlEk2JnsI: JzNoqV8ClRD6O += kb2icmDGVUZfW1OFz7sv(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪເ")+xmezOWMyhSXRGHlEk2JnsI
	JzNoqV8ClRD6O += OOkmZiVcfqlEurM1dHGb(u"ࠫࠥࡀ࡜࡝ࡰࠪແ")
	if showDialogs: kkDz5sdaPteM(IlL8ZnX74Yvep(u"ࠬาวา์ࠣห้หัิษ็ࠫໂ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨໃ"))
	if yrPG7D3t9Wsg0I1CE8m4UuM:
		euVlSpIGib2TqQULCaXR9xhgZ = yrPG7D3t9Wsg0I1CE8m4UuM
		if J92gCnbGWidQV70lBteTwU6D8uyzL: euVlSpIGib2TqQULCaXR9xhgZ = euVlSpIGib2TqQULCaXR9xhgZ.encode(YRvPKe2zMTDs8UCkr)
		euVlSpIGib2TqQULCaXR9xhgZ = NHsYdVBpXn.b64encode(euVlSpIGib2TqQULCaXR9xhgZ)
	elif AL5hPfTU9Dmuy1VwxOvX7o0KN4:
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧໄ") in ui7N5YGR9KdslpEbQkVTwFqDgI: f3KwYJNGHhb1lviMF0 = tHLwPKXACG5B2deoiup
		else: f3KwYJNGHhb1lviMF0 = ASInatQNLOxmbF
		if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(f3KwYJNGHhb1lviMF0):
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໅"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ฿๐ัࠡ็๋ะํีࠧໆ"))
			return f4vncKMRlXG9s
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,lrtFSogC8Nh9(u"ࠪ࠲ࡡࡺࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡹࡥ࡯ࡦࠣࡸ࡭࡫ࠠ࡭ࡱࡪࡪ࡮ࡲࡥࠨ໇"))
		E7rIbVtD3GSKTxfON,SyTm6WjEM0P1ApXuNlixtwOqRkLQ = [],YJpWv4QzC7sx8INVPukeZiOD03K(u"࠵ᄀ")
		file = open(f3KwYJNGHhb1lviMF0,V0VZk9763fusTReHFo4(u"ࠫࡷࡨ່ࠧ"))
		size,count = TGNwJtqvjZCnUhHKEXoep8xBbk(f3KwYJNGHhb1lviMF0)
		if size>wP4kpvXoDHq3hs7TFLyr2COn8(u"࠹࠰࠲࠲࠳࠴ᄁ"): file.seek(-wP4kpvXoDHq3hs7TFLyr2COn8(u"࠹࠰࠲࠲࠳࠴ᄁ"),IIPNcsCvQnOZk0yejJKl4BtgSrMw.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(YRvPKe2zMTDs8UCkr)
		data = ULJNHjGxD0YS3AXblRE4Pq8gp2QCFZ(data)
		aLZSGBw7NhXtCuDWgJR = data.splitlines()
		for iJbFcE2OQWRykXNMUlfrCv918SqpD in reversed(aLZSGBw7NhXtCuDWgJR):
			kXS3g75vnt = XiudasZV1rYAbLw5tD(iJbFcE2OQWRykXNMUlfrCv918SqpD)
			if kXS3g75vnt: continue
			cjZnrbaYq7tOC3L50h = YYqECUofyi7wFrW.findall(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮້࠭ࠬ"),iJbFcE2OQWRykXNMUlfrCv918SqpD,YYqECUofyi7wFrW.DOTALL)
			if cjZnrbaYq7tOC3L50h:
				iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w],cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]).replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][cCRvAuJQfjBpTg0PbYiaNO87],NdKhAS6MXVEORLTwob92pxlZ)
			else:
				cjZnrbaYq7tOC3L50h = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮໊࠭"),iJbFcE2OQWRykXNMUlfrCv918SqpD,YYqECUofyi7wFrW.DOTALL)
				if cjZnrbaYq7tOC3L50h: iJbFcE2OQWRykXNMUlfrCv918SqpD = iJbFcE2OQWRykXNMUlfrCv918SqpD.replace(cjZnrbaYq7tOC3L50h[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU],NdKhAS6MXVEORLTwob92pxlZ)
			E7rIbVtD3GSKTxfON.append(iJbFcE2OQWRykXNMUlfrCv918SqpD)
			if len(str(E7rIbVtD3GSKTxfON))>Tzx81Wb0RZC4ID5AyiU2(u"࠲࠶࠳࠳࠴࠵ᄂ"): break
		E7rIbVtD3GSKTxfON = reversed(E7rIbVtD3GSKTxfON)
		euVlSpIGib2TqQULCaXR9xhgZ = lNTJCZeBicWEz0Mg(u"ࠧ࡝ࡴ࡟ࡲ໋ࠬ").join(E7rIbVtD3GSKTxfON)
		euVlSpIGib2TqQULCaXR9xhgZ = euVlSpIGib2TqQULCaXR9xhgZ.encode(YRvPKe2zMTDs8UCkr)
		euVlSpIGib2TqQULCaXR9xhgZ = NHsYdVBpXn.b64encode(euVlSpIGib2TqQULCaXR9xhgZ)
	else: euVlSpIGib2TqQULCaXR9xhgZ = NdKhAS6MXVEORLTwob92pxlZ
	url = xKp3jkIvM09AZ4euXa87i5TVtfUD[lRP6GTaZJA1Xw3egLM4(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ໌")][cCRvAuJQfjBpTg0PbYiaNO87]
	YWsjNtDXPAgCya = {xY4icgQUj6mPVs73CTKu(u"ࠩࡶࡹࡧࡰࡥࡤࡶࠪໍ"):W3tVArvwOi20fXUyTS,gniNItGL6bKwpEW(u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ໎"):JzNoqV8ClRD6O,JGwsL21ZRlqSrWxEmF(u"ࠫࡱࡵࡧࡧ࡫࡯ࡩࠬ໏"):euVlSpIGib2TqQULCaXR9xhgZ}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,JGwsL21ZRlqSrWxEmF(u"ࠬࡖࡏࡔࡖࠪ໐"),url,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ໑"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if NeU6uRGpECkvMV5jf(u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ໒") in LMKFcEkU1Q7R80yt4OsgvwxbfP: PsKJk8XRHAQM = k6apiPAlLKM1ed8J42RjHh0o
	else: PsKJk8XRHAQM = f4vncKMRlXG9s
	if showDialogs:
		if PsKJk8XRHAQM:
			kkDz5sdaPteM(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫ໓"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪ໔"))
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩ໕"),R3lezw8h407ZvrAFxT(u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭໖"))
		else:
			kkDz5sdaPteM(OOkmZiVcfqlEurM1dHGb(u"๊ࠬไฤีไࠤๆฺไࠡษ็ษึูวๅࠩ໗"),lNTJCZeBicWEz0Mg(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧ໘"))
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໙"),rNyT0edugn(u"ࠨะฺวࠥ๎แีๆࠣๅ๏ࠦลาีส่ࠥอไาีส่ฮ࠭໚"))
	return PsKJk8XRHAQM
def eNcfBX4sLpyQmxa8S():
	ZLI75sAmWojzUYJtluw8h6H4reCf = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪࠦ࡭ࡦࡰࡸࠤ࡮ࡺࡥ࡮ࡵࠣࡸࡴࠦࡡࠡ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠣࡳࡹ࡮ࡥࡳࠢࡷ࡬ࡦࡴࠠࡂࡴࡤࡦ࡮ࡩࠠ࠯࠰ࠣࡓࡷࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤࡸ࡮࡯ࡸࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡥࡳࡪࠠࡵࡧࡻࡸࠥࡅࠡࠨ໛")
	XXnFpTZ9ksicAKzg1lMCP5Dtq = xY4icgQUj6mPVs73CTKu(u"๋้ࠪࠦสา์าࠤฯืฬๆหࠣๆํอฦๆࠢส่อืๆศ็ฯࠤส๊้ࠡๆ฽อࠥษฮา๋ࠣ฾๏ืࠠศๆ฼ีอ๐ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหุ่ษิࠤฬ๊รฮำไࠤํอไไฬสฬฮࠦวๅ฻ิฬ๏ฯࠠภࠣࠪໜ")
	Jc7R92k15u = HQK8NwPVcoJ(NeU6uRGpECkvMV5jf(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫໝ"),kb2icmDGVUZfW1OFz7sv(u"ࠬิั้ฮࠣࡉࡽ࡯ࡴࠨໞ"),Hlp3z0APt1GR4kMYK5xST(u"࠭ࡔࡳࡣࡱࡷࡱࡧࡴࡦࠢอีั๋ษࠨໟ"),hCm2fnEXs6Zt(u"ฺࠧำห๎ࠥࡇࡲࡢࡤ࡬ࡧࠬ໠"),eGW7cI6aQhr0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໡"),ZLI75sAmWojzUYJtluw8h6H4reCf+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩ࡟ࡲࡡࡴࠧ໢")+XXnFpTZ9ksicAKzg1lMCP5Dtq)
	if Jc7R92k15u in [-NeU6uRGpECkvMV5jf(u"࠲ᄃ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠲ᄄ")]: return
	elif Jc7R92k15u==NeU6uRGpECkvMV5jf(u"࠴ᄅ"):
		import md4vN8TBez
		md4vN8TBez.RgLTiujBCytzUGYI()
		return
	t9FKou1cX8pOJZIvR = HVmIrFwau90jQsgiWzExk(u"ࡔࡳࡷࡨᄬ")
	while t9FKou1cX8pOJZIvR:
		t9FKou1cX8pOJZIvR = lNTJCZeBicWEz0Mg(u"ࡇࡣ࡯ࡷࡪᄭ")
		message = IlL8ZnX74Yvep(u"ࠪษีอฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแ฻์ิࠤฬ๊ฬๅัࠣษ้๏ࠠฤ์ࠣะ้ีࠠฬษ้๎ࠥ็๊่ࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࠰࠱ࠤะ๋ࠠษ฻า๋ฬฺ๋ࠦำࠣห้ิืࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࡜࡯ࠢศิฬࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠๅษࠣฮ฽ํัࠡๆๆࠤ࠳࠴ࠠศา๊ฬࠥหไ๊ࠢࠥษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠣࠢ࠱࠲ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็๋ๆ฾ࠦวๅฮ฽ีฬ็๊ࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠศๆล๊ࠥ็สฮࠢࠥษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠣࠢยࠥࠬ໣")
		Jc7R92k15u = HQK8NwPVcoJ(Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ໤"),fOc18oTm5hsdD4pVZQj(u"ࠬࡋࡸࡪࡶࠣาึ๎ฬࠨ໥"),lrtFSogC8Nh9(u"࡙࠭ࡦࡵ๊ࠣ฾๋ࠧ໦"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠡว้ะ้๐า๋ࠩ໧"),JGwsL21ZRlqSrWxEmF(u"ࠨ฻า้ࠥ฾็้ำࠣห้ษอาใࠣ์ฬ๊ใหษหอࠥอไฺำห๎ฮ࠭໨"),message,profile=OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ໩"))
		if Jc7R92k15u==lNTJCZeBicWEz0Mg(u"࠶ᄆ"):
			message = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡶ࡫ࡩࡳࠦ࡯ࡱࡧࡱࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡺ࡯ࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡸࡱࡩ࡯ࠢࡷ࡬ࡦࡺࠠࡩࡣࡹࡩࠥࡢࠢࡂࡴ࡬ࡥࡱࡢࠢࠡࡨࡲࡲࡹࠦ࠮࠯ࠢࡄࡲࡩࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦࡉࡧࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠ࠯࠰ࠣࡘ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡸࡥࡨ࡫ࡲࡲࡦࡲࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢ࡟ࡲࡡࡴࠠࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡴ࡯ࡸࠢࡷࡳࠥࡵࡰࡦࡰࠣࡸ࡭࡫ࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡅࠡࠨ໪")
			Jc7R92k15u = HQK8NwPVcoJ(hCm2fnEXs6Zt(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ໫"),HVmIrFwau90jQsgiWzExk(u"ࠬࡋࡸࡪࡶࠣาึ๎ฬࠨ໬"),Hlp3z0APt1GR4kMYK5xST(u"࡙࠭ࡦࡵ๊ࠣ฾๋ࠧ໭"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡂࡴࡤࡦ࡮ࡩฺࠠำห๎ࠬ໮"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡏ࡬ࡷࡸ࡯࡮ࡨࠢࡄࡶࡦࡨࡩࡤࠢࡉࡳࡳࡺࠠࠧࠢࡗࡩࡽࡺࠧ໯"),message,profile=YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ໰"))
			if Jc7R92k15u==QQHFtjcaR2VpnSyTIv(u"࠷ᄇ"): t9FKou1cX8pOJZIvR = gniNItGL6bKwpEW(u"ࡖࡵࡹࡪᄮ")
		if Jc7R92k15u==eGW7cI6aQhr0(u"࠷ᄈ"): mgwjkqxKZcSa2Ofd5EJ()
	return
def faQSprgwXs2vVIFP4dAiT5NmhjE07():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໱"),lrtFSogC8Nh9(u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪ໲"))
	return
def ye6Yf3kJxS4h1ZDsKE():
	JzNoqV8ClRD6O = lrtFSogC8Nh9(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬ໳")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ໴"),JzNoqV8ClRD6O)
	return
def aV4j9FvDb3HyT8iLJ():
	JzNoqV8ClRD6O = NeU6uRGpECkvMV5jf(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫ໵")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໶"),JzNoqV8ClRD6O)
	return
def l5pmuBR3nSzT():
	JzNoqV8ClRD6O = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭໷")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໸"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭໹"),JzNoqV8ClRD6O)
	return
def TamyBH0gDMKWsOZ3IxrnwFNh():
	JzNoqV8ClRD6O = hCm2fnEXs6Zt(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ໺")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(HVmIrFwau90jQsgiWzExk(u"࠭ࡣࡦࡰࡷࡩࡷ࠭໻"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໼"),JzNoqV8ClRD6O,lRP6GTaZJA1Xw3egLM4(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ໽"))
	return
def lAUv3LZEsaG05SXOnboNfh():
	ZLI75sAmWojzUYJtluw8h6H4reCf = rNyT0edugn(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪ໾")
	XXnFpTZ9ksicAKzg1lMCP5Dtq = V0VZk9763fusTReHFo4(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬ໿")
	mbzrpYR0ZBMvjxJ2eDS = PzIpQnUXxRwNCivDhdakWTE(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬༀ")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༁"),ZLI75sAmWojzUYJtluw8h6H4reCf,XXnFpTZ9ksicAKzg1lMCP5Dtq,mbzrpYR0ZBMvjxJ2eDS)
	return
def sBJb1NZASzY():
	XXnFpTZ9ksicAKzg1lMCP5Dtq = LtGoXlQ2IYxqTJRySE6udfW98(u"࠭วๅๅสุࠥํ่ࠡ็ัึ๋ࠦๅลไอࠤ้๊ๅฺๆ๋้ฬะ๋ࠠีอาิ๋็ࠡษ็ฬึ์วๆฮ่ࠣำุๆࠡืไัฬะࠠศๆศ๊ฯืๆ๋ฬࠣ์ึ๎วษูࠣห้็๊ะ์๋๋ฬะࠠๅๆู๋ํ๊ࠠฦๆํ๋ฬࠦศิำ฼อࠥ๎ศะ๊้ࠤส์สา่ํฮࠥ๎วๅสิ๊ฬ๋ฬࠡ์่ืาํวࠡฬ็ๆฬฬ๊ศࠢห฽ิࠦว็ฬ๊หฦูࠦๆำ๊หࠥ๎รุ๋สࠤ฾์ฯࠡฬะำ๏ัࠠศๆหี๋อๅอࠢ࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤุฮูสࠢฦ๊ํอูࠡๆ฼้ึࠦวๅๅสุࠥࡀࠧ༂")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += V0VZk9763fusTReHFo4(u"ࠧ࡝ࡰ࡟ࡲࠬ༃") + ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨ࠳࠱ࠤะอศหࠢ็ฺ่็อศฬࠣห้ะ๊ࠡ็฼ีํ็ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ืࠠ็้สส๏อ้ࠠ็าฮ์ࠦࠧ༄") + str(hzP83xLawFqYneDtHGmSriWE/gniNItGL6bKwpEW(u"࠶࠱ᄉ")/gniNItGL6bKwpEW(u"࠶࠱ᄉ")/OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠳࠶ᄊ")/IlL8ZnX74Yvep(u"࠵࠳ᄋ")) + OOkmZiVcfqlEurM1dHGb(u"ุࠩࠣ์ืࠧ༅")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + eGW7cI6aQhr0(u"ࠪ࠶࠳ࠦฬะษࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็้ๆื่ืࠢฦ๊์อࠠๅษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ༆") + str(KxC8ewP4yTmq3lLj6voVfh7WNOX5H/NeU6uRGpECkvMV5jf(u"࠹࠴ᄌ")/NeU6uRGpECkvMV5jf(u"࠹࠴ᄌ")/V0VZk9763fusTReHFo4(u"࠶࠹ᄍ")) + WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࠥ๐่ๆࠩ༇")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ༈") + str(OewIv05xGhKQpFf/eGW7cI6aQhr0(u"࠻࠶ᄎ")/eGW7cI6aQhr0(u"࠻࠶ᄎ")/NeU6uRGpECkvMV5jf(u"࠸࠴ᄏ")) + NeU6uRGpECkvMV5jf(u"๋๊่࠭ࠠࠫ༉")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ༊") + str(h1dnE0q2zFHjXlvyGuLZxw/fOc18oTm5hsdD4pVZQj(u"࠶࠱ᄐ")/fOc18oTm5hsdD4pVZQj(u"࠶࠱ᄐ")) + Hlp3z0APt1GR4kMYK5xST(u"ࠨࠢึห฾ฯࠧ་")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + xY4icgQUj6mPVs73CTKu(u"ࠩ࠸࠲่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠะษษ้ฬ่ࠦๆัอ๋ࠥ࠭༌") + str(NXpO8DrVmeE/rNyT0edugn(u"࠷࠲ᄑ")/rNyT0edugn(u"࠷࠲ᄑ")) + kb2icmDGVUZfW1OFz7sv(u"ࠪࠤุอูสࠩ།")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + rNyT0edugn(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ༎") + str(MIT0n79k8beo26aJHW/YJpWv4QzC7sx8INVPukeZiOD03K(u"࠸࠳ᄒ")) + WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࠦฯใ์ๅอࠬ༏")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += B6IrC7zEHlw1oaeWf + gniNItGL6bKwpEW(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨ༐") + str(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE) + V0VZk9763fusTReHFo4(u"ࠧࠡัๅ๎็ฯࠧ༑")
	XXnFpTZ9ksicAKzg1lMCP5Dtq += R3lezw8h407ZvrAFxT(u"ࠨ࡞ࡱࡠࡳ࠭༒") + gniNItGL6bKwpEW(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭༓") + str(h1dnE0q2zFHjXlvyGuLZxw/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")) + hCm2fnEXs6Zt(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫ༔") + str(OewIv05xGhKQpFf/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")/eGW7cI6aQhr0(u"࠶࠹ᄔ")) + Hlp3z0APt1GR4kMYK5xST(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪ༕") + str(NXpO8DrVmeE/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")) + HVmIrFwau90jQsgiWzExk(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩ༖") + str(MIT0n79k8beo26aJHW/HVmIrFwau90jQsgiWzExk(u"࠹࠴ᄓ")) + NeU6uRGpECkvMV5jf(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨ༗") + str(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE) + kb2icmDGVUZfW1OFz7sv(u"ࠧࠡัๅ๎็ฯ༘ࠧ")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(NeU6uRGpECkvMV5jf(u"ࠨࡴ࡬࡫࡭ࡺ༙ࠧ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧ༚"),XXnFpTZ9ksicAKzg1lMCP5Dtq,QQHFtjcaR2VpnSyTIv(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭༛"))
	return
def zCgP09WFRJukoB2N4Dhab1rj6y():
	JzNoqV8ClRD6O = R3lezw8h407ZvrAFxT(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧ༜")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༝"),JzNoqV8ClRD6O)
	return
def D23q8QTREuvAFJnm4B7cKroHyS():
	JzNoqV8ClRD6O = NOrchaEV1iIZ87Uzlwgum(u"࠭ลัษࠣ์ฬา็หๅู้้ࠣไสࠢไ๎ࠥอไีสๆอࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤศ๎ࠠศ่ๆࠤฯ฾ๆࠡล้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ่อๆࠡใํ๋๋ࠥิไๆฬࠤ๊สโห้ࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢไษี์ࠠอำหࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠๅๅํࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอ฽ไษࠢสฺ่็อสࠢสฺ่ำ๊ฮหࠣ์ฯิา๋่๊หࠥฮฯๅษ้๋ࠣࠦวๅืไัฮࠦวๅไา๎๊ฯࠧ༞")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༟"),JzNoqV8ClRD6O)
	return
def yfMVixNbRGoH8m9():
	JzNoqV8ClRD6O = NeU6uRGpECkvMV5jf(u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ༠")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ༡"),JzNoqV8ClRD6O)
	return
def xo2Sme8a4DOw0():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭༢"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"้้๊ࠫࠡ์฼้้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไโ์า๎ํํวหࠢ࡟ࡲࠥ๐ฬษࠢอๅ฾๐ไࠡวูหๆฯࠠศี่๋ฬࠦ࡜࡯ࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ༣"))
	aV1HYqMRxUA3vmOr8LnGofj0FI5C7(rNyT0edugn(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ༤"),k6apiPAlLKM1ed8J42RjHh0o)
	return
def EEWbtr1wNXc9l():
	JzNoqV8ClRD6O  = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ๅละิห่ࠥวๆฬࠣฬ฾฼ࠠีำๆหฯࠦวๅว้ฮึ์สࠡษ็ำํ๊๊ࠡสฺ๋฾ูࠦศศๅࠤ฻ีࠠศๆหีฬ๋ฬࠡ็ฮ่้่ࠥะ์่ࠣฯูๅฮࠢไๆ฼ࠦไษ฻ูࠤู๊สฯั่๎ࠥอไๆฬุๅาࠦศศๆาาํ๊ࠠๅ็๋ห็฿ࠠศๆไ๎ิ๐่ࠨ༥")
	JzNoqV8ClRD6O += Tzx81Wb0RZC4ID5AyiU2(u"๊้ࠧࠡฮ๏าษࠡๆ๊ิฬࠦวๅ฻สส็ࠦแศ่๊ࠤฯ่ั๋สสࠤัฺ๋๊่ࠢืฯิฯๆ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡๆสࠤ๏ูสุ์฼์๋ࠦวๅัั์้ࠦไอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ัࠦอห๋้ࠣ฾ࠦวิฬัำฬ๋ࠧ༦")
	JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+lNTJCZeBicWEz0Mg(u"ࠨโࠣࠤ࡛ࡖࡎࠡࠢฦ์ࠥࠦࡐࡳࡱࡻࡽࠥࠦร้ࠢࠣࡈࡓ࡙ࠠࠡล๋ࠤศ๐ࠠฮๆࠣฬุ๐ืࠡฤัีࠬ༧")+kjd9LyNqQHMUevZiRI7OlBGF1h+B6IrC7zEHlw1oaeWf
	JzNoqV8ClRD6O += OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩ࡟ࡲ้อๆ้ࠡำห๊ࠥๆࠡ์ะ่ࠥอไๆึๆ่ฮ่ࠦฦ่่หࠥ็โุࠢึ๎็๎ๅࠡสศู้ออࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฦ฻สๆฮࠦๅ้ษๅ฽ࠥอฮา๋ࠣ็ฬ์สࠡฬ฼้้ࠦำศสๅหࠥฮฯู้่้ࠣอใๅࠩ༨")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(rNyT0edugn(u"ࠪࡶ࡮࡭ࡨࡵࠩ༩"),HVmIrFwau90jQsgiWzExk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༪"),JzNoqV8ClRD6O,NeU6uRGpECkvMV5jf(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ༫"))
	JzNoqV8ClRD6O = Tzx81Wb0RZC4ID5AyiU2(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩ༬")
	JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭༭")+kjd9LyNqQHMUevZiRI7OlBGF1h
	JzNoqV8ClRD6O += NOrchaEV1iIZ87Uzlwgum(u"ࠨ࡞ࡱࡠࡳ࠭༮")+Hlp3z0APt1GR4kMYK5xST(u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ༯")
	JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+hCm2fnEXs6Zt(u"ฺ้ࠪืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࠬ༰")+kjd9LyNqQHMUevZiRI7OlBGF1h
	JzNoqV8ClRD6O += YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡡࡴ࡜࡯ࠩ༱")+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭༲")
	JzNoqV8ClRD6O += Whef0cxB2iR93SC5IwUtk+gniNItGL6bKwpEW(u"࠭วาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํวࠨ༳")+kjd9LyNqQHMUevZiRI7OlBGF1h
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭༴"),hCm2fnEXs6Zt(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯ༵ࠫ"),JzNoqV8ClRD6O,kb2icmDGVUZfW1OFz7sv(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ༶"))
	return
def REH4tT9sJOf5xw1BkiZ():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠪฯ้อหูࠡิๆ๊ࠥไห๊สู้ࠦๅฺࠢส่๊ฮัๆฮ༷ࠪ"),JGwsL21ZRlqSrWxEmF(u"ࠫศืำๅࠢิืฬ๊ษࠡล๋ࠤฺ๊ใๅห้๋ࠣࠦโศศ่อࠥิฯๆษอࠤ์ึวࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴร้ࠢหหุะฮะษ่ࠤฬ๊แ๋ีห์่ࠦระ่ส๋ࡡࡴࠧ༸")+Whef0cxB2iR93SC5IwUtk+xY4icgQUj6mPVs73CTKu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾༹ࠧ")+kjd9LyNqQHMUevZiRI7OlBGF1h+eGW7cI6aQhr0(u"࠭࡜࡯࡞ࡱวํࠦศศำึห้ࠦว๋็ํ่ࠥอไ๊ࠢฦำ๋อ็ࠡࠢ࡟ࡲࠥ࠭༺")+Whef0cxB2iR93SC5IwUtk+lrtFSogC8Nh9(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲ࠭༻")+kjd9LyNqQHMUevZiRI7OlBGF1h)
	return
def KeJF5gduqhEoy0WmIbC2val74OX():
	sBJb1NZASzY()
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(xY4icgQUj6mPVs73CTKu(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ༼"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭༽"),QQHFtjcaR2VpnSyTIv(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศ๋ࠢห้๋ำฮࠢํฮ๊ࠦสๅไสส๏อฺ่ࠠาࠤฬ์ส่ษฤࠤ฾๋ัࠡษ็ูๆำวห๋ࠢห้๋ำฮࠢ็หࠥ๐ึา๋้๊้ࠢๆࠡ์ะ่ࠥฮูืࠢสฺ่๊วไๆࠪ༾"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==V0VZk9763fusTReHFo4(u"࠶ᄕ"):
		ofPX61UZEpGMTQLa4eFKnqWiOIz(k6apiPAlLKM1ed8J42RjHh0o)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠫฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣฬฬ๊ใศ็็ࠫ༿"),xY4icgQUj6mPVs73CTKu(u"ࠬหะศࠢๆห๋ะฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศฯาࠤฬ๊ๅ้ษๅ฽ࠥ็ฬาสࠣห้๋่ใ฻ࠣห้ศๆࠡ࠰࠱࠲ࠥ๎รัษࠣห้๋ิไๆฬࠤู๊สๆำฬࠤๆหะ็ࠢสีุ๊ࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ั࠭ཀ"))
	return TT32BcvomhVewpgMSWkEb46y7xqO
def evDOF2iEbqN5txMnVoXRSsgd8c(showDialogs=k6apiPAlLKM1ed8J42RjHh0o):
	if not showDialogs: showDialogs = k6apiPAlLKM1ed8J42RjHh0o
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡇࡆࡖࠪཁ"),xY4icgQUj6mPVs73CTKu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭ག"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫགྷ"))
	if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
		ZAJE8I02kH = f4vncKMRlXG9s
		cfGPeIbDgox07mQ = LeIEtX7A6J(f4vncKMRlXG9s)
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+V0VZk9763fusTReHFo4(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧང")+cfGPeIbDgox07mQ+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡡࠬཅ"))
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཆ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩཇ"))
	else:
		ZAJE8I02kH = k6apiPAlLKM1ed8J42RjHh0o
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ཈"),lrtFSogC8Nh9(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫཉ"))
	if not ZAJE8I02kH and showDialogs: GMd87U3cxOjgXb()
	return ZAJE8I02kH
def GMd87U3cxOjgXb():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫཊ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨཋ"))
	H5NMrlI8fGj1cz0dpnPtxAoQ4h2KT()
	return
def AWxD1rw2o6EeF(ui7N5YGR9KdslpEbQkVTwFqDgI=NdKhAS6MXVEORLTwob92pxlZ):
	AL5hPfTU9Dmuy1VwxOvX7o0KN4 = k6apiPAlLKM1ed8J42RjHh0o
	if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ཌ") not in ui7N5YGR9KdslpEbQkVTwFqDgI:
		AL5hPfTU9Dmuy1VwxOvX7o0KN4 = f4vncKMRlXG9s
		us7rL1qZAJURmQjPTtIhGN0daXf869 = HQK8NwPVcoJ(Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫཌྷ"),V0VZk9763fusTReHFo4(u"ࠬิั้ฮࠪཎ"),Tzx81Wb0RZC4ID5AyiU2(u"࠭ลาีส่๋ࠥิไๆฬࠫཏ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠧฦำึห้ࠦัิษ็อࠬཐ"),eGW7cI6aQhr0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫད"),eGW7cI6aQhr0(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬདྷ"))
		if us7rL1qZAJURmQjPTtIhGN0daXf869 in [-Hlp3z0APt1GR4kMYK5xST(u"࠷ᄖ"),gniNItGL6bKwpEW(u"࠰ᄗ")]: return
		elif us7rL1qZAJURmQjPTtIhGN0daXf869==lrtFSogC8Nh9(u"࠲ᄘ"):
			AL5hPfTU9Dmuy1VwxOvX7o0KN4 = k6apiPAlLKM1ed8J42RjHh0o
			ui7N5YGR9KdslpEbQkVTwFqDgI = IlL8ZnX74Yvep(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ན")
	if AL5hPfTU9Dmuy1VwxOvX7o0KN4:
		if QQHFtjcaR2VpnSyTIv(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫཔ") not in ui7N5YGR9KdslpEbQkVTwFqDgI:
			TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(IlL8ZnX74Yvep(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬཕ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭བ"),rNyT0edugn(u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧབྷ"))
			if TT32BcvomhVewpgMSWkEb46y7xqO!=fOc18oTm5hsdD4pVZQj(u"࠳ᄙ"):
				ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫམ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬཙ"))
				return
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ཚ"),rNyT0edugn(u"ࠫๆ๐ࠠศๆืหูฯࠠศๆๅหิ๋ษࠡฯส์้ࠦร็ࠢอ็ฯฮࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอิาฯࠣๅ๏ํวࠡษ็ู้้ไสࠢฦ์ࠥอไๆู๊์฾่ࠦฦาสࠤศืฯหࠢฯ์ฬฮࠠๆ่ࠣห้๋ศา็ฯࠤๆหะ็ࠢฦ็ฯฮฺ่๋ࠠห๋ࠦศา์า็ࠥษไฦๆๆฮึ๎ๆ๋ࠢส่ส๐ๅ๋ๆࠣ์ฯึใา๋่ࠢฬࠦส็ี์ࠤศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨཛ"))
	search = Z6GiHgnz0jNytc(header=QQHFtjcaR2VpnSyTIv(u"ࠬ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧཛྷ"),source=yNIDEX5hU4G769)
	if not search: return
	JzNoqV8ClRD6O = search
	if AL5hPfTU9Dmuy1VwxOvX7o0KN4: type = Hlp3z0APt1GR4kMYK5xST(u"࠭ࡐࡳࡱࡥࡰࡪࡳࠧཝ")
	else: type = xY4icgQUj6mPVs73CTKu(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠨཞ")
	PsKJk8XRHAQM = TM3EgsyYRtVxA9i(type,JzNoqV8ClRD6O,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫཟ"),ui7N5YGR9KdslpEbQkVTwFqDgI)
	return
def Jou4KX8bw3eOn5fxzayWFAN():
	ui7N5YGR9KdslpEbQkVTwFqDgI = V0VZk9763fusTReHFo4(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭འ")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(gniNItGL6bKwpEW(u"ࠪࡶ࡮࡭ࡨࡵࠩཡ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫར"),ui7N5YGR9KdslpEbQkVTwFqDgI,eGW7cI6aQhr0(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨལ"))
	ui7N5YGR9KdslpEbQkVTwFqDgI = Hlp3z0APt1GR4kMYK5xST(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩཤ")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(lNTJCZeBicWEz0Mg(u"ࠧ࡭ࡧࡩࡸࠬཥ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭ས"),ui7N5YGR9KdslpEbQkVTwFqDgI,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬཧ"))
	return
def j1DR9NEu3oGU8xi():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ཨ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩཀྵ"))
	yfMVixNbRGoH8m9()
	return
def uVIiT3vFU2nhwk4jagcN():
	ZLI75sAmWojzUYJtluw8h6H4reCf,XXnFpTZ9ksicAKzg1lMCP5Dtq,mbzrpYR0ZBMvjxJ2eDS,MWX39d1VjgqPaftLAwUD8orJc,tRvLHWy5dnlVFu6xs1p,dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n,OfRCSj6pJutMzLsPUE = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	YWsjNtDXPAgCya,iT8JQdYHMIpWlcm6,eXaRjbGy1UJdslriDPZNuzMv,vACo6NQg8nxLBfHIM9ePGr2DFX = {rNyT0edugn(u"ࠬࡧࠧཪ"):YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡡࠨཫ")},{},[],{}
	url = xKp3jkIvM09AZ4euXa87i5TVtfUD[fOc18oTm5hsdD4pVZQj(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧཬ")][llxMLe4gobHhsj1WGvd7qmIU]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(MIT0n79k8beo26aJHW,xY4icgQUj6mPVs73CTKu(u"ࠨࡒࡒࡗ࡙࠭཭"),url,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧ཮"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(NeU6uRGpECkvMV5jf(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡗࡹࡧࡴࡦࡵࠪ཯"),lrtFSogC8Nh9(u"࡚࡙ࠫࡁࠨ཰"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(lRP6GTaZJA1Xw3egLM4(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡑࡩ࡯ࡩࡧࡳࡲཱ࠭"),IlL8ZnX74Yvep(u"࠭ࡕࡌིࠩ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(R3lezw8h407ZvrAFxT(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹཱིࠧ"),HVmIrFwau90jQsgiWzExk(u"ࠨࡗࡄࡉུࠬ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(xY4icgQUj6mPVs73CTKu(u"ࠩࡖࡥࡺࡪࡩࠡࡃࡵࡥࡧ࡯ࡡࠨཱུ"),NeU6uRGpECkvMV5jf(u"ࠪࡏࡘࡇࠧྲྀ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡓࡵࡲࡵࡪࠣࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭ཷ"),R3lezw8h407ZvrAFxT(u"ࠬࡔ࠮ࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪླྀ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧཹ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡘ࠰ࡖࡥ࡭ࡧࡲࡢེࠩ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡡࡢࡣཻࠬ"),Uv7MkgVGyEbAlfFP0S8Zjqp2J)
	try: Xjbt9Ta0RcWgDBN = BdnA8WwtJeKUVvE(lrtFSogC8Nh9(u"ࠩ࡯࡭ࡸࡺོࠧ"),LMKFcEkU1Q7R80yt4OsgvwxbfP)
	except:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัཽ࠭"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫཾ"))
		return
	FbISGJ0NkOzEKAyjWY,JVo9b1WxGhB8rPySpgq2CdADR,WVsjCGB30i52Y = Xjbt9Ta0RcWgDBN
	vACo6NQg8nxLBfHIM9ePGr2DFX = {}
	ccO0SfaGnDHwy6l9pWxAU = [YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨཿ"),NeU6uRGpECkvMV5jf(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒྀࠬ")]
	uhaX4dDVSJOEsq71i3gMvr = [YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡂࡎࡏཱྀࠫ"),lNTJCZeBicWEz0Mg(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨྂ"),lRP6GTaZJA1Xw3egLM4(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪྃ"),rNyT0edugn(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ྄࡙ࠧ"),kb2icmDGVUZfW1OFz7sv(u"ࠫࡗࡋࡐࡐࡕࠪ྅")]+ccO0SfaGnDHwy6l9pWxAU+yy0zIog9KDlfOQ+EIVDQBT4RprwKAlaHd5t1LcgemqP
	for mAH4aPy8q1w,oosKHuWZ4Xl0jQbRfPh6G,W6EriPIUl37sT8AtHF4nOXQqMVYuwR in JVo9b1WxGhB8rPySpgq2CdADR:
		W6EriPIUl37sT8AtHF4nOXQqMVYuwR = L5xKSr96JmaX7N(W6EriPIUl37sT8AtHF4nOXQqMVYuwR)
		W6EriPIUl37sT8AtHF4nOXQqMVYuwR = W6EriPIUl37sT8AtHF4nOXQqMVYuwR.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࠦ࠮ࠨ྆"))
		MWX39d1VjgqPaftLAwUD8orJc += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+mAH4aPy8q1w+IlL8ZnX74Yvep(u"࠭࠺ࠡࠩ྇")+kjd9LyNqQHMUevZiRI7OlBGF1h+W6EriPIUl37sT8AtHF4nOXQqMVYuwR+B6IrC7zEHlw1oaeWf
		if oosKHuWZ4Xl0jQbRfPh6G.isdigit():
			vACo6NQg8nxLBfHIM9ePGr2DFX[mAH4aPy8q1w] = int(oosKHuWZ4Xl0jQbRfPh6G)
			if int(oosKHuWZ4Xl0jQbRfPh6G)>YJpWv4QzC7sx8INVPukeZiOD03K(u"࠴࠴࠵ᄚ"): oosKHuWZ4Xl0jQbRfPh6G = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪྈ")
			else: oosKHuWZ4Xl0jQbRfPh6G = NOrchaEV1iIZ87Uzlwgum(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪྉ")
		if mAH4aPy8q1w not in uhaX4dDVSJOEsq71i3gMvr:
			if   oosKHuWZ4Xl0jQbRfPh6G==xY4icgQUj6mPVs73CTKu(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬྊ"): ZLI75sAmWojzUYJtluw8h6H4reCf += Uv7MkgVGyEbAlfFP0S8Zjqp2J+mAH4aPy8q1w
			elif oosKHuWZ4Xl0jQbRfPh6G==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬྋ"): XXnFpTZ9ksicAKzg1lMCP5Dtq += Uv7MkgVGyEbAlfFP0S8Zjqp2J+mAH4aPy8q1w
	JsNlKTMRXCxbdS9UgZnLHkQIB12po,GjhMKb8fgkocTINAVx16RHmPal,VDbW96Jkx4MdXShBInTQZzomGpcO1r = list(zip(*JVo9b1WxGhB8rPySpgq2CdADR))
	for mAH4aPy8q1w in sorted(V0fxhGR6MoiWNebgd7yS4jvE):
		if mAH4aPy8q1w not in JsNlKTMRXCxbdS9UgZnLHkQIB12po:
			MWX39d1VjgqPaftLAwUD8orJc += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+mAH4aPy8q1w+Hlp3z0APt1GR4kMYK5xST(u"ࠫ࠿ࠦࠧྌ")+kjd9LyNqQHMUevZiRI7OlBGF1h+LtGoXlQ2IYxqTJRySE6udfW98(u"๊ࠬวࠡ์๋ะิ࠭ྍ")+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭࡜࡯࡞ࡱࠫྎ")
			if mAH4aPy8q1w not in uhaX4dDVSJOEsq71i3gMvr: mbzrpYR0ZBMvjxJ2eDS += Uv7MkgVGyEbAlfFP0S8Zjqp2J+mAH4aPy8q1w
	for W6EriPIUl37sT8AtHF4nOXQqMVYuwR,SyTm6WjEM0P1ApXuNlixtwOqRkLQ in FbISGJ0NkOzEKAyjWY:
		W6EriPIUl37sT8AtHF4nOXQqMVYuwR = L5xKSr96JmaX7N(W6EriPIUl37sT8AtHF4nOXQqMVYuwR)
		tRvLHWy5dnlVFu6xs1p += W6EriPIUl37sT8AtHF4nOXQqMVYuwR+kb2icmDGVUZfW1OFz7sv(u"ࠧ࠻ࠢࠪྏ")+Whef0cxB2iR93SC5IwUtk+str(SyTm6WjEM0P1ApXuNlixtwOqRkLQ)+kjd9LyNqQHMUevZiRI7OlBGF1h+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࠢࠣࠤࠬྐ")
	ZLI75sAmWojzUYJtluw8h6H4reCf = ZLI75sAmWojzUYJtluw8h6H4reCf.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	XXnFpTZ9ksicAKzg1lMCP5Dtq = XXnFpTZ9ksicAKzg1lMCP5Dtq.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	mbzrpYR0ZBMvjxJ2eDS = mbzrpYR0ZBMvjxJ2eDS.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	ANhUYlnKId3ZoFEie1cqOBprVRJS = ZLI75sAmWojzUYJtluw8h6H4reCf+Uv7MkgVGyEbAlfFP0S8Zjqp2J+XXnFpTZ9ksicAKzg1lMCP5Dtq
	ZyfMTYE9AsubJH6  = Tzx81Wb0RZC4ID5AyiU2(u"่ࠩ์ฬู่่ࠡฯัࠥอไษำ้ห๊าࠠษฬื฾๏๊ࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭ྑ")+B6IrC7zEHlw1oaeWf+V0VZk9763fusTReHFo4(u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨྒ")+B6IrC7zEHlw1oaeWf
	ZyfMTYE9AsubJH6 += Whef0cxB2iR93SC5IwUtk+ANhUYlnKId3ZoFEie1cqOBprVRJS+kjd9LyNqQHMUevZiRI7OlBGF1h+lRP6GTaZJA1Xw3egLM4(u"ࠫࡡࡴ࡜࡯ࠩྒྷ")
	ZyfMTYE9AsubJH6 += HVmIrFwau90jQsgiWzExk(u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫྔ")+B6IrC7zEHlw1oaeWf+fOc18oTm5hsdD4pVZQj(u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪྕ")+B6IrC7zEHlw1oaeWf
	ZyfMTYE9AsubJH6 += Whef0cxB2iR93SC5IwUtk+mbzrpYR0ZBMvjxJ2eDS+kjd9LyNqQHMUevZiRI7OlBGF1h
	BPSHjkE07pTbmZ9gUfxn8R23,Fr9lM6HZpdT3KgjCPJ7Uzt,ooRteEw6H2za3Gb8y4BMDfUYvS,jjHwLq5E7g1CrlU3 = lRP6GTaZJA1Xw3egLM4(u"࠴ᄛ"),lRP6GTaZJA1Xw3egLM4(u"࠴ᄛ"),lRP6GTaZJA1Xw3egLM4(u"࠴ᄛ"),lRP6GTaZJA1Xw3egLM4(u"࠴ᄛ")
	all = vACo6NQg8nxLBfHIM9ePGr2DFX[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡂࡎࡏࠫྖ")]
	if V0VZk9763fusTReHFo4(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨྗ") in list(vACo6NQg8nxLBfHIM9ePGr2DFX.keys()): BPSHjkE07pTbmZ9gUfxn8R23 = vACo6NQg8nxLBfHIM9ePGr2DFX[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ྘")]
	if V0VZk9763fusTReHFo4(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫྙ") in list(vACo6NQg8nxLBfHIM9ePGr2DFX.keys()): Fr9lM6HZpdT3KgjCPJ7Uzt = vACo6NQg8nxLBfHIM9ePGr2DFX[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬྚ")]
	if NOrchaEV1iIZ87Uzlwgum(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩྛ") in list(vACo6NQg8nxLBfHIM9ePGr2DFX.keys()): ooRteEw6H2za3Gb8y4BMDfUYvS = vACo6NQg8nxLBfHIM9ePGr2DFX[lNTJCZeBicWEz0Mg(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪྜ")]
	if PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡓࡇࡓࡓࡘ࠭ྜྷ") in list(vACo6NQg8nxLBfHIM9ePGr2DFX.keys()): jjHwLq5E7g1CrlU3 = vACo6NQg8nxLBfHIM9ePGr2DFX[hCm2fnEXs6Zt(u"ࠨࡔࡈࡔࡔ࡙ࠧྞ")]
	jR6zDwah317HeVoiyJgqFMrIE4OYs = all-BPSHjkE07pTbmZ9gUfxn8R23-Fr9lM6HZpdT3KgjCPJ7Uzt-ooRteEw6H2za3Gb8y4BMDfUYvS-jjHwLq5E7g1CrlU3
	gHbS3MaYo0j6uTdm2qyQnKP,pRd4Eb3jtzK71HmQgGvcA6Uwfa = WVsjCGB30i52Y[e8XhbyuzvjYkIsJUtB5w]
	gHbS3MaYo0j6uTdm2qyQnKP,sEzJvGNRAQZ = WVsjCGB30i52Y[llxMLe4gobHhsj1WGvd7qmIU]
	Z93CwDyPjzemTd = pRd4Eb3jtzK71HmQgGvcA6Uwfa-sEzJvGNRAQZ
	OfRCSj6pJutMzLsPUE += D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(sEzJvGNRAQZ)+kjd9LyNqQHMUevZiRI7OlBGF1h+V0VZk9763fusTReHFo4(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭ྟ")
	OfRCSj6pJutMzLsPUE += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(Z93CwDyPjzemTd)+kjd9LyNqQHMUevZiRI7OlBGF1h+HHvYL68lbJVZWM7tQEzSex3(u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧྠ")
	OfRCSj6pJutMzLsPUE += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(pRd4Eb3jtzK71HmQgGvcA6Uwfa)+kjd9LyNqQHMUevZiRI7OlBGF1h+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫฬู๊ะัࠣห้้ไ๋ࠢ็ะ๊๐ูࠡษ็วัําสࠢ࠽ࠤࠬྡ")
	OfRCSj6pJutMzLsPUE += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(len(WVsjCGB30i52Y[IlL8ZnX74Yvep(u"࠷ᄜ"):]))+kjd9LyNqQHMUevZiRI7OlBGF1h+JGwsL21ZRlqSrWxEmF(u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪྡྷ")
	for wziCR1x4XQEAOB9U6KfGJYmTHl8,gMXJ1uE2flZASBm6jYhspTnIe in WVsjCGB30i52Y[rNyT0edugn(u"࠸ᄝ"):]:
		wziCR1x4XQEAOB9U6KfGJYmTHl8 = L5xKSr96JmaX7N(wziCR1x4XQEAOB9U6KfGJYmTHl8)
		wziCR1x4XQEAOB9U6KfGJYmTHl8 = wziCR1x4XQEAOB9U6KfGJYmTHl8.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(kb2icmDGVUZfW1OFz7sv(u"࠭ࠠ࠯ࠩྣ"))
		OfRCSj6pJutMzLsPUE += wziCR1x4XQEAOB9U6KfGJYmTHl8+rNyT0edugn(u"ࠧ࠻ࠢࠪྤ")+Whef0cxB2iR93SC5IwUtk+str(gMXJ1uE2flZASBm6jYhspTnIe)+kjd9LyNqQHMUevZiRI7OlBGF1h+xY4icgQUj6mPVs73CTKu(u"ࠨࠢࠣࠤࠬྥ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(jR6zDwah317HeVoiyJgqFMrIE4OYs)+kjd9LyNqQHMUevZiRI7OlBGF1h+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧྦ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(BPSHjkE07pTbmZ9gUfxn8R23)+kjd9LyNqQHMUevZiRI7OlBGF1h+QQHFtjcaR2VpnSyTIv(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡสส๎ะ๎ๆࠡ࠼ࠣࠫྦྷ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(jjHwLq5E7g1CrlU3)+kjd9LyNqQHMUevZiRI7OlBGF1h+JGwsL21ZRlqSrWxEmF(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼ࠤ࠿ࠦࠧྨ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(Fr9lM6HZpdT3KgjCPJ7Uzt)+kjd9LyNqQHMUevZiRI7OlBGF1h+R3lezw8h407ZvrAFxT(u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩྩ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(ooRteEw6H2za3Gb8y4BMDfUYvS)+kjd9LyNqQHMUevZiRI7OlBGF1h+vju3SZDWL4ENYelmBOzUqrogp2(u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬྪ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+str(len(FbISGJ0NkOzEKAyjWY))+kjd9LyNqQHMUevZiRI7OlBGF1h+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧะ๊็ࠤูเไหࠢไ๎ิ๐่่ษอࠤ࠿ࠦࠧྫ")
	dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n += HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࡞ࡱࡠࡳ࠭ྫྷ")+tRvLHWy5dnlVFu6xs1p
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(lrtFSogC8Nh9(u"ࠩࡦࡩࡳࡺࡥࡳࠩྭ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪ฽ิีࠠศๆฦะ์ุษࠡษ็ฮ๏ࠦวิฬัำ๊ะ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪྮ"),OfRCSj6pJutMzLsPUE,R3lezw8h407ZvrAFxT(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧྯ"))
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬྰ"),HVmIrFwau90jQsgiWzExk(u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧྱ"),dC3WlOFAIrGXi8ymEgj5HYPNk2Lz1n,kb2icmDGVUZfW1OFz7sv(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪྲ"))
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(NOrchaEV1iIZ87Uzlwgum(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨླ"),OOkmZiVcfqlEurM1dHGb(u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬྴ"),ZyfMTYE9AsubJH6,IlL8ZnX74Yvep(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ྵ"))
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(lRP6GTaZJA1Xw3egLM4(u"ࠫࡱ࡫ࡦࡵࠩྶ"),R3lezw8h407ZvrAFxT(u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐ࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤฬูสฯั่ฮࠥอไษำ้ห๊าࠧྷ"),MWX39d1VjgqPaftLAwUD8orJc,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧྸ"))
	return
def ZI1SjsYWefGiqXaVRm3AN():
	JzNoqV8ClRD6O = lNTJCZeBicWEz0Mg(u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯ࠩྐྵ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+QQHFtjcaR2VpnSyTIv(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧྺ")+kjd9LyNqQHMUevZiRI7OlBGF1h+HVmIrFwau90jQsgiWzExk(u"ࠩ࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣวํࠦสฮ็ํ่์ࠦๅ็࡞ࡱࠫྻ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲࠫྼ")+kjd9LyNqQHMUevZiRI7OlBGF1h+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫ྽")
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ྾"),NOrchaEV1iIZ87Uzlwgum(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ྿"),JzNoqV8ClRD6O,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿀"))
	return
def AqZG1KQcdsrR9zo4OgextNwM():
	JzNoqV8ClRD6O = JGwsL21ZRlqSrWxEmF(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭࿁")+B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+xKp3jkIvM09AZ4euXa87i5TVtfUD[JGwsL21ZRlqSrWxEmF(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ࿂")][e8XhbyuzvjYkIsJUtB5w]+kjd9LyNqQHMUevZiRI7OlBGF1h+Tzx81Wb0RZC4ID5AyiU2(u"ࠪࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣࠫ࿃")+Whef0cxB2iR93SC5IwUtk+xKp3jkIvM09AZ4euXa87i5TVtfUD[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ࿄")][llxMLe4gobHhsj1WGvd7qmIU]+kjd9LyNqQHMUevZiRI7OlBGF1h
	JzNoqV8ClRD6O += WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬ࿅")+Whef0cxB2iR93SC5IwUtk+xKp3jkIvM09AZ4euXa87i5TVtfUD[Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡓࡐࡗࡕࡇࡊ࡙࿆ࠧ")][llxMLe4gobHhsj1WGvd7qmIU]+kjd9LyNqQHMUevZiRI7OlBGF1h
	JzNoqV8ClRD6O += Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪ࿇")+B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+xKp3jkIvM09AZ4euXa87i5TVtfUD[fOc18oTm5hsdD4pVZQj(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ࿈")][cCRvAuJQfjBpTg0PbYiaNO87]+kjd9LyNqQHMUevZiRI7OlBGF1h
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(eGW7cI6aQhr0(u"ࠩࡦࡩࡳࡺࡥࡳࠩ࿉"),NOrchaEV1iIZ87Uzlwgum(u"ࠪห้๋่ศไ฼ࠤฬ๊ัิ็ํอ๊ࠥศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࿊"),JzNoqV8ClRD6O,hCm2fnEXs6Zt(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ࿋"))
	return
def bQ7JWcP6NYfAXo9shkDUgK3S(llf4QxeOjKuvoRYIDyCz):
	ACOWB6GRmIbDKyl3Zn.executebuiltin(HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫࠫ࿌")+llf4QxeOjKuvoRYIDyCz+Hlp3z0APt1GR4kMYK5xST(u"࠭ࠩࠨ࿍"), k6apiPAlLKM1ed8J42RjHh0o)
	return
def mgwjkqxKZcSa2Ofd5EJ():
	vyQfmxGsUX5BSM7Hzq2lEdb6j(gniNItGL6bKwpEW(u"ࠧࡴࡶࡲࡴࠬ࿎"))
	ACOWB6GRmIbDKyl3Zn.executebuiltin(xY4icgQUj6mPVs73CTKu(u"ࠣࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡌࡲࡹ࡫ࡲࡧࡣࡦࡩࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠯ࠢ࿏"))
	return
def Rt6YElvDOzxp0UqJIo5cXNFmdL():
	ACOWB6GRmIbDKyl3Zn.executebuiltin(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠩࠨ࿐"), k6apiPAlLKM1ed8J42RjHh0o)
	return
def FOadCTG5zvKu9():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿑"),fOc18oTm5hsdD4pVZQj(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫ࿒"))
	return
def TTqocZXWd73KGkb():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿓"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ࿔"))
	return
def TAayl1jpmQFwCienqZcV8hJ2t(ppCAtOiLuUSM4=lRP6GTaZJA1Xw3egLM4(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭࿕"),showDialogs=k6apiPAlLKM1ed8J42RjHh0o):
	F5cKwEogkz64f0 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(R3lezw8h407ZvrAFxT(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ࿖"))
	data = O3OogF1l5reuQ.loads(F5cKwEogkz64f0)
	SSdf03Om9EeHWJPAvYo = data[eGW7cI6aQhr0(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ࿗")][vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡺࡦࡲࡵࡦࠩ࿘")]
	if QBp28giCnayJzmZH6vYO: SSdf03Om9EeHWJPAvYo = SSdf03Om9EeHWJPAvYo.encode(YRvPKe2zMTDs8UCkr)
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࿙"),V0VZk9763fusTReHFo4(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪ࿚")+SSdf03Om9EeHWJPAvYo+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨ࿛")+ppCAtOiLuUSM4+kb2icmDGVUZfW1OFz7sv(u"ࠧࠡมࠤࠫ࿜"))
		if TT32BcvomhVewpgMSWkEb46y7xqO!=Tzx81Wb0RZC4ID5AyiU2(u"࠱ᄞ"): return f4vncKMRlXG9s
	PsKJk8XRHAQM,DMjbhEY9ACkl7vPmyx3OW,vn3p2OgR4caMoNAbf5C8 = mnl7HeqUVKxEAOc(ppCAtOiLuUSM4,f4vncKMRlXG9s,f4vncKMRlXG9s)
	if PsKJk8XRHAQM:
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿝"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫ࿞"))
		ZB3WgSanUwV = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧ࿟")+ppCAtOiLuUSM4+IlL8ZnX74Yvep(u"ࠫࠧࢃࡽࠨ࿠"))
		PsKJk8XRHAQM = k6apiPAlLKM1ed8J42RjHh0o if rNyT0edugn(u"ࠬࡕࡋࠨ࿡") in ZB3WgSanUwV else f4vncKMRlXG9s
		XJ62UBRmIqFvfiNTQj.sleep(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠲ᄟ"))
		ACOWB6GRmIbDKyl3Zn.executebuiltin(eGW7cI6aQhr0(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭࿢"))
	elif showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࿣"),lNTJCZeBicWEz0Mg(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪ࿤"))
	return PsKJk8XRHAQM
def H5NMrlI8fGj1cz0dpnPtxAoQ4h2KT():
	url = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧ࿥")
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡋࡊ࡚ࠧ࿦"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡉࡑ࡚ࡣࡑࡇࡔࡆࡕࡗࡣࡐࡕࡄࡊࡡ࡙ࡉࡗ࡙ࡉࡐࡐ࠰࠵ࡸࡺࠧ࿧"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	L7dtCKSw9Jq = YYqECUofyi7wFrW.findall(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡺࡩࡵ࡮ࡨࡁࠧࡱ࡯ࡥ࡫࠰ࠬࡡࡪࠫ࡝࠰࡟ࡨ࠰࠳࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠫ࠰ࠫ࿨"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	L7dtCKSw9Jq = L7dtCKSw9Jq[e8XhbyuzvjYkIsJUtB5w].split(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࠭ࠨ࿩"))[e8XhbyuzvjYkIsJUtB5w]
	Rdl3ky4Ju2VtvMIH1iePnrm = str(kQI947MebLovYyVE08F5qPi6fj3)
	MWX39d1VjgqPaftLAwUD8orJc = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ศิ๊าࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ࿪")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+L7dtCKSw9Jq+kjd9LyNqQHMUevZiRI7OlBGF1h
	MWX39d1VjgqPaftLAwUD8orJc += OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࡞ࡱࡠࡳ࠭࿫")+QQHFtjcaR2VpnSyTIv(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨ࿬")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+Rdl3ky4Ju2VtvMIH1iePnrm+kjd9LyNqQHMUevZiRI7OlBGF1h
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿭"),MWX39d1VjgqPaftLAwUD8orJc)
	return
def zq7dBPs3CGxE4SijYV():
	Kh4DWp8sCnZGOqLNv67P19ba,TszoWDY6kwF2dv,JC2eTK8kOvZLryB = f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	zUw4pfbNtkrLS3,hjT7xISNCRef6ZJ,IyPLzAUNTwQVEmk4FSxi = f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	eCxtLjbwW1s = [wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ࿮"),hCm2fnEXs6Zt(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ࿯"),eGW7cI6aQhr0(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ࿰")]
	YYrKb4X8nZvo93BqaeJDt17 = E59vQkcMrwq0sBoeDUYClgG2St1(eCxtLjbwW1s)
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in eCxtLjbwW1s:
		if b0VaRYkgC4iOvHpmdeyzcQISJEsx not in list(YYrKb4X8nZvo93BqaeJDt17.keys()): continue
		ll83YbWxpZUkyBCnqeAv,Awb7WLOVQ4pCvcqxekRSJyMzi6t1,elhtxB482CfwzXbyvmEHnZUkjLMG6Y,EQM4cO7NhSku,Tam7elMYFwqCdh9,OI4JC6i8QscuSPgjGWTlxqyZpwDRM,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf = YYrKb4X8nZvo93BqaeJDt17[b0VaRYkgC4iOvHpmdeyzcQISJEsx]
		if b0VaRYkgC4iOvHpmdeyzcQISJEsx==lNTJCZeBicWEz0Mg(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ࿱"):
			zUw4pfbNtkrLS3 = ll83YbWxpZUkyBCnqeAv
			hjT7xISNCRef6ZJ = Awb7WLOVQ4pCvcqxekRSJyMzi6t1+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨ࿲")+P02oGj7X8m5uMz6VUCScZbDnLp4fR(OI4JC6i8QscuSPgjGWTlxqyZpwDRM)+eGW7cI6aQhr0(u"ࠩࠣ࠭ࠬ࿳")
			IyPLzAUNTwQVEmk4FSxi = EQM4cO7NhSku
		elif b0VaRYkgC4iOvHpmdeyzcQISJEsx==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ࿴"):
			Kh4DWp8sCnZGOqLNv67P19ba = Kh4DWp8sCnZGOqLNv67P19ba or ll83YbWxpZUkyBCnqeAv
			TszoWDY6kwF2dv += V0VZk9763fusTReHFo4(u"ࠫࠥࠦࠬࠡࠢࠪ࿵")+Awb7WLOVQ4pCvcqxekRSJyMzi6t1+eGW7cI6aQhr0(u"ࠬࠦࠠࠡࠢࠫࠤࠬ࿶")+P02oGj7X8m5uMz6VUCScZbDnLp4fR(OI4JC6i8QscuSPgjGWTlxqyZpwDRM)+V0VZk9763fusTReHFo4(u"࠭ࠠࠪࠩ࿷")
			JC2eTK8kOvZLryB += YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࠡࠢ࠯ࠤࠥ࠭࿸")+EQM4cO7NhSku
		elif b0VaRYkgC4iOvHpmdeyzcQISJEsx==NOrchaEV1iIZ87Uzlwgum(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ࿹"):
			mb6VM9jw1divpPBA = ll83YbWxpZUkyBCnqeAv
			js0SfmIvKuz6o = Awb7WLOVQ4pCvcqxekRSJyMzi6t1+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࠣࠤࠥࠦࠨࠡࠩ࿺")+P02oGj7X8m5uMz6VUCScZbDnLp4fR(OI4JC6i8QscuSPgjGWTlxqyZpwDRM)+V0VZk9763fusTReHFo4(u"ࠪࠤ࠮࠭࿻")
			fCIpEulPDnKqaF = EQM4cO7NhSku
	TszoWDY6kwF2dv = TszoWDY6kwF2dv.strip(xY4icgQUj6mPVs73CTKu(u"ࠫࠥࠦࠬࠡࠢࠪ࿼"))
	JC2eTK8kOvZLryB = JC2eTK8kOvZLryB.strip(HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦࠠ࠭ࠢࠣࠫ࿽"))
	YCzrbTZDI8HA1XJgS0Lpum  = LtGoXlQ2IYxqTJRySE6udfW98(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ࿾")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+IyPLzAUNTwQVEmk4FSxi+kjd9LyNqQHMUevZiRI7OlBGF1h
	YCzrbTZDI8HA1XJgS0Lpum += B6IrC7zEHlw1oaeWf+rNyT0edugn(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩ࿿")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+hjT7xISNCRef6ZJ+kjd9LyNqQHMUevZiRI7OlBGF1h
	YCzrbTZDI8HA1XJgS0Lpum += rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨ࡞ࡱࡠࡳ࠭က")+lRP6GTaZJA1Xw3egLM4(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่ืฯ๎ฯฺࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧခ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+JC2eTK8kOvZLryB+kjd9LyNqQHMUevZiRI7OlBGF1h
	YCzrbTZDI8HA1XJgS0Lpum += B6IrC7zEHlw1oaeWf+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬဂ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+TszoWDY6kwF2dv+kjd9LyNqQHMUevZiRI7OlBGF1h
	YCzrbTZDI8HA1XJgS0Lpum += hCm2fnEXs6Zt(u"ࠫࡡࡴ࡜࡯ࠩဃ")+V0VZk9763fusTReHFo4(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩင")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+fCIpEulPDnKqaF+kjd9LyNqQHMUevZiRI7OlBGF1h
	YCzrbTZDI8HA1XJgS0Lpum += B6IrC7zEHlw1oaeWf+YJpWv4QzC7sx8INVPukeZiOD03K(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧစ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+js0SfmIvKuz6o+kjd9LyNqQHMUevZiRI7OlBGF1h
	ll83YbWxpZUkyBCnqeAv = zUw4pfbNtkrLS3 or Kh4DWp8sCnZGOqLNv67P19ba
	if ll83YbWxpZUkyBCnqeAv:
		header = eGW7cI6aQhr0(u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩဆ")
		RM17uFVste3pJLBhjcn = hCm2fnEXs6Zt(u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠩဇ")
	else:
		header = xY4icgQUj6mPVs73CTKu(u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪဈ")
		RM17uFVste3pJLBhjcn = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬဉ")
	Mh2DG8WpkNXSO1arKLi = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬည")
	x2yfZGRC8F7 = YCzrbTZDI8HA1XJgS0Lpum+QQHFtjcaR2VpnSyTIv(u"ࠬࡢ࡮࡝ࡰࠪဋ")+RM17uFVste3pJLBhjcn+Tzx81Wb0RZC4ID5AyiU2(u"࠭࡜࡯࡞ࡱࠫဌ")+Mh2DG8WpkNXSO1arKLi
	cGY04x76XBKoQWJg9R5d2pkIvOsTFD(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ဍ"),header,x2yfZGRC8F7,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫဎ"))
	return ll83YbWxpZUkyBCnqeAv
def ePcCVZf6n5m(b0VaRYkgC4iOvHpmdeyzcQISJEsx,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf,showDialogs):
	PsKJk8XRHAQM = f4vncKMRlXG9s
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬဏ"),eGW7cI6aQhr0(u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆุ฽์฼ࠦไๅวูหๆฯࠠศๆ่฻้๎ศสࠢ็็๏๊ࠦห็ࠣฮะฮ๊ห้ࠣ฽้๏ࠠไ๊า๎ࠥ࠴ࠠศๆ่่ๆࠦโะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥอไร่ࠣรࠦ࠭တ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO!=llxMLe4gobHhsj1WGvd7qmIU: return f4vncKMRlXG9s
	qqOdPKSIpCL = VCoIxDK8uGJv(Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf,{},showDialogs)
	if qqOdPKSIpCL:
		BzW2ZRf5bqVsM = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ywv5SRh6Nxj,b0VaRYkgC4iOvHpmdeyzcQISJEsx)
		vWN2YePRikAXEFO6dQ8CT51bz(BzW2ZRf5bqVsM,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
		import zipfile as TZAqhHw8gmEtFvLJ,io as qdBtLoiZlNIe40FRn1TCvAX67k
		rGhlIMA3sTS8q = qdBtLoiZlNIe40FRn1TCvAX67k.BytesIO(qqOdPKSIpCL)
		try:
			J9736RKDQoZbXGxP8r5tLdlCHg1nqU = TZAqhHw8gmEtFvLJ.ZipFile(rGhlIMA3sTS8q)
			J9736RKDQoZbXGxP8r5tLdlCHg1nqU.extractall(ywv5SRh6Nxj)
			XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
			ACOWB6GRmIbDKyl3Zn.executebuiltin(JGwsL21ZRlqSrWxEmF(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨထ"))
			XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
			PsKJk8XRHAQM = vykWitsw8g(b0VaRYkgC4iOvHpmdeyzcQISJEsx)
		except: PsKJk8XRHAQM = f4vncKMRlXG9s
	if showDialogs:
		if PsKJk8XRHAQM: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨဒ"),NeU6uRGpECkvMV5jf(u"࠭สๆࠢห๊ัออࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪဓ"))
		else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪန"),NeU6uRGpECkvMV5jf(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ပ"))
	return PsKJk8XRHAQM
def aV1HYqMRxUA3vmOr8LnGofj0FI5C7(b0VaRYkgC4iOvHpmdeyzcQISJEsx,showDialogs=k6apiPAlLKM1ed8J42RjHh0o):
	if showDialogs==NdKhAS6MXVEORLTwob92pxlZ: showDialogs = k6apiPAlLKM1ed8J42RjHh0o
	sG5jgAF79ce8E = lwgJtprMozU8hq0YR7m6WLOjnDI321([b0VaRYkgC4iOvHpmdeyzcQISJEsx])
	zvwId89gRhCKce0BDt6TVYaFiM,B1nCuIcRs2j9 = sG5jgAF79ce8E[b0VaRYkgC4iOvHpmdeyzcQISJEsx]
	if B1nCuIcRs2j9:
		PsKJk8XRHAQM = k6apiPAlLKM1ed8J42RjHh0o
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬဖ"),V0VZk9763fusTReHFo4(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬဗ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+Tzx81Wb0RZC4ID5AyiU2(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧဘ"))
	else:
		PsKJk8XRHAQM = f4vncKMRlXG9s
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(HVmIrFwau90jQsgiWzExk(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬမ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩယ"),NdKhAS6MXVEORLTwob92pxlZ+b0VaRYkgC4iOvHpmdeyzcQISJEsx+xY4icgQUj6mPVs73CTKu(u"ࠧࠡ࡞ࡱࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ๎วๅสิ๊ฬ๋ฬࠡสะหัฯࠠๅ้สࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫရ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO==HHvYL68lbJVZWM7tQEzSex3(u"࠳ᄠ"):
			ACOWB6GRmIbDKyl3Zn.executebuiltin(V0VZk9763fusTReHFo4(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨလ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+JGwsL21ZRlqSrWxEmF(u"ࠩࠬࠫဝ"))
			XJ62UBRmIqFvfiNTQj.sleep(NOrchaEV1iIZ87Uzlwgum(u"࠴ᄡ"))
			ACOWB6GRmIbDKyl3Zn.executebuiltin(NOrchaEV1iIZ87Uzlwgum(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪသ"))
			XJ62UBRmIqFvfiNTQj.sleep(QQHFtjcaR2VpnSyTIv(u"࠵ᄢ"))
			while ACOWB6GRmIbDKyl3Zn.getCondVisibility(gniNItGL6bKwpEW(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨဟ")): XJ62UBRmIqFvfiNTQj.sleep(gniNItGL6bKwpEW(u"࠶ᄣ"))
			PsKJk8XRHAQM = vykWitsw8g(b0VaRYkgC4iOvHpmdeyzcQISJEsx)
			if showDialogs and PsKJk8XRHAQM: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨဠ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠭สๆࠢไัฺࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭အ"))
			elif showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪဢ"),IlL8ZnX74Yvep(u"ࠨใื่ࠥ็๊ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯࠠ࠯๋ࠢห้ำไ้๋ࠡࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๆ่ࠣาฬืฬࠡษ็ฬึ์วๆฮࠪဣ"))
	return PsKJk8XRHAQM
def vvgOIsoaZnwEXKRh29ui(showDialogs):
	if not showDialogs: TT32BcvomhVewpgMSWkEb46y7xqO = k6apiPAlLKM1ed8J42RjHh0o
	else: TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡦࡩࡳࡺࡥࡳࠩဤ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ဥ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠษ฻่่๏ฯࠠหฯา๎ะࠦฬๆ์฼ࠤฬ๊ลืษไหฯࠦสๅไสส๏อࠠไๆࠣ࠶࠹ࠦำศ฻ฬࠤํ๊ใ็่้่ࠢ์ࠠฦฮิหฦํวࠡษ็ฦ๋ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠฤ่ࠣฮ฼๊ศࠡ็้ࠤ่๎ฯ๋ࠢไัฺ่ࠦหฯา๎ะࠦฬๆ์฼ࠤฬ๊ลืษไหฯࠦฟࠨဦ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==rNyT0edugn(u"࠷ᄤ"):
		ACOWB6GRmIbDKyl3Zn.executebuiltin(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࡛ࠬࡰࡥࡣࡷࡩࡆࡪࡤࡰࡰࡕࡩࡵࡵࡳࠨဧ"))
		if showDialogs:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩဨ"),R3lezw8h407ZvrAFxT(u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧဩ"))
	return
def PaA9seqk5wpFI1lDKtonb8h2():
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,NeU6uRGpECkvMV5jf(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫဪ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪါ"))
	H5NMrlI8fGj1cz0dpnPtxAoQ4h2KT()
	ll83YbWxpZUkyBCnqeAv = zq7dBPs3CGxE4SijYV()
	if ll83YbWxpZUkyBCnqeAv:
		uuKwU7AkCmnMylP8gqsdeHxLb5i(k6apiPAlLKM1ed8J42RjHh0o)
		vvgOIsoaZnwEXKRh29ui(k6apiPAlLKM1ed8J42RjHh0o)
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def vykWitsw8g(b0VaRYkgC4iOvHpmdeyzcQISJEsx):
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(NeU6uRGpECkvMV5jf(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ာ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩိ"))
	succeeded = k6apiPAlLKM1ed8J42RjHh0o if Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡕࡋࠨီ") in UEsxyfd8rZMLOHgzc6emSFKD0ktYiT else f4vncKMRlXG9s
	return succeeded
def AutzO5eZQHMI3djo8bNSYm7FsRpf2(b0VaRYkgC4iOvHpmdeyzcQISJEsx):
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(Hlp3z0APt1GR4kMYK5xST(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩု")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+hCm2fnEXs6Zt(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭ူ"))
	succeeded = k6apiPAlLKM1ed8J42RjHh0o if OOkmZiVcfqlEurM1dHGb(u"ࠨࡑࡎࠫေ") in UEsxyfd8rZMLOHgzc6emSFKD0ktYiT else f4vncKMRlXG9s
	return succeeded
def mnl7HeqUVKxEAOc(b0VaRYkgC4iOvHpmdeyzcQISJEsx,showDialogs,xdCQR5pM7cV81XwUFoH,YYrKb4X8nZvo93BqaeJDt17=None):
	TT32BcvomhVewpgMSWkEb46y7xqO,succeeded,DMjbhEY9ACkl7vPmyx3OW,Awb7WLOVQ4pCvcqxekRSJyMzi6t1 = k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩဲ"),NdKhAS6MXVEORLTwob92pxlZ
	if not YYrKb4X8nZvo93BqaeJDt17: YYrKb4X8nZvo93BqaeJDt17 = E59vQkcMrwq0sBoeDUYClgG2St1([b0VaRYkgC4iOvHpmdeyzcQISJEsx])
	if b0VaRYkgC4iOvHpmdeyzcQISJEsx in list(YYrKb4X8nZvo93BqaeJDt17.keys()):
		ll83YbWxpZUkyBCnqeAv,Awb7WLOVQ4pCvcqxekRSJyMzi6t1,elhtxB482CfwzXbyvmEHnZUkjLMG6Y,EQM4cO7NhSku,Tam7elMYFwqCdh9,OI4JC6i8QscuSPgjGWTlxqyZpwDRM,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf = YYrKb4X8nZvo93BqaeJDt17[b0VaRYkgC4iOvHpmdeyzcQISJEsx]
		if OI4JC6i8QscuSPgjGWTlxqyZpwDRM==JGwsL21ZRlqSrWxEmF(u"ࠪ࡫ࡴࡵࡤࠨဳ"):
			succeeded,DMjbhEY9ACkl7vPmyx3OW = k6apiPAlLKM1ed8J42RjHh0o,Hlp3z0APt1GR4kMYK5xST(u"ࠫࡳࡵࡴࡩ࡫ࡱ࡫ࠬဴ")
			if xdCQR5pM7cV81XwUFoH and showDialogs:
				TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨဵ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ံ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+JGwsL21ZRlqSrWxEmF(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา့๋ࠪ"))
				if TT32BcvomhVewpgMSWkEb46y7xqO:
					succeeded = ePcCVZf6n5m(b0VaRYkgC4iOvHpmdeyzcQISJEsx,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf,f4vncKMRlXG9s)
					if succeeded:
						DMjbhEY9ACkl7vPmyx3OW = R3lezw8h407ZvrAFxT(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭း")
						if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ္ࠬ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅ้ฮ๋ำฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหษ฾อฯสࠢอฯอ๐ส่ษ࡟ࡲࡡࡴ်ࠧ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
					else:
						DMjbhEY9ACkl7vPmyx3OW = Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫျ")
						ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨြ"),lrtFSogC8Nh9(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ွ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
		else:
			if showDialogs:
				if OI4JC6i8QscuSPgjGWTlxqyZpwDRM==JGwsL21ZRlqSrWxEmF(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩှ"): JzNoqV8ClRD6O = JGwsL21ZRlqSrWxEmF(u"ࠨ็อ์็็ษࠨဿ")
				elif OI4JC6i8QscuSPgjGWTlxqyZpwDRM==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡲࡰࡩ࠭၀"): JzNoqV8ClRD6O = rNyT0edugn(u"ࠪๆิ๐ๅสࠩ၁")
				elif OI4JC6i8QscuSPgjGWTlxqyZpwDRM==Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ၂"): JzNoqV8ClRD6O = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬเ๊า่ࠢฯอะษࠨ၃")
				TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ၄"),YJpWv4QzC7sx8INVPukeZiOD03K(u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭၅")+JzNoqV8ClRD6O+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪ၆")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
			if not TT32BcvomhVewpgMSWkEb46y7xqO: DMjbhEY9ACkl7vPmyx3OW = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ၇")
			else:
				if OI4JC6i8QscuSPgjGWTlxqyZpwDRM==lrtFSogC8Nh9(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ၈"):
					succeeded = vykWitsw8g(b0VaRYkgC4iOvHpmdeyzcQISJEsx)
					if succeeded:
						DMjbhEY9ACkl7vPmyx3OW = PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬ၉")
						if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ၊"),V0VZk9763fusTReHFo4(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫ။")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
					elif showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ၌"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫ၍")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
				elif OI4JC6i8QscuSPgjGWTlxqyZpwDRM in [HVmIrFwau90jQsgiWzExk(u"ࠩࡲࡰࡩ࠭၎"),lNTJCZeBicWEz0Mg(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ၏")]:
					succeeded = ePcCVZf6n5m(b0VaRYkgC4iOvHpmdeyzcQISJEsx,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf,f4vncKMRlXG9s)
					if succeeded:
						if OI4JC6i8QscuSPgjGWTlxqyZpwDRM==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡴࡲࡤࠨၐ"): DMjbhEY9ACkl7vPmyx3OW = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ၑ")
						elif OI4JC6i8QscuSPgjGWTlxqyZpwDRM==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧၒ"): DMjbhEY9ACkl7vPmyx3OW = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪၓ")
						Awb7WLOVQ4pCvcqxekRSJyMzi6t1 = EQM4cO7NhSku
						if showDialogs:
							if DMjbhEY9ACkl7vPmyx3OW==HVmIrFwau90jQsgiWzExk(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩၔ"): ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၕ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦโะ์่อࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอัิ๐ห่ษ࡟ࡲࡡࡴࠧၖ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
							elif DMjbhEY9ACkl7vPmyx3OW==kb2icmDGVUZfW1OFz7sv(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧၗ"): ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨၘ"),JGwsL21ZRlqSrWxEmF(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧၙ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
					elif showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၚ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫၛ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
	elif showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၜ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨၝ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
	return succeeded,DMjbhEY9ACkl7vPmyx3OW,Awb7WLOVQ4pCvcqxekRSJyMzi6t1
def T5BXLUGacv4KuN1oHf0Swe(b0VaRYkgC4iOvHpmdeyzcQISJEsx,showDialogs,eNtjnPFICVx05):
	W0WgJmw8TDBdXnueVtGU6Ksj = moKCtu35ZJgji1UXIS0srpELB.connect(F9yN4TRdQclxaBGWt6rpSKwkJ)
	W0WgJmw8TDBdXnueVtGU6Ksj.text_factory = str
	ODXQpWsKqya39FEctSmlRJ84rkM7vI = W0WgJmw8TDBdXnueVtGU6Ksj.cursor()
	succeeded,llCcMXPHNI23jUS = k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s
	try:
		FFu3vphMQAUrOHm = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ၞ")
		ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(NOrchaEV1iIZ87Uzlwgum(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪၟ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+V0VZk9763fusTReHFo4(u"࠭ࠢࠡ࠽ࠪၠ"))
		r2EUDqT1KdNxH = ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()
		if r2EUDqT1KdNxH and FFu3vphMQAUrOHm not in str(r2EUDqT1KdNxH): ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(eGW7cI6aQhr0(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫၡ")+FFu3vphMQAUrOHm+eGW7cI6aQhr0(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧၢ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+NOrchaEV1iIZ87Uzlwgum(u"ࠩࠥࠤࡀ࠭ၣ"))
		j6lBaoXC3ig7rJyIMf1z = Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ၤ") if QBp28giCnayJzmZH6vYO else lrtFSogC8Nh9(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪၥ")
		ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ၦ")+j6lBaoXC3ig7rJyIMf1z+LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫၧ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+Hlp3z0APt1GR4kMYK5xST(u"ࠧࠣࠢ࠾ࠫၨ"))
		r2EUDqT1KdNxH = ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()
		if r2EUDqT1KdNxH:
			if showDialogs: TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫၩ"),gniNItGL6bKwpEW(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ၪ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࠤࡡࡴ࡜࡯ࠢࠪၫ")+Whef0cxB2iR93SC5IwUtk+PzIpQnUXxRwNCivDhdakWTE(u"๋ࠫࠥส้ไไࠤํ๊วࠡ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ၬ")+kjd9LyNqQHMUevZiRI7OlBGF1h+rNyT0edugn(u"ࠬࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪၭ"))
			else: TT32BcvomhVewpgMSWkEb46y7xqO = llxMLe4gobHhsj1WGvd7qmIU
			if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU:
				llCcMXPHNI23jUS = k6apiPAlLKM1ed8J42RjHh0o
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(fOc18oTm5hsdD4pVZQj(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬၮ")+j6lBaoXC3ig7rJyIMf1z+JGwsL21ZRlqSrWxEmF(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬၯ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+lNTJCZeBicWEz0Mg(u"ࠨࠤࠣ࠿ࠬၰ"))
		elif eNtjnPFICVx05:
			if showDialogs: TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၱ"),fOc18oTm5hsdD4pVZQj(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧၲ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫၳ")+Whef0cxB2iR93SC5IwUtk+NeU6uRGpECkvMV5jf(u"ࠬࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢࠪၴ")+kjd9LyNqQHMUevZiRI7OlBGF1h+rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥะแฺ์็๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫၵ"))
			else: TT32BcvomhVewpgMSWkEb46y7xqO = llxMLe4gobHhsj1WGvd7qmIU
			if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU:
				llCcMXPHNI23jUS = k6apiPAlLKM1ed8J42RjHh0o
				if QBp28giCnayJzmZH6vYO: ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(rNyT0edugn(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ၶ")+j6lBaoXC3ig7rJyIMf1z+V0VZk9763fusTReHFo4(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨၷ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+R3lezw8h407ZvrAFxT(u"ࠩࠥ࠭ࠥࡁࠧၸ"))
				else: ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(NOrchaEV1iIZ87Uzlwgum(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩၹ")+j6lBaoXC3ig7rJyIMf1z+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨၺ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬၻ"))
	except: succeeded = f4vncKMRlXG9s
	W0WgJmw8TDBdXnueVtGU6Ksj.commit()
	W0WgJmw8TDBdXnueVtGU6Ksj.close()
	if llCcMXPHNI23jUS:
		XJ62UBRmIqFvfiNTQj.sleep(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠱ᄥ"))
		ACOWB6GRmIbDKyl3Zn.executebuiltin(IlL8ZnX74Yvep(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪၼ"))
		XJ62UBRmIqFvfiNTQj.sleep(IlL8ZnX74Yvep(u"࠲ᄦ"))
		if showDialogs:
			if succeeded: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪၽ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ่ฯัฯูࠦๆๆํอࠥหีๅษะࠤฯำฯ๋อࠣห้หึศใฬࠤࡡࡴ࡜࡯ࠩၾ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
			else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၿ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪๅู๊สࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫႀ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx)
	return llCcMXPHNI23jUS
def ij5kzycSfln3WRu71XerIm4(eCxtLjbwW1s,showDialogs,xdCQR5pM7cV81XwUFoH,eNtjnPFICVx05):
	YYrKb4X8nZvo93BqaeJDt17 = E59vQkcMrwq0sBoeDUYClgG2St1(eCxtLjbwW1s)
	GVSCY3kWAMxK = f4vncKMRlXG9s
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in eCxtLjbwW1s:
		succeeded,DMjbhEY9ACkl7vPmyx3OW,Awb7WLOVQ4pCvcqxekRSJyMzi6t1 = mnl7HeqUVKxEAOc(b0VaRYkgC4iOvHpmdeyzcQISJEsx,showDialogs,xdCQR5pM7cV81XwUFoH,YYrKb4X8nZvo93BqaeJDt17)
		llCcMXPHNI23jUS = T5BXLUGacv4KuN1oHf0Swe(b0VaRYkgC4iOvHpmdeyzcQISJEsx,showDialogs,eNtjnPFICVx05)
		if llCcMXPHNI23jUS: GVSCY3kWAMxK = k6apiPAlLKM1ed8J42RjHh0o
	if GVSCY3kWAMxK:
		XJ62UBRmIqFvfiNTQj.sleep(QQHFtjcaR2VpnSyTIv(u"࠳ᄧ"))
		ACOWB6GRmIbDKyl3Zn.executebuiltin(kb2icmDGVUZfW1OFz7sv(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨႁ"))
		XJ62UBRmIqFvfiNTQj.sleep(NeU6uRGpECkvMV5jf(u"࠴ᄨ"))
	if showDialogs:
		if len(eCxtLjbwW1s)>YJpWv4QzC7sx8INVPukeZiOD03K(u"࠵ᄩ"): ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႂ"),V0VZk9763fusTReHFo4(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬႃ"))
		else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႄ"),lrtFSogC8Nh9(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬႅ")+eCxtLjbwW1s[eGW7cI6aQhr0(u"࠵ᄪ")])
	return
def uuKwU7AkCmnMylP8gqsdeHxLb5i(showDialogs):
	zZ2rsdBpH9mkjEuYUec6wCgyI = [hCm2fnEXs6Zt(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧႆ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬႇ"),lrtFSogC8Nh9(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨႈ"),xY4icgQUj6mPVs73CTKu(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬႉ")]
	VyMwWpeBU1G = [xY4icgQUj6mPVs73CTKu(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨႊ"),JGwsL21ZRlqSrWxEmF(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨႋ"),lrtFSogC8Nh9(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫႌ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥႍࠫ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫႎ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨႏ")]
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in VyMwWpeBU1G: AutzO5eZQHMI3djo8bNSYm7FsRpf2(b0VaRYkgC4iOvHpmdeyzcQISJEsx)
	ij5kzycSfln3WRu71XerIm4(zZ2rsdBpH9mkjEuYUec6wCgyI,showDialogs,f4vncKMRlXG9s,f4vncKMRlXG9s)
	return
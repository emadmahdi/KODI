# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'SHIAVOICE'
LJfTAEQPv9h4BXdwUp = '_SHV_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
headers = {'User-Agent':None}
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==310: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==311: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==312: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==313: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ILtiFPlhGwu(url)
	elif mode==314: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = qahUFzc8EDsd0PfVruTSOMKyCoLl1(text)
	elif mode==319: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,319,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="menulinks"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	items = YYqECUofyi7wFrW.findall('<h5>(.*?)</h5>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	for rAknWUHpDyi4IuGPfl2QYR in range(len(items)):
		title = items[rAknWUHpDyi4IuGPfl2QYR].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,314,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,str(rAknWUHpDyi4IuGPfl2QYR+1))
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مقاطع شهر',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,314,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'0')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<B>(.*?)</B>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,311)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def qahUFzc8EDsd0PfVruTSOMKyCoLl1(rAknWUHpDyi4IuGPfl2QYR):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-LATEST-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if rAknWUHpDyi4IuGPfl2QYR=='0':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="tab-content"(.*?)</table>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			title = title+' ('+name+')'
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312)
	elif rAknWUHpDyi4IuGPfl2QYR in ['1','2','3']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(<h5>.*?)<div class="col-lg',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		MYdB6PjntuJzDTW = int(rAknWUHpDyi4IuGPfl2QYR)-1
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[MYdB6PjntuJzDTW]
		if rAknWUHpDyi4IuGPfl2QYR=='1': items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		else: items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title,name in items:
			TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			title = title+' ('+name+')'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,311,TTuPH708dUNnjlG3oQpkZsi)
	elif rAknWUHpDyi4IuGPfl2QYR in ['4','5','6']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(<h5>.*?)</table>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		rAknWUHpDyi4IuGPfl2QYR = int(rAknWUHpDyi4IuGPfl2QYR)-4
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[rAknWUHpDyi4IuGPfl2QYR]
		items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,kLsEevcNpM2dy9mVFljGW,title,RoDOya8x9mcMLZduGkX7YJUQTqI in items:
			TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			kLsEevcNpM2dy9mVFljGW = kLsEevcNpM2dy9mVFljGW.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			RoDOya8x9mcMLZduGkX7YJUQTqI = RoDOya8x9mcMLZduGkX7YJUQTqI.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if kLsEevcNpM2dy9mVFljGW: name = kLsEevcNpM2dy9mVFljGW
			else: name = RoDOya8x9mcMLZduGkX7YJUQTqI
			title = title+' ('+name+')'
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312,TTuPH708dUNnjlG3oQpkZsi)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('ibox-heading"(.*?)class="float-right',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if 'catsum-mobile' in AAMHoYxRCmt2D6ph89W:
		items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if items:
			for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title,count in items:
				TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
				count = count.replace(' الصوتية: ',':')
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				title = title+' ('+count+')'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,311,TTuPH708dUNnjlG3oQpkZsi)
	else:
		items = YYqECUofyi7wFrW.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,QhDaMt8XxcrpHd,TLrSzM98nc2H3VODdyhpQI in items:
			if title==NdKhAS6MXVEORLTwob92pxlZ or QhDaMt8XxcrpHd==NdKhAS6MXVEORLTwob92pxlZ: continue
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title+' ('+TLrSzM98nc2H3VODdyhpQI+')'
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312)
	if not items: vl57jIYC4a(LMKFcEkU1Q7R80yt4OsgvwxbfP)
	return
def vl57jIYC4a(LMKFcEkU1Q7R80yt4OsgvwxbfP):
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="ibox-content"(.*?)class="pagination',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title,name,count,TLrSzM98nc2H3VODdyhpQI in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		title = title+' ('+name+')'
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312,NdKhAS6MXVEORLTwob92pxlZ,TLrSzM98nc2H3VODdyhpQI)
	return
def ILtiFPlhGwu(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-SEARCH_ITEMS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="ibox-content p-1"(.*?)class="ibox-content"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
		return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<strong>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if '/play-' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,311)
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<audio.*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<video.*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij[0]
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(zehVcU893FC6LEd1Aij,yNIDEX5hU4G769,'video')
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	jKLmo6xGCWEMF8O2fzZniaBlrSphgN = ['&t=a','&t=c','&t=s']
	if showDialogs:
		FcMgekHESpf = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('موقع صوت الشيعة - أختر البحث', FcMgekHESpf)
		if rRfpvbZojlygET5JL87wdzIPGe == -1: return
	elif '_SHIAVOICE-PERSONS_' in LM1WpcGdrz8QtHV0i53k: rRfpvbZojlygET5JL87wdzIPGe = 0
	elif '_SHIAVOICE-ALBUMS_' in LM1WpcGdrz8QtHV0i53k: rRfpvbZojlygET5JL87wdzIPGe = 1
	elif '_SHIAVOICE-AUDIOS_' in LM1WpcGdrz8QtHV0i53k: rRfpvbZojlygET5JL87wdzIPGe = 2
	else: return
	type = jKLmo6xGCWEMF8O2fzZniaBlrSphgN[rRfpvbZojlygET5JL87wdzIPGe]
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search.php?q='+search+type
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHIAVOICE-SEARCH-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="ibox-content"(.*?)class="ibox-content"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		if rRfpvbZojlygET5JL87wdzIPGe in [0,1]:
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title,name in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				title = title+' ('+name+')'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,313,TTuPH708dUNnjlG3oQpkZsi)
		elif rRfpvbZojlygET5JL87wdzIPGe==2:
			items = YYqECUofyi7wFrW.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title,name in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				title = title+' ('+name+')'
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,312)
	return
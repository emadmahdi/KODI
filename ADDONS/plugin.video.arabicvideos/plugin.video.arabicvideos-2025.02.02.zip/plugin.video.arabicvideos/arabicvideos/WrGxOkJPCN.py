# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'SHAHID4U'
LJfTAEQPv9h4BXdwUp = '_SH4_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
headers = {'User-Agent':kkCjlxiynwT34GVFc(True)}
Kdr54yMqbjTSX7piWREfPtZ2em = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==110: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==111: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==112: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==113: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url,True)
	elif mode==114: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'FULL_FILTER___'+text)
	elif mode==115: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'DEFINED_FILTER___'+text)
	elif mode==116: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url,False)
	elif mode==119: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(VNc1u4edS90FK5W6bsMgQC2B.url,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,119,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',REGxsWAoilB7dCFNgMhz0V98bcm,115)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',REGxsWAoilB7dCFNgMhz0V98bcm,114)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',REGxsWAoilB7dCFNgMhz0V98bcm,111,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('simple-filter(.*?)adv-filter',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for filter,TTuPH708dUNnjlG3oQpkZsi,title in items:
			url = REGxsWAoilB7dCFNgMhz0V98bcm+filter
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,url,111,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,filter)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="dropdown"(.*?)<script>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
			if 'netflix' in zehVcU893FC6LEd1Aij: title = 'نيتفلكس'
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,111)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ,VNc1u4edS90FK5W6bsMgQC2B=NdKhAS6MXVEORLTwob92pxlZ):
	if not VNc1u4edS90FK5W6bsMgQC2B: VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6,items,zIDPZSNn1OuweLHvmMKb6d = [],[],[]
	if mfVtpzhI3WGnAx0=='featured': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('glide__slides(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('shows-container(.*?)pagination',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items: items = YYqECUofyi7wFrW.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if 'WWE' in title: continue
		if 'javascript' in zehVcU893FC6LEd1Aij: continue
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if '/film/' in zehVcU893FC6LEd1Aij or 'فيلم' in zehVcU893FC6LEd1Aij or any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,112,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,113,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/actor/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,111,TTuPH708dUNnjlG3oQpkZsi)
		elif '/series/' in zehVcU893FC6LEd1Aij and '/list' not in url:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'/list'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,111,TTuPH708dUNnjlG3oQpkZsi)
		elif '/list' in url and 'حلقة' in title:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,112,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,113,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		if mfVtpzhI3WGnAx0!='search': items = YYqECUofyi7wFrW.findall('(updateQuery).*?>(.+?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		else: items = YYqECUofyi7wFrW.findall('<li>.*?href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if mfVtpzhI3WGnAx0!='search':
				if '?' in url: zehVcU893FC6LEd1Aij = url+'&page='+title
				else: zehVcU893FC6LEd1Aij = url+'?page='+title
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			if title: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,111,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,mfVtpzhI3WGnAx0)
	return
def vl57jIYC4a(url,pKk7eYUuHBDgG):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('items d-flex(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)>1:
		if '/season/' in bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]: ttVUWKLHayoTMnGwOjQqI,EIPXmH9BMs54SqTFjgrfzLnt = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0],bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
		else: ttVUWKLHayoTMnGwOjQqI,EIPXmH9BMs54SqTFjgrfzLnt = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1],bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	else: ttVUWKLHayoTMnGwOjQqI,EIPXmH9BMs54SqTFjgrfzLnt = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0],bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	for XW2Opt4RQsVihunCylz6j in range(2):
		if pKk7eYUuHBDgG: mode,type,AAMHoYxRCmt2D6ph89W = 116,'folder',ttVUWKLHayoTMnGwOjQqI
		else: mode,type,AAMHoYxRCmt2D6ph89W = 112,'video',EIPXmH9BMs54SqTFjgrfzLnt
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if pKk7eYUuHBDgG and len(items)<2:
			pKk7eYUuHBDgG = False
			continue
		for zehVcU893FC6LEd1Aij,VHXsFq24oDvfBtkh5lJ6,PJN58A9SFZTwi6uLMB73m in items:
			title = VHXsFq24oDvfBtkh5lJ6+Vwgflszp4WRA93kx6hvdua21HX5cOb+PJN58A9SFZTwi6uLMB73m
			ZI51XvE8YatWCmNdrp(type,LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,mode)
		break
	if not items and '/episodes' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		PPkFzM036KoU = YYqECUofyi7wFrW.findall('class="breadcrumb"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if PPkFzM036KoU:
			AAMHoYxRCmt2D6ph89W = PPkFzM036KoU[0]
			oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if len(oDhlaxn0EqyYikcHrmZBN8uv)>2:
				zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[2]+'list'
				hGJKk8tAiC3XFufEpqavQWmwTHdL(zehVcU893FC6LEd1Aij)
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="actions(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	lT2WwiCm0qzk9FvghQueGc1 = '/watch/' in AAMHoYxRCmt2D6ph89W
	download = '/download/' in AAMHoYxRCmt2D6ph89W
	if   lT2WwiCm0qzk9FvghQueGc1 and not download: YxEQ6jB4f1kIDLHpwchZnmXTsy,XRIckV0HC2EYTDpzPhry76Sbln91Kw = oDhlaxn0EqyYikcHrmZBN8uv[0],NdKhAS6MXVEORLTwob92pxlZ
	elif not lT2WwiCm0qzk9FvghQueGc1 and download: YxEQ6jB4f1kIDLHpwchZnmXTsy,XRIckV0HC2EYTDpzPhry76Sbln91Kw = NdKhAS6MXVEORLTwob92pxlZ,oDhlaxn0EqyYikcHrmZBN8uv[0]
	elif lT2WwiCm0qzk9FvghQueGc1 and download: YxEQ6jB4f1kIDLHpwchZnmXTsy,XRIckV0HC2EYTDpzPhry76Sbln91Kw = oDhlaxn0EqyYikcHrmZBN8uv[0],oDhlaxn0EqyYikcHrmZBN8uv[1]
	else: YxEQ6jB4f1kIDLHpwchZnmXTsy,XRIckV0HC2EYTDpzPhry76Sbln91Kw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	UTwH7zjZOrmFl = []
	if lT2WwiCm0qzk9FvghQueGc1:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',YxEQ6jB4f1kIDLHpwchZnmXTsy,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-PLAY-2nd')
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('let servers(.*?)player',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if gcBxGPatZIzQ1:
			zyoNRs5F72Bkr0JYfGh6PULju4bO = gcBxGPatZIzQ1[0]
			APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('"name":"(.*?)".*?"url":"(.*?)"',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
			for title,zehVcU893FC6LEd1Aij in APRuYMmlIVGTX:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('\\/','/')
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if download:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',XRIckV0HC2EYTDpzPhry76Sbln91Kw,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-PLAY-3rd')
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"servers"(.*?)info-container',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if gcBxGPatZIzQ1:
			zyoNRs5F72Bkr0JYfGh6PULju4bO = gcBxGPatZIzQ1[0]
			APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title,a0ao2jdlt4r9nhHwpvSgOVGA in APRuYMmlIVGTX:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'+'____'+a0ao2jdlt4r9nhHwpvSgOVGA
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search:
		search = Z6GiHgnz0jNytc()
		if not search: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
def oDejqO6uYrsWp5ym9TQtEdV(url):
	url = url.split('/smartemadfilter?')[0]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	Hk9cy1IL0PXCw3OgYE5nr = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('adv-filter(.*?)shows-container',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		pvTDzEwPZ16oSJOQr8Y,NNsAI58HYxeWb2d3it,sCRbZp6Irl17v = zip(*Hk9cy1IL0PXCw3OgYE5nr)
		Hk9cy1IL0PXCw3OgYE5nr = zip(NNsAI58HYxeWb2d3it,pvTDzEwPZ16oSJOQr8Y,sCRbZp6Irl17v)
	return Hk9cy1IL0PXCw3OgYE5nr
def nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W):
	items = YYqECUofyi7wFrW.findall('value="(.*?)".*?>\s*(.*?)\s*<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return items
def iZVSYfFWz37rOU9aguLHRmJcoK86tB(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	p9pPoLdYMbqwXz1FQraUxKNv35 = url.split('/smartemadfilter?')[0]
	Q5Jbsopg4HhxqTY = msbTrJW03xuvA(url,'url')
	url = url.replace(p9pPoLdYMbqwXz1FQraUxKNv35,Q5Jbsopg4HhxqTY)
	url = url.replace('/smartemadfilter?','/?')
	return url
e1fEh4Pv8R0ory6Q2JBzkWVwXL9xC = ['quality','year','genre','category']
mLT45zZwoDVtXBOjhNMsC = ['category','genre','year']
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='DEFINED_FILTER':
		if mLT45zZwoDVtXBOjhNMsC[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = mLT45zZwoDVtXBOjhNMsC[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(mLT45zZwoDVtXBOjhNMsC[0:-1])):
			if mLT45zZwoDVtXBOjhNMsC[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = mLT45zZwoDVtXBOjhNMsC[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='FULL_FILTER':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+Jv2yebcHLo5GCrXZlw
		Afey3cL4ojzg = iZVSYfFWz37rOU9aguLHRmJcoK86tB(BfjcMoqOsmdUvZVCHWIyQKi)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',Afey3cL4ojzg,111)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',Afey3cL4ojzg,111)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Hk9cy1IL0PXCw3OgYE5nr = oDejqO6uYrsWp5ym9TQtEdV(url)
	dict = {}
	for name,zZ0VrYRv6m8,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		name = name.replace('كل ',NdKhAS6MXVEORLTwob92pxlZ)
		items = nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='DEFINED_FILTER':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<2:
				if zZ0VrYRv6m8==mLT45zZwoDVtXBOjhNMsC[-1]:
					Afey3cL4ojzg = iZVSYfFWz37rOU9aguLHRmJcoK86tB(BfjcMoqOsmdUvZVCHWIyQKi)
					hGJKk8tAiC3XFufEpqavQWmwTHdL(Afey3cL4ojzg)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'DEFINED_FILTER___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				if zZ0VrYRv6m8==mLT45zZwoDVtXBOjhNMsC[-1]:
					Afey3cL4ojzg = iZVSYfFWz37rOU9aguLHRmJcoK86tB(BfjcMoqOsmdUvZVCHWIyQKi)
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',Afey3cL4ojzg,111)
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,115,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='FULL_FILTER':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع :'+name,BfjcMoqOsmdUvZVCHWIyQKi,114,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if K6KbZDHncNizQgl1fr59XV0=='196533': X9dRM31pz6y = 'أفلام نيتفلكس'
			elif K6KbZDHncNizQgl1fr59XV0=='196531': X9dRM31pz6y = 'مسلسلات نيتفلكس'
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' :'#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' :'+name
			if type=='FULL_FILTER': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,114,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='DEFINED_FILTER' and mLT45zZwoDVtXBOjhNMsC[-2]+'=' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'modified_filters')
				BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				Afey3cL4ojzg = iZVSYfFWz37rOU9aguLHRmJcoK86tB(BfjcMoqOsmdUvZVCHWIyQKi)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,111)
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,115,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.replace('=&','=0&')
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	for key in e1fEh4Pv8R0ory6Q2JBzkWVwXL9xC:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('=0','=')
	return LaGtUDiK2xnfz
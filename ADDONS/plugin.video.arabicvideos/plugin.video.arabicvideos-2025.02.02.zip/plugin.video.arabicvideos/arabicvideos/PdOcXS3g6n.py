# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'GOOGLESEARCH'
LJfTAEQPv9h4BXdwUp = '_GOS_'
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI):
	if   pPrvqm3tjuXLTgw1==1010: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif pPrvqm3tjuXLTgw1==1011: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hSkuXFLDROj1y(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1012: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = G4QnR9twrpqDdSfcji(TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1013: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Wv9EJeboacFK6XOwtVZfHDjNLdqIS()
	elif pPrvqm3tjuXLTgw1==1014: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = TyCRzXZjr0kSKF6NpE3sfgt(TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1015: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = q5GwKak9UerR0N6ZFDtuAJz1XlEoQ(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1016: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ik9NdPOYXBf4eFvaVQ(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1018: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = iseHVgSJ68ZYpExKNIo52FuWzbBm(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==1019: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(ui7N5YGR9KdslpEbQkVTwFqDgI,False)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder','بحث جوجل جديد',NdKhAS6MXVEORLTwob92pxlZ,1019)
	ZI51XvE8YatWCmNdrp('link','كيف يعمل بحث جوجل','',1013)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'==== كلمات البحث المخزنة ===='+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	nXryp1uRFle4bo = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if nXryp1uRFle4bo:
		nXryp1uRFle4bo = nXryp1uRFle4bo['__SEQUENCED_COLUMNS__']
		for ffYWUsElBLFTDkmH1x in reversed(nXryp1uRFle4bo):
			ZI51XvE8YatWCmNdrp('folder',ffYWUsElBLFTDkmH1x,NdKhAS6MXVEORLTwob92pxlZ,1019,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ffYWUsElBLFTDkmH1x)
	return
def iseHVgSJ68ZYpExKNIo52FuWzbBm(search):
	tTIQWSbOEqHJ4(search,True)
	MIjcStaDWnv(f4vncKMRlXG9s)
	return
def tTIQWSbOEqHJ4(search,YdRTcfbkDs=False):
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	w3SqvRknuD6rTAx = search.replace(LJfTAEQPv9h4BXdwUp,NdKhAS6MXVEORLTwob92pxlZ).lower()
	NBs0Uozt87SVKc5DlyauC69,uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = [],[],[]
	if not YdRTcfbkDs:
		NBs0Uozt87SVKc5DlyauC69 = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GOOGLESEARCH_RESULTS',w3SqvRknuD6rTAx)
		if NBs0Uozt87SVKc5DlyauC69: uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = NBs0Uozt87SVKc5DlyauC69
	if YdRTcfbkDs or not NBs0Uozt87SVKc5DlyauC69:
		import ddml0DI2qy
		ddml0DI2qy.oQA0DB8sYf(w3SqvRknuD6rTAx,'_GOOGLE',True)
		yhfSGqWXu74YP2 = eW4ibqvEtXV6(w3SqvRknuD6rTAx)
		for rMOG2USkPesYZD9KNAVqpc in yhfSGqWXu74YP2:
			name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w = rMOG2USkPesYZD9KNAVqpc
			if mAH4aPy8q1w in JuMxp2dLcDy6bj037awTvNIZ: uDXBi6Ap5V3YsS1Fxr.append(rMOG2USkPesYZD9KNAVqpc)
			else: aacMKtxgsX4mhlP.append(rMOG2USkPesYZD9KNAVqpc)
		uDXBi6Ap5V3YsS1Fxr = sorted(uDXBi6Ap5V3YsS1Fxr,reverse=f4vncKMRlXG9s,key=lambda key: key[e8XhbyuzvjYkIsJUtB5w])
		aacMKtxgsX4mhlP = sorted(aacMKtxgsX4mhlP,reverse=f4vncKMRlXG9s,key=lambda key: key[e8XhbyuzvjYkIsJUtB5w])
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'GOOGLESEARCH_RESULTS',w3SqvRknuD6rTAx,[uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP],KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DETAILED_GOOGLE',w3SqvRknuD6rTAx)
		ddml0DI2qy.oQA0DB8sYf(w3SqvRknuD6rTAx,'_GOOGLE',False)
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+w3SqvRknuD6rTAx+"')")
		if uDXBi6Ap5V3YsS1Fxr: ZaUVqChKHwRLYbeiOv('','','رسالة من المبرمج','تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(uDXBi6Ap5V3YsS1Fxr))+'  مواقع')
		else: uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = vwO1b6WjJBtXKknp(w3SqvRknuD6rTAx,f4vncKMRlXG9s)
	ZI51XvE8YatWCmNdrp('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('folder','بحث منفرد لمواقع جوجل',NdKhAS6MXVEORLTwob92pxlZ,1011,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder','نتائج البحث مفصلة - '+w3SqvRknuD6rTAx,'opened_sites_google',1012,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('folder','نتائج البحث مقسمة - '+w3SqvRknuD6rTAx,'listed_sites_google',1012,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder','مواقع جوجل ('+str(len(uDXBi6Ap5V3YsS1Fxr))+') - '+w3SqvRknuD6rTAx,'',1016,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('link','إعادة بحث جوجل - '+w3SqvRknuD6rTAx,'',1018,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,search)
	return
def ik9NdPOYXBf4eFvaVQ(w3SqvRknuD6rTAx):
	uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = vwO1b6WjJBtXKknp(w3SqvRknuD6rTAx)
	if not uDXBi6Ap5V3YsS1Fxr and not aacMKtxgsX4mhlP: return
	E263zduiLvwZsAjnh = {}
	for name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w in uDXBi6Ap5V3YsS1Fxr: E263zduiLvwZsAjnh[mAH4aPy8q1w] = name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w
	jXyoTFQzm6nYrabVHN8kg2vdR = list(E263zduiLvwZsAjnh.keys())
	import ddml0DI2qy
	llqoVr0WsTpyPx2duLz9OweifjRtK = ddml0DI2qy.uUa9cvTpySOLm2l(jXyoTFQzm6nYrabVHN8kg2vdR)
	for mAH4aPy8q1w in llqoVr0WsTpyPx2duLz9OweifjRtK:
		if 'tuple' in str(type(mAH4aPy8q1w)):
			emiIH49XT6jzOQrw.append(mAH4aPy8q1w)
			continue
		name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w = E263zduiLvwZsAjnh[mAH4aPy8q1w]
		QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
		ZI51XvE8YatWCmNdrp('folder',nwB7i5HsIz+name,zehVcU893FC6LEd1Aij,1014,QMNbdfSPq5gsV4rmR3ZoUni2,'',mAH4aPy8q1w)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'مواقع بجوجل غير موجودة بالبرنامج'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,1015)
	aacMKtxgsX4mhlP = sorted(aacMKtxgsX4mhlP,reverse=f4vncKMRlXG9s,key=lambda key: key[e8XhbyuzvjYkIsJUtB5w])
	for name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w in aacMKtxgsX4mhlP:
		ZI51XvE8YatWCmNdrp('link','_GOS_'+name,zehVcU893FC6LEd1Aij,1015,QMNbdfSPq5gsV4rmR3ZoUni2,'',mAH4aPy8q1w)
	return
def vwO1b6WjJBtXKknp(w3SqvRknuD6rTAx,Bj6sntVgZdPu8RXFLAW5NiQl=k6apiPAlLKM1ed8J42RjHh0o):
	uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = [],[]
	if Bj6sntVgZdPu8RXFLAW5NiQl:
		NBs0Uozt87SVKc5DlyauC69 = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GOOGLESEARCH_RESULTS',w3SqvRknuD6rTAx)
		if NBs0Uozt87SVKc5DlyauC69: uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = NBs0Uozt87SVKc5DlyauC69
	if not uDXBi6Ap5V3YsS1Fxr and not aacMKtxgsX4mhlP: ZaUVqChKHwRLYbeiOv('','','رسالة من المبرمج','للأسف جوجل لم يجد مواقع فيها طلبك')
	return uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP
def G4QnR9twrpqDdSfcji(aqmiV6x7p2UKd9FseTgJCyjb,w3SqvRknuD6rTAx):
	uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = vwO1b6WjJBtXKknp(w3SqvRknuD6rTAx)
	if not uDXBi6Ap5V3YsS1Fxr and not aacMKtxgsX4mhlP: return
	cCYE3PXZvdmJO64,IOarQgF7f1WNn = [],{}
	for name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w in uDXBi6Ap5V3YsS1Fxr:
		cCYE3PXZvdmJO64.append(mAH4aPy8q1w)
		IOarQgF7f1WNn[mAH4aPy8q1w] = zzQKRs5xZyTbDS2i01p(text)
	import ddml0DI2qy
	ddml0DI2qy.RCwQnGUkiqamB9PyLrTvI(w3SqvRknuD6rTAx,aqmiV6x7p2UKd9FseTgJCyjb,NdKhAS6MXVEORLTwob92pxlZ,cCYE3PXZvdmJO64,IOarQgF7f1WNn)
	return
def hSkuXFLDROj1y(w3SqvRknuD6rTAx):
	uDXBi6Ap5V3YsS1Fxr,aacMKtxgsX4mhlP = vwO1b6WjJBtXKknp(w3SqvRknuD6rTAx)
	if not uDXBi6Ap5V3YsS1Fxr and not aacMKtxgsX4mhlP: return
	E263zduiLvwZsAjnh = {}
	for name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w in uDXBi6Ap5V3YsS1Fxr:
		E263zduiLvwZsAjnh[mAH4aPy8q1w] = name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w
	jXyoTFQzm6nYrabVHN8kg2vdR = list(E263zduiLvwZsAjnh.keys())
	import ddml0DI2qy
	llqoVr0WsTpyPx2duLz9OweifjRtK = ddml0DI2qy.uUa9cvTpySOLm2l(jXyoTFQzm6nYrabVHN8kg2vdR)
	for mAH4aPy8q1w in llqoVr0WsTpyPx2duLz9OweifjRtK:
		if 'tuple' in str(type(mAH4aPy8q1w)):
			emiIH49XT6jzOQrw.append(mAH4aPy8q1w)
			continue
		name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w = E263zduiLvwZsAjnh[mAH4aPy8q1w]
		QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
		text = zzQKRs5xZyTbDS2i01p(text)
		name = name+' - '+w3SqvRknuD6rTAx
		ZI51XvE8YatWCmNdrp('folder',nwB7i5HsIz+name,mAH4aPy8q1w,548,QMNbdfSPq5gsV4rmR3ZoUni2,'',text)
	return
def zzQKRs5xZyTbDS2i01p(title):
	N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة)',title,YYqECUofyi7wFrW.DOTALL)
	PJN58A9SFZTwi6uLMB73m = N1VjdbtuO3z[0][0] if N1VjdbtuO3z else title
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return PJN58A9SFZTwi6uLMB73m
def eW4ibqvEtXV6(search):
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	BfjcMoqOsmdUvZVCHWIyQKi = url+'&start=0&num=100&tbm=vid&udm=7'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'GOOGLESEARCH-SEARCH-1st')
	if not VNc1u4edS90FK5W6bsMgQC2B.succeeded: return []
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	NgLocOQxqfk41wETWeJzGA = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YyHUiEXh8NQAvCf,'googlesearch')
	if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(NgLocOQxqfk41wETWeJzGA):
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.makedirs(NgLocOQxqfk41wETWeJzGA)
		except: pass
	items = []
	sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if sCRbZp6Irl17v:
		for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
			zehVcU893FC6LEd1Aij,title,text,k1ChwgueU5nbDX6K0BOEGx,name = AAMHoYxRCmt2D6ph89W
			k1ChwgueU5nbDX6K0BOEGx = ''
			items.append([zehVcU893FC6LEd1Aij,title,text,name,k1ChwgueU5nbDX6K0BOEGx])
	else:
		BfjcMoqOsmdUvZVCHWIyQKi = url+'&start=0&num=200'
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET::SCRAPERS',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'GOOGLESEARCH-SEARCH-2nd')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded: return []
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not sCRbZp6Irl17v: sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
			AAMHoYxRCmt2D6ph89W = BdnA8WwtJeKUVvE('list',AAMHoYxRCmt2D6ph89W)
			if len(AAMHoYxRCmt2D6ph89W)>17:
				zehVcU893FC6LEd1Aij = AAMHoYxRCmt2D6ph89W[17]
				title,text,name,k1ChwgueU5nbDX6K0BOEGx = AAMHoYxRCmt2D6ph89W[31][0:4]
				items.append([zehVcU893FC6LEd1Aij,title,text,name,k1ChwgueU5nbDX6K0BOEGx])
	Z9ZNUAWbocRz,cuBObUwPIxoLf0VFXnGs7l5a = [],[]
	for rMOG2USkPesYZD9KNAVqpc in items:
		zehVcU893FC6LEd1Aij,title,text,name,k1ChwgueU5nbDX6K0BOEGx = rMOG2USkPesYZD9KNAVqpc
		name = name.strip(' ')
		if not name: name = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
		name = UryVN9KOA5tuqi(name)
		if 'http://' in k1ChwgueU5nbDX6K0BOEGx or 'https://' in k1ChwgueU5nbDX6K0BOEGx: QMNbdfSPq5gsV4rmR3ZoUni2 = k1ChwgueU5nbDX6K0BOEGx
		elif 'data:image/' in k1ChwgueU5nbDX6K0BOEGx and ';base64,' in k1ChwgueU5nbDX6K0BOEGx:
			YXRdeE82Dh3BOfcHt1Z9jpN = YYqECUofyi7wFrW.findall('data:image/(\w+);base64,',k1ChwgueU5nbDX6K0BOEGx)
			YXRdeE82Dh3BOfcHt1Z9jpN = YXRdeE82Dh3BOfcHt1Z9jpN[0]
			QMNbdfSPq5gsV4rmR3ZoUni2 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(NgLocOQxqfk41wETWeJzGA,name+'.'+YXRdeE82Dh3BOfcHt1Z9jpN)
			if not IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(QMNbdfSPq5gsV4rmR3ZoUni2):
				k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.replace('\\u003d','=')
				k1ChwgueU5nbDX6K0BOEGx = k1ChwgueU5nbDX6K0BOEGx.replace('data:image/'+YXRdeE82Dh3BOfcHt1Z9jpN+';base64,','')
				Ene3jOXY51xHB40WtiJyh = NHsYdVBpXn.b64decode(k1ChwgueU5nbDX6K0BOEGx)
				open(QMNbdfSPq5gsV4rmR3ZoUni2,'wb').write(Ene3jOXY51xHB40WtiJyh)
		else: QMNbdfSPq5gsV4rmR3ZoUni2 = ''
		mAH4aPy8q1w = l25HU1oqtTCuDyWv(name,zehVcU893FC6LEd1Aij)
		if mAH4aPy8q1w not in cuBObUwPIxoLf0VFXnGs7l5a:
			cuBObUwPIxoLf0VFXnGs7l5a.append(mAH4aPy8q1w)
			name = P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w)
			Z9ZNUAWbocRz.append([name,zehVcU893FC6LEd1Aij,title,text,QMNbdfSPq5gsV4rmR3ZoUni2,mAH4aPy8q1w])
	return Z9ZNUAWbocRz
def TyCRzXZjr0kSKF6NpE3sfgt(zehVcU893FC6LEd1Aij,mAH4aPy8q1w):
	QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
	if nwB7i5HsIz: QQYZ7KIqVTxw()
	else: q5GwKak9UerR0N6ZFDtuAJz1XlEoQ()
	return
def Wv9EJeboacFK6XOwtVZfHDjNLdqIS():
	ZaUVqChKHwRLYbeiOv('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def q5GwKak9UerR0N6ZFDtuAJz1XlEoQ(mAH4aPy8q1w=''):
	ZaUVqChKHwRLYbeiOv('','',mAH4aPy8q1w,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def l25HU1oqtTCuDyWv(name,zehVcU893FC6LEd1Aij):
	cc67jvFI3Ub = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	RoDOya8x9mcMLZduGkX7YJUQTqI = name.lower()
	ZB3WgSanUwV = ''
	for key in list(cc67jvFI3Ub.keys()):
		if key.lower() in RoDOya8x9mcMLZduGkX7YJUQTqI: ZB3WgSanUwV = cc67jvFI3Ub[key]
	if not ZB3WgSanUwV:
		xKXbWz9coR7jUfil45aQENr0ICBJg = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'url')
		for mAH4aPy8q1w in list(xKp3jkIvM09AZ4euXa87i5TVtfUD.keys()):
			hhTD8OKNiVaj2ySZdUfBx6uIR5P = msbTrJW03xuvA(xKp3jkIvM09AZ4euXa87i5TVtfUD[mAH4aPy8q1w][0],'url')
			if xKXbWz9coR7jUfil45aQENr0ICBJg==hhTD8OKNiVaj2ySZdUfBx6uIR5P: ZB3WgSanUwV = mAH4aPy8q1w
	if not ZB3WgSanUwV:
		RoDOya8x9mcMLZduGkX7YJUQTqI = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
		for mAH4aPy8q1w in list(xKp3jkIvM09AZ4euXa87i5TVtfUD.keys()):
			gD3VTpiMe9HFLhnoQyZA5 = msbTrJW03xuvA(xKp3jkIvM09AZ4euXa87i5TVtfUD[mAH4aPy8q1w][0],'name')
			if RoDOya8x9mcMLZduGkX7YJUQTqI==gD3VTpiMe9HFLhnoQyZA5: ZB3WgSanUwV = mAH4aPy8q1w
	if not ZB3WgSanUwV: ZB3WgSanUwV = name
	ZB3WgSanUwV = ZB3WgSanUwV.upper()
	return ZB3WgSanUwV
# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'HALACIMA'
LJfTAEQPv9h4BXdwUp = '_HLC_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==80: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==81: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==82: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==83: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==89: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'HALACIMA-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,89,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('main-content(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-name="(.*?)".*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for mfVtpzhI3WGnAx0,title in items:
		zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajax/getItem?item='+mfVtpzhI3WGnAx0+'&Ajax=1'
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,81)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"nav-main"(.*?)</nav>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if zehVcU893FC6LEd1Aij=='#': continue
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,81)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'HALACIMA-TITLES-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP]
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'HALACIMA-TITLES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		if mfVtpzhI3WGnAx0=='featured':
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"container"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		elif '"section-post mb-10"' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"section-post mb-10"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		else:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<article(.*?)"pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items:
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not items: items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if '/series/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,83,TTuPH708dUNnjlG3oQpkZsi)
		elif 'سلاسل' not in url and any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,82,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'الحلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,83,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/movies/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,81,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,83,TTuPH708dUNnjlG3oQpkZsi)
	if mfVtpzhI3WGnAx0==NdKhAS6MXVEORLTwob92pxlZ:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)<footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=="": continue
				if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'هناك المزيد',url,81)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'HALACIMA-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"getSeasonsBySeries(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"list-episodes"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b and '/series/' not in url:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,83,TTuPH708dUNnjlG3oQpkZsi)
	elif gcBxGPatZIzQ1:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"image" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,82,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/movies/','/watch_movies/')
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace('/episodes/','/watch_episodes/')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'HALACIMA-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,'url')
	UTwH7zjZOrmFl = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"servers"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb = YYqECUofyi7wFrW.findall('postID = "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb = hCjvUfTn43KDe2BdlYZH6PVFyIuOb[0]
		items = YYqECUofyi7wFrW.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for oikt6P0hOAD5IvnlMpxf1,title in items:
			title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajax/getPlayer?server='+oikt6P0hOAD5IvnlMpxf1+'&postID='+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+'&Ajax=1'
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"downs"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__download'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'-')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search+'.html'
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
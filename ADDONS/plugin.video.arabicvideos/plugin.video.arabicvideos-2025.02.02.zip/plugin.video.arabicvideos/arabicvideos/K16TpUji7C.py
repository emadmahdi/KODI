# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'LODYNET'
LJfTAEQPv9h4BXdwUp = '_LDN_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الرئيسية','استفسارتكم و الطلبات']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==450: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==451: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==452: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==453: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = fxdz47XjOWTDnGJ6Zw1cvItbm(url)
	elif mode==454: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==459: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LODYNET-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,459,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مثبتات لودي نت',REGxsWAoilB7dCFNgMhz0V98bcm,451,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المضاف حديثا',REGxsWAoilB7dCFNgMhz0V98bcm,451,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'latest')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"MainMenu"(.*?)"SiteSlider"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if zehVcU893FC6LEd1Aij=='#': continue
			if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,451)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ):
	items = []
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LODYNET-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if mfVtpzhI3WGnAx0=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"SiteSlider"(.*?)"waves"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif mfVtpzhI3WGnAx0=='latest':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"RecentPosts"(.*?)"pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif '"ActorsList"' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"ActorsList"(.*?)"text/javascript"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif mfVtpzhI3WGnAx0 in ['0','1','2']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"Section"(.*?)</li></ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[int(mfVtpzhI3WGnAx0)]
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"BlocksArea"(.*?)"text/javascript"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items: items = YYqECUofyi7wFrW.findall('href="(.*?)".*?data-src="(.*?)".*?<h2>(.*?)</h2>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','حلقة','الفيلم']
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if '"ActorsList"' in LMKFcEkU1Q7R80yt4OsgvwxbfP and 'src=' in TTuPH708dUNnjlG3oQpkZsi:
			TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('src="(.*?)"',TTuPH708dUNnjlG3oQpkZsi,YYqECUofyi7wFrW.DOTALL)
			TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) حلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if not N1VjdbtuO3z: N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if set(title.split()) & set(iiSLCAX0rgEjoT68OYe3vnBI7WdZ) and 'مسلسل' not in title:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,452,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'حلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,453,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/category/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,451,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,453,TTuPH708dUNnjlG3oQpkZsi)
	if mfVtpzhI3WGnAx0 in [NdKhAS6MXVEORLTwob92pxlZ,'latest']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,451)
	return
def fxdz47XjOWTDnGJ6Zw1cvItbm(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LODYNET-SEASONS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"CategorySubLinks"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b and 'href=' in str(yyuOVAGPZijetcaNz0b):
		title = YYqECUofyi7wFrW.findall('<title>(.*?)-',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		title = title[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,454)
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,454)
	else: vl57jIYC4a(url)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LODYNET-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"EpisodesList"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"og:image" content="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0] if TTuPH708dUNnjlG3oQpkZsi else NdKhAS6MXVEORLTwob92pxlZ
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,452,TTuPH708dUNnjlG3oQpkZsi)
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,454)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp,ttFMHI9QPiN = [],[]
	BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/movies/','/watch_movies/')
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace('/episodes/','/watch_episodes/')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LODYNET-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<iframe src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
		if zehVcU893FC6LEd1Aij not in ttFMHI9QPiN:
			ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
			oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+oikt6P0hOAD5IvnlMpxf1+'__embed'
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"ServersList"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-embed="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if zehVcU893FC6LEd1Aij in ttFMHI9QPiN: continue
			ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"DownloadLinks"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<span>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			if zehVcU893FC6LEd1Aij in ttFMHI9QPiN: continue
			ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
			name = Pr4ubLdO7Z1qjKFaMIy3H(name)
			a0ao2jdlt4r9nhHwpvSgOVGA = YYqECUofyi7wFrW.findall('\d\d\d+',name,YYqECUofyi7wFrW.DOTALL)
			if a0ao2jdlt4r9nhHwpvSgOVGA:
				a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA[0]
				name = NdKhAS6MXVEORLTwob92pxlZ
			else: a0ao2jdlt4r9nhHwpvSgOVGA = NdKhAS6MXVEORLTwob92pxlZ
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__download'+a0ao2jdlt4r9nhHwpvSgOVGA
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search/'+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
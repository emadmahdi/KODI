# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ARABSEED'
headers = {'User-Agent':kkCjlxiynwT34GVFc()}
LJfTAEQPv9h4BXdwUp = '_ARS_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==250: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==251: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==252: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==253: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==254: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'CATEGORIES___'+text)
	elif mode==255: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'FILTERS___'+text)
	elif mode==256: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url,text)
	elif mode==259: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/main',NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,259,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/اخرى',254)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/category/اخرى',255)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/main',251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured_main')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'جديد الأفلام',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/main',251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'new_movies')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'جديد الحلقات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/main',251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'new_episodes')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المضاف حديثاً',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/latest',251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'lastest')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('class="MenuHeader"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	zyoNRs5F72Bkr0JYfGh6PULju4bO = gcBxGPatZIzQ1[0]
	APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if title not in Kdr54yMqbjTSX7piWREfPtZ2em and title!=NdKhAS6MXVEORLTwob92pxlZ:
			if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,256)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url,type):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if 'class="SliderInSection' in LMKFcEkU1Q7R80yt4OsgvwxbfP: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الأكثر مشاهدة',url,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'most')
	if 'class="MainSlides' in LMKFcEkU1Q7R80yt4OsgvwxbfP: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',url,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	if 'class="LinksList' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="LinksList(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)>1 and type=='new_episodes': AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
			items = YYqECUofyi7wFrW.findall('href="(.*?)"(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				PJN58A9SFZTwi6uLMB73m = YYqECUofyi7wFrW.findall('</i>(.*?)<span>(.*?)<',title,YYqECUofyi7wFrW.DOTALL)
				try: nDW6hxsUyd5NtALZ = PJN58A9SFZTwi6uLMB73m[0][0].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				except: nDW6hxsUyd5NtALZ = NdKhAS6MXVEORLTwob92pxlZ
				try: xIUmE83YCoqO = PJN58A9SFZTwi6uLMB73m[0][1].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				except: xIUmE83YCoqO = NdKhAS6MXVEORLTwob92pxlZ
				PJN58A9SFZTwi6uLMB73m = nDW6hxsUyd5NtALZ+Vwgflszp4WRA93kx6hvdua21HX5cOb+xIUmE83YCoqO
				if '<strong>' in title:
					RYdE7gpr2Nlc = YYqECUofyi7wFrW.findall('</i>(.*?)<',title,YYqECUofyi7wFrW.DOTALL)
					if RYdE7gpr2Nlc: PJN58A9SFZTwi6uLMB73m = RYdE7gpr2Nlc[0]
				if not PJN58A9SFZTwi6uLMB73m:
					RYdE7gpr2Nlc = YYqECUofyi7wFrW.findall('alt="(.*?)"',title,YYqECUofyi7wFrW.DOTALL)
					if RYdE7gpr2Nlc: PJN58A9SFZTwi6uLMB73m = RYdE7gpr2Nlc[0]
				if PJN58A9SFZTwi6uLMB73m:
					if 'key=' in zehVcU893FC6LEd1Aij: type = zehVcU893FC6LEd1Aij.split('key=')[1]
					else: type = 'newest'
					PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,zehVcU893FC6LEd1Aij,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,type)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type):
	VHkeUzoTxc9yl8rpaJO,data,items = 'GET',NdKhAS6MXVEORLTwob92pxlZ,[]
	if type=='filters':
		if '?' in url:
			VjFRLekX4tfA,OzUD8iTmGp15Sn9VINMHq = 'POST',{}
			BfjcMoqOsmdUvZVCHWIyQKi,kkBqpgGSQIR6PhVOjNKAfH = url.split('?')
			aLZSGBw7NhXtCuDWgJR = kkBqpgGSQIR6PhVOjNKAfH.split('&')
			for iJbFcE2OQWRykXNMUlfrCv918SqpD in aLZSGBw7NhXtCuDWgJR:
				key,K6KbZDHncNizQgl1fr59XV0 = iJbFcE2OQWRykXNMUlfrCv918SqpD.split('=')
				OzUD8iTmGp15Sn9VINMHq[key] = K6KbZDHncNizQgl1fr59XV0
			if aLZSGBw7NhXtCuDWgJR: VHkeUzoTxc9yl8rpaJO,url,data = VjFRLekX4tfA,BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,VHkeUzoTxc9yl8rpaJO,url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if type=='filters': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP]
	elif 'featured' in type: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="MainSlides(.*?)class="LinksList',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='new_movies': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='new_episodes': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='most': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="SliderInSection(.*?)class="LinksList',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="Blocks-UL"(.*?)class="AboElSeed"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if 'featured' in type:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		S6Ai4RlwfThbvoW38Hcd5JeKz0r = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if S6Ai4RlwfThbvoW38Hcd5JeKz0r:
			UTwH7zjZOrmFl,IGEpKNCaiLMT,rrWRpSuZvCHdt3BQMbmlYzGo,fmACYDaEFetdVr = zip(*S6Ai4RlwfThbvoW38Hcd5JeKz0r)
			items = zip(UTwH7zjZOrmFl,fmACYDaEFetdVr,IGEpKNCaiLMT)
	else:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if 'WWE' in title: continue
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if 'الحلقة' in title:
			N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
			if N1VjdbtuO3z:
				title = '_MOD_' + N1VjdbtuO3z[0]
				if title not in zIDPZSNn1OuweLHvmMKb6d:
					zIDPZSNn1OuweLHvmMKb6d.append(title)
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,253,TTuPH708dUNnjlG3oQpkZsi)
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,252,TTuPH708dUNnjlG3oQpkZsi)
		elif '/selary/' in zehVcU893FC6LEd1Aij or 'مسلسل' in title:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,253,TTuPH708dUNnjlG3oQpkZsi)
		else:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,252,TTuPH708dUNnjlG3oQpkZsi)
	if type in ['newest','best','most']:
		items = YYqECUofyi7wFrW.findall('page-numbers" href="(.*?)">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,type)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP[10000:]
	items = YYqECUofyi7wFrW.findall('data-src="(.*?)".*?alt="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not items: return
	TTuPH708dUNnjlG3oQpkZsi,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="ContainerEpisodesList"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<em>(.*?)</em>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,N1VjdbtuO3z in items:
			title = name+' - الحلقة رقم '+N1VjdbtuO3z
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,252,TTuPH708dUNnjlG3oQpkZsi)
	else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+'ملف التشغيل',url,252,TTuPH708dUNnjlG3oQpkZsi)
	return
def kYlKw9Bs0M1tybhiEDoR5UjPu(title,zehVcU893FC6LEd1Aij):
	PJN58A9SFZTwi6uLMB73m = YYqECUofyi7wFrW.findall('[a-zA-Z-]+',title,YYqECUofyi7wFrW.DOTALL)
	if PJN58A9SFZTwi6uLMB73m: title = PJN58A9SFZTwi6uLMB73m[0]
	else: title = title+Vwgflszp4WRA93kx6hvdua21HX5cOb+msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
	title = title.replace('عرب سيد',NdKhAS6MXVEORLTwob92pxlZ).replace('مباشر',NdKhAS6MXVEORLTwob92pxlZ).replace('مشاهدة',NdKhAS6MXVEORLTwob92pxlZ)
	title = title.replace('ٍ',NdKhAS6MXVEORLTwob92pxlZ)
	title = title.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	return title
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	BfjcMoqOsmdUvZVCHWIyQKi = VNc1u4edS90FK5W6bsMgQC2B.url
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,'url')
	headers['Referer'] = oikt6P0hOAD5IvnlMpxf1+'/'
	O8OAY149vKJNW2gqi6Gw,prtDOZCL6d2ER,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,[]
	ejOAzYrkn9TCEsXUv2q = YYqECUofyi7wFrW.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if ejOAzYrkn9TCEsXUv2q: O8OAY149vKJNW2gqi6Gw,HeW40B5t8iMsy2Y3GXU7QxJwg,prtDOZCL6d2ER,iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = ejOAzYrkn9TCEsXUv2q[0]
	else:
		ejOAzYrkn9TCEsXUv2q = YYqECUofyi7wFrW.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if ejOAzYrkn9TCEsXUv2q:
			zehVcU893FC6LEd1Aij,HeW40B5t8iMsy2Y3GXU7QxJwg = ejOAzYrkn9TCEsXUv2q[0]
			if 'watch' in HeW40B5t8iMsy2Y3GXU7QxJwg: O8OAY149vKJNW2gqi6Gw = zehVcU893FC6LEd1Aij
			else: prtDOZCL6d2ER = zehVcU893FC6LEd1Aij
	if O8OAY149vKJNW2gqi6Gw:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',O8OAY149vKJNW2gqi6Gw,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-PLAY-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="WatcherArea(.*?</ul>)',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			iQtFuKnHTd5sAeY018qOJc = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			iQtFuKnHTd5sAeY018qOJc = iQtFuKnHTd5sAeY018qOJc.replace('</ul>','<h3>')
			iQtFuKnHTd5sAeY018qOJc = iQtFuKnHTd5sAeY018qOJc.replace('<h3>','<h3><h3>')
			sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('<h3>.*?(\d+)(.*?)<h3>',iQtFuKnHTd5sAeY018qOJc,YYqECUofyi7wFrW.DOTALL)
			if not sCRbZp6Irl17v: sCRbZp6Irl17v = [(NdKhAS6MXVEORLTwob92pxlZ,iQtFuKnHTd5sAeY018qOJc)]
			for a0ao2jdlt4r9nhHwpvSgOVGA,AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
				if a0ao2jdlt4r9nhHwpvSgOVGA: a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA
				items = YYqECUofyi7wFrW.findall('data-link="(.*?)".*?<span>(.*?)</span>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				for zehVcU893FC6LEd1Aij,name in items:
					if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
					zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__watch'+a0ao2jdlt4r9nhHwpvSgOVGA
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not oDhlaxn0EqyYikcHrmZBN8uv: oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if oDhlaxn0EqyYikcHrmZBN8uv:
			zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA = oDhlaxn0EqyYikcHrmZBN8uv[0]
			name = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
			if '%' in a0ao2jdlt4r9nhHwpvSgOVGA: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__embed__'
			else: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__embed____'+a0ao2jdlt4r9nhHwpvSgOVGA
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if prtDOZCL6d2ER:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',prtDOZCL6d2ER,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-PLAY-3rd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="DownloadArea(.*?)<script src=',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			iQtFuKnHTd5sAeY018qOJc = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('class="DownloadServers(.*?)</ul>',iQtFuKnHTd5sAeY018qOJc,YYqECUofyi7wFrW.DOTALL)
			for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
				items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				for zehVcU893FC6LEd1Aij,title,a0ao2jdlt4r9nhHwpvSgOVGA in items:
					if not zehVcU893FC6LEd1Aij: continue
					if 'reviewstation' in zehVcU893FC6LEd1Aij: continue
					zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij)
					zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download____'+a0ao2jdlt4r9nhHwpvSgOVGA
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	oo8dLUCKPgaXpj9uJhFzWN2 = str(UTwH7zjZOrmFl)
	OOQ3WjMcgwymVU6K0X72d = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(K6KbZDHncNizQgl1fr59XV0 in oo8dLUCKPgaXpj9uJhFzWN2 for K6KbZDHncNizQgl1fr59XV0 in OOQ3WjMcgwymVU6K0X72d):
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search: search = Z6GiHgnz0jNytc()
	if not search: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/find/?find='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='CATEGORIES':
		if SkoY1Cry9Jx6bwVc[0]+'==' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = SkoY1Cry9Jx6bwVc[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(SkoY1Cry9Jx6bwVc[0:-1])):
			if SkoY1Cry9Jx6bwVc[xX6zt5oS08TO29CUhYJa1K]+'==' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = SkoY1Cry9Jx6bwVc[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&&'+II4s1CdgcbN6BSvWPnHtz+'==0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&&'+II4s1CdgcbN6BSvWPnHtz+'==0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&&')+'___'+g7jQ4ZX1quCJ.strip('&&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'//getposts??'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='FILTERS':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'//getposts??'+Jv2yebcHLo5GCrXZlw
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = sGnJcO28zRYIbekfivM(BfjcMoqOsmdUvZVCHWIyQKi)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'POST',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABSEED-FILTERS_MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	E8E5phAg1v9WFHmMO2wQJV = YYqECUofyi7wFrW.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	h9wzZ7KLEJ53xTSVB2AHWX = YYqECUofyi7wFrW.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	Hk9cy1IL0PXCw3OgYE5nr = E8E5phAg1v9WFHmMO2wQJV+h9wzZ7KLEJ53xTSVB2AHWX
	dict = {}
	for name,zZ0VrYRv6m8,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		items = YYqECUofyi7wFrW.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('data-rate="(.*?)".*?<em>(.*?)</em>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			items = []
			for X9dRM31pz6y,K6KbZDHncNizQgl1fr59XV0 in APRuYMmlIVGTX: items.append([X9dRM31pz6y,NdKhAS6MXVEORLTwob92pxlZ,K6KbZDHncNizQgl1fr59XV0])
			zZ0VrYRv6m8 = 'rate'
			name = 'التقييم'
		else: zZ0VrYRv6m8 = items[0][1]
		if '==' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='CATEGORIES':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<=1:
				if zZ0VrYRv6m8==SkoY1Cry9Jx6bwVc[-1]: hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'CATEGORIES___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = sGnJcO28zRYIbekfivM(BfjcMoqOsmdUvZVCHWIyQKi)
				if zZ0VrYRv6m8==SkoY1Cry9Jx6bwVc[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',BfjcMoqOsmdUvZVCHWIyQKi,254,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='FILTERS':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&&'+zZ0VrYRv6m8+'==0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&&'+zZ0VrYRv6m8+'==0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع :'+name,BfjcMoqOsmdUvZVCHWIyQKi,255,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for X9dRM31pz6y,gHbS3MaYo0j6uTdm2qyQnKP,K6KbZDHncNizQgl1fr59XV0 in items:
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			if 'الكل' in X9dRM31pz6y: continue
			X9dRM31pz6y = Pr4ubLdO7Z1qjKFaMIy3H(X9dRM31pz6y)
			VHXsFq24oDvfBtkh5lJ6,PJN58A9SFZTwi6uLMB73m = X9dRM31pz6y,X9dRM31pz6y
			PJN58A9SFZTwi6uLMB73m = name+': '+VHXsFq24oDvfBtkh5lJ6
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = PJN58A9SFZTwi6uLMB73m
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&&'+zZ0VrYRv6m8+'=='+VHXsFq24oDvfBtkh5lJ6
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&&'+zZ0VrYRv6m8+'=='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			if type=='FILTERS':
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,url,255,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='CATEGORIES' and SkoY1Cry9Jx6bwVc[-2]+'==' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'modified_filters')
				Afey3cL4ojzg = url+'//getposts??'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = sGnJcO28zRYIbekfivM(Afey3cL4ojzg)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,251,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,url,254,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
SkoY1Cry9Jx6bwVc = ['category','country','release-year']
sgSzKexXhImNZd = ['category','country','genre','release-year','language','quality','rate']
def sGnJcO28zRYIbekfivM(url):
	Hy2NRXYev15lQWn4IzqUw = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',Hy2NRXYev15lQWn4IzqUw)
	url = url.replace('/category/اخرى',NdKhAS6MXVEORLTwob92pxlZ)
	if Hy2NRXYev15lQWn4IzqUw not in url: url = url+Hy2NRXYev15lQWn4IzqUw
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.strip('&&')
	qZBlhLHkP5yp,LaGtUDiK2xnfz = {},NdKhAS6MXVEORLTwob92pxlZ
	if '==' in TGKlgc10fn:
		items = TGKlgc10fn.split('&&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('==')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	for key in sgSzKexXhImNZd:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&&'+key+'=='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&&'+key+'=='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&&')
	return LaGtUDiK2xnfz
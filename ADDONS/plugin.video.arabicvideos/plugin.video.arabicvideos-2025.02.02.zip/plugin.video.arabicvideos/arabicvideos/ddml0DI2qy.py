# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'GLOBALSEARCH'
LJfTAEQPv9h4BXdwUp = '_GLS_'
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	if   pPrvqm3tjuXLTgw1==540: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif pPrvqm3tjuXLTgw1==541: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = YXwEHj2ISqvfrAUb(ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==542: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = RCwQnGUkiqamB9PyLrTvI(ui7N5YGR9KdslpEbQkVTwFqDgI,TixSXhpW69Uba4f1NPqzYE7JcZ,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif pPrvqm3tjuXLTgw1==543: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Wv9EJeboacFK6XOwtVZfHDjNLdqIS()
	elif pPrvqm3tjuXLTgw1==548: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = U1aocSFD9eqz4uKCiRfh(TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==549: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(ui7N5YGR9KdslpEbQkVTwFqDgI)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder','بحث جديد لجميع المواقع',NdKhAS6MXVEORLTwob92pxlZ,549)
	ZI51XvE8YatWCmNdrp('link','كيف يعمل بحث جميع المواقع','',543)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'==== كلمات البحث المخزنة ===='+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	nXryp1uRFle4bo = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if nXryp1uRFle4bo:
		nXryp1uRFle4bo = nXryp1uRFle4bo['__SEQUENCED_COLUMNS__']
		for ffYWUsElBLFTDkmH1x in reversed(nXryp1uRFle4bo):
			ZI51XvE8YatWCmNdrp('folder',ffYWUsElBLFTDkmH1x,NdKhAS6MXVEORLTwob92pxlZ,549,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ffYWUsElBLFTDkmH1x)
	return
def tTIQWSbOEqHJ4(ffYWUsElBLFTDkmH1x):
	if not ffYWUsElBLFTDkmH1x:
		ffYWUsElBLFTDkmH1x = Z6GiHgnz0jNytc()
		if not ffYWUsElBLFTDkmH1x: return
		ffYWUsElBLFTDkmH1x = ffYWUsElBLFTDkmH1x.lower()
	w3SqvRknuD6rTAx = ffYWUsElBLFTDkmH1x.replace(LJfTAEQPv9h4BXdwUp,NdKhAS6MXVEORLTwob92pxlZ)
	oQA0DB8sYf(w3SqvRknuD6rTAx,'_ALL',True)
	ZI51XvE8YatWCmNdrp('link','بحث جماعي للمواقع - '+w3SqvRknuD6rTAx,'search_sites_all',542,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('folder','بحث منفرد للمواقع - '+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,541,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder','نتائج البحث مفصلة - '+w3SqvRknuD6rTAx,'opened_sites_all',542,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	ZI51XvE8YatWCmNdrp('folder','نتائج البحث مقسمة - '+w3SqvRknuD6rTAx,'listed_sites_all',542,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,w3SqvRknuD6rTAx)
	return
def oQA0DB8sYf(kRvDoJyE6tCQ8qNM,t61tPbV7UWZ,EAXfthm0jx27eG5YvC):
	if t61tPbV7UWZ=='_ALL': Bc9jvpw5eoTd = '_GLS_'
	elif t61tPbV7UWZ=='_GOOGLE': Bc9jvpw5eoTd = '_GOS_'
	QAyh2gNEwSiLdW31K = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,kRvDoJyE6tCQ8qNM)
	Xk72j9Hm0vaFec6po4UWR = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,Bc9jvpw5eoTd+kRvDoJyE6tCQ8qNM)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,kRvDoJyE6tCQ8qNM)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,Bc9jvpw5eoTd+kRvDoJyE6tCQ8qNM)
	Cg4BEYWrMyNRlDbofinm9j8JsqL = QAyh2gNEwSiLdW31K+Xk72j9Hm0vaFec6po4UWR
	if Cg4BEYWrMyNRlDbofinm9j8JsqL and EAXfthm0jx27eG5YvC: kRvDoJyE6tCQ8qNM = Bc9jvpw5eoTd+kRvDoJyE6tCQ8qNM
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,kRvDoJyE6tCQ8qNM,Cg4BEYWrMyNRlDbofinm9j8JsqL,KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
	return
def SGDUAhnk8eLvd(t61tPbV7UWZ):
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if TT32BcvomhVewpgMSWkEb46y7xqO!=1: return
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DETAILED'+t61tPbV7UWZ)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DIVIDED'+t61tPbV7UWZ)
	if t61tPbV7UWZ=='_GOOGLE': WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GOOGLESEARCH_RESULTS')
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def RCwQnGUkiqamB9PyLrTvI(hWGwxrcRzn0YqmkB3u6CEVl,gtu9JS8Xr3njYI6WDCNpRUFdQ,k7YFjfu31Uw6oJbOIrM=NdKhAS6MXVEORLTwob92pxlZ,Ksw1kNL0hSypE65oZM923TJ=BB0aZUJe38zfbw9HrWTtlvE,yhwa9tH2o8zIO={}):
	MSXGKkNdgYe7xzu4pAL318TWF6VD,cizdkEV5YN8tAIQyh4,LrlbjXH0zvqfD8OKG6ZJ,ccvT1YX8zoHdyg0W,A8AgRHsLxWo9Yz = [],{},{},{},{}
	if '_all' in gtu9JS8Xr3njYI6WDCNpRUFdQ: t61tPbV7UWZ,aqmiV6x7p2UKd9FseTgJCyjb,Bc9jvpw5eoTd = '_ALL','_all','_GLS_'
	elif '_google' in gtu9JS8Xr3njYI6WDCNpRUFdQ: t61tPbV7UWZ,aqmiV6x7p2UKd9FseTgJCyjb,Bc9jvpw5eoTd = '_GOOGLE','_google','_GOS_'
	if gtu9JS8Xr3njYI6WDCNpRUFdQ in ['listed_sites'+aqmiV6x7p2UKd9FseTgJCyjb,'opened_sites'+aqmiV6x7p2UKd9FseTgJCyjb,'closed_sites'+aqmiV6x7p2UKd9FseTgJCyjb]:
		if gtu9JS8Xr3njYI6WDCNpRUFdQ=='listed_sites'+aqmiV6x7p2UKd9FseTgJCyjb: MSXGKkNdgYe7xzu4pAL318TWF6VD = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,Bc9jvpw5eoTd+hWGwxrcRzn0YqmkB3u6CEVl)
		elif gtu9JS8Xr3njYI6WDCNpRUFdQ=='opened_sites'+aqmiV6x7p2UKd9FseTgJCyjb: MSXGKkNdgYe7xzu4pAL318TWF6VD = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_DETAILED'+t61tPbV7UWZ,hWGwxrcRzn0YqmkB3u6CEVl)
		elif gtu9JS8Xr3njYI6WDCNpRUFdQ=='closed_sites'+aqmiV6x7p2UKd9FseTgJCyjb: MSXGKkNdgYe7xzu4pAL318TWF6VD = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,'list','GLOBALSEARCH_DIVIDED'+t61tPbV7UWZ,(k7YFjfu31Uw6oJbOIrM,hWGwxrcRzn0YqmkB3u6CEVl))
	if not MSXGKkNdgYe7xzu4pAL318TWF6VD:
		ZLI75sAmWojzUYJtluw8h6H4reCf = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		XXnFpTZ9ksicAKzg1lMCP5Dtq = 'هل تريد الآن البحث في جميع المواقع عن \n "'+D7INg5kyRjwf4ZtoePVUrb1h2SJ+Vwgflszp4WRA93kx6hvdua21HX5cOb+hWGwxrcRzn0YqmkB3u6CEVl+Vwgflszp4WRA93kx6hvdua21HX5cOb+kjd9LyNqQHMUevZiRI7OlBGF1h+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if gtu9JS8Xr3njYI6WDCNpRUFdQ=='search_sites'+aqmiV6x7p2UKd9FseTgJCyjb: JzNoqV8ClRD6O = XXnFpTZ9ksicAKzg1lMCP5Dtq
		else: JzNoqV8ClRD6O = ZLI75sAmWojzUYJtluw8h6H4reCf+XXnFpTZ9ksicAKzg1lMCP5Dtq
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج',JzNoqV8ClRD6O)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=1: return
		f2cgzj0TovI9YVl7tan1QkMS8(False,False,False)
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Search For: [ '+hWGwxrcRzn0YqmkB3u6CEVl+' ]')
		sLgFo7bv3a0w = 1
		for mAH4aPy8q1w in Ksw1kNL0hSypE65oZM923TJ:
			hAwrJHNtMBsE7b = yhwa9tH2o8zIO[mAH4aPy8q1w] if yhwa9tH2o8zIO else hWGwxrcRzn0YqmkB3u6CEVl
			try: QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
			except: continue
			cizdkEV5YN8tAIQyh4[mAH4aPy8q1w] = []
			aPC0mLklY6jIUypFAwKbc = '_NODIALOGS_'
			if '-' in mAH4aPy8q1w: aPC0mLklY6jIUypFAwKbc = aPC0mLklY6jIUypFAwKbc+'_REMEMBERRESULTS__'+mAH4aPy8q1w+'_'
			if sLgFo7bv3a0w:
				XJ62UBRmIqFvfiNTQj.sleep(0.75)
				A8AgRHsLxWo9Yz[mAH4aPy8q1w] = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=vbpSAKljzB4xR8UPkyY2whrVG,args=(hAwrJHNtMBsE7b+aPC0mLklY6jIUypFAwKbc,))
				A8AgRHsLxWo9Yz[mAH4aPy8q1w].start()
			else: vbpSAKljzB4xR8UPkyY2whrVG(hAwrJHNtMBsE7b+aPC0mLklY6jIUypFAwKbc)
			kkDz5sdaPteM(P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w),NdKhAS6MXVEORLTwob92pxlZ,XJ62UBRmIqFvfiNTQj=1000)
		if sLgFo7bv3a0w:
			XJ62UBRmIqFvfiNTQj.sleep(2)
			for mAH4aPy8q1w in Ksw1kNL0hSypE65oZM923TJ: A8AgRHsLxWo9Yz[mAH4aPy8q1w].join(10)
			XJ62UBRmIqFvfiNTQj.sleep(2)
		for mAH4aPy8q1w in Ksw1kNL0hSypE65oZM923TJ:
			try: QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
			except: continue
			for gnmMTs3ArWXNhk1YP in emiIH49XT6jzOQrw:
				oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = gnmMTs3ArWXNhk1YP
				if nwB7i5HsIz in JHKDFe6Am0ruz8:
					if 'IPTV-' in mAH4aPy8q1w and (239>=pPrvqm3tjuXLTgw1>=230 or 289>=pPrvqm3tjuXLTgw1>=280):
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['IPTV-LIVE']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['IPTV-MOVIES']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['IPTV-SERIES']: continue
						if 'صفحة' not in JHKDFe6Am0ruz8:
							if   oJeO8LqTXi7W=='live': mAH4aPy8q1w = 'IPTV-LIVE'
							elif oJeO8LqTXi7W=='video': mAH4aPy8q1w = 'IPTV-MOVIES'
							elif oJeO8LqTXi7W=='folder': mAH4aPy8q1w = 'IPTV-SERIES'
						else:
							if   'LIVE' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'IPTV-LIVE'
							elif 'MOVIES' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'IPTV-MOVIES'
							elif 'SERIES' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'IPTV-SERIES'
					elif 'M3U-' in mAH4aPy8q1w and 729>=pPrvqm3tjuXLTgw1>=710:
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['M3U-LIVE']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['M3U-MOVIES']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['M3U-SERIES']: continue
						if 'صفحة' not in JHKDFe6Am0ruz8:
							if   oJeO8LqTXi7W=='live': mAH4aPy8q1w = 'M3U-LIVE'
							elif oJeO8LqTXi7W=='video': mAH4aPy8q1w = 'M3U-MOVIES'
							elif oJeO8LqTXi7W=='folder': mAH4aPy8q1w = 'M3U-SERIES'
						else:
							if   'LIVE' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'M3U-LIVE'
							elif 'MOVIES' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'M3U-MOVIES'
							elif 'SERIES' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'M3U-SERIES'
					elif 'YOUTUBE-' in mAH4aPy8q1w and 149>=pPrvqm3tjuXLTgw1>=140:
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['YOUTUBE-CHANNELS']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['YOUTUBE-PLAYLISTS']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in JHKDFe6Am0ruz8 or ':: ' in JHKDFe6Am0ruz8:
							continue
						else:
							if   pPrvqm3tjuXLTgw1==144 and 'USER' in JHKDFe6Am0ruz8: mAH4aPy8q1w = 'YOUTUBE-CHANNELS'
							elif pPrvqm3tjuXLTgw1==144 and 'CHNL' in JHKDFe6Am0ruz8: mAH4aPy8q1w = 'YOUTUBE-CHANNELS'
							elif pPrvqm3tjuXLTgw1==144 and 'LIST' in JHKDFe6Am0ruz8: mAH4aPy8q1w = 'YOUTUBE-PLAYLISTS'
							elif pPrvqm3tjuXLTgw1==143: mAH4aPy8q1w = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in mAH4aPy8q1w and 419>=pPrvqm3tjuXLTgw1>=400:
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['DAILYMOTION-PLAYLISTS']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['DAILYMOTION-CHANNELS']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['DAILYMOTION-VIDEOS']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['DAILYMOTION-LIVES']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['DAILYMOTION-HASHTAGS']: continue
						if   pPrvqm3tjuXLTgw1 in [401,405]: mAH4aPy8q1w = 'DAILYMOTION-PLAYLISTS'
						elif pPrvqm3tjuXLTgw1 in [402,406]: mAH4aPy8q1w = 'DAILYMOTION-CHANNELS'
						elif pPrvqm3tjuXLTgw1 in [404]: mAH4aPy8q1w = 'DAILYMOTION-VIDEOS'
						elif pPrvqm3tjuXLTgw1 in [415]: mAH4aPy8q1w = 'DAILYMOTION-LIVES'
						elif pPrvqm3tjuXLTgw1 in [416]: mAH4aPy8q1w = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in mAH4aPy8q1w and 39>=pPrvqm3tjuXLTgw1>=30:
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['PANET-SERIES']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['PANET-MOVIES']: continue
						if   pPrvqm3tjuXLTgw1 in [32,39]: mAH4aPy8q1w = 'PANET-SERIES'
						elif pPrvqm3tjuXLTgw1 in [33,39]: mAH4aPy8q1w = 'PANET-MOVIES'
					elif 'IFILM-' in mAH4aPy8q1w and 29>=pPrvqm3tjuXLTgw1>=20:
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['IFILM-ARABIC']: continue
						if gnmMTs3ArWXNhk1YP in cizdkEV5YN8tAIQyh4['IFILM-ENGLISH']: continue
						if   '/ar.' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'IFILM-ARABIC'
						elif '/en.' in TixSXhpW69Uba4f1NPqzYE7JcZ: mAH4aPy8q1w = 'IFILM-ENGLISH'
					cizdkEV5YN8tAIQyh4[mAH4aPy8q1w].append(gnmMTs3ArWXNhk1YP)
		for mAH4aPy8q1w in list(cizdkEV5YN8tAIQyh4.keys()):
			LrlbjXH0zvqfD8OKG6ZJ[mAH4aPy8q1w] = []
			ccvT1YX8zoHdyg0W[mAH4aPy8q1w] = []
			for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in cizdkEV5YN8tAIQyh4[mAH4aPy8q1w]:
				gnmMTs3ArWXNhk1YP = (oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
				if 'صفحة' in JHKDFe6Am0ruz8 and oJeO8LqTXi7W=='folder': ccvT1YX8zoHdyg0W[mAH4aPy8q1w].append(gnmMTs3ArWXNhk1YP)
				else: LrlbjXH0zvqfD8OKG6ZJ[mAH4aPy8q1w].append(gnmMTs3ArWXNhk1YP)
		WWcvAT4BD8m1rPVjoxufQZ,p1pjq2rst8mcbOaN = [],[]
		jXyoTFQzm6nYrabVHN8kg2vdR = list(LrlbjXH0zvqfD8OKG6ZJ.keys())
		llqoVr0WsTpyPx2duLz9OweifjRtK = uUa9cvTpySOLm2l(jXyoTFQzm6nYrabVHN8kg2vdR)
		oamxuyOJX7U1 = []
		for mAH4aPy8q1w in llqoVr0WsTpyPx2duLz9OweifjRtK:
			if 'tuple' in str(type(mAH4aPy8q1w)):
				oamxuyOJX7U1 = [mAH4aPy8q1w]
				continue
			if mAH4aPy8q1w not in Ksw1kNL0hSypE65oZM923TJ: continue
			if LrlbjXH0zvqfD8OKG6ZJ[mAH4aPy8q1w]:
				Zjw8iQxolcvY6tUfmahDkM = P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w)
				TTovlXzpHU3dY7Zb5G2s = [('link',D7INg5kyRjwf4ZtoePVUrb1h2SJ+'===== '+Zjw8iQxolcvY6tUfmahDkM+' ====='+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)]
				if 0: HHkXc7BhQ9OEygsTZUpG = hWGwxrcRzn0YqmkB3u6CEVl+' - '+'بحث'+Vwgflszp4WRA93kx6hvdua21HX5cOb+Zjw8iQxolcvY6tUfmahDkM
				else: HHkXc7BhQ9OEygsTZUpG = 'بحث'+Vwgflszp4WRA93kx6hvdua21HX5cOb+Zjw8iQxolcvY6tUfmahDkM+' - '+hWGwxrcRzn0YqmkB3u6CEVl
				if len(LrlbjXH0zvqfD8OKG6ZJ[mAH4aPy8q1w])<8: kKDS31mhnMyNwoWTrABvu = []
				else:
					luzIe3A2tG9xED4V0hSZci1d5pr = Whef0cxB2iR93SC5IwUtk+HHkXc7BhQ9OEygsTZUpG+kjd9LyNqQHMUevZiRI7OlBGF1h
					kKDS31mhnMyNwoWTrABvu = [('folder',Bc9jvpw5eoTd+luzIe3A2tG9xED4V0hSZci1d5pr,'closed_sites'+aqmiV6x7p2UKd9FseTgJCyjb,542,NdKhAS6MXVEORLTwob92pxlZ,mAH4aPy8q1w,hWGwxrcRzn0YqmkB3u6CEVl,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)]
				kVdwoTOvXiEg6W = LrlbjXH0zvqfD8OKG6ZJ[mAH4aPy8q1w]+ccvT1YX8zoHdyg0W[mAH4aPy8q1w]
				IEZYdtvUsJGqNW7kbmPHSRL1Xpr6Tj = oamxuyOJX7U1+TTovlXzpHU3dY7Zb5G2s+kVdwoTOvXiEg6W[:7]+kKDS31mhnMyNwoWTrABvu
				WWcvAT4BD8m1rPVjoxufQZ += IEZYdtvUsJGqNW7kbmPHSRL1Xpr6Tj
				PbdwQL04pxB6mNR = [('folder',Bc9jvpw5eoTd+HHkXc7BhQ9OEygsTZUpG,'closed_sites'+aqmiV6x7p2UKd9FseTgJCyjb,542,NdKhAS6MXVEORLTwob92pxlZ,mAH4aPy8q1w,hWGwxrcRzn0YqmkB3u6CEVl,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)]
				I2xgeCV7c0B5XuWhAOYbsmo8a = oamxuyOJX7U1+PbdwQL04pxB6mNR
				p1pjq2rst8mcbOaN += I2xgeCV7c0B5XuWhAOYbsmo8a
				eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DIVIDED'+t61tPbV7UWZ,(mAH4aPy8q1w,hWGwxrcRzn0YqmkB3u6CEVl),kVdwoTOvXiEg6W,KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
				oamxuyOJX7U1 = []
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_DETAILED'+t61tPbV7UWZ,hWGwxrcRzn0YqmkB3u6CEVl,WWcvAT4BD8m1rPVjoxufQZ,KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,hWGwxrcRzn0YqmkB3u6CEVl)
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,'GLOBALSEARCH_SPLITTED'+t61tPbV7UWZ,Bc9jvpw5eoTd+hWGwxrcRzn0YqmkB3u6CEVl,p1pjq2rst8mcbOaN,KxC8ewP4yTmq3lLj6voVfh7WNOX5H)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		MSXGKkNdgYe7xzu4pAL318TWF6VD = p1pjq2rst8mcbOaN if gtu9JS8Xr3njYI6WDCNpRUFdQ=='listed_sites'+aqmiV6x7p2UKd9FseTgJCyjb and p1pjq2rst8mcbOaN else WWcvAT4BD8m1rPVjoxufQZ
	if gtu9JS8Xr3njYI6WDCNpRUFdQ in ['listed_sites'+aqmiV6x7p2UKd9FseTgJCyjb,'opened_sites'+aqmiV6x7p2UKd9FseTgJCyjb,'closed_sites'+aqmiV6x7p2UKd9FseTgJCyjb]:
		for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG in MSXGKkNdgYe7xzu4pAL318TWF6VD:
			if gtu9JS8Xr3njYI6WDCNpRUFdQ in ['listed_sites'+aqmiV6x7p2UKd9FseTgJCyjb,'opened_sites'+aqmiV6x7p2UKd9FseTgJCyjb] and 'صفحة' in JHKDFe6Am0ruz8 and oJeO8LqTXi7W=='folder': continue
			ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,ui7N5YGR9KdslpEbQkVTwFqDgI,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	f2cgzj0TovI9YVl7tan1QkMS8(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
	return
def YXwEHj2ISqvfrAUb(search):
	llqoVr0WsTpyPx2duLz9OweifjRtK = uUa9cvTpySOLm2l(JuMxp2dLcDy6bj037awTvNIZ)
	for mAH4aPy8q1w in llqoVr0WsTpyPx2duLz9OweifjRtK:
		if '-' in mAH4aPy8q1w: continue
		if 'tuple' in str(type(mAH4aPy8q1w)):
			emiIH49XT6jzOQrw.append(mAH4aPy8q1w)
			continue
		QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
		name = P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w)+' - '+search
		ZI51XvE8YatWCmNdrp('folder',nwB7i5HsIz+name,mAH4aPy8q1w,548,'','',search)
	return
def U1aocSFD9eqz4uKCiRfh(mAH4aPy8q1w,search):
	QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = LLs7ZodwDpHNS2I(mAH4aPy8q1w)
	vbpSAKljzB4xR8UPkyY2whrVG(search)
	return
def Wv9EJeboacFK6XOwtVZfHDjNLdqIS():
	ZaUVqChKHwRLYbeiOv('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def TTzrQd43eEcxkigZWSyPlXn(hWGwxrcRzn0YqmkB3u6CEVl=NdKhAS6MXVEORLTwob92pxlZ):
	ffYWUsElBLFTDkmH1x,aPC0mLklY6jIUypFAwKbc,showDialogs = tSBXfikTvou6(hWGwxrcRzn0YqmkB3u6CEVl)
	if not ffYWUsElBLFTDkmH1x:
		ffYWUsElBLFTDkmH1x = Z6GiHgnz0jNytc()
		if not ffYWUsElBLFTDkmH1x: return
		ffYWUsElBLFTDkmH1x = ffYWUsElBLFTDkmH1x.lower()
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+'   Search For: [ '+ffYWUsElBLFTDkmH1x+' ]')
	n5pZARB2X0x8abLPeywMuHkqV = ffYWUsElBLFTDkmH1x+aPC0mLklY6jIUypFAwKbc
	if 0: RRHhn4pxK8MdfCA5ogFlrZOt,w3SqvRknuD6rTAx = ffYWUsElBLFTDkmH1x+' - ',NdKhAS6MXVEORLTwob92pxlZ
	else: RRHhn4pxK8MdfCA5ogFlrZOt,w3SqvRknuD6rTAx = NdKhAS6MXVEORLTwob92pxlZ,' - '+ffYWUsElBLFTDkmH1x
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'مواقع سيرفرات خاصة - قليلة المشاكل'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,157)
	ZI51XvE8YatWCmNdrp('folder','_M3U_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث M3U'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,719,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_IPT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث IPTV'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,239,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_BKR_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع بكرا'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,379,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_ART_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع تونز عربية'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,739,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_KRB_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع قناة كربلاء'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,329,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FH2_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فاصل الثاني'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,599,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_KTV_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع كتكوت تيفي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,819,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_EB1_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع ايجي بيست 1'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,779,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_EB2_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع ايجي بيست 2'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,789,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_IFL_'+RRHhn4pxK8MdfCA5ogFlrZOt+'  بحث موقع قناة آي فيلم'+w3SqvRknuD6rTAx+Uv7MkgVGyEbAlfFP0S8Zjqp2J,NdKhAS6MXVEORLTwob92pxlZ,29,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_AKO_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع أكوام القديم'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,79,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_AKW_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع أكوام الجديد'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,249,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_MRF_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع قناة المعارف'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,49,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SHM_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شوف ماكس'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,59,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,157)
	ZI51XvE8YatWCmNdrp('folder','_LRZ_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع لاروزا'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,709,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FJS_'+RRHhn4pxK8MdfCA5ogFlrZOt+' بحث موقع فجر شو'+w3SqvRknuD6rTAx+Vwgflszp4WRA93kx6hvdua21HX5cOb,NdKhAS6MXVEORLTwob92pxlZ,399,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_TVF_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع تيفي فان'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,469,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_LDN_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع لودي نت'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,459,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CMN_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما ناو'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,309,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SHN_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شاهد نيوز'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,589,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV+'_NODIALOGS_')
	ZI51XvE8YatWCmNdrp('folder','_ARS_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع عرب سييد'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,259,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CCB_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما كلوب'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,829,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SH4_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شاهد فوريو'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,119,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV+'_NODIALOGS_')
	ZI51XvE8YatWCmNdrp('folder','_SHT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شوفها تيفي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,649,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_WC1_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع وي سيما 1'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,569,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_WC2_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع وي سيما 2'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,1009,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'مواقع سيرفرات عامة - كثيرة المشاكل'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,157)
	ZI51XvE8YatWCmNdrp('folder','_TKT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع تكات'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,949,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FST_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فوستا'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,609,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FBK_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فبركة'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,629,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_YQT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع ياقوت'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,669,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SHB_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شبكتي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,969,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_VRB_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فاربون'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,879,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_BRS_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع برستيج'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,659,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_KRM_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع كرمالك'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,929,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_ANZ_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع انمي زد'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,979,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FSK_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فارسكو'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,999,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_HLC_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع هلا سيما'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,89,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_MST_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع المصطبة'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,869,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SNT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع شوف نت'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,849,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_DR7_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع دراما صح'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,689,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CFR_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما فري'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,839,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CMF_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما فانز'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,99,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CML_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما لايت'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,479,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_C4H_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما 400'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,699,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_ABD_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما عبدو'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,559,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_AKT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع اكوام تيوب'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,859,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_DCF_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع دراما كافيه'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,939,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FTV_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فوشار تيفي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,919,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_CWB_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما وبس'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,989,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_AHK_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع أهواك تيفي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,619,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_SRT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيريس تايم'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,899,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_FVD_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع فوشار فيديو'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,909,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_C4P_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع سيما فور بي'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,889,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_EB4_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع ايجي بيست 4'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,809,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+'مواقع سيرفرات خاصة - قليلة المشاكل'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,157)
	ZI51XvE8YatWCmNdrp('folder','_YUT_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع يوتيوب'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,149,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	ZI51XvE8YatWCmNdrp('folder','_DLM_'+RRHhn4pxK8MdfCA5ogFlrZOt+'بحث موقع دايلي موشن'+w3SqvRknuD6rTAx,NdKhAS6MXVEORLTwob92pxlZ,409,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,n5pZARB2X0x8abLPeywMuHkqV)
	return
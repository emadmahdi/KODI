# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'MOVIZLAND'
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
LJfTAEQPv9h4BXdwUp = '_MVZ_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
PPma30ybADqJNu = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][1]
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==180: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==181: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==182: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==183: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==188: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = L81DhZI6SA()
	elif mode==189: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def L81DhZI6SA():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج',message)
	return
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,189,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'بوكس اوفيس موفيز لاند',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,181,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'box-office')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أحدث الافلام',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,181,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'latest-movies')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'تليفزيون موفيز لاند',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,181,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'tv')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الاكثر مشاهدة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,181,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'top-views')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أقوى الافلام الحالية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,181,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'top-movies')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-MENU-1st')
	items = YYqECUofyi7wFrW.findall('<h2><a href="(.*?)".*?">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,181)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	elif type=='box-office': AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	elif type=='top-movies': AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('btn-2-overlay(.*?)<style>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	elif type=='top-views': AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	elif type=='tv': AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	else: AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
	if type in ['top-views','top-movies']:
		items = YYqECUofyi7wFrW.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	else: items = YYqECUofyi7wFrW.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	RnWCFcXJeB7Sv = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for TTuPH708dUNnjlG3oQpkZsi,IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72,p84GZVnd7xeHMbR3WAtBN2h6EaK0 in items:
		if type in ['top-views','top-movies']:
			TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,xKXbWz9coR7jUfil45aQENr0ICBJg,title = TTuPH708dUNnjlG3oQpkZsi,IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72,p84GZVnd7xeHMbR3WAtBN2h6EaK0
		else: TTuPH708dUNnjlG3oQpkZsi,title,zehVcU893FC6LEd1Aij,xKXbWz9coR7jUfil45aQENr0ICBJg = TTuPH708dUNnjlG3oQpkZsi,IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72,p84GZVnd7xeHMbR3WAtBN2h6EaK0
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij)
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('?view=true',NdKhAS6MXVEORLTwob92pxlZ)
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',NdKhAS6MXVEORLTwob92pxlZ).replace('بجوده ',NdKhAS6MXVEORLTwob92pxlZ)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'الحلقة' in title or 'الحلقه' in title:
			N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|الحلقه) \d+',title,YYqECUofyi7wFrW.DOTALL)
			if N1VjdbtuO3z:
				title = '_MOD_' + N1VjdbtuO3z[0][0]
				if title not in zIDPZSNn1OuweLHvmMKb6d:
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,183,TTuPH708dUNnjlG3oQpkZsi)
					zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in RnWCFcXJeB7Sv):
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij + '?servers=' + xKXbWz9coR7jUfil45aQENr0ICBJg
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,182,TTuPH708dUNnjlG3oQpkZsi)
		else:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij + '?servers=' + xKXbWz9coR7jUfil45aQENr0ICBJg
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,183,TTuPH708dUNnjlG3oQpkZsi)
	if type==NdKhAS6MXVEORLTwob92pxlZ:
		items = YYqECUofyi7wFrW.findall('\n<li><a href="(.*?)".*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
			if title!=NdKhAS6MXVEORLTwob92pxlZ:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,181)
	return
def vl57jIYC4a(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url.split('?servers=')[0]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-EPISODES-1st')
	AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	title,gHbS3MaYo0j6uTdm2qyQnKP,TTuPH708dUNnjlG3oQpkZsi = AAMHoYxRCmt2D6ph89W[0]
	name = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,YYqECUofyi7wFrW.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="episodesNumbers"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij in items:
			zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij)
			title = YYqECUofyi7wFrW.findall('(الحلقة|الحلقه)-([0-9]+)',zehVcU893FC6LEd1Aij.split('/')[-2],YYqECUofyi7wFrW.DOTALL)
			if not title: title = YYqECUofyi7wFrW.findall('()-([0-9]+)',zehVcU893FC6LEd1Aij.split('/')[-2],YYqECUofyi7wFrW.DOTALL)
			if title: title = Vwgflszp4WRA93kx6hvdua21HX5cOb + title[0][1]
			else: title = NdKhAS6MXVEORLTwob92pxlZ
			title = name + ' - ' + 'الحلقة' + title
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,182,TTuPH708dUNnjlG3oQpkZsi)
	if not items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',NdKhAS6MXVEORLTwob92pxlZ).replace('بجوده ',NdKhAS6MXVEORLTwob92pxlZ)
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,182,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	myEZsYk69Jj02AKPHQ7zgdh3VtU4I = url.split('?servers=')
	BfjcMoqOsmdUvZVCHWIyQKi = myEZsYk69Jj02AKPHQ7zgdh3VtU4I[0]
	del myEZsYk69Jj02AKPHQ7zgdh3VtU4I[0]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-PLAY-1st')
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('font-size: 25px;" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	if zehVcU893FC6LEd1Aij not in myEZsYk69Jj02AKPHQ7zgdh3VtU4I: myEZsYk69Jj02AKPHQ7zgdh3VtU4I.append(zehVcU893FC6LEd1Aij)
	UTwH7zjZOrmFl = []
	for zehVcU893FC6LEd1Aij in myEZsYk69Jj02AKPHQ7zgdh3VtU4I:
		if '://moshahda.' in zehVcU893FC6LEd1Aij:
			SaZ5osUmTV9b4Mnz3 = zehVcU893FC6LEd1Aij
			UTwH7zjZOrmFl.append(SaZ5osUmTV9b4Mnz3+'?named=Main')
	for zehVcU893FC6LEd1Aij in myEZsYk69Jj02AKPHQ7zgdh3VtU4I:
		if '://vb.movizland.' in zehVcU893FC6LEd1Aij:
			LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-PLAY-2nd')
			LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.decode('windows-1256').encode(YRvPKe2zMTDs8UCkr)
			LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
				sqa5mP1EXFHu2fR3Ar7yelgp,xGMCcl8P0dqYyXFwnE4JNRjH = [],[]
				if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)==1:
					title = NdKhAS6MXVEORLTwob92pxlZ
					AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
				else:
					for AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
						zyoNRs5F72Bkr0JYfGh6PULju4bO = YYqECUofyi7wFrW.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						if zyoNRs5F72Bkr0JYfGh6PULju4bO: AAMHoYxRCmt2D6ph89W = 'src="/uploads/13721411411.png"  \n  ' + zyoNRs5F72Bkr0JYfGh6PULju4bO[0][1]
						zyoNRs5F72Bkr0JYfGh6PULju4bO = YYqECUofyi7wFrW.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						if zyoNRs5F72Bkr0JYfGh6PULju4bO: AAMHoYxRCmt2D6ph89W = 'src="/uploads/13721411411.png"  \n  ' + zyoNRs5F72Bkr0JYfGh6PULju4bO[0]
						zyoNRs5F72Bkr0JYfGh6PULju4bO = YYqECUofyi7wFrW.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						if zyoNRs5F72Bkr0JYfGh6PULju4bO: AAMHoYxRCmt2D6ph89W = zyoNRs5F72Bkr0JYfGh6PULju4bO[0] + '  \n  src="/uploads/13721411411.png"'
						zM9nGj0YOgs = YYqECUofyi7wFrW.findall('<(.*?)http://up.movizland.(online|com)/uploads/',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						title = YYqECUofyi7wFrW.findall('> *([^<>]+) *<',zM9nGj0YOgs[0][0],YYqECUofyi7wFrW.DOTALL)
						title = Vwgflszp4WRA93kx6hvdua21HX5cOb.join(title)
						title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
						title = title.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
						sqa5mP1EXFHu2fR3Ar7yelgp.append(title)
					rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('أختر الفيديو المطلوب:', sqa5mP1EXFHu2fR3Ar7yelgp)
					if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
					title = sqa5mP1EXFHu2fR3Ar7yelgp[rRfpvbZojlygET5JL87wdzIPGe]
					AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[rRfpvbZojlygET5JL87wdzIPGe]
				zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('href="(http://moshahda\..*?/\w+.html)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				Qzn6OExqlSd = zehVcU893FC6LEd1Aij[0]
				UTwH7zjZOrmFl.append(Qzn6OExqlSd+'?named=Forum')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('ـ',NdKhAS6MXVEORLTwob92pxlZ)
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				lbWr2PBYQdksVDN15m = YYqECUofyi7wFrW.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				for lEQPNyLIs3n4XG0vx6 in lbWr2PBYQdksVDN15m:
					type = YYqECUofyi7wFrW.findall(' typetype="(.*?)" ',lEQPNyLIs3n4XG0vx6)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = NdKhAS6MXVEORLTwob92pxlZ
					items = YYqECUofyi7wFrW.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',lEQPNyLIs3n4XG0vx6,YYqECUofyi7wFrW.DOTALL)
					for x9xlM3jhuw2gC0cVSiUJnasNb,zehVcU893FC6LEd1Aij in items:
						title = YYqECUofyi7wFrW.findall('(\w+[ \w]*)<',x9xlM3jhuw2gC0cVSiUJnasNb)
						title = title[-1]
						zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij + '?named=' + title + type
						UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi.replace(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,PPma30ybADqJNu)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-PLAY-3rd')
	items = YYqECUofyi7wFrW.findall('" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		BCjJWuEGPqb = items[-1]
		UTwH7zjZOrmFl.append(BCjJWuEGPqb+'?named=Mobile')
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'MOVIZLAND-SEARCH-1st')
	items = YYqECUofyi7wFrW.findall('<option value="(.*?)">(.*?)</option>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	Fv6aESNicC0tWkgswGJ3VU = [ NdKhAS6MXVEORLTwob92pxlZ ]
	NnFCtc1X6syKOTM = [ 'الكل وبدون فلتر' ]
	for II4s1CdgcbN6BSvWPnHtz,title in items:
		Fv6aESNicC0tWkgswGJ3VU.append(II4s1CdgcbN6BSvWPnHtz)
		NnFCtc1X6syKOTM.append(title)
	if II4s1CdgcbN6BSvWPnHtz:
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر الفلتر المناسب:', NnFCtc1X6syKOTM)
		if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
		II4s1CdgcbN6BSvWPnHtz = Fv6aESNicC0tWkgswGJ3VU[rRfpvbZojlygET5JL87wdzIPGe]
	else: II4s1CdgcbN6BSvWPnHtz = NdKhAS6MXVEORLTwob92pxlZ
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/?s='+search+'&mcat='+II4s1CdgcbN6BSvWPnHtz
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
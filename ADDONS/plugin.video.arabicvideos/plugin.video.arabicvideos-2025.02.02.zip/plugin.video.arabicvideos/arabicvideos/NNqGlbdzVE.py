# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'EGYNOW'
LJfTAEQPv9h4BXdwUp = '_EGN_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==430: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==431: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==432: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==433: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==434: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==437: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = xSf6MDCKGg0(url)
	elif mode==439: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/films',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = YYqECUofyi7wFrW.findall('"canonical" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	REGxsWAoilB7dCFNgMhz0V98bcm = REGxsWAoilB7dCFNgMhz0V98bcm[0].strip('/')
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(REGxsWAoilB7dCFNgMhz0V98bcm,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,439,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',REGxsWAoilB7dCFNgMhz0V98bcm,435)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',REGxsWAoilB7dCFNgMhz0V98bcm,434)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المضاف حديثا',REGxsWAoilB7dCFNgMhz0V98bcm,431)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'افلام اون لاين',REGxsWAoilB7dCFNgMhz0V98bcm+'/films1',436)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات اون لاين',REGxsWAoilB7dCFNgMhz0V98bcm+'/series-all1',436)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'قائمة تفصيلية',REGxsWAoilB7dCFNgMhz0V98bcm,437)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"SiteNavigation"(.*?)"Search"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,431)
	return
def xSf6MDCKGg0(website=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',website+'/films',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = YYqECUofyi7wFrW.findall('"canonical" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	REGxsWAoilB7dCFNgMhz0V98bcm = REGxsWAoilB7dCFNgMhz0V98bcm[0].strip('/')
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(REGxsWAoilB7dCFNgMhz0V98bcm,'url')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"ListDroped"(.*?)"SearchingMaster"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for II4s1CdgcbN6BSvWPnHtz,K6KbZDHncNizQgl1fr59XV0,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		zehVcU893FC6LEd1Aij = website+'/explore/?'+II4s1CdgcbN6BSvWPnHtz+'='+K6KbZDHncNizQgl1fr59XV0
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,431)
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-SUBMENU-1st')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',url,431)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"titleSectionCon"(.*?)</div></div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-key="(.*?)".*?<em>(.*?)</em>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for mfVtpzhI3WGnAx0,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		BfjcMoqOsmdUvZVCHWIyQKi = REGxsWAoilB7dCFNgMhz0V98bcm+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+mfVtpzhI3WGnAx0
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,BfjcMoqOsmdUvZVCHWIyQKi,431)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-TITLES-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
	elif kF13d0oJXn4xKH=='featured':
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-TITLES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"MainSlider"(.*?)"MatchesTable"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-TITLES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"BlocksList"(.*?)"Paginate"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"BlocksList"(.*?)"titleSectionCon"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not items: items = YYqECUofyi7wFrW.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,432,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'الحلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,433,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/movseries/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,431,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,433,TTuPH708dUNnjlG3oQpkZsi)
	if kF13d0oJXn4xKH!='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"Paginate"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
				zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,431)
		ZZvTe8pmBr1buPwaj9N = YYqECUofyi7wFrW.findall('showmore" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if ZZvTe8pmBr1buPwaj9N:
			zehVcU893FC6LEd1Aij = ZZvTe8pmBr1buPwaj9N[0]
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مشاهدة المزيد',zehVcU893FC6LEd1Aij,431)
	return
def vl57jIYC4a(url):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	yyuOVAGPZijetcaNz0b,gcBxGPatZIzQ1 = [],[]
	if 'Episodes.php' in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-EPISODES-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		gcBxGPatZIzQ1 = [LMKFcEkU1Q7R80yt4OsgvwxbfP]
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-EPISODES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"SeasonsList"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"EpisodesList"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b:
		TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"og:image" content="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for bbxoFf2lTX1SYcVELZB8pWIsiCr,o3Uxe7yjMNh8mil21gqEVbtK,title in items:
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+o3Uxe7yjMNh8mil21gqEVbtK+'&post_id='+bbxoFf2lTX1SYcVELZB8pWIsiCr
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,433,TTuPH708dUNnjlG3oQpkZsi)
	elif gcBxGPatZIzQ1:
		TTuPH708dUNnjlG3oQpkZsi = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Thumb')
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,N1VjdbtuO3z in items:
			title = title+Vwgflszp4WRA93kx6hvdua21HX5cOb+N1VjdbtuO3z
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,432,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url+'/watch/'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	UTwH7zjZOrmFl = []
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,'url')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"container-servers"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		F8nsaPk2UKYHzG7EMB4cSXlrVpdv = YYqECUofyi7wFrW.findall('data-id="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if F8nsaPk2UKYHzG7EMB4cSXlrVpdv:
			F8nsaPk2UKYHzG7EMB4cSXlrVpdv = F8nsaPk2UKYHzG7EMB4cSXlrVpdv[0]
			items = YYqECUofyi7wFrW.findall('data-server="(.*?)".*?<span>(.*?)</span>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for oikt6P0hOAD5IvnlMpxf1,title in items:
				zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+oikt6P0hOAD5IvnlMpxf1+'&post_id='+F8nsaPk2UKYHzG7EMB4cSXlrVpdv+'?named='+title+'__watch'
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	kxClD5nyIRtBhEmKXGW8cj = YYqECUofyi7wFrW.findall('"container-iframe"><iframe src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if kxClD5nyIRtBhEmKXGW8cj:
		kxClD5nyIRtBhEmKXGW8cj = kxClD5nyIRtBhEmKXGW8cj[0].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
		title = msbTrJW03xuvA(kxClD5nyIRtBhEmKXGW8cj,'name')
		zehVcU893FC6LEd1Aij = kxClD5nyIRtBhEmKXGW8cj+'?named='+title+'__embed'
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"container-download"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,a0ao2jdlt4r9nhHwpvSgOVGA in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
			if a0ao2jdlt4r9nhHwpvSgOVGA!=NdKhAS6MXVEORLTwob92pxlZ: a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'+a0ao2jdlt4r9nhHwpvSgOVGA
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def oDejqO6uYrsWp5ym9TQtEdV(url):
	url = url.split('/smartemadfilter?')[0]
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',REGxsWAoilB7dCFNgMhz0V98bcm,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('("dropdown-button".*?)"SearchingMaster"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return Hk9cy1IL0PXCw3OgYE5nr
def nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W):
	items = YYqECUofyi7wFrW.findall('data-term="(\d+)" data-name="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return items
def WW6XmdChlOPbY(url):
	p9pPoLdYMbqwXz1FQraUxKNv35 = url.split('/smartemadfilter?')[0]
	Q5Jbsopg4HhxqTY = msbTrJW03xuvA(url,'url')
	url = url.replace(p9pPoLdYMbqwXz1FQraUxKNv35,Q5Jbsopg4HhxqTY)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def WybQ5S8RXk37df1qDm(g7jQ4ZX1quCJ,url):
	AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'modified_filters')
	Afey3cL4ojzg = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	Afey3cL4ojzg = WW6XmdChlOPbY(Afey3cL4ojzg)
	return Afey3cL4ojzg
axsbpdckhGP127u5wEgnZtV4LWvzli = ['category','country','genre','release-year']
dW42o7vIOrS9wu = ['quality','release-year','genre','category','language','country']
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='ALL_ITEMS_FILTER':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+Jv2yebcHLo5GCrXZlw
		BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',BfjcMoqOsmdUvZVCHWIyQKi,431)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,431)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Hk9cy1IL0PXCw3OgYE5nr = oDejqO6uYrsWp5ym9TQtEdV(url)
	dict = {}
	for name,AAMHoYxRCmt2D6ph89W,zZ0VrYRv6m8 in Hk9cy1IL0PXCw3OgYE5nr:
		name = name.replace('--',NdKhAS6MXVEORLTwob92pxlZ)
		items = nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='SPECIFIED_FILTER':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<2:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]:
					url = WW6XmdChlOPbY(url)
					hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'SPECIFIED_FILTER___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',BfjcMoqOsmdUvZVCHWIyQKi,431)
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',BfjcMoqOsmdUvZVCHWIyQKi,435,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='ALL_ITEMS_FILTER':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع :'+name,BfjcMoqOsmdUvZVCHWIyQKi,434,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if K6KbZDHncNizQgl1fr59XV0=='196533': X9dRM31pz6y = 'أفلام نيتفلكس'
			elif K6KbZDHncNizQgl1fr59XV0=='196531': X9dRM31pz6y = 'مسلسلات نيتفلكس'
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' :'#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' :'+name
			if type=='ALL_ITEMS_FILTER': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,434,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='SPECIFIED_FILTER' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				Afey3cL4ojzg = WybQ5S8RXk37df1qDm(g7jQ4ZX1quCJ,url)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,431)
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,435,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.replace('=&','=0&')
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all_filters': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('=0','=')
	return LaGtUDiK2xnfz
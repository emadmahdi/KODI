# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from clTCF7gUfL import *
yNIDEX5hU4G769 = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡌࡒࡎ࡚ࠧᄵ")
l03zGijuvOMfKbHRkNgTLtBWwXhrQ = hCm2fnEXs6Zt(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠪᄶ")
GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
iy8Ymsp0GMPVdSWTBR = int(DDq6xNzlMYK)
TWqGAlsD0bpihcwOB3FLfYKMdxgC = ACOWB6GRmIbDKyl3Zn.getInfoLabel(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬᄷ"))
TWqGAlsD0bpihcwOB3FLfYKMdxgC = TWqGAlsD0bpihcwOB3FLfYKMdxgC.replace(MgDNZ1f34w,NdKhAS6MXVEORLTwob92pxlZ).replace(iy0rIHuvaAgpbjRKnTQcJwLVs,NdKhAS6MXVEORLTwob92pxlZ)
if iy8Ymsp0GMPVdSWTBR==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠲࠷࠲ᅝ"): Bm3MUtIwVFH0iL19Je2oxb = HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ᄸ")+lvsJ2jaZktmNO6PbdXS+Hlp3z0APt1GR4kMYK5xST(u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭ᄹ")+dor6Z1x9CvBpQgKTG38bYtJ+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࠡ࡟ࠪᄺ")
else:
	dKZC7XDkuJSbWc = OOFEmwq2GkTz93WXy1Nj(RAHOMksyDUV3w7T1QjqKNX).replace(Whef0cxB2iR93SC5IwUtk,NdKhAS6MXVEORLTwob92pxlZ).replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,NdKhAS6MXVEORLTwob92pxlZ)
	dKZC7XDkuJSbWc = dKZC7XDkuJSbWc.replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	dKZC7XDkuJSbWc = dKZC7XDkuJSbWc.replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	Bm3MUtIwVFH0iL19Je2oxb = xY4icgQUj6mPVs73CTKu(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧᄻ")+TWqGAlsD0bpihcwOB3FLfYKMdxgC+Hlp3z0APt1GR4kMYK5xST(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩᄼ")+DDq6xNzlMYK+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪᄽ")+dKZC7XDkuJSbWc+kb2icmDGVUZfW1OFz7sv(u"ࠫࠥࡣࠧᄾ")
LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,l03zGijuvOMfKbHRkNgTLtBWwXhrQ+B6IrC7zEHlw1oaeWf+BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Bm3MUtIwVFH0iL19Je2oxb)
if rNyT0edugn(u"ࠬࡥࠧᄿ") in IGar1Z3F8lNX: bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B = IGar1Z3F8lNX.split(QQHFtjcaR2VpnSyTIv(u"࠭࡟ࠨᅀ"),JGwsL21ZRlqSrWxEmF(u"࠲ᅞ"))
else: bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B = IGar1Z3F8lNX,NdKhAS6MXVEORLTwob92pxlZ
lfcLCw603F8yDeIpTxnjNh9UqA2Z,ihuUeAVfaSbXMNn = f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ
if bEnO2mwHB8r4fZ in [JGwsL21ZRlqSrWxEmF(u"ࠧ࠲ࠩᅁ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨ࠴ࠪᅂ"),V0VZk9763fusTReHFo4(u"ࠩ࠶ࠫᅃ"),QQHFtjcaR2VpnSyTIv(u"ࠪ࠸ࠬᅄ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫ࠺࠭ᅅ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࠷࠱ࠨᅆ"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠭࠱࠳ࠩᅇ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧ࠲࠵ࠪᅈ")] and (YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡃࡇࡈࠬᅉ") in Ixf7NQG9J3ZTPbcSls42B or vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡕࡉࡒࡕࡖࡆࠩᅊ") in Ixf7NQG9J3ZTPbcSls42B or Hlp3z0APt1GR4kMYK5xST(u"࡙ࠪࡕ࠭ᅋ") in Ixf7NQG9J3ZTPbcSls42B or HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡉࡕࡗࡏࠩᅌ") in Ixf7NQG9J3ZTPbcSls42B):
	from LSQvu5zPa6 import uvTkyDmO9M48VN2xfXFgUeZ
	uvTkyDmO9M48VN2xfXFgUeZ(IGar1Z3F8lNX,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(eGW7cI6aQhr0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᅍ"),RAHOMksyDUV3w7T1QjqKNX)
	lfcLCw603F8yDeIpTxnjNh9UqA2Z = k6apiPAlLKM1ed8J42RjHh0o
elif not INCQEvfcLSX3ah7V4WHilmdZKGB and iy8Ymsp0GMPVdSWTBR in [rNyT0edugn(u"࠴࠶࠹ᅟ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠺࠵࠺ᅠ")]:
	ODnPkfW6des = str(BIlmnRhJjQAFyoeNYOzT67pHDrG[rNyT0edugn(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅎ")])
	yNIDEX5hU4G769 = lRP6GTaZJA1Xw3egLM4(u"ࠧࡊࡒࡗ࡚ࠬᅏ") if iy8Ymsp0GMPVdSWTBR==Tzx81Wb0RZC4ID5AyiU2(u"࠶࠸࠻ᅡ") else NOrchaEV1iIZ87Uzlwgum(u"ࠨࡏ࠶࡙ࠬᅐ")
	BRcCF3isYPjD9NWI5o7pJHK2un = yNIDEX5hU4G769.lower()
	VVBkbI2DtyaWw6mQp0 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(NOrchaEV1iIZ87Uzlwgum(u"ࠩࡤࡺ࠳࠭ᅑ")+BRcCF3isYPjD9NWI5o7pJHK2un+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨᅒ")+ODnPkfW6des)
	rDOMITncUW9pB8ktAQS2 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(V0VZk9763fusTReHFo4(u"ࠫࡦࡼ࠮ࠨᅓ")+BRcCF3isYPjD9NWI5o7pJHK2un+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨᅔ")+ODnPkfW6des)
	if VVBkbI2DtyaWw6mQp0 or rDOMITncUW9pB8ktAQS2:
		ZZT6GLaHQ1 += Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡼࠨᅕ")
		if VVBkbI2DtyaWw6mQp0: ZZT6GLaHQ1 += WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᅖ")+VVBkbI2DtyaWw6mQp0
		if rDOMITncUW9pB8ktAQS2: ZZT6GLaHQ1 += HVmIrFwau90jQsgiWzExk(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᅗ")+rDOMITncUW9pB8ktAQS2
		ZZT6GLaHQ1 = ZZT6GLaHQ1.replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡿࠪࠬᅘ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠪࢀࠬᅙ"))
	TIVBkW1tiL = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡦࡼ࠮ࠨᅚ")+BRcCF3isYPjD9NWI5o7pJHK2un+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧᅛ")+ODnPkfW6des)
	if TIVBkW1tiL:
		PYVz5xgS3ik0TRuXDHj = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩᅜ"),ZZT6GLaHQ1,YYqECUofyi7wFrW.DOTALL)
		ZZT6GLaHQ1 = ZZT6GLaHQ1.replace(PYVz5xgS3ik0TRuXDHj[e8XhbyuzvjYkIsJUtB5w],TIVBkW1tiL)
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(ZZT6GLaHQ1,yNIDEX5hU4G769,GY9jgon6yhP0IvtCBEJu3)
else:
	import PNC7bFKMI6
	try: PNC7bFKMI6.NkJLtbG8DcSgEm6sMw90Tuv(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B,TWqGAlsD0bpihcwOB3FLfYKMdxgC)
	except Exception as XvUfhH2qm6TMaw5bl9WVO1B: ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
	lfcLCw603F8yDeIpTxnjNh9UqA2Z = PNC7bFKMI6.lfcLCw603F8yDeIpTxnjNh9UqA2Z
DG54yfbLoBUCISVh6FkXmvtK9rzQjn(lfcLCw603F8yDeIpTxnjNh9UqA2Z,ihuUeAVfaSbXMNn)
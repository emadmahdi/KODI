# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'LAROZA'
LJfTAEQPv9h4BXdwUp = '_LRZ_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==700: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==701: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==702: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==703: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = o2XkvGWlaVzsUjdDLbQpg8(url,text)
	elif mode==704: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==709: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	REGxsWAoilB7dCFNgMhz0V98bcm = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',REGxsWAoilB7dCFNgMhz0V98bcm,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,709,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المسلسلات',REGxsWAoilB7dCFNgMhz0V98bcm+'/moslslat.php',701)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pm-top-nav"(.*?)class="hidden',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		title = title.replace('<b>',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if 'javascrip' in zehVcU893FC6LEd1Aij: continue
		if 'class=' in zehVcU893FC6LEd1Aij: continue
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,704)
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	NElpa837fkWBKeqY = False
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('role="menu"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('"presentation"','</ul>')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [(NdKhAS6MXVEORLTwob92pxlZ,AAMHoYxRCmt2D6ph89W)]
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' فرز أو فلتر أو ترتيب '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		for MKUGqBYspa2ALPwc1,AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if MKUGqBYspa2ALPwc1: MKUGqBYspa2ALPwc1 = MKUGqBYspa2ALPwc1+': '
			for zehVcU893FC6LEd1Aij,title in items:
				title = MKUGqBYspa2ALPwc1+title
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,701)
				NElpa837fkWBKeqY = True
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"pm-category-subcats"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if len(items)<30:
			if NElpa837fkWBKeqY: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
			for zehVcU893FC6LEd1Aij,title in items:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,701)
				NElpa837fkWBKeqY = True
	PPkFzM036KoU = YYqECUofyi7wFrW.findall('class="catfootr"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if 0 and PPkFzM036KoU:
		AAMHoYxRCmt2D6ph89W = PPkFzM036KoU[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if 1:
			if NElpa837fkWBKeqY: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
			for zehVcU893FC6LEd1Aij,title in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,701)
				NElpa837fkWBKeqY = True
	if not NElpa837fkWBKeqY: hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	if kF13d0oJXn4xKH=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-TITLES-1st')
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-TITLES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	AAMHoYxRCmt2D6ph89W,items = NdKhAS6MXVEORLTwob92pxlZ,[]
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	if kF13d0oJXn4xKH=='ajax-search':
		AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	elif kF13d0oJXn4xKH=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('id="content"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_episodes':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)>1: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	elif kF13d0oJXn4xKH=='featured_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"ba mgb table full"(.*?)"clearfix"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('("thumbnail".*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if AAMHoYxRCmt2D6ph89W and not items: items = YYqECUofyi7wFrW.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items: return
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة).\d+',title,YYqECUofyi7wFrW.DOTALL)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,702,TTuPH708dUNnjlG3oQpkZsi)
		elif kF13d0oJXn4xKH=='new_episodes':
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,702,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z:
			title = '_MOD_' + N1VjdbtuO3z[0][0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,703,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,703,TTuPH708dUNnjlG3oQpkZsi)
	if 1:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if '?' in url: url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC = url.split('?',1)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=='#': continue
				zehVcU893FC6LEd1Aij = url+zehVcU893FC6LEd1Aij
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,701)
	return
def o2XkvGWlaVzsUjdDLbQpg8(url,ck82Wb9aGlYMsEImj):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-EPISODES_SEASONS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	k1ChwgueU5nbDX6K0BOEGx = YYqECUofyi7wFrW.findall('"series-header".*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if k1ChwgueU5nbDX6K0BOEGx: TTuPH708dUNnjlG3oQpkZsi = k1ChwgueU5nbDX6K0BOEGx[0]
	else: TTuPH708dUNnjlG3oQpkZsi = NdKhAS6MXVEORLTwob92pxlZ
	items = []
	UwIYTGWyjosc6pikf48xLe5du = False
	if yyuOVAGPZijetcaNz0b and not ck82Wb9aGlYMsEImj:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not items: items = YYqECUofyi7wFrW.findall('data-serie="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for ck82Wb9aGlYMsEImj,title in items:
			ck82Wb9aGlYMsEImj = ck82Wb9aGlYMsEImj.strip('#')
			if len(items)>1: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,703,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,ck82Wb9aGlYMsEImj)
			else: UwIYTGWyjosc6pikf48xLe5du = True
	else: UwIYTGWyjosc6pikf48xLe5du = True
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"SeasonsEpisodesMain(.*?)<script>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6 and UwIYTGWyjosc6pikf48xLe5du:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall("`season_slug` = '"+ck82Wb9aGlYMsEImj+"'(.*?)</div>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if gcBxGPatZIzQ1: AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		else:
			BfjcMoqOsmdUvZVCHWIyQKi = REGxsWAoilB7dCFNgMhz0V98bcm+'/fetch_episodes.php'
			data = 'seasonId='+YUkzG2ymNSqdon(ck82Wb9aGlYMsEImj)
			headers = {'Content-Type':'application/x-www-form-urlencoded'}
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',BfjcMoqOsmdUvZVCHWIyQKi,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-EPISODES_SEASONS-2nd')
			AAMHoYxRCmt2D6ph89W = VNc1u4edS90FK5W6bsMgQC2B.content
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('''href=['"](.*?)['"]><em>(.*?)</span>''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not APRuYMmlIVGTX: APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)"><em>(.*?)</span>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		items = []
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi))
		if not items: items = YYqECUofyi7wFrW.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.strip('./')
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
			title = title.replace('</em><span>',Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,702,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp,ttFMHI9QPiN = [],[]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = ''
	if 'post=' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('id="player".*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
		bbxoFf2lTX1SYcVELZB8pWIsiCr = zehVcU893FC6LEd1Aij.split('post=')[1]
		bbxoFf2lTX1SYcVELZB8pWIsiCr = NHsYdVBpXn.b64decode(bbxoFf2lTX1SYcVELZB8pWIsiCr)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: bbxoFf2lTX1SYcVELZB8pWIsiCr = bbxoFf2lTX1SYcVELZB8pWIsiCr.decode(YRvPKe2zMTDs8UCkr)
		bbxoFf2lTX1SYcVELZB8pWIsiCr = BdnA8WwtJeKUVvE('dict',bbxoFf2lTX1SYcVELZB8pWIsiCr)
		oDhlaxn0EqyYikcHrmZBN8uv = bbxoFf2lTX1SYcVELZB8pWIsiCr['servers']
		DDviHT4pFVhgwaL = list(oDhlaxn0EqyYikcHrmZBN8uv.keys())
		oDhlaxn0EqyYikcHrmZBN8uv = list(oDhlaxn0EqyYikcHrmZBN8uv.values())
		hRfSE2oyUgL1XIAws49p8O3aWl = zip(DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv)
		for title,zehVcU893FC6LEd1Aij in hRfSE2oyUgL1XIAws49p8O3aWl:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	else:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace('video.php','play.php')
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LAROZA-PLAY-1st')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('"embedded" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
			if zehVcU893FC6LEd1Aij not in ttFMHI9QPiN:
				ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
				title = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__embed'
				Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pm-servers"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<script(.*?)</script',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
				AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
				if 'function(h,u,n,t,e,r)' in AAMHoYxRCmt2D6ph89W:
					AAMHoYxRCmt2D6ph89W = nadz1WI5ZUCSpYGJvNMAK(AAMHoYxRCmt2D6ph89W)
					AAMHoYxRCmt2D6ph89W = YYqECUofyi7wFrW.findall("encodedHtml = '(.*?)'",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
					if AAMHoYxRCmt2D6ph89W:
						AAMHoYxRCmt2D6ph89W = NHsYdVBpXn.b64decode(AAMHoYxRCmt2D6ph89W[0])
						if J92gCnbGWidQV70lBteTwU6D8uyzL: AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.decode(YRvPKe2zMTDs8UCkr)
						items = YYqECUofyi7wFrW.findall('data-name="(.*?)".*?data-embed="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
						for title,zehVcU893FC6LEd1Aij in items:
							if zehVcU893FC6LEd1Aij not in ttFMHI9QPiN:
								ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
								zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
								Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
		if 'pm-download' not in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			BfjcMoqOsmdUvZVCHWIyQKi = url.replace('video.php','download.php')
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,False,'LAROZA-PLAY-2nd')
			LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pm-download(.*?)"content"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<script(.*?)</script',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
				AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
				if 'function(h,u,n,t,e,r)' in AAMHoYxRCmt2D6ph89W:
					AAMHoYxRCmt2D6ph89W = nadz1WI5ZUCSpYGJvNMAK(AAMHoYxRCmt2D6ph89W)
					zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('"(http.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
					if zehVcU893FC6LEd1Aij:
						zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
						if zehVcU893FC6LEd1Aij not in ttFMHI9QPiN:
							ttFMHI9QPiN.append(zehVcU893FC6LEd1Aij)
							title = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,'name')
							zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'
							Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search.php?keywords='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
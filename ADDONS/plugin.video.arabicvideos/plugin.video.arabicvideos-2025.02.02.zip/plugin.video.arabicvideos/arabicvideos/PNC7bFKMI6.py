# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from clTCF7gUfL import *
import base64 as NHsYdVBpXn
yNIDEX5hU4G769 = rNyT0edugn(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪச")
emiIH49XT6jzOQrw,yZLFCImoREnkBv,BDG2gRTNFL37J6P5i = [],{},{}
lfcLCw603F8yDeIpTxnjNh9UqA2Z = f4vncKMRlXG9s
if J92gCnbGWidQV70lBteTwU6D8uyzL:
	ffJYyPuQ6WVvd795NnzRCx3slSB = ArK8Tohfy6wG.translatePath(OOkmZiVcfqlEurM1dHGb(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ஛"))
	YbDTMedqwUi9r4Jax = ArK8Tohfy6wG.translatePath(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬஜ"))
	tzFpPxC3jfygiWQE5HORvXJ6cmTwlu = ArK8Tohfy6wG.translatePath(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ஝"))
	F9yN4TRdQclxaBGWt6rpSKwkJ = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஞ"),lRP6GTaZJA1Xw3egLM4(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩட"),lNTJCZeBicWEz0Mg(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭஠"))
	syTojNd5DWg8tJFArX24xEvU = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,Hlp3z0APt1GR4kMYK5xST(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ஡"),NOrchaEV1iIZ87Uzlwgum(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ஢"),V0VZk9763fusTReHFo4(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫண"))
	tMC6foua7UF2WhVrv09i5qJsK = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,lrtFSogC8Nh9(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧத"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ஥"),PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ஦"))
	xDC7Nk52nKePfXhVRr = Tzx81Wb0RZC4ID5AyiU2(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ஧")
	from urllib.parse import quote as _EjwmP6n5ZIbGJDl7X84HiNFSTRaYe
else:
	ffJYyPuQ6WVvd795NnzRCx3slSB = ACOWB6GRmIbDKyl3Zn.translatePath(hCm2fnEXs6Zt(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪந"))
	YbDTMedqwUi9r4Jax = ACOWB6GRmIbDKyl3Zn.translatePath(rNyT0edugn(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫன"))
	tzFpPxC3jfygiWQE5HORvXJ6cmTwlu = ACOWB6GRmIbDKyl3Zn.translatePath(gniNItGL6bKwpEW(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨப"))
	F9yN4TRdQclxaBGWt6rpSKwkJ = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ஫"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ஬"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬ஭"))
	syTojNd5DWg8tJFArX24xEvU = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,gniNItGL6bKwpEW(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪம"),lrtFSogC8Nh9(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫய"),lRP6GTaZJA1Xw3egLM4(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪர"))
	tMC6foua7UF2WhVrv09i5qJsK = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,lNTJCZeBicWEz0Mg(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ற"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧல"),fOc18oTm5hsdD4pVZQj(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ள"))
	xDC7Nk52nKePfXhVRr = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨழ").encode(YRvPKe2zMTDs8UCkr)
	from urllib import quote as _EjwmP6n5ZIbGJDl7X84HiNFSTRaYe
ASInatQNLOxmbF = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(tzFpPxC3jfygiWQE5HORvXJ6cmTwlu,lrtFSogC8Nh9(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪவ"))
tHLwPKXACG5B2deoiup = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(tzFpPxC3jfygiWQE5HORvXJ6cmTwlu,lNTJCZeBicWEz0Mg(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨஶ"))
RmwsW86vQ1aPzLZAF0HEdlb4y = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,JGwsL21ZRlqSrWxEmF(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬஷ"))
FnyKZ8iu7wAsIHD4SYfr0OC = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,hCm2fnEXs6Zt(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ஸ"))
iqBT5RKfjnl = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬஹ"))
cXO4eSZFqrbYPotf = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,IlL8ZnX74Yvep(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ஺"))
U53uZnOCd9jwDgxpGaJNTe = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,rNyT0edugn(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ஻"))
aatgXM3DTnWQdNkHUi = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,gniNItGL6bKwpEW(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ஼"))
YyHUiEXh8NQAvCf = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ࡬ࡱࡦ࡭ࡥࡴࠩ஽"))
RMxPu3oUBJhwcIvdiz1CSO6AZklaT = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YyHUiEXh8NQAvCf,NOrchaEV1iIZ87Uzlwgum(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫா"))
huOq7j2rEtFN43DLVSGofxnlc = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YyHUiEXh8NQAvCf,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡶࠫி"))
QQHtOBLs25fTp7Imo = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(RMxPu3oUBJhwcIvdiz1CSO6AZklaT,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨீ"))
VAzvLnYQrdktx75g = bbo54rteSTAMHmaq3Jwsd.Addon().getAddonInfo(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡰࡢࡶ࡫ࠫு"))
pMZ4lcsP3Jh2Uu9XV1O8nWom = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,eGW7cI6aQhr0(u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩூ"))
oILX2stOJ9RrpYaCAZuFQB7VzmkU3 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,rNyT0edugn(u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫ௃"))
Kr3HEyJe07WxvahG6LVgmZU5FTlcf = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭௄"))
UlkX1OVdeBcfW9S = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ௅"))
k6RVEBw9Ppghav3To = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,IlL8ZnX74Yvep(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫெ"))
doIXrYnFNyQ = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,JGwsL21ZRlqSrWxEmF(u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩே"))
xaCeE9Ai8lb761J4XtgZURTGn = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,xY4icgQUj6mPVs73CTKu(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭ை"))
I2lfuLH3m7OpQyvj6UWr5dTGnAP = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,gniNItGL6bKwpEW(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭௉"))
Mlx2ijKJHNy9 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,Hlp3z0APt1GR4kMYK5xST(u"ࠨ࡯ࡨࡲࡺࡥࡲࡦࡦࡢ࠶࠵࠶ࡸ࠳࠷࠳࠲ࡵࡴࡧࠨொ"))
U0UT1PijZEFheu6zWg92CrpHsmA = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,lNTJCZeBicWEz0Mg(u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩோ"))
ywv5SRh6Nxj = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,lNTJCZeBicWEz0Mg(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪௌ"))
vPnhV2qXEHQ9bpJl56gfc0wImNRyx = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ்࠭"),PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ௎"),b0VaRYkgC4iOvHpmdeyzcQISJEsx,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ௏"))
XJ7ya50xLRCME2TNHbAfPQhDqj = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ffJYyPuQ6WVvd795NnzRCx3slSB,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧ࡮ࡧࡧ࡭ࡦ࠭ௐ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡈࡲࡲࡹࡹࠧ௑"),rNyT0edugn(u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬ௒"))
zWinZrBTwI3stoS7 = vju3SZDWL4ENYelmBOzUqrogp2(u"࠹ጌ")
omh6YcDWKgIBkNG3 = [JGwsL21ZRlqSrWxEmF(u"ูࠪๆืࠧ௓"),rNyT0edugn(u"ࠫศ๎ไࠨ௔"),HVmIrFwau90jQsgiWzExk(u"ࠬัว็์ࠪ௕"),kb2icmDGVUZfW1OFz7sv(u"࠭หศๆฮࠫ௖"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧาษห฽ࠬௗ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨะสุ้࠭௘"),lNTJCZeBicWEz0Mg(u"ࠩึหิูࠧ௙"),QQHFtjcaR2VpnSyTIv(u"ࠪืฬฮูࠨ௚"),lNTJCZeBicWEz0Mg(u"ࠫะอๅ็ࠩ௛"),IlL8ZnX74Yvep(u"ࠬะวิ฻ࠪ௜"),PzIpQnUXxRwNCivDhdakWTE(u"ู࠭ศึิࠫ௝")]
zdJ8hYIq5bK = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ௞")
bR3vPrUOm7J1loBXq = [QQHFtjcaR2VpnSyTIv(u"ࠨࡄࡒࡏࡗࡇࠧ௟"),NeU6uRGpECkvMV5jf(u"ࠩࡓࡅࡓࡋࡔࠨ௠"),gniNItGL6bKwpEW(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ௡"),NeU6uRGpECkvMV5jf(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ௢"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡏࡆࡊࡎࡐࠫ௣"),QQHFtjcaR2VpnSyTIv(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ௤"),OOkmZiVcfqlEurM1dHGb(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ௥")]
bR3vPrUOm7J1loBXq += [xY4icgQUj6mPVs73CTKu(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ௦"),lRP6GTaZJA1Xw3egLM4(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ௧"),xY4icgQUj6mPVs73CTKu(u"ࠪࡅࡐࡕࡁࡎࠩ௨"),NeU6uRGpECkvMV5jf(u"ࠫࡆࡑࡗࡂࡏࠪ௩"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ௪"),fOc18oTm5hsdD4pVZQj(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ௫")]
jWIEdNC3uzi0 = [QQHFtjcaR2VpnSyTIv(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ௬"),eGW7cI6aQhr0(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ௭"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ௮"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ௯"),Hlp3z0APt1GR4kMYK5xST(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ௰"),HVmIrFwau90jQsgiWzExk(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ௱"),lrtFSogC8Nh9(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ௲")]
jWIEdNC3uzi0 += [HVmIrFwau90jQsgiWzExk(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ௳"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ௴"),HVmIrFwau90jQsgiWzExk(u"ࠩࡖࡌࡔࡌࡈࡂࠩ௵"),R3lezw8h407ZvrAFxT(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫ௶"),kb2icmDGVUZfW1OFz7sv(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬ௷")]
tf91RipT8uVHFU20xsLbM6ZDvXoW = [R3lezw8h407ZvrAFxT(u"࡚ࠬࡉࡌࡃࡄࡘࠬ௸"),V0VZk9763fusTReHFo4(u"࠭ࡁ࡚ࡎࡒࡐࠬ௹"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡇࡑࡖࡘࡆ࠭௺"),V0VZk9763fusTReHFo4(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ௻"),fOc18oTm5hsdD4pVZQj(u"ࠩ࡜ࡅࡖࡕࡔࠨ௼"),HVmIrFwau90jQsgiWzExk(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭௽"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࡛ࠫࡇࡒࡃࡑࡑࠫ௾"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡈࡒࡔࡖࡈࡎࠬ௿")]
tf91RipT8uVHFU20xsLbM6ZDvXoW += [OOkmZiVcfqlEurM1dHGb(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧఀ"),xY4icgQUj6mPVs73CTKu(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩఁ"),lNTJCZeBicWEz0Mg(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩం"),xY4icgQUj6mPVs73CTKu(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫః"),QQHFtjcaR2VpnSyTIv(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫఄ"),NeU6uRGpECkvMV5jf(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭అ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ఆ")]
tf91RipT8uVHFU20xsLbM6ZDvXoW += [hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨఇ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩఈ"),xY4icgQUj6mPVs73CTKu(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫఉ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪఊ"),lNTJCZeBicWEz0Mg(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ఋ"),QQHFtjcaR2VpnSyTIv(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬఌ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ఍")]
tf91RipT8uVHFU20xsLbM6ZDvXoW += [R3lezw8h407ZvrAFxT(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩఎ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪఏ"),fOc18oTm5hsdD4pVZQj(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫఐ"),OOkmZiVcfqlEurM1dHGb(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ఑"),JGwsL21ZRlqSrWxEmF(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬఒ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡆࡎࡗࡂࡍࠪఓ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩఔ")]
tf91RipT8uVHFU20xsLbM6ZDvXoW += [V0VZk9763fusTReHFo4(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨక"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫఖ"),OOkmZiVcfqlEurM1dHGb(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭గ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩఘ"),lrtFSogC8Nh9(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬఙ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭చ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧఛ")]
NKUZziFxbMt = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧజ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨఝ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬఞ"),OOkmZiVcfqlEurM1dHGb(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬట")]
NKUZziFxbMt += [lNTJCZeBicWEz0Mg(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨఠ"),lrtFSogC8Nh9(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩడ"),QQHFtjcaR2VpnSyTIv(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ఢ"),IlL8ZnX74Yvep(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ణ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫత"),kb2icmDGVUZfW1OFz7sv(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨథ")]
NKUZziFxbMt += [wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡌࡔ࡙࡜ࠧద"),xY4icgQUj6mPVs73CTKu(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭ధ"),lNTJCZeBicWEz0Mg(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩన"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ఩")]
NKUZziFxbMt += [fOc18oTm5hsdD4pVZQj(u"࠭ࡍ࠴ࡗࠪప"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩఫ"),kb2icmDGVUZfW1OFz7sv(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬబ"),lRP6GTaZJA1Xw3egLM4(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭భ")]
LcdEWz9BRiQlr8MxgCHeuX = [QQHFtjcaR2VpnSyTIv(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬమ"),fOc18oTm5hsdD4pVZQj(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧయ"),OOkmZiVcfqlEurM1dHGb(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ర"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨఱ"),IlL8ZnX74Yvep(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧల"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪళ")]
GRZ1wqlPVDN = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨఴ")]
eegdvRQUGLoPBti0ISNJrbT8qcfH  = [Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡅࡐ࡝ࡁࡎࠩవ"),eGW7cI6aQhr0(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭శ"),NOrchaEV1iIZ87Uzlwgum(u"ࠬࡈࡏࡌࡔࡄࠫష"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡁࡌࡑࡄࡑࠬస"),R3lezw8h407ZvrAFxT(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩహ"),rNyT0edugn(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ఺"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ఻"),IlL8ZnX74Yvep(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉ఼ࠬ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫఽ")]
eegdvRQUGLoPBti0ISNJrbT8qcfH += [hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧా"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩి"),QQHFtjcaR2VpnSyTIv(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨీ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩు"),kb2icmDGVUZfW1OFz7sv(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪూ"),IlL8ZnX74Yvep(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧృ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡋࡕࡓࡕࡃࠪౄ"),NeU6uRGpECkvMV5jf(u"ࠬࡇࡈࡘࡃࡎࠫ౅"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨె")]
eegdvRQUGLoPBti0ISNJrbT8qcfH += [gniNItGL6bKwpEW(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫే"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫై"),hCm2fnEXs6Zt(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ౉"),QQHFtjcaR2VpnSyTIv(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬొ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ో"),kb2icmDGVUZfW1OFz7sv(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧౌ"),QQHFtjcaR2VpnSyTIv(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ్"),IlL8ZnX74Yvep(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪ౎")]
eegdvRQUGLoPBti0ISNJrbT8qcfH += [lNTJCZeBicWEz0Mg(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ౏"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ౐"),QQHFtjcaR2VpnSyTIv(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ౑"),V0VZk9763fusTReHFo4(u"࡙ࠫ࡜ࡆࡖࡐࠪ౒"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ౓"),IlL8ZnX74Yvep(u"࠭ࡓࡉࡑࡉࡌࡆ࠭౔"),HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡗࡃࡕࡆࡔࡔౕࠧ"),R3lezw8h407ZvrAFxT(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂౖࠩ"),xY4icgQUj6mPVs73CTKu(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ౗")]
eegdvRQUGLoPBti0ISNJrbT8qcfH += [gniNItGL6bKwpEW(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪౘ"),lRP6GTaZJA1Xw3egLM4(u"ࠫ࡞ࡇࡑࡐࡖࠪౙ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ౚ"),IlL8ZnX74Yvep(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ౛"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ౜"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪౝ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ౞"),Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ౟"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ౠ")]
eegdvRQUGLoPBti0ISNJrbT8qcfH += [lNTJCZeBicWEz0Mg(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪౡ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨౢ"),V0VZk9763fusTReHFo4(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨౣ"),QQHFtjcaR2VpnSyTIv(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ౤"),HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡗࡍࡐࡇࡁࡕࠩ౥"),gniNItGL6bKwpEW(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭౦"),fOc18oTm5hsdD4pVZQj(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭౧")]
brlZ1pWz9OkQNF  = [fOc18oTm5hsdD4pVZQj(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ౨"),fOc18oTm5hsdD4pVZQj(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ౩"),kb2icmDGVUZfW1OFz7sv(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ౪"),OOkmZiVcfqlEurM1dHGb(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬ౫"),NeU6uRGpECkvMV5jf(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ౬")]
brlZ1pWz9OkQNF += [JGwsL21ZRlqSrWxEmF(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ౭"),R3lezw8h407ZvrAFxT(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ౮")]
brlZ1pWz9OkQNF += [xY4icgQUj6mPVs73CTKu(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭౯"),lRP6GTaZJA1Xw3egLM4(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ౰"),NOrchaEV1iIZ87Uzlwgum(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ౱")]
brlZ1pWz9OkQNF += [lNTJCZeBicWEz0Mg(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ౲"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ౳"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ౴")]
brlZ1pWz9OkQNF += [HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭౵"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ౶"),JGwsL21ZRlqSrWxEmF(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ౷")]
V1eopDJNk3WOM2wy74b0 = [R3lezw8h407ZvrAFxT(u"ࠧࡎ࠵ࡘࠫ౸"),R3lezw8h407ZvrAFxT(u"ࠨࡋࡓࡘ࡛࠭౹"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ౺"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡍࡋࡏࡌࡎࠩ౻"),V0VZk9763fusTReHFo4(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ౼")]
V0fxhGR6MoiWNebgd7yS4jvE = eegdvRQUGLoPBti0ISNJrbT8qcfH+V1eopDJNk3WOM2wy74b0
BB0aZUJe38zfbw9HrWTtlvE = eegdvRQUGLoPBti0ISNJrbT8qcfH+brlZ1pWz9OkQNF
n1tdI8Kf4R5ovCZEJVP = BB0aZUJe38zfbw9HrWTtlvE+GRZ1wqlPVDN
JuMxp2dLcDy6bj037awTvNIZ = [hCm2fnEXs6Zt(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭౽")]+bR3vPrUOm7J1loBXq+[rNyT0edugn(u"࠭ࡍࡊ࡚ࡈࡈࠬ౾")]+jWIEdNC3uzi0+[V0VZk9763fusTReHFo4(u"ࠧࡑࡗࡅࡐࡎࡉࠧ౿")]+tf91RipT8uVHFU20xsLbM6ZDvXoW+[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩಀ")]+NKUZziFxbMt
aXD9VCmgGzqRFerBcJ = [OOkmZiVcfqlEurM1dHGb(u"ࠩࡄࡏࡔࡇࡍࠨಁ"),lRP6GTaZJA1Xw3egLM4(u"ࠪࡅࡐ࡝ࡁࡎࠩಂ"),eGW7cI6aQhr0(u"ࠫࡎࡌࡉࡍࡏࠪಃ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ಄"),V0VZk9763fusTReHFo4(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨಅ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩಆ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫಇ"),V0VZk9763fusTReHFo4(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪಈ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨಉ"),lNTJCZeBicWEz0Mg(u"ࠫࡒ࠹ࡕࠨಊ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡏࡐࡕࡘࠪಋ"),kb2icmDGVUZfW1OFz7sv(u"࠭ࡂࡐࡍࡕࡅࠬಌ"),xY4icgQUj6mPVs73CTKu(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ಍"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ಎ")]
NOT_TO_TEST_ALL_SERVERS = [rNyT0edugn(u"ࠩࡢࡅࡐࡕ࡟ࠨಏ"),NOrchaEV1iIZ87Uzlwgum(u"ࠪࡣࡆࡑࡗࡠࠩಐ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡤࡏࡆࡍࡡࠪ಑"),eGW7cI6aQhr0(u"ࠬࡥࡋࡓࡄࡢࠫಒ"),hCm2fnEXs6Zt(u"࠭࡟ࡎࡔࡉࡣࠬಓ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡠࡕࡋࡑࡤ࠭ಔ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡡࡖࡌ࡛ࡥࠧಕ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡢ࡝࡚࡚࡟ࠨಖ"),QQHFtjcaR2VpnSyTIv(u"ࠪࡣࡉࡒࡍࡠࠩಗ"),xY4icgQUj6mPVs73CTKu(u"ࠫࡤࡓࡕࠨಘ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡥࡉࡑࠩಙ"),HVmIrFwau90jQsgiWzExk(u"࠭࡟ࡃࡍࡕࡣࠬಚ"),JGwsL21ZRlqSrWxEmF(u"ࠧࡠࡇࡏࡇࡤ࠭ಛ"),lRP6GTaZJA1Xw3egLM4(u"ࠨࡡࡄࡖ࡙ࡥࠧಜ")]
B0vJILKy1FphGiXmwonQ = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧಝ"),NeU6uRGpECkvMV5jf(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨಞ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪಟ"),xY4icgQUj6mPVs73CTKu(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬಠ"),PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫಡ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬಢ"),NOrchaEV1iIZ87Uzlwgum(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧಣ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩತ")]
WTSe9tBI8iEX1Z60MaGsqnL4xyV = [
						 lRP6GTaZJA1Xw3egLM4(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬಥ")
						,xY4icgQUj6mPVs73CTKu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ದ")
						,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ಧ")
						]
JSX5Fx4zOwR = [
						 NeU6uRGpECkvMV5jf(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚ࡓ࠮࠳ࡶࡸࠬನ")
						,rNyT0edugn(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ಩")
						,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩಪ")
						,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪಫ")
						,PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬಬ")
						,gniNItGL6bKwpEW(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧಭ")
						,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩಮ")
						,QQHFtjcaR2VpnSyTIv(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪಯ")
						,Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫರ")
						,xY4icgQUj6mPVs73CTKu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬಱ")
						,NOrchaEV1iIZ87Uzlwgum(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩಲ")
						,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪಳ")
						,R3lezw8h407ZvrAFxT(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ಴")
						,lRP6GTaZJA1Xw3egLM4(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧವ")
						,lRP6GTaZJA1Xw3egLM4(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨಶ")
						]
t1raHhyD46KUw = JSX5Fx4zOwR+[
				 NeU6uRGpECkvMV5jf(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩಷ")
				,JGwsL21ZRlqSrWxEmF(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಸ")
				,xY4icgQUj6mPVs73CTKu(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಹ")
				,Hlp3z0APt1GR4kMYK5xST(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭಺")
				,Hlp3z0APt1GR4kMYK5xST(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧ಻")
				,R3lezw8h407ZvrAFxT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨ಼")
				,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨಽ")
				,xY4icgQUj6mPVs73CTKu(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩಾ")
				,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪಿ")
				,xY4icgQUj6mPVs73CTKu(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ೀ")
				,lRP6GTaZJA1Xw3egLM4(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ು")
				,rNyT0edugn(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧೂ")
				,HHvYL68lbJVZWM7tQEzSex3(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨೃ")
				,IlL8ZnX74Yvep(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫೄ")
				,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ೅")
				,lNTJCZeBicWEz0Mg(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪೆ")
				]
OOc1n5zLYbujBI = [NeU6uRGpECkvMV5jf(u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪೇ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫೈ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ೉"),HVmIrFwau90jQsgiWzExk(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ೊ"),IlL8ZnX74Yvep(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧೋ"),lNTJCZeBicWEz0Mg(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨೌ")]
xKp3jkIvM09AZ4euXa87i5TVtfUD = {
			 hCm2fnEXs6Zt(u"ࠨࡃࡋ࡛ࡆࡑ್ࠧ")		:[JGwsL21ZRlqSrWxEmF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫ೎")]
			,rNyT0edugn(u"ࠪࡅࡐࡕࡁࡎࠩ೏")		:[QQHFtjcaR2VpnSyTIv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨ೐")]
			,lrtFSogC8Nh9(u"ࠬࡇࡋࡘࡃࡐࠫ೑")		:[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭೒")]
			,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪ೓")	:[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨ೔")]
			,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫೕ")		:[JGwsL21ZRlqSrWxEmF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩೖ")]
			,HVmIrFwau90jQsgiWzExk(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬ೗")		:[NOrchaEV1iIZ87Uzlwgum(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡳࡳࡵࡤࡤ࠲ࡹࡼࠧ೘")]
			,lNTJCZeBicWEz0Mg(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨ೙")		:[xY4icgQUj6mPVs73CTKu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱ࡭ࡲ࡫ࡺࡪࡦ࠱ࡷ࡭ࡵࡷࠨ೚")]
			,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭೛")	:[NeU6uRGpECkvMV5jf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩ೜")]
			,hCm2fnEXs6Zt(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬೝ")		:[V0VZk9763fusTReHFo4(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫೞ")]
			,NOrchaEV1iIZ87Uzlwgum(u"ࠬࡇ࡙ࡍࡑࡏࠫ೟")		:[wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧ࠱ࡥࡾࡲ࡯࡭࠰ࡱࡩࡹ࠭ೠ")]
			,JGwsL21ZRlqSrWxEmF(u"ࠧࡃࡑࡎࡖࡆ࠭ೡ")		:[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧೢ")]
			,HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩೣ")		:[HHvYL68lbJVZWM7tQEzSex3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨ೤")]
			,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ೥")		:[IlL8ZnX74Yvep(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫ೦")]
			,LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭೧")		:[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺ࡰ࠯ࡥࡲࡱࠬ೨")]
			,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ೩")		:[NeU6uRGpECkvMV5jf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ೪")]
			,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ೫")		:[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ೬")]
			,JGwsL21ZRlqSrWxEmF(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೭")		:[kb2icmDGVUZfW1OFz7sv(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡥࡹࡩࡨࠨ೮")]
			,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭೯")	:[NeU6uRGpECkvMV5jf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭೰")]
			,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫೱ")		:[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧೲ")]
			,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ೳ")		:[OOkmZiVcfqlEurM1dHGb(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡪࡷ࡫ࡥ࠯ࡸ࡬ࡴࠬ೴")]
			,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ೵")	:[NOrchaEV1iIZ87Uzlwgum(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠻࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶ࠲ࡱࡾࡩ࠱ࠨ೶")]
			,rNyT0edugn(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ೷")		:[QQHFtjcaR2VpnSyTIv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧ೸")]
			,hCm2fnEXs6Zt(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬ೹")		:[OOkmZiVcfqlEurM1dHGb(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡺࡦࡦࡹ࠮࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪ೺")]
			,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೻")	:[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭೼"),HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ೽")]
			,HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ೾")	:[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠻࠮ࡥࡴࡤࡱࡦࡩࡡࡧࡧ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ೿")]
			,OOkmZiVcfqlEurM1dHGb(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫഀ")		:[NOrchaEV1iIZ87Uzlwgum(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡢ࡯ࡤࡷ࠼࠴࡮ࡦࡶࠪഁ")]
			,HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧം")		:[PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡨࡸࡲࠬഃ")]
			,Hlp3z0APt1GR4kMYK5xST(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩഄ")		:[hCm2fnEXs6Zt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡻࡪࡨࡣࡢ࡯ࠪഅ")]
			,OOkmZiVcfqlEurM1dHGb(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫആ")		:[R3lezw8h407ZvrAFxT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪഇ")]
			,hCm2fnEXs6Zt(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ഈ")		:[IlL8ZnX74Yvep(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬഉ")]
			,QQHFtjcaR2VpnSyTIv(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧഊ")		:[NeU6uRGpECkvMV5jf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧഋ")]
			,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪഌ")		:[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ഍")]
			,xY4icgQUj6mPVs73CTKu(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭എ")	:[QQHFtjcaR2VpnSyTIv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠳࡫࡬ࡪࡨ࠱ࡲࡪࡽࡳࠨഏ")]
			,HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഐ")		:[PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫ഑")]
			,Hlp3z0APt1GR4kMYK5xST(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪഒ")	:[R3lezw8h407ZvrAFxT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭ഓ")]
			,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪഔ")		:[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡰ࠯ࡨࡤࡶࡪࡹ࡫ࡰ࠰ࡱࡩࡹ࠭ക")]
			,IlL8ZnX74Yvep(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ഖ")		:[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫഗ")]
			,NeU6uRGpECkvMV5jf(u"࠭ࡆࡐࡕࡗࡅࠬഘ")		:[V0VZk9763fusTReHFo4(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫങ")]
			,PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩച")		:[NOrchaEV1iIZ87Uzlwgum(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࠳ࡧ࡬࡮ࡧࡶ࡬ࡰࡧࡨ࠯ࡰࡨࡸࠬഛ")]
			,eGW7cI6aQhr0(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬജ")		:[JGwsL21ZRlqSrWxEmF(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨ࠮ࡧࡷࡶ࡬ࡦࡸ࠭ࡵࡸ࠱ࡧࡴࡳࠧഝ")]
			,R3lezw8h407ZvrAFxT(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪഞ")	:[R3lezw8h407ZvrAFxT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡩࡹࡸ࡮ࡡࡳ࠰ࡹ࡭ࡩ࡫࡯ࠨട")]
			,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩഠ")		:[eGW7cI6aQhr0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪഡ")]
			,PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡌࡊࡎࡒࡍࠨഢ")		:[R3lezw8h407ZvrAFxT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫണ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬത"),lRP6GTaZJA1Xw3egLM4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ഥ"),gniNItGL6bKwpEW(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨദ"),R3lezw8h407ZvrAFxT(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧധ")]
			,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫന")	:[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪഩ")]
			,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬപ")		:[fOc18oTm5hsdD4pVZQj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡩࡵ࡭ࡲࡸ࠳ࡩࡡ࡮ࠩഫ")]
			,xY4icgQUj6mPVs73CTKu(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭ബ")		:[xY4icgQUj6mPVs73CTKu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡷ࠱࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡨࡵ࡭ࠨഭ")]
			,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭മ")	:[eGW7cI6aQhr0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬയ"),HVmIrFwau90jQsgiWzExk(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨര")]
			,lrtFSogC8Nh9(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪറ")		:[R3lezw8h407ZvrAFxT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩല")]
			,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ള")		:[fOc18oTm5hsdD4pVZQj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭ഴ")]
			,OOkmZiVcfqlEurM1dHGb(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪവ")	:[Hlp3z0APt1GR4kMYK5xST(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨശ")]
			,R3lezw8h407ZvrAFxT(u"ࠩࡓࡅࡓࡋࡔࠨഷ")		:[lNTJCZeBicWEz0Mg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬസ")]
			,NOrchaEV1iIZ87Uzlwgum(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ഹ")		:[OOkmZiVcfqlEurM1dHGb(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ഺ")]
			,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇ഻ࠪ")	:[IlL8ZnX74Yvep(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱ഼ࠬ")]
			,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫഽ")	:[R3lezw8h407ZvrAFxT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡩࡦ࠱ࡺ࡮ࡶࠧാ")]
			,eGW7cI6aQhr0(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬി")		:[Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮ࡥࡣࡼࠫീ")]
			,HVmIrFwau90jQsgiWzExk(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩു")	:[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬൂ")]
			,lRP6GTaZJA1Xw3egLM4(u"ࠧࡔࡊࡒࡊࡍࡇࠧൃ")		:[PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬൄ")]
			,IlL8ZnX74Yvep(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ൅")		:[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪെ"),rNyT0edugn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫേ"),NeU6uRGpECkvMV5jf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨൈ")]
			,lRP6GTaZJA1Xw3egLM4(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨ൉")		:[R3lezw8h407ZvrAFxT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨൊ")]
			,eGW7cI6aQhr0(u"ࠨࡖࡌࡏࡆࡇࡔࠨോ")		:[V0VZk9763fusTReHFo4(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧൌ")]
			,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡘ࡛ࡌࡕࡏ്ࠩ")		:[R3lezw8h407ZvrAFxT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩൎ")]
			,JGwsL21ZRlqSrWxEmF(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬ൏")		:[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭൐")]
			,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫ൑")	:[rNyT0edugn(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫ൒")]
			,vju3SZDWL4ENYelmBOzUqrogp2(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪ൓")		:[PzIpQnUXxRwNCivDhdakWTE(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡸ࡮࡯ࡸࠩൔ")]
			,xY4icgQUj6mPVs73CTKu(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬൕ")		:[lNTJCZeBicWEz0Mg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡣ࡭࡫ࡦ࡯ࠬൖ")]
			,NOrchaEV1iIZ87Uzlwgum(u"࡙࠭ࡂࡓࡒࡘࠬൗ")		:[kb2icmDGVUZfW1OFz7sv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬ൘")]
			,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ൙")		:[JGwsL21ZRlqSrWxEmF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ൚")]
			,fOc18oTm5hsdD4pVZQj(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ൛")	:[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ൜")]
			,hCm2fnEXs6Zt(u"ࠬࡏࡐࡕࡘࠪ൝")			:[fOc18oTm5hsdD4pVZQj(u"࠭ࠧ൞")]
			,lNTJCZeBicWEz0Mg(u"ࠧࡎ࠵ࡘࠫൟ")			:[hCm2fnEXs6Zt(u"ࠨࠩൠ")]
			,OOkmZiVcfqlEurM1dHGb(u"ࠩࡕࡉࡕࡕࡓࠨൡ")		:[NeU6uRGpECkvMV5jf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪൢ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨൣ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ൤")]
			,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪ൥")	:[HVmIrFwau90jQsgiWzExk(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ൦"),rNyT0edugn(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ൧"),R3lezw8h407ZvrAFxT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ൨")]
			,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧ൩")	:[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ൪"),eGW7cI6aQhr0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ൫"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ൬")]
			,JGwsL21ZRlqSrWxEmF(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫ൭")	:[rNyT0edugn(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ൮"),QQHFtjcaR2VpnSyTIv(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ൯"),lrtFSogC8Nh9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ൰")]
			,Hlp3z0APt1GR4kMYK5xST(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ൱")		:[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ൲"),hCm2fnEXs6Zt(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪ൳"),xY4icgQUj6mPVs73CTKu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ൴")]
			}
if llxMLe4gobHhsj1WGvd7qmIU:
	xKp3jkIvM09AZ4euXa87i5TVtfUD[rNyT0edugn(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ൵")] = [pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ൶"),V0VZk9763fusTReHFo4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ൷"),HVmIrFwau90jQsgiWzExk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ൸"),V0VZk9763fusTReHFo4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ൹"),JGwsL21ZRlqSrWxEmF(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪൺ"),gniNItGL6bKwpEW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ൻ"),hCm2fnEXs6Zt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩർ"),gniNItGL6bKwpEW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡦࡥࡵࡺࡣࡩࡣࠪൽ"),HVmIrFwau90jQsgiWzExk(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡸࡪࡹࡴࡪࡰࡪࠫൾ"),gniNItGL6bKwpEW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩൿ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ඀")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫඁ")] = [NeU6uRGpECkvMV5jf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫං"),IlL8ZnX74Yvep(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨඃ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ඄"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඅ"),fOc18oTm5hsdD4pVZQj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪආ"),hCm2fnEXs6Zt(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ඇ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩඈ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡦࡥࡵࡺࡣࡩࡣࠪඉ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡸࡪࡹࡴࡪࡰࡪࠫඊ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩඋ"),OOkmZiVcfqlEurM1dHGb(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨඌ")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[xY4icgQUj6mPVs73CTKu(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩඍ")] = [rNyT0edugn(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨඎ"),lrtFSogC8Nh9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬඏ"),hCm2fnEXs6Zt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫඐ"),R3lezw8h407ZvrAFxT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧඑ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧඒ"),lrtFSogC8Nh9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪඓ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ඔ"),V0VZk9763fusTReHFo4(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧඕ"),NeU6uRGpECkvMV5jf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨඖ"),V0VZk9763fusTReHFo4(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭඗"),xY4icgQUj6mPVs73CTKu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ඘")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧ඙")] = [hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩක"),OOkmZiVcfqlEurM1dHGb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ඛ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬග"),OOkmZiVcfqlEurM1dHGb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨඝ"),kb2icmDGVUZfW1OFz7sv(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨඞ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫඟ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧච"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨඡ"),hCm2fnEXs6Zt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩජ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧඣ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ඤ")]
else:
	xKp3jkIvM09AZ4euXa87i5TVtfUD[QQHFtjcaR2VpnSyTIv(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧඥ")] = [OOkmZiVcfqlEurM1dHGb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫඦ"),QQHFtjcaR2VpnSyTIv(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨට"),JGwsL21ZRlqSrWxEmF(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧඨ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඩ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪඪ"),R3lezw8h407ZvrAFxT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ණ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩඬ"),IlL8ZnX74Yvep(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪත"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫථ"),Hlp3z0APt1GR4kMYK5xST(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩද"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨධ")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪන")] = [V0VZk9763fusTReHFo4(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ඲"),eGW7cI6aQhr0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ඳ"),Hlp3z0APt1GR4kMYK5xST(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬප"),eGW7cI6aQhr0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨඵ"),QQHFtjcaR2VpnSyTIv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨබ"),JGwsL21ZRlqSrWxEmF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫභ"),QQHFtjcaR2VpnSyTIv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧම"),JGwsL21ZRlqSrWxEmF(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨඹ"),NeU6uRGpECkvMV5jf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩය"),eGW7cI6aQhr0(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧර"),Hlp3z0APt1GR4kMYK5xST(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭඼")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[eGW7cI6aQhr0(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠲ࠨල")] = [lNTJCZeBicWEz0Mg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ඾"),PzIpQnUXxRwNCivDhdakWTE(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ඿"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪව"),fOc18oTm5hsdD4pVZQj(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ශ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ෂ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩස"),NeU6uRGpECkvMV5jf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬහ"),kb2icmDGVUZfW1OFz7sv(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ළ"),lRP6GTaZJA1Xw3egLM4(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧෆ"),hCm2fnEXs6Zt(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ෇"),V0VZk9763fusTReHFo4(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ෈")]
	xKp3jkIvM09AZ4euXa87i5TVtfUD[Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭෉")] = [eGW7cI6aQhr0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽ්ࠬ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෋"),lRP6GTaZJA1Xw3egLM4(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෌"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෍"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ෎"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧා"),HVmIrFwau90jQsgiWzExk(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪැ"),gniNItGL6bKwpEW(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫෑ"),fOc18oTm5hsdD4pVZQj(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬි"),Hlp3z0APt1GR4kMYK5xST(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪී"),Hlp3z0APt1GR4kMYK5xST(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩු")]
yy0zIog9KDlfOQ = [LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ෕"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨූ"),V0VZk9763fusTReHFo4(u"ࠨࡇࡐࡅࡎࡒࡓࠨ෗"),OOkmZiVcfqlEurM1dHGb(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫෘ"),OOkmZiVcfqlEurM1dHGb(u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬෙ"),fOc18oTm5hsdD4pVZQj(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧේ"),xY4icgQUj6mPVs73CTKu(u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪෛ"),kb2icmDGVUZfW1OFz7sv(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧො"),HVmIrFwau90jQsgiWzExk(u"ࠧࡕࡇࡖࡘࡎࡔࡇࠨෝ"),gniNItGL6bKwpEW(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪෞ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡈ࡜ࡊࡉࡕࡕࡇࡍࡗࠬෟ")]
EIVDQBT4RprwKAlaHd5t1LcgemqP = [hCm2fnEXs6Zt(u"ࠪࡅࡉࡊࡏࡏࡕࠪ෠"),V0VZk9763fusTReHFo4(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭෡"),gniNItGL6bKwpEW(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ෢")]
class vOxDiB8g9WoVtqkXcN3w6HEfp4UL(Kb4rUJvNhY):
	def __init__(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,*aargs,**kkwargs):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.choiceID = -llxMLe4gobHhsj1WGvd7qmIU
	def onClick(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,bbeAuZV9FxN8hmB0TWasUH):
		if bbeAuZV9FxN8hmB0TWasUH>=PzIpQnUXxRwNCivDhdakWTE(u"࠾࠶࠱࠱ግ"): amPWXzZ9NCIHtDSfeOGiwxrK8Moc.choiceID = bbeAuZV9FxN8hmB0TWasUH-PzIpQnUXxRwNCivDhdakWTE(u"࠾࠶࠱࠱ግ")
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.UdHQNzo61bGwasLJZIA()
	def j36ISCpsVrAmvYXU(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,*aargs):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button0,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button1,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button2 = aargs[e8XhbyuzvjYkIsJUtB5w],aargs[llxMLe4gobHhsj1WGvd7qmIU],aargs[cCRvAuJQfjBpTg0PbYiaNO87]
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.header,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.text = aargs[uL69vJOU7xN0hGnZf2islDqk],aargs[TQNS6YMKAqnilsVObLpDRX]
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.profile,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.direction = aargs[wP4kpvXoDHq3hs7TFLyr2COn8(u"࠻ጎ")],aargs[eGW7cI6aQhr0(u"࠶ጏ")]
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout = aargs[Tzx81Wb0RZC4ID5AyiU2(u"࠹጑")],aargs[R3lezw8h407ZvrAFxT(u"࠹ጐ")]
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout>e8XhbyuzvjYkIsJUtB5w or amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout>Hlp3z0APt1GR4kMYK5xST(u"࠳ጒ"): amPWXzZ9NCIHtDSfeOGiwxrK8Moc.enable_progressbar = k6apiPAlLKM1ed8J42RjHh0o
		else: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.enable_progressbar = f4vncKMRlXG9s
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename = QQHtOBLs25fTp7Imo.replace(R3lezw8h407ZvrAFxT(u"࠭࡟࠱࠲࠳࠴ࡤ࠭෣"),fOc18oTm5hsdD4pVZQj(u"ࠧࡠࠩ෤")+str(XJ62UBRmIqFvfiNTQj.time())+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡡࠪ෥"))
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename = amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename.replace(fOc18oTm5hsdD4pVZQj(u"ࠩ࡟ࡠࠬ෦"),NeU6uRGpECkvMV5jf(u"ࠪࡠࡡࡢ࡜ࠨ෧")).replace(gniNItGL6bKwpEW(u"ࠫ࠴࠵ࠧ෨"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࠵࠯࠰࠱ࠪ෩"))
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_height = XlvB7rxiTQZs6FJKPfOn(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button0,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button1,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button2,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.header,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.text,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.profile,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.direction,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.enable_progressbar,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename)
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.show()
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(R3lezw8h407ZvrAFxT(u"࠽࠵࠻࠰ጓ")).setImage(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename)
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(lRP6GTaZJA1Xw3egLM4(u"࠾࠶࠵࠱ጔ")).setHeight(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_height)
		if not amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button1 and amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button0 and amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button2: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(QQHFtjcaR2VpnSyTIv(u"࠹࠱࠳࠵጖")).setPosition(-JGwsL21ZRlqSrWxEmF(u"࠳࠴࠳጗"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠶ጕ"))
		return amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_height
	def EeOqGNzmoTDCfrkRs581tSBwbvKM(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout:
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.th1 = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=amPWXzZ9NCIHtDSfeOGiwxrK8Moc.KireascGIqWjxUM3tfJkh0X7,args=())
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.th1.start()
		else: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.zqHvCfI25hrWLPTcp()
	def KireascGIqWjxUM3tfJkh0X7(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(LtGoXlQ2IYxqTJRySE6udfW98(u"࠻࠳࠶࠵ጘ")).setEnabled(k6apiPAlLKM1ed8J42RjHh0o)
		for XW2Opt4RQsVihunCylz6j in range(llxMLe4gobHhsj1WGvd7qmIU,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout+llxMLe4gobHhsj1WGvd7qmIU):
			XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
			qoQFSTpKLmHPV3XhbYU6j79DAnaBz = int(JGwsL21ZRlqSrWxEmF(u"࠴࠴࠵ጙ")*XW2Opt4RQsVihunCylz6j/amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout)
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.RrI9CPYJwtuD8Z6Q5mcEUbG(qoQFSTpKLmHPV3XhbYU6j79DAnaBz)
			if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.choiceID>rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠴ጚ"): break
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.zqHvCfI25hrWLPTcp()
	def TijIZx9e6PY5FawNvUGMX(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout:
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.th2 = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=amPWXzZ9NCIHtDSfeOGiwxrK8Moc.urS8PTw2vfchRZbU,args=())
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.th2.start()
		else: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.zqHvCfI25hrWLPTcp()
	def urS8PTw2vfchRZbU(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(lrtFSogC8Nh9(u"࠾࠶࠲࠱ጛ")).setEnabled(k6apiPAlLKM1ed8J42RjHh0o)
		XJ62UBRmIqFvfiNTQj.sleep(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.buttonstimeout)
		for XW2Opt4RQsVihunCylz6j in range(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout-llxMLe4gobHhsj1WGvd7qmIU,-llxMLe4gobHhsj1WGvd7qmIU,-llxMLe4gobHhsj1WGvd7qmIU):
			XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
			qoQFSTpKLmHPV3XhbYU6j79DAnaBz = int(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠷࠰࠱ጜ")*XW2Opt4RQsVihunCylz6j/amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout)
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.RrI9CPYJwtuD8Z6Q5mcEUbG(qoQFSTpKLmHPV3XhbYU6j79DAnaBz)
			if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.choiceID>e8XhbyuzvjYkIsJUtB5w: break
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.closetimeout>e8XhbyuzvjYkIsJUtB5w: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.choiceID = gniNItGL6bKwpEW(u"࠱࠱ጝ")
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.UdHQNzo61bGwasLJZIA()
	def RrI9CPYJwtuD8Z6Q5mcEUbG(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,qoQFSTpKLmHPV3XhbYU6j79DAnaBz):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.precent = qoQFSTpKLmHPV3XhbYU6j79DAnaBz
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(HVmIrFwau90jQsgiWzExk(u"࠺࠲࠵࠴ጞ")).setPercent(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.precent)
	def zqHvCfI25hrWLPTcp(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button0: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(QQHFtjcaR2VpnSyTIv(u"࠻࠳࠵࠵ጟ")).setEnabled(k6apiPAlLKM1ed8J42RjHh0o)
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button1: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(LtGoXlQ2IYxqTJRySE6udfW98(u"࠼࠴࠶࠷ጠ")).setEnabled(k6apiPAlLKM1ed8J42RjHh0o)
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.button2: amPWXzZ9NCIHtDSfeOGiwxrK8Moc.getControl(JGwsL21ZRlqSrWxEmF(u"࠽࠵࠷࠲ጡ")).setEnabled(k6apiPAlLKM1ed8J42RjHh0o)
	def UdHQNzo61bGwasLJZIA(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.close()
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.image_filename)
		except: pass
class k8Q6Hp1Z3YWK():
	def __init__(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,showDialogs=f4vncKMRlXG9s,logErrors=k6apiPAlLKM1ed8J42RjHh0o):
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.showDialogs = showDialogs
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.logErrors = logErrors
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.finishedLIST,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.failedLIST = [],[]
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.statusDICT,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.resultsDICT = {},{}
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.processesLIST = []
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.starttimeDICT,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.finishtimeDICT,amPWXzZ9NCIHtDSfeOGiwxrK8Moc.elpasedtimeDICT = {},{},{}
	def qvpoFNSCxcHMh(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,mpGDaUVONIECixkJYgoKlvB0tP,E0EVJp2ylAd9RO1,*aargs):
		mpGDaUVONIECixkJYgoKlvB0tP = str(mpGDaUVONIECixkJYgoKlvB0tP)
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.statusDICT[mpGDaUVONIECixkJYgoKlvB0tP] = Hlp3z0APt1GR4kMYK5xST(u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ෪")
		if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.showDialogs: kkDz5sdaPteM(NdKhAS6MXVEORLTwob92pxlZ,mpGDaUVONIECixkJYgoKlvB0tP)
		L74nuaBelp3WCyiOtd8U0xh = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=amPWXzZ9NCIHtDSfeOGiwxrK8Moc.o30oyPu7Qk9gUzNCMwYOfA4lB,args=(mpGDaUVONIECixkJYgoKlvB0tP,E0EVJp2ylAd9RO1,aargs))
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.processesLIST.append(L74nuaBelp3WCyiOtd8U0xh)
		return L74nuaBelp3WCyiOtd8U0xh
	def kraoHTGpWFtyz(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,mpGDaUVONIECixkJYgoKlvB0tP,E0EVJp2ylAd9RO1,*aargs):
		L74nuaBelp3WCyiOtd8U0xh = amPWXzZ9NCIHtDSfeOGiwxrK8Moc.qvpoFNSCxcHMh(mpGDaUVONIECixkJYgoKlvB0tP,E0EVJp2ylAd9RO1,*aargs)
		L74nuaBelp3WCyiOtd8U0xh.start()
	def o30oyPu7Qk9gUzNCMwYOfA4lB(amPWXzZ9NCIHtDSfeOGiwxrK8Moc,mpGDaUVONIECixkJYgoKlvB0tP,E0EVJp2ylAd9RO1,aargs):
		mpGDaUVONIECixkJYgoKlvB0tP = str(mpGDaUVONIECixkJYgoKlvB0tP)
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.starttimeDICT[mpGDaUVONIECixkJYgoKlvB0tP] = XJ62UBRmIqFvfiNTQj.time()
		try:
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.resultsDICT[mpGDaUVONIECixkJYgoKlvB0tP] = E0EVJp2ylAd9RO1(*aargs)
			if pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨ෫") in str(E0EVJp2ylAd9RO1) and not amPWXzZ9NCIHtDSfeOGiwxrK8Moc.resultsDICT[mpGDaUVONIECixkJYgoKlvB0tP].succeeded: yyTm3OqzGEYApS()
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.finishedLIST.append(mpGDaUVONIECixkJYgoKlvB0tP)
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.statusDICT[mpGDaUVONIECixkJYgoKlvB0tP] = QQHFtjcaR2VpnSyTIv(u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪ෬")
		except Exception as BBNRYIkquhmv2w5GasF:
			if amPWXzZ9NCIHtDSfeOGiwxrK8Moc.logErrors:
				ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
				if ihuUeAVfaSbXMNn!=lNTJCZeBicWEz0Mg(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ෭"): hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.failedLIST.append(mpGDaUVONIECixkJYgoKlvB0tP)
			amPWXzZ9NCIHtDSfeOGiwxrK8Moc.statusDICT[mpGDaUVONIECixkJYgoKlvB0tP] = kb2icmDGVUZfW1OFz7sv(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ෮")
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.finishtimeDICT[mpGDaUVONIECixkJYgoKlvB0tP] = XJ62UBRmIqFvfiNTQj.time()
		amPWXzZ9NCIHtDSfeOGiwxrK8Moc.elpasedtimeDICT[mpGDaUVONIECixkJYgoKlvB0tP] = amPWXzZ9NCIHtDSfeOGiwxrK8Moc.finishtimeDICT[mpGDaUVONIECixkJYgoKlvB0tP] - amPWXzZ9NCIHtDSfeOGiwxrK8Moc.starttimeDICT[mpGDaUVONIECixkJYgoKlvB0tP]
	def SNpUFlH8LwboVfe(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		for hAYrRbmFzE in amPWXzZ9NCIHtDSfeOGiwxrK8Moc.processesLIST:
			hAYrRbmFzE.start()
	def CEnA3LdjzvITtZ05oxcFS2yiW(amPWXzZ9NCIHtDSfeOGiwxrK8Moc):
		while xY4icgQUj6mPVs73CTKu(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬ෯") in list(amPWXzZ9NCIHtDSfeOGiwxrK8Moc.statusDICT.values()): XJ62UBRmIqFvfiNTQj.sleep(QQHFtjcaR2VpnSyTIv(u"࠶ጢ"))
def UILcbAk0o6yhY():
	if not INCQEvfcLSX3ah7V4WHilmdZKGB: return QQHFtjcaR2VpnSyTIv(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨ෰")
	KHwr0qxpMGQt = OOkmZiVcfqlEurM1dHGb(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫ෱")
	WCTZoNqxeJdR8H = [hCm2fnEXs6Zt(u"ࠧ࠹࠰࠸࠲࠵࠭ෲ"),HVmIrFwau90jQsgiWzExk(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬෳ"),QQHFtjcaR2VpnSyTIv(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧ෴"),OOkmZiVcfqlEurM1dHGb(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧ෵"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨ෶"),lRP6GTaZJA1Xw3egLM4(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩ෷"),HVmIrFwau90jQsgiWzExk(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪ෸"),lrtFSogC8Nh9(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫ෹"),OOkmZiVcfqlEurM1dHGb(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬ෺"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭෻"),OOkmZiVcfqlEurM1dHGb(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧ෼"),IlL8ZnX74Yvep(u"ࠫ࠷࠶࠲࠵࠰࠳࠻࠳࠸࠰ࠨ෽")]
	BovQ98pXr3Imy2 = WCTZoNqxeJdR8H[-llxMLe4gobHhsj1WGvd7qmIU]
	ItmPw2xCzsqj5ZRHFG740 = EFhOxiHtUq2cmaNPedwSQkI5BXDzg(BovQ98pXr3Imy2)
	ZwL3ExR1nJ40BWQMTsKCihY = EFhOxiHtUq2cmaNPedwSQkI5BXDzg(lvsJ2jaZktmNO6PbdXS)
	if ZwL3ExR1nJ40BWQMTsKCihY>ItmPw2xCzsqj5ZRHFG740:
		KHwr0qxpMGQt = lrtFSogC8Nh9(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ෾")
	return KHwr0qxpMGQt
def ZnTqIxcaAYu74US():
	for ssLYlthgeuX1Zwc2a,UEy3lpL0bKROhvu,tm1yhwbq8vSjXE6dnYk0P in IIPNcsCvQnOZk0yejJKl4BtgSrMw.walk(YyHUiEXh8NQAvCf,topdown=f4vncKMRlXG9s):
		if len(tm1yhwbq8vSjXE6dnYk0P)>Tzx81Wb0RZC4ID5AyiU2(u"࠻࠰࠱ጣ"): vWN2YePRikAXEFO6dQ8CT51bz(ssLYlthgeuX1Zwc2a,f4vncKMRlXG9s,f4vncKMRlXG9s)
	return
def ily4MIuXCkGm3wDH1TgsE9PnfOdpV():
	try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.makedirs(vJQYPbL42F013CRoqtEUI)
	except: pass
	pFYjUv29xyiGQotIB5W = UILcbAk0o6yhY()
	if pFYjUv29xyiGQotIB5W==rNyT0edugn(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭෿"): LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧ࠯࡞ࡷࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭฀")+RAHOMksyDUV3w7T1QjqKNX+HHvYL68lbJVZWM7tQEzSex3(u"ࠨࠢࡠࠫก"))
	else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,V0VZk9763fusTReHFo4(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ข")+RAHOMksyDUV3w7T1QjqKNX+Tzx81Wb0RZC4ID5AyiU2(u"ࠪࠤࡢ࠭ฃ"))
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧค"),V0VZk9763fusTReHFo4(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬฅ")+lvsJ2jaZktmNO6PbdXS)
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩฆ"),IlL8ZnX74Yvep(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪง"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,lNTJCZeBicWEz0Mg(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫจ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬฉ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ช"),OOkmZiVcfqlEurM1dHGb(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬซ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨฌ"),gniNItGL6bKwpEW(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨญ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,R3lezw8h407ZvrAFxT(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪฎ"),QQHFtjcaR2VpnSyTIv(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭ฏ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,R3lezw8h407ZvrAFxT(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬฐ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨฑ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧฒ"),vju3SZDWL4ENYelmBOzUqrogp2(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫณ"))
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭ด"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lrtFSogC8Nh9(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩต"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(kb2icmDGVUZfW1OFz7sv(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫถ"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(V0VZk9763fusTReHFo4(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬท"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(V0VZk9763fusTReHFo4(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ธ"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭น"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(eGW7cI6aQhr0(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪบ"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NeU6uRGpECkvMV5jf(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ป"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lrtFSogC8Nh9(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫผ"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NeU6uRGpECkvMV5jf(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩฝ"),NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫพ"),NdKhAS6MXVEORLTwob92pxlZ)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,NOrchaEV1iIZ87Uzlwgum(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫฟ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,HVmIrFwau90jQsgiWzExk(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫภ"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,wP4kpvXoDHq3hs7TFLyr2COn8(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫม"))
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,OOkmZiVcfqlEurM1dHGb(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨย"))
	fPhA8zJWjpb19U(f4vncKMRlXG9s)
	kyCTNqxg9hBKocfXW(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE)
	import oMV3OL4Bzl
	oMV3OL4Bzl.aV1HYqMRxUA3vmOr8LnGofj0FI5C7(fOc18oTm5hsdD4pVZQj(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧร"),f4vncKMRlXG9s)
	oMV3OL4Bzl.aV1HYqMRxUA3vmOr8LnGofj0FI5C7(Hlp3z0APt1GR4kMYK5xST(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫฤ"),f4vncKMRlXG9s)
	oMV3OL4Bzl.aV1HYqMRxUA3vmOr8LnGofj0FI5C7(IlL8ZnX74Yvep(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡧࡨࡰࡴࡪ࡭ࡤࡪࡴࡨࡧࡹ࠭ล"),f4vncKMRlXG9s)
	oMV3OL4Bzl.uuKwU7AkCmnMylP8gqsdeHxLb5i(k6apiPAlLKM1ed8J42RjHh0o)
	if pFYjUv29xyiGQotIB5W==NOrchaEV1iIZ87Uzlwgum(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪฦ"):
		ofPX61UZEpGMTQLa4eFKnqWiOIz(k6apiPAlLKM1ed8J42RjHh0o,[ZFMPvkNQbT2cHiUj])
	else:
		ofPX61UZEpGMTQLa4eFKnqWiOIz(f4vncKMRlXG9s,[])
		oMV3OL4Bzl.AqZG1KQcdsrR9zo4OgextNwM()
		try:
			EEXdIkeoYCWy3N0jT = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ว"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩศ"),lRP6GTaZJA1Xw3egLM4(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪษ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ส"))
			DtudR5oaiT6BNPOhL = bbo54rteSTAMHmaq3Jwsd.Addon(id=lrtFSogC8Nh9(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬห"))
			DtudR5oaiT6BNPOhL.setSetting(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨฬ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡊࡦࡲࡳࡦࠩอ"))
		except: pass
		try:
			EEXdIkeoYCWy3N0jT = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,IlL8ZnX74Yvep(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ฮ"),IlL8ZnX74Yvep(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩฯ"),PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭ะ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ั"))
			DtudR5oaiT6BNPOhL = bbo54rteSTAMHmaq3Jwsd.Addon(id=lNTJCZeBicWEz0Mg(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨา"))
			DtudR5oaiT6BNPOhL.setSetting(eGW7cI6aQhr0(u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬำ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪ࠷ࠬิ"))
		except: pass
		try:
			EEXdIkeoYCWy3N0jT = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,fOc18oTm5hsdD4pVZQj(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ี"),gniNItGL6bKwpEW(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩึ"),fOc18oTm5hsdD4pVZQj(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ื"),V0VZk9763fusTReHFo4(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱุ࠭"))
			DtudR5oaiT6BNPOhL = bbo54rteSTAMHmaq3Jwsd.Addon(id=IlL8ZnX74Yvep(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨู"))
			DtudR5oaiT6BNPOhL.setSetting(lrtFSogC8Nh9(u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔฺࠧ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪ࠶ࠬ฻"))
		except: pass
	dJC476xoE1ecpm0 = kNavZsXiUlWP5o4(LKitvZysHM)
	dJC476xoE1ecpm0 = kNavZsXiUlWP5o4(cXO4eSZFqrbYPotf)
	oMV3OL4Bzl.dwOKloTVHgZY8vJFrQazpD0BU6Stb(f4vncKMRlXG9s)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OOkmZiVcfqlEurM1dHGb(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ฼"),lvsJ2jaZktmNO6PbdXS)
	MIjcStaDWnv(f4vncKMRlXG9s)
	return
def HHTnh5qsKEPfro2iFvJd():
	SdrfqN9RtHZF8TuBeyEb4gvx = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(Hlp3z0APt1GR4kMYK5xST(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪ฽")))
	SdrfqN9RtHZF8TuBeyEb4gvx = e8XhbyuzvjYkIsJUtB5w if not SdrfqN9RtHZF8TuBeyEb4gvx else int(SdrfqN9RtHZF8TuBeyEb4gvx)
	if not SdrfqN9RtHZF8TuBeyEb4gvx or not e8XhbyuzvjYkIsJUtB5w<=MMQhDpyCenmO350aBAKVYk-SdrfqN9RtHZF8TuBeyEb4gvx<=NXpO8DrVmeE:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NOrchaEV1iIZ87Uzlwgum(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ฾"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
		kyCTNqxg9hBKocfXW(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE)
		ZvJB5gFE90drNxo7p1bcj = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OOkmZiVcfqlEurM1dHGb(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧ฿")))
		ZvJB5gFE90drNxo7p1bcj = e8XhbyuzvjYkIsJUtB5w if not ZvJB5gFE90drNxo7p1bcj else int(ZvJB5gFE90drNxo7p1bcj)
		if not ZvJB5gFE90drNxo7p1bcj or not e8XhbyuzvjYkIsJUtB5w<=MMQhDpyCenmO350aBAKVYk-ZvJB5gFE90drNxo7p1bcj<=h1dnE0q2zFHjXlvyGuLZxw:
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨเ"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
			Y6N8DUvSxeBFnKz(f4vncKMRlXG9s)
		LNbF9J6AXkcY2nU = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭แ")))
		LNbF9J6AXkcY2nU = e8XhbyuzvjYkIsJUtB5w if not LNbF9J6AXkcY2nU else int(LNbF9J6AXkcY2nU)
		if not LNbF9J6AXkcY2nU or not e8XhbyuzvjYkIsJUtB5w<=MMQhDpyCenmO350aBAKVYk-LNbF9J6AXkcY2nU<=OewIv05xGhKQpFf:
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(eGW7cI6aQhr0(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧโ"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
			L74nuaBelp3WCyiOtd8U0xh = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=ZnTqIxcaAYu74US)
			L74nuaBelp3WCyiOtd8U0xh.start()
	pZtTGR4aozUghSCkb3uqOvXL0K = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(IlL8ZnX74Yvep(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ใ")))
	pZtTGR4aozUghSCkb3uqOvXL0K = e8XhbyuzvjYkIsJUtB5w if not pZtTGR4aozUghSCkb3uqOvXL0K else int(pZtTGR4aozUghSCkb3uqOvXL0K)
	qHn4GDrECvf0BelWQL3MoNy = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HVmIrFwau90jQsgiWzExk(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧไ")))
	qHn4GDrECvf0BelWQL3MoNy = e8XhbyuzvjYkIsJUtB5w if not qHn4GDrECvf0BelWQL3MoNy else int(qHn4GDrECvf0BelWQL3MoNy)
	if not pZtTGR4aozUghSCkb3uqOvXL0K or not qHn4GDrECvf0BelWQL3MoNy or not e8XhbyuzvjYkIsJUtB5w<=MMQhDpyCenmO350aBAKVYk-qHn4GDrECvf0BelWQL3MoNy<=pZtTGR4aozUghSCkb3uqOvXL0K: WWm8BLXdC4tkeZIKQT()
	return
def WWm8BLXdC4tkeZIKQT():
	oya9sRNMYlTvFpPmw8C20 = llxMLe4gobHhsj1WGvd7qmIU
	n5eXd7uLTHNqZ4AJk8R6wKvIWl = f4vncKMRlXG9s if OMNiY8joQx.mmjbEaLDvxXGOsyo627 else k6apiPAlLKM1ed8J42RjHh0o
	if n5eXd7uLTHNqZ4AJk8R6wKvIWl:
		oo8Tv5VBQAZbptxl = igNr4jWHh8eIS0bM(k6apiPAlLKM1ed8J42RjHh0o)
		if len(oo8Tv5VBQAZbptxl)>llxMLe4gobHhsj1WGvd7qmIU:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,lRP6GTaZJA1Xw3egLM4(u"࠭࠮࡝ࡶࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩๅ")+RAHOMksyDUV3w7T1QjqKNX+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࠡ࡟ࠪๆ"))
			mpGDaUVONIECixkJYgoKlvB0tP,gMXJ1uE2flZASBm6jYhspTnIe,dhfVevor7I2tWBm,VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = oo8Tv5VBQAZbptxl[e8XhbyuzvjYkIsJUtB5w]
			Bj9EMHUr2wftyvR,JFTMsjhRbzieXp2x = VXdz0nyjQHPLeE.split(fOc18oTm5hsdD4pVZQj(u"ࠨ࡞ࡱ࠿ࡀ࠭็"))
			del oo8Tv5VBQAZbptxl[e8XhbyuzvjYkIsJUtB5w]
			G9VbghBs1idrzT3eNnQyOq8vEt5YI = Ijo3hy7zQO5x8aU9vAZDMV.sample(oo8Tv5VBQAZbptxl,llxMLe4gobHhsj1WGvd7qmIU)
			mpGDaUVONIECixkJYgoKlvB0tP,gMXJ1uE2flZASBm6jYhspTnIe,dhfVevor7I2tWBm,VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = G9VbghBs1idrzT3eNnQyOq8vEt5YI[e8XhbyuzvjYkIsJUtB5w]
			dhfVevor7I2tWBm = hCm2fnEXs6Zt(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ่")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠤ࠿้ࠦࠧ")+mpGDaUVONIECixkJYgoKlvB0tP+kjd9LyNqQHMUevZiRI7OlBGF1h+dhfVevor7I2tWBm
			jjpbVgW3hUw7XMyFI50N9ismLlGv2 = lRP6GTaZJA1Xw3egLM4(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮ๊ࠪ")
			zdJ8hYIq5bK = lNTJCZeBicWEz0Mg(u"ࠬอไหสิ฽ฬะ๋ࠧ")
			button0,button1 = VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2
			AACBpkgJWv8R = [button0,button1,zdJ8hYIq5bK]
			bi1ELMXDkh9THA = llxMLe4gobHhsj1WGvd7qmIU if OMNiY8joQx.WiJPMTZvOLGsV0xB8al else pnHgvFOCBZzc08yULQJGIqw9bf(u"࠱࠱ጤ")
			IUF5ecZfOplsHom = -hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠺ጥ")
			while IUF5ecZfOplsHom<e8XhbyuzvjYkIsJUtB5w:
				uuMahb0FtZk5dLiQDB = Ijo3hy7zQO5x8aU9vAZDMV.sample(AACBpkgJWv8R,uL69vJOU7xN0hGnZf2islDqk)
				IUF5ecZfOplsHom = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,uuMahb0FtZk5dLiQDB[e8XhbyuzvjYkIsJUtB5w],uuMahb0FtZk5dLiQDB[llxMLe4gobHhsj1WGvd7qmIU],uuMahb0FtZk5dLiQDB[cCRvAuJQfjBpTg0PbYiaNO87],Bj9EMHUr2wftyvR,dhfVevor7I2tWBm,rNyT0edugn(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ์"),bi1ELMXDkh9THA,IlL8ZnX74Yvep(u"࠸࠳ጦ"))
				if IUF5ecZfOplsHom==NOrchaEV1iIZ87Uzlwgum(u"࠴࠴ጧ"): break
				import oMV3OL4Bzl
				if IUF5ecZfOplsHom>=e8XhbyuzvjYkIsJUtB5w and uuMahb0FtZk5dLiQDB[IUF5ecZfOplsHom]==AACBpkgJWv8R[llxMLe4gobHhsj1WGvd7qmIU]:
					oMV3OL4Bzl.AWxD1rw2o6EeF()
					if IUF5ecZfOplsHom>=e8XhbyuzvjYkIsJUtB5w: IUF5ecZfOplsHom = -hCm2fnEXs6Zt(u"࠽ጨ")
				elif IUF5ecZfOplsHom>=e8XhbyuzvjYkIsJUtB5w and uuMahb0FtZk5dLiQDB[IUF5ecZfOplsHom]==AACBpkgJWv8R[cCRvAuJQfjBpTg0PbYiaNO87]:
					oMV3OL4Bzl.V57ovgQhPbWzRZO6jxU0(f4vncKMRlXG9s)
				if IUF5ecZfOplsHom==-llxMLe4gobHhsj1WGvd7qmIU: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪํ"),D7INg5kyRjwf4ZtoePVUrb1h2SJ+Hlp3z0APt1GR4kMYK5xST(u"ࠨะิ์ัࠦฮุลࠪ๎")+kjd9LyNqQHMUevZiRI7OlBGF1h+JGwsL21ZRlqSrWxEmF(u"ࠩ࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ๏"))
			oya9sRNMYlTvFpPmw8C20 = llxMLe4gobHhsj1WGvd7qmIU
		else: oya9sRNMYlTvFpPmw8C20 = e8XhbyuzvjYkIsJUtB5w
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ๐"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ๑"),QQHFtjcaR2VpnSyTIv(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ๒"),oya9sRNMYlTvFpPmw8C20,hzP83xLawFqYneDtHGmSriWE)
	return
def ssPDw4FzhqHQlnO(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B):
	if bEnO2mwHB8r4fZ in [rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭࠱ࠨ๓"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧ࠳ࠩ๔"),eGW7cI6aQhr0(u"ࠨ࠵ࠪ๕"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩ࠷ࠫ๖"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪ࠹ࠬ๗"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫ࠶࠷ࠧ๘"),OOkmZiVcfqlEurM1dHGb(u"ࠬ࠷࠲ࠨ๙"),OOkmZiVcfqlEurM1dHGb(u"࠭࠱࠴ࠩ๚")] and Ixf7NQG9J3ZTPbcSls42B:
		import LSQvu5zPa6
		LSQvu5zPa6.uvTkyDmO9M48VN2xfXFgUeZ(IGar1Z3F8lNX,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B)
		MIjcStaDWnv(f4vncKMRlXG9s,RAHOMksyDUV3w7T1QjqKNX)
	elif bEnO2mwHB8r4fZ==Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࠷ࠩ๛"):
		import PNC7bFKMI6
		if Ixf7NQG9J3ZTPbcSls42B==NOrchaEV1iIZ87Uzlwgum(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ๜"): PNC7bFKMI6.kkDz5sdaPteM(NOrchaEV1iIZ87Uzlwgum(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ๝"),PzIpQnUXxRwNCivDhdakWTE(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ๞"),XJ62UBRmIqFvfiNTQj=PzIpQnUXxRwNCivDhdakWTE(u"࠷࠶࠰࠱ጩ"))
		elif Ixf7NQG9J3ZTPbcSls42B==R3lezw8h407ZvrAFxT(u"ࠫࡉࡋࡌࡆࡖࡈࠫ๟"): zsPdJ2UtW7DZVFe04lAYbgjyqCR1(TixSXhpW69Uba4f1NPqzYE7JcZ,f4vncKMRlXG9s)
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = PNC7bFKMI6.kqLBiwGX3V8P4SOmrNI1F7AMU(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,iy8Ymsp0GMPVdSWTBR,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
		if Ixf7NQG9J3ZTPbcSls42B==wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ๠"): yyTm3OqzGEYApS()
	elif IGar1Z3F8lNX==hCm2fnEXs6Zt(u"࠭࠷ࠨ๡"):
		import ddml0DI2qy
		ddml0DI2qy.SGDUAhnk8eLvd(eGW7cI6aQhr0(u"ࠧࡠࡃࡏࡐࠬ๢"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	elif IGar1Z3F8lNX==lRP6GTaZJA1Xw3egLM4(u"ࠨ࠺ࠪ๣"): ACOWB6GRmIbDKyl3Zn.executebuiltin(lrtFSogC8Nh9(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ๤")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+IlL8ZnX74Yvep(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ๥")+str(DDq6xNzlMYK)+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ๦"))
	elif IGar1Z3F8lNX==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࠿ࠧ๧"):
		MIjcStaDWnv(k6apiPAlLKM1ed8J42RjHh0o)
	elif IGar1Z3F8lNX==QQHFtjcaR2VpnSyTIv(u"࠭࠱࠱ࠩ๨"):
		import ddml0DI2qy
		ddml0DI2qy.SGDUAhnk8eLvd(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡠࡉࡒࡓࡌࡒࡅࠨ๩"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	elif IGar1Z3F8lNX==IlL8ZnX74Yvep(u"ࠨ࠳࠷ࠫ๪"): MIjcStaDWnv(k6apiPAlLKM1ed8J42RjHh0o,QQHFtjcaR2VpnSyTIv(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡗࡉࡒࡖࠧ๫"))
	elif IGar1Z3F8lNX==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࠵࠺࠭๬"): MIjcStaDWnv(k6apiPAlLKM1ed8J42RjHh0o,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑࠩ๭"))
	elif IGar1Z3F8lNX==IlL8ZnX74Yvep(u"ࠬ࠷࠶ࠨ๮"): MIjcStaDWnv(k6apiPAlLKM1ed8J42RjHh0o,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ๯"))
	elif IGar1Z3F8lNX==IlL8ZnX74Yvep(u"ࠧ࠲࠹ࠪ๰"): MIjcStaDWnv(k6apiPAlLKM1ed8J42RjHh0o,Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡏࡈࡒ࡚ࡥࡒࡂࡐࡇࡓࡒࡏ࡚ࡆࡆࡢࡘࡊࡓࡐࠨ๱"))
	elif IGar1Z3F8lNX==OOkmZiVcfqlEurM1dHGb(u"ࠩ࠴࠼ࠬ๲"):
		rFSUYwTohtsByX4HJ0qElMD8nuk = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(V0VZk9763fusTReHFo4(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ๳"))
		if rFSUYwTohtsByX4HJ0qElMD8nuk: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lrtFSogC8Nh9(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨ๴"),NOrchaEV1iIZ87Uzlwgum(u"ࠬ࠳ࠧ๵")+rFSUYwTohtsByX4HJ0qElMD8nuk)
	if IGar1Z3F8lNX in [rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭࠹ࠨ๶"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧ࠲࠶ࠪ๷"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨ࠳࠸ࠫ๸"),lrtFSogC8Nh9(u"ࠩ࠴࠺ࠬ๹"),rNyT0edugn(u"ࠪ࠵࠼࠭๺")]: yyTm3OqzGEYApS()
	return
def NkJLtbG8DcSgEm6sMw90Tuv(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B,TWqGAlsD0bpihcwOB3FLfYKMdxgC):
	if INCQEvfcLSX3ah7V4WHilmdZKGB: ily4MIuXCkGm3wDH1TgsE9PnfOdpV()
	if IGar1Z3F8lNX: ssPDw4FzhqHQlnO(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,bEnO2mwHB8r4fZ,Ixf7NQG9J3ZTPbcSls42B)
	HHTnh5qsKEPfro2iFvJd()
	Y6N8DUvSxeBFnKz(k6apiPAlLKM1ed8J42RjHh0o)
	global JuMxp2dLcDy6bj037awTvNIZ,BB0aZUJe38zfbw9HrWTtlvE,n1tdI8Kf4R5ovCZEJVP
	for mAH4aPy8q1w in LcdEWz9BRiQlr8MxgCHeuX:
		if mAH4aPy8q1w in JuMxp2dLcDy6bj037awTvNIZ: JuMxp2dLcDy6bj037awTvNIZ.remove(mAH4aPy8q1w)
		if mAH4aPy8q1w in BB0aZUJe38zfbw9HrWTtlvE: BB0aZUJe38zfbw9HrWTtlvE.remove(mAH4aPy8q1w)
		if mAH4aPy8q1w in n1tdI8Kf4R5ovCZEJVP: n1tdI8Kf4R5ovCZEJVP.remove(mAH4aPy8q1w)
	PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V = k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s,f4vncKMRlXG9s
	Jq8UdGyAp9 = o6pkns2UGWqbh(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG,iy8Ymsp0GMPVdSWTBR,TWqGAlsD0bpihcwOB3FLfYKMdxgC,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V)
	KTzV0ixwbQtB1Y23ynGsF7HIgZkU,xmYofc7HByzQqEh81L2b6V,TNKZOBc0gpyvdk7q3mFCP4WVDJ,cfGPeIbDgox07mQ,rcFdCsmDMPgVAv02WfzTI,DCOsArKQ0f3w6ViGUx,z67QrXv9GugIx2AkWRFP35,bbcnJVQUh97HxztuDZe6ai2v = Jq8UdGyAp9
	if KTzV0ixwbQtB1Y23ynGsF7HIgZkU: return
	if xmYofc7HByzQqEh81L2b6V==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ๻"): kyCTNqxg9hBKocfXW(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE)
	vyQfmxGsUX5BSM7Hzq2lEdb6j(NeU6uRGpECkvMV5jf(u"ࠬࡹࡴࡢࡴࡷࠫ๼"))
	if ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HVmIrFwau90jQsgiWzExk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ๽")) not in [R3lezw8h407ZvrAFxT(u"ࠧࡂࡗࡗࡓࠬ๾"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡕࡗࡓࡕ࠭๿"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ຀")]:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩກ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫࡆ࡛ࡔࡐࠩຂ"))
	if not ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(fOc18oTm5hsdD4pVZQj(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ຃")): ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(rNyT0edugn(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭ຄ"),OOc1n5zLYbujBI[e8XhbyuzvjYkIsJUtB5w])
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = kqLBiwGX3V8P4SOmrNI1F7AMU(GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG)
	if pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ຅") in HSb5r1Di9I8eKTtAyuNZdC4W: hrMOzxUkYW7tbCyGqIDLu = k6apiPAlLKM1ed8J42RjHh0o
	if GY9jgon6yhP0IvtCBEJu3==lRP6GTaZJA1Xw3egLM4(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨຆ"):
		if cfGPeIbDgox07mQ!=HVmIrFwau90jQsgiWzExk(u"ࠩ࠱࠲ࠬງ") and rcFdCsmDMPgVAv02WfzTI: E2OlWsLqp5d78iQMmc3uzD()
		if oo2RYcTAqyksN1DHG7gLCaZJ>-llxMLe4gobHhsj1WGvd7qmIU:
			eFQaJX6tYIBEWoniu2lPz = [e8XhbyuzvjYkIsJUtB5w,JGwsL21ZRlqSrWxEmF(u"࠱࠶ጫ"),lrtFSogC8Nh9(u"࠲࠹ጬ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠳࠼ጭ"),eGW7cI6aQhr0(u"࠸࠶ጪ"),lRP6GTaZJA1Xw3egLM4(u"࠸࠺ጰ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠸࠴ጮ"),xY4icgQUj6mPVs73CTKu(u"࠹࠸ጯ")]
			if (hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠪ࡭ࡳࡺࠧຈ"),eGW7cI6aQhr0(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧຉ"),gniNItGL6bKwpEW(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪຊ")) or iy8Ymsp0GMPVdSWTBR not in eFQaJX6tYIBEWoniu2lPz) and not OMNiY8joQx.HHqA8u41iPZ:
				from md4vN8TBez import jOc8u6yzE2wIPRxrK7eni
				Da4GbdZXqmfC = tH7NMszRwQD0ICL6A1B(jOc8u6yzE2wIPRxrK7eni)
				KTzV0ixwbQtB1Y23ynGsF7HIgZkU = LLAlKs5Tbw1chPn(TNKZOBc0gpyvdk7q3mFCP4WVDJ,Da4GbdZXqmfC,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V)
				if Da4GbdZXqmfC and DCOsArKQ0f3w6ViGUx:
					eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,OOkmZiVcfqlEurM1dHGb(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ຋")+z67QrXv9GugIx2AkWRFP35+HVmIrFwau90jQsgiWzExk(u"ࠧࡠࠩຌ")+bbcnJVQUh97HxztuDZe6ai2v,TNKZOBc0gpyvdk7q3mFCP4WVDJ,Da4GbdZXqmfC,h1dnE0q2zFHjXlvyGuLZxw)
			else:
				vI4DUTHAYrjBPOXwu9nas.addDirectoryItem(oo2RYcTAqyksN1DHG7gLCaZJ,lNTJCZeBicWEz0Mg(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫຍ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+OOkmZiVcfqlEurM1dHGb(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩຎ"),JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ListItem(OOkmZiVcfqlEurM1dHGb(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩຏ")))
				vI4DUTHAYrjBPOXwu9nas.addDirectoryItem(oo2RYcTAqyksN1DHG7gLCaZJ,eGW7cI6aQhr0(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧຐ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+hCm2fnEXs6Zt(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬຑ"),JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ListItem(Tzx81Wb0RZC4ID5AyiU2(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬຒ")))
			vI4DUTHAYrjBPOXwu9nas.endOfDirectory(oo2RYcTAqyksN1DHG7gLCaZJ,PsKJk8XRHAQM,hrMOzxUkYW7tbCyGqIDLu,wOFPXMYDC3ebEvtkpmsluz45JQ1V)
	return
def kyCTNqxg9hBKocfXW(glZzNQkVmEFAuI908ox1D):
	if xY4icgQUj6mPVs73CTKu(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩຓ") in str(sevfFTR5mNndl): return
	eeVwTCht67KDkn = f4vncKMRlXG9s if glZzNQkVmEFAuI908ox1D else k6apiPAlLKM1ed8J42RjHh0o
	if not eeVwTCht67KDkn:
		CljxiRDzKArsQILc = tSWniwpOkD(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩດ")))
		CljxiRDzKArsQILc = e8XhbyuzvjYkIsJUtB5w if not CljxiRDzKArsQILc else int(CljxiRDzKArsQILc)
		if not CljxiRDzKArsQILc or not e8XhbyuzvjYkIsJUtB5w<=MMQhDpyCenmO350aBAKVYk-CljxiRDzKArsQILc<=glZzNQkVmEFAuI908ox1D: eeVwTCht67KDkn = k6apiPAlLKM1ed8J42RjHh0o
	if not eeVwTCht67KDkn:
		D4DPx62XrjmZv1qYHTuMbEg7 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(JGwsL21ZRlqSrWxEmF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧຕ"))
		if D4DPx62XrjmZv1qYHTuMbEg7 in [NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩຖ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪທ")]: eeVwTCht67KDkn = k6apiPAlLKM1ed8J42RjHh0o
	if not eeVwTCht67KDkn:
		SIjtlzEamoK4VuBMA = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨຘ"))
		Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(ZFMPvkNQbT2cHiUj)
		ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(V0VZk9763fusTReHFo4(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡣ࡮ࡪ࠻ࠨນ"))
		RR0jVLciM4S1UIw = str(ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()[fOc18oTm5hsdD4pVZQj(u"࠶ጱ")][fOc18oTm5hsdD4pVZQj(u"࠶ጱ")])
		Yo5K7kXcjOVq2SiTvludJ48f.close()
		NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(NOrchaEV1iIZ87Uzlwgum(u"࠵ጲ")*SIjtlzEamoK4VuBMA.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
		NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(NOrchaEV1iIZ87Uzlwgum(u"࠲࠶ጳ")*NhZuHrpLxyqnSIjGs4VFiW3MXk65.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
		NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠳࠼ጴ")*NhZuHrpLxyqnSIjGs4VFiW3MXk65.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
		NhZuHrpLxyqnSIjGs4VFiW3MXk65 = str(int(NhZuHrpLxyqnSIjGs4VFiW3MXk65[JGwsL21ZRlqSrWxEmF(u"࠷ጶ"):IlL8ZnX74Yvep(u"࠶࠸ጷ")],ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠷࠶ጸ")))[:wP4kpvXoDHq3hs7TFLyr2COn8(u"࠼ጵ")]
		if NhZuHrpLxyqnSIjGs4VFiW3MXk65!=RR0jVLciM4S1UIw: eeVwTCht67KDkn = k6apiPAlLKM1ed8J42RjHh0o
	if eeVwTCht67KDkn: XX87wBWjidG1ZgVQc0uJDab3tq(f4vncKMRlXG9s)
	return
def cJiwqfuC1HlD4Z(e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy,xmezOWMyhSXRGHlEk2JnsI,showDialogs):
	mAH4aPy8q1w = xmezOWMyhSXRGHlEk2JnsI.split(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧ࠮ࠩບ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w] if kb2icmDGVUZfW1OFz7sv(u"ࠨ࠯ࠪປ") in xmezOWMyhSXRGHlEk2JnsI else xmezOWMyhSXRGHlEk2JnsI
	if not showDialogs or xmezOWMyhSXRGHlEk2JnsI in JSX5Fx4zOwR or not OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX: return f4vncKMRlXG9s
	eFxB9v7dgAo4 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HVmIrFwau90jQsgiWzExk(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪຜ"))
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫຝ"),NdKhAS6MXVEORLTwob92pxlZ)
	L1LOtuJ0pfUxjFZeh = e5DznyEKA9hMcN3jX4Ou271gptkr in [xY4icgQUj6mPVs73CTKu(u"࠺ጼ"),NeU6uRGpECkvMV5jf(u"࠲࠳࠳࠴࠶ጺ"),rNyT0edugn(u"࠱࠲࠲࠳࠶ጹ"),rNyT0edugn(u"࠳࠳࠴࠺࠺ጻ")]
	yLmTq3YGlW7XvgIh6 = wNiDIHWX0BOk7ezTgfPx1RtVMvuKy.lower()
	eNkPn58qxUG = e5DznyEKA9hMcN3jX4Ou271gptkr in [e8XhbyuzvjYkIsJUtB5w,hCm2fnEXs6Zt(u"࠷࠰࠵ጿ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠵࠵࠶࠶࠲ጽ"),eGW7cI6aQhr0(u"࠶࠷࠱ጾ")]
	DI81rqW6mMFxa7 = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬພ") in yLmTq3YGlW7XvgIh6
	rebcskodWOhiZV1M5uvFQyzKpBSE = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬຟ") in yLmTq3YGlW7XvgIh6
	R57mUSLMx0oFwAKkT2aizPbscBE6uC = PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ຠ") in yLmTq3YGlW7XvgIh6
	v8FUzEaCMu4RmlOyZ6JxA = lRP6GTaZJA1Xw3egLM4(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩມ") in yLmTq3YGlW7XvgIh6
	nFCAMOipWNJ3fc8BRev1xyU = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(eGW7cI6aQhr0(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ຢ"))
	gxDTdfjnIKspHLWz9a12FmBke = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(QQHFtjcaR2VpnSyTIv(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬຣ"))
	oowWS6ICqcdBZvjJx1VEXL = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ຤")
	c4yQI96P7Z3jw5Y0 = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡊࡸࡲࡰࡴࠣࠫລ")+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+eGW7cI6aQhr0(u"ࠬࡀࠠࠨ຦")+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy
	c4yQI96P7Z3jw5Y0 = OOFEmwq2GkTz93WXy1Nj(c4yQI96P7Z3jw5Y0)
	if eNkPn58qxUG or DI81rqW6mMFxa7 or rebcskodWOhiZV1M5uvFQyzKpBSE or R57mUSLMx0oFwAKkT2aizPbscBE6uC or v8FUzEaCMu4RmlOyZ6JxA: oowWS6ICqcdBZvjJx1VEXL += lRP6GTaZJA1Xw3egLM4(u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣฬฬ๊ๅ้ไ฼ࡠࡳ࠭ວ")
	if L1LOtuJ0pfUxjFZeh: oowWS6ICqcdBZvjJx1VEXL += V0VZk9763fusTReHFo4(u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࡡࡴࠧຨ")
	c4yQI96P7Z3jw5Y0 = B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+c4yQI96P7Z3jw5Y0+kjd9LyNqQHMUevZiRI7OlBGF1h
	if nFCAMOipWNJ3fc8BRev1xyU==gniNItGL6bKwpEW(u"ࠨࡃࡖࡏࠬຩ") or gxDTdfjnIKspHLWz9a12FmBke==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡄࡗࡐ࠭ສ"):
		oowWS6ICqcdBZvjJx1VEXL += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"๋้ࠪࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬຫ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	srSail8ZMo23 = f4vncKMRlXG9s
	if nFCAMOipWNJ3fc8BRev1xyU==lNTJCZeBicWEz0Mg(u"ࠫࡆ࡙ࡋࠨຬ") or gxDTdfjnIKspHLWz9a12FmBke==QQHFtjcaR2VpnSyTIv(u"ࠬࡇࡓࡌࠩອ"):
		IUF5ecZfOplsHom = HQK8NwPVcoJ(lRP6GTaZJA1Xw3egLM4(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ຮ"),IlL8ZnX74Yvep(u"ࠧฯำ๋ะࠬຯ"),lrtFSogC8Nh9(u"ࠨวิืฬ๊ࠠๅๆ่ฬึ๋ฬࠨະ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩอู้๐อࠡษ็ู้้ไสࠩັ"),mAH4aPy8q1w+H9cMF21gLJSv3tA5CPYXza+P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w),oowWS6ICqcdBZvjJx1VEXL+B6IrC7zEHlw1oaeWf+c4yQI96P7Z3jw5Y0)
		if IUF5ecZfOplsHom==llxMLe4gobHhsj1WGvd7qmIU:
			from oMV3OL4Bzl import AWxD1rw2o6EeF
			AWxD1rw2o6EeF()
		elif IUF5ecZfOplsHom==cCRvAuJQfjBpTg0PbYiaNO87: srSail8ZMo23 = k6apiPAlLKM1ed8J42RjHh0o
	else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,mAH4aPy8q1w+H9cMF21gLJSv3tA5CPYXza+P02oGj7X8m5uMz6VUCScZbDnLp4fR(mAH4aPy8q1w),oowWS6ICqcdBZvjJx1VEXL,c4yQI96P7Z3jw5Y0)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫາ"),eFxB9v7dgAo4)
	return srSail8ZMo23
def ofPX61UZEpGMTQLa4eFKnqWiOIz(YhBrP2z9gXUfoiNJdH4ctjqla0bm1=f4vncKMRlXG9s,LisOfRrbGUP9pC1HF=[]):
	P5JhdZstal9p48LTjxBUom3fk = [LKitvZysHM,cXO4eSZFqrbYPotf]+LisOfRrbGUP9pC1HF
	for hNfrb20intZpMPUI3w in IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(vJQYPbL42F013CRoqtEUI):
		if YhBrP2z9gXUfoiNJdH4ctjqla0bm1 and (hNfrb20intZpMPUI3w.startswith(rNyT0edugn(u"ࠫ࡮ࡶࡴࡷࠩຳ")) or hNfrb20intZpMPUI3w.startswith(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡳ࠳ࡶࠩິ"))): continue
		if hNfrb20intZpMPUI3w.startswith(lNTJCZeBicWEz0Mg(u"࠭ࡦࡪ࡮ࡨࡣࠬີ")): continue
		llJDy5dWwTSX4ovNquLmaAHCKtr = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,hNfrb20intZpMPUI3w)
		if llJDy5dWwTSX4ovNquLmaAHCKtr in P5JhdZstal9p48LTjxBUom3fk: continue
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(llJDy5dWwTSX4ovNquLmaAHCKtr)
		except: pass
	if YyHUiEXh8NQAvCf not in P5JhdZstal9p48LTjxBUom3fk: vWN2YePRikAXEFO6dQ8CT51bz(YyHUiEXh8NQAvCf,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
	XJ62UBRmIqFvfiNTQj.sleep(JGwsL21ZRlqSrWxEmF(u"࠱ፀ"))
	return
def Z3ImMeH6dCKrJOjLo8(fpzTre9NAqoP,fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved=k6apiPAlLKM1ed8J42RjHh0o,UPu1AiwY6GOH5Xyk97vfSC2Jq=k6apiPAlLKM1ed8J42RjHh0o):
	ZZT6GLaHQ1 = ZZT6GLaHQ1+NeU6uRGpECkvMV5jf(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧຶ")+fpzTre9NAqoP
	MmDs0fWOCc3Bg = cJaAB4uQyp(OewIv05xGhKQpFf,fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,FBZQcNT8PedGlMC,showDialogs,xmezOWMyhSXRGHlEk2JnsI,aY7nZxP3iCWE5s6DMJOBUv8Ved,UPu1AiwY6GOH5Xyk97vfSC2Jq)
	if ZZT6GLaHQ1 in MmDs0fWOCc3Bg.content: MmDs0fWOCc3Bg.succeeded = f4vncKMRlXG9s
	if not MmDs0fWOCc3Bg.succeeded:
		yyTm3OqzGEYApS()
	return MmDs0fWOCc3Bg
def v9NCilWBmeg6X7UQTAJ0cKS1(ZZT6GLaHQ1):
	MmDs0fWOCc3Bg = cJaAB4uQyp(NXpO8DrVmeE,rNyT0edugn(u"ࠨࡉࡈࡘࠬື"),ZZT6GLaHQ1,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶຸࠪ"),k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
	ANFOiZ7h4pyU9M = []
	if MmDs0fWOCc3Bg.succeeded:
		tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
		dK3M0YGFVq9eWnZIOc4 = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸູ࠭"),tWcXU498FSdjKl2Iw7M)
		if dK3M0YGFVq9eWnZIOc4: tWcXU498FSdjKl2Iw7M = B6IrC7zEHlw1oaeWf.join(dK3M0YGFVq9eWnZIOc4)
		fV4v8socx0KTtmgbZFBDjap = tWcXU498FSdjKl2Iw7M.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).strip(B6IrC7zEHlw1oaeWf).split(B6IrC7zEHlw1oaeWf)
		ANFOiZ7h4pyU9M = []
		for fpzTre9NAqoP in fV4v8socx0KTtmgbZFBDjap:
			if fpzTre9NAqoP.count(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫ࠳຺࠭"))==uL69vJOU7xN0hGnZf2islDqk: ANFOiZ7h4pyU9M.append(fpzTre9NAqoP)
	return ANFOiZ7h4pyU9M
def O1ARy2cjnu(*aargs):
	XzDhM4q1SpRjiOJ6NBCuev = lrtFSogC8Nh9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭ົ")
	enOhEaRDXtCzV8x04igf = NOrchaEV1iIZ87Uzlwgum(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪຼ")
	e7WqoFMmfYga9KL = v9NCilWBmeg6X7UQTAJ0cKS1(enOhEaRDXtCzV8x04igf)
	ANFOiZ7h4pyU9M = v9NCilWBmeg6X7UQTAJ0cKS1(XzDhM4q1SpRjiOJ6NBCuev)
	e3ZsgE2ikcyMW = e7WqoFMmfYga9KL+ANFOiZ7h4pyU9M
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࠡࠢࠣࡋࡴࡺࠠࡱࡴࡲࡼ࡮࡫ࡳࠡ࡮࡬ࡷࡹࠦࠠࠡ࠳ࡶࡸ࠰࠸࡮ࡥ࠼ࠣ࡟ࠥ࠭ຽ")+str(len(e7WqoFMmfYga9KL))+lRP6GTaZJA1Xw3egLM4(u"ࠨ࠭ࠪ຾")+str(len(ANFOiZ7h4pyU9M))+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࠣࡡࠬ຿"))
	fpzTre9NAqoP = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪເ"))
	MmDs0fWOCc3Bg = CDtdAcPSKah()
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫແ"),NdKhAS6MXVEORLTwob92pxlZ)
	if fpzTre9NAqoP or e3ZsgE2ikcyMW:
		mpGDaUVONIECixkJYgoKlvB0tP,t7GucK3fAw = e8XhbyuzvjYkIsJUtB5w,HVmIrFwau90jQsgiWzExk(u"࠲࠲ፁ")
		GN6XFd9LkwhM0K3OExfr7U4ypDae = len(e3ZsgE2ikcyMW)
		sDFX0wniJNkyCrAoZGRtpL4bS = t7GucK3fAw
		if GN6XFd9LkwhM0K3OExfr7U4ypDae>sDFX0wniJNkyCrAoZGRtpL4bS: rQJLsAo2HuMTcVF9w = sDFX0wniJNkyCrAoZGRtpL4bS
		else: rQJLsAo2HuMTcVF9w = GN6XFd9LkwhM0K3OExfr7U4ypDae
		Zw3FOisxTMQBjy5rIJGmV = Ijo3hy7zQO5x8aU9vAZDMV.sample(e3ZsgE2ikcyMW,rQJLsAo2HuMTcVF9w)
		if fpzTre9NAqoP: Zw3FOisxTMQBjy5rIJGmV = [fpzTre9NAqoP]+Zw3FOisxTMQBjy5rIJGmV
		KKoQRcYbI30LBstfjTiF9aVGxmq = k8Q6Hp1Z3YWK(f4vncKMRlXG9s,f4vncKMRlXG9s)
		nDW6hxsUyd5NtALZ = XJ62UBRmIqFvfiNTQj.time()
		while XJ62UBRmIqFvfiNTQj.time()-nDW6hxsUyd5NtALZ<=t7GucK3fAw and not KKoQRcYbI30LBstfjTiF9aVGxmq.finishedLIST:
			if mpGDaUVONIECixkJYgoKlvB0tP<rQJLsAo2HuMTcVF9w:
				fpzTre9NAqoP = Zw3FOisxTMQBjy5rIJGmV[mpGDaUVONIECixkJYgoKlvB0tP]
				KKoQRcYbI30LBstfjTiF9aVGxmq.kraoHTGpWFtyz(mpGDaUVONIECixkJYgoKlvB0tP,Z3ImMeH6dCKrJOjLo8,fpzTre9NAqoP,*aargs)
			XJ62UBRmIqFvfiNTQj.sleep(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠲࠱࠻࠺ፂ"))
			mpGDaUVONIECixkJYgoKlvB0tP += llxMLe4gobHhsj1WGvd7qmIU
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lrtFSogC8Nh9(u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧໂ")+fpzTre9NAqoP+lNTJCZeBicWEz0Mg(u"࠭ࠠ࡞ࠩໃ"))
		finishedLIST = KKoQRcYbI30LBstfjTiF9aVGxmq.finishedLIST
		if finishedLIST:
			resultsDICT = KKoQRcYbI30LBstfjTiF9aVGxmq.resultsDICT
			UUkrEaTeKH54hdQOsS2Ivb = finishedLIST[e8XhbyuzvjYkIsJUtB5w]
			MmDs0fWOCc3Bg = resultsDICT[UUkrEaTeKH54hdQOsS2Ivb]
			fpzTre9NAqoP = Zw3FOisxTMQBjy5rIJGmV[int(UUkrEaTeKH54hdQOsS2Ivb)]
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(rNyT0edugn(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧໄ"),fpzTre9NAqoP)
			if UUkrEaTeKH54hdQOsS2Ivb!=e8XhbyuzvjYkIsJUtB5w: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Hlp3z0APt1GR4kMYK5xST(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ໅")+fpzTre9NAqoP+gniNItGL6bKwpEW(u"ࠩࠣࡡࠬໆ"))
			else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+QQHFtjcaR2VpnSyTIv(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ໇")+fpzTre9NAqoP+rNyT0edugn(u"ࠫࠥࡣ່ࠧ"))
	return MmDs0fWOCc3Bg
def bLOpXQMenuTIhZ95dF8f3(r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ,fbEu6LMqO9iKR5jaG0tIe):
	CXEbBhLqfU30jNFAQswH7pPcG = r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ.create_connection
	def ShYldyLsbU4e2(g3oiwHxpsGT0YkhdOZB9czFf61CA,*aargs,**kkwargs):
		FnCrjE5mLe3lKU,C8Byxocb1f2XJE53FaN = g3oiwHxpsGT0YkhdOZB9czFf61CA
		ip = kohKPuQdZrpUVOljAcy9BiWs5(FnCrjE5mLe3lKU,fbEu6LMqO9iKR5jaG0tIe)
		if ip: FnCrjE5mLe3lKU = ip[e8XhbyuzvjYkIsJUtB5w]
		else:
			if fbEu6LMqO9iKR5jaG0tIe in OOc1n5zLYbujBI: OOc1n5zLYbujBI.remove(fbEu6LMqO9iKR5jaG0tIe)
			if OOc1n5zLYbujBI:
				RGskj9WxVoI3Kp8 = OOc1n5zLYbujBI[e8XhbyuzvjYkIsJUtB5w]
				ip = kohKPuQdZrpUVOljAcy9BiWs5(FnCrjE5mLe3lKU,RGskj9WxVoI3Kp8)
				if ip: FnCrjE5mLe3lKU = ip[e8XhbyuzvjYkIsJUtB5w]
		g3oiwHxpsGT0YkhdOZB9czFf61CA = (FnCrjE5mLe3lKU,C8Byxocb1f2XJE53FaN)
		return CXEbBhLqfU30jNFAQswH7pPcG(g3oiwHxpsGT0YkhdOZB9czFf61CA,*aargs,**kkwargs)
	r8P5Hoc3wkBbVxMn6Ng0KRGyDTfYAQ.create_connection = ShYldyLsbU4e2
	return CXEbBhLqfU30jNFAQswH7pPcG
def rHpGMO1cy9SvR2L074(ZZT6GLaHQ1):
	NsZYASFKqul8WI2,EFqx5mph7t = ZZT6GLaHQ1.split(lrtFSogC8Nh9(u"ࠬ࠵້ࠧ"))[cCRvAuJQfjBpTg0PbYiaNO87],Hlp3z0APt1GR4kMYK5xST(u"࠻࠴ፃ")
	if YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭࠺ࠨ໊") in NsZYASFKqul8WI2: NsZYASFKqul8WI2,EFqx5mph7t = NsZYASFKqul8WI2.split(hCm2fnEXs6Zt(u"ࠧ࠻໋ࠩ"))
	OpKTi6djcEwV9rlM3BSgbzvkHRYDfn = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨ࠱ࠪ໌")+NOrchaEV1iIZ87Uzlwgum(u"ࠩ࠲ࠫໍ").join(ZZT6GLaHQ1.split(eGW7cI6aQhr0(u"ࠪ࠳ࠬ໎"))[IlL8ZnX74Yvep(u"࠷ፄ"):])
	kF13d0oJXn4xKH = NeU6uRGpECkvMV5jf(u"ࠫࡌࡋࡔࠡࠩ໏")+OpKTi6djcEwV9rlM3BSgbzvkHRYDfn+xY4icgQUj6mPVs73CTKu(u"ࠬࠦࡈࡕࡖࡓ࠳࠶࠴࠱࡝ࡴ࡟ࡲࠬ໐")
	kF13d0oJXn4xKH += QQHFtjcaR2VpnSyTIv(u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭໑")+NsZYASFKqul8WI2+hCm2fnEXs6Zt(u"ࠧ࡝ࡴ࡟ࡲࠬ໒")
	kF13d0oJXn4xKH += hCm2fnEXs6Zt(u"ࠨ࡞ࡵࡠࡳ࠭໓")
	from socket import socket as IEda5gR6kvfhQw3W0j,AF_INET as iZJKAR5qgr624HQ,SOCK_STREAM as yV0sLZKX8gqDRA5ueOQtjd2S
	try:
		YkxL5HPqv9zMRBEw2ou = IEda5gR6kvfhQw3W0j(iZJKAR5qgr624HQ,yV0sLZKX8gqDRA5ueOQtjd2S)
		YkxL5HPqv9zMRBEw2ou.connect((NsZYASFKqul8WI2,EFqx5mph7t))
		YkxL5HPqv9zMRBEw2ou.send(kF13d0oJXn4xKH.encode(YRvPKe2zMTDs8UCkr))
		PGEhdRUrs76XgNbZvV2ISj4 = YkxL5HPqv9zMRBEw2ou.recv(Hlp3z0APt1GR4kMYK5xST(u"࠺࠰࠺࠸ፆ")*hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠶࠶࠲࠵ፅ"))
		tWcXU498FSdjKl2Iw7M = repr(PGEhdRUrs76XgNbZvV2ISj4)
	except: tWcXU498FSdjKl2Iw7M = NdKhAS6MXVEORLTwob92pxlZ
	return tWcXU498FSdjKl2Iw7M
def msbTrJW03xuvA(XdfIYHGOi7Q3njzWaUwcJrk,GY9jgon6yhP0IvtCBEJu3):
	if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ࠱ࠫ໔") not in XdfIYHGOi7Q3njzWaUwcJrk: return XdfIYHGOi7Q3njzWaUwcJrk
	XdfIYHGOi7Q3njzWaUwcJrk = XdfIYHGOi7Q3njzWaUwcJrk+eGW7cI6aQhr0(u"ࠪ࠳ࠬ໕")
	YxhBl2v3kzW0j5NuFEd47iH,r5tZxUgYMEz4vihTkA2nHXN6PK0fGQ = XdfIYHGOi7Q3njzWaUwcJrk.split(eGW7cI6aQhr0(u"ࠫ࠳࠭໖"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠱ፇ"))
	F63Rfcnh9r4QBgJHX,TPMA7HvsBeprKWi4QYXh0ZJ5u = r5tZxUgYMEz4vihTkA2nHXN6PK0fGQ.split(eGW7cI6aQhr0(u"ࠬ࠵ࠧ໗"),NOrchaEV1iIZ87Uzlwgum(u"࠲ፈ"))
	XZiY3U1MTqN5HtW0co = YxhBl2v3kzW0j5NuFEd47iH+JGwsL21ZRlqSrWxEmF(u"࠭࠮ࠨ໘")+F63Rfcnh9r4QBgJHX
	if GY9jgon6yhP0IvtCBEJu3 in [rNyT0edugn(u"ࠧࡩࡱࡶࡸࠬ໙"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡰࡤࡱࡪ࠭໚")] and OOkmZiVcfqlEurM1dHGb(u"ࠩ࠲ࠫ໛") in XZiY3U1MTqN5HtW0co: XZiY3U1MTqN5HtW0co = XZiY3U1MTqN5HtW0co.rsplit(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࠳ࠬໜ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠳ፉ"))[llxMLe4gobHhsj1WGvd7qmIU]
	if GY9jgon6yhP0IvtCBEJu3==HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡳࡧ࡭ࡦࠩໝ") and ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬ࠴ࠧໞ") in XZiY3U1MTqN5HtW0co:
		TYa1dvRIngEo = XZiY3U1MTqN5HtW0co.split(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭࠮ࠨໟ"))
		oyKXHTUM7ra = len(TYa1dvRIngEo)
		if R3lezw8h407ZvrAFxT(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ໠") in XZiY3U1MTqN5HtW0co: TYa1dvRIngEo = fOc18oTm5hsdD4pVZQj(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭໡")
		elif oyKXHTUM7ra<=cCRvAuJQfjBpTg0PbYiaNO87: TYa1dvRIngEo = TYa1dvRIngEo[e8XhbyuzvjYkIsJUtB5w]
		elif oyKXHTUM7ra>=uL69vJOU7xN0hGnZf2islDqk: TYa1dvRIngEo = TYa1dvRIngEo[llxMLe4gobHhsj1WGvd7qmIU]
		if len(TYa1dvRIngEo)>llxMLe4gobHhsj1WGvd7qmIU: XZiY3U1MTqN5HtW0co = TYa1dvRIngEo
	return XZiY3U1MTqN5HtW0co
def jBwT7etlxOuUgakyX6CL(Hj0MLngi4e):
	j058ZYCiyTNMdPVWRnXe2GrO = repr(Hj0MLngi4e.encode(YRvPKe2zMTDs8UCkr)).replace(HVmIrFwau90jQsgiWzExk(u"ࠤࠪࠦ໢"),NdKhAS6MXVEORLTwob92pxlZ)
	return j058ZYCiyTNMdPVWRnXe2GrO
def kdNDPcUObAMs9Kz(T9b4VOmWDxtF):
	ddSBExFurKftAQoN4 = NdKhAS6MXVEORLTwob92pxlZ
	if QBp28giCnayJzmZH6vYO: T9b4VOmWDxtF = T9b4VOmWDxtF.decode(YRvPKe2zMTDs8UCkr)
	from unicodedata import decomposition as ut7T1EbDyrg8dRVOI
	for evDruf7CgXlPUWh1z6M5sAQ4xwa in T9b4VOmWDxtF:
		if   evDruf7CgXlPUWh1z6M5sAQ4xwa==HHvYL68lbJVZWM7tQEzSex3(u"ࡸࠫว࠭໣"): bHIhpKGoYkZz0sNwrvR1gdxVT = fOc18oTm5hsdD4pVZQj(u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ໤")
		elif evDruf7CgXlPUWh1z6M5sAQ4xwa==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࡺ࠭รࠨ໥"): bHIhpKGoYkZz0sNwrvR1gdxVT = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ໦")
		elif evDruf7CgXlPUWh1z6M5sAQ4xwa==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࡵࠨฦࠪ໧"): bHIhpKGoYkZz0sNwrvR1gdxVT = kb2icmDGVUZfW1OFz7sv(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ໨")
		elif evDruf7CgXlPUWh1z6M5sAQ4xwa==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࡷࠪษࠬ໩"): bHIhpKGoYkZz0sNwrvR1gdxVT = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ໪")
		elif evDruf7CgXlPUWh1z6M5sAQ4xwa==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࡹࠬฬࠧ໫"): bHIhpKGoYkZz0sNwrvR1gdxVT = gniNItGL6bKwpEW(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭໬")
		else:
			lc3Yq9zSTICn = ut7T1EbDyrg8dRVOI(evDruf7CgXlPUWh1z6M5sAQ4xwa)
			if Vwgflszp4WRA93kx6hvdua21HX5cOb in lc3Yq9zSTICn: bHIhpKGoYkZz0sNwrvR1gdxVT = lRP6GTaZJA1Xw3egLM4(u"࠭࡜࡝ࡷࠪ໭")+lc3Yq9zSTICn.split(Vwgflszp4WRA93kx6hvdua21HX5cOb,llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
			else:
				bHIhpKGoYkZz0sNwrvR1gdxVT = lNTJCZeBicWEz0Mg(u"ࠧ࠱࠲࠳࠴ࠬ໮")+hex(ord(evDruf7CgXlPUWh1z6M5sAQ4xwa)).replace(IlL8ZnX74Yvep(u"ࠨ࠲ࡻࠫ໯"),NdKhAS6MXVEORLTwob92pxlZ)
				bHIhpKGoYkZz0sNwrvR1gdxVT = JGwsL21ZRlqSrWxEmF(u"ࠩ࡟ࡠࡺ࠭໰")+bHIhpKGoYkZz0sNwrvR1gdxVT[-TQNS6YMKAqnilsVObLpDRX:]
		ddSBExFurKftAQoN4 += bHIhpKGoYkZz0sNwrvR1gdxVT
	ddSBExFurKftAQoN4 = ddSBExFurKftAQoN4.replace(kb2icmDGVUZfW1OFz7sv(u"ࠪࡠࡡࡻ࠰࠷ࡅࡆࠫ໱"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡡࡢࡵ࠱࠸࠷࠽ࠬ໲"))
	if QBp28giCnayJzmZH6vYO: ddSBExFurKftAQoN4 = ddSBExFurKftAQoN4.decode(lRP6GTaZJA1Xw3egLM4(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭໳")).encode(YRvPKe2zMTDs8UCkr)
	else: ddSBExFurKftAQoN4 = ddSBExFurKftAQoN4.encode(YRvPKe2zMTDs8UCkr).decode(LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ໴"))
	return ddSBExFurKftAQoN4
def Z6GiHgnz0jNytc(header=QQHFtjcaR2VpnSyTIv(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠧ໵"),qk0vxP27rbfuOwcgEtl3mUB1IDNWS=NdKhAS6MXVEORLTwob92pxlZ,bZDf2KP9VGEk4a=f4vncKMRlXG9s,source=NdKhAS6MXVEORLTwob92pxlZ):
	HSb5r1Di9I8eKTtAyuNZdC4W = lUCgB1053Z6NWj2AyvScxGkImF7(header,qk0vxP27rbfuOwcgEtl3mUB1IDNWS,type=JTIdpcz98k7RyxHOX5EnqD6L1vKe04.INPUT_ALPHANUM)
	HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(mrgzi2ktB4WS06QHPf5ZJE1Kv,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if not HSb5r1Di9I8eKTtAyuNZdC4W and not bZDf2KP9VGEk4a:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,Hlp3z0APt1GR4kMYK5xST(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ໶")+HSb5r1Di9I8eKTtAyuNZdC4W+hCm2fnEXs6Zt(u"ࠩࠥࠫ໷"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໸"),hCm2fnEXs6Zt(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧ໹"))
		return NdKhAS6MXVEORLTwob92pxlZ
	if HSb5r1Di9I8eKTtAyuNZdC4W not in [NdKhAS6MXVEORLTwob92pxlZ,Vwgflszp4WRA93kx6hvdua21HX5cOb]:
		HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		HSb5r1Di9I8eKTtAyuNZdC4W = kdNDPcUObAMs9Kz(HSb5r1Di9I8eKTtAyuNZdC4W)
	if source!=R3lezw8h407ZvrAFxT(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ໺") and ppU5ihvWXsaGPV1t4JlIMA8x(vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨ໻"),NdKhAS6MXVEORLTwob92pxlZ,[HSb5r1Di9I8eKTtAyuNZdC4W],f4vncKMRlXG9s):
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪ໼")+HSb5r1Di9I8eKTtAyuNZdC4W+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࠤࠪ໽"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ໾"),NOrchaEV1iIZ87Uzlwgum(u"ࠪห๋ะࠠไฬหฮ้ࠥไๆหࠣวํࠦัใ็่ࠣ์ูࠦๅษๅอࠥฮรโๆส้๊ࠥไไสสีࠥ็โุࠢ࠱࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์ึ้าࠦศศีอาิอๅ้ࠡๆิฬࠦใๅ็สฮࠬ໿"))
		return NdKhAS6MXVEORLTwob92pxlZ
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,rNyT0edugn(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡣ࡯ࡰࡴࡽࡥࡥ࠼ࠣࠤࠥࠨࠧༀ")+HSb5r1Di9I8eKTtAyuNZdC4W+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࠨࠧ༁"))
	return HSb5r1Di9I8eKTtAyuNZdC4W
def Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,BfjcMoqOsmdUvZVCHWIyQKi,omrd89nv0PGKFpL3TxfAXt={}):
	ZZT6GLaHQ1,X6mgRV5jeLploA7zxf,UNZ5JYoADPigf8Cn4FbBch,WCy1HJ6FmcxA = BfjcMoqOsmdUvZVCHWIyQKi,{},{},NdKhAS6MXVEORLTwob92pxlZ
	if lrtFSogC8Nh9(u"࠭ࡼࠨ༂") in BfjcMoqOsmdUvZVCHWIyQKi: ZZT6GLaHQ1,X6mgRV5jeLploA7zxf = muYp09a1NhMo7cZng5IOXyTSKt4qv2(BfjcMoqOsmdUvZVCHWIyQKi,kb2icmDGVUZfW1OFz7sv(u"ࠧࡽࠩ༃"))
	ItPrOJuMk97h4DGKl = list(set(list(omrd89nv0PGKFpL3TxfAXt.keys())+list(X6mgRV5jeLploA7zxf.keys())))
	for V9fBFLnGeItlHmYgE1Xi0xvWPz in ItPrOJuMk97h4DGKl:
		if V9fBFLnGeItlHmYgE1Xi0xvWPz in list(X6mgRV5jeLploA7zxf.keys()): UNZ5JYoADPigf8Cn4FbBch[V9fBFLnGeItlHmYgE1Xi0xvWPz] = X6mgRV5jeLploA7zxf[V9fBFLnGeItlHmYgE1Xi0xvWPz]
		else: UNZ5JYoADPigf8Cn4FbBch[V9fBFLnGeItlHmYgE1Xi0xvWPz] = omrd89nv0PGKFpL3TxfAXt[V9fBFLnGeItlHmYgE1Xi0xvWPz]
	if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ༄") not in ItPrOJuMk97h4DGKl: UNZ5JYoADPigf8Cn4FbBch[QQHFtjcaR2VpnSyTIv(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭༅")] = kkCjlxiynwT34GVFc()
	if IlL8ZnX74Yvep(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ༆") not in ItPrOJuMk97h4DGKl: UNZ5JYoADPigf8Cn4FbBch[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ༇")] = msbTrJW03xuvA(ZZT6GLaHQ1,HVmIrFwau90jQsgiWzExk(u"ࠬࡻࡲ࡭ࠩ༈"))
	if OOkmZiVcfqlEurM1dHGb(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨ༉") not in ItPrOJuMk97h4DGKl: UNZ5JYoADPigf8Cn4FbBch[JGwsL21ZRlqSrWxEmF(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ༊")] = QQHFtjcaR2VpnSyTIv(u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠺ࠩ་")
	for V9fBFLnGeItlHmYgE1Xi0xvWPz in list(UNZ5JYoADPigf8Cn4FbBch.keys()): WCy1HJ6FmcxA += HVmIrFwau90jQsgiWzExk(u"ࠩࠩࠫ༌")+V9fBFLnGeItlHmYgE1Xi0xvWPz+JGwsL21ZRlqSrWxEmF(u"ࠪࡁࠬ།")+UNZ5JYoADPigf8Cn4FbBch[V9fBFLnGeItlHmYgE1Xi0xvWPz]
	if WCy1HJ6FmcxA: WCy1HJ6FmcxA = V0VZk9763fusTReHFo4(u"ࠫࢁ࠭༎")+WCy1HJ6FmcxA[llxMLe4gobHhsj1WGvd7qmIU:]
	MmDs0fWOCc3Bg = cJaAB4uQyp(MIT0n79k8beo26aJHW,lRP6GTaZJA1Xw3egLM4(u"ࠬࡍࡅࡕࠩ༏"),ZZT6GLaHQ1,NdKhAS6MXVEORLTwob92pxlZ,UNZ5JYoADPigf8Cn4FbBch,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ༐"),f4vncKMRlXG9s,f4vncKMRlXG9s)
	tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
	if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ༑") not in tWcXU498FSdjKl2Iw7M: return [lRP6GTaZJA1Xw3egLM4(u"ࠨ࠯࠴ࠫ༒")],[ZZT6GLaHQ1+WCy1HJ6FmcxA]
	if lRP6GTaZJA1Xw3egLM4(u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭༓") in tWcXU498FSdjKl2Iw7M: return [ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࠱࠶࠭༔")],[ZZT6GLaHQ1+WCy1HJ6FmcxA]
	if pnHgvFOCBZzc08yULQJGIqw9bf(u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ༕") in tWcXU498FSdjKl2Iw7M: return [gniNItGL6bKwpEW(u"ࠬ࠳࠱ࠨ༖")],[ZZT6GLaHQ1+WCy1HJ6FmcxA]
	IGEpKNCaiLMT,UTwH7zjZOrmFl,JgQUDBnId6kMVw,cUK8BMbXeH = [],[],[],[]
	aLZSGBw7NhXtCuDWgJR = YYqECUofyi7wFrW.findall(lrtFSogC8Nh9(u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ༗"),tWcXU498FSdjKl2Iw7M+B6IrC7zEHlw1oaeWf,YYqECUofyi7wFrW.DOTALL)
	if not aLZSGBw7NhXtCuDWgJR: return [lrtFSogC8Nh9(u"ࠧ࠮࠳༘ࠪ")],[ZZT6GLaHQ1+WCy1HJ6FmcxA]
	for HR3U1ZcNgzoIifnu5tBA,XdfIYHGOi7Q3njzWaUwcJrk in aLZSGBw7NhXtCuDWgJR:
		kigsjlwVP28I5dpGSua,rFSUYwTohtsByX4HJ0qElMD8nuk,a0ao2jdlt4r9nhHwpvSgOVGA = {},-OOkmZiVcfqlEurM1dHGb(u"࠴ፊ"),-OOkmZiVcfqlEurM1dHGb(u"࠴ፊ")
		NOSLDxgEwbha81cQ4eJKHn = NdKhAS6MXVEORLTwob92pxlZ
		E5q7eGByuf1N9rV2LiozUaP = HR3U1ZcNgzoIifnu5tBA.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨ࠮༙ࠪ"))
		for KiBecyPA5WSGXCQu38h1F4n in E5q7eGByuf1N9rV2LiozUaP:
			if gniNItGL6bKwpEW(u"ࠩࡀࠫ༚") in KiBecyPA5WSGXCQu38h1F4n:
				V9fBFLnGeItlHmYgE1Xi0xvWPz,m6I48ydkMWlQN = KiBecyPA5WSGXCQu38h1F4n.split(IlL8ZnX74Yvep(u"ࠪࡁࠬ༛"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠵ፋ"))
				kigsjlwVP28I5dpGSua[V9fBFLnGeItlHmYgE1Xi0xvWPz.lower()] = m6I48ydkMWlQN
		if hCm2fnEXs6Zt(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ༜") in HR3U1ZcNgzoIifnu5tBA.lower():
			rFSUYwTohtsByX4HJ0qElMD8nuk = int(kigsjlwVP28I5dpGSua[xY4icgQUj6mPVs73CTKu(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ༝")])//lNTJCZeBicWEz0Mg(u"࠶࠶࠲࠵ፌ")
			NOSLDxgEwbha81cQ4eJKHn += str(rFSUYwTohtsByX4HJ0qElMD8nuk)+IlL8ZnX74Yvep(u"࠭࡫ࡣࡲࡶࠤࠥ࠭༞")
		elif vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ༟") in HR3U1ZcNgzoIifnu5tBA.lower():
			rFSUYwTohtsByX4HJ0qElMD8nuk = int(kigsjlwVP28I5dpGSua[NOrchaEV1iIZ87Uzlwgum(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ༠")])//YJpWv4QzC7sx8INVPukeZiOD03K(u"࠷࠰࠳࠶ፍ")
			NOSLDxgEwbha81cQ4eJKHn += str(rFSUYwTohtsByX4HJ0qElMD8nuk)+HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ༡")
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ༢") in HR3U1ZcNgzoIifnu5tBA.lower():
			a0ao2jdlt4r9nhHwpvSgOVGA = int(kigsjlwVP28I5dpGSua[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ༣")].split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡾࠧ༤"))[llxMLe4gobHhsj1WGvd7qmIU])
			NOSLDxgEwbha81cQ4eJKHn += str(a0ao2jdlt4r9nhHwpvSgOVGA)+Uv7MkgVGyEbAlfFP0S8Zjqp2J
		NOSLDxgEwbha81cQ4eJKHn = NOSLDxgEwbha81cQ4eJKHn.strip(Uv7MkgVGyEbAlfFP0S8Zjqp2J)
		if not NOSLDxgEwbha81cQ4eJKHn: NOSLDxgEwbha81cQ4eJKHn = lNTJCZeBicWEz0Mg(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ༥")
		if not XdfIYHGOi7Q3njzWaUwcJrk.startswith(fOc18oTm5hsdD4pVZQj(u"ࠧࡩࡶࡷࡴࠬ༦")):
			if XdfIYHGOi7Q3njzWaUwcJrk.startswith(hCm2fnEXs6Zt(u"ࠨ࠱࠲ࠫ༧")): XdfIYHGOi7Q3njzWaUwcJrk = ZZT6GLaHQ1.split(QQHFtjcaR2VpnSyTIv(u"ࠩ࠽ࠫ༨"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]+NOrchaEV1iIZ87Uzlwgum(u"ࠪ࠾ࠬ༩")+XdfIYHGOi7Q3njzWaUwcJrk
			elif XdfIYHGOi7Q3njzWaUwcJrk.startswith(QQHFtjcaR2VpnSyTIv(u"ࠫ࠴࠭༪")): XdfIYHGOi7Q3njzWaUwcJrk = msbTrJW03xuvA(ZZT6GLaHQ1,JGwsL21ZRlqSrWxEmF(u"ࠬࡻࡲ࡭ࠩ༫"))+XdfIYHGOi7Q3njzWaUwcJrk
			else: XdfIYHGOi7Q3njzWaUwcJrk = ZZT6GLaHQ1.rsplit(kb2icmDGVUZfW1OFz7sv(u"࠭࠯ࠨ༬"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧ࠰ࠩ༭")+XdfIYHGOi7Q3njzWaUwcJrk
		if gniNItGL6bKwpEW(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ༮") in list(kigsjlwVP28I5dpGSua.keys()):
			xKXbWz9coR7jUfil45aQENr0ICBJg = kigsjlwVP28I5dpGSua[NOrchaEV1iIZ87Uzlwgum(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ༯")]
			xKXbWz9coR7jUfil45aQENr0ICBJg = xKXbWz9coR7jUfil45aQENr0ICBJg.replace(lrtFSogC8Nh9(u"ࠪࠦࠬ༰"),NdKhAS6MXVEORLTwob92pxlZ).replace(eGW7cI6aQhr0(u"ࠦࠬࠨ༱"),NdKhAS6MXVEORLTwob92pxlZ).split(HVmIrFwau90jQsgiWzExk(u"ࠬࠩࠧ༲"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
			F8ipzId7PMgj = atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(xKXbWz9coR7jUfil45aQENr0ICBJg)
			if F8ipzId7PMgj: PJN58A9SFZTwi6uLMB73m = NOSLDxgEwbha81cQ4eJKHn+Uv7MkgVGyEbAlfFP0S8Zjqp2J+F8ipzId7PMgj
			else: PJN58A9SFZTwi6uLMB73m = NOSLDxgEwbha81cQ4eJKHn
			PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m+lRP6GTaZJA1Xw3egLM4(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭༳")
			PJN58A9SFZTwi6uLMB73m = PJN58A9SFZTwi6uLMB73m+Uv7MkgVGyEbAlfFP0S8Zjqp2J+msbTrJW03xuvA(xKXbWz9coR7jUfil45aQENr0ICBJg,R3lezw8h407ZvrAFxT(u"ࠧ࡯ࡣࡰࡩࠬ༴"))
			IGEpKNCaiLMT.append(PJN58A9SFZTwi6uLMB73m)
			UTwH7zjZOrmFl.append(xKXbWz9coR7jUfil45aQENr0ICBJg)
			JgQUDBnId6kMVw.append(a0ao2jdlt4r9nhHwpvSgOVGA)
			cUK8BMbXeH.append(rFSUYwTohtsByX4HJ0qElMD8nuk)
		XdfIYHGOi7Q3njzWaUwcJrk = XdfIYHGOi7Q3njzWaUwcJrk.split(fOc18oTm5hsdD4pVZQj(u"ࠨ༵ࠥࠪ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
		F8ipzId7PMgj = atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(XdfIYHGOi7Q3njzWaUwcJrk)
		if F8ipzId7PMgj: NOSLDxgEwbha81cQ4eJKHn = NOSLDxgEwbha81cQ4eJKHn+Uv7MkgVGyEbAlfFP0S8Zjqp2J+F8ipzId7PMgj
		NOSLDxgEwbha81cQ4eJKHn = NOSLDxgEwbha81cQ4eJKHn+Uv7MkgVGyEbAlfFP0S8Zjqp2J+msbTrJW03xuvA(XdfIYHGOi7Q3njzWaUwcJrk,PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡱࡥࡲ࡫ࠧ༶"))
		IGEpKNCaiLMT.append(NOSLDxgEwbha81cQ4eJKHn)
		UTwH7zjZOrmFl.append(XdfIYHGOi7Q3njzWaUwcJrk)
		JgQUDBnId6kMVw.append(a0ao2jdlt4r9nhHwpvSgOVGA)
		cUK8BMbXeH.append(rFSUYwTohtsByX4HJ0qElMD8nuk)
	hRfSE2oyUgL1XIAws49p8O3aWl = list(zip(IGEpKNCaiLMT,UTwH7zjZOrmFl,JgQUDBnId6kMVw,cUK8BMbXeH))
	hRfSE2oyUgL1XIAws49p8O3aWl = sorted(hRfSE2oyUgL1XIAws49p8O3aWl, reverse=k6apiPAlLKM1ed8J42RjHh0o, key=lambda key: key[uL69vJOU7xN0hGnZf2islDqk])
	IGEpKNCaiLMT,UTwH7zjZOrmFl,JgQUDBnId6kMVw,cUK8BMbXeH = list(zip(*hRfSE2oyUgL1XIAws49p8O3aWl))
	IGEpKNCaiLMT,UTwH7zjZOrmFl = list(IGEpKNCaiLMT),list(UTwH7zjZOrmFl)
	xGMCcl8P0dqYyXFwnE4JNRjH = []
	for XdfIYHGOi7Q3njzWaUwcJrk in UTwH7zjZOrmFl: xGMCcl8P0dqYyXFwnE4JNRjH.append(XdfIYHGOi7Q3njzWaUwcJrk+WCy1HJ6FmcxA)
	nmf7NvpgRwVPGxhAbeC5ik2 = list(zip(xGMCcl8P0dqYyXFwnE4JNRjH,[rNyT0edugn(u"ࠪࡨࡺࡳ࡭ࡺ༷ࠩ")]*len(xGMCcl8P0dqYyXFwnE4JNRjH),cUK8BMbXeH))
	NbWS4eC2ncvYkjQ0lmzZis7tPdG5o = bkqNe6d9GKctQ(yNIDEX5hU4G769,nmf7NvpgRwVPGxhAbeC5ik2)
	if NbWS4eC2ncvYkjQ0lmzZis7tPdG5o:
		zehVcU893FC6LEd1Aij,gHbS3MaYo0j6uTdm2qyQnKP,rFSUYwTohtsByX4HJ0qElMD8nuk = NbWS4eC2ncvYkjQ0lmzZis7tPdG5o[fOc18oTm5hsdD4pVZQj(u"࠰ፎ")]
		index = xGMCcl8P0dqYyXFwnE4JNRjH.index(zehVcU893FC6LEd1Aij)
		title = IGEpKNCaiLMT[index]
		IGEpKNCaiLMT,xGMCcl8P0dqYyXFwnE4JNRjH = [title],[zehVcU893FC6LEd1Aij]
	return IGEpKNCaiLMT,xGMCcl8P0dqYyXFwnE4JNRjH
def kohKPuQdZrpUVOljAcy9BiWs5(FnCrjE5mLe3lKU,fbEu6LMqO9iKR5jaG0tIe=NdKhAS6MXVEORLTwob92pxlZ):
	if not fbEu6LMqO9iKR5jaG0tIe: fbEu6LMqO9iKR5jaG0tIe = OOc1n5zLYbujBI[e8XhbyuzvjYkIsJUtB5w]
	if FnCrjE5mLe3lKU.replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠫ࠳࠭༸"),NdKhAS6MXVEORLTwob92pxlZ).isdigit(): return [FnCrjE5mLe3lKU]
	from struct import pack as bg0YhtjCENeam9pHB25FoyXGcfuO,unpack_from as hX8BOlfZijNd0x
	from socket import socket as IEda5gR6kvfhQw3W0j,AF_INET as iZJKAR5qgr624HQ,SOCK_DGRAM as N1pDBmLzkR5
	try:
		zRNvUFCOq2paf9dtH4l0JmXS5goA = bg0YhtjCENeam9pHB25FoyXGcfuO(lRP6GTaZJA1Xw3egLM4(u"ࠧࡄࡈ༹ࠣ"), xY4icgQUj6mPVs73CTKu(u"࠲࠴࠳࠸࠾ፏ"))
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࠾ࡉࠤ༺"), HVmIrFwau90jQsgiWzExk(u"࠴࠸࠺ፐ"))
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(hCm2fnEXs6Zt(u"ࠢ࠿ࡊࠥ༻"), llxMLe4gobHhsj1WGvd7qmIU)
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠣࡀࡋࠦ༼"), e8XhbyuzvjYkIsJUtB5w)
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(kb2icmDGVUZfW1OFz7sv(u"ࠤࡁࡌࠧ༽"), e8XhbyuzvjYkIsJUtB5w)
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(HHvYL68lbJVZWM7tQEzSex3(u"ࠥࡂࡍࠨ༾"), e8XhbyuzvjYkIsJUtB5w)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: sIpf7LEa8dXGRiJ = FnCrjE5mLe3lKU.split(lrtFSogC8Nh9(u"ࠫ࠳࠭༿"))
		else: sIpf7LEa8dXGRiJ = FnCrjE5mLe3lKU.decode(YRvPKe2zMTDs8UCkr).split(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࠴ࠧཀ"))
		for cW8jXTY32JOsFvgh9rBxUa6L in sIpf7LEa8dXGRiJ:
			X50IEOGBnZakmNu1TY = cW8jXTY32JOsFvgh9rBxUa6L.encode(YRvPKe2zMTDs8UCkr)
			zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(kb2icmDGVUZfW1OFz7sv(u"ࠨࡂࠣཁ"), len(cW8jXTY32JOsFvgh9rBxUa6L))
			for yM6TWPmrUfkZg9HLotIbFznY3X in cW8jXTY32JOsFvgh9rBxUa6L:
				zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(eGW7cI6aQhr0(u"ࠢࡤࠤག"), yM6TWPmrUfkZg9HLotIbFznY3X.encode(YRvPKe2zMTDs8UCkr))
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠣࡄࠥགྷ"), e8XhbyuzvjYkIsJUtB5w)
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(NeU6uRGpECkvMV5jf(u"ࠤࡁࡌࠧང"), llxMLe4gobHhsj1WGvd7qmIU)
		zRNvUFCOq2paf9dtH4l0JmXS5goA += bg0YhtjCENeam9pHB25FoyXGcfuO(Hlp3z0APt1GR4kMYK5xST(u"ࠥࡂࡍࠨཅ"), llxMLe4gobHhsj1WGvd7qmIU)
		UZYHJXPfB8M1dx = IEda5gR6kvfhQw3W0j(iZJKAR5qgr624HQ,N1pDBmLzkR5)
		UZYHJXPfB8M1dx.sendto(bytes(zRNvUFCOq2paf9dtH4l0JmXS5goA), (fbEu6LMqO9iKR5jaG0tIe, R3lezw8h407ZvrAFxT(u"࠸࠷ፑ")))
		UZYHJXPfB8M1dx.settimeout(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠺ፒ"))
		dJC476xoE1ecpm0, t3YFnpWVBu = UZYHJXPfB8M1dx.recvfrom(xY4icgQUj6mPVs73CTKu(u"࠶࠶࠲࠵ፓ"))
		UZYHJXPfB8M1dx.close()
		YA4Ki2j8l9OaF6zQpHqwhR5oNvdk0t = hX8BOlfZijNd0x(QQHFtjcaR2VpnSyTIv(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧཆ"), dJC476xoE1ecpm0, e8XhbyuzvjYkIsJUtB5w)
		OqYdn4X5EH = YA4Ki2j8l9OaF6zQpHqwhR5oNvdk0t[uL69vJOU7xN0hGnZf2islDqk]
		peGi5yorMz2vaVFU4W = len(FnCrjE5mLe3lKU)+R3lezw8h407ZvrAFxT(u"࠷࠸ፔ")
		VXdz0nyjQHPLeE = []
		for _8JVPdqftwDk9Y60pXz5sQiceIa in range(OqYdn4X5EH):
			ZqugxpibBwcs6F = peGi5yorMz2vaVFU4W
			j0L1eJudaO = llxMLe4gobHhsj1WGvd7qmIU
			KKiJCvgtnfFhkpWd8r = f4vncKMRlXG9s
			while k6apiPAlLKM1ed8J42RjHh0o:
				yM6TWPmrUfkZg9HLotIbFznY3X = hX8BOlfZijNd0x(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡄࡂࠣཇ"), dJC476xoE1ecpm0, ZqugxpibBwcs6F)[e8XhbyuzvjYkIsJUtB5w]
				if yM6TWPmrUfkZg9HLotIbFznY3X == e8XhbyuzvjYkIsJUtB5w:
					ZqugxpibBwcs6F += llxMLe4gobHhsj1WGvd7qmIU
					break
				if yM6TWPmrUfkZg9HLotIbFznY3X >= wP4kpvXoDHq3hs7TFLyr2COn8(u"࠱࠺࠴ፕ"):
					O8RsqoNp9HlKfP3Be = hX8BOlfZijNd0x(OOkmZiVcfqlEurM1dHGb(u"ࠨ࠾ࡃࠤ཈"), dJC476xoE1ecpm0, ZqugxpibBwcs6F + llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
					ZqugxpibBwcs6F = ((yM6TWPmrUfkZg9HLotIbFznY3X << lNTJCZeBicWEz0Mg(u"࠹ፖ")) + O8RsqoNp9HlKfP3Be - 0xc000) - llxMLe4gobHhsj1WGvd7qmIU
					KKiJCvgtnfFhkpWd8r = k6apiPAlLKM1ed8J42RjHh0o
				ZqugxpibBwcs6F += llxMLe4gobHhsj1WGvd7qmIU
				if KKiJCvgtnfFhkpWd8r == f4vncKMRlXG9s: j0L1eJudaO += llxMLe4gobHhsj1WGvd7qmIU
			if KKiJCvgtnfFhkpWd8r == k6apiPAlLKM1ed8J42RjHh0o: j0L1eJudaO += llxMLe4gobHhsj1WGvd7qmIU
			peGi5yorMz2vaVFU4W = peGi5yorMz2vaVFU4W + j0L1eJudaO
			Bp791Edl2tuq4yJIcbaeMjWDZQ = hX8BOlfZijNd0x(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠢ࠿ࡊࡋࡍࡍࠨཉ"), dJC476xoE1ecpm0, peGi5yorMz2vaVFU4W)
			peGi5yorMz2vaVFU4W = peGi5yorMz2vaVFU4W + fOc18oTm5hsdD4pVZQj(u"࠳࠳ፗ")
			heuBzcqj7G6bniN = Bp791Edl2tuq4yJIcbaeMjWDZQ[e8XhbyuzvjYkIsJUtB5w]
			UIh8ieqO1GutjgsL4YDQfaAn5pHZ3 = Bp791Edl2tuq4yJIcbaeMjWDZQ[uL69vJOU7xN0hGnZf2islDqk]
			if heuBzcqj7G6bniN == llxMLe4gobHhsj1WGvd7qmIU:
				jyCtkzdV4nL1hv6WYbul5 = hX8BOlfZijNd0x(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠣࡀࠥཊ")+HHvYL68lbJVZWM7tQEzSex3(u"ࠤࡅࠦཋ")*UIh8ieqO1GutjgsL4YDQfaAn5pHZ3, dJC476xoE1ecpm0, peGi5yorMz2vaVFU4W)
				ip = NdKhAS6MXVEORLTwob92pxlZ
				for yM6TWPmrUfkZg9HLotIbFznY3X in jyCtkzdV4nL1hv6WYbul5: ip += str(yM6TWPmrUfkZg9HLotIbFznY3X) + HHvYL68lbJVZWM7tQEzSex3(u"ࠪ࠲ࠬཌ")
				ip = ip[e8XhbyuzvjYkIsJUtB5w:-llxMLe4gobHhsj1WGvd7qmIU]
				VXdz0nyjQHPLeE.append(ip)
			if heuBzcqj7G6bniN in [llxMLe4gobHhsj1WGvd7qmIU,cCRvAuJQfjBpTg0PbYiaNO87,PzIpQnUXxRwNCivDhdakWTE(u"࠺ፚ"),OOkmZiVcfqlEurM1dHGb(u"࠼፛"),NOrchaEV1iIZ87Uzlwgum(u"࠵࠺ፙ"),rNyT0edugn(u"࠵࠼ፘ")]: peGi5yorMz2vaVFU4W = peGi5yorMz2vaVFU4W + UIh8ieqO1GutjgsL4YDQfaAn5pHZ3
	except: VXdz0nyjQHPLeE = []
	if not VXdz0nyjQHPLeE: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Tzx81Wb0RZC4ID5AyiU2(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪཌྷ")+FnCrjE5mLe3lKU+NeU6uRGpECkvMV5jf(u"ࠬࠦ࡝ࠨཎ"))
	return VXdz0nyjQHPLeE
def ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,ZZT6GLaHQ1,QQmNifUzRSTZL5jPvy129hA,showDialogs=k6apiPAlLKM1ed8J42RjHh0o):
	if QQmNifUzRSTZL5jPvy129hA:
		SVeiG0daFAsyPWjJHU = [ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ใษษิࠫཏ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧษษ็฾ࠬཐ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡣࡧࡹࡱࡺࠧད"),HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡻࡼࠬདྷ"),HVmIrFwau90jQsgiWzExk(u"ࠪࡷࡪࡾࠧན")]
		if yNIDEX5hU4G769!=LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡇࡕࡋࡓࡃࠪཔ"):
			SVeiG0daFAsyPWjJHU += [Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡸ࠺ࠨཕ"),gniNItGL6bKwpEW(u"࠭ࡲ࠮ࠩབ"),QQHFtjcaR2VpnSyTIv(u"ࠧ࠮࡯ࡤࠫབྷ")]
			SVeiG0daFAsyPWjJHU += [IlL8ZnX74Yvep(u"ࠨ࠼ࡵࠫམ"),OOkmZiVcfqlEurM1dHGb(u"ࠩ࠰ࡶࠬཙ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡱࡦ࠳ࠧཚ")]
		for j7q5bhLFizsntMYOd in QQmNifUzRSTZL5jPvy129hA:
			if QQHFtjcaR2VpnSyTIv(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭ཛ") in j7q5bhLFizsntMYOd: continue
			if JGwsL21ZRlqSrWxEmF(u"ࠬำไใหࠪཛྷ") in j7q5bhLFizsntMYOd: continue
			j7q5bhLFizsntMYOd = j7q5bhLFizsntMYOd.lower()
			if QBp28giCnayJzmZH6vYO: j7q5bhLFizsntMYOd = j7q5bhLFizsntMYOd.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
			j7q5bhLFizsntMYOd = j7q5bhLFizsntMYOd.replace(R3lezw8h407ZvrAFxT(u"࠭࠺ࠨཝ"),NdKhAS6MXVEORLTwob92pxlZ)
			zo6YZGyLvERn9msWaw = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫཞ"),j7q5bhLFizsntMYOd,YYqECUofyi7wFrW.DOTALL)
			uGTkSPN2OBW9MhZVpQDq6lR = f4vncKMRlXG9s
			for QQWC0cbSTBLh2 in zo6YZGyLvERn9msWaw:
				if len(QQWC0cbSTBLh2)==cCRvAuJQfjBpTg0PbYiaNO87:
					uGTkSPN2OBW9MhZVpQDq6lR = k6apiPAlLKM1ed8J42RjHh0o
					break
			if V0VZk9763fusTReHFo4(u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫཟ") in j7q5bhLFizsntMYOd: continue
			elif PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪའ") in j7q5bhLFizsntMYOd: continue
			elif NeU6uRGpECkvMV5jf(u"ࠪ฾๏ืࠠๆื้ๅࠬཡ") in j7q5bhLFizsntMYOd: continue
			elif JcQtOuhMdvYSyLNCw([fOc18oTm5hsdD4pVZQj(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭ར")])[e8XhbyuzvjYkIsJUtB5w]: continue
			elif j7q5bhLFizsntMYOd in [wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡸࠧལ")] or uGTkSPN2OBW9MhZVpQDq6lR or any(K6KbZDHncNizQgl1fr59XV0 in j7q5bhLFizsntMYOd for K6KbZDHncNizQgl1fr59XV0 in SVeiG0daFAsyPWjJHU):
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬཤ")+ZZT6GLaHQ1+JGwsL21ZRlqSrWxEmF(u"ࠧࠡ࡟ࠪཥ"))
				if showDialogs: kkDz5sdaPteM(rNyT0edugn(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫས"),QQHFtjcaR2VpnSyTIv(u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫཧ"))
				return k6apiPAlLKM1ed8J42RjHh0o
	return f4vncKMRlXG9s
def ZaUVqChKHwRLYbeiOv(*aargs,**kkwargs):
	if aargs:
		direction = aargs[e8XhbyuzvjYkIsJUtB5w]
		rifpJXLv0CkbU6wxdW = aargs[llxMLe4gobHhsj1WGvd7qmIU]
		if not direction: direction = HVmIrFwau90jQsgiWzExk(u"ࠪࡧࡪࡴࡴࡦࡴࠪཨ")
		if not rifpJXLv0CkbU6wxdW: rifpJXLv0CkbU6wxdW = V0VZk9763fusTReHFo4(u"ࠫฬูสๆำสีࠬཀྵ")
		P2r8GHo6Nk = aargs[cCRvAuJQfjBpTg0PbYiaNO87]
		HSb5r1Di9I8eKTtAyuNZdC4W = B6IrC7zEHlw1oaeWf.join(aargs[pnHgvFOCBZzc08yULQJGIqw9bf(u"࠳፜"):])
	else: direction,rifpJXLv0CkbU6wxdW,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W = NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡕࡋࠨཪ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	HQK8NwPVcoJ(direction,NdKhAS6MXVEORLTwob92pxlZ,rifpJXLv0CkbU6wxdW,NdKhAS6MXVEORLTwob92pxlZ,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,**kkwargs)
	return
def ggJvHnLYzmlj3Z(*aargs,**kkwargs):
	direction = aargs[e8XhbyuzvjYkIsJUtB5w]
	NN6X3dwe5LJo = aargs[llxMLe4gobHhsj1WGvd7qmIU]
	RpC3kSnflPoN9ArzdOHchgtT = aargs[cCRvAuJQfjBpTg0PbYiaNO87]
	if RpC3kSnflPoN9ArzdOHchgtT or NN6X3dwe5LJo: XTjhc7EVNw3l4BzGC0Mes = k6apiPAlLKM1ed8J42RjHh0o
	else: XTjhc7EVNw3l4BzGC0Mes = f4vncKMRlXG9s
	P2r8GHo6Nk = aargs[uL69vJOU7xN0hGnZf2islDqk]
	HSb5r1Di9I8eKTtAyuNZdC4W = aargs[TQNS6YMKAqnilsVObLpDRX]
	if not direction: direction = hCm2fnEXs6Zt(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ཫ")
	if not NN6X3dwe5LJo: NN6X3dwe5LJo = kb2icmDGVUZfW1OFz7sv(u"ࠧไๆสࠤࠥࡔ࡯ࠨཬ")
	if not RpC3kSnflPoN9ArzdOHchgtT: RpC3kSnflPoN9ArzdOHchgtT = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪ཭")
	if len(aargs)>=eGW7cI6aQhr0(u"࠸፞"): HSb5r1Di9I8eKTtAyuNZdC4W += B6IrC7zEHlw1oaeWf+aargs[Hlp3z0APt1GR4kMYK5xST(u"࠶፝")]
	if len(aargs)>=hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠺፟"): HSb5r1Di9I8eKTtAyuNZdC4W += B6IrC7zEHlw1oaeWf+aargs[wP4kpvXoDHq3hs7TFLyr2COn8(u"࠺፠")]
	IUF5ecZfOplsHom = HQK8NwPVcoJ(direction,NN6X3dwe5LJo,NdKhAS6MXVEORLTwob92pxlZ,RpC3kSnflPoN9ArzdOHchgtT,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,**kkwargs)
	if IUF5ecZfOplsHom==-Tzx81Wb0RZC4ID5AyiU2(u"࠶፡") and XTjhc7EVNw3l4BzGC0Mes: IUF5ecZfOplsHom = -llxMLe4gobHhsj1WGvd7qmIU
	elif IUF5ecZfOplsHom==-llxMLe4gobHhsj1WGvd7qmIU and not XTjhc7EVNw3l4BzGC0Mes: IUF5ecZfOplsHom = f4vncKMRlXG9s
	elif IUF5ecZfOplsHom==e8XhbyuzvjYkIsJUtB5w: IUF5ecZfOplsHom = f4vncKMRlXG9s
	elif IUF5ecZfOplsHom==cCRvAuJQfjBpTg0PbYiaNO87: IUF5ecZfOplsHom = k6apiPAlLKM1ed8J42RjHh0o
	return IUF5ecZfOplsHom
def cCanV8J9iKuojqe5v4(*aargs,**kkwargs):
	return JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Dialog().select(*aargs,**kkwargs)
def kkDz5sdaPteM(*aargs,**kkwargs):
	P2r8GHo6Nk = aargs[e8XhbyuzvjYkIsJUtB5w]
	HSb5r1Di9I8eKTtAyuNZdC4W = aargs[llxMLe4gobHhsj1WGvd7qmIU]
	qRYEV1S6XFmnUzhrK = kkwargs[JGwsL21ZRlqSrWxEmF(u"ࠩࡷ࡭ࡲ࡫ࠧ཮")] if NeU6uRGpECkvMV5jf(u"ࠪࡸ࡮ࡳࡥࠨ཯") in list(kkwargs.keys()) else gniNItGL6bKwpEW(u"࠷࠰࠱࠲።")
	GEXsv7PpyJAC = aargs[cCRvAuJQfjBpTg0PbYiaNO87] if len(aargs)>cCRvAuJQfjBpTg0PbYiaNO87 and lNTJCZeBicWEz0Mg(u"ࠫࡹ࡯࡭ࡦࠩ཰") not in aargs[cCRvAuJQfjBpTg0PbYiaNO87] else PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡷ࡫ࡧࡶ࡮ࡤࡶཱࠬ")
	L74nuaBelp3WCyiOtd8U0xh = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=cb4JrMNwE8u,args=(P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,GEXsv7PpyJAC,qRYEV1S6XFmnUzhrK))
	L74nuaBelp3WCyiOtd8U0xh.start()
	return
def cb4JrMNwE8u(P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,GEXsv7PpyJAC,qRYEV1S6XFmnUzhrK):
	sGQdvPAxSjKyc51DltL4fH = GEXsv7PpyJAC.replace(lRP6GTaZJA1Xw3egLM4(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤི࠭"),NdKhAS6MXVEORLTwob92pxlZ)
	name = LeIEtX7A6J(k6apiPAlLKM1ed8J42RjHh0o,sGQdvPAxSjKyc51DltL4fH+gniNItGL6bKwpEW(u"ࠧࠡ࠯ཱིࠣࠫ")+P2r8GHo6Nk+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠢ࠰ࠤུࠬ")+HSb5r1Di9I8eKTtAyuNZdC4W)
	name = UryVN9KOA5tuqi(name)
	image_filename = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(huOq7j2rEtFN43DLVSGofxnlc,name+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩ࠱ࡴࡳ࡭ཱུࠧ"))
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(image_filename):
		if GEXsv7PpyJAC==QQHFtjcaR2VpnSyTIv(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠪྲྀ"): image_height = OOkmZiVcfqlEurM1dHGb(u"࠱࠲࠹፣")
		elif GEXsv7PpyJAC==PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡥࡺࡺ࡯ࠨཷ"): image_height = hCm2fnEXs6Zt(u"࠳࠳࠳፤")
	else: image_height = XlvB7rxiTQZs6FJKPfOn(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,GEXsv7PpyJAC,IlL8ZnX74Yvep(u"ࠬࡲࡥࡧࡶࠪླྀ"),f4vncKMRlXG9s,image_filename)
	eDUSkwbMiCGRgN = Kb4rUJvNhY(pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭ཹ"),VAzvLnYQrdktx75g,NeU6uRGpECkvMV5jf(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨེ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ࠹࠵࠴ࡵཻ࠭"))
	eDUSkwbMiCGRgN.show()
	if GEXsv7PpyJAC==fOc18oTm5hsdD4pVZQj(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴོ࠭"):
		eDUSkwbMiCGRgN.getControl(lRP6GTaZJA1Xw3egLM4(u"࠼࠴࠹࠶፦")).setHeight(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠴࠴࠹፥"))
		eDUSkwbMiCGRgN.getControl(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠿࠰࠵࠲፩")).setPosition(NOrchaEV1iIZ87Uzlwgum(u"࠹࠺፧"),-vju3SZDWL4ENYelmBOzUqrogp2(u"࠽࠶፨"))
		eDUSkwbMiCGRgN.getControl(eGW7cI6aQhr0(u"࠹࠱࠷࠳፪")).setPosition(HHvYL68lbJVZWM7tQEzSex3(u"࠲࠴࠳፫"),-V0VZk9763fusTReHFo4(u"࠸࠳፬"))
		eDUSkwbMiCGRgN.getControl(OOkmZiVcfqlEurM1dHGb(u"࠹࠶࠰፯")).setPosition(HVmIrFwau90jQsgiWzExk(u"࠼࠴፭"),-NOrchaEV1iIZ87Uzlwgum(u"࠷࠺፮"))
	eDUSkwbMiCGRgN.getControl(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠺࠰࠲፰")).setVisible(f4vncKMRlXG9s)
	eDUSkwbMiCGRgN.getControl(HVmIrFwau90jQsgiWzExk(u"࠴࠱࠴፱")).setVisible(f4vncKMRlXG9s)
	eDUSkwbMiCGRgN.getControl(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠺࠲࠸࠴፲")).setImage(image_filename)
	eDUSkwbMiCGRgN.getControl(V0VZk9763fusTReHFo4(u"࠻࠳࠹࠵፳")).setHeight(image_height)
	XJ62UBRmIqFvfiNTQj.sleep(qRYEV1S6XFmnUzhrK//YJpWv4QzC7sx8INVPukeZiOD03K(u"࠴࠴࠵࠶࠮࠱፴"))
	return
def AGLwyhimZ4uT5qjd0K(*aargs,**kkwargs):
	P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,profile,direction = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪཽࠫ"),NeU6uRGpECkvMV5jf(u"ࠫࡱ࡫ࡦࡵࠩཾ")
	if len(aargs)>=llxMLe4gobHhsj1WGvd7qmIU: P2r8GHo6Nk = aargs[e8XhbyuzvjYkIsJUtB5w]
	if len(aargs)>=cCRvAuJQfjBpTg0PbYiaNO87: HSb5r1Di9I8eKTtAyuNZdC4W = aargs[llxMLe4gobHhsj1WGvd7qmIU]
	if len(aargs)>=uL69vJOU7xN0hGnZf2islDqk: profile = aargs[cCRvAuJQfjBpTg0PbYiaNO87]
	if len(aargs)>=TQNS6YMKAqnilsVObLpDRX: direction = aargs[uL69vJOU7xN0hGnZf2islDqk]
	return cGY04x76XBKoQWJg9R5d2pkIvOsTFD(direction,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,profile)
def eYEZS7Nzmd3jXyFq4(*aargs,**kkwargs):
	return JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Dialog().contextmenu(*aargs,**kkwargs)
def xgIRMkJHuDWX4YNh7a(*aargs,**kkwargs):
	return JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Dialog().browseSingle(*aargs,**kkwargs)
def lUCgB1053Z6NWj2AyvScxGkImF7(*aargs,**kkwargs):
	return JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Dialog().input(*aargs,**kkwargs)
def UpNqSvlOPeuKntGWCT1rR3aI4b(*aargs,**kkwargs):
	return JTIdpcz98k7RyxHOX5EnqD6L1vKe04.DialogProgress(*aargs,**kkwargs)
def HQK8NwPVcoJ(direction,button0=NdKhAS6MXVEORLTwob92pxlZ,button1=NdKhAS6MXVEORLTwob92pxlZ,button2=NdKhAS6MXVEORLTwob92pxlZ,P2r8GHo6Nk=NdKhAS6MXVEORLTwob92pxlZ,HSb5r1Di9I8eKTtAyuNZdC4W=NdKhAS6MXVEORLTwob92pxlZ,profile=vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧཿ"),rJxMQs0bm4DT3ZYvd5CH=e8XhbyuzvjYkIsJUtB5w,cANIhJeYB6rQz02akdSlb8nT1PsO=e8XhbyuzvjYkIsJUtB5w):
	if not direction: direction = ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡣࡦࡰࡷࡩࡷྀ࠭")
	eDUSkwbMiCGRgN = vOxDiB8g9WoVtqkXcN3w6HEfp4UL(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ཱྀࠩ"),VAzvLnYQrdktx75g,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩྂ"),gniNItGL6bKwpEW(u"ࠩ࠺࠶࠵ࡶࠧྃ"))
	eDUSkwbMiCGRgN.j36ISCpsVrAmvYXU(button0,button1,button2,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,profile,direction,rJxMQs0bm4DT3ZYvd5CH,cANIhJeYB6rQz02akdSlb8nT1PsO)
	if rJxMQs0bm4DT3ZYvd5CH>e8XhbyuzvjYkIsJUtB5w: eDUSkwbMiCGRgN.EeOqGNzmoTDCfrkRs581tSBwbvKM()
	if cANIhJeYB6rQz02akdSlb8nT1PsO>e8XhbyuzvjYkIsJUtB5w: eDUSkwbMiCGRgN.TijIZx9e6PY5FawNvUGMX()
	if rJxMQs0bm4DT3ZYvd5CH==e8XhbyuzvjYkIsJUtB5w and cANIhJeYB6rQz02akdSlb8nT1PsO==e8XhbyuzvjYkIsJUtB5w: eDUSkwbMiCGRgN.zqHvCfI25hrWLPTcp()
	eDUSkwbMiCGRgN.doModal()
	IUF5ecZfOplsHom = eDUSkwbMiCGRgN.choiceID
	return IUF5ecZfOplsHom
def cGY04x76XBKoQWJg9R5d2pkIvOsTFD(direction,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,profile=OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪ྄ࠫ")):
	if not direction: direction = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡱ࡫ࡦࡵࠩ྅")
	eDUSkwbMiCGRgN = Kb4rUJvNhY(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨ྆"),VAzvLnYQrdktx75g,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ྇"),eGW7cI6aQhr0(u"ࠧ࠸࠴࠳ࡴࠬྈ"))
	image_filename = QQHtOBLs25fTp7Imo.replace(QQHFtjcaR2VpnSyTIv(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨྉ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡢࠫྊ")+str(XJ62UBRmIqFvfiNTQj.time())+R3lezw8h407ZvrAFxT(u"ࠪࡣࠬྋ"))
	image_filename = image_filename.replace(rNyT0edugn(u"ࠫࡡࡢࠧྌ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡢ࡜࡝࡞ࠪྍ")).replace(IlL8ZnX74Yvep(u"࠭࠯࠰ࠩྎ"),gniNItGL6bKwpEW(u"ࠧ࠰࠱࠲࠳ࠬྏ"))
	image_height = XlvB7rxiTQZs6FJKPfOn(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,P2r8GHo6Nk,HSb5r1Di9I8eKTtAyuNZdC4W,profile,direction,f4vncKMRlXG9s,image_filename)
	eDUSkwbMiCGRgN.show()
	eDUSkwbMiCGRgN.getControl(HHvYL68lbJVZWM7tQEzSex3(u"࠽࠵࠻࠰፵")).setHeight(image_height)
	eDUSkwbMiCGRgN.getControl(Hlp3z0APt1GR4kMYK5xST(u"࠾࠶࠵࠱፶")).setImage(image_filename)
	nV80a1XQzqi3wgcCrD = eDUSkwbMiCGRgN.doModal()
	try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(image_filename)
	except: pass
	return nV80a1XQzqi3wgcCrD
def kkCjlxiynwT34GVFc(DD0bWEd5YeX=k6apiPAlLKM1ed8J42RjHh0o):
	if DD0bWEd5YeX:
		VVBkbI2DtyaWw6mQp0 = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,V0VZk9763fusTReHFo4(u"ࠨࡵࡷࡶࠬྐ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬྑ"),NeU6uRGpECkvMV5jf(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭ྒ"))
		if VVBkbI2DtyaWw6mQp0: return VVBkbI2DtyaWw6mQp0
	HSb5r1Di9I8eKTtAyuNZdC4W = NdKhAS6MXVEORLTwob92pxlZ
	if e8XhbyuzvjYkIsJUtB5w and MmDs0fWOCc3Bg.succeeded:
		tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
		ZZiHOu2GRo5SrgImeL34 = tWcXU498FSdjKl2Iw7M.count(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥࠬྒྷ"))
		if ZZiHOu2GRo5SrgImeL34>LtGoXlQ2IYxqTJRySE6udfW98(u"࠾࠰፷"):
			HSb5r1Di9I8eKTtAyuNZdC4W = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࡭ࡥࡵ࠯ࡷ࡬ࡪ࠳࡬ࡪࡵࡷ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧྔ"),tWcXU498FSdjKl2Iw7M,YYqECUofyi7wFrW.DOTALL)
			HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W[e8XhbyuzvjYkIsJUtB5w]
	if not HSb5r1Di9I8eKTtAyuNZdC4W:
		ZikQmFCHn6jgURK = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,hCm2fnEXs6Zt(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬྕ"),eGW7cI6aQhr0(u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨྖ"))
		HSb5r1Di9I8eKTtAyuNZdC4W = open(ZikQmFCHn6jgURK,lRP6GTaZJA1Xw3egLM4(u"ࠨࡴࡥࠫྗ")).read()
		if J92gCnbGWidQV70lBteTwU6D8uyzL: HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.decode(YRvPKe2zMTDs8UCkr)
		HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)
	VlHQvSAoRm1K7fDXcqag = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠩࠫࡑࡴࢀࡩ࡭࡮ࡤ࠲࠯ࡅࠩ࡝ࡰࠪ྘"),HSb5r1Di9I8eKTtAyuNZdC4W,YYqECUofyi7wFrW.DOTALL)
	hrCmQfU8pjqKYi = []
	for HR3U1ZcNgzoIifnu5tBA in VlHQvSAoRm1K7fDXcqag:
		EEQFvU5nWa1uNiIO8tJByD9mcSjkKX = HR3U1ZcNgzoIifnu5tBA.lower()
		if hCm2fnEXs6Zt(u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫྙ") in EEQFvU5nWa1uNiIO8tJByD9mcSjkKX: continue
		if IlL8ZnX74Yvep(u"ࠫࡺࡨࡵ࡯ࡶࡸࠫྚ") in EEQFvU5nWa1uNiIO8tJByD9mcSjkKX: continue
		if eGW7cI6aQhr0(u"ࠬ࡯ࡰࡩࡱࡱࡩࠬྛ") in EEQFvU5nWa1uNiIO8tJByD9mcSjkKX: continue
		if QQHFtjcaR2VpnSyTIv(u"࠭ࡣࡳࡱࡶࠫྜ") in EEQFvU5nWa1uNiIO8tJByD9mcSjkKX: continue
		hrCmQfU8pjqKYi.append(HR3U1ZcNgzoIifnu5tBA)
	VVBkbI2DtyaWw6mQp0 = Ijo3hy7zQO5x8aU9vAZDMV.sample(hrCmQfU8pjqKYi,llxMLe4gobHhsj1WGvd7qmIU)
	VVBkbI2DtyaWw6mQp0 = VVBkbI2DtyaWw6mQp0[e8XhbyuzvjYkIsJUtB5w]
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,JGwsL21ZRlqSrWxEmF(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪྜྷ"),eGW7cI6aQhr0(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫྞ"),VVBkbI2DtyaWw6mQp0,h1dnE0q2zFHjXlvyGuLZxw)
	return VVBkbI2DtyaWw6mQp0
def ZeaDz4KMlg5bSRBfT1tnVCGH(ihuUeAVfaSbXMNn=NdKhAS6MXVEORLTwob92pxlZ):
	showDialogs = k6apiPAlLKM1ed8J42RjHh0o if OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX==NdKhAS6MXVEORLTwob92pxlZ else OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX
	if not showDialogs: return
	if not ihuUeAVfaSbXMNn: ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
	if Hlp3z0APt1GR4kMYK5xST(u"ࠩࡖࡽࡸࡺࡥ࡮ࡇࡻ࡭ࡹ࠭ྟ") in ihuUeAVfaSbXMNn or vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ྠ") in ihuUeAVfaSbXMNn: return
	if ihuUeAVfaSbXMNn!=YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧྡ"): hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
	aLZSGBw7NhXtCuDWgJR = ihuUeAVfaSbXMNn.splitlines()
	XvUfhH2qm6TMaw5bl9WVO1B = aLZSGBw7NhXtCuDWgJR[-HHvYL68lbJVZWM7tQEzSex3(u"࠱፸")]
	kdRE9PFX427 = open(ASInatQNLOxmbF,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡸࡢࠨྡྷ")).read()
	if J92gCnbGWidQV70lBteTwU6D8uyzL: kdRE9PFX427 = kdRE9PFX427.decode(YRvPKe2zMTDs8UCkr)
	kdRE9PFX427 = kdRE9PFX427[-kb2icmDGVUZfW1OFz7sv(u"࠹࠲࠳࠴፹"):]
	mqgWoY2a3fw9MUB = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࠽ࠨྣ")*HVmIrFwau90jQsgiWzExk(u"࠳࠳࠴፺")
	if mqgWoY2a3fw9MUB in kdRE9PFX427: kdRE9PFX427 = kdRE9PFX427.rsplit(mqgWoY2a3fw9MUB,llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
	if XvUfhH2qm6TMaw5bl9WVO1B in kdRE9PFX427: kdRE9PFX427 = kdRE9PFX427.rsplit(XvUfhH2qm6TMaw5bl9WVO1B,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
	wLZmC8xs1QMFh92 = YYqECUofyi7wFrW.findall(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭ྤ"),kdRE9PFX427,YYqECUofyi7wFrW.DOTALL)
	for YcpGlJBEQg92HNKICbXqAi03,xmezOWMyhSXRGHlEk2JnsI in reversed(wLZmC8xs1QMFh92):
		if xmezOWMyhSXRGHlEk2JnsI: break
	else: xmezOWMyhSXRGHlEk2JnsI = lRP6GTaZJA1Xw3egLM4(u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨྥ")
	u45yDBATUY9C30mGEX1HS,HR3U1ZcNgzoIifnu5tBA,E0EVJp2ylAd9RO1 = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	mxAnQLlOUyCP0IsFfTvzV = Tzx81Wb0RZC4ID5AyiU2(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨྦ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+lrtFSogC8Nh9(u"ࠪห้ิืฤ࠼ࠣࠤࠬྦྷ")+kjd9LyNqQHMUevZiRI7OlBGF1h+XvUfhH2qm6TMaw5bl9WVO1B
	ueCnDqN7ymJKgjcFRvA = R3lezw8h407ZvrAFxT(u"ࠫࡠࡘࡔࡍ࡟ࠪྨ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+HHvYL68lbJVZWM7tQEzSex3(u"ࠬอไๆืาี࠿ࠦࠠࠨྩ")+kjd9LyNqQHMUevZiRI7OlBGF1h+xmezOWMyhSXRGHlEk2JnsI
	for H1pGYSweEhy0bMBu83PsDAlkUjXJ in reversed(aLZSGBw7NhXtCuDWgJR):
		if vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭ྪ") in H1pGYSweEhy0bMBu83PsDAlkUjXJ and Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ྫ") in H1pGYSweEhy0bMBu83PsDAlkUjXJ: break
	H1pGYSweEhy0bMBu83PsDAlkUjXJ = YYqECUofyi7wFrW.findall(OOkmZiVcfqlEurM1dHGb(u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫྫྷ"),H1pGYSweEhy0bMBu83PsDAlkUjXJ,YYqECUofyi7wFrW.DOTALL)
	if H1pGYSweEhy0bMBu83PsDAlkUjXJ:
		u45yDBATUY9C30mGEX1HS,HR3U1ZcNgzoIifnu5tBA,E0EVJp2ylAd9RO1 = H1pGYSweEhy0bMBu83PsDAlkUjXJ[e8XhbyuzvjYkIsJUtB5w]
		if eGW7cI6aQhr0(u"ࠩ࠲ࠫྭ") in u45yDBATUY9C30mGEX1HS: u45yDBATUY9C30mGEX1HS = u45yDBATUY9C30mGEX1HS.rsplit(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࠳ࠬྮ"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
		else: u45yDBATUY9C30mGEX1HS = u45yDBATUY9C30mGEX1HS.rsplit(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡡࡢࠧྯ"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
		ZpYrqjDz5o24gN3JlAawS6 = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡡࡒࡕࡎࡠࠫྰ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+xY4icgQUj6mPVs73CTKu(u"࠭วๅ็็ๅ࠿ࠦࠠࠨྱ")+kjd9LyNqQHMUevZiRI7OlBGF1h+u45yDBATUY9C30mGEX1HS
		KUxan7uHTNvMwYP4b9GeAy1O = fOc18oTm5hsdD4pVZQj(u"ࠧ࡜ࡔࡗࡐࡢ࠭ྲ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+fOc18oTm5hsdD4pVZQj(u"ࠨษ็ื฼ื࠺ࠡࠢࠪླ")+kjd9LyNqQHMUevZiRI7OlBGF1h+HR3U1ZcNgzoIifnu5tBA
		HwBTkRPfI21vunYSlQXbUx5mg73e = Hlp3z0APt1GR4kMYK5xST(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨྴ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪห้๋ใศ่࠽ࠤࠥ࠭ྵ")+kjd9LyNqQHMUevZiRI7OlBGF1h+E0EVJp2ylAd9RO1
		qHwKY5RPLWANEuMI3lx = ZpYrqjDz5o24gN3JlAawS6+B6IrC7zEHlw1oaeWf+KUxan7uHTNvMwYP4b9GeAy1O+B6IrC7zEHlw1oaeWf+HwBTkRPfI21vunYSlQXbUx5mg73e+B6IrC7zEHlw1oaeWf+ueCnDqN7ymJKgjcFRvA+B6IrC7zEHlw1oaeWf+mxAnQLlOUyCP0IsFfTvzV
		uLtMP4K032r9OkpSZAFcV8nlx6dB = KUxan7uHTNvMwYP4b9GeAy1O+B6IrC7zEHlw1oaeWf+ueCnDqN7ymJKgjcFRvA+B6IrC7zEHlw1oaeWf+mxAnQLlOUyCP0IsFfTvzV+B6IrC7zEHlw1oaeWf+ZpYrqjDz5o24gN3JlAawS6+B6IrC7zEHlw1oaeWf+HwBTkRPfI21vunYSlQXbUx5mg73e
		SUBVzQaxcImMJRfEAPqe = KUxan7uHTNvMwYP4b9GeAy1O+B6IrC7zEHlw1oaeWf+mxAnQLlOUyCP0IsFfTvzV+B6IrC7zEHlw1oaeWf+ZpYrqjDz5o24gN3JlAawS6+B6IrC7zEHlw1oaeWf+HwBTkRPfI21vunYSlQXbUx5mg73e
	else:
		ZpYrqjDz5o24gN3JlAawS6,KUxan7uHTNvMwYP4b9GeAy1O,HwBTkRPfI21vunYSlQXbUx5mg73e = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		qHwKY5RPLWANEuMI3lx = ueCnDqN7ymJKgjcFRvA+HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡡࡴ࡜࡯ࠩྶ")+mxAnQLlOUyCP0IsFfTvzV
		uLtMP4K032r9OkpSZAFcV8nlx6dB = ueCnDqN7ymJKgjcFRvA+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡢ࡮࡝ࡰࠪྷ")+mxAnQLlOUyCP0IsFfTvzV
		SUBVzQaxcImMJRfEAPqe = mxAnQLlOUyCP0IsFfTvzV
	Ug8SQ5iMrqFh2L0wmOcRXv9KDC7Ae = lRP6GTaZJA1Xw3egLM4(u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัࠪྸ")+B6IrC7zEHlw1oaeWf
	pmGySuDJA7ho = ZwKR1OatDkTCdy7c()
	KxjraNEB3PlHs81AtQnqyGcivV = []
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = pmGySuDJA7ho[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬྐྵ")]
	ZwL3ExR1nJ40BWQMTsKCihY = EFhOxiHtUq2cmaNPedwSQkI5BXDzg(lvsJ2jaZktmNO6PbdXS)
	if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ྺ") in list(pmGySuDJA7ho.keys()):
		for IIrhNlSeJAw1yCTs7RX0BVE9WobKm,UmoyND3rkc,YVmGRrwvUHbxgfJPnkCEND9 in UEsxyfd8rZMLOHgzc6emSFKD0ktYiT:
			KxjraNEB3PlHs81AtQnqyGcivV = max(KxjraNEB3PlHs81AtQnqyGcivV,UmoyND3rkc)
		if ZwL3ExR1nJ40BWQMTsKCihY<KxjraNEB3PlHs81AtQnqyGcivV:
			P2r8GHo6Nk = lRP6GTaZJA1Xw3egLM4(u"ࠩๅ้ࠥฮสฮัํฯࠥอไษำ้ห๊าࠠใส็ࠤสืำศๆࠣห้ษฮุษฤࠤ้๊ๅษำ่ะࠬྻ")
			IUF5ecZfOplsHom = HQK8NwPVcoJ(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡶ࡮࡭ࡨࡵࠩྼ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ྽"),IlL8ZnX74Yvep(u"ࠬะอะ์ฮࠫ྾"),R3lezw8h407ZvrAFxT(u"࠭ฮา๊ฯࠫ྿"),Ug8SQ5iMrqFh2L0wmOcRXv9KDC7Ae+P2r8GHo6Nk,qHwKY5RPLWANEuMI3lx)
			if IUF5ecZfOplsHom==llxMLe4gobHhsj1WGvd7qmIU:
				import oMV3OL4Bzl
				oMV3OL4Bzl.uuKwU7AkCmnMylP8gqsdeHxLb5i(k6apiPAlLKM1ed8J42RjHh0o)
				yyTm3OqzGEYApS()
			elif IUF5ecZfOplsHom==cCRvAuJQfjBpTg0PbYiaNO87: yyTm3OqzGEYApS()
	MyoruWEtPJUb1XCkqdhpZIVi = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,gniNItGL6bKwpEW(u"ࠧ࡭࡫ࡶࡸࠬ࿀"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ࿁"),Hlp3z0APt1GR4kMYK5xST(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ࿂"))
	if not MyoruWEtPJUb1XCkqdhpZIVi: MyoruWEtPJUb1XCkqdhpZIVi = []
	uLtMP4K032r9OkpSZAFcV8nlx6dB = uLtMP4K032r9OkpSZAFcV8nlx6dB.replace(B6IrC7zEHlw1oaeWf,JGwsL21ZRlqSrWxEmF(u"ࠪࡠࡡࡴࠧ࿃")).replace(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡠࡘࡔࡍ࡟ࠪ࿄"),NdKhAS6MXVEORLTwob92pxlZ).replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,NdKhAS6MXVEORLTwob92pxlZ).replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)
	SUBVzQaxcImMJRfEAPqe = SUBVzQaxcImMJRfEAPqe.replace(B6IrC7zEHlw1oaeWf,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡢ࡜࡯ࠩ࿅")).replace(QQHFtjcaR2VpnSyTIv(u"࡛࠭ࡓࡖࡏࡡ࿆ࠬ"),NdKhAS6MXVEORLTwob92pxlZ).replace(D7INg5kyRjwf4ZtoePVUrb1h2SJ,NdKhAS6MXVEORLTwob92pxlZ).replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)
	fOyNmxu26lAGvr3eopR09hYcVPjEWb = lvsJ2jaZktmNO6PbdXS+lrtFSogC8Nh9(u"ࠧ࠻࠼ࠪ࿇")+SUBVzQaxcImMJRfEAPqe
	if fOyNmxu26lAGvr3eopR09hYcVPjEWb in MyoruWEtPJUb1XCkqdhpZIVi:
		P2r8GHo6Nk = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭࿈")
		ZaUVqChKHwRLYbeiOv(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡵ࡭࡬࡮ࡴࠨ࿉"),NdKhAS6MXVEORLTwob92pxlZ,Ug8SQ5iMrqFh2L0wmOcRXv9KDC7Ae+P2r8GHo6Nk,qHwKY5RPLWANEuMI3lx)
		return
	KBFscea86IxdJrTpPR5v97UDYS = str(kQI947MebLovYyVE08F5qPi6fj3).split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࠲ࠬ࿊"))[e8XhbyuzvjYkIsJUtB5w]
	ZZT6GLaHQ1 = xKp3jkIvM09AZ4euXa87i5TVtfUD[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ࿋")][OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠹፻")]
	MmDs0fWOCc3Bg = cJaAB4uQyp(NXpO8DrVmeE,QQHFtjcaR2VpnSyTIv(u"ࠬࡖࡏࡔࡖࠪ࿌"),ZZT6GLaHQ1,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧ࿍"),f4vncKMRlXG9s,f4vncKMRlXG9s)
	tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
	wy40QuZTqbkHLr = YYqECUofyi7wFrW.findall(OOkmZiVcfqlEurM1dHGb(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡋࡎࡅ࠼࠽ࡉࡓࡊࠧ࿎"),tWcXU498FSdjKl2Iw7M,YYqECUofyi7wFrW.DOTALL)
	for DVBs6vKWwzgTxQMfY5EAncuiXOe8I,XDdR05gIp7kNuhomMByZWz9Vai,A7ASX5LOmY6hzQfcbuZ,SGEj3mQrXOhkPbIwFz94Ypg5 in wy40QuZTqbkHLr:
		DVBs6vKWwzgTxQMfY5EAncuiXOe8I = DVBs6vKWwzgTxQMfY5EAncuiXOe8I.split(fOc18oTm5hsdD4pVZQj(u"ࠨ࠭ࠪ࿏"))
		A7ASX5LOmY6hzQfcbuZ = A7ASX5LOmY6hzQfcbuZ.split(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࠮ࠫ࿐"))
		SGEj3mQrXOhkPbIwFz94Ypg5 = SGEj3mQrXOhkPbIwFz94Ypg5.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࠯ࠬ࿑"))
		if HR3U1ZcNgzoIifnu5tBA in DVBs6vKWwzgTxQMfY5EAncuiXOe8I and XvUfhH2qm6TMaw5bl9WVO1B==XDdR05gIp7kNuhomMByZWz9Vai and lvsJ2jaZktmNO6PbdXS in A7ASX5LOmY6hzQfcbuZ and KBFscea86IxdJrTpPR5v97UDYS in SGEj3mQrXOhkPbIwFz94Ypg5:
			P2r8GHo6Nk = Tzx81Wb0RZC4ID5AyiU2(u"ࠫ์ึวࠡษ็า฼ษࠠๆ฻ิ์ๆ่ࠦิ์฼ห้าࠠษษ็ษฺีวาࠢส่็อฯๆࠩ࿒")
			TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(IlL8ZnX74Yvep(u"ࠬࡸࡩࡨࡪࡷࠫ࿓"),hCm2fnEXs6Zt(u"࠭ฮา๊ฯࠫ࿔"),Tzx81Wb0RZC4ID5AyiU2(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ࿕"),Ug8SQ5iMrqFh2L0wmOcRXv9KDC7Ae+P2r8GHo6Nk,qHwKY5RPLWANEuMI3lx)
			if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU: ZaUVqChKHwRLYbeiOv(JGwsL21ZRlqSrWxEmF(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࿖"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,P2r8GHo6Nk)
			return
	P2r8GHo6Nk = IlL8ZnX74Yvep(u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ࿗")
	Jc7R92k15u = HQK8NwPVcoJ(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡶ࡮࡭ࡨࡵࠩ࿘"),kb2icmDGVUZfW1OFz7sv(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ࿙"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬะอะ์ฮࠤัุฦ๋ࠩ࿚"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭สฮัํฯࠥอไษำ้ห๊าࠧ࿛"),Ug8SQ5iMrqFh2L0wmOcRXv9KDC7Ae+P2r8GHo6Nk,qHwKY5RPLWANEuMI3lx)
	if Jc7R92k15u==llxMLe4gobHhsj1WGvd7qmIU:
		Y6N8DUvSxeBFnKz(f4vncKMRlXG9s)
		kkDz5sdaPteM(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠥอไอิษ๎ࠬ࿜"),eGW7cI6aQhr0(u"ࠨ๏ࡖࡹࡨࡩࡥࡴࡵࠪ࿝"),XJ62UBRmIqFvfiNTQj=rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠻࠺࠶፼"))
		yyTm3OqzGEYApS()
	elif Jc7R92k15u==cCRvAuJQfjBpTg0PbYiaNO87:
		import oMV3OL4Bzl
		oMV3OL4Bzl.uuKwU7AkCmnMylP8gqsdeHxLb5i(k6apiPAlLKM1ed8J42RjHh0o)
		yyTm3OqzGEYApS()
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(lNTJCZeBicWEz0Mg(u"ࠩࡦࡩࡳࡺࡥࡳࠩ࿞"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿟"),lRP6GTaZJA1Xw3egLM4(u"ุࠫ๎แࠡ์อ้ࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์฼ีๆࠦวๅ็หี๊าࠠฤ์้ࠤํ๋ส๊๋ࠢ็๏็้ࠠๆ่หีอࠠฮื็ฮࠥํะ่ࠢสฺ่๊ใๅห่ࠣศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥอีๅษะࠤฺ๊ใๅหࠣ์์๎ࠠๅษࠣ๎฾ืแࠡๅํๅࠥ฾็าฬࠣ์้๋วัษࠣ฼์ืส๊่ࠡฮ๎ุ่ࠦำอࠤ์ึ็ࠡษ็ู้้ไสࠢ࠱ࠤ์๊ࠠหำํำࠥษัิษ็ࠤฬ๊ำอๆࠣรࠬ࿠"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU: AL5hPfTU9Dmuy1VwxOvX7o0KN4 = rNyT0edugn(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ࿡")
	else:
		ZaUVqChKHwRLYbeiOv(PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࿢"),NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࿣"),D7INg5kyRjwf4ZtoePVUrb1h2SJ+PzIpQnUXxRwNCivDhdakWTE(u"ࠨฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽รࠨ࿤")+kjd9LyNqQHMUevZiRI7OlBGF1h+Hlp3z0APt1GR4kMYK5xST(u"ࠩ࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬ࿥"))
		return
	ntDbV4lpe3WzTJ = uLtMP4K032r9OkpSZAFcV8nlx6dB
	import oMV3OL4Bzl
	PsKJk8XRHAQM = oMV3OL4Bzl.TM3EgsyYRtVxA9i(hCm2fnEXs6Zt(u"ࠪࡉࡷࡸ࡯ࡳࡵࠪ࿦"),ntDbV4lpe3WzTJ,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫ࿧"),AL5hPfTU9Dmuy1VwxOvX7o0KN4)
	if PsKJk8XRHAQM and AL5hPfTU9Dmuy1VwxOvX7o0KN4:
		MyoruWEtPJUb1XCkqdhpZIVi.append(fOyNmxu26lAGvr3eopR09hYcVPjEWb)
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ࿨"),QQHFtjcaR2VpnSyTIv(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ࿩"),MyoruWEtPJUb1XCkqdhpZIVi,hzP83xLawFqYneDtHGmSriWE)
	return
def El28JQ9TdkPsr(dJC476xoE1ecpm0,filename=None):
	if J92gCnbGWidQV70lBteTwU6D8uyzL: dJC476xoE1ecpm0 = dJC476xoE1ecpm0.encode(YRvPKe2zMTDs8UCkr)
	if not filename: hNfrb20intZpMPUI3w = PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧ࿪")+str(XJ62UBRmIqFvfiNTQj.time())+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨ࠰ࡧࡥࡹ࠭࿫")
	else: hNfrb20intZpMPUI3w = HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤࡠࠩ࿬")+filename+QQHFtjcaR2VpnSyTIv(u"ࠪ࠲ࡩࡧࡴࠨ࿭")
	open(hNfrb20intZpMPUI3w,hCm2fnEXs6Zt(u"ࠫࡼࡨࠧ࿮")).write(dJC476xoE1ecpm0)
	return
def igNr4jWHh8eIS0bM(pma7xfu1g43KVTMFQ):
	if pma7xfu1g43KVTMFQ:
		oo8Tv5VBQAZbptxl = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,rNyT0edugn(u"ࠬࡲࡩࡴࡶࠪ࿯"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ࿰"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ࿱"))
		if oo8Tv5VBQAZbptxl: return oo8Tv5VBQAZbptxl
	ZZT6GLaHQ1 = xKp3jkIvM09AZ4euXa87i5TVtfUD[Hlp3z0APt1GR4kMYK5xST(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ࿲")][HHvYL68lbJVZWM7tQEzSex3(u"࠺፽")]
	gMXJ1uE2flZASBm6jYhspTnIe = nvHz4MPEfa6Q1D5cydq(f4vncKMRlXG9s) if not pma7xfu1g43KVTMFQ else lop0ZwWYLmxOPAaErzF6cQvDkVR
	HMpc7T2lNkGV3CEyPFI8hvq9aS = Fa1ehN3qiLZ8tfwj()
	wziCR1x4XQEAOB9U6KfGJYmTHl8 = HMpc7T2lNkGV3CEyPFI8hvq9aS.split(Hlp3z0APt1GR4kMYK5xST(u"ࠩ࠯ࠫ࿳"))[cCRvAuJQfjBpTg0PbYiaNO87]
	iJM4pYxHqdgwmb = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,V0VZk9763fusTReHFo4(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ࿴"))
	NiLBlXEqVw7jdvYc9HU510Prhy = J3qavAbx1ZNmS2YHkEjXK6()
	EEbWxcT86wIO54GFZgmoveXC = {R3lezw8h407ZvrAFxT(u"ࠫࡺࡹࡥࡳࠩ࿵"):gMXJ1uE2flZASBm6jYhspTnIe,rNyT0edugn(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭࿶"):lvsJ2jaZktmNO6PbdXS,lRP6GTaZJA1Xw3egLM4(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ࿷"):wziCR1x4XQEAOB9U6KfGJYmTHl8,OOkmZiVcfqlEurM1dHGb(u"ࠧࡪࡦࡶࠫ࿸"):R4kMS9YE5Nby3giq(NiLBlXEqVw7jdvYc9HU510Prhy)}
	MmDs0fWOCc3Bg = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,rNyT0edugn(u"ࠨࡒࡒࡗ࡙࠭࿹"),ZZT6GLaHQ1,EEbWxcT86wIO54GFZgmoveXC,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ࿺"))
	oo8Tv5VBQAZbptxl = []
	if MmDs0fWOCc3Bg.succeeded:
		tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
		oo8Tv5VBQAZbptxl = tWcXU498FSdjKl2Iw7M.replace(fOc18oTm5hsdD4pVZQj(u"ࠪࡠࡡࡸࠧ࿻"),B6IrC7zEHlw1oaeWf).replace(rNyT0edugn(u"ࠫࡡࡢ࡮ࠨ࿼"),B6IrC7zEHlw1oaeWf).replace(IlL8ZnX74Yvep(u"ࠬࡢࡲ࡝ࡰࠪ࿽"),B6IrC7zEHlw1oaeWf).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,B6IrC7zEHlw1oaeWf)
		oo8Tv5VBQAZbptxl = YYqECUofyi7wFrW.findall(QQHFtjcaR2VpnSyTIv(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ࿾"),oo8Tv5VBQAZbptxl,YYqECUofyi7wFrW.DOTALL)
		if oo8Tv5VBQAZbptxl:
			oo8Tv5VBQAZbptxl = sorted(oo8Tv5VBQAZbptxl,reverse=f4vncKMRlXG9s,key=lambda key: int(key[e8XhbyuzvjYkIsJUtB5w]))
			mpGDaUVONIECixkJYgoKlvB0tP,gMXJ1uE2flZASBm6jYhspTnIe,dhfVevor7I2tWBm,VXdz0nyjQHPLeE,jjpbVgW3hUw7XMyFI50N9ismLlGv2,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy = oo8Tv5VBQAZbptxl[e8XhbyuzvjYkIsJUtB5w]
			mAI7WaKBLyr5E2FGQD = wNiDIHWX0BOk7ezTgfPx1RtVMvuKy if JcQtOuhMdvYSyLNCw([R3lezw8h407ZvrAFxT(u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭࿿")])[e8XhbyuzvjYkIsJUtB5w] else dhfVevor7I2tWBm
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OOkmZiVcfqlEurM1dHGb(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪက"),mAI7WaKBLyr5E2FGQD)
			eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬခ"),xY4icgQUj6mPVs73CTKu(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ဂ"),oo8Tv5VBQAZbptxl,h1dnE0q2zFHjXlvyGuLZxw)
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(Hlp3z0APt1GR4kMYK5xST(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ဃ"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
	return oo8Tv5VBQAZbptxl
def egfRV9FZMqoOKvU5IEJ7Sdw1l2a(E5q7eGByuf1N9rV2LiozUaP,goAPKzw5S2fBuqbjXM0a61TW8=e8XhbyuzvjYkIsJUtB5w,UdrDPKvYnJO8ciE9FQwuHz1lbfC=e8XhbyuzvjYkIsJUtB5w):
	if goAPKzw5S2fBuqbjXM0a61TW8 and not UdrDPKvYnJO8ciE9FQwuHz1lbfC: UdrDPKvYnJO8ciE9FQwuHz1lbfC = len(E5q7eGByuf1N9rV2LiozUaP)//goAPKzw5S2fBuqbjXM0a61TW8
	SGOZ2mT063zYLr,XW2Opt4RQsVihunCylz6j,pq96M0Po3CwahTmdu = [],-llxMLe4gobHhsj1WGvd7qmIU,e8XhbyuzvjYkIsJUtB5w
	for KiBecyPA5WSGXCQu38h1F4n in E5q7eGByuf1N9rV2LiozUaP:
		if pq96M0Po3CwahTmdu%UdrDPKvYnJO8ciE9FQwuHz1lbfC==e8XhbyuzvjYkIsJUtB5w:
			XW2Opt4RQsVihunCylz6j += llxMLe4gobHhsj1WGvd7qmIU
			SGOZ2mT063zYLr.append([])
		SGOZ2mT063zYLr[XW2Opt4RQsVihunCylz6j].append(KiBecyPA5WSGXCQu38h1F4n)
		pq96M0Po3CwahTmdu += llxMLe4gobHhsj1WGvd7qmIU
	return SGOZ2mT063zYLr
def rfe0K9Pgai5b6TkADRLxSBlOvZ1(hNfrb20intZpMPUI3w,dJC476xoE1ecpm0):
	yx95vDYhicREUC62QgW = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,hNfrb20intZpMPUI3w)
	if llxMLe4gobHhsj1WGvd7qmIU or pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡏࡐࡕࡘࡢࠫင") not in hNfrb20intZpMPUI3w or hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡍ࠴ࡗࡢࠫစ") not in hNfrb20intZpMPUI3w: HSb5r1Di9I8eKTtAyuNZdC4W = str(dJC476xoE1ecpm0)
	else:
		SGOZ2mT063zYLr = egfRV9FZMqoOKvU5IEJ7Sdw1l2a(dJC476xoE1ecpm0,NOrchaEV1iIZ87Uzlwgum(u"࠾፾"))
		HSb5r1Di9I8eKTtAyuNZdC4W = NdKhAS6MXVEORLTwob92pxlZ
		for ggClOy4J2sNd in SGOZ2mT063zYLr:
			HSb5r1Di9I8eKTtAyuNZdC4W += str(ggClOy4J2sNd)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ဆ")
		HSb5r1Di9I8eKTtAyuNZdC4W = HSb5r1Di9I8eKTtAyuNZdC4W.strip(HVmIrFwau90jQsgiWzExk(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧဇ"))
	PPu5tl4CMcbgDVWHRBQS = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.compress(HSb5r1Di9I8eKTtAyuNZdC4W)
	open(yx95vDYhicREUC62QgW,NOrchaEV1iIZ87Uzlwgum(u"ࠩࡺࡦࠬဈ")).write(PPu5tl4CMcbgDVWHRBQS)
	return
def QQ1K8FHxWl0z5jZ9p(DD6cpk8Q1ryURVAtg7N9OHu,hNfrb20intZpMPUI3w):
	if DD6cpk8Q1ryURVAtg7N9OHu==wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡨ࡮ࡩࡴࠨဉ"): dJC476xoE1ecpm0 = {}
	elif DD6cpk8Q1ryURVAtg7N9OHu==PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡱ࡯ࡳࡵࠩည"): dJC476xoE1ecpm0 = []
	elif DD6cpk8Q1ryURVAtg7N9OHu==HVmIrFwau90jQsgiWzExk(u"ࠬࡹࡴࡳࠩဋ"): dJC476xoE1ecpm0 = NdKhAS6MXVEORLTwob92pxlZ
	elif DD6cpk8Q1ryURVAtg7N9OHu==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡩ࡯ࡶࠪဌ"): dJC476xoE1ecpm0 = e8XhbyuzvjYkIsJUtB5w
	else: dJC476xoE1ecpm0 = None
	yx95vDYhicREUC62QgW = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,hNfrb20intZpMPUI3w)
	PPu5tl4CMcbgDVWHRBQS = open(yx95vDYhicREUC62QgW,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡳࡤࠪဍ")).read()
	HSb5r1Di9I8eKTtAyuNZdC4W = fvrhqAQLpuFMS9CctkRsIwPBxgEj5.decompress(PPu5tl4CMcbgDVWHRBQS)
	if lRP6GTaZJA1Xw3egLM4(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧဎ") not in HSb5r1Di9I8eKTtAyuNZdC4W: dJC476xoE1ecpm0 = eval(HSb5r1Di9I8eKTtAyuNZdC4W)
	else:
		SGOZ2mT063zYLr = HSb5r1Di9I8eKTtAyuNZdC4W.split(V0VZk9763fusTReHFo4(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨဏ"))
		del HSb5r1Di9I8eKTtAyuNZdC4W
		dJC476xoE1ecpm0 = []
		JJ3a4pkwEchfiC6WAOMUqnN = k8Q6Hp1Z3YWK()
		mpGDaUVONIECixkJYgoKlvB0tP = e8XhbyuzvjYkIsJUtB5w
		for ggClOy4J2sNd in SGOZ2mT063zYLr:
			JJ3a4pkwEchfiC6WAOMUqnN.qvpoFNSCxcHMh(str(mpGDaUVONIECixkJYgoKlvB0tP),eval,ggClOy4J2sNd)
			mpGDaUVONIECixkJYgoKlvB0tP += llxMLe4gobHhsj1WGvd7qmIU
		del SGOZ2mT063zYLr
		JJ3a4pkwEchfiC6WAOMUqnN.SNpUFlH8LwboVfe()
		JJ3a4pkwEchfiC6WAOMUqnN.CEnA3LdjzvITtZ05oxcFS2yiW()
		dbxCpkoGLXQ1JgZ59EKtiYn4FM3w86 = list(JJ3a4pkwEchfiC6WAOMUqnN.resultsDICT.keys())
		hlZNUScTgixrRHL = sorted(dbxCpkoGLXQ1JgZ59EKtiYn4FM3w86,reverse=f4vncKMRlXG9s,key=lambda key: int(key))
		for mpGDaUVONIECixkJYgoKlvB0tP in hlZNUScTgixrRHL:
			dJC476xoE1ecpm0 += JJ3a4pkwEchfiC6WAOMUqnN.resultsDICT[mpGDaUVONIECixkJYgoKlvB0tP]
	return dJC476xoE1ecpm0
def poyuWRvCicwsFGLK(b0VaRYkgC4iOvHpmdeyzcQISJEsx):
	B980Bg15KhDHxTZ = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,NeU6uRGpECkvMV5jf(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪတ"),b0VaRYkgC4iOvHpmdeyzcQISJEsx,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧထ"))
	try: DDxzbi9Gh7st1eQfRL = open(B980Bg15KhDHxTZ,HVmIrFwau90jQsgiWzExk(u"ࠬࡸࡢࠨဒ")).read()
	except:
		P31nOef8YF0oNRA42qLgWrwS6vmc = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ffJYyPuQ6WVvd795NnzRCx3slSB,vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ဓ"),b0VaRYkgC4iOvHpmdeyzcQISJEsx,PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪန"))
		try: DDxzbi9Gh7st1eQfRL = open(P31nOef8YF0oNRA42qLgWrwS6vmc,Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡴࡥࠫပ")).read()
		except: return NdKhAS6MXVEORLTwob92pxlZ,[]
	if J92gCnbGWidQV70lBteTwU6D8uyzL: DDxzbi9Gh7st1eQfRL = DDxzbi9Gh7st1eQfRL.decode(YRvPKe2zMTDs8UCkr)
	AAREZSMo7Hrs46 = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭ဖ"),DDxzbi9Gh7st1eQfRL,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	if not AAREZSMo7Hrs46: return NdKhAS6MXVEORLTwob92pxlZ,[]
	vG9DKXktgwAVsa7,gSuyoPmMsOLxVewQth = AAREZSMo7Hrs46[e8XhbyuzvjYkIsJUtB5w],EFhOxiHtUq2cmaNPedwSQkI5BXDzg(AAREZSMo7Hrs46[e8XhbyuzvjYkIsJUtB5w])
	return vG9DKXktgwAVsa7,gSuyoPmMsOLxVewQth
def ZwKR1OatDkTCdy7c():
	pEQLmag3NIjTiPWtG = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,Hlp3z0APt1GR4kMYK5xST(u"ࠪࡨ࡮ࡩࡴࠨဗ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧဘ"),V0VZk9763fusTReHFo4(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭မ"))
	if pEQLmag3NIjTiPWtG: return pEQLmag3NIjTiPWtG
	pmGySuDJA7ho,pEQLmag3NIjTiPWtG = {},{}
	wLZmC8xs1QMFh92 = [xKp3jkIvM09AZ4euXa87i5TVtfUD[R3lezw8h407ZvrAFxT(u"࠭ࡒࡆࡒࡒࡗࠬယ")][e8XhbyuzvjYkIsJUtB5w]]
	if kQI947MebLovYyVE08F5qPi6fj3>IlL8ZnX74Yvep(u"࠱࠸࠰࠼࠽፿"): wLZmC8xs1QMFh92.append(xKp3jkIvM09AZ4euXa87i5TVtfUD[PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡓࡇࡓࡓࡘ࠭ရ")][llxMLe4gobHhsj1WGvd7qmIU])
	if J92gCnbGWidQV70lBteTwU6D8uyzL: wLZmC8xs1QMFh92.append(xKp3jkIvM09AZ4euXa87i5TVtfUD[fOc18oTm5hsdD4pVZQj(u"ࠨࡔࡈࡔࡔ࡙ࠧလ")][cCRvAuJQfjBpTg0PbYiaNO87])
	for lljaRZD8tK6Q0GpMBXYz2E7dO in wLZmC8xs1QMFh92:
		MmDs0fWOCc3Bg = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,lNTJCZeBicWEz0Mg(u"ࠩࡊࡉ࡙࠭ဝ"),lljaRZD8tK6Q0GpMBXYz2E7dO,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧသ"))
		if MmDs0fWOCc3Bg.succeeded:
			tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
			OWCd50elQ8ETN = lljaRZD8tK6Q0GpMBXYz2E7dO.rsplit(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࠴࠭ဟ"),lRP6GTaZJA1Xw3egLM4(u"࠲ᎀ"))[e8XhbyuzvjYkIsJUtB5w]
			f78KNetUkgJHTuM0Eb = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ဠ"),tWcXU498FSdjKl2Iw7M,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
			for b0VaRYkgC4iOvHpmdeyzcQISJEsx,HEoMeayCO8fZX in f78KNetUkgJHTuM0Eb:
				VMD68anfAhRBxvX = OWCd50elQ8ETN+PzIpQnUXxRwNCivDhdakWTE(u"࠭࠯ࠨအ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+HHvYL68lbJVZWM7tQEzSex3(u"ࠧ࠰ࠩဢ")+b0VaRYkgC4iOvHpmdeyzcQISJEsx+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ࠯ࠪဣ")+HEoMeayCO8fZX+eGW7cI6aQhr0(u"ࠩ࠱ࡾ࡮ࡶࠧဤ")
				if b0VaRYkgC4iOvHpmdeyzcQISJEsx not in list(pmGySuDJA7ho.keys()):
					pmGySuDJA7ho[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = []
					pEQLmag3NIjTiPWtG[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = []
				W8PewZnYABkayvmLczd3NhT7MfVFO = EFhOxiHtUq2cmaNPedwSQkI5BXDzg(HEoMeayCO8fZX)
				pmGySuDJA7ho[b0VaRYkgC4iOvHpmdeyzcQISJEsx].append((HEoMeayCO8fZX,W8PewZnYABkayvmLczd3NhT7MfVFO,VMD68anfAhRBxvX))
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in list(pmGySuDJA7ho.keys()):
		pEQLmag3NIjTiPWtG[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = sorted(pmGySuDJA7ho[b0VaRYkgC4iOvHpmdeyzcQISJEsx],reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU])
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,eGW7cI6aQhr0(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ဥ"),rNyT0edugn(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬဦ"),pEQLmag3NIjTiPWtG,h1dnE0q2zFHjXlvyGuLZxw)
	return pEQLmag3NIjTiPWtG
def EFhOxiHtUq2cmaNPedwSQkI5BXDzg(HEoMeayCO8fZX):
	W8PewZnYABkayvmLczd3NhT7MfVFO = []
	ddW1bUPO3i = HEoMeayCO8fZX.split(PzIpQnUXxRwNCivDhdakWTE(u"ࠬ࠴ࠧဧ"))
	for QQbv0MHY9BcAgeDVLjxk in ddW1bUPO3i:
		X50IEOGBnZakmNu1TY = YYqECUofyi7wFrW.findall(IlL8ZnX74Yvep(u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪဨ"),QQbv0MHY9BcAgeDVLjxk,YYqECUofyi7wFrW.DOTALL)
		paRK3sq8J0CIMyr9nFQumX = []
		for cW8jXTY32JOsFvgh9rBxUa6L in X50IEOGBnZakmNu1TY:
			if cW8jXTY32JOsFvgh9rBxUa6L.isdigit(): cW8jXTY32JOsFvgh9rBxUa6L = int(cW8jXTY32JOsFvgh9rBxUa6L)
			paRK3sq8J0CIMyr9nFQumX.append(cW8jXTY32JOsFvgh9rBxUa6L)
		W8PewZnYABkayvmLczd3NhT7MfVFO.append(paRK3sq8J0CIMyr9nFQumX)
	return W8PewZnYABkayvmLczd3NhT7MfVFO
def fC2lhA1xTkHn(W8PewZnYABkayvmLczd3NhT7MfVFO):
	HEoMeayCO8fZX = NdKhAS6MXVEORLTwob92pxlZ
	for QQbv0MHY9BcAgeDVLjxk in W8PewZnYABkayvmLczd3NhT7MfVFO:
		for cW8jXTY32JOsFvgh9rBxUa6L in QQbv0MHY9BcAgeDVLjxk: HEoMeayCO8fZX += str(cW8jXTY32JOsFvgh9rBxUa6L)
		HEoMeayCO8fZX += pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠯ࠩဩ")
	HEoMeayCO8fZX = HEoMeayCO8fZX.strip(fOc18oTm5hsdD4pVZQj(u"ࠨ࠰ࠪဪ"))
	return HEoMeayCO8fZX
def E59vQkcMrwq0sBoeDUYClgG2St1(eCxtLjbwW1s):
	YYrKb4X8nZvo93BqaeJDt17 = {}
	pmGySuDJA7ho = ZwKR1OatDkTCdy7c()
	sG5jgAF79ce8E = lwgJtprMozU8hq0YR7m6WLOjnDI321(eCxtLjbwW1s)
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in eCxtLjbwW1s:
		if b0VaRYkgC4iOvHpmdeyzcQISJEsx not in list(pmGySuDJA7ho.keys()): continue
		pEQLmag3NIjTiPWtG = pmGySuDJA7ho[b0VaRYkgC4iOvHpmdeyzcQISJEsx]
		EQM4cO7NhSku,Tam7elMYFwqCdh9,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf = pEQLmag3NIjTiPWtG[e8XhbyuzvjYkIsJUtB5w]
		Awb7WLOVQ4pCvcqxekRSJyMzi6t1,elhtxB482CfwzXbyvmEHnZUkjLMG6Y = poyuWRvCicwsFGLK(b0VaRYkgC4iOvHpmdeyzcQISJEsx)
		zvwId89gRhCKce0BDt6TVYaFiM,B1nCuIcRs2j9 = sG5jgAF79ce8E[b0VaRYkgC4iOvHpmdeyzcQISJEsx]
		nS12gr6CpZIOy = Tam7elMYFwqCdh9>elhtxB482CfwzXbyvmEHnZUkjLMG6Y and zvwId89gRhCKce0BDt6TVYaFiM
		ll83YbWxpZUkyBCnqeAv = k6apiPAlLKM1ed8J42RjHh0o
		if not zvwId89gRhCKce0BDt6TVYaFiM: MnAITLgi5G = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪါ")
		elif not B1nCuIcRs2j9: MnAITLgi5G = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬာ")
		elif nS12gr6CpZIOy: MnAITLgi5G = QQHFtjcaR2VpnSyTIv(u"ࠫࡴࡲࡤࠨိ")
		else:
			MnAITLgi5G = xY4icgQUj6mPVs73CTKu(u"ࠬ࡭࡯ࡰࡦࠪီ")
			ll83YbWxpZUkyBCnqeAv = f4vncKMRlXG9s
		YYrKb4X8nZvo93BqaeJDt17[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = ll83YbWxpZUkyBCnqeAv,Awb7WLOVQ4pCvcqxekRSJyMzi6t1,elhtxB482CfwzXbyvmEHnZUkjLMG6Y,EQM4cO7NhSku,Tam7elMYFwqCdh9,MnAITLgi5G,Inw5eXFRa1VOqlbAmhk9PB7EZj8Hf
	return YYrKb4X8nZvo93BqaeJDt17
def BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,NVT28v6sPAKwCcGQ,cFN3zvIRQ4x0XPanbHelSgKEV6=NdKhAS6MXVEORLTwob92pxlZ,KUxan7uHTNvMwYP4b9GeAy1O=NdKhAS6MXVEORLTwob92pxlZ,DVBs6vKWwzgTxQMfY5EAncuiXOe8I=NdKhAS6MXVEORLTwob92pxlZ):
	if QBp28giCnayJzmZH6vYO: muL0lDzdjc7EA4pNJgYfbGq.update(NVT28v6sPAKwCcGQ,cFN3zvIRQ4x0XPanbHelSgKEV6,KUxan7uHTNvMwYP4b9GeAy1O,DVBs6vKWwzgTxQMfY5EAncuiXOe8I)
	else: muL0lDzdjc7EA4pNJgYfbGq.update(NVT28v6sPAKwCcGQ,cFN3zvIRQ4x0XPanbHelSgKEV6+B6IrC7zEHlw1oaeWf+KUxan7uHTNvMwYP4b9GeAy1O+B6IrC7zEHlw1oaeWf+DVBs6vKWwzgTxQMfY5EAncuiXOe8I)
	return
def l4SxGUb2p8jysLXAgQITDPY0(cqzC1gA3uKNVyiXQ0mpZL):
	def BwZ7K1o2U9WJOdzR4(t0jz1LeDF7rYUuP3iTRqHGZOK4,G98UeJVjr7isaZyoAfSw625mnKQNl0,rWQ6Ga2KjDS=YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨု")):
		return ((t0jz1LeDF7rYUuP3iTRqHGZOK4 == e8XhbyuzvjYkIsJUtB5w) and rWQ6Ga2KjDS[e8XhbyuzvjYkIsJUtB5w]) or (BwZ7K1o2U9WJOdzR4(t0jz1LeDF7rYUuP3iTRqHGZOK4 // G98UeJVjr7isaZyoAfSw625mnKQNl0, G98UeJVjr7isaZyoAfSw625mnKQNl0, rWQ6Ga2KjDS).lstrip(rWQ6Ga2KjDS[e8XhbyuzvjYkIsJUtB5w]) + rWQ6Ga2KjDS[t0jz1LeDF7rYUuP3iTRqHGZOK4 % G98UeJVjr7isaZyoAfSw625mnKQNl0])
	def DMVgsNfK9wqhEkQdi31m465bu(bbIBEZQkY72RrpztaTwqiAmOj, AvBYdKXjCz4FST, pcQlFNW6bOh, xYQDV8CgLOfJTenUoqHMGScXpjB, AwCISfqxyQ98RPJONKmhs=None, bylPH8wh97mORr0kjx=None, Wgz9ElyOiPqfBZYQerj=None):
		while (pcQlFNW6bOh):
			pcQlFNW6bOh-=V0VZk9763fusTReHFo4(u"࠳ᎁ")
			if (xYQDV8CgLOfJTenUoqHMGScXpjB[pcQlFNW6bOh]): bbIBEZQkY72RrpztaTwqiAmOj = YYqECUofyi7wFrW.sub(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠢ࡝࡞ࡥࠦူ") + BwZ7K1o2U9WJOdzR4(pcQlFNW6bOh, AvBYdKXjCz4FST) + HHvYL68lbJVZWM7tQEzSex3(u"ࠣ࡞࡟ࡦࠧေ"),  xYQDV8CgLOfJTenUoqHMGScXpjB[pcQlFNW6bOh], bbIBEZQkY72RrpztaTwqiAmOj)
		return bbIBEZQkY72RrpztaTwqiAmOj
	cqzC1gA3uKNVyiXQ0mpZL = cqzC1gA3uKNVyiXQ0mpZL.split(PzIpQnUXxRwNCivDhdakWTE(u"ࠩࢀࠬࠬဲ"))[llxMLe4gobHhsj1WGvd7qmIU]
	cqzC1gA3uKNVyiXQ0mpZL = cqzC1gA3uKNVyiXQ0mpZL.rsplit(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡷࡵࡲࡩࡵࠩဳ"))[e8XhbyuzvjYkIsJUtB5w]+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠦࡸࡶ࡬ࡪࡶࠫࠫࢁ࠭ࠩࠪࠤဴ")
	Bl9VrUSa5mjWPhJcI3 = eval(lRP6GTaZJA1Xw3egLM4(u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭ဵ")+cqzC1gA3uKNVyiXQ0mpZL,{IlL8ZnX74Yvep(u"࠭ࡢࡢࡵࡨࡒࠬံ"):BwZ7K1o2U9WJOdzR4,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡶࡰࡳࡥࡨࡱ့ࠧ"):DMVgsNfK9wqhEkQdi31m465bu})
	return Bl9VrUSa5mjWPhJcI3
def nadz1WI5ZUCSpYGJvNMAK(code):
	_E4UlViWIcvxngC1=OOkmZiVcfqlEurM1dHGb(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠬ࠱ࠥး")
	def udMsxy0DWjE(bylPH8wh97mORr0kjx,AwCISfqxyQ98RPJONKmhs,ch2IUjRuFZer64gdQW0Ex5l):
		YyBm06HKaiszvXgNM8Wqb9uJt = list(_E4UlViWIcvxngC1)
		ObXHLU7G6Sm1suhDTWP = YyBm06HKaiszvXgNM8Wqb9uJt[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠳ᎂ"):AwCISfqxyQ98RPJONKmhs]
		xX6zt5oS08TO29CUhYJa1K = YyBm06HKaiszvXgNM8Wqb9uJt[QQHFtjcaR2VpnSyTIv(u"࠴ᎃ"):ch2IUjRuFZer64gdQW0Ex5l]
		bylPH8wh97mORr0kjx = list(bylPH8wh97mORr0kjx)[::-vju3SZDWL4ENYelmBOzUqrogp2(u"࠶ᎄ")]
		RU2IVQ0PNd9 = rNyT0edugn(u"࠶ᎅ")
		for pcQlFNW6bOh,G98UeJVjr7isaZyoAfSw625mnKQNl0 in enumerate(bylPH8wh97mORr0kjx):
			if G98UeJVjr7isaZyoAfSw625mnKQNl0 in ObXHLU7G6Sm1suhDTWP: RU2IVQ0PNd9 = RU2IVQ0PNd9 + ObXHLU7G6Sm1suhDTWP.index(G98UeJVjr7isaZyoAfSw625mnKQNl0)*AwCISfqxyQ98RPJONKmhs**pcQlFNW6bOh
		xYQDV8CgLOfJTenUoqHMGScXpjB = NOrchaEV1iIZ87Uzlwgum(u"ࠤ္ࠥ")
		while RU2IVQ0PNd9 > HVmIrFwau90jQsgiWzExk(u"࠰ᎆ"):
			xYQDV8CgLOfJTenUoqHMGScXpjB = xX6zt5oS08TO29CUhYJa1K[RU2IVQ0PNd9%ch2IUjRuFZer64gdQW0Ex5l] + xYQDV8CgLOfJTenUoqHMGScXpjB
			RU2IVQ0PNd9 = (RU2IVQ0PNd9 - (RU2IVQ0PNd9%ch2IUjRuFZer64gdQW0Ex5l))//ch2IUjRuFZer64gdQW0Ex5l
		return int(xYQDV8CgLOfJTenUoqHMGScXpjB) or YJpWv4QzC7sx8INVPukeZiOD03K(u"࠱ᎇ")
	def sq06iEdlU1Q(ObXHLU7G6Sm1suhDTWP,u,PP7gfoVqHd2Eba36vLjn,g9IBNJDiuG5RQOVt7nhEzjSWyM,AwCISfqxyQ98RPJONKmhs,Wgz9ElyOiPqfBZYQerj):
		Wgz9ElyOiPqfBZYQerj = LtGoXlQ2IYxqTJRySE6udfW98(u"်ࠥࠦ");
		xX6zt5oS08TO29CUhYJa1K = NeU6uRGpECkvMV5jf(u"࠲ᎈ")
		while xX6zt5oS08TO29CUhYJa1K < len(ObXHLU7G6Sm1suhDTWP):
			RU2IVQ0PNd9 = lNTJCZeBicWEz0Mg(u"࠳ᎉ")
			rdIZwVnJLbg = kb2icmDGVUZfW1OFz7sv(u"ࠦࠧျ")
			while ObXHLU7G6Sm1suhDTWP[xX6zt5oS08TO29CUhYJa1K] is not PP7gfoVqHd2Eba36vLjn[AwCISfqxyQ98RPJONKmhs]:
				rdIZwVnJLbg = R3lezw8h407ZvrAFxT(u"ࠬ࠭ြ").join([rdIZwVnJLbg,ObXHLU7G6Sm1suhDTWP[xX6zt5oS08TO29CUhYJa1K]])
				xX6zt5oS08TO29CUhYJa1K = xX6zt5oS08TO29CUhYJa1K + WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵ᎊ")
			while RU2IVQ0PNd9 < len(PP7gfoVqHd2Eba36vLjn):
				rdIZwVnJLbg = rdIZwVnJLbg.replace(PP7gfoVqHd2Eba36vLjn[RU2IVQ0PNd9],str(RU2IVQ0PNd9))
				RU2IVQ0PNd9 = RU2IVQ0PNd9 + hCm2fnEXs6Zt(u"࠶ᎋ")
			Wgz9ElyOiPqfBZYQerj = PzIpQnUXxRwNCivDhdakWTE(u"࠭ࠧွ").join([Wgz9ElyOiPqfBZYQerj,lNTJCZeBicWEz0Mg(u"ࠧࠨှ").join(map(chr, [udMsxy0DWjE(rdIZwVnJLbg,AwCISfqxyQ98RPJONKmhs,lNTJCZeBicWEz0Mg(u"࠷࠰ᎌ")) - g9IBNJDiuG5RQOVt7nhEzjSWyM]))])
			xX6zt5oS08TO29CUhYJa1K = xX6zt5oS08TO29CUhYJa1K + YJpWv4QzC7sx8INVPukeZiOD03K(u"࠱ᎍ")
		return Wgz9ElyOiPqfBZYQerj
	code = code.replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࡞ࡱࠫဿ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࠪ၀")).replace(R3lezw8h407ZvrAFxT(u"ࠪࡠࡷ࠭၁"),QQHFtjcaR2VpnSyTIv(u"ࠫࠬ၂"))
	KUovinTpeyLDcJ5aw = YYqECUofyi7wFrW.findall(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡢࡽ࡝ࠪࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯࡜ࠪ࡞ࠬࠫ၃"),code,YYqECUofyi7wFrW.DOTALL)
	if KUovinTpeyLDcJ5aw:
		KUovinTpeyLDcJ5aw = list(KUovinTpeyLDcJ5aw[LtGoXlQ2IYxqTJRySE6udfW98(u"࠱ᎎ")])
		for aqbvc6UkxKOI7QDdsuzHp2EfG,code in enumerate(KUovinTpeyLDcJ5aw):
			if code.isdigit(): KUovinTpeyLDcJ5aw[aqbvc6UkxKOI7QDdsuzHp2EfG] = int(code)
			else: KUovinTpeyLDcJ5aw[aqbvc6UkxKOI7QDdsuzHp2EfG] = code.replace(lrtFSogC8Nh9(u"࠭࡜ࠣࠩ၄"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࠨ၅"))
		UUOuEsegXhG6D7jxPt31nZw = sq06iEdlU1Q(*KUovinTpeyLDcJ5aw)
		return UUOuEsegXhG6D7jxPt31nZw
	return xY4icgQUj6mPVs73CTKu(u"ࠨࠩ၆")
def ggmr4AaQTjP9q53zIbHk0LN(ZZT6GLaHQ1,vZEnVYOqwJCzKTUFH3GL=NdKhAS6MXVEORLTwob92pxlZ):
	if vZEnVYOqwJCzKTUFH3GL==QQHFtjcaR2VpnSyTIv(u"ࠩ࡯ࡳࡼ࡫ࡲࠨ၇"): ZZT6GLaHQ1 = YYqECUofyi7wFrW.sub(IlL8ZnX74Yvep(u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪ၈"),lambda ECrs4IkpNmHefBqj75Su: ECrs4IkpNmHefBqj75Su.group(e8XhbyuzvjYkIsJUtB5w).lower(),ZZT6GLaHQ1)
	elif vZEnVYOqwJCzKTUFH3GL==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡺࡶࡰࡦࡴࠪ၉"): ZZT6GLaHQ1 = YYqECUofyi7wFrW.sub(JGwsL21ZRlqSrWxEmF(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬ၊"),lambda ECrs4IkpNmHefBqj75Su: ECrs4IkpNmHefBqj75Su.group(e8XhbyuzvjYkIsJUtB5w).upper(),ZZT6GLaHQ1)
	return ZZT6GLaHQ1
def lwgJtprMozU8hq0YR7m6WLOjnDI321(eCxtLjbwW1s):
	KMnGs7o4h0jqHNbWgeSxkC9fF,iTPbIQcJuMxr4 = f4vncKMRlXG9s,f4vncKMRlXG9s
	Yo5K7kXcjOVq2SiTvludJ48f = moKCtu35ZJgji1UXIS0srpELB.connect(F9yN4TRdQclxaBGWt6rpSKwkJ)
	Yo5K7kXcjOVq2SiTvludJ48f.text_factory = str
	ODXQpWsKqya39FEctSmlRJ84rkM7vI = Yo5K7kXcjOVq2SiTvludJ48f.cursor()
	if len(eCxtLjbwW1s)==llxMLe4gobHhsj1WGvd7qmIU: qhTmbY9WIA3 = lrtFSogC8Nh9(u"࠭ࠨࠣࠩ။")+eCxtLjbwW1s[e8XhbyuzvjYkIsJUtB5w]+NOrchaEV1iIZ87Uzlwgum(u"ࠧࠣࠫࠪ၌")
	else: qhTmbY9WIA3 = str(tuple(eCxtLjbwW1s))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(fOc18oTm5hsdD4pVZQj(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨ၍")+qhTmbY9WIA3+R3lezw8h407ZvrAFxT(u"ࠩࠣ࠿ࠬ၎"))
	r2EUDqT1KdNxH = ODXQpWsKqya39FEctSmlRJ84rkM7vI.fetchall()
	Yo5K7kXcjOVq2SiTvludJ48f.commit()
	Yo5K7kXcjOVq2SiTvludJ48f.close()
	sG5jgAF79ce8E = {}
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx in eCxtLjbwW1s: sG5jgAF79ce8E[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = (f4vncKMRlXG9s,f4vncKMRlXG9s)
	for b0VaRYkgC4iOvHpmdeyzcQISJEsx,iTPbIQcJuMxr4 in r2EUDqT1KdNxH:
		KMnGs7o4h0jqHNbWgeSxkC9fF = k6apiPAlLKM1ed8J42RjHh0o
		iTPbIQcJuMxr4 = iTPbIQcJuMxr4==llxMLe4gobHhsj1WGvd7qmIU
		sG5jgAF79ce8E[b0VaRYkgC4iOvHpmdeyzcQISJEsx] = (KMnGs7o4h0jqHNbWgeSxkC9fF,iTPbIQcJuMxr4)
	return sG5jgAF79ce8E
def kNavZsXiUlWP5o4(u45yDBATUY9C30mGEX1HS):
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = NdKhAS6MXVEORLTwob92pxlZ
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(u45yDBATUY9C30mGEX1HS):
		HHVF24kQUwi3XSegWCu7x9 = open(u45yDBATUY9C30mGEX1HS,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡶࡧ࠭၏")).read()
		if J92gCnbGWidQV70lBteTwU6D8uyzL: HHVF24kQUwi3XSegWCu7x9 = HHVF24kQUwi3XSegWCu7x9.decode(YRvPKe2zMTDs8UCkr)
		Zo9FdgX2YxTajth = BdnA8WwtJeKUVvE(QQHFtjcaR2VpnSyTIv(u"ࠫࡩ࡯ࡣࡵࠩၐ"),HHVF24kQUwi3XSegWCu7x9)
		if Zo9FdgX2YxTajth:
			UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = {}
			for V9fBFLnGeItlHmYgE1Xi0xvWPz in Zo9FdgX2YxTajth.keys():
				UEsxyfd8rZMLOHgzc6emSFKD0ktYiT[V9fBFLnGeItlHmYgE1Xi0xvWPz] = []
				for nwO2JLqMCDUxlzvrQcAmYybsIP3p in Zo9FdgX2YxTajth[V9fBFLnGeItlHmYgE1Xi0xvWPz]:
					GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
					GY9jgon6yhP0IvtCBEJu3 = nwO2JLqMCDUxlzvrQcAmYybsIP3p[e8XhbyuzvjYkIsJUtB5w]
					vczZTnVU6PuaFG5EeALl4MKOj0 = nwO2JLqMCDUxlzvrQcAmYybsIP3p[llxMLe4gobHhsj1WGvd7qmIU]
					vczZTnVU6PuaFG5EeALl4MKOj0 = x5lwbtumkO6X2TgFoVh(vczZTnVU6PuaFG5EeALl4MKOj0)
					ZZT6GLaHQ1 = nwO2JLqMCDUxlzvrQcAmYybsIP3p[cCRvAuJQfjBpTg0PbYiaNO87]
					DDq6xNzlMYK = nwO2JLqMCDUxlzvrQcAmYybsIP3p[uL69vJOU7xN0hGnZf2islDqk]
					k1ChwgueU5nbDX6K0BOEGx = nwO2JLqMCDUxlzvrQcAmYybsIP3p[TQNS6YMKAqnilsVObLpDRX]
					jNgDBqeKyZ4zSkGv8ROMA70aIYcC = nwO2JLqMCDUxlzvrQcAmYybsIP3p[NeU6uRGpECkvMV5jf(u"࠷ᎏ")]
					if len(nwO2JLqMCDUxlzvrQcAmYybsIP3p)>kb2icmDGVUZfW1OFz7sv(u"࠹᎐"): HSb5r1Di9I8eKTtAyuNZdC4W = nwO2JLqMCDUxlzvrQcAmYybsIP3p[kb2icmDGVUZfW1OFz7sv(u"࠹᎐")]
					if len(nwO2JLqMCDUxlzvrQcAmYybsIP3p)>JGwsL21ZRlqSrWxEmF(u"࠻᎑"): IGar1Z3F8lNX = nwO2JLqMCDUxlzvrQcAmYybsIP3p[JGwsL21ZRlqSrWxEmF(u"࠻᎑")]
					if len(nwO2JLqMCDUxlzvrQcAmYybsIP3p)>OOkmZiVcfqlEurM1dHGb(u"࠽᎒"): BIlmnRhJjQAFyoeNYOzT67pHDrG = nwO2JLqMCDUxlzvrQcAmYybsIP3p[OOkmZiVcfqlEurM1dHGb(u"࠽᎒")]
					if u45yDBATUY9C30mGEX1HS==cXO4eSZFqrbYPotf: X7pg6YTBqCNcd = GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,NdKhAS6MXVEORLTwob92pxlZ,BIlmnRhJjQAFyoeNYOzT67pHDrG
					else: X7pg6YTBqCNcd = GY9jgon6yhP0IvtCBEJu3,vczZTnVU6PuaFG5EeALl4MKOj0,ZZT6GLaHQ1,DDq6xNzlMYK,k1ChwgueU5nbDX6K0BOEGx,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,HSb5r1Di9I8eKTtAyuNZdC4W,IGar1Z3F8lNX,BIlmnRhJjQAFyoeNYOzT67pHDrG
					UEsxyfd8rZMLOHgzc6emSFKD0ktYiT[V9fBFLnGeItlHmYgE1Xi0xvWPz].append(X7pg6YTBqCNcd)
		bQrogdaYD9T7jeNuXGML = str(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: bQrogdaYD9T7jeNuXGML = bQrogdaYD9T7jeNuXGML.encode(YRvPKe2zMTDs8UCkr)
		open(u45yDBATUY9C30mGEX1HS,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡽࡢࠨၑ")).write(bQrogdaYD9T7jeNuXGML)
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LLs7ZodwDpHNS2I(mAH4aPy8q1w):
	qe2jNxudnaWwt5 = mAH4aPy8q1w.split(lNTJCZeBicWEz0Mg(u"࠭࠭ࠨၒ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
	QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	if   qe2jNxudnaWwt5==Hlp3z0APt1GR4kMYK5xST(u"ࠧࡂࡊ࡚ࡅࡐ࠭ၓ")		:	from cYq2KbBZWE			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lNTJCZeBicWEz0Mg(u"ࠨࡃࡎࡓࡆࡓࠧၔ")		:	from Nbylaq3nUL			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==Hlp3z0APt1GR4kMYK5xST(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫၕ")	:	from er3kMPhVNc		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==NOrchaEV1iIZ87Uzlwgum(u"ࠪࡅࡐ࡝ࡁࡎࠩၖ")		:	from dKusGQWL0z			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==QQHFtjcaR2VpnSyTIv(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧၗ")	:	from qqleA1jS6x		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡇࡌࡂࡔࡄࡆࠬၘ")	:	from fSyDaLbhPV			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lRP6GTaZJA1Xw3egLM4(u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨၙ")	:	from FBVhCy8bmu		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪၚ")	: 	from WZnIKqCXk1		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==eGW7cI6aQhr0(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪၛ")	:	from UB5dzQrPLo		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==Hlp3z0APt1GR4kMYK5xST(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪၜ")	:	from cvyMs6YGTC		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==kb2icmDGVUZfW1OFz7sv(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬၝ")	:	from QcOfGXA9Cm		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==V0VZk9763fusTReHFo4(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩၞ"):	from fe0RVyc76O	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧၟ")	:	from TsmavPO7dc		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==IlL8ZnX74Yvep(u"࠭ࡁ࡚ࡎࡒࡐࠬၠ")		:	from Im6ndcfLAp			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡃࡑࡎࡖࡆ࠭ၡ")		:	from gg34ZwSuqD			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨၢ")	:	from JOWH78lStd			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪၣ")	:	from QsVPk2WXEd		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==xY4icgQUj6mPVs73CTKu(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪၤ")	:	from zMPF5YBk81			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==QQHFtjcaR2VpnSyTIv(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫၥ")	:	from IOY8EXZopF			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==NOrchaEV1iIZ87Uzlwgum(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧၦ")	:	from ElC38ro1qU		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==V0VZk9763fusTReHFo4(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨၧ")	:	from H6HiytTblh		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lRP6GTaZJA1Xw3egLM4(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ၨ"):	from K9gHSUpl7R	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==eGW7cI6aQhr0(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪၩ")	:	from zd351qvLMF		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==eGW7cI6aQhr0(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫၪ")	:	from ww9nK7YSqW		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬၫ")	:	from VrFUbL8Mao		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧၬ")	:	from KkQ9eFYNl2		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ၭ")	:	from igcP5NRLxS		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==eGW7cI6aQhr0(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨၮ")	:	from ZEQvGmABjy		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬၯ"):	from rkeSbyBcK6	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lNTJCZeBicWEz0Mg(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫၰ")	:	from OL4sqv3XwG		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==gniNItGL6bKwpEW(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪၱ")	:	from c5v7rxYBim		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫၲ")	:	from aajQ2ou438		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==kb2icmDGVUZfW1OFz7sv(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ၳ")	:	from zhlqBY1Ev2		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lRP6GTaZJA1Xw3egLM4(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧၴ")	:	from y36qAHGaVj		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lrtFSogC8Nh9(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨၵ")	:	from duEz093LZo		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩၶ")	:	from WMNy1hKjbO		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==rNyT0edugn(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩၷ")	:	from OO6PpsFrJ5		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩၸ")	:	from NNqGlbdzVE			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==Hlp3z0APt1GR4kMYK5xST(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬၹ")	:	from WPfZbgQour		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧၺ")	:	from JhUEHLwq3p		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ၻ")	:	from Fm1zcZNQ3B		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩၼ")	:	from jTdEqINm1i		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨၽ")	:	from F1gOKUowiN		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lrtFSogC8Nh9(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪၾ")	:	from xVDPCTs6jX		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hCm2fnEXs6Zt(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫၿ")	:	from VV4pcXHnJF		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡊࡔ࡙ࡔࡂࠩႀ")		:	from FOonXswmBg			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬႁ")	:	from nny96FkWMw		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧႂ")	:	from ppeikWrXIE		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫႃ"):	from ccv5OBnlYI	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==NOrchaEV1iIZ87Uzlwgum(u"ࠧࡈࡑࡒࡋࡑࡋࡓࡆࡃࡕࡇࡍ࠭ႄ"):	from PdOcXS3g6n	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lrtFSogC8Nh9(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪႅ")	:	from tBpA6DSOTz		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡌࡊࡎࡒࡍࠨႆ")		:	from PH6RWpv5DK			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡍࡕ࡚ࡖࠨႇ")		:	from dduW7Cg5Fx			import ILukXJh2lbAiTvHMm as QQYZ7KIqVTxw,vQHGIF21bUxu9ByzEsXrewmAchVZM as vbpSAKljzB4xR8UPkyY2whrVG,vzAmZXEiDGPInYHrlF3bLK57yte4Uj as nwB7i5HsIz
	elif qe2jNxudnaWwt5==eGW7cI6aQhr0(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧႈ")	:	from PzTe9tjNfS		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧႉ")	:	from hRQNHY5VxL		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨႊ")	:	from RQzfIOVrm3		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==OOkmZiVcfqlEurM1dHGb(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨႋ")	:	from f1zHIw6gOU		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lrtFSogC8Nh9(u"ࠨࡎࡄࡖࡔࡠࡁࠨႌ")	:	from ss7D4f8nvo			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==JGwsL21ZRlqSrWxEmF(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖႍࠪ")	:	from K16TpUji7C		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==V0VZk9763fusTReHFo4(u"ࠪࡑ࠸࡛ࠧႎ")		:	from ws4trNj60m			import ILukXJh2lbAiTvHMm as QQYZ7KIqVTxw,vQHGIF21bUxu9ByzEsXrewmAchVZM as vbpSAKljzB4xR8UPkyY2whrVG,vzAmZXEiDGPInYHrlF3bLK57yte4Uj as nwB7i5HsIz
	elif qe2jNxudnaWwt5==OOkmZiVcfqlEurM1dHGb(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧႏ")	:	from ZGB3i4C59P		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ႐")	:	from ggaX57uqsJ			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==NeU6uRGpECkvMV5jf(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭႑")	:	from Mv1S0NnoLc			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡑࡃࡑࡉ࡙࠭႒")		:	from d9huMaXpyx			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lRP6GTaZJA1Xw3egLM4(u"ࠨࡓࡉࡍࡑࡓࠧ႓")		:	from DowJ4kLM2h			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭႔"):	from QdC0V9SAYs		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭႕")	:	from d3ugQCBmVX		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==HVmIrFwau90jQsgiWzExk(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭႖")	:	from WrGxOkJPCN		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ႗"):	from t81t4mpBRk		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==NOrchaEV1iIZ87Uzlwgum(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ႘")	:	from EJie7xtBG0		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==kb2icmDGVUZfW1OFz7sv(u"ࠧࡔࡊࡒࡊࡍࡇࠧ႙")	:	from fx0PH6CZqm			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪႚ")	:	from x95LPSfncN		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==gniNItGL6bKwpEW(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫႛ")	:	from KoUb7iamN5		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬႜ")	:	from T3TQo2Fr5e		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==HVmIrFwau90jQsgiWzExk(u"࡙ࠫࡏࡋࡂࡃࡗࠫႝ")	:	from EvGdcZ5yHS			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lNTJCZeBicWEz0Mg(u"࡚ࠬࡖࡇࡗࡑࠫ႞")		:	from zJrlt5mZ9w			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lrtFSogC8Nh9(u"࠭ࡖࡂࡔࡅࡓࡓ࠭႟")	:	from nk1erWgiOG			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hCm2fnEXs6Zt(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫႠ"):	from VhwdoC7WQ4		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==gniNItGL6bKwpEW(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩႡ")	:	from xemC84so16		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪႢ")	:	from heCY5Ecfio		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lNTJCZeBicWEz0Mg(u"ࠪ࡝ࡆࡗࡏࡕࠩႣ")		:	from vAy1deOHbh			import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==lNTJCZeBicWEz0Mg(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬႤ")	:	from jdhuexnA5b		import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	elif qe2jNxudnaWwt5==rNyT0edugn(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫႥ"):	from mm48iVRB7K	import LkmCVzJQol0YsM83i7tnr as QQYZ7KIqVTxw,tTIQWSbOEqHJ4 as vbpSAKljzB4xR8UPkyY2whrVG,LJfTAEQPv9h4BXdwUp as nwB7i5HsIz
	return QQYZ7KIqVTxw,vbpSAKljzB4xR8UPkyY2whrVG,nwB7i5HsIz
def VCoIxDK8uGJv(a7Qs0nfh1coIBg8EyeqTSkz2xr9F,JoWX5If80G,showDialogs):
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,NOrchaEV1iIZ87Uzlwgum(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫႦ")+a7Qs0nfh1coIBg8EyeqTSkz2xr9F+HVmIrFwau90jQsgiWzExk(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪႧ")+str(JoWX5If80G)+QQHFtjcaR2VpnSyTIv(u"ࠨࠢࡠࠫႨ"))
	muL0lDzdjc7EA4pNJgYfbGq = UpNqSvlOPeuKntGWCT1rR3aI4b()
	muL0lDzdjc7EA4pNJgYfbGq.create(fOc18oTm5hsdD4pVZQj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႩ"),JGwsL21ZRlqSrWxEmF(u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬႪ"))
	Dov3MKEat5RHycwPWZdhqGsb = IlL8ZnX74Yvep(u"࠷࠰࠳࠶᎓")*IlL8ZnX74Yvep(u"࠷࠰࠳࠶᎓")
	H4upontDk3qJyMXBA = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠱᎔")*Dov3MKEat5RHycwPWZdhqGsb
	import requests as HnCNqGOWBc0tZViv
	MmDs0fWOCc3Bg = HnCNqGOWBc0tZViv.get(a7Qs0nfh1coIBg8EyeqTSkz2xr9F,stream=k6apiPAlLKM1ed8J42RjHh0o,headers=JoWX5If80G)
	eei9N3BWrGUu = MmDs0fWOCc3Bg.headers
	MmDs0fWOCc3Bg.close()
	wwpeoYJd75v1GFzi8T9fagCBQ2KHVX = bytes()
	if not eei9N3BWrGUu:
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႫ"),lrtFSogC8Nh9(u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨႬ"))
		muL0lDzdjc7EA4pNJgYfbGq.close()
	else:
		if rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧႭ") not in list(eei9N3BWrGUu.keys()): lTMoZiynD4m6kg1q8W3r = e8XhbyuzvjYkIsJUtB5w
		else: lTMoZiynD4m6kg1q8W3r = int(eei9N3BWrGUu[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨႮ")])
		C3i1KT47NwSVzcZqvlPbfW = str(int(HHvYL68lbJVZWM7tQEzSex3(u"࠳࠳࠴࠵᎖")*lTMoZiynD4m6kg1q8W3r/Dov3MKEat5RHycwPWZdhqGsb)/NOrchaEV1iIZ87Uzlwgum(u"࠲࠲࠳࠴࠳࠶᎕"))
		BhWA4gXCoLuOzQJVY0N = int(lTMoZiynD4m6kg1q8W3r/H4upontDk3qJyMXBA)+llxMLe4gobHhsj1WGvd7qmIU
		if WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨႯ") in list(eei9N3BWrGUu.keys()) and lTMoZiynD4m6kg1q8W3r>Dov3MKEat5RHycwPWZdhqGsb:
			vKd8PzAoHUTk4wsB7cMpE2Xh1G = k6apiPAlLKM1ed8J42RjHh0o
			cFAJrHO74sqo8YfmM9LnP6z0p5a = []
			q3t40zlDovynZe2 = xY4icgQUj6mPVs73CTKu(u"࠴࠴᎗")
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(e8XhbyuzvjYkIsJUtB5w*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠰ࠫႰ")+str(llxMLe4gobHhsj1WGvd7qmIU*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(llxMLe4gobHhsj1WGvd7qmIU*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࠱ࠬႱ")+str(cCRvAuJQfjBpTg0PbYiaNO87*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(cCRvAuJQfjBpTg0PbYiaNO87*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫ࠲࠭Ⴒ")+str(uL69vJOU7xN0hGnZf2islDqk*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(uL69vJOU7xN0hGnZf2islDqk*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+Hlp3z0APt1GR4kMYK5xST(u"ࠬ࠳ࠧႳ")+str(TQNS6YMKAqnilsVObLpDRX*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(TQNS6YMKAqnilsVObLpDRX*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭࠭ࠨႴ")+str(Tzx81Wb0RZC4ID5AyiU2(u"࠹᎘")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(lRP6GTaZJA1Xw3egLM4(u"࠺᎙")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧ࠮ࠩႵ")+str(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠼᎚")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(pnHgvFOCBZzc08yULQJGIqw9bf(u"࠷᎜")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+JGwsL21ZRlqSrWxEmF(u"ࠨ࠯ࠪႶ")+str(vju3SZDWL4ENYelmBOzUqrogp2(u"࠷᎛")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(kb2icmDGVUZfW1OFz7sv(u"࠺᎞")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+JGwsL21ZRlqSrWxEmF(u"ࠩ࠰ࠫႷ")+str(OOkmZiVcfqlEurM1dHGb(u"࠺᎝")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠽Ꭰ")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+fOc18oTm5hsdD4pVZQj(u"ࠪ࠱ࠬႸ")+str(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠽᎟")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2-llxMLe4gobHhsj1WGvd7qmIU))
			cFAJrHO74sqo8YfmM9LnP6z0p5a.append(str(eGW7cI6aQhr0(u"࠿Ꭱ")*lTMoZiynD4m6kg1q8W3r//q3t40zlDovynZe2)+Hlp3z0APt1GR4kMYK5xST(u"ࠫ࠲࠭Ⴙ"))
			PKdLFYTM69oEp = float(BhWA4gXCoLuOzQJVY0N)/q3t40zlDovynZe2
			D01DCdMatxTcJBF = PKdLFYTM69oEp/int(llxMLe4gobHhsj1WGvd7qmIU+PKdLFYTM69oEp)
		else:
			vKd8PzAoHUTk4wsB7cMpE2Xh1G = f4vncKMRlXG9s
			q3t40zlDovynZe2 = llxMLe4gobHhsj1WGvd7qmIU
			D01DCdMatxTcJBF = llxMLe4gobHhsj1WGvd7qmIU
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭Ⴚ")+str(vKd8PzAoHUTk4wsB7cMpE2Xh1G)+R3lezw8h407ZvrAFxT(u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨႻ")+str(lTMoZiynD4m6kg1q8W3r)+HVmIrFwau90jQsgiWzExk(u"ࠧࠡ࡟ࠪႼ"))
		XW2Opt4RQsVihunCylz6j,YYRx4XETLolbkfSvwVH7tUhdp3PJI = e8XhbyuzvjYkIsJUtB5w,e8XhbyuzvjYkIsJUtB5w
		for pq96M0Po3CwahTmdu in range(q3t40zlDovynZe2):
			omrd89nv0PGKFpL3TxfAXt = JoWX5If80G.copy()
			if vKd8PzAoHUTk4wsB7cMpE2Xh1G: omrd89nv0PGKFpL3TxfAXt[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡔࡤࡲ࡬࡫ࠧႽ")] = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩႾ")+cFAJrHO74sqo8YfmM9LnP6z0p5a[pq96M0Po3CwahTmdu]
			MmDs0fWOCc3Bg = HnCNqGOWBc0tZViv.get(a7Qs0nfh1coIBg8EyeqTSkz2xr9F,stream=k6apiPAlLKM1ed8J42RjHh0o,headers=omrd89nv0PGKFpL3TxfAXt,timeout=rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠳࠱࠲Ꭲ"))
			for TF4iWfOYEx18970HPBm2QDyuZ in MmDs0fWOCc3Bg.iter_content(chunk_size=H4upontDk3qJyMXBA):
				if muL0lDzdjc7EA4pNJgYfbGq.iscanceled():
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,lNTJCZeBicWEz0Mg(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪႿ"))
					break
				XW2Opt4RQsVihunCylz6j += D01DCdMatxTcJBF
				wwpeoYJd75v1GFzi8T9fagCBQ2KHVX += TF4iWfOYEx18970HPBm2QDyuZ
				if not YYRx4XETLolbkfSvwVH7tUhdp3PJI: YYRx4XETLolbkfSvwVH7tUhdp3PJI = len(TF4iWfOYEx18970HPBm2QDyuZ)
				if lTMoZiynD4m6kg1q8W3r: BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,JGwsL21ZRlqSrWxEmF(u"࠲࠲࠳Ꭳ")*XW2Opt4RQsVihunCylz6j//BhWA4gXCoLuOzQJVY0N,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬჀ"),str(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠳࠳࠴࠳࠶Ꭴ")*YYRx4XETLolbkfSvwVH7tUhdp3PJI*XW2Opt4RQsVihunCylz6j//H4upontDk3qJyMXBA//ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠳࠳࠴࠳࠶Ꭴ"))+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࠦ࠯ࠡࠩჁ")+C3i1KT47NwSVzcZqvlPbfW+wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠠࡎࡄࠪჂ"))
				else: BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,YYRx4XETLolbkfSvwVH7tUhdp3PJI*XW2Opt4RQsVihunCylz6j//H4upontDk3qJyMXBA,xY4icgQUj6mPVs73CTKu(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠬჃ"),str(lNTJCZeBicWEz0Mg(u"࠴࠴࠵࠴࠰Ꭵ")*YYRx4XETLolbkfSvwVH7tUhdp3PJI*XW2Opt4RQsVihunCylz6j//H4upontDk3qJyMXBA//lNTJCZeBicWEz0Mg(u"࠴࠴࠵࠴࠰Ꭵ"))+NOrchaEV1iIZ87Uzlwgum(u"ࠨࠢࡐࡆࠬჄ"))
			MmDs0fWOCc3Bg.close()
		muL0lDzdjc7EA4pNJgYfbGq.close()
		if len(wwpeoYJd75v1GFzi8T9fagCBQ2KHVX)<lTMoZiynD4m6kg1q8W3r and lTMoZiynD4m6kg1q8W3r>e8XhbyuzvjYkIsJUtB5w:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡰࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡧࡴ࠻ࠢ࡞ࠤࠬჅ")+str(len(wwpeoYJd75v1GFzi8T9fagCBQ2KHVX)//Dov3MKEat5RHycwPWZdhqGsb)+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨ჆")+C3i1KT47NwSVzcZqvlPbfW+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࠥࡓࡂࠡ࡟ࠪჇ"))
			IUF5ecZfOplsHom = HQK8NwPVcoJ(NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠬหไ฻ษฤࠤํิั้ฮࠪ჈"),lNTJCZeBicWEz0Mg(u"࠭วิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺ࠭჉"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧฦ฻สำฮࠦฬๅสࠣห้๋ไโࠩ჊"),IlL8ZnX74Yvep(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ჋"),R3lezw8h407ZvrAFxT(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭჌")+str(len(wwpeoYJd75v1GFzi8T9fagCBQ2KHVX)//Dov3MKEat5RHycwPWZdhqGsb)+lrtFSogC8Nh9(u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩჍ")+C3i1KT47NwSVzcZqvlPbfW+wP4kpvXoDHq3hs7TFLyr2COn8(u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭჎"))
			if IUF5ecZfOplsHom==cCRvAuJQfjBpTg0PbYiaNO87: wwpeoYJd75v1GFzi8T9fagCBQ2KHVX = VCoIxDK8uGJv(a7Qs0nfh1coIBg8EyeqTSkz2xr9F,JoWX5If80G,showDialogs)
			elif IUF5ecZfOplsHom==llxMLe4gobHhsj1WGvd7qmIU: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,eGW7cI6aQhr0(u"ࠬ࠴࡜ࡵࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫ჏"))
			else: return NdKhAS6MXVEORLTwob92pxlZ
			if not wwpeoYJd75v1GFzi8T9fagCBQ2KHVX: return NdKhAS6MXVEORLTwob92pxlZ
		else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,JGwsL21ZRlqSrWxEmF(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪა")+C3i1KT47NwSVzcZqvlPbfW+NeU6uRGpECkvMV5jf(u"ࠧࠡࡏࡅࠤࡢ࠭ბ"))
	return wwpeoYJd75v1GFzi8T9fagCBQ2KHVX
def Spv1HQj0hiL(yNIDEX5hU4G769):
	return MmDs0fWOCc3Bg
def Fa1ehN3qiLZ8tfwj(ip=NdKhAS6MXVEORLTwob92pxlZ):
	global q24qAUj8wQEsorTlkI
	if q24qAUj8wQEsorTlkI: return q24qAUj8wQEsorTlkI
	RRrnKzx3aSojwGB1I4,wziCR1x4XQEAOB9U6KfGJYmTHl8,Sv9gthd0MNU2E,pF9wEI43XhgkSDHRaZ6,ttDWyhpsw4XfkH,wmWUxgHeuoOa9FCL = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	ZZT6GLaHQ1 = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫგ")+ip+HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧდ")
	JoWX5If80G = {vju3SZDWL4ENYelmBOzUqrogp2(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧე"):NdKhAS6MXVEORLTwob92pxlZ}
	MmDs0fWOCc3Bg = cJaAB4uQyp(NXpO8DrVmeE,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡌࡋࡔࠨვ"),ZZT6GLaHQ1,NdKhAS6MXVEORLTwob92pxlZ,JoWX5If80G,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨზ"))
	if not MmDs0fWOCc3Bg.succeeded:
		ZZT6GLaHQ1 = eGW7cI6aQhr0(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱ࠯ࡤࡴ࡮࠴ࡣࡰ࡯࠲࡮ࡸࡵ࡮࠰ࠩთ")+ip+OOkmZiVcfqlEurM1dHGb(u"ࠧࡀࡨ࡬ࡩࡱࡪࡳ࠾ࡳࡸࡩࡷࡿࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠲ࡣࡪࡶࡼ࠰ࡴ࡬ࡦࡴࡧࡷࠫი")
		MmDs0fWOCc3Bg = cJaAB4uQyp(NXpO8DrVmeE,lRP6GTaZJA1Xw3egLM4(u"ࠨࡉࡈࡘࠬკ"),ZZT6GLaHQ1,NdKhAS6MXVEORLTwob92pxlZ,JoWX5If80G,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠴ࡱࡨࠬლ"))
	if MmDs0fWOCc3Bg.succeeded:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = MmDs0fWOCc3Bg.content
		Cir51bwOlk6PcAe7VzWNXIKv = O3OogF1l5reuQ.loads(LMKFcEkU1Q7R80yt4OsgvwxbfP)
		rcRGOLbM7eIXHSVdP0FlDQ = list(Cir51bwOlk6PcAe7VzWNXIKv.keys())
		if NOrchaEV1iIZ87Uzlwgum(u"ࠪ࡭ࡵ࠭მ") in rcRGOLbM7eIXHSVdP0FlDQ: ip = Cir51bwOlk6PcAe7VzWNXIKv[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡮ࡶࠧნ")]
		if V0VZk9763fusTReHFo4(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨო") in rcRGOLbM7eIXHSVdP0FlDQ: RRrnKzx3aSojwGB1I4 = Cir51bwOlk6PcAe7VzWNXIKv[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩპ")]
		if JGwsL21ZRlqSrWxEmF(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨჟ") in rcRGOLbM7eIXHSVdP0FlDQ: wziCR1x4XQEAOB9U6KfGJYmTHl8 = Cir51bwOlk6PcAe7VzWNXIKv[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩრ")]
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨს") in rcRGOLbM7eIXHSVdP0FlDQ: Sv9gthd0MNU2E = Cir51bwOlk6PcAe7VzWNXIKv[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩტ")]
		if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫუ") in rcRGOLbM7eIXHSVdP0FlDQ: pF9wEI43XhgkSDHRaZ6 = Cir51bwOlk6PcAe7VzWNXIKv[QQHFtjcaR2VpnSyTIv(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬფ")]
		if LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡣࡪࡶࡼࠫქ") in rcRGOLbM7eIXHSVdP0FlDQ: ttDWyhpsw4XfkH = Cir51bwOlk6PcAe7VzWNXIKv[V0VZk9763fusTReHFo4(u"ࠧࡤ࡫ࡷࡽࠬღ")]
		if eGW7cI6aQhr0(u"ࠨࡳࡸࡩࡷࡿࠧყ") in rcRGOLbM7eIXHSVdP0FlDQ: ip = Cir51bwOlk6PcAe7VzWNXIKv[gniNItGL6bKwpEW(u"ࠩࡴࡹࡪࡸࡹࠨშ")]
		if eGW7cI6aQhr0(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨჩ") in rcRGOLbM7eIXHSVdP0FlDQ: Sv9gthd0MNU2E = Cir51bwOlk6PcAe7VzWNXIKv[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩც")]
		if hCm2fnEXs6Zt(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩძ") in rcRGOLbM7eIXHSVdP0FlDQ: pF9wEI43XhgkSDHRaZ6 = Cir51bwOlk6PcAe7VzWNXIKv[pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪწ")]
		if pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩჭ") in rcRGOLbM7eIXHSVdP0FlDQ:
			wmWUxgHeuoOa9FCL = Cir51bwOlk6PcAe7VzWNXIKv[PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪხ")][pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡸࡸࡨ࠭ჯ")]
			if wmWUxgHeuoOa9FCL[e8XhbyuzvjYkIsJUtB5w] not in [LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪ࠱ࠬჰ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࠰࠭ჱ")]: wmWUxgHeuoOa9FCL = Tzx81Wb0RZC4ID5AyiU2(u"ࠬ࠱ࠧჲ")+wmWUxgHeuoOa9FCL
		if xY4icgQUj6mPVs73CTKu(u"࠭࡯ࡧࡨࡶࡩࡹ࠭ჳ") in rcRGOLbM7eIXHSVdP0FlDQ:
			wmWUxgHeuoOa9FCL = Cir51bwOlk6PcAe7VzWNXIKv[lNTJCZeBicWEz0Mg(u"ࠧࡰࡨࡩࡷࡪࡺࠧჴ")]
			if wmWUxgHeuoOa9FCL>=eGW7cI6aQhr0(u"࠴Ꭶ"): wmWUxgHeuoOa9FCL = lRP6GTaZJA1Xw3egLM4(u"ࠨ࠭ࠪჵ")+XJ62UBRmIqFvfiNTQj.strftime(QQHFtjcaR2VpnSyTIv(u"ࠤࠨࡌ࠿ࠫࡍࠣჶ"),XJ62UBRmIqFvfiNTQj.gmtime(wmWUxgHeuoOa9FCL))
			else: wmWUxgHeuoOa9FCL = lNTJCZeBicWEz0Mg(u"ࠪ࠱ࠬჷ")+XJ62UBRmIqFvfiNTQj.strftime(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠦࠪࡎ࠺ࠦࡏࠥჸ"),XJ62UBRmIqFvfiNTQj.gmtime(-wmWUxgHeuoOa9FCL))
	q24qAUj8wQEsorTlkI = ip+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬ࠲ࠧჹ")+RRrnKzx3aSojwGB1I4+eGW7cI6aQhr0(u"࠭ࠬࠨჺ")+wziCR1x4XQEAOB9U6KfGJYmTHl8+hCm2fnEXs6Zt(u"ࠧ࠭ࠩ჻")+pF9wEI43XhgkSDHRaZ6+OOkmZiVcfqlEurM1dHGb(u"ࠨ࠮ࠪჼ")+ttDWyhpsw4XfkH+IlL8ZnX74Yvep(u"ࠩ࠯ࠫჽ")+wmWUxgHeuoOa9FCL
	q24qAUj8wQEsorTlkI = q24qAUj8wQEsorTlkI.encode(YRvPKe2zMTDs8UCkr)
	if J92gCnbGWidQV70lBteTwU6D8uyzL: q24qAUj8wQEsorTlkI = q24qAUj8wQEsorTlkI.decode(lNTJCZeBicWEz0Mg(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫჾ"))
	q24qAUj8wQEsorTlkI = L5xKSr96JmaX7N(q24qAUj8wQEsorTlkI)
	return q24qAUj8wQEsorTlkI
def tSBXfikTvou6(i8COmeovjQzNB3W5kSAHtLxZaFV1):
	kUFKBwzhxEMDtIH9eg,showDialogs = NdKhAS6MXVEORLTwob92pxlZ,k6apiPAlLKM1ed8J42RjHh0o
	if i8COmeovjQzNB3W5kSAHtLxZaFV1.count(Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡤ࠭ჿ"))>=cCRvAuJQfjBpTg0PbYiaNO87:
		i8COmeovjQzNB3W5kSAHtLxZaFV1,kUFKBwzhxEMDtIH9eg = i8COmeovjQzNB3W5kSAHtLxZaFV1.split(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡥࠧᄀ"),llxMLe4gobHhsj1WGvd7qmIU)
		kUFKBwzhxEMDtIH9eg = R3lezw8h407ZvrAFxT(u"࠭࡟ࠨᄁ")+kUFKBwzhxEMDtIH9eg
		if WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬᄂ") in kUFKBwzhxEMDtIH9eg: showDialogs = f4vncKMRlXG9s
		else: showDialogs = k6apiPAlLKM1ed8J42RjHh0o
	return i8COmeovjQzNB3W5kSAHtLxZaFV1,kUFKBwzhxEMDtIH9eg,showDialogs
def J3qavAbx1ZNmS2YHkEjXK6():
	iJM4pYxHqdgwmb = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,IlL8ZnX74Yvep(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᄃ"))
	NiLBlXEqVw7jdvYc9HU510Prhy = e8XhbyuzvjYkIsJUtB5w
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(iJM4pYxHqdgwmb):
		for hNfrb20intZpMPUI3w in IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(iJM4pYxHqdgwmb):
			if eGW7cI6aQhr0(u"ࠩ࠱ࡴࡾࡵࠧᄄ") in hNfrb20intZpMPUI3w: continue
			if rNyT0edugn(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨᄅ") in hNfrb20intZpMPUI3w: continue
			W4WjYuz3KxvOod56Uq9RbsyQD = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(iJM4pYxHqdgwmb,hNfrb20intZpMPUI3w)
			LsdBE8ni6CvZQ2FU74KJY,ZZiHOu2GRo5SrgImeL34 = TGNwJtqvjZCnUhHKEXoep8xBbk(W4WjYuz3KxvOod56Uq9RbsyQD)
			NiLBlXEqVw7jdvYc9HU510Prhy += LsdBE8ni6CvZQ2FU74KJY
	return NiLBlXEqVw7jdvYc9HU510Prhy
def XX87wBWjidG1ZgVQc0uJDab3tq(showDialogs):
	njNe3lbqzcxEv2X7G = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᄆ"))
	k7s5qmQSzxUjPvcdBCt = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠬࡹࡴࡳࠩᄇ"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᄈ"),lNTJCZeBicWEz0Mg(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᄉ"))
	FCjbnt7UNEBomTYZqfkrxz9Ow,lEr430yfRt = njNe3lbqzcxEv2X7G,k7s5qmQSzxUjPvcdBCt
	Xjvn03sxNgqQJiGFhraMAB,E0R3FKYyUxO4gfwe = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	if Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᄊ") not in str(sevfFTR5mNndl):
		ZZT6GLaHQ1 = xKp3jkIvM09AZ4euXa87i5TVtfUD[JGwsL21ZRlqSrWxEmF(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᄋ")][uL69vJOU7xN0hGnZf2islDqk]
		HMpc7T2lNkGV3CEyPFI8hvq9aS = Fa1ehN3qiLZ8tfwj()
		wziCR1x4XQEAOB9U6KfGJYmTHl8 = HMpc7T2lNkGV3CEyPFI8hvq9aS.split(rNyT0edugn(u"ࠪ࠰ࠬᄌ"))[cCRvAuJQfjBpTg0PbYiaNO87]
		NiLBlXEqVw7jdvYc9HU510Prhy = J3qavAbx1ZNmS2YHkEjXK6()
		EEbWxcT86wIO54GFZgmoveXC = {QQHFtjcaR2VpnSyTIv(u"ࠫࡺࡹࡥࡳࠩᄍ"):lop0ZwWYLmxOPAaErzF6cQvDkVR,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᄎ"):lvsJ2jaZktmNO6PbdXS,HVmIrFwau90jQsgiWzExk(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᄏ"):wziCR1x4XQEAOB9U6KfGJYmTHl8,NOrchaEV1iIZ87Uzlwgum(u"ࠧࡪࡦࡶࠫᄐ"):R4kMS9YE5Nby3giq(NiLBlXEqVw7jdvYc9HU510Prhy)}
		MmDs0fWOCc3Bg = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,fOc18oTm5hsdD4pVZQj(u"ࠨࡒࡒࡗ࡙࠭ᄑ"),ZZT6GLaHQ1,EEbWxcT86wIO54GFZgmoveXC,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ᄒ"))
		if not MmDs0fWOCc3Bg.succeeded:
			if njNe3lbqzcxEv2X7G in [NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠪࡒࡊ࡝ࠧᄓ")]: FCjbnt7UNEBomTYZqfkrxz9Ow = QQHFtjcaR2VpnSyTIv(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᄔ")
			elif njNe3lbqzcxEv2X7G==QQHFtjcaR2VpnSyTIv(u"ࠬࡕࡌࡅࠩᄕ"): FCjbnt7UNEBomTYZqfkrxz9Ow = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᄖ")
		else:
			v84KXhZSOzMwt0jRdCFWrc59JLDTpB = MmDs0fWOCc3Bg.content
			v84KXhZSOzMwt0jRdCFWrc59JLDTpB = BdnA8WwtJeKUVvE(eGW7cI6aQhr0(u"ࠧ࡭࡫ࡶࡸࠬᄗ"),v84KXhZSOzMwt0jRdCFWrc59JLDTpB)
			v84KXhZSOzMwt0jRdCFWrc59JLDTpB = sorted(v84KXhZSOzMwt0jRdCFWrc59JLDTpB,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: int(key[e8XhbyuzvjYkIsJUtB5w]))
			E0R3FKYyUxO4gfwe,lEr430yfRt = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
			for qfMt30zJNPXIBUGO,gCwLj1RsF2BDh8Ocl7b4KUXW,ntDbV4lpe3WzTJ in v84KXhZSOzMwt0jRdCFWrc59JLDTpB:
				if qfMt30zJNPXIBUGO==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨ࠲ࠪᄘ"):
					E0R3FKYyUxO4gfwe += ntDbV4lpe3WzTJ+PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠽࠾ࠬᄙ")
					continue
				if lEr430yfRt: lEr430yfRt += B6IrC7zEHlw1oaeWf+Whef0cxB2iR93SC5IwUtk+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᄚ")+kjd9LyNqQHMUevZiRI7OlBGF1h+NOrchaEV1iIZ87Uzlwgum(u"ࠫࡡࡴ࡜࡯ࠩᄛ")
				PRxfNOs4YjMzbQe = ntDbV4lpe3WzTJ.split(B6IrC7zEHlw1oaeWf)[e8XhbyuzvjYkIsJUtB5w]
				zb8CjxRJgq093hdBMnTeaGm = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩᄜ") if gCwLj1RsF2BDh8Ocl7b4KUXW else NdKhAS6MXVEORLTwob92pxlZ
				lEr430yfRt += ntDbV4lpe3WzTJ.replace(PRxfNOs4YjMzbQe,D7INg5kyRjwf4ZtoePVUrb1h2SJ+PRxfNOs4YjMzbQe+zb8CjxRJgq093hdBMnTeaGm+kjd9LyNqQHMUevZiRI7OlBGF1h)+B6IrC7zEHlw1oaeWf
			lEr430yfRt = B6IrC7zEHlw1oaeWf+lEr430yfRt+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭࡜࡯࡞ࡱࠫᄝ")
			E0R3FKYyUxO4gfwe = E0R3FKYyUxO4gfwe.strip(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠻࠼ࠪᄞ"))
			Xjvn03sxNgqQJiGFhraMAB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(JGwsL21ZRlqSrWxEmF(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫᄟ"))
			if lEr430yfRt==k7s5qmQSzxUjPvcdBCt and njNe3lbqzcxEv2X7G in [OOkmZiVcfqlEurM1dHGb(u"ࠩࡒࡐࡉ࠭ᄠ"),gniNItGL6bKwpEW(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩᄡ")]: FCjbnt7UNEBomTYZqfkrxz9Ow = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡔࡒࡄࠨᄢ")
			else: FCjbnt7UNEBomTYZqfkrxz9Ow = Hlp3z0APt1GR4kMYK5xST(u"ࠬࡔࡅࡘࠩᄣ")
			eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᄤ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᄥ"),lEr430yfRt,hzP83xLawFqYneDtHGmSriWE)
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lrtFSogC8Nh9(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᄦ"),R4kMS9YE5Nby3giq(MMQhDpyCenmO350aBAKVYk))
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NeU6uRGpECkvMV5jf(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬᄧ"),E0R3FKYyUxO4gfwe)
			NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠺Ꭷ")*E0R3FKYyUxO4gfwe.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
			NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠷࠴Ꭸ")*NhZuHrpLxyqnSIjGs4VFiW3MXk65.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
			NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(IlL8ZnX74Yvep(u"࠱࠺Ꭹ")*NhZuHrpLxyqnSIjGs4VFiW3MXk65.encode(YRvPKe2zMTDs8UCkr)).hexdigest()
			Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(ZFMPvkNQbT2cHiUj)
			RR0jVLciM4S1UIw = ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(lrtFSogC8Nh9(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࡁࠬᄨ")+str(int(NhZuHrpLxyqnSIjGs4VFiW3MXk65[ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵Ꭻ"):xY4icgQUj6mPVs73CTKu(u"࠴࠶Ꭼ")],WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵࠻Ꭽ")))[:rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠺Ꭺ")]+lNTJCZeBicWEz0Mg(u"ࠫࡀ࠭ᄩ"))
			Yo5K7kXcjOVq2SiTvludJ48f.close()
		s2fhaumdexPCEBkpnZ9M = k6apiPAlLKM1ed8J42RjHh0o if E0R3FKYyUxO4gfwe!=Xjvn03sxNgqQJiGFhraMAB else f4vncKMRlXG9s
		if s2fhaumdexPCEBkpnZ9M:
			rwABl928Xkpb61DLWz4ytN = OMNiY8joQx.WiJPMTZvOLGsV0xB8al
			OMNiY8joQx.HHqA8u41iPZ,OMNiY8joQx.WiJPMTZvOLGsV0xB8al,OMNiY8joQx.ZIWy6VLs8hNkbrExYSjM3OXDUaRGmo,OMNiY8joQx.mmjbEaLDvxXGOsyo627 = JcQtOuhMdvYSyLNCw([vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ᄪ"),HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧᄫ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬᄬ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩᄭ")])
			FbChoiw1ADq = OMNiY8joQx.WiJPMTZvOLGsV0xB8al
			if not rwABl928Xkpb61DLWz4ytN and FbChoiw1ADq and HVmIrFwau90jQsgiWzExk(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧᄮ") in sevfFTR5mNndl:
				sevfFTR5mNndl.remove(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᄯ"))
				sevfFTR5mNndl.append(NOrchaEV1iIZ87Uzlwgum(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᄰ"))
			elif rwABl928Xkpb61DLWz4ytN and not FbChoiw1ADq and wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᄱ") in sevfFTR5mNndl:
				sevfFTR5mNndl.remove(HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᄲ"))
				sevfFTR5mNndl.append(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᄳ"))
			MIjcStaDWnv(f4vncKMRlXG9s)
	if showDialogs:
		if FCjbnt7UNEBomTYZqfkrxz9Ow in [ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᄴ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᄵ")]:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄶ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫ์์วไุ่่๊ࠢษࠡใํࠤัํวำๅࠣ์์๐ࠠๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ั้ࠣห้๋ิไๆฬࠤ็ี๋ࠠๅู๋๊ࠥศษ้สࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤฬ๊ัศ๊อีࠥอไฯษุࠤอ้ࠠฤู๊้้ࠣไสࠢไ๎ࠥอไฤี็หู่ࠦ็ัๆࠫᄷ"))
		else:
			cGY04x76XBKoQWJg9R5d2pkIvOsTFD(eGW7cI6aQhr0(u"ࠬࡸࡩࡨࡪࡷࠫᄸ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ัิษษ่๋ࠥๆࠡษ็้อืๅอࠢศ่๎ࠦๅิฬัำ๊๐ࠠศๆหี๋อๅอࠩᄹ"),lEr430yfRt,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᄺ"))
			FCjbnt7UNEBomTYZqfkrxz9Ow = OOkmZiVcfqlEurM1dHGb(u"ࠨࡑࡏࡈࠬᄻ")
	if FCjbnt7UNEBomTYZqfkrxz9Ow!=njNe3lbqzcxEv2X7G:
		ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(gniNItGL6bKwpEW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᄼ"),FCjbnt7UNEBomTYZqfkrxz9Ow)
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def hhsS5zK1clE4O3apXPTuxHG(FnCrjE5mLe3lKU,C8Byxocb1f2XJE53FaN):
	from socket import socket as IEda5gR6kvfhQw3W0j,AF_INET as iZJKAR5qgr624HQ,SOCK_STREAM as yV0sLZKX8gqDRA5ueOQtjd2S
	UZYHJXPfB8M1dx = IEda5gR6kvfhQw3W0j(iZJKAR5qgr624HQ,yV0sLZKX8gqDRA5ueOQtjd2S)
	UZYHJXPfB8M1dx.settimeout(llxMLe4gobHhsj1WGvd7qmIU)
	zPhBukdGmV03IW,Cglzp370P6OcGXR945A = k6apiPAlLKM1ed8J42RjHh0o,e8XhbyuzvjYkIsJUtB5w
	nDW6hxsUyd5NtALZ = XJ62UBRmIqFvfiNTQj.time()
	try: UZYHJXPfB8M1dx.connect((FnCrjE5mLe3lKU,C8Byxocb1f2XJE53FaN))
	except: zPhBukdGmV03IW = f4vncKMRlXG9s
	eDShqfYAwjcW1t6siza = XJ62UBRmIqFvfiNTQj.time()
	if zPhBukdGmV03IW: Cglzp370P6OcGXR945A = eDShqfYAwjcW1t6siza-nDW6hxsUyd5NtALZ
	return Cglzp370P6OcGXR945A
def fPhA8zJWjpb19U(showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄽ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪᄾ"))
	else: TT32BcvomhVewpgMSWkEb46y7xqO = k6apiPAlLKM1ed8J42RjHh0o
	if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU:
		for hNfrb20intZpMPUI3w in IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(vJQYPbL42F013CRoqtEUI):
			if hNfrb20intZpMPUI3w.endswith(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࠴ࡤࡣࠩᄿ")) and rNyT0edugn(u"࠭ࡤࡢࡶࡤࠫᅀ") in hNfrb20intZpMPUI3w:
				BhYaS5uGWnLvfAE3t82e = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,hNfrb20intZpMPUI3w)
				Yo5K7kXcjOVq2SiTvludJ48f,ODXQpWsKqya39FEctSmlRJ84rkM7vI = WEABULZXvMdCTxicg3(BhYaS5uGWnLvfAE3t82e)
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪᅁ"))
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(QQHFtjcaR2VpnSyTIv(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭ᅂ"))
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(kb2icmDGVUZfW1OFz7sv(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬᅃ"))
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(V0VZk9763fusTReHFo4(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ᅄ"))
				ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(OOkmZiVcfqlEurM1dHGb(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬᅅ"))
				Yo5K7kXcjOVq2SiTvludJ48f.commit()
				Yo5K7kXcjOVq2SiTvludJ48f.close()
		if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅆ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧᅇ"))
	return
def f2cgzj0TovI9YVl7tan1QkMS8(KkX2HPS5E3AdRUc7B,I7i1xurAntw5lW6UmQE2SFH3JVcf,showDialogs):
	if KkX2HPS5E3AdRUc7B!=None:
		OMNiY8joQx.ALLOW_DNS_FIX = KkX2HPS5E3AdRUc7B
	if I7i1xurAntw5lW6UmQE2SFH3JVcf!=None:
		OMNiY8joQx.ALLOW_PROXY_FIX = I7i1xurAntw5lW6UmQE2SFH3JVcf
	if showDialogs!=None:
		OMNiY8joQx.ALLOW_SHOWDIALOGS_FIX = showDialogs
	return
def XvhfRwib72MAxunGNYsD0(website,u4d0xmJkwWFSvCZaB2TMVHP36eU,YYmOIhlsbxR5vGd=None):
	OOMcyXNzkTYuqLaI = Hlp3z0APt1GR4kMYK5xST(u"࠶࠶Ꭾ")
	QuoF8exMg3d6l7PHCK = [LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),kb2icmDGVUZfW1OFz7sv(u"࠱࠱Ꮀ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠶Ꮁ"),kb2icmDGVUZfW1OFz7sv(u"࠱࠱Ꮀ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠷Ꭿ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"࠶Ꮁ")]
	cA8XegvG05xuDs9oQP2iOZqkI = []
	SdX7GTCAQwa8Nt4 = [gniNItGL6bKwpEW(u"࠲Ꮂ")]*OOMcyXNzkTYuqLaI
	US3CZiDQMWAJ905HwG1oOukqRPa = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,hCm2fnEXs6Zt(u"ࠧࡥ࡫ࡦࡸࠬᅈ"),NeU6uRGpECkvMV5jf(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪᅉ"))
	for pkIdwlL6VXOPYT3iD9xRAvcWMJy1 in list(US3CZiDQMWAJ905HwG1oOukqRPa.keys()):
		if website not in pkIdwlL6VXOPYT3iD9xRAvcWMJy1: continue
		mAH4aPy8q1w,kkgj2LcE4dBmZY6MAV7t1GNbTrS = pkIdwlL6VXOPYT3iD9xRAvcWMJy1.split(HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡢࡣࠬᅊ"))
		SdX7GTCAQwa8Nt4[int(kkgj2LcE4dBmZY6MAV7t1GNbTrS)] = US3CZiDQMWAJ905HwG1oOukqRPa[pkIdwlL6VXOPYT3iD9xRAvcWMJy1]
	for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(OOMcyXNzkTYuqLaI):
		if Lw25iFJMOgNEora84dkT0Hx7Zcpj in L0FAgEfwqWl5PUDhIzpi8J9KNm23o6+u4d0xmJkwWFSvCZaB2TMVHP36eU: continue
		if Lw25iFJMOgNEora84dkT0Hx7Zcpj==YYmOIhlsbxR5vGd: SdX7GTCAQwa8Nt4[Lw25iFJMOgNEora84dkT0Hx7Zcpj] = SdX7GTCAQwa8Nt4[Lw25iFJMOgNEora84dkT0Hx7Zcpj]+YJpWv4QzC7sx8INVPukeZiOD03K(u"࠴Ꮃ")
		if SdX7GTCAQwa8Nt4[Lw25iFJMOgNEora84dkT0Hx7Zcpj]<V0VZk9763fusTReHFo4(u"࠷Ꮄ"): cA8XegvG05xuDs9oQP2iOZqkI += [Lw25iFJMOgNEora84dkT0Hx7Zcpj]*QuoF8exMg3d6l7PHCK[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
	if not cA8XegvG05xuDs9oQP2iOZqkI:
		for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(OOMcyXNzkTYuqLaI):
			SdX7GTCAQwa8Nt4[Lw25iFJMOgNEora84dkT0Hx7Zcpj] = Hlp3z0APt1GR4kMYK5xST(u"࠵Ꮅ")
			if Lw25iFJMOgNEora84dkT0Hx7Zcpj in L0FAgEfwqWl5PUDhIzpi8J9KNm23o6+u4d0xmJkwWFSvCZaB2TMVHP36eU: continue
			cA8XegvG05xuDs9oQP2iOZqkI += [Lw25iFJMOgNEora84dkT0Hx7Zcpj]*QuoF8exMg3d6l7PHCK[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
	for Lw25iFJMOgNEora84dkT0Hx7Zcpj in L0FAgEfwqWl5PUDhIzpi8J9KNm23o6: SdX7GTCAQwa8Nt4[Lw25iFJMOgNEora84dkT0Hx7Zcpj] = YJpWv4QzC7sx8INVPukeZiOD03K(u"࠿࠹࠺࠻Ꮆ")
	lLB67X0emQfa = []
	for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(OOMcyXNzkTYuqLaI): lLB67X0emQfa.append(website+R3lezw8h407ZvrAFxT(u"ࠪࡣࡤ࠭ᅋ")+str(Lw25iFJMOgNEora84dkT0Hx7Zcpj))
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ᅌ"),lLB67X0emQfa,SdX7GTCAQwa8Nt4,vvgEtaduGZLspwRN9CYmyiefl1QA*V0VZk9763fusTReHFo4(u"࠵Ꮇ"),k6apiPAlLKM1ed8J42RjHh0o)
	return cA8XegvG05xuDs9oQP2iOZqkI
def mHdRh8KCp01I45v(fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,e5DznyEKA9hMcN3jX4Ou271gptkr=lNTJCZeBicWEz0Mg(u"ࠬ࠭ᅍ"),wNiDIHWX0BOk7ezTgfPx1RtVMvuKy=hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࠧᅎ"),u4d0xmJkwWFSvCZaB2TMVHP36eU=[]):
	kkDz5sdaPteM(rNyT0edugn(u"ࠧษัฦฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᅏ"),NdKhAS6MXVEORLTwob92pxlZ,XJ62UBRmIqFvfiNTQj=gniNItGL6bKwpEW(u"࠸࠷࠳Ꮈ"))
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lrtFSogC8Nh9(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᅐ")+str(e5DznyEKA9hMcN3jX4Ou271gptkr)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᅑ")+wNiDIHWX0BOk7ezTgfPx1RtVMvuKy+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᅒ")+xmezOWMyhSXRGHlEk2JnsI+lrtFSogC8Nh9(u"ࠫࠥࡣࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᅓ")+BfjcMoqOsmdUvZVCHWIyQKi+PzIpQnUXxRwNCivDhdakWTE(u"ࠬࠦ࡝ࠨᅔ"))
	website = xmezOWMyhSXRGHlEk2JnsI.split(R3lezw8h407ZvrAFxT(u"࠭࠭ࠨᅕ"))[e8XhbyuzvjYkIsJUtB5w]
	S4EOzTvfQ317abKA5kYZGx = XvhfRwib72MAxunGNYsD0(website,u4d0xmJkwWFSvCZaB2TMVHP36eU)
	n5w3CRodyczAelGWjuNHm2ZV = []
	if website==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᅖ"):
		if e8XhbyuzvjYkIsJUtB5w in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [e8XhbyuzvjYkIsJUtB5w]
		if llxMLe4gobHhsj1WGvd7qmIU in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [llxMLe4gobHhsj1WGvd7qmIU]
		if cCRvAuJQfjBpTg0PbYiaNO87 in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [cCRvAuJQfjBpTg0PbYiaNO87]
		if uL69vJOU7xN0hGnZf2islDqk in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [uL69vJOU7xN0hGnZf2islDqk]*gniNItGL6bKwpEW(u"࠳࠳Ꮉ")
		if TQNS6YMKAqnilsVObLpDRX in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [TQNS6YMKAqnilsVObLpDRX]*V0VZk9763fusTReHFo4(u"࠸Ꮊ")
		if vju3SZDWL4ENYelmBOzUqrogp2(u"࠺Ꮌ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [vju3SZDWL4ENYelmBOzUqrogp2(u"࠺Ꮌ")]*QQHFtjcaR2VpnSyTIv(u"࠵࠵Ꮋ")
		if JGwsL21ZRlqSrWxEmF(u"࠼Ꮍ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [JGwsL21ZRlqSrWxEmF(u"࠼Ꮍ")]
		if xY4icgQUj6mPVs73CTKu(u"࠷Ꮎ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [xY4icgQUj6mPVs73CTKu(u"࠷Ꮎ")]
	elif website==QQHFtjcaR2VpnSyTIv(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᅗ"):
		if uL69vJOU7xN0hGnZf2islDqk in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [uL69vJOU7xN0hGnZf2islDqk]*eGW7cI6aQhr0(u"࠲࠲Ꮏ")
	elif website==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫᅘ"):
		if llxMLe4gobHhsj1WGvd7qmIU in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [llxMLe4gobHhsj1WGvd7qmIU]
		if TQNS6YMKAqnilsVObLpDRX in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [TQNS6YMKAqnilsVObLpDRX]*WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠷Ꮐ")
		if fOc18oTm5hsdD4pVZQj(u"࠹Ꮒ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [fOc18oTm5hsdD4pVZQj(u"࠹Ꮒ")]*rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠴࠴Ꮑ")
		if lrtFSogC8Nh9(u"࠻Ꮓ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [lrtFSogC8Nh9(u"࠻Ꮓ")]
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"࠽Ꮔ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [YJpWv4QzC7sx8INVPukeZiOD03K(u"࠽Ꮔ")]
	elif website==pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᅙ"):
		if TQNS6YMKAqnilsVObLpDRX in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [TQNS6YMKAqnilsVObLpDRX]*rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠵Ꮕ")
		if V0VZk9763fusTReHFo4(u"࠷Ꮗ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [V0VZk9763fusTReHFo4(u"࠷Ꮗ")]*NeU6uRGpECkvMV5jf(u"࠲࠲Ꮖ")
	elif website==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬᅚ"):
		if lRP6GTaZJA1Xw3egLM4(u"࠼Ꮘ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [lRP6GTaZJA1Xw3egLM4(u"࠼Ꮘ")]*pnHgvFOCBZzc08yULQJGIqw9bf(u"࠵࠵Ꮙ")
	elif website==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡍࡏࡐࡉࡏࡉࡘࡋࡁࡓࡅࡋࠫᅛ"):
		if lRP6GTaZJA1Xw3egLM4(u"࠺Ꮛ") in S4EOzTvfQ317abKA5kYZGx: n5w3CRodyczAelGWjuNHm2ZV += [lRP6GTaZJA1Xw3egLM4(u"࠺Ꮛ")]*xY4icgQUj6mPVs73CTKu(u"࠺Ꮚ")
	if n5w3CRodyczAelGWjuNHm2ZV: S4EOzTvfQ317abKA5kYZGx = n5w3CRodyczAelGWjuNHm2ZV
	if S4EOzTvfQ317abKA5kYZGx:
		t0t9xLg6P8skKleECGQRTbSH = Ijo3hy7zQO5x8aU9vAZDMV.sample(S4EOzTvfQ317abKA5kYZGx,llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
	else: t0t9xLg6P8skKleECGQRTbSH = -llxMLe4gobHhsj1WGvd7qmIU
	update = k6apiPAlLKM1ed8J42RjHh0o
	if t0t9xLg6P8skKleECGQRTbSH==e8XhbyuzvjYkIsJUtB5w:
		scraperserver = lNTJCZeBicWEz0Mg(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠳ࠪᅜ")
		IFU87Wkc5uwqsPmtV29iY = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯࠾࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠾࠺࠹࠵࠴ࠩᅝ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+Hlp3z0APt1GR4kMYK5xST(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᅞ")+IFU87Wkc5uwqsPmtV29iY+OOkmZiVcfqlEurM1dHGb(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᅟ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==llxMLe4gobHhsj1WGvd7qmIU:
		scraperserver = kb2icmDGVUZfW1OFz7sv(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠸ࠧᅠ")
		IFU87Wkc5uwqsPmtV29iY = NOrchaEV1iIZ87Uzlwgum(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭ᅡ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+xY4icgQUj6mPVs73CTKu(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᅢ")+IFU87Wkc5uwqsPmtV29iY+rNyT0edugn(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᅣ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==cCRvAuJQfjBpTg0PbYiaNO87:
		scraperserver = V0VZk9763fusTReHFo4(u"ࠧࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬ࠫᅤ")
		IFU87Wkc5uwqsPmtV29iY = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠾࡫࡯࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧᅥ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+lRP6GTaZJA1Xw3egLM4(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᅦ")+IFU87Wkc5uwqsPmtV29iY+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᅧ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==uL69vJOU7xN0hGnZf2islDqk:
		scraperserver = kb2icmDGVUZfW1OFz7sv(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ᅨ")
		Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi.replace(fOc18oTm5hsdD4pVZQj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧᅩ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧᅪ"))
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = hCm2fnEXs6Zt(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲࡨࡹࡵ࠴ࡣࡰ࡯࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠩ࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡉࡥࡱࡹࡥࠧࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮ࠩࡹࡷࡲ࠽ࠨᅫ")+YUkzG2ymNSqdon(Afey3cL4ojzg)
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡉࡈࡘࠬᅬ"),pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==TQNS6YMKAqnilsVObLpDRX:
		scraperserver = hCm2fnEXs6Zt(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵࠩᅭ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = eGW7cI6aQhr0(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺ࠮ࡤࡱࡰ࠳ࡄࡺ࡯࡬ࡧࡱࡁࡦ࠺ࡦ࠸ࡨࡥ࠵࠹࠳࠲ࡥࡧࡩ࠱࠹࠶࠷࠲࠯࠻࠺࠹ࡨ࠭࠳࠴ࡨ࠷࠷࠼࠴ࡥ࠶ࡧࡨࡨࠬࡰࡳࡱࡻࡽࡈࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡷࡵࡰࡂ࠭ᅮ")+YUkzG2ymNSqdon(BfjcMoqOsmdUvZVCHWIyQKi)
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡌࡋࡔࠨᅯ"),pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
		try:
			wNeWBx39UjiCf6GFrV7obLmk.content = BdnA8WwtJeKUVvE(gniNItGL6bKwpEW(u"ࠬࡪࡩࡤࡶࠪᅰ"),wNeWBx39UjiCf6GFrV7obLmk.content)
			wNeWBx39UjiCf6GFrV7obLmk.content = wNeWBx39UjiCf6GFrV7obLmk.content[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᅱ")]
		except: pass
	elif t0t9xLg6P8skKleECGQRTbSH==vju3SZDWL4ENYelmBOzUqrogp2(u"࠵Ꮜ"):
		scraperserver = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠶࠭ᅲ")
		IFU87Wkc5uwqsPmtV29iY = NOrchaEV1iIZ87Uzlwgum(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡥࡶࡴࡽࡳࡦࡴࡀࡊࡦࡲࡳࡦࠨࡩࡳࡷࡽࡡࡳࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠼࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠲ࡨࡵ࡭࠻࠺࠳࠼࠵࠭ᅳ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+OOkmZiVcfqlEurM1dHGb(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᅴ")+IFU87Wkc5uwqsPmtV29iY+V0VZk9763fusTReHFo4(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᅵ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==QQHFtjcaR2VpnSyTIv(u"࠷Ꮝ"):
		scraperserver = PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠱ࠨᅶ")
		IFU87Wkc5uwqsPmtV29iY = kb2icmDGVUZfW1OFz7sv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡣ࠳࠸࠶ࡥࡧ࠷ࡥ࠶࠲࠷࠸ࡩ࠸ࡣࡢ࠷ࡧ࠹ࡩ࠹ࡦ࠺ࡧ࠶ࡧ࠸࠾࠶ࡦࡥࡤ࠵࠶࠶࠸࠴࠺࠼ࡥ࠼࠹࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩࠫ࡭ࡥࡰࡅࡲࡨࡪࡃࡩ࡭ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩᅷ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+fOc18oTm5hsdD4pVZQj(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᅸ")+IFU87Wkc5uwqsPmtV29iY+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᅹ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==HHvYL68lbJVZWM7tQEzSex3(u"࠹Ꮞ"):
		scraperserver = lRP6GTaZJA1Xw3egLM4(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬᅺ")
		IFU87Wkc5uwqsPmtV29iY = xY4icgQUj6mPVs73CTKu(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦࠨࡪࡩࡴࡉ࡯ࡥࡧࡀ࡭ࡱࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ᅻ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᅼ")+IFU87Wkc5uwqsPmtV29iY+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᅽ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==PzIpQnUXxRwNCivDhdakWTE(u"࠻Ꮟ"):
		scraperserver = eGW7cI6aQhr0(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩᅾ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = NeU6uRGpECkvMV5jf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᅿ")+YUkzG2ymNSqdon(BfjcMoqOsmdUvZVCHWIyQKi)
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(NeU6uRGpECkvMV5jf(u"ࠧࡈࡇࡗࠫᆀ"),pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	elif t0t9xLg6P8skKleECGQRTbSH==HHvYL68lbJVZWM7tQEzSex3(u"࠽Ꮠ"):
		scraperserver = lRP6GTaZJA1Xw3egLM4(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠸ࠧᆁ")
		IFU87Wkc5uwqsPmtV29iY = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡶࡪࡺࡵࡳࡰࡢࡴࡦ࡭ࡥࡠࡵࡲࡹࡷࡩࡥ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪᆂ")
		pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = BfjcMoqOsmdUvZVCHWIyQKi+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᆃ")+IFU87Wkc5uwqsPmtV29iY+HVmIrFwau90jQsgiWzExk(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᆄ")
		wNeWBx39UjiCf6GFrV7obLmk = W1nrEA8Xg3(fiuheaxH14ZML0,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	else:
		scraperserver,pYGHPzT0Ma7vQBe42SiWOnoEsdJ1 = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		wNeWBx39UjiCf6GFrV7obLmk = CDtdAcPSKah()
		update = f4vncKMRlXG9s
	if update and not wNeWBx39UjiCf6GFrV7obLmk.succeeded:
		XvhfRwib72MAxunGNYsD0(website,[],t0t9xLg6P8skKleECGQRTbSH)
		if len(list(set(S4EOzTvfQ317abKA5kYZGx)))>llxMLe4gobHhsj1WGvd7qmIU:
			TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆅ"),JGwsL21ZRlqSrWxEmF(u"࠭ไๅลึๅู๊ࠥาใิࠤ๊฿วๅฮฬࠤฬ๊ออสࠣี็๋ࠠࠨᆆ")+str(t0t9xLg6P8skKleECGQRTbSH)+HVmIrFwau90jQsgiWzExk(u"ࠧࠡใื่ࠥ็๊ࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢอะฬ๎าࠡษ็ััฮࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤุ๐ัโำ้ࠣำะไโࠢยࠥࠬᆇ"))
			if TT32BcvomhVewpgMSWkEb46y7xqO==llxMLe4gobHhsj1WGvd7qmIU:
				u4d0xmJkwWFSvCZaB2TMVHP36eU.append(t0t9xLg6P8skKleECGQRTbSH)
				wNeWBx39UjiCf6GFrV7obLmk = mHdRh8KCp01I45v(fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,QTJoMqgAIvF8OzRVn,wmDAkp0iLt,xmezOWMyhSXRGHlEk2JnsI,e5DznyEKA9hMcN3jX4Ou271gptkr,wNiDIHWX0BOk7ezTgfPx1RtVMvuKy,u4d0xmJkwWFSvCZaB2TMVHP36eU)
				return wNeWBx39UjiCf6GFrV7obLmk
	wNeWBx39UjiCf6GFrV7obLmk.scrapernumber = str(t0t9xLg6P8skKleECGQRTbSH)
	wNeWBx39UjiCf6GFrV7obLmk.scraperserver = scraperserver
	wNeWBx39UjiCf6GFrV7obLmk.scraperurl = pYGHPzT0Ma7vQBe42SiWOnoEsdJ1
	h5oE6DKTWfkQlatSrNvyV7e = NOrchaEV1iIZ87Uzlwgum(u"ࠨีํีๆืࠠาไ่ࠤࠬᆈ")+wNeWBx39UjiCf6GFrV7obLmk.scrapernumber
	if wNeWBx39UjiCf6GFrV7obLmk.succeeded:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lRP6GTaZJA1Xw3egLM4(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᆉ")+scraperserver+eGW7cI6aQhr0(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆊ")+xmezOWMyhSXRGHlEk2JnsI+lNTJCZeBicWEz0Mg(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᆋ")+BfjcMoqOsmdUvZVCHWIyQKi+NeU6uRGpECkvMV5jf(u"ࠬࠦ࡝ࠨᆌ"))
		kkDz5sdaPteM(vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᆍ"),h5oE6DKTWfkQlatSrNvyV7e,XJ62UBRmIqFvfiNTQj=JGwsL21ZRlqSrWxEmF(u"࠼࠻࠰Ꮡ"))
	else:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫᆎ")+scraperserver+HHvYL68lbJVZWM7tQEzSex3(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᆏ")+str(wNeWBx39UjiCf6GFrV7obLmk.code)+JGwsL21ZRlqSrWxEmF(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᆐ")+wNeWBx39UjiCf6GFrV7obLmk.reason+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆑ")+xmezOWMyhSXRGHlEk2JnsI+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᆒ")+BfjcMoqOsmdUvZVCHWIyQKi+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࠦ࡝ࠨᆓ"))
		kkDz5sdaPteM(NOrchaEV1iIZ87Uzlwgum(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᆔ"),h5oE6DKTWfkQlatSrNvyV7e,XJ62UBRmIqFvfiNTQj=Tzx81Wb0RZC4ID5AyiU2(u"࠽࠵࠱Ꮢ"))
	return wNeWBx39UjiCf6GFrV7obLmk
def NNOlox5zCj0XvqkAiraH8pLGbe4g(CSHxmGj6O01AWEXVoRcK,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,showDialogs,xmezOWMyhSXRGHlEk2JnsI):
	if not dJC476xoE1ecpm0 or isinstance(dJC476xoE1ecpm0,dict): fiuheaxH14ZML0 = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡈࡇࡗࠫᆕ")
	else:
		fiuheaxH14ZML0 = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡒࡒࡗ࡙࠭ᆖ")
		dJC476xoE1ecpm0 = OOFEmwq2GkTz93WXy1Nj(dJC476xoE1ecpm0)
		TTd1RfDSI0bq6GrVmc8Ug9QyKCoWk,dJC476xoE1ecpm0 = muYp09a1NhMo7cZng5IOXyTSKt4qv2(dJC476xoE1ecpm0)
	MmDs0fWOCc3Bg = cJaAB4uQyp(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,k6apiPAlLKM1ed8J42RjHh0o,showDialogs,xmezOWMyhSXRGHlEk2JnsI)
	tWcXU498FSdjKl2Iw7M = MmDs0fWOCc3Bg.content
	tWcXU498FSdjKl2Iw7M = str(tWcXU498FSdjKl2Iw7M)
	return tWcXU498FSdjKl2Iw7M
def ubz0qK9aRUNEQj6HrvF2OpCGLS47(ZZT6GLaHQ1):
	LD41PtegiRVhx32Foyp = ZZT6GLaHQ1.split(NeU6uRGpECkvMV5jf(u"ࠩࡿࢀࠬᆗ"))
	BfjcMoqOsmdUvZVCHWIyQKi,ekC5B0cLVoOYiQJbKv43sTMWXtn,gWPvSYDsxc,thQS25UGHN9I0ywmbvWM4gCrOVp = LD41PtegiRVhx32Foyp[e8XhbyuzvjYkIsJUtB5w],None,None,k6apiPAlLKM1ed8J42RjHh0o
	for KiBecyPA5WSGXCQu38h1F4n in LD41PtegiRVhx32Foyp:
		if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᆘ") in KiBecyPA5WSGXCQu38h1F4n: ekC5B0cLVoOYiQJbKv43sTMWXtn = KiBecyPA5WSGXCQu38h1F4n[eGW7cI6aQhr0(u"࠱࠲Ꮣ"):]
		elif NOrchaEV1iIZ87Uzlwgum(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᆙ") in KiBecyPA5WSGXCQu38h1F4n: gWPvSYDsxc = KiBecyPA5WSGXCQu38h1F4n[kb2icmDGVUZfW1OFz7sv(u"࠺Ꮤ"):]
		elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᆚ") in KiBecyPA5WSGXCQu38h1F4n: thQS25UGHN9I0ywmbvWM4gCrOVp = f4vncKMRlXG9s
	return BfjcMoqOsmdUvZVCHWIyQKi,ekC5B0cLVoOYiQJbKv43sTMWXtn,gWPvSYDsxc,thQS25UGHN9I0ywmbvWM4gCrOVp
def C8Y0qMpABJKzNRG9kvOWy(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,ZZT6GLaHQ1,yWeoHwkC1tuIR0DOan6cldYp,BBkJtawedRljxcbUsznOv0Ty,BYTWjHUNI9XzCSha5G241,JoWX5If80G=NdKhAS6MXVEORLTwob92pxlZ):
	EE8pkA29X6vBYTOerGgJS4Zyt = msbTrJW03xuvA(ZZT6GLaHQ1,PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡵࡳ࡮ࠪᆛ"))
	W9g3i4X1RSway = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᆜ")+yWeoHwkC1tuIR0DOan6cldYp)
	if EE8pkA29X6vBYTOerGgJS4Zyt==W9g3i4X1RSway: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(fOc18oTm5hsdD4pVZQj(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᆝ")+yWeoHwkC1tuIR0DOan6cldYp,NdKhAS6MXVEORLTwob92pxlZ)
	if W9g3i4X1RSway: Afey3cL4ojzg = ZZT6GLaHQ1.replace(EE8pkA29X6vBYTOerGgJS4Zyt,W9g3i4X1RSway)
	else:
		Afey3cL4ojzg = ZZT6GLaHQ1
		W9g3i4X1RSway = EE8pkA29X6vBYTOerGgJS4Zyt
	ROC7WiSmuMYvFayLc5Ed = cJaAB4uQyp(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,JoWX5If80G,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭ᆞ"))
	tWcXU498FSdjKl2Iw7M = ROC7WiSmuMYvFayLc5Ed.content
	if J92gCnbGWidQV70lBteTwU6D8uyzL:
		try: tWcXU498FSdjKl2Iw7M = tWcXU498FSdjKl2Iw7M.decode(YRvPKe2zMTDs8UCkr,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᆟ"))
		except: pass
	if not ROC7WiSmuMYvFayLc5Ed.succeeded or BYTWjHUNI9XzCSha5G241 not in tWcXU498FSdjKl2Iw7M:
		BBkJtawedRljxcbUsznOv0Ty = BBkJtawedRljxcbUsznOv0Ty.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,gniNItGL6bKwpEW(u"ࠫ࠰࠭ᆠ"))
		BfjcMoqOsmdUvZVCHWIyQKi = lRP6GTaZJA1Xw3egLM4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪᆡ")+BBkJtawedRljxcbUsznOv0Ty
		omrd89nv0PGKFpL3TxfAXt = {OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᆢ"):NdKhAS6MXVEORLTwob92pxlZ}
		HYfNLiDK3yRF7 = cJaAB4uQyp(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫᆣ"))
		if HYfNLiDK3yRF7.succeeded:
			tWcXU498FSdjKl2Iw7M = HYfNLiDK3yRF7.content
			if J92gCnbGWidQV70lBteTwU6D8uyzL:
				try: tWcXU498FSdjKl2Iw7M = tWcXU498FSdjKl2Iw7M.decode(YRvPKe2zMTDs8UCkr,gniNItGL6bKwpEW(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᆤ"))
				except: pass
			oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᆥ"),tWcXU498FSdjKl2Iw7M,YYqECUofyi7wFrW.DOTALL)
			vY6FELhax9eOcB0G75QpzDjVkSCw1g = [W9g3i4X1RSway]
			G6X510afmUsrWbCxBTH = [HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡥࡵࡱࠧᆦ"),V0VZk9763fusTReHFo4(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᆧ"),NOrchaEV1iIZ87Uzlwgum(u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭ᆨ"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᆩ"),IlL8ZnX74Yvep(u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩᆪ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡲ࡫ࡴࠬᆫ"),NeU6uRGpECkvMV5jf(u"ࠩࡤࡸࡱࡧࡱࠨᆬ"),lNTJCZeBicWEz0Mg(u"ࠪࡷ࡮ࡺࡥࡪࡰࡧ࡭ࡨ࡫ࡳࠨᆭ"),kb2icmDGVUZfW1OFz7sv(u"ࠫࡸࡻࡲ࠯࡮ࡼࠫᆮ"),kb2icmDGVUZfW1OFz7sv(u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᆯ"),IlL8ZnX74Yvep(u"࠭ࡩ࡯ࡨࡲࡶࡲ࡫ࡲࠨᆰ"),Hlp3z0APt1GR4kMYK5xST(u"ࠧࡴ࡫ࡷࡩࡱ࡯࡫ࡦࠩᆱ"),IlL8ZnX74Yvep(u"ࠨ࡫ࡱࡷࡹࡧࡧࡳࡣࡰࠫᆲ"),hCm2fnEXs6Zt(u"ࠩࡶࡲࡦࡶࡣࡩࡣࡷࠫᆳ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠪ࡬ࡹࡺࡰ࠮ࡧࡴࡹ࡮ࡼࠧᆴ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫ࡫ࡧࡳࡦ࡮ࡳࡰࡺࡹࠧᆵ")]
			for XdfIYHGOi7Q3njzWaUwcJrk in oDhlaxn0EqyYikcHrmZBN8uv:
				if any(K6KbZDHncNizQgl1fr59XV0 in XdfIYHGOi7Q3njzWaUwcJrk for K6KbZDHncNizQgl1fr59XV0 in G6X510afmUsrWbCxBTH): continue
				W9g3i4X1RSway = msbTrJW03xuvA(XdfIYHGOi7Q3njzWaUwcJrk,xY4icgQUj6mPVs73CTKu(u"ࠬࡻࡲ࡭ࠩᆶ"))
				if W9g3i4X1RSway in vY6FELhax9eOcB0G75QpzDjVkSCw1g: continue
				if len(vY6FELhax9eOcB0G75QpzDjVkSCw1g)==OOkmZiVcfqlEurM1dHGb(u"࠻Ꮥ"):
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ᆷ")+yWeoHwkC1tuIR0DOan6cldYp+Tzx81Wb0RZC4ID5AyiU2(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᆸ")+EE8pkA29X6vBYTOerGgJS4Zyt+JGwsL21ZRlqSrWxEmF(u"ࠨࠢࡠࠫᆹ"))
					ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᆺ")+yWeoHwkC1tuIR0DOan6cldYp,NdKhAS6MXVEORLTwob92pxlZ)
					break
				vY6FELhax9eOcB0G75QpzDjVkSCw1g.append(W9g3i4X1RSway)
				Afey3cL4ojzg = ZZT6GLaHQ1.replace(EE8pkA29X6vBYTOerGgJS4Zyt,W9g3i4X1RSway)
				ROC7WiSmuMYvFayLc5Ed = cJaAB4uQyp(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,JoWX5If80G,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧᆻ"))
				tWcXU498FSdjKl2Iw7M = ROC7WiSmuMYvFayLc5Ed.content
				if ROC7WiSmuMYvFayLc5Ed.succeeded and BYTWjHUNI9XzCSha5G241 in tWcXU498FSdjKl2Iw7M:
					LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NOrchaEV1iIZ87Uzlwgum(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫᆼ")+yWeoHwkC1tuIR0DOan6cldYp+kb2icmDGVUZfW1OFz7sv(u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫᆽ")+W9g3i4X1RSway+hCm2fnEXs6Zt(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫᆾ")+EE8pkA29X6vBYTOerGgJS4Zyt+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࠡ࡟ࠪᆿ"))
					ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᇀ")+yWeoHwkC1tuIR0DOan6cldYp,W9g3i4X1RSway)
					break
	return W9g3i4X1RSway,Afey3cL4ojzg,ROC7WiSmuMYvFayLc5Ed
def P02oGj7X8m5uMz6VUCScZbDnLp4fR(HSb5r1Di9I8eKTtAyuNZdC4W):
	ghT0DuIqbr = {
	 wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᇁ")				:pnHgvFOCBZzc08yULQJGIqw9bf(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᇂ")
	,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡦࡱ࡯ࡢ࡯ࠪᇃ")				:hCm2fnEXs6Zt(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩᇄ")
	,rNyT0edugn(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᇅ")				:NOrchaEV1iIZ87Uzlwgum(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᇆ")
	,fOc18oTm5hsdD4pVZQj(u"ࠨࡣ࡮ࡻࡦࡳࠧᇇ")				:OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᇈ")
	,kb2icmDGVUZfW1OFz7sv(u"ࠪࡥࡰࡽࡡ࡮ࡶࡸࡦࡪ࠭ᇉ")			:R3lezw8h407ZvrAFxT(u"๊ࠫ๎โฺࠢส็ํอๅࠡฬํ์อ࠭ᇊ")
	,rNyT0edugn(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᇋ")				:OOkmZiVcfqlEurM1dHGb(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᇌ")
	,fOc18oTm5hsdD4pVZQj(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᇍ")				:wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᇎ")
	,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᇏ")			:YJpWv4QzC7sx8INVPukeZiOD03K(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭ᇐ")
	,QQHFtjcaR2VpnSyTIv(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭ᇑ")				:rtUJso6d7iaNf1yWejxnc5DEXFg(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩᇒ")
	,lRP6GTaZJA1Xw3egLM4(u"࠭ࡡ࡭࡯ࡶࡸࡧࡧࠧᇓ")				:WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧๆ๊ๅ฽ࠥอไๆืฺฬฮ࠭ᇔ")
	,R3lezw8h407ZvrAFxT(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪᇕ")				:hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨᇖ")
	,HVmIrFwau90jQsgiWzExk(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨᇗ")			:NOrchaEV1iIZ87Uzlwgum(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ᇘ")
	,kb2icmDGVUZfW1OFz7sv(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧᇙ")				:ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭ᇚ")
	,hCm2fnEXs6Zt(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩᇛ")				:fOc18oTm5hsdD4pVZQj(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩᇜ")
	,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡤࡽࡱࡵ࡬ࠨᇝ")				:V0VZk9763fusTReHFo4(u"้ࠪํู่ࠡลํ่ํ๊ࠧᇞ")
	,lRP6GTaZJA1Xw3egLM4(u"ࠫࡧࡵ࡫ࡳࡣࠪᇟ")				:NeU6uRGpECkvMV5jf(u"๋่ࠬใ฻ࠣฬ่ืวࠨᇠ")
	,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡢࡳࡵࡷࡩ࡯࠭ᇡ")				:LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬᇢ")
	,hCm2fnEXs6Zt(u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩᇣ")				:lNTJCZeBicWEz0Mg(u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩᇤ")
	,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡧ࡮ࡳࡡ࠵ࡲࠪᇥ")				:JGwsL21ZRlqSrWxEmF(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิࠤอ๐ࠧᇦ")
	,QQHFtjcaR2VpnSyTIv(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬᇧ")				:eGW7cI6aQhr0(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨᇨ")
	,hCm2fnEXs6Zt(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩᇩ")				:OOkmZiVcfqlEurM1dHGb(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩᇪ")
	,V0VZk9763fusTReHFo4(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫᇫ")				:rNyT0edugn(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫᇬ")
	,OOkmZiVcfqlEurM1dHGb(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪᇭ")			:IlL8ZnX74Yvep(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪᇮ")
	,LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨᇯ")				:lRP6GTaZJA1Xw3egLM4(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᇰ")
	,fOc18oTm5hsdD4pVZQj(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪᇱ")				:ggWEFaH6fcVIO9SzRZLiuxo7P(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪᇲ")
	,HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡧ࡮ࡳࡡࡧࡴࡨࡩࠬᇳ")				:QQHFtjcaR2VpnSyTIv(u"๊ࠫ๎โฺࠢึ๎๊อࠠโำํࠫᇴ")
	,rNyT0edugn(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨᇵ")			:kb2icmDGVUZfW1OFz7sv(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧᇶ")
	,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᇷ")				:hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨᇸ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡦ࡭ࡲࡧࡷࡣࡣࡶࠫᇹ")				:wP4kpvXoDHq3hs7TFLyr2COn8(u"้ࠪํู่ࠡีํ้ฬ่ࠦษีࠪᇺ")
	,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᇻ")			:rtUJso6d7iaNf1yWejxnc5DEXFg(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠧᇼ")
	,IlL8ZnX74Yvep(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᇽ")	:wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢืฯิฯๆ์้ࠫᇾ")
	,fOc18oTm5hsdD4pVZQj(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡨࡢࡵ࡫ࡸࡦ࡭ࡳࠨᇿ")	:rNyT0edugn(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫሀ")
	,NOrchaEV1iIZ87Uzlwgum(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮࡮࡬ࡺࡪࡹࠧሁ")	:lNTJCZeBicWEz0Mg(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅษษืีࠬሂ")
	,PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ሃ"):lNTJCZeBicWEz0Mg(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧሄ")
	,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬህ")	:OOkmZiVcfqlEurM1dHGb(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪሆ")
	,Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧሇ")	:vju3SZDWL4ENYelmBOzUqrogp2(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧለ")
	,gniNItGL6bKwpEW(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ሉ")				:Tzx81Wb0RZC4ID5AyiU2(u"๋ࠬส้ไไࠫሊ")
	,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡤࡳࡣࡰࡥࡨࡧࡦࡦࠩላ")			:Tzx81Wb0RZC4ID5AyiU2(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤ่อแ๋้ࠪሌ")
	,xY4icgQUj6mPVs73CTKu(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩል")				:wP4kpvXoDHq3hs7TFLyr2COn8(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩሎ")
	,V0VZk9763fusTReHFo4(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫሏ")				:OOkmZiVcfqlEurM1dHGb(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬሐ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧሑ")				:IlL8ZnX74Yvep(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩሒ")
	,lNTJCZeBicWEz0Mg(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩሓ")				:R3lezw8h407ZvrAFxT(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫሔ")
	,lNTJCZeBicWEz0Mg(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫሕ")				:LtGoXlQ2IYxqTJRySE6udfW98(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭ሖ")
	,fOc18oTm5hsdD4pVZQj(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭ሗ")				:JGwsL21ZRlqSrWxEmF(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨመ")
	,hCm2fnEXs6Zt(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪሙ")			:QQHFtjcaR2VpnSyTIv(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬሚ")
	,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩማ")				:HHvYL68lbJVZWM7tQEzSex3(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩሜ")
	,rNyT0edugn(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪም")				:wP4kpvXoDHq3hs7TFLyr2COn8(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫሞ")
	,rNyT0edugn(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧሟ")				:JGwsL21ZRlqSrWxEmF(u"࠭ๅ้ไ฼ࠤ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬሠ")
	,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡦ࡮࡬ࡪࡻ࡯ࡤࡦࡱࠪሡ")			:HVmIrFwau90jQsgiWzExk(u"ࠨ็๋ๆ฾ࠦรๅ์ไࠤๆ๐ฯ๋๊ࠪሢ")
	,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪሣ")				:Hlp3z0APt1GR4kMYK5xST(u"้ࠪํู่ࠡใหี่ฯࠧሤ")
	,HHvYL68lbJVZWM7tQEzSex3(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫሥ")				:R3lezw8h407ZvrAFxT(u"ࠬ็ิๅࠩሦ")
	,V0VZk9763fusTReHFo4(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩሧ")			:vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬረ")
	,OOkmZiVcfqlEurM1dHGb(u"ࠨࡨࡤࡶࡪࡹ࡫ࡰࠩሩ")				:lRP6GTaZJA1Xw3egLM4(u"่ࠩ์็฿ࠠโษิื่๎ࠧሪ")
	,eGW7cI6aQhr0(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬራ")				:pnHgvFOCBZzc08yULQJGIqw9bf(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭ሬ")
	,xY4icgQUj6mPVs73CTKu(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧር")				:OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩሮ")
	,HVmIrFwau90jQsgiWzExk(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧሯ")				:JGwsL21ZRlqSrWxEmF(u"ࠨ็ฯ่ิ࠭ሰ")
	,lrtFSogC8Nh9(u"ࠩࡩࡳࡸࡺࡡࠨሱ")				:lNTJCZeBicWEz0Mg(u"้ࠪํู่ࠡใ๋ืฯอࠧሲ")
	,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫ࡫ࡻ࡮ࡰࡰࡷࡺࠬሳ")				:JGwsL21ZRlqSrWxEmF(u"๋่ࠬใ฻ࠣๅ๋๎ๆࠡฬํๅ๏࠭ሴ")
	,lrtFSogC8Nh9(u"࠭ࡦࡶࡵ࡫ࡥࡷࡺࡶࠨስ")				:NOrchaEV1iIZ87Uzlwgum(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤฯ๐แ๋ࠩሶ")
	,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ሷ")			:R3lezw8h407ZvrAFxT(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬሸ")
	,rNyT0edugn(u"ࠪ࡫ࡴࡵࡤࠨሹ")					:rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫั๐ฯࠨሺ")
	,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧሻ")				:kb2icmDGVUZfW1OFz7sv(u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ሼ")
	,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡩࡧ࡯ࡥࡱ࠭ሽ")				:HVmIrFwau90jQsgiWzExk(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫሾ")
	,kb2icmDGVUZfW1OFz7sv(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨሿ")				:gniNItGL6bKwpEW(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧቀ")
	,PzIpQnUXxRwNCivDhdakWTE(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪቁ")			:rNyT0edugn(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧቂ")
	,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭ቃ")		:QQHFtjcaR2VpnSyTIv(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬቄ")
	,OOkmZiVcfqlEurM1dHGb(u"ࠨ࡫ࡳࡸࡻ࠭ቅ")					:wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡌࡔ࡙࡜ࠧቆ")
	,eGW7cI6aQhr0(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ቇ")			:wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨቈ")
	,Tzx81Wb0RZC4ID5AyiU2(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪ቉")			:QQHFtjcaR2VpnSyTIv(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪቊ")
	,PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬቋ")			:kb2icmDGVUZfW1OFz7sv(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧቌ")
	,HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬቍ")			:Hlp3z0APt1GR4kMYK5xST(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭቎")
	,QQHFtjcaR2VpnSyTIv(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭቏")				:pnHgvFOCBZzc08yULQJGIqw9bf(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧቐ")
	,R3lezw8h407ZvrAFxT(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨቑ")				:kb2icmDGVUZfW1OFz7sv(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫቒ")
	,xY4icgQUj6mPVs73CTKu(u"ࠨ࡭࡬ࡶࡲࡧ࡬࡬ࠩቓ")				:pnHgvFOCBZzc08yULQJGIqw9bf(u"่ࠩ์็฿ࠠไำ่ห้้ࠧቔ")
	,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡰࡦࡸ࡯ࡻࡣࠪቕ")				:lRP6GTaZJA1Xw3egLM4(u"๊ࠫ๎โฺࠢ็หึ๎าศࠩቖ")
	,V0VZk9763fusTReHFo4(u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭቗")				:HHvYL68lbJVZWM7tQEzSex3(u"࠭ๅๅใࠪቘ")
	,gniNItGL6bKwpEW(u"ࠧ࡭࡫ࡹࡩࠬ቙")					:HHvYL68lbJVZWM7tQEzSex3(u"ࠨไ้หฮ࠭ቚ")
	,rNyT0edugn(u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩቛ")				:LtGoXlQ2IYxqTJRySE6udfW98(u"้้ࠪ็ࠧቜ")
	,Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬቝ")				:vju3SZDWL4ENYelmBOzUqrogp2(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ቞")
	,kb2icmDGVUZfW1OFz7sv(u"࠭࡭࠴ࡷࠪ቟")					:NOrchaEV1iIZ87Uzlwgum(u"ࠧࡎ࠵ࡘࠫበ")
	,Hlp3z0APt1GR4kMYK5xST(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪቡ")				:hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬቢ")
	,eGW7cI6aQhr0(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧባ")			:hCm2fnEXs6Zt(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧቤ")
	,R3lezw8h407ZvrAFxT(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩብ")			:lNTJCZeBicWEz0Mg(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫቦ")
	,NeU6uRGpECkvMV5jf(u"ࠧ࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱࠪቧ")			:xY4icgQUj6mPVs73CTKu(u"ࠨ็๋ๆ฾ࠦๅศีสࠤๆ๐ฯ๋๊ࠪቨ")
	,lrtFSogC8Nh9(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪቩ")				:OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"้ࠪๆ่่ะࠩቪ")
	,hCm2fnEXs6Zt(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫቫ")				:kb2icmDGVUZfW1OFz7sv(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧቬ")
	,PzIpQnUXxRwNCivDhdakWTE(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ቭ")				:lNTJCZeBicWEz0Mg(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧቮ")
	,PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡱ࡯ࡨࠬቯ")					:vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩๅำ๏๋ࠧተ")
	,NeU6uRGpECkvMV5jf(u"ࠪࡴࡦࡴࡥࡵࠩቱ")				:rNyT0edugn(u"๊ࠫ๎โฺࠢหห๋๐สࠨቲ")
	,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫታ")			:IlL8ZnX74Yvep(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩቴ")
	,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ት")			:pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭ቶ")
	,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡴࡪ࡮ࡲ࡭ࠨቷ")				:rtUJso6d7iaNf1yWejxnc5DEXFg(u"้ࠪํู่ࠡๅํ์ࠥ็๊ๅ็ࠪቸ")
	,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥࠨቹ")			:JGwsL21ZRlqSrWxEmF(u"๋่ࠬใ฻ࠣื๏ื๊ิࠢอห๏๋ࠧቺ")
	,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩቻ")			:hCm2fnEXs6Zt(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫቼ")
	,R3lezw8h407ZvrAFxT(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪች")				:V0VZk9763fusTReHFo4(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫቾ")
	,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧቿ")			:ggWEFaH6fcVIO9SzRZLiuxo7P(u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬኀ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨኁ")			:NOrchaEV1iIZ87Uzlwgum(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨኂ")
	,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪኃ")		:PzIpQnUXxRwNCivDhdakWTE(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩኄ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬኅ")		:LtGoXlQ2IYxqTJRySE6udfW98(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬኆ")
	,xY4icgQUj6mPVs73CTKu(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨኇ")	:eGW7cI6aQhr0(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬኈ")
	,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭኉")				:wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩኊ")
	,lrtFSogC8Nh9(u"ࠨࡵ࡫ࡳࡴ࡬࡭ࡢࡺࠪኋ")				:lRP6GTaZJA1Xw3egLM4(u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩኌ")
	,HVmIrFwau90jQsgiWzExk(u"ࠪࡷ࡭ࡵ࡯ࡧࡰࡨࡸࠬኍ")				:rNyT0edugn(u"๊ࠫ๎โฺࠢื์ๆࠦๆหࠩ኎")
	,OOkmZiVcfqlEurM1dHGb(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ኏")				:NeU6uRGpECkvMV5jf(u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬነ")
	,eGW7cI6aQhr0(u"ࠧࡵ࡫࡮ࡥࡦࡺࠧኑ")				:HVmIrFwau90jQsgiWzExk(u"ࠨ็๋ๆ฾ࠦสไษอࠫኒ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡷࡺ࡫ࡻ࡮ࠨና")				:fOc18oTm5hsdD4pVZQj(u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪኔ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡻࡧࡲࡣࡱࡱࠫን")				:lrtFSogC8Nh9(u"๋่ࠬใ฻ࠣๅฬืศ้่ࠪኖ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡶࡪࡦࡨࡳࠬኗ")				:YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧโ์า๎ํ࠭ኘ")
	,xY4icgQUj6mPVs73CTKu(u"ࠨࡸ࡬ࡨࡪࡵ࡮ࡴࡣࡨࡱࠬኙ")			:WiIt2NUHAqQ5wrud3TgkCRDj7L(u"่ࠩ์็฿ࠠโ์า๎ํࠦๆิษษ้ࠬኚ")
	,rNyT0edugn(u"ࠪࡻࡪࡩࡩ࡮ࡣ࠴ࠫኛ")				:kb2icmDGVUZfW1OFz7sv(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠣ࠵ࠬኜ")
	,lRP6GTaZJA1Xw3egLM4(u"ࠬࡽࡥࡤ࡫ࡰࡥ࠷࠭ኝ")				:vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠥ࠸ࠧኞ")
	,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡺࡣࡴࡳࡹ࠭ኟ")				:OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬአ")
	,Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪኡ")				:lRP6GTaZJA1Xw3egLM4(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨኢ")
	,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧኣ")		:HHvYL68lbJVZWM7tQEzSex3(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩኤ")
	,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪእ")	:ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫኦ")
	,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠩኧ")		:HHvYL68lbJVZWM7tQEzSex3(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩከ")
	,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡽࡹࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩኩ")			:Tzx81Wb0RZC4ID5AyiU2(u"๊ࠫ๎วใ฻้๋๊้ࠣࠦฬํ์อ࠭ኪ")
	}
	A3AEoSWgaR9YLvfxhycpzw1bs = HSb5r1Di9I8eKTtAyuNZdC4W.lower()
	for key in list(ghT0DuIqbr.keys()):
		JQpKOeyntF4V = key.lower()
		if A3AEoSWgaR9YLvfxhycpzw1bs==JQpKOeyntF4V:
			HSb5r1Di9I8eKTtAyuNZdC4W = ghT0DuIqbr[key]
			break
	return HSb5r1Di9I8eKTtAyuNZdC4W
def yyTm3OqzGEYApS():
	eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬካ"))
	raise ValueError(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩኬ"))
def MIjcStaDWnv(ba7oA5f2SPLrX,qUx6vZiKgs75=NdKhAS6MXVEORLTwob92pxlZ):
	global lfcLCw603F8yDeIpTxnjNh9UqA2Z
	lfcLCw603F8yDeIpTxnjNh9UqA2Z = k6apiPAlLKM1ed8J42RjHh0o
	if not qUx6vZiKgs75 and ba7oA5f2SPLrX: qUx6vZiKgs75 = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨክ")
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NeU6uRGpECkvMV5jf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬኮ"),qUx6vZiKgs75)
	return
def YUkzG2ymNSqdon(ZZT6GLaHQ1,xNlbPeJvSF=YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩ࠽࠳ࠬኯ")):
	return _EjwmP6n5ZIbGJDl7X84HiNFSTRaYe(ZZT6GLaHQ1,xNlbPeJvSF)
def ZRM4Lu0Oop3e(J1Fr6IsBcfhjQ):
	if J1Fr6IsBcfhjQ in [NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪ࠴ࠬኰ"),e8XhbyuzvjYkIsJUtB5w]: return NdKhAS6MXVEORLTwob92pxlZ
	J1Fr6IsBcfhjQ = int(J1Fr6IsBcfhjQ)
	uva8Tz9LtI0wkAV = J1Fr6IsBcfhjQ^OewIv05xGhKQpFf
	ttG9i2duQc = J1Fr6IsBcfhjQ^h1dnE0q2zFHjXlvyGuLZxw
	lqQ4xNyVgF689JOu7dwzItGb = J1Fr6IsBcfhjQ^NXpO8DrVmeE
	nV80a1XQzqi3wgcCrD = str(uva8Tz9LtI0wkAV)+str(ttG9i2duQc)+str(lqQ4xNyVgF689JOu7dwzItGb)
	return nV80a1XQzqi3wgcCrD
def Qrz6ULn21ofEyWGcTN4PKB(J1Fr6IsBcfhjQ):
	if J1Fr6IsBcfhjQ in [NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࠵࠭኱"),e8XhbyuzvjYkIsJUtB5w]: return NdKhAS6MXVEORLTwob92pxlZ
	J1Fr6IsBcfhjQ = str(J1Fr6IsBcfhjQ)
	nV80a1XQzqi3wgcCrD = NdKhAS6MXVEORLTwob92pxlZ
	if len(J1Fr6IsBcfhjQ)==wP4kpvXoDHq3hs7TFLyr2COn8(u"࠴࠹Ꮦ"):
		uva8Tz9LtI0wkAV,ttG9i2duQc,lqQ4xNyVgF689JOu7dwzItGb = J1Fr6IsBcfhjQ[e8XhbyuzvjYkIsJUtB5w:TQNS6YMKAqnilsVObLpDRX],J1Fr6IsBcfhjQ[TQNS6YMKAqnilsVObLpDRX:JGwsL21ZRlqSrWxEmF(u"࠽Ꮧ")],J1Fr6IsBcfhjQ[JGwsL21ZRlqSrWxEmF(u"࠽Ꮧ"):]
		uva8Tz9LtI0wkAV = int(uva8Tz9LtI0wkAV)^NXpO8DrVmeE
		ttG9i2duQc = int(ttG9i2duQc)^h1dnE0q2zFHjXlvyGuLZxw
		lqQ4xNyVgF689JOu7dwzItGb = int(lqQ4xNyVgF689JOu7dwzItGb)^OewIv05xGhKQpFf
		if uva8Tz9LtI0wkAV==ttG9i2duQc==lqQ4xNyVgF689JOu7dwzItGb: nV80a1XQzqi3wgcCrD = str(uva8Tz9LtI0wkAV*V0VZk9763fusTReHFo4(u"࠻࠶Ꮨ"))
	return nV80a1XQzqi3wgcCrD
def R4kMS9YE5Nby3giq(J1Fr6IsBcfhjQ,VAjzWLpX8FkGfBbnT24yhw=lrtFSogC8Nh9(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧኲ")):
	if J1Fr6IsBcfhjQ==NdKhAS6MXVEORLTwob92pxlZ: return NdKhAS6MXVEORLTwob92pxlZ
	J1Fr6IsBcfhjQ = int(J1Fr6IsBcfhjQ)+int(VAjzWLpX8FkGfBbnT24yhw)
	uva8Tz9LtI0wkAV = J1Fr6IsBcfhjQ^OewIv05xGhKQpFf
	ttG9i2duQc = J1Fr6IsBcfhjQ^h1dnE0q2zFHjXlvyGuLZxw
	lqQ4xNyVgF689JOu7dwzItGb = J1Fr6IsBcfhjQ^NXpO8DrVmeE
	nV80a1XQzqi3wgcCrD = str(uva8Tz9LtI0wkAV)+str(ttG9i2duQc)+str(lqQ4xNyVgF689JOu7dwzItGb)
	return nV80a1XQzqi3wgcCrD
def tSWniwpOkD(J1Fr6IsBcfhjQ,VAjzWLpX8FkGfBbnT24yhw=kb2icmDGVUZfW1OFz7sv(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨኳ")):
	if J1Fr6IsBcfhjQ==NdKhAS6MXVEORLTwob92pxlZ: return NdKhAS6MXVEORLTwob92pxlZ
	J1Fr6IsBcfhjQ = str(J1Fr6IsBcfhjQ)
	oyKXHTUM7ra = int(len(J1Fr6IsBcfhjQ)/uL69vJOU7xN0hGnZf2islDqk)
	uva8Tz9LtI0wkAV = int(J1Fr6IsBcfhjQ[e8XhbyuzvjYkIsJUtB5w:oyKXHTUM7ra])^OewIv05xGhKQpFf
	ttG9i2duQc = int(J1Fr6IsBcfhjQ[oyKXHTUM7ra:cCRvAuJQfjBpTg0PbYiaNO87*oyKXHTUM7ra])^h1dnE0q2zFHjXlvyGuLZxw
	lqQ4xNyVgF689JOu7dwzItGb = int(J1Fr6IsBcfhjQ[cCRvAuJQfjBpTg0PbYiaNO87*oyKXHTUM7ra:uL69vJOU7xN0hGnZf2islDqk*oyKXHTUM7ra])^NXpO8DrVmeE
	nV80a1XQzqi3wgcCrD = NdKhAS6MXVEORLTwob92pxlZ
	if uva8Tz9LtI0wkAV==ttG9i2duQc==lqQ4xNyVgF689JOu7dwzItGb: nV80a1XQzqi3wgcCrD = str(int(uva8Tz9LtI0wkAV)-int(VAjzWLpX8FkGfBbnT24yhw))
	return nV80a1XQzqi3wgcCrD
def XXaQrd76gFzMAPNGycuUHtK9pk(fmuMAVvP58kJ):
	hhrHZsQwKfa5cu7tVloM2eymDnGA6k = xKp3jkIvM09AZ4euXa87i5TVtfUD[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧኴ")][hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠾Ꮩ")]
	VuBDk6YoA7 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫኵ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡶ࡯࡮ࡴࡳࠨ኶"),Hlp3z0APt1GR4kMYK5xST(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ኷"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫ࠼࠸࠰ࡱࠩኸ"),kb2icmDGVUZfW1OFz7sv(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧኹ"))
	rK840PontS92Vg,STlBIyjUWg94Ek = TGNwJtqvjZCnUhHKEXoep8xBbk(VuBDk6YoA7)
	rK840PontS92Vg = R4kMS9YE5Nby3giq(rK840PontS92Vg,OOkmZiVcfqlEurM1dHGb(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩኺ"))
	svLTmtQBeHAyudpWfOP = {HVmIrFwau90jQsgiWzExk(u"ࠧࡪࡦࡶࠫኻ"):Hlp3z0APt1GR4kMYK5xST(u"ࠨࡆࡌࡅࡑࡕࡇࠨኼ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡸࡷࡷ࠭ኽ"):lop0ZwWYLmxOPAaErzF6cQvDkVR,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡺࡪࡸࠧኾ"):lvsJ2jaZktmNO6PbdXS,kb2icmDGVUZfW1OFz7sv(u"ࠫࡸࡩࡲࠨ኿"):fmuMAVvP58kJ,OOkmZiVcfqlEurM1dHGb(u"ࠬࡹࡩࡻࠩዀ"):rK840PontS92Vg}
	dRDczeSXg5miIpY7jyGF63ZnMfV = {hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ዁"):hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ዂ")}
	IIXNjOi2YHsBQK0JrgyxWz6TuLS = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,kb2icmDGVUZfW1OFz7sv(u"ࠨࡒࡒࡗ࡙࠭ዃ"),hhrHZsQwKfa5cu7tVloM2eymDnGA6k,svLTmtQBeHAyudpWfOP,dRDczeSXg5miIpY7jyGF63ZnMfV,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪዄ"))
	mmrBEpGiFNKnMuZcag9U2SIj = IIXNjOi2YHsBQK0JrgyxWz6TuLS.content
	try:
		if not mmrBEpGiFNKnMuZcag9U2SIj: HLzgEPx0uY4ZtXGNVAriDRbBdC31
		AUth8odcDVMLN3WR5HKSe = BdnA8WwtJeKUVvE(kb2icmDGVUZfW1OFz7sv(u"ࠪࡨ࡮ࡩࡴࠨዅ"),mmrBEpGiFNKnMuZcag9U2SIj)
		lEC9PYbh6ZGVM047emAURHn = AUth8odcDVMLN3WR5HKSe[HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡲࡹࡧࠨ዆")]
		cbCI6XKl3kUNi = AUth8odcDVMLN3WR5HKSe[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡹࡥࡤࠩ዇")]
		Sy6u32KlYMZFe5AT4DC7kbdVrn9U = AUth8odcDVMLN3WR5HKSe[HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡳࡵࡲࠪወ")]
		cbCI6XKl3kUNi = int(tSWniwpOkD(cbCI6XKl3kUNi,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪዉ")))
		Sy6u32KlYMZFe5AT4DC7kbdVrn9U = int(tSWniwpOkD(Sy6u32KlYMZFe5AT4DC7kbdVrn9U,lNTJCZeBicWEz0Mg(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫዊ")))
		for CerDt5g7KqvRIuQSM9F in range(cbCI6XKl3kUNi,e8XhbyuzvjYkIsJUtB5w,-Sy6u32KlYMZFe5AT4DC7kbdVrn9U):
			if not eval(V0VZk9763fusTReHFo4(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧዋ"),{HVmIrFwau90jQsgiWzExk(u"ࠪࡼࡧࡳࡣࠨዌ"):ACOWB6GRmIbDKyl3Zn}): HLzgEPx0uY4ZtXGNVAriDRbBdC31
			kkDz5sdaPteM(lNTJCZeBicWEz0Mg(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪው"),str(CerDt5g7KqvRIuQSM9F)+QQHFtjcaR2VpnSyTIv(u"ࠬࠦࠠฬษ้๎ฮ࠭ዎ"),XJ62UBRmIqFvfiNTQj=hCm2fnEXs6Zt(u"࠳࠱࠲Ꮪ")*Sy6u32KlYMZFe5AT4DC7kbdVrn9U)
			ACOWB6GRmIbDKyl3Zn.sleep(Tzx81Wb0RZC4ID5AyiU2(u"࠲࠲࠳࠴Ꮫ")*Sy6u32KlYMZFe5AT4DC7kbdVrn9U)
		if eval(HVmIrFwau90jQsgiWzExk(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫዏ"),{NeU6uRGpECkvMV5jf(u"ࠧࡹࡤࡰࡧࠬዐ"):ACOWB6GRmIbDKyl3Zn}):
			lEC9PYbh6ZGVM047emAURHn = lEC9PYbh6ZGVM047emAURHn.replace(B6IrC7zEHlw1oaeWf,Hlp3z0APt1GR4kMYK5xST(u"ࠨ࡞࡟ࡲࠬዑ")).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,rNyT0edugn(u"ࠩ࡟ࡠࡷ࠭ዒ"))
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠪาึ๎ฬࠨዓ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧዔ"),lEC9PYbh6ZGVM047emAURHn)
		HLzgEPx0uY4ZtXGNVAriDRbBdC31
	except: exec(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬዕ"),{Hlp3z0APt1GR4kMYK5xST(u"࠭ࡸࡣ࡯ࡦࠫዖ"):ACOWB6GRmIbDKyl3Zn})
	return
def FVab3jTRmkLU8e():
	exec(JGwsL21ZRlqSrWxEmF(u"ࠧࠨࠩࠐࠎࡹࡸࡹ࠻ࠏࠍࠍࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱࡛࡮ࡴࡤࡰࡹࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠐࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡸࡲࡥࡦࡲࠫ࠵࠵࠶࠰ࠪࠏࠍࠍࠎࡺࡲࡺ࠼ࠣࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸࠴ࡧࡦࡶࡉࡳࡨࡻࡳࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡨࡲࡦࡣ࡮ࠑࠏࠏࡺࡤࡴࡨࡥࡹ࡫࡟ࡦࡴࡲࡶࡷࠓࠊࡦࡺࡦࡩࡵࡺ࠺ࠡࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠎࠌࠪࠫࠬ዗"),{xY4icgQUj6mPVs73CTKu(u"ࠨࡺࡥࡱࡨ࡭ࡵࡪࠩዘ"):JTIdpcz98k7RyxHOX5EnqD6L1vKe04,HVmIrFwau90jQsgiWzExk(u"ࠩࡻࡦࡲࡩࠧዙ"):ACOWB6GRmIbDKyl3Zn})
	return
def TGNwJtqvjZCnUhHKEXoep8xBbk(u45yDBATUY9C30mGEX1HS):
	LsdBE8ni6CvZQ2FU74KJY,ZZiHOu2GRo5SrgImeL34 = e8XhbyuzvjYkIsJUtB5w,e8XhbyuzvjYkIsJUtB5w
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(u45yDBATUY9C30mGEX1HS):
		try: LsdBE8ni6CvZQ2FU74KJY = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.getsize(u45yDBATUY9C30mGEX1HS)
		except: pass
		if not LsdBE8ni6CvZQ2FU74KJY:
			try: LsdBE8ni6CvZQ2FU74KJY = IIPNcsCvQnOZk0yejJKl4BtgSrMw.stat(u45yDBATUY9C30mGEX1HS).st_size
			except: pass
		if not LsdBE8ni6CvZQ2FU74KJY:
			try:
				from pathlib import Path as dm8WbT4SY2CvGohxBs06L7l
				LsdBE8ni6CvZQ2FU74KJY = dm8WbT4SY2CvGohxBs06L7l(u45yDBATUY9C30mGEX1HS).stat().st_size
			except: pass
		if LsdBE8ni6CvZQ2FU74KJY: ZZiHOu2GRo5SrgImeL34 = llxMLe4gobHhsj1WGvd7qmIU
	return LsdBE8ni6CvZQ2FU74KJY,ZZiHOu2GRo5SrgImeL34
def zsPdJ2UtW7DZVFe04lAYbgjyqCR1(v3H5sVg8LnRkf,showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ዚ"),v3H5sVg8LnRkf+HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡡࡴ࡜࡯ࠩዛ")+Whef0cxB2iR93SC5IwUtk+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩዜ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠳Ꮬ"): return
	a3XNg6O7dGUIDxTqtFSkM4Q89l5BYK = f4vncKMRlXG9s
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(v3H5sVg8LnRkf):
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(v3H5sVg8LnRkf.decode(YRvPKe2zMTDs8UCkr))
		except:
			try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(dqGMI6aLpn5sz)
			except Exception as A6w7jOmcXhpV8FoWy9tHNMkb:
				if showDialogs: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩዝ"),str(A6w7jOmcXhpV8FoWy9tHNMkb))
				a3XNg6O7dGUIDxTqtFSkM4Q89l5BYK = k6apiPAlLKM1ed8J42RjHh0o
	if showDialogs:
		if a3XNg6O7dGUIDxTqtFSkM4Q89l5BYK: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪዞ"),V0VZk9763fusTReHFo4(u"ࠨใื่ฯูࠦๆๆํอ๋ࠥำฮࠢส่๊๊แࠨዟ"))
		else:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬዠ"),lRP6GTaZJA1Xw3egLM4(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫዡ"))
			MIjcStaDWnv(f4vncKMRlXG9s)
	return
def vWN2YePRikAXEFO6dQ8CT51bz(BJhHT1lSQ5FoP9NkEMrWR2qpu,YYWr7cq1b5Hdhis,showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧዢ"),BJhHT1lSQ5FoP9NkEMrWR2qpu+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡢ࡮࡝ࡰࠪዣ")+Whef0cxB2iR93SC5IwUtk+NOrchaEV1iIZ87Uzlwgum(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤࠫዤ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=llxMLe4gobHhsj1WGvd7qmIU: return
	XvUfhH2qm6TMaw5bl9WVO1B = f4vncKMRlXG9s
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(BJhHT1lSQ5FoP9NkEMrWR2qpu):
		for ssLYlthgeuX1Zwc2a,UEy3lpL0bKROhvu,tm1yhwbq8vSjXE6dnYk0P in IIPNcsCvQnOZk0yejJKl4BtgSrMw.walk(BJhHT1lSQ5FoP9NkEMrWR2qpu,topdown=f4vncKMRlXG9s):
			for u45yDBATUY9C30mGEX1HS in tm1yhwbq8vSjXE6dnYk0P:
				yx95vDYhicREUC62QgW = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ssLYlthgeuX1Zwc2a,u45yDBATUY9C30mGEX1HS)
				try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(yx95vDYhicREUC62QgW)
				except Exception as BBNRYIkquhmv2w5GasF:
					if showDialogs and not XvUfhH2qm6TMaw5bl9WVO1B: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪዥ"),str(BBNRYIkquhmv2w5GasF))
					XvUfhH2qm6TMaw5bl9WVO1B = k6apiPAlLKM1ed8J42RjHh0o
			if YYWr7cq1b5Hdhis:
				for dir in UEy3lpL0bKROhvu:
					BzW2ZRf5bqVsM = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ssLYlthgeuX1Zwc2a,dir)
					try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.rmdir(BzW2ZRf5bqVsM)
					except: pass
		if YYWr7cq1b5Hdhis:
			try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.rmdir(ssLYlthgeuX1Zwc2a)
			except: pass
	if showDialogs and not XvUfhH2qm6TMaw5bl9WVO1B:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫዦ"),HVmIrFwau90jQsgiWzExk(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪዧ"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def MKsaBZtpJ9uR2D(CSHxmGj6O01AWEXVoRcK,fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI):
	BfjcMoqOsmdUvZVCHWIyQKi,ekC5B0cLVoOYiQJbKv43sTMWXtn,gWPvSYDsxc,thQS25UGHN9I0ywmbvWM4gCrOVp = ubz0qK9aRUNEQj6HrvF2OpCGLS47(ZZT6GLaHQ1)
	KiBecyPA5WSGXCQu38h1F4n = fiuheaxH14ZML0,BfjcMoqOsmdUvZVCHWIyQKi,dJC476xoE1ecpm0,JoWX5If80G
	if CSHxmGj6O01AWEXVoRcK<R3lezw8h407ZvrAFxT(u"࠳Ꮭ"):
		WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫየ"),KiBecyPA5WSGXCQu38h1F4n)
		CSHxmGj6O01AWEXVoRcK = -CSHxmGj6O01AWEXVoRcK
	if CSHxmGj6O01AWEXVoRcK>gniNItGL6bKwpEW(u"࠴Ꮮ"):
		tWcXU498FSdjKl2Iw7M = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,QQHFtjcaR2VpnSyTIv(u"ࠫࡸࡺࡲࠨዩ"),fOc18oTm5hsdD4pVZQj(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ዪ"),KiBecyPA5WSGXCQu38h1F4n)
		if tWcXU498FSdjKl2Iw7M:
			hhM2Wn1045PDsl6p8VLA7vIN(Hlp3z0APt1GR4kMYK5xST(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫያ"),ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI,fiuheaxH14ZML0)
			return tWcXU498FSdjKl2Iw7M
	tWcXU498FSdjKl2Iw7M = KJz9WRbX2g0LeCD(fiuheaxH14ZML0,ZZT6GLaHQ1,dJC476xoE1ecpm0,JoWX5If80G,xmezOWMyhSXRGHlEk2JnsI)
	if tWcXU498FSdjKl2Iw7M and CSHxmGj6O01AWEXVoRcK: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,OOkmZiVcfqlEurM1dHGb(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨዬ"),KiBecyPA5WSGXCQu38h1F4n,tWcXU498FSdjKl2Iw7M,CSHxmGj6O01AWEXVoRcK)
	return tWcXU498FSdjKl2Iw7M
def bkqNe6d9GKctQ(yNIDEX5hU4G769,MM3jlypOEut8vzd,xSZrUKCsi5oal6T9RbhAJdOvWe=e8XhbyuzvjYkIsJUtB5w):
	RYGSxoeX2M6Vr5Jkj0Wnp4alOU = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬይ"))
	if RYGSxoeX2M6Vr5Jkj0Wnp4alOU and kb2icmDGVUZfW1OFz7sv(u"ࠩ࠰ࠫዮ") not in RYGSxoeX2M6Vr5Jkj0Wnp4alOU: ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB,kkdfXIRj7Vo2aDhMnJUHgueci0qP = int(RYGSxoeX2M6Vr5Jkj0Wnp4alOU),k6apiPAlLKM1ed8J42RjHh0o
	elif xSZrUKCsi5oal6T9RbhAJdOvWe: ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB,kkdfXIRj7Vo2aDhMnJUHgueci0qP = xSZrUKCsi5oal6T9RbhAJdOvWe,f4vncKMRlXG9s
	else: return []
	yg2cN3viaqXRtC9lBS5KVh8bm,Fw9AK1mqcgv45T = [],NdKhAS6MXVEORLTwob92pxlZ
	PmANnXlkGxc4w,GAfXvb2wcFoImdrNaP4V,ZgvBUf0TS3H5ey1Fm,h4uSR2ysZL7t0plWP = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,e8XhbyuzvjYkIsJUtB5w,e8XhbyuzvjYkIsJUtB5w
	MM3jlypOEut8vzd = sorted(MM3jlypOEut8vzd,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: (key[llxMLe4gobHhsj1WGvd7qmIU],key[cCRvAuJQfjBpTg0PbYiaNO87]))
	for stream,A0KmCsTOIn6hHNpFjP,rFSUYwTohtsByX4HJ0qElMD8nuk in MM3jlypOEut8vzd+[[NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,e8XhbyuzvjYkIsJUtB5w]]:
		if A0KmCsTOIn6hHNpFjP==Fw9AK1mqcgv45T:
			if rFSUYwTohtsByX4HJ0qElMD8nuk>ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB: GAfXvb2wcFoImdrNaP4V,h4uSR2ysZL7t0plWP = stream,rFSUYwTohtsByX4HJ0qElMD8nuk
			elif not PmANnXlkGxc4w: PmANnXlkGxc4w,ZgvBUf0TS3H5ey1Fm = stream,rFSUYwTohtsByX4HJ0qElMD8nuk
		else:
			if GAfXvb2wcFoImdrNaP4V or PmANnXlkGxc4w:
				if PmANnXlkGxc4w: yg2cN3viaqXRtC9lBS5KVh8bm.append([PmANnXlkGxc4w,Fw9AK1mqcgv45T,ZgvBUf0TS3H5ey1Fm])
				elif GAfXvb2wcFoImdrNaP4V: yg2cN3viaqXRtC9lBS5KVh8bm.append([GAfXvb2wcFoImdrNaP4V,Fw9AK1mqcgv45T,h4uSR2ysZL7t0plWP])
			if rFSUYwTohtsByX4HJ0qElMD8nuk>ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB:
				GAfXvb2wcFoImdrNaP4V,h4uSR2ysZL7t0plWP = stream,rFSUYwTohtsByX4HJ0qElMD8nuk
				PmANnXlkGxc4w,ZgvBUf0TS3H5ey1Fm = NdKhAS6MXVEORLTwob92pxlZ,e8XhbyuzvjYkIsJUtB5w
			else:
				GAfXvb2wcFoImdrNaP4V,h4uSR2ysZL7t0plWP = NdKhAS6MXVEORLTwob92pxlZ,e8XhbyuzvjYkIsJUtB5w
				PmANnXlkGxc4w,ZgvBUf0TS3H5ey1Fm = stream,rFSUYwTohtsByX4HJ0qElMD8nuk
		Fw9AK1mqcgv45T = A0KmCsTOIn6hHNpFjP
	if kkdfXIRj7Vo2aDhMnJUHgueci0qP:
		qNaus6jMOU5R49hogzTDLGW0Pp3A,dTDEx6AGogWCXyiJUIq3L40,gV7U4r1eiWb6thNEdHaxYMnRoQmP = zip(*yg2cN3viaqXRtC9lBS5KVh8bm)
		AAmKCucoLeVxEfNrZz1Qb2aIMDlpdO = [pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡱࡵ࠺ࠧዯ"),NOrchaEV1iIZ87Uzlwgum(u"ࠫࡲࡶࡤࠨደ"),OOkmZiVcfqlEurM1dHGb(u"ࠬࡺࡳࠨዱ"),NOrchaEV1iIZ87Uzlwgum(u"࠭࡭࠴ࡷࠪዲ")]
		for A0KmCsTOIn6hHNpFjP in AAmKCucoLeVxEfNrZz1Qb2aIMDlpdO:
			if A0KmCsTOIn6hHNpFjP in dTDEx6AGogWCXyiJUIq3L40:
				index = dTDEx6AGogWCXyiJUIq3L40.index(A0KmCsTOIn6hHNpFjP)
				yg2cN3viaqXRtC9lBS5KVh8bm = [[qNaus6jMOU5R49hogzTDLGW0Pp3A[index],dTDEx6AGogWCXyiJUIq3L40[index],gV7U4r1eiWb6thNEdHaxYMnRoQmP[index]]]
				break
	return yg2cN3viaqXRtC9lBS5KVh8bm
def uUa9cvTpySOLm2l(jXyoTFQzm6nYrabVHN8kg2vdR):
	llqoVr0WsTpyPx2duLz9OweifjRtK,oamxuyOJX7U1 = [],None
	for mAH4aPy8q1w in JuMxp2dLcDy6bj037awTvNIZ:
		if mAH4aPy8q1w==QQHFtjcaR2VpnSyTIv(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨዳ"): oamxuyOJX7U1 = (hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࡮࡬ࡲࡰ࠭ዴ"),Whef0cxB2iR93SC5IwUtk+QQHFtjcaR2VpnSyTIv(u"่ࠩ์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅࠩድ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"࠶࠻࠷Ꮯ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
		elif mAH4aPy8q1w==lRP6GTaZJA1Xw3egLM4(u"ࠪࡑࡎ࡞ࡅࡅࠩዶ"): oamxuyOJX7U1 = (rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡱ࡯࡮࡬ࠩዷ"),Whef0cxB2iR93SC5IwUtk+fOc18oTm5hsdD4pVZQj(u"๋่ࠬศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็ࠫዸ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠷࠵࠸Ꮰ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
		elif mAH4aPy8q1w==JGwsL21ZRlqSrWxEmF(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ዹ"): oamxuyOJX7U1 = (lNTJCZeBicWEz0Mg(u"ࠧ࡭࡫ࡱ࡯ࠬዺ"),Whef0cxB2iR93SC5IwUtk+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨ็๋ห็฿ࠠิ์ิๅึอสࠡ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไࠨዻ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"࠱࠶࠹Ꮱ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
		if mAH4aPy8q1w not in jXyoTFQzm6nYrabVHN8kg2vdR: continue
		if oamxuyOJX7U1:
			llqoVr0WsTpyPx2duLz9OweifjRtK.append(oamxuyOJX7U1)
			oamxuyOJX7U1 = None
		if mAH4aPy8q1w not in [NeU6uRGpECkvMV5jf(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪዼ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡑࡎ࡞ࡅࡅࠩዽ"),lrtFSogC8Nh9(u"ࠫࡕ࡛ࡂࡍࡋࡆࠫዾ")]: llqoVr0WsTpyPx2duLz9OweifjRtK.append(mAH4aPy8q1w)
	return llqoVr0WsTpyPx2duLz9OweifjRtK
def sPtRDbJGVcMg3hIznEr7yOvYH4l(MeJwHj8QArDUlxzqPmyThYp,args=[]):
	dRDczeSXg5miIpY7jyGF63ZnMfV = {pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫዿ"):rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩጀ")}
	RN8ftezPBL4Dk3s,RrN36nPBbk08lTQg,vQTBO8yazKJe4d1CZDRo = HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡷࡥࡥࡧ࠻࠻࠳࠵࠸ࡪࡪ࡭ࡨ࡮ࡺ࡯ࡸ࡮ࡰ࠭ጁ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠶࠶ࡺࡨࡼ࠳ࡥࡨࡪ࡮ࡰࡵ࠷࠹ࡵࡻࡾࡩ࠸ࠧጂ"),int(XJ62UBRmIqFvfiNTQj.time())
	rkvERUdWXuhG = RN8ftezPBL4Dk3s+gVXbksjWZ2Y3por5yQd8wCufUzMm7T+str(vQTBO8yazKJe4d1CZDRo)+lvsJ2jaZktmNO6PbdXS+RrN36nPBbk08lTQg
	NhZuHrpLxyqnSIjGs4VFiW3MXk65 = f6ZTNntQrRHd.md5(rkvERUdWXuhG.encode(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡸࡸ࡫࠾ࠧጃ"))).hexdigest()[:QQHFtjcaR2VpnSyTIv(u"࠴࠴Ꮲ")]
	svLTmtQBeHAyudpWfOP = {Tzx81Wb0RZC4ID5AyiU2(u"ࠪ࡮ࡸࡩ࡯ࡥࡧࠪጄ"):MeJwHj8QArDUlxzqPmyThYp,V0VZk9763fusTReHFo4(u"ࠫࡦࡸࡧࡴࠩጅ"):args,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡻࡳࡦࡴࠪጆ"):gVXbksjWZ2Y3por5yQd8wCufUzMm7T,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧጇ"):lvsJ2jaZktmNO6PbdXS,kb2icmDGVUZfW1OFz7sv(u"ࠧࡪࡦࡶࠫገ"):NhZuHrpLxyqnSIjGs4VFiW3MXk65}
	svLTmtQBeHAyudpWfOP = O3OogF1l5reuQ.dumps(svLTmtQBeHAyudpWfOP)
	N9Rr1uY7bpnw6sIxafGU5BkSejKm = xKp3jkIvM09AZ4euXa87i5TVtfUD[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨጉ")][V0VZk9763fusTReHFo4(u"࠳࠳Ꮳ")]
	IIXNjOi2YHsBQK0JrgyxWz6TuLS = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,lNTJCZeBicWEz0Mg(u"ࠩࡓࡓࡘ࡚ࠧጊ"),N9Rr1uY7bpnw6sIxafGU5BkSejKm,svLTmtQBeHAyudpWfOP,dRDczeSXg5miIpY7jyGF63ZnMfV,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡅࡄࡗࡗࡉࡤࡐࡓ࠮࠳ࡶࡸࠬጋ"))
	mmrBEpGiFNKnMuZcag9U2SIj = IIXNjOi2YHsBQK0JrgyxWz6TuLS.content
	return mmrBEpGiFNKnMuZcag9U2SIj
from hrjbtDZLXS import *
# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ALFATIMI'
LJfTAEQPv9h4BXdwUp = '_FTM_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
m6UReHPXT3Mu5 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
nKxDiJGPckm8Vhwyr = ['3030','628']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==60: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==61: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==62: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==63: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==64: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = BBQbvtLcTxDrRas(text)
	elif mode==69: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,69,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'ما يتم مشاهدته الان',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,64,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'recent_viewed_vids')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الاكثر مشاهدة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,64,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'most_viewed_vids')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'اضيفت مؤخرا',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,64,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'recently_added_vids')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'فيديو عشوائي',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,64,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'random_vids')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'افلام ومسلسلات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,61,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'-1')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'البرامج الدينية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,61,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'-2')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'English Videos',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,61,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'-3')
	return NdKhAS6MXVEORLTwob92pxlZ
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,II4s1CdgcbN6BSvWPnHtz):
	kvB1AdWwKOg3XJVquF = NdKhAS6MXVEORLTwob92pxlZ
	if II4s1CdgcbN6BSvWPnHtz not in ['-1','-2','-3']: kvB1AdWwKOg3XJVquF = '?cat='+II4s1CdgcbN6BSvWPnHtz
	BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/menu_level.php'+kvB1AdWwKOg3XJVquF
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ALFATIMI-TITLES-1st')
	items = YYqECUofyi7wFrW.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	DbgjFwHnOIfLBeToCa8r2Q,NElpa837fkWBKeqY = False,False
	for zehVcU893FC6LEd1Aij,title,count in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
		kvB1AdWwKOg3XJVquF = YYqECUofyi7wFrW.findall('cat=(.*?)&',zehVcU893FC6LEd1Aij,YYqECUofyi7wFrW.DOTALL)[0]
		if II4s1CdgcbN6BSvWPnHtz==kvB1AdWwKOg3XJVquF: DbgjFwHnOIfLBeToCa8r2Q = True
		elif DbgjFwHnOIfLBeToCa8r2Q 	or (II4s1CdgcbN6BSvWPnHtz=='-1' and kvB1AdWwKOg3XJVquF in m6UReHPXT3Mu5)  						or (II4s1CdgcbN6BSvWPnHtz=='-2' and kvB1AdWwKOg3XJVquF not in nKxDiJGPckm8Vhwyr and kvB1AdWwKOg3XJVquF not in m6UReHPXT3Mu5)  						or (II4s1CdgcbN6BSvWPnHtz=='-3' and kvB1AdWwKOg3XJVquF in nKxDiJGPckm8Vhwyr):
							if count=='1': ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,63)
							else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,61,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kvB1AdWwKOg3XJVquF)
							NElpa837fkWBKeqY = True
	if not NElpa837fkWBKeqY: vl57jIYC4a(url)
	return
def vl57jIYC4a(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALFATIMI-EPISODES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination(.*?)id="footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zehVcU893FC6LEd1Aij = NdKhAS6MXVEORLTwob92pxlZ
	for TTuPH708dUNnjlG3oQpkZsi,title,zehVcU893FC6LEd1Aij in items:
		title = title.replace('Add',NdKhAS6MXVEORLTwob92pxlZ).replace('to Quicklist',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,63,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('(.*?)div',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W=bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	AAMHoYxRCmt2D6ph89W=YYqECUofyi7wFrW.findall('pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	items=YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = url.split('?')[0]
	for zehVcU893FC6LEd1Aij,P3BtEb8xUT7MCi in items:
		zehVcU893FC6LEd1Aij = BfjcMoqOsmdUvZVCHWIyQKi + zehVcU893FC6LEd1Aij
		title = Pr4ubLdO7Z1qjKFaMIy3H(P3BtEb8xUT7MCi)
		title = 'صفحة ' + title
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,62)
	return zehVcU893FC6LEd1Aij
def uuvhoSanB2TWD(url):
	if 'videos.php' in url: url = vl57jIYC4a(url)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,'ALFATIMI-PLAY-1st')
	items = YYqECUofyi7wFrW.findall('playlistfile:"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(url,yNIDEX5hU4G769,'video')
	return
def BBQbvtLcTxDrRas(II4s1CdgcbN6BSvWPnHtz):
	YWsjNtDXPAgCya = { 'mode' : II4s1CdgcbN6BSvWPnHtz }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = g1Vmb5T39C(YWsjNtDXPAgCya)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = 'http:'+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,63,TTuPH708dUNnjlG3oQpkZsi)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/search_result.php?query=' + n5pZARB2X0x8abLPeywMuHkqV
	vl57jIYC4a(url)
	return
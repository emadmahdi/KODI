# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
yNIDEX5hU4G769 = 'AKOAM'
LJfTAEQPv9h4BXdwUp = '_AKO_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
XVvbIje9CntM0rKRNP1iDFdJq = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==70: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==71: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = VebtvXQp8SCg52Jkxmi4OoqK(url)
	elif mode==72: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==73: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = aaj6M2ZThKAvFJs8UbCf39GqLgOH(url)
	elif mode==74: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==79: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,79,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'سلسلة افلام',NdKhAS6MXVEORLTwob92pxlZ,79,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'سلسلة افلام')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'سلاسل منوعة',NdKhAS6MXVEORLTwob92pxlZ,79,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'سلسلة')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Kdr54yMqbjTSX7piWREfPtZ2em = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKOAM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="partions"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,71)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def VebtvXQp8SCg52Jkxmi4OoqK(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKOAM-CATEGORIES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('sect_parts(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,72)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'جميع الفروع',url,72)
	else: hGJKk8tAiC3XFufEpqavQWmwTHdL(url,NdKhAS6MXVEORLTwob92pxlZ)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('section_title featured_title(.*?)subjects-crousel',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='search':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('akoam_result(.*?)<script',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='more':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('section_title more_title(.*?)footer_bottom_services',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('navigation(.*?)<script',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not items and bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in XVvbIje9CntM0rKRNP1iDFdJq): ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,73,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,73,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pagination"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall("</li><li >.*?href='(.*?)'>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,72,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,type)
	return
def uomTexROFz(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAM-SECTIONS-2nd')
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('"href","(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[1]
	return BfjcMoqOsmdUvZVCHWIyQKi
def aaj6M2ZThKAvFJs8UbCf39GqLgOH(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKOAM-SECTIONS-1st')
	qd8EOGsINrnkVe4SHU = YYqECUofyi7wFrW.findall('"(https*://akwam.net/\w+.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	XMh38aowpbWSDfujk1i = YYqECUofyi7wFrW.findall('"(https*://underurl.com/\w+.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if qd8EOGsINrnkVe4SHU or XMh38aowpbWSDfujk1i:
		if qd8EOGsINrnkVe4SHU: Afey3cL4ojzg = qd8EOGsINrnkVe4SHU[0]
		elif XMh38aowpbWSDfujk1i: Afey3cL4ojzg = uomTexROFz(XMh38aowpbWSDfujk1i[0])
		Afey3cL4ojzg = OOFEmwq2GkTz93WXy1Nj(Afey3cL4ojzg)
		import dKusGQWL0z
		if '/series/' in Afey3cL4ojzg or '/shows/' in Afey3cL4ojzg: dKusGQWL0z.vl57jIYC4a(Afey3cL4ojzg)
		else: dKusGQWL0z.uuvhoSanB2TWD(Afey3cL4ojzg)
		return
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	items = YYqECUofyi7wFrW.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,73)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		kkDz5sdaPteM('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,TTuPH708dUNnjlG3oQpkZsi,AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if 'sub_epsiode_title' in AAMHoYxRCmt2D6ph89W:
		items = YYqECUofyi7wFrW.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	else:
		jItLlSeMrE9wOqks675BaV0xHP = YYqECUofyi7wFrW.findall('sub_file_title\'>(.*?) - <i>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		items = []
		for filename in jItLlSeMrE9wOqks675BaV0xHP:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',NdKhAS6MXVEORLTwob92pxlZ) ]
	count = 0
	IGEpKNCaiLMT,rhqUmV4b8fEwDAng = [],[]
	size = len(items)
	for title,filename in items:
		uJqZbeXK04CRjoQ = NdKhAS6MXVEORLTwob92pxlZ
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: uJqZbeXK04CRjoQ = filename.split('.')[-1]
		title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		IGEpKNCaiLMT.append(title)
		rhqUmV4b8fEwDAng.append(count)
		count += 1
	if size>0:
		if any(K6KbZDHncNizQgl1fr59XV0 in name for K6KbZDHncNizQgl1fr59XV0 in XVvbIje9CntM0rKRNP1iDFdJq):
			if size==1:
				rRfpvbZojlygET5JL87wdzIPGe = 0
			else:
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر الفيديو المناسب:', IGEpKNCaiLMT)
				if rRfpvbZojlygET5JL87wdzIPGe == -1: return
			uuvhoSanB2TWD(url+'?section='+str(1+rhqUmV4b8fEwDAng[size-rRfpvbZojlygET5JL87wdzIPGe-1]))
		else:
			for xX6zt5oS08TO29CUhYJa1K in reversed(range(size)):
				title = name + ' - ' + IGEpKNCaiLMT[xX6zt5oS08TO29CUhYJa1K]
				title = title.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				zehVcU893FC6LEd1Aij = url + '?section='+str(size-xX6zt5oS08TO29CUhYJa1K)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,74,TTuPH708dUNnjlG3oQpkZsi)
	else:
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+'الرابط ليس فيديو',NdKhAS6MXVEORLTwob92pxlZ,9999,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	BfjcMoqOsmdUvZVCHWIyQKi,N1VjdbtuO3z = url.split('?section=')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,True,NdKhAS6MXVEORLTwob92pxlZ,'AKOAM-PLAY_AKOAM-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	iQtFuKnHTd5sAeY018qOJc = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	iQtFuKnHTd5sAeY018qOJc = iQtFuKnHTd5sAeY018qOJc + 'direct_link_box'
	sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('epsoide_box(.*?)direct_link_box',iQtFuKnHTd5sAeY018qOJc,YYqECUofyi7wFrW.DOTALL)
	N1VjdbtuO3z = len(sCRbZp6Irl17v)-int(N1VjdbtuO3z)
	AAMHoYxRCmt2D6ph89W = sCRbZp6Irl17v[N1VjdbtuO3z]
	Pj8lY4doOfxiFMuNLhv3tnp = []
	eClPqfsXn4T7boGvu53cOILZU = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = YYqECUofyi7wFrW.findall("class='download_btn.*?href='(.*?)'",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij in items:
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named=________akoam')
	items = YYqECUofyi7wFrW.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for vj12AhN30WoZbq8pKQsGixDFt5U,zehVcU893FC6LEd1Aij in items:
		vj12AhN30WoZbq8pKQsGixDFt5U = vj12AhN30WoZbq8pKQsGixDFt5U.split('/')[-1]
		vj12AhN30WoZbq8pKQsGixDFt5U = vj12AhN30WoZbq8pKQsGixDFt5U.split('.')[0]
		if vj12AhN30WoZbq8pKQsGixDFt5U in eClPqfsXn4T7boGvu53cOILZU:
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+eClPqfsXn4T7boGvu53cOILZU[vj12AhN30WoZbq8pKQsGixDFt5U]+'________akoam')
		else: Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+vj12AhN30WoZbq8pKQsGixDFt5U+'________akoam')
	if not Pj8lY4doOfxiFMuNLhv3tnp:
		message = YYqECUofyi7wFrW.findall('sub-no-file.*?\n(.*?)\n',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if message: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من الموقع الاصلي',message[0])
	else:
		import ttrmdIqhPY
		ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/search/'+n5pZARB2X0x8abLPeywMuHkqV
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
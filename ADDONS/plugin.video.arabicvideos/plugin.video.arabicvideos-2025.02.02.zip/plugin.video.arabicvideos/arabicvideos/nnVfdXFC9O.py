# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'LIVETV'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD['PYTHON'][0]
def QGLoruqnmiAel7Op(mode,url):
	if   mode==100: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==101: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Hn70PSCVdsEvRXKz('0',True)
	elif mode==102: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Hn70PSCVdsEvRXKz('1',True)
	elif mode==103: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Hn70PSCVdsEvRXKz('2',True)
	elif mode==104: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Hn70PSCVdsEvRXKz('3',True)
	elif mode==105: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==106: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Hn70PSCVdsEvRXKz('4',True)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder','_M3U_'+'قوائم فيديوهات M3U',NdKhAS6MXVEORLTwob92pxlZ,762)
	ZI51XvE8YatWCmNdrp('folder','_IPT_'+'قوائم فيديوهات IPTV',NdKhAS6MXVEORLTwob92pxlZ,761)
	ZI51XvE8YatWCmNdrp('folder','_TV0_'+'قنوات من مواقعها الأصلية',NdKhAS6MXVEORLTwob92pxlZ,101)
	ZI51XvE8YatWCmNdrp('folder','_TV4_'+'قنوات مختارة من يوتيوب',NdKhAS6MXVEORLTwob92pxlZ,106)
	ZI51XvE8YatWCmNdrp('folder','_YUT_'+'قنوات عربية من يوتيوب',NdKhAS6MXVEORLTwob92pxlZ,147)
	ZI51XvE8YatWCmNdrp('folder','_YUT_'+'قنوات أجنبية من يوتيوب',NdKhAS6MXVEORLTwob92pxlZ,148)
	ZI51XvE8YatWCmNdrp('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',NdKhAS6MXVEORLTwob92pxlZ,28)
	ZI51XvE8YatWCmNdrp('live','_MRF_'+'قناة المعارف من موقعهم',NdKhAS6MXVEORLTwob92pxlZ,41)
	ZI51XvE8YatWCmNdrp('live','_PNT_'+'قناة هلا من موقع بانيت',NdKhAS6MXVEORLTwob92pxlZ,38)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder','_TV1_'+'قنوات تلفزيونية عامة',NdKhAS6MXVEORLTwob92pxlZ,102)
	ZI51XvE8YatWCmNdrp('folder','_TV2_'+'قنوات تلفزيونية خاصة',NdKhAS6MXVEORLTwob92pxlZ,103)
	ZI51XvE8YatWCmNdrp('folder','_TV3_'+'قنوات تلفزيونية للفحص',NdKhAS6MXVEORLTwob92pxlZ,104)
	return
def Hn70PSCVdsEvRXKz(yzApRd2Dnes07XUZTM,showDialogs=True):
	LJfTAEQPv9h4BXdwUp = '_TV'+yzApRd2Dnes07XUZTM+'_'
	YWsjNtDXPAgCya = {'id':NdKhAS6MXVEORLTwob92pxlZ,'user':lop0ZwWYLmxOPAaErzF6cQvDkVR,'function':'list','menu':yzApRd2Dnes07XUZTM}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-ITEMS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = YYqECUofyi7wFrW.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		for xX6zt5oS08TO29CUhYJa1K in range(len(items)):
			name = items[xX6zt5oS08TO29CUhYJa1K][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[xX6zt5oS08TO29CUhYJa1K] = items[xX6zt5oS08TO29CUhYJa1K][0],items[xX6zt5oS08TO29CUhYJa1K][1],items[xX6zt5oS08TO29CUhYJa1K][2],name,items[xX6zt5oS08TO29CUhYJa1K][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for xmezOWMyhSXRGHlEk2JnsI,oikt6P0hOAD5IvnlMpxf1,f1BA08uJ2nePQcdCHRqNEZKoGM,name,TTuPH708dUNnjlG3oQpkZsi in items:
			if '#' in xmezOWMyhSXRGHlEk2JnsI: continue
			if xmezOWMyhSXRGHlEk2JnsI!='URL': name = name+Whef0cxB2iR93SC5IwUtk+H9cMF21gLJSv3tA5CPYXza+xmezOWMyhSXRGHlEk2JnsI+kjd9LyNqQHMUevZiRI7OlBGF1h
			url = xmezOWMyhSXRGHlEk2JnsI+';;'+oikt6P0hOAD5IvnlMpxf1+';;'+f1BA08uJ2nePQcdCHRqNEZKoGM+';;'+yzApRd2Dnes07XUZTM
			ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+NdKhAS6MXVEORLTwob92pxlZ+name,url,105,TTuPH708dUNnjlG3oQpkZsi)
	else:
		if showDialogs: ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+'هذه الخدمة مخصصة للمبرمج فقط',NdKhAS6MXVEORLTwob92pxlZ,9999)
	return
def uuvhoSanB2TWD(id):
	xmezOWMyhSXRGHlEk2JnsI,oikt6P0hOAD5IvnlMpxf1,f1BA08uJ2nePQcdCHRqNEZKoGM,yzApRd2Dnes07XUZTM = id.split(';;')
	url = NdKhAS6MXVEORLTwob92pxlZ
	if xmezOWMyhSXRGHlEk2JnsI=='URL': url = f1BA08uJ2nePQcdCHRqNEZKoGM
	elif xmezOWMyhSXRGHlEk2JnsI=='YOUTUBE':
		url = xKp3jkIvM09AZ4euXa87i5TVtfUD['YOUTUBE'][0]+'/watch?v='+f1BA08uJ2nePQcdCHRqNEZKoGM
		import ttrmdIqhPY
		ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx([url],yNIDEX5hU4G769,'live',url)
		return
	elif xmezOWMyhSXRGHlEk2JnsI=='GA':
		YWsjNtDXPAgCya = { 'id' : NdKhAS6MXVEORLTwob92pxlZ, 'user' : lop0ZwWYLmxOPAaErzF6cQvDkVR , 'function' : 'playGA1' , 'menu' : NdKhAS6MXVEORLTwob92pxlZ }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,False,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-1st')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		cookies = VNc1u4edS90FK5W6bsMgQC2B.cookies
		d1FLKw8qESkjoYDM9AXeQVmGcs2WPI = cookies['ASP.NET_SessionId']
		url = VNc1u4edS90FK5W6bsMgQC2B.headers['Location']
		YWsjNtDXPAgCya = { 'id' : f1BA08uJ2nePQcdCHRqNEZKoGM , 'user' : lop0ZwWYLmxOPAaErzF6cQvDkVR , 'function' : 'playGA2' , 'menu' : NdKhAS6MXVEORLTwob92pxlZ }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+d1FLKw8qESkjoYDM9AXeQVmGcs2WPI }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,YWsjNtDXPAgCya,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-2nd')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		url = YYqECUofyi7wFrW.findall('resp":"(http.*?m3u8)(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		zehVcU893FC6LEd1Aij = url[0][0]
		e3suhJiZytU7c = url[0][1]
		Iagmql8xyrt9VD = 'http://38.'+oikt6P0hOAD5IvnlMpxf1+'777/'+f1BA08uJ2nePQcdCHRqNEZKoGM+'_HD.m3u8'+e3suhJiZytU7c
		llKEMij0osBD = Iagmql8xyrt9VD.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		ttyHch7PnA1 = Iagmql8xyrt9VD.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		IGEpKNCaiLMT = ['HD','SD1','SD2']
		UTwH7zjZOrmFl = [Iagmql8xyrt9VD,llKEMij0osBD,ttyHch7PnA1]
		rRfpvbZojlygET5JL87wdzIPGe = 0
		if rRfpvbZojlygET5JL87wdzIPGe == -1: return
		else: url = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	elif xmezOWMyhSXRGHlEk2JnsI=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		YWsjNtDXPAgCya = { 'id' : f1BA08uJ2nePQcdCHRqNEZKoGM , 'user' : lop0ZwWYLmxOPAaErzF6cQvDkVR , 'function' : 'playNT' , 'menu' : yzApRd2Dnes07XUZTM }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST', qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN, YWsjNtDXPAgCya, headers, False,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-3rd')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		url = VNc1u4edS90FK5W6bsMgQC2B.headers['Location']
		url = url.replace('%20',Vwgflszp4WRA93kx6hvdua21HX5cOb)
		url = url.replace('%3D','=')
		if 'Learn' in f1BA08uJ2nePQcdCHRqNEZKoGM:
			url = url.replace('NTNNile',NdKhAS6MXVEORLTwob92pxlZ)
			url = url.replace('learning1','Learning')
	elif xmezOWMyhSXRGHlEk2JnsI=='PL':
		YWsjNtDXPAgCya = { 'id' : f1BA08uJ2nePQcdCHRqNEZKoGM , 'user' : lop0ZwWYLmxOPAaErzF6cQvDkVR , 'function' : 'playPL' , 'menu' : yzApRd2Dnes07XUZTM }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST', qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN, YWsjNtDXPAgCya, NdKhAS6MXVEORLTwob92pxlZ,False,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-4th')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		url = VNc1u4edS90FK5W6bsMgQC2B.headers['Location']
		headers = {'Referer':VNc1u4edS90FK5W6bsMgQC2B.headers['Referer']}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'POST',url, NdKhAS6MXVEORLTwob92pxlZ,headers , NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-5th')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		items = YYqECUofyi7wFrW.findall('source src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		url = items[0]
	elif xmezOWMyhSXRGHlEk2JnsI in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if xmezOWMyhSXRGHlEk2JnsI=='TA': f1BA08uJ2nePQcdCHRqNEZKoGM = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		YWsjNtDXPAgCya = { 'id' : f1BA08uJ2nePQcdCHRqNEZKoGM , 'user' : lop0ZwWYLmxOPAaErzF6cQvDkVR , 'function' : 'play'+xmezOWMyhSXRGHlEk2JnsI , 'menu' : yzApRd2Dnes07XUZTM }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,YWsjNtDXPAgCya,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-6th')
		if not VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		url = VNc1u4edS90FK5W6bsMgQC2B.headers['Location']
		if xmezOWMyhSXRGHlEk2JnsI=='FM':
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET', url, NdKhAS6MXVEORLTwob92pxlZ, NdKhAS6MXVEORLTwob92pxlZ, False,NdKhAS6MXVEORLTwob92pxlZ,'LIVETV-PLAY-7th')
			url = VNc1u4edS90FK5W6bsMgQC2B.headers['Location']
			url = url.replace('https','http')
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(url,yNIDEX5hU4G769,'live')
	return
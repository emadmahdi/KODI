# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᶀ")
Arg59QcGfXjObz0CoqSU6NPH4K = []
headers = {JGwsL21ZRlqSrWxEmF(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᶁ"):NdKhAS6MXVEORLTwob92pxlZ}
def ffhkpjGYRZ(source,GY9jgon6yhP0IvtCBEJu3,url):
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lNTJCZeBicWEz0Mg(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࡵࠣࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨᶂ")+source+fOc18oTm5hsdD4pVZQj(u"ࠩࠣࡡࠥࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪᶃ")+GY9jgon6yhP0IvtCBEJu3+lNTJCZeBicWEz0Mg(u"ࠪࠤࡢ࠭ᶄ"))
	RRHcUyPE7dCxNzB9Dw3KfGp = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡩ࡯ࡣࡵࠩᶅ"),R3lezw8h407ZvrAFxT(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨᶆ"),V0VZk9763fusTReHFo4(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬᶇ"))
	ssPwFfnphBNO6rAcEWuaH = XJ62UBRmIqFvfiNTQj.strftime(fOc18oTm5hsdD4pVZQj(u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍࠨᶈ"),XJ62UBRmIqFvfiNTQj.gmtime(MMQhDpyCenmO350aBAKVYk))
	iJbFcE2OQWRykXNMUlfrCv918SqpD = ssPwFfnphBNO6rAcEWuaH,url
	key = source+mrgzi2ktB4WS06QHPf5ZJE1Kv+lvsJ2jaZktmNO6PbdXS+mrgzi2ktB4WS06QHPf5ZJE1Kv+str(kQI947MebLovYyVE08F5qPi6fj3)
	JzNoqV8ClRD6O = NdKhAS6MXVEORLTwob92pxlZ
	if key not in list(RRHcUyPE7dCxNzB9Dw3KfGp.keys()): RRHcUyPE7dCxNzB9Dw3KfGp[key] = [iJbFcE2OQWRykXNMUlfrCv918SqpD]
	else:
		if url not in str(RRHcUyPE7dCxNzB9Dw3KfGp[key]): RRHcUyPE7dCxNzB9Dw3KfGp[key].append(iJbFcE2OQWRykXNMUlfrCv918SqpD)
		else: JzNoqV8ClRD6O = gniNItGL6bKwpEW(u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭ᶉ")
	bhuizJTtvLwyZqQGod5rm24IVn9aXY = e8XhbyuzvjYkIsJUtB5w
	for key in list(RRHcUyPE7dCxNzB9Dw3KfGp.keys()):
		RRHcUyPE7dCxNzB9Dw3KfGp[key] = list(set(RRHcUyPE7dCxNzB9Dw3KfGp[key]))
		bhuizJTtvLwyZqQGod5rm24IVn9aXY += len(RRHcUyPE7dCxNzB9Dw3KfGp[key])
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶊ"),gniNItGL6bKwpEW(u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫᶋ")+JzNoqV8ClRD6O+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡡࡴ࡜࡯ࠢ็่฾๊ๅࠡษ็ฬึ์วๆฮࠣ๎็๎ๅࠡสฯ้฾ࠦโศศ่อࠥฮวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤ๏าฯࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ์ุ๎แࠡ์฼ี฻ูࠦๅ์ๆࠤฬ๊ศา่ส้ัࠦร็ࠢอีุ๊่ࠠา๊ࠤฬ๊โศศ่อࠥหไ๊ࠢส่๊ฮัๆฮࠣ฽๋ีๅศࠢํูอำฺࠠัา๋ฬࠦ࠵ࠡใํำ๏๎็ศฬࠪᶌ")+gniNItGL6bKwpEW(u"ࠬࡢ࡮࡝ࡰࠪᶍ")+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣห้่วว็ฬࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠩᶎ")+str(bhuizJTtvLwyZqQGod5rm24IVn9aXY))
	if bhuizJTtvLwyZqQGod5rm24IVn9aXY>=NOrchaEV1iIZ87Uzlwgum(u"࠻೙"):
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶏ"),OOkmZiVcfqlEurM1dHGb(u"ࠨษ็ฬึ์วๆฮࠣะ๊฿ࠠใษษ้ฮࠦแ๋้สࠤ࠺ࠦแ๋ัํ์์อสࠡๆ่ࠤ๏าฯࠡษ็ฬึ์วๆฮ่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬู๊อ้ࠡำ๋ࠥอไใษษ้ฮࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥหัิษ็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢๅฬ้ࠦๅิฯ๊หࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไๆสิ้ัࠦศโฯุࠤ์ึ็ࠡษ็ๅ๏ี๊้้สฮࠥลࠡࠢࠩᶐ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO==JGwsL21ZRlqSrWxEmF(u"࠱೚"):
			yrPG7D3t9Wsg0I1CE8m4UuM = NdKhAS6MXVEORLTwob92pxlZ
			for key in list(RRHcUyPE7dCxNzB9Dw3KfGp.keys()):
				yrPG7D3t9Wsg0I1CE8m4UuM += B6IrC7zEHlw1oaeWf+key
				cG7xHnkpZEgqrlIXWQidA = sorted(RRHcUyPE7dCxNzB9Dw3KfGp[key],reverse=f4vncKMRlXG9s,key=lambda pODxdAHs90g7tWV3ILKlX: pODxdAHs90g7tWV3ILKlX[e8XhbyuzvjYkIsJUtB5w])
				for ssPwFfnphBNO6rAcEWuaH,url in cG7xHnkpZEgqrlIXWQidA:
					yrPG7D3t9Wsg0I1CE8m4UuM += B6IrC7zEHlw1oaeWf+ssPwFfnphBNO6rAcEWuaH+mrgzi2ktB4WS06QHPf5ZJE1Kv+OOFEmwq2GkTz93WXy1Nj(url)
				yrPG7D3t9Wsg0I1CE8m4UuM += wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ࡟ࡲࡡࡴࠧᶑ")
			import oMV3OL4Bzl
			PsKJk8XRHAQM = oMV3OL4Bzl.TM3EgsyYRtVxA9i(HHvYL68lbJVZWM7tQEzSex3(u"࡚ࠪ࡮ࡪࡥࡰࡵࠪᶒ"),NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᶓ"),NdKhAS6MXVEORLTwob92pxlZ,yrPG7D3t9Wsg0I1CE8m4UuM)
			if PsKJk8XRHAQM: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶔ"),NeU6uRGpECkvMV5jf(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩᶕ"))
			else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶖ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨใื่ฯูࠦๆๆํอࠥอไฦำึห้࠭ᶗ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO!=-llxMLe4gobHhsj1WGvd7qmIU:
			RRHcUyPE7dCxNzB9Dw3KfGp = {}
			WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬᶘ"),kb2icmDGVUZfW1OFz7sv(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩᶙ"))
	if RRHcUyPE7dCxNzB9Dw3KfGp: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,OOkmZiVcfqlEurM1dHGb(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧᶚ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫᶛ"),RRHcUyPE7dCxNzB9Dw3KfGp,hzP83xLawFqYneDtHGmSriWE)
	return
def jjPCW61oIg(I5Y0Ve3Uc2wjtF1,source):
	iQ9bCrJLy8zUnXA1Hqk,IGEpKNCaiLMT,UTwH7zjZOrmFl,ttFMHI9QPiN = [],[],[],[]
	for XmQUz51EvhsOJioPldRK in I5Y0Ve3Uc2wjtF1[:]:
		F1wRk76it3mPIy4jCTh,eecXAVTfIujZra4wbqkNpLUhF = XmQUz51EvhsOJioPldRK,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࠧᶜ")
		if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᶝ") in XmQUz51EvhsOJioPldRK: F1wRk76it3mPIy4jCTh,eecXAVTfIujZra4wbqkNpLUhF = XmQUz51EvhsOJioPldRK.split(lNTJCZeBicWEz0Mg(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᶞ"),llxMLe4gobHhsj1WGvd7qmIU)
		if F1wRk76it3mPIy4jCTh in ttFMHI9QPiN: continue
		if source==lrtFSogC8Nh9(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪᶟ"): BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = pHIji6rfbSgCK0Ph7ZG(F1wRk76it3mPIy4jCTh)
		elif PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡵࡻ࡯ࡤࠨᶠ") in F1wRk76it3mPIy4jCTh: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = pHIji6rfbSgCK0Ph7ZG(F1wRk76it3mPIy4jCTh)
		if UTwH7zjZOrmFl:
			I5Y0Ve3Uc2wjtF1.remove(XmQUz51EvhsOJioPldRK)
			HeW40B5t8iMsy2Y3GXU7QxJwg = YYqECUofyi7wFrW.findall(rNyT0edugn(u"ࠫࡳࡧ࡭ࡦࡦࡀ࠲࠯ࡅ࡟ࡠࠪ࠱࠮ࡄ࠯࡟ࡠࠩᶡ"),XmQUz51EvhsOJioPldRK+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡥ࡟ࠨᶢ"),YYqECUofyi7wFrW.DOTALL)
			HeW40B5t8iMsy2Y3GXU7QxJwg = HeW40B5t8iMsy2Y3GXU7QxJwg[NeU6uRGpECkvMV5jf(u"࠱೛")] if HeW40B5t8iMsy2Y3GXU7QxJwg else lNTJCZeBicWEz0Mg(u"࠭ࠧᶣ")
			for PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg in zip(IGEpKNCaiLMT,UTwH7zjZOrmFl):
				if xKXbWz9coR7jUfil45aQENr0ICBJg in ttFMHI9QPiN: continue
				ttFMHI9QPiN.append(xKXbWz9coR7jUfil45aQENr0ICBJg)
				xKXbWz9coR7jUfil45aQENr0ICBJg = xKXbWz9coR7jUfil45aQENr0ICBJg+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᶤ")+PJN58A9SFZTwi6uLMB73m+JGwsL21ZRlqSrWxEmF(u"ࠨࡡࡢࠫᶥ")+HeW40B5t8iMsy2Y3GXU7QxJwg
				iQ9bCrJLy8zUnXA1Hqk.append(xKXbWz9coR7jUfil45aQENr0ICBJg)
	return I5Y0Ve3Uc2wjtF1+iQ9bCrJLy8zUnXA1Hqk
def rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,source,GY9jgon6yhP0IvtCBEJu3,url):
	if not Pj8lY4doOfxiFMuNLhv3tnp:
		ffhkpjGYRZ(source,GY9jgon6yhP0IvtCBEJu3,url)
		return
	Pj8lY4doOfxiFMuNLhv3tnp = jjPCW61oIg(Pj8lY4doOfxiFMuNLhv3tnp,source)
	Pj8lY4doOfxiFMuNLhv3tnp = list(set(Pj8lY4doOfxiFMuNLhv3tnp))
	IGEpKNCaiLMT,UTwH7zjZOrmFl = vvO4dcYPlRW8E2rLgQoZqw0e(Pj8lY4doOfxiFMuNLhv3tnp,source)
	if OMNiY8joQx.resolveonly:
		dd9SpCKeW02O1IYNE3RZ4FcUl = Y0Ryg6u358jZwcEk2LtzQIWAlbGmO(IGEpKNCaiLMT,UTwH7zjZOrmFl,source,f4vncKMRlXG9s)
		return
	Eym4trJcf2,BGulEd0o6ZQLzk5WHwMs2bN,MM2inT9uqCKp6zsvxYdf,dd9SpCKeW02O1IYNE3RZ4FcUl,Bk6hbuOyGaJmz9vn7,rMOG2USkPesYZD9KNAVqpc = f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,[],NdKhAS6MXVEORLTwob92pxlZ,[]
	mxVtqvyQodcAbHDYW = not any(K6KbZDHncNizQgl1fr59XV0 in source for K6KbZDHncNizQgl1fr59XV0 in aXD9VCmgGzqRFerBcJ)
	if mxVtqvyQodcAbHDYW:
		VIWBqok03K = e8XhbyuzvjYkIsJUtB5w
		aaSxBF9rs4KAwvcVENhMCTJ = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,Tzx81Wb0RZC4ID5AyiU2(u"ࠩ࡯࡭ࡸࡺࠧᶦ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡙ࡕࡄࡅࡈࡉࡉࡋࡄࠨᶧ"))
		ow5c2RiMFfy3NEHX = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,lrtFSogC8Nh9(u"ࠫࡱ࡯ࡳࡵࠩᶨ"),HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡇࡃࡌࡐࡊࡊࠧᶩ"))
		rAknWUHpDyi4IuGPfl2QYR = e8XhbyuzvjYkIsJUtB5w
		for title,zehVcU893FC6LEd1Aij in zip(IGEpKNCaiLMT,UTwH7zjZOrmFl):
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split(JGwsL21ZRlqSrWxEmF(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᶪ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
			if zehVcU893FC6LEd1Aij in aaSxBF9rs4KAwvcVENhMCTJ:
				VIWBqok03K += llxMLe4gobHhsj1WGvd7qmIU
				IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR] = kRJIE1KlPjZyAbQ73aHGFo24w6Ld9+title+kjd9LyNqQHMUevZiRI7OlBGF1h
			elif zehVcU893FC6LEd1Aij in ow5c2RiMFfy3NEHX:
				VIWBqok03K += llxMLe4gobHhsj1WGvd7qmIU
				IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR] = Whef0cxB2iR93SC5IwUtk+title+kjd9LyNqQHMUevZiRI7OlBGF1h
			rAknWUHpDyi4IuGPfl2QYR += llxMLe4gobHhsj1WGvd7qmIU
		rMOG2USkPesYZD9KNAVqpc = [D7INg5kyRjwf4ZtoePVUrb1h2SJ+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧโฯุࠤัฺ๋๊ࠢสุ่๐ัโำสฮࠬᶫ")+kjd9LyNqQHMUevZiRI7OlBGF1h]
	else: Bk6hbuOyGaJmz9vn7 = D7INg5kyRjwf4ZtoePVUrb1h2SJ+Hlp3z0APt1GR4kMYK5xST(u"ࠨลัฮึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠨᶬ")+kjd9LyNqQHMUevZiRI7OlBGF1h
	ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ᶭ"))
	KkjO5Re2rGlEu3cINw = HHvYL68lbJVZWM7tQEzSex3(u"ࠪ࠱ࠬᶮ") not in ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB
	while k6apiPAlLKM1ed8J42RjHh0o:
		HxKEtpzS5Ii4Z = k6apiPAlLKM1ed8J42RjHh0o
		if mxVtqvyQodcAbHDYW:
			if KkjO5Re2rGlEu3cINw and len(IGEpKNCaiLMT)==llxMLe4gobHhsj1WGvd7qmIU: rRfpvbZojlygET5JL87wdzIPGe = llxMLe4gobHhsj1WGvd7qmIU
			else:
				wjAUSepBW67Q3iO9PdIbn = str(IGEpKNCaiLMT).count(kRJIE1KlPjZyAbQ73aHGFo24w6Ld9)
				AZIaywFfHYjX3c = str(IGEpKNCaiLMT).count(Whef0cxB2iR93SC5IwUtk)
				xd307bqcZy = len(IGEpKNCaiLMT)-wjAUSepBW67Q3iO9PdIbn-AZIaywFfHYjX3c
				if QBp28giCnayJzmZH6vYO: Bk6hbuOyGaJmz9vn7 = Whef0cxB2iR93SC5IwUtk+lRP6GTaZJA1Xw3egLM4(u"ࠫࠥࠦࠠิ์ษอ࠿࠭ᶯ")+str(AZIaywFfHYjX3c)+kjd9LyNqQHMUevZiRI7OlBGF1h+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦࠠࠡ็ฯ๋ํ๊ษ࠻ࠩᶰ")+str(xd307bqcZy)+kRJIE1KlPjZyAbQ73aHGFo24w6Ld9+Hlp3z0APt1GR4kMYK5xST(u"࠭ฬ๋ัฬ࠾ࠬᶱ")+str(wjAUSepBW67Q3iO9PdIbn)+kjd9LyNqQHMUevZiRI7OlBGF1h
				else: Bk6hbuOyGaJmz9vn7 = kRJIE1KlPjZyAbQ73aHGFo24w6Ld9+JGwsL21ZRlqSrWxEmF(u"ࠧอ์าอ࠿࠭ᶲ")+str(wjAUSepBW67Q3iO9PdIbn)+kjd9LyNqQHMUevZiRI7OlBGF1h+HHvYL68lbJVZWM7tQEzSex3(u"ࠨࠢࠣࠤ๊า็้ๆฬ࠾ࠬᶳ")+str(xd307bqcZy)+Whef0cxB2iR93SC5IwUtk+QQHFtjcaR2VpnSyTIv(u"ࠩࠣࠤู๊ࠥวห࠽ࠫᶴ")+str(AZIaywFfHYjX3c)+kjd9LyNqQHMUevZiRI7OlBGF1h
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(Bk6hbuOyGaJmz9vn7,rMOG2USkPesYZD9KNAVqpc+IGEpKNCaiLMT)
			if rRfpvbZojlygET5JL87wdzIPGe==e8XhbyuzvjYkIsJUtB5w:
				HxKEtpzS5Ii4Z = f4vncKMRlXG9s
				start,end = e8XhbyuzvjYkIsJUtB5w,len(IGEpKNCaiLMT)-llxMLe4gobHhsj1WGvd7qmIU
				dd9SpCKeW02O1IYNE3RZ4FcUl = Y0Ryg6u358jZwcEk2LtzQIWAlbGmO(IGEpKNCaiLMT,UTwH7zjZOrmFl,source,k6apiPAlLKM1ed8J42RjHh0o)
				MM2inT9uqCKp6zsvxYdf = NeU6uRGpECkvMV5jf(u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࡤࡧ࡬࡭ࠩᶵ") if dd9SpCKeW02O1IYNE3RZ4FcUl else lrtFSogC8Nh9(u"ࠫࡳࡵࡴࡠࡴࡨࡷࡴࡲࡶࡢࡤ࡯ࡩࠬᶶ")
			elif rRfpvbZojlygET5JL87wdzIPGe>e8XhbyuzvjYkIsJUtB5w: start,end = rRfpvbZojlygET5JL87wdzIPGe-llxMLe4gobHhsj1WGvd7qmIU,rRfpvbZojlygET5JL87wdzIPGe-llxMLe4gobHhsj1WGvd7qmIU
		else:
			if KkjO5Re2rGlEu3cINw and len(IGEpKNCaiLMT)==llxMLe4gobHhsj1WGvd7qmIU: rRfpvbZojlygET5JL87wdzIPGe = e8XhbyuzvjYkIsJUtB5w
			else: rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(Bk6hbuOyGaJmz9vn7,IGEpKNCaiLMT)
			start,end = rRfpvbZojlygET5JL87wdzIPGe,rRfpvbZojlygET5JL87wdzIPGe
		if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU:
			MM2inT9uqCKp6zsvxYdf = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧᶷ")
			break
		if HxKEtpzS5Ii4Z:
			MM2inT9uqCKp6zsvxYdf = fOc18oTm5hsdD4pVZQj(u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࡠࡱࡱࡩࠬᶸ")
			dd9SpCKeW02O1IYNE3RZ4FcUl = Y0Ryg6u358jZwcEk2LtzQIWAlbGmO([IGEpKNCaiLMT[start]],[UTwH7zjZOrmFl[start]],source,k6apiPAlLKM1ed8J42RjHh0o)
			title,zehVcU893FC6LEd1Aij,BGulEd0o6ZQLzk5WHwMs2bN,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv = dd9SpCKeW02O1IYNE3RZ4FcUl[e8XhbyuzvjYkIsJUtB5w]
			NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5,aP637mkyOIjgxdqctlUVE2TN4AvQzu = ivwklbMCaPGSTftjg6F(title,zehVcU893FC6LEd1Aij,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv,source,GY9jgon6yhP0IvtCBEJu3)
			if NcpgyMDWfl4XtmUdxT1i3H9wkJR0z5 in [lrtFSogC8Nh9(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬᶹ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩᶺ"),xY4icgQUj6mPVs73CTKu(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪᶻ")]:
				Eym4trJcf2 = k6apiPAlLKM1ed8J42RjHh0o
				break
			else:
				if not BGulEd0o6ZQLzk5WHwMs2bN: BGulEd0o6ZQLzk5WHwMs2bN = rNyT0edugn(u"࡚ࠪ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡧࡣ࡬ࡰࡪࡪࠧᶼ")
				title = Whef0cxB2iR93SC5IwUtk+title+kjd9LyNqQHMUevZiRI7OlBGF1h
				dd9SpCKeW02O1IYNE3RZ4FcUl[e8XhbyuzvjYkIsJUtB5w] = title,zehVcU893FC6LEd1Aij,BGulEd0o6ZQLzk5WHwMs2bN,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv
				rwhEG0osYOykLRuBi5ZS = zehVcU893FC6LEd1Aij.split(Hlp3z0APt1GR4kMYK5xST(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᶽ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
				WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,hCm2fnEXs6Zt(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡗࡆࡇࡊࡋࡄࡆࡆࠪᶾ"),rwhEG0osYOykLRuBi5ZS)
				eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,HVmIrFwau90jQsgiWzExk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨᶿ"),rwhEG0osYOykLRuBi5ZS,[BGulEd0o6ZQLzk5WHwMs2bN,title,zehVcU893FC6LEd1Aij],h1dnE0q2zFHjXlvyGuLZxw)
			if BGulEd0o6ZQLzk5WHwMs2bN==lrtFSogC8Nh9(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᷀"): break
			h2hHkw6jETOvqc7B = xY4icgQUj6mPVs73CTKu(u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠡࠢࠪ᷁")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩ࡟ࡲࡠࡒࡅࡇࡖࡠࠤ᷂ࠥ࠭")) if BGulEd0o6ZQLzk5WHwMs2bN.count(B6IrC7zEHlw1oaeWf)>R3lezw8h407ZvrAFxT(u"࠵೜") else B6IrC7zEHlw1oaeWf+BGulEd0o6ZQLzk5WHwMs2bN
			if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ᷃") not in source: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᷄"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨ᷅")+B6IrC7zEHlw1oaeWf+h2hHkw6jETOvqc7B,profile=rNyT0edugn(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ᷆"))
			if len(UTwH7zjZOrmFl)==llxMLe4gobHhsj1WGvd7qmIU and BGulEd0o6ZQLzk5WHwMs2bN: break
		for rAknWUHpDyi4IuGPfl2QYR in range(start,end+llxMLe4gobHhsj1WGvd7qmIU):
			XyMEQj1RlPUcnrC = e8XhbyuzvjYkIsJUtB5w if HxKEtpzS5Ii4Z else rAknWUHpDyi4IuGPfl2QYR
			title,zehVcU893FC6LEd1Aij,BGulEd0o6ZQLzk5WHwMs2bN,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv = dd9SpCKeW02O1IYNE3RZ4FcUl[XyMEQj1RlPUcnrC]
			IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR] = IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR].replace(Whef0cxB2iR93SC5IwUtk,NdKhAS6MXVEORLTwob92pxlZ).replace(kRJIE1KlPjZyAbQ73aHGFo24w6Ld9,NdKhAS6MXVEORLTwob92pxlZ).replace(kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ)
			if BGulEd0o6ZQLzk5WHwMs2bN: IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR] = Whef0cxB2iR93SC5IwUtk+IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR]+kjd9LyNqQHMUevZiRI7OlBGF1h
			else: IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR] = kRJIE1KlPjZyAbQ73aHGFo24w6Ld9+IGEpKNCaiLMT[rAknWUHpDyi4IuGPfl2QYR]+kjd9LyNqQHMUevZiRI7OlBGF1h
	if MM2inT9uqCKp6zsvxYdf==PzIpQnUXxRwNCivDhdakWTE(u"ࠧ࡯ࡱࡷࡣࡷ࡫ࡳࡰ࡮ࡹࡥࡧࡲࡥࠨ᷇"): ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᷈"),JGwsL21ZRlqSrWxEmF(u"ࠩ็่ศูแࠡๆสࠤ๏๎ฬะࠢึ๎ึ็ัศฬࠣะ๏ีษࠡใํࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ࠱࠲ࠥำว้ๆࠣว๋ࠦสษฯฮࠤ฾์่ࠠาสࠤฬ๊แ๋ัํ์ࠥ็๊ࠡ็๋ห็฿ࠠฤะิํࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠧ᷉"))
	if not Eym4trJcf2 or MM2inT9uqCKp6zsvxYdf in [rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨ᷊ࠬ"),Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡳࡵࡴࡠࡴࡨࡷࡴࡲࡶࡢࡤ࡯ࡩࠬ᷋")] or BGulEd0o6ZQLzk5WHwMs2bN:
		eyscIJr8U9dTtFVbhPx5 = ACOWB6GRmIbDKyl3Zn.executeJSONRPC(JGwsL21ZRlqSrWxEmF(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬ᷌"))
	return
Af0Qa6dFT7EZPSNJMeLmU,tXSljcPk9ZBH4wumMLIFO,Y5cBahqQ0An6x8b,R9THEsIkMJv6m05VAGo,QIAmjsvXplbk0ce24dSNgH7MY,KaVOQqFDzXCcA = [],[],[],[],[],[]
def Y0Ryg6u358jZwcEk2LtzQIWAlbGmO(UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp,source,showDialogs):
	global Af0Qa6dFT7EZPSNJMeLmU,tXSljcPk9ZBH4wumMLIFO,Y5cBahqQ0An6x8b,R9THEsIkMJv6m05VAGo,QIAmjsvXplbk0ce24dSNgH7MY,KaVOQqFDzXCcA
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT,gKZ0VkN472arIp,new = [],[],[]
	f2cgzj0TovI9YVl7tan1QkMS8(f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s)
	count = len(Pj8lY4doOfxiFMuNLhv3tnp)
	for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(count):
		Af0Qa6dFT7EZPSNJMeLmU.append(None)
		tXSljcPk9ZBH4wumMLIFO.append(None)
		Y5cBahqQ0An6x8b.append(None)
		R9THEsIkMJv6m05VAGo.append(None)
		QIAmjsvXplbk0ce24dSNgH7MY.append(None)
		KaVOQqFDzXCcA.append(e8XhbyuzvjYkIsJUtB5w)
		title = UpvYl7QkMBOTJIeSyCiH92GKfm56rn[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
		zehVcU893FC6LEd1Aij = Pj8lY4doOfxiFMuNLhv3tnp[Lw25iFJMOgNEora84dkT0Hx7Zcpj].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(HVmIrFwau90jQsgiWzExk(u"࠭ࠦࠨ᷍")).strip(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡀ᷎ࠩ")).strip(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ࠱᷏ࠪ"))
		if count>llxMLe4gobHhsj1WGvd7qmIU and showDialogs: kkDz5sdaPteM(PzIpQnUXxRwNCivDhdakWTE(u"ࠩไัฺࠦำ๋ำไีࠥืโๆ᷐ࠢࠣࠫ")+str(Lw25iFJMOgNEora84dkT0Hx7Zcpj+OOkmZiVcfqlEurM1dHGb(u"࠴ೝ")),title)
		RRH8zxqi2ysw4YVJ = [YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ᷑"),PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ᷒"),NeU6uRGpECkvMV5jf(u"ࠬࡇࡋࡘࡃࡐࠫᷓ")]
		if source in RRH8zxqi2ysw4YVJ: Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj] = Snh7HCdumqw9jlLVtXP(title,zehVcU893FC6LEd1Aij,source,Lw25iFJMOgNEora84dkT0Hx7Zcpj)
		else:
			if QQHFtjcaR2VpnSyTIv(u"࠵ೞ"):
				QTUijzHvFNGYZ = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=Snh7HCdumqw9jlLVtXP,args=(title,zehVcU893FC6LEd1Aij,source,Lw25iFJMOgNEora84dkT0Hx7Zcpj))
				QTUijzHvFNGYZ.start()
				gKZ0VkN472arIp.append(QTUijzHvFNGYZ)
				new.append(Lw25iFJMOgNEora84dkT0Hx7Zcpj)
				XJ62UBRmIqFvfiNTQj.sleep(lRP6GTaZJA1Xw3egLM4(u"࠶೟"))
	timeout = eGW7cI6aQhr0(u"࠼࠰ೠ") if source==lrtFSogC8Nh9(u"࠭ࡁࡌ࡙ࡄࡑࠬᷔ") else xY4icgQUj6mPVs73CTKu(u"࠳࠱ೡ")
	nDW6hxsUyd5NtALZ = XJ62UBRmIqFvfiNTQj.time()
	for QTUijzHvFNGYZ in gKZ0VkN472arIp: QTUijzHvFNGYZ.join(timeout)
	for Lw25iFJMOgNEora84dkT0Hx7Zcpj in range(count):
		title = UpvYl7QkMBOTJIeSyCiH92GKfm56rn[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
		zehVcU893FC6LEd1Aij = Pj8lY4doOfxiFMuNLhv3tnp[Lw25iFJMOgNEora84dkT0Hx7Zcpj].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).strip(lrtFSogC8Nh9(u"ࠧࠧࠩᷕ")).strip(kb2icmDGVUZfW1OFz7sv(u"ࠨࡁࠪᷖ")).strip(gniNItGL6bKwpEW(u"ࠩ࠲ࠫᷗ"))
		s91Em4uS7tf5WM = k6apiPAlLKM1ed8J42RjHh0o if KaVOQqFDzXCcA[Lw25iFJMOgNEora84dkT0Hx7Zcpj]+llxMLe4gobHhsj1WGvd7qmIU>timeout else f4vncKMRlXG9s
		if Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj] and len(Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj])==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠴ೢ") and (Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj][e8XhbyuzvjYkIsJUtB5w] or Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj][cCRvAuJQfjBpTg0PbYiaNO87]): h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg = Af0Qa6dFT7EZPSNJMeLmU[Lw25iFJMOgNEora84dkT0Hx7Zcpj]
		elif s91Em4uS7tf5WM: h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡚ࠥࡩ࡮ࡧࡧࠤࡔࡻࡴࠡࠪࠪᷘ")+str(timeout)+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࠥࡹࡥࡤࡱࡱࡨࡸ࠯ࠧᷙ"),[],[]
		else: h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩᷚ"),[],[]
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT.append([title,zehVcU893FC6LEd1Aij,h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg])
		if Lw25iFJMOgNEora84dkT0Hx7Zcpj in new:
			rwhEG0osYOykLRuBi5ZS = zehVcU893FC6LEd1Aij.split(kb2icmDGVUZfW1OFz7sv(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᷛ"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
			if not h2hHkw6jETOvqc7B: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬᷜ"),rwhEG0osYOykLRuBi5ZS,[h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg],h1dnE0q2zFHjXlvyGuLZxw)
			else: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪᷝ"),rwhEG0osYOykLRuBi5ZS,[h2hHkw6jETOvqc7B,PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg],h1dnE0q2zFHjXlvyGuLZxw)
	f2cgzj0TovI9YVl7tan1QkMS8(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def Snh7HCdumqw9jlLVtXP(oikt6P0hOAD5IvnlMpxf1,url,source,UfsQbH5JM7vg32G1lX8EN):
	global Af0Qa6dFT7EZPSNJMeLmU,KaVOQqFDzXCcA
	KaVOQqFDzXCcA[UfsQbH5JM7vg32G1lX8EN] = e8XhbyuzvjYkIsJUtB5w
	nDW6hxsUyd5NtALZ = XJ62UBRmIqFvfiNTQj.time()
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+PzIpQnUXxRwNCivDhdakWTE(u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪᷞ")+oikt6P0hOAD5IvnlMpxf1+V0VZk9763fusTReHFo4(u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧᷟ")+url+lNTJCZeBicWEz0Mg(u"ࠫࠥࡣࠧᷠ"))
	zehVcU893FC6LEd1Aij,eez2krpcog8fAXd9IhOi = url,NdKhAS6MXVEORLTwob92pxlZ
	QvL8iHu1yk3GzN0lPXFnox5OpS = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩᷡ")
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = HkEpUai5tocg6mTZuCwrFPM(url,source)
	if BGulEd0o6ZQLzk5WHwMs2bN==YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᷢ"):
		Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = NeU6uRGpECkvMV5jf(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᷣ"),[],[]
		KaVOQqFDzXCcA[UfsQbH5JM7vg32G1lX8EN] = XJ62UBRmIqFvfiNTQj.time()-nDW6hxsUyd5NtALZ
		return Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN]
	elif lRP6GTaZJA1Xw3egLM4(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᷤ") in BGulEd0o6ZQLzk5WHwMs2bN:
		eez2krpcog8fAXd9IhOi = fOc18oTm5hsdD4pVZQj(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠣࡒࡪ࡫ࡤࠡࡇࡻࡸࡪࡸ࡮ࡢ࡮ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠬᷥ")
		zehVcU893FC6LEd1Aij = jjP7EciLOl(UTwH7zjZOrmFl)[e8XhbyuzvjYkIsJUtB5w]
		QvL8iHu1yk3GzN0lPXFnox5OpS,eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl = OOHUFWfhldq3LkZvDsMp9YVb62en(eez2krpcog8fAXd9IhOi,zehVcU893FC6LEd1Aij,source,UfsQbH5JM7vg32G1lX8EN)
		if eez2krpcog8fAXd9IhOi==JGwsL21ZRlqSrWxEmF(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᷦ"):
			KaVOQqFDzXCcA[UfsQbH5JM7vg32G1lX8EN] = XJ62UBRmIqFvfiNTQj.time()-nDW6hxsUyd5NtALZ
			return eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	elif BGulEd0o6ZQLzk5WHwMs2bN: eez2krpcog8fAXd9IhOi = vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠣࠫᷧ")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)[:hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠺࠳ೣ")]
	if UTwH7zjZOrmFl:
		UTwH7zjZOrmFl = jjP7EciLOl(UTwH7zjZOrmFl)
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Hlp3z0APt1GR4kMYK5xST(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠾ࠥࡡࠠࠨᷨ")+oikt6P0hOAD5IvnlMpxf1+NOrchaEV1iIZ87Uzlwgum(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪᷩ")+QvL8iHu1yk3GzN0lPXFnox5OpS+fOc18oTm5hsdD4pVZQj(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫᷪ")+url+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨᷫ")+zehVcU893FC6LEd1Aij+PzIpQnUXxRwNCivDhdakWTE(u"ࠩࠣࡡ࡚ࠥࠦࠠࠡࠢࠣ࡮ࡪࡥࡰࡵ࠽ࠤࡠࠦࠧᷬ")+str(UTwH7zjZOrmFl)+IlL8ZnX74Yvep(u"ࠪࠤࡢ࠭ᷭ"))
	else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NOrchaEV1iIZ87Uzlwgum(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫᷮ")+oikt6P0hOAD5IvnlMpxf1+hCm2fnEXs6Zt(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩᷯ")+url+wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭ᷰ")+zehVcU893FC6LEd1Aij+JGwsL21ZRlqSrWxEmF(u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩᷱ")+eez2krpcog8fAXd9IhOi+HVmIrFwau90jQsgiWzExk(u"ࠨࠢࡠࠫᷲ"))
	eez2krpcog8fAXd9IhOi = OOFEmwq2GkTz93WXy1Nj(eez2krpcog8fAXd9IhOi)
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	KaVOQqFDzXCcA[UfsQbH5JM7vg32G1lX8EN] = XJ62UBRmIqFvfiNTQj.time()-nDW6hxsUyd5NtALZ
	return eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
def ivwklbMCaPGSTftjg6F(title,zehVcU893FC6LEd1Aij,IGEpKNCaiLMT,UTwH7zjZOrmFl,source,GY9jgon6yhP0IvtCBEJu3=NdKhAS6MXVEORLTwob92pxlZ):
	if UTwH7zjZOrmFl:
		if not IGEpKNCaiLMT[QQHFtjcaR2VpnSyTIv(u"࠳೤")]: IGEpKNCaiLMT = UTwH7zjZOrmFl
		ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(NOrchaEV1iIZ87Uzlwgum(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ᷳ"))
		KkjO5Re2rGlEu3cINw = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࠱ࠬᷴ") not in ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB
		while k6apiPAlLKM1ed8J42RjHh0o:
			if KkjO5Re2rGlEu3cINw and len(UTwH7zjZOrmFl)==llxMLe4gobHhsj1WGvd7qmIU: rRfpvbZojlygET5JL87wdzIPGe = e8XhbyuzvjYkIsJUtB5w
			else: rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(lRP6GTaZJA1Xw3egLM4(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ᷵"), IGEpKNCaiLMT)
			if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: ZB3WgSanUwV = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧ᷶")
			else:
				W1lyozPsEhVbFMkL = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
				LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lRP6GTaZJA1Xw3egLM4(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤ᷷ࠬ")+title+V0VZk9763fusTReHFo4(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝᷸ࠣࠫ")+zehVcU893FC6LEd1Aij+OOkmZiVcfqlEurM1dHGb(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛᷹ࠦࠡࠩ")+str(W1lyozPsEhVbFMkL)+gniNItGL6bKwpEW(u"ࠩࠣࡡ᷺ࠬ"))
				if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭᷻") in W1lyozPsEhVbFMkL and xY4icgQUj6mPVs73CTKu(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ᷼") in W1lyozPsEhVbFMkL:
					h2hHkw6jETOvqc7B,sqa5mP1EXFHu2fR3Ar7yelgp,xGMCcl8P0dqYyXFwnE4JNRjH = SIgPRFslDqCe2WB8O(W1lyozPsEhVbFMkL)
					if xGMCcl8P0dqYyXFwnE4JNRjH: W1lyozPsEhVbFMkL = xGMCcl8P0dqYyXFwnE4JNRjH[e8XhbyuzvjYkIsJUtB5w]
					else: W1lyozPsEhVbFMkL = NdKhAS6MXVEORLTwob92pxlZ
				if not W1lyozPsEhVbFMkL: ZB3WgSanUwV = Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥ᷽ࠩ")
				else: ZB3WgSanUwV = llQB96aRtAXDdJyW3IkgfOMcKrF8w4(W1lyozPsEhVbFMkL,source,GY9jgon6yhP0IvtCBEJu3)
			if ZB3WgSanUwV in [eGW7cI6aQhr0(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ᷾"),V0VZk9763fusTReHFo4(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ᷿"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭Ḁ"),hCm2fnEXs6Zt(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫḁ")] or len(UTwH7zjZOrmFl)==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠵೥"): break
			elif ZB3WgSanUwV in [R3lezw8h407ZvrAFxT(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪḂ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬḃ"),HVmIrFwau90jQsgiWzExk(u"ࠬࡺࡲࡪࡧࡧࠫḄ")]: break
			else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩḅ"),eGW7cI6aQhr0(u"ࠧศๆ่่ๆࠦไๆࠢํ฽๊๊ࠠอำหࠤ๊๊แࠡ฼ํี์࠭Ḇ"))
	else:
		ZB3WgSanUwV = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬḇ")
		if atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij): ZB3WgSanUwV = llQB96aRtAXDdJyW3IkgfOMcKrF8w4(zehVcU893FC6LEd1Aij,source,GY9jgon6yhP0IvtCBEJu3)
	return ZB3WgSanUwV,UTwH7zjZOrmFl
def oqQC8nstR6pDxvzmrebaG(url,source):
	BfjcMoqOsmdUvZVCHWIyQKi,o0VhOLlDHSsUyBXg9JkW,oikt6P0hOAD5IvnlMpxf1,Ko9uSsHqUljXWnIwv,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2 = url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪḈ") in url:
		BfjcMoqOsmdUvZVCHWIyQKi,o0VhOLlDHSsUyBXg9JkW = url.split(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫḉ"),llxMLe4gobHhsj1WGvd7qmIU)
		o0VhOLlDHSsUyBXg9JkW = o0VhOLlDHSsUyBXg9JkW+Hlp3z0APt1GR4kMYK5xST(u"ࠫࡤࡥࠧḊ")+lRP6GTaZJA1Xw3egLM4(u"ࠬࡥ࡟ࠨḋ")+OOkmZiVcfqlEurM1dHGb(u"࠭࡟ࡠࠩḌ")+IlL8ZnX74Yvep(u"ࠧࡠࡡࠪḍ")+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡡࡢࠫḎ")
		JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2,ueCnDqN7ymJKgjcFRvA, = o0VhOLlDHSsUyBXg9JkW.split(gniNItGL6bKwpEW(u"ࠩࡢࡣࠬḏ"))[:rNyT0edugn(u"࠻೦")]
	if not a0ao2jdlt4r9nhHwpvSgOVGA: a0ao2jdlt4r9nhHwpvSgOVGA = IlL8ZnX74Yvep(u"ࠪ࠴ࠬḐ")
	else: a0ao2jdlt4r9nhHwpvSgOVGA = a0ao2jdlt4r9nhHwpvSgOVGA.replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡵ࠭ḑ"),NdKhAS6MXVEORLTwob92pxlZ).replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,NdKhAS6MXVEORLTwob92pxlZ)
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.strip(lNTJCZeBicWEz0Mg(u"ࠬࡅࠧḒ")).strip(PzIpQnUXxRwNCivDhdakWTE(u"࠭࠯ࠨḓ")).strip(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࠧࠩḔ"))
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,Hlp3z0APt1GR4kMYK5xST(u"ࠨࡪࡲࡷࡹ࠭ḕ"))
	if JHKDFe6Am0ruz8: Ko9uSsHqUljXWnIwv = JHKDFe6Am0ruz8
	else: Ko9uSsHqUljXWnIwv = oikt6P0hOAD5IvnlMpxf1
	Ko9uSsHqUljXWnIwv = msbTrJW03xuvA(Ko9uSsHqUljXWnIwv,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡱࡥࡲ࡫ࠧḖ"))
	JHKDFe6Am0ruz8 = JHKDFe6Am0ruz8.replace(OOkmZiVcfqlEurM1dHGb(u"้ࠪออิาࠩḗ"),NdKhAS6MXVEORLTwob92pxlZ).replace(rNyT0edugn(u"ุࠫ๐ัโำࠪḘ"),NdKhAS6MXVEORLTwob92pxlZ).replace(kb2icmDGVUZfW1OFz7sv(u"ࠬอไࠡࠩḙ"),Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	o0VhOLlDHSsUyBXg9JkW = o0VhOLlDHSsUyBXg9JkW.replace(LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ๅษษืีࠬḚ"),NdKhAS6MXVEORLTwob92pxlZ).replace(QQHFtjcaR2VpnSyTIv(u"ࠧิ์ิๅึ࠭ḛ"),NdKhAS6MXVEORLTwob92pxlZ).replace(gniNItGL6bKwpEW(u"ࠨษ็ࠤࠬḜ"),Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	Ko9uSsHqUljXWnIwv = Ko9uSsHqUljXWnIwv.replace(IlL8ZnX74Yvep(u"่ࠩฬฬฺัࠨḝ"),NdKhAS6MXVEORLTwob92pxlZ).replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠪื๏ืแาࠩḞ"),NdKhAS6MXVEORLTwob92pxlZ).replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫฬ๊ࠠࠨḟ"),Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	return BfjcMoqOsmdUvZVCHWIyQKi,o0VhOLlDHSsUyBXg9JkW,oikt6P0hOAD5IvnlMpxf1,Ko9uSsHqUljXWnIwv,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2
def W3v15nH7GD4aVMdELcP8JAZkFtoB(url,source):
	ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,zb8CjxRJgq093hdBMnTeaGm,tYMCKl4JFhzA0XirGBamkb1,B0SmsWZEvX43PK9eGnH6phVNM,eecXAVTfIujZra4wbqkNpLUhF,QvL8iHu1yk3GzN0lPXFnox5OpS = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,None,None,None,None,None
	BfjcMoqOsmdUvZVCHWIyQKi,o0VhOLlDHSsUyBXg9JkW,oikt6P0hOAD5IvnlMpxf1,Ko9uSsHqUljXWnIwv,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2 = oqQC8nstR6pDxvzmrebaG(url,source)
	if gniNItGL6bKwpEW(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ḡ") in url:
		if   GY9jgon6yhP0IvtCBEJu3==IlL8ZnX74Yvep(u"࠭ࡥ࡮ࡤࡨࡨࠬḡ"): GY9jgon6yhP0IvtCBEJu3 = Vwgflszp4WRA93kx6hvdua21HX5cOb+hCm2fnEXs6Zt(u"ࠧๆใู่ࠬḢ")
		elif GY9jgon6yhP0IvtCBEJu3==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡹࡤࡸࡨ࡮ࠧḣ"): GY9jgon6yhP0IvtCBEJu3 = Vwgflszp4WRA93kx6hvdua21HX5cOb+OOkmZiVcfqlEurM1dHGb(u"ࠩࠨู้อ็ะหࠪḤ")
		elif GY9jgon6yhP0IvtCBEJu3==NeU6uRGpECkvMV5jf(u"ࠪࡦࡴࡺࡨࠨḥ"): GY9jgon6yhP0IvtCBEJu3 = Vwgflszp4WRA93kx6hvdua21HX5cOb+hCm2fnEXs6Zt(u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭Ḧ")
		elif GY9jgon6yhP0IvtCBEJu3==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧḧ"): GY9jgon6yhP0IvtCBEJu3 = Vwgflszp4WRA93kx6hvdua21HX5cOb+IlL8ZnX74Yvep(u"࠭ࠥࠦࠧอั๊๐ไࠨḨ")
		elif GY9jgon6yhP0IvtCBEJu3==NdKhAS6MXVEORLTwob92pxlZ: GY9jgon6yhP0IvtCBEJu3 = Vwgflszp4WRA93kx6hvdua21HX5cOb+OOkmZiVcfqlEurM1dHGb(u"ࠧࠦࠧࠨࠩࠬḩ")
		if uJqZbeXK04CRjoQ!=NdKhAS6MXVEORLTwob92pxlZ:
			if fOc18oTm5hsdD4pVZQj(u"ࠨ࡯ࡳ࠸ࠬḪ") not in uJqZbeXK04CRjoQ: uJqZbeXK04CRjoQ = fOc18oTm5hsdD4pVZQj(u"ࠩࠨࠫḫ")+uJqZbeXK04CRjoQ
			uJqZbeXK04CRjoQ = Vwgflszp4WRA93kx6hvdua21HX5cOb+uJqZbeXK04CRjoQ
		if a0ao2jdlt4r9nhHwpvSgOVGA!=NdKhAS6MXVEORLTwob92pxlZ:
			a0ao2jdlt4r9nhHwpvSgOVGA = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭Ḭ")+a0ao2jdlt4r9nhHwpvSgOVGA
			a0ao2jdlt4r9nhHwpvSgOVGA = Vwgflszp4WRA93kx6hvdua21HX5cOb+a0ao2jdlt4r9nhHwpvSgOVGA[-xY4icgQUj6mPVs73CTKu(u"࠿೧"):]
	if   Hlp3z0APt1GR4kMYK5xST(u"ࠫࡆࡑࡏࡂࡏࠪḭ")		in source: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif hCm2fnEXs6Zt(u"ࠬࡇࡋࡘࡃࡐࠫḮ")		in source: zb8CjxRJgq093hdBMnTeaGm	= ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡡ࡬ࡹࡤࡱࠬḯ")
	elif lNTJCZeBicWEz0Mg(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩḰ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧḱ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif HVmIrFwau90jQsgiWzExk(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫḲ")		in source: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠪࡥࡱࡧࡲࡢࡤࠪḳ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡫ࡧࡳࡦ࡮ࠪḴ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡺ࠷࡮ࡧࡨࡰࠬḵ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif lRP6GTaZJA1Xw3egLM4(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭Ḷ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩḷ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif HVmIrFwau90jQsgiWzExk(u"ࠨࡨࡤ࡮ࡪࡸࠧḸ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠩไะึ࠭ḹ")			in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡪࡦࡰࡥࡳࠩḺ")
	elif QQHFtjcaR2VpnSyTIv(u"ࠫๆ๊ำุ์้ࠫḻ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= OOkmZiVcfqlEurM1dHGb(u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨḼ")
	elif HVmIrFwau90jQsgiWzExk(u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭ḽ")		in BfjcMoqOsmdUvZVCHWIyQKi:   zb8CjxRJgq093hdBMnTeaGm	= R3lezw8h407ZvrAFxT(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧḾ")
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨḿ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif OOkmZiVcfqlEurM1dHGb(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩṀ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫṁ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif HVmIrFwau90jQsgiWzExk(u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬṂ")		in JHKDFe6Am0ruz8:   zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪṃ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif lRP6GTaZJA1Xw3egLM4(u"࠭ࡢࡰ࡭ࡵࡥࠬṄ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡵࡸࡩࡹࡳ࠭ṅ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif QQHFtjcaR2VpnSyTIv(u"ࠨࡶࡹ࡯ࡸࡧࠧṆ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif fOc18oTm5hsdD4pVZQj(u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪṇ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif lrtFSogC8Nh9(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬṈ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif lRP6GTaZJA1Xw3egLM4(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ṉ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif gniNItGL6bKwpEW(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧṊ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif lrtFSogC8Nh9(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭ṋ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif V0VZk9763fusTReHFo4(u"ࠧࡦࡩࡼࡲࡴࡽࠧṌ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif lrtFSogC8Nh9(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪṍ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif NeU6uRGpECkvMV5jf(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫṎ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif HVmIrFwau90jQsgiWzExk(u"ࠪࡶࡪࡪ࡭ࡰࡦࡻࠫṏ")	 	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= lrtFSogC8Nh9(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬṐ")
	elif lNTJCZeBicWEz0Mg(u"ࠬࡿ࡯ࡶࡶࡸࠫṑ")	 	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧṒ")
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧṓ")	 	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩṔ")
	elif kb2icmDGVUZfW1OFz7sv(u"ࠩࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨṕ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= Ko9uSsHqUljXWnIwv
	elif xY4icgQUj6mPVs73CTKu(u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨṖ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= xY4icgQUj6mPVs73CTKu(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨṗ")
	elif rNyT0edugn(u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧṘ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= V0VZk9763fusTReHFo4(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨṙ")
	elif rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨṚ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= OOkmZiVcfqlEurM1dHGb(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪṛ")
	elif JGwsL21ZRlqSrWxEmF(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫṜ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬṝ")
	elif IlL8ZnX74Yvep(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪṞ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫṟ")
	elif kb2icmDGVUZfW1OFz7sv(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩṠ")	in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡪࡰࡩࡰࡦࡳࠧṡ")
	elif HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩṢ")		in oikt6P0hOAD5IvnlMpxf1: zb8CjxRJgq093hdBMnTeaGm	= pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪṣ")
	elif hCm2fnEXs6Zt(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭Ṥ")	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= V0VZk9763fusTReHFo4(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧṥ")
	elif kb2icmDGVUZfW1OFz7sv(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭Ṧ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= xY4icgQUj6mPVs73CTKu(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧṧ")
	elif HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩṨ")	 	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= QQHFtjcaR2VpnSyTIv(u"ࠨࡥࡤࡸࡨ࡮ࠧṩ")
	elif eGW7cI6aQhr0(u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪṪ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫṫ")
	elif lrtFSogC8Nh9(u"ࠫࡻ࡯ࡤࡣ࡯ࠪṬ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= R3lezw8h407ZvrAFxT(u"ࠬࡼࡩࡥࡤࡰࠫṭ")
	elif Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡶࡪࡦ࡫ࡨࠬṮ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠧ࡮ࡻࡹ࡭ࡩ࠭ṯ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠨ࡯ࡼࡺ࡮࡯ࡤࠨṰ")		in oikt6P0hOAD5IvnlMpxf1: eecXAVTfIujZra4wbqkNpLUhF	= Ko9uSsHqUljXWnIwv
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫṱ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= JGwsL21ZRlqSrWxEmF(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬṲ")
	elif NeU6uRGpECkvMV5jf(u"ࠫ࡬ࡵࡶࡪࡦࠪṳ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= rNyT0edugn(u"ࠬ࡭࡯ࡷ࡫ࡧࠫṴ")
	elif pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨṵ") 	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩṶ")
	elif wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫṷ")	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= lrtFSogC8Nh9(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬṸ")
	elif hCm2fnEXs6Zt(u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨṹ")	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩṺ")
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩṻ") 	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= fOc18oTm5hsdD4pVZQj(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪṼ")
	elif pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨṽ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= lrtFSogC8Nh9(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩṾ")
	elif WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡸࡴࡵ࠭ṿ") 			in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= hCm2fnEXs6Zt(u"ࠪࡹࡵࡨ࡯࡮ࠩẀ")
	elif wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡺࡶࡢࠨẁ") 			in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= lRP6GTaZJA1Xw3egLM4(u"ࠬࡻࡰࡣࡱࡰࠫẂ")
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭ẃ") 		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧẄ")
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡸ࡮ࠫẅ") 			in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= hCm2fnEXs6Zt(u"ࠩࡹ࡯ࠬẆ")
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬẇ") 	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭Ẉ")
	elif OOkmZiVcfqlEurM1dHGb(u"ࠬࡼࡩࡥࡤࡲࡦࠬẉ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= IlL8ZnX74Yvep(u"࠭ࡶࡪࡦࡥࡳࡧ࠭Ẋ")
	elif JGwsL21ZRlqSrWxEmF(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧẋ") 		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= hCm2fnEXs6Zt(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨẌ")
	elif QQHFtjcaR2VpnSyTIv(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ẍ") 	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= QQHFtjcaR2VpnSyTIv(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧẎ")
	elif xY4icgQUj6mPVs73CTKu(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨẏ")	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= IlL8ZnX74Yvep(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩẐ")
	elif IlL8ZnX74Yvep(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪẑ")	in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫẒ")
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨẓ")		in oikt6P0hOAD5IvnlMpxf1: tYMCKl4JFhzA0XirGBamkb1	= IlL8ZnX74Yvep(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩẔ")
	if   zb8CjxRJgq093hdBMnTeaGm:	ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = NOrchaEV1iIZ87Uzlwgum(u"ࠪาฬ฻ࠧẕ"),zb8CjxRJgq093hdBMnTeaGm
	elif eecXAVTfIujZra4wbqkNpLUhF:		ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = IlL8ZnX74Yvep(u"๋ࠫࠪอะัࠪẖ"),eecXAVTfIujZra4wbqkNpLUhF
	elif tYMCKl4JFhzA0XirGBamkb1:		ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = R3lezw8h407ZvrAFxT(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪẗ"),tYMCKl4JFhzA0XirGBamkb1
	elif B0SmsWZEvX43PK9eGnH6phVNM:	ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = NeU6uRGpECkvMV5jf(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬẘ"),B0SmsWZEvX43PK9eGnH6phVNM
	elif QvL8iHu1yk3GzN0lPXFnox5OpS:	ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧẙ"),Ko9uSsHqUljXWnIwv
	else:			ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8 = kb2icmDGVUZfW1OFz7sv(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩẚ"),Ko9uSsHqUljXWnIwv
	return ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA
def MenmyB8ldJo3VZ(BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl):
	DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv = [],[]
	for title,zehVcU893FC6LEd1Aij in zip(IGEpKNCaiLMT,UTwH7zjZOrmFl):
		if atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij):
			DDviHT4pFVhgwaL.append(title)
			oDhlaxn0EqyYikcHrmZBN8uv.append(zehVcU893FC6LEd1Aij)
	if not oDhlaxn0EqyYikcHrmZBN8uv and not BGulEd0o6ZQLzk5WHwMs2bN: BGulEd0o6ZQLzk5WHwMs2bN = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡉࡥ࡮ࡲࡥࡥࠩẛ")
	return BGulEd0o6ZQLzk5WHwMs2bN,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv
def HkEpUai5tocg6mTZuCwrFPM(url,source):
	BfjcMoqOsmdUvZVCHWIyQKi,eecXAVTfIujZra4wbqkNpLUhF,oikt6P0hOAD5IvnlMpxf1,Ko9uSsHqUljXWnIwv,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2 = oqQC8nstR6pDxvzmrebaG(url,source)
	if   NOrchaEV1iIZ87Uzlwgum(u"ࠪࡽࡴࡻࡴࡶࠩẜ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧẝ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬẞ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩẟ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	elif lrtFSogC8Nh9(u"ࠧࡲࡸ࡬ࡨࠬẠ")			in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = pHIji6rfbSgCK0Ph7ZG(BfjcMoqOsmdUvZVCHWIyQKi)
	elif WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡨ࡬ࡰࡲ࡫ࡹࠨạ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = pHIji6rfbSgCK0Ph7ZG(BfjcMoqOsmdUvZVCHWIyQKi)
	elif gniNItGL6bKwpEW(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪẢ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = pHIji6rfbSgCK0Ph7ZG(BfjcMoqOsmdUvZVCHWIyQKi)
	elif hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡅࡐࡕࡁࡎࠩả")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Nbylaq3nUL(BfjcMoqOsmdUvZVCHWIyQKi,JHKDFe6Am0ruz8)
	elif fOc18oTm5hsdD4pVZQj(u"ࠫࡆࡑࡗࡂࡏࠪẤ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = dKusGQWL0z(BfjcMoqOsmdUvZVCHWIyQKi,GY9jgon6yhP0IvtCBEJu3,a0ao2jdlt4r9nhHwpvSgOVGA)
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧấ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = xVDPCTs6jX(BfjcMoqOsmdUvZVCHWIyQKi)
	elif NeU6uRGpECkvMV5jf(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧẦ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = JGwsL21ZRlqSrWxEmF(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪầ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	elif NeU6uRGpECkvMV5jf(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨẨ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = IOY8EXZopF(BfjcMoqOsmdUvZVCHWIyQKi)
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫẩ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = H6HiytTblh(BfjcMoqOsmdUvZVCHWIyQKi)
	elif fOc18oTm5hsdD4pVZQj(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬẪ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = TsmavPO7dc(BfjcMoqOsmdUvZVCHWIyQKi)
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ẫ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ElC38ro1qU(BfjcMoqOsmdUvZVCHWIyQKi)
	elif NOrchaEV1iIZ87Uzlwgum(u"࡙ࠬࡈࡐࡈࡋࡅࠬẬ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = fx0PH6CZqm(BfjcMoqOsmdUvZVCHWIyQKi)
	elif gniNItGL6bKwpEW(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨậ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = zhlqBY1Ev2(BfjcMoqOsmdUvZVCHWIyQKi,rDOMITncUW9pB8ktAQS2)
	elif wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧẮ")		in source: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ss7D4f8nvo(BfjcMoqOsmdUvZVCHWIyQKi)
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪắ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = RQzfIOVrm3(BfjcMoqOsmdUvZVCHWIyQKi)
	elif lNTJCZeBicWEz0Mg(u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬẰ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = er3kMPhVNc(BfjcMoqOsmdUvZVCHWIyQKi)
	elif NeU6uRGpECkvMV5jf(u"ࠪࡥࡱࡧࡲࡢࡤࠪằ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = FKGWstNv90lZB(BfjcMoqOsmdUvZVCHWIyQKi)
	elif xY4icgQUj6mPVs73CTKu(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭Ẳ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = WrGxOkJPCN(BfjcMoqOsmdUvZVCHWIyQKi)
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧẳ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = WrGxOkJPCN(BfjcMoqOsmdUvZVCHWIyQKi)
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡥࡨࡻࡱࡳࡼ࠭Ẵ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NNqGlbdzVE(BfjcMoqOsmdUvZVCHWIyQKi)
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡵࡸࡩࡹࡳ࠭ẵ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = zJrlt5mZ9w(BfjcMoqOsmdUvZVCHWIyQKi)
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡶࡹ࡯ࡸࡧࠧẶ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = zJrlt5mZ9w(BfjcMoqOsmdUvZVCHWIyQKi)
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫặ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = zJrlt5mZ9w(BfjcMoqOsmdUvZVCHWIyQKi)
	elif IlL8ZnX74Yvep(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬẸ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = tBpA6DSOTz(BfjcMoqOsmdUvZVCHWIyQKi)
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ẹ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = T3TQo2Fr5e(BfjcMoqOsmdUvZVCHWIyQKi)
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧẺ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = OyDzTmkNf8BHKeV0Y(BfjcMoqOsmdUvZVCHWIyQKi)
	elif vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡶࡴ࠶ࡸࠫẻ")			in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ggaX57uqsJ(BfjcMoqOsmdUvZVCHWIyQKi)
	elif JGwsL21ZRlqSrWxEmF(u"ࠧࡧࡣ࡭ࡩࡷ࠭Ẽ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = jTdEqINm1i(BfjcMoqOsmdUvZVCHWIyQKi)
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩẽ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = igcP5NRLxS(BfjcMoqOsmdUvZVCHWIyQKi)
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪẾ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = igcP5NRLxS(BfjcMoqOsmdUvZVCHWIyQKi)
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧế")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = KkQ9eFYNl2(BfjcMoqOsmdUvZVCHWIyQKi)
	elif gniNItGL6bKwpEW(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧỀ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = KkQ9eFYNl2(BfjcMoqOsmdUvZVCHWIyQKi)
	elif xY4icgQUj6mPVs73CTKu(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬề")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Mv1S0NnoLc(BfjcMoqOsmdUvZVCHWIyQKi)
	elif V0VZk9763fusTReHFo4(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭Ể")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = W4HYvIXqED52Gm7MFNgdOJiB(BfjcMoqOsmdUvZVCHWIyQKi)
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡣࡱ࡮ࡶࡦ࠭ể")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = gg34ZwSuqD(BfjcMoqOsmdUvZVCHWIyQKi)
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭Ễ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = rkeSbyBcK6(BfjcMoqOsmdUvZVCHWIyQKi)
	elif PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫễ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = qqUfHpWYb2(BfjcMoqOsmdUvZVCHWIyQKi)
	elif HVmIrFwau90jQsgiWzExk(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩỆ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = WMNy1hKjbO(BfjcMoqOsmdUvZVCHWIyQKi)
	elif lRP6GTaZJA1Xw3egLM4(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩệ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	elif rNyT0edugn(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭Ỉ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = duEz093LZo(BfjcMoqOsmdUvZVCHWIyQKi)
	elif xY4icgQUj6mPVs73CTKu(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬỉ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Y2SNCRe4AX(BfjcMoqOsmdUvZVCHWIyQKi)
	elif OOkmZiVcfqlEurM1dHGb(u"ࠧࡶࡲࡥࡥࡲ࠭Ị") 		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	else: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫị"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	if BGulEd0o6ZQLzk5WHwMs2bN not in [fOc18oTm5hsdD4pVZQj(u"ࠩࠪỌ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨọ"),OOkmZiVcfqlEurM1dHGb(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧỎ")]: BGulEd0o6ZQLzk5WHwMs2bN = xY4icgQUj6mPVs73CTKu(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨỏ")+BGulEd0o6ZQLzk5WHwMs2bN
	return BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
def OOHUFWfhldq3LkZvDsMp9YVb62en(eez2krpcog8fAXd9IhOi,url,source,UfsQbH5JM7vg32G1lX8EN):
	global Af0Qa6dFT7EZPSNJMeLmU,tXSljcPk9ZBH4wumMLIFO,Y5cBahqQ0An6x8b,R9THEsIkMJv6m05VAGo,QIAmjsvXplbk0ce24dSNgH7MY
	q6M5LEtYC27Vz = []
	for QvL8iHu1yk3GzN0lPXFnox5OpS in [tXSljcPk9ZBH4wumMLIFO,Y5cBahqQ0An6x8b,R9THEsIkMJv6m05VAGo,QIAmjsvXplbk0ce24dSNgH7MY]: QvL8iHu1yk3GzN0lPXFnox5OpS[UfsQbH5JM7vg32G1lX8EN] = ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧỐ"),[],[]
	ZKIsyn4MmOwQjJxedrHN2TFzbv,kkV1FutoS8g7cTwaOjA5URvi = [krY0o8ZJs6K5GO2npb9I,dI04fJF3jLMAzrVTcC1nSUBui7v,ltJp5PhoC8ir,mVBhzgcyWRl1HZfo],[]
	if NOrchaEV1iIZ87Uzlwgum(u"ࠧࡧࡴࡧࡰࠬố") in url: ZKIsyn4MmOwQjJxedrHN2TFzbv,kkV1FutoS8g7cTwaOjA5URvi = [krY0o8ZJs6K5GO2npb9I,dI04fJF3jLMAzrVTcC1nSUBui7v,mVBhzgcyWRl1HZfo],[R9THEsIkMJv6m05VAGo]
	if xY4icgQUj6mPVs73CTKu(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩỒ") in url: ZKIsyn4MmOwQjJxedrHN2TFzbv,kkV1FutoS8g7cTwaOjA5URvi = [krY0o8ZJs6K5GO2npb9I],[Y5cBahqQ0An6x8b,R9THEsIkMJv6m05VAGo,QIAmjsvXplbk0ce24dSNgH7MY]
	for QvL8iHu1yk3GzN0lPXFnox5OpS in kkV1FutoS8g7cTwaOjA5URvi: QvL8iHu1yk3GzN0lPXFnox5OpS[UfsQbH5JM7vg32G1lX8EN] = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡖ࡯࡮ࡶࡰࡦࡦࠪồ"),[],[]
	for QvL8iHu1yk3GzN0lPXFnox5OpS in ZKIsyn4MmOwQjJxedrHN2TFzbv:
		vZAh7YG5N1r = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=QvL8iHu1yk3GzN0lPXFnox5OpS,args=(url,source,UfsQbH5JM7vg32G1lX8EN))
		q6M5LEtYC27Vz.append(vZAh7YG5N1r)
		vZAh7YG5N1r.start()
		XJ62UBRmIqFvfiNTQj.sleep(rNyT0edugn(u"࠱೨"))
	D7vgeGb3xHi,MmNi5TUcL7KBty41XkEVdAHhWqlP20,rrxAmqsjLIUMSGnWl28F,hibQWZOXwTEg = f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s,f4vncKMRlXG9s
	timeout,step = Tzx81Wb0RZC4ID5AyiU2(u"࠴࠲೩"),cCRvAuJQfjBpTg0PbYiaNO87
	for f0g9moODEt2N in range(timeout//step):
		if not D7vgeGb3xHi and tXSljcPk9ZBH4wumMLIFO[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w]!=lNTJCZeBicWEz0Mg(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫỔ"): D7vgeGb3xHi = k6apiPAlLKM1ed8J42RjHh0o
		if not MmNi5TUcL7KBty41XkEVdAHhWqlP20 and Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w]!=QQHFtjcaR2VpnSyTIv(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬổ"): MmNi5TUcL7KBty41XkEVdAHhWqlP20 = k6apiPAlLKM1ed8J42RjHh0o
		if not rrxAmqsjLIUMSGnWl28F and R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w]!=LtGoXlQ2IYxqTJRySE6udfW98(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭Ỗ"): rrxAmqsjLIUMSGnWl28F = k6apiPAlLKM1ed8J42RjHh0o
		if not hibQWZOXwTEg and QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w]!=fOc18oTm5hsdD4pVZQj(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧỗ"): hibQWZOXwTEg = k6apiPAlLKM1ed8J42RjHh0o
		if D7vgeGb3xHi and MmNi5TUcL7KBty41XkEVdAHhWqlP20 and rrxAmqsjLIUMSGnWl28F and hibQWZOXwTEg: break
		if not tXSljcPk9ZBH4wumMLIFO[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w] and tXSljcPk9ZBH4wumMLIFO[UfsQbH5JM7vg32G1lX8EN][cCRvAuJQfjBpTg0PbYiaNO87]: break
		if not Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w] and Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN][cCRvAuJQfjBpTg0PbYiaNO87]: break
		if not R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w] and R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN][cCRvAuJQfjBpTg0PbYiaNO87]: break
		if not QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN][e8XhbyuzvjYkIsJUtB5w] and QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN][cCRvAuJQfjBpTg0PbYiaNO87]: break
		XJ62UBRmIqFvfiNTQj.sleep(step)
	for vZAh7YG5N1r in q6M5LEtYC27Vz: vZAh7YG5N1r.join(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠳೪"))
	PkZ0sEXJCfu9MvK7RldFwtLx = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭Ộ")
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = tXSljcPk9ZBH4wumMLIFO[UfsQbH5JM7vg32G1lX8EN]
	UTwH7zjZOrmFl = jjP7EciLOl(UTwH7zjZOrmFl)
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	if BGulEd0o6ZQLzk5WHwMs2bN==OOkmZiVcfqlEurM1dHGb(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ộ") or UTwH7zjZOrmFl: return PkZ0sEXJCfu9MvK7RldFwtLx,BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	eez2krpcog8fAXd9IhOi += eGW7cI6aQhr0(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠣࠫỚ")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)[:QQHFtjcaR2VpnSyTIv(u"࠻࠴೫")]
	PkZ0sEXJCfu9MvK7RldFwtLx = QQHFtjcaR2VpnSyTIv(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩớ")
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN]
	UTwH7zjZOrmFl = jjP7EciLOl(UTwH7zjZOrmFl)
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	if BGulEd0o6ZQLzk5WHwMs2bN==kb2icmDGVUZfW1OFz7sv(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩỜ") or UTwH7zjZOrmFl: return PkZ0sEXJCfu9MvK7RldFwtLx,BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	eez2krpcog8fAXd9IhOi += eGW7cI6aQhr0(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧờ")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)[:JGwsL21ZRlqSrWxEmF(u"࠼࠵೬")]
	PkZ0sEXJCfu9MvK7RldFwtLx = kb2icmDGVUZfW1OFz7sv(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠬỞ")
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN]
	UTwH7zjZOrmFl = jjP7EciLOl(UTwH7zjZOrmFl)
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	if BGulEd0o6ZQLzk5WHwMs2bN==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬở") or UTwH7zjZOrmFl: return PkZ0sEXJCfu9MvK7RldFwtLx,BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	eez2krpcog8fAXd9IhOi += hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠺࠺ࠡࠢࠪỠ")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)[:YJpWv4QzC7sx8INVPukeZiOD03K(u"࠽࠶೭")]
	PkZ0sEXJCfu9MvK7RldFwtLx = xY4icgQUj6mPVs73CTKu(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨỡ")
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN]
	UTwH7zjZOrmFl = jjP7EciLOl(UTwH7zjZOrmFl)
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	if BGulEd0o6ZQLzk5WHwMs2bN==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨỢ") or UTwH7zjZOrmFl: return PkZ0sEXJCfu9MvK7RldFwtLx,BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	eez2krpcog8fAXd9IhOi += OOkmZiVcfqlEurM1dHGb(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠷࠽ࠤࠥ࠭ợ")+BGulEd0o6ZQLzk5WHwMs2bN.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)[:IlL8ZnX74Yvep(u"࠾࠰೮")]
	Af0Qa6dFT7EZPSNJMeLmU[UfsQbH5JM7vg32G1lX8EN] = eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
	return PkZ0sEXJCfu9MvK7RldFwtLx,eez2krpcog8fAXd9IhOi,IGEpKNCaiLMT,UTwH7zjZOrmFl
def krY0o8ZJs6K5GO2npb9I(url,source,UfsQbH5JM7vg32G1lX8EN):
	BfjcMoqOsmdUvZVCHWIyQKi,eecXAVTfIujZra4wbqkNpLUhF,oikt6P0hOAD5IvnlMpxf1,Ko9uSsHqUljXWnIwv,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,rDOMITncUW9pB8ktAQS2 = oqQC8nstR6pDxvzmrebaG(url,source)
	UTwH7zjZOrmFl = []
	if Hlp3z0APt1GR4kMYK5xST(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪỤ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = rkeSbyBcK6(url)
	elif lrtFSogC8Nh9(u"࠭ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࠬụ") in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = fQ6n9eLcvmX2joCtJlMTFU7A8rSDP1(url)
	elif fOc18oTm5hsdD4pVZQj(u"ࠧࡺࡱࡸࡸࡺ࠭Ủ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ZXBg7eKNj6UyVl(url)
	elif WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨủ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ZXBg7eKNj6UyVl(url)
	elif HVmIrFwau90jQsgiWzExk(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨỨ")	in url   : BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = eCNSW8zE6AbHs0KVBXcLu(url)
	elif LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬứ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = SIgPRFslDqCe2WB8O(url)
	elif vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨࠬỪ")		in url   : BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = xVDPCTs6jX(url)
	elif lrtFSogC8Nh9(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨừ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = YLntPJTBomgMlH(url)
	elif eGW7cI6aQhr0(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧỬ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = JD05CQjgRdFv6kX7cfipsNLVzHhw(url)
	elif vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨử")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Dydjg3nW4sRIa5m9NKzfwkB(url)
	elif wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡧ࠸ࡸࡸࡧࡲࠨỮ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = u2FBJOfvix8ECz6b(url)
	elif IlL8ZnX74Yvep(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨữ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = QNCoXB036udyLhTtIZDP15qEHkJmVz(url)
	elif NeU6uRGpECkvMV5jf(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭Ự")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = QNCoXB036udyLhTtIZDP15qEHkJmVz(url)
	elif hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡺࡶࡢࡢ࡯ࠪự") 		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	elif Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧỲ") 	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = xxjKtSkWMBnqDVU(url)
	elif wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩỳ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = wxciAvM1GDBT(url)
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫỴ") 	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = RvVIaX5d803B(url)
	elif OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩỵ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ep20hACWNc(url)
	elif lNTJCZeBicWEz0Mg(u"ࠩࡸࡴࡧ࠭Ỷ") 			in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = AzJg5ZHj6spGtiwRDKYFcyOqEuQUv7(url)
	elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡹࡵࡶࠧỷ") 			in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = AzJg5ZHj6spGtiwRDKYFcyOqEuQUv7(url)
	elif vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫỸ") 		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = Gr28xomQivj3VHtsFnbWdLhguSfp(url)
	elif xY4icgQUj6mPVs73CTKu(u"ࠬࡼ࡫ࠨỹ")	 		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = wWfenLMcu4s6(BfjcMoqOsmdUvZVCHWIyQKi)
	elif NOrchaEV1iIZ87Uzlwgum(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨỺ") 	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = ug4d8qH5DlQXALm1F(url)
	elif OOkmZiVcfqlEurM1dHGb(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧỻ")		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = dRMvbBfZVFwHA0JGeOT2r1yiS(url)
	elif eGW7cI6aQhr0(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨỼ") 		in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = HOTqs9aZBf(url)
	elif hCm2fnEXs6Zt(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ỽ") 	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = zwrI0NtL7BYRvV6W59sS4ofZyD(url)
	elif kb2icmDGVUZfW1OFz7sv(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧỾ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = H3m7LsRVaGYB8gK5twFyblzUZ(url)
	elif eGW7cI6aQhr0(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨỿ")	in oikt6P0hOAD5IvnlMpxf1: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = mCV9TYUjiWF6qa5REXLuNBxb0so(url)
	else: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[],[]
	global tXSljcPk9ZBH4wumMLIFO
	if BGulEd0o6ZQLzk5WHwMs2bN not in [pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬ࠭ἀ"),xY4icgQUj6mPVs73CTKu(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫἁ"),kb2icmDGVUZfW1OFz7sv(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪἂ")]: BGulEd0o6ZQLzk5WHwMs2bN = rNyT0edugn(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫἃ")+BGulEd0o6ZQLzk5WHwMs2bN
	tXSljcPk9ZBH4wumMLIFO[UfsQbH5JM7vg32G1lX8EN] = BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	return
def dI04fJF3jLMAzrVTcC1nSUBui7v(url,source,UfsQbH5JM7vg32G1lX8EN):
	global Y5cBahqQ0An6x8b
	if NeU6uRGpECkvMV5jf(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪἄ") in url:
		Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN] = xY4icgQUj6mPVs73CTKu(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡙ࠥ࡫ࡪࡲࡳࡩࡩ࠭ἅ"),[],[]
		return
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[],[]
	if atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(url):
		BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	if not UTwH7zjZOrmFl:
		BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = z2ofs5BIu8(url)
	if not UTwH7zjZOrmFl:
		BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = fMPmhBIROjZLpE4nQckF8b16TJoC(url)
	if not UTwH7zjZOrmFl:
		if BGulEd0o6ZQLzk5WHwMs2bN==WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἆ"): BGulEd0o6ZQLzk5WHwMs2bN = NdKhAS6MXVEORLTwob92pxlZ
		Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN] = R3lezw8h407ZvrAFxT(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨἇ")+BGulEd0o6ZQLzk5WHwMs2bN,[],[]
		return
	Y5cBahqQ0An6x8b[UfsQbH5JM7vg32G1lX8EN] = BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
	return
def ltJp5PhoC8ir(url,source,UfsQbH5JM7vg32G1lX8EN):
	ihuUeAVfaSbXMNn = NdKhAS6MXVEORLTwob92pxlZ
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = f4vncKMRlXG9s
	try:
		import resolveurl as VYzHwT4IDNBCeEu2yUW7gQ1k
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = VYzHwT4IDNBCeEu2yUW7gQ1k.resolve(url)
	except Exception as hcKrT3bew489nFp1U0: ihuUeAVfaSbXMNn = str(hcKrT3bew489nFp1U0)
	global R9THEsIkMJv6m05VAGo
	if not UEsxyfd8rZMLOHgzc6emSFKD0ktYiT:
		if ihuUeAVfaSbXMNn==NdKhAS6MXVEORLTwob92pxlZ:
			ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
			if ihuUeAVfaSbXMNn!=WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩἈ"): hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
		BGulEd0o6ZQLzk5WHwMs2bN = ihuUeAVfaSbXMNn.splitlines()[-llxMLe4gobHhsj1WGvd7qmIU]
		R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN] = lrtFSogC8Nh9(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪἉ")+BGulEd0o6ZQLzk5WHwMs2bN,[],[]
		return
	R9THEsIkMJv6m05VAGo[UfsQbH5JM7vg32G1lX8EN] = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[UEsxyfd8rZMLOHgzc6emSFKD0ktYiT]
	return
def mVBhzgcyWRl1HZfo(url,source,UfsQbH5JM7vg32G1lX8EN):
	ihuUeAVfaSbXMNn = NdKhAS6MXVEORLTwob92pxlZ
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = f4vncKMRlXG9s
	try:
		import yt_dlp as B3cEAr0wqL14efR
		QmOIvPrSYsVTXyoqiM4Kc1xn8g0hNJ = B3cEAr0wqL14efR.YoutubeDL({PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡰࡲࡣࡨࡵ࡬ࡰࡴࠪἊ"): k6apiPAlLKM1ed8J42RjHh0o})
		UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QmOIvPrSYsVTXyoqiM4Kc1xn8g0hNJ.extract_info(url,download=f4vncKMRlXG9s)
	except Exception as hcKrT3bew489nFp1U0: ihuUeAVfaSbXMNn = str(hcKrT3bew489nFp1U0)
	global QIAmjsvXplbk0ce24dSNgH7MY
	if not UEsxyfd8rZMLOHgzc6emSFKD0ktYiT or xY4icgQUj6mPVs73CTKu(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪἋ") not in list(UEsxyfd8rZMLOHgzc6emSFKD0ktYiT.keys()):
		if ihuUeAVfaSbXMNn==NdKhAS6MXVEORLTwob92pxlZ:
			ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
			if ihuUeAVfaSbXMNn!=rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭Ἄ"): hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
		BGulEd0o6ZQLzk5WHwMs2bN = ihuUeAVfaSbXMNn.splitlines()[-llxMLe4gobHhsj1WGvd7qmIU]
		QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN] = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧἍ")+BGulEd0o6ZQLzk5WHwMs2bN,[],[]
	else:
		IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
		for zehVcU893FC6LEd1Aij in UEsxyfd8rZMLOHgzc6emSFKD0ktYiT[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭Ἆ")]:
			IGEpKNCaiLMT.append(zehVcU893FC6LEd1Aij[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡦࡰࡴࡰࡥࡹ࠭Ἇ")])
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij[Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡶࡴ࡯ࠫἐ")])
		QIAmjsvXplbk0ce24dSNgH7MY[UfsQbH5JM7vg32G1lX8EN] = NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
	return
def z2ofs5BIu8(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡉࡈࡘࠬἑ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡅࡅࡋࡕࡉࡈ࡚࡟ࡖࡔࡏ࠱࠶ࡹࡴࠨἒ"))
	headers = VNc1u4edS90FK5W6bsMgQC2B.headers
	if NeU6uRGpECkvMV5jf(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬἓ") in list(headers.keys()):
		zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[lNTJCZeBicWEz0Mg(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ἔ")]
		if atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij): return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return V0VZk9763fusTReHFo4(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨἕ"),[],[]
def jjP7EciLOl(myEZsYk69Jj02AKPHQ7zgdh3VtU4I):
	if rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭࡬ࡪࡵࡷࠫ἖") in str(type(myEZsYk69Jj02AKPHQ7zgdh3VtU4I)):
		oDhlaxn0EqyYikcHrmZBN8uv = []
		for zehVcU893FC6LEd1Aij in myEZsYk69Jj02AKPHQ7zgdh3VtU4I:
			if OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡴࡶࡵࠫ἗") in str(type(zehVcU893FC6LEd1Aij)): zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			oDhlaxn0EqyYikcHrmZBN8uv.append(zehVcU893FC6LEd1Aij)
	else: oDhlaxn0EqyYikcHrmZBN8uv = myEZsYk69Jj02AKPHQ7zgdh3VtU4I.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ).replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	return oDhlaxn0EqyYikcHrmZBN8uv
def vvO4dcYPlRW8E2rLgQoZqw0e(xGMCcl8P0dqYyXFwnE4JNRjH,source):
	data = hVmfOZ06UbnD2odNq(ZFMPvkNQbT2cHiUj,lRP6GTaZJA1Xw3egLM4(u"ࠨ࡮࡬ࡷࡹ࠭Ἐ"),eGW7cI6aQhr0(u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪἙ"),xGMCcl8P0dqYyXFwnE4JNRjH)
	if data:
		IGEpKNCaiLMT,UTwH7zjZOrmFl = zip(*data)
		IGEpKNCaiLMT,UTwH7zjZOrmFl = list(IGEpKNCaiLMT),list(UTwH7zjZOrmFl)
		return IGEpKNCaiLMT,UTwH7zjZOrmFl
	IGEpKNCaiLMT,UTwH7zjZOrmFl,WWFKvmy3wPQBXpbG = [],[],[]
	for zehVcU893FC6LEd1Aij in xGMCcl8P0dqYyXFwnE4JNRjH:
		if lrtFSogC8Nh9(u"ࠪ࠳࠴࠭Ἒ") not in zehVcU893FC6LEd1Aij: continue
		ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA = W3v15nH7GD4aVMdELcP8JAZkFtoB(zehVcU893FC6LEd1Aij,source)
		a0ao2jdlt4r9nhHwpvSgOVGA = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠫࡡࡪࠫࠨἛ"),a0ao2jdlt4r9nhHwpvSgOVGA,YYqECUofyi7wFrW.DOTALL)
		if a0ao2jdlt4r9nhHwpvSgOVGA: a0ao2jdlt4r9nhHwpvSgOVGA = int(a0ao2jdlt4r9nhHwpvSgOVGA[e8XhbyuzvjYkIsJUtB5w])
		else: a0ao2jdlt4r9nhHwpvSgOVGA = e8XhbyuzvjYkIsJUtB5w
		oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,kb2icmDGVUZfW1OFz7sv(u"ࠬࡴࡡ࡮ࡧࠪἜ"))
		WWFKvmy3wPQBXpbG.append([ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,zehVcU893FC6LEd1Aij,oikt6P0hOAD5IvnlMpxf1])
	if WWFKvmy3wPQBXpbG:
		keKM8V6C32NclE = sorted(WWFKvmy3wPQBXpbG,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: (key[TQNS6YMKAqnilsVObLpDRX],key[e8XhbyuzvjYkIsJUtB5w],key[uL69vJOU7xN0hGnZf2islDqk],key[cCRvAuJQfjBpTg0PbYiaNO87],key[llxMLe4gobHhsj1WGvd7qmIU],key[OOkmZiVcfqlEurM1dHGb(u"࠵೯")],key[JGwsL21ZRlqSrWxEmF(u"࠷೰")]))
		ttFMHI9QPiN,kxClD5nyIRtBhEmKXGW8cj = [],[]
		for iJbFcE2OQWRykXNMUlfrCv918SqpD in keKM8V6C32NclE:
			ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,zehVcU893FC6LEd1Aij,oikt6P0hOAD5IvnlMpxf1 = iJbFcE2OQWRykXNMUlfrCv918SqpD
			if HHvYL68lbJVZWM7tQEzSex3(u"࠭ๅโุ็ࠫἝ") in GY9jgon6yhP0IvtCBEJu3:
				kxClD5nyIRtBhEmKXGW8cj.append(iJbFcE2OQWRykXNMUlfrCv918SqpD)
				continue
			if iJbFcE2OQWRykXNMUlfrCv918SqpD not in ttFMHI9QPiN: ttFMHI9QPiN.append(iJbFcE2OQWRykXNMUlfrCv918SqpD)
		ttFMHI9QPiN = kxClD5nyIRtBhEmKXGW8cj+ttFMHI9QPiN
		rAknWUHpDyi4IuGPfl2QYR = e8XhbyuzvjYkIsJUtB5w
		for ibPZISFLE7HVc4zK,JHKDFe6Am0ruz8,GY9jgon6yhP0IvtCBEJu3,uJqZbeXK04CRjoQ,a0ao2jdlt4r9nhHwpvSgOVGA,zehVcU893FC6LEd1Aij,oikt6P0hOAD5IvnlMpxf1 in ttFMHI9QPiN:
			a0ao2jdlt4r9nhHwpvSgOVGA = str(a0ao2jdlt4r9nhHwpvSgOVGA) if a0ao2jdlt4r9nhHwpvSgOVGA else NdKhAS6MXVEORLTwob92pxlZ
			title = NOrchaEV1iIZ87Uzlwgum(u"ࠧิ์ิๅึ࠭἞")+Vwgflszp4WRA93kx6hvdua21HX5cOb+GY9jgon6yhP0IvtCBEJu3+Vwgflszp4WRA93kx6hvdua21HX5cOb+ibPZISFLE7HVc4zK+Vwgflszp4WRA93kx6hvdua21HX5cOb+a0ao2jdlt4r9nhHwpvSgOVGA+Vwgflszp4WRA93kx6hvdua21HX5cOb+uJqZbeXK04CRjoQ+Vwgflszp4WRA93kx6hvdua21HX5cOb+JHKDFe6Am0ruz8
			if oikt6P0hOAD5IvnlMpxf1.lower() not in title.lower(): title = title+Vwgflszp4WRA93kx6hvdua21HX5cOb+oikt6P0hOAD5IvnlMpxf1
			title = title.replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࠧࠪ἟"),NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
			rAknWUHpDyi4IuGPfl2QYR += llxMLe4gobHhsj1WGvd7qmIU
			title = str(rAknWUHpDyi4IuGPfl2QYR)+lRP6GTaZJA1Xw3egLM4(u"ࠩ࠱ࠤࠬἠ")+title
			if zehVcU893FC6LEd1Aij not in UTwH7zjZOrmFl:
				IGEpKNCaiLMT.append(title)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		if UTwH7zjZOrmFl:
			data = zip(IGEpKNCaiLMT,UTwH7zjZOrmFl)
			if data: eMN9D4l8hbiKFyLPHIVkAmB7Jvt(ZFMPvkNQbT2cHiUj,fOc18oTm5hsdD4pVZQj(u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫἡ"),xGMCcl8P0dqYyXFwnE4JNRjH,data,OewIv05xGhKQpFf)
	IGEpKNCaiLMT,UTwH7zjZOrmFl = list(IGEpKNCaiLMT),list(UTwH7zjZOrmFl)
	return IGEpKNCaiLMT,UTwH7zjZOrmFl
def FKGWstNv90lZB(url):
	if JGwsL21ZRlqSrWxEmF(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪἢ") in url:
		IGEpKNCaiLMT,UTwH7zjZOrmFl = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,url)
		if UTwH7zjZOrmFl: return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
		return NeU6uRGpECkvMV5jf(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࠵ࡘ࠼ࠬἣ"),[],[]
	return lrtFSogC8Nh9(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἤ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def RQzfIOVrm3(url):
	Pj8lY4doOfxiFMuNLhv3tnp,UpvYl7QkMBOTJIeSyCiH92GKfm56rn = [],[]
	if V0VZk9763fusTReHFo4(u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪἥ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,fOc18oTm5hsdD4pVZQj(u"ࠨࡉࡈࡘࠬἦ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫἧ"))
		if kb2icmDGVUZfW1OFz7sv(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬἨ") in VNc1u4edS90FK5W6bsMgQC2B.headers:
			zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[V0VZk9763fusTReHFo4(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭Ἡ")]
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
			oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,gniNItGL6bKwpEW(u"ࠬࡴࡡ࡮ࡧࠪἪ"))
			UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(oikt6P0hOAD5IvnlMpxf1)
	elif kb2icmDGVUZfW1OFz7sv(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬἫ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡈࡇࡗࠫἬ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪἭ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		cqzC1gA3uKNVyiXQ0mpZL = YYqECUofyi7wFrW.findall(QQHFtjcaR2VpnSyTIv(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩἮ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if cqzC1gA3uKNVyiXQ0mpZL:
			cqzC1gA3uKNVyiXQ0mpZL = cqzC1gA3uKNVyiXQ0mpZL[e8XhbyuzvjYkIsJUtB5w]
			Bl9VrUSa5mjWPhJcI3 = l4SxGUb2p8jysLXAgQITDPY0(cqzC1gA3uKNVyiXQ0mpZL)
			wLZmC8xs1QMFh92 = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨἯ"),Bl9VrUSa5mjWPhJcI3,YYqECUofyi7wFrW.DOTALL)
			if wLZmC8xs1QMFh92:
				wLZmC8xs1QMFh92 = wLZmC8xs1QMFh92[e8XhbyuzvjYkIsJUtB5w]
				wLZmC8xs1QMFh92 = BdnA8WwtJeKUVvE(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡱ࡯ࡳࡵࠩἰ"),wLZmC8xs1QMFh92)
				for dict in wLZmC8xs1QMFh92:
					zehVcU893FC6LEd1Aij = dict[rNyT0edugn(u"ࠬ࡬ࡩ࡭ࡧࠪἱ")]
					a0ao2jdlt4r9nhHwpvSgOVGA = dict[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭࡬ࡢࡤࡨࡰࠬἲ")]
					Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
					oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,QQHFtjcaR2VpnSyTIv(u"ࠧ࡯ࡣࡰࡩࠬἳ"))
					UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(a0ao2jdlt4r9nhHwpvSgOVGA+Vwgflszp4WRA93kx6hvdua21HX5cOb+oikt6P0hOAD5IvnlMpxf1)
		elif gniNItGL6bKwpEW(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪἴ") in VNc1u4edS90FK5W6bsMgQC2B.headers:
			zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[gniNItGL6bKwpEW(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫἵ")]
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
			oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡲࡦࡳࡥࠨἶ"))
			UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(oikt6P0hOAD5IvnlMpxf1)
		if Hlp3z0APt1GR4kMYK5xST(u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫἷ") in url:
			zehVcU893FC6LEd1Aij = url.split(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡅࡵࡳ࡮ࡀࠫἸ"))[llxMLe4gobHhsj1WGvd7qmIU]
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠦࠨἹ"))[e8XhbyuzvjYkIsJUtB5w]
			if zehVcU893FC6LEd1Aij:
				Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
				UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(hCm2fnEXs6Zt(u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧἺ"))
	else:
		Pj8lY4doOfxiFMuNLhv3tnp.append(url)
		oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,lrtFSogC8Nh9(u"ࠨࡰࡤࡱࡪ࠭Ἳ"))
		UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(oikt6P0hOAD5IvnlMpxf1)
	if not Pj8lY4doOfxiFMuNLhv3tnp: return HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭Ἴ"),[],[]
	elif len(Pj8lY4doOfxiFMuNLhv3tnp)==llxMLe4gobHhsj1WGvd7qmIU: zehVcU893FC6LEd1Aij = Pj8lY4doOfxiFMuNLhv3tnp[e8XhbyuzvjYkIsJUtB5w]
	else:
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(JGwsL21ZRlqSrWxEmF(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨἽ"),UpvYl7QkMBOTJIeSyCiH92GKfm56rn)
		if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return NOrchaEV1iIZ87Uzlwgum(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἾ"),[],[]
		zehVcU893FC6LEd1Aij = Pj8lY4doOfxiFMuNLhv3tnp[rRfpvbZojlygET5JL87wdzIPGe]
	return ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨἿ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def fQ6n9eLcvmX2joCtJlMTFU7A8rSDP1(url):
	headers = {wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪὀ"):vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡌࡱࡧ࡭࠴࠭ὁ")+str(kQI947MebLovYyVE08F5qPi6fj3)}
	for XW2Opt4RQsVihunCylz6j in range(eGW7cI6aQhr0(u"࠷࠳ೱ")):
		XJ62UBRmIqFvfiNTQj.sleep(Tzx81Wb0RZC4ID5AyiU2(u"࠳࠲࠶࠶࠰ೲ"))
		VNc1u4edS90FK5W6bsMgQC2B = W1nrEA8Xg3(HVmIrFwau90jQsgiWzExk(u"ࠨࡉࡈࡘࠬὂ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭ὃ"))
		if hCm2fnEXs6Zt(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬὄ") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()):
			zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ὅ")]
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ὆")+headers[vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ὇")]
			return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
		if VNc1u4edS90FK5W6bsMgQC2B.code!=hCm2fnEXs6Zt(u"࠸࠷࠿ೳ"): break
	return V0VZk9763fusTReHFo4(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠭Ὀ"),[],[]
def eCNSW8zE6AbHs0KVBXcLu(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,fOc18oTm5hsdD4pVZQj(u"ࠨࡉࡈࡘࠬὉ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨὊ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧὋ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		return NdKhAS6MXVEORLTwob92pxlZ,[a0ao2jdlt4r9nhHwpvSgOVGA],[zehVcU893FC6LEd1Aij]
	return HVmIrFwau90jQsgiWzExk(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬὌ"),[],[]
def heCY5Ecfio(url):
	if QQHFtjcaR2VpnSyTIv(u"ࠬ࠵ࡷࡦࡧࡳ࡭ࡸ࠵ࠧὍ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡇࡆࡖࠪ὎"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠵࠱࠶ࡹࡴࠨ὏"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡵࡺࡧ࡬ࡪࡶࡼࡂࠬὐ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij: url = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		else: return YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄ࠶ࠬὑ"),[],[]
	return vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ὒ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def pHIji6rfbSgCK0Ph7ZG(url):
	BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = NdKhAS6MXVEORLTwob92pxlZ,[],[]
	if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨὓ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,V0VZk9763fusTReHFo4(u"ࠬࡍࡅࡕࠩὔ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,hCm2fnEXs6Zt(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡔ࡚ࡎࡊ࠭࠲ࡵࡷࠫὕ"))
		zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.url
		if zehVcU893FC6LEd1Aij: BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	elif IlL8ZnX74Yvep(u"ࠧࡴࡧࡵࡺࡂ࠭ὖ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,lRP6GTaZJA1Xw3egLM4(u"ࠨࡉࡈࡘࠬὗ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡗࡖࡊࡆ࠰࠶ࡳࡪࠧ὘"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩὙ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij: url = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		else:
			zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(eGW7cI6aQhr0(u"ࠦࡆࡲࡢࡢࡒ࡯ࡥࡾ࡫ࡲࡄࡱࡱࡸࡷࡵ࡬࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩࠥ὚"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if zehVcU893FC6LEd1Aij:
				url = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
				url = NHsYdVBpXn.b64decode(url)
				if J92gCnbGWidQV70lBteTwU6D8uyzL: url = url.decode(YRvPKe2zMTDs8UCkr)
			else: return lRP6GTaZJA1Xw3egLM4(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡒࡘࡌࡈࠬὛ"),[],[]
		BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ὜"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,R3lezw8h407ZvrAFxT(u"ࠧࡈࡇࡗࠫὝ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡖ࡜ࡉࡅ࠯࠶ࡶࡩ࠭὞"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࠥࡥࡵࡲࡲ࠮࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪὟ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[Tzx81Wb0RZC4ID5AyiU2(u"࠵೴")]
			items = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ὠ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(title)
				Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	return BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp
def xVDPCTs6jX(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡌࡋࡔࠨὡ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧὢ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	LMKFcEkU1Q7R80yt4OsgvwxbfP = CP2rKkbdyhaxvmuU89TOAec(LMKFcEkU1Q7R80yt4OsgvwxbfP)
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧὣ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]]
	return QQHFtjcaR2VpnSyTIv(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡘࡋࡌࡉࡆ࠴ࠫὤ"),[],[]
def ss7D4f8nvo(url):
	if len(url)>xY4icgQUj6mPVs73CTKu(u"࠸࠰࠱೵"):
		url = url.strip(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࠱ࠪὥ"))+fOc18oTm5hsdD4pVZQj(u"ࠩ࠲ࠫὦ")
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡋࡊ࡚ࠧὧ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡃࡕࡓ࡟ࡇ࠭࠲ࡵࡷࠫὨ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		if e8XhbyuzvjYkIsJUtB5w and IlL8ZnX74Yvep(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠮࠭Ὡ") in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠢ࡭ࡱࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬὪ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
				AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠰೶")]
				bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࡸࡤࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࠫὫ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
					AAMHoYxRCmt2D6ph89W = nadz1WI5ZUCSpYGJvNMAK(bMU7NEFK5RJ8dcz0jtqiWmvyar6[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠱೷")])
		elif len(LMKFcEkU1Q7R80yt4OsgvwxbfP)<V0VZk9763fusTReHFo4(u"࠶࠳࠴೸"): zehVcU893FC6LEd1Aij = LMKFcEkU1Q7R80yt4OsgvwxbfP
		else: return rNyT0edugn(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡐࡆࡘࡏ࡛ࡃࠪὬ"),[],[]
		return PzIpQnUXxRwNCivDhdakWTE(u"ࠩࠪὭ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return xY4icgQUj6mPVs73CTKu(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ὦ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def fx0PH6CZqm(url):
	if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫ࠴ࡪ࡯ࡸࡰ࠱ࡴ࡭ࡶࠧὯ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡍࡅࡕࠩὰ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡌࡈࡂ࠯࠴ࡷࡹ࠭ά"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡷࡳࡣࡳࡴࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨὲ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		url = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	return eGW7cI6aQhr0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫέ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def IOY8EXZopF(url):
	if gniNItGL6bKwpEW(u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭ὴ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,hCm2fnEXs6Zt(u"ࠪࡋࡊ࡚ࠧή"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅ࠹࡛࠭࠲ࡵࡷࠫὶ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪί"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		if V0VZk9763fusTReHFo4(u"࠭ࡨࡵࡶࡳࠫὸ") in zehVcU893FC6LEd1Aij: return eGW7cI6aQhr0(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪό"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
		return lrtFSogC8Nh9(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪὺ"),[],[]
	return lRP6GTaZJA1Xw3egLM4(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬύ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def NNqGlbdzVE(url):
	BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
	omrd89nv0PGKFpL3TxfAXt = {NOrchaEV1iIZ87Uzlwgum(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ὼ"):Hlp3z0APt1GR4kMYK5xST(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬώ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ὾"):R3lezw8h407ZvrAFxT(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭὿")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,xY4icgQUj6mPVs73CTKu(u"ࠧࡑࡑࡖࡘࠬᾀ"),BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡏࡑ࡚࠱࠶ࡹࡴࠨᾁ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᾂ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: return R3lezw8h407ZvrAFxT(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡐࡒ࡛ࠬᾃ"),[],[]
	zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	return LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᾄ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def T3TQo2Fr5e(url):
	headers = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨᾅ"):fOc18oTm5hsdD4pVZQj(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧᾆ")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡈࡇࡗࠫᾇ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪᾈ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᾉ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	if not zehVcU893FC6LEd1Aij: return Hlp3z0APt1GR4kMYK5xST(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧᾊ"),[],[]
	zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	return lNTJCZeBicWEz0Mg(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᾋ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def tBpA6DSOTz(url):
	BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
	omrd89nv0PGKFpL3TxfAXt = {Hlp3z0APt1GR4kMYK5xST(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᾌ"):R3lezw8h407ZvrAFxT(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᾍ")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡑࡑࡖࡘࠬᾎ"),BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡍࡇࡌࡂࡅࡌࡑࡆ࠳࠱ࡴࡶࠪᾏ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"ࠩࠪࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫᾐ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	if not zehVcU893FC6LEd1Aij: return ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡎࡁࡍࡃࡆࡍࡒࡇࠧᾑ"),[],[]
	zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	if lRP6GTaZJA1Xw3egLM4(u"ࠫ࡭ࡺࡴࡱࠩᾒ") not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = Hlp3z0APt1GR4kMYK5xST(u"ࠬ࡮ࡴࡵࡲ࠽ࠫᾓ")+zehVcU893FC6LEd1Aij
	return vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾔ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def ElC38ro1qU(url):
	xKXbWz9coR7jUfil45aQENr0ICBJg,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = url,[],[]
	if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࠧᾕ") in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {kb2icmDGVUZfW1OFz7sv(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᾖ"):hCm2fnEXs6Zt(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᾗ")}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡔࡔ࡙ࡔࠨᾘ"),BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡆࡈࡄࡐ࠯࠴ࡷࡹ࠭ᾙ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		n5w3CRodyczAelGWjuNHm2ZV = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩᾚ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if n5w3CRodyczAelGWjuNHm2ZV: xKXbWz9coR7jUfil45aQENr0ICBJg = n5w3CRodyczAelGWjuNHm2ZV[e8XhbyuzvjYkIsJUtB5w]
	return ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾛ"),[NdKhAS6MXVEORLTwob92pxlZ],[xKXbWz9coR7jUfil45aQENr0ICBJg]
def zJrlt5mZ9w(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,fOc18oTm5hsdD4pVZQj(u"ࠧࡈࡇࡗࠫᾜ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧᾝ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	RCLE0xUdisba7gDz9NW3w = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥᾞ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	if RCLE0xUdisba7gDz9NW3w:
		RCLE0xUdisba7gDz9NW3w = RCLE0xUdisba7gDz9NW3w[e8XhbyuzvjYkIsJUtB5w][NOrchaEV1iIZ87Uzlwgum(u"࠵೹"):]
		RCLE0xUdisba7gDz9NW3w = NHsYdVBpXn.b64decode(RCLE0xUdisba7gDz9NW3w)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: RCLE0xUdisba7gDz9NW3w = RCLE0xUdisba7gDz9NW3w.decode(YRvPKe2zMTDs8UCkr)
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(OOkmZiVcfqlEurM1dHGb(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᾟ"),RCLE0xUdisba7gDz9NW3w,YYqECUofyi7wFrW.DOTALL)
	else: zehVcU893FC6LEd1Aij = NdKhAS6MXVEORLTwob92pxlZ
	if not zehVcU893FC6LEd1Aij: return PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡔࡗࡈࡘࡒࠬᾠ"),[],[]
	zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	if rNyT0edugn(u"ࠬ࡮ࡴࡵࡲࠪᾡ") not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡨࡵࡶࡳ࠾ࠬᾢ")+zehVcU893FC6LEd1Aij
	return NOrchaEV1iIZ87Uzlwgum(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᾣ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def OyDzTmkNf8BHKeV0Y(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,NOrchaEV1iIZ87Uzlwgum(u"ࠨࡉࡈࡘࠬᾤ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫᾥ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᾦ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: return eGW7cI6aQhr0(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨᾧ"),[],[]
	zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	return PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᾨ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def rkeSbyBcK6(url):
	id = url.split(PzIpQnUXxRwNCivDhdakWTE(u"࠭࠯ࠨᾩ"))[-wP4kpvXoDHq3hs7TFLyr2COn8(u"࠵೺")]
	if YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧ࠰ࡧࡰࡦࡪࡪࠧᾪ") in url: url = url.replace(HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨᾫ"),NdKhAS6MXVEORLTwob92pxlZ)
	url = url.replace(NeU6uRGpECkvMV5jf(u"ࠩ࠱ࡧࡴࡳ࠯ࠨᾬ"),R3lezw8h407ZvrAFxT(u"ࠪ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡯ࡨࡸࡦࡪࡡࡵࡣ࠲ࠫᾭ"))
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡌࡋࡔࠨᾮ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳࠱ࡴࡶࠪᾯ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	BGulEd0o6ZQLzk5WHwMs2bN = PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ᾰ")
	hcKrT3bew489nFp1U0 = YYqECUofyi7wFrW.findall(fOc18oTm5hsdD4pVZQj(u"ࠧࠣࡧࡵࡶࡴࡸࠢ࠯ࠬࡂࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᾱ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if hcKrT3bew489nFp1U0: BGulEd0o6ZQLzk5WHwMs2bN = hcKrT3bew489nFp1U0[e8XhbyuzvjYkIsJUtB5w]
	url = YYqECUofyi7wFrW.findall(kb2icmDGVUZfW1OFz7sv(u"ࠨࡺ࠰ࡱࡵ࡫ࡧࡖࡔࡏࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᾲ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not url and BGulEd0o6ZQLzk5WHwMs2bN:
		return BGulEd0o6ZQLzk5WHwMs2bN,[],[]
	zehVcU893FC6LEd1Aij = url[e8XhbyuzvjYkIsJUtB5w].replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࡟ࡠࠬᾳ"),NdKhAS6MXVEORLTwob92pxlZ)
	sqa5mP1EXFHu2fR3Ar7yelgp,xGMCcl8P0dqYyXFwnE4JNRjH = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,zehVcU893FC6LEd1Aij)
	ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OOkmZiVcfqlEurM1dHGb(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧᾴ"))
	if ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB and kb2icmDGVUZfW1OFz7sv(u"ࠫ࠲࠭᾵") not in ewksPz4WJDOpHvVKNGZ5i3Ty0AgtB: title,zehVcU893FC6LEd1Aij = sqa5mP1EXFHu2fR3Ar7yelgp[HHvYL68lbJVZWM7tQEzSex3(u"࠵೻")],xGMCcl8P0dqYyXFwnE4JNRjH[HHvYL68lbJVZWM7tQEzSex3(u"࠵೻")]
	else:
		Y8jOherRiQumx0Ay = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀ࡜ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡷࡨࡸࡥࡦࡰࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩᾶ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if Y8jOherRiQumx0Ay: rrOqGw4b0zaie8PskjX,RFmd7SuHDc6x2yq15vVohUj3,gyMlWOFB9IrPE6xJTaU4qdkeVs8 = Y8jOherRiQumx0Ay[e8XhbyuzvjYkIsJUtB5w]
		else: rrOqGw4b0zaie8PskjX,RFmd7SuHDc6x2yq15vVohUj3,gyMlWOFB9IrPE6xJTaU4qdkeVs8 = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		gyMlWOFB9IrPE6xJTaU4qdkeVs8 = gyMlWOFB9IrPE6xJTaU4qdkeVs8.replace(NeU6uRGpECkvMV5jf(u"࠭࡜࠰ࠩᾷ"),eGW7cI6aQhr0(u"ࠧ࠰ࠩᾸ"))
		RFmd7SuHDc6x2yq15vVohUj3 = L5xKSr96JmaX7N(RFmd7SuHDc6x2yq15vVohUj3)
		IGEpKNCaiLMT = [Whef0cxB2iR93SC5IwUtk+R3lezw8h407ZvrAFxT(u"ࠨࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪᾹ")+RFmd7SuHDc6x2yq15vVohUj3+kjd9LyNqQHMUevZiRI7OlBGF1h]+sqa5mP1EXFHu2fR3Ar7yelgp
		UTwH7zjZOrmFl = [gyMlWOFB9IrPE6xJTaU4qdkeVs8]+xGMCcl8P0dqYyXFwnE4JNRjH
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(IlL8ZnX74Yvep(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪᾺ")+str(len(UTwH7zjZOrmFl)-V0VZk9763fusTReHFo4(u"࠷೼"))+eGW7cI6aQhr0(u"ࠪࠤ๊๊แࠪࠩΆ"),IGEpKNCaiLMT)
		if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return gniNItGL6bKwpEW(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾼ"),[],[]
		elif rRfpvbZojlygET5JL87wdzIPGe==e8XhbyuzvjYkIsJUtB5w:
			yEH9TlCK53NSmtVopLGPsBxI = hnu0oKAvsG4PaX6yxiTj2eftY.argv[e8XhbyuzvjYkIsJUtB5w]+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠷࠴࠷ࠬࡵࡳ࡮ࡀࠫ᾽")+gyMlWOFB9IrPE6xJTaU4qdkeVs8+rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠦࡵࡧࡻࡸࡹࡃࠧι")+RFmd7SuHDc6x2yq15vVohUj3
			ACOWB6GRmIbDKyl3Zn.executebuiltin(NOrchaEV1iIZ87Uzlwgum(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ᾿")+yEH9TlCK53NSmtVopLGPsBxI+rNyT0edugn(u"ࠣࠫࠥ῀"))
			return hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ῁"),[],[]
		title,zehVcU893FC6LEd1Aij = IGEpKNCaiLMT[rRfpvbZojlygET5JL87wdzIPGe],UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	return NdKhAS6MXVEORLTwob92pxlZ,[title],[zehVcU893FC6LEd1Aij]
def gg34ZwSuqD(zehVcU893FC6LEd1Aij):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,xY4icgQUj6mPVs73CTKu(u"ࠪࡋࡊ࡚ࠧῂ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃࡑࡎࡖࡆ࠳࠱ࡴࡶࠪῃ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if R3lezw8h407ZvrAFxT(u"ࠬ࠴ࡪࡴࡱࡱࠫῄ") in zehVcU893FC6LEd1Aij: url = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"࠭ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭῅"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: url = YYqECUofyi7wFrW.findall(kb2icmDGVUZfW1OFz7sv(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬῆ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not url: return vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆࡔࡑࡒࡂࠩῇ"),[],[]
	url = url[e8XhbyuzvjYkIsJUtB5w]
	if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩ࡫ࡸࡹࡶࠧῈ") not in url: url = gniNItGL6bKwpEW(u"ࠪ࡬ࡹࡺࡰ࠻ࠩΈ")+url
	return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
def SIgPRFslDqCe2WB8O(url):
	headers = { ggWEFaH6fcVIO9SzRZLiuxo7P(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨῊ") : NdKhAS6MXVEORLTwob92pxlZ }
	if hCm2fnEXs6Zt(u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨΉ") in url:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠶ࡹࡴࠨῌ"))
		items = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭῍"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if items: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[items[e8XhbyuzvjYkIsJUtB5w]]
		else:
			JzNoqV8ClRD6O = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭῎"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if JzNoqV8ClRD6O:
				ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊วึๆํࠫ῏"),JzNoqV8ClRD6O[e8XhbyuzvjYkIsJUtB5w])
				return rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࠫῐ")+JzNoqV8ClRD6O[e8XhbyuzvjYkIsJUtB5w],[],[]
	else:
		RoDOya8x9mcMLZduGkX7YJUQTqI = lrtFSogC8Nh9(u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧῑ")
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧῒ"))
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(kb2icmDGVUZfW1OFz7sv(u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨΐ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ῔"),[],[]
		xKXbWz9coR7jUfil45aQENr0ICBJg = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w]
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]
		if vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨ࠰ࡵࡥࡷ࠭῕") in AAMHoYxRCmt2D6ph89W or R3lezw8h407ZvrAFxT(u"ࠩ࠱ࡾ࡮ࡶࠧῖ") in AAMHoYxRCmt2D6ph89W: return lrtFSogC8Nh9(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨῗ"),[],[]
		items = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬῘ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		YWsjNtDXPAgCya = {}
		for JHKDFe6Am0ruz8,K6KbZDHncNizQgl1fr59XV0 in items:
			YWsjNtDXPAgCya[JHKDFe6Am0ruz8] = K6KbZDHncNizQgl1fr59XV0
		data = g1Vmb5T39C(YWsjNtDXPAgCya)
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,xKXbWz9coR7jUfil45aQENr0ICBJg,data,headers,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠷ࡷࡪࠧῙ"))
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࠡࡘ࡬ࡨࡪࡵ࠮ࠫࡁࡪࡩࡹࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࠯ࠬࡂ࠭࡮ࡳࡡࡨࡧ࠽ࠫῚ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫΊ"),[],[]
		download = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w]
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]
		items = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣ࠰࠭ࡃࠧࢂࠩࠨ῜"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		QQgG862yiLenuYHlBO,IGEpKNCaiLMT,nnsGZ4jriVKNmpvAhFS70D1TCYtl,UTwH7zjZOrmFl,tk2aRyzhOf8mWiJEq = [],[],[],[],[]
		for zehVcU893FC6LEd1Aij,title in items:
			if PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ῝") in zehVcU893FC6LEd1Aij:
				QQgG862yiLenuYHlBO,nnsGZ4jriVKNmpvAhFS70D1TCYtl = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,zehVcU893FC6LEd1Aij)
				UTwH7zjZOrmFl = UTwH7zjZOrmFl + nnsGZ4jriVKNmpvAhFS70D1TCYtl
				if QQgG862yiLenuYHlBO[e8XhbyuzvjYkIsJUtB5w]==xY4icgQUj6mPVs73CTKu(u"ࠪ࠱࠶࠭῞"): IGEpKNCaiLMT.append(YJpWv4QzC7sx8INVPukeZiOD03K(u"ู๊ࠫࠥาใิࠤำอีࠡࠩ῟")+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡳ࠳ࡶ࠺ࠣࠫῠ")+RoDOya8x9mcMLZduGkX7YJUQTqI)
				else:
					for title in QQgG862yiLenuYHlBO:
						IGEpKNCaiLMT.append(lRP6GTaZJA1Xw3egLM4(u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫῡ")+hCm2fnEXs6Zt(u"ࠧ࡮࠵ࡸ࠼ࠥ࠭ῢ")+RoDOya8x9mcMLZduGkX7YJUQTqI+Vwgflszp4WRA93kx6hvdua21HX5cOb+title)
			else:
				title = title.replace(HVmIrFwau90jQsgiWzExk(u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪΰ"),NdKhAS6MXVEORLTwob92pxlZ)
				title = title.strip(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࠥࠫῤ"))
				title = lrtFSogC8Nh9(u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩῥ")+lNTJCZeBicWEz0Mg(u"ࠫࠥࡳࡰ࠵ࠢࠪῦ")+RoDOya8x9mcMLZduGkX7YJUQTqI+Vwgflszp4WRA93kx6hvdua21HX5cOb+title
				IGEpKNCaiLMT.append(title)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		zehVcU893FC6LEd1Aij = IlL8ZnX74Yvep(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧῧ") + download
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠺ࡺࡨࠨῨ"))
		items = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯ࠦῩ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for id,pPrvqm3tjuXLTgw1,hash,PDFYOURfNJQ4lwCqaM in items:
			title = eGW7cI6aQhr0(u"ࠨࠢึ๎ึ็ัࠡฬะ้๏๊ࠠฯษุࠤࠬῪ")+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࠣࡱࡵ࠺ࠠࠨΎ")+RoDOya8x9mcMLZduGkX7YJUQTqI+Vwgflszp4WRA93kx6hvdua21HX5cOb+PDFYOURfNJQ4lwCqaM.split(lNTJCZeBicWEz0Mg(u"ࠪࡼࠬῬ"))[llxMLe4gobHhsj1WGvd7qmIU]
			zehVcU893FC6LEd1Aij = wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ῭")+id+JGwsL21ZRlqSrWxEmF(u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ΅")+pPrvqm3tjuXLTgw1+xY4icgQUj6mPVs73CTKu(u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭`")+hash
			tk2aRyzhOf8mWiJEq.append(PDFYOURfNJQ4lwCqaM)
			IGEpKNCaiLMT.append(title)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		tk2aRyzhOf8mWiJEq = set(tk2aRyzhOf8mWiJEq)
		N32Mw0rUmiAqVShgX4LdZeoEczl,Ie1t0AUyxpKEvMJsbq2Rc = [],[]
		for title in IGEpKNCaiLMT:
			z9o0pbqcfi5vHlSVQZFjrD = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ῰"),title+HVmIrFwau90jQsgiWzExk(u"ࠨࠨࠩࠫ῱"),YYqECUofyi7wFrW.DOTALL)
			for PDFYOURfNJQ4lwCqaM in tk2aRyzhOf8mWiJEq:
				if z9o0pbqcfi5vHlSVQZFjrD[e8XhbyuzvjYkIsJUtB5w] in PDFYOURfNJQ4lwCqaM:
					title = title.replace(z9o0pbqcfi5vHlSVQZFjrD[e8XhbyuzvjYkIsJUtB5w],PDFYOURfNJQ4lwCqaM.split(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡻࠫῲ"))[llxMLe4gobHhsj1WGvd7qmIU])
			N32Mw0rUmiAqVShgX4LdZeoEczl.append(title)
		for xX6zt5oS08TO29CUhYJa1K in range(len(UTwH7zjZOrmFl)):
			items = YYqECUofyi7wFrW.findall(R3lezw8h407ZvrAFxT(u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦῳ"),WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࠫࠬࠧῴ")+N32Mw0rUmiAqVShgX4LdZeoEczl[xX6zt5oS08TO29CUhYJa1K]+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠬࠦࠨ῵"),YYqECUofyi7wFrW.DOTALL)
			Ie1t0AUyxpKEvMJsbq2Rc.append( [N32Mw0rUmiAqVShgX4LdZeoEczl[xX6zt5oS08TO29CUhYJa1K],UTwH7zjZOrmFl[xX6zt5oS08TO29CUhYJa1K],items[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w],items[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU]] )
		Ie1t0AUyxpKEvMJsbq2Rc = sorted(Ie1t0AUyxpKEvMJsbq2Rc, key=lambda lPVSU9krH8qwJGs2ahLnpTcti0xzZ: lPVSU9krH8qwJGs2ahLnpTcti0xzZ[uL69vJOU7xN0hGnZf2islDqk], reverse=k6apiPAlLKM1ed8J42RjHh0o)
		Ie1t0AUyxpKEvMJsbq2Rc = sorted(Ie1t0AUyxpKEvMJsbq2Rc, key=lambda lPVSU9krH8qwJGs2ahLnpTcti0xzZ: lPVSU9krH8qwJGs2ahLnpTcti0xzZ[cCRvAuJQfjBpTg0PbYiaNO87], reverse=f4vncKMRlXG9s)
		IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
		for xX6zt5oS08TO29CUhYJa1K in range(len(Ie1t0AUyxpKEvMJsbq2Rc)):
			IGEpKNCaiLMT.append(Ie1t0AUyxpKEvMJsbq2Rc[xX6zt5oS08TO29CUhYJa1K][e8XhbyuzvjYkIsJUtB5w])
			UTwH7zjZOrmFl.append(Ie1t0AUyxpKEvMJsbq2Rc[xX6zt5oS08TO29CUhYJa1K][llxMLe4gobHhsj1WGvd7qmIU])
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return Hlp3z0APt1GR4kMYK5xST(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪῶ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def u2FBJOfvix8ECz6b(url):
	BDkTn4JaU3HsYzI = url.split(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡀࠩῷ"))
	BfjcMoqOsmdUvZVCHWIyQKi = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
	headers = { rNyT0edugn(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬῸ") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩΌ"))
	items = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫῺ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	url = items[e8XhbyuzvjYkIsJUtB5w]
	return hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΏ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def Dydjg3nW4sRIa5m9NKzfwkB(url):
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	headers = { IlL8ZnX74Yvep(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩῼ") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ´"))
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(kb2icmDGVUZfW1OFz7sv(u"ࠧࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡࡸࡶࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ῾"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]]
	else: return HVmIrFwau90jQsgiWzExk(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠫ῿"),[],[]
def QNCoXB036udyLhTtIZDP15qEHkJmVz(url):
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	headers = { YJpWv4QzC7sx8INVPukeZiOD03K(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࠀ") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫࠁ"))
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩࠂ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]]
	else: return fOc18oTm5hsdD4pVZQj(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨࠃ"),[],[]
def jTdEqINm1i(url):
	IGEpKNCaiLMT,UTwH7zjZOrmFl,errno = [],[],NdKhAS6MXVEORLTwob92pxlZ
	if V0VZk9763fusTReHFo4(u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬࠄ") in url:
		BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq = muYp09a1NhMo7cZng5IOXyTSKt4qv2(url)
		omrd89nv0PGKFpL3TxfAXt = {OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࠅ"):QQHFtjcaR2VpnSyTIv(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠆ")}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡕࡕࡓࡕࠩࠇ"),BfjcMoqOsmdUvZVCHWIyQKi,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨࠈ"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		if HeFB5x2wED.startswith(R3lezw8h407ZvrAFxT(u"࠭ࡨࡵࡶࡳࠫࠉ")): BfjcMoqOsmdUvZVCHWIyQKi = HeFB5x2wED
		else:
			Afey3cL4ojzg = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨࠊ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if Afey3cL4ojzg:
				BfjcMoqOsmdUvZVCHWIyQKi = Afey3cL4ojzg[e8XhbyuzvjYkIsJUtB5w]
				Afey3cL4ojzg = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯࡛ࠧࠦࡠࠫࠋ"),BfjcMoqOsmdUvZVCHWIyQKi,YYqECUofyi7wFrW.DOTALL)
				if Afey3cL4ojzg:
					BfjcMoqOsmdUvZVCHWIyQKi = OOFEmwq2GkTz93WXy1Nj(Afey3cL4ojzg[e8XhbyuzvjYkIsJUtB5w])
					return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	elif lrtFSogC8Nh9(u"ࠩ࠲ࡰ࡮ࡴ࡫ࡴ࠱ࠪࠌ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡋࡊ࡚ࠧࠍ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧࠎ"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		if hCm2fnEXs6Zt(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࠏ") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()): BfjcMoqOsmdUvZVCHWIyQKi = VNc1u4edS90FK5W6bsMgQC2B.headers[kb2icmDGVUZfW1OFz7sv(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࠐ")]
		else: BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠑ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)[e8XhbyuzvjYkIsJUtB5w]
	if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ࠱ࡹ࠳ࠬࠒ") in BfjcMoqOsmdUvZVCHWIyQKi or PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠲ࡪ࠴࠭ࠓ") in BfjcMoqOsmdUvZVCHWIyQKi:
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace(JGwsL21ZRlqSrWxEmF(u"ࠪ࠳࡫࠵ࠧࠔ"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪࠕ"))
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace(NeU6uRGpECkvMV5jf(u"ࠬ࠵ࡶ࠰ࠩࠖ"),PzIpQnUXxRwNCivDhdakWTE(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬࠗ"))
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡑࡑࡖࡘࠬ࠘"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ࠙"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		items = YYqECUofyi7wFrW.findall(R3lezw8h407ZvrAFxT(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࠚ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if items:
			for zehVcU893FC6LEd1Aij,title in items:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡠࡡ࠭ࠛ"),NdKhAS6MXVEORLTwob92pxlZ)
				IGEpKNCaiLMT.append(title)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		else:
			items = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࠜ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if items:
				zehVcU893FC6LEd1Aij = items[e8XhbyuzvjYkIsJUtB5w]
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡢ࡜ࠨࠝ"),NdKhAS6MXVEORLTwob92pxlZ)
				IGEpKNCaiLMT.append(NdKhAS6MXVEORLTwob92pxlZ)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	else: return hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠞ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return rNyT0edugn(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬࠟ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def ggaX57uqsJ(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡉࡈࡘࠬࠠ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩࠡ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	IGEpKNCaiLMT,UTwH7zjZOrmFl,errno = [],[],NdKhAS6MXVEORLTwob92pxlZ
	if gniNItGL6bKwpEW(u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭ࠢ") in url or eGW7cI6aQhr0(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬࠣ") in url:
		if fOc18oTm5hsdD4pVZQj(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨࠤ") in url:
			BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠥ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]
		else: BfjcMoqOsmdUvZVCHWIyQKi = url
		if R3lezw8h407ZvrAFxT(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧࠦ") not in BfjcMoqOsmdUvZVCHWIyQKi: return rNyT0edugn(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠧ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡊࡉ࡙࠭ࠨ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪࠩ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧࠪ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
		items = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠫ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if items:
			for zehVcU893FC6LEd1Aij,TWqGAlsD0bpihcwOB3FLfYKMdxgC in items:
				IGEpKNCaiLMT.append(TWqGAlsD0bpihcwOB3FLfYKMdxgC)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	elif lrtFSogC8Nh9(u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨࠬ") in url:
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫ࠭"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,kb2icmDGVUZfW1OFz7sv(u"ࠨࡉࡈࡘࠬ࠮"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ࠯"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		Afey3cL4ojzg = YYqECUofyi7wFrW.findall(lrtFSogC8Nh9(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠰"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		Afey3cL4ojzg = Afey3cL4ojzg[e8XhbyuzvjYkIsJUtB5w]
		IGEpKNCaiLMT.append(NdKhAS6MXVEORLTwob92pxlZ)
		UTwH7zjZOrmFl.append(Afey3cL4ojzg)
	elif R3lezw8h407ZvrAFxT(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ࠱") in url:
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(IlL8ZnX74Yvep(u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠲"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if BfjcMoqOsmdUvZVCHWIyQKi:
			BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]
			return R3lezw8h407ZvrAFxT(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࠳"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓ࡛࡙࠴ࡖࠩ࠴"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def H6HiytTblh(url):
	if vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡁࡪࡩࡹࡃࠧ࠵") in url:
		zehVcU893FC6LEd1Aij = url.split(HVmIrFwau90jQsgiWzExk(u"ࠩࡂ࡫ࡪࡺ࠽ࠨ࠶"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
		zehVcU893FC6LEd1Aij = NHsYdVBpXn.b64decode(zehVcU893FC6LEd1Aij)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.decode(YRvPKe2zMTDs8UCkr,Hlp3z0APt1GR4kMYK5xST(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ࠷"))
		return wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࠸"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	website = xKp3jkIvM09AZ4euXa87i5TVtfUD[HVmIrFwau90jQsgiWzExk(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ࠹")][e8XhbyuzvjYkIsJUtB5w]
	headers = {R3lezw8h407ZvrAFxT(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠺"):website}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,xY4icgQUj6mPVs73CTKu(u"ࠧࡈࡇࡗࠫ࠻"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠲࡯ࡦࠪ࠼"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡸࡶࡱ࠭࠽"))
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(fOc18oTm5hsdD4pVZQj(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠾"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠦࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠩࠫ࠲࠯ࡅࠩࠨࠤ࠿"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦࡀ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]+xY4icgQUj6mPVs73CTKu(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩࡁ")+website
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	if kb2icmDGVUZfW1OFz7sv(u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧࡂ") in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		XyJiGqefbISD = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࡃ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if XyJiGqefbISD:
			zehVcU893FC6LEd1Aij = XyJiGqefbISD[e8XhbyuzvjYkIsJUtB5w]
			zehVcU893FC6LEd1Aij = NHsYdVBpXn.b64decode(zehVcU893FC6LEd1Aij)
			if J92gCnbGWidQV70lBteTwU6D8uyzL: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.decode(YRvPKe2zMTDs8UCkr,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩࡄ"))
			zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪ࡬ࡹࡺࡰ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠲ࠧࡅ"),zehVcU893FC6LEd1Aij,YYqECUofyi7wFrW.DOTALL)
			if zehVcU893FC6LEd1Aij:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]+R3lezw8h407ZvrAFxT(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧࡆ")+website
				return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡇ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
def zhlqBY1Ev2(url,rDOMITncUW9pB8ktAQS2):
	UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = [],[]
	if gniNItGL6bKwpEW(u"࠭࠯࠲࠱ࠪࡈ") in url:
		zehVcU893FC6LEd1Aij = url.replace(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧ࠰࠳࠲ࠫࡉ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠱࠷࠳ࠬࡊ"))
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡊࡉ࡙࠭ࡋ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬࡌ"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(OOkmZiVcfqlEurM1dHGb(u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪࡍ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
			items = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࡎ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA in items:
				if zehVcU893FC6LEd1Aij not in Pj8lY4doOfxiFMuNLhv3tnp:
					Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
					oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭࡮ࡢ࡯ࡨࠫࡏ"))
					UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(oikt6P0hOAD5IvnlMpxf1+Uv7MkgVGyEbAlfFP0S8Zjqp2J+a0ao2jdlt4r9nhHwpvSgOVGA)
			return NdKhAS6MXVEORLTwob92pxlZ,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp
	elif ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠰ࡦ࠲ࠫࡐ") in url:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,rNyT0edugn(u"ࠨࡉࡈࡘࠬࡑ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫࡒ"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(rNyT0edugn(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࡓ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w].replace(JGwsL21ZRlqSrWxEmF(u"ࠫ࠴࠷࠯ࠨࡔ"),OOkmZiVcfqlEurM1dHGb(u"ࠬ࠵࠴࠰ࠩࡕ"))
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,NeU6uRGpECkvMV5jf(u"࠭ࡇࡆࡖࠪࡖ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠹ࡲࡥࠩࡗ"))
			HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
			zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(QQHFtjcaR2VpnSyTIv(u"ࠨࡥ࡯ࡥࡸࡹ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࡘ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if zehVcU893FC6LEd1Aij: return wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࡙ࠬ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]]
	elif fOc18oTm5hsdD4pVZQj(u"ࠪ࠳ࡷࡵ࡬ࡦ࠱࡚ࠪ") in url:
		headers = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶ࡛ࠬ"):rDOMITncUW9pB8ktAQS2}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,gniNItGL6bKwpEW(u"ࠬࡍࡅࡕࠩ࡜"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠹ࡺࡨࠨ࡝"))
		zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࡞")]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡉࡈࡘࠬ࡟"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠶ࡶ࡫ࠫࡠ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = C86scPnSqUQGH9Ybkau2ozF3JIfi(zehVcU893FC6LEd1Aij,LMKFcEkU1Q7R80yt4OsgvwxbfP)
		return BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp
	elif Hlp3z0APt1GR4kMYK5xST(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧࡡ") in url:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨࡢ"),gniNItGL6bKwpEW(u"ࠬ࠵ࡳࡤࡴ࡬ࡴࡹ࠵ࠧࡣ"))
		omrd89nv0PGKFpL3TxfAXt = {NeU6uRGpECkvMV5jf(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧࡤ"):rDOMITncUW9pB8ktAQS2}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,fOc18oTm5hsdD4pVZQj(u"ࠧࡈࡇࡗࠫࡥ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠶ࡵࡪࠪࡦ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࡧ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,Hlp3z0APt1GR4kMYK5xST(u"ࠪࡋࡊ࡚ࠧࡨ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠺ࡸ࡭࠭ࡩ"))
			LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
			if fOc18oTm5hsdD4pVZQj(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࡪ") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()):
				zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[gniNItGL6bKwpEW(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ࡫")]
				VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡈࡇࡗࠫ࡬"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠸ࡵࡪࠪ࡭"))
				LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
				BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = C86scPnSqUQGH9Ybkau2ozF3JIfi(zehVcU893FC6LEd1Aij,LMKFcEkU1Q7R80yt4OsgvwxbfP)
				if Pj8lY4doOfxiFMuNLhv3tnp: return BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp
			elif kb2icmDGVUZfW1OFz7sv(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪ࡮") in zehVcU893FC6LEd1Aij:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(OOkmZiVcfqlEurM1dHGb(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ࡯"),kb2icmDGVUZfW1OFz7sv(u"ࠫ࠴ࡰࡷࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨࡰ"))
				return YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡱ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	else: return gniNItGL6bKwpEW(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࡲ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	return JGwsL21ZRlqSrWxEmF(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫࡳ"),[],[]
def duEz093LZo(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,fOc18oTm5hsdD4pVZQj(u"ࠨࡉࡈࡘࠬࡴ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫࡵ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	data = YYqECUofyi7wFrW.findall(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࡶ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if data:
		W2pUR5OSbl,id,M5sz3U6VaPjpCvWSNykcnBtmHFdb = data[e8XhbyuzvjYkIsJUtB5w]
		data = Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡴࡶ࠽ࠨࡷ")+W2pUR5OSbl+Tzx81Wb0RZC4ID5AyiU2(u"ࠬࠬࡩࡥ࠿ࠪࡸ")+id+QQHFtjcaR2VpnSyTIv(u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧࡹ")+M5sz3U6VaPjpCvWSNykcnBtmHFdb
		headers = {rNyT0edugn(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ࡺ"):HVmIrFwau90jQsgiWzExk(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧࡻ")}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡓࡓࡘ࡚ࠧࡼ"),url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠴ࡱࡨࠬࡽ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࠧࡸࡥࡧࡧࡵࡩࡷࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡾ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij: return HVmIrFwau90jQsgiWzExk(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡿ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]]
	return kb2icmDGVUZfW1OFz7sv(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪࢀ"),[],[]
def WMNy1hKjbO(url):
	headers = {lrtFSogC8Nh9(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪࢁ"):fOc18oTm5hsdD4pVZQj(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩࢂ")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,NeU6uRGpECkvMV5jf(u"ࠩࡊࡉ࡙࠭ࢃ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮࠳ࡶࡸࠬࢄ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢅ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w].replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
		return OOkmZiVcfqlEurM1dHGb(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࢆ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return lrtFSogC8Nh9(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪࢇ"),[],[]
def aajQ2ou438(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url.split(QQHFtjcaR2VpnSyTIv(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࢈"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w].strip(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡁࠪࢉ")).strip(lrtFSogC8Nh9(u"ࠩ࠲ࠫࢊ")).strip(HVmIrFwau90jQsgiWzExk(u"ࠪࠪࠬࢋ"))
	IGEpKNCaiLMT,UTwH7zjZOrmFl,items,Afey3cL4ojzg = [],[],[],NdKhAS6MXVEORLTwob92pxlZ
	headers = { R3lezw8h407ZvrAFxT(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࢌ"):YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬࢍ") }
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡇࡆࡖࠪࢎ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠶ࡹࡴࠨ࢏"))
	if lNTJCZeBicWEz0Mg(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ࢐") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()): Afey3cL4ojzg = VNc1u4edS90FK5W6bsMgQC2B.headers[OOkmZiVcfqlEurM1dHGb(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ࢑")]
	if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪ࡬ࡹࡺࡰࠨ࢒") in Afey3cL4ojzg:
		if rNyT0edugn(u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ࢓") in url: Afey3cL4ojzg = Afey3cL4ojzg.replace(lRP6GTaZJA1Xw3egLM4(u"ࠬ࠵ࡦ࠰ࠩ࢔"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠭࠯ࡷ࠱ࠪ࢕"))
		YiXIq6R5rAUBSO1afGZcD = BfjcMoqOsmdUvZVCHWIyQKi.split(JGwsL21ZRlqSrWxEmF(u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ࢖"))[llxMLe4gobHhsj1WGvd7qmIU]
		headers = { HVmIrFwau90jQsgiWzExk(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࢗ"):headers[kb2icmDGVUZfW1OFz7sv(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࢘")] , QQHFtjcaR2VpnSyTIv(u"ࠪࡇࡴࡵ࡫ࡪࡧ࢙ࠪ"):rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡕࡎࡐࡔࡋࡇࡁ࢚ࠬ")+YiXIq6R5rAUBSO1afGZcD }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,lrtFSogC8Nh9(u"ࠬࡍࡅࡕ࢛ࠩ"),Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,headers,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ࢜"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧ࠰ࡨ࠲ࠫ࢝") in Afey3cL4ojzg: items = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࢞"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		elif rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩ࠲ࡺ࠴࠭࢟") in Afey3cL4ojzg: items = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢠ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if items: return [],[NdKhAS6MXVEORLTwob92pxlZ],[ items[e8XhbyuzvjYkIsJUtB5w] ]
		elif lrtFSogC8Nh9(u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪࢡ") in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			return V0VZk9763fusTReHFo4(u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้หๆหำ้ฮࠥอไฯษุอࠥฮใࠨࢢ"),[],[]
	else: return WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕࠩࢣ"),[],[]
def Y2SNCRe4AX(zehVcU893FC6LEd1Aij):
	BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(JGwsL21ZRlqSrWxEmF(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩࢤ"),zehVcU893FC6LEd1Aij+HVmIrFwau90jQsgiWzExk(u"ࠨࠨࠩࠫࢥ"),YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
	hCjvUfTn43KDe2BdlYZH6PVFyIuOb,PCdTnUSfhk5x = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
	url = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪࢦ")+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+lNTJCZeBicWEz0Mg(u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧࢧ")+PCdTnUSfhk5x
	headers = { ggWEFaH6fcVIO9SzRZLiuxo7P(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࢨ"):NdKhAS6MXVEORLTwob92pxlZ , fOc18oTm5hsdD4pVZQj(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨࢩ"):R3lezw8h407ZvrAFxT(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧࢪ") }
	BfjcMoqOsmdUvZVCHWIyQKi = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭ࢫ"))
	return rNyT0edugn(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢬ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
def Mv1S0NnoLc(url):
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡸࡶࡱ࠭ࢭ"))
	omrd89nv0PGKFpL3TxfAXt = {R3lezw8h407ZvrAFxT(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫࢮ"):oikt6P0hOAD5IvnlMpxf1,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ࢯ"):YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬࢰ")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(MIT0n79k8beo26aJHW,IlL8ZnX74Yvep(u"࠭ࡇࡆࡖࠪࢱ"),url,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡉࡉࡎࡃ࠰࠵ࡸࡺࠧࢲ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩࢳ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = NdKhAS6MXVEORLTwob92pxlZ
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
		items = YYqECUofyi7wFrW.findall(R3lezw8h407ZvrAFxT(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢴ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
		for title,zehVcU893FC6LEd1Aij in items:
			IGEpKNCaiLMT.append(title)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		if len(UTwH7zjZOrmFl)==llxMLe4gobHhsj1WGvd7qmIU: BfjcMoqOsmdUvZVCHWIyQKi = UTwH7zjZOrmFl[e8XhbyuzvjYkIsJUtB5w]
		elif len(UTwH7zjZOrmFl)>llxMLe4gobHhsj1WGvd7qmIU:
			rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(HHvYL68lbJVZWM7tQEzSex3(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨࢵ"), IGEpKNCaiLMT)
			if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return QQHFtjcaR2VpnSyTIv(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢶ"),[],[]
			BfjcMoqOsmdUvZVCHWIyQKi = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢷ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: BfjcMoqOsmdUvZVCHWIyQKi = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
	if not BfjcMoqOsmdUvZVCHWIyQKi: return pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨࢸ"),[],[]
	return WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࢹ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
def W4HYvIXqED52Gm7MFNgdOJiB(url):
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡷࡵࡰࠬࢺ"))
	omrd89nv0PGKFpL3TxfAXt = {OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࢻ"):oikt6P0hOAD5IvnlMpxf1,JGwsL21ZRlqSrWxEmF(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬࢼ"):rNyT0edugn(u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫࢽ")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(MIT0n79k8beo26aJHW,OOkmZiVcfqlEurM1dHGb(u"ࠬࡍࡅࡕࠩࢾ"),url,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡉࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ࢿ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨࣀ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	BfjcMoqOsmdUvZVCHWIyQKi = NdKhAS6MXVEORLTwob92pxlZ
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
		items = YYqECUofyi7wFrW.findall(eGW7cI6aQhr0(u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣁ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
		for title,zehVcU893FC6LEd1Aij in items:
			IGEpKNCaiLMT.append(title)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
		if len(UTwH7zjZOrmFl)==llxMLe4gobHhsj1WGvd7qmIU: BfjcMoqOsmdUvZVCHWIyQKi = UTwH7zjZOrmFl[e8XhbyuzvjYkIsJUtB5w]
		elif len(UTwH7zjZOrmFl)>llxMLe4gobHhsj1WGvd7qmIU:
			rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(IlL8ZnX74Yvep(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣂ"), IGEpKNCaiLMT)
			if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣃ"),[],[]
			BfjcMoqOsmdUvZVCHWIyQKi = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	if not BfjcMoqOsmdUvZVCHWIyQKi:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࣄ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: BfjcMoqOsmdUvZVCHWIyQKi = bMU7NEFK5RJ8dcz0jtqiWmvyar6[e8XhbyuzvjYkIsJUtB5w]
	if not BfjcMoqOsmdUvZVCHWIyQKi: return WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧࣅ"),[],[]
	return wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࣆ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
def er3kMPhVNc(zehVcU893FC6LEd1Aij):
	BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ࣇ"),zehVcU893FC6LEd1Aij+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠨࠩࠫࣈ"),YYqECUofyi7wFrW.DOTALL)
	url,hCjvUfTn43KDe2BdlYZH6PVFyIuOb,PCdTnUSfhk5x = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
	data = {PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪࣉ"):hCjvUfTn43KDe2BdlYZH6PVFyIuOb,rNyT0edugn(u"ࠪࡷࡪࡸࡶࡦࡴࠪ࣊"):PCdTnUSfhk5x}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,kb2icmDGVUZfW1OFz7sv(u"ࠫࡕࡕࡓࡕࠩ࣋"),url,data,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ࣌"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(eGW7cI6aQhr0(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࣍"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[e8XhbyuzvjYkIsJUtB5w]
	return OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࣎"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
def KkQ9eFYNl2(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡉࡈࡘ࣏ࠬ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮࠳ࡶࡸ࣐ࠬ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(rNyT0edugn(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ࣑ࠫࠥࠫ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		if zehVcU893FC6LEd1Aij: return OOkmZiVcfqlEurM1dHGb(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࣒ࠧ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return OOkmZiVcfqlEurM1dHGb(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖ࣓ࠪ"),[],[]
def zd351qvLMF(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,IlL8ZnX74Yvep(u"࠭ࡇࡆࡖࠪࣔ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩࣕ"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(IlL8ZnX74Yvep(u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣖ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[e8XhbyuzvjYkIsJUtB5w]
	return PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣗ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def igcP5NRLxS(url):
	p9pPoLdYMbqwXz1FQraUxKNv35 = msbTrJW03xuvA(url,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡹࡷࡲࠧࣘ"))
	if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࡮ࡴࡤࡦࡺࡀࠫࣙ") in url:
		headers = {hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ࣚ"):p9pPoLdYMbqwXz1FQraUxKNv35}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡇࡆࡖࠪࣛ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨࣜ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(eGW7cI6aQhr0(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣝ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if BfjcMoqOsmdUvZVCHWIyQKi:
			BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]
			if kb2icmDGVUZfW1OFz7sv(u"ࠩ࡫ࡸࡹࡶࠧࣞ") not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡬ࡹࡺࡰ࠻ࠩࣟ")+BfjcMoqOsmdUvZVCHWIyQKi
			if fOc18oTm5hsdD4pVZQj(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ࣠") in BfjcMoqOsmdUvZVCHWIyQKi:
				BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ࣡"),wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ࣢"))
				VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡈࡇࡗࣣࠫ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩࣤ"))
				HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
				items = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣥ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
				IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
				Q5Jbsopg4HhxqTY = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,JGwsL21ZRlqSrWxEmF(u"ࠪࡹࡷࡲࣦࠧ"))
				for zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA in reversed(items):
					zehVcU893FC6LEd1Aij = Q5Jbsopg4HhxqTY+zehVcU893FC6LEd1Aij+JGwsL21ZRlqSrWxEmF(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧࣧ")+Q5Jbsopg4HhxqTY
					IGEpKNCaiLMT.append(a0ao2jdlt4r9nhHwpvSgOVGA)
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
				return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
			else: return ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣨ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	BfjcMoqOsmdUvZVCHWIyQKi = url+rNyT0edugn(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࣩࠩ")+p9pPoLdYMbqwXz1FQraUxKNv35
	if Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡩࡶࡷࡴࠬ࣪") not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = lNTJCZeBicWEz0Mg(u"ࠨࡪࡷࡸࡵࡀࠧ࣫")+BfjcMoqOsmdUvZVCHWIyQKi
	return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
def frZNhe5TLv9tKHokIU1J(zehVcU893FC6LEd1Aij):
	p9pPoLdYMbqwXz1FQraUxKNv35 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,lRP6GTaZJA1Xw3egLM4(u"ࠩࡸࡶࡱ࠭࣬"))
	if Hlp3z0APt1GR4kMYK5xST(u"ࠪࡴࡴࡹࡴࡪࡦ࣭ࠪ") in zehVcU893FC6LEd1Aij:
		BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨ࣮ࠪ"),zehVcU893FC6LEd1Aij+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠬࠦࠨ࣯"),YYqECUofyi7wFrW.DOTALL)
		url,hCjvUfTn43KDe2BdlYZH6PVFyIuOb,PCdTnUSfhk5x = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
		data = {V0VZk9763fusTReHFo4(u"࠭ࡩࡥࣰࠩ"):hCjvUfTn43KDe2BdlYZH6PVFyIuOb,HVmIrFwau90jQsgiWzExk(u"ࠧࡴࡧࡵࡺࡪࡸࣱࠧ"):PCdTnUSfhk5x}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,kb2icmDGVUZfW1OFz7sv(u"ࠨࡒࡒࡗࣲ࡙࠭"),url,data,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪࣳ"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣴ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[e8XhbyuzvjYkIsJUtB5w]
		if HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬࣵ") in BfjcMoqOsmdUvZVCHWIyQKi:
			headers = {rNyT0edugn(u"ࠬࡘࡥࡧࡧࡵࡩࡷࣶ࠭"):p9pPoLdYMbqwXz1FQraUxKNv35,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࣷ"):NdKhAS6MXVEORLTwob92pxlZ}
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,gniNItGL6bKwpEW(u"ࠧࡈࡇࡗࠫࣸ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࣹࠩ"))
			HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
			items = YYqECUofyi7wFrW.findall(HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣺ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
			Q5Jbsopg4HhxqTY = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡹࡷࡲࠧࣻ"))
			for zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA in reversed(items):
				zehVcU893FC6LEd1Aij = Q5Jbsopg4HhxqTY+zehVcU893FC6LEd1Aij+kb2icmDGVUZfW1OFz7sv(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧࣼ")+Q5Jbsopg4HhxqTY
				IGEpKNCaiLMT.append(a0ao2jdlt4r9nhHwpvSgOVGA)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
		else: return lNTJCZeBicWEz0Mg(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣽ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	else:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+NOrchaEV1iIZ87Uzlwgum(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩࣾ")+p9pPoLdYMbqwXz1FQraUxKNv35
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
def qqUfHpWYb2(zehVcU893FC6LEd1Aij):
	if PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡱࡱࡶࡸ࡮ࡪࠧࣿ") in zehVcU893FC6LEd1Aij:
		BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪऀ"),zehVcU893FC6LEd1Aij+kb2icmDGVUZfW1OFz7sv(u"ࠩࠩࠪࠬँ"),YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb,PCdTnUSfhk5x = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
		hJwkd3LAI12PUQtin04 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,R3lezw8h407ZvrAFxT(u"ࠪࡹࡷࡲࠧं"))
		url = hJwkd3LAI12PUQtin04+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩः")+hCjvUfTn43KDe2BdlYZH6PVFyIuOb+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩऄ")+PCdTnUSfhk5x
		headers = { JGwsL21ZRlqSrWxEmF(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪअ"):NdKhAS6MXVEORLTwob92pxlZ , V0VZk9763fusTReHFo4(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪआ"):kb2icmDGVUZfW1OFz7sv(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩइ") }
		BfjcMoqOsmdUvZVCHWIyQKi = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠲ࡵࡷࠫई"))
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)
		return pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭उ"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	elif NOrchaEV1iIZ87Uzlwgum(u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨऊ") in zehVcU893FC6LEd1Aij:
		SyTm6WjEM0P1ApXuNlixtwOqRkLQ = e8XhbyuzvjYkIsJUtB5w
		while ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩऋ") in zehVcU893FC6LEd1Aij and SyTm6WjEM0P1ApXuNlixtwOqRkLQ<HHvYL68lbJVZWM7tQEzSex3(u"࠵೽"):
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡇࡆࡖࠪऌ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OOkmZiVcfqlEurM1dHGb(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩऍ"))
			if kb2icmDGVUZfW1OFz7sv(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪऎ") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()): zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[rNyT0edugn(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫए")]
			SyTm6WjEM0P1ApXuNlixtwOqRkLQ += llxMLe4gobHhsj1WGvd7qmIU
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	else: return WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧऐ"),[],[]
def TsmavPO7dc(url):
	oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡺࡸ࡬ࠨऑ"))
	headers = {JGwsL21ZRlqSrWxEmF(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ऒ"):oikt6P0hOAD5IvnlMpxf1,ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪओ"):kkCjlxiynwT34GVFc()}
	if lrtFSogC8Nh9(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨऔ") in url:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪक"))
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨख"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w].replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡬ࡹࡺࡰࡴࠩग"),lrtFSogC8Nh9(u"ࠫ࡭ࡺࡴࡱࠩघ"))
			return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	else:
		YWGy2NKdghfRsZmSOepQHv5cU = cJaAB4uQyp(OewIv05xGhKQpFf,IlL8ZnX74Yvep(u"ࠬࡍࡅࡕࠩङ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨच"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = YWGy2NKdghfRsZmSOepQHv5cU.content
		omrd89nv0PGKFpL3TxfAXt = headers.copy()
		if R3lezw8h407ZvrAFxT(u"ࠧࡠ࡮ࡱ࡯ࡤ࠭छ") in str(YWGy2NKdghfRsZmSOepQHv5cU.cookies):
			cookies = YWGy2NKdghfRsZmSOepQHv5cU.cookies
			omrd89nv0PGKFpL3TxfAXt[R3lezw8h407ZvrAFxT(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨज")] = OOFEmwq2GkTz93WXy1Nj(g1Vmb5T39C(cookies))
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬझ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not zehVcU893FC6LEd1Aij: return NeU6uRGpECkvMV5jf(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ञ"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
		else:
			zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w])+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࠫࡪ࠽࠲ࠩट")
			HYfNLiDK3yRF7 = cJaAB4uQyp(OewIv05xGhKQpFf,kb2icmDGVUZfW1OFz7sv(u"ࠬࡍࡅࡕࠩठ"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠹ࡺࡨࠨड"))
			LMKFcEkU1Q7R80yt4OsgvwxbfP = HYfNLiDK3yRF7.content
			zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(JGwsL21ZRlqSrWxEmF(u"ࠧࡪࡦࡀࠦࡧࡺ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪढ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if zehVcU893FC6LEd1Aij:
				zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w])
				if NOrchaEV1iIZ87Uzlwgum(u"ࠨ࡯ࡳ࠸ࠬण") in zehVcU893FC6LEd1Aij and hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࠲ࡨ࠴࠭त") in zehVcU893FC6LEd1Aij: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
				else: return hCm2fnEXs6Zt(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭थ"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return JGwsL21ZRlqSrWxEmF(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨद"),[],[]
def WrGxOkJPCN(zehVcU893FC6LEd1Aij):
	if lNTJCZeBicWEz0Mg(u"ࠬࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠩध") in zehVcU893FC6LEd1Aij:
		headers = {ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩन"):PzIpQnUXxRwNCivDhdakWTE(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨऩ")}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,lRP6GTaZJA1Xw3egLM4(u"ࠨࡉࡈࡘࠬप"),zehVcU893FC6LEd1Aij,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫफ"))
		url = VNc1u4edS90FK5W6bsMgQC2B.content
		if url: return PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ब"),[NdKhAS6MXVEORLTwob92pxlZ],[url]
	else:
		BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬभ"),zehVcU893FC6LEd1Aij,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if not BDkTn4JaU3HsYzI: BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(JGwsL21ZRlqSrWxEmF(u"ࠬࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨम"),zehVcU893FC6LEd1Aij,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		hCjvUfTn43KDe2BdlYZH6PVFyIuOb,PCdTnUSfhk5x = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
		oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(zehVcU893FC6LEd1Aij,lrtFSogC8Nh9(u"࠭ࡵࡳ࡮ࠪय"))
		url = oikt6P0hOAD5IvnlMpxf1+Hlp3z0APt1GR4kMYK5xST(u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨर")
		data = {lrtFSogC8Nh9(u"ࠨ࡫ࡧࠫऱ"):hCjvUfTn43KDe2BdlYZH6PVFyIuOb,gniNItGL6bKwpEW(u"ࠩ࡬ࠫल"):PCdTnUSfhk5x}
		headers = {LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ळ"):QQHFtjcaR2VpnSyTIv(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬऴ"),R3lezw8h407ZvrAFxT(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭व"):zehVcU893FC6LEd1Aij}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,hCm2fnEXs6Zt(u"࠭ࡐࡐࡕࡗࠫश"),url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠸࡮ࡥࠩष"))
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
		BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭स"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if BfjcMoqOsmdUvZVCHWIyQKi:
			BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w]
			return NeU6uRGpECkvMV5jf(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬह"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	return fOc18oTm5hsdD4pVZQj(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡂࡊࡌࡈ࠹࡛ࠧऺ"),[],[]
def kYe8jlqfS51Cs2aMRF(NejavJwnuG2Rd94V):
	Svz7JDX8sAT9lPpwibg3h4MO = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(HVmIrFwau90jQsgiWzExk(u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬऻ"))
	headers = {rNyT0edugn(u"ࠬࡉ࡯ࡰ࡭࡬ࡩ़ࠬ"):Svz7JDX8sAT9lPpwibg3h4MO} if Svz7JDX8sAT9lPpwibg3h4MO else NdKhAS6MXVEORLTwob92pxlZ
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,hCm2fnEXs6Zt(u"࠭ࡇࡆࡖࠪऽ"),NejavJwnuG2Rd94V,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠵ࡸࡺࠧा"))
	yjZWDU9r4ALoMtFTmBdgqe = VNc1u4edS90FK5W6bsMgQC2B.content
	mm0OrvwLt96pChUQuyR = str(VNc1u4edS90FK5W6bsMgQC2B.headers)
	S9bpYs3tzv42rE8 = mm0OrvwLt96pChUQuyR+yjZWDU9r4ALoMtFTmBdgqe
	if wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨ࠰ࡰࡴ࠹࠭ि") in S9bpYs3tzv42rE8: NElpa837fkWBKeqY = k6apiPAlLKM1ed8J42RjHh0o
	else:
		CYqOpzoluWMn632Si,JMox3q27Fi1Rd468Z,V8Q3p9dnGtslvuS2,UU8TripJhfwmg2vluR7O,NElpa837fkWBKeqY = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s
		captcha = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧी"),yjZWDU9r4ALoMtFTmBdgqe,YYqECUofyi7wFrW.DOTALL)
		if captcha: V8Q3p9dnGtslvuS2,UU8TripJhfwmg2vluR7O = captcha[e8XhbyuzvjYkIsJUtB5w]
		qMprWTDUZYfJQk3HE2Adg = xKp3jkIvM09AZ4euXa87i5TVtfUD[gniNItGL6bKwpEW(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪु")][ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠸೾")]
		if e8XhbyuzvjYkIsJUtB5w:
			data = {lrtFSogC8Nh9(u"ࠫࡺࡹࡥࡳࠩू"):lop0ZwWYLmxOPAaErzF6cQvDkVR,NOrchaEV1iIZ87Uzlwgum(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ृ"):lvsJ2jaZktmNO6PbdXS,R3lezw8h407ZvrAFxT(u"࠭ࡵࡳ࡮ࠪॄ"):NejavJwnuG2Rd94V,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧ࡬ࡧࡼࠫॅ"):UU8TripJhfwmg2vluR7O,QQHFtjcaR2VpnSyTIv(u"ࠨ࡫ࡧࠫॆ"):NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠩ࡭ࡳࡧ࠭े"):lrtFSogC8Nh9(u"ࠪ࡫ࡪࡺࡵࡳ࡮ࡶࠫै")}
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,lNTJCZeBicWEz0Mg(u"ࠫࡕࡕࡓࡕࠩॉ"),qMprWTDUZYfJQk3HE2Adg,data,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠴ࡱࡨࠬॊ"))
			LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NdKhAS6MXVEORLTwob92pxlZ
		if LMKFcEkU1Q7R80yt4OsgvwxbfP.startswith(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡕࡓࡎࡖࡁࠬो")):
			myEZsYk69Jj02AKPHQ7zgdh3VtU4I = BdnA8WwtJeKUVvE(kb2icmDGVUZfW1OFz7sv(u"ࠧ࡭࡫ࡶࡸࠬौ"),LMKFcEkU1Q7R80yt4OsgvwxbfP.split(Hlp3z0APt1GR4kMYK5xST(u"ࠨࡗࡕࡐࡘࡃ्ࠧ"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU])
			for kF13d0oJXn4xKH in myEZsYk69Jj02AKPHQ7zgdh3VtU4I:
				url = kF13d0oJXn4xKH[PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡸࡶࡱ࠭ॎ")]
				VHkeUzoTxc9yl8rpaJO = kF13d0oJXn4xKH[NOrchaEV1iIZ87Uzlwgum(u"ࠪࡱࡪࡺࡨࡰࡦࠪॏ")]
				data = kF13d0oJXn4xKH[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡩࡧࡴࡢࠩॐ")]
				headers = kF13d0oJXn4xKH[HVmIrFwau90jQsgiWzExk(u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭॑")]
				VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,VHkeUzoTxc9yl8rpaJO,url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ॒࠭"))
				yjZWDU9r4ALoMtFTmBdgqe = VNc1u4edS90FK5W6bsMgQC2B.content
				if fOc18oTm5hsdD4pVZQj(u"ࠧ࠯࡯ࡳ࠸ࠬ॓") in yjZWDU9r4ALoMtFTmBdgqe:
					NElpa837fkWBKeqY = k6apiPAlLKM1ed8J42RjHh0o
					break
				mm0OrvwLt96pChUQuyR = str(VNc1u4edS90FK5W6bsMgQC2B.headers)
				S9bpYs3tzv42rE8 = mm0OrvwLt96pChUQuyR+yjZWDU9r4ALoMtFTmBdgqe
				CYqOpzoluWMn632Si = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"ࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡢࡷࠬࠫ࠱࠮ࡄࠨࠨࡦࡻࡍ࠲࠯ࡅࠩࠣࠩ॔"),S9bpYs3tzv42rE8,YYqECUofyi7wFrW.DOTALL)
				JMox3q27Fi1Rd468Z = YYqECUofyi7wFrW.findall(HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱ࠲࠯ࡅࠢࠩ࠲࠶ࡅ࠳࠰࠿ࠪࠤࠪॕ"),S9bpYs3tzv42rE8,YYqECUofyi7wFrW.DOTALL)
				if JMox3q27Fi1Rd468Z: JMox3q27Fi1Rd468Z = JMox3q27Fi1Rd468Z[e8XhbyuzvjYkIsJUtB5w]
				if CYqOpzoluWMn632Si or JMox3q27Fi1Rd468Z: break
		if not NElpa837fkWBKeqY:
			if not CYqOpzoluWMn632Si:
				if captcha and not JMox3q27Fi1Rd468Z:
					if llxMLe4gobHhsj1WGvd7qmIU: JMox3q27Fi1Rd468Z = zW4UEsR59mvrA1tGhSq(UU8TripJhfwmg2vluR7O,Hlp3z0APt1GR4kMYK5xST(u"ࠪࡥࡷ࠭ॖ"),NejavJwnuG2Rd94V)
					else:
						if not LMKFcEkU1Q7R80yt4OsgvwxbfP.startswith(V0VZk9763fusTReHFo4(u"ࠫࡎࡊ࠽ࠨॗ")):
							data = {pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡻࡳࡦࡴࠪक़"):lop0ZwWYLmxOPAaErzF6cQvDkVR,vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧख़"):lvsJ2jaZktmNO6PbdXS,JGwsL21ZRlqSrWxEmF(u"ࠧࡶࡴ࡯ࠫग़"):NejavJwnuG2Rd94V,HVmIrFwau90jQsgiWzExk(u"ࠨ࡭ࡨࡽࠬज़"):UU8TripJhfwmg2vluR7O,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࡬ࡨࠬड़"):NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"ࠪ࡮ࡴࡨࠧढ़"):R3lezw8h407ZvrAFxT(u"ࠫ࡬࡫ࡴࡪࡦࠪफ़")}
							VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡖࡏࡔࡖࠪय़"),qMprWTDUZYfJQk3HE2Adg,data,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠷ࡸ࡭࠭ॠ"))
							LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
						else: LMKFcEkU1Q7R80yt4OsgvwxbfP = HHvYL68lbJVZWM7tQEzSex3(u"ࠧࡊࡆࡀ࠵࠷࠹࠴࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠺࠵ࠨॡ")
						if LMKFcEkU1Q7R80yt4OsgvwxbfP.startswith(rNyT0edugn(u"ࠨࡋࡇࡁࠬॢ")):
							DGokc4fO8UTjqms5VSKMZuvpJWN1b = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠩࡌࡈࡂ࠮࠮ࠫࡁࠬ࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨॣ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
							I92F8dQzr5peL1Mls74wfqECk3chA,t7GucK3fAw = DGokc4fO8UTjqms5VSKMZuvpJWN1b[e8XhbyuzvjYkIsJUtB5w]
							JzNoqV8ClRD6O = Tzx81Wb0RZC4ID5AyiU2(u"๋ࠪีํࠠศๆ฼้้๐ษࠡฬะฮฬา้ࠠไอࠤ๊์ࠠ࠲࠲ࠣษ้๏ࠠࠨ।")+t7GucK3fAw+PzIpQnUXxRwNCivDhdakWTE(u"ࠫࠥัว็์ฬࠫ॥")
							muL0lDzdjc7EA4pNJgYfbGq = UpNqSvlOPeuKntGWCT1rR3aI4b()
							muL0lDzdjc7EA4pNJgYfbGq.create(lRP6GTaZJA1Xw3egLM4(u"๋ࠬอศ๊็อࠥะฬศ๊ีࠤๆำีࠡล้หࠥษๆิษ้ࠤํ๊ำหࠢหี๋อๅอࠢๆ์๊ฮ๊้ฬิࠫ०"),JzNoqV8ClRD6O)
							DIzg1tGYOFkCBwy = XJ62UBRmIqFvfiNTQj.time()
							XlyRYBaMWCNL6c4fHut5Is20jQTz,jLRu1zWA9v5mSE2Ds8qMV0lBpKG = e8XhbyuzvjYkIsJUtB5w,e8XhbyuzvjYkIsJUtB5w
							while XlyRYBaMWCNL6c4fHut5Is20jQTz<int(t7GucK3fAw):
								BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,int(XlyRYBaMWCNL6c4fHut5Is20jQTz/int(t7GucK3fAw)*HVmIrFwau90jQsgiWzExk(u"࠳࠳࠴೿")),JzNoqV8ClRD6O,NdKhAS6MXVEORLTwob92pxlZ,t7GucK3fAw+lNTJCZeBicWEz0Mg(u"࠭ࠠ࠰ࠢࠪ१")+str(int(XlyRYBaMWCNL6c4fHut5Is20jQTz))+lNTJCZeBicWEz0Mg(u"ࠧࠡࠢฮห๋๐ษࠨ२"))
								if XlyRYBaMWCNL6c4fHut5Is20jQTz>jLRu1zWA9v5mSE2Ds8qMV0lBpKG+lrtFSogC8Nh9(u"࠴࠴ഀ"):
									data = {xY4icgQUj6mPVs73CTKu(u"ࠨࡷࡶࡩࡷ࠭३"):lop0ZwWYLmxOPAaErzF6cQvDkVR,kb2icmDGVUZfW1OFz7sv(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ४"):lvsJ2jaZktmNO6PbdXS,JGwsL21ZRlqSrWxEmF(u"ࠪࡹࡷࡲࠧ५"):NejavJwnuG2Rd94V,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡰ࡫ࡹࠨ६"):UU8TripJhfwmg2vluR7O,kb2icmDGVUZfW1OFz7sv(u"ࠬ࡯ࡤࠨ७"):I92F8dQzr5peL1Mls74wfqECk3chA,PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡪࡰࡤࠪ८"):Hlp3z0APt1GR4kMYK5xST(u"ࠧࡨࡧࡷࡸࡴࡱࡥ࡯ࠩ९")}
									VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡒࡒࡗ࡙࠭॰"),qMprWTDUZYfJQk3HE2Adg,data,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩॱ"))
									LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
									if LMKFcEkU1Q7R80yt4OsgvwxbfP.startswith(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪࡘࡔࡑࡅࡏ࠿ࠪॲ")):
										JMox3q27Fi1Rd468Z = LMKFcEkU1Q7R80yt4OsgvwxbfP.split(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࡙ࠫࡕࡋࡆࡐࡀࠫॳ"),YJpWv4QzC7sx8INVPukeZiOD03K(u"࠵ഁ"))[llxMLe4gobHhsj1WGvd7qmIU]
										break
									jLRu1zWA9v5mSE2Ds8qMV0lBpKG = XlyRYBaMWCNL6c4fHut5Is20jQTz
								else: XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
								XlyRYBaMWCNL6c4fHut5Is20jQTz = XJ62UBRmIqFvfiNTQj.time()-DIzg1tGYOFkCBwy
							muL0lDzdjc7EA4pNJgYfbGq.close()
				if JMox3q27Fi1Rd468Z:
					sOKnvihoP7IGfbX = VNc1u4edS90FK5W6bsMgQC2B.cookies
					d1FLKw8qESkjoYDM9AXeQVmGcs2WPI = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬ࠿ࠬॴ"),S9bpYs3tzv42rE8,YYqECUofyi7wFrW.DOTALL)
					if hCm2fnEXs6Zt(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ॵ") in list(sOKnvihoP7IGfbX.keys()): d1FLKw8qESkjoYDM9AXeQVmGcs2WPI = sOKnvihoP7IGfbX[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧॶ")]
					elif d1FLKw8qESkjoYDM9AXeQVmGcs2WPI: d1FLKw8qESkjoYDM9AXeQVmGcs2WPI = d1FLKw8qESkjoYDM9AXeQVmGcs2WPI[e8XhbyuzvjYkIsJUtB5w]
					captcha = YYqECUofyi7wFrW.findall(fOc18oTm5hsdD4pVZQj(u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॷ"),yjZWDU9r4ALoMtFTmBdgqe,YYqECUofyi7wFrW.DOTALL)
					if captcha: V8Q3p9dnGtslvuS2,UU8TripJhfwmg2vluR7O = captcha[e8XhbyuzvjYkIsJUtB5w]
					if d1FLKw8qESkjoYDM9AXeQVmGcs2WPI and captcha:
						headers = {NOrchaEV1iIZ87Uzlwgum(u"ࠩࡆࡳࡴࡱࡩࡦࠩॸ"):kb2icmDGVUZfW1OFz7sv(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠫॹ")+d1FLKw8qESkjoYDM9AXeQVmGcs2WPI,IlL8ZnX74Yvep(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬॺ"):NejavJwnuG2Rd94V,NeU6uRGpECkvMV5jf(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫॻ"):lNTJCZeBicWEz0Mg(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬॼ")}
						data = OOkmZiVcfqlEurM1dHGb(u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠨॽ")+JMox3q27Fi1Rd468Z
						VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,Hlp3z0APt1GR4kMYK5xST(u"ࠨࡒࡒࡗ࡙࠭ॾ"),V8Q3p9dnGtslvuS2,data,headers,f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠼ࡴࡩࠩॿ"))
						yjZWDU9r4ALoMtFTmBdgqe = VNc1u4edS90FK5W6bsMgQC2B.content
						try: cookies = VNc1u4edS90FK5W6bsMgQC2B.cookies
						except: cookies = {}
						CYqOpzoluWMn632Si = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠥࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࠰࠭ࡃ࠮࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤঀ"),str(cookies),YYqECUofyi7wFrW.DOTALL)
			if CYqOpzoluWMn632Si:
				JHKDFe6Am0ruz8,CYqOpzoluWMn632Si = CYqOpzoluWMn632Si[e8XhbyuzvjYkIsJUtB5w]
				Svz7JDX8sAT9lPpwibg3h4MO = JHKDFe6Am0ruz8+lRP6GTaZJA1Xw3egLM4(u"ࠫࡂ࠭ঁ")+CYqOpzoluWMn632Si
				ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OOkmZiVcfqlEurM1dHGb(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ং"),Svz7JDX8sAT9lPpwibg3h4MO)
				ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩঃ"),hCm2fnEXs6Zt(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥหๆิษ้ࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษะี๊ࠥ์สศศฯࠤ์ึวࠡษ็ๅา฻ࠠๅๅํࠤ๏ูสฯั่๋ฬࠦไศฯๅหࠥ࠴࠮๊ࠡ็หࠥะ่อัࠣัฬาษࠡๆศ฽ฬีษ้ࠡำหࠥอไโฯุࠤ้฿ฯสࠢฦุ์ืࠠ࡝ࡰ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้็อึࠢึ์ๆ๊ࠦหๅิีࠥ็๊ࠡฯส่ฮࠦส฻์ิࠤึฮืࠡษ็ะ์อาࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣษ฼็วยࠢิหํะัࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢไู้ࠦำๅๅࠣห้ืว้ฬิࠤ࠳࠴ࠠฤ๊ࠣหุะฮะษ่ࠤ࡛ࡖࡎࠡล๋ࠤอื่ไีํࠫ঄"))
				if lrtFSogC8Nh9(u"ࠨ࠰ࡰࡴ࠹࠭অ") not in yjZWDU9r4ALoMtFTmBdgqe:
					headers = {hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡆࡳࡴࡱࡩࡦࠩআ"):Svz7JDX8sAT9lPpwibg3h4MO}
					VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,eGW7cI6aQhr0(u"ࠪࡋࡊ࡚ࠧই"),NejavJwnuG2Rd94V,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫঈ"))
					yjZWDU9r4ALoMtFTmBdgqe = VNc1u4edS90FK5W6bsMgQC2B.content
	if not NElpa837fkWBKeqY and not Svz7JDX8sAT9lPpwibg3h4MO: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨউ"),QQHFtjcaR2VpnSyTIv(u"࠭แีๆอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ࠲࠳ࠦอศ๊็ࠤส฿วะหࠣห้฿ๅๅ์ฬࠤ๊ืษࠡลัี๎ࠦศศีอาิอๅ่ࠡไืࠥอไโ์า๎ํࠦร้ࠢไ๎ิ๐่ࠡ฼ํี์ࠦๅ็้ࠢๅุࠦวๅ็๋ๆ฾࠭ঊ"))
	return yjZWDU9r4ALoMtFTmBdgqe
def dKusGQWL0z(url,GY9jgon6yhP0IvtCBEJu3,a0ao2jdlt4r9nhHwpvSgOVGA):
	Pj8lY4doOfxiFMuNLhv3tnp,UpvYl7QkMBOTJIeSyCiH92GKfm56rn = [],[]
	NejavJwnuG2Rd94V = url
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,kb2icmDGVUZfW1OFz7sv(u"ࠧࡈࡇࡗࠫঋ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧঌ"))
	HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
	iBlpTHn5JZ381yboeqa4X6 = []
	if HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ঍") in HeFB5x2wED or kb2icmDGVUZfW1OFz7sv(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ঎") in HeFB5x2wED:
		sCRbZp6Irl17v = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠲࠯ࡅ࠼࠰ࡣࡁࠫএ"),HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if sCRbZp6Irl17v:
			for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
				oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall(IlL8ZnX74Yvep(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩঐ"),AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				for zehVcU893FC6LEd1Aij,title in oDhlaxn0EqyYikcHrmZBN8uv:
					if zehVcU893FC6LEd1Aij in Pj8lY4doOfxiFMuNLhv3tnp: continue
					if lRP6GTaZJA1Xw3egLM4(u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ঑") not in zehVcU893FC6LEd1Aij and NeU6uRGpECkvMV5jf(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ঒") not in zehVcU893FC6LEd1Aij: continue
					if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨษࠪও") not in title:
						iBlpTHn5JZ381yboeqa4X6.append((title,zehVcU893FC6LEd1Aij))
						continue
					title = title.replace(V0VZk9763fusTReHFo4(u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪঔ"),NdKhAS6MXVEORLTwob92pxlZ).replace(eGW7cI6aQhr0(u"ࠪࠤ࠲ࠦࠧক"),NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
					if fOc18oTm5hsdD4pVZQj(u"ࠫࡸࡶࡡ࡯ࠩখ") in title: continue
					Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
					UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(title)
			for title,zehVcU893FC6LEd1Aij in iBlpTHn5JZ381yboeqa4X6:
				if zehVcU893FC6LEd1Aij not in Pj8lY4doOfxiFMuNLhv3tnp:
					Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
					UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(title)
			rRfpvbZojlygET5JL87wdzIPGe = e8XhbyuzvjYkIsJUtB5w
			if len(Pj8lY4doOfxiFMuNLhv3tnp)>llxMLe4gobHhsj1WGvd7qmIU:
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(NOrchaEV1iIZ87Uzlwgum(u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬগ"),UpvYl7QkMBOTJIeSyCiH92GKfm56rn)
				if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return OOkmZiVcfqlEurM1dHGb(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫঘ"),[],[]
			if Pj8lY4doOfxiFMuNLhv3tnp and rRfpvbZojlygET5JL87wdzIPGe>=e8XhbyuzvjYkIsJUtB5w: NejavJwnuG2Rd94V = Pj8lY4doOfxiFMuNLhv3tnp[rRfpvbZojlygET5JL87wdzIPGe]
	yjZWDU9r4ALoMtFTmBdgqe = kYe8jlqfS51Cs2aMRF(NejavJwnuG2Rd94V)
	UTwH7zjZOrmFl,IGEpKNCaiLMT = [],[]
	if GY9jgon6yhP0IvtCBEJu3==rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩঙ"):
		GXKTe39O08UaQ4NmEnoHjkF = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭চ"),yjZWDU9r4ALoMtFTmBdgqe,YYqECUofyi7wFrW.DOTALL)
		if GXKTe39O08UaQ4NmEnoHjkF:
			zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(GXKTe39O08UaQ4NmEnoHjkF[e8XhbyuzvjYkIsJUtB5w])
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			IGEpKNCaiLMT.append(a0ao2jdlt4r9nhHwpvSgOVGA)
	elif GY9jgon6yhP0IvtCBEJu3==hCm2fnEXs6Zt(u"ࠩࡺࡥࡹࡩࡨࠨছ"):
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬজ"),yjZWDU9r4ALoMtFTmBdgqe,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,size in oDhlaxn0EqyYikcHrmZBN8uv:
			if not zehVcU893FC6LEd1Aij: continue
			if a0ao2jdlt4r9nhHwpvSgOVGA in size:
				IGEpKNCaiLMT.append(size)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
				break
		if not UTwH7zjZOrmFl:
			for zehVcU893FC6LEd1Aij,size in oDhlaxn0EqyYikcHrmZBN8uv:
				if not zehVcU893FC6LEd1Aij: continue
				IGEpKNCaiLMT.append(size)
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if not UTwH7zjZOrmFl: return PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬঝ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def Nbylaq3nUL(url,JHKDFe6Am0ruz8):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡍࡅࡕࠩঞ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬট"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	cookies = VNc1u4edS90FK5W6bsMgQC2B.cookies
	if QQHFtjcaR2VpnSyTIv(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧঠ") in list(cookies.keys()):
		Svz7JDX8sAT9lPpwibg3h4MO = cookies[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨড")]
		Svz7JDX8sAT9lPpwibg3h4MO = OOFEmwq2GkTz93WXy1Nj(L5xKSr96JmaX7N(Svz7JDX8sAT9lPpwibg3h4MO))
		items = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪঢ"),Svz7JDX8sAT9lPpwibg3h4MO,YYqECUofyi7wFrW.DOTALL)
		BfjcMoqOsmdUvZVCHWIyQKi = items[e8XhbyuzvjYkIsJUtB5w].replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡠ࠴࠭ণ"),Hlp3z0APt1GR4kMYK5xST(u"ࠫ࠴࠭ত"))
		BfjcMoqOsmdUvZVCHWIyQKi = L5xKSr96JmaX7N(BfjcMoqOsmdUvZVCHWIyQKi)
	else: BfjcMoqOsmdUvZVCHWIyQKi = url
	if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧথ") in BfjcMoqOsmdUvZVCHWIyQKi:
		Wm7RJb1HIyvZsphFfEU8Yc = BfjcMoqOsmdUvZVCHWIyQKi.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࠥ࠳ࡈࠪদ"))[-llxMLe4gobHhsj1WGvd7qmIU]
		BfjcMoqOsmdUvZVCHWIyQKi = NeU6uRGpECkvMV5jf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪধ")+Wm7RJb1HIyvZsphFfEU8Yc
		return R3lezw8h407ZvrAFxT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫন"),[NdKhAS6MXVEORLTwob92pxlZ],[BfjcMoqOsmdUvZVCHWIyQKi]
	else:
		website = xKp3jkIvM09AZ4euXa87i5TVtfUD[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡄࡏࡔࡇࡍࠨ঩")][e8XhbyuzvjYkIsJUtB5w]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡋࡊ࡚ࠧপ"),website,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,k6apiPAlLKM1ed8J42RjHh0o,NdKhAS6MXVEORLTwob92pxlZ,HVmIrFwau90jQsgiWzExk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠲࡯ࡦࠪফ"))
		OtpMBh9kmdyjasb = VNc1u4edS90FK5W6bsMgQC2B.url
		mKfBFuIDRO91LYenUCvXMViks2rq3E = BfjcMoqOsmdUvZVCHWIyQKi.split(gniNItGL6bKwpEW(u"ࠬ࠵ࠧব"))[cCRvAuJQfjBpTg0PbYiaNO87]
		clnRG4AzrIWY0bh = OtpMBh9kmdyjasb.split(fOc18oTm5hsdD4pVZQj(u"࠭࠯ࠨভ"))[cCRvAuJQfjBpTg0PbYiaNO87]
		Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi.replace(mKfBFuIDRO91LYenUCvXMViks2rq3E,clnRG4AzrIWY0bh)
		headers = { hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫম"):NdKhAS6MXVEORLTwob92pxlZ , V0VZk9763fusTReHFo4(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫয"):PzIpQnUXxRwNCivDhdakWTE(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪর") , eGW7cI6aQhr0(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ঱"):Afey3cL4ojzg }
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,fOc18oTm5hsdD4pVZQj(u"ࠫࡕࡕࡓࡕࠩল"), Afey3cL4ojzg, NdKhAS6MXVEORLTwob92pxlZ, headers, f4vncKMRlXG9s,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫ঳"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		items = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭঴"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if not items:
			items = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ঵"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
			if not items:
				items = YYqECUofyi7wFrW.findall(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨশ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		if items:
			zehVcU893FC6LEd1Aij = items[e8XhbyuzvjYkIsJUtB5w].replace(eGW7cI6aQhr0(u"ࠩ࡟࠳ࠬষ"),eGW7cI6aQhr0(u"ࠪ࠳ࠬস"))
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.rstrip(OOkmZiVcfqlEurM1dHGb(u"ࠫ࠴࠭হ"))
			if OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬ࡮ࡴࡵࡲࠪ঺") not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = fOc18oTm5hsdD4pVZQj(u"࠭ࡨࡵࡶࡳ࠾ࠬ঻") + zehVcU893FC6LEd1Aij
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(NeU6uRGpECkvMV5jf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ়"),Hlp3z0APt1GR4kMYK5xST(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪঽ"))
			if JHKDFe6Am0ruz8==NdKhAS6MXVEORLTwob92pxlZ: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
			else: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = IlL8ZnX74Yvep(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬা"),[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
		else: BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡐࡃࡐࠫি"),[],[]
		return BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
def RvVIaX5d803B(url):
	headers = { OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨী") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩু"))
	items = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧূ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	IGEpKNCaiLMT,UTwH7zjZOrmFl,errno = [],[],NdKhAS6MXVEORLTwob92pxlZ
	if items:
		for zehVcU893FC6LEd1Aij,TWqGAlsD0bpihcwOB3FLfYKMdxgC in items:
			IGEpKNCaiLMT.append(TWqGAlsD0bpihcwOB3FLfYKMdxgC)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return NeU6uRGpECkvMV5jf(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭ৃ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def WeyK7mVkESYq0Zif(url):
	f1BA08uJ2nePQcdCHRqNEZKoGM = url.split(HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࠱ࠪৄ"))[hCm2fnEXs6Zt(u"࠸ം")]
	data = lNTJCZeBicWEz0Mg(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠧ࡫ࡧࡁࠬ৅")+f1BA08uJ2nePQcdCHRqNEZKoGM
	headers = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ৆"):WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪে")}
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,eGW7cI6aQhr0(u"ࠬࡖࡏࡔࡖࠪৈ"),url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡖࡉࡒ࠭࠲ࡵࡷࠫ৉"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠧࡢࡦࡥࡰࡴࡩ࡫ࡠࡦࡨࡸࡪࡩࡴࡦࡦ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৊"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		url = items[e8XhbyuzvjYkIsJUtB5w]
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	return PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡗࡊࡌࠨো"),[],[]
def wWfenLMcu4s6(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,Hlp3z0APt1GR4kMYK5xST(u"ࠩࡊࡉ࡙࠭ৌ"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,kb2icmDGVUZfW1OFz7sv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡌ࠯࠴ࡷࡹ্࠭"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	try: LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.decode(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࡺࡺࡦ࠹ࠩৎ"),V0VZk9763fusTReHFo4(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ৏"))
	except: pass
	items = YYqECUofyi7wFrW.findall(R3lezw8h407ZvrAFxT(u"࠭ࡤࡰࡥࡶࡣࡳࡵ࡟ࡱࡴࡨࡺ࡮࡫ࡷࡠࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৐"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		url = items[e8XhbyuzvjYkIsJUtB5w]
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	return V0VZk9763fusTReHFo4(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡏࠬ৑"),[],[]
def Gr28xomQivj3VHtsFnbWdLhguSfp(url):
	headers = {OOkmZiVcfqlEurM1dHGb(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ৒"):NdKhAS6MXVEORLTwob92pxlZ}
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ৓"))
	items = YYqECUofyi7wFrW.findall(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৔"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		url = items[e8XhbyuzvjYkIsJUtB5w]+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ৕")+url
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	return xY4icgQUj6mPVs73CTKu(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡓࡏࡓࡆࡊࠧ৖"),[],[]
def ug4d8qH5DlQXALm1F(url):
	url = url.strip(V0VZk9763fusTReHFo4(u"࠭࠯ࠨৗ"))
	if HHvYL68lbJVZWM7tQEzSex3(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ৘") in url: Wm7RJb1HIyvZsphFfEU8Yc = url.split(NeU6uRGpECkvMV5jf(u"ࠨ࠱ࠪ৙"))[TQNS6YMKAqnilsVObLpDRX]
	else: Wm7RJb1HIyvZsphFfEU8Yc = url.split(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࠲ࠫ৚"))[-llxMLe4gobHhsj1WGvd7qmIU]
	url = lRP6GTaZJA1Xw3egLM4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡩࡳࡵࡴࡨࡥࡲ࠴ࡴࡰ࠱ࡳࡰࡦࡿࡥࡳࡁࡩ࡭ࡩࡃࠧ৛") + Wm7RJb1HIyvZsphFfEU8Yc
	headers = { WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨড়") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧঢ়"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.replace(NeU6uRGpECkvMV5jf(u"࠭࡜࡝ࠩ৞"),NdKhAS6MXVEORLTwob92pxlZ)
	items = YYqECUofyi7wFrW.findall(fOc18oTm5hsdD4pVZQj(u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧয়"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[ items[e8XhbyuzvjYkIsJUtB5w] ]
	return eGW7cI6aQhr0(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬৠ"),[],[]
def HOTqs9aZBf(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩৡ"))
	items = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪৢ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	for zehVcU893FC6LEd1Aij,TWqGAlsD0bpihcwOB3FLfYKMdxgC,z9o0pbqcfi5vHlSVQZFjrD in items:
		IGEpKNCaiLMT.append(TWqGAlsD0bpihcwOB3FLfYKMdxgC+Vwgflszp4WRA93kx6hvdua21HX5cOb+z9o0pbqcfi5vHlSVQZFjrD)
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return Hlp3z0APt1GR4kMYK5xST(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭ৣ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def zwrI0NtL7BYRvV6W59sS4ofZyD(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ৤"))
	items = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡂ࠯ࡵࡦࡁࠦ৥"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	items = set(items)
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	for Wm7RJb1HIyvZsphFfEU8Yc,pPrvqm3tjuXLTgw1,lkOQsqHtJvhzZLbUdma,TWqGAlsD0bpihcwOB3FLfYKMdxgC,z9o0pbqcfi5vHlSVQZFjrD in items:
		url = JGwsL21ZRlqSrWxEmF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳ࠳ࡻࡳ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ০")+Wm7RJb1HIyvZsphFfEU8Yc+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ১")+pPrvqm3tjuXLTgw1+R3lezw8h407ZvrAFxT(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ২")+lkOQsqHtJvhzZLbUdma
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧ৩"))
		items = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৪"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij in items:
			IGEpKNCaiLMT.append(TWqGAlsD0bpihcwOB3FLfYKMdxgC+Vwgflszp4WRA93kx6hvdua21HX5cOb+z9o0pbqcfi5vHlSVQZFjrD)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if len(UTwH7zjZOrmFl)==e8XhbyuzvjYkIsJUtB5w: return ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ৫"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def AzJg5ZHj6spGtiwRDKYFcyOqEuQUv7(url):
	zehVcU893FC6LEd1Aij = NdKhAS6MXVEORLTwob92pxlZ
	if llxMLe4gobHhsj1WGvd7qmIU or OOkmZiVcfqlEurM1dHGb(u"࠭ࡋࡦࡻࡀࠫ৬") not in url:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(lrtFSogC8Nh9(u"ࠧࡶࡲࡥࡳࡲ࠴࡬ࡪࡸࡨࠫ৭"),IlL8ZnX74Yvep(u"ࠨࡷࡳࡴࡴࡳ࠮࡭࡫ࡹࡩࠬ৮"))
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.split(hCm2fnEXs6Zt(u"ࠩ࠲ࠫ৯"))
		Wm7RJb1HIyvZsphFfEU8Yc = BfjcMoqOsmdUvZVCHWIyQKi[uL69vJOU7xN0hGnZf2islDqk]
		BfjcMoqOsmdUvZVCHWIyQKi = xY4icgQUj6mPVs73CTKu(u"ࠪ࠳ࠬৰ").join(BfjcMoqOsmdUvZVCHWIyQKi[e8XhbyuzvjYkIsJUtB5w:TQNS6YMKAqnilsVObLpDRX])
		YWsjNtDXPAgCya = {JGwsL21ZRlqSrWxEmF(u"ࠫ࡮ࡪࠧৱ"):Wm7RJb1HIyvZsphFfEU8Yc,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡵࡰࠨ৲"):OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ৳"),R3lezw8h407ZvrAFxT(u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ৴"):WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ৵")}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,fOc18oTm5hsdD4pVZQj(u"ࠩࡓࡓࡘ࡚ࠧ৶"),BfjcMoqOsmdUvZVCHWIyQKi,YWsjNtDXPAgCya,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ৷"))
		if NeU6uRGpECkvMV5jf(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭৸") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()): zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[hCm2fnEXs6Zt(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ৹")]
		if not zehVcU893FC6LEd1Aij and VNc1u4edS90FK5W6bsMgQC2B.succeeded:
			LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
			zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৺"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡈࡇࡗࠫ৻"),url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧৼ"))
		if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ৽") in list(VNc1u4edS90FK5W6bsMgQC2B.headers.keys()): zehVcU893FC6LEd1Aij = VNc1u4edS90FK5W6bsMgQC2B.headers[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ৾")]
	if zehVcU893FC6LEd1Aij: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	return lrtFSogC8Nh9(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ৿"),[],[]
def xxjKtSkWMBnqDVU(url):
	headers = { hCm2fnEXs6Zt(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ਀") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨਁ"))
	items = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਂ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	if items:
		IGEpKNCaiLMT.append(QQHFtjcaR2VpnSyTIv(u"ࠨ࡯ࡳ࠸ࠬਃ"))
		UTwH7zjZOrmFl.append(items[e8XhbyuzvjYkIsJUtB5w][llxMLe4gobHhsj1WGvd7qmIU])
		IGEpKNCaiLMT.append(NeU6uRGpECkvMV5jf(u"ࠩࡰ࠷ࡺ࠾ࠧ਄"))
		UTwH7zjZOrmFl.append(items[e8XhbyuzvjYkIsJUtB5w][e8XhbyuzvjYkIsJUtB5w])
		return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
	else: return QQHFtjcaR2VpnSyTIv(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧਅ"),[],[]
def ZXBg7eKNj6UyVl(url):
	Wm7RJb1HIyvZsphFfEU8Yc = url.split(R3lezw8h407ZvrAFxT(u"ࠫ࠴࠭ਆ"))[-llxMLe4gobHhsj1WGvd7qmIU]
	Wm7RJb1HIyvZsphFfEU8Yc = Wm7RJb1HIyvZsphFfEU8Yc.split(kb2icmDGVUZfW1OFz7sv(u"ࠬࠬࠧਇ"))[e8XhbyuzvjYkIsJUtB5w]
	Wm7RJb1HIyvZsphFfEU8Yc = Wm7RJb1HIyvZsphFfEU8Yc.replace(HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨਈ"),NdKhAS6MXVEORLTwob92pxlZ)
	BfjcMoqOsmdUvZVCHWIyQKi = xKp3jkIvM09AZ4euXa87i5TVtfUD[lrtFSogC8Nh9(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨਉ")][e8XhbyuzvjYkIsJUtB5w]+V0VZk9763fusTReHFo4(u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫਊ")+Wm7RJb1HIyvZsphFfEU8Yc
	KPDs0hxnXv1TkjAeWQLR2drflU5M = lNTJCZeBicWEz0Mg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬ਋")+Wm7RJb1HIyvZsphFfEU8Yc
	k85kVbHKMXdrJOcFZ3,q5biGxDUYWKHIElhp = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NdKhAS6MXVEORLTwob92pxlZ
	Ls7aZS51eqYfI8nW3JCPvtdcDT26,wwIl14v7ZDcRiMAm = NdKhAS6MXVEORLTwob92pxlZ,{}
	BbevGuEI8g,ffiUrcjECR4yKXu = NdKhAS6MXVEORLTwob92pxlZ,{}
	headers = {JGwsL21ZRlqSrWxEmF(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ਌"):NdKhAS6MXVEORLTwob92pxlZ}
	if e8XhbyuzvjYkIsJUtB5w:
		ze8LIWQlyKpUTjoAa29mrX = pnHgvFOCBZzc08yULQJGIqw9bf(u"࠷ഃ")
		for XW2Opt4RQsVihunCylz6j in range(ze8LIWQlyKpUTjoAa29mrX):
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,fOc18oTm5hsdD4pVZQj(u"ࠫࡌࡋࡔࠨ਍"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭਎"))
			LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		KDQ9VLgNcxFOE8jt2h = YYqECUofyi7wFrW.findall(lRP6GTaZJA1Xw3egLM4(u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡖ࡬ࡢࡻࡨࡶࡗ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪਏ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		Ls7aZS51eqYfI8nW3JCPvtdcDT26 = KDQ9VLgNcxFOE8jt2h[e8XhbyuzvjYkIsJUtB5w] if KDQ9VLgNcxFOE8jt2h else LMKFcEkU1Q7R80yt4OsgvwxbfP
		wwIl14v7ZDcRiMAm = BdnA8WwtJeKUVvE(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡥ࡫ࡦࡸࠬਐ"),Ls7aZS51eqYfI8nW3JCPvtdcDT26)
	else:
		Afey3cL4ojzg = xKp3jkIvM09AZ4euXa87i5TVtfUD[eGW7cI6aQhr0(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ਑")][e8XhbyuzvjYkIsJUtB5w]+hCm2fnEXs6Zt(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡲ࡯ࡥࡾ࡫ࡲࠨ਒")
		YNJDLMW71js5kxuPdEl60qUGK = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(lNTJCZeBicWEz0Mg(u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬਓ"))
		if YNJDLMW71js5kxuPdEl60qUGK.count(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫ࠿ࡀ࠺ࠨਔ"))==lNTJCZeBicWEz0Mg(u"࠴ഄ"):
			HHhYctUFjAw04rg,key,aR4SpDYFyGOhAE,d9TXmPKf7iOx3jc4rW8QsuBIYU,JMox3q27Fi1Rd468Z = YNJDLMW71js5kxuPdEl60qUGK.split(xY4icgQUj6mPVs73CTKu(u"ࠬࡀ࠺࠻ࠩਕ"))
			headers[V0VZk9763fusTReHFo4(u"࠭ࡘ࠮ࡉࡲࡳ࡬࠳ࡖࡪࡵ࡬ࡸࡴࡸ࠭ࡊࡦࠪਖ")] = HHhYctUFjAw04rg
		headers[QQHFtjcaR2VpnSyTIv(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ਗ")] = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫਘ")
		if llxMLe4gobHhsj1WGvd7qmIU:
			kkBqpgGSQIR6PhVOjNKAfH = gniNItGL6bKwpEW(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩਙ")+Wm7RJb1HIyvZsphFfEU8Yc+xY4icgQUj6mPVs73CTKu(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠽࠮࠳࠲࠵࠸࠶࠸࠰࠲࠰࠴࠼࠳࠶࠰ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼࡙ࠣࠦ࡜ࡈࡕࡏࡏ࠹ࠧࢃࡽࡾࠩਚ")
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,R3lezw8h407ZvrAFxT(u"ࠫࡕࡕࡓࡕࠩਛ"),Afey3cL4ojzg,kkBqpgGSQIR6PhVOjNKAfH,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠵ࡲࡩ࠭ਜ"))
			KDQ9VLgNcxFOE8jt2h = VNc1u4edS90FK5W6bsMgQC2B.content
			if wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ਝ") in KDQ9VLgNcxFOE8jt2h:
				Ls7aZS51eqYfI8nW3JCPvtdcDT26 = KDQ9VLgNcxFOE8jt2h.replace(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨਞ"),PzIpQnUXxRwNCivDhdakWTE(u"ࠨࠨࠪਟ"))
				wwIl14v7ZDcRiMAm = BdnA8WwtJeKUVvE(PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡧ࡭ࡨࡺࠧਠ"),Ls7aZS51eqYfI8nW3JCPvtdcDT26)
		if llxMLe4gobHhsj1WGvd7qmIU:
			kkBqpgGSQIR6PhVOjNKAfH = R3lezw8h407ZvrAFxT(u"ࠪࡿࠧࡼࡩࡥࡧࡲࡍࡩࠨ࠺ࠡࠤࠪਡ")+Wm7RJb1HIyvZsphFfEU8Yc+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࠧ࠲ࠠࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠱࠺࠰࠷࠹࠳࠺ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡍࡔ࡙ࠢࡾࡿࢀࠫਢ")
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠬࡖࡏࡔࡖࠪਣ"),Afey3cL4ojzg,kkBqpgGSQIR6PhVOjNKAfH,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠷ࡷࡪࠧਤ"))
			KDQ9VLgNcxFOE8jt2h = VNc1u4edS90FK5W6bsMgQC2B.content
			if rNyT0edugn(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧਥ") in KDQ9VLgNcxFOE8jt2h:
				BbevGuEI8g = KDQ9VLgNcxFOE8jt2h.replace(hCm2fnEXs6Zt(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩਦ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࠩࠫਧ"))
				ffiUrcjECR4yKXu = BdnA8WwtJeKUVvE(rNyT0edugn(u"ࠪࡨ࡮ࡩࡴࠨਨ"),BbevGuEI8g)
		if llxMLe4gobHhsj1WGvd7qmIU and V0VZk9763fusTReHFo4(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ਩") not in Ls7aZS51eqYfI8nW3JCPvtdcDT26:
			Ls7aZS51eqYfI8nW3JCPvtdcDT26,wwIl14v7ZDcRiMAm,wwIl14v7ZDcRiMAm = NdKhAS6MXVEORLTwob92pxlZ,{},{}
			kkBqpgGSQIR6PhVOjNKAfH = NOrchaEV1iIZ87Uzlwgum(u"ࠬࢁࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬਪ")+Wm7RJb1HIyvZsphFfEU8Yc+QQHFtjcaR2VpnSyTIv(u"࠭ࠢ࠭ࠢࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠴࠱࠶࠵࠸࠴࠱࠹࠵࠺࠳࠶࠱࠯࠲࠳ࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠦࠢࡎ࡙ࡈࡆࠧࢃࡽࡾࠩਫ")
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡑࡑࡖࡘࠬਬ"),Afey3cL4ojzg,kkBqpgGSQIR6PhVOjNKAfH,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠺ࡴࡩࠩਭ"))
			KDQ9VLgNcxFOE8jt2h = VNc1u4edS90FK5W6bsMgQC2B.content
			if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩਮ") in KDQ9VLgNcxFOE8jt2h:
				Ls7aZS51eqYfI8nW3JCPvtdcDT26 = KDQ9VLgNcxFOE8jt2h.replace(PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫਯ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫࠫ࠭ਰ"))
				wwIl14v7ZDcRiMAm = BdnA8WwtJeKUVvE(eGW7cI6aQhr0(u"ࠬࡪࡩࡤࡶࠪ਱"),Ls7aZS51eqYfI8nW3JCPvtdcDT26)
		if llxMLe4gobHhsj1WGvd7qmIU and QQHFtjcaR2VpnSyTIv(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ਲ") not in BbevGuEI8g:
			BbevGuEI8g,ffiUrcjECR4yKXu,ffiUrcjECR4yKXu = NdKhAS6MXVEORLTwob92pxlZ,{},{}
			kkBqpgGSQIR6PhVOjNKAfH = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡼࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧਲ਼")+Wm7RJb1HIyvZsphFfEU8Yc+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࠤ࠯ࠤࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠵࠾࠴࠲࠺࠰࠶࠻ࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡃࡑࡈࡗࡕࡉࡅࠤ࠯ࠤࠧࡧ࡮ࡥࡴࡲ࡭ࡩ࡙ࡤ࡬ࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠹࠱ࠣࡿࢀࢁࠬ਴")
			headers[xY4icgQUj6mPVs73CTKu(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਵ")] = R3lezw8h407ZvrAFxT(u"ࠪࡧࡴࡳ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡢࡰࡧࡶࡴ࡯ࡤ࠯ࡻࡲࡹࡹࡻࡢࡦ࠱࠴࠽࠳࠸࠹࠯࠵࠺ࠤ࠭ࡒࡩ࡯ࡷࡻ࠿࡛ࠥ࠻ࠡࡃࡱࡨࡷࡵࡩࡥࠢ࠴࠶ࡀࠦࡇࡃࠫࠣ࡫ࡿ࡯ࡰࠨਸ਼")
			VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,NeU6uRGpECkvMV5jf(u"ࠫࡕࡕࡓࡕࠩ਷"),Afey3cL4ojzg,kkBqpgGSQIR6PhVOjNKAfH,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ਸ"))
			KDQ9VLgNcxFOE8jt2h = VNc1u4edS90FK5W6bsMgQC2B.content
			if WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ਹ") in KDQ9VLgNcxFOE8jt2h:
				BbevGuEI8g = KDQ9VLgNcxFOE8jt2h.replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ਺"),R3lezw8h407ZvrAFxT(u"ࠨࠨࠪ਻"))
				ffiUrcjECR4yKXu = BdnA8WwtJeKUVvE(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡧ࡭ࡨࡺ਼ࠧ"),BbevGuEI8g)
	AZ46x8yOEbsNlFo,wwu3Pe0vGZRDdmi1x7hKkfAQUlH,DI7A8XtwRm4Qza0oCdE,o6XClFjiWGpgwDMHbeOzYQmIcdTqyP = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,[],[]
	zqm8aOgEQ0jsW6Muw25vh,V9Z0yX8DPzOtHA5EmcLk4rRC,ncAxWHyhpRmM2bsv1E8tJ0gq,uFcwzGKeTvbOZA6g4r9REiLDo0xl = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,[],[]
	try: wwu3Pe0vGZRDdmi1x7hKkfAQUlH = wwIl14v7ZDcRiMAm[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ਽")][IlL8ZnX74Yvep(u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬਾ")]
	except: pass
	try: V9Z0yX8DPzOtHA5EmcLk4rRC = ffiUrcjECR4yKXu[kb2icmDGVUZfW1OFz7sv(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬਿ")][gniNItGL6bKwpEW(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧੀ")]
	except: pass
	try: AZ46x8yOEbsNlFo = wwIl14v7ZDcRiMAm[kb2icmDGVUZfW1OFz7sv(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧੁ")][WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪੂ")]
	except: pass
	try: zqm8aOgEQ0jsW6Muw25vh = ffiUrcjECR4yKXu[HVmIrFwau90jQsgiWzExk(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ੃")][hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ੄")]
	except: pass
	try: DI7A8XtwRm4Qza0oCdE = wwIl14v7ZDcRiMAm[eGW7cI6aQhr0(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ੅")][QQHFtjcaR2VpnSyTIv(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭੆")]
	except: pass
	try: ncAxWHyhpRmM2bsv1E8tJ0gq = ffiUrcjECR4yKXu[hCm2fnEXs6Zt(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ੇ")][YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨੈ")]
	except: pass
	try: o6XClFjiWGpgwDMHbeOzYQmIcdTqyP = wwIl14v7ZDcRiMAm[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ੉")][JGwsL21ZRlqSrWxEmF(u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫ੊")]
	except: pass
	try: uFcwzGKeTvbOZA6g4r9REiLDo0xl = ffiUrcjECR4yKXu[JGwsL21ZRlqSrWxEmF(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪੋ")][IlL8ZnX74Yvep(u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭ੌ")]
	except: pass
	if not LMKFcEkU1Q7R80yt4OsgvwxbfP:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,kb2icmDGVUZfW1OFz7sv(u"ࠬࡍࡅࡕ੍ࠩ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠺ࡹ࡮ࠧ੎"))
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if not any([wwu3Pe0vGZRDdmi1x7hKkfAQUlH,V9Z0yX8DPzOtHA5EmcLk4rRC,AZ46x8yOEbsNlFo,zqm8aOgEQ0jsW6Muw25vh,DI7A8XtwRm4Qza0oCdE,ncAxWHyhpRmM2bsv1E8tJ0gq,o6XClFjiWGpgwDMHbeOzYQmIcdTqyP,uFcwzGKeTvbOZA6g4r9REiLDo0xl]):
		ZLI75sAmWojzUYJtluw8h6H4reCf = YYqECUofyi7wFrW.findall(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ੏"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		XXnFpTZ9ksicAKzg1lMCP5Dtq = YYqECUofyi7wFrW.findall(OOkmZiVcfqlEurM1dHGb(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ੐"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		mbzrpYR0ZBMvjxJ2eDS = YYqECUofyi7wFrW.findall(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨੑ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		MWX39d1VjgqPaftLAwUD8orJc = YYqECUofyi7wFrW.findall(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ੒"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		ZyfMTYE9AsubJH6,ANhUYlnKId3ZoFEie1cqOBprVRJS,DzSbi6ACstnuGaZ = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		try: ZyfMTYE9AsubJH6 = wwIl14v7ZDcRiMAm[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ੓")][gniNItGL6bKwpEW(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ੔")][QQHFtjcaR2VpnSyTIv(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ੕")][kb2icmDGVUZfW1OFz7sv(u"ࠧࡵ࡫ࡷࡰࡪ࠭੖")][OOkmZiVcfqlEurM1dHGb(u"ࠨࡴࡸࡲࡸ࠭੗")][e8XhbyuzvjYkIsJUtB5w][vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡷࡩࡽࡺࠧ੘")]
		except:
			try: ZyfMTYE9AsubJH6 = ffiUrcjECR4yKXu[Hlp3z0APt1GR4kMYK5xST(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧਖ਼")][LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩਗ਼")][rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ਜ਼")][HVmIrFwau90jQsgiWzExk(u"࠭ࡴࡪࡶ࡯ࡩࠬੜ")][ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡳࡷࡱࡷࠬ੝")][e8XhbyuzvjYkIsJUtB5w][vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")]
			except: pass
		try: ANhUYlnKId3ZoFEie1cqOBprVRJS = wwIl14v7ZDcRiMAm[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭੟")][HVmIrFwau90jQsgiWzExk(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ੠")][lRP6GTaZJA1Xw3egLM4(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ੡")][rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭੢")][e8XhbyuzvjYkIsJUtB5w][ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡲࡶࡰࡶࠫ੣")][e8XhbyuzvjYkIsJUtB5w][wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡵࡧࡻࡸࠬ੤")]
		except:
			try: ANhUYlnKId3ZoFEie1cqOBprVRJS = ffiUrcjECR4yKXu[lrtFSogC8Nh9(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ੥")][LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ੦")][wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ੧")][NOrchaEV1iIZ87Uzlwgum(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬ੨")][e8XhbyuzvjYkIsJUtB5w][V0VZk9763fusTReHFo4(u"ࠬࡸࡵ࡯ࡵࠪ੩")][e8XhbyuzvjYkIsJUtB5w][gniNItGL6bKwpEW(u"࠭ࡴࡦࡺࡷࠫ੪")]
			except: pass
		try: DzSbi6ACstnuGaZ = wwIl14v7ZDcRiMAm[Tzx81Wb0RZC4ID5AyiU2(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ੫")][gniNItGL6bKwpEW(u"ࠨࡴࡨࡥࡸࡵ࡮ࠨ੬")]
		except:
			try: DzSbi6ACstnuGaZ = ffiUrcjECR4yKXu[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭੭")][Hlp3z0APt1GR4kMYK5xST(u"ࠪࡶࡪࡧࡳࡰࡰࠪ੮")]
			except: pass
		LM7HVTRv1FSqcAlKx0NzBsyi2 = lrtFSogC8Nh9(u"ࠫࠬ੯")
		HqulIpFziP1YVeOtmQTSf = Whef0cxB2iR93SC5IwUtk+Tzx81Wb0RZC4ID5AyiU2(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮࠦ࠮࠯ࠢฦ์ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣ࠲࠳ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢํัฯอฬࠡึํล๋ࠥอะัࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢ฽๎ึࠦโศัิࠤศ์๋ࠠึ฽่ࠥอไโ์า๎ํࠦวๅฤ้ࠫੰ")+kjd9LyNqQHMUevZiRI7OlBGF1h
		if ZLI75sAmWojzUYJtluw8h6H4reCf or XXnFpTZ9ksicAKzg1lMCP5Dtq or mbzrpYR0ZBMvjxJ2eDS or MWX39d1VjgqPaftLAwUD8orJc or ZyfMTYE9AsubJH6 or ANhUYlnKId3ZoFEie1cqOBprVRJS or DzSbi6ACstnuGaZ:
			if   ZLI75sAmWojzUYJtluw8h6H4reCf: JzNoqV8ClRD6O = ZLI75sAmWojzUYJtluw8h6H4reCf[e8XhbyuzvjYkIsJUtB5w]
			elif XXnFpTZ9ksicAKzg1lMCP5Dtq: JzNoqV8ClRD6O = XXnFpTZ9ksicAKzg1lMCP5Dtq[e8XhbyuzvjYkIsJUtB5w]
			elif mbzrpYR0ZBMvjxJ2eDS: JzNoqV8ClRD6O = mbzrpYR0ZBMvjxJ2eDS[e8XhbyuzvjYkIsJUtB5w]
			elif MWX39d1VjgqPaftLAwUD8orJc: JzNoqV8ClRD6O = MWX39d1VjgqPaftLAwUD8orJc[e8XhbyuzvjYkIsJUtB5w]
			elif ZyfMTYE9AsubJH6: JzNoqV8ClRD6O = ZyfMTYE9AsubJH6
			elif ANhUYlnKId3ZoFEie1cqOBprVRJS: JzNoqV8ClRD6O = ANhUYlnKId3ZoFEie1cqOBprVRJS
			elif DzSbi6ACstnuGaZ: JzNoqV8ClRD6O = DzSbi6ACstnuGaZ
			LM7HVTRv1FSqcAlKx0NzBsyi2 = JzNoqV8ClRD6O.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			HqulIpFziP1YVeOtmQTSf += ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭࡜࡯࡞ࡱࠫੱ")+D7INg5kyRjwf4ZtoePVUrb1h2SJ+IlL8ZnX74Yvep(u"ࠧาีส่ฮࠦๅ็ࠢํ์ฯ๐่ษࠩੲ")+kjd9LyNqQHMUevZiRI7OlBGF1h+B6IrC7zEHlw1oaeWf+LM7HVTRv1FSqcAlKx0NzBsyi2
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬੳ"),HqulIpFziP1YVeOtmQTSf)
		if LM7HVTRv1FSqcAlKx0NzBsyi2: LM7HVTRv1FSqcAlKx0NzBsyi2 = JGwsL21ZRlqSrWxEmF(u"ࠩ࠽ࠤࠬੴ")+LM7HVTRv1FSqcAlKx0NzBsyi2
		return OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪੵ")+LM7HVTRv1FSqcAlKx0NzBsyi2,[],[]
	DVZR04pBEdyhNo7FHMtPSw2,kUzBdg1XrD0h4cjYVTb,JPw7OlgYLWb02KRyrQ1hmtDZ = [],[],[]
	eYESac2L4fQ = [wwu3Pe0vGZRDdmi1x7hKkfAQUlH,V9Z0yX8DPzOtHA5EmcLk4rRC]
	tMwgfqohvYCWZOa = [AZ46x8yOEbsNlFo,zqm8aOgEQ0jsW6Muw25vh]
	ttFMHI9QPiN,f7REmdi4Gcl0QM9JWVw1qhsxSaKy = [],[]
	for GzemS02YIZMnwNxAoC in DI7A8XtwRm4Qza0oCdE+ncAxWHyhpRmM2bsv1E8tJ0gq:
		if GzemS02YIZMnwNxAoC[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡮ࡺࡡࡨࠩ੶")] not in ttFMHI9QPiN:
			ttFMHI9QPiN.append(GzemS02YIZMnwNxAoC[NOrchaEV1iIZ87Uzlwgum(u"ࠬ࡯ࡴࡢࡩࠪ੷")])
			f7REmdi4Gcl0QM9JWVw1qhsxSaKy.append(GzemS02YIZMnwNxAoC)
	ttFMHI9QPiN,BhKHdsaYynC3fVD4X = [],[]
	for GzemS02YIZMnwNxAoC in o6XClFjiWGpgwDMHbeOzYQmIcdTqyP+uFcwzGKeTvbOZA6g4r9REiLDo0xl:
		if GzemS02YIZMnwNxAoC[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡩࡵࡣࡪࠫ੸")] not in ttFMHI9QPiN:
			ttFMHI9QPiN.append(GzemS02YIZMnwNxAoC[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡪࡶࡤ࡫ࠬ੹")])
			BhKHdsaYynC3fVD4X.append(GzemS02YIZMnwNxAoC)
	for dict in f7REmdi4Gcl0QM9JWVw1qhsxSaKy+BhKHdsaYynC3fVD4X:
		if PzIpQnUXxRwNCivDhdakWTE(u"ࠨ࡫ࡷࡥ࡬࠭੺") in list(dict.keys()): dict[lRP6GTaZJA1Xw3egLM4(u"ࠩ࡬ࡸࡦ࡭ࠧ੻")] = str(dict[IlL8ZnX74Yvep(u"ࠪ࡭ࡹࡧࡧࠨ੼")])
		if fOc18oTm5hsdD4pVZQj(u"ࠫ࡫ࡶࡳࠨ੽") in list(dict.keys()): dict[IlL8ZnX74Yvep(u"ࠬ࡬ࡰࡴࠩ੾")] = str(dict[IlL8ZnX74Yvep(u"࠭ࡦࡱࡵࠪ੿")])
		if JGwsL21ZRlqSrWxEmF(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ઀") in list(dict.keys()): dict[PzIpQnUXxRwNCivDhdakWTE(u"ࠨࡶࡼࡴࡪ࠭ઁ")] = dict[IlL8ZnX74Yvep(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫં")]
		if hCm2fnEXs6Zt(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬઃ") in list(dict.keys()): dict[hCm2fnEXs6Zt(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ઄")] = str(dict[lRP6GTaZJA1Xw3egLM4(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧઅ")])
		if lNTJCZeBicWEz0Mg(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭આ") in list(dict.keys()): dict[QQHFtjcaR2VpnSyTIv(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨઇ")] = str(dict[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨઈ")])
		if NeU6uRGpECkvMV5jf(u"ࠩࡺ࡭ࡩࡺࡨࠨઉ") in list(dict.keys()): dict[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡷ࡮ࢀࡥࠨઊ")] = str(dict[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡼ࡯ࡤࡵࡪࠪઋ")])+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬࡾࠧઌ")+str(dict[pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ઍ")])
		if vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ઎") in list(dict.keys()): dict[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ࡫ࡱ࡭ࡹ࠭એ")] = dict[NOrchaEV1iIZ87Uzlwgum(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬઐ")][pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡷࡹࡧࡲࡵࠩઑ")]+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫ࠲࠭઒")+dict[hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨઓ")][hCm2fnEXs6Zt(u"࠭ࡥ࡯ࡦࠪઔ")]
		if rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫક") in list(dict.keys()): dict[lNTJCZeBicWEz0Mg(u"ࠨ࡫ࡱࡨࡪࡾࠧખ")] = dict[xY4icgQUj6mPVs73CTKu(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭ગ")][kb2icmDGVUZfW1OFz7sv(u"ࠪࡷࡹࡧࡲࡵࠩઘ")]+Hlp3z0APt1GR4kMYK5xST(u"ࠫ࠲࠭ઙ")+dict[JGwsL21ZRlqSrWxEmF(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩચ")][Hlp3z0APt1GR4kMYK5xST(u"࠭ࡥ࡯ࡦࠪછ")]
		if WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨજ") in list(dict.keys()): dict[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩઝ")] = dict[IlL8ZnX74Yvep(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪઞ")]
		if OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫટ") in list(dict.keys()) and int(dict[R3lezw8h407ZvrAFxT(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬઠ")])>kb2icmDGVUZfW1OFz7sv(u"࠲࠳࠴࠶࠷࠸࠳࠴࠵അ"): del dict[QQHFtjcaR2VpnSyTIv(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ડ")]
		if YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨઢ") in list(dict.keys()):
			FUvml2uyThtb1 = dict[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩણ")].split(lRP6GTaZJA1Xw3egLM4(u"ࠨࠨࠪત"))
			for rMOG2USkPesYZD9KNAVqpc in FUvml2uyThtb1:
				key,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split(kb2icmDGVUZfW1OFz7sv(u"ࠩࡀࠫથ"),NOrchaEV1iIZ87Uzlwgum(u"࠳ആ"))
				dict[key] = OOFEmwq2GkTz93WXy1Nj(K6KbZDHncNizQgl1fr59XV0)
		if rNyT0edugn(u"ࠪࡹࡷࡲࠧદ") in list(dict.keys()): dict[PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡺࡸ࡬ࠨધ")] = OOFEmwq2GkTz93WXy1Nj(dict[IlL8ZnX74Yvep(u"ࠬࡻࡲ࡭ࠩન")])
		DVZR04pBEdyhNo7FHMtPSw2.append(dict)
	WEumF9K86qaGVXDfU7P = NdKhAS6MXVEORLTwob92pxlZ
	ZdRnjPKuphCyO7Ubc2AezVtkHSWDr = YYqECUofyi7wFrW.findall(rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨ઩"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if ZdRnjPKuphCyO7Ubc2AezVtkHSWDr:
		ZdRnjPKuphCyO7Ubc2AezVtkHSWDr = xKp3jkIvM09AZ4euXa87i5TVtfUD[HVmIrFwau90jQsgiWzExk(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨપ")][e8XhbyuzvjYkIsJUtB5w]+ZdRnjPKuphCyO7Ubc2AezVtkHSWDr[e8XhbyuzvjYkIsJUtB5w]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,OOkmZiVcfqlEurM1dHGb(u"ࠨࡉࡈࡘࠬફ"),ZdRnjPKuphCyO7Ubc2AezVtkHSWDr,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠸ࡵࡪࠪબ"))
		WEumF9K86qaGVXDfU7P = VNc1u4edS90FK5W6bsMgQC2B.content
	if WEumF9K86qaGVXDfU7P:
		if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠪࡷࡵࡃࡳࡪࡩࠪભ") in Ls7aZS51eqYfI8nW3JCPvtdcDT26+BbevGuEI8g:
			import youtube_signature.cipher as EhQIixOf4B6PZYepaVRGzs1rng2,youtube_signature.json_script_engine as ephWLm7RfSMiqs62Inr9JOo4Uj5
			FUvml2uyThtb1 = ux5Ifn0WcH42.FUvml2uyThtb1.Cipher()
			FUvml2uyThtb1._object_cache = {}
			dUbl0EBftphH7Aeyo = FUvml2uyThtb1._load_javascript(WEumF9K86qaGVXDfU7P)
			B5UQ6dT7bShRMDsz8u = BdnA8WwtJeKUVvE(rNyT0edugn(u"ࠫࡸࡺࡲࠨમ"),str(dUbl0EBftphH7Aeyo))
			r1tzY7D0GkLH3 = ux5Ifn0WcH42.V0X3ho798iSxa6YrscOAjw4mez5LFW.JsonScriptEngine(B5UQ6dT7bShRMDsz8u)
		BBdjO29EWZ6CKR4ak7NnFgMcV = YYqECUofyi7wFrW.findall(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࡠ࠳࡭ࡥࡵ࡞ࠫࠦࡳࠨ࡜ࠪ࡞ࠬࠪࠫࡢࠨࡣ࠿ࡿࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࡦࡂ࡙ࡴࡳ࡫ࡱ࡫ࡡ࠴ࡦࡳࡱࡰࡇ࡭ࡧࡲࡄࡱࡧࡩࡡ࠮࠱࠲࠲࡟࠭ࢁࠐࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡵࡷࡶࡤ࡯ࡤࡹࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࠯࡟࠮࠭ࠫࠬ࡜ࠩࡤࡀࠦࡳࡴࠢ࡝࡝࡟࠯࠭ࡅࡐ࠾ࡵࡷࡶࡤ࡯ࡤࡹࠫ࡟ࡡࠏࠏࠉࠊࠋࠬࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌ࠰ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠮ࡡ࡝ࠫࠬࡃ࠱ࡩ࠽ࡢ࡞࠱ࠎࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎ࡭ࡥࡵ࡞ࠫࡦࡡ࠯ࡼࠋࠋࠌࠍࠎࠏࠉ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࡝ࡥࡠࡢࡢࡼ࡝ࡾࡱࡹࡱࡲࠊࠊࠋࠌࠍࠎ࠯࡜ࠪࠨࠩࡠ࠭ࡩ࠽ࡽࠌࠌࠍࠎࠏ࡜ࡣࠪࡂࡔࡁࡼࡡࡳࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࡁࠏࠏࠉࠊࠫࠫࡃࡕࡂ࡮ࡧࡷࡱࡧࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯ࠨࡀ࠼࡟࡟࠭ࡅࡐ࠽࡫ࡧࡼࡃࡢࡤࠬࠫ࡟ࡡ࠮ࡅ࡜ࠩ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࡟࠭ࠏࠏࠉࠊࠪࡂࠬࡻࡧࡲࠪ࠮࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠲ࡸ࡫ࡴ࡝ࠪࠫࡃ࠿ࠨ࡮ࠬࠤࡿ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡ࠲ࠨࡀࡒࡀࡺࡦࡸࠩ࡝ࠫࠬࠫࠬ࠭ય"),WEumF9K86qaGVXDfU7P)
		if BBdjO29EWZ6CKR4ak7NnFgMcV:
			BBdjO29EWZ6CKR4ak7NnFgMcV = YYqECUofyi7wFrW.findall(BBdjO29EWZ6CKR4ak7NnFgMcV[lNTJCZeBicWEz0Mg(u"࠳ഇ")][NeU6uRGpECkvMV5jf(u"࠶ഈ")]+Hlp3z0APt1GR4kMYK5xST(u"࠭࠽࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪર"),WEumF9K86qaGVXDfU7P,YYqECUofyi7wFrW.DOTALL)[lNTJCZeBicWEz0Mg(u"࠳ഇ")]
			ky8nGY0N6sDuI1CSqPHtaVliQmT34e = WEumF9K86qaGVXDfU7P.find(BBdjO29EWZ6CKR4ak7NnFgMcV+R3lezw8h407ZvrAFxT(u"ࠧ࠾ࡨࡸࡲࡨࡺࡩࡰࡰࠫࠫ઱"))
			CVNlW52uFv7YEQ69SGILy = WEumF9K86qaGVXDfU7P.find(rNyT0edugn(u"ࠨࡿ࠾ࠫલ"), ky8nGY0N6sDuI1CSqPHtaVliQmT34e)
			uMcN6DL8anf = WEumF9K86qaGVXDfU7P[ky8nGY0N6sDuI1CSqPHtaVliQmT34e:CVNlW52uFv7YEQ69SGILy]+fOc18oTm5hsdD4pVZQj(u"ࠩࢀࠫળ")
			TJuYivhol1PQB = YYqECUofyi7wFrW.findall(Hlp3z0APt1GR4kMYK5xST(u"ࠪࡺࡦࡸࠠ࠯ࠬࡂࡁ࠭࠴ࠪࡀࠫ࡟࠲ࠬ઴"),uMcN6DL8anf,YYqECUofyi7wFrW.DOTALL)[lNTJCZeBicWEz0Mg(u"࠵ഉ")]
			cjB5dslaMPWJ0VFykAxILTK1Do = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࡮࡬࡜ࠩࡶࡼࡴࡪࡵࡦࠡ࠰࠭ࡃࡂࡃ࠽ࠣࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠦࡡ࠯ࡲࡦࡶࡸࡶࡳࠦࠧવ")+TJuYivhol1PQB+kb2icmDGVUZfW1OFz7sv(u"ࠬࡁࠧશ"),uMcN6DL8anf,YYqECUofyi7wFrW.DOTALL)
			if cjB5dslaMPWJ0VFykAxILTK1Do: uMcN6DL8anf = uMcN6DL8anf.replace(cjB5dslaMPWJ0VFykAxILTK1Do[LtGoXlQ2IYxqTJRySE6udfW98(u"࠶ഊ")],OOkmZiVcfqlEurM1dHGb(u"࠭ࠧષ"))
			uXFYhAenVBC9THdfL13Zx = {}
			for dict in DVZR04pBEdyhNo7FHMtPSw2:
				url = dict[JGwsL21ZRlqSrWxEmF(u"ࠧࡶࡴ࡯ࠫસ")]
				if lNTJCZeBicWEz0Mg(u"ࠨࠨࡱࡁࠬહ") in url:
					MLpSsqvhciZrWFO5Rbm = url.split(Hlp3z0APt1GR4kMYK5xST(u"ࠩࠩࡲࡂ࠭઺"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU].split(xY4icgQUj6mPVs73CTKu(u"ࠪࠪࠬ઻"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]
					if MLpSsqvhciZrWFO5Rbm not in list(uXFYhAenVBC9THdfL13Zx.keys()): uXFYhAenVBC9THdfL13Zx[MLpSsqvhciZrWFO5Rbm] = sPtRDbJGVcMg3hIznEr7yOvYH4l(uMcN6DL8anf,[BBdjO29EWZ6CKR4ak7NnFgMcV,MLpSsqvhciZrWFO5Rbm])
					dict[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡺࡸ࡬ࠨ઼")] = url.replace(rNyT0edugn(u"ࠬࠬ࡮࠾ࠩઽ")+MLpSsqvhciZrWFO5Rbm+lNTJCZeBicWEz0Mg(u"࠭ࠦࠨા"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࠧࡰࡀࠫિ")+uXFYhAenVBC9THdfL13Zx[MLpSsqvhciZrWFO5Rbm]+HHvYL68lbJVZWM7tQEzSex3(u"ࠨࠨࠪી"))
	for dict in DVZR04pBEdyhNo7FHMtPSw2:
		url = dict[QQHFtjcaR2VpnSyTIv(u"ࠩࡸࡶࡱ࠭ુ")]
		if IlL8ZnX74Yvep(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧૂ") in url or url.count(JGwsL21ZRlqSrWxEmF(u"ࠫࡸ࡯ࡧ࠾ࠩૃ"))>llxMLe4gobHhsj1WGvd7qmIU:
			kUzBdg1XrD0h4cjYVTb.append(dict)
		elif WEumF9K86qaGVXDfU7P and PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡹࠧૄ") in list(dict.keys()) and hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡳࡱࠩૅ") in list(dict.keys()):
			io9TO0F4JIfrwCzZksthXq = r1tzY7D0GkLH3.execute(dict[IlL8ZnX74Yvep(u"ࠧࡴࠩ૆")])
			if io9TO0F4JIfrwCzZksthXq!=dict[xY4icgQUj6mPVs73CTKu(u"ࠨࡵࠪે")]:
				dict[ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡸࡶࡱ࠭ૈ")] = url+PzIpQnUXxRwNCivDhdakWTE(u"ࠪࠪࠬૉ")+dict[R3lezw8h407ZvrAFxT(u"ࠫࡸࡶࠧ૊")]+Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡃࠧો")+io9TO0F4JIfrwCzZksthXq
				kUzBdg1XrD0h4cjYVTb.append(dict)
	for dict in kUzBdg1XrD0h4cjYVTb:
		uJqZbeXK04CRjoQ,fadJCTP6bKmXNugL08yhoBz3E,izmvOBEAoNuQ3Sf,iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z,Yib7SkGJaT,rFSUYwTohtsByX4HJ0qElMD8nuk = vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧૌ"),fOc18oTm5hsdD4pVZQj(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ્"),NeU6uRGpECkvMV5jf(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ૎"),Hlp3z0APt1GR4kMYK5xST(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ૏"),NdKhAS6MXVEORLTwob92pxlZ,lrtFSogC8Nh9(u"ࠪ࠴ࠬૐ")
		try:
			rCkRQ6XZSvij8z = dict[hCm2fnEXs6Zt(u"ࠫࡹࡿࡰࡦࠩ૑")]
			rCkRQ6XZSvij8z = rCkRQ6XZSvij8z.replace(lRP6GTaZJA1Xw3egLM4(u"ࠬ࠱ࠧ૒"),NdKhAS6MXVEORLTwob92pxlZ)
			items = YYqECUofyi7wFrW.findall(NOrchaEV1iIZ87Uzlwgum(u"࠭ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૓"),rCkRQ6XZSvij8z,YYqECUofyi7wFrW.DOTALL)
			iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z,uJqZbeXK04CRjoQ,Yib7SkGJaT = items[e8XhbyuzvjYkIsJUtB5w]
			GNBgSf2789cXrn4Mt = Yib7SkGJaT.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠭ࠩ૔"))
			fadJCTP6bKmXNugL08yhoBz3E = NdKhAS6MXVEORLTwob92pxlZ
			for rMOG2USkPesYZD9KNAVqpc in GNBgSf2789cXrn4Mt: fadJCTP6bKmXNugL08yhoBz3E += rMOG2USkPesYZD9KNAVqpc.split(Tzx81Wb0RZC4ID5AyiU2(u"ࠨ࠰ࠪ૕"))[e8XhbyuzvjYkIsJUtB5w]+fOc18oTm5hsdD4pVZQj(u"ࠩ࠯ࠫ૖")
			fadJCTP6bKmXNugL08yhoBz3E = fadJCTP6bKmXNugL08yhoBz3E.strip(R3lezw8h407ZvrAFxT(u"ࠪ࠰ࠬ૗"))
			if HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ૘") in list(dict.keys()): rFSUYwTohtsByX4HJ0qElMD8nuk = str(int(dict[V0VZk9763fusTReHFo4(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭૙")])//LtGoXlQ2IYxqTJRySE6udfW98(u"࠱࠱࠴࠷ഋ"))+Tzx81Wb0RZC4ID5AyiU2(u"࠭࡫ࡣࡲࡶࠤࠥ࠭૚")
			else: rFSUYwTohtsByX4HJ0qElMD8nuk = NdKhAS6MXVEORLTwob92pxlZ
			if iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z==IlL8ZnX74Yvep(u"ࠧࡵࡧࡻࡸࠬ૛"): continue
			elif IlL8ZnX74Yvep(u"ࠨ࠮ࠪ૜") in rCkRQ6XZSvij8z:
				iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡄ࠯࡛࠭૝")
				izmvOBEAoNuQ3Sf = uJqZbeXK04CRjoQ+Uv7MkgVGyEbAlfFP0S8Zjqp2J+rFSUYwTohtsByX4HJ0qElMD8nuk+dict[NOrchaEV1iIZ87Uzlwgum(u"ࠪࡷ࡮ࢀࡥࠨ૞")].split(lrtFSogC8Nh9(u"ࠫࡽ࠭૟"))[llxMLe4gobHhsj1WGvd7qmIU]
			elif iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡼࡩࡥࡧࡲࠫૠ"):
				iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = vju3SZDWL4ENYelmBOzUqrogp2(u"࠭ࡖࡪࡦࡨࡳࠬૡ")
				izmvOBEAoNuQ3Sf = rFSUYwTohtsByX4HJ0qElMD8nuk+dict[eGW7cI6aQhr0(u"ࠧࡴ࡫ࡽࡩࠬૢ")].split(gniNItGL6bKwpEW(u"ࠨࡺࠪૣ"))[llxMLe4gobHhsj1WGvd7qmIU]+Uv7MkgVGyEbAlfFP0S8Zjqp2J+dict[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡩࡴࡸ࠭૤")]+gniNItGL6bKwpEW(u"ࠪࡪࡵࡹࠧ૥")+Uv7MkgVGyEbAlfFP0S8Zjqp2J+uJqZbeXK04CRjoQ
			elif iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠫࡦࡻࡤࡪࡱࠪ૦"):
				iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z = NOrchaEV1iIZ87Uzlwgum(u"ࠬࡇࡵࡥ࡫ࡲࠫ૧")
				izmvOBEAoNuQ3Sf = rFSUYwTohtsByX4HJ0qElMD8nuk+str(int(dict[QQHFtjcaR2VpnSyTIv(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ૨")])/wP4kpvXoDHq3hs7TFLyr2COn8(u"࠲࠲࠳࠴ഌ"))+Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࡬ࡪࡽࠤࠥ࠭૩")+dict[lrtFSogC8Nh9(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ૪")]+QQHFtjcaR2VpnSyTIv(u"ࠩࡦ࡬ࠬ૫")+Uv7MkgVGyEbAlfFP0S8Zjqp2J+uJqZbeXK04CRjoQ
		except:
			ihuUeAVfaSbXMNn = gg5FIJdLzZY4MCfxiTAswNp.format_exc()
			if ihuUeAVfaSbXMNn!=Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭૬"): hnu0oKAvsG4PaX6yxiTj2eftY.stderr.write(ihuUeAVfaSbXMNn)
		if hCm2fnEXs6Zt(u"ࠫࡩࡻࡲ࠾ࠩ૭") in dict[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡻࡲ࡭ࠩ૮")]: TLrSzM98nc2H3VODdyhpQI = round(lRP6GTaZJA1Xw3egLM4(u"࠳࠲࠺എ")+float(dict[QQHFtjcaR2VpnSyTIv(u"࠭ࡵࡳ࡮ࠪ૯")].split(lNTJCZeBicWEz0Mg(u"ࠧࡥࡷࡵࡁࠬ૰"),NOrchaEV1iIZ87Uzlwgum(u"࠳഍"))[llxMLe4gobHhsj1WGvd7qmIU].split(hCm2fnEXs6Zt(u"ࠨࠨࠪ૱"),llxMLe4gobHhsj1WGvd7qmIU)[e8XhbyuzvjYkIsJUtB5w]))
		elif vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ૲") in list(dict.keys()): TLrSzM98nc2H3VODdyhpQI = round(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠴࠳࠻ഏ")+float(dict[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭૳")])/QQHFtjcaR2VpnSyTIv(u"࠶࠶࠰࠱ഐ"))
		else: TLrSzM98nc2H3VODdyhpQI = PzIpQnUXxRwNCivDhdakWTE(u"ࠫ࠵࠭૴")
		if vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭૵") not in list(dict.keys()): rFSUYwTohtsByX4HJ0qElMD8nuk = dict[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡳࡪࡼࡨࠫ૶")].split(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡹࠩ૷"))[llxMLe4gobHhsj1WGvd7qmIU]
		else: rFSUYwTohtsByX4HJ0qElMD8nuk = str(int(dict[gniNItGL6bKwpEW(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ૸")])//JGwsL21ZRlqSrWxEmF(u"࠷࠰࠳࠶഑"))
		if lrtFSogC8Nh9(u"ࠩ࡬ࡲ࡮ࡺࠧૹ") not in list(dict.keys()): dict[OOkmZiVcfqlEurM1dHGb(u"ࠪ࡭ࡳ࡯ࡴࠨૺ")] = Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࠵࠳࠰ࠨૻ")
		dict[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡺࡩࡵ࡮ࡨࠫૼ")] = iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z+xY4icgQUj6mPVs73CTKu(u"࠭࠺ࠡࠢࠪ૽")+izmvOBEAoNuQ3Sf+fOc18oTm5hsdD4pVZQj(u"ࠧࠡࠢࠫࠫ૾")+fadJCTP6bKmXNugL08yhoBz3E+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨ࠮ࠪ૿")+dict[Tzx81Wb0RZC4ID5AyiU2(u"ࠩ࡬ࡸࡦ࡭ࠧ଀")]+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪ࠭ࠬଁ")
		dict[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬଂ")] = izmvOBEAoNuQ3Sf.split(Uv7MkgVGyEbAlfFP0S8Zjqp2J)[e8XhbyuzvjYkIsJUtB5w].split(lrtFSogC8Nh9(u"ࠬࡱࡢࡱࡵࠪଃ"))[e8XhbyuzvjYkIsJUtB5w]
		dict[PzIpQnUXxRwNCivDhdakWTE(u"࠭ࡴࡺࡲࡨ࠶ࠬ଄")] = iLvYjAn5h3PbcfHxCrwoDQE1gNuG9z
		dict[hCm2fnEXs6Zt(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩଅ")] = uJqZbeXK04CRjoQ
		dict[HVmIrFwau90jQsgiWzExk(u"ࠨࡥࡲࡨࡪࡩࡳࠨଆ")] = Yib7SkGJaT
		dict[Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫଇ")] = TLrSzM98nc2H3VODdyhpQI
		dict[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫଈ")] = rFSUYwTohtsByX4HJ0qElMD8nuk
		JPw7OlgYLWb02KRyrQ1hmtDZ.append(dict)
	vORKrZwSCud,HVpIGgmrcK,jg3nCaphckXFvi0VsbQL5uH,y5O3U0lJPGYj2TVfFtq1,G9b2QjDgCzaBpHJ5 = [],[],[],[],[]
	U7a2bws6yCoKcuBYQHjeizqLM,HBn4qjQDdyAbK5J,cc7InUBbAY,f6mYOyLsa10UK8wZbChW,EELJTab0FSmQ92MDpUCu3okd5A = [],[],[],[],[]
	for etIolqazKYCO9kXviH08FcE2y1WJfU in tMwgfqohvYCWZOa:
		if not etIolqazKYCO9kXviH08FcE2y1WJfU: continue
		dict = {}
		dict[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡹࡿࡰࡦ࠴ࠪଉ")] = HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡇࠫࡗࠩଊ")
		dict[hCm2fnEXs6Zt(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨଋ")] = HHvYL68lbJVZWM7tQEzSex3(u"ࠧ࡮ࡲࡧࠫଌ")
		dict[IlL8ZnX74Yvep(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ଍")] = dict[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡷࡽࡵ࡫࠲ࠨ଎")]+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪ࠾ࠥࠦࠧଏ")+dict[gniNItGL6bKwpEW(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ଐ")]+Uv7MkgVGyEbAlfFP0S8Zjqp2J+fOc18oTm5hsdD4pVZQj(u"ࠬา่ะหࠣิ่๐ษࠨ଑")
		dict[NeU6uRGpECkvMV5jf(u"࠭ࡵࡳ࡮ࠪ଒")] = etIolqazKYCO9kXviH08FcE2y1WJfU
		dict[lrtFSogC8Nh9(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨଓ")] = lrtFSogC8Nh9(u"ࠨ࠲ࠪଔ")
		dict[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪକ")] = HVmIrFwau90jQsgiWzExk(u"ࠪ࠵࠶࠷࠲࠳࠴࠶࠷࠸࠭ଖ")
		JPw7OlgYLWb02KRyrQ1hmtDZ.append(dict)
	for l96AgWvzdmonsGf4 in eYESac2L4fQ:
		if not l96AgWvzdmonsGf4: continue
		QQgG862yiLenuYHlBO,nnsGZ4jriVKNmpvAhFS70D1TCYtl = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,l96AgWvzdmonsGf4)
		s8B7U1MtKhZLoO = list(zip(QQgG862yiLenuYHlBO,nnsGZ4jriVKNmpvAhFS70D1TCYtl))
		for title,zehVcU893FC6LEd1Aij in s8B7U1MtKhZLoO:
			dict = {}
			dict[HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡹࡿࡰࡦ࠴ࠪଗ")] = xY4icgQUj6mPVs73CTKu(u"ࠬࡇࠫࡗࠩଘ")
			dict[R3lezw8h407ZvrAFxT(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨଙ")] = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧ࡮࠵ࡸ࠼ࠬଚ")
			dict[lRP6GTaZJA1Xw3egLM4(u"ࠨࡷࡵࡰࠬଛ")] = zehVcU893FC6LEd1Aij
			if JGwsL21ZRlqSrWxEmF(u"ࠩ࡮ࡦࡵࡹࠧଜ") in title: dict[gniNItGL6bKwpEW(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫଝ")] = title.split(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡰࡨࡰࡴࠩଞ"))[e8XhbyuzvjYkIsJUtB5w].rsplit(Uv7MkgVGyEbAlfFP0S8Zjqp2J)[-llxMLe4gobHhsj1WGvd7qmIU]
			else: dict[NOrchaEV1iIZ87Uzlwgum(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ଟ")] = eGW7cI6aQhr0(u"࠭࠱࠱ࠩଠ")
			if title.count(Uv7MkgVGyEbAlfFP0S8Zjqp2J)>llxMLe4gobHhsj1WGvd7qmIU:
				a0ao2jdlt4r9nhHwpvSgOVGA = title.rsplit(Uv7MkgVGyEbAlfFP0S8Zjqp2J)[-uL69vJOU7xN0hGnZf2islDqk]
				if a0ao2jdlt4r9nhHwpvSgOVGA.isdigit(): dict[eGW7cI6aQhr0(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨଡ")] = a0ao2jdlt4r9nhHwpvSgOVGA
				else: dict[HVmIrFwau90jQsgiWzExk(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩଢ")] = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩ࠳࠴࠵࠶ࠧଣ")
			if title==JGwsL21ZRlqSrWxEmF(u"ࠪ࠱࠶࠭ତ"): dict[R3lezw8h407ZvrAFxT(u"ࠫࡹ࡯ࡴ࡭ࡧࠪଥ")] = dict[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࡺࡹࡱࡧ࠵ࠫଦ")]+QQHFtjcaR2VpnSyTIv(u"࠭࠺ࠡࠢࠪଧ")+dict[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩନ")]+Uv7MkgVGyEbAlfFP0S8Zjqp2J+lRP6GTaZJA1Xw3egLM4(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ଩")
			else: dict[rNyT0edugn(u"ࠩࡷ࡭ࡹࡲࡥࠨପ")] = dict[JGwsL21ZRlqSrWxEmF(u"ࠪࡸࡾࡶࡥ࠳ࠩଫ")]+V0VZk9763fusTReHFo4(u"ࠫ࠿ࠦࠠࠨବ")+dict[rNyT0edugn(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧଭ")]+Uv7MkgVGyEbAlfFP0S8Zjqp2J+dict[R3lezw8h407ZvrAFxT(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧମ")]+kb2icmDGVUZfW1OFz7sv(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧଯ")+dict[V0VZk9763fusTReHFo4(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩର")]
			JPw7OlgYLWb02KRyrQ1hmtDZ.append(dict)
	JPw7OlgYLWb02KRyrQ1hmtDZ = sorted(JPw7OlgYLWb02KRyrQ1hmtDZ,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: int(key[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ଱")]))
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [NOrchaEV1iIZ87Uzlwgum(u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧଲ")],[NdKhAS6MXVEORLTwob92pxlZ]
	try: MMyq7lWOz4Dn = wwIl14v7ZDcRiMAm[NOrchaEV1iIZ87Uzlwgum(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭ଳ")][fOc18oTm5hsdD4pVZQj(u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ଴")][YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭ଵ")]
	except: MMyq7lWOz4Dn = []
	try: pSdMw5ZAHa1EytJP = wwIl14v7ZDcRiMAm[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩଶ")][lRP6GTaZJA1Xw3egLM4(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬଷ")][hCm2fnEXs6Zt(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩସ")]
	except: pSdMw5ZAHa1EytJP = []
	for rD1pe46nZKkIhEbPlzLm0jWd3N8CV in MMyq7lWOz4Dn+pSdMw5ZAHa1EytJP:
		try:
			zehVcU893FC6LEd1Aij = rD1pe46nZKkIhEbPlzLm0jWd3N8CV[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫହ")]
			try: title = rD1pe46nZKkIhEbPlzLm0jWd3N8CV[QQHFtjcaR2VpnSyTIv(u"ࠫࡳࡧ࡭ࡦࠩ଺")][hCm2fnEXs6Zt(u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩ଻")]
			except: title = rD1pe46nZKkIhEbPlzLm0jWd3N8CV[lrtFSogC8Nh9(u"࠭࡮ࡢ࡯ࡨ଼ࠫ")][lRP6GTaZJA1Xw3egLM4(u"ࠧࡳࡷࡱࡷࠬଽ")][e8XhbyuzvjYkIsJUtB5w][lNTJCZeBicWEz0Mg(u"ࠨࡶࡨࡼࡹ࠭ା")]
		except: continue
		if title not in IGEpKNCaiLMT:
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			IGEpKNCaiLMT.append(title)
	if len(IGEpKNCaiLMT)>llxMLe4gobHhsj1WGvd7qmIU:
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩสาฯืࠠศๆอีั๋ษࠡࠪࠪି")+str(len(IGEpKNCaiLMT))+QQHFtjcaR2VpnSyTIv(u"ࠪࠤ๊๊แࠪࠩୀ"), IGEpKNCaiLMT)
		if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩୁ"),[],[]
		elif rRfpvbZojlygET5JL87wdzIPGe!=e8XhbyuzvjYkIsJUtB5w:
			zehVcU893FC6LEd1Aij = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]+JGwsL21ZRlqSrWxEmF(u"ࠬࠬࠧୂ")
			xUbhTNz3J4mRWAVLIgEXya7 = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫୃ"),zehVcU893FC6LEd1Aij)
			if xUbhTNz3J4mRWAVLIgEXya7: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(xUbhTNz3J4mRWAVLIgEXya7[e8XhbyuzvjYkIsJUtB5w],OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨୄ"))
			else: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ୅")
			k85kVbHKMXdrJOcFZ3 = zehVcU893FC6LEd1Aij.strip(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࠩࠫ୆"))
	MM3jlypOEut8vzd = []
	for dict in JPw7OlgYLWb02KRyrQ1hmtDZ:
		if dict[QQHFtjcaR2VpnSyTIv(u"ࠪࡸࡾࡶࡥ࠳ࠩେ")]==Hlp3z0APt1GR4kMYK5xST(u"࡛ࠫ࡯ࡤࡦࡱࠪୈ"):
			vORKrZwSCud.append(dict[PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡺࡩࡵ࡮ࡨࠫ୉")])
			U7a2bws6yCoKcuBYQHjeizqLM.append(dict)
		elif dict[NOrchaEV1iIZ87Uzlwgum(u"࠭ࡴࡺࡲࡨ࠶ࠬ୊")]==eGW7cI6aQhr0(u"ࠧࡂࡷࡧ࡭ࡴ࠭ୋ"):
			HVpIGgmrcK.append(dict[QQHFtjcaR2VpnSyTIv(u"ࠨࡶ࡬ࡸࡱ࡫ࠧୌ")])
			HBn4qjQDdyAbK5J.append(dict)
		elif dict[OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨ୍ࠫ")]==QQHFtjcaR2VpnSyTIv(u"ࠪࡱࡵࡪࠧ୎"):
			title = dict[hCm2fnEXs6Zt(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୏")].replace(IlL8ZnX74Yvep(u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ୐"),NdKhAS6MXVEORLTwob92pxlZ)
			if YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ୑") not in list(dict.keys()): rFSUYwTohtsByX4HJ0qElMD8nuk = lNTJCZeBicWEz0Mg(u"ࠧ࠱ࠩ୒")
			else: rFSUYwTohtsByX4HJ0qElMD8nuk = dict[Hlp3z0APt1GR4kMYK5xST(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ୓")]
			MM3jlypOEut8vzd.append([dict,{},title,rFSUYwTohtsByX4HJ0qElMD8nuk])
		else:
			title = dict[eGW7cI6aQhr0(u"ࠩࡷ࡭ࡹࡲࡥࠨ୔")].replace(R3lezw8h407ZvrAFxT(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ୕"),NdKhAS6MXVEORLTwob92pxlZ)
			if kb2icmDGVUZfW1OFz7sv(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬୖ") not in list(dict.keys()): rFSUYwTohtsByX4HJ0qElMD8nuk = NeU6uRGpECkvMV5jf(u"ࠬ࠶ࠧୗ")
			else: rFSUYwTohtsByX4HJ0qElMD8nuk = dict[NeU6uRGpECkvMV5jf(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ୘")]
			MM3jlypOEut8vzd.append([dict,{},title,rFSUYwTohtsByX4HJ0qElMD8nuk])
			jg3nCaphckXFvi0VsbQL5uH.append(title)
			cc7InUBbAY.append(dict)
		vobzanCrwY = k6apiPAlLKM1ed8J42RjHh0o
		if NOrchaEV1iIZ87Uzlwgum(u"ࠧࡤࡱࡧࡩࡨࡹࠧ୙") in list(dict.keys()):
			if fOc18oTm5hsdD4pVZQj(u"ࠨࡣࡹ࠴ࠬ୚") in dict[hCm2fnEXs6Zt(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ୛")]: vobzanCrwY = f4vncKMRlXG9s
			elif kQI947MebLovYyVE08F5qPi6fj3<vju3SZDWL4ENYelmBOzUqrogp2(u"࠱࠹ഒ") and fOc18oTm5hsdD4pVZQj(u"ࠪࡥࡻࡩࠧଡ଼") not in dict[lRP6GTaZJA1Xw3egLM4(u"ࠫࡨࡵࡤࡦࡥࡶࠫଢ଼")] and lNTJCZeBicWEz0Mg(u"ࠬࡳࡰ࠵ࡣࠪ୞") not in dict[pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ୟ")]: vobzanCrwY = f4vncKMRlXG9s
		if vobzanCrwY and dict[vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࡵࡻࡳࡩ࠷࠭ୠ")]==ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡘ࡬ࡨࡪࡵࠧୡ") and dict[R3lezw8h407ZvrAFxT(u"ࠩ࡬ࡲ࡮ࡺࠧୢ")]!=Hlp3z0APt1GR4kMYK5xST(u"ࠪ࠴࠲࠶ࠧୣ"):
			G9b2QjDgCzaBpHJ5.append(dict[gniNItGL6bKwpEW(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୤")])
			EELJTab0FSmQ92MDpUCu3okd5A.append(dict)
		elif vobzanCrwY and dict[OOkmZiVcfqlEurM1dHGb(u"ࠬࡺࡹࡱࡧ࠵ࠫ୥")]==rNyT0edugn(u"࠭ࡁࡶࡦ࡬ࡳࠬ୦") and dict[PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡪࡰ࡬ࡸࠬ୧")]!=HVmIrFwau90jQsgiWzExk(u"ࠨ࠲࠰࠴ࠬ୨"):
			y5O3U0lJPGYj2TVfFtq1.append(dict[rNyT0edugn(u"ࠩࡷ࡭ࡹࡲࡥࠨ୩")])
			f6mYOyLsa10UK8wZbChW.append(dict)
	for UQC3hSuM2lZ7kyOdxF8Lo0aztV1K in f6mYOyLsa10UK8wZbChW:
		s3yt0Vvnulm98HJ1rxh = UQC3hSuM2lZ7kyOdxF8Lo0aztV1K[lRP6GTaZJA1Xw3egLM4(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ୪")]
		for efo8uHkmazcT5i4SJRFM7 in EELJTab0FSmQ92MDpUCu3okd5A:
			GGRcOWqElJfKQLiaNH2Pg5htv1XB3U = efo8uHkmazcT5i4SJRFM7[eGW7cI6aQhr0(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ୫")]
			rFSUYwTohtsByX4HJ0qElMD8nuk = int(GGRcOWqElJfKQLiaNH2Pg5htv1XB3U)+int(s3yt0Vvnulm98HJ1rxh)
			title = efo8uHkmazcT5i4SJRFM7[YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡺࡩࡵ࡮ࡨࠫ୬")].replace(lRP6GTaZJA1Xw3egLM4(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ୭"),Hlp3z0APt1GR4kMYK5xST(u"ࠧ࡮ࡲࡧࠤࠥ࠭୮"))
			title = title.replace(efo8uHkmazcT5i4SJRFM7[Hlp3z0APt1GR4kMYK5xST(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ୯")]+Uv7MkgVGyEbAlfFP0S8Zjqp2J,NdKhAS6MXVEORLTwob92pxlZ)
			title = title.replace(GGRcOWqElJfKQLiaNH2Pg5htv1XB3U+OOkmZiVcfqlEurM1dHGb(u"ࠩ࡮ࡦࡵࡹࠧ୰"),str(rFSUYwTohtsByX4HJ0qElMD8nuk)+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡯ࡧࡶࡳࠨୱ"))
			title = title+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫ࠭࠭୲")+UQC3hSuM2lZ7kyOdxF8Lo0aztV1K[lrtFSogC8Nh9(u"ࠬࡺࡩࡵ࡮ࡨࠫ୳")].split(IlL8ZnX74Yvep(u"࠭ࠨࠨ୴"),llxMLe4gobHhsj1WGvd7qmIU)[llxMLe4gobHhsj1WGvd7qmIU]
			MM3jlypOEut8vzd.append([efo8uHkmazcT5i4SJRFM7,UQC3hSuM2lZ7kyOdxF8Lo0aztV1K,title,rFSUYwTohtsByX4HJ0qElMD8nuk])
	nmf7NvpgRwVPGxhAbeC5ik2 = []
	for stream in MM3jlypOEut8vzd:
		efo8uHkmazcT5i4SJRFM7,UQC3hSuM2lZ7kyOdxF8Lo0aztV1K,title,rFSUYwTohtsByX4HJ0qElMD8nuk = stream
		A0KmCsTOIn6hHNpFjP = title[:uL69vJOU7xN0hGnZf2islDqk]
		if Tzx81Wb0RZC4ID5AyiU2(u"ࠧัๅํอࠬ୵") in title: A0KmCsTOIn6hHNpFjP += eGW7cI6aQhr0(u"ࠨ࠭ࠪ୶")
		nmf7NvpgRwVPGxhAbeC5ik2.append([stream,A0KmCsTOIn6hHNpFjP,int(rFSUYwTohtsByX4HJ0qElMD8nuk)])
	o5jZUyNPBV = f4vncKMRlXG9s
	s7EObei1y9f5uzTSnH = bkqNe6d9GKctQ(yNIDEX5hU4G769,nmf7NvpgRwVPGxhAbeC5ik2)
	if s7EObei1y9f5uzTSnH:
		BdmYK3SkbqoLiN,c4chgEC9JvT2eLVtubfWiaNUXA7B,title,rFSUYwTohtsByX4HJ0qElMD8nuk = s7EObei1y9f5uzTSnH[OOkmZiVcfqlEurM1dHGb(u"࠱ഓ")][OOkmZiVcfqlEurM1dHGb(u"࠱ഓ")]
		q5biGxDUYWKHIElhp = BdmYK3SkbqoLiN[HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡸࡶࡱ࠭୷")]
		if eGW7cI6aQhr0(u"ࠪࡱࡵࡪࠧ୸") in title and q5biGxDUYWKHIElhp!=etIolqazKYCO9kXviH08FcE2y1WJfU: o5jZUyNPBV = k6apiPAlLKM1ed8J42RjHh0o
		SSAftji8BdTODK0MICh3 = title
	else:
		yg2cN3viaqXRtC9lBS5KVh8bm = bkqNe6d9GKctQ(yNIDEX5hU4G769,nmf7NvpgRwVPGxhAbeC5ik2,kb2icmDGVUZfW1OFz7sv(u"࠳࠸࠴࠵ഔ"))
		yg2cN3viaqXRtC9lBS5KVh8bm,dTDEx6AGogWCXyiJUIq3L40,gV7U4r1eiWb6thNEdHaxYMnRoQmP = zip(*yg2cN3viaqXRtC9lBS5KVh8bm)
		hQgNWme5ikKIL8aJjoH3u,EEyMfdZcaB4SWsnpiRtPYXx,jDmwtZLPpTQKboI = [],[],e8XhbyuzvjYkIsJUtB5w
		MM3jlypOEut8vzd = sorted(MM3jlypOEut8vzd, reverse=k6apiPAlLKM1ed8J42RjHh0o, key=lambda key: float(key[uL69vJOU7xN0hGnZf2islDqk]))
		RFmd7SuHDc6x2yq15vVohUj3,Pisg3QJtzB9G8hVFZvc,vXYz7wbeQ3dpLS5P2xA9uZRncrWt = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
		try: RFmd7SuHDc6x2yq15vVohUj3 = wwIl14v7ZDcRiMAm[lrtFSogC8Nh9(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ୹")][Hlp3z0APt1GR4kMYK5xST(u"ࠬࡧࡵࡵࡪࡲࡶࠬ୺")]
		except:
			try: RFmd7SuHDc6x2yq15vVohUj3 = ffiUrcjECR4yKXu[IlL8ZnX74Yvep(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ୻")][NeU6uRGpECkvMV5jf(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧ୼")]
			except: pass
		try: Pisg3QJtzB9G8hVFZvc = wwIl14v7ZDcRiMAm[R3lezw8h407ZvrAFxT(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ୽")][vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ୾")]
		except:
			try: Pisg3QJtzB9G8hVFZvc = ffiUrcjECR4yKXu[lrtFSogC8Nh9(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ୿")][YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧ஀")]
			except: pass
		if RFmd7SuHDc6x2yq15vVohUj3 and Pisg3QJtzB9G8hVFZvc:
			jDmwtZLPpTQKboI += llxMLe4gobHhsj1WGvd7qmIU
			title = Whef0cxB2iR93SC5IwUtk+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ஁")+RFmd7SuHDc6x2yq15vVohUj3+kjd9LyNqQHMUevZiRI7OlBGF1h
			zehVcU893FC6LEd1Aij = xKp3jkIvM09AZ4euXa87i5TVtfUD[NeU6uRGpECkvMV5jf(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧஂ")][e8XhbyuzvjYkIsJUtB5w]+OOkmZiVcfqlEurM1dHGb(u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪஃ")+Pisg3QJtzB9G8hVFZvc
			hQgNWme5ikKIL8aJjoH3u.append(title)
			EEyMfdZcaB4SWsnpiRtPYXx.append(zehVcU893FC6LEd1Aij)
			try: vXYz7wbeQ3dpLS5P2xA9uZRncrWt = wwIl14v7ZDcRiMAm[QQHFtjcaR2VpnSyTIv(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ஄")][WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬஅ")][HVmIrFwau90jQsgiWzExk(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧஆ")][-llxMLe4gobHhsj1WGvd7qmIU][OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡺࡸ࡬ࠨஇ")]
			except:
				try: vXYz7wbeQ3dpLS5P2xA9uZRncrWt = ffiUrcjECR4yKXu[IlL8ZnX74Yvep(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫஈ")][fOc18oTm5hsdD4pVZQj(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩஉ")][NOrchaEV1iIZ87Uzlwgum(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫஊ")][-llxMLe4gobHhsj1WGvd7qmIU][eGW7cI6aQhr0(u"ࠨࡷࡵࡰࠬ஋")]
				except: pass
		for efo8uHkmazcT5i4SJRFM7,UQC3hSuM2lZ7kyOdxF8Lo0aztV1K,title,rFSUYwTohtsByX4HJ0qElMD8nuk in yg2cN3viaqXRtC9lBS5KVh8bm:
			hQgNWme5ikKIL8aJjoH3u.append(title) ; EEyMfdZcaB4SWsnpiRtPYXx.append(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ஌"))
		if jg3nCaphckXFvi0VsbQL5uH: hQgNWme5ikKIL8aJjoH3u.append(eGW7cI6aQhr0(u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ஍")) ; EEyMfdZcaB4SWsnpiRtPYXx.append(kb2icmDGVUZfW1OFz7sv(u"ࠫࡲࡻࡸࡦࡦࠪஎ"))
		if MM3jlypOEut8vzd: hQgNWme5ikKIL8aJjoH3u.append(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩஏ")) ; EEyMfdZcaB4SWsnpiRtPYXx.append(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡡ࡭࡮ࠪஐ"))
		if G9b2QjDgCzaBpHJ5: hQgNWme5ikKIL8aJjoH3u.append(NOrchaEV1iIZ87Uzlwgum(u"ࠧศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬ஑")) ; EEyMfdZcaB4SWsnpiRtPYXx.append(JGwsL21ZRlqSrWxEmF(u"ࠨ࡯ࡳࡨࠬஒ"))
		if vORKrZwSCud: hQgNWme5ikKIL8aJjoH3u.append(JGwsL21ZRlqSrWxEmF(u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩஓ")) ; EEyMfdZcaB4SWsnpiRtPYXx.append(kb2icmDGVUZfW1OFz7sv(u"ࠪࡺ࡮ࡪࡥࡰࠩஔ"))
		if HVpIGgmrcK: hQgNWme5ikKIL8aJjoH3u.append(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫக")) ; EEyMfdZcaB4SWsnpiRtPYXx.append(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡧࡵࡥ࡫ࡲࠫ஖"))
		while k6apiPAlLKM1ed8J42RjHh0o:
			rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(KPDs0hxnXv1TkjAeWQLR2drflU5M, hQgNWme5ikKIL8aJjoH3u)
			if rRfpvbZojlygET5JL87wdzIPGe==-llxMLe4gobHhsj1WGvd7qmIU: return hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ஗"),[],[]
			elif rRfpvbZojlygET5JL87wdzIPGe==e8XhbyuzvjYkIsJUtB5w and RFmd7SuHDc6x2yq15vVohUj3:
				zehVcU893FC6LEd1Aij = EEyMfdZcaB4SWsnpiRtPYXx[rRfpvbZojlygET5JL87wdzIPGe]
				yEH9TlCK53NSmtVopLGPsBxI = hnu0oKAvsG4PaX6yxiTj2eftY.argv[e8XhbyuzvjYkIsJUtB5w]+hCm2fnEXs6Zt(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ஘")+YUkzG2ymNSqdon(RFmd7SuHDc6x2yq15vVohUj3)+JGwsL21ZRlqSrWxEmF(u"ࠨࠨࡸࡶࡱࡃࠧங")+zehVcU893FC6LEd1Aij
				if vXYz7wbeQ3dpLS5P2xA9uZRncrWt: yEH9TlCK53NSmtVopLGPsBxI = yEH9TlCK53NSmtVopLGPsBxI+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪச")+YUkzG2ymNSqdon(vXYz7wbeQ3dpLS5P2xA9uZRncrWt)
				ACOWB6GRmIbDKyl3Zn.executebuiltin(HVmIrFwau90jQsgiWzExk(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ஛")+yEH9TlCK53NSmtVopLGPsBxI+kb2icmDGVUZfW1OFz7sv(u"ࠦ࠮ࠨஜ"))
				return Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ஝"),[],[]
			us7rL1qZAJURmQjPTtIhGN0daXf869 = EEyMfdZcaB4SWsnpiRtPYXx[rRfpvbZojlygET5JL87wdzIPGe]
			SSAftji8BdTODK0MICh3 = hQgNWme5ikKIL8aJjoH3u[rRfpvbZojlygET5JL87wdzIPGe]
			if us7rL1qZAJURmQjPTtIhGN0daXf869==NeU6uRGpECkvMV5jf(u"࠭ࡤࡢࡵ࡫ࠫஞ"):
				q5biGxDUYWKHIElhp = etIolqazKYCO9kXviH08FcE2y1WJfU
				break
			elif us7rL1qZAJURmQjPTtIhGN0daXf869 in [OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠧࡢࡷࡧ࡭ࡴ࠭ட"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡸ࡬ࡨࡪࡵࠧ஠"),lNTJCZeBicWEz0Mg(u"ࠩࡰࡹࡽ࡫ࡤࠨ஡")]:
				if us7rL1qZAJURmQjPTtIhGN0daXf869==R3lezw8h407ZvrAFxT(u"ࠪࡱࡺࡾࡥࡥࠩ஢"): IGEpKNCaiLMT,WNVly9Zp6xzDRT4sUYw = jg3nCaphckXFvi0VsbQL5uH,cc7InUBbAY
				elif us7rL1qZAJURmQjPTtIhGN0daXf869==HVmIrFwau90jQsgiWzExk(u"ࠫࡻ࡯ࡤࡦࡱࠪண"): IGEpKNCaiLMT,WNVly9Zp6xzDRT4sUYw = vORKrZwSCud,U7a2bws6yCoKcuBYQHjeizqLM
				elif us7rL1qZAJURmQjPTtIhGN0daXf869==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡧࡵࡥ࡫ࡲࠫத"): IGEpKNCaiLMT,WNVly9Zp6xzDRT4sUYw = HVpIGgmrcK,HBn4qjQDdyAbK5J
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(JGwsL21ZRlqSrWxEmF(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬ஥")+str(len(IGEpKNCaiLMT))+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࠡ็็ๅ࠮࠭஦"), IGEpKNCaiLMT)
				if rRfpvbZojlygET5JL87wdzIPGe!=-llxMLe4gobHhsj1WGvd7qmIU:
					q5biGxDUYWKHIElhp = WNVly9Zp6xzDRT4sUYw[rRfpvbZojlygET5JL87wdzIPGe][lNTJCZeBicWEz0Mg(u"ࠨࡷࡵࡰࠬ஧")]
					SSAftji8BdTODK0MICh3 = IGEpKNCaiLMT[rRfpvbZojlygET5JL87wdzIPGe]
					break
			elif us7rL1qZAJURmQjPTtIhGN0daXf869==vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩࡰࡴࡩ࠭ந"):
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(Hlp3z0APt1GR4kMYK5xST(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࠦࠨࠨன")+str(len(G9b2QjDgCzaBpHJ5))+rtUJso6d7iaNf1yWejxnc5DEXFg(u"๋ࠫࠥไโࠫࠪப"), G9b2QjDgCzaBpHJ5)
				if rRfpvbZojlygET5JL87wdzIPGe!=-llxMLe4gobHhsj1WGvd7qmIU:
					SSAftji8BdTODK0MICh3 = G9b2QjDgCzaBpHJ5[rRfpvbZojlygET5JL87wdzIPGe]
					BdmYK3SkbqoLiN = EELJTab0FSmQ92MDpUCu3okd5A[rRfpvbZojlygET5JL87wdzIPGe]
					rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(rNyT0edugn(u"ࠬอฮหำࠣะํีษࠡษ็ูํะࠠࠩࠩ஫")+str(len(y5O3U0lJPGYj2TVfFtq1))+eGW7cI6aQhr0(u"࠭ࠠๆๆไ࠭ࠬ஬"), y5O3U0lJPGYj2TVfFtq1)
					if rRfpvbZojlygET5JL87wdzIPGe!=-llxMLe4gobHhsj1WGvd7qmIU:
						SSAftji8BdTODK0MICh3 += OOkmZiVcfqlEurM1dHGb(u"ࠧࠡ࠭ࠣࠫ஭")+y5O3U0lJPGYj2TVfFtq1[rRfpvbZojlygET5JL87wdzIPGe]
						c4chgEC9JvT2eLVtubfWiaNUXA7B = f6mYOyLsa10UK8wZbChW[rRfpvbZojlygET5JL87wdzIPGe]
						o5jZUyNPBV = k6apiPAlLKM1ed8J42RjHh0o
						break
			elif us7rL1qZAJURmQjPTtIhGN0daXf869==HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡣ࡯ࡰࠬம"):
				k0gJv2nS3FfIVs9e7UYOmNDiG84jX,N1EndI2gSc65bJHYKZCkwRup3a4o,ryJ9vzFGRghKZ6Hj7moec,RD0ZoSEYgpN = list(zip(*MM3jlypOEut8vzd))
				rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨய")+str(len(ryJ9vzFGRghKZ6Hj7moec))+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪࠤ๊๊แࠪࠩர"), ryJ9vzFGRghKZ6Hj7moec)
				if rRfpvbZojlygET5JL87wdzIPGe!=-llxMLe4gobHhsj1WGvd7qmIU:
					SSAftji8BdTODK0MICh3 = ryJ9vzFGRghKZ6Hj7moec[rRfpvbZojlygET5JL87wdzIPGe]
					BdmYK3SkbqoLiN = k0gJv2nS3FfIVs9e7UYOmNDiG84jX[rRfpvbZojlygET5JL87wdzIPGe]
					if PzIpQnUXxRwNCivDhdakWTE(u"ࠫࡲࡶࡤࠨற") in ryJ9vzFGRghKZ6Hj7moec[rRfpvbZojlygET5JL87wdzIPGe] and BdmYK3SkbqoLiN[HVmIrFwau90jQsgiWzExk(u"ࠬࡻࡲ࡭ࠩல")]!=etIolqazKYCO9kXviH08FcE2y1WJfU:
						c4chgEC9JvT2eLVtubfWiaNUXA7B = N1EndI2gSc65bJHYKZCkwRup3a4o[rRfpvbZojlygET5JL87wdzIPGe]
						o5jZUyNPBV = k6apiPAlLKM1ed8J42RjHh0o
					else: q5biGxDUYWKHIElhp = BdmYK3SkbqoLiN[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡵࡳ࡮ࠪள")]
					break
			elif us7rL1qZAJURmQjPTtIhGN0daXf869==NeU6uRGpECkvMV5jf(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨழ"):
				k0gJv2nS3FfIVs9e7UYOmNDiG84jX,N1EndI2gSc65bJHYKZCkwRup3a4o,ryJ9vzFGRghKZ6Hj7moec,RD0ZoSEYgpN = list(zip(*yg2cN3viaqXRtC9lBS5KVh8bm))
				BdmYK3SkbqoLiN = k0gJv2nS3FfIVs9e7UYOmNDiG84jX[rRfpvbZojlygET5JL87wdzIPGe-jDmwtZLPpTQKboI]
				if eGW7cI6aQhr0(u"ࠨ࡯ࡳࡨࠬவ") in ryJ9vzFGRghKZ6Hj7moec[rRfpvbZojlygET5JL87wdzIPGe-jDmwtZLPpTQKboI] and BdmYK3SkbqoLiN[NeU6uRGpECkvMV5jf(u"ࠩࡸࡶࡱ࠭ஶ")]!=etIolqazKYCO9kXviH08FcE2y1WJfU:
					c4chgEC9JvT2eLVtubfWiaNUXA7B = N1EndI2gSc65bJHYKZCkwRup3a4o[rRfpvbZojlygET5JL87wdzIPGe-jDmwtZLPpTQKboI]
					o5jZUyNPBV = k6apiPAlLKM1ed8J42RjHh0o
				else: q5biGxDUYWKHIElhp = BdmYK3SkbqoLiN[IlL8ZnX74Yvep(u"ࠪࡹࡷࡲࠧஷ")]
				SSAftji8BdTODK0MICh3 = ryJ9vzFGRghKZ6Hj7moec[rRfpvbZojlygET5JL87wdzIPGe-jDmwtZLPpTQKboI]
				break
	if o5jZUyNPBV:
		XUSW95ZEMAFHvt6QLjgPrz7ueNsBVh = int(BdmYK3SkbqoLiN[HVmIrFwau90jQsgiWzExk(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ஸ")])
		aqzjiEHrKP5NS21g4ne = int(c4chgEC9JvT2eLVtubfWiaNUXA7B[OOkmZiVcfqlEurM1dHGb(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧஹ")])
		TLrSzM98nc2H3VODdyhpQI = str(max(XUSW95ZEMAFHvt6QLjgPrz7ueNsBVh,aqzjiEHrKP5NS21g4ne))
		eA82EOqWsSBvuKmQgVLp = BdmYK3SkbqoLiN[HHvYL68lbJVZWM7tQEzSex3(u"࠭ࡵࡳ࡮ࠪ஺")].replace(xY4icgQUj6mPVs73CTKu(u"ࠧࠧࠩ஻"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠨࡤࡱࡵࡁࠧ஼"))
		CAzabrYpKfI7PB5M = c4chgEC9JvT2eLVtubfWiaNUXA7B[rNyT0edugn(u"ࠩࡸࡶࡱ࠭஽")].replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࠪࠬா"),rNyT0edugn(u"ࠫࠫࡧ࡭ࡱ࠽ࠪி"))
		mpd = HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡂࡍࡑࡆࠣࡱࡪࡪࡩࡢࡒࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࡄࡶࡴࡤࡸ࡮ࡵ࡮࠾ࠤࡓࡘࠬீ")+TLrSzM98nc2H3VODdyhpQI+xY4icgQUj6mPVs73CTKu(u"࠭ࡓࠣࡀ࡟ࡲࠬு")
		mpd += NOrchaEV1iIZ87Uzlwgum(u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫூ")
		mpd += eGW7cI6aQhr0(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬ௃")+BdmYK3SkbqoLiN[V0VZk9763fusTReHFo4(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ௄")]+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ௅")+BdmYK3SkbqoLiN[rNyT0edugn(u"ࠫࡨࡵࡤࡦࡥࡶࠫெ")]+xY4icgQUj6mPVs73CTKu(u"ࠬࠨ࠾࡝ࡰࠪே")
		mpd += lrtFSogC8Nh9(u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫை")
		mpd += HHvYL68lbJVZWM7tQEzSex3(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ௉")+eA82EOqWsSBvuKmQgVLp+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧொ")
		mpd += vju3SZDWL4ENYelmBOzUqrogp2(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧோ")+BdmYK3SkbqoLiN[hCm2fnEXs6Zt(u"ࠪ࡭ࡳࡪࡥࡹࠩௌ")]+fOc18oTm5hsdD4pVZQj(u"ࠫࠧࡄ࡜࡯்ࠩ")
		mpd += lrtFSogC8Nh9(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ௎")+BdmYK3SkbqoLiN[xY4icgQUj6mPVs73CTKu(u"࠭ࡩ࡯࡫ࡷࠫ௏")]+QQHFtjcaR2VpnSyTIv(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧௐ")
		mpd += LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ௑")
		mpd += gniNItGL6bKwpEW(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ௒")
		mpd += hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ௓")
		mpd += pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨ௔")+c4chgEC9JvT2eLVtubfWiaNUXA7B[WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௕")]+gniNItGL6bKwpEW(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪ௖")+c4chgEC9JvT2eLVtubfWiaNUXA7B[IlL8ZnX74Yvep(u"ࠧࡤࡱࡧࡩࡨࡹࠧௗ")]+gniNItGL6bKwpEW(u"ࠨࠤࡁࡠࡳ࠭௘")
		mpd += hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ௙")
		mpd += PzIpQnUXxRwNCivDhdakWTE(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭௚")+CAzabrYpKfI7PB5M+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ௛")
		mpd += PzIpQnUXxRwNCivDhdakWTE(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ௜")+c4chgEC9JvT2eLVtubfWiaNUXA7B[OOkmZiVcfqlEurM1dHGb(u"࠭ࡩ࡯ࡦࡨࡼࠬ௝")]+eGW7cI6aQhr0(u"ࠧࠣࡀ࡟ࡲࠬ௞")
		mpd += YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ௟")+c4chgEC9JvT2eLVtubfWiaNUXA7B[gniNItGL6bKwpEW(u"ࠩ࡬ࡲ࡮ࡺࠧ௠")]+xY4icgQUj6mPVs73CTKu(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ௡")
		mpd += LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ௢")
		mpd += LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ௣")
		mpd += xY4icgQUj6mPVs73CTKu(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ௤")
		mpd += eGW7cI6aQhr0(u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ௥")
		mpd += YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪ௦")
		if J92gCnbGWidQV70lBteTwU6D8uyzL:
			import http.server as jj3hDlQtX7CZPFu1N2iJ
			import http.client as IFeCZk4lmgHPDB2Lf
		else:
			import BaseHTTPServer as jj3hDlQtX7CZPFu1N2iJ
			import httplib as IFeCZk4lmgHPDB2Lf
		class Al9MTJQNhkC(jj3hDlQtX7CZPFu1N2iJ.HTTPServer):
			def __init__(gXxGoMb8p6aWPL9eIj7fn34Z,ip=fOc18oTm5hsdD4pVZQj(u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ௧"),port=IlL8ZnX74Yvep(u"࠸࠹࠵࠻࠵ക"),mpd=QQHFtjcaR2VpnSyTIv(u"ࠪࡀࡃ࠭௨")):
				gXxGoMb8p6aWPL9eIj7fn34Z.ip = ip
				gXxGoMb8p6aWPL9eIj7fn34Z.port = port
				gXxGoMb8p6aWPL9eIj7fn34Z.mpd = mpd
				jj3hDlQtX7CZPFu1N2iJ.HTTPServer.__init__(gXxGoMb8p6aWPL9eIj7fn34Z,(gXxGoMb8p6aWPL9eIj7fn34Z.ip,gXxGoMb8p6aWPL9eIj7fn34Z.port),Pir2xBsgtYAFEqLIeC5NdT71fZ)
				gXxGoMb8p6aWPL9eIj7fn34Z.mpdurl = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ௩")+ip+IlL8ZnX74Yvep(u"ࠬࡀࠧ௪")+str(port)+kb2icmDGVUZfW1OFz7sv(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ௫")
			def start(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.threads = k8Q6Hp1Z3YWK(f4vncKMRlXG9s)
				gXxGoMb8p6aWPL9eIj7fn34Z.threads.kraoHTGpWFtyz(llxMLe4gobHhsj1WGvd7qmIU,gXxGoMb8p6aWPL9eIj7fn34Z.T4kEcX9tMvzbFCuoiZdB)
			def T4kEcX9tMvzbFCuoiZdB(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.keeprunning = k6apiPAlLKM1ed8J42RjHh0o
				while gXxGoMb8p6aWPL9eIj7fn34Z.keeprunning:
					gXxGoMb8p6aWPL9eIj7fn34Z.handle_request()
			def stop(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.keeprunning = f4vncKMRlXG9s
				gXxGoMb8p6aWPL9eIj7fn34Z.PtGLmYdlKyw9EzBb5CM8Rhs64()
			def EgbABcq6041Ly5enIXDv(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.stop()
				gXxGoMb8p6aWPL9eIj7fn34Z.IEda5gR6kvfhQw3W0j.close()
				gXxGoMb8p6aWPL9eIj7fn34Z.server_close()
			def V0VgqYl5RoIXLybn6Mx(gXxGoMb8p6aWPL9eIj7fn34Z,mpd):
				gXxGoMb8p6aWPL9eIj7fn34Z.mpd = mpd
			def PtGLmYdlKyw9EzBb5CM8Rhs64(gXxGoMb8p6aWPL9eIj7fn34Z):
				Yo5K7kXcjOVq2SiTvludJ48f = IFeCZk4lmgHPDB2Lf.HTTPConnection(gXxGoMb8p6aWPL9eIj7fn34Z.ip+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠻ࠩ௬")+str(gXxGoMb8p6aWPL9eIj7fn34Z.port))
				Yo5K7kXcjOVq2SiTvludJ48f.request(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠣࡊࡈࡅࡉࠨ௭"), LtGoXlQ2IYxqTJRySE6udfW98(u"ࠤ࠲ࠦ௮"))
		class Pir2xBsgtYAFEqLIeC5NdT71fZ(jj3hDlQtX7CZPFu1N2iJ.BaseHTTPRequestHandler):
			def L7AtdgKzUkYcN(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.send_response(gniNItGL6bKwpEW(u"࠶࠵࠶ഖ"))
				gXxGoMb8p6aWPL9eIj7fn34Z.send_header(V0VZk9763fusTReHFo4(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ௯"),OOkmZiVcfqlEurM1dHGb(u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ௰"))
				gXxGoMb8p6aWPL9eIj7fn34Z.end_headers()
				gXxGoMb8p6aWPL9eIj7fn34Z.wfile.write(gXxGoMb8p6aWPL9eIj7fn34Z.oikt6P0hOAD5IvnlMpxf1.mpd.encode(YRvPKe2zMTDs8UCkr))
				XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
				if gXxGoMb8p6aWPL9eIj7fn34Z.path==R3lezw8h407ZvrAFxT(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ௱"): gXxGoMb8p6aWPL9eIj7fn34Z.oikt6P0hOAD5IvnlMpxf1.EgbABcq6041Ly5enIXDv()
				if gXxGoMb8p6aWPL9eIj7fn34Z.path==gniNItGL6bKwpEW(u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ௲"): gXxGoMb8p6aWPL9eIj7fn34Z.oikt6P0hOAD5IvnlMpxf1.EgbABcq6041Ly5enIXDv()
			def S3Sx0YTFjdgAoX4Kp(gXxGoMb8p6aWPL9eIj7fn34Z):
				gXxGoMb8p6aWPL9eIj7fn34Z.send_response(Hlp3z0APt1GR4kMYK5xST(u"࠷࠶࠰ഗ"))
				gXxGoMb8p6aWPL9eIj7fn34Z.end_headers()
		ImG7FH0jCdSgtc = Al9MTJQNhkC(OOkmZiVcfqlEurM1dHGb(u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪ௳"),HVmIrFwau90jQsgiWzExk(u"࠻࠵࠱࠷࠸ഘ"),mpd)
		q5biGxDUYWKHIElhp = ImG7FH0jCdSgtc.mpdurl
		ImG7FH0jCdSgtc.start()
	else: ImG7FH0jCdSgtc = NdKhAS6MXVEORLTwob92pxlZ
	if J92gCnbGWidQV70lBteTwU6D8uyzL: w0aE3Mzvb75ZJ1lfg8,MR59nLE32xJ0dVSFKeZA68s = NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"ࠨ࡞ࡷࠫ௴")
	else: w0aE3Mzvb75ZJ1lfg8,MR59nLE32xJ0dVSFKeZA68s = HHvYL68lbJVZWM7tQEzSex3(u"ࠩ࡟ࡸࠬ௵"),NdKhAS6MXVEORLTwob92pxlZ
	vvzbYF2TjZmhdtrODVNoBs8WSxR = w0aE3Mzvb75ZJ1lfg8+QQHFtjcaR2VpnSyTIv(u"ࠪࡅࡺࡪࡩࡰ࠼ࠣ࡟ࠥ࠭௶")+c4chgEC9JvT2eLVtubfWiaNUXA7B[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡺࡸ࡬ࠨ௷")]+lRP6GTaZJA1Xw3egLM4(u"ࠬࠦ࡝࡝ࡰ࡟ࡸࡡࡺࠧ௸")+MR59nLE32xJ0dVSFKeZA68s+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭ࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ௹")+BdmYK3SkbqoLiN[kb2icmDGVUZfW1OFz7sv(u"ࠧࡶࡴ࡯ࠫ௺")]+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࠢࡠࠫ௻") if o5jZUyNPBV else w0aE3Mzvb75ZJ1lfg8+HVmIrFwau90jQsgiWzExk(u"ࠩࡄ࠯࡛ࡀࠠ࡜ࠢࠪ௼")+q5biGxDUYWKHIElhp+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠤࡢ࠭௽")
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(CSF2xtI1Yg5baHPJqZdOj9Ah,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Hlp3z0APt1GR4kMYK5xST(u"ࠫࡡࡺࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡶࡵࡩࡦࡳ࠺ࠡ࡝ࠣࠫ௾")+SSAftji8BdTODK0MICh3+HHvYL68lbJVZWM7tQEzSex3(u"ࠬࠦ࡝ࠡࠢࠣࠫ௿")+vvzbYF2TjZmhdtrODVNoBs8WSxR+R3lezw8h407ZvrAFxT(u"࠭ࠧఀ"))
	if not q5biGxDUYWKHIElhp: return hCm2fnEXs6Zt(u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧఁ"),[],[]
	return NdKhAS6MXVEORLTwob92pxlZ,[SSAftji8BdTODK0MICh3],[[q5biGxDUYWKHIElhp,k85kVbHKMXdrJOcFZ3,ImG7FH0jCdSgtc]]
def dRMvbBfZVFwHA0JGeOT2r1yiS(url):
	headers = { wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬం") : NdKhAS6MXVEORLTwob92pxlZ }
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡄࡒࡆ࠲࠷ࡳࡵࠩః"))
	items = YYqECUofyi7wFrW.findall(kb2icmDGVUZfW1OFz7sv(u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤࡿ࠭ࡡࢃࠧఄ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	items = set(items)
	items = sorted(items, reverse=k6apiPAlLKM1ed8J42RjHh0o, key=lambda key: key[cCRvAuJQfjBpTg0PbYiaNO87])
	QQgG862yiLenuYHlBO,IGEpKNCaiLMT,nnsGZ4jriVKNmpvAhFS70D1TCYtl,UTwH7zjZOrmFl = [],[],[],[]
	if not items: return hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡅࡓࡇ࠭అ"),[],[]
	for zehVcU893FC6LEd1Aij,gHbS3MaYo0j6uTdm2qyQnKP,TWqGAlsD0bpihcwOB3FLfYKMdxgC in items:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬఆ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡨࡵࡶࡳ࠾ࠬఇ"))
		if ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧ࠯࡯࠶ࡹ࠽࠭ఈ") in zehVcU893FC6LEd1Aij:
			QQgG862yiLenuYHlBO,nnsGZ4jriVKNmpvAhFS70D1TCYtl = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,zehVcU893FC6LEd1Aij)
			UTwH7zjZOrmFl = UTwH7zjZOrmFl + nnsGZ4jriVKNmpvAhFS70D1TCYtl
			if QQgG862yiLenuYHlBO[e8XhbyuzvjYkIsJUtB5w]==YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠯࠴ࠫఉ"): IGEpKNCaiLMT.append(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩึ๎ึ็ัࠡะสูࠬఊ")+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫఋ"))
			else:
				for title in QQgG862yiLenuYHlBO:
					IGEpKNCaiLMT.append(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ุࠫ๐ัโำࠣาฬ฻ࠧఌ")+H9cMF21gLJSv3tA5CPYXza+title)
		else:
			title = IlL8ZnX74Yvep(u"ู๊ࠬาใิࠤำอีࠨ఍")+R3lezw8h407ZvrAFxT(u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩఎ")+TWqGAlsD0bpihcwOB3FLfYKMdxgC
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			IGEpKNCaiLMT.append(title)
	return NdKhAS6MXVEORLTwob92pxlZ,IGEpKNCaiLMT,UTwH7zjZOrmFl
def C86scPnSqUQGH9Ybkau2ozF3JIfi(url,LMKFcEkU1Q7R80yt4OsgvwxbfP):
	UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp,P8RTh7Qr4mlxfEzBVesk0GvWuAJw3,iQ9bCrJLy8zUnXA1Hqk,oDhlaxn0EqyYikcHrmZBN8uv = [],[],[],[],[]
	if eGW7cI6aQhr0(u"ࠧࡴࡶࡵࠫఏ") not in str(type(LMKFcEkU1Q7R80yt4OsgvwxbfP)): LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.decode(YRvPKe2zMTDs8UCkr,lRP6GTaZJA1Xw3egLM4(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨఐ"))
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(lNTJCZeBicWEz0Mg(u"ࠩ࠿ࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ఑"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij and not atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]): zehVcU893FC6LEd1Aij = []
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩఒ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij and not atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]): zehVcU893FC6LEd1Aij = []
	if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪఓ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij and not atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]): zehVcU893FC6LEd1Aij = []
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[e8XhbyuzvjYkIsJUtB5w]
		title = zehVcU893FC6LEd1Aij.rsplit(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࠴ࠧఔ"),rNyT0edugn(u"࠱ങ"))[llxMLe4gobHhsj1WGvd7qmIU]
		UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(title)
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	else:
		sCRbZp6Irl17v = YYqECUofyi7wFrW.findall(ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬక"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not sCRbZp6Irl17v: sCRbZp6Irl17v = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠧࡷࡣࡵࠤࡸࡵࡵࡳࡥࡨࡷࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪఖ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not sCRbZp6Irl17v: sCRbZp6Irl17v = YYqECUofyi7wFrW.findall(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠨࡸࡤࡶࠥࡰࡷࠡ࠿ࠣࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮࠭గ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not sCRbZp6Irl17v: sCRbZp6Irl17v = YYqECUofyi7wFrW.findall(PzIpQnUXxRwNCivDhdakWTE(u"ࠩࡹࡥࡷࠦࡰ࡭ࡣࡼࡩࡷࠦ࠽ࠡ࠰࠭ࡃࡡ࠮ࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪ࡞ࠬࠫఘ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if sCRbZp6Irl17v:
			sCRbZp6Irl17v = sCRbZp6Irl17v[e8XhbyuzvjYkIsJUtB5w]
			sCRbZp6Irl17v = YYqECUofyi7wFrW.sub(R3lezw8h407ZvrAFxT(u"ࡵࠫ࠭ࡡ࡜ࡼ࡞࠯ࡡࡠࡢࡴ࡝ࡵ࡟ࡲࡡࡸ࡝ࠫࠫࠫࡠࡼ࠱࡛࡝ࡶ࡟ࡷࡢ࠰ࠩ࠻ࠩఙ"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࡶࠬࡢ࠱ࠣ࡞࠵ࠦ࠿࠭చ"),sCRbZp6Irl17v)
			sCRbZp6Irl17v = BdnA8WwtJeKUVvE(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡪࡩࡤࡶࠪఛ"),sCRbZp6Irl17v)
			if isinstance(sCRbZp6Irl17v,dict): sCRbZp6Irl17v = [sCRbZp6Irl17v]
			for AAMHoYxRCmt2D6ph89W in sCRbZp6Irl17v:
				gQhzY0f9o423,zehVcU893FC6LEd1Aij = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
				if isinstance(AAMHoYxRCmt2D6ph89W,dict):
					keys = list(AAMHoYxRCmt2D6ph89W.keys())
					if   NeU6uRGpECkvMV5jf(u"࠭ࡴࡺࡲࡨࠫజ") in keys: gQhzY0f9o423 = str(AAMHoYxRCmt2D6ph89W[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡵࡻࡳࡩࠬఝ")])
					if   rNyT0edugn(u"ࠨࡨ࡬ࡰࡪ࠭ఞ") in keys: zehVcU893FC6LEd1Aij = AAMHoYxRCmt2D6ph89W[rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠩࡩ࡭ࡱ࡫ࠧట")]
					elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࡬ࡱࡹࠧఠ") in keys: zehVcU893FC6LEd1Aij = AAMHoYxRCmt2D6ph89W[NeU6uRGpECkvMV5jf(u"ࠫ࡭ࡲࡳࠨడ")]
					elif IlL8ZnX74Yvep(u"ࠬࡹࡲࡤࠩఢ") in keys: zehVcU893FC6LEd1Aij = AAMHoYxRCmt2D6ph89W[rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࡳࡳࡥࠪణ")]
					if   QQHFtjcaR2VpnSyTIv(u"ࠧ࡭ࡣࡥࡩࡱ࠭త") in keys: title = str(AAMHoYxRCmt2D6ph89W[xY4icgQUj6mPVs73CTKu(u"ࠨ࡮ࡤࡦࡪࡲࠧథ")])
					elif HVmIrFwau90jQsgiWzExk(u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡪࡨ࡭࡬࡮ࡴࠨద") in keys: title = str(AAMHoYxRCmt2D6ph89W[OOkmZiVcfqlEurM1dHGb(u"ࠪࡺ࡮ࡪࡥࡰࡡ࡫ࡩ࡮࡭ࡨࡵࠩధ")])
					elif YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫ࠳࠭న") in zehVcU893FC6LEd1Aij: title = zehVcU893FC6LEd1Aij.rsplit(lNTJCZeBicWEz0Mg(u"ࠬ࠴ࠧ఩"),IlL8ZnX74Yvep(u"࠲ച"))[llxMLe4gobHhsj1WGvd7qmIU]
					else: title = zehVcU893FC6LEd1Aij
				elif isinstance(AAMHoYxRCmt2D6ph89W,str):
					zehVcU893FC6LEd1Aij = AAMHoYxRCmt2D6ph89W
					title = zehVcU893FC6LEd1Aij.rsplit(gniNItGL6bKwpEW(u"࠭࠮ࠨప"),vju3SZDWL4ENYelmBOzUqrogp2(u"࠳ഛ"))[llxMLe4gobHhsj1WGvd7qmIU]
				if llxMLe4gobHhsj1WGvd7qmIU:
					UpvYl7QkMBOTJIeSyCiH92GKfm56rn.append(title+Uv7MkgVGyEbAlfFP0S8Zjqp2J+gQhzY0f9o423)
					Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	for zehVcU893FC6LEd1Aij,title in zip(Pj8lY4doOfxiFMuNLhv3tnp,UpvYl7QkMBOTJIeSyCiH92GKfm56rn):
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧ࡝࡞࠲ࠫఫ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࠱ࠪబ"))
		oikt6P0hOAD5IvnlMpxf1 = msbTrJW03xuvA(url,xY4icgQUj6mPVs73CTKu(u"ࠩࡸࡶࡱ࠭భ"))
		VVBkbI2DtyaWw6mQp0 = kkCjlxiynwT34GVFc()
		if lRP6GTaZJA1Xw3egLM4(u"ࠪ࡬ࡹࡺࡰࠨమ") not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = oikt6P0hOAD5IvnlMpxf1+zehVcU893FC6LEd1Aij
		if V0VZk9763fusTReHFo4(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪయ") in zehVcU893FC6LEd1Aij:
			headers = {QQHFtjcaR2VpnSyTIv(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩర"):VVBkbI2DtyaWw6mQp0,YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧఱ"):oikt6P0hOAD5IvnlMpxf1}
			TdaSf2GBNzbXtJwEKq,rXcPIVwYM9nZStuLWKbCT = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,zehVcU893FC6LEd1Aij,headers)
			iQ9bCrJLy8zUnXA1Hqk += rXcPIVwYM9nZStuLWKbCT
			P8RTh7Qr4mlxfEzBVesk0GvWuAJw3 += TdaSf2GBNzbXtJwEKq
		else:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ల")+VVBkbI2DtyaWw6mQp0+fOc18oTm5hsdD4pVZQj(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫళ")+oikt6P0hOAD5IvnlMpxf1
			iQ9bCrJLy8zUnXA1Hqk.append(zehVcU893FC6LEd1Aij)
			P8RTh7Qr4mlxfEzBVesk0GvWuAJw3.append(title)
	BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = NdKhAS6MXVEORLTwob92pxlZ,[],[]
	if iQ9bCrJLy8zUnXA1Hqk: BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp = NdKhAS6MXVEORLTwob92pxlZ,P8RTh7Qr4mlxfEzBVesk0GvWuAJw3,iQ9bCrJLy8zUnXA1Hqk
	else:
		if lRP6GTaZJA1Xw3egLM4(u"ࠩ࠿ࠫఴ") not in LMKFcEkU1Q7R80yt4OsgvwxbfP and len(LMKFcEkU1Q7R80yt4OsgvwxbfP)<PzIpQnUXxRwNCivDhdakWTE(u"࠴࠴࠵ജ") and LMKFcEkU1Q7R80yt4OsgvwxbfP: BGulEd0o6ZQLzk5WHwMs2bN = LMKFcEkU1Q7R80yt4OsgvwxbfP
		else:
			msg = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠪࡀࡩ࡯ࡶࠡࡵࡷࡽࡱ࡫࠽ࠣ࠰࠭ࡃࠧࡄࠨࡇ࡫࡯ࡩ࠳࠰࠿ࠪ࠾ࠪవ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if not msg: msg = YYqECUofyi7wFrW.findall(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡹࡴࡤࡼࡩࡥࡧࡲࡣࡸࡺࡵࡣࡡࡷࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧశ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if not msg: msg = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠬࡂࡨ࠳ࡀࠫࡗࡴࡸࡲࡺ࠰࠭ࡃ࠮ࡂࠧష"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			if msg: BGulEd0o6ZQLzk5WHwMs2bN = msg[e8XhbyuzvjYkIsJUtB5w]
	return BGulEd0o6ZQLzk5WHwMs2bN,UpvYl7QkMBOTJIeSyCiH92GKfm56rn,Pj8lY4doOfxiFMuNLhv3tnp
def TLOnHcoQRM8(xfq1U58HajsdyJtAG,url):
	global kqow3KUzQJTrXh6AvmdRZCOep2
	url = url.strip(wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭࠯ࠨస"))
	Bl9VrUSa5mjWPhJcI3,YWsjNtDXPAgCya = NdKhAS6MXVEORLTwob92pxlZ,{}
	headers = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫహ"):kkCjlxiynwT34GVFc()}
	headers[V0VZk9763fusTReHFo4(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ఺")] = msbTrJW03xuvA(url,hCm2fnEXs6Zt(u"ࠩࡸࡶࡱ࠭఻"))
	headers[lRP6GTaZJA1Xw3egLM4(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩ఼ࠬ")] = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠽ࠬఽ")
	headers[PzIpQnUXxRwNCivDhdakWTE(u"࡙ࠬࡥࡤ࠯ࡉࡩࡹࡩࡨ࠮ࡆࡨࡷࡹ࠭ా")] = pnHgvFOCBZzc08yULQJGIqw9bf(u"࠭ࡩࡧࡴࡤࡱࡪ࠭ి")
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡈࡇࡗࠫీ"),url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪు"))
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	qa75ZG0PbshwDofBOmil8L = VNc1u4edS90FK5W6bsMgQC2B.code
	if not isinstance(LMKFcEkU1Q7R80yt4OsgvwxbfP,str): LMKFcEkU1Q7R80yt4OsgvwxbfP = LMKFcEkU1Q7R80yt4OsgvwxbfP.decode(YRvPKe2zMTDs8UCkr,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩూ"))
	if HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࠩృ") in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		cqzC1gA3uKNVyiXQ0mpZL = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯࡟ࡩࡸ࡝࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧౄ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if cqzC1gA3uKNVyiXQ0mpZL:
			try: Bl9VrUSa5mjWPhJcI3 = l4SxGUb2p8jysLXAgQITDPY0(cqzC1gA3uKNVyiXQ0mpZL[e8XhbyuzvjYkIsJUtB5w])
			except: Bl9VrUSa5mjWPhJcI3 = NdKhAS6MXVEORLTwob92pxlZ
	if LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠮࠭౅") in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		cqzC1gA3uKNVyiXQ0mpZL = YYqECUofyi7wFrW.findall(gniNItGL6bKwpEW(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪ࡫࠰ࡺ࠲࡮࠭ࡶ࠯ࡩ࠱ࡸ࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭ె"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if cqzC1gA3uKNVyiXQ0mpZL:
			try: Bl9VrUSa5mjWPhJcI3 = nadz1WI5ZUCSpYGJvNMAK(cqzC1gA3uKNVyiXQ0mpZL[e8XhbyuzvjYkIsJUtB5w])
			except: Bl9VrUSa5mjWPhJcI3 = NdKhAS6MXVEORLTwob92pxlZ
	HeFB5x2wED = LMKFcEkU1Q7R80yt4OsgvwxbfP+Bl9VrUSa5mjWPhJcI3
	if Tzx81Wb0RZC4ID5AyiU2(u"ࠧࠣ࡫ࡧ࠶ࠧ࠭ే") in HeFB5x2wED or kb2icmDGVUZfW1OFz7sv(u"ࠨࠤ࡬ࡨࠧ࠭ై") in HeFB5x2wED:
		wkJM1RecONrIf = url.split(HVmIrFwau90jQsgiWzExk(u"ࠩ࠲ࠫ౉"))[uL69vJOU7xN0hGnZf2islDqk].replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪࡩࡲࡨࡥࡥ࠯ࠪొ"),NdKhAS6MXVEORLTwob92pxlZ).replace(fOc18oTm5hsdD4pVZQj(u"ࠫ࠳࡮ࡴ࡮࡮ࠪో"),NdKhAS6MXVEORLTwob92pxlZ)
		if lNTJCZeBicWEz0Mg(u"ࠬࠨࡩࡥ࠴ࠥࠫౌ") in HeFB5x2wED: YWsjNtDXPAgCya = {wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡩࡥ࠴్ࠪ"):wkJM1RecONrIf,IlL8ZnX74Yvep(u"ࠧࡰࡲࠪ౎"):HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ౏")}
		elif pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࠥ࡭ࡩࠨࠧ౐") in HeFB5x2wED: YWsjNtDXPAgCya = {lrtFSogC8Nh9(u"ࠪ࡭ࡩ࠭౑"):wkJM1RecONrIf,HVmIrFwau90jQsgiWzExk(u"ࠫࡴࡶࠧ౒"):QQHFtjcaR2VpnSyTIv(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨ౓")}
		omrd89nv0PGKFpL3TxfAXt = headers.copy()
		omrd89nv0PGKFpL3TxfAXt[LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ౔")] = LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩౕ࠭")
		HYfNLiDK3yRF7 = cJaAB4uQyp(NXpO8DrVmeE,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࡒࡒࡗౖ࡙࠭"),url,YWsjNtDXPAgCya,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,fOc18oTm5hsdD4pVZQj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠳ࡰࡧࠫ౗"))
		HeFB5x2wED = HYfNLiDK3yRF7.content
	cIwh43gP05nHXBl1K9oM8,ipEmhNdUsvkfRoBuJ2MZnTqDLg,z1fyIlHgNd7D63 = C86scPnSqUQGH9Ybkau2ozF3JIfi(url,HeFB5x2wED)
	kqow3KUzQJTrXh6AvmdRZCOep2[xfq1U58HajsdyJtAG] = cIwh43gP05nHXBl1K9oM8,ipEmhNdUsvkfRoBuJ2MZnTqDLg,z1fyIlHgNd7D63,qa75ZG0PbshwDofBOmil8L
	return
kqow3KUzQJTrXh6AvmdRZCOep2,CCwVvHdm8yozTIkW4PKr9Sjx = {},e8XhbyuzvjYkIsJUtB5w
def fMPmhBIROjZLpE4nQckF8b16TJoC(url):
	global kqow3KUzQJTrXh6AvmdRZCOep2,CCwVvHdm8yozTIkW4PKr9Sjx
	oDhlaxn0EqyYikcHrmZBN8uv,threads = [],[]
	CCwVvHdm8yozTIkW4PKr9Sjx += NOrchaEV1iIZ87Uzlwgum(u"࠵࠵࠶ഝ")
	W1ZlXh8PjVK = CCwVvHdm8yozTIkW4PKr9Sjx
	oDhlaxn0EqyYikcHrmZBN8uv.append([llxMLe4gobHhsj1WGvd7qmIU,url])
	kqow3KUzQJTrXh6AvmdRZCOep2[W1ZlXh8PjVK+llxMLe4gobHhsj1WGvd7qmIU] = [None,None,None,None]
	Z3XSP7aOuz = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=TLOnHcoQRM8,args=(W1ZlXh8PjVK+llxMLe4gobHhsj1WGvd7qmIU,url))
	Z3XSP7aOuz.start()
	Z3XSP7aOuz.join(eGW7cI6aQhr0(u"࠶࠶ഞ"))
	if not kqow3KUzQJTrXh6AvmdRZCOep2[W1ZlXh8PjVK+rNyT0edugn(u"࠷ട")][cCRvAuJQfjBpTg0PbYiaNO87]:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫౘ"),rNyT0edugn(u"ࠫ࠴࠭ౙ"))
		BDkTn4JaU3HsYzI = YYqECUofyi7wFrW.findall(hCm2fnEXs6Zt(u"ࠬࡤࠨ࠯ࠬࡂ࠾࠴࠵࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪࠦࠪౚ"),BfjcMoqOsmdUvZVCHWIyQKi+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠭࠯ࠨ౛"),YYqECUofyi7wFrW.DOTALL)
		start,sqQOBXemjlz,end = BDkTn4JaU3HsYzI[e8XhbyuzvjYkIsJUtB5w]
		end = end.strip(fOc18oTm5hsdD4pVZQj(u"ࠧ࠰ࠩ౜"))
		SpFqy2xd60behLHiRA = len(sqQOBXemjlz)<TQNS6YMKAqnilsVObLpDRX or sqQOBXemjlz in [QQHFtjcaR2VpnSyTIv(u"ࠨࡨ࡬ࡰࡪ࠭ౝ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ౞"),HVmIrFwau90jQsgiWzExk(u"ࠪࡺ࡮ࡪࡥࡰࡧࡰࡦࡪࡪࠧ౟"),kb2icmDGVUZfW1OFz7sv(u"ࠫࡦࡰࡡࡹࠩౠ"),hCm2fnEXs6Zt(u"ࠬ࡯ࡦࡳࡣࡰࡩࠬౡ"),lNTJCZeBicWEz0Mg(u"࠭࡭ࡪࡴࡵࡳࡷ࠭ౢ")]
		if not SpFqy2xd60behLHiRA: oDhlaxn0EqyYikcHrmZBN8uv.append([cCRvAuJQfjBpTg0PbYiaNO87,start+NeU6uRGpECkvMV5jf(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨౣ")+sqQOBXemjlz+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ࠱ࠪ౤")+end])
		if end: oDhlaxn0EqyYikcHrmZBN8uv.append([uL69vJOU7xN0hGnZf2islDqk,start+NOrchaEV1iIZ87Uzlwgum(u"ࠩ࠲ࠫ౥")+sqQOBXemjlz+lrtFSogC8Nh9(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ౦")+end])
		if OOkmZiVcfqlEurM1dHGb(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ౧") in sqQOBXemjlz:
			v0vTWtsedL98DjKBAZXf2 = sqQOBXemjlz.replace(lRP6GTaZJA1Xw3egLM4(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ౨"),NdKhAS6MXVEORLTwob92pxlZ)
			oDhlaxn0EqyYikcHrmZBN8uv.append([TQNS6YMKAqnilsVObLpDRX,start+vju3SZDWL4ENYelmBOzUqrogp2(u"࠭࠯ࠨ౩")+v0vTWtsedL98DjKBAZXf2+PzIpQnUXxRwNCivDhdakWTE(u"ࠧ࠰ࠩ౪")+end])
			oDhlaxn0EqyYikcHrmZBN8uv.append([lNTJCZeBicWEz0Mg(u"࠵ഠ"),start+HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ౫")+v0vTWtsedL98DjKBAZXf2+xY4icgQUj6mPVs73CTKu(u"ࠩ࠲ࠫ౬")+end])
			if end: oDhlaxn0EqyYikcHrmZBN8uv.append([IlL8ZnX74Yvep(u"࠷ഡ"),start+gniNItGL6bKwpEW(u"ࠪ࠳ࠬ౭")+v0vTWtsedL98DjKBAZXf2+kb2icmDGVUZfW1OFz7sv(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ౮")+end])
		elif hCm2fnEXs6Zt(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ౯") in end:
			rtTb2dNoqEuexX4MY6aI = end.replace(R3lezw8h407ZvrAFxT(u"࠭࠮ࡩࡶࡰࡰࠬ౰"),NdKhAS6MXVEORLTwob92pxlZ)
			oDhlaxn0EqyYikcHrmZBN8uv.append([WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠹ഢ"),start+Hlp3z0APt1GR4kMYK5xST(u"ࠧ࠰ࠩ౱")+sqQOBXemjlz+OOkmZiVcfqlEurM1dHGb(u"ࠨ࠱ࠪ౲")+rtTb2dNoqEuexX4MY6aI])
			if not SpFqy2xd60behLHiRA: oDhlaxn0EqyYikcHrmZBN8uv.append([JGwsL21ZRlqSrWxEmF(u"࠻ണ"),start+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ౳")+sqQOBXemjlz+JGwsL21ZRlqSrWxEmF(u"ࠪ࠳ࠬ౴")+rtTb2dNoqEuexX4MY6aI])
			oDhlaxn0EqyYikcHrmZBN8uv.append([WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠽ത"),start+eGW7cI6aQhr0(u"ࠫ࠴࠭౵")+sqQOBXemjlz+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭౶")+rtTb2dNoqEuexX4MY6aI])
		else:
			if not SpFqy2xd60behLHiRA: oDhlaxn0EqyYikcHrmZBN8uv.append([kb2icmDGVUZfW1OFz7sv(u"࠶࠶ഥ"),start+Tzx81Wb0RZC4ID5AyiU2(u"࠭࠯ࠨ౷")+sqQOBXemjlz+R3lezw8h407ZvrAFxT(u"ࠧ࠯ࡪࡷࡱࡱ࠭౸")])
			if not SpFqy2xd60behLHiRA: oDhlaxn0EqyYikcHrmZBN8uv.append([kb2icmDGVUZfW1OFz7sv(u"࠷࠱ദ"),start+NeU6uRGpECkvMV5jf(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ౹")+sqQOBXemjlz+HVmIrFwau90jQsgiWzExk(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ౺")])
			if end: oDhlaxn0EqyYikcHrmZBN8uv.append([JGwsL21ZRlqSrWxEmF(u"࠱࠳ധ"),start+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪ࠳ࠬ౻")+sqQOBXemjlz+rNyT0edugn(u"ࠫ࠴࠭౼")+end+gniNItGL6bKwpEW(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ౽")])
			if end: oDhlaxn0EqyYikcHrmZBN8uv.append([kb2icmDGVUZfW1OFz7sv(u"࠲࠵ന"),start+gniNItGL6bKwpEW(u"࠭࠯ࠨ౾")+sqQOBXemjlz+eGW7cI6aQhr0(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ౿")+end+lNTJCZeBicWEz0Mg(u"ࠨ࠰࡫ࡸࡲࡲࠧಀ")])
		if SpFqy2xd60behLHiRA and end:
			end = end.replace(NOrchaEV1iIZ87Uzlwgum(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪಁ"),xY4icgQUj6mPVs73CTKu(u"ࠪ࠳ࠬಂ"))
			oDhlaxn0EqyYikcHrmZBN8uv.append([NeU6uRGpECkvMV5jf(u"࠳࠷ഩ"),start+Hlp3z0APt1GR4kMYK5xST(u"ࠫ࠴࠭ಃ")+end])
			oDhlaxn0EqyYikcHrmZBN8uv.append([IlL8ZnX74Yvep(u"࠴࠹പ"),start+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭಄")+end])
			if QQHFtjcaR2VpnSyTIv(u"࠭࠮ࡩࡶࡰࡰࠬಅ") in end:
				rtTb2dNoqEuexX4MY6aI = end.replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠧ࠯ࡪࡷࡱࡱ࠭ಆ"),NdKhAS6MXVEORLTwob92pxlZ)
				oDhlaxn0EqyYikcHrmZBN8uv.append([hCm2fnEXs6Zt(u"࠵࠻ഫ"),start+NOrchaEV1iIZ87Uzlwgum(u"ࠨ࠱ࠪಇ")+rtTb2dNoqEuexX4MY6aI])
				oDhlaxn0EqyYikcHrmZBN8uv.append([HHvYL68lbJVZWM7tQEzSex3(u"࠶࠽ബ"),start+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪಈ")+rtTb2dNoqEuexX4MY6aI])
			else:
				oDhlaxn0EqyYikcHrmZBN8uv.append([lRP6GTaZJA1Xw3egLM4(u"࠷࠸ഭ"),start+HHvYL68lbJVZWM7tQEzSex3(u"ࠪ࠳ࠬಉ")+end+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫ࠳࡮ࡴ࡮࡮ࠪಊ")])
				oDhlaxn0EqyYikcHrmZBN8uv.append([IlL8ZnX74Yvep(u"࠱࠺മ"),start+JGwsL21ZRlqSrWxEmF(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ಋ")+end+JGwsL21ZRlqSrWxEmF(u"࠭࠮ࡩࡶࡰࡰࠬಌ")])
		xnEw2XGHUi9O8zZ0Y4lIva7jFmdK6B = []
		for f1BA08uJ2nePQcdCHRqNEZKoGM,zehVcU893FC6LEd1Aij in oDhlaxn0EqyYikcHrmZBN8uv[llxMLe4gobHhsj1WGvd7qmIU:]:
			kqow3KUzQJTrXh6AvmdRZCOep2[W1ZlXh8PjVK+f1BA08uJ2nePQcdCHRqNEZKoGM] = [None,None,None,None]
			Iy53FOE1XKaPN6d = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=TLOnHcoQRM8,args=(W1ZlXh8PjVK+f1BA08uJ2nePQcdCHRqNEZKoGM,zehVcU893FC6LEd1Aij))
			Iy53FOE1XKaPN6d.start()
			xnEw2XGHUi9O8zZ0Y4lIva7jFmdK6B.append(Iy53FOE1XKaPN6d)
			XJ62UBRmIqFvfiNTQj.sleep(lNTJCZeBicWEz0Mg(u"࠱࠰࠺࠹യ"))
		for Iy53FOE1XKaPN6d in xnEw2XGHUi9O8zZ0Y4lIva7jFmdK6B: Iy53FOE1XKaPN6d.join(fOc18oTm5hsdD4pVZQj(u"࠳࠳ര"))
	BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl = NdKhAS6MXVEORLTwob92pxlZ,[],[]
	vtYwiBHLkl = []
	for f1BA08uJ2nePQcdCHRqNEZKoGM,zehVcU893FC6LEd1Aij in oDhlaxn0EqyYikcHrmZBN8uv:
		nyYB7WfJb8EwM,zokIcZxy9H7wiM,uupITli4wLS,NRCf6swHYMxK94lzey = kqow3KUzQJTrXh6AvmdRZCOep2[W1ZlXh8PjVK+f1BA08uJ2nePQcdCHRqNEZKoGM]
		if not UTwH7zjZOrmFl and uupITli4wLS: IGEpKNCaiLMT,UTwH7zjZOrmFl = zokIcZxy9H7wiM,uupITli4wLS
		if not BGulEd0o6ZQLzk5WHwMs2bN and nyYB7WfJb8EwM: BGulEd0o6ZQLzk5WHwMs2bN = nyYB7WfJb8EwM
		if NRCf6swHYMxK94lzey: vtYwiBHLkl.append(NRCf6swHYMxK94lzey)
	vtYwiBHLkl = list(set(vtYwiBHLkl))
	if not BGulEd0o6ZQLzk5WHwMs2bN and len(vtYwiBHLkl)==R3lezw8h407ZvrAFxT(u"࠴റ"):
		qa75ZG0PbshwDofBOmil8L = vtYwiBHLkl[e8XhbyuzvjYkIsJUtB5w]
		if qa75ZG0PbshwDofBOmil8L!=wP4kpvXoDHq3hs7TFLyr2COn8(u"࠶࠵࠶ല"):
			if qa75ZG0PbshwDofBOmil8L<e8XhbyuzvjYkIsJUtB5w: BGulEd0o6ZQLzk5WHwMs2bN = lNTJCZeBicWEz0Mg(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰࡢࡩࡨ࠳ࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࡩࡣࡦࡵࡶ࡭ࡧࡲࡥࠨ಍")
			else:
				BGulEd0o6ZQLzk5WHwMs2bN = hCm2fnEXs6Zt(u"ࠨࡊࡗࡘࡕࠦࡅࡳࡴࡲࡶ࠿ࠦࠧಎ")+str(qa75ZG0PbshwDofBOmil8L)
				if J92gCnbGWidQV70lBteTwU6D8uyzL: import http.client as IFeCZk4lmgHPDB2Lf
				else: import httplib as IFeCZk4lmgHPDB2Lf
				try: BGulEd0o6ZQLzk5WHwMs2bN += Tzx81Wb0RZC4ID5AyiU2(u"ࠩࠣࠬࠥ࠭ಏ")+IFeCZk4lmgHPDB2Lf.responses[qa75ZG0PbshwDofBOmil8L]+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠪࠤ࠮࠭ಐ")
				except: pass
	XJ62UBRmIqFvfiNTQj.sleep(llxMLe4gobHhsj1WGvd7qmIU)
	return BGulEd0o6ZQLzk5WHwMs2bN,IGEpKNCaiLMT,UTwH7zjZOrmFl
class ql2ru1NZiv3BepLz(JTIdpcz98k7RyxHOX5EnqD6L1vKe04.WindowDialog):
	def __init__(gXxGoMb8p6aWPL9eIj7fn34Z, *args, **A3en9HdIOQJ):
		REMWyqSOnp4T5rvNUZ0BIdu72YH = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g, NeU6uRGpECkvMV5jf(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ಑"), xY4icgQUj6mPVs73CTKu(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩಒ"), fOc18oTm5hsdD4pVZQj(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡨࡧ࠯ࡲࡱ࡫ࠬಓ"))
		B4mqWvGMLHpKPtiQ2EUsjRxO = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g, hCm2fnEXs6Zt(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪಔ"), HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬಕ"), gniNItGL6bKwpEW(u"ࠩࡶࡩࡱ࡫ࡣࡵࡧࡧ࠲ࡵࡴࡧࠨಖ"))
		tzs5Ph9xN12QVG = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g, JGwsL21ZRlqSrWxEmF(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ಗ"), YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨಘ"), YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬࡨࡵࡵࡶࡲࡲ࡫ࡵ࠮ࡱࡰࡪࠫಙ"))
		bbEogpize6f1WD0BysNC49J = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g, HVmIrFwau90jQsgiWzExk(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩಚ"), xY4icgQUj6mPVs73CTKu(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫಛ"), gniNItGL6bKwpEW(u"ࠨࡤࡸࡸࡹࡵ࡮࡯ࡨ࠱ࡴࡳ࡭ࠧಜ"))
		ptCaAruPFOfliWK = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(VAzvLnYQrdktx75g, Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬಝ"), rNyT0edugn(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧಞ"), R3lezw8h407ZvrAFxT(u"ࠫࡧࡻࡴࡵࡱࡱࡦ࡬࠴ࡰ࡯ࡩࠪಟ"))
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelled = f4vncKMRlXG9s
		gXxGoMb8p6aWPL9eIj7fn34Z.chk = [e8XhbyuzvjYkIsJUtB5w] * pnHgvFOCBZzc08yULQJGIqw9bf(u"࠾ള")
		gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton = [e8XhbyuzvjYkIsJUtB5w] * pnHgvFOCBZzc08yULQJGIqw9bf(u"࠿ഴ")
		gXxGoMb8p6aWPL9eIj7fn34Z.chkstate = [f4vncKMRlXG9s] * OOkmZiVcfqlEurM1dHGb(u"࠹വ")
		zrc3eEq1LOgQa7ZU, aiYTfwoh4E6AFJtNumn5Ij, HSiXzvIK91amuQ, lwcyEPoZVhWg64snm987C0Lb5ixKSe = NeU6uRGpECkvMV5jf(u"࠳࠷࠳ശ"), e8XhbyuzvjYkIsJUtB5w, IlL8ZnX74Yvep(u"࠹࠳࠴ഷ"), IlL8ZnX74Yvep(u"࠺࠺࠵സ")
		BsQWfnENJDyzGqtg = zrc3eEq1LOgQa7ZU+HSiXzvIK91amuQ//cCRvAuJQfjBpTg0PbYiaNO87
		OS3ZVlWctvm5, xx2BdHMGP7, V9tXPiN0DuWO8TBw7g13obSrQc2df, T1D2vi3tClHeEyg = NOrchaEV1iIZ87Uzlwgum(u"࠸࠻࠵ഺ"), ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵࠷࠶ഹ"), IlL8ZnX74Yvep(u"࠻࠰࠱഻"), IlL8ZnX74Yvep(u"࠻࠰࠱഻")
		pz9REGmFsd04QJPCIr3X6koeVHWfU = OS3ZVlWctvm5+V9tXPiN0DuWO8TBw7g13obSrQc2df//cCRvAuJQfjBpTg0PbYiaNO87
		lWgYMuDE7zf, qqIFBzWEtdD, t4qvLPAXfQbxN07nVmzHZ, PR7l9zW5NIHnM = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠲࠲࠳ഽ"), rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠸࠸࠹ാ"), pnHgvFOCBZzc08yULQJGIqw9bf(u"࠱࠶࠲഼"), eGW7cI6aQhr0(u"࠸࠴ി")
		EVay39RQu1cDq = BsQWfnENJDyzGqtg-t4qvLPAXfQbxN07nVmzHZ-lWgYMuDE7zf//cCRvAuJQfjBpTg0PbYiaNO87
		RRitLZsxdmu1AXJGj6fWM = BsQWfnENJDyzGqtg+lWgYMuDE7zf//cCRvAuJQfjBpTg0PbYiaNO87
		drIXWt8A9MhcfejaKZoPFpn, j9ePcVin27Yghso64, T5tN3HxAFGZfMj4uaO9om, JzKDLGbPjARkdWHev7fTm9YUXx = lrtFSogC8Nh9(u"࠷࠺࠻ീ"), lRP6GTaZJA1Xw3egLM4(u"࠸࠶ു"), HVmIrFwau90jQsgiWzExk(u"࠵࠱࠲ൃ"), lrtFSogC8Nh9(u"࠻࠰ൂ")
		IAjub4O0EGtqWc9XsamSCBMoLz, eKq179EWHX6bAMCOmdYF, rGtdBfCqmShkUej9, a8xvNUO73bw1SeK = HVmIrFwau90jQsgiWzExk(u"࠴࠷࠸ൄ"), LtGoXlQ2IYxqTJRySE6udfW98(u"࠻࠵േ"), V0VZk9763fusTReHFo4(u"࠸࠴࠵െ"), lRP6GTaZJA1Xw3egLM4(u"࠷࠳൅")
		dQDRs3SUMLYlogb = vju3SZDWL4ENYelmBOzUqrogp2(u"࠵࠴࠹ൈ")
		zrc3eEq1LOgQa7ZU, aiYTfwoh4E6AFJtNumn5Ij, HSiXzvIK91amuQ, lwcyEPoZVhWg64snm987C0Lb5ixKSe = int(zrc3eEq1LOgQa7ZU*dQDRs3SUMLYlogb), int(aiYTfwoh4E6AFJtNumn5Ij*dQDRs3SUMLYlogb), int(HSiXzvIK91amuQ*dQDRs3SUMLYlogb), int(lwcyEPoZVhWg64snm987C0Lb5ixKSe*dQDRs3SUMLYlogb)
		OS3ZVlWctvm5, xx2BdHMGP7, V9tXPiN0DuWO8TBw7g13obSrQc2df, T1D2vi3tClHeEyg = int(OS3ZVlWctvm5*dQDRs3SUMLYlogb), int(xx2BdHMGP7*dQDRs3SUMLYlogb), int(V9tXPiN0DuWO8TBw7g13obSrQc2df*dQDRs3SUMLYlogb), int(T1D2vi3tClHeEyg*dQDRs3SUMLYlogb)
		EVay39RQu1cDq, FK1k3nxOWEJHyiRVAw, ABIuWsqTcUwyK7fYEZLaXROi, aaRrSexKzqL = int(EVay39RQu1cDq*dQDRs3SUMLYlogb), int(qqIFBzWEtdD*dQDRs3SUMLYlogb), int(t4qvLPAXfQbxN07nVmzHZ*dQDRs3SUMLYlogb), int(PR7l9zW5NIHnM*dQDRs3SUMLYlogb)
		RRitLZsxdmu1AXJGj6fWM, LOVfbqdNM6rAsuFC, TTm7z9EtQfceapInWLG, KYz7H2ROQbj9uIcnaPVNJyB = int(RRitLZsxdmu1AXJGj6fWM*dQDRs3SUMLYlogb), int(qqIFBzWEtdD*dQDRs3SUMLYlogb), int(t4qvLPAXfQbxN07nVmzHZ*dQDRs3SUMLYlogb), int(PR7l9zW5NIHnM*dQDRs3SUMLYlogb)
		drIXWt8A9MhcfejaKZoPFpn, j9ePcVin27Yghso64, T5tN3HxAFGZfMj4uaO9om, JzKDLGbPjARkdWHev7fTm9YUXx = int(drIXWt8A9MhcfejaKZoPFpn*dQDRs3SUMLYlogb), int(j9ePcVin27Yghso64*dQDRs3SUMLYlogb), int(T5tN3HxAFGZfMj4uaO9om*dQDRs3SUMLYlogb), int(JzKDLGbPjARkdWHev7fTm9YUXx*dQDRs3SUMLYlogb)
		IAjub4O0EGtqWc9XsamSCBMoLz, eKq179EWHX6bAMCOmdYF, rGtdBfCqmShkUej9, a8xvNUO73bw1SeK = int(IAjub4O0EGtqWc9XsamSCBMoLz*dQDRs3SUMLYlogb), int(eKq179EWHX6bAMCOmdYF*dQDRs3SUMLYlogb), int(rGtdBfCqmShkUej9*dQDRs3SUMLYlogb), int(a8xvNUO73bw1SeK*dQDRs3SUMLYlogb)
		hhekIRQ0ucBAobxKTHLwMD = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlImage(zrc3eEq1LOgQa7ZU, aiYTfwoh4E6AFJtNumn5Ij, HSiXzvIK91amuQ, lwcyEPoZVhWg64snm987C0Lb5ixKSe, REMWyqSOnp4T5rvNUZ0BIdu72YH)
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(hhekIRQ0ucBAobxKTHLwMD)
		gXxGoMb8p6aWPL9eIj7fn34Z.iteration = A3en9HdIOQJ.get(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬ࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࠨಠ"))
		XXQDOZqLsivj8VwaR = D7INg5kyRjwf4ZtoePVUrb1h2SJ+lrtFSogC8Nh9(u"࠭แฮืࠣว๋อࠠฦ่ึห๋่ࠦๅีอࠤึ๎ศ้ฬࠣࠤࠥࠦࠠࠡࠢࠣࠤࠬಡ")+xY4icgQUj6mPVs73CTKu(u"ࠧศๆ่ัฬ๎ไสࠢิๆ๊ࠦࠠࠨಢ")+str(gXxGoMb8p6aWPL9eIj7fn34Z.iteration)+kjd9LyNqQHMUevZiRI7OlBGF1h
		gXxGoMb8p6aWPL9eIj7fn34Z.strActionInfo = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlLabel(drIXWt8A9MhcfejaKZoPFpn, j9ePcVin27Yghso64, T5tN3HxAFGZfMj4uaO9om, JzKDLGbPjARkdWHev7fTm9YUXx, XXQDOZqLsivj8VwaR, eGW7cI6aQhr0(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨಣ"))
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.strActionInfo)
		TTuPH708dUNnjlG3oQpkZsi = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlImage(OS3ZVlWctvm5, xx2BdHMGP7, V9tXPiN0DuWO8TBw7g13obSrQc2df, T1D2vi3tClHeEyg, A3en9HdIOQJ.get(lrtFSogC8Nh9(u"ࠩࡦࡥࡵࡺࡣࡩࡣࠪತ")))
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(TTuPH708dUNnjlG3oQpkZsi)
		d8XVUp9gtI3M = D7INg5kyRjwf4ZtoePVUrb1h2SJ+A3en9HdIOQJ.get(HHvYL68lbJVZWM7tQEzSex3(u"ࠪࡱࡸ࡭ࠧಥ"))+kjd9LyNqQHMUevZiRI7OlBGF1h
		gXxGoMb8p6aWPL9eIj7fn34Z.strActionInfo = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlLabel(IAjub4O0EGtqWc9XsamSCBMoLz, eKq179EWHX6bAMCOmdYF, rGtdBfCqmShkUej9, a8xvNUO73bw1SeK, d8XVUp9gtI3M, gniNItGL6bKwpEW(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫದ"))
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.strActionInfo)
		text = D7INg5kyRjwf4ZtoePVUrb1h2SJ+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬิั้ฮࠪಧ")+kjd9LyNqQHMUevZiRI7OlBGF1h
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlButton(EVay39RQu1cDq, FK1k3nxOWEJHyiRVAw, ABIuWsqTcUwyK7fYEZLaXROi, aaRrSexKzqL, text, focusTexture=ptCaAruPFOfliWK, noFocusTexture=tzs5Ph9xN12QVG, alignment=pnHgvFOCBZzc08yULQJGIqw9bf(u"࠸൉"))
		text = D7INg5kyRjwf4ZtoePVUrb1h2SJ+rNyT0edugn(u"࠭วิฬ่ีฬืࠧನ")+kjd9LyNqQHMUevZiRI7OlBGF1h
		gXxGoMb8p6aWPL9eIj7fn34Z.okbutton = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlButton(RRitLZsxdmu1AXJGj6fWM, LOVfbqdNM6rAsuFC, TTm7z9EtQfceapInWLG, KYz7H2ROQbj9uIcnaPVNJyB, text, focusTexture=ptCaAruPFOfliWK, noFocusTexture=tzs5Ph9xN12QVG, alignment=JGwsL21ZRlqSrWxEmF(u"࠲ൊ"))
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
		gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton)
		Hte8fmp52V, w1EGsSvaLVo4IlAejDf = T1D2vi3tClHeEyg//uL69vJOU7xN0hGnZf2islDqk, V9tXPiN0DuWO8TBw7g13obSrQc2df//uL69vJOU7xN0hGnZf2islDqk
		for xX6zt5oS08TO29CUhYJa1K in range(vju3SZDWL4ENYelmBOzUqrogp2(u"࠺ോ")):
			WDVyXGbvCrgaTN1xo = xX6zt5oS08TO29CUhYJa1K // uL69vJOU7xN0hGnZf2islDqk
			k6f7Y2Nxqw9M = xX6zt5oS08TO29CUhYJa1K % uL69vJOU7xN0hGnZf2islDqk
			hP76Bs8teS2XNOpygd1wQq = OS3ZVlWctvm5 + (w1EGsSvaLVo4IlAejDf * k6f7Y2Nxqw9M)
			ZnNTYfKvL1R37bB2G = xx2BdHMGP7 + (Hte8fmp52V * WDVyXGbvCrgaTN1xo)
			gXxGoMb8p6aWPL9eIj7fn34Z.chk[xX6zt5oS08TO29CUhYJa1K] = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlImage(hP76Bs8teS2XNOpygd1wQq, ZnNTYfKvL1R37bB2G, w1EGsSvaLVo4IlAejDf, Hte8fmp52V, B4mqWvGMLHpKPtiQ2EUsjRxO)
			gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.chk[xX6zt5oS08TO29CUhYJa1K])
			gXxGoMb8p6aWPL9eIj7fn34Z.chk[xX6zt5oS08TO29CUhYJa1K].setVisible(f4vncKMRlXG9s)
			gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K] = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.ControlButton(hP76Bs8teS2XNOpygd1wQq, ZnNTYfKvL1R37bB2G, w1EGsSvaLVo4IlAejDf, Hte8fmp52V, str(xX6zt5oS08TO29CUhYJa1K + llxMLe4gobHhsj1WGvd7qmIU), font=NOrchaEV1iIZ87Uzlwgum(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧ಩"), focusTexture=tzs5Ph9xN12QVG, noFocusTexture=bbEogpize6f1WD0BysNC49J)
			gXxGoMb8p6aWPL9eIj7fn34Z.addControl(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K])
		for xX6zt5oS08TO29CUhYJa1K in range(R3lezw8h407ZvrAFxT(u"࠻ൌ")):
			InMU0dkmqaveF6f1VhQwABEc = (xX6zt5oS08TO29CUhYJa1K // uL69vJOU7xN0hGnZf2islDqk) * uL69vJOU7xN0hGnZf2islDqk
			D0R56N4LehfB = InMU0dkmqaveF6f1VhQwABEc + (xX6zt5oS08TO29CUhYJa1K + llxMLe4gobHhsj1WGvd7qmIU) % uL69vJOU7xN0hGnZf2islDqk
			hh1JbeinqAV0ZO8NI9dLcUr = InMU0dkmqaveF6f1VhQwABEc + (xX6zt5oS08TO29CUhYJa1K - llxMLe4gobHhsj1WGvd7qmIU) % uL69vJOU7xN0hGnZf2islDqk
			rnABy3QsjR2NEpcWSuXkl95bq4o = (xX6zt5oS08TO29CUhYJa1K - uL69vJOU7xN0hGnZf2islDqk) % hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠼്")
			AIXDFYNzwJ6K7QvcT1jr = (xX6zt5oS08TO29CUhYJa1K + uL69vJOU7xN0hGnZf2islDqk) % fOc18oTm5hsdD4pVZQj(u"࠽ൎ")
			gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlRight(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[D0R56N4LehfB])
			gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlLeft(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[hh1JbeinqAV0ZO8NI9dLcUr])
			if xX6zt5oS08TO29CUhYJa1K <= cCRvAuJQfjBpTg0PbYiaNO87:
				gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlUp(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
			else:
				gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlUp(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[rnABy3QsjR2NEpcWSuXkl95bq4o])
			if xX6zt5oS08TO29CUhYJa1K >= kb2icmDGVUZfW1OFz7sv(u"࠻൏"):
				gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlDown(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
			else:
				gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[xX6zt5oS08TO29CUhYJa1K].controlDown(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[AIXDFYNzwJ6K7QvcT1jr])
		gXxGoMb8p6aWPL9eIj7fn34Z.okbutton.controlLeft(gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton)
		gXxGoMb8p6aWPL9eIj7fn34Z.okbutton.controlRight(gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton)
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton.controlLeft(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton.controlRight(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
		gXxGoMb8p6aWPL9eIj7fn34Z.okbutton.controlDown(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[cCRvAuJQfjBpTg0PbYiaNO87])
		gXxGoMb8p6aWPL9eIj7fn34Z.okbutton.controlUp(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[JGwsL21ZRlqSrWxEmF(u"࠾൐")])
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton.controlDown(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[e8XhbyuzvjYkIsJUtB5w])
		gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton.controlUp(gXxGoMb8p6aWPL9eIj7fn34Z.chkbutton[OOkmZiVcfqlEurM1dHGb(u"࠶൑")])
		gXxGoMb8p6aWPL9eIj7fn34Z.setFocus(gXxGoMb8p6aWPL9eIj7fn34Z.okbutton)
	def get(gXxGoMb8p6aWPL9eIj7fn34Z):
		gXxGoMb8p6aWPL9eIj7fn34Z.doModal()
		gXxGoMb8p6aWPL9eIj7fn34Z.close()
		if not gXxGoMb8p6aWPL9eIj7fn34Z.cancelled:
			return [xX6zt5oS08TO29CUhYJa1K for xX6zt5oS08TO29CUhYJa1K in range(JGwsL21ZRlqSrWxEmF(u"࠺൒")) if gXxGoMb8p6aWPL9eIj7fn34Z.chkstate[xX6zt5oS08TO29CUhYJa1K]]
	def onControl(gXxGoMb8p6aWPL9eIj7fn34Z, QTJdLGEbVeFZWOUuwDhKia5q7P0):
		if QTJdLGEbVeFZWOUuwDhKia5q7P0.getId() == gXxGoMb8p6aWPL9eIj7fn34Z.okbutton.getId() and any(gXxGoMb8p6aWPL9eIj7fn34Z.chkstate):
			gXxGoMb8p6aWPL9eIj7fn34Z.close()
		elif QTJdLGEbVeFZWOUuwDhKia5q7P0.getId() == gXxGoMb8p6aWPL9eIj7fn34Z.cancelbutton.getId():
			gXxGoMb8p6aWPL9eIj7fn34Z.cancelled = k6apiPAlLKM1ed8J42RjHh0o
			gXxGoMb8p6aWPL9eIj7fn34Z.close()
		else:
			TWqGAlsD0bpihcwOB3FLfYKMdxgC = QTJdLGEbVeFZWOUuwDhKia5q7P0.getLabel()
			if TWqGAlsD0bpihcwOB3FLfYKMdxgC.isnumeric():
				index = int(TWqGAlsD0bpihcwOB3FLfYKMdxgC) - llxMLe4gobHhsj1WGvd7qmIU
				gXxGoMb8p6aWPL9eIj7fn34Z.chkstate[index] = not gXxGoMb8p6aWPL9eIj7fn34Z.chkstate[index]
				gXxGoMb8p6aWPL9eIj7fn34Z.chk[index].setVisible(gXxGoMb8p6aWPL9eIj7fn34Z.chkstate[index])
	def onAction(gXxGoMb8p6aWPL9eIj7fn34Z, J2bWNij3HmU1R9P5ItnxXBd7pSZA):
		if J2bWNij3HmU1R9P5ItnxXBd7pSZA == vju3SZDWL4ENYelmBOzUqrogp2(u"࠳࠳൓"):
			gXxGoMb8p6aWPL9eIj7fn34Z.cancelled = k6apiPAlLKM1ed8J42RjHh0o
			gXxGoMb8p6aWPL9eIj7fn34Z.close()
def zW4UEsR59mvrA1tGhSq(key,lzWinvL53T2D0cGawRBPqm9FMAU7kQ,url):
	headers = {ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩಪ"):url,HHvYL68lbJVZWM7tQEzSex3(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫಫ"):lzWinvL53T2D0cGawRBPqm9FMAU7kQ}
	ylOgAQwbRHuvFdkK3I7GUxmo = xY4icgQUj6mPVs73CTKu(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠯ࡢࡲ࡬࠳࡫ࡧ࡬࡭ࡤࡤࡧࡰࡅ࡫࠾ࠩಬ")+key
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,HHvYL68lbJVZWM7tQEzSex3(u"ࠫࡌࡋࡔࠨಭ"),ylOgAQwbRHuvFdkK3I7GUxmo,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡈࡘࡤࡘࡅࡄࡃࡓࡘࡈࡎࡁ࠳ࡡࡗࡓࡐࡋࡎ࠮࠳ࡶࡸࠬಮ"))
	JMox3q27Fi1Rd468Z,iteration = NdKhAS6MXVEORLTwob92pxlZ,e8XhbyuzvjYkIsJUtB5w
	while k6apiPAlLKM1ed8J42RjHh0o:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
		YWsjNtDXPAgCya = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"࠭ࠢࠩ࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠴࠲ࡴࡦࡿ࡬ࡰࡣࡧ࡟ࡣࠨ࡝ࠬࠫࠪಯ"), LMKFcEkU1Q7R80yt4OsgvwxbfP)
		iteration += llxMLe4gobHhsj1WGvd7qmIU
		message = YYqECUofyi7wFrW.findall(Tzx81Wb0RZC4ID5AyiU2(u"ࠧ࠽࡮ࡤࡦࡪࡲ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡵࡧࡻࡸࠧࡡ࡞࠿࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱࡧࡢࡦ࡮ࡁࠫರ"), LMKFcEkU1Q7R80yt4OsgvwxbfP)
		if not message: message = YYqECUofyi7wFrW.findall(xY4icgQUj6mPVs73CTKu(u"ࠨ࠾ࡧ࡭ࡻࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡥࡳࡴࡲࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫಱ"), LMKFcEkU1Q7R80yt4OsgvwxbfP)
		if not message:
			JMox3q27Fi1Rd468Z = YYqECUofyi7wFrW.findall(HVmIrFwau90jQsgiWzExk(u"ࠩࡵࡩࡦࡪ࡯࡯࡮ࡼࡂ࠭࠴ࠪࡀࠫ࠿ࠫಲ"), LMKFcEkU1Q7R80yt4OsgvwxbfP)[e8XhbyuzvjYkIsJUtB5w]
			break
		else:
			message = message[e8XhbyuzvjYkIsJUtB5w]
			YWsjNtDXPAgCya = YWsjNtDXPAgCya[e8XhbyuzvjYkIsJUtB5w]
		bHGsF6D8VEYUuqO2BcK0Rm57tyeWSg = YYqECUofyi7wFrW.findall(IlL8ZnX74Yvep(u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡧࠧࡢࡳࠬࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩಳ"), LMKFcEkU1Q7R80yt4OsgvwxbfP)[e8XhbyuzvjYkIsJUtB5w]
		aYhG9UArbKdvnNsjL1Hw = gniNItGL6bKwpEW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲࠫࡳࠨ಴") % (YWsjNtDXPAgCya.replace(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࠬࡡ࡮ࡲ࠾ࠫವ"), PzIpQnUXxRwNCivDhdakWTE(u"࠭ࠦࠨಶ")))
		message = YYqECUofyi7wFrW.sub(R3lezw8h407ZvrAFxT(u"ࠧ࠽࠱ࡂࠬࡩ࡯ࡶࡽࡵࡷࡶࡴࡴࡧࠪ࡝ࡡࡂࡢ࠰࠾ࠨಷ"), NdKhAS6MXVEORLTwob92pxlZ, message)
		HL6jkriKSAtoYaqDRCJXgw3P7 = ql2ru1NZiv3BepLz(captcha=aYhG9UArbKdvnNsjL1Hw, msg=message, iteration=iteration)
		UUVFbMcw2Wy3dKJYOE9 = HL6jkriKSAtoYaqDRCJXgw3P7.get()
		if not UUVFbMcw2Wy3dKJYOE9: break
		data = {rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࡥࠪಸ"): bHGsF6D8VEYUuqO2BcK0Rm57tyeWSg, eGW7cI6aQhr0(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫಹ"): UUVFbMcw2Wy3dKJYOE9}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,IlL8ZnX74Yvep(u"ࠪࡔࡔ࡙ࡔࠨ಺"),ylOgAQwbRHuvFdkK3I7GUxmo,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠳ࡰࡧࠫ಻"))
	return JMox3q27Fi1Rd468Z
def YLntPJTBomgMlH(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ಼"))
	items = YYqECUofyi7wFrW.findall(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫಽ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[ items[e8XhbyuzvjYkIsJUtB5w] ]
	else: return OOkmZiVcfqlEurM1dHGb(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬಾ"),[],[]
def ep20hACWNc(url):
	return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
def mCV9TYUjiWF6qa5REXLuNBxb0so(url):
	oikt6P0hOAD5IvnlMpxf1 = url.split(R3lezw8h407ZvrAFxT(u"ࠨ࠱ࠪಿ"))
	bjW2CJiv1soaS0fnzTDgN5 = IlL8ZnX74Yvep(u"ࠩ࠲ࠫೀ").join(oikt6P0hOAD5IvnlMpxf1[e8XhbyuzvjYkIsJUtB5w:uL69vJOU7xN0hGnZf2islDqk])
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧು"))
	items = YYqECUofyi7wFrW.findall(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ೂ"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72,p84GZVnd7xeHMbR3WAtBN2h6EaK0,RRk6trWiOl,cvft6zNPWR17bTO8kAnl,tTYG8ZzOqc9j7d5Dh = items[e8XhbyuzvjYkIsJUtB5w]
		y6D8aMBhHnCQbLujWtlv = int(IUyjCkcPwiESY0o1s3QD72) % int(p84GZVnd7xeHMbR3WAtBN2h6EaK0) + int(RRk6trWiOl) % int(cvft6zNPWR17bTO8kAnl)
		url = bjW2CJiv1soaS0fnzTDgN5 + IVMxYoyhROTnXdbLBgzrjU48AEf + str(y6D8aMBhHnCQbLujWtlv) + tTYG8ZzOqc9j7d5Dh
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[url]
	else: return wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫೃ"),[],[]
def wxciAvM1GDBT(url):
	id = url.split(Tzx81Wb0RZC4ID5AyiU2(u"࠭࠯ࠨೄ"))[-llxMLe4gobHhsj1WGvd7qmIU]
	headers = { QQHFtjcaR2VpnSyTIv(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭೅") : lRP6GTaZJA1Xw3egLM4(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧೆ") }
	YWsjNtDXPAgCya = { JGwsL21ZRlqSrWxEmF(u"ࠤ࡬ࡨࠧೇ"):id , WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠥࡳࡵࠨೈ"):rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠢ೉") }
	kF13d0oJXn4xKH = cJaAB4uQyp(NXpO8DrVmeE,fOc18oTm5hsdD4pVZQj(u"ࠬࡖࡏࡔࡖࠪೊ"), url, YWsjNtDXPAgCya, headers, NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩೋ"))
	if NOrchaEV1iIZ87Uzlwgum(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩೌ") in list(kF13d0oJXn4xKH.headers.keys()): zehVcU893FC6LEd1Aij = kF13d0oJXn4xKH.headers[pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰ್ࠪ")]
	else: zehVcU893FC6LEd1Aij = url
	if zehVcU893FC6LEd1Aij: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[zehVcU893FC6LEd1Aij]
	else: return kb2icmDGVUZfW1OFz7sv(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠧ೎"),[],[]
def H3m7LsRVaGYB8gK5twFyblzUZ(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rNyT0edugn(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡊࡐࡗ࡚ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭೏"))
	items = YYqECUofyi7wFrW.findall(NeU6uRGpECkvMV5jf(u"ࠫࡲࡶ࠴࠻ࠢ࡟࡟ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ೐"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[ items[e8XhbyuzvjYkIsJUtB5w] ]
	else: return OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ೑"),[],[]
def JD05CQjgRdFv6kX7cfipsNLVzHhw(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ೒"))
	items = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ೓"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		url = url = Tzx81Wb0RZC4ID5AyiU2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ೔") + items[e8XhbyuzvjYkIsJUtB5w]
		return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[ url ]
	else: return pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡃࡉࡋ࡙ࡉࠬೕ"),[],[]
def tHT45Rwo2673BkDnXLrOKv(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫೖ"))
	items = YYqECUofyi7wFrW.findall(QQHFtjcaR2VpnSyTIv(u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ೗"),LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items: return NdKhAS6MXVEORLTwob92pxlZ,[NdKhAS6MXVEORLTwob92pxlZ],[ items[e8XhbyuzvjYkIsJUtB5w] ]
	else: return HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ೘"),[],[]
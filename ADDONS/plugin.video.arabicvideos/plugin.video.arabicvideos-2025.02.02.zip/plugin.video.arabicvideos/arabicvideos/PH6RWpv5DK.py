# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'IFILM'
LJfTAEQPv9h4BXdwUp = '_IFL_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
PPma30ybADqJNu = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][1]
bnmdzNygt4HWEPOvL6lQMB = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][2]
rIDJ8Kc4tVWEn = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][3]
def QGLoruqnmiAel7Op(mode,url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,text):
	if   mode==20: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = i1FZMrCP5Wj9suYod()
	elif mode==21: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr(url)
	elif mode==22: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==23: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==24: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url,text)
	elif mode==25: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vSMU0Lx32j7bWKFE85sIc6ifa(url)
	elif mode==27: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dbe3CzcI4ywG0jDmfY8HSxsqp(url)
	elif mode==28: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = h0l5idBX3q4L2YVj9yUGwvSFA1Jrb()
	elif mode==29: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def i1FZMrCP5Wj9suYod():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'عربي',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,21,NdKhAS6MXVEORLTwob92pxlZ,'101')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'English',PPma30ybADqJNu,21,NdKhAS6MXVEORLTwob92pxlZ,'101')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فارسى',bnmdzNygt4HWEPOvL6lQMB,21,NdKhAS6MXVEORLTwob92pxlZ,'101')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فارسى 2',rIDJ8Kc4tVWEn,21,NdKhAS6MXVEORLTwob92pxlZ,'101')
	return
def h0l5idBX3q4L2YVj9yUGwvSFA1Jrb():
	ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'عربي',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,27)
	ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'English',PPma30ybADqJNu,27)
	ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'فارسى',bnmdzNygt4HWEPOvL6lQMB,27)
	ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+'فارسى 2',rIDJ8Kc4tVWEn,27)
	return
def LkmCVzJQol0YsM83i7tnr(wyc9jtzYWvma3VhKorsQkxL4J):
	yNIDEX5hU4G769 = wyc9jtzYWvma3VhKorsQkxL4J
	if wyc9jtzYWvma3VhKorsQkxL4J=='IFILM-ARABIC': wyc9jtzYWvma3VhKorsQkxL4J = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	elif wyc9jtzYWvma3VhKorsQkxL4J=='IFILM-ENGLISH': wyc9jtzYWvma3VhKorsQkxL4J = PPma30ybADqJNu
	else: yNIDEX5hU4G769 = NdKhAS6MXVEORLTwob92pxlZ
	lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(wyc9jtzYWvma3VhKorsQkxL4J)
	if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='ar' or yNIDEX5hU4G769=='IFILM-ARABIC':
		N296FnKTR4qJtXEu8P = 'بحث في الموقع'
		kLsEevcNpM2dy9mVFljGW = 'مسلسلات - حالية'
		RoDOya8x9mcMLZduGkX7YJUQTqI = 'مسلسلات - أحدث'
		gD3VTpiMe9HFLhnoQyZA5 = 'مسلسلات - أبجدي'
		vkcdYHEuS1f0eK9IO = 'بث حي آي فيلم'
		lOHVmKIcjAs1DdP7wxhbSTiea3RXf = 'أفلام'
		JAZXOUQoYWL72rfuRky1wdN = 'موسيقى'
		Gti6vR3g48uW9FjJHMnyfeQKhLN = 'برامج'
	elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en' or yNIDEX5hU4G769=='IFILM-ENGLISH':
		N296FnKTR4qJtXEu8P = 'Search in site'
		kLsEevcNpM2dy9mVFljGW = 'Series - Current'
		RoDOya8x9mcMLZduGkX7YJUQTqI = 'Series - Latest'
		gD3VTpiMe9HFLhnoQyZA5 = 'Series - Alphabet'
		vkcdYHEuS1f0eK9IO = 'Live iFilm channel'
		lOHVmKIcjAs1DdP7wxhbSTiea3RXf = 'Movies'
		JAZXOUQoYWL72rfuRky1wdN = 'Music'
		Gti6vR3g48uW9FjJHMnyfeQKhLN = 'Shows'
	elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ in ['fa','fa2']:
		N296FnKTR4qJtXEu8P = 'جستجو در سایت'
		kLsEevcNpM2dy9mVFljGW = 'سريال - جاری'
		RoDOya8x9mcMLZduGkX7YJUQTqI = 'سريال - آخرین'
		gD3VTpiMe9HFLhnoQyZA5 = 'سريال - الفبا'
		vkcdYHEuS1f0eK9IO = 'پخش زنده اي فيلم'
		lOHVmKIcjAs1DdP7wxhbSTiea3RXf = 'فيلم'
		JAZXOUQoYWL72rfuRky1wdN = 'موسيقى'
		Gti6vR3g48uW9FjJHMnyfeQKhLN = 'برنامه ها'
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+N296FnKTR4qJtXEu8P,wyc9jtzYWvma3VhKorsQkxL4J,29,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('live',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+vkcdYHEuS1f0eK9IO,wyc9jtzYWvma3VhKorsQkxL4J,27)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	yzApRd2Dnes07XUZTM = ['Series','Program','Music']
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,wyc9jtzYWvma3VhKorsQkxL4J+'/home',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('button-menu(.*?)/Contact',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if any(K6KbZDHncNizQgl1fr59XV0 in zehVcU893FC6LEd1Aij for K6KbZDHncNizQgl1fr59XV0 in yzApRd2Dnes07XUZTM):
				url = wyc9jtzYWvma3VhKorsQkxL4J+zehVcU893FC6LEd1Aij
				if 'Series' in zehVcU893FC6LEd1Aij:
					ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,url,22,NdKhAS6MXVEORLTwob92pxlZ,'100')
					ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+RoDOya8x9mcMLZduGkX7YJUQTqI,url,22,NdKhAS6MXVEORLTwob92pxlZ,'101')
					ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+gD3VTpiMe9HFLhnoQyZA5,url,22,NdKhAS6MXVEORLTwob92pxlZ,'201')
				elif 'Film' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+lOHVmKIcjAs1DdP7wxhbSTiea3RXf,url,22,NdKhAS6MXVEORLTwob92pxlZ,'100')
				elif 'Music' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+JAZXOUQoYWL72rfuRky1wdN,url,25,NdKhAS6MXVEORLTwob92pxlZ,'101')
				elif 'Program' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+Gti6vR3g48uW9FjJHMnyfeQKhLN,url,22,NdKhAS6MXVEORLTwob92pxlZ,'101')
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def vSMU0Lx32j7bWKFE85sIc6ifa(url):
	wyc9jtzYWvma3VhKorsQkxL4J = dLJ0iFgeWvKBR4uxaw(url)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-MUSIC_MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('Music-tools-header(.*?)Music-body',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	title = YYqECUofyi7wFrW.findall('<p>(.*?)</p>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)[0]
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,22,NdKhAS6MXVEORLTwob92pxlZ,'101')
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = wyc9jtzYWvma3VhKorsQkxL4J + zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,23,NdKhAS6MXVEORLTwob92pxlZ,'101')
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	wyc9jtzYWvma3VhKorsQkxL4J = dLJ0iFgeWvKBR4uxaw(url)
	lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url)
	type = url.split('/')[-1]
	AAK5NVEevzI1nUuLHcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)//100)
	jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)%100)
	if type=='Series' and jNgDBqeKyZ4zSkGv8ROMA70aIYcC=='0':
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-TITLES-1st')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('serial-body(.*?)class="row',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			title = L5xKSr96JmaX7N(title)
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			zehVcU893FC6LEd1Aij = wyc9jtzYWvma3VhKorsQkxL4J + zehVcU893FC6LEd1Aij
			TTuPH708dUNnjlG3oQpkZsi = wyc9jtzYWvma3VhKorsQkxL4J + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,23,TTuPH708dUNnjlG3oQpkZsi,AAK5NVEevzI1nUuLHcC+'01')
	YjQKgJNBxDu65PyqZCOc8zwdX=0
	if type=='Series': II4s1CdgcbN6BSvWPnHtz='3'
	if type=='Film': II4s1CdgcbN6BSvWPnHtz='5'
	if type=='Program': II4s1CdgcbN6BSvWPnHtz='7'
	if type in ['Series','Program','Film'] and jNgDBqeKyZ4zSkGv8ROMA70aIYcC!='0':
		BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Home/PageingItem?category='+II4s1CdgcbN6BSvWPnHtz+'&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&orderby='+AAK5NVEevzI1nUuLHcC
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-TITLES-2nd')
		items = YYqECUofyi7wFrW.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for id,title,TTuPH708dUNnjlG3oQpkZsi in items:
			title = L5xKSr96JmaX7N(title)
			title = title.replace('\\',NdKhAS6MXVEORLTwob92pxlZ)
			title = title.replace('"',NdKhAS6MXVEORLTwob92pxlZ)
			YjQKgJNBxDu65PyqZCOc8zwdX += 1
			zehVcU893FC6LEd1Aij = wyc9jtzYWvma3VhKorsQkxL4J + '/' + type + '/Content/' + id
			TTuPH708dUNnjlG3oQpkZsi = wyc9jtzYWvma3VhKorsQkxL4J + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
			if type=='Film': ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,24,TTuPH708dUNnjlG3oQpkZsi,AAK5NVEevzI1nUuLHcC+'01')
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,23,TTuPH708dUNnjlG3oQpkZsi,AAK5NVEevzI1nUuLHcC+'01')
	if type=='Music':
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,wyc9jtzYWvma3VhKorsQkxL4J+'/Music/Index?page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-TITLES-3rd')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination-demo(.*?)pagination-demo',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			YjQKgJNBxDu65PyqZCOc8zwdX += 1
			TTuPH708dUNnjlG3oQpkZsi = wyc9jtzYWvma3VhKorsQkxL4J + TTuPH708dUNnjlG3oQpkZsi
			zehVcU893FC6LEd1Aij = wyc9jtzYWvma3VhKorsQkxL4J + zehVcU893FC6LEd1Aij
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,23,TTuPH708dUNnjlG3oQpkZsi,'101')
	if YjQKgJNBxDu65PyqZCOc8zwdX>20:
		title='صفحة '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': title = 'Page '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': title = 'صفحه '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': title = 'صفحه '
		for gWfeTcKdiYhAM7Skv4NI5GQLtXj8H in range(1,11) :
			if not jNgDBqeKyZ4zSkGv8ROMA70aIYcC==str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H):
				YMIQdZAVP4Lfxi0uwFGhDK = '0'+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H),url,22,NdKhAS6MXVEORLTwob92pxlZ,AAK5NVEevzI1nUuLHcC+YMIQdZAVP4Lfxi0uwFGhDK[-2:])
	return
def vl57jIYC4a(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC):
	if not jNgDBqeKyZ4zSkGv8ROMA70aIYcC: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = 0
	wyc9jtzYWvma3VhKorsQkxL4J = dLJ0iFgeWvKBR4uxaw(url)
	O35s8zKmnrf71PcDCShyR2gaM = dLJ0iFgeWvKBR4uxaw(url)
	lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url)
	BDkTn4JaU3HsYzI = url.split('/')
	id,type = BDkTn4JaU3HsYzI[-1],BDkTn4JaU3HsYzI[3]
	AAK5NVEevzI1nUuLHcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)//100)
	jNgDBqeKyZ4zSkGv8ROMA70aIYcC = str(int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)%100)
	YjQKgJNBxDu65PyqZCOc8zwdX = 0
	if type=='Series':
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-1st')
		items = YYqECUofyi7wFrW.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		title = ' - الحلقة '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': title = ' - Episode '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': title = ' - قسمت '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': title = ' - قسمت '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': Mzjy23Ddpg = NdKhAS6MXVEORLTwob92pxlZ
		else: Mzjy23Ddpg = lzWinvL53T2D0cGawRBPqm9FMAU7kQ
		kudNimUtwcpP6B = YYqECUofyi7wFrW.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for name,count,TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij in items:
			for N1VjdbtuO3z in range(int(count),0,-1):
				Wx5TCXBc23GwaIltSPp = TTuPH708dUNnjlG3oQpkZsi + Mzjy23Ddpg + id + '/' + str(N1VjdbtuO3z) + '.png'
				kLsEevcNpM2dy9mVFljGW = name + title + str(N1VjdbtuO3z)
				kLsEevcNpM2dy9mVFljGW = Pr4ubLdO7Z1qjKFaMIy3H(kLsEevcNpM2dy9mVFljGW)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,url,24,Wx5TCXBc23GwaIltSPp,NdKhAS6MXVEORLTwob92pxlZ,str(N1VjdbtuO3z))
	elif type=='Program':
		BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&orderby=1'
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-2nd')
		items = YYqECUofyi7wFrW.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		title = ' - الحلقة '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': title = ' - Episode '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': title = ' - قسمت '
		if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': title = ' - قسمت '
		for N1VjdbtuO3z,TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,O1O8ciXDgsLpe7,name in items:
			YjQKgJNBxDu65PyqZCOc8zwdX += 1
			Wx5TCXBc23GwaIltSPp = O35s8zKmnrf71PcDCShyR2gaM + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
			name = L5xKSr96JmaX7N(name)
			kLsEevcNpM2dy9mVFljGW = name + title + str(N1VjdbtuO3z)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,BfjcMoqOsmdUvZVCHWIyQKi,24,Wx5TCXBc23GwaIltSPp,NdKhAS6MXVEORLTwob92pxlZ,str(YjQKgJNBxDu65PyqZCOc8zwdX))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Music/GetTracksBy?id='+str(id)+'&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&type=0'
			LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-3rd')
			items = YYqECUofyi7wFrW.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,name,title in items:
				YjQKgJNBxDu65PyqZCOc8zwdX += 1
				Wx5TCXBc23GwaIltSPp = O35s8zKmnrf71PcDCShyR2gaM + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
				kLsEevcNpM2dy9mVFljGW = name + ' - ' + title
				kLsEevcNpM2dy9mVFljGW = kLsEevcNpM2dy9mVFljGW.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				kLsEevcNpM2dy9mVFljGW = L5xKSr96JmaX7N(kLsEevcNpM2dy9mVFljGW)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,BfjcMoqOsmdUvZVCHWIyQKi,24,Wx5TCXBc23GwaIltSPp,NdKhAS6MXVEORLTwob92pxlZ,str(YjQKgJNBxDu65PyqZCOc8zwdX))
		elif 'Clips' in url:
			BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Music/GetTracksBy?id=0&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&type=15'
			LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-4th')
			items = YYqECUofyi7wFrW.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			for TTuPH708dUNnjlG3oQpkZsi,title,zehVcU893FC6LEd1Aij in items:
				YjQKgJNBxDu65PyqZCOc8zwdX += 1
				Wx5TCXBc23GwaIltSPp = O35s8zKmnrf71PcDCShyR2gaM + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
				kLsEevcNpM2dy9mVFljGW = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				kLsEevcNpM2dy9mVFljGW = L5xKSr96JmaX7N(kLsEevcNpM2dy9mVFljGW)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,BfjcMoqOsmdUvZVCHWIyQKi,24,Wx5TCXBc23GwaIltSPp,NdKhAS6MXVEORLTwob92pxlZ,str(YjQKgJNBxDu65PyqZCOc8zwdX))
		elif 'category' in url:
			if 'category=6' in url:
				BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Music/GetTracksBy?id=0&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&type=6'
				LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				BfjcMoqOsmdUvZVCHWIyQKi = wyc9jtzYWvma3VhKorsQkxL4J+'/Music/GetTracksBy?id=0&page='+jNgDBqeKyZ4zSkGv8ROMA70aIYcC+'&size=30&type=4'
				LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-EPISODES-6th')
			items = YYqECUofyi7wFrW.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,name,title in items:
				YjQKgJNBxDu65PyqZCOc8zwdX += 1
				Wx5TCXBc23GwaIltSPp = O35s8zKmnrf71PcDCShyR2gaM + YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
				kLsEevcNpM2dy9mVFljGW = name + ' - ' + title
				kLsEevcNpM2dy9mVFljGW = kLsEevcNpM2dy9mVFljGW.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				kLsEevcNpM2dy9mVFljGW = L5xKSr96JmaX7N(kLsEevcNpM2dy9mVFljGW)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+kLsEevcNpM2dy9mVFljGW,BfjcMoqOsmdUvZVCHWIyQKi,24,Wx5TCXBc23GwaIltSPp,NdKhAS6MXVEORLTwob92pxlZ,str(YjQKgJNBxDu65PyqZCOc8zwdX))
	if type=='Music' or type=='Program':
		if YjQKgJNBxDu65PyqZCOc8zwdX>25:
			title='صفحة '
			if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': title = ' Page '
			if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': title = ' صفحه '
			if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': title = ' صفحه '
			for gWfeTcKdiYhAM7Skv4NI5GQLtXj8H in range(1,11):
				if not jNgDBqeKyZ4zSkGv8ROMA70aIYcC==str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H):
					YMIQdZAVP4Lfxi0uwFGhDK = '0'+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H)
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H),url,23,NdKhAS6MXVEORLTwob92pxlZ,AAK5NVEevzI1nUuLHcC+YMIQdZAVP4Lfxi0uwFGhDK[-2:])
	return
def uuvhoSanB2TWD(url,N1VjdbtuO3z):
	O35s8zKmnrf71PcDCShyR2gaM = dLJ0iFgeWvKBR4uxaw(url)
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-PLAY-1st')
	items = YYqECUofyi7wFrW.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url)
		BDkTn4JaU3HsYzI = url.split('/')
		id,type = BDkTn4JaU3HsYzI[-1],BDkTn4JaU3HsYzI[3]
		zehVcU893FC6LEd1Aij = items[0][0]+lzWinvL53T2D0cGawRBPqm9FMAU7kQ+id+'/,'+N1VjdbtuO3z+','+N1VjdbtuO3z+'_'+items[0][2]
		IGEpKNCaiLMT.append('m3u8')
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	items = YYqECUofyi7wFrW.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url)
		BDkTn4JaU3HsYzI = url.split('/')
		id,type = BDkTn4JaU3HsYzI[-1],BDkTn4JaU3HsYzI[3]
		zehVcU893FC6LEd1Aij = items[0][0]+lzWinvL53T2D0cGawRBPqm9FMAU7kQ+id+'/'+N1VjdbtuO3z+items[0][2]
		IGEpKNCaiLMT.append('mp4 url')
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	items = YYqECUofyi7wFrW.findall('source src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij in items:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('//','/')
		IGEpKNCaiLMT.append('mp4 src')
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	items = YYqECUofyi7wFrW.findall('VideoAddress":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		zehVcU893FC6LEd1Aij = items[int(N1VjdbtuO3z)-1]
		zehVcU893FC6LEd1Aij = O35s8zKmnrf71PcDCShyR2gaM+YUkzG2ymNSqdon(zehVcU893FC6LEd1Aij)
		IGEpKNCaiLMT.append('mp4 address')
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	items = YYqECUofyi7wFrW.findall('VoiceAddress":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		zehVcU893FC6LEd1Aij = items[int(N1VjdbtuO3z)-1]
		zehVcU893FC6LEd1Aij = O35s8zKmnrf71PcDCShyR2gaM+YUkzG2ymNSqdon(zehVcU893FC6LEd1Aij)
		IGEpKNCaiLMT.append('mp3 address')
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if len(UTwH7zjZOrmFl)==1: zehVcU893FC6LEd1Aij = UTwH7zjZOrmFl[0]
	else:
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر الفيديو المناسب:', IGEpKNCaiLMT)
		if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
		zehVcU893FC6LEd1Aij = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(zehVcU893FC6LEd1Aij,yNIDEX5hU4G769,'video')
	return
def dLJ0iFgeWvKBR4uxaw(url):
	if qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN in url: mAH4aPy8q1w = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	elif PPma30ybADqJNu in url: mAH4aPy8q1w = PPma30ybADqJNu
	elif bnmdzNygt4HWEPOvL6lQMB in url: mAH4aPy8q1w = bnmdzNygt4HWEPOvL6lQMB
	elif rIDJ8Kc4tVWEn in url: mAH4aPy8q1w = rIDJ8Kc4tVWEn
	else: mAH4aPy8q1w = NdKhAS6MXVEORLTwob92pxlZ
	return mAH4aPy8q1w
def yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url):
	if   qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN in url: lzWinvL53T2D0cGawRBPqm9FMAU7kQ = 'ar'
	elif PPma30ybADqJNu in url: lzWinvL53T2D0cGawRBPqm9FMAU7kQ = 'en'
	elif bnmdzNygt4HWEPOvL6lQMB in url: lzWinvL53T2D0cGawRBPqm9FMAU7kQ = 'fa'
	elif rIDJ8Kc4tVWEn in url: lzWinvL53T2D0cGawRBPqm9FMAU7kQ = 'fa2'
	else: lzWinvL53T2D0cGawRBPqm9FMAU7kQ = NdKhAS6MXVEORLTwob92pxlZ
	return lzWinvL53T2D0cGawRBPqm9FMAU7kQ
def dbe3CzcI4ywG0jDmfY8HSxsqp(url):
	lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(url)
	BfjcMoqOsmdUvZVCHWIyQKi = url + '/Home/Live'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-LIVE-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = YYqECUofyi7wFrW.findall('source src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	Afey3cL4ojzg = items[0]
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(Afey3cL4ojzg,yNIDEX5hU4G769,'live')
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search:
		search = Z6GiHgnz0jNytc()
		if not search: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	if showDialogs:
		neZJ1TkAp2 = [ qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN , PPma30ybADqJNu , bnmdzNygt4HWEPOvL6lQMB , rIDJ8Kc4tVWEn ]
		V2E56eU4vIrcYoh91Azpm = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر اللغة المناسبة:', V2E56eU4vIrcYoh91Azpm)
		if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
		website = neZJ1TkAp2[rRfpvbZojlygET5JL87wdzIPGe]
	else:
		if '_IFILM-ARABIC_' in LM1WpcGdrz8QtHV0i53k: website = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
		elif '_IFILM-ENGLISH_' in LM1WpcGdrz8QtHV0i53k: website = PPma30ybADqJNu
		else: website = NdKhAS6MXVEORLTwob92pxlZ
	if not website: return
	lzWinvL53T2D0cGawRBPqm9FMAU7kQ = yjBVESQ2HnFIrzad9fxWXNDbeksTKC(website)
	BfjcMoqOsmdUvZVCHWIyQKi = website + "/Home/Search?searchstring=" + n5pZARB2X0x8abLPeywMuHkqV
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IFILM-SEARCH-1st')
	items = YYqECUofyi7wFrW.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if items:
		for TTuPH708dUNnjlG3oQpkZsi,II4s1CdgcbN6BSvWPnHtz,id,title in items:
			if II4s1CdgcbN6BSvWPnHtz in ['3','7']:
				title = title.replace('\\',NdKhAS6MXVEORLTwob92pxlZ)
				title = title.replace('"',NdKhAS6MXVEORLTwob92pxlZ)
				if II4s1CdgcbN6BSvWPnHtz=='3':
					type = 'Series'
					if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='ar': name = 'مسلسل : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': name = 'Series : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': name = 'سريال ها : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': name = 'سريال ها : '
				elif II4s1CdgcbN6BSvWPnHtz=='5':
					type = 'Film'
					if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='ar': name = 'فيلم : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': name = 'Movie : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': name = 'فيلم : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': name = 'فلم ها : '
				elif II4s1CdgcbN6BSvWPnHtz=='7':
					type = 'Program'
					if lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='ar': name = 'برنامج : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='en': name = 'Program : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa': name = 'برنامه ها : '
					elif lzWinvL53T2D0cGawRBPqm9FMAU7kQ=='fa2': name = 'برنامه ها : '
				title = name + title
				zehVcU893FC6LEd1Aij = website + '/' + type + '/Content/' + id
				TTuPH708dUNnjlG3oQpkZsi = YUkzG2ymNSqdon(TTuPH708dUNnjlG3oQpkZsi)
				TTuPH708dUNnjlG3oQpkZsi = website+TTuPH708dUNnjlG3oQpkZsi
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,23,TTuPH708dUNnjlG3oQpkZsi,'101')
	return
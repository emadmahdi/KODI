# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'SERIES4WATCH'
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
LJfTAEQPv9h4BXdwUp = '_SFW_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==210: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==211: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==212: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==213: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==214: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = bwtZAYUFVqsG03Cju(url)
	elif mode==215: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = SWlTpxh369(url)
	elif mode==218: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = L81DhZI6SA()
	elif mode==219: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def L81DhZI6SA():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,219,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/getpostsPin?type=one&data=pin&limit=25'
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المميزة',url,211)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('FiltersButtons(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-get="(.*?)".*?</i>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/getposts?type=one&data='+zehVcU893FC6LEd1Aij
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,url,211)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('navigation-menu(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(http.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	Kdr54yMqbjTSX7piWREfPtZ2em = ['مسلسلات انمي','الرئيسية']
	for zehVcU893FC6LEd1Aij,title in items:
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,211)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('MediaGrid"(.*?)class="pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		else: return
	items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	RnWCFcXJeB7Sv = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		if '/series/' in zehVcU893FC6LEd1Aij: continue
		zehVcU893FC6LEd1Aij = OOFEmwq2GkTz93WXy1Nj(zehVcU893FC6LEd1Aij).strip('/')
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if '/film/' in zehVcU893FC6LEd1Aij or any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in RnWCFcXJeB7Sv):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,212,TTuPH708dUNnjlG3oQpkZsi)
		elif '/episode/' in zehVcU893FC6LEd1Aij and 'الحلقة' in title:
			N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
			if N1VjdbtuO3z:
				title = '_MOD_' + N1VjdbtuO3z[0]
				if title not in zIDPZSNn1OuweLHvmMKb6d:
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,213,TTuPH708dUNnjlG3oQpkZsi)
					zIDPZSNn1OuweLHvmMKb6d.append(title)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,213,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
			if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,211)
	return
def vl57jIYC4a(url):
	YqICN1R0Mb4JZFkzhvDW9e,items,NlnQdZwm4j = -1,[],[]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-EPISODES-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('ti-list-numbered(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		sCRbZp6Irl17v = NdKhAS6MXVEORLTwob92pxlZ.join(bMU7NEFK5RJ8dcz0jtqiWmvyar6)
		items = YYqECUofyi7wFrW.findall('href="(.*?)"',sCRbZp6Irl17v,YYqECUofyi7wFrW.DOTALL)
	items.append(url)
	items = set(items)
	for zehVcU893FC6LEd1Aij in items:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.strip('/')
		title = '_MOD_' + zehVcU893FC6LEd1Aij.split('/')[-1].replace('-',Vwgflszp4WRA93kx6hvdua21HX5cOb)
		oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = YYqECUofyi7wFrW.findall('الحلقة-(\d+)',zehVcU893FC6LEd1Aij.split('/')[-1],YYqECUofyi7wFrW.DOTALL)
		if oLQuxeSOY6A0fq2kF3TZnbGgw7Dc: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = oLQuxeSOY6A0fq2kF3TZnbGgw7Dc[0]
		else: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = '0'
		NlnQdZwm4j.append([zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc])
	items = sorted(NlnQdZwm4j, reverse=False, key=lambda key: int(key[2]))
	cPqut3WSXjAVyaGhH7O5J9obw2i = str(items).count('/season/')
	YqICN1R0Mb4JZFkzhvDW9e = str(items).count('/episode/')
	if cPqut3WSXjAVyaGhH7O5J9obw2i>1 and YqICN1R0Mb4JZFkzhvDW9e>0 and '/season/' not in url:
		for zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc in items:
			if '/season/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,213)
	else:
		for zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc in items:
			if '/season/' not in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,212)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl = []
	BDkTn4JaU3HsYzI = url.split('/')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(BDkTn4JaU3HsYzI[3],'watch')
		HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-PLAY-2nd')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="servers-list(.*?)</div>',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if items:
				id = YYqECUofyi7wFrW.findall('post_id=(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
				if id:
					f1BA08uJ2nePQcdCHRqNEZKoGM = id[0]
					for zehVcU893FC6LEd1Aij,title in items:
						zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/?postid='+f1BA08uJ2nePQcdCHRqNEZKoGM+'&serverid='+zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
						UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
			else:
				items = YYqECUofyi7wFrW.findall('data-embedd=".*?(http.*?)("|&quot;)',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
				for zehVcU893FC6LEd1Aij,gHbS3MaYo0j6uTdm2qyQnKP in items:
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if '/download/' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(BDkTn4JaU3HsYzI[3],'download')
		HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-PLAY-3rd')
		id = YYqECUofyi7wFrW.findall('postId:"(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		if id:
			f1BA08uJ2nePQcdCHRqNEZKoGM = id[0]
			omrd89nv0PGKFpL3TxfAXt = { 'User-Agent':NdKhAS6MXVEORLTwob92pxlZ , 'X-Requested-With':'XMLHttpRequest' }
			BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/ajaxCenter?_action=getdownloadlinks&postId='+f1BA08uJ2nePQcdCHRqNEZKoGM
			HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,'SERIES4WATCH-PLAY-4th')
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<h3.*?(\d+)(.*?)</div>',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
				for PDFYOURfNJQ4lwCqaM,AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
					items = YYqECUofyi7wFrW.findall('<td>(.*?)<.*?href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
					for name,zehVcU893FC6LEd1Aij in items:
						UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij+'?named='+name+'__download'+'____'+PDFYOURfNJQ4lwCqaM)
			else:
				bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<h6(.*?)</table>',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
				if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [HeFB5x2wED]
				for AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
					name = NdKhAS6MXVEORLTwob92pxlZ
					items = YYqECUofyi7wFrW.findall('href="(http.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
					for zehVcU893FC6LEd1Aij in items:
						oikt6P0hOAD5IvnlMpxf1 = '&&' + zehVcU893FC6LEd1Aij.split('/')[2].lower() + '&&'
						oikt6P0hOAD5IvnlMpxf1 = oikt6P0hOAD5IvnlMpxf1.replace('.com&&',NdKhAS6MXVEORLTwob92pxlZ).replace('.co&&',NdKhAS6MXVEORLTwob92pxlZ)
						oikt6P0hOAD5IvnlMpxf1 = oikt6P0hOAD5IvnlMpxf1.replace('.net&&',NdKhAS6MXVEORLTwob92pxlZ).replace('.org&&',NdKhAS6MXVEORLTwob92pxlZ)
						oikt6P0hOAD5IvnlMpxf1 = oikt6P0hOAD5IvnlMpxf1.replace('.live&&',NdKhAS6MXVEORLTwob92pxlZ).replace('.online&&',NdKhAS6MXVEORLTwob92pxlZ)
						oikt6P0hOAD5IvnlMpxf1 = oikt6P0hOAD5IvnlMpxf1.replace('&&hd.',NdKhAS6MXVEORLTwob92pxlZ).replace('&&www.',NdKhAS6MXVEORLTwob92pxlZ)
						oikt6P0hOAD5IvnlMpxf1 = oikt6P0hOAD5IvnlMpxf1.replace('&&',NdKhAS6MXVEORLTwob92pxlZ)
						zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij + '?named=' + name + oikt6P0hOAD5IvnlMpxf1 + '__download'
						UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/search?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
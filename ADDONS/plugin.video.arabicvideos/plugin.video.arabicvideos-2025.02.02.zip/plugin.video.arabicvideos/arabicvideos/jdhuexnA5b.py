# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'YOUTUBE'
LJfTAEQPv9h4BXdwUp = '_YUT_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
s5xcQMUd1SmHl = 0
def QGLoruqnmiAel7Op(mode,url,text,type,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,name,k1ChwgueU5nbDX6K0BOEGx):
	if	 mode==140: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==141: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hCm09RdvD2o5ZVeaB4LHjIMyJ(url,name,k1ChwgueU5nbDX6K0BOEGx)
	elif mode==143: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url,type)
	elif mode==144: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,text)
	elif mode==145: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dvESi09LR7(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==147: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Yq5GtpOPik()
	elif mode==148: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = FtasY5ON9BovVJ4yclwbL86i1T03dZ()
	elif mode==149: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	if 0:
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'قائمة 1',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'قائمة 2',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'شخص',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/user/TCNofficial',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'موقع',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'حساب',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/@TheSocialCTV',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'العاب',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/gaming',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'افلام',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/feed/storefront',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مختارات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/feed/guide_builder',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'قصيرة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/shorts',144,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'تصفح',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/youtubei/v1/guide?key=',144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'رئيسية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+NdKhAS6MXVEORLTwob92pxlZ,144)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'رائج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/feed/trending?bp=',144)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,149,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الرائجة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/feed/trending',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'التصفح',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/youtubei/v1/guide?key=',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'القصيرة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/shorts',144,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مختارات يوتيوب',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/feed/guide_builder',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مختارات البرنامج',NdKhAS6MXVEORLTwob92pxlZ,290)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: قنوات عربية',NdKhAS6MXVEORLTwob92pxlZ,147)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: قنوات أجنبية',NdKhAS6MXVEORLTwob92pxlZ,148)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: افلام عربية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=فيلم',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: افلام اجنبية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=movie',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: مسرحيات عربية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=مسرحية',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: مسلسلات عربية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: مسلسلات اجنبية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=series&sp=EgIQAw==',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: مسلسلات كارتون',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=كارتون&sp=EgIQAw==',144)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث: خطبة المرجعية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def hCm09RdvD2o5ZVeaB4LHjIMyJ(url,name,k1ChwgueU5nbDX6K0BOEGx):
	name = x5lwbtumkO6X2TgFoVh(name)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'CHNL:  '+name,url,144,k1ChwgueU5nbDX6K0BOEGx)
	return
def Yq5GtpOPik():
	hGJKk8tAiC3XFufEpqavQWmwTHdL(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def FtasY5ON9BovVJ4yclwbL86i1T03dZ():
	hGJKk8tAiC3XFufEpqavQWmwTHdL(qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query=tv&sp=EgJAAQ==')
	return
def uuvhoSanB2TWD(url,type):
	url = url.split('&',1)[0]
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx([url],yNIDEX5hU4G769,type,url)
	return
def EiPjKTgFnN3yBp(ZHRKwglmD9CSQefINvMTLxczAjWP,url,Xd8PpnWk1RlgzSmuNjtK3):
	level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = Xd8PpnWk1RlgzSmuNjtK3.split('::')
	rdCjOq4fPEH,kjFzGUhuNwqIsDpd = [],[]
	if '/youtubei/v1/browse' in url: rdCjOq4fPEH.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: rdCjOq4fPEH.append("yccc['onResponseReceivedCommands']")
	rdCjOq4fPEH.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': rdCjOq4fPEH.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	rdCjOq4fPEH.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	rdCjOq4fPEH.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	rdCjOq4fPEH.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	rdCjOq4fPEH.append("yccc['entries']")
	rdCjOq4fPEH.append("yccc['items'][3]['guideSectionRenderer']['items']")
	DwuzVQArZ2aGg9JiMmU1CRdbl,oUQDYZSnt6FVxHu2iarkBER9,s8FOXRExvfmYde9jZaboT2gziIG = D0OSXATbZant3(ZHRKwglmD9CSQefINvMTLxczAjWP,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
	if level=='1' and DwuzVQArZ2aGg9JiMmU1CRdbl:
		if len(oUQDYZSnt6FVxHu2iarkBER9)>1 and 'search_query' not in url:
			for S6Ai4RlwfThbvoW38Hcd5JeKz0r in range(len(oUQDYZSnt6FVxHu2iarkBER9)):
				MLwenNmSRfz95ZK7Oaris = str(S6Ai4RlwfThbvoW38Hcd5JeKz0r)
				rdCjOq4fPEH = []
				rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['reloadContinuationItemsCommand']['continuationItems']")
				rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['command']")
				rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]")
				PsKJk8XRHAQM,rMOG2USkPesYZD9KNAVqpc,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(oUQDYZSnt6FVxHu2iarkBER9,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
				if PsKJk8XRHAQM: kjFzGUhuNwqIsDpd.append([rMOG2USkPesYZD9KNAVqpc,url,'2::'+MLwenNmSRfz95ZK7Oaris+'::0::0'])
			rdCjOq4fPEH.append("yccc['continuationEndpoint']")
			PsKJk8XRHAQM,rMOG2USkPesYZD9KNAVqpc,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(ZHRKwglmD9CSQefINvMTLxczAjWP,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
			if PsKJk8XRHAQM and kjFzGUhuNwqIsDpd and 'continuationCommand' in list(rMOG2USkPesYZD9KNAVqpc.keys()):
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/my_main_page_shorts_link'
				kjFzGUhuNwqIsDpd.append([rMOG2USkPesYZD9KNAVqpc,zehVcU893FC6LEd1Aij,'1::0::0::0'])
	return oUQDYZSnt6FVxHu2iarkBER9,DwuzVQArZ2aGg9JiMmU1CRdbl,kjFzGUhuNwqIsDpd,s8FOXRExvfmYde9jZaboT2gziIG
def NCGfScZJ8Kj75t6Ak2WDrHYa4L9eiP(ZHRKwglmD9CSQefINvMTLxczAjWP,oUQDYZSnt6FVxHu2iarkBER9,url,Xd8PpnWk1RlgzSmuNjtK3):
	level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = Xd8PpnWk1RlgzSmuNjtK3.split('::')
	rdCjOq4fPEH,AAHB4mhWDtsFGy2S59IeC = [],[]
	rdCjOq4fPEH.append("yddd[0]['itemSectionRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['reloadContinuationItemsCommand']['continuationItems']")
	rdCjOq4fPEH.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: rdCjOq4fPEH.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: rdCjOq4fPEH.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	rdCjOq4fPEH.append("yddd["+MLwenNmSRfz95ZK7Oaris+"]")
	zcWLJZXjfh6S,xNK8GlenVA2UHcPuCmiTjpo3aWL,Q2KNFnOqRd4w6J0EVtel5I8YPhMy = D0OSXATbZant3(oUQDYZSnt6FVxHu2iarkBER9,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
	if level=='2' and zcWLJZXjfh6S:
		if len(xNK8GlenVA2UHcPuCmiTjpo3aWL)>1:
			for S6Ai4RlwfThbvoW38Hcd5JeKz0r in range(len(xNK8GlenVA2UHcPuCmiTjpo3aWL)):
				o0oBKgNUzTraeIcLuGvED1f = str(S6Ai4RlwfThbvoW38Hcd5JeKz0r)
				rdCjOq4fPEH = []
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['richSectionRenderer']['content']")
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]")
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['richItemRenderer']['content']")
				rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]")
				PsKJk8XRHAQM,rMOG2USkPesYZD9KNAVqpc,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(xNK8GlenVA2UHcPuCmiTjpo3aWL,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
				if PsKJk8XRHAQM: AAHB4mhWDtsFGy2S59IeC.append([rMOG2USkPesYZD9KNAVqpc,url,'3::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::0'])
			rdCjOq4fPEH.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			rdCjOq4fPEH.append("yddd[1]")
			PsKJk8XRHAQM,rMOG2USkPesYZD9KNAVqpc,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(oUQDYZSnt6FVxHu2iarkBER9,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
			if PsKJk8XRHAQM and AAHB4mhWDtsFGy2S59IeC and 'continuationItemRenderer' in list(rMOG2USkPesYZD9KNAVqpc.keys()):
				AAHB4mhWDtsFGy2S59IeC.append([rMOG2USkPesYZD9KNAVqpc,url,'3::0::0::0'])
	return xNK8GlenVA2UHcPuCmiTjpo3aWL,zcWLJZXjfh6S,AAHB4mhWDtsFGy2S59IeC,Q2KNFnOqRd4w6J0EVtel5I8YPhMy
def n4nebfYL6k5igjWAaIRpJ3owD0M(ZHRKwglmD9CSQefINvMTLxczAjWP,xNK8GlenVA2UHcPuCmiTjpo3aWL,url,Xd8PpnWk1RlgzSmuNjtK3):
	level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = Xd8PpnWk1RlgzSmuNjtK3.split('::')
	rdCjOq4fPEH,HHrKdiCJDx = [],[]
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	rdCjOq4fPEH.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	rdCjOq4fPEH.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	rdCjOq4fPEH.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['reelShelfRenderer']['items']")
	rdCjOq4fPEH.append("yeee["+o0oBKgNUzTraeIcLuGvED1f+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	rdCjOq4fPEH.append("yeee")
	xxbTs4lC5At1HoIcO,tV9wzX6Y803AGEOMNTBWb,YlirAseM6IhS = D0OSXATbZant3(xNK8GlenVA2UHcPuCmiTjpo3aWL,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
	if level=='3' and xxbTs4lC5At1HoIcO:
		if len(tV9wzX6Y803AGEOMNTBWb)>0:
			for S6Ai4RlwfThbvoW38Hcd5JeKz0r in range(len(tV9wzX6Y803AGEOMNTBWb)):
				Fn9ZHUYao5x8K = str(S6Ai4RlwfThbvoW38Hcd5JeKz0r)
				rdCjOq4fPEH = []
				rdCjOq4fPEH.append("yfff["+Fn9ZHUYao5x8K+"]['richItemRenderer']['content']")
				rdCjOq4fPEH.append("yfff["+Fn9ZHUYao5x8K+"]['gameCardRenderer']['game']")
				rdCjOq4fPEH.append("yfff["+Fn9ZHUYao5x8K+"]['itemSectionRenderer']['contents'][0]")
				rdCjOq4fPEH.append("yfff["+Fn9ZHUYao5x8K+"]")
				rdCjOq4fPEH.append("yfff")
				PsKJk8XRHAQM,rMOG2USkPesYZD9KNAVqpc,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(tV9wzX6Y803AGEOMNTBWb,NdKhAS6MXVEORLTwob92pxlZ,rdCjOq4fPEH)
				if PsKJk8XRHAQM: HHrKdiCJDx.append([rMOG2USkPesYZD9KNAVqpc,url,'4::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K])
	return tV9wzX6Y803AGEOMNTBWb,xxbTs4lC5At1HoIcO,HHrKdiCJDx,YlirAseM6IhS
def D0OSXATbZant3(IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72,NFLVJIiWY7v9Xgqu):
	ZHRKwglmD9CSQefINvMTLxczAjWP,IUyjCkcPwiESY0o1s3QD72 = IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72
	oUQDYZSnt6FVxHu2iarkBER9,IUyjCkcPwiESY0o1s3QD72 = IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72
	xNK8GlenVA2UHcPuCmiTjpo3aWL,IUyjCkcPwiESY0o1s3QD72 = IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72
	tV9wzX6Y803AGEOMNTBWb,IUyjCkcPwiESY0o1s3QD72 = IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72
	rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c = IVMxYoyhROTnXdbLBgzrjU48AEf,IUyjCkcPwiESY0o1s3QD72
	count = len(NFLVJIiWY7v9Xgqu)
	for XW2Opt4RQsVihunCylz6j in range(count):
		try:
			WWJaAdRQj3y8r = eval(NFLVJIiWY7v9Xgqu[XW2Opt4RQsVihunCylz6j])
			return True,WWJaAdRQj3y8r,XW2Opt4RQsVihunCylz6j+1
		except: pass
	return False,NdKhAS6MXVEORLTwob92pxlZ,0
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,Xd8PpnWk1RlgzSmuNjtK3=NdKhAS6MXVEORLTwob92pxlZ,data=NdKhAS6MXVEORLTwob92pxlZ):
	kjFzGUhuNwqIsDpd,AAHB4mhWDtsFGy2S59IeC,HHrKdiCJDx = [],[],[]
	if '::' not in Xd8PpnWk1RlgzSmuNjtK3: Xd8PpnWk1RlgzSmuNjtK3 = '1::0::0::0'
	level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = Xd8PpnWk1RlgzSmuNjtK3.split('::')
	if level=='4': level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = '1',MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K
	data = data.replace('_REMEMBERRESULTS_',NdKhAS6MXVEORLTwob92pxlZ)
	LMKFcEkU1Q7R80yt4OsgvwxbfP,ZHRKwglmD9CSQefINvMTLxczAjWP,OzUD8iTmGp15Sn9VINMHq = E4V9Yd5cvOJW8Rm7(url,data)
	Xd8PpnWk1RlgzSmuNjtK3 = level+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
	if level in ['1','2','3']:
		oUQDYZSnt6FVxHu2iarkBER9,DwuzVQArZ2aGg9JiMmU1CRdbl,kjFzGUhuNwqIsDpd,s8FOXRExvfmYde9jZaboT2gziIG = EiPjKTgFnN3yBp(ZHRKwglmD9CSQefINvMTLxczAjWP,url,Xd8PpnWk1RlgzSmuNjtK3)
		if not DwuzVQArZ2aGg9JiMmU1CRdbl: return
		zzZtQG6D8bTgfkcLUh9m4 = len(kjFzGUhuNwqIsDpd)
		if zzZtQG6D8bTgfkcLUh9m4<2:
			if level=='1': level = '2'
			kjFzGUhuNwqIsDpd = []
	Xd8PpnWk1RlgzSmuNjtK3 = level+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
	if level in ['2','3']:
		xNK8GlenVA2UHcPuCmiTjpo3aWL,zcWLJZXjfh6S,AAHB4mhWDtsFGy2S59IeC,Q2KNFnOqRd4w6J0EVtel5I8YPhMy = NCGfScZJ8Kj75t6Ak2WDrHYa4L9eiP(ZHRKwglmD9CSQefINvMTLxczAjWP,oUQDYZSnt6FVxHu2iarkBER9,url,Xd8PpnWk1RlgzSmuNjtK3)
		if not zcWLJZXjfh6S: return
		zGfnKXtEIp782Bl3SurU = len(AAHB4mhWDtsFGy2S59IeC)
		if zGfnKXtEIp782Bl3SurU<2:
			if level=='2': level = '3'
			AAHB4mhWDtsFGy2S59IeC = []
	Xd8PpnWk1RlgzSmuNjtK3 = level+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
	if level in ['3']:
		tV9wzX6Y803AGEOMNTBWb,xxbTs4lC5At1HoIcO,HHrKdiCJDx,YlirAseM6IhS = n4nebfYL6k5igjWAaIRpJ3owD0M(ZHRKwglmD9CSQefINvMTLxczAjWP,xNK8GlenVA2UHcPuCmiTjpo3aWL,url,Xd8PpnWk1RlgzSmuNjtK3)
		if not xxbTs4lC5At1HoIcO: return
		wl3oUNf9pPFnVRQYyWBkh4 = len(HHrKdiCJDx)
	for rMOG2USkPesYZD9KNAVqpc,url,Xd8PpnWk1RlgzSmuNjtK3 in kjFzGUhuNwqIsDpd+AAHB4mhWDtsFGy2S59IeC+HHrKdiCJDx:
		zPhBukdGmV03IW = DzEaCduA7wWPpXLsMZSjx(rMOG2USkPesYZD9KNAVqpc,url,Xd8PpnWk1RlgzSmuNjtK3)
	return
def DzEaCduA7wWPpXLsMZSjx(rMOG2USkPesYZD9KNAVqpc,url=NdKhAS6MXVEORLTwob92pxlZ,Xd8PpnWk1RlgzSmuNjtK3=NdKhAS6MXVEORLTwob92pxlZ):
	if '::' in Xd8PpnWk1RlgzSmuNjtK3: level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = Xd8PpnWk1RlgzSmuNjtK3.split('::')
	else: level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = '1','0','0','0'
	PsKJk8XRHAQM,title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,count,TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd,nIyGbRwDjlemVgX873,ccByzjri98HPTkIZ3Y1EoD0L5OgbvQ = nFVjam16AuTM(rMOG2USkPesYZD9KNAVqpc)
	O7TLdNZjpW = '/videos?' in zehVcU893FC6LEd1Aij or '/streams?' in zehVcU893FC6LEd1Aij or '/playlists?' in zehVcU893FC6LEd1Aij
	K0TXmdZiEoGayp7L6 = '/channels?' in zehVcU893FC6LEd1Aij or '/shorts?' in zehVcU893FC6LEd1Aij
	if O7TLdNZjpW or K0TXmdZiEoGayp7L6: zehVcU893FC6LEd1Aij = url
	O7TLdNZjpW = 'watch?v=' not in zehVcU893FC6LEd1Aij and '/playlist?list=' not in zehVcU893FC6LEd1Aij
	K0TXmdZiEoGayp7L6 = '/gaming' not in zehVcU893FC6LEd1Aij  and '/feed/storefront' not in zehVcU893FC6LEd1Aij
	if Xd8PpnWk1RlgzSmuNjtK3[0:5]=='3::0::' and O7TLdNZjpW and K0TXmdZiEoGayp7L6: zehVcU893FC6LEd1Aij = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in zehVcU893FC6LEd1Aij:
		level,MLwenNmSRfz95ZK7Oaris,o0oBKgNUzTraeIcLuGvED1f,Fn9ZHUYao5x8K = '1','0','0','0'
		Xd8PpnWk1RlgzSmuNjtK3 = NdKhAS6MXVEORLTwob92pxlZ
	OzUD8iTmGp15Sn9VINMHq = NdKhAS6MXVEORLTwob92pxlZ
	if '/youtubei/v1/browse' in zehVcU893FC6LEd1Aij or '/youtubei/v1/search' in zehVcU893FC6LEd1Aij or '/my_main_page_shorts_link' in url:
		data = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.youtube.data')
		if data.count(':::')==4:
			HHhYctUFjAw04rg,key,aR4SpDYFyGOhAE,d9TXmPKf7iOx3jc4rW8QsuBIYU,JMox3q27Fi1Rd468Z = data.split(':::')
			OzUD8iTmGp15Sn9VINMHq = HHhYctUFjAw04rg+':::'+key+':::'+aR4SpDYFyGOhAE+':::'+d9TXmPKf7iOx3jc4rW8QsuBIYU+':::'+ccByzjri98HPTkIZ3Y1EoD0L5OgbvQ
			if '/my_main_page_shorts_link' in url and not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = url
			else: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?key='+key
	if not title:
		global s5xcQMUd1SmHl
		s5xcQMUd1SmHl += 1
		title = 'فيديوهات '+str(s5xcQMUd1SmHl)
		Xd8PpnWk1RlgzSmuNjtK3 = '3'+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
	if not PsKJk8XRHAQM: return False
	elif 'searchPyvRenderer' in str(rMOG2USkPesYZD9KNAVqpc): return False
	elif '/about' in zehVcU893FC6LEd1Aij: return False
	elif '/community' in zehVcU893FC6LEd1Aij: return False
	elif 'continuationItemRenderer' in list(rMOG2USkPesYZD9KNAVqpc.keys()) or 'continuationCommand' in list(rMOG2USkPesYZD9KNAVqpc.keys()):
		if int(level)>1: level = str(int(level)-1)
		Xd8PpnWk1RlgzSmuNjtK3 = level+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+':: '+'صفحة أخرى',zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3,OzUD8iTmGp15Sn9VINMHq)
	elif '/search' in zehVcU893FC6LEd1Aij:
		title = ':: '+title
		Xd8PpnWk1RlgzSmuNjtK3 = '3'+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
		url = url.replace('/search',NdKhAS6MXVEORLTwob92pxlZ)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,145,NdKhAS6MXVEORLTwob92pxlZ,Xd8PpnWk1RlgzSmuNjtK3,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not zehVcU893FC6LEd1Aij:
		Xd8PpnWk1RlgzSmuNjtK3 = '3'+'::'+MLwenNmSRfz95ZK7Oaris+'::'+o0oBKgNUzTraeIcLuGvED1f+'::'+Fn9ZHUYao5x8K
		title = ':: '+title
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3,OzUD8iTmGp15Sn9VINMHq)
	elif '/browse' in zehVcU893FC6LEd1Aij and url==qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN:
		title = ':: '+title
		Xd8PpnWk1RlgzSmuNjtK3 = '2::0::0::0'
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3,OzUD8iTmGp15Sn9VINMHq)
	elif not zehVcU893FC6LEd1Aij and 'horizontalMovieListRenderer' in str(rMOG2USkPesYZD9KNAVqpc):
		title = ':: '+title
		Xd8PpnWk1RlgzSmuNjtK3 = '3::0::0::0'
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3)
	elif 'messageRenderer' in str(rMOG2USkPesYZD9KNAVqpc):
		ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+title,NdKhAS6MXVEORLTwob92pxlZ,9999)
	elif GX4QpS6hxrMt59g1KnaDd:
		ZI51XvE8YatWCmNdrp('live',LJfTAEQPv9h4BXdwUp+GX4QpS6hxrMt59g1KnaDd+title,zehVcU893FC6LEd1Aij,143,TTuPH708dUNnjlG3oQpkZsi)
	elif '/playlist?list=' in zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('&playnext=1',NdKhAS6MXVEORLTwob92pxlZ)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'LIST'+count+':  '+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3)
	elif '/shorts/' in zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split('&list=',1)[0]
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,143,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI)
	elif '/watch?v=' in zehVcU893FC6LEd1Aij:
		if '&list=' in zehVcU893FC6LEd1Aij and count:
			CCPud5HnVxESzYU6QsJXLRgK = zehVcU893FC6LEd1Aij.split('&list=',1)[1]
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/playlist?list='+CCPud5HnVxESzYU6QsJXLRgK
			Xd8PpnWk1RlgzSmuNjtK3 = '1::0::0::0'
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'LIST'+count+':  '+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3)
		else:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split('&list=',1)[0]
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,143,TTuPH708dUNnjlG3oQpkZsi,TLrSzM98nc2H3VODdyhpQI)
	elif '/channel/' in zehVcU893FC6LEd1Aij or '/c/' in zehVcU893FC6LEd1Aij or ('/@' in zehVcU893FC6LEd1Aij and zehVcU893FC6LEd1Aij.count('/')==3):
		if QBp28giCnayJzmZH6vYO:
			title = title.decode(YRvPKe2zMTDs8UCkr).encode('raw_unicode_escape')
			title = L5xKSr96JmaX7N(title)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'CHNL'+count+':  '+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3)
	elif '/user/' in zehVcU893FC6LEd1Aij:
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'USER'+count+':  '+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3)
	else:
		if not zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = url
		title = ':: '+title
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,144,TTuPH708dUNnjlG3oQpkZsi,Xd8PpnWk1RlgzSmuNjtK3,OzUD8iTmGp15Sn9VINMHq)
	return True
def nFVjam16AuTM(rMOG2USkPesYZD9KNAVqpc):
	PsKJk8XRHAQM,title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,count,TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd,nIyGbRwDjlemVgX873,JMox3q27Fi1Rd468Z = False,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	if not isinstance(rMOG2USkPesYZD9KNAVqpc,dict): return PsKJk8XRHAQM,title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,count,TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd,nIyGbRwDjlemVgX873,JMox3q27Fi1Rd468Z
	for MMmB7KwzHGpQUexEcA5DFZt in list(rMOG2USkPesYZD9KNAVqpc.keys()):
		IdT2y19C4WPZK3c = rMOG2USkPesYZD9KNAVqpc[MMmB7KwzHGpQUexEcA5DFZt]
		if isinstance(IdT2y19C4WPZK3c,dict): break
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	rdCjOq4fPEH.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	rdCjOq4fPEH.append("yrender['header']['richListHeaderRenderer']['title']")
	rdCjOq4fPEH.append("yrender['headline']['simpleText']")
	rdCjOq4fPEH.append("yrender['unplayableText']['simpleText']")
	rdCjOq4fPEH.append("yrender['formattedTitle']['simpleText']")
	rdCjOq4fPEH.append("yrender['title']['simpleText']")
	rdCjOq4fPEH.append("yrender['title']['runs'][0]['text']")
	rdCjOq4fPEH.append("yrender['text']['simpleText']")
	rdCjOq4fPEH.append("yrender['text']['runs'][0]['text']")
	rdCjOq4fPEH.append("yrender['title']['content']")
	rdCjOq4fPEH.append("yrender['title']")
	rdCjOq4fPEH.append("item['title']")
	rdCjOq4fPEH.append("item['reelWatchEndpoint']['videoId']")
	PsKJk8XRHAQM,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	rdCjOq4fPEH.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	rdCjOq4fPEH.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	rdCjOq4fPEH.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	rdCjOq4fPEH.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	rdCjOq4fPEH.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	rdCjOq4fPEH.append("item['commandMetadata']['webCommandMetadata']['url']")
	PsKJk8XRHAQM,zehVcU893FC6LEd1Aij,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['thumbnail']['thumbnails'][0]['url']")
	rdCjOq4fPEH.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	rdCjOq4fPEH.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	PsKJk8XRHAQM,TTuPH708dUNnjlG3oQpkZsi,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	rdCjOq4fPEH.append("yrender['videoCountShortText']['simpleText']")
	rdCjOq4fPEH.append("yrender['videoCountText']['runs'][0]['text']")
	rdCjOq4fPEH.append("yrender['videoCount']")
	PsKJk8XRHAQM,count,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	rdCjOq4fPEH.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	rdCjOq4fPEH.append("yrender['lengthText']['simpleText']")
	rdCjOq4fPEH.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	rdCjOq4fPEH.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	PsKJk8XRHAQM,TLrSzM98nc2H3VODdyhpQI,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	rdCjOq4fPEH = []
	rdCjOq4fPEH.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	rdCjOq4fPEH.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	PsKJk8XRHAQM,JMox3q27Fi1Rd468Z,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = D0OSXATbZant3(rMOG2USkPesYZD9KNAVqpc,IdT2y19C4WPZK3c,rdCjOq4fPEH)
	if 'LIVE' in TLrSzM98nc2H3VODdyhpQI: TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd = NdKhAS6MXVEORLTwob92pxlZ,'LIVE:  '
	if 'مباشر' in TLrSzM98nc2H3VODdyhpQI: TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd = NdKhAS6MXVEORLTwob92pxlZ,'LIVE:  '
	if 'badges' in list(IdT2y19C4WPZK3c.keys()):
		a1sXYcINKEqeLt = str(IdT2y19C4WPZK3c['badges'])
		if 'Free with Ads' in a1sXYcINKEqeLt: nIyGbRwDjlemVgX873 = '$:  '
		if 'LIVE' in a1sXYcINKEqeLt: GX4QpS6hxrMt59g1KnaDd = 'LIVE:  '
		if 'Buy' in a1sXYcINKEqeLt or 'Rent' in a1sXYcINKEqeLt: nIyGbRwDjlemVgX873 = '$$:  '
		if jBwT7etlxOuUgakyX6CL(u'مباشر') in a1sXYcINKEqeLt: GX4QpS6hxrMt59g1KnaDd = 'LIVE:  '
		if jBwT7etlxOuUgakyX6CL(u'شراء') in a1sXYcINKEqeLt: nIyGbRwDjlemVgX873 = '$$:  '
		if jBwT7etlxOuUgakyX6CL(u'استئجار') in a1sXYcINKEqeLt: nIyGbRwDjlemVgX873 = '$$:  '
		if jBwT7etlxOuUgakyX6CL(u'إعلانات') in a1sXYcINKEqeLt: nIyGbRwDjlemVgX873 = '$:  '
	zehVcU893FC6LEd1Aij = L5xKSr96JmaX7N(zehVcU893FC6LEd1Aij)
	if zehVcU893FC6LEd1Aij and 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
	TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.split('?')[0]
	if  TTuPH708dUNnjlG3oQpkZsi and 'http' not in TTuPH708dUNnjlG3oQpkZsi: TTuPH708dUNnjlG3oQpkZsi = 'https:'+TTuPH708dUNnjlG3oQpkZsi
	title = L5xKSr96JmaX7N(title)
	if nIyGbRwDjlemVgX873: title = nIyGbRwDjlemVgX873+title
	TLrSzM98nc2H3VODdyhpQI = TLrSzM98nc2H3VODdyhpQI.replace(',',NdKhAS6MXVEORLTwob92pxlZ)
	count = count.replace(',',NdKhAS6MXVEORLTwob92pxlZ)
	count = YYqECUofyi7wFrW.findall('\d+',count)
	if count: count = count[0]
	else: count = NdKhAS6MXVEORLTwob92pxlZ
	return True,title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,count,TLrSzM98nc2H3VODdyhpQI,GX4QpS6hxrMt59g1KnaDd,nIyGbRwDjlemVgX873,JMox3q27Fi1Rd468Z
def E4V9Yd5cvOJW8Rm7(url,data=NdKhAS6MXVEORLTwob92pxlZ,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	if kF13d0oJXn4xKH==NdKhAS6MXVEORLTwob92pxlZ: kF13d0oJXn4xKH = 'ytInitialData'
	VVBkbI2DtyaWw6mQp0 = kkCjlxiynwT34GVFc()
	omrd89nv0PGKFpL3TxfAXt = {'User-Agent':VVBkbI2DtyaWw6mQp0,'Cookie':'PREF=hl=ar'}
	global ptbWxl0eDEwc5PQaKR3XHzn4fF
	if not data: data = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.youtube.data')
	if data.count(':::')==4: HHhYctUFjAw04rg,key,aR4SpDYFyGOhAE,d9TXmPKf7iOx3jc4rW8QsuBIYU,JMox3q27Fi1Rd468Z = data.split(':::')
	else: HHhYctUFjAw04rg,key,aR4SpDYFyGOhAE,d9TXmPKf7iOx3jc4rW8QsuBIYU,JMox3q27Fi1Rd468Z = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	OzUD8iTmGp15Sn9VINMHq = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":aR4SpDYFyGOhAE}}}
	if url==qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/shorts' or '/my_main_page_shorts_link' in url:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		OzUD8iTmGp15Sn9VINMHq['sequenceParams'] = HHhYctUFjAw04rg
		OzUD8iTmGp15Sn9VINMHq = str(OzUD8iTmGp15Sn9VINMHq)
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',url,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/youtubei/v1/guide?key='+key
		OzUD8iTmGp15Sn9VINMHq = str(OzUD8iTmGp15Sn9VINMHq)
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',url,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and HHhYctUFjAw04rg:
		OzUD8iTmGp15Sn9VINMHq['continuation'] = JMox3q27Fi1Rd468Z
		OzUD8iTmGp15Sn9VINMHq['context']['client']['visitorData'] = HHhYctUFjAw04rg
		OzUD8iTmGp15Sn9VINMHq = str(OzUD8iTmGp15Sn9VINMHq)
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'POST',url,OzUD8iTmGp15Sn9VINMHq,omrd89nv0PGKFpL3TxfAXt,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and d9TXmPKf7iOx3jc4rW8QsuBIYU:
		omrd89nv0PGKFpL3TxfAXt.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':aR4SpDYFyGOhAE})
		omrd89nv0PGKFpL3TxfAXt.update({'Cookie':'VISITOR_INFO1_LIVE='+d9TXmPKf7iOx3jc4rW8QsuBIYU})
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'YOUTUBE-GET_PAGE_DATA-6th')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall('"innertubeApiKey".*?"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.I)
	if ekmszoF6UQAbHp9r0ug: key = ekmszoF6UQAbHp9r0ug[0]
	ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall('"cver".*?"value".*?"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.I)
	if ekmszoF6UQAbHp9r0ug: aR4SpDYFyGOhAE = ekmszoF6UQAbHp9r0ug[0]
	ekmszoF6UQAbHp9r0ug = YYqECUofyi7wFrW.findall('"visitorData".*?"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.I)
	if ekmszoF6UQAbHp9r0ug: HHhYctUFjAw04rg = ekmszoF6UQAbHp9r0ug[0]
	cookies = VNc1u4edS90FK5W6bsMgQC2B.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): d9TXmPKf7iOx3jc4rW8QsuBIYU = cookies['VISITOR_INFO1_LIVE']
	kkBqpgGSQIR6PhVOjNKAfH = HHhYctUFjAw04rg+':::'+key+':::'+aR4SpDYFyGOhAE+':::'+d9TXmPKf7iOx3jc4rW8QsuBIYU+':::'+JMox3q27Fi1Rd468Z
	if kF13d0oJXn4xKH=='ytInitialData' and 'ytInitialData' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		rQPv1iFLdyJsfKWEHT5XpaNw6n4 = YYqECUofyi7wFrW.findall('window\["ytInitialData"\] = ({.*?});',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not rQPv1iFLdyJsfKWEHT5XpaNw6n4: rQPv1iFLdyJsfKWEHT5XpaNw6n4 = YYqECUofyi7wFrW.findall('var ytInitialData = ({.*?});',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		JJlP3RKczCmZv1k6tDpw2AjyqfrM = BdnA8WwtJeKUVvE('str',rQPv1iFLdyJsfKWEHT5XpaNw6n4[0])
	elif kF13d0oJXn4xKH=='ytInitialGuideData' and 'ytInitialGuideData' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		rQPv1iFLdyJsfKWEHT5XpaNw6n4 = YYqECUofyi7wFrW.findall('var ytInitialGuideData = ({.*?});',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		JJlP3RKczCmZv1k6tDpw2AjyqfrM = BdnA8WwtJeKUVvE('str',rQPv1iFLdyJsfKWEHT5XpaNw6n4[0])
	elif '</script>' not in LMKFcEkU1Q7R80yt4OsgvwxbfP: JJlP3RKczCmZv1k6tDpw2AjyqfrM = BdnA8WwtJeKUVvE('str',LMKFcEkU1Q7R80yt4OsgvwxbfP)
	else: JJlP3RKczCmZv1k6tDpw2AjyqfrM = NdKhAS6MXVEORLTwob92pxlZ
	if 0:
		ZHRKwglmD9CSQefINvMTLxczAjWP = str(JJlP3RKczCmZv1k6tDpw2AjyqfrM)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: ZHRKwglmD9CSQefINvMTLxczAjWP = ZHRKwglmD9CSQefINvMTLxczAjWP.encode(YRvPKe2zMTDs8UCkr)
		open('S:\\0000emad.dat','wb').write(ZHRKwglmD9CSQefINvMTLxczAjWP)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.youtube.data',kkBqpgGSQIR6PhVOjNKAfH)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP,JJlP3RKczCmZv1k6tDpw2AjyqfrM,kkBqpgGSQIR6PhVOjNKAfH
def dvESi09LR7(url,Xd8PpnWk1RlgzSmuNjtK3):
	search = Z6GiHgnz0jNytc()
	if not search: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	BfjcMoqOsmdUvZVCHWIyQKi = url+'/search?query='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi,Xd8PpnWk1RlgzSmuNjtK3)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search:
		search = Z6GiHgnz0jNytc()
		if not search: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in LM1WpcGdrz8QtHV0i53k: DQLgakzOUcseAIGFYX49qdjbp = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in LM1WpcGdrz8QtHV0i53k: DQLgakzOUcseAIGFYX49qdjbp = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in LM1WpcGdrz8QtHV0i53k: DQLgakzOUcseAIGFYX49qdjbp = '&sp=EgIQAg%253D%253D'
		else: DQLgakzOUcseAIGFYX49qdjbp = NdKhAS6MXVEORLTwob92pxlZ
		Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi+DQLgakzOUcseAIGFYX49qdjbp
	else:
		FCrsASNvW02TguaBtmX74d,ck7691EeJVL2ZXRT3BYAMdSiloGHK,PJN58A9SFZTwi6uLMB73m = [],[],NdKhAS6MXVEORLTwob92pxlZ
		f5DYjuszdNerbVEPvQJ = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		PwTO5EaK8I0kn2VhsCzurUjW7mfvcQ = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		ggVEnmYptys2SQxLizkchHCrleAa9 = cCanV8J9iKuojqe5v4('اختر البحث المناسب',f5DYjuszdNerbVEPvQJ)
		if ggVEnmYptys2SQxLizkchHCrleAa9 == -1: return
		q6GKHjDkB58sO1odX73 = PwTO5EaK8I0kn2VhsCzurUjW7mfvcQ[ggVEnmYptys2SQxLizkchHCrleAa9]
		LMKFcEkU1Q7R80yt4OsgvwxbfP,pcQlFNW6bOh,data = E4V9Yd5cvOJW8Rm7(BfjcMoqOsmdUvZVCHWIyQKi+q6GKHjDkB58sO1odX73)
		if pcQlFNW6bOh:
			try:
				bylPH8wh97mORr0kjx = pcQlFNW6bOh['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for wrcHI0xyZdMRQUq5m4ezb in range(len(bylPH8wh97mORr0kjx)):
					group = bylPH8wh97mORr0kjx[wrcHI0xyZdMRQUq5m4ezb]['searchFilterGroupRenderer']['filters']
					for iSs4QbW3kfNd8 in range(len(group)):
						IdT2y19C4WPZK3c = group[iSs4QbW3kfNd8]['searchFilterRenderer']
						if 'navigationEndpoint' in list(IdT2y19C4WPZK3c.keys()):
							zehVcU893FC6LEd1Aij = IdT2y19C4WPZK3c['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace('\u0026','&')
							title = IdT2y19C4WPZK3c['tooltip']
							title = title.replace('البحث عن ',NdKhAS6MXVEORLTwob92pxlZ)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								PJN58A9SFZTwi6uLMB73m = title
								xKXbWz9coR7jUfil45aQENr0ICBJg = zehVcU893FC6LEd1Aij
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',NdKhAS6MXVEORLTwob92pxlZ)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								PJN58A9SFZTwi6uLMB73m = title
								xKXbWz9coR7jUfil45aQENr0ICBJg = zehVcU893FC6LEd1Aij
							if 'Sort by' in title: continue
							FCrsASNvW02TguaBtmX74d.append(L5xKSr96JmaX7N(title))
							ck7691EeJVL2ZXRT3BYAMdSiloGHK.append(zehVcU893FC6LEd1Aij)
			except: pass
		if not PJN58A9SFZTwi6uLMB73m: cCqoPT2Hw7e3G61NKJ = NdKhAS6MXVEORLTwob92pxlZ
		else:
			FCrsASNvW02TguaBtmX74d = ['بدون فلتر',PJN58A9SFZTwi6uLMB73m]+FCrsASNvW02TguaBtmX74d
			ck7691EeJVL2ZXRT3BYAMdSiloGHK = [NdKhAS6MXVEORLTwob92pxlZ,xKXbWz9coR7jUfil45aQENr0ICBJg]+ck7691EeJVL2ZXRT3BYAMdSiloGHK
			S5XbJGrugxYDc2eZf = cCanV8J9iKuojqe5v4('موقع يوتيوب - اختر الفلتر',FCrsASNvW02TguaBtmX74d)
			if S5XbJGrugxYDc2eZf == -1: return
			cCqoPT2Hw7e3G61NKJ = ck7691EeJVL2ZXRT3BYAMdSiloGHK[S5XbJGrugxYDc2eZf]
		if cCqoPT2Hw7e3G61NKJ: Afey3cL4ojzg = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+cCqoPT2Hw7e3G61NKJ
		elif q6GKHjDkB58sO1odX73: Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi+q6GKHjDkB58sO1odX73
		else: Afey3cL4ojzg = BfjcMoqOsmdUvZVCHWIyQKi
	hGJKk8tAiC3XFufEpqavQWmwTHdL(Afey3cL4ojzg)
	return
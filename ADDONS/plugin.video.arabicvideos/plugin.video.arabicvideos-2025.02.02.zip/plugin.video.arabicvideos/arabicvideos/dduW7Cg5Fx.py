# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
qaD1Jv7VWbMoI04Bx8UkrC9XQOh = 'IPTV'
vzAmZXEiDGPInYHrlF3bLK57yte4Uj = '_IPT_'
RPM1AYqXgjEpiVmrSGoyxWu3Cd5 = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def mxnEVjz6b3v(pPrvqm3tjuXLTgw1,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI,oJeO8LqTXi7W,nnkBNQrAK1SmzpfYD0j,ww1lsWcSe2Cd):
	global vzAmZXEiDGPInYHrlF3bLK57yte4Uj
	try:
		n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 = str(ww1lsWcSe2Cd['folder'])
		vzAmZXEiDGPInYHrlF3bLK57yte4Uj = '_IP'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0+'_'
	except: n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 = NdKhAS6MXVEORLTwob92pxlZ
	if   pPrvqm3tjuXLTgw1==230: CCXjewWZpg = Okf27SFxldwuPArYQoZaVWIGisJ()
	elif pPrvqm3tjuXLTgw1==231: CCXjewWZpg = vP5ik0AFSOgLy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==232: CCXjewWZpg = u5xpT7GVv9HEFwX1Jli(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==233: CCXjewWZpg = RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI,nnkBNQrAK1SmzpfYD0j)
	elif pPrvqm3tjuXLTgw1==234: CCXjewWZpg = Hn70PSCVdsEvRXKz(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI,nnkBNQrAK1SmzpfYD0j)
	elif pPrvqm3tjuXLTgw1==235: CCXjewWZpg = uuvhoSanB2TWD(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,oJeO8LqTXi7W)
	elif pPrvqm3tjuXLTgw1==236: CCXjewWZpg = cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True)
	elif pPrvqm3tjuXLTgw1==237: CCXjewWZpg = OOKMeIaUPtBYi1CsJy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True)
	elif pPrvqm3tjuXLTgw1==238: CCXjewWZpg = AAjh6JMSqFpzsR9mknVBiorK3PbU(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==239: CCXjewWZpg = vQHGIF21bUxu9ByzEsXrewmAchVZM(ui7N5YGR9KdslpEbQkVTwFqDgI,n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,nnkBNQrAK1SmzpfYD0j)
	elif pPrvqm3tjuXLTgw1==280: CCXjewWZpg = ILukXJh2lbAiTvHMm(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True)
	elif pPrvqm3tjuXLTgw1==281: CCXjewWZpg = JbGCRM586yE91VWgmv2pxk(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==282: CCXjewWZpg = AIigTdEx6DUuZOe7XS34B0w(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==283: CCXjewWZpg = qJpAc18aTmrt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==285: CCXjewWZpg = b9bgkQrYWZO30jRS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,ui7N5YGR9KdslpEbQkVTwFqDgI)
	elif pPrvqm3tjuXLTgw1==286: CCXjewWZpg = O4I6JnAhPtSWZ5rUj0lBGu3XY(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	elif pPrvqm3tjuXLTgw1==289: CCXjewWZpg = ti3AxKdPBOMs(ui7N5YGR9KdslpEbQkVTwFqDgI,n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,nnkBNQrAK1SmzpfYD0j)
	else: CCXjewWZpg = False
	return CCXjewWZpg
def Okf27SFxldwuPArYQoZaVWIGisJ():
	for n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 in range(1,zWinZrBTwI3stoS7+1):
		vzAmZXEiDGPInYHrlF3bLK57yte4Uj = '_IP'+str(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)+'_'
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قائمة مجلد '+omh6YcDWKgIBkNG3[n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0],NdKhAS6MXVEORLTwob92pxlZ,280,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	return
def ILukXJh2lbAiTvHMm(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0=NdKhAS6MXVEORLTwob92pxlZ,vGYPOQXBhywrVcDAnaENWRuljZx=NdKhAS6MXVEORLTwob92pxlZ):
	if n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0:
		oGj2iIu06c = {'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}
		H4g8eAZ2bpJYyOniS3mscQo9FaPW = NdKhAS6MXVEORLTwob92pxlZ
	else:
		oGj2iIu06c = NdKhAS6MXVEORLTwob92pxlZ
		H4g8eAZ2bpJYyOniS3mscQo9FaPW = NdKhAS6MXVEORLTwob92pxlZ
	FaXlUmRIsDjwdqe2G3AzCbh78 = vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx)
	if not FaXlUmRIsDjwdqe2G3AzCbh78:
		ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+D7INg5kyRjwf4ZtoePVUrb1h2SJ+' إضافة أو تغيير اشتراك'+H4g8eAZ2bpJYyOniS3mscQo9FaPW+' '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,231,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+D7INg5kyRjwf4ZtoePVUrb1h2SJ+' جلب ملفات'+H4g8eAZ2bpJYyOniS3mscQo9FaPW+' '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,232,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	else:
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'بحث في الملفات'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,289,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_',NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مصنفة مرتبة'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مصنفة من القسم'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_FROM_GROUP_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مصنفة من الاسم'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_FROM_NAME_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مصنفة بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_ORIGINAL_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مجهولة مرتبة'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_UNKNOWN_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'قنوات مجهولة بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_UNKNOWN_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أفلام مصنفة بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_MOVIES_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أفلام مصنفة مرتبة'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_MOVIES_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'مسلسلات مصنفة بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_SERIES_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'مسلسلات مصنفة مرتبة'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_SERIES_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فيديوهات بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_ORIGINAL_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فيديوهات مصنفة من القسم'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_FROM_GROUP_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فيديوهات مصنفة من الاسم'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_FROM_NAME_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فيديوهات مجهولة بلا ترتيب'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_UNKNOWN_GROUPED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فيديوهات مجهولة مرتبة'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'VOD_UNKNOWN_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'برامج القنوات (جدول فقط)'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_EPG_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أرشيف القنوات للأيام الماضية'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_TIMESHIFT_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أرشيف برامج القنوات للأيام الماضية'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,'LIVE_ARCHIVED_GROUPED_SORTED',233,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'إضافة أو تغيير اشتراك'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,231,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'جلب ملفات'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,232,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'مسح ملفات'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,237,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'فحص اشتراك'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,236,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'عدد فيديوهات'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,281,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'Referer تغيير'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,286,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'User-Agent تغيير'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,283,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'استخدم السيرفر الأسرع'+H4g8eAZ2bpJYyOniS3mscQo9FaPW,NdKhAS6MXVEORLTwob92pxlZ,282,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,oGj2iIu06c)
	return
def cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	jjztPcUT2HIApNRdLhw,ttG3HFhpQEXj45IPObwiDLU = False,NdKhAS6MXVEORLTwob92pxlZ
	z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2 = HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if qfRW2x4uosEYZJ59Kl6mLcQ==NdKhAS6MXVEORLTwob92pxlZ: return False,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	RpYN2DWoKIbUHuL = uOagfXTyh4zjYP6plMbsnSe(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if APgYxb0Ksd:
		KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET',APgYxb0Ksd,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,False,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-CHECK_ACCOUNT-1st')
		JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
		if KgjQPrdmkW0pZfiwx9e6qL.succeeded:
			HOjCdxLUIVgD2K97YJ8lnMbScTR5,abMLKnYcoX1hVU8iCyqQRsGONkE,Ad2t9cYX6jOTZHGFD48iQIbsq,O2OqPcpX1lija7,RD8cpU1smkSvbhoi20d = 0,0,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
			try:
				GzemS02YIZMnwNxAoC = BdnA8WwtJeKUVvE('dict',JIVXou7hYWQ6CKDsPOUytnml3e9)
				ttG3HFhpQEXj45IPObwiDLU = GzemS02YIZMnwNxAoC['user_info']['status']
				jjztPcUT2HIApNRdLhw = True
				Ad2t9cYX6jOTZHGFD48iQIbsq = GzemS02YIZMnwNxAoC['server_info']['time_now']
			except: pass
			if Ad2t9cYX6jOTZHGFD48iQIbsq:
				try:
					Tby0jB7xtZvVzIAK9hidRa2FX = XJ62UBRmIqFvfiNTQj.strptime(Ad2t9cYX6jOTZHGFD48iQIbsq,'%Y.%m.%d %H:%M:%S')
					HOjCdxLUIVgD2K97YJ8lnMbScTR5 = int(XJ62UBRmIqFvfiNTQj.mktime(Tby0jB7xtZvVzIAK9hidRa2FX))
					abMLKnYcoX1hVU8iCyqQRsGONkE = int(MMQhDpyCenmO350aBAKVYk-HOjCdxLUIVgD2K97YJ8lnMbScTR5)
					abMLKnYcoX1hVU8iCyqQRsGONkE = int((abMLKnYcoX1hVU8iCyqQRsGONkE+900)/1800)*1800
				except: pass
				try:
					Tby0jB7xtZvVzIAK9hidRa2FX = XJ62UBRmIqFvfiNTQj.localtime(int(GzemS02YIZMnwNxAoC['user_info']['created_at']))
					O2OqPcpX1lija7 = XJ62UBRmIqFvfiNTQj.strftime('%Y.%m.%d %H:%M:%S',Tby0jB7xtZvVzIAK9hidRa2FX)
				except: pass
				try:
					Tby0jB7xtZvVzIAK9hidRa2FX = XJ62UBRmIqFvfiNTQj.localtime(int(GzemS02YIZMnwNxAoC['user_info']['exp_date']))
					RD8cpU1smkSvbhoi20d = XJ62UBRmIqFvfiNTQj.strftime('%Y.%m.%d %H:%M:%S',Tby0jB7xtZvVzIAK9hidRa2FX)
				except: pass
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.timestamp_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,str(MMQhDpyCenmO350aBAKVYk))
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.timediff_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,str(abMLKnYcoX1hVU8iCyqQRsGONkE))
			try:
				fG8NTk0C9UuZyqnhBRAOmJwtPWld47 = '"server_info":'+JIVXou7hYWQ6CKDsPOUytnml3e9.split('"server_info":')[1]
				fG8NTk0C9UuZyqnhBRAOmJwtPWld47 = fG8NTk0C9UuZyqnhBRAOmJwtPWld47.replace(':',': ').replace(',',', ').replace('}}','}')
				GkjtU2JcRuQXz4 = YYqECUofyi7wFrW.findall('"url": "(.*?)", "port": "(.*?)"',fG8NTk0C9UuZyqnhBRAOmJwtPWld47,YYqECUofyi7wFrW.DOTALL)
				z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = GkjtU2JcRuQXz4[0]
			except: jjztPcUT2HIApNRdLhw = False
			if jjztPcUT2HIApNRdLhw and vGYPOQXBhywrVcDAnaENWRuljZx:
				max = GzemS02YIZMnwNxAoC['user_info']['max_connections']
				x6K4BaC0JX1VdPpgwFE = GzemS02YIZMnwNxAoC['user_info']['active_cons']
				I35EUZQdkysYKCANBzxXM = GzemS02YIZMnwNxAoC['user_info']['is_trial']
				fqjCLHdYoekZO8i1cpKT = APgYxb0Ksd.split('?',1)
				JzNoqV8ClRD6O = 'URL:  '+Whef0cxB2iR93SC5IwUtk+APgYxb0Ksd+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\n\nStatus:  '+Whef0cxB2iR93SC5IwUtk+ttG3HFhpQEXj45IPObwiDLU+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\nTrial:    '+Whef0cxB2iR93SC5IwUtk+str(I35EUZQdkysYKCANBzxXM=='1')+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\nCreated  At:  '+Whef0cxB2iR93SC5IwUtk+O2OqPcpX1lija7+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\nExpiry Date:  '+Whef0cxB2iR93SC5IwUtk+RD8cpU1smkSvbhoi20d+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\nConnections   ( Active / Maximum ) :  '+Whef0cxB2iR93SC5IwUtk+x6K4BaC0JX1VdPpgwFE+' / '+max+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\nAllowed Outputs:   '+Whef0cxB2iR93SC5IwUtk+" , ".join(GzemS02YIZMnwNxAoC['user_info']['allowed_output_formats'])+kjd9LyNqQHMUevZiRI7OlBGF1h
				JzNoqV8ClRD6O += '\n\n'+fG8NTk0C9UuZyqnhBRAOmJwtPWld47
				if ttG3HFhpQEXj45IPObwiDLU=='Active': AGLwyhimZ4uT5qjd0K('الاشتراك يعمل بدون مشاكل',JzNoqV8ClRD6O)
				else: AGLwyhimZ4uT5qjd0K('يبدو أن هناك مشكلة في الاشتراك',JzNoqV8ClRD6O)
	if APgYxb0Ksd and jjztPcUT2HIApNRdLhw and ttG3HFhpQEXj45IPObwiDLU=='Active':
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+APgYxb0Ksd+' ]')
		wylQWMjqTHrgxz = True
	else:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,'Checking IPTV URL   [ Does not work ]   [ '+APgYxb0Ksd+' ]')
		if vGYPOQXBhywrVcDAnaENWRuljZx: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		wylQWMjqTHrgxz = False
	return wylQWMjqTHrgxz,z1EemnPD4UaMC,TKIqiGcdpOlZEXD3
def Hn70PSCVdsEvRXKz(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON,PNVChFSnk4HEBwGTKd5m0,GGju2D5QzAeFLfB,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	if not GGju2D5QzAeFLfB: GGju2D5QzAeFLfB = '1'
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx): return
	H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON)
	f0CWuX47GAHBsNeQIVoxlZp1Ln = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list',vHWoXGczON,PNVChFSnk4HEBwGTKd5m0)
	cv7noMaZA1xyfGqU = int(GGju2D5QzAeFLfB)*100
	wajml8bIqCJShpkB6uiWM4tdE2D53Z = cv7noMaZA1xyfGqU-100
	for ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex in f0CWuX47GAHBsNeQIVoxlZp1Ln[wajml8bIqCJShpkB6uiWM4tdE2D53Z:cv7noMaZA1xyfGqU]:
		s1s0Ro2vAeDXG9wapJEk4O = ('GROUPED' in vHWoXGczON or vHWoXGczON=='ALL')
		OhN8Iwg5TH39YCvf = ('GROUPED' not in vHWoXGczON and vHWoXGczON!='ALL')
		if s1s0Ro2vAeDXG9wapJEk4O or OhN8Iwg5TH39YCvf:
			if   'ARCHIVED'  in vHWoXGczON: emiIH49XT6jzOQrw.append(['folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,238,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,'ARCHIVED',NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}])
			elif 'EPG' 		 in vHWoXGczON: emiIH49XT6jzOQrw.append(['folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,238,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,'FULL_EPG',NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}])
			elif 'TIMESHIFT' in vHWoXGczON: emiIH49XT6jzOQrw.append(['folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,238,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,'TIMESHIFT',NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}])
			elif 'LIVE' 	 in vHWoXGczON: emiIH49XT6jzOQrw.append(['live',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,235,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ueFHThK2pDYc,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}])
			else: emiIH49XT6jzOQrw.append(['video',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,235,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0}])
	HLxXen3Wgy9QhIJzYSjtadG = len(f0CWuX47GAHBsNeQIVoxlZp1Ln)
	vBGAzWDix8LQoFljXCIpw3uKVZ(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,GGju2D5QzAeFLfB,vHWoXGczON,234,HLxXen3Wgy9QhIJzYSjtadG,PNVChFSnk4HEBwGTKd5m0)
	return
def S9yrdJZp8h0coYz7E6t1w(k5ldQyZzAFMDChtXwrLxqG7m):
	ZI51XvE8YatWCmNdrp('link',k5ldQyZzAFMDChtXwrLxqG7m+'هذه القائمة إما فارغة أو غير موجودة',NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('link',k5ldQyZzAFMDChtXwrLxqG7m+'أو الخدمة غير موجودة في اشتراكك',NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('link',k5ldQyZzAFMDChtXwrLxqG7m+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',NdKhAS6MXVEORLTwob92pxlZ,9999)
	return
def RTeM4nCOkqvFZtzaL0WgdBDsp1jP5l(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON,PNVChFSnk4HEBwGTKd5m0,GGju2D5QzAeFLfB,I5PKRXr82cyjbo=NdKhAS6MXVEORLTwob92pxlZ,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	if not GGju2D5QzAeFLfB: GGju2D5QzAeFLfB = '1'
	k5ldQyZzAFMDChtXwrLxqG7m = vzAmZXEiDGPInYHrlF3bLK57yte4Uj
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx): return False
	if '__SERIES__' in PNVChFSnk4HEBwGTKd5m0: E8MSnFbuVof3RqLmG,NGAo1d7Z4Obp5lkLymIwxizf = PNVChFSnk4HEBwGTKd5m0.split('__SERIES__')
	else: E8MSnFbuVof3RqLmG,NGAo1d7Z4Obp5lkLymIwxizf = PNVChFSnk4HEBwGTKd5m0,NdKhAS6MXVEORLTwob92pxlZ
	H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON)
	DDSMWfVtINn = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list',vHWoXGczON,'__GROUPS__')
	if not DDSMWfVtINn: return False
	TbGlgmdN9iCI3ZYUx = []
	for ucBCXwgzfPhHRx2NnjGQ,SGsBInjFVT12LOhzCafex in DDSMWfVtINn:
		if I5PKRXr82cyjbo:
			if '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ: k5ldQyZzAFMDChtXwrLxqG7m = 'SERIES'
			elif '!!__UNKNOWN__!!' in ucBCXwgzfPhHRx2NnjGQ: k5ldQyZzAFMDChtXwrLxqG7m = 'UNKNOWN'
			elif 'LIVE' in vHWoXGczON: k5ldQyZzAFMDChtXwrLxqG7m = 'LIVE'
			else: k5ldQyZzAFMDChtXwrLxqG7m = 'VIDEOS'
			k5ldQyZzAFMDChtXwrLxqG7m = ','+Whef0cxB2iR93SC5IwUtk+k5ldQyZzAFMDChtXwrLxqG7m+': '+kjd9LyNqQHMUevZiRI7OlBGF1h
		if '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ: bGjgpEXoYZuAeR8f127KT4OhNMckV,jo01ZIwOuYcDGefPQLkbTpqv = ucBCXwgzfPhHRx2NnjGQ.split('__SERIES__')
		else: bGjgpEXoYZuAeR8f127KT4OhNMckV,jo01ZIwOuYcDGefPQLkbTpqv = ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ
		if not PNVChFSnk4HEBwGTKd5m0:
			if bGjgpEXoYZuAeR8f127KT4OhNMckV in TbGlgmdN9iCI3ZYUx: continue
			TbGlgmdN9iCI3ZYUx.append(bGjgpEXoYZuAeR8f127KT4OhNMckV)
			if 'RANDOM' in I5PKRXr82cyjbo: ZI51XvE8YatWCmNdrp('folder',k5ldQyZzAFMDChtXwrLxqG7m+bGjgpEXoYZuAeR8f127KT4OhNMckV,vHWoXGczON,167,NdKhAS6MXVEORLTwob92pxlZ,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
			elif '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ: ZI51XvE8YatWCmNdrp('folder',k5ldQyZzAFMDChtXwrLxqG7m+bGjgpEXoYZuAeR8f127KT4OhNMckV,vHWoXGczON,233,NdKhAS6MXVEORLTwob92pxlZ,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
			else: ZI51XvE8YatWCmNdrp('folder',k5ldQyZzAFMDChtXwrLxqG7m+bGjgpEXoYZuAeR8f127KT4OhNMckV,vHWoXGczON,234,NdKhAS6MXVEORLTwob92pxlZ,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
		elif '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ and bGjgpEXoYZuAeR8f127KT4OhNMckV==E8MSnFbuVof3RqLmG:
			if jo01ZIwOuYcDGefPQLkbTpqv in TbGlgmdN9iCI3ZYUx: continue
			TbGlgmdN9iCI3ZYUx.append(jo01ZIwOuYcDGefPQLkbTpqv)
			if 'RANDOM' in I5PKRXr82cyjbo: ZI51XvE8YatWCmNdrp('folder',k5ldQyZzAFMDChtXwrLxqG7m+jo01ZIwOuYcDGefPQLkbTpqv,vHWoXGczON,167,NdKhAS6MXVEORLTwob92pxlZ,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
			else: ZI51XvE8YatWCmNdrp('folder',k5ldQyZzAFMDChtXwrLxqG7m+jo01ZIwOuYcDGefPQLkbTpqv,vHWoXGczON,234,SGsBInjFVT12LOhzCafex,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	emiIH49XT6jzOQrw[:] = sorted(emiIH49XT6jzOQrw,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq[1].lower())
	if not I5PKRXr82cyjbo:
		cv7noMaZA1xyfGqU = int(GGju2D5QzAeFLfB)*100
		wajml8bIqCJShpkB6uiWM4tdE2D53Z = cv7noMaZA1xyfGqU-100
		HLxXen3Wgy9QhIJzYSjtadG = len(emiIH49XT6jzOQrw)
		emiIH49XT6jzOQrw[:] = emiIH49XT6jzOQrw[wajml8bIqCJShpkB6uiWM4tdE2D53Z:cv7noMaZA1xyfGqU]
		vBGAzWDix8LQoFljXCIpw3uKVZ(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,GGju2D5QzAeFLfB,vHWoXGczON,233,HLxXen3Wgy9QhIJzYSjtadG,PNVChFSnk4HEBwGTKd5m0)
	return True
def AAjh6JMSqFpzsR9mknVBiorK3PbU(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,y79WgHOJvC8):
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True): return
	RpYN2DWoKIbUHuL = uOagfXTyh4zjYP6plMbsnSe(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	HOjCdxLUIVgD2K97YJ8lnMbScTR5 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.timestamp_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if not HOjCdxLUIVgD2K97YJ8lnMbScTR5 or MMQhDpyCenmO350aBAKVYk-int(HOjCdxLUIVgD2K97YJ8lnMbScTR5)>24*lvmy4BZ6Reqb:
		wylQWMjqTHrgxz,z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,False)
		if not wylQWMjqTHrgxz: return
	abMLKnYcoX1hVU8iCyqQRsGONkE = int(ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.timediff_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0))
	yP4kQfHATSoOt7CZVp8D = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.server_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	qfRW2x4uosEYZJ59Kl6mLcQ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.username_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	sXz6et9qU5DR0cBhyQ7TlML2 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.password_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	OHUs9WrAwuZojepit1B = TixSXhpW69Uba4f1NPqzYE7JcZ.split('/')
	uXRI2WDbt3qyMgYUcBGaFNzwLdTl = OHUs9WrAwuZojepit1B[-1].replace('.ts',NdKhAS6MXVEORLTwob92pxlZ).replace('.m3u8',NdKhAS6MXVEORLTwob92pxlZ)
	if y79WgHOJvC8=='SHORT_EPG': O9qzDctrfSgN = 'get_short_epg'
	else: O9qzDctrfSgN = 'get_simple_data_table'
	APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2 = HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if not qfRW2x4uosEYZJ59Kl6mLcQ: return
	T0Y92OcbS5R8 = APgYxb0Ksd+'&action='+O9qzDctrfSgN+'&stream_id='+uXRI2WDbt3qyMgYUcBGaFNzwLdTl
	JIVXou7hYWQ6CKDsPOUytnml3e9 = AxUpBa0g6wYCKohf2F9bqH(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,T0Y92OcbS5R8,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-EPG_ITEMS-2nd')
	XbprP02gmWqHkezjAanNu3 = BdnA8WwtJeKUVvE('dict',JIVXou7hYWQ6CKDsPOUytnml3e9)
	uuWlgqZ9jybGhfi2tRmXBsew8CQLY5 = XbprP02gmWqHkezjAanNu3['epg_listings']
	KKeUOrovBVd4SR = []
	if y79WgHOJvC8 in ['ARCHIVED','TIMESHIFT']:
		for GzemS02YIZMnwNxAoC in uuWlgqZ9jybGhfi2tRmXBsew8CQLY5:
			if GzemS02YIZMnwNxAoC['has_archive']==1:
				KKeUOrovBVd4SR.append(GzemS02YIZMnwNxAoC)
				if y79WgHOJvC8 in ['TIMESHIFT']: break
		if not KKeUOrovBVd4SR: return
		ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+Whef0cxB2iR93SC5IwUtk+'الملفات الأولي بهذه القائمة قد لا تعمل'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		if y79WgHOJvC8 in ['TIMESHIFT']:
			WvtVwK04JLN29lbozAYQ = 2
			dpawOusxYMVEC1lF7kDRzhQenAGj = WvtVwK04JLN29lbozAYQ*lvmy4BZ6Reqb
			KKeUOrovBVd4SR = []
			s6IZo9UmVapxWwLq82FMNA7 = int(int(GzemS02YIZMnwNxAoC['start_timestamp'])/dpawOusxYMVEC1lF7kDRzhQenAGj)*dpawOusxYMVEC1lF7kDRzhQenAGj
			x6tdcsYJD0o24EAOl7CnmWZjqhHy = MMQhDpyCenmO350aBAKVYk+dpawOusxYMVEC1lF7kDRzhQenAGj
			fFb1eWIVhXDRT6NMB = int((x6tdcsYJD0o24EAOl7CnmWZjqhHy-s6IZo9UmVapxWwLq82FMNA7)/lvmy4BZ6Reqb)
			for Gg8apTf0hM3 in range(fFb1eWIVhXDRT6NMB):
				if Gg8apTf0hM3>=6:
					if Gg8apTf0hM3%WvtVwK04JLN29lbozAYQ!=0: continue
					OJGK8zCMqWQ = dpawOusxYMVEC1lF7kDRzhQenAGj
				else: OJGK8zCMqWQ = dpawOusxYMVEC1lF7kDRzhQenAGj//2
				kCY9R6wFVTo7s3BAtUp1SMq = s6IZo9UmVapxWwLq82FMNA7+Gg8apTf0hM3*lvmy4BZ6Reqb
				GzemS02YIZMnwNxAoC = {}
				GzemS02YIZMnwNxAoC['title'] = NdKhAS6MXVEORLTwob92pxlZ
				Tby0jB7xtZvVzIAK9hidRa2FX = XJ62UBRmIqFvfiNTQj.localtime(kCY9R6wFVTo7s3BAtUp1SMq-abMLKnYcoX1hVU8iCyqQRsGONkE-lvmy4BZ6Reqb)
				GzemS02YIZMnwNxAoC['start'] = XJ62UBRmIqFvfiNTQj.strftime('%Y.%m.%d %H:%M:%S',Tby0jB7xtZvVzIAK9hidRa2FX)
				GzemS02YIZMnwNxAoC['start_timestamp'] = str(kCY9R6wFVTo7s3BAtUp1SMq)
				GzemS02YIZMnwNxAoC['stop_timestamp'] = str(kCY9R6wFVTo7s3BAtUp1SMq+OJGK8zCMqWQ)
				KKeUOrovBVd4SR.append(GzemS02YIZMnwNxAoC)
	elif y79WgHOJvC8 in ['SHORT_EPG','FULL_EPG']: KKeUOrovBVd4SR = uuWlgqZ9jybGhfi2tRmXBsew8CQLY5
	if y79WgHOJvC8=='FULL_EPG' and len(KKeUOrovBVd4SR)>0:
		ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+Whef0cxB2iR93SC5IwUtk+'هذه قائمة برامج القنوات (جدول فقط)ـ'+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Z928bSfpkiL5Y0AXouIx = []
	SGsBInjFVT12LOhzCafex = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Icon')
	for GzemS02YIZMnwNxAoC in KKeUOrovBVd4SR:
		pmAFLa7SRWhcK5dn6DxrwYO = NHsYdVBpXn.b64decode(GzemS02YIZMnwNxAoC['title'])
		if J92gCnbGWidQV70lBteTwU6D8uyzL: pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.decode(YRvPKe2zMTDs8UCkr)
		kCY9R6wFVTo7s3BAtUp1SMq = int(GzemS02YIZMnwNxAoC['start_timestamp'])
		vIC02zENlUpVJ58DQLXcOKs = int(GzemS02YIZMnwNxAoC['stop_timestamp'])
		W91iuYBIvmZhq2jyKxSQAJ5Fep = str(int((vIC02zENlUpVJ58DQLXcOKs-kCY9R6wFVTo7s3BAtUp1SMq+59)/60))
		zA8a16q4educLBvSZPNDTk5bwgpijI = GzemS02YIZMnwNxAoC['start'].replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,':')
		Tby0jB7xtZvVzIAK9hidRa2FX = XJ62UBRmIqFvfiNTQj.localtime(kCY9R6wFVTo7s3BAtUp1SMq-lvmy4BZ6Reqb)
		NygjkhBJmHdDe = XJ62UBRmIqFvfiNTQj.strftime('%H:%M',Tby0jB7xtZvVzIAK9hidRa2FX)
		RexLuk93C4lV5nONaGX8WyiAt6YHE = XJ62UBRmIqFvfiNTQj.strftime('%a',Tby0jB7xtZvVzIAK9hidRa2FX)
		if y79WgHOJvC8=='SHORT_EPG': pmAFLa7SRWhcK5dn6DxrwYO = D7INg5kyRjwf4ZtoePVUrb1h2SJ+NygjkhBJmHdDe+' ـ '+pmAFLa7SRWhcK5dn6DxrwYO+kjd9LyNqQHMUevZiRI7OlBGF1h
		elif y79WgHOJvC8=='TIMESHIFT': pmAFLa7SRWhcK5dn6DxrwYO = RexLuk93C4lV5nONaGX8WyiAt6YHE+Vwgflszp4WRA93kx6hvdua21HX5cOb+NygjkhBJmHdDe+' ('+W91iuYBIvmZhq2jyKxSQAJ5Fep+'min)'
		else: pmAFLa7SRWhcK5dn6DxrwYO = RexLuk93C4lV5nONaGX8WyiAt6YHE+Vwgflszp4WRA93kx6hvdua21HX5cOb+NygjkhBJmHdDe+' ('+W91iuYBIvmZhq2jyKxSQAJ5Fep+'min)   '+pmAFLa7SRWhcK5dn6DxrwYO+' ـ'
		if y79WgHOJvC8 in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			Lh6w2TefzP = yP4kQfHATSoOt7CZVp8D+'/timeshift/'+qfRW2x4uosEYZJ59Kl6mLcQ+'/'+sXz6et9qU5DR0cBhyQ7TlML2+'/'+W91iuYBIvmZhq2jyKxSQAJ5Fep+'/'+zA8a16q4educLBvSZPNDTk5bwgpijI+'/'+uXRI2WDbt3qyMgYUcBGaFNzwLdTl+'.m3u8'
			if y79WgHOJvC8=='FULL_EPG': ZI51XvE8YatWCmNdrp('link',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,Lh6w2TefzP,9999,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
			else: ZI51XvE8YatWCmNdrp('video',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,Lh6w2TefzP,235,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
		Z928bSfpkiL5Y0AXouIx.append(pmAFLa7SRWhcK5dn6DxrwYO)
	if y79WgHOJvC8=='SHORT_EPG' and Z928bSfpkiL5Y0AXouIx: q2Fnt8jfSJ4QgKPYbkoD7lvWC6pcew = eYEZS7Nzmd3jXyFq4(Z928bSfpkiL5Y0AXouIx)
	return Z928bSfpkiL5Y0AXouIx
def AIigTdEx6DUuZOe7XS34B0w(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True): return
	yP4kQfHATSoOt7CZVp8D,v2vVnemKRZs7pB9hU,owmxqFRuAIH5yEe41CMkdj76g9 = NdKhAS6MXVEORLTwob92pxlZ,0,0
	wylQWMjqTHrgxz,z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,False)
	if wylQWMjqTHrgxz:
		QqdHIgaWXYNsmifj4zGkREhoUD = kohKPuQdZrpUVOljAcy9BiWs5(z1EemnPD4UaMC)
		v2vVnemKRZs7pB9hU = hhsS5zK1clE4O3apXPTuxHG(QqdHIgaWXYNsmifj4zGkREhoUD[0],int(TKIqiGcdpOlZEXD3))
		H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'LIVE_GROUPED')
		C1waZEmdt59PeOpWi6Y = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list','LIVE_GROUPED')
		f0CWuX47GAHBsNeQIVoxlZp1Ln = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list','LIVE_GROUPED',C1waZEmdt59PeOpWi6Y[1])
		TixSXhpW69Uba4f1NPqzYE7JcZ = f0CWuX47GAHBsNeQIVoxlZp1Ln[0][2]
		jptbqDRzUSV9fTY1Hh6IJB8Kw = YYqECUofyi7wFrW.findall('://(.*?)/',TixSXhpW69Uba4f1NPqzYE7JcZ,YYqECUofyi7wFrW.DOTALL)
		jptbqDRzUSV9fTY1Hh6IJB8Kw = jptbqDRzUSV9fTY1Hh6IJB8Kw[0]
		if ':' in jptbqDRzUSV9fTY1Hh6IJB8Kw: eKFZgIkLEp,uIdxz9BmRc0tXOoa = jptbqDRzUSV9fTY1Hh6IJB8Kw.split(':')
		else: eKFZgIkLEp,uIdxz9BmRc0tXOoa = jptbqDRzUSV9fTY1Hh6IJB8Kw,'80'
		XwcKmOFHP1nd = kohKPuQdZrpUVOljAcy9BiWs5(eKFZgIkLEp)
		owmxqFRuAIH5yEe41CMkdj76g9 = hhsS5zK1clE4O3apXPTuxHG(XwcKmOFHP1nd[0],int(uIdxz9BmRc0tXOoa))
	if v2vVnemKRZs7pB9hU and owmxqFRuAIH5yEe41CMkdj76g9:
		JzNoqV8ClRD6O = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		JzNoqV8ClRD6O += '\n\n'+'وقت ضائع في السيرفر الأصلي'+B6IrC7zEHlw1oaeWf+str(int(owmxqFRuAIH5yEe41CMkdj76g9*1000))+' ملي ثانية'
		JzNoqV8ClRD6O += '\n\n'+'وقت ضائع في السيرفر البديل'+B6IrC7zEHlw1oaeWf+str(int(v2vVnemKRZs7pB9hU*1000))+' ملي ثانية'
		jTxAYItnH8rO2KD5aJ43bo9V7kiGS = ggJvHnLYzmlj3Z('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',JzNoqV8ClRD6O)
		if jTxAYItnH8rO2KD5aJ43bo9V7kiGS==1 and v2vVnemKRZs7pB9hU<owmxqFRuAIH5yEe41CMkdj76g9: yP4kQfHATSoOt7CZVp8D = z1EemnPD4UaMC+':'+TKIqiGcdpOlZEXD3
	else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.server_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,yP4kQfHATSoOt7CZVp8D)
	return
def uuvhoSanB2TWD(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,TixSXhpW69Uba4f1NPqzYE7JcZ,oJeO8LqTXi7W):
	tIheugQMq8Vp4DLXOZ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	O5Kp6lQkWySc3fvqrVGMJz = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.referer_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if tIheugQMq8Vp4DLXOZ or O5Kp6lQkWySc3fvqrVGMJz:
		TixSXhpW69Uba4f1NPqzYE7JcZ += '|'
		if tIheugQMq8Vp4DLXOZ: TixSXhpW69Uba4f1NPqzYE7JcZ += '&User-Agent='+tIheugQMq8Vp4DLXOZ
		if O5Kp6lQkWySc3fvqrVGMJz: TixSXhpW69Uba4f1NPqzYE7JcZ += '&Referer='+O5Kp6lQkWySc3fvqrVGMJz
		TixSXhpW69Uba4f1NPqzYE7JcZ = TixSXhpW69Uba4f1NPqzYE7JcZ.replace('|&','|')
	QRDe7UnjLdMHJKWsyClB = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.server_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if QRDe7UnjLdMHJKWsyClB:
		AvXcO4zhRU1VFe2gCLnisy5paJ09 = YYqECUofyi7wFrW.findall('://(.*?)/',TixSXhpW69Uba4f1NPqzYE7JcZ,YYqECUofyi7wFrW.DOTALL)
		TixSXhpW69Uba4f1NPqzYE7JcZ = TixSXhpW69Uba4f1NPqzYE7JcZ.replace(AvXcO4zhRU1VFe2gCLnisy5paJ09[0],QRDe7UnjLdMHJKWsyClB)
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(TixSXhpW69Uba4f1NPqzYE7JcZ,qaD1Jv7VWbMoI04Bx8UkrC9XQOh,oJeO8LqTXi7W)
	return
def qJpAc18aTmrt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	tIheugQMq8Vp4DLXOZ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	oLCbzYFH7a = ggJvHnLYzmlj3Z('center','استخدام الأصلي','تعديل القديم',tIheugQMq8Vp4DLXOZ,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if oLCbzYFH7a==1: tIheugQMq8Vp4DLXOZ = Z6GiHgnz0jNytc('أكتب ـIPTV User-Agent جديد',tIheugQMq8Vp4DLXOZ,True)
	else: tIheugQMq8Vp4DLXOZ = 'Unknown'
	if tIheugQMq8Vp4DLXOZ==Vwgflszp4WRA93kx6hvdua21HX5cOb:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oLCbzYFH7a = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,tIheugQMq8Vp4DLXOZ,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if oLCbzYFH7a!=1:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم الإلغاء')
		return
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,tIheugQMq8Vp4DLXOZ)
	uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	return
def O4I6JnAhPtSWZ5rUj0lBGu3XY(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	O5Kp6lQkWySc3fvqrVGMJz = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.referer_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	oLCbzYFH7a = ggJvHnLYzmlj3Z('center','استخدام الأصلي','تعديل القديم',O5Kp6lQkWySc3fvqrVGMJz,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if oLCbzYFH7a==1: O5Kp6lQkWySc3fvqrVGMJz = Z6GiHgnz0jNytc('أكتب ـIPTV Referer جديد',O5Kp6lQkWySc3fvqrVGMJz,True)
	else: O5Kp6lQkWySc3fvqrVGMJz = NdKhAS6MXVEORLTwob92pxlZ
	if O5Kp6lQkWySc3fvqrVGMJz==Vwgflszp4WRA93kx6hvdua21HX5cOb:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	oLCbzYFH7a = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,O5Kp6lQkWySc3fvqrVGMJz,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if oLCbzYFH7a!=1:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم الإلغاء')
		return
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.referer_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,O5Kp6lQkWySc3fvqrVGMJz)
	uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	return
def HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,UuMZOyiGe6fozTX4bcWK=NdKhAS6MXVEORLTwob92pxlZ):
	if not UuMZOyiGe6fozTX4bcWK: UuMZOyiGe6fozTX4bcWK = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.url_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	yP4kQfHATSoOt7CZVp8D = msbTrJW03xuvA(UuMZOyiGe6fozTX4bcWK,'url')
	qfRW2x4uosEYZJ59Kl6mLcQ = YYqECUofyi7wFrW.findall('username=(.*?)&',UuMZOyiGe6fozTX4bcWK+'&',YYqECUofyi7wFrW.DOTALL)
	sXz6et9qU5DR0cBhyQ7TlML2 = YYqECUofyi7wFrW.findall('password=(.*?)&',UuMZOyiGe6fozTX4bcWK+'&',YYqECUofyi7wFrW.DOTALL)
	if not qfRW2x4uosEYZJ59Kl6mLcQ or not sXz6et9qU5DR0cBhyQ7TlML2:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	qfRW2x4uosEYZJ59Kl6mLcQ = qfRW2x4uosEYZJ59Kl6mLcQ[0]
	sXz6et9qU5DR0cBhyQ7TlML2 = sXz6et9qU5DR0cBhyQ7TlML2[0]
	APgYxb0Ksd = yP4kQfHATSoOt7CZVp8D+'/player_api.php?username='+qfRW2x4uosEYZJ59Kl6mLcQ+'&password='+sXz6et9qU5DR0cBhyQ7TlML2
	V8zyRjo6bpkl14qXIvWmC = yP4kQfHATSoOt7CZVp8D+'/get.php?username='+qfRW2x4uosEYZJ59Kl6mLcQ+'&password='+sXz6et9qU5DR0cBhyQ7TlML2+'&type=m3u_plus'
	return APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2
def AlJ6Ez1HvhVNZpC(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,X1hB94JYqA58o0mbVNKQr=NdKhAS6MXVEORLTwob92pxlZ):
	Y4I7L2ktbB = X1hB94JYqA58o0mbVNKQr.replace('/','_').replace(':','_').replace('.','_')
	Y4I7L2ktbB = Y4I7L2ktbB.replace('?','_').replace('=','_').replace('&','_')
	Y4I7L2ktbB = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(vJQYPbL42F013CRoqtEUI,Y4I7L2ktbB).strip('.m3u')+'.m3u'
	return Y4I7L2ktbB
def vP5ik0AFSOgLy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	BM5SG9vaLw4dFX = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.url_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	ZjzYtGIOve = True
	if BM5SG9vaLw4dFX:
		oLCbzYFH7a = HQK8NwPVcoJ('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',Whef0cxB2iR93SC5IwUtk+BM5SG9vaLw4dFX+kjd9LyNqQHMUevZiRI7OlBGF1h+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if oLCbzYFH7a==-1: return
		elif oLCbzYFH7a==0: BM5SG9vaLw4dFX = NdKhAS6MXVEORLTwob92pxlZ
		elif oLCbzYFH7a==2:
			oLCbzYFH7a = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oLCbzYFH7a in [-1,0]: return
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم مسح الرابط')
			ZjzYtGIOve = False
			ynpJdMhIj0XzOlW = NdKhAS6MXVEORLTwob92pxlZ
	if ZjzYtGIOve:
		ynpJdMhIj0XzOlW = Z6GiHgnz0jNytc('اكتب رابط ـIPTV كاملا',BM5SG9vaLw4dFX)
		ynpJdMhIj0XzOlW = ynpJdMhIj0XzOlW.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if not ynpJdMhIj0XzOlW:
			oLCbzYFH7a = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if oLCbzYFH7a in [-1,0]: return
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم مسح الرابط')
	else:
		APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2 = HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,ynpJdMhIj0XzOlW)
		if not qfRW2x4uosEYZJ59Kl6mLcQ: return
		JzNoqV8ClRD6O = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+yP4kQfHATSoOt7CZVp8D+kjd9LyNqQHMUevZiRI7OlBGF1h+'عنوان السيرفر: '
		JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+qfRW2x4uosEYZJ59Kl6mLcQ+kjd9LyNqQHMUevZiRI7OlBGF1h+'اسم المستخدم: '
		JzNoqV8ClRD6O += B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+qyxr761uVdgLRCPf++'كلمة السر: '
		oLCbzYFH7a = ggJvHnLYzmlj3Z('right',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'الرابط الجديد هو:',Whef0cxB2iR93SC5IwUtk+ynpJdMhIj0XzOlW+kjd9LyNqQHMUevZiRI7OlBGF1h+'\n\n'+JzNoqV8ClRD6O)
		if oLCbzYFH7a!=1:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم الإلغاء')
			return
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.url_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,ynpJdMhIj0XzOlW)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.timestamp_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,NdKhAS6MXVEORLTwob92pxlZ)
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.timediff_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,NdKhAS6MXVEORLTwob92pxlZ)
	tIheugQMq8Vp4DLXOZ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if not tIheugQMq8Vp4DLXOZ: ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'Unknown')
	adIN9GyVg3YQH8lq = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,ynpJdMhIj0XzOlW+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if adIN9GyVg3YQH8lq==1: wylQWMjqTHrgxz,z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,True)
	uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	return
def gl8LY1XTOJ4yeMdbZ7KrhC(hyRfxjI9ruDPkHwcA5vbg,zvGc7mWs5trklndE,nRLCd912K8g4sH,GXqwjoV2nP4IYpe970BvELfxh5bQFy,jpGSFfu5zemrJv3xWTE,lH2Tk5x7UqJ6W,V8zyRjo6bpkl14qXIvWmC):
	f0CWuX47GAHBsNeQIVoxlZp1Ln,aAlkcrojSVg = [],[]
	XmELZ9tNoC6Wx8OpYGjyS = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		if lH2Tk5x7UqJ6W%473==0:
			BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,40+int(10*lH2Tk5x7UqJ6W/jpGSFfu5zemrJv3xWTE),'قراءة الفيديوهات','الفيديو رقم:-',str(lH2Tk5x7UqJ6W)+' / '+str(jpGSFfu5zemrJv3xWTE))
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return None,None,None
		TixSXhpW69Uba4f1NPqzYE7JcZ = YYqECUofyi7wFrW.findall('^(.*?)\n+((http|https|rtmp).*?)$',WEPkgTHGs46itVBLn5fZb21QSIvC,YYqECUofyi7wFrW.DOTALL)
		if TixSXhpW69Uba4f1NPqzYE7JcZ:
			WEPkgTHGs46itVBLn5fZb21QSIvC,TixSXhpW69Uba4f1NPqzYE7JcZ,iCmkXMpWGzVKxSTU0L8NE = TixSXhpW69Uba4f1NPqzYE7JcZ[0]
			TixSXhpW69Uba4f1NPqzYE7JcZ = TixSXhpW69Uba4f1NPqzYE7JcZ.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
			WEPkgTHGs46itVBLn5fZb21QSIvC = WEPkgTHGs46itVBLn5fZb21QSIvC.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
		else:
			aAlkcrojSVg.append({'line':WEPkgTHGs46itVBLn5fZb21QSIvC})
			continue
		huxQ0beA1nNZ3lgMq6Sz,ueFHThK2pDYc,ucBCXwgzfPhHRx2NnjGQ,pmAFLa7SRWhcK5dn6DxrwYO,oJeO8LqTXi7W,gj70pFIx8kYMhbVBLmJPZU = {},NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,False
		try:
			WEPkgTHGs46itVBLn5fZb21QSIvC,pmAFLa7SRWhcK5dn6DxrwYO = WEPkgTHGs46itVBLn5fZb21QSIvC.rsplit('",',1)
			WEPkgTHGs46itVBLn5fZb21QSIvC = WEPkgTHGs46itVBLn5fZb21QSIvC+'"'
		except:
			try: WEPkgTHGs46itVBLn5fZb21QSIvC,pmAFLa7SRWhcK5dn6DxrwYO = WEPkgTHGs46itVBLn5fZb21QSIvC.rsplit('1,',1)
			except: pmAFLa7SRWhcK5dn6DxrwYO = NdKhAS6MXVEORLTwob92pxlZ
		huxQ0beA1nNZ3lgMq6Sz['url'] = TixSXhpW69Uba4f1NPqzYE7JcZ
		HPOWCrRIpeZgDvjM3y0GBK5S7clkm = YYqECUofyi7wFrW.findall(' (.*?)="(.*?)"',WEPkgTHGs46itVBLn5fZb21QSIvC,YYqECUofyi7wFrW.DOTALL)
		for GWkcLexzmpJyl7nYq,TTc4QGeF0UH in HPOWCrRIpeZgDvjM3y0GBK5S7clkm:
			GWkcLexzmpJyl7nYq = GWkcLexzmpJyl7nYq.replace('"',NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			huxQ0beA1nNZ3lgMq6Sz[GWkcLexzmpJyl7nYq] = TTc4QGeF0UH.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		kiCvDsTUxeX1mSrHq0pb = list(huxQ0beA1nNZ3lgMq6Sz.keys())
		if not pmAFLa7SRWhcK5dn6DxrwYO:
			if 'name' in kiCvDsTUxeX1mSrHq0pb and huxQ0beA1nNZ3lgMq6Sz['name']: pmAFLa7SRWhcK5dn6DxrwYO = huxQ0beA1nNZ3lgMq6Sz['name']
		huxQ0beA1nNZ3lgMq6Sz['title'] = pmAFLa7SRWhcK5dn6DxrwYO.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'logo' in kiCvDsTUxeX1mSrHq0pb:
			huxQ0beA1nNZ3lgMq6Sz['img'] = huxQ0beA1nNZ3lgMq6Sz['logo']
			del huxQ0beA1nNZ3lgMq6Sz['logo']
		else: huxQ0beA1nNZ3lgMq6Sz['img'] = NdKhAS6MXVEORLTwob92pxlZ
		if 'group' in kiCvDsTUxeX1mSrHq0pb and huxQ0beA1nNZ3lgMq6Sz['group']: ucBCXwgzfPhHRx2NnjGQ = huxQ0beA1nNZ3lgMq6Sz['group']
		if any(K6KbZDHncNizQgl1fr59XV0 in TixSXhpW69Uba4f1NPqzYE7JcZ.lower() for K6KbZDHncNizQgl1fr59XV0 in XmELZ9tNoC6Wx8OpYGjyS):
			gj70pFIx8kYMhbVBLmJPZU = True if 'm3u' not in TixSXhpW69Uba4f1NPqzYE7JcZ else False
		if gj70pFIx8kYMhbVBLmJPZU or '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ or '__MOVIES__' in ucBCXwgzfPhHRx2NnjGQ:
			oJeO8LqTXi7W = 'VOD'
			if '__SERIES__' in ucBCXwgzfPhHRx2NnjGQ: oJeO8LqTXi7W = oJeO8LqTXi7W+'_SERIES'
			elif '__MOVIES__' in ucBCXwgzfPhHRx2NnjGQ: oJeO8LqTXi7W = oJeO8LqTXi7W+'_MOVIES'
			else: oJeO8LqTXi7W = oJeO8LqTXi7W+'_UNKNOWN'
			ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.replace('__SERIES__',NdKhAS6MXVEORLTwob92pxlZ).replace('__MOVIES__',NdKhAS6MXVEORLTwob92pxlZ)
		else:
			oJeO8LqTXi7W = 'LIVE'
			if pmAFLa7SRWhcK5dn6DxrwYO in zvGc7mWs5trklndE: ueFHThK2pDYc = ueFHThK2pDYc+'_EPG'
			if pmAFLa7SRWhcK5dn6DxrwYO in nRLCd912K8g4sH: ueFHThK2pDYc = ueFHThK2pDYc+'_ARCHIVED'
			if not ucBCXwgzfPhHRx2NnjGQ: oJeO8LqTXi7W = oJeO8LqTXi7W+'_UNKNOWN'
			else: oJeO8LqTXi7W = oJeO8LqTXi7W+ueFHThK2pDYc
		ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'LIVE_UNKNOWN' in oJeO8LqTXi7W: ucBCXwgzfPhHRx2NnjGQ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in oJeO8LqTXi7W: ucBCXwgzfPhHRx2NnjGQ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in oJeO8LqTXi7W:
			UI28x1WK0MZypCtF7Ofhov = YYqECUofyi7wFrW.findall('(.*?) [Ss]\d+ +[Ee]\d+',huxQ0beA1nNZ3lgMq6Sz['title'],YYqECUofyi7wFrW.DOTALL)
			if UI28x1WK0MZypCtF7Ofhov: UI28x1WK0MZypCtF7Ofhov = UI28x1WK0MZypCtF7Ofhov[0]
			else: UI28x1WK0MZypCtF7Ofhov = '!!__UNKNOWN_SERIES__!!'
			ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ+'__SERIES__'+UI28x1WK0MZypCtF7Ofhov
		if 'id' in kiCvDsTUxeX1mSrHq0pb: del huxQ0beA1nNZ3lgMq6Sz['id']
		if 'ID' in kiCvDsTUxeX1mSrHq0pb: del huxQ0beA1nNZ3lgMq6Sz['ID']
		if 'name' in kiCvDsTUxeX1mSrHq0pb: del huxQ0beA1nNZ3lgMq6Sz['name']
		pmAFLa7SRWhcK5dn6DxrwYO = huxQ0beA1nNZ3lgMq6Sz['title']
		pmAFLa7SRWhcK5dn6DxrwYO = L5xKSr96JmaX7N(pmAFLa7SRWhcK5dn6DxrwYO)
		pmAFLa7SRWhcK5dn6DxrwYO = wFQWj7dAETfqpJblOV1H(pmAFLa7SRWhcK5dn6DxrwYO)
		ZzneXfgbsUr2K47CYvi9P,ucBCXwgzfPhHRx2NnjGQ = P4AZKCExBRQkdOipnLzcbom9MNuh(ucBCXwgzfPhHRx2NnjGQ)
		yP50C63JLrgaRh1ulmpKxGkoSc,pmAFLa7SRWhcK5dn6DxrwYO = P4AZKCExBRQkdOipnLzcbom9MNuh(pmAFLa7SRWhcK5dn6DxrwYO)
		huxQ0beA1nNZ3lgMq6Sz['type'] = oJeO8LqTXi7W
		huxQ0beA1nNZ3lgMq6Sz['context'] = ueFHThK2pDYc
		huxQ0beA1nNZ3lgMq6Sz['group'] = ucBCXwgzfPhHRx2NnjGQ.upper()
		huxQ0beA1nNZ3lgMq6Sz['title'] = pmAFLa7SRWhcK5dn6DxrwYO.upper()
		huxQ0beA1nNZ3lgMq6Sz['country'] = yP50C63JLrgaRh1ulmpKxGkoSc.upper()
		huxQ0beA1nNZ3lgMq6Sz['language'] = ZzneXfgbsUr2K47CYvi9P.upper()
		f0CWuX47GAHBsNeQIVoxlZp1Ln.append(huxQ0beA1nNZ3lgMq6Sz)
		lH2Tk5x7UqJ6W += 1
	return f0CWuX47GAHBsNeQIVoxlZp1Ln,lH2Tk5x7UqJ6W,aAlkcrojSVg
def wFQWj7dAETfqpJblOV1H(pmAFLa7SRWhcK5dn6DxrwYO):
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.replace('||','|').replace('___',':').replace('--','-')
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.replace('[[','[').replace(']]',']')
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.replace('((','(').replace('))',')')
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.replace('<<','<').replace('>>','>')
	pmAFLa7SRWhcK5dn6DxrwYO = pmAFLa7SRWhcK5dn6DxrwYO.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	return pmAFLa7SRWhcK5dn6DxrwYO
def k67kpg2JWKFjPlBsweEA4U(IDFyf2vjJS1eohqrsO0PYHcnlL7,GXqwjoV2nP4IYpe970BvELfxh5bQFy):
	ee5T4aBoFCzrYWIcZq2AkynG = {}
	for FXmB68Vl1npDkCEaO9zuciTxAt0 in RPM1AYqXgjEpiVmrSGoyxWu3Cd5: ee5T4aBoFCzrYWIcZq2AkynG[FXmB68Vl1npDkCEaO9zuciTxAt0] = []
	jpGSFfu5zemrJv3xWTE = len(IDFyf2vjJS1eohqrsO0PYHcnlL7)
	nwsIK15FYZA8hzSRflm = str(jpGSFfu5zemrJv3xWTE)
	lH2Tk5x7UqJ6W = 0
	aAlkcrojSVg = []
	for huxQ0beA1nNZ3lgMq6Sz in IDFyf2vjJS1eohqrsO0PYHcnlL7:
		if lH2Tk5x7UqJ6W%873==0:
			BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,50+int(5*lH2Tk5x7UqJ6W/jpGSFfu5zemrJv3xWTE),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(lH2Tk5x7UqJ6W)+' / '+nwsIK15FYZA8hzSRflm)
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return None,None
		ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex = huxQ0beA1nNZ3lgMq6Sz['group'],huxQ0beA1nNZ3lgMq6Sz['context'],huxQ0beA1nNZ3lgMq6Sz['title'],huxQ0beA1nNZ3lgMq6Sz['url'],huxQ0beA1nNZ3lgMq6Sz['img']
		yP50C63JLrgaRh1ulmpKxGkoSc,ZzneXfgbsUr2K47CYvi9P,FXmB68Vl1npDkCEaO9zuciTxAt0 = huxQ0beA1nNZ3lgMq6Sz['country'],huxQ0beA1nNZ3lgMq6Sz['language'],huxQ0beA1nNZ3lgMq6Sz['type']
		sv4gF2tcQpxN7zmMqA = (ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex)
		OnUYWZ7fjEM2zqbQDx9FV3k5r = False
		if 'LIVE' in FXmB68Vl1npDkCEaO9zuciTxAt0:
			if 'UNKNOWN' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_UNKNOWN_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
			elif 'LIVE' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
			else: OnUYWZ7fjEM2zqbQDx9FV3k5r = True
			ee5T4aBoFCzrYWIcZq2AkynG['LIVE_ORIGINAL_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
		elif 'VOD' in FXmB68Vl1npDkCEaO9zuciTxAt0:
			if 'UNKNOWN' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_UNKNOWN_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
			elif 'MOVIES' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_MOVIES_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
			elif 'SERIES' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_SERIES_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
			else: OnUYWZ7fjEM2zqbQDx9FV3k5r = True
			ee5T4aBoFCzrYWIcZq2AkynG['VOD_ORIGINAL_GROUPED'].append(sv4gF2tcQpxN7zmMqA)
		else: OnUYWZ7fjEM2zqbQDx9FV3k5r = True
		if OnUYWZ7fjEM2zqbQDx9FV3k5r: aAlkcrojSVg.append(huxQ0beA1nNZ3lgMq6Sz)
		lH2Tk5x7UqJ6W += 1
	LZnE1UgFoSB2YwxNi = sorted(IDFyf2vjJS1eohqrsO0PYHcnlL7,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq['title'].lower())
	del IDFyf2vjJS1eohqrsO0PYHcnlL7
	nwsIK15FYZA8hzSRflm = str(jpGSFfu5zemrJv3xWTE)
	lH2Tk5x7UqJ6W = 0
	for huxQ0beA1nNZ3lgMq6Sz in LZnE1UgFoSB2YwxNi:
		lH2Tk5x7UqJ6W += 1
		if lH2Tk5x7UqJ6W%873==0:
			BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,55+int(5*lH2Tk5x7UqJ6W/jpGSFfu5zemrJv3xWTE),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(lH2Tk5x7UqJ6W)+' / '+nwsIK15FYZA8hzSRflm)
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return None,None
		FXmB68Vl1npDkCEaO9zuciTxAt0 = huxQ0beA1nNZ3lgMq6Sz['type']
		ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex = huxQ0beA1nNZ3lgMq6Sz['group'],huxQ0beA1nNZ3lgMq6Sz['context'],huxQ0beA1nNZ3lgMq6Sz['title'],huxQ0beA1nNZ3lgMq6Sz['url'],huxQ0beA1nNZ3lgMq6Sz['img']
		yP50C63JLrgaRh1ulmpKxGkoSc,ZzneXfgbsUr2K47CYvi9P = huxQ0beA1nNZ3lgMq6Sz['country'],huxQ0beA1nNZ3lgMq6Sz['language']
		kUnqOJ6eg3tBhI8zSEKZ1HAiv9 = (ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc+'_TIMESHIFT',pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex)
		sv4gF2tcQpxN7zmMqA = (ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex)
		C590e3nylcvZpJPBG7oYwjhIuEV = (yP50C63JLrgaRh1ulmpKxGkoSc,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex)
		lEdsU4xjDpZPNv1hQKAMySzr3m = (ZzneXfgbsUr2K47CYvi9P,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex)
		if 'LIVE' in FXmB68Vl1npDkCEaO9zuciTxAt0:
			if 'UNKNOWN' in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_UNKNOWN_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			else: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			if 'EPG'		in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_EPG_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			if 'ARCHIVED'	in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_ARCHIVED_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			if 'ARCHIVED'	in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['LIVE_TIMESHIFT_GROUPED_SORTED'].append(kUnqOJ6eg3tBhI8zSEKZ1HAiv9)
			ee5T4aBoFCzrYWIcZq2AkynG['LIVE_FROM_NAME_SORTED'].append(C590e3nylcvZpJPBG7oYwjhIuEV)
			ee5T4aBoFCzrYWIcZq2AkynG['LIVE_FROM_GROUP_SORTED'].append(lEdsU4xjDpZPNv1hQKAMySzr3m)
		elif 'VOD' in FXmB68Vl1npDkCEaO9zuciTxAt0:
			if   'UNKNOWN'	in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_UNKNOWN_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			elif 'MOVIES'	in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_MOVIES_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			elif 'SERIES'	in FXmB68Vl1npDkCEaO9zuciTxAt0: ee5T4aBoFCzrYWIcZq2AkynG['VOD_SERIES_GROUPED_SORTED'].append(sv4gF2tcQpxN7zmMqA)
			ee5T4aBoFCzrYWIcZq2AkynG['VOD_FROM_NAME_SORTED'].append(C590e3nylcvZpJPBG7oYwjhIuEV)
			ee5T4aBoFCzrYWIcZq2AkynG['VOD_FROM_GROUP_SORTED'].append(lEdsU4xjDpZPNv1hQKAMySzr3m)
	return ee5T4aBoFCzrYWIcZq2AkynG,aAlkcrojSVg
def P4AZKCExBRQkdOipnLzcbom9MNuh(pmAFLa7SRWhcK5dn6DxrwYO):
	if len(pmAFLa7SRWhcK5dn6DxrwYO)<3: return pmAFLa7SRWhcK5dn6DxrwYO,pmAFLa7SRWhcK5dn6DxrwYO
	zlEG2fKPoTeaL6hM0CsIyRwQXgVB1,BBm6RHxceY5 = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = pmAFLa7SRWhcK5dn6DxrwYO
	wwHgof1TOJVMQch4i0jE = pmAFLa7SRWhcK5dn6DxrwYO[:1]
	olfTc5bqQYPvIB98ZDRr = pmAFLa7SRWhcK5dn6DxrwYO[1:]
	if   wwHgof1TOJVMQch4i0jE=='(': BBm6RHxceY5 = ')'
	elif wwHgof1TOJVMQch4i0jE=='[': BBm6RHxceY5 = ']'
	elif wwHgof1TOJVMQch4i0jE=='<': BBm6RHxceY5 = '>'
	elif wwHgof1TOJVMQch4i0jE=='|': BBm6RHxceY5 = '|'
	if BBm6RHxceY5 and (BBm6RHxceY5 in olfTc5bqQYPvIB98ZDRr):
		fbakAvdgj5,AyYl4zfTPntGpK2Dj = olfTc5bqQYPvIB98ZDRr.split(BBm6RHxceY5,1)
		zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = fbakAvdgj5
		ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = wwHgof1TOJVMQch4i0jE+fbakAvdgj5+BBm6RHxceY5+Vwgflszp4WRA93kx6hvdua21HX5cOb+AyYl4zfTPntGpK2Dj
	elif pmAFLa7SRWhcK5dn6DxrwYO.count('|')>=2:
		fbakAvdgj5,AyYl4zfTPntGpK2Dj = pmAFLa7SRWhcK5dn6DxrwYO.split('|',1)
		zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = fbakAvdgj5
		ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = fbakAvdgj5+' |'+AyYl4zfTPntGpK2Dj
	else:
		BBm6RHxceY5 = YYqECUofyi7wFrW.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',pmAFLa7SRWhcK5dn6DxrwYO,YYqECUofyi7wFrW.DOTALL)
		if not BBm6RHxceY5: BBm6RHxceY5 = YYqECUofyi7wFrW.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',pmAFLa7SRWhcK5dn6DxrwYO,YYqECUofyi7wFrW.DOTALL)
		if not BBm6RHxceY5: BBm6RHxceY5 = YYqECUofyi7wFrW.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',pmAFLa7SRWhcK5dn6DxrwYO,YYqECUofyi7wFrW.DOTALL)
		if BBm6RHxceY5:
			fbakAvdgj5,AyYl4zfTPntGpK2Dj = pmAFLa7SRWhcK5dn6DxrwYO.split(BBm6RHxceY5[0],1)
			zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = fbakAvdgj5
			ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = fbakAvdgj5+Vwgflszp4WRA93kx6hvdua21HX5cOb+BBm6RHxceY5[0]+Vwgflszp4WRA93kx6hvdua21HX5cOb+AyYl4zfTPntGpK2Dj
	ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = ZZGseMhTYuDdn3EQjbpF9o2Bk8fg.replace(H9cMF21gLJSv3tA5CPYXza,Vwgflszp4WRA93kx6hvdua21HX5cOb).replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = zlEG2fKPoTeaL6hM0CsIyRwQXgVB1.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
	if not zlEG2fKPoTeaL6hM0CsIyRwQXgVB1: zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = '!!__UNKNOWN__!!'
	zlEG2fKPoTeaL6hM0CsIyRwQXgVB1 = zlEG2fKPoTeaL6hM0CsIyRwQXgVB1.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	ZZGseMhTYuDdn3EQjbpF9o2Bk8fg = ZZGseMhTYuDdn3EQjbpF9o2Bk8fg.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
	return zlEG2fKPoTeaL6hM0CsIyRwQXgVB1,ZZGseMhTYuDdn3EQjbpF9o2Bk8fg
def uOagfXTyh4zjYP6plMbsnSe(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	RpYN2DWoKIbUHuL = {}
	tIheugQMq8Vp4DLXOZ = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.useragent_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if tIheugQMq8Vp4DLXOZ: RpYN2DWoKIbUHuL['User-Agent'] = tIheugQMq8Vp4DLXOZ
	O5Kp6lQkWySc3fvqrVGMJz = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.iptv.referer_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if O5Kp6lQkWySc3fvqrVGMJz: RpYN2DWoKIbUHuL['Referer'] = O5Kp6lQkWySc3fvqrVGMJz
	return RpYN2DWoKIbUHuL
def u5xpT7GVv9HEFwX1Jli(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	global GXqwjoV2nP4IYpe970BvELfxh5bQFy,ee5T4aBoFCzrYWIcZq2AkynG,iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV,hfnLYPpyjs7rAJl6Fxbw0Q,Kiqd4bB5DORle9hAYNzGkjZF,C1waZEmdt59PeOpWi6Y,x4FHThtE68ROieYskW,ksXvoYf8NiWTuOnH47gQZB3ry9,aTBOWYdNpDmt6ZQ2b17
	APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2 = HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if not qfRW2x4uosEYZJ59Kl6mLcQ: return
	RpYN2DWoKIbUHuL = uOagfXTyh4zjYP6plMbsnSe(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	jTxAYItnH8rO2KD5aJ43bo9V7kiGS = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if jTxAYItnH8rO2KD5aJ43bo9V7kiGS!=1: return
	Y4I7L2ktbB = U53uZnOCd9jwDgxpGaJNTe.replace('___','_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if 1:
		wylQWMjqTHrgxz,z1EemnPD4UaMC,TKIqiGcdpOlZEXD3 = cZk0pQ76Pa85jVsGvLWuyltqSKx(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,False)
		if not wylQWMjqTHrgxz:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not V8zyRjo6bpkl14qXIvWmC: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(qaD1Jv7VWbMoI04Bx8UkrC9XQOh)+'   No IPTV URL found to download IPTV files')
			else: LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(qaD1Jv7VWbMoI04Bx8UkrC9XQOh)+'   Failed to download IPTV files')
			return
		vt4rDT1W52FKGC = VCoIxDK8uGJv(V8zyRjo6bpkl14qXIvWmC,RpYN2DWoKIbUHuL,True)
		if not vt4rDT1W52FKGC: return
		open(Y4I7L2ktbB,'wb').write(vt4rDT1W52FKGC)
	else: vt4rDT1W52FKGC = open(Y4I7L2ktbB,'rb').read()
	if J92gCnbGWidQV70lBteTwU6D8uyzL and vt4rDT1W52FKGC: vt4rDT1W52FKGC = vt4rDT1W52FKGC.decode(YRvPKe2zMTDs8UCkr)
	GXqwjoV2nP4IYpe970BvELfxh5bQFy = UpNqSvlOPeuKntGWCT1rR3aI4b()
	GXqwjoV2nP4IYpe970BvELfxh5bQFy.create('جلب ملفات ـIPTV جديدة',NdKhAS6MXVEORLTwob92pxlZ)
	BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,15,'تنظيف الملف الرئيسي',NdKhAS6MXVEORLTwob92pxlZ)
	vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('"tvg-','" tvg-')
	vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('َ',NdKhAS6MXVEORLTwob92pxlZ).replace('ً',NdKhAS6MXVEORLTwob92pxlZ).replace('ُ',NdKhAS6MXVEORLTwob92pxlZ).replace('ٌ',NdKhAS6MXVEORLTwob92pxlZ)
	vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('ّ',NdKhAS6MXVEORLTwob92pxlZ).replace('ِ',NdKhAS6MXVEORLTwob92pxlZ).replace('ٍ',NdKhAS6MXVEORLTwob92pxlZ).replace('ْ',NdKhAS6MXVEORLTwob92pxlZ)
	vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('group-title=','group=').replace('tvg-',NdKhAS6MXVEORLTwob92pxlZ)
	nRLCd912K8g4sH,zvGc7mWs5trklndE = [],[]
	BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
		GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
		return
	TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_series_categories'
	KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',TixSXhpW69Uba4f1NPqzYE7JcZ,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-CREATE_STREAMS-1st')
	JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
	JIVXou7hYWQ6CKDsPOUytnml3e9 = L5xKSr96JmaX7N(JIVXou7hYWQ6CKDsPOUytnml3e9)
	AAFnvSTl8d5YC = YYqECUofyi7wFrW.findall('category_name":"(.*?)"',JIVXou7hYWQ6CKDsPOUytnml3e9,YYqECUofyi7wFrW.DOTALL)
	del JIVXou7hYWQ6CKDsPOUytnml3e9
	for ucBCXwgzfPhHRx2NnjGQ in AAFnvSTl8d5YC:
		ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.replace('\/','/')
		if QBp28giCnayJzmZH6vYO: ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
		vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('group="'+ucBCXwgzfPhHRx2NnjGQ+'"','group="__SERIES__'+ucBCXwgzfPhHRx2NnjGQ+'"')
	del AAFnvSTl8d5YC
	BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
		GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
		return
	TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_vod_categories'
	KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',TixSXhpW69Uba4f1NPqzYE7JcZ,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-CREATE_STREAMS-2nd')
	JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
	JIVXou7hYWQ6CKDsPOUytnml3e9 = L5xKSr96JmaX7N(JIVXou7hYWQ6CKDsPOUytnml3e9)
	vIyWUg0tmcN = YYqECUofyi7wFrW.findall('category_name":"(.*?)"',JIVXou7hYWQ6CKDsPOUytnml3e9,YYqECUofyi7wFrW.DOTALL)
	del JIVXou7hYWQ6CKDsPOUytnml3e9
	for ucBCXwgzfPhHRx2NnjGQ in vIyWUg0tmcN:
		ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.replace('\/','/')
		if QBp28giCnayJzmZH6vYO: ucBCXwgzfPhHRx2NnjGQ = ucBCXwgzfPhHRx2NnjGQ.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
		vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace('group="'+ucBCXwgzfPhHRx2NnjGQ+'"','group="__MOVIES__'+ucBCXwgzfPhHRx2NnjGQ+'"')
	del vIyWUg0tmcN
	BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
		GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
		return
	TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_live_streams'
	KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',TixSXhpW69Uba4f1NPqzYE7JcZ,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-CREATE_STREAMS-3rd')
	JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
	JIVXou7hYWQ6CKDsPOUytnml3e9 = L5xKSr96JmaX7N(JIVXou7hYWQ6CKDsPOUytnml3e9)
	WWLrIAcGnKsUzgmXitpMJkaQHP1bY3 = YYqECUofyi7wFrW.findall('"name":"(.*?)".*?"tv_archive":(.*?),',JIVXou7hYWQ6CKDsPOUytnml3e9,YYqECUofyi7wFrW.DOTALL)
	for JHKDFe6Am0ruz8,o0nI3fYBuKLbz96atmhlpSV8R in WWLrIAcGnKsUzgmXitpMJkaQHP1bY3:
		if o0nI3fYBuKLbz96atmhlpSV8R=='1': nRLCd912K8g4sH.append(JHKDFe6Am0ruz8)
	del WWLrIAcGnKsUzgmXitpMJkaQHP1bY3
	VVlucjv1AXOWDGRaQnz = YYqECUofyi7wFrW.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',JIVXou7hYWQ6CKDsPOUytnml3e9,YYqECUofyi7wFrW.DOTALL)
	del JIVXou7hYWQ6CKDsPOUytnml3e9
	for JHKDFe6Am0ruz8,BshOm5IxTv9nXMZQpG7WdAVF6w in VVlucjv1AXOWDGRaQnz:
		if BshOm5IxTv9nXMZQpG7WdAVF6w!='null': zvGc7mWs5trklndE.append(JHKDFe6Am0ruz8)
	del VVlucjv1AXOWDGRaQnz
	vt4rDT1W52FKGC = vt4rDT1W52FKGC.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,B6IrC7zEHlw1oaeWf)
	hyRfxjI9ruDPkHwcA5vbg = YYqECUofyi7wFrW.findall('NF:(.+?)'+'#'+'EXTI',vt4rDT1W52FKGC+'\n+'+'#'+'EXTINF:',YYqECUofyi7wFrW.DOTALL)
	if not hyRfxjI9ruDPkHwcA5vbg:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(qaD1Jv7VWbMoI04Bx8UkrC9XQOh)+'   Folder:'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0+'   No video links found in IPTV file')
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+B6IrC7zEHlw1oaeWf+D7INg5kyRjwf4ZtoePVUrb1h2SJ+'مجلد رقم '+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
		GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
		return
	OL5fk29YmaxnzUVCcgZehbirDT = []
	for WEPkgTHGs46itVBLn5fZb21QSIvC in hyRfxjI9ruDPkHwcA5vbg:
		x8mywfBFY7c1niDkoM6HWsN = WEPkgTHGs46itVBLn5fZb21QSIvC.lower()
		if 'adult' in x8mywfBFY7c1niDkoM6HWsN: continue
		if 'xxx' in x8mywfBFY7c1niDkoM6HWsN: continue
		OL5fk29YmaxnzUVCcgZehbirDT.append(WEPkgTHGs46itVBLn5fZb21QSIvC)
	hyRfxjI9ruDPkHwcA5vbg = OL5fk29YmaxnzUVCcgZehbirDT
	del OL5fk29YmaxnzUVCcgZehbirDT
	aHKyvoq8Fb = 1024*1024
	v1nDjom7KayIh = 1+len(vt4rDT1W52FKGC)//aHKyvoq8Fb//10
	del vt4rDT1W52FKGC
	lOLK3Mzs67N0hvkPdWotp = len(hyRfxjI9ruDPkHwcA5vbg)
	y5mYaF7GTOi3rNPWDXqMvb = egfRV9FZMqoOKvU5IEJ7Sdw1l2a(hyRfxjI9ruDPkHwcA5vbg,v1nDjom7KayIh)
	del hyRfxjI9ruDPkHwcA5vbg
	for zG37PsWCeVZ4aYtmkE2DTowqBF in range(v1nDjom7KayIh):
		BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,35+int(5*zG37PsWCeVZ4aYtmkE2DTowqBF/v1nDjom7KayIh),'تقطيع الملف الرئيسي','الجزء رقم:-',str(zG37PsWCeVZ4aYtmkE2DTowqBF+1)+' / '+str(v1nDjom7KayIh))
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
		BhCtHiQq87SEyJupbzg = str(y5mYaF7GTOi3rNPWDXqMvb[zG37PsWCeVZ4aYtmkE2DTowqBF])
		if J92gCnbGWidQV70lBteTwU6D8uyzL: BhCtHiQq87SEyJupbzg = BhCtHiQq87SEyJupbzg.encode(YRvPKe2zMTDs8UCkr)
		open(Y4I7L2ktbB+'.00'+str(zG37PsWCeVZ4aYtmkE2DTowqBF),'wb').write(BhCtHiQq87SEyJupbzg)
	del y5mYaF7GTOi3rNPWDXqMvb,BhCtHiQq87SEyJupbzg
	Q02dGeiOHYX8NJ36sVa91f4,IDFyf2vjJS1eohqrsO0PYHcnlL7,lH2Tk5x7UqJ6W = [],[],0
	for zG37PsWCeVZ4aYtmkE2DTowqBF in range(v1nDjom7KayIh):
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
		BhCtHiQq87SEyJupbzg = open(Y4I7L2ktbB+'.00'+str(zG37PsWCeVZ4aYtmkE2DTowqBF),'rb').read()
		XJ62UBRmIqFvfiNTQj.sleep(1)
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(Y4I7L2ktbB+'.00'+str(zG37PsWCeVZ4aYtmkE2DTowqBF))
		except: pass
		if J92gCnbGWidQV70lBteTwU6D8uyzL: BhCtHiQq87SEyJupbzg = BhCtHiQq87SEyJupbzg.decode(YRvPKe2zMTDs8UCkr)
		RCwnHioZjtF2WlfbMgB6JT1Gpe3X = BdnA8WwtJeKUVvE('list',BhCtHiQq87SEyJupbzg)
		del BhCtHiQq87SEyJupbzg
		f0CWuX47GAHBsNeQIVoxlZp1Ln,lH2Tk5x7UqJ6W,aAlkcrojSVg = gl8LY1XTOJ4yeMdbZ7KrhC(RCwnHioZjtF2WlfbMgB6JT1Gpe3X,zvGc7mWs5trklndE,nRLCd912K8g4sH,GXqwjoV2nP4IYpe970BvELfxh5bQFy,lOLK3Mzs67N0hvkPdWotp,lH2Tk5x7UqJ6W,V8zyRjo6bpkl14qXIvWmC)
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
		if not f0CWuX47GAHBsNeQIVoxlZp1Ln:
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
		IDFyf2vjJS1eohqrsO0PYHcnlL7 += f0CWuX47GAHBsNeQIVoxlZp1Ln
		Q02dGeiOHYX8NJ36sVa91f4 += aAlkcrojSVg
	del RCwnHioZjtF2WlfbMgB6JT1Gpe3X,f0CWuX47GAHBsNeQIVoxlZp1Ln
	ee5T4aBoFCzrYWIcZq2AkynG,aAlkcrojSVg = k67kpg2JWKFjPlBsweEA4U(IDFyf2vjJS1eohqrsO0PYHcnlL7,GXqwjoV2nP4IYpe970BvELfxh5bQFy)
	if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
		GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
		return
	Q02dGeiOHYX8NJ36sVa91f4 += aAlkcrojSVg
	del IDFyf2vjJS1eohqrsO0PYHcnlL7,aAlkcrojSVg
	hfnLYPpyjs7rAJl6Fxbw0Q,Kiqd4bB5DORle9hAYNzGkjZF,C1waZEmdt59PeOpWi6Y,x4FHThtE68ROieYskW,ksXvoYf8NiWTuOnH47gQZB3ry9 = {},{},{},0,0
	ByUSr9X0Lw = list(ee5T4aBoFCzrYWIcZq2AkynG.keys())
	aTBOWYdNpDmt6ZQ2b17 = len(ByUSr9X0Lw)*3
	if 1:
		A8AgRHsLxWo9Yz = {}
		for vHWoXGczON in ByUSr9X0Lw:
			A8AgRHsLxWo9Yz[vHWoXGczON] = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=iRgD3C95yjKNzcrxav8GXBZoOYAfp,args=(vHWoXGczON,))
			A8AgRHsLxWo9Yz[vHWoXGczON].start()
		for vHWoXGczON in ByUSr9X0Lw:
			A8AgRHsLxWo9Yz[vHWoXGczON].join()
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
	else:
		for vHWoXGczON in ByUSr9X0Lw:
			iRgD3C95yjKNzcrxav8GXBZoOYAfp(vHWoXGczON)
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return
	OOKMeIaUPtBYi1CsJy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,False)
	ByUSr9X0Lw = list(hfnLYPpyjs7rAJl6Fxbw0Q.keys())
	iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV = 0
	if 1:
		A8AgRHsLxWo9Yz = {}
		for vHWoXGczON in ByUSr9X0Lw:
			A8AgRHsLxWo9Yz[vHWoXGczON] = ayQ463vhoOT2NqWjkX7fLFuKJ.Thread(target=wngDRPXfp5MuNxdmIAbZOeiHa0YC,args=(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON))
			A8AgRHsLxWo9Yz[vHWoXGczON].start()
		for vHWoXGczON in ByUSr9X0Lw:
			A8AgRHsLxWo9Yz[vHWoXGczON].join()
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
			GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
			return
	else:
		for vHWoXGczON in ByUSr9X0Lw:
			wngDRPXfp5MuNxdmIAbZOeiHa0YC(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON)
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return
	zG37PsWCeVZ4aYtmkE2DTowqBF = 0
	cFGhi4rxf9zS7IJ2AZlORBnvgLaK = len(Q02dGeiOHYX8NJ36sVa91f4)
	H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'IGNORED')
	for ffd3vPGr6MOKE in Q02dGeiOHYX8NJ36sVa91f4:
		if zG37PsWCeVZ4aYtmkE2DTowqBF%27==0:
			BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,95+int(5*zG37PsWCeVZ4aYtmkE2DTowqBF//cFGhi4rxf9zS7IJ2AZlORBnvgLaK),'تخزين المهملة','الفيديو رقم:-',str(zG37PsWCeVZ4aYtmkE2DTowqBF)+' / '+str(cFGhi4rxf9zS7IJ2AZlORBnvgLaK))
			if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled():
				GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
				return
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(H8WhnXc1YZ6yidq2EjACv4B,'IGNORED',str(ffd3vPGr6MOKE),NdKhAS6MXVEORLTwob92pxlZ,hzP83xLawFqYneDtHGmSriWE)
		zG37PsWCeVZ4aYtmkE2DTowqBF += 1
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(H8WhnXc1YZ6yidq2EjACv4B,'IGNORED','__COUNT__',str(cFGhi4rxf9zS7IJ2AZlORBnvgLaK),hzP83xLawFqYneDtHGmSriWE)
	eMN9D4l8hbiKFyLPHIVkAmB7Jvt(H8WhnXc1YZ6yidq2EjACv4B,'DUMMY','__DUMMY__','1',hzP83xLawFqYneDtHGmSriWE)
	GXqwjoV2nP4IYpe970BvELfxh5bQFy.close()
	XJ62UBRmIqFvfiNTQj.sleep(1)
	wFlovynI9iuNVg = JbGCRM586yE91VWgmv2pxk(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,False)
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج',D7INg5kyRjwf4ZtoePVUrb1h2SJ+'تم جلب ملفات ـIPTV جديدة'+kjd9LyNqQHMUevZiRI7OlBGF1h+'\n\n'+wFlovynI9iuNVg)
	uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	fPhA8zJWjpb19U(False)
	MIjcStaDWnv(False)
	return
def iRgD3C95yjKNzcrxav8GXBZoOYAfp(vHWoXGczON):
	global GXqwjoV2nP4IYpe970BvELfxh5bQFy,ee5T4aBoFCzrYWIcZq2AkynG,iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV,hfnLYPpyjs7rAJl6Fxbw0Q,Kiqd4bB5DORle9hAYNzGkjZF,C1waZEmdt59PeOpWi6Y,x4FHThtE68ROieYskW,ksXvoYf8NiWTuOnH47gQZB3ry9,aTBOWYdNpDmt6ZQ2b17
	hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON] = {}
	FFCE0z9SvfuGn1theHdLcgXp5,A8rEYMZwj97CyWekHXB3DvgTiqQoS = {},[]
	O3TNSGVC4H = len(ee5T4aBoFCzrYWIcZq2AkynG[vHWoXGczON])
	hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON]['__COUNT__'] = O3TNSGVC4H
	if O3TNSGVC4H>0:
		LCvVQ7zExacZb,U7gBkY5xIl6,Uq6OKw8vSZQiFabkWzIB92e5sYjp,Npi7G6Hvnf80QB3j,KwS9xnRQA0G = zip(*ee5T4aBoFCzrYWIcZq2AkynG[vHWoXGczON])
		del U7gBkY5xIl6,Uq6OKw8vSZQiFabkWzIB92e5sYjp,Npi7G6Hvnf80QB3j
		II5PpfeZibgu02NHCj = list(set(LCvVQ7zExacZb))
		for ucBCXwgzfPhHRx2NnjGQ in II5PpfeZibgu02NHCj:
			FFCE0z9SvfuGn1theHdLcgXp5[ucBCXwgzfPhHRx2NnjGQ] = NdKhAS6MXVEORLTwob92pxlZ
			hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON][ucBCXwgzfPhHRx2NnjGQ] = []
		BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,60+int(15*ksXvoYf8NiWTuOnH47gQZB3ry9//aTBOWYdNpDmt6ZQ2b17),'تصنيع القوائم','الجزء رقم:-',str(ksXvoYf8NiWTuOnH47gQZB3ry9)+' / '+str(aTBOWYdNpDmt6ZQ2b17))
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled(): return
		ksXvoYf8NiWTuOnH47gQZB3ry9 += 1
		DUacheC03KNrw = len(II5PpfeZibgu02NHCj)
		del II5PpfeZibgu02NHCj
		A8rEYMZwj97CyWekHXB3DvgTiqQoS = list(set(zip(LCvVQ7zExacZb,KwS9xnRQA0G)))
		del LCvVQ7zExacZb,KwS9xnRQA0G
		for ucBCXwgzfPhHRx2NnjGQ,nnQPgrIaSEN09T5hf4sx in A8rEYMZwj97CyWekHXB3DvgTiqQoS:
			if not FFCE0z9SvfuGn1theHdLcgXp5[ucBCXwgzfPhHRx2NnjGQ] and nnQPgrIaSEN09T5hf4sx: FFCE0z9SvfuGn1theHdLcgXp5[ucBCXwgzfPhHRx2NnjGQ] = nnQPgrIaSEN09T5hf4sx
		BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,60+int(15*ksXvoYf8NiWTuOnH47gQZB3ry9//aTBOWYdNpDmt6ZQ2b17),'تصنيع القوائم','الجزء رقم:-',str(ksXvoYf8NiWTuOnH47gQZB3ry9)+' / '+str(aTBOWYdNpDmt6ZQ2b17))
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled(): return
		ksXvoYf8NiWTuOnH47gQZB3ry9 += 1
		rYcVmC2tD9F1LHJds3q7OfRNzlbXne = list(FFCE0z9SvfuGn1theHdLcgXp5.keys())
		o7YCPBUkacNI3EsqpHK5wTi6jMt = list(FFCE0z9SvfuGn1theHdLcgXp5.values())
		del FFCE0z9SvfuGn1theHdLcgXp5
		A8rEYMZwj97CyWekHXB3DvgTiqQoS = list(zip(rYcVmC2tD9F1LHJds3q7OfRNzlbXne,o7YCPBUkacNI3EsqpHK5wTi6jMt))
		del rYcVmC2tD9F1LHJds3q7OfRNzlbXne,o7YCPBUkacNI3EsqpHK5wTi6jMt
		A8rEYMZwj97CyWekHXB3DvgTiqQoS = sorted(A8rEYMZwj97CyWekHXB3DvgTiqQoS)
	else: ksXvoYf8NiWTuOnH47gQZB3ry9 += 2
	hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON]['__GROUPS__'] = A8rEYMZwj97CyWekHXB3DvgTiqQoS
	del A8rEYMZwj97CyWekHXB3DvgTiqQoS
	for ucBCXwgzfPhHRx2NnjGQ,ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex in ee5T4aBoFCzrYWIcZq2AkynG[vHWoXGczON]:
		hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON][ucBCXwgzfPhHRx2NnjGQ].append((ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex))
	BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,60+int(15*ksXvoYf8NiWTuOnH47gQZB3ry9//aTBOWYdNpDmt6ZQ2b17),'تصنيع القوائم','الجزء رقم:-',str(ksXvoYf8NiWTuOnH47gQZB3ry9)+' / '+str(aTBOWYdNpDmt6ZQ2b17))
	if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled(): return
	ksXvoYf8NiWTuOnH47gQZB3ry9 += 1
	del ee5T4aBoFCzrYWIcZq2AkynG[vHWoXGczON]
	C1waZEmdt59PeOpWi6Y[vHWoXGczON] = list(hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON].keys())
	Kiqd4bB5DORle9hAYNzGkjZF[vHWoXGczON] = len(C1waZEmdt59PeOpWi6Y[vHWoXGczON])
	x4FHThtE68ROieYskW += Kiqd4bB5DORle9hAYNzGkjZF[vHWoXGczON]
	return
def wngDRPXfp5MuNxdmIAbZOeiHa0YC(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON):
	global GXqwjoV2nP4IYpe970BvELfxh5bQFy,ee5T4aBoFCzrYWIcZq2AkynG,iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV,hfnLYPpyjs7rAJl6Fxbw0Q,Kiqd4bB5DORle9hAYNzGkjZF,C1waZEmdt59PeOpWi6Y,x4FHThtE68ROieYskW,ksXvoYf8NiWTuOnH47gQZB3ry9,aTBOWYdNpDmt6ZQ2b17
	H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON)
	for lH2Tk5x7UqJ6W in range(1+Kiqd4bB5DORle9hAYNzGkjZF[vHWoXGczON]//273):
		ffhydj7MtN4zblS = []
		mEqK5iPWubkjSe3I7nXt = C1waZEmdt59PeOpWi6Y[vHWoXGczON][0:273]
		for ucBCXwgzfPhHRx2NnjGQ in mEqK5iPWubkjSe3I7nXt:
			ffhydj7MtN4zblS.append(hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON][ucBCXwgzfPhHRx2NnjGQ])
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(H8WhnXc1YZ6yidq2EjACv4B,vHWoXGczON,mEqK5iPWubkjSe3I7nXt,ffhydj7MtN4zblS,hzP83xLawFqYneDtHGmSriWE,True)
		iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV += len(mEqK5iPWubkjSe3I7nXt)
		BBKvjLwgdSInHPYkFOzhJpeEcN(GXqwjoV2nP4IYpe970BvELfxh5bQFy,75+int(20*iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV//x4FHThtE68ROieYskW),'تخزين القوائم','القائمة رقم:-',str(iTa7Mp5lhGgY2ZfUOoW0B3ty8cEDFV)+' / '+str(x4FHThtE68ROieYskW))
		if GXqwjoV2nP4IYpe970BvELfxh5bQFy.iscanceled(): return
		del C1waZEmdt59PeOpWi6Y[vHWoXGczON][0:273]
	del hfnLYPpyjs7rAJl6Fxbw0Q[vHWoXGczON],C1waZEmdt59PeOpWi6Y[vHWoXGczON],Kiqd4bB5DORle9hAYNzGkjZF[vHWoXGczON]
	return
def JbGCRM586yE91VWgmv2pxk(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx): return
	IzVgJRBF1ocKH48 = 'رسالة من المبرمج'
	YfUcDrv1JNjiB5l7C9nuoVqXMZ = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'LIVE_ORIGINAL_GROUPED')
	R6A5YDCMqJ7Ocknz2LbsV = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'VOD_ORIGINAL_GROUPED')
	cFGhi4rxf9zS7IJ2AZlORBnvgLaK = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','IGNORED','__COUNT__')
	ThXPnGE9I70tdaKNyeqZ5iFLwY6pB = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	EpfqULKnMNZac3 = hVmfOZ06UbnD2odNq(R6A5YDCMqJ7Ocknz2LbsV,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	IlJwqGROry1C4PvhzT8u5oct3Dg = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','LIVE_GROUPED','__COUNT__')
	knycDjfdwzHT = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	RbjQnuD8T6WPGqZ2y4 = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','VOD_MOVIES_GROUPED','__COUNT__')
	KJ1G369PlWYoHt = hVmfOZ06UbnD2odNq(R6A5YDCMqJ7Ocknz2LbsV,'int','VOD_SERIES_GROUPED','__COUNT__')
	s8LUOkMX3R7wyeCItfA64YpuxaE = hVmfOZ06UbnD2odNq(YfUcDrv1JNjiB5l7C9nuoVqXMZ,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	C1waZEmdt59PeOpWi6Y = hVmfOZ06UbnD2odNq(R6A5YDCMqJ7Ocknz2LbsV,'list','VOD_SERIES_GROUPED','__GROUPS__')
	SQeDwXot6zu = []
	for ucBCXwgzfPhHRx2NnjGQ,SGsBInjFVT12LOhzCafex in C1waZEmdt59PeOpWi6Y:
		oCte0cxNuyn51bAIJZqLMh9 = ucBCXwgzfPhHRx2NnjGQ.split('__SERIES__')[1]
		SQeDwXot6zu.append(oCte0cxNuyn51bAIJZqLMh9)
	kkhTF8tldI3VNWXMAzu7Yv = len(SQeDwXot6zu)
	HLxXen3Wgy9QhIJzYSjtadG = int(RbjQnuD8T6WPGqZ2y4)+int(KJ1G369PlWYoHt)+int(s8LUOkMX3R7wyeCItfA64YpuxaE)+int(knycDjfdwzHT)+int(IlJwqGROry1C4PvhzT8u5oct3Dg)
	wFlovynI9iuNVg = NdKhAS6MXVEORLTwob92pxlZ
	wFlovynI9iuNVg += 'قنوات: '+str(IlJwqGROry1C4PvhzT8u5oct3Dg)
	wFlovynI9iuNVg += '   .   أفلام: '+str(RbjQnuD8T6WPGqZ2y4)
	wFlovynI9iuNVg += '\nمسلسلات: '+str(kkhTF8tldI3VNWXMAzu7Yv)
	wFlovynI9iuNVg += '   .   حلقات: '+str(KJ1G369PlWYoHt)
	wFlovynI9iuNVg += '\nقنوات مجهولة: '+str(knycDjfdwzHT)
	wFlovynI9iuNVg += '   .   فيدوهات مجهولة: '+str(s8LUOkMX3R7wyeCItfA64YpuxaE)
	wFlovynI9iuNVg += '\nمجموع القنوات: '+str(ThXPnGE9I70tdaKNyeqZ5iFLwY6pB)
	wFlovynI9iuNVg += '   .   مجموع الفيديوهات: '+str(EpfqULKnMNZac3)
	wFlovynI9iuNVg += '\n\nمجموع المضافة: '+str(HLxXen3Wgy9QhIJzYSjtadG)
	wFlovynI9iuNVg += '   .   مجموع المهملة: '+str(cFGhi4rxf9zS7IJ2AZlORBnvgLaK)
	if vGYPOQXBhywrVcDAnaENWRuljZx: ZaUVqChKHwRLYbeiOv('center',NdKhAS6MXVEORLTwob92pxlZ,IzVgJRBF1ocKH48,wFlovynI9iuNVg)
	BR4xNu7Wjgkslq = wFlovynI9iuNVg.replace('\n\n',B6IrC7zEHlw1oaeWf)
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,'.\tCounts of IPTV videos   Folder: '+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0+B6IrC7zEHlw1oaeWf+BR4xNu7Wjgkslq)
	return wFlovynI9iuNVg
def OOKMeIaUPtBYi1CsJy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	if vGYPOQXBhywrVcDAnaENWRuljZx:
		jTxAYItnH8rO2KD5aJ43bo9V7kiGS = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if jTxAYItnH8rO2KD5aJ43bo9V7kiGS!=1: return
		wJx2dhIA7skyvr = U53uZnOCd9jwDgxpGaJNTe.replace('___','_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
		try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(wJx2dhIA7skyvr)
		except: pass
	wJx2dhIA7skyvr = RmwsW86vQ1aPzLZAF0HEdlb4y.replace('___','_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(wJx2dhIA7skyvr)
	except: pass
	wJx2dhIA7skyvr = FnyKZ8iu7wAsIHD4SYfr0OC.replace('___','_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	try: IIPNcsCvQnOZk0yejJKl4BtgSrMw.remove(wJx2dhIA7skyvr)
	except: pass
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'SECTIONS_IPTV','SECTIONS_IPTV_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	fPhA8zJWjpb19U(False)
	uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if vGYPOQXBhywrVcDAnaENWRuljZx:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		MIjcStaDWnv(False)
	return
def vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0=NdKhAS6MXVEORLTwob92pxlZ,vGYPOQXBhywrVcDAnaENWRuljZx=True):
	if n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0:
		H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(str(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0),'DUMMY')
		iCmkXMpWGzVKxSTU0L8NE = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'str','DUMMY','__DUMMY__')
		if iCmkXMpWGzVKxSTU0L8NE: return True
	else:
		n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 = '1'
		for H4g8eAZ2bpJYyOniS3mscQo9FaPW in range(1,zWinZrBTwI3stoS7+1):
			H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(str(H4g8eAZ2bpJYyOniS3mscQo9FaPW),'DUMMY')
			iCmkXMpWGzVKxSTU0L8NE = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'str','DUMMY','__DUMMY__')
			if iCmkXMpWGzVKxSTU0L8NE: return True
	if vGYPOQXBhywrVcDAnaENWRuljZx:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+Whef0cxB2iR93SC5IwUtk+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+kjd9LyNqQHMUevZiRI7OlBGF1h)
		IzVgJRBF1ocKH48 = 'إضافة وتغيير رابط '+omh6YcDWKgIBkNG3[1]+' (مجلد '+omh6YcDWKgIBkNG3[int(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)]+')'
		jTxAYItnH8rO2KD5aJ43bo9V7kiGS = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,IzVgJRBF1ocKH48,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if jTxAYItnH8rO2KD5aJ43bo9V7kiGS==1: vP5ik0AFSOgLy(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	return False
def vQHGIF21bUxu9ByzEsXrewmAchVZM(oCOzNbhWryp9DRT4dwa,n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0=NdKhAS6MXVEORLTwob92pxlZ,vHWoXGczON=NdKhAS6MXVEORLTwob92pxlZ,GGju2D5QzAeFLfB=NdKhAS6MXVEORLTwob92pxlZ):
	if not GGju2D5QzAeFLfB: GGju2D5QzAeFLfB = '1'
	ffYWUsElBLFTDkmH1x,aPC0mLklY6jIUypFAwKbc,vGYPOQXBhywrVcDAnaENWRuljZx = tSBXfikTvou6(oCOzNbhWryp9DRT4dwa)
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx): return
	if not ffYWUsElBLFTDkmH1x:
		ffYWUsElBLFTDkmH1x = Z6GiHgnz0jNytc()
		if not ffYWUsElBLFTDkmH1x: return
	kTmJY6UAn87i4z = [NdKhAS6MXVEORLTwob92pxlZ,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not vHWoXGczON:
		if not vGYPOQXBhywrVcDAnaENWRuljZx:
			if   '_IPTV-LIVE_' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[1]
			elif '_IPTV-MOVIES' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[2]
			elif '_IPTV-SERIES' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[3]
			else: vHWoXGczON = kTmJY6UAn87i4z[0]
		else:
			B6BRcJjTNWw82q0Ua15 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			us7rL1qZAJURmQjPTtIhGN0daXf869 = cCanV8J9iKuojqe5v4('أختر البحث المناسب', B6BRcJjTNWw82q0Ua15)
			if us7rL1qZAJURmQjPTtIhGN0daXf869==-1: return
			vHWoXGczON = kTmJY6UAn87i4z[us7rL1qZAJURmQjPTtIhGN0daXf869]
	ffYWUsElBLFTDkmH1x = ffYWUsElBLFTDkmH1x+'_NODIALOGS_'
	if n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: ti3AxKdPBOMs(ffYWUsElBLFTDkmH1x,n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON,GGju2D5QzAeFLfB)
	else:
		for n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0 in range(1,zWinZrBTwI3stoS7+1):
			ti3AxKdPBOMs(ffYWUsElBLFTDkmH1x,str(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0),vHWoXGczON,GGju2D5QzAeFLfB)
		emiIH49XT6jzOQrw[:] = sorted(emiIH49XT6jzOQrw,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq[1].lower())
	return
def ti3AxKdPBOMs(oCOzNbhWryp9DRT4dwa,n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON=NdKhAS6MXVEORLTwob92pxlZ,GGju2D5QzAeFLfB=NdKhAS6MXVEORLTwob92pxlZ):
	if not GGju2D5QzAeFLfB: GGju2D5QzAeFLfB = '1'
	ffYWUsElBLFTDkmH1x,aPC0mLklY6jIUypFAwKbc,vGYPOQXBhywrVcDAnaENWRuljZx = tSBXfikTvou6(oCOzNbhWryp9DRT4dwa)
	if not n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0: return
	if not vUGsjuw7mN8TFakprdZXV(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vGYPOQXBhywrVcDAnaENWRuljZx): return
	if not ffYWUsElBLFTDkmH1x:
		ffYWUsElBLFTDkmH1x = Z6GiHgnz0jNytc()
		if not ffYWUsElBLFTDkmH1x: return
	kTmJY6UAn87i4z = [NdKhAS6MXVEORLTwob92pxlZ,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not vHWoXGczON:
		if not vGYPOQXBhywrVcDAnaENWRuljZx:
			if   '_IPTV-LIVE_' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[1]
			elif '_IPTV-MOVIES' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[2]
			elif '_IPTV-SERIES' in aPC0mLklY6jIUypFAwKbc: vHWoXGczON = kTmJY6UAn87i4z[3]
			else: vHWoXGczON = kTmJY6UAn87i4z[0]
		else:
			B6BRcJjTNWw82q0Ua15 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			us7rL1qZAJURmQjPTtIhGN0daXf869 = cCanV8J9iKuojqe5v4('أختر البحث المناسب', B6BRcJjTNWw82q0Ua15)
			if us7rL1qZAJURmQjPTtIhGN0daXf869==-1: return
			vHWoXGczON = kTmJY6UAn87i4z[us7rL1qZAJURmQjPTtIhGN0daXf869]
	R71FGdnPWt6A = ffYWUsElBLFTDkmH1x.lower()
	H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,'SEARCH')
	CCXjewWZpg = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list','SEARCH',(vHWoXGczON,R71FGdnPWt6A))
	if not CCXjewWZpg:
		lJGPqFBjk3cby4T0pVWe76wfNoaL,l8tkxuRjW9PKAFBUyYoQvZ = [],[]
		if not vHWoXGczON: c9abioz03N1vqKmWJeQw = [1,2,3,4,5]
		else: c9abioz03N1vqKmWJeQw = [kTmJY6UAn87i4z.index(vHWoXGczON)]
		for zG37PsWCeVZ4aYtmkE2DTowqBF in c9abioz03N1vqKmWJeQw:
			H8WhnXc1YZ6yidq2EjACv4B = VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,kTmJY6UAn87i4z[zG37PsWCeVZ4aYtmkE2DTowqBF])
			if zG37PsWCeVZ4aYtmkE2DTowqBF!=3:
				f0CWuX47GAHBsNeQIVoxlZp1Ln = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'dict',kTmJY6UAn87i4z[zG37PsWCeVZ4aYtmkE2DTowqBF])
				del f0CWuX47GAHBsNeQIVoxlZp1Ln['__COUNT__']
				del f0CWuX47GAHBsNeQIVoxlZp1Ln['__GROUPS__']
				del f0CWuX47GAHBsNeQIVoxlZp1Ln['__SEQUENCED_COLUMNS__']
				C1waZEmdt59PeOpWi6Y = list(f0CWuX47GAHBsNeQIVoxlZp1Ln.keys())
				for ucBCXwgzfPhHRx2NnjGQ in C1waZEmdt59PeOpWi6Y:
					for ueFHThK2pDYc,pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex in f0CWuX47GAHBsNeQIVoxlZp1Ln[ucBCXwgzfPhHRx2NnjGQ]:
						if R71FGdnPWt6A in pmAFLa7SRWhcK5dn6DxrwYO.lower(): l8tkxuRjW9PKAFBUyYoQvZ.append((pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex))
					del f0CWuX47GAHBsNeQIVoxlZp1Ln[ucBCXwgzfPhHRx2NnjGQ]
				del f0CWuX47GAHBsNeQIVoxlZp1Ln
			else: C1waZEmdt59PeOpWi6Y = hVmfOZ06UbnD2odNq(H8WhnXc1YZ6yidq2EjACv4B,'list',kTmJY6UAn87i4z[zG37PsWCeVZ4aYtmkE2DTowqBF],'__GROUPS__')
			for ucBCXwgzfPhHRx2NnjGQ in C1waZEmdt59PeOpWi6Y:
				try: ucBCXwgzfPhHRx2NnjGQ,SGsBInjFVT12LOhzCafex = ucBCXwgzfPhHRx2NnjGQ
				except: SGsBInjFVT12LOhzCafex = NdKhAS6MXVEORLTwob92pxlZ
				if R71FGdnPWt6A in ucBCXwgzfPhHRx2NnjGQ.lower():
					if zG37PsWCeVZ4aYtmkE2DTowqBF!=3: QOSPNZKHWY0B2Xag = ucBCXwgzfPhHRx2NnjGQ
					else:
						bGjgpEXoYZuAeR8f127KT4OhNMckV,jo01ZIwOuYcDGefPQLkbTpqv = ucBCXwgzfPhHRx2NnjGQ.split('__SERIES__')
						if R71FGdnPWt6A in bGjgpEXoYZuAeR8f127KT4OhNMckV.lower(): QOSPNZKHWY0B2Xag = bGjgpEXoYZuAeR8f127KT4OhNMckV
						else: QOSPNZKHWY0B2Xag = jo01ZIwOuYcDGefPQLkbTpqv
					lJGPqFBjk3cby4T0pVWe76wfNoaL.append((ucBCXwgzfPhHRx2NnjGQ,QOSPNZKHWY0B2Xag,kTmJY6UAn87i4z[zG37PsWCeVZ4aYtmkE2DTowqBF],SGsBInjFVT12LOhzCafex))
			del C1waZEmdt59PeOpWi6Y
		lJGPqFBjk3cby4T0pVWe76wfNoaL = set(lJGPqFBjk3cby4T0pVWe76wfNoaL)
		l8tkxuRjW9PKAFBUyYoQvZ = set(l8tkxuRjW9PKAFBUyYoQvZ)
		lJGPqFBjk3cby4T0pVWe76wfNoaL = sorted(lJGPqFBjk3cby4T0pVWe76wfNoaL,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq[1])
		l8tkxuRjW9PKAFBUyYoQvZ = sorted(l8tkxuRjW9PKAFBUyYoQvZ,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq[0])
		eMN9D4l8hbiKFyLPHIVkAmB7Jvt(H8WhnXc1YZ6yidq2EjACv4B,'SEARCH',(vHWoXGczON,R71FGdnPWt6A),(lJGPqFBjk3cby4T0pVWe76wfNoaL,l8tkxuRjW9PKAFBUyYoQvZ),hzP83xLawFqYneDtHGmSriWE)
	else: lJGPqFBjk3cby4T0pVWe76wfNoaL,l8tkxuRjW9PKAFBUyYoQvZ = CCXjewWZpg
	C1waZEmdt59PeOpWi6Y = len(lJGPqFBjk3cby4T0pVWe76wfNoaL)
	yy1wcpAbSBL = len(l8tkxuRjW9PKAFBUyYoQvZ)
	nnkBNQrAK1SmzpfYD0j = int(GGju2D5QzAeFLfB)
	mLZQjbAOrUvGClRwHJgzN8V = max(0,(nnkBNQrAK1SmzpfYD0j-1)*100)
	u4BEOvSXALs1 = max(0,nnkBNQrAK1SmzpfYD0j*100)
	ZyJ1HoFjAOYWk0lCU8a6Gh = max(0,mLZQjbAOrUvGClRwHJgzN8V-C1waZEmdt59PeOpWi6Y)
	KDVm4UJOrvq2WNyA9F1GhI = max(0,u4BEOvSXALs1-C1waZEmdt59PeOpWi6Y)
	for ucBCXwgzfPhHRx2NnjGQ,QOSPNZKHWY0B2Xag,pl3JLFDaHiUV9v0wdh,SGsBInjFVT12LOhzCafex in lJGPqFBjk3cby4T0pVWe76wfNoaL[mLZQjbAOrUvGClRwHJgzN8V:u4BEOvSXALs1]:
		ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+QOSPNZKHWY0B2Xag,pl3JLFDaHiUV9v0wdh,234,SGsBInjFVT12LOhzCafex,'1',ucBCXwgzfPhHRx2NnjGQ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	del lJGPqFBjk3cby4T0pVWe76wfNoaL
	for pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,SGsBInjFVT12LOhzCafex in l8tkxuRjW9PKAFBUyYoQvZ[ZyJ1HoFjAOYWk0lCU8a6Gh:KDVm4UJOrvq2WNyA9F1GhI]:
		tZYp17hkvqMbR = atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(TixSXhpW69Uba4f1NPqzYE7JcZ)
		oJeO8LqTXi7W = 'live'
		if '.mkv' in tZYp17hkvqMbR or 'VOD' in vHWoXGczON: oJeO8LqTXi7W = 'video'
		ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,235,SGsBInjFVT12LOhzCafex,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	del l8tkxuRjW9PKAFBUyYoQvZ
	vBGAzWDix8LQoFljXCIpw3uKVZ(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,GGju2D5QzAeFLfB,vHWoXGczON,239,C1waZEmdt59PeOpWi6Y+yy1wcpAbSBL,ffYWUsElBLFTDkmH1x+'_NODIALOGS_')
	return
def vBGAzWDix8LQoFljXCIpw3uKVZ(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,GGju2D5QzAeFLfB,vHWoXGczON,pPrvqm3tjuXLTgw1,HLxXen3Wgy9QhIJzYSjtadG,ui7N5YGR9KdslpEbQkVTwFqDgI):
	if GGju2D5QzAeFLfB!='1': ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'صفحة '+str(1),vHWoXGczON,pPrvqm3tjuXLTgw1,NdKhAS6MXVEORLTwob92pxlZ,str(1),ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	if not HLxXen3Wgy9QhIJzYSjtadG: HLxXen3Wgy9QhIJzYSjtadG = 0
	QwxSyIqjWrC0Etz1s9 = int(HLxXen3Wgy9QhIJzYSjtadG/100)+1
	for nnkBNQrAK1SmzpfYD0j in range(2,QwxSyIqjWrC0Etz1s9):
		s1s0Ro2vAeDXG9wapJEk4O = (nnkBNQrAK1SmzpfYD0j%10==0 or int(GGju2D5QzAeFLfB)-4<nnkBNQrAK1SmzpfYD0j<int(GGju2D5QzAeFLfB)+4)
		OhN8Iwg5TH39YCvf = (s1s0Ro2vAeDXG9wapJEk4O and int(GGju2D5QzAeFLfB)-40<nnkBNQrAK1SmzpfYD0j<int(GGju2D5QzAeFLfB)+40)
		if str(nnkBNQrAK1SmzpfYD0j)!=GGju2D5QzAeFLfB and (nnkBNQrAK1SmzpfYD0j%100==0 or OhN8Iwg5TH39YCvf):
			ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'صفحة '+str(nnkBNQrAK1SmzpfYD0j),vHWoXGczON,pPrvqm3tjuXLTgw1,NdKhAS6MXVEORLTwob92pxlZ,str(nnkBNQrAK1SmzpfYD0j),ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	if str(QwxSyIqjWrC0Etz1s9)!=GGju2D5QzAeFLfB: ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+'أخر صفحة '+str(QwxSyIqjWrC0Etz1s9),vHWoXGczON,pPrvqm3tjuXLTgw1,NdKhAS6MXVEORLTwob92pxlZ,str(QwxSyIqjWrC0Etz1s9),ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	return
def VHFAL9igJ2saU5Xt(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON):
	if 'SERIES' in vHWoXGczON or 'VOD_ORIGINAL' in vHWoXGczON: H8WhnXc1YZ6yidq2EjACv4B = FnyKZ8iu7wAsIHD4SYfr0OC
	else: H8WhnXc1YZ6yidq2EjACv4B = RmwsW86vQ1aPzLZAF0HEdlb4y
	H8WhnXc1YZ6yidq2EjACv4B = H8WhnXc1YZ6yidq2EjACv4B.replace('___','_'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	return H8WhnXc1YZ6yidq2EjACv4B
def b9bgkQrYWZO30jRS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0,vHWoXGczON,PNVChFSnk4HEBwGTKd5m0):
	APgYxb0Ksd,V8zyRjo6bpkl14qXIvWmC,yP4kQfHATSoOt7CZVp8D,qfRW2x4uosEYZJ59Kl6mLcQ,sXz6et9qU5DR0cBhyQ7TlML2 = HHVaFs2AgEcyMGhS(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if not qfRW2x4uosEYZJ59Kl6mLcQ: return
	RpYN2DWoKIbUHuL = uOagfXTyh4zjYP6plMbsnSe(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0)
	if   vHWoXGczON=='XTREAM_LIVE_GROUPS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_live_categories'
	elif vHWoXGczON=='XTREAM_VOD_GROUPS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_vod_categories'
	elif vHWoXGczON=='XTREAM_SERIES_GROUPS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_series_categories'
	elif vHWoXGczON=='XTREAM_LIVE_ITEMS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_live_streams&category_id='+PNVChFSnk4HEBwGTKd5m0
	elif vHWoXGczON=='XTREAM_VOD_ITEMS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_vod_streams&category_id='+PNVChFSnk4HEBwGTKd5m0
	elif vHWoXGczON=='XTREAM_SERIES_ITEMS': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_series&category_id='+PNVChFSnk4HEBwGTKd5m0
	elif vHWoXGczON=='XTREAM_EPISODES': TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd+'&action=get_series_info&series_id='+PNVChFSnk4HEBwGTKd5m0
	else: return
	KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',TixSXhpW69Uba4f1NPqzYE7JcZ,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'IPTV-XTREAM_MENUS-1st')
	JIVXou7hYWQ6CKDsPOUytnml3e9 = KgjQPrdmkW0pZfiwx9e6qL.content
	if QBp28giCnayJzmZH6vYO: JIVXou7hYWQ6CKDsPOUytnml3e9 = JIVXou7hYWQ6CKDsPOUytnml3e9.decode(YRvPKe2zMTDs8UCkr).encode(YRvPKe2zMTDs8UCkr)
	zXmtWEy1lBRw4cCoHI = BdnA8WwtJeKUVvE('list',JIVXou7hYWQ6CKDsPOUytnml3e9)
	if 'GROUPS' in vHWoXGczON:
		vHWoXGczON = vHWoXGczON.replace('_GROUPS','_ITEMS')
		zXmtWEy1lBRw4cCoHI = sorted(zXmtWEy1lBRw4cCoHI,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq['category_name'].lower())
		for ucBCXwgzfPhHRx2NnjGQ in zXmtWEy1lBRw4cCoHI:
			Wm7RJb1HIyvZsphFfEU8Yc = ucBCXwgzfPhHRx2NnjGQ['category_id']
			pmAFLa7SRWhcK5dn6DxrwYO = ucBCXwgzfPhHRx2NnjGQ['category_name']
			ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,vHWoXGczON,285,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,str(Wm7RJb1HIyvZsphFfEU8Yc),NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	elif vHWoXGczON=='XTREAM_SERIES_ITEMS':
		zXmtWEy1lBRw4cCoHI = sorted(zXmtWEy1lBRw4cCoHI,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq['name'].lower())
		for zzIWgLZ3OBjwEHKo in zXmtWEy1lBRw4cCoHI:
			pmAFLa7SRWhcK5dn6DxrwYO = zzIWgLZ3OBjwEHKo['name']
			nnQPgrIaSEN09T5hf4sx = zzIWgLZ3OBjwEHKo['cover']
			Wm7RJb1HIyvZsphFfEU8Yc = zzIWgLZ3OBjwEHKo['series_id']
			ZI51XvE8YatWCmNdrp('folder',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,'XTREAM_EPISODES',285,nnQPgrIaSEN09T5hf4sx,NdKhAS6MXVEORLTwob92pxlZ,str(Wm7RJb1HIyvZsphFfEU8Yc),NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	elif vHWoXGczON=='XTREAM_EPISODES':
		nnQPgrIaSEN09T5hf4sx = zXmtWEy1lBRw4cCoHI['info']['cover']
		JHKDFe6Am0ruz8 = zXmtWEy1lBRw4cCoHI['info']['name']
		q2qWu4jDaCvSmRV = zXmtWEy1lBRw4cCoHI['episodes']
		for HY1hsJMjr5no7SxETKpN in q2qWu4jDaCvSmRV:
			WQ6uieCN0ctfnOSrlhL8w51dA7 = q2qWu4jDaCvSmRV[HY1hsJMjr5no7SxETKpN]
			for tb5mdIfprAia in WQ6uieCN0ctfnOSrlhL8w51dA7:
				pmAFLa7SRWhcK5dn6DxrwYO = tb5mdIfprAia['title']
				h032V5HxLnqfKUXbkjBMlZt = YYqECUofyi7wFrW.findall('\d+.(S\d+E\d+)',pmAFLa7SRWhcK5dn6DxrwYO,YYqECUofyi7wFrW.DOTALL)
				if h032V5HxLnqfKUXbkjBMlZt: pmAFLa7SRWhcK5dn6DxrwYO = JHKDFe6Am0ruz8+Vwgflszp4WRA93kx6hvdua21HX5cOb+h032V5HxLnqfKUXbkjBMlZt[0]
				Wm7RJb1HIyvZsphFfEU8Yc = tb5mdIfprAia['id']
				KnBzZaqy5ipVsxPUv9WL8wD = tb5mdIfprAia['container_extension']
				TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd.split('/player_api.php')[0]+'/series/'+qfRW2x4uosEYZJ59Kl6mLcQ+'/'+sXz6et9qU5DR0cBhyQ7TlML2+'/'+str(Wm7RJb1HIyvZsphFfEU8Yc)+'.'+KnBzZaqy5ipVsxPUv9WL8wD
				ZI51XvE8YatWCmNdrp('video',vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,235,nnQPgrIaSEN09T5hf4sx,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	elif 'ITEMS' in vHWoXGczON:
		oJeO8LqTXi7W = 'live' if 'LIVE' in vHWoXGczON else 'video'
		zXmtWEy1lBRw4cCoHI = sorted(zXmtWEy1lBRw4cCoHI,reverse=False,key=lambda GWkcLexzmpJyl7nYq: GWkcLexzmpJyl7nYq['name'].lower())
		for SZ2CFD8flz in zXmtWEy1lBRw4cCoHI:
			pmAFLa7SRWhcK5dn6DxrwYO = SZ2CFD8flz['name']
			nnQPgrIaSEN09T5hf4sx = SZ2CFD8flz['stream_icon']
			Wm7RJb1HIyvZsphFfEU8Yc = SZ2CFD8flz['stream_id']
			try:
				KnBzZaqy5ipVsxPUv9WL8wD = SZ2CFD8flz['container_extension']
				if KnBzZaqy5ipVsxPUv9WL8wD: KnBzZaqy5ipVsxPUv9WL8wD = '.'+KnBzZaqy5ipVsxPUv9WL8wD
			except: KnBzZaqy5ipVsxPUv9WL8wD = NdKhAS6MXVEORLTwob92pxlZ
			if SZ2CFD8flz['stream_type']=='live': FXmB68Vl1npDkCEaO9zuciTxAt0,hYBH7CEj8KMs = NdKhAS6MXVEORLTwob92pxlZ,'live'
			elif SZ2CFD8flz['stream_type']=='movie': FXmB68Vl1npDkCEaO9zuciTxAt0,hYBH7CEj8KMs = 'movie/','video'
			TixSXhpW69Uba4f1NPqzYE7JcZ = APgYxb0Ksd.split('/player_api.php')[0]+'/'+FXmB68Vl1npDkCEaO9zuciTxAt0+qfRW2x4uosEYZJ59Kl6mLcQ+'/'+sXz6et9qU5DR0cBhyQ7TlML2+'/'+str(Wm7RJb1HIyvZsphFfEU8Yc)+KnBzZaqy5ipVsxPUv9WL8wD
			ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,vzAmZXEiDGPInYHrlF3bLK57yte4Uj+pmAFLa7SRWhcK5dn6DxrwYO,TixSXhpW69Uba4f1NPqzYE7JcZ,235,nnQPgrIaSEN09T5hf4sx,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,{'folder':n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0})
	return
def uN4sXMInz1oQCR75WAxFhPYwv9k(n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0):
	lDY2Q5J4IA = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.provider')
	kDQWK1Rs84qiHO9fFmVGJILNpb = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting('av.language.code')
	WUM9Xg1RHz(ZFMPvkNQbT2cHiUj,'MENUS_CACHE_'+lDY2Q5J4IA+'_'+kDQWK1Rs84qiHO9fFmVGJILNpb,'%_IP'+n3eg6iKvUpxMtLIWZbqhQ8Ez79yu0+'_%')
	return
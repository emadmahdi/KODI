# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'FABRAKA'
LJfTAEQPv9h4BXdwUp = '_FBK_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الصفحة الرئيسية','Sign in']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==620: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==621: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==622: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==623: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = o2XkvGWlaVzsUjdDLbQpg8(url,text)
	elif mode==624: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==629: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	REGxsWAoilB7dCFNgMhz0V98bcm,url,VNc1u4edS90FK5W6bsMgQC2B = C8Y0qMpABJKzNRG9kvOWy(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,629,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'جديد الحلقات',REGxsWAoilB7dCFNgMhz0V98bcm,621,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'new_episodes')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'جديد الأفلام',REGxsWAoilB7dCFNgMhz0V98bcm,621,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'new_movies')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المسلسلات المميزة',REGxsWAoilB7dCFNgMhz0V98bcm,621,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured_series')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"navslide-wrap"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,624)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('/category.php">(.*?)"navslide-divider"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("'dropdown-menu'(.*?)</ul>",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zyoNRs5F72Bkr0JYfGh6PULju4bO in bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace(zyoNRs5F72Bkr0JYfGh6PULju4bO,NdKhAS6MXVEORLTwob92pxlZ)
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,624)
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FABRAKA-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"caret"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('"presentation"','</ul>')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [(NdKhAS6MXVEORLTwob92pxlZ,AAMHoYxRCmt2D6ph89W)]
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' فرز أو فلتر أو ترتيب '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		for MKUGqBYspa2ALPwc1,AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if MKUGqBYspa2ALPwc1: MKUGqBYspa2ALPwc1 = MKUGqBYspa2ALPwc1+': '
			for zehVcU893FC6LEd1Aij,title in items:
				title = MKUGqBYspa2ALPwc1+title
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,621)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"pm-category-subcats"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if len(items)<30:
			ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
			for zehVcU893FC6LEd1Aij,title in items:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,621)
	if not yyuOVAGPZijetcaNz0b and not gcBxGPatZIzQ1: hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	if kF13d0oJXn4xKH=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FABRAKA-TITLES-1st')
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FABRAKA-TITLES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	AAMHoYxRCmt2D6ph89W,items = NdKhAS6MXVEORLTwob92pxlZ,[]
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	if kF13d0oJXn4xKH=='ajax-search':
		AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	elif kF13d0oJXn4xKH=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pm-video-watch-featured"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_episodes':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)>1: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	elif kF13d0oJXn4xKH=='featured_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(data-echo=".*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if AAMHoYxRCmt2D6ph89W and not items: items = YYqECUofyi7wFrW.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items: return
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة).\d+',title,YYqECUofyi7wFrW.DOTALL)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,622,TTuPH708dUNnjlG3oQpkZsi)
		elif kF13d0oJXn4xKH=='new_episodes':
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,622,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z:
			title = '_MOD_' + N1VjdbtuO3z[0][0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,623,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,623,TTuPH708dUNnjlG3oQpkZsi)
	if 1:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=='#': continue
				zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,621)
	return
def o2XkvGWlaVzsUjdDLbQpg8(url,ck82Wb9aGlYMsEImj):
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FABRAKA-EPISODES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	k1ChwgueU5nbDX6K0BOEGx = YYqECUofyi7wFrW.findall('"series-header".*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if k1ChwgueU5nbDX6K0BOEGx: TTuPH708dUNnjlG3oQpkZsi = k1ChwgueU5nbDX6K0BOEGx[0]
	else: TTuPH708dUNnjlG3oQpkZsi = NdKhAS6MXVEORLTwob92pxlZ
	items = []
	UwIYTGWyjosc6pikf48xLe5du = False
	if yyuOVAGPZijetcaNz0b and not ck82Wb9aGlYMsEImj:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for ck82Wb9aGlYMsEImj,title in items:
			ck82Wb9aGlYMsEImj = ck82Wb9aGlYMsEImj.strip('#')
			if len(items)>1: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,623,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,ck82Wb9aGlYMsEImj)
			else: UwIYTGWyjosc6pikf48xLe5du = True
	else: UwIYTGWyjosc6pikf48xLe5du = True
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('id="'+ck82Wb9aGlYMsEImj+'"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1 and UwIYTGWyjosc6pikf48xLe5du:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		items = []
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi))
		if not items: items = YYqECUofyi7wFrW.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in items:
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
			title = title.replace('</em><span>',Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,622,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp = []
	url = url.replace('watch.php','see.php')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FABRAKA-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"WatchList"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__watch'
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<iframe src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]+'?named='+title+'__embed'
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"downloadlist"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search.php?keywords='+search
	REGxsWAoilB7dCFNgMhz0V98bcm,BfjcMoqOsmdUvZVCHWIyQKi,HYfNLiDK3yRF7 = C8Y0qMpABJKzNRG9kvOWy(ee2SDNw9sRVdhxmioTIkZGj6FqzrBE,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi,'search')
	return
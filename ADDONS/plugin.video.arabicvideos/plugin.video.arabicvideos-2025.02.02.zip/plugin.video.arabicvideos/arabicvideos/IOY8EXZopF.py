# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'CIMA4U'
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
LJfTAEQPv9h4BXdwUp = '_C4U_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==420: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==421: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==422: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = fxdz47XjOWTDnGJ6Zw1cvItbm(url)
	elif mode==423: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==424: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==427: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = xSf6MDCKGg0(url)
	elif mode==429: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = YYqECUofyi7wFrW.findall('href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	REGxsWAoilB7dCFNgMhz0V98bcm = REGxsWAoilB7dCFNgMhz0V98bcm[0].strip('/')
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(REGxsWAoilB7dCFNgMhz0V98bcm,'url')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,429,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',REGxsWAoilB7dCFNgMhz0V98bcm,425)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',REGxsWAoilB7dCFNgMhz0V98bcm,424)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الرئيسية',REGxsWAoilB7dCFNgMhz0V98bcm,421)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('NavigationMenu(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="*(.*?)"*>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if '/actors' in zehVcU893FC6LEd1Aij: title = 'أفلام النجوم'
		elif '/netflix' in zehVcU893FC6LEd1Aij: title = 'أفلام ومسلسلات نيتفلكس'
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,421)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'قائمة تفصيلية',REGxsWAoilB7dCFNgMhz0V98bcm,427)
	return
def xSf6MDCKGg0(website=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('FilteringTitle(.*?)PageTitle',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for II4s1CdgcbN6BSvWPnHtz,id,zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		if 'netflix-movies' in zehVcU893FC6LEd1Aij: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in zehVcU893FC6LEd1Aij: title = 'مسلسلات نيتفلكس'
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,II4s1CdgcbN6BSvWPnHtz+'|'+id)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if not mfVtpzhI3WGnAx0 or '|' in mfVtpzhI3WGnAx0:
		if '|' not in mfVtpzhI3WGnAx0: PHku698FMgAtX = NdKhAS6MXVEORLTwob92pxlZ
		else: PHku698FMgAtX = '/archive/'+mfVtpzhI3WGnAx0
		mqgWoY2a3fw9MUB = False
		if 'PinSlider' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',url,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
			mqgWoY2a3fw9MUB = True
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('PageTitle(.*?)PageContent',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			zyoNRs5F72Bkr0JYfGh6PULju4bO = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('data-tab="(.*?)".*?<span>(.*?)<',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
			for q2qyGrWpAa8KHsOP,PJN58A9SFZTwi6uLMB73m in APRuYMmlIVGTX:
				xKXbWz9coR7jUfil45aQENr0ICBJg = REGxsWAoilB7dCFNgMhz0V98bcm+'/ajaxcenter/action/HomepageLoader/tab/'+q2qyGrWpAa8KHsOP+PHku698FMgAtX+'/'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+PJN58A9SFZTwi6uLMB73m,xKXbWz9coR7jUfil45aQENr0ICBJg,421)
				mqgWoY2a3fw9MUB = True
		if mqgWoY2a3fw9MUB: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	if mfVtpzhI3WGnAx0=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('PinSlider(.*?)MultiFilter',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('PinSlider(.*?)PageTitle',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		else: AAMHoYxRCmt2D6ph89W = NdKhAS6MXVEORLTwob92pxlZ
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
	elif '/filter/' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('PageContent(.*?)class="*pagination"*',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif '/actors' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('PageContent(.*?)class="*pagination"*',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('Cima4uBlocks(.*?)</li></ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		else: AAMHoYxRCmt2D6ph89W = NdKhAS6MXVEORLTwob92pxlZ
	if not items: items = YYqECUofyi7wFrW.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items: items = YYqECUofyi7wFrW.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if not title: continue
		if '?news=' in zehVcU893FC6LEd1Aij: continue
		title = title.replace('مشاهدة ',NdKhAS6MXVEORLTwob92pxlZ)
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) حلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if N1VjdbtuO3z and 'حلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,422,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/actor/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,421,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,422,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6 and mfVtpzhI3WGnAx0!='featured':
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
			if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,421)
	ZZvTe8pmBr1buPwaj9N = YYqECUofyi7wFrW.findall('</li><a href="(.*?)".*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if ZZvTe8pmBr1buPwaj9N:
		zehVcU893FC6LEd1Aij,title = ZZvTe8pmBr1buPwaj9N[0]
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,421)
	return
def fxdz47XjOWTDnGJ6Zw1cvItbm(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-SEASONS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="WatchNow".*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		url = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-SEASONS-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('SeasonsSections(.*?)</div></div></div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if '/tag/' in url or '/actor' in url:
		hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		TTuPH708dUNnjlG3oQpkZsi = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Thumb')
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall("href='(.*?)'>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		LL3UxVMdhNHg = ['مسلسل','موسم','برنامج','حلقة']
		for zehVcU893FC6LEd1Aij,title in items:
			if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in LL3UxVMdhNHg):
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,423,TTuPH708dUNnjlG3oQpkZsi)
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,426,TTuPH708dUNnjlG3oQpkZsi)
	else: vl57jIYC4a(url)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"background-image:url\((.*?)\)',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if TTuPH708dUNnjlG3oQpkZsi: TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
	else: TTuPH708dUNnjlG3oQpkZsi = NdKhAS6MXVEORLTwob92pxlZ
	PPkFzM036KoU = YYqECUofyi7wFrW.findall('EpisodesSection(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if PPkFzM036KoU:
		AAMHoYxRCmt2D6ph89W = PPkFzM036KoU[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,N1VjdbtuO3z in items:
			title = title+Vwgflszp4WRA93kx6hvdua21HX5cOb+N1VjdbtuO3z
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,426,TTuPH708dUNnjlG3oQpkZsi)
	else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+'رابط التشغيل',url,426,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ku1JLjPTovhReOEbD8xs5 = VNc1u4edS90FK5W6bsMgQC2B.url
	if QBp28giCnayJzmZH6vYO: ku1JLjPTovhReOEbD8xs5 = ku1JLjPTovhReOEbD8xs5.encode(YRvPKe2zMTDs8UCkr)
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(ku1JLjPTovhReOEbD8xs5,'url')
	UTwH7zjZOrmFl = []
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('WatchSection(.*?)</div></div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-link="(.*?)".*? />(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for PCdTnUSfhk5x,title in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if 'myvid' in title.lower(): title = 'خاص '+title
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/structure/server.php?id='+PCdTnUSfhk5x+'?named='+title+'__watch'
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('DownloadServers(.*?)</div></div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*? />(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if 'myvid' in title.lower(): PJN58A9SFZTwi6uLMB73m = '__خاص'
			else: PJN58A9SFZTwi6uLMB73m = NdKhAS6MXVEORLTwob92pxlZ
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'+PJN58A9SFZTwi6uLMB73m
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.replace(SSDnd9QAUwo86G7eurKlaPikE3qsv,NdKhAS6MXVEORLTwob92pxlZ)
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/Search?q='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
def oDejqO6uYrsWp5ym9TQtEdV(url):
	if 'smartemadfilter' not in url: url = msbTrJW03xuvA(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('MultiFilter(.*?)PageTitle',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return Hk9cy1IL0PXCw3OgYE5nr
def nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W):
	items = YYqECUofyi7wFrW.findall('data-id="(.*?)".*?</div>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	return items
def WW6XmdChlOPbY(url):
	p9pPoLdYMbqwXz1FQraUxKNv35 = url.split('/smartemadfilter?')[0]
	Q5Jbsopg4HhxqTY = msbTrJW03xuvA(url,'url')
	url = url.replace(p9pPoLdYMbqwXz1FQraUxKNv35,Q5Jbsopg4HhxqTY)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
axsbpdckhGP127u5wEgnZtV4LWvzli = ['category','types','release-year']
dW42o7vIOrS9wu = ['Quality','release-year','types','category']
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global axsbpdckhGP127u5wEgnZtV4LWvzli
			axsbpdckhGP127u5wEgnZtV4LWvzli = axsbpdckhGP127u5wEgnZtV4LWvzli[1:]
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='ALL_ITEMS_FILTER':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'/smartemadfilter?'+Jv2yebcHLo5GCrXZlw
		BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',BfjcMoqOsmdUvZVCHWIyQKi,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filter')
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filter')
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	Hk9cy1IL0PXCw3OgYE5nr = oDejqO6uYrsWp5ym9TQtEdV(url)
	dict = {}
	for name,AAMHoYxRCmt2D6ph89W,zZ0VrYRv6m8 in Hk9cy1IL0PXCw3OgYE5nr:
		if '/category/' in url and zZ0VrYRv6m8=='category': continue
		name = name.replace('--',NdKhAS6MXVEORLTwob92pxlZ)
		items = nkSR6t57HFW49sQTawqf23(AAMHoYxRCmt2D6ph89W)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='SPECIFIED_FILTER':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<2:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]:
					url = WW6XmdChlOPbY(url)
					hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'SPECIFIED_FILTER___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				BfjcMoqOsmdUvZVCHWIyQKi = WW6XmdChlOPbY(BfjcMoqOsmdUvZVCHWIyQKi)
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filter')
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,425,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='ALL_ITEMS_FILTER':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع :'+name,BfjcMoqOsmdUvZVCHWIyQKi,424,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if K6KbZDHncNizQgl1fr59XV0=='196533': X9dRM31pz6y = 'أفلام نيتفلكس'
			elif K6KbZDHncNizQgl1fr59XV0=='196531': X9dRM31pz6y = 'مسلسلات نيتفلكس'
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' :'#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' :'+name
			if type=='ALL_ITEMS_FILTER': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,424,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='SPECIFIED_FILTER' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'modified_filters')
				Afey3cL4ojzg = url+'/smartemadfilter?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				Afey3cL4ojzg = WW6XmdChlOPbY(Afey3cL4ojzg)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,421,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filter')
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,425,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.replace('=&','=0&')
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('=0','=')
	return LaGtUDiK2xnfz
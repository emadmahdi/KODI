# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = NOrchaEV1iIZ87Uzlwgum(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢡ")
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,TixSXhpW69Uba4f1NPqzYE7JcZ):
	if   pPrvqm3tjuXLTgw1==gniNItGL6bKwpEW(u"࠹࠳࠱श"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = jjPeXFuh47TZGdNqzJo2BlSRHn()
	elif pPrvqm3tjuXLTgw1==hCm2fnEXs6Zt(u"࠳࠴࠳ष"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(TixSXhpW69Uba4f1NPqzYE7JcZ)
	elif pPrvqm3tjuXLTgw1==Tzx81Wb0RZC4ID5AyiU2(u"࠴࠵࠵स"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = eqsYMPkjnpTXf9yKru8IlacGH75UbR()
	elif pPrvqm3tjuXLTgw1==hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠵࠶࠷ह"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = gKZC1l0onSBe5hHa3Epb()
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = f4vncKMRlXG9s
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def uuvhoSanB2TWD(TixSXhpW69Uba4f1NPqzYE7JcZ):
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(TixSXhpW69Uba4f1NPqzYE7JcZ,yNIDEX5hU4G769,HHvYL68lbJVZWM7tQEzSex3(u"ࠬࡼࡩࡥࡧࡲࠫࢢ"))
	return
def gKZC1l0onSBe5hHa3Epb():
	JzNoqV8ClRD6O = lrtFSogC8Nh9(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢣ")
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,LtGoXlQ2IYxqTJRySE6udfW98(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢤ"),JzNoqV8ClRD6O)
	return
def jjPeXFuh47TZGdNqzJo2BlSRHn():
	ZI51XvE8YatWCmNdrp(gniNItGL6bKwpEW(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),Whef0cxB2iR93SC5IwUtk+lrtFSogC8Nh9(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢦ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,fOc18oTm5hsdD4pVZQj(u"࠶࠷࠸ऺ"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠪࡰ࡮ࡴ࡫ࠨࢧ"),Whef0cxB2iR93SC5IwUtk+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢨ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"࠷࠸࠸ऻ"))
	ZI51XvE8YatWCmNdrp(NOrchaEV1iIZ87Uzlwgum(u"ࠬࡲࡩ࡯࡭ࠪࢩ"),Whef0cxB2iR93SC5IwUtk+wP4kpvXoDHq3hs7TFLyr2COn8(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢪ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,Hlp3z0APt1GR4kMYK5xST(u"࠾࠿࠹࠺़"))
	XXWNTKGmpa3FHQx79wrz6E8 = MiazsOdrF4w0UIK6l()
	i6Ic8Q1MaoTZBeqAkzE = IIPNcsCvQnOZk0yejJKl4BtgSrMw.stat(XXWNTKGmpa3FHQx79wrz6E8).st_mtime
	tm1yhwbq8vSjXE6dnYk0P = []
	if J92gCnbGWidQV70lBteTwU6D8uyzL: lubJQERph7w30AfeCygnjaKX9 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(XXWNTKGmpa3FHQx79wrz6E8.encode(YRvPKe2zMTDs8UCkr))
	else: lubJQERph7w30AfeCygnjaKX9 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(XXWNTKGmpa3FHQx79wrz6E8.decode(YRvPKe2zMTDs8UCkr))
	for Ibt19xdJGMVu34OyQRZAWTF in lubJQERph7w30AfeCygnjaKX9:
		if J92gCnbGWidQV70lBteTwU6D8uyzL: Ibt19xdJGMVu34OyQRZAWTF = Ibt19xdJGMVu34OyQRZAWTF.decode(YRvPKe2zMTDs8UCkr)
		if not Ibt19xdJGMVu34OyQRZAWTF.startswith(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢫ")): continue
		ayjYmDPuGbw91rxLgS6UKX37O = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(XXWNTKGmpa3FHQx79wrz6E8,Ibt19xdJGMVu34OyQRZAWTF)
		i6Ic8Q1MaoTZBeqAkzE = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.getmtime(ayjYmDPuGbw91rxLgS6UKX37O)
		tm1yhwbq8vSjXE6dnYk0P.append([Ibt19xdJGMVu34OyQRZAWTF,i6Ic8Q1MaoTZBeqAkzE])
	tm1yhwbq8vSjXE6dnYk0P = sorted(tm1yhwbq8vSjXE6dnYk0P,reverse=k6apiPAlLKM1ed8J42RjHh0o,key=lambda key: key[llxMLe4gobHhsj1WGvd7qmIU])
	for Ibt19xdJGMVu34OyQRZAWTF,i6Ic8Q1MaoTZBeqAkzE in tm1yhwbq8vSjXE6dnYk0P:
		if QBp28giCnayJzmZH6vYO:
			try: Ibt19xdJGMVu34OyQRZAWTF = Ibt19xdJGMVu34OyQRZAWTF.decode(YRvPKe2zMTDs8UCkr)
			except: pass
			Ibt19xdJGMVu34OyQRZAWTF = Ibt19xdJGMVu34OyQRZAWTF.encode(YRvPKe2zMTDs8UCkr)
		ayjYmDPuGbw91rxLgS6UKX37O = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(XXWNTKGmpa3FHQx79wrz6E8,Ibt19xdJGMVu34OyQRZAWTF)
		ZI51XvE8YatWCmNdrp(JGwsL21ZRlqSrWxEmF(u"ࠨࡸ࡬ࡨࡪࡵࠧࢬ"),Ibt19xdJGMVu34OyQRZAWTF,ayjYmDPuGbw91rxLgS6UKX37O,LtGoXlQ2IYxqTJRySE6udfW98(u"࠹࠳࠲ऽ"))
	return
def MiazsOdrF4w0UIK6l():
	XXWNTKGmpa3FHQx79wrz6E8 = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢭ"))
	if XXWNTKGmpa3FHQx79wrz6E8: return XXWNTKGmpa3FHQx79wrz6E8
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lRP6GTaZJA1Xw3egLM4(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢮ"),vJQYPbL42F013CRoqtEUI)
	return vJQYPbL42F013CRoqtEUI
def eqsYMPkjnpTXf9yKru8IlacGH75UbR():
	XXWNTKGmpa3FHQx79wrz6E8 = MiazsOdrF4w0UIK6l()
	HCg4lIBNqQK3XdbDipAfLPG1MT = ggJvHnLYzmlj3Z(eGW7cI6aQhr0(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢯ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,xY4icgQUj6mPVs73CTKu(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢰ"),D7INg5kyRjwf4ZtoePVUrb1h2SJ+XXWNTKGmpa3FHQx79wrz6E8+kjd9LyNqQHMUevZiRI7OlBGF1h+R3lezw8h407ZvrAFxT(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢱ"))
	if HCg4lIBNqQK3XdbDipAfLPG1MT==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠱ा"):
		wr1a38EKcHOyR = xgIRMkJHuDWX4YNh7a(hCm2fnEXs6Zt(u"࠴ि"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢲ"),JGwsL21ZRlqSrWxEmF(u"ࠨ࡮ࡲࡧࡦࡲࠧࢳ"),NdKhAS6MXVEORLTwob92pxlZ,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o,XXWNTKGmpa3FHQx79wrz6E8)
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢴ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢵ"),D7INg5kyRjwf4ZtoePVUrb1h2SJ+XXWNTKGmpa3FHQx79wrz6E8+kjd9LyNqQHMUevZiRI7OlBGF1h+NeU6uRGpECkvMV5jf(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢶ"))
		if TT32BcvomhVewpgMSWkEb46y7xqO==LtGoXlQ2IYxqTJRySE6udfW98(u"࠳ी"):
			ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(NOrchaEV1iIZ87Uzlwgum(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢷ"),wr1a38EKcHOyR)
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,lRP6GTaZJA1Xw3egLM4(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢸ"),QQHFtjcaR2VpnSyTIv(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࢹ"))
	return
def o1OSHpxKtczW05Ig(TixSXhpW69Uba4f1NPqzYE7JcZ,F8ipzId7PMgj=NdKhAS6MXVEORLTwob92pxlZ,website=NdKhAS6MXVEORLTwob92pxlZ):
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࢺ")+TixSXhpW69Uba4f1NPqzYE7JcZ+xY4icgQUj6mPVs73CTKu(u"ࠩࠣࡡࠬࢻ"))
	if not F8ipzId7PMgj: F8ipzId7PMgj = atpJZKYNTGb8Wg0c4rBLPCUSzoxO2I(TixSXhpW69Uba4f1NPqzYE7JcZ)
	XXWNTKGmpa3FHQx79wrz6E8 = MiazsOdrF4w0UIK6l()
	cfGPeIbDgox07mQ = LeIEtX7A6J(f4vncKMRlXG9s)
	Ibt19xdJGMVu34OyQRZAWTF = cfGPeIbDgox07mQ.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡣࠬࢼ"))
	Ibt19xdJGMVu34OyQRZAWTF = UryVN9KOA5tuqi(Ibt19xdJGMVu34OyQRZAWTF)
	Ibt19xdJGMVu34OyQRZAWTF = PzIpQnUXxRwNCivDhdakWTE(u"ࠫ࡫࡯࡬ࡦࡡࠪࢽ")+str(int(MMQhDpyCenmO350aBAKVYk))[-rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠷ु"):]+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠬࡥࠧࢾ")+Ibt19xdJGMVu34OyQRZAWTF+F8ipzId7PMgj
	zUPS5mB1OwkhT = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(XXWNTKGmpa3FHQx79wrz6E8,Ibt19xdJGMVu34OyQRZAWTF)
	RpYN2DWoKIbUHuL = {}
	RpYN2DWoKIbUHuL[ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࢿ")] = NdKhAS6MXVEORLTwob92pxlZ
	RpYN2DWoKIbUHuL[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣀ")] = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠬ࠲࠮ࠬࣁ")
	TixSXhpW69Uba4f1NPqzYE7JcZ = TixSXhpW69Uba4f1NPqzYE7JcZ.replace(Tzx81Wb0RZC4ID5AyiU2(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣂ"),NdKhAS6MXVEORLTwob92pxlZ)
	if hCm2fnEXs6Zt(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨࣃ") in TixSXhpW69Uba4f1NPqzYE7JcZ:
		BfjcMoqOsmdUvZVCHWIyQKi,VVBkbI2DtyaWw6mQp0 = TixSXhpW69Uba4f1NPqzYE7JcZ.rsplit(eGW7cI6aQhr0(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࣄ"),Hlp3z0APt1GR4kMYK5xST(u"࠵ू"))
		VVBkbI2DtyaWw6mQp0 = VVBkbI2DtyaWw6mQp0.replace(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࢂࠧࣅ"),NdKhAS6MXVEORLTwob92pxlZ).replace(PzIpQnUXxRwNCivDhdakWTE(u"࠭ࠦࠨࣆ"),NdKhAS6MXVEORLTwob92pxlZ)
	else: BfjcMoqOsmdUvZVCHWIyQKi,VVBkbI2DtyaWw6mQp0 = TixSXhpW69Uba4f1NPqzYE7JcZ,None
	if not VVBkbI2DtyaWw6mQp0: VVBkbI2DtyaWw6mQp0 = kkCjlxiynwT34GVFc()
	if VVBkbI2DtyaWw6mQp0: RpYN2DWoKIbUHuL[NeU6uRGpECkvMV5jf(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ")] = VVBkbI2DtyaWw6mQp0
	if hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣈ") in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi,rDOMITncUW9pB8ktAQS2 = BfjcMoqOsmdUvZVCHWIyQKi.rsplit(Hlp3z0APt1GR4kMYK5xST(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫࣉ"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠶ृ"))
	else: BfjcMoqOsmdUvZVCHWIyQKi,rDOMITncUW9pB8ktAQS2 = BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.strip(NOrchaEV1iIZ87Uzlwgum(u"ࠪࢀࠬ࣊")).strip(kb2icmDGVUZfW1OFz7sv(u"ࠫࠫ࠭࣋")).strip(eGW7cI6aQhr0(u"ࠬࢂࠧ࣌")).strip(JGwsL21ZRlqSrWxEmF(u"࠭ࠦࠨ࣍"))
	rDOMITncUW9pB8ktAQS2 = rDOMITncUW9pB8ktAQS2.replace(HVmIrFwau90jQsgiWzExk(u"ࠧࡽࠩ࣎"),NdKhAS6MXVEORLTwob92pxlZ).replace(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨࠨ࣏ࠪ"),NdKhAS6MXVEORLTwob92pxlZ)
	if rDOMITncUW9pB8ktAQS2:	RpYN2DWoKIbUHuL[LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ࣐ࠪ")] = rDOMITncUW9pB8ktAQS2
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+HHvYL68lbJVZWM7tQEzSex3(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝࣑ࠣࠫ")+BfjcMoqOsmdUvZVCHWIyQKi+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠ࣒ࠦࠧ")+str(RpYN2DWoKIbUHuL)+R3lezw8h407ZvrAFxT(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤ࣓ࠬ")+zUPS5mB1OwkhT+rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ࠠ࡞ࠩࣔ"))
	Dov3MKEat5RHycwPWZdhqGsb = IlL8ZnX74Yvep(u"࠷࠰࠳࠶ॄ")*IlL8ZnX74Yvep(u"࠷࠰࠳࠶ॄ")
	Fhmroi3W87V10Y = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠰ॅ")
	try:
		GtDFkIciAf2UT3vop8OWu =	ACOWB6GRmIbDKyl3Zn.getInfoLabel(gniNItGL6bKwpEW(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣕ"))
		GtDFkIciAf2UT3vop8OWu = YYqECUofyi7wFrW.findall(V0VZk9763fusTReHFo4(u"ࠨ࡞ࡧ࠯ࠬࣖ"),GtDFkIciAf2UT3vop8OWu)
		Fhmroi3W87V10Y = int(GtDFkIciAf2UT3vop8OWu[e8XhbyuzvjYkIsJUtB5w])
	except: pass
	if not Fhmroi3W87V10Y:
		try:
			Iub93zp1LNTVaj = IIPNcsCvQnOZk0yejJKl4BtgSrMw.statvfs(XXWNTKGmpa3FHQx79wrz6E8)
			Fhmroi3W87V10Y = Iub93zp1LNTVaj.f_frsize*Iub93zp1LNTVaj.f_bavail//Dov3MKEat5RHycwPWZdhqGsb
		except: pass
	if not Fhmroi3W87V10Y:
		try:
			Iub93zp1LNTVaj = IIPNcsCvQnOZk0yejJKl4BtgSrMw.fstatvfs(XXWNTKGmpa3FHQx79wrz6E8)
			Fhmroi3W87V10Y = Iub93zp1LNTVaj.f_frsize*Iub93zp1LNTVaj.f_bavail//Dov3MKEat5RHycwPWZdhqGsb
		except: pass
	if not Fhmroi3W87V10Y:
		try:
			import shutil as R2zPdn6WUkwe9l5fu
			bhuizJTtvLwyZqQGod5rm24IVn9aXY,bcJj2ILDGREmQCp5AO6g1Kuqsrhfz,awDL79iXoQN6nyY = R2zPdn6WUkwe9l5fu.disk_usage(XXWNTKGmpa3FHQx79wrz6E8)
			Fhmroi3W87V10Y = awDL79iXoQN6nyY//Dov3MKEat5RHycwPWZdhqGsb
		except: pass
	if not Fhmroi3W87V10Y:
		cGY04x76XBKoQWJg9R5d2pkIvOsTFD(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠩࡵ࡭࡬࡮ࡴࠨࣗ"),hCm2fnEXs6Zt(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣘ"),lRP6GTaZJA1Xw3egLM4(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨࣙ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࣚ"))
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+fOc18oTm5hsdD4pVZQj(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧࣛ"))
		return f4vncKMRlXG9s
	if F8ipzId7PMgj==Hlp3z0APt1GR4kMYK5xST(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣜ"):
		IGEpKNCaiLMT,UTwH7zjZOrmFl = Ijx8kSvADOboa4E52zrfu9UteF(yNIDEX5hU4G769,BfjcMoqOsmdUvZVCHWIyQKi,RpYN2DWoKIbUHuL)
		if len(IGEpKNCaiLMT)==ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠱ॆ"):
			kkDz5sdaPteM(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣝ"),NdKhAS6MXVEORLTwob92pxlZ)
			return f4vncKMRlXG9s
		elif len(IGEpKNCaiLMT)==OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠳े"): rRfpvbZojlygET5JL87wdzIPGe = kb2icmDGVUZfW1OFz7sv(u"࠳ै")
		elif len(IGEpKNCaiLMT)>WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠵ॉ"):
			rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4(rNyT0edugn(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣞ"), IGEpKNCaiLMT)
			if rRfpvbZojlygET5JL87wdzIPGe == -rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠶ॊ") :
				kkDz5sdaPteM(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ࣟ"),NdKhAS6MXVEORLTwob92pxlZ)
				return f4vncKMRlXG9s
		BfjcMoqOsmdUvZVCHWIyQKi = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	DnGAKCUBg6bT7yw25NFik = WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠶ो")
	import requests as HnCNqGOWBc0tZViv
	if F8ipzId7PMgj==hCm2fnEXs6Zt(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ࣠"):
		zUPS5mB1OwkhT = zUPS5mB1OwkhT.rsplit(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ࣡"))[e8XhbyuzvjYkIsJUtB5w]+YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭࠮࡮ࡲ࠷ࠫ࣢")
		KgjQPrdmkW0pZfiwx9e6qL = cJaAB4uQyp(NXpO8DrVmeE,lrtFSogC8Nh9(u"ࠧࡈࡇࡗࣣࠫ"),BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,RpYN2DWoKIbUHuL,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨࣤ"))
		ffDvjT0ASUWNoBrcY = KgjQPrdmkW0pZfiwx9e6qL.content
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪࣥ"),ffDvjT0ASUWNoBrcY+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡠࡳࡢࡲࠨࣦ"),YYqECUofyi7wFrW.DOTALL)
		if not oDhlaxn0EqyYikcHrmZBN8uv:
			LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+Tzx81Wb0RZC4ID5AyiU2(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧࣧ")+BfjcMoqOsmdUvZVCHWIyQKi+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬࠦ࡝ࠨࣨ"))
			return f4vncKMRlXG9s
		zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[e8XhbyuzvjYkIsJUtB5w]
		if not zehVcU893FC6LEd1Aij.startswith(lNTJCZeBicWEz0Mg(u"࠭ࡨࡵࡶࡳࣩࠫ")):
			if zehVcU893FC6LEd1Aij.startswith(V0VZk9763fusTReHFo4(u"ࠧ࠰࠱ࠪ࣪")): zehVcU893FC6LEd1Aij = BfjcMoqOsmdUvZVCHWIyQKi.split(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨ࠼ࠪ࣫"),LtGoXlQ2IYxqTJRySE6udfW98(u"࠱ौ"))[e8XhbyuzvjYkIsJUtB5w]+fOc18oTm5hsdD4pVZQj(u"ࠩ࠽ࠫ࣬")+zehVcU893FC6LEd1Aij
			elif zehVcU893FC6LEd1Aij.startswith(JGwsL21ZRlqSrWxEmF(u"ࠪ࠳࣭ࠬ")): zehVcU893FC6LEd1Aij = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡺࡸ࡬ࠨ࣮"))+zehVcU893FC6LEd1Aij
			else: zehVcU893FC6LEd1Aij = BfjcMoqOsmdUvZVCHWIyQKi.rsplit(hCm2fnEXs6Zt(u"ࠬ࠵࣯ࠧ"),fOc18oTm5hsdD4pVZQj(u"࠲्"))[e8XhbyuzvjYkIsJUtB5w]+xY4icgQUj6mPVs73CTKu(u"࠭࠯ࠨࣰ")+zehVcU893FC6LEd1Aij
		KgjQPrdmkW0pZfiwx9e6qL = HnCNqGOWBc0tZViv.request(ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࡈࡇࡗࣱࠫ"),zehVcU893FC6LEd1Aij,headers=RpYN2DWoKIbUHuL,verify=f4vncKMRlXG9s)
		W8FfIEUhVxTQ2LCHnl5S3rbc794KM = KgjQPrdmkW0pZfiwx9e6qL.content
		uYOpjGIPC9D6iQBdAn = len(W8FfIEUhVxTQ2LCHnl5S3rbc794KM)
		BhWA4gXCoLuOzQJVY0N = len(oDhlaxn0EqyYikcHrmZBN8uv)
		DnGAKCUBg6bT7yw25NFik = uYOpjGIPC9D6iQBdAn*BhWA4gXCoLuOzQJVY0N
	else:
		uYOpjGIPC9D6iQBdAn = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠳ॎ")*Dov3MKEat5RHycwPWZdhqGsb
		KgjQPrdmkW0pZfiwx9e6qL = HnCNqGOWBc0tZViv.request(OOkmZiVcfqlEurM1dHGb(u"ࠨࡉࡈࡘࣲࠬ"),BfjcMoqOsmdUvZVCHWIyQKi,headers=RpYN2DWoKIbUHuL,verify=f4vncKMRlXG9s,stream=k6apiPAlLKM1ed8J42RjHh0o)
		if lRP6GTaZJA1Xw3egLM4(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪࣳ") in KgjQPrdmkW0pZfiwx9e6qL.headers: DnGAKCUBg6bT7yw25NFik = int(KgjQPrdmkW0pZfiwx9e6qL.headers[wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣴ")])
		BhWA4gXCoLuOzQJVY0N = int(DnGAKCUBg6bT7yw25NFik//uYOpjGIPC9D6iQBdAn)
	C3i1KT47NwSVzcZqvlPbfW = int(DnGAKCUBg6bT7yw25NFik//Dov3MKEat5RHycwPWZdhqGsb)+LtGoXlQ2IYxqTJRySE6udfW98(u"࠴ॏ")
	if DnGAKCUBg6bT7yw25NFik<rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠶࠶࠶࠰࠱ॐ"):
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+NOrchaEV1iIZ87Uzlwgum(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣵ")+BfjcMoqOsmdUvZVCHWIyQKi+eGW7cI6aQhr0(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࣶࠦࠡࠩ")+str(C3i1KT47NwSVzcZqvlPbfW)+YJpWv4QzC7sx8INVPukeZiOD03K(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣷ")+str(Fhmroi3W87V10Y)+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣸ")+zUPS5mB1OwkhT+rNyT0edugn(u"ࠨࠢࡠࣹࠫ"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࣺࠬ"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬࣻ"))
		return f4vncKMRlXG9s
	tNC7syw5cI6lD4fh12Jm = NeU6uRGpECkvMV5jf(u"࠹࠶࠰॑")
	meialMA3YThxoj1V2t0bpnOQk = Fhmroi3W87V10Y-C3i1KT47NwSVzcZqvlPbfW
	if meialMA3YThxoj1V2t0bpnOQk<tNC7syw5cI6lD4fh12Jm:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(sSHvJFeTkhoE8KnuNWwljAg3mX16,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+HHvYL68lbJVZWM7tQEzSex3(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪࣼ")+BfjcMoqOsmdUvZVCHWIyQKi+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(C3i1KT47NwSVzcZqvlPbfW)+V0VZk9763fusTReHFo4(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(Fhmroi3W87V10Y)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧࣿ")+str(tNC7syw5cI6lD4fh12Jm)+OOkmZiVcfqlEurM1dHGb(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऀ")+zUPS5mB1OwkhT+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩࠣࡡࠬँ"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,eGW7cI6aQhr0(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪं"),HHvYL68lbJVZWM7tQEzSex3(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪः")+str(C3i1KT47NwSVzcZqvlPbfW)+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऄ")+str(Fhmroi3W87V10Y)+fOc18oTm5hsdD4pVZQj(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭अ")+str(tNC7syw5cI6lD4fh12Jm)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩआ"))
		return f4vncKMRlXG9s
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NeU6uRGpECkvMV5jf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨइ"),NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪई"),vju3SZDWL4ENYelmBOzUqrogp2(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩउ")+str(C3i1KT47NwSVzcZqvlPbfW)+LtGoXlQ2IYxqTJRySE6udfW98(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऊ")+str(Fhmroi3W87V10Y)+kb2icmDGVUZfW1OFz7sv(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऋ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO!=NOrchaEV1iIZ87Uzlwgum(u"࠷॒"):
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,R3lezw8h407ZvrAFxT(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫऌ"))
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+OOkmZiVcfqlEurM1dHGb(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऍ")+BfjcMoqOsmdUvZVCHWIyQKi+lNTJCZeBicWEz0Mg(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऎ")+zUPS5mB1OwkhT+OOkmZiVcfqlEurM1dHGb(u"ࠩࠣࡡࠬए"))
		return f4vncKMRlXG9s
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+lNTJCZeBicWEz0Mg(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨऐ"))
	muL0lDzdjc7EA4pNJgYfbGq = UpNqSvlOPeuKntGWCT1rR3aI4b()
	muL0lDzdjc7EA4pNJgYfbGq.create(zUPS5mB1OwkhT,NOrchaEV1iIZ87Uzlwgum(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬऑ"))
	NNtLwEV1qi = k6apiPAlLKM1ed8J42RjHh0o
	nDW6hxsUyd5NtALZ = XJ62UBRmIqFvfiNTQj.time()
	if not OMNiY8joQx.WiJPMTZvOLGsV0xB8al:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),HHvYL68lbJVZWM7tQEzSex3(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧओ"))
		return f4vncKMRlXG9s
	if J92gCnbGWidQV70lBteTwU6D8uyzL: wJx2dhIA7skyvr = open(zUPS5mB1OwkhT,lrtFSogC8Nh9(u"ࠧࡸࡤࠪऔ"))
	else: wJx2dhIA7skyvr = open(zUPS5mB1OwkhT.decode(YRvPKe2zMTDs8UCkr),HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡹࡥࠫक"))
	if F8ipzId7PMgj==wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨख"):
		for XW2Opt4RQsVihunCylz6j in range(HVmIrFwau90jQsgiWzExk(u"࠱॓"),BhWA4gXCoLuOzQJVY0N+HVmIrFwau90jQsgiWzExk(u"࠱॓")):
			zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[XW2Opt4RQsVihunCylz6j-rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠲॔")]
			if not zehVcU893FC6LEd1Aij.startswith(hCm2fnEXs6Zt(u"ࠪ࡬ࡹࡺࡰࠨग")):
				if zehVcU893FC6LEd1Aij.startswith(lrtFSogC8Nh9(u"ࠫ࠴࠵ࠧघ")): zehVcU893FC6LEd1Aij = BfjcMoqOsmdUvZVCHWIyQKi.split(LtGoXlQ2IYxqTJRySE6udfW98(u"ࠬࡀࠧङ"),HHvYL68lbJVZWM7tQEzSex3(u"࠳ॕ"))[e8XhbyuzvjYkIsJUtB5w]+QQHFtjcaR2VpnSyTIv(u"࠭࠺ࠨच")+zehVcU893FC6LEd1Aij
				elif zehVcU893FC6LEd1Aij.startswith(YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧ࠰ࠩछ")): zehVcU893FC6LEd1Aij = msbTrJW03xuvA(BfjcMoqOsmdUvZVCHWIyQKi,wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠨࡷࡵࡰࠬज"))+zehVcU893FC6LEd1Aij
				else: zehVcU893FC6LEd1Aij = BfjcMoqOsmdUvZVCHWIyQKi.rsplit(PzIpQnUXxRwNCivDhdakWTE(u"ࠩ࠲ࠫझ"),rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠴ॖ"))[e8XhbyuzvjYkIsJUtB5w]+NeU6uRGpECkvMV5jf(u"ࠪ࠳ࠬञ")+zehVcU893FC6LEd1Aij
			KgjQPrdmkW0pZfiwx9e6qL = HnCNqGOWBc0tZViv.request(Tzx81Wb0RZC4ID5AyiU2(u"ࠫࡌࡋࡔࠨट"),zehVcU893FC6LEd1Aij,headers=RpYN2DWoKIbUHuL,verify=f4vncKMRlXG9s)
			W8FfIEUhVxTQ2LCHnl5S3rbc794KM = KgjQPrdmkW0pZfiwx9e6qL.content
			KgjQPrdmkW0pZfiwx9e6qL.close()
			wJx2dhIA7skyvr.write(W8FfIEUhVxTQ2LCHnl5S3rbc794KM)
			eDShqfYAwjcW1t6siza = XJ62UBRmIqFvfiNTQj.time()
			llkqFrRAVpbeNic8 = eDShqfYAwjcW1t6siza-nDW6hxsUyd5NtALZ
			ffegTAdoWrZjulnS6ix2a8tBOkD = llkqFrRAVpbeNic8//XW2Opt4RQsVihunCylz6j
			My9u5NnAd6wTDH3X = ffegTAdoWrZjulnS6ix2a8tBOkD*(BhWA4gXCoLuOzQJVY0N+vju3SZDWL4ENYelmBOzUqrogp2(u"࠵ॗ"))
			svOy0h9lC4LwkRocmSeadbtBxU21gT = My9u5NnAd6wTDH3X-llkqFrRAVpbeNic8
			BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,int(NOrchaEV1iIZ87Uzlwgum(u"࠷࠰࠱ख़")*XW2Opt4RQsVihunCylz6j//(BhWA4gXCoLuOzQJVY0N+NeU6uRGpECkvMV5jf(u"࠶क़"))),rNyT0edugn(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ठ"),xY4icgQUj6mPVs73CTKu(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ड"),str(XW2Opt4RQsVihunCylz6j*uYOpjGIPC9D6iQBdAn//Dov3MKEat5RHycwPWZdhqGsb)+R3lezw8h407ZvrAFxT(u"ࠧ࠰ࠩढ")+str(C3i1KT47NwSVzcZqvlPbfW)+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ण")+XJ62UBRmIqFvfiNTQj.strftime(PzIpQnUXxRwNCivDhdakWTE(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦत"),XJ62UBRmIqFvfiNTQj.gmtime(svOy0h9lC4LwkRocmSeadbtBxU21gT))+NOrchaEV1iIZ87Uzlwgum(u"ࠪࠤๅ࠭थ"))
			if muL0lDzdjc7EA4pNJgYfbGq.iscanceled():
				NNtLwEV1qi = f4vncKMRlXG9s
				break
	else:
		XW2Opt4RQsVihunCylz6j = eGW7cI6aQhr0(u"࠰ग़")
		for W8FfIEUhVxTQ2LCHnl5S3rbc794KM in KgjQPrdmkW0pZfiwx9e6qL.iter_content(chunk_size=uYOpjGIPC9D6iQBdAn):
			wJx2dhIA7skyvr.write(W8FfIEUhVxTQ2LCHnl5S3rbc794KM)
			XW2Opt4RQsVihunCylz6j = XW2Opt4RQsVihunCylz6j+lrtFSogC8Nh9(u"࠲ज़")
			eDShqfYAwjcW1t6siza = XJ62UBRmIqFvfiNTQj.time()
			llkqFrRAVpbeNic8 = eDShqfYAwjcW1t6siza-nDW6hxsUyd5NtALZ
			ffegTAdoWrZjulnS6ix2a8tBOkD = llkqFrRAVpbeNic8/XW2Opt4RQsVihunCylz6j
			My9u5NnAd6wTDH3X = ffegTAdoWrZjulnS6ix2a8tBOkD*(BhWA4gXCoLuOzQJVY0N+pnHgvFOCBZzc08yULQJGIqw9bf(u"࠳ड़"))
			svOy0h9lC4LwkRocmSeadbtBxU21gT = My9u5NnAd6wTDH3X-llkqFrRAVpbeNic8
			BBKvjLwgdSInHPYkFOzhJpeEcN(muL0lDzdjc7EA4pNJgYfbGq,int(hCm2fnEXs6Zt(u"࠵࠵࠶फ़")*XW2Opt4RQsVihunCylz6j/(BhWA4gXCoLuOzQJVY0N+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠴ढ़"))),NOrchaEV1iIZ87Uzlwgum(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬद"),NeU6uRGpECkvMV5jf(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬध"),str(XW2Opt4RQsVihunCylz6j*uYOpjGIPC9D6iQBdAn//Dov3MKEat5RHycwPWZdhqGsb)+HHvYL68lbJVZWM7tQEzSex3(u"࠭࠯ࠨन")+str(C3i1KT47NwSVzcZqvlPbfW)+R3lezw8h407ZvrAFxT(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬऩ")+XJ62UBRmIqFvfiNTQj.strftime(HVmIrFwau90jQsgiWzExk(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥप"),XJ62UBRmIqFvfiNTQj.gmtime(svOy0h9lC4LwkRocmSeadbtBxU21gT))+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࠣไࠬफ"))
			if muL0lDzdjc7EA4pNJgYfbGq.iscanceled():
				NNtLwEV1qi = f4vncKMRlXG9s
				break
		KgjQPrdmkW0pZfiwx9e6qL.close()
	wJx2dhIA7skyvr.close()
	muL0lDzdjc7EA4pNJgYfbGq.close()
	if not NNtLwEV1qi:
		LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧब")+BfjcMoqOsmdUvZVCHWIyQKi+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫभ")+zUPS5mB1OwkhT+fOc18oTm5hsdD4pVZQj(u"ࠬࠦ࡝ࠨम"))
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩय"),gniNItGL6bKwpEW(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"))
		return k6apiPAlLKM1ed8J42RjHh0o
	LlDhFpn5VqN6KJdy4HboeZ7YjcMC(Ng4e6LpJBxa5rlI,BoOvMhqAWp9Utgmi4bKPeCfkGDj(yNIDEX5hU4G769)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧऱ")+BfjcMoqOsmdUvZVCHWIyQKi+hCm2fnEXs6Zt(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+zUPS5mB1OwkhT+JGwsL21ZRlqSrWxEmF(u"ࠪࠤࡢ࠭ळ"))
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,V0VZk9763fusTReHFo4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),IlL8ZnX74Yvep(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫव"))
	return k6apiPAlLKM1ed8J42RjHh0o
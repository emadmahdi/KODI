# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
qaD1Jv7VWbMoI04Bx8UkrC9XQOh = 'FAVORITES'
def mxnEVjz6b3v(pPrvqm3tjuXLTgw1,M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	if   pPrvqm3tjuXLTgw1==270: CCXjewWZpg = ILukXJh2lbAiTvHMm(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
	else: CCXjewWZpg = False
	return CCXjewWZpg
def uvTkyDmO9M48VN2xfXFgUeZ(ueFHThK2pDYc,M04mGtIJy2DxazuYWgdVjAZiKwRnrB,VQnUAutkMNTJWp5):
	if not ueFHThK2pDYc: return
	if   VQnUAutkMNTJWp5=='UP1'	: ZNBcx5jFThe6PEun9wyJq87MkOKVR(M04mGtIJy2DxazuYWgdVjAZiKwRnrB,True,llxMLe4gobHhsj1WGvd7qmIU)
	elif VQnUAutkMNTJWp5=='DOWN1'	: ZNBcx5jFThe6PEun9wyJq87MkOKVR(M04mGtIJy2DxazuYWgdVjAZiKwRnrB,False,llxMLe4gobHhsj1WGvd7qmIU)
	elif VQnUAutkMNTJWp5=='UP4'	: ZNBcx5jFThe6PEun9wyJq87MkOKVR(M04mGtIJy2DxazuYWgdVjAZiKwRnrB,True,TQNS6YMKAqnilsVObLpDRX)
	elif VQnUAutkMNTJWp5=='DOWN4'	: ZNBcx5jFThe6PEun9wyJq87MkOKVR(M04mGtIJy2DxazuYWgdVjAZiKwRnrB,False,TQNS6YMKAqnilsVObLpDRX)
	elif VQnUAutkMNTJWp5=='ADD1'	: f8zqOdQcMG4jDPFsBVyWe35a2x(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
	elif VQnUAutkMNTJWp5=='REMOVE1': kWv854f1Yem6N3QtJnb2A0UoSMpy(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
	elif VQnUAutkMNTJWp5=='DELETELIST': K70AOyBbpjlz(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
	return
def ILukXJh2lbAiTvHMm(M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	fHpXR4r0865bGijhKotqJaQy9EWAO = yWbk3mQft0RzghLlCHBudcsYGr()
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
		try:
			ZuFtE4J8SB2vz53Lb = fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]
			if e8XhbyuzvjYkIsJUtB5w and M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['5','11','12','13']:
				for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd in ZuFtE4J8SB2vz53Lb:
					if oJeO8LqTXi7W=='video':
						ZI51XvE8YatWCmNdrp('video',Whef0cxB2iR93SC5IwUtk+'تشغيل من الأعلى إلى الأسفل'+kjd9LyNqQHMUevZiRI7OlBGF1h,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc)
						ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
						break
			for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd in ZuFtE4J8SB2vz53Lb:
				ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd)
		except:
			fHpXR4r0865bGijhKotqJaQy9EWAO = kNavZsXiUlWP5o4(cXO4eSZFqrbYPotf)
			ZuFtE4J8SB2vz53Lb = fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]
			for oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd in ZuFtE4J8SB2vz53Lb:
				ZI51XvE8YatWCmNdrp(oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd)
	return
def f8zqOdQcMG4jDPFsBVyWe35a2x(M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['5','11','12','13'] and oJeO8LqTXi7W!='video':
		ZaUVqChKHwRLYbeiOv('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	X32lUyoDBqp14T = oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,ww1lsWcSe2Cd
	fHpXR4r0865bGijhKotqJaQy9EWAO = yWbk3mQft0RzghLlCHBudcsYGr()
	P3DvncFVCuqWUI = {}
	for UL9cXybt0dr86m2l5MBknxfEYuhj in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
		if UL9cXybt0dr86m2l5MBknxfEYuhj!=M04mGtIJy2DxazuYWgdVjAZiKwRnrB: P3DvncFVCuqWUI[UL9cXybt0dr86m2l5MBknxfEYuhj] = fHpXR4r0865bGijhKotqJaQy9EWAO[UL9cXybt0dr86m2l5MBknxfEYuhj]
		else:
			if JHKDFe6Am0ruz8 and JHKDFe6Am0ruz8!='..':
				E5EQWhANjYBdyOXaMn = fHpXR4r0865bGijhKotqJaQy9EWAO[UL9cXybt0dr86m2l5MBknxfEYuhj]
				if X32lUyoDBqp14T in E5EQWhANjYBdyOXaMn:
					wq7HiQYfGAEk6a2FmNCULWMPIT = E5EQWhANjYBdyOXaMn.index(X32lUyoDBqp14T)
					del E5EQWhANjYBdyOXaMn[wq7HiQYfGAEk6a2FmNCULWMPIT]
				LzF8toxPQlN = E5EQWhANjYBdyOXaMn+[X32lUyoDBqp14T]
				P3DvncFVCuqWUI[UL9cXybt0dr86m2l5MBknxfEYuhj] = LzF8toxPQlN
			else: P3DvncFVCuqWUI[UL9cXybt0dr86m2l5MBknxfEYuhj] = fHpXR4r0865bGijhKotqJaQy9EWAO[UL9cXybt0dr86m2l5MBknxfEYuhj]
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB not in list(P3DvncFVCuqWUI.keys()): P3DvncFVCuqWUI[M04mGtIJy2DxazuYWgdVjAZiKwRnrB] = [X32lUyoDBqp14T]
	f2iEW5O4tHR = str(P3DvncFVCuqWUI)
	if J92gCnbGWidQV70lBteTwU6D8uyzL: f2iEW5O4tHR = f2iEW5O4tHR.encode(YRvPKe2zMTDs8UCkr)
	open(cXO4eSZFqrbYPotf,'wb').write(f2iEW5O4tHR)
	return
def kWv854f1Yem6N3QtJnb2A0UoSMpy(M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	X32lUyoDBqp14T = oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,ww1lsWcSe2Cd
	fHpXR4r0865bGijhKotqJaQy9EWAO = yWbk3mQft0RzghLlCHBudcsYGr()
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()) and X32lUyoDBqp14T in fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]:
		fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB].remove(X32lUyoDBqp14T)
		if len(fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB])==e8XhbyuzvjYkIsJUtB5w: del fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]
		f2iEW5O4tHR = str(fHpXR4r0865bGijhKotqJaQy9EWAO)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: f2iEW5O4tHR = f2iEW5O4tHR.encode(YRvPKe2zMTDs8UCkr)
		open(cXO4eSZFqrbYPotf,'wb').write(f2iEW5O4tHR)
	return
def ZNBcx5jFThe6PEun9wyJq87MkOKVR(M04mGtIJy2DxazuYWgdVjAZiKwRnrB,aARVireUYg0JGhXd2FP8pWBt4wm67,lZ7UhRa9kCXx):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd = W17Zj6mXnvxLdM50cPA(RAHOMksyDUV3w7T1QjqKNX)
	X32lUyoDBqp14T = oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,ww1lsWcSe2Cd
	fHpXR4r0865bGijhKotqJaQy9EWAO = yWbk3mQft0RzghLlCHBudcsYGr()
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
		E5EQWhANjYBdyOXaMn = fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]
		if X32lUyoDBqp14T not in E5EQWhANjYBdyOXaMn: return
		AtxSM2L7PCWNqlf4 = len(E5EQWhANjYBdyOXaMn)
		for zG37PsWCeVZ4aYtmkE2DTowqBF in range(e8XhbyuzvjYkIsJUtB5w,lZ7UhRa9kCXx):
			vlA8xkMPQG0sDiNgRz = E5EQWhANjYBdyOXaMn.index(X32lUyoDBqp14T)
			if aARVireUYg0JGhXd2FP8pWBt4wm67: DDQC0PHKI9JB7pidgc = vlA8xkMPQG0sDiNgRz-llxMLe4gobHhsj1WGvd7qmIU
			else: DDQC0PHKI9JB7pidgc = vlA8xkMPQG0sDiNgRz+llxMLe4gobHhsj1WGvd7qmIU
			if DDQC0PHKI9JB7pidgc>=AtxSM2L7PCWNqlf4: DDQC0PHKI9JB7pidgc = DDQC0PHKI9JB7pidgc-AtxSM2L7PCWNqlf4
			if DDQC0PHKI9JB7pidgc<e8XhbyuzvjYkIsJUtB5w: DDQC0PHKI9JB7pidgc = DDQC0PHKI9JB7pidgc+AtxSM2L7PCWNqlf4
			E5EQWhANjYBdyOXaMn.insert(DDQC0PHKI9JB7pidgc, E5EQWhANjYBdyOXaMn.pop(vlA8xkMPQG0sDiNgRz))
		fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB] = E5EQWhANjYBdyOXaMn
		f2iEW5O4tHR = str(fHpXR4r0865bGijhKotqJaQy9EWAO)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: f2iEW5O4tHR = f2iEW5O4tHR.encode(YRvPKe2zMTDs8UCkr)
		open(cXO4eSZFqrbYPotf,'wb').write(f2iEW5O4tHR)
	return
def uNRrQwP4IF0at86GECcmU(M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['1','2','3','4']: vvrxQoB6aUb8WSOE5kdG,qUytSOiM9bQ2eznWD784Yd3s1cr = 'مفضلة',M04mGtIJy2DxazuYWgdVjAZiKwRnrB
	elif M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['5']: vvrxQoB6aUb8WSOE5kdG,qUytSOiM9bQ2eznWD784Yd3s1cr = 'تشغيل','1'
	elif M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['11']: vvrxQoB6aUb8WSOE5kdG,qUytSOiM9bQ2eznWD784Yd3s1cr = 'تشغيل','2'
	else: vvrxQoB6aUb8WSOE5kdG,qUytSOiM9bQ2eznWD784Yd3s1cr = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	P2mSCFoJyvZtGgqj5dkuh = vvrxQoB6aUb8WSOE5kdG+Vwgflszp4WRA93kx6hvdua21HX5cOb+qUytSOiM9bQ2eznWD784Yd3s1cr
	return P2mSCFoJyvZtGgqj5dkuh
def K70AOyBbpjlz(M04mGtIJy2DxazuYWgdVjAZiKwRnrB):
	P2mSCFoJyvZtGgqj5dkuh = uNRrQwP4IF0at86GECcmU(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
	jTxAYItnH8rO2KD5aJ43bo9V7kiGS = ggJvHnLYzmlj3Z('center',NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+P2mSCFoJyvZtGgqj5dkuh+' ؟!')
	if jTxAYItnH8rO2KD5aJ43bo9V7kiGS!=1: return
	fHpXR4r0865bGijhKotqJaQy9EWAO = yWbk3mQft0RzghLlCHBudcsYGr()
	if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
		del fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]
		f2iEW5O4tHR = str(fHpXR4r0865bGijhKotqJaQy9EWAO)
		if J92gCnbGWidQV70lBteTwU6D8uyzL: f2iEW5O4tHR = f2iEW5O4tHR.encode(YRvPKe2zMTDs8UCkr)
		open(cXO4eSZFqrbYPotf,'wb').write(f2iEW5O4tHR)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+P2mSCFoJyvZtGgqj5dkuh)
	return
def yWbk3mQft0RzghLlCHBudcsYGr():
	fHpXR4r0865bGijhKotqJaQy9EWAO = {}
	if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(cXO4eSZFqrbYPotf):
		fKw0VX1usOnQ = open(cXO4eSZFqrbYPotf,'rb').read()
		if J92gCnbGWidQV70lBteTwU6D8uyzL: fKw0VX1usOnQ = fKw0VX1usOnQ.decode(YRvPKe2zMTDs8UCkr)
		fHpXR4r0865bGijhKotqJaQy9EWAO = BdnA8WwtJeKUVvE('dict',fKw0VX1usOnQ)
	return fHpXR4r0865bGijhKotqJaQy9EWAO
def DO4B07vQ5KhVk6Jns1fmIzre(fHpXR4r0865bGijhKotqJaQy9EWAO,X32lUyoDBqp14T,UPNgfmhisTOEV):
	oJeO8LqTXi7W,JHKDFe6Am0ruz8,TixSXhpW69Uba4f1NPqzYE7JcZ,pPrvqm3tjuXLTgw1,nnQPgrIaSEN09T5hf4sx,nnkBNQrAK1SmzpfYD0j,ui7N5YGR9KdslpEbQkVTwFqDgI,ueFHThK2pDYc,ww1lsWcSe2Cd = X32lUyoDBqp14T
	if not pPrvqm3tjuXLTgw1: oJeO8LqTXi7W,pPrvqm3tjuXLTgw1 = 'folder','260'
	Of1khvo5qBZdRYLm,M04mGtIJy2DxazuYWgdVjAZiKwRnrB = [],NdKhAS6MXVEORLTwob92pxlZ
	if 'context=' in RAHOMksyDUV3w7T1QjqKNX:
		h032V5HxLnqfKUXbkjBMlZt = YYqECUofyi7wFrW.findall('context=(\d+)',RAHOMksyDUV3w7T1QjqKNX,YYqECUofyi7wFrW.DOTALL)
		if h032V5HxLnqfKUXbkjBMlZt: M04mGtIJy2DxazuYWgdVjAZiKwRnrB = str(h032V5HxLnqfKUXbkjBMlZt[e8XhbyuzvjYkIsJUtB5w])
	if pPrvqm3tjuXLTgw1=='270':
		M04mGtIJy2DxazuYWgdVjAZiKwRnrB = ueFHThK2pDYc
		if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
			P2mSCFoJyvZtGgqj5dkuh = uNRrQwP4IF0at86GECcmU(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
			Of1khvo5qBZdRYLm.append(('مسح قائمة '+P2mSCFoJyvZtGgqj5dkuh,'RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_DELETELIST'+')'))
	else:
		if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()):
			count = len(fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB])
			if count>llxMLe4gobHhsj1WGvd7qmIU: Of1khvo5qBZdRYLm.append(('تحريك 1 للأعلى','RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_UP1)'))
			if count>TQNS6YMKAqnilsVObLpDRX: Of1khvo5qBZdRYLm.append(('تحريك 4 للأعلى','RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_UP4)'))
			if count>llxMLe4gobHhsj1WGvd7qmIU: Of1khvo5qBZdRYLm.append(('تحريك 1 للأسفل','RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_DOWN1)'))
			if count>TQNS6YMKAqnilsVObLpDRX: Of1khvo5qBZdRYLm.append(('تحريك 4 للأسفل','RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_DOWN4)'))
		for M04mGtIJy2DxazuYWgdVjAZiKwRnrB in ['1','2','3','4','5','11']:
			P2mSCFoJyvZtGgqj5dkuh = uNRrQwP4IF0at86GECcmU(M04mGtIJy2DxazuYWgdVjAZiKwRnrB)
			if M04mGtIJy2DxazuYWgdVjAZiKwRnrB in list(fHpXR4r0865bGijhKotqJaQy9EWAO.keys()) and X32lUyoDBqp14T in fHpXR4r0865bGijhKotqJaQy9EWAO[M04mGtIJy2DxazuYWgdVjAZiKwRnrB]:
				Of1khvo5qBZdRYLm.append(('مسح من '+P2mSCFoJyvZtGgqj5dkuh,'RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_REMOVE1)'))
			else: Of1khvo5qBZdRYLm.append(('إضافة ل'+P2mSCFoJyvZtGgqj5dkuh,'RunPlugin('+UPNgfmhisTOEV+'&context='+M04mGtIJy2DxazuYWgdVjAZiKwRnrB+'_ADD1)'))
	o6xcr3QIvEMgOX9weV7d4sWh5YG2n = []
	for L3L2gjl1w69R0FMn4EHBIsqhKacGV,Ny4SOo8cls3ndDpfJ in Of1khvo5qBZdRYLm:
		L3L2gjl1w69R0FMn4EHBIsqhKacGV = D7INg5kyRjwf4ZtoePVUrb1h2SJ+L3L2gjl1w69R0FMn4EHBIsqhKacGV+kjd9LyNqQHMUevZiRI7OlBGF1h
		o6xcr3QIvEMgOX9weV7d4sWh5YG2n.append((L3L2gjl1w69R0FMn4EHBIsqhKacGV,Ny4SOo8cls3ndDpfJ,))
	return o6xcr3QIvEMgOX9weV7d4sWh5YG2n
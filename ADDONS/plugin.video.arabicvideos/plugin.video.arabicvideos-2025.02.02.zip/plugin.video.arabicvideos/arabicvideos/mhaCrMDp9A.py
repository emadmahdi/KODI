# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'EGYBESTVIP'
LJfTAEQPv9h4BXdwUp = '_EGV_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
def QGLoruqnmiAel7Op(mode,url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,text):
	if   mode==220: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==221: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
	elif mode==222: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==223: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==224: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url)
	elif mode==229: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,229,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBEST-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="i i-home"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)"(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,222)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="ba(.*?)<script',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		for title,zehVcU893FC6LEd1Aij in items:
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,221)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if 'html' not in zehVcU893FC6LEd1Aij: continue
			if not zehVcU893FC6LEd1Aij.endswith('/'): ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,221)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="rs_scroll"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,224)
	return
def Xi3ZCagjOpSAvB1rlnE6(url):
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',url,221)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-FILTERS_MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="sub_nav(.*?)id="movies',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".+?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if zehVcU893FC6LEd1Aij=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,221)
	else: hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,jNgDBqeKyZ4zSkGv8ROMA70aIYcC='1'):
	if jNgDBqeKyZ4zSkGv8ROMA70aIYcC==NdKhAS6MXVEORLTwob92pxlZ: jNgDBqeKyZ4zSkGv8ROMA70aIYcC = '1'
	if '/search' in url or '?' in url: BfjcMoqOsmdUvZVCHWIyQKi = url + '&'
	else: BfjcMoqOsmdUvZVCHWIyQKi = url + '?'
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi + 'page=' + jNgDBqeKyZ4zSkGv8ROMA70aIYcC
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('class="pda"(.*?)div',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[-1]
	elif '/series/' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('class="owl-carousel owl-carousel(.*?)div',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6=YYqECUofyi7wFrW.findall('id="movies(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[-1]
	items = YYqECUofyi7wFrW.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		if '/movie/' in zehVcU893FC6LEd1Aij or '/episode' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij.rstrip('/'),223,TTuPH708dUNnjlG3oQpkZsi)
		else:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,221,TTuPH708dUNnjlG3oQpkZsi)
	if len(items)>=16:
		JRcAa1Kxmv09 = ['/movies','/tv','/search','/trending']
		jNgDBqeKyZ4zSkGv8ROMA70aIYcC = int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC)
		if any(K6KbZDHncNizQgl1fr59XV0 in url for K6KbZDHncNizQgl1fr59XV0 in JRcAa1Kxmv09):
			for PP7gfoVqHd2Eba36vLjn in range(0,1000,100):
				if int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC/100)*100==PP7gfoVqHd2Eba36vLjn:
					for xX6zt5oS08TO29CUhYJa1K in range(PP7gfoVqHd2Eba36vLjn,PP7gfoVqHd2Eba36vLjn+100,10):
						if int(jNgDBqeKyZ4zSkGv8ROMA70aIYcC/10)*10==xX6zt5oS08TO29CUhYJa1K:
							for RU2IVQ0PNd9 in range(xX6zt5oS08TO29CUhYJa1K,xX6zt5oS08TO29CUhYJa1K+10,1):
								if not jNgDBqeKyZ4zSkGv8ROMA70aIYcC==RU2IVQ0PNd9 and RU2IVQ0PNd9!=0:
									ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+str(RU2IVQ0PNd9),url,221,NdKhAS6MXVEORLTwob92pxlZ,str(RU2IVQ0PNd9))
						elif xX6zt5oS08TO29CUhYJa1K!=0: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+str(xX6zt5oS08TO29CUhYJa1K),url,221,NdKhAS6MXVEORLTwob92pxlZ,str(xX6zt5oS08TO29CUhYJa1K))
						else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+str(1),url,221,NdKhAS6MXVEORLTwob92pxlZ,str(1))
				elif PP7gfoVqHd2Eba36vLjn!=0: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+str(PP7gfoVqHd2Eba36vLjn),url,221,NdKhAS6MXVEORLTwob92pxlZ,str(PP7gfoVqHd2Eba36vLjn))
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+str(1),url,221)
	return
def uuvhoSanB2TWD(url):
	IGEpKNCaiLMT,UTwH7zjZOrmFl = [],[]
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-PLAY-1st')
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('<td>التصنيف</td>.*?">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	O8OAY149vKJNW2gqi6Gw,prtDOZCL6d2ER = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	zrhi2ovCXTGfQ,IIp6xZkvN1VuXB = LMKFcEkU1Q7R80yt4OsgvwxbfP,LMKFcEkU1Q7R80yt4OsgvwxbfP
	DwRM0TnhdG3mfPi4WcYlra1 = YYqECUofyi7wFrW.findall('show_dl api" href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if DwRM0TnhdG3mfPi4WcYlra1:
		for zehVcU893FC6LEd1Aij in DwRM0TnhdG3mfPi4WcYlra1:
			if '/watch/' in zehVcU893FC6LEd1Aij: O8OAY149vKJNW2gqi6Gw = zehVcU893FC6LEd1Aij
			elif '/download/' in zehVcU893FC6LEd1Aij: prtDOZCL6d2ER = zehVcU893FC6LEd1Aij
		if O8OAY149vKJNW2gqi6Gw!=NdKhAS6MXVEORLTwob92pxlZ: zrhi2ovCXTGfQ = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,O8OAY149vKJNW2gqi6Gw,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-PLAY-2nd')
		if prtDOZCL6d2ER!=NdKhAS6MXVEORLTwob92pxlZ: IIp6xZkvN1VuXB = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,prtDOZCL6d2ER,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-PLAY-3rd')
	Odl7hA0bCnfFytP9WuVLE8Kqp = YYqECUofyi7wFrW.findall('id="video".*?data-src="(.*?)"',zrhi2ovCXTGfQ,YYqECUofyi7wFrW.DOTALL)
	if Odl7hA0bCnfFytP9WuVLE8Kqp:
		BfjcMoqOsmdUvZVCHWIyQKi = Odl7hA0bCnfFytP9WuVLE8Kqp[0]
		if BfjcMoqOsmdUvZVCHWIyQKi!=NdKhAS6MXVEORLTwob92pxlZ and 'uploaded.egybest.download' in BfjcMoqOsmdUvZVCHWIyQKi and '/?id=_' not in BfjcMoqOsmdUvZVCHWIyQKi:
			HeFB5x2wED = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-PLAY-4th')
			C0ncQBqp6NyKELVZ4J53S1f2eklhtA = YYqECUofyi7wFrW.findall('source src="(.*?)" title="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if C0ncQBqp6NyKELVZ4J53S1f2eklhtA:
				for zehVcU893FC6LEd1Aij,a0ao2jdlt4r9nhHwpvSgOVGA in C0ncQBqp6NyKELVZ4J53S1f2eklhtA:
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij+'?named=ed.egybest.do__watch__mp4__'+a0ao2jdlt4r9nhHwpvSgOVGA)
			else:
				oikt6P0hOAD5IvnlMpxf1 = BfjcMoqOsmdUvZVCHWIyQKi.split('/')[2]
				UTwH7zjZOrmFl.append(BfjcMoqOsmdUvZVCHWIyQKi+'?named='+oikt6P0hOAD5IvnlMpxf1+'__watch')
		elif BfjcMoqOsmdUvZVCHWIyQKi!=NdKhAS6MXVEORLTwob92pxlZ:
			oikt6P0hOAD5IvnlMpxf1 = BfjcMoqOsmdUvZVCHWIyQKi.split('/')[2]
			UTwH7zjZOrmFl.append(BfjcMoqOsmdUvZVCHWIyQKi+'?named='+oikt6P0hOAD5IvnlMpxf1+'__watch')
	sSWcyTjP5kHU8Vv = YYqECUofyi7wFrW.findall('<table class="dls_table(.*?)</table>',IIp6xZkvN1VuXB,YYqECUofyi7wFrW.DOTALL)
	if sSWcyTjP5kHU8Vv:
		sSWcyTjP5kHU8Vv = sSWcyTjP5kHU8Vv[0]
		xJOajKZbskdNuMYXTwfG7hL = YYqECUofyi7wFrW.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',sSWcyTjP5kHU8Vv,YYqECUofyi7wFrW.DOTALL)
		if xJOajKZbskdNuMYXTwfG7hL:
			for a0ao2jdlt4r9nhHwpvSgOVGA,zehVcU893FC6LEd1Aij in xJOajKZbskdNuMYXTwfG7hL:
				if 'myegyvip' not in zehVcU893FC6LEd1Aij: continue
				if zehVcU893FC6LEd1Aij.count('/')>=2:
					oikt6P0hOAD5IvnlMpxf1 = zehVcU893FC6LEd1Aij.split('/')[2]
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij+'?named='+oikt6P0hOAD5IvnlMpxf1+'__download__mp4__'+a0ao2jdlt4r9nhHwpvSgOVGA)
	RKFv4AP3fDzwtisg6V1nGCQyjbu = []
	for zehVcU893FC6LEd1Aij in UTwH7zjZOrmFl:
		RKFv4AP3fDzwtisg6V1nGCQyjbu.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(RKFv4AP3fDzwtisg6V1nGCQyjbu,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(NXpO8DrVmeE,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'EGYBESTVIP-SEARCH-1st')
	JMox3q27Fi1Rd468Z = YYqECUofyi7wFrW.findall('name="_token" value="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if JMox3q27Fi1Rd468Z:
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search?_token='+JMox3q27Fi1Rd468Z[0]+'&q='+n5pZARB2X0x8abLPeywMuHkqV
		hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
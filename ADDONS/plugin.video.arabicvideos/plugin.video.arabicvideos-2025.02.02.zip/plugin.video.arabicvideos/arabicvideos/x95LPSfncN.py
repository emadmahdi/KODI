# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'SHOOFMAX'
LJfTAEQPv9h4BXdwUp = '_SHM_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
PPma30ybADqJNu = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][1]
bnmdzNygt4HWEPOvL6lQMB = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][2]
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==50: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==51: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==52: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==53: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==55: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = jPOu9vltSekIUMh6bJQx4B08()
	elif mode==56: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = DuC4tnHyx7h3kwbRPJT()
	elif mode==57: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ONohvx9PlU3Gnwyi8FJ5kg(url,1)
	elif mode==58: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = ONohvx9PlU3Gnwyi8FJ5kg(url,2)
	elif mode==59: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,59,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المسلسلات',NdKhAS6MXVEORLTwob92pxlZ,56)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الافلام',NdKhAS6MXVEORLTwob92pxlZ,55)
	return NdKhAS6MXVEORLTwob92pxlZ
def jPOu9vltSekIUMh6bJQx4B08():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أفلام مرتبة بسنة الإنتاج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movie/1/yop',57)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أفلام مرتبة بالأفضل تقييم',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movie/1/review',57)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أفلام مرتبة بالأكثر مشاهدة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movie/1/views',57)
	return
def DuC4tnHyx7h3kwbRPJT():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات مرتبة بسنة الإنتاج',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/series/1/yop',57)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات مرتبة بالأفضل تقييم',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/series/1/review',57)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسلات مرتبة بالأكثر مشاهدة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/series/1/views',57)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	if '?' in url:
		BDkTn4JaU3HsYzI = url.split('?')
		url = BDkTn4JaU3HsYzI[0]
		filter = '?' + YUkzG2ymNSqdon(BDkTn4JaU3HsYzI[1],'=&:/%')
	else: filter = NdKhAS6MXVEORLTwob92pxlZ
	type,jNgDBqeKyZ4zSkGv8ROMA70aIYcC,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': HeW40B5t8iMsy2Y3GXU7QxJwg='فيلم'
		elif type=='series': HeW40B5t8iMsy2Y3GXU7QxJwg='مسلسل'
		url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/genre/filter/' + YUkzG2ymNSqdon(HeW40B5t8iMsy2Y3GXU7QxJwg) + '/' + jNgDBqeKyZ4zSkGv8ROMA70aIYcC + '/' + sort + filter
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-TITLES-1st')
		items = YYqECUofyi7wFrW.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		YjQKgJNBxDu65PyqZCOc8zwdX=0
		for id,title,Z2r6GnWwLaHeMBhOjAVq4,TTuPH708dUNnjlG3oQpkZsi in items:
			YjQKgJNBxDu65PyqZCOc8zwdX += 1
			TTuPH708dUNnjlG3oQpkZsi = bnmdzNygt4HWEPOvL6lQMB + '/v2/img/program/main/' + TTuPH708dUNnjlG3oQpkZsi + '-2.jpg'
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/program/' + id
			if type=='movie': ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,53,TTuPH708dUNnjlG3oQpkZsi)
			if type=='series': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسل '+title,zehVcU893FC6LEd1Aij+'?ep='+Z2r6GnWwLaHeMBhOjAVq4+'='+title+'='+TTuPH708dUNnjlG3oQpkZsi,52,TTuPH708dUNnjlG3oQpkZsi)
	else:
		if type=='movie': HeW40B5t8iMsy2Y3GXU7QxJwg='movies'
		elif type=='series': HeW40B5t8iMsy2Y3GXU7QxJwg='series'
		url = PPma30ybADqJNu + '/json/selected/' + sort + '-' + HeW40B5t8iMsy2Y3GXU7QxJwg + '-WW.json'
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-TITLES-2nd')
		items = YYqECUofyi7wFrW.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		YjQKgJNBxDu65PyqZCOc8zwdX=0
		for id,Z2r6GnWwLaHeMBhOjAVq4,TTuPH708dUNnjlG3oQpkZsi,title in items:
			YjQKgJNBxDu65PyqZCOc8zwdX += 1
			TTuPH708dUNnjlG3oQpkZsi = PPma30ybADqJNu + '/img/program/' + TTuPH708dUNnjlG3oQpkZsi + '-2.jpg'
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/program/' + id
			if type=='movie': ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,53,TTuPH708dUNnjlG3oQpkZsi)
			elif type=='series': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مسلسل '+title,zehVcU893FC6LEd1Aij+'?ep='+Z2r6GnWwLaHeMBhOjAVq4+'='+title+'='+TTuPH708dUNnjlG3oQpkZsi,52,TTuPH708dUNnjlG3oQpkZsi)
	title='صفحة '
	if YjQKgJNBxDu65PyqZCOc8zwdX==16:
		for gWfeTcKdiYhAM7Skv4NI5GQLtXj8H in range(1,13) :
			if not jNgDBqeKyZ4zSkGv8ROMA70aIYcC==str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H):
				url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/genre/filter/'+type+'/'+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H)+'/'+sort+filter
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title+str(gWfeTcKdiYhAM7Skv4NI5GQLtXj8H),url,51)
	return
def vl57jIYC4a(url):
	BDkTn4JaU3HsYzI = url.split('=')
	Z2r6GnWwLaHeMBhOjAVq4 = int(BDkTn4JaU3HsYzI[1])
	name = OOFEmwq2GkTz93WXy1Nj(BDkTn4JaU3HsYzI[2])
	name = name.replace('_MOD_مسلسل ',NdKhAS6MXVEORLTwob92pxlZ)
	TTuPH708dUNnjlG3oQpkZsi = BDkTn4JaU3HsYzI[3]
	url = url.split('?')[0]
	if Z2r6GnWwLaHeMBhOjAVq4==0:
		LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-EPISODES-1st')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<select(.*?)</select>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('option value="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		Z2r6GnWwLaHeMBhOjAVq4 = int(items[-1])
	for N1VjdbtuO3z in range(Z2r6GnWwLaHeMBhOjAVq4,0,-1):
		zehVcU893FC6LEd1Aij = url + '?ep=' + str(N1VjdbtuO3z)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(N1VjdbtuO3z)
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,53,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-PLAY-1st')
	b2DwleUrZghT7zuF6xp49X08NQP1 = YYqECUofyi7wFrW.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if b2DwleUrZghT7zuF6xp49X08NQP1:
		XJ62UBRmIqFvfiNTQj = b2DwleUrZghT7zuF6xp49X08NQP1[1].replace('T',mrgzi2ktB4WS06QHPf5ZJE1Kv)
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+B6IrC7zEHlw1oaeWf+XJ62UBRmIqFvfiNTQj)
		return
	j8F0WQaEcie,ggTKfbsj9dLn = [],[]
	wZ6qBhF0n5yLaGc8ps37dzPHvf = YYqECUofyi7wFrW.findall('var origin_link = "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	I0481yBiTw9HRvnfDJVANash = YYqECUofyi7wFrW.findall('var backup_origin_link = "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)[0]
	oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('hls: (.*?)_link\+"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for oikt6P0hOAD5IvnlMpxf1,zehVcU893FC6LEd1Aij in oDhlaxn0EqyYikcHrmZBN8uv:
		if 'backup' in oikt6P0hOAD5IvnlMpxf1:
			oikt6P0hOAD5IvnlMpxf1 = 'backup server'
			url = I0481yBiTw9HRvnfDJVANash + zehVcU893FC6LEd1Aij
		else:
			oikt6P0hOAD5IvnlMpxf1 = 'main server'
			url = wZ6qBhF0n5yLaGc8ps37dzPHvf + zehVcU893FC6LEd1Aij
		if '.m3u8' in url:
			j8F0WQaEcie.append(url)
			ggTKfbsj9dLn.append('m3u8  '+oikt6P0hOAD5IvnlMpxf1)
	oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	oDhlaxn0EqyYikcHrmZBN8uv += YYqECUofyi7wFrW.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for oikt6P0hOAD5IvnlMpxf1,zehVcU893FC6LEd1Aij in oDhlaxn0EqyYikcHrmZBN8uv:
		filename = zehVcU893FC6LEd1Aij.split('/')[-1]
		filename = filename.replace('fallback',NdKhAS6MXVEORLTwob92pxlZ)
		filename = filename.replace('.mp4',NdKhAS6MXVEORLTwob92pxlZ)
		filename = filename.replace('-',NdKhAS6MXVEORLTwob92pxlZ)
		if 'backup' in oikt6P0hOAD5IvnlMpxf1:
			oikt6P0hOAD5IvnlMpxf1 = 'backup server'
			url = I0481yBiTw9HRvnfDJVANash + zehVcU893FC6LEd1Aij
		else:
			oikt6P0hOAD5IvnlMpxf1 = 'main server'
			url = wZ6qBhF0n5yLaGc8ps37dzPHvf + zehVcU893FC6LEd1Aij
		j8F0WQaEcie.append(url)
		ggTKfbsj9dLn.append('mp4  '+oikt6P0hOAD5IvnlMpxf1+Uv7MkgVGyEbAlfFP0S8Zjqp2J+filename)
	rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('Select Video Quality:', ggTKfbsj9dLn)
	if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
	url = j8F0WQaEcie[rRfpvbZojlygET5JL87wdzIPGe]
	llQB96aRtAXDdJyW3IkgfOMcKrF8w4(url,yNIDEX5hU4G769,'video')
	return
def ONohvx9PlU3Gnwyi8FJ5kg(url,type):
	if 'series' in url: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/genre/مسلسل'
	else: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/genre/فيلم'
	BfjcMoqOsmdUvZVCHWIyQKi = YUkzG2ymNSqdon(BfjcMoqOsmdUvZVCHWIyQKi)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-FILTERS-1st')
	if type==1: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('subgenre(.*?)div',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type==2: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('country(.*?)div',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('option value="(.*?)">(.*?)</option',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if type==1:
		for rIEzNRbDQeCfGks9HvZwWJU,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url+'?subgenre='+rIEzNRbDQeCfGks9HvZwWJU,58)
	elif type==2:
		url,rIEzNRbDQeCfGks9HvZwWJU = url.split('?')
		for wziCR1x4XQEAOB9U6KfGJYmTHl8,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url+'?country='+wziCR1x4XQEAOB9U6KfGJYmTHl8+'&'+rIEzNRbDQeCfGks9HvZwWJU,51)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search: search = Z6GiHgnz0jNytc()
	if not search: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search?q='+n5pZARB2X0x8abLPeywMuHkqV
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,True,NdKhAS6MXVEORLTwob92pxlZ,'SHOOFMAX-SEARCH-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('general-body(.*?)search-bottom-padding',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if items:
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + zehVcU893FC6LEd1Aij
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+YUkzG2ymNSqdon(title)+'='+TTuPH708dUNnjlG3oQpkZsi
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,52,TTuPH708dUNnjlG3oQpkZsi)
				else:
					title = '_MOD_فيلم '+title
					ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,url,53,TTuPH708dUNnjlG3oQpkZsi)
	return
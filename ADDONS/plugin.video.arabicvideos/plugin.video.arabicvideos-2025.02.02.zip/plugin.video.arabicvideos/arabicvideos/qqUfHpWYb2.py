# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ARBLIONZ'
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
LJfTAEQPv9h4BXdwUp = '_ARL_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==200: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==201: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	elif mode==202: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==203: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==204: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'FILTERS___'+text)
	elif mode==205: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'CATEGORIES___'+text)
	elif mode==209: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,209,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,205)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,204)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'??trending',201)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أفلام مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'??trending_movies',201)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'??trending_series',201)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الصفحة الرئيسية',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'??mainpage',201)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,True,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('categories-tabs(.*?)MainRow',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-get="(.*?)".*?<h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for filter,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/ajax/home/more?filter='+filter
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,201)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('navigation-menu(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,201)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url):
	if '??' in url: url,type = url.split('??')
	else: type = NdKhAS6MXVEORLTwob92pxlZ
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-TITLES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
	if 'getposts' in url: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP]
	elif type=='trending':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='trending_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='trending_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	elif type=='111mainpage':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="container page-content"(.*?)class="tabs"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('page-content(.*?)main-footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: return
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	RnWCFcXJeB7Sv = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = YYqECUofyi7wFrW.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items:
		items = YYqECUofyi7wFrW.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		oDhlaxn0EqyYikcHrmZBN8uv,QQJRhamjz0nYHV,DDviHT4pFVhgwaL = zip(*items)
		items = zip(QQJRhamjz0nYHV,oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		if '/series/' in zehVcU893FC6LEd1Aij: continue
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.strip('/')
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if '/film/' in zehVcU893FC6LEd1Aij or any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in RnWCFcXJeB7Sv):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,202,TTuPH708dUNnjlG3oQpkZsi)
		elif '/episode/' in zehVcU893FC6LEd1Aij and 'الحلقة' in title:
			N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
			if N1VjdbtuO3z:
				title = '_MOD_' + N1VjdbtuO3z[0]
				if title not in zIDPZSNn1OuweLHvmMKb6d:
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,203,TTuPH708dUNnjlG3oQpkZsi)
					zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif '/pack/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij+'/films',201,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,203,TTuPH708dUNnjlG3oQpkZsi)
	if type in [NdKhAS6MXVEORLTwob92pxlZ,'mainpage']:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href=["\'](http.*?)["\'].*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
				if 'search?s=' in url:
					qZJygXSzkx15HMuljBwt4GKFN2 = zehVcU893FC6LEd1Aij.split('page=')[1]
					eC61iZgx8qMkNWfD3yT = url.split('page=')[1]
					zehVcU893FC6LEd1Aij = url.replace('page='+eC61iZgx8qMkNWfD3yT,'page='+qZJygXSzkx15HMuljBwt4GKFN2)
				if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,201)
	return
def vl57jIYC4a(url):
	YqICN1R0Mb4JZFkzhvDW9e,items,NlnQdZwm4j = -1,[],[]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('ti-list-numbered(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		NlnQdZwm4j = []
		sCRbZp6Irl17v = NdKhAS6MXVEORLTwob92pxlZ.join(bMU7NEFK5RJ8dcz0jtqiWmvyar6)
		items = YYqECUofyi7wFrW.findall('href="(.*?)"',sCRbZp6Irl17v,YYqECUofyi7wFrW.DOTALL)
	items.append(url)
	items = set(items)
	for zehVcU893FC6LEd1Aij in items:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.strip('/')
		title = '_MOD_' + zehVcU893FC6LEd1Aij.split('/')[-1].replace('-',Vwgflszp4WRA93kx6hvdua21HX5cOb)
		oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = YYqECUofyi7wFrW.findall('الحلقة-(\d+)',zehVcU893FC6LEd1Aij.split('/')[-1],YYqECUofyi7wFrW.DOTALL)
		if oLQuxeSOY6A0fq2kF3TZnbGgw7Dc: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = oLQuxeSOY6A0fq2kF3TZnbGgw7Dc[0]
		else: oLQuxeSOY6A0fq2kF3TZnbGgw7Dc = '0'
		NlnQdZwm4j.append([zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc])
	items = sorted(NlnQdZwm4j, reverse=False, key=lambda key: int(key[2]))
	cPqut3WSXjAVyaGhH7O5J9obw2i = str(items).count('/season/')
	YqICN1R0Mb4JZFkzhvDW9e = str(items).count('/episode/')
	if cPqut3WSXjAVyaGhH7O5J9obw2i>1 and YqICN1R0Mb4JZFkzhvDW9e>0 and '/season/' not in url:
		for zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc in items:
			if '/season/' in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,203)
	else:
		for zehVcU893FC6LEd1Aij,title,oLQuxeSOY6A0fq2kF3TZnbGgw7Dc in items:
			if '/season/' not in zehVcU893FC6LEd1Aij:
				title = OOFEmwq2GkTz93WXy1Nj(title)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,202)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl = []
	BDkTn4JaU3HsYzI = url.split('/')
	M94vqWhgDVHF = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,True,'ARBLIONZ-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
	id = YYqECUofyi7wFrW.findall('postId:"(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not id: id = YYqECUofyi7wFrW.findall('post_id=(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not id: id = YYqECUofyi7wFrW.findall('post-id="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if id: id = id[0]
	if '/watch/' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		BfjcMoqOsmdUvZVCHWIyQKi = url.replace(BDkTn4JaU3HsYzI[3],'watch')
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,headers,True,True,'ARBLIONZ-PLAY-2nd')
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
		bVHF5x6dk0m2SepUG7lj3NsDZLCcif = YYqECUofyi7wFrW.findall('data-embedd="(.*?)".*?alt="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('data-embedd=".*?(http.*?)("|&quot;)',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		yBbJpP4NqMXReEa = YYqECUofyi7wFrW.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',HeFB5x2wED)
		eJiwyhAuWr = YYqECUofyi7wFrW.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		f8qBxohL3RcNzTWbjp71YeIkta5 = YYqECUofyi7wFrW.findall('server="(.*?)".*?<span>(.*?)<',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
		items = bVHF5x6dk0m2SepUG7lj3NsDZLCcif+APRuYMmlIVGTX+yBbJpP4NqMXReEa+sZEBgo9cfnXJq2rK1+eJiwyhAuWr+f8qBxohL3RcNzTWbjp71YeIkta5
		if not items:
			items = YYqECUofyi7wFrW.findall('<span>(.*?)</span>.*?src="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL|YYqECUofyi7wFrW.IGNORECASE)
			items = [(G98UeJVjr7isaZyoAfSw625mnKQNl0,AvBYdKXjCz4FST) for AvBYdKXjCz4FST,G98UeJVjr7isaZyoAfSw625mnKQNl0 in items]
		for oikt6P0hOAD5IvnlMpxf1,title in items:
			if '.png' in oikt6P0hOAD5IvnlMpxf1: continue
			if '.jpg' in oikt6P0hOAD5IvnlMpxf1: continue
			if '&quot;' in oikt6P0hOAD5IvnlMpxf1: continue
			a0ao2jdlt4r9nhHwpvSgOVGA = YYqECUofyi7wFrW.findall('\d\d\d+',title,YYqECUofyi7wFrW.DOTALL)
			if a0ao2jdlt4r9nhHwpvSgOVGA:
				a0ao2jdlt4r9nhHwpvSgOVGA = a0ao2jdlt4r9nhHwpvSgOVGA[0]
				if a0ao2jdlt4r9nhHwpvSgOVGA in title: title = title.replace(a0ao2jdlt4r9nhHwpvSgOVGA+'p',NdKhAS6MXVEORLTwob92pxlZ).replace(a0ao2jdlt4r9nhHwpvSgOVGA,NdKhAS6MXVEORLTwob92pxlZ).strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA
			else: a0ao2jdlt4r9nhHwpvSgOVGA = NdKhAS6MXVEORLTwob92pxlZ
			if oikt6P0hOAD5IvnlMpxf1.isdigit():
				zehVcU893FC6LEd1Aij = M94vqWhgDVHF+'/?postid='+id+'&serverid='+oikt6P0hOAD5IvnlMpxf1+'?named='+title+'__watch'+a0ao2jdlt4r9nhHwpvSgOVGA
			else:
				if 'http' not in oikt6P0hOAD5IvnlMpxf1: oikt6P0hOAD5IvnlMpxf1 = 'http:'+oikt6P0hOAD5IvnlMpxf1
				a0ao2jdlt4r9nhHwpvSgOVGA = YYqECUofyi7wFrW.findall('\d\d\d+',title,YYqECUofyi7wFrW.DOTALL)
				if a0ao2jdlt4r9nhHwpvSgOVGA: a0ao2jdlt4r9nhHwpvSgOVGA = '____'+a0ao2jdlt4r9nhHwpvSgOVGA[0]
				else: a0ao2jdlt4r9nhHwpvSgOVGA = NdKhAS6MXVEORLTwob92pxlZ
				zehVcU893FC6LEd1Aij = oikt6P0hOAD5IvnlMpxf1+'?named=__watch'+a0ao2jdlt4r9nhHwpvSgOVGA
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if 'DownloadNow' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		omrd89nv0PGKFpL3TxfAXt = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/download'
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,True,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-PLAY-3rd')
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<ul class="download-items(.*?)</ul>',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
		for AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			items = YYqECUofyi7wFrW.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,name,a0ao2jdlt4r9nhHwpvSgOVGA in items:
				zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+name+'__download'+'____'+a0ao2jdlt4r9nhHwpvSgOVGA
				UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	elif '/download/' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		omrd89nv0PGKFpL3TxfAXt = { 'User-Agent':NdKhAS6MXVEORLTwob92pxlZ , 'X-Requested-With':'XMLHttpRequest' }
		BfjcMoqOsmdUvZVCHWIyQKi = M94vqWhgDVHF + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,omrd89nv0PGKFpL3TxfAXt,True,True,'ARBLIONZ-PLAY-4th')
		HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
		if 'download-btns' in HeFB5x2wED:
			yBbJpP4NqMXReEa = YYqECUofyi7wFrW.findall('href="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			for Afey3cL4ojzg in yBbJpP4NqMXReEa:
				if '/page/' not in Afey3cL4ojzg and 'http' in Afey3cL4ojzg:
					Afey3cL4ojzg = Afey3cL4ojzg+'?named=__download'
					UTwH7zjZOrmFl.append(Afey3cL4ojzg)
				elif '/page/' in Afey3cL4ojzg:
					a0ao2jdlt4r9nhHwpvSgOVGA = NdKhAS6MXVEORLTwob92pxlZ
					VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',Afey3cL4ojzg,NdKhAS6MXVEORLTwob92pxlZ,headers,True,True,'ARBLIONZ-PLAY-5th')
					gPy9H5KsCRL0eWdB4IoMlDT = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
					sCRbZp6Irl17v = YYqECUofyi7wFrW.findall('(<strong>.*?)-----',gPy9H5KsCRL0eWdB4IoMlDT,YYqECUofyi7wFrW.DOTALL)
					for TO7ptH29QAZC1GL0gyjWSJr in sCRbZp6Irl17v:
						W1eZaEv5rsTwXn9jJ67Yp = NdKhAS6MXVEORLTwob92pxlZ
						sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('<strong>(.*?)</strong>',TO7ptH29QAZC1GL0gyjWSJr,YYqECUofyi7wFrW.DOTALL)
						for NtwPeajVSHB7YMXyb in sZEBgo9cfnXJq2rK1:
							rMOG2USkPesYZD9KNAVqpc = YYqECUofyi7wFrW.findall('\d\d\d+',NtwPeajVSHB7YMXyb,YYqECUofyi7wFrW.DOTALL)
							if rMOG2USkPesYZD9KNAVqpc:
								a0ao2jdlt4r9nhHwpvSgOVGA = '____'+rMOG2USkPesYZD9KNAVqpc[0]
								break
						for NtwPeajVSHB7YMXyb in reversed(sZEBgo9cfnXJq2rK1):
							rMOG2USkPesYZD9KNAVqpc = YYqECUofyi7wFrW.findall('\w\w+',NtwPeajVSHB7YMXyb,YYqECUofyi7wFrW.DOTALL)
							if rMOG2USkPesYZD9KNAVqpc:
								W1eZaEv5rsTwXn9jJ67Yp = rMOG2USkPesYZD9KNAVqpc[0]
								break
						eJiwyhAuWr = YYqECUofyi7wFrW.findall('href="(.*?)"',TO7ptH29QAZC1GL0gyjWSJr,YYqECUofyi7wFrW.DOTALL)
						for kUS2hmXsTqZjK4nBRdQ5bFOy6w1Y3 in eJiwyhAuWr:
							kUS2hmXsTqZjK4nBRdQ5bFOy6w1Y3 = kUS2hmXsTqZjK4nBRdQ5bFOy6w1Y3+'?named='+W1eZaEv5rsTwXn9jJ67Yp+'__download'+a0ao2jdlt4r9nhHwpvSgOVGA
							UTwH7zjZOrmFl.append(kUS2hmXsTqZjK4nBRdQ5bFOy6w1Y3)
		elif 'slow-motion' in HeFB5x2wED:
			HeFB5x2wED = HeFB5x2wED.replace('<h6 ','==END== ==START==')+'==END=='
			HeFB5x2wED = HeFB5x2wED.replace('<h3 ','==END== ==START==')+'==END=='
			kQ8U2Bwts4nODSMmARdbK = YYqECUofyi7wFrW.findall('==START==(.*?)==END==',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
			if kQ8U2Bwts4nODSMmARdbK:
				for TO7ptH29QAZC1GL0gyjWSJr in kQ8U2Bwts4nODSMmARdbK:
					if 'href=' not in TO7ptH29QAZC1GL0gyjWSJr: continue
					jwYxZe23Icrp6atF0z = NdKhAS6MXVEORLTwob92pxlZ
					sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('slow-motion">(.*?)<',TO7ptH29QAZC1GL0gyjWSJr,YYqECUofyi7wFrW.DOTALL)
					for NtwPeajVSHB7YMXyb in sZEBgo9cfnXJq2rK1:
						rMOG2USkPesYZD9KNAVqpc = YYqECUofyi7wFrW.findall('\d\d\d+',NtwPeajVSHB7YMXyb,YYqECUofyi7wFrW.DOTALL)
						if rMOG2USkPesYZD9KNAVqpc:
							jwYxZe23Icrp6atF0z = '____'+rMOG2USkPesYZD9KNAVqpc[0]
							break
					sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('<td>(.*?)</td>.*?href="(http.*?)"',TO7ptH29QAZC1GL0gyjWSJr,YYqECUofyi7wFrW.DOTALL)
					if sZEBgo9cfnXJq2rK1:
						for W1eZaEv5rsTwXn9jJ67Yp,uupITli4wLS in sZEBgo9cfnXJq2rK1:
							uupITli4wLS = uupITli4wLS+'?named='+W1eZaEv5rsTwXn9jJ67Yp+'__download'+jwYxZe23Icrp6atF0z
							UTwH7zjZOrmFl.append(uupITli4wLS)
					else:
						sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('href="(.*?http.*?)".*?name">(.*?)<',TO7ptH29QAZC1GL0gyjWSJr,YYqECUofyi7wFrW.DOTALL)
						for uupITli4wLS,W1eZaEv5rsTwXn9jJ67Yp in sZEBgo9cfnXJq2rK1:
							uupITli4wLS = uupITli4wLS.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)+'?named='+W1eZaEv5rsTwXn9jJ67Yp+'__download'+jwYxZe23Icrp6atF0z
							UTwH7zjZOrmFl.append(uupITli4wLS)
			else:
				sZEBgo9cfnXJq2rK1 = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(\w+)<',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
				for uupITli4wLS,W1eZaEv5rsTwXn9jJ67Yp in sZEBgo9cfnXJq2rK1:
					uupITli4wLS = uupITli4wLS.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)+'?named='+W1eZaEv5rsTwXn9jJ67Yp+'__download'
					UTwH7zjZOrmFl.append(uupITli4wLS)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/alz',NdKhAS6MXVEORLTwob92pxlZ,headers,True,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-SEARCH-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content.encode(YRvPKe2zMTDs8UCkr)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('chevron-select(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if showDialogs and bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('value="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		Fv6aESNicC0tWkgswGJ3VU,NnFCtc1X6syKOTM = [],[]
		for II4s1CdgcbN6BSvWPnHtz,title in items:
			Fv6aESNicC0tWkgswGJ3VU.append(II4s1CdgcbN6BSvWPnHtz)
			NnFCtc1X6syKOTM.append(title)
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر الفلتر المناسب:', NnFCtc1X6syKOTM)
		if rRfpvbZojlygET5JL87wdzIPGe == -1 : return
		II4s1CdgcbN6BSvWPnHtz = Fv6aESNicC0tWkgswGJ3VU[rRfpvbZojlygET5JL87wdzIPGe]
	else: II4s1CdgcbN6BSvWPnHtz = NdKhAS6MXVEORLTwob92pxlZ
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/search?s='+search+'&category='+II4s1CdgcbN6BSvWPnHtz+'&page=1'
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	axsbpdckhGP127u5wEgnZtV4LWvzli = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='CATEGORIES':
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'/getposts?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='FILTERS':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'modified_filters')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'/getposts?'+Jv2yebcHLo5GCrXZlw
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها ',BfjcMoqOsmdUvZVCHWIyQKi,201)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,201)
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url+'/alz',NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'ARBLIONZ-FILTERS_MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('AjaxFilteringData(.*?)FilterWord',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	dict = {}
	for name,zZ0VrYRv6m8,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		name = name.replace('اختيار ',NdKhAS6MXVEORLTwob92pxlZ)
		name = name.replace('سنة الإنتاج','السنة')
		items = YYqECUofyi7wFrW.findall('value="(.*?)".*?</div>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='CATEGORIES':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<=1:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'CATEGORIES___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',BfjcMoqOsmdUvZVCHWIyQKi,201)
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع ',BfjcMoqOsmdUvZVCHWIyQKi,205,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='FILTERS':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع :'+name,BfjcMoqOsmdUvZVCHWIyQKi,204,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			X9dRM31pz6y = X9dRM31pz6y.replace(B6IrC7zEHlw1oaeWf,NdKhAS6MXVEORLTwob92pxlZ)
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' :'#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' :'+name
			if type=='FILTERS': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,204,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='CATEGORIES' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'modified_filters')
				Afey3cL4ojzg = url+'/getposts?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,201)
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,205,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.replace('=&','=0&')
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	dW42o7vIOrS9wu = ['category','release-year','genre','Quality']
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if '%' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = YUkzG2ymNSqdon(K6KbZDHncNizQgl1fr59XV0)
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('=0','=')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.replace('Quality','quality')
	return LaGtUDiK2xnfz
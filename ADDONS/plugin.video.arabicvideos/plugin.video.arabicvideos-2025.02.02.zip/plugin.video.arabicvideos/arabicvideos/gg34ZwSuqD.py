# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'BOKRA'
LJfTAEQPv9h4BXdwUp = '_BKR_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
Kdr54yMqbjTSX7piWREfPtZ2em = ['افلام للكبار','بكرا TV']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==370: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==371: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==372: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==374: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = QQYuzMASegjyVlno86JBOWZXHaE(url)
	elif mode==375: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = OvnDmPcHJjYV(url)
	elif mode==376: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = h6fKMFAwdylQCRUGHe(0,url)
	elif mode==377: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = h6fKMFAwdylQCRUGHe(1,url)
	elif mode==379: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-MENU-1st')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,379,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('right-side(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,375)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'الأحدث',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,376)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'قائمة الممثلين',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,374)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="container"(.*?)top-menu',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items[7:]:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371)
		for zehVcU893FC6LEd1Aij,title in items[0:7]:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371)
	return
def QQYuzMASegjyVlno86JBOWZXHaE(website=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(OewIv05xGhKQpFf,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-ACTORSMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="row cat Tags"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if 'http' in zehVcU893FC6LEd1Aij: continue
			else: zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371)
	return
def OvnDmPcHJjYV(website=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-FEATURED-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"MainContent"(.*?)main-title2',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('://',':///').replace('//','/').replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
				ZI51XvE8YatWCmNdrp('video',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,372,TTuPH708dUNnjlG3oQpkZsi)
	return
def h6fKMFAwdylQCRUGHe(id,website=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-WATCHINGNOW-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('main-title2(.*?)class="row',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[id]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
			if not any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em):
				TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('://',':///').replace('//','/').replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
				ZI51XvE8YatWCmNdrp('video',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,372,TTuPH708dUNnjlG3oQpkZsi)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,HeW40B5t8iMsy2Y3GXU7QxJwg=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if 'vidpage_' in url:
		zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('href="(/Album-.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if zehVcU893FC6LEd1Aij:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij[0]
			hGJKk8tAiC3XFufEpqavQWmwTHdL(zehVcU893FC6LEd1Aij)
			return
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class=" subcats"(.*?)class="col-md-3',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if HeW40B5t8iMsy2Y3GXU7QxJwg==NdKhAS6MXVEORLTwob92pxlZ and bMU7NEFK5RJ8dcz0jtqiWmvyar6 and bMU7NEFK5RJ8dcz0jtqiWmvyar6[0].count('href')>1:
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',url,371,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'titles')
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)" title="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371)
	else:
		zIDPZSNn1OuweLHvmMKb6d = []
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="col-md-3(.*?)col-xs-12',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="col-sm-8"(.*?)col-xs-12',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.replace('://',':///').replace('//','/').replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
				if '/al_' in zehVcU893FC6LEd1Aij:
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371,TTuPH708dUNnjlG3oQpkZsi)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) - +الحلقة +\d+',title,YYqECUofyi7wFrW.DOTALL)
					if N1VjdbtuO3z: title = '_MOD_مسلسل '+N1VjdbtuO3z[0]
					if title not in zIDPZSNn1OuweLHvmMKb6d:
						zIDPZSNn1OuweLHvmMKb6d.append(title)
						ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371,TTuPH708dUNnjlG3oQpkZsi)
				else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,372,TTuPH708dUNnjlG3oQpkZsi)
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('class="".*?href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+zehVcU893FC6LEd1Aij
				title = 'صفحة '+Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,371,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'titles')
	return
def uuvhoSanB2TWD(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('label-success mrg-btm-5 ">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	Afey3cL4ojzg = NdKhAS6MXVEORLTwob92pxlZ
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('var url = "(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
	else: BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/vidpage_','/Play/')
	if 'http' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+BfjcMoqOsmdUvZVCHWIyQKi
	BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi.strip('-')
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(MIT0n79k8beo26aJHW,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'BOKRA-PLAY-2nd')
	HeFB5x2wED = VNc1u4edS90FK5W6bsMgQC2B.content
	Afey3cL4ojzg = YYqECUofyi7wFrW.findall('src="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
	if Afey3cL4ojzg:
		Afey3cL4ojzg = Afey3cL4ojzg[-1]
		if 'http' not in Afey3cL4ojzg: Afey3cL4ojzg = 'http:'+Afey3cL4ojzg
		if '/PLAY/' not in BfjcMoqOsmdUvZVCHWIyQKi:
			if 'embed.min.js' in Afey3cL4ojzg:
				vYwWzXRZLjKceotifTCHdn48sM = YYqECUofyi7wFrW.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',HeFB5x2wED,YYqECUofyi7wFrW.DOTALL)
				if vYwWzXRZLjKceotifTCHdn48sM:
					lPB8pXikwEG03Kxs52cmTV, Jchz5nHgGeijp9swMmRl8dxt7 = vYwWzXRZLjKceotifTCHdn48sM[0]
					Afey3cL4ojzg = msbTrJW03xuvA(Afey3cL4ojzg,'url')+'/v2/'+lPB8pXikwEG03Kxs52cmTV+'/config/'+Jchz5nHgGeijp9swMmRl8dxt7+'.json'
		import ttrmdIqhPY
		ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx([Afey3cL4ojzg],yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/Search/'+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
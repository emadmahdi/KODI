﻿# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1,JiUeBfkOqIMQXjGu0):
	if JiUeBfkOqIMQXjGu0==NdKhAS6MXVEORLTwob92pxlZ: return
	if pPrvqm3tjuXLTgw1==1:
		I1bOcNok6WCfmK0U7 = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.getCurrentWindowDialogId()
		uuVmFR6ObHinQ4kqjS0 = JTIdpcz98k7RyxHOX5EnqD6L1vKe04.Window(I1bOcNok6WCfmK0U7)
		JiUeBfkOqIMQXjGu0 = kdNDPcUObAMs9Kz(JiUeBfkOqIMQXjGu0)
		uuVmFR6ObHinQ4kqjS0.getControl(311).setLabel(JiUeBfkOqIMQXjGu0)
	if pPrvqm3tjuXLTgw1==0:
		GY9jgon6yhP0IvtCBEJu3='X'
		if J92gCnbGWidQV70lBteTwU6D8uyzL: EpOm9bkn1UC4g7vZXGSeW5xriLcV = isinstance(JiUeBfkOqIMQXjGu0,str)
		else: EpOm9bkn1UC4g7vZXGSeW5xriLcV = isinstance(JiUeBfkOqIMQXjGu0,unicode)
		if EpOm9bkn1UC4g7vZXGSeW5xriLcV==True: GY9jgon6yhP0IvtCBEJu3='U'
		LGPdNBH2iKRl1=str(type(JiUeBfkOqIMQXjGu0))+Vwgflszp4WRA93kx6hvdua21HX5cOb+JiUeBfkOqIMQXjGu0+Vwgflszp4WRA93kx6hvdua21HX5cOb+GY9jgon6yhP0IvtCBEJu3+Vwgflszp4WRA93kx6hvdua21HX5cOb
		for xX6zt5oS08TO29CUhYJa1K in range(0,len(JiUeBfkOqIMQXjGu0),1):
			LGPdNBH2iKRl1 += hex(ord(JiUeBfkOqIMQXjGu0[xX6zt5oS08TO29CUhYJa1K])).replace('0x',NdKhAS6MXVEORLTwob92pxlZ)+Vwgflszp4WRA93kx6hvdua21HX5cOb
		JiUeBfkOqIMQXjGu0 = kdNDPcUObAMs9Kz(JiUeBfkOqIMQXjGu0)
		GY9jgon6yhP0IvtCBEJu3='X'
		if J92gCnbGWidQV70lBteTwU6D8uyzL: EpOm9bkn1UC4g7vZXGSeW5xriLcV = isinstance(JiUeBfkOqIMQXjGu0, str)
		else: EpOm9bkn1UC4g7vZXGSeW5xriLcV = isinstance(JiUeBfkOqIMQXjGu0, unicode)
		if EpOm9bkn1UC4g7vZXGSeW5xriLcV==True: GY9jgon6yhP0IvtCBEJu3='U'
		jzwm4GtlgVxiQ7h5Sdpy3=str(type(JiUeBfkOqIMQXjGu0))+Vwgflszp4WRA93kx6hvdua21HX5cOb+JiUeBfkOqIMQXjGu0+Vwgflszp4WRA93kx6hvdua21HX5cOb+GY9jgon6yhP0IvtCBEJu3+Vwgflszp4WRA93kx6hvdua21HX5cOb
		for xX6zt5oS08TO29CUhYJa1K in range(0,len(JiUeBfkOqIMQXjGu0),1):
			jzwm4GtlgVxiQ7h5Sdpy3 += hex(ord(JiUeBfkOqIMQXjGu0[xX6zt5oS08TO29CUhYJa1K])).replace('0x',NdKhAS6MXVEORLTwob92pxlZ)+Vwgflszp4WRA93kx6hvdua21HX5cOb
	return
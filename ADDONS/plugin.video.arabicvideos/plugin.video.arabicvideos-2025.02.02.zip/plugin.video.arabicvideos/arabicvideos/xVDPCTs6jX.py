# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'FASELHD1'
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
LJfTAEQPv9h4BXdwUp = '_FH1_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['جوائز الأوسكار','المراجعات','wwe']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==570: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==571: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==572: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==573: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = X15CPKmVLqpi9hdvBsjZOY2D3Q(url,text)
	elif mode==576: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = FVCR1rfbYZHGLBP()
	elif mode==579: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('link',LJfTAEQPv9h4BXdwUp+'لماذا الموقع بطيء',NdKhAS6MXVEORLTwob92pxlZ,576)
	REGxsWAoilB7dCFNgMhz0V98bcm,url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD1-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',REGxsWAoilB7dCFNgMhz0V98bcm,579,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',REGxsWAoilB7dCFNgMhz0V98bcm,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured1')
	items = YYqECUofyi7wFrW.findall('class="h3">(.*?)<.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for title,zehVcU893FC6LEd1Aij in items:
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details1')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"menu-primary"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		p58bkCrGnwJFDs1i9Ut036hgLVdl2y = YYqECUofyi7wFrW.findall('<li (.*?)</li>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		ddW1bUPO3i = [NdKhAS6MXVEORLTwob92pxlZ,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		XW2Opt4RQsVihunCylz6j = 0
		for yzApRd2Dnes07XUZTM in p58bkCrGnwJFDs1i9Ut036hgLVdl2y:
			if XW2Opt4RQsVihunCylz6j>0: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',yzApRd2Dnes07XUZTM,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=='#': continue
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
				if title==NdKhAS6MXVEORLTwob92pxlZ: continue
				if any(K6KbZDHncNizQgl1fr59XV0 in title.lower() for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em): continue
				title = ddW1bUPO3i[XW2Opt4RQsVihunCylz6j]+title
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details2')
			XW2Opt4RQsVihunCylz6j += 1
	return
def FVCR1rfbYZHGLBP():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD1-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('class="h4">(.*?)</div>(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if not gcBxGPatZIzQ1: return
	if type=='filters':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"homeSlide"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		QQJRhamjz0nYHV,oDhlaxn0EqyYikcHrmZBN8uv,DDviHT4pFVhgwaL = zip(*items)
		items = zip(oDhlaxn0EqyYikcHrmZBN8uv,QQJRhamjz0nYHV,DDviHT4pFVhgwaL)
	elif type=='featured2':
		title,AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	elif type=='details2' and len(gcBxGPatZIzQ1)>1:
		title = gcBxGPatZIzQ1[0][0]
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured2')
		title = gcBxGPatZIzQ1[1][0]
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details3')
		return
	else:
		title,AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[-1]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	zIDPZSNn1OuweLHvmMKb6d = []
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if any(K6KbZDHncNizQgl1fr59XV0 in title.lower() for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em): continue
		TTuPH708dUNnjlG3oQpkZsi = L5xKSr96JmaX7N(TTuPH708dUNnjlG3oQpkZsi)
		TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi.split('?resize=')[0]
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة).\d+',title,YYqECUofyi7wFrW.DOTALL)
		if '/collections/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,571,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and type==NdKhAS6MXVEORLTwob92pxlZ:
			title = '_MOD_'+N1VjdbtuO3z[0][0]
			title = title.strip(' –')
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,573,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif 'episodes/' in zehVcU893FC6LEd1Aij or 'movies/' in zehVcU893FC6LEd1Aij or 'hindi/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,572,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,573,TTuPH708dUNnjlG3oQpkZsi)
	if type=='filters':
		aJNqiPEbZKIM5y6txrwTRj20dGHU = YYqECUofyi7wFrW.findall('"more_button_page":(.*?),',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if aJNqiPEbZKIM5y6txrwTRj20dGHU:
			count = aJNqiPEbZKIM5y6txrwTRj20dGHU[0]
			zehVcU893FC6LEd1Aij = url+'/offset/'+count
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة أخرى',zehVcU893FC6LEd1Aij,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
	elif 'details' in type:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("class='pagination(.*?)</div>",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall("href='(.*?)'.*?>(.*?)<",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = 'صفحة '+Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,571,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details4')
	return
def X15CPKmVLqpi9hdvBsjZOY2D3Q(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD1-SEASONS_EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ttVUWKLHayoTMnGwOjQqI = False
	if not type:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"seasonList"(.*?)"container"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if len(items)>1:
				REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
				ttVUWKLHayoTMnGwOjQqI = True
				for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,name,title in items:
					name = Pr4ubLdO7Z1qjKFaMIy3H(name)
					if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
					title = name+' - '+title
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,573,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,'episodes')
	if type=='episodes' or not ttVUWKLHayoTMnGwOjQqI:
		k1ChwgueU5nbDX6K0BOEGx = YYqECUofyi7wFrW.findall('"posterImg".*?src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if k1ChwgueU5nbDX6K0BOEGx: TTuPH708dUNnjlG3oQpkZsi = k1ChwgueU5nbDX6K0BOEGx[0]
		else: TTuPH708dUNnjlG3oQpkZsi = NdKhAS6MXVEORLTwob92pxlZ
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"epAll"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,572,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp,UU4f5PJzKIg,iQ9bCrJLy8zUnXA1Hqk = [],[],[]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD1-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZnxuHry0Apj1 = YYqECUofyi7wFrW.findall('مستوى المشاهدة.*?">(.*?)</span>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if ZnxuHry0Apj1:
		QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('"tag">(.*?)</a>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"videoRow"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split('&img=')[0]
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named=__embed')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="streamHeader(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall("href = '(.*?)'.*?</i>(.*?)</a>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split('&img=')[0]
			name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+name+'__watch')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="downloadLinks(.*?)blackwindow',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</span>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij.split('&img=')[0]
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+name+'__download')
	for raU0zgHfjWDip2dXFvKYJM3bxOSeN in Pj8lY4doOfxiFMuNLhv3tnp:
		zehVcU893FC6LEd1Aij,name = raU0zgHfjWDip2dXFvKYJM3bxOSeN.split('?named')
		if zehVcU893FC6LEd1Aij not in UU4f5PJzKIg:
			UU4f5PJzKIg.append(zehVcU893FC6LEd1Aij)
			iQ9bCrJLy8zUnXA1Hqk.append(raU0zgHfjWDip2dXFvKYJM3bxOSeN)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(iQ9bCrJLy8zUnXA1Hqk,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	BfjcMoqOsmdUvZVCHWIyQKi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi,'details5')
	return
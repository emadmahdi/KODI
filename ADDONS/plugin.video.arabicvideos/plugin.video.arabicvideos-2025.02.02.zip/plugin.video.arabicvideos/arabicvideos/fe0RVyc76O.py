# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'ARABICTOONS'
LJfTAEQPv9h4BXdwUp = '_ART_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==730: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==731: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==732: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==733: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==734: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = xxVivmSW0trfb5jo(url)
	elif mode==735: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = S4CpWA8MXV67f(url)
	elif mode==739: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,739,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'افلام',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/movies.php',731)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/cartoon.php',734)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات مميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/top.php',735)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أحدث الأفلام المضافة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,731,'','','LATEST_MOVIES')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أحدث المسلسلات المضافة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,731,'','','LATEST_SERIES')
	return
def xxVivmSW0trfb5jo(url):
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الكل',url,731)
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-SERIES_SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('label="navigation"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall("href='(.*?)'>(.*?)</a>",AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = 'حرف '+title
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,731)
	return
def S4CpWA8MXV67f(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-SERIES_FEATURED-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="slider"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,733,TTuPH708dUNnjlG3oQpkZsi)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("class='moviesBlocks(.*?)list-group",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if kF13d0oJXn4xKH=='LATEST_SERIES': AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	else: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
		TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if 'movies.php' in url or kF13d0oJXn4xKH=='LATEST_MOVIES':
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,732,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,733,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[-1]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,731)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall("class='moviesBlocks(.*?)script",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for title,zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,J1Fr6IsBcfhjQ in items:
			zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
			TTuPH708dUNnjlG3oQpkZsi = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+TTuPH708dUNnjlG3oQpkZsi
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			title = title+Vwgflszp4WRA93kx6hvdua21HX5cOb+J1Fr6IsBcfhjQ.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,732,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp = []
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('source src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if oDhlaxn0EqyYikcHrmZBN8uv:
		zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[0]
		if 'Referer=' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'|Referer=https://www.arabic-toons.com'
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named=__embed')
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	UTwH7zjZOrmFl = [NdKhAS6MXVEORLTwob92pxlZ,'m']
	V2E56eU4vIrcYoh91Azpm = ['مسلسلات','افلام']
	if showDialogs:
		rRfpvbZojlygET5JL87wdzIPGe = cCanV8J9iKuojqe5v4('اختر النوع المطلوب:', V2E56eU4vIrcYoh91Azpm)
		if rRfpvbZojlygET5JL87wdzIPGe==-1: return
	else: rRfpvbZojlygET5JL87wdzIPGe = 0
	type = UTwH7zjZOrmFl[rRfpvbZojlygET5JL87wdzIPGe]
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/livesearch.php?'+type+'&q='+search
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'ARABICTOONS-SEARCH-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		zehVcU893FC6LEd1Aij = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/'+zehVcU893FC6LEd1Aij
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		if type=='m': ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,732)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,733)
	return
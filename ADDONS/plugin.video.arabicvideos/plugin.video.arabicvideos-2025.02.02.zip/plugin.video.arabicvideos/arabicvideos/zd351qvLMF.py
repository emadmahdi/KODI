# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'CIMACLUP'
LJfTAEQPv9h4BXdwUp = '_CMC_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['موقع نتفليكس']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==490: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==491: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==492: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==493: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==494: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==499: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text,url)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	REGxsWAoilB7dCFNgMhz0V98bcm = YYqECUofyi7wFrW.findall('href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	REGxsWAoilB7dCFNgMhz0V98bcm = REGxsWAoilB7dCFNgMhz0V98bcm[0].strip('/')
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(REGxsWAoilB7dCFNgMhz0V98bcm,'url')
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"filter AjaxifyFilter"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('data-filter="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/wp-content/themes/old/filter/'+zehVcU893FC6LEd1Aij+'.php'
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,491)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أفلام',REGxsWAoilB7dCFNgMhz0V98bcm+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'مسلسلات',REGxsWAoilB7dCFNgMhz0V98bcm+'/category/مسلسلات/مسلسلات-اجنبى',494,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="navigation-menu"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if zehVcU893FC6LEd1Aij=='/': continue
		if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,491)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"filter"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,491)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,mfVtpzhI3WGnAx0=NdKhAS6MXVEORLTwob92pxlZ):
	items = []
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	AAMHoYxRCmt2D6ph89W = NdKhAS6MXVEORLTwob92pxlZ
	if '.php' in url: AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
	elif '?s=' in url:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"blocks(.*?)"manifest"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"Blocks(.*?)"manifest"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if not AAMHoYxRCmt2D6ph89W: return
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) حلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if not N1VjdbtuO3z: N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) الحلقة \d+',title,YYqECUofyi7wFrW.DOTALL)
		if not N1VjdbtuO3z or any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,492,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and 'حلقة' in title:
			title = '_MOD_' + N1VjdbtuO3z[0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,493,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,493,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('<li><a href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = Pr4ubLdO7Z1qjKFaMIy3H(title)
			title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
			if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,491)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	BfjcMoqOsmdUvZVCHWIyQKi = YYqECUofyi7wFrW.findall('"ButtonsBarCo".*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if BfjcMoqOsmdUvZVCHWIyQKi:
		BfjcMoqOsmdUvZVCHWIyQKi = BfjcMoqOsmdUvZVCHWIyQKi[0]
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-EPISODES-2nd')
		LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	TTuPH708dUNnjlG3oQpkZsi = YYqECUofyi7wFrW.findall('"img-responsive" src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if TTuPH708dUNnjlG3oQpkZsi: TTuPH708dUNnjlG3oQpkZsi = TTuPH708dUNnjlG3oQpkZsi[0]
	else: TTuPH708dUNnjlG3oQpkZsi = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Thumb')
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"filter"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"Blocks(.*?)class="pagination"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b and '/series/' not in url:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,493,TTuPH708dUNnjlG3oQpkZsi)
	elif gcBxGPatZIzQ1:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if items:
			for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,492,TTuPH708dUNnjlG3oQpkZsi)
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				title = title.replace('الصفحة ',NdKhAS6MXVEORLTwob92pxlZ)
				if title!=NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,491)
	return
def uuvhoSanB2TWD(url):
	BfjcMoqOsmdUvZVCHWIyQKi = url.strip('/')+'/?view=1'
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'CIMACLUP-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	UTwH7zjZOrmFl = []
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	F8nsaPk2UKYHzG7EMB4cSXlrVpdv = YYqECUofyi7wFrW.findall("data: 'q=(.*?)&",LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	F8nsaPk2UKYHzG7EMB4cSXlrVpdv = F8nsaPk2UKYHzG7EMB4cSXlrVpdv[0]
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"serversList"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-server="(.*?)">(.*?)</li>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for YiAaDLWdBjXh2tVuMRlbCn7SHU6x,title in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/wp-content/themes/old/servers/server.php?q='+F8nsaPk2UKYHzG7EMB4cSXlrVpdv+'&i='+YiAaDLWdBjXh2tVuMRlbCn7SHU6x+'?named='+title+'__watch'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('"embedServer".*?SRC="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		title = 'مفضل'
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]+'?named=__embed__'+title
		UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"downloadsList"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('<td>(.*?)</td>.*?href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for title,zehVcU893FC6LEd1Aij in items:
			title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if 'anavidz' in zehVcU893FC6LEd1Aij: PJN58A9SFZTwi6uLMB73m = '__خاص'
			else: PJN58A9SFZTwi6uLMB73m = NdKhAS6MXVEORLTwob92pxlZ
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named='+title+'__download'+PJN58A9SFZTwi6uLMB73m
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search,REGxsWAoilB7dCFNgMhz0V98bcm=NdKhAS6MXVEORLTwob92pxlZ):
	if not REGxsWAoilB7dCFNgMhz0V98bcm: REGxsWAoilB7dCFNgMhz0V98bcm = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if not search:
		search = Z6GiHgnz0jNytc()
		if not search: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = REGxsWAoilB7dCFNgMhz0V98bcm+'/index.php?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
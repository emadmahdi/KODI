# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
headers = { 'User-Agent' : NdKhAS6MXVEORLTwob92pxlZ }
yNIDEX5hU4G769 = 'AKWAM'
LJfTAEQPv9h4BXdwUp = '_AKW_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
xb2tHj8r6GWsOkco4PiChUdIvnQ = NdKhAS6MXVEORLTwob92pxlZ
Kdr54yMqbjTSX7piWREfPtZ2em = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==240: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==241: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==242: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==243: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==244: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'FILTERS___'+text)
	elif mode==245: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = Xi3ZCagjOpSAvB1rlnE6(url,'CATEGORIES___'+text)
	elif mode==246: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = mMycZCEBSPKHD45Y39hdL8xRs(url)
	elif mode==247: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = yswS0fnYxlrocVB7(url)
	elif mode==248: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = dehui8nFWQINVZDcT4H()
	elif mode==249: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def dehui8nFWQINVZDcT4H():
	ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'AKWAM-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	P3bJCfGdLapwAKNV = YYqECUofyi7wFrW.findall('home-site-btn-container.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if P3bJCfGdLapwAKNV: P3bJCfGdLapwAKNV = P3bJCfGdLapwAKNV[0]
	else: P3bJCfGdLapwAKNV = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',P3bJCfGdLapwAKNV,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'AKWAM-MENU-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,249,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر محدد',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,246)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'فلتر كامل',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,247)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المميزة',P3bJCfGdLapwAKNV,241,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	recent = YYqECUofyi7wFrW.findall('recently-container.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	zehVcU893FC6LEd1Aij = recent[0]
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'أضيف حديثا',zehVcU893FC6LEd1Aij,241)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,name,AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		if name in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+name,zehVcU893FC6LEd1Aij,241)
		items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			title = name+Vwgflszp4WRA93kx6hvdua21HX5cOb+title
			ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,241)
	return
def mMycZCEBSPKHD45Y39hdL8xRs(website=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKWAM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="menu(.*?)<nav',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?text">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
				title = title+' مصنفة'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,245)
		if website==NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def yswS0fnYxlrocVB7(website=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,headers,NdKhAS6MXVEORLTwob92pxlZ,'AKWAM-MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="menu(.*?)<nav',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?text">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title not in Kdr54yMqbjTSX7piWREfPtZ2em:
				title = title+' مفلترة'
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,244)
		if website==NdKhAS6MXVEORLTwob92pxlZ: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('swiper-container(.*?)swiper-button-prev',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	else: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="widget"(.*?)main-footer',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not items:
			items = YYqECUofyi7wFrW.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
			if '/series/' in zehVcU893FC6LEd1Aij or '/shows/' in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,242,TTuPH708dUNnjlG3oQpkZsi)
			elif '/movies/' in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,243,TTuPH708dUNnjlG3oQpkZsi)
			elif '/games/' not in zehVcU893FC6LEd1Aij:
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,243,TTuPH708dUNnjlG3oQpkZsi)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			zehVcU893FC6LEd1Aij = Pr4ubLdO7Z1qjKFaMIy3H(zehVcU893FC6LEd1Aij)
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,241)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	n5pZARB2X0x8abLPeywMuHkqV = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'%20')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN + '/search?q='+n5pZARB2X0x8abLPeywMuHkqV
	UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def vl57jIYC4a(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(h1dnE0q2zFHjXlvyGuLZxw,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		TTuPH708dUNnjlG3oQpkZsi = ACOWB6GRmIbDKyl3Zn.getInfoLabel('ListItem.Icon')
		ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+'رابط التشغيل',url,243,TTuPH708dUNnjlG3oQpkZsi)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('-episodes">(.*?)<div class="widget-4',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		EIPXmH9BMs54SqTFjgrfzLnt = YYqECUofyi7wFrW.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title,TTuPH708dUNnjlG3oQpkZsi in EIPXmH9BMs54SqTFjgrfzLnt:
			title = title.replace(Uv7MkgVGyEbAlfFP0S8Zjqp2J,Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in zehVcU893FC6LEd1Aij: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,242,TTuPH708dUNnjlG3oQpkZsi)
			else: ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,243,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKWAM-PLAY-1st')
	QQmNifUzRSTZL5jPvy129hA = YYqECUofyi7wFrW.findall('badge-danger.*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if QQmNifUzRSTZL5jPvy129hA and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,QQmNifUzRSTZL5jPvy129hA): return
	AACBpkgJWv8R = YYqECUofyi7wFrW.findall('li><a href="#(.*?)".*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	UTwH7zjZOrmFl,IGEpKNCaiLMT,sCRbZp6Irl17v,Pwh3gLtVrE28Xu7OQadJTnUqvf0G4o = [],[],[],[]
	if AACBpkgJWv8R:
		uJqZbeXK04CRjoQ = 'mp4'
		for rifpJXLv0CkbU6wxdW,a0ao2jdlt4r9nhHwpvSgOVGA in AACBpkgJWv8R:
			bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('tab-content quality" id="'+rifpJXLv0CkbU6wxdW+'".*?</div>.\s*</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			sCRbZp6Irl17v.append(AAMHoYxRCmt2D6ph89W)
			Pwh3gLtVrE28Xu7OQadJTnUqvf0G4o.append(a0ao2jdlt4r9nhHwpvSgOVGA)
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="qualities(.*?)<h3.*?>(.*?)<',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			AAMHoYxRCmt2D6ph89W,filename = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			OOQ3WjMcgwymVU6K0X72d = ['zip','rar','txt','pdf','htm','tar','iso','html']
			uJqZbeXK04CRjoQ = filename.rsplit('.',1)[1].strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			if uJqZbeXK04CRjoQ in OOQ3WjMcgwymVU6K0X72d:
				ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		sCRbZp6Irl17v.append(AAMHoYxRCmt2D6ph89W)
		Pwh3gLtVrE28Xu7OQadJTnUqvf0G4o.append(NdKhAS6MXVEORLTwob92pxlZ)
	for xX6zt5oS08TO29CUhYJa1K in range(len(sCRbZp6Irl17v)):
		oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('href="(.*?)".*?icon-(.*?)"',sCRbZp6Irl17v[xX6zt5oS08TO29CUhYJa1K],YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,mOUXR3ZSgPh1 in oDhlaxn0EqyYikcHrmZBN8uv:
			if 'torrent' in mOUXR3ZSgPh1: continue
			elif 'download' in mOUXR3ZSgPh1: type = 'download'
			elif 'play' in mOUXR3ZSgPh1: type = 'watch'
			else: type = 'unknown'
			zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij+'?named=__'+type+'____'+Pwh3gLtVrE28Xu7OQadJTnUqvf0G4o[xX6zt5oS08TO29CUhYJa1K]+'__akwam'
			UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(UTwH7zjZOrmFl,yNIDEX5hU4G769,'video',url)
	return
def Xi3ZCagjOpSAvB1rlnE6(url,filter):
	axsbpdckhGP127u5wEgnZtV4LWvzli = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==NdKhAS6MXVEORLTwob92pxlZ: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ
	else: Lo2zu1PTAB6,Jv2yebcHLo5GCrXZlw = filter.split('___')
	if type=='CATEGORIES':
		if axsbpdckhGP127u5wEgnZtV4LWvzli[0]+'=' not in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[0]
		for xX6zt5oS08TO29CUhYJa1K in range(len(axsbpdckhGP127u5wEgnZtV4LWvzli[0:-1])):
			if axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K]+'=' in Lo2zu1PTAB6: II4s1CdgcbN6BSvWPnHtz = axsbpdckhGP127u5wEgnZtV4LWvzli[xX6zt5oS08TO29CUhYJa1K+1]
		T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+II4s1CdgcbN6BSvWPnHtz+'=0'
		fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f.strip('&')+'___'+g7jQ4ZX1quCJ.strip('&')
		AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'all')
		BfjcMoqOsmdUvZVCHWIyQKi = url+'?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
	elif type=='FILTERS':
		jjG4QBW3iLf90w7eqhXY = UOWRnGaFuL(Lo2zu1PTAB6,'modified_values')
		jjG4QBW3iLf90w7eqhXY = OOFEmwq2GkTz93WXy1Nj(jjG4QBW3iLf90w7eqhXY)
		if Jv2yebcHLo5GCrXZlw!=NdKhAS6MXVEORLTwob92pxlZ: Jv2yebcHLo5GCrXZlw = UOWRnGaFuL(Jv2yebcHLo5GCrXZlw,'all')
		if Jv2yebcHLo5GCrXZlw==NdKhAS6MXVEORLTwob92pxlZ: BfjcMoqOsmdUvZVCHWIyQKi = url
		else: BfjcMoqOsmdUvZVCHWIyQKi = url+'?'+Jv2yebcHLo5GCrXZlw
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'أظهار قائمة الفيديو التي تم اختيارها',BfjcMoqOsmdUvZVCHWIyQKi,241,NdKhAS6MXVEORLTwob92pxlZ,'1')
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+' [[   '+jjG4QBW3iLf90w7eqhXY+'   ]]',BfjcMoqOsmdUvZVCHWIyQKi,241,NdKhAS6MXVEORLTwob92pxlZ,'1')
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	LMKFcEkU1Q7R80yt4OsgvwxbfP = NNOlox5zCj0XvqkAiraH8pLGbe4g(OewIv05xGhKQpFf,url,NdKhAS6MXVEORLTwob92pxlZ,headers,True,'AKWAM-FILTERS_MENU-1st')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<form id(.*?)</form>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	Hk9cy1IL0PXCw3OgYE5nr = YYqECUofyi7wFrW.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	dict = {}
	for zZ0VrYRv6m8,name,AAMHoYxRCmt2D6ph89W in Hk9cy1IL0PXCw3OgYE5nr:
		items = YYqECUofyi7wFrW.findall('<option(.*?)>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if '=' not in BfjcMoqOsmdUvZVCHWIyQKi: BfjcMoqOsmdUvZVCHWIyQKi = url
		if type=='CATEGORIES':
			if II4s1CdgcbN6BSvWPnHtz!=zZ0VrYRv6m8: continue
			elif len(items)<=1:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: hGJKk8tAiC3XFufEpqavQWmwTHdL(BfjcMoqOsmdUvZVCHWIyQKi)
				else: Xi3ZCagjOpSAvB1rlnE6(BfjcMoqOsmdUvZVCHWIyQKi,'CATEGORIES___'+fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
				return
			else:
				if zZ0VrYRv6m8==axsbpdckhGP127u5wEgnZtV4LWvzli[-1]: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,241,NdKhAS6MXVEORLTwob92pxlZ,'1')
				else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع',BfjcMoqOsmdUvZVCHWIyQKi,245,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		elif type=='FILTERS':
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'=0'
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'=0'
			fjEQgcz4HNRKeqDs63ASZM9Bxnpo = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'الجميع : '+name,BfjcMoqOsmdUvZVCHWIyQKi,244,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,fjEQgcz4HNRKeqDs63ASZM9Bxnpo)
		dict[zZ0VrYRv6m8] = {}
		for K6KbZDHncNizQgl1fr59XV0,X9dRM31pz6y in items:
			if X9dRM31pz6y in Kdr54yMqbjTSX7piWREfPtZ2em: continue
			if 'value' not in K6KbZDHncNizQgl1fr59XV0: K6KbZDHncNizQgl1fr59XV0 = X9dRM31pz6y
			else: K6KbZDHncNizQgl1fr59XV0 = YYqECUofyi7wFrW.findall('"(.*?)"',K6KbZDHncNizQgl1fr59XV0,YYqECUofyi7wFrW.DOTALL)[0]
			dict[zZ0VrYRv6m8][K6KbZDHncNizQgl1fr59XV0] = X9dRM31pz6y
			T2XisBtK7JIyA0k3f = Lo2zu1PTAB6+'&'+zZ0VrYRv6m8+'='+X9dRM31pz6y
			g7jQ4ZX1quCJ = Jv2yebcHLo5GCrXZlw+'&'+zZ0VrYRv6m8+'='+K6KbZDHncNizQgl1fr59XV0
			PnyBREZtmaUbVJGTM32 = T2XisBtK7JIyA0k3f+'___'+g7jQ4ZX1quCJ
			title = X9dRM31pz6y+' : '#+dict[zZ0VrYRv6m8]['0']
			title = X9dRM31pz6y+' : '+name
			if type=='FILTERS': ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,244,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
			elif type=='CATEGORIES' and axsbpdckhGP127u5wEgnZtV4LWvzli[-2]+'=' in Lo2zu1PTAB6:
				AeDYSUtj2L3i8GZgTmx6sW9kHaM = UOWRnGaFuL(g7jQ4ZX1quCJ,'all')
				Afey3cL4ojzg = url+'?'+AeDYSUtj2L3i8GZgTmx6sW9kHaM
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,Afey3cL4ojzg,241,NdKhAS6MXVEORLTwob92pxlZ,'1')
			else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,245,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,PnyBREZtmaUbVJGTM32)
	return
def UOWRnGaFuL(TGKlgc10fn,mode):
	TGKlgc10fn = TGKlgc10fn.strip('&')
	qZBlhLHkP5yp = {}
	if '=' in TGKlgc10fn:
		items = TGKlgc10fn.split('&')
		for rMOG2USkPesYZD9KNAVqpc in items:
			y6D8aMBhHnCQbLujWtlv,K6KbZDHncNizQgl1fr59XV0 = rMOG2USkPesYZD9KNAVqpc.split('=')
			qZBlhLHkP5yp[y6D8aMBhHnCQbLujWtlv] = K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = NdKhAS6MXVEORLTwob92pxlZ
	dW42o7vIOrS9wu = ['section','category','rating','year','language','formats','quality']
	for key in dW42o7vIOrS9wu:
		if key in list(qZBlhLHkP5yp.keys()): K6KbZDHncNizQgl1fr59XV0 = qZBlhLHkP5yp[key]
		else: K6KbZDHncNizQgl1fr59XV0 = '0'
		if mode=='modified_values' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+' + '+K6KbZDHncNizQgl1fr59XV0
		elif mode=='modified_filters' and K6KbZDHncNizQgl1fr59XV0!='0': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
		elif mode=='all': LaGtUDiK2xnfz = LaGtUDiK2xnfz+'&'+key+'='+K6KbZDHncNizQgl1fr59XV0
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip(' + ')
	LaGtUDiK2xnfz = LaGtUDiK2xnfz.strip('&')
	return LaGtUDiK2xnfz
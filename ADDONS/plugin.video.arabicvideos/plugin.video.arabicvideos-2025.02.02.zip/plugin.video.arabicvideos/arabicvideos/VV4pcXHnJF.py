# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'FASELHD2'
headers = {'User-Agent':NdKhAS6MXVEORLTwob92pxlZ}
LJfTAEQPv9h4BXdwUp = '_FH2_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['wwe']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==590: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==591: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==592: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==593: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = X15CPKmVLqpi9hdvBsjZOY2D3Q(url,text)
	elif mode==599: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	REGxsWAoilB7dCFNgMhz0V98bcm = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',REGxsWAoilB7dCFNgMhz0V98bcm,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD2-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',REGxsWAoilB7dCFNgMhz0V98bcm,599,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'المميزة',REGxsWAoilB7dCFNgMhz0V98bcm,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured1')
	items = YYqECUofyi7wFrW.findall('<strong>(.*?)</strong>.*?href="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	for title,zehVcU893FC6LEd1Aij in items:
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details1')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('main-menu"(.*?)header-social',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		p58bkCrGnwJFDs1i9Ut036hgLVdl2y = YYqECUofyi7wFrW.findall('<li (.*?)</li>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for yzApRd2Dnes07XUZTM in p58bkCrGnwJFDs1i9Ut036hgLVdl2y:
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',yzApRd2Dnes07XUZTM,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
				ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details2')
	return LMKFcEkU1Q7R80yt4OsgvwxbfP
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD2-TITLES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	wqTpPdvUhA7Yzcjxr20LQ3HXMg4Nub = 0
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"archive-slider(.*?)<h4>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1: zyoNRs5F72Bkr0JYfGh6PULju4bO = gcBxGPatZIzQ1[0]
	else: zyoNRs5F72Bkr0JYfGh6PULju4bO = NdKhAS6MXVEORLTwob92pxlZ
	if type=='featured1':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"slider-carousel"(.*?)</container>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		QQJRhamjz0nYHV,DDviHT4pFVhgwaL,oDhlaxn0EqyYikcHrmZBN8uv = zip(*items)
		items = zip(oDhlaxn0EqyYikcHrmZBN8uv,QQJRhamjz0nYHV,DDviHT4pFVhgwaL)
	elif type=='featured2':
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',zyoNRs5F72Bkr0JYfGh6PULju4bO,YYqECUofyi7wFrW.DOTALL)
	elif type=='filters':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [LMKFcEkU1Q7R80yt4OsgvwxbfP.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in zyoNRs5F72Bkr0JYfGh6PULju4bO:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<h4>(.*?)</h4>(.*?)</container>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'مميزة',url,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured2')
		title = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0][0]
		ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,url,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details3')
		return
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<h4>(.*?)</h4>(.*?)</container>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		title,AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	zIDPZSNn1OuweLHvmMKb6d = []
	for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
		if any(K6KbZDHncNizQgl1fr59XV0 in title.lower() for K6KbZDHncNizQgl1fr59XV0 in Kdr54yMqbjTSX7piWREfPtZ2em): continue
		title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
		title = Pr4ubLdO7Z1qjKFaMIy3H(title)
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة).\d+',title,YYqECUofyi7wFrW.DOTALL)
		if '/movseries/' in zehVcU893FC6LEd1Aij:
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,591,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z and type==NdKhAS6MXVEORLTwob92pxlZ:
			title = '_MOD_'+N1VjdbtuO3z[0][0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,593,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		elif any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,592,TTuPH708dUNnjlG3oQpkZsi)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,593,TTuPH708dUNnjlG3oQpkZsi)
	if type=='filters':
		aJNqiPEbZKIM5y6txrwTRj20dGHU = YYqECUofyi7wFrW.findall('"more_button_page":(.*?),',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if aJNqiPEbZKIM5y6txrwTRj20dGHU:
			count = aJNqiPEbZKIM5y6txrwTRj20dGHU[0]
			zehVcU893FC6LEd1Aij = url+'/offset/'+count
			ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة أخرى',zehVcU893FC6LEd1Aij,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'filters')
	elif 'details' in type:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('class="pagination(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = 'صفحة '+Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,591,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'details4')
	return
def X15CPKmVLqpi9hdvBsjZOY2D3Q(url,type=NdKhAS6MXVEORLTwob92pxlZ):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD2-SEASONS_EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ttVUWKLHayoTMnGwOjQqI = False
	if not type:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<seasons(.*?)</seasons>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if len(items)>1:
				REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
				ttVUWKLHayoTMnGwOjQqI = True
				for zehVcU893FC6LEd1Aij,TTuPH708dUNnjlG3oQpkZsi,title in items:
					title = Pr4ubLdO7Z1qjKFaMIy3H(title)
					ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,593,TTuPH708dUNnjlG3oQpkZsi,NdKhAS6MXVEORLTwob92pxlZ,'episodes')
	if type=='episodes' or not ttVUWKLHayoTMnGwOjQqI:
		k1ChwgueU5nbDX6K0BOEGx = YYqECUofyi7wFrW.findall('<bkز*?image:url\((.*?)\)"></bk>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if k1ChwgueU5nbDX6K0BOEGx: TTuPH708dUNnjlG3oQpkZsi = k1ChwgueU5nbDX6K0BOEGx[0]
		else: TTuPH708dUNnjlG3oQpkZsi = NdKhAS6MXVEORLTwob92pxlZ
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<all-episodes(.*?)</all-episodes>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				title = title.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,592,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	Pj8lY4doOfxiFMuNLhv3tnp,UU4f5PJzKIg,iQ9bCrJLy8zUnXA1Hqk = [],[],[]
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(NXpO8DrVmeE,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'FASELHD2-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZnxuHry0Apj1 = YYqECUofyi7wFrW.findall('العمر :.*?<strong">(.*?)</strong>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if ZnxuHry0Apj1 and ppU5ihvWXsaGPV1t4JlIMA8x(yNIDEX5hU4G769,url,ZnxuHry0Apj1): return
	zehVcU893FC6LEd1Aij = YYqECUofyi7wFrW.findall('<iframe src="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if zehVcU893FC6LEd1Aij:
		zehVcU893FC6LEd1Aij = zehVcU893FC6LEd1Aij[0]
		Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named=__embed')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<slice-title(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('data-url="(.*?)".*?</i>(.*?)</li>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			name = name.strip(Vwgflszp4WRA93kx6hvdua21HX5cOb)
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+name+'__watch')
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('<downloads(.*?)</downloads>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?</div>(.*?)</div>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,name in items:
			Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+'?named='+name+'__download')
	for raU0zgHfjWDip2dXFvKYJM3bxOSeN in Pj8lY4doOfxiFMuNLhv3tnp:
		zehVcU893FC6LEd1Aij,name = raU0zgHfjWDip2dXFvKYJM3bxOSeN.split('?named')
		if zehVcU893FC6LEd1Aij not in UU4f5PJzKIg:
			UU4f5PJzKIg.append(zehVcU893FC6LEd1Aij)
			iQ9bCrJLy8zUnXA1Hqk.append(raU0zgHfjWDip2dXFvKYJM3bxOSeN)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(iQ9bCrJLy8zUnXA1Hqk,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	REGxsWAoilB7dCFNgMhz0V98bcm = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN
	url = REGxsWAoilB7dCFNgMhz0V98bcm+'/?s='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'details5')
	return
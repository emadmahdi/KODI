# -*- coding: utf-8 -*-
import sys as hnu0oKAvsG4PaX6yxiTj2eftY
LkOBGtHwfzpgTqE4lKVuoCy0bQ3 = hnu0oKAvsG4PaX6yxiTj2eftY.version_info [0] == 2
GGpY93jckybWRI185ZxJr6zqf7LPE = 2048
Ro16pVvjb9I8OGwq2cDFSedm = 7
def rG7SuqQvVnEY1efcWbpUBhgJ8iF (zzJM4GNw0dgbLXWTR):
	global XVibeH2ptQMgmqD5YosAaNUFWEZ
	eN19YUxjhAn = ord (zzJM4GNw0dgbLXWTR [-1])
	mouRIMJlVLfA34ZGg = zzJM4GNw0dgbLXWTR [:-1]
	OrafMW25dZ3PgR9wUxikToq6BV17uA = eN19YUxjhAn % len (mouRIMJlVLfA34ZGg)
	V0Gq1mpMYCebhl8UZ4ri = mouRIMJlVLfA34ZGg [:OrafMW25dZ3PgR9wUxikToq6BV17uA] + mouRIMJlVLfA34ZGg [OrafMW25dZ3PgR9wUxikToq6BV17uA:]
	if LkOBGtHwfzpgTqE4lKVuoCy0bQ3:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = unicode () .join ([unichr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	else:
		YnFlTbGRJ6HLjVcXdf0QZrUp4 = str () .join ([chr (ord (hhWgA16IKNcZG0MuivUELx5HF2Y) - GGpY93jckybWRI185ZxJr6zqf7LPE - (ZXtGM4YL3JAq6WwURpdxscN8vI + eN19YUxjhAn) % Ro16pVvjb9I8OGwq2cDFSedm) for ZXtGM4YL3JAq6WwURpdxscN8vI, hhWgA16IKNcZG0MuivUELx5HF2Y in enumerate (V0Gq1mpMYCebhl8UZ4ri)])
	return eval (YnFlTbGRJ6HLjVcXdf0QZrUp4)
hCm2fnEXs6Zt,vju3SZDWL4ENYelmBOzUqrogp2,wP4kpvXoDHq3hs7TFLyr2COn8=rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF,rG7SuqQvVnEY1efcWbpUBhgJ8iF
fOc18oTm5hsdD4pVZQj,R3lezw8h407ZvrAFxT,WiIt2NUHAqQ5wrud3TgkCRDj7L=wP4kpvXoDHq3hs7TFLyr2COn8,vju3SZDWL4ENYelmBOzUqrogp2,hCm2fnEXs6Zt
V0VZk9763fusTReHFo4,JGwsL21ZRlqSrWxEmF,rNyT0edugn=WiIt2NUHAqQ5wrud3TgkCRDj7L,R3lezw8h407ZvrAFxT,fOc18oTm5hsdD4pVZQj
OOkmZiVcfqlEurM1dHGb,LtGoXlQ2IYxqTJRySE6udfW98,kb2icmDGVUZfW1OFz7sv=rNyT0edugn,JGwsL21ZRlqSrWxEmF,V0VZk9763fusTReHFo4
HVmIrFwau90jQsgiWzExk,IlL8ZnX74Yvep,pnHgvFOCBZzc08yULQJGIqw9bf=kb2icmDGVUZfW1OFz7sv,LtGoXlQ2IYxqTJRySE6udfW98,OOkmZiVcfqlEurM1dHGb
ggWEFaH6fcVIO9SzRZLiuxo7P,xY4icgQUj6mPVs73CTKu,Hlp3z0APt1GR4kMYK5xST=pnHgvFOCBZzc08yULQJGIqw9bf,IlL8ZnX74Yvep,HVmIrFwau90jQsgiWzExk
QQHFtjcaR2VpnSyTIv,Tzx81Wb0RZC4ID5AyiU2,lNTJCZeBicWEz0Mg=Hlp3z0APt1GR4kMYK5xST,xY4icgQUj6mPVs73CTKu,ggWEFaH6fcVIO9SzRZLiuxo7P
NeU6uRGpECkvMV5jf,lrtFSogC8Nh9,YJpWv4QzC7sx8INVPukeZiOD03K=lNTJCZeBicWEz0Mg,Tzx81Wb0RZC4ID5AyiU2,QQHFtjcaR2VpnSyTIv
OblVzEoPfRGCamyFkJUc34wLTI8Aju,HHvYL68lbJVZWM7tQEzSex3,gniNItGL6bKwpEW=YJpWv4QzC7sx8INVPukeZiOD03K,lrtFSogC8Nh9,NeU6uRGpECkvMV5jf
rtUJso6d7iaNf1yWejxnc5DEXFg,PzIpQnUXxRwNCivDhdakWTE,hEPxFf1Tdo7tADqwcupWJSyU6KHY0=gniNItGL6bKwpEW,HHvYL68lbJVZWM7tQEzSex3,OblVzEoPfRGCamyFkJUc34wLTI8Aju
eGW7cI6aQhr0,lRP6GTaZJA1Xw3egLM4,NOrchaEV1iIZ87Uzlwgum=hEPxFf1Tdo7tADqwcupWJSyU6KHY0,PzIpQnUXxRwNCivDhdakWTE,rtUJso6d7iaNf1yWejxnc5DEXFg
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = hCm2fnEXs6Zt(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
LJfTAEQPv9h4BXdwUp = OOkmZiVcfqlEurM1dHGb(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
o8CfwIsWvO0QJqym1bZKTl = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ywv5SRh6Nxj,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
AQVfaxUPpgh2n9X = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(ywv5SRh6Nxj,R3lezw8h407ZvrAFxT(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
mNRzob0rd7l8vXUOTI9 = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(YbDTMedqwUi9r4Jax,R3lezw8h407ZvrAFxT(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),lNTJCZeBicWEz0Mg(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
CpnPfINcmVd3aS1sWHtULwYkT = tMC6foua7UF2WhVrv09i5qJsK
ajC5qxpRugwfb1 = HVmIrFwau90jQsgiWzExk(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
KT4AZroL6J9jN = kb2icmDGVUZfW1OFz7sv(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
O1VXxjFGvDeC = JGwsL21ZRlqSrWxEmF(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
fhLwkVbzievJ = NOrchaEV1iIZ87Uzlwgum(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
sDN1Yc7OaK = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
ebEoW9ntzVlci6NI = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def QGLoruqnmiAel7Op(pPrvqm3tjuXLTgw1):
	if   pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠼࠺࠰ࡸ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = otm7ikp5d203jfA4()
	elif pPrvqm3tjuXLTgw1==HHvYL68lbJVZWM7tQEzSex3(u"࠽࠴࠲ࡹ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(o8CfwIsWvO0QJqym1bZKTl,k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==YJpWv4QzC7sx8INVPukeZiOD03K(u"࠷࠵࠴ࡺ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(AQVfaxUPpgh2n9X,k6apiPAlLKM1ed8J42RjHh0o,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==kb2icmDGVUZfW1OFz7sv(u"࠸࠶࠶ࡻ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(mNRzob0rd7l8vXUOTI9,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==HHvYL68lbJVZWM7tQEzSex3(u"࠹࠷࠸ࡼ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = lT6SgxvdkPrIWsu(CpnPfINcmVd3aS1sWHtULwYkT,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==R3lezw8h407ZvrAFxT(u"࠺࠸࠺ࡽ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = TNMCblnVwW1s2ZUiJXO5x3ycAF(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==QQHFtjcaR2VpnSyTIv(u"࠻࠺࠶ࡾ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = i3iRVSxbZqWf5()
	elif pPrvqm3tjuXLTgw1==rNyT0edugn(u"࠼࠻࠱ࡿ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(ajC5qxpRugwfb1,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠽࠵࠳ࢀ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(KT4AZroL6J9jN,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==xY4icgQUj6mPVs73CTKu(u"࠷࠶࠵ࢁ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(O1VXxjFGvDeC,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==xY4icgQUj6mPVs73CTKu(u"࠸࠷࠷ࢂ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(fhLwkVbzievJ,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==Tzx81Wb0RZC4ID5AyiU2(u"࠹࠸࠹ࢃ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(sDN1Yc7OaK,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==HVmIrFwau90jQsgiWzExk(u"࠺࠹࠻ࢄ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vWN2YePRikAXEFO6dQ8CT51bz(ebEoW9ntzVlci6NI,f4vncKMRlXG9s,k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==Tzx81Wb0RZC4ID5AyiU2(u"࠻࠺࠽ࢅ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = FFIqmOCEnJl7RiDKvh6LycWQZN1Ao(k6apiPAlLKM1ed8J42RjHh0o)
	elif pPrvqm3tjuXLTgw1==V0VZk9763fusTReHFo4(u"࠼࠻࠸ࢆ"): UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LBoH93G85NW()
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = f4vncKMRlXG9s
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def otm7ikp5d203jfA4():
	cLZwr3eADx0PFUtiESb,zzZtQG6D8bTgfkcLUh9m4 = HmeyCrFTsnX7h6GYv8cl(o8CfwIsWvO0QJqym1bZKTl)
	SgfInD2R1akrux0B3t,zGfnKXtEIp782Bl3SurU = HmeyCrFTsnX7h6GYv8cl(AQVfaxUPpgh2n9X)
	zNUm9YG4vp738tPCXa5Q,wl3oUNf9pPFnVRQYyWBkh4 = HmeyCrFTsnX7h6GYv8cl(mNRzob0rd7l8vXUOTI9)
	DbvfnPU4Kk,fNtlaTF4HVAcDOW = TGNwJtqvjZCnUhHKEXoep8xBbk(CpnPfINcmVd3aS1sWHtULwYkT)
	DbvfnPU4Kk -= V0VZk9763fusTReHFo4(u"࠹࠶࠹࠸࠷ࢇ")
	fNtlaTF4HVAcDOW -= kb2icmDGVUZfW1OFz7sv(u"࠱࢈")
	YCzrbTZDI8HA1XJgS0Lpum = HVmIrFwau90jQsgiWzExk(u"ࠩࠣࠬࠬࠌ")+T9238oYbFOLmWXsd5M4JnrE(cLZwr3eADx0PFUtiESb)+Tzx81Wb0RZC4ID5AyiU2(u"ࠪࠤ࠲ࠦࠧࠍ")+str(zzZtQG6D8bTgfkcLUh9m4)+lNTJCZeBicWEz0Mg(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	RM17uFVste3pJLBhjcn = Hlp3z0APt1GR4kMYK5xST(u"ࠬࠦࠨࠨࠏ")+T9238oYbFOLmWXsd5M4JnrE(SgfInD2R1akrux0B3t)+IlL8ZnX74Yvep(u"࠭ࠠ࠮ࠢࠪࠐ")+str(zGfnKXtEIp782Bl3SurU)+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	Mh2DG8WpkNXSO1arKLi = Tzx81Wb0RZC4ID5AyiU2(u"ࠨࠢࠫࠫࠒ")+T9238oYbFOLmWXsd5M4JnrE(zNUm9YG4vp738tPCXa5Q)+fOc18oTm5hsdD4pVZQj(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(wl3oUNf9pPFnVRQYyWBkh4)+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	x2yfZGRC8F7 = lRP6GTaZJA1Xw3egLM4(u"ࠫࠥ࠮ࠧࠕ")+T9238oYbFOLmWXsd5M4JnrE(DbvfnPU4Kk)+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠬ࠯ࠧࠖ")
	AtxSM2L7PCWNqlf4 = cLZwr3eADx0PFUtiESb+SgfInD2R1akrux0B3t+zNUm9YG4vp738tPCXa5Q+DbvfnPU4Kk
	Gg8apTf0hM3 = zzZtQG6D8bTgfkcLUh9m4+zGfnKXtEIp782Bl3SurU+wl3oUNf9pPFnVRQYyWBkh4+fNtlaTF4HVAcDOW
	ui7N5YGR9KdslpEbQkVTwFqDgI = HHvYL68lbJVZWM7tQEzSex3(u"࠭ࠠࠩࠩࠗ")+T9238oYbFOLmWXsd5M4JnrE(AtxSM2L7PCWNqlf4)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧࠡ࠯ࠣࠫ࠘")+str(Gg8apTf0hM3)+OOkmZiVcfqlEurM1dHGb(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	ZI51XvE8YatWCmNdrp(eGW7cI6aQhr0(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),LJfTAEQPv9h4BXdwUp+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,lNTJCZeBicWEz0Mg(u"࠸࠶࠸ࢉ"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),Whef0cxB2iR93SC5IwUtk+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠻࠼࠽࠾ࢊ"))
	ZI51XvE8YatWCmNdrp(eGW7cI6aQhr0(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),LJfTAEQPv9h4BXdwUp+lRP6GTaZJA1Xw3egLM4(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+YCzrbTZDI8HA1XJgS0Lpum,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠺࠸࠶ࢋ"))
	ZI51XvE8YatWCmNdrp(HHvYL68lbJVZWM7tQEzSex3(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),LJfTAEQPv9h4BXdwUp+xY4icgQUj6mPVs73CTKu(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+RM17uFVste3pJLBhjcn,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"࠻࠹࠸ࢌ"))
	ZI51XvE8YatWCmNdrp(lRP6GTaZJA1Xw3egLM4(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),LJfTAEQPv9h4BXdwUp+ggWEFaH6fcVIO9SzRZLiuxo7P(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+Mh2DG8WpkNXSO1arKLi,NdKhAS6MXVEORLTwob92pxlZ,QQHFtjcaR2VpnSyTIv(u"࠼࠺࠳ࢍ"))
	ZI51XvE8YatWCmNdrp(eGW7cI6aQhr0(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),LJfTAEQPv9h4BXdwUp+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+x2yfZGRC8F7,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"࠽࠴࠵ࢎ"))
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(lrtFSogC8Nh9(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),NdKhAS6MXVEORLTwob92pxlZ)
	return
def i3iRVSxbZqWf5():
	S5KCZPh6oLzYEGd2k7AsnRD = k6apiPAlLKM1ed8J42RjHh0o if PzIpQnUXxRwNCivDhdakWTE(u"ࠨ࠱ࠪࠧ") in YbDTMedqwUi9r4Jax else f4vncKMRlXG9s
	if not S5KCZPh6oLzYEGd2k7AsnRD:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),LtGoXlQ2IYxqTJRySE6udfW98(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	xmYofc7HByzQqEh81L2b6V = ptbWxl0eDEwc5PQaKR3XHzn4fF.getSetting(pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not xmYofc7HByzQqEh81L2b6V: LBoH93G85NW()
	cLZwr3eADx0PFUtiESb,zzZtQG6D8bTgfkcLUh9m4 = HmeyCrFTsnX7h6GYv8cl(ajC5qxpRugwfb1)
	SgfInD2R1akrux0B3t,zGfnKXtEIp782Bl3SurU = HmeyCrFTsnX7h6GYv8cl(KT4AZroL6J9jN)
	zNUm9YG4vp738tPCXa5Q,wl3oUNf9pPFnVRQYyWBkh4 = HmeyCrFTsnX7h6GYv8cl(O1VXxjFGvDeC)
	DbvfnPU4Kk,fNtlaTF4HVAcDOW = HmeyCrFTsnX7h6GYv8cl(fhLwkVbzievJ)
	kBO5eIzcr1,AABwHxqQjc = HmeyCrFTsnX7h6GYv8cl(sDN1Yc7OaK)
	hXzsbj3f6DSpdRq,t4nSLCRy6G8VQD50JEaZu193Pvm = HmeyCrFTsnX7h6GYv8cl(ebEoW9ntzVlci6NI)
	YCzrbTZDI8HA1XJgS0Lpum = OOkmZiVcfqlEurM1dHGb(u"ࠬࠦࠨࠨࠫ")+T9238oYbFOLmWXsd5M4JnrE(cLZwr3eADx0PFUtiESb)+NeU6uRGpECkvMV5jf(u"࠭ࠠ࠮ࠢࠪࠬ")+str(zzZtQG6D8bTgfkcLUh9m4)+hCm2fnEXs6Zt(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	RM17uFVste3pJLBhjcn = rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࠢࠫࠫ࠮")+T9238oYbFOLmWXsd5M4JnrE(SgfInD2R1akrux0B3t)+fOc18oTm5hsdD4pVZQj(u"ࠩࠣ࠱ࠥ࠭࠯")+str(zGfnKXtEIp782Bl3SurU)+lrtFSogC8Nh9(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	Mh2DG8WpkNXSO1arKLi = PzIpQnUXxRwNCivDhdakWTE(u"ࠫࠥ࠮ࠧ࠱")+T9238oYbFOLmWXsd5M4JnrE(zNUm9YG4vp738tPCXa5Q)+JGwsL21ZRlqSrWxEmF(u"ࠬࠦ࠭ࠡࠩ࠲")+str(wl3oUNf9pPFnVRQYyWBkh4)+fOc18oTm5hsdD4pVZQj(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	x2yfZGRC8F7 = QQHFtjcaR2VpnSyTIv(u"ࠧࠡࠪࠪ࠴")+T9238oYbFOLmWXsd5M4JnrE(DbvfnPU4Kk)+rtUJso6d7iaNf1yWejxnc5DEXFg(u"ࠨࠢ࠰ࠤࠬ࠵")+str(fNtlaTF4HVAcDOW)+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	gSb5BJePv7w9 = OOkmZiVcfqlEurM1dHGb(u"ࠪࠤ࠭࠭࠷")+T9238oYbFOLmWXsd5M4JnrE(kBO5eIzcr1)+LtGoXlQ2IYxqTJRySE6udfW98(u"ࠫࠥ࠳ࠠࠨ࠸")+str(AABwHxqQjc)+hCm2fnEXs6Zt(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	h21cZlOC8EKqmWSvnQBL4o = gniNItGL6bKwpEW(u"࠭ࠠࠩࠩ࠺")+T9238oYbFOLmWXsd5M4JnrE(hXzsbj3f6DSpdRq)+vju3SZDWL4ENYelmBOzUqrogp2(u"ࠧࠡ࠯ࠣࠫ࠻")+str(t4nSLCRy6G8VQD50JEaZu193Pvm)+Hlp3z0APt1GR4kMYK5xST(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	AtxSM2L7PCWNqlf4 = cLZwr3eADx0PFUtiESb+SgfInD2R1akrux0B3t+zNUm9YG4vp738tPCXa5Q+DbvfnPU4Kk+kBO5eIzcr1+hXzsbj3f6DSpdRq
	Gg8apTf0hM3 = zzZtQG6D8bTgfkcLUh9m4+zGfnKXtEIp782Bl3SurU+wl3oUNf9pPFnVRQYyWBkh4+fNtlaTF4HVAcDOW+AABwHxqQjc+t4nSLCRy6G8VQD50JEaZu193Pvm
	ui7N5YGR9KdslpEbQkVTwFqDgI = hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࠣࠬࠬ࠽")+T9238oYbFOLmWXsd5M4JnrE(AtxSM2L7PCWNqlf4)+Hlp3z0APt1GR4kMYK5xST(u"ࠪࠤ࠲ࠦࠧ࠾")+str(Gg8apTf0hM3)+V0VZk9763fusTReHFo4(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	ZI51XvE8YatWCmNdrp(Tzx81Wb0RZC4ID5AyiU2(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),LJfTAEQPv9h4BXdwUp+ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠷࠶࠺࢏"))
	ZI51XvE8YatWCmNdrp(wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),LJfTAEQPv9h4BXdwUp+Tzx81Wb0RZC4ID5AyiU2(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+ui7N5YGR9KdslpEbQkVTwFqDgI,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠸࠷࠺࢐"))
	ZI51XvE8YatWCmNdrp(lrtFSogC8Nh9(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),Whef0cxB2iR93SC5IwUtk+pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,IlL8ZnX74Yvep(u"࠻࠼࠽࠾࢑"))
	ZI51XvE8YatWCmNdrp(R3lezw8h407ZvrAFxT(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),LJfTAEQPv9h4BXdwUp+lNTJCZeBicWEz0Mg(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+YCzrbTZDI8HA1XJgS0Lpum,NdKhAS6MXVEORLTwob92pxlZ,hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"࠺࠹࠶࢒"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),LJfTAEQPv9h4BXdwUp+JGwsL21ZRlqSrWxEmF(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+RM17uFVste3pJLBhjcn,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"࠻࠺࠸࢓"))
	ZI51XvE8YatWCmNdrp(R3lezw8h407ZvrAFxT(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),LJfTAEQPv9h4BXdwUp+Hlp3z0APt1GR4kMYK5xST(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+Mh2DG8WpkNXSO1arKLi,NdKhAS6MXVEORLTwob92pxlZ,NeU6uRGpECkvMV5jf(u"࠼࠻࠳࢔"))
	ZI51XvE8YatWCmNdrp(hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),LJfTAEQPv9h4BXdwUp+PzIpQnUXxRwNCivDhdakWTE(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+x2yfZGRC8F7,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠽࠵࠵࢕"))
	ZI51XvE8YatWCmNdrp(vju3SZDWL4ENYelmBOzUqrogp2(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),LJfTAEQPv9h4BXdwUp+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+gSb5BJePv7w9,NdKhAS6MXVEORLTwob92pxlZ,JGwsL21ZRlqSrWxEmF(u"࠷࠶࠷࢖"))
	ZI51XvE8YatWCmNdrp(WiIt2NUHAqQ5wrud3TgkCRDj7L(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),LJfTAEQPv9h4BXdwUp+OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+h21cZlOC8EKqmWSvnQBL4o,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠸࠷࠹ࢗ"))
	ptbWxl0eDEwc5PQaKR3XHzn4fF.setSetting(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),NdKhAS6MXVEORLTwob92pxlZ)
	return
def LBoH93G85NW():
	TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),NOrchaEV1iIZ87Uzlwgum(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if TT32BcvomhVewpgMSWkEb46y7xqO==-PzIpQnUXxRwNCivDhdakWTE(u"࠳࢘"): return
	if TT32BcvomhVewpgMSWkEb46y7xqO:
		import subprocess as AkxWe21r8J4R
		try:
			AkxWe21r8J4R.Popen(R3lezw8h407ZvrAFxT(u"ࠬࡹࡵࠨࡕ"))
			HCRaU6zpXNZ = k6apiPAlLKM1ed8J42RjHh0o
		except: HCRaU6zpXNZ = f4vncKMRlXG9s
		if HCRaU6zpXNZ:
			qAKpHEX1fwU7Pz = ajC5qxpRugwfb1+Vwgflszp4WRA93kx6hvdua21HX5cOb+KT4AZroL6J9jN+Vwgflszp4WRA93kx6hvdua21HX5cOb+O1VXxjFGvDeC+Vwgflszp4WRA93kx6hvdua21HX5cOb+fhLwkVbzievJ+Vwgflszp4WRA93kx6hvdua21HX5cOb+sDN1Yc7OaK+Vwgflszp4WRA93kx6hvdua21HX5cOb+ebEoW9ntzVlci6NI
			cj0Zp3Dv7RLyexGwfJ = AkxWe21r8J4R.Popen(xY4icgQUj6mPVs73CTKu(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+qAKpHEX1fwU7Pz+YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠧࠣࠩࡗ"),shell=k6apiPAlLKM1ed8J42RjHh0o,stdin=AkxWe21r8J4R.PIPE,stdout=AkxWe21r8J4R.PIPE,stderr=AkxWe21r8J4R.PIPE)
			ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,HHvYL68lbJVZWM7tQEzSex3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),NeU6uRGpECkvMV5jf(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			MIjcStaDWnv(f4vncKMRlXG9s)
		else: ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,gniNItGL6bKwpEW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),wP4kpvXoDHq3hs7TFLyr2COn8(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def T9238oYbFOLmWXsd5M4JnrE(AtxSM2L7PCWNqlf4):
	for lPVSU9krH8qwJGs2ahLnpTcti0xzZ in [QQHFtjcaR2VpnSyTIv(u"ࠬࡈࠧ࡜"),lRP6GTaZJA1Xw3egLM4(u"࠭ࡋࡃࠩ࡝"),lRP6GTaZJA1Xw3egLM4(u"ࠧࡎࡄࠪ࡞"),YJpWv4QzC7sx8INVPukeZiOD03K(u"ࠨࡉࡅࠫ࡟"),hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩࡗࡆࠬࡠ")]:
		if AtxSM2L7PCWNqlf4<pnHgvFOCBZzc08yULQJGIqw9bf(u"࠴࠴࠷࠺࢙"): break
		else: AtxSM2L7PCWNqlf4 /= OOkmZiVcfqlEurM1dHGb(u"࠵࠵࠸࠴࠯࠲࢚")
	ui7N5YGR9KdslpEbQkVTwFqDgI = pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(AtxSM2L7PCWNqlf4,lPVSU9krH8qwJGs2ahLnpTcti0xzZ)
	return ui7N5YGR9KdslpEbQkVTwFqDgI
def HmeyCrFTsnX7h6GYv8cl(FpB420s78PRQZ=OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫ࠳࠭ࡢ")):
	global BTUWg2bCs1t0,v60FtfRxhwVKLCcO
	BTUWg2bCs1t0,v60FtfRxhwVKLCcO = ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵࢛"),ggWEFaH6fcVIO9SzRZLiuxo7P(u"࠵࢛")
	def SSTteZ8ydz(FpB420s78PRQZ):
		global BTUWg2bCs1t0,v60FtfRxhwVKLCcO
		if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.exists(FpB420s78PRQZ):
			if vju3SZDWL4ENYelmBOzUqrogp2(u"࠶࢜") and OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(IIPNcsCvQnOZk0yejJKl4BtgSrMw):
				for XYQwWZTKcjO2qRnr6mDafykH4gx in IIPNcsCvQnOZk0yejJKl4BtgSrMw.scandir(FpB420s78PRQZ):
					if XYQwWZTKcjO2qRnr6mDafykH4gx.is_dir(follow_symlinks=f4vncKMRlXG9s):
						SSTteZ8ydz(XYQwWZTKcjO2qRnr6mDafykH4gx.path)
					elif XYQwWZTKcjO2qRnr6mDafykH4gx.is_file(follow_symlinks=f4vncKMRlXG9s):
						BTUWg2bCs1t0 += XYQwWZTKcjO2qRnr6mDafykH4gx.stat().st_size
						v60FtfRxhwVKLCcO += fOc18oTm5hsdD4pVZQj(u"࠱࢝")
			else:
				for XYQwWZTKcjO2qRnr6mDafykH4gx in IIPNcsCvQnOZk0yejJKl4BtgSrMw.listdir(FpB420s78PRQZ):
					W4WjYuz3KxvOod56Uq9RbsyQD = IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.abspath(IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.join(FpB420s78PRQZ,XYQwWZTKcjO2qRnr6mDafykH4gx))
					if IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.isdir(W4WjYuz3KxvOod56Uq9RbsyQD):
						SSTteZ8ydz(W4WjYuz3KxvOod56Uq9RbsyQD)
					elif IIPNcsCvQnOZk0yejJKl4BtgSrMw.path.isfile(W4WjYuz3KxvOod56Uq9RbsyQD):
						AtxSM2L7PCWNqlf4,Gg8apTf0hM3 = TGNwJtqvjZCnUhHKEXoep8xBbk(W4WjYuz3KxvOod56Uq9RbsyQD)
						BTUWg2bCs1t0 += AtxSM2L7PCWNqlf4
						v60FtfRxhwVKLCcO += Gg8apTf0hM3
		return
	try: SSTteZ8ydz(FpB420s78PRQZ)
	except: pass
	return BTUWg2bCs1t0,v60FtfRxhwVKLCcO
def TNMCblnVwW1s2ZUiJXO5x3ycAF(showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,rtUJso6d7iaNf1yWejxnc5DEXFg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),Whef0cxB2iR93SC5IwUtk+kb2icmDGVUZfW1OFz7sv(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠬࡥ")+B6IrC7zEHlw1oaeWf+gniNItGL6bKwpEW(u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧࡦ")+B6IrC7zEHlw1oaeWf+hEPxFf1Tdo7tADqwcupWJSyU6KHY0(u"ࠩยࠥࠦ࠭ࡧ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=NOrchaEV1iIZ87Uzlwgum(u"࠲࢞"): return
	vWN2YePRikAXEFO6dQ8CT51bz(o8CfwIsWvO0QJqym1bZKTl,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(AQVfaxUPpgh2n9X,k6apiPAlLKM1ed8J42RjHh0o,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(mNRzob0rd7l8vXUOTI9,f4vncKMRlXG9s,f4vncKMRlXG9s)
	lT6SgxvdkPrIWsu(CpnPfINcmVd3aS1sWHtULwYkT,f4vncKMRlXG9s)
	if showDialogs:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def FFIqmOCEnJl7RiDKvh6LycWQZN1Ao(showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,Tzx81Wb0RZC4ID5AyiU2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),Whef0cxB2iR93SC5IwUtk+WiIt2NUHAqQ5wrud3TgkCRDj7L(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ࡫")+B6IrC7zEHlw1oaeWf+rNyT0edugn(u"ࠧࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠤ࠳࠴ࠠࡥࡴࡲࡴࡧࡵࡸࠡ࠰࠱ࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠡ࠰࠱ࠤࡱࡵࡧࡨࡧࡵࠤ࠳࠴ࠠ࡭ࡱࡪࠤ࠳࠴ࠠࡢࡰࡵࠫ࡬")+B6IrC7zEHlw1oaeWf+HHvYL68lbJVZWM7tQEzSex3(u"ࠨࡁࠤࠥࠬ࡭")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=fOc18oTm5hsdD4pVZQj(u"࠳࢟"): return
	vWN2YePRikAXEFO6dQ8CT51bz(ajC5qxpRugwfb1,f4vncKMRlXG9s,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(KT4AZroL6J9jN,f4vncKMRlXG9s,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(O1VXxjFGvDeC,f4vncKMRlXG9s,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(fhLwkVbzievJ,f4vncKMRlXG9s,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(sDN1Yc7OaK,f4vncKMRlXG9s,f4vncKMRlXG9s)
	vWN2YePRikAXEFO6dQ8CT51bz(ebEoW9ntzVlci6NI,f4vncKMRlXG9s,f4vncKMRlXG9s)
	if showDialogs:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NOrchaEV1iIZ87Uzlwgum(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),NeU6uRGpECkvMV5jf(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
def lT6SgxvdkPrIWsu(BhYaS5uGWnLvfAE3t82e,showDialogs):
	if showDialogs:
		TT32BcvomhVewpgMSWkEb46y7xqO = ggJvHnLYzmlj3Z(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,hCm2fnEXs6Zt(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),Whef0cxB2iR93SC5IwUtk+eGW7cI6aQhr0(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࡱ")+kjd9LyNqQHMUevZiRI7OlBGF1h)
		if TT32BcvomhVewpgMSWkEb46y7xqO!=OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࠴ࢠ"): return
	Yo5K7kXcjOVq2SiTvludJ48f = moKCtu35ZJgji1UXIS0srpELB.connect(BhYaS5uGWnLvfAE3t82e)
	Yo5K7kXcjOVq2SiTvludJ48f.text_factory = str
	ODXQpWsKqya39FEctSmlRJ84rkM7vI = Yo5K7kXcjOVq2SiTvludJ48f.cursor()
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(NeU6uRGpECkvMV5jf(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࡲ"))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(PzIpQnUXxRwNCivDhdakWTE(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࡳ"))
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(OOkmZiVcfqlEurM1dHGb(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࡴ"))
	Yo5K7kXcjOVq2SiTvludJ48f.commit()
	ODXQpWsKqya39FEctSmlRJ84rkM7vI.execute(OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࡵ"))
	Yo5K7kXcjOVq2SiTvludJ48f.close()
	if showDialogs:
		ZaUVqChKHwRLYbeiOv(NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,OblVzEoPfRGCamyFkJUc34wLTI8Aju(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),pnHgvFOCBZzc08yULQJGIqw9bf(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡷ"))
		MIjcStaDWnv(f4vncKMRlXG9s)
	return
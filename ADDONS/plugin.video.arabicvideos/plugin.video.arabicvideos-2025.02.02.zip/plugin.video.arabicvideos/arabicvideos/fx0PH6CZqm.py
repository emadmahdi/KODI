# -*- coding: utf-8 -*-
from PNC7bFKMI6 import *
yNIDEX5hU4G769 = 'SHOFHA'
LJfTAEQPv9h4BXdwUp = '_SHT_'
qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN = xKp3jkIvM09AZ4euXa87i5TVtfUD[yNIDEX5hU4G769][0]
Kdr54yMqbjTSX7piWREfPtZ2em = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def QGLoruqnmiAel7Op(mode,url,text):
	if   mode==640: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = LkmCVzJQol0YsM83i7tnr()
	elif mode==641: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = hGJKk8tAiC3XFufEpqavQWmwTHdL(url,text)
	elif mode==642: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = uuvhoSanB2TWD(url)
	elif mode==644: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url)
	elif mode==645: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = vl57jIYC4a(url)
	elif mode==649: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = tTIQWSbOEqHJ4(text)
	else: UEsxyfd8rZMLOHgzc6emSFKD0ktYiT = False
	return UEsxyfd8rZMLOHgzc6emSFKD0ktYiT
def LkmCVzJQol0YsM83i7tnr():
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-MENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'بحث في الموقع',NdKhAS6MXVEORLTwob92pxlZ,649,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'_REMEMBERRESULTS_')
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'المميزة',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN,641,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'featured')
	ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+'جديد الموقع',qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/newvideos.php',641,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ)
	ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"navslide-divider"></div>(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	for zehVcU893FC6LEd1Aij,title in items:
		if title in Kdr54yMqbjTSX7piWREfPtZ2em: continue
		ZI51XvE8YatWCmNdrp('folder',yNIDEX5hU4G769+'_SCRIPT_'+LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,644)
	return
def EX8ceSG6UIbCDBxdmJwzRa0l39W7Nn(url):
	bVHF5x6dk0m2SepUG7lj3NsDZLCcif = []
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-SUBMENU-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	yyuOVAGPZijetcaNz0b = YYqECUofyi7wFrW.findall('"caret"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if yyuOVAGPZijetcaNz0b:
		AAMHoYxRCmt2D6ph89W = yyuOVAGPZijetcaNz0b[0]
		AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('"presentation"','</ul>')
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if not bMU7NEFK5RJ8dcz0jtqiWmvyar6: bMU7NEFK5RJ8dcz0jtqiWmvyar6 = [(NdKhAS6MXVEORLTwob92pxlZ,AAMHoYxRCmt2D6ph89W)]
		ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' فرز أو فلتر أو ترتيب '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
		for MKUGqBYspa2ALPwc1,AAMHoYxRCmt2D6ph89W in bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			bVHF5x6dk0m2SepUG7lj3NsDZLCcif = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if MKUGqBYspa2ALPwc1: MKUGqBYspa2ALPwc1 = MKUGqBYspa2ALPwc1+': '
			for zehVcU893FC6LEd1Aij,title in bVHF5x6dk0m2SepUG7lj3NsDZLCcif:
				title = MKUGqBYspa2ALPwc1+title
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,641)
	gcBxGPatZIzQ1 = YYqECUofyi7wFrW.findall('"pm-category-subcats"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if gcBxGPatZIzQ1:
		AAMHoYxRCmt2D6ph89W = gcBxGPatZIzQ1[0]
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		if len(APRuYMmlIVGTX)<30:
			if bVHF5x6dk0m2SepUG7lj3NsDZLCcif: ZI51XvE8YatWCmNdrp('link',Whef0cxB2iR93SC5IwUtk+' ===== ===== ===== '+kjd9LyNqQHMUevZiRI7OlBGF1h,NdKhAS6MXVEORLTwob92pxlZ,9999)
			for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,641)
	if not yyuOVAGPZijetcaNz0b and not gcBxGPatZIzQ1: hGJKk8tAiC3XFufEpqavQWmwTHdL(url)
	return
def hGJKk8tAiC3XFufEpqavQWmwTHdL(url,kF13d0oJXn4xKH=NdKhAS6MXVEORLTwob92pxlZ):
	if kF13d0oJXn4xKH=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'POST',url,data,headers,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-TITLES-1st')
	else:
		VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-TITLES-2nd')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	AAMHoYxRCmt2D6ph89W,items = NdKhAS6MXVEORLTwob92pxlZ,[]
	REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
	if kF13d0oJXn4xKH=='ajax-search':
		AAMHoYxRCmt2D6ph89W = LMKFcEkU1Q7R80yt4OsgvwxbfP
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	elif kF13d0oJXn4xKH=='featured':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pm-video-watch-featured"(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_episodes':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	elif kF13d0oJXn4xKH=='new_movies':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"row pm-ul-browse-videos(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if len(bMU7NEFK5RJ8dcz0jtqiWmvyar6)>1: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[1]
	elif kF13d0oJXn4xKH=='featured_series':
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		APRuYMmlIVGTX = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in APRuYMmlIVGTX: items.append((NdKhAS6MXVEORLTwob92pxlZ,zehVcU893FC6LEd1Aij,title))
	else:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('(data-echo=".*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6: AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
	if AAMHoYxRCmt2D6ph89W and not items: items = YYqECUofyi7wFrW.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
	if not items: return
	zIDPZSNn1OuweLHvmMKb6d = []
	iiSLCAX0rgEjoT68OYe3vnBI7WdZ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for TTuPH708dUNnjlG3oQpkZsi,zehVcU893FC6LEd1Aij,title in items:
		N1VjdbtuO3z = YYqECUofyi7wFrW.findall('(.*?) (الحلقة|حلقة).\d+',title,YYqECUofyi7wFrW.DOTALL)
		if any(K6KbZDHncNizQgl1fr59XV0 in title for K6KbZDHncNizQgl1fr59XV0 in iiSLCAX0rgEjoT68OYe3vnBI7WdZ):
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,642,TTuPH708dUNnjlG3oQpkZsi)
		elif kF13d0oJXn4xKH=='new_episodes':
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,642,TTuPH708dUNnjlG3oQpkZsi)
		elif N1VjdbtuO3z:
			title = '_MOD_' + N1VjdbtuO3z[0][0]
			if title not in zIDPZSNn1OuweLHvmMKb6d:
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,645,TTuPH708dUNnjlG3oQpkZsi)
				zIDPZSNn1OuweLHvmMKb6d.append(title)
		else: ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,645,TTuPH708dUNnjlG3oQpkZsi)
	if 1:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"pagination(.*?)</ul>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			items = YYqECUofyi7wFrW.findall('href="(.*?)".*?>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			for zehVcU893FC6LEd1Aij,title in items:
				if zehVcU893FC6LEd1Aij=='#': continue
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+'/'+zehVcU893FC6LEd1Aij.strip('/')
				title = Pr4ubLdO7Z1qjKFaMIy3H(title)
				ZI51XvE8YatWCmNdrp('folder',LJfTAEQPv9h4BXdwUp+'صفحة '+title,zehVcU893FC6LEd1Aij,641)
	return
def vl57jIYC4a(url):
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',url,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-EPISODES-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	k1ChwgueU5nbDX6K0BOEGx = YYqECUofyi7wFrW.findall('"image" content="(.*?)"',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	TTuPH708dUNnjlG3oQpkZsi = k1ChwgueU5nbDX6K0BOEGx[0] if k1ChwgueU5nbDX6K0BOEGx else NdKhAS6MXVEORLTwob92pxlZ
	bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"AiredEPS"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
	if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
		AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
		items = YYqECUofyi7wFrW.findall('href="(.*?)".*?<span>(.*?)</em>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
		for zehVcU893FC6LEd1Aij,title in items:
			title = title.replace('</span><em>',Vwgflszp4WRA93kx6hvdua21HX5cOb)
			ZI51XvE8YatWCmNdrp('video',LJfTAEQPv9h4BXdwUp+title,zehVcU893FC6LEd1Aij,642,TTuPH708dUNnjlG3oQpkZsi)
	return
def uuvhoSanB2TWD(url):
	UTwH7zjZOrmFl,V2E56eU4vIrcYoh91Azpm,Pj8lY4doOfxiFMuNLhv3tnp = [],[],[]
	BfjcMoqOsmdUvZVCHWIyQKi = url.replace('/watch.php','/view.php') if '/watch.php' in url else url
	VNc1u4edS90FK5W6bsMgQC2B = cJaAB4uQyp(h1dnE0q2zFHjXlvyGuLZxw,'GET',BfjcMoqOsmdUvZVCHWIyQKi,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,NdKhAS6MXVEORLTwob92pxlZ,'SHOFHA-PLAY-1st')
	LMKFcEkU1Q7R80yt4OsgvwxbfP = VNc1u4edS90FK5W6bsMgQC2B.content
	if 'embedded-video' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"embedded-video"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if oDhlaxn0EqyYikcHrmZBN8uv:
				zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[0]
				if zehVcU893FC6LEd1Aij not in UTwH7zjZOrmFl:
					V2E56eU4vIrcYoh91Azpm.append('?named=__embed')
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if 'WatchServers' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"WatchServers"(.*?)</script>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			vYwWzXRZLjKceotifTCHdn48sM = YYqECUofyi7wFrW.findall('id="(.*?)".*?</span>(.*?)</button>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			AAMHoYxRCmt2D6ph89W = AAMHoYxRCmt2D6ph89W.replace('\\"','"').replace('\/','/')
			oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('"<iframe.src="(.*?)"',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if len(vYwWzXRZLjKceotifTCHdn48sM)==len(oDhlaxn0EqyYikcHrmZBN8uv):
				for id,title in vYwWzXRZLjKceotifTCHdn48sM:
					zehVcU893FC6LEd1Aij = oDhlaxn0EqyYikcHrmZBN8uv[int(id)]
					if zehVcU893FC6LEd1Aij not in UTwH7zjZOrmFl:
						V2E56eU4vIrcYoh91Azpm.append('?named='+title+'__watch')
						UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	if 'DownloadServer' in LMKFcEkU1Q7R80yt4OsgvwxbfP:
		bMU7NEFK5RJ8dcz0jtqiWmvyar6 = YYqECUofyi7wFrW.findall('"DownloadServer"(.*?)</div>',LMKFcEkU1Q7R80yt4OsgvwxbfP,YYqECUofyi7wFrW.DOTALL)
		if bMU7NEFK5RJ8dcz0jtqiWmvyar6:
			AAMHoYxRCmt2D6ph89W = bMU7NEFK5RJ8dcz0jtqiWmvyar6[0]
			oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('href="(.*?)".*?</i>(.*?)</a>',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			if not oDhlaxn0EqyYikcHrmZBN8uv: oDhlaxn0EqyYikcHrmZBN8uv = YYqECUofyi7wFrW.findall('href="(.*?)">(.*?)<',AAMHoYxRCmt2D6ph89W,YYqECUofyi7wFrW.DOTALL)
			REGxsWAoilB7dCFNgMhz0V98bcm = msbTrJW03xuvA(url,'url')
			for zehVcU893FC6LEd1Aij,title in oDhlaxn0EqyYikcHrmZBN8uv:
				if 'http' not in zehVcU893FC6LEd1Aij: zehVcU893FC6LEd1Aij = REGxsWAoilB7dCFNgMhz0V98bcm+zehVcU893FC6LEd1Aij
				if zehVcU893FC6LEd1Aij not in UTwH7zjZOrmFl:
					V2E56eU4vIrcYoh91Azpm.append('?named='+title+'__download')
					UTwH7zjZOrmFl.append(zehVcU893FC6LEd1Aij)
	hRfSE2oyUgL1XIAws49p8O3aWl = zip(UTwH7zjZOrmFl,V2E56eU4vIrcYoh91Azpm)
	for zehVcU893FC6LEd1Aij,name in hRfSE2oyUgL1XIAws49p8O3aWl: Pj8lY4doOfxiFMuNLhv3tnp.append(zehVcU893FC6LEd1Aij+name)
	import ttrmdIqhPY
	ttrmdIqhPY.rg6StQ4I5wVT7ABoyzGK3Ne2LZx(Pj8lY4doOfxiFMuNLhv3tnp,yNIDEX5hU4G769,'video',url)
	return
def tTIQWSbOEqHJ4(search):
	search,LM1WpcGdrz8QtHV0i53k,showDialogs = tSBXfikTvou6(search)
	if search==NdKhAS6MXVEORLTwob92pxlZ: search = Z6GiHgnz0jNytc()
	if search==NdKhAS6MXVEORLTwob92pxlZ: return
	search = search.replace(Vwgflszp4WRA93kx6hvdua21HX5cOb,'+')
	url = qsDeoiGd8QYwOhkMPAE3mW1g4FRCtN+'/search.php?keywords='+search
	hGJKk8tAiC3XFufEpqavQWmwTHdL(url,'search')
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FUNONTV'
Z0BYJQghVL1v87CAem = '_FNT_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = {'Referer':gAVl1vUmus8}
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==1070: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==1071: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==1072: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==1073: ka7jz96YCdTBnQOLVPuJG3285MHf = E5mTvMgjPFJKs1noB7we8i(url,text)
	elif mode==1074: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==1079: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,1079,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''["']navslide-wrap["'](.*?)</ul>''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1074)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('/category.php">(.*?)"navslide-divider"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''["']dropdown-menu["'](.*?)</ul>''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for MtCcgLOoBTGp4nqzVhYJliX8Zva6s in oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = Po9h3gWFuLR2.replace(MtCcgLOoBTGp4nqzVhYJliX8Zva6s,sCHVtMAvqirbQ4BUK3cgWo)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if not title: continue
		if title in MqARWHDkmiT4nlz: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1074)
	return
def ffy5vVCNau6FWgbmp(url):
	qqfsNGJplK,Y0WVJ5CTpDO = [],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx and '.php' in str(GzRKsiw5PBIe1NlrqmQy9STx):
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"presentation"','</ul>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [(sCHVtMAvqirbQ4BUK3cgWo,Po9h3gWFuLR2)]
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' فرز أو فلتر أو ترتيب '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for J8noyr10GLB9exORpmSIHTWiFPc,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			qqfsNGJplK = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if J8noyr10GLB9exORpmSIHTWiFPc: J8noyr10GLB9exORpmSIHTWiFPc = J8noyr10GLB9exORpmSIHTWiFPc+': '
			for B17r2fdFy9ns8tiOMLu,title in qqfsNGJplK:
				title = J8noyr10GLB9exORpmSIHTWiFPc+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1071)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"list-inline"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if 1 or len(Y0WVJ5CTpDO)<30:
			if qqfsNGJplK: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO:
				if title in MqARWHDkmiT4nlz: continue
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1071,'','','series')
	if not GzRKsiw5PBIe1NlrqmQy9STx and not iUtXlDhSVoBZJrPTQAwcER9nfMkN: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		HSNYwERMjzyxmrPku = headers.copy()
		HSNYwERMjzyxmrPku['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-TITLES-1st')
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-TITLES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Po9h3gWFuLR2,items = sCHVtMAvqirbQ4BUK3cgWo,[]
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	elif n1WYDtVC8dRHbXJkMa=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-carousel_featured"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_episodes':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if len(oPnz7Zt4xLHTwR)>1: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
	elif n1WYDtVC8dRHbXJkMa=='featured_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-grid"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if Po9h3gWFuLR2 and not items: items = fNntYJW45mEFSdRX8g.findall('''"thumbnail".*?<a href=["'](.*?)["'].*?title=["'](.*?)["'].*?data-echo=["'](.*?)["']''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: return
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS += '|Referer='+gAVl1vUmus8
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1072,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif n1WYDtVC8dRHbXJkMa in ['new_episodes','series']:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1072,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1073,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1073,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if 1:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,1071)
	return
def E5mTvMgjPFJKs1noB7we8i(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-EPISODES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"image" content="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[0] if Qp3jGv8leCbuiEU5Im else sCHVtMAvqirbQ4BUK3cgWo
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS += '|Referer='+gAVl1vUmus8
	items = []
	irDX4SOHZKIaLUvhyjCbx0T = False
	if GzRKsiw5PBIe1NlrqmQy9STx and not Obes76wjH9LRyEqc2NWPTSphZz34K:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Obes76wjH9LRyEqc2NWPTSphZz34K,title in items:
			Obes76wjH9LRyEqc2NWPTSphZz34K = Obes76wjH9LRyEqc2NWPTSphZz34K.strip('#')
			if len(items)>1: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,1073,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,Obes76wjH9LRyEqc2NWPTSphZz34K)
			else: irDX4SOHZKIaLUvhyjCbx0T = True
	else: irDX4SOHZKIaLUvhyjCbx0T = True
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('id="'+Obes76wjH9LRyEqc2NWPTSphZz34K+'"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('SeasonsEpisodesMain(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
			Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('./')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1072,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN and irDX4SOHZKIaLUvhyjCbx0T:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if Y0WVJ5CTpDO:
			OO4rxuZoVb8KA5mdCl9HcRJiY3PIsS,LgIkJvYh7iC0ZexNWO = zip(*Y0WVJ5CTpDO)
			W2vfKC7sJcmdlXFLYbQEgT = [Mx0TQvmZAsedaGj4opVDJu5by8RUwS]*len(Y0WVJ5CTpDO)
			items = zip(LgIkJvYh7iC0ZexNWO,OO4rxuZoVb8KA5mdCl9HcRJiY3PIsS,W2vfKC7sJcmdlXFLYbQEgT)
		if not items: items = fNntYJW45mEFSdRX8g.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS += '|Referer='+gAVl1vUmus8
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
			title = title.replace('</em><span>',AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,1072,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p,GQkoWhXOlsSVIp0Z = [],[]
	Sw0pOFoVhPeIxbl = ''
	if 'post=' in Sw0pOFoVhPeIxbl:
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('id="player".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		sYTMXCn5AG0KR3E9SUO = B17r2fdFy9ns8tiOMLu.split('post=')[1]
		sYTMXCn5AG0KR3E9SUO = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(sYTMXCn5AG0KR3E9SUO)
		if I5VKjrFL0Bk97: sYTMXCn5AG0KR3E9SUO = sYTMXCn5AG0KR3E9SUO.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		sYTMXCn5AG0KR3E9SUO = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',sYTMXCn5AG0KR3E9SUO)
		PXFtqmw5lBGQNa0IV8 = sYTMXCn5AG0KR3E9SUO['servers']
		J4EIW0hU16YCcqn92uatb3 = list(PXFtqmw5lBGQNa0IV8.keys())
		PXFtqmw5lBGQNa0IV8 = list(PXFtqmw5lBGQNa0IV8.values())
		icYBfzVeQunoDOv2w08dKl = zip(J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8)
		for title,B17r2fdFy9ns8tiOMLu in icYBfzVeQunoDOv2w08dKl:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	else:
		vrEJRkchKxtDNiqO1b79mL5eT = url.replace('watch.php','view.php')
		vrEJRkchKxtDNiqO1b79mL5eT,ISfWanzRV0GLEpY7e9Tl4FBsv1u = vrEJRkchKxtDNiqO1b79mL5eT.split('?vid=')
		i68iPmaHVAZknGv2SNpyzCwcFE = 'ur='+ISfWanzRV0GLEpY7e9Tl4FBsv1u+'&action=0&submit=submit'
		HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FUNONTV-PLAY2-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		if 0:
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"embedURL" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
				if B17r2fdFy9ns8tiOMLu not in GQkoWhXOlsSVIp0Z:
					GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
					smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__embed'
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
		if 1:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"embeding"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if oPnz7Zt4xLHTwR:
				Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
				items = fNntYJW45mEFSdRX8g.findall('data-embed="(.*?)".*?</span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in items:
					if B17r2fdFy9ns8tiOMLu in GQkoWhXOlsSVIp0Z: continue
					GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
		if 0:
			vrEJRkchKxtDNiqO1b79mL5eT = url.replace('watch.php','downloads.php')
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,False,'FUNONTV-PLAY-2nd')
			Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-download"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			for Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
				items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<strong>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				if not items: items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in items:
					if B17r2fdFy9ns8tiOMLu in GQkoWhXOlsSVIp0Z: continue
					GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
					smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__download'
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/search.php?keywords='+search
	fs7D0d3QyAT(url,'search')
	return
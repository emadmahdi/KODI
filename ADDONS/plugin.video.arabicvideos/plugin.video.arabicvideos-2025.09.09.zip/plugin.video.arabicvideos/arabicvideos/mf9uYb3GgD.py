# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'DAILYMOTION'
Z0BYJQghVL1v87CAem = '_DLM_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
DbmJ9I0ZfXgcFlO8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][1]
def dBHD1Vl7hQuNOY(mode,url,text,type,mRwrKW6fNZV):
	if	 mode==400: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==401: ka7jz96YCdTBnQOLVPuJG3285MHf = np3MHYVyiq(url,text)
	elif mode==402: ka7jz96YCdTBnQOLVPuJG3285MHf = hVwNx4B8gCKfEbv(url,text)
	elif mode==403: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url,text)
	elif mode==404: ka7jz96YCdTBnQOLVPuJG3285MHf = JhonQXzeNV5aOS6jfUlxG87t01(text,mRwrKW6fNZV)
	elif mode==405: ka7jz96YCdTBnQOLVPuJG3285MHf = oKm0sSOBIdYPMxbE(text,mRwrKW6fNZV)
	elif mode==406: ka7jz96YCdTBnQOLVPuJG3285MHf = eZIrVhlHcQSJ(text,mRwrKW6fNZV)
	elif mode==407: ka7jz96YCdTBnQOLVPuJG3285MHf = I1feNnlh3WBT2APZS(url,mRwrKW6fNZV)
	elif mode==408: ka7jz96YCdTBnQOLVPuJG3285MHf = RNP5lSfIxAjk(url,mRwrKW6fNZV)
	elif mode==409: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text,mRwrKW6fNZV)
	elif mode==411: ka7jz96YCdTBnQOLVPuJG3285MHf = F5FDLaJU9nS7YucWhPrftjiKgbN3I(url,text)
	elif mode==414: ka7jz96YCdTBnQOLVPuJG3285MHf = qaMTEl0rI1jk83meNhWYSgnU7Pcd(text)
	elif mode==415: ka7jz96YCdTBnQOLVPuJG3285MHf = M4zJwKDUu8AlGnLZk6Ve1Y2(text,mRwrKW6fNZV)
	elif mode==416: ka7jz96YCdTBnQOLVPuJG3285MHf = hPRyUEWfCDv(text,mRwrKW6fNZV)
	elif mode==417: ka7jz96YCdTBnQOLVPuJG3285MHf = FFq3M7saDXPgWRojfdkuZ(url,mRwrKW6fNZV)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الرئيسية',sCHVtMAvqirbQ4BUK3cgWo,414)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن فيديوهات',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'videos?sortBy=','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن آخر الفيديوهات',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن الفيديوهات الأكثر مشاهدة',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن قوائم التشغيل',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'playlists','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن مستخدم',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'channels','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن بث حي',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'lives','_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن هاشتاك',sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,'hashtags','_REMEMBERRESULTS_')
	return
def hVwNx4B8gCKfEbv(url,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4):
	if '/dm_' in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,False,sCHVtMAvqirbQ4BUK3cgWo,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = UHqibFEGL8fjKhI.headers
		if 'Location' in list(headers.keys()): url = gAVl1vUmus8+headers['Location']
	AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 = VXWOCAE6ns3paJ8DLG479NQfMu+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4+B8alA5nvIhTxQ
	AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 = T6TaiswfS5qkt47d8cgIyEx0r2BV(AT9pZVPjxgWM0mL5ybkOaQesz6GEB4)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: بث حي',url,411,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'channel_lives_now')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: آخر الفيديوهات',url+'/videos',408)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: المميزة',url,411,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'channel_featured_videos')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: قوائم التشغيل',url+'/playlists',407)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: قنوات ذات صلة',url,411,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'channel_related_channel')
	return
def T6TaiswfS5qkt47d8cgIyEx0r2BV(title):
	title = title.rstrip('\\').strip(AAh0X3OCacr4HpifRGLZKT).replace('\\\\','\\')
	title = EEH4kBfGY0FuZUjeNn(title)
	return title
def YH54mqkD2eU06(url,EU7FNSgO6Mk3sTZRIxerhwuio):
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1([url],Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def JhonQXzeNV5aOS6jfUlxG87t01(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = sCHVtMAvqirbQ4BUK3cgWo
	search = search.split('/videos')[0]
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	if sort==sCHVtMAvqirbQ4BUK3cgWo: n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysortmethod',sCHVtMAvqirbQ4BUK3cgWo)
	else: n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = gAVl1vUmus8+'/search/'+search+'/videos'
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"videos"(.*?)"VideoConnection"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for id,title,vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4,yAMScJ6z3E8,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+id
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			EU7FNSgO6Mk3sTZRIxerhwuio = vvaxwZmzFV2UjGoqkDfi7P04SBurT+'::'+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,EU7FNSgO6Mk3sTZRIxerhwuio)
		if '"hasNextPage":true' in Sw0pOFoVhPeIxbl:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,404,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def oKm0sSOBIdYPMxbE(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	url = gAVl1vUmus8+'/search/'+search+'/playlists'
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	items = fNntYJW45mEFSdRX8g.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for id,name,vTz7lX4BuVStZUNRIf9,vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count in items:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
		EU7FNSgO6Mk3sTZRIxerhwuio = vvaxwZmzFV2UjGoqkDfi7P04SBurT+'::'+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,401,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,EU7FNSgO6Mk3sTZRIxerhwuio)
	if '"hasNextPage":true' in Sw0pOFoVhPeIxbl:
		mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,405,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def eZIrVhlHcQSJ(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	url = gAVl1vUmus8+'/search/'+search+'/channels'
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"channels"(.*?)"ChannelConnection"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for id,name,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+id
			title = 'USER:  '+name
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,402,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,name)
		if '"hasNextPage":true' in Sw0pOFoVhPeIxbl:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,406,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def qaMTEl0rI1jk83meNhWYSgnU7Pcd(w8l5VIpjhcAED):
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['home']['neon']['sections']['edges']
		if not w8l5VIpjhcAED:
			ZvpDbVLI7JNFMEd = []
			for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
				tpgF3TAwi1lzeEybSxV7PvZun8MKQ = HX4YPi952Kap1['node']['title']
				if tpgF3TAwi1lzeEybSxV7PvZun8MKQ not in ZvpDbVLI7JNFMEd: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+tpgF3TAwi1lzeEybSxV7PvZun8MKQ,sCHVtMAvqirbQ4BUK3cgWo,414,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,tpgF3TAwi1lzeEybSxV7PvZun8MKQ)
				ZvpDbVLI7JNFMEd.append(tpgF3TAwi1lzeEybSxV7PvZun8MKQ)
		else:
			for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
				tpgF3TAwi1lzeEybSxV7PvZun8MKQ = HX4YPi952Kap1['node']['title']
				if tpgF3TAwi1lzeEybSxV7PvZun8MKQ==w8l5VIpjhcAED:
					K7einAgvDb6uGhsxpNR3Zt = HX4YPi952Kap1['node']['components']['edges']
					for B8297zbJEioL in K7einAgvDb6uGhsxpNR3Zt:
						yAMScJ6z3E8 = str(B8297zbJEioL['node']['duration'])
						title = EEH4kBfGY0FuZUjeNn(B8297zbJEioL['node']['title'])
						title = title.replace('\/','/')
						S7SiNumW9bEIpPOrTK56ZaYyC = B8297zbJEioL['node']['xid']
						Mx0TQvmZAsedaGj4opVDJu5by8RUwS = B8297zbJEioL['node']['thumbnailx480']
						Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
						B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+S7SiNumW9bEIpPOrTK56ZaYyC
						XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	return
def M4zJwKDUu8AlGnLZk6Ve1Y2(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	url = gAVl1vUmus8+'/search/'+search+'/lives'
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		try: umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['search']['lives']['edges']
		except: umG9ZW75zUqrJSefO8KcHi = []
		for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
			name = HX4YPi952Kap1['node']['title']
			name = EEH4kBfGY0FuZUjeNn(name)
			S7SiNumW9bEIpPOrTK56ZaYyC = HX4YPi952Kap1['node']['xid']
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+S7SiNumW9bEIpPOrTK56ZaYyC
			XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'LIVE: '+name,B17r2fdFy9ns8tiOMLu,403)
		if '"hasNextPage":true' in zcoVyl0XFamiKfEWYtjQJC:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,415,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def VNFJ10Q5KDb6pUm4kcvuqEnx(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	url = gAVl1vUmus8+'/search/'+search+'/topics'
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		try: umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['search']['topics']['edges']
		except: umG9ZW75zUqrJSefO8KcHi = []
		for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
			name = HX4YPi952Kap1['node']['name']
			S7SiNumW9bEIpPOrTK56ZaYyC = HX4YPi952Kap1['node']['xid']
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/topic/'+S7SiNumW9bEIpPOrTK56ZaYyC
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'TOPIC: '+name,B17r2fdFy9ns8tiOMLu,413)
		if '"hasNextPage":true' in zcoVyl0XFamiKfEWYtjQJC:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,412,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def zdrxwjmulSDHnEt6aNqLJi8To(url,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	S7SiNumW9bEIpPOrTK56ZaYyC = url.split('/')[-1]
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mytopicid',S7SiNumW9bEIpPOrTK56ZaYyC)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['topic']['videos']['edges']
		for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
			yAMScJ6z3E8 = str(HX4YPi952Kap1['node']['duration'])
			title = EEH4kBfGY0FuZUjeNn(HX4YPi952Kap1['node']['title'])
			title = title.replace('\/','/')
			S7SiNumW9bEIpPOrTK56ZaYyC = HX4YPi952Kap1['node']['xid']
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = HX4YPi952Kap1['node']['thumbnailx480']
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+S7SiNumW9bEIpPOrTK56ZaYyC
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
		if '"hasNextPage":true' in zcoVyl0XFamiKfEWYtjQJC:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,413,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV)
	return
def np3MHYVyiq(url,EU7FNSgO6Mk3sTZRIxerhwuio):
	id = url.split('/')[-1]
	vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 = EU7FNSgO6Mk3sTZRIxerhwuio.split('::',1)
	B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+vvaxwZmzFV2UjGoqkDfi7P04SBurT
	AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 = T6TaiswfS5qkt47d8cgIyEx0r2BV(AT9pZVPjxgWM0mL5ybkOaQesz6GEB4)
	title = VXWOCAE6ns3paJ8DLG479NQfMu+'OWNER:  '+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4+B8alA5nvIhTxQ
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,402,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4)
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('myplaylistid',id)
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"collection_videos"(.*?)"SectionEdge"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for id,title,yAMScJ6z3E8,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+id
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			EU7FNSgO6Mk3sTZRIxerhwuio = vvaxwZmzFV2UjGoqkDfi7P04SBurT+'::'+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,EU7FNSgO6Mk3sTZRIxerhwuio)
	return
def RNP5lSfIxAjk(url,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	ISfWanzRV0GLEpY7e9Tl4FBsv1u = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mychannelid',ISfWanzRV0GLEpY7e9Tl4FBsv1u)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysortmethod',sort)
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for id,title,yAMScJ6z3E8,vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+id
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			EU7FNSgO6Mk3sTZRIxerhwuio = vvaxwZmzFV2UjGoqkDfi7P04SBurT+'::'+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,EU7FNSgO6Mk3sTZRIxerhwuio)
		if '"hasNextPage":true' in Sw0pOFoVhPeIxbl:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,408,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV)
	return
def I1feNnlh3WBT2APZS(url,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	ISfWanzRV0GLEpY7e9Tl4FBsv1u = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mychannelid',ISfWanzRV0GLEpY7e9Tl4FBsv1u)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysortmethod',sort)
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for id,name,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count,vTz7lX4BuVStZUNRIf9,vvaxwZmzFV2UjGoqkDfi7P04SBurT,AT9pZVPjxgWM0mL5ybkOaQesz6GEB4 in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			EU7FNSgO6Mk3sTZRIxerhwuio = vvaxwZmzFV2UjGoqkDfi7P04SBurT+'::'+AT9pZVPjxgWM0mL5ybkOaQesz6GEB4
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,401,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,EU7FNSgO6Mk3sTZRIxerhwuio)
		if '"hasNextPage":true' in Sw0pOFoVhPeIxbl:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,407,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV)
	return
def F5FDLaJU9nS7YucWhPrftjiKgbN3I(url,ov3xrPlnIKj):
	ISfWanzRV0GLEpY7e9Tl4FBsv1u = url.split('/')[3]
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mychannelid',ISfWanzRV0GLEpY7e9Tl4FBsv1u)
	Sw0pOFoVhPeIxbl = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	U10Ugw2RBdVL94MFpHGAXCsitYkDE = Kdnrl9JHV0cFaGzC5bN.loads(Sw0pOFoVhPeIxbl)
	try: items = U10Ugw2RBdVL94MFpHGAXCsitYkDE['data']['channel'][ov3xrPlnIKj]['edges']
	except: items = []
	if not items: XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+'لا توجد نتائج',sCHVtMAvqirbQ4BUK3cgWo,9999)
	else:
		for UqKgalXPCz7eQAL08foMx1R in items:
			lPknHmSEG3Q1KdV4Lob0wNFYetJax9 = UqKgalXPCz7eQAL08foMx1R['node']
			S7SiNumW9bEIpPOrTK56ZaYyC = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['xid']
			keys = list(lPknHmSEG3Q1KdV4Lob0wNFYetJax9.keys())
			eQfa8Csg0IFdAH6YV = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['__typename'].lower()
			if eQfa8Csg0IFdAH6YV=='channel':
				name = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['name']
				tLSUP9jy5qAlb = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['displayName']
				title = 'USER:  '+tLSUP9jy5qAlb
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['coverURLx375']
			else:
				name = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['channel']['name']
				tLSUP9jy5qAlb = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['channel']['displayName']
				title = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['title']
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = lPknHmSEG3Q1KdV4Lob0wNFYetJax9['thumbnailx360']
				if eQfa8Csg0IFdAH6YV=='live': title = 'LIVE:  '+title
			title = T6TaiswfS5qkt47d8cgIyEx0r2BV(title)
			EU7FNSgO6Mk3sTZRIxerhwuio = name+'::'+tLSUP9jy5qAlb
			if qdUK5ioJyrO1T:
				title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				EU7FNSgO6Mk3sTZRIxerhwuio = EU7FNSgO6Mk3sTZRIxerhwuio.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			if eQfa8Csg0IFdAH6YV=='channel':
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+S7SiNumW9bEIpPOrTK56ZaYyC
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,402,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,EU7FNSgO6Mk3sTZRIxerhwuio)
			else:
				if eQfa8Csg0IFdAH6YV=='video': yAMScJ6z3E8 = str(lPknHmSEG3Q1KdV4Lob0wNFYetJax9['duration'])
				else: yAMScJ6z3E8 = sCHVtMAvqirbQ4BUK3cgWo
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+S7SiNumW9bEIpPOrTK56ZaYyC
				XAozRfZ68H9x2OsiP3LmIaql1(eQfa8Csg0IFdAH6YV,Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,EU7FNSgO6Mk3sTZRIxerhwuio)
	return
def hPRyUEWfCDv(search,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mysearchwords',search)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagelimit','40')
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	url = gAVl1vUmus8+'/search/'+search+'/hashtags'
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		try: umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['search']['hashtags']['edges']
		except: umG9ZW75zUqrJSefO8KcHi = []
		for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
			name = HX4YPi952Kap1['node']['name']
			name = EEH4kBfGY0FuZUjeNn(name)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/hashtag/'+name[1:]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'HSHTG: '+name,B17r2fdFy9ns8tiOMLu,417)
		if '"hasNextPage":true' in zcoVyl0XFamiKfEWYtjQJC:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,416,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,search)
	return
def FFq3M7saDXPgWRojfdkuZ(url,mRwrKW6fNZV=sCHVtMAvqirbQ4BUK3cgWo):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	name = url.split('/')[-1]
	n1WYDtVC8dRHbXJkMa = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('myhashtagname',name)
	n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.replace('mypagenumber',mRwrKW6fNZV)
	zcoVyl0XFamiKfEWYtjQJC = OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa)
	if zcoVyl0XFamiKfEWYtjQJC:
		paZgBkNqKWTmv8CHEjcS0UnPAzY9X = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',zcoVyl0XFamiKfEWYtjQJC)
		umG9ZW75zUqrJSefO8KcHi = paZgBkNqKWTmv8CHEjcS0UnPAzY9X['data']['contentFeed']['edges']
		for HX4YPi952Kap1 in umG9ZW75zUqrJSefO8KcHi:
			yAMScJ6z3E8 = str(HX4YPi952Kap1['node']['post']['duration'])
			title = EEH4kBfGY0FuZUjeNn(HX4YPi952Kap1['node']['post']['title'])
			title = title.replace('\/','/')
			S7SiNumW9bEIpPOrTK56ZaYyC = HX4YPi952Kap1['node']['post']['xid']
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = HX4YPi952Kap1['node']['post']['thumbnailx480']
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/video/'+S7SiNumW9bEIpPOrTK56ZaYyC
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,403,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
		if '"hasNextPage":true' in zcoVyl0XFamiKfEWYtjQJC:
			mRwrKW6fNZV = str(int(mRwrKW6fNZV)+1)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+mRwrKW6fNZV,url,416,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV)
	return
def OOpRMXZrx5Jjk(n1WYDtVC8dRHbXJkMa,search=sCHVtMAvqirbQ4BUK3cgWo):
	if I5VKjrFL0Bk97: n1WYDtVC8dRHbXJkMa = n1WYDtVC8dRHbXJkMa.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	Sevf2X0bRghaCtMqN8YwPQ1Bux6HDp = jC1O5pfBcsSIyZ7wxtDmYo8eT0()
	headers = {"Authorization":Sevf2X0bRghaCtMqN8YwPQ1Bux6HDp,"Origin":gAVl1vUmus8,'Content-Type':'text/plain; charset=utf-8'}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',DbmJ9I0ZfXgcFlO8,n1WYDtVC8dRHbXJkMa,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'DAILYMOTION-GET_PAGEDATA-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	return Sw0pOFoVhPeIxbl
def jC1O5pfBcsSIyZ7wxtDmYo8eT0():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'DAILYMOTION-GET_AUTHINTICATION-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	HefLZwzTrAjUBXcR4og = fNntYJW45mEFSdRX8g.findall('var n="(.*?)",o="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	HrnXOa5GQJeg6NR8LdYj9WkqA1,pcwZiUaXBvCHxTDI1OSfbAPt3WVQ = HefLZwzTrAjUBXcR4og[-1]
	peqWKPyrFQ83HzfbiXLmjdShC = 'https://graphql.api.dailymotion.com/oauth/token'
	TTSKnsyRc1 = 'client_credentials'
	data = {'client_id':HrnXOa5GQJeg6NR8LdYj9WkqA1,'client_secret':pcwZiUaXBvCHxTDI1OSfbAPt3WVQ,'grant_type':TTSKnsyRc1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',peqWKPyrFQ83HzfbiXLmjdShC,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	HefLZwzTrAjUBXcR4og = fNntYJW45mEFSdRX8g.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	TGOd4wutMDixc61esno3FRfL8BN9mH,KVzwLXNt5eRupgUSaCvGjf1MiA72W = HefLZwzTrAjUBXcR4og[0]
	Sevf2X0bRghaCtMqN8YwPQ1Bux6HDp = KVzwLXNt5eRupgUSaCvGjf1MiA72W+" "+TGOd4wutMDixc61esno3FRfL8BN9mH
	return Sevf2X0bRghaCtMqN8YwPQ1Bux6HDp
def RsxrGI1pcyY3UXTSLiC(search,Ffh8yTQ3d6sp=sCHVtMAvqirbQ4BUK3cgWo):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not Ffh8yTQ3d6sp and showDialogs:
		oF0QalEg7VdXtcyOm43 = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('موقع ديلي موشن - اختر البحث',oF0QalEg7VdXtcyOm43)
		if jQLzA92KFEcpw==-1: return
		elif jQLzA92KFEcpw==0: Ffh8yTQ3d6sp = 'videos?sortBy='
		elif jQLzA92KFEcpw==1: Ffh8yTQ3d6sp = 'videos?sortBy=RECENT'
		elif jQLzA92KFEcpw==2: Ffh8yTQ3d6sp = 'videos?sortBy=VIEW_COUNT'
		elif jQLzA92KFEcpw==3: Ffh8yTQ3d6sp = 'playlists'
		elif jQLzA92KFEcpw==4: Ffh8yTQ3d6sp = 'channels'
		elif jQLzA92KFEcpw==5: Ffh8yTQ3d6sp = 'lives'
		elif jQLzA92KFEcpw==6: Ffh8yTQ3d6sp = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in Z2VkQhiPAOuboSRB: Ffh8yTQ3d6sp = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in Z2VkQhiPAOuboSRB: Ffh8yTQ3d6sp = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in Z2VkQhiPAOuboSRB: Ffh8yTQ3d6sp = 'channels'
	elif '_DAILYMOTION-LIVES_' in Z2VkQhiPAOuboSRB: Ffh8yTQ3d6sp = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in Z2VkQhiPAOuboSRB: Ffh8yTQ3d6sp = 'hashtags'
	elif not Ffh8yTQ3d6sp: Ffh8yTQ3d6sp = 'videos?sortBy='
	if not search:
		search = UyBdvjGrFxDWMpmLOXn()
		if not search: return
	if 'videos' in Ffh8yTQ3d6sp: JhonQXzeNV5aOS6jfUlxG87t01(search+'/'+Ffh8yTQ3d6sp)
	elif 'playlists' in Ffh8yTQ3d6sp: oKm0sSOBIdYPMxbE(search)
	elif 'channels' in Ffh8yTQ3d6sp: eZIrVhlHcQSJ(search)
	elif 'lives' in Ffh8yTQ3d6sp: M4zJwKDUu8AlGnLZk6Ve1Y2(search)
	elif 'hashtags' in Ffh8yTQ3d6sp: hPRyUEWfCDv(search)
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'HALACIMA'
Z0BYJQghVL1v87CAem = '_HLC_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==80: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==81: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==82: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==83: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==89: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'HALACIMA-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(gAVl1vUmus8,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,89,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-content(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-name="(.*?)".*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for pm4F0M2Dsuh6otP7Zi5NXT,title in items:
		B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/ajax/getItem?item='+pm4F0M2Dsuh6otP7Zi5NXT+'&Ajax=1'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,81)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"nav-main"(.*?)</nav>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu=='#': continue
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,81)
	return
def fs7D0d3QyAT(url,pm4F0M2Dsuh6otP7Zi5NXT=sCHVtMAvqirbQ4BUK3cgWo):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'HALACIMA-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = [Sw0pOFoVhPeIxbl]
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'HALACIMA-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		if pm4F0M2Dsuh6otP7Zi5NXT=='featured':
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"container"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		elif '"section-post mb-10"' in Sw0pOFoVhPeIxbl:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"section-post mb-10"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		else:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<article(.*?)"pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not items:
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not items: items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if '/series/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,83,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif 'سلاسل' not in url and any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,82,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'الحلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,83,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movies/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,81,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,83,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if pm4F0M2Dsuh6otP7Zi5NXT==sCHVtMAvqirbQ4BUK3cgWo:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)<footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=="": continue
				if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'هناك المزيد',url,81)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'HALACIMA-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"getSeasonsBySeries(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"list-episodes"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx and '/series/' not in url:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,83,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"image" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,82,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/movies/','/watch_movies/')
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.replace('/episodes/','/watch_episodes/')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'HALACIMA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,'url')
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"servers"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		uu4UgsMj01aImASoXpYDO9iQcfG = fNntYJW45mEFSdRX8g.findall('postID = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		uu4UgsMj01aImASoXpYDO9iQcfG = uu4UgsMj01aImASoXpYDO9iQcfG[0]
		items = fNntYJW45mEFSdRX8g.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for smh8Qbf9jH,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/ajax/getPlayer?server='+smh8Qbf9jH+'&postID='+uu4UgsMj01aImASoXpYDO9iQcfG+'&Ajax=1'
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downs"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__download'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'-')
	url = gAVl1vUmus8+'/search/'+search+'.html'
	fs7D0d3QyAT(url)
	return
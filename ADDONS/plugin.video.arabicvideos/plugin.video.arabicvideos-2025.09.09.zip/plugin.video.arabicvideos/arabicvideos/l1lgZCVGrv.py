# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'CIMANOW'
Z0BYJQghVL1v87CAem = '_CMN_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['قائمتي']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==300: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==301: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==302: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==303: ka7jz96YCdTBnQOLVPuJG3285MHf = XTVdM7xH3Z9vEKna1uq2plbWy(url)
	elif mode==304: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==305: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==306: ka7jz96YCdTBnQOLVPuJG3285MHf = NNq5VBrDKEfJ8he()
	elif mode==309: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,309,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8+'/home',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<header(.*?)</header>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('<li><a href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if not any(value in title for value in MqARWHDkmiT4nlz):
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,301)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	ffy5vVCNau6FWgbmp(gAVl1vUmus8+'/home',Sw0pOFoVhPeIxbl)
	return Sw0pOFoVhPeIxbl
def NNq5VBrDKEfJ8he():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def ffy5vVCNau6FWgbmp(url,Sw0pOFoVhPeIxbl=sCHVtMAvqirbQ4BUK3cgWo):
	if not Sw0pOFoVhPeIxbl:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-SUBMENU-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	nkjHK2zQeb4vBuoaxPZTqIALW5S1 = 0
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(<section>.*?</section>)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		for Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			nkjHK2zQeb4vBuoaxPZTqIALW5S1 += 1
			items = fNntYJW45mEFSdRX8g.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for title,hBbgtZLX2dnuk,B17r2fdFy9ns8tiOMLu in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				if title==sCHVtMAvqirbQ4BUK3cgWo: title = 'بووووو'
				if 'em><a' not in hBbgtZLX2dnuk:
					if Po9h3gWFuLR2.count('/category/')>0:
						tF8cULEI3N7 = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
						for B17r2fdFy9ns8tiOMLu in tF8cULEI3N7:
							title = B17r2fdFy9ns8tiOMLu.split('/')[-2]
							XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,301)
						continue
					else: B17r2fdFy9ns8tiOMLu = url+'?sequence='+str(nkjHK2zQeb4vBuoaxPZTqIALW5S1)
				if not any(value in title for value in MqARWHDkmiT4nlz):
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,302)
	else: fs7D0d3QyAT(url,Sw0pOFoVhPeIxbl)
	return
def fs7D0d3QyAT(url,Sw0pOFoVhPeIxbl=sCHVtMAvqirbQ4BUK3cgWo):
	if Sw0pOFoVhPeIxbl==sCHVtMAvqirbQ4BUK3cgWo:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if '?sequence=' in url:
		url,nkjHK2zQeb4vBuoaxPZTqIALW5S1 = url.split('?sequence=')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(<section>.*?</section>)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[int(nkjHK2zQeb4vBuoaxPZTqIALW5S1)-1]
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"posts"(.*?)</body>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for B17r2fdFy9ns8tiOMLu,data,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		title = fNntYJW45mEFSdRX8g.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,fNntYJW45mEFSdRX8g.DOTALL)
		if title: title = title[0][2].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		if not title or title==sCHVtMAvqirbQ4BUK3cgWo:
			title = fNntYJW45mEFSdRX8g.findall('title">.*?</em>(.*?)<',data,fNntYJW45mEFSdRX8g.DOTALL)
			if title: title = title[0].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			if not title or title==sCHVtMAvqirbQ4BUK3cgWo:
				title = fNntYJW45mEFSdRX8g.findall('title">(.*?)<',data,fNntYJW45mEFSdRX8g.DOTALL)
				title = title[0].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		title = tt36wUe4HTPFmfs5hcbr(title)
		title = title.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
			AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			MtCcgLOoBTGp4nqzVhYJliX8Zva6s = B17r2fdFy9ns8tiOMLu+data+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
			if '/selary/' in MtCcgLOoBTGp4nqzVhYJliX8Zva6s or 'مسلسل' in MtCcgLOoBTGp4nqzVhYJliX8Zva6s or '"episode"' in MtCcgLOoBTGp4nqzVhYJliX8Zva6s:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,303,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,305,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<li><a href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,302)
	return
def XTVdM7xH3Z9vEKna1uq2plbWy(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-SEASONS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	name = fNntYJW45mEFSdRX8g.findall('<title>(.*?)</title>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',sCHVtMAvqirbQ4BUK3cgWo).replace('Cima Now',sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		name = name.split('الحلقة')[0].strip(AAh0X3OCacr4HpifRGLZKT)+' - '
	else: name = sCHVtMAvqirbQ4BUK3cgWo
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<section(.*?)</section>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)>1:
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = name+title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,304)
		elif len(items)==1:
			B17r2fdFy9ns8tiOMLu,title = items[0]
			VzOBjnIkZSH7ft(B17r2fdFy9ns8tiOMLu)
		else: VzOBjnIkZSH7ft(url)
	return
def VzOBjnIkZSH7ft(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if '/selary/' not in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"episodes"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			title = 'الحلقة '+title
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,305)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"details"(.*?)"related"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,305,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	SxoCubQzinw0ZEjpPs4rR8BlTK6 = fNntYJW45mEFSdRX8g.findall('class="shine" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if SxoCubQzinw0ZEjpPs4rR8BlTK6:
		smh8Qbf9jH = GABnmSFOwtsu37(SxoCubQzinw0ZEjpPs4rR8BlTK6[0],'url')
		headers = {'Referer':smh8Qbf9jH}
	else: headers = sCHVtMAvqirbQ4BUK3cgWo
	vrEJRkchKxtDNiqO1b79mL5eT = url+'watching/'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMANOW-PLAY-5th')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"download"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			XO7Zr2W6kwieA = fNntYJW45mEFSdRX8g.findall('\d\d\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if XO7Zr2W6kwieA:
				XO7Zr2W6kwieA = '____'+XO7Zr2W6kwieA[0]
				title = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
			else: XO7Zr2W6kwieA = sCHVtMAvqirbQ4BUK3cgWo
			NroHCBWaxUZOfbgqMzAL4vJ2 = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+XO7Zr2W6kwieA
			ss7YGDbuAIxgnqaQroTV.append(NroHCBWaxUZOfbgqMzAL4vJ2)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"watch"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('"embed".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
			title = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__embed'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		PXFtqmw5lBGQNa0IV8 = [gAVl1vUmus8+'/wp-content/themes/Cima%20Now%20New/core.php']
		if PXFtqmw5lBGQNa0IV8:
			items = fNntYJW45mEFSdRX8g.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for nTxciHKjwprDmO,id,title in items:
				title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[0]+'?action=switch&index='+nTxciHKjwprDmO+'&id='+id+'?named='+title+'__watch'
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8 + '/?s='+search
	fs7D0d3QyAT(url)
	return
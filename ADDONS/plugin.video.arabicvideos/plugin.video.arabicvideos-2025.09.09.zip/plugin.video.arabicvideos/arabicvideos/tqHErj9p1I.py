# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from nd6qWvh3Ve import *
class ARlfkgH0P1XtmOF9rKQdSesoWi(aNe7DOTW1st3bMQp9URuZhj4riV):
	def __init__(thP1UxTJWikB5QSNM9ERdDIbOpfZ,*aargs,**kkwargs):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.choiceID = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	def onClick(thP1UxTJWikB5QSNM9ERdDIbOpfZ,lzbCeg835jVmnqDuHo1w2rfE):
		if lzbCeg835jVmnqDuHo1w2rfE>=RDwahqjPfbdyEiTtnLQu(u"࠺࠲࠴࠴ઝ"): thP1UxTJWikB5QSNM9ERdDIbOpfZ.choiceID = lzbCeg835jVmnqDuHo1w2rfE-RDwahqjPfbdyEiTtnLQu(u"࠺࠲࠴࠴ઝ")
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.vJHCj59sVmcOP1ZpqTGi6NKQMD()
	def jOE1YD5Q8tHidkrFIT3(thP1UxTJWikB5QSNM9ERdDIbOpfZ,*aargs):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.button0,thP1UxTJWikB5QSNM9ERdDIbOpfZ.button1,thP1UxTJWikB5QSNM9ERdDIbOpfZ.button2 = aargs[BewrUo9ANCa17G43Sn0LH5xh],aargs[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.header,thP1UxTJWikB5QSNM9ERdDIbOpfZ.text = aargs[vUnJhT2NO8yirHcAmg],aargs[kK7gj9HE462hADJbvr]
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.profile,thP1UxTJWikB5QSNM9ERdDIbOpfZ.direction = aargs[BWfpRku7SsM6cbE0eG(u"࠷ઞ")],aargs[SE97R3Dpj6dPLweVKU(u"࠹ટ")]
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout,thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout = aargs[fvYGxnZNUiyP4HJkMIoS25(u"࠼ડ")],aargs[sH6BOz5wKRFcEg(u"࠼ઠ")]
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout>BewrUo9ANCa17G43Sn0LH5xh or thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout>SE97R3Dpj6dPLweVKU(u"࠶ઢ"): thP1UxTJWikB5QSNM9ERdDIbOpfZ.enable_progressbar = ndkUxG9LtewJ
		else: thP1UxTJWikB5QSNM9ERdDIbOpfZ.enable_progressbar = lvzrYTpcBaK
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename = EysacJBh8vHLKUlmjzNqY670WAbiuC.replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧਉ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡡࠪਊ")+str(hDjf1Ubgq629nXlOvcFLH4Jw.time())+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡢࠫ਋"))
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename = thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename.replace(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡠࡡ࠭਌"),TzIj50KpohEOHx6CbZWqB(u"ࠫࡡࡢ࡜࡝ࠩ਍")).replace(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࠵࠯ࠨ਎"),YQNd4wejLSAVJ6T(u"࠭࠯࠰࠱࠲ࠫਏ"))
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_height = xYsdFIBfqz3P(thP1UxTJWikB5QSNM9ERdDIbOpfZ.button0,thP1UxTJWikB5QSNM9ERdDIbOpfZ.button1,thP1UxTJWikB5QSNM9ERdDIbOpfZ.button2,thP1UxTJWikB5QSNM9ERdDIbOpfZ.header,thP1UxTJWikB5QSNM9ERdDIbOpfZ.text,thP1UxTJWikB5QSNM9ERdDIbOpfZ.profile,thP1UxTJWikB5QSNM9ERdDIbOpfZ.direction,thP1UxTJWikB5QSNM9ERdDIbOpfZ.enable_progressbar,thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename)
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.show()
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(YQNd4wejLSAVJ6T(u"࠹࠱࠷࠳ણ")).setImage(thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename)
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(oVwa0kcqxj1e7mLplAfZdGT(u"࠺࠲࠸࠴ત")).setHeight(thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_height)
		if not thP1UxTJWikB5QSNM9ERdDIbOpfZ.button1 and thP1UxTJWikB5QSNM9ERdDIbOpfZ.button0 and thP1UxTJWikB5QSNM9ERdDIbOpfZ.button2: thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(TzIj50KpohEOHx6CbZWqB(u"࠼࠴࠶࠸દ")).setPosition(-Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠶࠷࠶ધ"),qeG16a4pbSHziNVQ2uFXrs(u"࠲થ"))
		return thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename,thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_height
	def OQnAYJgN9CKe(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout:
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.th1 = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=thP1UxTJWikB5QSNM9ERdDIbOpfZ.SnJostVF0h)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.th1.start()
		else: thP1UxTJWikB5QSNM9ERdDIbOpfZ.BfI7RxKMaO2oYqThw8m1yursD()
	def SnJostVF0h(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(TzIj50KpohEOHx6CbZWqB(u"࠾࠶࠲࠱ન")).setEnabled(ndkUxG9LtewJ)
		for ruCEzOyVgmGt9WHI7BSofF6d8 in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			CnI0XHdpLA1JPzMu = int(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠷࠰࠱઩")*ruCEzOyVgmGt9WHI7BSofF6d8/thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.SIKqTP4goaNuzVLQc(CnI0XHdpLA1JPzMu)
			if thP1UxTJWikB5QSNM9ERdDIbOpfZ.choiceID>Js61GTdX5wzMurUqi7Z(u"࠰પ"): break
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.BfI7RxKMaO2oYqThw8m1yursD()
	def ouA4m5qZJ7KlHT2gjFv1hzx9dN68(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout:
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.th2 = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=thP1UxTJWikB5QSNM9ERdDIbOpfZ.Z5J8osqnv1YxUreKjh)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.th2.start()
		else: thP1UxTJWikB5QSNM9ERdDIbOpfZ.BfI7RxKMaO2oYqThw8m1yursD()
	def Z5J8osqnv1YxUreKjh(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠺࠲࠵࠴ફ")).setEnabled(ndkUxG9LtewJ)
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(thP1UxTJWikB5QSNM9ERdDIbOpfZ.buttonstimeout)
		for ruCEzOyVgmGt9WHI7BSofF6d8 in range(thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			CnI0XHdpLA1JPzMu = int(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠳࠳࠴બ")*ruCEzOyVgmGt9WHI7BSofF6d8/thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.SIKqTP4goaNuzVLQc(CnI0XHdpLA1JPzMu)
			if thP1UxTJWikB5QSNM9ERdDIbOpfZ.choiceID>BewrUo9ANCa17G43Sn0LH5xh: break
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.closetimeout>BewrUo9ANCa17G43Sn0LH5xh: thP1UxTJWikB5QSNM9ERdDIbOpfZ.choiceID = SE97R3Dpj6dPLweVKU(u"࠴࠴ભ")
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.vJHCj59sVmcOP1ZpqTGi6NKQMD()
	def SIKqTP4goaNuzVLQc(thP1UxTJWikB5QSNM9ERdDIbOpfZ,CnI0XHdpLA1JPzMu):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.precent = CnI0XHdpLA1JPzMu
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(jwzOabysh0Z(u"࠽࠵࠸࠰મ")).setPercent(thP1UxTJWikB5QSNM9ERdDIbOpfZ.precent)
	def BfI7RxKMaO2oYqThw8m1yursD(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.button0: thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(aenpKvQCGVzhLXEdWiDIZ(u"࠾࠶࠱࠱ય")).setEnabled(ndkUxG9LtewJ)
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.button1: thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(RDwahqjPfbdyEiTtnLQu(u"࠿࠰࠲࠳ર")).setEnabled(ndkUxG9LtewJ)
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.button2: thP1UxTJWikB5QSNM9ERdDIbOpfZ.getControl(Js61GTdX5wzMurUqi7Z(u"࠹࠱࠳࠵઱")).setEnabled(ndkUxG9LtewJ)
	def vJHCj59sVmcOP1ZpqTGi6NKQMD(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.close()
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(thP1UxTJWikB5QSNM9ERdDIbOpfZ.image_filename)
		except: pass
def ZZDswXvceNFRhafpUtWELYCP(*aargs,**kkwargs):
	if aargs:
		direction = aargs[BewrUo9ANCa17G43Sn0LH5xh]
		RZm7QpeBkEMf6YidoPJACSvl = aargs[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if not direction: direction = SE97R3Dpj6dPLweVKU(u"ࠧࡤࡧࡱࡸࡪࡸࠧਐ")
		if not RZm7QpeBkEMf6YidoPJACSvl: RZm7QpeBkEMf6YidoPJACSvl = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨษึฮ๊ืวาࠩ਑")
		JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = slFfrUIWCowaBA7tce3iZbj8xn.join(aargs[zLjWeKu6JgNO7vocUD0Qpy(u"࠴લ"):])
	else: direction,RZm7QpeBkEMf6YidoPJACSvl,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF = sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"ࠩࡒࡏࠬ਒"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	bP5mf0Mo2nz(direction,sCHVtMAvqirbQ4BUK3cgWo,RZm7QpeBkEMf6YidoPJACSvl,sCHVtMAvqirbQ4BUK3cgWo,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,**kkwargs)
	return
def NVjFvLmZCYRu1S893eTf6dUbqJl(*aargs,**kkwargs):
	direction = aargs[BewrUo9ANCa17G43Sn0LH5xh]
	FzdaO2KUI8bsSD3 = aargs[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	aroXbNp3GI5WEQ = aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
	if aroXbNp3GI5WEQ or FzdaO2KUI8bsSD3: k9kSOUbW7cQXe6uzRvijshVFTmB = ndkUxG9LtewJ
	else: k9kSOUbW7cQXe6uzRvijshVFTmB = lvzrYTpcBaK
	JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = aargs[vUnJhT2NO8yirHcAmg]
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = aargs[kK7gj9HE462hADJbvr]
	if not direction: direction = sH6BOz5wKRFcEg(u"ࠪࡧࡪࡴࡴࡦࡴࠪਓ")
	if not FzdaO2KUI8bsSD3: FzdaO2KUI8bsSD3 = YQNd4wejLSAVJ6T(u"่๊ࠫวࠡࠢࡑࡳࠬਔ")
	if not aroXbNp3GI5WEQ: aroXbNp3GI5WEQ = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧਕ")
	if len(aargs)>=Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠹઴"): TqNvzBxf1KpPDg3SRA4yj2mwcVF += slFfrUIWCowaBA7tce3iZbj8xn+aargs[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠷ળ")]
	if len(aargs)>=Js61GTdX5wzMurUqi7Z(u"࠻વ"): TqNvzBxf1KpPDg3SRA4yj2mwcVF += slFfrUIWCowaBA7tce3iZbj8xn+aargs[bGzRdmOErkIylxALniq6(u"࠻શ")]
	WQOh7NoUEJuHgGK0pzTrktyeLjxMB = bP5mf0Mo2nz(direction,FzdaO2KUI8bsSD3,sCHVtMAvqirbQ4BUK3cgWo,aroXbNp3GI5WEQ,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,**kkwargs)
	if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==-qeG16a4pbSHziNVQ2uFXrs(u"࠷ષ") and k9kSOUbW7cQXe6uzRvijshVFTmB: WQOh7NoUEJuHgGK0pzTrktyeLjxMB = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU and not k9kSOUbW7cQXe6uzRvijshVFTmB: WQOh7NoUEJuHgGK0pzTrktyeLjxMB = lvzrYTpcBaK
	elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==BewrUo9ANCa17G43Sn0LH5xh: WQOh7NoUEJuHgGK0pzTrktyeLjxMB = lvzrYTpcBaK
	elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==rgpY5VUqKbeFOCD9Nki2SmGvxEja: WQOh7NoUEJuHgGK0pzTrktyeLjxMB = ndkUxG9LtewJ
	return WQOh7NoUEJuHgGK0pzTrktyeLjxMB
def Wdlg19qZ4apQtYFCINvBeML0c(*aargs,**kkwargs):
	return qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Dialog().select(*aargs,**kkwargs)
def iRaHzNpJhSx6ZnCfrvD7j93lks(*aargs,**kkwargs):
	JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = aargs[BewrUo9ANCa17G43Sn0LH5xh]
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = aargs[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	X0NEpstWm1RlguHxCZIidbyLO = kkwargs[zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡴࡪ࡯ࡨࠫਖ")] if fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡵ࡫ࡰࡩࠬਗ") in list(kkwargs.keys()) else aYH620Dh48GEsTFfOBSQ7r(u"࠱࠱࠲࠳સ")
	cZmDS8oHAKQbl6k9xguFEtILO = aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja] if len(aargs)>rgpY5VUqKbeFOCD9Nki2SmGvxEja and iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡶ࡬ࡱࡪ࠭ਘ") not in aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja] else XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩਙ")
	BMscHRxPIvdGhaFZ0Vo9Er4jX = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=f8ADIjd6Pa1lSq57pt,args=(JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,cZmDS8oHAKQbl6k9xguFEtILO,X0NEpstWm1RlguHxCZIidbyLO))
	BMscHRxPIvdGhaFZ0Vo9Er4jX.start()
	return
def f8ADIjd6Pa1lSq57pt(JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,cZmDS8oHAKQbl6k9xguFEtILO,X0NEpstWm1RlguHxCZIidbyLO):
	EdD0OcyWb3h9omz2lSFexpVQ = cZmDS8oHAKQbl6k9xguFEtILO.replace(SE97R3Dpj6dPLweVKU(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪਚ"),sCHVtMAvqirbQ4BUK3cgWo)
	name = qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(ndkUxG9LtewJ,EdD0OcyWb3h9omz2lSFexpVQ+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࠥ࠳ࠠࠨਛ")+JQFmSGbDjgUZ0OYKPEhqzRXTlpnV+jwzOabysh0Z(u"ࠬࠦ࠭ࠡࠩਜ")+TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	name = ij3WwceDrmqafJy6Lsx4S9GCFuP(name)
	image_filename = YYEXZsUWhf52vz7HLxc0qGJ.path.join(wagflpRqFe,name+zLjWeKu6JgNO7vocUD0Qpy(u"࠭࠮ࡱࡰࡪࠫਝ"))
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(image_filename):
		if cZmDS8oHAKQbl6k9xguFEtILO==EJgYdjbIiWe1apkQlZcR42(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧਞ"): image_height = IOHSz7YPF9WusGgUt1Dq(u"࠲࠳࠺હ")
		elif cZmDS8oHAKQbl6k9xguFEtILO==SE97R3Dpj6dPLweVKU(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬਟ"): image_height = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠴࠴࠴઺")
	else: image_height = xYsdFIBfqz3P(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,cZmDS8oHAKQbl6k9xguFEtILO,gDETKVh8mZe09Nd(u"ࠩ࡯ࡩ࡫ࡺࠧਠ"),lvzrYTpcBaK,image_filename)
	cCgLhTmB5zS4e = aNe7DOTW1st3bMQp9URuZhj4riV(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪਡ"),ffBvikd9sV,hPFcB6Uxmabj59Iq(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬਢ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠽࠲࠱ࡲࠪਣ"))
	cCgLhTmB5zS4e.show()
	if cZmDS8oHAKQbl6k9xguFEtILO==SE97R3Dpj6dPLweVKU(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪਤ"):
		cCgLhTmB5zS4e.getControl(t19ZOVHA4CpwFKaeiubcMGvz(u"࠽࠵࠺࠰઼")).setHeight(qeG16a4pbSHziNVQ2uFXrs(u"࠵࠵࠺઻"))
		cCgLhTmB5zS4e.getControl(BWfpRku7SsM6cbE0eG(u"࠹࠱࠶࠳િ")).setPosition(RDwahqjPfbdyEiTtnLQu(u"࠺࠻ઽ"),-iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠾࠰ા"))
		cCgLhTmB5zS4e.getControl(qeG16a4pbSHziNVQ2uFXrs(u"࠺࠲࠸࠴ી")).setPosition(IO7k2hZXSz(u"࠳࠵࠴ુ"),-iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠹࠴ૂ"))
		cCgLhTmB5zS4e.getControl(BWfpRku7SsM6cbE0eG(u"࠺࠰࠱ૅ")).setPosition(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠽࠵ૃ"),-bGzRdmOErkIylxALniq6(u"࠸࠻ૄ"))
	cCgLhTmB5zS4e.getControl(BWfpRku7SsM6cbE0eG(u"࠴࠱࠳૆")).setVisible(lvzrYTpcBaK)
	cCgLhTmB5zS4e.getControl(RDwahqjPfbdyEiTtnLQu(u"࠵࠲࠵ે")).setVisible(lvzrYTpcBaK)
	cCgLhTmB5zS4e.getControl(IOHSz7YPF9WusGgUt1Dq(u"࠻࠳࠹࠵ૈ")).setImage(image_filename)
	cCgLhTmB5zS4e.getControl(aenpKvQCGVzhLXEdWiDIZ(u"࠼࠴࠺࠶ૉ")).setHeight(image_height)
	hDjf1Ubgq629nXlOvcFLH4Jw.sleep(X0NEpstWm1RlguHxCZIidbyLO//Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠵࠵࠶࠰࠯࠲૊"))
	return
def aMy5eXwi3xguBjzEV(*aargs,**kkwargs):
	JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,profile,direction = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਥ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࡮ࡨࡪࡹ࠭ਦ")
	if len(aargs)>=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = aargs[BewrUo9ANCa17G43Sn0LH5xh]
	if len(aargs)>=rgpY5VUqKbeFOCD9Nki2SmGvxEja: TqNvzBxf1KpPDg3SRA4yj2mwcVF = aargs[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	if len(aargs)>=vUnJhT2NO8yirHcAmg: profile = aargs[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
	if len(aargs)>=kK7gj9HE462hADJbvr: direction = aargs[vUnJhT2NO8yirHcAmg]
	return ctjhP4l8L5pbwqZuQo3VYr(direction,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,profile)
def jEu4OHoLUhPNk(*aargs,**kkwargs):
	return qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Dialog().contextmenu(*aargs,**kkwargs)
def c6aXnvizlYyZjem(*aargs,**kkwargs):
	return qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Dialog().browseSingle(*aargs,**kkwargs)
def HISfnDvUOcLzuA7m5VXk6egoq(*aargs,**kkwargs):
	return qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Dialog().input(*aargs,**kkwargs)
def xSIYZduC9imekB7c0J6oOa82FVnNU(*aargs,**kkwargs):
	return qqtbjl02E5pUOdQ1yMn8xABJsVG67w.DialogProgress(*aargs,**kkwargs)
def bP5mf0Mo2nz(direction,button0=sCHVtMAvqirbQ4BUK3cgWo,button1=sCHVtMAvqirbQ4BUK3cgWo,button2=sCHVtMAvqirbQ4BUK3cgWo,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV=sCHVtMAvqirbQ4BUK3cgWo,TqNvzBxf1KpPDg3SRA4yj2mwcVF=sCHVtMAvqirbQ4BUK3cgWo,profile=IO7k2hZXSz(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫਧ"),gXoqTyCvwcpsjPhD=BewrUo9ANCa17G43Sn0LH5xh,xjBItVKHSGyNpeE9=BewrUo9ANCa17G43Sn0LH5xh):
	if not direction: direction = SE97R3Dpj6dPLweVKU(u"ࠪࡧࡪࡴࡴࡦࡴࠪਨ")
	cCgLhTmB5zS4e = ARlfkgH0P1XtmOF9rKQdSesoWi(Js61GTdX5wzMurUqi7Z(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭਩"),ffBvikd9sV,BWfpRku7SsM6cbE0eG(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ਪ"),qqw1upCsKM(u"࠭࠷࠳࠲ࡳࠫਫ"))
	cCgLhTmB5zS4e.jOE1YD5Q8tHidkrFIT3(button0,button1,button2,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,profile,direction,gXoqTyCvwcpsjPhD,xjBItVKHSGyNpeE9)
	if gXoqTyCvwcpsjPhD>BewrUo9ANCa17G43Sn0LH5xh: cCgLhTmB5zS4e.OQnAYJgN9CKe()
	if xjBItVKHSGyNpeE9>BewrUo9ANCa17G43Sn0LH5xh: cCgLhTmB5zS4e.ouA4m5qZJ7KlHT2gjFv1hzx9dN68()
	if gXoqTyCvwcpsjPhD==BewrUo9ANCa17G43Sn0LH5xh and xjBItVKHSGyNpeE9==BewrUo9ANCa17G43Sn0LH5xh: cCgLhTmB5zS4e.BfI7RxKMaO2oYqThw8m1yursD()
	cCgLhTmB5zS4e.doModal()
	WQOh7NoUEJuHgGK0pzTrktyeLjxMB = cCgLhTmB5zS4e.choiceID
	return WQOh7NoUEJuHgGK0pzTrktyeLjxMB
def ctjhP4l8L5pbwqZuQo3VYr(direction,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,profile=Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨਬ")):
	if not direction: direction = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡮ࡨࡪࡹ࠭ਭ")
	cCgLhTmB5zS4e = aNe7DOTW1st3bMQp9URuZhj4riV(hPFcB6Uxmabj59Iq(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬਮ"),ffBvikd9sV,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫਯ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠼࠸࠰ࡱࠩਰ"))
	image_filename = EysacJBh8vHLKUlmjzNqY670WAbiuC.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ਱"),gDETKVh8mZe09Nd(u"࠭࡟ࠨਲ")+str(hDjf1Ubgq629nXlOvcFLH4Jw.time())+bGzRdmOErkIylxALniq6(u"ࠧࡠࠩਲ਼"))
	image_filename = image_filename.replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࡞࡟ࠫ਴"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࡟ࡠࡡࡢࠧਵ")).replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠪ࠳࠴࠭ਸ਼"),TzIj50KpohEOHx6CbZWqB(u"ࠫ࠴࠵࠯࠰ࠩ਷"))
	image_height = xYsdFIBfqz3P(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,profile,direction,lvzrYTpcBaK,image_filename)
	cCgLhTmB5zS4e.show()
	cCgLhTmB5zS4e.getControl(BWfpRku7SsM6cbE0eG(u"࠾࠶࠵࠱ો")).setHeight(image_height)
	cCgLhTmB5zS4e.getControl(t19ZOVHA4CpwFKaeiubcMGvz(u"࠿࠰࠶࠲ૌ")).setImage(image_filename)
	EEAmpOW4IoViLx6D958YPc21B = cCgLhTmB5zS4e.doModal()
	try: YYEXZsUWhf52vz7HLxc0qGJ.remove(image_filename)
	except: pass
	return EEAmpOW4IoViLx6D958YPc21B
def xYsdFIBfqz3P(oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv):
	nBPJmCSwXRef = YYEXZsUWhf52vz7HLxc0qGJ.path.dirname(TubPMk85WZRwzrqJI1FAlv)
	if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(nBPJmCSwXRef):
		try: YYEXZsUWhf52vz7HLxc0qGJ.makedirs(nBPJmCSwXRef)
		except: pass
	nzPTctjDi7pvrS81 = e756M1PWwU(RRtlz6e2I8jnc)
	HH0DAPjIetYMV3 = WiD0ZTYyQJFdbOhsLPza36(nzPTctjDi7pvrS81,oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv)
	return HH0DAPjIetYMV3
def e756M1PWwU(RRtlz6e2I8jnc):
	hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo = tBMCpcY2vUV1dEjZ7PDG
	a29fyUe57Fj8qVrKigEoBtMA = oVwa0kcqxj1e7mLplAfZdGT(u"࠲࠱્")
	fB37CUp54Rn0NzGglHurjvAXVw = Js61GTdX5wzMurUqi7Z(u"࠳࠲૎")
	ck5DG3KwtvBzIj = BewrUo9ANCa17G43Sn0LH5xh
	IIq0PATcrX6lido8UeC1y7jHu = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬਸ")
	XObuCsJgLwGYz0eM375vVA = BewrUo9ANCa17G43Sn0LH5xh
	MVxSXB9JWbji1 = SE97R3Dpj6dPLweVKU(u"࠳࠼૏")
	mmVStIAKqJhLWcR7UEM3TsYefN = aenpKvQCGVzhLXEdWiDIZ(u"࠶࠴ૐ")
	KHkXJioWAjl4whu96GPpOE5cL = SE97R3Dpj6dPLweVKU(u"࠼૑")
	w3OosjS6Agbi5EL = ndkUxG9LtewJ
	uej7Hh39ET = YQNd4wejLSAVJ6T(u"࠸࠽࠵૒")
	TTdJmk5aCOb4ZSRxwLHAjl = t19ZOVHA4CpwFKaeiubcMGvz(u"࠺࠱࠱૓")
	Znv64F7myW2CLEPGeXzikuDTxo1 = SE97R3Dpj6dPLweVKU(u"࠵࠱૔")
	jAeKE1l3kTUPsIq6NWi = XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠳࠺࠳૕")
	i5Zpxoulz3WYBQeHGa9r7sFw = t19ZOVHA4CpwFKaeiubcMGvz(u"࠴࠻૖")
	rMnHFaW7cT9hxye5g0uPCU = tBMCpcY2vUV1dEjZ7PDG
	AuBxtZPOI4F2MCseSrLyGg3vnE6 = BewrUo9ANCa17G43Sn0LH5xh
	Bu8xLVHPbSiK3EfG64QrYDngjI = SE97R3Dpj6dPLweVKU(u"࠶࠵૗")
	h7a1PcOKrIjni0kb9gl3me6CL = [gDETKVh8mZe09Nd(u"࠹࠶૚"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠷࠷૘"),aenpKvQCGVzhLXEdWiDIZ(u"࠷࠾૙")]
	from PIL import ImageDraw as WifTQeMkcR07KZouJVYvls4h,ImageFont as BfexTtRADqZL8iFSwVoYN2yHaMvOn,Image as MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye
	if E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬਹ") in RRtlz6e2I8jnc:
		if RRtlz6e2I8jnc==GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ਺"):
			oMI7Z1rWmNaJgze = RDwahqjPfbdyEiTtnLQu(u"࠱࠲࠹૛")
			IIq0PATcrX6lido8UeC1y7jHu = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ࡮ࡨࡪࡹ࠭਻")
			w3OosjS6Agbi5EL = lvzrYTpcBaK
		elif RRtlz6e2I8jnc==aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ਼࠭"):
			oMI7Z1rWmNaJgze = IOHSz7YPF9WusGgUt1Dq(u"࡙ࠪࡕࡖࡅࡓࠩ਽")
			IIq0PATcrX6lido8UeC1y7jHu = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡷ࡯ࡧࡩࡶࠪਾ")
			ck5DG3KwtvBzIj = hPFcB6Uxmabj59Iq(u"࠲࠲૜")
		LTIt1XG4rZCh0 = YQNd4wejLSAVJ6T(u"࠹࠵࠴૝")
		h7a1PcOKrIjni0kb9gl3me6CL = [aenpKvQCGVzhLXEdWiDIZ(u"࠶࠷૞"),aenpKvQCGVzhLXEdWiDIZ(u"࠶࠷૞"),aenpKvQCGVzhLXEdWiDIZ(u"࠶࠷૞")]
		fB37CUp54Rn0NzGglHurjvAXVw = qeG16a4pbSHziNVQ2uFXrs(u"࠶࠵૟")
		a29fyUe57Fj8qVrKigEoBtMA = BewrUo9ANCa17G43Sn0LH5xh
		mmVStIAKqJhLWcR7UEM3TsYefN = aenpKvQCGVzhLXEdWiDIZ(u"࠷࠶ૠ")
		MVxSXB9JWbji1 = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠹࠵ૡ")
	elif RRtlz6e2I8jnc==Js61GTdX5wzMurUqi7Z(u"ࠬࡳࡥ࡯ࡷࡢ࡭ࡹ࡫࡭ࠨਿ"):
		h7a1PcOKrIjni0kb9gl3me6CL,LTIt1XG4rZCh0,oMI7Z1rWmNaJgze = [hPFcB6Uxmabj59Iq(u"࠴࠻૤"),hPFcB6Uxmabj59Iq(u"࠴࠻૤"),hPFcB6Uxmabj59Iq(u"࠴࠻૤")],qeG16a4pbSHziNVQ2uFXrs(u"࠲࠱࠲ૢ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠳࠷࠳ૣ")
		XObuCsJgLwGYz0eM375vVA,mmVStIAKqJhLWcR7UEM3TsYefN,MVxSXB9JWbji1, = BewrUo9ANCa17G43Sn0LH5xh,-TzIj50KpohEOHx6CbZWqB(u"࠴࠶૥"),-fvYGxnZNUiyP4HJkMIoS25(u"࠷࠵૦")
		a29fyUe57Fj8qVrKigEoBtMA = BewrUo9ANCa17G43Sn0LH5xh
		VVXWPnLj3h8Iz5q0ATb7M = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.open(vcUEd8DY4u6zXiO1o)
		dIuwilQVa6T1FBc = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.new(qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡒࡈࡄࡄࠫੀ"),(LTIt1XG4rZCh0,oMI7Z1rWmNaJgze),(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠷࠻࠵૧"),BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠷࠻࠵૧")))
	elif RRtlz6e2I8jnc==qqw1upCsKM(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੁ"): h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠴࠻૫"),YQNd4wejLSAVJ6T(u"࠸࠴૨"),GVurlv8HeoXEzPRiQB7Ty(u"࠲࠱૩")],Js61GTdX5wzMurUqi7Z(u"࠸࠴࠵૬"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠺࠲࠳૪")
	elif RRtlz6e2I8jnc==RDwahqjPfbdyEiTtnLQu(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ੂ"): h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [zLjWeKu6JgNO7vocUD0Qpy(u"࠸࠸૮"),EJgYdjbIiWe1apkQlZcR42(u"࠲࠹૰"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠶࠹૭")],YQNd4wejLSAVJ6T(u"࠶࠲࠳૱"),gDETKVh8mZe09Nd(u"࠿࠰࠱૯")
	elif RRtlz6e2I8jnc==SIkwCEdJHTD9v1(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ੃"): h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠸࠼૵"),RDwahqjPfbdyEiTtnLQu(u"࠵࠵૲"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠶࠽૴")],E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠻࠰࠱૶"),qqw1upCsKM(u"࠼࠴࠵૳")
	elif RRtlz6e2I8jnc==zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭੄"): oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = aYH620Dh48GEsTFfOBSQ7r(u"࠷࠵࠲૷"),oVwa0kcqxj1e7mLplAfZdGT(u"࠲࠴࠺࠴૸")
	elif RRtlz6e2I8jnc==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ੅"): oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = aYH620Dh48GEsTFfOBSQ7r(u"࡛ࠬࡐࡑࡇࡕࠫ੆"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠳࠵࠻࠵ૹ")
	elif RRtlz6e2I8jnc==IOHSz7YPF9WusGgUt1Dq(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫੇ"): h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [GVurlv8HeoXEzPRiQB7Ty(u"࠸࠸૽"),hPFcB6Uxmabj59Iq(u"࠲࠴૾"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠵࠽ૻ")],jwzOabysh0Z(u"࠺࠸࠵ૺ"),bGzRdmOErkIylxALniq6(u"࠶࠸࠷࠱ૼ")
	elif RRtlz6e2I8jnc==oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪੈ"): h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [bGzRdmOErkIylxALniq6(u"࠵࠼ଁ"),RDwahqjPfbdyEiTtnLQu(u"࠶࠸ଂ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠳࠻଀")],IOHSz7YPF9WusGgUt1Dq(u"ࠨࡗࡓࡔࡊࡘࠧ੉"),gDETKVh8mZe09Nd(u"࠲࠴࠺࠴૿")
	wnaDyx7CM9vzYJmG0SfXU1jdsOH,ox1ZuFje7l2fkL0i,TOkXQumgw35BFioY6njpJtMEyD0qb = h7a1PcOKrIjni0kb9gl3me6CL
	b6b1UxHaEDWyoYqeL2PRuS5XNtMOl = BfexTtRADqZL8iFSwVoYN2yHaMvOn.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=wnaDyx7CM9vzYJmG0SfXU1jdsOH)
	NrVZ3LRFPs5 = BfexTtRADqZL8iFSwVoYN2yHaMvOn.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=ox1ZuFje7l2fkL0i)
	dBkIzjaxtmA19PyHCNuX67fn8 = BfexTtRADqZL8iFSwVoYN2yHaMvOn.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=TOkXQumgw35BFioY6njpJtMEyD0qb)
	UckbZ20dDejFg = LTIt1XG4rZCh0-mmVStIAKqJhLWcR7UEM3TsYefN*rgpY5VUqKbeFOCD9Nki2SmGvxEja
	RnoqYA81baVHQwvJZhkieCPgL3XtE = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.new(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡕࡋࡇࡇࠧ੊"),(UckbZ20dDejFg,EJgYdjbIiWe1apkQlZcR42(u"࠶࠶࠰ଃ")),(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠸࠵࠶଄"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠸࠵࠶଄"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠸࠵࠶଄"),BewrUo9ANCa17G43Sn0LH5xh))
	ggh2EzTxfV8c5sl47 = WifTQeMkcR07KZouJVYvls4h.Draw(RnoqYA81baVHQwvJZhkieCPgL3XtE)
	kDRFWdOxeM059oCH3zXV4,nHF4m1bZYrcjstGUPa = ggh2EzTxfV8c5sl47.textsize(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬੋ"),font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl)
	MdbzSxVDFPB,LAnc5aRsbQ8feCqO = ggh2EzTxfV8c5sl47.textsize(SIkwCEdJHTD9v1(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ੌ"),font=NrVZ3LRFPs5)
	QRSuEI6CMYNd8B7hgkTrqc = {Js61GTdX5wzMurUqi7Z(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡮ࡡࡳࡣ࡮ࡥࡹ੍࠭"):lvzrYTpcBaK,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡳࡶࡲࡳࡳࡷࡺ࡟࡭࡫ࡪࡥࡹࡻࡲࡦࡵࠪ੎"):ndkUxG9LtewJ,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡂࡔࡄࡆࡎࡉࠠࡍࡋࡊࡅ࡙࡛ࡒࡆࠢࡄࡐࡑࡇࡈࠨ੏"):lvzrYTpcBaK}
	from arabic_reshaper import ArabicReshaper as liLRuEyc2G9no
	hvXMB9VWELz8l = liLRuEyc2G9no(configuration=QRSuEI6CMYNd8B7hgkTrqc)
	nzPTctjDi7pvrS81 = {}
	G20KTjWFfs9V = locals()
	for FCYq34IhByUnfKRi1GS5pmD6Vzd7ju in G20KTjWFfs9V: nzPTctjDi7pvrS81[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju] = G20KTjWFfs9V[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju]
	return nzPTctjDi7pvrS81
def WiD0ZTYyQJFdbOhsLPza36(nzPTctjDi7pvrS81,oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv):
	for FCYq34IhByUnfKRi1GS5pmD6Vzd7ju in nzPTctjDi7pvrS81: globals()[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju] = nzPTctjDi7pvrS81[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju]
	global i5Zpxoulz3WYBQeHGa9r7sFw,rMnHFaW7cT9hxye5g0uPCU
	if RRtlz6e2I8jnc!=qeG16a4pbSHziNVQ2uFXrs(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ੐"):
		lnd8TJjXS4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(sH6BOz5wKRFcEg(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪੑ"))
		if lnd8TJjXS4:
			if oIra9JvSTHjFx1Z==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬ੒"): oIra9JvSTHjFx1Z = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫ࡞࡫ࡳࠨ੓")
			elif oIra9JvSTHjFx1Z==bGzRdmOErkIylxALniq6(u"้ࠬไศࠢࠣࡒࡴ࠭੔"): oIra9JvSTHjFx1Z = RDwahqjPfbdyEiTtnLQu(u"࠭ࡎࡰࠩ੕")
			if Wrh9Yna5jc==E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩ੖"): Wrh9Yna5jc = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨ࡛ࡨࡷࠬ੗")
			elif Wrh9Yna5jc==EJgYdjbIiWe1apkQlZcR42(u"ࠩๆ่ฬࠦࠠࡏࡱࠪ੘"): Wrh9Yna5jc = SIkwCEdJHTD9v1(u"ࠪࡒࡴ࠭ਖ਼")
			if CXsBGz3FiMS601LyJOc4oKjbT5Rh==sH6BOz5wKRFcEg(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ਗ਼"): CXsBGz3FiMS601LyJOc4oKjbT5Rh = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࡟ࡥࡴࠩਜ਼")
			elif CXsBGz3FiMS601LyJOc4oKjbT5Rh==BWfpRku7SsM6cbE0eG(u"࠭ใๅษࠣࠤࡓࡵࠧੜ"): CXsBGz3FiMS601LyJOc4oKjbT5Rh = SE97R3Dpj6dPLweVKU(u"ࠧࡏࡱࠪ੝")
			PaQp3oz49JfRdYbywq = J7YQHOxiBW0SrcXCwaN5dmf2ZRAKp([oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN])
			if PaQp3oz49JfRdYbywq: oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN = PaQp3oz49JfRdYbywq
	if qdUK5ioJyrO1T:
		T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		II2lAsxMPkyUH8 = II2lAsxMPkyUH8.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		oIra9JvSTHjFx1Z = oIra9JvSTHjFx1Z.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		Wrh9Yna5jc = Wrh9Yna5jc.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		CXsBGz3FiMS601LyJOc4oKjbT5Rh = CXsBGz3FiMS601LyJOc4oKjbT5Rh.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	SmFfYHy6tZVB = II2lAsxMPkyUH8.count(slFfrUIWCowaBA7tce3iZbj8xn)+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	TXfVLgQsJOMPkEC95GjUuiYpn = a29fyUe57Fj8qVrKigEoBtMA+SmFfYHy6tZVB*(nHF4m1bZYrcjstGUPa+ck5DG3KwtvBzIj)-ck5DG3KwtvBzIj
	if T67f3LG49xpP8zcN:
		LUZugd8opYADI = LAnc5aRsbQ8feCqO+KHkXJioWAjl4whu96GPpOE5cL
		IrgvU0ZftXsmnYTpwH = hvXMB9VWELz8l.reshape(T67f3LG49xpP8zcN)
		if w3OosjS6Agbi5EL:
			jiBcXPaIq8sEx6n9 = o5IXWZjB6fQu7T1NdA(ggh2EzTxfV8c5sl47,NrVZ3LRFPs5,IrgvU0ZftXsmnYTpwH,ox1ZuFje7l2fkL0i,UckbZ20dDejFg,LUZugd8opYADI)
			Yji8HZntyzO2TUr9d = CvZSWkKsoRNYmnp7IhgOufr4(jiBcXPaIq8sEx6n9)
			RyB8Wbcr3zgSP1UJwk = Yji8HZntyzO2TUr9d.count(slFfrUIWCowaBA7tce3iZbj8xn)+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			CQKfX8hTSap = MVxSXB9JWbji1+RyB8Wbcr3zgSP1UJwk*LUZugd8opYADI-KHkXJioWAjl4whu96GPpOE5cL
		else:
			CQKfX8hTSap = MVxSXB9JWbji1+LAnc5aRsbQ8feCqO
			Yji8HZntyzO2TUr9d = IrgvU0ZftXsmnYTpwH.split(slFfrUIWCowaBA7tce3iZbj8xn)[BewrUo9ANCa17G43Sn0LH5xh]
			jiBcXPaIq8sEx6n9 = IrgvU0ZftXsmnYTpwH.split(slFfrUIWCowaBA7tce3iZbj8xn)[BewrUo9ANCa17G43Sn0LH5xh]
	else: CQKfX8hTSap = MVxSXB9JWbji1
	QYk0XERuxAbmNrDH49yov = AuBxtZPOI4F2MCseSrLyGg3vnE6+Bu8xLVHPbSiK3EfG64QrYDngjI
	if fVwySktquzhxdBRn03D:
		fcyQv5Ud0m3IPnOgM7zT = TTdJmk5aCOb4ZSRxwLHAjl-uej7Hh39ET
		QYk0XERuxAbmNrDH49yov += fcyQv5Ud0m3IPnOgM7zT
	else: fcyQv5Ud0m3IPnOgM7zT = BewrUo9ANCa17G43Sn0LH5xh
	if oIra9JvSTHjFx1Z or Wrh9Yna5jc or CXsBGz3FiMS601LyJOc4oKjbT5Rh: QYk0XERuxAbmNrDH49yov += Znv64F7myW2CLEPGeXzikuDTxo1
	HH0DAPjIetYMV3 = oMI7Z1rWmNaJgze if oMI7Z1rWmNaJgze!=jwzOabysh0Z(u"ࠨࡗࡓࡔࡊࡘࠧਫ਼") else TXfVLgQsJOMPkEC95GjUuiYpn+CQKfX8hTSap+QYk0XERuxAbmNrDH49yov
	RnoqYA81baVHQwvJZhkieCPgL3XtE = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.new(sH6BOz5wKRFcEg(u"ࠩࡕࡋࡇࡇࠧ੟"),(LTIt1XG4rZCh0,HH0DAPjIetYMV3),(SE97R3Dpj6dPLweVKU(u"࠲࠶࠷ଅ"),SE97R3Dpj6dPLweVKU(u"࠲࠶࠷ଅ"),SE97R3Dpj6dPLweVKU(u"࠲࠶࠷ଅ"),BewrUo9ANCa17G43Sn0LH5xh))
	MMv0dpRCFlxcYTn5 = WifTQeMkcR07KZouJVYvls4h.Draw(RnoqYA81baVHQwvJZhkieCPgL3XtE)
	LnBWoMKYASTqgjGQvNs5DrH4 = HH0DAPjIetYMV3-TXfVLgQsJOMPkEC95GjUuiYpn-QYk0XERuxAbmNrDH49yov-MVxSXB9JWbji1
	if not Wrh9Yna5jc and oIra9JvSTHjFx1Z and CXsBGz3FiMS601LyJOc4oKjbT5Rh:
		i5Zpxoulz3WYBQeHGa9r7sFw += aenpKvQCGVzhLXEdWiDIZ(u"࠲࠲࠸ଆ")
		rMnHFaW7cT9hxye5g0uPCU -= GVurlv8HeoXEzPRiQB7Ty(u"࠳࠴࠴ଇ")
	import bidi.algorithm as KKIAFzsoVcRrT9
	if II2lAsxMPkyUH8:
		GZLdR4CbNqyiUQekun = a29fyUe57Fj8qVrKigEoBtMA
		II2lAsxMPkyUH8 = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(II2lAsxMPkyUH8))
		PCS2siEhbL = II2lAsxMPkyUH8.splitlines()
		for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
			if QXeuCy5v3cK4qEVBLzPabFUlAfGN0m:
				rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl)
				if IIq0PATcrX6lido8UeC1y7jHu==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡧࡪࡴࡴࡦࡴࠪ੠"): duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+(LTIt1XG4rZCh0-rhkm6OzYH87QTCJcs0DiR4Mox)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
				elif IIq0PATcrX6lido8UeC1y7jHu==SE97R3Dpj6dPLweVKU(u"ࠫࡷ࡯ࡧࡩࡶࠪ੡"): duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+LTIt1XG4rZCh0-rhkm6OzYH87QTCJcs0DiR4Mox-fB37CUp54Rn0NzGglHurjvAXVw
				elif IIq0PATcrX6lido8UeC1y7jHu==IO7k2hZXSz(u"ࠬࡲࡥࡧࡶࠪ੢"): duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+fB37CUp54Rn0NzGglHurjvAXVw
				MMv0dpRCFlxcYTn5.text((duNxLa39T2C,GZLdR4CbNqyiUQekun),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl,fill=jwzOabysh0Z(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭੣"))
			GZLdR4CbNqyiUQekun += wnaDyx7CM9vzYJmG0SfXU1jdsOH+ck5DG3KwtvBzIj
	if oIra9JvSTHjFx1Z or Wrh9Yna5jc or CXsBGz3FiMS601LyJOc4oKjbT5Rh:
		qS64NgRWvMrJ8DF1Ibwjc = TXfVLgQsJOMPkEC95GjUuiYpn+LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1+fcyQv5Ud0m3IPnOgM7zT+AuBxtZPOI4F2MCseSrLyGg3vnE6
		if oIra9JvSTHjFx1Z:
			oIra9JvSTHjFx1Z = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(oIra9JvSTHjFx1Z))
			c0VoSDtgiuFHI5pZ,OF04hqeDzIi9nQpR38gCKtSo = MMv0dpRCFlxcYTn5.textsize(oIra9JvSTHjFx1Z,font=dBkIzjaxtmA19PyHCNuX67fn8)
			SSMtFvgcGNo2jDT9HwuYkrOnl5hU8 = i5Zpxoulz3WYBQeHGa9r7sFw+BewrUo9ANCa17G43Sn0LH5xh*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-c0VoSDtgiuFHI5pZ)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((SSMtFvgcGNo2jDT9HwuYkrOnl5hU8,qS64NgRWvMrJ8DF1Ibwjc),oIra9JvSTHjFx1Z,font=dBkIzjaxtmA19PyHCNuX67fn8,fill=fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ੤"))
		if Wrh9Yna5jc:
			Wrh9Yna5jc = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(Wrh9Yna5jc))
			QQyUd9r38FNbGc,hZKdzHwa3nuykf4JRMc = MMv0dpRCFlxcYTn5.textsize(Wrh9Yna5jc,font=dBkIzjaxtmA19PyHCNuX67fn8)
			o2TFuvnzqcI15XyYGsaSkg = i5Zpxoulz3WYBQeHGa9r7sFw+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-QQyUd9r38FNbGc)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((o2TFuvnzqcI15XyYGsaSkg,qS64NgRWvMrJ8DF1Ibwjc),Wrh9Yna5jc,font=dBkIzjaxtmA19PyHCNuX67fn8,fill=IO7k2hZXSz(u"ࠨࡻࡨࡰࡱࡵࡷࠨ੥"))
		if CXsBGz3FiMS601LyJOc4oKjbT5Rh:
			CXsBGz3FiMS601LyJOc4oKjbT5Rh = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(CXsBGz3FiMS601LyJOc4oKjbT5Rh))
			Zare87wiP0do4lpIcFG,TcD6haEQXJl = MMv0dpRCFlxcYTn5.textsize(CXsBGz3FiMS601LyJOc4oKjbT5Rh,font=dBkIzjaxtmA19PyHCNuX67fn8)
			XeQazj5mr7n = i5Zpxoulz3WYBQeHGa9r7sFw+rgpY5VUqKbeFOCD9Nki2SmGvxEja*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-Zare87wiP0do4lpIcFG)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((XeQazj5mr7n,qS64NgRWvMrJ8DF1Ibwjc),CXsBGz3FiMS601LyJOc4oKjbT5Rh,font=dBkIzjaxtmA19PyHCNuX67fn8,fill=t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ੦"))
	if T67f3LG49xpP8zcN:
		nhapAbW6evX5tCi,OiX96NRy8HB1I0ZnFaJht3rpGTWM = [],[]
		jiBcXPaIq8sEx6n9 = BBYXwHyqUiTLCG3fhcZzgQ8(jiBcXPaIq8sEx6n9)
		bKXvpdiOwloPZzhFA5aI9trNx4nCM = jiBcXPaIq8sEx6n9.split(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ੧"))
		for bjIwotHlkAWc1ZCsgPJQV6eui7x in bKXvpdiOwloPZzhFA5aI9trNx4nCM:
			gJHQDsfcEPjBwd82t3Y = JUTpkxOQHBVZ5
			if   aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭੨") in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = jwzOabysh0Z(u"ࠬࡲࡥࡧࡶࠪ੩")
			elif YQNd4wejLSAVJ6T(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ੪") in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭੫")
			elif TzIj50KpohEOHx6CbZWqB(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ੬") in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = RDwahqjPfbdyEiTtnLQu(u"ࠩࡦࡩࡳࡺࡥࡳࠩ੭")
			RzDbac7IKWfBXm9ZPMtw = bjIwotHlkAWc1ZCsgPJQV6eui7x
			j1rxPg56UYSCIhR7ZkVeKL = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ੮"),bjIwotHlkAWc1ZCsgPJQV6eui7x,fNntYJW45mEFSdRX8g.DOTALL)
			for apym85Pd0MzHq64ItJEVOT in j1rxPg56UYSCIhR7ZkVeKL: RzDbac7IKWfBXm9ZPMtw = RzDbac7IKWfBXm9ZPMtw.replace(apym85Pd0MzHq64ItJEVOT,sCHVtMAvqirbQ4BUK3cgWo)
			if RzDbac7IKWfBXm9ZPMtw==sCHVtMAvqirbQ4BUK3cgWo: rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = BewrUo9ANCa17G43Sn0LH5xh,LUZugd8opYADI
			else: rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(RzDbac7IKWfBXm9ZPMtw,font=NrVZ3LRFPs5)
			if   gJHQDsfcEPjBwd82t3Y==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡱ࡫ࡦࡵࠩ੯"): dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN
			elif gJHQDsfcEPjBwd82t3Y==aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡸࡩࡨࡪࡷࠫੰ"): dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN+UckbZ20dDejFg-rhkm6OzYH87QTCJcs0DiR4Mox
			elif gJHQDsfcEPjBwd82t3Y==E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ੱ"): dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN+(UckbZ20dDejFg-rhkm6OzYH87QTCJcs0DiR4Mox)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			if dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1<mmVStIAKqJhLWcR7UEM3TsYefN: dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN
			nhapAbW6evX5tCi.append(dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1)
			OiX96NRy8HB1I0ZnFaJht3rpGTWM.append(rhkm6OzYH87QTCJcs0DiR4Mox)
		dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = nhapAbW6evX5tCi[BewrUo9ANCa17G43Sn0LH5xh]
		RNWfyoQawsSxDmL = jiBcXPaIq8sEx6n9.split(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡠࡵࡶࡷࡤ࠭ੲ"))
		g96zSBYUm37lLn = (qeG16a4pbSHziNVQ2uFXrs(u"࠵࠹࠺ଈ"),qeG16a4pbSHziNVQ2uFXrs(u"࠵࠹࠺ଈ"),qeG16a4pbSHziNVQ2uFXrs(u"࠵࠹࠺ଈ"),qeG16a4pbSHziNVQ2uFXrs(u"࠵࠹࠺ଈ"))
		wXzR7vmOngylaDd9EH2qftMpsb0Wuo = g96zSBYUm37lLn
		boMtO7FXAdlEag,SoNdClO5PAnEhkwVR9KXr = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
		ySU0z7cBD3mMxdCPi = lvzrYTpcBaK
		AkvaK6WezXLFRjqxtM3T8d7oc1uQD = BewrUo9ANCa17G43Sn0LH5xh
		iVEPe8hHw6fZ9aop4Lmv = TXfVLgQsJOMPkEC95GjUuiYpn+MVxSXB9JWbji1/rgpY5VUqKbeFOCD9Nki2SmGvxEja
		if CQKfX8hTSap<(LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1):
			SMAKGqJDtu7g = (LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1-CQKfX8hTSap)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			iVEPe8hHw6fZ9aop4Lmv = TXfVLgQsJOMPkEC95GjUuiYpn+MVxSXB9JWbji1+SMAKGqJDtu7g-LAnc5aRsbQ8feCqO/rgpY5VUqKbeFOCD9Nki2SmGvxEja
		for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in RNWfyoQawsSxDmL:
			if not QXeuCy5v3cK4qEVBLzPabFUlAfGN0m or (QXeuCy5v3cK4qEVBLzPabFUlAfGN0m and ord(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[BewrUo9ANCa17G43Sn0LH5xh])==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠺࠺࠸࠷࠺ଉ")): continue
			HJ8lCvFKsbQn5IYqxDt7 = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(SE97R3Dpj6dPLweVKU(u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫੳ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			TslkEYuPemcq = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(bGzRdmOErkIylxALniq6(u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬੴ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			xUfZnApo4RcCbw1NleaOIry5DBL9GY = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(Js61GTdX5wzMurUqi7Z(u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧੵ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			lBOgrhU3IJA1aXfcNH = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ੶"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			XBdwygbaAhVN = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ੷"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			iGTynS50DLflzduKbO17kx6QA = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(jwzOabysh0Z(u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ੸"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			fQcSnmUrwPH39g = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭੹"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			if len(HJ8lCvFKsbQn5IYqxDt7)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				AkvaK6WezXLFRjqxtM3T8d7oc1uQD += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = HJ8lCvFKsbQn5IYqxDt7[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				boMtO7FXAdlEag = BewrUo9ANCa17G43Sn0LH5xh
				dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = nhapAbW6evX5tCi[AkvaK6WezXLFRjqxtM3T8d7oc1uQD]
				SoNdClO5PAnEhkwVR9KXr += LUZugd8opYADI
				ySU0z7cBD3mMxdCPi = lvzrYTpcBaK
			elif len(TslkEYuPemcq)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = TslkEYuPemcq[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[BewrUo9ANCa17G43Sn0LH5xh:qeG16a4pbSHziNVQ2uFXrs(u"࠽ଊ")]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = qqw1upCsKM(u"ࠨࠥࠪ੺")+wXzR7vmOngylaDd9EH2qftMpsb0Wuo[rgpY5VUqKbeFOCD9Nki2SmGvxEja:]
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠿ଋ"):]
			elif len(xUfZnApo4RcCbw1NleaOIry5DBL9GY)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = xUfZnApo4RcCbw1NleaOIry5DBL9GY[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = g96zSBYUm37lLn
			elif len(lBOgrhU3IJA1aXfcNH)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = lBOgrhU3IJA1aXfcNH[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				ySU0z7cBD3mMxdCPi = ndkUxG9LtewJ
				boMtO7FXAdlEag = OiX96NRy8HB1I0ZnFaJht3rpGTWM[AkvaK6WezXLFRjqxtM3T8d7oc1uQD]
			elif len(XBdwygbaAhVN)>aYH620Dh48GEsTFfOBSQ7r(u"࠱ଌ"): QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = XBdwygbaAhVN[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			elif len(iGTynS50DLflzduKbO17kx6QA)>qeG16a4pbSHziNVQ2uFXrs(u"࠲଍"): QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = iGTynS50DLflzduKbO17kx6QA[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			elif len(fQcSnmUrwPH39g)>E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳଎"): QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = fQcSnmUrwPH39g[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			if QXeuCy5v3cK4qEVBLzPabFUlAfGN0m:
				fUypeQitldr7 = iVEPe8hHw6fZ9aop4Lmv+SoNdClO5PAnEhkwVR9KXr
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = KKIAFzsoVcRrT9.get_display(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m)
				rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5)
				if ySU0z7cBD3mMxdCPi: boMtO7FXAdlEag -= rhkm6OzYH87QTCJcs0DiR4Mox
				otdpUiax59SIP6ebhcLqD7FuZJVr = dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1+boMtO7FXAdlEag
				MMv0dpRCFlxcYTn5.text((otdpUiax59SIP6ebhcLqD7FuZJVr,fUypeQitldr7),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5,fill=wXzR7vmOngylaDd9EH2qftMpsb0Wuo)
				if RRtlz6e2I8jnc==zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ੻"): MMv0dpRCFlxcYTn5.text((otdpUiax59SIP6ebhcLqD7FuZJVr+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,fUypeQitldr7+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5,fill=wXzR7vmOngylaDd9EH2qftMpsb0Wuo)
				if not ySU0z7cBD3mMxdCPi: boMtO7FXAdlEag += rhkm6OzYH87QTCJcs0DiR4Mox
				if fUypeQitldr7>LnBWoMKYASTqgjGQvNs5DrH4+LUZugd8opYADI: break
	if RRtlz6e2I8jnc==YQNd4wejLSAVJ6T(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭੼"):
		S4UZknpfuJt5brycwPj = VVXWPnLj3h8Iz5q0ATb7M.copy()
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(BWfpRku7SsM6cbE0eG(u"࠳࠲࠵࠻ଏ"))
		S4UZknpfuJt5brycwPj.paste(dIuwilQVa6T1FBc,(BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh),mask=RnoqYA81baVHQwvJZhkieCPgL3XtE)
	else: S4UZknpfuJt5brycwPj = RnoqYA81baVHQwvJZhkieCPgL3XtE
	if qdUK5ioJyrO1T: TubPMk85WZRwzrqJI1FAlv = TubPMk85WZRwzrqJI1FAlv.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	try: S4UZknpfuJt5brycwPj.save(TubPMk85WZRwzrqJI1FAlv)
	except UnicodeError:
		if qdUK5ioJyrO1T:
			TubPMk85WZRwzrqJI1FAlv = TubPMk85WZRwzrqJI1FAlv.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			S4UZknpfuJt5brycwPj.save(TubPMk85WZRwzrqJI1FAlv)
	return HH0DAPjIetYMV3
def o5IXWZjB6fQu7T1NdA(ggh2EzTxfV8c5sl47,NrVZ3LRFPs5,rtkvdDL8Hugy,owFcBgpMP3nzTfO,UckbZ20dDejFg,veDZ67muyJp):
	R8gkMNxsIaLDfoXjyOnQhe,bbjSo3FKdYRxa4g7rzIsiThBOQ,KKZRWLAOlvbMTo98nzhESrIV5cj2mH = sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh,Js61GTdX5wzMurUqi7Z(u"࠵࠺࠶࠰࠱ଐ")
	rtkvdDL8Hugy = rtkvdDL8Hugy.replace(qqw1upCsKM(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ੽"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ੾"))
	Or4zBtT5yjoGkR69QmFngqb = UckbZ20dDejFg-owFcBgpMP3nzTfO*rgpY5VUqKbeFOCD9Nki2SmGvxEja
	for ryszSPJMwcRiQXEumZ in rtkvdDL8Hugy.splitlines():
		bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
		X8TVbKNQOvChRcwAUzqnuG,rrjF0lpnM1 = BewrUo9ANCa17G43Sn0LH5xh,sCHVtMAvqirbQ4BUK3cgWo
		for jQGoEi4HPVkK3svrM5Z in ryszSPJMwcRiQXEumZ.split(AAh0X3OCacr4HpifRGLZKT):
			d5FhmKRjuvGSt = CvZSWkKsoRNYmnp7IhgOufr4(AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z)
			FFaP9lE0MnWjskZeNoR21B8vx,qgbc3JhIZkF46SWiXRYzVdUA = ggh2EzTxfV8c5sl47.textsize(d5FhmKRjuvGSt,font=NrVZ3LRFPs5)
			if X8TVbKNQOvChRcwAUzqnuG+FFaP9lE0MnWjskZeNoR21B8vx<Or4zBtT5yjoGkR69QmFngqb:
				if not rrjF0lpnM1: rrjF0lpnM1 += jQGoEi4HPVkK3svrM5Z
				else: rrjF0lpnM1 += AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z
				X8TVbKNQOvChRcwAUzqnuG += FFaP9lE0MnWjskZeNoR21B8vx
			else:
				if FFaP9lE0MnWjskZeNoR21B8vx<Or4zBtT5yjoGkR69QmFngqb:
					rrjF0lpnM1 += EJgYdjbIiWe1apkQlZcR42(u"࠭࡜࡯ࠢࠪ੿")+jQGoEi4HPVkK3svrM5Z
					bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
					X8TVbKNQOvChRcwAUzqnuG = FFaP9lE0MnWjskZeNoR21B8vx
				else:
					while FFaP9lE0MnWjskZeNoR21B8vx>Or4zBtT5yjoGkR69QmFngqb:
						for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,len(AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
							wGQ1UViarZt8TK6zF9Rp = AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z[:qT1ZRz0VMiXQhxFUPdJC2u9asvrN]
							D3MxqnLQjZFRg0yNH8vC = jQGoEi4HPVkK3svrM5Z[qT1ZRz0VMiXQhxFUPdJC2u9asvrN:]
							gYaToe6zSu4nc1NWCXv8 = CvZSWkKsoRNYmnp7IhgOufr4(wGQ1UViarZt8TK6zF9Rp)
							c1hmuk36stDWNvE49ipYC7rZUS,nnms1w34hSFzDQToCJ = ggh2EzTxfV8c5sl47.textsize(gYaToe6zSu4nc1NWCXv8,font=NrVZ3LRFPs5)
							if X8TVbKNQOvChRcwAUzqnuG+c1hmuk36stDWNvE49ipYC7rZUS>Or4zBtT5yjoGkR69QmFngqb:
								eTSMFJpPkcOvb = FFaP9lE0MnWjskZeNoR21B8vx-c1hmuk36stDWNvE49ipYC7rZUS
								rrjF0lpnM1 += wGQ1UViarZt8TK6zF9Rp+slFfrUIWCowaBA7tce3iZbj8xn
								bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
								FFaP9lE0MnWjskZeNoR21B8vx = eTSMFJpPkcOvb
								if eTSMFJpPkcOvb>Or4zBtT5yjoGkR69QmFngqb:
									X8TVbKNQOvChRcwAUzqnuG = BewrUo9ANCa17G43Sn0LH5xh
									jQGoEi4HPVkK3svrM5Z = D3MxqnLQjZFRg0yNH8vC
								else:
									X8TVbKNQOvChRcwAUzqnuG = eTSMFJpPkcOvb
									rrjF0lpnM1 += D3MxqnLQjZFRg0yNH8vC
								break
				if bbjSo3FKdYRxa4g7rzIsiThBOQ>KKZRWLAOlvbMTo98nzhESrIV5cj2mH: break
		R8gkMNxsIaLDfoXjyOnQhe += slFfrUIWCowaBA7tce3iZbj8xn+rrjF0lpnM1
		if bbjSo3FKdYRxa4g7rzIsiThBOQ>KKZRWLAOlvbMTo98nzhESrIV5cj2mH: break
	R8gkMNxsIaLDfoXjyOnQhe = R8gkMNxsIaLDfoXjyOnQhe[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
	R8gkMNxsIaLDfoXjyOnQhe = R8gkMNxsIaLDfoXjyOnQhe.replace(SIkwCEdJHTD9v1(u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ઀"),SIkwCEdJHTD9v1(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩઁ"))
	return R8gkMNxsIaLDfoXjyOnQhe
def CvZSWkKsoRNYmnp7IhgOufr4(jQGoEi4HPVkK3svrM5Z):
	if TzIj50KpohEOHx6CbZWqB(u"ࠩ࡞ࠫં") in jQGoEi4HPVkK3svrM5Z and aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡡࠬઃ") in jQGoEi4HPVkK3svrM5Z:
		j1rxPg56UYSCIhR7ZkVeKL = [B8alA5nvIhTxQ,sH6BOz5wKRFcEg(u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ઄"),EJgYdjbIiWe1apkQlZcR42(u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭અ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨઆ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪઇ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࡝ࡕࡘࡑࡣࠧઈ"),SIkwCEdJHTD9v1(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩઉ"),SIkwCEdJHTD9v1(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫઊ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭ઋ")]
		IWLR5Qnlhv9O2dNUsb4cmtSgJVEiGu = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬઌ"),jQGoEi4HPVkK3svrM5Z,fNntYJW45mEFSdRX8g.DOTALL)
		nnsAL2wpV6ax1fiSYX5GlqPot7 = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨઍ"),jQGoEi4HPVkK3svrM5Z,fNntYJW45mEFSdRX8g.DOTALL)
		Bc0xOiyM2fv5 = j1rxPg56UYSCIhR7ZkVeKL+IWLR5Qnlhv9O2dNUsb4cmtSgJVEiGu+nnsAL2wpV6ax1fiSYX5GlqPot7
		for apym85Pd0MzHq64ItJEVOT in Bc0xOiyM2fv5: jQGoEi4HPVkK3svrM5Z = jQGoEi4HPVkK3svrM5Z.replace(apym85Pd0MzHq64ItJEVOT,sCHVtMAvqirbQ4BUK3cgWo)
	return jQGoEi4HPVkK3svrM5Z
def BBYXwHyqUiTLCG3fhcZzgQ8(T67f3LG49xpP8zcN):
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(slFfrUIWCowaBA7tce3iZbj8xn,qqw1upCsKM(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ઎"))
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(qqw1upCsKM(u"ࠨ࡝ࡕࡘࡑࡣࠧએ"),sH6BOz5wKRFcEg(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪઐ"))
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪઑ"),IOHSz7YPF9WusGgUt1Dq(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭઒"))
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭ઓ"),qqw1upCsKM(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩઔ"))
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩક"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬખ"))
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(B8alA5nvIhTxQ,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫગ"))
	bBQXe49Icj = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬઘ"),T67f3LG49xpP8zcN,fNntYJW45mEFSdRX8g.DOTALL)
	for p64PCz0clvJ8Z5nXOxDEaQuI3k2i in bBQXe49Icj: T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬઙ")+p64PCz0clvJ8Z5nXOxDEaQuI3k2i+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡣࠧચ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧછ")+p64PCz0clvJ8Z5nXOxDEaQuI3k2i+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡠࠩજ"))
	return T67f3LG49xpP8zcN
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'MOVS4U'
Z0BYJQghVL1v87CAem = '_M4U_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['انواع افلام','جودات افلام']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==380: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==381: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==382: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==383: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==389: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,389,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',gAVl1vUmus8,381,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الجانبية',gAVl1vUmus8,381,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'sider')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'MOVS4U-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall('<header>.*?<h2>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for nkjHK2zQeb4vBuoaxPZTqIALW5S1 in range(len(items)):
		title = items[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,gAVl1vUmus8,381,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'latest'+str(nkjHK2zQeb4vBuoaxPZTqIALW5S1))
	Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu"(.*?)id="contenedor"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 += oPnz7Zt4xLHTwR[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="sidebar(.*?)aside',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 += oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	trd5bZgxTR = True
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		if title=='الأعلى مشاهدة':
			if trd5bZgxTR:
				title = 'الافلام '+title
				trd5bZgxTR = False
			else: title = 'المسلسلات '+title
		if title not in MqARWHDkmiT4nlz:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,381)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,type):
	Po9h3gWFuLR2,items = [],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'MOVS4U-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if type=='search':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="search-page"(.*?)class="sidebar',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='sider':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="widget(.*?)class="widget',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		UiCoactjPvXf04QKV = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		ss7YGDbuAIxgnqaQroTV,T3bQnXl7ZSaYLiC8FR0PIWqOB,V9TdsglcWYv0X = zip(*UiCoactjPvXf04QKV)
		items = zip(T3bQnXl7ZSaYLiC8FR0PIWqOB,ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X)
	elif type=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="slider-movies-tvshows"(.*?)<header>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif 'latest' in type:
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = int(type[-1:])
		Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('<header>','<end><start>')
		Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('<div class="sidebar','<end><div class="sidebar')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<start>(.*?)<end>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
		if nkjHK2zQeb4vBuoaxPZTqIALW5S1==2: items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="content"(.*?)class="(pagination|sidebar)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0][0]
			if '/collection/' in url:
				items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			elif '/quality/' in url:
				items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items and Po9h3gWFuLR2:
		items = fNntYJW45mEFSdRX8g.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		if 'serie' in title:
			title = fNntYJW45mEFSdRX8g.findall('^(.*?)<.*?serie">(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
			title = title[0][1]
			if title in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ: continue
			AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			title = '_MOD_'+title
		dwDUvp0LAuyg1rI = fNntYJW45mEFSdRX8g.findall('^(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
		if dwDUvp0LAuyg1rI: title = dwDUvp0LAuyg1rI[0]
		title = tt36wUe4HTPFmfs5hcbr(title)
		if '/tvshows/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,383,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/episodes/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,383,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/seasons/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,383,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/collection/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,381,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,382,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		ryHBlJhLE3xDodaMsFZe = oPnz7Zt4xLHTwR[0][0]
		CCHMJEumLSxl = oPnz7Zt4xLHTwR[0][1]
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0][2]
		items = fNntYJW45mEFSdRX8g.findall("href='(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title==sCHVtMAvqirbQ4BUK3cgWo or title==CCHMJEumLSxl: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,381,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('/page/'+title+'/','/page/'+CCHMJEumLSxl+'/')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'اخر صفحة '+CCHMJEumLSxl,B17r2fdFy9ns8tiOMLu,381,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'MOVS4U-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('class="C rated".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7,False):
		XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+'المسلسل للكبار والمبرمج منعه',sCHVtMAvqirbQ4BUK3cgWo,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('''class='item'><a href="(.*?)"''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if vrEJRkchKxtDNiqO1b79mL5eT:
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[1]
			VzOBjnIkZSH7ft(vrEJRkchKxtDNiqO1b79mL5eT)
			return
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''class='episodios'(.*?)id="cast"''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,bbFPOJrmkCaE6ul37XiKU,B17r2fdFy9ns8tiOMLu,name in items:
			title = bbFPOJrmkCaE6ul37XiKU+' : '+name+' الحلقة'
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,382)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'MOVS4U-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('class="C rated".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0][0]
		items = fNntYJW45mEFSdRX8g.findall("data-url='(.*?)'.*?class='server'>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="remodal"(.*?)class="remodal-close"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url,'search')
	return
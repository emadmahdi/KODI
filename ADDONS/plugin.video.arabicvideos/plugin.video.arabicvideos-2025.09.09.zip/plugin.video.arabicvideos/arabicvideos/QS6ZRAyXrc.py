# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'YOUTUBE'
Z0BYJQghVL1v87CAem = '_YUT_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
h5wFNra3VdCfctlsPTjqnup2yJEmIO = 0
def dBHD1Vl7hQuNOY(mode,url,text,type,mRwrKW6fNZV,name,Qp3jGv8leCbuiEU5Im):
	if	 mode==140: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==141: ka7jz96YCdTBnQOLVPuJG3285MHf = Xs2FgT9Dld4BvHwSK(url,name,Qp3jGv8leCbuiEU5Im)
	elif mode==143: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url,type)
	elif mode==144: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV,text)
	elif mode==145: ka7jz96YCdTBnQOLVPuJG3285MHf = gt9WJMRHNs8c0kpSDoGbOIrnU(url,mRwrKW6fNZV)
	elif mode==147: ka7jz96YCdTBnQOLVPuJG3285MHf = SSL839Yov6Fx()
	elif mode==148: ka7jz96YCdTBnQOLVPuJG3285MHf = RabDto4vMVJFc9uA5WxICB()
	elif mode==149: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	if 0:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'قائمة 1',gAVl1vUmus8+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'قائمة 2',gAVl1vUmus8+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'شخص',gAVl1vUmus8+'/user/TCNofficial',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'موقع',gAVl1vUmus8+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'حساب',gAVl1vUmus8+'/@TheSocialCTV',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'العاب',gAVl1vUmus8+'/gaming',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'افلام',gAVl1vUmus8+'/feed/storefront',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مختارات',gAVl1vUmus8+'/feed/guide_builder',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'قصيرة',gAVl1vUmus8+'/shorts',144,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'تصفح',gAVl1vUmus8+'/youtubei/v1/guide?key=',144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'رئيسية',gAVl1vUmus8+sCHVtMAvqirbQ4BUK3cgWo,144)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'رائج',gAVl1vUmus8+'/feed/trending?bp=',144)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,149,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الرائجة',gAVl1vUmus8+'/feed/trending',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'التصفح',gAVl1vUmus8+'/youtubei/v1/guide?key=',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'القصيرة',gAVl1vUmus8+'/shorts',144,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مختارات يوتيوب',gAVl1vUmus8+'/feed/guide_builder',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مختارات البرنامج',sCHVtMAvqirbQ4BUK3cgWo,290)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: قنوات عربية',sCHVtMAvqirbQ4BUK3cgWo,147)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: قنوات أجنبية',sCHVtMAvqirbQ4BUK3cgWo,148)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: افلام عربية',gAVl1vUmus8+'/results?search_query=فيلم',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: افلام اجنبية',gAVl1vUmus8+'/results?search_query=movie',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: مسرحيات عربية',gAVl1vUmus8+'/results?search_query=مسرحية',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: مسلسلات عربية',gAVl1vUmus8+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: مسلسلات اجنبية',gAVl1vUmus8+'/results?search_query=series&sp=EgIQAw==',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: مسلسلات كارتون',gAVl1vUmus8+'/results?search_query=كارتون&sp=EgIQAw==',144)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث: خطبة المرجعية',gAVl1vUmus8+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def Xs2FgT9Dld4BvHwSK(url,name,Qp3jGv8leCbuiEU5Im):
	name = nnXGrIdCOuVxENgQz3lsckS(name)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'CHNL:  '+name,url,144,Qp3jGv8leCbuiEU5Im)
	return
def SSL839Yov6Fx():
	fs7D0d3QyAT(gAVl1vUmus8+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def RabDto4vMVJFc9uA5WxICB():
	fs7D0d3QyAT(gAVl1vUmus8+'/results?search_query=tv&sp=EgJAAQ==')
	return
def YH54mqkD2eU06(url,type):
	url = url.split('&',1)[0]
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1([url],Ll1m0nJoaAPvHsXqyRE,type,url)
	return
def ftEjSqRWO1JwTmCyv8LNZ3KodQiH7(kDpWtBrX8YaQZnSsKTE,url,nTxciHKjwprDmO):
	level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = nTxciHKjwprDmO.split('::')
	sF6zTyIGjet9LJlNQdVC0,VVf2GITJE6SydglLe1aRtrN3nCP = [],[]
	if '/youtubei/v1/browse' in url: sF6zTyIGjet9LJlNQdVC0.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: sF6zTyIGjet9LJlNQdVC0.append("yccc['onResponseReceivedCommands']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': sF6zTyIGjet9LJlNQdVC0.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['entries']")
	sF6zTyIGjet9LJlNQdVC0.append("yccc['items'][3]['guideSectionRenderer']['items']")
	MweNfdicjkgpGzoJVLTOD,eLqAWxDw8ZagGMhHyvNJfC,cxdy9whUzoLt37Ik = Gm0XTsVxiA8ORUWl6HEbQj(kDpWtBrX8YaQZnSsKTE,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
	if level=='1' and MweNfdicjkgpGzoJVLTOD:
		if len(eLqAWxDw8ZagGMhHyvNJfC)>1 and 'search_query' not in url:
			for WW94e5w08VbEuo1UvSCKyiBDMt in range(len(eLqAWxDw8ZagGMhHyvNJfC)):
				BXso7lYiGK3Dqx15Q = str(WW94e5w08VbEuo1UvSCKyiBDMt)
				sF6zTyIGjet9LJlNQdVC0 = []
				sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['reloadContinuationItemsCommand']['continuationItems']")
				sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['command']")
				sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]")
				bEZlOa1inyrUgdTw9BKNtcMCLYI,UqKgalXPCz7eQAL08foMx1R,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(eLqAWxDw8ZagGMhHyvNJfC,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
				if bEZlOa1inyrUgdTw9BKNtcMCLYI: VVf2GITJE6SydglLe1aRtrN3nCP.append([UqKgalXPCz7eQAL08foMx1R,url,'2::'+BXso7lYiGK3Dqx15Q+'::0::0'])
			sF6zTyIGjet9LJlNQdVC0.append("yccc['continuationEndpoint']")
			bEZlOa1inyrUgdTw9BKNtcMCLYI,UqKgalXPCz7eQAL08foMx1R,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(kDpWtBrX8YaQZnSsKTE,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
			if bEZlOa1inyrUgdTw9BKNtcMCLYI and VVf2GITJE6SydglLe1aRtrN3nCP and 'continuationCommand' in list(UqKgalXPCz7eQAL08foMx1R.keys()):
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/my_main_page_shorts_link'
				VVf2GITJE6SydglLe1aRtrN3nCP.append([UqKgalXPCz7eQAL08foMx1R,B17r2fdFy9ns8tiOMLu,'1::0::0::0'])
	return eLqAWxDw8ZagGMhHyvNJfC,MweNfdicjkgpGzoJVLTOD,VVf2GITJE6SydglLe1aRtrN3nCP,cxdy9whUzoLt37Ik
def MNAnFJz1qIPt(kDpWtBrX8YaQZnSsKTE,eLqAWxDw8ZagGMhHyvNJfC,url,nTxciHKjwprDmO):
	level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = nTxciHKjwprDmO.split('::')
	sF6zTyIGjet9LJlNQdVC0,sIcQCfewdEzB4H6an1xhYWbSlLi = [],[]
	sF6zTyIGjet9LJlNQdVC0.append("yddd[0]['itemSectionRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['reloadContinuationItemsCommand']['continuationItems']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: sF6zTyIGjet9LJlNQdVC0.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: sF6zTyIGjet9LJlNQdVC0.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yddd["+BXso7lYiGK3Dqx15Q+"]")
	H5iLZGEv3PaFMtSYjNe,dQHMBWcUg46JYtXwk,hKW0rX1IYZEdM = Gm0XTsVxiA8ORUWl6HEbQj(eLqAWxDw8ZagGMhHyvNJfC,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
	if level=='2' and H5iLZGEv3PaFMtSYjNe:
		if len(dQHMBWcUg46JYtXwk)>1:
			for WW94e5w08VbEuo1UvSCKyiBDMt in range(len(dQHMBWcUg46JYtXwk)):
				krF5ZpjBbJ8tGW = str(WW94e5w08VbEuo1UvSCKyiBDMt)
				sF6zTyIGjet9LJlNQdVC0 = []
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['richSectionRenderer']['content']")
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]")
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['richItemRenderer']['content']")
				sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]")
				bEZlOa1inyrUgdTw9BKNtcMCLYI,UqKgalXPCz7eQAL08foMx1R,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(dQHMBWcUg46JYtXwk,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
				if bEZlOa1inyrUgdTw9BKNtcMCLYI: sIcQCfewdEzB4H6an1xhYWbSlLi.append([UqKgalXPCz7eQAL08foMx1R,url,'3::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::0'])
			sF6zTyIGjet9LJlNQdVC0.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			sF6zTyIGjet9LJlNQdVC0.append("yddd[1]")
			bEZlOa1inyrUgdTw9BKNtcMCLYI,UqKgalXPCz7eQAL08foMx1R,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(eLqAWxDw8ZagGMhHyvNJfC,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
			if bEZlOa1inyrUgdTw9BKNtcMCLYI and sIcQCfewdEzB4H6an1xhYWbSlLi and 'continuationItemRenderer' in list(UqKgalXPCz7eQAL08foMx1R.keys()):
				sIcQCfewdEzB4H6an1xhYWbSlLi.append([UqKgalXPCz7eQAL08foMx1R,url,'3::0::0::0'])
	return dQHMBWcUg46JYtXwk,H5iLZGEv3PaFMtSYjNe,sIcQCfewdEzB4H6an1xhYWbSlLi,hKW0rX1IYZEdM
def TG0MIX2lSz4UFVgoOWb(kDpWtBrX8YaQZnSsKTE,dQHMBWcUg46JYtXwk,url,nTxciHKjwprDmO):
	level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = nTxciHKjwprDmO.split('::')
	sF6zTyIGjet9LJlNQdVC0,CufyoW2OZqXK = [],[]
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['reelShelfRenderer']['items']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee["+krF5ZpjBbJ8tGW+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	sF6zTyIGjet9LJlNQdVC0.append("yeee")
	ZzNgeikb4CQd,RzavUgomqFjElNtDe2W10GSZuT4i9,zb1wUkD4NixHRvGP = Gm0XTsVxiA8ORUWl6HEbQj(dQHMBWcUg46JYtXwk,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
	if level=='3' and ZzNgeikb4CQd:
		if len(RzavUgomqFjElNtDe2W10GSZuT4i9)>0:
			for WW94e5w08VbEuo1UvSCKyiBDMt in range(len(RzavUgomqFjElNtDe2W10GSZuT4i9)):
				Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = str(WW94e5w08VbEuo1UvSCKyiBDMt)
				sF6zTyIGjet9LJlNQdVC0 = []
				sF6zTyIGjet9LJlNQdVC0.append("yfff["+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7+"]['richItemRenderer']['content']")
				sF6zTyIGjet9LJlNQdVC0.append("yfff["+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7+"]['gameCardRenderer']['game']")
				sF6zTyIGjet9LJlNQdVC0.append("yfff["+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7+"]['itemSectionRenderer']['contents'][0]")
				sF6zTyIGjet9LJlNQdVC0.append("yfff["+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7+"]")
				sF6zTyIGjet9LJlNQdVC0.append("yfff")
				bEZlOa1inyrUgdTw9BKNtcMCLYI,UqKgalXPCz7eQAL08foMx1R,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(RzavUgomqFjElNtDe2W10GSZuT4i9,sCHVtMAvqirbQ4BUK3cgWo,sF6zTyIGjet9LJlNQdVC0)
				if bEZlOa1inyrUgdTw9BKNtcMCLYI: CufyoW2OZqXK.append([UqKgalXPCz7eQAL08foMx1R,url,'4::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7])
	return RzavUgomqFjElNtDe2W10GSZuT4i9,ZzNgeikb4CQd,CufyoW2OZqXK,zb1wUkD4NixHRvGP
def Gm0XTsVxiA8ORUWl6HEbQj(YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa,HsD0jdhW4AUe39zkmwTiRn6xNg):
	kDpWtBrX8YaQZnSsKTE,oFtKYZryln32AsLqcjBgWODwpa = YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa
	eLqAWxDw8ZagGMhHyvNJfC,oFtKYZryln32AsLqcjBgWODwpa = YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa
	dQHMBWcUg46JYtXwk,oFtKYZryln32AsLqcjBgWODwpa = YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa
	RzavUgomqFjElNtDe2W10GSZuT4i9,oFtKYZryln32AsLqcjBgWODwpa = YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa
	UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL = YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa
	count = len(HsD0jdhW4AUe39zkmwTiRn6xNg)
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(count):
		try:
			NdyTY6FHwsagCGPnv = eval(HsD0jdhW4AUe39zkmwTiRn6xNg[ruCEzOyVgmGt9WHI7BSofF6d8])
			return True,NdyTY6FHwsagCGPnv,ruCEzOyVgmGt9WHI7BSofF6d8+1
		except: pass
	return False,sCHVtMAvqirbQ4BUK3cgWo,0
def fs7D0d3QyAT(url,nTxciHKjwprDmO=sCHVtMAvqirbQ4BUK3cgWo,data=sCHVtMAvqirbQ4BUK3cgWo):
	VVf2GITJE6SydglLe1aRtrN3nCP,sIcQCfewdEzB4H6an1xhYWbSlLi,CufyoW2OZqXK = [],[],[]
	if '::' not in nTxciHKjwprDmO: nTxciHKjwprDmO = '1::0::0::0'
	level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = nTxciHKjwprDmO.split('::')
	if level=='4': level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = '1',BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
	data = data.replace('_REMEMBERRESULTS_',sCHVtMAvqirbQ4BUK3cgWo)
	Sw0pOFoVhPeIxbl,kDpWtBrX8YaQZnSsKTE,i68iPmaHVAZknGv2SNpyzCwcFE = H168HdpnGbmLg(url,data)
	nTxciHKjwprDmO = level+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
	if level in ['1','2','3']:
		eLqAWxDw8ZagGMhHyvNJfC,MweNfdicjkgpGzoJVLTOD,VVf2GITJE6SydglLe1aRtrN3nCP,cxdy9whUzoLt37Ik = ftEjSqRWO1JwTmCyv8LNZ3KodQiH7(kDpWtBrX8YaQZnSsKTE,url,nTxciHKjwprDmO)
		if not MweNfdicjkgpGzoJVLTOD: return
		qphvbDJWHnoAZ7ajde4tI8lg = len(VVf2GITJE6SydglLe1aRtrN3nCP)
		if qphvbDJWHnoAZ7ajde4tI8lg<2:
			if level=='1': level = '2'
			VVf2GITJE6SydglLe1aRtrN3nCP = []
	nTxciHKjwprDmO = level+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
	if level in ['2','3']:
		dQHMBWcUg46JYtXwk,H5iLZGEv3PaFMtSYjNe,sIcQCfewdEzB4H6an1xhYWbSlLi,hKW0rX1IYZEdM = MNAnFJz1qIPt(kDpWtBrX8YaQZnSsKTE,eLqAWxDw8ZagGMhHyvNJfC,url,nTxciHKjwprDmO)
		if not H5iLZGEv3PaFMtSYjNe: return
		x1iFdU4kutEJPODIjWnyM37s2bC9z = len(sIcQCfewdEzB4H6an1xhYWbSlLi)
		if x1iFdU4kutEJPODIjWnyM37s2bC9z<2:
			if level=='2': level = '3'
			sIcQCfewdEzB4H6an1xhYWbSlLi = []
	nTxciHKjwprDmO = level+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
	if level in ['3']:
		RzavUgomqFjElNtDe2W10GSZuT4i9,ZzNgeikb4CQd,CufyoW2OZqXK,zb1wUkD4NixHRvGP = TG0MIX2lSz4UFVgoOWb(kDpWtBrX8YaQZnSsKTE,dQHMBWcUg46JYtXwk,url,nTxciHKjwprDmO)
		if not ZzNgeikb4CQd: return
		KVfpMWtx5lbycgNIid8 = len(CufyoW2OZqXK)
	for UqKgalXPCz7eQAL08foMx1R,url,nTxciHKjwprDmO in VVf2GITJE6SydglLe1aRtrN3nCP+sIcQCfewdEzB4H6an1xhYWbSlLi+CufyoW2OZqXK:
		aa0t2BHrOX8sdCm = nWrdX4LvTiQqcy8BN(UqKgalXPCz7eQAL08foMx1R,url,nTxciHKjwprDmO)
	return
def nWrdX4LvTiQqcy8BN(UqKgalXPCz7eQAL08foMx1R,url=sCHVtMAvqirbQ4BUK3cgWo,nTxciHKjwprDmO=sCHVtMAvqirbQ4BUK3cgWo):
	if '::' in nTxciHKjwprDmO: level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = nTxciHKjwprDmO.split('::')
	else: level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = '1','0','0','0'
	bEZlOa1inyrUgdTw9BKNtcMCLYI,title,B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count,yAMScJ6z3E8,jnzo1t7ID0EVH,WUICZqepnyE1,TTxVeZGHdw8E = t7AHGVsjhoOvPJSRuy6Mbzcf(UqKgalXPCz7eQAL08foMx1R)
	DJdqw1257bxYUocfmEAg = '/videos?' in B17r2fdFy9ns8tiOMLu or '/streams?' in B17r2fdFy9ns8tiOMLu or '/playlists?' in B17r2fdFy9ns8tiOMLu
	y5xOmdu2DwQJzcsjZtrFvM8UE = '/channels?' in B17r2fdFy9ns8tiOMLu or '/shorts?' in B17r2fdFy9ns8tiOMLu
	if DJdqw1257bxYUocfmEAg or y5xOmdu2DwQJzcsjZtrFvM8UE: B17r2fdFy9ns8tiOMLu = url
	DJdqw1257bxYUocfmEAg = 'watch?v=' not in B17r2fdFy9ns8tiOMLu and '/playlist?list=' not in B17r2fdFy9ns8tiOMLu
	y5xOmdu2DwQJzcsjZtrFvM8UE = '/gaming' not in B17r2fdFy9ns8tiOMLu  and '/feed/storefront' not in B17r2fdFy9ns8tiOMLu
	if nTxciHKjwprDmO[0:5]=='3::0::' and DJdqw1257bxYUocfmEAg and y5xOmdu2DwQJzcsjZtrFvM8UE: B17r2fdFy9ns8tiOMLu = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in B17r2fdFy9ns8tiOMLu:
		level,BXso7lYiGK3Dqx15Q,krF5ZpjBbJ8tGW,Jyufx3GEIh2pRCMcgXordnKNYO9Ua7 = '1','0','0','0'
		nTxciHKjwprDmO = sCHVtMAvqirbQ4BUK3cgWo
	i68iPmaHVAZknGv2SNpyzCwcFE = sCHVtMAvqirbQ4BUK3cgWo
	if '/youtubei/v1/browse' in B17r2fdFy9ns8tiOMLu or '/youtubei/v1/search' in B17r2fdFy9ns8tiOMLu or '/my_main_page_shorts_link' in url:
		data = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.youtube.data')
		if data.count(':::')==4:
			L0kWgirzRe4NXJv,key,OJNI3s4dBaj,LidS4P2AqOtD7z,iigMzLZxRm6npGVfCvb0 = data.split(':::')
			i68iPmaHVAZknGv2SNpyzCwcFE = L0kWgirzRe4NXJv+':::'+key+':::'+OJNI3s4dBaj+':::'+LidS4P2AqOtD7z+':::'+TTxVeZGHdw8E
			if '/my_main_page_shorts_link' in url and not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = url
			else: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?key='+key
	if not title:
		global h5wFNra3VdCfctlsPTjqnup2yJEmIO
		h5wFNra3VdCfctlsPTjqnup2yJEmIO += 1
		title = 'فيديوهات '+str(h5wFNra3VdCfctlsPTjqnup2yJEmIO)
		nTxciHKjwprDmO = '3'+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
	if not bEZlOa1inyrUgdTw9BKNtcMCLYI: return False
	elif 'searchPyvRenderer' in str(UqKgalXPCz7eQAL08foMx1R): return False
	elif '/about' in B17r2fdFy9ns8tiOMLu: return False
	elif '/community' in B17r2fdFy9ns8tiOMLu: return False
	elif 'continuationItemRenderer' in list(UqKgalXPCz7eQAL08foMx1R.keys()) or 'continuationCommand' in list(UqKgalXPCz7eQAL08foMx1R.keys()):
		if int(level)>1: level = str(int(level)-1)
		nTxciHKjwprDmO = level+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+':: '+'صفحة أخرى',B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO,i68iPmaHVAZknGv2SNpyzCwcFE)
	elif '/search' in B17r2fdFy9ns8tiOMLu:
		title = ':: '+title
		nTxciHKjwprDmO = '3'+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
		url = url.replace('/search',sCHVtMAvqirbQ4BUK3cgWo)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,145,sCHVtMAvqirbQ4BUK3cgWo,nTxciHKjwprDmO,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not B17r2fdFy9ns8tiOMLu:
		nTxciHKjwprDmO = '3'+'::'+BXso7lYiGK3Dqx15Q+'::'+krF5ZpjBbJ8tGW+'::'+Jyufx3GEIh2pRCMcgXordnKNYO9Ua7
		title = ':: '+title
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO,i68iPmaHVAZknGv2SNpyzCwcFE)
	elif '/browse' in B17r2fdFy9ns8tiOMLu and url==gAVl1vUmus8:
		title = ':: '+title
		nTxciHKjwprDmO = '2::0::0::0'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO,i68iPmaHVAZknGv2SNpyzCwcFE)
	elif not B17r2fdFy9ns8tiOMLu and 'horizontalMovieListRenderer' in str(UqKgalXPCz7eQAL08foMx1R):
		title = ':: '+title
		nTxciHKjwprDmO = '3::0::0::0'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO)
	elif 'messageRenderer' in str(UqKgalXPCz7eQAL08foMx1R):
		XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,9999)
	elif jnzo1t7ID0EVH:
		XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+jnzo1t7ID0EVH+title,B17r2fdFy9ns8tiOMLu,143,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif '/playlist?list=' in B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('&playnext=1',sCHVtMAvqirbQ4BUK3cgWo)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'LIST'+count+':  '+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO)
	elif '/shorts/' in B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('&list=',1)[0]
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,143,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	elif '/watch?v=' in B17r2fdFy9ns8tiOMLu:
		if '&list=' in B17r2fdFy9ns8tiOMLu and count:
			x8DHcMgpdYXRZBESmKPI = B17r2fdFy9ns8tiOMLu.split('&list=',1)[1]
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/playlist?list='+x8DHcMgpdYXRZBESmKPI
			nTxciHKjwprDmO = '1::0::0::0'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'LIST'+count+':  '+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO)
		else:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('&list=',1)[0]
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,143,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	elif '/channel/' in B17r2fdFy9ns8tiOMLu or '/c/' in B17r2fdFy9ns8tiOMLu or ('/@' in B17r2fdFy9ns8tiOMLu and B17r2fdFy9ns8tiOMLu.count('/')==3):
		if qdUK5ioJyrO1T:
			title = title.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode('raw_unicode_escape')
			title = EEH4kBfGY0FuZUjeNn(title)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'CHNL'+count+':  '+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO)
	elif '/user/' in B17r2fdFy9ns8tiOMLu:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'USER'+count+':  '+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO)
	else:
		if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = url
		title = ':: '+title
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,144,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,nTxciHKjwprDmO,i68iPmaHVAZknGv2SNpyzCwcFE)
	return True
def t7AHGVsjhoOvPJSRuy6Mbzcf(UqKgalXPCz7eQAL08foMx1R):
	bEZlOa1inyrUgdTw9BKNtcMCLYI,title,B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count,yAMScJ6z3E8,jnzo1t7ID0EVH,WUICZqepnyE1,iigMzLZxRm6npGVfCvb0 = False,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if not isinstance(UqKgalXPCz7eQAL08foMx1R,dict): return bEZlOa1inyrUgdTw9BKNtcMCLYI,title,B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count,yAMScJ6z3E8,jnzo1t7ID0EVH,WUICZqepnyE1,iigMzLZxRm6npGVfCvb0
	for PGw0rh7ux5U4lVznQpE9C2 in list(UqKgalXPCz7eQAL08foMx1R.keys()):
		m4sz3l2Q6vXCL = UqKgalXPCz7eQAL08foMx1R[PGw0rh7ux5U4lVznQpE9C2]
		if isinstance(m4sz3l2Q6vXCL,dict): break
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['header']['richListHeaderRenderer']['title']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['headline']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['unplayableText']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['formattedTitle']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['title']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['title']['runs'][0]['text']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['text']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['text']['runs'][0]['text']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['title']['content']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['title']")
	sF6zTyIGjet9LJlNQdVC0.append("item['title']")
	sF6zTyIGjet9LJlNQdVC0.append("item['reelWatchEndpoint']['videoId']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	sF6zTyIGjet9LJlNQdVC0.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	sF6zTyIGjet9LJlNQdVC0.append("item['commandMetadata']['webCommandMetadata']['url']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,B17r2fdFy9ns8tiOMLu,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnail']['thumbnails'][0]['url']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	sF6zTyIGjet9LJlNQdVC0.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['videoCountShortText']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['videoCountText']['runs'][0]['text']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['videoCount']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,count,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['lengthText']['simpleText']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,yAMScJ6z3E8,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	sF6zTyIGjet9LJlNQdVC0 = []
	sF6zTyIGjet9LJlNQdVC0.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	sF6zTyIGjet9LJlNQdVC0.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	bEZlOa1inyrUgdTw9BKNtcMCLYI,iigMzLZxRm6npGVfCvb0,zPm7HsNhv8Gt5jpi2YUZlnOeDT = Gm0XTsVxiA8ORUWl6HEbQj(UqKgalXPCz7eQAL08foMx1R,m4sz3l2Q6vXCL,sF6zTyIGjet9LJlNQdVC0)
	if 'LIVE' in yAMScJ6z3E8: yAMScJ6z3E8,jnzo1t7ID0EVH = sCHVtMAvqirbQ4BUK3cgWo,'LIVE:  '
	if 'مباشر' in yAMScJ6z3E8: yAMScJ6z3E8,jnzo1t7ID0EVH = sCHVtMAvqirbQ4BUK3cgWo,'LIVE:  '
	if 'badges' in list(m4sz3l2Q6vXCL.keys()):
		h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD = str(m4sz3l2Q6vXCL['badges'])
		if 'Free with Ads' in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: WUICZqepnyE1 = '$:  '
		if 'LIVE' in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: jnzo1t7ID0EVH = 'LIVE:  '
		if 'Buy' in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD or 'Rent' in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: WUICZqepnyE1 = '$$:  '
		if ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(u'مباشر') in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: jnzo1t7ID0EVH = 'LIVE:  '
		if ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(u'شراء') in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: WUICZqepnyE1 = '$$:  '
		if ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(u'استئجار') in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: WUICZqepnyE1 = '$$:  '
		if ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(u'إعلانات') in h1eV0CKIUJF3xbTtzlQ4rAiqMyRjD: WUICZqepnyE1 = '$:  '
	B17r2fdFy9ns8tiOMLu = EEH4kBfGY0FuZUjeNn(B17r2fdFy9ns8tiOMLu)
	if B17r2fdFy9ns8tiOMLu and 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.split('?')[0]
	if  Mx0TQvmZAsedaGj4opVDJu5by8RUwS and 'http' not in Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = 'https:'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
	title = EEH4kBfGY0FuZUjeNn(title)
	if WUICZqepnyE1: title = WUICZqepnyE1+title
	yAMScJ6z3E8 = yAMScJ6z3E8.replace(',',sCHVtMAvqirbQ4BUK3cgWo)
	count = count.replace(',',sCHVtMAvqirbQ4BUK3cgWo)
	count = fNntYJW45mEFSdRX8g.findall('\d+',count)
	if count: count = count[0]
	else: count = sCHVtMAvqirbQ4BUK3cgWo
	return True,title,B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,count,yAMScJ6z3E8,jnzo1t7ID0EVH,WUICZqepnyE1,iigMzLZxRm6npGVfCvb0
def H168HdpnGbmLg(url,data=sCHVtMAvqirbQ4BUK3cgWo,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	if n1WYDtVC8dRHbXJkMa==sCHVtMAvqirbQ4BUK3cgWo: n1WYDtVC8dRHbXJkMa = 'ytInitialData'
	MMKTiky7N3vVPdx6GIzHFOf2Yjq = OOsacGDt4owXd52q7gC8l()
	HSNYwERMjzyxmrPku = {'User-Agent':MMKTiky7N3vVPdx6GIzHFOf2Yjq,'Cookie':'PREF=hl=ar'}
	global fDQNTKLnvHaWw2BEAIzg0FPMjyq
	if not data: data = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.youtube.data')
	if data.count(':::')==4: L0kWgirzRe4NXJv,key,OJNI3s4dBaj,LidS4P2AqOtD7z,iigMzLZxRm6npGVfCvb0 = data.split(':::')
	else: L0kWgirzRe4NXJv,key,OJNI3s4dBaj,LidS4P2AqOtD7z,iigMzLZxRm6npGVfCvb0 = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	i68iPmaHVAZknGv2SNpyzCwcFE = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":OJNI3s4dBaj}}}
	if url==gAVl1vUmus8+'/shorts' or '/my_main_page_shorts_link' in url:
		url = gAVl1vUmus8+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		i68iPmaHVAZknGv2SNpyzCwcFE['sequenceParams'] = L0kWgirzRe4NXJv
		i68iPmaHVAZknGv2SNpyzCwcFE = str(i68iPmaHVAZknGv2SNpyzCwcFE)
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',url,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = gAVl1vUmus8+'/youtubei/v1/guide?key='+key
		i68iPmaHVAZknGv2SNpyzCwcFE = str(i68iPmaHVAZknGv2SNpyzCwcFE)
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',url,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and L0kWgirzRe4NXJv:
		i68iPmaHVAZknGv2SNpyzCwcFE['continuation'] = iigMzLZxRm6npGVfCvb0
		i68iPmaHVAZknGv2SNpyzCwcFE['context']['client']['visitorData'] = L0kWgirzRe4NXJv
		i68iPmaHVAZknGv2SNpyzCwcFE = str(i68iPmaHVAZknGv2SNpyzCwcFE)
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',url,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and LidS4P2AqOtD7z:
		HSNYwERMjzyxmrPku.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':OJNI3s4dBaj})
		HSNYwERMjzyxmrPku.update({'Cookie':'VISITOR_INFO1_LIVE='+LidS4P2AqOtD7z})
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'YOUTUBE-GET_PAGE_DATA-6th')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall('"innertubeApiKey".*?"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.I)
	if AHhdOiGao5UZ: key = AHhdOiGao5UZ[0]
	AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall('"cver".*?"value".*?"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.I)
	if AHhdOiGao5UZ: OJNI3s4dBaj = AHhdOiGao5UZ[0]
	AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall('"visitorData".*?"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.I)
	if AHhdOiGao5UZ: L0kWgirzRe4NXJv = AHhdOiGao5UZ[0]
	cookies = UHqibFEGL8fjKhI.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): LidS4P2AqOtD7z = cookies['VISITOR_INFO1_LIVE']
	MAR96O0yHe7jiIlEXB = L0kWgirzRe4NXJv+':::'+key+':::'+OJNI3s4dBaj+':::'+LidS4P2AqOtD7z+':::'+iigMzLZxRm6npGVfCvb0
	if n1WYDtVC8dRHbXJkMa=='ytInitialData' and 'ytInitialData' in Sw0pOFoVhPeIxbl:
		Rta7jzNBTk3XYMW = fNntYJW45mEFSdRX8g.findall('window\["ytInitialData"\] = ({.*?});',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not Rta7jzNBTk3XYMW: Rta7jzNBTk3XYMW = fNntYJW45mEFSdRX8g.findall('var ytInitialData = ({.*?});',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		LLbSx9uDIBn = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',Rta7jzNBTk3XYMW[0])
	elif n1WYDtVC8dRHbXJkMa=='ytInitialGuideData' and 'ytInitialGuideData' in Sw0pOFoVhPeIxbl:
		Rta7jzNBTk3XYMW = fNntYJW45mEFSdRX8g.findall('var ytInitialGuideData = ({.*?});',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		LLbSx9uDIBn = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',Rta7jzNBTk3XYMW[0])
	elif '</script>' not in Sw0pOFoVhPeIxbl: LLbSx9uDIBn = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',Sw0pOFoVhPeIxbl)
	else: LLbSx9uDIBn = sCHVtMAvqirbQ4BUK3cgWo
	if 0:
		kDpWtBrX8YaQZnSsKTE = str(LLbSx9uDIBn)
		if I5VKjrFL0Bk97: kDpWtBrX8YaQZnSsKTE = kDpWtBrX8YaQZnSsKTE.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open('S:\\0000emad.dat','wb').write(kDpWtBrX8YaQZnSsKTE)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.youtube.data',MAR96O0yHe7jiIlEXB)
	return Sw0pOFoVhPeIxbl,LLbSx9uDIBn,MAR96O0yHe7jiIlEXB
def gt9WJMRHNs8c0kpSDoGbOIrnU(url,nTxciHKjwprDmO):
	search = UyBdvjGrFxDWMpmLOXn()
	if not search: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	vrEJRkchKxtDNiqO1b79mL5eT = url+'/search?query='+search
	fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT,nTxciHKjwprDmO)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search:
		search = UyBdvjGrFxDWMpmLOXn()
		if not search: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in Z2VkQhiPAOuboSRB: Dv96uXEs5CUm = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in Z2VkQhiPAOuboSRB: Dv96uXEs5CUm = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in Z2VkQhiPAOuboSRB: Dv96uXEs5CUm = '&sp=EgIQAg%253D%253D'
		else: Dv96uXEs5CUm = sCHVtMAvqirbQ4BUK3cgWo
		rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT+Dv96uXEs5CUm
	else:
		QfJ0bZmq719LH,xM6gIpWJtQd,dwDUvp0LAuyg1rI = [],[],sCHVtMAvqirbQ4BUK3cgWo
		rJ857SwTsRjotNvH = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		rupBJ8fV7N9kK = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		uBK0F4NmnWSwyqGC = Wdlg19qZ4apQtYFCINvBeML0c('اختر البحث المناسب',rJ857SwTsRjotNvH)
		if uBK0F4NmnWSwyqGC == -1: return
		LacUv0olEZmrI3q5eSOgRxXtWy = rupBJ8fV7N9kK[uBK0F4NmnWSwyqGC]
		Sw0pOFoVhPeIxbl,YyQSLTwIN8FGMOnhBRmd7E,data = H168HdpnGbmLg(vrEJRkchKxtDNiqO1b79mL5eT+LacUv0olEZmrI3q5eSOgRxXtWy)
		if YyQSLTwIN8FGMOnhBRmd7E:
			try:
				PGIMerh3ZFgUmcWCQJTY = YyQSLTwIN8FGMOnhBRmd7E['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for BEodrcM8VXxAQ2Jg5umU in range(len(PGIMerh3ZFgUmcWCQJTY)):
					group = PGIMerh3ZFgUmcWCQJTY[BEodrcM8VXxAQ2Jg5umU]['searchFilterGroupRenderer']['filters']
					for FyActaxBu2LebEJUCwdq in range(len(group)):
						m4sz3l2Q6vXCL = group[FyActaxBu2LebEJUCwdq]['searchFilterRenderer']
						if 'navigationEndpoint' in list(m4sz3l2Q6vXCL.keys()):
							B17r2fdFy9ns8tiOMLu = m4sz3l2Q6vXCL['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('\u0026','&')
							title = m4sz3l2Q6vXCL['tooltip']
							title = title.replace('البحث عن ',sCHVtMAvqirbQ4BUK3cgWo)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								dwDUvp0LAuyg1rI = title
								NroHCBWaxUZOfbgqMzAL4vJ2 = B17r2fdFy9ns8tiOMLu
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',sCHVtMAvqirbQ4BUK3cgWo)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								dwDUvp0LAuyg1rI = title
								NroHCBWaxUZOfbgqMzAL4vJ2 = B17r2fdFy9ns8tiOMLu
							if 'Sort by' in title: continue
							QfJ0bZmq719LH.append(EEH4kBfGY0FuZUjeNn(title))
							xM6gIpWJtQd.append(B17r2fdFy9ns8tiOMLu)
			except: pass
		if not dwDUvp0LAuyg1rI: fMQadozCIr = sCHVtMAvqirbQ4BUK3cgWo
		else:
			QfJ0bZmq719LH = ['بدون فلتر',dwDUvp0LAuyg1rI]+QfJ0bZmq719LH
			xM6gIpWJtQd = [sCHVtMAvqirbQ4BUK3cgWo,NroHCBWaxUZOfbgqMzAL4vJ2]+xM6gIpWJtQd
			M6tyHOrBTbDxNRz2Q4jqwhiKXgU9V = Wdlg19qZ4apQtYFCINvBeML0c('موقع يوتيوب - اختر الفلتر',QfJ0bZmq719LH)
			if M6tyHOrBTbDxNRz2Q4jqwhiKXgU9V == -1: return
			fMQadozCIr = xM6gIpWJtQd[M6tyHOrBTbDxNRz2Q4jqwhiKXgU9V]
		if fMQadozCIr: rdQ5tOIzuelfvcYbNsM = gAVl1vUmus8+fMQadozCIr
		elif LacUv0olEZmrI3q5eSOgRxXtWy: rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT+LacUv0olEZmrI3q5eSOgRxXtWy
		else: rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT
	fs7D0d3QyAT(rdQ5tOIzuelfvcYbNsM)
	return
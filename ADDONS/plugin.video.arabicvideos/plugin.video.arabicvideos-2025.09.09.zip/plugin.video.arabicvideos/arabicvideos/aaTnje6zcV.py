# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'CIMACLUP'
Z0BYJQghVL1v87CAem = '_CMC_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['موقع نتفليكس']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==490: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==491: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==492: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==493: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==494: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==499: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text,url)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	aeBQsh4fzLr8XM5xou1gcyE = aeBQsh4fzLr8XM5xou1gcyE[0].strip('/')
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(aeBQsh4fzLr8XM5xou1gcyE,'url')
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"filter AjaxifyFilter"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('data-filter="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/old/filter/'+B17r2fdFy9ns8tiOMLu+'.php'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,491)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أفلام',aeBQsh4fzLr8XM5xou1gcyE+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مسلسلات',aeBQsh4fzLr8XM5xou1gcyE+'/category/مسلسلات/مسلسلات-اجنبى',494,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="navigation-menu"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu=='/': continue
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,491)
	return Sw0pOFoVhPeIxbl
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"filter"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,491)
	return
def fs7D0d3QyAT(url,pm4F0M2Dsuh6otP7Zi5NXT=sCHVtMAvqirbQ4BUK3cgWo):
	items = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
	if '.php' in url: Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
	elif '?s=' in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"blocks(.*?)"manifest"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"Blocks(.*?)"manifest"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not Po9h3gWFuLR2: return
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) حلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if not bbFPOJrmkCaE6ul37XiKU: bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if not bbFPOJrmkCaE6ul37XiKU or any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,492,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'حلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,493,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,493,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<li><a href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
			if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,491)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('"ButtonsBarCo".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT:
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-EPISODES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"img-responsive" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
	else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Thumb')
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"filter"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"Blocks(.*?)class="pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx and '/series/' not in url:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,493,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,492,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = tt36wUe4HTPFmfs5hcbr(title)
				title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
				if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,491)
	return
def YH54mqkD2eU06(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url.strip('/')+'/?view=1'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMACLUP-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ss7YGDbuAIxgnqaQroTV = []
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	SSyNiGLhxRXH1TzFW3DPw = fNntYJW45mEFSdRX8g.findall("data: 'q=(.*?)&",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	SSyNiGLhxRXH1TzFW3DPw = SSyNiGLhxRXH1TzFW3DPw[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"serversList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('data-server="(.*?)">(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for xpr5w6F1cy4VbSIWJMRdt,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/old/servers/server.php?q='+SSyNiGLhxRXH1TzFW3DPw+'&i='+xpr5w6F1cy4VbSIWJMRdt+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"embedServer".*?SRC="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		title = 'مفضل'
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]+'?named=__embed__'+title
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downloadsList"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<td>(.*?)</td>.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if 'anavidz' in B17r2fdFy9ns8tiOMLu: dwDUvp0LAuyg1rI = '__خاص'
			else: dwDUvp0LAuyg1rI = sCHVtMAvqirbQ4BUK3cgWo
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+dwDUvp0LAuyg1rI
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search,aeBQsh4fzLr8XM5xou1gcyE=sCHVtMAvqirbQ4BUK3cgWo):
	if not aeBQsh4fzLr8XM5xou1gcyE: aeBQsh4fzLr8XM5xou1gcyE = gAVl1vUmus8
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search:
		search = UyBdvjGrFxDWMpmLOXn()
		if not search: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = aeBQsh4fzLr8XM5xou1gcyE+'/index.php?s='+search
	fs7D0d3QyAT(url)
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYBEST3'
Z0BYJQghVL1v87CAem = '_EB3_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==790: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==791: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV)
	elif mode==792: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==793: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==796: ka7jz96YCdTBnQOLVPuJG3285MHf = kAUpK78mJRgoWZQytrNXeh5xf3v(url,mRwrKW6fNZV)
	elif mode==799: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('list-pages(.*?)fa-folder',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-article(.*?)social-box',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('main-title.*?">(.*?)<.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791,sCHVtMAvqirbQ4BUK3cgWo,'mainmenu')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-menu(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791)
	return Sw0pOFoVhPeIxbl
def kAUpK78mJRgoWZQytrNXeh5xf3v(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-SEASONS_EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-article".*?">(.*?)<(.*?)article',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		bFNze460jv,pWu3ti618zVAbjdf7,items = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[]
		for name,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			if 'حلقات' in name: pWu3ti618zVAbjdf7 = Po9h3gWFuLR2
			if 'مواسم' in name: bFNze460jv = Po9h3gWFuLR2
		if bFNze460jv and not type:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',bFNze460jv,fNntYJW45mEFSdRX8g.DOTALL)
			if len(items)>1:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,796,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
		if pWu3ti618zVAbjdf7 and len(items)<2:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,793,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else:
				items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,793)
	return
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	T1AWiH6ZJ2X3Ccs,start,Ffh8yTQ3d6sp,select,CUb4zVG6lTcmaAqBJnr = 0,0,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if 'pagination' in type:
		EvBZakmM65UlcHDqxeiInArPWCF,data = muXAzTa365Mjklef1ZP7JiWrIR(url)
		T1AWiH6ZJ2X3Ccs = int(data['limit'])
		start = int(data['start'])
		Ffh8yTQ3d6sp = data['type']
		select = data['select']
		i68iPmaHVAZknGv2SNpyzCwcFE = 'limit='+str(T1AWiH6ZJ2X3Ccs)+'&start='+str(start)+'&type='+Ffh8yTQ3d6sp+'&select='+select
		HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',EvBZakmM65UlcHDqxeiInArPWCF,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		ssUAzo3RibtgDv7O0x = 'blocks'+Sw0pOFoVhPeIxbl+'article'
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		ssUAzo3RibtgDv7O0x = Sw0pOFoVhPeIxbl
		code = fNntYJW45mEFSdRX8g.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if code:
			code = code[0].replace('var',sCHVtMAvqirbQ4BUK3cgWo).replace(AAh0X3OCacr4HpifRGLZKT,sCHVtMAvqirbQ4BUK3cgWo).replace("'",sCHVtMAvqirbQ4BUK3cgWo).replace(';','&')
			qLbRrEtgenpSi,data = muXAzTa365Mjklef1ZP7JiWrIR('?'+code)
			T1AWiH6ZJ2X3Ccs = int(data['limit'])
			start = int(data['start'])
			Ffh8yTQ3d6sp = data['type']
			select = data['select']
			CUb4zVG6lTcmaAqBJnr = data['ajaxurl']
			i68iPmaHVAZknGv2SNpyzCwcFE = 'limit='+str(T1AWiH6ZJ2X3Ccs)+'&start='+str(start)+'&type='+Ffh8yTQ3d6sp+'&select='+select
			EvBZakmM65UlcHDqxeiInArPWCF = gAVl1vUmus8+CUb4zVG6lTcmaAqBJnr
			HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded'}
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',EvBZakmM65UlcHDqxeiInArPWCF,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-TITLES-3rd')
			ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
			ssUAzo3RibtgDv7O0x = 'blocks'+ssUAzo3RibtgDv7O0x+'article'
	items,hwGsDZtO93Qm1IkdYinj,W6WgK7nGvCuozqhaSkFMXiye = [],False,False
	if not type:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-content(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791,sCHVtMAvqirbQ4BUK3cgWo,'submenu')
				hwGsDZtO93Qm1IkdYinj = True
	if not type:
		W6WgK7nGvCuozqhaSkFMXiye = jWXMJvDftU2zxVTh9G3QE7oZ0B(Sw0pOFoVhPeIxbl)
	if not hwGsDZtO93Qm1IkdYinj and not W6WgK7nGvCuozqhaSkFMXiye:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('blocks(.*?)article',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.strip(slFfrUIWCowaBA7tce3iZbj8xn)
				B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
				if '/selary/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				elif 'مسلسل' in B17r2fdFy9ns8tiOMLu and 'حلقة' not in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,796,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				elif 'موسم' in B17r2fdFy9ns8tiOMLu and 'حلقة' not in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,796,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,793,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		l4M5eoBRmE = 12
		data = fNntYJW45mEFSdRX8g.findall('class="(load-more.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)==l4M5eoBRmE and (data or 'pagination' in type):
			i68iPmaHVAZknGv2SNpyzCwcFE = 'limit='+str(l4M5eoBRmE)+'&start='+str(start+l4M5eoBRmE)+'&type='+Ffh8yTQ3d6sp+'&select='+select
			vrEJRkchKxtDNiqO1b79mL5eT = EvBZakmM65UlcHDqxeiInArPWCF+'?next=page&'+i68iPmaHVAZknGv2SNpyzCwcFE
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'المزيد',vrEJRkchKxtDNiqO1b79mL5eT,791,sCHVtMAvqirbQ4BUK3cgWo,'pagination_'+type)
	return
def jWXMJvDftU2zxVTh9G3QE7oZ0B(Sw0pOFoVhPeIxbl):
	W6WgK7nGvCuozqhaSkFMXiye = False
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-article(.*?)article',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if Jae64ky3REO57A2MvVHB90: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for B4SziFvRIXpPeGmfZDw3aVWJMAKNc,name,Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
			name = name.strip(AAh0X3OCacr4HpifRGLZKT)
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,value in items:
				title = name+':  '+value
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,791,sCHVtMAvqirbQ4BUK3cgWo,'filter')
				W6WgK7nGvCuozqhaSkFMXiye = True
	return W6WgK7nGvCuozqhaSkFMXiye
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST3-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	cb1fAztguv78n9LGhSWJFm5p,y2EPKIcgxi8do3NOu6zbZ = [],[]
	items = fNntYJW45mEFSdRX8g.findall('server-item.*?data-code="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for noedSQKWMIuEvg7aBHzT82V in items:
		bxIzTX3mtuZ8Ueh5fcVDAFwPlOW = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(noedSQKWMIuEvg7aBHzT82V)
		if I5VKjrFL0Bk97: bxIzTX3mtuZ8Ueh5fcVDAFwPlOW = bxIzTX3mtuZ8Ueh5fcVDAFwPlOW.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('src="(.*?)"',bxIzTX3mtuZ8Ueh5fcVDAFwPlOW,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
			if B17r2fdFy9ns8tiOMLu not in y2EPKIcgxi8do3NOu6zbZ:
				y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
				smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__watch')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="downloads(.*?)</section>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu in items:
			if B17r2fdFy9ns8tiOMLu not in y2EPKIcgxi8do3NOu6zbZ:
				if '/?url=' in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('/?url=')[1]
				y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
				smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__download____'+XO7Zr2W6kwieA)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(text):
	return
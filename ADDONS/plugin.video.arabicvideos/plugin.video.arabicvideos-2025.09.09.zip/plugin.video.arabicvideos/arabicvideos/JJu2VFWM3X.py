﻿# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,G4dY6kBH0wZCbFj3sUncgPeQf):
	if G4dY6kBH0wZCbFj3sUncgPeQf==sCHVtMAvqirbQ4BUK3cgWo: return
	if QQ8kHjYnKEDU3sxft9S5iRoB==1:
		vRxCTm7SY3 = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.getCurrentWindowDialogId()
		IiDXAnVWU2k90cT = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Window(vRxCTm7SY3)
		G4dY6kBH0wZCbFj3sUncgPeQf = fko6iadls820ZP9MNqX(G4dY6kBH0wZCbFj3sUncgPeQf)
		IiDXAnVWU2k90cT.getControl(311).setLabel(G4dY6kBH0wZCbFj3sUncgPeQf)
	if QQ8kHjYnKEDU3sxft9S5iRoB==0:
		ScEpZwINx93VJ5aWfb4='X'
		if I5VKjrFL0Bk97: Ozivpc5oZY2bPL9AHSf43lRM6 = isinstance(G4dY6kBH0wZCbFj3sUncgPeQf,str)
		else: Ozivpc5oZY2bPL9AHSf43lRM6 = isinstance(G4dY6kBH0wZCbFj3sUncgPeQf,unicode)
		if Ozivpc5oZY2bPL9AHSf43lRM6==True: ScEpZwINx93VJ5aWfb4='U'
		CCQM59qev8NB=str(type(G4dY6kBH0wZCbFj3sUncgPeQf))+AAh0X3OCacr4HpifRGLZKT+G4dY6kBH0wZCbFj3sUncgPeQf+AAh0X3OCacr4HpifRGLZKT+ScEpZwINx93VJ5aWfb4+AAh0X3OCacr4HpifRGLZKT
		for XMIo9vWSBymeLJnK6YsU in range(0,len(G4dY6kBH0wZCbFj3sUncgPeQf),1):
			CCQM59qev8NB += hex(ord(G4dY6kBH0wZCbFj3sUncgPeQf[XMIo9vWSBymeLJnK6YsU])).replace('0x',sCHVtMAvqirbQ4BUK3cgWo)+AAh0X3OCacr4HpifRGLZKT
		G4dY6kBH0wZCbFj3sUncgPeQf = fko6iadls820ZP9MNqX(G4dY6kBH0wZCbFj3sUncgPeQf)
		ScEpZwINx93VJ5aWfb4='X'
		if I5VKjrFL0Bk97: Ozivpc5oZY2bPL9AHSf43lRM6 = isinstance(G4dY6kBH0wZCbFj3sUncgPeQf, str)
		else: Ozivpc5oZY2bPL9AHSf43lRM6 = isinstance(G4dY6kBH0wZCbFj3sUncgPeQf, unicode)
		if Ozivpc5oZY2bPL9AHSf43lRM6==True: ScEpZwINx93VJ5aWfb4='U'
		rrfNEVnbX9ID56YTkRGoPwCd2x=str(type(G4dY6kBH0wZCbFj3sUncgPeQf))+AAh0X3OCacr4HpifRGLZKT+G4dY6kBH0wZCbFj3sUncgPeQf+AAh0X3OCacr4HpifRGLZKT+ScEpZwINx93VJ5aWfb4+AAh0X3OCacr4HpifRGLZKT
		for XMIo9vWSBymeLJnK6YsU in range(0,len(G4dY6kBH0wZCbFj3sUncgPeQf),1):
			rrfNEVnbX9ID56YTkRGoPwCd2x += hex(ord(G4dY6kBH0wZCbFj3sUncgPeQf[XMIo9vWSBymeLJnK6YsU])).replace('0x',sCHVtMAvqirbQ4BUK3cgWo)+AAh0X3OCacr4HpifRGLZKT
	return
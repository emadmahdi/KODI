# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = SIkwCEdJHTD9v1(u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫᰘ")
Z0BYJQghVL1v87CAem = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡤࡒࡓࡕࡡࠪᰙ")
TiZsAOU7nptlPhEqbXfxr = kK7gj9HE462hADJbvr
hHgazZFwbfj8Sn = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠱࠱Ẅ")
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,url,T67f3LG49xpP8zcN,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q):
	try: J26JEXNRtmOrlj8qhesLYI0dKpQ = str(ZQC69Pyo4BOamJlwSLtAWINg7q[BWfpRku7SsM6cbE0eG(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰚ")])
	except: J26JEXNRtmOrlj8qhesLYI0dKpQ = sCHVtMAvqirbQ4BUK3cgWo
	if   QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠲࠸࠳ẅ"): ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠳࠹࠵Ẇ"): ka7jz96YCdTBnQOLVPuJG3285MHf = z3zcYGSh5WjO2yRiBne(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠴࠺࠷ẇ"): ka7jz96YCdTBnQOLVPuJG3285MHf = rrOFuQcHqGEv1ywIRk6At(T67f3LG49xpP8zcN,gDETKVh8mZe09Nd(u"࠴࠺࠷ẇ"))
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠵࠻࠹Ẉ"): ka7jz96YCdTBnQOLVPuJG3285MHf = rrOFuQcHqGEv1ywIRk6At(T67f3LG49xpP8zcN,qqw1upCsKM(u"࠵࠻࠹Ẉ"))
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠶࠼࠴ẉ"): ka7jz96YCdTBnQOLVPuJG3285MHf = ccZ9Ndx4vesaBAj76XlItz0ufDkb(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==zLjWeKu6JgNO7vocUD0Qpy(u"࠷࠶࠶Ẋ"): ka7jz96YCdTBnQOLVPuJG3285MHf = Gk0X91WgTzaRZr3iYBPNfwEp2cqe(url,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==jwzOabysh0Z(u"࠱࠷࠸ẋ"): ka7jz96YCdTBnQOLVPuJG3285MHf = ALsVGTMZE1fv0QgRaqKSndpChtIJ(url,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==zLjWeKu6JgNO7vocUD0Qpy(u"࠲࠸࠺Ẍ"): ka7jz96YCdTBnQOLVPuJG3285MHf = vq9kLfGj0x2sVcml8yTiY(url,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==jwzOabysh0Z(u"࠳࠹࠼ẍ"): ka7jz96YCdTBnQOLVPuJG3285MHf = U0hN78tHfFG6M3beAXqdg5V9ra(url,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==oVwa0kcqxj1e7mLplAfZdGT(u"࠺࠺࠶Ẏ"): ka7jz96YCdTBnQOLVPuJG3285MHf = b7l0kiavWztB9sre5FIMf1y()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==sH6BOz5wKRFcEg(u"࠻࠻࠸ẏ"): ka7jz96YCdTBnQOLVPuJG3285MHf = EGYFymUSnZsl9b()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==sH6BOz5wKRFcEg(u"࠼࠼࠳Ẑ"): ka7jz96YCdTBnQOLVPuJG3285MHf = IP3rok2TcX(J26JEXNRtmOrlj8qhesLYI0dKpQ,T67f3LG49xpP8zcN,mRwrKW6fNZV)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠽࠶࠵ẑ"): ka7jz96YCdTBnQOLVPuJG3285MHf = Y1sdLTAkqnuRhXN8KaFC6w4BtfvxHP(J26JEXNRtmOrlj8qhesLYI0dKpQ,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==EJgYdjbIiWe1apkQlZcR42(u"࠷࠷࠷Ẓ"): ka7jz96YCdTBnQOLVPuJG3285MHf = UUjh9kH05VedARfTsJKxi8rS4tQ(J26JEXNRtmOrlj8qhesLYI0dKpQ,T67f3LG49xpP8zcN)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = lvzrYTpcBaK
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰛ"),IOHSz7YPF9WusGgUt1Dq(u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨᰜ"),sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"࠲࠸࠴ẓ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠨࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰝ"))
	XAozRfZ68H9x2OsiP3LmIaql1(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡩࡳࡱࡪࡥࡳࠩᰞ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪๆฺุ๋ࠠึ๋หห๐ࠧᰟ"),sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠳࠹࠶Ẕ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰠ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰡ"),IOHSz7YPF9WusGgUt1Dq(u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩᰢ"),sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠴࠺࠸ẕ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᰣ"))
	XAozRfZ68H9x2OsiP3LmIaql1(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰤ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨᰥ"),sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠵࠻࠺ẖ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰦ"))
	XAozRfZ68H9x2OsiP3LmIaql1(aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰧ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᰨ"),sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠼࠼࠳ẗ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᰩ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Js61GTdX5wzMurUqi7Z(u"ࠧ࡭࡫ࡱ࡯ࠬᰪ"),VXWOCAE6ns3paJ8DLG479NQfMu+IO7k2hZXSz(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᰫ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"࠿࠹࠺࠻ẘ"))
	XAozRfZ68H9x2OsiP3LmIaql1(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡩࡳࡱࡪࡥࡳࠩᰬ"),hPFcB6Uxmabj59Iq(u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧᰭ"),sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"࠱࠷࠵ẙ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᰮ"))
	XAozRfZ68H9x2OsiP3LmIaql1(jwzOabysh0Z(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰯ"),SIkwCEdJHTD9v1(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ࠭ᰰ"),sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠲࠸࠶ẚ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰱ"))
	XAozRfZ68H9x2OsiP3LmIaql1(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰲ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᰳ"),sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"࠳࠹࠶ẛ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰴ"))
	XAozRfZ68H9x2OsiP3LmIaql1(aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰵ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬᰶ"),sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠴࠺࠷ẜ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,SIkwCEdJHTD9v1(u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᰷࠭"))
	XAozRfZ68H9x2OsiP3LmIaql1(Js61GTdX5wzMurUqi7Z(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᰸"),aYH620Dh48GEsTFfOBSQ7r(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸࡛ࠠษฯฮࠤ฾ฺ่ศศํࠫ᰹"),sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"࠵࠻࠺ẝ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᰺"))
	XAozRfZ68H9x2OsiP3LmIaql1(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᰻"),TzIj50KpohEOHx6CbZWqB(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ᰼"),sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"࠼࠼࠵ẞ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᰽"))
	XAozRfZ68H9x2OsiP3LmIaql1(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭࡬ࡪࡰ࡮ࠫ᰾"),VXWOCAE6ns3paJ8DLG479NQfMu+hPFcB6Uxmabj59Iq(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭᰿")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"࠿࠹࠺࠻ẟ"))
	XAozRfZ68H9x2OsiP3LmIaql1(aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᱀"),GVurlv8HeoXEzPRiQB7Ty(u"ࠩๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ᱁"),sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"࠱࠷࠵Ạ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱂"))
	XAozRfZ68H9x2OsiP3LmIaql1(qeG16a4pbSHziNVQ2uFXrs(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᱃"),TzIj50KpohEOHx6CbZWqB(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭᱄"),sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲࠸࠶ạ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᱅"))
	XAozRfZ68H9x2OsiP3LmIaql1(sH6BOz5wKRFcEg(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᱆"),SIkwCEdJHTD9v1(u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ᱇"),sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳࠹࠶Ả"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᱈"))
	XAozRfZ68H9x2OsiP3LmIaql1(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱉"),Js61GTdX5wzMurUqi7Z(u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ᱊"),sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"࠴࠺࠷ả"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᱋"))
	XAozRfZ68H9x2OsiP3LmIaql1(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᱌"),Js61GTdX5wzMurUqi7Z(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠠษฯฮࠤ฾ฺ่ศศํࠫᱍ"),sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"࠵࠻࠺Ấ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᱎ"))
	XAozRfZ68H9x2OsiP3LmIaql1(RDwahqjPfbdyEiTtnLQu(u"ࠩࡩࡳࡱࡪࡥࡳࠩᱏ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ᱐"),sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠼࠼࠴ấ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᱑"))
	return
def b7l0kiavWztB9sre5FIMf1y():
	XAozRfZ68H9x2OsiP3LmIaql1(SE97R3Dpj6dPLweVKU(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᱒"),aYH620Dh48GEsTFfOBSQ7r(u"࠭࡟ࡊࡒࡗࡣࠬ᱓")+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡊࡒࡗ࡚ࠬ᱔"),sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠽࠶࠵Ầ"))
	XAozRfZ68H9x2OsiP3LmIaql1(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࡮࡬ࡲࡰ࠭᱕"),VXWOCAE6ns3paJ8DLG479NQfMu+SIkwCEdJHTD9v1(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ᱖")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"࠹࠺࠻࠼ầ"))
	for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
		Z0BYJQghVL1v87CAem = EJgYdjbIiWe1apkQlZcR42(u"ࠪࡣࡎࡖࠧ᱗")+str(J26JEXNRtmOrlj8qhesLYI0dKpQ)+hPFcB6Uxmabj59Iq(u"ࠫࡤ࠭᱘")
		XAozRfZ68H9x2OsiP3LmIaql1(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᱙"),Z0BYJQghVL1v87CAem+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᱚ")+dTacwSXg2MOGtHY[J26JEXNRtmOrlj8qhesLYI0dKpQ],sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"࠸࠸࠷Ẩ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱛ"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
	return
def EGYFymUSnZsl9b():
	XAozRfZ68H9x2OsiP3LmIaql1(jwzOabysh0Z(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱜ"),YQNd4wejLSAVJ6T(u"ࠩࡢࡑ࠸࡛࡟ࠨᱝ")+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡑ࠸࡛ࠧᱞ"),sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠹࠹࠹ẩ"))
	XAozRfZ68H9x2OsiP3LmIaql1(gDETKVh8mZe09Nd(u"ࠫࡱ࡯࡮࡬ࠩᱟ"),VXWOCAE6ns3paJ8DLG479NQfMu+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᱠ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠼࠽࠾࠿Ẫ"))
	for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
		Z0BYJQghVL1v87CAem = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭࡟ࡎࡗࠪᱡ")+str(J26JEXNRtmOrlj8qhesLYI0dKpQ)+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡠࠩᱢ")
		XAozRfZ68H9x2OsiP3LmIaql1(IOHSz7YPF9WusGgUt1Dq(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱣ"),Z0BYJQghVL1v87CAem+qeG16a4pbSHziNVQ2uFXrs(u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫᱤ")+dTacwSXg2MOGtHY[J26JEXNRtmOrlj8qhesLYI0dKpQ],sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"࠻࠻࠻ẫ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡪࡴࡲࡤࡦࡴࠪᱥ"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
	return
def ff3nv7dbe0yUkHL(oT2iHwjfBx0FPX5ZCph9aWs38):
	global BfGYWT9AcviCDwn,hFT3NSxgnXwMZL8frYCU52cB
	lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
	try:
		if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡎࡌࡉࡍࡏࠪᱦ") in oT2iHwjfBx0FPX5ZCph9aWs38: lDt71RPxgnZs0LzHurJAdqU(oT2iHwjfBx0FPX5ZCph9aWs38)
		else: lDt71RPxgnZs0LzHurJAdqU()
		pmITdHi6V1hU3 = lvzrYTpcBaK
	except:
		M4kqclZxfAHteyg3RF9()
		pmITdHi6V1hU3 = ndkUxG9LtewJ
	oT2iHwjfBx0FPX5ZCph9aWs38 = g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38)
	if pmITdHi6V1hU3:
		iRaHzNpJhSx6ZnCfrvD7j93lks(oT2iHwjfBx0FPX5ZCph9aWs38,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ็ิๅࠢ็่ศูแࠨᱧ"),hDjf1Ubgq629nXlOvcFLH4Jw=YQNd4wejLSAVJ6T(u"࠷࠶࠰࠱Ậ"))
		BfGYWT9AcviCDwn += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		hFT3NSxgnXwMZL8frYCU52cB += IOHSz7YPF9WusGgUt1Dq(u"࠭ࠠ࠯ࠢࠪᱨ")+oT2iHwjfBx0FPX5ZCph9aWs38
	else: iRaHzNpJhSx6ZnCfrvD7j93lks(oT2iHwjfBx0FPX5ZCph9aWs38,sCHVtMAvqirbQ4BUK3cgWo,hDjf1Ubgq629nXlOvcFLH4Jw=SE97R3Dpj6dPLweVKU(u"࠷࠰࠱࠲ậ"))
	return
G7ZIPF3Qw2u6C10WkoXRTK8tlvm = {}
def FFYK70nUmu(izaCdj1N853f6EWR4ghD=ndkUxG9LtewJ):
	global BfGYWT9AcviCDwn,hFT3NSxgnXwMZL8frYCU52cB,G7ZIPF3Qw2u6C10WkoXRTK8tlvm
	if not izaCdj1N853f6EWR4ghD:
		G7ZIPF3Qw2u6C10WkoXRTK8tlvm = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡥ࡫ࡦࡸࠬᱩ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩᱪ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧᱫ"))
		if G7ZIPF3Qw2u6C10WkoXRTK8tlvm: return
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡧࡪࡴࡴࡦࡴࠪᱬ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫาะ้ࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳࠴ࠠิ์ไัฺࠦวๅสิ๊ฬ๋ฬࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢะฮ๎๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳࠴ࠠฬ็ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬำุๆ้ࠡำ๋ࠥอไฤไึห๊ࠦอห๋่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่่หํวࠡ็ิอࠥษฮา๋ࠣ࠲࠳ࠦ็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࡟ࡲࡡࡴࠧᱭ")+VXWOCAE6ns3paJ8DLG479NQfMu+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠศๆล๊ࠥลࠧᱮ")+B8alA5nvIhTxQ)
	if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return
	YgJ3ybSlEOxXUL7m(VMB1l2JKvI,VMB1l2JKvI,VMB1l2JKvI)
	cVZS4by3K6nMXhmuH7OI = Q1siCkTZyw.menuItemsLIST
	BfGYWT9AcviCDwn,hFT3NSxgnXwMZL8frYCU52cB,threads = BewrUo9ANCa17G43Sn0LH5xh,sCHVtMAvqirbQ4BUK3cgWo,{}
	for oT2iHwjfBx0FPX5ZCph9aWs38 in yy2piuoUNchWGelADxq7Q1:
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		threads[oT2iHwjfBx0FPX5ZCph9aWs38] = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=ff3nv7dbe0yUkHL,args=(oT2iHwjfBx0FPX5ZCph9aWs38,))
		threads[oT2iHwjfBx0FPX5ZCph9aWs38].start()
	else:
		for oT2iHwjfBx0FPX5ZCph9aWs38 in list(threads.keys()): threads[oT2iHwjfBx0FPX5ZCph9aWs38].join()
	Q1siCkTZyw.menuItemsLIST[:] = cVZS4by3K6nMXhmuH7OI
	G7ZIPF3Qw2u6C10WkoXRTK8tlvm = {}
	for oT2iHwjfBx0FPX5ZCph9aWs38 in list(threads.keys()):
		try: FXns4zKPZ3JW61HbuhidaRNgToMj = Q1siCkTZyw.menuItemsDICT[oT2iHwjfBx0FPX5ZCph9aWs38]
		except: continue
		oT2iHwjfBx0FPX5ZCph9aWs38 = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭࡟ࡍࡕࡗࡣࠬᱯ")+g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38)
		for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD in FXns4zKPZ3JW61HbuhidaRNgToMj:
			if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = zLjWeKu6JgNO7vocUD0Qpy(u"ࠧ࠯࠰࠱࠲ࠬᱰ")
			else:
				if hoVitY5TylJ7GBEIZNOQg8pukq.count(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡡࠪᱱ"))>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.split(EJgYdjbIiWe1apkQlZcR42(u"ࠩࡢࠫᱲ"),rgpY5VUqKbeFOCD9Nki2SmGvxEja)[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࢤࠬᱳ"),sCHVtMAvqirbQ4BUK3cgWo).replace(gDETKVh8mZe09Nd(u"ࠫࠥࡎࡄࠨᱴ"),sCHVtMAvqirbQ4BUK3cgWo).replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡎࡄࠡࠩᱵ"),sCHVtMAvqirbQ4BUK3cgWo)
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(Js61GTdX5wzMurUqi7Z(u"࠭เࠨᱶ"),sCHVtMAvqirbQ4BUK3cgWo).replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧสࠩᱷ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠨ้ࠪᱸ")).replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩวࠫᱹ"),EJgYdjbIiWe1apkQlZcR42(u"ࠪ์ࠬᱺ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(IO7k2hZXSz(u"ࠫศ࠭ᱻ"),sH6BOz5wKRFcEg(u"ࠬอࠧᱼ")).replace(TzIj50KpohEOHx6CbZWqB(u"࠭ลࠨᱽ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠧศࠩ᱾")).replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨฤࠪ᱿"),YQNd4wejLSAVJ6T(u"ࠩสࠫᲀ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(SIkwCEdJHTD9v1(u"่ࠪศ࠭ᲁ"),IOHSz7YPF9WusGgUt1Dq(u"้ࠫอࠧᲂ")).replace(hPFcB6Uxmabj59Iq(u"๊ࠬลࠨᲃ"),SIkwCEdJHTD9v1(u"࠭ไศࠩᲄ")).replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧๅฤࠪᲅ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨๆสࠫᲆ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(sH6BOz5wKRFcEg(u"ࠩ๑ࠫᲇ"),sCHVtMAvqirbQ4BUK3cgWo).replace(YQNd4wejLSAVJ6T(u"ࠪ๏ࠬᲈ"),sCHVtMAvqirbQ4BUK3cgWo).replace(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ๔࠭Ᲊ"),sCHVtMAvqirbQ4BUK3cgWo).replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬ๒ࠧᲊ"),sCHVtMAvqirbQ4BUK3cgWo)
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(gDETKVh8mZe09Nd(u"࠭๐ࠨ᲋"),sCHVtMAvqirbQ4BUK3cgWo).replace(sH6BOz5wKRFcEg(u"ࠧ๎ࠩ᲌"),sCHVtMAvqirbQ4BUK3cgWo).replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ๔ࠪ᲍"),sCHVtMAvqirbQ4BUK3cgWo).replace(bGzRdmOErkIylxALniq6(u"ࠩ๔ࠫ᲎"),sCHVtMAvqirbQ4BUK3cgWo)
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࢀࠬ᲏"),sCHVtMAvqirbQ4BUK3cgWo).replace(EJgYdjbIiWe1apkQlZcR42(u"ࠫࢃ࠭Ა"),sCHVtMAvqirbQ4BUK3cgWo)
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(gDETKVh8mZe09Nd(u"ࠬอ่็ࠢ็ห๏์ࠧᲑ"),sCHVtMAvqirbQ4BUK3cgWo).replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ำ๋็สࠤ้อ๊หࠩᲒ"),sCHVtMAvqirbQ4BUK3cgWo)
				cTjpJBLzO4d19wiZAP = [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧศๆ฼หอ࠭Დ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨะํห้࠭Ე"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩส่อ๎ๅࠨᲕ"),YQNd4wejLSAVJ6T(u"ࠪห้อๆࠨᲖ"),qqw1upCsKM(u"ࠫฬ฽แศๆࠪᲗ"),sH6BOz5wKRFcEg(u"ࠬำวๅ์๊ࠫᲘ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭วๅ฼สึࠬᲙ"),IOHSz7YPF9WusGgUt1Dq(u"ࠧึษ็ัࠬᲚ"),SE97R3Dpj6dPLweVKU(u"ࠨษ็ำ๏์ࠧᲛ"),BWfpRku7SsM6cbE0eG(u"่ࠩ์ฬ๊๊ะࠩᲜ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪห้฿วๅ็ࠪᲝ"),qqw1upCsKM(u"ࠫฬ฿ๅศๆࠪᲞ")]
				if not any(VVIdbMLzmrBwlR72u in hoVitY5TylJ7GBEIZNOQg8pukq for VVIdbMLzmrBwlR72u in cTjpJBLzO4d19wiZAP): hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠬอไࠨᲟ"),sCHVtMAvqirbQ4BUK3cgWo)
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭วฯำํࠫᲠ"),gDETKVh8mZe09Nd(u"ࠧศะิํࠬᲡ")).replace(RDwahqjPfbdyEiTtnLQu(u"ࠨษฯ๊อ๏ࠧᲢ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠩสะ๋ฮ๊ࠨᲣ")).replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ฽ฬฬไ๋้ࠪᲤ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠫ฾อฦๅ์ࠪᲥ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠬอฬ็สํ๋ࠬᲦ"),gDETKVh8mZe09Nd(u"࠭วอ่ห๎ࠬᲧ")).replace(aYH620Dh48GEsTFfOBSQ7r(u"ฺࠧำห๎์࠭Შ"),Js61GTdX5wzMurUqi7Z(u"ࠨ฻ิฬ๏࠭Ჩ")).replace(IOHSz7YPF9WusGgUt1Dq(u"ࠩิ์๊อๆิ์๊ࠫᲪ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪีํ๋ว็ีํࠫᲫ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(SE97R3Dpj6dPLweVKU(u"ࠫ฿ืศ๋้ࠪᲬ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠬเัษ์ࠪᲭ")).replace(jwzOabysh0Z(u"่࠭ࠡ็ึุ่๊วหࠩᲮ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧๆี็ื้อสࠨᲯ")).replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠨษ฽ห๋๏ࠧᲰ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩส฾ฬ์๊ࠨᲱ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠪฮฬื๊ฯ์ࠪᲲ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫฯอั๋ะࠪᲳ")).replace(qqw1upCsKM(u"ࠬิ๊ศๆࠣ฽้๋๊ࠨᲴ"),aYH620Dh48GEsTFfOBSQ7r(u"࠭ฮ๋ษ็ࠫᲵ")).replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧๆ๊ึ๎็๐็ࠨᲶ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠨ็๋ื๏่้ࠨᲷ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"๊๊ࠩิ๏ࠧᲸ"),qqw1upCsKM(u"๋๋ࠪี๊ࠨᲹ")).replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫ์์ฯ๋้ࠪᲺ"),IO7k2hZXSz(u"ࠬํๆะ์ࠪ᲻")).replace(bGzRdmOErkIylxALniq6(u"่࠭ฬษษๆ๏ํࠧ᲼"),EJgYdjbIiWe1apkQlZcR42(u"้ࠧอสส็๐ࠧᲽ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(GVurlv8HeoXEzPRiQB7Ty(u"ࠨฬ็๎ๆุ๊้่ํ๋ࠬᲾ"),hPFcB6Uxmabj59Iq(u"ࠩอ่ๆุ๊้่ࠪᲿ")).replace(BWfpRku7SsM6cbE0eG(u"ࠪฮ้็า๋๊้๎์࠭᳀"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫฯ๊แำ์๋๊ࠬ᳁")).replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠬ๎ࠠไำอ์๋࠭᳂"),SIkwCEdJHTD9v1(u"่࠭ไำอ์๋࠭᳃"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(jwzOabysh0Z(u"ࠧศๆะห้๐็ࠨ᳄"),bGzRdmOErkIylxALniq6(u"ࠨฯส่๏ํࠧ᳅")).replace(t19ZOVHA4CpwFKaeiubcMGvz(u"่ࠩ์ุ໒โ๋ࠩ᳆"),aYH620Dh48GEsTFfOBSQ7r(u"้ࠪํู๊ใ๋ࠪ᳇")).replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠫฬ๊ว็็ํࠫ᳈"),BWfpRku7SsM6cbE0eG(u"ࠬอๆๆ์ࠪ᳉"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(EJgYdjbIiWe1apkQlZcR42(u"࠭วๅ็ึุ่๊วหࠩ᳊"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧๆี็ื้อสࠨ᳋")).replace(IO7k2hZXSz(u"ࠨษ็ฬึอๅอࠩ᳌"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩหีฬ๋ฬࠨ᳍")).replace(jwzOabysh0Z(u"ࠪ็ฬืส้่ࠪ᳎"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"่ࠫืส้่ࠪ᳏"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(RDwahqjPfbdyEiTtnLQu(u"ࠬำั้สࠪ᳐"),YQNd4wejLSAVJ6T(u"࠭อาสࠪ᳑")).replace(BWfpRku7SsM6cbE0eG(u"ࠧศๆส๊ฬฺ๊ะࠩ᳒"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨษ้หู๐ฯࠨ᳓")).replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠩสื๏๎᳔๊่ࠩ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪหุ๐่๋᳕ࠩ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(YQNd4wejLSAVJ6T(u"ࠫ฾ืศ๊᳖ࠩ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬ฿ัษ์᳗ࠪ")).replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭สาๅ์᳘ࠫ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠧหำๆ๎᳙ࠬ")).replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨฬิ็๏ํࠧ᳚"),aenpKvQCGVzhLXEdWiDIZ(u"ࠩอี่๐ࠧ᳛")).replace(TzIj50KpohEOHx6CbZWqB(u"ࠪห้๋ึศใ᳜ࠪ"),aYH620Dh48GEsTFfOBSQ7r(u"๊ࠫ฼วโ᳝ࠩ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(Js61GTdX5wzMurUqi7Z(u"ࠬื๊ศุํ᳞ࠫ"),Js61GTdX5wzMurUqi7Z(u"࠭ั๋ษูอ᳟ࠬ")).replace(bGzRdmOErkIylxALniq6(u"ࠧา์สฺ์࠭᳠"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨำํห฻ฯࠧ᳡")).replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩสื๏๎᳢๊่ࠩ"),sH6BOz5wKRFcEg(u"ࠪหุ๐᳣่๋ࠩ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"่ࠫ๎ๅ๋ั์᳤ࠫ"),EJgYdjbIiWe1apkQlZcR42(u"้่ࠬๆ์า๎᳥ࠬ")).replace(RDwahqjPfbdyEiTtnLQu(u"࠭ใ้็ํำ๏ํ᳦ࠧ"),bGzRdmOErkIylxALniq6(u"ࠧไ๊่๎ิ๐᳧ࠧ")).replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨษ้๎๊๐᳨ࠧ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩส๊๊๐ࠧᳩ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠪห๋๐ๅ๋ึ้ࠫᳪ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫฬ์ๅ๋ึ้ࠫᳫ")).replace(Js61GTdX5wzMurUqi7Z(u"ࠬอๆๆ๋ࠪᳬ"),bGzRdmOErkIylxALniq6(u"࠭ว็็ํุ๋᳭࠭")).replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧศ่่๎ࠬᳮ"),EJgYdjbIiWe1apkQlZcR42(u"ࠨษ้้๏ฺๆࠨᳯ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩส๊๊๐ิ็ึ้ࠫᳰ"),qqw1upCsKM(u"ࠪห๋๋๊ี่ࠪᳱ")).replace(qeG16a4pbSHziNVQ2uFXrs(u"ࠫฬ๊ว็็ํุ๋࠭ᳲ"),IO7k2hZXSz(u"ࠬอๆๆ์ื๊ࠬᳳ")).replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭วโๆส้๋ࠥำๅี็หฯ࠭᳴"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧศใ็ห๊่ࠦๆี็ื้อสࠨᳵ"))
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).strip(qqw1upCsKM(u"ࠨ࠯ࠪᳶ")).strip(AAh0X3OCacr4HpifRGLZKT)
			if hoVitY5TylJ7GBEIZNOQg8pukq not in list(G7ZIPF3Qw2u6C10WkoXRTK8tlvm.keys()): G7ZIPF3Qw2u6C10WkoXRTK8tlvm[hoVitY5TylJ7GBEIZNOQg8pukq] = {}
			G7ZIPF3Qw2u6C10WkoXRTK8tlvm[hoVitY5TylJ7GBEIZNOQg8pukq][oT2iHwjfBx0FPX5ZCph9aWs38] = [iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD]
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,gDETKVh8mZe09Nd(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ᳷"),IOHSz7YPF9WusGgUt1Dq(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࡣࡆࡒࡌࠨ᳸"),G7ZIPF3Qw2u6C10WkoXRTK8tlvm,IfAkw39UvaYWEDXLthFrbSzG)
	if BfGYWT9AcviCDwn>=hHgazZFwbfj8Sn: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,GVurlv8HeoXEzPRiQB7Ty(u"้ࠫี๊ไุ่่๊ࠢษࠡใํࠤࠬ᳹")+str(BfGYWT9AcviCDwn)+qqw1upCsKM(u"ࠬࠦๅ้ไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎็ไาสࠤฺ๊ใๅหࠣือฮ็ศࠢ฼หิฯࠠๆ่ࠣห้หๆหำ้๎ฯูࠦ็ัๆࠤํอไๆ๊สๆ฾ࠦ็๋࠼ࠪᳺ")+hFT3NSxgnXwMZL8frYCU52cB)
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Js61GTdX5wzMurUqi7Z(u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬ᳻"))
	YgJ3ybSlEOxXUL7m(K3nC0rDSptmG,K3nC0rDSptmG,K3nC0rDSptmG)
	xxpJdCwRN6SrscbOmga7h5UlHBiW()
	return
def WhC0jgVlb8(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP):
	R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
	Z6bx30Qg8jkIlrqhXvTsRGAV = Q1siCkTZyw.menuItemsLIST
	Q1siCkTZyw.menuItemsLIST[:] = []
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP and oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ᳼") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
		ka7jz96YCdTBnQOLVPuJG3285MHf = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࡮࡬ࡷࡹ࠭᳽"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ᳾"),IOHSz7YPF9WusGgUt1Dq(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫ᳿")+J26JEXNRtmOrlj8qhesLYI0dKpQ)
	elif hPFcB6Uxmabj59Iq(u"ࠫࡤࡒࡉࡗࡇࡢࠫᴀ") not in mHY2EseIvtnoF6Ax0KWdQVrLP or qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡥࡖࡐࡆࡢࠫᴁ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
		import ebtl4A2fjS
		Iqm6XAWBlF = Js61GTdX5wzMurUqi7Z(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫᴂ")
		if IO7k2hZXSz(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᴃ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			try: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᴄ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+SIkwCEdJHTD9v1(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴅ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫᴆ"),Iqm6XAWBlF)
			try: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,qeG16a4pbSHziNVQ2uFXrs(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᴇ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+sH6BOz5wKRFcEg(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴈ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᴉ"),Iqm6XAWBlF)
			try: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,qqw1upCsKM(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᴊ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+IOHSz7YPF9WusGgUt1Dq(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᴋ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪᴌ"),Iqm6XAWBlF)
		if aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡣ࡛ࡕࡄࡠࠩᴍ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			try: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,Js61GTdX5wzMurUqi7Z(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᴎ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴏ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫᴐ"),Iqm6XAWBlF)
			try: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᴑ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᴒ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧᴓ"),Iqm6XAWBlF)
		ka7jz96YCdTBnQOLVPuJG3285MHf = Q1siCkTZyw.menuItemsLIST
		if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᴔ"),EJgYdjbIiWe1apkQlZcR42(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬᴕ")+J26JEXNRtmOrlj8qhesLYI0dKpQ,ka7jz96YCdTBnQOLVPuJG3285MHf,IfAkw39UvaYWEDXLthFrbSzG)
	Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def auWNV5nl9qOMhbGdZrf7j(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP):
	R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
	Z6bx30Qg8jkIlrqhXvTsRGAV = Q1siCkTZyw.menuItemsLIST
	Q1siCkTZyw.menuItemsLIST[:] = []
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP and oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᴖ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
		ka7jz96YCdTBnQOLVPuJG3285MHf = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,t19ZOVHA4CpwFKaeiubcMGvz(u"࠭࡬ࡪࡵࡷࠫᴗ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ᴘ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨᴙ")+J26JEXNRtmOrlj8qhesLYI0dKpQ)
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᴚ") not in mHY2EseIvtnoF6Ax0KWdQVrLP or t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡣ࡛ࡕࡄࡠࠩᴛ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
		import Sce6q5zwUj
		Iqm6XAWBlF = TzIj50KpohEOHx6CbZWqB(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡำึหห๊ࠠศๆหี๋อๅอࠩᴜ")
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡥࡌࡊࡘࡈࡣࠬᴝ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			try: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᴞ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴟ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊แ๋ัํ์์อสࠨᴠ"),Iqm6XAWBlF)
			try: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,t19ZOVHA4CpwFKaeiubcMGvz(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᴡ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴢ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᴣ"),Iqm6XAWBlF)
			try: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᴤ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+GVurlv8HeoXEzPRiQB7Ty(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴥ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᴦ"),Iqm6XAWBlF)
		if aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡡ࡙ࡓࡉࡥࠧᴧ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			try: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᴨ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+RDwahqjPfbdyEiTtnLQu(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴩ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨᴪ"),Iqm6XAWBlF)
			try: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(J26JEXNRtmOrlj8qhesLYI0dKpQ,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᴫ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,mHY2EseIvtnoF6Ax0KWdQVrLP+IOHSz7YPF9WusGgUt1Dq(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴬ"),lvzrYTpcBaK)
			except: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᴭ"),Iqm6XAWBlF)
		ka7jz96YCdTBnQOLVPuJG3285MHf = Q1siCkTZyw.menuItemsLIST
		if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᴮ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩᴯ")+J26JEXNRtmOrlj8qhesLYI0dKpQ,ka7jz96YCdTBnQOLVPuJG3285MHf,IfAkw39UvaYWEDXLthFrbSzG)
	Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def IP3rok2TcX(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP,G2YolWZq41cxE):
	YgJ3ybSlEOxXUL7m(EctkVfa3Tr6PdbX9UJ2,EctkVfa3Tr6PdbX9UJ2,VMB1l2JKvI)
	if G2YolWZq41cxE: FFYK70nUmu(lvzrYTpcBaK)
	elif sH6BOz5wKRFcEg(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᴰ") in mHY2EseIvtnoF6Ax0KWdQVrLP and not G2YolWZq41cxE: FFYK70nUmu(ndkUxG9LtewJ)
	b2V6tvAsuxUikeYPL = mHY2EseIvtnoF6Ax0KWdQVrLP.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᴱ"),sCHVtMAvqirbQ4BUK3cgWo).replace(gDETKVh8mZe09Nd(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᴲ"),sCHVtMAvqirbQ4BUK3cgWo).replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴳ"),sCHVtMAvqirbQ4BUK3cgWo)
	if not G2YolWZq41cxE:
		XAozRfZ68H9x2OsiP3LmIaql1(sH6BOz5wKRFcEg(u"ࠧ࡭࡫ࡱ࡯ࠬᴴ"),sH6BOz5wKRFcEg(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦวๅลๅืฬ๋ࠧᴵ"),sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠷࠷࠵Ắ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᴶ")+b2V6tvAsuxUikeYPL,sCHVtMAvqirbQ4BUK3cgWo,{aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴷ"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
		XAozRfZ68H9x2OsiP3LmIaql1(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡱ࡯࡮࡬ࠩᴸ"),VXWOCAE6ns3paJ8DLG479NQfMu+oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᴹ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠺࠻࠼࠽ắ"))
		tF8cULEI3N7 = [oVwa0kcqxj1e7mLplAfZdGT(u"࠭รโๆส้ࠬᴺ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧๆี็ื้อสࠨᴻ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨ็ึีา๐วหࠩᴼ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠩหีฬ๋ฬࠨᴽ"),SE97R3Dpj6dPLweVKU(u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩᴾ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠫึ๋ึศ่ࠪᴿ"),Js61GTdX5wzMurUqi7Z(u"ࠬษอะอ࠰วำืࠧᵀ"),gDETKVh8mZe09Nd(u"࠭ำๅษึ่ࠬᵁ"),Js61GTdX5wzMurUqi7Z(u"ࠧๆ๊ึ๎็๏ࠧᵂ"),RDwahqjPfbdyEiTtnLQu(u"ࠨลื๋ึ࠳รไอิࠫᵃ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠩส่ว์ࠧᵄ"),qqw1upCsKM(u"ฺࠪา้ࠧᵅ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫึ๐วืหࠪᵆ"),IOHSz7YPF9WusGgUt1Dq(u"ࠬ์๊หใ็็ุ࠭ᵇ"),YQNd4wejLSAVJ6T(u"࠭ๅๆอ็๎๋࠭ᵈ"),SIkwCEdJHTD9v1(u"ࠧษอࠣั๏࠭ᵉ"),TzIj50KpohEOHx6CbZWqB(u"ࠨัํ๊๏ฯࠧᵊ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩึ๊ํอสࠨᵋ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪวำื้ࠨᵌ")]
		G2YolWZq41cxE = BewrUo9ANCa17G43Sn0LH5xh
		for Pe09LbEydSWxAB7RV8ZplfYGOjnQ5v in tF8cULEI3N7:
			G2YolWZq41cxE += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			XAozRfZ68H9x2OsiP3LmIaql1(aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵍ"),Z0BYJQghVL1v87CAem+Pe09LbEydSWxAB7RV8ZplfYGOjnQ5v,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"࠹࠹࠷Ằ"),sCHVtMAvqirbQ4BUK3cgWo,str(G2YolWZq41cxE),b2V6tvAsuxUikeYPL,sCHVtMAvqirbQ4BUK3cgWo,{XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵎ"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
	else:
		UcK2zDnOlEZ7Vwad8 = [zLjWeKu6JgNO7vocUD0Qpy(u"࠭วโๆส้ࠬᵏ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭ᵐ"),RDwahqjPfbdyEiTtnLQu(u"ࠨใํ่๊࠭ᵑ"),TzIj50KpohEOHx6CbZWqB(u"ࠩไ่๊࠭ᵒ")]
		ddDLz2MFtS9Irsy5gi7CwvJ8c = [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ุ้๊ࠪำๅࠩᵓ"),SE97R3Dpj6dPLweVKU(u"ࠫࡸ࡫ࡲࡪࡧࡶࠫᵔ")]
		PaUpRMAIguJq = [SE97R3Dpj6dPLweVKU(u"๋ࠬำศำะࠫᵕ"),Js61GTdX5wzMurUqi7Z(u"࠭ๅิำะ๎ฬะࠧᵖ")]
		SQA9nqgV1XMjKNbGlFx = [zLjWeKu6JgNO7vocUD0Qpy(u"ࠧษำส้ั࠭ᵗ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡵ࡫ࡳࡼ࠭ᵘ"),Js61GTdX5wzMurUqi7Z(u"ࠩอ่ๆุ๊้่ࠪᵙ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪฮ้๐แำ์๋๊ࠬᵚ")]
		JChq6N98expEazfdi7Hb = [aenpKvQCGVzhLXEdWiDIZ(u"ࠫฬ์ๅ๋ࠩᵛ"),YQNd4wejLSAVJ6T(u"้ࠬัห๊้ࠫᵜ"),IO7k2hZXSz(u"࠭ใศำอ์๋࠭ᵝ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࡬࡫ࡧࡷࠬᵞ"),IO7k2hZXSz(u"ࠨูไ่ࠬᵟ"),EJgYdjbIiWe1apkQlZcR42(u"ࠩส฻ๆอไࠨᵠ")]
		Oi36L4kAcCK2 = [IO7k2hZXSz(u"ࠪี๊฼ว็ࠩᵡ")]
		dh1kDr9texw6szfNu = [Js61GTdX5wzMurUqi7Z(u"ࠫฬำฯฬࠩᵢ"),TzIj50KpohEOHx6CbZWqB(u"ࠬอฮาࠩᵣ"),gDETKVh8mZe09Nd(u"࠭ๅ้ะิࠫᵤ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧอัํำࠬᵥ"),bGzRdmOErkIylxALniq6(u"ࠨ็ูหๆ࠭ᵦ"),bGzRdmOErkIylxALniq6(u"ࠩะำ๏ัࠧᵧ")]
		GtLOfW7nvTSpJryFlYHAkU50V2xoZ = [aYH620Dh48GEsTFfOBSQ7r(u"ࠪื้อำๅࠩᵨ"),aenpKvQCGVzhLXEdWiDIZ(u"ุ๊ࠫำๅ้ࠪᵩ")]
		sZHhFUjKtkVbJzl = [aYH620Dh48GEsTFfOBSQ7r(u"ࠬอฺศ่ํࠫᵪ"),RDwahqjPfbdyEiTtnLQu(u"࠭ๅ้ีํๆ๎࠭ᵫ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠧไๆํฬࠬᵬ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨฯไ่ࠬᵭ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡰࡹࡸ࡯ࡣࠨᵮ")]
		oyHLviwPc13stmg60OnZNJ = [E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪห่ััࠨᵯ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠫฬฺ็าࠩᵰ"),fvYGxnZNUiyP4HJkMIoS25(u"๋ࠬๅ๋ิ๊ࠫᵱ"),YQNd4wejLSAVJ6T(u"࠭วฺๆ์ࠫᵲ"),SE97R3Dpj6dPLweVKU(u"ࠧๆะอหึํࠧᵳ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨ็ัฮฬืวหࠩᵴ"),gDETKVh8mZe09Nd(u"ࠩสๆํ๏ࠧᵵ")]
		mSQh6Ufb0oBtW2KaIA = [Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪห้อๆࠨᵶ"),RDwahqjPfbdyEiTtnLQu(u"ࠫาอไ๋ࠩᵷ"),gDETKVh8mZe09Nd(u"๋ࠬหษฬࠪᵸ"),t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ัศศฯࠫᵹ")]
		xFe4mOi0a9QYkPUJgKwvSXrGpsT3D = [t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧืฯๆࠫᵺ"),Js61GTdX5wzMurUqi7Z(u"ࠨๅ๋้๏ี๊ࠨᵻ")]
		cn7WQbZdv3rOlpUgYftL2HGPi9umhk = [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩิ๎ฬ฼็ࠨᵼ"),SIkwCEdJHTD9v1(u"ࠪ็ํื็ࠨᵽ"),Js61GTdX5wzMurUqi7Z(u"๊ࠫ฻วา฻๊ࠫᵾ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ฺ่ࠬหࠩᵿ"),qqw1upCsKM(u"࠭ั๋ษูอࠬᶀ")]
		xxeYQKA7rwhvG = [IO7k2hZXSz(u"ࠧ็์อๅ้้ำࠨᶁ"),jwzOabysh0Z(u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩᶂ"),IO7k2hZXSz(u"้ࠩ๎ฯ็ไ๋ๅึࠫᶃ")]
		rrbyQEeSYkHit = [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"้๊ࠪัไ๋่ࠪᶄ"),TzIj50KpohEOHx6CbZWqB(u"ࠫฬฺฮศืࠪᶅ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ์ฬ้็ࠪᶆ")]
		I2IfwUGCn68MRT3QFhWNjsDxrb = [RDwahqjPfbdyEiTtnLQu(u"࠭ศฬࠢะ๎ࠬᶇ"),SE97R3Dpj6dPLweVKU(u"ࠧ࡭࡫ࡹࡩࠬᶈ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨไ้ห์࠭ᶉ"),TzIj50KpohEOHx6CbZWqB(u"ࠩๅ๊ํอสࠨᶊ")]
		nnQRzZ0pugk7j = [oVwa0kcqxj1e7mLplAfZdGT(u"ࠪำ๏์ࠧᶋ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠫฬีู๋้ࠪᶌ"),aenpKvQCGVzhLXEdWiDIZ(u"ุ๊ࠬศำสฮࠬᶍ"),fvYGxnZNUiyP4HJkMIoS25(u"࠭ไุ็ํหฯ࠭ᶎ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧะ฻สลࠬᶏ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨไิห๋࠭ᶐ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩๅูฬฬฯࠨᶑ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪีะอมࠨᶒ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"๊ࠫืฬฺ์๊ࠫᶓ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬอะศ่ࠪᶔ"),sH6BOz5wKRFcEg(u"࠭วิๆส้ࠬᶕ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧห๊สุ๏ำࠧᶖ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨะฺฬࠬᶗ"),gDETKVh8mZe09Nd(u"ࠩะ์ื๎๊ࠨᶘ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠪ฽ฯฮวหࠩᶙ"),t19ZOVHA4CpwFKaeiubcMGvz(u"๊ࠫ๎วๅ์าࠫᶚ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ์่ศ฻ํࠫᶛ"),BWfpRku7SsM6cbE0eG(u"ู࠭ใษษำࠬᶜ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧศ่สุ๏ีࠧᶝ")]
		HKgGhVAo8bvdDNC2L = [IO7k2hZXSz(u"ࠨ࠴࠳࠵࠵࠭ᶞ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠵࠴࠶࠷ࠧᶟ"),YQNd4wejLSAVJ6T(u"ࠪ࠶࠵࠷࠲ࠨᶠ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫ࠷࠶࠱࠴ࠩᶡ"),IOHSz7YPF9WusGgUt1Dq(u"ࠬ࠸࠰࠲࠶ࠪᶢ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠭࠲࠱࠳࠸ࠫᶣ"),BWfpRku7SsM6cbE0eG(u"ࠧ࠳࠲࠴࠺ࠬᶤ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨ࠴࠳࠵࠼࠭ᶥ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠩ࠵࠴࠶࠾ࠧᶦ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠪ࠶࠵࠷࠹ࠨᶧ"),jwzOabysh0Z(u"ࠫ࠷࠶࠲࠱ࠩᶨ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠬ࠸࠰࠳࠳ࠪᶩ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭࠲࠱࠴࠵ࠫᶪ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࠳࠲࠵࠷ࠬᶫ"),BWfpRku7SsM6cbE0eG(u"ࠨ࠴࠳࠶࠹࠭ᶬ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࠵࠴࠷࠻ࠧᶭ"),BWfpRku7SsM6cbE0eG(u"ࠪ࠶࠵࠸࠶ࠨᶮ"),BWfpRku7SsM6cbE0eG(u"ࠫ࠷࠶࠲࠸ࠩᶯ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠸࠰࠳࠺ࠪᶰ")]
		for hoVitY5TylJ7GBEIZNOQg8pukq in sorted(list(G7ZIPF3Qw2u6C10WkoXRTK8tlvm.keys())):
			XXqGLnKo8vWYh1IMz9C0 = hoVitY5TylJ7GBEIZNOQg8pukq.lower()
			B4SziFvRIXpPeGmfZDw3aVWJMAKNc = []
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in UcK2zDnOlEZ7Vwad8): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in ddDLz2MFtS9Irsy5gi7CwvJ8c): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(rgpY5VUqKbeFOCD9Nki2SmGvxEja)
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in PaUpRMAIguJq): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(vUnJhT2NO8yirHcAmg)
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in SQA9nqgV1XMjKNbGlFx): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(kK7gj9HE462hADJbvr)
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in JChq6N98expEazfdi7Hb): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(tBMCpcY2vUV1dEjZ7PDG)
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in Oi36L4kAcCK2): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(GVurlv8HeoXEzPRiQB7Ty(u"࠹ằ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in dh1kDr9texw6szfNu) and XXqGLnKo8vWYh1IMz9C0 not in [XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭วฯำ์ࠫᶱ")]: B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(jwzOabysh0Z(u"࠻Ẳ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in GtLOfW7nvTSpJryFlYHAkU50V2xoZ): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(aYH620Dh48GEsTFfOBSQ7r(u"࠽ẳ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in sZHhFUjKtkVbJzl): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠿Ẵ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in oyHLviwPc13stmg60OnZNJ): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(aenpKvQCGVzhLXEdWiDIZ(u"࠱࠱ẵ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in mSQh6Ufb0oBtW2KaIA): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(Js61GTdX5wzMurUqi7Z(u"࠲࠳Ặ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in xFe4mOi0a9QYkPUJgKwvSXrGpsT3D): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(hPFcB6Uxmabj59Iq(u"࠳࠵ặ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in cn7WQbZdv3rOlpUgYftL2HGPi9umhk): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠴࠷Ẹ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in xxeYQKA7rwhvG): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(zLjWeKu6JgNO7vocUD0Qpy(u"࠵࠹ẹ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in rrbyQEeSYkHit): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(SIkwCEdJHTD9v1(u"࠶࠻Ẻ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in I2IfwUGCn68MRT3QFhWNjsDxrb): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠷࠶ẻ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in nnQRzZ0pugk7j): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(gDETKVh8mZe09Nd(u"࠱࠸Ẽ"))
			if any(value in XXqGLnKo8vWYh1IMz9C0 for value in HKgGhVAo8bvdDNC2L): B4SziFvRIXpPeGmfZDw3aVWJMAKNc.append(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠲࠺ẽ"))
			if not B4SziFvRIXpPeGmfZDw3aVWJMAKNc: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = [BWfpRku7SsM6cbE0eG(u"࠳࠼Ế")]
			for h0d2iFau8GsoWqDpTEg in B4SziFvRIXpPeGmfZDw3aVWJMAKNc:
				if str(h0d2iFau8GsoWqDpTEg)==G2YolWZq41cxE:
					XAozRfZ68H9x2OsiP3LmIaql1(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶲ"),Z0BYJQghVL1v87CAem+hoVitY5TylJ7GBEIZNOQg8pukq,hoVitY5TylJ7GBEIZNOQg8pukq,SE97R3Dpj6dPLweVKU(u"࠴࠺࠻ế"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,b2V6tvAsuxUikeYPL+TzIj50KpohEOHx6CbZWqB(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶳ"))
	YgJ3ybSlEOxXUL7m(EctkVfa3Tr6PdbX9UJ2,EctkVfa3Tr6PdbX9UJ2,K3nC0rDSptmG)
	return
def Y1sdLTAkqnuRhXN8KaFC6w4BtfvxHP(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP):
	R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP:
		XAozRfZ68H9x2OsiP3LmIaql1(YQNd4wejLSAVJ6T(u"ࠩ࡯࡭ࡳࡱࠧᶴ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡊࡒࡗ࡚ࠬᶵ"),sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠻࠻࠺Ề"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᶶ"),sCHVtMAvqirbQ4BUK3cgWo,{gDETKVh8mZe09Nd(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶷ"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
		XAozRfZ68H9x2OsiP3LmIaql1(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࡬ࡪࡰ࡮ࠫᶸ"),VXWOCAE6ns3paJ8DLG479NQfMu+EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᶹ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"࠾࠿࠹࠺ề"))
	Z6bx30Qg8jkIlrqhXvTsRGAV = Q1siCkTZyw.menuItemsLIST[:]
	import ebtl4A2fjS
	if J26JEXNRtmOrlj8qhesLYI0dKpQ:
		if not ebtl4A2fjS.l1au36XEkVRnFrs(J26JEXNRtmOrlj8qhesLYI0dKpQ,ndkUxG9LtewJ): return
		yNnjgRSIz0Ft8h713LkM = WhC0jgVlb8(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP)
		iIdvU69jyWzCs = sorted(yNnjgRSIz0Ft8h713LkM,reverse=lvzrYTpcBaK,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lower())
	else:
		if not ebtl4A2fjS.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
		if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP and jwzOabysh0Z(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᶺ") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			iIdvU69jyWzCs = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,EJgYdjbIiWe1apkQlZcR42(u"ࠩ࡯࡭ࡸࡺࠧᶻ"),YQNd4wejLSAVJ6T(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᶼ"),YQNd4wejLSAVJ6T(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᶽ"))
		else:
			pNrekSJFfb7EsQUdlz,iIdvU69jyWzCs,yNnjgRSIz0Ft8h713LkM = [],[],[]
			for pRVTLts8SB in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
				iIdvU69jyWzCs += WhC0jgVlb8(str(pRVTLts8SB),mHY2EseIvtnoF6Ax0KWdQVrLP)
			for type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in iIdvU69jyWzCs:
				if T67f3LG49xpP8zcN not in pNrekSJFfb7EsQUdlz:
					pNrekSJFfb7EsQUdlz.append(T67f3LG49xpP8zcN)
					JPADWUwge9smGQBvcqzRLpFt4kIN = type,hoVitY5TylJ7GBEIZNOQg8pukq,T67f3LG49xpP8zcN,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠷࠶࠶Ể"),Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,mHY2EseIvtnoF6Ax0KWdQVrLP,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q
					yNnjgRSIz0Ft8h713LkM.append(JPADWUwge9smGQBvcqzRLpFt4kIN)
			iIdvU69jyWzCs = sorted(yNnjgRSIz0Ft8h713LkM,reverse=lvzrYTpcBaK,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lower())
			if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,oVwa0kcqxj1e7mLplAfZdGT(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᶾ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪᶿ"),iIdvU69jyWzCs,IfAkw39UvaYWEDXLthFrbSzG)
	Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs
	Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def UUjh9kH05VedARfTsJKxi8rS4tQ(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP):
	R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP:
		XAozRfZ68H9x2OsiP3LmIaql1(aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࡭࡫ࡱ࡯ࠬ᷀"),SIkwCEdJHTD9v1(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡓ࠳ࡖࠩ᷁"),sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠷࠷࠷ể"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥ᷂ࠧ"),sCHVtMAvqirbQ4BUK3cgWo,{phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᷃"):J26JEXNRtmOrlj8qhesLYI0dKpQ})
		XAozRfZ68H9x2OsiP3LmIaql1(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡱ࡯࡮࡬ࠩ᷄"),VXWOCAE6ns3paJ8DLG479NQfMu+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ᷅")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"࠺࠻࠼࠽Ễ"))
	Z6bx30Qg8jkIlrqhXvTsRGAV = Q1siCkTZyw.menuItemsLIST[:]
	import Sce6q5zwUj
	if J26JEXNRtmOrlj8qhesLYI0dKpQ:
		if not Sce6q5zwUj.l1au36XEkVRnFrs(J26JEXNRtmOrlj8qhesLYI0dKpQ,ndkUxG9LtewJ): return
		yNnjgRSIz0Ft8h713LkM = auWNV5nl9qOMhbGdZrf7j(J26JEXNRtmOrlj8qhesLYI0dKpQ,mHY2EseIvtnoF6Ax0KWdQVrLP)
		iIdvU69jyWzCs = sorted(yNnjgRSIz0Ft8h713LkM,reverse=lvzrYTpcBaK,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lower())
	else:
		if not Sce6q5zwUj.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
		if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP and t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ᷆") not in mHY2EseIvtnoF6Ax0KWdQVrLP:
			iIdvU69jyWzCs = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,gDETKVh8mZe09Nd(u"ࠧ࡭࡫ࡶࡸࠬ᷇"),qqw1upCsKM(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ᷈"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬ᷉"))
		else:
			pNrekSJFfb7EsQUdlz,iIdvU69jyWzCs,yNnjgRSIz0Ft8h713LkM = [],[],[]
			for pRVTLts8SB in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
				iIdvU69jyWzCs += auWNV5nl9qOMhbGdZrf7j(str(pRVTLts8SB),mHY2EseIvtnoF6Ax0KWdQVrLP)
			for type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in iIdvU69jyWzCs:
				if T67f3LG49xpP8zcN not in pNrekSJFfb7EsQUdlz:
					pNrekSJFfb7EsQUdlz.append(T67f3LG49xpP8zcN)
					JPADWUwge9smGQBvcqzRLpFt4kIN = type,hoVitY5TylJ7GBEIZNOQg8pukq,T67f3LG49xpP8zcN,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠳࠹࠹ễ"),Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,mHY2EseIvtnoF6Ax0KWdQVrLP,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q
					yNnjgRSIz0Ft8h713LkM.append(JPADWUwge9smGQBvcqzRLpFt4kIN)
			iIdvU69jyWzCs = sorted(yNnjgRSIz0Ft8h713LkM,reverse=lvzrYTpcBaK,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lower())
			if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖ᷊ࠩ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ᷋"),iIdvU69jyWzCs,IfAkw39UvaYWEDXLthFrbSzG)
	Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs
	Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def Gk0X91WgTzaRZr3iYBPNfwEp2cqe(group,mHY2EseIvtnoF6Ax0KWdQVrLP):
	R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
	ka7jz96YCdTBnQOLVPuJG3285MHf = []
	iQfp2eKkgHt3IREYvF0Mw1q8sru9 = BWfpRku7SsM6cbE0eG(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ᷌") if t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡉࡑࡖ࡙ࠫ᷍") in mHY2EseIvtnoF6Ax0KWdQVrLP else aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡠࡏ࠶࡙ࡤ᷎࠭")
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: ka7jz96YCdTBnQOLVPuJG3285MHf = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࡮࡬ࡷࡹ᷏࠭"),gDETKVh8mZe09Nd(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖ᷐ࠫ")+iQfp2eKkgHt3IREYvF0Mw1q8sru9[:-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],group)
	if not ka7jz96YCdTBnQOLVPuJG3285MHf:
		for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: ka7jz96YCdTBnQOLVPuJG3285MHf += JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡰ࡮ࡹࡴࠨ᷑"),IO7k2hZXSz(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭᷒")+iQfp2eKkgHt3IREYvF0Mw1q8sru9[:-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],Js61GTdX5wzMurUqi7Z(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧᷓ")+iQfp2eKkgHt3IREYvF0Mw1q8sru9+str(J26JEXNRtmOrlj8qhesLYI0dKpQ))
			elif iQfp2eKkgHt3IREYvF0Mw1q8sru9==oVwa0kcqxj1e7mLplAfZdGT(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭ᷔ"): ka7jz96YCdTBnQOLVPuJG3285MHf += WhC0jgVlb8(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),sH6BOz5wKRFcEg(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᷕ"))
			elif iQfp2eKkgHt3IREYvF0Mw1q8sru9==sH6BOz5wKRFcEg(u"ࠨࡡࡐ࠷࡚ࡥࠧᷖ"): ka7jz96YCdTBnQOLVPuJG3285MHf += auWNV5nl9qOMhbGdZrf7j(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),RDwahqjPfbdyEiTtnLQu(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᷗ"))
		for type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in ka7jz96YCdTBnQOLVPuJG3285MHf:
			if T67f3LG49xpP8zcN==group: Wwod49PBvQO(type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
		items,Y0WVJ5CTpDO = [],[]
		for type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in Q1siCkTZyw.menuItemsLIST:
			gjFU25IEfw = type,hoVitY5TylJ7GBEIZNOQg8pukq[kK7gj9HE462hADJbvr:],url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,sCHVtMAvqirbQ4BUK3cgWo
			if gjFU25IEfw not in Y0WVJ5CTpDO:
				Y0WVJ5CTpDO.append(gjFU25IEfw)
				UqKgalXPCz7eQAL08foMx1R = type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q
				items.append(UqKgalXPCz7eQAL08foMx1R)
		ka7jz96YCdTBnQOLVPuJG3285MHf = sorted(items,reverse=lvzrYTpcBaK,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lower()[aYH620Dh48GEsTFfOBSQ7r(u"࠸Ệ"):])
		if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬᷘ")+iQfp2eKkgHt3IREYvF0Mw1q8sru9[:-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],group,ka7jz96YCdTBnQOLVPuJG3285MHf,IfAkw39UvaYWEDXLthFrbSzG)
	if qqw1upCsKM(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᷙ") in mHY2EseIvtnoF6Ax0KWdQVrLP and len(ka7jz96YCdTBnQOLVPuJG3285MHf)>TiZsAOU7nptlPhEqbXfxr:
		Q1siCkTZyw.menuItemsLIST[:] = []
		XAozRfZ68H9x2OsiP3LmIaql1(SIkwCEdJHTD9v1(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷚ"),gDETKVh8mZe09Nd(u"࡛࠭ࠨᷛ")+VXWOCAE6ns3paJ8DLG479NQfMu+group+B8alA5nvIhTxQ+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩᷜ"),group,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠵࠻࠻ệ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iQfp2eKkgHt3IREYvF0Mw1q8sru9+hPFcB6Uxmabj59Iq(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᷝ"))
		XAozRfZ68H9x2OsiP3LmIaql1(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡩࡳࡱࡪࡥࡳࠩᷞ"),TzIj50KpohEOHx6CbZWqB(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩᷟ"),group,GVurlv8HeoXEzPRiQB7Ty(u"࠶࠼࠵Ỉ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iQfp2eKkgHt3IREYvF0Mw1q8sru9+sH6BOz5wKRFcEg(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷠ"))
		XAozRfZ68H9x2OsiP3LmIaql1(jwzOabysh0Z(u"ࠬࡲࡩ࡯࡭ࠪᷡ"),VXWOCAE6ns3paJ8DLG479NQfMu+SIkwCEdJHTD9v1(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᷢ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"࠿࠹࠺࠻ỉ"))
		ka7jz96YCdTBnQOLVPuJG3285MHf = Q1siCkTZyw.menuItemsLIST+VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(ka7jz96YCdTBnQOLVPuJG3285MHf,TiZsAOU7nptlPhEqbXfxr)
	Q1siCkTZyw.menuItemsLIST[:] = ka7jz96YCdTBnQOLVPuJG3285MHf
	Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def z3zcYGSh5WjO2yRiBne(mHY2EseIvtnoF6Ax0KWdQVrLP):
	XAozRfZ68H9x2OsiP3LmIaql1(YQNd4wejLSAVJ6T(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᷣ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫᷤ"),sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠱࠷࠳Ị"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩᷥ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡰ࡮ࡴ࡫ࠨᷦ"),VXWOCAE6ns3paJ8DLG479NQfMu+fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᷧ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"࠺࠻࠼࠽ị"))
	Cn7rMEPzUvJOL4jge = Q1siCkTZyw.menuItemsLIST[:]
	Q1siCkTZyw.menuItemsLIST[:] = []
	import ueZX4hr0sn
	ueZX4hr0sn.N9pi3VIH5uR(TzIj50KpohEOHx6CbZWqB(u"ࠬ࠶ࠧᷨ"),lvzrYTpcBaK)
	ueZX4hr0sn.N9pi3VIH5uR(Js61GTdX5wzMurUqi7Z(u"࠭࠱ࠨᷩ"),lvzrYTpcBaK)
	ueZX4hr0sn.N9pi3VIH5uR(gDETKVh8mZe09Nd(u"ࠧ࠳ࠩᷪ"),lvzrYTpcBaK)
	if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪᷫ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		Q1siCkTZyw.menuItemsLIST[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
		if len(Q1siCkTZyw.menuItemsLIST)>TiZsAOU7nptlPhEqbXfxr: Q1siCkTZyw.menuItemsLIST[:] = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(Q1siCkTZyw.menuItemsLIST,TiZsAOU7nptlPhEqbXfxr)
	Q1siCkTZyw.menuItemsLIST[:] = Cn7rMEPzUvJOL4jge+Q1siCkTZyw.menuItemsLIST
	return
def ccZ9Ndx4vesaBAj76XlItz0ufDkb(mHY2EseIvtnoF6Ax0KWdQVrLP):
	mHY2EseIvtnoF6Ax0KWdQVrLP = mHY2EseIvtnoF6Ax0KWdQVrLP.replace(GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷬ"),sCHVtMAvqirbQ4BUK3cgWo).replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᷭ"),sCHVtMAvqirbQ4BUK3cgWo)
	headers = { TzIj50KpohEOHx6CbZWqB(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᷮ") : sCHVtMAvqirbQ4BUK3cgWo }
	url = aYH620Dh48GEsTFfOBSQ7r(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫᷯ")
	data = {EJgYdjbIiWe1apkQlZcR42(u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨᷰ"):bGzRdmOErkIylxALniq6(u"ࠧ࠶࠲ࠪᷱ")}
	data = JePn6VTBrLMDmsCzX(data)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(xCE0toTumIHWiLyMfF,SIkwCEdJHTD9v1(u"ࠨࡉࡈࡘࠬᷲ"),url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕࡢࡊࡗࡕࡍࡠ࡙ࡒࡖࡉ࡙࠭࠲ࡵࡷࠫᷳ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᷴ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
	items = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ᷵"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	XXUwKBC6J9yderR,VulPb29ctzvqohkagji7CDUHW5Zyx = list(zip(*items))
	yl2OQgNIzMv08iU = []
	oPrWxK0E1gvhS74 = [AAh0X3OCacr4HpifRGLZKT,TzIj50KpohEOHx6CbZWqB(u"ࠬࠨࠧ᷶"),fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡠࠨ᷷"),hPFcB6Uxmabj59Iq(u"᷸ࠧ࠭ࠩ"),IOHSz7YPF9WusGgUt1Dq(u"ࠨ࠰᷹ࠪ"),EJgYdjbIiWe1apkQlZcR42(u"ࠩ࠽᷺ࠫ"),SE97R3Dpj6dPLweVKU(u"ࠪ࠿ࠬ᷻"),BWfpRku7SsM6cbE0eG(u"ࠦࠬࠨ᷼"),sH6BOz5wKRFcEg(u"ࠬ࠳᷽ࠧ")]
	CxmzLgfeOZ = VulPb29ctzvqohkagji7CDUHW5Zyx+XXUwKBC6J9yderR
	for hNbcGFOVvzmJ7DrYjWMnC0 in CxmzLgfeOZ:
		if hNbcGFOVvzmJ7DrYjWMnC0 in VulPb29ctzvqohkagji7CDUHW5Zyx: Y7LHSCIv8VnJRDPiou31zWf = rgpY5VUqKbeFOCD9Nki2SmGvxEja
		if hNbcGFOVvzmJ7DrYjWMnC0 in XXUwKBC6J9yderR: Y7LHSCIv8VnJRDPiou31zWf = kK7gj9HE462hADJbvr
		bqyZfOwBDGNp6IghEVCYvcJ47 = [XMIo9vWSBymeLJnK6YsU in hNbcGFOVvzmJ7DrYjWMnC0 for XMIo9vWSBymeLJnK6YsU in oPrWxK0E1gvhS74]
		if any(bqyZfOwBDGNp6IghEVCYvcJ47):
			nTxciHKjwprDmO = bqyZfOwBDGNp6IghEVCYvcJ47.index(ndkUxG9LtewJ)
			g9gS8eXhEmkI6 = oPrWxK0E1gvhS74[nTxciHKjwprDmO]
			ufnPGc2oe9ZhM = sCHVtMAvqirbQ4BUK3cgWo
			if hNbcGFOVvzmJ7DrYjWMnC0.count(g9gS8eXhEmkI6)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: LF2whrsjuTpoABm6g8n,co9XIP3VMkgLp0Jjhf6w,ufnPGc2oe9ZhM = hNbcGFOVvzmJ7DrYjWMnC0.split(g9gS8eXhEmkI6,rgpY5VUqKbeFOCD9Nki2SmGvxEja)
			else: LF2whrsjuTpoABm6g8n,co9XIP3VMkgLp0Jjhf6w = hNbcGFOVvzmJ7DrYjWMnC0.split(g9gS8eXhEmkI6,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			if len(LF2whrsjuTpoABm6g8n)>Y7LHSCIv8VnJRDPiou31zWf: yl2OQgNIzMv08iU.append(LF2whrsjuTpoABm6g8n.lower())
			if len(co9XIP3VMkgLp0Jjhf6w)>Y7LHSCIv8VnJRDPiou31zWf: yl2OQgNIzMv08iU.append(co9XIP3VMkgLp0Jjhf6w.lower())
			if len(ufnPGc2oe9ZhM)>Y7LHSCIv8VnJRDPiou31zWf: yl2OQgNIzMv08iU.append(ufnPGc2oe9ZhM.lower())
		elif len(hNbcGFOVvzmJ7DrYjWMnC0)>Y7LHSCIv8VnJRDPiou31zWf: yl2OQgNIzMv08iU.append(hNbcGFOVvzmJ7DrYjWMnC0.lower())
	for XMIo9vWSBymeLJnK6YsU in range(aYH620Dh48GEsTFfOBSQ7r(u"࠻Ọ")): VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.shuffle(yl2OQgNIzMv08iU)
	if TzIj50KpohEOHx6CbZWqB(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ᷾") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		RxYVLUfieMDFH1 = imU5I1ewc4dEHvkQ8
	elif qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡠࡋࡓࡘ࡛ࡥ᷿ࠧ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		RxYVLUfieMDFH1 = [sH6BOz5wKRFcEg(u"ࠨࡋࡓࡘ࡛࠭Ḁ")]
		import ebtl4A2fjS
		if not ebtl4A2fjS.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
	elif gDETKVh8mZe09Nd(u"ࠩࡢࡑ࠸࡛࡟ࠨḁ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		RxYVLUfieMDFH1 = [IOHSz7YPF9WusGgUt1Dq(u"ࠪࡑ࠸࡛ࠧḂ")]
		import Sce6q5zwUj
		if not Sce6q5zwUj.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
	count,ZImfeoPXv27H = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
	XAozRfZ68H9x2OsiP3LmIaql1(BWfpRku7SsM6cbE0eG(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḃ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡡࠠࠡ࡟ࠣ࠾ฬ๊ศฮอࠣ฽๋࠭Ḅ"),sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"࠴࠺࠹ọ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḅ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
	XAozRfZ68H9x2OsiP3LmIaql1(jwzOabysh0Z(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḆ"),hPFcB6Uxmabj59Iq(u"ࠨว฼หิฯࠠศๆหัะࠦวๅ฻ื์ฬฬ๊ࠨḇ"),sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"࠵࠻࠺Ỏ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧḈ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
	XAozRfZ68H9x2OsiP3LmIaql1(RDwahqjPfbdyEiTtnLQu(u"ࠪࡰ࡮ࡴ࡫ࠨḉ"),VXWOCAE6ns3paJ8DLG479NQfMu+Js61GTdX5wzMurUqi7Z(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩḊ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠾࠿࠹࠺ỏ"))
	avQ7DwoGOtKXUmb9Jxf6 = Q1siCkTZyw.menuItemsLIST[:]
	Q1siCkTZyw.menuItemsLIST[:] = []
	R5Bv1bsG9kEPwQI = []
	for hNbcGFOVvzmJ7DrYjWMnC0 in yl2OQgNIzMv08iU:
		co9XIP3VMkgLp0Jjhf6w = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡡࠠ࡝࠮࡟࠿ࡡࡀ࡜࠮࡞࠮ࡠࡂࡢࠢ࡝ࠩ࡟࡟ࡡࡣ࡜ࠩ࡞ࠬࡠࢀࡢࡽ࡝ࠣ࡟ࡄࠬḋ")+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࠣࠨḌ")+IO7k2hZXSz(u"ࠧ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫḍ"),hNbcGFOVvzmJ7DrYjWMnC0,fNntYJW45mEFSdRX8g.DOTALL)
		if co9XIP3VMkgLp0Jjhf6w: hNbcGFOVvzmJ7DrYjWMnC0 = hNbcGFOVvzmJ7DrYjWMnC0.split(co9XIP3VMkgLp0Jjhf6w[BewrUo9ANCa17G43Sn0LH5xh],zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		TADQpqhaRgcUHIr2jXLPVZS = hNbcGFOVvzmJ7DrYjWMnC0.replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ๓ࠪḎ"),sCHVtMAvqirbQ4BUK3cgWo).replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ๑ࠫḏ"),sCHVtMAvqirbQ4BUK3cgWo).replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ๏ࠬḐ"),sCHVtMAvqirbQ4BUK3cgWo).replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ๔࠭ḑ"),sCHVtMAvqirbQ4BUK3cgWo).replace(BWfpRku7SsM6cbE0eG(u"ࠬ๒ࠧḒ"),sCHVtMAvqirbQ4BUK3cgWo)
		TADQpqhaRgcUHIr2jXLPVZS = TADQpqhaRgcUHIr2jXLPVZS.replace(SIkwCEdJHTD9v1(u"࠭๐ࠨḓ"),sCHVtMAvqirbQ4BUK3cgWo).replace(qqw1upCsKM(u"ࠧ๎ࠩḔ"),sCHVtMAvqirbQ4BUK3cgWo).replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ๔ࠪḕ"),sCHVtMAvqirbQ4BUK3cgWo).replace(qeG16a4pbSHziNVQ2uFXrs(u"ࠩฏࠫḖ"),sCHVtMAvqirbQ4BUK3cgWo).replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠪไࠬḗ"),sCHVtMAvqirbQ4BUK3cgWo)
		if TADQpqhaRgcUHIr2jXLPVZS: R5Bv1bsG9kEPwQI.append(TADQpqhaRgcUHIr2jXLPVZS)
	K9wcUMsgZFDC6Q2iXYuE = []
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(BewrUo9ANCa17G43Sn0LH5xh,Js61GTdX5wzMurUqi7Z(u"࠸࠰Ố")):
		search = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(R5Bv1bsG9kEPwQI,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		if search in K9wcUMsgZFDC6Q2iXYuE: continue
		K9wcUMsgZFDC6Q2iXYuE.append(search)
		oT2iHwjfBx0FPX5ZCph9aWs38 = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(RxYVLUfieMDFH1,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+bGzRdmOErkIylxALniq6(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧḘ")+str(oT2iHwjfBx0FPX5ZCph9aWs38)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨḙ")+search)
		lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
		bHSQRo5vFEuWUw1978CLY(search+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫḚ"))
		if len(Q1siCkTZyw.menuItemsLIST)>BewrUo9ANCa17G43Sn0LH5xh: break
	search = search.replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡠࡏࡒࡈࡤ࠭ḛ"),sCHVtMAvqirbQ4BUK3cgWo)
	avQ7DwoGOtKXUmb9Jxf6[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = IOHSz7YPF9WusGgUt1Dq(u"ࠨ࡝ࠪḜ")+VXWOCAE6ns3paJ8DLG479NQfMu+search+B8alA5nvIhTxQ+qeG16a4pbSHziNVQ2uFXrs(u"ࠩࠣ࠾อำหࠡ฻้ࡡࠬḝ")
	Q1siCkTZyw.menuItemsLIST[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
	if len(Q1siCkTZyw.menuItemsLIST)>TiZsAOU7nptlPhEqbXfxr: Q1siCkTZyw.menuItemsLIST[:] = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(Q1siCkTZyw.menuItemsLIST,TiZsAOU7nptlPhEqbXfxr)
	Q1siCkTZyw.menuItemsLIST[:] = avQ7DwoGOtKXUmb9Jxf6+Q1siCkTZyw.menuItemsLIST
	return
def ALsVGTMZE1fv0QgRaqKSndpChtIJ(IckaHSybt1NpeZqVoUP5M7RgY,mHY2EseIvtnoF6Ax0KWdQVrLP):
	IckaHSybt1NpeZqVoUP5M7RgY = IckaHSybt1NpeZqVoUP5M7RgY.replace(EJgYdjbIiWe1apkQlZcR42(u"ࠪࡣࡒࡕࡄࡠࠩḞ"),sCHVtMAvqirbQ4BUK3cgWo)
	mHY2EseIvtnoF6Ax0KWdQVrLP = mHY2EseIvtnoF6Ax0KWdQVrLP.replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ḟ"),sCHVtMAvqirbQ4BUK3cgWo).replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḠ"),sCHVtMAvqirbQ4BUK3cgWo)
	FFYK70nUmu(lvzrYTpcBaK)
	if not G7ZIPF3Qw2u6C10WkoXRTK8tlvm: return
	if qeG16a4pbSHziNVQ2uFXrs(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨḡ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		XAozRfZ68H9x2OsiP3LmIaql1(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḢ"),SIkwCEdJHTD9v1(u"ࠨ࡝ࠪḣ")+VXWOCAE6ns3paJ8DLG479NQfMu+IckaHSybt1NpeZqVoUP5M7RgY+B8alA5nvIhTxQ+aYH620Dh48GEsTFfOBSQ7r(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫḤ"),IckaHSybt1NpeZqVoUP5M7RgY,oVwa0kcqxj1e7mLplAfZdGT(u"࠱࠷࠸ố"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḥ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
		XAozRfZ68H9x2OsiP3LmIaql1(fvYGxnZNUiyP4HJkMIoS25(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḦ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫḧ"),IckaHSybt1NpeZqVoUP5M7RgY,qeG16a4pbSHziNVQ2uFXrs(u"࠲࠸࠹Ồ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḨ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
		XAozRfZ68H9x2OsiP3LmIaql1(TzIj50KpohEOHx6CbZWqB(u"ࠧ࡭࡫ࡱ࡯ࠬḩ"),VXWOCAE6ns3paJ8DLG479NQfMu+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ḫ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"࠻࠼࠽࠾ồ"))
	for website in sorted(list(G7ZIPF3Qw2u6C10WkoXRTK8tlvm[IckaHSybt1NpeZqVoUP5M7RgY].keys())):
		type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = G7ZIPF3Qw2u6C10WkoXRTK8tlvm[IckaHSybt1NpeZqVoUP5M7RgY][website]
		if EJgYdjbIiWe1apkQlZcR42(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫḫ") in mHY2EseIvtnoF6Ax0KWdQVrLP or len(G7ZIPF3Qw2u6C10WkoXRTK8tlvm[IckaHSybt1NpeZqVoUP5M7RgY])==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			Wwod49PBvQO(type,sCHVtMAvqirbQ4BUK3cgWo,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)
			Q1siCkTZyw.menuItemsLIST[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
			Z6bx30Qg8jkIlrqhXvTsRGAV,iIdvU69jyWzCs = Q1siCkTZyw.menuItemsLIST[:vUnJhT2NO8yirHcAmg],Q1siCkTZyw.menuItemsLIST[vUnJhT2NO8yirHcAmg:]
			if YQNd4wejLSAVJ6T(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬḬ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
				for XMIo9vWSBymeLJnK6YsU in range(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠼Ổ")): VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.shuffle(iIdvU69jyWzCs)
				Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs[:TiZsAOU7nptlPhEqbXfxr]
			else: Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs
		elif qqw1upCsKM(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬḭ") in mHY2EseIvtnoF6Ax0KWdQVrLP: XAozRfZ68H9x2OsiP3LmIaql1(qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḮ"),website,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
	return
def rrOFuQcHqGEv1ywIRk6At(mHY2EseIvtnoF6Ax0KWdQVrLP,QQ8kHjYnKEDU3sxft9S5iRoB):
	mHY2EseIvtnoF6Ax0KWdQVrLP = mHY2EseIvtnoF6Ax0KWdQVrLP.replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḯ"),sCHVtMAvqirbQ4BUK3cgWo).replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḰ"),sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq,iIdvU69jyWzCs = sCHVtMAvqirbQ4BUK3cgWo,[]
	XAozRfZ68H9x2OsiP3LmIaql1(jwzOabysh0Z(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨḱ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࡞ࠫḲ")+VXWOCAE6ns3paJ8DLG479NQfMu+hoVitY5TylJ7GBEIZNOQg8pukq+B8alA5nvIhTxQ+Js61GTdX5wzMurUqi7Z(u"ࠪࠤ࠿อไใี่ࡡࠬḳ"),sCHVtMAvqirbQ4BUK3cgWo,QQ8kHjYnKEDU3sxft9S5iRoB,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḴ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
	XAozRfZ68H9x2OsiP3LmIaql1(Js61GTdX5wzMurUqi7Z(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḵ"),bGzRdmOErkIylxALniq6(u"࠭ลฺษาอࠥ฽ไษࠢๅืู๊ࠦี๊สส๏࠭Ḷ"),sCHVtMAvqirbQ4BUK3cgWo,QQ8kHjYnKEDU3sxft9S5iRoB,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḷ")+mHY2EseIvtnoF6Ax0KWdQVrLP)
	XAozRfZ68H9x2OsiP3LmIaql1(SIkwCEdJHTD9v1(u"ࠨ࡮࡬ࡲࡰ࠭Ḹ"),VXWOCAE6ns3paJ8DLG479NQfMu+RDwahqjPfbdyEiTtnLQu(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧḹ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠽࠾࠿࠹ổ"))
	Z6bx30Qg8jkIlrqhXvTsRGAV = Q1siCkTZyw.menuItemsLIST[:]
	Q1siCkTZyw.menuItemsLIST[:] = []
	ka7jz96YCdTBnQOLVPuJG3285MHf = []
	if GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫḺ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		FFYK70nUmu(lvzrYTpcBaK)
		if not G7ZIPF3Qw2u6C10WkoXRTK8tlvm: return
		KK0RLAUGNi2gf = list(G7ZIPF3Qw2u6C10WkoXRTK8tlvm.keys())
		IckaHSybt1NpeZqVoUP5M7RgY = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(KK0RLAUGNi2gf,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		yl2OQgNIzMv08iU = list(G7ZIPF3Qw2u6C10WkoXRTK8tlvm[IckaHSybt1NpeZqVoUP5M7RgY].keys())
		website = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(yl2OQgNIzMv08iU,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = G7ZIPF3Qw2u6C10WkoXRTK8tlvm[IckaHSybt1NpeZqVoUP5M7RgY][website]
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧḻ")+website+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨḼ")+hoVitY5TylJ7GBEIZNOQg8pukq+aYH620Dh48GEsTFfOBSQ7r(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨḽ")+url+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪḾ")+str(Wi8Izh1wT0aoryCMVDY2splStF9uc3))
	elif oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨḿ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		import ebtl4A2fjS
		if not ebtl4A2fjS.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
		for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			ka7jz96YCdTBnQOLVPuJG3285MHf += WhC0jgVlb8(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),mHY2EseIvtnoF6Ax0KWdQVrLP)
		if not ka7jz96YCdTBnQOLVPuJG3285MHf: return
		type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(ka7jz96YCdTBnQOLVPuJG3285MHf,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+IOHSz7YPF9WusGgUt1Dq(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩṀ")+hoVitY5TylJ7GBEIZNOQg8pukq+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬṁ")+url+bGzRdmOErkIylxALniq6(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧṂ")+str(Wi8Izh1wT0aoryCMVDY2splStF9uc3))
	elif oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡥࡍ࠴ࡗࡢࠫṃ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		import Sce6q5zwUj
		if not Sce6q5zwUj.l1au36XEkVRnFrs(sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ): return
		for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			ka7jz96YCdTBnQOLVPuJG3285MHf += auWNV5nl9qOMhbGdZrf7j(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),mHY2EseIvtnoF6Ax0KWdQVrLP)
		if not ka7jz96YCdTBnQOLVPuJG3285MHf: return
		type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(ka7jz96YCdTBnQOLVPuJG3285MHf,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+EJgYdjbIiWe1apkQlZcR42(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ṅ")+hoVitY5TylJ7GBEIZNOQg8pukq+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩṅ")+url+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫṆ")+str(Wi8Izh1wT0aoryCMVDY2splStF9uc3))
	FlTDMd2Kg4rkhNtR = hoVitY5TylJ7GBEIZNOQg8pukq
	kRol93eOaZMILCFWKj5Hgunb2 = []
	for XMIo9vWSBymeLJnK6YsU in range(BewrUo9ANCa17G43Sn0LH5xh,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠶࠶Ỗ")):
		if XMIo9vWSBymeLJnK6YsU>BewrUo9ANCa17G43Sn0LH5xh: SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩṇ")+hoVitY5TylJ7GBEIZNOQg8pukq+aYH620Dh48GEsTFfOBSQ7r(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬṈ")+url+zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧṉ")+str(Wi8Izh1wT0aoryCMVDY2splStF9uc3))
		Q1siCkTZyw.menuItemsLIST[:] = []
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==aYH620Dh48GEsTFfOBSQ7r(u"࠸࠳࠵ỗ") and zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ṋ") in T67f3LG49xpP8zcN: Wi8Izh1wT0aoryCMVDY2splStF9uc3 = BWfpRku7SsM6cbE0eG(u"࠲࠴࠵Ộ")
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==IOHSz7YPF9WusGgUt1Dq(u"࠸࠳࠷ộ") and qeG16a4pbSHziNVQ2uFXrs(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ṋ") in T67f3LG49xpP8zcN: Wi8Izh1wT0aoryCMVDY2splStF9uc3 = t19ZOVHA4CpwFKaeiubcMGvz(u"࠹࠴࠷Ớ")
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠴࠸࠹ớ"): Wi8Izh1wT0aoryCMVDY2splStF9uc3 = SE97R3Dpj6dPLweVKU(u"࠶࠾࠷Ờ")
		qLbRrEtgenpSi = Wwod49PBvQO(type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
		if fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧṌ") in mHY2EseIvtnoF6Ax0KWdQVrLP and Wi8Izh1wT0aoryCMVDY2splStF9uc3==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠶࠼࠷ờ"): del Q1siCkTZyw.menuItemsLIST[:vUnJhT2NO8yirHcAmg]
		if hPFcB6Uxmabj59Iq(u"ࠨࡡࡐ࠷࡚ࡥࠧṍ") in mHY2EseIvtnoF6Ax0KWdQVrLP and Wi8Izh1wT0aoryCMVDY2splStF9uc3==gDETKVh8mZe09Nd(u"࠷࠶࠹Ở"): del Q1siCkTZyw.menuItemsLIST[:vUnJhT2NO8yirHcAmg]
		iIdvU69jyWzCs[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
		if kRol93eOaZMILCFWKj5Hgunb2 and ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࡷࠪั้่ษࠨṎ")) in str(iIdvU69jyWzCs) or ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(aenpKvQCGVzhLXEdWiDIZ(u"ࡸࠫา๊โ่ࠩṏ")) in str(iIdvU69jyWzCs):
			hoVitY5TylJ7GBEIZNOQg8pukq = FlTDMd2Kg4rkhNtR
			iIdvU69jyWzCs[:] = kRol93eOaZMILCFWKj5Hgunb2
			break
		FlTDMd2Kg4rkhNtR = hoVitY5TylJ7GBEIZNOQg8pukq
		kRol93eOaZMILCFWKj5Hgunb2 = iIdvU69jyWzCs
		if str(iIdvU69jyWzCs).count(qqw1upCsKM(u"ࠫࡻ࡯ࡤࡦࡱࠪṐ"))>BewrUo9ANCa17G43Sn0LH5xh: break
		if str(iIdvU69jyWzCs).count(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡲࡩࡷࡧࠪṑ"))>BewrUo9ANCa17G43Sn0LH5xh: break
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==IO7k2hZXSz(u"࠲࠴࠵ở"): break
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠸࠳࠶Ỡ"): break
		if Wi8Izh1wT0aoryCMVDY2splStF9uc3==TzIj50KpohEOHx6CbZWqB(u"࠴࠼࠵ỡ"): break
		if gDETKVh8mZe09Nd(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨṒ") in mHY2EseIvtnoF6Ax0KWdQVrLP and iIdvU69jyWzCs: type,hoVitY5TylJ7GBEIZNOQg8pukq,url,Wi8Izh1wT0aoryCMVDY2splStF9uc3,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(iIdvU69jyWzCs,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
	if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࠯࠰࠱࠲ࠬṓ")
	elif hoVitY5TylJ7GBEIZNOQg8pukq.count(BWfpRku7SsM6cbE0eG(u"ࠨࡡࠪṔ"))>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡢࠫṕ"),rgpY5VUqKbeFOCD9Nki2SmGvxEja)[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(IOHSz7YPF9WusGgUt1Dq(u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭Ṗ"),sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡤࡓࡏࡅࡡࠪṗ"),sCHVtMAvqirbQ4BUK3cgWo)
	Z6bx30Qg8jkIlrqhXvTsRGAV[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = sH6BOz5wKRFcEg(u"ࠬࡡࠧṘ")+VXWOCAE6ns3paJ8DLG479NQfMu+hoVitY5TylJ7GBEIZNOQg8pukq+B8alA5nvIhTxQ+oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨṙ")
	if t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩṚ") in mHY2EseIvtnoF6Ax0KWdQVrLP:
		for XMIo9vWSBymeLJnK6YsU in range(aenpKvQCGVzhLXEdWiDIZ(u"࠼Ợ")): VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.shuffle(iIdvU69jyWzCs)
		Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs[:TiZsAOU7nptlPhEqbXfxr]
	else: Q1siCkTZyw.menuItemsLIST[:] = Z6bx30Qg8jkIlrqhXvTsRGAV+iIdvU69jyWzCs
	return
def vq9kLfGj0x2sVcml8yTiY(ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg):
	YLGARKjz7kuNZ5Tg = YLGARKjz7kuNZ5Tg.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṛ"),sCHVtMAvqirbQ4BUK3cgWo).replace(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ṝ"),sCHVtMAvqirbQ4BUK3cgWo)
	DRdMOy0EPtsVGJ = YLGARKjz7kuNZ5Tg
	if hPFcB6Uxmabj59Iq(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫṝ") in YLGARKjz7kuNZ5Tg:
		DRdMOy0EPtsVGJ = YLGARKjz7kuNZ5Tg.split(SIkwCEdJHTD9v1(u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬṞ"))[BewrUo9ANCa17G43Sn0LH5xh]
		type = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨṟ")
	elif bGzRdmOErkIylxALniq6(u"࠭ࡖࡐࡆࠪṠ") in ppSoqn4Dh1vAVgdTEsukr: type = GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪṡ")
	elif TzIj50KpohEOHx6CbZWqB(u"ࠨࡎࡌ࡚ࡊ࠭Ṣ") in ppSoqn4Dh1vAVgdTEsukr: type = IOHSz7YPF9WusGgUt1Dq(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪṣ")
	XAozRfZ68H9x2OsiP3LmIaql1(qqw1upCsKM(u"ࠪࡪࡴࡲࡤࡦࡴࠪṤ"),sH6BOz5wKRFcEg(u"ࠫࡠ࠭ṥ")+VXWOCAE6ns3paJ8DLG479NQfMu+type+DRdMOy0EPtsVGJ+B8alA5nvIhTxQ+sH6BOz5wKRFcEg(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧṦ"),ppSoqn4Dh1vAVgdTEsukr,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠵࠻࠽ợ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṧ")+YLGARKjz7kuNZ5Tg)
	XAozRfZ68H9x2OsiP3LmIaql1(Js61GTdX5wzMurUqi7Z(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṨ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧṩ"),ppSoqn4Dh1vAVgdTEsukr,qqw1upCsKM(u"࠶࠼࠷Ụ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṪ")+YLGARKjz7kuNZ5Tg)
	XAozRfZ68H9x2OsiP3LmIaql1(SIkwCEdJHTD9v1(u"ࠪࡰ࡮ࡴ࡫ࠨṫ"),VXWOCAE6ns3paJ8DLG479NQfMu+aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩṬ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠿࠹࠺࠻ụ"))
	import ebtl4A2fjS
	for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
		if Js61GTdX5wzMurUqi7Z(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ṭ") in YLGARKjz7kuNZ5Tg: ebtl4A2fjS.eyAvQG2hJUaLD9EVzC7t(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK)
		else: ebtl4A2fjS.N9pi3VIH5uR(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK)
	Q1siCkTZyw.menuItemsLIST[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
	if len(Q1siCkTZyw.menuItemsLIST)>(TiZsAOU7nptlPhEqbXfxr+vUnJhT2NO8yirHcAmg): Q1siCkTZyw.menuItemsLIST[:] = Q1siCkTZyw.menuItemsLIST[:vUnJhT2NO8yirHcAmg]+VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(Q1siCkTZyw.menuItemsLIST[vUnJhT2NO8yirHcAmg:],TiZsAOU7nptlPhEqbXfxr)
	return
def U0hN78tHfFG6M3beAXqdg5V9ra(ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg):
	YLGARKjz7kuNZ5Tg = YLGARKjz7kuNZ5Tg.replace(gDETKVh8mZe09Nd(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṮ"),sCHVtMAvqirbQ4BUK3cgWo).replace(jwzOabysh0Z(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṯ"),sCHVtMAvqirbQ4BUK3cgWo)
	DRdMOy0EPtsVGJ = YLGARKjz7kuNZ5Tg
	if jwzOabysh0Z(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨṰ") in YLGARKjz7kuNZ5Tg:
		DRdMOy0EPtsVGJ = YLGARKjz7kuNZ5Tg.split(GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩṱ"))[BewrUo9ANCa17G43Sn0LH5xh]
		type = oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭Ṳ")
	elif qeG16a4pbSHziNVQ2uFXrs(u"࡛ࠫࡕࡄࠨṳ") in ppSoqn4Dh1vAVgdTEsukr: type = EJgYdjbIiWe1apkQlZcR42(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨṴ")
	elif RDwahqjPfbdyEiTtnLQu(u"࠭ࡌࡊࡘࡈࠫṵ") in ppSoqn4Dh1vAVgdTEsukr: type = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨṶ")
	XAozRfZ68H9x2OsiP3LmIaql1(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṷ"),qqw1upCsKM(u"ࠩ࡞ࠫṸ")+VXWOCAE6ns3paJ8DLG479NQfMu+type+DRdMOy0EPtsVGJ+B8alA5nvIhTxQ+bGzRdmOErkIylxALniq6(u"ࠪࠤ࠿อไใี่ࡡࠬṹ"),ppSoqn4Dh1vAVgdTEsukr,aYH620Dh48GEsTFfOBSQ7r(u"࠱࠷࠺Ủ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṺ")+YLGARKjz7kuNZ5Tg)
	XAozRfZ68H9x2OsiP3LmIaql1(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṻ"),jwzOabysh0Z(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬṼ"),ppSoqn4Dh1vAVgdTEsukr,BWfpRku7SsM6cbE0eG(u"࠲࠸࠻ủ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṽ")+YLGARKjz7kuNZ5Tg)
	XAozRfZ68H9x2OsiP3LmIaql1(EJgYdjbIiWe1apkQlZcR42(u"ࠨ࡮࡬ࡲࡰ࠭Ṿ"),VXWOCAE6ns3paJ8DLG479NQfMu+aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧṿ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"࠻࠼࠽࠾Ứ"))
	import Sce6q5zwUj
	for J26JEXNRtmOrlj8qhesLYI0dKpQ in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,cjJXgt71A5+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
		if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪẀ") in YLGARKjz7kuNZ5Tg: Sce6q5zwUj.eyAvQG2hJUaLD9EVzC7t(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK)
		else: Sce6q5zwUj.N9pi3VIH5uR(str(J26JEXNRtmOrlj8qhesLYI0dKpQ),ppSoqn4Dh1vAVgdTEsukr,YLGARKjz7kuNZ5Tg,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK)
	Q1siCkTZyw.menuItemsLIST[:] = XtaCi471OjhHJIyBncvZq3f09(Q1siCkTZyw.menuItemsLIST)
	if len(Q1siCkTZyw.menuItemsLIST)>(TiZsAOU7nptlPhEqbXfxr+vUnJhT2NO8yirHcAmg): Q1siCkTZyw.menuItemsLIST[:] = Q1siCkTZyw.menuItemsLIST[:vUnJhT2NO8yirHcAmg]+VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(Q1siCkTZyw.menuItemsLIST[vUnJhT2NO8yirHcAmg:],TiZsAOU7nptlPhEqbXfxr)
	return
def XtaCi471OjhHJIyBncvZq3f09(PtvZEwWnoLJSk8y3iz0Op6IV):
	J02G8lWjuTDvYg1xwUnZ = []
	for type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in PtvZEwWnoLJSk8y3iz0Op6IV:
		if aYH620Dh48GEsTFfOBSQ7r(u"ฺࠫ็อสࠩẁ") in hoVitY5TylJ7GBEIZNOQg8pukq or Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ฻แฮ้ࠪẂ") in hoVitY5TylJ7GBEIZNOQg8pukq or Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡰࡢࡩࡨࠫẃ") in hoVitY5TylJ7GBEIZNOQg8pukq.lower(): continue
		J02G8lWjuTDvYg1xwUnZ.append([type,hoVitY5TylJ7GBEIZNOQg8pukq,url,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q])
	return J02G8lWjuTDvYg1xwUnZ
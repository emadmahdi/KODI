# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ALARAB'
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
Z0BYJQghVL1v87CAem = '_KLA_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==10: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==11: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==12: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==13: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==14: ka7jz96YCdTBnQOLVPuJG3285MHf = dh1kDr9texw6szfNu()
	elif mode==15: ka7jz96YCdTBnQOLVPuJG3285MHf = jnlW360bDN()
	elif mode==16: ka7jz96YCdTBnQOLVPuJG3285MHf = Oi36L4kAcCK2()
	elif mode==19: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,19,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'آخر الإضافات',sCHVtMAvqirbQ4BUK3cgWo,14)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مسلسلات رمضان',sCHVtMAvqirbQ4BUK3cgWo,15)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'ALARAB-MENU-1st')
	oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('id="nav-slider"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vziK8BQWlad39rjA = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',vziK8BQWlad39rjA,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,11)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="navbar"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	MtCcgLOoBTGp4nqzVhYJliX8Zva6s = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',MtCcgLOoBTGp4nqzVhYJliX8Zva6s,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,11)
	return Sw0pOFoVhPeIxbl
def jnlW360bDN():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'جميع المسلسلات العربية',gAVl1vUmus8+'/view-8/مسلسلات-عربية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات السنة الأخيرة',sCHVtMAvqirbQ4BUK3cgWo,16)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان الأخيرة 1',gAVl1vUmus8+'/view-8/مسلسلات-رمضان-2022',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان الأخيرة 2',gAVl1vUmus8+'/view-8/مسلسلات-رمضان-2023',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2023',gAVl1vUmus8+'/ramadan2023/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2022',gAVl1vUmus8+'/ramadan2022/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2021',gAVl1vUmus8+'/ramadan2021/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2020',gAVl1vUmus8+'/ramadan2020/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2019',gAVl1vUmus8+'/ramadan2019/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2018',gAVl1vUmus8+'/ramadan2018/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2017',gAVl1vUmus8+'/ramadan2017/مصرية',11)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات رمضان 2016',gAVl1vUmus8+'/ramadan2016/مصرية',11)
	return
def dh1kDr9texw6szfNu():
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'ALARAB-LATEST-1st')
	oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('heading-top(.*?)div class=',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]+oPnz7Zt4xLHTwR[1]
	items=fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		url = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
		if 'series' in url: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,11,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,12,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def fs7D0d3QyAT(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,True,'ALARAB-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('video-category(.*?)right_content',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	vVU3etr1sKREmPkX9z26D0qoJ = False
	items = fNntYJW45mEFSdRX8g.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ,EFTdOhkS9b = [],[]
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		if title==sCHVtMAvqirbQ4BUK3cgWo: title = B17r2fdFy9ns8tiOMLu.split('/')[-1].replace('-',AAh0X3OCacr4HpifRGLZKT)
		zPm7HsNhv8Gt5jpi2YUZlnOeDT = fNntYJW45mEFSdRX8g.findall('(\d+)',title,fNntYJW45mEFSdRX8g.DOTALL)
		if zPm7HsNhv8Gt5jpi2YUZlnOeDT: zPm7HsNhv8Gt5jpi2YUZlnOeDT = int(zPm7HsNhv8Gt5jpi2YUZlnOeDT[0])
		else: zPm7HsNhv8Gt5jpi2YUZlnOeDT = 0
		EFTdOhkS9b.append([Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT])
	EFTdOhkS9b = sorted(EFTdOhkS9b, reverse=True, key=lambda key: key[3])
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT in EFTdOhkS9b:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('عالية على العرب',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('مشاهدة مباشرة',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('اون لاين',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('اونلاين',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('بجودة عالية',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('جودة عالية',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('بدون تحميل',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('على العرب',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.replace('مباشرة',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		title = '_MOD_'+title
		dwDUvp0LAuyg1rI = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if bbFPOJrmkCaE6ul37XiKU: dwDUvp0LAuyg1rI = bbFPOJrmkCaE6ul37XiKU[0]
		if dwDUvp0LAuyg1rI not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
			AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(dwDUvp0LAuyg1rI)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,B17r2fdFy9ns8tiOMLu,13,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				vVU3etr1sKREmPkX9z26D0qoJ = True
			elif 'series' in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,11,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				vVU3etr1sKREmPkX9z26D0qoJ = True
			else:
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,12,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				vVU3etr1sKREmPkX9z26D0qoJ = True
	if vVU3etr1sKREmPkX9z26D0qoJ:
		items = fNntYJW45mEFSdRX8g.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,mRwrKW6fNZV in items:
			url = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+mRwrKW6fNZV,url,11)
	return
def VzOBjnIkZSH7ft(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'ALARAB-EPISODES-1st')
	XJiqmptnOTc = fNntYJW45mEFSdRX8g.findall('href="(/series.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+XJiqmptnOTc[0]
	ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV = []
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'ALARAB-PLAY-1st')
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('class="resp-iframe" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT:
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('^(http.*?)(http.*?)$',vrEJRkchKxtDNiqO1b79mL5eT,fNntYJW45mEFSdRX8g.DOTALL)
		if PXFtqmw5lBGQNa0IV8:
			trd5bZgxTR = PXFtqmw5lBGQNa0IV8[0][0]
			a9QwvrLMsmCRNOKdPJk,u8gPKGbQBOVomTwUAW467nRYL = PXFtqmw5lBGQNa0IV8[0][1].rsplit('/',1)
			rdQ5tOIzuelfvcYbNsM = a9QwvrLMsmCRNOKdPJk+'?named=__watch'
			ss7YGDbuAIxgnqaQroTV.append(rdQ5tOIzuelfvcYbNsM)
			Ow0mUS9ZFyzuian = trd5bZgxTR+u8gPKGbQBOVomTwUAW467nRYL
		else:
			ssUAzo3RibtgDv7O0x = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,False,'ALARAB-PLAY-2nd')
			vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('"src": "(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if vrEJRkchKxtDNiqO1b79mL5eT:
				vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]+'?named=__watch__m3u8'
				ss7YGDbuAIxgnqaQroTV.append(vrEJRkchKxtDNiqO1b79mL5eT)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('searchBox(.*?)<style>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if vrEJRkchKxtDNiqO1b79mL5eT:
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]+'?named=__watch'
			ss7YGDbuAIxgnqaQroTV.append(vrEJRkchKxtDNiqO1b79mL5eT)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def Oi36L4kAcCK2():
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'ALARAB-RAMADAN-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="content_sec"(.*?)id="left_content"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	MugkeGqXAO15PW9 = fNntYJW45mEFSdRX8g.findall('/ramadan([0-9]+)/',str(items),fNntYJW45mEFSdRX8g.DOTALL)
	MugkeGqXAO15PW9 = MugkeGqXAO15PW9[0]
	for B17r2fdFy9ns8tiOMLu,title in items:
		url = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)+AAh0X3OCacr4HpifRGLZKT+MugkeGqXAO15PW9
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,11)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8 + "/q/" + ktT4O0VJm8UaDNlxKvinoBYFgdH
	ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	return
# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
import xbmc as FoiwfTEhGD8ulS25HeUvnI,re as fNntYJW45mEFSdRX8g,sys as xlOFiKpdTI1Vjw5YN,xbmcaddon as UFrHeStKa3MmB6o1xfsECp9VbN,random as VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC,os as YYEXZsUWhf52vz7HLxc0qGJ,xbmcvfs as DuYdwp9gNe1nE7qbT,time as hDjf1Ubgq629nXlOvcFLH4Jw,pickle as o5i4JgH2Z3pPC6br,zlib as eJFGwKIhm4iTx5dfalZqEkDj,xbmcgui as qqtbjl02E5pUOdQ1yMn8xABJsVG67w,xbmcplugin as RPtvgsXL0EzbhIr,sqlite3 as jcNEqrxW4uBOgHKhvU3dnMfXTFm,traceback as xlRuE56JKzkBeZbX1AqYUGrCfy0apj,threading as v9vwimFady3NL,hashlib as O2QkHmVIjxELq,json as Kdnrl9JHV0cFaGzC5bN
from wMsidgVoE7 import *
import Q1siCkTZyw
Ll1m0nJoaAPvHsXqyRE = IOHSz7YPF9WusGgUt1Dq(u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧഃ")
ffBvikd9sV = UFrHeStKa3MmB6o1xfsECp9VbN.Addon().getAddonInfo(hPFcB6Uxmabj59Iq(u"ࠧࡱࡣࡷ࡬ࠬഄ"))
NN0PuQ7ZiFsmgObx6dCY = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,Js61GTdX5wzMurUqi7Z(u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪഅ"))
xlOFiKpdTI1Vjw5YN.path.append(NN0PuQ7ZiFsmgObx6dCY)
LLt0mXJQ1Frlou9CT2g86YGNqKz = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣആ"))
A4AOrGi8QL = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧഇ"),LLt0mXJQ1Frlou9CT2g86YGNqKz,fNntYJW45mEFSdRX8g.DOTALL)
A4AOrGi8QL = float(A4AOrGi8QL[BewrUo9ANCa17G43Sn0LH5xh])
WrKEwgvP16MGD = FoiwfTEhGD8ulS25HeUvnI.Player
aNe7DOTW1st3bMQp9URuZhj4riV = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.WindowXMLDialog
qdUK5ioJyrO1T = A4AOrGi8QL<XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠴࠽ໜ")
I5VKjrFL0Bk97 = A4AOrGi8QL>wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠵࠽࠴࠹࠺ໝ")
if I5VKjrFL0Bk97:
	C2WLO5vrNS = DuYdwp9gNe1nE7qbT.translatePath(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬഈ"))
	WAYCiXUoEzsF8lgKDh4VBuaNnvp = FoiwfTEhGD8ulS25HeUvnI.LOGINFO
	t0ozNJUhjCVgRmMp89KGaWvfl3AS,aU23gVSeZ8QMl = EJgYdjbIiWe1apkQlZcR42(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ഉ"),BWfpRku7SsM6cbE0eG(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧഊ")
	FYRWMho3SjB = DuYdwp9gNe1nE7qbT.translatePath(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨഋ"))
	from urllib.parse import unquote as _vb57xQgZzPSkfw9G01J6FECyWdea
	zzXbKjEJ47ysUgH2LPl3dnt = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩഌ")
else:
	C2WLO5vrNS = FoiwfTEhGD8ulS25HeUvnI.translatePath(IO7k2hZXSz(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ഍"))
	WAYCiXUoEzsF8lgKDh4VBuaNnvp = FoiwfTEhGD8ulS25HeUvnI.LOGNOTICE
	t0ozNJUhjCVgRmMp89KGaWvfl3AS,aU23gVSeZ8QMl = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫഎ").encode(sFCqDzfS562gpyMjnLicrPWhB8oXT),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬഏ").encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	FYRWMho3SjB = FoiwfTEhGD8ulS25HeUvnI.translatePath(qqw1upCsKM(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ഐ"))
	from urllib import unquote as _vb57xQgZzPSkfw9G01J6FECyWdea
	zzXbKjEJ47ysUgH2LPl3dnt = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ഑").encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
Xkp839QMmYzrsoWTyca = xlOFiKpdTI1Vjw5YN.argv[BewrUo9ANCa17G43Sn0LH5xh].split(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧ࠰ࠩഒ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
ZWaC4pLbOV1QEMrof08eu = int(xlOFiKpdTI1Vjw5YN.argv[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
ERbOfw2FjKUAZGo = xlOFiKpdTI1Vjw5YN.argv[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
sIW4GjOcwn7HZliCkguPoE9K = Xkp839QMmYzrsoWTyca.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࠰ࠪഓ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
WHzJr591Ka8gRdbiLmBp0hT3S = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(IOHSz7YPF9WusGgUt1Dq(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩഔ")+Xkp839QMmYzrsoWTyca+TzIj50KpohEOHx6CbZWqB(u"ࠪ࠭ࠬക"))
XX4rMRSnQdbZ1NJiKu8pOfvDla = YYEXZsUWhf52vz7HLxc0qGJ.path.join(FYRWMho3SjB,Xkp839QMmYzrsoWTyca)
rNq1RX4ZwSpgcM35tPG60Hl8bFdhk = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,gDETKVh8mZe09Nd(u"ࠫ࡮ࡳࡡࡨࡧࡶࠫഖ"))
wagflpRqFe = YYEXZsUWhf52vz7HLxc0qGJ.path.join(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬഗ"))
xRy1Tct5K9n = YYEXZsUWhf52vz7HLxc0qGJ.path.join(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡹࠧഘ"))
EysacJBh8vHLKUlmjzNqY670WAbiuC = YYEXZsUWhf52vz7HLxc0qGJ.path.join(xRy1Tct5K9n,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪങ"))
elBiEOg5o8Vbn1wJ96LZcysxtqYF = YYEXZsUWhf52vz7HLxc0qGJ.path.join(C2WLO5vrNS,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ࡯ࡨࡨ࡮ࡧࠧച"),IO7k2hZXSz(u"ࠩࡉࡳࡳࡺࡳࠨഛ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭ജ"))
qD1l8d3bQVN2uanhBLpyWTtcx = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,sH6BOz5wKRFcEg(u"ࠫࡲࡧࡩ࡯ࡦࡤࡸࡦ࠴ࡤࡣࠩഝ"))
nbfoUAIGjyD2PQcSJO = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡲࡡࡴࡶࡹ࡭ࡩ࡫࡯ࡴ࠰ࡧࡥࡹ࠭ഞ"))
JVAlZw9Nsnj = int(hDjf1Ubgq629nXlOvcFLH4Jw.time())
fDQNTKLnvHaWw2BEAIzg0FPMjyq = UFrHeStKa3MmB6o1xfsECp9VbN.Addon(id=Xkp839QMmYzrsoWTyca)
xu70PCdiTQr = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪട"))
GsowyWv4QneEtJ = lvzrYTpcBaK if xu70PCdiTQr==WHzJr591Ka8gRdbiLmBp0hT3S else ndkUxG9LtewJ
def muXAzTa365Mjklef1ZP7JiWrIR(ZvWwXBJxzk3Qi9uAHKTD8hY2,qSTQadRYkueMBEG=t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡀࠩഠ")):
	if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠿ࠪഡ") in ZvWwXBJxzk3Qi9uAHKTD8hY2:
		if qSTQadRYkueMBEG in ZvWwXBJxzk3Qi9uAHKTD8hY2: vrEJRkchKxtDNiqO1b79mL5eT,AHWo7bqBpiKY8JD43N1vk = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(qSTQadRYkueMBEG,aYH620Dh48GEsTFfOBSQ7r(u"࠶ໞ"))
		else: vrEJRkchKxtDNiqO1b79mL5eT,AHWo7bqBpiKY8JD43N1vk = sCHVtMAvqirbQ4BUK3cgWo,ZvWwXBJxzk3Qi9uAHKTD8hY2
		AHWo7bqBpiKY8JD43N1vk = AHWo7bqBpiKY8JD43N1vk.split(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࠩࠫഢ"))
		i68iPmaHVAZknGv2SNpyzCwcFE = {}
		for PXyqQrDuLCGJ9618h24gi3jWnRO in AHWo7bqBpiKY8JD43N1vk:
			XuhpgCFwT9RcZe8Yta5,ueLNQY06r4zt3qk = PXyqQrDuLCGJ9618h24gi3jWnRO.split(Js61GTdX5wzMurUqi7Z(u"ࠪࡁࠬണ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠷ໟ"))
			i68iPmaHVAZknGv2SNpyzCwcFE[XuhpgCFwT9RcZe8Yta5] = ueLNQY06r4zt3qk
	else: vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = ZvWwXBJxzk3Qi9uAHKTD8hY2,{}
	return vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE
def nnXGrIdCOuVxENgQz3lsckS(zz17bL8m9dw2kIcNqR5ortGiXnKj4):
	vvPTLDfC6UnYucB7igeNOJb9sM,oT2iHwjfBx0FPX5ZCph9aWs38,oiY3SLt9RJEPj = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	zz17bL8m9dw2kIcNqR5ortGiXnKj4 = zz17bL8m9dw2kIcNqR5ortGiXnKj4.replace(t0ozNJUhjCVgRmMp89KGaWvfl3AS,sCHVtMAvqirbQ4BUK3cgWo).replace(aU23gVSeZ8QMl,sCHVtMAvqirbQ4BUK3cgWo)
	AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊ࠵࠾ࡃ࠲ࡈ࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫത"),zz17bL8m9dw2kIcNqR5ortGiXnKj4,fNntYJW45mEFSdRX8g.DOTALL)
	if AHhdOiGao5UZ: vvPTLDfC6UnYucB7igeNOJb9sM,oT2iHwjfBx0FPX5ZCph9aWs38,zz17bL8m9dw2kIcNqR5ortGiXnKj4 = AHhdOiGao5UZ[BewrUo9ANCa17G43Sn0LH5xh]
	if vvPTLDfC6UnYucB7igeNOJb9sM not in [AAh0X3OCacr4HpifRGLZKT,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ࠲ࠧഥ"),sCHVtMAvqirbQ4BUK3cgWo]: oiY3SLt9RJEPj = qqw1upCsKM(u"࠭࡟ࡎࡑࡇࡣࠬദ")
	if oT2iHwjfBx0FPX5ZCph9aWs38: oT2iHwjfBx0FPX5ZCph9aWs38 = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡠࠩധ")+oT2iHwjfBx0FPX5ZCph9aWs38+aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡡࠪന")
	zz17bL8m9dw2kIcNqR5ortGiXnKj4 = oT2iHwjfBx0FPX5ZCph9aWs38+oiY3SLt9RJEPj+zz17bL8m9dw2kIcNqR5ortGiXnKj4
	return zz17bL8m9dw2kIcNqR5ortGiXnKj4
def mSeoVfgRpNF9PKrJ(ZvWwXBJxzk3Qi9uAHKTD8hY2):
	return _vb57xQgZzPSkfw9G01J6FECyWdea(ZvWwXBJxzk3Qi9uAHKTD8hY2)
def g5FNRVqWzdHSAZGuoMe1YxETD3h(CXVGU3Nw6DA50ksJtSFPMIlEzRrTWo):
	XYOznjN9svQd = {sH6BOz5wKRFcEg(u"ࠩࡷࡽࡵ࡫ࠧഩ"):sCHVtMAvqirbQ4BUK3cgWo,SIkwCEdJHTD9v1(u"ࠪࡱࡴࡪࡥࠨപ"):sCHVtMAvqirbQ4BUK3cgWo,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡺࡸ࡬ࠨഫ"):sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠬࡺࡥࡹࡶࠪബ"):sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠭ࡰࡢࡩࡨࠫഭ"):sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧ࡯ࡣࡰࡩࠬമ"):sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠨ࡫ࡰࡥ࡬࡫ࠧയ"):sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪര"):sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬറ"):sCHVtMAvqirbQ4BUK3cgWo}
	if EJgYdjbIiWe1apkQlZcR42(u"ࠫࡄ࠭ല") in CXVGU3Nw6DA50ksJtSFPMIlEzRrTWo: CXVGU3Nw6DA50ksJtSFPMIlEzRrTWo = CXVGU3Nw6DA50ksJtSFPMIlEzRrTWo.split(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡅࠧള"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	vrEJRkchKxtDNiqO1b79mL5eT,E4f6gu3GROx2HaCWJiAISZ = muXAzTa365Mjklef1ZP7JiWrIR(CXVGU3Nw6DA50ksJtSFPMIlEzRrTWo)
	aargs = dict(list(XYOznjN9svQd.items())+list(E4f6gu3GROx2HaCWJiAISZ.items()))
	a9lewTLUIoWC5 = aargs[zLjWeKu6JgNO7vocUD0Qpy(u"࠭࡭ࡰࡦࡨࠫഴ")]
	bHQ2jlVsNGdkXx = mSeoVfgRpNF9PKrJ(aargs[qqw1upCsKM(u"ࠧࡶࡴ࡯ࠫവ")])
	v1vsUdVLNe7SqERy48trJZhP9f = mSeoVfgRpNF9PKrJ(aargs[t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡶࡨࡼࡹ࠭ശ")])
	u8Pi3ZV2vQGfm = mSeoVfgRpNF9PKrJ(aargs[gDETKVh8mZe09Nd(u"ࠩࡳࡥ࡬࡫ࠧഷ")])
	wwRALzTk89gKGqsZ = mSeoVfgRpNF9PKrJ(aargs[bGzRdmOErkIylxALniq6(u"ࠪࡸࡾࡶࡥࠨസ")])
	qqk7Fgcdxl6DW9KARr3XO = mSeoVfgRpNF9PKrJ(aargs[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡳࡧ࡭ࡦࠩഹ")])
	tDnaQez4Sugsimf9TGvpP = mSeoVfgRpNF9PKrJ(aargs[SIkwCEdJHTD9v1(u"ࠬ࡯࡭ࡢࡩࡨࠫഺ")])
	btpnEkYS8OTDFKxjQgzeCX = aargs[hPFcB6Uxmabj59Iq(u"࠭ࡣࡰࡰࡷࡩࡽࡺ഻ࠧ")]
	XylSkhaf9VZEjnebv20J4MRLdWpmc = mSeoVfgRpNF9PKrJ(aargs[RDwahqjPfbdyEiTtnLQu(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵ഼ࠩ")])
	if XylSkhaf9VZEjnebv20J4MRLdWpmc: XylSkhaf9VZEjnebv20J4MRLdWpmc = eval(XylSkhaf9VZEjnebv20J4MRLdWpmc)
	else: XylSkhaf9VZEjnebv20J4MRLdWpmc = {}
	if not a9lewTLUIoWC5: wwRALzTk89gKGqsZ = qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨഽ") ; a9lewTLUIoWC5 = aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࠵࠺࠵࠭ാ")
	return wwRALzTk89gKGqsZ,qqk7Fgcdxl6DW9KARr3XO,bHQ2jlVsNGdkXx,a9lewTLUIoWC5,tDnaQez4Sugsimf9TGvpP,u8Pi3ZV2vQGfm,v1vsUdVLNe7SqERy48trJZhP9f,btpnEkYS8OTDFKxjQgzeCX,XylSkhaf9VZEjnebv20J4MRLdWpmc
def JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE):
	rrjoEaIPihWTLAFz61lXNZ = xlOFiKpdTI1Vjw5YN._getframe(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU).f_code.co_name
	if not Ll1m0nJoaAPvHsXqyRE or not rrjoEaIPihWTLAFz61lXNZ or rrjoEaIPihWTLAFz61lXNZ==RDwahqjPfbdyEiTtnLQu(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬി"):
		return gDETKVh8mZe09Nd(u"ࠫࡠࠦࠧീ")+sIW4GjOcwn7HZliCkguPoE9K.upper()+BWfpRku7SsM6cbE0eG(u"ࠬࡥࠧു")+WHzJr591Ka8gRdbiLmBp0hT3S+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭࡟ࠨൂ")+str(A4AOrGi8QL)+SE97R3Dpj6dPLweVKU(u"ࠧࠡ࡟ࠪൃ")
	return qeG16a4pbSHziNVQ2uFXrs(u"ࠨ࠰࡟ࡸࠬൄ")+rrjoEaIPihWTLAFz61lXNZ
def SH6EVn0T9d8bKCUMLl1sJOFR(kqGBCd3XrSN,LZ1DGWKyolJb2NgvOzIR0=sCHVtMAvqirbQ4BUK3cgWo):
	if not LZ1DGWKyolJb2NgvOzIR0: kqGBCd3XrSN,LZ1DGWKyolJb2NgvOzIR0 = sCHVtMAvqirbQ4BUK3cgWo,kqGBCd3XrSN
	LZ1DGWKyolJb2NgvOzIR0 = LZ1DGWKyolJb2NgvOzIR0.replace(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࡟ࡼ࠵࠶ࠧ൅"),sCHVtMAvqirbQ4BUK3cgWo)
	if qdUK5ioJyrO1T:
		try: LZ1DGWKyolJb2NgvOzIR0 = LZ1DGWKyolJb2NgvOzIR0.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪെ")).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫേ"))
		except: LZ1DGWKyolJb2NgvOzIR0 = LZ1DGWKyolJb2NgvOzIR0.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT,qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬൈ"))
	zw4YhbkeE7UJgpRSiPVfCtH = WAYCiXUoEzsF8lgKDh4VBuaNnvp
	CChmRfAOZ4eLtczYduF = [sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo]
	if kqGBCd3XrSN: LZ1DGWKyolJb2NgvOzIR0 = LZ1DGWKyolJb2NgvOzIR0.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo).replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
	else: kqGBCd3XrSN = lIm9XbGnwLkdi5q
	UPbrd4HYXyFLaiZN0eWm,qSTQadRYkueMBEG = XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࡜ࡵࠩ൉"),OUmtsIB1zyF
	YLPN3aMnlwrQHudjqSc = SE97R3Dpj6dPLweVKU(u"࠵࠴໡")*AAh0X3OCacr4HpifRGLZKT if I5VKjrFL0Bk97 else E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳࠲໠")*AAh0X3OCacr4HpifRGLZKT
	s3r5yTo6bez = kK7gj9HE462hADJbvr*UPbrd4HYXyFLaiZN0eWm
	if LZ1DGWKyolJb2NgvOzIR0.startswith(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨൊ")): LZ1DGWKyolJb2NgvOzIR0 = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࠰࡟ࡸࠬോ")+LZ1DGWKyolJb2NgvOzIR0
	if oom21Pvk6Q59d in kqGBCd3XrSN: zw4YhbkeE7UJgpRSiPVfCtH = FoiwfTEhGD8ulS25HeUvnI.LOGERROR
	if kqGBCd3XrSN in [lIm9XbGnwLkdi5q,oom21Pvk6Q59d]: CChmRfAOZ4eLtczYduF = [LZ1DGWKyolJb2NgvOzIR0]
	elif kqGBCd3XrSN==wdyXQbPWRMOrg82: CChmRfAOZ4eLtczYduF = LZ1DGWKyolJb2NgvOzIR0.split(qSTQadRYkueMBEG)
	elif kqGBCd3XrSN==CRxa3v2o1wMXzZLu8FDinm6gsr:
		PDwk9XvU7CeV = LZ1DGWKyolJb2NgvOzIR0.split(qSTQadRYkueMBEG)
		CChmRfAOZ4eLtczYduF = [PDwk9XvU7CeV[BewrUo9ANCa17G43Sn0LH5xh]]
		for dAukY5fr20HZDntgKLi in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,len(PDwk9XvU7CeV),rgpY5VUqKbeFOCD9Nki2SmGvxEja):
			try: aLqBFQT7HhrKyf4I3cewWjum9v = PDwk9XvU7CeV[dAukY5fr20HZDntgKLi]+qSTQadRYkueMBEG+PDwk9XvU7CeV[dAukY5fr20HZDntgKLi+GVurlv8HeoXEzPRiQB7Ty(u"࠳໢")]
			except: aLqBFQT7HhrKyf4I3cewWjum9v = PDwk9XvU7CeV[dAukY5fr20HZDntgKLi]
			CChmRfAOZ4eLtczYduF.append(aLqBFQT7HhrKyf4I3cewWjum9v)
	NNhO1itsfkYvRg42 = CChmRfAOZ4eLtczYduF[BewrUo9ANCa17G43Sn0LH5xh]
	for MCDsZVht3YjHOx in CChmRfAOZ4eLtczYduF[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]:
		if kqGBCd3XrSN in [wdyXQbPWRMOrg82,CRxa3v2o1wMXzZLu8FDinm6gsr]: s3r5yTo6bez += UPbrd4HYXyFLaiZN0eWm
		NNhO1itsfkYvRg42 += f6fsIXQonhvcGg1p+YLPN3aMnlwrQHudjqSc+s3r5yTo6bez+MCDsZVht3YjHOx
	if kqGBCd3XrSN in [oom21Pvk6Q59d,wdyXQbPWRMOrg82]: NNhO1itsfkYvRg42 += slFfrUIWCowaBA7tce3iZbj8xn
	NNhO1itsfkYvRg42 += Js61GTdX5wzMurUqi7Z(u"ࠩࠣࡣࠬൌ")
	if oVwa0kcqxj1e7mLplAfZdGT(u"്ࠪࠩࠬ") in NNhO1itsfkYvRg42: NNhO1itsfkYvRg42 = mSeoVfgRpNF9PKrJ(NNhO1itsfkYvRg42)
	FoiwfTEhGD8ulS25HeUvnI.log(NNhO1itsfkYvRg42,level=zw4YhbkeE7UJgpRSiPVfCtH)
	return
def spTLJreC42Nlh9dInEKvyF7w(Km2Nn9TCXAu5Lt3FoBRHyxZ7P):
	try: lxGwZhDLdoySA1avUN5 = jcNEqrxW4uBOgHKhvU3dnMfXTFm.connect(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,check_same_thread=lvzrYTpcBaK)
	except:
		if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(XX4rMRSnQdbZ1NJiKu8pOfvDla):
			YYEXZsUWhf52vz7HLxc0qGJ.makedirs(XX4rMRSnQdbZ1NJiKu8pOfvDla)
			lxGwZhDLdoySA1avUN5 = jcNEqrxW4uBOgHKhvU3dnMfXTFm.connect(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,check_same_thread=lvzrYTpcBaK)
	lxGwZhDLdoySA1avUN5.text_factory = str
	Fy1DHCosVPbSNMnWl0RQaiLtxB = lxGwZhDLdoySA1avUN5.cursor()
	Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡩ࡟ࡪࡰࡧࡩࡽࡃ࡮ࡰࠢ࠾ࠫൎ"))
	Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࠦ࠻ࠨ൏"))
	Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(SIkwCEdJHTD9v1(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇࠢ࠾ࠫ൐"))
	Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇࠢ࠾ࠫ൑"))
	lxGwZhDLdoySA1avUN5.commit()
	return lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB
def cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,yMvGrmLuA9UWecgxzdOlhV,hNAQSTsxa1O,po8ZR6HBscC=()):
	TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = ZetiSjBQ9bTnF23pzsmXcyWuK
	timeout = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠴࠴໣")
	OO4rxuZoVb8KA5mdCl9HcRJiY3PIsS = hDjf1Ubgq629nXlOvcFLH4Jw.time()
	import tqHErj9p1I
	while hDjf1Ubgq629nXlOvcFLH4Jw.time()-OO4rxuZoVb8KA5mdCl9HcRJiY3PIsS<timeout:
		try:
			if yMvGrmLuA9UWecgxzdOlhV: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = Fy1DHCosVPbSNMnWl0RQaiLtxB.executemany(hNAQSTsxa1O,po8ZR6HBscC).fetchall()
			else: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(hNAQSTsxa1O,po8ZR6HBscC).fetchall()
			break
		except Exception as JcXhduGYBrITK0Hg:
			if qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡦࡤࡸࡦࡨࡡࡴࡧࠣ࡭ࡸࠦ࡬ࡰࡥ࡮ࡩࡩ࠭൒") not in str(JcXhduGYBrITK0Hg): break
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,qeG16a4pbSHziNVQ2uFXrs(u"ࠩ࠱ࡠࡹࡊࡡࡵࡣࡥࡥࡸ࡫ࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡ࡮ࡲࡧࡰ࡫ࡤࠡࠢࠣࠫ൓")+Km2Nn9TCXAu5Lt3FoBRHyxZ7P+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡷࡩࡧࡱࠤࡪࡾࡥࡤࡷࡷ࡭ࡳ࡭ࠠࡵࡪ࡬ࡷࠥࡹࡴࡢࡶࡨࡱࡪࡴࡴࠡࠢࠣࠫൔ")+hNAQSTsxa1O)
		lxGwZhDLdoySA1avUN5.commit()
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(TzIj50KpohEOHx6CbZWqB(u"࠴࠳࠸࠵໤"))
	lxGwZhDLdoySA1avUN5.commit()
	return TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq
def JKCrO8x7ZyIfwVgSvX(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,ELcNnjip84CGbeK,rD2FgmZUo9ELzqCwOJAvaKcH10NR,zzPrYFDOSEiaw0nVdu1qfXL=ZetiSjBQ9bTnF23pzsmXcyWuK):
	gWlmUqwV3YrIT2XNPxQCisBHSDG9 = Z3ugcA9ihpqBzDJM(ELcNnjip84CGbeK)
	K6SYhoTVCnIFyEe8zL4X2 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪൕ"))
	if rD2FgmZUo9ELzqCwOJAvaKcH10NR not in [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨൖ"),RDwahqjPfbdyEiTtnLQu(u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡐࡍࡋࡗࡘࡊࡊ࡟ࡂࡎࡏࠫൗ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡑࡎࡌࡘ࡙ࡋࡄࡠࡉࡒࡓࡌࡒࡅࠨ൘")] and Km2Nn9TCXAu5Lt3FoBRHyxZ7P==qD1l8d3bQVN2uanhBLpyWTtcx and zzPrYFDOSEiaw0nVdu1qfXL!=zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ൙"):
		if K6SYhoTVCnIFyEe8zL4X2==zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡖࡘࡔࡖࠧ൚"): return gWlmUqwV3YrIT2XNPxQCisBHSDG9
		VCYw96jJq4Gk = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ൛"))
		if VCYw96jJq4Gk==IOHSz7YPF9WusGgUt1Dq(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ൜"):
			aDIrWXnPZ7zY8ulSpedh9tfEKb(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,rD2FgmZUo9ELzqCwOJAvaKcH10NR,zzPrYFDOSEiaw0nVdu1qfXL)
			return gWlmUqwV3YrIT2XNPxQCisBHSDG9
	JMqK2nLmt0AHW6zeS8E = BewrUo9ANCa17G43Sn0LH5xh
	if K6SYhoTVCnIFyEe8zL4X2==hPFcB6Uxmabj59Iq(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭൝"): JMqK2nLmt0AHW6zeS8E = LLg3oeFAZujGWitdBw0DOsRmhlVk
	lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(Km2Nn9TCXAu5Lt3FoBRHyxZ7P)
	if JMqK2nLmt0AHW6zeS8E: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭൞")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+YQNd4wejLSAVJ6T(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠿ࠩൟ")+str(JVAlZw9Nsnj+JMqK2nLmt0AHW6zeS8E)+qeG16a4pbSHziNVQ2uFXrs(u"ࠨࠢ࠾ࠫൠ"))
	TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,bGzRdmOErkIylxALniq6(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩൡ")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+SE97R3Dpj6dPLweVKU(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡀࠬൢ")+str(JVAlZw9Nsnj)+sH6BOz5wKRFcEg(u"ࠫࠥࡁࠧൣ"))
	if zzPrYFDOSEiaw0nVdu1qfXL:
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠤࠪ൤")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+oVwa0kcqxj1e7mLplAfZdGT(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭൥"),(str(zzPrYFDOSEiaw0nVdu1qfXL),))
		if TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq:
			try:
				TqNvzBxf1KpPDg3SRA4yj2mwcVF = eJFGwKIhm4iTx5dfalZqEkDj.decompress(TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh])
				gWlmUqwV3YrIT2XNPxQCisBHSDG9 = o5i4JgH2Z3pPC6br.loads(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
			except: pass
	else:
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,RDwahqjPfbdyEiTtnLQu(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬ൦")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+qeG16a4pbSHziNVQ2uFXrs(u"ࠨࠤࠣ࠿ࠬ൧"))
		if TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq:
			gWlmUqwV3YrIT2XNPxQCisBHSDG9,lI5DAaOBo4N0cm = {},[]
			for kkeIbrwGSngmTJcaMUVX0p,i68iPmaHVAZknGv2SNpyzCwcFE in TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq:
				pnXGs1DmPvYJE2SliMLB = eJFGwKIhm4iTx5dfalZqEkDj.decompress(i68iPmaHVAZknGv2SNpyzCwcFE)
				i68iPmaHVAZknGv2SNpyzCwcFE = o5i4JgH2Z3pPC6br.loads(pnXGs1DmPvYJE2SliMLB)
				gWlmUqwV3YrIT2XNPxQCisBHSDG9[kkeIbrwGSngmTJcaMUVX0p] = i68iPmaHVAZknGv2SNpyzCwcFE
				lI5DAaOBo4N0cm.append(kkeIbrwGSngmTJcaMUVX0p)
			if lI5DAaOBo4N0cm:
				gWlmUqwV3YrIT2XNPxQCisBHSDG9[qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ൨")] = lI5DAaOBo4N0cm
				if ELcNnjip84CGbeK==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡰ࡮ࡹࡴࠨ൩"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = lI5DAaOBo4N0cm
	lxGwZhDLdoySA1avUN5.close()
	return gWlmUqwV3YrIT2XNPxQCisBHSDG9
def kPQB6UJMiVGmHoT9w8(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,rD2FgmZUo9ELzqCwOJAvaKcH10NR,zzPrYFDOSEiaw0nVdu1qfXL,gWlmUqwV3YrIT2XNPxQCisBHSDG9,DDjhsEl7bwnm0H,m38c7jLiUNnhQ90uIf=lvzrYTpcBaK):
	K6SYhoTVCnIFyEe8zL4X2 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ൪"))
	if K6SYhoTVCnIFyEe8zL4X2==YQNd4wejLSAVJ6T(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭൫") and DDjhsEl7bwnm0H>LLg3oeFAZujGWitdBw0DOsRmhlVk: DDjhsEl7bwnm0H = LLg3oeFAZujGWitdBw0DOsRmhlVk
	if m38c7jLiUNnhQ90uIf:
		ofLNbsZxdtEvC0gRM2r9khzTeV,qpC2d7QYwEsVM4SxLnjGZOBbr95 = [],[]
		for ruCEzOyVgmGt9WHI7BSofF6d8 in range(len(zzPrYFDOSEiaw0nVdu1qfXL)):
			TqNvzBxf1KpPDg3SRA4yj2mwcVF = o5i4JgH2Z3pPC6br.dumps(gWlmUqwV3YrIT2XNPxQCisBHSDG9[ruCEzOyVgmGt9WHI7BSofF6d8])
			bGwsU4tNFuVD61Bn = eJFGwKIhm4iTx5dfalZqEkDj.compress(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
			ofLNbsZxdtEvC0gRM2r9khzTeV.append((zzPrYFDOSEiaw0nVdu1qfXL[ruCEzOyVgmGt9WHI7BSofF6d8],))
			qpC2d7QYwEsVM4SxLnjGZOBbr95.append((DDjhsEl7bwnm0H+JVAlZw9Nsnj,str(zzPrYFDOSEiaw0nVdu1qfXL[ruCEzOyVgmGt9WHI7BSofF6d8]),bGwsU4tNFuVD61Bn))
	else:
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = o5i4JgH2Z3pPC6br.dumps(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		iiey8KZNLChmU5 = eJFGwKIhm4iTx5dfalZqEkDj.compress(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(Km2Nn9TCXAu5Lt3FoBRHyxZ7P)
	TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,qqw1upCsKM(u"࠭ࡃࡓࡇࡄࡘࡊࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡐࡒࡘࠥࡋࡘࡊࡕࡗࡗࠥࠨࠧ൬")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+jwzOabysh0Z(u"ࠧࠣࠢࠫࡩࡽࡶࡩࡳࡻ࠯ࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠪࠢ࠾ࠫ൭"))
	if m38c7jLiUNnhQ90uIf:
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,ndkUxG9LtewJ,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ൮")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+sH6BOz5wKRFcEg(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ൯"),ofLNbsZxdtEvC0gRM2r9khzTeV)
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,ndkUxG9LtewJ,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪ൰")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩ൱"),qpC2d7QYwEsVM4SxLnjGZOBbr95)
	else:
		if DDjhsEl7bwnm0H:
			TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,bGzRdmOErkIylxALniq6(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ൲")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+fvYGxnZNUiyP4HJkMIoS25(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭൳"),(str(zzPrYFDOSEiaw0nVdu1qfXL),))
			TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ൴")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭൵"),(DDjhsEl7bwnm0H+JVAlZw9Nsnj,str(zzPrYFDOSEiaw0nVdu1qfXL),iiey8KZNLChmU5))
		else:
			TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,hPFcB6Uxmabj59Iq(u"ࠩࡘࡔࡉࡇࡔࡆࠢࠥࠫ൶")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+SE97R3Dpj6dPLweVKU(u"࡙ࠪࠦࠥࡅࡕࠢࡧࡥࡹࡧࠠ࠾ࠢࡂࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ൷"),(iiey8KZNLChmU5,str(zzPrYFDOSEiaw0nVdu1qfXL)))
	lxGwZhDLdoySA1avUN5.close()
	return
def aDIrWXnPZ7zY8ulSpedh9tfEKb(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,rD2FgmZUo9ELzqCwOJAvaKcH10NR,zzPrYFDOSEiaw0nVdu1qfXL=ZetiSjBQ9bTnF23pzsmXcyWuK):
	lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(Km2Nn9TCXAu5Lt3FoBRHyxZ7P)
	if zzPrYFDOSEiaw0nVdu1qfXL==ZetiSjBQ9bTnF23pzsmXcyWuK: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,BWfpRku7SsM6cbE0eG(u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭൸")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࠨࠠ࠼ࠩ൹"))
	else:
		QM2ZImdXnzTkS7Yy8qW35KohEGax6 = (str(zzPrYFDOSEiaw0nVdu1qfXL),)
		if bGzRdmOErkIylxALniq6(u"࠭ࠥࠨൺ") in zzPrYFDOSEiaw0nVdu1qfXL: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,RDwahqjPfbdyEiTtnLQu(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧൻ")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+Js61GTdX5wzMurUqi7Z(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫർ"),QM2ZImdXnzTkS7Yy8qW35KohEGax6)
		else: TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = cc5Z1RvyW0JlMqzxKuA2BV9(Km2Nn9TCXAu5Lt3FoBRHyxZ7P,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,YQNd4wejLSAVJ6T(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩൽ")+rD2FgmZUo9ELzqCwOJAvaKcH10NR+IOHSz7YPF9WusGgUt1Dq(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪൾ"),QM2ZImdXnzTkS7Yy8qW35KohEGax6)
	lxGwZhDLdoySA1avUN5.close()
	return
class Ri48LsGaHerVuZX7Nd(): pass
class Rxc41oNqDF(Ri48LsGaHerVuZX7Nd):
	def __init__(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.url = sCHVtMAvqirbQ4BUK3cgWo
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.code = -hPFcB6Uxmabj59Iq(u"࠾࠿໥")
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.reason = sCHVtMAvqirbQ4BUK3cgWo
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.content = sCHVtMAvqirbQ4BUK3cgWo
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.headers = {}
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.cookies = {}
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.succeeded = lvzrYTpcBaK
def Z3ugcA9ihpqBzDJM(ScEpZwINx93VJ5aWfb4):
	if ScEpZwINx93VJ5aWfb4==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡩ࡯ࡣࡵࠩൿ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = {}
	elif ScEpZwINx93VJ5aWfb4==bGzRdmOErkIylxALniq6(u"ࠬࡲࡩࡴࡶࠪ඀"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = []
	elif ScEpZwINx93VJ5aWfb4==aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡴࡶࡲ࡯ࡩࠬඁ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = ()
	elif ScEpZwINx93VJ5aWfb4==SE97R3Dpj6dPLweVKU(u"ࠧࡴࡶࡵࠫං"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = sCHVtMAvqirbQ4BUK3cgWo
	elif ScEpZwINx93VJ5aWfb4==aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࡫ࡱࡸࠬඃ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = BewrUo9ANCa17G43Sn0LH5xh
	elif ScEpZwINx93VJ5aWfb4==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ඄"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = Rxc41oNqDF()
	elif not ScEpZwINx93VJ5aWfb4: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = ZetiSjBQ9bTnF23pzsmXcyWuK
	else: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = ZetiSjBQ9bTnF23pzsmXcyWuK
	return gWlmUqwV3YrIT2XNPxQCisBHSDG9
def MN3T7mznDkdF(CCF4HAtDpIOGicqzlJnMNRho2ZygYS):
	DCjGexuaXMNAPSL7cn = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭අ"))
	W8bymBGDL0TKtlA46o7Y2 = Q1siCkTZyw.AV_CLIENT_IDS.splitlines()
	BGKeuk0mQ1b7xR6 = BewrUo9ANCa17G43Sn0LH5xh
	l4M5eoBRmE = len(CCF4HAtDpIOGicqzlJnMNRho2ZygYS)
	SDh8EX2tbg0BwHpqecoGiF1fsP = [lvzrYTpcBaK]*l4M5eoBRmE
	for mpMRWQBLZPa8eSChXzji7xn in [JVAlZw9Nsnj,JVAlZw9Nsnj-EGwIN9K6n5rVsjpLC4qvSUTyo3Z2]:
		Ktx53gRi6zsc8ODXaLWyNVmj = str(mpMRWQBLZPa8eSChXzji7xn*qqw1upCsKM(u"࠱࠱࠲࠳࠴࠵࠴࠰໧")/Js61GTdX5wzMurUqi7Z(u"࠺࠳࠳࠲࠳࠴໦"))[BewrUo9ANCa17G43Sn0LH5xh:E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠵໨")]
		if Ktx53gRi6zsc8ODXaLWyNVmj!=BGKeuk0mQ1b7xR6:
			for dAukY5fr20HZDntgKLi in range(l4M5eoBRmE):
				if not SDh8EX2tbg0BwHpqecoGiF1fsP[dAukY5fr20HZDntgKLi]:
					aa0t2BHrOX8sdCm = lvzrYTpcBaK
					for cQlZh3kA0Lwoz9stXWHu8dK65U7C2a in W8bymBGDL0TKtlA46o7Y2:
						tp5PA0K6xmvB = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࡝࠷࠹ࠨආ")+CCF4HAtDpIOGicqzlJnMNRho2ZygYS[dAukY5fr20HZDntgKLi]+oVwa0kcqxj1e7mLplAfZdGT(u"ࠬ࠷࠸࠾ࠩඇ")+cQlZh3kA0Lwoz9stXWHu8dK65U7C2a[-oVwa0kcqxj1e7mLplAfZdGT(u"࠴࠷໩"):]+WHzJr591Ka8gRdbiLmBp0hT3S+Ktx53gRi6zsc8ODXaLWyNVmj
						tp5PA0K6xmvB = O2QkHmVIjxELq.md5(tp5PA0K6xmvB.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()[:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠶࠶໪")]
						if tp5PA0K6xmvB in DCjGexuaXMNAPSL7cn:
							aa0t2BHrOX8sdCm = ndkUxG9LtewJ
							break
					SDh8EX2tbg0BwHpqecoGiF1fsP[dAukY5fr20HZDntgKLi] = aa0t2BHrOX8sdCm
		BGKeuk0mQ1b7xR6 = Ktx53gRi6zsc8ODXaLWyNVmj
	return SDh8EX2tbg0BwHpqecoGiF1fsP
class HMzjup1gByIwG(WrKEwgvP16MGD):
	def __init__(thP1UxTJWikB5QSNM9ERdDIbOpfZ): pass
	def lWmwN4ZC3Hz6AUj1BLJxOivI(thP1UxTJWikB5QSNM9ERdDIbOpfZ,C1iP8hmd9kRa0xY4FWer):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧඈ") if Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc else sCHVtMAvqirbQ4BUK3cgWo
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.C1iP8hmd9kRa0xY4FWer = C1iP8hmd9kRa0xY4FWer
		if not Q1siCkTZyw.P56VUO0NuA8bq:
			import CCKRSEkHBw
			CCKRSEkHBw.hO36FxWalTjkvQ9IzPH7bo(xCE0toTumIHWiLyMfF)
	def onPlayBackStopped(thP1UxTJWikB5QSNM9ERdDIbOpfZ): thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧඉ")
	def onPlayBackError(thP1UxTJWikB5QSNM9ERdDIbOpfZ): thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨඊ")
	def onPlayBackEnded(thP1UxTJWikB5QSNM9ERdDIbOpfZ): thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = YQNd4wejLSAVJ6T(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩඋ")
	def onPlayBackStarted(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫඌ")
		fYTtDBCSAZLyauI7xOGJPhpK = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=thP1UxTJWikB5QSNM9ERdDIbOpfZ.OvuPBHhKC4)
		fYTtDBCSAZLyauI7xOGJPhpK.start()
	def onAVStarted(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		if Q1siCkTZyw.P56VUO0NuA8bq: thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = SIkwCEdJHTD9v1(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬඍ")
		else: thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = SE97R3Dpj6dPLweVKU(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ඎ")
	def OvuPBHhKC4(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		AA6xmFYBTg2kfJ0Q9t5PNrWs(qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡳࡵࡱࡳࠫඏ"))
		W0Q1yUDVihsKCA5xkaM7qlu = BewrUo9ANCa17G43Sn0LH5xh
		while not eval(qqw1upCsKM(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬඐ"),{TzIj50KpohEOHx6CbZWqB(u"ࠨࡺࡥࡱࡨ࠭එ"):FoiwfTEhGD8ulS25HeUvnI}) and thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪඒ"):
			FoiwfTEhGD8ulS25HeUvnI.sleep(EJgYdjbIiWe1apkQlZcR42(u"࠵࠵࠶࠰໫"))
			W0Q1yUDVihsKCA5xkaM7qlu += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			if W0Q1yUDVihsKCA5xkaM7qlu>t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠻࠶໬"): return
		if Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc: thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫඓ")
		elif Q1siCkTZyw.P56VUO0NuA8bq: thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬඔ")
		elif Q1siCkTZyw.sIS7FqTadm3ZEJpg4G:
			import CCKRSEkHBw
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ඕ")
			XHWyDMnTY74vCG = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=CCKRSEkHBw.EEtm4D3fSIHhZpeyl68gqL9JUciXuo,args=(thP1UxTJWikB5QSNM9ERdDIbOpfZ.C1iP8hmd9kRa0xY4FWer,)).start()
			wBpDjAUsqoc8mGti2nb = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=CCKRSEkHBw.IlwgjiRbfLCAouYX2k0vVqQT7DSJ).start()
		else: thP1UxTJWikB5QSNM9ERdDIbOpfZ.uQf6qJZCOzK5R = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧඖ")
def gPs81ehZEAucbqrNl2WfKViOGF():
	QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	xDJtcgz9NiQvkLG1sn4weyZ7uXE = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭඗"))
	try:
		qo7wjJXOWrzcZtD0HKxEyi = open(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ඘"),qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡵࡦࠬ඙")).read()
		if I5VKjrFL0Bk97: qo7wjJXOWrzcZtD0HKxEyi = qo7wjJXOWrzcZtD0HKxEyi.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		IM3YuhQBfWbAySiHc = fNntYJW45mEFSdRX8g.findall(aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧක"),qo7wjJXOWrzcZtD0HKxEyi,fNntYJW45mEFSdRX8g.IGNORECASE)
		if IM3YuhQBfWbAySiHc: QVKeCkS0sb8POThNiU = IM3YuhQBfWbAySiHc[BewrUo9ANCa17G43Sn0LH5xh]
	except: pass
	try:
		import subprocess as n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx
		Z3bWwelnq1daSk6sBuo = n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.Popen(aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩඛ"),shell=ndkUxG9LtewJ,stdin=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE,stdout=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE,stderr=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE)
		IYiwhf9syCFxnPNTjX24Rr0Kc7d8 = Z3bWwelnq1daSk6sBuo.stdout.read()
		if IYiwhf9syCFxnPNTjX24Rr0Kc7d8:
			if I5VKjrFL0Bk97:
				IYiwhf9syCFxnPNTjX24Rr0Kc7d8 = IYiwhf9syCFxnPNTjX24Rr0Kc7d8.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,YQNd4wejLSAVJ6T(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬග"))
			yrks4eDiI7 = fNntYJW45mEFSdRX8g.findall(hPFcB6Uxmabj59Iq(u"࠭ࠠࠩ࡞ࡧࡿ࠶࠶ࡽࠪࠢࠪඝ"),IYiwhf9syCFxnPNTjX24Rr0Kc7d8,fNntYJW45mEFSdRX8g.IGNORECASE)
			if yrks4eDiI7: pOoVJZDrxPGRbBw1UzXQ0t9qS = min(yrks4eDiI7)
	except: pass
	return xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS
def CCKuzJQIRvg(apfJtOlTi9ZAPxdDFW2GC0w8oKk=ndkUxG9LtewJ,aaRe85jDnZKfx7E=XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠹࠲໭")):
	s4df8jGwgqUZJE = ndkUxG9LtewJ
	if apfJtOlTi9ZAPxdDFW2GC0w8oKk:
		dmAyJ9NEPVQgeWzB0C = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,IOHSz7YPF9WusGgUt1Dq(u"ࠧ࡭࡫ࡶࡸࠬඞ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫඟ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧච"))
		if dmAyJ9NEPVQgeWzB0C:
			L8w3sZbMmtKDV1dSTOY7G,ZkI3OjwHXWTgv1,TnU3cSxmM0lZCpG,HmvrGxWA4U6Dg = dmAyJ9NEPVQgeWzB0C
			s4df8jGwgqUZJE = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,YQNd4wejLSAVJ6T(u"ࠪࡰ࡮ࡹࡴࠨඡ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧජ"),EJgYdjbIiWe1apkQlZcR42(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫඣ"))
			if s4df8jGwgqUZJE: xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS = s4df8jGwgqUZJE
			else: xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS = gPs81ehZEAucbqrNl2WfKViOGF()
			if (ZkI3OjwHXWTgv1,TnU3cSxmM0lZCpG,HmvrGxWA4U6Dg)==(xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS):
				srUCekDRHJw0ibglXOhBo2tE = slFfrUIWCowaBA7tce3iZbj8xn.join(L8w3sZbMmtKDV1dSTOY7G)
				return srUCekDRHJw0ibglXOhBo2tE
	if s4df8jGwgqUZJE: xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS = gPs81ehZEAucbqrNl2WfKViOGF()
	global J9xAHQEXz80PMwkW,LEVUxS2Zj5H6CsrRNaimz
	J9xAHQEXz80PMwkW,LEVUxS2Zj5H6CsrRNaimz,ngoY1Qm7z4hB3bJvUsG68PFf = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	aaRe85jDnZKfx7E = aaRe85jDnZKfx7E//rgpY5VUqKbeFOCD9Nki2SmGvxEja
	P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=LgtBusqR8fAX7).start()
	P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=mmOyn2bkIYsq0aJQrh7).start()
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(t19ZOVHA4CpwFKaeiubcMGvz(u"࠱࠱໮")):
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠱࠰࠸໯"))
		if not ngoY1Qm7z4hB3bJvUsG68PFf:
			try:
				CJhkXv1j0M = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(Js61GTdX5wzMurUqi7Z(u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡎࡣࡦࡅࡩࡪࡲࡦࡵࡶࠫඤ"))
				if CJhkXv1j0M.count(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧ࠻ࠩඥ"))==tBMCpcY2vUV1dEjZ7PDG and CJhkXv1j0M.count(SE97R3Dpj6dPLweVKU(u"ࠨ࠲ࠪඦ"))<RDwahqjPfbdyEiTtnLQu(u"࠻໰"):
					CJhkXv1j0M = CJhkXv1j0M.lower().replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠽ࠫට"),sCHVtMAvqirbQ4BUK3cgWo)
					ngoY1Qm7z4hB3bJvUsG68PFf = str(int(CJhkXv1j0M,oVwa0kcqxj1e7mLplAfZdGT(u"࠴࠺໱")))
			except: pass
		if J9xAHQEXz80PMwkW and LEVUxS2Zj5H6CsrRNaimz and ngoY1Qm7z4hB3bJvUsG68PFf: break
	zKO1XDym86Md2 = [LEVUxS2Zj5H6CsrRNaimz,J9xAHQEXz80PMwkW,ngoY1Qm7z4hB3bJvUsG68PFf,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭ඨ")]
	if QVKeCkS0sb8POThNiU or pOoVJZDrxPGRbBw1UzXQ0t9qS:
		C7R1SafVk5vo6Lj2ibBTgXuWZ8Y = [(kK7gj9HE462hADJbvr,QVKeCkS0sb8POThNiU),(tBMCpcY2vUV1dEjZ7PDG,pOoVJZDrxPGRbBw1UzXQ0t9qS)]
		for XuhpgCFwT9RcZe8Yta5,ueLNQY06r4zt3qk in C7R1SafVk5vo6Lj2ibBTgXuWZ8Y:
			ueLNQY06r4zt3qk = ueLNQY06r4zt3qk.strip(qeG16a4pbSHziNVQ2uFXrs(u"ࠫ࠵࠭ඩ"))
			if ueLNQY06r4zt3qk:
				if I5VKjrFL0Bk97: ueLNQY06r4zt3qk = ueLNQY06r4zt3qk.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				ueLNQY06r4zt3qk = str(int(O2QkHmVIjxELq.md5(ueLNQY06r4zt3qk).hexdigest(),aYH620Dh48GEsTFfOBSQ7r(u"࠷࠻໲")))
				d0j4hSpTDs = [int(ueLNQY06r4zt3qk[Ms2VgLeNSijxnFCw4JW:Ms2VgLeNSijxnFCw4JW+Js61GTdX5wzMurUqi7Z(u"࠶࠻໳")]) for Ms2VgLeNSijxnFCw4JW in range(len(ueLNQY06r4zt3qk)) if Ms2VgLeNSijxnFCw4JW%Js61GTdX5wzMurUqi7Z(u"࠶࠻໳")==BewrUo9ANCa17G43Sn0LH5xh]
				zKO1XDym86Md2[XuhpgCFwT9RcZe8Yta5-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = str(sum(d0j4hSpTDs))
	W8bymBGDL0TKtlA46o7Y2,TSkEe9yqPbtBR15Mgi3KIC = [],lvzrYTpcBaK
	for sQMtEJYDbLHGOX56P0zNiw,d0j4hSpTDs in enumerate(zKO1XDym86Md2):
		if not d0j4hSpTDs: continue
		if TSkEe9yqPbtBR15Mgi3KIC and d0j4hSpTDs==zKO1XDym86Md2[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]: continue
		TSkEe9yqPbtBR15Mgi3KIC = ndkUxG9LtewJ
		d0j4hSpTDs = qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࠶ࠧඪ")*aaRe85jDnZKfx7E+d0j4hSpTDs
		d0j4hSpTDs = d0j4hSpTDs[-aaRe85jDnZKfx7E:]
		LLvZHuQKza0,OVMIwuacvNqS13PJjXrAG = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		VgnM06SjH8sCRzK5TLbqWy = str(int(GVurlv8HeoXEzPRiQB7Ty(u"࠭࠹ࠨණ")*(aaRe85jDnZKfx7E+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))-int(d0j4hSpTDs))[-aaRe85jDnZKfx7E:]
		for dAukY5fr20HZDntgKLi in list(range(BewrUo9ANCa17G43Sn0LH5xh,aaRe85jDnZKfx7E,kK7gj9HE462hADJbvr)):
			LLvZHuQKza0 += VgnM06SjH8sCRzK5TLbqWy[dAukY5fr20HZDntgKLi:dAukY5fr20HZDntgKLi+kK7gj9HE462hADJbvr]+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧ࠮ࠩඬ")
			OVMIwuacvNqS13PJjXrAG += str(sum(map(int,d0j4hSpTDs[dAukY5fr20HZDntgKLi:dAukY5fr20HZDntgKLi+kK7gj9HE462hADJbvr]))%wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠷࠰໴"))
		cQlZh3kA0Lwoz9stXWHu8dK65U7C2a = str(sQMtEJYDbLHGOX56P0zNiw)+LLvZHuQKza0+OVMIwuacvNqS13PJjXrAG
		W8bymBGDL0TKtlA46o7Y2.append(cQlZh3kA0Lwoz9stXWHu8dK65U7C2a)
	s3vfIkhcXT8e,L8w3sZbMmtKDV1dSTOY7G = [],[]
	for user in W8bymBGDL0TKtlA46o7Y2:
		count = str(str(W8bymBGDL0TKtlA46o7Y2).count(user[fvYGxnZNUiyP4HJkMIoS25(u"࠱໵"):]))
		s3vfIkhcXT8e.append(count+user)
	s3vfIkhcXT8e = sorted(s3vfIkhcXT8e,reverse=ndkUxG9LtewJ,key=lambda key: key[BewrUo9ANCa17G43Sn0LH5xh])
	for user in s3vfIkhcXT8e: L8w3sZbMmtKDV1dSTOY7G.append(user[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:])
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,RDwahqjPfbdyEiTtnLQu(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫත"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨථ"),[xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS],NjPWfJS7CUoTsz4lKk0hg)
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ද"),EJgYdjbIiWe1apkQlZcR42(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩධ"),[L8w3sZbMmtKDV1dSTOY7G,xDJtcgz9NiQvkLG1sn4weyZ7uXE,QVKeCkS0sb8POThNiU,pOoVJZDrxPGRbBw1UzXQ0t9qS],NjPWfJS7CUoTsz4lKk0hg)
	for user in Q1siCkTZyw.BADCOMMONIDS:
		if user in L8w3sZbMmtKDV1dSTOY7G: L8w3sZbMmtKDV1dSTOY7G.remove(user)
	srUCekDRHJw0ibglXOhBo2tE = slFfrUIWCowaBA7tce3iZbj8xn.join(L8w3sZbMmtKDV1dSTOY7G)
	return srUCekDRHJw0ibglXOhBo2tE
def LgtBusqR8fAX7():
	global J9xAHQEXz80PMwkW
	try:
		import getmac82 as LvBh5z30Pp7tCMYEZcay1
		Pl1Lem8CRo = LvBh5z30Pp7tCMYEZcay1.get_mac_address()
		if Pl1Lem8CRo.count(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡀࠧන"))==tBMCpcY2vUV1dEjZ7PDG and Pl1Lem8CRo.count(RDwahqjPfbdyEiTtnLQu(u"࠭࠰ࠨ඲"))<aenpKvQCGVzhLXEdWiDIZ(u"࠺໶"):
			Pl1Lem8CRo = Pl1Lem8CRo.lower().replace(qeG16a4pbSHziNVQ2uFXrs(u"ࠧ࠻ࠩඳ"),sCHVtMAvqirbQ4BUK3cgWo)
			J9xAHQEXz80PMwkW = str(int(Pl1Lem8CRo,SE97R3Dpj6dPLweVKU(u"࠳࠹໷")))
	except: pass
	return
def mmOyn2bkIYsq0aJQrh7():
	global LEVUxS2Zj5H6CsrRNaimz
	try:
		import getmac95 as SP3xXJB1UF92VNYW
		LMfOb8dI7KlovEDkNugt5U = SP3xXJB1UF92VNYW.get_mac_address()
		if LMfOb8dI7KlovEDkNugt5U.count(BWfpRku7SsM6cbE0eG(u"ࠨ࠼ࠪප"))==tBMCpcY2vUV1dEjZ7PDG and LMfOb8dI7KlovEDkNugt5U.count(fvYGxnZNUiyP4HJkMIoS25(u"ࠩ࠳ࠫඵ"))<aYH620Dh48GEsTFfOBSQ7r(u"࠼໸"):
			LMfOb8dI7KlovEDkNugt5U = LMfOb8dI7KlovEDkNugt5U.lower().replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪ࠾ࠬබ"),sCHVtMAvqirbQ4BUK3cgWo)
			LEVUxS2Zj5H6CsrRNaimz = str(int(LMfOb8dI7KlovEDkNugt5U,fvYGxnZNUiyP4HJkMIoS25(u"࠵࠻໹")))
	except: pass
	return
def oTwfq964iZjEhD0(ScEpZwINx93VJ5aWfb4,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,CXTZu2YvNpEPkinLf8Ohlm3Rg):
	for hpwzbO1JuTc in iSlmE0M1pBkwuq9D8CWtOrAK:
		if hpwzbO1JuTc in ZvWwXBJxzk3Qi9uAHKTD8hY2: ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(hpwzbO1JuTc,sCHVtMAvqirbQ4BUK3cgWo)
		if hpwzbO1JuTc in u0K219wAgLr8TXDcVGsqQPtRkCH6ov: u0K219wAgLr8TXDcVGsqQPtRkCH6ov = u0K219wAgLr8TXDcVGsqQPtRkCH6ov.replace(hpwzbO1JuTc,sCHVtMAvqirbQ4BUK3cgWo)
	HSNYwERMjzyxmrPku = str(u0K219wAgLr8TXDcVGsqQPtRkCH6ov)[BewrUo9ANCa17G43Sn0LH5xh:XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠷࠻࠰໺")].replace(slFfrUIWCowaBA7tce3iZbj8xn,RDwahqjPfbdyEiTtnLQu(u"ࠫࡡࡢ࡮ࠨභ")).replace(f6fsIXQonhvcGg1p,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡢ࡜ࡳࠩම")).replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT)
	if len(str(u0K219wAgLr8TXDcVGsqQPtRkCH6ov))>qqw1upCsKM(u"࠸࠵࠱໻"): HSNYwERMjzyxmrPku = HSNYwERMjzyxmrPku+SIkwCEdJHTD9v1(u"࠭ࠠ࠯࠰࠱ࠫඹ")
	i68iPmaHVAZknGv2SNpyzCwcFE = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࠯࠰࠱ࠫය")
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࠪර")+ScEpZwINx93VJ5aWfb4+TzIj50KpohEOHx6CbZWqB(u"ࠩࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ඼")+ZvWwXBJxzk3Qi9uAHKTD8hY2+Js61GTdX5wzMurUqi7Z(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬල")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+EJgYdjbIiWe1apkQlZcR42(u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭඾")+CXTZu2YvNpEPkinLf8Ohlm3Rg+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ඿")+str(HSNYwERMjzyxmrPku)+aenpKvQCGVzhLXEdWiDIZ(u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭ව")+i68iPmaHVAZknGv2SNpyzCwcFE+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࠡ࡟ࠪශ"))
	return
def mpfNBWFjnzLs(CXTZu2YvNpEPkinLf8Ohlm3Rg,UJNQY1RuL8tFSEwWahpV6,gWlmUqwV3YrIT2XNPxQCisBHSDG9=sCHVtMAvqirbQ4BUK3cgWo,u0K219wAgLr8TXDcVGsqQPtRkCH6ov=sCHVtMAvqirbQ4BUK3cgWo,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=sCHVtMAvqirbQ4BUK3cgWo):
	if I5VKjrFL0Bk97: import urllib.request as VqrUb0FmlfZcI2C9
	else: import urllib2 as VqrUb0FmlfZcI2C9
	if not u0K219wAgLr8TXDcVGsqQPtRkCH6ov: u0K219wAgLr8TXDcVGsqQPtRkCH6ov = {hPFcB6Uxmabj59Iq(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬෂ"):sCHVtMAvqirbQ4BUK3cgWo}
	if not gWlmUqwV3YrIT2XNPxQCisBHSDG9: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = {}
	PnhUdWqRNyv52MzoujXO1F = gWlmUqwV3YrIT2XNPxQCisBHSDG9
	HgSYTMciDE4j0sW3f8nX6xm = UJNQY1RuL8tFSEwWahpV6 in Q1siCkTZyw.SITESURLS[TzIj50KpohEOHx6CbZWqB(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩස")]
	if HgSYTMciDE4j0sW3f8nX6xm:
		CXTZu2YvNpEPkinLf8Ohlm3Rg = YQNd4wejLSAVJ6T(u"ࠪࡔࡔ࡙ࡔࠨහ")
		u0K219wAgLr8TXDcVGsqQPtRkCH6ov[gDETKVh8mZe09Nd(u"ࠫࡆ࡜࠭ࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࠫළ")] = zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠱࠯࠲ࠪෆ")
		Ar3d1e0wLo85OUQTuBmR6kV = Kdnrl9JHV0cFaGzC5bN.dumps(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		import CCKRSEkHBw
		PnhUdWqRNyv52MzoujXO1F = CCKRSEkHBw.MLSsdPul803Tn4WBeGkZp6aQc(Ar3d1e0wLo85OUQTuBmR6kV,SE97R3Dpj6dPLweVKU(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷໼"))
		UJNQY1RuL8tFSEwWahpV6 = UJNQY1RuL8tFSEwWahpV6+bGzRdmOErkIylxALniq6(u"࠭࠿ࡶࡵࡨࡶࡂ࠭෇")+IRqQOePKNclx1td
	elif CXTZu2YvNpEPkinLf8Ohlm3Rg==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡈࡇࡗࠫ෈"):
		UJNQY1RuL8tFSEwWahpV6 = ZvWwXBJxzk3Qi9uAHKTD8hY2+gDETKVh8mZe09Nd(u"ࠨࡁࠪ෉")+JePn6VTBrLMDmsCzX(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		PnhUdWqRNyv52MzoujXO1F = ZetiSjBQ9bTnF23pzsmXcyWuK
	elif CXTZu2YvNpEPkinLf8Ohlm3Rg==oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡓࡓࡘ්࡚ࠧ") and oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ࡮ࡸࡵ࡮ࠨ෋") in str(u0K219wAgLr8TXDcVGsqQPtRkCH6ov):
		gWlmUqwV3YrIT2XNPxQCisBHSDG9 = Kdnrl9JHV0cFaGzC5bN.dumps(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		PnhUdWqRNyv52MzoujXO1F = str(gWlmUqwV3YrIT2XNPxQCisBHSDG9).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	elif CXTZu2YvNpEPkinLf8Ohlm3Rg==TzIj50KpohEOHx6CbZWqB(u"ࠫࡕࡕࡓࡕࠩ෌"):
		gWlmUqwV3YrIT2XNPxQCisBHSDG9 = JePn6VTBrLMDmsCzX(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		PnhUdWqRNyv52MzoujXO1F = gWlmUqwV3YrIT2XNPxQCisBHSDG9.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	oTwfq964iZjEhD0(sH6BOz5wKRFcEg(u"࡛ࠬࡒࡍࡎࡌࡆࡡࡺ࡜ࡵࡑࡓࡉࡓࡥࡕࡓࡎࠪ෍"),UJNQY1RuL8tFSEwWahpV6,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,CXTZu2YvNpEPkinLf8Ohlm3Rg)
	try:
		xxg2MYuSkc0QWCJ4bKlHveEB = VqrUb0FmlfZcI2C9.Request(UJNQY1RuL8tFSEwWahpV6,headers=u0K219wAgLr8TXDcVGsqQPtRkCH6ov,data=PnhUdWqRNyv52MzoujXO1F)
		mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = VqrUb0FmlfZcI2C9.urlopen(xxg2MYuSkc0QWCJ4bKlHveEB)
		CCfbK58TvPGXn0 = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.read()
		ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN = SE97R3Dpj6dPLweVKU(u"࠳࠲࠳໽"),IOHSz7YPF9WusGgUt1Dq(u"࠭ࡏࡌࠩ෎")
	except:
		CCfbK58TvPGXn0 = sCHVtMAvqirbQ4BUK3cgWo
		ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,SE97R3Dpj6dPLweVKU(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸࠧා")
	try:
		if HgSYTMciDE4j0sW3f8nX6xm and CCfbK58TvPGXn0:
			fK940diGVI6b = {StN8fF7ynudQqDbYmV4EJX.lower(): I3qosYg7HjWda1uEJexb0wOPhlFn8B for StN8fF7ynudQqDbYmV4EJX, I3qosYg7HjWda1uEJexb0wOPhlFn8B in mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers.items()}
			if fK940diGVI6b.get(sH6BOz5wKRFcEg(u"ࠨࡣࡹ࠱ࡪࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠨැ"))==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࡙ࠩࡩࡷࡹࡩࡰࡰࠣ࠵࠳࠶ࠧෑ"):
				CCfbK58TvPGXn0,ENvtPw6MZKm9g = CCKRSEkHBw.EBA1sh2eDxfKZ(CCfbK58TvPGXn0,SE97R3Dpj6dPLweVKU(u"࠺࠴࠶࠼࠺࠹࠴࠷࠹໾"))
				if ENvtPw6MZKm9g==E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡍࡓ࡜ࡁࡍࡋࡇࡣ࡙ࡏࡍࡆࡕࡗࡅࡒࡖࠧි"):
					j7CADXI1yWt90Gc52HrsUhKeN,ltE6Cgu1AyjR8Dde = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡎࡴࡶࡢ࡮࡬ࡨࠥࡇࡐࡊࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࠬී"),-tBMCpcY2vUV1dEjZ7PDG
					CCfbK58TvPGXn0 = j7CADXI1yWt90Gc52HrsUhKeN
	except: CCfbK58TvPGXn0 = sCHVtMAvqirbQ4BUK3cgWo
	if I5VKjrFL0Bk97 and isinstance(CCfbK58TvPGXn0,bytes): CCfbK58TvPGXn0 = CCfbK58TvPGXn0.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇࡢࡴ࡝ࡶࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧු")+str(ltE6Cgu1AyjR8Dde)+Js61GTdX5wzMurUqi7Z(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ෕")+j7CADXI1yWt90Gc52HrsUhKeN+oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩූ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ෗")+UJNQY1RuL8tFSEwWahpV6+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࠣࡡࠬෘ"))
	return CCfbK58TvPGXn0
def deIJ3zjs7yKh0rn5O6clgmZ2(KkoZOFLJy3RNvjD05lrMYmg):
	OAxkrZ0Du45YKXSt9Pl2Wj = str(VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.randrange(sH6BOz5wKRFcEg(u"࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱໿"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺ༀ")))
	DIFmgPZVM6b79G4hlH = {
		XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦෙ"):IRqQOePKNclx1td,
		IO7k2hZXSz(u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣේ"):str(A4AOrGi8QL),
		t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥෛ"):WHzJr591Ka8gRdbiLmBp0hT3S,
		GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡤࡦࡸ࡬ࡧࡪࡥࡦࡢ࡯࡬ࡰࡾࠨො"):WHzJr591Ka8gRdbiLmBp0hT3S,
		TzIj50KpohEOHx6CbZWqB(u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤෝ"): WHzJr591Ka8gRdbiLmBp0hT3S,
		XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠣࡥࡤࡶࡷ࡯ࡥࡳࠤෞ"):GVurlv8HeoXEzPRiQB7Ty(u"ࠤࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࠤෟ"),
		aenpKvQCGVzhLXEdWiDIZ(u"ࠥ࡭ࡵࠨ෠"): bGzRdmOErkIylxALniq6(u"ࠦࠩࡸࡥ࡮ࡱࡷࡩࠧ෡"),
		E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࠪࡳ࡬࡫ࡳࡣࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࡥࡳࡺࡰࡦࠦ෢"):lvzrYTpcBaK
	}
	Kzg01kvpPudQ7AWEmjIaxoF = []
	for J0FI8ovETc4iqelhzpjR2XSY7DBPHd in KkoZOFLJy3RNvjD05lrMYmg:
		Uypv0Wze2S9T1mdRKoMDw4k7EqG8L = DIFmgPZVM6b79G4hlH.copy()
		Uypv0Wze2S9T1mdRKoMDw4k7EqG8L[XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ෣")] = J0FI8ovETc4iqelhzpjR2XSY7DBPHd
		Uypv0Wze2S9T1mdRKoMDw4k7EqG8L[Js61GTdX5wzMurUqi7Z(u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ෤")] = {YQNd4wejLSAVJ6T(u"ࠣࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ෥"):J0FI8ovETc4iqelhzpjR2XSY7DBPHd}
		Uypv0Wze2S9T1mdRKoMDw4k7EqG8L[aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫ෦")] = {aYH620Dh48GEsTFfOBSQ7r(u"࡙ࠥࡸ࡫ࡲࡠࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ෧"):J0FI8ovETc4iqelhzpjR2XSY7DBPHd}
		Kzg01kvpPudQ7AWEmjIaxoF.append(Uypv0Wze2S9T1mdRKoMDw4k7EqG8L)
	gWlmUqwV3YrIT2XNPxQCisBHSDG9 = {
		GVurlv8HeoXEzPRiQB7Ty(u"ࠦࡦࡶࡩࡠ࡭ࡨࡽࠧ෨"):jwzOabysh0Z(u"ࠬ࠸࠵࠵ࡦࡧ࠷ࡦ࠺࠰࠺ࡦ࠻ࡦ࠻࠾࠱ࡥ࠶ࡨ࠵࠶࠽ࡥࡦ࠹࠻ࡧࡪࡨࡦ࠳࠻ࠪ෩"),
		sH6BOz5wKRFcEg(u"ࠨࡩ࡯ࡵࡨࡶࡹࡥࡩࡥࠤ෪"):OAxkrZ0Du45YKXSt9Pl2Wj,
		Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠢࡦࡸࡨࡲࡹࡹࠢ෫"): Kzg01kvpPudQ7AWEmjIaxoF
	}
	u0K219wAgLr8TXDcVGsqQPtRkCH6ov = {XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ෬"):qqw1upCsKM(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ෭")}
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠳࠰ࡤࡱࡵࡲࡩࡵࡷࡧࡩ࠳ࡩ࡯࡮࠱࠵࠳࡭ࡺࡴࡱࡣࡳ࡭ࠬ෮")
	cIy4z8xCUt7j5MhPZO = mpfNBWFjnzLs(SIkwCEdJHTD9v1(u"ࠫࡕࡕࡓࡕࠩ෯"),ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,qqw1upCsKM(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࡙࠭࠲ࡵࡷࠫ෰"))
	return cIy4z8xCUt7j5MhPZO
def FHyPhGQ6O13K7jUeTq4WapdAVYfvX(ELcNnjip84CGbeK,TqNvzBxf1KpPDg3SRA4yj2mwcVF):
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.replace(aYH620Dh48GEsTFfOBSQ7r(u"࠭࡮ࡶ࡮࡯ࠫ෱"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡏࡱࡱࡩࠬෲ"))
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.replace(YQNd4wejLSAVJ6T(u"ࠨࡶࡵࡹࡪ࠭ෳ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩࡗࡶࡺ࡫ࠧ෴"))
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.replace(IO7k2hZXSz(u"ࠪࡪࡦࡲࡳࡦࠩ෵"),sH6BOz5wKRFcEg(u"ࠫࡋࡧ࡬ࡴࡧࠪ෶"))
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.replace(hPFcB6Uxmabj59Iq(u"ࠬࡢ࠯ࠨ෷"),IOHSz7YPF9WusGgUt1Dq(u"࠭࠯ࠨ෸"))
	try: pnXGs1DmPvYJE2SliMLB = eval(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	except: pnXGs1DmPvYJE2SliMLB = Z3ugcA9ihpqBzDJM(ELcNnjip84CGbeK)
	return pnXGs1DmPvYJE2SliMLB
def ngmFwvKdSq4lNZoITsyJ3PGE2X6u():
	ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧ෹"),zz17bL8m9dw2kIcNqR5ortGiXnKj4,fNntYJW45mEFSdRX8g.DOTALL)
	if AHhdOiGao5UZ: zz17bL8m9dw2kIcNqR5ortGiXnKj4 = zz17bL8m9dw2kIcNqR5ortGiXnKj4.split(AHhdOiGao5UZ[BewrUo9ANCa17G43Sn0LH5xh],zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	g0eU93LncmwbEDVX = hDjf1Ubgq629nXlOvcFLH4Jw.strftime(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨ෺"),hDjf1Ubgq629nXlOvcFLH4Jw.localtime(JVAlZw9Nsnj))
	zz17bL8m9dw2kIcNqR5ortGiXnKj4 = zz17bL8m9dw2kIcNqR5ortGiXnKj4+g0eU93LncmwbEDVX
	yFgOx69L2tnTUvoNu0V5ZGrkRJ = ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(nbfoUAIGjyD2PQcSJO):
		Zk4v1yYSjrp7VEHnUfzx0TO2oI = open(nbfoUAIGjyD2PQcSJO,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡵࡦࠬ෻")).read()
		if I5VKjrFL0Bk97: Zk4v1yYSjrp7VEHnUfzx0TO2oI = Zk4v1yYSjrp7VEHnUfzx0TO2oI.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		Zk4v1yYSjrp7VEHnUfzx0TO2oI = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(RDwahqjPfbdyEiTtnLQu(u"ࠪࡨ࡮ࡩࡴࠨ෼"),Zk4v1yYSjrp7VEHnUfzx0TO2oI)
	else: Zk4v1yYSjrp7VEHnUfzx0TO2oI = {}
	s1eVRLfFbycvMB = {}
	for Ikn5XPLRpb73 in list(Zk4v1yYSjrp7VEHnUfzx0TO2oI.keys()):
		if Ikn5XPLRpb73!=ScEpZwINx93VJ5aWfb4: s1eVRLfFbycvMB[Ikn5XPLRpb73] = Zk4v1yYSjrp7VEHnUfzx0TO2oI[Ikn5XPLRpb73]
		else:
			if zz17bL8m9dw2kIcNqR5ortGiXnKj4 and zz17bL8m9dw2kIcNqR5ortGiXnKj4!=GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࠳࠴ࠧ෽"):
				kKzfnM7hPmTsic0N9wOutWIS = Zk4v1yYSjrp7VEHnUfzx0TO2oI[Ikn5XPLRpb73]
				if yFgOx69L2tnTUvoNu0V5ZGrkRJ in kKzfnM7hPmTsic0N9wOutWIS:
					nTxciHKjwprDmO = kKzfnM7hPmTsic0N9wOutWIS.index(yFgOx69L2tnTUvoNu0V5ZGrkRJ)
					del kKzfnM7hPmTsic0N9wOutWIS[nTxciHKjwprDmO]
				iIdvU69jyWzCs = [yFgOx69L2tnTUvoNu0V5ZGrkRJ]+kKzfnM7hPmTsic0N9wOutWIS
				iIdvU69jyWzCs = iIdvU69jyWzCs[:bGzRdmOErkIylxALniq6(u"࠺࠶༁")]
				s1eVRLfFbycvMB[Ikn5XPLRpb73] = iIdvU69jyWzCs
			else: s1eVRLfFbycvMB[Ikn5XPLRpb73] = Zk4v1yYSjrp7VEHnUfzx0TO2oI[Ikn5XPLRpb73]
	if ScEpZwINx93VJ5aWfb4 not in list(s1eVRLfFbycvMB.keys()): s1eVRLfFbycvMB[ScEpZwINx93VJ5aWfb4] = [yFgOx69L2tnTUvoNu0V5ZGrkRJ]
	s1eVRLfFbycvMB = str(s1eVRLfFbycvMB)
	if I5VKjrFL0Bk97: s1eVRLfFbycvMB = s1eVRLfFbycvMB.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	open(nbfoUAIGjyD2PQcSJO,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡽࡢࠨ෾")).write(s1eVRLfFbycvMB)
	return
def JePn6VTBrLMDmsCzX(gWlmUqwV3YrIT2XNPxQCisBHSDG9):
	if I5VKjrFL0Bk97: import urllib.parse as ooOg8LFnj4
	else: import urllib as ooOg8LFnj4
	JYNt675KaS2qnU8pF = ooOg8LFnj4.urlencode(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
	return JYNt675KaS2qnU8pF
def CeXLtzElr5DHhs(rdQ5tOIzuelfvcYbNsM,AApqPfNKwRLY2CIdmc6zly=sCHVtMAvqirbQ4BUK3cgWo,wwRALzTk89gKGqsZ=sCHVtMAvqirbQ4BUK3cgWo):
	jB60op5V1XwCvxhHOGk = AApqPfNKwRLY2CIdmc6zly not in [GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡍ࠴ࡗࠪ෿"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡊࡒࡗ࡚ࠬ฀")]
	if not wwRALzTk89gKGqsZ: wwRALzTk89gKGqsZ = zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡸ࡬ࡨࡪࡵࠧก")
	A9bvplQ5GH4uI,yurvfKe5UXVBwaj0D26oJh4xZY7lIg,yBXqH1SW6M0gsfKAdc8GDrFUmo = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫข"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if len(rdQ5tOIzuelfvcYbNsM)==vUnJhT2NO8yirHcAmg:
		ZvWwXBJxzk3Qi9uAHKTD8hY2,S0VpDiU7zXOsZMkfblNuc,yBXqH1SW6M0gsfKAdc8GDrFUmo = rdQ5tOIzuelfvcYbNsM
		if S0VpDiU7zXOsZMkfblNuc: yurvfKe5UXVBwaj0D26oJh4xZY7lIg = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻ࠢ࡞ࠤࠬฃ")+S0VpDiU7zXOsZMkfblNuc+YQNd4wejLSAVJ6T(u"ࠫࠥࡣࠧค")
	else: ZvWwXBJxzk3Qi9uAHKTD8hY2,S0VpDiU7zXOsZMkfblNuc,yBXqH1SW6M0gsfKAdc8GDrFUmo = rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࠫ࠲࠱ࠩฅ"),AAh0X3OCacr4HpifRGLZKT)
	m3URNoVvLS6F = FA0Y1k9va5O2zmU6By(ZvWwXBJxzk3Qi9uAHKTD8hY2)
	if AApqPfNKwRLY2CIdmc6zly not in [XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨฆ"),bGzRdmOErkIylxALniq6(u"ࠧࡊࡒࡗ࡚ࠬง")]:
		if AApqPfNKwRLY2CIdmc6zly!=RDwahqjPfbdyEiTtnLQu(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪจ"): ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(AAh0X3OCacr4HpifRGLZKT,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࠨ࠶࠵࠭ฉ"))
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩช")+ZvWwXBJxzk3Qi9uAHKTD8hY2+SIkwCEdJHTD9v1(u"ࠫࠥࡣࠧซ")+yurvfKe5UXVBwaj0D26oJh4xZY7lIg)
		if m3URNoVvLS6F==aYH620Dh48GEsTFfOBSQ7r(u"ࠬ࠴࡭࠴ࡷ࠻ࠫฌ") and AApqPfNKwRLY2CIdmc6zly not in [E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡉࡑࡖ࡙ࠫญ"),BWfpRku7SsM6cbE0eG(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨฎ")]:
			import CCKRSEkHBw,tqHErj9p1I
			V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = CCKRSEkHBw.KyzU5RhvoJMQwd8j3asD(AApqPfNKwRLY2CIdmc6zly,ZvWwXBJxzk3Qi9uAHKTD8hY2)
			JZD8Wzc1MGq9fgVFI2oENX5eT = len(ss7YGDbuAIxgnqaQroTV)
			if JZD8Wzc1MGq9fgVFI2oENX5eT>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				jQLzA92KFEcpw = tqHErj9p1I.Wdlg19qZ4apQtYFCINvBeML0c(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩฏ")+str(JZD8Wzc1MGq9fgVFI2oENX5eT)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"้้ࠩࠣ็ࠩࠨฐ"), V9TdsglcWYv0X)
				if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
					tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪษ้เวยࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨฑ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡈࡧ࡮ࡤࡧ࡯ࠫฒ"))
					return A9bvplQ5GH4uI
			else: jQLzA92KFEcpw = BewrUo9ANCa17G43Sn0LH5xh
			ZvWwXBJxzk3Qi9uAHKTD8hY2 = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
			if V9TdsglcWYv0X[BewrUo9ANCa17G43Sn0LH5xh]!=TzIj50KpohEOHx6CbZWqB(u"ࠬ࠳࠱ࠨณ"):
				SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+TzIj50KpohEOHx6CbZWqB(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬด")+V9TdsglcWYv0X[jQLzA92KFEcpw]+qqw1upCsKM(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨต")+ZvWwXBJxzk3Qi9uAHKTD8hY2+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࠢࡠࠫถ"))
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪท") in ZvWwXBJxzk3Qi9uAHKTD8hY2: ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2+Js61GTdX5wzMurUqi7Z(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪธ")
		elif qeG16a4pbSHziNVQ2uFXrs(u"ࠫ࡭ࡺࡴࡱࠩน") in ZvWwXBJxzk3Qi9uAHKTD8hY2.lower() and aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬบ") not in ZvWwXBJxzk3Qi9uAHKTD8hY2 and qqw1upCsKM(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫป") not in ZvWwXBJxzk3Qi9uAHKTD8hY2:
			ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2+Js61GTdX5wzMurUqi7Z(u"ࠧࡽࠩผ") if SIkwCEdJHTD9v1(u"ࠨࡾࠪฝ") not in ZvWwXBJxzk3Qi9uAHKTD8hY2 else ZvWwXBJxzk3Qi9uAHKTD8hY2+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࠩࠫพ")
			if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨฟ") not in ZvWwXBJxzk3Qi9uAHKTD8hY2 and XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ภ") in ZvWwXBJxzk3Qi9uAHKTD8hY2.lower(): ZvWwXBJxzk3Qi9uAHKTD8hY2 += iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠧࠩม")
			if BWfpRku7SsM6cbE0eG(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡀࠫย") not in ZvWwXBJxzk3Qi9uAHKTD8hY2.lower() and AApqPfNKwRLY2CIdmc6zly not in [bGzRdmOErkIylxALniq6(u"ࠧࡊࡒࡗ࡚ࠬร"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡏ࠶࡙ࠬฤ")]: ZvWwXBJxzk3Qi9uAHKTD8hY2 += TzIj50KpohEOHx6CbZWqB(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨล")
			if YQNd4wejLSAVJ6T(u"ࠪࡶࡪ࡬ࡥࡳࡧࡵࡁࠬฦ") not in ZvWwXBJxzk3Qi9uAHKTD8hY2.lower(): ZvWwXBJxzk3Qi9uAHKTD8hY2 += E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲࠩࠫว")
			if jwzOabysh0Z(u"ࠬࡧࡣࡤࡧࡳࡸ࠲ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠽ࠨศ") not in ZvWwXBJxzk3Qi9uAHKTD8hY2.lower(): ZvWwXBJxzk3Qi9uAHKTD8hY2 += phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠰ࡦࡸ࠻ࡲ࠿࠳࠲࠾ࠬࠧษ")
	SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+IOHSz7YPF9WusGgUt1Dq(u"ࠧࠡࠢࠣࡋࡴࡺࠠࡧ࡫ࡱࡥࡱࠦࡵࡳ࡮ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨส")+ZvWwXBJxzk3Qi9uAHKTD8hY2+qqw1upCsKM(u"ࠨࠢࡠࠫห"))
	JO0zVATClpYK3WHh5ywG9faL28btS = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ListItem()
	wwRALzTk89gKGqsZ,qqk7Fgcdxl6DW9KARr3XO,bHQ2jlVsNGdkXx,a9lewTLUIoWC5,tDnaQez4Sugsimf9TGvpP,u8Pi3ZV2vQGfm,v1vsUdVLNe7SqERy48trJZhP9f,btpnEkYS8OTDFKxjQgzeCX,XylSkhaf9VZEjnebv20J4MRLdWpmc = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	if AApqPfNKwRLY2CIdmc6zly not in [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫฬ"),TzIj50KpohEOHx6CbZWqB(u"ࠪࡍࡕ࡚ࡖࠨอ")]:
		if qdUK5ioJyrO1T: aaiOtTGVWcS1Yw = zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧฮ")
		else: aaiOtTGVWcS1Yw = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࠪฯ")
		JO0zVATClpYK3WHh5ywG9faL28btS.setProperty(aaiOtTGVWcS1Yw, sCHVtMAvqirbQ4BUK3cgWo)
		JO0zVATClpYK3WHh5ywG9faL28btS.setMimeType(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫะ"))
		if A4AOrGi8QL<GVurlv8HeoXEzPRiQB7Ty(u"࠸࠰༂"): JO0zVATClpYK3WHh5ywG9faL28btS.setInfo(TzIj50KpohEOHx6CbZWqB(u"ࠧࡷ࡫ࡧࡩࡴ࠭ั"),{E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫา"):phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡰࡳࡻ࡯ࡥࠨำ")})
		else:
			bqeJQUNMIR8 = JO0zVATClpYK3WHh5ywG9faL28btS.getVideoInfoTag()
			bqeJQUNMIR8.setMediaType(TzIj50KpohEOHx6CbZWqB(u"ࠪࡱࡴࡼࡩࡦࠩิ"))
		JO0zVATClpYK3WHh5ywG9faL28btS.setArt({TzIj50KpohEOHx6CbZWqB(u"ࠫࡹ࡮ࡵ࡮ࡤࠪี"):tDnaQez4Sugsimf9TGvpP,IOHSz7YPF9WusGgUt1Dq(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬึ"):tDnaQez4Sugsimf9TGvpP,sH6BOz5wKRFcEg(u"࠭ࡢࡢࡰࡱࡩࡷ࠭ื"):tDnaQez4Sugsimf9TGvpP,BWfpRku7SsM6cbE0eG(u"ࠧࡧࡣࡱࡥࡷࡺุࠧ"):tDnaQez4Sugsimf9TGvpP,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶูࠪ"):tDnaQez4Sugsimf9TGvpP,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳฺࠬ"):tDnaQez4Sugsimf9TGvpP,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭฻"):tDnaQez4Sugsimf9TGvpP,TzIj50KpohEOHx6CbZWqB(u"ࠫ࡮ࡩ࡯࡯ࠩ฼"):tDnaQez4Sugsimf9TGvpP})
		if m3URNoVvLS6F in [sH6BOz5wKRFcEg(u"ࠬ࠴࡭ࡱࡦࠪ฽"),qeG16a4pbSHziNVQ2uFXrs(u"࠭࠮࡮࠵ࡸ࠼ࠬ฾")]: JO0zVATClpYK3WHh5ywG9faL28btS.setContentLookup(ndkUxG9LtewJ)
		else: JO0zVATClpYK3WHh5ywG9faL28btS.setContentLookup(lvzrYTpcBaK)
		from i5kNU6T7vE import oodkrSivUAOcRaIZEHQx32VL7bnX
		if qqw1upCsKM(u"ࠧࡳࡶࡰࡴࠬ฿") in ZvWwXBJxzk3Qi9uAHKTD8hY2:
			oodkrSivUAOcRaIZEHQx32VL7bnX(GVurlv8HeoXEzPRiQB7Ty(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫเ"),lvzrYTpcBaK)
		elif m3URNoVvLS6F==hPFcB6Uxmabj59Iq(u"ࠩ࠱ࡱࡵࡪࠧแ") or phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪโ") in ZvWwXBJxzk3Qi9uAHKTD8hY2:
			oodkrSivUAOcRaIZEHQx32VL7bnX(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫใ"),lvzrYTpcBaK)
			JO0zVATClpYK3WHh5ywG9faL28btS.setProperty(aaiOtTGVWcS1Yw,jwzOabysh0Z(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬไ"))
			JO0zVATClpYK3WHh5ywG9faL28btS.setProperty(BWfpRku7SsM6cbE0eG(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭ๅ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࡮ࡲࡧࠫๆ"))
		if S0VpDiU7zXOsZMkfblNuc:
			JO0zVATClpYK3WHh5ywG9faL28btS.setSubtitles([S0VpDiU7zXOsZMkfblNuc])
	if wwRALzTk89gKGqsZ==hPFcB6Uxmabj59Iq(u"ࠨࡸ࡬ࡨࡪࡵࠧ็") and AApqPfNKwRLY2CIdmc6zly==SE97R3Dpj6dPLweVKU(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ่ࠫ"):
		A9bvplQ5GH4uI = BWfpRku7SsM6cbE0eG(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦ้ࠪ")
		AApqPfNKwRLY2CIdmc6zly = SE97R3Dpj6dPLweVKU(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖ๊ࠫ")
	elif wwRALzTk89gKGqsZ==YQNd4wejLSAVJ6T(u"ࠬࡼࡩࡥࡧࡲ๋ࠫ") and btpnEkYS8OTDFKxjQgzeCX.startswith(fvYGxnZNUiyP4HJkMIoS25(u"࠭࠶ࠨ์")):
		A9bvplQ5GH4uI = qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬํ")
		AApqPfNKwRLY2CIdmc6zly = AApqPfNKwRLY2CIdmc6zly+bGzRdmOErkIylxALniq6(u"ࠨࡡࡇࡐࠬ๎")
	if A9bvplQ5GH4uI!=qqw1upCsKM(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧ๏"): ngmFwvKdSq4lNZoITsyJ3PGE2X6u()
	l495HcJsCGoDM7r3xStLVF.lWmwN4ZC3Hz6AUj1BLJxOivI(AApqPfNKwRLY2CIdmc6zly)
	if l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R: return aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ๐")
	if wwRALzTk89gKGqsZ==YQNd4wejLSAVJ6T(u"ࠫࡻ࡯ࡤࡦࡱࠪ๑") and not btpnEkYS8OTDFKxjQgzeCX.startswith(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬ࠼ࠧ๒")):
		JO0zVATClpYK3WHh5ywG9faL28btS.setPath(ZvWwXBJxzk3Qi9uAHKTD8hY2)
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭๓")+ZvWwXBJxzk3Qi9uAHKTD8hY2+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠡ࡟ࠪ๔"))
		RPtvgsXL0EzbhIr.setResolvedUrl(ZWaC4pLbOV1QEMrof08eu,ndkUxG9LtewJ,JO0zVATClpYK3WHh5ywG9faL28btS)
	elif wwRALzTk89gKGqsZ==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࡮࡬ࡺࡪ࠭๕"):
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+IO7k2hZXSz(u"ࠩࠣࠤࠥࡒࡩࡷࡧࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ๖")+ZvWwXBJxzk3Qi9uAHKTD8hY2+aYH620Dh48GEsTFfOBSQ7r(u"ࠪࠤࡢ࠭๗"))
		l495HcJsCGoDM7r3xStLVF.play(ZvWwXBJxzk3Qi9uAHKTD8hY2,JO0zVATClpYK3WHh5ywG9faL28btS)
	bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	if A9bvplQ5GH4uI==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ๘"):
		from mJ8GoRh0Vl import XRKnIBMaj8gsrUYfveWp
		bEZlOa1inyrUgdTw9BKNtcMCLYI = XRKnIBMaj8gsrUYfveWp(ZvWwXBJxzk3Qi9uAHKTD8hY2,m3URNoVvLS6F,AApqPfNKwRLY2CIdmc6zly)
		if bEZlOa1inyrUgdTw9BKNtcMCLYI: ngmFwvKdSq4lNZoITsyJ3PGE2X6u()
	else:
		YNRdyxs6T5EKlf8,A9bvplQ5GH4uI,wI3xhegyTjFPcULX2ARYuBGD4bnQH,N6ID1TmrtHdQWPOj4n02uRpJAbiC,ped0bk4uyiRs = BewrUo9ANCa17G43Sn0LH5xh,TzIj50KpohEOHx6CbZWqB(u"ࠬࡺࡲࡪࡧࡧࠫ๙"),lvzrYTpcBaK,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠲࠲࠳࠴༄"),TzIj50KpohEOHx6CbZWqB(u"࠴࠶࠲࠳࠴༃")
		if jB60op5V1XwCvxhHOGk: import tqHErj9p1I
		while YNRdyxs6T5EKlf8<ped0bk4uyiRs:
			FoiwfTEhGD8ulS25HeUvnI.sleep(N6ID1TmrtHdQWPOj4n02uRpJAbiC)
			YNRdyxs6T5EKlf8 += N6ID1TmrtHdQWPOj4n02uRpJAbiC
			if l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R==t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ๚") and not wI3xhegyTjFPcULX2ARYuBGD4bnQH:
				if jB60op5V1XwCvxhHOGk: tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส๐ฬศัࠣห้็๊ะ์๋ࠫ๛"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩ๜"),hDjf1Ubgq629nXlOvcFLH4Jw=qqw1upCsKM(u"࠹࠸࠴༅"))
				SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡴࡶࡤࡶࡹ࡫ࡤ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭๝")+ZvWwXBJxzk3Qi9uAHKTD8hY2+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠤࡢ࠭๞")+yurvfKe5UXVBwaj0D26oJh4xZY7lIg)
				wI3xhegyTjFPcULX2ARYuBGD4bnQH = ndkUxG9LtewJ
			elif l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R in [aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ๟"),qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭๠")]:
				SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+aenpKvQCGVzhLXEdWiDIZ(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺ࡫ࡱ࡫ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ๡")+ZvWwXBJxzk3Qi9uAHKTD8hY2+sH6BOz5wKRFcEg(u"ࠧࠡ࡟ࠪ๢")+yurvfKe5UXVBwaj0D26oJh4xZY7lIg)
				break
			elif l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ๣"):
				SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+IO7k2hZXSz(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ๤")+ZvWwXBJxzk3Qi9uAHKTD8hY2+sH6BOz5wKRFcEg(u"ࠪࠤࡢ࠭๥")+yurvfKe5UXVBwaj0D26oJh4xZY7lIg)
				if jB60op5V1XwCvxhHOGk: tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(aYH620Dh48GEsTFfOBSQ7r(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ๦"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭๧"),hDjf1Ubgq629nXlOvcFLH4Jw=Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠺࠹࠵༆"))
				break
			elif l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R==GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ๨"):
				SH6EVn0T9d8bKCUMLl1sJOFR(oom21Pvk6Q59d,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+BWfpRku7SsM6cbE0eG(u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ๩")+ZvWwXBJxzk3Qi9uAHKTD8hY2+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࠢࡠࠫ๪"))
				break
		else: A9bvplQ5GH4uI = bGzRdmOErkIylxALniq6(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ๫")
	if A9bvplQ5GH4uI in [GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ๬")] or l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R in [bGzRdmOErkIylxALniq6(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ๭"),RDwahqjPfbdyEiTtnLQu(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭๮")] or bEZlOa1inyrUgdTw9BKNtcMCLYI: jq1yMu9V5Bt3lxh6K(AApqPfNKwRLY2CIdmc6zly)
	else: exec(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡩ࡮ࡲࡲࡶࡹࠦࡸࡣ࡯ࡦ࠿ࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫ๯"))
	sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying()
	if not sxjn4kIyMur8fw9KUTFDiB3 and A9bvplQ5GH4uI not in [IO7k2hZXSz(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬ๰")]:
		msg = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ๱") if A9bvplQ5GH4uI==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ๲") else bGzRdmOErkIylxALniq6(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ๳")
		if jB60op5V1XwCvxhHOGk: tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ๴"),msg,hDjf1Ubgq629nXlOvcFLH4Jw=SIkwCEdJHTD9v1(u"࠻࠺࠶༇"))
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࠦࠠࠡࠩ๵")+msg+SIkwCEdJHTD9v1(u"࠭࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ๶")+ZvWwXBJxzk3Qi9uAHKTD8hY2+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࠡ࡟ࠪ๷")+yurvfKe5UXVBwaj0D26oJh4xZY7lIg)
	return l495HcJsCGoDM7r3xStLVF.uQf6qJZCOzK5R
def FA0Y1k9va5O2zmU6By(ZvWwXBJxzk3Qi9uAHKTD8hY2):
	if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡁࠪ๸") in ZvWwXBJxzk3Qi9uAHKTD8hY2: ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(BWfpRku7SsM6cbE0eG(u"ࠩࡂࠫ๹"))[BewrUo9ANCa17G43Sn0LH5xh]
	if qqw1upCsKM(u"ࠪࢀࠬ๺") in ZvWwXBJxzk3Qi9uAHKTD8hY2: ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(hPFcB6Uxmabj59Iq(u"ࠫࢁ࠭๻"))[BewrUo9ANCa17G43Sn0LH5xh]
	path = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬ࠵ࠧ๼").join(ZvWwXBJxzk3Qi9uAHKTD8hY2.split(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭࠯ࠨ๽"))[qqw1upCsKM(u"࠸༈"):]) if EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠻࠱࠲ࠫ๾") in ZvWwXBJxzk3Qi9uAHKTD8hY2 else ZvWwXBJxzk3Qi9uAHKTD8hY2
	ZGSHIelLiEYb16dqJpC9uxmkBh = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠨ࡞࠱ࠬࡠࡧ࠭ࡻ࠲࠰࠽ࡢࢁ࠲࠭࠶ࢀ࠭ࠬ๿"),path,fNntYJW45mEFSdRX8g.DOTALL)
	if ZGSHIelLiEYb16dqJpC9uxmkBh:
		ZGSHIelLiEYb16dqJpC9uxmkBh = ZGSHIelLiEYb16dqJpC9uxmkBh[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		ZFxWeCnlaM1k92AgVJQwp = [zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡰ࠷ࡺ࠾ࠧ຀"),RDwahqjPfbdyEiTtnLQu(u"ࠪࡱࡵ࠺ࠧກ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡲࡶࡤࠨຂ"),BWfpRku7SsM6cbE0eG(u"ࠬࡽࡥࡣ࡯ࠪ຃"),SIkwCEdJHTD9v1(u"࠭ࡡࡷ࡫ࠪຄ"),IOHSz7YPF9WusGgUt1Dq(u"ࠧࡢࡣࡦࠫ຅"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࡯࠶ࡹࠬຆ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡰ࡯ࡻ࠭ງ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡪࡱࡼࠧຈ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡲࡶ࠳ࠨຉ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡺࡳࠨຊ")]
		if ZGSHIelLiEYb16dqJpC9uxmkBh in ZFxWeCnlaM1k92AgVJQwp: return SIkwCEdJHTD9v1(u"࠭࠮ࠨ຋")+ZGSHIelLiEYb16dqJpC9uxmkBh
	return sCHVtMAvqirbQ4BUK3cgWo
def jq1yMu9V5Bt3lxh6K(Uypv0Wze2S9T1mdRKoMDw4k7EqG8L):
	if not Q1siCkTZyw.P56VUO0NuA8bq: Uypv0Wze2S9T1mdRKoMDw4k7EqG8L += XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡠࡖࡖࠫຌ")
	Q1siCkTZyw.SEND_THESE_EVENTS.append(Uypv0Wze2S9T1mdRKoMDw4k7EqG8L)
	return
def xxpJdCwRN6SrscbOmga7h5UlHBiW(sf84PM56kOHqSW9TBCE7nR=lvzrYTpcBaK):
	bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡆࡰࡪࡧࡲࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶ࢃࡽࠨຍ"))
	M1AbKTe7LqSjw0WmGpHa3EV(sf84PM56kOHqSW9TBCE7nR,jwzOabysh0Z(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬຎ"))
	xlOFiKpdTI1Vjw5YN.exit()
def M1AbKTe7LqSjw0WmGpHa3EV(sf84PM56kOHqSW9TBCE7nR,Ro2CsQFGOj14wKIgcuHJ):
	if Ro2CsQFGOj14wKIgcuHJ:
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ຏ") in Ro2CsQFGOj14wKIgcuHJ: SH6EVn0T9d8bKCUMLl1sJOFR(sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧຐ"))
		else:
			MioQH67u51k = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ຑ"))
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(RDwahqjPfbdyEiTtnLQu(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧຒ"),sCHVtMAvqirbQ4BUK3cgWo)
			import CCKRSEkHBw
			CCKRSEkHBw.M4kqclZxfAHteyg3RF9(Ro2CsQFGOj14wKIgcuHJ)
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(SIkwCEdJHTD9v1(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨຓ"),MioQH67u51k)
	AA6xmFYBTg2kfJ0Q9t5PNrWs(TzIj50KpohEOHx6CbZWqB(u"ࠨࡵࡷࡳࡵ࠭ດ"))
	VCYw96jJq4Gk = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ຕ"))
	if VCYw96jJq4Gk==SIkwCEdJHTD9v1(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡣࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫຖ"): fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(qqw1upCsKM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨທ"),RDwahqjPfbdyEiTtnLQu(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬຘ"))
	elif VCYw96jJq4Gk==RDwahqjPfbdyEiTtnLQu(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ນ"): fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫບ"),sCHVtMAvqirbQ4BUK3cgWo)
	if fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫປ")) not in [aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡄ࡙࡙ࡕࠧຜ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡗ࡙ࡕࡐࠨຝ"),bGzRdmOErkIylxALniq6(u"ࠫࡆ࡙ࡋࠨພ")]: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Js61GTdX5wzMurUqi7Z(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨຟ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡁࡔࡍࠪຠ"))
	if fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬມ")) not in [phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡃࡘࡘࡔ࠭ຢ"),YQNd4wejLSAVJ6T(u"ࠩࡖࡘࡔࡖࠧຣ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡅࡘࡑࠧ຤")]: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(IO7k2hZXSz(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩລ"),RDwahqjPfbdyEiTtnLQu(u"ࠬࡇࡓࡌࠩ຦"))
	TAhmWVXIFszKd8H = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫວ"))
	KILF7s4vrwlacS89W = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪຨ"))
	if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧຩ") in str(KILF7s4vrwlacS89W) and TAhmWVXIFszKd8H in [aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬສ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩຫ")]:
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(IOHSz7YPF9WusGgUt1Dq(u"࠶࠮࠲࠲࠳༉"))
		FoiwfTEhGD8ulS25HeUvnI.executebuiltin(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨຬ"))
	if BewrUo9ANCa17G43Sn0LH5xh and ZWaC4pLbOV1QEMrof08eu>-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		RPtvgsXL0EzbhIr.setResolvedUrl(ZWaC4pLbOV1QEMrof08eu,lvzrYTpcBaK,qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ListItem())
		bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs = lvzrYTpcBaK,lvzrYTpcBaK,lvzrYTpcBaK
		RPtvgsXL0EzbhIr.endOfDirectory(ZWaC4pLbOV1QEMrof08eu,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs)
	if Q1siCkTZyw.SEND_THESE_EVENTS: deIJ3zjs7yKh0rn5O6clgmZ2(Q1siCkTZyw.SEND_THESE_EVENTS)
	dlEaZmbiovQ = EipOeSawWYvUZPTgf3jRrm50CV16o()
	if dlEaZmbiovQ and not Q1siCkTZyw.resolveonly:
		Q1siCkTZyw.resolveonly = ndkUxG9LtewJ
		sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying()
		if not sxjn4kIyMur8fw9KUTFDiB3: bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(SE97R3Dpj6dPLweVKU(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡃ࡭ࡧࡤࡶࠧ࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡴࡱࡧࡹ࡭࡫ࡶࡸ࡮ࡪࠢ࠻࠳ࢀࢁࠬອ"))
		else:
			QvwzPIxC3Un26G = PNBXjeMbWyGmFHrS0xOt7nuIoUAwZ()
			if QvwzPIxC3Un26G:
				import CCKRSEkHBw,tqHErj9p1I
				for dAukY5fr20HZDntgKLi in range(BewrUo9ANCa17G43Sn0LH5xh,QL2JgXnCN3Di,vUnJhT2NO8yirHcAmg):
					hDjf1Ubgq629nXlOvcFLH4Jw.sleep(vUnJhT2NO8yirHcAmg)
					sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying()
					if not sxjn4kIyMur8fw9KUTFDiB3:
						tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(aYH620Dh48GEsTFfOBSQ7r(u"࠭วๅใํำ๏๎ࠠศๆ็หา่ࠧຮ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠧฦๆ฽หฦࠦแฮืࠣหู้๊าใิหฯ࠭ຯ"),hDjf1Ubgq629nXlOvcFLH4Jw=XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠵࠱࠲༊"))
						break
				else:
					ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = g5FNRVqWzdHSAZGuoMe1YxETD3h(QvwzPIxC3Un26G)
					if not any(value in zz17bL8m9dw2kIcNqR5ortGiXnKj4 for value in CCKRSEkHBw.NOT_TO_TEST_ALL_SERVERS):
						tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨษ็ๅ๏ี๊้ࠢส่้ออใࠩະ"),sH6BOz5wKRFcEg(u"ࠩไัฺࠦฬๆ์฼ࠤฬ๊ำ๋ำไีฬะࠧັ"),hDjf1Ubgq629nXlOvcFLH4Jw=jwzOabysh0Z(u"࠸࠷࠳་"))
						hDjf1Ubgq629nXlOvcFLH4Jw.sleep(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠴༌"))
						if qdUK5ioJyrO1T:
							ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
						CCKRSEkHBw.YgJ3ybSlEOxXUL7m(VMB1l2JKvI,VMB1l2JKvI,VMB1l2JKvI)
						ka7jz96YCdTBnQOLVPuJG3285MHf = CCKRSEkHBw.Wwod49PBvQO(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
						CCKRSEkHBw.YgJ3ybSlEOxXUL7m(K3nC0rDSptmG,K3nC0rDSptmG,K3nC0rDSptmG)
						tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(IOHSz7YPF9WusGgUt1Dq(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫາ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫฬ์ส่๋ࠣๅา฻ࠠศๆึ๎ึ็ัศฬࠪຳ"),hDjf1Ubgq629nXlOvcFLH4Jw=GVurlv8HeoXEzPRiQB7Ty(u"࠺࠹࠵།"))
						sf84PM56kOHqSW9TBCE7nR = lvzrYTpcBaK
	T1AWiH6ZJ2X3Ccs = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(bGzRdmOErkIylxALniq6(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩິ"))
	if E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࠭ࠨີ") in T1AWiH6ZJ2X3Ccs:
		T1AWiH6ZJ2X3Ccs = T1AWiH6ZJ2X3Ccs.replace(Js61GTdX5wzMurUqi7Z(u"ࠧ࠮ࠩຶ"),sCHVtMAvqirbQ4BUK3cgWo)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬື"),T1AWiH6ZJ2X3Ccs)
	if sf84PM56kOHqSW9TBCE7nR: FoiwfTEhGD8ulS25HeUvnI.executebuiltin(BWfpRku7SsM6cbE0eG(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭ຸ࠭"))
	return
def PNBXjeMbWyGmFHrS0xOt7nuIoUAwZ():
	BmvE1rKwnh = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(YQNd4wejLSAVJ6T(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡌ࡫ࡴࡊࡶࡨࡱࡸࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ࠽࡟ࠧࡺࡩࡵ࡮ࡨࠦ࠱ࠨࡦࡪ࡮ࡨࠦ࠱ࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤࡠࢁ࠱ࠨࡩࡥࠤ࠽࠵ࢂູ࠭"))
	ka7jz96YCdTBnQOLVPuJG3285MHf = Kdnrl9JHV0cFaGzC5bN.loads(BmvE1rKwnh)[SE97R3Dpj6dPLweVKU(u"ࠫࡷ࡫ࡳࡶ࡮ࡷ຺ࠫ")]
	QvwzPIxC3Un26G = sCHVtMAvqirbQ4BUK3cgWo
	try: items = ka7jz96YCdTBnQOLVPuJG3285MHf[hPFcB6Uxmabj59Iq(u"ࠬ࡯ࡴࡦ࡯ࡶࠫົ")]
	except: return sCHVtMAvqirbQ4BUK3cgWo
	if items:
		for nkjHK2zQeb4vBuoaxPZTqIALW5S1,file in enumerate(items):
			path = file[zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡦࡪ࡮ࡨࠫຼ")]
			if Xkp839QMmYzrsoWTyca not in path: continue
			path = path.split(Xkp839QMmYzrsoWTyca)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
			if path==ERbOfw2FjKUAZGo: break
		count = ka7jz96YCdTBnQOLVPuJG3285MHf[Js61GTdX5wzMurUqi7Z(u"ࠧ࡭࡫ࡰ࡭ࡹࡹࠧຽ")][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡶࡲࡸࡦࡲࠧ຾")]
		if nkjHK2zQeb4vBuoaxPZTqIALW5S1+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU<count: QvwzPIxC3Un26G = items[nkjHK2zQeb4vBuoaxPZTqIALW5S1+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU][TzIj50KpohEOHx6CbZWqB(u"ࠩࡩ࡭ࡱ࡫ࠧ຿")]
	return QvwzPIxC3Un26G
def EipOeSawWYvUZPTgf3jRrm50CV16o():
	bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(qqw1upCsKM(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤࢀࢁࠬເ"))
	c7zXEldMQv6 = lvzrYTpcBaK if IOHSz7YPF9WusGgUt1Dq(u"ࠫࡠࡣࠧແ") in str(bOU4wkFLus) else ndkUxG9LtewJ
	return c7zXEldMQv6
def AA6xmFYBTg2kfJ0Q9t5PNrWs(oV35YaQKhlzFedyEXAxBkCpG):
	if Q1siCkTZyw.busydialog_active:
		if oV35YaQKhlzFedyEXAxBkCpG==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡹࡴࡰࡲࠪໂ"):
			cCgLhTmB5zS4e = SE97R3Dpj6dPLweVKU(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫໃ") if A4AOrGi8QL>t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠵࠼࠴࠹࠺༎") else XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫໄ")
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(IO7k2hZXSz(u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࠨ໅")+cCgLhTmB5zS4e+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࠬࠫໆ"))
			Q1siCkTZyw.busydialog_active = lvzrYTpcBaK
	else:
		if oV35YaQKhlzFedyEXAxBkCpG==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡷࡹࡧࡲࡵࠩ໇"):
			cCgLhTmB5zS4e = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭່ࠩ") if A4AOrGi8QL>wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠶࠽࠮࠺࠻༏") else RDwahqjPfbdyEiTtnLQu(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨ້ࠩ")
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨ໊")+cCgLhTmB5zS4e+GVurlv8HeoXEzPRiQB7Ty(u"໋ࠧࠪࠩ"))
			Q1siCkTZyw.busydialog_active = ndkUxG9LtewJ
	return
def P6q4YZs5pCFr7aiOv8mlV1UktWXISd(*args,**cTQl2aZmAUB8Ir7N91sRkpMnFoJG):
	daemon = cTQl2aZmAUB8Ir7N91sRkpMnFoJG.pop(YQNd4wejLSAVJ6T(u"ࠨࡦࡤࡩࡲࡵ࡮ࠨ໌"),lvzrYTpcBaK)
	BMscHRxPIvdGhaFZ0Vo9Er4jX = v9vwimFady3NL.Thread(*args,**cTQl2aZmAUB8Ir7N91sRkpMnFoJG)
	BMscHRxPIvdGhaFZ0Vo9Er4jX.daemon = daemon
	return BMscHRxPIvdGhaFZ0Vo9Er4jX
def qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(PRhHG8UngNFxAWQmKkp,hoVitY5TylJ7GBEIZNOQg8pukq=sCHVtMAvqirbQ4BUK3cgWo):
	if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪໍ"))
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).strip(AAh0X3OCacr4HpifRGLZKT)
	if PRhHG8UngNFxAWQmKkp: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ໎"),sCHVtMAvqirbQ4BUK3cgWo).replace(GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡢ࠭໏"),sCHVtMAvqirbQ4BUK3cgWo)
	else: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo).replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(ppPYj60nQOTlIut3X59FGZd,sCHVtMAvqirbQ4BUK3cgWo).replace(YA9GohfEca42kZOB6FN5t3y70JxMQg,sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aU23gVSeZ8QMl,sCHVtMAvqirbQ4BUK3cgWo).replace(t0ozNJUhjCVgRmMp89KGaWvfl3AS,sCHVtMAvqirbQ4BUK3cgWo)
	VSzDZiYCvW9Fyf5dtjoGpM3w = fNntYJW45mEFSdRX8g.findall(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡࠩ໐"),hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
	if VSzDZiYCvW9Fyf5dtjoGpM3w: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.split(VSzDZiYCvW9Fyf5dtjoGpM3w[BewrUo9ANCa17G43Sn0LH5xh],zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = BWfpRku7SsM6cbE0eG(u"࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩ໑")
	return hoVitY5TylJ7GBEIZNOQg8pukq
def ij3WwceDrmqafJy6Lsx4S9GCFuP(spngGR4jdhTFkJD2Sx1iva):
	R6LDWx2iFVlJUfOseSk5HyPnmIvcXg = sCHVtMAvqirbQ4BUK3cgWo.join(qT1ZRz0VMiXQhxFUPdJC2u9asvrN for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in spngGR4jdhTFkJD2Sx1iva if qT1ZRz0VMiXQhxFUPdJC2u9asvrN not in aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࡝࠱ࠥ࠾࠯ࡅ࠼࠿ࡾࠪ໒")+zzXbKjEJ47ysUgH2LPl3dnt)
	return R6LDWx2iFVlJUfOseSk5HyPnmIvcXg
W8bymBGDL0TKtlA46o7Y2 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨ࡮࡬ࡷࡹ࠭໓"),hPFcB6Uxmabj59Iq(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ໔"),RDwahqjPfbdyEiTtnLQu(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨ໕"))
if W8bymBGDL0TKtlA46o7Y2:
	L8w3sZbMmtKDV1dSTOY7G,ZkI3OjwHXWTgv1,TnU3cSxmM0lZCpG,HmvrGxWA4U6Dg = W8bymBGDL0TKtlA46o7Y2
	Q1siCkTZyw.AV_CLIENT_IDS = slFfrUIWCowaBA7tce3iZbj8xn.join(L8w3sZbMmtKDV1dSTOY7G)
if not Q1siCkTZyw.AV_CLIENT_IDS: Q1siCkTZyw.AV_CLIENT_IDS = CCKuzJQIRvg()
l495HcJsCGoDM7r3xStLVF = HMzjup1gByIwG()
Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc,Q1siCkTZyw.P56VUO0NuA8bq,Q1siCkTZyw.sIS7FqTadm3ZEJpg4G,Q1siCkTZyw.hc1vNqbTWYrBo69ynVau4QRHs,Q1siCkTZyw.avprivsnorestrict,Q1siCkTZyw.avprivslongperiod = MN3T7mznDkdF([EJgYdjbIiWe1apkQlZcR42(u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ໖"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭໗"),hPFcB6Uxmabj59Iq(u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡖࡔ࡙ࡒ࡚࡙ࡕ࠶ࡊ࡛ࠫ໘"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ໙"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡭࡯ࡈ࡛ࡋࡖࡆ࡚ࠪ໚"),jwzOabysh0Z(u"ࠩࡐࡘ࠵࠻ࡈ࡙࠲࡯ࡘ࡙ࡋࡆࡏࡕࡘࡒ࡫࡛ࡅࡗࡕࡖ࡙࠾ࡋࡘࠨ໛")])
IRqQOePKNclx1td = Q1siCkTZyw.AV_CLIENT_IDS.splitlines()[BewrUo9ANCa17G43Sn0LH5xh][-jwzOabysh0Z(u"࠸࠴༐"):]
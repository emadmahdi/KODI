# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FASELHD2'
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
Z0BYJQghVL1v87CAem = '_FH2_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][BewrUo9ANCa17G43Sn0LH5xh]
MqARWHDkmiT4nlz = ['FaselHD']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==590: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==591: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==592: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==593: ka7jz96YCdTBnQOLVPuJG3285MHf = kAUpK78mJRgoWZQytrNXeh5xf3v(url,text)
	elif mode==599: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	aeBQsh4fzLr8XM5xou1gcyE = gAVl1vUmus8
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',aeBQsh4fzLr8XM5xou1gcyE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD2-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',aeBQsh4fzLr8XM5xou1gcyE,599,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	items = fNntYJW45mEFSdRX8g.findall('<h3>(.*?)<.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	nkjHK2zQeb4vBuoaxPZTqIALW5S1 = BewrUo9ANCa17G43Sn0LH5xh
	for title,B17r2fdFy9ns8tiOMLu in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if any(value in title for value in MqARWHDkmiT4nlz): continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,591,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured'+str(nkjHK2zQeb4vBuoaxPZTqIALW5S1))
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"main-menu"(.*?)</nav>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		T490LUzt3RyObrnIoVjPFAmYZf = fNntYJW45mEFSdRX8g.findall('<li (.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for qsPRMmI7pHU2Ax4b98GgBTv in T490LUzt3RyObrnIoVjPFAmYZf:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',qsPRMmI7pHU2Ax4b98GgBTv,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,591)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,Ffh8yTQ3d6sp=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD2-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = []
	if 'featured' in Ffh8yTQ3d6sp:
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = Ffh8yTQ3d6sp[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"boxes--holder"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[int(nkjHK2zQeb4vBuoaxPZTqIALW5S1)]
	elif Ffh8yTQ3d6sp=='filters':
		oPnz7Zt4xLHTwR = [Sw0pOFoVhPeIxbl.replace('\\/','/').replace('\\"','"')]
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"boxes--holder"(.*?)"pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
	if not items: items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		try: title = title.encode(sfaeVtLiZh3xYJ9P).decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		except: pass
		title = tt36wUe4HTPFmfs5hcbr(title)
		if any(value in title.lower() for value in MqARWHDkmiT4nlz): continue
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if '/movseries/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,591,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU:
			title = '_MOD_'+bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,593,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif any(value in title for value in chRY3biUoxnVltIk): XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,592,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,593,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if Ffh8yTQ3d6sp=='filters':
		Djhn7VkYUeNaz = fNntYJW45mEFSdRX8g.findall('"more_button_page":(.*?),',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if Djhn7VkYUeNaz:
			count = Djhn7VkYUeNaz[0]
			B17r2fdFy9ns8tiOMLu = url+'/offset/'+count
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة أخرى',B17r2fdFy9ns8tiOMLu,591,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
	elif 'featured' not in Ffh8yTQ3d6sp:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = 'صفحة '+tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,591,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'details4')
	return
def kAUpK78mJRgoWZQytrNXeh5xf3v(url,data=sCHVtMAvqirbQ4BUK3cgWo):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD2-SEASONS_EPISODES-1st')
		Sw0pOFoVhPeIxbl = '"EpisodesList"'+UHqibFEGL8fjKhI.content+'</div>'
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD2-SEASONS_EPISODES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"inner--image"><img src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[BewrUo9ANCa17G43Sn0LH5xh] if Qp3jGv8leCbuiEU5Im else sCHVtMAvqirbQ4BUK3cgWo
	items = []
	if not data:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"SeasonsList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
			items = fNntYJW45mEFSdRX8g.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if len(items)>1:
				for SSyNiGLhxRXH1TzFW3DPw,Obes76wjH9LRyEqc2NWPTSphZz34K,title in items:
					B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					i68iPmaHVAZknGv2SNpyzCwcFE = 'season='+Obes76wjH9LRyEqc2NWPTSphZz34K+'&post_id='+SSyNiGLhxRXH1TzFW3DPw
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,593,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,i68iPmaHVAZknGv2SNpyzCwcFE)
			else: data = ndkUxG9LtewJ
	if data and len(items)<rgpY5VUqKbeFOCD9Nki2SmGvxEja:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"EpisodesList"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<em>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,l36lfOiDWUt9PMXHR,dwDUvp0LAuyg1rI in items:
				title = l36lfOiDWUt9PMXHR+AAh0X3OCacr4HpifRGLZKT+dwDUvp0LAuyg1rI
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,592,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	url = url.strip('/')+'/watch/'
	cb1fAztguv78n9LGhSWJFm5p,Uhsr1gY3uKa9W8N5zwPVRm6SA,sTnCDNGi3hy0W78 = [],[],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD2-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	parekFWPdl = fNntYJW45mEFSdRX8g.findall('العمر :.*?<strong">(.*?)</strong>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if parekFWPdl and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,parekFWPdl): return
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('<iframe src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named=__embed')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"main--contents"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for xpr5w6F1cy4VbSIWJMRdt,SSyNiGLhxRXH1TzFW3DPw,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+SSyNiGLhxRXH1TzFW3DPw+'&i='+xpr5w6F1cy4VbSIWJMRdt
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downloads"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name in items:
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__download')
	for KKHeUdhFn5jbykSRGIXAfm8z2lCsc in cb1fAztguv78n9LGhSWJFm5p:
		B17r2fdFy9ns8tiOMLu,name = KKHeUdhFn5jbykSRGIXAfm8z2lCsc.split('?named')
		if B17r2fdFy9ns8tiOMLu not in Uhsr1gY3uKa9W8N5zwPVRm6SA:
			Uhsr1gY3uKa9W8N5zwPVRm6SA.append(B17r2fdFy9ns8tiOMLu)
			sTnCDNGi3hy0W78.append(KKHeUdhFn5jbykSRGIXAfm8z2lCsc)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(sTnCDNGi3hy0W78,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	aeBQsh4fzLr8XM5xou1gcyE = gAVl1vUmus8
	url = aeBQsh4fzLr8XM5xou1gcyE+'/?s='+search
	fs7D0d3QyAT(url,'details5')
	return
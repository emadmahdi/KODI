# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
headers = { 'User-Agent' : sCHVtMAvqirbQ4BUK3cgWo }
Ll1m0nJoaAPvHsXqyRE = 'AKOAM'
Z0BYJQghVL1v87CAem = '_AKO_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
Z2ZIzGw9ajkVeuPST6WlK1 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==70: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==71: ka7jz96YCdTBnQOLVPuJG3285MHf = MpKIfTitvZC2YxsD(url)
	elif mode==72: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==73: ka7jz96YCdTBnQOLVPuJG3285MHf = Mcjr1E4KaVq8CZTFIkA5PYlHOUWX3(url)
	elif mode==74: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==79: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,79,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'سلسلة افلام',sCHVtMAvqirbQ4BUK3cgWo,79,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'سلسلة افلام')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'سلاسل منوعة',sCHVtMAvqirbQ4BUK3cgWo,79,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'سلسلة')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	MqARWHDkmiT4nlz = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKOAM-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="partions"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,71)
	return Sw0pOFoVhPeIxbl
def MpKIfTitvZC2YxsD(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKOAM-CATEGORIES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('sect_parts(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,72)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'جميع الفروع',url,72)
	else: fs7D0d3QyAT(url,sCHVtMAvqirbQ4BUK3cgWo)
	return
def fs7D0d3QyAT(url,type):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('section_title featured_title(.*?)subjects-crousel',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='search':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('akoam_result(.*?)<script',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='more':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('section_title more_title(.*?)footer_bottom_services',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('navigation(.*?)<script',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not items and oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		title = tt36wUe4HTPFmfs5hcbr(title)
		if any(value in title for value in Z2ZIzGw9ajkVeuPST6WlK1): XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,73,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,73,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall("</li><li >.*?href='(.*?)'>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,72,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	return
def ee9KgtfDohHOdV5S3A7wBqvJplZ(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAM-SECTIONS-2nd')
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('"href","(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[1]
	return vrEJRkchKxtDNiqO1b79mL5eT
def Mcjr1E4KaVq8CZTFIkA5PYlHOUWX3(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAM-SECTIONS-1st')
	t4tDubprC9y = fNntYJW45mEFSdRX8g.findall('"(https*://akwam.net/\w+.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	qfk4ctus7CAKNYno1 = fNntYJW45mEFSdRX8g.findall('"(https*://underurl.com/\w+.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if t4tDubprC9y or qfk4ctus7CAKNYno1:
		if t4tDubprC9y: rdQ5tOIzuelfvcYbNsM = t4tDubprC9y[0]
		elif qfk4ctus7CAKNYno1: rdQ5tOIzuelfvcYbNsM = ee9KgtfDohHOdV5S3A7wBqvJplZ(qfk4ctus7CAKNYno1[0])
		rdQ5tOIzuelfvcYbNsM = mSeoVfgRpNF9PKrJ(rdQ5tOIzuelfvcYbNsM)
		import jARZX7M1ml
		if '/series/' in rdQ5tOIzuelfvcYbNsM or '/shows/' in rdQ5tOIzuelfvcYbNsM: jARZX7M1ml.VzOBjnIkZSH7ft(rdQ5tOIzuelfvcYbNsM)
		else: jARZX7M1ml.YH54mqkD2eU06(rdQ5tOIzuelfvcYbNsM)
		return
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	items = fNntYJW45mEFSdRX8g.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,73)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR:
		iRaHzNpJhSx6ZnCfrvD7j93lks('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	name = name.strip(AAh0X3OCacr4HpifRGLZKT)
	if 'sub_epsiode_title' in Po9h3gWFuLR2:
		items = fNntYJW45mEFSdRX8g.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		OgLompvI02YSaJEljTi8BXu7hknxt1 = fNntYJW45mEFSdRX8g.findall('sub_file_title\'>(.*?) - <i>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		items = []
		for filename in OgLompvI02YSaJEljTi8BXu7hknxt1:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',sCHVtMAvqirbQ4BUK3cgWo) ]
	count = 0
	V9TdsglcWYv0X,oo7Q4BjJEXkiphVmLT3YxRMd1 = [],[]
	size = len(items)
	for title,filename in items:
		ccDFuk5NAjMTqo3hv = sCHVtMAvqirbQ4BUK3cgWo
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: ccDFuk5NAjMTqo3hv = filename.split('.')[-1]
		title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		V9TdsglcWYv0X.append(title)
		oo7Q4BjJEXkiphVmLT3YxRMd1.append(count)
		count += 1
	if size>0:
		if any(value in name for value in Z2ZIzGw9ajkVeuPST6WlK1):
			if size==1:
				jQLzA92KFEcpw = 0
			else:
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('اختر الفيديو المناسب:', V9TdsglcWYv0X)
				if jQLzA92KFEcpw == -1: return
			YH54mqkD2eU06(url+'?section='+str(1+oo7Q4BjJEXkiphVmLT3YxRMd1[size-jQLzA92KFEcpw-1]))
		else:
			for XMIo9vWSBymeLJnK6YsU in reversed(range(size)):
				title = name + ' - ' + V9TdsglcWYv0X[XMIo9vWSBymeLJnK6YsU]
				title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				B17r2fdFy9ns8tiOMLu = url + '?section='+str(size-XMIo9vWSBymeLJnK6YsU)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,74,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+'الرابط ليس فيديو',sCHVtMAvqirbQ4BUK3cgWo,9999,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	vrEJRkchKxtDNiqO1b79mL5eT,bbFPOJrmkCaE6ul37XiKU = url.split('?section=')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,True,sCHVtMAvqirbQ4BUK3cgWo,'AKOAM-PLAY_AKOAM-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	EmDNMPbur2HR9Gw0c8QO4aUXt = oPnz7Zt4xLHTwR[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	EmDNMPbur2HR9Gw0c8QO4aUXt = EmDNMPbur2HR9Gw0c8QO4aUXt + 'direct_link_box'
	Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('epsoide_box(.*?)direct_link_box',EmDNMPbur2HR9Gw0c8QO4aUXt,fNntYJW45mEFSdRX8g.DOTALL)
	bbFPOJrmkCaE6ul37XiKU = len(Jae64ky3REO57A2MvVHB90)-int(bbFPOJrmkCaE6ul37XiKU)
	Po9h3gWFuLR2 = Jae64ky3REO57A2MvVHB90[bbFPOJrmkCaE6ul37XiKU]
	cb1fAztguv78n9LGhSWJFm5p = []
	ZpoRODJzM1GSQmAY74IgB5CL8l6jNE = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = fNntYJW45mEFSdRX8g.findall("class='download_btn.*?href='(.*?)'",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu in items:
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named=________akoam')
	items = fNntYJW45mEFSdRX8g.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for TpVhjRmk3t7HWb8BgQfJc,B17r2fdFy9ns8tiOMLu in items:
		TpVhjRmk3t7HWb8BgQfJc = TpVhjRmk3t7HWb8BgQfJc.split('/')[-1]
		TpVhjRmk3t7HWb8BgQfJc = TpVhjRmk3t7HWb8BgQfJc.split('.')[0]
		if TpVhjRmk3t7HWb8BgQfJc in ZpoRODJzM1GSQmAY74IgB5CL8l6jNE:
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+ZpoRODJzM1GSQmAY74IgB5CL8l6jNE[TpVhjRmk3t7HWb8BgQfJc]+'________akoam')
		else: cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+TpVhjRmk3t7HWb8BgQfJc+'________akoam')
	if not cb1fAztguv78n9LGhSWJFm5p:
		message = fNntYJW45mEFSdRX8g.findall('sub-no-file.*?\n(.*?)\n',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if message: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'رسالة من الموقع الاصلي',message[0])
	else:
		import c27OeP8ifd
		c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	url = gAVl1vUmus8 + '/search/'+ktT4O0VJm8UaDNlxKvinoBYFgdH
	ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,'search')
	return
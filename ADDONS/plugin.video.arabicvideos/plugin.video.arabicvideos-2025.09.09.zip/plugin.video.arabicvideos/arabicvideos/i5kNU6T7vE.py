# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = gDETKVh8mZe09Nd(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ༖")
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,T67f3LG49xpP8zcN=sCHVtMAvqirbQ4BUK3cgWo):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠵ᇮ"): aSxdivqJspMnPh2oFY3t5fbuC(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IOHSz7YPF9WusGgUt1Dq(u"࠷ᇯ"): pass
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠲ᇰ"): QiGkIR6Eys(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠴ᇱ"): Yq6eVtEZr8uR5dfwkic()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==bGzRdmOErkIylxALniq6(u"࠶ᇲ"): a5a0tHPJWLQkdnz(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==EJgYdjbIiWe1apkQlZcR42(u"࠸ᇳ"): T5evpuMhmoI3y()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠺ᇴ"): OJkvd6Ir0BznNZQPTH()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==RDwahqjPfbdyEiTtnLQu(u"࠼ᇵ"): XzMkGaOSRLNVQj09yUJ()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SE97R3Dpj6dPLweVKU(u"࠾ᇶ"): mXS9ITdcatQ5N1FVj()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠱࠶࠲ᇷ"): BX1P8uClS5oftpjbmHdncN()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲࠷࠴ᇸ"): yilKW1fr6qdBwRbAsu9()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==BWfpRku7SsM6cbE0eG(u"࠳࠸࠶ᇹ"): ccgBkbWj4nyDVNLRfJI7lixs2r()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==bGzRdmOErkIylxALniq6(u"࠴࠹࠸ᇺ"): S3QYF7enwiv8yx0PV()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠵࠺࠺ᇻ"): jgkrmTetQy9PEqR5ouF8VX7wiac()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==Js61GTdX5wzMurUqi7Z(u"࠶࠻࠵ᇼ"): MMz02gPCtLQqZIRYn8aJoU7yAWSfTi()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==YQNd4wejLSAVJ6T(u"࠷࠵࠷ᇽ"): xPiDA4XUSGIOJoldyrR()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠱࠶࠹ᇾ"): U1y9eVSkA0J5Bf4Yahp()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠲࠷࠻ᇿ"): HtvG3mYIKQ9BRJFhzcXC0frjySZq()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==GVurlv8HeoXEzPRiQB7Ty(u"࠳࠸࠽ሀ"): BvrNt7VUqLnwZCYsKO3oxWeluJ(ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠴࠻࠵ሁ"): ct2pq8FlO6waebmx7TLPoi()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠵࠼࠷ሂ"): i7IW3RVZvoM4T0QXtjJlda()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IOHSz7YPF9WusGgUt1Dq(u"࠶࠽࠲ሃ"): FrMEeKQbiIup5oXG([T67f3LG49xpP8zcN],ndkUxG9LtewJ,ndkUxG9LtewJ,lvzrYTpcBaK)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==bGzRdmOErkIylxALniq6(u"࠷࠷࠴ሄ"): oodkrSivUAOcRaIZEHQx32VL7bnX(bGzRdmOErkIylxALniq6(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭༗"),ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠱࠸࠶ህ"): oodkrSivUAOcRaIZEHQx32VL7bnX(oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲ༘ࠪ"),ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IOHSz7YPF9WusGgUt1Dq(u"࠲࠹࠸ሆ"): a8FjrbdOq14t0LnNm6WY7S5lixocy()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠳࠺࠺ሇ"): psXWD1dSP0hxoBmgkCyTb7FO()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠴࠻࠼ለ"): XHLbq3IhMj9d5oTyUG7nktSY4a2(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰ༙ࠬ"))
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠵࠼࠿ሉ"): XHLbq3IhMj9d5oTyUG7nktSY4a2(YQNd4wejLSAVJ6T(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ༚"))
	elif QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠶࠿࠰ሊ"): uqkXOJBAitwLZfCoQsKPIdyV0Tj7zR()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠷࠹࠲ላ"): eeVDaAky74hHwXO9xl()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==oVwa0kcqxj1e7mLplAfZdGT(u"࠱࠺࠴ሌ"): liDPwqHeKdSzkojEUfO0A()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IO7k2hZXSz(u"࠲࠻࠶ል"): dekCi2uKQySYGnj8pV()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==Js61GTdX5wzMurUqi7Z(u"࠳࠼࠸ሎ"): xlYzAoJ1wUShHZij()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==bGzRdmOErkIylxALniq6(u"࠴࠽࠺ሏ"): Qfn18L2q56lzaUHg()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aenpKvQCGVzhLXEdWiDIZ(u"࠵࠾࠼ሐ"): TPfqCyJx6F()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aenpKvQCGVzhLXEdWiDIZ(u"࠶࠿࠷ሑ"): ihcSPjLvJTGQCV621lD0BdymRs()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==EJgYdjbIiWe1apkQlZcR42(u"࠷࠹࠹ሒ"): xqeOhgp3Ps98()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==t19ZOVHA4CpwFKaeiubcMGvz(u"࠱࠺࠻ሓ"): pesuPtSgrvoW()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==fvYGxnZNUiyP4HJkMIoS25(u"࠴࠶࠳ሔ"): CCAL6mu3SjHK(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠵࠷࠵ሕ"): os617uvdNSDGn()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠶࠸࠷ሖ"): Uva1wYqPi0C7ASB()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SE97R3Dpj6dPLweVKU(u"࠷࠹࠹ሗ"): SCMQ1zrKD60AL5uZcsT()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aenpKvQCGVzhLXEdWiDIZ(u"࠸࠺࠵መ"): Dzcs4oa0qmGI1kSiMxNd()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==RDwahqjPfbdyEiTtnLQu(u"࠹࠴࠷ሙ"): RRIKPjLqlmtoOVa6JGedr74hkc(lvzrYTpcBaK)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠳࠵࠹ሚ"): z1zgwnV9AhRXZlUePbrGp(ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠴࠶࠻ማ"): z1gHElIOi2b3Bv()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠵࠷࠽ሜ"): muQzOPIT9SeVGXxgo17i(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ༛"),ndkUxG9LtewJ,ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IOHSz7YPF9WusGgUt1Dq(u"࠸࠴࠵ም"): ds7lWCwa1iP2kuNMehE()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==hPFcB6Uxmabj59Iq(u"࠹࠵࠷ሞ"): gsBmvnw85qJ7E3PiZCA()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==hPFcB6Uxmabj59Iq(u"࠺࠶࠲ሟ"): Y1mZSo9Wuhv()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==bGzRdmOErkIylxALniq6(u"࠻࠰࠴ሠ"): tj3iXa80rd(nbfoUAIGjyD2PQcSJO)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==sH6BOz5wKRFcEg(u"࠵࠱࠶ሡ"): tj3iXa80rd(u3yGxS2mRw1fW54N7DchIvEoaq)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠶࠲࠸ሢ"): Wgb2cQE3par()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠷࠳࠺ሣ"): Hy2bntGarc7J(ndkUxG9LtewJ)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠸࠴࠼ሤ"): BBrtgDSGi8()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==jwzOabysh0Z(u"࠹࠵࠾ሥ"): yfAvIeOjC32kmcgxL()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠶࠶࠲࠱ሦ"): XXqDgPpCIlzkeGfURTyvw42EmMKSY()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==YQNd4wejLSAVJ6T(u"࠷࠰࠳࠳ሧ"): W1B93d8jg4qAmKXpFQH5o()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠱࠱࠴࠵ረ"): XHLbq3IhMj9d5oTyUG7nktSY4a2(BWfpRku7SsM6cbE0eG(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ༜"))
	elif QQ8kHjYnKEDU3sxft9S5iRoB==t19ZOVHA4CpwFKaeiubcMGvz(u"࠲࠲࠵࠷ሩ"): JvTO6dAwbmgYCZcoMBzfrKVxUq()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠳࠳࠶࠹ሪ"): BsXf0nkEaz8peqiST(ndkUxG9LtewJ)
	return
def BsXf0nkEaz8peqiST(showDialogs=lvzrYTpcBaK):
	zQl805HD2gp = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡨࡧ࡬ࡦ࠰࡮ࡩࡾࡨ࡯ࡢࡴࡧࡰࡦࡿ࡯ࡶࡶࡶࠦࢂࢃࠧ༝"))
	zQl805HD2gp = Kdnrl9JHV0cFaGzC5bN.loads(zQl805HD2gp)[t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡲࡦࡵࡸࡰࡹ࠭༞")][Js61GTdX5wzMurUqi7Z(u"ࠧࡷࡣ࡯ࡹࡪ࠭༟")]
	dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm,eqtrXuoigvUDSdAbkIBRJcjL8 = rgpY5VUqKbeFOCD9Nki2SmGvxEja,zQl805HD2gp[:]
	if showDialogs:
		s4MQr8tjRFmHaGNXnCiZuV = EJgYdjbIiWe1apkQlZcR42(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊ส่ࠢๅ฾๊ษ๊ࠡอ฽๊๊ࠧ༠") if sH6BOz5wKRFcEg(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩ༡") in zQl805HD2gp else XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ๊ะ่ใใฬࠫ༢")
		dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm = bP5mf0Mo2nz(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ༣"),IO7k2hZXSz(u"ࠬิั้ฮࠪ༤"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ล๋ไสๅࠬ༥"),SIkwCEdJHTD9v1(u"ࠧหึ฽๎้࠭༦"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,VXWOCAE6ns3paJ8DLG479NQfMu+s4MQr8tjRFmHaGNXnCiZuV+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn+slFfrUIWCowaBA7tce3iZbj8xn+EJgYdjbIiWe1apkQlZcR42(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสิ็ะࠤออำหะาห๊ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠศๆ่์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋ะࠠหีอ฻๏฿ࠠฤ่ࠣฮ฾๋ไࠡสะฯࠥ็๊ࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢหหุะฮะษ่ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ๊ࠣฮุะื๋฻ࠣว๋ࠦสไฬหࠤึูวๅห่้๋ࠣศา็ฯࠤออไๅ฼ฬࠤฬู๊าสํอࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨ༧"))
	if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==rgpY5VUqKbeFOCD9Nki2SmGvxEja and t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩ༨") not in zQl805HD2gp: eqtrXuoigvUDSdAbkIBRJcjL8 = [Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪ༩")]+zQl805HD2gp
	elif dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU and aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫ༪") in zQl805HD2gp:
		eqtrXuoigvUDSdAbkIBRJcjL8 = zQl805HD2gp[:]
		eqtrXuoigvUDSdAbkIBRJcjL8.remove(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬ༫"))
	if eqtrXuoigvUDSdAbkIBRJcjL8!=zQl805HD2gp:
		eqtrXuoigvUDSdAbkIBRJcjL8 = str(eqtrXuoigvUDSdAbkIBRJcjL8).replace(BWfpRku7SsM6cbE0eG(u"ࠨࠧࠣ༬"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࠣࠩ༭"))
		ka7jz96YCdTBnQOLVPuJG3285MHf = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡤࡣ࡯ࡩ࠳ࡱࡥࡺࡤࡲࡥࡷࡪ࡬ࡢࡻࡲࡹࡹࡹࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠪ༮")+eqtrXuoigvUDSdAbkIBRJcjL8+RDwahqjPfbdyEiTtnLQu(u"ࠩࢀࢁࠬ༯"))
		if showDialogs:
			if EJgYdjbIiWe1apkQlZcR42(u"ࠪࡸࡷࡻࡥࠨ༰") in str(ka7jz96YCdTBnQOLVPuJG3285MHf): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨ༱"))
			else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,aYH620Dh48GEsTFfOBSQ7r(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪ༲"))
	return
def JvTO6dAwbmgYCZcoMBzfrKVxUq():
	qlu4QIrH7GwzJ5LTn8jKA = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(bGzRdmOErkIylxALniq6(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ༳"))
	message = IOHSz7YPF9WusGgUt1Dq(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭༴")+str(qlu4QIrH7GwzJ5LTn8jKA)+SIkwCEdJHTD9v1(u"ࠨࠢ࡮ࡦࡵࡹ༵ࠧ") if qlu4QIrH7GwzJ5LTn8jKA else qeG16a4pbSHziNVQ2uFXrs(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨ༶")
	message = VXWOCAE6ns3paJ8DLG479NQfMu+message+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส༷ࠩ")+B8alA5nvIhTxQ
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ༸"),bGzRdmOErkIylxALniq6(u"ࠬิั้ฮ༹ࠪ"),sH6BOz5wKRFcEg(u"࠭ล๋ไสๅࠬ༺"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧหึ฽๎้࠭༻"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,message+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ࡞ࡱࡠࡳอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠥํ๊ࠡ฻่่๏ฯ๋ࠠไ๋้ࠥฮ็ศࠢส่อืๆศ็ฯࠤออฮห์สีࠥษูๅ๋ࠣะํีษࠡ็อ์ๆืษࠡๆิๆ๊ࠦวๅฮ๋ำฮࠦวๅาํࠤฬ์สࠡฬะำิํࠠโ์๋ࠣีํࠠศๆืหูฯࠠ࠯࠰ࠣ์์ึวࠡ็฼๊ฬํฺ่ࠠา้ฬࠦสใ๊่ࠤฬ์สࠡสอุ฿๐ไࠡใํำ๏๎ࠠโษ้ࠤฬ๊ศา่ส้ัࠦไ็ࠢํืศ๊ใࠡ฻้ࠤฬ๊ฬ้ัฬࠤฬ๊ส๋ࠢอี๏ี็ศࠢ็ว๋ࠦวๅสิ๊ฬ๋ฬࠡี๋ๅࠥ๐ฮหษิࠤฬ๊ฬ้ัฬࠤศ๎ส้็สฮ๏้๊ศࠢ࠱࠲ࠥ฿ไๆษࠣห๋ํ๋ࠠฮหࠤฬิส๋ษิࠤึ่ๅࠡฮ๋ำฮࠦี฻์ิࠤสึวࠡๅส๊ฯࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦศุ์ษอࠥษ่ࠡไ็๎้ฯࠧ༼"))
	if KTxQcnwvOF0pqt in [-qqw1upCsKM(u"࠴ራ"),EJgYdjbIiWe1apkQlZcR42(u"࠴ሬ")]: return
	if KTxQcnwvOF0pqt==fvYGxnZNUiyP4HJkMIoS25(u"࠶ር"):
		qlu4QIrH7GwzJ5LTn8jKA = sCHVtMAvqirbQ4BUK3cgWo
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,GVurlv8HeoXEzPRiQB7Ty(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ไสๅࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠬ༽"))
	else:
		items = [iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪ࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬ༾"),gDETKVh8mZe09Nd(u"ࠫ࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭༿"),aYH620Dh48GEsTFfOBSQ7r(u"ࠬ࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧཀ"),BWfpRku7SsM6cbE0eG(u"࠭࠱࠱࠲࠳ࠤࡰࡨࡰࡴࠩཁ"),IO7k2hZXSz(u"ࠧ࠲࠴࠸࠴ࠥࡱࡢࡱࡵࠪག"),IO7k2hZXSz(u"ࠨ࠳࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫགྷ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩ࠴࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬང"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪ࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ཅ"),BWfpRku7SsM6cbE0eG(u"ࠫ࠷࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧཆ"),TzIj50KpohEOHx6CbZWqB(u"ࠬ࠹࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཇ"),BWfpRku7SsM6cbE0eG(u"࠭࠳࠶࠲࠳ࠤࡰࡨࡰࡴࠩ཈"),gDETKVh8mZe09Nd(u"ࠧ࠵࠲࠳࠴ࠥࡱࡢࡱࡵࠪཉ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࠶࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫཊ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠩ࠸࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬཋ"),SIkwCEdJHTD9v1(u"ࠪ࠺࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ཌ"),TzIj50KpohEOHx6CbZWqB(u"ࠫ࠼࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧཌྷ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࠾࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨཎ"),aYH620Dh48GEsTFfOBSQ7r(u"࠭࠹࠱࠲࠳ࠤࡰࡨࡰࡴࠩཏ"),BWfpRku7SsM6cbE0eG(u"ࠧ࠲࠲࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫཐ"),jwzOabysh0Z(u"ࠨ࠳࠴࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬད"),SE97R3Dpj6dPLweVKU(u"ࠩ࠴࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭དྷ"),sH6BOz5wKRFcEg(u"ࠪ࠽࠾࠿࠹࠺ࠢ࡮ࡦࡵࡹࠧན")]
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(IOHSz7YPF9WusGgUt1Dq(u"ࠫฬิสาࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠢส่๊์วิสฬࠫཔ"),items)
		if jQLzA92KFEcpw==-Js61GTdX5wzMurUqi7Z(u"࠷ሮ"): return
		qlu4QIrH7GwzJ5LTn8jKA = str(items[jQLzA92KFEcpw][:-sH6BOz5wKRFcEg(u"࠵ሯ")])
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,BWfpRku7SsM6cbE0eG(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอุ฿๐ไ๊ࠡอัิ๐ฯࠡำๅ้ࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࡡࡴ࡜࡯ࠩཕ")+VXWOCAE6ns3paJ8DLG479NQfMu+qlu4QIrH7GwzJ5LTn8jKA+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࠠ࡬ࡤࡳࡷࠬབ")+B8alA5nvIhTxQ)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫབྷ"),qlu4QIrH7GwzJ5LTn8jKA)
	return
def W1B93d8jg4qAmKXpFQH5o(qZtRjimVkrx7GeUdWYOJuNn9X2=lvzrYTpcBaK):
	c7zXEldMQv6 = EipOeSawWYvUZPTgf3jRrm50CV16o()
	s4MQr8tjRFmHaGNXnCiZuV = qqw1upCsKM(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใࠢํ฽๊๊ࠧམ") if c7zXEldMQv6 else phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไ้ࠣฯ๎โโࠩཙ")
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡧࡪࡴࡴࡦࡴࠪཚ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫำื่อࠩཛ"),sH6BOz5wKRFcEg(u"ࠬห๊ใษไࠫཛྷ"),YQNd4wejLSAVJ6T(u"࠭สี฼ํ่ࠬཝ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,VXWOCAE6ns3paJ8DLG479NQfMu+s4MQr8tjRFmHaGNXnCiZuV+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn+TzIj50KpohEOHx6CbZWqB(u"่ࠧา๊ࠤฬู๊่์ไอࠥะฬฺๆࠣ็ํี๊ࠡล๋ฮํ๋วห์ๆ๎ฬ๊ࠦใ๊่ࠤอะิ฻์็ࠤฬ๊แ๋ัํ์ࠥอไๅษะๆࠥ࠴࠮ࠡว่หࠥฮูะࠢส๊ฯํวยࠢส่ๆ๐ฯ๋๊ࠣห้ำวๅ์ࠣฬศ้ๅๅ้ࠣ࠲࠳ࠦร้ࠢห฽ิࠦวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨสอษ๋ึࠥหไ๊ࠢส่้ออใࠤࠣ࠲࠳่ࠦฤ์ูห๋ࠥๅไ่ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠣห้๊วฮไࠣฬฬ๊ๆใำࠣ฽้๏ࠠำำࠣࠦส๐โศใࠣห้็๊ะ์๋ࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥอไศีอๅฬีษࠡ็้ࠤฯเ๊๋ำࠣฮึะ๊ษ่ࠢัฯ๎๊ศฬࠣห้่่ศศ่ࠤ࠳࠴้ࠠะสูฮࠦสาฬํฬࠥำไใษอࠤฬ๊ๅิๆึ่ฬะࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไ้ࠡำ๋ࠥอไฺ้ํๅฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧཞ"))
	if KTxQcnwvOF0pqt==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝ࡠࢁࢂ࠭ཟ"))
	elif KTxQcnwvOF0pqt==rgpY5VUqKbeFOCD9Nki2SmGvxEja: bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞࠵ࡢࢃࡽࠨའ"))
	if KTxQcnwvOF0pqt in [zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,rgpY5VUqKbeFOCD9Nki2SmGvxEja]:
		if IOHSz7YPF9WusGgUt1Dq(u"ࠪࡸࡷࡻࡥࠨཡ") in str(bOU4wkFLus): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,jwzOabysh0Z(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨར"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪལ"))
	return
def XXqDgPpCIlzkeGfURTyvw42EmMKSY():
	url = Q1siCkTZyw.SITESURLS[E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨཤ")][t19ZOVHA4CpwFKaeiubcMGvz(u"࠱ሰ")]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡈࡇࡗࠫཥ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭ས"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	y0k6SDdtf5PiGXEFuH = fNntYJW45mEFSdRX8g.findall(BWfpRku7SsM6cbE0eG(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࠩࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩཧ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	y0k6SDdtf5PiGXEFuH = sorted(y0k6SDdtf5PiGXEFuH,reverse=ndkUxG9LtewJ)
	jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪหำะัࠡษ็ษฺีวาࠢส่ี๐ࠠหำํำࠥะหษ์อ๋ࠬཨ"),y0k6SDdtf5PiGXEFuH)
	if jQLzA92KFEcpw>=qeG16a4pbSHziNVQ2uFXrs(u"࠲ሱ"):
		VYAdvpFMtK5wesi = url.rsplit(SIkwCEdJHTD9v1(u"ࠫ࠴࠭ཀྵ"),IO7k2hZXSz(u"࠴ሲ"))[t19ZOVHA4CpwFKaeiubcMGvz(u"࠴ሳ")]+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠭ཪ")+y0k6SDdtf5PiGXEFuH[jQLzA92KFEcpw]+EJgYdjbIiWe1apkQlZcR42(u"࠭࠮ࡻ࡫ࡳࠫཫ")
		succeeded = YYISwoJk4KhWc(RDwahqjPfbdyEiTtnLQu(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬཬ"),VYAdvpFMtK5wesi,ndkUxG9LtewJ)
		if succeeded:
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(EJgYdjbIiWe1apkQlZcR42(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ཭"),sCHVtMAvqirbQ4BUK3cgWo)
			bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qqw1upCsKM(u"ࠩอ้ࠥะหษ์อࠤส฻ฯศำࠣๆิ๐ๅࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦไไ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอะอะ์ฮࠤัฺ๋๊ࠢส่อืวๆฮࠣฬฬูสฯัส้ࠥศฮาࠢศูิอัࠡ็อ์ๆืࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ๊ิฬࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬ཮"))
			if bR4jqNrpMesHt93OgGKi6WDVaQA: muQzOPIT9SeVGXxgo17i(qqw1upCsKM(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ཯"),ndkUxG9LtewJ,ndkUxG9LtewJ)
	return
def BBrtgDSGi8():
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"ࠫ์๊ࠠหำํำࠥ็ูๅษุ้ࠣำࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣห้ิวึหࠣฬํ่สࠡฮ็ฬࠥอไหฯา๎ะอสࠡ࠰࠱ࠤ์ึวࠡษ็ุ้ำࠠิ๊ไࠤ๏ูศษࠢอัิ๐หࠡใ๋ี๏ࠦไอ็ํ฽ࠥ๎ุศศไࠤฬ๊ศา่ส้ัࠦวๅฬํࠤฯ฿สๆัࠣ฽้๏ࠠๆำ๋ีࠥ๎โห่ࠢ฽๏์ࠧ཰"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶཱࠪ"),sCHVtMAvqirbQ4BUK3cgWo)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷི࠭"),sCHVtMAvqirbQ4BUK3cgWo)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(SE97R3Dpj6dPLweVKU(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪཱིࠫ"),sCHVtMAvqirbQ4BUK3cgWo)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴུࠩ"),sCHVtMAvqirbQ4BUK3cgWo)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶཱུࠫ"),sCHVtMAvqirbQ4BUK3cgWo)
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪฮ๊ࠦๅิฯࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦวๅะสูฮࠦศ้ไอࠤั๊ศࠡษ็ฮาี๊ฬษอࠤ࠳࠴้ࠠี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬฯำฯ๋อ๋ࠣีํࠠศๆศ฽ิอฯศฬࠣ࠲࠳่ࠦฤ์ูหࠥะอะ์ฮࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦวๅ๊ๅฮࠬྲྀ"))
		Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def Wgb2cQE3par():
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,jwzOabysh0Z(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩཷ"),TzIj50KpohEOHx6CbZWqB(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨླྀ"))
	Q3KzTrUfXiFAhEGg1W72toxyIPudmp = NIEPcjs2b0YDrZ7(lvzrYTpcBaK)
	wAY6DkqRPtjH7L25W3GrinQESUh = slFfrUIWCowaBA7tce3iZbj8xn
	k0k1wfsYno6rCujDdcHTzZ = F7Fe63KbGjaz2TcmCNHPdo5QiXO+Js61GTdX5wzMurUqi7Z(u"࠭ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢࠪཹ")+B8alA5nvIhTxQ
	sL3pRmWIfAgxHCo = slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ེࠣࠫ")+B8alA5nvIhTxQ+gDETKVh8mZe09Nd(u"ࠨ࡞ࡱࡠࡳཻ࠭")
	for id,qtWgRvai4wjFumUCLMH,r1PgycpO2EHAuM,oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6,reason in reversed(Q3KzTrUfXiFAhEGg1W72toxyIPudmp):
		if id==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠳ོࠫ"):
			ss5d8hPGLTrFC4eBJmIgMvXnK3,zMPElG9TxQkZ2UXf03CDJvncR5Kgr = oAsDQxGyP2kFK7wYiIN.split(SE97R3Dpj6dPLweVKU(u"ࠪࡠࡳࡁ࠻ࠨཽ"))
			continue
		if wAY6DkqRPtjH7L25W3GrinQESUh!=slFfrUIWCowaBA7tce3iZbj8xn: wAY6DkqRPtjH7L25W3GrinQESUh += sL3pRmWIfAgxHCo
		xFNW2M6ijZbhzuoHgPC0Ba = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡠࡘࡔࡍ࡟ࠪཾ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+id+bGzRdmOErkIylxALniq6(u"ࠬࠦ࠺ࠡࠩཿ")+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭วๅีวห้ࠦ࠺ྀࠡࠩ")+B8alA5nvIhTxQ+r1PgycpO2EHAuM
		N6yp1C9H8R = YQNd4wejLSAVJ6T(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨཱྀ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨษ็ะํอศࠡ࠼ࠣࠫྂ")+B8alA5nvIhTxQ+oAsDQxGyP2kFK7wYiIN
		D6kU7MfbGhxpWgB2CzlR1cqJs0 = TzIj50KpohEOHx6CbZWqB(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨྃ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+zLjWeKu6JgNO7vocUD0Qpy(u"ࠪห้ิืฤࠢ࠽ࠤ྄ࠬ")+B8alA5nvIhTxQ+bg1dAEcph3zqxXio4eL0fQ8CJtjWu6
		W3AlVjrGIZ6Q1u2awYNPLcpRgvyX = YQNd4wejLSAVJ6T(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬ྅")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+oVwa0kcqxj1e7mLplAfZdGT(u"ࠬอไิสหࠤ࠿ࠦࠧ྆")+B8alA5nvIhTxQ+reason
		wAY6DkqRPtjH7L25W3GrinQESUh += xFNW2M6ijZbhzuoHgPC0Ba+N6yp1C9H8R+slFfrUIWCowaBA7tce3iZbj8xn+k0k1wfsYno6rCujDdcHTzZ+slFfrUIWCowaBA7tce3iZbj8xn+D6kU7MfbGhxpWgB2CzlR1cqJs0+W3AlVjrGIZ6Q1u2awYNPLcpRgvyX+slFfrUIWCowaBA7tce3iZbj8xn
	ctjhP4l8L5pbwqZuQo3VYr(SE97R3Dpj6dPLweVKU(u"࠭ࡲࡪࡩ࡫ࡸࠬ྇"),zMPElG9TxQkZ2UXf03CDJvncR5Kgr,wAY6DkqRPtjH7L25W3GrinQESUh,fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨྈ"))
	return
def tj3iXa80rd(file):
	if file==u3yGxS2mRw1fW54N7DchIvEoaq: MhgT0at2uZjKFAf5qEmlxI8D1U = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨྉ")
	elif file==nbfoUAIGjyD2PQcSJO: MhgT0at2uZjKFAf5qEmlxI8D1U = sH6BOz5wKRFcEg(u"ࠩๅ์ฬฬๅࠡฤัีࠥอไโ์า๎ํํวหࠩྊ")
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(BWfpRku7SsM6cbE0eG(u"ࠪࡧࡪࡴࡴࡦࡴࠪྋ"),EJgYdjbIiWe1apkQlZcR42(u"ู๊ࠫอࠨྌ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠬหีๅษะࠫྍ"),BWfpRku7SsM6cbE0eG(u"࠭ฮา๊ฯࠫྎ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬྏ")+MhgT0at2uZjKFAf5qEmlxI8D1U+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨྐ"))
	if KTxQcnwvOF0pqt==jwzOabysh0Z(u"࠵ሴ"):
		if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(file):
			try: YYEXZsUWhf52vz7HLxc0qGJ.remove(file)
			except: pass
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,YQNd4wejLSAVJ6T(u"ࠩอ้๋ࠥำฮ่่ࠢๆࠦࠧྑ")+MhgT0at2uZjKFAf5qEmlxI8D1U)
	elif KTxQcnwvOF0pqt==Js61GTdX5wzMurUqi7Z(u"࠷ስ"):
		data = IV2b9wBsc0SmCaUEkNDK(file)
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪྒ")+MhgT0at2uZjKFAf5qEmlxI8D1U)
	return
def gsBmvnw85qJ7E3PiZCA():
	if A4AOrGi8QL<Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠱࠹ሶ"):
		Iqm6XAWBlF = SE97R3Dpj6dPLweVKU(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧྒྷ")+str(A4AOrGi8QL)+IO7k2hZXSz(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭ྔ")
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
		return
	KILF7s4vrwlacS89W = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(RDwahqjPfbdyEiTtnLQu(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩྕ"))
	MyeJZzh0Q8RYL2U6 = nPkDNvLX7xircVpzhsGKW([EJgYdjbIiWe1apkQlZcR42(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ྖ")])
	gahvbG5HU6K2,bouwqHLYBPR,zHhnYg2u1XwbiU,EEQBpUP2sGJiOzj,g9T1HLpJAj,BBevUT9ILGQjF3yKwoO,Z4V8ucaRqo7K9mIE6O = MyeJZzh0Q8RYL2U6[IO7k2hZXSz(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧྗ")]
	if gahvbG5HU6K2 or Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ྘") not in str(KILF7s4vrwlacS89W):
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,bGzRdmOErkIylxALniq6(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨྙ"))
		bEZlOa1inyrUgdTw9BKNtcMCLYI = Y1mZSo9Wuhv()
		if not bEZlOa1inyrUgdTw9BKNtcMCLYI: return
	M2kZysTmRDFcK9ofSx(ndkUxG9LtewJ)
	return
def M2kZysTmRDFcK9ofSx(showDialogs=ndkUxG9LtewJ):
	KILF7s4vrwlacS89W = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧྚ"))
	if jwzOabysh0Z(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫྛ") not in str(KILF7s4vrwlacS89W):
		if showDialogs:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"࠭ไๅลึๅࠥา็ศิๆࠤ้อ๋ࠠีอาิ๋ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫྜ"))
		return
	yAFzVdqn3LpEYQKMZ0fCo2XtW = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡢࡦࡧࡳࡳࡹࠧྜྷ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧྞ"),TzIj50KpohEOHx6CbZWqB(u"ࠩ࠺࠶࠵ࡶࠧྟ"),IOHSz7YPF9WusGgUt1Dq(u"ࠪࡑࡾ࡜ࡩࡥࡧࡲࡒࡦࡼ࠮ࡹ࡯࡯ࠫྠ"))
	if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(yAFzVdqn3LpEYQKMZ0fCo2XtW): return
	Zk4v1yYSjrp7VEHnUfzx0TO2oI = open(yAFzVdqn3LpEYQKMZ0fCo2XtW,SIkwCEdJHTD9v1(u"ࠫࡷࡨࠧྡ")).read()
	if I5VKjrFL0Bk97: Zk4v1yYSjrp7VEHnUfzx0TO2oI = Zk4v1yYSjrp7VEHnUfzx0TO2oI.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	Q5lUcZTv78bX4Ys = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠮࡜ࡥ࠭࠯ࡠࡩ࠱ࠬ࡝ࡦ࠮࠭࠱࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡦࡹࡶࡂࠬྡྷ"),Zk4v1yYSjrp7VEHnUfzx0TO2oI,fNntYJW45mEFSdRX8g.DOTALL)
	jjq9Ro5sUiPgbNC3,KGbf5PQzERsNa = Q5lUcZTv78bX4Ys[BewrUo9ANCa17G43Sn0LH5xh]
	ttUWklgBsLVZ9zpR5IfnH6Ci2FvM = GVurlv8HeoXEzPRiQB7Ty(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧྣ")+jjq9Ro5sUiPgbNC3+bGzRdmOErkIylxALniq6(u"ࠧ࠭ࠩྤ")+KGbf5PQzERsNa+hPFcB6Uxmabj59Iq(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪྥ")
	if showDialogs:
		MvJmKdHcGxRZWgBOP5A8 = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(TzIj50KpohEOHx6CbZWqB(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡜ࡩࡦࡹࡰࡳࡩ࡫ࠧྦ"))
		if MvJmKdHcGxRZWgBOP5A8==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ྦྷ"): TAhmWVXIFszKd8H = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ็๎วว็ࠣห้้สศสฬࠫྨ")
		elif MvJmKdHcGxRZWgBOP5A8==qqw1upCsKM(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫྩ"): TAhmWVXIFszKd8H = oVwa0kcqxj1e7mLplAfZdGT(u"࠭โ้ษษ้ࠥอไึ๊ิࠫྪ")
		else: TAhmWVXIFszKd8H = oVwa0kcqxj1e7mLplAfZdGT(u"ࠧใ๊สส๊ࠦรฯำ์ࠫྫ")
		KTxQcnwvOF0pqt = bP5mf0Mo2nz(hPFcB6Uxmabj59Iq(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨྫྷ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩๅ์ฬฬๅࠡลัี๎࠭ྭ"),YQNd4wejLSAVJ6T(u"ࠪๆํอฦๆࠢส่่ะวษหࠪྮ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫ็๎วว็ࠣห้฻่าࠩྯ"),EJgYdjbIiWe1apkQlZcR42(u"ࠬอๆหࠢะห้๐วࠡฬึฮำีๅࠡࠩྰ")+TAhmWVXIFszKd8H,t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ว็ฬࠣห้ศๆࠡฬึฮำีๅࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๋๋ࠢีอࠠๆ฻้ห์ࠦว็ๅࠣฮุะื๋฻ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦศะๆสࠤ๊์ࠠใ๊สส๊ࠦวๅๅอหอฯࠠ࠯๋ࠢว๏฼วࠡฬึฮ฼๐ูࠡวํๆฬ็็ศࠢไ๎ࠥษ๊๊ࠡๅฮࠥะิศรࠣࡠࡳࡢ࡮ࠡࠩྱ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤࠫྲ")+B8alA5nvIhTxQ)
		if KTxQcnwvOF0pqt==bGzRdmOErkIylxALniq6(u"࠲ሷ"): S9R7tZsF1uxGedhKfWVb = qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫླ")
		elif KTxQcnwvOF0pqt==qqw1upCsKM(u"࠴ሸ"): S9R7tZsF1uxGedhKfWVb = YQNd4wejLSAVJ6T(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨྴ")
		else: S9R7tZsF1uxGedhKfWVb = sCHVtMAvqirbQ4BUK3cgWo
	else:
		MvJmKdHcGxRZWgBOP5A8 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨྵ"))
		if   MvJmKdHcGxRZWgBOP5A8==sCHVtMAvqirbQ4BUK3cgWo: KTxQcnwvOF0pqt = YQNd4wejLSAVJ6T(u"࠳ሹ")
		elif MvJmKdHcGxRZWgBOP5A8==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧྶ"): KTxQcnwvOF0pqt = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠵ሺ")
		elif MvJmKdHcGxRZWgBOP5A8==GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫྷ"): KTxQcnwvOF0pqt = TzIj50KpohEOHx6CbZWqB(u"࠷ሻ")
		S9R7tZsF1uxGedhKfWVb = MvJmKdHcGxRZWgBOP5A8
	if   KTxQcnwvOF0pqt==aenpKvQCGVzhLXEdWiDIZ(u"࠶ሼ"): h0hPnMbgUfDwvsS = sH6BOz5wKRFcEg(u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪྸ")
	elif KTxQcnwvOF0pqt==oVwa0kcqxj1e7mLplAfZdGT(u"࠱ሽ"): h0hPnMbgUfDwvsS = IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫྐྵ")
	elif KTxQcnwvOF0pqt==bGzRdmOErkIylxALniq6(u"࠳ሾ"): h0hPnMbgUfDwvsS = jwzOabysh0Z(u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬྺ")
	else: return
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧྻ"),S9R7tZsF1uxGedhKfWVb)
	ZmQ7GFPdvVfk = GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫྼ")+h0hPnMbgUfDwvsS+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫ࠱࠭྽")+KGbf5PQzERsNa+IOHSz7YPF9WusGgUt1Dq(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ྾")
	s1eVRLfFbycvMB = Zk4v1yYSjrp7VEHnUfzx0TO2oI.replace(ttUWklgBsLVZ9zpR5IfnH6Ci2FvM,ZmQ7GFPdvVfk)
	if I5VKjrFL0Bk97: s1eVRLfFbycvMB = s1eVRLfFbycvMB.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	open(yAFzVdqn3LpEYQKMZ0fCo2XtW,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡷࡣࠩ྿")).write(s1eVRLfFbycvMB)
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,TzIj50KpohEOHx6CbZWqB(u"ࠧ࠯࡞ࡷࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬ࿀")+h0hPnMbgUfDwvsS+SIkwCEdJHTD9v1(u"ࠨࠢࡠࠫ࿁"))
	if showDialogs: FoiwfTEhGD8ulS25HeUvnI.executebuiltin(EJgYdjbIiWe1apkQlZcR42(u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨ࿂"))
	return
def ds7lWCwa1iP2kuNMehE():
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,YQNd4wejLSAVJ6T(u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨ࿃"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠳ሿ"): XzMkGaOSRLNVQj09yUJ()
	return
def mXS9ITdcatQ5N1FVj():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,fvYGxnZNUiyP4HJkMIoS25(u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧ࿄"))
	return
def z1gHElIOi2b3Bv():
	xFNW2M6ijZbhzuoHgPC0Ba = F7Fe63KbGjaz2TcmCNHPdo5QiXO+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡࠩ࿅")+B8alA5nvIhTxQ
	xFNW2M6ijZbhzuoHgPC0Ba += t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอ࿆ࠬ")
	xFNW2M6ijZbhzuoHgPC0Ba += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࠬ࿇")+B8alA5nvIhTxQ
	N6yp1C9H8R = F7Fe63KbGjaz2TcmCNHPdo5QiXO+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨสิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡࠩ࿈")+B8alA5nvIhTxQ
	N6yp1C9H8R += qeG16a4pbSHziNVQ2uFXrs(u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭࿉")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴࠪ࿊")+B8alA5nvIhTxQ
	Iqm6XAWBlF = IOHSz7YPF9WusGgUt1Dq(u"ࠫࡠࡘࡔࡍ࡟ࠪ࿋")+xFNW2M6ijZbhzuoHgPC0Ba+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪ࿌")+N6yp1C9H8R
	ctjhP4l8L5pbwqZuQo3VYr(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡲࡪࡩ࡫ࡸࠬ࿍"),sCHVtMAvqirbQ4BUK3cgWo,Iqm6XAWBlF)
	return
def RRIKPjLqlmtoOVa6JGedr74hkc(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP):
	hO36FxWalTjkvQ9IzPH7bo(UTCXGnK7Fs4Y5pNkt2ARDWuw)
	Q3KzTrUfXiFAhEGg1W72toxyIPudmp = NIEPcjs2b0YDrZ7(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP)
	for Uypv0Wze2S9T1mdRKoMDw4k7EqG8L in [zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ࿎"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ࿏"),SIkwCEdJHTD9v1(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧ࿐"),Js61GTdX5wzMurUqi7Z(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘࡥࡔࡔࠩ࿑")]:
		if Uypv0Wze2S9T1mdRKoMDw4k7EqG8L in Q1siCkTZyw.SEND_THESE_EVENTS: Q1siCkTZyw.SEND_THESE_EVENTS.remove(Uypv0Wze2S9T1mdRKoMDw4k7EqG8L)
	jq1yMu9V5Bt3lxh6K(BWfpRku7SsM6cbE0eG(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧ࿒"))
	id,qtWgRvai4wjFumUCLMH,r1PgycpO2EHAuM,oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6,reason = Q3KzTrUfXiFAhEGg1W72toxyIPudmp[BewrUo9ANCa17G43Sn0LH5xh]
	ss5d8hPGLTrFC4eBJmIgMvXnK3,zMPElG9TxQkZ2UXf03CDJvncR5Kgr = oAsDQxGyP2kFK7wYiIN.split(TzIj50KpohEOHx6CbZWqB(u"ࠬࡢ࡮࠼࠽ࠪ࿓"))
	N6yp1C9H8R,D6kU7MfbGhxpWgB2CzlR1cqJs0,W3AlVjrGIZ6Q1u2awYNPLcpRgvyX = bg1dAEcph3zqxXio4eL0fQ8CJtjWu6.split(SE97R3Dpj6dPLweVKU(u"࠭࡜࡯࠽࠾ࠫ࿔"))
	peSR3JjBoIg8QKXmM9iaFy2567 = ndkUxG9LtewJ
	while peSR3JjBoIg8QKXmM9iaFy2567:
		zWJ8MZebuAGomyBhLr5QDgtKnaw = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧฯำ๋ะࠬ࿕"),SIkwCEdJHTD9v1(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧ࿖"),IO7k2hZXSz(u"ࠩๅหห๋ษࠡษ็ฮอืูศฬࠪ࿗"),gDETKVh8mZe09Nd(u"่ࠪส๐โศใࠣห้หูๅษ้หฯࠦ࠺ࠡࠢอฬึ฿ࠠฤ๊ࠣหู๊อࠡษ็ฬึ์วๆฮࠪ࿘"),N6yp1C9H8R)
		if zWJ8MZebuAGomyBhLr5QDgtKnaw==t19ZOVHA4CpwFKaeiubcMGvz(u"࠵ቀ"): nFjp6P0Zte = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"ࠫ฾๎ฯสࠩ࿙"),sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ࿚"),D6kU7MfbGhxpWgB2CzlR1cqJs0,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪ࿛"))
		elif zWJ8MZebuAGomyBhLr5QDgtKnaw==qqw1upCsKM(u"࠵ቁ"): QiGkIR6Eys()
		else: peSR3JjBoIg8QKXmM9iaFy2567 = lvzrYTpcBaK
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def Dzcs4oa0qmGI1kSiMxNd():
	uqkXOJBAitwLZfCoQsKPIdyV0Tj7zR()
	BSfO0YckGiQ4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(gDETKVh8mZe09Nd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭࿜"))
	Iqm6XAWBlF = {}
	Iqm6XAWBlF[oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡃࡘࡘࡔ࠭࿝")] = zLjWeKu6JgNO7vocUD0Qpy(u"ࠩส่่อิࠡษ็ฮ้่วว์ࠣ๎฾๋ไࠨ࿞")
	Iqm6XAWBlF[qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡗ࡙ࡕࡐࠨ࿟")] = qeG16a4pbSHziNVQ2uFXrs(u"ࠫฬ๊ใศึ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ࿠")
	Iqm6XAWBlF[qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭࿡")] = bGzRdmOErkIylxALniq6(u"࠭ใศึࠣะิอࠠใืํีࠥอไๆั์ࠤ࠳ࠦࠧ࿢")+str(LLg3oeFAZujGWitdBw0DOsRmhlVk/t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠻࠶ቂ"))+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࠡัๅ๎็ฯࠠโไฺࠫ࿣")
	JHj1gp4GbLc6lZ9rUvIY0Qk3 = Iqm6XAWBlF[BSfO0YckGiQ4]
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠨๅสุࠥ࠭࿤")+str(LLg3oeFAZujGWitdBw0DOsRmhlVk/qeG16a4pbSHziNVQ2uFXrs(u"࠼࠰ቃ"))+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࠣำ็๐โสࠩ࿥"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ࿦"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫส๐โศใࠣ็ฬ๋ไࠨ࿧"),JHj1gp4GbLc6lZ9rUvIY0Qk3,fvYGxnZNUiyP4HJkMIoS25(u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ࿨"))
	if KTxQcnwvOF0pqt==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠰ቄ"): pyGPrefokwu2 = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ࿩")
	elif KTxQcnwvOF0pqt==aYH620Dh48GEsTFfOBSQ7r(u"࠲ቅ"): pyGPrefokwu2 = jwzOabysh0Z(u"ࠧࡂࡗࡗࡓࠬ࿪")
	elif KTxQcnwvOF0pqt==IO7k2hZXSz(u"࠴ቆ"): pyGPrefokwu2 = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡕࡗࡓࡕ࠭࿫")
	else: pyGPrefokwu2 = sCHVtMAvqirbQ4BUK3cgWo
	if pyGPrefokwu2:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ࿬"),pyGPrefokwu2)
		XS9RC7u3MNAQmEbFBdY = Iqm6XAWBlF[pyGPrefokwu2]
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XS9RC7u3MNAQmEbFBdY)
	return
def SCMQ1zrKD60AL5uZcsT():
	Iqm6XAWBlF = {}
	Iqm6XAWBlF[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡅ࡚࡚ࡏࠨ࿭")] = BWfpRku7SsM6cbE0eG(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩ࿮")
	Iqm6XAWBlF[SIkwCEdJHTD9v1(u"ࠬࡇࡓࡌࠩ࿯")] = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪ࿰")
	Iqm6XAWBlF[qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡔࡖࡒࡔࠬ࿱")] = YQNd4wejLSAVJ6T(u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ࿲")
	lTStjx0HuzNoCM6 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(RDwahqjPfbdyEiTtnLQu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩ࿳"))
	BSfO0YckGiQ4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭࿴"))
	JHj1gp4GbLc6lZ9rUvIY0Qk3 = Iqm6XAWBlF[BSfO0YckGiQ4]+lTStjx0HuzNoCM6
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩ࿵"),jwzOabysh0Z(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ࿶"),IO7k2hZXSz(u"࠭ล๋ไสๅ้ࠥวๆๆࠪ࿷"),JHj1gp4GbLc6lZ9rUvIY0Qk3,Js61GTdX5wzMurUqi7Z(u"ࠧิ์ิๅึࠦࡄࡏࡕ๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎็๎ๅࠡสอัํ๐ไࠡลึ้ฬวࠠศๆ่์ฬู่๊ࠡสุ่๐ัโำสฮࠥหไ๊ࠢฦี็อๅ๊ࠡ฼๊ิࠦศฺุࠣห้์วิࠢํๆํ๋ࠠษฯฯฬࠥ๎ๅ็฻ࠣ์า฼ัࠡส฼ฺࠥอไๆ๊สๆ฾ࠦ࠮ࠡๆอุ฿๐ไࠡีํีๆืࠠࡅࡐࡖࠤ็๋ࠠษษัฮ๏อัࠡษ็ื๏ืแาࠢส่๊์วิสࠣวํࠦโๆࠢหษ๏่วโ้ࠣฬฬ๊ใศ็็ࠫ࿸"))
	if KTxQcnwvOF0pqt==aYH620Dh48GEsTFfOBSQ7r(u"࠳ቇ"): pyGPrefokwu2 = aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡃࡖࡏࠬ࿹")
	elif KTxQcnwvOF0pqt==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠵ቈ"): pyGPrefokwu2 = IOHSz7YPF9WusGgUt1Dq(u"ࠩࡄ࡙࡙ࡕࠧ࿺")
	elif KTxQcnwvOF0pqt==aenpKvQCGVzhLXEdWiDIZ(u"࠷቉"): pyGPrefokwu2 = Js61GTdX5wzMurUqi7Z(u"ࠪࡗ࡙ࡕࡐࠨ࿻")
	if KTxQcnwvOF0pqt in [TzIj50KpohEOHx6CbZWqB(u"࠰ቋ"),IOHSz7YPF9WusGgUt1Dq(u"࠷ቊ")]:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿼"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ู๊ࠬาใิ࠾ࠥ࠭࿽")+Q1siCkTZyw.DNS_SERVERS[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],jwzOabysh0Z(u"࠭ำ๋ำไี࠿ࠦࠧ࿾")+Q1siCkTZyw.DNS_SERVERS[BewrUo9ANCa17G43Sn0LH5xh],sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠧฤะอหึࠦำ๋ำไีࠥࡊࡎࡔࠢส่๊์วิส่่ࠣ࠭࿿"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA==oVwa0kcqxj1e7mLplAfZdGT(u"࠲ቌ"): EETAMfnVhl84qv = Q1siCkTZyw.DNS_SERVERS[BewrUo9ANCa17G43Sn0LH5xh]
		else: EETAMfnVhl84qv = Q1siCkTZyw.DNS_SERVERS[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	elif KTxQcnwvOF0pqt==zLjWeKu6JgNO7vocUD0Qpy(u"࠴ቍ"): EETAMfnVhl84qv = sCHVtMAvqirbQ4BUK3cgWo
	else: pyGPrefokwu2 = sCHVtMAvqirbQ4BUK3cgWo
	if pyGPrefokwu2:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(sH6BOz5wKRFcEg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫက"),pyGPrefokwu2)
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(gDETKVh8mZe09Nd(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩခ"),EETAMfnVhl84qv)
		XS9RC7u3MNAQmEbFBdY = Iqm6XAWBlF[pyGPrefokwu2]+EETAMfnVhl84qv
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XS9RC7u3MNAQmEbFBdY)
	return
def Uva1wYqPi0C7ASB():
	BSfO0YckGiQ4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨဂ"))
	Iqm6XAWBlF = {}
	Iqm6XAWBlF[RDwahqjPfbdyEiTtnLQu(u"ࠫࡆ࡛ࡔࡐࠩဃ")] = IOHSz7YPF9WusGgUt1Dq(u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭င")
	Iqm6XAWBlF[EJgYdjbIiWe1apkQlZcR42(u"࠭ࡁࡔࡍࠪစ")] = Js61GTdX5wzMurUqi7Z(u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨဆ")
	Iqm6XAWBlF[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡕࡗࡓࡕ࠭ဇ")] = Js61GTdX5wzMurUqi7Z(u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫဈ")
	JHj1gp4GbLc6lZ9rUvIY0Qk3 = Iqm6XAWBlF[BSfO0YckGiQ4]
	KTxQcnwvOF0pqt = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨဉ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪည"),bGzRdmOErkIylxALniq6(u"ࠬห๊ใษไࠤ่อๅๅࠩဋ"),JHj1gp4GbLc6lZ9rUvIY0Qk3,fvYGxnZNUiyP4HJkMIoS25(u"࠭วๅสิ์ู่๊้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์฼้้่ࠦิ์ฺࠤอ๐ๆࠡฮ๊หื้้ࠠษ็ษ๋ะั็์อࠤ࠳ࠦ็้ࠢํืฯ๊ๅูࠡ็ฬฬะใ๊ࠡํๆํ๋ࠠษีะฬ์อࠠษั็ห๋ࠥๆไࠢฮ้ࠥ๐ศฺอ๊ห๊ࠥใࠡ࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣว๊ࠦล๋ไสๅࠥอไษำ๋็ุ๐ࠠภࠩဌ"))
	if KTxQcnwvOF0pqt==gDETKVh8mZe09Nd(u"࠳቎"): pyGPrefokwu2 = aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡂࡕࡎࠫဍ")
	elif KTxQcnwvOF0pqt==qeG16a4pbSHziNVQ2uFXrs(u"࠵቏"): pyGPrefokwu2 = qqw1upCsKM(u"ࠨࡃࡘࡘࡔ࠭ဎ")
	elif KTxQcnwvOF0pqt==RDwahqjPfbdyEiTtnLQu(u"࠷ቐ"): pyGPrefokwu2 = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡖࡘࡔࡖࠧဏ")
	else: pyGPrefokwu2 = sCHVtMAvqirbQ4BUK3cgWo
	if pyGPrefokwu2:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨတ"),pyGPrefokwu2)
		XS9RC7u3MNAQmEbFBdY = Iqm6XAWBlF[pyGPrefokwu2]
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XS9RC7u3MNAQmEbFBdY)
	return
def yfAvIeOjC32kmcgxL():
	XHhlp8fFLq0JvCsO5tag1 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫထ"))
	if XHhlp8fFLq0JvCsO5tag1==TzIj50KpohEOHx6CbZWqB(u"࡙ࠬࡔࡐࡒࠪဒ"): header = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅห๊ๅๅࠬဓ")
	else: header = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆใ฼่ࠬန")
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨวํๆฬ็ࠧပ"),hPFcB6Uxmabj59Iq(u"ࠩอๅ฾๐ไࠨဖ"),header,BWfpRku7SsM6cbE0eG(u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧဗ"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==-jwzOabysh0Z(u"࠷ቑ"): return
	elif bR4jqNrpMesHt93OgGKi6WDVaQA:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫဘ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡇࡕࡕࡑࠪမ"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t19ZOVHA4CpwFKaeiubcMGvz(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨယ"))
	else:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧရ"),Js61GTdX5wzMurUqi7Z(u"ࠨࡕࡗࡓࡕ࠭လ"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,BWfpRku7SsM6cbE0eG(u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫဝ"))
	return
def aSxdivqJspMnPh2oFY3t5fbuC(T67f3LG49xpP8zcN):
	if T67f3LG49xpP8zcN!=sCHVtMAvqirbQ4BUK3cgWo:
		T67f3LG49xpP8zcN = fko6iadls820ZP9MNqX(T67f3LG49xpP8zcN)
		T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		vRxCTm7SY3 = EJgYdjbIiWe1apkQlZcR42(u"࠱࠱࠳࠳࠷ቒ")
		IiDXAnVWU2k90cT = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.Window(vRxCTm7SY3)
		IiDXAnVWU2k90cT.getControl(SIkwCEdJHTD9v1(u"࠴࠳࠴ቓ")).setLabel(T67f3LG49xpP8zcN)
	return
jH5bKstlC1Zhd6uVaY = [
			 E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࡡࡷࡵࡳࡥࡨ࡫ࡳ࠱ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣသ")
			,SE97R3Dpj6dPLweVKU(u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧဟ")
			,gDETKVh8mZe09Nd(u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧဠ")
			,aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨအ")
			,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨဢ")
			,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪဣ")
			,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠨဤ")+aenpKvQCGVzhLXEdWiDIZ(u"ࠪࠧࠬဥ")+oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪဦ")
			,YQNd4wejLSAVJ6T(u"ࠬࡏ࡮ࡴࡧࡦࡹࡷ࡫ࡒࡦࡳࡸࡩࡸࡺࡗࡢࡴࡱ࡭ࡳ࡭ࠬࠨဧ")
			,bGzRdmOErkIylxALniq6(u"࠭ࡅࡳࡴࡲࡶࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࠯ࡀ࡯ࡲࡨࡪ࡫࠽࠱ࠨࡷࡩࡽࡺࡴ࠾ࠩဨ")
			,IO7k2hZXSz(u"ࠧࡸࡣࡵࡲ࡮ࡴࡧࡴ࠰ࡺࡥࡷࡴࠨࠨဩ")
			,qqw1upCsKM(u"ࠨࡠࡡࡢࡣࡤࠧဪ")
			,qqw1upCsKM(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧါ")
			,qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡰࡦࡸࡧࡦࠢࡤࡹࡩ࡯࡯ࠡࡵࡼࡲࡨࠦࡥࡳࡴࡲࡶ࠿࠭ာ")
			,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࡮ࡴࡦࡰ࠼ࠣࡑࡪࡪࡩࡢࡥࡲࡨࡪࡩࠠࡥࡧࡦࡳࡩ࡫ࡲ࠻ࠩိ")
			]
def N6j1GPLg7TOvB0UyzFDbmqV2c(mrDfbxOkTg):
	if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪီ") in mrDfbxOkTg and iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫု") in mrDfbxOkTg: return ndkUxG9LtewJ
	for T67f3LG49xpP8zcN in jH5bKstlC1Zhd6uVaY:
		if T67f3LG49xpP8zcN in mrDfbxOkTg: return ndkUxG9LtewJ
	return lvzrYTpcBaK
def bIkPf0W3jYoC9srZHB(data):
	fe4CMJHbT0X8PjB = TzIj50KpohEOHx6CbZWqB(u"࠺ቕ") if I5VKjrFL0Bk97 else iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠳࠸ቔ")
	data = data.replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠷࠵ቖ")*AAh0X3OCacr4HpifRGLZKT,fe4CMJHbT0X8PjB*AAh0X3OCacr4HpifRGLZKT)
	data = data.replace(jwzOabysh0Z(u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭ူ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࠼ࠣࠫေ"))
	i68iPmaHVAZknGv2SNpyzCwcFE = sCHVtMAvqirbQ4BUK3cgWo
	for mrDfbxOkTg in data.splitlines():
		vJHCj59sVmcOP1ZpqTGi6NKQMD = fNntYJW45mEFSdRX8g.findall(hPFcB6Uxmabj59Iq(u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠯ࠫࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨဲ"),mrDfbxOkTg,fNntYJW45mEFSdRX8g.DOTALL)
		if vJHCj59sVmcOP1ZpqTGi6NKQMD: mrDfbxOkTg = mrDfbxOkTg.replace(vJHCj59sVmcOP1ZpqTGi6NKQMD[BewrUo9ANCa17G43Sn0LH5xh],sCHVtMAvqirbQ4BUK3cgWo)
		i68iPmaHVAZknGv2SNpyzCwcFE += slFfrUIWCowaBA7tce3iZbj8xn+mrDfbxOkTg
	return i68iPmaHVAZknGv2SNpyzCwcFE
def CCAL6mu3SjHK(wW0BmDC1J4NphExbcdqVTX):
	if IOHSz7YPF9WusGgUt1Dq(u"ࠪࡓࡑࡊࠧဳ") in wW0BmDC1J4NphExbcdqVTX:
		hqAGF52C4PizZl0 = Q8fWtaezok9gNZbuilHc36IOX
		header = aenpKvQCGVzhLXEdWiDIZ(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่็ี๊ๆࠢยࠫဴ")
	else:
		hqAGF52C4PizZl0 = GJ96QNqUWSpM40HlLdYsAfVkgKZ
		header = bGzRdmOErkIylxALniq6(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้ำวๅ์ࠣรࠬဵ")
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,header,qeG16a4pbSHziNVQ2uFXrs(u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩံ"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA!=Js61GTdX5wzMurUqi7Z(u"࠶቗"): return
	QCXsYOgjc9SPuf7T,ffpXyPnsrkNAgIq = [],jwzOabysh0Z(u"࠶ቘ")
	size,count = kAxsioNSB6w5cDaKGlueOjXd(hqAGF52C4PizZl0)
	file = open(hqAGF52C4PizZl0,gDETKVh8mZe09Nd(u"ࠧࡳࡤ့ࠪ"))
	if size>qeG16a4pbSHziNVQ2uFXrs(u"࠲࠲࠳࠶࠵࠶ቚ"): file.seek(-XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠱࠱࠲࠴࠴࠵቙"),YYEXZsUWhf52vz7HLxc0qGJ.SEEK_END)
	data = file.read()
	file.close()
	if I5VKjrFL0Bk97: data = data.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	data = bIkPf0W3jYoC9srZHB(data)
	CChmRfAOZ4eLtczYduF = data.split(slFfrUIWCowaBA7tce3iZbj8xn)
	for mrDfbxOkTg in reversed(CChmRfAOZ4eLtczYduF):
		u95o6jXcIRF023xOmCWNP7HUAYGa8e = N6j1GPLg7TOvB0UyzFDbmqV2c(mrDfbxOkTg)
		if u95o6jXcIRF023xOmCWNP7HUAYGa8e: continue
		mrDfbxOkTg = mrDfbxOkTg.replace(BWfpRku7SsM6cbE0eG(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࡡࠪး"),F7Fe63KbGjaz2TcmCNHPdo5QiXO+hPFcB6Uxmabj59Iq(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤ္ࠬ")+B8alA5nvIhTxQ)
		mrDfbxOkTg = mrDfbxOkTg.replace(gDETKVh8mZe09Nd(u"ࠪࡉࡗࡘࡏࡓ࠼်ࠪ"),Js61GTdX5wzMurUqi7Z(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇ࠲࠳࠴࠵ࡣࠧျ")+BWfpRku7SsM6cbE0eG(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬြ")+B8alA5nvIhTxQ)
		ZLfgYDrEVHqG = sCHVtMAvqirbQ4BUK3cgWo
		dluO1VREUfohcD79 = fNntYJW45mEFSdRX8g.findall(BWfpRku7SsM6cbE0eG(u"࠭࡞ࠩ࡞ࡧ࠯࠲࠮࡜ࡥ࠭࠰ࡠࡩ࠱ࠠ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭ࠬ࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ွ"),mrDfbxOkTg,fNntYJW45mEFSdRX8g.DOTALL)
		if dluO1VREUfohcD79:
			mrDfbxOkTg = mrDfbxOkTg.replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh],dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]).replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][rgpY5VUqKbeFOCD9Nki2SmGvxEja],sCHVtMAvqirbQ4BUK3cgWo)
			ZLfgYDrEVHqG = dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		else:
			dluO1VREUfohcD79 = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧှ"),mrDfbxOkTg,fNntYJW45mEFSdRX8g.DOTALL)
			if dluO1VREUfohcD79:
				mrDfbxOkTg = mrDfbxOkTg.replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],sCHVtMAvqirbQ4BUK3cgWo)
				ZLfgYDrEVHqG = dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh]
		if ZLfgYDrEVHqG: mrDfbxOkTg = mrDfbxOkTg.replace(ZLfgYDrEVHqG,VXWOCAE6ns3paJ8DLG479NQfMu+ZLfgYDrEVHqG+B8alA5nvIhTxQ)
		QCXsYOgjc9SPuf7T.append(mrDfbxOkTg)
		if len(str(QCXsYOgjc9SPuf7T))>wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠷࠳࠵࠵࠶ቛ"): break
	QCXsYOgjc9SPuf7T = reversed(QCXsYOgjc9SPuf7T)
	xjY3SM4Fm8JPsT09ac1zg6iUebnwBL = slFfrUIWCowaBA7tce3iZbj8xn.join(QCXsYOgjc9SPuf7T)
	ctjhP4l8L5pbwqZuQo3VYr(qqw1upCsKM(u"ࠨ࡮ࡨࡪࡹ࠭ဿ"),Js61GTdX5wzMurUqi7Z(u"ࠩลาึࠦริูิࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊࠭၀"),xjY3SM4Fm8JPsT09ac1zg6iUebnwBL,Js61GTdX5wzMurUqi7Z(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭၁"))
	return
def pesuPtSgrvoW():
	ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK = open(oAOpesfZdgqDaJmXSKPi,qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡷࡨࠧ၂")).read()
	if I5VKjrFL0Bk97: ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK = ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK = ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK.replace(Js61GTdX5wzMurUqi7Z(u"ࠬࡢࡴࠨ၃"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠨ၄"))
	MyeJZzh0Q8RYL2U6 = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠧࠩࡸ࡟ࡨ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ၅"),ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK,fNntYJW45mEFSdRX8g.DOTALL)
	for mrDfbxOkTg in MyeJZzh0Q8RYL2U6:
		ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK = ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK.replace(mrDfbxOkTg,F7Fe63KbGjaz2TcmCNHPdo5QiXO+mrDfbxOkTg+B8alA5nvIhTxQ)
	aMy5eXwi3xguBjzEV(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨษ็ฮ฿๐๊าษอࠤฬ๊รฯ์ิอࠥ็๊ࠡษ็ฬึอๅอࠩ၆"),ip2cDVN9lAOh5uLb4yG8xQMoYIk6FK)
	return
def xqeOhgp3Ps98():
	xFNW2M6ijZbhzuoHgPC0Ba = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩห฽฻ࠦวๅลีีฬืฺࠠๆ์ࠤฬ๊ั๋็๋ฮ้่ࠥ็ฬิ์้ࠦส้ใิࠤส๋ใศ่ํอࠥะโะ์่ࠤํะรฯ์ิࠤฬ๊แ๋ัํ์ࠥ๎็ั้ࠣห้ษาาษิࠤ์๐ࠠศๆฦื์๋้ࠠษ็วึ่วๆ่ࠢ฽ࠥฮูื๋ࠢ็ฬ๊สศๆํࠫ၇")
	N6yp1C9H8R = zLjWeKu6JgNO7vocUD0Qpy(u"่ࠪฯ่ฯ๋็ࠣห้็๊ะ์๋ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ๅ๋่ࠣ์้ะรฯ์ิ๋ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ิษิࠤ࠳ࠦรๆษࠣ฽ิฯࠠศี๊้๋ࠥสหษ็๎ฮࠦแ่า๊ࠤฯ่่ๆࠢหฮาื๊ไࠢส่ๆ๐ฯ๋๊ࠣฬํ่สࠡษๆฬึࠦๅ็๋ࠢๆฯࠦวๅี๊้ࠥอไ้ษะำࠥ࠴ࠠฤ็สࠤฬ๊ำ่็ࠣห้ษูๅ๋ࠣ์ฬ๊ริใ็ࠤๆํ่ࠡ์ะี่ࠦวๅใํำ๏๎ࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤํ๊ใ็ࠢหๆๆุษࠡๅห๎ึฯࠧ၈")
	D6kU7MfbGhxpWgB2CzlR1cqJs0 = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫศ๋วࠡษ็วึ่วๆࠢไ๋๏ࠦสิฬัำ๊ࠦไๅฬๅำ๏๋้ࠠษ็ฮศิ๊า๋่่ࠢ์ࠠษ็ๅำฬืฺࠠัาࠤฬ๊ห้ษ้๎ࠥ๎วๅัๅหห่ࠠ࠯่ࠢฯ้อࠠาไ่ࠤ࠺࠺࠴ࠡฬ฼๊๏ࠦ࠵ࠡัๅหห่้ࠠࠢ࠷࠸ࠥัว็์ฬࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอมࠡสะือࠦวิฬัำฬ๋ใࠡๆ็ื์๋ࠠศๆํ้๏์ࠠฤ๊ࠣื์๋ࠠศๆํืฬืࠧ၉")
	Iqm6XAWBlF = xFNW2M6ijZbhzuoHgPC0Ba+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡀࠠࠨ၊")+N6yp1C9H8R+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠠ࠯ࠢࠪ။")+D6kU7MfbGhxpWgB2CzlR1cqJs0
	ctjhP4l8L5pbwqZuQo3VYr(qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡤࡧࡱࡸࡪࡸࠧ၌"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF,SE97R3Dpj6dPLweVKU(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ၍"))
	return
def XuLQaKS9RB4CxOYG5J0kMsNZnq6bFl(type,Iqm6XAWBlF,showDialogs=ndkUxG9LtewJ,url=sCHVtMAvqirbQ4BUK3cgWo,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=sCHVtMAvqirbQ4BUK3cgWo,T67f3LG49xpP8zcN=sCHVtMAvqirbQ4BUK3cgWo,I9ikUXVehmdcq37OKNs8P4JDYM=sCHVtMAvqirbQ4BUK3cgWo):
	NOgJSmViqTn2U = ndkUxG9LtewJ
	if not Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc:
		if showDialogs:
			W3yq0gJkGs2r5wz7TEHfx1SbOM = (Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩสุ่฽ั࠻ࠩ၎") in Iqm6XAWBlF and aenpKvQCGVzhLXEdWiDIZ(u"ࠪห้๋ใศ่࠽ࠫ၏") in Iqm6XAWBlF and gDETKVh8mZe09Nd(u"ࠫฬ๊ๅๅใ࠽ࠫၐ") in Iqm6XAWBlF and t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬอไฯูฦࠫၑ") in Iqm6XAWBlF and jwzOabysh0Z(u"࠭วๅ็ุำึࡀࠧၒ") in Iqm6XAWBlF)
			if not W3yq0gJkGs2r5wz7TEHfx1SbOM: NOgJSmViqTn2U = NVjFvLmZCYRu1S893eTf6dUbqJl(bGzRdmOErkIylxALniq6(u"ࠧࡤࡧࡱࡸࡪࡸࠧၓ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠨ้็ࠤฯืำๅ๊ࠢิ์ࠦวๅำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬၔ"),Iqm6XAWBlF.replace(Js61GTdX5wzMurUqi7Z(u"ࠩ࡟ࡠࡳ࠭ၕ"),slFfrUIWCowaBA7tce3iZbj8xn))
	elif showDialogs:
		Iqm6XAWBlF = IO7k2hZXSz(u"ࠪࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅหࠪၖ")
		h4PBgIzXl0vOQwdi6kZFCJTjcRSq91 = NVjFvLmZCYRu1S893eTf6dUbqJl(SE97R3Dpj6dPLweVKU(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၗ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬၘ")+gDETKVh8mZe09Nd(u"࠭ࠠࠡ࠳࠲࠹ࠬၙ"),aenpKvQCGVzhLXEdWiDIZ(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬၚ"))
		BBN6o3tV0YRlpkLD = NVjFvLmZCYRu1S893eTf6dUbqJl(gDETKVh8mZe09Nd(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨၛ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩၜ")+SE97R3Dpj6dPLweVKU(u"ࠪࠤࠥ࠸࠯࠶ࠩၝ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩၞ"))
		WCciFTRYD9of3x2kgydUlJQsNeE = NVjFvLmZCYRu1S893eTf6dUbqJl(Js61GTdX5wzMurUqi7Z(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၟ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ၠ")+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡࠢ࠶࠳࠺࠭ၡ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ၢ"))
		fEYhGVHFst = NVjFvLmZCYRu1S893eTf6dUbqJl(bGzRdmOErkIylxALniq6(u"ࠩࡦࡩࡳࡺࡥࡳࠩၣ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪၤ")+qqw1upCsKM(u"ࠫࠥࠦ࠴࠰࠷ࠪၥ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪၦ"))
		NOgJSmViqTn2U = NVjFvLmZCYRu1S893eTf6dUbqJl(qqw1upCsKM(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၧ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧၨ")+IO7k2hZXSz(u"ࠨࠢࠣ࠹࠴࠻ࠧၩ"),zLjWeKu6JgNO7vocUD0Qpy(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧၪ"))
	qtWgRvai4wjFumUCLMH = CCKuzJQIRvg(lvzrYTpcBaK)
	xbgYhuPI6dE7JcD1ZOH = oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡅ࡛ࡀࠠࠨၫ")+qtWgRvai4wjFumUCLMH+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࠲࠭ၬ")+type
	KKOmR8SLlskcNxuPwqFtZhWa = ndkUxG9LtewJ if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨၭ") in T67f3LG49xpP8zcN else lvzrYTpcBaK
	if not NOgJSmViqTn2U:
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠢห๊ฬวฺࠠๆ์ࠤ฼๊ศไࠩၮ"))
		return lvzrYTpcBaK
	N2NyodgJbjQTSAr7Z6s4M = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(EJgYdjbIiWe1apkQlZcR42(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭ၯ"))
	Iqm6XAWBlF += Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࠢ࡟ࡠࡳࡢ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢ࡟ࡠࡳࡇࡤࡥࡱࡱࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧၰ")+WHzJr591Ka8gRdbiLmBp0hT3S+qeG16a4pbSHziNVQ2uFXrs(u"ࠩࠣ࠾ࡡࡢ࡮ࠨၱ")
	Iqm6XAWBlF += YQNd4wejLSAVJ6T(u"ࠪࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫၲ")+qtWgRvai4wjFumUCLMH+SIkwCEdJHTD9v1(u"ࠫࠥࡀ࡜࡝ࡰࡎࡳࡩ࡯ࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪၳ")+LLt0mXJQ1Frlou9CT2g86YGNqKz+qeG16a4pbSHziNVQ2uFXrs(u"ࠬࠦ࠺࡝࡞ࡱࠫၴ")
	Iqm6XAWBlF += wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡋࡰࡦ࡬ࠤࡓࡧ࡭ࡦ࠼ࠣࠫၵ")+N2NyodgJbjQTSAr7Z6s4M
	wquHle38sKUCAMLSg = B1UysZq2WtOj()
	wquHle38sKUCAMLSg = IgCGzHw45TJ7PeuO1EKl(wquHle38sKUCAMLSg)
	if wquHle38sKUCAMLSg: Iqm6XAWBlF += aenpKvQCGVzhLXEdWiDIZ(u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩၶ")+wquHle38sKUCAMLSg
	if url: Iqm6XAWBlF += SIkwCEdJHTD9v1(u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬၷ")+url
	if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: Iqm6XAWBlF += t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩၸ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt
	Iqm6XAWBlF += aenpKvQCGVzhLXEdWiDIZ(u"ࠪࠤ࠿ࡢ࡜࡯ࠩၹ")
	if showDialogs: iRaHzNpJhSx6ZnCfrvD7j93lks(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫัอั๋ࠢส่สืำศๆࠪၺ"),sH6BOz5wKRFcEg(u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧၻ"))
	if KKOmR8SLlskcNxuPwqFtZhWa:
		if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭ၼ") in T67f3LG49xpP8zcN: eglTkxhKVZ3tLrSQdMyuA = Q8fWtaezok9gNZbuilHc36IOX
		else: eglTkxhKVZ3tLrSQdMyuA = GJ96QNqUWSpM40HlLdYsAfVkgKZ
		if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(eglTkxhKVZ3tLrSQdMyuA):
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,gDETKVh8mZe09Nd(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬၽ"))
			return lvzrYTpcBaK
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠰࡟ࡸࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡪࡴࡤࠡࡶ࡫ࡩࠥࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ၾ"))
		QCXsYOgjc9SPuf7T,ffpXyPnsrkNAgIq = [],qqw1upCsKM(u"࠳ቜ")
		file = open(eglTkxhKVZ3tLrSQdMyuA,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡵࡦࠬၿ"))
		size,count = kAxsioNSB6w5cDaKGlueOjXd(eglTkxhKVZ3tLrSQdMyuA)
		if size>YQNd4wejLSAVJ6T(u"࠷࠵࠷࠰࠱࠲ቝ"): file.seek(-YQNd4wejLSAVJ6T(u"࠷࠵࠷࠰࠱࠲ቝ"),YYEXZsUWhf52vz7HLxc0qGJ.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		data = bIkPf0W3jYoC9srZHB(data)
		CChmRfAOZ4eLtczYduF = data.splitlines()
		for mrDfbxOkTg in reversed(CChmRfAOZ4eLtczYduF):
			u95o6jXcIRF023xOmCWNP7HUAYGa8e = N6j1GPLg7TOvB0UyzFDbmqV2c(mrDfbxOkTg)
			if u95o6jXcIRF023xOmCWNP7HUAYGa8e: continue
			dluO1VREUfohcD79 = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪႀ"),mrDfbxOkTg,fNntYJW45mEFSdRX8g.DOTALL)
			if dluO1VREUfohcD79:
				mrDfbxOkTg = mrDfbxOkTg.replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh],dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]).replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][rgpY5VUqKbeFOCD9Nki2SmGvxEja],sCHVtMAvqirbQ4BUK3cgWo)
			else:
				dluO1VREUfohcD79 = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫႁ"),mrDfbxOkTg,fNntYJW45mEFSdRX8g.DOTALL)
				if dluO1VREUfohcD79: mrDfbxOkTg = mrDfbxOkTg.replace(dluO1VREUfohcD79[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],sCHVtMAvqirbQ4BUK3cgWo)
			QCXsYOgjc9SPuf7T.append(mrDfbxOkTg)
			if len(str(QCXsYOgjc9SPuf7T))>XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠷࠻࠱࠱࠲࠳቞"): break
		QCXsYOgjc9SPuf7T = reversed(QCXsYOgjc9SPuf7T)
		xjY3SM4Fm8JPsT09ac1zg6iUebnwBL = qqw1upCsKM(u"ࠬࡢࡲ࡝ࡰࠪႂ").join(QCXsYOgjc9SPuf7T)
	elif I9ikUXVehmdcq37OKNs8P4JDYM: xjY3SM4Fm8JPsT09ac1zg6iUebnwBL = I9ikUXVehmdcq37OKNs8P4JDYM
	else: xjY3SM4Fm8JPsT09ac1zg6iUebnwBL = sCHVtMAvqirbQ4BUK3cgWo
	url = Q1siCkTZyw.SITESURLS[E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ႃ")][rgpY5VUqKbeFOCD9Nki2SmGvxEja]
	rnCzKJiBSsgGhj = {IO7k2hZXSz(u"ࠧࡴࡷࡥ࡮ࡪࡩࡴࠨႄ"):xbgYhuPI6dE7JcD1ZOH,TzIj50KpohEOHx6CbZWqB(u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩႅ"):Iqm6XAWBlF,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪႆ"):xjY3SM4Fm8JPsT09ac1zg6iUebnwBL}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡔࡔ࡙ࡔࠨႇ"),url,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧႈ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if hPFcB6Uxmabj59Iq(u"ࠬࡹࡥ࡯ࡦࡢࡷࡺࡩࡣࡦࡧࡧࡩࡩ࠭ႉ") in Sw0pOFoVhPeIxbl: bEZlOa1inyrUgdTw9BKNtcMCLYI = ndkUxG9LtewJ
	else: bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	if showDialogs:
		if bEZlOa1inyrUgdTw9BKNtcMCLYI:
			iRaHzNpJhSx6ZnCfrvD7j93lks(aYH620Dh48GEsTFfOBSQ7r(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩႊ"),TzIj50KpohEOHx6CbZWqB(u"ࠧࡔࡷࡦࡧࡪࡹࡳࠨႋ"))
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠧႌ"),Js61GTdX5wzMurUqi7Z(u"ࠩอ้ࠥหัิษ็ࠤฬ๊ัิษ็อࠥฮๆอษะႍࠫ"))
		else:
			iRaHzNpJhSx6ZnCfrvD7j93lks(E2QIcUfmlwa3xR17DFrkezBSsyh(u"่้ࠪษำโࠢไุ้ࠦวๅวิืฬ๊ࠧႎ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡋࡧࡩ࡭ࡷࡵࡩࠬႏ"))
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IO7k2hZXSz(u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ႐"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def yilKW1fr6qdBwRbAsu9():
	xFNW2M6ijZbhzuoHgPC0Ba = BWfpRku7SsM6cbE0eG(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡵࡴࡤࡲࡸࡲࡡࡵࡧࠣࡱࡪࡴࡵࠡ࡫ࡷࡩࡲࡹࠠࡵࡱࠣࡥࠥࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠠࡰࡶ࡫ࡩࡷࠦࡴࡩࡣࡱࠤࡆࡸࡡࡣ࡫ࡦࠤ࠳࠴ࠠࡐࡴࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡁࡳࡣࡥ࡭ࡨࠦ࡬ࡦࡶࡷࡩࡷࡹࠠࡢࡰࡧࠤࡹ࡫ࡸࡵࠢࡂࠥࠬ႑")
	N6yp1C9H8R = gDETKVh8mZe09Nd(u"่ࠧๆࠣฮึ๐ฯࠡฬิะ๊ฯࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡว็ํฺ๊ࠥสࠢฦาึ๏ࠠ฻์ิࠤฬู๊าสํอࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศ฼์อัࠡษ็วาืแ๊ࠡส่่ะวษหࠣห้฿ัษ์ฬࠤฤࠧࠧ႒")
	dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm = bP5mf0Mo2nz(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ႓"),EJgYdjbIiWe1apkQlZcR42(u"ࠩัีําࠠࡆࡺ࡬ࡸࠬ႔"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡘࡷࡧ࡮ࡴ࡮ࡤࡸࡪࠦสาฮ่อࠬ႕"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ฾ืศ๋ࠢࡄࡶࡦࡨࡩࡤࠩ႖"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,xFNW2M6ijZbhzuoHgPC0Ba+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡢ࡮࡝ࡰࠪ႗")+N6yp1C9H8R)
	if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm in [-Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠷቟"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠰በ")]: return
	elif dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲ቡ"):
		import E2mWUgOe8f
		E2mWUgOe8f.yHrwgZMOhjYPTXiJBx()
		return
	AAnySgavtB = ndkUxG9LtewJ
	while AAnySgavtB:
		AAnySgavtB = lvzrYTpcBaK
		message = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ลัษࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้ษอาใࠣห้฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠࠣว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠨࠠฬ็ࠣ฾๏ืࠠศๆั฻ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦลัษ่๊ࠣࠦสอัࠣห้ิืࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢไ฾๏ืࠠศๆฯ่ิࠦลๅ๋ࠣว๏ࠦฬๅัࠣฯฬ์๊ࠡใํ๋ࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠฬ็ࠣฬ฾ี็ศࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࡟ࡲࠥหะศࠢ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห่ࠣฬࠦสู้ิࠤ้้ࠠ࠯࠰ࠣหีํศࠡว็ํࠥࠨลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠦࠥ࠴࠮ࠡอ่ࠤ฿๐ัࠡว฼ำฬีวหࠢส่๊๎โฺࠢส่ัเัศใํࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣห้ศๆࠡใอัࠥࠨลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠦࠥลࠡࠨ႘")
		dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm = bP5mf0Mo2nz(SE97R3Dpj6dPLweVKU(u"ࠧࡤࡧࡱࡸࡪࡸࠧ႙"),jwzOabysh0Z(u"ࠨࡇࡻ࡭ࡹࠦฮา๊ฯࠫႚ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡜ࡩࡸࠦๆฺ็ࠪႛ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠤส์ฬๅ์ี๎ࠬႜ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ฾ีๅฺ๊ࠡ์ึࠦวๅละีๆ่ࠦศๆๆฮฬฮษࠡษ็฽ึฮ๊สࠩႝ"),message,profile=SIkwCEdJHTD9v1(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪ႞"))
		if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==gDETKVh8mZe09Nd(u"࠴ቢ"):
			message = bGzRdmOErkIylxALniq6(u"࠭ࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࡽࡩࡵࡪࠣࡅࡷࡧࡢࡪࡥࠣࡰࡪࡺࡴࡦࡴࡶࠤࡹ࡮ࡥ࡯ࠢࡲࡴࡪࡴࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࠰࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡨࡧ࡮࡝ࠩࡷࠤ࡫࡯࡮ࡥࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡪࡴࡴࡴࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡷࡰ࡯࡮ࠡࡶࡲࠤࡦࡴࡹࠡࡱࡷ࡬ࡪࡸࠠࡴ࡭࡬ࡲࠥࡺࡨࡢࡶࠣ࡬ࡦࡼࡥࠡ࡞ࠥࡅࡷ࡯ࡡ࡭࡞ࠥࠤ࡫ࡵ࡮ࡵࠢ࠱࠲ࠥࡇ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠢࡷࡳࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࡜࡯ࠢࡌࡪࠥࡇࡲࡢࡤ࡬ࡧࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡪࡵࠣࡲࡴࡺࠠࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣ࠲࠳ࠦࡔࡩࡧࡱࠤࡴࡶࡥ࡯ࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡴࡨ࡫࡮ࡵ࡮ࡢ࡮ࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡢ࡮࡝ࡰࠣࡈࡴࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡰࡲࡻࠥࡺ࡯ࠡࡱࡳࡩࡳࠦࡴࡩࡧࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡁࠤࠫ႟")
			dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm = bP5mf0Mo2nz(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡤࡧࡱࡸࡪࡸࠧႠ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡇࡻ࡭ࡹࠦฮา๊ฯࠫႡ"),IO7k2hZXSz(u"ࠩ࡜ࡩࡸࠦๆฺ็ࠪႢ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡅࡷࡧࡢࡪࡥࠣ฽ึฮ๊ࠨႣ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡒ࡯ࡳࡴ࡫ࡱ࡫ࠥࡇࡲࡢࡤ࡬ࡧࠥࡌ࡯࡯ࡶ࡚ࠣࠪࠥࡥࡹࡶࠪႤ"),message,profile=qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪႥ"))
			if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==gDETKVh8mZe09Nd(u"࠵ባ"): AAnySgavtB = ndkUxG9LtewJ
		if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==jwzOabysh0Z(u"࠵ቤ"): OJkvd6Ir0BznNZQPTH()
	return
def S3QYF7enwiv8yx0PV():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"ฺ࠭ศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠥ๎ไๅฬฦ็ิࠦโๆࠢหฮูเ๊ๅࠢส่ึอศุࠢส่ี๐ࠠๅษࠣ๎฾๋ไࠡอ่ࠤ็๋ࠠษวิืฬ๊ࠠๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠศๆๅหห๋ษࠡษ็ีห๐ำ๋ห่้ࠣฮั็ษ่ะࠬႦ"))
	return
def jgkrmTetQy9PEqR5ouF8VX7wiac():
	Iqm6XAWBlF = qeG16a4pbSHziNVQ2uFXrs(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦๅฯืุࠤๆ่ืࠡๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠๆๆ๊ࠥํะศࠢ็หࠥ๐ๅ็฻ࠣ์ั๎ฯࠡ็๋ห็฿ࠠโ์๊หࠥษแๅษ่ࠤํ๋ำๅี็หฯࠦๅหำฯ้ฮࠦร้่ࠢำอ๊ฬสࠢศ่๎ࠦวๅๆ฽อࠥอไฺำห๎ฮ่ࠦศๆ์ࠤ้เวหࠢสาึ๏้ࠠๆสࠤ๏๎ฬะࠢึฬอࠦไๅฬๆีฬืࠧႧ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
	return
def MMz02gPCtLQqZIRYn8aJoU7yAWSfTi():
	Iqm6XAWBlF = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨษ็ีํอศุࠢส่อ฽๊วห่ࠣฬูࠦๅษๅอ๊ࠥ็ศࠢหห้ฮั็ษ่ะࠥ๎ฺศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠬႨ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
	return
def xPiDA4XUSGIOJoldyrR():
	Iqm6XAWBlF = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭Ⴉ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬႪ"),Iqm6XAWBlF)
	return
def U1y9eVSkA0J5Bf4Yahp():
	Iqm6XAWBlF = RDwahqjPfbdyEiTtnLQu(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩႫ")
	ctjhP4l8L5pbwqZuQo3VYr(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬႬ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩႭ"))
	return
def HtvG3mYIKQ9BRJFhzcXC0frjySZq():
	xFNW2M6ijZbhzuoHgPC0Ba = IOHSz7YPF9WusGgUt1Dq(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨႮ")
	N6yp1C9H8R = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪႯ")
	D6kU7MfbGhxpWgB2CzlR1cqJs0 = aYH620Dh48GEsTFfOBSQ7r(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪႰ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,xFNW2M6ijZbhzuoHgPC0Ba,N6yp1C9H8R,D6kU7MfbGhxpWgB2CzlR1cqJs0)
	return
def uqkXOJBAitwLZfCoQsKPIdyV0Tj7zR():
	N6yp1C9H8R = bGzRdmOErkIylxALniq6(u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫႱ")
	N6yp1C9H8R += t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡡࡴ࡜࡯ࠩႲ") + SIkwCEdJHTD9v1(u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫႳ") + str(IfAkw39UvaYWEDXLthFrbSzG/Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠻࠶ብ")/Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠻࠶ብ")/Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠸࠴ቦ")/qqw1upCsKM(u"࠳࠱ቧ")) + aenpKvQCGVzhLXEdWiDIZ(u"࠭ࠠี้ิࠫႴ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࠳࠰ࠣะิอุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไๆใิ์฻ࠦร็้สࠤ้อࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭Ⴕ") + str(gQtzWRX97wZHiJ/t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠷࠲ቨ")/t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠷࠲ቨ")/t19ZOVHA4CpwFKaeiubcMGvz(u"࠴࠷ቩ")) + Js61GTdX5wzMurUqi7Z(u"ࠨࠢํ์๊࠭Ⴖ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭Ⴗ") + str(OOht4Ly9dmZMIz/XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠹࠴ቪ")/XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠹࠴ቪ")/aYH620Dh48GEsTFfOBSQ7r(u"࠶࠹ቫ")) + qqw1upCsKM(u"ࠪࠤ๏๎ๅࠨႸ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭Ⴙ") + str(NjPWfJS7CUoTsz4lKk0hg/IOHSz7YPF9WusGgUt1Dq(u"࠻࠶ቬ")/IOHSz7YPF9WusGgUt1Dq(u"࠻࠶ቬ")) + BWfpRku7SsM6cbE0eG(u"ࠬࠦำศ฻ฬࠫႺ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࠵࠯ࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤิอฦๆษࠣ์๊ีส่ࠢࠪႻ") + str(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2/oVwa0kcqxj1e7mLplAfZdGT(u"࠼࠰ቭ")/oVwa0kcqxj1e7mLplAfZdGT(u"࠼࠰ቭ")) + IOHSz7YPF9WusGgUt1Dq(u"ࠧࠡีส฽ฮ࠭Ⴜ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + Js61GTdX5wzMurUqi7Z(u"ࠨ࠸࠱ࠤัีวࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣ็ะ๐ัศ๋้ࠢิะ็ࠡࠩႽ") + str(xCE0toTumIHWiLyMfF/aenpKvQCGVzhLXEdWiDIZ(u"࠶࠱ቮ")) + phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࠣำ็๐โสࠩႾ")
	N6yp1C9H8R += slFfrUIWCowaBA7tce3iZbj8xn + XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬႿ") + str(UTCXGnK7Fs4Y5pNkt2ARDWuw) + jwzOabysh0Z(u"ࠫࠥีโ๋ไฬࠫჀ")
	N6yp1C9H8R += qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡢ࡮࡝ࡰࠪჁ") + jwzOabysh0Z(u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪჂ") + str(NjPWfJS7CUoTsz4lKk0hg/jwzOabysh0Z(u"࠷࠲ቯ")/jwzOabysh0Z(u"࠷࠲ቯ")) + EJgYdjbIiWe1apkQlZcR42(u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨჃ") + str(OOht4Ly9dmZMIz/jwzOabysh0Z(u"࠷࠲ቯ")/jwzOabysh0Z(u"࠷࠲ቯ")/fvYGxnZNUiyP4HJkMIoS25(u"࠴࠷ተ")) + zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧჄ") + str(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2/jwzOabysh0Z(u"࠷࠲ቯ")/jwzOabysh0Z(u"࠷࠲ቯ")) + IOHSz7YPF9WusGgUt1Dq(u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭Ⴥ") + str(xCE0toTumIHWiLyMfF/jwzOabysh0Z(u"࠷࠲ቯ")) + EJgYdjbIiWe1apkQlZcR42(u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬ჆") + str(UTCXGnK7Fs4Y5pNkt2ARDWuw) + sH6BOz5wKRFcEg(u"ࠫࠥีโ๋ไฬࠫჇ")
	ctjhP4l8L5pbwqZuQo3VYr(sH6BOz5wKRFcEg(u"ࠬࡸࡩࡨࡪࡷࠫ჈"),t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫ჉"),N6yp1C9H8R,BWfpRku7SsM6cbE0eG(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ჊"))
	return
def eeVDaAky74hHwXO9xl():
	Iqm6XAWBlF = oVwa0kcqxj1e7mLplAfZdGT(u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫ჋")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
	return
def liDPwqHeKdSzkojEUfO0A():
	Iqm6XAWBlF = BWfpRku7SsM6cbE0eG(u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪ჌")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
	return
def dekCi2uKQySYGnj8pV():
	Iqm6XAWBlF = qeG16a4pbSHziNVQ2uFXrs(u"ࠪห้เัืฺ่๊ࠢࠥ็ศัฬࠤฬ๊สีใํีࠥํุ่่ࠡห๋ࠦีฮหࠣ์ุื๊สࠢส่๊฿ไ้็สฮࠥอไๆฬหหิ๊ษࠡสํ๊ࠥอไษำ้ห๊า้ࠠษ็้ํู่ࠡษ็ู้็ั๊๊ࠡิฬࠦวๅุ่หฺ๋๋ࠦำ้ࠣ฼๊่ษ๋่ࠢฬࠦอศฮฬࠤ้ํฺ่ࠠาࠤฬ๊วหืส่ࠥอ่ࠡษ็ีอ฽ࠠๆ฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ืๅึฯࠧჍ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
	return
def xlYzAoJ1wUShHZij():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,EJgYdjbIiWe1apkQlZcR42(u"้้๊ࠫࠡ์฼้้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไโ์า๎ํํวหࠢ࡟ࡲࠥ๐ฬษࠢอๅ฾๐ไࠡวูหๆฯࠠศี่๋ฬࠦ࡜࡯ࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ჎"))
	oodkrSivUAOcRaIZEHQx32VL7bnX(GVurlv8HeoXEzPRiQB7Ty(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ჏"),ndkUxG9LtewJ)
	return
def Qfn18L2q56lzaUHg():
	Iqm6XAWBlF  = IO7k2hZXSz(u"࠭ๅละิห่ࠥวๆฬࠣฬ฾฼ࠠีำๆหฯࠦวๅว้ฮึ์สࠡษ็ำํ๊๊ࠡสฺ๋฾ูࠦศศๅࠤ฻ีࠠศๆหีฬ๋ฬࠡ็ฮ่้่ࠥะ์่ࠣฯูๅฮࠢไๆ฼ࠦไษ฻ูࠤู๊สฯั่๎ࠥอไๆฬุๅาࠦศศๆาาํ๊ࠠๅ็๋ห็฿ࠠศๆไ๎ิ๐่ࠨა")
	Iqm6XAWBlF += fvYGxnZNUiyP4HJkMIoS25(u"๊้ࠧࠡฮ๏าษࠡๆ๊ิฬࠦวๅ฻สส็ࠦแศ่๊ࠤฯ่ั๋สสࠤัฺ๋๊่ࠢืฯิฯๆ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡๆสࠤ๏ูสุ์฼์๋ࠦวๅัั์้ࠦไอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ัࠦอห๋้ࠣ฾ࠦวิฬัำฬ๋ࠧბ")
	Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+jwzOabysh0Z(u"ࠨโࠣࠤ࡛ࡖࡎࠡࠢฦ์ࠥࠦࡐࡳࡱࡻࡽࠥࠦร้ࠢࠣࡈࡓ࡙ࠠࠡล๋ࠤศ๐ࠠฮๆࠣฬุ๐ืࠡฤัีࠬგ")+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn
	Iqm6XAWBlF += fvYGxnZNUiyP4HJkMIoS25(u"ࠩ࡟ࡲ้อๆ้ࠡำห๊ࠥๆࠡ์ะ่ࠥอไๆึๆ่ฮ่ࠦฦ่่หࠥ็โุࠢึ๎็๎ๅࠡสศู้ออࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฦ฻สๆฮࠦๅ้ษๅ฽ࠥอฮา๋ࠣ็ฬ์สࠡฬ฼้้ࠦำศสๅหࠥฮฯู้่้ࠣอใๅࠩდ")
	ctjhP4l8L5pbwqZuQo3VYr(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡶ࡮࡭ࡨࡵࠩე"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧვ"))
	Iqm6XAWBlF = TzIj50KpohEOHx6CbZWqB(u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨზ")
	Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡡ࡬ࡱࡤࡱࠥࠦࡥࡨࡻࡥࡩࡸࡺࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠥࠦ࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠢࠣࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠢࠣࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬთ")+B8alA5nvIhTxQ
	Iqm6XAWBlF += BWfpRku7SsM6cbE0eG(u"ࠧ࡝ࡰ࡟ࡲࠬი")+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩკ")
	Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ู่ࠩึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัสࠫლ")+B8alA5nvIhTxQ
	Iqm6XAWBlF += hPFcB6Uxmabj59Iq(u"ࠪࡠࡳࡢ࡮ࠨმ")+YQNd4wejLSAVJ6T(u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬნ")
	Iqm6XAWBlF += VXWOCAE6ns3paJ8DLG479NQfMu+gDETKVh8mZe09Nd(u"ࠬอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อࠧო")+B8alA5nvIhTxQ
	ctjhP4l8L5pbwqZuQo3VYr(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡲࡪࡩ࡫ࡸࠬპ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF,SIkwCEdJHTD9v1(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪჟ"))
	return
def TPfqCyJx6F():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨრ"),TzIj50KpohEOHx6CbZWqB(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣีุอฦๅ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࠬს")+VXWOCAE6ns3paJ8DLG479NQfMu+Js61GTdX5wzMurUqi7Z(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࠬტ")+B8alA5nvIhTxQ+IOHSz7YPF9WusGgUt1Dq(u"ࠫࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣࠫუ")+VXWOCAE6ns3paJ8DLG479NQfMu+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫფ")+B8alA5nvIhTxQ)
	return
def a5a0tHPJWLQkdnz(showDialogs=ndkUxG9LtewJ):
	if not showDialogs: showDialogs = ndkUxG9LtewJ
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,Js61GTdX5wzMurUqi7Z(u"࠭ࡇࡆࡖࠪქ"),EJgYdjbIiWe1apkQlZcR42(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭ღ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫყ"))
	if not UHqibFEGL8fjKhI.succeeded:
		OCFUqPoudjLi7Kg2t1NG = lvzrYTpcBaK
		kS9s3KBpxE548V2 = qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(lvzrYTpcBaK)
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧშ")+kS9s3KBpxE548V2+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡡࠬჩ"))
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qqw1upCsKM(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨც"))
	else:
		OCFUqPoudjLi7Kg2t1NG = ndkUxG9LtewJ
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩძ"))
	if not OCFUqPoudjLi7Kg2t1NG and showDialogs: ccgBkbWj4nyDVNLRfJI7lixs2r()
	return OCFUqPoudjLi7Kg2t1NG
def ccgBkbWj4nyDVNLRfJI7lixs2r():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬწ"))
	fE8zgXQkwH7PeIl1a()
	return
def QiGkIR6Eys(T67f3LG49xpP8zcN=sCHVtMAvqirbQ4BUK3cgWo):
	KKOmR8SLlskcNxuPwqFtZhWa = ndkUxG9LtewJ
	if IO7k2hZXSz(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪჭ") not in T67f3LG49xpP8zcN:
		KKOmR8SLlskcNxuPwqFtZhWa = lvzrYTpcBaK
		KTxQcnwvOF0pqt = bP5mf0Mo2nz(aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨხ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩัีําࠧჯ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪษึูวๅุ่่๊ࠢษࠨჰ"),hPFcB6Uxmabj59Iq(u"ࠫสืำศๆࠣีุอไสࠩჱ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨჲ"))
		if KTxQcnwvOF0pqt in [-EJgYdjbIiWe1apkQlZcR42(u"࠴ቱ"),aYH620Dh48GEsTFfOBSQ7r(u"࠴ቲ")]: return
		elif KTxQcnwvOF0pqt==YQNd4wejLSAVJ6T(u"࠶ታ"):
			KKOmR8SLlskcNxuPwqFtZhWa = ndkUxG9LtewJ
			T67f3LG49xpP8zcN = Js61GTdX5wzMurUqi7Z(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩჳ")
	if KKOmR8SLlskcNxuPwqFtZhWa:
		if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧჴ") not in T67f3LG49xpP8zcN:
			bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(RDwahqjPfbdyEiTtnLQu(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨჵ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"ฺ๋ࠩ฾ࠦวๅ็ื็้ฯࠠโ์ࠣหู้ฬๅࠩჶ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠪๆอ๊ࠠฦำึห้ࠦวๅีฯ่ࠥ฿ไ๋ๅࠣว๋ࠦสไำิࠤࠥ์แิࠢส่ๆ฿ไࠡษ็ิ๏ࠦรฺูส็ࠥอไๆึๆ่ฮࠦ࠮ࠡๆๆ๎ࠥ๐สๆࠢอืั๐ไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ࠳่ࠦษั๋๊ࠥํะศࠢส่ฯูฬ๋ๆࠣืํ็ࠠหำึ่๋ࠥไโࠢ็หࠥ็ววัฬࠤ๊์็ࠡๆศ๊์ࠦไศࠢํัฯ๎๊ࠡ฻็ํࠥอไๆึๆ่ฮࠦวๅฬํࠤฯื๊ะࠢส๊ฯࠦวๅวห่ฬเฺ่๊ࠠหࠥ࠴่ࠠๆࠣๆ๊ะࠠษฬๆีฬืࠠศๆุ่่๊ษࠡมࠪჷ"))
			if bR4jqNrpMesHt93OgGKi6WDVaQA!=aYH620Dh48GEsTFfOBSQ7r(u"࠷ቴ"):
				ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧჸ"),IOHSz7YPF9WusGgUt1Dq(u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨჹ"))
				return
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"࠭แ๋ࠢสู่อิสࠢส่็อฯๆหࠣัฬ๎ไࠡล้ࠤฯ้สษࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ั่ࠦศึิัࠥ็๊่ษࠣห้๋ิไๆฬࠤศ๎ࠠศๆ่์฻๎ู๊ࠡศิฬࠦราัอࠤั๎วษ่๊ࠢࠥอไๆสิ้ัࠦแฦา้ࠤศ้สษࠢ฼๊ํอๆࠡสิ๎ิ้ࠠฤๆศ่่ะั้่ํࠤฬ๊ล๋็ํ่ࠥ๎สัๅิࠤํ๊วࠡฬ้ื๎ࠦร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪჺ"))
	Iqm6XAWBlF = UyBdvjGrFxDWMpmLOXn(header=jwzOabysh0Z(u"ࠧࡘࡴ࡬ࡸࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࠣࠤฬ้สษࠢิืฬ๊ษࠨ჻"),source=Ll1m0nJoaAPvHsXqyRE)
	if not Iqm6XAWBlF: return
	if KKOmR8SLlskcNxuPwqFtZhWa: type = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠩჼ")
	else: type = fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠪჽ")
	bEZlOa1inyrUgdTw9BKNtcMCLYI = XuLQaKS9RB4CxOYG5J0kMsNZnq6bFl(type,Iqm6XAWBlF,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡖࡕࡈࡖࡘ࠭ჾ"),T67f3LG49xpP8zcN)
	return
def Yq6eVtEZr8uR5dfwkic():
	T67f3LG49xpP8zcN = Js61GTdX5wzMurUqi7Z(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊้ࠦฮาࠤ้ํࠠฤ์ࠣื๏ืแาࠢํืฯ฼๊โࠢฦ๎๋ࠥอห๊ํหฯ࠴ࠠศๆหี๋อๅอࠢํืฯิฯๆࠢิ์ฬฮื๊ࠡอฺ๊๐ๆࠡๆ่ัฯ๎๊ศฬ้ࠣึ็ฺ่หࠣ฽้๏ࠠิ์ิๅึอสࠡะสีั๐ษ࠯ࠢส่อืๆศ็ฯࠤ฿๐ัࠡ็ึศํฺ๊่ࠠࠣว๏ࠦๅฮฬ๋๎ฬะࠠห็ࠣฮา๋๊ๅ้สࠤ฾๊้ࠡีํีๆืวห๋้ࠢํอโฺࠢัหึา๊ส้ࠢࠥํอโฺฺࠢีๆࠦหศๆฮࠦ࠳ࠦฬๆ์฼ࠤฬ๊ริ็สลࠥ๎วๅ็สี่อส๊ࠡสฺ่๎ั๊ࠡส่๊์ิ้ำสฮࠥํ๊ࠡะสูฮࠦศศืะหอํว࠯ࠢส่อืๆศ็ฯࠤ้อ๋่ࠠอ๋่ࠦอใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮࠦࡄࡎࡅࡄࠤสึวࠡๅส๊๊ࠥฯ๋ๅุ่ࠣ๎้ࠡะสูฮࠦศศๆิ์ฬฮื๊ࠡส่ฯ฼วๆ์้ࠤฬ๊ฮศำฯ๎ฮࠦแศๆิะฬวࠠศๆอ์ฬ฻ไࠡ็฼ࠤสีวาห๋ࠣีํࠠศๆึ๎ึ็ัศฬࠣ์ฬ๊ๅ้ษๅ฽ࠥอไฯษิะ๏ฯ࠮้ࠡำหࠥอไษำ้ห๊า่๊ࠠࠣฬอูวุห้ࠣฯ฻แฮࠢ็้ํอโฺࠢส่ํ๐ศࠨჿ")
	ctjhP4l8L5pbwqZuQo3VYr(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡸࡩࡨࡪࡷࠫᄀ"),GVurlv8HeoXEzPRiQB7Ty(u"࠭อใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮ࠭ᄁ"),T67f3LG49xpP8zcN,bGzRdmOErkIylxALniq6(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᄂ"))
	T67f3LG49xpP8zcN = hPFcB6Uxmabj59Iq(u"ࠨࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢ࡫ࡳࡸࡺࠠࡢࡰࡼࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡵ࡮ࠡࡣࡱࡽࠥࡹࡥࡳࡸࡨࡶ࠳ࠦࡉࡵࠢࡲࡲࡱࡿࠠࡶࡵࡨࡷࠥࡲࡩ࡯࡭ࡶࠤࡹࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡸ࡭ࡧࡴࠡࡹࡤࡷࠥࡻࡰ࡭ࡱࡤࡨࡪࡪࠠࡵࡱࠣࡴࡴࡶࡵ࡭ࡣࡵࠤࡴࡴ࡬ࡪࡰࡨࠤࡻ࡯ࡤࡦࡱࠣ࡬ࡴࡹࡴࡪࡰࡪࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡆࡲ࡬ࠡࡶࡵࡥࡩ࡫࡭ࡢࡴ࡮ࡷ࠱ࠦࡶࡪࡦࡨࡳࡸ࠲ࠠࡵࡴࡤࡨࡪࠦ࡮ࡢ࡯ࡨࡷ࠱ࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠ࡮ࡣࡵ࡯ࡸ࠲ࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࡨࡨࠥࡽ࡯ࡳ࡭࠯ࠤࡱࡵࡧࡰࡵࠣࡶࡪ࡬ࡥࡳࡧࡱࡧࡪࡪࠠࡩࡧࡵࡩ࡮ࡴࠠࡣࡧ࡯ࡳࡳ࡭ࠠࡵࡱࠣࡸ࡭࡫ࡩࡳࠢࡵࡩࡸࡶࡥࡤࡶ࡬ࡺࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡥࡲࡱࡵࡧ࡮ࡪࡧࡶ࠲࡚ࠥࡨࡦࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡶ࡭ࡧࡲࡥࠡࡨࡲࡶࠥࡽࡨࡢࡶࠣࡳࡹ࡮ࡥࡳࠢࡳࡩࡴࡶ࡬ࡦࠢࡸࡴࡱࡵࡡࡥࠢࡷࡳࠥ࠹ࡲࡥࠢࡳࡥࡷࡺࡹࠡࡵ࡬ࡸࡪࡹ࠮࡙ࠡࡨࠤࡺࡸࡧࡦࠢࡤࡰࡱࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡲࡻࡳ࡫ࡲࡴ࠮ࠣࡸࡴࠦࡲࡦࡥࡲ࡫ࡳ࡯ࡺࡦࠢࡷ࡬ࡦࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬ࡵࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡷࡪࡶ࡫࡭ࡳࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡧࡲࡦࠢ࡯ࡳࡨࡧࡴࡦࡦࠣࡷࡴࡳࡥࡸࡪࡨࡶࡪࠦࡥ࡭ࡵࡨࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࠡࡱࡵࠤࡻ࡯ࡤࡦࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡧࡲࡦࠢࡩࡶࡴࡳࠠࡰࡶ࡫ࡩࡷࠦࡶࡢࡴ࡬ࡳࡺࡹࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡧ࡮ࡺࠢ࡯ࡩ࡬ࡧ࡬ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡲ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡤࡴࡵࡸ࡯ࡱࡴ࡬ࡥࡹ࡫ࠠ࡮ࡧࡧ࡭ࡦࠦࡦࡪ࡮ࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡨࡰࡵࡷࡩࡷࡹ࠮ࠡࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡷ࡮ࡳࡰ࡭ࡻࠣࡥࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴ࠱ࠫᄃ")
	ctjhP4l8L5pbwqZuQo3VYr(SE97R3Dpj6dPLweVKU(u"ࠩ࡯ࡩ࡫ࡺࠧᄄ"),TzIj50KpohEOHx6CbZWqB(u"ࠪࡈ࡮࡭ࡩࡵࡣ࡯ࠤࡒ࡯࡬࡭ࡧࡱࡲ࡮ࡻ࡭ࠡࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤࡆࡩࡴࠡࠪࡇࡑࡈࡇࠩࠨᄅ"),T67f3LG49xpP8zcN,GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᄆ"))
	return
def i7IW3RVZvoM4T0QXtjJlda():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Js61GTdX5wzMurUqi7Z(u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪᄇ"))
	dekCi2uKQySYGnj8pV()
	return
def psXWD1dSP0hxoBmgkCyTb7FO():
	k2YJCTI6lsPzXg = {}
	gApJuUn2WDPB5eijdVQ,w9kcLzVGXJ0eoy2xMaqgE,XTHzomFv7kW1LPhMad = Jha2IH6oq0uNl98sTXi3mbfDRZ(lvzrYTpcBaK)
	xFNW2M6ijZbhzuoHgPC0Ba,N6yp1C9H8R,D6kU7MfbGhxpWgB2CzlR1cqJs0,W3AlVjrGIZ6Q1u2awYNPLcpRgvyX,W9cPXtTLG526Orzaf0,f4JRZCXeoStl8bcEQVLHz,VvWkqGJniDN5tySZlx = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	xFNW2M6ijZbhzuoHgPC0Ba = LvzD9S8RPyGeukZQqb2T0B.join(w9kcLzVGXJ0eoy2xMaqgE)
	N6yp1C9H8R = LvzD9S8RPyGeukZQqb2T0B.join(XTHzomFv7kW1LPhMad)
	oowKA39k4BIRuT5QMn6,iQnZbGqywo8xYtJpfm51k9AaF,sxFd3Dga7n21vwtGAj0frR8 = gApJuUn2WDPB5eijdVQ
	for oT2iHwjfBx0FPX5ZCph9aWs38,xgStGd8hXZ4QrJfsvWYImceF,za6gw5tnfGs02liq in iQnZbGqywo8xYtJpfm51k9AaF:
		za6gw5tnfGs02liq = EEH4kBfGY0FuZUjeNn(za6gw5tnfGs02liq)
		za6gw5tnfGs02liq = za6gw5tnfGs02liq.strip(AAh0X3OCacr4HpifRGLZKT).strip(IOHSz7YPF9WusGgUt1Dq(u"࠭ࠠ࠯ࠩᄈ"))
		qCDt2dG9EZ6pXskxnMUK3cw = oT2iHwjfBx0FPX5ZCph9aWs38.replace(SE97R3Dpj6dPLweVKU(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᄉ"),IO7k2hZXSz(u"ࠨࡃࡓࡍࠬᄊ"))
		W3AlVjrGIZ6Q1u2awYNPLcpRgvyX += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+qCDt2dG9EZ6pXskxnMUK3cw+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࠽ࠤࠬᄋ")+B8alA5nvIhTxQ+za6gw5tnfGs02liq+slFfrUIWCowaBA7tce3iZbj8xn
		if xgStGd8hXZ4QrJfsvWYImceF.isdigit(): k2YJCTI6lsPzXg[oT2iHwjfBx0FPX5ZCph9aWs38] = int(xgStGd8hXZ4QrJfsvWYImceF)
	cdxXe8sIEKFTnZOPoLwC,lSmoZnRN6CDauAPi1vHIg9VO,vck6hZoRHUxy8e1iSNnf3ld0gWGJ = list(zip(*iQnZbGqywo8xYtJpfm51k9AaF))
	for oT2iHwjfBx0FPX5ZCph9aWs38 in sorted(P0SFzyBJp94qMnNH3hQ1aDfZT82x):
		if oT2iHwjfBx0FPX5ZCph9aWs38 not in cdxXe8sIEKFTnZOPoLwC:
			W3AlVjrGIZ6Q1u2awYNPLcpRgvyX += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+oT2iHwjfBx0FPX5ZCph9aWs38+jwzOabysh0Z(u"ࠪ࠾ࠥ࠭ᄌ")+B8alA5nvIhTxQ+XxE4VAKW7LQzdk2Il3gUr1vwn(u"้ࠫอ๋๊ࠠฯำࠬᄍ")+slFfrUIWCowaBA7tce3iZbj8xn
			if oT2iHwjfBx0FPX5ZCph9aWs38 not in Q1siCkTZyw.non_videos_actions: D6kU7MfbGhxpWgB2CzlR1cqJs0 += LvzD9S8RPyGeukZQqb2T0B+oT2iHwjfBx0FPX5ZCph9aWs38
	for za6gw5tnfGs02liq,ffpXyPnsrkNAgIq in oowKA39k4BIRuT5QMn6:
		za6gw5tnfGs02liq = EEH4kBfGY0FuZUjeNn(za6gw5tnfGs02liq)
		W9cPXtTLG526Orzaf0 += za6gw5tnfGs02liq+YQNd4wejLSAVJ6T(u"ࠬࡀࠠࠨᄎ")+VXWOCAE6ns3paJ8DLG479NQfMu+str(ffpXyPnsrkNAgIq)+B8alA5nvIhTxQ+OUmtsIB1zyF
	xFNW2M6ijZbhzuoHgPC0Ba = xFNW2M6ijZbhzuoHgPC0Ba.strip(AAh0X3OCacr4HpifRGLZKT)
	N6yp1C9H8R = N6yp1C9H8R.strip(AAh0X3OCacr4HpifRGLZKT)
	D6kU7MfbGhxpWgB2CzlR1cqJs0 = D6kU7MfbGhxpWgB2CzlR1cqJs0.strip(AAh0X3OCacr4HpifRGLZKT)
	x5xRmbLfZiNMdWrwUH6pz7og29DB = xFNW2M6ijZbhzuoHgPC0Ba+RDwahqjPfbdyEiTtnLQu(u"࠭ࠠࠡ࠰࠱ࠤࠥ࠭ᄏ")+N6yp1C9H8R
	hJa6B8OyePM97A4  = TzIj50KpohEOHx6CbZWqB(u"ࠧๆ๊สๆ฾ࠦฬ๋ัฬࠤูเไࠡษ็ฬึ์วๆฮ้๋ࠣํวࠡใํำ๏๎็ศฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠࠩ็้ࠤฬ๊รไอิࠤส๊้ࠡษ็ว็๊ࠩࠨᄐ")+slFfrUIWCowaBA7tce3iZbj8xn+RDwahqjPfbdyEiTtnLQu(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋้่ࠤๆํ๊ࠡ็้ࠤ฾์ฯไ๋่ࠢ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั่ࠦๅษ้๋ࠣࠦวๅ็๋ๆ฾࠭ᄑ")+slFfrUIWCowaBA7tce3iZbj8xn
	hJa6B8OyePM97A4 += VXWOCAE6ns3paJ8DLG479NQfMu+x5xRmbLfZiNMdWrwUH6pz7og29DB+B8alA5nvIhTxQ+aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࡟ࡲࡡࡴࠧᄒ")
	hJa6B8OyePM97A4 += YQNd4wejLSAVJ6T(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆ้๋ࠣํวࠡษ็ฬึ์วๆฮࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊ส้ࠢࠫึะศสࠢฦฬัี๊ࠪࠩᄓ")+slFfrUIWCowaBA7tce3iZbj8xn+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไ๊ࠡฯ์ิࠦๅีๅ็อࠥ฿ๆะๅࠣวํࠦแ๋ࠢส่๊๎โฺࠢฦ์ࠥ็๊ࠡษ็ฬึ์วๆฮࠪᄔ")+slFfrUIWCowaBA7tce3iZbj8xn
	D6kU7MfbGhxpWgB2CzlR1cqJs0 = LvzD9S8RPyGeukZQqb2T0B.join(sorted(D6kU7MfbGhxpWgB2CzlR1cqJs0.split(LvzD9S8RPyGeukZQqb2T0B)))
	hJa6B8OyePM97A4 += VXWOCAE6ns3paJ8DLG479NQfMu+D6kU7MfbGhxpWgB2CzlR1cqJs0+B8alA5nvIhTxQ
	TTUq8fCJFYp2ouiEzjtWSeZHKQB01,mvwdLU67KPg,ZEbWLP7cxhBl4z83FNT,Ow1ntKvQufTbPH6FB8AECR9Mc = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠰ት"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠰ት"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠰ት"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠰ት")
	all = k2YJCTI6lsPzXg[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡇࡌࡍࠩᄕ")]
	if Js61GTdX5wzMurUqi7Z(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᄖ") in list(k2YJCTI6lsPzXg.keys()): TTUq8fCJFYp2ouiEzjtWSeZHKQB01 = k2YJCTI6lsPzXg[sH6BOz5wKRFcEg(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᄗ")]
	if hPFcB6Uxmabj59Iq(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩᄘ") in list(k2YJCTI6lsPzXg.keys()): mvwdLU67KPg = k2YJCTI6lsPzXg[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪᄙ")]
	if qqw1upCsKM(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧᄚ") in list(k2YJCTI6lsPzXg.keys()): ZEbWLP7cxhBl4z83FNT = k2YJCTI6lsPzXg[gDETKVh8mZe09Nd(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨᄛ")]
	if fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡘࡅࡑࡑࡖࠫᄜ") in list(k2YJCTI6lsPzXg.keys()): Ow1ntKvQufTbPH6FB8AECR9Mc = k2YJCTI6lsPzXg[sH6BOz5wKRFcEg(u"࠭ࡒࡆࡒࡒࡗࠬᄝ")]
	uuSKFrbiJRIlDUqnNzcf = all-TTUq8fCJFYp2ouiEzjtWSeZHKQB01-mvwdLU67KPg-ZEbWLP7cxhBl4z83FNT-Ow1ntKvQufTbPH6FB8AECR9Mc
	qLbRrEtgenpSi,cLpvq2zDPdnRgM6lbZiY = sxFd3Dga7n21vwtGAj0frR8[BewrUo9ANCa17G43Sn0LH5xh]
	qLbRrEtgenpSi,AoC9uHc5qaJVEd8UOGSZXKeQzIPY = sxFd3Dga7n21vwtGAj0frR8[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	ppeN3Ba1t8qhuTZmr7HIdfkWA6b = cLpvq2zDPdnRgM6lbZiY-AoC9uHc5qaJVEd8UOGSZXKeQzIPY
	VvWkqGJniDN5tySZlx += F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(AoC9uHc5qaJVEd8UOGSZXKeQzIPY)+B8alA5nvIhTxQ+EJgYdjbIiWe1apkQlZcR42(u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫᄞ")
	VvWkqGJniDN5tySZlx += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(ppeN3Ba1t8qhuTZmr7HIdfkWA6b)+B8alA5nvIhTxQ+aYH620Dh48GEsTFfOBSQ7r(u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬᄟ")
	VvWkqGJniDN5tySZlx += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(cLpvq2zDPdnRgM6lbZiY)+B8alA5nvIhTxQ+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪᄠ")
	VvWkqGJniDN5tySZlx += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(len(sxFd3Dga7n21vwtGAj0frR8[TzIj50KpohEOHx6CbZWqB(u"࠳ቶ"):]))+B8alA5nvIhTxQ+IO7k2hZXSz(u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨᄡ")
	for AAegc4nriYPDjplE2FToBqG5xsWv,qtWgRvai4wjFumUCLMH in sxFd3Dga7n21vwtGAj0frR8[IOHSz7YPF9WusGgUt1Dq(u"࠴ቷ"):]:
		AAegc4nriYPDjplE2FToBqG5xsWv = EEH4kBfGY0FuZUjeNn(AAegc4nriYPDjplE2FToBqG5xsWv)
		AAegc4nriYPDjplE2FToBqG5xsWv = AAegc4nriYPDjplE2FToBqG5xsWv.strip(AAh0X3OCacr4HpifRGLZKT).strip(bGzRdmOErkIylxALniq6(u"ࠫࠥ࠴ࠧᄢ"))
		VvWkqGJniDN5tySZlx += AAegc4nriYPDjplE2FToBqG5xsWv+Js61GTdX5wzMurUqi7Z(u"ࠬࡀࠠࠨᄣ")+VXWOCAE6ns3paJ8DLG479NQfMu+str(qtWgRvai4wjFumUCLMH)+B8alA5nvIhTxQ+TzIj50KpohEOHx6CbZWqB(u"࠭ࠠࠡࠢࠪᄤ")
	f4JRZCXeoStl8bcEQVLHz += F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(uuSKFrbiJRIlDUqnNzcf)+B8alA5nvIhTxQ+TzIj50KpohEOHx6CbZWqB(u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬᄥ")
	f4JRZCXeoStl8bcEQVLHz += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(TTUq8fCJFYp2ouiEzjtWSeZHKQB01)+B8alA5nvIhTxQ+EJgYdjbIiWe1apkQlZcR42(u"ࠨู็ฬฬะࠠิ์ิๅึࠦࡁࡑࡋࠣ࠾ࠥ࠭ᄦ")
	f4JRZCXeoStl8bcEQVLHz += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(Ow1ntKvQufTbPH6FB8AECR9Mc)+B8alA5nvIhTxQ+t19ZOVHA4CpwFKaeiubcMGvz(u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่ืฯ๎ฯฺࠢ࠽ࠤࠬᄧ")
	f4JRZCXeoStl8bcEQVLHz += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(mvwdLU67KPg)+B8alA5nvIhTxQ+RDwahqjPfbdyEiTtnLQu(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧᄨ")
	f4JRZCXeoStl8bcEQVLHz += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(ZEbWLP7cxhBl4z83FNT)+B8alA5nvIhTxQ+SE97R3Dpj6dPLweVKU(u"ࠫฯัศ๋ฬࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠻ࠢࠪᄩ")
	f4JRZCXeoStl8bcEQVLHz += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+str(len(oowKA39k4BIRuT5QMn6))+B8alA5nvIhTxQ+EJgYdjbIiWe1apkQlZcR42(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬᄪ")
	f4JRZCXeoStl8bcEQVLHz += phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࡜࡯࡞ࡱࠫᄫ")+W9cPXtTLG526Orzaf0
	ctjhP4l8L5pbwqZuQo3VYr(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄬ"),qqw1upCsKM(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩᄭ"),f4JRZCXeoStl8bcEQVLHz,Js61GTdX5wzMurUqi7Z(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᄮ"))
	ctjhP4l8L5pbwqZuQo3VYr(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡧࡪࡴࡴࡦࡴࠪᄯ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧᄰ"),hJa6B8OyePM97A4,aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᄱ"))
	ctjhP4l8L5pbwqZuQo3VYr(gDETKVh8mZe09Nd(u"࠭࡬ࡦࡨࡷࠫᄲ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩᄳ"),W3AlVjrGIZ6Q1u2awYNPLcpRgvyX,GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩᄴ"))
	return
def ihcSPjLvJTGQCV621lD0BdymRs():
	Iqm6XAWBlF = hPFcB6Uxmabj59Iq(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱࠫᄵ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+gDETKVh8mZe09Nd(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᄶ")+B8alA5nvIhTxQ+SE97R3Dpj6dPLweVKU(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳ࠭ᄷ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+BWfpRku7SsM6cbE0eG(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠭ᄸ")+B8alA5nvIhTxQ+SIkwCEdJHTD9v1(u"࠭࡜࡯࡞ࡱࡠࡳࠦ็ั้ࠣห้ืำศๆฬࠤํเ๊า้สࠤ่ั๊า่ࠢ์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤฺ๐ว็หࠣห้ฮั็ษ่ะࠥ๎วๅ็ี๎ิࠦรุ๋สࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อู๋ࠥๅ๊่หฯࠦวๅสิ๊ฬ๋ฬࠨᄹ")
	ctjhP4l8L5pbwqZuQo3VYr(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄺ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF,TzIj50KpohEOHx6CbZWqB(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᄻ"))
	return
def os617uvdNSDGn():
	Iqm6XAWBlF = aenpKvQCGVzhLXEdWiDIZ(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧᄼ")+slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+Q1siCkTZyw.SITESURLS[sH6BOz5wKRFcEg(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩᄽ")][BewrUo9ANCa17G43Sn0LH5xh]+B8alA5nvIhTxQ+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠨᄾ")+VXWOCAE6ns3paJ8DLG479NQfMu+Q1siCkTZyw.SITESURLS[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫᄿ")][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]+B8alA5nvIhTxQ
	Iqm6XAWBlF += Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳ࠭ᅀ")+VXWOCAE6ns3paJ8DLG479NQfMu+Q1siCkTZyw.SITESURLS[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭ᅁ")][BewrUo9ANCa17G43Sn0LH5xh]+B8alA5nvIhTxQ+YQNd4wejLSAVJ6T(u"ࠨࠢࠣࠤࠥษ่ࠡࠢࠣࠤࠬᅂ")+VXWOCAE6ns3paJ8DLG479NQfMu+Q1siCkTZyw.SITESURLS[oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨᅃ")][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]+B8alA5nvIhTxQ
	Iqm6XAWBlF += TzIj50KpohEOHx6CbZWqB(u"ࠪࡠࡳࡢ࡮࡝ࡰฯ้๏฿ࠠๆๆไหฯูࠦๆษาࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆ่์็฿ࠠฤั้ห์࠭ᅄ")+slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+Q1siCkTZyw.SITESURLS[gDETKVh8mZe09Nd(u"ࠫࡋࡏࡌࡆࡕࡢࡗࡔ࡛ࡒࡄࡇࡖࠫᅅ")][BewrUo9ANCa17G43Sn0LH5xh]+B8alA5nvIhTxQ
	ctjhP4l8L5pbwqZuQo3VYr(qqw1upCsKM(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᅆ"),SE97R3Dpj6dPLweVKU(u"࠭วๅ็๋ห็฿ࠠศๆิื๊๐ษࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬᅇ"),Iqm6XAWBlF,SE97R3Dpj6dPLweVKU(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᅈ"))
	return
def XHLbq3IhMj9d5oTyUG7nktSY4a2(yb6eMXdsvGY4pJCQE9WtP5DBqzf1jR):
	FoiwfTEhGD8ulS25HeUvnI.executebuiltin(TzIj50KpohEOHx6CbZWqB(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠧᅉ")+yb6eMXdsvGY4pJCQE9WtP5DBqzf1jR+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࠬࠫᅊ"), ndkUxG9LtewJ)
	return
def OJkvd6Ir0BznNZQPTH():
	AA6xmFYBTg2kfJ0Q9t5PNrWs(TzIj50KpohEOHx6CbZWqB(u"ࠪࡷࡹࡵࡰࠨᅋ"))
	FoiwfTEhGD8ulS25HeUvnI.executebuiltin(qeG16a4pbSHziNVQ2uFXrs(u"ࠦࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࡔࡧࡷࡸ࡮ࡴࡧࡴࠫࠥᅌ"))
	return
def T5evpuMhmoI3y():
	FoiwfTEhGD8ulS25HeUvnI.executebuiltin(sH6BOz5wKRFcEg(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠬࠫᅍ"), ndkUxG9LtewJ)
	return
def ct2pq8FlO6waebmx7TLPoi():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭ᅎ"))
	return
def BX1P8uClS5oftpjbmHdncN():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ์โาࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࠪᅏ"))
	return
def Y1mZSo9Wuhv(vSG3AQKU8J0VtEz=IOHSz7YPF9WusGgUt1Dq(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᅐ"),showDialogs=ndkUxG9LtewJ):
	KILF7s4vrwlacS89W = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(jwzOabysh0Z(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬᅑ"))
	data = Kdnrl9JHV0cFaGzC5bN.loads(KILF7s4vrwlacS89W)
	NZqK2Brit3f8oyd = data[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᅒ")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡻࡧ࡬ࡶࡧࠪᅓ")]
	if qdUK5ioJyrO1T: NZqK2Brit3f8oyd = NZqK2Brit3f8oyd.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,sH6BOz5wKRFcEg(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪᅔ")+NZqK2Brit3f8oyd+RDwahqjPfbdyEiTtnLQu(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨᅕ")+vSG3AQKU8J0VtEz+fvYGxnZNUiyP4HJkMIoS25(u"ࠧࠡมࠤࠫᅖ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=IOHSz7YPF9WusGgUt1Dq(u"࠴ቸ"): return lvzrYTpcBaK
	bEZlOa1inyrUgdTw9BKNtcMCLYI,QOkDW1VMTgYP4wLeibCxaNpSRKqy,An45kqNI8dr9o = hdtaWARbFnsvxlfCIL8(vSG3AQKU8J0VtEz,lvzrYTpcBaK,lvzrYTpcBaK)
	if bEZlOa1inyrUgdTw9BKNtcMCLYI:
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪᅗ"))
		YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(SE97R3Dpj6dPLweVKU(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭ᅘ")+vSG3AQKU8J0VtEz+sH6BOz5wKRFcEg(u"ࠪࠦࢂࢃࠧᅙ"))
		bEZlOa1inyrUgdTw9BKNtcMCLYI = ndkUxG9LtewJ if BWfpRku7SsM6cbE0eG(u"ࠫࡔࡑࠧᅚ") in YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z else lvzrYTpcBaK
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(aYH620Dh48GEsTFfOBSQ7r(u"࠵ቹ"))
		FoiwfTEhGD8ulS25HeUvnI.executebuiltin(SIkwCEdJHTD9v1(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬᅛ"))
	elif showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,TzIj50KpohEOHx6CbZWqB(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨᅜ"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def fE8zgXQkwH7PeIl1a():
	url = bGzRdmOErkIylxALniq6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬᅝ")
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,gDETKVh8mZe09Nd(u"ࠨࡉࡈࡘࠬᅞ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬᅟ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	NHSEdQ9TrzFh0sK5tx = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩᅠ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	NHSEdQ9TrzFh0sK5tx = NHSEdQ9TrzFh0sK5tx[BewrUo9ANCa17G43Sn0LH5xh].split(hPFcB6Uxmabj59Iq(u"ࠫ࠲࠭ᅡ"))[BewrUo9ANCa17G43Sn0LH5xh]
	vQD0Pp7L4dcTaZu = str(A4AOrGi8QL)
	W3AlVjrGIZ6Q1u2awYNPLcpRgvyX = GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧᅢ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+NHSEdQ9TrzFh0sK5tx+B8alA5nvIhTxQ
	W3AlVjrGIZ6Q1u2awYNPLcpRgvyX += BWfpRku7SsM6cbE0eG(u"࠭࡜࡯࡞ࡱࠫᅣ")+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᅤ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+vQD0Pp7L4dcTaZu+B8alA5nvIhTxQ
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,W3AlVjrGIZ6Q1u2awYNPLcpRgvyX)
	return
def SCVues5Z1MXwdNf():
	CaGgk4EYc1u,GkYEBR09J3uoO,qwi3JEdpkre5zoAuD4cxWLsf6 = lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	wOxaW0ANE4eyFBVzdDU5qoK,n5ypta1qUAdGWB4cPfYeVzox,BBIphvQdZ6F = lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	ZQtAwbhVH5kToe1lSC0zdgysi = [phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᅥ"),YQNd4wejLSAVJ6T(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᅦ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᅧ")]
	MyeJZzh0Q8RYL2U6 = nPkDNvLX7xircVpzhsGKW(ZQtAwbhVH5kToe1lSC0zdgysi)
	for Xkp839QMmYzrsoWTyca in ZQtAwbhVH5kToe1lSC0zdgysi:
		if Xkp839QMmYzrsoWTyca not in list(MyeJZzh0Q8RYL2U6.keys()): continue
		gahvbG5HU6K2,jBLdhuUa7iOPYT20SMvgq1FtH9Rl,TGnRrvw6jEd5egaU,HFeWmMp7oDBZn,m2mLEiued649gFS0X,BpgvYo1ac5IZz8,tNVIYvLuPnhc4AJHQesUbk6CyXjMow = MyeJZzh0Q8RYL2U6[Xkp839QMmYzrsoWTyca]
		if Xkp839QMmYzrsoWTyca==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩᅨ"):
			wOxaW0ANE4eyFBVzdDU5qoK = gahvbG5HU6K2
			n5ypta1qUAdGWB4cPfYeVzox = jBLdhuUa7iOPYT20SMvgq1FtH9Rl+hPFcB6Uxmabj59Iq(u"ࠬࠦࠠࠡࠢࠫࠤࠬᅩ")+g7k6hjSBrX4oOElJW59c2bUZpMquw(BpgvYo1ac5IZz8)+SE97R3Dpj6dPLweVKU(u"࠭ࠠࠪࠩᅪ")
			BBIphvQdZ6F = HFeWmMp7oDBZn
		elif Xkp839QMmYzrsoWTyca==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩᅫ"):
			CaGgk4EYc1u = CaGgk4EYc1u or gahvbG5HU6K2
			GkYEBR09J3uoO += E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࠢࠣ࠰ࠥࠦࠧᅬ")+jBLdhuUa7iOPYT20SMvgq1FtH9Rl+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࠣࠤࠥࠦࠨࠡࠩᅭ")+g7k6hjSBrX4oOElJW59c2bUZpMquw(BpgvYo1ac5IZz8)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࠤ࠮࠭ᅮ")
			qwi3JEdpkre5zoAuD4cxWLsf6 += aYH620Dh48GEsTFfOBSQ7r(u"ࠫࠥࠦࠬࠡࠢࠪᅯ")+HFeWmMp7oDBZn
		elif Xkp839QMmYzrsoWTyca==aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᅰ"):
			AsSdUfbonZxOD8eIkRipu74 = gahvbG5HU6K2
			uuK7CWvZQA1bHI6NwLUTlFahsne = jBLdhuUa7iOPYT20SMvgq1FtH9Rl+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠠࠡࠢࠣࠬࠥ࠭ᅱ")+g7k6hjSBrX4oOElJW59c2bUZpMquw(BpgvYo1ac5IZz8)+qeG16a4pbSHziNVQ2uFXrs(u"ࠧࠡࠫࠪᅲ")
			PYAzwWdQGkm9jLD = HFeWmMp7oDBZn
	GkYEBR09J3uoO = GkYEBR09J3uoO.strip(TzIj50KpohEOHx6CbZWqB(u"ࠨࠢࠣ࠰ࠥࠦࠧᅳ"))
	qwi3JEdpkre5zoAuD4cxWLsf6 = qwi3JEdpkre5zoAuD4cxWLsf6.strip(RDwahqjPfbdyEiTtnLQu(u"ࠩࠣࠤ࠱ࠦࠠࠨᅴ"))
	fSHCW2FmqlKVN  = bGzRdmOErkIylxALniq6(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨᅵ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+BBIphvQdZ6F+B8alA5nvIhTxQ
	fSHCW2FmqlKVN += slFfrUIWCowaBA7tce3iZbj8xn+EJgYdjbIiWe1apkQlZcR42(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไษำ้ห๊าฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᅶ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+n5ypta1qUAdGWB4cPfYeVzox+B8alA5nvIhTxQ
	fSHCW2FmqlKVN += E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡢ࡮࡝ࡰࠪᅷ")+zLjWeKu6JgNO7vocUD0Qpy(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫᅸ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+qwi3JEdpkre5zoAuD4cxWLsf6+B8alA5nvIhTxQ
	fSHCW2FmqlKVN += slFfrUIWCowaBA7tce3iZbj8xn+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩᅹ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+GkYEBR09J3uoO+B8alA5nvIhTxQ
	fSHCW2FmqlKVN += oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࡞ࡱࡠࡳ࠭ᅺ")+Js61GTdX5wzMurUqi7Z(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᅻ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+PYAzwWdQGkm9jLD+B8alA5nvIhTxQ
	fSHCW2FmqlKVN += slFfrUIWCowaBA7tce3iZbj8xn+YQNd4wejLSAVJ6T(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫᅼ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+uuK7CWvZQA1bHI6NwLUTlFahsne+B8alA5nvIhTxQ
	gahvbG5HU6K2 = wOxaW0ANE4eyFBVzdDU5qoK or CaGgk4EYc1u
	if gahvbG5HU6K2:
		header = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫฬ๊ัอษฤࠤฯำฯ๋อࠣษ฻อแศฬࠣ็ํี๊ࠡๆะ่ࠥอไๆึส็้࠭ᅽ")
		pnXGs1DmPvYJE2SliMLB = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬอๆหࠢหัฬาษࠡๆอัิ๐หࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร้ࠢอัิ๐หࠡ็ึฮํีูࠡ฻่หิ࠭ᅾ")
	else:
		header = aenpKvQCGVzhLXEdWiDIZ(u"࠭อศๆํห๊ࠥวࠡ์๋ะิࠦสฮัํฯฬะࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦร้่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧᅿ")
		pnXGs1DmPvYJE2SliMLB = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧศๆิะฬวࠠฦส็ห฿ࠦวๅ็หี๊าฺ่ࠠࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอ์ฬา็ไࠩᆀ")
	yzQK57YoRave9u0TGlJWA8MNrU2 = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣ฽๋ีใࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ๏าศࠡล้ࠤ๏้่็ࠢ็ำ๏้ࠠโ์ࠣ็ํี๊࡝ࡰ่ืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩᆁ")
	Z69c1xJwW27UR = fSHCW2FmqlKVN+Js61GTdX5wzMurUqi7Z(u"ࠩ࡟ࡲࡡࡴࠧᆂ")+pnXGs1DmPvYJE2SliMLB+TzIj50KpohEOHx6CbZWqB(u"ࠪࡠࡳࡢ࡮ࠨᆃ")+yzQK57YoRave9u0TGlJWA8MNrU2
	ctjhP4l8L5pbwqZuQo3VYr(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡷ࡯ࡧࡩࡶࠪᆄ"),header,Z69c1xJwW27UR,oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᆅ"))
	return gahvbG5HU6K2
def YYISwoJk4KhWc(Xkp839QMmYzrsoWTyca,tNVIYvLuPnhc4AJHQesUbk6CyXjMow,showDialogs):
	bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,TzIj50KpohEOHx6CbZWqB(u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฻เุ่ࠢ็่ส฼วโหࠣห้๋ืๅ๊หอ๊ࠥใ๋ࠢํฮ๊ࠦสฬสํฮ์ูࠦๅ๋ࠣ็ํี๊ࠡ࠰ࠣห้๋ไโࠢๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠢࠩᆆ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return lvzrYTpcBaK
	sJzRAZFi5TvNPVM4e0E2d = RDrfnwmMg8EblLCXFzBV0O6(tNVIYvLuPnhc4AJHQesUbk6CyXjMow,{},showDialogs)
	if sJzRAZFi5TvNPVM4e0E2d:
		CwTd7rY3Se0tK2sxLZl = YYEXZsUWhf52vz7HLxc0qGJ.path.join(Tv3HwUmSdkPOKaC5QulpJcDqy,Xkp839QMmYzrsoWTyca)
		W0BFzMOVpdNxnmer5aZfs(CwTd7rY3Se0tK2sxLZl,ndkUxG9LtewJ,lvzrYTpcBaK)
		import zipfile as NOUZz3GtaIKpsqhn,io as tDI0v86ReViT9Ou7XsEL24W1kG
		K89HuxNGBqU74LnDj = tDI0v86ReViT9Ou7XsEL24W1kG.BytesIO(sJzRAZFi5TvNPVM4e0E2d)
		try:
			QdRjomsgn9ZXlzcuSv30CNa = NOUZz3GtaIKpsqhn.ZipFile(K89HuxNGBqU74LnDj)
			QdRjomsgn9ZXlzcuSv30CNa.extractall(Tv3HwUmSdkPOKaC5QulpJcDqy)
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫᆇ"))
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			bEZlOa1inyrUgdTw9BKNtcMCLYI = LXC6NZ3rfqtF2heQjSnWuHK9Y71oA(Xkp839QMmYzrsoWTyca)
		except: bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	if showDialogs:
		if bEZlOa1inyrUgdTw9BKNtcMCLYI: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬᆈ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IO7k2hZXSz(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧᆉ"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def oodkrSivUAOcRaIZEHQx32VL7bnX(Xkp839QMmYzrsoWTyca,showDialogs=ndkUxG9LtewJ):
	if showDialogs==sCHVtMAvqirbQ4BUK3cgWo: showDialogs = ndkUxG9LtewJ
	bbJkqcTvRaD5pK0IwCLxh = NatTJnPvDI2VzLf0GeE5U4rOAS8uCk([Xkp839QMmYzrsoWTyca])
	goMtdGWFzeY7q5,ygh20JmuTLVa = bbJkqcTvRaD5pK0IwCLxh[Xkp839QMmYzrsoWTyca]
	if ygh20JmuTLVa:
		bEZlOa1inyrUgdTw9BKNtcMCLYI = ndkUxG9LtewJ
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,hPFcB6Uxmabj59Iq(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬᆊ")+Xkp839QMmYzrsoWTyca+IO7k2hZXSz(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧᆋ"))
	else:
		bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(TzIj50KpohEOHx6CbZWqB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᆌ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,sCHVtMAvqirbQ4BUK3cgWo+Xkp839QMmYzrsoWTyca+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠠ࡝ࡰ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ฼ํี๋ࠥแฺๆฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠤํอไษำ้ห๊าࠠษฯสะฮࠦไ่ษࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪᆍ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠶ቺ"):
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧᆎ")+Xkp839QMmYzrsoWTyca+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࠫࠪᆏ"))
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠷ቻ"))
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(gDETKVh8mZe09Nd(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩᆐ"))
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(EJgYdjbIiWe1apkQlZcR42(u"࠱ቼ"))
			while FoiwfTEhGD8ulS25HeUvnI.getCondVisibility(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧᆑ")): hDjf1Ubgq629nXlOvcFLH4Jw.sleep(fvYGxnZNUiyP4HJkMIoS25(u"࠲ች"))
			bEZlOa1inyrUgdTw9BKNtcMCLYI = LXC6NZ3rfqtF2heQjSnWuHK9Y71oA(Xkp839QMmYzrsoWTyca)
			if showDialogs and bEZlOa1inyrUgdTw9BKNtcMCLYI: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫฯ๋ࠠโฯุࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫᆒ"))
			elif showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SE97R3Dpj6dPLweVKU(u"ࠬ็ิๅࠢไ๎ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ࠳่ࠦศๆะ่ࠥํ่ࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ๊์ࠠฯษิะࠥอไษำ้ห๊าࠧᆓ"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def BvrNt7VUqLnwZCYsKO3oxWeluJ(showDialogs):
	if not showDialogs: bR4jqNrpMesHt93OgGKi6WDVaQA = ndkUxG9LtewJ
	else: bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(RDwahqjPfbdyEiTtnLQu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆔ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SE97R3Dpj6dPLweVKU(u"ࠧษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣฬ฾๋ไ๋หࠣฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢอ่็อฦ๋ษࠣ็้ࠦ࠲࠵ࠢึห฾ฯ้ࠠๆๆ๊๋ࠥๅไ่ࠣษัืวย้สࠤฬ๊ย็ࠢ࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣว๋ࠦสุๆหࠤ๊์ࠠไ๊า๎ࠥ็อึ๋ࠢฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢยࠫᆕ"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==fvYGxnZNUiyP4HJkMIoS25(u"࠳ቾ"):
		FoiwfTEhGD8ulS25HeUvnI.executebuiltin(hPFcB6Uxmabj59Iq(u"ࠨࡗࡳࡨࡦࡺࡥࡂࡦࡧࡳࡳࡘࡥࡱࡱࡶࠫᆖ"))
		if showDialogs:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,oVwa0kcqxj1e7mLplAfZdGT(u"ࠩอ้ࠥหัิษ็ࠤ฼๊ศࠡว็ํࠥฮั็ษ่ะ้่ࠥะ์ࠣห้ึ๊ࠡใํࠤัํวำๅ่่ࠣ๐๋ࠠไ๋้ࠥฮสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡ࠰ࠣฬ๊อࠠโ์๊หࠥะอะ์ฮࠤ์ึวࠡษ็ฬึ์วๆฮࠣ์ฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩᆗ"))
	return
def XzMkGaOSRLNVQj09yUJ():
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,jwzOabysh0Z(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨᆘ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬᆙ"))
	fE8zgXQkwH7PeIl1a()
	gahvbG5HU6K2 = SCVues5Z1MXwdNf()
	if gahvbG5HU6K2:
		z1zgwnV9AhRXZlUePbrGp(ndkUxG9LtewJ)
		BvrNt7VUqLnwZCYsKO3oxWeluJ(ndkUxG9LtewJ)
		Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def LXC6NZ3rfqtF2heQjSnWuHK9Y71oA(Xkp839QMmYzrsoWTyca):
	ka7jz96YCdTBnQOLVPuJG3285MHf = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(SIkwCEdJHTD9v1(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨᆚ")+Xkp839QMmYzrsoWTyca+IO7k2hZXSz(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫᆛ"))
	succeeded = ndkUxG9LtewJ if qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡐࡍࠪᆜ") in ka7jz96YCdTBnQOLVPuJG3285MHf else lvzrYTpcBaK
	return succeeded
def WD5EuNVqeiOrj074QBPk(Xkp839QMmYzrsoWTyca):
	ka7jz96YCdTBnQOLVPuJG3285MHf = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫᆝ")+Xkp839QMmYzrsoWTyca+fvYGxnZNUiyP4HJkMIoS25(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨᆞ"))
	succeeded = ndkUxG9LtewJ if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡓࡐ࠭ᆟ") in ka7jz96YCdTBnQOLVPuJG3285MHf else lvzrYTpcBaK
	return succeeded
def hdtaWARbFnsvxlfCIL8(Xkp839QMmYzrsoWTyca,showDialogs,R9ZzxKcPweHF7IhGXJ6AbV,MyeJZzh0Q8RYL2U6=None):
	bR4jqNrpMesHt93OgGKi6WDVaQA,succeeded,QOkDW1VMTgYP4wLeibCxaNpSRKqy,jBLdhuUa7iOPYT20SMvgq1FtH9Rl = ndkUxG9LtewJ,lvzrYTpcBaK,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᆠ"),sCHVtMAvqirbQ4BUK3cgWo
	if not MyeJZzh0Q8RYL2U6: MyeJZzh0Q8RYL2U6 = nPkDNvLX7xircVpzhsGKW([Xkp839QMmYzrsoWTyca])
	if Xkp839QMmYzrsoWTyca in list(MyeJZzh0Q8RYL2U6.keys()):
		gahvbG5HU6K2,jBLdhuUa7iOPYT20SMvgq1FtH9Rl,TGnRrvw6jEd5egaU,HFeWmMp7oDBZn,m2mLEiued649gFS0X,BpgvYo1ac5IZz8,tNVIYvLuPnhc4AJHQesUbk6CyXjMow = MyeJZzh0Q8RYL2U6[Xkp839QMmYzrsoWTyca]
		if BpgvYo1ac5IZz8==IOHSz7YPF9WusGgUt1Dq(u"ࠬ࡭࡯ࡰࡦࠪᆡ"):
			succeeded,QOkDW1VMTgYP4wLeibCxaNpSRKqy = ndkUxG9LtewJ,zLjWeKu6JgNO7vocUD0Qpy(u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧᆢ")
			if R9ZzxKcPweHF7IhGXJ6AbV and showDialogs:
				bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,aenpKvQCGVzhLXEdWiDIZ(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤ่๎ฯ๋ࠢํืฯิฯๆࠢฦาึࠦลึัสี๋ࠥส้ใิࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ้ํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧᆣ")+Xkp839QMmYzrsoWTyca+sH6BOz5wKRFcEg(u"ࠨ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส่ࠢีฮࠦรฯำ์ࠫᆤ"))
				if bR4jqNrpMesHt93OgGKi6WDVaQA:
					succeeded = YYISwoJk4KhWc(Xkp839QMmYzrsoWTyca,tNVIYvLuPnhc4AJHQesUbk6CyXjMow,lvzrYTpcBaK)
					if succeeded:
						QOkDW1VMTgYP4wLeibCxaNpSRKqy = oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡵࡩ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧᆥ")
						if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IOHSz7YPF9WusGgUt1Dq(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅ้ฮ๋ำฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหษ฾อฯสࠢอฯอ๐ส่ษ࡟ࡲࡡࡴࠧᆦ")+Xkp839QMmYzrsoWTyca)
					else:
						QOkDW1VMTgYP4wLeibCxaNpSRKqy = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᆧ")
						ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᆨ")+Xkp839QMmYzrsoWTyca)
		else:
			if showDialogs:
				if BpgvYo1ac5IZz8==BWfpRku7SsM6cbE0eG(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᆩ"): Iqm6XAWBlF = IOHSz7YPF9WusGgUt1Dq(u"ࠧๆฬ๋ๆๆฯࠧᆪ")
				elif BpgvYo1ac5IZz8==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡱ࡯ࡨࠬᆫ"): Iqm6XAWBlF = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩๅำ๏๋ษࠨᆬ")
				elif BpgvYo1ac5IZz8==TzIj50KpohEOHx6CbZWqB(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫᆭ"): Iqm6XAWBlF = fvYGxnZNUiyP4HJkMIoS25(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧᆮ")
				bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬํะ่ࠢส่ส฼วโหࠣࠫᆯ")+Iqm6XAWBlF+RDwahqjPfbdyEiTtnLQu(u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨᆰ")+Xkp839QMmYzrsoWTyca)
			if not bR4jqNrpMesHt93OgGKi6WDVaQA: QOkDW1VMTgYP4wLeibCxaNpSRKqy = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩᆱ")
			else:
				if BpgvYo1ac5IZz8==qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪᆲ"):
					succeeded = LXC6NZ3rfqtF2heQjSnWuHK9Y71oA(Xkp839QMmYzrsoWTyca)
					if succeeded:
						QOkDW1VMTgYP4wLeibCxaNpSRKqy = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪᆳ")
						if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨᆴ")+Xkp839QMmYzrsoWTyca)
					elif showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,BWfpRku7SsM6cbE0eG(u"้๊ࠫริใࠣ࠲࠳ࠦวๅวูหๆฯࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์้๋๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧᆵ")+Xkp839QMmYzrsoWTyca)
				elif BpgvYo1ac5IZz8 in [GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡵ࡬ࡥࠩᆶ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧᆷ")]:
					succeeded = YYISwoJk4KhWc(Xkp839QMmYzrsoWTyca,tNVIYvLuPnhc4AJHQesUbk6CyXjMow,lvzrYTpcBaK)
					if succeeded:
						if BpgvYo1ac5IZz8==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡰ࡮ࡧࠫᆸ"): QOkDW1VMTgYP4wLeibCxaNpSRKqy = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩᆹ")
						elif BpgvYo1ac5IZz8==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᆺ"): QOkDW1VMTgYP4wLeibCxaNpSRKqy = gDETKVh8mZe09Nd(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᆻ")
						jBLdhuUa7iOPYT20SMvgq1FtH9Rl = HFeWmMp7oDBZn
						if showDialogs:
							if QOkDW1VMTgYP4wLeibCxaNpSRKqy==IOHSz7YPF9WusGgUt1Dq(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬᆼ"): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩᆽ")+Xkp839QMmYzrsoWTyca)
							elif QOkDW1VMTgYP4wLeibCxaNpSRKqy==t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩᆾ"): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,hPFcB6Uxmabj59Iq(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ๊ࠥๅࠡฬๆ๊๋่ࠥอ๊าอࠥ็๊ࠡๅ๋ำ๏ࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮะฮ๊ห้สࡠࡳࡢ࡮ࠨᆿ")+Xkp839QMmYzrsoWTyca)
					elif showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,BWfpRku7SsM6cbE0eG(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᇀ")+Xkp839QMmYzrsoWTyca)
	elif showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧᇁ")+Xkp839QMmYzrsoWTyca)
	return succeeded,QOkDW1VMTgYP4wLeibCxaNpSRKqy,jBLdhuUa7iOPYT20SMvgq1FtH9Rl
def muQzOPIT9SeVGXxgo17i(Xkp839QMmYzrsoWTyca,showDialogs,mnTUu64oZ0Jg2qQEHWijdp):
	ELs4Ppwig9N8rM0nvRfAoHT7qCe2 = jcNEqrxW4uBOgHKhvU3dnMfXTFm.connect(fMnyRlYuDxPHvjC)
	ELs4Ppwig9N8rM0nvRfAoHT7qCe2.text_factory = str
	Fy1DHCosVPbSNMnWl0RQaiLtxB = ELs4Ppwig9N8rM0nvRfAoHT7qCe2.cursor()
	succeeded,u87uR3tQKkVNUGOIiFX6azS4 = ndkUxG9LtewJ,lvzrYTpcBaK
	try:
		vvBRErH6dzWpThoL4fb = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᇂ")
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᇃ")+Xkp839QMmYzrsoWTyca+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠨࠠ࠼ࠩᇄ"))
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = Fy1DHCosVPbSNMnWl0RQaiLtxB.fetchall()
		if TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq and vvBRErH6dzWpThoL4fb not in str(TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq): Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪᇅ")+vvBRErH6dzWpThoL4fb+BWfpRku7SsM6cbE0eG(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᇆ")+Xkp839QMmYzrsoWTyca+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࠤࠣ࠿ࠬᇇ"))
		TeISRhCa4i6 = sH6BOz5wKRFcEg(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬᇈ") if qdUK5ioJyrO1T else fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩᇉ")
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(IO7k2hZXSz(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬᇊ")+TeISRhCa4i6+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᇋ")+Xkp839QMmYzrsoWTyca+IO7k2hZXSz(u"࠭ࠢࠡ࠽ࠪᇌ"))
		TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = Fy1DHCosVPbSNMnWl0RQaiLtxB.fetchall()
		if TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq:
			if showDialogs: bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫᇍ")+Xkp839QMmYzrsoWTyca+hPFcB6Uxmabj59Iq(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨᇎ")+VXWOCAE6ns3paJ8DLG479NQfMu+SIkwCEdJHTD9v1(u"้ࠩࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫᇏ")+B8alA5nvIhTxQ+YQNd4wejLSAVJ6T(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤฺ๐ว็หࠣฬึ์วๆฮࠣ฽๊อฯࠨᇐ"))
			else: bR4jqNrpMesHt93OgGKi6WDVaQA = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				u87uR3tQKkVNUGOIiFX6azS4 = ndkUxG9LtewJ
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪᇑ")+TeISRhCa4i6+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᇒ")+Xkp839QMmYzrsoWTyca+TzIj50KpohEOHx6CbZWqB(u"࠭ࠢࠡ࠽ࠪᇓ"))
		elif mnTUu64oZ0Jg2qQEHWijdp:
			if showDialogs: bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,aYH620Dh48GEsTFfOBSQ7r(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫᇔ")+Xkp839QMmYzrsoWTyca+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨᇕ")+VXWOCAE6ns3paJ8DLG479NQfMu+YQNd4wejLSAVJ6T(u"้ࠩࠣๆ฿ไ๊ࠡํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใ๊ࠤฬ๊ย็ࠢยࠥࠦࠦࠧᇖ")+B8alA5nvIhTxQ+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢอๅ฾๐ไ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤฺ๐ว็หࠣฬึ์วๆฮࠣ฽๊อฯࠨᇗ"))
			else: bR4jqNrpMesHt93OgGKi6WDVaQA = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				u87uR3tQKkVNUGOIiFX6azS4 = ndkUxG9LtewJ
				if qdUK5ioJyrO1T: Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(Js61GTdX5wzMurUqi7Z(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪᇘ")+TeISRhCa4i6+fvYGxnZNUiyP4HJkMIoS25(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬᇙ")+Xkp839QMmYzrsoWTyca+XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࠢࠪࠢ࠾ࠫᇚ"))
				else: Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ᇛ")+TeISRhCa4i6+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬᇜ")+Xkp839QMmYzrsoWTyca+IOHSz7YPF9WusGgUt1Dq(u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩᇝ"))
	except: succeeded = lvzrYTpcBaK
	ELs4Ppwig9N8rM0nvRfAoHT7qCe2.commit()
	ELs4Ppwig9N8rM0nvRfAoHT7qCe2.close()
	if u87uR3tQKkVNUGOIiFX6azS4:
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(qeG16a4pbSHziNVQ2uFXrs(u"࠴ቿ"))
		FoiwfTEhGD8ulS25HeUvnI.executebuiltin(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧᇞ"))
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(oVwa0kcqxj1e7mLplAfZdGT(u"࠵ኀ"))
		if showDialogs:
			if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,YQNd4wejLSAVJ6T(u"๋ࠫาอหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬᇟ")+Xkp839QMmYzrsoWTyca)
			else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qqw1upCsKM(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ᇠ")+Xkp839QMmYzrsoWTyca)
	return u87uR3tQKkVNUGOIiFX6azS4
def FrMEeKQbiIup5oXG(ZQtAwbhVH5kToe1lSC0zdgysi,showDialogs,R9ZzxKcPweHF7IhGXJ6AbV,mnTUu64oZ0Jg2qQEHWijdp):
	MyeJZzh0Q8RYL2U6 = nPkDNvLX7xircVpzhsGKW(ZQtAwbhVH5kToe1lSC0zdgysi)
	K7cFQCx6UGdigW = lvzrYTpcBaK
	for Xkp839QMmYzrsoWTyca in ZQtAwbhVH5kToe1lSC0zdgysi:
		succeeded,QOkDW1VMTgYP4wLeibCxaNpSRKqy,jBLdhuUa7iOPYT20SMvgq1FtH9Rl = hdtaWARbFnsvxlfCIL8(Xkp839QMmYzrsoWTyca,showDialogs,R9ZzxKcPweHF7IhGXJ6AbV,MyeJZzh0Q8RYL2U6)
		u87uR3tQKkVNUGOIiFX6azS4 = muQzOPIT9SeVGXxgo17i(Xkp839QMmYzrsoWTyca,showDialogs,mnTUu64oZ0Jg2qQEHWijdp)
		if u87uR3tQKkVNUGOIiFX6azS4: K7cFQCx6UGdigW = ndkUxG9LtewJ
	if K7cFQCx6UGdigW:
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(fvYGxnZNUiyP4HJkMIoS25(u"࠶ኁ"))
		FoiwfTEhGD8ulS25HeUvnI.executebuiltin(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᇡ"))
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(fvYGxnZNUiyP4HJkMIoS25(u"࠷ኂ"))
	if showDialogs:
		if len(ZQtAwbhVH5kToe1lSC0zdgysi)>zLjWeKu6JgNO7vocUD0Qpy(u"࠱ኃ"): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦฬๆ์฼ࠤฬ๊ลืษไหฯ࠭ᇢ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,TzIj50KpohEOHx6CbZWqB(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᇣ")+ZQtAwbhVH5kToe1lSC0zdgysi[qeG16a4pbSHziNVQ2uFXrs(u"࠱ኄ")])
	return
def z1zgwnV9AhRXZlUePbrGp(showDialogs):
	DiZCEfHG6BnohgajLUV0cb4z = [YQNd4wejLSAVJ6T(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᇤ"),sH6BOz5wKRFcEg(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᇥ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨᇦ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬᇧ")]
	deHmL0uzFXO = [Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨᇨ"),TzIj50KpohEOHx6CbZWqB(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨᇩ"),EJgYdjbIiWe1apkQlZcR42(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫᇪ"),qqw1upCsKM(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫᇫ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫᇬ"),RDwahqjPfbdyEiTtnLQu(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨᇭ")]
	for Xkp839QMmYzrsoWTyca in deHmL0uzFXO: WD5EuNVqeiOrj074QBPk(Xkp839QMmYzrsoWTyca)
	FrMEeKQbiIup5oXG(DiZCEfHG6BnohgajLUV0cb4z,showDialogs,lvzrYTpcBaK,lvzrYTpcBaK)
	return
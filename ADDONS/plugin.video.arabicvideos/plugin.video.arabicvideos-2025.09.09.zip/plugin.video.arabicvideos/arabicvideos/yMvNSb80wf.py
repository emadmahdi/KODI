# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYNOW'
Z0BYJQghVL1v87CAem = '_EGN_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==430: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==431: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==432: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==433: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==434: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==437: ka7jz96YCdTBnQOLVPuJG3285MHf = gaVbExnQiwt0rlO6(url)
	elif mode==439: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8+'/films',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = fNntYJW45mEFSdRX8g.findall('"canonical" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	aeBQsh4fzLr8XM5xou1gcyE = aeBQsh4fzLr8XM5xou1gcyE[0].strip('/')
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(aeBQsh4fzLr8XM5xou1gcyE,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,439,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',aeBQsh4fzLr8XM5xou1gcyE,435)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',aeBQsh4fzLr8XM5xou1gcyE,434)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المضاف حديثا',aeBQsh4fzLr8XM5xou1gcyE,431)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'افلام اون لاين',aeBQsh4fzLr8XM5xou1gcyE+'/films1',436)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مسلسلات اون لاين',aeBQsh4fzLr8XM5xou1gcyE+'/series-all1',436)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'قائمة تفصيلية',aeBQsh4fzLr8XM5xou1gcyE,437)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"SiteNavigation"(.*?)"Search"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,431)
	return
def gaVbExnQiwt0rlO6(website=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',website+'/films',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = fNntYJW45mEFSdRX8g.findall('"canonical" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	aeBQsh4fzLr8XM5xou1gcyE = aeBQsh4fzLr8XM5xou1gcyE[0].strip('/')
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(aeBQsh4fzLr8XM5xou1gcyE,'url')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"ListDroped"(.*?)"SearchingMaster"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B4SziFvRIXpPeGmfZDw3aVWJMAKNc,value,title in items:
		if title in MqARWHDkmiT4nlz: continue
		B17r2fdFy9ns8tiOMLu = website+'/explore/?'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'='+value
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,431)
	return
def ffy5vVCNau6FWgbmp(url):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-SUBMENU-1st')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',url,431)
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"titleSectionCon"(.*?)</div></div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-key="(.*?)".*?<em>(.*?)</em>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for pm4F0M2Dsuh6otP7Zi5NXT,title in items:
		if title in MqARWHDkmiT4nlz: continue
		vrEJRkchKxtDNiqO1b79mL5eT = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+pm4F0M2Dsuh6otP7Zi5NXT
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,vrEJRkchKxtDNiqO1b79mL5eT,431)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
	elif n1WYDtVC8dRHbXJkMa=='featured':
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"MainSlider"(.*?)"MatchesTable"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"BlocksList"(.*?)"Paginate"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"BlocksList"(.*?)"titleSectionCon"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not items: items = fNntYJW45mEFSdRX8g.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,432,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'الحلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,433,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movseries/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,431,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,433,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if n1WYDtVC8dRHbXJkMa!='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"Paginate"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
				B17r2fdFy9ns8tiOMLu = tt36wUe4HTPFmfs5hcbr(B17r2fdFy9ns8tiOMLu)
				title = tt36wUe4HTPFmfs5hcbr(title)
				if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,431)
		fMlokB12KS3wrF = fNntYJW45mEFSdRX8g.findall('showmore" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if fMlokB12KS3wrF:
			B17r2fdFy9ns8tiOMLu = fMlokB12KS3wrF[0]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مشاهدة المزيد',B17r2fdFy9ns8tiOMLu,431)
	return
def VzOBjnIkZSH7ft(url):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	GzRKsiw5PBIe1NlrqmQy9STx,iUtXlDhSVoBZJrPTQAwcER9nfMkN = [],[]
	if 'Episodes.php' in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-EPISODES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		iUtXlDhSVoBZJrPTQAwcER9nfMkN = [Sw0pOFoVhPeIxbl]
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-EPISODES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"SeasonsList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"EpisodesList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"og:image" content="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for sYTMXCn5AG0KR3E9SUO,yR2KJX91QxacgsVP0uAp3bI6qj,title in items:
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+yR2KJX91QxacgsVP0uAp3bI6qj+'&post_id='+sYTMXCn5AG0KR3E9SUO
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,433,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Thumb')
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,bbFPOJrmkCaE6ul37XiKU in items:
			title = title+AAh0X3OCacr4HpifRGLZKT+bbFPOJrmkCaE6ul37XiKU
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,432,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url+'/watch/'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ss7YGDbuAIxgnqaQroTV = []
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,'url')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"container-servers"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		SSyNiGLhxRXH1TzFW3DPw = fNntYJW45mEFSdRX8g.findall('data-id="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if SSyNiGLhxRXH1TzFW3DPw:
			SSyNiGLhxRXH1TzFW3DPw = SSyNiGLhxRXH1TzFW3DPw[0]
			items = fNntYJW45mEFSdRX8g.findall('data-server="(.*?)".*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for smh8Qbf9jH,title in items:
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+smh8Qbf9jH+'&post_id='+SSyNiGLhxRXH1TzFW3DPw+'?named='+title+'__watch'
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	zklYuTMJpIQScm4oB = fNntYJW45mEFSdRX8g.findall('"container-iframe"><iframe src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if zklYuTMJpIQScm4oB:
		zklYuTMJpIQScm4oB = zklYuTMJpIQScm4oB[0].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
		title = GABnmSFOwtsu37(zklYuTMJpIQScm4oB,'name')
		B17r2fdFy9ns8tiOMLu = zklYuTMJpIQScm4oB+'?named='+title+'__embed'
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"container-download"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,XO7Zr2W6kwieA in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
			if XO7Zr2W6kwieA!=sCHVtMAvqirbQ4BUK3cgWo: XO7Zr2W6kwieA = '____'+XO7Zr2W6kwieA
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+XO7Zr2W6kwieA
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url)
	return
def J6qLc3tuKiNQS1gdma45IFTo(url):
	url = url.split('/smartemadfilter?')[0]
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',aeBQsh4fzLr8XM5xou1gcyE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('("dropdown-button".*?)"SearchingMaster"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return ssNoPMBKbeHfzu09G7vpDgyEZiIm
def qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2):
	items = fNntYJW45mEFSdRX8g.findall('data-term="(\d+)" data-name="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return items
def UR7wsGhrVpTqilKnXNPezbYD0(url):
	OLN043hZlvyaB = url.split('/smartemadfilter?')[0]
	ffnlE3miaPHCj6NU40zvh7QFwsI2 = GABnmSFOwtsu37(url,'url')
	url = url.replace(OLN043hZlvyaB,ffnlE3miaPHCj6NU40zvh7QFwsI2)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def UcTQNpxYFJj(nGjoKRMy1mDqUx0,url):
	ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'modified_filters')
	rdQ5tOIzuelfvcYbNsM = url+'/smartemadfilter?'+ukGBUJAz02tOe
	rdQ5tOIzuelfvcYbNsM = UR7wsGhrVpTqilKnXNPezbYD0(rdQ5tOIzuelfvcYbNsM)
	return rdQ5tOIzuelfvcYbNsM
JqMFOusdXt69Py = ['category','country','genre','release-year']
QC1LKoSRIvJFA7fpx3u0 = ['quality','release-year','genre','category','language','country']
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if JqMFOusdXt69Py[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(JqMFOusdXt69Py[0:-1])):
			if JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+ukGBUJAz02tOe
	elif type=='ALL_ITEMS_FILTER':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+RLkAVfXyplPhsSgb9760oCZW
		vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها ',vrEJRkchKxtDNiqO1b79mL5eT,431)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',vrEJRkchKxtDNiqO1b79mL5eT,431)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = J6qLc3tuKiNQS1gdma45IFTo(url)
	dict = {}
	for name,Po9h3gWFuLR2,ppWPYnc0JHvsmuTBqCXDEkzyN8 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		name = name.replace('--',sCHVtMAvqirbQ4BUK3cgWo)
		items = qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='SPECIFIED_FILTER':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<2:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]:
					url = UR7wsGhrVpTqilKnXNPezbYD0(url)
					fs7D0d3QyAT(url)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'SPECIFIED_FILTER___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',vrEJRkchKxtDNiqO1b79mL5eT,431)
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',vrEJRkchKxtDNiqO1b79mL5eT,435,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='ALL_ITEMS_FILTER':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع :'+name,vrEJRkchKxtDNiqO1b79mL5eT,434,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if value=='196533': CCzds3YbQDjKUFxfA5RHMIyBaSt = 'أفلام نيتفلكس'
			elif value=='196531': CCzds3YbQDjKUFxfA5RHMIyBaSt = 'مسلسلات نيتفلكس'
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'#+dict[ppWPYnc0JHvsmuTBqCXDEkzyN8]['0']
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'+name
			if type=='ALL_ITEMS_FILTER': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,434,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='SPECIFIED_FILTER' and JqMFOusdXt69Py[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				rdQ5tOIzuelfvcYbNsM = UcTQNpxYFJj(nGjoKRMy1mDqUx0,url)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,431)
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,435,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.replace('=&','=0&')
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	for key in QC1LKoSRIvJFA7fpx3u0:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if '%' not in value: value = IgCGzHw45TJ7PeuO1EKl(value)
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all_filters': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.replace('=0','=')
	return FQZjpoeBUGkTShcbE3d
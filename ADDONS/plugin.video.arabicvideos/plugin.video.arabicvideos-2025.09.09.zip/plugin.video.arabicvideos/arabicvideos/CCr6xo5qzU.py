# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ALFATIMI'
Z0BYJQghVL1v87CAem = '_FTM_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
n4PlBpr2sRHy1zYmW3cE8N = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
x6vcFsfJdPI = ['3030','628']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==60: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==61: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==62: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==63: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==64: ka7jz96YCdTBnQOLVPuJG3285MHf = mNOGpfZ8Iy7LXcgWJsuEqBD(text)
	elif mode==69: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,69,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'ما يتم مشاهدته الان',gAVl1vUmus8,64,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'recent_viewed_vids')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الاكثر مشاهدة',gAVl1vUmus8,64,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'most_viewed_vids')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'اضيفت مؤخرا',gAVl1vUmus8,64,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'recently_added_vids')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'فيديو عشوائي',gAVl1vUmus8,64,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'random_vids')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'افلام ومسلسلات',gAVl1vUmus8,61,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'-1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'البرامج الدينية',gAVl1vUmus8,61,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'-2')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'English Videos',gAVl1vUmus8,61,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'-3')
	return sCHVtMAvqirbQ4BUK3cgWo
def fs7D0d3QyAT(url,B4SziFvRIXpPeGmfZDw3aVWJMAKNc):
	h0d2iFau8GsoWqDpTEg = sCHVtMAvqirbQ4BUK3cgWo
	if B4SziFvRIXpPeGmfZDw3aVWJMAKNc not in ['-1','-2','-3']: h0d2iFau8GsoWqDpTEg = '?cat='+B4SziFvRIXpPeGmfZDw3aVWJMAKNc
	vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+'/menu_level.php'+h0d2iFau8GsoWqDpTEg
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALFATIMI-TITLES-1st')
	items = fNntYJW45mEFSdRX8g.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	UnspeLKkWXtx7Z,vVU3etr1sKREmPkX9z26D0qoJ = False,False
	for B17r2fdFy9ns8tiOMLu,title,count in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
		h0d2iFau8GsoWqDpTEg = fNntYJW45mEFSdRX8g.findall('cat=(.*?)&',B17r2fdFy9ns8tiOMLu,fNntYJW45mEFSdRX8g.DOTALL)[0]
		if B4SziFvRIXpPeGmfZDw3aVWJMAKNc==h0d2iFau8GsoWqDpTEg: UnspeLKkWXtx7Z = True
		elif UnspeLKkWXtx7Z 	or (B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='-1' and h0d2iFau8GsoWqDpTEg in n4PlBpr2sRHy1zYmW3cE8N)  						or (B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='-2' and h0d2iFau8GsoWqDpTEg not in x6vcFsfJdPI and h0d2iFau8GsoWqDpTEg not in n4PlBpr2sRHy1zYmW3cE8N)  						or (B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='-3' and h0d2iFau8GsoWqDpTEg in x6vcFsfJdPI):
							if count=='1': XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,63)
							else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,61,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,h0d2iFau8GsoWqDpTEg)
							vVU3etr1sKREmPkX9z26D0qoJ = True
	if not vVU3etr1sKREmPkX9z26D0qoJ: VzOBjnIkZSH7ft(url)
	return
def VzOBjnIkZSH7ft(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALFATIMI-EPISODES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination(.*?)id="footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	B17r2fdFy9ns8tiOMLu = sCHVtMAvqirbQ4BUK3cgWo
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,B17r2fdFy9ns8tiOMLu in items:
		title = title.replace('Add',sCHVtMAvqirbQ4BUK3cgWo).replace('to Quicklist',sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,63,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('(.*?)div',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2=oPnz7Zt4xLHTwR[0]
	Po9h3gWFuLR2=fNntYJW45mEFSdRX8g.findall('pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	items=fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = url.split('?')[0]
	for B17r2fdFy9ns8tiOMLu,cLsJOECgZlU5Pp1RMVI0WTr in items:
		B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT + B17r2fdFy9ns8tiOMLu
		title = tt36wUe4HTPFmfs5hcbr(cLsJOECgZlU5Pp1RMVI0WTr)
		title = 'صفحة ' + title
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,62)
	return B17r2fdFy9ns8tiOMLu
def YH54mqkD2eU06(url):
	if 'videos.php' in url: url = VzOBjnIkZSH7ft(url)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALFATIMI-PLAY-1st')
	items = fNntYJW45mEFSdRX8g.findall('playlistfile:"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	CeXLtzElr5DHhs(url,Ll1m0nJoaAPvHsXqyRE,'video')
	return
def mNOGpfZ8Iy7LXcgWJsuEqBD(B4SziFvRIXpPeGmfZDw3aVWJMAKNc):
	rnCzKJiBSsgGhj = { 'mode' : B4SziFvRIXpPeGmfZDw3aVWJMAKNc }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = JePn6VTBrLMDmsCzX(rnCzKJiBSsgGhj)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,63,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8 + '/search_result.php?query=' + ktT4O0VJm8UaDNlxKvinoBYFgdH
	VzOBjnIkZSH7ft(url)
	return
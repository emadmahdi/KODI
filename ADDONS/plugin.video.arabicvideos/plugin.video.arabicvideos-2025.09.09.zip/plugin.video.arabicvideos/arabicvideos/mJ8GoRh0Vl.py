# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ଑")
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,qhWpTazQ9ws):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠳࠴࠲ட"): ka7jz96YCdTBnQOLVPuJG3285MHf = Acum3R7kU8od9yHECMqX2()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==aYH620Dh48GEsTFfOBSQ7r(u"࠴࠵࠴஠"): ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(qhWpTazQ9ws)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠵࠶࠶஡"): ka7jz96YCdTBnQOLVPuJG3285MHf = INcgTsr70wMRqzJubiFvkAoY()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==zLjWeKu6JgNO7vocUD0Qpy(u"࠶࠷࠸஢"): ka7jz96YCdTBnQOLVPuJG3285MHf = hRuBckfKaV0P4xN9oWj3Y()
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = lvzrYTpcBaK
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def YH54mqkD2eU06(qhWpTazQ9ws):
	CeXLtzElr5DHhs(qhWpTazQ9ws,Ll1m0nJoaAPvHsXqyRE,fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡶࡪࡦࡨࡳࠬ଒"))
	return
def hRuBckfKaV0P4xN9oWj3Y():
	Iqm6XAWBlF = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ଓ")
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧଔ"),Iqm6XAWBlF)
	return
def Acum3R7kU8od9yHECMqX2():
	XAozRfZ68H9x2OsiP3LmIaql1(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࡯࡭ࡳࡱࠧକ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨଖ"),sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"࠷࠸࠹ண"))
	XAozRfZ68H9x2OsiP3LmIaql1(EJgYdjbIiWe1apkQlZcR42(u"ࠫࡱ࡯࡮࡬ࠩଗ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬଘ"),sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"࠸࠹࠲த"))
	XAozRfZ68H9x2OsiP3LmIaql1(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭࡬ࡪࡰ࡮ࠫଙ"),VXWOCAE6ns3paJ8DLG479NQfMu+EJgYdjbIiWe1apkQlZcR42(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ଚ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠿࠹࠺࠻஥"))
	yDvjTUlFMadgoNhX70HJPK5bzcILsx = NNMuyfWCVPp54bAa8BwvUeHlm7()
	CCk19RmFzuZVJcyL7nvfg = YYEXZsUWhf52vz7HLxc0qGJ.stat(yDvjTUlFMadgoNhX70HJPK5bzcILsx).st_mtime
	y0k6SDdtf5PiGXEFuH = []
	if I5VKjrFL0Bk97: vyRp9YFTBIfG5LM = YYEXZsUWhf52vz7HLxc0qGJ.listdir(yDvjTUlFMadgoNhX70HJPK5bzcILsx.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
	else: vyRp9YFTBIfG5LM = YYEXZsUWhf52vz7HLxc0qGJ.listdir(yDvjTUlFMadgoNhX70HJPK5bzcILsx.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
	for spngGR4jdhTFkJD2Sx1iva in vyRp9YFTBIfG5LM:
		if I5VKjrFL0Bk97: spngGR4jdhTFkJD2Sx1iva = spngGR4jdhTFkJD2Sx1iva.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		if not spngGR4jdhTFkJD2Sx1iva.startswith(EJgYdjbIiWe1apkQlZcR42(u"ࠨࡨ࡬ࡰࡪࡥࠧଛ")): continue
		ix8XK3BV47kdFcANeTlU2Q = YYEXZsUWhf52vz7HLxc0qGJ.path.join(yDvjTUlFMadgoNhX70HJPK5bzcILsx,spngGR4jdhTFkJD2Sx1iva)
		CCk19RmFzuZVJcyL7nvfg = YYEXZsUWhf52vz7HLxc0qGJ.path.getmtime(ix8XK3BV47kdFcANeTlU2Q)
		y0k6SDdtf5PiGXEFuH.append([spngGR4jdhTFkJD2Sx1iva,CCk19RmFzuZVJcyL7nvfg])
	y0k6SDdtf5PiGXEFuH = sorted(y0k6SDdtf5PiGXEFuH,reverse=ndkUxG9LtewJ,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
	for spngGR4jdhTFkJD2Sx1iva,CCk19RmFzuZVJcyL7nvfg in y0k6SDdtf5PiGXEFuH:
		if qdUK5ioJyrO1T:
			try: spngGR4jdhTFkJD2Sx1iva = spngGR4jdhTFkJD2Sx1iva.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			except: pass
			spngGR4jdhTFkJD2Sx1iva = spngGR4jdhTFkJD2Sx1iva.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		ix8XK3BV47kdFcANeTlU2Q = YYEXZsUWhf52vz7HLxc0qGJ.path.join(yDvjTUlFMadgoNhX70HJPK5bzcILsx,spngGR4jdhTFkJD2Sx1iva)
		XAozRfZ68H9x2OsiP3LmIaql1(fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡹ࡭ࡩ࡫࡯ࠨଜ"),spngGR4jdhTFkJD2Sx1iva,ix8XK3BV47kdFcANeTlU2Q,hPFcB6Uxmabj59Iq(u"࠳࠴࠳஦"))
	return
def NNMuyfWCVPp54bAa8BwvUeHlm7():
	yDvjTUlFMadgoNhX70HJPK5bzcILsx = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(YQNd4wejLSAVJ6T(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ଝ"))
	if yDvjTUlFMadgoNhX70HJPK5bzcILsx: return yDvjTUlFMadgoNhX70HJPK5bzcILsx
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧଞ"),XX4rMRSnQdbZ1NJiKu8pOfvDla)
	return XX4rMRSnQdbZ1NJiKu8pOfvDla
def INcgTsr70wMRqzJubiFvkAoY():
	yDvjTUlFMadgoNhX70HJPK5bzcILsx = NNMuyfWCVPp54bAa8BwvUeHlm7()
	iOT5s9d6l18kuFwzbv0p4WM3ryR = NVjFvLmZCYRu1S893eTf6dUbqJl(SIkwCEdJHTD9v1(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଟ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪଠ"),F7Fe63KbGjaz2TcmCNHPdo5QiXO+yDvjTUlFMadgoNhX70HJPK5bzcILsx+B8alA5nvIhTxQ+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨଡ"))
	if iOT5s9d6l18kuFwzbv0p4WM3ryR==oVwa0kcqxj1e7mLplAfZdGT(u"࠲஧"):
		kz2Jqt6TsvYEC9uS7 = c6aXnvizlYyZjem(IO7k2hZXSz(u"࠵ந"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬଢ"),Js61GTdX5wzMurUqi7Z(u"ࠩ࡯ࡳࡨࡧ࡬ࠨଣ"),sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,ndkUxG9LtewJ,yDvjTUlFMadgoNhX70HJPK5bzcILsx)
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(gDETKVh8mZe09Nd(u"ࠪࡧࡪࡴࡴࡦࡴࠪତ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨଥ"),F7Fe63KbGjaz2TcmCNHPdo5QiXO+yDvjTUlFMadgoNhX70HJPK5bzcILsx+B8alA5nvIhTxQ+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭ଦ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA==oVwa0kcqxj1e7mLplAfZdGT(u"࠴ன"):
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩଧ"),kz2Jqt6TsvYEC9uS7)
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,fvYGxnZNUiyP4HJkMIoS25(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨନ"))
	return
def XRKnIBMaj8gsrUYfveWp(qhWpTazQ9ws,m3URNoVvLS6F=sCHVtMAvqirbQ4BUK3cgWo,website=sCHVtMAvqirbQ4BUK3cgWo):
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ଩")+qhWpTazQ9ws+SIkwCEdJHTD9v1(u"ࠩࠣࡡࠬପ"))
	if not m3URNoVvLS6F: m3URNoVvLS6F = FA0Y1k9va5O2zmU6By(qhWpTazQ9ws)
	yDvjTUlFMadgoNhX70HJPK5bzcILsx = NNMuyfWCVPp54bAa8BwvUeHlm7()
	kS9s3KBpxE548V2 = qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(lvzrYTpcBaK)
	spngGR4jdhTFkJD2Sx1iva = kS9s3KBpxE548V2.replace(AAh0X3OCacr4HpifRGLZKT,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡣࠬଫ"))
	spngGR4jdhTFkJD2Sx1iva = ij3WwceDrmqafJy6Lsx4S9GCFuP(spngGR4jdhTFkJD2Sx1iva)
	spngGR4jdhTFkJD2Sx1iva = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࡫࡯࡬ࡦࡡࠪବ")+str(int(JVAlZw9Nsnj))[-t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠸ப"):]+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡥࠧଭ")+spngGR4jdhTFkJD2Sx1iva+m3URNoVvLS6F
	VjZ3hOHdJgzxSPBbU = YYEXZsUWhf52vz7HLxc0qGJ.path.join(yDvjTUlFMadgoNhX70HJPK5bzcILsx,spngGR4jdhTFkJD2Sx1iva)
	f6cPGkTodE = {}
	f6cPGkTodE[qqw1upCsKM(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨମ")] = sCHVtMAvqirbQ4BUK3cgWo
	f6cPGkTodE[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡂࡥࡦࡩࡵࡺࠧଯ")] = SE97R3Dpj6dPLweVKU(u"ࠨࠬ࠲࠮ࠬର")
	qhWpTazQ9ws = qhWpTazQ9ws.replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ଱"),sCHVtMAvqirbQ4BUK3cgWo)
	if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨଲ") in qhWpTazQ9ws:
		vrEJRkchKxtDNiqO1b79mL5eT,MMKTiky7N3vVPdx6GIzHFOf2Yjq = qhWpTazQ9ws.rsplit(jwzOabysh0Z(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩଳ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠶஫"))
		MMKTiky7N3vVPdx6GIzHFOf2Yjq = MMKTiky7N3vVPdx6GIzHFOf2Yjq.replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࢂࠧ଴"),sCHVtMAvqirbQ4BUK3cgWo).replace(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࠦࠨଵ"),sCHVtMAvqirbQ4BUK3cgWo)
	else: vrEJRkchKxtDNiqO1b79mL5eT,MMKTiky7N3vVPdx6GIzHFOf2Yjq = qhWpTazQ9ws,None
	if not MMKTiky7N3vVPdx6GIzHFOf2Yjq: MMKTiky7N3vVPdx6GIzHFOf2Yjq = OOsacGDt4owXd52q7gC8l()
	if MMKTiky7N3vVPdx6GIzHFOf2Yjq: f6cPGkTodE[gDETKVh8mZe09Nd(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଶ")] = MMKTiky7N3vVPdx6GIzHFOf2Yjq
	if XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪଷ") in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT,jcZbnfXTDoymgClJqYiABS = vrEJRkchKxtDNiqO1b79mL5eT.rsplit(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫସ"),hPFcB6Uxmabj59Iq(u"࠷஬"))
	else: vrEJRkchKxtDNiqO1b79mL5eT,jcZbnfXTDoymgClJqYiABS = vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.strip(sH6BOz5wKRFcEg(u"ࠪࢀࠬହ")).strip(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࠫ࠭଺")).strip(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࢂࠧ଻")).strip(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࠦࠨ଼"))
	jcZbnfXTDoymgClJqYiABS = jcZbnfXTDoymgClJqYiABS.replace(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡽࠩଽ"),sCHVtMAvqirbQ4BUK3cgWo).replace(SIkwCEdJHTD9v1(u"ࠨࠨࠪା"),sCHVtMAvqirbQ4BUK3cgWo)
	if jcZbnfXTDoymgClJqYiABS:	f6cPGkTodE[SIkwCEdJHTD9v1(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪି")] = jcZbnfXTDoymgClJqYiABS
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+RDwahqjPfbdyEiTtnLQu(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୀ")+vrEJRkchKxtDNiqO1b79mL5eT+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧୁ")+str(f6cPGkTodE)+aenpKvQCGVzhLXEdWiDIZ(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬୂ")+VjZ3hOHdJgzxSPBbU+EJgYdjbIiWe1apkQlZcR42(u"࠭ࠠ࡞ࠩୃ"))
	fri6g5k2WyC = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠱࠱࠴࠷஭")*phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠱࠱࠴࠷஭")
	jWdq5GD1lFbH706miPhVEptB = T1eyjvbtkBKJhRmXqYCDcfHia()//fri6g5k2WyC
	if not jWdq5GD1lFbH706miPhVEptB:
		ctjhP4l8L5pbwqZuQo3VYr(sH6BOz5wKRFcEg(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ୄ"),sH6BOz5wKRFcEg(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨ୅"),Js61GTdX5wzMurUqi7Z(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭୆"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭େ"))
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+aYH620Dh48GEsTFfOBSQ7r(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬୈ"))
		return lvzrYTpcBaK
	if m3URNoVvLS6F==IO7k2hZXSz(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ୉"):
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,vrEJRkchKxtDNiqO1b79mL5eT,f6cPGkTodE)
		if len(V9TdsglcWYv0X)==EJgYdjbIiWe1apkQlZcR42(u"࠱ம"):
			iRaHzNpJhSx6ZnCfrvD7j93lks(aenpKvQCGVzhLXEdWiDIZ(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪ୊"),sCHVtMAvqirbQ4BUK3cgWo)
			return lvzrYTpcBaK
		elif len(V9TdsglcWYv0X)==EJgYdjbIiWe1apkQlZcR42(u"࠳ய"): jQLzA92KFEcpw = XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠳ர")
		elif len(V9TdsglcWYv0X)>Js61GTdX5wzMurUqi7Z(u"࠵ற"):
			jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(GVurlv8HeoXEzPRiQB7Ty(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬୋ"), V9TdsglcWYv0X)
			if jQLzA92KFEcpw == -hPFcB6Uxmabj59Iq(u"࠶ல") :
				iRaHzNpJhSx6ZnCfrvD7j93lks(zLjWeKu6JgNO7vocUD0Qpy(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫୌ"),sCHVtMAvqirbQ4BUK3cgWo)
				return lvzrYTpcBaK
		vrEJRkchKxtDNiqO1b79mL5eT = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	CbEFaXxo83Y4cyZwHUnL = EJgYdjbIiWe1apkQlZcR42(u"࠶ள")
	import requests as xu5ndl3mkU2
	if m3URNoVvLS6F==sH6BOz5wKRFcEg(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ୍"):
		VjZ3hOHdJgzxSPBbU = VjZ3hOHdJgzxSPBbU.rsplit(RDwahqjPfbdyEiTtnLQu(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ୎"))[BewrUo9ANCa17G43Sn0LH5xh]+jwzOabysh0Z(u"ࠫ࠳ࡳࡰ࠵ࠩ୏")
		qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡍࡅࡕࠩ୐"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭୑"))
		LPtY4xQrMz3THZ1KswqhjBmWo = qg3X0dy7CDRQmIGvk.content
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ୒"),LPtY4xQrMz3THZ1KswqhjBmWo+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ࡞ࡱࡠࡷ࠭୓"),fNntYJW45mEFSdRX8g.DOTALL)
		if not PXFtqmw5lBGQNa0IV8:
			SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+Js61GTdX5wzMurUqi7Z(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ୔")+vrEJRkchKxtDNiqO1b79mL5eT+TzIj50KpohEOHx6CbZWqB(u"ࠪࠤࡢ࠭୕"))
			return lvzrYTpcBaK
		B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[BewrUo9ANCa17G43Sn0LH5xh]
		if not B17r2fdFy9ns8tiOMLu.startswith(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫ࡭ࡺࡴࡱࠩୖ")):
			if B17r2fdFy9ns8tiOMLu.startswith(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬ࠵࠯ࠨୗ")): B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT.split(SIkwCEdJHTD9v1(u"࠭࠺ࠨ୘"),jwzOabysh0Z(u"࠱ழ"))[BewrUo9ANCa17G43Sn0LH5xh]+gDETKVh8mZe09Nd(u"ࠧ࠻ࠩ୙")+B17r2fdFy9ns8tiOMLu
			elif B17r2fdFy9ns8tiOMLu.startswith(BWfpRku7SsM6cbE0eG(u"ࠨ࠱ࠪ୚")): B17r2fdFy9ns8tiOMLu = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡸࡶࡱ࠭୛"))+B17r2fdFy9ns8tiOMLu
			else: B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT.rsplit(qqw1upCsKM(u"ࠪ࠳ࠬଡ଼"),SIkwCEdJHTD9v1(u"࠲வ"))[BewrUo9ANCa17G43Sn0LH5xh]+RDwahqjPfbdyEiTtnLQu(u"ࠫ࠴࠭ଢ଼")+B17r2fdFy9ns8tiOMLu
		qg3X0dy7CDRQmIGvk = xu5ndl3mkU2.request(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡍࡅࡕࠩ୞"),B17r2fdFy9ns8tiOMLu,headers=f6cPGkTodE,verify=lvzrYTpcBaK)
		RRh4zwU0tPAHMuG = qg3X0dy7CDRQmIGvk.content
		WjF9GsJU25lc = len(RRh4zwU0tPAHMuG)
		Pa0dISCjrYKZL = len(PXFtqmw5lBGQNa0IV8)
		CbEFaXxo83Y4cyZwHUnL = WjF9GsJU25lc*Pa0dISCjrYKZL
	else:
		WjF9GsJU25lc = E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳ஶ")*fri6g5k2WyC
		qg3X0dy7CDRQmIGvk = xu5ndl3mkU2.request(IOHSz7YPF9WusGgUt1Dq(u"࠭ࡇࡆࡖࠪୟ"),vrEJRkchKxtDNiqO1b79mL5eT,headers=f6cPGkTodE,verify=lvzrYTpcBaK,stream=ndkUxG9LtewJ)
		if EJgYdjbIiWe1apkQlZcR42(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨୠ") in qg3X0dy7CDRQmIGvk.headers: CbEFaXxo83Y4cyZwHUnL = int(qg3X0dy7CDRQmIGvk.headers[jwzOabysh0Z(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩୡ")])
		Pa0dISCjrYKZL = int(CbEFaXxo83Y4cyZwHUnL//WjF9GsJU25lc)
	FhNEObAMX75cP4mt3 = int(CbEFaXxo83Y4cyZwHUnL//fri6g5k2WyC)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠴ஷ")
	if CbEFaXxo83Y4cyZwHUnL<hPFcB6Uxmabj59Iq(u"࠶࠶࠶࠰࠱ஸ"):
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+RDwahqjPfbdyEiTtnLQu(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫୢ")+vrEJRkchKxtDNiqO1b79mL5eT+aenpKvQCGVzhLXEdWiDIZ(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧୣ")+str(FhNEObAMX75cP4mt3)+GVurlv8HeoXEzPRiQB7Ty(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ୤")+str(jWdq5GD1lFbH706miPhVEptB)+IOHSz7YPF9WusGgUt1Dq(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୥")+VjZ3hOHdJgzxSPBbU+zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࠠ࡞ࠩ୦"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩ୧"))
		return lvzrYTpcBaK
	q3HNGgLkMPi9J6osOyaehv4rp = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠹࠶࠰ஹ")
	gnMKsNdGCBm8TrJA4Rt = jWdq5GD1lFbH706miPhVEptB-FhNEObAMX75cP4mt3
	if gnMKsNdGCBm8TrJA4Rt<q3HNGgLkMPi9J6osOyaehv4rp:
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+gDETKVh8mZe09Nd(u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୨")+vrEJRkchKxtDNiqO1b79mL5eT+Js61GTdX5wzMurUqi7Z(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭୩")+str(FhNEObAMX75cP4mt3)+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ୪")+str(jWdq5GD1lFbH706miPhVEptB)+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࠥࡓࡂࠡ࠯ࠣࠫ୫")+str(q3HNGgLkMPi9J6osOyaehv4rp)+IO7k2hZXSz(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ୬")+VjZ3hOHdJgzxSPBbU+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠠ࡞ࠩ୭"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧ୮"),RDwahqjPfbdyEiTtnLQu(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧ୯")+str(FhNEObAMX75cP4mt3)+XxE4VAKW7LQzdk2Il3gUr1vwn(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨ୰")+str(jWdq5GD1lFbH706miPhVEptB)+RDwahqjPfbdyEiTtnLQu(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪୱ")+str(q3HNGgLkMPi9J6osOyaehv4rp)+BWfpRku7SsM6cbE0eG(u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭୲"))
		return lvzrYTpcBaK
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ୳"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"࠭็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥลࠧ୴"),fvYGxnZNUiyP4HJkMIoS25(u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠฮฮ่๋ࠥะโา์หหࠥ࠭୵")+str(FhNEObAMX75cP4mt3)+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦสใำํฬฬࠦࠧ୶")+str(jWdq5GD1lFbH706miPhVEptB)+SE97R3Dpj6dPLweVKU(u"้ࠩࠣ๏เวษษํฮࠥ๎็ัษࠣห้๋ไโࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠๅๆอั๊๐ไࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦลๅ๋ࠣะ์อาไࠢ࠱ࠤ์๊ࠠศ่อࠤ๊ะรไัࠣ์ฯื๊ะࠢส่ฬูสๆำสีࠥฮสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣรࠬ୷"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA!=phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠷஺"):
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ୸"))
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SIkwCEdJHTD9v1(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭୹")+vrEJRkchKxtDNiqO1b79mL5eT+bGzRdmOErkIylxALniq6(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ୺")+VjZ3hOHdJgzxSPBbU+GVurlv8HeoXEzPRiQB7Ty(u"࠭ࠠ࡞ࠩ୻"))
		return lvzrYTpcBaK
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+qqw1upCsKM(u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬ୼"))
	USk4nVycGqThQJ6u12daMIHxsoP = xSIYZduC9imekB7c0J6oOa82FVnNU()
	USk4nVycGqThQJ6u12daMIHxsoP.create(VjZ3hOHdJgzxSPBbU,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ୽"))
	KKH7CXzpTeybwsrAUB = ndkUxG9LtewJ
	ofLNbsZxdtEvC0gRM2r9khzTeV = hDjf1Ubgq629nXlOvcFLH4Jw.time()
	if not Q1siCkTZyw.P56VUO0NuA8bq:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩหือฮฺࠠั่ࠤฬ๊สษำ฼ࠤฯ๋ࠠฦๆ฽หฦࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ୾"))
		return lvzrYTpcBaK
	if I5VKjrFL0Bk97: qFnIl6OB5eWZToQ8PUGKsHvC3 = open(VjZ3hOHdJgzxSPBbU,sH6BOz5wKRFcEg(u"ࠪࡻࡧ࠭୿"))
	else: qFnIl6OB5eWZToQ8PUGKsHvC3 = open(VjZ3hOHdJgzxSPBbU.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT),SE97R3Dpj6dPLweVKU(u"ࠫࡼࡨࠧ஀"))
	if m3URNoVvLS6F==Js61GTdX5wzMurUqi7Z(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁"):
		for ruCEzOyVgmGt9WHI7BSofF6d8 in range(hPFcB6Uxmabj59Iq(u"࠱஻"),Pa0dISCjrYKZL+hPFcB6Uxmabj59Iq(u"࠱஻")):
			B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[ruCEzOyVgmGt9WHI7BSofF6d8-TzIj50KpohEOHx6CbZWqB(u"࠲஼")]
			if not B17r2fdFy9ns8tiOMLu.startswith(YQNd4wejLSAVJ6T(u"࠭ࡨࡵࡶࡳࠫஂ")):
				if B17r2fdFy9ns8tiOMLu.startswith(sH6BOz5wKRFcEg(u"ࠧ࠰࠱ࠪஃ")): B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT.split(qeG16a4pbSHziNVQ2uFXrs(u"ࠨ࠼ࠪ஄"),aenpKvQCGVzhLXEdWiDIZ(u"࠳஽"))[BewrUo9ANCa17G43Sn0LH5xh]+IO7k2hZXSz(u"ࠩ࠽ࠫஅ")+B17r2fdFy9ns8tiOMLu
				elif B17r2fdFy9ns8tiOMLu.startswith(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪ࠳ࠬஆ")): B17r2fdFy9ns8tiOMLu = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,IO7k2hZXSz(u"ࠫࡺࡸ࡬ࠨஇ"))+B17r2fdFy9ns8tiOMLu
				else: B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT.rsplit(aYH620Dh48GEsTFfOBSQ7r(u"ࠬ࠵ࠧஈ"),YQNd4wejLSAVJ6T(u"࠴ா"))[BewrUo9ANCa17G43Sn0LH5xh]+aenpKvQCGVzhLXEdWiDIZ(u"࠭࠯ࠨஉ")+B17r2fdFy9ns8tiOMLu
			qg3X0dy7CDRQmIGvk = xu5ndl3mkU2.request(sH6BOz5wKRFcEg(u"ࠧࡈࡇࡗࠫஊ"),B17r2fdFy9ns8tiOMLu,headers=f6cPGkTodE,verify=lvzrYTpcBaK)
			RRh4zwU0tPAHMuG = qg3X0dy7CDRQmIGvk.content
			qg3X0dy7CDRQmIGvk.close()
			qFnIl6OB5eWZToQ8PUGKsHvC3.write(RRh4zwU0tPAHMuG)
			OKxmid0sqAy9actWj8YGp4bJ = hDjf1Ubgq629nXlOvcFLH4Jw.time()
			gWvbAosxPliDMp5Kwz9e = OKxmid0sqAy9actWj8YGp4bJ-ofLNbsZxdtEvC0gRM2r9khzTeV
			RY9G6do1jChS8NplHiETv0fzDBwq2 = gWvbAosxPliDMp5Kwz9e//ruCEzOyVgmGt9WHI7BSofF6d8
			U8xFO3jtIKWf = RY9G6do1jChS8NplHiETv0fzDBwq2*(Pa0dISCjrYKZL+XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠵ி"))
			VM5fl6GozcEw4jZu9Bd0YIi = U8xFO3jtIKWf-gWvbAosxPliDMp5Kwz9e
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,int(bGzRdmOErkIylxALniq6(u"࠷࠰࠱ு")*ruCEzOyVgmGt9WHI7BSofF6d8//(Pa0dISCjrYKZL+aenpKvQCGVzhLXEdWiDIZ(u"࠶ீ"))),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ஋"),SE97R3Dpj6dPLweVKU(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ஌"),str(ruCEzOyVgmGt9WHI7BSofF6d8*WjF9GsJU25lc//fri6g5k2WyC)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪ࠳ࠬ஍")+str(FhNEObAMX75cP4mt3)+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩஎ")+hDjf1Ubgq629nXlOvcFLH4Jw.strftime(qeG16a4pbSHziNVQ2uFXrs(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢஏ"),hDjf1Ubgq629nXlOvcFLH4Jw.gmtime(VM5fl6GozcEw4jZu9Bd0YIi))+hPFcB6Uxmabj59Iq(u"࠭ࠠแࠩஐ"))
			if USk4nVycGqThQJ6u12daMIHxsoP.iscanceled():
				KKH7CXzpTeybwsrAUB = lvzrYTpcBaK
				break
	else:
		ruCEzOyVgmGt9WHI7BSofF6d8 = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠰ூ")
		for RRh4zwU0tPAHMuG in qg3X0dy7CDRQmIGvk.iter_content(chunk_size=WjF9GsJU25lc):
			qFnIl6OB5eWZToQ8PUGKsHvC3.write(RRh4zwU0tPAHMuG)
			ruCEzOyVgmGt9WHI7BSofF6d8 = ruCEzOyVgmGt9WHI7BSofF6d8+E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠲௃")
			OKxmid0sqAy9actWj8YGp4bJ = hDjf1Ubgq629nXlOvcFLH4Jw.time()
			gWvbAosxPliDMp5Kwz9e = OKxmid0sqAy9actWj8YGp4bJ-ofLNbsZxdtEvC0gRM2r9khzTeV
			RY9G6do1jChS8NplHiETv0fzDBwq2 = gWvbAosxPliDMp5Kwz9e/ruCEzOyVgmGt9WHI7BSofF6d8
			U8xFO3jtIKWf = RY9G6do1jChS8NplHiETv0fzDBwq2*(Pa0dISCjrYKZL+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠳௄"))
			VM5fl6GozcEw4jZu9Bd0YIi = U8xFO3jtIKWf-gWvbAosxPliDMp5Kwz9e
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,int(Js61GTdX5wzMurUqi7Z(u"࠵࠵࠶ெ")*ruCEzOyVgmGt9WHI7BSofF6d8/(Pa0dISCjrYKZL+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠴௅"))),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ஑"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨஒ"),str(ruCEzOyVgmGt9WHI7BSofF6d8*WjF9GsJU25lc//fri6g5k2WyC)+GVurlv8HeoXEzPRiQB7Ty(u"ࠩ࠲ࠫஓ")+str(FhNEObAMX75cP4mt3)+IOHSz7YPF9WusGgUt1Dq(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨஔ")+hDjf1Ubgq629nXlOvcFLH4Jw.strftime(TzIj50KpohEOHx6CbZWqB(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨக"),hDjf1Ubgq629nXlOvcFLH4Jw.gmtime(VM5fl6GozcEw4jZu9Bd0YIi))+TzIj50KpohEOHx6CbZWqB(u"ࠬࠦเࠨ஖"))
			if USk4nVycGqThQJ6u12daMIHxsoP.iscanceled():
				KKH7CXzpTeybwsrAUB = lvzrYTpcBaK
				break
		qg3X0dy7CDRQmIGvk.close()
	qFnIl6OB5eWZToQ8PUGKsHvC3.close()
	USk4nVycGqThQJ6u12daMIHxsoP.close()
	if not KKH7CXzpTeybwsrAUB:
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+RDwahqjPfbdyEiTtnLQu(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ஗")+vrEJRkchKxtDNiqO1b79mL5eT+gDETKVh8mZe09Nd(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ஘")+VjZ3hOHdJgzxSPBbU+BWfpRku7SsM6cbE0eG(u"ࠨࠢࡠࠫங"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"ࠩหัุฮุࠠๆห็ࠥะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪச"))
		return ndkUxG9LtewJ
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SIkwCEdJHTD9v1(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ஛")+vrEJRkchKxtDNiqO1b79mL5eT+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫஜ")+VjZ3hOHdJgzxSPBbU+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࠦ࡝ࠨ஝"))
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IOHSz7YPF9WusGgUt1Dq(u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬஞ"))
	return ndkUxG9LtewJ
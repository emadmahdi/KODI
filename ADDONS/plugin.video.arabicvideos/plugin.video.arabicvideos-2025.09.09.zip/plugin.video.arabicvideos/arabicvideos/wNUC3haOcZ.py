# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ARABSEED'
headers = {'User-Agent':OOsacGDt4owXd52q7gC8l()}
Z0BYJQghVL1v87CAem = '_ARS_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==250: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==251: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==252: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==253: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==254: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'CATEGORIES___'+text)
	elif mode==255: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'FILTERS___'+text)
	elif mode==256: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url,text)
	elif mode==259: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8+'/main',sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,259,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',gAVl1vUmus8+'/category/اخرى',254)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',gAVl1vUmus8+'/category/اخرى',255)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'المميزة',gAVl1vUmus8+'/main',251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured_main')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'جديد الأفلام',gAVl1vUmus8+'/main',251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'new_movies')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'جديد الحلقات',gAVl1vUmus8+'/main',251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'new_episodes')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المضاف حديثاً',gAVl1vUmus8+'/latest',251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'lastest')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('menu__bar hide__md(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	MtCcgLOoBTGp4nqzVhYJliX8Zva6s = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
	Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',MtCcgLOoBTGp4nqzVhYJliX8Zva6s,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO:
		if '/category/' not in B17r2fdFy9ns8tiOMLu: continue
		title = tt36wUe4HTPFmfs5hcbr(title)
		if title not in MqARWHDkmiT4nlz and title!=sCHVtMAvqirbQ4BUK3cgWo:
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,251)
	return Sw0pOFoVhPeIxbl
def ffy5vVCNau6FWgbmp(url,type):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if 'class="SliderInSection' in Sw0pOFoVhPeIxbl: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الأكثر مشاهدة',url,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'most')
	if 'class="MainSlides' in Sw0pOFoVhPeIxbl: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'المميزة',url,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	if 'class="LinksList' in Sw0pOFoVhPeIxbl:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="LinksList(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			if len(oPnz7Zt4xLHTwR)>1 and type=='new_episodes': Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				dwDUvp0LAuyg1rI = fNntYJW45mEFSdRX8g.findall('</i>(.*?)<span>(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
				try: ofLNbsZxdtEvC0gRM2r9khzTeV = dwDUvp0LAuyg1rI[0][0].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				except: ofLNbsZxdtEvC0gRM2r9khzTeV = sCHVtMAvqirbQ4BUK3cgWo
				try: qpC2d7QYwEsVM4SxLnjGZOBbr95 = dwDUvp0LAuyg1rI[0][1].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				except: qpC2d7QYwEsVM4SxLnjGZOBbr95 = sCHVtMAvqirbQ4BUK3cgWo
				dwDUvp0LAuyg1rI = ofLNbsZxdtEvC0gRM2r9khzTeV+AAh0X3OCacr4HpifRGLZKT+qpC2d7QYwEsVM4SxLnjGZOBbr95
				if '<strong>' in title:
					dhY42MxNJjeDb1 = fNntYJW45mEFSdRX8g.findall('</i>(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
					if dhY42MxNJjeDb1: dwDUvp0LAuyg1rI = dhY42MxNJjeDb1[0]
				if not dwDUvp0LAuyg1rI:
					dhY42MxNJjeDb1 = fNntYJW45mEFSdRX8g.findall('alt="(.*?)"',title,fNntYJW45mEFSdRX8g.DOTALL)
					if dhY42MxNJjeDb1: dwDUvp0LAuyg1rI = dhY42MxNJjeDb1[0]
				if dwDUvp0LAuyg1rI:
					if 'key=' in B17r2fdFy9ns8tiOMLu: type = B17r2fdFy9ns8tiOMLu.split('key=')[1]
					else: type = 'newest'
					dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.strip(AAh0X3OCacr4HpifRGLZKT)
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,B17r2fdFy9ns8tiOMLu,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	return
def fs7D0d3QyAT(url,Ffh8yTQ3d6sp):
	iwTyLWxRlNrO1vG9u03MeJSk,data,items = 'GET',sCHVtMAvqirbQ4BUK3cgWo,[]
	if Ffh8yTQ3d6sp=='filters':
		if '?' in url:
			KzUgMjo5wIn7,i68iPmaHVAZknGv2SNpyzCwcFE = 'POST',{}
			vrEJRkchKxtDNiqO1b79mL5eT,MAR96O0yHe7jiIlEXB = url.split('?')
			CChmRfAOZ4eLtczYduF = MAR96O0yHe7jiIlEXB.split('&')
			for mrDfbxOkTg in CChmRfAOZ4eLtczYduF:
				key,value = mrDfbxOkTg.split('=')
				i68iPmaHVAZknGv2SNpyzCwcFE[key] = value
			if CChmRfAOZ4eLtczYduF: iwTyLWxRlNrO1vG9u03MeJSk,url,data = KzUgMjo5wIn7,vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,iwTyLWxRlNrO1vG9u03MeJSk,url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if Ffh8yTQ3d6sp=='filters': oPnz7Zt4xLHTwR = [Sw0pOFoVhPeIxbl]
	elif 'featured' in Ffh8yTQ3d6sp: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="MainSlides(.*?)class="LinksList',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	elif Ffh8yTQ3d6sp=='new_movies': oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	elif Ffh8yTQ3d6sp=='new_episodes': oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	elif Ffh8yTQ3d6sp=='most': oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="SliderInSection(.*?)class="LinksList',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"blocks__section(.*?)"paginate"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if 'featured' in Ffh8yTQ3d6sp:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		WW94e5w08VbEuo1UvSCKyiBDMt = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if WW94e5w08VbEuo1UvSCKyiBDMt:
			ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X,UDYPxMQdNli,T3bQnXl7ZSaYLiC8FR0PIWqOB = zip(*WW94e5w08VbEuo1UvSCKyiBDMt)
			items = zip(ss7YGDbuAIxgnqaQroTV,T3bQnXl7ZSaYLiC8FR0PIWqOB,V9TdsglcWYv0X)
	else:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		if 'WWE' in title: continue
		title = tt36wUe4HTPFmfs5hcbr(title)
		if 'الحلقة' in title:
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,253,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,252,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/selary/' in B17r2fdFy9ns8tiOMLu or 'مسلسل' in title:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,253,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,252,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"paginate"(.*?)</section>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Ffh8yTQ3d6sp)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall('"poster__single".*?data-src="(.*?)".*?alt="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: return
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(AAh0X3OCacr4HpifRGLZKT)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(AAh0X3OCacr4HpifRGLZKT)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"episodes__list boxs__wrapper(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,bbFPOJrmkCaE6ul37XiKU in items:
			title = name+' - حلقة رقم '+bbFPOJrmkCaE6ul37XiKU
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,252,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+'ملف التشغيل',url,252,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def CwkSL1bxVfF9MQerH4N5Jd(title,B17r2fdFy9ns8tiOMLu):
	dwDUvp0LAuyg1rI = fNntYJW45mEFSdRX8g.findall('[a-zA-Z-]+',title,fNntYJW45mEFSdRX8g.DOTALL)
	if dwDUvp0LAuyg1rI: title = dwDUvp0LAuyg1rI[0]
	else: title = title+AAh0X3OCacr4HpifRGLZKT+GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
	title = title.replace('عرب سيد',sCHVtMAvqirbQ4BUK3cgWo).replace('مباشر',sCHVtMAvqirbQ4BUK3cgWo).replace('مشاهدة',sCHVtMAvqirbQ4BUK3cgWo)
	title = title.replace('ٍ',sCHVtMAvqirbQ4BUK3cgWo)
	title = title.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	return title
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	smh8Qbf9jH = GABnmSFOwtsu37(url,'url')
	headers = {'Referer':smh8Qbf9jH}
	cb1fAztguv78n9LGhSWJFm5p = []
	SRGnH2WJIe9rmjYX = fNntYJW45mEFSdRX8g.findall('href="([^"]*)" class="btton download__btn"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if SRGnH2WJIe9rmjYX:
		SRGnH2WJIe9rmjYX = SRGnH2WJIe9rmjYX[0]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',SRGnH2WJIe9rmjYX,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"tabs__holder(.*?)</section>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,l36lfOiDWUt9PMXHR,dwDUvp0LAuyg1rI in items:
				XO7Zr2W6kwieA = fNntYJW45mEFSdRX8g.findall('\d+',dwDUvp0LAuyg1rI,fNntYJW45mEFSdRX8g.DOTALL)
				XO7Zr2W6kwieA = '__'+XO7Zr2W6kwieA[0] if XO7Zr2W6kwieA else sCHVtMAvqirbQ4BUK3cgWo
				if '/l/' in B17r2fdFy9ns8tiOMLu:
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('/l/')[1]
					B17r2fdFy9ns8tiOMLu = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(B17r2fdFy9ns8tiOMLu)
					if I5VKjrFL0Bk97: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+l36lfOiDWUt9PMXHR+'__download'+XO7Zr2W6kwieA
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	eeBGcKQ71ayFoSDp = fNntYJW45mEFSdRX8g.findall('href="(.*?)" class="btton watch__btn"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if BewrUo9ANCa17G43Sn0LH5xh and eeBGcKQ71ayFoSDp:
		eeBGcKQ71ayFoSDp = eeBGcKQ71ayFoSDp[0]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',eeBGcKQ71ayFoSDp,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"watch__area"(.*?)<section',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('href="(.*?)" class="btton download__btn"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def BQjzsA0r83OGo(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	vrEJRkchKxtDNiqO1b79mL5eT = UHqibFEGL8fjKhI.url
	smh8Qbf9jH = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,'url')
	headers['Referer'] = smh8Qbf9jH+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	ss7YGDbuAIxgnqaQroTV,ddQUZA9kChTLcj0XIFup8t = [],[]
	Qph1lem4wZHEvyt8,ccjhoC3yMPTABROfzxrktGQibwH24,rgC2djTJKkXB7DNP03G1hza9lb = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	C1E2lnuoH64Q,XFuct1LpC0abw,STLNfojWAlvx7RqBsYtUmFP8wM = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	uuW3GkR6IMncfphbLa4ViBAD8g5FN = fNntYJW45mEFSdRX8g.findall('"WatchButtons"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if uuW3GkR6IMncfphbLa4ViBAD8g5FN:
		Po9h3gWFuLR2 = uuW3GkR6IMncfphbLa4ViBAD8g5FN[BewrUo9ANCa17G43Sn0LH5xh]
		if '<form' in Po9h3gWFuLR2:
			ddQUZA9kChTLcj0XIFup8t = fNntYJW45mEFSdRX8g.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if ddQUZA9kChTLcj0XIFup8t:
				iwTyLWxRlNrO1vG9u03MeJSk = 'POST'
				for J0FI8ovETc4iqelhzpjR2XSY7DBPHd,name,value in ddQUZA9kChTLcj0XIFup8t:
					if 'wpost' in name: Qph1lem4wZHEvyt8,ccjhoC3yMPTABROfzxrktGQibwH24,rgC2djTJKkXB7DNP03G1hza9lb = J0FI8ovETc4iqelhzpjR2XSY7DBPHd,name,value
					elif 'dpost' in name: C1E2lnuoH64Q,XFuct1LpC0abw,STLNfojWAlvx7RqBsYtUmFP8wM = J0FI8ovETc4iqelhzpjR2XSY7DBPHd,name,value
				JdsQi561jl = ccjhoC3yMPTABROfzxrktGQibwH24+'='+rgC2djTJKkXB7DNP03G1hza9lb
				XSTkhmHFwVpdIRZGLYWfAJzE = XFuct1LpC0abw+'='+STLNfojWAlvx7RqBsYtUmFP8wM
		else:
			ddQUZA9kChTLcj0XIFup8t = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if ddQUZA9kChTLcj0XIFup8t:
				iwTyLWxRlNrO1vG9u03MeJSk = 'GET'
				for B17r2fdFy9ns8tiOMLu in ddQUZA9kChTLcj0XIFup8t:
					if 'wpost' in B17r2fdFy9ns8tiOMLu: Qph1lem4wZHEvyt8 = B17r2fdFy9ns8tiOMLu
					elif 'dpost' in B17r2fdFy9ns8tiOMLu: C1E2lnuoH64Q = B17r2fdFy9ns8tiOMLu
				JdsQi561jl = sCHVtMAvqirbQ4BUK3cgWo
				XSTkhmHFwVpdIRZGLYWfAJzE = sCHVtMAvqirbQ4BUK3cgWo
	if Qph1lem4wZHEvyt8:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,iwTyLWxRlNrO1vG9u03MeJSk,Qph1lem4wZHEvyt8,JdsQi561jl,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="WatcherArea(.*?</ul>)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			EmDNMPbur2HR9Gw0c8QO4aUXt = oPnz7Zt4xLHTwR[0]
			EmDNMPbur2HR9Gw0c8QO4aUXt = EmDNMPbur2HR9Gw0c8QO4aUXt.replace('</ul>','<h3>')
			EmDNMPbur2HR9Gw0c8QO4aUXt = EmDNMPbur2HR9Gw0c8QO4aUXt.replace('<h3>','<h3><h3>')
			Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('<h3>.*?(\d+)(.*?)<h3>',EmDNMPbur2HR9Gw0c8QO4aUXt,fNntYJW45mEFSdRX8g.DOTALL)
			if not Jae64ky3REO57A2MvVHB90: Jae64ky3REO57A2MvVHB90 = [(sCHVtMAvqirbQ4BUK3cgWo,EmDNMPbur2HR9Gw0c8QO4aUXt)]
			for XO7Zr2W6kwieA,Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
				if XO7Zr2W6kwieA: XO7Zr2W6kwieA = '____'+XO7Zr2W6kwieA
				items = fNntYJW45mEFSdRX8g.findall('data-link="(.*?)".*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,name in items:
					if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__watch'+XO7Zr2W6kwieA
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if PXFtqmw5lBGQNa0IV8:
			B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA = PXFtqmw5lBGQNa0IV8[0]
			name = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
			if '%' in XO7Zr2W6kwieA: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__embed__'
			else: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__embed____'+XO7Zr2W6kwieA
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if C1E2lnuoH64Q:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,iwTyLWxRlNrO1vG9u03MeJSk,C1E2lnuoH64Q,XSTkhmHFwVpdIRZGLYWfAJzE,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-PLAY-3rd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="DownloadArea(.*?)<script src=',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			EmDNMPbur2HR9Gw0c8QO4aUXt = oPnz7Zt4xLHTwR[0]
			Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('class="DownloadServers(.*?)</ul>',EmDNMPbur2HR9Gw0c8QO4aUXt,fNntYJW45mEFSdRX8g.DOTALL)
			for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
				items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title,XO7Zr2W6kwieA in items:
					if not B17r2fdFy9ns8tiOMLu: continue
					if 'reviewstation' in B17r2fdFy9ns8tiOMLu: continue
					B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
					B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download____'+XO7Zr2W6kwieA
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	lXAp8kKdZoBRF6 = str(ss7YGDbuAIxgnqaQroTV)
	PMBCoYnud5cytxL23TRaG4h = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in lXAp8kKdZoBRF6 for value in PMBCoYnud5cytxL23TRaG4h):
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search: search = UyBdvjGrFxDWMpmLOXn()
	if not search: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/find/?word='+search+'&type='
	fs7D0d3QyAT(url,'search')
	return
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='CATEGORIES':
		if W1cHmxljniR9X0wqF[0]+'==' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = W1cHmxljniR9X0wqF[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(W1cHmxljniR9X0wqF[0:-1])):
			if W1cHmxljniR9X0wqF[XMIo9vWSBymeLJnK6YsU]+'==' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = W1cHmxljniR9X0wqF[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'==0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'==0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&&')+'___'+nGjoKRMy1mDqUx0.strip('&&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'//getposts??'+ukGBUJAz02tOe
	elif type=='FILTERS':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'//getposts??'+RLkAVfXyplPhsSgb9760oCZW
		Ow0mUS9ZFyzuian = Ilmn8yBUNY3r9M(vrEJRkchKxtDNiqO1b79mL5eT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها ',Ow0mUS9ZFyzuian,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',Ow0mUS9ZFyzuian,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'POST',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ARABSEED-FILTERS_MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	I07DbtCuBVqkFo3UKh = fNntYJW45mEFSdRX8g.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	heCc1gGIWNTpBbd2KO0zufnL = fNntYJW45mEFSdRX8g.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = I07DbtCuBVqkFo3UKh+heCc1gGIWNTpBbd2KO0zufnL
	dict = {}
	for name,ppWPYnc0JHvsmuTBqCXDEkzyN8,Po9h3gWFuLR2 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		items = fNntYJW45mEFSdRX8g.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('data-rate="(.*?)".*?<em>(.*?)</em>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			items = []
			for CCzds3YbQDjKUFxfA5RHMIyBaSt,value in Y0WVJ5CTpDO: items.append([CCzds3YbQDjKUFxfA5RHMIyBaSt,sCHVtMAvqirbQ4BUK3cgWo,value])
			ppWPYnc0JHvsmuTBqCXDEkzyN8 = 'rate'
			name = 'التقييم'
		else: ppWPYnc0JHvsmuTBqCXDEkzyN8 = items[0][1]
		if '==' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='CATEGORIES':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<=1:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==W1cHmxljniR9X0wqF[-1]: fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'CATEGORIES___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				Ow0mUS9ZFyzuian = Ilmn8yBUNY3r9M(vrEJRkchKxtDNiqO1b79mL5eT)
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==W1cHmxljniR9X0wqF[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',Ow0mUS9ZFyzuian,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',vrEJRkchKxtDNiqO1b79mL5eT,254,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='FILTERS':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'==0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'==0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع :'+name,vrEJRkchKxtDNiqO1b79mL5eT,255,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for CCzds3YbQDjKUFxfA5RHMIyBaSt,qLbRrEtgenpSi,value in items:
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			if 'الكل' in CCzds3YbQDjKUFxfA5RHMIyBaSt: continue
			CCzds3YbQDjKUFxfA5RHMIyBaSt = tt36wUe4HTPFmfs5hcbr(CCzds3YbQDjKUFxfA5RHMIyBaSt)
			l36lfOiDWUt9PMXHR,dwDUvp0LAuyg1rI = CCzds3YbQDjKUFxfA5RHMIyBaSt,CCzds3YbQDjKUFxfA5RHMIyBaSt
			dwDUvp0LAuyg1rI = name+': '+l36lfOiDWUt9PMXHR
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = dwDUvp0LAuyg1rI
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=='+l36lfOiDWUt9PMXHR
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			if type=='FILTERS':
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,url,255,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='CATEGORIES' and W1cHmxljniR9X0wqF[-2]+'==' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'modified_filters')
				rdQ5tOIzuelfvcYbNsM = url+'//getposts??'+ukGBUJAz02tOe
				Ow0mUS9ZFyzuian = Ilmn8yBUNY3r9M(rdQ5tOIzuelfvcYbNsM)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,Ow0mUS9ZFyzuian,251,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,url,254,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
W1cHmxljniR9X0wqF = ['category','country','release-year']
y1WTIeidMwHB5USKnC3Eh = ['category','country','genre','release-year','language','quality','rate']
def Ilmn8yBUNY3r9M(url):
	gXEPoDQlsh0dC4xUJqrip = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',gXEPoDQlsh0dC4xUJqrip)
	url = url.replace('/category/اخرى',sCHVtMAvqirbQ4BUK3cgWo)
	if gXEPoDQlsh0dC4xUJqrip not in url: url = url+gXEPoDQlsh0dC4xUJqrip
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&&')
	RI3oQTg7X4E1K6qYcFhvLsJpD,FQZjpoeBUGkTShcbE3d = {},sCHVtMAvqirbQ4BUK3cgWo
	if '==' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('==')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	for key in y1WTIeidMwHB5USKnC3Eh:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if '%' not in value: value = IgCGzHw45TJ7PeuO1EKl(value)
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&&'+key+'=='+value
		elif mode=='all': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&&'+key+'=='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&&')
	return FQZjpoeBUGkTShcbE3d
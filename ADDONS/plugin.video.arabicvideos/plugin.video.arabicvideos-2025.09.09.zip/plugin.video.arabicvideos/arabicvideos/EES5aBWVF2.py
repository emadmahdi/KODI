# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FABRAKA'
Z0BYJQghVL1v87CAem = '_FBK_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الصفحة الرئيسية','Sign in']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==620: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==621: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==622: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==623: ka7jz96YCdTBnQOLVPuJG3285MHf = E5mTvMgjPFJKs1noB7we8i(url,text)
	elif mode==624: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==629: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	aeBQsh4fzLr8XM5xou1gcyE,url,UHqibFEGL8fjKhI = sR7ur2eYBtTXPKqLWHp1jFbcwV(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',gAVl1vUmus8,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,629,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'جديد الحلقات',aeBQsh4fzLr8XM5xou1gcyE,621,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'new_episodes')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'جديد الأفلام',aeBQsh4fzLr8XM5xou1gcyE,621,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'new_movies')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المسلسلات المميزة',aeBQsh4fzLr8XM5xou1gcyE,621,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured_series')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"navslide-wrap"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,624)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('/category.php">(.*?)"navslide-divider"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("'dropdown-menu'(.*?)</ul>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for MtCcgLOoBTGp4nqzVhYJliX8Zva6s in oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = Po9h3gWFuLR2.replace(MtCcgLOoBTGp4nqzVhYJliX8Zva6s,sCHVtMAvqirbQ4BUK3cgWo)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,624)
	return
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FABRAKA-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"presentation"','</ul>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [(sCHVtMAvqirbQ4BUK3cgWo,Po9h3gWFuLR2)]
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' فرز أو فلتر أو ترتيب '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for J8noyr10GLB9exORpmSIHTWiFPc,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if J8noyr10GLB9exORpmSIHTWiFPc: J8noyr10GLB9exORpmSIHTWiFPc = J8noyr10GLB9exORpmSIHTWiFPc+': '
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = J8noyr10GLB9exORpmSIHTWiFPc+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,621)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"pm-category-subcats"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)<30:
			XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			for B17r2fdFy9ns8tiOMLu,title in items:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,621)
	if not GzRKsiw5PBIe1NlrqmQy9STx and not iUtXlDhSVoBZJrPTQAwcER9nfMkN: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FABRAKA-TITLES-1st')
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FABRAKA-TITLES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Po9h3gWFuLR2,items = sCHVtMAvqirbQ4BUK3cgWo,[]
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	elif n1WYDtVC8dRHbXJkMa=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-video-watch-featured"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_episodes':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if len(oPnz7Zt4xLHTwR)>1: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
	elif n1WYDtVC8dRHbXJkMa=='featured_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(data-echo=".*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if Po9h3gWFuLR2 and not items: items = fNntYJW45mEFSdRX8g.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: return
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,622,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif n1WYDtVC8dRHbXJkMa=='new_episodes':
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,622,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,623,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,623,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if 1:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,621)
	return
def E5mTvMgjPFJKs1noB7we8i(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FABRAKA-EPISODES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"series-header".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if Qp3jGv8leCbuiEU5Im: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[0]
	else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = sCHVtMAvqirbQ4BUK3cgWo
	items = []
	irDX4SOHZKIaLUvhyjCbx0T = False
	if GzRKsiw5PBIe1NlrqmQy9STx and not Obes76wjH9LRyEqc2NWPTSphZz34K:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Obes76wjH9LRyEqc2NWPTSphZz34K,title in items:
			Obes76wjH9LRyEqc2NWPTSphZz34K = Obes76wjH9LRyEqc2NWPTSphZz34K.strip('#')
			if len(items)>1: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,623,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,Obes76wjH9LRyEqc2NWPTSphZz34K)
			else: irDX4SOHZKIaLUvhyjCbx0T = True
	else: irDX4SOHZKIaLUvhyjCbx0T = True
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('id="'+Obes76wjH9LRyEqc2NWPTSphZz34K+'"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN and irDX4SOHZKIaLUvhyjCbx0T:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		items = []
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS))
		if not items: items = fNntYJW45mEFSdRX8g.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
			title = title.replace('</em><span>',AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,622,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p = []
	url = url.replace('watch.php','see.php')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FABRAKA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"WatchList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('<iframe src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]+'?named='+title+'__embed'
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downloadlist"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/search.php?keywords='+search
	aeBQsh4fzLr8XM5xou1gcyE,vrEJRkchKxtDNiqO1b79mL5eT,CxP3d82yUTnMa = sR7ur2eYBtTXPKqLWHp1jFbcwV(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT,'search')
	return
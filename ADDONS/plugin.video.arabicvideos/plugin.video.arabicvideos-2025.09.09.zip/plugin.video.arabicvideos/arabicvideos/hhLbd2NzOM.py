# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'BOKRA'
Z0BYJQghVL1v87CAem = '_BKR_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
MqARWHDkmiT4nlz = ['افلام للكبار','بكرا TV']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==370: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==371: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==372: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==374: ka7jz96YCdTBnQOLVPuJG3285MHf = MMuAOPd9DFmy5NQK64IpjbVLqrXg(url)
	elif mode==375: ka7jz96YCdTBnQOLVPuJG3285MHf = oyHLviwPc13stmg60OnZNJ(url)
	elif mode==376: ka7jz96YCdTBnQOLVPuJG3285MHf = MnSOEyaZe8A96Bb5Jxmkjt3fIWNX(0,url)
	elif mode==377: ka7jz96YCdTBnQOLVPuJG3285MHf = MnSOEyaZe8A96Bb5Jxmkjt3fIWNX(1,url)
	elif mode==379: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-MENU-1st')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,379,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('right-side(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',gAVl1vUmus8,375)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الأحدث',gAVl1vUmus8,376)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'قائمة الممثلين',gAVl1vUmus8,374)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="container"(.*?)top-menu',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items[7:]:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371)
		for B17r2fdFy9ns8tiOMLu,title in items[0:7]:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371)
	return
def MMuAOPd9DFmy5NQK64IpjbVLqrXg(website=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-ACTORSMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="row cat Tags"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'http' in B17r2fdFy9ns8tiOMLu: continue
			else: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371)
	return
def oyHLviwPc13stmg60OnZNJ(website=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-FEATURED-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"MainContent"(.*?)main-title2',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('://',':///').replace('//','/').replace(AAh0X3OCacr4HpifRGLZKT,'%20')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,372,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def MnSOEyaZe8A96Bb5Jxmkjt3fIWNX(id,website=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-WATCHINGNOW-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-title2(.*?)class="row',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[id]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if not any(value in title for value in MqARWHDkmiT4nlz):
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('://',':///').replace('//','/').replace(AAh0X3OCacr4HpifRGLZKT,'%20')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,372,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def fs7D0d3QyAT(url,RvEJc0WgkhHQ29U743OKZa=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if 'vidpage_' in url:
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('href="(/Album-.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu[0]
			fs7D0d3QyAT(B17r2fdFy9ns8tiOMLu)
			return
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class=" subcats"(.*?)class="col-md-3',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if RvEJc0WgkhHQ29U743OKZa==sCHVtMAvqirbQ4BUK3cgWo and oPnz7Zt4xLHTwR and oPnz7Zt4xLHTwR[0].count('href')>1:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',url,371,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'titles')
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371)
	else:
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="col-md-3(.*?)col-xs-12',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="col-sm-8"(.*?)col-xs-12',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('://',':///').replace('//','/').replace(AAh0X3OCacr4HpifRGLZKT,'%20')
				if '/al_' in B17r2fdFy9ns8tiOMLu:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) - +الحلقة +\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
					if bbFPOJrmkCaE6ul37XiKU: title = '_MOD_مسلسل '+bbFPOJrmkCaE6ul37XiKU[0]
					if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
						AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
						XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,372,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('class="".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
				title = 'صفحة '+tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,371,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'titles')
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('label-success mrg-btm-5 ">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	rdQ5tOIzuelfvcYbNsM = sCHVtMAvqirbQ4BUK3cgWo
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('var url = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
	else: vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/vidpage_','/Play/')
	if 'http' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+vrEJRkchKxtDNiqO1b79mL5eT
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.strip('-')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(xCE0toTumIHWiLyMfF,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'BOKRA-PLAY-2nd')
	ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
	rdQ5tOIzuelfvcYbNsM = fNntYJW45mEFSdRX8g.findall('src="(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
	if rdQ5tOIzuelfvcYbNsM:
		rdQ5tOIzuelfvcYbNsM = rdQ5tOIzuelfvcYbNsM[-1]
		if 'http' not in rdQ5tOIzuelfvcYbNsM: rdQ5tOIzuelfvcYbNsM = 'http:'+rdQ5tOIzuelfvcYbNsM
		if '/PLAY/' not in vrEJRkchKxtDNiqO1b79mL5eT:
			if 'embed.min.js' in rdQ5tOIzuelfvcYbNsM:
				ddB7cunzbmtoMLW0 = fNntYJW45mEFSdRX8g.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
				if ddB7cunzbmtoMLW0:
					Yvw9tFmq7NOCjs0I64RBJe, J2ZmsnUi316jb0 = ddB7cunzbmtoMLW0[0]
					rdQ5tOIzuelfvcYbNsM = GABnmSFOwtsu37(rdQ5tOIzuelfvcYbNsM,'url')+'/v2/'+Yvw9tFmq7NOCjs0I64RBJe+'/config/'+J2ZmsnUi316jb0+'.json'
		import c27OeP8ifd
		c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1([rdQ5tOIzuelfvcYbNsM],Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/Search/'+search
	fs7D0d3QyAT(url)
	return
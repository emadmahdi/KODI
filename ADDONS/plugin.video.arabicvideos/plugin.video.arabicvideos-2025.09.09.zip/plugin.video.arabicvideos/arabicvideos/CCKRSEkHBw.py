# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from nd6qWvh3Ve import *
from tqHErj9p1I import *
import base64 as JzkVPibWdBTRMGo15CjtnlUy9Hu8fX
Ll1m0nJoaAPvHsXqyRE = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ༑")
if I5VKjrFL0Bk97:
	T169TYotn5V = DuYdwp9gNe1nE7qbT.translatePath(GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ༒"))
	ns962b50AYBo8k = DuYdwp9gNe1nE7qbT.translatePath(EJgYdjbIiWe1apkQlZcR42(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭༓"))
	fMnyRlYuDxPHvjC = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,sH6BOz5wKRFcEg(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ༔"),SE97R3Dpj6dPLweVKU(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭༕"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪ༖"))
	WxSD2nC9mkUMVu = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,BWfpRku7SsM6cbE0eG(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ༗"),fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦ༘ࠩ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨ༙"))
	n0neOuhY3xdkSvFQXwoHf4i2l19q = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,IOHSz7YPF9WusGgUt1Dq(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ༚"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ༛"),qeG16a4pbSHziNVQ2uFXrs(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫ༜"))
	from urllib.parse import quote as _8KvBQjAnCw
else:
	T169TYotn5V = FoiwfTEhGD8ulS25HeUvnI.translatePath(gDETKVh8mZe09Nd(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭༝"))
	ns962b50AYBo8k = FoiwfTEhGD8ulS25HeUvnI.translatePath(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ༞"))
	fMnyRlYuDxPHvjC = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ༟"),SE97R3Dpj6dPLweVKU(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ༠"),sH6BOz5wKRFcEg(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠴࠺࠲ࡩࡨࠧ༡"))
	WxSD2nC9mkUMVu = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ༢"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭༣"),TzIj50KpohEOHx6CbZWqB(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ༤"))
	n0neOuhY3xdkSvFQXwoHf4i2l19q = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,BWfpRku7SsM6cbE0eG(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ༥"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ༦"),IOHSz7YPF9WusGgUt1Dq(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ༧"))
	from urllib import quote as _8KvBQjAnCw
GJ96QNqUWSpM40HlLdYsAfVkgKZ = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ns962b50AYBo8k,IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ༨"))
Q8fWtaezok9gNZbuilHc36IOX = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ns962b50AYBo8k,IOHSz7YPF9WusGgUt1Dq(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ༩"))
JJkHbPqLZtIUMFrWlA41C9EaOdy = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,IOHSz7YPF9WusGgUt1Dq(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭༪"))
H5HkipzgNFQSTObj3CPfcV = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ༫"))
EEeKyBGvrkDn5CgHOSXs2 = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,oVwa0kcqxj1e7mLplAfZdGT(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭༬"))
u3yGxS2mRw1fW54N7DchIvEoaq = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨ༭"))
nVBSuE26QPC9dy = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,sH6BOz5wKRFcEg(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ༮"))
m5ONVyjLqsA90BJfuUTZQDw = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,bGzRdmOErkIylxALniq6(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ༯"))
ffBvikd9sV = UFrHeStKa3MmB6o1xfsECp9VbN.Addon().getAddonInfo(fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡴࡦࡺࡨࠨ༰"))
UvMDPtgRVLnHT = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭༱"))
nnsZ7GJjkoOCm = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ༲"))
IFnt6y1WaB5HDY32RPkC7iqpxo = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ༳"))
OOemwT278AcMUPgL65uW0ykaFsxRY = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,SE97R3Dpj6dPLweVKU(u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ༴"))
tYzpdDO3uvWZRl = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,RDwahqjPfbdyEiTtnLQu(u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨ༵"))
mgZ8M1v6fb9dVPSB = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,hPFcB6Uxmabj59Iq(u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭༶"))
X0Omf5ADrZGM83nRh2YQJpvyBa = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩ༷ࠪ"))
f183sWBmD6LXzhtoE2arqYMik = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪ༸"))
vcUEd8DY4u6zXiO1o = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,IO7k2hZXSz(u"ࠬࡳࡥ࡯ࡷࡢࡶࡪࡪ࡟࠳࠲࠳ࡼ࠷࠻࠰࠯ࡲࡱ࡫༹ࠬ"))
oAOpesfZdgqDaJmXSKPi = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭༺"))
Tv3HwUmSdkPOKaC5QulpJcDqy = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,sH6BOz5wKRFcEg(u"ࠧࡢࡦࡧࡳࡳࡹࠧ༻"))
RvhOKYnirjD5CWyHs7ao = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ༼"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭༽"),Xkp839QMmYzrsoWTyca)
Y9Y7tpco2OSwMr5h4eZ3siT = YYEXZsUWhf52vz7HLxc0qGJ.path.join(RvhOKYnirjD5CWyHs7ao,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ༾"))
JJkcTYwWo0 = set(Q1siCkTZyw.BADWEBSITES)
yy2piuoUNchWGelADxq7Q1 = [UqKgalXPCz7eQAL08foMx1R for UqKgalXPCz7eQAL08foMx1R in yy2piuoUNchWGelADxq7Q1 if UqKgalXPCz7eQAL08foMx1R not in JJkcTYwWo0]
lAF6gQMxJOK = [UqKgalXPCz7eQAL08foMx1R for UqKgalXPCz7eQAL08foMx1R in lAF6gQMxJOK if UqKgalXPCz7eQAL08foMx1R not in JJkcTYwWo0]
ccehpQ8jEwfV1garCtYiOHS6PzqKyk = [UqKgalXPCz7eQAL08foMx1R for UqKgalXPCz7eQAL08foMx1R in ccehpQ8jEwfV1garCtYiOHS6PzqKyk if UqKgalXPCz7eQAL08foMx1R not in JJkcTYwWo0]
imU5I1ewc4dEHvkQ8 = [UqKgalXPCz7eQAL08foMx1R for UqKgalXPCz7eQAL08foMx1R in imU5I1ewc4dEHvkQ8 if UqKgalXPCz7eQAL08foMx1R not in JJkcTYwWo0]
P0SFzyBJp94qMnNH3hQ1aDfZT82x = [UqKgalXPCz7eQAL08foMx1R for UqKgalXPCz7eQAL08foMx1R in P0SFzyBJp94qMnNH3hQ1aDfZT82x if UqKgalXPCz7eQAL08foMx1R not in JJkcTYwWo0]
class kGX9IF07jirosWYaf3c():
	def __init__(thP1UxTJWikB5QSNM9ERdDIbOpfZ,showDialogs=lvzrYTpcBaK,logErrors=ndkUxG9LtewJ):
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.showDialogs = showDialogs
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.logErrors = logErrors
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.finishedLIST,thP1UxTJWikB5QSNM9ERdDIbOpfZ.failedLIST = [],[]
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.statusDICT,thP1UxTJWikB5QSNM9ERdDIbOpfZ.resultsDICT = {},{}
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.processesLIST = []
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.starttimeDICT,thP1UxTJWikB5QSNM9ERdDIbOpfZ.finishtimeDICT,thP1UxTJWikB5QSNM9ERdDIbOpfZ.elpasedtimeDICT = {},{},{}
	def wlbeaA4Xu5Wj(thP1UxTJWikB5QSNM9ERdDIbOpfZ,W0wg5RhFv2j8fr1B,S05jute4Vcsn7TwCZa,*aargs):
		W0wg5RhFv2j8fr1B = str(W0wg5RhFv2j8fr1B)
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.statusDICT[W0wg5RhFv2j8fr1B] = fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬ༿")
		if thP1UxTJWikB5QSNM9ERdDIbOpfZ.showDialogs: iRaHzNpJhSx6ZnCfrvD7j93lks(sCHVtMAvqirbQ4BUK3cgWo,W0wg5RhFv2j8fr1B)
		BMscHRxPIvdGhaFZ0Vo9Er4jX = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=thP1UxTJWikB5QSNM9ERdDIbOpfZ.XXlrGNK8YacWyIjgHCAOFq3vwpdS,args=(W0wg5RhFv2j8fr1B,S05jute4Vcsn7TwCZa,aargs))
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.processesLIST.append(BMscHRxPIvdGhaFZ0Vo9Er4jX)
		return BMscHRxPIvdGhaFZ0Vo9Er4jX
	def pQfd3FT4Jz7G(thP1UxTJWikB5QSNM9ERdDIbOpfZ,W0wg5RhFv2j8fr1B,S05jute4Vcsn7TwCZa,*aargs):
		BMscHRxPIvdGhaFZ0Vo9Er4jX = thP1UxTJWikB5QSNM9ERdDIbOpfZ.wlbeaA4Xu5Wj(W0wg5RhFv2j8fr1B,S05jute4Vcsn7TwCZa,*aargs)
		BMscHRxPIvdGhaFZ0Vo9Er4jX.start()
	def XXlrGNK8YacWyIjgHCAOFq3vwpdS(thP1UxTJWikB5QSNM9ERdDIbOpfZ,W0wg5RhFv2j8fr1B,S05jute4Vcsn7TwCZa,aargs):
		W0wg5RhFv2j8fr1B = str(W0wg5RhFv2j8fr1B)
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.starttimeDICT[W0wg5RhFv2j8fr1B] = hDjf1Ubgq629nXlOvcFLH4Jw.time()
		try:
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.resultsDICT[W0wg5RhFv2j8fr1B] = S05jute4Vcsn7TwCZa(*aargs)
			if IOHSz7YPF9WusGgUt1Dq(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ཀ") in str(S05jute4Vcsn7TwCZa) and not thP1UxTJWikB5QSNM9ERdDIbOpfZ.resultsDICT[W0wg5RhFv2j8fr1B].succeeded: xxpJdCwRN6SrscbOmga7h5UlHBiW()
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.finishedLIST.append(W0wg5RhFv2j8fr1B)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.statusDICT[W0wg5RhFv2j8fr1B] = GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨཁ")
		except Exception as QQa32JB7je0XdftAuz6yvxZsrViPo:
			if thP1UxTJWikB5QSNM9ERdDIbOpfZ.logErrors:
				Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
				if Ro2CsQFGOj14wKIgcuHJ!=qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪག"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.failedLIST.append(W0wg5RhFv2j8fr1B)
			thP1UxTJWikB5QSNM9ERdDIbOpfZ.statusDICT[W0wg5RhFv2j8fr1B] = aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨགྷ")
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.finishtimeDICT[W0wg5RhFv2j8fr1B] = hDjf1Ubgq629nXlOvcFLH4Jw.time()
		thP1UxTJWikB5QSNM9ERdDIbOpfZ.elpasedtimeDICT[W0wg5RhFv2j8fr1B] = thP1UxTJWikB5QSNM9ERdDIbOpfZ.finishtimeDICT[W0wg5RhFv2j8fr1B] - thP1UxTJWikB5QSNM9ERdDIbOpfZ.starttimeDICT[W0wg5RhFv2j8fr1B]
	def Cks6uN5Dm8cZRd7pL(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		for Z3bWwelnq1daSk6sBuo in thP1UxTJWikB5QSNM9ERdDIbOpfZ.processesLIST:
			Z3bWwelnq1daSk6sBuo.start()
	def levYBZEi5Swz4jyxt7nLDrWOkuXa(thP1UxTJWikB5QSNM9ERdDIbOpfZ):
		while IO7k2hZXSz(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪང") in list(thP1UxTJWikB5QSNM9ERdDIbOpfZ.statusDICT.values()): hDjf1Ubgq629nXlOvcFLH4Jw.sleep(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠶ᕙ"))
def h6kpld5nzQUJgbfGMemtj3B1():
	if not GsowyWv4QneEtJ: return Js61GTdX5wzMurUqi7Z(u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭ཅ")
	w8zyLag3EZOmiPK5WITvVo9GQnHrY = aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩཆ")
	FIHRKzwZJou8nTP1dryLtc = [aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠾࠮࠶࠰࠳ࠫཇ"),BWfpRku7SsM6cbE0eG(u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ཈"),sH6BOz5wKRFcEg(u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬཉ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬཊ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭ཋ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧཌ"),jwzOabysh0Z(u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨཌྷ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩཎ"),RDwahqjPfbdyEiTtnLQu(u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪཏ"),bGzRdmOErkIylxALniq6(u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫཐ"),EJgYdjbIiWe1apkQlZcR42(u"ࠨ࠴࠳࠶࠹࠴࠰࠲࠰࠴࠸ࠬད"),TzIj50KpohEOHx6CbZWqB(u"ࠩ࠵࠴࠷࠺࠮࠱࠹࠱࠶࠵࠭དྷ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪ࠶࠵࠸࠵࠯࠲࠸࠲࠵࠻ࠧན")]
	an1YPvIm5Hi = FIHRKzwZJou8nTP1dryLtc[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	xdTktfXSIO = VxJn5edvBgR7s2QqfAjw4(an1YPvIm5Hi)
	GGRPEdHMSq6oeZTA3Yi = VxJn5edvBgR7s2QqfAjw4(WHzJr591Ka8gRdbiLmBp0hT3S)
	if GGRPEdHMSq6oeZTA3Yi>xdTktfXSIO:
		w8zyLag3EZOmiPK5WITvVo9GQnHrY = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫཔ")
	return w8zyLag3EZOmiPK5WITvVo9GQnHrY
def YzTg4VFtHGSLNrXQZPjuhcy3W6oOK(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP):
	AAujtyiVHpQ68Uvcnz7S4sP2,F3FX7q1vIHAQRCfy5gn = sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP: AAujtyiVHpQ68Uvcnz7S4sP2 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,Js61GTdX5wzMurUqi7Z(u"ࠬࡹࡴࡳࠩཕ"),fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫབ"),SE97R3Dpj6dPLweVKU(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩབྷ"))
	if not AAujtyiVHpQ68Uvcnz7S4sP2:
		ZvWwXBJxzk3Qi9uAHKTD8hY2 = Q1siCkTZyw.SITESURLS[fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨམ")][wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠿ᕚ")]
		QDeqblFjHiWLB7om09XrUygT = {Js61GTdX5wzMurUqi7Z(u"ࠩࡸࡷࡪࡸࠧཙ"):Q1siCkTZyw.AV_CLIENT_IDS,jwzOabysh0Z(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫཚ"):WHzJr591Ka8gRdbiLmBp0hT3S}
		AAujtyiVHpQ68Uvcnz7S4sP2 = mpfNBWFjnzLs(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡕࡕࡓࡕࠩཛ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,QDeqblFjHiWLB7om09XrUygT,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡤࡖ࡙ࡕࡊࡒࡒࡤࡉࡏࡅࡇ࠰࠵ࡸࡺࠧཛྷ"))
		jq1yMu9V5Bt3lxh6K(Q1siCkTZyw.api_python_actions[E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠹ᕛ")])
		if AAujtyiVHpQ68Uvcnz7S4sP2: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,jwzOabysh0Z(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫཝ"),EJgYdjbIiWe1apkQlZcR42(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩཞ"),AAujtyiVHpQ68Uvcnz7S4sP2,IfAkw39UvaYWEDXLthFrbSzG)
		F3FX7q1vIHAQRCfy5gn = ndkUxG9LtewJ
	if AAujtyiVHpQ68Uvcnz7S4sP2:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
		exec(AAujtyiVHpQ68Uvcnz7S4sP2,globals(),locals())
		Q1siCkTZyw.SITESURLS.update(NEW_SITESURLS)
		Q1siCkTZyw.BADSCRAPERS = list(set(Q1siCkTZyw.BADSCRAPERS+NEW_BADSCRAPERS))
		Q1siCkTZyw.BADCOMMONIDS = list(set(Q1siCkTZyw.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if WHzJr591Ka8gRdbiLmBp0hT3S in list(NEW_BADWEBSITES.keys()): Q1siCkTZyw.BADWEBSITES += NEW_BADWEBSITES[WHzJr591Ka8gRdbiLmBp0hT3S]
	return F3FX7q1vIHAQRCfy5gn
def FFKCPmhnBy3EfGqO0eNo5V9cR4dp8():
	try: YYEXZsUWhf52vz7HLxc0qGJ.makedirs(XX4rMRSnQdbZ1NJiKu8pOfvDla)
	except: pass
	W8WxH0KGfs2DPAe3OLEl = h6kpld5nzQUJgbfGMemtj3B1()
	if W8WxH0KGfs2DPAe3OLEl==EJgYdjbIiWe1apkQlZcR42(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨཟ"): SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,bGzRdmOErkIylxALniq6(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨའ")+ERbOfw2FjKUAZGo+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࠤࡢ࠭ཡ"))
	else: SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,Js61GTdX5wzMurUqi7Z(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨར")+ERbOfw2FjKUAZGo+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࠦ࡝ࠨལ"))
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Js61GTdX5wzMurUqi7Z(u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭ཤ")+WHzJr591Ka8gRdbiLmBp0hT3S)
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,TzIj50KpohEOHx6CbZWqB(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪཥ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭ས"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,IO7k2hZXSz(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠸ࠧཧ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ཨ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩཀྵ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨཪ"),Js61GTdX5wzMurUqi7Z(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫཫ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,YQNd4wejLSAVJ6T(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪཬ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧ཭"))
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩ཮"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬ཯"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳ࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ཰"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨཱ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ིࠩ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴཱིࠩ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹུ࠭"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(hPFcB6Uxmabj59Iq(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳཱུࠩ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧྲྀ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(SE97R3Dpj6dPLweVKU(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬཷ"),sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Js61GTdX5wzMurUqi7Z(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧླྀ"),sCHVtMAvqirbQ4BUK3cgWo)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧཹ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,SIkwCEdJHTD9v1(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ེࠧ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,sH6BOz5wKRFcEg(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸ཻ࡛ࠧ"))
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,gDETKVh8mZe09Nd(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖོࠫ"))
	Hy2bntGarc7J(lvzrYTpcBaK)
	hO36FxWalTjkvQ9IzPH7bo(UTCXGnK7Fs4Y5pNkt2ARDWuw)
	import i5kNU6T7vE
	i5kNU6T7vE.oodkrSivUAOcRaIZEHQx32VL7bnX(RDwahqjPfbdyEiTtnLQu(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧཽࠪ"),lvzrYTpcBaK)
	i5kNU6T7vE.oodkrSivUAOcRaIZEHQx32VL7bnX(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧཾ"),lvzrYTpcBaK)
	i5kNU6T7vE.oodkrSivUAOcRaIZEHQx32VL7bnX(IOHSz7YPF9WusGgUt1Dq(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡪ࡫ࡳࡰࡦࡩࡧ࡭ࡷ࡫ࡣࡵࠩཿ"),lvzrYTpcBaK)
	i5kNU6T7vE.z1zgwnV9AhRXZlUePbrGp(ndkUxG9LtewJ)
	i5kNU6T7vE.BsXf0nkEaz8peqiST(lvzrYTpcBaK)
	if W8WxH0KGfs2DPAe3OLEl==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊྀ࠭"):
		ltKCxe0hWVn5jQ(ndkUxG9LtewJ,[qD1l8d3bQVN2uanhBLpyWTtcx])
	else:
		ltKCxe0hWVn5jQ(lvzrYTpcBaK,[])
		i5kNU6T7vE.os617uvdNSDGn()
		try:
			sVB7FNgmOydqfA9kDwKlczb4e5t2Y = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢཱྀࠩ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬྂ"),TzIj50KpohEOHx6CbZWqB(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ྃ"),IO7k2hZXSz(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭྄ࠩ"))
			zutInfbQdP5rXKGA = UFrHeStKa3MmB6o1xfsECp9VbN.Addon(id=zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ྅"))
			zutInfbQdP5rXKGA.setSetting(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡧࡶ࠯ࡣࡸࡸࡴࡥࡰࡪࡥ࡮ࠫ྆"),BWfpRku7SsM6cbE0eG(u"࠭ࡆࡢ࡮ࡶࡩࠬ྇"))
		except: pass
		try:
			sVB7FNgmOydqfA9kDwKlczb4e5t2Y = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩྈ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬྉ"),BWfpRku7SsM6cbE0eG(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩྊ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩྋ"))
			zutInfbQdP5rXKGA = UFrHeStKa3MmB6o1xfsECp9VbN.Addon(id=aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫྌ"))
			zutInfbQdP5rXKGA.setSetting(hPFcB6Uxmabj59Iq(u"ࠬࡧࡶ࠯ࡸ࡬ࡨࡪࡵ࡟ࡲࡷࡤࡰ࡮ࡺࡹࠨྍ"),YQNd4wejLSAVJ6T(u"࠭࠳ࠨྎ"))
		except: pass
		try:
			sVB7FNgmOydqfA9kDwKlczb4e5t2Y = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,BWfpRku7SsM6cbE0eG(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩྏ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬྐ"),SIkwCEdJHTD9v1(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩྑ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩྒ"))
			zutInfbQdP5rXKGA = UFrHeStKa3MmB6o1xfsECp9VbN.Addon(id=aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫྒྷ"))
			zutInfbQdP5rXKGA.setSetting(aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡧࡶ࠯ࡕࡗࡖࡊࡇࡍࡔࡇࡏࡉࡈ࡚ࡉࡐࡐࠪྔ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠭࠲ࠨྕ"))
		except: pass
	gWlmUqwV3YrIT2XNPxQCisBHSDG9 = IV2b9wBsc0SmCaUEkNDK(nbfoUAIGjyD2PQcSJO)
	gWlmUqwV3YrIT2XNPxQCisBHSDG9 = IV2b9wBsc0SmCaUEkNDK(u3yGxS2mRw1fW54N7DchIvEoaq)
	i5kNU6T7vE.M2kZysTmRDFcK9ofSx(lvzrYTpcBaK)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(TzIj50KpohEOHx6CbZWqB(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫྖ"),WHzJr591Ka8gRdbiLmBp0hT3S)
	Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def U5JhK4daVybAziFn8Qsrfum(kkJoBAxwN3VrDH):
	F3FX7q1vIHAQRCfy5gn = YzTg4VFtHGSLNrXQZPjuhcy3W6oOK(ndkUxG9LtewJ)
	if F3FX7q1vIHAQRCfy5gn:
		return
	PgiydOHjRF = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(IOHSz7YPF9WusGgUt1Dq(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭ྗ")))
	PgiydOHjRF = BewrUo9ANCa17G43Sn0LH5xh if not PgiydOHjRF else int(PgiydOHjRF)
	if not PgiydOHjRF or not BewrUo9ANCa17G43Sn0LH5xh<=JVAlZw9Nsnj-PgiydOHjRF<=EGwIN9K6n5rVsjpLC4qvSUTyo3Z2:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(TzIj50KpohEOHx6CbZWqB(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡵ࡫ࡳࡷࡺࠧ྘"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
		hO36FxWalTjkvQ9IzPH7bo(UTCXGnK7Fs4Y5pNkt2ARDWuw)
		return
	ookgIeBpN5E26dVDcnRTvKAjqz = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬྙ")))
	ookgIeBpN5E26dVDcnRTvKAjqz = BewrUo9ANCa17G43Sn0LH5xh if not ookgIeBpN5E26dVDcnRTvKAjqz else int(ookgIeBpN5E26dVDcnRTvKAjqz)
	GFNtSRs3zXY08DxQm5ilpW = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ྚ")))
	GFNtSRs3zXY08DxQm5ilpW = BewrUo9ANCa17G43Sn0LH5xh if not GFNtSRs3zXY08DxQm5ilpW else int(GFNtSRs3zXY08DxQm5ilpW)
	if not ookgIeBpN5E26dVDcnRTvKAjqz or not GFNtSRs3zXY08DxQm5ilpW or not BewrUo9ANCa17G43Sn0LH5xh<=JVAlZw9Nsnj-GFNtSRs3zXY08DxQm5ilpW<=ookgIeBpN5E26dVDcnRTvKAjqz:
		ffUAMOwXtQkK(ndkUxG9LtewJ,ookgIeBpN5E26dVDcnRTvKAjqz)
		return
	G9pHx05lkALE = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬྛ")))
	G9pHx05lkALE = BewrUo9ANCa17G43Sn0LH5xh if not G9pHx05lkALE else int(G9pHx05lkALE)
	if not G9pHx05lkALE or not BewrUo9ANCa17G43Sn0LH5xh<=JVAlZw9Nsnj-G9pHx05lkALE<=NjPWfJS7CUoTsz4lKk0hg:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ྜ"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
		YzTg4VFtHGSLNrXQZPjuhcy3W6oOK(lvzrYTpcBaK)
		return
	if lvzrYTpcBaK:
		eC3HOGUqgfwA2aKlpT = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(gDETKVh8mZe09Nd(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫྜྷ")))
		eC3HOGUqgfwA2aKlpT = BewrUo9ANCa17G43Sn0LH5xh if not eC3HOGUqgfwA2aKlpT else int(eC3HOGUqgfwA2aKlpT)
		if not eC3HOGUqgfwA2aKlpT or not BewrUo9ANCa17G43Sn0LH5xh<=JVAlZw9Nsnj-eC3HOGUqgfwA2aKlpT<=OOht4Ly9dmZMIz:
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬྞ"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
	return
def ffUAMOwXtQkK(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP,ookgIeBpN5E26dVDcnRTvKAjqz):
	CPVzbJEYn3 = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	n9WSIFALzeH0v = lvzrYTpcBaK if Q1siCkTZyw.hc1vNqbTWYrBo69ynVau4QRHs else ndkUxG9LtewJ
	if n9WSIFALzeH0v:
		if not ookgIeBpN5E26dVDcnRTvKAjqz: R1doy3mDZ4cJVTw5FGLY2t0KxiBvP = lvzrYTpcBaK
		Q3KzTrUfXiFAhEGg1W72toxyIPudmp = NIEPcjs2b0YDrZ7(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP)
		if len(Q3KzTrUfXiFAhEGg1W72toxyIPudmp)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࠱ࡠࡹ࡙ࡨࡰࡹ࡬ࡲ࡬ࠦࡑࡶࡧࡶࡸ࡮ࡵ࡮ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬྟ")+ERbOfw2FjKUAZGo+RDwahqjPfbdyEiTtnLQu(u"ࠪࠤࡢ࠭ྠ"))
			W0wg5RhFv2j8fr1B,qtWgRvai4wjFumUCLMH,r1PgycpO2EHAuM,oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6,j7CADXI1yWt90Gc52HrsUhKeN = Q3KzTrUfXiFAhEGg1W72toxyIPudmp[BewrUo9ANCa17G43Sn0LH5xh]
			ss5d8hPGLTrFC4eBJmIgMvXnK3,zMPElG9TxQkZ2UXf03CDJvncR5Kgr = oAsDQxGyP2kFK7wYiIN.split(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡡࡴ࠻࠼ࠩྡ"))
			del Q3KzTrUfXiFAhEGg1W72toxyIPudmp[BewrUo9ANCa17G43Sn0LH5xh]
			KIcM6BqA4G = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(Q3KzTrUfXiFAhEGg1W72toxyIPudmp,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			W0wg5RhFv2j8fr1B,qtWgRvai4wjFumUCLMH,r1PgycpO2EHAuM,oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6,j7CADXI1yWt90Gc52HrsUhKeN = KIcM6BqA4G[BewrUo9ANCa17G43Sn0LH5xh]
			r1PgycpO2EHAuM = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡡࡒࡕࡎࡠࠫྡྷ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+hPFcB6Uxmabj59Iq(u"࠭ࠠ࠻ࠢࠪྣ")+W0wg5RhFv2j8fr1B+B8alA5nvIhTxQ+r1PgycpO2EHAuM
			bg1dAEcph3zqxXio4eL0fQ8CJtjWu6 = jwzOabysh0Z(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ྤ")
			lSuHhDE4L9Wx7n2QGoUIjiemKC = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨษ็ฮอืูศฬࠪྥ")
			button0,button1 = oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6
			JVXYbzyvU6hmQRHWKeZ = [button0,button1,lSuHhDE4L9Wx7n2QGoUIjiemKC]
			zcL2SdjgEmO39ly4CQT = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU if Q1siCkTZyw.P56VUO0NuA8bq else fvYGxnZNUiyP4HJkMIoS25(u"࠲࠲ᕜ")
			WQOh7NoUEJuHgGK0pzTrktyeLjxMB = -t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠻ᕝ")
			while WQOh7NoUEJuHgGK0pzTrktyeLjxMB<BewrUo9ANCa17G43Sn0LH5xh:
				yZR4Vr3mFJwnuH6Pilhojqp85sc0k = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(JVXYbzyvU6hmQRHWKeZ,vUnJhT2NO8yirHcAmg)
				WQOh7NoUEJuHgGK0pzTrktyeLjxMB = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,yZR4Vr3mFJwnuH6Pilhojqp85sc0k[BewrUo9ANCa17G43Sn0LH5xh],yZR4Vr3mFJwnuH6Pilhojqp85sc0k[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],yZR4Vr3mFJwnuH6Pilhojqp85sc0k[rgpY5VUqKbeFOCD9Nki2SmGvxEja],ss5d8hPGLTrFC4eBJmIgMvXnK3,r1PgycpO2EHAuM,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫྦ"),zcL2SdjgEmO39ly4CQT,BWfpRku7SsM6cbE0eG(u"࠹࠴ᕞ"))
				if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==zLjWeKu6JgNO7vocUD0Qpy(u"࠵࠵ᕟ"): break
				import i5kNU6T7vE
				if WQOh7NoUEJuHgGK0pzTrktyeLjxMB>=BewrUo9ANCa17G43Sn0LH5xh and yZR4Vr3mFJwnuH6Pilhojqp85sc0k[WQOh7NoUEJuHgGK0pzTrktyeLjxMB]==JVXYbzyvU6hmQRHWKeZ[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]:
					i5kNU6T7vE.QiGkIR6Eys()
					if WQOh7NoUEJuHgGK0pzTrktyeLjxMB>=BewrUo9ANCa17G43Sn0LH5xh: WQOh7NoUEJuHgGK0pzTrktyeLjxMB = -qeG16a4pbSHziNVQ2uFXrs(u"࠾ᕠ")
				elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB>=BewrUo9ANCa17G43Sn0LH5xh and yZR4Vr3mFJwnuH6Pilhojqp85sc0k[WQOh7NoUEJuHgGK0pzTrktyeLjxMB]==JVXYbzyvU6hmQRHWKeZ[rgpY5VUqKbeFOCD9Nki2SmGvxEja]:
					i5kNU6T7vE.RRIKPjLqlmtoOVa6JGedr74hkc(lvzrYTpcBaK)
				if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,F7Fe63KbGjaz2TcmCNHPdo5QiXO+hPFcB6Uxmabj59Iq(u"ࠪาึ๎ฬࠡะฺวࠬྦྷ")+B8alA5nvIhTxQ+jwzOabysh0Z(u"ࠫࡡࡴࠠๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩྨ"))
			CPVzbJEYn3 = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		else: CPVzbJEYn3 = BewrUo9ANCa17G43Sn0LH5xh
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧྩ"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩྪ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬྫ"),CPVzbJEYn3,IfAkw39UvaYWEDXLthFrbSzG)
	return
def du4vrTO0AtShVl(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA):
	if cwnGP8Qo6h in [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࠳ࠪྫྷ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠩ࠵ࠫྭ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪ࠷ࠬྮ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠹࠭ྯ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࠻ࠧྰ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠭࠱࠲ࠩྱ"),EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠲࠴ࠪྲ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ࠳࠶ࠫླ")] and T5Teu1pJhvEmgkcn7OoA:
		import gRQYBo5zxp
		gRQYBo5zxp.xlatCDi92hr0nNjVqgcSvp84(IFYonX8LZUfz3VJyuQlxgE,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA)
		Ims96cLXkvKOx0GD(lvzrYTpcBaK,ERbOfw2FjKUAZGo)
	elif cwnGP8Qo6h==jwzOabysh0Z(u"ࠩ࠹ࠫྴ"):
		import CCKRSEkHBw,tqHErj9p1I
		if T5Teu1pJhvEmgkcn7OoA==BWfpRku7SsM6cbE0eG(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬྵ"): tqHErj9p1I.iRaHzNpJhSx6ZnCfrvD7j93lks(IOHSz7YPF9WusGgUt1Dq(u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫྶ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬྷ"),hDjf1Ubgq629nXlOvcFLH4Jw=Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠸࠰࠱࠲ᕡ"))
		elif T5Teu1pJhvEmgkcn7OoA==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡄࡆࡎࡈࡘࡊ࠭ྸ"): lAF3aONH7GKop5kw9bPd1sC(qhWpTazQ9ws,lvzrYTpcBaK)
		ka7jz96YCdTBnQOLVPuJG3285MHf = CCKRSEkHBw.Wwod49PBvQO(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,kkJoBAxwN3VrDH,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
		if T5Teu1pJhvEmgkcn7OoA==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩྐྵ"): xxpJdCwRN6SrscbOmga7h5UlHBiW()
	elif IFYonX8LZUfz3VJyuQlxgE==aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࠹ࠪྺ"):
		import PG9FRcxAEz
		PG9FRcxAEz.FBeYAuIGlPr08Rxsgcd7ijJ32K(sH6BOz5wKRFcEg(u"ࠩࡢࡅࡑࡒࠧྻ"))
		Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	elif IFYonX8LZUfz3VJyuQlxgE==SE97R3Dpj6dPLweVKU(u"ࠪ࠼ࠬྼ"): FoiwfTEhGD8ulS25HeUvnI.executebuiltin(jwzOabysh0Z(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ྽")+Xkp839QMmYzrsoWTyca+aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡅ࡭ࡰࡦࡨࡁࠬ྾")+str(GLrDUZJWtdSzaoeQNfw)+gDETKVh8mZe09Nd(u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭྿"))
	elif IFYonX8LZUfz3VJyuQlxgE==IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠺ࠩ࿀"):
		Ims96cLXkvKOx0GD(ndkUxG9LtewJ)
	elif IFYonX8LZUfz3VJyuQlxgE==TzIj50KpohEOHx6CbZWqB(u"ࠨ࠳࠳ࠫ࿁"):
		import PG9FRcxAEz
		PG9FRcxAEz.FBeYAuIGlPr08Rxsgcd7ijJ32K(aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡢࡋࡔࡕࡇࡍࡇࠪ࿂"))
		Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	elif IFYonX8LZUfz3VJyuQlxgE==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࠵࠹࠭࿃"): Ims96cLXkvKOx0GD(ndkUxG9LtewJ,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࡣ࡙ࡋࡍࡑࠩ࿄"))
	elif IFYonX8LZUfz3VJyuQlxgE==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠷࠵ࠨ࿅"): Ims96cLXkvKOx0GD(ndkUxG9LtewJ,sH6BOz5wKRFcEg(u"࠭ࡍࡆࡐࡘࡣࡆ࡙ࡃࡆࡐࡇࡉࡉࡥࡔࡆࡏࡓ࿆ࠫ"))
	elif IFYonX8LZUfz3VJyuQlxgE==aYH620Dh48GEsTFfOBSQ7r(u"ࠧ࠲࠸ࠪ࿇"): Ims96cLXkvKOx0GD(ndkUxG9LtewJ,YQNd4wejLSAVJ6T(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ࿈"))
	elif IFYonX8LZUfz3VJyuQlxgE==SE97R3Dpj6dPLweVKU(u"ࠩ࠴࠻ࠬ࿉"): Ims96cLXkvKOx0GD(ndkUxG9LtewJ,qqw1upCsKM(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤ࡚ࡅࡎࡒࠪ࿊"))
	elif IFYonX8LZUfz3VJyuQlxgE==RDwahqjPfbdyEiTtnLQu(u"ࠫ࠶࠾ࠧ࿋"):
		qlu4QIrH7GwzJ5LTn8jKA = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩ࿌"))
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ࿍"),TzIj50KpohEOHx6CbZWqB(u"ࠧ࠮ࠩ࿎")+qlu4QIrH7GwzJ5LTn8jKA)
	if IFYonX8LZUfz3VJyuQlxgE in [gDETKVh8mZe09Nd(u"ࠨ࠻ࠪ࿏"),qqw1upCsKM(u"ࠩ࠴࠸ࠬ࿐"),sH6BOz5wKRFcEg(u"ࠪ࠵࠺࠭࿑"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫ࠶࠼ࠧ࿒"),BWfpRku7SsM6cbE0eG(u"ࠬ࠷࠷ࠨ࿓")]: xxpJdCwRN6SrscbOmga7h5UlHBiW(ndkUxG9LtewJ)
	return
def wwxESsWhkyfG9PLr6gqiKapUudb0B(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA,c4yVMkzYb0):
	if GsowyWv4QneEtJ: FFKCPmhnBy3EfGqO0eNo5V9cR4dp8()
	if IFYonX8LZUfz3VJyuQlxgE: du4vrTO0AtShVl(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA)
	U5JhK4daVybAziFn8Qsrfum(kkJoBAxwN3VrDH)
	bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs = ndkUxG9LtewJ,lvzrYTpcBaK,lvzrYTpcBaK
	vvFwjLN0bgtkWzuAn2 = m7mdZMySHFgANK2tOxrV(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,c4yVMkzYb0,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs)
	oEl4uLWVdyhcOvIGtBzQ30x,VCYw96jJq4Gk,OhD2fSz5YEWLgAv8qM,kS9s3KBpxE548V2,UU8715SsCl,XtlhpEmrFy40uMS,YHakRg6Flvr4toSVswx3ubhTyPei,ggbIlnr0tyfBACsaO3hERKVe7 = vvFwjLN0bgtkWzuAn2
	if oEl4uLWVdyhcOvIGtBzQ30x: return
	if VCYw96jJq4Gk==BWfpRku7SsM6cbE0eG(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭࿔"): hO36FxWalTjkvQ9IzPH7bo(UTCXGnK7Fs4Y5pNkt2ARDWuw)
	AA6xmFYBTg2kfJ0Q9t5PNrWs(EJgYdjbIiWe1apkQlZcR42(u"ࠧࡴࡶࡤࡶࡹ࠭࿕"))
	if fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ࿖")) not in [qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡄ࡙࡙ࡕࠧ࿗"),jwzOabysh0Z(u"ࠪࡗ࡙ࡕࡐࠨ࿘"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ࿙")]:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ࿚"),IO7k2hZXSz(u"࠭ࡁࡖࡖࡒࠫ࿛"))
	if not fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(TzIj50KpohEOHx6CbZWqB(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧ࿜")): fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(hPFcB6Uxmabj59Iq(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ࿝"),Q1siCkTZyw.DNS_SERVERS[BewrUo9ANCa17G43Sn0LH5xh])
	ka7jz96YCdTBnQOLVPuJG3285MHf = Wwod49PBvQO(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
	if gDETKVh8mZe09Nd(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ࿞") in TqNvzBxf1KpPDg3SRA4yj2mwcVF: n0I1sFqQjXcKMkl3fDWg = ndkUxG9LtewJ
	if ScEpZwINx93VJ5aWfb4==SE97R3Dpj6dPLweVKU(u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿟"):
		if kS9s3KBpxE548V2!=SIkwCEdJHTD9v1(u"ࠫ࠳࠴ࠧ࿠") and UU8715SsCl: ngmFwvKdSq4lNZoITsyJ3PGE2X6u()
		if ZWaC4pLbOV1QEMrof08eu>-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			ddLzN85nOy = [BewrUo9ANCa17G43Sn0LH5xh,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲࠷ᕣ"),bGzRdmOErkIylxALniq6(u"࠳࠺ᕤ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠴࠽ᕥ"),qqw1upCsKM(u"࠲࠷ᕢ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠹࠴ᕨ"),jwzOabysh0Z(u"࠹࠵ᕦ"),qeG16a4pbSHziNVQ2uFXrs(u"࠺࠹ᕧ"),YQNd4wejLSAVJ6T(u"࠱࠲࠲ᕩ")]
			if (JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,sH6BOz5wKRFcEg(u"ࠬ࡯࡮ࡵࠩ࿡"),jwzOabysh0Z(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ࿢"),EJgYdjbIiWe1apkQlZcR42(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ࿣")) or kkJoBAxwN3VrDH not in ddLzN85nOy) and not Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc:
				from E2mWUgOe8f import zyV0KWNRrFosC1bx7IXewiOYc
				Q9hWn4j3BDLApkvU50P,V3JeOCaoXifQdFPkcq6pmR = QLDTHI1XbtJ9qPBad2rG5zYxOmEf(zyV0KWNRrFosC1bx7IXewiOYc)
				oEl4uLWVdyhcOvIGtBzQ30x = rfyFvhxA94H(OhD2fSz5YEWLgAv8qM,Q9hWn4j3BDLApkvU50P,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs)
				if Q9hWn4j3BDLApkvU50P and XtlhpEmrFy40uMS:
					if V3JeOCaoXifQdFPkcq6pmR: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ࿤")+YHakRg6Flvr4toSVswx3ubhTyPei+oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡢࠫ࿥")+ggbIlnr0tyfBACsaO3hERKVe7,OhD2fSz5YEWLgAv8qM,Q9hWn4j3BDLApkvU50P,NjPWfJS7CUoTsz4lKk0hg)
					else: aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ࿦")+YHakRg6Flvr4toSVswx3ubhTyPei+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡤ࠭࿧")+ggbIlnr0tyfBACsaO3hERKVe7,OhD2fSz5YEWLgAv8qM)
			else:
				RPtvgsXL0EzbhIr.addDirectoryItem(ZWaC4pLbOV1QEMrof08eu,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ࿨")+Xkp839QMmYzrsoWTyca+RDwahqjPfbdyEiTtnLQu(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭࿩"),qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ListItem(YQNd4wejLSAVJ6T(u"ࠧๅัํ็๋ࠥิไๆฬࠤ๊์ࠠอ้สึ่࠭࿪")))
				RPtvgsXL0EzbhIr.addDirectoryItem(ZWaC4pLbOV1QEMrof08eu,SE97R3Dpj6dPLweVKU(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ࿫")+Xkp839QMmYzrsoWTyca+hPFcB6Uxmabj59Iq(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ࿬"),qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ListItem(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪวๆะอࠡๆอๆึษࠠศๆอๅฬ฻๊ๅࠩ࿭")))
			RPtvgsXL0EzbhIr.endOfDirectory(ZWaC4pLbOV1QEMrof08eu,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs)
	return
def hO36FxWalTjkvQ9IzPH7bo(UJOif1LqoE5kaMmh72wxs0IDg):
	if sH6BOz5wKRFcEg(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭࿮") in str(Q1siCkTZyw.SEND_THESE_EVENTS): return
	VJ9Uml8uhXc6pRa3wvD51rBngx = lvzrYTpcBaK if UJOif1LqoE5kaMmh72wxs0IDg else ndkUxG9LtewJ
	if not VJ9Uml8uhXc6pRa3wvD51rBngx:
		Jdgjmf9WVCk = dh4Y5pvylFJEmH3LzgKBRNTac2(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭࿯")))
		Jdgjmf9WVCk = BewrUo9ANCa17G43Sn0LH5xh if not Jdgjmf9WVCk else int(Jdgjmf9WVCk)
		if not Jdgjmf9WVCk or not BewrUo9ANCa17G43Sn0LH5xh<=JVAlZw9Nsnj-Jdgjmf9WVCk<=UJOif1LqoE5kaMmh72wxs0IDg: VJ9Uml8uhXc6pRa3wvD51rBngx = ndkUxG9LtewJ
	if not VJ9Uml8uhXc6pRa3wvD51rBngx:
		VV3FkwuyRBrqhNg085f6bALe = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(SE97R3Dpj6dPLweVKU(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ࿰"))
		if VV3FkwuyRBrqhNg085f6bALe in [sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭࿱"),EJgYdjbIiWe1apkQlZcR42(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧ࿲")]: VJ9Uml8uhXc6pRa3wvD51rBngx = ndkUxG9LtewJ
	if not VJ9Uml8uhXc6pRa3wvD51rBngx:
		WuoFa2wsEpAeRr1lkGTyx = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(hPFcB6Uxmabj59Iq(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ࿳"))
		lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(qD1l8d3bQVN2uanhBLpyWTtcx)
		RsuIPESNQw1Md = cc5Z1RvyW0JlMqzxKuA2BV9(qD1l8d3bQVN2uanhBLpyWTtcx,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮ࡠ࡫ࡧࠤࡀ࠭࿴"))
		RsuIPESNQw1Md = RsuIPESNQw1Md[fvYGxnZNUiyP4HJkMIoS25(u"࠱ᕪ")][fvYGxnZNUiyP4HJkMIoS25(u"࠱ᕪ")]
		lxGwZhDLdoySA1avUN5.close()
		oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠷ᕫ")*WuoFa2wsEpAeRr1lkGTyx.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
		oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(aYH620Dh48GEsTFfOBSQ7r(u"࠴࠸ᕬ")*oo68qhpVEJgC7R.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
		oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(Js61GTdX5wzMurUqi7Z(u"࠵࠾ᕭ")*oo68qhpVEJgC7R.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
		oo68qhpVEJgC7R = str(int(oo68qhpVEJgC7R[oVwa0kcqxj1e7mLplAfZdGT(u"࠹ᕯ"):IO7k2hZXSz(u"࠱࠳ᕰ")],XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠲࠸ᕱ")))[:Js61GTdX5wzMurUqi7Z(u"࠾ᕮ")]
		if oo68qhpVEJgC7R!=RsuIPESNQw1Md: VJ9Uml8uhXc6pRa3wvD51rBngx = ndkUxG9LtewJ
	if VJ9Uml8uhXc6pRa3wvD51rBngx: fn3GEANaheOuW0IQ56(lvzrYTpcBaK)
	return
def DDuLcAv3Xl1b54tHBs(ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,showDialogs):
	oT2iHwjfBx0FPX5ZCph9aWs38 = zVbp6yjdF3qKkTvhDsJX9fgMceCuxt.split(hPFcB6Uxmabj59Iq(u"ࠫ࠲࠭࿵"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh] if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬ࠳ࠧ࿶") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt else zVbp6yjdF3qKkTvhDsJX9fgMceCuxt
	if not showDialogs or zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in tX4b7VxPQv5hyf18iwlBGWNOrIU: return lvzrYTpcBaK
	MioQH67u51k = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ࿷"))
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(IO7k2hZXSz(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ࿸"),sCHVtMAvqirbQ4BUK3cgWo)
	vHr4dOtX2UuJh8Tx = ltE6Cgu1AyjR8Dde in [TzIj50KpohEOHx6CbZWqB(u"࠼ᕵ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠴࠵࠵࠶࠱ᕳ"),jwzOabysh0Z(u"࠳࠴࠴࠵࠸ᕲ"),YQNd4wejLSAVJ6T(u"࠵࠵࠶࠵࠵ᕴ")]
	if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡁࡸࡷࡪࡸ࠽ࠨ࿹") in j7CADXI1yWt90Gc52HrsUhKeN: j7CADXI1yWt90Gc52HrsUhKeN = j7CADXI1yWt90Gc52HrsUhKeN.split(qqw1upCsKM(u"ࠩࡂࡹࡸ࡫ࡲ࠾ࠩ࿺"),fvYGxnZNUiyP4HJkMIoS25(u"࠷ᕶ"))[TzIj50KpohEOHx6CbZWqB(u"࠰ᕷ")]+gDETKVh8mZe09Nd(u"ࠪ࠭ࠬ࿻")
	IUzwGH36xdg5 = j7CADXI1yWt90Gc52HrsUhKeN.lower()
	ELGqSTC1DJRuF6gjdZB = ltE6Cgu1AyjR8Dde in [BewrUo9ANCa17G43Sn0LH5xh,TzIj50KpohEOHx6CbZWqB(u"࠴࠴࠹ᕺ"),IO7k2hZXSz(u"࠲࠲࠳࠺࠶ᕸ"),gDETKVh8mZe09Nd(u"࠳࠴࠵ᕹ")]
	aOIXY9LEGnbmtpkz = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ࿼") in IUzwGH36xdg5
	XjFnlJ05Y7o = aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ࿽") in IUzwGH36xdg5
	ttvkVGSRjubMyNHinmApxgCc = IO7k2hZXSz(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭࿾") in IUzwGH36xdg5
	y6imocsTWK3BaA2Hf7Vw5 = SE97R3Dpj6dPLweVKU(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ࿿") in IUzwGH36xdg5
	ff4XDA7shar6lkG = aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡳࡩࡴࡵ࡬ࡲ࡬ࠦࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠣࡧ࡭࡫ࡣ࡬ࠩက") in IUzwGH36xdg5
	LQxnVhmCywp8AjNiql = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡹࡰࡷࡵࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥࡪࡥࡷ࡫ࡦࡩࡸ࠭ခ") in IUzwGH36xdg5
	tvXK2luiTNQ7dayCDZ5 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨဂ"))
	uujXZpi9nHULqr175C = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧဃ"))
	zv8aF3GpEd0JU4O9B = gDETKVh8mZe09Nd(u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧင")
	GPgK4inID7qV = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡅࡳࡴࡲࡶࠥ࠭စ")+str(ltE6Cgu1AyjR8Dde)+qeG16a4pbSHziNVQ2uFXrs(u"ࠧ࠻ࠢࠪဆ")+j7CADXI1yWt90Gc52HrsUhKeN
	GPgK4inID7qV = mSeoVfgRpNF9PKrJ(GPgK4inID7qV)
	if any([ELGqSTC1DJRuF6gjdZB,aOIXY9LEGnbmtpkz,XjFnlJ05Y7o,ttvkVGSRjubMyNHinmApxgCc,y6imocsTWK3BaA2Hf7Vw5,ff4XDA7shar6lkG,LQxnVhmCywp8AjNiql]): zv8aF3GpEd0JU4O9B += t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨဇ")
	if vHr4dOtX2UuJh8Tx: zv8aF3GpEd0JU4O9B += BWfpRku7SsM6cbE0eG(u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩဈ")
	GPgK4inID7qV = slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+GPgK4inID7qV+B8alA5nvIhTxQ
	if tvXK2luiTNQ7dayCDZ5==qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡅࡘࡑࠧဉ") or uujXZpi9nHULqr175C==GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡆ࡙ࡋࠨည"):
		zv8aF3GpEd0JU4O9B += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+RDwahqjPfbdyEiTtnLQu(u"ࠬํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦࠧࠧဋ")+B8alA5nvIhTxQ
	rm0eA8hx6v35NDzLwG1HcFtpCMdTiR = lvzrYTpcBaK
	if tvXK2luiTNQ7dayCDZ5==jwzOabysh0Z(u"࠭ࡁࡔࡍࠪဌ") or uujXZpi9nHULqr175C==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡂࡕࡎࠫဍ"):
		WQOh7NoUEJuHgGK0pzTrktyeLjxMB = bP5mf0Mo2nz(SE97R3Dpj6dPLweVKU(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨဎ"),qqw1upCsKM(u"ࠩัีําࠧဏ"),YQNd4wejLSAVJ6T(u"ࠪษึูวๅࠢ็่๊ฮัๆฮࠪတ"),BWfpRku7SsM6cbE0eG(u"ࠫฯ฻ไ๋ฯࠣห้๋ิไๆฬࠫထ"),oT2iHwjfBx0FPX5ZCph9aWs38+OUmtsIB1zyF+g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38),zv8aF3GpEd0JU4O9B+slFfrUIWCowaBA7tce3iZbj8xn+GPgK4inID7qV)
		if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			from i5kNU6T7vE import QiGkIR6Eys
			QiGkIR6Eys()
		elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==rgpY5VUqKbeFOCD9Nki2SmGvxEja: rm0eA8hx6v35NDzLwG1HcFtpCMdTiR = ndkUxG9LtewJ
	else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,oT2iHwjfBx0FPX5ZCph9aWs38+OUmtsIB1zyF+g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38),zv8aF3GpEd0JU4O9B,GPgK4inID7qV)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Js61GTdX5wzMurUqi7Z(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ဒ"),MioQH67u51k)
	return rm0eA8hx6v35NDzLwG1HcFtpCMdTiR
def ltKCxe0hWVn5jQ(GQe4hdxsaELBtwN1vWMCPqSYD=lvzrYTpcBaK,qM0To6HhF8ZpLx9mJEO=[]):
	O5TaPIBpwZ = [nbfoUAIGjyD2PQcSJO,u3yGxS2mRw1fW54N7DchIvEoaq]+qM0To6HhF8ZpLx9mJEO
	for PaIF3ENgrM61XfTBD7xy8JjC in YYEXZsUWhf52vz7HLxc0qGJ.listdir(XX4rMRSnQdbZ1NJiKu8pOfvDla):
		if GQe4hdxsaELBtwN1vWMCPqSYD and (PaIF3ENgrM61XfTBD7xy8JjC.startswith(BWfpRku7SsM6cbE0eG(u"࠭ࡩࡱࡶࡹࠫဓ")) or PaIF3ENgrM61XfTBD7xy8JjC.startswith(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ࡮࠵ࡸࠫန"))): continue
		if PaIF3ENgrM61XfTBD7xy8JjC.startswith(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡨ࡬ࡰࡪࡥࠧပ")): continue
		zdY4mqiILFl9CGjnX = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,PaIF3ENgrM61XfTBD7xy8JjC)
		if zdY4mqiILFl9CGjnX in O5TaPIBpwZ: continue
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(zdY4mqiILFl9CGjnX)
		except: pass
	if rNq1RX4ZwSpgcM35tPG60Hl8bFdhk not in O5TaPIBpwZ: W0BFzMOVpdNxnmer5aZfs(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,ndkUxG9LtewJ,lvzrYTpcBaK)
	hDjf1Ubgq629nXlOvcFLH4Jw.sleep(aenpKvQCGVzhLXEdWiDIZ(u"࠵ᕻ"))
	return
def xxcby9ZSlrPUzmQ4ADH6jL1Iv8(ROjGrfYUugFieHspvEBJaNS4,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij=ndkUxG9LtewJ,iY3xS59ZAVkjhsIum1=ndkUxG9LtewJ):
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2+BWfpRku7SsM6cbE0eG(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩဖ")+ROjGrfYUugFieHspvEBJaNS4
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij,iY3xS59ZAVkjhsIum1)
	if ZvWwXBJxzk3Qi9uAHKTD8hY2 in mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded = lvzrYTpcBaK
	if not mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		xxpJdCwRN6SrscbOmga7h5UlHBiW()
	return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
def BBr3o1nTdOuCj9Hc4pvEDYKWGm6VNa(ZvWwXBJxzk3Qi9uAHKTD8hY2):
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡋࡊ࡚ࠧဗ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬဘ"),ndkUxG9LtewJ,lvzrYTpcBaK)
	K8zvPxky0WwECDJNhXS = []
	if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
		LLtShb48gvCwJZI1xByez0YcDV = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨမ"),cIy4z8xCUt7j5MhPZO)
		if LLtShb48gvCwJZI1xByez0YcDV: cIy4z8xCUt7j5MhPZO = slFfrUIWCowaBA7tce3iZbj8xn.join(LLtShb48gvCwJZI1xByez0YcDV)
		qP6NKJiZ8e1wfSzC = cIy4z8xCUt7j5MhPZO.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).strip(slFfrUIWCowaBA7tce3iZbj8xn).split(slFfrUIWCowaBA7tce3iZbj8xn)
		K8zvPxky0WwECDJNhXS = []
		for ROjGrfYUugFieHspvEBJaNS4 in qP6NKJiZ8e1wfSzC:
			if ROjGrfYUugFieHspvEBJaNS4.count(fvYGxnZNUiyP4HJkMIoS25(u"࠭࠮ࠨယ"))==vUnJhT2NO8yirHcAmg: K8zvPxky0WwECDJNhXS.append(ROjGrfYUugFieHspvEBJaNS4)
	return K8zvPxky0WwECDJNhXS
def UBWIYiHgE0Rsyt8bVOnAqkoT(*aargs):
	L6vro1bZVWzg9Y = sH6BOz5wKRFcEg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨရ")
	omenQasGg2FKNV = IOHSz7YPF9WusGgUt1Dq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬလ")
	xHuz9bPV7m = BBr3o1nTdOuCj9Hc4pvEDYKWGm6VNa(omenQasGg2FKNV)
	K8zvPxky0WwECDJNhXS = BBr3o1nTdOuCj9Hc4pvEDYKWGm6VNa(L6vro1bZVWzg9Y)
	kkRZ8nuQrLzlBSV5Xwb = xHuz9bPV7m+K8zvPxky0WwECDJNhXS
	SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡳࡶࡴࡾࡩࡦࡵࠣࡰ࡮ࡹࡴࠡࠢࠣ࠵ࡸࡺࠫ࠳ࡰࡧ࠾ࠥࡡࠠࠨဝ")+str(len(xHuz9bPV7m))+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࠯ࠬသ")+str(len(K8zvPxky0WwECDJNhXS))+sH6BOz5wKRFcEg(u"ࠫࠥࡣࠧဟ"))
	ROjGrfYUugFieHspvEBJaNS4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(qqw1upCsKM(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬဠ"))
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = Rxc41oNqDF()
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭အ"),sCHVtMAvqirbQ4BUK3cgWo)
	if ROjGrfYUugFieHspvEBJaNS4 or kkRZ8nuQrLzlBSV5Xwb:
		W0wg5RhFv2j8fr1B,YNRdyxs6T5EKlf8 = BewrUo9ANCa17G43Sn0LH5xh,bGzRdmOErkIylxALniq6(u"࠶࠶ᕼ")
		VGCuRI9v7Aapn1ceiwsKf43 = len(kkRZ8nuQrLzlBSV5Xwb)
		JlLb9Fz1kK3mOiTCQgGqW = YNRdyxs6T5EKlf8
		if VGCuRI9v7Aapn1ceiwsKf43>JlLb9Fz1kK3mOiTCQgGqW: HqpTsYiJBw = JlLb9Fz1kK3mOiTCQgGqW
		else: HqpTsYiJBw = VGCuRI9v7Aapn1ceiwsKf43
		OitvpqH9rxwGRUBnm = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(kkRZ8nuQrLzlBSV5Xwb,HqpTsYiJBw)
		if ROjGrfYUugFieHspvEBJaNS4: OitvpqH9rxwGRUBnm = [ROjGrfYUugFieHspvEBJaNS4]+OitvpqH9rxwGRUBnm
		DDPyVhzCw4kREsXg98 = kGX9IF07jirosWYaf3c(lvzrYTpcBaK,lvzrYTpcBaK)
		ofLNbsZxdtEvC0gRM2r9khzTeV = hDjf1Ubgq629nXlOvcFLH4Jw.time()
		while hDjf1Ubgq629nXlOvcFLH4Jw.time()-ofLNbsZxdtEvC0gRM2r9khzTeV<=YNRdyxs6T5EKlf8 and not DDPyVhzCw4kREsXg98.finishedLIST:
			if W0wg5RhFv2j8fr1B<HqpTsYiJBw:
				ROjGrfYUugFieHspvEBJaNS4 = OitvpqH9rxwGRUBnm[W0wg5RhFv2j8fr1B]
				DDPyVhzCw4kREsXg98.pQfd3FT4Jz7G(W0wg5RhFv2j8fr1B,xxcby9ZSlrPUzmQ4ADH6jL1Iv8,ROjGrfYUugFieHspvEBJaNS4,*aargs)
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠶࠮࠸࠷ᕽ"))
			W0wg5RhFv2j8fr1B += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩဢ")+ROjGrfYUugFieHspvEBJaNS4+bGzRdmOErkIylxALniq6(u"ࠨࠢࡠࠫဣ"))
		finishedLIST = DDPyVhzCw4kREsXg98.finishedLIST
		if finishedLIST:
			resultsDICT = DDPyVhzCw4kREsXg98.resultsDICT
			RPN0fBH8CJoq3A2skOjwtg7WQVv = finishedLIST[BewrUo9ANCa17G43Sn0LH5xh]
			mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = resultsDICT[RPN0fBH8CJoq3A2skOjwtg7WQVv]
			ROjGrfYUugFieHspvEBJaNS4 = OitvpqH9rxwGRUBnm[int(RPN0fBH8CJoq3A2skOjwtg7WQVv)]
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(YQNd4wejLSAVJ6T(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩဤ"),ROjGrfYUugFieHspvEBJaNS4)
			if RPN0fBH8CJoq3A2skOjwtg7WQVv!=BewrUo9ANCa17G43Sn0LH5xh: SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭ဥ")+ROjGrfYUugFieHspvEBJaNS4+qeG16a4pbSHziNVQ2uFXrs(u"ࠫࠥࡣࠧဦ"))
			else: SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+TzIj50KpohEOHx6CbZWqB(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧဧ")+ROjGrfYUugFieHspvEBJaNS4+qeG16a4pbSHziNVQ2uFXrs(u"࠭ࠠ࡞ࠩဨ"))
	return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
def xhZzF68kis0YbMq(Y6VjgSTnFPIz14JKwtC,wxcCDGXEkniWdJA,eecQ6RgGxk5o1Zw=ndkUxG9LtewJ):
	iFno95x7tC = Y6VjgSTnFPIz14JKwtC.create_connection
	def XhmJzxpecG7Cf93UKQHk(wGl8yMTZfaAmcXUb69W4BSPxKv3,*aargs,**kkwargs):
		afQqnTxbUcPNXgrJlW4LsY,YYlzJnQkmVFXyK0CxGpIPeEchMZ8 = wGl8yMTZfaAmcXUb69W4BSPxKv3
		ip = I0DJU1BnhLfH4QP5cb(afQqnTxbUcPNXgrJlW4LsY,wxcCDGXEkniWdJA)
		if ip: afQqnTxbUcPNXgrJlW4LsY = ip[BewrUo9ANCa17G43Sn0LH5xh]
		elif eecQ6RgGxk5o1Zw:
			if wxcCDGXEkniWdJA in Q1siCkTZyw.DNS_SERVERS: Q1siCkTZyw.DNS_SERVERS.remove(wxcCDGXEkniWdJA)
			if Q1siCkTZyw.DNS_SERVERS:
				a2aEpfLSYMRtyXhAkCvq8nTV = Q1siCkTZyw.DNS_SERVERS[BewrUo9ANCa17G43Sn0LH5xh]
				ip = I0DJU1BnhLfH4QP5cb(afQqnTxbUcPNXgrJlW4LsY,a2aEpfLSYMRtyXhAkCvq8nTV)
				if ip: afQqnTxbUcPNXgrJlW4LsY = ip[BewrUo9ANCa17G43Sn0LH5xh]
		if ip: Q1siCkTZyw.dns_succeeded_urls.append(afQqnTxbUcPNXgrJlW4LsY)
		wGl8yMTZfaAmcXUb69W4BSPxKv3 = (afQqnTxbUcPNXgrJlW4LsY,YYlzJnQkmVFXyK0CxGpIPeEchMZ8)
		return iFno95x7tC(wGl8yMTZfaAmcXUb69W4BSPxKv3,*aargs,**kkwargs)
	Y6VjgSTnFPIz14JKwtC.create_connection = XhmJzxpecG7Cf93UKQHk
	return iFno95x7tC
def p4Y5E1hkxglyFuAdQi(ZvWwXBJxzk3Qi9uAHKTD8hY2):
	z2cUPXqDRA3YkxOH04lvrp8W,igUWtNqEny9Z1AQTejhYJ = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠰ࠩဩ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja],oVwa0kcqxj1e7mLplAfZdGT(u"࠸࠱ᕾ")
	if aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࠼ࠪဪ") in z2cUPXqDRA3YkxOH04lvrp8W: z2cUPXqDRA3YkxOH04lvrp8W,igUWtNqEny9Z1AQTejhYJ = z2cUPXqDRA3YkxOH04lvrp8W.split(SE97R3Dpj6dPLweVKU(u"ࠩ࠽ࠫါ"))
	KKgrbxZkRdE3 = GVurlv8HeoXEzPRiQB7Ty(u"ࠪ࠳ࠬာ")+oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࠴࠭ိ").join(ZvWwXBJxzk3Qi9uAHKTD8hY2.split(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࠵ࠧီ"))[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠴ᕿ"):])
	n1WYDtVC8dRHbXJkMa = fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡇࡆࡖࠣࠫု")+KKgrbxZkRdE3+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧူ")
	n1WYDtVC8dRHbXJkMa += Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡊࡲࡷࡹࡀࠠࠨေ")+z2cUPXqDRA3YkxOH04lvrp8W+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࡟ࡶࡡࡴࠧဲ")
	n1WYDtVC8dRHbXJkMa += t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡠࡷࡢ࡮ࠨဳ")
	from socket import socket as j1W9U4Ekxs0cYo7Aw2fzdyVgnb6,AF_INET as BfexTtRADqZL8iFSwVoYN2yHaMvOn,SOCK_STREAM as MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye
	try:
		yvmksHVgL5Uun3j0a2SerYcRlpFw = j1W9U4Ekxs0cYo7Aw2fzdyVgnb6(BfexTtRADqZL8iFSwVoYN2yHaMvOn,MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye)
		yvmksHVgL5Uun3j0a2SerYcRlpFw.connect((z2cUPXqDRA3YkxOH04lvrp8W,igUWtNqEny9Z1AQTejhYJ))
		yvmksHVgL5Uun3j0a2SerYcRlpFw.send(n1WYDtVC8dRHbXJkMa.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
		AyEMQSfYspBkNzm9 = yvmksHVgL5Uun3j0a2SerYcRlpFw.recv(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠷࠴࠾࠼ᖁ")*Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠳࠳࠶࠹ᖀ"))
		cIy4z8xCUt7j5MhPZO = repr(AyEMQSfYspBkNzm9)
	except: cIy4z8xCUt7j5MhPZO = sCHVtMAvqirbQ4BUK3cgWo
	return cIy4z8xCUt7j5MhPZO
def GABnmSFOwtsu37(yWUkt8lwbPq3QcrBZKmedxN6,ScEpZwINx93VJ5aWfb4):
	if aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࠳࠭ဴ") not in yWUkt8lwbPq3QcrBZKmedxN6: return yWUkt8lwbPq3QcrBZKmedxN6
	yWUkt8lwbPq3QcrBZKmedxN6 = yWUkt8lwbPq3QcrBZKmedxN6+bGzRdmOErkIylxALniq6(u"ࠬ࠵ࠧဵ")
	pNP4syKOran,F72hdE9LTOYNKaPk3Xe4qRInjV = yWUkt8lwbPq3QcrBZKmedxN6.split(qeG16a4pbSHziNVQ2uFXrs(u"࠭࠮ࠨံ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠵ᖂ"))
	fTBwGciXuDgmKz,vC4YjfaHmKE3r = F72hdE9LTOYNKaPk3Xe4qRInjV.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧ࠰့ࠩ"),Js61GTdX5wzMurUqi7Z(u"࠶ᖃ"))
	ha6z5Ufv0kdDwqPo = pNP4syKOran+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ࠰ࠪး")+fTBwGciXuDgmKz
	if ScEpZwINx93VJ5aWfb4 in [SIkwCEdJHTD9v1(u"ࠩ࡫ࡳࡸࡺ္ࠧ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡲࡦࡳࡥࠨ်")] and Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫ࠴࠭ျ") in ha6z5Ufv0kdDwqPo: ha6z5Ufv0kdDwqPo = ha6z5Ufv0kdDwqPo.rsplit(IO7k2hZXSz(u"ࠬ࠵ࠧြ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠷ᖄ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	if ScEpZwINx93VJ5aWfb4==BWfpRku7SsM6cbE0eG(u"࠭࡮ࡢ࡯ࡨࠫွ") and SIkwCEdJHTD9v1(u"ࠧ࠯ࠩှ") in ha6z5Ufv0kdDwqPo:
		kJ2YEV9vlyI6Lwu5ZnszGX1bhTc = ha6z5Ufv0kdDwqPo.split(Js61GTdX5wzMurUqi7Z(u"ࠨ࠰ࠪဿ"))
		aaRe85jDnZKfx7E = len(kJ2YEV9vlyI6Lwu5ZnszGX1bhTc)
		if aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ၀") in ha6z5Ufv0kdDwqPo: kJ2YEV9vlyI6Lwu5ZnszGX1bhTc = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ၁")
		elif aaRe85jDnZKfx7E<=rgpY5VUqKbeFOCD9Nki2SmGvxEja: kJ2YEV9vlyI6Lwu5ZnszGX1bhTc = kJ2YEV9vlyI6Lwu5ZnszGX1bhTc[BewrUo9ANCa17G43Sn0LH5xh]
		elif aaRe85jDnZKfx7E>=vUnJhT2NO8yirHcAmg: kJ2YEV9vlyI6Lwu5ZnszGX1bhTc = kJ2YEV9vlyI6Lwu5ZnszGX1bhTc[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if len(kJ2YEV9vlyI6Lwu5ZnszGX1bhTc)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: ha6z5Ufv0kdDwqPo = kJ2YEV9vlyI6Lwu5ZnszGX1bhTc
	return ha6z5Ufv0kdDwqPo
def ZfInhvTe4NpKc6AJbUXyi9jFQ5zBGH(KK2irjmpgAsFyLvGCMSEkcXz):
	QWRioCzFv63 = repr(KK2irjmpgAsFyLvGCMSEkcXz.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠦࠬࠨ၂"),sCHVtMAvqirbQ4BUK3cgWo)
	return QWRioCzFv63
def fko6iadls820ZP9MNqX(k04wPI3jEGhAvCuBzbTSxdep8oWFRV):
	ieoupNBclFW6rYjkI1VsvOMK4G = sCHVtMAvqirbQ4BUK3cgWo
	if qdUK5ioJyrO1T: k04wPI3jEGhAvCuBzbTSxdep8oWFRV = k04wPI3jEGhAvCuBzbTSxdep8oWFRV.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	from unicodedata import decomposition as liLRuEyc2G9no
	for GJR0Z4T7QnhXKBPtf6Sm8so9Yi in k04wPI3jEGhAvCuBzbTSxdep8oWFRV:
		if   GJR0Z4T7QnhXKBPtf6Sm8so9Yi==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࡺ࠭ยࠨ၃"): rrRuZMmldOGwVHtpL1CoKYky0Ua = qqw1upCsKM(u"࠭࡜࡝ࡷ࠳࠺࠷࠸ࠧ၄")
		elif GJR0Z4T7QnhXKBPtf6Sm8so9Yi==gDETKVh8mZe09Nd(u"ࡵࠨลࠪ၅"): rrRuZMmldOGwVHtpL1CoKYky0Ua = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠴ࠩ၆")
		elif GJR0Z4T7QnhXKBPtf6Sm8so9Yi==sH6BOz5wKRFcEg(u"ࡷࠪศࠬ၇"): rrRuZMmldOGwVHtpL1CoKYky0Ua = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡠࡡࡻ࠰࠷࠴࠷ࠫ၈")
		elif GJR0Z4T7QnhXKBPtf6Sm8so9Yi==bGzRdmOErkIylxALniq6(u"ࡹࠬหࠧ၉"): rrRuZMmldOGwVHtpL1CoKYky0Ua = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠺࠭၊")
		elif GJR0Z4T7QnhXKBPtf6Sm8so9Yi==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࡻࠧวࠩ။"): rrRuZMmldOGwVHtpL1CoKYky0Ua = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠶ࠨ၌")
		else:
			pTQj2X8mYGb = liLRuEyc2G9no(GJR0Z4T7QnhXKBPtf6Sm8so9Yi)
			if AAh0X3OCacr4HpifRGLZKT in pTQj2X8mYGb: rrRuZMmldOGwVHtpL1CoKYky0Ua = qeG16a4pbSHziNVQ2uFXrs(u"ࠨ࡞࡟ࡹࠬ၍")+pTQj2X8mYGb.split(AAh0X3OCacr4HpifRGLZKT,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			else:
				rrRuZMmldOGwVHtpL1CoKYky0Ua = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࠳࠴࠵࠶ࠧ၎")+hex(ord(GJR0Z4T7QnhXKBPtf6Sm8so9Yi)).replace(Js61GTdX5wzMurUqi7Z(u"ࠪ࠴ࡽ࠭၏"),sCHVtMAvqirbQ4BUK3cgWo)
				rrRuZMmldOGwVHtpL1CoKYky0Ua = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡡࡢࡵࠨၐ")+rrRuZMmldOGwVHtpL1CoKYky0Ua[-kK7gj9HE462hADJbvr:]
		ieoupNBclFW6rYjkI1VsvOMK4G += rrRuZMmldOGwVHtpL1CoKYky0Ua
	ieoupNBclFW6rYjkI1VsvOMK4G = ieoupNBclFW6rYjkI1VsvOMK4G.replace(EJgYdjbIiWe1apkQlZcR42(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ၑ"),SIkwCEdJHTD9v1(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧၒ"))
	if qdUK5ioJyrO1T: ieoupNBclFW6rYjkI1VsvOMK4G = ieoupNBclFW6rYjkI1VsvOMK4G.decode(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨၓ")).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	else: ieoupNBclFW6rYjkI1VsvOMK4G = ieoupNBclFW6rYjkI1VsvOMK4G.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT).decode(bGzRdmOErkIylxALniq6(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩၔ"))
	return ieoupNBclFW6rYjkI1VsvOMK4G
def UyBdvjGrFxDWMpmLOXn(header=YQNd4wejLSAVJ6T(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩၕ"),FMZdXbKcEDgCzvuGUxorY93V=sCHVtMAvqirbQ4BUK3cgWo,yq8EvJ7tZnTdFoAuKf0NzkQ1I64gPR=lvzrYTpcBaK,source=sCHVtMAvqirbQ4BUK3cgWo):
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = HISfnDvUOcLzuA7m5VXk6egoq(header,FMZdXbKcEDgCzvuGUxorY93V,type=qqtbjl02E5pUOdQ1yMn8xABJsVG67w.INPUT_ALPHANUM)
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.strip(AAh0X3OCacr4HpifRGLZKT).replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	if not TqNvzBxf1KpPDg3SRA4yj2mwcVF and not yq8EvJ7tZnTdFoAuKf0NzkQ1I64gPR:
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠼ࠣࠤࠥࠨࠧၖ")+TqNvzBxf1KpPDg3SRA4yj2mwcVF+Js61GTdX5wzMurUqi7Z(u"ࠫࠧ࠭ၗ"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨၘ"))
		return sCHVtMAvqirbQ4BUK3cgWo
	if TqNvzBxf1KpPDg3SRA4yj2mwcVF not in [sCHVtMAvqirbQ4BUK3cgWo,AAh0X3OCacr4HpifRGLZKT]:
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.strip(AAh0X3OCacr4HpifRGLZKT)
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = fko6iadls820ZP9MNqX(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	if source!=phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨၙ") and NNwUI8zLc39CGi2Mle(RDwahqjPfbdyEiTtnLQu(u"ࠧࡌࡇ࡜ࡆࡔࡇࡒࡅࠩၚ"),sCHVtMAvqirbQ4BUK3cgWo,[TqNvzBxf1KpPDg3SRA4yj2mwcVF],lvzrYTpcBaK):
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫၛ")+TqNvzBxf1KpPDg3SRA4yj2mwcVF+TzIj50KpohEOHx6CbZWqB(u"ࠩࠥࠫၜ"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"ࠪห๋ะࠠไฬหฮ้ࠥไๆหࠣวํࠦัใ็่ࠣ์ูࠦๅษๅอࠥฮรโๆส้๊ࠥไไสสีࠥ็โุࠢ࠱࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์ึ้าࠦศศีอาิอๅ้ࠡๆิฬࠦใๅ็สฮࠬၝ"))
		return sCHVtMAvqirbQ4BUK3cgWo
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡣ࡯ࡰࡴࡽࡥࡥ࠼ࠣࠤࠥࠨࠧၞ")+TqNvzBxf1KpPDg3SRA4yj2mwcVF+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࠨࠧၟ"))
	return TqNvzBxf1KpPDg3SRA4yj2mwcVF
def KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,vrEJRkchKxtDNiqO1b79mL5eT,HSNYwERMjzyxmrPku={}):
	ZvWwXBJxzk3Qi9uAHKTD8hY2,LqKlMyf1snxkhROjEeDWtZS6J,HSrmwdqBFbvkVJ,WWQq0NRhgnCIzeT6AP3BUkvl = vrEJRkchKxtDNiqO1b79mL5eT,{},{},sCHVtMAvqirbQ4BUK3cgWo
	if fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡼࠨၠ") in vrEJRkchKxtDNiqO1b79mL5eT: ZvWwXBJxzk3Qi9uAHKTD8hY2,LqKlMyf1snxkhROjEeDWtZS6J = muXAzTa365Mjklef1ZP7JiWrIR(vrEJRkchKxtDNiqO1b79mL5eT,aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡽࠩၡ"))
	mVBPcXoNUypC4ungjxaOqKGJWLi1 = list(set(list(HSNYwERMjzyxmrPku.keys())+list(LqKlMyf1snxkhROjEeDWtZS6J.keys())))
	for XuhpgCFwT9RcZe8Yta5 in mVBPcXoNUypC4ungjxaOqKGJWLi1:
		if XuhpgCFwT9RcZe8Yta5 in list(LqKlMyf1snxkhROjEeDWtZS6J.keys()): HSrmwdqBFbvkVJ[XuhpgCFwT9RcZe8Yta5] = LqKlMyf1snxkhROjEeDWtZS6J[XuhpgCFwT9RcZe8Yta5]
		else: HSrmwdqBFbvkVJ[XuhpgCFwT9RcZe8Yta5] = HSNYwERMjzyxmrPku[XuhpgCFwT9RcZe8Yta5]
	if YQNd4wejLSAVJ6T(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬၢ") not in mVBPcXoNUypC4ungjxaOqKGJWLi1: HSrmwdqBFbvkVJ[BWfpRku7SsM6cbE0eG(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ၣ")] = OOsacGDt4owXd52q7gC8l()
	if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫၤ") not in mVBPcXoNUypC4ungjxaOqKGJWLi1: HSrmwdqBFbvkVJ[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬၥ")] = GABnmSFOwtsu37(ZvWwXBJxzk3Qi9uAHKTD8hY2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡻࡲ࡭ࠩၦ"))
	if fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨၧ") not in mVBPcXoNUypC4ungjxaOqKGJWLi1: HSrmwdqBFbvkVJ[IOHSz7YPF9WusGgUt1Dq(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩၨ")] = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡧࡱ࠰ࡦࡸ࠻ࡲ࠿࠳࠲࠾࠭ၩ")
	for XuhpgCFwT9RcZe8Yta5 in list(HSrmwdqBFbvkVJ.keys()): WWQq0NRhgnCIzeT6AP3BUkvl += GVurlv8HeoXEzPRiQB7Ty(u"ࠩࠩࠫၪ")+XuhpgCFwT9RcZe8Yta5+SE97R3Dpj6dPLweVKU(u"ࠪࡁࠬၫ")+HSrmwdqBFbvkVJ[XuhpgCFwT9RcZe8Yta5]
	if WWQq0NRhgnCIzeT6AP3BUkvl: WWQq0NRhgnCIzeT6AP3BUkvl = BWfpRku7SsM6cbE0eG(u"ࠫࢁ࠭ၬ")+WWQq0NRhgnCIzeT6AP3BUkvl[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(xCE0toTumIHWiLyMfF,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡍࡅࡕࠩၭ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,sCHVtMAvqirbQ4BUK3cgWo,HSrmwdqBFbvkVJ,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪၮ"),lvzrYTpcBaK,lvzrYTpcBaK)
	cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
	if jwzOabysh0Z(u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫၯ") not in cIy4z8xCUt7j5MhPZO: return [SIkwCEdJHTD9v1(u"ࠨ࠯࠴ࠫၰ")],[ZvWwXBJxzk3Qi9uAHKTD8hY2+WWQq0NRhgnCIzeT6AP3BUkvl]
	if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭ၱ") in cIy4z8xCUt7j5MhPZO: return [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࠱࠶࠭ၲ")],[ZvWwXBJxzk3Qi9uAHKTD8hY2+WWQq0NRhgnCIzeT6AP3BUkvl]
	if fvYGxnZNUiyP4HJkMIoS25(u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨၳ") in cIy4z8xCUt7j5MhPZO: return [gDETKVh8mZe09Nd(u"ࠬ࠳࠱ࠨၴ")],[ZvWwXBJxzk3Qi9uAHKTD8hY2+WWQq0NRhgnCIzeT6AP3BUkvl]
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,pYIcUDHni6BmxZAKyGrNWfFJsR4,yytqzpQMJwGekivobsmIl = [],[],[],[]
	CChmRfAOZ4eLtczYduF = fNntYJW45mEFSdRX8g.findall(jwzOabysh0Z(u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧၵ"),cIy4z8xCUt7j5MhPZO+slFfrUIWCowaBA7tce3iZbj8xn,fNntYJW45mEFSdRX8g.DOTALL)
	if not CChmRfAOZ4eLtczYduF: return [IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠮࠳ࠪၶ")],[ZvWwXBJxzk3Qi9uAHKTD8hY2+WWQq0NRhgnCIzeT6AP3BUkvl]
	for MCDsZVht3YjHOx,yWUkt8lwbPq3QcrBZKmedxN6 in CChmRfAOZ4eLtczYduF:
		zaIDkRr1UNp58WOBSZgtnXv,qlu4QIrH7GwzJ5LTn8jKA,XO7Zr2W6kwieA = {},-XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠱ᖅ"),-XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠱ᖅ")
		xkXveAgCLl = sCHVtMAvqirbQ4BUK3cgWo
		TUzIvZOQCcmg2ALqp = MCDsZVht3YjHOx.split(qqw1upCsKM(u"ࠨ࠮ࠪၷ"))
		for sNmyDVjHLfuhtoOdx0FZgWcYq9Al in TUzIvZOQCcmg2ALqp:
			if BWfpRku7SsM6cbE0eG(u"ࠩࡀࠫၸ") in sNmyDVjHLfuhtoOdx0FZgWcYq9Al:
				XuhpgCFwT9RcZe8Yta5,ueLNQY06r4zt3qk = sNmyDVjHLfuhtoOdx0FZgWcYq9Al.split(aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡁࠬၹ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠲ᖆ"))
				zaIDkRr1UNp58WOBSZgtnXv[XuhpgCFwT9RcZe8Yta5.lower()] = ueLNQY06r4zt3qk
		if IO7k2hZXSz(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨၺ") in MCDsZVht3YjHOx.lower():
			qlu4QIrH7GwzJ5LTn8jKA = int(zaIDkRr1UNp58WOBSZgtnXv[zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩၻ")])//aenpKvQCGVzhLXEdWiDIZ(u"࠳࠳࠶࠹ᖇ")
			xkXveAgCLl += str(qlu4QIrH7GwzJ5LTn8jKA)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ၼ")
		elif IO7k2hZXSz(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪၽ") in MCDsZVht3YjHOx.lower():
			qlu4QIrH7GwzJ5LTn8jKA = int(zaIDkRr1UNp58WOBSZgtnXv[Js61GTdX5wzMurUqi7Z(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫၾ")])//t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠴࠴࠷࠺ᖈ")
			xkXveAgCLl += str(qlu4QIrH7GwzJ5LTn8jKA)+Js61GTdX5wzMurUqi7Z(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩၿ")
		if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧႀ") in MCDsZVht3YjHOx.lower():
			XO7Zr2W6kwieA = int(zaIDkRr1UNp58WOBSZgtnXv[SE97R3Dpj6dPLweVKU(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨႁ")].split(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡾࠧႂ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
			xkXveAgCLl += str(XO7Zr2W6kwieA)+LvzD9S8RPyGeukZQqb2T0B
		xkXveAgCLl = xkXveAgCLl.strip(LvzD9S8RPyGeukZQqb2T0B)
		if not xkXveAgCLl: xkXveAgCLl = XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧႃ")
		if not yWUkt8lwbPq3QcrBZKmedxN6.startswith(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡩࡶࡷࡴࠬႄ")):
			if yWUkt8lwbPq3QcrBZKmedxN6.startswith(qeG16a4pbSHziNVQ2uFXrs(u"ࠨ࠱࠲ࠫႅ")): yWUkt8lwbPq3QcrBZKmedxN6 = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(RDwahqjPfbdyEiTtnLQu(u"ࠩ࠽ࠫႆ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]+YQNd4wejLSAVJ6T(u"ࠪ࠾ࠬႇ")+yWUkt8lwbPq3QcrBZKmedxN6
			elif yWUkt8lwbPq3QcrBZKmedxN6.startswith(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࠴࠭ႈ")): yWUkt8lwbPq3QcrBZKmedxN6 = GABnmSFOwtsu37(ZvWwXBJxzk3Qi9uAHKTD8hY2,Js61GTdX5wzMurUqi7Z(u"ࠬࡻࡲ࡭ࠩႉ"))+yWUkt8lwbPq3QcrBZKmedxN6
			else: yWUkt8lwbPq3QcrBZKmedxN6 = ZvWwXBJxzk3Qi9uAHKTD8hY2.rsplit(BWfpRku7SsM6cbE0eG(u"࠭࠯ࠨႊ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]+IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠰ࠩႋ")+yWUkt8lwbPq3QcrBZKmedxN6
		if TzIj50KpohEOHx6CbZWqB(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪႌ") in list(zaIDkRr1UNp58WOBSZgtnXv.keys()):
			NroHCBWaxUZOfbgqMzAL4vJ2 = zaIDkRr1UNp58WOBSZgtnXv[BWfpRku7SsM6cbE0eG(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ႍࠫ")]
			NroHCBWaxUZOfbgqMzAL4vJ2 = NroHCBWaxUZOfbgqMzAL4vJ2.replace(sH6BOz5wKRFcEg(u"ࠪࠦࠬႎ"),sCHVtMAvqirbQ4BUK3cgWo).replace(EJgYdjbIiWe1apkQlZcR42(u"ࠦࠬࠨႏ"),sCHVtMAvqirbQ4BUK3cgWo).split(IO7k2hZXSz(u"ࠬࠩࠧ႐"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
			m3URNoVvLS6F = FA0Y1k9va5O2zmU6By(NroHCBWaxUZOfbgqMzAL4vJ2)
			if m3URNoVvLS6F: dwDUvp0LAuyg1rI = xkXveAgCLl+LvzD9S8RPyGeukZQqb2T0B+m3URNoVvLS6F
			else: dwDUvp0LAuyg1rI = xkXveAgCLl
			dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭႑")
			dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI+LvzD9S8RPyGeukZQqb2T0B+GABnmSFOwtsu37(NroHCBWaxUZOfbgqMzAL4vJ2,aYH620Dh48GEsTFfOBSQ7r(u"ࠧ࡯ࡣࡰࡩࠬ႒"))
			V9TdsglcWYv0X.append(dwDUvp0LAuyg1rI)
			ss7YGDbuAIxgnqaQroTV.append(NroHCBWaxUZOfbgqMzAL4vJ2)
			pYIcUDHni6BmxZAKyGrNWfFJsR4.append(XO7Zr2W6kwieA)
			yytqzpQMJwGekivobsmIl.append(qlu4QIrH7GwzJ5LTn8jKA)
		yWUkt8lwbPq3QcrBZKmedxN6 = yWUkt8lwbPq3QcrBZKmedxN6.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࠥࠪ႓"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
		m3URNoVvLS6F = FA0Y1k9va5O2zmU6By(yWUkt8lwbPq3QcrBZKmedxN6)
		if m3URNoVvLS6F: xkXveAgCLl = xkXveAgCLl+LvzD9S8RPyGeukZQqb2T0B+m3URNoVvLS6F
		xkXveAgCLl = xkXveAgCLl+LvzD9S8RPyGeukZQqb2T0B+GABnmSFOwtsu37(yWUkt8lwbPq3QcrBZKmedxN6,BWfpRku7SsM6cbE0eG(u"ࠩࡱࡥࡲ࡫ࠧ႔"))
		V9TdsglcWYv0X.append(xkXveAgCLl)
		ss7YGDbuAIxgnqaQroTV.append(yWUkt8lwbPq3QcrBZKmedxN6)
		pYIcUDHni6BmxZAKyGrNWfFJsR4.append(XO7Zr2W6kwieA)
		yytqzpQMJwGekivobsmIl.append(qlu4QIrH7GwzJ5LTn8jKA)
	icYBfzVeQunoDOv2w08dKl = list(zip(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,pYIcUDHni6BmxZAKyGrNWfFJsR4,yytqzpQMJwGekivobsmIl))
	icYBfzVeQunoDOv2w08dKl = sorted(icYBfzVeQunoDOv2w08dKl, reverse=ndkUxG9LtewJ, key=lambda key: key[vUnJhT2NO8yirHcAmg])
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,pYIcUDHni6BmxZAKyGrNWfFJsR4,yytqzpQMJwGekivobsmIl = list(zip(*icYBfzVeQunoDOv2w08dKl))
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = list(V9TdsglcWYv0X),list(ss7YGDbuAIxgnqaQroTV)
	EPhoOUqS1MxVfbR8s6gud = []
	for yWUkt8lwbPq3QcrBZKmedxN6 in ss7YGDbuAIxgnqaQroTV: EPhoOUqS1MxVfbR8s6gud.append(yWUkt8lwbPq3QcrBZKmedxN6+WWQq0NRhgnCIzeT6AP3BUkvl)
	W3MR1OLTGDxIqZApenrC5zk = list(zip(EPhoOUqS1MxVfbR8s6gud,[qqw1upCsKM(u"ࠪࡨࡺࡳ࡭ࡺࠩ႕")]*len(EPhoOUqS1MxVfbR8s6gud),yytqzpQMJwGekivobsmIl))
	X91pGenYIh8z0cv = ju4rw9S8bBylgdK1AOoIh5Dvzf(Ll1m0nJoaAPvHsXqyRE,W3MR1OLTGDxIqZApenrC5zk)
	if X91pGenYIh8z0cv:
		B17r2fdFy9ns8tiOMLu,qLbRrEtgenpSi,qlu4QIrH7GwzJ5LTn8jKA = X91pGenYIh8z0cv[Js61GTdX5wzMurUqi7Z(u"࠴ᖉ")]
		index = EPhoOUqS1MxVfbR8s6gud.index(B17r2fdFy9ns8tiOMLu)
		title = V9TdsglcWYv0X[index]
		V9TdsglcWYv0X,EPhoOUqS1MxVfbR8s6gud = [title],[B17r2fdFy9ns8tiOMLu]
	return V9TdsglcWYv0X,EPhoOUqS1MxVfbR8s6gud
def I0DJU1BnhLfH4QP5cb(afQqnTxbUcPNXgrJlW4LsY,wxcCDGXEkniWdJA=sCHVtMAvqirbQ4BUK3cgWo):
	if not wxcCDGXEkniWdJA: wxcCDGXEkniWdJA = Q1siCkTZyw.DNS_SERVERS[BewrUo9ANCa17G43Sn0LH5xh]
	if afQqnTxbUcPNXgrJlW4LsY.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࠳࠭႖"),sCHVtMAvqirbQ4BUK3cgWo).isdigit(): return [afQqnTxbUcPNXgrJlW4LsY]
	from struct import pack as SS4x90XTKF5prLd3PvhHM,unpack_from as dekMihtnTfvB0L
	from socket import socket as j1W9U4Ekxs0cYo7Aw2fzdyVgnb6,AF_INET as BfexTtRADqZL8iFSwVoYN2yHaMvOn,SOCK_DGRAM as vv9XZ0fba7Vq34ezPTpCUIFYE
	try:
		Rra4SJs2FePqnMT7gc9AV = SS4x90XTKF5prLd3PvhHM(bGzRdmOErkIylxALniq6(u"ࠧࡄࡈࠣ႗"), GVurlv8HeoXEzPRiQB7Ty(u"࠶࠸࠰࠵࠻ᖊ"))
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(TzIj50KpohEOHx6CbZWqB(u"ࠨ࠾ࡉࠤ႘"), TzIj50KpohEOHx6CbZWqB(u"࠸࠵࠷ᖋ"))
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠢ࠿ࡊࠥ႙"), zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(gDETKVh8mZe09Nd(u"ࠣࡀࡋࠦႚ"), BewrUo9ANCa17G43Sn0LH5xh)
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠤࡁࡌࠧႛ"), BewrUo9ANCa17G43Sn0LH5xh)
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(zLjWeKu6JgNO7vocUD0Qpy(u"ࠥࡂࡍࠨႜ"), BewrUo9ANCa17G43Sn0LH5xh)
		if I5VKjrFL0Bk97: oSaRZsrebhB8V = afQqnTxbUcPNXgrJlW4LsY.split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࠳࠭ႝ"))
		else: oSaRZsrebhB8V = afQqnTxbUcPNXgrJlW4LsY.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).split(fvYGxnZNUiyP4HJkMIoS25(u"ࠬ࠴ࠧ႞"))
		for fFkvEQWyOtAMSjJb in oSaRZsrebhB8V:
			PWiDSTJnUhdm1o5g6OltZ = fFkvEQWyOtAMSjJb.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(Js61GTdX5wzMurUqi7Z(u"ࠨࡂࠣ႟"), len(fFkvEQWyOtAMSjJb))
			for L5iOb4zqskBfNWjxIUhoK8plg3QFe in fFkvEQWyOtAMSjJb:
				Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(SE97R3Dpj6dPLweVKU(u"ࠢࡤࠤႠ"), L5iOb4zqskBfNWjxIUhoK8plg3QFe.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠣࡄࠥႡ"), BewrUo9ANCa17G43Sn0LH5xh)
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(aYH620Dh48GEsTFfOBSQ7r(u"ࠤࡁࡌࠧႢ"), zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		Rra4SJs2FePqnMT7gc9AV += SS4x90XTKF5prLd3PvhHM(YQNd4wejLSAVJ6T(u"ࠥࡂࡍࠨႣ"), zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		CceqGTzsMNIZL7 = j1W9U4Ekxs0cYo7Aw2fzdyVgnb6(BfexTtRADqZL8iFSwVoYN2yHaMvOn,vv9XZ0fba7Vq34ezPTpCUIFYE)
		CceqGTzsMNIZL7.sendto(bytes(Rra4SJs2FePqnMT7gc9AV),(wxcCDGXEkniWdJA,SIkwCEdJHTD9v1(u"࠵࠴ᖌ")))
		CceqGTzsMNIZL7.settimeout(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠷ᖍ"))
		gWlmUqwV3YrIT2XNPxQCisBHSDG9, kkj86AuULyJhP = CceqGTzsMNIZL7.recvfrom(jwzOabysh0Z(u"࠳࠳࠶࠹ᖎ"))
		CceqGTzsMNIZL7.close()
		uuQz9cXKGU5hmL6PAaT3DtWoEIZBy = dekMihtnTfvB0L(IOHSz7YPF9WusGgUt1Dq(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧႤ"), gWlmUqwV3YrIT2XNPxQCisBHSDG9, BewrUo9ANCa17G43Sn0LH5xh)
		krxiLIbmZjTg49az8hUO = uuQz9cXKGU5hmL6PAaT3DtWoEIZBy[vUnJhT2NO8yirHcAmg]
		RXOxyCLtpfg = len(afQqnTxbUcPNXgrJlW4LsY)+TzIj50KpohEOHx6CbZWqB(u"࠴࠼ᖏ")
		oAsDQxGyP2kFK7wYiIN = []
		for _ij0PaU2hqRnMeZ9BLIlpYsr in range(krxiLIbmZjTg49az8hUO):
			HsjlCiq6MgXza708x2tfNSEh = RXOxyCLtpfg
			MMzO6US57cdnjqsX4Yy2Rwb98Kt = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			nmRBhCSF2QyP = lvzrYTpcBaK
			while ndkUxG9LtewJ:
				L5iOb4zqskBfNWjxIUhoK8plg3QFe = dekMihtnTfvB0L(GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡄࡂࠣႥ"), gWlmUqwV3YrIT2XNPxQCisBHSDG9, HsjlCiq6MgXza708x2tfNSEh)[BewrUo9ANCa17G43Sn0LH5xh]
				if L5iOb4zqskBfNWjxIUhoK8plg3QFe == BewrUo9ANCa17G43Sn0LH5xh:
					HsjlCiq6MgXza708x2tfNSEh += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
					break
				if L5iOb4zqskBfNWjxIUhoK8plg3QFe >= RDwahqjPfbdyEiTtnLQu(u"࠵࠾࠸ᖐ"):
					OR3NAerTDlUtJK5yuVS0vGsf = dekMihtnTfvB0L(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࠾ࡃࠤႦ"), gWlmUqwV3YrIT2XNPxQCisBHSDG9, HsjlCiq6MgXza708x2tfNSEh + zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
					HsjlCiq6MgXza708x2tfNSEh = ((L5iOb4zqskBfNWjxIUhoK8plg3QFe << qqw1upCsKM(u"࠽ᖑ")) + OR3NAerTDlUtJK5yuVS0vGsf - 0xc000) - zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
					nmRBhCSF2QyP = ndkUxG9LtewJ
				HsjlCiq6MgXza708x2tfNSEh += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				if nmRBhCSF2QyP == lvzrYTpcBaK: MMzO6US57cdnjqsX4Yy2Rwb98Kt += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			if nmRBhCSF2QyP == ndkUxG9LtewJ: MMzO6US57cdnjqsX4Yy2Rwb98Kt += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			RXOxyCLtpfg = RXOxyCLtpfg + MMzO6US57cdnjqsX4Yy2Rwb98Kt
			cWPyiQAqZ3egaE = dekMihtnTfvB0L(qqw1upCsKM(u"ࠢ࠿ࡊࡋࡍࡍࠨႧ"), gWlmUqwV3YrIT2XNPxQCisBHSDG9, RXOxyCLtpfg)
			RXOxyCLtpfg = RXOxyCLtpfg + qeG16a4pbSHziNVQ2uFXrs(u"࠷࠰ᖒ")
			DDtWOx9LyE1YVUAfN56eko = cWPyiQAqZ3egaE[BewrUo9ANCa17G43Sn0LH5xh]
			ttyvrw58iBzPuLeN4o09cA = cWPyiQAqZ3egaE[vUnJhT2NO8yirHcAmg]
			if DDtWOx9LyE1YVUAfN56eko == zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				flDLNnudicZ4xGs2UJk0IvFEO = dekMihtnTfvB0L(aYH620Dh48GEsTFfOBSQ7r(u"ࠣࡀࠥႨ")+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠤࡅࠦႩ")*ttyvrw58iBzPuLeN4o09cA, gWlmUqwV3YrIT2XNPxQCisBHSDG9, RXOxyCLtpfg)
				ip = sCHVtMAvqirbQ4BUK3cgWo
				for L5iOb4zqskBfNWjxIUhoK8plg3QFe in flDLNnudicZ4xGs2UJk0IvFEO: ip += str(L5iOb4zqskBfNWjxIUhoK8plg3QFe) + t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪ࠲ࠬႪ")
				ip = ip[BewrUo9ANCa17G43Sn0LH5xh:-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				oAsDQxGyP2kFK7wYiIN.append(ip)
			if DDtWOx9LyE1YVUAfN56eko in [zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,rgpY5VUqKbeFOCD9Nki2SmGvxEja,SIkwCEdJHTD9v1(u"࠷ᖕ"),TzIj50KpohEOHx6CbZWqB(u"࠹ᖖ"),sH6BOz5wKRFcEg(u"࠲࠷ᖔ"),TzIj50KpohEOHx6CbZWqB(u"࠲࠹ᖓ")]: RXOxyCLtpfg = RXOxyCLtpfg + ttyvrw58iBzPuLeN4o09cA
	except: oAsDQxGyP2kFK7wYiIN = []
	if not oAsDQxGyP2kFK7wYiIN: SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+qeG16a4pbSHziNVQ2uFXrs(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪႫ")+afQqnTxbUcPNXgrJlW4LsY+RDwahqjPfbdyEiTtnLQu(u"ࠬࠦ࡝ࠨႬ"))
	return oAsDQxGyP2kFK7wYiIN
def NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,ZvWwXBJxzk3Qi9uAHKTD8hY2,twBMfGAxJOELq6oHj5S2d7,showDialogs=ndkUxG9LtewJ):
	if Q1siCkTZyw.avprivsnorestrict or not twBMfGAxJOELq6oHj5S2d7: return lvzrYTpcBaK
	Ua4oGF6vmHZif2Dcb7hNS9 = [BWfpRku7SsM6cbE0eG(u"࠭ࡡࡥࡷ࡯ࡸࠬႭ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࠲࠺࠮ࠫႮ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡺࡻࠫႯ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡳࡳࡷࡴࠧႰ"),YQNd4wejLSAVJ6T(u"ࠪࡷࡪࡾࠧႱ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡳࡹࡦࡸࠩႲ"),bGzRdmOErkIylxALniq6(u"ࠬࡳࡡࡵࡷࡵࡩࠬႳ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ใษษิࠫႴ"),YQNd4wejLSAVJ6T(u"ࠧษษ็฾ࠬႵ"),gDETKVh8mZe09Nd(u"ࠨษหหา๐ࠧႶ"),RDwahqjPfbdyEiTtnLQu(u"ࠩฯุ๊࠭Ⴗ"),aenpKvQCGVzhLXEdWiDIZ(u"้๊ࠪ์ฺ่ࠩႸ")]
	if Ll1m0nJoaAPvHsXqyRE!=Js61GTdX5wzMurUqi7Z(u"ࠫࡇࡕࡋࡓࡃࠪႹ"): Ua4oGF6vmHZif2Dcb7hNS9 += [iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡸ࠺ࠨႺ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࠺ࡳࠩႻ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡳ࠯ࠪႼ"),EJgYdjbIiWe1apkQlZcR42(u"ࠨ࠯ࡵࠫႽ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࠰ࡱࡦ࠭Ⴞ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡱࡦ࠳ࠧႿ")]
	for qvJbgdM9esQ53RA1 in twBMfGAxJOELq6oHj5S2d7:
		qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.lower()
		if Js61GTdX5wzMurUqi7Z(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭Ⴠ") in qvJbgdM9esQ53RA1: continue
		if SIkwCEdJHTD9v1(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨჁ") in qvJbgdM9esQ53RA1: continue
		if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧჂ") in qvJbgdM9esQ53RA1: continue
		if EJgYdjbIiWe1apkQlZcR42(u"ࠧฮๆๅอࠬჃ") in qvJbgdM9esQ53RA1: continue
		if aYH620Dh48GEsTFfOBSQ7r(u"ࠨ฼ํี๋ࠥี็ใࠪჄ") in qvJbgdM9esQ53RA1: continue
		qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.replace(EJgYdjbIiWe1apkQlZcR42(u"ࠩฦࠫჅ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪหࠬ჆")).replace(IOHSz7YPF9WusGgUt1Dq(u"ࠫส࠭Ⴧ"),IOHSz7YPF9WusGgUt1Dq(u"ࠬอࠧ჈")).replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ยࠨ჉"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧศࠩ჊")).replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠨ๐ࠪ჋"),sCHVtMAvqirbQ4BUK3cgWo).replace(hPFcB6Uxmabj59Iq(u"ࠩ๎ࠫ჌"),sCHVtMAvqirbQ4BUK3cgWo)
		qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.replace(TzIj50KpohEOHx6CbZWqB(u"ࠪ๓ࠬჍ"),sCHVtMAvqirbQ4BUK3cgWo).replace(GVurlv8HeoXEzPRiQB7Ty(u"ࠫ๕࠭჎"),sCHVtMAvqirbQ4BUK3cgWo).replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ๓ࠧ჏"),sCHVtMAvqirbQ4BUK3cgWo).replace(GVurlv8HeoXEzPRiQB7Ty(u"࠭๑ࠨა"),sCHVtMAvqirbQ4BUK3cgWo)
		qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.replace(YQNd4wejLSAVJ6T(u"ࠧแࠩბ"),sCHVtMAvqirbQ4BUK3cgWo).replace(IO7k2hZXSz(u"ࠨ࠼ࠪგ"),sCHVtMAvqirbQ4BUK3cgWo)
		if qdUK5ioJyrO1T: qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		zCATjKHS9sbceMYrRknU0GpBxovJt = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"ࠩࠫ࠵ࡠ࠻࠭࠺࡟࠮ࢀ࠷ࡡ࠰࠮࠵ࡠ࠯࠮࠭დ"),qvJbgdM9esQ53RA1,fNntYJW45mEFSdRX8g.DOTALL)
		couwSaDOAMl0ZtJER3nk1j2WXVFYH = lvzrYTpcBaK
		for WQjJAPO1yMURXr5edqmwKCvZE in zCATjKHS9sbceMYrRknU0GpBxovJt:
			if len(WQjJAPO1yMURXr5edqmwKCvZE)==rgpY5VUqKbeFOCD9Nki2SmGvxEja:
				couwSaDOAMl0ZtJER3nk1j2WXVFYH = ndkUxG9LtewJ
				break
		if qvJbgdM9esQ53RA1 in [GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡶࠬე")] or couwSaDOAMl0ZtJER3nk1j2WXVFYH or any(value in qvJbgdM9esQ53RA1 for value in Ua4oGF6vmHZif2Dcb7hNS9):
			SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+YQNd4wejLSAVJ6T(u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪვ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+fvYGxnZNUiyP4HJkMIoS25(u"ࠬࠦ࡝ࠨზ"))
			if showDialogs: iRaHzNpJhSx6ZnCfrvD7j93lks(OODdgcrlh8KQo0A7M2eEvViwPqpkR,oVwa0kcqxj1e7mLplAfZdGT(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨთ"))
			return ndkUxG9LtewJ
	return lvzrYTpcBaK
def OOsacGDt4owXd52q7gC8l(yOaAGVBzsUJD7oN6ZkbWKmHX2=ndkUxG9LtewJ):
	if yOaAGVBzsUJD7oN6ZkbWKmHX2:
		MMKTiky7N3vVPdx6GIzHFOf2Yjq = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡴࡶࡵࠫი"),hPFcB6Uxmabj59Iq(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭კ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬლ"))
		if MMKTiky7N3vVPdx6GIzHFOf2Yjq: return MMKTiky7N3vVPdx6GIzHFOf2Yjq
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = sCHVtMAvqirbQ4BUK3cgWo
	if BewrUo9ANCa17G43Sn0LH5xh and mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
		JZD8Wzc1MGq9fgVFI2oENX5eT = cIy4z8xCUt7j5MhPZO.count(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫმ"))
		if JZD8Wzc1MGq9fgVFI2oENX5eT>t19ZOVHA4CpwFKaeiubcMGvz(u"࠼࠵ᖗ"):
			TqNvzBxf1KpPDg3SRA4yj2mwcVF = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ნ"),cIy4z8xCUt7j5MhPZO,fNntYJW45mEFSdRX8g.DOTALL)
			TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF[BewrUo9ANCa17G43Sn0LH5xh]
	if not TqNvzBxf1KpPDg3SRA4yj2mwcVF:
		jguiVmO30UdaNX8CytZ = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,IOHSz7YPF9WusGgUt1Dq(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫო"),EJgYdjbIiWe1apkQlZcR42(u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧპ"))
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = open(jguiVmO30UdaNX8CytZ,hPFcB6Uxmabj59Iq(u"ࠧࡳࡤࠪჟ")).read()
		if I5VKjrFL0Bk97: TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)
	z4zhyldk8iv5T2rB3pteGXUjfCbZ = fNntYJW45mEFSdRX8g.findall(aenpKvQCGVzhLXEdWiDIZ(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩრ"),TqNvzBxf1KpPDg3SRA4yj2mwcVF,fNntYJW45mEFSdRX8g.DOTALL)
	G7SzBNa2E9DCwHs0To = []
	for MCDsZVht3YjHOx in z4zhyldk8iv5T2rB3pteGXUjfCbZ:
		JsK09FyLe4apHiG2tbo = MCDsZVht3YjHOx.lower()
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪს") in JsK09FyLe4apHiG2tbo: continue
		if IO7k2hZXSz(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪტ") in JsK09FyLe4apHiG2tbo: continue
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫუ") in JsK09FyLe4apHiG2tbo: continue
		if qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡩࡲࡰࡵࠪფ") in JsK09FyLe4apHiG2tbo: continue
		G7SzBNa2E9DCwHs0To.append(MCDsZVht3YjHOx)
	MMKTiky7N3vVPdx6GIzHFOf2Yjq = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(G7SzBNa2E9DCwHs0To,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
	MMKTiky7N3vVPdx6GIzHFOf2Yjq = MMKTiky7N3vVPdx6GIzHFOf2Yjq[BewrUo9ANCa17G43Sn0LH5xh]
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫქ"),SIkwCEdJHTD9v1(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪღ"),MMKTiky7N3vVPdx6GIzHFOf2Yjq,NjPWfJS7CUoTsz4lKk0hg)
	return MMKTiky7N3vVPdx6GIzHFOf2Yjq
def M4kqclZxfAHteyg3RF9(Ro2CsQFGOj14wKIgcuHJ=sCHVtMAvqirbQ4BUK3cgWo):
	if Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX==lvzrYTpcBaK: return
	if not Ro2CsQFGOj14wKIgcuHJ: Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
	if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡕࡼࡷࡹ࡫࡭ࡆࡺ࡬ࡸࠬყ") in Ro2CsQFGOj14wKIgcuHJ or t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬშ") in Ro2CsQFGOj14wKIgcuHJ: return
	if Ro2CsQFGOj14wKIgcuHJ!=oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ჩ"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
	CChmRfAOZ4eLtczYduF = Ro2CsQFGOj14wKIgcuHJ.splitlines()
	YPL6cq2GuCUHwKZE = CChmRfAOZ4eLtczYduF[-oVwa0kcqxj1e7mLplAfZdGT(u"࠶ᖘ")]
	D46kTgexcnKuNoLFqvXwBO8hz = open(GJ96QNqUWSpM40HlLdYsAfVkgKZ,aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡷࡨࠧც")).read()
	if I5VKjrFL0Bk97: D46kTgexcnKuNoLFqvXwBO8hz = D46kTgexcnKuNoLFqvXwBO8hz.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	D46kTgexcnKuNoLFqvXwBO8hz = D46kTgexcnKuNoLFqvXwBO8hz[-Js61GTdX5wzMurUqi7Z(u"࠾࠰࠱࠲ᖙ"):]
	qSTQadRYkueMBEG = hPFcB6Uxmabj59Iq(u"ࠬࡃࠧძ")*zLjWeKu6JgNO7vocUD0Qpy(u"࠱࠱࠲ᖚ")
	if qSTQadRYkueMBEG in D46kTgexcnKuNoLFqvXwBO8hz: D46kTgexcnKuNoLFqvXwBO8hz = D46kTgexcnKuNoLFqvXwBO8hz.rsplit(qSTQadRYkueMBEG,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	if YPL6cq2GuCUHwKZE in D46kTgexcnKuNoLFqvXwBO8hz: D46kTgexcnKuNoLFqvXwBO8hz = D46kTgexcnKuNoLFqvXwBO8hz.rsplit(YPL6cq2GuCUHwKZE,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
	nnPEShQHg8OYIqkw1U4T = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬწ"),D46kTgexcnKuNoLFqvXwBO8hz,fNntYJW45mEFSdRX8g.DOTALL)
	for b4bXGJiQZ5qfPIAT,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in reversed(nnPEShQHg8OYIqkw1U4T):
		if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: break
	else: zVbp6yjdF3qKkTvhDsJX9fgMceCuxt = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧჭ")
	eQz8qI1Mn7OG3btvldjEJoAC4iPkZU,MCDsZVht3YjHOx,S05jute4Vcsn7TwCZa = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	G68NY52VKJiaEC = IOHSz7YPF9WusGgUt1Dq(u"ࠨ࡝ࡕࡘࡑࡣࠧხ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+BWfpRku7SsM6cbE0eG(u"ࠩส่ำ฽ร࠻ࠢࠣࠫჯ")+B8alA5nvIhTxQ+YPL6cq2GuCUHwKZE
	pZ3BTamb0Ilo9AsOg4 = SIkwCEdJHTD9v1(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩჰ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+IO7k2hZXSz(u"ࠫฬ๊ๅึัิ࠾ࠥࠦࠧჱ")+B8alA5nvIhTxQ+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt
	for zidsJpI29rx4w1nOjgFTL3hMqY in reversed(CChmRfAOZ4eLtczYduF):
		if YQNd4wejLSAVJ6T(u"ࠬࡌࡩ࡭ࡧࠣࠦࠬჲ") in zidsJpI29rx4w1nOjgFTL3hMqY and IO7k2hZXSz(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬჳ") in zidsJpI29rx4w1nOjgFTL3hMqY: break
	zidsJpI29rx4w1nOjgFTL3hMqY = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪჴ"),zidsJpI29rx4w1nOjgFTL3hMqY,fNntYJW45mEFSdRX8g.DOTALL)
	if zidsJpI29rx4w1nOjgFTL3hMqY:
		eQz8qI1Mn7OG3btvldjEJoAC4iPkZU,MCDsZVht3YjHOx,S05jute4Vcsn7TwCZa = zidsJpI29rx4w1nOjgFTL3hMqY[BewrUo9ANCa17G43Sn0LH5xh]
		if IOHSz7YPF9WusGgUt1Dq(u"ࠨ࠱ࠪჵ") in eQz8qI1Mn7OG3btvldjEJoAC4iPkZU: eQz8qI1Mn7OG3btvldjEJoAC4iPkZU = eQz8qI1Mn7OG3btvldjEJoAC4iPkZU.rsplit(bGzRdmOErkIylxALniq6(u"ࠩ࠲ࠫჶ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		else: eQz8qI1Mn7OG3btvldjEJoAC4iPkZU = eQz8qI1Mn7OG3btvldjEJoAC4iPkZU.rsplit(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡠࡡ࠭ჷ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		nnUym3V9260 = aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡠࡘࡔࡍ࡟ࠪჸ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+TzIj50KpohEOHx6CbZWqB(u"ࠬอไๆๆไ࠾ࠥࠦࠧჹ")+B8alA5nvIhTxQ+eQz8qI1Mn7OG3btvldjEJoAC4iPkZU
		T6n8CtKOhQ7WblcAirmD = t19ZOVHA4CpwFKaeiubcMGvz(u"࡛࠭ࡓࡖࡏࡡࠬჺ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+GVurlv8HeoXEzPRiQB7Ty(u"ࠧศๆึ฻ึࡀࠠࠡࠩ჻")+B8alA5nvIhTxQ+MCDsZVht3YjHOx
		yxj5a4VYcuWA9oInmSwUEl17LdHMN = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࡝ࡕࡘࡑࡣࠧჼ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+IOHSz7YPF9WusGgUt1Dq(u"ࠩส่๊้ว็࠼ࠣࠤࠬჽ")+B8alA5nvIhTxQ+S05jute4Vcsn7TwCZa
		Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM = nnUym3V9260+slFfrUIWCowaBA7tce3iZbj8xn+T6n8CtKOhQ7WblcAirmD+slFfrUIWCowaBA7tce3iZbj8xn+yxj5a4VYcuWA9oInmSwUEl17LdHMN+slFfrUIWCowaBA7tce3iZbj8xn+pZ3BTamb0Ilo9AsOg4+slFfrUIWCowaBA7tce3iZbj8xn+G68NY52VKJiaEC
		UwKbf6oXuvN4yCM8VP9J = T6n8CtKOhQ7WblcAirmD+slFfrUIWCowaBA7tce3iZbj8xn+pZ3BTamb0Ilo9AsOg4+slFfrUIWCowaBA7tce3iZbj8xn+G68NY52VKJiaEC+slFfrUIWCowaBA7tce3iZbj8xn+nnUym3V9260+slFfrUIWCowaBA7tce3iZbj8xn+yxj5a4VYcuWA9oInmSwUEl17LdHMN
		ahWvK8iXowul = T6n8CtKOhQ7WblcAirmD+slFfrUIWCowaBA7tce3iZbj8xn+G68NY52VKJiaEC+slFfrUIWCowaBA7tce3iZbj8xn+nnUym3V9260+slFfrUIWCowaBA7tce3iZbj8xn+yxj5a4VYcuWA9oInmSwUEl17LdHMN
	else:
		nnUym3V9260,T6n8CtKOhQ7WblcAirmD,yxj5a4VYcuWA9oInmSwUEl17LdHMN = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM = pZ3BTamb0Ilo9AsOg4+sH6BOz5wKRFcEg(u"ࠪࡠࡳࡢ࡮ࠨჾ")+G68NY52VKJiaEC
		UwKbf6oXuvN4yCM8VP9J = pZ3BTamb0Ilo9AsOg4+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡡࡴ࡜࡯ࠩჿ")+G68NY52VKJiaEC
		ahWvK8iXowul = G68NY52VKJiaEC
	olQI2kRuTHN17AJrWUzCm8tYZBn4O = EJgYdjbIiWe1apkQlZcR42(u"ࠬำฯฬࠢั฻ศฺ๋ࠦำ้ࠣ็฻่ะࠩᄀ")+slFfrUIWCowaBA7tce3iZbj8xn
	OOksd3tyHLKfXqSA5670MZcoRT = obBK3wzFaNnv()
	R8DH0JyxQ2acrKbqZSThA = []
	ka7jz96YCdTBnQOLVPuJG3285MHf = OOksd3tyHLKfXqSA5670MZcoRT[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᄁ")]
	GGRPEdHMSq6oeZTA3Yi = VxJn5edvBgR7s2QqfAjw4(WHzJr591Ka8gRdbiLmBp0hT3S)
	if SE97R3Dpj6dPLweVKU(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᄂ") in list(OOksd3tyHLKfXqSA5670MZcoRT.keys()):
		for xu70PCdiTQr,zyZ8oihpC6e3jISL4RGDUJ0nVmxAK,XSA7ZjMychaK in ka7jz96YCdTBnQOLVPuJG3285MHf:
			R8DH0JyxQ2acrKbqZSThA = max(R8DH0JyxQ2acrKbqZSThA,zyZ8oihpC6e3jISL4RGDUJ0nVmxAK)
		if GGRPEdHMSq6oeZTA3Yi<R8DH0JyxQ2acrKbqZSThA:
			JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = qeG16a4pbSHziNVQ2uFXrs(u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫᄃ")
			WQOh7NoUEJuHgGK0pzTrktyeLjxMB = bP5mf0Mo2nz(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡵ࡭࡬࡮ࡴࠨᄄ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧᄅ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫฯำฯ๋อࠪᄆ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬิั้ฮࠪᄇ"),olQI2kRuTHN17AJrWUzCm8tYZBn4O+JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM)
			if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				import i5kNU6T7vE
				i5kNU6T7vE.z1zgwnV9AhRXZlUePbrGp(ndkUxG9LtewJ)
				xxpJdCwRN6SrscbOmga7h5UlHBiW()
			elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==rgpY5VUqKbeFOCD9Nki2SmGvxEja: xxpJdCwRN6SrscbOmga7h5UlHBiW()
	ZZmSF8yE4PO = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,IOHSz7YPF9WusGgUt1Dq(u"࠭࡬ࡪࡵࡷࠫᄈ"),bGzRdmOErkIylxALniq6(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪᄉ"),gDETKVh8mZe09Nd(u"ࠨࡃࡏࡐࡤ࡙ࡅࡏࡖࡢࡉࡗࡘࡏࡓࡕࠪᄊ"))
	if not ZZmSF8yE4PO: ZZmSF8yE4PO = []
	UwKbf6oXuvN4yCM8VP9J = UwKbf6oXuvN4yCM8VP9J.replace(slFfrUIWCowaBA7tce3iZbj8xn,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࡟ࡠࡳ࠭ᄋ")).replace(qqw1upCsKM(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩᄌ"),sCHVtMAvqirbQ4BUK3cgWo).replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
	ahWvK8iXowul = ahWvK8iXowul.replace(slFfrUIWCowaBA7tce3iZbj8xn,hPFcB6Uxmabj59Iq(u"ࠫࡡࡢ࡮ࠨᄍ")).replace(TzIj50KpohEOHx6CbZWqB(u"ࠬࡡࡒࡕࡎࡠࠫᄎ"),sCHVtMAvqirbQ4BUK3cgWo).replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
	SfnV8iGEvekUIp = WHzJr591Ka8gRdbiLmBp0hT3S+YQNd4wejLSAVJ6T(u"࠭࠺࠻ࠩᄏ")+ahWvK8iXowul
	if SfnV8iGEvekUIp in ZZmSF8yE4PO:
		JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = Js61GTdX5wzMurUqi7Z(u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬᄐ")
		ZZDswXvceNFRhafpUtWELYCP(RDwahqjPfbdyEiTtnLQu(u"ࠨࡴ࡬࡫࡭ࡺࠧᄑ"),sCHVtMAvqirbQ4BUK3cgWo,olQI2kRuTHN17AJrWUzCm8tYZBn4O+JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM)
		return
	i1zGONJA5stWwqSpbH6Fxyom2h = str(A4AOrGi8QL).split(YQNd4wejLSAVJ6T(u"ࠩ࠱ࠫᄒ"))[BewrUo9ANCa17G43Sn0LH5xh]
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = Q1siCkTZyw.SITESURLS[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᄓ")][IO7k2hZXSz(u"࠷ᖛ")]
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡕࡕࡓࡕࠩᄔ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭ᄕ"),lvzrYTpcBaK,lvzrYTpcBaK)
	cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
	baPQY693Hyq47F2DhCvpZ = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ᄖ"),cIy4z8xCUt7j5MhPZO,fNntYJW45mEFSdRX8g.DOTALL)
	for oo47Cas3V8j6nIrAtGkqDmXh,NgmfuLcatlOR7Eyj3CMDsr2H,IXfJRNUBx2T,qciOgnRJ3BVZX in baPQY693Hyq47F2DhCvpZ:
		oo47Cas3V8j6nIrAtGkqDmXh = oo47Cas3V8j6nIrAtGkqDmXh.split(GVurlv8HeoXEzPRiQB7Ty(u"ࠧࠬࠩᄗ"))
		IXfJRNUBx2T = IXfJRNUBx2T.split(hPFcB6Uxmabj59Iq(u"ࠨ࠭ࠪᄘ"))
		qciOgnRJ3BVZX = qciOgnRJ3BVZX.split(zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࠮ࠫᄙ"))
		if MCDsZVht3YjHOx in oo47Cas3V8j6nIrAtGkqDmXh and YPL6cq2GuCUHwKZE==NgmfuLcatlOR7Eyj3CMDsr2H and WHzJr591Ka8gRdbiLmBp0hT3S in IXfJRNUBx2T and i1zGONJA5stWwqSpbH6Fxyom2h in qciOgnRJ3BVZX:
			JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = hPFcB6Uxmabj59Iq(u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨᄚ")
			bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡷ࡯ࡧࡩࡶࠪᄛ"),EJgYdjbIiWe1apkQlZcR42(u"ࠬิั้ฮࠪᄜ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪᄝ"),olQI2kRuTHN17AJrWUzCm8tYZBn4O+JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM)
			if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: ZZDswXvceNFRhafpUtWELYCP(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄞ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,JQFmSGbDjgUZ0OYKPEhqzRXTlpnV)
			return
	JQFmSGbDjgUZ0OYKPEhqzRXTlpnV = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨᄟ")
	dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm = bP5mf0Mo2nz(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡵ࡭࡬࡮ࡴࠨᄠ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧᄡ"),BWfpRku7SsM6cbE0eG(u"ࠫฯำฯ๋อࠣะืฬ๊ࠨᄢ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬะอะ์ฮࠤฬ๊ศา่ส้ั࠭ᄣ"),olQI2kRuTHN17AJrWUzCm8tYZBn4O+JQFmSGbDjgUZ0OYKPEhqzRXTlpnV,Lbgzs6N3Jqrxc0pE2nACQ1tyZ7fkM)
	if dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		YzTg4VFtHGSLNrXQZPjuhcy3W6oOK(lvzrYTpcBaK)
		iRaHzNpJhSx6ZnCfrvD7j93lks(hPFcB6Uxmabj59Iq(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣห้ะอะ์ฮࠤฬ๊ฬำศํࠫᄤ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ๎ࡕࡸࡧࡨ࡫ࡳࡴࠩᄥ"),hDjf1Ubgq629nXlOvcFLH4Jw=Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠹࠸࠴ᖜ"))
		xxpJdCwRN6SrscbOmga7h5UlHBiW()
	elif dk3HWlPpvBj1zrGcfVwRUJ48DOQLTm==rgpY5VUqKbeFOCD9Nki2SmGvxEja:
		import i5kNU6T7vE
		i5kNU6T7vE.z1zgwnV9AhRXZlUePbrGp(ndkUxG9LtewJ)
		xxpJdCwRN6SrscbOmga7h5UlHBiW()
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(TzIj50KpohEOHx6CbZWqB(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᄦ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪᄧ"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: KKOmR8SLlskcNxuPwqFtZhWa = YQNd4wejLSAVJ6T(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ᄨ")
	else:
		ZZDswXvceNFRhafpUtWELYCP(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᄩ"),sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,F7Fe63KbGjaz2TcmCNHPdo5QiXO+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬᄪ")+B8alA5nvIhTxQ+TzIj50KpohEOHx6CbZWqB(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩᄫ"))
		return
	LZ1DGWKyolJb2NgvOzIR0 = UwKbf6oXuvN4yCM8VP9J
	import i5kNU6T7vE
	bEZlOa1inyrUgdTw9BKNtcMCLYI = i5kNU6T7vE.XuLQaKS9RB4CxOYG5J0kMsNZnq6bFl(bGzRdmOErkIylxALniq6(u"ࠧࡆࡴࡵࡳࡷࡹࠧᄬ"),LZ1DGWKyolJb2NgvOzIR0,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨᄭ"),KKOmR8SLlskcNxuPwqFtZhWa)
	if bEZlOa1inyrUgdTw9BKNtcMCLYI and KKOmR8SLlskcNxuPwqFtZhWa:
		ZZmSF8yE4PO.append(SfnV8iGEvekUIp)
		kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬᄮ"),IO7k2hZXSz(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬᄯ"),ZZmSF8yE4PO,IfAkw39UvaYWEDXLthFrbSzG)
	return
def S5g4WZwHrl6mojOi01zXtydh(gWlmUqwV3YrIT2XNPxQCisBHSDG9,filename=ZetiSjBQ9bTnF23pzsmXcyWuK):
	hDjf1Ubgq629nXlOvcFLH4Jw.sleep(RDwahqjPfbdyEiTtnLQu(u"࠳࠲࠵࠸࠵ᖝ"))
	if I5VKjrFL0Bk97: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = gWlmUqwV3YrIT2XNPxQCisBHSDG9.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	if not filename: PaIF3ENgrM61XfTBD7xy8JjC = bGzRdmOErkIylxALniq6(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫᄰ")+str(hDjf1Ubgq629nXlOvcFLH4Jw.time())+SIkwCEdJHTD9v1(u"ࠬ࠴ࡤࡢࡶࠪᄱ")
	else: PaIF3ENgrM61XfTBD7xy8JjC = SE97R3Dpj6dPLweVKU(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ᄲ")+filename+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ࠯ࡦࡤࡸࠬᄳ")
	open(PaIF3ENgrM61XfTBD7xy8JjC,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡹࡥࠫᄴ")).write(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
	return
def NIEPcjs2b0YDrZ7(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP):
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP:
		Q3KzTrUfXiFAhEGg1W72toxyIPudmp = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"ࠩ࡯࡭ࡸࡺࠧᄵ"),BWfpRku7SsM6cbE0eG(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨᄶ"),gDETKVh8mZe09Nd(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧᄷ"))
		if Q3KzTrUfXiFAhEGg1W72toxyIPudmp: return Q3KzTrUfXiFAhEGg1W72toxyIPudmp
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = Q1siCkTZyw.SITESURLS[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᄸ")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠹ᖞ")]
	qtWgRvai4wjFumUCLMH = CCKuzJQIRvg(lvzrYTpcBaK) if not R1doy3mDZ4cJVTw5FGLY2t0KxiBvP else Q1siCkTZyw.AV_CLIENT_IDS
	wquHle38sKUCAMLSg = B1UysZq2WtOj()
	AAegc4nriYPDjplE2FToBqG5xsWv = wquHle38sKUCAMLSg.split(EJgYdjbIiWe1apkQlZcR42(u"࠭ࠬࠨᄹ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
	o8eVX1SApIPfu7kaUlmH2034c = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,SE97R3Dpj6dPLweVKU(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᄺ"))
	ICkdKFRWBru9A = uzmcSHYqpIliTL83r2F5()
	QDeqblFjHiWLB7om09XrUygT = {t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡷࡶࡩࡷ࠭ᄻ"):qtWgRvai4wjFumUCLMH,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᄼ"):WHzJr591Ka8gRdbiLmBp0hT3S,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᄽ"):AAegc4nriYPDjplE2FToBqG5xsWv,zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࡮ࡪࡳࠨᄾ"):EpTiLePsOavwod3DxXcjJCq(ICkdKFRWBru9A)}
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,bGzRdmOErkIylxALniq6(u"ࠬࡖࡏࡔࡖࠪᄿ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,QDeqblFjHiWLB7om09XrUygT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫᅀ"))
	Q3KzTrUfXiFAhEGg1W72toxyIPudmp = []
	if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
		Q3KzTrUfXiFAhEGg1W72toxyIPudmp = cIy4z8xCUt7j5MhPZO.replace(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࡝࡞ࡵࠫᅁ"),slFfrUIWCowaBA7tce3iZbj8xn).replace(jwzOabysh0Z(u"ࠨ࡞࡟ࡲࠬᅂ"),slFfrUIWCowaBA7tce3iZbj8xn).replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࡟ࡶࡡࡴࠧᅃ"),slFfrUIWCowaBA7tce3iZbj8xn).replace(f6fsIXQonhvcGg1p,slFfrUIWCowaBA7tce3iZbj8xn)
		Q3KzTrUfXiFAhEGg1W72toxyIPudmp = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ᅄ"),Q3KzTrUfXiFAhEGg1W72toxyIPudmp,fNntYJW45mEFSdRX8g.DOTALL)
		if Q3KzTrUfXiFAhEGg1W72toxyIPudmp:
			Q3KzTrUfXiFAhEGg1W72toxyIPudmp = sorted(Q3KzTrUfXiFAhEGg1W72toxyIPudmp,reverse=lvzrYTpcBaK,key=lambda key: int(key[BewrUo9ANCa17G43Sn0LH5xh]))
			W0wg5RhFv2j8fr1B,qtWgRvai4wjFumUCLMH,r1PgycpO2EHAuM,oAsDQxGyP2kFK7wYiIN,bg1dAEcph3zqxXio4eL0fQ8CJtjWu6,j7CADXI1yWt90Gc52HrsUhKeN = Q3KzTrUfXiFAhEGg1W72toxyIPudmp[BewrUo9ANCa17G43Sn0LH5xh]
			UfiY8o5rA0H = j7CADXI1yWt90Gc52HrsUhKeN if Q1siCkTZyw.avprivslongperiod else r1PgycpO2EHAuM
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(Js61GTdX5wzMurUqi7Z(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ᅅ"),UfiY8o5rA0H)
			kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪᅆ"),YQNd4wejLSAVJ6T(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩᅇ"),Q3KzTrUfXiFAhEGg1W72toxyIPudmp,NjPWfJS7CUoTsz4lKk0hg)
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩᅈ"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
	return Q3KzTrUfXiFAhEGg1W72toxyIPudmp
def cnPoQy2IgjJH5ewYpkZ6B(TUzIvZOQCcmg2ALqp,UGvYM8eoINsAcw=BewrUo9ANCa17G43Sn0LH5xh,dg3VvS0F2ExzutwCN=BewrUo9ANCa17G43Sn0LH5xh):
	if UGvYM8eoINsAcw and not dg3VvS0F2ExzutwCN: dg3VvS0F2ExzutwCN = len(TUzIvZOQCcmg2ALqp)//UGvYM8eoINsAcw
	lpIaz2edjvxH0h4MUiYtkOScN,ruCEzOyVgmGt9WHI7BSofF6d8,xPrB341NbwAJdSR92zf = [],-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,BewrUo9ANCa17G43Sn0LH5xh
	for sNmyDVjHLfuhtoOdx0FZgWcYq9Al in TUzIvZOQCcmg2ALqp:
		if xPrB341NbwAJdSR92zf%dg3VvS0F2ExzutwCN==BewrUo9ANCa17G43Sn0LH5xh:
			ruCEzOyVgmGt9WHI7BSofF6d8 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			lpIaz2edjvxH0h4MUiYtkOScN.append([])
		lpIaz2edjvxH0h4MUiYtkOScN[ruCEzOyVgmGt9WHI7BSofF6d8].append(sNmyDVjHLfuhtoOdx0FZgWcYq9Al)
		xPrB341NbwAJdSR92zf += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	return lpIaz2edjvxH0h4MUiYtkOScN
def t5ty4HcmFA(PaIF3ENgrM61XfTBD7xy8JjC,gWlmUqwV3YrIT2XNPxQCisBHSDG9):
	YCSV1Wce7fqnBbEFT90p4zX5v = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,PaIF3ENgrM61XfTBD7xy8JjC)
	if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU or sH6BOz5wKRFcEg(u"ࠨࡋࡓࡘ࡛ࡥࠧᅉ") not in PaIF3ENgrM61XfTBD7xy8JjC or EJgYdjbIiWe1apkQlZcR42(u"ࠩࡐ࠷࡚ࡥࠧᅊ") not in PaIF3ENgrM61XfTBD7xy8JjC: TqNvzBxf1KpPDg3SRA4yj2mwcVF = str(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
	else:
		lpIaz2edjvxH0h4MUiYtkOScN = cnPoQy2IgjJH5ewYpkZ6B(gWlmUqwV3YrIT2XNPxQCisBHSDG9,jwzOabysh0Z(u"࠽ᖟ"))
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = sCHVtMAvqirbQ4BUK3cgWo
		for q4imW7zcFvh3My in lpIaz2edjvxH0h4MUiYtkOScN:
			TqNvzBxf1KpPDg3SRA4yj2mwcVF += str(q4imW7zcFvh3My)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᅋ")
		TqNvzBxf1KpPDg3SRA4yj2mwcVF = TqNvzBxf1KpPDg3SRA4yj2mwcVF.strip(RDwahqjPfbdyEiTtnLQu(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪᅌ"))
	iiey8KZNLChmU5 = eJFGwKIhm4iTx5dfalZqEkDj.compress(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	open(YCSV1Wce7fqnBbEFT90p4zX5v,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡽࡢࠨᅍ")).write(iiey8KZNLChmU5)
	return
def DrpfGhOCYIog(ELcNnjip84CGbeK,PaIF3ENgrM61XfTBD7xy8JjC):
	if ELcNnjip84CGbeK==BWfpRku7SsM6cbE0eG(u"࠭ࡤࡪࡥࡷࠫᅎ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = {}
	elif ELcNnjip84CGbeK==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࡭࡫ࡶࡸࠬᅏ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = []
	elif ELcNnjip84CGbeK==RDwahqjPfbdyEiTtnLQu(u"ࠨࡵࡷࡶࠬᅐ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = sCHVtMAvqirbQ4BUK3cgWo
	elif ELcNnjip84CGbeK==gDETKVh8mZe09Nd(u"ࠩ࡬ࡲࡹ࠭ᅑ"): gWlmUqwV3YrIT2XNPxQCisBHSDG9 = BewrUo9ANCa17G43Sn0LH5xh
	else: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = ZetiSjBQ9bTnF23pzsmXcyWuK
	YCSV1Wce7fqnBbEFT90p4zX5v = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,PaIF3ENgrM61XfTBD7xy8JjC)
	iiey8KZNLChmU5 = open(YCSV1Wce7fqnBbEFT90p4zX5v,Js61GTdX5wzMurUqi7Z(u"ࠪࡶࡧ࠭ᅒ")).read()
	TqNvzBxf1KpPDg3SRA4yj2mwcVF = eJFGwKIhm4iTx5dfalZqEkDj.decompress(iiey8KZNLChmU5)
	if IO7k2hZXSz(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪᅓ") not in TqNvzBxf1KpPDg3SRA4yj2mwcVF: gWlmUqwV3YrIT2XNPxQCisBHSDG9 = eval(TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	else:
		lpIaz2edjvxH0h4MUiYtkOScN = TqNvzBxf1KpPDg3SRA4yj2mwcVF.split(SIkwCEdJHTD9v1(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫᅔ"))
		del TqNvzBxf1KpPDg3SRA4yj2mwcVF
		gWlmUqwV3YrIT2XNPxQCisBHSDG9 = []
		Jy0r8hXLFv9Q1EOdcxHtN7pGfq = kGX9IF07jirosWYaf3c()
		W0wg5RhFv2j8fr1B = BewrUo9ANCa17G43Sn0LH5xh
		for q4imW7zcFvh3My in lpIaz2edjvxH0h4MUiYtkOScN:
			Jy0r8hXLFv9Q1EOdcxHtN7pGfq.wlbeaA4Xu5Wj(str(W0wg5RhFv2j8fr1B),eval,q4imW7zcFvh3My)
			W0wg5RhFv2j8fr1B += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		del lpIaz2edjvxH0h4MUiYtkOScN
		Jy0r8hXLFv9Q1EOdcxHtN7pGfq.Cks6uN5Dm8cZRd7pL()
		Jy0r8hXLFv9Q1EOdcxHtN7pGfq.levYBZEi5Swz4jyxt7nLDrWOkuXa()
		PpaL3i4t8RS5VnjeW0zd = list(Jy0r8hXLFv9Q1EOdcxHtN7pGfq.resultsDICT.keys())
		mUhOw4rMjSXlbxJpY3LIZnEAFDeq = sorted(PpaL3i4t8RS5VnjeW0zd,reverse=lvzrYTpcBaK,key=lambda key: int(key))
		for W0wg5RhFv2j8fr1B in mUhOw4rMjSXlbxJpY3LIZnEAFDeq:
			gWlmUqwV3YrIT2XNPxQCisBHSDG9 += Jy0r8hXLFv9Q1EOdcxHtN7pGfq.resultsDICT[W0wg5RhFv2j8fr1B]
	return gWlmUqwV3YrIT2XNPxQCisBHSDG9
def WFS1nR5MvjJdYsoc6PIyBiHfUe9(Xkp839QMmYzrsoWTyca):
	vP6o4aQ0tuUy27DCERdh3eG = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ᅕ"),Xkp839QMmYzrsoWTyca,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪᅖ"))
	try: R8bt20jACuWTynFd7 = open(vP6o4aQ0tuUy27DCERdh3eG,sH6BOz5wKRFcEg(u"ࠨࡴࡥࠫᅗ")).read()
	except:
		QQ3N1dsTvi8fVSuOmgB0y = YYEXZsUWhf52vz7HLxc0qGJ.path.join(C2WLO5vrNS,fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩᅘ"),Xkp839QMmYzrsoWTyca,GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ᅙ"))
		try: R8bt20jACuWTynFd7 = open(QQ3N1dsTvi8fVSuOmgB0y,RDwahqjPfbdyEiTtnLQu(u"ࠫࡷࡨࠧᅚ")).read()
		except: return sCHVtMAvqirbQ4BUK3cgWo,[]
	if I5VKjrFL0Bk97: R8bt20jACuWTynFd7 = R8bt20jACuWTynFd7.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	nf6rQ1XiUpHAYbs0uj = fNntYJW45mEFSdRX8g.findall(GVurlv8HeoXEzPRiQB7Ty(u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩᅛ"),R8bt20jACuWTynFd7,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	if not nf6rQ1XiUpHAYbs0uj: return sCHVtMAvqirbQ4BUK3cgWo,[]
	rbXC7aIwUq2N4RmA3cp61iFxfVeS,cS15ECwvyLu = nf6rQ1XiUpHAYbs0uj[BewrUo9ANCa17G43Sn0LH5xh],VxJn5edvBgR7s2QqfAjw4(nf6rQ1XiUpHAYbs0uj[BewrUo9ANCa17G43Sn0LH5xh])
	return rbXC7aIwUq2N4RmA3cp61iFxfVeS,cS15ECwvyLu
def obBK3wzFaNnv():
	eFgmjvwdfG6Sa = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡤࡪࡥࡷࠫᅜ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᅝ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩᅞ"))
	if eFgmjvwdfG6Sa: return eFgmjvwdfG6Sa
	OOksd3tyHLKfXqSA5670MZcoRT,eFgmjvwdfG6Sa = {},{}
	nnPEShQHg8OYIqkw1U4T = [Q1siCkTZyw.SITESURLS[jwzOabysh0Z(u"ࠩࡕࡉࡕࡕࡓࠨᅟ")][BewrUo9ANCa17G43Sn0LH5xh]]
	if A4AOrGi8QL>Js61GTdX5wzMurUqi7Z(u"࠷࠷࠯࠻࠼ᖠ"): nnPEShQHg8OYIqkw1U4T.append(Q1siCkTZyw.SITESURLS[fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡖࡊࡖࡏࡔࠩᅠ")][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
	if I5VKjrFL0Bk97: nnPEShQHg8OYIqkw1U4T.append(Q1siCkTZyw.SITESURLS[aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡗࡋࡐࡐࡕࠪᅡ")][rgpY5VUqKbeFOCD9Nki2SmGvxEja])
	for YJdIrA3lGTj9R0uget1NPc57FzXK in nnPEShQHg8OYIqkw1U4T:
		mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,qqw1upCsKM(u"ࠬࡍࡅࡕࠩᅢ"),YJdIrA3lGTj9R0uget1NPc57FzXK,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪᅣ"))
		if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
			cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
			aG0j6kUYryTZXsASfV8v4hPcR = YJdIrA3lGTj9R0uget1NPc57FzXK.rsplit(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧ࠰ࠩᅤ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠱ᖡ"))[BewrUo9ANCa17G43Sn0LH5xh]
			HUlm0Buy4oe3RSAjDKJ25CtEi = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᅥ"),cIy4z8xCUt7j5MhPZO,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
			for Xkp839QMmYzrsoWTyca,ODmlkIvh3sTVQn1NMGFRaCPz in HUlm0Buy4oe3RSAjDKJ25CtEi:
				SGhiv3IAQ5Y9Vf4uNekgJw1TRj0Wq = aG0j6kUYryTZXsASfV8v4hPcR+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࠲ࠫᅦ")+Xkp839QMmYzrsoWTyca+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࠳ࠬᅧ")+Xkp839QMmYzrsoWTyca+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࠲࠭ᅨ")+ODmlkIvh3sTVQn1NMGFRaCPz+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࠴ࡺࡪࡲࠪᅩ")
				if Xkp839QMmYzrsoWTyca not in list(OOksd3tyHLKfXqSA5670MZcoRT.keys()):
					OOksd3tyHLKfXqSA5670MZcoRT[Xkp839QMmYzrsoWTyca] = []
					eFgmjvwdfG6Sa[Xkp839QMmYzrsoWTyca] = []
				MhFz0qYO5dXepToHRlu = VxJn5edvBgR7s2QqfAjw4(ODmlkIvh3sTVQn1NMGFRaCPz)
				OOksd3tyHLKfXqSA5670MZcoRT[Xkp839QMmYzrsoWTyca].append((ODmlkIvh3sTVQn1NMGFRaCPz,MhFz0qYO5dXepToHRlu,SGhiv3IAQ5Y9Vf4uNekgJw1TRj0Wq))
	for Xkp839QMmYzrsoWTyca in list(OOksd3tyHLKfXqSA5670MZcoRT.keys()):
		eFgmjvwdfG6Sa[Xkp839QMmYzrsoWTyca] = sorted(OOksd3tyHLKfXqSA5670MZcoRT[Xkp839QMmYzrsoWTyca],reverse=ndkUxG9LtewJ,key=lambda key: key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫᅪ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨᅫ"),eFgmjvwdfG6Sa,NjPWfJS7CUoTsz4lKk0hg)
	return eFgmjvwdfG6Sa
def VxJn5edvBgR7s2QqfAjw4(ODmlkIvh3sTVQn1NMGFRaCPz):
	MhFz0qYO5dXepToHRlu = []
	j1fNops7G2uO6PWb = ODmlkIvh3sTVQn1NMGFRaCPz.split(bGzRdmOErkIylxALniq6(u"ࠨ࠰ࠪᅬ"))
	for tpgF3TAwi1lzeEybSxV7PvZun8MKQ in j1fNops7G2uO6PWb:
		PWiDSTJnUhdm1o5g6OltZ = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"ࠩ࡟ࡨ࠰ࢂ࡛࡝࠭࡟࠱ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠭ᅭ"),tpgF3TAwi1lzeEybSxV7PvZun8MKQ,fNntYJW45mEFSdRX8g.DOTALL)
		PQDLyiqBbVWas63Ex = []
		for fFkvEQWyOtAMSjJb in PWiDSTJnUhdm1o5g6OltZ:
			if fFkvEQWyOtAMSjJb.isdigit(): fFkvEQWyOtAMSjJb = int(fFkvEQWyOtAMSjJb)
			PQDLyiqBbVWas63Ex.append(fFkvEQWyOtAMSjJb)
		MhFz0qYO5dXepToHRlu.append(PQDLyiqBbVWas63Ex)
	return MhFz0qYO5dXepToHRlu
def VG06i4oRh3Ks2Hqm(MhFz0qYO5dXepToHRlu):
	ODmlkIvh3sTVQn1NMGFRaCPz = sCHVtMAvqirbQ4BUK3cgWo
	for tpgF3TAwi1lzeEybSxV7PvZun8MKQ in MhFz0qYO5dXepToHRlu:
		for fFkvEQWyOtAMSjJb in tpgF3TAwi1lzeEybSxV7PvZun8MKQ: ODmlkIvh3sTVQn1NMGFRaCPz += str(fFkvEQWyOtAMSjJb)
		ODmlkIvh3sTVQn1NMGFRaCPz += GVurlv8HeoXEzPRiQB7Ty(u"ࠪ࠲ࠬᅮ")
	ODmlkIvh3sTVQn1NMGFRaCPz = ODmlkIvh3sTVQn1NMGFRaCPz.strip(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࠳࠭ᅯ"))
	return ODmlkIvh3sTVQn1NMGFRaCPz
def nPkDNvLX7xircVpzhsGKW(ZQtAwbhVH5kToe1lSC0zdgysi):
	MyeJZzh0Q8RYL2U6 = {}
	OOksd3tyHLKfXqSA5670MZcoRT = obBK3wzFaNnv()
	bbJkqcTvRaD5pK0IwCLxh = NatTJnPvDI2VzLf0GeE5U4rOAS8uCk(ZQtAwbhVH5kToe1lSC0zdgysi)
	for Xkp839QMmYzrsoWTyca in ZQtAwbhVH5kToe1lSC0zdgysi:
		if Xkp839QMmYzrsoWTyca not in list(OOksd3tyHLKfXqSA5670MZcoRT.keys()): continue
		eFgmjvwdfG6Sa = OOksd3tyHLKfXqSA5670MZcoRT[Xkp839QMmYzrsoWTyca]
		HFeWmMp7oDBZn,m2mLEiued649gFS0X,tNVIYvLuPnhc4AJHQesUbk6CyXjMow = eFgmjvwdfG6Sa[BewrUo9ANCa17G43Sn0LH5xh]
		jBLdhuUa7iOPYT20SMvgq1FtH9Rl,TGnRrvw6jEd5egaU = WFS1nR5MvjJdYsoc6PIyBiHfUe9(Xkp839QMmYzrsoWTyca)
		goMtdGWFzeY7q5,ygh20JmuTLVa = bbJkqcTvRaD5pK0IwCLxh[Xkp839QMmYzrsoWTyca]
		eEXlbJcFYVaLWC6rPhAn = m2mLEiued649gFS0X>TGnRrvw6jEd5egaU and goMtdGWFzeY7q5
		gahvbG5HU6K2 = ndkUxG9LtewJ
		if not goMtdGWFzeY7q5: bhNicoMgLY45BCOe0 = sH6BOz5wKRFcEg(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᅰ")
		elif not ygh20JmuTLVa: bhNicoMgLY45BCOe0 = TzIj50KpohEOHx6CbZWqB(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᅱ")
		elif eEXlbJcFYVaLWC6rPhAn: bhNicoMgLY45BCOe0 = IO7k2hZXSz(u"ࠧࡰ࡮ࡧࠫᅲ")
		else:
			bhNicoMgLY45BCOe0 = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡩࡲࡳࡩ࠭ᅳ")
			gahvbG5HU6K2 = lvzrYTpcBaK
		MyeJZzh0Q8RYL2U6[Xkp839QMmYzrsoWTyca] = gahvbG5HU6K2,jBLdhuUa7iOPYT20SMvgq1FtH9Rl,TGnRrvw6jEd5egaU,HFeWmMp7oDBZn,m2mLEiued649gFS0X,bhNicoMgLY45BCOe0,tNVIYvLuPnhc4AJHQesUbk6CyXjMow
	return MyeJZzh0Q8RYL2U6
def TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,OEvCWAKIHmgMnocBVJLyzlju,GG31MtKY0ekWaApNr2CiLUR6F7=sCHVtMAvqirbQ4BUK3cgWo,T6n8CtKOhQ7WblcAirmD=sCHVtMAvqirbQ4BUK3cgWo,oo47Cas3V8j6nIrAtGkqDmXh=sCHVtMAvqirbQ4BUK3cgWo):
	if qdUK5ioJyrO1T: USk4nVycGqThQJ6u12daMIHxsoP.update(OEvCWAKIHmgMnocBVJLyzlju,GG31MtKY0ekWaApNr2CiLUR6F7,T6n8CtKOhQ7WblcAirmD,oo47Cas3V8j6nIrAtGkqDmXh)
	else: USk4nVycGqThQJ6u12daMIHxsoP.update(OEvCWAKIHmgMnocBVJLyzlju,GG31MtKY0ekWaApNr2CiLUR6F7+slFfrUIWCowaBA7tce3iZbj8xn+T6n8CtKOhQ7WblcAirmD+slFfrUIWCowaBA7tce3iZbj8xn+oo47Cas3V8j6nIrAtGkqDmXh)
	return
def wpsnGYEcj5dqy6rOSDFkHJzf(A1kThCgL4f):
	def ssaT9DUKQgLXlSRFv8PG1enBNj6H0(BsCDOiZm73hF,cce6g1pARrUxGuEySF4,XuPV1fZQmhE=qqw1upCsKM(u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛ࠤᅴ")):
		return ((BsCDOiZm73hF == BewrUo9ANCa17G43Sn0LH5xh) and XuPV1fZQmhE[BewrUo9ANCa17G43Sn0LH5xh]) or (ssaT9DUKQgLXlSRFv8PG1enBNj6H0(BsCDOiZm73hF // cce6g1pARrUxGuEySF4, cce6g1pARrUxGuEySF4, XuPV1fZQmhE).lstrip(XuPV1fZQmhE[BewrUo9ANCa17G43Sn0LH5xh]) + XuPV1fZQmhE[BsCDOiZm73hF % cce6g1pARrUxGuEySF4])
	def cgORB1EpuLX08iloe3xKj(W7i3ALxX84bKfNG9, WRBJCFc6Yg, YyQSLTwIN8FGMOnhBRmd7E, StN8fF7ynudQqDbYmV4EJX, VdODUImoyLhYjvSAKQPFM4iN=ZetiSjBQ9bTnF23pzsmXcyWuK, PGIMerh3ZFgUmcWCQJTY=ZetiSjBQ9bTnF23pzsmXcyWuK, yEMgeZJojhmnP6fr=ZetiSjBQ9bTnF23pzsmXcyWuK):
		while (YyQSLTwIN8FGMOnhBRmd7E):
			YyQSLTwIN8FGMOnhBRmd7E-=IOHSz7YPF9WusGgUt1Dq(u"࠲ᖢ")
			if (StN8fF7ynudQqDbYmV4EJX[YyQSLTwIN8FGMOnhBRmd7E]): W7i3ALxX84bKfNG9 = fNntYJW45mEFSdRX8g.sub(SE97R3Dpj6dPLweVKU(u"ࠥࡠࡡࡨࠢᅵ") + ssaT9DUKQgLXlSRFv8PG1enBNj6H0(YyQSLTwIN8FGMOnhBRmd7E, WRBJCFc6Yg) + Js61GTdX5wzMurUqi7Z(u"ࠦࡡࡢࡢࠣᅶ"),  StN8fF7ynudQqDbYmV4EJX[YyQSLTwIN8FGMOnhBRmd7E], W7i3ALxX84bKfNG9)
		return W7i3ALxX84bKfNG9
	A1kThCgL4f = A1kThCgL4f.split(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࢃࠨࠨᅷ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	A1kThCgL4f = A1kThCgL4f.rsplit(hPFcB6Uxmabj59Iq(u"࠭ࡳࡱ࡮࡬ࡸࠬᅸ"))[BewrUo9ANCa17G43Sn0LH5xh]+YQNd4wejLSAVJ6T(u"ࠢࡴࡲ࡯࡭ࡹ࠮ࠧࡽࠩࠬ࠭ࠧᅹ")
	Pgj5yWUqHhn = eval(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩᅺ")+A1kThCgL4f,{hPFcB6Uxmabj59Iq(u"ࠩࡥࡥࡸ࡫ࡎࠨᅻ"):ssaT9DUKQgLXlSRFv8PG1enBNj6H0,gDETKVh8mZe09Nd(u"ࠪࡹࡳࡶࡡࡤ࡭ࠪᅼ"):cgORB1EpuLX08iloe3xKj})
	return Pgj5yWUqHhn
def IY54gnc6DzOS(code):
	_bSinLE8XV2z4lkyHqNTrx0Kf=aYH620Dh48GEsTFfOBSQ7r(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝࠯࠴ࠨᅽ")
	def tBOHnY0Eu2l1whcxqM4(PGIMerh3ZFgUmcWCQJTY,VdODUImoyLhYjvSAKQPFM4iN,yLQI14ozJbFqGwd):
		QOE7CvkVNeU9uolchSngZ64Yqmp3j = list(_bSinLE8XV2z4lkyHqNTrx0Kf)
		Z1v54962cBjGQbkxNMgJIHd = QOE7CvkVNeU9uolchSngZ64Yqmp3j[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲ᖣ"):VdODUImoyLhYjvSAKQPFM4iN]
		XMIo9vWSBymeLJnK6YsU = QOE7CvkVNeU9uolchSngZ64Yqmp3j[t19ZOVHA4CpwFKaeiubcMGvz(u"࠳ᖤ"):yLQI14ozJbFqGwd]
		PGIMerh3ZFgUmcWCQJTY = list(PGIMerh3ZFgUmcWCQJTY)[::-jwzOabysh0Z(u"࠵ᖥ")]
		xukLvBPUIn = IO7k2hZXSz(u"࠵ᖦ")
		for YyQSLTwIN8FGMOnhBRmd7E,cce6g1pARrUxGuEySF4 in enumerate(PGIMerh3ZFgUmcWCQJTY):
			if cce6g1pARrUxGuEySF4 in Z1v54962cBjGQbkxNMgJIHd: xukLvBPUIn = xukLvBPUIn + Z1v54962cBjGQbkxNMgJIHd.index(cce6g1pARrUxGuEySF4)*VdODUImoyLhYjvSAKQPFM4iN**YyQSLTwIN8FGMOnhBRmd7E
		StN8fF7ynudQqDbYmV4EJX = jwzOabysh0Z(u"ࠧࠨᅾ")
		while xukLvBPUIn > qqw1upCsKM(u"࠶ᖧ"):
			StN8fF7ynudQqDbYmV4EJX = XMIo9vWSBymeLJnK6YsU[xukLvBPUIn%yLQI14ozJbFqGwd] + StN8fF7ynudQqDbYmV4EJX
			xukLvBPUIn = (xukLvBPUIn - (xukLvBPUIn%yLQI14ozJbFqGwd))//yLQI14ozJbFqGwd
		return int(StN8fF7ynudQqDbYmV4EJX) or fvYGxnZNUiyP4HJkMIoS25(u"࠰ᖨ")
	def gJhOneWjHcrfxVNI1Kt(Z1v54962cBjGQbkxNMgJIHd,u,TYeRU0bcKNwuWzsfJCjPZi,wieNPVpZgRMHk,VdODUImoyLhYjvSAKQPFM4iN,yEMgeZJojhmnP6fr):
		yEMgeZJojhmnP6fr = zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢᅿ");
		XMIo9vWSBymeLJnK6YsU = EJgYdjbIiWe1apkQlZcR42(u"࠱ᖩ")
		while XMIo9vWSBymeLJnK6YsU < len(Z1v54962cBjGQbkxNMgJIHd):
			xukLvBPUIn = E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠲ᖪ")
			q0CvzPKYly4noZ51FX3URMIkSTh = Js61GTdX5wzMurUqi7Z(u"ࠢࠣᆀ")
			while Z1v54962cBjGQbkxNMgJIHd[XMIo9vWSBymeLJnK6YsU] is not TYeRU0bcKNwuWzsfJCjPZi[VdODUImoyLhYjvSAKQPFM4iN]:
				q0CvzPKYly4noZ51FX3URMIkSTh = sCHVtMAvqirbQ4BUK3cgWo.join([q0CvzPKYly4noZ51FX3URMIkSTh,Z1v54962cBjGQbkxNMgJIHd[XMIo9vWSBymeLJnK6YsU]])
				XMIo9vWSBymeLJnK6YsU = XMIo9vWSBymeLJnK6YsU + RDwahqjPfbdyEiTtnLQu(u"࠴ᖫ")
			while xukLvBPUIn < len(TYeRU0bcKNwuWzsfJCjPZi):
				q0CvzPKYly4noZ51FX3URMIkSTh = q0CvzPKYly4noZ51FX3URMIkSTh.replace(TYeRU0bcKNwuWzsfJCjPZi[xukLvBPUIn],str(xukLvBPUIn))
				xukLvBPUIn = xukLvBPUIn + SIkwCEdJHTD9v1(u"࠵ᖬ")
			yEMgeZJojhmnP6fr = sCHVtMAvqirbQ4BUK3cgWo.join([yEMgeZJojhmnP6fr,sCHVtMAvqirbQ4BUK3cgWo.join(map(chr, [tBOHnY0Eu2l1whcxqM4(q0CvzPKYly4noZ51FX3URMIkSTh,VdODUImoyLhYjvSAKQPFM4iN,oVwa0kcqxj1e7mLplAfZdGT(u"࠶࠶ᖭ")) - wieNPVpZgRMHk]))])
			XMIo9vWSBymeLJnK6YsU = XMIo9vWSBymeLJnK6YsU + t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠷ᖮ")
		return yEMgeZJojhmnP6fr
	code = code.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࡞ࡱࠫᆁ"),sCHVtMAvqirbQ4BUK3cgWo).replace(bGzRdmOErkIylxALniq6(u"ࠩ࡟ࡶࠬᆂ"),sCHVtMAvqirbQ4BUK3cgWo)
	cBr6N7wavRCU2TYqtGhso0IWdOeZ = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠪࡠࢂࡢࠨࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭ࡡ࠯࡜ࠪࠩᆃ"),code,fNntYJW45mEFSdRX8g.DOTALL)
	if cBr6N7wavRCU2TYqtGhso0IWdOeZ:
		cBr6N7wavRCU2TYqtGhso0IWdOeZ = list(cBr6N7wavRCU2TYqtGhso0IWdOeZ[aYH620Dh48GEsTFfOBSQ7r(u"࠰ᖯ")])
		for oYTBMPpewq6ZmCO27tiD4HEzJKy,code in enumerate(cBr6N7wavRCU2TYqtGhso0IWdOeZ):
			if code.isdigit(): cBr6N7wavRCU2TYqtGhso0IWdOeZ[oYTBMPpewq6ZmCO27tiD4HEzJKy] = int(code)
			else: cBr6N7wavRCU2TYqtGhso0IWdOeZ[oYTBMPpewq6ZmCO27tiD4HEzJKy] = code.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡡࠨࠧᆄ"),sCHVtMAvqirbQ4BUK3cgWo)
		p1I9DSy2t8XPgU4ORcds = gJhOneWjHcrfxVNI1Kt(*cBr6N7wavRCU2TYqtGhso0IWdOeZ)
		return p1I9DSy2t8XPgU4ORcds
	return sCHVtMAvqirbQ4BUK3cgWo
def a1ZbJRIdvq4sczt(ZvWwXBJxzk3Qi9uAHKTD8hY2,BJmyAE4VjMQbdfFi8YlNs=sCHVtMAvqirbQ4BUK3cgWo):
	if BJmyAE4VjMQbdfFi8YlNs==RDwahqjPfbdyEiTtnLQu(u"ࠬࡲ࡯ࡸࡧࡵࠫᆅ"): ZvWwXBJxzk3Qi9uAHKTD8hY2 = fNntYJW45mEFSdRX8g.sub(sH6BOz5wKRFcEg(u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭ᆆ"),lambda QaqTSDCo2WhLklXUHbjOs5: QaqTSDCo2WhLklXUHbjOs5.group(BewrUo9ANCa17G43Sn0LH5xh).lower(),ZvWwXBJxzk3Qi9uAHKTD8hY2)
	elif BJmyAE4VjMQbdfFi8YlNs==E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡶࡲࡳࡩࡷ࠭ᆇ"): ZvWwXBJxzk3Qi9uAHKTD8hY2 = fNntYJW45mEFSdRX8g.sub(sH6BOz5wKRFcEg(u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨᆈ"),lambda QaqTSDCo2WhLklXUHbjOs5: QaqTSDCo2WhLklXUHbjOs5.group(BewrUo9ANCa17G43Sn0LH5xh).upper(),ZvWwXBJxzk3Qi9uAHKTD8hY2)
	return ZvWwXBJxzk3Qi9uAHKTD8hY2
def NatTJnPvDI2VzLf0GeE5U4rOAS8uCk(ZQtAwbhVH5kToe1lSC0zdgysi):
	FjoEY1MfAkL2x73Ver,c7zXEldMQv6 = lvzrYTpcBaK,lvzrYTpcBaK
	lxGwZhDLdoySA1avUN5 = jcNEqrxW4uBOgHKhvU3dnMfXTFm.connect(fMnyRlYuDxPHvjC)
	lxGwZhDLdoySA1avUN5.text_factory = str
	Fy1DHCosVPbSNMnWl0RQaiLtxB = lxGwZhDLdoySA1avUN5.cursor()
	if len(ZQtAwbhVH5kToe1lSC0zdgysi)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: pFkIQ9hAU1y7WHiMgubVEetZ2a5z = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࠫࠦࠬᆉ")+ZQtAwbhVH5kToe1lSC0zdgysi[BewrUo9ANCa17G43Sn0LH5xh]+SE97R3Dpj6dPLweVKU(u"ࠪࠦ࠮࠭ᆊ")
	else: pFkIQ9hAU1y7WHiMgubVEetZ2a5z = str(tuple(ZQtAwbhVH5kToe1lSC0zdgysi))
	Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫᆋ")+pFkIQ9hAU1y7WHiMgubVEetZ2a5z+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࠦ࠻ࠨᆌ"))
	TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq = Fy1DHCosVPbSNMnWl0RQaiLtxB.fetchall()
	lxGwZhDLdoySA1avUN5.close()
	bbJkqcTvRaD5pK0IwCLxh = {}
	for Xkp839QMmYzrsoWTyca in ZQtAwbhVH5kToe1lSC0zdgysi: bbJkqcTvRaD5pK0IwCLxh[Xkp839QMmYzrsoWTyca] = (lvzrYTpcBaK,lvzrYTpcBaK)
	for Xkp839QMmYzrsoWTyca,c7zXEldMQv6 in TtkjgECB8yIF1mMGXxVrARQ6U3ZuHq:
		FjoEY1MfAkL2x73Ver = ndkUxG9LtewJ
		c7zXEldMQv6 = c7zXEldMQv6==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		bbJkqcTvRaD5pK0IwCLxh[Xkp839QMmYzrsoWTyca] = (FjoEY1MfAkL2x73Ver,c7zXEldMQv6)
	return bbJkqcTvRaD5pK0IwCLxh
def IV2b9wBsc0SmCaUEkNDK(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU):
	ka7jz96YCdTBnQOLVPuJG3285MHf = sCHVtMAvqirbQ4BUK3cgWo
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU):
		Zk4v1yYSjrp7VEHnUfzx0TO2oI = open(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡲࡣࠩᆍ")).read()
		if I5VKjrFL0Bk97: Zk4v1yYSjrp7VEHnUfzx0TO2oI = Zk4v1yYSjrp7VEHnUfzx0TO2oI.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		AADQUzVxGbcirTe2ZukL = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(BWfpRku7SsM6cbE0eG(u"ࠧࡥ࡫ࡦࡸࠬᆎ"),Zk4v1yYSjrp7VEHnUfzx0TO2oI)
		if AADQUzVxGbcirTe2ZukL:
			ka7jz96YCdTBnQOLVPuJG3285MHf = {}
			for XuhpgCFwT9RcZe8Yta5 in AADQUzVxGbcirTe2ZukL.keys():
				ka7jz96YCdTBnQOLVPuJG3285MHf[XuhpgCFwT9RcZe8Yta5] = []
				for aE4mq7uL0f13y6Pvk in AADQUzVxGbcirTe2ZukL[XuhpgCFwT9RcZe8Yta5]:
					ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
					ScEpZwINx93VJ5aWfb4 = aE4mq7uL0f13y6Pvk[BewrUo9ANCa17G43Sn0LH5xh]
					zz17bL8m9dw2kIcNqR5ortGiXnKj4 = aE4mq7uL0f13y6Pvk[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
					zz17bL8m9dw2kIcNqR5ortGiXnKj4 = nnXGrIdCOuVxENgQz3lsckS(zz17bL8m9dw2kIcNqR5ortGiXnKj4)
					ZvWwXBJxzk3Qi9uAHKTD8hY2 = aE4mq7uL0f13y6Pvk[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
					GLrDUZJWtdSzaoeQNfw = aE4mq7uL0f13y6Pvk[vUnJhT2NO8yirHcAmg]
					Qp3jGv8leCbuiEU5Im = aE4mq7uL0f13y6Pvk[kK7gj9HE462hADJbvr]
					mRwrKW6fNZV = aE4mq7uL0f13y6Pvk[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠶ᖰ")]
					if len(aE4mq7uL0f13y6Pvk)>fvYGxnZNUiyP4HJkMIoS25(u"࠸ᖱ"): TqNvzBxf1KpPDg3SRA4yj2mwcVF = aE4mq7uL0f13y6Pvk[fvYGxnZNUiyP4HJkMIoS25(u"࠸ᖱ")]
					if len(aE4mq7uL0f13y6Pvk)>bGzRdmOErkIylxALniq6(u"࠺ᖲ"): IFYonX8LZUfz3VJyuQlxgE = aE4mq7uL0f13y6Pvk[bGzRdmOErkIylxALniq6(u"࠺ᖲ")]
					if len(aE4mq7uL0f13y6Pvk)>Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠼ᖳ"): ZQC69Pyo4BOamJlwSLtAWINg7q = aE4mq7uL0f13y6Pvk[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠼ᖳ")]
					if eQz8qI1Mn7OG3btvldjEJoAC4iPkZU==u3yGxS2mRw1fW54N7DchIvEoaq: CnWwy5e1OtBT6ArFUqVNv = ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q
					else: CnWwy5e1OtBT6ArFUqVNv = ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q
					ka7jz96YCdTBnQOLVPuJG3285MHf[XuhpgCFwT9RcZe8Yta5].append(CnWwy5e1OtBT6ArFUqVNv)
		s1eVRLfFbycvMB = str(ka7jz96YCdTBnQOLVPuJG3285MHf)
		if I5VKjrFL0Bk97: s1eVRLfFbycvMB = s1eVRLfFbycvMB.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡹࡥࠫᆏ")).write(s1eVRLfFbycvMB)
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38):
	qCDt2dG9EZ6pXskxnMUK3cw = oT2iHwjfBx0FPX5ZCph9aWs38.split(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠰ࠫᆐ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
	lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if   qCDt2dG9EZ6pXskxnMUK3cw==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡅࡍ࡝ࡁࡌࠩᆑ")		:	from XHGUixIV15			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==EJgYdjbIiWe1apkQlZcR42(u"ࠫࡆࡑࡏࡂࡏࠪᆒ")		:	from Tj607v5yLp			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧᆓ")	:	from q2Z5n1Y0lG		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡁࡌ࡙ࡄࡑࠬᆔ")		:	from jARZX7M1ml			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪᆕ")	:	from PPy8eUQk7I		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==TzIj50KpohEOHx6CbZWqB(u"ࠨࡃࡏࡅࡗࡇࡂࠨᆖ")	:	from ms5uRvCM3J			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SE97R3Dpj6dPLweVKU(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫᆗ")	:	from CCr6xo5qzU		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==BWfpRku7SsM6cbE0eG(u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭ᆘ")	: 	from nAUyG7RDzd		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ᆙ")	:	from jSQ1pFam8A		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IO7k2hZXSz(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ᆚ")	:	from XWpCdiOMY7		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==BWfpRku7SsM6cbE0eG(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨᆛ")	:	from f4GMVdHIem		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬᆜ"):	from mkoePUv2GJ	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==sH6BOz5wKRFcEg(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪᆝ")	:	from wNUC3haOcZ		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==sH6BOz5wKRFcEg(u"ࠩࡄ࡝ࡑࡕࡌࠨᆞ")		:	from mfFJQNIMUj			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==RDwahqjPfbdyEiTtnLQu(u"ࠪࡆࡔࡑࡒࡂࠩᆟ")		:	from hhLbd2NzOM			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qqw1upCsKM(u"ࠫࡇࡘࡓࡕࡇࡍࠫᆠ")	:	from LVRH6rwKZs			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==bGzRdmOErkIylxALniq6(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᆡ")	:	from xpnBkIXMyR		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ᆢ")	:	from Sd1Nl0aFVK			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Js61GTdX5wzMurUqi7Z(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᆣ")	:	from iZ67teKPJ2			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==YQNd4wejLSAVJ6T(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪᆤ")	:	from F9iSmYecgb		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫᆥ")	:	from QEwz0xoOij		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==EJgYdjbIiWe1apkQlZcR42(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᆦ"):	from rdOtXv5GaM	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==hPFcB6Uxmabj59Iq(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭ᆧ")	:	from aaTnje6zcV		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧᆨ")	:	from cS5xb9FMyp		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IO7k2hZXSz(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨᆩ")	:	from RXNoxvIq0f		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᆪ")	:	from yhdRrYV18l		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩᆫ")	:	from l1lgZCVGrv		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==gDETKVh8mZe09Nd(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫᆬ")	:	from J3ZvWq0ipG		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SIkwCEdJHTD9v1(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨᆭ"):	from mf9uYb3GgD	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==jwzOabysh0Z(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧᆮ")	:	from NK9LFjVnrW		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ᆯ")	:	from sP3HGvTXiC		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧᆰ")	:	from usqkUlxVwh		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==EJgYdjbIiWe1apkQlZcR42(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩᆱ")	:	from pptqZhrQWd		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪᆲ")	:	from z8Zxb5UIV6		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫᆳ")	:	from TAFQaICyVY		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==bGzRdmOErkIylxALniq6(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬᆴ")	:	from JJpkL4ZuSH		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==sH6BOz5wKRFcEg(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬᆵ")	:	from JfPDVnRtmv		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬᆶ")	:	from yMvNSb80wf			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨᆷ")	:	from xwcG7MVrQW		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪᆸ")	:	from KVZaNo2zEF		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IO7k2hZXSz(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩᆹ")	:	from EES5aBWVF2		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==YQNd4wejLSAVJ6T(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬᆺ")	:	from dmn76SaZ0E		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IOHSz7YPF9WusGgUt1Dq(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫᆻ")	:	from VXe9Ul7Oa5		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qqw1upCsKM(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᆼ")	:	from AjNmfn13zT		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧᆽ")	:	from V7UpJAqcw2		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IO7k2hZXSz(u"࠭ࡆࡐࡕࡗࡅࠬᆾ")		:	from FWPvQSmib2			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==BWfpRku7SsM6cbE0eG(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨᆿ")	:	from ncL0p324ZN		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SE97R3Dpj6dPLweVKU(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪᇀ")	:	from vOduzMJrZE		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IOHSz7YPF9WusGgUt1Dq(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧᇁ"):	from So1tmHRnIe	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡋࡔࡕࡇࡍࡇࡖࡉࡆࡘࡃࡉࠩᇂ"):	from Im8RhG6yKo	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ᇃ")	:	from xb2NoaQ9Zy		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SIkwCEdJHTD9v1(u"ࠬࡏࡆࡊࡎࡐࠫᇄ")		:	from ppqt7r6ZCE			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡉࡑࡖ࡙ࠫᇅ")		:	from ebtl4A2fjS			import AtylB0o7GnY9ui1UQSqNdPL4r as lDt71RPxgnZs0LzHurJAdqU,wwinEbetVG3su1TD2L7NFOp as bHSQRo5vFEuWUw1978CLY,Y6xCT1m2lpbnKLJPZ5R8hSqO as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪᇆ")	:	from Fu5bY3i9qa		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==bGzRdmOErkIylxALniq6(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪᇇ")	:	from PrAIsOzcUJ		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫᇈ")	:	from LLxy1itIZw		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫᇉ")	:	from FDXgRQWdmE		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫᇊ")	:	from zqxwGS0RVE			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IOHSz7YPF9WusGgUt1Dq(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ᇋ")	:	from X2ikalSeLH		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IOHSz7YPF9WusGgUt1Dq(u"࠭ࡍ࠴ࡗࠪᇌ")		:	from Sce6q5zwUj			import AtylB0o7GnY9ui1UQSqNdPL4r as lDt71RPxgnZs0LzHurJAdqU,wwinEbetVG3su1TD2L7NFOp as bHSQRo5vFEuWUw1978CLY,Y6xCT1m2lpbnKLJPZ5R8hSqO as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪᇍ")	:	from NdFX5QSV3L		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨᇎ")	:	from tiYMKpXwQd			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡐ࡝ࡈࡏࡍࡂࠩᇏ")	:	from x9hXV5TpjR			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==gDETKVh8mZe09Nd(u"ࠪࡔࡆࡔࡅࡕࠩᇐ")		:	from cZSK5HMeRw			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡖࡌࡉࡍࡏࠪᇑ")		:	from ZcfKHF79DV			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩᇒ"):	from bJxvjiPuw9		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩᇓ")	:	from G7GM8rJD5L		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==IO7k2hZXSz(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᇔ")	:	from n8RHJpFYok		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SE97R3Dpj6dPLweVKU(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠵ࠫᇕ")	:	from ocIxB1kEzR		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==BWfpRku7SsM6cbE0eG(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ᇖ"):	from W8pDvYTJXN		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ᇗ")	:	from XtYQV6UoLh		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡘࡎࡏࡇࡊࡄࠫᇘ")	:	from q0Y34fJ7Uc			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧᇙ")	:	from QQdkySvpmf		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨᇚ")	:	from BnFQtDGrve		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SE97R3Dpj6dPLweVKU(u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩᇛ")	:	from q9qglSBkTG		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡖࡌࡏࡆࡇࡔࠨᇜ")	:	from RPH2VIMztg			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡗ࡚ࡋ࡛ࡎࠨᇝ")		:	from ygrODsPR43			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==SIkwCEdJHTD9v1(u"࡚ࠪࡆࡘࡂࡐࡐࠪᇞ")	:	from GU5gDRVTpP			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==hPFcB6Uxmabj59Iq(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨᇟ"):	from OxXZUQmTly		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ᇠ")	:	from p917vUklSE		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧᇡ")	:	from cqd2Poybkf		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==BWfpRku7SsM6cbE0eG(u"࡚ࠧࡃࡔࡓ࡙࠭ᇢ")		:	from u9XB0pRhsC			import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩᇣ")	:	from QS6ZRAyXrc		import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	elif qCDt2dG9EZ6pXskxnMUK3cw==sH6BOz5wKRFcEg(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨᇤ"):	from jUrtF1V8fW	import PMKv9oB6gJZak as lDt71RPxgnZs0LzHurJAdqU,RsxrGI1pcyY3UXTSLiC as bHSQRo5vFEuWUw1978CLY,Z0BYJQghVL1v87CAem as o0wDANXvUE7fS2Z
	return lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z
def RDrfnwmMg8EblLCXFzBV0O6(QWXZ0cprsdRh7x8gzBtiFuY,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,showDialogs):
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,YQNd4wejLSAVJ6T(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨᇥ")+QWXZ0cprsdRh7x8gzBtiFuY+YQNd4wejLSAVJ6T(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᇦ")+str(u0K219wAgLr8TXDcVGsqQPtRkCH6ov)+RDwahqjPfbdyEiTtnLQu(u"ࠬࠦ࡝ࠨᇧ"))
	USk4nVycGqThQJ6u12daMIHxsoP = xSIYZduC9imekB7c0J6oOa82FVnNU()
	USk4nVycGqThQJ6u12daMIHxsoP.create(OODdgcrlh8KQo0A7M2eEvViwPqpkR,jwzOabysh0Z(u"๊࠭อำํࠤฬ๊ย็ࠢไัฺࠦวๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์่ࠦษ฻า๋ฬࠦำ้ใࠣฮอีรࠡ฻่่๏ฯࠠอๆหࠤฬ๊ๅๅใ้๋ࠣࠦวๅว้ฮึ์สࠨᇨ"))
	fri6g5k2WyC = EJgYdjbIiWe1apkQlZcR42(u"࠶࠶࠲࠵ᖴ")*EJgYdjbIiWe1apkQlZcR42(u"࠶࠶࠲࠵ᖴ")
	t78u1kQJWBNgl0Li2I = bGzRdmOErkIylxALniq6(u"࠷ᖵ")*fri6g5k2WyC
	import requests as xu5ndl3mkU2
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = xu5ndl3mkU2.get(QWXZ0cprsdRh7x8gzBtiFuY,stream=ndkUxG9LtewJ,headers=u0K219wAgLr8TXDcVGsqQPtRkCH6ov)
	tt2CTb8mA7 = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.close()
	Rsg41SD5myZ = bytes()
	if not tt2CTb8mA7:
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,hPFcB6Uxmabj59Iq(u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪᇩ"))
		USk4nVycGqThQJ6u12daMIHxsoP.close()
	else:
		if XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᇪ") not in list(tt2CTb8mA7.keys()): FFrPceqigmkoOyT = BewrUo9ANCa17G43Sn0LH5xh
		else: FFrPceqigmkoOyT = int(tt2CTb8mA7[aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᇫ")])
		FhNEObAMX75cP4mt3 = str(int(TzIj50KpohEOHx6CbZWqB(u"࠲࠲࠳࠴ᖷ")*FFrPceqigmkoOyT/fri6g5k2WyC)/zLjWeKu6JgNO7vocUD0Qpy(u"࠱࠱࠲࠳࠲࠵ᖶ"))
		Pa0dISCjrYKZL = int(FFrPceqigmkoOyT/t78u1kQJWBNgl0Li2I)+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		if oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪᇬ") in list(tt2CTb8mA7.keys()) and FFrPceqigmkoOyT>fri6g5k2WyC:
			mmG4zlbEF6Uwp = ndkUxG9LtewJ
			bbPy9BetzD2aw84p3URcGxMX = []
			L3kSz2KyfMqNG0OJojREnWCr = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠳࠳ᖸ")
			bbPy9BetzD2aw84p3URcGxMX.append(str(BewrUo9ANCa17G43Sn0LH5xh*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+gDETKVh8mZe09Nd(u"ࠫ࠲࠭ᇭ")+str(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+SE97R3Dpj6dPLweVKU(u"ࠬ࠳ࠧᇮ")+str(rgpY5VUqKbeFOCD9Nki2SmGvxEja*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(rgpY5VUqKbeFOCD9Nki2SmGvxEja*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+YQNd4wejLSAVJ6T(u"࠭࠭ࠨᇯ")+str(vUnJhT2NO8yirHcAmg*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(vUnJhT2NO8yirHcAmg*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+SIkwCEdJHTD9v1(u"ࠧ࠮ࠩᇰ")+str(kK7gj9HE462hADJbvr*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(kK7gj9HE462hADJbvr*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ࠯ࠪᇱ")+str(t19ZOVHA4CpwFKaeiubcMGvz(u"࠸ᖹ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠹ᖺ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+Js61GTdX5wzMurUqi7Z(u"ࠩ࠰ࠫᇲ")+str(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠻ᖻ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(aYH620Dh48GEsTFfOBSQ7r(u"࠶ᖽ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪ࠱ࠬᇳ")+str(aenpKvQCGVzhLXEdWiDIZ(u"࠽ᖼ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(aenpKvQCGVzhLXEdWiDIZ(u"࠹ᖿ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠲࠭ᇴ")+str(aYH620Dh48GEsTFfOBSQ7r(u"࠹ᖾ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(hPFcB6Uxmabj59Iq(u"࠼ᗁ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠳ࠧᇵ")+str(IO7k2hZXSz(u"࠼ᗀ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU))
			bbPy9BetzD2aw84p3URcGxMX.append(str(SIkwCEdJHTD9v1(u"࠾ᗂ")*FFrPceqigmkoOyT//L3kSz2KyfMqNG0OJojREnWCr)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࠭ࠨᇶ"))
			JE4mFio63wyGf9q1 = float(Pa0dISCjrYKZL)/L3kSz2KyfMqNG0OJojREnWCr
			UAiy5a9LEwkGnOlsZrmbSpQR = JE4mFio63wyGf9q1/int(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU+JE4mFio63wyGf9q1)
		else:
			mmG4zlbEF6Uwp = lvzrYTpcBaK
			L3kSz2KyfMqNG0OJojREnWCr = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			UAiy5a9LEwkGnOlsZrmbSpQR = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨᇷ")+str(mmG4zlbEF6Uwp)+TzIj50KpohEOHx6CbZWqB(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᇸ")+str(FFrPceqigmkoOyT)+RDwahqjPfbdyEiTtnLQu(u"ࠩࠣࡡࠬᇹ"))
		ruCEzOyVgmGt9WHI7BSofF6d8,E9k5lOchmdg6iUMJao3DS8vNbKBPe = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
		for xPrB341NbwAJdSR92zf in range(L3kSz2KyfMqNG0OJojREnWCr):
			HSNYwERMjzyxmrPku = u0K219wAgLr8TXDcVGsqQPtRkCH6ov.copy()
			if mmG4zlbEF6Uwp: HSNYwERMjzyxmrPku[Js61GTdX5wzMurUqi7Z(u"ࠪࡖࡦࡴࡧࡦࠩᇺ")] = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡧࡿࡴࡦࡵࡀࠫᇻ")+bbPy9BetzD2aw84p3URcGxMX[xPrB341NbwAJdSR92zf]
			mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = xu5ndl3mkU2.get(QWXZ0cprsdRh7x8gzBtiFuY,stream=ndkUxG9LtewJ,headers=HSNYwERMjzyxmrPku,timeout=qqw1upCsKM(u"࠹࠰࠱ᗃ"))
			for IIo6O8rR2aDcFClKwmBfytGnuH4p in mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.iter_content(chunk_size=t78u1kQJWBNgl0Li2I):
				if USk4nVycGqThQJ6u12daMIHxsoP.iscanceled():
					SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,gDETKVh8mZe09Nd(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬᇼ"))
					break
				ruCEzOyVgmGt9WHI7BSofF6d8 += UAiy5a9LEwkGnOlsZrmbSpQR
				Rsg41SD5myZ += IIo6O8rR2aDcFClKwmBfytGnuH4p
				if not E9k5lOchmdg6iUMJao3DS8vNbKBPe: E9k5lOchmdg6iUMJao3DS8vNbKBPe = len(IIo6O8rR2aDcFClKwmBfytGnuH4p)
				if FFrPceqigmkoOyT: TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,hPFcB6Uxmabj59Iq(u"࠱࠱࠲ᗄ")*ruCEzOyVgmGt9WHI7BSofF6d8//Pa0dISCjrYKZL,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᇽ"),str(zLjWeKu6JgNO7vocUD0Qpy(u"࠲࠲࠳࠲࠵ᗅ")*E9k5lOchmdg6iUMJao3DS8vNbKBPe*ruCEzOyVgmGt9WHI7BSofF6d8//t78u1kQJWBNgl0Li2I//zLjWeKu6JgNO7vocUD0Qpy(u"࠲࠲࠳࠲࠵ᗅ"))+BWfpRku7SsM6cbE0eG(u"ࠧࠡ࠱ࠣࠫᇾ")+FhNEObAMX75cP4mt3+qqw1upCsKM(u"ࠨࠢࡐࡆࠬᇿ"))
				else: TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,E9k5lOchmdg6iUMJao3DS8vNbKBPe*ruCEzOyVgmGt9WHI7BSofF6d8//t78u1kQJWBNgl0Li2I,qqw1upCsKM(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧሀ"),str(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳࠳࠴࠳࠶ᗆ")*E9k5lOchmdg6iUMJao3DS8vNbKBPe*ruCEzOyVgmGt9WHI7BSofF6d8//t78u1kQJWBNgl0Li2I//E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠳࠳࠴࠳࠶ᗆ"))+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࠤࡒࡈࠧሁ"))
			mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.close()
		USk4nVycGqThQJ6u12daMIHxsoP.close()
		if len(Rsg41SD5myZ)<FFrPceqigmkoOyT and FFrPceqigmkoOyT>BewrUo9ANCa17G43Sn0LH5xh:
			SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧሂ")+str(len(Rsg41SD5myZ)//fri6g5k2WyC)+TzIj50KpohEOHx6CbZWqB(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪሃ")+FhNEObAMX75cP4mt3+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠠࡎࡄࠣࡡࠬሄ"))
			WQOh7NoUEJuHgGK0pzTrktyeLjxMB = bP5mf0Mo2nz(sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬህ"),bGzRdmOErkIylxALniq6(u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨሆ"),gDETKVh8mZe09Nd(u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫሇ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,hPFcB6Uxmabj59Iq(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧለ")+str(len(Rsg41SD5myZ)//fri6g5k2WyC)+Js61GTdX5wzMurUqi7Z(u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪሉ")+FhNEObAMX75cP4mt3+SIkwCEdJHTD9v1(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧሊ"))
			if WQOh7NoUEJuHgGK0pzTrktyeLjxMB==rgpY5VUqKbeFOCD9Nki2SmGvxEja: Rsg41SD5myZ = RDrfnwmMg8EblLCXFzBV0O6(QWXZ0cprsdRh7x8gzBtiFuY,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,showDialogs)
			elif WQOh7NoUEJuHgGK0pzTrktyeLjxMB==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,qeG16a4pbSHziNVQ2uFXrs(u"࠭࠮࡝ࡶࡑࡳࡹࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡢࡥࡦࡩࡵࡺࡥࡥࠢࡤࡲࡩࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡨࠬላ"))
			else: return sCHVtMAvqirbQ4BUK3cgWo
			if not Rsg41SD5myZ: return sCHVtMAvqirbQ4BUK3cgWo
		else: SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫሌ")+FhNEObAMX75cP4mt3+qqw1upCsKM(u"ࠨࠢࡐࡆࠥࡣࠧል"))
	return Rsg41SD5myZ
def MGvEwsFnhOI5rPLoytjNVxui48RQc(Ll1m0nJoaAPvHsXqyRE):
	return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
def B1UysZq2WtOj(ip=sCHVtMAvqirbQ4BUK3cgWo):
	if Q1siCkTZyw.GEOLOCATION_DATA: return Q1siCkTZyw.GEOLOCATION_DATA
	bVdhLTmakwJH,AAegc4nriYPDjplE2FToBqG5xsWv,ZM8R9TH2Wkc0DiYn3dPE1BVzSGQu,feHTpJjtE9mqsGb7WNwkP,IEuaV1FwykoUCzHNAs4cLMDYf8,iVERZHcYk0l3DPByrAqe9Jf = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	ZvWwXBJxzk3Qi9uAHKTD8hY2 = bGzRdmOErkIylxALniq6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬሎ")+ip+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨሏ")
	u0K219wAgLr8TXDcVGsqQPtRkCH6ov = {hPFcB6Uxmabj59Iq(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨሐ"):sCHVtMAvqirbQ4BUK3cgWo}
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,SIkwCEdJHTD9v1(u"ࠬࡍࡅࡕࠩሑ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,sCHVtMAvqirbQ4BUK3cgWo,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩሒ"))
	if not mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		ZvWwXBJxzk3Qi9uAHKTD8hY2 = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲ࠰ࡥࡵ࡯࠮ࡤࡱࡰ࠳࡯ࡹ࡯࡯࠱ࠪሓ")+ip+aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡁࡩ࡭ࡪࡲࡤࡴ࠿ࡴࡹࡪࡸࡹ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠬࡤ࡫ࡷࡽ࠱ࡵࡦࡧࡵࡨࡸࠬሔ")
		mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,hPFcB6Uxmabj59Iq(u"ࠩࡊࡉ࡙࠭ሕ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,sCHVtMAvqirbQ4BUK3cgWo,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠵ࡲࡩ࠭ሖ"))
	if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		Sw0pOFoVhPeIxbl = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
		D0QYaVGsmb = Kdnrl9JHV0cFaGzC5bN.loads(Sw0pOFoVhPeIxbl)
		aN1dy2M5PO = list(D0QYaVGsmb.keys())
		if aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡮ࡶࠧሗ") in aN1dy2M5PO: ip = D0QYaVGsmb[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࡯ࡰࠨመ")]
		if t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩሙ") in aN1dy2M5PO: bVdhLTmakwJH = D0QYaVGsmb[IOHSz7YPF9WusGgUt1Dq(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪሚ")]
		if IO7k2hZXSz(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩማ") in aN1dy2M5PO: AAegc4nriYPDjplE2FToBqG5xsWv = D0QYaVGsmb[EJgYdjbIiWe1apkQlZcR42(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪሜ")]
		if jwzOabysh0Z(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩም") in aN1dy2M5PO: ZM8R9TH2Wkc0DiYn3dPE1BVzSGQu = D0QYaVGsmb[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪሞ")]
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬሟ") in aN1dy2M5PO: feHTpJjtE9mqsGb7WNwkP = D0QYaVGsmb[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ሠ")]
		if BWfpRku7SsM6cbE0eG(u"ࠧࡤ࡫ࡷࡽࠬሡ") in aN1dy2M5PO: IEuaV1FwykoUCzHNAs4cLMDYf8 = D0QYaVGsmb[RDwahqjPfbdyEiTtnLQu(u"ࠨࡥ࡬ࡸࡾ࠭ሢ")]
		if fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡴࡹࡪࡸࡹࠨሣ") in aN1dy2M5PO: ip = D0QYaVGsmb[EJgYdjbIiWe1apkQlZcR42(u"ࠪࡵࡺ࡫ࡲࡺࠩሤ")]
		if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩሥ") in aN1dy2M5PO: ZM8R9TH2Wkc0DiYn3dPE1BVzSGQu = D0QYaVGsmb[IOHSz7YPF9WusGgUt1Dq(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧࠪሦ")]
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪሧ") in aN1dy2M5PO: feHTpJjtE9mqsGb7WNwkP = D0QYaVGsmb[hPFcB6Uxmabj59Iq(u"ࠧࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨࠫረ")]
		if fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪሩ") in aN1dy2M5PO:
			iVERZHcYk0l3DPByrAqe9Jf = D0QYaVGsmb[IO7k2hZXSz(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫሪ")][gDETKVh8mZe09Nd(u"ࠪࡹࡹࡩࠧራ")]
			if iVERZHcYk0l3DPByrAqe9Jf[BewrUo9ANCa17G43Sn0LH5xh] not in [aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࠲࠭ሬ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࠱ࠧር")]: iVERZHcYk0l3DPByrAqe9Jf = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࠫࠨሮ")+iVERZHcYk0l3DPByrAqe9Jf
		if bGzRdmOErkIylxALniq6(u"ࠧࡰࡨࡩࡷࡪࡺࠧሯ") in aN1dy2M5PO:
			iVERZHcYk0l3DPByrAqe9Jf = D0QYaVGsmb[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡱࡩࡪࡸ࡫ࡴࠨሰ")]
			if iVERZHcYk0l3DPByrAqe9Jf>=qqw1upCsKM(u"࠳ᗇ"): iVERZHcYk0l3DPByrAqe9Jf = sH6BOz5wKRFcEg(u"ࠩ࠮ࠫሱ")+hDjf1Ubgq629nXlOvcFLH4Jw.strftime(Js61GTdX5wzMurUqi7Z(u"ࠥࠩࡍࡀࠥࡎࠤሲ"),hDjf1Ubgq629nXlOvcFLH4Jw.gmtime(iVERZHcYk0l3DPByrAqe9Jf))
			else: iVERZHcYk0l3DPByrAqe9Jf = hPFcB6Uxmabj59Iq(u"ࠫ࠲࠭ሳ")+hDjf1Ubgq629nXlOvcFLH4Jw.strftime(Js61GTdX5wzMurUqi7Z(u"ࠧࠫࡈ࠻ࠧࡐࠦሴ"),hDjf1Ubgq629nXlOvcFLH4Jw.gmtime(-iVERZHcYk0l3DPByrAqe9Jf))
	IxqLjtQYNM5znb8dO = ip+XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࠬࠨስ")+bVdhLTmakwJH+GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࠭ࠩሶ")+AAegc4nriYPDjplE2FToBqG5xsWv+aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࠮ࠪሷ")+feHTpJjtE9mqsGb7WNwkP+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠯ࠫሸ")+IEuaV1FwykoUCzHNAs4cLMDYf8+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࠰ࠬሹ")+iVERZHcYk0l3DPByrAqe9Jf
	IxqLjtQYNM5znb8dO = IxqLjtQYNM5znb8dO.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	if I5VKjrFL0Bk97: IxqLjtQYNM5znb8dO = IxqLjtQYNM5znb8dO.decode(BWfpRku7SsM6cbE0eG(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬሺ"))
	Q1siCkTZyw.GEOLOCATION_DATA = EEH4kBfGY0FuZUjeNn(IxqLjtQYNM5znb8dO)
	return Q1siCkTZyw.GEOLOCATION_DATA
def KwmOrR2yNXpGFiCv4fMthB5(xTOcwNCrnVRKWDHU):
	alqMXBCP0tj8rDAWREmH2OwYzLkSVZ,showDialogs = sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ
	if xTOcwNCrnVRKWDHU.count(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡥࠧሻ"))>=rgpY5VUqKbeFOCD9Nki2SmGvxEja:
		xTOcwNCrnVRKWDHU,alqMXBCP0tj8rDAWREmH2OwYzLkSVZ = xTOcwNCrnVRKWDHU.split(bGzRdmOErkIylxALniq6(u"࠭࡟ࠨሼ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		alqMXBCP0tj8rDAWREmH2OwYzLkSVZ = GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡠࠩሽ")+alqMXBCP0tj8rDAWREmH2OwYzLkSVZ
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ሾ") in alqMXBCP0tj8rDAWREmH2OwYzLkSVZ: showDialogs = lvzrYTpcBaK
		else: showDialogs = ndkUxG9LtewJ
	return xTOcwNCrnVRKWDHU,alqMXBCP0tj8rDAWREmH2OwYzLkSVZ,showDialogs
def uzmcSHYqpIliTL83r2F5():
	o8eVX1SApIPfu7kaUlmH2034c = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨሿ"))
	ICkdKFRWBru9A = BewrUo9ANCa17G43Sn0LH5xh
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(o8eVX1SApIPfu7kaUlmH2034c):
		for PaIF3ENgrM61XfTBD7xy8JjC in YYEXZsUWhf52vz7HLxc0qGJ.listdir(o8eVX1SApIPfu7kaUlmH2034c):
			if RDwahqjPfbdyEiTtnLQu(u"ࠪ࠲ࡵࡿ࡯ࠨቀ") in PaIF3ENgrM61XfTBD7xy8JjC: continue
			if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡤࡥࡰࡺࡥࡤࡧ࡭࡫࡟ࡠࠩቁ") in PaIF3ENgrM61XfTBD7xy8JjC: continue
			VI319xM5FmX = YYEXZsUWhf52vz7HLxc0qGJ.path.join(o8eVX1SApIPfu7kaUlmH2034c,PaIF3ENgrM61XfTBD7xy8JjC)
			lejLft4K0yH,JZD8Wzc1MGq9fgVFI2oENX5eT = kAxsioNSB6w5cDaKGlueOjXd(VI319xM5FmX)
			ICkdKFRWBru9A += lejLft4K0yH
	return ICkdKFRWBru9A
def fn3GEANaheOuW0IQ56(showDialogs):
	PPkjz4OX12 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪቂ"))
	LEo2z1dYGaDgFmUTRrsuyA = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡳࡵࡴࠪቃ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬቄ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪቅ"))
	tfvK8Arhz2,BrnSagYlO2Iq = PPkjz4OX12,LEo2z1dYGaDgFmUTRrsuyA
	dKpmt8hqkDAVrgnscb,SDh8EX2tbg0BwHpqecoGiF1fsP = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫቆ") not in str(Q1siCkTZyw.SEND_THESE_EVENTS):
		ZvWwXBJxzk3Qi9uAHKTD8hY2 = Q1siCkTZyw.SITESURLS[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪቇ")][vUnJhT2NO8yirHcAmg]
		wquHle38sKUCAMLSg = B1UysZq2WtOj()
		AAegc4nriYPDjplE2FToBqG5xsWv = wquHle38sKUCAMLSg.split(aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࠱࠭ቈ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		ICkdKFRWBru9A = uzmcSHYqpIliTL83r2F5()
		QDeqblFjHiWLB7om09XrUygT = {IO7k2hZXSz(u"ࠬࡻࡳࡦࡴࠪ቉"):Q1siCkTZyw.AV_CLIENT_IDS,RDwahqjPfbdyEiTtnLQu(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧቊ"):WHzJr591Ka8gRdbiLmBp0hT3S,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨቋ"):AAegc4nriYPDjplE2FToBqG5xsWv,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࡫ࡧࡷࠬቌ"):EpTiLePsOavwod3DxXcjJCq(ICkdKFRWBru9A)}
		mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡓࡓࡘ࡚ࠧቍ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,QDeqblFjHiWLB7om09XrUygT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ቎"))
		if not mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
			if PPkjz4OX12 in [sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠫࡓࡋࡗࠨ቏")]: tfvK8Arhz2 = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫቐ")
			elif PPkjz4OX12==t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡏࡍࡆࠪቑ"): tfvK8Arhz2 = gDETKVh8mZe09Nd(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ቒ")
		else:
			s5BdlmXUIwZ4tHFV76CLNRe2YqJp = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
			s5BdlmXUIwZ4tHFV76CLNRe2YqJp = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࡮࡬ࡷࡹ࠭ቓ"),s5BdlmXUIwZ4tHFV76CLNRe2YqJp)
			s5BdlmXUIwZ4tHFV76CLNRe2YqJp = sorted(s5BdlmXUIwZ4tHFV76CLNRe2YqJp,reverse=ndkUxG9LtewJ,key=lambda key: int(key[BewrUo9ANCa17G43Sn0LH5xh]))
			SDh8EX2tbg0BwHpqecoGiF1fsP,BrnSagYlO2Iq = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
			for yWAubmLh8ZqoKdjeYi6Flv0n,H0HGXDJgPdeERxAjSFLf,LZ1DGWKyolJb2NgvOzIR0 in s5BdlmXUIwZ4tHFV76CLNRe2YqJp:
				if yWAubmLh8ZqoKdjeYi6Flv0n==zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࠳ࠫቔ"):
					SDh8EX2tbg0BwHpqecoGiF1fsP += LZ1DGWKyolJb2NgvOzIR0+EJgYdjbIiWe1apkQlZcR42(u"ࠪ࠾࠿࠭ቕ")
					continue
				if BrnSagYlO2Iq: BrnSagYlO2Iq += slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+TzIj50KpohEOHx6CbZWqB(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪቖ")+B8alA5nvIhTxQ+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡢ࡮࡝ࡰࠪ቗")
				j96yD8JMVc4z = LZ1DGWKyolJb2NgvOzIR0.split(slFfrUIWCowaBA7tce3iZbj8xn)[BewrUo9ANCa17G43Sn0LH5xh]
				UUq3preLtbT8foQEaHWz5AGh = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪቘ") if H0HGXDJgPdeERxAjSFLf else sCHVtMAvqirbQ4BUK3cgWo
				BrnSagYlO2Iq += LZ1DGWKyolJb2NgvOzIR0.replace(j96yD8JMVc4z,F7Fe63KbGjaz2TcmCNHPdo5QiXO+j96yD8JMVc4z+UUq3preLtbT8foQEaHWz5AGh+B8alA5nvIhTxQ)+slFfrUIWCowaBA7tce3iZbj8xn
			BrnSagYlO2Iq = slFfrUIWCowaBA7tce3iZbj8xn+BrnSagYlO2Iq+aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࡝ࡰ࡟ࡲࠬ቙")
			SDh8EX2tbg0BwHpqecoGiF1fsP = SDh8EX2tbg0BwHpqecoGiF1fsP.strip(aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࠼࠽ࠫቚ"))
			dKpmt8hqkDAVrgnscb = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(IO7k2hZXSz(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬቛ"))
			if BrnSagYlO2Iq==LEo2z1dYGaDgFmUTRrsuyA and PPkjz4OX12 in [SE97R3Dpj6dPLweVKU(u"ࠪࡓࡑࡊࠧቜ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቝ")]: tfvK8Arhz2 = GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡕࡌࡅࠩ቞")
			else: tfvK8Arhz2 = sH6BOz5wKRFcEg(u"࠭ࡎࡆ࡙ࠪ቟")
			kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬበ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪቡ"),BrnSagYlO2Iq,IfAkw39UvaYWEDXLthFrbSzG)
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪቢ"),EpTiLePsOavwod3DxXcjJCq(JVAlZw9Nsnj))
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ባ"),SDh8EX2tbg0BwHpqecoGiF1fsP)
			oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(oVwa0kcqxj1e7mLplAfZdGT(u"࠹ᗈ")*SDh8EX2tbg0BwHpqecoGiF1fsP.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
			oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠶࠺ᗉ")*oo68qhpVEJgC7R.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
			oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠷࠹ᗊ")*oo68qhpVEJgC7R.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)).hexdigest()
			lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(qD1l8d3bQVN2uanhBLpyWTtcx)
			cc5Z1RvyW0JlMqzxKuA2BV9(qD1l8d3bQVN2uanhBLpyWTtcx,lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB,lvzrYTpcBaK,Js61GTdX5wzMurUqi7Z(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡡ࡬ࡨࡂ࠭ቤ")+str(int(oo68qhpVEJgC7R[XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠴ᗌ"):t19ZOVHA4CpwFKaeiubcMGvz(u"࠳࠵ᗍ")],qeG16a4pbSHziNVQ2uFXrs(u"࠴࠺ᗎ")))[:EJgYdjbIiWe1apkQlZcR42(u"࠹ᗋ")]+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠦ࠻ࠨብ"))
			lxGwZhDLdoySA1avUN5.close()
		g5thoWBkD2ZNKMAq4CaE = ndkUxG9LtewJ if SDh8EX2tbg0BwHpqecoGiF1fsP!=dKpmt8hqkDAVrgnscb else lvzrYTpcBaK
		if g5thoWBkD2ZNKMAq4CaE:
			y4tNcIOe5hUnVuE9CWQFqJ = Q1siCkTZyw.P56VUO0NuA8bq
			Q1siCkTZyw.DDx2Ff6SX9zNUMmGEc,Q1siCkTZyw.P56VUO0NuA8bq,Q1siCkTZyw.sIS7FqTadm3ZEJpg4G,Q1siCkTZyw.hc1vNqbTWYrBo69ynVau4QRHs,Q1siCkTZyw.avprivsnorestrict,Q1siCkTZyw.avprivslongperiod = MN3T7mznDkdF([sH6BOz5wKRFcEg(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧቦ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨቧ"),jwzOabysh0Z(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ቨ"),BWfpRku7SsM6cbE0eG(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪቩ"),gDETKVh8mZe09Nd(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘ࡯ࡱࡊࡖࡆࡘࡈ࡜ࠬቪ"),jwzOabysh0Z(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪቫ")])
			wwLpvumsUe = Q1siCkTZyw.P56VUO0NuA8bq
			if not y4tNcIOe5hUnVuE9CWQFqJ and wwLpvumsUe and t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪቬ") in Q1siCkTZyw.SEND_THESE_EVENTS:
				Q1siCkTZyw.SEND_THESE_EVENTS.remove(oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫቭ"))
				Q1siCkTZyw.SEND_THESE_EVENTS.append(EJgYdjbIiWe1apkQlZcR42(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩቮ"))
			elif y4tNcIOe5hUnVuE9CWQFqJ and not wwLpvumsUe and jwzOabysh0Z(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪቯ") in Q1siCkTZyw.SEND_THESE_EVENTS:
				Q1siCkTZyw.SEND_THESE_EVENTS.remove(hPFcB6Uxmabj59Iq(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫተ"))
				Q1siCkTZyw.SEND_THESE_EVENTS.append(YQNd4wejLSAVJ6T(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨቱ"))
			Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	if showDialogs:
		if tfvK8Arhz2 in [GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪቲ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫታ")]:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,TzIj50KpohEOHx6CbZWqB(u"࠭็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠิสห๋ฬࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦวๅำส์ฯืࠠศๆัหฺࠦศไࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆฦื้อใࠡ฻้ำ่࠭ቴ"))
		else:
			ctjhP4l8L5pbwqZuQo3VYr(SIkwCEdJHTD9v1(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ት"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫቶ"),BrnSagYlO2Iq,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪቷ"))
			tfvK8Arhz2 = bGzRdmOErkIylxALniq6(u"ࠪࡓࡑࡊࠧቸ")
	if tfvK8Arhz2!=PPkjz4OX12:
		fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩቹ"),tfvK8Arhz2)
		Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def dk5CWBPUzZ8vpuRNFjmQIysAc9hKeM(afQqnTxbUcPNXgrJlW4LsY,YYlzJnQkmVFXyK0CxGpIPeEchMZ8):
	import socket as j1W9U4Ekxs0cYo7Aw2fzdyVgnb6
	CceqGTzsMNIZL7 = j1W9U4Ekxs0cYo7Aw2fzdyVgnb6.socket(j1W9U4Ekxs0cYo7Aw2fzdyVgnb6.AF_INET,j1W9U4Ekxs0cYo7Aw2fzdyVgnb6.SOCK_STREAM)
	CceqGTzsMNIZL7.settimeout(vUnJhT2NO8yirHcAmg)
	try:
		ofLNbsZxdtEvC0gRM2r9khzTeV = hDjf1Ubgq629nXlOvcFLH4Jw.time()
		CceqGTzsMNIZL7.connect((afQqnTxbUcPNXgrJlW4LsY,YYlzJnQkmVFXyK0CxGpIPeEchMZ8))
		qpC2d7QYwEsVM4SxLnjGZOBbr95 = hDjf1Ubgq629nXlOvcFLH4Jw.time()
		DDZkNLtrFyew6IWbd7JlhjqQSO1 = round((qpC2d7QYwEsVM4SxLnjGZOBbr95-ofLNbsZxdtEvC0gRM2r9khzTeV)*gDETKVh8mZe09Nd(u"࠵࠵࠶࠰ᗏ"))
	except: DDZkNLtrFyew6IWbd7JlhjqQSO1 = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	CceqGTzsMNIZL7.close()
	return DDZkNLtrFyew6IWbd7JlhjqQSO1
def Hy2bntGarc7J(showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫቺ"))
	else: bR4jqNrpMesHt93OgGKi6WDVaQA = ndkUxG9LtewJ
	if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		for PaIF3ENgrM61XfTBD7xy8JjC in YYEXZsUWhf52vz7HLxc0qGJ.listdir(XX4rMRSnQdbZ1NJiKu8pOfvDla):
			if PaIF3ENgrM61XfTBD7xy8JjC.endswith(SE97R3Dpj6dPLweVKU(u"࠭࠮ࡥࡤࠪቻ")) and YQNd4wejLSAVJ6T(u"ࠧࡥࡣࡷࡥࠬቼ") in PaIF3ENgrM61XfTBD7xy8JjC:
				Km2Nn9TCXAu5Lt3FoBRHyxZ7P = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,PaIF3ENgrM61XfTBD7xy8JjC)
				lxGwZhDLdoySA1avUN5,Fy1DHCosVPbSNMnWl0RQaiLtxB = spTLJreC42Nlh9dInEKvyF7w(Km2Nn9TCXAu5Lt3FoBRHyxZ7P)
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(TzIj50KpohEOHx6CbZWqB(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫች"))
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧቾ"))
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭ቿ"))
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(SE97R3Dpj6dPLweVKU(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧኀ"))
				Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ኁ"))
				lxGwZhDLdoySA1avUN5.commit()
				lxGwZhDLdoySA1avUN5.close()
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,gDETKVh8mZe09Nd(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧኂ"))
	return
def YgJ3ybSlEOxXUL7m(ltoZ7jCi2KmrFqpeQTP4,IWhKALXd8Y,showDialogs):
	if ltoZ7jCi2KmrFqpeQTP4!=EctkVfa3Tr6PdbX9UJ2:
		if ltoZ7jCi2KmrFqpeQTP4==lbyqTk2FBWLnKOtICNRM9jpfxvh0GP: Q1siCkTZyw.ALLOW_DNS_FIX = ndkUxG9LtewJ
		elif ltoZ7jCi2KmrFqpeQTP4==VMB1l2JKvI: Q1siCkTZyw.ALLOW_DNS_FIX = lvzrYTpcBaK
		elif ltoZ7jCi2KmrFqpeQTP4==K3nC0rDSptmG: Q1siCkTZyw.ALLOW_DNS_FIX = ndkUxG9LtewJ
	if IWhKALXd8Y!=EctkVfa3Tr6PdbX9UJ2:
		if IWhKALXd8Y==lbyqTk2FBWLnKOtICNRM9jpfxvh0GP: Q1siCkTZyw.ALLOW_PROXY_FIX = ndkUxG9LtewJ
		elif IWhKALXd8Y==VMB1l2JKvI: Q1siCkTZyw.ALLOW_PROXY_FIX = lvzrYTpcBaK
		elif IWhKALXd8Y==K3nC0rDSptmG: Q1siCkTZyw.ALLOW_PROXY_FIX = ndkUxG9LtewJ
	if showDialogs!=EctkVfa3Tr6PdbX9UJ2:
		if showDialogs==lbyqTk2FBWLnKOtICNRM9jpfxvh0GP: Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX = ndkUxG9LtewJ
		elif showDialogs==VMB1l2JKvI: Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX = lvzrYTpcBaK
		elif showDialogs==K3nC0rDSptmG: Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX = ndkUxG9LtewJ
	return
def HzIGjJ2lDb94ONgKqamZWMoFeXkc(website,ggkGX81L20zpEWumhUqANo,yJX3ja4MZI=ZetiSjBQ9bTnF23pzsmXcyWuK):
	hx9lGf8EAQtKRD = t19ZOVHA4CpwFKaeiubcMGvz(u"࠶࠶ᗐ")
	ooxtG5I0rCuaW9RS = [sH6BOz5wKRFcEg(u"࠷ᗑ"),sH6BOz5wKRFcEg(u"࠷ᗑ"),sH6BOz5wKRFcEg(u"࠷ᗑ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠱࠱ᗒ"),IO7k2hZXSz(u"࠶ᗓ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠱࠱ᗒ"),sH6BOz5wKRFcEg(u"࠷ᗑ"),sH6BOz5wKRFcEg(u"࠷ᗑ"),sH6BOz5wKRFcEg(u"࠷ᗑ"),IO7k2hZXSz(u"࠶ᗓ")]
	dIUhMJ0WOBlwAivrZpPfGcC = []
	sA4CdhVLuZblQ1XNqcky = [YQNd4wejLSAVJ6T(u"࠲ᗔ")]*hx9lGf8EAQtKRD
	Vit8HCqSxFaLoWfJZ5 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡥ࡫ࡦࡸࠬኃ"),TzIj50KpohEOHx6CbZWqB(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪኄ"))
	for Qyg5b3kGYOvisjI2KareRLS in list(Vit8HCqSxFaLoWfJZ5.keys()):
		if website not in Qyg5b3kGYOvisjI2KareRLS: continue
		oT2iHwjfBx0FPX5ZCph9aWs38,hLkHeuK7dR4TGVJFgM = Qyg5b3kGYOvisjI2KareRLS.split(RDwahqjPfbdyEiTtnLQu(u"ࠩࡢࡣࠬኅ"))
		sA4CdhVLuZblQ1XNqcky[int(hLkHeuK7dR4TGVJFgM)] = Vit8HCqSxFaLoWfJZ5[Qyg5b3kGYOvisjI2KareRLS]
	for dAukY5fr20HZDntgKLi in range(hx9lGf8EAQtKRD):
		if dAukY5fr20HZDntgKLi in Q1siCkTZyw.BADSCRAPERS+ggkGX81L20zpEWumhUqANo: continue
		if dAukY5fr20HZDntgKLi==yJX3ja4MZI: sA4CdhVLuZblQ1XNqcky[dAukY5fr20HZDntgKLi] = sA4CdhVLuZblQ1XNqcky[dAukY5fr20HZDntgKLi]+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠴ᗕ")
		if sA4CdhVLuZblQ1XNqcky[dAukY5fr20HZDntgKLi]<zLjWeKu6JgNO7vocUD0Qpy(u"࠷ᗖ"): dIUhMJ0WOBlwAivrZpPfGcC += [dAukY5fr20HZDntgKLi]*ooxtG5I0rCuaW9RS[dAukY5fr20HZDntgKLi]
	if not dIUhMJ0WOBlwAivrZpPfGcC:
		for dAukY5fr20HZDntgKLi in range(hx9lGf8EAQtKRD):
			sA4CdhVLuZblQ1XNqcky[dAukY5fr20HZDntgKLi] = aYH620Dh48GEsTFfOBSQ7r(u"࠵ᗗ")
			if dAukY5fr20HZDntgKLi in Q1siCkTZyw.BADSCRAPERS+ggkGX81L20zpEWumhUqANo: continue
			dIUhMJ0WOBlwAivrZpPfGcC += [dAukY5fr20HZDntgKLi]*ooxtG5I0rCuaW9RS[dAukY5fr20HZDntgKLi]
	for dAukY5fr20HZDntgKLi in Q1siCkTZyw.BADSCRAPERS: sA4CdhVLuZblQ1XNqcky[dAukY5fr20HZDntgKLi] = aenpKvQCGVzhLXEdWiDIZ(u"࠿࠹࠺࠻ᗘ")
	o18f9ZFbQvjtBsiDCgp7 = []
	for dAukY5fr20HZDntgKLi in range(hx9lGf8EAQtKRD): o18f9ZFbQvjtBsiDCgp7.append(website+IOHSz7YPF9WusGgUt1Dq(u"ࠪࡣࡤ࠭ኆ")+str(dAukY5fr20HZDntgKLi))
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ኇ"),o18f9ZFbQvjtBsiDCgp7,sA4CdhVLuZblQ1XNqcky,qYPWJUCGENXH*qeG16a4pbSHziNVQ2uFXrs(u"࠵ᗙ"),ndkUxG9LtewJ)
	return dIUhMJ0WOBlwAivrZpPfGcC
def dETqR0pCNwmv4PWuUOBt5rXcAh(CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ltE6Cgu1AyjR8Dde=sCHVtMAvqirbQ4BUK3cgWo,j7CADXI1yWt90Gc52HrsUhKeN=sCHVtMAvqirbQ4BUK3cgWo,ggkGX81L20zpEWumhUqANo=[]):
	website = zVbp6yjdF3qKkTvhDsJX9fgMceCuxt.split(GVurlv8HeoXEzPRiQB7Ty(u"ࠬ࠳ࠧኈ"))[BewrUo9ANCa17G43Sn0LH5xh]
	S3kGz4CgeJp6yOBsPD2KTw = HzIGjJ2lDb94ONgKqamZWMoFeXkc(website,ggkGX81L20zpEWumhUqANo)
	PDwk9XvU7CeV = []
	if website==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ኉"):
		if BewrUo9ANCa17G43Sn0LH5xh in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [BewrUo9ANCa17G43Sn0LH5xh]
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if rgpY5VUqKbeFOCD9Nki2SmGvxEja in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		if vUnJhT2NO8yirHcAmg in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [vUnJhT2NO8yirHcAmg]*Js61GTdX5wzMurUqi7Z(u"࠲࠲ᗚ")
		if kK7gj9HE462hADJbvr in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [kK7gj9HE462hADJbvr]*tBMCpcY2vUV1dEjZ7PDG
		if tBMCpcY2vUV1dEjZ7PDG in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [tBMCpcY2vUV1dEjZ7PDG]*oVwa0kcqxj1e7mLplAfZdGT(u"࠳࠳ᗛ")
		if Js61GTdX5wzMurUqi7Z(u"࠹ᗜ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [Js61GTdX5wzMurUqi7Z(u"࠹ᗜ")]
		if sH6BOz5wKRFcEg(u"࠻ᗝ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [sH6BOz5wKRFcEg(u"࠻ᗝ")]
	elif website==gDETKVh8mZe09Nd(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩኊ"):
		if vUnJhT2NO8yirHcAmg in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [vUnJhT2NO8yirHcAmg]*qeG16a4pbSHziNVQ2uFXrs(u"࠶࠶ᗞ")
	elif website==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫኋ"):
		if kK7gj9HE462hADJbvr in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [kK7gj9HE462hADJbvr]*tBMCpcY2vUV1dEjZ7PDG
		if tBMCpcY2vUV1dEjZ7PDG in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [tBMCpcY2vUV1dEjZ7PDG]*E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠷࠰ᗟ")
	elif website==SIkwCEdJHTD9v1(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪኌ"):
		if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠹ᗠ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠹ᗠ")]*Js61GTdX5wzMurUqi7Z(u"࠲࠲ᗡ")
	elif website==gDETKVh8mZe09Nd(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫኍ"):
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if tBMCpcY2vUV1dEjZ7PDG in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [tBMCpcY2vUV1dEjZ7PDG]*BWfpRku7SsM6cbE0eG(u"࠳࠳ᗢ")
	elif website==SIkwCEdJHTD9v1(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪ኎"):
		if kK7gj9HE462hADJbvr in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [kK7gj9HE462hADJbvr]*tBMCpcY2vUV1dEjZ7PDG
	elif website==TzIj50KpohEOHx6CbZWqB(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭኏"):
		if tBMCpcY2vUV1dEjZ7PDG in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [tBMCpcY2vUV1dEjZ7PDG]*qqw1upCsKM(u"࠴࠴ᗣ")
		if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠺ᗤ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠺ᗤ")]
		if jwzOabysh0Z(u"࠼ᗥ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [jwzOabysh0Z(u"࠼ᗥ")]
		if TzIj50KpohEOHx6CbZWqB(u"࠾ᗦ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [TzIj50KpohEOHx6CbZWqB(u"࠾ᗦ")]
	elif website==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨነ"):
		if aenpKvQCGVzhLXEdWiDIZ(u"࠶ᗧ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [aenpKvQCGVzhLXEdWiDIZ(u"࠶ᗧ")]
		if Js61GTdX5wzMurUqi7Z(u"࠸ᗨ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [Js61GTdX5wzMurUqi7Z(u"࠸ᗨ")]
	elif website==zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩኑ"):
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if kK7gj9HE462hADJbvr in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [kK7gj9HE462hADJbvr]*tBMCpcY2vUV1dEjZ7PDG
		if tBMCpcY2vUV1dEjZ7PDG in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [tBMCpcY2vUV1dEjZ7PDG]*IOHSz7YPF9WusGgUt1Dq(u"࠳࠳ᗩ")
		if bGzRdmOErkIylxALniq6(u"࠹ᗪ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [bGzRdmOErkIylxALniq6(u"࠹ᗪ")]
		if GVurlv8HeoXEzPRiQB7Ty(u"࠻ᗫ") in S3kGz4CgeJp6yOBsPD2KTw: PDwk9XvU7CeV += [GVurlv8HeoXEzPRiQB7Ty(u"࠻ᗫ")]
	if PDwk9XvU7CeV: S3kGz4CgeJp6yOBsPD2KTw = PDwk9XvU7CeV
	if S3kGz4CgeJp6yOBsPD2KTw:
		CfwlNGaUxp9FeVE = VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.sample(S3kGz4CgeJp6yOBsPD2KTw,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
	else: CfwlNGaUxp9FeVE = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	yQoAmM9VEn5WBUzbIcjLDNdHXqewF = YQNd4wejLSAVJ6T(u"ࠨีํีๆืࠠาไ่ࠤࠬኒ")+str(CfwlNGaUxp9FeVE)
	SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+GVurlv8HeoXEzPRiQB7Ty(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ና")+str(CfwlNGaUxp9FeVE)+fvYGxnZNUiyP4HJkMIoS25(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪኔ")+str(ltE6Cgu1AyjR8Dde)+IO7k2hZXSz(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬን")+j7CADXI1yWt90Gc52HrsUhKeN+aenpKvQCGVzhLXEdWiDIZ(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኖ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+Js61GTdX5wzMurUqi7Z(u"࠭ࠠ࡞࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫኗ")+vrEJRkchKxtDNiqO1b79mL5eT+jwzOabysh0Z(u"ࠧࠡ࡟ࠪኘ"))
	update = ndkUxG9LtewJ
	if CfwlNGaUxp9FeVE==BewrUo9ANCa17G43Sn0LH5xh:
		scraperserver = SE97R3Dpj6dPLweVKU(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠵ࠬኙ")
		EufOnyTp13jCeQk2bX = gDETKVh8mZe09Nd(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠱࠶࠲ࡧ࠶࠷࡬࠱࠮ࡥ࠸࠼ࡦ࠳࠴࠱࠴࠴࠱ࡦࡧ࠸࠵࠯ࡨ࠽࠷࠹ࡣࡢࡨ࠻࠹࠽࠹࠴ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫኚ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+RDwahqjPfbdyEiTtnLQu(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኛ")+EufOnyTp13jCeQk2bX+aenpKvQCGVzhLXEdWiDIZ(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫኜ")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		scraperserver = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠳ࠩኝ")
		EufOnyTp13jCeQk2bX = XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨኞ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+sH6BOz5wKRFcEg(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧኟ")+EufOnyTp13jCeQk2bX+jwzOabysh0Z(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨአ")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==rgpY5VUqKbeFOCD9Nki2SmGvxEja:
		scraperserver = SIkwCEdJHTD9v1(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ኡ")
		EufOnyTp13jCeQk2bX = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࡀ࡭ࡱࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩኢ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+YQNd4wejLSAVJ6T(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫኣ")+EufOnyTp13jCeQk2bX+qeG16a4pbSHziNVQ2uFXrs(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬኤ")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==vUnJhT2NO8yirHcAmg:
		scraperserver = EJgYdjbIiWe1apkQlZcR42(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨእ")
		rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT.replace(bGzRdmOErkIylxALniq6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩኦ"),qqw1upCsKM(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩኧ"))
		Ow0mUS9ZFyzuian = sH6BOz5wKRFcEg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴࡪࡻࡰ࠯ࡥࡲࡱ࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠫࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡋࡧ࡬ࡴࡧࠩࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰࠫࡻࡲ࡭࠿ࠪከ")+IgCGzHw45TJ7PeuO1EKl(rdQ5tOIzuelfvcYbNsM)
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡋࡊ࡚ࠧኩ"),Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==kK7gj9HE462hADJbvr:
		scraperserver = fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫኪ")
		Ow0mUS9ZFyzuian = YQNd4wejLSAVJ6T(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵ࠰ࡦࡳࡲ࠵࠿ࡵࡱ࡮ࡩࡳࡃࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠧࡲࡵࡳࡽࡿࡃࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡹࡷࡲ࠽ࠨካ")+IgCGzHw45TJ7PeuO1EKl(vrEJRkchKxtDNiqO1b79mL5eT)
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡇࡆࡖࠪኬ"),Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
		try:
			vBIjcfMhKJyYbtRlXEnH719Nuqpds8.content = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡥ࡫ࡦࡸࠬክ"),vBIjcfMhKJyYbtRlXEnH719Nuqpds8.content)
			vBIjcfMhKJyYbtRlXEnH719Nuqpds8.content = vBIjcfMhKJyYbtRlXEnH719Nuqpds8.content[jwzOabysh0Z(u"ࠨࡴࡨࡷࡺࡲࡴࠨኮ")]
		except: pass
	elif CfwlNGaUxp9FeVE==tBMCpcY2vUV1dEjZ7PDG:
		scraperserver = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠱ࠨኯ")
		EufOnyTp13jCeQk2bX = zLjWeKu6JgNO7vocUD0Qpy(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡋࡏࠪࡧࡸ࡯ࡸࡵࡨࡶࡂࡌࡡ࡭ࡵࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨኰ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+sH6BOz5wKRFcEg(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ኱")+EufOnyTp13jCeQk2bX+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬኲ")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==BWfpRku7SsM6cbE0eG(u"࠻ᗬ"):
		scraperserver = YQNd4wejLSAVJ6T(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠳ࠪኳ")
		EufOnyTp13jCeQk2bX = hPFcB6Uxmabj59Iq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫኴ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+YQNd4wejLSAVJ6T(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨኵ")+EufOnyTp13jCeQk2bX+EJgYdjbIiWe1apkQlZcR42(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ኶")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==RDwahqjPfbdyEiTtnLQu(u"࠽ᗭ"):
		scraperserver = IOHSz7YPF9WusGgUt1Dq(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠸ࠧ኷")
		EufOnyTp13jCeQk2bX = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨኸ")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+YQNd4wejLSAVJ6T(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬኹ")+EufOnyTp13jCeQk2bX+EJgYdjbIiWe1apkQlZcR42(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ኺ")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠸ᗮ"):
		scraperserver = jwzOabysh0Z(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠶ࠫኻ")
		Ow0mUS9ZFyzuian = RDwahqjPfbdyEiTtnLQu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠯ࡷ࠳࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠦࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩኼ")+IgCGzHw45TJ7PeuO1EKl(vrEJRkchKxtDNiqO1b79mL5eT)
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(Js61GTdX5wzMurUqi7Z(u"ࠩࡊࡉ࡙࠭ኽ"),Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	elif CfwlNGaUxp9FeVE==t19ZOVHA4CpwFKaeiubcMGvz(u"࠺ᗯ"):
		scraperserver = sH6BOz5wKRFcEg(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠳ࠩኾ")
		EufOnyTp13jCeQk2bX = oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡸࡥࡵࡷࡵࡲࡤࡶࡡࡨࡧࡢࡷࡴࡻࡲࡤࡧࡀࡸࡷࡻࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬ኿")
		Ow0mUS9ZFyzuian = vrEJRkchKxtDNiqO1b79mL5eT+qeG16a4pbSHziNVQ2uFXrs(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዀ")+EufOnyTp13jCeQk2bX+TzIj50KpohEOHx6CbZWqB(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭዁")
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,Ow0mUS9ZFyzuian,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,lvzrYTpcBaK,lvzrYTpcBaK)
	else:
		scraperserver,Ow0mUS9ZFyzuian = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = Rxc41oNqDF()
		update = lvzrYTpcBaK
	ppGgAy7uPqUZ = (qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡷࡧࡵ࡭࡫ࡿ࠮ࡩࡶࡰࡰࡄࡸࡥࡥ࡫ࡵࡩࡨࡺ࠽ࠨዂ") in vrEJRkchKxtDNiqO1b79mL5eT)
	if ppGgAy7uPqUZ: vBIjcfMhKJyYbtRlXEnH719Nuqpds8.succeeded = lvzrYTpcBaK
	if update and not vBIjcfMhKJyYbtRlXEnH719Nuqpds8.succeeded:
		HzIGjJ2lDb94ONgKqamZWMoFeXkc(website,[],CfwlNGaUxp9FeVE)
		if len(list(set(S3kGz4CgeJp6yOBsPD2KTw)))>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"ࠨๆ็วุ็ࠠิ์ิๅึࠦๅฺษ็ะฮࠦวๅฯฯฬࠥืโๆࠢࠪዃ")+str(CfwlNGaUxp9FeVE)+jwzOabysh0Z(u"ࠩࠣๅู๊ࠠโ์ࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠠ࠯࠰๋้ࠣࠦสา์าࠤ๊ำว้ๆฬࠤฯาว้ิࠣห้ำฬษ่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦำ๋ำไี๋ࠥฮหๆไࠤฤࠧࠧዄ"))
			if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				ggkGX81L20zpEWumhUqANo.append(CfwlNGaUxp9FeVE)
				vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = dETqR0pCNwmv4PWuUOBt5rXcAh(CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN,ggkGX81L20zpEWumhUqANo)
				return vBIjcfMhKJyYbtRlXEnH719Nuqpds8
	vBIjcfMhKJyYbtRlXEnH719Nuqpds8.scrapernumber = str(CfwlNGaUxp9FeVE)
	scraperserver = scraperserver+aYH620Dh48GEsTFfOBSQ7r(u"ࠪࠤ࠿ࠦࠧዅ")+str(CfwlNGaUxp9FeVE)
	vBIjcfMhKJyYbtRlXEnH719Nuqpds8.scraperserver = scraperserver
	vBIjcfMhKJyYbtRlXEnH719Nuqpds8.scraperurl = Ow0mUS9ZFyzuian
	if vBIjcfMhKJyYbtRlXEnH719Nuqpds8.succeeded:
		SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ዆")+scraperserver+IOHSz7YPF9WusGgUt1Dq(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ዇")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+IO7k2hZXSz(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬወ")+vrEJRkchKxtDNiqO1b79mL5eT+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࠡ࡟ࠪዉ"))
		iRaHzNpJhSx6ZnCfrvD7j93lks(fvYGxnZNUiyP4HJkMIoS25(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪዊ"),yQoAmM9VEn5WBUzbIcjLDNdHXqewF,hDjf1Ubgq629nXlOvcFLH4Jw=wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠳࠳࠴࠵ᗰ"))
	else:
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ዋ")+scraperserver+SIkwCEdJHTD9v1(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪዌ")+str(vBIjcfMhKJyYbtRlXEnH719Nuqpds8.code)+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ው")+vBIjcfMhKJyYbtRlXEnH719Nuqpds8.reason+IOHSz7YPF9WusGgUt1Dq(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዎ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+BWfpRku7SsM6cbE0eG(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬዏ")+vrEJRkchKxtDNiqO1b79mL5eT+aenpKvQCGVzhLXEdWiDIZ(u"ࠧࠡ࡟ࠪዐ"))
		iRaHzNpJhSx6ZnCfrvD7j93lks(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨใื่ฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪዑ"),yQoAmM9VEn5WBUzbIcjLDNdHXqewF,hDjf1Ubgq629nXlOvcFLH4Jw=BWfpRku7SsM6cbE0eG(u"࠴࠴࠵࠶ᗱ"))
	return vBIjcfMhKJyYbtRlXEnH719Nuqpds8
def OXZtmCgx20(K6SYhoTVCnIFyEe8zL4X2,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt):
	if not gWlmUqwV3YrIT2XNPxQCisBHSDG9 or isinstance(gWlmUqwV3YrIT2XNPxQCisBHSDG9,dict): CXTZu2YvNpEPkinLf8Ohlm3Rg = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡊࡉ࡙࠭ዒ")
	else:
		CXTZu2YvNpEPkinLf8Ohlm3Rg = gDETKVh8mZe09Nd(u"ࠪࡔࡔ࡙ࡔࠨዓ")
		gWlmUqwV3YrIT2XNPxQCisBHSDG9 = mSeoVfgRpNF9PKrJ(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
		I796Ixs4TAZF,gWlmUqwV3YrIT2XNPxQCisBHSDG9 = muXAzTa365Mjklef1ZP7JiWrIR(gWlmUqwV3YrIT2XNPxQCisBHSDG9)
	mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = ttRBeVWLbpMzNQO75Zox4PXu8EGg(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,ndkUxG9LtewJ,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt)
	cIy4z8xCUt7j5MhPZO = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
	cIy4z8xCUt7j5MhPZO = str(cIy4z8xCUt7j5MhPZO)
	return cIy4z8xCUt7j5MhPZO
def ZZAphuVI2C69Mt3NqTyJ1bkL(ZvWwXBJxzk3Qi9uAHKTD8hY2):
	RzHSucpgDWKiFlPaAIbjnm2Ets3q = ZvWwXBJxzk3Qi9uAHKTD8hY2.split(sH6BOz5wKRFcEg(u"ࠫࢁࢂࠧዔ"))
	vrEJRkchKxtDNiqO1b79mL5eT,iBZOl3bVjWPufr0JvxphG5kIzgcF2U,aapYv0lK3Sr2COEJqwL,dgoN8FJ0VaPSybR = RzHSucpgDWKiFlPaAIbjnm2Ets3q[BewrUo9ANCa17G43Sn0LH5xh],ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ndkUxG9LtewJ
	for sNmyDVjHLfuhtoOdx0FZgWcYq9Al in RzHSucpgDWKiFlPaAIbjnm2Ets3q:
		if IOHSz7YPF9WusGgUt1Dq(u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪዕ") in sNmyDVjHLfuhtoOdx0FZgWcYq9Al: iBZOl3bVjWPufr0JvxphG5kIzgcF2U = sNmyDVjHLfuhtoOdx0FZgWcYq9Al[qeG16a4pbSHziNVQ2uFXrs(u"࠵࠶ᗲ"):]
		elif YQNd4wejLSAVJ6T(u"࠭ࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩዖ") in sNmyDVjHLfuhtoOdx0FZgWcYq9Al: aapYv0lK3Sr2COEJqwL = sNmyDVjHLfuhtoOdx0FZgWcYq9Al[SE97R3Dpj6dPLweVKU(u"࠾ᗳ"):]
		elif EJgYdjbIiWe1apkQlZcR42(u"ࠧࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ዗") in sNmyDVjHLfuhtoOdx0FZgWcYq9Al: dgoN8FJ0VaPSybR = lvzrYTpcBaK
	return vrEJRkchKxtDNiqO1b79mL5eT,iBZOl3bVjWPufr0JvxphG5kIzgcF2U,aapYv0lK3Sr2COEJqwL,dgoN8FJ0VaPSybR
def sR7ur2eYBtTXPKqLWHp1jFbcwV(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,LL6CcFwo43D5aXjIzBUmJkuv,luD2keMTH4RC1dfz6BaItjswxiLp8h,qqItjsdrW0X9a,u0K219wAgLr8TXDcVGsqQPtRkCH6ov=sCHVtMAvqirbQ4BUK3cgWo):
	vSI7i2L8hyrxlkcbn = GABnmSFOwtsu37(ZvWwXBJxzk3Qi9uAHKTD8hY2,hPFcB6Uxmabj59Iq(u"ࠨࡷࡵࡰࠬዘ"))
	EETAMfnVhl84qv = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫዙ")+LL6CcFwo43D5aXjIzBUmJkuv)
	if vSI7i2L8hyrxlkcbn==EETAMfnVhl84qv: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(TzIj50KpohEOHx6CbZWqB(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬዚ")+LL6CcFwo43D5aXjIzBUmJkuv,sCHVtMAvqirbQ4BUK3cgWo)
	if EETAMfnVhl84qv: rdQ5tOIzuelfvcYbNsM = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(vSI7i2L8hyrxlkcbn,EETAMfnVhl84qv)
	else:
		rdQ5tOIzuelfvcYbNsM = ZvWwXBJxzk3Qi9uAHKTD8hY2
		EETAMfnVhl84qv = vSI7i2L8hyrxlkcbn
	GGySQr6d3Tn7iLDkXAINbF2M = ttRBeVWLbpMzNQO75Zox4PXu8EGg(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨዛ"))
	cIy4z8xCUt7j5MhPZO = GGySQr6d3Tn7iLDkXAINbF2M.content
	if I5VKjrFL0Bk97:
		try: cIy4z8xCUt7j5MhPZO = cIy4z8xCUt7j5MhPZO.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,Js61GTdX5wzMurUqi7Z(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬዜ"))
		except: pass
	if not GGySQr6d3Tn7iLDkXAINbF2M.succeeded or qqItjsdrW0X9a not in cIy4z8xCUt7j5MhPZO:
		luD2keMTH4RC1dfz6BaItjswxiLp8h = luD2keMTH4RC1dfz6BaItjswxiLp8h.replace(AAh0X3OCacr4HpifRGLZKT,TzIj50KpohEOHx6CbZWqB(u"࠭ࠫࠨዝ"))
		vrEJRkchKxtDNiqO1b79mL5eT = sH6BOz5wKRFcEg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬዞ")+luD2keMTH4RC1dfz6BaItjswxiLp8h
		HSNYwERMjzyxmrPku = {GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬዟ"):sCHVtMAvqirbQ4BUK3cgWo}
		CxP3d82yUTnMa = ttRBeVWLbpMzNQO75Zox4PXu8EGg(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ዠ"))
		if CxP3d82yUTnMa.succeeded:
			cIy4z8xCUt7j5MhPZO = CxP3d82yUTnMa.content
			if I5VKjrFL0Bk97:
				try: cIy4z8xCUt7j5MhPZO = cIy4z8xCUt7j5MhPZO.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,IO7k2hZXSz(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪዡ"))
				except: pass
			PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬዢ"),cIy4z8xCUt7j5MhPZO,fNntYJW45mEFSdRX8g.DOTALL)
			qqzNauMAd3iIcgte = [EETAMfnVhl84qv]
			Fc4jm5Ce1qzHpTN9n0RWdh3QJDb = [XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡧࡰ࡬ࠩዣ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ዤ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨዥ"),sH6BOz5wKRFcEg(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩዦ"),jwzOabysh0Z(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫዧ"),RDwahqjPfbdyEiTtnLQu(u"ࠪࡴ࡭ࡶࠧየ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡦࡺ࡬ࡢࡳࠪዩ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪዪ"),qqw1upCsKM(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭ያ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩዬ"),SE97R3Dpj6dPLweVKU(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪይ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫዮ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭ዯ"),sH6BOz5wKRFcEg(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭ደ"),BWfpRku7SsM6cbE0eG(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩዱ"),hPFcB6Uxmabj59Iq(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩዲ")]
			for yWUkt8lwbPq3QcrBZKmedxN6 in PXFtqmw5lBGQNa0IV8:
				if any(value in yWUkt8lwbPq3QcrBZKmedxN6 for value in Fc4jm5Ce1qzHpTN9n0RWdh3QJDb): continue
				EETAMfnVhl84qv = GABnmSFOwtsu37(yWUkt8lwbPq3QcrBZKmedxN6,YQNd4wejLSAVJ6T(u"ࠧࡶࡴ࡯ࠫዳ"))
				if EETAMfnVhl84qv in qqzNauMAd3iIcgte: continue
				if len(qqzNauMAd3iIcgte)==jwzOabysh0Z(u"࠿ᗴ"):
					SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨዴ")+LL6CcFwo43D5aXjIzBUmJkuv+hPFcB6Uxmabj59Iq(u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧድ")+vSI7i2L8hyrxlkcbn+jwzOabysh0Z(u"ࠪࠤࡢ࠭ዶ"))
					fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭ዷ")+LL6CcFwo43D5aXjIzBUmJkuv,sCHVtMAvqirbQ4BUK3cgWo)
					break
				qqzNauMAd3iIcgte.append(EETAMfnVhl84qv)
				rdQ5tOIzuelfvcYbNsM = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(vSI7i2L8hyrxlkcbn,EETAMfnVhl84qv)
				GGySQr6d3Tn7iLDkXAINbF2M = ttRBeVWLbpMzNQO75Zox4PXu8EGg(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩዸ"))
				cIy4z8xCUt7j5MhPZO = GGySQr6d3Tn7iLDkXAINbF2M.content
				if GGySQr6d3Tn7iLDkXAINbF2M.succeeded and qqItjsdrW0X9a in cIy4z8xCUt7j5MhPZO:
					SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SIkwCEdJHTD9v1(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ዹ")+LL6CcFwo43D5aXjIzBUmJkuv+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭ዺ")+EETAMfnVhl84qv+aYH620Dh48GEsTFfOBSQ7r(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ዻ")+vSI7i2L8hyrxlkcbn+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࠣࡡࠬዼ"))
					fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(gDETKVh8mZe09Nd(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬዽ")+LL6CcFwo43D5aXjIzBUmJkuv,EETAMfnVhl84qv)
					break
	return EETAMfnVhl84qv,rdQ5tOIzuelfvcYbNsM,GGySQr6d3Tn7iLDkXAINbF2M
def g7k6hjSBrX4oOElJW59c2bUZpMquw(TqNvzBxf1KpPDg3SRA4yj2mwcVF):
	yylp3OPwkxS4csXVtu = {
	 Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡦ࡮ࡷࡢ࡭ࠪዾ")				:t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧዿ")
	,TzIj50KpohEOHx6CbZWqB(u"࠭ࡡ࡬ࡱࡤࡱࠬጀ")				:jwzOabysh0Z(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫጁ")
	,gDETKVh8mZe09Nd(u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪጂ")				:Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪጃ")
	,hPFcB6Uxmabj59Iq(u"ࠪࡥࡰࡽࡡ࡮ࠩጄ")				:hPFcB6Uxmabj59Iq(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨጅ")
	,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡧ࡫ࡸࡣࡰࡸࡺࡨࡥࠨጆ")			:jwzOabysh0Z(u"࠭ๅ้ไ฼ࠤฬ้่ศ็ࠣฮ๏๎ศࠨጇ")
	,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧገ")				:oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨጉ")
	,SIkwCEdJHTD9v1(u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫጊ")				:TzIj50KpohEOHx6CbZWqB(u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩጋ")
	,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧጌ")			:Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨግ")
	,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨጎ")				:E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫጏ")
	,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡣ࡯ࡱࡸࡺࡢࡢࠩጐ")				:Js61GTdX5wzMurUqi7Z(u"่ࠩ์็฿ࠠศๆู่฼ฮษࠨ጑")
	,YQNd4wejLSAVJ6T(u"ࠪࡥࡳ࡯࡭ࡦࡼ࡬ࡨࠬጒ")				:sH6BOz5wKRFcEg(u"๊ࠫ๎โฺࠢส๊๊๐ࠠำัࠪጓ")
	,jwzOabysh0Z(u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪጔ")			:bGzRdmOErkIylxALniq6(u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨጕ")
	,SIkwCEdJHTD9v1(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ጖")				:jwzOabysh0Z(u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ጗")
	,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫጘ")				:aenpKvQCGVzhLXEdWiDIZ(u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫጙ")
	,hPFcB6Uxmabj59Iq(u"ࠫࡦࡿ࡬ࡰ࡮ࠪጚ")				:t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"๋่ࠬใ฻ࠣว๏๊่ๅࠩጛ")
	,aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡢࡰ࡭ࡵࡥࠬጜ")				:qeG16a4pbSHziNVQ2uFXrs(u"ࠧๆ๊ๅ฽ࠥฮใาษࠪጝ")
	,qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨጞ")				:oVwa0kcqxj1e7mLplAfZdGT(u"่ࠩ์็฿ࠠษำึฮ๏าࠧጟ")
	,hPFcB6Uxmabj59Iq(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫጠ")				:IOHSz7YPF9WusGgUt1Dq(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫጡ")
	,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡩࡩ࡮ࡣ࠷ࡴࠬጢ")				:sH6BOz5wKRFcEg(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึࠦศ๋ࠩጣ")
	,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧጤ")				:IO7k2hZXSz(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪጥ")
	,TzIj50KpohEOHx6CbZWqB(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫጦ")				:t19ZOVHA4CpwFKaeiubcMGvz(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫጧ")
	,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ጨ")				:qeG16a4pbSHziNVQ2uFXrs(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ጩ")
	,aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬጪ")			:IO7k2hZXSz(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬጫ")
	,fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪጬ")				:TzIj50KpohEOHx6CbZWqB(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪጭ")
	,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬጮ")				:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬጯ")
	,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡩࡩ࡮ࡣࡩࡶࡪ࡫ࠧጰ")				:hPFcB6Uxmabj59Iq(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไี๏࠭ጱ")
	,oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪጲ")			:TzIj50KpohEOHx6CbZWqB(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩጳ")
	,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪጴ")				:aenpKvQCGVzhLXEdWiDIZ(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪጵ")
	,GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡨ࡯࡭ࡢࡹࡥࡥࡸ࠭ጶ")				:hPFcB6Uxmabj59Iq(u"๋่ࠬใ฻ࠣื๏๋ว๊ࠡหืࠬጷ")
	,Js61GTdX5wzMurUqi7Z(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫጸ")			:aenpKvQCGVzhLXEdWiDIZ(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠩጹ")
	,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨጺ")	:t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤู๊สฯั่๎๋࠭ጻ")
	,IO7k2hZXSz(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡪࡤࡷ࡭ࡺࡡࡨࡵࠪጼ")	:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦ็ศึอห่࠭ጽ")
	,jwzOabysh0Z(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡰ࡮ࡼࡥࡴࠩጾ")	:E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็หหูืࠧጿ")
	,GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨፀ"):sH6BOz5wKRFcEg(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๆํอฦๆࠩፁ")
	,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡵࡱࡳ࡭ࡨࡹࠧፂ")	:Js61GTdX5wzMurUqi7Z(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬፃ")
	,GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩፄ")	:IO7k2hZXSz(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩፅ")
	,qqw1upCsKM(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨፆ")				:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧๆฬ๋ๆๆ࠭ፇ")
	,jwzOabysh0Z(u"ࠨࡦࡵࡥࡲࡧࡣࡢࡨࡨࠫፈ")			:hPFcB6Uxmabj59Iq(u"่ࠩ์็฿ࠠะำส้ฬࠦใศใํ๋ࠬፉ")
	,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫፊ")				:fvYGxnZNUiyP4HJkMIoS25(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫፋ")
	,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ፌ")				:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧፍ")
	,SE97R3Dpj6dPLweVKU(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩፎ")				:zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫፏ")
	,jwzOabysh0Z(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫፐ")				:SIkwCEdJHTD9v1(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭ፑ")
	,qqw1upCsKM(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ፒ")				:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨፓ")
	,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨፔ")				:TzIj50KpohEOHx6CbZWqB(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪፕ")
	,IO7k2hZXSz(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬፖ")			:jwzOabysh0Z(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧፗ")
	,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫፘ")				:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫፙ")
	,aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬፚ")				:bGzRdmOErkIylxALniq6(u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭፛")
	,RDwahqjPfbdyEiTtnLQu(u"ࠧࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢࠩ፜")				:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨ็๋ๆ฾ࠦๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧ፝")
	,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡨࡰ࡮࡬ࡶࡪࡦࡨࡳࠬ፞")			:fvYGxnZNUiyP4HJkMIoS25(u"้ࠪํู่ࠡล็๎ๆࠦแ๋ัํ์ࠬ፟")
	,qqw1upCsKM(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬ፠")				:XxE4VAKW7LQzdk2Il3gUr1vwn(u"๋่ࠬใ฻ࠣๅอืใสࠩ፡")
	,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭።")				:RDwahqjPfbdyEiTtnLQu(u"ࠧโึ็ࠫ፣")
	,EJgYdjbIiWe1apkQlZcR42(u"ࠨࡨࡤ࡮ࡪࡸࡳࡩࡱࡺࠫ፤")			:GVurlv8HeoXEzPRiQB7Ty(u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧ፥")
	,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡪࡦࡸࡥࡴ࡭ࡲࠫ፦")				:XxE4VAKW7LQzdk2Il3gUr1vwn(u"๊ࠫ๎โฺࠢไหึูใ้ࠩ፧")
	,GVurlv8HeoXEzPRiQB7Ty(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ፨")				:Js61GTdX5wzMurUqi7Z(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ፩")
	,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ፪")				:Js61GTdX5wzMurUqi7Z(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ፫")
	,GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡩࡳࡱࡪࡥࡳࠩ፬")				:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"้ࠪั๊ฯࠨ፭")
	,Js61GTdX5wzMurUqi7Z(u"ࠫ࡫ࡵࡳࡵࡣࠪ፮")				:YQNd4wejLSAVJ6T(u"๋่ࠬใ฻ࠣๅํูสศࠩ፯")
	,jwzOabysh0Z(u"࠭ࡦࡶࡰࡲࡲࡹࡼࠧ፰")				:zLjWeKu6JgNO7vocUD0Qpy(u"ࠧๆ๊ๅ฽ࠥ็ๆ้่ࠣฮ๏็๊ࠨ፱")
	,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡨࡸࡷ࡭ࡧࡲࡵࡸࠪ፲")				:Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"่ࠩ์็฿ࠠโ๊ืหึࠦส๋ใํࠫ፳")
	,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡪࡺࡹࡨࡢࡴࡹ࡭ࡩ࡫࡯ࠨ፴")			:EJgYdjbIiWe1apkQlZcR42(u"๊ࠫ๎โฺࠢไ์ูอัࠡใํำ๏๎ࠧ፵")
	,jwzOabysh0Z(u"ࠬ࡭࡯ࡰࡦࠪ፶")					:jwzOabysh0Z(u"࠭ฬ๋ัࠪ፷")
	,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ፸")				:t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ፹")
	,TzIj50KpohEOHx6CbZWqB(u"ࠩ࡫ࡩࡱࡧ࡬ࠨ፺")				:E2QIcUfmlwa3xR17DFrkezBSsyh(u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭፻")
	,gDETKVh8mZe09Nd(u"ࠫ࡮࡬ࡩ࡭࡯ࠪ፼")				:jwzOabysh0Z(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩ፽")
	,sH6BOz5wKRFcEg(u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬ፾")			:YQNd4wejLSAVJ6T(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩ፿")
	,hPFcB6Uxmabj59Iq(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨᎀ")		:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧᎁ")
	,aenpKvQCGVzhLXEdWiDIZ(u"ࠪ࡭ࡵࡺࡶࠨᎂ")					:jwzOabysh0Z(u"ࠫࡎࡖࡔࡗࠩᎃ")
	,zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨᎄ")			:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪᎅ")
	,RDwahqjPfbdyEiTtnLQu(u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᎆ")			:iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬᎇ")
	,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧᎈ")			:jwzOabysh0Z(u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩᎉ")
	,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧᎊ")			:GVurlv8HeoXEzPRiQB7Ty(u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨᎋ")
	,RDwahqjPfbdyEiTtnLQu(u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨᎌ")				:fvYGxnZNUiyP4HJkMIoS25(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩᎍ")
	,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᎎ")				:E2QIcUfmlwa3xR17DFrkezBSsyh(u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭ᎏ")
	,qeG16a4pbSHziNVQ2uFXrs(u"ࠪ࡯࡮ࡸ࡭ࡢ࡮࡮ࠫ᎐")				:YQNd4wejLSAVJ6T(u"๊ࠫ๎โฺࠢๆี๊อไไࠩ᎑")
	,IO7k2hZXSz(u"ࠬࡲࡡࡳࡱࡽࡥࠬ᎒")				:EJgYdjbIiWe1apkQlZcR42(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫ᎓")
	,qqw1upCsKM(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨ᎔")				:gDETKVh8mZe09Nd(u"ࠨ็็ๅࠬ᎕")
	,bGzRdmOErkIylxALniq6(u"ࠩ࡯࡭ࡻ࡫ࠧ᎖")					:SIkwCEdJHTD9v1(u"ࠪๆ๋อษࠨ᎗")
	,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫ᎘")				:E2QIcUfmlwa3xR17DFrkezBSsyh(u"๋ࠬไโࠩ᎙")
	,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧ᎚")				:t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭᎛")
	,aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࡯࠶ࡹࠬ᎜")					:YQNd4wejLSAVJ6T(u"ࠩࡐ࠷࡚࠭᎝")
	,sH6BOz5wKRFcEg(u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬ᎞")				:iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧ᎟")
	,hPFcB6Uxmabj59Iq(u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩᎠ")			:E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩᎡ")
	,bGzRdmOErkIylxALniq6(u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫᎢ")			:XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭Ꭳ")
	,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡰࡥࡸࡧࡶࡪࡦࡨࡳࠬᎤ")			:XxE4VAKW7LQzdk2Il3gUr1vwn(u"้ࠪํู่ࠡ็สืฬࠦแ๋ัํ์ࠬᎥ")
	,Js61GTdX5wzMurUqi7Z(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᎦ")				:aYH620Dh48GEsTFfOBSQ7r(u"๋ࠬแใ๊าࠫᎧ")
	,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭Ꭸ")				:RDwahqjPfbdyEiTtnLQu(u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩᎩ")
	,SIkwCEdJHTD9v1(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨᎪ")				:RDwahqjPfbdyEiTtnLQu(u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩᎫ")
	,BWfpRku7SsM6cbE0eG(u"ࠪࡳࡱࡪࠧᎬ")					:YQNd4wejLSAVJ6T(u"ࠫ็ี๊ๆࠩᎭ")
	,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡶࡡ࡯ࡧࡷࠫᎮ")				:Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᎯ")
	,zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭Ꮀ")			:zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫᎱ")
	,qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨᎲ")			:fvYGxnZNUiyP4HJkMIoS25(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨᎳ")
	,aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡶ࡬ࡩ࡭࡯ࠪᎴ")				:zLjWeKu6JgNO7vocUD0Qpy(u"๋่ࠬใ฻ࠣ็๏๎ࠠโ์็้ࠬᎵ")
	,YQNd4wejLSAVJ6T(u"࠭ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧࠪᎶ")			:IOHSz7YPF9WusGgUt1Dq(u"ࠧๆ๊ๅ฽ู๊ࠥา์ึࠤฯอ๊ๆࠩᎷ")
	,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡵ࡫ࡥࡧࡧ࡫ࡢࡶࡼࠫᎸ")			:IO7k2hZXSz(u"่ࠩ์็฿ࠠีสๆฮ๏࠭Ꮉ")
	,oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬᎺ")				:RDwahqjPfbdyEiTtnLQu(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭Ꮋ")
	,bGzRdmOErkIylxALniq6(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠲ࠨᎼ")			:aenpKvQCGVzhLXEdWiDIZ(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠡ࠴ࠪᎽ")
	,fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫᎾ")			:t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩᎿ")
	,SIkwCEdJHTD9v1(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬᏀ")			:hPFcB6Uxmabj59Iq(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬᏁ")
	,IOHSz7YPF9WusGgUt1Dq(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧᏂ")		:RDwahqjPfbdyEiTtnLQu(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭Ꮓ")
	,IO7k2hZXSz(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩᏄ")		:qqw1upCsKM(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩᏅ")
	,TzIj50KpohEOHx6CbZWqB(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬᏆ")	:EJgYdjbIiWe1apkQlZcR42(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩᏇ")
	,EJgYdjbIiWe1apkQlZcR42(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪᏈ")				:SE97R3Dpj6dPLweVKU(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭Ꮙ")
	,gDETKVh8mZe09Nd(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧᏊ")				:aenpKvQCGVzhLXEdWiDIZ(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭Ꮛ")
	,hPFcB6Uxmabj59Iq(u"ࠧࡴࡪࡲࡳ࡫ࡴࡥࡵࠩᏌ")				:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ็๋ๆ฾ࠦิ้ใ๊ࠣฯ࠭Ꮝ")
	,TzIj50KpohEOHx6CbZWqB(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫᏎ")				:Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩᏏ")
	,SIkwCEdJHTD9v1(u"ࠫࡹ࡯࡫ࡢࡣࡷࠫᏐ")				:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๋่ࠬใ฻ࠣฮ่อสࠨᏑ")
	,BWfpRku7SsM6cbE0eG(u"࠭ࡴࡷࡨࡸࡲࠬᏒ")				:qeG16a4pbSHziNVQ2uFXrs(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧᏓ")
	,BWfpRku7SsM6cbE0eG(u"ࠨࡸࡤࡶࡧࡵ࡮ࠨᏔ")				:hPFcB6Uxmabj59Iq(u"่ࠩ์็฿ࠠโษิฬํ์ࠧᏕ")
	,gDETKVh8mZe09Nd(u"ࠪࡺ࡮ࡪࡥࡰࠩᏖ")				:EJgYdjbIiWe1apkQlZcR42(u"ࠫๆ๐ฯ๋๊ࠪᏗ")
	,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡼࡩࡥࡧࡲࡲࡸࡧࡥ࡮ࠩᏘ")			:iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ๅ้ไ฼ࠤๆ๐ฯุ๋๊๊ࠣอฦๆࠩᏙ")
	,fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠱ࠨᏚ")				:Js61GTdX5wzMurUqi7Z(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠲ࠩᏛ")
	,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠴ࠪᏜ")				:qqw1upCsKM(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠵ࠫᏝ")
	,sH6BOz5wKRFcEg(u"ࠫࡾࡧࡱࡰࡶࠪᏞ")				:zLjWeKu6JgNO7vocUD0Qpy(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩᏟ")
	,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᏠ")				:XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬᏡ")
	,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᏢ")		:aenpKvQCGVzhLXEdWiDIZ(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭Ꮳ")
	,hPFcB6Uxmabj59Iq(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧᏤ")	:TzIj50KpohEOHx6CbZWqB(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨᏥ")
	,gDETKVh8mZe09Nd(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭Ꮶ")		:iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭Ꮷ")
	,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭Ꮸ")			:wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ็๋ห็฿ࠠๆ่ࠣ๎ํะ๊้สࠪᏩ")
	}
	YdDhAON4FVfJslQjnB2vKX58 = TqNvzBxf1KpPDg3SRA4yj2mwcVF.lower()
	for key in list(yylp3OPwkxS4csXVtu.keys()):
		pvGEU4fW3q0u2wYt = key.lower()
		if YdDhAON4FVfJslQjnB2vKX58==pvGEU4fW3q0u2wYt:
			TqNvzBxf1KpPDg3SRA4yj2mwcVF = yylp3OPwkxS4csXVtu[key]
			break
	return TqNvzBxf1KpPDg3SRA4yj2mwcVF
def Ims96cLXkvKOx0GD(vhqzSbJmCRFIoW1uEAH6OKntlrDp9i,VEtfZ1GRT4SrihUjbycLC3qpg=sCHVtMAvqirbQ4BUK3cgWo):
	Q1siCkTZyw.H2heYqoNSfBbcLRGiUsWDZnAEIgJ7j = ndkUxG9LtewJ
	if not VEtfZ1GRT4SrihUjbycLC3qpg and vhqzSbJmCRFIoW1uEAH6OKntlrDp9i: VEtfZ1GRT4SrihUjbycLC3qpg = zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪᏪ")
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(BWfpRku7SsM6cbE0eG(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᏫ"),VEtfZ1GRT4SrihUjbycLC3qpg)
	return
def IgCGzHw45TJ7PeuO1EKl(ZvWwXBJxzk3Qi9uAHKTD8hY2,nRylPVX0Hem2hEOSLJFiudMbx=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠿࠵ࠧᏬ")):
	return _8KvBQjAnCw(ZvWwXBJxzk3Qi9uAHKTD8hY2,nRylPVX0Hem2hEOSLJFiudMbx)
def kkWaVfZ8QTuG5NnlpsXYqmePzU3Ex1(gX6m1GcBsMRE):
	if gX6m1GcBsMRE in [sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࠶ࠧᏭ"),BewrUo9ANCa17G43Sn0LH5xh]: return sCHVtMAvqirbQ4BUK3cgWo
	gX6m1GcBsMRE = int(gX6m1GcBsMRE)
	BGxPyJQSdwsEqX5lkfrRDi3 = gX6m1GcBsMRE^OOht4Ly9dmZMIz
	Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V = gX6m1GcBsMRE^NjPWfJS7CUoTsz4lKk0hg
	u8gPKGbQBOVomTwUAW467nRYL = gX6m1GcBsMRE^EGwIN9K6n5rVsjpLC4qvSUTyo3Z2
	EEAmpOW4IoViLx6D958YPc21B = str(BGxPyJQSdwsEqX5lkfrRDi3)+str(Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V)+str(u8gPKGbQBOVomTwUAW467nRYL)
	return EEAmpOW4IoViLx6D958YPc21B
def yQY79s60iwLT(gX6m1GcBsMRE):
	if gX6m1GcBsMRE in [sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"࠭࠰ࠨᏮ"),BewrUo9ANCa17G43Sn0LH5xh]: return sCHVtMAvqirbQ4BUK3cgWo
	gX6m1GcBsMRE = str(gX6m1GcBsMRE)
	EEAmpOW4IoViLx6D958YPc21B = sCHVtMAvqirbQ4BUK3cgWo
	if len(gX6m1GcBsMRE)==Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠱࠶ᗵ"):
		BGxPyJQSdwsEqX5lkfrRDi3,Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V,u8gPKGbQBOVomTwUAW467nRYL = gX6m1GcBsMRE[BewrUo9ANCa17G43Sn0LH5xh:kK7gj9HE462hADJbvr],gX6m1GcBsMRE[kK7gj9HE462hADJbvr:Js61GTdX5wzMurUqi7Z(u"࠺ᗶ")],gX6m1GcBsMRE[Js61GTdX5wzMurUqi7Z(u"࠺ᗶ"):]
		BGxPyJQSdwsEqX5lkfrRDi3 = int(BGxPyJQSdwsEqX5lkfrRDi3)^EGwIN9K6n5rVsjpLC4qvSUTyo3Z2
		Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V = int(Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V)^NjPWfJS7CUoTsz4lKk0hg
		u8gPKGbQBOVomTwUAW467nRYL = int(u8gPKGbQBOVomTwUAW467nRYL)^OOht4Ly9dmZMIz
		if BGxPyJQSdwsEqX5lkfrRDi3==Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V==u8gPKGbQBOVomTwUAW467nRYL: EEAmpOW4IoViLx6D958YPc21B = str(BGxPyJQSdwsEqX5lkfrRDi3*RDwahqjPfbdyEiTtnLQu(u"࠸࠳ᗷ"))
	return EEAmpOW4IoViLx6D958YPc21B
def EpTiLePsOavwod3DxXcjJCq(gX6m1GcBsMRE,ovLKQxp9Beg=gDETKVh8mZe09Nd(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᏯ")):
	if gX6m1GcBsMRE==sCHVtMAvqirbQ4BUK3cgWo: return sCHVtMAvqirbQ4BUK3cgWo
	gX6m1GcBsMRE = int(gX6m1GcBsMRE)+int(ovLKQxp9Beg)
	BGxPyJQSdwsEqX5lkfrRDi3 = gX6m1GcBsMRE^OOht4Ly9dmZMIz
	Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V = gX6m1GcBsMRE^NjPWfJS7CUoTsz4lKk0hg
	u8gPKGbQBOVomTwUAW467nRYL = gX6m1GcBsMRE^EGwIN9K6n5rVsjpLC4qvSUTyo3Z2
	EEAmpOW4IoViLx6D958YPc21B = str(BGxPyJQSdwsEqX5lkfrRDi3)+str(Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V)+str(u8gPKGbQBOVomTwUAW467nRYL)
	return EEAmpOW4IoViLx6D958YPc21B
def dh4Y5pvylFJEmH3LzgKBRNTac2(gX6m1GcBsMRE,ovLKQxp9Beg=jwzOabysh0Z(u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪᏰ")):
	if gX6m1GcBsMRE==sCHVtMAvqirbQ4BUK3cgWo: return sCHVtMAvqirbQ4BUK3cgWo
	gX6m1GcBsMRE = str(gX6m1GcBsMRE)
	aaRe85jDnZKfx7E = int(len(gX6m1GcBsMRE)/vUnJhT2NO8yirHcAmg)
	BGxPyJQSdwsEqX5lkfrRDi3 = int(gX6m1GcBsMRE[BewrUo9ANCa17G43Sn0LH5xh:aaRe85jDnZKfx7E])^OOht4Ly9dmZMIz
	Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V = int(gX6m1GcBsMRE[aaRe85jDnZKfx7E:rgpY5VUqKbeFOCD9Nki2SmGvxEja*aaRe85jDnZKfx7E])^NjPWfJS7CUoTsz4lKk0hg
	u8gPKGbQBOVomTwUAW467nRYL = int(gX6m1GcBsMRE[rgpY5VUqKbeFOCD9Nki2SmGvxEja*aaRe85jDnZKfx7E:vUnJhT2NO8yirHcAmg*aaRe85jDnZKfx7E])^EGwIN9K6n5rVsjpLC4qvSUTyo3Z2
	EEAmpOW4IoViLx6D958YPc21B = sCHVtMAvqirbQ4BUK3cgWo
	if BGxPyJQSdwsEqX5lkfrRDi3==Fq3UOLeIDrxEgpBk5mbnHGKsY4j9V==u8gPKGbQBOVomTwUAW467nRYL: EEAmpOW4IoViLx6D958YPc21B = str(int(BGxPyJQSdwsEqX5lkfrRDi3)-int(ovLKQxp9Beg))
	return EEAmpOW4IoViLx6D958YPc21B
def EEtm4D3fSIHhZpeyl68gqL9JUciXuo(C1iP8hmd9kRa0xY4FWer):
	ROyGHwjLdJ = Q1siCkTZyw.SITESURLS[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᏱ")][SE97R3Dpj6dPLweVKU(u"࠻ᗸ")]
	dBHbR5Dp3tCfXqwVE2mIiJcNP0v = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭Ᏺ"),IO7k2hZXSz(u"ࠫࡸࡱࡩ࡯ࡵࠪᏳ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭Ᏼ"),EJgYdjbIiWe1apkQlZcR42(u"࠭࠷࠳࠲ࡳࠫᏵ"),YQNd4wejLSAVJ6T(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ᏶"))
	adbqm89TkAJ63IZWcFDvY5PXtwH,o6fBKw0a4GAN1Our9iI = kAxsioNSB6w5cDaKGlueOjXd(dBHbR5Dp3tCfXqwVE2mIiJcNP0v)
	adbqm89TkAJ63IZWcFDvY5PXtwH = EpTiLePsOavwod3DxXcjJCq(adbqm89TkAJ63IZWcFDvY5PXtwH,hPFcB6Uxmabj59Iq(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ᏷"))
	BJRZHwUtcf2i9hyueYrWLqM = {RDwahqjPfbdyEiTtnLQu(u"ࠩ࡬ࡨࡸ࠭ᏸ"):hPFcB6Uxmabj59Iq(u"ࠪࡈࡎࡇࡌࡐࡉࠪᏹ"),SE97R3Dpj6dPLweVKU(u"ࠫࡺࡹࡲࠨᏺ"):Q1siCkTZyw.AV_CLIENT_IDS,aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡼࡥࡳࠩᏻ"):WHzJr591Ka8gRdbiLmBp0hT3S,BWfpRku7SsM6cbE0eG(u"࠭ࡳࡤࡴࠪᏼ"):C1iP8hmd9kRa0xY4FWer,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡴ࡫ࡽࠫᏽ"):adbqm89TkAJ63IZWcFDvY5PXtwH}
	BznVJGMjmdqu2b4KU = {t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ᏾"):gDETKVh8mZe09Nd(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ᏿")}
	XXjVkRwgBZJrhPQKvSdiFo5 = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,TzIj50KpohEOHx6CbZWqB(u"ࠪࡔࡔ࡙ࡔࠨ᐀"),ROyGHwjLdJ,BJRZHwUtcf2i9hyueYrWLqM,BznVJGMjmdqu2b4KU,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬᐁ"))
	FaDxgsGO0Ic = XXjVkRwgBZJrhPQKvSdiFo5.content
	try:
		if not FaDxgsGO0Ic: CQo4KJAhl5ywtRBDW9Xvpuz
		yyvhAW3Lc5wCmaMH8 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡪࡩࡤࡶࠪᐂ"),FaDxgsGO0Ic)
		kd2pACnLxs5 = yyvhAW3Lc5wCmaMH8[Js61GTdX5wzMurUqi7Z(u"࠭࡭ࡴࡩࠪᐃ")]
		VQZRDsGaTHx6ULOYdtm = yyvhAW3Lc5wCmaMH8[SE97R3Dpj6dPLweVKU(u"ࠧࡴࡧࡦࠫᐄ")]
		i13KkR89lLsASNuEdztBnhJZ7I0T = yyvhAW3Lc5wCmaMH8[aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡵࡷࡴࠬᐅ")]
		VQZRDsGaTHx6ULOYdtm = int(dh4Y5pvylFJEmH3LzgKBRNTac2(VQZRDsGaTHx6ULOYdtm,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᐆ")))
		i13KkR89lLsASNuEdztBnhJZ7I0T = int(dh4Y5pvylFJEmH3LzgKBRNTac2(i13KkR89lLsASNuEdztBnhJZ7I0T,bGzRdmOErkIylxALniq6(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᐇ")))
		for PM4lkYVI3fL5Z6cuRBs0QN2HEO in range(VQZRDsGaTHx6ULOYdtm,BewrUo9ANCa17G43Sn0LH5xh,-i13KkR89lLsASNuEdztBnhJZ7I0T):
			if not eval(SIkwCEdJHTD9v1(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩᐈ"),{sH6BOz5wKRFcEg(u"ࠬࡾࡢ࡮ࡥࠪᐉ"):FoiwfTEhGD8ulS25HeUvnI}): CQo4KJAhl5ywtRBDW9Xvpuz
			iRaHzNpJhSx6ZnCfrvD7j93lks(sH6BOz5wKRFcEg(u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬᐊ"),str(PM4lkYVI3fL5Z6cuRBs0QN2HEO)+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡࠢฮห๋๐ษࠨᐋ"),hDjf1Ubgq629nXlOvcFLH4Jw=Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠵࠵࠶ᗹ")*i13KkR89lLsASNuEdztBnhJZ7I0T)
			FoiwfTEhGD8ulS25HeUvnI.sleep(YQNd4wejLSAVJ6T(u"࠶࠶࠰࠱ᗺ")*i13KkR89lLsASNuEdztBnhJZ7I0T)
		if eval(IOHSz7YPF9WusGgUt1Dq(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ᐌ"),{Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡻࡦࡲࡩࠧᐍ"):FoiwfTEhGD8ulS25HeUvnI}):
			kd2pACnLxs5 = kd2pACnLxs5.replace(slFfrUIWCowaBA7tce3iZbj8xn,GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡠࡡࡴࠧᐎ")).replace(f6fsIXQonhvcGg1p,SE97R3Dpj6dPLweVKU(u"ࠫࡡࡢࡲࠨᐏ"))
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠬิั้ฮࠪᐐ"),OODdgcrlh8KQo0A7M2eEvViwPqpkR,kd2pACnLxs5)
		CQo4KJAhl5ywtRBDW9Xvpuz
	except: exec(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᐑ"),{Js61GTdX5wzMurUqi7Z(u"ࠧࡹࡤࡰࡧࠬᐒ"):FoiwfTEhGD8ulS25HeUvnI})
	return
def IlwgjiRbfLCAouYX2k0vVqQT7DSJ():
	exec(SIkwCEdJHTD9v1(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᐓ"),{sH6BOz5wKRFcEg(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᐔ"):qqtbjl02E5pUOdQ1yMn8xABJsVG67w,fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡼࡧࡳࡣࠨᐕ"):FoiwfTEhGD8ulS25HeUvnI})
	return
def kAxsioNSB6w5cDaKGlueOjXd(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU):
	lejLft4K0yH,JZD8Wzc1MGq9fgVFI2oENX5eT = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU):
		try: lejLft4K0yH = YYEXZsUWhf52vz7HLxc0qGJ.path.getsize(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU)
		except: pass
		if not lejLft4K0yH:
			try: lejLft4K0yH = YYEXZsUWhf52vz7HLxc0qGJ.stat(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU).st_size
			except: pass
		if not lejLft4K0yH:
			try:
				from pathlib import Path as dmoA9Sqc2I7NzlUuxsCDK
				lejLft4K0yH = dmoA9Sqc2I7NzlUuxsCDK(eQz8qI1Mn7OG3btvldjEJoAC4iPkZU).stat().st_size
			except: pass
		if lejLft4K0yH: JZD8Wzc1MGq9fgVFI2oENX5eT = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	return lejLft4K0yH,JZD8Wzc1MGq9fgVFI2oENX5eT
def lAF3aONH7GKop5kw9bPd1sC(RyUhNr8ASWvQcLpP2XkBb4ZCtguT,showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RyUhNr8ASWvQcLpP2XkBb4ZCtguT+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡡࡴ࡜࡯ࠩᐖ")+VXWOCAE6ns3paJ8DLG479NQfMu+TzIj50KpohEOHx6CbZWqB(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩᐗ")+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠷ᗻ"): return lvzrYTpcBaK
	succeeded = ndkUxG9LtewJ
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(RyUhNr8ASWvQcLpP2XkBb4ZCtguT):
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(RyUhNr8ASWvQcLpP2XkBb4ZCtguT.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
		except:
			try: YYEXZsUWhf52vz7HLxc0qGJ.remove(P9Jbh5TemwIHzrfiLE4qNng)
			except Exception as QQa32JB7je0XdftAuz6yvxZsrViPo:
				succeeded = lvzrYTpcBaK
				if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,str(QQa32JB7je0XdftAuz6yvxZsrViPo))
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭แีๆอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭ᐘ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᐙ"))
	return succeeded
def W0BFzMOVpdNxnmer5aZfs(ZchVHo6zb08,EfnBwZks795bXSaFhioY,showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,ZchVHo6zb08+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡞ࡱࡠࡳ࠭ᐚ")+VXWOCAE6ns3paJ8DLG479NQfMu+EJgYdjbIiWe1apkQlZcR42(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧᐛ")+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return lvzrYTpcBaK
	succeeded = ndkUxG9LtewJ
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(ZchVHo6zb08):
		for gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd,qfSYQAwZVMvu0tbrUkyhHIsRW163p,y0k6SDdtf5PiGXEFuH in YYEXZsUWhf52vz7HLxc0qGJ.walk(ZchVHo6zb08,topdown=lvzrYTpcBaK):
			for eQz8qI1Mn7OG3btvldjEJoAC4iPkZU in y0k6SDdtf5PiGXEFuH:
				YCSV1Wce7fqnBbEFT90p4zX5v = YYEXZsUWhf52vz7HLxc0qGJ.path.join(gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd,eQz8qI1Mn7OG3btvldjEJoAC4iPkZU)
				try: YYEXZsUWhf52vz7HLxc0qGJ.remove(YCSV1Wce7fqnBbEFT90p4zX5v)
				except Exception as QQa32JB7je0XdftAuz6yvxZsrViPo:
					succeeded = lvzrYTpcBaK
					if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,str(QQa32JB7je0XdftAuz6yvxZsrViPo))
			if EfnBwZks795bXSaFhioY:
				for dir in qfSYQAwZVMvu0tbrUkyhHIsRW163p:
					CwTd7rY3Se0tK2sxLZl = YYEXZsUWhf52vz7HLxc0qGJ.path.join(gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd,dir)
					try: YYEXZsUWhf52vz7HLxc0qGJ.rmdir(CwTd7rY3Se0tK2sxLZl)
					except: pass
		if EfnBwZks795bXSaFhioY:
			try: YYEXZsUWhf52vz7HLxc0qGJ.rmdir(gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd)
			except: pass
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,jwzOabysh0Z(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᐜ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,jwzOabysh0Z(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭ᐝ"))
	return succeeded
def oi4MGF01PsQtfzAqNYreVa8yE(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt):
	vrEJRkchKxtDNiqO1b79mL5eT,iBZOl3bVjWPufr0JvxphG5kIzgcF2U,aapYv0lK3Sr2COEJqwL,dgoN8FJ0VaPSybR = ZZAphuVI2C69Mt3NqTyJ1bkL(ZvWwXBJxzk3Qi9uAHKTD8hY2)
	sNmyDVjHLfuhtoOdx0FZgWcYq9Al = CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov
	if K6SYhoTVCnIFyEe8zL4X2<Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠰ᗼ"):
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,sH6BOz5wKRFcEg(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᐞ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al)
		K6SYhoTVCnIFyEe8zL4X2 = -K6SYhoTVCnIFyEe8zL4X2
	if K6SYhoTVCnIFyEe8zL4X2>EJgYdjbIiWe1apkQlZcR42(u"࠱ᗽ"):
		cIy4z8xCUt7j5MhPZO = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,IOHSz7YPF9WusGgUt1Dq(u"࠭ࡳࡵࡴࠪᐟ"),gDETKVh8mZe09Nd(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᐠ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al)
		if cIy4z8xCUt7j5MhPZO:
			oTwfq964iZjEhD0(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭ᐡ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,CXTZu2YvNpEPkinLf8Ohlm3Rg)
			return cIy4z8xCUt7j5MhPZO
	cIy4z8xCUt7j5MhPZO = mpfNBWFjnzLs(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt)
	if cIy4z8xCUt7j5MhPZO and K6SYhoTVCnIFyEe8zL4X2: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,sH6BOz5wKRFcEg(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᐢ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al,cIy4z8xCUt7j5MhPZO,K6SYhoTVCnIFyEe8zL4X2)
	return cIy4z8xCUt7j5MhPZO
def ju4rw9S8bBylgdK1AOoIh5Dvzf(Ll1m0nJoaAPvHsXqyRE,zhi6So8CxtLT,zzGwiueprAn=BewrUo9ANCa17G43Sn0LH5xh):
	rJDTBxeNGdbp15j = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧᐣ"))
	if rJDTBxeNGdbp15j and E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫ࠲࠭ᐤ") not in rJDTBxeNGdbp15j: T1AWiH6ZJ2X3Ccs,BBkK3fdtw8HibrRnULIupsljVGz = int(rJDTBxeNGdbp15j),ndkUxG9LtewJ
	elif zzGwiueprAn: T1AWiH6ZJ2X3Ccs,BBkK3fdtw8HibrRnULIupsljVGz = zzGwiueprAn,lvzrYTpcBaK
	else: return []
	d4xV85PtbL6UBNm7yEwgZSFk1l,CQIe58claUP7Z3Dn4isKqBSyA9YoGr = [],sCHVtMAvqirbQ4BUK3cgWo
	p18gmYI0AvoxwOe2yMdBEl39S4ULcD,xiUXH2D4J8SkLNvtycEd96IFAV0,Tk1QpGhaoIVAznXBg,uk6oMnPFAcrs52b9m1H47GyxLXJOZ = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
	zhi6So8CxtLT = sorted(zhi6So8CxtLT,reverse=ndkUxG9LtewJ,key=lambda key: (key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],key[rgpY5VUqKbeFOCD9Nki2SmGvxEja]))
	for stream,gZYmIQjku63s4txUAecER,qlu4QIrH7GwzJ5LTn8jKA in zhi6So8CxtLT+[[sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh]]:
		if gZYmIQjku63s4txUAecER==CQIe58claUP7Z3Dn4isKqBSyA9YoGr:
			if qlu4QIrH7GwzJ5LTn8jKA>T1AWiH6ZJ2X3Ccs: xiUXH2D4J8SkLNvtycEd96IFAV0,uk6oMnPFAcrs52b9m1H47GyxLXJOZ = stream,qlu4QIrH7GwzJ5LTn8jKA
			elif not p18gmYI0AvoxwOe2yMdBEl39S4ULcD: p18gmYI0AvoxwOe2yMdBEl39S4ULcD,Tk1QpGhaoIVAznXBg = stream,qlu4QIrH7GwzJ5LTn8jKA
		else:
			if xiUXH2D4J8SkLNvtycEd96IFAV0 or p18gmYI0AvoxwOe2yMdBEl39S4ULcD:
				if p18gmYI0AvoxwOe2yMdBEl39S4ULcD: d4xV85PtbL6UBNm7yEwgZSFk1l.append([p18gmYI0AvoxwOe2yMdBEl39S4ULcD,CQIe58claUP7Z3Dn4isKqBSyA9YoGr,Tk1QpGhaoIVAznXBg])
				elif xiUXH2D4J8SkLNvtycEd96IFAV0: d4xV85PtbL6UBNm7yEwgZSFk1l.append([xiUXH2D4J8SkLNvtycEd96IFAV0,CQIe58claUP7Z3Dn4isKqBSyA9YoGr,uk6oMnPFAcrs52b9m1H47GyxLXJOZ])
			if qlu4QIrH7GwzJ5LTn8jKA>T1AWiH6ZJ2X3Ccs:
				xiUXH2D4J8SkLNvtycEd96IFAV0,uk6oMnPFAcrs52b9m1H47GyxLXJOZ = stream,qlu4QIrH7GwzJ5LTn8jKA
				p18gmYI0AvoxwOe2yMdBEl39S4ULcD,Tk1QpGhaoIVAznXBg = sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh
			else:
				xiUXH2D4J8SkLNvtycEd96IFAV0,uk6oMnPFAcrs52b9m1H47GyxLXJOZ = sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh
				p18gmYI0AvoxwOe2yMdBEl39S4ULcD,Tk1QpGhaoIVAznXBg = stream,qlu4QIrH7GwzJ5LTn8jKA
		CQIe58claUP7Z3Dn4isKqBSyA9YoGr = gZYmIQjku63s4txUAecER
	if BBkK3fdtw8HibrRnULIupsljVGz:
		vF7BwmirVQhcgE8lIMKZ4pd,sfyLahiENMJ6nd5Hxpc4lYwS0m2,OEJViylR8QT941jLG = zip(*d4xV85PtbL6UBNm7yEwgZSFk1l)
		ysJi2aWnd70TuL = [gDETKVh8mZe09Nd(u"ࠬࡳࡰ࠵ࠩᐥ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭࡭ࡱࡦࠪᐦ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡵࡵࠪᐧ"),TzIj50KpohEOHx6CbZWqB(u"ࠨ࡯࠶ࡹࠬᐨ")]
		for gZYmIQjku63s4txUAecER in ysJi2aWnd70TuL:
			if gZYmIQjku63s4txUAecER in sfyLahiENMJ6nd5Hxpc4lYwS0m2:
				index = sfyLahiENMJ6nd5Hxpc4lYwS0m2.index(gZYmIQjku63s4txUAecER)
				d4xV85PtbL6UBNm7yEwgZSFk1l = [[vF7BwmirVQhcgE8lIMKZ4pd[index],sfyLahiENMJ6nd5Hxpc4lYwS0m2[index],OEJViylR8QT941jLG[index]]]
				break
	return d4xV85PtbL6UBNm7yEwgZSFk1l
def zATVmaxnLvJf6E5So9cFNB(ZBlesVYJcG):
	LWMxiQoXg6vsFT1AK,eeVSO5ZDUk7ybwd2Cmogx = [],ZetiSjBQ9bTnF23pzsmXcyWuK
	for oT2iHwjfBx0FPX5ZCph9aWs38 in ccehpQ8jEwfV1garCtYiOHS6PzqKyk:
		if oT2iHwjfBx0FPX5ZCph9aWs38==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪᐩ"): eeVSO5ZDUk7ybwd2Cmogx = (SE97R3Dpj6dPLweVKU(u"ࠪࡰ࡮ࡴ࡫ࠨᐪ"),VXWOCAE6ns3paJ8DLG479NQfMu+XxE4VAKW7LQzdk2Il3gUr1vwn(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫᐫ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"࠳࠸࠻ᗾ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)
		elif oT2iHwjfBx0FPX5ZCph9aWs38==bGzRdmOErkIylxALniq6(u"ࠬࡓࡉ࡙ࡇࡇࠫᐬ"): eeVSO5ZDUk7ybwd2Cmogx = (qqw1upCsKM(u"࠭࡬ࡪࡰ࡮ࠫᐭ"),VXWOCAE6ns3paJ8DLG479NQfMu+fvYGxnZNUiyP4HJkMIoS25(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭ᐮ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"࠴࠹࠼ᗿ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)
		elif oT2iHwjfBx0FPX5ZCph9aWs38==hPFcB6Uxmabj59Iq(u"ࠨࡒࡘࡆࡑࡏࡃࠨᐯ"): eeVSO5ZDUk7ybwd2Cmogx = (XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࡯࡭ࡳࡱࠧᐰ"),VXWOCAE6ns3paJ8DLG479NQfMu+YQNd4wejLSAVJ6T(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪᐱ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠵࠺࠽ᘀ"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)
		if oT2iHwjfBx0FPX5ZCph9aWs38 not in ZBlesVYJcG: continue
		if eeVSO5ZDUk7ybwd2Cmogx:
			LWMxiQoXg6vsFT1AK.append(eeVSO5ZDUk7ybwd2Cmogx)
			eeVSO5ZDUk7ybwd2Cmogx = ZetiSjBQ9bTnF23pzsmXcyWuK
		if oT2iHwjfBx0FPX5ZCph9aWs38 not in [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬᐲ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡓࡉ࡙ࡇࡇࠫᐳ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ᐴ")]: LWMxiQoXg6vsFT1AK.append(oT2iHwjfBx0FPX5ZCph9aWs38)
	return LWMxiQoXg6vsFT1AK
def iFhUJ1tGmzoRjK(AbmCVjhycUPswQ9kHZaMJ6p0LxG,args=[]):
	BznVJGMjmdqu2b4KU = {Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᐵ"):gDETKVh8mZe09Nd(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᐶ")}
	bC6ySLvicNuHzE3UVaBdjAtZ,ouXMOacBj0PGxDT6rR9KgzA2,Y7ID12REWATwuqxG8en9U0 = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨᐷ"),Js61GTdX5wzMurUqi7Z(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩᐸ"),int(hDjf1Ubgq629nXlOvcFLH4Jw.time())
	Mryt3ouEfI05hziOw = bC6ySLvicNuHzE3UVaBdjAtZ+IRqQOePKNclx1td+str(Y7ID12REWATwuqxG8en9U0)+WHzJr591Ka8gRdbiLmBp0hT3S+ouXMOacBj0PGxDT6rR9KgzA2
	oo68qhpVEJgC7R = O2QkHmVIjxELq.md5(Mryt3ouEfI05hziOw.encode(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡺࡺࡦ࠹ࠩᐹ"))).hexdigest()[:jwzOabysh0Z(u"࠸࠸ᘁ")]
	BJRZHwUtcf2i9hyueYrWLqM = {bGzRdmOErkIylxALniq6(u"ࠬࡰࡳࡤࡱࡧࡩࠬᐺ"):AbmCVjhycUPswQ9kHZaMJ6p0LxG,gDETKVh8mZe09Nd(u"࠭ࡡࡳࡩࡶࠫᐻ"):args,YQNd4wejLSAVJ6T(u"ࠧࡶࡵࡨࡶࠬᐼ"):IRqQOePKNclx1td,qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᐽ"):WHzJr591Ka8gRdbiLmBp0hT3S,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࡬ࡨࡸ࠭ᐾ"):oo68qhpVEJgC7R}
	UEwFolcXOvDe0LPn = Q1siCkTZyw.SITESURLS[EJgYdjbIiWe1apkQlZcR42(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐿ")][t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠷࠰ᘂ")]
	XXjVkRwgBZJrhPQKvSdiFo5 = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡕࡕࡓࡕࠩᑀ"),UEwFolcXOvDe0LPn,BJRZHwUtcf2i9hyueYrWLqM,BznVJGMjmdqu2b4KU,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧᑁ"))
	FaDxgsGO0Ic = XXjVkRwgBZJrhPQKvSdiFo5.content
	return FaDxgsGO0Ic
def Tgpqkx7DH6w30r(TMOe4Xa3V6zIGyl,timeout,kqugFQjAD9xvcCRPbWf1,G7CHAhyrnKuZQdYEoXVTFtfc,BcKsXOowl2mLMQh5Zk86):
	KKH7CXzpTeybwsrAUB = lvzrYTpcBaK
	for WCXyON0VpFJ in TMOe4Xa3V6zIGyl:
		WCXyON0VpFJ.start()
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(kqugFQjAD9xvcCRPbWf1)
		KKH7CXzpTeybwsrAUB = BcKsXOowl2mLMQh5Zk86()
		if KKH7CXzpTeybwsrAUB: break
	else:
		TT2GvQLo9aXigm3FyxWIUdMuEJrj5 = int(timeout-len(TMOe4Xa3V6zIGyl)*kqugFQjAD9xvcCRPbWf1)
		if TT2GvQLo9aXigm3FyxWIUdMuEJrj5>BewrUo9ANCa17G43Sn0LH5xh:
			for qLbRrEtgenpSi in range(TT2GvQLo9aXigm3FyxWIUdMuEJrj5//G7CHAhyrnKuZQdYEoXVTFtfc):
				hDjf1Ubgq629nXlOvcFLH4Jw.sleep(G7CHAhyrnKuZQdYEoXVTFtfc)
				KKH7CXzpTeybwsrAUB = BcKsXOowl2mLMQh5Zk86()
				if KKH7CXzpTeybwsrAUB: break
	for WCXyON0VpFJ in TMOe4Xa3V6zIGyl:
		try: WCXyON0VpFJ.join(kqugFQjAD9xvcCRPbWf1)
		except: pass
	return KKH7CXzpTeybwsrAUB
def T1eyjvbtkBKJhRmXqYCDcfHia(zhsLMNunK2dYeWOQ1vp=FYRWMho3SjB):
	s8creo0nSTR5iOftY1aqVPw3CZWJLU = sH6BOz5wKRFcEg(u"࠱࠱࠴࠷ᘃ")
	JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = BewrUo9ANCa17G43Sn0LH5xh
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo:
		try:
			import shutil as hvpcXtKFBU
			JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = hvpcXtKFBU.disk_usage(zhsLMNunK2dYeWOQ1vp).free
		except: pass
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo and hasattr(YYEXZsUWhf52vz7HLxc0qGJ,zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡳࡵࡣࡷࡺ࡫ࡹࠧᑂ")):
		try:
			RBoUbtwEHKgNxVGv7Tpz5A138d4F = YYEXZsUWhf52vz7HLxc0qGJ.statvfs(zhsLMNunK2dYeWOQ1vp)
			JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = RBoUbtwEHKgNxVGv7Tpz5A138d4F.f_frsize * RBoUbtwEHKgNxVGv7Tpz5A138d4F.f_bavail
		except: pass
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo and hasattr(YYEXZsUWhf52vz7HLxc0qGJ,YQNd4wejLSAVJ6T(u"ࠧࡧࡵࡷࡥࡹࡼࡦࡴࠩᑃ")):
		try:
			RBoUbtwEHKgNxVGv7Tpz5A138d4F = YYEXZsUWhf52vz7HLxc0qGJ.fstatvfs(zhsLMNunK2dYeWOQ1vp)
			JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = RBoUbtwEHKgNxVGv7Tpz5A138d4F.f_frsize * RBoUbtwEHKgNxVGv7Tpz5A138d4F.f_bavail
		except: pass
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo and xlOFiKpdTI1Vjw5YN.platform == oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡹ࡬ࡲ࠸࠸ࠧᑄ"):
		try:
			import ctypes as rrRj72Zgo8
			y96yUFjWRNGXHP0METea4zmk8wq = rrRj72Zgo8.c_ulonglong(BewrUo9ANCa17G43Sn0LH5xh)
			rrRj72Zgo8.windll.kernel32.GetDiskFreeSpaceExW(rrRj72Zgo8.c_wchar_p(zhsLMNunK2dYeWOQ1vp),None,None,rrRj72Zgo8.pointer(y96yUFjWRNGXHP0METea4zmk8wq))
			JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = y96yUFjWRNGXHP0METea4zmk8wq.value
		except: pass
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo:
		try:
			GOah7YIAKjT = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬᑅ"))
			B8BC6IqU0cAl = fNntYJW45mEFSdRX8g.findall(hPFcB6Uxmabj59Iq(u"ࠪࡠࡩ࠱ࠨࡀ࠼࡟࠲ࡡࡪࠫࠪࡁࠪᑆ"),GOah7YIAKjT,fNntYJW45mEFSdRX8g.DOTALL)
			if B8BC6IqU0cAl:
				B8BC6IqU0cAl = float(B8BC6IqU0cAl[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠱ᘄ")])
				if   iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࡙ࠫ࠭ᑇ") in GOah7YIAKjT: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = B8BC6IqU0cAl*s8creo0nSTR5iOftY1aqVPw3CZWJLU**kK7gj9HE462hADJbvr
				elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡍࠧᑈ") in GOah7YIAKjT: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = B8BC6IqU0cAl*s8creo0nSTR5iOftY1aqVPw3CZWJLU**vUnJhT2NO8yirHcAmg
				elif SIkwCEdJHTD9v1(u"࠭ࡍࠨᑉ") in GOah7YIAKjT: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = B8BC6IqU0cAl*s8creo0nSTR5iOftY1aqVPw3CZWJLU**rgpY5VUqKbeFOCD9Nki2SmGvxEja
				elif E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡌࠩᑊ") in GOah7YIAKjT: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = B8BC6IqU0cAl*s8creo0nSTR5iOftY1aqVPw3CZWJLU
				else: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = B8BC6IqU0cAl
		except: pass
	if not JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo: JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo = qeG16a4pbSHziNVQ2uFXrs(u"࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻ᘅ")
	return int(JJgl2iX0qnbxHBUjQ6PrLyCecmYSfo)
def Jha2IH6oq0uNl98sTXi3mbfDRZ(R1doy3mDZ4cJVTw5FGLY2t0KxiBvP):
	if R1doy3mDZ4cJVTw5FGLY2t0KxiBvP:
		JBzSYtjua2qRrFi5mQA8GNEk9ox6 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,SIkwCEdJHTD9v1(u"ࠨ࡮࡬ࡷࡹ࠭ᑋ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᑌ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨᑍ"))
		if JBzSYtjua2qRrFi5mQA8GNEk9ox6: return JBzSYtjua2qRrFi5mQA8GNEk9ox6
	rnCzKJiBSsgGhj = {bGzRdmOErkIylxALniq6(u"ࠫࡦ࠭ᑎ"):bGzRdmOErkIylxALniq6(u"ࠬࡧࠧᑏ")}
	url = Q1siCkTZyw.SITESURLS[bGzRdmOErkIylxALniq6(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᑐ")][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,qqw1upCsKM(u"ࠧࡑࡑࡖࡘࠬᑑ"),url,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡋࡊ࡚࡟ࡔࡋࡗࡉࡘࡥࡕࡔࡃࡊࡉ࠲࠷ࡳࡵࠩᑒ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩᑓ"),IO7k2hZXSz(u"࡙ࠪࡘࡇࠧᑔ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬᑕ"),GVurlv8HeoXEzPRiQB7Ty(u"࡛ࠬࡋࠨᑖ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(jwzOabysh0Z(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ᑗ"),SIkwCEdJHTD9v1(u"ࠧࡖࡃࡈࠫᑘ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧᑙ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡎࡗࡆ࠭ᑚ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᑛ"),SIkwCEdJHTD9v1(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩᑜ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(sH6BOz5wKRFcEg(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ᑝ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨᑞ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡠࡡࡢࠫᑟ"),LvzD9S8RPyGeukZQqb2T0B)
	try: gApJuUn2WDPB5eijdVQ = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(SE97R3Dpj6dPLweVKU(u"ࠨ࡮࡬ࡷࡹ࠭ᑠ"),Sw0pOFoVhPeIxbl)
	except:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,EJgYdjbIiWe1apkQlZcR42(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩᑡ"))
		return
	oowKA39k4BIRuT5QMn6,iQnZbGqywo8xYtJpfm51k9AaF,sxFd3Dga7n21vwtGAj0frR8 = gApJuUn2WDPB5eijdVQ
	w9kcLzVGXJ0eoy2xMaqgE,XTHzomFv7kW1LPhMad = [],[]
	for oT2iHwjfBx0FPX5ZCph9aWs38,xgStGd8hXZ4QrJfsvWYImceF,za6gw5tnfGs02liq in iQnZbGqywo8xYtJpfm51k9AaF:
		if xgStGd8hXZ4QrJfsvWYImceF.isdigit(): xgStGd8hXZ4QrJfsvWYImceF = gDETKVh8mZe09Nd(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ᑢ") if int(xgStGd8hXZ4QrJfsvWYImceF)>qeG16a4pbSHziNVQ2uFXrs(u"࠸࠴ᘆ") else jwzOabysh0Z(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭ᑣ")
		if oT2iHwjfBx0FPX5ZCph9aWs38 not in Q1siCkTZyw.non_videos_actions:
			if   xgStGd8hXZ4QrJfsvWYImceF==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᑤ"): w9kcLzVGXJ0eoy2xMaqgE.append(oT2iHwjfBx0FPX5ZCph9aWs38)
			elif xgStGd8hXZ4QrJfsvWYImceF==sH6BOz5wKRFcEg(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᑥ"): XTHzomFv7kW1LPhMad.append(oT2iHwjfBx0FPX5ZCph9aWs38)
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᑦ"),sH6BOz5wKRFcEg(u"ࠨࡕࡌࡘࡊ࡙࡟ࡖࡕࡄࡋࡊ࠭ᑧ"),[gApJuUn2WDPB5eijdVQ,w9kcLzVGXJ0eoy2xMaqgE,XTHzomFv7kW1LPhMad],NjPWfJS7CUoTsz4lKk0hg)
	return gApJuUn2WDPB5eijdVQ,w9kcLzVGXJ0eoy2xMaqgE,XTHzomFv7kW1LPhMad
def ttRBeVWLbpMzNQO75Zox4PXu8EGg(K6SYhoTVCnIFyEe8zL4X2,CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij=sCHVtMAvqirbQ4BUK3cgWo,iY3xS59ZAVkjhsIum1=sCHVtMAvqirbQ4BUK3cgWo):
	if hPFcB6Uxmabj59Iq(u"ࠩ࠽࠾ࠬᑨ") in CXTZu2YvNpEPkinLf8Ohlm3Rg: CXTZu2YvNpEPkinLf8Ohlm3Rg,ScEpZwINx93VJ5aWfb4 = CXTZu2YvNpEPkinLf8Ohlm3Rg.split(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪ࠾࠿࠭ᑩ"))
	else: CXTZu2YvNpEPkinLf8Ohlm3Rg,ScEpZwINx93VJ5aWfb4 = CXTZu2YvNpEPkinLf8Ohlm3Rg,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࠬᑪ")
	vrEJRkchKxtDNiqO1b79mL5eT,iBZOl3bVjWPufr0JvxphG5kIzgcF2U,aapYv0lK3Sr2COEJqwL,dgoN8FJ0VaPSybR = ZZAphuVI2C69Mt3NqTyJ1bkL(ZvWwXBJxzk3Qi9uAHKTD8hY2)
	E7sHixnPXJko4 = u0K219wAgLr8TXDcVGsqQPtRkCH6ov.copy() if isinstance(u0K219wAgLr8TXDcVGsqQPtRkCH6ov,dict) else u0K219wAgLr8TXDcVGsqQPtRkCH6ov
	sNmyDVjHLfuhtoOdx0FZgWcYq9Al = CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,gWlmUqwV3YrIT2XNPxQCisBHSDG9,E7sHixnPXJko4,h9eHNK3ZzI
	if K6SYhoTVCnIFyEe8zL4X2<BewrUo9ANCa17G43Sn0LH5xh:
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᑫ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al)
		K6SYhoTVCnIFyEe8zL4X2 = -K6SYhoTVCnIFyEe8zL4X2
	if K6SYhoTVCnIFyEe8zL4X2>BewrUo9ANCa17G43Sn0LH5xh:
		mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᑬ"),bGzRdmOErkIylxALniq6(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᑭ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al)
		if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
			oTwfq964iZjEhD0(SIkwCEdJHTD9v1(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᑮ"),vrEJRkchKxtDNiqO1b79mL5eT,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,CXTZu2YvNpEPkinLf8Ohlm3Rg)
			return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
	if ScEpZwINx93VJ5aWfb4==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࠫᑯ"): mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = dETqR0pCNwmv4PWuUOBt5rXcAh(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt)
	else: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij,iY3xS59ZAVkjhsIum1)
	if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.succeeded:
		if fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᑰ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content = CucRkH5KZqofAMWUgBFYVIz2jewbO(mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content,IO7k2hZXSz(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࡤࡎࡔࡎࡎࡢࡩࡳࡩ࡯ࡥࡧࡵࠫᑱ"))
		if mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.scrape: K6SYhoTVCnIFyEe8zL4X2 = OOht4Ly9dmZMIz
		if K6SYhoTVCnIFyEe8zL4X2 and mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᑲ"),sNmyDVjHLfuhtoOdx0FZgWcYq9Al,mmVhCYRLZI9oUfpcBzWiKJqNle6P2G,K6SYhoTVCnIFyEe8zL4X2)
	return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
def tCv5DBalk93umTy(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,data,headers,allow_redirects,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij,iY3xS59ZAVkjhsIum1):
	if data==sCHVtMAvqirbQ4BUK3cgWo: data = {}
	if headers==sCHVtMAvqirbQ4BUK3cgWo: headers = {}
	JJi0fB5bAKNCmDTrdWeFajvop289 = ndkUxG9LtewJ if allow_redirects in [sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ] else lvzrYTpcBaK
	wwKJzPUNesqLXrGZ6V5dC4B = ndkUxG9LtewJ if showDialogs in [sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ] else lvzrYTpcBaK
	ccwlRNomV6SWxsG3MJT = ndkUxG9LtewJ if ngCEfIL0MPdtvS3N5xij in [sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ] else lvzrYTpcBaK
	bfTGKy2HVtpN74g = ndkUxG9LtewJ if iY3xS59ZAVkjhsIum1 in [sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ] else lvzrYTpcBaK
	i68iPmaHVAZknGv2SNpyzCwcFE = data
	HSNYwERMjzyxmrPku = headers
	wwKJzPUNesqLXrGZ6V5dC4B = wwKJzPUNesqLXrGZ6V5dC4B if Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX==ZetiSjBQ9bTnF23pzsmXcyWuK else Q1siCkTZyw.ALLOW_SHOWDIALOGS_FIX
	ccwlRNomV6SWxsG3MJT = ccwlRNomV6SWxsG3MJT if Q1siCkTZyw.ALLOW_DNS_FIX==ZetiSjBQ9bTnF23pzsmXcyWuK else Q1siCkTZyw.ALLOW_DNS_FIX
	bfTGKy2HVtpN74g = bfTGKy2HVtpN74g if Q1siCkTZyw.ALLOW_PROXY_FIX==ZetiSjBQ9bTnF23pzsmXcyWuK else Q1siCkTZyw.ALLOW_PROXY_FIX
	if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt==TzIj50KpohEOHx6CbZWqB(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡋࡑࡗ࡙ࡇࡌࡍࡡࡒࡐࡉࡥࡒࡆࡎࡈࡅࡘࡋ࠭࠲ࡵࡷࠫᑳ"): HSNYwERMjzyxmrPku = {}
	else:
		rL70myIdXCjnJatpF9NUs36Y2Rlw1b = list(HSNYwERMjzyxmrPku.keys())
		if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᑴ") not in rL70myIdXCjnJatpF9NUs36Y2Rlw1b: HSNYwERMjzyxmrPku[oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᑵ")] = TzIj50KpohEOHx6CbZWqB(u"ࠩ࡫ࡸࡹࡶࠧᑶ")
		if qqw1upCsKM(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᑷ") not in rL70myIdXCjnJatpF9NUs36Y2Rlw1b: HSNYwERMjzyxmrPku[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᑸ")] = OOsacGDt4owXd52q7gC8l(ndkUxG9LtewJ)
	return CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ccwlRNomV6SWxsG3MJT,bfTGKy2HVtpN74g
def YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij=sCHVtMAvqirbQ4BUK3cgWo,iY3xS59ZAVkjhsIum1=sCHVtMAvqirbQ4BUK3cgWo):
	FNtoIQygCMwk3emv8h6GKaYdjUAJ0 = tCv5DBalk93umTy(CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,showDialogs,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ngCEfIL0MPdtvS3N5xij,iY3xS59ZAVkjhsIum1)
	CXTZu2YvNpEPkinLf8Ohlm3Rg,ZvWwXBJxzk3Qi9uAHKTD8hY2,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ccwlRNomV6SWxsG3MJT,bfTGKy2HVtpN74g = FNtoIQygCMwk3emv8h6GKaYdjUAJ0
	vrEJRkchKxtDNiqO1b79mL5eT,iBZOl3bVjWPufr0JvxphG5kIzgcF2U,aapYv0lK3Sr2COEJqwL,dgoN8FJ0VaPSybR = ZZAphuVI2C69Mt3NqTyJ1bkL(ZvWwXBJxzk3Qi9uAHKTD8hY2)
	wxcCDGXEkniWdJA = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(RDwahqjPfbdyEiTtnLQu(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬᑹ"))
	uujXZpi9nHULqr175C = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᑺ"))
	tvXK2luiTNQ7dayCDZ5 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(SE97R3Dpj6dPLweVKU(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᑻ"))
	S3kGz4CgeJp6yOBsPD2KTw = [SE97R3Dpj6dPLweVKU(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶࠫᑼ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᑽ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨᑾ"),SE97R3Dpj6dPLweVKU(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫᑿ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧᒀ"),hPFcB6Uxmabj59Iq(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰࠩᒁ")]
	RcUIGLuJvStpBhjo0g1qnl3 = ndkUxG9LtewJ if any(value in ZvWwXBJxzk3Qi9uAHKTD8hY2 for value in S3kGz4CgeJp6yOBsPD2KTw) else lvzrYTpcBaK
	if fvYGxnZNUiyP4HJkMIoS25(u"ࠧࠧࡷࡵࡰࡂ࠭ᒂ") in vrEJRkchKxtDNiqO1b79mL5eT and RcUIGLuJvStpBhjo0g1qnl3: ooQ6m4Tw1uJ7hY0GEK3j = vrEJRkchKxtDNiqO1b79mL5eT.rsplit(sH6BOz5wKRFcEg(u"ࠨࠨࡸࡶࡱࡃࠧᒃ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	else: ooQ6m4Tw1uJ7hY0GEK3j = sCHVtMAvqirbQ4BUK3cgWo
	xf3B4mLh2YGrRwQJtAMoeUdubzTNK7 = Q1siCkTZyw.SITESURLS[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᒄ")]
	HgSYTMciDE4j0sW3f8nX6xm = vrEJRkchKxtDNiqO1b79mL5eT in xf3B4mLh2YGrRwQJtAMoeUdubzTNK7 or ooQ6m4Tw1uJ7hY0GEK3j in xf3B4mLh2YGrRwQJtAMoeUdubzTNK7
	H9r8Bq10YGwe = Q1siCkTZyw.SITESURLS[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡖࡊࡖࡏࡔࠩᒅ")]
	q0PH3BVZmvr8baWldpNTy = vrEJRkchKxtDNiqO1b79mL5eT in H9r8Bq10YGwe or ooQ6m4Tw1uJ7hY0GEK3j in H9r8Bq10YGwe
	k5RO1goIxCaBLtShdmrEnwyiHvGcf = HgSYTMciDE4j0sW3f8nX6xm or q0PH3BVZmvr8baWldpNTy
	Y42YlDhFvNe = lvzrYTpcBaK
	ATCJ4O6t0vRImPU1a5uDQhM = ndkUxG9LtewJ
	DGwiQ96hX37rHjbUn1IFZTol = iBZOl3bVjWPufr0JvxphG5kIzgcF2U==None and aapYv0lK3Sr2COEJqwL==None and not RcUIGLuJvStpBhjo0g1qnl3
	if DGwiQ96hX37rHjbUn1IFZTol and k5RO1goIxCaBLtShdmrEnwyiHvGcf:
		if HgSYTMciDE4j0sW3f8nX6xm:
			UlDNcTC6OPXyLr = xf3B4mLh2YGrRwQJtAMoeUdubzTNK7.index(vrEJRkchKxtDNiqO1b79mL5eT)
			kbAQsYcGFESIUK = Q1siCkTZyw.SITESURLS[gDETKVh8mZe09Nd(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩᒆ")][UlDNcTC6OPXyLr]
			Acj1DiQBJX6v = Q1siCkTZyw.SITESURLS[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪᒇ")][UlDNcTC6OPXyLr]
			BBy7SvzcMU913DTbg0G = Q1siCkTZyw.SITESURLS[gDETKVh8mZe09Nd(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫᒈ")][UlDNcTC6OPXyLr]
			J0FI8ovETc4iqelhzpjR2XSY7DBPHd = Q1siCkTZyw.api_python_actions[UlDNcTC6OPXyLr]
			if J0FI8ovETc4iqelhzpjR2XSY7DBPHd==bGzRdmOErkIylxALniq6(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩᒉ"): ccwlRNomV6SWxsG3MJT,bfTGKy2HVtpN74g,ATCJ4O6t0vRImPU1a5uDQhM = lvzrYTpcBaK,lvzrYTpcBaK,lvzrYTpcBaK
			elif J0FI8ovETc4iqelhzpjR2XSY7DBPHd==sH6BOz5wKRFcEg(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᒊ"): Y42YlDhFvNe = ndkUxG9LtewJ
		elif q0PH3BVZmvr8baWldpNTy:
			UlDNcTC6OPXyLr = H9r8Bq10YGwe.index(vrEJRkchKxtDNiqO1b79mL5eT)
			kbAQsYcGFESIUK = Q1siCkTZyw.SITESURLS[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠶࠭ᒋ")][UlDNcTC6OPXyLr]
			Acj1DiQBJX6v = Q1siCkTZyw.SITESURLS[SE97R3Dpj6dPLweVKU(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧᒌ")][UlDNcTC6OPXyLr]
			BBy7SvzcMU913DTbg0G = Q1siCkTZyw.SITESURLS[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠳ࠨᒍ")][UlDNcTC6OPXyLr]
			J0FI8ovETc4iqelhzpjR2XSY7DBPHd = Q1siCkTZyw.api_repos_actions[UlDNcTC6OPXyLr]
	if aapYv0lK3Sr2COEJqwL==sCHVtMAvqirbQ4BUK3cgWo: aapYv0lK3Sr2COEJqwL = wxcCDGXEkniWdJA
	elif aapYv0lK3Sr2COEJqwL==None and uujXZpi9nHULqr175C in [aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡇࡕࡕࡑࠪᒎ"),sH6BOz5wKRFcEg(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᒏ")] and ccwlRNomV6SWxsG3MJT: aapYv0lK3Sr2COEJqwL = wxcCDGXEkniWdJA
	if HgSYTMciDE4j0sW3f8nX6xm or q0PH3BVZmvr8baWldpNTy: YNRdyxs6T5EKlf8 = oVwa0kcqxj1e7mLplAfZdGT(u"࠶࠵ᘇ")
	elif RcUIGLuJvStpBhjo0g1qnl3: YNRdyxs6T5EKlf8 = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠻࠶ᘈ")
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in tX4b7VxPQv5hyf18iwlBGWNOrIU: YNRdyxs6T5EKlf8 = sH6BOz5wKRFcEg(u"࠷࠰ᘉ")
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒐ"): YNRdyxs6T5EKlf8 = jwzOabysh0Z(u"࠲࠱ᘊ")
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt==IO7k2hZXSz(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩᒑ"): YNRdyxs6T5EKlf8 = SIkwCEdJHTD9v1(u"࠳࠲ᘋ")
	elif IO7k2hZXSz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫᒒ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = sH6BOz5wKRFcEg(u"࠹࠳ᘌ")
	elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡗࡍࡕࡆࡉࡃࠪᒓ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠺࠹ᘍ")
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫᒔ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = IO7k2hZXSz(u"࠶࠺ᘎ")
	elif YQNd4wejLSAVJ6T(u"ࠬࡇࡈࡘࡃࡎࠫᒕ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = aenpKvQCGVzhLXEdWiDIZ(u"࠷࠶ᘏ")
	elif aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᒖ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = aYH620Dh48GEsTFfOBSQ7r(u"࠸࠰ᘐ")
	elif bGzRdmOErkIylxALniq6(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ᒗ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = zLjWeKu6JgNO7vocUD0Qpy(u"࠳࠱ᘑ")
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡃࡎࡓࡆࡓࠧᒘ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = SIkwCEdJHTD9v1(u"࠳࠷ᘒ")
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡄࡏ࡜ࡇࡍࠨᒙ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = BWfpRku7SsM6cbE0eG(u"࠵࠳ᘓ")
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᒚ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠵࠴ᘔ")
	elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ᒛ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = EJgYdjbIiWe1apkQlZcR42(u"࠺࠵ᘕ")
	elif SE97R3Dpj6dPLweVKU(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧᒜ") in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: YNRdyxs6T5EKlf8 = hPFcB6Uxmabj59Iq(u"࠹࠶ᘖ")
	else: YNRdyxs6T5EKlf8 = oVwa0kcqxj1e7mLplAfZdGT(u"࠷࠵ᘗ")
	AA2XCzuIf9mrY1vijVy = (iBZOl3bVjWPufr0JvxphG5kIzgcF2U!=None)
	H0JPAb8dNjKa = (aapYv0lK3Sr2COEJqwL!=None and uujXZpi9nHULqr175C!=aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡓࡕࡑࡓࠫᒝ"))
	if AA2XCzuIf9mrY1vijVy and not RcUIGLuJvStpBhjo0g1qnl3: iRaHzNpJhSx6ZnCfrvD7j93lks(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧหใ฼๎้ࠦศา๊ๆื๏ࠦัใ็ࠪᒞ"),iBZOl3bVjWPufr0JvxphG5kIzgcF2U)
	elif H0JPAb8dNjKa: iRaHzNpJhSx6ZnCfrvD7j93lks(jwzOabysh0Z(u"ࠨฬไ฽๏๊ࠠࡅࡐࡖࠤึ่ๅࠨᒟ"),aapYv0lK3Sr2COEJqwL)
	if AA2XCzuIf9mrY1vijVy:
		qP6NKJiZ8e1wfSzC = {YQNd4wejLSAVJ6T(u"ࠤ࡫ࡸࡹࡶࠢᒠ"):iBZOl3bVjWPufr0JvxphG5kIzgcF2U,BWfpRku7SsM6cbE0eG(u"ࠥ࡬ࡹࡺࡰࡴࠤᒡ"):iBZOl3bVjWPufr0JvxphG5kIzgcF2U}
		IZzpg2kucW8fXjb9lHA10JVRy3n6Mm = iBZOl3bVjWPufr0JvxphG5kIzgcF2U
	else: qP6NKJiZ8e1wfSzC,IZzpg2kucW8fXjb9lHA10JVRy3n6Mm = {},sCHVtMAvqirbQ4BUK3cgWo
	if H0JPAb8dNjKa:
		import urllib3.util.connection as Y6VjgSTnFPIz14JKwtC
		iFno95x7tC = xhZzF68kis0YbMq(Y6VjgSTnFPIz14JKwtC,wxcCDGXEkniWdJA,ndkUxG9LtewJ)
	OMvtWxaKkjHLbhFzZi5Gc3rBU6Aqs,pZ3BTamb0Ilo9AsOg4,KzUgMjo5wIn7,GP2y79OISZ,BBLXCe7VrNyOlzMAwIGu8amtH,RM02Hfc5hqL3nPsBgQjX,verify = JJi0fB5bAKNCmDTrdWeFajvop289,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,CXTZu2YvNpEPkinLf8Ohlm3Rg,lvzrYTpcBaK,lvzrYTpcBaK,lvzrYTpcBaK,dgoN8FJ0VaPSybR
	if Y42YlDhFvNe: BBLXCe7VrNyOlzMAwIGu8amtH = ndkUxG9LtewJ
	if k5RO1goIxCaBLtShdmrEnwyiHvGcf or JJi0fB5bAKNCmDTrdWeFajvop289: OMvtWxaKkjHLbhFzZi5Gc3rBU6Aqs = lvzrYTpcBaK
	ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN = -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,IOHSz7YPF9WusGgUt1Dq(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫᒢ")
	x4dA3jP29GZXhVveMJ = lvzrYTpcBaK
	if not Q1siCkTZyw.FORWARDS_HOSTNAMES: Q1siCkTZyw.FORWARDS_HOSTNAMES = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡪࡩࡤࡶࠪᒣ"),Js61GTdX5wzMurUqi7Z(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠵ࠫᒤ"),qqw1upCsKM(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᒥ"))
	bcjX8vr6wpsJFDy7e = []
	while vrEJRkchKxtDNiqO1b79mL5eT not in bcjX8vr6wpsJFDy7e and vrEJRkchKxtDNiqO1b79mL5eT in list(Q1siCkTZyw.FORWARDS_HOSTNAMES.keys()):
		bcjX8vr6wpsJFDy7e.append(vrEJRkchKxtDNiqO1b79mL5eT)
		vrEJRkchKxtDNiqO1b79mL5eT = Q1siCkTZyw.FORWARDS_HOSTNAMES[vrEJRkchKxtDNiqO1b79mL5eT]
	da3O1IK4XZx2uLVCMmcGNJpqjHoRY9 = i68iPmaHVAZknGv2SNpyzCwcFE
	if HgSYTMciDE4j0sW3f8nX6xm:
		KzUgMjo5wIn7 = oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡒࡒࡗ࡙࠭ᒦ")
		HSNYwERMjzyxmrPku[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡄ࡚࠲ࡋ࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᒧ")] = qqw1upCsKM(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᒨ")
		YK8cqOm07g5aBZQph = Kdnrl9JHV0cFaGzC5bN.dumps(i68iPmaHVAZknGv2SNpyzCwcFE)
		da3O1IK4XZx2uLVCMmcGNJpqjHoRY9 = MLSsdPul803Tn4WBeGkZp6aQc(YK8cqOm07g5aBZQph,oVwa0kcqxj1e7mLplAfZdGT(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷ᘘ"))
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT+EJgYdjbIiWe1apkQlZcR42(u"ࠫࡄࡻࡳࡦࡴࡀࠫᒩ")+IRqQOePKNclx1td
	import requests as xu5ndl3mkU2
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(t19ZOVHA4CpwFKaeiubcMGvz(u"࠺ᘙ")):
		bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
		if ruCEzOyVgmGt9WHI7BSofF6d8:
			pZ3BTamb0Ilo9AsOg4 = aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭ᒪ")
			try: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.close()
			except: pass
		if RcUIGLuJvStpBhjo0g1qnl3 or not AA2XCzuIf9mrY1vijVy: oTwfq964iZjEhD0(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓ࡝ࡶࡒࡔࡊࡔ࡟ࡖࡔࡏࠫᒫ"),vrEJRkchKxtDNiqO1b79mL5eT,da3O1IK4XZx2uLVCMmcGNJpqjHoRY9,HSNYwERMjzyxmrPku,pZ3BTamb0Ilo9AsOg4,KzUgMjo5wIn7)
		rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT
		try:
			mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = xu5ndl3mkU2.request(KzUgMjo5wIn7,vrEJRkchKxtDNiqO1b79mL5eT,data=da3O1IK4XZx2uLVCMmcGNJpqjHoRY9,headers=HSNYwERMjzyxmrPku,verify=verify,allow_redirects=OMvtWxaKkjHLbhFzZi5Gc3rBU6Aqs,timeout=YNRdyxs6T5EKlf8,proxies=qP6NKJiZ8e1wfSzC)
			if qqw1upCsKM(u"࠵࠳࠴ᘚ")<=mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.status_code<=aYH620Dh48GEsTFfOBSQ7r(u"࠶࠽࠾ᘛ"):
				if not GP2y79OISZ:
					B17r2fdFy9ns8tiOMLu = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers.get(jwzOabysh0Z(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᒬ")) or mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers.get(fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᒭ")) or sCHVtMAvqirbQ4BUK3cgWo
					if B17r2fdFy9ns8tiOMLu: vrEJRkchKxtDNiqO1b79mL5eT = B17r2fdFy9ns8tiOMLu.strip(sH6BOz5wKRFcEg(u"ࠩ࠽ࠫᒮ"))
					else: GP2y79OISZ = ndkUxG9LtewJ
					if not GP2y79OISZ: vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.encode(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡰࡦࡺࡩ࡯࠳ࠪᒯ"),jwzOabysh0Z(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᒰ")).decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᒱ"))
					if k5RO1goIxCaBLtShdmrEnwyiHvGcf and mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.status_code==t19ZOVHA4CpwFKaeiubcMGvz(u"࠷࠵࠽ᘜ"):
						OMvtWxaKkjHLbhFzZi5Gc3rBU6Aqs = JJi0fB5bAKNCmDTrdWeFajvop289
						KzUgMjo5wIn7 = CXTZu2YvNpEPkinLf8Ohlm3Rg
						GP2y79OISZ = ndkUxG9LtewJ
						LLoCexPTUGs8ji1M2y
				if not GP2y79OISZ or JJi0fB5bAKNCmDTrdWeFajvop289:
					if fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡨࡵࡶࡳࠫᒲ") not in vrEJRkchKxtDNiqO1b79mL5eT:
						ha6z5Ufv0kdDwqPo = GABnmSFOwtsu37(rdQ5tOIzuelfvcYbNsM,jwzOabysh0Z(u"ࠧࡶࡴ࡯ࠫᒳ"))
						vrEJRkchKxtDNiqO1b79mL5eT = ha6z5Ufv0kdDwqPo+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨ࠱ࠪᒴ")+vrEJRkchKxtDNiqO1b79mL5eT.lstrip(sH6BOz5wKRFcEg(u"ࠩ࠲ࠫᒵ"))
				if vrEJRkchKxtDNiqO1b79mL5eT!=rdQ5tOIzuelfvcYbNsM:
					Q1siCkTZyw.FORWARDS_HOSTNAMES[rdQ5tOIzuelfvcYbNsM] = vrEJRkchKxtDNiqO1b79mL5eT
					x4dA3jP29GZXhVveMJ = ndkUxG9LtewJ
				if not GP2y79OISZ:
					Y624n1PjAvVtq80KBuZfgcGosCw = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
					if FA0Y1k9va5O2zmU6By(vrEJRkchKxtDNiqO1b79mL5eT): GP2y79OISZ = ndkUxG9LtewJ
			elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠻࠵࠱ᘞ")<=mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.status_code<=jwzOabysh0Z(u"࠺࠿࠹ᘝ"): BBLXCe7VrNyOlzMAwIGu8amtH = ndkUxG9LtewJ
			else: GP2y79OISZ = ndkUxG9LtewJ
			if not GP2y79OISZ and not JJi0fB5bAKNCmDTrdWeFajvop289 and Y624n1PjAvVtq80KBuZfgcGosCw.headers: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G = Y624n1PjAvVtq80KBuZfgcGosCw
			rdQ5tOIzuelfvcYbNsM = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.url
			ltE6Cgu1AyjR8Dde = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.status_code
			j7CADXI1yWt90Gc52HrsUhKeN = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.reason
			mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.raise_for_status()
			bEZlOa1inyrUgdTw9BKNtcMCLYI = ndkUxG9LtewJ
		except xu5ndl3mkU2.exceptions.HTTPError as QQa32JB7je0XdftAuz6yvxZsrViPo:
			pass
		except xu5ndl3mkU2.exceptions.Timeout as QQa32JB7je0XdftAuz6yvxZsrViPo:
			if qdUK5ioJyrO1T: j7CADXI1yWt90Gc52HrsUhKeN = str(QQa32JB7je0XdftAuz6yvxZsrViPo.message).split(aYH620Dh48GEsTFfOBSQ7r(u"ࠪ࠾ࠥ࠭ᒶ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			else: j7CADXI1yWt90Gc52HrsUhKeN = str(QQa32JB7je0XdftAuz6yvxZsrViPo).split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࠿ࠦࠧᒷ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		except xu5ndl3mkU2.exceptions.ConnectionError as QQa32JB7je0XdftAuz6yvxZsrViPo:
			try: YPL6cq2GuCUHwKZE = QQa32JB7je0XdftAuz6yvxZsrViPo.message[BewrUo9ANCa17G43Sn0LH5xh]
			except: YPL6cq2GuCUHwKZE = str(QQa32JB7je0XdftAuz6yvxZsrViPo)
			gm8ZDbQkpOEv = fNntYJW45mEFSdRX8g.findall(Js61GTdX5wzMurUqi7Z(u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢᒸ"),YPL6cq2GuCUHwKZE)
			if not gm8ZDbQkpOEv: gm8ZDbQkpOEv = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࠬࠡࡧࡵࡶࡴࡸ࡜ࠩࠪ࡟ࡨ࠰࠯ࠬࠡࠩࠫ࠲࠯ࡅࠩࠨࠤᒹ"),YPL6cq2GuCUHwKZE)
			if not gm8ZDbQkpOEv:
				RLMfmFr2jZ = fNntYJW45mEFSdRX8g.findall(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠻࠰࠭ࡃ࠭ࡢࡤࠬࠫ࠽ࠦᒺ"),YPL6cq2GuCUHwKZE)
				if RLMfmFr2jZ: gm8ZDbQkpOEv = [RLMfmFr2jZ[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],RLMfmFr2jZ[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh]]
			if not gm8ZDbQkpOEv: gm8ZDbQkpOEv = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"ࠣ࠼ࠫࡠࡩ࠱ࠩ࠻ࠢࠫ࠲࠯ࡅࠩࠨࠤᒻ"),YPL6cq2GuCUHwKZE)
			if not gm8ZDbQkpOEv: gm8ZDbQkpOEv = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠤࠣࠬࡡࡪࠫࠪ࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᒼ"),YPL6cq2GuCUHwKZE)
			try: ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN = gm8ZDbQkpOEv[BewrUo9ANCa17G43Sn0LH5xh]
			except: ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN = -rgpY5VUqKbeFOCD9Nki2SmGvxEja,YPL6cq2GuCUHwKZE
		except xu5ndl3mkU2.exceptions.RequestException as QQa32JB7je0XdftAuz6yvxZsrViPo:
			if qdUK5ioJyrO1T: j7CADXI1yWt90Gc52HrsUhKeN = QQa32JB7je0XdftAuz6yvxZsrViPo.message
			else: j7CADXI1yWt90Gc52HrsUhKeN = str(QQa32JB7je0XdftAuz6yvxZsrViPo)
		except:
			try: ltE6Cgu1AyjR8Dde = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.status_code
			except: pass
			try: j7CADXI1yWt90Gc52HrsUhKeN = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.reason
			except: pass
		j7CADXI1yWt90Gc52HrsUhKeN = str(j7CADXI1yWt90Gc52HrsUhKeN)
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡢࡴࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᒽ")+str(ltE6Cgu1AyjR8Dde)+bGzRdmOErkIylxALniq6(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᒾ")+j7CADXI1yWt90Gc52HrsUhKeN+zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᒿ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+gDETKVh8mZe09Nd(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᓀ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+gDETKVh8mZe09Nd(u"ࠧࠡ࡟ࠪᓁ"))
		if DGwiQ96hX37rHjbUn1IFZTol and k5RO1goIxCaBLtShdmrEnwyiHvGcf and not BBLXCe7VrNyOlzMAwIGu8amtH and ltE6Cgu1AyjR8Dde!=TzIj50KpohEOHx6CbZWqB(u"࠲࠱࠲ᘟ") and gDETKVh8mZe09Nd(u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫᓂ") not in vrEJRkchKxtDNiqO1b79mL5eT:
			if vrEJRkchKxtDNiqO1b79mL5eT not in [kbAQsYcGFESIUK,Acj1DiQBJX6v,BBy7SvzcMU913DTbg0G]: vrEJRkchKxtDNiqO1b79mL5eT,BBLXCe7VrNyOlzMAwIGu8amtH = kbAQsYcGFESIUK,lvzrYTpcBaK
			elif vrEJRkchKxtDNiqO1b79mL5eT==kbAQsYcGFESIUK: vrEJRkchKxtDNiqO1b79mL5eT,BBLXCe7VrNyOlzMAwIGu8amtH = Acj1DiQBJX6v,lvzrYTpcBaK
			elif vrEJRkchKxtDNiqO1b79mL5eT==Acj1DiQBJX6v: vrEJRkchKxtDNiqO1b79mL5eT,BBLXCe7VrNyOlzMAwIGu8amtH = BBy7SvzcMU913DTbg0G,ndkUxG9LtewJ
			continue
		if not GP2y79OISZ and bEZlOa1inyrUgdTw9BKNtcMCLYI: continue
		break
	ltE6Cgu1AyjR8Dde = int(ltE6Cgu1AyjR8Dde)
	if not bEZlOa1inyrUgdTw9BKNtcMCLYI:
		DDZkNLtrFyew6IWbd7JlhjqQSO1 = dk5CWBPUzZ8vpuRNFjmQIysAc9hKeM(hPFcB6Uxmabj59Iq(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪᓃ"),EJgYdjbIiWe1apkQlZcR42(u"࠹࠲ᘠ"))
		if DDZkNLtrFyew6IWbd7JlhjqQSO1==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,Js61GTdX5wzMurUqi7Z(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࠡࡆࡌࡗࡈࡕࡎࡏࡇࡆࡘࡊࡊࠠࠡࠢࡗ࡬ࡪࠦࡤࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡱࡳࡹࠦࡣࡰࡰࡱࡩࡨࡺࡥࡥࠢࡷࡳࠥࡺࡨࡦࠢ࡬ࡲࡹ࡫ࡲ࡯ࡧࡷࠤࠦࠧࠧᓄ"))
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"้๊ࠫริใࠣะ์อาไࠢ฽๎ึࠦๅาส๋฻ࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐ำหะา้ࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลฺัสำฬะࠠอ้สึฺ่๋ࠦำูࠣา๐อสࠢ࡟ࡲࡡࡴࠠๅฯ็ࠤฬ๊ๅีๅ็อࠥะรไัࠣว๋ࠦฬ่ษี็๋ࠥัษฺ๊ࠤอ฽ั๋ไฬࠤฺำ๊ฮหࠣฬฬ๊ล็ฬิ๊ฯ่ࠦโ์๊ࠤฬ๊ล็ฬิ๊ฯࠦสฺ็็ࠤอ฻่าหࠣะ๏ีษࠨᓅ"))
			xxpJdCwRN6SrscbOmga7h5UlHBiW()
			return mmVhCYRLZI9oUfpcBzWiKJqNle6P2G
	if not bEZlOa1inyrUgdTw9BKNtcMCLYI and bcjX8vr6wpsJFDy7e:
		for url in bcjX8vr6wpsJFDy7e:
			if url in list(Q1siCkTZyw.FORWARDS_HOSTNAMES.keys()):
				del Q1siCkTZyw.FORWARDS_HOSTNAMES[url]
				x4dA3jP29GZXhVveMJ = ndkUxG9LtewJ
	if x4dA3jP29GZXhVveMJ:
		kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠴ࠪᓆ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᓇ"),Q1siCkTZyw.FORWARDS_HOSTNAMES,OOht4Ly9dmZMIz)
		Q1siCkTZyw.FORWARDS_HOSTNAMES = {}
	if aapYv0lK3Sr2COEJqwL!=None and uujXZpi9nHULqr175C!=phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡔࡖࡒࡔࠬᓈ"): Y6VjgSTnFPIz14JKwtC.create_connection = iFno95x7tC
	if uujXZpi9nHULqr175C==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨᓉ") and ccwlRNomV6SWxsG3MJT: aapYv0lK3Sr2COEJqwL = None
	if not bEZlOa1inyrUgdTw9BKNtcMCLYI and iBZOl3bVjWPufr0JvxphG5kIzgcF2U==None and zVbp6yjdF3qKkTvhDsJX9fgMceCuxt not in tX4b7VxPQv5hyf18iwlBGWNOrIU:
		Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
		if Ro2CsQFGOj14wKIgcuHJ!=BWfpRku7SsM6cbE0eG(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᓊ"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
	CxP3d82yUTnMa = Rxc41oNqDF()
	if RcUIGLuJvStpBhjo0g1qnl3: rdQ5tOIzuelfvcYbNsM = ooQ6m4Tw1uJ7hY0GEK3j
	if not rdQ5tOIzuelfvcYbNsM: rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT
	CxP3d82yUTnMa.url = rdQ5tOIzuelfvcYbNsM
	CxP3d82yUTnMa.scrape = RcUIGLuJvStpBhjo0g1qnl3
	try:
		HSrmwdqBFbvkVJ = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers
		if not HSrmwdqBFbvkVJ.get(aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᓋ")) and not HSrmwdqBFbvkVJ.get(qqw1upCsKM(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᓌ")): HSrmwdqBFbvkVJ.headers[BWfpRku7SsM6cbE0eG(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᓍ")] = rdQ5tOIzuelfvcYbNsM
	except: HSrmwdqBFbvkVJ = {}
	try:
		CCfbK58TvPGXn0 = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.content
		if HgSYTMciDE4j0sW3f8nX6xm and CCfbK58TvPGXn0:
			fK940diGVI6b = {StN8fF7ynudQqDbYmV4EJX.lower(): I3qosYg7HjWda1uEJexb0wOPhlFn8B for StN8fF7ynudQqDbYmV4EJX, I3qosYg7HjWda1uEJexb0wOPhlFn8B in mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.headers.items()}
			if fK940diGVI6b.get(jwzOabysh0Z(u"࠭ࡡࡷ࠯ࡨࡲࡨࡸࡹࡱࡶ࡬ࡳࡳ࠭ᓎ"))==aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠳࠱࠴ࠬᓏ"):
				CCfbK58TvPGXn0,ENvtPw6MZKm9g = EBA1sh2eDxfKZ(CCfbK58TvPGXn0,qeG16a4pbSHziNVQ2uFXrs(u"࠺࠴࠶࠼࠺࠹࠴࠷࠹ᘡ"))
				if ENvtPw6MZKm9g==E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡋࡑ࡚ࡆࡒࡉࡅࡡࡗࡍࡒࡋࡓࡕࡃࡐࡔࠬᓐ"):
					j7CADXI1yWt90Gc52HrsUhKeN,ltE6Cgu1AyjR8Dde = BWfpRku7SsM6cbE0eG(u"ࠩࡌࡲࡻࡧ࡬ࡪࡦࠣࡅࡕࡏࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࠪᓑ"),-tBMCpcY2vUV1dEjZ7PDG
					bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
					CCfbK58TvPGXn0 = j7CADXI1yWt90Gc52HrsUhKeN
	except: CCfbK58TvPGXn0 = sCHVtMAvqirbQ4BUK3cgWo
	if I5VKjrFL0Bk97 and isinstance(CCfbK58TvPGXn0,bytes):
		try: CCfbK58TvPGXn0 = CCfbK58TvPGXn0.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		except: CCfbK58TvPGXn0 = CCfbK58TvPGXn0.decode(sfaeVtLiZh3xYJ9P)
	if HgSYTMciDE4j0sW3f8nX6xm and CCfbK58TvPGXn0 and XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠹࠺࠶ᘣ")<=ltE6Cgu1AyjR8Dde<=BWfpRku7SsM6cbE0eG(u"࠸࠽࠾ᘢ"): j7CADXI1yWt90Gc52HrsUhKeN = CCfbK58TvPGXn0
	try: zADt21IvBV7dkQspenjG5J = mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.cookies.get_dict()
	except: zADt21IvBV7dkQspenjG5J = {}
	try: mmVhCYRLZI9oUfpcBzWiKJqNle6P2G.close()
	except: pass
	CxP3d82yUTnMa.code = ltE6Cgu1AyjR8Dde
	CxP3d82yUTnMa.reason = j7CADXI1yWt90Gc52HrsUhKeN
	CxP3d82yUTnMa.content = CCfbK58TvPGXn0
	CxP3d82yUTnMa.headers = HSrmwdqBFbvkVJ
	CxP3d82yUTnMa.cookies = zADt21IvBV7dkQspenjG5J
	CxP3d82yUTnMa.succeeded = bEZlOa1inyrUgdTw9BKNtcMCLYI
	CxP3d82yUTnMa.scrapernumber = sCHVtMAvqirbQ4BUK3cgWo
	CxP3d82yUTnMa.scraperserver = sCHVtMAvqirbQ4BUK3cgWo
	CxP3d82yUTnMa.scraperurl = sCHVtMAvqirbQ4BUK3cgWo
	if qdUK5ioJyrO1T or isinstance(CxP3d82yUTnMa.content,str): AAjQSKuWFwzB60CI7hOUgvJbDrmk9X = CxP3d82yUTnMa.content.lower()
	else: AAjQSKuWFwzB60CI7hOUgvJbDrmk9X = sCHVtMAvqirbQ4BUK3cgWo
	DJdqw1257bxYUocfmEAg = (gDETKVh8mZe09Nd(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᓒ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X or oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᓓ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X) and AAjQSKuWFwzB60CI7hOUgvJbDrmk9X.count(Js61GTdX5wzMurUqi7Z(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᓔ"))>rgpY5VUqKbeFOCD9Nki2SmGvxEja and fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᓕ") not in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt and zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩᓖ") not in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X and not RcUIGLuJvStpBhjo0g1qnl3
	ppGgAy7uPqUZ = (XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡸࡨࡶ࡮࡬ࡹ࠯ࡪࡷࡱࡱࡅࡲࡦࡦ࡬ࡶࡪࡩࡴ࠾ࠩᓗ") in rdQ5tOIzuelfvcYbNsM)
	if ltE6Cgu1AyjR8Dde==Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠷࠶࠰ᘤ") and (DJdqw1257bxYUocfmEAg or ppGgAy7uPqUZ):
		CxP3d82yUTnMa.succeeded = lvzrYTpcBaK
	if CxP3d82yUTnMa.succeeded and DGwiQ96hX37rHjbUn1IFZTol and k5RO1goIxCaBLtShdmrEnwyiHvGcf:
		Uypv0Wze2S9T1mdRKoMDw4k7EqG8L = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪᓘ")+i68iPmaHVAZknGv2SNpyzCwcFE[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪ࡮ࡴࡨࠧᓙ")].upper().replace(YQNd4wejLSAVJ6T(u"ࠫࡌࡋࡔࠨᓚ"),sCHVtMAvqirbQ4BUK3cgWo) if Y42YlDhFvNe else J0FI8ovETc4iqelhzpjR2XSY7DBPHd
		jq1yMu9V5Bt3lxh6K(Uypv0Wze2S9T1mdRKoMDw4k7EqG8L)
	if not CxP3d82yUTnMa.succeeded and DGwiQ96hX37rHjbUn1IFZTol:
		y5xOmdu2DwQJzcsjZtrFvM8UE = (BWfpRku7SsM6cbE0eG(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩᓛ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X and jwzOabysh0Z(u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨᓜ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X)
		vKfrpSZaLHBWRuAXoGq607it = (wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧ࠶ࠢࡶࡩࡨ࠭ᓝ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X and IOHSz7YPF9WusGgUt1Dq(u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩᓞ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X)
		rJPabSGoYW = (ltE6Cgu1AyjR8Dde in [bGzRdmOErkIylxALniq6(u"࠺࠰࠴ᘥ")] and IOHSz7YPF9WusGgUt1Dq(u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬᓟ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X)
		z9Oj5ZLeryoaUs2TiBh = (hPFcB6Uxmabj59Iq(u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬᓠ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X and Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨᓡ") in AAjQSKuWFwzB60CI7hOUgvJbDrmk9X)
		EEb6t7WBfhMZ2 = (BWfpRku7SsM6cbE0eG(u"ࠬ࡝ࡒࡐࡐࡊࡣ࡛ࡋࡒࡔࡋࡒࡒࡤࡔࡕࡎࡄࡈࡖࠬᓢ") in j7CADXI1yWt90Gc52HrsUhKeN or E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡷࡳࡱࡱ࡫ࠥࡼࡥࡳࡵ࡬ࡳࡳࠦ࡮ࡶ࡯ࡥࡩࡷ࠭ᓣ") in j7CADXI1yWt90Gc52HrsUhKeN)
		if   DJdqw1257bxYUocfmEAg: j7CADXI1yWt90Gc52HrsUhKeN = aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧᓤ")
		elif y5xOmdu2DwQJzcsjZtrFvM8UE: j7CADXI1yWt90Gc52HrsUhKeN = aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩᓥ")
		elif vKfrpSZaLHBWRuAXoGq607it: j7CADXI1yWt90Gc52HrsUhKeN = qqw1upCsKM(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩᓦ")
		elif rJPabSGoYW: j7CADXI1yWt90Gc52HrsUhKeN = jwzOabysh0Z(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶࠤࡩ࡫࡮ࡪࡧࡧࠫᓧ")
		elif z9Oj5ZLeryoaUs2TiBh: j7CADXI1yWt90Gc52HrsUhKeN = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭ᓨ")
		elif ppGgAy7uPqUZ: j7CADXI1yWt90Gc52HrsUhKeN = bGzRdmOErkIylxALniq6(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡰ࡭ࡸࡹࡩ࡯ࡩࠣ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠠࡤࡪࡨࡧࡰ࠭ᓩ")
		elif EEb6t7WBfhMZ2: j7CADXI1yWt90Gc52HrsUhKeN = qqw1upCsKM(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡽࡴࡻࡲࠡࡰࡨࡸࡼࡵࡲ࡬ࠢࡧࡩࡻ࡯ࡣࡦࡵࠪᓪ")
		else: j7CADXI1yWt90Gc52HrsUhKeN = str(j7CADXI1yWt90Gc52HrsUhKeN)
		if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in K4b0LHxYq2: pass
		elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in tX4b7VxPQv5hyf18iwlBGWNOrIU:
			SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SE97R3Dpj6dPLweVKU(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᓫ")+str(ltE6Cgu1AyjR8Dde)+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᓬ")+j7CADXI1yWt90Gc52HrsUhKeN+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᓭ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+jwzOabysh0Z(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᓮ")+vrEJRkchKxtDNiqO1b79mL5eT+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࠥࡣࠧᓯ"))
		else: SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+TzIj50KpohEOHx6CbZWqB(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᓰ")+str(ltE6Cgu1AyjR8Dde)+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨᓱ")+j7CADXI1yWt90Gc52HrsUhKeN+zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᓲ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+YQNd4wejLSAVJ6T(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᓳ")+vrEJRkchKxtDNiqO1b79mL5eT+EJgYdjbIiWe1apkQlZcR42(u"ࠩࠣࡡࠬᓴ"))
		KnhF0THdoRVipUZmx8sAfXg7P = ooQ6m4Tw1uJ7hY0GEK3j if RcUIGLuJvStpBhjo0g1qnl3 else mSeoVfgRpNF9PKrJ(vrEJRkchKxtDNiqO1b79mL5eT)
		if qdUK5ioJyrO1T and isinstance(KnhF0THdoRVipUZmx8sAfXg7P,unicode): KnhF0THdoRVipUZmx8sAfXg7P = KnhF0THdoRVipUZmx8sAfXg7P.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		if k5RO1goIxCaBLtShdmrEnwyiHvGcf: KnhF0THdoRVipUZmx8sAfXg7P = KnhF0THdoRVipUZmx8sAfXg7P.split(SE97R3Dpj6dPLweVKU(u"ࠪ࠳ࠬᓵ"))[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		nxzrQgAItNskH0lFimGMRO3KW = str(j7CADXI1yWt90Gc52HrsUhKeN)+qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡡࡴࠨࠨᓶ")+KnhF0THdoRVipUZmx8sAfXg7P+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠯ࠧᓷ")
		if any([DJdqw1257bxYUocfmEAg,y5xOmdu2DwQJzcsjZtrFvM8UE,vKfrpSZaLHBWRuAXoGq607it,rJPabSGoYW,z9Oj5ZLeryoaUs2TiBh,ppGgAy7uPqUZ,EEb6t7WBfhMZ2]) and bfTGKy2HVtpN74g:
			if not EEb6t7WBfhMZ2:
				CxP3d82yUTnMa.code = -vUnJhT2NO8yirHcAmg
				II3OJXBgwTiKAykLV = aYH620Dh48GEsTFfOBSQ7r(u"࠭็ั้ࠣห้฻แฮห่ࠣฬ๊ࠦๆๅ้ࠤั๊ศ่ษ้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲࠳ࠦไฤ่ࠣ฽้๐็ศ้ࠢ์฾ࠦๅ็ࠢส่าาศࠡ์่๊฾ࠦศาษ่ะࠥอไไ๊่ฬ๏๎สา่๊ࠢࠥาไษ๋ࠢๅฯำ้ࠠษึฮำีวๆ๊ࠢิฬࠦวๅ่๋฽๋ࠥๆࠡษ็ูๆำวหࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣ๎ุะื๋฻ࠣว๋๊ࠦฮษ๋่ࠥอำหะาห๊ࠦล็ฬิ๊ฯࠦรฯำ์ࠤ้ะฬศ๊ีࠤ์ึวࠡษ็ััฮࠠ࠯࠰่่ࠣ์ࠠๅษࠣ๎ําฯุ่ࠡห๋ࠦร็๊ࠢิ์ࠦวๅ็ะหํ๊ษࠡี๋ๅࠥะๆอฯ࡟ࡲࠬᓸ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡆࡴࡵࡳࡷࠦࡃࡰࡦࡨ࠾ࠥࠦࠧᓹ")+str(CxP3d82yUTnMa.code)+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+RDwahqjPfbdyEiTtnLQu(u"ࠨ้็ࠤฯื๊ะ่๊ࠢࠥฮั็ษ่ะࠥ฿ๅศัࠣว๋๊ࠦฮษ๋่ࠥะฬศ๊ีࠤ์ึวࠡษ็ััฮࠠภࠣࠪᓺ")+B8alA5nvIhTxQ
			else:
				CxP3d82yUTnMa.code = -kK7gj9HE462hADJbvr
				II3OJXBgwTiKAykLV = aenpKvQCGVzhLXEdWiDIZ(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฯ๋ๆฺࠢไฮาࠦศฺุูࠣๆำวหࠢส่ส์สา่อࠤฬ๊ึา๊ิ๎ฮࠦ࠮࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣฮ่๎ๆࠡ็้ࠤฬ๊ัศ๊อีࠥ฿ๆะๅࠣวํࠦๅ็ࠢหี๋อๅอࠢ฼๊ิ้ࠠฤ๊้๋ࠣࠦฬ่ษีࠤ฾์ฯไࠢ࠱࠲ࠥ๎ุ๋ใอ๋ࠥอไฮ็ส๎ฮࠦึะࠢส่ๆ๐ั้ีสฮࠥษุ่ࠡาࠤฬ๊สอีึࠤศ๎ࠠืัࠣห้ฮัศ็ฯࠤฬ๊ๅลาํอࠥ࠴࠮ࠡๆะ่ࠥอไๆึๆ่ฮ๊ࠦอสࠣษ๏่วโ๊ࠢิ์ࠦวๅฯ่ห๏ฯࠠศๆัห฼ฬษ࡝ࡰࠪᓻ")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡉࡷࡸ࡯ࡳࠢࡆࡳࡩ࡫࠺ࠡࠢࠪᓼ")+str(CxP3d82yUTnMa.code)+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+BWfpRku7SsM6cbE0eG(u"ࠫ์๊ࠠหำํำ๋ࠥๆࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร็ࠢํัฬ๎ไࠡษึฮำีวๆࠢศ๊ฯืๆหࠢฦาึ๏ࠠๅฬฯหํุ่ࠠา๊ࠤฬ๊อๆษํอࠥลࠡࠨᓽ")+B8alA5nvIhTxQ
			bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,II3OJXBgwTiKAykLV)
			if bR4jqNrpMesHt93OgGKi6WDVaQA:
				vBIjcfMhKJyYbtRlXEnH719Nuqpds8 = dETqR0pCNwmv4PWuUOBt5rXcAh(CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,da3O1IK4XZx2uLVCMmcGNJpqjHoRY9,HSNYwERMjzyxmrPku,JJi0fB5bAKNCmDTrdWeFajvop289,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,ltE6Cgu1AyjR8Dde,j7CADXI1yWt90Gc52HrsUhKeN)
				if vBIjcfMhKJyYbtRlXEnH719Nuqpds8.succeeded: return vBIjcfMhKJyYbtRlXEnH719Nuqpds8
		bR4jqNrpMesHt93OgGKi6WDVaQA = ndkUxG9LtewJ
		if (uujXZpi9nHULqr175C==RDwahqjPfbdyEiTtnLQu(u"ࠬࡇࡓࡌࠩᓾ") or tvXK2luiTNQ7dayCDZ5==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡁࡔࡍࠪᓿ")) and (ccwlRNomV6SWxsG3MJT or bfTGKy2HVtpN74g):
			bR4jqNrpMesHt93OgGKi6WDVaQA = DDuLcAv3Xl1b54tHBs(ltE6Cgu1AyjR8Dde,nxzrQgAItNskH0lFimGMRO3KW,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,wwKJzPUNesqLXrGZ6V5dC4B)
			if bR4jqNrpMesHt93OgGKi6WDVaQA and uujXZpi9nHULqr175C==SIkwCEdJHTD9v1(u"ࠧࡂࡕࡎࠫᔀ"): uujXZpi9nHULqr175C = Js61GTdX5wzMurUqi7Z(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪᔁ")
			else: uujXZpi9nHULqr175C = BWfpRku7SsM6cbE0eG(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᔂ")
			if bR4jqNrpMesHt93OgGKi6WDVaQA and tvXK2luiTNQ7dayCDZ5==GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡅࡘࡑࠧᔃ"): tvXK2luiTNQ7dayCDZ5 = bGzRdmOErkIylxALniq6(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᔄ")
			else: tvXK2luiTNQ7dayCDZ5 = GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᔅ")
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᔆ"),uujXZpi9nHULqr175C)
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(qqw1upCsKM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᔇ"),tvXK2luiTNQ7dayCDZ5)
		if bR4jqNrpMesHt93OgGKi6WDVaQA:
			if ltE6Cgu1AyjR8Dde==aenpKvQCGVzhLXEdWiDIZ(u"࠸ᘦ") and IO7k2hZXSz(u"ࠨࡪࡷࡸࡵࡹࠧᔈ") in vrEJRkchKxtDNiqO1b79mL5eT and ATCJ4O6t0vRImPU1a5uDQhM:
				if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(BWfpRku7SsM6cbE0eG(u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩᔉ"),sH6BOz5wKRFcEg(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᔊ"),hDjf1Ubgq629nXlOvcFLH4Jw=zLjWeKu6JgNO7vocUD0Qpy(u"࠳࠲࠳࠴ᘧ"))
				rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT+SIkwCEdJHTD9v1(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᔋ")
				GGySQr6d3Tn7iLDkXAINbF2M = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,rdQ5tOIzuelfvcYbNsM,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,wwKJzPUNesqLXrGZ6V5dC4B,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠵ࡲࡩ࠭ᔌ"))
				if GGySQr6d3Tn7iLDkXAINbF2M.succeeded:
					CxP3d82yUTnMa = GGySQr6d3Tn7iLDkXAINbF2M
					SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+bGzRdmOErkIylxALniq6(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᔍ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᔎ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+YQNd4wejLSAVJ6T(u"ࠨࠢࡠࠫᔏ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(qeG16a4pbSHziNVQ2uFXrs(u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ᔐ"),qqw1upCsKM(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᔑ"),hDjf1Ubgq629nXlOvcFLH4Jw=E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠴࠳࠴࠵ᘨ"))
				else:
					SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᔒ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+hPFcB6Uxmabj59Iq(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᔓ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+SE97R3Dpj6dPLweVKU(u"࠭ࠠ࡞ࠩᔔ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪᔕ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᔖ"),hDjf1Ubgq629nXlOvcFLH4Jw=BWfpRku7SsM6cbE0eG(u"࠵࠴࠵࠶ᘩ"))
			if not CxP3d82yUTnMa.succeeded and tvXK2luiTNQ7dayCDZ5 in [sH6BOz5wKRFcEg(u"ࠩࡄ࡙࡙ࡕࠧᔗ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᔘ")] and bfTGKy2HVtpN74g:
				if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫᔙ"),YQNd4wejLSAVJ6T(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᔚ"),hDjf1Ubgq629nXlOvcFLH4Jw=qeG16a4pbSHziNVQ2uFXrs(u"࠶࠵࠶࠰ᘪ"))
				GGySQr6d3Tn7iLDkXAINbF2M = UBWIYiHgE0Rsyt8bVOnAqkoT(CXTZu2YvNpEPkinLf8Ohlm3Rg,vrEJRkchKxtDNiqO1b79mL5eT,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,wwKJzPUNesqLXrGZ6V5dC4B,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt)
				if GGySQr6d3Tn7iLDkXAINbF2M.succeeded:
					CxP3d82yUTnMa = GGySQr6d3Tn7iLDkXAINbF2M
					SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SIkwCEdJHTD9v1(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᔛ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᔜ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࠢࡠࠫᔝ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(XxE4VAKW7LQzdk2Il3gUr1vwn(u"้ࠩะฬำࠠิ์ิๅึอสࠡสิ์ู่๊ࠨᔞ"),zLjWeKu6JgNO7vocUD0Qpy(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᔟ"),hDjf1Ubgq629nXlOvcFLH4Jw=hPFcB6Uxmabj59Iq(u"࠷࠶࠰࠱ᘫ"))
				else:
					SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+Js61GTdX5wzMurUqi7Z(u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᔠ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+aYH620Dh48GEsTFfOBSQ7r(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᔡ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࠠ࡞ࠩᔢ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬᔣ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᔤ"),hDjf1Ubgq629nXlOvcFLH4Jw=qqw1upCsKM(u"࠸࠰࠱࠲ᘬ"))
			if not CxP3d82yUTnMa.succeeded and uujXZpi9nHULqr175C in [aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡄ࡙࡙ࡕࠧᔥ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᔦ")] and ccwlRNomV6SWxsG3MJT:
				if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(RDwahqjPfbdyEiTtnLQu(u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᔧ"),jwzOabysh0Z(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᔨ"),hDjf1Ubgq629nXlOvcFLH4Jw=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠲࠱࠲࠳ᘭ"))
				rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT+oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫᔩ")
				GGySQr6d3Tn7iLDkXAINbF2M = YTUhmp4NetWSMdR6w1X(CXTZu2YvNpEPkinLf8Ohlm3Rg,rdQ5tOIzuelfvcYbNsM,gWlmUqwV3YrIT2XNPxQCisBHSDG9,u0K219wAgLr8TXDcVGsqQPtRkCH6ov,h9eHNK3ZzI,wwKJzPUNesqLXrGZ6V5dC4B,oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠹ࡺࡨࠨᔪ"))
				if GGySQr6d3Tn7iLDkXAINbF2M.succeeded:
					CxP3d82yUTnMa = GGySQr6d3Tn7iLDkXAINbF2M
					SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+gDETKVh8mZe09Nd(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨᔫ")+wxcCDGXEkniWdJA+aYH620Dh48GEsTFfOBSQ7r(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᔬ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᔭ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+GVurlv8HeoXEzPRiQB7Ty(u"ࠫࠥࡣࠧᔮ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ์ฬศฯࠣื๏ืแาࠢࡇࡒࡘ࠭ᔯ"),GVurlv8HeoXEzPRiQB7Ty(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᔰ"),hDjf1Ubgq629nXlOvcFLH4Jw=qeG16a4pbSHziNVQ2uFXrs(u"࠳࠲࠳࠴ᘮ"))
				else:
					SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+sH6BOz5wKRFcEg(u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫᔱ")+wxcCDGXEkniWdJA+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᔲ")+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+sH6BOz5wKRFcEg(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᔳ")+ZvWwXBJxzk3Qi9uAHKTD8hY2+RDwahqjPfbdyEiTtnLQu(u"ࠪࠤࡢ࠭ᔴ"))
					if wwKJzPUNesqLXrGZ6V5dC4B: iRaHzNpJhSx6ZnCfrvD7j93lks(YQNd4wejLSAVJ6T(u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫᔵ"),aYH620Dh48GEsTFfOBSQ7r(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᔶ"),hDjf1Ubgq629nXlOvcFLH4Jw=Js61GTdX5wzMurUqi7Z(u"࠴࠳࠴࠵ᘯ"))
		if tvXK2luiTNQ7dayCDZ5==GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨᔷ") or uujXZpi9nHULqr175C==bGzRdmOErkIylxALniq6(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᔸ"): wwKJzPUNesqLXrGZ6V5dC4B = lvzrYTpcBaK
		if not CxP3d82yUTnMa.succeeded:
			if wwKJzPUNesqLXrGZ6V5dC4B: rm0eA8hx6v35NDzLwG1HcFtpCMdTiR = DDuLcAv3Xl1b54tHBs(ltE6Cgu1AyjR8Dde,nxzrQgAItNskH0lFimGMRO3KW,zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,wwKJzPUNesqLXrGZ6V5dC4B)
			if CxP3d82yUTnMa.code!=Js61GTdX5wzMurUqi7Z(u"࠵࠴࠵ᘰ") and zVbp6yjdF3qKkTvhDsJX9fgMceCuxt not in KAgokEa3RwmuHiWsJ0 and hPFcB6Uxmabj59Iq(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬᔹ") not in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: xxpJdCwRN6SrscbOmga7h5UlHBiW()
	if fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᔺ")) not in [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡅ࡚࡚ࡏࠨᔻ"),qqw1upCsKM(u"ࠫࡘ࡚ࡏࡑࠩᔼ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡇࡓࡌࠩᔽ")]: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(gDETKVh8mZe09Nd(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᔾ"),RDwahqjPfbdyEiTtnLQu(u"ࠧࡂࡕࡎࠫᔿ"))
	if fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(SIkwCEdJHTD9v1(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᕀ")) not in [qqw1upCsKM(u"ࠩࡄ࡙࡙ࡕࠧᕁ"),sH6BOz5wKRFcEg(u"ࠪࡗ࡙ࡕࡐࠨᕂ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡆ࡙ࡋࠨᕃ")]: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(YQNd4wejLSAVJ6T(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᕄ"),Js61GTdX5wzMurUqi7Z(u"࠭ࡁࡔࡍࠪᕅ"))
	return CxP3d82yUTnMa
def CasQSfk0wdcOIbHJZ9BX4ForAL8U(MAR96O0yHe7jiIlEXB, OU7LQebVZERtugDfG9):
	jkR5T27yS1AmfO4CGxcZQU8zaKBb, OU7LQebVZERtugDfG9 = list(MAR96O0yHe7jiIlEXB), OU7LQebVZERtugDfG9 & 0xFFFFFFFF
	for XMIo9vWSBymeLJnK6YsU in range(len(jkR5T27yS1AmfO4CGxcZQU8zaKBb)-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU, BewrUo9ANCa17G43Sn0LH5xh, -zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
		OU7LQebVZERtugDfG9 = (OU7LQebVZERtugDfG9 * SE97R3Dpj6dPLweVKU(u"࠶࠼࠶࠵࠷࠵࠹ᘲ") + GVurlv8HeoXEzPRiQB7Ty(u"࠵࠵࠷࠳࠺࠲࠷࠶࠷࠹ᘱ")) & 0xFFFFFFFF
		jkR5T27yS1AmfO4CGxcZQU8zaKBb[XMIo9vWSBymeLJnK6YsU], jkR5T27yS1AmfO4CGxcZQU8zaKBb[OU7LQebVZERtugDfG9 % (XMIo9vWSBymeLJnK6YsU + zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)] = jkR5T27yS1AmfO4CGxcZQU8zaKBb[OU7LQebVZERtugDfG9 % (XMIo9vWSBymeLJnK6YsU + zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)], jkR5T27yS1AmfO4CGxcZQU8zaKBb[XMIo9vWSBymeLJnK6YsU]
	return sH6BOz5wKRFcEg(u"ࠧࠨᕆ").join(jkR5T27yS1AmfO4CGxcZQU8zaKBb)
def BrvhZ3fdG9xRYUD4zw5quTiIk186(MAR96O0yHe7jiIlEXB, DeGZcTax0vhuyA, MPdxhKgVWGetvCE8X):
	aLYdD1iuhlweJHG = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࠩᕇ").join(chr(XMIo9vWSBymeLJnK6YsU) for XMIo9vWSBymeLJnK6YsU in range(zLjWeKu6JgNO7vocUD0Qpy(u"࠸࠵࠷ᘳ")))
	if not I5VKjrFL0Bk97: aLYdD1iuhlweJHG = aLYdD1iuhlweJHG.decode(Js61GTdX5wzMurUqi7Z(u"ࠩ࡯ࡥࡹ࡯࡮࠲ࠩᕈ"))
	zRfPweEpnLYIO79K24o8tsFuBqbd6U = CasQSfk0wdcOIbHJZ9BX4ForAL8U(aLYdD1iuhlweJHG, DeGZcTax0vhuyA)
	c0juIlGi4tJy5f2ZX3C = CasQSfk0wdcOIbHJZ9BX4ForAL8U(zRfPweEpnLYIO79K24o8tsFuBqbd6U, DeGZcTax0vhuyA)
	VWaCTh2GbyfRENml9Z = dict(zip(zRfPweEpnLYIO79K24o8tsFuBqbd6U,c0juIlGi4tJy5f2ZX3C)) if not MPdxhKgVWGetvCE8X else dict(zip(c0juIlGi4tJy5f2ZX3C,zRfPweEpnLYIO79K24o8tsFuBqbd6U))
	MAR96O0yHe7jiIlEXB = SE97R3Dpj6dPLweVKU(u"ࠪࠫᕉ").join(VWaCTh2GbyfRENml9Z.get(YyQSLTwIN8FGMOnhBRmd7E,YyQSLTwIN8FGMOnhBRmd7E) for YyQSLTwIN8FGMOnhBRmd7E in MAR96O0yHe7jiIlEXB)
	return MAR96O0yHe7jiIlEXB
def zxobrwLtVksKTYWCE6cIB9emjy2(MAR96O0yHe7jiIlEXB, DeGZcTax0vhuyA):
	YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z, m5KDiGznabfMWheqgtkwvSQ30, a2ahBjKNCr6lWVRFY = [], BewrUo9ANCa17G43Sn0LH5xh, BewrUo9ANCa17G43Sn0LH5xh
	OgeHu35nFjCp = [XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠱࠱ᘴ")-int(PGIMerh3ZFgUmcWCQJTY) for PGIMerh3ZFgUmcWCQJTY in str(DeGZcTax0vhuyA)[::-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]]
	kA4XaBoqIKR = int(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࠾࠭ᕊ")*len(str(DeGZcTax0vhuyA)))//vUnJhT2NO8yirHcAmg-DeGZcTax0vhuyA
	DeGZcTax0vhuyA, kA4XaBoqIKR = DeGZcTax0vhuyA % IOHSz7YPF9WusGgUt1Dq(u"࠳࠷࠹ᘵ"), kA4XaBoqIKR % IOHSz7YPF9WusGgUt1Dq(u"࠳࠷࠹ᘵ")
	while m5KDiGznabfMWheqgtkwvSQ30 < len(MAR96O0yHe7jiIlEXB):
		tz2qMePyAfa0WhpnLuromDHBsjd = OgeHu35nFjCp[a2ahBjKNCr6lWVRFY%len(OgeHu35nFjCp)]
		Po9h3gWFuLR2 = MAR96O0yHe7jiIlEXB[m5KDiGznabfMWheqgtkwvSQ30 : m5KDiGznabfMWheqgtkwvSQ30 + tz2qMePyAfa0WhpnLuromDHBsjd]
		YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z += [(ord(YyQSLTwIN8FGMOnhBRmd7E)^DeGZcTax0vhuyA)^kA4XaBoqIKR for YyQSLTwIN8FGMOnhBRmd7E in Po9h3gWFuLR2][::-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		m5KDiGznabfMWheqgtkwvSQ30 += tz2qMePyAfa0WhpnLuromDHBsjd
		a2ahBjKNCr6lWVRFY += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	YYf4aHtOwcq = chr if I5VKjrFL0Bk97 else unichr
	MAR96O0yHe7jiIlEXB = EJgYdjbIiWe1apkQlZcR42(u"ࠬ࠭ᕋ").join([YYf4aHtOwcq(YyQSLTwIN8FGMOnhBRmd7E) for YyQSLTwIN8FGMOnhBRmd7E in YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z])
	return MAR96O0yHe7jiIlEXB
def MLSsdPul803Tn4WBeGkZp6aQc(MAR96O0yHe7jiIlEXB,OU7LQebVZERtugDfG9,NVvgz0QceU47OqIX=BewrUo9ANCa17G43Sn0LH5xh):
	if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		if isinstance(MAR96O0yHe7jiIlEXB, bytes): MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.decode(IO7k2hZXSz(u"࠭ࡵࡵࡨ࠻ࠫᕌ"))
		laHc9bBjz0IkERX6qNiT7L = hDjf1Ubgq629nXlOvcFLH4Jw.time()+NVvgz0QceU47OqIX if NVvgz0QceU47OqIX>BewrUo9ANCa17G43Sn0LH5xh else hDjf1Ubgq629nXlOvcFLH4Jw.time()
		MAR96O0yHe7jiIlEXB = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࡵࠣࡽࢀࢀࢁࢂࡻࡾࠤᕍ").format(int(laHc9bBjz0IkERX6qNiT7L), MAR96O0yHe7jiIlEXB)
		MAR96O0yHe7jiIlEXB = zxobrwLtVksKTYWCE6cIB9emjy2(MAR96O0yHe7jiIlEXB, OU7LQebVZERtugDfG9)
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.encode(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡷࡷࡪ࠽࠭ᕎ"))
		MAR96O0yHe7jiIlEXB = eJFGwKIhm4iTx5dfalZqEkDj.compress(MAR96O0yHe7jiIlEXB)
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.decode(IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡯ࡥࡹ࡯࡮࠲ࠩᕏ"))
		MAR96O0yHe7jiIlEXB = BrvhZ3fdG9xRYUD4zw5quTiIk186(MAR96O0yHe7jiIlEXB, OU7LQebVZERtugDfG9, aenpKvQCGVzhLXEdWiDIZ(u"ࡈࡤࡰࡸ࡫ᘶ"))
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.encode(IO7k2hZXSz(u"ࠪࡹࡹ࡬࠸ࠨᕐ"))
	return MAR96O0yHe7jiIlEXB
def EBA1sh2eDxfKZ(MAR96O0yHe7jiIlEXB,OU7LQebVZERtugDfG9,NVvgz0QceU47OqIX=BewrUo9ANCa17G43Sn0LH5xh):
	ENvtPw6MZKm9g = oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡋࡇࡉࡍࡇࡇࠫᕑ")
	if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		if isinstance(MAR96O0yHe7jiIlEXB, bytes): MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.decode(aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡻࡴࡧ࠺ࠪᕒ"))
		MAR96O0yHe7jiIlEXB = BrvhZ3fdG9xRYUD4zw5quTiIk186(MAR96O0yHe7jiIlEXB, OU7LQebVZERtugDfG9, TzIj50KpohEOHx6CbZWqB(u"ࡗࡶࡺ࡫ᘷ"))
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.encode(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࡬ࡢࡶ࡬ࡲ࠶࠭ᕓ"))
		MAR96O0yHe7jiIlEXB = eJFGwKIhm4iTx5dfalZqEkDj.decompress(MAR96O0yHe7jiIlEXB)
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.decode(jwzOabysh0Z(u"ࠧࡶࡶࡩ࠼ࠬᕔ"))
		MAR96O0yHe7jiIlEXB = zxobrwLtVksKTYWCE6cIB9emjy2(MAR96O0yHe7jiIlEXB, OU7LQebVZERtugDfG9)
		laHc9bBjz0IkERX6qNiT7L, MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.split(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡾࡿࢀࠬᕕ"), zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		ENvtPw6MZKm9g = bGzRdmOErkIylxALniq6(u"ࠩࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬᕖ")
		if NVvgz0QceU47OqIX>BewrUo9ANCa17G43Sn0LH5xh:
			eQoIlLYq4s8Dmg0u = hDjf1Ubgq629nXlOvcFLH4Jw.time()-int(laHc9bBjz0IkERX6qNiT7L)
			if abs(eQoIlLYq4s8Dmg0u)>NVvgz0QceU47OqIX: ENvtPw6MZKm9g = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡍࡓ࡜ࡁࡍࡋࡇࡣ࡙ࡏࡍࡆࡕࡗࡅࡒࡖࠧᕗ")
		MAR96O0yHe7jiIlEXB = MAR96O0yHe7jiIlEXB.encode(IOHSz7YPF9WusGgUt1Dq(u"ࠫࡺࡺࡦ࠹ࠩᕘ"))
	return MAR96O0yHe7jiIlEXB,ENvtPw6MZKm9g
from hhLiJuqsIt import *
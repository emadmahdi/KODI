# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from wMsidgVoE7 import *
SITESURLS = {
			 SIkwCEdJHTD9v1(u"ࠬࡇࡈࡘࡃࡎࠫே")		:[EJgYdjbIiWe1apkQlZcR42(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨை")]
			,RDwahqjPfbdyEiTtnLQu(u"ࠧࡂࡍࡒࡅࡒ࠭௉")		:[fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬொ")]
			,YQNd4wejLSAVJ6T(u"ࠩࡄࡏ࡜ࡇࡍࠨோ")		:[SE97R3Dpj6dPLweVKU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸࠪௌ")]
			,oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋ்ࠧ")	:[Js61GTdX5wzMurUqi7Z(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡯ࡼࡧ࡭࠯ࡶࡸࡦࡪ࠭௎")]
			,IOHSz7YPF9WusGgUt1Dq(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ௏")		:[SIkwCEdJHTD9v1(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭ௐ")]
			,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩ௑")		:[t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮ࡰࡷࡹࡨࡡ࠯ࡶࡹࠫ௒")]
			,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ௓")		:[aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡪ࡯ࡨࡾ࡮ࡪ࠮ࡴࡪࡲࡻࠬ௔")]
			,RDwahqjPfbdyEiTtnLQu(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ௕")	:[SE97R3Dpj6dPLweVKU(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭௖")]
			,hPFcB6Uxmabj59Iq(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩௗ")		:[aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ௘")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠩࡄ࡝ࡑࡕࡌࠨ௙")		:[RDwahqjPfbdyEiTtnLQu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫࠮ࡢࡻ࡯ࡳࡱ࠴࡮ࡦࡶࠪ௚")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠫࡇࡕࡋࡓࡃࠪ௛")		:[RDwahqjPfbdyEiTtnLQu(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩࡲࡩࡷࡧ࠱ࡧࡴ࠭௜")]
			,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡂࡓࡕࡗࡉࡏ࠭௝")		:[qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ௞")]
			,oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ௟")		:[YQNd4wejLSAVJ6T(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ௠")]
			,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪ௡")		:[GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡤ࡫ࡰࡥ࠹ࡶ࠮ࡤࡱࡰࠫ௢")]
			,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ௣")		:[XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬ௤")]
			,EJgYdjbIiWe1apkQlZcR42(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ௥")		:[aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡱ࠳ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ௦")]
			,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ௧")		:[IOHSz7YPF9WusGgUt1Dq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯ࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡤ࡮ࡸࡦࠬ௨")]
			,bGzRdmOErkIylxALniq6(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ௩")	:[sH6BOz5wKRFcEg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡷࡸ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹࡨࡰࡲࠪ௪")]
			,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ௫")		:[oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࠪ௬")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ௭")		:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡧࡴࡨࡩ࠳ࡼࡩࡱࠩ௮")]
			,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௯")	:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪ௰")]
			,hPFcB6Uxmabj59Iq(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭௱")		:[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫ௲")]
			,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ௳")		:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡽࡨ࡯࡭ࡢ࠰ࡦࡧࠬ௴")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ௵")	:[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ௶"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ௷")]
			,YQNd4wejLSAVJ6T(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨ௸")	:[GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠸࠲ࡩࡸࡡ࡮ࡣࡦࡥ࡫࡫࠭ࡵࡸ࠱ࡧࡴࡳࠧ௹")]
			,qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ௺")		:[gDETKVh8mZe09Nd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡶࡦࡳࡡࡴ࠹࠱ࡲࡪࡺࠧ௻")]
			,zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ௼")		:[hPFcB6Uxmabj59Iq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳࡬ࡵ࡯ࠩ௽")]
			,RDwahqjPfbdyEiTtnLQu(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭௾")		:[YQNd4wejLSAVJ6T(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ௿")]
			,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨఀ")		:[qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧఁ")]
			,TzIj50KpohEOHx6CbZWqB(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪం")		:[hPFcB6Uxmabj59Iq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩః")]
			,Js61GTdX5wzMurUqi7Z(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫఄ")		:[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫఅ")]
			,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧఆ")		:[qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭ఇ")]
			,qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪఈ")	:[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦ࡮ࡩࡥ࠰ࡨࡰ࡮࡬࠮࡯ࡧࡺࡷࠬఉ")]
			,aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪఊ")		:[zLjWeKu6JgNO7vocUD0Qpy(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡢࡳ࡭ࡤ࠲ࡨࡵ࡭ࠨఋ")]
			,BWfpRku7SsM6cbE0eG(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧఌ")	:[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࡬ࡨࡶ࠳ࡹࡨࡰࡹࠪ఍")]
			,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧఎ")		:[BWfpRku7SsM6cbE0eG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡴ࠳࡬ࡡࡳࡧࡶ࡯ࡴ࠴࡮ࡦࡶࠪఏ")]
			,qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪఐ")		:[qqw1upCsKM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸࡲࡡ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡦࡰࡴࡻࡤࠨ఑")]
			,qqw1upCsKM(u"ࠪࡊࡔ࡙ࡔࡂࠩఒ")		:[aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷ࡫࠰ࡩࡳࡸࡺࡡ࠮ࡶࡹ࠲ࡳ࡫ࡴࠨఓ")]
			,qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭ఔ")		:[qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࠰ࡤࡰࡲ࡫ࡳࡩ࡭ࡤ࡬࠳ࡴࡥࡵࠩక")]
			,bGzRdmOErkIylxALniq6(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩఖ")		:[IO7k2hZXSz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥ࠲࡫ࡻࡳࡩࡣࡵ࠱ࡹࡼ࠮ࡤࡱࡰࠫగ")]
			,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧఘ")	:[qqw1upCsKM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡦࡶࡵ࡫ࡥࡷ࠴ࡶࡪࡦࡨࡳࠬఙ")]
			,Js61GTdX5wzMurUqi7Z(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭చ")		:[aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯࡯ࡨࡨ࡮ࡧࠧఛ")]
			,hPFcB6Uxmabj59Iq(u"࠭ࡉࡇࡋࡏࡑࠬజ")		:[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨఝ"),SE97R3Dpj6dPLweVKU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩఞ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪట"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬఠ"),qqw1upCsKM(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫడ")]
			,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨఢ")	:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧణ")]
			,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩత")		:[Js61GTdX5wzMurUqi7Z(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮࡭ࡹࡱ࡯ࡵ࠰ࡦࡥࡲ࠭థ")]
			,SIkwCEdJHTD9v1(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪద")		:[qeG16a4pbSHziNVQ2uFXrs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡻ࠮࡬࡫ࡵࡱࡦࡲ࡫࠯ࡥࡲࡱࠬధ")]
			,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫన")		:[TzIj50KpohEOHx6CbZWqB(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡢࡴࡲࡾࡦ࠴ࡩ࡯࡭ࠪ఩")]
			,aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧప")		:[GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡲࡨࡾࡴࡥࡵ࠰࡯࡭ࡳࡱࠧఫ")]
			,IO7k2hZXSz(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫబ")	:[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴࡭ࡢࡵࡤ࠲ࡳ࡫ࡷࡴࠩభ")]
			,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡔࡆࡔࡅࡕࠩమ")		:[YQNd4wejLSAVJ6T(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭య")]
			,jwzOabysh0Z(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧర")		:[oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪ࠱ࡨࡱࡦࡪ࡟ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠵࡯࡭ࡦ࠲࡭ࡳࡪࡥࡹ࠰࡫ࡸࡲࡲࠧఱ")]
			,oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫల")	:[jwzOabysh0Z(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡥ࠳ࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦ࠰ࡦࡥࡲ࠭ళ")]
			,Js61GTdX5wzMurUqi7Z(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫఴ")		:[RDwahqjPfbdyEiTtnLQu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࠶ࡸ࠲ࡳ࡫ࡴࠨవ")]
			,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠸ࠧశ")	:[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯࡮࡬ࡺࡪ࠭ష")]
			,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪస")	:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭హ")]
			,EJgYdjbIiWe1apkQlZcR42(u"ࠨࡕࡋࡓࡋࡎࡁࠨ఺")		:[bGzRdmOErkIylxALniq6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭఻")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜఼ࠬ")		:[RDwahqjPfbdyEiTtnLQu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫఽ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬా"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩి")]
			,aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩీ")		:[TzIj50KpohEOHx6CbZWqB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡹࡨࡰࡱࡩࡲࡪࡺ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧు")]
			,YQNd4wejLSAVJ6T(u"ࠩࡗࡍࡐࡇࡁࡕࠩూ")		:[BWfpRku7SsM6cbE0eG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡫ࡢࡣࡷ࠲ࡳ࡫ࡴࠨృ")]
			,BWfpRku7SsM6cbE0eG(u"࡙ࠫ࡜ࡆࡖࡐࠪౄ")		:[SE97R3Dpj6dPLweVKU(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪ౅")]
			,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ె")		:[fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡺࡦࡸࡢࡰࡰ࠱ࡧࡦࡳࠧే")]
			,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬై")	:[bGzRdmOErkIylxALniq6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠰ࡱࡷࡦ࡫࡭࠯ࡰࡨࡸࠬ౉")]
			,BWfpRku7SsM6cbE0eG(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫొ")		:[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡹࡨࡰࡹࠪో")]
			,IOHSz7YPF9WusGgUt1Dq(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ౌ")		:[Js61GTdX5wzMurUqi7Z(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡦ࡭ࡲࡧ࠮ࡤ࡮࡬ࡧࡰ్࠭")]
			,IOHSz7YPF9WusGgUt1Dq(u"࡚ࠧࡃࡔࡓ࡙࠭౎")		:[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭౏")]
			,SE97R3Dpj6dPLweVKU(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ౐")		:[RDwahqjPfbdyEiTtnLQu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭౑")]
			,hPFcB6Uxmabj59Iq(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪ౒")	:[hPFcB6Uxmabj59Iq(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ౓")]
			,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡉࡑࡖ࡙ࠫ౔")			:[sCHVtMAvqirbQ4BUK3cgWo]
			,BWfpRku7SsM6cbE0eG(u"ࠧࡎ࠵ࡘౕࠫ")			:[sCHVtMAvqirbQ4BUK3cgWo]
			,oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡔࡈࡔࡔౖ࡙ࠧ")		:[jwzOabysh0Z(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ౗"),hPFcB6Uxmabj59Iq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧౘ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨౙ")]
			,bGzRdmOErkIylxALniq6(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠲ࠩౚ")	:[SIkwCEdJHTD9v1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ౛"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ౜"),aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩౝ")]
			,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠷࠭౞")	:[IO7k2hZXSz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ౟"),SE97R3Dpj6dPLweVKU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ౠ"),bGzRdmOErkIylxALniq6(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧౡ")]
			,qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠵ࠪౢ")	:[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨౣ"),EJgYdjbIiWe1apkQlZcR42(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭౤"),gDETKVh8mZe09Nd(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ౥")]
			,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩ౦")	:[SIkwCEdJHTD9v1(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠭౧"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡰࡵࡤࡪࠩ౨"),RDwahqjPfbdyEiTtnLQu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ౩")]
			,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡇࡋࡏࡉࡘࡥࡓࡐࡗࡕࡇࡊ࡙ࠧ౪"):[aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰࠨ౫")]
			,zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ౬")	:[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭౭"),aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪ౮")]
			}
if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
	SITESURLS[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ౯")]      = [E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ౰"),qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ౱"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ౲"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ౳"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ౴"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ౵"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭౶"),EJgYdjbIiWe1apkQlZcR42(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ౷"),sH6BOz5wKRFcEg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ౸"),EJgYdjbIiWe1apkQlZcR42(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭౹"),bGzRdmOErkIylxALniq6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ౺"),BWfpRku7SsM6cbE0eG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡹࡰࡷࡷࡹࡧ࡫࡮ࡴ࡫ࡪࠫ౻")]
	SITESURLS[EJgYdjbIiWe1apkQlZcR42(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩ౼")] = [sH6BOz5wKRFcEg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ౽"),IOHSz7YPF9WusGgUt1Dq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭౾"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ౿"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨಀ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨಁ"),bGzRdmOErkIylxALniq6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫಂ"),qqw1upCsKM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧಃ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ಄"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩಅ"),SE97R3Dpj6dPLweVKU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧಆ"),BWfpRku7SsM6cbE0eG(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ಇ"),jwzOabysh0Z(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡺࡱࡸࡸࡺࡨࡥ࡯ࡵ࡬࡫ࠬಈ")]
	SITESURLS[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠲ࠨಉ")] = [t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧಊ"),TzIj50KpohEOHx6CbZWqB(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫಋ"),oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪಌ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭಍"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ಎ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩಏ"),IO7k2hZXSz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬಐ"),TzIj50KpohEOHx6CbZWqB(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭಑"),EJgYdjbIiWe1apkQlZcR42(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧಒ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬಓ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫಔ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡿ࡯ࡶࡶࡸࡦࡪࡴࡳࡪࡩࠪಕ")]
	SITESURLS[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧಖ")] = [gDETKVh8mZe09Nd(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩಗ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ಘ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬಙ"),oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨಚ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨಛ"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫಜ"),hPFcB6Uxmabj59Iq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧಝ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨಞ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩಟ"),SE97R3Dpj6dPLweVKU(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧಠ"),Js61GTdX5wzMurUqi7Z(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ಡ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡺࡱࡸࡸࡺࡨࡥ࡯ࡵ࡬࡫ࠬಢ")]
else:
	SITESURLS[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨಣ")]      = [t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬತ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩಥ"),BWfpRku7SsM6cbE0eG(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨದ"),hPFcB6Uxmabj59Iq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫಧ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫನ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ಩"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪಪ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫಫ"),qqw1upCsKM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬಬ"),gDETKVh8mZe09Nd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪಭ"),IO7k2hZXSz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩಮ"),RDwahqjPfbdyEiTtnLQu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡽࡴࡻࡴࡶࡤࡨࡲࡸ࡯ࡧࠨಯ")]
	SITESURLS[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬರ")] = [hPFcB6Uxmabj59Iq(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫಱ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨಲ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧಳ"),qqw1upCsKM(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ಴"),Js61GTdX5wzMurUqi7Z(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪವ"),TzIj50KpohEOHx6CbZWqB(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ಶ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩಷ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪಸ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫಹ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ಺"),IOHSz7YPF9WusGgUt1Dq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ಻"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡼࡳࡺࡺࡵࡣࡧࡱࡷ࡮࡭಼ࠧ")]
	SITESURLS[GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠵ࠫಽ")] = [SIkwCEdJHTD9v1(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪಾ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧಿ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ೀ"),SE97R3Dpj6dPLweVKU(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩು"),fvYGxnZNUiyP4HJkMIoS25(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩೂ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬೃ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨೄ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ೅"),TzIj50KpohEOHx6CbZWqB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪೆ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨೇ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧೈ"),IO7k2hZXSz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡻࡲࡹࡹࡻࡢࡦࡰࡶ࡭࡬࠭೉")]
	SITESURLS[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠵ࠪೊ")] = [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩೋ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ೌ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰ್ࠬ"),jwzOabysh0Z(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ೎"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ೏"),Js61GTdX5wzMurUqi7Z(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ೐"),jwzOabysh0Z(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ೑"),GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ೒"),bGzRdmOErkIylxALniq6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ೓"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ೔"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ೕ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡺࡱࡸࡸࡺࡨࡥ࡯ࡵ࡬࡫ࠬೖ")]
api_python_actions = [qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭೗"),SE97R3Dpj6dPLweVKU(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭೘"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡅࡎࡃࡌࡐࡘ࠭೙"),jwzOabysh0Z(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ೚"),qqw1upCsKM(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ೛"),GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ೜"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨೝ"),IO7k2hZXSz(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬೞ"),hPFcB6Uxmabj59Iq(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭೟"),sH6BOz5wKRFcEg(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨೠ"),TzIj50KpohEOHx6CbZWqB(u"ࠧࡆ࡚ࡈࡇ࡚࡚ࡅࡋࡕࠪೡ"),gDETKVh8mZe09Nd(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࡐࡖࡍࡌ࠭ೢ")]
api_repos_actions = [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡄࡈࡉࡕࡎࡔࠩೣ"),SIkwCEdJHTD9v1(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬ೤"),gDETKVh8mZe09Nd(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭೥")]
non_videos_actions = [iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡇࡌࡍࠩ೦"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭೧"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ೨"),bGzRdmOErkIylxALniq6(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ೩"),jwzOabysh0Z(u"ࠩࡕࡉࡕࡕࡓࠨ೪"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭೫"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧ೬"),IOHSz7YPF9WusGgUt1Dq(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫ೭"),GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡇࡆࡖࡌࡈࠬ೮"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪ೯")]+api_python_actions+api_repos_actions
hc1vNqbTWYrBo69ynVau4QRHs = lvzrYTpcBaK
sIS7FqTadm3ZEJpg4G = ndkUxG9LtewJ
DDx2Ff6SX9zNUMmGEc = lvzrYTpcBaK
P56VUO0NuA8bq = lvzrYTpcBaK
avprivsnorestrict = lvzrYTpcBaK
avprivslongperiod = lvzrYTpcBaK
resolveonly = lvzrYTpcBaK
H2heYqoNSfBbcLRGiUsWDZnAEIgJ7j = lvzrYTpcBaK
ALLOW_DNS_FIX = ZetiSjBQ9bTnF23pzsmXcyWuK
ALLOW_PROXY_FIX = ZetiSjBQ9bTnF23pzsmXcyWuK
ALLOW_SHOWDIALOGS_FIX = ZetiSjBQ9bTnF23pzsmXcyWuK
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ೰"),fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬೱ"),IOHSz7YPF9WusGgUt1Dq(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫೲ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ೳ"),bGzRdmOErkIylxALniq6(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ೴"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ೵"),fvYGxnZNUiyP4HJkMIoS25(u"࡚ࠧࡃࡔࡓ࡙࠭೶"),gDETKVh8mZe09Nd(u"ࠨࡘࡄࡖࡇࡕࡎࠨ೷"),SE97R3Dpj6dPLweVKU(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ೸"),gDETKVh8mZe09Nd(u"ࠪࡔࡆࡔࡅࡕࠩ೹"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡘࡎࡁࡃࡃࡎࡅ࡙࡟ࠧ೺")]
BADCOMMONIDS = [sH6BOz5wKRFcEg(u"ࠬ࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠹࠺࠻࠼࠱࠵࠶࠰࠱ࠩ೻"),aYH620Dh48GEsTFfOBSQ7r(u"࠭࠹࠺࠺࠻࠱࠼࠽࠶࠷࠯࠸࠹࠹࠺࠭࠴࠵࠵࠶࠲࠸࠰࠹࠸ࠪ೼")]
GEOLOCATION_DATA = sCHVtMAvqirbQ4BUK3cgWo
AV_CLIENT_IDS = sCHVtMAvqirbQ4BUK3cgWo
DNS_SERVERS = [IO7k2hZXSz(u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨ೽"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ೾"),IOHSz7YPF9WusGgUt1Dq(u"ࠩ࠴࠲࠵࠴࠰࠯࠳ࠪ೿"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࠼࠳࠾࠮࠵࠰࠷ࠫഀ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠲࠯࠴࠵࠶ࠬഁ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠱࠰࠵࠶࠵࠭ം")]
busydialog_active = lvzrYTpcBaK
dns_succeeded_urls = []
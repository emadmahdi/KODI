# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYDEAD'
Z0BYJQghVL1v87CAem = '_EGD_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==440: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==441: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==442: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==443: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==449: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYDEAD-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(gAVl1vUmus8,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,449,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الرئيسية',gAVl1vUmus8,441)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="title_menu_right"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		if B17r2fdFy9ns8tiOMLu=='#': continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,441)
	return
def fs7D0d3QyAT(url,zPm7HsNhv8Gt5jpi2YUZlnOeDT=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYDEAD-TITLES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="list-related"(.*?)class="pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		if '/url/' in B17r2fdFy9ns8tiOMLu: continue
		elif '/season/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,443,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/episode/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,443,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,442,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,441)
	return
def VzOBjnIkZSH7ft(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYDEAD-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"seasons-list"(.*?)</div>.</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"episodes-list"(.*?)</div>.</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,443,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"og:image" content="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,442,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYDEAD-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"watchAreaMaster"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('data-link="(.*?)".*?<p>(.*?)</p>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"donwload-servers-list"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for title,XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+'____'+XO7Zr2W6kwieA
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url)
	return
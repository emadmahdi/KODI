# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHAHIDNEWS'
Z0BYJQghVL1v87CAem = '_SHN_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['قنوات فضائية','فارسكو','Show more']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==580: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==581: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==582: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==583: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url,text)
	elif mode==584: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==589: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHAHIDNEWS-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,589,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('/category.php">(.*?)"navslide-divider"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("'dropdown-menu'(.*?)</ul>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for MtCcgLOoBTGp4nqzVhYJliX8Zva6s in oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = Po9h3gWFuLR2.replace(MtCcgLOoBTGp4nqzVhYJliX8Zva6s,sCHVtMAvqirbQ4BUK3cgWo)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,584)
	return
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHAHIDNEWS-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"presentation"','</ul>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [(sCHVtMAvqirbQ4BUK3cgWo,Po9h3gWFuLR2)]
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' فرز أو فلتر أو ترتيب '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for J8noyr10GLB9exORpmSIHTWiFPc,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if J8noyr10GLB9exORpmSIHTWiFPc: J8noyr10GLB9exORpmSIHTWiFPc = J8noyr10GLB9exORpmSIHTWiFPc+': '
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = J8noyr10GLB9exORpmSIHTWiFPc+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,581)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"pm-category-subcats"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)<30:
			XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			for B17r2fdFy9ns8tiOMLu,title in items:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,581)
	if not GzRKsiw5PBIe1NlrqmQy9STx and not iUtXlDhSVoBZJrPTQAwcER9nfMkN: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHAHIDNEWS-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(data-echo=".*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"BlocksList"(.*?)"titleSectionCon"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="pm-grid"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="pm-related"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not items: items = fNntYJW45mEFSdRX8g.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
		if 'http' not in Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = aeBQsh4fzLr8XM5xou1gcyE+'/'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS.strip('/')
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,582,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'الحلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,583,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movseries/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,581,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,583,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if n1WYDtVC8dRHbXJkMa not in ['featured_movies','featured_series']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,581)
		fMlokB12KS3wrF = fNntYJW45mEFSdRX8g.findall('showmore" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if fMlokB12KS3wrF:
			B17r2fdFy9ns8tiOMLu = fMlokB12KS3wrF[0]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مشاهدة المزيد',B17r2fdFy9ns8tiOMLu,581)
	return
def VzOBjnIkZSH7ft(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHAHIDNEWS-EPISODES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('nav-seasons"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	items = []
	irDX4SOHZKIaLUvhyjCbx0T = False
	if GzRKsiw5PBIe1NlrqmQy9STx and not Obes76wjH9LRyEqc2NWPTSphZz34K:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Obes76wjH9LRyEqc2NWPTSphZz34K,title in items:
			Obes76wjH9LRyEqc2NWPTSphZz34K = Obes76wjH9LRyEqc2NWPTSphZz34K.strip('#')
			if len(items)>1: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,583,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Obes76wjH9LRyEqc2NWPTSphZz34K)
			else: irDX4SOHZKIaLUvhyjCbx0T = True
	else: irDX4SOHZKIaLUvhyjCbx0T = True
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('id="'+Obes76wjH9LRyEqc2NWPTSphZz34K+'"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN and irDX4SOHZKIaLUvhyjCbx0T:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,title in items:
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,582)
		else:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,582)
	return
def YH54mqkD2eU06(url):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	ss7YGDbuAIxgnqaQroTV = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHAHIDNEWS-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"Playerholder".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
	if B17r2fdFy9ns8tiOMLu and 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
	rBJKF4h3jcUPZq = B17r2fdFy9ns8tiOMLu.split('hash=')[1]
	cuIJ3axEtVWvs = rBJKF4h3jcUPZq.split('__')
	FFtef8KTOLv,PXFtqmw5lBGQNa0IV8,title = sCHVtMAvqirbQ4BUK3cgWo,[],sCHVtMAvqirbQ4BUK3cgWo
	for tLBfjh05uaXlHYxr3P6sVpGiT18U in cuIJ3axEtVWvs:
		c3c2EeSNOkR1FUVLh6niTZps = ((4-len(tLBfjh05uaXlHYxr3P6sVpGiT18U)%4)%4)*'='
		try:
			tLBfjh05uaXlHYxr3P6sVpGiT18U = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(tLBfjh05uaXlHYxr3P6sVpGiT18U+c3c2EeSNOkR1FUVLh6niTZps)
			if I5VKjrFL0Bk97: tLBfjh05uaXlHYxr3P6sVpGiT18U = tLBfjh05uaXlHYxr3P6sVpGiT18U.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,'ignore')
		except: pass
		FFtef8KTOLv += tLBfjh05uaXlHYxr3P6sVpGiT18U
	FFtef8KTOLv = FFtef8KTOLv.replace(' = ',' => ')
	pru47ACWcjDKEF0oN = FFtef8KTOLv.splitlines()
	for B17r2fdFy9ns8tiOMLu in pru47ACWcjDKEF0oN:
		if '://' in B17r2fdFy9ns8tiOMLu: PXFtqmw5lBGQNa0IV8.append(B17r2fdFy9ns8tiOMLu)
	for B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
		if ' => ' in B17r2fdFy9ns8tiOMLu: title,B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split(' => ')
		elif 'http' in B17r2fdFy9ns8tiOMLu:
			title,B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('http')
			B17r2fdFy9ns8tiOMLu = 'http'+B17r2fdFy9ns8tiOMLu
		else: continue
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.strip(' ')
		if not title: title = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/search.php?keywords='+search
	fs7D0d3QyAT(url)
	return
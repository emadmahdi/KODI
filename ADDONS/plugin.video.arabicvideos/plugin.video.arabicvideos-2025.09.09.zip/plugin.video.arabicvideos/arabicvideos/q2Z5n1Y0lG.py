# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
headers = { 'User-Agent' : sCHVtMAvqirbQ4BUK3cgWo }
Ll1m0nJoaAPvHsXqyRE = 'AKOAMCAM'
Z0BYJQghVL1v87CAem = '_AKC_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مصارعة']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==350: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==351: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==352: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==353: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==354: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'FILTERS___'+text)
	elif mode==355: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'CATEGORIES___'+text)
	elif mode==356: ka7jz96YCdTBnQOLVPuJG3285MHf = DvkcTgS1Pw(url)
	elif mode==357: ka7jz96YCdTBnQOLVPuJG3285MHf = siMN4Rf1WQom0eqA7rgvVP6BbzCd(url)
	elif mode==359: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+F7Fe63KbGjaz2TcmCNHPdo5QiXO+'هذا الموقع مغلق'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,8)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,359,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',gAVl1vUmus8,356)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',gAVl1vUmus8,357)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-MENU-1st')
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('recently-container.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
	else: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'اضيف حديثا',vrEJRkchKxtDNiqO1b79mL5eT,351)
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('@id":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
	else: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',vrEJRkchKxtDNiqO1b79mL5eT,351,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-categories-list(.*?)main-categories-list',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?class="font.*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,351)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="categories-box(.*?)<footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = tt36wUe4HTPFmfs5hcbr(B17r2fdFy9ns8tiOMLu)
			if title not in MqARWHDkmiT4nlz: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,351)
	return Sw0pOFoVhPeIxbl
def DvkcTgS1Pw(website=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu(.*?)<nav',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?text">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz:
				title = title+' مصنفة'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,355)
		if website==sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	return Sw0pOFoVhPeIxbl
def siMN4Rf1WQom0eqA7rgvVP6BbzCd(website=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu(.*?)<nav',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?text">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz:
				title = title+' مفلترة'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,354)
		if website==sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(UTCXGnK7Fs4Y5pNkt2ARDWuw,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('swiper-container(.*?)swiper-button-prev',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="container"(.*?)main-footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|الحلقه) \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
				if bbFPOJrmkCaE6ul37XiKU:
					title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
					if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
						XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,352,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
						AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			elif 'مسلسل' in title:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,352,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,353,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href=["\'](.*?)["\'].*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = tt36wUe4HTPFmfs5hcbr(B17r2fdFy9ns8tiOMLu)
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,351)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8 + '/?s='+ktT4O0VJm8UaDNlxKvinoBYFgdH
	ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	return
def VzOBjnIkZSH7ft(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAMCAM-EPISODES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('text-white">الحلقات(.*?)<header',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		pWu3ti618zVAbjdf7 = fNntYJW45mEFSdRX8g.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in pWu3ti618zVAbjdf7:
			if 'الحلقة' in title or 'الحلقه' in title: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,353,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Icon')
		if Sw0pOFoVhPeIxbl.count('<title>')>1: title = fNntYJW45mEFSdRX8g.findall('<title>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[1]
		else: title = 'رابط التشغيل'
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,353,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X = [],[]
	RFAL7sXKtHqieEQn = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-PLAY-1st')
	Sw0pOFoVhPeIxbl = RFAL7sXKtHqieEQn.content
	uu4UgsMj01aImASoXpYDO9iQcfG = fNntYJW45mEFSdRX8g.findall('post_id=(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if uu4UgsMj01aImASoXpYDO9iQcfG:
		uu4UgsMj01aImASoXpYDO9iQcfG = uu4UgsMj01aImASoXpYDO9iQcfG[0]
		headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':uu4UgsMj01aImASoXpYDO9iQcfG}
		vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		FBfDnW6ZGCTm8IxpdcvAw491Sqs = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'POST',vrEJRkchKxtDNiqO1b79mL5eT,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-PLAY-1st')
		ssUAzo3RibtgDv7O0x = FBfDnW6ZGCTm8IxpdcvAw491Sqs.content
		items = fNntYJW45mEFSdRX8g.findall('data-server="(.*?)".*?class="text">(.*?)<',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		for DvXq6pumzN7AyP50rU,name in items:
			B17r2fdFy9ns8tiOMLu = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?postid='+uu4UgsMj01aImASoXpYDO9iQcfG+'&serverid='+DvXq6pumzN7AyP50rU+'?named='+name+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			V9TdsglcWYv0X.append(name)
		vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		FBfDnW6ZGCTm8IxpdcvAw491Sqs = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'POST',vrEJRkchKxtDNiqO1b79mL5eT,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'AKOAMCAM-PLAY-1st')
		ssUAzo3RibtgDv7O0x = FBfDnW6ZGCTm8IxpdcvAw491Sqs.content
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?class="text">(.*?)<',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			V9TdsglcWYv0X.append(title)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	JqMFOusdXt69Py = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='CATEGORIES':
		if JqMFOusdXt69Py[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(JqMFOusdXt69Py[0:-1])):
			if JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'?'+ukGBUJAz02tOe
	elif type=='FILTERS':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'?'+RLkAVfXyplPhsSgb9760oCZW
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها',vrEJRkchKxtDNiqO1b79mL5eT,351,sCHVtMAvqirbQ4BUK3cgWo,'1')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',vrEJRkchKxtDNiqO1b79mL5eT,351,sCHVtMAvqirbQ4BUK3cgWo,'1')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<form id(.*?)</form>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	dict = {}
	for ppWPYnc0JHvsmuTBqCXDEkzyN8,name,Po9h3gWFuLR2 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		items = fNntYJW45mEFSdRX8g.findall('<option(.*?)>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='CATEGORIES':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<=1:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'CATEGORIES___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,351,sCHVtMAvqirbQ4BUK3cgWo,'1')
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,355,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='FILTERS':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع : '+name,vrEJRkchKxtDNiqO1b79mL5eT,354,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			if 'value' not in value: value = CCzds3YbQDjKUFxfA5RHMIyBaSt
			else: value = fNntYJW45mEFSdRX8g.findall('"(.*?)"',value,fNntYJW45mEFSdRX8g.DOTALL)[0]
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' : '#+dict[ppWPYnc0JHvsmuTBqCXDEkzyN8]['0']
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' : '+name
			if type=='FILTERS': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,354,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='CATEGORIES' and JqMFOusdXt69Py[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'all')
				rdQ5tOIzuelfvcYbNsM = url+'?'+ukGBUJAz02tOe
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,351,sCHVtMAvqirbQ4BUK3cgWo,'1')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,355,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	QC1LKoSRIvJFA7fpx3u0 = ['cat','genre','release-year','quality','orderby']
	for key in QC1LKoSRIvJFA7fpx3u0:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	return FQZjpoeBUGkTShcbE3d
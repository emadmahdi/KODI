# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'CIMA4U'
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
Z0BYJQghVL1v87CAem = '_C4U_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==420: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==421: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==422: ka7jz96YCdTBnQOLVPuJG3285MHf = XTVdM7xH3Z9vEKna1uq2plbWy(url)
	elif mode==423: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==424: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==427: ka7jz96YCdTBnQOLVPuJG3285MHf = gaVbExnQiwt0rlO6(url)
	elif mode==429: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	aeBQsh4fzLr8XM5xou1gcyE = aeBQsh4fzLr8XM5xou1gcyE[0].strip('/')
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(aeBQsh4fzLr8XM5xou1gcyE,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,429,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',aeBQsh4fzLr8XM5xou1gcyE,425)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',aeBQsh4fzLr8XM5xou1gcyE,424)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الرئيسية',aeBQsh4fzLr8XM5xou1gcyE,421)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('NavigationMenu(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="*(.*?)"*>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		if '/actors' in B17r2fdFy9ns8tiOMLu: title = 'أفلام النجوم'
		elif '/netflix' in B17r2fdFy9ns8tiOMLu: title = 'أفلام ومسلسلات نيتفلكس'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,421)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'قائمة تفصيلية',aeBQsh4fzLr8XM5xou1gcyE,427)
	return
def gaVbExnQiwt0rlO6(website=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('FilteringTitle(.*?)PageTitle',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B4SziFvRIXpPeGmfZDw3aVWJMAKNc,id,B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		if 'netflix-movies' in B17r2fdFy9ns8tiOMLu: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in B17r2fdFy9ns8tiOMLu: title = 'مسلسلات نيتفلكس'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'|'+id)
	return
def fs7D0d3QyAT(url,pm4F0M2Dsuh6otP7Zi5NXT=sCHVtMAvqirbQ4BUK3cgWo):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if not pm4F0M2Dsuh6otP7Zi5NXT or '|' in pm4F0M2Dsuh6otP7Zi5NXT:
		if '|' not in pm4F0M2Dsuh6otP7Zi5NXT: FhQgHPaqfANrMkbmi27coSVz = sCHVtMAvqirbQ4BUK3cgWo
		else: FhQgHPaqfANrMkbmi27coSVz = '/archive/'+pm4F0M2Dsuh6otP7Zi5NXT
		qSTQadRYkueMBEG = False
		if 'PinSlider' in Sw0pOFoVhPeIxbl:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'المميزة',url,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
			qSTQadRYkueMBEG = True
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('PageTitle(.*?)PageContent',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			MtCcgLOoBTGp4nqzVhYJliX8Zva6s = oPnz7Zt4xLHTwR[0]
			Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('data-tab="(.*?)".*?<span>(.*?)<',MtCcgLOoBTGp4nqzVhYJliX8Zva6s,fNntYJW45mEFSdRX8g.DOTALL)
			for IFJL23MGvf4pdDAwxSe7jORUk6ybo,dwDUvp0LAuyg1rI in Y0WVJ5CTpDO:
				NroHCBWaxUZOfbgqMzAL4vJ2 = aeBQsh4fzLr8XM5xou1gcyE+'/ajaxcenter/action/HomepageLoader/tab/'+IFJL23MGvf4pdDAwxSe7jORUk6ybo+FhQgHPaqfANrMkbmi27coSVz+'/'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2,421)
				qSTQadRYkueMBEG = True
		if qSTQadRYkueMBEG: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	if pm4F0M2Dsuh6otP7Zi5NXT=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('PinSlider(.*?)MultiFilter',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('PinSlider(.*?)PageTitle',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		else: Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
	elif '/filter/' in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('PageContent(.*?)class="*pagination"*',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif '/actors' in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('PageContent(.*?)class="*pagination"*',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('Cima4uBlocks(.*?)</li></ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		else: Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
	if not items: items = fNntYJW45mEFSdRX8g.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: items = fNntYJW45mEFSdRX8g.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		if not title: continue
		if '?news=' in B17r2fdFy9ns8tiOMLu: continue
		title = title.replace('مشاهدة ',sCHVtMAvqirbQ4BUK3cgWo)
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) حلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if bbFPOJrmkCaE6ul37XiKU and 'حلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,422,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/actor/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,421,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,422,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR and pm4F0M2Dsuh6otP7Zi5NXT!='featured':
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
			if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,421)
	fMlokB12KS3wrF = fNntYJW45mEFSdRX8g.findall('</li><a href="(.*?)".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if fMlokB12KS3wrF:
		B17r2fdFy9ns8tiOMLu,title = fMlokB12KS3wrF[0]
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,421)
	return
def XTVdM7xH3Z9vEKna1uq2plbWy(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-SEASONS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="WatchNow".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		url = oPnz7Zt4xLHTwR[0]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-SEASONS-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('SeasonsSections(.*?)</div></div></div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if '/tag/' in url or '/actor' in url:
		fs7D0d3QyAT(url)
	elif oPnz7Zt4xLHTwR:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Thumb')
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall("href='(.*?)'>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		zV8m6pXkuNvb2EHght9oa = ['مسلسل','موسم','برنامج','حلقة']
		for B17r2fdFy9ns8tiOMLu,title in items:
			if any(value in title for value in zV8m6pXkuNvb2EHght9oa):
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,423,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,426,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else: VzOBjnIkZSH7ft(url)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"background-image:url\((.*?)\)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
	else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = sCHVtMAvqirbQ4BUK3cgWo
	JuMsyDf3elBpHVq6AcQtEaxmw = fNntYJW45mEFSdRX8g.findall('EpisodesSection(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if JuMsyDf3elBpHVq6AcQtEaxmw:
		Po9h3gWFuLR2 = JuMsyDf3elBpHVq6AcQtEaxmw[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,bbFPOJrmkCaE6ul37XiKU in items:
			title = title+AAh0X3OCacr4HpifRGLZKT+bbFPOJrmkCaE6ul37XiKU
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,426,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+'رابط التشغيل',url,426,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	EAZunpmsk9z57jQVUyXB6ld = UHqibFEGL8fjKhI.url
	if qdUK5ioJyrO1T: EAZunpmsk9z57jQVUyXB6ld = EAZunpmsk9z57jQVUyXB6ld.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(EAZunpmsk9z57jQVUyXB6ld,'url')
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('WatchSection(.*?)</div></div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('data-link="(.*?)".*? />(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for DvXq6pumzN7AyP50rU,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if 'myvid' in title.lower(): title = 'خاص '+title
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/structure/server.php?id='+DvXq6pumzN7AyP50rU+'?named='+title+'__watch'
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('DownloadServers(.*?)</div></div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*? />(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if 'myvid' in title.lower(): dwDUvp0LAuyg1rI = '__خاص'
			else: dwDUvp0LAuyg1rI = sCHVtMAvqirbQ4BUK3cgWo
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+dwDUvp0LAuyg1rI
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/Search?q='+search
	fs7D0d3QyAT(url,'search')
	return
def J6qLc3tuKiNQS1gdma45IFTo(url):
	if 'smartemadfilter' not in url: url = GABnmSFOwtsu37(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('MultiFilter(.*?)PageTitle',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return ssNoPMBKbeHfzu09G7vpDgyEZiIm
def qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2):
	items = fNntYJW45mEFSdRX8g.findall('data-id="(.*?)".*?</div>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return items
def UR7wsGhrVpTqilKnXNPezbYD0(url):
	OLN043hZlvyaB = url.split('/smartemadfilter?')[0]
	ffnlE3miaPHCj6NU40zvh7QFwsI2 = GABnmSFOwtsu37(url,'url')
	url = url.replace(OLN043hZlvyaB,ffnlE3miaPHCj6NU40zvh7QFwsI2)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
JqMFOusdXt69Py = ['category','types','release-year']
QC1LKoSRIvJFA7fpx3u0 = ['Quality','release-year','types','category']
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global JqMFOusdXt69Py
			JqMFOusdXt69Py = JqMFOusdXt69Py[1:]
		if JqMFOusdXt69Py[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(JqMFOusdXt69Py[0:-1])):
			if JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+ukGBUJAz02tOe
	elif type=='ALL_ITEMS_FILTER':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+RLkAVfXyplPhsSgb9760oCZW
		vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها ',vrEJRkchKxtDNiqO1b79mL5eT,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filter')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',vrEJRkchKxtDNiqO1b79mL5eT,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filter')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = J6qLc3tuKiNQS1gdma45IFTo(url)
	dict = {}
	for name,Po9h3gWFuLR2,ppWPYnc0JHvsmuTBqCXDEkzyN8 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		if '/category/' in url and ppWPYnc0JHvsmuTBqCXDEkzyN8=='category': continue
		name = name.replace('--',sCHVtMAvqirbQ4BUK3cgWo)
		items = qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='SPECIFIED_FILTER':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<2:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]:
					url = UR7wsGhrVpTqilKnXNPezbYD0(url)
					fs7D0d3QyAT(url)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'SPECIFIED_FILTER___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filter')
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,425,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='ALL_ITEMS_FILTER':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع :'+name,vrEJRkchKxtDNiqO1b79mL5eT,424,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if value=='196533': CCzds3YbQDjKUFxfA5RHMIyBaSt = 'أفلام نيتفلكس'
			elif value=='196531': CCzds3YbQDjKUFxfA5RHMIyBaSt = 'مسلسلات نيتفلكس'
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'#+dict[ppWPYnc0JHvsmuTBqCXDEkzyN8]['0']
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'+name
			if type=='ALL_ITEMS_FILTER': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,424,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='SPECIFIED_FILTER' and JqMFOusdXt69Py[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'modified_filters')
				rdQ5tOIzuelfvcYbNsM = url+'/smartemadfilter?'+ukGBUJAz02tOe
				rdQ5tOIzuelfvcYbNsM = UR7wsGhrVpTqilKnXNPezbYD0(rdQ5tOIzuelfvcYbNsM)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,421,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filter')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,425,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.replace('=&','=0&')
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	for key in QC1LKoSRIvJFA7fpx3u0:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if '%' not in value: value = IgCGzHw45TJ7PeuO1EKl(value)
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.replace('=0','=')
	return FQZjpoeBUGkTShcbE3d
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
headers = { 'User-Agent' : sCHVtMAvqirbQ4BUK3cgWo }
Ll1m0nJoaAPvHsXqyRE = 'AKWAM'
Z0BYJQghVL1v87CAem = '_AKW_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MOfrsNYL31Ktm6p = sCHVtMAvqirbQ4BUK3cgWo
MqARWHDkmiT4nlz = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==240: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==241: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==242: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==243: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==244: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'FILTERS___'+text)
	elif mode==245: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'CATEGORIES___'+text)
	elif mode==246: ka7jz96YCdTBnQOLVPuJG3285MHf = DvkcTgS1Pw(url)
	elif mode==247: ka7jz96YCdTBnQOLVPuJG3285MHf = siMN4Rf1WQom0eqA7rgvVP6BbzCd(url)
	elif mode==248: ka7jz96YCdTBnQOLVPuJG3285MHf = SlHnvBIboFqUAaJEhZw14gsW()
	elif mode==249: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def SlHnvBIboFqUAaJEhZw14gsW():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'AKWAM-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	VMRdWBSeTCsmivIbJPO0lLpc4wy = fNntYJW45mEFSdRX8g.findall('home-site-btn-container.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if VMRdWBSeTCsmivIbJPO0lLpc4wy: VMRdWBSeTCsmivIbJPO0lLpc4wy = VMRdWBSeTCsmivIbJPO0lLpc4wy[0]
	else: VMRdWBSeTCsmivIbJPO0lLpc4wy = gAVl1vUmus8
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',VMRdWBSeTCsmivIbJPO0lLpc4wy,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'AKWAM-MENU-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,249,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',gAVl1vUmus8,246)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',gAVl1vUmus8,247)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',VMRdWBSeTCsmivIbJPO0lLpc4wy,241,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	recent = fNntYJW45mEFSdRX8g.findall('recently-container.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	B17r2fdFy9ns8tiOMLu = recent[0]
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أضيف حديثا',B17r2fdFy9ns8tiOMLu,241)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,name,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
		if name in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,241)
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			title = name+AAh0X3OCacr4HpifRGLZKT+title
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,241)
	return
def DvkcTgS1Pw(website=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKWAM-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu(.*?)<nav',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?text">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz:
				title = title+' مصنفة'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,245)
		if website==sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	return Sw0pOFoVhPeIxbl
def siMN4Rf1WQom0eqA7rgvVP6BbzCd(website=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'AKWAM-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu(.*?)<nav',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?text">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title not in MqARWHDkmiT4nlz:
				title = title+' مفلترة'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,244)
		if website==sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('swiper-container(.*?)swiper-button-prev',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="widget"(.*?)main-footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not items:
			items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
			if '/series/' in B17r2fdFy9ns8tiOMLu or '/shows/' in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,242,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			elif '/movies/' in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,243,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			elif '/games/' not in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,243,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			B17r2fdFy9ns8tiOMLu = tt36wUe4HTPFmfs5hcbr(B17r2fdFy9ns8tiOMLu)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,241)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	url = gAVl1vUmus8 + '/search?q='+ktT4O0VJm8UaDNlxKvinoBYFgdH
	ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	return
def VzOBjnIkZSH7ft(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in Sw0pOFoVhPeIxbl:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Icon')
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+'رابط التشغيل',url,243,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('-episodes">(.*?)<div class="widget-4',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		pWu3ti618zVAbjdf7 = fNntYJW45mEFSdRX8g.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in pWu3ti618zVAbjdf7:
			title = title.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,242,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,243,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKWAM-PLAY-1st')
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('badge-danger.*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	JVXYbzyvU6hmQRHWKeZ = fNntYJW45mEFSdRX8g.findall('li><a href="#(.*?)".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X,Jae64ky3REO57A2MvVHB90,KEsXoQP4U98OatkxW = [],[],[],[]
	if JVXYbzyvU6hmQRHWKeZ:
		ccDFuk5NAjMTqo3hv = 'mp4'
		for RZm7QpeBkEMf6YidoPJACSvl,XO7Zr2W6kwieA in JVXYbzyvU6hmQRHWKeZ:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('tab-content quality" id="'+RZm7QpeBkEMf6YidoPJACSvl+'".*?</div>.\s*</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			Jae64ky3REO57A2MvVHB90.append(Po9h3gWFuLR2)
			KEsXoQP4U98OatkxW.append(XO7Zr2W6kwieA)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="qualities(.*?)<h3.*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			Po9h3gWFuLR2,filename = oPnz7Zt4xLHTwR[0]
			PMBCoYnud5cytxL23TRaG4h = ['zip','rar','txt','pdf','htm','tar','iso','html']
			ccDFuk5NAjMTqo3hv = filename.rsplit('.',1)[1].strip(AAh0X3OCacr4HpifRGLZKT)
			if ccDFuk5NAjMTqo3hv in PMBCoYnud5cytxL23TRaG4h:
				ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'الملف ليس فيديو ولا صوت')
				return
		Jae64ky3REO57A2MvVHB90.append(Po9h3gWFuLR2)
		KEsXoQP4U98OatkxW.append(sCHVtMAvqirbQ4BUK3cgWo)
	for XMIo9vWSBymeLJnK6YsU in range(len(Jae64ky3REO57A2MvVHB90)):
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?icon-(.*?)"',Jae64ky3REO57A2MvVHB90[XMIo9vWSBymeLJnK6YsU],fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,XXiWerLobpQPhI in PXFtqmw5lBGQNa0IV8:
			if 'torrent' in XXiWerLobpQPhI: continue
			elif 'download' in XXiWerLobpQPhI: type = 'download'
			elif 'play' in XXiWerLobpQPhI: type = 'watch'
			else: type = 'unknown'
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named=__'+type+'____'+KEsXoQP4U98OatkxW[XMIo9vWSBymeLJnK6YsU]+'__akwam'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	JqMFOusdXt69Py = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='CATEGORIES':
		if JqMFOusdXt69Py[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(JqMFOusdXt69Py[0:-1])):
			if JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'?'+ukGBUJAz02tOe
	elif type=='FILTERS':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'?'+RLkAVfXyplPhsSgb9760oCZW
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها',vrEJRkchKxtDNiqO1b79mL5eT,241,sCHVtMAvqirbQ4BUK3cgWo,'1')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',vrEJRkchKxtDNiqO1b79mL5eT,241,sCHVtMAvqirbQ4BUK3cgWo,'1')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,True,'AKWAM-FILTERS_MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<form id(.*?)</form>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	dict = {}
	for ppWPYnc0JHvsmuTBqCXDEkzyN8,name,Po9h3gWFuLR2 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		items = fNntYJW45mEFSdRX8g.findall('<option(.*?)>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='CATEGORIES':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<=1:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'CATEGORIES___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,241,sCHVtMAvqirbQ4BUK3cgWo,'1')
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,245,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='FILTERS':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع : '+name,vrEJRkchKxtDNiqO1b79mL5eT,244,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			if 'value' not in value: value = CCzds3YbQDjKUFxfA5RHMIyBaSt
			else: value = fNntYJW45mEFSdRX8g.findall('"(.*?)"',value,fNntYJW45mEFSdRX8g.DOTALL)[0]
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' : '#+dict[ppWPYnc0JHvsmuTBqCXDEkzyN8]['0']
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' : '+name
			if type=='FILTERS': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,244,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='CATEGORIES' and JqMFOusdXt69Py[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'all')
				rdQ5tOIzuelfvcYbNsM = url+'?'+ukGBUJAz02tOe
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,241,sCHVtMAvqirbQ4BUK3cgWo,'1')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,245,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	QC1LKoSRIvJFA7fpx3u0 = ['section','category','rating','year','language','formats','quality']
	for key in QC1LKoSRIvJFA7fpx3u0:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	return FQZjpoeBUGkTShcbE3d
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
import bs4 as ww82JdBj0osLnp9W
Ll1m0nJoaAPvHsXqyRE = 'ELCINEMA'
Z0BYJQghVL1v87CAem = '_ELC_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
headers = {'Referer':gAVl1vUmus8}
MqARWHDkmiT4nlz = []
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==510: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==511: ka7jz96YCdTBnQOLVPuJG3285MHf = Mm2obZ1IcGksDBlCPqOYLHiuyt5Sx(url)
	elif mode==512: ka7jz96YCdTBnQOLVPuJG3285MHf = TTZxbksPGABtwEz8YV(url)
	elif mode==513: ka7jz96YCdTBnQOLVPuJG3285MHf = ZZzBrEuUy7wc2(url)
	elif mode==514: ka7jz96YCdTBnQOLVPuJG3285MHf = ZGqC638Tm4UonjKuNdHaEDvleLb(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: ka7jz96YCdTBnQOLVPuJG3285MHf = ZGqC638Tm4UonjKuNdHaEDvleLb(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: ka7jz96YCdTBnQOLVPuJG3285MHf = hg9tKaw1ryiUCsfE4G(text)
	elif mode==517: ka7jz96YCdTBnQOLVPuJG3285MHf = Gzud4aA7hwWYt8cUlIsger56ZKfD(url)
	elif mode==518: ka7jz96YCdTBnQOLVPuJG3285MHf = yyR3TXNZ1u(url)
	elif mode==519: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	elif mode==520: ka7jz96YCdTBnQOLVPuJG3285MHf = o6ZYMpV3kb(url)
	elif mode==521: ka7jz96YCdTBnQOLVPuJG3285MHf = lcYOxQvWKomyR1NjLB(url)
	elif mode==522: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==523: ka7jz96YCdTBnQOLVPuJG3285MHf = fw5dRNP9rSOioJh834Gv1CWgYm(text)
	elif mode==524: ka7jz96YCdTBnQOLVPuJG3285MHf = XUmTLkgxsC()
	elif mode==525: ka7jz96YCdTBnQOLVPuJG3285MHf = ZxtrSyApYu()
	elif mode==526: ka7jz96YCdTBnQOLVPuJG3285MHf = PKhT4cofNnmag52BZL9FixjtUu()
	elif mode==527: ka7jz96YCdTBnQOLVPuJG3285MHf = vARdrP26jXqKNCoZbu0hx()
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث بموسوعة السينما',sCHVtMAvqirbQ4BUK3cgWo,519)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'موسوعة الأعمال',sCHVtMAvqirbQ4BUK3cgWo,525)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'موسوعة الأشخاص',sCHVtMAvqirbQ4BUK3cgWo,526)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'موسوعة المصنفات',sCHVtMAvqirbQ4BUK3cgWo,527)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'موسوعة المنوعات',sCHVtMAvqirbQ4BUK3cgWo,524)
	return
def XUmTLkgxsC():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' فيديوهات - خاصة',gAVl1vUmus8+'/video',520)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فيديوهات - أحدث',gAVl1vUmus8+'/video/latest',521)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فيديوهات - أقدم',gAVl1vUmus8+'/video/oldest',521)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فيديوهات - أكثر مشاهدة',gAVl1vUmus8+'/video/views',521)
	return
def ZxtrSyApYu():
	bP3YCpBqOcuaI2HAkdQfmstzR1L = gAVl1vUmus8+'/lineup?utf8=%E2%9C%93'
	tzJHT2cVPRSaNmfpqA = bP3YCpBqOcuaI2HAkdQfmstzR1L+'&type=2&category=1&foreign=false&tag='
	SvgYZR2hc7lGLneroW5Xswz8BNHT1q = bP3YCpBqOcuaI2HAkdQfmstzR1L+'&type=2&category=3&foreign=false&tag='
	rE8DyOwVK5Gic4XTA = bP3YCpBqOcuaI2HAkdQfmstzR1L+'&type=2&category=1&foreign=true&tag='
	m78U5zTasDIyOAq = bP3YCpBqOcuaI2HAkdQfmstzR1L+'&type=2&category=3&foreign=true&tag='
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات أفلام عربي',tzJHT2cVPRSaNmfpqA,511)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات مسلسلات عربي',SvgYZR2hc7lGLneroW5Xswz8BNHT1q,511)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات أفلام اجنبي',rE8DyOwVK5Gic4XTA,511)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات مسلسلات اجنبي',m78U5zTasDIyOAq,511)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس أعمال أبجدي',gAVl1vUmus8+'/index/work/alphabet',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس  بلد الإنتاج',gAVl1vUmus8+'/index/work/country',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس اللغة',gAVl1vUmus8+'/index/work/language',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس مصنفات العمل',gAVl1vUmus8+'/index/work/genre',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس سنة الإصدار',gAVl1vUmus8+'/index/work/release_year',517)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مواسم - فلتر محدد',gAVl1vUmus8+'/seasonals',515)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مواسم - فلتر كامل',gAVl1vUmus8+'/seasonals',514)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات - فلتر محدد',gAVl1vUmus8+'/lineup',515)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات - فلتر كامل',gAVl1vUmus8+'/lineup',514)
	return
def vARdrP26jXqKNCoZbu0hx():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8+'/lineup',sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Po9h3gWFuLR2 = F17ecOpvsYb3REWA.find('select',attrs={'name':'tag'})
	Z2VkQhiPAOuboSRB = Po9h3gWFuLR2.find_all('option')
	for CCzds3YbQDjKUFxfA5RHMIyBaSt in Z2VkQhiPAOuboSRB:
		value = CCzds3YbQDjKUFxfA5RHMIyBaSt.get('value')
		if not value: continue
		title = CCzds3YbQDjKUFxfA5RHMIyBaSt.text
		if qdUK5ioJyrO1T:
			title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			value = value.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',sCHVtMAvqirbQ4BUK3cgWo)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,511)
	return
def PKhT4cofNnmag52BZL9FixjtUu():
	bP3YCpBqOcuaI2HAkdQfmstzR1L = gAVl1vUmus8+'/lineup?utf8=%E2%9C%93'
	mkTJF3suO6yQMES = bP3YCpBqOcuaI2HAkdQfmstzR1L+'&type=1&category=&foreign=&tag='
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات أشخاص',mkTJF3suO6yQMES,511)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس أشخاص أبجدي',gAVl1vUmus8+'/index/person/alphabet',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس موطن',gAVl1vUmus8+'/index/person/nationality',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس  تاريخ الميلاد',gAVl1vUmus8+'/index/person/birth_year',517)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فهرس  تاريخ الوفاة',gAVl1vUmus8+'/index/person/death_year',517)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات - فلتر محدد',gAVl1vUmus8+'/lineup',515)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مصنفات - فلتر كامل',gAVl1vUmus8+'/lineup',514)
	return
def Mm2obZ1IcGksDBlCPqOYLHiuyt5Sx(url):
	if '/seasonals' in url: nTxciHKjwprDmO = 0
	elif '/lineup' in url: nTxciHKjwprDmO = 1
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-LISTS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Jae64ky3REO57A2MvVHB90 = F17ecOpvsYb3REWA.find_all(class_='jumbo-theater clearfix')
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		title = Po9h3gWFuLR2.find_all('a')[nTxciHKjwprDmO].text
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+Po9h3gWFuLR2.find_all('a')[nTxciHKjwprDmO].get('href')
		if qdUK5ioJyrO1T:
			title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		if not Jae64ky3REO57A2MvVHB90:
			TTZxbksPGABtwEz8YV(B17r2fdFy9ns8tiOMLu)
			return
		else:
			title = title.replace('قائمة ',sCHVtMAvqirbQ4BUK3cgWo)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,512)
	HYPCgInSqDoZyBv3eziWNXpE(F17ecOpvsYb3REWA,511)
	return
def HYPCgInSqDoZyBv3eziWNXpE(F17ecOpvsYb3REWA,mode):
	Po9h3gWFuLR2 = F17ecOpvsYb3REWA.find(class_='pagination')
	if Po9h3gWFuLR2:
		WdOkgLCxqNDG = Po9h3gWFuLR2.find_all('a')
		CHXjcVaLYnelSPJyOZ0Tz9uKMowAb = Po9h3gWFuLR2.find_all('li')
		tTnpr6sKuAaCQ = list(zip(WdOkgLCxqNDG,CHXjcVaLYnelSPJyOZ0Tz9uKMowAb))
		ruCEzOyVgmGt9WHI7BSofF6d8 = -1
		l4M5eoBRmE = len(tTnpr6sKuAaCQ)
		for cLsJOECgZlU5Pp1RMVI0WTr,DvWILxzl1Rky in tTnpr6sKuAaCQ:
			ruCEzOyVgmGt9WHI7BSofF6d8 += 1
			DvWILxzl1Rky = DvWILxzl1Rky['class']
			if 'unavailable' in DvWILxzl1Rky or 'current' in DvWILxzl1Rky: continue
			XXqGLnKo8vWYh1IMz9C0 = cLsJOECgZlU5Pp1RMVI0WTr.text
			NroHCBWaxUZOfbgqMzAL4vJ2 = gAVl1vUmus8+cLsJOECgZlU5Pp1RMVI0WTr.get('href')
			if qdUK5ioJyrO1T:
				XXqGLnKo8vWYh1IMz9C0 = XXqGLnKo8vWYh1IMz9C0.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				NroHCBWaxUZOfbgqMzAL4vJ2 = NroHCBWaxUZOfbgqMzAL4vJ2.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			if   ruCEzOyVgmGt9WHI7BSofF6d8==0: XXqGLnKo8vWYh1IMz9C0 = 'أولى'
			elif ruCEzOyVgmGt9WHI7BSofF6d8==1: XXqGLnKo8vWYh1IMz9C0 = 'سابقة'
			elif ruCEzOyVgmGt9WHI7BSofF6d8==l4M5eoBRmE-2: XXqGLnKo8vWYh1IMz9C0 = 'لاحقة'
			elif ruCEzOyVgmGt9WHI7BSofF6d8==l4M5eoBRmE-1: XXqGLnKo8vWYh1IMz9C0 = 'أخيرة'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+XXqGLnKo8vWYh1IMz9C0,NroHCBWaxUZOfbgqMzAL4vJ2,mode)
	return
def TTZxbksPGABtwEz8YV(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-TITLES1-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Jae64ky3REO57A2MvVHB90 = F17ecOpvsYb3REWA.find_all(class_='row')
	items,trd5bZgxTR = [],True
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		if not Po9h3gWFuLR2.find(class_='thumbnail-wrapper'): continue
		if trd5bZgxTR: trd5bZgxTR = False ; continue
		fU2Tc3aME9x1igFrSh7elVGK4v0JXk = []
		jwba7n0GkDBS1PzMAKfe = Po9h3gWFuLR2.find_all(class_=['censorship red','censorship purple'])
		for BYaX1VTj5xb in jwba7n0GkDBS1PzMAKfe:
			qvJbgdM9esQ53RA1 = BYaX1VTj5xb.find_all('li')[1].text
			if qdUK5ioJyrO1T:
				qvJbgdM9esQ53RA1 = qvJbgdM9esQ53RA1.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			fU2Tc3aME9x1igFrSh7elVGK4v0JXk.append(qvJbgdM9esQ53RA1)
		if not NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,sCHVtMAvqirbQ4BUK3cgWo,fU2Tc3aME9x1igFrSh7elVGK4v0JXk,False):
			Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('data-src')
			title = Po9h3gWFuLR2.find('h3')
			name = title.find('a').text
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+title.find('a').get('href')
			xUXQbeRHCY = Po9h3gWFuLR2.find(class_='no-margin')
			LLK65NaZBX = Po9h3gWFuLR2.find(class_='legend')
			if xUXQbeRHCY: xUXQbeRHCY = xUXQbeRHCY.text
			if LLK65NaZBX: LLK65NaZBX = LLK65NaZBX.text
			if qdUK5ioJyrO1T:
				Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				name = name.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				if xUXQbeRHCY: xUXQbeRHCY = xUXQbeRHCY.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			ZQC69Pyo4BOamJlwSLtAWINg7q = {}
			if LLK65NaZBX: ZQC69Pyo4BOamJlwSLtAWINg7q['stars'] = LLK65NaZBX
			if xUXQbeRHCY:
				xUXQbeRHCY = xUXQbeRHCY.replace(slFfrUIWCowaBA7tce3iZbj8xn,' .. ')
				ZQC69Pyo4BOamJlwSLtAWINg7q['plot'] = xUXQbeRHCY.replace('...اقرأ المزيد',sCHVtMAvqirbQ4BUK3cgWo)
			if '/work/' in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,516,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q)
			elif '/person/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,513,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q)
	HYPCgInSqDoZyBv3eziWNXpE(F17ecOpvsYb3REWA,512)
	return
def ZZzBrEuUy7wc2(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-TITLES2-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Jae64ky3REO57A2MvVHB90 = F17ecOpvsYb3REWA.find_all('li')
	IAEfYnUaKMF7DhW,items = [],[]
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		if not Po9h3gWFuLR2.find(class_='thumbnail-wrapper'): continue
		if not Po9h3gWFuLR2.find(class_=['unstyled','unstyled text-center']): continue
		if Po9h3gWFuLR2.find(class_='hide'): continue
		title = Po9h3gWFuLR2.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in IAEfYnUaKMF7DhW: continue
		IAEfYnUaKMF7DhW.append(name)
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+title.find('a').get('href')
		if '/search/work/' in url: Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('src')
		elif '/search/person/' in url: Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('data-src')
		elif '/search/video/' in url: Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('data-src')
		else: Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('src')
		if qdUK5ioJyrO1T:
			name = name.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		name = name.strip(AAh0X3OCacr4HpifRGLZKT)
		items.append((name,B17r2fdFy9ns8tiOMLu,Qp3jGv8leCbuiEU5Im))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,B17r2fdFy9ns8tiOMLu,Qp3jGv8leCbuiEU5Im in items:
		if '/search/video/' in url: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,522,Qp3jGv8leCbuiEU5Im)
		elif '/search/person/' in url: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,513,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,516,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name)
	return
def hg9tKaw1ryiUCsfE4G(text):
	text = text.replace('الإعلان',sCHVtMAvqirbQ4BUK3cgWo).replace('لفيلم',sCHVtMAvqirbQ4BUK3cgWo).replace('الرسمي',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace('إعلان',sCHVtMAvqirbQ4BUK3cgWo).replace('فيلم',sCHVtMAvqirbQ4BUK3cgWo).replace('البرومو',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace('التشويقي',sCHVtMAvqirbQ4BUK3cgWo).replace('لمسلسل',sCHVtMAvqirbQ4BUK3cgWo).replace('مسلسل',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace(':',sCHVtMAvqirbQ4BUK3cgWo).replace(')',sCHVtMAvqirbQ4BUK3cgWo).replace('(',sCHVtMAvqirbQ4BUK3cgWo).replace(',',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace('_',sCHVtMAvqirbQ4BUK3cgWo).replace(';',sCHVtMAvqirbQ4BUK3cgWo).replace('-',sCHVtMAvqirbQ4BUK3cgWo).replace('.',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace('\'',sCHVtMAvqirbQ4BUK3cgWo).replace('\"',sCHVtMAvqirbQ4BUK3cgWo)
	text = text.replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	text = text.strip(AAh0X3OCacr4HpifRGLZKT)
	F1AXVgQ5W4LaZMGNYKU = text.count(AAh0X3OCacr4HpifRGLZKT)+1
	if F1AXVgQ5W4LaZMGNYKU==1:
		fw5dRNP9rSOioJh834Gv1CWgYm(text)
		return
	XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+VXWOCAE6ns3paJ8DLG479NQfMu+'==== كلمات للبحث ===='+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	IyC5eznObHuqjkdJ9Lf6ZVUNGcvmtT = text.split(AAh0X3OCacr4HpifRGLZKT)
	LkDMBpPd2lmVXJwqgRh = pow(2,F1AXVgQ5W4LaZMGNYKU)
	JEHnsWjXY5Tlb = []
	def jPJWX3z02nsuvL8REet59(WRBJCFc6Yg,cce6g1pARrUxGuEySF4):
		if WRBJCFc6Yg=='1': return cce6g1pARrUxGuEySF4
		return sCHVtMAvqirbQ4BUK3cgWo
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(LkDMBpPd2lmVXJwqgRh,0,-1):
		cfGnFZuJTELrzwRi942X6S = list(F1AXVgQ5W4LaZMGNYKU*'0'+bin(ruCEzOyVgmGt9WHI7BSofF6d8)[2:])[-F1AXVgQ5W4LaZMGNYKU:]
		cfGnFZuJTELrzwRi942X6S = reversed(cfGnFZuJTELrzwRi942X6S)
		YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = map(jPJWX3z02nsuvL8REet59,cfGnFZuJTELrzwRi942X6S,IyC5eznObHuqjkdJ9Lf6ZVUNGcvmtT)
		title = AAh0X3OCacr4HpifRGLZKT.join(filter(None,YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z))
		if qdUK5ioJyrO1T: dwDUvp0LAuyg1rI = title.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		else: dwDUvp0LAuyg1rI = title
		if len(dwDUvp0LAuyg1rI)>2 and title not in JEHnsWjXY5Tlb:
			JEHnsWjXY5Tlb.append(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,523,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,title)
	return
def fw5dRNP9rSOioJh834Gv1CWgYm(P9YiS4ysOIjdLz2C):
	if qdUK5ioJyrO1T:
		P9YiS4ysOIjdLz2C = P9YiS4ysOIjdLz2C.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		import arabic_reshaper as gMbq9wE2BhUGTm3JaH67i4OIFlX,bidi.algorithm as KKIAFzsoVcRrT9
		P9YiS4ysOIjdLz2C = gMbq9wE2BhUGTm3JaH67i4OIFlX.ArabicReshaper().reshape(P9YiS4ysOIjdLz2C)
		P9YiS4ysOIjdLz2C = KKIAFzsoVcRrT9.get_display(P9YiS4ysOIjdLz2C)
	import PG9FRcxAEz
	P9YiS4ysOIjdLz2C = UyBdvjGrFxDWMpmLOXn(FMZdXbKcEDgCzvuGUxorY93V=P9YiS4ysOIjdLz2C)
	PG9FRcxAEz.RsxrGI1pcyY3UXTSLiC(P9YiS4ysOIjdLz2C)
	return
def Gzud4aA7hwWYt8cUlIsger56ZKfD(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-INDEXES_LISTS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Po9h3gWFuLR2 = F17ecOpvsYb3REWA.find(class_='list-separator list-title')
	J4EIW0hU16YCcqn92uatb3 = Po9h3gWFuLR2.find_all('a')
	items = []
	for title in J4EIW0hU16YCcqn92uatb3:
		name = title.text
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+title.get('href')
		if qdUK5ioJyrO1T:
			name = name.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		if '#' not in B17r2fdFy9ns8tiOMLu: items.append((name,B17r2fdFy9ns8tiOMLu))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for UqKgalXPCz7eQAL08foMx1R in items:
		name,B17r2fdFy9ns8tiOMLu = UqKgalXPCz7eQAL08foMx1R
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,518)
	return
def yyR3TXNZ1u(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-INDEXES_TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Jae64ky3REO57A2MvVHB90 = F17ecOpvsYb3REWA.find(class_='expand').find_all('tr')
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		QQhPadl2UsEtqM0IwSp3fy6FXDVuo = Po9h3gWFuLR2.find_all('a')
		if not QQhPadl2UsEtqM0IwSp3fy6FXDVuo: continue
		Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('data-src')
		name = QQhPadl2UsEtqM0IwSp3fy6FXDVuo[1].text
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+QQhPadl2UsEtqM0IwSp3fy6FXDVuo[1].get('href')
		LLK65NaZBX = Po9h3gWFuLR2.find(class_='legend')
		if LLK65NaZBX: LLK65NaZBX = LLK65NaZBX.text
		if qdUK5ioJyrO1T:
			name = name.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		ZQC69Pyo4BOamJlwSLtAWINg7q = {}
		if LLK65NaZBX: ZQC69Pyo4BOamJlwSLtAWINg7q['stars'] = LLK65NaZBX
		if '/work/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,516,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q)
		elif '/person/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+name,B17r2fdFy9ns8tiOMLu,513,Qp3jGv8leCbuiEU5Im,sCHVtMAvqirbQ4BUK3cgWo,name,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q)
	HYPCgInSqDoZyBv3eziWNXpE(F17ecOpvsYb3REWA,518)
	return
def o6ZYMpV3kb(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-VIDEOS_LISTS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	J4EIW0hU16YCcqn92uatb3 = F17ecOpvsYb3REWA.find_all(class_='section-title inline')
	PXFtqmw5lBGQNa0IV8 = F17ecOpvsYb3REWA.find_all(class_='button green small right')
	items = zip(J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8)
	for title,B17r2fdFy9ns8tiOMLu in items:
		title = title.text
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu.get('href')
		if qdUK5ioJyrO1T:
			title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		title = title.replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,521)
	return
def lcYOxQvWKomyR1NjLB(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-VIDEOS_TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Shw1i7dCP9ezUY5o2u8T = F17ecOpvsYb3REWA.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	Jae64ky3REO57A2MvVHB90 = Shw1i7dCP9ezUY5o2u8T.find_all('li')
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		title = Po9h3gWFuLR2.find(class_='title').text
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+Po9h3gWFuLR2.find('a').get('href')
		Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2.find('img').get('data-src')
		yAMScJ6z3E8 = Po9h3gWFuLR2.find(class_='duration').text
		if qdUK5ioJyrO1T:
			title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			yAMScJ6z3E8 = yAMScJ6z3E8.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		yAMScJ6z3E8 = yAMScJ6z3E8.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,522,Qp3jGv8leCbuiEU5Im,yAMScJ6z3E8)
	HYPCgInSqDoZyBv3eziWNXpE(F17ecOpvsYb3REWA,521)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	B17r2fdFy9ns8tiOMLu = F17ecOpvsYb3REWA.find(class_='flex-video').find('iframe').get('src')
	if qdUK5ioJyrO1T: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1([B17r2fdFy9ns8tiOMLu],Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	url = gAVl1vUmus8+'/search/?q='+search
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-SEARCH-1st')
	if not UHqibFEGL8fjKhI.succeeded:
		mkTJF3suO6yQMES = gAVl1vUmus8+'/search_entity/?q='+search+'&entity=work'
		NroHCBWaxUZOfbgqMzAL4vJ2 = gAVl1vUmus8+'/search_entity/?q='+search+'&entity=person'
		ToVLNn7B1MsY9dzjpgkW = gAVl1vUmus8+'/search_entity/?q='+search+'&entity=video'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن أعمال',mkTJF3suO6yQMES,513,sCHVtMAvqirbQ4BUK3cgWo,search)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن أشخاص',NroHCBWaxUZOfbgqMzAL4vJ2,513,sCHVtMAvqirbQ4BUK3cgWo,search)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث عن فيديوهات',ToVLNn7B1MsY9dzjpgkW,513,sCHVtMAvqirbQ4BUK3cgWo,search)
		return
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	F17ecOpvsYb3REWA = ww82JdBj0osLnp9W.BeautifulSoup(Sw0pOFoVhPeIxbl,'html.parser',multi_valued_attributes=None)
	Jae64ky3REO57A2MvVHB90 = F17ecOpvsYb3REWA.find_all(class_='section-title left')
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		title = Po9h3gWFuLR2.text
		if qdUK5ioJyrO1T:
			title = title.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		title = title.split('(',1)[0].strip(AAh0X3OCacr4HpifRGLZKT)
		if   'أعمال' in title: B17r2fdFy9ns8tiOMLu = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: B17r2fdFy9ns8tiOMLu = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: B17r2fdFy9ns8tiOMLu = url.replace('/search/','/search/video/')
		else: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,513)
	return
def ZGqC638Tm4UonjKuNdHaEDvleLb(url,text):
	global JqMFOusdXt69Py,QC1LKoSRIvJFA7fpx3u0
	if '/seasonals' in url:
		JqMFOusdXt69Py = ['seasonal','year','category']
		QC1LKoSRIvJFA7fpx3u0 = ['seasonal','year','category']
	elif '/lineup' in url:
		JqMFOusdXt69Py = ['category','foreign','type']
		QC1LKoSRIvJFA7fpx3u0 = ['category','foreign','type']
	mke5qXIUM8Fd2Ljb4Rv3y(url,text)
	return
def J6qLc3tuKiNQS1gdma45IFTo(url):
	url = url.split('/smartemadfilter?')[0]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('form action="/(.*?)</form>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return ssNoPMBKbeHfzu09G7vpDgyEZiIm
def qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2):
	items = fNntYJW45mEFSdRX8g.findall('<option value="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return items
def UR7wsGhrVpTqilKnXNPezbYD0(url):
	OLN043hZlvyaB = url.split('/smartemadfilter?')[0]
	ffnlE3miaPHCj6NU40zvh7QFwsI2 = GABnmSFOwtsu37(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def fPA6QWt4x075wcahUkGRyiIe(nGjoKRMy1mDqUx0,url):
	ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'all_filters')
	rdQ5tOIzuelfvcYbNsM = url+'/smartemadfilter?'+ukGBUJAz02tOe
	rdQ5tOIzuelfvcYbNsM = UR7wsGhrVpTqilKnXNPezbYD0(rdQ5tOIzuelfvcYbNsM)
	return rdQ5tOIzuelfvcYbNsM
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if JqMFOusdXt69Py[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(JqMFOusdXt69Py[0:-1])):
			if JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = JqMFOusdXt69Py[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+ukGBUJAz02tOe
	elif type=='ALL_ITEMS_FILTER':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW!=sCHVtMAvqirbQ4BUK3cgWo: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'modified_filters')
		if RLkAVfXyplPhsSgb9760oCZW==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+RLkAVfXyplPhsSgb9760oCZW
		vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها ',vrEJRkchKxtDNiqO1b79mL5eT,511)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',vrEJRkchKxtDNiqO1b79mL5eT,511)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = J6qLc3tuKiNQS1gdma45IFTo(url)
	dict = {}
	for name,ppWPYnc0JHvsmuTBqCXDEkzyN8,Po9h3gWFuLR2 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		name = name.replace('--',sCHVtMAvqirbQ4BUK3cgWo)
		items = qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='SPECIFIED_FILTER':
			if ppWPYnc0JHvsmuTBqCXDEkzyN8 not in JqMFOusdXt69Py: continue
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<2:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]:
					url = UR7wsGhrVpTqilKnXNPezbYD0(url)
					TTZxbksPGABtwEz8YV(url)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'SPECIFIED_FILTER___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				vrEJRkchKxtDNiqO1b79mL5eT = UR7wsGhrVpTqilKnXNPezbYD0(vrEJRkchKxtDNiqO1b79mL5eT)
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==JqMFOusdXt69Py[-1]: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,511)
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',vrEJRkchKxtDNiqO1b79mL5eT,515,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='ALL_ITEMS_FILTER':
			if ppWPYnc0JHvsmuTBqCXDEkzyN8 not in QC1LKoSRIvJFA7fpx3u0: continue
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع: '+name,vrEJRkchKxtDNiqO1b79mL5eT,514,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			if 'مصنفات أخرى' in CCzds3YbQDjKUFxfA5RHMIyBaSt: continue
			if 'الكل' in CCzds3YbQDjKUFxfA5RHMIyBaSt: continue
			if 'اللغة' in CCzds3YbQDjKUFxfA5RHMIyBaSt: continue
			CCzds3YbQDjKUFxfA5RHMIyBaSt = CCzds3YbQDjKUFxfA5RHMIyBaSt.replace('قائمة ',sCHVtMAvqirbQ4BUK3cgWo)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			if name: title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'+name
			else: title = CCzds3YbQDjKUFxfA5RHMIyBaSt
			if type=='ALL_ITEMS_FILTER': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,514,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='SPECIFIED_FILTER' and JqMFOusdXt69Py[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				rdQ5tOIzuelfvcYbNsM = fPA6QWt4x075wcahUkGRyiIe(nGjoKRMy1mDqUx0,url)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,511)
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,515,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.replace('=&','=0&')
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	for key in QC1LKoSRIvJFA7fpx3u0:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if '%' not in value: value = IgCGzHw45TJ7PeuO1EKl(value)
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all_filters': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.replace('=0','=')
	return FQZjpoeBUGkTShcbE3d
JqMFOusdXt69Py = []
QC1LKoSRIvJFA7fpx3u0 = []
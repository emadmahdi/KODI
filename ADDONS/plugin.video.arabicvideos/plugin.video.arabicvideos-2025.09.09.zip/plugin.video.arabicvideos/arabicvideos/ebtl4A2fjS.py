# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
qsActmwjBGK4Ia1OFihlnCz = 'IPTV'
Y6xCT1m2lpbnKLJPZ5R8hSqO = '_IPT_'
BBervUf81CI = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def wLkpI14XdRKiGohZ(QQ8kHjYnKEDU3sxft9S5iRoB,qhWpTazQ9ws,T67f3LG49xpP8zcN,iHPTUWrX1nbg,Ml0wzrY8uFeLOaPQyxmbX9,bK0LycGjJxiVCD):
	global Y6xCT1m2lpbnKLJPZ5R8hSqO
	try:
		n0mErNiResZbqGAJBv9MD = str(bK0LycGjJxiVCD['folder'])
		Y6xCT1m2lpbnKLJPZ5R8hSqO = '_IP'+n0mErNiResZbqGAJBv9MD+'_'
	except: n0mErNiResZbqGAJBv9MD = sCHVtMAvqirbQ4BUK3cgWo
	if   QQ8kHjYnKEDU3sxft9S5iRoB==230: PaQp3oz49JfRdYbywq = DXj03CeVTGswb4Nt6mnBAkryQ1uaL()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==231: PaQp3oz49JfRdYbywq = DDB7wFaNcizxyU48vh(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==232: PaQp3oz49JfRdYbywq = AgWpUkH7avPIDQlTd(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==233: PaQp3oz49JfRdYbywq = eyAvQG2hJUaLD9EVzC7t(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,T67f3LG49xpP8zcN,Ml0wzrY8uFeLOaPQyxmbX9)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==234: PaQp3oz49JfRdYbywq = N9pi3VIH5uR(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,T67f3LG49xpP8zcN,Ml0wzrY8uFeLOaPQyxmbX9)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==235: PaQp3oz49JfRdYbywq = YH54mqkD2eU06(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,iHPTUWrX1nbg)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==236: PaQp3oz49JfRdYbywq = VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,True)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==237: PaQp3oz49JfRdYbywq = HLQ1ZNlJWDdIixM(n0mErNiResZbqGAJBv9MD,True)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==238: PaQp3oz49JfRdYbywq = WFPIro0iEtVHwyqlT6QSzCsLBx9XY(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==239: PaQp3oz49JfRdYbywq = wwinEbetVG3su1TD2L7NFOp(T67f3LG49xpP8zcN,n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,Ml0wzrY8uFeLOaPQyxmbX9)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==280: PaQp3oz49JfRdYbywq = AtylB0o7GnY9ui1UQSqNdPL4r(n0mErNiResZbqGAJBv9MD,True)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==281: PaQp3oz49JfRdYbywq = uHTIzYAhjJ3qm9MDeW0BRbgZtK(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==282: PaQp3oz49JfRdYbywq = xxwJBgtV95On7DWHNGzfIThUYb(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==283: PaQp3oz49JfRdYbywq = yypMYPghQAUxsvc1t(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==285: PaQp3oz49JfRdYbywq = n9ymIsTHvEerj(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==286: PaQp3oz49JfRdYbywq = F2FxcPKzsrIt3YZoCVn8WD0eNb9L(n0mErNiResZbqGAJBv9MD)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==289: PaQp3oz49JfRdYbywq = O4QcEU3y2KYghPjAnBaFHNeMqL8G5(T67f3LG49xpP8zcN,n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,Ml0wzrY8uFeLOaPQyxmbX9)
	else: PaQp3oz49JfRdYbywq = False
	return PaQp3oz49JfRdYbywq
def DXj03CeVTGswb4Nt6mnBAkryQ1uaL():
	for n0mErNiResZbqGAJBv9MD in range(1,cjJXgt71A5+1):
		Y6xCT1m2lpbnKLJPZ5R8hSqO = '_IP'+str(n0mErNiResZbqGAJBv9MD)+'_'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قائمة مجلد '+dTacwSXg2MOGtHY[n0mErNiResZbqGAJBv9MD],sCHVtMAvqirbQ4BUK3cgWo,280,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	return
def AtylB0o7GnY9ui1UQSqNdPL4r(n0mErNiResZbqGAJBv9MD=sCHVtMAvqirbQ4BUK3cgWo,JOQGgY5w8D93IKM=sCHVtMAvqirbQ4BUK3cgWo):
	if n0mErNiResZbqGAJBv9MD:
		vkLWdeYx3r = {'folder':n0mErNiResZbqGAJBv9MD}
		sHph3rGJzo5bE8LajqVk6 = sCHVtMAvqirbQ4BUK3cgWo
	else:
		vkLWdeYx3r = sCHVtMAvqirbQ4BUK3cgWo
		sHph3rGJzo5bE8LajqVk6 = sCHVtMAvqirbQ4BUK3cgWo
	mRGIy32XYpiLq = l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM)
	if not mRGIy32XYpiLq:
		XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+F7Fe63KbGjaz2TcmCNHPdo5QiXO+' إضافة أو تغيير اشتراك'+sHph3rGJzo5bE8LajqVk6+' '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,231,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+F7Fe63KbGjaz2TcmCNHPdo5QiXO+' جلب ملفات'+sHph3rGJzo5bE8LajqVk6+' '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,232,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	else:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'بحث في الملفات'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,289,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_',sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مصنفة مرتبة'+sHph3rGJzo5bE8LajqVk6,'LIVE_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مصنفة من القسم'+sHph3rGJzo5bE8LajqVk6,'LIVE_FROM_GROUP_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مصنفة من الاسم'+sHph3rGJzo5bE8LajqVk6,'LIVE_FROM_NAME_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مصنفة بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'LIVE_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'LIVE_ORIGINAL_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مجهولة مرتبة'+sHph3rGJzo5bE8LajqVk6,'LIVE_UNKNOWN_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'قنوات مجهولة بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'LIVE_UNKNOWN_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أفلام مصنفة بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'VOD_MOVIES_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أفلام مصنفة مرتبة'+sHph3rGJzo5bE8LajqVk6,'VOD_MOVIES_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'مسلسلات مصنفة بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'VOD_SERIES_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'مسلسلات مصنفة مرتبة'+sHph3rGJzo5bE8LajqVk6,'VOD_SERIES_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فيديوهات بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'VOD_ORIGINAL_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فيديوهات مصنفة من القسم'+sHph3rGJzo5bE8LajqVk6,'VOD_FROM_GROUP_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فيديوهات مصنفة من الاسم'+sHph3rGJzo5bE8LajqVk6,'VOD_FROM_NAME_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فيديوهات مجهولة بلا ترتيب'+sHph3rGJzo5bE8LajqVk6,'VOD_UNKNOWN_GROUPED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فيديوهات مجهولة مرتبة'+sHph3rGJzo5bE8LajqVk6,'VOD_UNKNOWN_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'برامج القنوات (جدول فقط)'+sHph3rGJzo5bE8LajqVk6,'LIVE_EPG_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أرشيف القنوات للأيام الماضية'+sHph3rGJzo5bE8LajqVk6,'LIVE_TIMESHIFT_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أرشيف برامج القنوات للأيام الماضية'+sHph3rGJzo5bE8LajqVk6,'LIVE_ARCHIVED_GROUPED_SORTED',233,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'إضافة أو تغيير اشتراك'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,231,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'جلب ملفات'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,232,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'مسح ملفات'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,237,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'فحص اشتراك'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,236,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'عدد فيديوهات'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,281,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'Referer تغيير'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,286,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'User-Agent تغيير'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,283,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+'استخدم السيرفر الأسرع'+sHph3rGJzo5bE8LajqVk6,sCHVtMAvqirbQ4BUK3cgWo,282,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,vkLWdeYx3r)
	return
def VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM=True):
	NNIFtST43GDbkHiO9nxQeyW1chu,kPqgVeWBXH8o1D3hNmbF5E = False,sCHVtMAvqirbQ4BUK3cgWo
	j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o = yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD)
	if ttdqEI7vlzPcpKHyZjgXN3esmfBkT==sCHVtMAvqirbQ4BUK3cgWo: return False,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	f6cPGkTodE = RusZHdXe94JY86zVCUm(n0mErNiResZbqGAJBv9MD)
	if rGeZ4sV3gt0xNw8aLBi:
		qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',rGeZ4sV3gt0xNw8aLBi,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,False,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-CHECK_ACCOUNT-1st')
		BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
		if qg3X0dy7CDRQmIGvk.succeeded:
			ffW86x5vpF1a,Y4PEuSTGl3fvtnw09,SpM2uJDOZP0,CE5GBV1oNS,rrtif3Oy8Wo = 0,0,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
			try:
				Or8bHzxEWwPBpQ1cJ2Ano9a = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',BJ0mjN2OU8)
				kPqgVeWBXH8o1D3hNmbF5E = Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['status']
				NNIFtST43GDbkHiO9nxQeyW1chu = True
				SpM2uJDOZP0 = Or8bHzxEWwPBpQ1cJ2Ano9a['server_info']['time_now']
			except: pass
			if SpM2uJDOZP0:
				try:
					vWMF0ABO9KTYcLISfGV7n15lg8 = hDjf1Ubgq629nXlOvcFLH4Jw.strptime(SpM2uJDOZP0,'%Y.%m.%d %H:%M:%S')
					ffW86x5vpF1a = int(hDjf1Ubgq629nXlOvcFLH4Jw.mktime(vWMF0ABO9KTYcLISfGV7n15lg8))
					Y4PEuSTGl3fvtnw09 = int(JVAlZw9Nsnj-ffW86x5vpF1a)
					Y4PEuSTGl3fvtnw09 = int((Y4PEuSTGl3fvtnw09+900)/1800)*1800
				except: pass
				try:
					vWMF0ABO9KTYcLISfGV7n15lg8 = hDjf1Ubgq629nXlOvcFLH4Jw.localtime(int(Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['created_at']))
					CE5GBV1oNS = hDjf1Ubgq629nXlOvcFLH4Jw.strftime('%Y.%m.%d %H:%M:%S',vWMF0ABO9KTYcLISfGV7n15lg8)
				except: pass
				try:
					vWMF0ABO9KTYcLISfGV7n15lg8 = hDjf1Ubgq629nXlOvcFLH4Jw.localtime(int(Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['exp_date']))
					rrtif3Oy8Wo = hDjf1Ubgq629nXlOvcFLH4Jw.strftime('%Y.%m.%d %H:%M:%S',vWMF0ABO9KTYcLISfGV7n15lg8)
				except: pass
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.timestamp_'+n0mErNiResZbqGAJBv9MD,str(JVAlZw9Nsnj))
			fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.timediff_'+n0mErNiResZbqGAJBv9MD,str(Y4PEuSTGl3fvtnw09))
			try:
				IS30UKuNAtr = '"server_info":'+BJ0mjN2OU8.split('"server_info":')[1]
				IS30UKuNAtr = IS30UKuNAtr.replace(':',': ').replace(',',', ').replace('}}','}')
				j0Eq17nK4FLvkehXudCo = fNntYJW45mEFSdRX8g.findall('"url": "(.*?)", "port": "(.*?)"',IS30UKuNAtr,fNntYJW45mEFSdRX8g.DOTALL)
				j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = j0Eq17nK4FLvkehXudCo[0]
			except: NNIFtST43GDbkHiO9nxQeyW1chu = False
			if NNIFtST43GDbkHiO9nxQeyW1chu and JOQGgY5w8D93IKM:
				max = Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['max_connections']
				FEXxe87n6QhVrsjakHt0KOCLc4TJ = Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['active_cons']
				xLcSwghvonXJGBiYEjmt = Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['is_trial']
				TTHMsre0DtK9i3BSYlv4 = rGeZ4sV3gt0xNw8aLBi.split('?',1)
				Iqm6XAWBlF = 'URL:  '+VXWOCAE6ns3paJ8DLG479NQfMu+rGeZ4sV3gt0xNw8aLBi+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\n\nStatus:  '+VXWOCAE6ns3paJ8DLG479NQfMu+kPqgVeWBXH8o1D3hNmbF5E+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\nTrial:    '+VXWOCAE6ns3paJ8DLG479NQfMu+str(xLcSwghvonXJGBiYEjmt=='1')+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\nCreated  At:  '+VXWOCAE6ns3paJ8DLG479NQfMu+CE5GBV1oNS+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\nExpiry Date:  '+VXWOCAE6ns3paJ8DLG479NQfMu+rrtif3Oy8Wo+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\nConnections   ( Active / Maximum ) :  '+VXWOCAE6ns3paJ8DLG479NQfMu+FEXxe87n6QhVrsjakHt0KOCLc4TJ+' / '+max+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\nAllowed Outputs:   '+VXWOCAE6ns3paJ8DLG479NQfMu+" , ".join(Or8bHzxEWwPBpQ1cJ2Ano9a['user_info']['allowed_output_formats'])+B8alA5nvIhTxQ
				Iqm6XAWBlF += '\n\n'+IS30UKuNAtr
				if kPqgVeWBXH8o1D3hNmbF5E=='Active': aMy5eXwi3xguBjzEV('الاشتراك يعمل بدون مشاكل',Iqm6XAWBlF)
				else: aMy5eXwi3xguBjzEV('يبدو أن هناك مشكلة في الاشتراك',Iqm6XAWBlF)
	if rGeZ4sV3gt0xNw8aLBi and NNIFtST43GDbkHiO9nxQeyW1chu and kPqgVeWBXH8o1D3hNmbF5E=='Active':
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+rGeZ4sV3gt0xNw8aLBi+' ]')
		mO0jXV8KQFIGyCvSBWkDq2uo5flR = True
	else:
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,'Checking IPTV URL   [ Does not work ]   [ '+rGeZ4sV3gt0xNw8aLBi+' ]')
		if JOQGgY5w8D93IKM: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		mO0jXV8KQFIGyCvSBWkDq2uo5flR = False
	return mO0jXV8KQFIGyCvSBWkDq2uo5flR,j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn
def N9pi3VIH5uR(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV,gk8ScGJHxzypX7sfrt3BhK,gesptH6cYkwRiM28rCqzoPhDN5,JOQGgY5w8D93IKM=True):
	if not gesptH6cYkwRiM28rCqzoPhDN5: gesptH6cYkwRiM28rCqzoPhDN5 = '1'
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM): return
	EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV)
	yUQouZ5rALX0DM1b9Ex2nR6gtO = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list',i6NzAvsXlpDE8atUWOboIV,gk8ScGJHxzypX7sfrt3BhK)
	HHATo0NhxR7mabDcgYBvX = int(gesptH6cYkwRiM28rCqzoPhDN5)*100
	tSXdaJgy24fl = HHATo0NhxR7mabDcgYBvX-100
	for hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in yUQouZ5rALX0DM1b9Ex2nR6gtO[tSXdaJgy24fl:HHATo0NhxR7mabDcgYBvX]:
		IfNx7TAMFG0WpKbvS9jXo1RdLCk = ('GROUPED' in i6NzAvsXlpDE8atUWOboIV or i6NzAvsXlpDE8atUWOboIV=='ALL')
		XlYVW4iqbnx1ztJrd = ('GROUPED' not in i6NzAvsXlpDE8atUWOboIV and i6NzAvsXlpDE8atUWOboIV!='ALL')
		if IfNx7TAMFG0WpKbvS9jXo1RdLCk or XlYVW4iqbnx1ztJrd:
			if   'ARCHIVED'  in i6NzAvsXlpDE8atUWOboIV: Q1siCkTZyw.menuItemsLIST.append(['folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,238,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,'ARCHIVED',sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD}])
			elif 'EPG' 		 in i6NzAvsXlpDE8atUWOboIV: Q1siCkTZyw.menuItemsLIST.append(['folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,238,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,'FULL_EPG',sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD}])
			elif 'TIMESHIFT' in i6NzAvsXlpDE8atUWOboIV: Q1siCkTZyw.menuItemsLIST.append(['folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,238,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,'TIMESHIFT',sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD}])
			elif 'LIVE' 	 in i6NzAvsXlpDE8atUWOboIV: Q1siCkTZyw.menuItemsLIST.append(['live',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,235,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hzwScpHQRnB5Z,{'folder':n0mErNiResZbqGAJBv9MD}])
			else: Q1siCkTZyw.menuItemsLIST.append(['video',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,235,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD}])
	IBVxTKyo7J = len(yUQouZ5rALX0DM1b9Ex2nR6gtO)
	HYPCgInSqDoZyBv3eziWNXpE(n0mErNiResZbqGAJBv9MD,gesptH6cYkwRiM28rCqzoPhDN5,i6NzAvsXlpDE8atUWOboIV,234,IBVxTKyo7J,gk8ScGJHxzypX7sfrt3BhK)
	return
def PjLelYqs7k3a14A69tDNrOQ(DDCPgG0vnmj):
	XAozRfZ68H9x2OsiP3LmIaql1('link',DDCPgG0vnmj+'هذه القائمة إما فارغة أو غير موجودة',sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('link',DDCPgG0vnmj+'أو الخدمة غير موجودة في اشتراكك',sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('link',DDCPgG0vnmj+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',sCHVtMAvqirbQ4BUK3cgWo,9999)
	return
def eyAvQG2hJUaLD9EVzC7t(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV,gk8ScGJHxzypX7sfrt3BhK,gesptH6cYkwRiM28rCqzoPhDN5,J2UiTdymwHqK4C7xV0G=sCHVtMAvqirbQ4BUK3cgWo,JOQGgY5w8D93IKM=True):
	if not gesptH6cYkwRiM28rCqzoPhDN5: gesptH6cYkwRiM28rCqzoPhDN5 = '1'
	DDCPgG0vnmj = Y6xCT1m2lpbnKLJPZ5R8hSqO
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM): return False
	if '__SERIES__' in gk8ScGJHxzypX7sfrt3BhK: EEMTnly4DW0vApjC5bhiPNG,xe8StvTpBioykhjr6MaGHuAb = gk8ScGJHxzypX7sfrt3BhK.split('__SERIES__')
	else: EEMTnly4DW0vApjC5bhiPNG,xe8StvTpBioykhjr6MaGHuAb = gk8ScGJHxzypX7sfrt3BhK,sCHVtMAvqirbQ4BUK3cgWo
	EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV)
	s92Wtq50xmwD8oYQdeLbpzyfcEMCI = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list',i6NzAvsXlpDE8atUWOboIV,'__GROUPS__')
	if not s92Wtq50xmwD8oYQdeLbpzyfcEMCI: return False
	qXx2herdFyC4ZocWR0fk1mJzEsVp = []
	for mktodBPJD9yqsc,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in s92Wtq50xmwD8oYQdeLbpzyfcEMCI:
		if J2UiTdymwHqK4C7xV0G:
			if '__SERIES__' in mktodBPJD9yqsc: DDCPgG0vnmj = 'SERIES'
			elif '!!__UNKNOWN__!!' in mktodBPJD9yqsc: DDCPgG0vnmj = 'UNKNOWN'
			elif 'LIVE' in i6NzAvsXlpDE8atUWOboIV: DDCPgG0vnmj = 'LIVE'
			else: DDCPgG0vnmj = 'VIDEOS'
			DDCPgG0vnmj = ','+VXWOCAE6ns3paJ8DLG479NQfMu+DDCPgG0vnmj+': '+B8alA5nvIhTxQ
		if '__SERIES__' in mktodBPJD9yqsc: yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,e1a3qvSMmby = mktodBPJD9yqsc.split('__SERIES__')
		else: yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,e1a3qvSMmby = mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo
		if not gk8ScGJHxzypX7sfrt3BhK:
			if yyj1RWNpdCqGbYQLeBsDKxU3kaH7M in qXx2herdFyC4ZocWR0fk1mJzEsVp: continue
			qXx2herdFyC4ZocWR0fk1mJzEsVp.append(yyj1RWNpdCqGbYQLeBsDKxU3kaH7M)
			if 'RANDOM' in J2UiTdymwHqK4C7xV0G: XAozRfZ68H9x2OsiP3LmIaql1('folder',DDCPgG0vnmj+yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,i6NzAvsXlpDE8atUWOboIV,167,sCHVtMAvqirbQ4BUK3cgWo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
			elif '__SERIES__' in mktodBPJD9yqsc: XAozRfZ68H9x2OsiP3LmIaql1('folder',DDCPgG0vnmj+yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,i6NzAvsXlpDE8atUWOboIV,233,sCHVtMAvqirbQ4BUK3cgWo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',DDCPgG0vnmj+yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,i6NzAvsXlpDE8atUWOboIV,234,sCHVtMAvqirbQ4BUK3cgWo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
		elif '__SERIES__' in mktodBPJD9yqsc and yyj1RWNpdCqGbYQLeBsDKxU3kaH7M==EEMTnly4DW0vApjC5bhiPNG:
			if e1a3qvSMmby in qXx2herdFyC4ZocWR0fk1mJzEsVp: continue
			qXx2herdFyC4ZocWR0fk1mJzEsVp.append(e1a3qvSMmby)
			if 'RANDOM' in J2UiTdymwHqK4C7xV0G: XAozRfZ68H9x2OsiP3LmIaql1('folder',DDCPgG0vnmj+e1a3qvSMmby,i6NzAvsXlpDE8atUWOboIV,167,sCHVtMAvqirbQ4BUK3cgWo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',DDCPgG0vnmj+e1a3qvSMmby,i6NzAvsXlpDE8atUWOboIV,234,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	Q1siCkTZyw.menuItemsLIST[:] = sorted(Q1siCkTZyw.menuItemsLIST,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju[1].lower())
	if not J2UiTdymwHqK4C7xV0G:
		HHATo0NhxR7mabDcgYBvX = int(gesptH6cYkwRiM28rCqzoPhDN5)*100
		tSXdaJgy24fl = HHATo0NhxR7mabDcgYBvX-100
		IBVxTKyo7J = len(Q1siCkTZyw.menuItemsLIST)
		Q1siCkTZyw.menuItemsLIST[:] = Q1siCkTZyw.menuItemsLIST[tSXdaJgy24fl:HHATo0NhxR7mabDcgYBvX]
		HYPCgInSqDoZyBv3eziWNXpE(n0mErNiResZbqGAJBv9MD,gesptH6cYkwRiM28rCqzoPhDN5,i6NzAvsXlpDE8atUWOboIV,233,IBVxTKyo7J,gk8ScGJHxzypX7sfrt3BhK)
	return True
def WFPIro0iEtVHwyqlT6QSzCsLBx9XY(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,hhuJlBDf7PimqkWcCwHUX):
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,True): return
	f6cPGkTodE = RusZHdXe94JY86zVCUm(n0mErNiResZbqGAJBv9MD)
	ffW86x5vpF1a = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.timestamp_'+n0mErNiResZbqGAJBv9MD)
	if not ffW86x5vpF1a or JVAlZw9Nsnj-int(ffW86x5vpF1a)>24*YYAdZjDy5erLEOa3Vh02Ux:
		mO0jXV8KQFIGyCvSBWkDq2uo5flR,j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,False)
		if not mO0jXV8KQFIGyCvSBWkDq2uo5flR: return
	Y4PEuSTGl3fvtnw09 = int(fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.timediff_'+n0mErNiResZbqGAJBv9MD))
	jVJZueBdXFra2v0L = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.server_'+n0mErNiResZbqGAJBv9MD)
	ttdqEI7vlzPcpKHyZjgXN3esmfBkT = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.username_'+n0mErNiResZbqGAJBv9MD)
	OC1aqTJt2EyZALVx4o = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.password_'+n0mErNiResZbqGAJBv9MD)
	AYbLHrxo0XejF = qhWpTazQ9ws.split('/')
	k8kZ7RpXgohev5uTSKnOxy = AYbLHrxo0XejF[-1].replace('.ts',sCHVtMAvqirbQ4BUK3cgWo).replace('.m3u8',sCHVtMAvqirbQ4BUK3cgWo)
	if hhuJlBDf7PimqkWcCwHUX=='SHORT_EPG': hQ7fOmgMaln2VeE = 'get_short_epg'
	else: hQ7fOmgMaln2VeE = 'get_simple_data_table'
	rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o = yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD)
	if not ttdqEI7vlzPcpKHyZjgXN3esmfBkT: return
	OE2iIuYLRD8WpQxTmlwNVfyjrhFZ = rGeZ4sV3gt0xNw8aLBi+'&action='+hQ7fOmgMaln2VeE+'&stream_id='+k8kZ7RpXgohev5uTSKnOxy
	BJ0mjN2OU8 = zzTutjFVIi(UTCXGnK7Fs4Y5pNkt2ARDWuw,OE2iIuYLRD8WpQxTmlwNVfyjrhFZ,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-EPG_ITEMS-2nd')
	fjrJMzvsAchS7XeQt1RlEL = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',BJ0mjN2OU8)
	SfBMms7CUZzxv6li8Ryc3p5bIrg = fjrJMzvsAchS7XeQt1RlEL['epg_listings']
	XfdNJpjgFRDS52owacZ = []
	if hhuJlBDf7PimqkWcCwHUX in ['ARCHIVED','TIMESHIFT']:
		for Or8bHzxEWwPBpQ1cJ2Ano9a in SfBMms7CUZzxv6li8Ryc3p5bIrg:
			if Or8bHzxEWwPBpQ1cJ2Ano9a['has_archive']==1:
				XfdNJpjgFRDS52owacZ.append(Or8bHzxEWwPBpQ1cJ2Ano9a)
				if hhuJlBDf7PimqkWcCwHUX in ['TIMESHIFT']: break
		if not XfdNJpjgFRDS52owacZ: return
		XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+VXWOCAE6ns3paJ8DLG479NQfMu+'الملفات الأولي بهذه القائمة قد لا تعمل'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		if hhuJlBDf7PimqkWcCwHUX in ['TIMESHIFT']:
			newkjEsZRLMypFQvtlu3TDSxfc = 2
			vC2gYLDSWpIwz4GEu = newkjEsZRLMypFQvtlu3TDSxfc*YYAdZjDy5erLEOa3Vh02Ux
			XfdNJpjgFRDS52owacZ = []
			s8ioRT4FvE1cHJkdWXpQDZxGmYr9 = int(int(Or8bHzxEWwPBpQ1cJ2Ano9a['start_timestamp'])/vC2gYLDSWpIwz4GEu)*vC2gYLDSWpIwz4GEu
			BB7KSbHTrzYXIAZlMjJ2hE = JVAlZw9Nsnj+vC2gYLDSWpIwz4GEu
			IIjtDlvBMynQsZ4T0Vu58xFhrkm = int((BB7KSbHTrzYXIAZlMjJ2hE-s8ioRT4FvE1cHJkdWXpQDZxGmYr9)/YYAdZjDy5erLEOa3Vh02Ux)
			for l1ybzmhn4Pt5qKTrY in range(IIjtDlvBMynQsZ4T0Vu58xFhrkm):
				if l1ybzmhn4Pt5qKTrY>=6:
					if l1ybzmhn4Pt5qKTrY%newkjEsZRLMypFQvtlu3TDSxfc!=0: continue
					OjyQrecApZ8 = vC2gYLDSWpIwz4GEu
				else: OjyQrecApZ8 = vC2gYLDSWpIwz4GEu//2
				BBoR4W6vIHYrSe7wx5Vqm1XpCbu = s8ioRT4FvE1cHJkdWXpQDZxGmYr9+l1ybzmhn4Pt5qKTrY*YYAdZjDy5erLEOa3Vh02Ux
				Or8bHzxEWwPBpQ1cJ2Ano9a = {}
				Or8bHzxEWwPBpQ1cJ2Ano9a['title'] = sCHVtMAvqirbQ4BUK3cgWo
				vWMF0ABO9KTYcLISfGV7n15lg8 = hDjf1Ubgq629nXlOvcFLH4Jw.localtime(BBoR4W6vIHYrSe7wx5Vqm1XpCbu-Y4PEuSTGl3fvtnw09-YYAdZjDy5erLEOa3Vh02Ux)
				Or8bHzxEWwPBpQ1cJ2Ano9a['start'] = hDjf1Ubgq629nXlOvcFLH4Jw.strftime('%Y.%m.%d %H:%M:%S',vWMF0ABO9KTYcLISfGV7n15lg8)
				Or8bHzxEWwPBpQ1cJ2Ano9a['start_timestamp'] = str(BBoR4W6vIHYrSe7wx5Vqm1XpCbu)
				Or8bHzxEWwPBpQ1cJ2Ano9a['stop_timestamp'] = str(BBoR4W6vIHYrSe7wx5Vqm1XpCbu+OjyQrecApZ8)
				XfdNJpjgFRDS52owacZ.append(Or8bHzxEWwPBpQ1cJ2Ano9a)
	elif hhuJlBDf7PimqkWcCwHUX in ['SHORT_EPG','FULL_EPG']: XfdNJpjgFRDS52owacZ = SfBMms7CUZzxv6li8Ryc3p5bIrg
	if hhuJlBDf7PimqkWcCwHUX=='FULL_EPG' and len(XfdNJpjgFRDS52owacZ)>0:
		XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+VXWOCAE6ns3paJ8DLG479NQfMu+'هذه قائمة برامج القنوات (جدول فقط)ـ'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	eCYkO0bJhQH3F8IpBGS = []
	Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Icon')
	for Or8bHzxEWwPBpQ1cJ2Ano9a in XfdNJpjgFRDS52owacZ:
		F29iVTaoCEjXBMvfuxytelrn = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(Or8bHzxEWwPBpQ1cJ2Ano9a['title'])
		if I5VKjrFL0Bk97: F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		BBoR4W6vIHYrSe7wx5Vqm1XpCbu = int(Or8bHzxEWwPBpQ1cJ2Ano9a['start_timestamp'])
		b0F5PWXBGLCzcqMrEwegUaRy6tV = int(Or8bHzxEWwPBpQ1cJ2Ano9a['stop_timestamp'])
		M6J17exUWI42CfrZL5KE0tnHac = str(int((b0F5PWXBGLCzcqMrEwegUaRy6tV-BBoR4W6vIHYrSe7wx5Vqm1XpCbu+59)/60))
		yUvSLqfD0mk8tdhWIZjlpz = Or8bHzxEWwPBpQ1cJ2Ano9a['start'].replace(AAh0X3OCacr4HpifRGLZKT,':')
		vWMF0ABO9KTYcLISfGV7n15lg8 = hDjf1Ubgq629nXlOvcFLH4Jw.localtime(BBoR4W6vIHYrSe7wx5Vqm1XpCbu-YYAdZjDy5erLEOa3Vh02Ux)
		QYL9dKovabnNgWCrSfAy1c = hDjf1Ubgq629nXlOvcFLH4Jw.strftime('%H:%M',vWMF0ABO9KTYcLISfGV7n15lg8)
		theyTzC9vEMDigFnL20XpmAd7Yljr = hDjf1Ubgq629nXlOvcFLH4Jw.strftime('%a',vWMF0ABO9KTYcLISfGV7n15lg8)
		if hhuJlBDf7PimqkWcCwHUX=='SHORT_EPG': F29iVTaoCEjXBMvfuxytelrn = F7Fe63KbGjaz2TcmCNHPdo5QiXO+QYL9dKovabnNgWCrSfAy1c+' ـ '+F29iVTaoCEjXBMvfuxytelrn+B8alA5nvIhTxQ
		elif hhuJlBDf7PimqkWcCwHUX=='TIMESHIFT': F29iVTaoCEjXBMvfuxytelrn = theyTzC9vEMDigFnL20XpmAd7Yljr+AAh0X3OCacr4HpifRGLZKT+QYL9dKovabnNgWCrSfAy1c+' ('+M6J17exUWI42CfrZL5KE0tnHac+'min)'
		else: F29iVTaoCEjXBMvfuxytelrn = theyTzC9vEMDigFnL20XpmAd7Yljr+AAh0X3OCacr4HpifRGLZKT+QYL9dKovabnNgWCrSfAy1c+' ('+M6J17exUWI42CfrZL5KE0tnHac+'min)   '+F29iVTaoCEjXBMvfuxytelrn+' ـ'
		if hhuJlBDf7PimqkWcCwHUX in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			KRcwaBJFVnTN = jVJZueBdXFra2v0L+'/timeshift/'+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+'/'+OC1aqTJt2EyZALVx4o+'/'+M6J17exUWI42CfrZL5KE0tnHac+'/'+yUvSLqfD0mk8tdhWIZjlpz+'/'+k8kZ7RpXgohev5uTSKnOxy+'.m3u8'
			if hhuJlBDf7PimqkWcCwHUX=='FULL_EPG': XAozRfZ68H9x2OsiP3LmIaql1('link',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,KRcwaBJFVnTN,9999,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,KRcwaBJFVnTN,235,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
		eCYkO0bJhQH3F8IpBGS.append(F29iVTaoCEjXBMvfuxytelrn)
	if hhuJlBDf7PimqkWcCwHUX=='SHORT_EPG' and eCYkO0bJhQH3F8IpBGS: ZxtSnXd37gOiwmjUWV6ksI90Nc5 = jEu4OHoLUhPNk(eCYkO0bJhQH3F8IpBGS)
	return eCYkO0bJhQH3F8IpBGS
def xxwJBgtV95On7DWHNGzfIThUYb(n0mErNiResZbqGAJBv9MD):
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,True): return
	jVJZueBdXFra2v0L,CCfbZeBsUvTozFEJQ,UXvTG0Iyi5R2jkcH = sCHVtMAvqirbQ4BUK3cgWo,0,0
	mO0jXV8KQFIGyCvSBWkDq2uo5flR,j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,False)
	if mO0jXV8KQFIGyCvSBWkDq2uo5flR:
		jiTxrXQWn1wCagcfyAv2SphZM = I0DJU1BnhLfH4QP5cb(j96QRnpZhX5EbNYuor)
		CCfbZeBsUvTozFEJQ = dk5CWBPUzZ8vpuRNFjmQIysAc9hKeM(jiTxrXQWn1wCagcfyAv2SphZM[0],int(DiRoY1vCVHjphJlb5kwFZGn))
		EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,'LIVE_GROUPED')
		JfXr5qciYokQHtdWnL3sBZMvuSb2DA = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list','LIVE_GROUPED')
		yUQouZ5rALX0DM1b9Ex2nR6gtO = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list','LIVE_GROUPED',JfXr5qciYokQHtdWnL3sBZMvuSb2DA[1])
		qhWpTazQ9ws = yUQouZ5rALX0DM1b9Ex2nR6gtO[0][2]
		w2J1jYpGcnodTiruqQEDgAb = fNntYJW45mEFSdRX8g.findall('://(.*?)/',qhWpTazQ9ws,fNntYJW45mEFSdRX8g.DOTALL)
		w2J1jYpGcnodTiruqQEDgAb = w2J1jYpGcnodTiruqQEDgAb[0]
		if ':' in w2J1jYpGcnodTiruqQEDgAb: Quy5HKNvj4m396JiaAOZXghlSLnM,H3ESJWu9ap08xdYR5Kr1 = w2J1jYpGcnodTiruqQEDgAb.split(':')
		else: Quy5HKNvj4m396JiaAOZXghlSLnM,H3ESJWu9ap08xdYR5Kr1 = w2J1jYpGcnodTiruqQEDgAb,'80'
		hjsaVYI7TFqXuz = I0DJU1BnhLfH4QP5cb(Quy5HKNvj4m396JiaAOZXghlSLnM)
		UXvTG0Iyi5R2jkcH = dk5CWBPUzZ8vpuRNFjmQIysAc9hKeM(hjsaVYI7TFqXuz[0],int(H3ESJWu9ap08xdYR5Kr1))
	if CCfbZeBsUvTozFEJQ and UXvTG0Iyi5R2jkcH:
		Iqm6XAWBlF = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		Iqm6XAWBlF += '\n\n'+'وقت ضائع في السيرفر الأصلي'+slFfrUIWCowaBA7tce3iZbj8xn+str(int(UXvTG0Iyi5R2jkcH*1000))+' ملي ثانية'
		Iqm6XAWBlF += '\n\n'+'وقت ضائع في السيرفر البديل'+slFfrUIWCowaBA7tce3iZbj8xn+str(int(CCfbZeBsUvTozFEJQ*1000))+' ملي ثانية'
		PemgFp6AyMXlb = NVjFvLmZCYRu1S893eTf6dUbqJl('center','السيرفر الأصلي','السيرفر الأسرع',OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
		if PemgFp6AyMXlb==1 and CCfbZeBsUvTozFEJQ<UXvTG0Iyi5R2jkcH: jVJZueBdXFra2v0L = j96QRnpZhX5EbNYuor+':'+DiRoY1vCVHjphJlb5kwFZGn
	else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'البرنامج لم يجد السيرفر البديل')
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.server_'+n0mErNiResZbqGAJBv9MD,jVJZueBdXFra2v0L)
	return
def YH54mqkD2eU06(n0mErNiResZbqGAJBv9MD,qhWpTazQ9ws,iHPTUWrX1nbg):
	fqKOthNIQVH467gJ8xdnm = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD)
	n4o9NFv1SGslZjfCu3wY = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.referer_'+n0mErNiResZbqGAJBv9MD)
	if fqKOthNIQVH467gJ8xdnm or n4o9NFv1SGslZjfCu3wY:
		qhWpTazQ9ws += '|'
		if fqKOthNIQVH467gJ8xdnm: qhWpTazQ9ws += '&User-Agent='+fqKOthNIQVH467gJ8xdnm
		if n4o9NFv1SGslZjfCu3wY: qhWpTazQ9ws += '&Referer='+n4o9NFv1SGslZjfCu3wY
		qhWpTazQ9ws = qhWpTazQ9ws.replace('|&','|')
	o75WlftZK6wV49HNidEgAPBc = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.server_'+n0mErNiResZbqGAJBv9MD)
	if o75WlftZK6wV49HNidEgAPBc:
		ipgvlWRx8Km0Y6JyjIQA = fNntYJW45mEFSdRX8g.findall('://(.*?)/',qhWpTazQ9ws,fNntYJW45mEFSdRX8g.DOTALL)
		qhWpTazQ9ws = qhWpTazQ9ws.replace(ipgvlWRx8Km0Y6JyjIQA[0],o75WlftZK6wV49HNidEgAPBc)
	CeXLtzElr5DHhs(qhWpTazQ9ws,qsActmwjBGK4Ia1OFihlnCz,iHPTUWrX1nbg)
	return
def yypMYPghQAUxsvc1t(n0mErNiResZbqGAJBv9MD):
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	fqKOthNIQVH467gJ8xdnm = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD)
	aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center','استخدام الأصلي','تعديل القديم',fqKOthNIQVH467gJ8xdnm,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if aAlySQF0LTW7VoR6Ztqw4eIEzbM==1: fqKOthNIQVH467gJ8xdnm = UyBdvjGrFxDWMpmLOXn('أكتب ـIPTV User-Agent جديد',fqKOthNIQVH467gJ8xdnm,True)
	else: fqKOthNIQVH467gJ8xdnm = 'Unknown'
	if fqKOthNIQVH467gJ8xdnm==AAh0X3OCacr4HpifRGLZKT:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fqKOthNIQVH467gJ8xdnm,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if aAlySQF0LTW7VoR6Ztqw4eIEzbM!=1:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم الإلغاء')
		return
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD,fqKOthNIQVH467gJ8xdnm)
	Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD)
	return
def F2FxcPKzsrIt3YZoCVn8WD0eNb9L(n0mErNiResZbqGAJBv9MD):
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	n4o9NFv1SGslZjfCu3wY = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.referer_'+n0mErNiResZbqGAJBv9MD)
	aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center','استخدام الأصلي','تعديل القديم',n4o9NFv1SGslZjfCu3wY,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if aAlySQF0LTW7VoR6Ztqw4eIEzbM==1: n4o9NFv1SGslZjfCu3wY = UyBdvjGrFxDWMpmLOXn('أكتب ـIPTV Referer جديد',n4o9NFv1SGslZjfCu3wY,True)
	else: n4o9NFv1SGslZjfCu3wY = sCHVtMAvqirbQ4BUK3cgWo
	if n4o9NFv1SGslZjfCu3wY==AAh0X3OCacr4HpifRGLZKT:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,n4o9NFv1SGslZjfCu3wY,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if aAlySQF0LTW7VoR6Ztqw4eIEzbM!=1:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم الإلغاء')
		return
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.referer_'+n0mErNiResZbqGAJBv9MD,n4o9NFv1SGslZjfCu3wY)
	Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD)
	return
def yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD,zWJrKMOk0GtvwFb3619SUjEe7x=sCHVtMAvqirbQ4BUK3cgWo):
	if not zWJrKMOk0GtvwFb3619SUjEe7x: zWJrKMOk0GtvwFb3619SUjEe7x = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.url_'+n0mErNiResZbqGAJBv9MD)
	jVJZueBdXFra2v0L = GABnmSFOwtsu37(zWJrKMOk0GtvwFb3619SUjEe7x,'url')
	ttdqEI7vlzPcpKHyZjgXN3esmfBkT = fNntYJW45mEFSdRX8g.findall('username=(.*?)&',zWJrKMOk0GtvwFb3619SUjEe7x+'&',fNntYJW45mEFSdRX8g.DOTALL)
	OC1aqTJt2EyZALVx4o = fNntYJW45mEFSdRX8g.findall('password=(.*?)&',zWJrKMOk0GtvwFb3619SUjEe7x+'&',fNntYJW45mEFSdRX8g.DOTALL)
	if not ttdqEI7vlzPcpKHyZjgXN3esmfBkT or not OC1aqTJt2EyZALVx4o:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	ttdqEI7vlzPcpKHyZjgXN3esmfBkT = ttdqEI7vlzPcpKHyZjgXN3esmfBkT[0]
	OC1aqTJt2EyZALVx4o = OC1aqTJt2EyZALVx4o[0]
	rGeZ4sV3gt0xNw8aLBi = jVJZueBdXFra2v0L+'/player_api.php?username='+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+'&password='+OC1aqTJt2EyZALVx4o
	wbYt4mZ8zRnP6HuyD5CW7EdBp03 = jVJZueBdXFra2v0L+'/get.php?username='+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+'&password='+OC1aqTJt2EyZALVx4o+'&type=m3u_plus'
	return rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o
def WNuk3RdAqg2h8Gp0xrBDC1Ui(n0mErNiResZbqGAJBv9MD,guGJjivFdHenxs3=sCHVtMAvqirbQ4BUK3cgWo):
	iz264eWFKwOutYAlTpdM3NfyR5EqP = guGJjivFdHenxs3.replace('/','_').replace(':','_').replace('.','_')
	iz264eWFKwOutYAlTpdM3NfyR5EqP = iz264eWFKwOutYAlTpdM3NfyR5EqP.replace('?','_').replace('=','_').replace('&','_')
	iz264eWFKwOutYAlTpdM3NfyR5EqP = YYEXZsUWhf52vz7HLxc0qGJ.path.join(XX4rMRSnQdbZ1NJiKu8pOfvDla,iz264eWFKwOutYAlTpdM3NfyR5EqP).strip('.m3u')+'.m3u'
	return iz264eWFKwOutYAlTpdM3NfyR5EqP
def DDB7wFaNcizxyU48vh(n0mErNiResZbqGAJBv9MD):
	OwPJzuATWeB9iKrVksnQ0c6R = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.url_'+n0mErNiResZbqGAJBv9MD)
	FNUPhRp3EZVMHykIa2x4tfD9S = True
	if OwPJzuATWeB9iKrVksnQ0c6R:
		aAlySQF0LTW7VoR6Ztqw4eIEzbM = bP5mf0Mo2nz('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',VXWOCAE6ns3paJ8DLG479NQfMu+OwPJzuATWeB9iKrVksnQ0c6R+B8alA5nvIhTxQ+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if aAlySQF0LTW7VoR6Ztqw4eIEzbM==-1: return
		elif aAlySQF0LTW7VoR6Ztqw4eIEzbM==0: OwPJzuATWeB9iKrVksnQ0c6R = sCHVtMAvqirbQ4BUK3cgWo
		elif aAlySQF0LTW7VoR6Ztqw4eIEzbM==2:
			aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if aAlySQF0LTW7VoR6Ztqw4eIEzbM in [-1,0]: return
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم مسح الرابط')
			FNUPhRp3EZVMHykIa2x4tfD9S = False
			EoO3RmAzCXQaJ1tsF4c6lMY = sCHVtMAvqirbQ4BUK3cgWo
	if FNUPhRp3EZVMHykIa2x4tfD9S:
		EoO3RmAzCXQaJ1tsF4c6lMY = UyBdvjGrFxDWMpmLOXn('اكتب رابط ـIPTV كاملا',OwPJzuATWeB9iKrVksnQ0c6R)
		EoO3RmAzCXQaJ1tsF4c6lMY = EoO3RmAzCXQaJ1tsF4c6lMY.strip(AAh0X3OCacr4HpifRGLZKT)
		if not EoO3RmAzCXQaJ1tsF4c6lMY:
			aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if aAlySQF0LTW7VoR6Ztqw4eIEzbM in [-1,0]: return
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم مسح الرابط')
	else:
		rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o = yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD,EoO3RmAzCXQaJ1tsF4c6lMY)
		if not ttdqEI7vlzPcpKHyZjgXN3esmfBkT: return
		Iqm6XAWBlF = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+jVJZueBdXFra2v0L+B8alA5nvIhTxQ+'عنوان السيرفر: '
		Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+B8alA5nvIhTxQ+'اسم المستخدم: '
		Iqm6XAWBlF += slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+fkZNsEaolApyXY7++'كلمة السر: '
		aAlySQF0LTW7VoR6Ztqw4eIEzbM = NVjFvLmZCYRu1S893eTf6dUbqJl('right',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'الرابط الجديد هو:',VXWOCAE6ns3paJ8DLG479NQfMu+EoO3RmAzCXQaJ1tsF4c6lMY+B8alA5nvIhTxQ+'\n\n'+Iqm6XAWBlF)
		if aAlySQF0LTW7VoR6Ztqw4eIEzbM!=1:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم الإلغاء')
			return
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.url_'+n0mErNiResZbqGAJBv9MD,EoO3RmAzCXQaJ1tsF4c6lMY)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.timestamp_'+n0mErNiResZbqGAJBv9MD,sCHVtMAvqirbQ4BUK3cgWo)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.timediff_'+n0mErNiResZbqGAJBv9MD,sCHVtMAvqirbQ4BUK3cgWo)
	fqKOthNIQVH467gJ8xdnm = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD)
	if not fqKOthNIQVH467gJ8xdnm: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD,'Unknown')
	NPEilWIJnk4wsAx = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EoO3RmAzCXQaJ1tsF4c6lMY+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if NPEilWIJnk4wsAx==1: mO0jXV8KQFIGyCvSBWkDq2uo5flR,j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,True)
	Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD)
	return
def bTMR0umOhPtVZpJy(PCS2siEhbL,l0lJA4Ci3ogvIRs,Ut4lwL8mGHir1S,cjZt7uG9zqM6YTLFdigShex2mWP0Cw,dxGQUo7NmTRhBXkOEs,k4k13tbwsvEyH6,wbYt4mZ8zRnP6HuyD5CW7EdBp03):
	yUQouZ5rALX0DM1b9Ex2nR6gtO,djC9wc2ATM3Kn = [],[]
	gCiTMLVnhk9ubIWpX65ftsxaPe = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		if k4k13tbwsvEyH6%473==0:
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,40+int(10*k4k13tbwsvEyH6/dxGQUo7NmTRhBXkOEs),'قراءة الفيديوهات','الفيديو رقم:-',str(k4k13tbwsvEyH6)+' / '+str(dxGQUo7NmTRhBXkOEs))
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return None,None,None
		qhWpTazQ9ws = fNntYJW45mEFSdRX8g.findall('^(.*?)\n+((http|https|rtmp).*?)$',QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,fNntYJW45mEFSdRX8g.DOTALL)
		if qhWpTazQ9ws:
			QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,qhWpTazQ9ws,FFvbXzryi3TRG5wEM6t9SD = qhWpTazQ9ws[0]
			qhWpTazQ9ws = qhWpTazQ9ws.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
			QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
		else:
			djC9wc2ATM3Kn.append({'line':QXeuCy5v3cK4qEVBLzPabFUlAfGN0m})
			continue
		oFm4Hphs8xGiMQDT,hzwScpHQRnB5Z,mktodBPJD9yqsc,F29iVTaoCEjXBMvfuxytelrn,iHPTUWrX1nbg,g6sNJGRlahpDo7kF4wPHAYBXSjmT = {},sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,False
		try:
			QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,F29iVTaoCEjXBMvfuxytelrn = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.rsplit('",',1)
			QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m+'"'
		except:
			try: QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,F29iVTaoCEjXBMvfuxytelrn = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.rsplit('1,',1)
			except: F29iVTaoCEjXBMvfuxytelrn = sCHVtMAvqirbQ4BUK3cgWo
		oFm4Hphs8xGiMQDT['url'] = qhWpTazQ9ws
		NLAQlmwOTz2KhJ5psb = fNntYJW45mEFSdRX8g.findall(' (.*?)="(.*?)"',QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,fNntYJW45mEFSdRX8g.DOTALL)
		for FCYq34IhByUnfKRi1GS5pmD6Vzd7ju,VVIdbMLzmrBwlR72u in NLAQlmwOTz2KhJ5psb:
			FCYq34IhByUnfKRi1GS5pmD6Vzd7ju = FCYq34IhByUnfKRi1GS5pmD6Vzd7ju.replace('"',sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			oFm4Hphs8xGiMQDT[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju] = VVIdbMLzmrBwlR72u.strip(AAh0X3OCacr4HpifRGLZKT)
		Pklx6F2JMfnDqWus3V8IzHCU = list(oFm4Hphs8xGiMQDT.keys())
		if not F29iVTaoCEjXBMvfuxytelrn:
			if 'name' in Pklx6F2JMfnDqWus3V8IzHCU and oFm4Hphs8xGiMQDT['name']: F29iVTaoCEjXBMvfuxytelrn = oFm4Hphs8xGiMQDT['name']
		oFm4Hphs8xGiMQDT['title'] = F29iVTaoCEjXBMvfuxytelrn.strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		if 'logo' in Pklx6F2JMfnDqWus3V8IzHCU:
			oFm4Hphs8xGiMQDT['img'] = oFm4Hphs8xGiMQDT['logo']
			del oFm4Hphs8xGiMQDT['logo']
		else: oFm4Hphs8xGiMQDT['img'] = sCHVtMAvqirbQ4BUK3cgWo
		if 'group' in Pklx6F2JMfnDqWus3V8IzHCU and oFm4Hphs8xGiMQDT['group']: mktodBPJD9yqsc = oFm4Hphs8xGiMQDT['group']
		if any(value in qhWpTazQ9ws.lower() for value in gCiTMLVnhk9ubIWpX65ftsxaPe):
			g6sNJGRlahpDo7kF4wPHAYBXSjmT = True if 'm3u' not in qhWpTazQ9ws else False
		if g6sNJGRlahpDo7kF4wPHAYBXSjmT or '__SERIES__' in mktodBPJD9yqsc or '__MOVIES__' in mktodBPJD9yqsc:
			iHPTUWrX1nbg = 'VOD'
			if '__SERIES__' in mktodBPJD9yqsc: iHPTUWrX1nbg = iHPTUWrX1nbg+'_SERIES'
			elif '__MOVIES__' in mktodBPJD9yqsc: iHPTUWrX1nbg = iHPTUWrX1nbg+'_MOVIES'
			else: iHPTUWrX1nbg = iHPTUWrX1nbg+'_UNKNOWN'
			mktodBPJD9yqsc = mktodBPJD9yqsc.replace('__SERIES__',sCHVtMAvqirbQ4BUK3cgWo).replace('__MOVIES__',sCHVtMAvqirbQ4BUK3cgWo)
		else:
			iHPTUWrX1nbg = 'LIVE'
			if F29iVTaoCEjXBMvfuxytelrn in l0lJA4Ci3ogvIRs: hzwScpHQRnB5Z = hzwScpHQRnB5Z+'_EPG'
			if F29iVTaoCEjXBMvfuxytelrn in Ut4lwL8mGHir1S: hzwScpHQRnB5Z = hzwScpHQRnB5Z+'_ARCHIVED'
			if not mktodBPJD9yqsc: iHPTUWrX1nbg = iHPTUWrX1nbg+'_UNKNOWN'
			else: iHPTUWrX1nbg = iHPTUWrX1nbg+hzwScpHQRnB5Z
		mktodBPJD9yqsc = mktodBPJD9yqsc.strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		if 'LIVE_UNKNOWN' in iHPTUWrX1nbg: mktodBPJD9yqsc = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in iHPTUWrX1nbg: mktodBPJD9yqsc = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in iHPTUWrX1nbg:
			R5qlWVKmfDy3EhZJFaojk1wxOQberg = fNntYJW45mEFSdRX8g.findall('(.*?) [Ss]\d+ +[Ee]\d+',oFm4Hphs8xGiMQDT['title'],fNntYJW45mEFSdRX8g.DOTALL)
			if R5qlWVKmfDy3EhZJFaojk1wxOQberg: R5qlWVKmfDy3EhZJFaojk1wxOQberg = R5qlWVKmfDy3EhZJFaojk1wxOQberg[0]
			else: R5qlWVKmfDy3EhZJFaojk1wxOQberg = '!!__UNKNOWN_SERIES__!!'
			mktodBPJD9yqsc = mktodBPJD9yqsc+'__SERIES__'+R5qlWVKmfDy3EhZJFaojk1wxOQberg
		if 'id' in Pklx6F2JMfnDqWus3V8IzHCU: del oFm4Hphs8xGiMQDT['id']
		if 'ID' in Pklx6F2JMfnDqWus3V8IzHCU: del oFm4Hphs8xGiMQDT['ID']
		if 'name' in Pklx6F2JMfnDqWus3V8IzHCU: del oFm4Hphs8xGiMQDT['name']
		F29iVTaoCEjXBMvfuxytelrn = oFm4Hphs8xGiMQDT['title']
		F29iVTaoCEjXBMvfuxytelrn = EEH4kBfGY0FuZUjeNn(F29iVTaoCEjXBMvfuxytelrn)
		F29iVTaoCEjXBMvfuxytelrn = MUO7CmBl80JIXbY(F29iVTaoCEjXBMvfuxytelrn)
		BnkzAOjfRJ,mktodBPJD9yqsc = H9gcGeSnlD(mktodBPJD9yqsc)
		Vmv2xTMJsCO,F29iVTaoCEjXBMvfuxytelrn = H9gcGeSnlD(F29iVTaoCEjXBMvfuxytelrn)
		oFm4Hphs8xGiMQDT['type'] = iHPTUWrX1nbg
		oFm4Hphs8xGiMQDT['context'] = hzwScpHQRnB5Z
		oFm4Hphs8xGiMQDT['group'] = mktodBPJD9yqsc.upper()
		oFm4Hphs8xGiMQDT['title'] = F29iVTaoCEjXBMvfuxytelrn.upper()
		oFm4Hphs8xGiMQDT['country'] = Vmv2xTMJsCO.upper()
		oFm4Hphs8xGiMQDT['language'] = BnkzAOjfRJ.upper()
		yUQouZ5rALX0DM1b9Ex2nR6gtO.append(oFm4Hphs8xGiMQDT)
		k4k13tbwsvEyH6 += 1
	return yUQouZ5rALX0DM1b9Ex2nR6gtO,k4k13tbwsvEyH6,djC9wc2ATM3Kn
def MUO7CmBl80JIXbY(F29iVTaoCEjXBMvfuxytelrn):
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.replace('||','|').replace('___',':').replace('--','-')
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.replace('[[','[').replace(']]',']')
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.replace('((','(').replace('))',')')
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.replace('<<','<').replace('>>','>')
	F29iVTaoCEjXBMvfuxytelrn = F29iVTaoCEjXBMvfuxytelrn.strip(AAh0X3OCacr4HpifRGLZKT)
	return F29iVTaoCEjXBMvfuxytelrn
def dMB4WVx89z0o(WGEk0sn3gqNAfjYC6v,cjZt7uG9zqM6YTLFdigShex2mWP0Cw):
	o3ozHicZwpSYJEUk9nVQxIR = {}
	for kcw0uEQAlF74YDqtO25MxLNmo3KIn in BBervUf81CI: o3ozHicZwpSYJEUk9nVQxIR[kcw0uEQAlF74YDqtO25MxLNmo3KIn] = []
	dxGQUo7NmTRhBXkOEs = len(WGEk0sn3gqNAfjYC6v)
	JsQUfTpcreCOLGMX4z3t56aA = str(dxGQUo7NmTRhBXkOEs)
	k4k13tbwsvEyH6 = 0
	djC9wc2ATM3Kn = []
	for oFm4Hphs8xGiMQDT in WGEk0sn3gqNAfjYC6v:
		if k4k13tbwsvEyH6%873==0:
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,50+int(5*k4k13tbwsvEyH6/dxGQUo7NmTRhBXkOEs),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(k4k13tbwsvEyH6)+' / '+JsQUfTpcreCOLGMX4z3t56aA)
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return None,None
		mktodBPJD9yqsc,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo = oFm4Hphs8xGiMQDT['group'],oFm4Hphs8xGiMQDT['context'],oFm4Hphs8xGiMQDT['title'],oFm4Hphs8xGiMQDT['url'],oFm4Hphs8xGiMQDT['img']
		Vmv2xTMJsCO,BnkzAOjfRJ,kcw0uEQAlF74YDqtO25MxLNmo3KIn = oFm4Hphs8xGiMQDT['country'],oFm4Hphs8xGiMQDT['language'],oFm4Hphs8xGiMQDT['type']
		wrzbqTk4gVhm = (mktodBPJD9yqsc,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo)
		mRDvL65rfelaBVbYuAkQG1 = False
		if 'LIVE' in kcw0uEQAlF74YDqtO25MxLNmo3KIn:
			if 'UNKNOWN' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_UNKNOWN_GROUPED'].append(wrzbqTk4gVhm)
			elif 'LIVE' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_GROUPED'].append(wrzbqTk4gVhm)
			else: mRDvL65rfelaBVbYuAkQG1 = True
			o3ozHicZwpSYJEUk9nVQxIR['LIVE_ORIGINAL_GROUPED'].append(wrzbqTk4gVhm)
		elif 'VOD' in kcw0uEQAlF74YDqtO25MxLNmo3KIn:
			if 'UNKNOWN' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_UNKNOWN_GROUPED'].append(wrzbqTk4gVhm)
			elif 'MOVIES' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_MOVIES_GROUPED'].append(wrzbqTk4gVhm)
			elif 'SERIES' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_SERIES_GROUPED'].append(wrzbqTk4gVhm)
			else: mRDvL65rfelaBVbYuAkQG1 = True
			o3ozHicZwpSYJEUk9nVQxIR['VOD_ORIGINAL_GROUPED'].append(wrzbqTk4gVhm)
		else: mRDvL65rfelaBVbYuAkQG1 = True
		if mRDvL65rfelaBVbYuAkQG1: djC9wc2ATM3Kn.append(oFm4Hphs8xGiMQDT)
		k4k13tbwsvEyH6 += 1
	ejhi32FTgQpfRwCvy = sorted(WGEk0sn3gqNAfjYC6v,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju['title'].lower())
	del WGEk0sn3gqNAfjYC6v
	JsQUfTpcreCOLGMX4z3t56aA = str(dxGQUo7NmTRhBXkOEs)
	k4k13tbwsvEyH6 = 0
	for oFm4Hphs8xGiMQDT in ejhi32FTgQpfRwCvy:
		k4k13tbwsvEyH6 += 1
		if k4k13tbwsvEyH6%873==0:
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,55+int(5*k4k13tbwsvEyH6/dxGQUo7NmTRhBXkOEs),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(k4k13tbwsvEyH6)+' / '+JsQUfTpcreCOLGMX4z3t56aA)
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return None,None
		kcw0uEQAlF74YDqtO25MxLNmo3KIn = oFm4Hphs8xGiMQDT['type']
		mktodBPJD9yqsc,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo = oFm4Hphs8xGiMQDT['group'],oFm4Hphs8xGiMQDT['context'],oFm4Hphs8xGiMQDT['title'],oFm4Hphs8xGiMQDT['url'],oFm4Hphs8xGiMQDT['img']
		Vmv2xTMJsCO,BnkzAOjfRJ = oFm4Hphs8xGiMQDT['country'],oFm4Hphs8xGiMQDT['language']
		f3WaDgJ0ic1qkKBUEGtV = (mktodBPJD9yqsc,hzwScpHQRnB5Z+'_TIMESHIFT',F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo)
		wrzbqTk4gVhm = (mktodBPJD9yqsc,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo)
		GhijvEyXUHdNItPOp9g48aJbq = (Vmv2xTMJsCO,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo)
		zAdiqHyne5 = (BnkzAOjfRJ,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo)
		if 'LIVE' in kcw0uEQAlF74YDqtO25MxLNmo3KIn:
			if 'UNKNOWN' in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_UNKNOWN_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			else: o3ozHicZwpSYJEUk9nVQxIR['LIVE_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			if 'EPG'		in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_EPG_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			if 'ARCHIVED'	in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_ARCHIVED_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			if 'ARCHIVED'	in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['LIVE_TIMESHIFT_GROUPED_SORTED'].append(f3WaDgJ0ic1qkKBUEGtV)
			o3ozHicZwpSYJEUk9nVQxIR['LIVE_FROM_NAME_SORTED'].append(GhijvEyXUHdNItPOp9g48aJbq)
			o3ozHicZwpSYJEUk9nVQxIR['LIVE_FROM_GROUP_SORTED'].append(zAdiqHyne5)
		elif 'VOD' in kcw0uEQAlF74YDqtO25MxLNmo3KIn:
			if   'UNKNOWN'	in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_UNKNOWN_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			elif 'MOVIES'	in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_MOVIES_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			elif 'SERIES'	in kcw0uEQAlF74YDqtO25MxLNmo3KIn: o3ozHicZwpSYJEUk9nVQxIR['VOD_SERIES_GROUPED_SORTED'].append(wrzbqTk4gVhm)
			o3ozHicZwpSYJEUk9nVQxIR['VOD_FROM_NAME_SORTED'].append(GhijvEyXUHdNItPOp9g48aJbq)
			o3ozHicZwpSYJEUk9nVQxIR['VOD_FROM_GROUP_SORTED'].append(zAdiqHyne5)
	return o3ozHicZwpSYJEUk9nVQxIR,djC9wc2ATM3Kn
def H9gcGeSnlD(F29iVTaoCEjXBMvfuxytelrn):
	if len(F29iVTaoCEjXBMvfuxytelrn)<3: return F29iVTaoCEjXBMvfuxytelrn,F29iVTaoCEjXBMvfuxytelrn
	X7Z9vq0wd2nFmopl4U18kS6ix,ddMEpG390goYF = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	uUHD4jaO01gcTSInqYFNCkXR36s2VB = F29iVTaoCEjXBMvfuxytelrn
	XlkB5ZhjObQxKgnv0HeL72ouw = F29iVTaoCEjXBMvfuxytelrn[:1]
	k2kKunEcXQrxASf = F29iVTaoCEjXBMvfuxytelrn[1:]
	if   XlkB5ZhjObQxKgnv0HeL72ouw=='(': ddMEpG390goYF = ')'
	elif XlkB5ZhjObQxKgnv0HeL72ouw=='[': ddMEpG390goYF = ']'
	elif XlkB5ZhjObQxKgnv0HeL72ouw=='<': ddMEpG390goYF = '>'
	elif XlkB5ZhjObQxKgnv0HeL72ouw=='|': ddMEpG390goYF = '|'
	if ddMEpG390goYF and (ddMEpG390goYF in k2kKunEcXQrxASf):
		T5TZrCnOqxtcs,lxpm1KOd5fBo4REWL = k2kKunEcXQrxASf.split(ddMEpG390goYF,1)
		X7Z9vq0wd2nFmopl4U18kS6ix = T5TZrCnOqxtcs
		uUHD4jaO01gcTSInqYFNCkXR36s2VB = XlkB5ZhjObQxKgnv0HeL72ouw+T5TZrCnOqxtcs+ddMEpG390goYF+AAh0X3OCacr4HpifRGLZKT+lxpm1KOd5fBo4REWL
	elif F29iVTaoCEjXBMvfuxytelrn.count('|')>=2:
		T5TZrCnOqxtcs,lxpm1KOd5fBo4REWL = F29iVTaoCEjXBMvfuxytelrn.split('|',1)
		X7Z9vq0wd2nFmopl4U18kS6ix = T5TZrCnOqxtcs
		uUHD4jaO01gcTSInqYFNCkXR36s2VB = T5TZrCnOqxtcs+' |'+lxpm1KOd5fBo4REWL
	else:
		ddMEpG390goYF = fNntYJW45mEFSdRX8g.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',F29iVTaoCEjXBMvfuxytelrn,fNntYJW45mEFSdRX8g.DOTALL)
		if not ddMEpG390goYF: ddMEpG390goYF = fNntYJW45mEFSdRX8g.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',F29iVTaoCEjXBMvfuxytelrn,fNntYJW45mEFSdRX8g.DOTALL)
		if not ddMEpG390goYF: ddMEpG390goYF = fNntYJW45mEFSdRX8g.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',F29iVTaoCEjXBMvfuxytelrn,fNntYJW45mEFSdRX8g.DOTALL)
		if ddMEpG390goYF:
			T5TZrCnOqxtcs,lxpm1KOd5fBo4REWL = F29iVTaoCEjXBMvfuxytelrn.split(ddMEpG390goYF[0],1)
			X7Z9vq0wd2nFmopl4U18kS6ix = T5TZrCnOqxtcs
			uUHD4jaO01gcTSInqYFNCkXR36s2VB = T5TZrCnOqxtcs+AAh0X3OCacr4HpifRGLZKT+ddMEpG390goYF[0]+AAh0X3OCacr4HpifRGLZKT+lxpm1KOd5fBo4REWL
	uUHD4jaO01gcTSInqYFNCkXR36s2VB = uUHD4jaO01gcTSInqYFNCkXR36s2VB.replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	X7Z9vq0wd2nFmopl4U18kS6ix = X7Z9vq0wd2nFmopl4U18kS6ix.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	if not X7Z9vq0wd2nFmopl4U18kS6ix: X7Z9vq0wd2nFmopl4U18kS6ix = '!!__UNKNOWN__!!'
	X7Z9vq0wd2nFmopl4U18kS6ix = X7Z9vq0wd2nFmopl4U18kS6ix.strip(AAh0X3OCacr4HpifRGLZKT)
	uUHD4jaO01gcTSInqYFNCkXR36s2VB = uUHD4jaO01gcTSInqYFNCkXR36s2VB.strip(AAh0X3OCacr4HpifRGLZKT)
	return X7Z9vq0wd2nFmopl4U18kS6ix,uUHD4jaO01gcTSInqYFNCkXR36s2VB
def RusZHdXe94JY86zVCUm(n0mErNiResZbqGAJBv9MD):
	f6cPGkTodE = {}
	fqKOthNIQVH467gJ8xdnm = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.useragent_'+n0mErNiResZbqGAJBv9MD)
	if fqKOthNIQVH467gJ8xdnm: f6cPGkTodE['User-Agent'] = fqKOthNIQVH467gJ8xdnm
	n4o9NFv1SGslZjfCu3wY = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.iptv.referer_'+n0mErNiResZbqGAJBv9MD)
	if n4o9NFv1SGslZjfCu3wY: f6cPGkTodE['Referer'] = n4o9NFv1SGslZjfCu3wY
	return f6cPGkTodE
def AgWpUkH7avPIDQlTd(n0mErNiResZbqGAJBv9MD):
	global cjZt7uG9zqM6YTLFdigShex2mWP0Cw,o3ozHicZwpSYJEUk9nVQxIR,yaDQRpOuiINGlw0Vt5,jSsBgMOVmLv9bHF8EZc1qX3PWz,g9fO6kNvuiRzorLKcm0,JfXr5qciYokQHtdWnL3sBZMvuSb2DA,KRhXgJHjeAZ9W,NjZOtAHv0JDSldTLCz,JKXQaflLwx5p2yWq6TG
	rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o = yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD)
	if not ttdqEI7vlzPcpKHyZjgXN3esmfBkT: return
	f6cPGkTodE = RusZHdXe94JY86zVCUm(n0mErNiResZbqGAJBv9MD)
	PemgFp6AyMXlb = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if PemgFp6AyMXlb!=1: return
	iz264eWFKwOutYAlTpdM3NfyR5EqP = nVBSuE26QPC9dy.replace('___','_'+n0mErNiResZbqGAJBv9MD)
	if 1:
		mO0jXV8KQFIGyCvSBWkDq2uo5flR,j96QRnpZhX5EbNYuor,DiRoY1vCVHjphJlb5kwFZGn = VVh1NdpvHBzKqbIEym39kAW(n0mErNiResZbqGAJBv9MD,False)
		if not mO0jXV8KQFIGyCvSBWkDq2uo5flR:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not wbYt4mZ8zRnP6HuyD5CW7EdBp03: SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(qsActmwjBGK4Ia1OFihlnCz)+'   No IPTV URL found to download IPTV files')
			else: SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(qsActmwjBGK4Ia1OFihlnCz)+'   Failed to download IPTV files')
			return
		bbRo7fu6PV = RDrfnwmMg8EblLCXFzBV0O6(wbYt4mZ8zRnP6HuyD5CW7EdBp03,f6cPGkTodE,True)
		if not bbRo7fu6PV: return
		open(iz264eWFKwOutYAlTpdM3NfyR5EqP,'wb').write(bbRo7fu6PV)
	else: bbRo7fu6PV = open(iz264eWFKwOutYAlTpdM3NfyR5EqP,'rb').read()
	if I5VKjrFL0Bk97 and bbRo7fu6PV: bbRo7fu6PV = bbRo7fu6PV.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	cjZt7uG9zqM6YTLFdigShex2mWP0Cw = xSIYZduC9imekB7c0J6oOa82FVnNU()
	cjZt7uG9zqM6YTLFdigShex2mWP0Cw.create('جلب ملفات ـIPTV جديدة',sCHVtMAvqirbQ4BUK3cgWo)
	TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,15,'تنظيف الملف الرئيسي',sCHVtMAvqirbQ4BUK3cgWo)
	bbRo7fu6PV = bbRo7fu6PV.replace('"tvg-','" tvg-')
	bbRo7fu6PV = bbRo7fu6PV.replace('َ',sCHVtMAvqirbQ4BUK3cgWo).replace('ً',sCHVtMAvqirbQ4BUK3cgWo).replace('ُ',sCHVtMAvqirbQ4BUK3cgWo).replace('ٌ',sCHVtMAvqirbQ4BUK3cgWo)
	bbRo7fu6PV = bbRo7fu6PV.replace('ّ',sCHVtMAvqirbQ4BUK3cgWo).replace('ِ',sCHVtMAvqirbQ4BUK3cgWo).replace('ٍ',sCHVtMAvqirbQ4BUK3cgWo).replace('ْ',sCHVtMAvqirbQ4BUK3cgWo)
	bbRo7fu6PV = bbRo7fu6PV.replace('group-title=','group=').replace('tvg-',sCHVtMAvqirbQ4BUK3cgWo)
	Ut4lwL8mGHir1S,l0lJA4Ci3ogvIRs = [],[]
	TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
		cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
		return
	qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_series_categories'
	qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',qhWpTazQ9ws,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-CREATE_STREAMS-1st')
	BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
	BJ0mjN2OU8 = EEH4kBfGY0FuZUjeNn(BJ0mjN2OU8)
	tLyFBZrWC8MOD2Qq7sVvcjEm60lfR = fNntYJW45mEFSdRX8g.findall('category_name":"(.*?)"',BJ0mjN2OU8,fNntYJW45mEFSdRX8g.DOTALL)
	del BJ0mjN2OU8
	for mktodBPJD9yqsc in tLyFBZrWC8MOD2Qq7sVvcjEm60lfR:
		mktodBPJD9yqsc = mktodBPJD9yqsc.replace('\/','/')
		if qdUK5ioJyrO1T: mktodBPJD9yqsc = mktodBPJD9yqsc.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		bbRo7fu6PV = bbRo7fu6PV.replace('group="'+mktodBPJD9yqsc+'"','group="__SERIES__'+mktodBPJD9yqsc+'"')
	del tLyFBZrWC8MOD2Qq7sVvcjEm60lfR
	TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
		cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
		return
	qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_vod_categories'
	qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',qhWpTazQ9ws,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-CREATE_STREAMS-2nd')
	BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
	BJ0mjN2OU8 = EEH4kBfGY0FuZUjeNn(BJ0mjN2OU8)
	ncS3d7U6ZDWPM8G = fNntYJW45mEFSdRX8g.findall('category_name":"(.*?)"',BJ0mjN2OU8,fNntYJW45mEFSdRX8g.DOTALL)
	del BJ0mjN2OU8
	for mktodBPJD9yqsc in ncS3d7U6ZDWPM8G:
		mktodBPJD9yqsc = mktodBPJD9yqsc.replace('\/','/')
		if qdUK5ioJyrO1T: mktodBPJD9yqsc = mktodBPJD9yqsc.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		bbRo7fu6PV = bbRo7fu6PV.replace('group="'+mktodBPJD9yqsc+'"','group="__MOVIES__'+mktodBPJD9yqsc+'"')
	del ncS3d7U6ZDWPM8G
	TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
		cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
		return
	qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_live_streams'
	qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',qhWpTazQ9ws,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-CREATE_STREAMS-3rd')
	BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
	BJ0mjN2OU8 = EEH4kBfGY0FuZUjeNn(BJ0mjN2OU8)
	REuvT0lNVBAqk1cMKWagUbGJft = fNntYJW45mEFSdRX8g.findall('"name":"(.*?)".*?"tv_archive":(.*?),',BJ0mjN2OU8,fNntYJW45mEFSdRX8g.DOTALL)
	for hoVitY5TylJ7GBEIZNOQg8pukq,ndNat0kYIgs6Mz9X32 in REuvT0lNVBAqk1cMKWagUbGJft:
		if ndNat0kYIgs6Mz9X32=='1': Ut4lwL8mGHir1S.append(hoVitY5TylJ7GBEIZNOQg8pukq)
	del REuvT0lNVBAqk1cMKWagUbGJft
	Fly1VpdBREWnsCxA = fNntYJW45mEFSdRX8g.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',BJ0mjN2OU8,fNntYJW45mEFSdRX8g.DOTALL)
	del BJ0mjN2OU8
	for hoVitY5TylJ7GBEIZNOQg8pukq,PPmI0yBl8UoVcCuX in Fly1VpdBREWnsCxA:
		if PPmI0yBl8UoVcCuX!='null': l0lJA4Ci3ogvIRs.append(hoVitY5TylJ7GBEIZNOQg8pukq)
	del Fly1VpdBREWnsCxA
	bbRo7fu6PV = bbRo7fu6PV.replace(f6fsIXQonhvcGg1p,slFfrUIWCowaBA7tce3iZbj8xn)
	PCS2siEhbL = fNntYJW45mEFSdRX8g.findall('NF:(.+?)'+'#'+'EXTI',bbRo7fu6PV+'\n+'+'#'+'EXTINF:',fNntYJW45mEFSdRX8g.DOTALL)
	if not PCS2siEhbL:
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(qsActmwjBGK4Ia1OFihlnCz)+'   Folder:'+n0mErNiResZbqGAJBv9MD+'   No video links found in IPTV file')
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+slFfrUIWCowaBA7tce3iZbj8xn+F7Fe63KbGjaz2TcmCNHPdo5QiXO+'مجلد رقم '+n0mErNiResZbqGAJBv9MD)
		cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
		return
	SMH9E1eokOZIv7PWBl = []
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		sTJc21iSDbQP3WNCtvglKy = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.lower()
		if 'adult' in sTJc21iSDbQP3WNCtvglKy: continue
		if 'xxx' in sTJc21iSDbQP3WNCtvglKy: continue
		SMH9E1eokOZIv7PWBl.append(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m)
	PCS2siEhbL = SMH9E1eokOZIv7PWBl
	del SMH9E1eokOZIv7PWBl
	acHwI36Bsby7fkXrvJ = 1024*1024
	vNwEjKIP1z = 1+len(bbRo7fu6PV)//acHwI36Bsby7fkXrvJ//10
	del bbRo7fu6PV
	EEd0qeiJr7VRwyGD25faBznkKcF = len(PCS2siEhbL)
	jJvBVak9cEzZw = cnPoQy2IgjJH5ewYpkZ6B(PCS2siEhbL,vNwEjKIP1z)
	del PCS2siEhbL
	for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(vNwEjKIP1z):
		TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,35+int(5*qT1ZRz0VMiXQhxFUPdJC2u9asvrN/vNwEjKIP1z),'تقطيع الملف الرئيسي','الجزء رقم:-',str(qT1ZRz0VMiXQhxFUPdJC2u9asvrN+1)+' / '+str(vNwEjKIP1z))
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
		HgiBCrhuWNoO97KEvDwj6Fsb2nPVl = str(jJvBVak9cEzZw[qT1ZRz0VMiXQhxFUPdJC2u9asvrN])
		if I5VKjrFL0Bk97: HgiBCrhuWNoO97KEvDwj6Fsb2nPVl = HgiBCrhuWNoO97KEvDwj6Fsb2nPVl.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open(iz264eWFKwOutYAlTpdM3NfyR5EqP+'.00'+str(qT1ZRz0VMiXQhxFUPdJC2u9asvrN),'wb').write(HgiBCrhuWNoO97KEvDwj6Fsb2nPVl)
	del jJvBVak9cEzZw,HgiBCrhuWNoO97KEvDwj6Fsb2nPVl
	oTkSavHU6wZV,WGEk0sn3gqNAfjYC6v,k4k13tbwsvEyH6 = [],[],0
	for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(vNwEjKIP1z):
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
		HgiBCrhuWNoO97KEvDwj6Fsb2nPVl = open(iz264eWFKwOutYAlTpdM3NfyR5EqP+'.00'+str(qT1ZRz0VMiXQhxFUPdJC2u9asvrN),'rb').read()
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(1)
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(iz264eWFKwOutYAlTpdM3NfyR5EqP+'.00'+str(qT1ZRz0VMiXQhxFUPdJC2u9asvrN))
		except: pass
		if I5VKjrFL0Bk97: HgiBCrhuWNoO97KEvDwj6Fsb2nPVl = HgiBCrhuWNoO97KEvDwj6Fsb2nPVl.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		z4sGrm1h6k5VTPto = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('list',HgiBCrhuWNoO97KEvDwj6Fsb2nPVl)
		del HgiBCrhuWNoO97KEvDwj6Fsb2nPVl
		yUQouZ5rALX0DM1b9Ex2nR6gtO,k4k13tbwsvEyH6,djC9wc2ATM3Kn = bTMR0umOhPtVZpJy(z4sGrm1h6k5VTPto,l0lJA4Ci3ogvIRs,Ut4lwL8mGHir1S,cjZt7uG9zqM6YTLFdigShex2mWP0Cw,EEd0qeiJr7VRwyGD25faBznkKcF,k4k13tbwsvEyH6,wbYt4mZ8zRnP6HuyD5CW7EdBp03)
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
		if not yUQouZ5rALX0DM1b9Ex2nR6gtO:
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
		WGEk0sn3gqNAfjYC6v += yUQouZ5rALX0DM1b9Ex2nR6gtO
		oTkSavHU6wZV += djC9wc2ATM3Kn
	del z4sGrm1h6k5VTPto,yUQouZ5rALX0DM1b9Ex2nR6gtO
	o3ozHicZwpSYJEUk9nVQxIR,djC9wc2ATM3Kn = dMB4WVx89z0o(WGEk0sn3gqNAfjYC6v,cjZt7uG9zqM6YTLFdigShex2mWP0Cw)
	if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
		cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
		return
	oTkSavHU6wZV += djC9wc2ATM3Kn
	del WGEk0sn3gqNAfjYC6v,djC9wc2ATM3Kn
	jSsBgMOVmLv9bHF8EZc1qX3PWz,g9fO6kNvuiRzorLKcm0,JfXr5qciYokQHtdWnL3sBZMvuSb2DA,KRhXgJHjeAZ9W,NjZOtAHv0JDSldTLCz = {},{},{},0,0
	nnolY3d8HW = list(o3ozHicZwpSYJEUk9nVQxIR.keys())
	JKXQaflLwx5p2yWq6TG = len(nnolY3d8HW)*3
	if 1:
		v0DZzfGCA8T1mycBb5l = {}
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV] = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=i5dQYAEqu86azy0s,args=(i6NzAvsXlpDE8atUWOboIV,))
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV].start()
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV].join()
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
	else:
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			i5dQYAEqu86azy0s(i6NzAvsXlpDE8atUWOboIV)
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return
	HLQ1ZNlJWDdIixM(n0mErNiResZbqGAJBv9MD,False)
	nnolY3d8HW = list(jSsBgMOVmLv9bHF8EZc1qX3PWz.keys())
	yaDQRpOuiINGlw0Vt5 = 0
	if 1:
		v0DZzfGCA8T1mycBb5l = {}
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV] = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=dWFMzURYkfsVNDKjmBrqeT82cAEJ1,args=(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV))
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV].start()
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			v0DZzfGCA8T1mycBb5l[i6NzAvsXlpDE8atUWOboIV].join()
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
			cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
			return
	else:
		for i6NzAvsXlpDE8atUWOboIV in nnolY3d8HW:
			dWFMzURYkfsVNDKjmBrqeT82cAEJ1(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV)
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return
	qT1ZRz0VMiXQhxFUPdJC2u9asvrN = 0
	syGWjxq8nrKhEM5 = len(oTkSavHU6wZV)
	EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,'IGNORED')
	for XxVnOjqhE7Mdl2 in oTkSavHU6wZV:
		if qT1ZRz0VMiXQhxFUPdJC2u9asvrN%27==0:
			TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,95+int(5*qT1ZRz0VMiXQhxFUPdJC2u9asvrN//syGWjxq8nrKhEM5),'تخزين المهملة','الفيديو رقم:-',str(qT1ZRz0VMiXQhxFUPdJC2u9asvrN)+' / '+str(syGWjxq8nrKhEM5))
			if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled():
				cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
				return
		kPQB6UJMiVGmHoT9w8(EM3RApNQLyuDgO4X,'IGNORED',str(XxVnOjqhE7Mdl2),sCHVtMAvqirbQ4BUK3cgWo,IfAkw39UvaYWEDXLthFrbSzG)
		qT1ZRz0VMiXQhxFUPdJC2u9asvrN += 1
	kPQB6UJMiVGmHoT9w8(EM3RApNQLyuDgO4X,'IGNORED','__COUNT__',str(syGWjxq8nrKhEM5),IfAkw39UvaYWEDXLthFrbSzG)
	kPQB6UJMiVGmHoT9w8(EM3RApNQLyuDgO4X,'DUMMY','__DUMMY__','1',IfAkw39UvaYWEDXLthFrbSzG)
	cjZt7uG9zqM6YTLFdigShex2mWP0Cw.close()
	hDjf1Ubgq629nXlOvcFLH4Jw.sleep(1)
	ttbwKUOHZg = uHTIzYAhjJ3qm9MDeW0BRbgZtK(n0mErNiResZbqGAJBv9MD,False)
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,F7Fe63KbGjaz2TcmCNHPdo5QiXO+'تم جلب ملفات ـIPTV جديدة'+B8alA5nvIhTxQ+'\n\n'+ttbwKUOHZg)
	Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD)
	Hy2bntGarc7J(False)
	Ims96cLXkvKOx0GD(False)
	return
def i5dQYAEqu86azy0s(i6NzAvsXlpDE8atUWOboIV):
	global cjZt7uG9zqM6YTLFdigShex2mWP0Cw,o3ozHicZwpSYJEUk9nVQxIR,yaDQRpOuiINGlw0Vt5,jSsBgMOVmLv9bHF8EZc1qX3PWz,g9fO6kNvuiRzorLKcm0,JfXr5qciYokQHtdWnL3sBZMvuSb2DA,KRhXgJHjeAZ9W,NjZOtAHv0JDSldTLCz,JKXQaflLwx5p2yWq6TG
	jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV] = {}
	pt8ZcLkxTu7vAbWPz0nE4Bh5l,C6Dy0XswSExIpf7YVkU1Q = {},[]
	AWcDfRMVCN6yTil8IoLp = len(o3ozHicZwpSYJEUk9nVQxIR[i6NzAvsXlpDE8atUWOboIV])
	jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV]['__COUNT__'] = AWcDfRMVCN6yTil8IoLp
	if AWcDfRMVCN6yTil8IoLp>0:
		WGOXD4bx0lReMZ,r4qpuFGV8D5wvgI,zWqbUVt6l2nCLyI3wk1Qi8KM,D8vWVjHlLUdYmy,R6RXwecj45DMtr8GauodIS7Y = zip(*o3ozHicZwpSYJEUk9nVQxIR[i6NzAvsXlpDE8atUWOboIV])
		del r4qpuFGV8D5wvgI,zWqbUVt6l2nCLyI3wk1Qi8KM,D8vWVjHlLUdYmy
		K8KLdbWEXQmfp9OUD3Ps = list(set(WGOXD4bx0lReMZ))
		for mktodBPJD9yqsc in K8KLdbWEXQmfp9OUD3Ps:
			pt8ZcLkxTu7vAbWPz0nE4Bh5l[mktodBPJD9yqsc] = sCHVtMAvqirbQ4BUK3cgWo
			jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV][mktodBPJD9yqsc] = []
		TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,60+int(15*NjZOtAHv0JDSldTLCz//JKXQaflLwx5p2yWq6TG),'تصنيع القوائم','الجزء رقم:-',str(NjZOtAHv0JDSldTLCz)+' / '+str(JKXQaflLwx5p2yWq6TG))
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled(): return
		NjZOtAHv0JDSldTLCz += 1
		OfiXm97ypAT = len(K8KLdbWEXQmfp9OUD3Ps)
		del K8KLdbWEXQmfp9OUD3Ps
		C6Dy0XswSExIpf7YVkU1Q = list(set(zip(WGOXD4bx0lReMZ,R6RXwecj45DMtr8GauodIS7Y)))
		del WGOXD4bx0lReMZ,R6RXwecj45DMtr8GauodIS7Y
		for mktodBPJD9yqsc,yNbi4akQM9EHO8wSlCGoJZx in C6Dy0XswSExIpf7YVkU1Q:
			if not pt8ZcLkxTu7vAbWPz0nE4Bh5l[mktodBPJD9yqsc] and yNbi4akQM9EHO8wSlCGoJZx: pt8ZcLkxTu7vAbWPz0nE4Bh5l[mktodBPJD9yqsc] = yNbi4akQM9EHO8wSlCGoJZx
		TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,60+int(15*NjZOtAHv0JDSldTLCz//JKXQaflLwx5p2yWq6TG),'تصنيع القوائم','الجزء رقم:-',str(NjZOtAHv0JDSldTLCz)+' / '+str(JKXQaflLwx5p2yWq6TG))
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled(): return
		NjZOtAHv0JDSldTLCz += 1
		xn7Uy2mSF9Lophqe = list(pt8ZcLkxTu7vAbWPz0nE4Bh5l.keys())
		tzyvqFoRXl = list(pt8ZcLkxTu7vAbWPz0nE4Bh5l.values())
		del pt8ZcLkxTu7vAbWPz0nE4Bh5l
		C6Dy0XswSExIpf7YVkU1Q = list(zip(xn7Uy2mSF9Lophqe,tzyvqFoRXl))
		del xn7Uy2mSF9Lophqe,tzyvqFoRXl
		C6Dy0XswSExIpf7YVkU1Q = sorted(C6Dy0XswSExIpf7YVkU1Q)
	else: NjZOtAHv0JDSldTLCz += 2
	jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV]['__GROUPS__'] = C6Dy0XswSExIpf7YVkU1Q
	del C6Dy0XswSExIpf7YVkU1Q
	for mktodBPJD9yqsc,hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in o3ozHicZwpSYJEUk9nVQxIR[i6NzAvsXlpDE8atUWOboIV]:
		jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV][mktodBPJD9yqsc].append((hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo))
	TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,60+int(15*NjZOtAHv0JDSldTLCz//JKXQaflLwx5p2yWq6TG),'تصنيع القوائم','الجزء رقم:-',str(NjZOtAHv0JDSldTLCz)+' / '+str(JKXQaflLwx5p2yWq6TG))
	if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled(): return
	NjZOtAHv0JDSldTLCz += 1
	del o3ozHicZwpSYJEUk9nVQxIR[i6NzAvsXlpDE8atUWOboIV]
	JfXr5qciYokQHtdWnL3sBZMvuSb2DA[i6NzAvsXlpDE8atUWOboIV] = list(jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV].keys())
	g9fO6kNvuiRzorLKcm0[i6NzAvsXlpDE8atUWOboIV] = len(JfXr5qciYokQHtdWnL3sBZMvuSb2DA[i6NzAvsXlpDE8atUWOboIV])
	KRhXgJHjeAZ9W += g9fO6kNvuiRzorLKcm0[i6NzAvsXlpDE8atUWOboIV]
	return
def dWFMzURYkfsVNDKjmBrqeT82cAEJ1(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV):
	global cjZt7uG9zqM6YTLFdigShex2mWP0Cw,o3ozHicZwpSYJEUk9nVQxIR,yaDQRpOuiINGlw0Vt5,jSsBgMOVmLv9bHF8EZc1qX3PWz,g9fO6kNvuiRzorLKcm0,JfXr5qciYokQHtdWnL3sBZMvuSb2DA,KRhXgJHjeAZ9W,NjZOtAHv0JDSldTLCz,JKXQaflLwx5p2yWq6TG
	EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV)
	for k4k13tbwsvEyH6 in range(1+g9fO6kNvuiRzorLKcm0[i6NzAvsXlpDE8atUWOboIV]//273):
		EZkqJtmoyhx = []
		xDabPQBwMektW2JT = JfXr5qciYokQHtdWnL3sBZMvuSb2DA[i6NzAvsXlpDE8atUWOboIV][0:273]
		for mktodBPJD9yqsc in xDabPQBwMektW2JT:
			EZkqJtmoyhx.append(jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV][mktodBPJD9yqsc])
		kPQB6UJMiVGmHoT9w8(EM3RApNQLyuDgO4X,i6NzAvsXlpDE8atUWOboIV,xDabPQBwMektW2JT,EZkqJtmoyhx,IfAkw39UvaYWEDXLthFrbSzG,True)
		yaDQRpOuiINGlw0Vt5 += len(xDabPQBwMektW2JT)
		TM0y8CGwSR9ANHLEdXI4uqmeJt5(cjZt7uG9zqM6YTLFdigShex2mWP0Cw,75+int(20*yaDQRpOuiINGlw0Vt5//KRhXgJHjeAZ9W),'تخزين القوائم','القائمة رقم:-',str(yaDQRpOuiINGlw0Vt5)+' / '+str(KRhXgJHjeAZ9W))
		if cjZt7uG9zqM6YTLFdigShex2mWP0Cw.iscanceled(): return
		del JfXr5qciYokQHtdWnL3sBZMvuSb2DA[i6NzAvsXlpDE8atUWOboIV][0:273]
	del jSsBgMOVmLv9bHF8EZc1qX3PWz[i6NzAvsXlpDE8atUWOboIV],JfXr5qciYokQHtdWnL3sBZMvuSb2DA[i6NzAvsXlpDE8atUWOboIV],g9fO6kNvuiRzorLKcm0[i6NzAvsXlpDE8atUWOboIV]
	return
def uHTIzYAhjJ3qm9MDeW0BRbgZtK(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM=True):
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM): return
	gJ5HToD4b0fsQ3im = OODdgcrlh8KQo0A7M2eEvViwPqpkR
	xAuNED94mrQWv = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,'LIVE_ORIGINAL_GROUPED')
	imduHcLnGAlDypzrUPoCIagwV3BQq = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,'VOD_ORIGINAL_GROUPED')
	syGWjxq8nrKhEM5 = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','IGNORED','__COUNT__')
	CqZKFg9ei82Yfs0zdVLBGcJWn5 = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	roYkUcalTZW6nX7eAiqR3FwNJx5h1p = JKCrO8x7ZyIfwVgSvX(imduHcLnGAlDypzrUPoCIagwV3BQq,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	HVDBmw2JO5c6f1bTiIAp8M79NxlaF = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','LIVE_GROUPED','__COUNT__')
	Y5SsLdRCvoMUw29e7FOaJPhpjBD0 = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	w9vCrjdRAtSQMEy45fne0Nq7 = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','VOD_MOVIES_GROUPED','__COUNT__')
	XNKLDk43R7 = JKCrO8x7ZyIfwVgSvX(imduHcLnGAlDypzrUPoCIagwV3BQq,'int','VOD_SERIES_GROUPED','__COUNT__')
	WQ7dXkhqP2mb = JKCrO8x7ZyIfwVgSvX(xAuNED94mrQWv,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	JfXr5qciYokQHtdWnL3sBZMvuSb2DA = JKCrO8x7ZyIfwVgSvX(imduHcLnGAlDypzrUPoCIagwV3BQq,'list','VOD_SERIES_GROUPED','__GROUPS__')
	Y0OzxJWNyTA6MQH = []
	for mktodBPJD9yqsc,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in JfXr5qciYokQHtdWnL3sBZMvuSb2DA:
		CSHuwkaMzOU75d = mktodBPJD9yqsc.split('__SERIES__')[1]
		Y0OzxJWNyTA6MQH.append(CSHuwkaMzOU75d)
	ZXyx8DqMTk7QYGesl = len(Y0OzxJWNyTA6MQH)
	IBVxTKyo7J = int(w9vCrjdRAtSQMEy45fne0Nq7)+int(XNKLDk43R7)+int(WQ7dXkhqP2mb)+int(Y5SsLdRCvoMUw29e7FOaJPhpjBD0)+int(HVDBmw2JO5c6f1bTiIAp8M79NxlaF)
	ttbwKUOHZg = sCHVtMAvqirbQ4BUK3cgWo
	ttbwKUOHZg += 'قنوات: '+str(HVDBmw2JO5c6f1bTiIAp8M79NxlaF)
	ttbwKUOHZg += '   .   أفلام: '+str(w9vCrjdRAtSQMEy45fne0Nq7)
	ttbwKUOHZg += '\nمسلسلات: '+str(ZXyx8DqMTk7QYGesl)
	ttbwKUOHZg += '   .   حلقات: '+str(XNKLDk43R7)
	ttbwKUOHZg += '\nقنوات مجهولة: '+str(Y5SsLdRCvoMUw29e7FOaJPhpjBD0)
	ttbwKUOHZg += '   .   فيدوهات مجهولة: '+str(WQ7dXkhqP2mb)
	ttbwKUOHZg += '\nمجموع القنوات: '+str(CqZKFg9ei82Yfs0zdVLBGcJWn5)
	ttbwKUOHZg += '   .   مجموع الفيديوهات: '+str(roYkUcalTZW6nX7eAiqR3FwNJx5h1p)
	ttbwKUOHZg += '\n\nمجموع المضافة: '+str(IBVxTKyo7J)
	ttbwKUOHZg += '   .   مجموع المهملة: '+str(syGWjxq8nrKhEM5)
	if JOQGgY5w8D93IKM: ZZDswXvceNFRhafpUtWELYCP('center',sCHVtMAvqirbQ4BUK3cgWo,gJ5HToD4b0fsQ3im,ttbwKUOHZg)
	pUWHFheG8n3vwmS0EauAzkx4oBgVYJ = ttbwKUOHZg.replace('\n\n',slFfrUIWCowaBA7tce3iZbj8xn)
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,'.\tCounts of IPTV videos   Folder: '+n0mErNiResZbqGAJBv9MD+slFfrUIWCowaBA7tce3iZbj8xn+pUWHFheG8n3vwmS0EauAzkx4oBgVYJ)
	return ttbwKUOHZg
def HLQ1ZNlJWDdIixM(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM=True):
	if JOQGgY5w8D93IKM:
		PemgFp6AyMXlb = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if PemgFp6AyMXlb!=1: return
		qFnIl6OB5eWZToQ8PUGKsHvC3 = nVBSuE26QPC9dy.replace('___','_'+n0mErNiResZbqGAJBv9MD)
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(qFnIl6OB5eWZToQ8PUGKsHvC3)
		except: pass
	qFnIl6OB5eWZToQ8PUGKsHvC3 = JJkHbPqLZtIUMFrWlA41C9EaOdy.replace('___','_'+n0mErNiResZbqGAJBv9MD)
	try: YYEXZsUWhf52vz7HLxc0qGJ.remove(qFnIl6OB5eWZToQ8PUGKsHvC3)
	except: pass
	qFnIl6OB5eWZToQ8PUGKsHvC3 = H5HkipzgNFQSTObj3CPfcV.replace('___','_'+n0mErNiResZbqGAJBv9MD)
	try: YYEXZsUWhf52vz7HLxc0qGJ.remove(qFnIl6OB5eWZToQ8PUGKsHvC3)
	except: pass
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'SECTIONS_IPTV','SECTIONS_IPTV_'+n0mErNiResZbqGAJBv9MD)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	Hy2bntGarc7J(False)
	Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD)
	if JOQGgY5w8D93IKM:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم مسح جميع ملفات ـIPTV')
		Ims96cLXkvKOx0GD(False)
	return
def l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD=sCHVtMAvqirbQ4BUK3cgWo,JOQGgY5w8D93IKM=True):
	if n0mErNiResZbqGAJBv9MD:
		EM3RApNQLyuDgO4X = byXFEoIvTe(str(n0mErNiResZbqGAJBv9MD),'DUMMY')
		FFvbXzryi3TRG5wEM6t9SD = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'str','DUMMY','__DUMMY__')
		if FFvbXzryi3TRG5wEM6t9SD: return True
	else:
		n0mErNiResZbqGAJBv9MD = '1'
		for sHph3rGJzo5bE8LajqVk6 in range(1,cjJXgt71A5+1):
			EM3RApNQLyuDgO4X = byXFEoIvTe(str(sHph3rGJzo5bE8LajqVk6),'DUMMY')
			FFvbXzryi3TRG5wEM6t9SD = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'str','DUMMY','__DUMMY__')
			if FFvbXzryi3TRG5wEM6t9SD: return True
	if JOQGgY5w8D93IKM:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+VXWOCAE6ns3paJ8DLG479NQfMu+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+B8alA5nvIhTxQ)
		gJ5HToD4b0fsQ3im = 'إضافة وتغيير رابط '+dTacwSXg2MOGtHY[1]+' (مجلد '+dTacwSXg2MOGtHY[int(n0mErNiResZbqGAJBv9MD)]+')'
		PemgFp6AyMXlb = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,gJ5HToD4b0fsQ3im,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if PemgFp6AyMXlb==1: DDB7wFaNcizxyU48vh(n0mErNiResZbqGAJBv9MD)
	return False
def wwinEbetVG3su1TD2L7NFOp(BVEYuzQJ17X,n0mErNiResZbqGAJBv9MD=sCHVtMAvqirbQ4BUK3cgWo,i6NzAvsXlpDE8atUWOboIV=sCHVtMAvqirbQ4BUK3cgWo,gesptH6cYkwRiM28rCqzoPhDN5=sCHVtMAvqirbQ4BUK3cgWo):
	if not gesptH6cYkwRiM28rCqzoPhDN5: gesptH6cYkwRiM28rCqzoPhDN5 = '1'
	W7jZKBiSIo0shrXl4y9pFT,mHY2EseIvtnoF6Ax0KWdQVrLP,JOQGgY5w8D93IKM = KwmOrR2yNXpGFiCv4fMthB5(BVEYuzQJ17X)
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM): return
	if not W7jZKBiSIo0shrXl4y9pFT:
		W7jZKBiSIo0shrXl4y9pFT = UyBdvjGrFxDWMpmLOXn()
		if not W7jZKBiSIo0shrXl4y9pFT: return
	yUcVKsxhQGJ6WkA = [sCHVtMAvqirbQ4BUK3cgWo,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not i6NzAvsXlpDE8atUWOboIV:
		if not JOQGgY5w8D93IKM:
			if   '_IPTV-LIVE_' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[1]
			elif '_IPTV-MOVIES' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[2]
			elif '_IPTV-SERIES' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[3]
			else: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[0]
		else:
			qGC7i8fnZKpwFoVa5Axz = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			KTxQcnwvOF0pqt = Wdlg19qZ4apQtYFCINvBeML0c('أختر البحث المناسب', qGC7i8fnZKpwFoVa5Axz)
			if KTxQcnwvOF0pqt==-1: return
			i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[KTxQcnwvOF0pqt]
	W7jZKBiSIo0shrXl4y9pFT = W7jZKBiSIo0shrXl4y9pFT+'_NODIALOGS_'
	if n0mErNiResZbqGAJBv9MD: O4QcEU3y2KYghPjAnBaFHNeMqL8G5(W7jZKBiSIo0shrXl4y9pFT,n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV,gesptH6cYkwRiM28rCqzoPhDN5)
	else:
		for n0mErNiResZbqGAJBv9MD in range(1,cjJXgt71A5+1):
			O4QcEU3y2KYghPjAnBaFHNeMqL8G5(W7jZKBiSIo0shrXl4y9pFT,str(n0mErNiResZbqGAJBv9MD),i6NzAvsXlpDE8atUWOboIV,gesptH6cYkwRiM28rCqzoPhDN5)
		Q1siCkTZyw.menuItemsLIST[:] = sorted(Q1siCkTZyw.menuItemsLIST,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju[1].lower())
	return
def O4QcEU3y2KYghPjAnBaFHNeMqL8G5(BVEYuzQJ17X,n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV=sCHVtMAvqirbQ4BUK3cgWo,gesptH6cYkwRiM28rCqzoPhDN5=sCHVtMAvqirbQ4BUK3cgWo):
	if not gesptH6cYkwRiM28rCqzoPhDN5: gesptH6cYkwRiM28rCqzoPhDN5 = '1'
	W7jZKBiSIo0shrXl4y9pFT,mHY2EseIvtnoF6Ax0KWdQVrLP,JOQGgY5w8D93IKM = KwmOrR2yNXpGFiCv4fMthB5(BVEYuzQJ17X)
	if not n0mErNiResZbqGAJBv9MD: return
	if not l1au36XEkVRnFrs(n0mErNiResZbqGAJBv9MD,JOQGgY5w8D93IKM): return
	if not W7jZKBiSIo0shrXl4y9pFT:
		W7jZKBiSIo0shrXl4y9pFT = UyBdvjGrFxDWMpmLOXn()
		if not W7jZKBiSIo0shrXl4y9pFT: return
	yUcVKsxhQGJ6WkA = [sCHVtMAvqirbQ4BUK3cgWo,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not i6NzAvsXlpDE8atUWOboIV:
		if not JOQGgY5w8D93IKM:
			if   '_IPTV-LIVE_' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[1]
			elif '_IPTV-MOVIES' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[2]
			elif '_IPTV-SERIES' in mHY2EseIvtnoF6Ax0KWdQVrLP: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[3]
			else: i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[0]
		else:
			qGC7i8fnZKpwFoVa5Axz = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			KTxQcnwvOF0pqt = Wdlg19qZ4apQtYFCINvBeML0c('أختر البحث المناسب', qGC7i8fnZKpwFoVa5Axz)
			if KTxQcnwvOF0pqt==-1: return
			i6NzAvsXlpDE8atUWOboIV = yUcVKsxhQGJ6WkA[KTxQcnwvOF0pqt]
	Y1Db3fUdO4Sg8pzQVq6aP = W7jZKBiSIo0shrXl4y9pFT.lower()
	EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,'SEARCH')
	PaQp3oz49JfRdYbywq = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list','SEARCH',(i6NzAvsXlpDE8atUWOboIV,Y1Db3fUdO4Sg8pzQVq6aP))
	if not PaQp3oz49JfRdYbywq:
		z1sBRM9frjlgXAoSPuZ2DTG,fxdXrmqbGJP1 = [],[]
		if not i6NzAvsXlpDE8atUWOboIV: YvTmBhfDixkF9R5Q0Cl = [1,2,3,4,5]
		else: YvTmBhfDixkF9R5Q0Cl = [yUcVKsxhQGJ6WkA.index(i6NzAvsXlpDE8atUWOboIV)]
		for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in YvTmBhfDixkF9R5Q0Cl:
			EM3RApNQLyuDgO4X = byXFEoIvTe(n0mErNiResZbqGAJBv9MD,yUcVKsxhQGJ6WkA[qT1ZRz0VMiXQhxFUPdJC2u9asvrN])
			if qT1ZRz0VMiXQhxFUPdJC2u9asvrN!=3:
				yUQouZ5rALX0DM1b9Ex2nR6gtO = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'dict',yUcVKsxhQGJ6WkA[qT1ZRz0VMiXQhxFUPdJC2u9asvrN])
				del yUQouZ5rALX0DM1b9Ex2nR6gtO['__COUNT__']
				del yUQouZ5rALX0DM1b9Ex2nR6gtO['__GROUPS__']
				del yUQouZ5rALX0DM1b9Ex2nR6gtO['__SEQUENCED_COLUMNS__']
				JfXr5qciYokQHtdWnL3sBZMvuSb2DA = list(yUQouZ5rALX0DM1b9Ex2nR6gtO.keys())
				for mktodBPJD9yqsc in JfXr5qciYokQHtdWnL3sBZMvuSb2DA:
					for hzwScpHQRnB5Z,F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in yUQouZ5rALX0DM1b9Ex2nR6gtO[mktodBPJD9yqsc]:
						if Y1Db3fUdO4Sg8pzQVq6aP in F29iVTaoCEjXBMvfuxytelrn.lower(): fxdXrmqbGJP1.append((F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo))
					del yUQouZ5rALX0DM1b9Ex2nR6gtO[mktodBPJD9yqsc]
				del yUQouZ5rALX0DM1b9Ex2nR6gtO
			else: JfXr5qciYokQHtdWnL3sBZMvuSb2DA = JKCrO8x7ZyIfwVgSvX(EM3RApNQLyuDgO4X,'list',yUcVKsxhQGJ6WkA[qT1ZRz0VMiXQhxFUPdJC2u9asvrN],'__GROUPS__')
			for mktodBPJD9yqsc in JfXr5qciYokQHtdWnL3sBZMvuSb2DA:
				try: mktodBPJD9yqsc,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo = mktodBPJD9yqsc
				except: Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo = sCHVtMAvqirbQ4BUK3cgWo
				if Y1Db3fUdO4Sg8pzQVq6aP in mktodBPJD9yqsc.lower():
					if qT1ZRz0VMiXQhxFUPdJC2u9asvrN!=3: dnigOKorH8sIQLMmy27qPkpJDVEf = mktodBPJD9yqsc
					else:
						yyj1RWNpdCqGbYQLeBsDKxU3kaH7M,e1a3qvSMmby = mktodBPJD9yqsc.split('__SERIES__')
						if Y1Db3fUdO4Sg8pzQVq6aP in yyj1RWNpdCqGbYQLeBsDKxU3kaH7M.lower(): dnigOKorH8sIQLMmy27qPkpJDVEf = yyj1RWNpdCqGbYQLeBsDKxU3kaH7M
						else: dnigOKorH8sIQLMmy27qPkpJDVEf = e1a3qvSMmby
					z1sBRM9frjlgXAoSPuZ2DTG.append((mktodBPJD9yqsc,dnigOKorH8sIQLMmy27qPkpJDVEf,yUcVKsxhQGJ6WkA[qT1ZRz0VMiXQhxFUPdJC2u9asvrN],Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo))
			del JfXr5qciYokQHtdWnL3sBZMvuSb2DA
		z1sBRM9frjlgXAoSPuZ2DTG = set(z1sBRM9frjlgXAoSPuZ2DTG)
		fxdXrmqbGJP1 = set(fxdXrmqbGJP1)
		z1sBRM9frjlgXAoSPuZ2DTG = sorted(z1sBRM9frjlgXAoSPuZ2DTG,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju[1])
		fxdXrmqbGJP1 = sorted(fxdXrmqbGJP1,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju[0])
		kPQB6UJMiVGmHoT9w8(EM3RApNQLyuDgO4X,'SEARCH',(i6NzAvsXlpDE8atUWOboIV,Y1Db3fUdO4Sg8pzQVq6aP),(z1sBRM9frjlgXAoSPuZ2DTG,fxdXrmqbGJP1),IfAkw39UvaYWEDXLthFrbSzG)
	else: z1sBRM9frjlgXAoSPuZ2DTG,fxdXrmqbGJP1 = PaQp3oz49JfRdYbywq
	JfXr5qciYokQHtdWnL3sBZMvuSb2DA = len(z1sBRM9frjlgXAoSPuZ2DTG)
	gy1GYU8vNMus5rjwxEBmJlH97ke = len(fxdXrmqbGJP1)
	Ml0wzrY8uFeLOaPQyxmbX9 = int(gesptH6cYkwRiM28rCqzoPhDN5)
	MnsHovpUwdxZtFNeK7WjyuAYqlk = max(0,(Ml0wzrY8uFeLOaPQyxmbX9-1)*100)
	K8KjV0kxqCc297fTgFGve = max(0,Ml0wzrY8uFeLOaPQyxmbX9*100)
	sKCcxZHSvB465bN9WDM0toAge = max(0,MnsHovpUwdxZtFNeK7WjyuAYqlk-JfXr5qciYokQHtdWnL3sBZMvuSb2DA)
	VV72Kp5YRjx3CHGqSOFJLzBEs1 = max(0,K8KjV0kxqCc297fTgFGve-JfXr5qciYokQHtdWnL3sBZMvuSb2DA)
	for mktodBPJD9yqsc,dnigOKorH8sIQLMmy27qPkpJDVEf,ydJ1b3OaPxNEqQ6oLZws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in z1sBRM9frjlgXAoSPuZ2DTG[MnsHovpUwdxZtFNeK7WjyuAYqlk:K8KjV0kxqCc297fTgFGve]:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+dnigOKorH8sIQLMmy27qPkpJDVEf,ydJ1b3OaPxNEqQ6oLZws,234,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,'1',mktodBPJD9yqsc,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	del z1sBRM9frjlgXAoSPuZ2DTG
	for F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo in fxdXrmqbGJP1[sKCcxZHSvB465bN9WDM0toAge:VV72Kp5YRjx3CHGqSOFJLzBEs1]:
		WDaRkJulyzsv6XLgijIfCBPcbowA8 = FA0Y1k9va5O2zmU6By(qhWpTazQ9ws)
		iHPTUWrX1nbg = 'live'
		if '.mkv' in WDaRkJulyzsv6XLgijIfCBPcbowA8 or 'VOD' in i6NzAvsXlpDE8atUWOboIV: iHPTUWrX1nbg = 'video'
		XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,235,Aja3J2T8Yk9pPzsRSIbilBOUMZF6Lo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	del fxdXrmqbGJP1
	HYPCgInSqDoZyBv3eziWNXpE(n0mErNiResZbqGAJBv9MD,gesptH6cYkwRiM28rCqzoPhDN5,i6NzAvsXlpDE8atUWOboIV,239,JfXr5qciYokQHtdWnL3sBZMvuSb2DA+gy1GYU8vNMus5rjwxEBmJlH97ke,W7jZKBiSIo0shrXl4y9pFT+'_NODIALOGS_')
	return
def HYPCgInSqDoZyBv3eziWNXpE(n0mErNiResZbqGAJBv9MD,gesptH6cYkwRiM28rCqzoPhDN5,i6NzAvsXlpDE8atUWOboIV,QQ8kHjYnKEDU3sxft9S5iRoB,IBVxTKyo7J,T67f3LG49xpP8zcN):
	if gesptH6cYkwRiM28rCqzoPhDN5!='1': XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'صفحة '+str(1),i6NzAvsXlpDE8atUWOboIV,QQ8kHjYnKEDU3sxft9S5iRoB,sCHVtMAvqirbQ4BUK3cgWo,str(1),T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	if not IBVxTKyo7J: IBVxTKyo7J = 0
	ssJUVvBWQ9OnMHYENT8x56wop = int(IBVxTKyo7J/100)+1
	for Ml0wzrY8uFeLOaPQyxmbX9 in range(2,ssJUVvBWQ9OnMHYENT8x56wop):
		IfNx7TAMFG0WpKbvS9jXo1RdLCk = (Ml0wzrY8uFeLOaPQyxmbX9%10==0 or int(gesptH6cYkwRiM28rCqzoPhDN5)-4<Ml0wzrY8uFeLOaPQyxmbX9<int(gesptH6cYkwRiM28rCqzoPhDN5)+4)
		XlYVW4iqbnx1ztJrd = (IfNx7TAMFG0WpKbvS9jXo1RdLCk and int(gesptH6cYkwRiM28rCqzoPhDN5)-40<Ml0wzrY8uFeLOaPQyxmbX9<int(gesptH6cYkwRiM28rCqzoPhDN5)+40)
		if str(Ml0wzrY8uFeLOaPQyxmbX9)!=gesptH6cYkwRiM28rCqzoPhDN5 and (Ml0wzrY8uFeLOaPQyxmbX9%100==0 or XlYVW4iqbnx1ztJrd):
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'صفحة '+str(Ml0wzrY8uFeLOaPQyxmbX9),i6NzAvsXlpDE8atUWOboIV,QQ8kHjYnKEDU3sxft9S5iRoB,sCHVtMAvqirbQ4BUK3cgWo,str(Ml0wzrY8uFeLOaPQyxmbX9),T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	if str(ssJUVvBWQ9OnMHYENT8x56wop)!=gesptH6cYkwRiM28rCqzoPhDN5: XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+'أخر صفحة '+str(ssJUVvBWQ9OnMHYENT8x56wop),i6NzAvsXlpDE8atUWOboIV,QQ8kHjYnKEDU3sxft9S5iRoB,sCHVtMAvqirbQ4BUK3cgWo,str(ssJUVvBWQ9OnMHYENT8x56wop),T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	return
def byXFEoIvTe(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV):
	if 'SERIES' in i6NzAvsXlpDE8atUWOboIV or 'VOD_ORIGINAL' in i6NzAvsXlpDE8atUWOboIV: EM3RApNQLyuDgO4X = H5HkipzgNFQSTObj3CPfcV
	else: EM3RApNQLyuDgO4X = JJkHbPqLZtIUMFrWlA41C9EaOdy
	EM3RApNQLyuDgO4X = EM3RApNQLyuDgO4X.replace('___','_'+n0mErNiResZbqGAJBv9MD)
	return EM3RApNQLyuDgO4X
def n9ymIsTHvEerj(n0mErNiResZbqGAJBv9MD,i6NzAvsXlpDE8atUWOboIV,gk8ScGJHxzypX7sfrt3BhK):
	rGeZ4sV3gt0xNw8aLBi,wbYt4mZ8zRnP6HuyD5CW7EdBp03,jVJZueBdXFra2v0L,ttdqEI7vlzPcpKHyZjgXN3esmfBkT,OC1aqTJt2EyZALVx4o = yyxda2JsiMYDbCZ8B1nUPLlj6Of(n0mErNiResZbqGAJBv9MD)
	if not ttdqEI7vlzPcpKHyZjgXN3esmfBkT: return
	f6cPGkTodE = RusZHdXe94JY86zVCUm(n0mErNiResZbqGAJBv9MD)
	if   i6NzAvsXlpDE8atUWOboIV=='XTREAM_LIVE_GROUPS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_live_categories'
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_VOD_GROUPS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_vod_categories'
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_SERIES_GROUPS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_series_categories'
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_LIVE_ITEMS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_live_streams&category_id='+gk8ScGJHxzypX7sfrt3BhK
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_VOD_ITEMS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_vod_streams&category_id='+gk8ScGJHxzypX7sfrt3BhK
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_SERIES_ITEMS': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_series&category_id='+gk8ScGJHxzypX7sfrt3BhK
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_EPISODES': qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi+'&action=get_series_info&series_id='+gk8ScGJHxzypX7sfrt3BhK
	else: return
	qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',qhWpTazQ9ws,sCHVtMAvqirbQ4BUK3cgWo,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IPTV-XTREAM_MENUS-1st')
	BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
	if qdUK5ioJyrO1T: BJ0mjN2OU8 = BJ0mjN2OU8.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	ZZeiM0apRS7UHQ4C2lur = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('list',BJ0mjN2OU8)
	if 'GROUPS' in i6NzAvsXlpDE8atUWOboIV:
		i6NzAvsXlpDE8atUWOboIV = i6NzAvsXlpDE8atUWOboIV.replace('_GROUPS','_ITEMS')
		ZZeiM0apRS7UHQ4C2lur = sorted(ZZeiM0apRS7UHQ4C2lur,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju['category_name'].lower())
		for mktodBPJD9yqsc in ZZeiM0apRS7UHQ4C2lur:
			FPUgVuv9xDmQbsKh = mktodBPJD9yqsc['category_id']
			F29iVTaoCEjXBMvfuxytelrn = mktodBPJD9yqsc['category_name']
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,i6NzAvsXlpDE8atUWOboIV,285,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,str(FPUgVuv9xDmQbsKh),sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_SERIES_ITEMS':
		ZZeiM0apRS7UHQ4C2lur = sorted(ZZeiM0apRS7UHQ4C2lur,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju['name'].lower())
		for hxpSu7nBoX6EPQOAZ in ZZeiM0apRS7UHQ4C2lur:
			F29iVTaoCEjXBMvfuxytelrn = hxpSu7nBoX6EPQOAZ['name']
			yNbi4akQM9EHO8wSlCGoJZx = hxpSu7nBoX6EPQOAZ['cover']
			FPUgVuv9xDmQbsKh = hxpSu7nBoX6EPQOAZ['series_id']
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,'XTREAM_EPISODES',285,yNbi4akQM9EHO8wSlCGoJZx,sCHVtMAvqirbQ4BUK3cgWo,str(FPUgVuv9xDmQbsKh),sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	elif i6NzAvsXlpDE8atUWOboIV=='XTREAM_EPISODES':
		yNbi4akQM9EHO8wSlCGoJZx = ZZeiM0apRS7UHQ4C2lur['info']['cover']
		hoVitY5TylJ7GBEIZNOQg8pukq = ZZeiM0apRS7UHQ4C2lur['info']['name']
		obfO5Dp9JY = ZZeiM0apRS7UHQ4C2lur['episodes']
		for BiUZg1Aj9SKM7vTu8Ntesa in obfO5Dp9JY:
			gCTxAUsvheMGmBrnatR8XVi = obfO5Dp9JY[BiUZg1Aj9SKM7vTu8Ntesa]
			for KanW48Ahcxq7SJYrpCPm in gCTxAUsvheMGmBrnatR8XVi:
				F29iVTaoCEjXBMvfuxytelrn = KanW48Ahcxq7SJYrpCPm['title']
				VSzDZiYCvW9Fyf5dtjoGpM3w = fNntYJW45mEFSdRX8g.findall('\d+.(S\d+E\d+)',F29iVTaoCEjXBMvfuxytelrn,fNntYJW45mEFSdRX8g.DOTALL)
				if VSzDZiYCvW9Fyf5dtjoGpM3w: F29iVTaoCEjXBMvfuxytelrn = hoVitY5TylJ7GBEIZNOQg8pukq+AAh0X3OCacr4HpifRGLZKT+VSzDZiYCvW9Fyf5dtjoGpM3w[0]
				FPUgVuv9xDmQbsKh = KanW48Ahcxq7SJYrpCPm['id']
				cjvnPTLrF4MlZqh5dUz8EbH = KanW48Ahcxq7SJYrpCPm['container_extension']
				qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi.split('/player_api.php')[0]+'/series/'+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+'/'+OC1aqTJt2EyZALVx4o+'/'+str(FPUgVuv9xDmQbsKh)+'.'+cjvnPTLrF4MlZqh5dUz8EbH
				XAozRfZ68H9x2OsiP3LmIaql1('video',Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,235,yNbi4akQM9EHO8wSlCGoJZx,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	elif 'ITEMS' in i6NzAvsXlpDE8atUWOboIV:
		iHPTUWrX1nbg = 'live' if 'LIVE' in i6NzAvsXlpDE8atUWOboIV else 'video'
		ZZeiM0apRS7UHQ4C2lur = sorted(ZZeiM0apRS7UHQ4C2lur,reverse=False,key=lambda FCYq34IhByUnfKRi1GS5pmD6Vzd7ju: FCYq34IhByUnfKRi1GS5pmD6Vzd7ju['name'].lower())
		for g7pWujNlkBJom5FGeSA3aYix in ZZeiM0apRS7UHQ4C2lur:
			F29iVTaoCEjXBMvfuxytelrn = g7pWujNlkBJom5FGeSA3aYix['name']
			yNbi4akQM9EHO8wSlCGoJZx = g7pWujNlkBJom5FGeSA3aYix['stream_icon']
			FPUgVuv9xDmQbsKh = g7pWujNlkBJom5FGeSA3aYix['stream_id']
			try:
				cjvnPTLrF4MlZqh5dUz8EbH = g7pWujNlkBJom5FGeSA3aYix['container_extension']
				if cjvnPTLrF4MlZqh5dUz8EbH: cjvnPTLrF4MlZqh5dUz8EbH = '.'+cjvnPTLrF4MlZqh5dUz8EbH
			except: cjvnPTLrF4MlZqh5dUz8EbH = sCHVtMAvqirbQ4BUK3cgWo
			if g7pWujNlkBJom5FGeSA3aYix['stream_type']=='live': kcw0uEQAlF74YDqtO25MxLNmo3KIn,MP3Gosu25BA7Q9FlHqgda0y = sCHVtMAvqirbQ4BUK3cgWo,'live'
			elif g7pWujNlkBJom5FGeSA3aYix['stream_type']=='movie': kcw0uEQAlF74YDqtO25MxLNmo3KIn,MP3Gosu25BA7Q9FlHqgda0y = 'movie/','video'
			qhWpTazQ9ws = rGeZ4sV3gt0xNw8aLBi.split('/player_api.php')[0]+'/'+kcw0uEQAlF74YDqtO25MxLNmo3KIn+ttdqEI7vlzPcpKHyZjgXN3esmfBkT+'/'+OC1aqTJt2EyZALVx4o+'/'+str(FPUgVuv9xDmQbsKh)+cjvnPTLrF4MlZqh5dUz8EbH
			XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,Y6xCT1m2lpbnKLJPZ5R8hSqO+F29iVTaoCEjXBMvfuxytelrn,qhWpTazQ9ws,235,yNbi4akQM9EHO8wSlCGoJZx,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,{'folder':n0mErNiResZbqGAJBv9MD})
	return
def Mg2LkdGOpjwe5K6uH3txaTR9WS8P(n0mErNiResZbqGAJBv9MD):
	VVwQgNjJAehI2KSPLs4Y60B = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.provider')
	vr6aJ5xiRcd1GUpQOqHgC4EwLBu = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'MENUS_CACHE_'+VVwQgNjJAehI2KSPLs4Y60B+'_'+vr6aJ5xiRcd1GUpQOqHgC4EwLBu,'%_IP'+n0mErNiResZbqGAJBv9MD+'_%')
	return
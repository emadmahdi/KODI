# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYBEST4'
Z0BYJQghVL1v87CAem = '_EB4_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==800: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==801: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV)
	elif mode==802: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==803: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==804: ka7jz96YCdTBnQOLVPuJG3285MHf = jWXMJvDftU2zxVTh9G3QE7oZ0B(url)
	elif mode==806: ka7jz96YCdTBnQOLVPuJG3285MHf = kAUpK78mJRgoWZQytrNXeh5xf3v(url,mRwrKW6fNZV)
	elif mode==809: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,809,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر',gAVl1vUmus8+'/trending',804,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('nav-categories(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('mainContent(.*?)<footer>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801,sCHVtMAvqirbQ4BUK3cgWo,'mainmenu')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-menu(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801)
	return Sw0pOFoVhPeIxbl
def kAUpK78mJRgoWZQytrNXeh5xf3v(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-SEASONS_EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('mainTitle.*?>(.*?)<(.*?)pageContent',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		bFNze460jv,pWu3ti618zVAbjdf7,items = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[]
		for name,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			if 'حلقات' in name: pWu3ti618zVAbjdf7 = Po9h3gWFuLR2
			if 'مواسم' in name: bFNze460jv = Po9h3gWFuLR2
		if bFNze460jv and not type:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',bFNze460jv,fNntYJW45mEFSdRX8g.DOTALL)
			if len(items)>1:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,806,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
		if pWu3ti618zVAbjdf7 and len(items)<2:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,803,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else:
				items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,803)
	return
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	T1AWiH6ZJ2X3Ccs,start,Ffh8yTQ3d6sp,select,CUb4zVG6lTcmaAqBJnr = 0,0,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if 'pagination' in type:
		EvBZakmM65UlcHDqxeiInArPWCF,i68iPmaHVAZknGv2SNpyzCwcFE = url.split('?next=page&')
		HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',EvBZakmM65UlcHDqxeiInArPWCF,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		ssUAzo3RibtgDv7O0x = 'secContent'+Sw0pOFoVhPeIxbl+'<footer>'
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		ssUAzo3RibtgDv7O0x = Sw0pOFoVhPeIxbl
	items,hwGsDZtO93Qm1IkdYinj,W6WgK7nGvCuozqhaSkFMXiye = [],False,False
	if not type and '/collections' not in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('mainContent(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801,sCHVtMAvqirbQ4BUK3cgWo,'submenu')
				hwGsDZtO93Qm1IkdYinj = True
	if not hwGsDZtO93Qm1IkdYinj:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('secContent(.*?)mainContent',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.strip(slFfrUIWCowaBA7tce3iZbj8xn)
				title = tt36wUe4HTPFmfs5hcbr(title)
				if '/series/' in B17r2fdFy9ns8tiOMLu and type=='season': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,806,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
				elif '/series/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,806,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				elif '/seasons/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
				elif '/collections' in url: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'collections')
				else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,803,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('loadMoreParams = (.*?);',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			FNtoIQygCMwk3emv8h6GKaYdjUAJ0 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',Po9h3gWFuLR2)
			CUb4zVG6lTcmaAqBJnr = FNtoIQygCMwk3emv8h6GKaYdjUAJ0['ajaxurl']
			Djhn7VkYUeNaz = int(FNtoIQygCMwk3emv8h6GKaYdjUAJ0['current_page'])+1
			XbQFqjwKx8 = int(FNtoIQygCMwk3emv8h6GKaYdjUAJ0['max_page'])
			IkKz4GD69iNWE = FNtoIQygCMwk3emv8h6GKaYdjUAJ0['posts'].replace('False','false').replace('True','true').replace('None','null')
			if Djhn7VkYUeNaz<XbQFqjwKx8:
				i68iPmaHVAZknGv2SNpyzCwcFE = 'action=loadmore&query='+IgCGzHw45TJ7PeuO1EKl(IkKz4GD69iNWE,sCHVtMAvqirbQ4BUK3cgWo)+'&page='+str(Djhn7VkYUeNaz)
				vrEJRkchKxtDNiqO1b79mL5eT = CUb4zVG6lTcmaAqBJnr+'?next=page&'+i68iPmaHVAZknGv2SNpyzCwcFE
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'جلب المزيد',vrEJRkchKxtDNiqO1b79mL5eT,801,sCHVtMAvqirbQ4BUK3cgWo,'pagination_'+type)
		elif '?next=page&' in url:
			i68iPmaHVAZknGv2SNpyzCwcFE,cLsJOECgZlU5Pp1RMVI0WTr = i68iPmaHVAZknGv2SNpyzCwcFE.rsplit('=',1)
			cLsJOECgZlU5Pp1RMVI0WTr = int(cLsJOECgZlU5Pp1RMVI0WTr)+1
			vrEJRkchKxtDNiqO1b79mL5eT = EvBZakmM65UlcHDqxeiInArPWCF+'?next=page&'+i68iPmaHVAZknGv2SNpyzCwcFE+'='+str(cLsJOECgZlU5Pp1RMVI0WTr)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'جلب المزيد',vrEJRkchKxtDNiqO1b79mL5eT,801,sCHVtMAvqirbQ4BUK3cgWo,'pagination_'+type)
	return
def jWXMJvDftU2zxVTh9G3QE7oZ0B(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-FILTERS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('sub_nav(.*?)secContent ',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('"current_opt">(.*?)<(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for name,Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
			if 'التصنيف' in name: continue
			name = name.strip(AAh0X3OCacr4HpifRGLZKT)
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,value in items:
				title = name+':  '+value
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,801,sCHVtMAvqirbQ4BUK3cgWo,'filter')
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST4-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('<td>التصنيف</td>.*?">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	cb1fAztguv78n9LGhSWJFm5p,y2EPKIcgxi8do3NOu6zbZ = [],[]
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('postEmbed.*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
		y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
		smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__embed')
	AOWvNSu2tR4pogIXKDlw9j = fNntYJW45mEFSdRX8g.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if AOWvNSu2tR4pogIXKDlw9j:
		CUb4zVG6lTcmaAqBJnr,uu4UgsMj01aImASoXpYDO9iQcfG = AOWvNSu2tR4pogIXKDlw9j[0]
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('postPlayer(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			vF7BwmirVQhcgE8lIMKZ4pd = fNntYJW45mEFSdRX8g.findall('<li.*?id\,(.*?)\);">(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for Tl7xVIFkOZ2mMGXoPe,name in vF7BwmirVQhcgE8lIMKZ4pd:
				B17r2fdFy9ns8tiOMLu = CUb4zVG6lTcmaAqBJnr+'/temp/ajax/iframe.php?id='+uu4UgsMj01aImASoXpYDO9iQcfG+'&video='+Tl7xVIFkOZ2mMGXoPe
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__watch')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pageContentDown(.*?)</table>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu in items:
			if B17r2fdFy9ns8tiOMLu not in y2EPKIcgxi8do3NOu6zbZ:
				if '/?url=' in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('/?url=')[1]
				y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
				smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__download____'+XO7Zr2W6kwieA)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search: search = UyBdvjGrFxDWMpmLOXn()
	if not search: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+ktT4O0VJm8UaDNlxKvinoBYFgdH
	fs7D0d3QyAT(url,'search')
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SERIES4WATCH'
headers = { 'User-Agent' : sCHVtMAvqirbQ4BUK3cgWo }
Z0BYJQghVL1v87CAem = '_SFW_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==210: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==211: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==212: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==213: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==214: ka7jz96YCdTBnQOLVPuJG3285MHf = w2pMhFGB46aDjiPT7(url)
	elif mode==215: ka7jz96YCdTBnQOLVPuJG3285MHf = niwsgEXmrfqSyUTcdj4eWH9u0tK(url)
	elif mode==218: ka7jz96YCdTBnQOLVPuJG3285MHf = mqWXn7kf4l3Q5sOtuzZP()
	elif mode==219: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def mqWXn7kf4l3Q5sOtuzZP():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'الموقع تغير بالكامل',message)
	return
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,219,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	url = gAVl1vUmus8+'/getpostsPin?type=one&data=pin&limit=25'
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',url,211)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('FiltersButtons(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-get="(.*?)".*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		url = gAVl1vUmus8+'/getposts?type=one&data='+B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,url,211)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('navigation-menu(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(http.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	MqARWHDkmiT4nlz = ['مسلسلات انمي','الرئيسية']
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if not any(value in title for value in MqARWHDkmiT4nlz):
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,211)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('MediaGrid"(.*?)class="pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		else: return
	items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	a4NmDS7WutoLk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		if '/series/' in B17r2fdFy9ns8tiOMLu: continue
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		title = tt36wUe4HTPFmfs5hcbr(title)
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if '/film/' in B17r2fdFy9ns8tiOMLu or any(value in title for value in a4NmDS7WutoLk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,212,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/episode/' in B17r2fdFy9ns8tiOMLu and 'الحلقة' in title:
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,213,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,213,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = tt36wUe4HTPFmfs5hcbr(B17r2fdFy9ns8tiOMLu)
			title = tt36wUe4HTPFmfs5hcbr(title)
			title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
			if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,211)
	return
def VzOBjnIkZSH7ft(url):
	M5wijux8CsFcWvnkTph1ZaJ4X,items,EFTdOhkS9b = -1,[],[]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-EPISODES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('ti-list-numbered(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Jae64ky3REO57A2MvVHB90 = sCHVtMAvqirbQ4BUK3cgWo.join(oPnz7Zt4xLHTwR)
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Jae64ky3REO57A2MvVHB90,fNntYJW45mEFSdRX8g.DOTALL)
	items.append(url)
	items = set(items)
	for B17r2fdFy9ns8tiOMLu in items:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.strip('/')
		title = '_MOD_' + B17r2fdFy9ns8tiOMLu.split('/')[-1].replace('-',AAh0X3OCacr4HpifRGLZKT)
		zPm7HsNhv8Gt5jpi2YUZlnOeDT = fNntYJW45mEFSdRX8g.findall('الحلقة-(\d+)',B17r2fdFy9ns8tiOMLu.split('/')[-1],fNntYJW45mEFSdRX8g.DOTALL)
		if zPm7HsNhv8Gt5jpi2YUZlnOeDT: zPm7HsNhv8Gt5jpi2YUZlnOeDT = zPm7HsNhv8Gt5jpi2YUZlnOeDT[0]
		else: zPm7HsNhv8Gt5jpi2YUZlnOeDT = '0'
		EFTdOhkS9b.append([B17r2fdFy9ns8tiOMLu,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT])
	items = sorted(EFTdOhkS9b, reverse=False, key=lambda key: int(key[2]))
	o5shnLISwa2HzQvqxJ = str(items).count('/season/')
	M5wijux8CsFcWvnkTph1ZaJ4X = str(items).count('/episode/')
	if o5shnLISwa2HzQvqxJ>1 and M5wijux8CsFcWvnkTph1ZaJ4X>0 and '/season/' not in url:
		for B17r2fdFy9ns8tiOMLu,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT in items:
			if '/season/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,213)
	else:
		for B17r2fdFy9ns8tiOMLu,title,zPm7HsNhv8Gt5jpi2YUZlnOeDT in items:
			if '/season/' not in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,212)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV = []
	cuIJ3axEtVWvs = url.split('/')
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in Sw0pOFoVhPeIxbl:
		vrEJRkchKxtDNiqO1b79mL5eT = url.replace(cuIJ3axEtVWvs[3],'watch')
		ssUAzo3RibtgDv7O0x = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-PLAY-2nd')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="servers-list(.*?)</div>',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				id = fNntYJW45mEFSdRX8g.findall('post_id=(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
				if id:
					ISfWanzRV0GLEpY7e9Tl4FBsv1u = id[0]
					for B17r2fdFy9ns8tiOMLu,title in items:
						B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/?postid='+ISfWanzRV0GLEpY7e9Tl4FBsv1u+'&serverid='+B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
						ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			else:
				items = fNntYJW45mEFSdRX8g.findall('data-embedd=".*?(http.*?)("|&quot;)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,qLbRrEtgenpSi in items:
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if '/download/' in Sw0pOFoVhPeIxbl:
		vrEJRkchKxtDNiqO1b79mL5eT = url.replace(cuIJ3axEtVWvs[3],'download')
		ssUAzo3RibtgDv7O0x = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-PLAY-3rd')
		id = fNntYJW45mEFSdRX8g.findall('postId:"(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if id:
			ISfWanzRV0GLEpY7e9Tl4FBsv1u = id[0]
			HSNYwERMjzyxmrPku = { 'User-Agent':sCHVtMAvqirbQ4BUK3cgWo , 'X-Requested-With':'XMLHttpRequest' }
			vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8 + '/ajaxCenter?_action=getdownloadlinks&postId='+ISfWanzRV0GLEpY7e9Tl4FBsv1u
			ssUAzo3RibtgDv7O0x = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,'SERIES4WATCH-PLAY-4th')
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<h3.*?(\d+)(.*?)</div>',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if oPnz7Zt4xLHTwR:
				for xt31eNGL70UKPn,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
					items = fNntYJW45mEFSdRX8g.findall('<td>(.*?)<.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
					for name,B17r2fdFy9ns8tiOMLu in items:
						ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__download'+'____'+xt31eNGL70UKPn)
			else:
				oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<h6(.*?)</table>',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
				if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [ssUAzo3RibtgDv7O0x]
				for Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
					name = sCHVtMAvqirbQ4BUK3cgWo
					items = fNntYJW45mEFSdRX8g.findall('href="(http.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
					for B17r2fdFy9ns8tiOMLu in items:
						smh8Qbf9jH = '&&' + B17r2fdFy9ns8tiOMLu.split('/')[2].lower() + '&&'
						smh8Qbf9jH = smh8Qbf9jH.replace('.com&&',sCHVtMAvqirbQ4BUK3cgWo).replace('.co&&',sCHVtMAvqirbQ4BUK3cgWo)
						smh8Qbf9jH = smh8Qbf9jH.replace('.net&&',sCHVtMAvqirbQ4BUK3cgWo).replace('.org&&',sCHVtMAvqirbQ4BUK3cgWo)
						smh8Qbf9jH = smh8Qbf9jH.replace('.live&&',sCHVtMAvqirbQ4BUK3cgWo).replace('.online&&',sCHVtMAvqirbQ4BUK3cgWo)
						smh8Qbf9jH = smh8Qbf9jH.replace('&&hd.',sCHVtMAvqirbQ4BUK3cgWo).replace('&&www.',sCHVtMAvqirbQ4BUK3cgWo)
						smh8Qbf9jH = smh8Qbf9jH.replace('&&',sCHVtMAvqirbQ4BUK3cgWo)
						B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu + '?named=' + name + smh8Qbf9jH + '__download'
						ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8 + '/search?s='+search
	fs7D0d3QyAT(url)
	return
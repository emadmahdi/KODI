# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHOOFPRO'
Z0BYJQghVL1v87CAem = '_SHP_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مصارعة','بث مباشر']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==480: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==481: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==482: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==483: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url,text)
	elif mode==489: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text,url)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFPRO-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	aeBQsh4fzLr8XM5xou1gcyE = aeBQsh4fzLr8XM5xou1gcyE[0].strip('/')
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(aeBQsh4fzLr8XM5xou1gcyE,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',aeBQsh4fzLr8XM5xou1gcyE,489,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أحدث المواضيع',aeBQsh4fzLr8XM5xou1gcyE,481)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"navigation"(.*?)"myAccount"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu=='#': continue
		if title in MqARWHDkmiT4nlz: continue
		title = tt36wUe4HTPFmfs5hcbr(title)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,481)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,j4jdnGfAzKNS6tgLQaUhcYP0xBvRMC):
	items = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFPRO-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"post(.*?)"footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	CjYMEI9BN1UrT6 = '/'.join(j4jdnGfAzKNS6tgLQaUhcYP0xBvRMC.strip('/').split('/')[4:]).split('-')
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) حلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if j4jdnGfAzKNS6tgLQaUhcYP0xBvRMC:
			NroHCBWaxUZOfbgqMzAL4vJ2 = '/'.join(B17r2fdFy9ns8tiOMLu.strip('/').split('/')[4:]).split('-')
			nliIUSHYWDLjFwaBf5CvrQKOd9JgPu = len([pkO5dBQveUZuJFt0 for pkO5dBQveUZuJFt0 in CjYMEI9BN1UrT6 if pkO5dBQveUZuJFt0 in NroHCBWaxUZOfbgqMzAL4vJ2])
			if nliIUSHYWDLjFwaBf5CvrQKOd9JgPu>2 and '/episodes/' in B17r2fdFy9ns8tiOMLu:
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,482,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			if not bbFPOJrmkCaE6ul37XiKU: bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if set(title.split()) & set(chRY3biUoxnVltIk) and 'مسلسل' not in title:
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,482,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			elif bbFPOJrmkCaE6ul37XiKU and 'حلقة' in title:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,483,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,url)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,483,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,url)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("'pagination'(.*?)</div>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall("href='(.*?)'.*?>(.*?)</a>",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
			if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,481,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,j4jdnGfAzKNS6tgLQaUhcYP0xBvRMC)
	return
def VzOBjnIkZSH7ft(url,vrEJRkchKxtDNiqO1b79mL5eT):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFPRO-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"img-responsive" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
	else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Thumb')
	PUxBS7ZvOkgMAuoEdwizsh8fjWe = True
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"listSeasons(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx and '/ajax/seasons' not in url:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		count = Po9h3gWFuLR2.count('data-slug=')
		if count==0: count = Po9h3gWFuLR2.count('data-season=')
		if count>1:
			PUxBS7ZvOkgMAuoEdwizsh8fjWe = False
			if 'data-slug="' in Po9h3gWFuLR2:
				items = fNntYJW45mEFSdRX8g.findall('data-slug="(.*?)">(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for id,title in items:
					B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,483,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else:
				items = fNntYJW45mEFSdRX8g.findall('data-season="(.*?)">(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for id,title in items:
					B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,483,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if PUxBS7ZvOkgMAuoEdwizsh8fjWe:
		Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
		if '/ajax/seasons' in url: Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
		else:
			iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"eplist"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if iUtXlDhSVoBZJrPTQAwcER9nfMkN: Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,482,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if not Q1siCkTZyw.menuItemsLIST: fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT,url)
	return
def YH54mqkD2eU06(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url.strip('/')+'/?do=watch'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFPRO-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ss7YGDbuAIxgnqaQroTV = []
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	SSyNiGLhxRXH1TzFW3DPw = fNntYJW45mEFSdRX8g.findall('vo_postID = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not SSyNiGLhxRXH1TzFW3DPw: SSyNiGLhxRXH1TzFW3DPw = fNntYJW45mEFSdRX8g.findall('\(this\.id\,0\,(.*?)\)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	SSyNiGLhxRXH1TzFW3DPw = SSyNiGLhxRXH1TzFW3DPw[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"serversList"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('id="(.*?)".*?">(.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for xpr5w6F1cy4VbSIWJMRdt,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+SSyNiGLhxRXH1TzFW3DPw+'&video='+xpr5w6F1cy4VbSIWJMRdt[2:]+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"getEmbed".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		title = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu[0],'url')
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]+'?named='+title+'__embed'
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	vrEJRkchKxtDNiqO1b79mL5eT = url.strip('/')+'/?do=download'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFPRO-PLAY-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"table-responsive"(.*?)</table>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('<td>(.*?)</td>.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if 'anavidz' in B17r2fdFy9ns8tiOMLu: dwDUvp0LAuyg1rI = '__خاص'
			else: dwDUvp0LAuyg1rI = sCHVtMAvqirbQ4BUK3cgWo
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'+dwDUvp0LAuyg1rI
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search,aeBQsh4fzLr8XM5xou1gcyE=sCHVtMAvqirbQ4BUK3cgWo):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	if aeBQsh4fzLr8XM5xou1gcyE==sCHVtMAvqirbQ4BUK3cgWo: aeBQsh4fzLr8XM5xou1gcyE = gAVl1vUmus8
	url = aeBQsh4fzLr8XM5xou1gcyE+'/search/'+search+'/'
	fs7D0d3QyAT(url,sCHVtMAvqirbQ4BUK3cgWo)
	return
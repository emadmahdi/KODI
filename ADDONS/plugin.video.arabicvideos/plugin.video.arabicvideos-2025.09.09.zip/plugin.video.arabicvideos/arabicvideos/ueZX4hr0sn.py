# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'LIVETV'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS['PYTHON'][0]
def dBHD1Vl7hQuNOY(mode,url):
	if   mode==100: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==101: ka7jz96YCdTBnQOLVPuJG3285MHf = N9pi3VIH5uR('0',True)
	elif mode==102: ka7jz96YCdTBnQOLVPuJG3285MHf = N9pi3VIH5uR('1',True)
	elif mode==103: ka7jz96YCdTBnQOLVPuJG3285MHf = N9pi3VIH5uR('2',True)
	elif mode==104: ka7jz96YCdTBnQOLVPuJG3285MHf = N9pi3VIH5uR('3',True)
	elif mode==105: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==106: ka7jz96YCdTBnQOLVPuJG3285MHf = N9pi3VIH5uR('4',True)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_M3U_'+'قوائم فيديوهات M3U',sCHVtMAvqirbQ4BUK3cgWo,762)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_IPT_'+'قوائم فيديوهات IPTV',sCHVtMAvqirbQ4BUK3cgWo,761)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TV0_'+'قنوات من مواقعها الأصلية',sCHVtMAvqirbQ4BUK3cgWo,101)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TV4_'+'قنوات مختارة من يوتيوب',sCHVtMAvqirbQ4BUK3cgWo,106)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_YUT_'+'قنوات عربية من يوتيوب',sCHVtMAvqirbQ4BUK3cgWo,147)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_YUT_'+'قنوات أجنبية من يوتيوب',sCHVtMAvqirbQ4BUK3cgWo,148)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',sCHVtMAvqirbQ4BUK3cgWo,28)
	XAozRfZ68H9x2OsiP3LmIaql1('live','_MRF_'+'قناة المعارف من موقعهم',sCHVtMAvqirbQ4BUK3cgWo,41)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TV1_'+'قنوات تلفزيونية عامة',sCHVtMAvqirbQ4BUK3cgWo,102)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TV2_'+'قنوات تلفزيونية خاصة',sCHVtMAvqirbQ4BUK3cgWo,103)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TV3_'+'قنوات تلفزيونية للفحص',sCHVtMAvqirbQ4BUK3cgWo,104)
	return
def N9pi3VIH5uR(qsPRMmI7pHU2Ax4b98GgBTv,showDialogs=True):
	Z0BYJQghVL1v87CAem = '_TV'+qsPRMmI7pHU2Ax4b98GgBTv+'_'
	rnCzKJiBSsgGhj = {'id':sCHVtMAvqirbQ4BUK3cgWo,'user':Q1siCkTZyw.AV_CLIENT_IDS,'function':'list','menu':qsPRMmI7pHU2Ax4b98GgBTv}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',gAVl1vUmus8,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-ITEMS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		for XMIo9vWSBymeLJnK6YsU in range(len(items)):
			name = items[XMIo9vWSBymeLJnK6YsU][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[XMIo9vWSBymeLJnK6YsU] = items[XMIo9vWSBymeLJnK6YsU][0],items[XMIo9vWSBymeLJnK6YsU][1],items[XMIo9vWSBymeLJnK6YsU][2],name,items[XMIo9vWSBymeLJnK6YsU][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,smh8Qbf9jH,ISfWanzRV0GLEpY7e9Tl4FBsv1u,name,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			if '#' in zVbp6yjdF3qKkTvhDsJX9fgMceCuxt: continue
			if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt!='URL': name = name+VXWOCAE6ns3paJ8DLG479NQfMu+OUmtsIB1zyF+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+B8alA5nvIhTxQ
			url = zVbp6yjdF3qKkTvhDsJX9fgMceCuxt+';;'+smh8Qbf9jH+';;'+ISfWanzRV0GLEpY7e9Tl4FBsv1u+';;'+qsPRMmI7pHU2Ax4b98GgBTv
			XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+sCHVtMAvqirbQ4BUK3cgWo+name,url,105,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		if showDialogs: XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+'هذه الخدمة مخصصة للمبرمج فقط',sCHVtMAvqirbQ4BUK3cgWo,9999)
	return
def YH54mqkD2eU06(id):
	zVbp6yjdF3qKkTvhDsJX9fgMceCuxt,smh8Qbf9jH,ISfWanzRV0GLEpY7e9Tl4FBsv1u,qsPRMmI7pHU2Ax4b98GgBTv = id.split(';;')
	url = sCHVtMAvqirbQ4BUK3cgWo
	if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='URL': url = ISfWanzRV0GLEpY7e9Tl4FBsv1u
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='YOUTUBE':
		url = Q1siCkTZyw.SITESURLS['YOUTUBE'][0]+'/watch?v='+ISfWanzRV0GLEpY7e9Tl4FBsv1u
		import c27OeP8ifd
		c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1([url],Ll1m0nJoaAPvHsXqyRE,'live',url)
		return
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='GA':
		rnCzKJiBSsgGhj = { 'id' : sCHVtMAvqirbQ4BUK3cgWo, 'user' : Q1siCkTZyw.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : sCHVtMAvqirbQ4BUK3cgWo }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,False,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-1st')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		cookies = UHqibFEGL8fjKhI.cookies
		oL5VwdErqXSmxBcYat9M4J = cookies['ASP.NET_SessionId']
		url = UHqibFEGL8fjKhI.headers['Location']
		rnCzKJiBSsgGhj = { 'id' : ISfWanzRV0GLEpY7e9Tl4FBsv1u , 'user' : Q1siCkTZyw.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : sCHVtMAvqirbQ4BUK3cgWo }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+oL5VwdErqXSmxBcYat9M4J }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,rnCzKJiBSsgGhj,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-2nd')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		url = fNntYJW45mEFSdRX8g.findall('resp":"(http.*?m3u8)(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		B17r2fdFy9ns8tiOMLu = url[0][0]
		FNtoIQygCMwk3emv8h6GKaYdjUAJ0 = url[0][1]
		zz5oBgTvE2aYmCWOdkjKrXFqp8lc = 'http://38.'+smh8Qbf9jH+'777/'+ISfWanzRV0GLEpY7e9Tl4FBsv1u+'_HD.m3u8'+FNtoIQygCMwk3emv8h6GKaYdjUAJ0
		a0HR7ZSnPKJUpuQtGq9jxF8YO6isED = zz5oBgTvE2aYmCWOdkjKrXFqp8lc.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		x9fHXyKkYhQWowNs7zL3086I = zz5oBgTvE2aYmCWOdkjKrXFqp8lc.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		V9TdsglcWYv0X = ['HD','SD1','SD2']
		ss7YGDbuAIxgnqaQroTV = [zz5oBgTvE2aYmCWOdkjKrXFqp8lc,a0HR7ZSnPKJUpuQtGq9jxF8YO6isED,x9fHXyKkYhQWowNs7zL3086I]
		jQLzA92KFEcpw = 0
		if jQLzA92KFEcpw == -1: return
		else: url = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		rnCzKJiBSsgGhj = { 'id' : ISfWanzRV0GLEpY7e9Tl4FBsv1u , 'user' : Q1siCkTZyw.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : qsPRMmI7pHU2Ax4b98GgBTv }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST', gAVl1vUmus8, rnCzKJiBSsgGhj, headers, False,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-3rd')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		url = UHqibFEGL8fjKhI.headers['Location']
		url = url.replace('%20',AAh0X3OCacr4HpifRGLZKT)
		url = url.replace('%3D','=')
		if 'Learn' in ISfWanzRV0GLEpY7e9Tl4FBsv1u:
			url = url.replace('NTNNile',sCHVtMAvqirbQ4BUK3cgWo)
			url = url.replace('learning1','Learning')
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='PL':
		rnCzKJiBSsgGhj = { 'id' : ISfWanzRV0GLEpY7e9Tl4FBsv1u , 'user' : Q1siCkTZyw.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : qsPRMmI7pHU2Ax4b98GgBTv }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST', gAVl1vUmus8, rnCzKJiBSsgGhj, sCHVtMAvqirbQ4BUK3cgWo,False,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-4th')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		url = UHqibFEGL8fjKhI.headers['Location']
		headers = {'Referer':UHqibFEGL8fjKhI.headers['Referer']}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'POST',url, sCHVtMAvqirbQ4BUK3cgWo,headers , sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-5th')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		items = fNntYJW45mEFSdRX8g.findall('source src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		url = items[0]
	elif zVbp6yjdF3qKkTvhDsJX9fgMceCuxt in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='TA': ISfWanzRV0GLEpY7e9Tl4FBsv1u = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		rnCzKJiBSsgGhj = { 'id' : ISfWanzRV0GLEpY7e9Tl4FBsv1u , 'user' : Q1siCkTZyw.AV_CLIENT_IDS , 'function' : 'play'+zVbp6yjdF3qKkTvhDsJX9fgMceCuxt , 'menu' : qsPRMmI7pHU2Ax4b98GgBTv }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'POST',gAVl1vUmus8,rnCzKJiBSsgGhj,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-6th')
		if not UHqibFEGL8fjKhI.succeeded:
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		url = UHqibFEGL8fjKhI.headers['Location']
		if zVbp6yjdF3qKkTvhDsJX9fgMceCuxt=='FM':
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET', url, sCHVtMAvqirbQ4BUK3cgWo, sCHVtMAvqirbQ4BUK3cgWo, False,sCHVtMAvqirbQ4BUK3cgWo,'LIVETV-PLAY-7th')
			url = UHqibFEGL8fjKhI.headers['Location']
			url = url.replace('https','http')
	CeXLtzElr5DHhs(url,Ll1m0nJoaAPvHsXqyRE,'live')
	return
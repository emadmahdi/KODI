# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'GOOGLESEARCH'
Z0BYJQghVL1v87CAem = '_GOS_'
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,qhWpTazQ9ws,T67f3LG49xpP8zcN):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==1010: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1011: ka7jz96YCdTBnQOLVPuJG3285MHf = OV2BJfjtdzRpxQqu(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1012: ka7jz96YCdTBnQOLVPuJG3285MHf = ISVwZeapFX7GKnAN(qhWpTazQ9ws,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1013: ka7jz96YCdTBnQOLVPuJG3285MHf = ssSRfWtjcpeTUwyhqnl0LG()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1014: ka7jz96YCdTBnQOLVPuJG3285MHf = veGrPibpxkSDFtdyCNaE3H1zf(qhWpTazQ9ws,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1015: ka7jz96YCdTBnQOLVPuJG3285MHf = KsNyGSRTCr98WFtHn1(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1016: ka7jz96YCdTBnQOLVPuJG3285MHf = bbI5u2noSp3M(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1018: ka7jz96YCdTBnQOLVPuJG3285MHf = iFjZ32g7fLvm0TNhoEPeVtXInWyu6(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==1019: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(T67f3LG49xpP8zcN,False)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder','بحث جوجل جديد',sCHVtMAvqirbQ4BUK3cgWo,1019)
	XAozRfZ68H9x2OsiP3LmIaql1('link','كيف يعمل بحث جوجل','',1013)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'==== كلمات البحث المخزنة ===='+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	mCB7EzlZ8fqUdGLoODPcyYAwF = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if mCB7EzlZ8fqUdGLoODPcyYAwF:
		mCB7EzlZ8fqUdGLoODPcyYAwF = mCB7EzlZ8fqUdGLoODPcyYAwF['__SEQUENCED_COLUMNS__']
		for W7jZKBiSIo0shrXl4y9pFT in reversed(mCB7EzlZ8fqUdGLoODPcyYAwF):
			XAozRfZ68H9x2OsiP3LmIaql1('folder',W7jZKBiSIo0shrXl4y9pFT,sCHVtMAvqirbQ4BUK3cgWo,1019,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,W7jZKBiSIo0shrXl4y9pFT)
	return
def iFjZ32g7fLvm0TNhoEPeVtXInWyu6(search):
	RsxrGI1pcyY3UXTSLiC(search,True)
	Ims96cLXkvKOx0GD(lvzrYTpcBaK)
	return
def RsxrGI1pcyY3UXTSLiC(search,mgSYo15edfJrq3ZVp9uvWy=False):
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	P9YiS4ysOIjdLz2C = search.replace(Z0BYJQghVL1v87CAem,sCHVtMAvqirbQ4BUK3cgWo).lower()
	NpRf15tcU8KX,KdhTyezCauncW,UE64zxksZFtGjrJAvX = [],[],[]
	if not mgSYo15edfJrq3ZVp9uvWy:
		NpRf15tcU8KX = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GOOGLESEARCH_RESULTS',P9YiS4ysOIjdLz2C)
		if NpRf15tcU8KX: KdhTyezCauncW,UE64zxksZFtGjrJAvX = NpRf15tcU8KX
	if mgSYo15edfJrq3ZVp9uvWy or not NpRf15tcU8KX:
		import PG9FRcxAEz
		PG9FRcxAEz.KQIGDxw2ZMJBmkT6iLyj0(P9YiS4ysOIjdLz2C,'_GOOGLE',True)
		sCktdRiMHJK7L = cjxCBNwXKkYgI0zdFO(P9YiS4ysOIjdLz2C)
		for UqKgalXPCz7eQAL08foMx1R in sCktdRiMHJK7L:
			name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 = UqKgalXPCz7eQAL08foMx1R
			if oT2iHwjfBx0FPX5ZCph9aWs38 in ccehpQ8jEwfV1garCtYiOHS6PzqKyk: KdhTyezCauncW.append(UqKgalXPCz7eQAL08foMx1R)
			else: UE64zxksZFtGjrJAvX.append(UqKgalXPCz7eQAL08foMx1R)
		KdhTyezCauncW = sorted(KdhTyezCauncW,reverse=lvzrYTpcBaK,key=lambda key: key[BewrUo9ANCa17G43Sn0LH5xh])
		UE64zxksZFtGjrJAvX = sorted(UE64zxksZFtGjrJAvX,reverse=lvzrYTpcBaK,key=lambda key: key[BewrUo9ANCa17G43Sn0LH5xh])
		kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'GOOGLESEARCH_RESULTS',P9YiS4ysOIjdLz2C,[KdhTyezCauncW,UE64zxksZFtGjrJAvX],gQtzWRX97wZHiJ)
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DETAILED_GOOGLE',P9YiS4ysOIjdLz2C)
		PG9FRcxAEz.KQIGDxw2ZMJBmkT6iLyj0(P9YiS4ysOIjdLz2C,'_GOOGLE',False)
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+P9YiS4ysOIjdLz2C+"')")
		if KdhTyezCauncW: ZZDswXvceNFRhafpUtWELYCP('','',OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(KdhTyezCauncW))+'  مواقع')
		else: KdhTyezCauncW,UE64zxksZFtGjrJAvX = J0gjdsAnzZB(P9YiS4ysOIjdLz2C,lvzrYTpcBaK)
	XAozRfZ68H9x2OsiP3LmIaql1('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','بحث منفرد لمواقع جوجل',sCHVtMAvqirbQ4BUK3cgWo,1011,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','نتائج البحث مفصلة - '+P9YiS4ysOIjdLz2C,'opened_sites_google',1012,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','نتائج البحث مقسمة - '+P9YiS4ysOIjdLz2C,'listed_sites_google',1012,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','مواقع جوجل ('+str(len(KdhTyezCauncW))+') - '+P9YiS4ysOIjdLz2C,'',1016,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('link','إعادة بحث جوجل - '+P9YiS4ysOIjdLz2C,'',1018,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,search)
	return
def bbI5u2noSp3M(P9YiS4ysOIjdLz2C):
	KdhTyezCauncW,UE64zxksZFtGjrJAvX = J0gjdsAnzZB(P9YiS4ysOIjdLz2C)
	if not KdhTyezCauncW and not UE64zxksZFtGjrJAvX: return
	xZr3kGjw7MJc8nhPpi24Ff15IOXymK = {}
	for name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 in KdhTyezCauncW: xZr3kGjw7MJc8nhPpi24Ff15IOXymK[oT2iHwjfBx0FPX5ZCph9aWs38] = name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38
	ZBlesVYJcG = list(xZr3kGjw7MJc8nhPpi24Ff15IOXymK.keys())
	import PG9FRcxAEz
	LWMxiQoXg6vsFT1AK = PG9FRcxAEz.zATVmaxnLvJf6E5So9cFNB(ZBlesVYJcG)
	for oT2iHwjfBx0FPX5ZCph9aWs38 in LWMxiQoXg6vsFT1AK:
		if isinstance(oT2iHwjfBx0FPX5ZCph9aWs38,tuple):
			Q1siCkTZyw.menuItemsLIST.append(oT2iHwjfBx0FPX5ZCph9aWs38)
			continue
		name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 = xZr3kGjw7MJc8nhPpi24Ff15IOXymK[oT2iHwjfBx0FPX5ZCph9aWs38]
		lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',o0wDANXvUE7fS2Z+name,B17r2fdFy9ns8tiOMLu,1014,j26eY4gCXa7A5inTklZdB8IpWmfvt,'',oT2iHwjfBx0FPX5ZCph9aWs38)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'مواقع بجوجل غير موجودة بالبرنامج'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,1015)
	UE64zxksZFtGjrJAvX = sorted(UE64zxksZFtGjrJAvX,reverse=lvzrYTpcBaK,key=lambda key: key[BewrUo9ANCa17G43Sn0LH5xh])
	for name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 in UE64zxksZFtGjrJAvX:
		XAozRfZ68H9x2OsiP3LmIaql1('link','_GOS_'+name,B17r2fdFy9ns8tiOMLu,1015,j26eY4gCXa7A5inTklZdB8IpWmfvt,'',oT2iHwjfBx0FPX5ZCph9aWs38)
	return
def J0gjdsAnzZB(P9YiS4ysOIjdLz2C,qZtRjimVkrx7GeUdWYOJuNn9X2=ndkUxG9LtewJ):
	KdhTyezCauncW,UE64zxksZFtGjrJAvX = [],[]
	if qZtRjimVkrx7GeUdWYOJuNn9X2:
		NpRf15tcU8KX = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GOOGLESEARCH_RESULTS',P9YiS4ysOIjdLz2C)
		if NpRf15tcU8KX: KdhTyezCauncW,UE64zxksZFtGjrJAvX = NpRf15tcU8KX
	if not KdhTyezCauncW and not UE64zxksZFtGjrJAvX: ZZDswXvceNFRhafpUtWELYCP('','',OODdgcrlh8KQo0A7M2eEvViwPqpkR,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return KdhTyezCauncW,UE64zxksZFtGjrJAvX
def ISVwZeapFX7GKnAN(XMygx0kDvOtKWn6I,P9YiS4ysOIjdLz2C):
	KdhTyezCauncW,UE64zxksZFtGjrJAvX = J0gjdsAnzZB(P9YiS4ysOIjdLz2C)
	if not KdhTyezCauncW and not UE64zxksZFtGjrJAvX: return
	hZGq82NwEUYsPvypJxi3T,qfGBisy5dR8N0pcQuTHo = [],{}
	for name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 in KdhTyezCauncW:
		hZGq82NwEUYsPvypJxi3T.append(oT2iHwjfBx0FPX5ZCph9aWs38)
		qfGBisy5dR8N0pcQuTHo[oT2iHwjfBx0FPX5ZCph9aWs38] = w9w6xmqI2RNnbtQ8oBd7zTMYJfWHpF(text)
	import PG9FRcxAEz
	PG9FRcxAEz.WceYBZH6GpR(P9YiS4ysOIjdLz2C,XMygx0kDvOtKWn6I,sCHVtMAvqirbQ4BUK3cgWo,hZGq82NwEUYsPvypJxi3T,qfGBisy5dR8N0pcQuTHo)
	return
def OV2BJfjtdzRpxQqu(P9YiS4ysOIjdLz2C):
	KdhTyezCauncW,UE64zxksZFtGjrJAvX = J0gjdsAnzZB(P9YiS4ysOIjdLz2C)
	if not KdhTyezCauncW and not UE64zxksZFtGjrJAvX: return
	xZr3kGjw7MJc8nhPpi24Ff15IOXymK = {}
	for name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 in KdhTyezCauncW:
		xZr3kGjw7MJc8nhPpi24Ff15IOXymK[oT2iHwjfBx0FPX5ZCph9aWs38] = name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38
	ZBlesVYJcG = list(xZr3kGjw7MJc8nhPpi24Ff15IOXymK.keys())
	import PG9FRcxAEz
	LWMxiQoXg6vsFT1AK = PG9FRcxAEz.zATVmaxnLvJf6E5So9cFNB(ZBlesVYJcG)
	for oT2iHwjfBx0FPX5ZCph9aWs38 in LWMxiQoXg6vsFT1AK:
		if isinstance(oT2iHwjfBx0FPX5ZCph9aWs38,tuple):
			Q1siCkTZyw.menuItemsLIST.append(oT2iHwjfBx0FPX5ZCph9aWs38)
			continue
		name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38 = xZr3kGjw7MJc8nhPpi24Ff15IOXymK[oT2iHwjfBx0FPX5ZCph9aWs38]
		lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
		text = w9w6xmqI2RNnbtQ8oBd7zTMYJfWHpF(text)
		name = name+' - '+P9YiS4ysOIjdLz2C
		XAozRfZ68H9x2OsiP3LmIaql1('folder',o0wDANXvUE7fS2Z+name,oT2iHwjfBx0FPX5ZCph9aWs38,548,j26eY4gCXa7A5inTklZdB8IpWmfvt,'',text)
	return
def w9w6xmqI2RNnbtQ8oBd7zTMYJfWHpF(title):
	bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة)',title,fNntYJW45mEFSdRX8g.DOTALL)
	dwDUvp0LAuyg1rI = bbFPOJrmkCaE6ul37XiKU[0][0] if bbFPOJrmkCaE6ul37XiKU else title
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	dwDUvp0LAuyg1rI = dwDUvp0LAuyg1rI.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return dwDUvp0LAuyg1rI
def cjxCBNwXKkYgI0zdFO(search):
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	vrEJRkchKxtDNiqO1b79mL5eT = url+'&start=0&num=100&tbm=vid&udm=7'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'GOOGLESEARCH-SEARCH-1st')
	if not UHqibFEGL8fjKhI.succeeded: return []
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	TE62cNnYeBLgGxpmt5r1DS04o = YYEXZsUWhf52vz7HLxc0qGJ.path.join(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,'googlesearch')
	if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(TE62cNnYeBLgGxpmt5r1DS04o):
		try: YYEXZsUWhf52vz7HLxc0qGJ.makedirs(TE62cNnYeBLgGxpmt5r1DS04o)
		except: pass
	items = []
	Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if Jae64ky3REO57A2MvVHB90:
		for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
			B17r2fdFy9ns8tiOMLu,title,text,Qp3jGv8leCbuiEU5Im,name = Po9h3gWFuLR2
			Qp3jGv8leCbuiEU5Im = ''
			items.append([B17r2fdFy9ns8tiOMLu,title,text,name,Qp3jGv8leCbuiEU5Im])
	else:
		vrEJRkchKxtDNiqO1b79mL5eT = url+'&start=0&num=200'
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET::SCRAPERS',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'GOOGLESEARCH-SEARCH-2nd')
		if not UHqibFEGL8fjKhI.succeeded: return []
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not Jae64ky3REO57A2MvVHB90: Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
			Po9h3gWFuLR2 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('list',Po9h3gWFuLR2)
			if len(Po9h3gWFuLR2)>17:
				B17r2fdFy9ns8tiOMLu = Po9h3gWFuLR2[17]
				title,text,name,Qp3jGv8leCbuiEU5Im = Po9h3gWFuLR2[31][0:4]
				items.append([B17r2fdFy9ns8tiOMLu,title,text,name,Qp3jGv8leCbuiEU5Im])
	RsZrTL8Up1v0,QAcGtHariDqlWx13ChERmnPFT8j = [],[]
	for UqKgalXPCz7eQAL08foMx1R in items:
		B17r2fdFy9ns8tiOMLu,title,text,name,Qp3jGv8leCbuiEU5Im = UqKgalXPCz7eQAL08foMx1R
		name = name.strip(' ')
		if not name: name = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
		name = ij3WwceDrmqafJy6Lsx4S9GCFuP(name)
		if 'http://' in Qp3jGv8leCbuiEU5Im or 'https://' in Qp3jGv8leCbuiEU5Im: j26eY4gCXa7A5inTklZdB8IpWmfvt = Qp3jGv8leCbuiEU5Im
		elif 'data:image/' in Qp3jGv8leCbuiEU5Im and ';base64,' in Qp3jGv8leCbuiEU5Im:
			qgDQszAK6uSGajEowHUFhyYV = fNntYJW45mEFSdRX8g.findall('data:image/(\w+);base64,',Qp3jGv8leCbuiEU5Im)
			qgDQszAK6uSGajEowHUFhyYV = qgDQszAK6uSGajEowHUFhyYV[0]
			j26eY4gCXa7A5inTklZdB8IpWmfvt = YYEXZsUWhf52vz7HLxc0qGJ.path.join(TE62cNnYeBLgGxpmt5r1DS04o,name+'.'+qgDQszAK6uSGajEowHUFhyYV)
			if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(j26eY4gCXa7A5inTklZdB8IpWmfvt):
				Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.replace('\\u003d','=')
				Qp3jGv8leCbuiEU5Im = Qp3jGv8leCbuiEU5Im.replace('data:image/'+qgDQszAK6uSGajEowHUFhyYV+';base64,','')
				WKJNpYfOylvAxRX3m96HCLon8MIrz = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(Qp3jGv8leCbuiEU5Im)
				open(j26eY4gCXa7A5inTklZdB8IpWmfvt,'wb').write(WKJNpYfOylvAxRX3m96HCLon8MIrz)
		else: j26eY4gCXa7A5inTklZdB8IpWmfvt = ''
		oT2iHwjfBx0FPX5ZCph9aWs38 = tyY0Hj7cQJ(name,B17r2fdFy9ns8tiOMLu)
		if oT2iHwjfBx0FPX5ZCph9aWs38 not in QAcGtHariDqlWx13ChERmnPFT8j:
			QAcGtHariDqlWx13ChERmnPFT8j.append(oT2iHwjfBx0FPX5ZCph9aWs38)
			name = g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38)
			RsZrTL8Up1v0.append([name,B17r2fdFy9ns8tiOMLu,title,text,j26eY4gCXa7A5inTklZdB8IpWmfvt,oT2iHwjfBx0FPX5ZCph9aWs38])
	return RsZrTL8Up1v0
def veGrPibpxkSDFtdyCNaE3H1zf(B17r2fdFy9ns8tiOMLu,oT2iHwjfBx0FPX5ZCph9aWs38):
	lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
	if o0wDANXvUE7fS2Z: lDt71RPxgnZs0LzHurJAdqU()
	else: KsNyGSRTCr98WFtHn1()
	return
def ssSRfWtjcpeTUwyhqnl0LG():
	ZZDswXvceNFRhafpUtWELYCP('','',OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def KsNyGSRTCr98WFtHn1(oT2iHwjfBx0FPX5ZCph9aWs38=''):
	ZZDswXvceNFRhafpUtWELYCP('','',oT2iHwjfBx0FPX5ZCph9aWs38,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def tyY0Hj7cQJ(name,B17r2fdFy9ns8tiOMLu):
	GDAV6Cab9PvLIteM7Y5r84 = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	XXqGLnKo8vWYh1IMz9C0 = name.lower()
	YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = ''
	for key in list(GDAV6Cab9PvLIteM7Y5r84.keys()):
		if key.lower() in XXqGLnKo8vWYh1IMz9C0: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = GDAV6Cab9PvLIteM7Y5r84[key]
	if not YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z:
		NroHCBWaxUZOfbgqMzAL4vJ2 = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'url')
		for oT2iHwjfBx0FPX5ZCph9aWs38 in list(Q1siCkTZyw.SITESURLS.keys()):
			ToVLNn7B1MsY9dzjpgkW = GABnmSFOwtsu37(Q1siCkTZyw.SITESURLS[oT2iHwjfBx0FPX5ZCph9aWs38][0],'url')
			if NroHCBWaxUZOfbgqMzAL4vJ2==ToVLNn7B1MsY9dzjpgkW: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = oT2iHwjfBx0FPX5ZCph9aWs38
	if not YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z:
		XXqGLnKo8vWYh1IMz9C0 = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
		for oT2iHwjfBx0FPX5ZCph9aWs38 in list(Q1siCkTZyw.SITESURLS.keys()):
			oTdCnO9jtL5VfFi7UlhJIgk = GABnmSFOwtsu37(Q1siCkTZyw.SITESURLS[oT2iHwjfBx0FPX5ZCph9aWs38][0],'name')
			if XXqGLnKo8vWYh1IMz9C0==oTdCnO9jtL5VfFi7UlhJIgk: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = oT2iHwjfBx0FPX5ZCph9aWs38
	if not YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = name
	YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z.upper()
	return YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z
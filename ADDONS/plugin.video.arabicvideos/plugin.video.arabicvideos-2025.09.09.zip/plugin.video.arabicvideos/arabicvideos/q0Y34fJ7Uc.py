# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHOFHA'
Z0BYJQghVL1v87CAem = '_SHT_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==640: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==641: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==642: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==644: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==645: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==649: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,649,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المميزة',gAVl1vUmus8,641,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'جديد الموقع',gAVl1vUmus8+'/newvideos.php',641,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"navslide-divider"></div>(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,644)
	return
def ffy5vVCNau6FWgbmp(url):
	qqfsNGJplK = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"presentation"','</ul>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [(sCHVtMAvqirbQ4BUK3cgWo,Po9h3gWFuLR2)]
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' فرز أو فلتر أو ترتيب '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for J8noyr10GLB9exORpmSIHTWiFPc,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			qqfsNGJplK = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if J8noyr10GLB9exORpmSIHTWiFPc: J8noyr10GLB9exORpmSIHTWiFPc = J8noyr10GLB9exORpmSIHTWiFPc+': '
			for B17r2fdFy9ns8tiOMLu,title in qqfsNGJplK:
				title = J8noyr10GLB9exORpmSIHTWiFPc+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,641)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"pm-category-subcats"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(Y0WVJ5CTpDO)<30:
			if qqfsNGJplK: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,641)
	if not GzRKsiw5PBIe1NlrqmQy9STx and not iUtXlDhSVoBZJrPTQAwcER9nfMkN: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-TITLES-1st')
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-TITLES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Po9h3gWFuLR2,items = sCHVtMAvqirbQ4BUK3cgWo,[]
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	elif n1WYDtVC8dRHbXJkMa=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-video-watch-featured"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_episodes':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if len(oPnz7Zt4xLHTwR)>1: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
	elif n1WYDtVC8dRHbXJkMa=='featured_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(data-echo=".*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if Po9h3gWFuLR2 and not items: items = fNntYJW45mEFSdRX8g.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: return
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,642,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif n1WYDtVC8dRHbXJkMa=='new_episodes':
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,642,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,645,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,645,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if 1:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,641)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"image" content="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[0] if Qp3jGv8leCbuiEU5Im else sCHVtMAvqirbQ4BUK3cgWo
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"AiredEPS"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)</em>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.replace('</span><em>',AAh0X3OCacr4HpifRGLZKT)
			if qdUK5ioJyrO1T: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,642,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV,CChFzu9SVf5UT4paLAKtEmJj,cb1fAztguv78n9LGhSWJFm5p = [],[],[]
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/watch.php','/view.php') if '/watch.php' in url else url
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOFHA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if 'embedded-video' in Sw0pOFoVhPeIxbl:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"embedded-video"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if PXFtqmw5lBGQNa0IV8:
				B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[0]
				if B17r2fdFy9ns8tiOMLu not in ss7YGDbuAIxgnqaQroTV:
					CChFzu9SVf5UT4paLAKtEmJj.append('?named=__embed')
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if 'WatchServers' in Sw0pOFoVhPeIxbl:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"WatchServers"(.*?)</script>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			ddB7cunzbmtoMLW0 = fNntYJW45mEFSdRX8g.findall('id="(.*?)".*?</span>(.*?)</button>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('\\"','"').replace('\/','/')
			PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('"<iframe.src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if len(ddB7cunzbmtoMLW0)==len(PXFtqmw5lBGQNa0IV8):
				for id,title in ddB7cunzbmtoMLW0:
					B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[int(id)]
					if B17r2fdFy9ns8tiOMLu not in ss7YGDbuAIxgnqaQroTV:
						CChFzu9SVf5UT4paLAKtEmJj.append('?named='+title+'__watch')
						ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if 'DownloadServer' in Sw0pOFoVhPeIxbl:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"DownloadServer"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if not PXFtqmw5lBGQNa0IV8: PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
			for B17r2fdFy9ns8tiOMLu,title in PXFtqmw5lBGQNa0IV8:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
				if B17r2fdFy9ns8tiOMLu not in ss7YGDbuAIxgnqaQroTV:
					CChFzu9SVf5UT4paLAKtEmJj.append('?named='+title+'__download')
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	icYBfzVeQunoDOv2w08dKl = zip(ss7YGDbuAIxgnqaQroTV,CChFzu9SVf5UT4paLAKtEmJj)
	for B17r2fdFy9ns8tiOMLu,name in icYBfzVeQunoDOv2w08dKl: cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+name)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/search.php?keywords='+search
	fs7D0d3QyAT(url,'search')
	return
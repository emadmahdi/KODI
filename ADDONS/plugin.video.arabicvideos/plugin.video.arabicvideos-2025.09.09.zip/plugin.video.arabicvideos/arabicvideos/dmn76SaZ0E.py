# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FAJERSHOW'
Z0BYJQghVL1v87CAem = '_FJS_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==390: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==391: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==392: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==393: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==399: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,399,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FAJERSHOW-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall('<header>.*?<h2>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for nkjHK2zQeb4vBuoaxPZTqIALW5S1 in range(len(items)):
		title = items[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,gAVl1vUmus8,391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'latest'+str(nkjHK2zQeb4vBuoaxPZTqIALW5S1))
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مختارات عشوائية',gAVl1vUmus8,391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'randoms')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أعلى الأفلام تقييماً',gAVl1vUmus8,391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'top_imdb_movies')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أعلى المسلسلات تقييماً',gAVl1vUmus8,391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'top_imdb_series')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أفلام مميزة',gAVl1vUmus8+'/movies',391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured_movies')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مسلسلات مميزة',gAVl1vUmus8+'/tvshows',391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured_tvshows')
	Po9h3gWFuLR2 = sCHVtMAvqirbQ4BUK3cgWo
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="menu"(.*?)id="contenedor"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 += oPnz7Zt4xLHTwR[0]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8+'/movies',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FAJERSHOW-MENU-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="releases"(.*?)aside',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 += oPnz7Zt4xLHTwR[0]
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	trd5bZgxTR = True
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		if title=='الأعلى مشاهدة':
			if trd5bZgxTR:
				title = 'الافلام '+title
				trd5bZgxTR = False
			else: title = 'المسلسلات '+title
		if title not in MqARWHDkmiT4nlz:
			if title=='أفلام': XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,gAVl1vUmus8+'/movies',391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'all_movies_tvshows')
			elif title=='مسلسلات': XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,gAVl1vUmus8+'/tvshows',391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'all_movies_tvshows')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,391)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,type):
	Po9h3gWFuLR2,items = [],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FAJERSHOW-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if type in ['featured_movies','featured_tvshows']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="content"(.*?)id="archive-content"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif type=='all_movies_tvshows':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="archive-content"(.*?)class="pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif type=='top_imdb_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='top_imdb_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("class='top-imdb-list tright(.*?)footer",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='search':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="search-page"(.*?)class="sidebar',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='sider':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="widget(.*?)class="widget',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		icYBfzVeQunoDOv2w08dKl = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		ss7YGDbuAIxgnqaQroTV,T3bQnXl7ZSaYLiC8FR0PIWqOB,V9TdsglcWYv0X = zip(*icYBfzVeQunoDOv2w08dKl)
		items = zip(T3bQnXl7ZSaYLiC8FR0PIWqOB,ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X)
	elif type=='randoms':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="slider-movies-tvshows"(.*?)<header>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif 'latest' in type:
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = int(type[-1:])
		Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('<header>','<end><start>')
		Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('</div></div></div>','</div></div></div><end>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<start>(.*?)<end>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
		if nkjHK2zQeb4vBuoaxPZTqIALW5S1==6:
			icYBfzVeQunoDOv2w08dKl = fNntYJW45mEFSdRX8g.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			T3bQnXl7ZSaYLiC8FR0PIWqOB,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = zip(*icYBfzVeQunoDOv2w08dKl)
			items = zip(T3bQnXl7ZSaYLiC8FR0PIWqOB,ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="content"(.*?)class="(pagination|sidebar)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0][0]
			if '/collection/' in url:
				items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			elif '/quality/' in url:
				items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items and Po9h3gWFuLR2:
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = fNntYJW45mEFSdRX8g.findall('^(.*?)<.*?serie">(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
			title = title[0][1]
			if title in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ: continue
			AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			title = '_MOD_'+title
		dwDUvp0LAuyg1rI = fNntYJW45mEFSdRX8g.findall('^(.*?)<',title,fNntYJW45mEFSdRX8g.DOTALL)
		if dwDUvp0LAuyg1rI: title = dwDUvp0LAuyg1rI[0]
		title = tt36wUe4HTPFmfs5hcbr(title)
		if '/tvshows/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,393,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/episodes/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,393,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/seasons/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,393,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/collection/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,391,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,392,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if type not in ['featured_movies','featured_tvshows']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,391,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	return
def VzOBjnIkZSH7ft(url):
	smh8Qbf9jH = GABnmSFOwtsu37(url,'url')
	url = url.replace(smh8Qbf9jH,gAVl1vUmus8)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FAJERSHOW-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('class="C rated".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,392,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	Sw0pOFoVhPeIxbl = oi4MGF01PsQtfzAqNYreVa8yE(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FAJERSHOW-PLAY-1st')
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('class="C rated".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	ss7YGDbuAIxgnqaQroTV = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0][0]
		items = fNntYJW45mEFSdRX8g.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for type,sYTMXCn5AG0KR3E9SUO,CdjZazNV5lpTbi2HYU4RKGI,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+sYTMXCn5AG0KR3E9SUO+'&nume='+CdjZazNV5lpTbi2HYU4RKGI+'&type='+type
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA,TTtDQFAY086Gop1WbuXsHJkwxU in items:
			if '=' in Mx0TQvmZAsedaGj4opVDJu5by8RUwS:
				fznBtNGxTDEmI = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.split('=')[1]
				title = GABnmSFOwtsu37(fznBtNGxTDEmI,'host')
			else: title = sCHVtMAvqirbQ4BUK3cgWo
			title = TTtDQFAY086Gop1WbuXsHJkwxU+AAh0X3OCacr4HpifRGLZKT+title
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download____'+XO7Zr2W6kwieA
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url,'search')
	return
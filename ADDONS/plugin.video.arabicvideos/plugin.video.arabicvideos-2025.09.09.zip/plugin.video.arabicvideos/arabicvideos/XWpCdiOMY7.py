# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ALMSTBA'
Z0BYJQghVL1v87CAem = '_MST_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الرئيسية','يلا شوت']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==860: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==861: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==862: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==863: ka7jz96YCdTBnQOLVPuJG3285MHf = E5mTvMgjPFJKs1noB7we8i(url,text)
	elif mode==869: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8+'/indx1/',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,869,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"primary-links"(.*?)</u',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,861)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"list-categories"(.*?)<script',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu.lstrip('/')
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,861)
	return
def fs7D0d3QyAT(url,Ffh8yTQ3d6sp=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-content"(.*?)"footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"overlay"','"duration"><')
		items = fNntYJW45mEFSdRX8g.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(' ')
			title = tt36wUe4HTPFmfs5hcbr(title)
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if 'episodes' not in Ffh8yTQ3d6sp and bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
				title = title.replace('اون لاين',sCHVtMAvqirbQ4BUK3cgWo)
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,863,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,862,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''["']pagination["'](.*?)["']footer["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Ffh8yTQ3d6sp = 'episodes_pages' if 'episodes' in Ffh8yTQ3d6sp else 'pages'
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,861,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Ffh8yTQ3d6sp)
	else:
		BKaELMnQSX8NmuFl2fHD = fNntYJW45mEFSdRX8g.findall('class="pagination__next.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if BKaELMnQSX8NmuFl2fHD:
			B17r2fdFy9ns8tiOMLu = BKaELMnQSX8NmuFl2fHD[0]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة لاحقة',B17r2fdFy9ns8tiOMLu,861,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Ffh8yTQ3d6sp)
	return
def E5mTvMgjPFJKs1noB7we8i(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-EPISODES_SEASONS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"episodes-container"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"thumbnailUrl":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[0] if Qp3jGv8leCbuiEU5Im else sCHVtMAvqirbQ4BUK3cgWo
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.replace('\/','/')
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS += '|Referer='+gAVl1vUmus8
	items = []
	irDX4SOHZKIaLUvhyjCbx0T = False
	if GzRKsiw5PBIe1NlrqmQy9STx and not Obes76wjH9LRyEqc2NWPTSphZz34K:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('data-tab="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Obes76wjH9LRyEqc2NWPTSphZz34K,title in items:
			Obes76wjH9LRyEqc2NWPTSphZz34K = Obes76wjH9LRyEqc2NWPTSphZz34K.strip('#')
			if len(items)>1: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,863,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,Obes76wjH9LRyEqc2NWPTSphZz34K)
			else: irDX4SOHZKIaLUvhyjCbx0T = True
	else: irDX4SOHZKIaLUvhyjCbx0T = True
	if irDX4SOHZKIaLUvhyjCbx0T or not Obes76wjH9LRyEqc2NWPTSphZz34K:
		if not Obes76wjH9LRyEqc2NWPTSphZz34K: iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"tab-content.*?id="(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		else: iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"tab-content.*?id="'+Obes76wjH9LRyEqc2NWPTSphZz34K+'"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
			Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('./')
				title = title.replace('</em><span>',AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,862,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p,GQkoWhXOlsSVIp0Z = [],[]
	vrEJRkchKxtDNiqO1b79mL5eT = url.strip('/')+'/?do=watch'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('iframe src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-PLAY-2nd')
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		NroHCBWaxUZOfbgqMzAL4vJ2 = fNntYJW45mEFSdRX8g.findall('iframe src="(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		NroHCBWaxUZOfbgqMzAL4vJ2 = NroHCBWaxUZOfbgqMzAL4vJ2[0] if NroHCBWaxUZOfbgqMzAL4vJ2 else B17r2fdFy9ns8tiOMLu
		NroHCBWaxUZOfbgqMzAL4vJ2 = tt36wUe4HTPFmfs5hcbr(NroHCBWaxUZOfbgqMzAL4vJ2)
		if NroHCBWaxUZOfbgqMzAL4vJ2 not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(NroHCBWaxUZOfbgqMzAL4vJ2)
			smh8Qbf9jH = GABnmSFOwtsu37(NroHCBWaxUZOfbgqMzAL4vJ2,'name')
			NroHCBWaxUZOfbgqMzAL4vJ2 = NroHCBWaxUZOfbgqMzAL4vJ2+'?named='+smh8Qbf9jH+'__embed'
			cb1fAztguv78n9LGhSWJFm5p.append(NroHCBWaxUZOfbgqMzAL4vJ2)
	headers = {'Referer':url}
	SSyNiGLhxRXH1TzFW3DPw = fNntYJW45mEFSdRX8g.findall('post_id:(\d+)',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	d1Y4gxcA7sQk3 = gAVl1vUmus8+'/wp-admin/admin-ajax.php?action=video_info&post_id='+SSyNiGLhxRXH1TzFW3DPw[0]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',d1Y4gxcA7sQk3,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMSTBA-PLAY-3rd')
	ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"src":"(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('\/','/')
		if B17r2fdFy9ns8tiOMLu not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
			smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__watch'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"Download" target="_blank" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		if B17r2fdFy9ns8tiOMLu not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
			smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'name')
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__download'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url,'search')
	return
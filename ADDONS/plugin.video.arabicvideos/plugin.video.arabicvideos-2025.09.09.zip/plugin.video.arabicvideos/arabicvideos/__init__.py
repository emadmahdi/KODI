# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from nd6qWvh3Ve import *
Ll1m0nJoaAPvHsXqyRE = oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡋࡑࡍ࡙࠭ኋ")
LL95FhrBQvbuSXsneAiCq = EJgYdjbIiWe1apkQlZcR42(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩኌ")
ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
kkJoBAxwN3VrDH = int(GLrDUZJWtdSzaoeQNfw)
c4yVMkzYb0 = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel(GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫኍ"))
c4yVMkzYb0 = c4yVMkzYb0.replace(t0ozNJUhjCVgRmMp89KGaWvfl3AS,sCHVtMAvqirbQ4BUK3cgWo).replace(aU23gVSeZ8QMl,sCHVtMAvqirbQ4BUK3cgWo)
if kkJoBAxwN3VrDH==bGzRdmOErkIylxALniq6(u"࠸࠶࠱ኳ"): SxL7M413qgT8JldEKb = aenpKvQCGVzhLXEdWiDIZ(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ኎")+WHzJr591Ka8gRdbiLmBp0hT3S+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬ኏")+LLt0mXJQ1Frlou9CT2g86YGNqKz+SIkwCEdJHTD9v1(u"࠭ࠠ࡞ࠩነ")
else:
	rXuE2yFODenNismaCIKgf5L7hVtx = mSeoVfgRpNF9PKrJ(ERbOfw2FjKUAZGo).replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo)
	rXuE2yFODenNismaCIKgf5L7hVtx = rXuE2yFODenNismaCIKgf5L7hVtx.replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
	rXuE2yFODenNismaCIKgf5L7hVtx = rXuE2yFODenNismaCIKgf5L7hVtx.replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	SxL7M413qgT8JldEKb = TzIj50KpohEOHx6CbZWqB(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭ኑ")+c4yVMkzYb0+TzIj50KpohEOHx6CbZWqB(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨኒ")+GLrDUZJWtdSzaoeQNfw+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩና")+rXuE2yFODenNismaCIKgf5L7hVtx+qqw1upCsKM(u"ࠪࠤࡢ࠭ኔ")
SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,LL95FhrBQvbuSXsneAiCq+slFfrUIWCowaBA7tce3iZbj8xn+JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+SxL7M413qgT8JldEKb)
if SE97R3Dpj6dPLweVKU(u"ࠫࡤ࠭ን") in IFYonX8LZUfz3VJyuQlxgE: cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA = IFYonX8LZUfz3VJyuQlxgE.split(RDwahqjPfbdyEiTtnLQu(u"ࠬࡥࠧኖ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
else: cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA = IFYonX8LZUfz3VJyuQlxgE,sCHVtMAvqirbQ4BUK3cgWo
Q1siCkTZyw.H2heYqoNSfBbcLRGiUsWDZnAEIgJ7j,Ro2CsQFGOj14wKIgcuHJ = lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo
if cwnGP8Qo6h in [phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࠱ࠨኗ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ࠳ࠩኘ"),qqw1upCsKM(u"ࠨ࠵ࠪኙ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࠷ࠫኚ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪ࠹ࠬኛ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࠶࠷ࠧኜ"),bGzRdmOErkIylxALniq6(u"ࠬ࠷࠲ࠨኝ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࠱࠴ࠩኞ")] and (SIkwCEdJHTD9v1(u"ࠧࡂࡆࡇࠫኟ") in T5Teu1pJhvEmgkcn7OoA or XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡔࡈࡑࡔ࡜ࡅࠨአ") in T5Teu1pJhvEmgkcn7OoA or Js61GTdX5wzMurUqi7Z(u"ࠩࡘࡔࠬኡ") in T5Teu1pJhvEmgkcn7OoA or YQNd4wejLSAVJ6T(u"ࠪࡈࡔ࡝ࡎࠨኢ") in T5Teu1pJhvEmgkcn7OoA):
	from gRQYBo5zxp import xlatCDi92hr0nNjVqgcSvp84
	xlatCDi92hr0nNjVqgcSvp84(IFYonX8LZUfz3VJyuQlxgE,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(jwzOabysh0Z(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨኣ"),ERbOfw2FjKUAZGo)
	Q1siCkTZyw.H2heYqoNSfBbcLRGiUsWDZnAEIgJ7j = ndkUxG9LtewJ
elif not GsowyWv4QneEtJ and kkJoBAxwN3VrDH in [jwzOabysh0Z(u"࠲࠴࠷ኴ"),Js61GTdX5wzMurUqi7Z(u"࠸࠳࠸ኵ")]:
	J26JEXNRtmOrlj8qhesLYI0dKpQ = str(ZQC69Pyo4BOamJlwSLtAWINg7q[qqw1upCsKM(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኤ")])
	Ll1m0nJoaAPvHsXqyRE = GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡉࡑࡖ࡙ࠫእ") if kkJoBAxwN3VrDH==aYH620Dh48GEsTFfOBSQ7r(u"࠴࠶࠹኶") else fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡎ࠵ࡘࠫኦ")
	byMFpR6TYN4miKoxnt = Ll1m0nJoaAPvHsXqyRE.lower()
	MMKTiky7N3vVPdx6GIzHFOf2Yjq = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡣࡹ࠲ࠬኧ")+byMFpR6TYN4miKoxnt+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧከ")+J26JEXNRtmOrlj8qhesLYI0dKpQ)
	jcZbnfXTDoymgClJqYiABS = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(SE97R3Dpj6dPLweVKU(u"ࠪࡥࡻ࠴ࠧኩ")+byMFpR6TYN4miKoxnt+bGzRdmOErkIylxALniq6(u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧኪ")+J26JEXNRtmOrlj8qhesLYI0dKpQ)
	if MMKTiky7N3vVPdx6GIzHFOf2Yjq or jcZbnfXTDoymgClJqYiABS:
		ZvWwXBJxzk3Qi9uAHKTD8hY2 += qqw1upCsKM(u"ࠬࢂࠧካ")
		if MMKTiky7N3vVPdx6GIzHFOf2Yjq: ZvWwXBJxzk3Qi9uAHKTD8hY2 += qeG16a4pbSHziNVQ2uFXrs(u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬኬ")+MMKTiky7N3vVPdx6GIzHFOf2Yjq
		if jcZbnfXTDoymgClJqYiABS: ZvWwXBJxzk3Qi9uAHKTD8hY2 += iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪክ")+jcZbnfXTDoymgClJqYiABS
		ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡾࠩࠫኮ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡿࠫኯ"))
	ZqC0UbVjhQo6DAFHf = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(BWfpRku7SsM6cbE0eG(u"ࠪࡥࡻ࠴ࠧኰ")+byMFpR6TYN4miKoxnt+IOHSz7YPF9WusGgUt1Dq(u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭኱")+J26JEXNRtmOrlj8qhesLYI0dKpQ)
	if ZqC0UbVjhQo6DAFHf:
		JMQOVt1w2S7l3yReLTihDrbq54YHvf = fNntYJW45mEFSdRX8g.findall(bGzRdmOErkIylxALniq6(u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨኲ"),ZvWwXBJxzk3Qi9uAHKTD8hY2,fNntYJW45mEFSdRX8g.DOTALL)
		ZvWwXBJxzk3Qi9uAHKTD8hY2 = ZvWwXBJxzk3Qi9uAHKTD8hY2.replace(JMQOVt1w2S7l3yReLTihDrbq54YHvf[BewrUo9ANCa17G43Sn0LH5xh],ZqC0UbVjhQo6DAFHf)
	CeXLtzElr5DHhs(ZvWwXBJxzk3Qi9uAHKTD8hY2,Ll1m0nJoaAPvHsXqyRE,ScEpZwINx93VJ5aWfb4)
else:
	import CCKRSEkHBw
	try: CCKRSEkHBw.wwxESsWhkyfG9PLr6gqiKapUudb0B(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,cwnGP8Qo6h,T5Teu1pJhvEmgkcn7OoA,c4yVMkzYb0)
	except Exception as YPL6cq2GuCUHwKZE: Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
M1AbKTe7LqSjw0WmGpHa3EV(Q1siCkTZyw.H2heYqoNSfBbcLRGiUsWDZnAEIgJ7j,Ro2CsQFGOj14wKIgcuHJ)
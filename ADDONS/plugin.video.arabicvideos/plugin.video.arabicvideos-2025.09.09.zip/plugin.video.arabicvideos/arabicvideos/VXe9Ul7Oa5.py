# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FARESKO'
Z0BYJQghVL1v87CAem = '_FSK_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الرئيسية','يلا شوت']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==990: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==991: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==992: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==993: ka7jz96YCdTBnQOLVPuJG3285MHf = ddDLz2MFtS9Irsy5gi7CwvJ8c(url)
	elif mode==999: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,999,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"primary-links"(.*?)</u',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,991)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"list-categories"(.*?)</u',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu.lstrip('/')
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,991)
	return
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-content"(.*?)"footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"overlay"','"duration"><')
		items = fNntYJW45mEFSdRX8g.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(' ')
			title = tt36wUe4HTPFmfs5hcbr(title)
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if 'episodes' not in type and bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
				title = title.replace('اون لاين',sCHVtMAvqirbQ4BUK3cgWo)
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,993,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,992,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''["']pagination["'](.*?)["']footer["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,991,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	else:
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('load-next-button" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة جديدة',B17r2fdFy9ns8tiOMLu[0],991,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,type)
	return
def ddDLz2MFtS9Irsy5gi7CwvJ8c(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-SERIES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="eplist"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		pWu3ti618zVAbjdf7 = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in pWu3ti618zVAbjdf7:
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,992)
	else:
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"category".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
			fs7D0d3QyAT(B17r2fdFy9ns8tiOMLu,'episodes')
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p,GQkoWhXOlsSVIp0Z = [],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if 'hash=' in Sw0pOFoVhPeIxbl:
		BykQz3MNqE09rsgbfo5WVcP = fNntYJW45mEFSdRX8g.findall('hash=(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		BykQz3MNqE09rsgbfo5WVcP = list(set(BykQz3MNqE09rsgbfo5WVcP))
		for sYTMXCn5AG0KR3E9SUO in BykQz3MNqE09rsgbfo5WVcP:
			PQDLyiqBbVWas63Ex = []
			cuIJ3axEtVWvs = sYTMXCn5AG0KR3E9SUO.split('__')
			for tLBfjh05uaXlHYxr3P6sVpGiT18U in cuIJ3axEtVWvs:
				try:
					tLBfjh05uaXlHYxr3P6sVpGiT18U = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(tLBfjh05uaXlHYxr3P6sVpGiT18U+'=')
					if I5VKjrFL0Bk97: tLBfjh05uaXlHYxr3P6sVpGiT18U = tLBfjh05uaXlHYxr3P6sVpGiT18U.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
					PQDLyiqBbVWas63Ex.append(tLBfjh05uaXlHYxr3P6sVpGiT18U)
				except: pass
			PXFtqmw5lBGQNa0IV8 = '>'.join(PQDLyiqBbVWas63Ex)
			PXFtqmw5lBGQNa0IV8 = PXFtqmw5lBGQNa0IV8.splitlines()
			for B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
				if ' => ' in B17r2fdFy9ns8tiOMLu:
					title,B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split(' => ')
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch')
	elif 'post_id' in Sw0pOFoVhPeIxbl:
		uu4UgsMj01aImASoXpYDO9iQcfG = fNntYJW45mEFSdRX8g.findall("post_id = '(.*?)'",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if uu4UgsMj01aImASoXpYDO9iQcfG:
			uu4UgsMj01aImASoXpYDO9iQcfG = uu4UgsMj01aImASoXpYDO9iQcfG[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			mkTJF3suO6yQMES = gAVl1vUmus8+'/wp-admin/admin-ajax.php?action=video_info&post_id='+uu4UgsMj01aImASoXpYDO9iQcfG
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',mkTJF3suO6yQMES,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-PLAY-2nd')
			EmO72KWnipacGP1R = UHqibFEGL8fjKhI.content
			SyfGmcVoYQ = fNntYJW45mEFSdRX8g.findall('"name":"(.*?)","src":"(.*?)"',EmO72KWnipacGP1R,fNntYJW45mEFSdRX8g.DOTALL)
			if not SyfGmcVoYQ:
				SyfGmcVoYQ = fNntYJW45mEFSdRX8g.findall('"src":"(.*?)"',EmO72KWnipacGP1R,fNntYJW45mEFSdRX8g.DOTALL)
				if SyfGmcVoYQ:
					ceJxzRr5KqAg3NtyUFkTY9nP8OsB = ['']*len(SyfGmcVoYQ)
					SyfGmcVoYQ = list(zip(ceJxzRr5KqAg3NtyUFkTY9nP8OsB,SyfGmcVoYQ))
			for name,B17r2fdFy9ns8tiOMLu in SyfGmcVoYQ:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('\\/','/')
				B17r2fdFy9ns8tiOMLu = IgCGzHw45TJ7PeuO1EKl(B17r2fdFy9ns8tiOMLu)
				if B17r2fdFy9ns8tiOMLu in GQkoWhXOlsSVIp0Z: continue
				else: GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__watch')
			NroHCBWaxUZOfbgqMzAL4vJ2 = gAVl1vUmus8+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+uu4UgsMj01aImASoXpYDO9iQcfG+'&video_id=null&video_url=null&video_source=custom'
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',NroHCBWaxUZOfbgqMzAL4vJ2,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FARESKO-PLAY-3rd')
			ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
			ZnNrmUO0JYwfF8CKquAl2B = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if ZnNrmUO0JYwfF8CKquAl2B:
				URfT0ICBsA,XUo3P0KcfNJGg2pF5mtQhua4ER = zip(*ZnNrmUO0JYwfF8CKquAl2B)
				ZnNrmUO0JYwfF8CKquAl2B = list(zip(XUo3P0KcfNJGg2pF5mtQhua4ER,URfT0ICBsA))
			for name,B17r2fdFy9ns8tiOMLu in ZnNrmUO0JYwfF8CKquAl2B:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('\\/','/')
				B17r2fdFy9ns8tiOMLu = IgCGzHw45TJ7PeuO1EKl(B17r2fdFy9ns8tiOMLu)
				if B17r2fdFy9ns8tiOMLu in GQkoWhXOlsSVIp0Z: continue
				else: GQkoWhXOlsSVIp0Z.append(B17r2fdFy9ns8tiOMLu)
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__download')
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url,'search')
	return
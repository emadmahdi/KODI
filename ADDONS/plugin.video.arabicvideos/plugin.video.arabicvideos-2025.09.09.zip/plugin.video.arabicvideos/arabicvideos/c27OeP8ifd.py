# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = gDETKVh8mZe09Nd(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ứ")
kXMbsAYDeB89gxr1wj = []
headers = {Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨỪ"):sCHVtMAvqirbQ4BUK3cgWo}
def PBahkj1p7s53o48NGemT(url,jREtxl9pGdyaYeChZOb1SLiQ2,JJCBn7FaOociDjUp0P9EW5ruzVQ):
	url = url.replace(jwzOabysh0Z(u"ࠬ࠵࡭ࡪࡴࡵࡳࡷ࠵ࠧừ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࠯ࡪࡨࡵࡥࡲ࡫࠯ࠨỬ")).replace(TzIj50KpohEOHx6CbZWqB(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫử"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࠱࡬ࡪࡷࡧ࡭ࡦ࠱ࠪỮ"))
	url = url.replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩ࠲ࡻ࠳ࡳࡥࡨࡣࡰࡥࡽ࠴࡭ࡦ࠱ࠪữ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪ࠳ࡲ࡫ࡧࡢ࡯ࡤࡼ࠳ࡳࡥ࠰ࠩỰ"))
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡌࡋࡔࠨự"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐࡉࡌࡇࡍࡂ࡚࠰࠵ࡸࡺࠧỲ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	KKaOGUP8NXcmDpTxL6SviZBd = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠦࡲࡷࡲࡸࡀࡀࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽ࠪỳ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	headers = {jwzOabysh0Z(u"࡙ࠧ࠯ࡌࡲࡪࡸࡴࡪࡣࠪỴ"):IOHSz7YPF9WusGgUt1Dq(u"ࠨࡶࡵࡹࡪ࠭ỵ"),YQNd4wejLSAVJ6T(u"࡛ࠩ࠱ࡎࡴࡥࡳࡶ࡬ࡥ࠲ࡖࡡࡳࡶ࡬ࡥࡱ࠳ࡄࡢࡶࡤࠫỶ"):aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡷࡹࡸࡥࡢ࡯ࡶࠫỷ"),TzIj50KpohEOHx6CbZWqB(u"ࠫ࡝࠳ࡉ࡯ࡧࡵࡸ࡮ࡧ࠭ࡑࡣࡵࡸ࡮ࡧ࡬࠮ࡅࡲࡱࡵࡵ࡮ࡦࡰࡷࠫỸ"):iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡬ࡩ࡭ࡧࡶ࠳ࡲ࡯ࡲࡳࡱࡵ࠳ࡻ࡯ࡤࡦࡱࠪỹ")}
	headers[oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡘ࠮ࡋࡱࡩࡷࡺࡩࡢ࠯࡙ࡩࡷࡹࡩࡰࡰࠪỺ")] = KKaOGUP8NXcmDpTxL6SviZBd[BewrUo9ANCa17G43Sn0LH5xh]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,Js61GTdX5wzMurUqi7Z(u"ࠧࡈࡇࡗࠫỻ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓࡅࡈࡃࡐࡅ࡝࠳࠲࡯ࡦࠪỼ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	feXwiQs4FvWB26xdrRHT3EVcMUY = Kdnrl9JHV0cFaGzC5bN.loads(Sw0pOFoVhPeIxbl)
	vF7BwmirVQhcgE8lIMKZ4pd = feXwiQs4FvWB26xdrRHT3EVcMUY[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡳࡶࡴࡶࡳࠨỽ")][SE97R3Dpj6dPLweVKU(u"ࠪࡷࡹࡸࡥࡢ࡯ࡶࠫỾ")][YQNd4wejLSAVJ6T(u"ࠫࡩࡧࡴࡢࠩỿ")]
	cb1fAztguv78n9LGhSWJFm5p = []
	for dAukY5fr20HZDntgKLi in range(len(vF7BwmirVQhcgE8lIMKZ4pd)):
		XO7Zr2W6kwieA = vF7BwmirVQhcgE8lIMKZ4pd[dAukY5fr20HZDntgKLi][gDETKVh8mZe09Nd(u"ࠬࡲࡡࡣࡧ࡯ࠫἀ")]
		PXFtqmw5lBGQNa0IV8 = vF7BwmirVQhcgE8lIMKZ4pd[dAukY5fr20HZDntgKLi][SE97R3Dpj6dPLweVKU(u"࠭࡭ࡪࡴࡵࡳࡷࡹࠧἁ")]
		for rry1PjdVFJTpQ7m5g in range(len(PXFtqmw5lBGQNa0IV8)):
			title = PXFtqmw5lBGQNa0IV8[rry1PjdVFJTpQ7m5g][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡥࡴ࡬ࡺࡪࡸࠧἂ")]
			B17r2fdFy9ns8tiOMLu = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡪࡷࡸࡵࡹ࠺ࠨἃ")+PXFtqmw5lBGQNa0IV8[rry1PjdVFJTpQ7m5g][qeG16a4pbSHziNVQ2uFXrs(u"ࠩ࡯࡭ࡳࡱࠧἄ")]+SIkwCEdJHTD9v1(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫἅ")+title+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡤࡥࠧἆ")+jREtxl9pGdyaYeChZOb1SLiQ2+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡥ࡟ࠨἇ")+XO7Zr2W6kwieA
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	return cb1fAztguv78n9LGhSWJFm5p
def BAGYzCJQtLof(url,jREtxl9pGdyaYeChZOb1SLiQ2,JJCBn7FaOociDjUp0P9EW5ruzVQ):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,RDwahqjPfbdyEiTtnLQu(u"࠭ࡇࡆࡖࠪἈ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sH6BOz5wKRFcEg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡆࡒࡂࡂࡒࡏࡅ࡞ࡋࡒ࠮࠳ࡶࡸࠬἉ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if I5VKjrFL0Bk97 and isinstance(Sw0pOFoVhPeIxbl,bytes): Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,IOHSz7YPF9WusGgUt1Dq(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨἊ"))
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"ࠩࠥࡥࡵࡲࡲ࠮࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪἋ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall(jwzOabysh0Z(u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨࡡࡱ࡮ࡵ࠱ࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧἌ"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		cb1fAztguv78n9LGhSWJFm5p = []
		for B17r2fdFy9ns8tiOMLu,title in items:
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+BWfpRku7SsM6cbE0eG(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬἍ")+title+BWfpRku7SsM6cbE0eG(u"ࠬࡥ࡟ࠨἎ")+jREtxl9pGdyaYeChZOb1SLiQ2)
	return cb1fAztguv78n9LGhSWJFm5p
def w9IYl38L7FDxPaou0(url,jREtxl9pGdyaYeChZOb1SLiQ2,JJCBn7FaOociDjUp0P9EW5ruzVQ):
	WylzIgKiVTaZXUQEtO = url.split(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭࠯ࠨἏ"))[E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠹ອ")]
	ToVLNn7B1MsY9dzjpgkW = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(WylzIgKiVTaZXUQEtO)
	if I5VKjrFL0Bk97: ToVLNn7B1MsY9dzjpgkW = ToVLNn7B1MsY9dzjpgkW.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	ggS2s0uWLMAbz = mSeoVfgRpNF9PKrJ(ToVLNn7B1MsY9dzjpgkW)+qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨἐ")+JJCBn7FaOociDjUp0P9EW5ruzVQ
	return [ggS2s0uWLMAbz]
def O9OsCEenrMyUSAlcqLYG76zuH4XDBf(av6RNsfGi2lD,source):
	GQkoWhXOlsSVIp0Z,ttiruedcm9 = [],[]
	for mkTJF3suO6yQMES in av6RNsfGi2lD:
		RvEJc0WgkhHQ29U743OKZa = fNntYJW45mEFSdRX8g.findall(IO7k2hZXSz(u"ࠨࡰࡤࡱࡪࡪ࠽࠯ࠬࡂࡣࡤ࠮࠮ࠫࡁࠬࡣࡤ࠭ἑ"),mkTJF3suO6yQMES+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡢࡣࠬἒ"),fNntYJW45mEFSdRX8g.DOTALL)
		iXhlWHwSex9sLTVkzBbtgIn7ZY = RvEJc0WgkhHQ29U743OKZa[BewrUo9ANCa17G43Sn0LH5xh] if RvEJc0WgkhHQ29U743OKZa else sCHVtMAvqirbQ4BUK3cgWo
		KOhtrlZq1ck8I2NDyx5CY6,JJNBaGnFwLZ5uCT496SdoVjr,sTnCDNGi3hy0W78 = mkTJF3suO6yQMES,sCHVtMAvqirbQ4BUK3cgWo,[]
		if bGzRdmOErkIylxALniq6(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫἓ") in mkTJF3suO6yQMES: KOhtrlZq1ck8I2NDyx5CY6,JJNBaGnFwLZ5uCT496SdoVjr = mkTJF3suO6yQMES.split(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬἔ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		try:
			if gDETKVh8mZe09Nd(u"ࠬࡧ࡬ࡣࡣࡳࡰࡦࡿࡥࡳࠩἕ") in KOhtrlZq1ck8I2NDyx5CY6: sTnCDNGi3hy0W78 = BAGYzCJQtLof(KOhtrlZq1ck8I2NDyx5CY6,iXhlWHwSex9sLTVkzBbtgIn7ZY,JJNBaGnFwLZ5uCT496SdoVjr)
			elif GVurlv8HeoXEzPRiQB7Ty(u"࠭࡭ࡦࡩࡤࡱࡦࡾࠧ἖") in KOhtrlZq1ck8I2NDyx5CY6: sTnCDNGi3hy0W78 = PBahkj1p7s53o48NGemT(KOhtrlZq1ck8I2NDyx5CY6,iXhlWHwSex9sLTVkzBbtgIn7ZY,JJNBaGnFwLZ5uCT496SdoVjr)
			elif SIkwCEdJHTD9v1(u"ࠧ࠰࡮࠲ࡥࡍࡘ࠰ࡤࡊࡐ࠺ࡑࡿ࠹ࠨ἗") in KOhtrlZq1ck8I2NDyx5CY6: sTnCDNGi3hy0W78 = w9IYl38L7FDxPaou0(KOhtrlZq1ck8I2NDyx5CY6,iXhlWHwSex9sLTVkzBbtgIn7ZY,JJNBaGnFwLZ5uCT496SdoVjr)
		except: pass
		if sTnCDNGi3hy0W78:
			for NroHCBWaxUZOfbgqMzAL4vJ2 in sTnCDNGi3hy0W78:
				OlbyhQUPi8d4mz6o0VTrjXnSq1CIK,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf = NroHCBWaxUZOfbgqMzAL4vJ2,sCHVtMAvqirbQ4BUK3cgWo
				if SE97R3Dpj6dPLweVKU(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩἘ") in NroHCBWaxUZOfbgqMzAL4vJ2: OlbyhQUPi8d4mz6o0VTrjXnSq1CIK,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf = NroHCBWaxUZOfbgqMzAL4vJ2.split(IO7k2hZXSz(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪἙ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
				if OlbyhQUPi8d4mz6o0VTrjXnSq1CIK not in GQkoWhXOlsSVIp0Z:
					GQkoWhXOlsSVIp0Z.append(OlbyhQUPi8d4mz6o0VTrjXnSq1CIK)
					ttiruedcm9.append(NroHCBWaxUZOfbgqMzAL4vJ2)
		elif KOhtrlZq1ck8I2NDyx5CY6 not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(KOhtrlZq1ck8I2NDyx5CY6)
			ttiruedcm9.append(mkTJF3suO6yQMES)
	return ttiruedcm9
def jMnrbw4qeoV2iW0R8(source,ScEpZwINx93VJ5aWfb4,url):
	SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+RDwahqjPfbdyEiTtnLQu(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡦࡪࡰࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࡷࠥࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪἚ")+source+Js61GTdX5wzMurUqi7Z(u"ࠫࠥࡣࠠࠡࠢࠣࡘࡾࡶࡥ࠻ࠢ࡞ࠤࠬἛ")+ScEpZwINx93VJ5aWfb4+BWfpRku7SsM6cbE0eG(u"ࠬࠦ࡝ࠨἜ"))
	Oq0Q9PrB5oyVc = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡤࡪࡥࡷࠫἝ"),IOHSz7YPF9WusGgUt1Dq(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ἞"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ἟"))
	g0eU93LncmwbEDVX = hDjf1Ubgq629nXlOvcFLH4Jw.strftime(fvYGxnZNUiyP4HJkMIoS25(u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏࠪἠ"),hDjf1Ubgq629nXlOvcFLH4Jw.gmtime(JVAlZw9Nsnj))
	mrDfbxOkTg = g0eU93LncmwbEDVX,url
	key = source+bRa9TlJO4fPdsUAj+WHzJr591Ka8gRdbiLmBp0hT3S+bRa9TlJO4fPdsUAj+str(A4AOrGi8QL)
	Iqm6XAWBlF = sCHVtMAvqirbQ4BUK3cgWo
	if key not in list(Oq0Q9PrB5oyVc.keys()): Oq0Q9PrB5oyVc[key] = [mrDfbxOkTg]
	else:
		if url not in str(Oq0Q9PrB5oyVc[key]): Oq0Q9PrB5oyVc[key].append(mrDfbxOkTg)
		else: Iqm6XAWBlF = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡠࡳࠦ็ัษࠣห้็๊ะ์๋ࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣฮ฾๋ไࠨἡ")
	Wdwe79VYB6U3R = BewrUo9ANCa17G43Sn0LH5xh
	for key in list(Oq0Q9PrB5oyVc.keys()):
		Oq0Q9PrB5oyVc[key] = list(set(Oq0Q9PrB5oyVc[key]))
		Wdwe79VYB6U3R += len(Oq0Q9PrB5oyVc[key])
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,sH6BOz5wKRFcEg(u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬἢ")+Iqm6XAWBlF+YQNd4wejLSAVJ6T(u"ࠬࡢ࡮࡝ࡰ่้ࠣ฿ไๆࠢส่อืๆศ็ฯࠤ๏่่ๆࠢหะ๊฿ࠠใษษ้ฮࠦศศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥ๐ฬะࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤํู่โࠢํ฽ึ฼ฺࠠๆํ็ࠥอไษำ้ห๊าࠠฤ่ࠣฮึูไ้ࠡำ๋ࠥอไใษษ้ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾์ฯๆษࠣ๎ฺฮอࠡ฻าำ์อࠠ࠶ࠢไ๎ิ๐่่ษอࠫἣ")+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࡜࡯࡞ࡱࠫἤ")+aenpKvQCGVzhLXEdWiDIZ(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪἥ")+str(Wdwe79VYB6U3R))
	if Wdwe79VYB6U3R>=tBMCpcY2vUV1dEjZ7PDG:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨษ็ฬึ์วๆฮࠣะ๊฿ࠠใษษ้ฮࠦแ๋้สࠤ࠺ࠦแ๋ัํ์์อสࠡๆ่ࠤ๏าฯࠡษ็ฬึ์วๆฮ่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ࠴࠮ࠡี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬู๊อ้ࠡำ๋ࠥอไใษษ้ฮࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥหัิษ็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢๅฬ้ࠦๅิฯ๊หࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไๆสิ้ัࠦศโฯุࠤ์ึ็ࠡษ็ๅ๏ี๊้้สฮࠥลࠡࠢࠩἦ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			I9ikUXVehmdcq37OKNs8P4JDYM = sCHVtMAvqirbQ4BUK3cgWo
			for key in list(Oq0Q9PrB5oyVc.keys()):
				I9ikUXVehmdcq37OKNs8P4JDYM += slFfrUIWCowaBA7tce3iZbj8xn+key
				AU17xCW65FsvrK4jZOubX = sorted(Oq0Q9PrB5oyVc[key],reverse=lvzrYTpcBaK,key=lambda FXVwjSiZIosnbJL: FXVwjSiZIosnbJL[BewrUo9ANCa17G43Sn0LH5xh])
				for g0eU93LncmwbEDVX,url in AU17xCW65FsvrK4jZOubX:
					I9ikUXVehmdcq37OKNs8P4JDYM += slFfrUIWCowaBA7tce3iZbj8xn+g0eU93LncmwbEDVX+bRa9TlJO4fPdsUAj+mSeoVfgRpNF9PKrJ(url)
				I9ikUXVehmdcq37OKNs8P4JDYM += TzIj50KpohEOHx6CbZWqB(u"ࠩ࡟ࡲࡡࡴࠧἧ")
			import i5kNU6T7vE
			bEZlOa1inyrUgdTw9BKNtcMCLYI = i5kNU6T7vE.XuLQaKS9RB4CxOYG5J0kMsNZnq6bFl(EJgYdjbIiWe1apkQlZcR42(u"࡚ࠪ࡮ࡪࡥࡰࡵࠪἨ"),sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨἩ"),sCHVtMAvqirbQ4BUK3cgWo,I9ikUXVehmdcq37OKNs8P4JDYM)
			if bEZlOa1inyrUgdTw9BKNtcMCLYI: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨἪ"))
			else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫἫ"))
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			Oq0Q9PrB5oyVc = {}
			aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,hPFcB6Uxmabj59Iq(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪἬ"),gDETKVh8mZe09Nd(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧἭ"))
	if Oq0Q9PrB5oyVc: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,IO7k2hZXSz(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬἮ"),jwzOabysh0Z(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩἯ"),Oq0Q9PrB5oyVc,IfAkw39UvaYWEDXLthFrbSzG)
	return
def xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,source,ScEpZwINx93VJ5aWfb4,url):
	if not cb1fAztguv78n9LGhSWJFm5p:
		jMnrbw4qeoV2iW0R8(source,ScEpZwINx93VJ5aWfb4,url)
		return
	T1AWiH6ZJ2X3Ccs = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(SE97R3Dpj6dPLweVKU(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨἰ"))
	E4EWmXuYSIvfUzcM6adTwC0 = jwzOabysh0Z(u"ࠬ࠳ࠧἱ") not in T1AWiH6ZJ2X3Ccs
	sTnCDNGi3hy0W78 = O9OsCEenrMyUSAlcqLYG76zuH4XDBf(cb1fAztguv78n9LGhSWJFm5p[:],source)
	if sTnCDNGi3hy0W78!=cb1fAztguv78n9LGhSWJFm5p and not E4EWmXuYSIvfUzcM6adTwC0:
		LLDRFWC7Vg6cONqpGBQr3lmdh9 = []
		for mkTJF3suO6yQMES in cb1fAztguv78n9LGhSWJFm5p:
			uxzkVE6jAXNoiW,JJCBn7FaOociDjUp0P9EW5ruzVQ = mkTJF3suO6yQMES,sCHVtMAvqirbQ4BUK3cgWo
			if EJgYdjbIiWe1apkQlZcR42(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧἲ") in mkTJF3suO6yQMES: uxzkVE6jAXNoiW,JJCBn7FaOociDjUp0P9EW5ruzVQ = mkTJF3suO6yQMES.split(SIkwCEdJHTD9v1(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨἳ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			JJCBn7FaOociDjUp0P9EW5ruzVQ = JJCBn7FaOociDjUp0P9EW5ruzVQ.replace(YQNd4wejLSAVJ6T(u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩἴ"),SIkwCEdJHTD9v1(u"ࠩࠪἵ")).replace(YQNd4wejLSAVJ6T(u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧἶ"),TzIj50KpohEOHx6CbZWqB(u"ࠫࠬἷ")).replace(qqw1upCsKM(u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭Ἰ"),RDwahqjPfbdyEiTtnLQu(u"࠭ࠧἹ"))
			LLDRFWC7Vg6cONqpGBQr3lmdh9.append(JJCBn7FaOociDjUp0P9EW5ruzVQ)
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(YQNd4wejLSAVJ6T(u"ࠧฦฺ๊หึࠦโ้ษษ้ࠥอไอ๊าอࠬἺ"),LLDRFWC7Vg6cONqpGBQr3lmdh9)
	cb1fAztguv78n9LGhSWJFm5p = list(set(sTnCDNGi3hy0W78))
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = u9flYvgRdTxPckohWB7a3DA(cb1fAztguv78n9LGhSWJFm5p,source)
	if Q1siCkTZyw.resolveonly:
		sscApg7rI3Uvjh0ON = mmKLY7eObwN1yxaBJWgdp8QCXZ(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,source,lvzrYTpcBaK)
		return
	ss5e6cLGylx,JbShzsakZ5M1i,IpKAUD2fuvgae4MciY,sscApg7rI3Uvjh0ON,bbEmOiqdw4h5gk7yK,UqKgalXPCz7eQAL08foMx1R = lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[],sCHVtMAvqirbQ4BUK3cgWo,[]
	Z3kqwutrJ5TmQSecf = lvzrYTpcBaK if source in ygksQzPTubHYiDG0SOmrXqlKVJMfv else ndkUxG9LtewJ
	if Z3kqwutrJ5TmQSecf:
		DD1SGtqosZ = BewrUo9ANCa17G43Sn0LH5xh
		nw7r40tCmJ8Ye = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࡮࡬ࡷࡹ࠭Ἳ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧἼ"))
		ZoW2SVwcADN0eyzhXJ = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,BWfpRku7SsM6cbE0eG(u"ࠪࡰ࡮ࡹࡴࠨἽ"),IOHSz7YPF9WusGgUt1Dq(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧἾ"))
		AVlZNvLrbJ59ukXGf0Bt6iOdcR = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,SIkwCEdJHTD9v1(u"ࠬࡲࡩࡴࡶࠪἿ"),IO7k2hZXSz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨὀ"))
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = BewrUo9ANCa17G43Sn0LH5xh
		for title,B17r2fdFy9ns8tiOMLu in list(zip(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV)):
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨὁ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
			if B17r2fdFy9ns8tiOMLu in nw7r40tCmJ8Ye:
				DD1SGtqosZ += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = ppPYj60nQOTlIut3X59FGZd+title+B8alA5nvIhTxQ
			elif B17r2fdFy9ns8tiOMLu in AVlZNvLrbJ59ukXGf0Bt6iOdcR:
				DD1SGtqosZ += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = VXWOCAE6ns3paJ8DLG479NQfMu+title+B8alA5nvIhTxQ
			elif B17r2fdFy9ns8tiOMLu in ZoW2SVwcADN0eyzhXJ:
				DD1SGtqosZ += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = title
			else:
				DD1SGtqosZ += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = title
			nkjHK2zQeb4vBuoaxPZTqIALW5S1 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		UqKgalXPCz7eQAL08foMx1R = [F7Fe63KbGjaz2TcmCNHPdo5QiXO+Js61GTdX5wzMurUqi7Z(u"ࠨใะูࠥาๅ๋฻ࠣหู้๊าใิหฯ࠭ὂ")+B8alA5nvIhTxQ]
	else: bbEmOiqdw4h5gk7yK = F7Fe63KbGjaz2TcmCNHPdo5QiXO+aYH620Dh48GEsTFfOBSQ7r(u"ࠩฦาฯืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠩὃ")+B8alA5nvIhTxQ
	while ndkUxG9LtewJ:
		DGHgA1rN5hFXMtOI8oz2PSVW = ndkUxG9LtewJ
		if Z3kqwutrJ5TmQSecf:
			if E4EWmXuYSIvfUzcM6adTwC0 and len(V9TdsglcWYv0X)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: jQLzA92KFEcpw = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			else:
				Yv09gxn2mohD8VN4e7OJHdPW5CsLK = str(V9TdsglcWYv0X).count(ppPYj60nQOTlIut3X59FGZd)
				p4ad8xPW0M7krRSCiQXYHThe = str(V9TdsglcWYv0X).count(VXWOCAE6ns3paJ8DLG479NQfMu)
				VUzbY6uPvwMKyc = len(V9TdsglcWYv0X)-Yv09gxn2mohD8VN4e7OJHdPW5CsLK-p4ad8xPW0M7krRSCiQXYHThe
				if qdUK5ioJyrO1T: bbEmOiqdw4h5gk7yK = VXWOCAE6ns3paJ8DLG479NQfMu+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࠤࠥࠦำ๋ศฬ࠾ࠬὄ")+str(p4ad8xPW0M7krRSCiQXYHThe)+B8alA5nvIhTxQ+sH6BOz5wKRFcEg(u"ࠫࠥࠦࠠๆฮ๊์้ฯ࠺ࠨὅ")+str(VUzbY6uPvwMKyc)+ppPYj60nQOTlIut3X59FGZd+gDETKVh8mZe09Nd(u"ࠬา๊ะห࠽ࠫ὆")+str(Yv09gxn2mohD8VN4e7OJHdPW5CsLK)+B8alA5nvIhTxQ
				else: bbEmOiqdw4h5gk7yK = ppPYj60nQOTlIut3X59FGZd+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ฬ๋ัฬ࠾ࠬ὇")+str(Yv09gxn2mohD8VN4e7OJHdPW5CsLK)+B8alA5nvIhTxQ+qqw1upCsKM(u"้ࠧࠡࠢࠣัํ่ๅห࠽ࠫὈ")+str(VUzbY6uPvwMKyc)+VXWOCAE6ns3paJ8DLG479NQfMu+aYH620Dh48GEsTFfOBSQ7r(u"ࠨࠢࠣࠤุ๐ฦส࠼ࠪὉ")+str(p4ad8xPW0M7krRSCiQXYHThe)+B8alA5nvIhTxQ
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(bbEmOiqdw4h5gk7yK,UqKgalXPCz7eQAL08foMx1R+V9TdsglcWYv0X)
			if jQLzA92KFEcpw==BewrUo9ANCa17G43Sn0LH5xh:
				DGHgA1rN5hFXMtOI8oz2PSVW = lvzrYTpcBaK
				start,end = BewrUo9ANCa17G43Sn0LH5xh,len(V9TdsglcWYv0X)-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				sscApg7rI3Uvjh0ON = mmKLY7eObwN1yxaBJWgdp8QCXZ(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,source,ndkUxG9LtewJ)
				IpKAUD2fuvgae4MciY = zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࡣࡦࡲ࡬ࠨὊ") if sscApg7rI3Uvjh0ON else qqw1upCsKM(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨࠫὋ")
			elif jQLzA92KFEcpw>BewrUo9ANCa17G43Sn0LH5xh: start,end = jQLzA92KFEcpw-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,jQLzA92KFEcpw-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		else:
			if E4EWmXuYSIvfUzcM6adTwC0 and len(V9TdsglcWYv0X)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: jQLzA92KFEcpw = BewrUo9ANCa17G43Sn0LH5xh
			else: jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(bbEmOiqdw4h5gk7yK,V9TdsglcWYv0X)
			start,end = jQLzA92KFEcpw,jQLzA92KFEcpw
		if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			IpKAUD2fuvgae4MciY = qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭Ὄ")
			break
		if DGHgA1rN5hFXMtOI8oz2PSVW:
			IpKAUD2fuvgae4MciY = jwzOabysh0Z(u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪ࡟ࡰࡰࡨࠫὍ")
			sscApg7rI3Uvjh0ON = mmKLY7eObwN1yxaBJWgdp8QCXZ([V9TdsglcWYv0X[start]],[ss7YGDbuAIxgnqaQroTV[start]],source,ndkUxG9LtewJ)
			title,B17r2fdFy9ns8tiOMLu,JbShzsakZ5M1i,J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8,s4MQr8tjRFmHaGNXnCiZuV = sscApg7rI3Uvjh0ON[BewrUo9ANCa17G43Sn0LH5xh]
			A9bvplQ5GH4uI,J1WoKmE2596G = lYwIfmpARQe5zGo(title,B17r2fdFy9ns8tiOMLu,J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8,source,ScEpZwINx93VJ5aWfb4)
			if A9bvplQ5GH4uI in [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫ὎"),qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ὏"),EJgYdjbIiWe1apkQlZcR42(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩὐ")]:
				ss5e6cLGylx = ndkUxG9LtewJ
				break
			else:
				if not JbShzsakZ5M1i: JbShzsakZ5M1i = BWfpRku7SsM6cbE0eG(u"࡙ࠩ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡦࡢ࡫࡯ࡩࡩ࠭ὑ")
				title = VXWOCAE6ns3paJ8DLG479NQfMu+title+B8alA5nvIhTxQ
				sscApg7rI3Uvjh0ON[BewrUo9ANCa17G43Sn0LH5xh] = title,B17r2fdFy9ns8tiOMLu,JbShzsakZ5M1i,J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8,s4MQr8tjRFmHaGNXnCiZuV
				BK1tFuzUeANXZpQPEOlofLmckT6S = B17r2fdFy9ns8tiOMLu.split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫὒ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]
				aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,RDwahqjPfbdyEiTtnLQu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡖࡅࡆࡉࡊࡊࡅࡅࠩὓ"),BK1tFuzUeANXZpQPEOlofLmckT6S)
				kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,BWfpRku7SsM6cbE0eG(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡇࡃࡌࡐࡊࡊࠧὔ"),BK1tFuzUeANXZpQPEOlofLmckT6S,[JbShzsakZ5M1i,title,B17r2fdFy9ns8tiOMLu],NjPWfJS7CUoTsz4lKk0hg)
			if JbShzsakZ5M1i==oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫὕ"): break
			K4KcLWaVQETnCUM2 = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠠࠡࠩὖ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬὗ")) if JbShzsakZ5M1i.count(slFfrUIWCowaBA7tce3iZbj8xn)>gDETKVh8mZe09Nd(u"࠹ຮ") else slFfrUIWCowaBA7tce3iZbj8xn+JbShzsakZ5M1i
			if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ὘") not in source: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์ࡢ࡮ࠨὙ")+K4KcLWaVQETnCUM2,profile=bGzRdmOErkIylxALniq6(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ὚"))
			if len(ss7YGDbuAIxgnqaQroTV)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU and JbShzsakZ5M1i: break
		for nkjHK2zQeb4vBuoaxPZTqIALW5S1 in range(start,end+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
			n0nlbGBkPSQoNej9Zw4 = BewrUo9ANCa17G43Sn0LH5xh if DGHgA1rN5hFXMtOI8oz2PSVW else nkjHK2zQeb4vBuoaxPZTqIALW5S1
			title,B17r2fdFy9ns8tiOMLu,JbShzsakZ5M1i,J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8,s4MQr8tjRFmHaGNXnCiZuV = sscApg7rI3Uvjh0ON[n0nlbGBkPSQoNej9Zw4]
			V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1].replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(ppPYj60nQOTlIut3X59FGZd,sCHVtMAvqirbQ4BUK3cgWo).replace(VU8su1fdMzlHvyA0B,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
			if s4MQr8tjRFmHaGNXnCiZuV==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭Ὓ"): V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = ppPYj60nQOTlIut3X59FGZd+V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1]+B8alA5nvIhTxQ
			elif s4MQr8tjRFmHaGNXnCiZuV==aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧ὜"): V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = VXWOCAE6ns3paJ8DLG479NQfMu+V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1]+B8alA5nvIhTxQ
			else: V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1] = V9TdsglcWYv0X[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
	if IpKAUD2fuvgae4MciY==BWfpRku7SsM6cbE0eG(u"ࠧ࡯ࡱࡷࡣࡷ࡫ࡳࡰ࡮ࡹࡥࡧࡲࡥࠨὝ"): ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,fvYGxnZNUiyP4HJkMIoS25(u"ࠨๆ็วุ็ࠠๅษࠣ๎ําฯࠡีํีๆืวหࠢฯ๎ิฯࠠโ์๋ࠣีอࠠศๆไ๎ิ๐่ࠡ࠰࠱ࠤาอ่ๅࠢฦ๊ࠥะศฮอࠣ฽๋ࠦ็ัษࠣห้็๊ะ์๋ࠤๆ๐ࠠๆ๊สๆ฾ࠦรฯำ์ࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ั࠭὞"))
	if not ss5e6cLGylx or IpKAUD2fuvgae4MciY in [GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫὟ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨࠫὠ")] or JbShzsakZ5M1i:
		bOU4wkFLus = FoiwfTEhGD8ulS25HeUvnI.executeJSONRPC(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡉ࡬ࡦࡣࡵࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲ࡿࢀࠫὡ"))
	return
def mmKLY7eObwN1yxaBJWgdp8QCXZ(tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p,source,showDialogs):
	global nn4cTU9V6zujRfkC5,qKj4oFagTbmAnLR,Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G,vvPBtc3a5jGXURnNSyluAsOgC6Yx,y82bKWI6n1,WAwDbyNEci3daMK7hPfQRpx9C1vL
	nn4cTU9V6zujRfkC5,qKj4oFagTbmAnLR,Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G,vvPBtc3a5jGXURnNSyluAsOgC6Yx = [],[],[],[]
	y82bKWI6n1,WAwDbyNEci3daMK7hPfQRpx9C1vL = [],[]
	ka7jz96YCdTBnQOLVPuJG3285MHf,F0FHjWtorQxaN,new = [],[],[]
	YgJ3ybSlEOxXUL7m(VMB1l2JKvI,VMB1l2JKvI,VMB1l2JKvI)
	count = len(cb1fAztguv78n9LGhSWJFm5p)
	for dAukY5fr20HZDntgKLi in range(count):
		nn4cTU9V6zujRfkC5.append(ZetiSjBQ9bTnF23pzsmXcyWuK)
		qKj4oFagTbmAnLR.append(ZetiSjBQ9bTnF23pzsmXcyWuK)
		Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G.append(ZetiSjBQ9bTnF23pzsmXcyWuK)
		vvPBtc3a5jGXURnNSyluAsOgC6Yx.append(ZetiSjBQ9bTnF23pzsmXcyWuK)
		y82bKWI6n1.append(ZetiSjBQ9bTnF23pzsmXcyWuK)
		WAwDbyNEci3daMK7hPfQRpx9C1vL.append(BewrUo9ANCa17G43Sn0LH5xh)
		title = tryU7sQv0e91cVL3h2xKRpqHdm6[dAukY5fr20HZDntgKLi]
		B17r2fdFy9ns8tiOMLu = cb1fAztguv78n9LGhSWJFm5p[dAukY5fr20HZDntgKLi].strip(AAh0X3OCacr4HpifRGLZKT).strip(IO7k2hZXSz(u"ࠬࠬࠧὢ")).strip(jwzOabysh0Z(u"࠭࠿ࠨὣ")).strip(Js61GTdX5wzMurUqi7Z(u"ࠧ࠰ࠩὤ"))
		if count>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU and showDialogs: iRaHzNpJhSx6ZnCfrvD7j93lks(GVurlv8HeoXEzPRiQB7Ty(u"ࠨใะูู๊ࠥาใิࠤึ่ๅࠡࠢࠪὥ")+str(dAukY5fr20HZDntgKLi+SIkwCEdJHTD9v1(u"࠱ຯ")),title)
		NNs5QZqnJ4GCymeTxHoFXBI = [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪὦ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨὧ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡆࡑࡗࡂࡏࠪὨ")]
		if source in NNs5QZqnJ4GCymeTxHoFXBI: y82bKWI6n1[dAukY5fr20HZDntgKLi] = na5dAbURXCmKOv6fBptlc1N(title,B17r2fdFy9ns8tiOMLu,source,dAukY5fr20HZDntgKLi,ndkUxG9LtewJ)
		else:
			if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				Q5yJm7zvEIPK3BVY0Ze89Wt = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=na5dAbURXCmKOv6fBptlc1N,args=(title,B17r2fdFy9ns8tiOMLu,source,dAukY5fr20HZDntgKLi,count==IOHSz7YPF9WusGgUt1Dq(u"࠲ະ")))
				F0FHjWtorQxaN.append(Q5yJm7zvEIPK3BVY0Ze89Wt)
				new.append(dAukY5fr20HZDntgKLi)
	def wJ2SXGBCYsgIp1():
		vfrjqSsdFHxQOBtEl1uJ = lvzrYTpcBaK
		for B17r2fdFy9ns8tiOMLu in y82bKWI6n1:
			if not B17r2fdFy9ns8tiOMLu: break
		else: vfrjqSsdFHxQOBtEl1uJ = ndkUxG9LtewJ
		sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying() if Q1siCkTZyw.resolveonly else ndkUxG9LtewJ
		return vfrjqSsdFHxQOBtEl1uJ or not sxjn4kIyMur8fw9KUTFDiB3
	Tgpqkx7DH6w30r(F0FHjWtorQxaN,AWvIZYNDLM2wP,favJM9wCN6Q1BxjmVUP,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,wJ2SXGBCYsgIp1)
	for dAukY5fr20HZDntgKLi in range(count):
		title = tryU7sQv0e91cVL3h2xKRpqHdm6[dAukY5fr20HZDntgKLi]
		B17r2fdFy9ns8tiOMLu = cb1fAztguv78n9LGhSWJFm5p[dAukY5fr20HZDntgKLi].strip(AAh0X3OCacr4HpifRGLZKT).strip(zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࠬࠧὩ")).strip(IOHSz7YPF9WusGgUt1Dq(u"࠭࠿ࠨὪ")).strip(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ࠰ࠩὫ"))
		BK1tFuzUeANXZpQPEOlofLmckT6S = B17r2fdFy9ns8tiOMLu.split(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩὬ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh] if dAukY5fr20HZDntgKLi in new else lvzrYTpcBaK
		stream = y82bKWI6n1[dAukY5fr20HZDntgKLi]
		if stream and not stream[BewrUo9ANCa17G43Sn0LH5xh] and stream[rgpY5VUqKbeFOCD9Nki2SmGvxEja]:
			s4MQr8tjRFmHaGNXnCiZuV = TzIj50KpohEOHx6CbZWqB(u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪὭ")
			K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2 = stream
			if BK1tFuzUeANXZpQPEOlofLmckT6S: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,YQNd4wejLSAVJ6T(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡙ࡕࡄࡅࡈࡉࡉࡋࡄࠨὮ"),BK1tFuzUeANXZpQPEOlofLmckT6S,[K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2],NjPWfJS7CUoTsz4lKk0hg)
		elif stream and stream[BewrUo9ANCa17G43Sn0LH5xh] and not stream[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] and not stream[rgpY5VUqKbeFOCD9Nki2SmGvxEja]:
			s4MQr8tjRFmHaGNXnCiZuV = oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬὯ")
			K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2 = aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࡟ࡲࠬὰ")+stream[BewrUo9ANCa17G43Sn0LH5xh],[],[]
			if BK1tFuzUeANXZpQPEOlofLmckT6S: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,bGzRdmOErkIylxALniq6(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨά"),BK1tFuzUeANXZpQPEOlofLmckT6S,[K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2],NjPWfJS7CUoTsz4lKk0hg)
		elif WAwDbyNEci3daMK7hPfQRpx9C1vL[dAukY5fr20HZDntgKLi]+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU>AAwX4J3uM1fH59mIhkBqexLSKyzb:
			s4MQr8tjRFmHaGNXnCiZuV = IO7k2hZXSz(u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨὲ")
			K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2 = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡴࡪ࡯ࡨࡨࠥࡵࡵࡵࠢࠫࠫέ")+str(WAwDbyNEci3daMK7hPfQRpx9C1vL[dAukY5fr20HZDntgKLi])+IO7k2hZXSz(u"ࠩࠣࡷࡪࡩ࡯࡯ࡦࡶ࠭ࠬὴ"),[],[]
			if BK1tFuzUeANXZpQPEOlofLmckT6S: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,qqw1upCsKM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭ή"),BK1tFuzUeANXZpQPEOlofLmckT6S,[K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2],NjPWfJS7CUoTsz4lKk0hg)
		elif not stream:
			s4MQr8tjRFmHaGNXnCiZuV = SIkwCEdJHTD9v1(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࠫὶ")
			K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2 = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠬί"),[],[]
			if BK1tFuzUeANXZpQPEOlofLmckT6S: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡗࡑࡏࡓࡕࡗࡏࠩὸ"),BK1tFuzUeANXZpQPEOlofLmckT6S,[K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2],NjPWfJS7CUoTsz4lKk0hg)
		else:
			s4MQr8tjRFmHaGNXnCiZuV = EJgYdjbIiWe1apkQlZcR42(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨό")
			K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2 = gDETKVh8mZe09Nd(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡷ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡺࡸࡥࠨὺ"),[],[]
			if BK1tFuzUeANXZpQPEOlofLmckT6S: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬύ"),BK1tFuzUeANXZpQPEOlofLmckT6S,[K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2],NjPWfJS7CUoTsz4lKk0hg)
		ka7jz96YCdTBnQOLVPuJG3285MHf.append([title,B17r2fdFy9ns8tiOMLu,K4KcLWaVQETnCUM2,dwDUvp0LAuyg1rI,NroHCBWaxUZOfbgqMzAL4vJ2,s4MQr8tjRFmHaGNXnCiZuV])
	YgJ3ybSlEOxXUL7m(K3nC0rDSptmG,K3nC0rDSptmG,K3nC0rDSptmG)
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def na5dAbURXCmKOv6fBptlc1N(smh8Qbf9jH,url,source,eC9s1fQEKDF4jnw0zVPrJ3db,PPugTDGs1YHr6L8vBiEfzcS0):
	global y82bKWI6n1,WAwDbyNEci3daMK7hPfQRpx9C1vL
	WAwDbyNEci3daMK7hPfQRpx9C1vL[eC9s1fQEKDF4jnw0zVPrJ3db] = BewrUo9ANCa17G43Sn0LH5xh
	ofLNbsZxdtEvC0gRM2r9khzTeV = hDjf1Ubgq629nXlOvcFLH4Jw.time()
	SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+jwzOabysh0Z(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫὼ")+smh8Qbf9jH+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨώ")+url+qqw1upCsKM(u"ࠬࠦ࡝ࠨ὾"))
	B17r2fdFy9ns8tiOMLu,Hi64ZlMGdDw5XN8hIfVKq10RkJ = url,sCHVtMAvqirbQ4BUK3cgWo
	Wt5PeuKxa30B9qVmFYEvloIS7Ur6T = aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ὿")
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = Lr6Q0Jxgy5S3GTDREYkls(url,source)
	if JbShzsakZ5M1i==E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᾀ"):
		y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = bGzRdmOErkIylxALniq6(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᾁ"),[],[]
		WAwDbyNEci3daMK7hPfQRpx9C1vL[eC9s1fQEKDF4jnw0zVPrJ3db] = hDjf1Ubgq629nXlOvcFLH4Jw.time()-ofLNbsZxdtEvC0gRM2r9khzTeV
		return y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db]
	elif qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᾂ") in JbShzsakZ5M1i:
		Hi64ZlMGdDw5XN8hIfVKq10RkJ = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡹࠠࠩ࠴࠰࠹࠮࠭ᾃ")
		B17r2fdFy9ns8tiOMLu = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)[BewrUo9ANCa17G43Sn0LH5xh]
		Wt5PeuKxa30B9qVmFYEvloIS7Ur6T,Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ZPWtLCpzSDR92c(Hi64ZlMGdDw5XN8hIfVKq10RkJ,B17r2fdFy9ns8tiOMLu,source,eC9s1fQEKDF4jnw0zVPrJ3db)
		if Hi64ZlMGdDw5XN8hIfVKq10RkJ==TzIj50KpohEOHx6CbZWqB(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾄ"):
			y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
			WAwDbyNEci3daMK7hPfQRpx9C1vL[eC9s1fQEKDF4jnw0zVPrJ3db] = hDjf1Ubgq629nXlOvcFLH4Jw.time()-ofLNbsZxdtEvC0gRM2r9khzTeV
			return Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	elif JbShzsakZ5M1i: Hi64ZlMGdDw5XN8hIfVKq10RkJ = gDETKVh8mZe09Nd(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬᾅ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)[:YQNd4wejLSAVJ6T(u"࠺࠳ັ")]
	if ss7YGDbuAIxgnqaQroTV:
		ss7YGDbuAIxgnqaQroTV = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)
		SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+fvYGxnZNUiyP4HJkMIoS25(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩᾆ")+smh8Qbf9jH+qqw1upCsKM(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫᾇ")+Wt5PeuKxa30B9qVmFYEvloIS7Ur6T+aenpKvQCGVzhLXEdWiDIZ(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬᾈ")+url+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩᾉ")+B17r2fdFy9ns8tiOMLu+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࠤࡢࠦࠠࠡࠢࠣࠤ࡛࡯ࡤࡦࡱࡶ࠾ࠥࡡࠠࠨᾊ")+str(ss7YGDbuAIxgnqaQroTV)+BWfpRku7SsM6cbE0eG(u"ࠫࠥࡣࠧᾋ"))
	else:
		VBAGZ9tRDEIK3 = GVurlv8HeoXEzPRiQB7Ty(u"ࠬࠦࠠࠡࡇࡵࡶࡴࡸࡳ࠻ࠢ࡞ࠤࠬᾌ")+Hi64ZlMGdDw5XN8hIfVKq10RkJ+Js61GTdX5wzMurUqi7Z(u"࠭ࠠ࡞ࠩᾍ") if PPugTDGs1YHr6L8vBiEfzcS0 else sCHVtMAvqirbQ4BUK3cgWo
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧᾎ")+smh8Qbf9jH+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬᾏ")+url+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩᾐ")+B17r2fdFy9ns8tiOMLu+qqw1upCsKM(u"ࠪࠤࡢ࠭ᾑ")+VBAGZ9tRDEIK3)
	Hi64ZlMGdDw5XN8hIfVKq10RkJ = mSeoVfgRpNF9PKrJ(Hi64ZlMGdDw5XN8hIfVKq10RkJ)
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	WAwDbyNEci3daMK7hPfQRpx9C1vL[eC9s1fQEKDF4jnw0zVPrJ3db] = hDjf1Ubgq629nXlOvcFLH4Jw.time()-ofLNbsZxdtEvC0gRM2r9khzTeV
	return Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def lYwIfmpARQe5zGo(title,B17r2fdFy9ns8tiOMLu,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,source,ScEpZwINx93VJ5aWfb4=sCHVtMAvqirbQ4BUK3cgWo):
	if ss7YGDbuAIxgnqaQroTV:
		if not V9TdsglcWYv0X[BewrUo9ANCa17G43Sn0LH5xh]: V9TdsglcWYv0X = ss7YGDbuAIxgnqaQroTV
		T1AWiH6ZJ2X3Ccs = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨᾒ"))
		E4EWmXuYSIvfUzcM6adTwC0 = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬ࠳ࠧᾓ") not in T1AWiH6ZJ2X3Ccs
		while ndkUxG9LtewJ:
			if E4EWmXuYSIvfUzcM6adTwC0 and len(ss7YGDbuAIxgnqaQroTV)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: jQLzA92KFEcpw = BewrUo9ANCa17G43Sn0LH5xh
			else: jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(IO7k2hZXSz(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬᾔ"),V9TdsglcWYv0X)
			if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = SE97R3Dpj6dPLweVKU(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩᾕ")
			else:
				L4L5ni6ZNo = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
				SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧᾖ")+title+IO7k2hZXSz(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭ᾗ")+B17r2fdFy9ns8tiOMLu+oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫᾘ")+str(L4L5ni6ZNo)+BWfpRku7SsM6cbE0eG(u"ࠫࠥࡣࠧᾙ"))
				if oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨᾚ") in L4L5ni6ZNo and XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭ᾛ") in L4L5ni6ZNo:
					K4KcLWaVQETnCUM2,Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb,EPhoOUqS1MxVfbR8s6gud = DDzVvfdgeky(L4L5ni6ZNo)
					if EPhoOUqS1MxVfbR8s6gud: L4L5ni6ZNo = EPhoOUqS1MxVfbR8s6gud[BewrUo9ANCa17G43Sn0LH5xh]
					else: L4L5ni6ZNo = sCHVtMAvqirbQ4BUK3cgWo
				if not L4L5ni6ZNo: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = TzIj50KpohEOHx6CbZWqB(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᾜ")
				else: YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = CeXLtzElr5DHhs(L4L5ni6ZNo,source,ScEpZwINx93VJ5aWfb4)
			if YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z in [jwzOabysh0Z(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩᾝ"),Js61GTdX5wzMurUqi7Z(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪᾞ"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨᾟ"),gDETKVh8mZe09Nd(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ᾠ")] or len(ss7YGDbuAIxgnqaQroTV)==IOHSz7YPF9WusGgUt1Dq(u"࠴າ"): break
			elif YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z in [zLjWeKu6JgNO7vocUD0Qpy(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᾡ"),aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧᾢ"),qqw1upCsKM(u"ࠧࡵࡴ࡬ࡩࡩ࠭ᾣ")]: break
			else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Js61GTdX5wzMurUqi7Z(u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧᾤ"))
	else:
		YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = IO7k2hZXSz(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭ᾥ")
		if FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu): YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z = CeXLtzElr5DHhs(B17r2fdFy9ns8tiOMLu,source,ScEpZwINx93VJ5aWfb4)
	return YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z,ss7YGDbuAIxgnqaQroTV
def aaDJlvkPbdY1TqciuUg8NjhXtKE(url,source):
	vrEJRkchKxtDNiqO1b79mL5eT,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf,smh8Qbf9jH,ztleg931DbxSUEO6HCKTVrcZFkw,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS = url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᾦ") in url:
		vrEJRkchKxtDNiqO1b79mL5eT,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf = url.split(hPFcB6Uxmabj59Iq(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᾧ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf = cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡥ࡟ࠨᾨ")+hPFcB6Uxmabj59Iq(u"࠭࡟ࡠࠩᾩ")+oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡠࡡࠪᾪ")+IO7k2hZXSz(u"ࠨࡡࡢࠫᾫ")+oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡢࡣࠬᾬ")
		hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS,pZ3BTamb0Ilo9AsOg4 = cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf.split(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡣࡤ࠭ᾭ"))[:SIkwCEdJHTD9v1(u"࠺ຳ")]
	if not XO7Zr2W6kwieA: XO7Zr2W6kwieA = fvYGxnZNUiyP4HJkMIoS25(u"ࠫ࠵࠭ᾮ")
	else: XO7Zr2W6kwieA = XO7Zr2W6kwieA.replace(aenpKvQCGVzhLXEdWiDIZ(u"ࠬࡶࠧᾯ"),sCHVtMAvqirbQ4BUK3cgWo).replace(AAh0X3OCacr4HpifRGLZKT,sCHVtMAvqirbQ4BUK3cgWo)
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.strip(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࠿ࠨᾰ")).strip(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧ࠰ࠩᾱ")).strip(qqw1upCsKM(u"ࠨࠨࠪᾲ"))
	smh8Qbf9jH = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,jwzOabysh0Z(u"ࠩ࡫ࡳࡸࡺࠧᾳ"))
	if hoVitY5TylJ7GBEIZNOQg8pukq: ztleg931DbxSUEO6HCKTVrcZFkw = hoVitY5TylJ7GBEIZNOQg8pukq
	else: ztleg931DbxSUEO6HCKTVrcZFkw = smh8Qbf9jH
	ztleg931DbxSUEO6HCKTVrcZFkw = GABnmSFOwtsu37(ztleg931DbxSUEO6HCKTVrcZFkw,oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡲࡦࡳࡥࠨᾴ"))
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(Js61GTdX5wzMurUqi7Z(u"๊ࠫฮวีำࠪ᾵"),sCHVtMAvqirbQ4BUK3cgWo).replace(hPFcB6Uxmabj59Iq(u"ู๊ࠬาใิࠫᾶ"),sCHVtMAvqirbQ4BUK3cgWo).replace(bGzRdmOErkIylxALniq6(u"࠭วๅࠢࠪᾷ"),AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf = cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf.replace(qeG16a4pbSHziNVQ2uFXrs(u"ࠧๆสสุึ࠭Ᾰ"),sCHVtMAvqirbQ4BUK3cgWo).replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨีํีๆืࠧᾹ"),sCHVtMAvqirbQ4BUK3cgWo).replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩส่ࠥ࠭Ὰ"),AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	ztleg931DbxSUEO6HCKTVrcZFkw = ztleg931DbxSUEO6HCKTVrcZFkw.replace(zLjWeKu6JgNO7vocUD0Qpy(u"้ࠪออิาࠩΆ"),sCHVtMAvqirbQ4BUK3cgWo).replace(BWfpRku7SsM6cbE0eG(u"ุࠫ๐ัโำࠪᾼ"),sCHVtMAvqirbQ4BUK3cgWo).replace(BWfpRku7SsM6cbE0eG(u"ࠬอไࠡࠩ᾽"),AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
	return vrEJRkchKxtDNiqO1b79mL5eT,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf,smh8Qbf9jH,ztleg931DbxSUEO6HCKTVrcZFkw,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS
def FL3YSRq1tBAbxckNUOrugiVv5dla4(url,source):
	Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,UUq3preLtbT8foQEaHWz5AGh,Hv5hjWtP8lKGuZr7eOB2w0oJ,ijHD7XCGFzh0,JJCBn7FaOociDjUp0P9EW5ruzVQ,Wt5PeuKxa30B9qVmFYEvloIS7Ur6T = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK
	vrEJRkchKxtDNiqO1b79mL5eT,cj9nTYrXlitoVZEPU8JaWxMF1Ah5yf,smh8Qbf9jH,ztleg931DbxSUEO6HCKTVrcZFkw,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS = aaDJlvkPbdY1TqciuUg8NjhXtKE(url,source)
	if IO7k2hZXSz(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧι") in url:
		if   ScEpZwINx93VJ5aWfb4==IO7k2hZXSz(u"ࠧࡦ࡯ࡥࡩࡩ࠭᾿"): ScEpZwINx93VJ5aWfb4 = AAh0X3OCacr4HpifRGLZKT+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ็ไฺ้࠭῀")
		elif ScEpZwINx93VJ5aWfb4==SIkwCEdJHTD9v1(u"ࠩࡺࡥࡹࡩࡨࠨ῁"): ScEpZwINx93VJ5aWfb4 = AAh0X3OCacr4HpifRGLZKT+BWfpRku7SsM6cbE0eG(u"ฺ๊ࠪࠩว่ัฬࠫῂ")
		elif ScEpZwINx93VJ5aWfb4==qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡧࡵࡴࡩࠩῃ"): ScEpZwINx93VJ5aWfb4 = AAh0X3OCacr4HpifRGLZKT+aenpKvQCGVzhLXEdWiDIZ(u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧῄ")
		elif ScEpZwINx93VJ5aWfb4==aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ῅"): ScEpZwINx93VJ5aWfb4 = AAh0X3OCacr4HpifRGLZKT+IOHSz7YPF9WusGgUt1Dq(u"ࠧࠦࠧࠨฮา๋๊ๅࠩῆ")
		elif ScEpZwINx93VJ5aWfb4==sCHVtMAvqirbQ4BUK3cgWo: ScEpZwINx93VJ5aWfb4 = AAh0X3OCacr4HpifRGLZKT+gDETKVh8mZe09Nd(u"ࠨࠧࠨࠩࠪ࠭ῇ")
		if ccDFuk5NAjMTqo3hv!=sCHVtMAvqirbQ4BUK3cgWo:
			if RDwahqjPfbdyEiTtnLQu(u"ࠩࡰࡴ࠹࠭Ὲ") not in ccDFuk5NAjMTqo3hv: ccDFuk5NAjMTqo3hv = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࠩࠬΈ")+ccDFuk5NAjMTqo3hv
			ccDFuk5NAjMTqo3hv = AAh0X3OCacr4HpifRGLZKT+ccDFuk5NAjMTqo3hv
		if XO7Zr2W6kwieA!=sCHVtMAvqirbQ4BUK3cgWo:
			XO7Zr2W6kwieA = fvYGxnZNUiyP4HJkMIoS25(u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧῊ")+XO7Zr2W6kwieA
			XO7Zr2W6kwieA = AAh0X3OCacr4HpifRGLZKT+XO7Zr2W6kwieA[-jwzOabysh0Z(u"࠾ິ"):]
	if   qqw1upCsKM(u"ࠬࡇࡋࡐࡃࡐࠫΉ")		in source: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡁࡌ࡙ࡄࡑࠬῌ")		in source and XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡕࡗࡅࡉࠬ῍") not in source: UUq3preLtbT8foQEaHWz5AGh	= Js61GTdX5wzMurUqi7Z(u"ࠨࡣ࡮ࡻࡦࡳࠧ῎")
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ῏")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif Js61GTdX5wzMurUqi7Z(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩῐ")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif SIkwCEdJHTD9v1(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ῑ")		in source: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬῒ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif YQNd4wejLSAVJ6T(u"࠭ࡦࡢࡵࡨࡰࠬΐ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif TzIj50KpohEOHx6CbZWqB(u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ῔")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ῕")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫῖ")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡪࡦࡰࡥࡳࠩῗ")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫๆาัࠨῘ")			in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= qeG16a4pbSHziNVQ2uFXrs(u"ࠬ࡬ࡡ࡫ࡧࡵࠫῙ")
	elif t19ZOVHA4CpwFKaeiubcMGvz(u"࠭แๅีฺ๎๋࠭Ὶ")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= TzIj50KpohEOHx6CbZWqB(u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪΊ")
	elif SIkwCEdJHTD9v1(u"ࠨࡩࡧࡶ࡮ࡼࡥࠨ῜")		in vrEJRkchKxtDNiqO1b79mL5eT:   UUq3preLtbT8foQEaHWz5AGh	= t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩ῝")
	elif Js61GTdX5wzMurUqi7Z(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ῞")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ῟")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ῠ")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif GVurlv8HeoXEzPRiQB7Ty(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧῡ")		in hoVitY5TylJ7GBEIZNOQg8pukq:   UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif Js61GTdX5wzMurUqi7Z(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬῢ")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡤࡲ࡯ࡷࡧࠧΰ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif TzIj50KpohEOHx6CbZWqB(u"ࠩࡷࡺ࡫ࡻ࡮ࠨῤ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif gDETKVh8mZe09Nd(u"ࠪࡸࡻࡱࡳࡢࠩῥ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬῦ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧῧ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif TzIj50KpohEOHx6CbZWqB(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨῨ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩῩ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨῪ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif hPFcB6Uxmabj59Iq(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩΎ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif jwzOabysh0Z(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬῬ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif SE97R3Dpj6dPLweVKU(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭῭")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif qqw1upCsKM(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭΅")	 	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡲࡦࡦࡰࡳࡩࡾࠧ`")
	elif IOHSz7YPF9WusGgUt1Dq(u"ࠧࡺࡱࡸࡸࡺ࠭῰")	 	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ῱")
	elif sH6BOz5wKRFcEg(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩῲ")	 	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫῳ")
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪῴ")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif BWfpRku7SsM6cbE0eG(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪ῵")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= sH6BOz5wKRFcEg(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪῶ")
	elif SE97R3Dpj6dPLweVKU(u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩῷ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪῸ")
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪΌ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬῺ")
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭Ώ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧῼ")
	elif SE97R3Dpj6dPLweVKU(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ´")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= bGzRdmOErkIylxALniq6(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭῾")
	elif SE97R3Dpj6dPLweVKU(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ῿")	in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= hPFcB6Uxmabj59Iq(u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫࠀ")
	elif IOHSz7YPF9WusGgUt1Dq(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ࠁ")		in smh8Qbf9jH: UUq3preLtbT8foQEaHWz5AGh	= Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧࠂ")
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪࠃ")	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫࠄ")
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪࠅ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫࠆ")
	elif t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭ࠇ")	 	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡩࡡࡵࡥ࡫ࠫࠈ")
	elif fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧࠉ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= BWfpRku7SsM6cbE0eG(u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨࠊ")
	elif qqw1upCsKM(u"ࠨࡸ࡬ࡨࡧࡳࠧࠋ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡹ࡭ࡩࡨ࡭ࠨࠌ")
	elif gDETKVh8mZe09Nd(u"ࠪࡺ࡮ࡪࡨࡥࠩࠍ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif BWfpRku7SsM6cbE0eG(u"ࠫࡲࡿࡶࡪࡦࠪࠎ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif sH6BOz5wKRFcEg(u"ࠬࡳࡹࡷ࡫࡬ࡨࠬࠏ")		in smh8Qbf9jH: JJCBn7FaOociDjUp0P9EW5ruzVQ	= ztleg931DbxSUEO6HCKTVrcZFkw
	elif qqw1upCsKM(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨࠐ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= hPFcB6Uxmabj59Iq(u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩࠑ")
	elif IO7k2hZXSz(u"ࠨࡩࡲࡺ࡮ࡪࠧࠒ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡪࡳࡻ࡯ࡤࠨࠓ")
	elif YQNd4wejLSAVJ6T(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬࠔ") 	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭ࠕ")
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨࠖ")	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= oVwa0kcqxj1e7mLplAfZdGT(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩࠗ")
	elif bGzRdmOErkIylxALniq6(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ࠘")	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭࠙")
	elif EJgYdjbIiWe1apkQlZcR42(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ࠚ") 	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧࠛ")
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬࠜ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= jwzOabysh0Z(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ࠝ")
	elif hPFcB6Uxmabj59Iq(u"࠭ࡵࡱࡲࠪࠞ") 			in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= SE97R3Dpj6dPLweVKU(u"ࠧࡶࡲࡥࡳࡲ࠭ࠟ")
	elif SIkwCEdJHTD9v1(u"ࠨࡷࡳࡦࠬࠠ") 			in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡸࡴࡧࡵ࡭ࠨࠡ")
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪࠢ") 		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫࠣ")
	elif IO7k2hZXSz(u"ࠬࡼ࡫ࠨࠤ") 			in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡶ࡬ࠩࠥ")
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩࠦ") 	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= jwzOabysh0Z(u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪࠧ")
	elif qqw1upCsKM(u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩࠨ")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪࠩ")
	elif jwzOabysh0Z(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫࠪ") 		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡼࡩࡥࡱࡽࡥࠬࠫ")
	elif Js61GTdX5wzMurUqi7Z(u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪࠬ") 	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= YQNd4wejLSAVJ6T(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ࠭")
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ࠮")	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= Js61GTdX5wzMurUqi7Z(u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭࠯")
	elif EJgYdjbIiWe1apkQlZcR42(u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ࠰")	in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= EJgYdjbIiWe1apkQlZcR42(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ࠱")
	elif hPFcB6Uxmabj59Iq(u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬ࠲")		in smh8Qbf9jH: Hv5hjWtP8lKGuZr7eOB2w0oJ	= XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡨࡥ࠯ࡦࡨࡳ࠭࠳")
	if   UUq3preLtbT8foQEaHWz5AGh:	Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧฯษุࠫ࠴"),UUq3preLtbT8foQEaHWz5AGh
	elif JJCBn7FaOociDjUp0P9EW5ruzVQ:		Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = bGzRdmOErkIylxALniq6(u"ࠨ่ࠧัิีࠧ࠵"),JJCBn7FaOociDjUp0P9EW5ruzVQ
	elif Hv5hjWtP8lKGuZr7eOB2w0oJ:		Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = fvYGxnZNUiyP4HJkMIoS25(u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ࠶"),Hv5hjWtP8lKGuZr7eOB2w0oJ
	elif ijHD7XCGFzh0:	Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = gDETKVh8mZe09Nd(u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ࠷"),ijHD7XCGFzh0
	elif Wt5PeuKxa30B9qVmFYEvloIS7Ur6T:	Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ࠸"),ztleg931DbxSUEO6HCKTVrcZFkw
	else:			Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭࠹"),ztleg931DbxSUEO6HCKTVrcZFkw
	return Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA
def EKpLfBMgnV7lqib(JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV):
	J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8 = [],[]
	for title,B17r2fdFy9ns8tiOMLu in list(zip(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV)):
		if FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu):
			J4EIW0hU16YCcqn92uatb3.append(title)
			PXFtqmw5lBGQNa0IV8.append(B17r2fdFy9ns8tiOMLu)
	if not PXFtqmw5lBGQNa0IV8 and not JbShzsakZ5M1i: JbShzsakZ5M1i = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡆࡢ࡫࡯ࡩࡩ࠭࠺")
	return JbShzsakZ5M1i,J4EIW0hU16YCcqn92uatb3,PXFtqmw5lBGQNa0IV8
def Lr6Q0Jxgy5S3GTDREYkls(url,source):
	vrEJRkchKxtDNiqO1b79mL5eT,JJCBn7FaOociDjUp0P9EW5ruzVQ,smh8Qbf9jH,ztleg931DbxSUEO6HCKTVrcZFkw,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS = aaDJlvkPbdY1TqciuUg8NjhXtKE(url,source)
	if   Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡺࡱࡸࡸࡺ࠭࠻")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࠼"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	elif bGzRdmOErkIylxALniq6(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ࠽")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࠾"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡦࡲࡢࡢࡲ࡯ࡥࡾ࡫ࡲࠨ࠿")	in vrEJRkchKxtDNiqO1b79mL5eT  : JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = T2YLaVWXG60qgKeQmI(vrEJRkchKxtDNiqO1b79mL5eT)
	elif IOHSz7YPF9WusGgUt1Dq(u"ࠬࡇࡋࡐࡃࡐࠫࡀ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = Tj607v5yLp(vrEJRkchKxtDNiqO1b79mL5eT,hoVitY5TylJ7GBEIZNOQg8pukq)
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡁࡌ࡙ࡄࡑࠬࡁ")		in source and jwzOabysh0Z(u"ࠧࡕࡗࡅࡉࠬࡂ") not in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = jARZX7M1ml(vrEJRkchKxtDNiqO1b79mL5eT,ScEpZwINx93VJ5aWfb4,XO7Zr2W6kwieA)
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪࡃ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = AjNmfn13zT(vrEJRkchKxtDNiqO1b79mL5eT)
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫࡄ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = V7UpJAqcw2(vrEJRkchKxtDNiqO1b79mL5eT)
	elif IO7k2hZXSz(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫࡅ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࡆ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬࡇ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = iZ67teKPJ2(vrEJRkchKxtDNiqO1b79mL5eT)
	elif IO7k2hZXSz(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨࡈ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = QEwz0xoOij(vrEJRkchKxtDNiqO1b79mL5eT)
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩࡉ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = wNUC3haOcZ(vrEJRkchKxtDNiqO1b79mL5eT)
	elif phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪࡊ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = F9iSmYecgb(vrEJRkchKxtDNiqO1b79mL5eT)
	elif t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡖࡌࡔࡌࡈࡂࠩࡋ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = q0Y34fJ7Uc(vrEJRkchKxtDNiqO1b79mL5eT,ScEpZwINx93VJ5aWfb4,JJCBn7FaOociDjUp0P9EW5ruzVQ)
	elif RDwahqjPfbdyEiTtnLQu(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬࡌ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = pptqZhrQWd(vrEJRkchKxtDNiqO1b79mL5eT,jcZbnfXTDoymgClJqYiABS)
	elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫࡍ")		in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = zqxwGS0RVE(vrEJRkchKxtDNiqO1b79mL5eT)
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩࡎ")	in source: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = W8pDvYTJXN(vrEJRkchKxtDNiqO1b79mL5eT)
	elif IO7k2hZXSz(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨࡏ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = LLxy1itIZw(vrEJRkchKxtDNiqO1b79mL5eT)
	elif bGzRdmOErkIylxALniq6(u"ࠧࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪࡐ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = q2Z5n1Y0lG(vrEJRkchKxtDNiqO1b79mL5eT)
	elif jwzOabysh0Z(u"ࠨࡣ࡯ࡥࡷࡧࡢࠨࡑ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = y8U12BpqlL37oKXYa6rswHmb(vrEJRkchKxtDNiqO1b79mL5eT)
	elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫࡒ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = n8RHJpFYok(vrEJRkchKxtDNiqO1b79mL5eT)
	elif qqw1upCsKM(u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬࡓ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = n8RHJpFYok(vrEJRkchKxtDNiqO1b79mL5eT)
	elif bGzRdmOErkIylxALniq6(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫࡔ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = yMvNSb80wf(vrEJRkchKxtDNiqO1b79mL5eT)
	elif aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡺࡶࡧࡷࡱࠫࡕ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ygrODsPR43(vrEJRkchKxtDNiqO1b79mL5eT)
	elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡴࡷ࡭ࡶࡥࠬࡖ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ygrODsPR43(vrEJRkchKxtDNiqO1b79mL5eT)
	elif iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡵࡸ࠰ࡪ࠳ࡩ࡯࡮ࠩࡗ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ygrODsPR43(vrEJRkchKxtDNiqO1b79mL5eT)
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪࡘ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = xb2NoaQ9Zy(vrEJRkchKxtDNiqO1b79mL5eT)
	elif YQNd4wejLSAVJ6T(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲ࡙ࠫ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = q9qglSBkTG(vrEJRkchKxtDNiqO1b79mL5eT)
	elif SE97R3Dpj6dPLweVKU(u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴ࡚ࠬ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = kTczPeGDXdyipfhjSv2rQ0xVWmgJZC(vrEJRkchKxtDNiqO1b79mL5eT)
	elif TzIj50KpohEOHx6CbZWqB(u"ࠫࡻࡹ࠴ࡶ࡛ࠩ")			in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = tiYMKpXwQd(vrEJRkchKxtDNiqO1b79mL5eT)
	elif aenpKvQCGVzhLXEdWiDIZ(u"ࠬ࡬ࡡ࡫ࡧࡵࠫ࡜")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = dmn76SaZ0E(vrEJRkchKxtDNiqO1b79mL5eT)
	elif YQNd4wejLSAVJ6T(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ࡝")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = l1lgZCVGrv(vrEJRkchKxtDNiqO1b79mL5eT)
	elif zLjWeKu6JgNO7vocUD0Qpy(u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ࡞")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = l1lgZCVGrv(vrEJRkchKxtDNiqO1b79mL5eT)
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡥ࡬ࡱࡦ࠳࡬ࡪࡩ࡫ࡸࠬ࡟")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = yhdRrYV18l(vrEJRkchKxtDNiqO1b79mL5eT)
	elif gDETKVh8mZe09Nd(u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬࡠ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = yhdRrYV18l(vrEJRkchKxtDNiqO1b79mL5eT)
	elif SE97R3Dpj6dPLweVKU(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪࡡ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = x9hXV5TpjR(vrEJRkchKxtDNiqO1b79mL5eT)
	elif hPFcB6Uxmabj59Iq(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫࡢ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ww0XZepxIaWkygRHdUPN3qcVojQ(vrEJRkchKxtDNiqO1b79mL5eT)
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡨ࡯࡬ࡴࡤࠫࡣ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = hhLbd2NzOM(vrEJRkchKxtDNiqO1b79mL5eT)
	elif iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫࡤ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = mf9uYb3GgD(vrEJRkchKxtDNiqO1b79mL5eT)
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩࡥ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = F9YthIPSBJ(vrEJRkchKxtDNiqO1b79mL5eT)
	elif E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧࡦ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = JJpkL4ZuSH(vrEJRkchKxtDNiqO1b79mL5eT)
	elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧࡧ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	elif qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫࡨ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = TAFQaICyVY(vrEJRkchKxtDNiqO1b79mL5eT)
	elif IO7k2hZXSz(u"ࠫࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠪࡩ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = nE2ZGVzOhD(vrEJRkchKxtDNiqO1b79mL5eT)
	elif Js61GTdX5wzMurUqi7Z(u"ࠬࡻࡰࡣࡣࡰࠫࡪ") 		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	else: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࡫"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	if not JbShzsakZ5M1i and not ss7YGDbuAIxgnqaQroTV: JbShzsakZ5M1i = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷ࠠࡇࡣ࡬ࡰࡺࡸࡥࠨ࡬")
	elif JbShzsakZ5M1i not in [sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࡭"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࡮")]: JbShzsakZ5M1i = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭࡯")+JbShzsakZ5M1i
	return JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def ZPWtLCpzSDR92c(Hi64ZlMGdDw5XN8hIfVKq10RkJ,url,source,eC9s1fQEKDF4jnw0zVPrJ3db):
	global y82bKWI6n1,nn4cTU9V6zujRfkC5,qKj4oFagTbmAnLR,Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G,vvPBtc3a5jGXURnNSyluAsOgC6Yx
	C4Ci79LKzmMnP = []
	for Wt5PeuKxa30B9qVmFYEvloIS7Ur6T in [nn4cTU9V6zujRfkC5,qKj4oFagTbmAnLR,Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G,vvPBtc3a5jGXURnNSyluAsOgC6Yx]: Wt5PeuKxa30B9qVmFYEvloIS7Ur6T[eC9s1fQEKDF4jnw0zVPrJ3db] = SIkwCEdJHTD9v1(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬࡰ"),[],[]
	ST4dU5Mkbfs68CLKWGitQrz,OIYA4sTfrlNv90 = [pHTSuQVY9UiG7BzxCqtFX52Kd8f,HEkd6aBMwOuxciWI2DhNr,JYUlXs6pkTto7w49DfxL0NjWma1,wNe8I9gx4BhSJR6GAz],[]
	if SIkwCEdJHTD9v1(u"ࠬ࡬ࡲࡥ࡮ࠪࡱ") in url: ST4dU5Mkbfs68CLKWGitQrz,OIYA4sTfrlNv90 = [pHTSuQVY9UiG7BzxCqtFX52Kd8f,HEkd6aBMwOuxciWI2DhNr,wNe8I9gx4BhSJR6GAz],[Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G]
	if TzIj50KpohEOHx6CbZWqB(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧࡲ") in url: ST4dU5Mkbfs68CLKWGitQrz,OIYA4sTfrlNv90 = [pHTSuQVY9UiG7BzxCqtFX52Kd8f],[qKj4oFagTbmAnLR,Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G,vvPBtc3a5jGXURnNSyluAsOgC6Yx]
	for Wt5PeuKxa30B9qVmFYEvloIS7Ur6T in OIYA4sTfrlNv90: Wt5PeuKxa30B9qVmFYEvloIS7Ur6T[eC9s1fQEKDF4jnw0zVPrJ3db] = Js61GTdX5wzMurUqi7Z(u"ࠧࡔ࡭࡬ࡴࡵ࡫ࡤࠨࡳ"),[],[]
	for Wt5PeuKxa30B9qVmFYEvloIS7Ur6T in ST4dU5Mkbfs68CLKWGitQrz:
		t2thfclTmSpkgF = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=Wt5PeuKxa30B9qVmFYEvloIS7Ur6T,args=(url,source,eC9s1fQEKDF4jnw0zVPrJ3db))
		C4Ci79LKzmMnP.append(t2thfclTmSpkgF)
	def taxU7Nu8OfyQFwI3Gp2mKvWPbg5V6():
		Y4jr0mxaOyuiUPb,MQXDxIN1mH,euIv8rzHwXWVB,p9fMGLjuy3ClPa0QYek = lvzrYTpcBaK,lvzrYTpcBaK,lvzrYTpcBaK,lvzrYTpcBaK
		kChFiqwubnHNMpUls,title,B17r2fdFy9ns8tiOMLu = nn4cTU9V6zujRfkC5[eC9s1fQEKDF4jnw0zVPrJ3db]
		if (B17r2fdFy9ns8tiOMLu and not kChFiqwubnHNMpUls) or (kChFiqwubnHNMpUls and kChFiqwubnHNMpUls!=E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩࡴ")): Y4jr0mxaOyuiUPb = ndkUxG9LtewJ
		kChFiqwubnHNMpUls,title,B17r2fdFy9ns8tiOMLu = qKj4oFagTbmAnLR[eC9s1fQEKDF4jnw0zVPrJ3db]
		if (B17r2fdFy9ns8tiOMLu and not kChFiqwubnHNMpUls) or (kChFiqwubnHNMpUls and kChFiqwubnHNMpUls!=XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪࡵ")): MQXDxIN1mH = ndkUxG9LtewJ
		kChFiqwubnHNMpUls,title,B17r2fdFy9ns8tiOMLu = Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G[eC9s1fQEKDF4jnw0zVPrJ3db]
		if (B17r2fdFy9ns8tiOMLu and not kChFiqwubnHNMpUls) or (kChFiqwubnHNMpUls and kChFiqwubnHNMpUls!=EJgYdjbIiWe1apkQlZcR42(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫࡶ")): euIv8rzHwXWVB = ndkUxG9LtewJ
		kChFiqwubnHNMpUls,title,B17r2fdFy9ns8tiOMLu = vvPBtc3a5jGXURnNSyluAsOgC6Yx[eC9s1fQEKDF4jnw0zVPrJ3db]
		if (B17r2fdFy9ns8tiOMLu and not kChFiqwubnHNMpUls) or (kChFiqwubnHNMpUls and kChFiqwubnHNMpUls!=fvYGxnZNUiyP4HJkMIoS25(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬࡷ")): p9fMGLjuy3ClPa0QYek = ndkUxG9LtewJ
		vfrjqSsdFHxQOBtEl1uJ = all([Y4jr0mxaOyuiUPb,MQXDxIN1mH,euIv8rzHwXWVB,p9fMGLjuy3ClPa0QYek])
		sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying() if Q1siCkTZyw.resolveonly else ndkUxG9LtewJ
		return vfrjqSsdFHxQOBtEl1uJ or not sxjn4kIyMur8fw9KUTFDiB3
	Tgpqkx7DH6w30r(C4Ci79LKzmMnP,AAwX4J3uM1fH59mIhkBqexLSKyzb,favJM9wCN6Q1BxjmVUP,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,taxU7Nu8OfyQFwI3Gp2mKvWPbg5V6)
	succeeded = sH6BOz5wKRFcEg(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫࡸ")
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = nn4cTU9V6zujRfkC5[eC9s1fQEKDF4jnw0zVPrJ3db]
	ss7YGDbuAIxgnqaQroTV = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	if JbShzsakZ5M1i==EJgYdjbIiWe1apkQlZcR42(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡹ") or ss7YGDbuAIxgnqaQroTV: return succeeded,JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	Hi64ZlMGdDw5XN8hIfVKq10RkJ += sH6BOz5wKRFcEg(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠡࠩࡺ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)[:fvYGxnZNUiyP4HJkMIoS25(u"࠾࠰ີ")]
	succeeded = gDETKVh8mZe09Nd(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧࡻ")
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = qKj4oFagTbmAnLR[eC9s1fQEKDF4jnw0zVPrJ3db]
	ss7YGDbuAIxgnqaQroTV = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	if JbShzsakZ5M1i==SE97R3Dpj6dPLweVKU(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࡼ") or ss7YGDbuAIxgnqaQroTV: return succeeded,JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	Hi64ZlMGdDw5XN8hIfVKq10RkJ += qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠤࠬࡽ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)[:EJgYdjbIiWe1apkQlZcR42(u"࠸࠱ຶ")]
	succeeded = YQNd4wejLSAVJ6T(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪࡾ")
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G[eC9s1fQEKDF4jnw0zVPrJ3db]
	ss7YGDbuAIxgnqaQroTV = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	if JbShzsakZ5M1i==hPFcB6Uxmabj59Iq(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࡿ") or ss7YGDbuAIxgnqaQroTV: return succeeded,JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	Hi64ZlMGdDw5XN8hIfVKq10RkJ += TzIj50KpohEOHx6CbZWqB(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠸࠿ࠦࠠࠨࢀ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)[:phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠹࠲ື")]
	succeeded = hPFcB6Uxmabj59Iq(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠺࠭ࢁ")
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = vvPBtc3a5jGXURnNSyluAsOgC6Yx[eC9s1fQEKDF4jnw0zVPrJ3db]
	ss7YGDbuAIxgnqaQroTV = h0EVKGQIBvg1CtUF2mTui(ss7YGDbuAIxgnqaQroTV)
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	if JbShzsakZ5M1i==EJgYdjbIiWe1apkQlZcR42(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࢂ") or ss7YGDbuAIxgnqaQroTV: return succeeded,JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	Hi64ZlMGdDw5XN8hIfVKq10RkJ += wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠵࠻ࠢࠣࠫࢃ")+JbShzsakZ5M1i.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)[:jwzOabysh0Z(u"࠺࠳ຸ")]
	y82bKWI6n1[eC9s1fQEKDF4jnw0zVPrJ3db] = Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	return succeeded,Hi64ZlMGdDw5XN8hIfVKq10RkJ,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def pHTSuQVY9UiG7BzxCqtFX52Kd8f(url,source,eC9s1fQEKDF4jnw0zVPrJ3db):
	vrEJRkchKxtDNiqO1b79mL5eT,JJCBn7FaOociDjUp0P9EW5ruzVQ,smh8Qbf9jH,ztleg931DbxSUEO6HCKTVrcZFkw,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,jcZbnfXTDoymgClJqYiABS = aaDJlvkPbdY1TqciuUg8NjhXtKE(url,source)
	ss7YGDbuAIxgnqaQroTV = []
	if qqw1upCsKM(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨࢄ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = mf9uYb3GgD(url)
	elif qqw1upCsKM(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡹࡸ࡫ࡲࡤࡱࠪࢅ") in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = kkeMOjvm7cXF(url)
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡿ࡯ࡶࡶࡸࠫࢆ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = nmITaXcljkPYM(url)
	elif RDwahqjPfbdyEiTtnLQu(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭ࢇ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = nmITaXcljkPYM(url)
	elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭࢈")	in url   : JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = tQzym80gXnr2vjV(url)
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪࢉ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = DDzVvfdgeky(url)
	elif Js61GTdX5wzMurUqi7Z(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪࢊ")		in url   : JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = AjNmfn13zT(url)
	elif aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭ࢋ")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = yymfrBhUikM6sA7wo2eHFNcn9TY(url)
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬࢌ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = gx5yt6po1JCmdsTzPFBZ7OvYckw4Uh(url)
	elif qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ࢍ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = dagRGEpQwmHPIlKvYrW9xtuZ(url)
	elif hPFcB6Uxmabj59Iq(u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭ࢎ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = R6QGI9PdmXt(url)
	elif phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭࢏")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sGKHk6FQSynwrqv1T4e58Eo3O(url)
	elif SIkwCEdJHTD9v1(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ࢐")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sGKHk6FQSynwrqv1T4e58Eo3O(url)
	elif qqw1upCsKM(u"ࠩࡸࡴࡧࡧ࡭ࠨ࢑") 		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	elif fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ࢒") 	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = HHEymeCxoNY3s(url)
	elif EJgYdjbIiWe1apkQlZcR42(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ࢓")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = ee3IWH4taxSDJ5FscGlARVidgOqm(url)
	elif YQNd4wejLSAVJ6T(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ࢔") 	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = E7rbaKcWdp852HeilwzNIXDtMY9(url)
	elif bGzRdmOErkIylxALniq6(u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ࢕")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = C26pQc1wHYT7eFSzsNugLfhod(url)
	elif BWfpRku7SsM6cbE0eG(u"ࠧࡶࡲࡥࠫ࢖") 			in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = llb0GQWFiusfn1P49(url)
	elif oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡷࡳࡴࠬࢗ") 			in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = llb0GQWFiusfn1P49(url)
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡸࡵࡱࡵࡡࡥࠩ࢘") 		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = T2qmsON9Gdp(url)
	elif EJgYdjbIiWe1apkQlZcR42(u"ࠪࡺࡰ࢙࠭")	 		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = C580OnlQcx7veMwUoJjsiyqDpzg9b(vrEJRkchKxtDNiqO1b79mL5eT)
	elif Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࢚࠭") 	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = lvWsDdUpkqZ(url)
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡼࡩࡥࡤࡲࡦ࢛ࠬ")		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = IH8J1pOMvqaFA7L(url)
	elif SE97R3Dpj6dPLweVKU(u"࠭ࡶࡪࡦࡲࡾࡦ࠭࢜") 		in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = MMKgQNDkWRYF(url)
	elif RDwahqjPfbdyEiTtnLQu(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ࢝") 	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = bRFCyLBgtolzVH28rsdYqwU4(url)
	elif BWfpRku7SsM6cbE0eG(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ࢞")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sRIMoWQFbOycT5hSVJEBkL1(url)
	elif SE97R3Dpj6dPLweVKU(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭࢟")	in smh8Qbf9jH: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = P0RtZUW9yIKdvfXg(url)
	else: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[],[]
	global nn4cTU9V6zujRfkC5
	if not JbShzsakZ5M1i and not ss7YGDbuAIxgnqaQroTV: JbShzsakZ5M1i = sH6BOz5wKRFcEg(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠴ࠣࡊࡦ࡯࡬ࡶࡴࡨࠫࢠ")
	elif JbShzsakZ5M1i not in [sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢡ"),BWfpRku7SsM6cbE0eG(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࢢ")]: JbShzsakZ5M1i = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࢣ")+JbShzsakZ5M1i
	nn4cTU9V6zujRfkC5[eC9s1fQEKDF4jnw0zVPrJ3db] = JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	return
def HEkd6aBMwOuxciWI2DhNr(url,source,eC9s1fQEKDF4jnw0zVPrJ3db):
	global qKj4oFagTbmAnLR
	if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨࢤ") in url:
		qKj4oFagTbmAnLR[eC9s1fQEKDF4jnw0zVPrJ3db] = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡗࡰ࡯ࡰࡱࡧࡧࠫࢥ"),[],[]
		return
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[],[]
	if FA0Y1k9va5O2zmU6By(url):
		JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	if not ss7YGDbuAIxgnqaQroTV:
		JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = JLbp71YOovU(url)
	if not ss7YGDbuAIxgnqaQroTV:
		JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = JJqiRCW6DHKfkV0wgEGO3nAXY1(url)
	if not ss7YGDbuAIxgnqaQroTV:
		if JbShzsakZ5M1i==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࢦ"): JbShzsakZ5M1i = sCHVtMAvqirbQ4BUK3cgWo
		JbShzsakZ5M1i = Js61GTdX5wzMurUqi7Z(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࢧ")+JbShzsakZ5M1i if JbShzsakZ5M1i else aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶ࠤࡋࡧࡩ࡭ࡷࡵࡩࠬࢨ")
	qKj4oFagTbmAnLR[eC9s1fQEKDF4jnw0zVPrJ3db] = JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	return
def JYUlXs6pkTto7w49DfxL0NjWma1(url,source,eC9s1fQEKDF4jnw0zVPrJ3db):
	Ro2CsQFGOj14wKIgcuHJ = sCHVtMAvqirbQ4BUK3cgWo
	ka7jz96YCdTBnQOLVPuJG3285MHf = lvzrYTpcBaK
	try:
		import resolveurl as bimfUl12qk7ZzKyjv
		ka7jz96YCdTBnQOLVPuJG3285MHf = bimfUl12qk7ZzKyjv.resolve(url)
	except Exception as kChFiqwubnHNMpUls: Ro2CsQFGOj14wKIgcuHJ = str(kChFiqwubnHNMpUls)
	global Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G
	if not ka7jz96YCdTBnQOLVPuJG3285MHf:
		if Ro2CsQFGOj14wKIgcuHJ==sCHVtMAvqirbQ4BUK3cgWo:
			Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
			if Ro2CsQFGOj14wKIgcuHJ!=GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨࢩ"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
		JbShzsakZ5M1i = Ro2CsQFGOj14wKIgcuHJ.splitlines()[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G[eC9s1fQEKDF4jnw0zVPrJ3db] = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࢪ")+JbShzsakZ5M1i,[],[]
		return
	Q6VR7fpbJuLTyZdznOjI1kDr8cBS3G[eC9s1fQEKDF4jnw0zVPrJ3db] = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ka7jz96YCdTBnQOLVPuJG3285MHf]
	return
def wNe8I9gx4BhSJR6GAz(url,source,eC9s1fQEKDF4jnw0zVPrJ3db):
	Ro2CsQFGOj14wKIgcuHJ = sCHVtMAvqirbQ4BUK3cgWo
	ka7jz96YCdTBnQOLVPuJG3285MHf = lvzrYTpcBaK
	try:
		import yt_dlp as w5iuK1fBe26GZ7mElbL
		nNGpcwvJE32KFdl46ZBgH5DQWS = w5iuK1fBe26GZ7mElbL.YoutubeDL({phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩࢫ"): ndkUxG9LtewJ})
		ka7jz96YCdTBnQOLVPuJG3285MHf = nNGpcwvJE32KFdl46ZBgH5DQWS.extract_info(url,download=lvzrYTpcBaK)
	except Exception as kChFiqwubnHNMpUls: Ro2CsQFGOj14wKIgcuHJ = str(kChFiqwubnHNMpUls)
	global vvPBtc3a5jGXURnNSyluAsOgC6Yx
	if not ka7jz96YCdTBnQOLVPuJG3285MHf or SIkwCEdJHTD9v1(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩࢬ") not in list(ka7jz96YCdTBnQOLVPuJG3285MHf.keys()):
		if Ro2CsQFGOj14wKIgcuHJ==sCHVtMAvqirbQ4BUK3cgWo:
			Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
			if Ro2CsQFGOj14wKIgcuHJ!=Js61GTdX5wzMurUqi7Z(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬࢭ"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
		JbShzsakZ5M1i = Ro2CsQFGOj14wKIgcuHJ.splitlines()[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		vvPBtc3a5jGXURnNSyluAsOgC6Yx[eC9s1fQEKDF4jnw0zVPrJ3db] = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࢮ")+JbShzsakZ5M1i,[],[]
	else:
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
		for B17r2fdFy9ns8tiOMLu in ka7jz96YCdTBnQOLVPuJG3285MHf[RDwahqjPfbdyEiTtnLQu(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬࢯ")]:
			V9TdsglcWYv0X.append(B17r2fdFy9ns8tiOMLu[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬࢰ")])
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu[aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡵࡳ࡮ࠪࢱ")])
		vvPBtc3a5jGXURnNSyluAsOgC6Yx[eC9s1fQEKDF4jnw0zVPrJ3db] = sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	return
def JLbp71YOovU(url,headers=sCHVtMAvqirbQ4BUK3cgWo):
	if not headers:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,bGzRdmOErkIylxALniq6(u"ࠧࡈࡇࡗࠫࢲ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡄࡊࡔࡈࡇ࡙ࡥࡕࡓࡎ࠰࠵ࡸࡺࠧࢳ"))
		headers = UHqibFEGL8fjKhI.headers
	B17r2fdFy9ns8tiOMLu = headers.get(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࢴ")) or headers.get(oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬࢵ")) or sCHVtMAvqirbQ4BUK3cgWo
	if B17r2fdFy9ns8tiOMLu and FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu): return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧࢶ"),[],[]
def h0EVKGQIBvg1CtUF2mTui(fH6PnGusaZ4M0Vb):
	if isinstance(fH6PnGusaZ4M0Vb,list):
		PXFtqmw5lBGQNa0IV8 = []
		for B17r2fdFy9ns8tiOMLu in fH6PnGusaZ4M0Vb:
			if isinstance(B17r2fdFy9ns8tiOMLu,str): B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			PXFtqmw5lBGQNa0IV8.append(B17r2fdFy9ns8tiOMLu)
	else: PXFtqmw5lBGQNa0IV8 = fH6PnGusaZ4M0Vb.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
	return PXFtqmw5lBGQNa0IV8
def u9flYvgRdTxPckohWB7a3DA(EPhoOUqS1MxVfbR8s6gud,source):
	data = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,bGzRdmOErkIylxALniq6(u"ࠬࡲࡩࡴࡶࠪࢷ"),RDwahqjPfbdyEiTtnLQu(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧࢸ"),EPhoOUqS1MxVfbR8s6gud)
	if data:
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = zip(*data)
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = list(V9TdsglcWYv0X),list(ss7YGDbuAIxgnqaQroTV)
		return V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,Z65ZKfvBY0yhHW2sGaDAb = [],[],[]
	for B17r2fdFy9ns8tiOMLu in EPhoOUqS1MxVfbR8s6gud:
		if jwzOabysh0Z(u"ࠧ࠰࠱ࠪࢹ") not in B17r2fdFy9ns8tiOMLu: continue
		Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA = FL3YSRq1tBAbxckNUOrugiVv5dla4(B17r2fdFy9ns8tiOMLu,source)
		XO7Zr2W6kwieA = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࡞ࡧ࠯ࠬࢺ"),XO7Zr2W6kwieA,fNntYJW45mEFSdRX8g.DOTALL)
		if XO7Zr2W6kwieA: XO7Zr2W6kwieA = int(XO7Zr2W6kwieA[BewrUo9ANCa17G43Sn0LH5xh])
		else: XO7Zr2W6kwieA = BewrUo9ANCa17G43Sn0LH5xh
		smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡱࡥࡲ࡫ࠧࢻ"))
		Z65ZKfvBY0yhHW2sGaDAb.append([Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu,smh8Qbf9jH])
	if Z65ZKfvBY0yhHW2sGaDAb:
		YRQMu8z2CWoZcDpOebmSArlU7tE = sorted(Z65ZKfvBY0yhHW2sGaDAb,reverse=ndkUxG9LtewJ,key=lambda key: (key[kK7gj9HE462hADJbvr],key[BewrUo9ANCa17G43Sn0LH5xh],key[vUnJhT2NO8yirHcAmg],key[rgpY5VUqKbeFOCD9Nki2SmGvxEja],key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU],key[qqw1upCsKM(u"࠸ູ")],key[BWfpRku7SsM6cbE0eG(u"࠺຺")]))
		GQkoWhXOlsSVIp0Z,zklYuTMJpIQScm4oB = [],[]
		for mrDfbxOkTg in YRQMu8z2CWoZcDpOebmSArlU7tE:
			Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu,smh8Qbf9jH = mrDfbxOkTg
			if jwzOabysh0Z(u"้ࠪๆ฼ไࠨࢼ") in ScEpZwINx93VJ5aWfb4:
				zklYuTMJpIQScm4oB.append(mrDfbxOkTg)
				continue
			if mrDfbxOkTg not in GQkoWhXOlsSVIp0Z: GQkoWhXOlsSVIp0Z.append(mrDfbxOkTg)
		GQkoWhXOlsSVIp0Z = zklYuTMJpIQScm4oB+GQkoWhXOlsSVIp0Z
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = BewrUo9ANCa17G43Sn0LH5xh
		for Hsi9WYLgv2yRPtZE3UAof5,hoVitY5TylJ7GBEIZNOQg8pukq,ScEpZwINx93VJ5aWfb4,ccDFuk5NAjMTqo3hv,XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu,smh8Qbf9jH in GQkoWhXOlsSVIp0Z:
			XO7Zr2W6kwieA = str(XO7Zr2W6kwieA) if XO7Zr2W6kwieA else sCHVtMAvqirbQ4BUK3cgWo
			title = RDwahqjPfbdyEiTtnLQu(u"ุࠫ๐ัโำࠪࢽ")+AAh0X3OCacr4HpifRGLZKT+ScEpZwINx93VJ5aWfb4+AAh0X3OCacr4HpifRGLZKT+Hsi9WYLgv2yRPtZE3UAof5+AAh0X3OCacr4HpifRGLZKT+XO7Zr2W6kwieA+AAh0X3OCacr4HpifRGLZKT+ccDFuk5NAjMTqo3hv+AAh0X3OCacr4HpifRGLZKT+hoVitY5TylJ7GBEIZNOQg8pukq
			if smh8Qbf9jH.lower() not in title.lower(): title = title+AAh0X3OCacr4HpifRGLZKT+smh8Qbf9jH
			title = title.replace(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࠫࠧࢾ"),sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
			nkjHK2zQeb4vBuoaxPZTqIALW5S1 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			title = str(nkjHK2zQeb4vBuoaxPZTqIALW5S1)+SE97R3Dpj6dPLweVKU(u"࠭࠮ࠡࠩࢿ")+title
			if B17r2fdFy9ns8tiOMLu not in ss7YGDbuAIxgnqaQroTV:
				V9TdsglcWYv0X.append(title)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		if ss7YGDbuAIxgnqaQroTV:
			data = list(zip(V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV))
			if data: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨࣀ"),EPhoOUqS1MxVfbR8s6gud,data,OOht4Ly9dmZMIz)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = list(V9TdsglcWYv0X),list(ss7YGDbuAIxgnqaQroTV)
	return V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def T2YLaVWXG60qgKeQmI(url):
	JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = sCHVtMAvqirbQ4BUK3cgWo,[],[]
	if jwzOabysh0Z(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬࣁ") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡊࡉ࡙࠭ࣂ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡍࡄࡄࡔࡑࡇ࡙ࡆࡔ࠰࠵ࡸࡺࠧࣃ"))
		B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.url
		if B17r2fdFy9ns8tiOMLu: JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	elif qqw1upCsKM(u"ࠫࡸ࡫ࡲࡷ࠿ࠪࣄ") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡍࡅࡕࠩࣅ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IO7k2hZXSz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗ࠳࠲࡯ࡦࠪࣆ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣇ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: url = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		else:
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(IO7k2hZXSz(u"ࠣࡃ࡯ࡦࡦࡖ࡬ࡢࡻࡨࡶࡈࡵ࡮ࡵࡴࡲࡰࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠢࣈ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu:
				url = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
				url = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(url)
				if I5VKjrFL0Bk97: url = url.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			else: return gDETKVh8mZe09Nd(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡂࡂࡒࡏࡅ࡞ࡋࡒࠨࣉ"),[],[]
		JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = SE97R3Dpj6dPLweVKU(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࣊"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	return JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p
def XWpCdiOMY7(url,ScEpZwINx93VJ5aWfb4,JJCBn7FaOociDjUp0P9EW5ruzVQ):
	if zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡶࡼࡩࡥࠩ࣋") in url:
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = BAGYzCJQtLof(url,ScEpZwINx93VJ5aWfb4,JJCBn7FaOociDjUp0P9EW5ruzVQ)
		if ss7YGDbuAIxgnqaQroTV: return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
		return XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡐࡗ࡙ࡈࡁࠨ࣌"),[],[]
	return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࣍"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def y8U12BpqlL37oKXYa6rswHmb(url):
	if bGzRdmOErkIylxALniq6(u"ࠧ࠯࡯࠶ࡹ࠽࠭࣎") in url:
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,url)
		if ss7YGDbuAIxgnqaQroTV: return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
		return TzIj50KpohEOHx6CbZWqB(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨ࣏"),[],[]
	return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࣐ࠬ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def LLxy1itIZw(url):
	cb1fAztguv78n9LGhSWJFm5p,tryU7sQv0e91cVL3h2xKRpqHdm6 = [],[]
	if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࣑࠭") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,IO7k2hZXSz(u"ࠫࡌࡋࡔࠨ࣒"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺ࣓ࠧ"))
		if E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࣔ") in UHqibFEGL8fjKhI.headers:
			B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[hPFcB6Uxmabj59Iq(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࣕ")]
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
			smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡰࡤࡱࡪ࠭ࣖ"))
			tryU7sQv0e91cVL3h2xKRpqHdm6.append(smh8Qbf9jH)
	elif XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨࣗ") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,SE97R3Dpj6dPLweVKU(u"ࠪࡋࡊ࡚ࠧࣘ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭ࣙ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		A1kThCgL4f = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬࣚ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if A1kThCgL4f:
			A1kThCgL4f = A1kThCgL4f[BewrUo9ANCa17G43Sn0LH5xh]
			Pgj5yWUqHhn = wpsnGYEcj5dqy6rOSDFkHJzf(A1kThCgL4f)
			nnPEShQHg8OYIqkw1U4T = fNntYJW45mEFSdRX8g.findall(hPFcB6Uxmabj59Iq(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫࣛ"),Pgj5yWUqHhn,fNntYJW45mEFSdRX8g.DOTALL)
			if nnPEShQHg8OYIqkw1U4T:
				nnPEShQHg8OYIqkw1U4T = nnPEShQHg8OYIqkw1U4T[BewrUo9ANCa17G43Sn0LH5xh]
				nnPEShQHg8OYIqkw1U4T = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧ࡭࡫ࡶࡸࠬࣜ"),nnPEShQHg8OYIqkw1U4T)
				for dict in nnPEShQHg8OYIqkw1U4T:
					B17r2fdFy9ns8tiOMLu = dict[YQNd4wejLSAVJ6T(u"ࠨࡨ࡬ࡰࡪ࠭ࣝ")]
					XO7Zr2W6kwieA = dict[RDwahqjPfbdyEiTtnLQu(u"ࠩ࡯ࡥࡧ࡫࡬ࠨࣞ")]
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
					smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡲࡦࡳࡥࠨࣟ"))
					tryU7sQv0e91cVL3h2xKRpqHdm6.append(XO7Zr2W6kwieA+AAh0X3OCacr4HpifRGLZKT+smh8Qbf9jH)
		elif XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭࣠") in UHqibFEGL8fjKhI.headers:
			B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ࣡")]
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
			smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,hPFcB6Uxmabj59Iq(u"࠭࡮ࡢ࡯ࡨࠫ࣢"))
			tryU7sQv0e91cVL3h2xKRpqHdm6.append(smh8Qbf9jH)
		if XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࣣࠧ") in url:
			B17r2fdFy9ns8tiOMLu = url.split(fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡁࡸࡶࡱࡃࠧࣤ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split(aenpKvQCGVzhLXEdWiDIZ(u"ࠩࠩࠫࣥ"))[BewrUo9ANCa17G43Sn0LH5xh]
			if B17r2fdFy9ns8tiOMLu:
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
				tryU7sQv0e91cVL3h2xKRpqHdm6.append(aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࣦࠪ"))
	else:
		cb1fAztguv78n9LGhSWJFm5p.append(url)
		smh8Qbf9jH = GABnmSFOwtsu37(url,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡳࡧ࡭ࡦࠩࣧ"))
		tryU7sQv0e91cVL3h2xKRpqHdm6.append(smh8Qbf9jH)
	if not cb1fAztguv78n9LGhSWJFm5p: return TzIj50KpohEOHx6CbZWqB(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩࣨ"),[],[]
	elif len(cb1fAztguv78n9LGhSWJFm5p)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: B17r2fdFy9ns8tiOMLu = cb1fAztguv78n9LGhSWJFm5p[BewrUo9ANCa17G43Sn0LH5xh]
	else:
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(aenpKvQCGVzhLXEdWiDIZ(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࣩࠫ"),tryU7sQv0e91cVL3h2xKRpqHdm6)
		if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࣪"),[],[]
		B17r2fdFy9ns8tiOMLu = cb1fAztguv78n9LGhSWJFm5p[jQLzA92KFEcpw]
	return TzIj50KpohEOHx6CbZWqB(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࣫"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def kkeMOjvm7cXF(url):
	headers = {IO7k2hZXSz(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࣬"):BWfpRku7SsM6cbE0eG(u"ࠪࡏࡴࡪࡩ࠰࣭ࠩ")+str(A4AOrGi8QL)}
	for ruCEzOyVgmGt9WHI7BSofF6d8 in range(bGzRdmOErkIylxALniq6(u"࠺࠶ົ")):
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(favJM9wCN6Q1BxjmVUP)
		UHqibFEGL8fjKhI = YTUhmp4NetWSMdR6w1X(IO7k2hZXSz(u"ࠫࡌࡋࡔࠨ࣮"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵ࣯ࠩ"))
		if SE97R3Dpj6dPLweVKU(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࣰ") in list(UHqibFEGL8fjKhI.headers.keys()):
			B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࣱࠩ")]
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࣲࠧ")+headers[RDwahqjPfbdyEiTtnLQu(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࣳ")]
			return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
		if UHqibFEGL8fjKhI.code!=aYH620Dh48GEsTFfOBSQ7r(u"࠺࠲࠺ຼ"): break
	return phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩࣴ"),[],[]
def tQzym80gXnr2vjV(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡌࡋࡔࠨࣵ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࣶࠫ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪࣷ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		return sCHVtMAvqirbQ4BUK3cgWo,[XO7Zr2W6kwieA],[B17r2fdFy9ns8tiOMLu]
	return SIkwCEdJHTD9v1(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨࣸ"),[],[]
def cqd2Poybkf(url):
	if aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࣹࠪ") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡊࡉ࡙ࣺ࠭"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫࣻ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨࣼ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: url = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		else: return qqw1upCsKM(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨࣽ"),[],[]
	return gDETKVh8mZe09Nd(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࣾ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def AjNmfn13zT(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,hPFcB6Uxmabj59Iq(u"ࠧࡈࡇࡗࠫࣿ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪऀ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Sw0pOFoVhPeIxbl = CucRkH5KZqofAMWUgBFYVIz2jewbO(Sw0pOFoVhPeIxbl)
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(sH6BOz5wKRFcEg(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪँ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]]
	return TzIj50KpohEOHx6CbZWqB(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧं"),[],[]
def V7UpJAqcw2(url):
	if Js61GTdX5wzMurUqi7Z(u"ࠫࡄ࡯ࡤ࠾ࠩः") in url:
		headers = {IOHSz7YPF9WusGgUt1Dq(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫऄ"):Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭अ")}
		url,data = url.rsplit(qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡀࠩआ"),aYH620Dh48GEsTFfOBSQ7r(u"࠱ຽ"))
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡒࡒࡗ࡙࠭इ"),url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠸࠭࠲ࡵࡷࠫई"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(RDwahqjPfbdyEiTtnLQu(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩउ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: url = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		else: return qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊ࠲ࠨऊ"),[],[]
	return gDETKVh8mZe09Nd(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨऋ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def zqxwGS0RVE(url):
	if len(url)>SE97R3Dpj6dPLweVKU(u"࠳࠲࠳຾"):
		url = url.strip(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭࠯ࠨऌ"))+YQNd4wejLSAVJ6T(u"ࠧ࠰ࠩऍ")
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡉࡈࡘࠬऎ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡁࡓࡑ࡝ࡅ࠲࠷ࡳࡵࠩए"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		if BewrUo9ANCa17G43Sn0LH5xh and SIkwCEdJHTD9v1(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴࠬࠫऐ") in Sw0pOFoVhPeIxbl:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࠧࡲ࡯ࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪऑ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if oPnz7Zt4xLHTwR:
				Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
				oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(jwzOabysh0Z(u"ࠬࡂࡳࡤࡴ࡬ࡴࡹࡄࡶࡢࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࠩऒ"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				if oPnz7Zt4xLHTwR:
					Po9h3gWFuLR2 = IY54gnc6DzOS(oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh])
		elif len(Sw0pOFoVhPeIxbl)<aenpKvQCGVzhLXEdWiDIZ(u"࠶࠳࠴຿"): B17r2fdFy9ns8tiOMLu = Sw0pOFoVhPeIxbl
		else: return BWfpRku7SsM6cbE0eG(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡄࡖࡔࡠࡁࠨओ"),[],[]
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪऔ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def q0Y34fJ7Uc(url,ScEpZwINx93VJ5aWfb4,JJCBn7FaOociDjUp0P9EW5ruzVQ):
	if qqw1upCsKM(u"ࠨ࠱ࡧࡳࡼࡴ࠮ࡱࡪࡳࠫक") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡊࡉ࡙࠭ख"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡉࡌࡆ࠳࠱ࡴࡶࠪग"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡻࡷࡧࡰࡱࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬघ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		url = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨङ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def iZ67teKPJ2(url):
	if E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪच") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡈࡇࡗࠫछ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨज"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧझ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࡬ࡹࡺࡰࠨञ") in B17r2fdFy9ns8tiOMLu: return phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧट"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
		return iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅ࠹࡛ࠧठ"),[],[]
	return Js61GTdX5wzMurUqi7Z(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩड"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def yMvNSb80wf(url):
	vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
	HSNYwERMjzyxmrPku = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪढ"):TzIj50KpohEOHx6CbZWqB(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩण"),qqw1upCsKM(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨत"):Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪथ")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡕࡕࡓࡕࠩद"),vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡓࡕࡗ࠮࠳ࡶࡸࠬध"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(BWfpRku7SsM6cbE0eG(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫन"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: return SE97R3Dpj6dPLweVKU(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡔࡏࡘࠩऩ"),[],[]
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	return RDwahqjPfbdyEiTtnLQu(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫप"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def q9qglSBkTG(url):
	headers = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬफ"):BWfpRku7SsM6cbE0eG(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫब")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡌࡋࡔࠨभ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡓࡔࡌࡐࡓࡑ࠰࠵ࡸࡺࠧम"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫय"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	if not B17r2fdFy9ns8tiOMLu: return XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡔࡕࡆࡑࡔࡒࠫर"),[],[]
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	return RDwahqjPfbdyEiTtnLQu(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫऱ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def xb2NoaQ9Zy(url):
	vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
	HSNYwERMjzyxmrPku = {E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨल"):YQNd4wejLSAVJ6T(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪळ")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡕࡕࡓࡕࠩऴ"),vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡊࡄࡐࡆࡉࡉࡎࡃ࠰࠵ࡸࡺࠧव"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࠧࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠭ࠧࠨश"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	if not B17r2fdFy9ns8tiOMLu: return qqw1upCsKM(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡋࡅࡑࡇࡃࡊࡏࡄࠫष"),[],[]
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	if sH6BOz5wKRFcEg(u"ࠨࡪࡷࡸࡵ࠭स") not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gDETKVh8mZe09Nd(u"ࠩ࡫ࡸࡹࡶ࠺ࠨह")+B17r2fdFy9ns8tiOMLu
	return Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ऺ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def F9iSmYecgb(url):
	NroHCBWaxUZOfbgqMzAL4vJ2,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = url,[],[]
	if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࠴ࡧࡪࡢࡺ࠲ࠫऻ") in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {sH6BOz5wKRFcEg(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨ़ࠫ"):IOHSz7YPF9WusGgUt1Dq(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ऽ")}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,jwzOabysh0Z(u"ࠧࡑࡑࡖࡘࠬा"),vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪि"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		PDwk9XvU7CeV = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࠪࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭ी"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if PDwk9XvU7CeV: NroHCBWaxUZOfbgqMzAL4vJ2 = PDwk9XvU7CeV[BewrUo9ANCa17G43Sn0LH5xh]
	return YQNd4wejLSAVJ6T(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ु"),[sCHVtMAvqirbQ4BUK3cgWo],[NroHCBWaxUZOfbgqMzAL4vJ2]
def ygrODsPR43(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡌࡋࡔࠨू"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫृ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	j8JSKTwtLXWaAi1muP = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢॄ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	if j8JSKTwtLXWaAi1muP:
		j8JSKTwtLXWaAi1muP = j8JSKTwtLXWaAi1muP[BewrUo9ANCa17G43Sn0LH5xh][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠵ເ"):]
		j8JSKTwtLXWaAi1muP = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(j8JSKTwtLXWaAi1muP)
		if I5VKjrFL0Bk97: j8JSKTwtLXWaAi1muP = j8JSKTwtLXWaAi1muP.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॅ"),j8JSKTwtLXWaAi1muP,fNntYJW45mEFSdRX8g.DOTALL)
	else: B17r2fdFy9ns8tiOMLu = sCHVtMAvqirbQ4BUK3cgWo
	if not B17r2fdFy9ns8tiOMLu: return aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡘ࡛ࡌࡕࡏࠩॆ"),[],[]
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡫ࡸࡹࡶࠧे") not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪ࡬ࡹࡺࡰ࠻ࠩै")+B17r2fdFy9ns8tiOMLu
	return EJgYdjbIiWe1apkQlZcR42(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧॉ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def kTczPeGDXdyipfhjSv2rQ0xVWmgJZC(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡍࡅࡕࠩॊ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨो"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬौ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: return GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔ्ࠬ"),[],[]
	B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	return bGzRdmOErkIylxALniq6(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॎ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def mf9uYb3GgD(url):
	id = url.split(YQNd4wejLSAVJ6T(u"ࠪ࠳ࠬॏ"))[-YQNd4wejLSAVJ6T(u"࠵ແ")]
	if Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࠴࡫࡭ࡣࡧࡧࠫॐ") in url: url = url.replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ॑"),sCHVtMAvqirbQ4BUK3cgWo)
	url = url.replace(sH6BOz5wKRFcEg(u"࠭࠮ࡤࡱࡰ࠳॒ࠬ"),RDwahqjPfbdyEiTtnLQu(u"ࠧ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡳࡥࡵࡣࡧࡥࡹࡧ࠯ࠨ॓"))
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡉࡈࡘࠬ॔"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧॕ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	JbShzsakZ5M1i = GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪॖ")
	kChFiqwubnHNMpUls = fNntYJW45mEFSdRX8g.findall(jwzOabysh0Z(u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬॗ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if kChFiqwubnHNMpUls: JbShzsakZ5M1i = kChFiqwubnHNMpUls[BewrUo9ANCa17G43Sn0LH5xh]
	url = fNntYJW45mEFSdRX8g.findall(qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩक़"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not url and JbShzsakZ5M1i:
		return JbShzsakZ5M1i,[],[]
	B17r2fdFy9ns8tiOMLu = url[BewrUo9ANCa17G43Sn0LH5xh].replace(E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࡜࡝ࠩख़"),sCHVtMAvqirbQ4BUK3cgWo)
	Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb,EPhoOUqS1MxVfbR8s6gud = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,B17r2fdFy9ns8tiOMLu)
	T1AWiH6ZJ2X3Ccs = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫग़"))
	if T1AWiH6ZJ2X3Ccs and bGzRdmOErkIylxALniq6(u"ࠨ࠯ࠪज़") not in T1AWiH6ZJ2X3Ccs: title,B17r2fdFy9ns8tiOMLu = Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb[BewrUo9ANCa17G43Sn0LH5xh],EPhoOUqS1MxVfbR8s6gud[BewrUo9ANCa17G43Sn0LH5xh]
	else:
		EU7FNSgO6Mk3sTZRIxerhwuio = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡠࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ड़"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if EU7FNSgO6Mk3sTZRIxerhwuio: lljqOEPzL0xJ,Zaw0JbCPGm12Mtej96dvTI,rN6akWgiOMAVRy = EU7FNSgO6Mk3sTZRIxerhwuio[BewrUo9ANCa17G43Sn0LH5xh]
		else: lljqOEPzL0xJ,Zaw0JbCPGm12Mtej96dvTI,rN6akWgiOMAVRy = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		rN6akWgiOMAVRy = rN6akWgiOMAVRy.replace(fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡠ࠴࠭ढ़"),EJgYdjbIiWe1apkQlZcR42(u"ࠫ࠴࠭फ़"))
		Zaw0JbCPGm12Mtej96dvTI = EEH4kBfGY0FuZUjeNn(Zaw0JbCPGm12Mtej96dvTI)
		V9TdsglcWYv0X = [VXWOCAE6ns3paJ8DLG479NQfMu+gDETKVh8mZe09Nd(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧय़")+Zaw0JbCPGm12Mtej96dvTI+B8alA5nvIhTxQ]+Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb
		ss7YGDbuAIxgnqaQroTV = [rN6akWgiOMAVRy]+EPhoOUqS1MxVfbR8s6gud
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(RDwahqjPfbdyEiTtnLQu(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧॠ")+str(len(ss7YGDbuAIxgnqaQroTV)-aenpKvQCGVzhLXEdWiDIZ(u"࠶ໂ"))+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࠡ็็ๅ࠮࠭ॡ"),V9TdsglcWYv0X)
		if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ॢ"),[],[]
		elif jQLzA92KFEcpw==BewrUo9ANCa17G43Sn0LH5xh:
			p71LjtPSvMAnW = xlOFiKpdTI1Vjw5YN.argv[BewrUo9ANCa17G43Sn0LH5xh]+IO7k2hZXSz(u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨॣ")+rN6akWgiOMAVRy+IOHSz7YPF9WusGgUt1Dq(u"ࠪࠪࡹ࡫ࡸࡵࡶࡀࠫ।")+Zaw0JbCPGm12Mtej96dvTI
			FoiwfTEhGD8ulS25HeUvnI.executebuiltin(aenpKvQCGVzhLXEdWiDIZ(u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ॥")+p71LjtPSvMAnW+qqw1upCsKM(u"ࠧ࠯ࠢ०"))
			return E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ१"),[],[]
		title,B17r2fdFy9ns8tiOMLu = V9TdsglcWYv0X[jQLzA92KFEcpw],ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	return sCHVtMAvqirbQ4BUK3cgWo,[title],[B17r2fdFy9ns8tiOMLu]
def hhLbd2NzOM(B17r2fdFy9ns8tiOMLu):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡈࡇࡗࠫ२"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧ३"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if IOHSz7YPF9WusGgUt1Dq(u"ࠩ࠱࡮ࡸࡵ࡮ࠨ४") in B17r2fdFy9ns8tiOMLu: url = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ५"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else: url = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ६"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not url: return XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭७"),[],[]
	url = url[BewrUo9ANCa17G43Sn0LH5xh]
	if aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡨࡵࡶࡳࠫ८") not in url: url = SE97R3Dpj6dPLweVKU(u"ࠧࡩࡶࡷࡴ࠿࠭९")+url
	return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
def DDzVvfdgeky(url):
	headers = { XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ॰") : sCHVtMAvqirbQ4BUK3cgWo }
	if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬॱ") in url:
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬॲ"))
		items = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॳ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if items: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[items[BewrUo9ANCa17G43Sn0LH5xh]]
		else:
			Iqm6XAWBlF = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪॴ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if Iqm6XAWBlF:
				ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IO7k2hZXSz(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨॵ"),Iqm6XAWBlF[BewrUo9ANCa17G43Sn0LH5xh])
				return YQNd4wejLSAVJ6T(u"ࠧࡆࡴࡵࡳࡷࡀࠠࠨॶ")+Iqm6XAWBlF[BewrUo9ANCa17G43Sn0LH5xh],[],[]
	else:
		XXqGLnKo8vWYh1IMz9C0 = IOHSz7YPF9WusGgUt1Dq(u"ࠨ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠫॷ")
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫॸ"))
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬॹ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: return aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨॺ"),[],[]
		NroHCBWaxUZOfbgqMzAL4vJ2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh]
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࠴ࡲࡢࡴࠪॻ") in Po9h3gWFuLR2 or iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭࠮ࡻ࡫ࡳࠫॼ") in Po9h3gWFuLR2: return RDwahqjPfbdyEiTtnLQu(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬॽ"),[],[]
		items = fNntYJW45mEFSdRX8g.findall(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॾ"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		rnCzKJiBSsgGhj = {}
		for hoVitY5TylJ7GBEIZNOQg8pukq,value in items:
			rnCzKJiBSsgGhj[hoVitY5TylJ7GBEIZNOQg8pukq] = value
		data = JePn6VTBrLMDmsCzX(rnCzKJiBSsgGhj)
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,NroHCBWaxUZOfbgqMzAL4vJ2,data,headers,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫॿ"))
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(IO7k2hZXSz(u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨঀ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: return oVwa0kcqxj1e7mLplAfZdGT(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨঁ"),[],[]
		download = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh]
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		items = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬং"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		FLVObYDAIwx1,V9TdsglcWYv0X,ZNnRHC1ldwyafz9JvSB7oFTcrAmq,ss7YGDbuAIxgnqaQroTV,tt7pDgV6YfCqkjAuHSF = [],[],[],[],[]
		for B17r2fdFy9ns8tiOMLu,title in items:
			if IO7k2hZXSz(u"࠭࠮࡮࠵ࡸ࠼ࠬঃ") in B17r2fdFy9ns8tiOMLu:
				FLVObYDAIwx1,ZNnRHC1ldwyafz9JvSB7oFTcrAmq = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,B17r2fdFy9ns8tiOMLu)
				ss7YGDbuAIxgnqaQroTV = ss7YGDbuAIxgnqaQroTV + ZNnRHC1ldwyafz9JvSB7oFTcrAmq
				if FLVObYDAIwx1[BewrUo9ANCa17G43Sn0LH5xh]==aenpKvQCGVzhLXEdWiDIZ(u"ࠧ࠮࠳ࠪ঄"): V9TdsglcWYv0X.append(sH6BOz5wKRFcEg(u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭অ")+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡰ࠷ࡺ࠾ࠠࠨআ")+XXqGLnKo8vWYh1IMz9C0)
				else:
					for title in FLVObYDAIwx1:
						V9TdsglcWYv0X.append(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨই")+BWfpRku7SsM6cbE0eG(u"ࠫࡲ࠹ࡵ࠹ࠢࠪঈ")+XXqGLnKo8vWYh1IMz9C0+AAh0X3OCacr4HpifRGLZKT+title)
			else:
				title = title.replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧউ"),sCHVtMAvqirbQ4BUK3cgWo)
				title = title.strip(sH6BOz5wKRFcEg(u"࠭ࠢࠨঊ"))
				title = fvYGxnZNUiyP4HJkMIoS25(u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭ঋ")+SIkwCEdJHTD9v1(u"ࠨࠢࡰࡴ࠹ࠦࠧঌ")+XXqGLnKo8vWYh1IMz9C0+AAh0X3OCacr4HpifRGLZKT+title
				V9TdsglcWYv0X.append(title)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		B17r2fdFy9ns8tiOMLu = bGzRdmOErkIylxALniq6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ঍") + download
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬ঎"))
		items = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣএ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for id,QQ8kHjYnKEDU3sxft9S5iRoB,hash,xt31eNGL70UKPn in items:
			title = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩঐ")+bGzRdmOErkIylxALniq6(u"࠭ࠠ࡮ࡲ࠷ࠤࠬ঑")+XXqGLnKo8vWYh1IMz9C0+AAh0X3OCacr4HpifRGLZKT+xt31eNGL70UKPn.split(zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡹࠩ঒"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			B17r2fdFy9ns8tiOMLu = IO7k2hZXSz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭ও")+id+zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩঔ")+QQ8kHjYnKEDU3sxft9S5iRoB+YQNd4wejLSAVJ6T(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪক")+hash
			tt7pDgV6YfCqkjAuHSF.append(xt31eNGL70UKPn)
			V9TdsglcWYv0X.append(title)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		tt7pDgV6YfCqkjAuHSF = set(tt7pDgV6YfCqkjAuHSF)
		EERkGfUDcu68jmCthsXZ9wBblLgI,Bmr6HYSGWZ9hvCDQntfOFM7 = [],[]
		for title in V9TdsglcWYv0X:
			pSj9fZbRmO2NLEy = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦখ"),title+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࠬࠦࠨগ"),fNntYJW45mEFSdRX8g.DOTALL)
			for xt31eNGL70UKPn in tt7pDgV6YfCqkjAuHSF:
				if pSj9fZbRmO2NLEy[BewrUo9ANCa17G43Sn0LH5xh] in xt31eNGL70UKPn:
					title = title.replace(pSj9fZbRmO2NLEy[BewrUo9ANCa17G43Sn0LH5xh],xt31eNGL70UKPn.split(SE97R3Dpj6dPLweVKU(u"࠭ࡸࠨঘ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
			EERkGfUDcu68jmCthsXZ9wBblLgI.append(title)
		for XMIo9vWSBymeLJnK6YsU in range(len(ss7YGDbuAIxgnqaQroTV)):
			items = fNntYJW45mEFSdRX8g.findall(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣঙ"),SIkwCEdJHTD9v1(u"ࠨࠨࠩࠫচ")+EERkGfUDcu68jmCthsXZ9wBblLgI[XMIo9vWSBymeLJnK6YsU]+IO7k2hZXSz(u"ࠩࠩࠪࠬছ"),fNntYJW45mEFSdRX8g.DOTALL)
			Bmr6HYSGWZ9hvCDQntfOFM7.append( [EERkGfUDcu68jmCthsXZ9wBblLgI[XMIo9vWSBymeLJnK6YsU],ss7YGDbuAIxgnqaQroTV[XMIo9vWSBymeLJnK6YsU],items[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh],items[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]] )
		Bmr6HYSGWZ9hvCDQntfOFM7 = sorted(Bmr6HYSGWZ9hvCDQntfOFM7, key=lambda pkO5dBQveUZuJFt0: pkO5dBQveUZuJFt0[vUnJhT2NO8yirHcAmg], reverse=ndkUxG9LtewJ)
		Bmr6HYSGWZ9hvCDQntfOFM7 = sorted(Bmr6HYSGWZ9hvCDQntfOFM7, key=lambda pkO5dBQveUZuJFt0: pkO5dBQveUZuJFt0[rgpY5VUqKbeFOCD9Nki2SmGvxEja], reverse=lvzrYTpcBaK)
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
		for XMIo9vWSBymeLJnK6YsU in range(len(Bmr6HYSGWZ9hvCDQntfOFM7)):
			V9TdsglcWYv0X.append(Bmr6HYSGWZ9hvCDQntfOFM7[XMIo9vWSBymeLJnK6YsU][BewrUo9ANCa17G43Sn0LH5xh])
			ss7YGDbuAIxgnqaQroTV.append(Bmr6HYSGWZ9hvCDQntfOFM7[XMIo9vWSBymeLJnK6YsU][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return TzIj50KpohEOHx6CbZWqB(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧজ"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def R6QGI9PdmXt(url):
	cuIJ3axEtVWvs = url.split(fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡄ࠭ঝ"))
	vrEJRkchKxtDNiqO1b79mL5eT = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
	headers = { iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩঞ") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭ট"))
	items = fNntYJW45mEFSdRX8g.findall(IO7k2hZXSz(u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨঠ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	url = items[BewrUo9ANCa17G43Sn0LH5xh]
	return EJgYdjbIiWe1apkQlZcR42(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫড"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def dagRGEpQwmHPIlKvYrW9xtuZ(url):
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	headers = { qqw1upCsKM(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ঢ") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩণ"))
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫত"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]]
	else: return sH6BOz5wKRFcEg(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨথ"),[],[]
def sGKHk6FQSynwrqv1T4e58Eo3O(url):
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	headers = { oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪদ") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭ধ"))
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫন"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if vrEJRkchKxtDNiqO1b79mL5eT: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]]
	else: return fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ঩"),[],[]
def dmn76SaZ0E(url):
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,errno = [],[],sCHVtMAvqirbQ4BUK3cgWo
	if SIkwCEdJHTD9v1(u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧপ") in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {gDETKVh8mZe09Nd(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪফ"):wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬব")}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,SIkwCEdJHTD9v1(u"࠭ࡐࡐࡕࡗࠫভ"),vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪম"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		if ssUAzo3RibtgDv7O0x.startswith(SE97R3Dpj6dPLweVKU(u"ࠨࡪࡷࡸࡵ࠭য")): vrEJRkchKxtDNiqO1b79mL5eT = ssUAzo3RibtgDv7O0x
		else:
			rdQ5tOIzuelfvcYbNsM = fNntYJW45mEFSdRX8g.findall(RDwahqjPfbdyEiTtnLQu(u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨࠩࠪর"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if rdQ5tOIzuelfvcYbNsM:
				vrEJRkchKxtDNiqO1b79mL5eT = rdQ5tOIzuelfvcYbNsM[BewrUo9ANCa17G43Sn0LH5xh]
				rdQ5tOIzuelfvcYbNsM = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪ࡝ࠩࠨࡢ࠭঱"),vrEJRkchKxtDNiqO1b79mL5eT,fNntYJW45mEFSdRX8g.DOTALL)
				if rdQ5tOIzuelfvcYbNsM:
					vrEJRkchKxtDNiqO1b79mL5eT = mSeoVfgRpNF9PKrJ(rdQ5tOIzuelfvcYbNsM[BewrUo9ANCa17G43Sn0LH5xh])
					return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	elif wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬল") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡍࡅࡕࠩ঳"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ঴"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ঵") in list(UHqibFEGL8fjKhI.headers.keys()): vrEJRkchKxtDNiqO1b79mL5eT = UHqibFEGL8fjKhI.headers[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪশ")]
		else:
			vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ষ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh] if vrEJRkchKxtDNiqO1b79mL5eT else url
	if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪ࠳ࡻ࠵ࠧস") in vrEJRkchKxtDNiqO1b79mL5eT or iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࠴࡬࠯ࠨহ") in vrEJRkchKxtDNiqO1b79mL5eT:
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.replace(YQNd4wejLSAVJ6T(u"ࠬ࠵ࡦ࠰ࠩ঺"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ঻"))
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.replace(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࠰ࡸ࠲়ࠫ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧঽ"))
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,hPFcB6Uxmabj59Iq(u"ࠩࡓࡓࡘ࡚ࠧা"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭ি"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		items = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧী"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,title in items:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡢ࡜ࠨু"),sCHVtMAvqirbQ4BUK3cgWo)
				V9TdsglcWYv0X.append(title)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		else:
			items = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧূ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				B17r2fdFy9ns8tiOMLu = items[BewrUo9ANCa17G43Sn0LH5xh]
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(hPFcB6Uxmabj59Iq(u"ࠧ࡝࡞ࠪৃ"),sCHVtMAvqirbQ4BUK3cgWo)
				V9TdsglcWYv0X.append(sCHVtMAvqirbQ4BUK3cgWo)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	else: return hPFcB6Uxmabj59Iq(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫৄ"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ৅"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def tiYMKpXwQd(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,EJgYdjbIiWe1apkQlZcR42(u"ࠪࡋࡊ࡚ࠧ৆"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠲ࡵࡷࠫে"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,errno = [],[],sCHVtMAvqirbQ4BUK3cgWo
	if oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨৈ") in url or gDETKVh8mZe09Nd(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ৉") in url:
		if BWfpRku7SsM6cbE0eG(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ৊") in url:
			vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ো"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]
		else: vrEJRkchKxtDNiqO1b79mL5eT = url
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩৌ") not in vrEJRkchKxtDNiqO1b79mL5eT: return sH6BOz5wKRFcEg(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ্࠭"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡌࡋࡔࠨৎ"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ৏"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(bGzRdmOErkIylxALniq6(u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ৐"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall(jwzOabysh0Z(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৑"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,c4yVMkzYb0 in items:
				V9TdsglcWYv0X.append(c4yVMkzYb0)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ৒") in url:
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭৓"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡋࡊ࡚ࠧ৔"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ৕"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		rdQ5tOIzuelfvcYbNsM = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৖"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		rdQ5tOIzuelfvcYbNsM = rdQ5tOIzuelfvcYbNsM[BewrUo9ANCa17G43Sn0LH5xh]
		V9TdsglcWYv0X.append(sCHVtMAvqirbQ4BUK3cgWo)
		ss7YGDbuAIxgnqaQroTV.append(rdQ5tOIzuelfvcYbNsM)
	elif zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠ࡮࡬ࡲࡰ࠭ৗ") in url:
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧ࠽ࡥࡨࡲࡹ࡫ࡲ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৘"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if vrEJRkchKxtDNiqO1b79mL5eT:
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]
			return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ৙"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return SIkwCEdJHTD9v1(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ৚"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def QEwz0xoOij(url):
	if oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡃ࡬࡫ࡴ࠾ࠩ৛") in url:
		B17r2fdFy9ns8tiOMLu = url.split(aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡄ࡭ࡥࡵ࠿ࠪড়"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		B17r2fdFy9ns8tiOMLu = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(B17r2fdFy9ns8tiOMLu)
		if I5VKjrFL0Bk97: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,qqw1upCsKM(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬঢ়"))
		return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৞"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	website = Q1siCkTZyw.SITESURLS[RDwahqjPfbdyEiTtnLQu(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩয়")][BewrUo9ANCa17G43Sn0LH5xh]
	headers = {hPFcB6Uxmabj59Iq(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩৠ"):website}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,RDwahqjPfbdyEiTtnLQu(u"ࠩࡊࡉ࡙࠭ৡ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮࠴ࡱࡨࠬৢ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	smh8Qbf9jH = GABnmSFOwtsu37(url,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡺࡸ࡬ࠨৣ"))
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৤"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠨࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠫ࠭࠴ࠪࡀࠫࠪࠦ৥"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"ࠢࡧ࡫࡯ࡩ࠿࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ০"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ১")+website
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	if YQNd4wejLSAVJ6T(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠩ২") in Sw0pOFoVhPeIxbl:
		ppoc5Ayi76X3u = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ৩"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if ppoc5Ayi76X3u:
			B17r2fdFy9ns8tiOMLu = ppoc5Ayi76X3u[BewrUo9ANCa17G43Sn0LH5xh]
			B17r2fdFy9ns8tiOMLu = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(B17r2fdFy9ns8tiOMLu)
			if I5VKjrFL0Bk97: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ৪"))
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࡮ࡴࡵࡲ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࠭ࠩ৫"),B17r2fdFy9ns8tiOMLu,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ৬")+website
				return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ৭"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
def pptqZhrQWd(url,jcZbnfXTDoymgClJqYiABS):
	tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = [],[]
	if aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࠱࠴࠳ࠬ৮") in url:
		B17r2fdFy9ns8tiOMLu = url.replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࠲࠵࠴࠭৯"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࠳࠹࠵ࠧৰ"))
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,EJgYdjbIiWe1apkQlZcR42(u"ࠫࡌࡋࡔࠨৱ"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠵ࡸࡺࠧ৲"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(qeG16a4pbSHziNVQ2uFXrs(u"࠭࠼ࡷ࡫ࡧࡩࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡥࡧࡲࡂࠬ৳"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
			items = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৴"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA in items:
				if B17r2fdFy9ns8tiOMLu not in cb1fAztguv78n9LGhSWJFm5p:
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
					smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,bGzRdmOErkIylxALniq6(u"ࠨࡰࡤࡱࡪ࠭৵"))
					tryU7sQv0e91cVL3h2xKRpqHdm6.append(smh8Qbf9jH+LvzD9S8RPyGeukZQqb2T0B+XO7Zr2W6kwieA)
			return sCHVtMAvqirbQ4BUK3cgWo,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p
	elif IO7k2hZXSz(u"ࠩ࠲ࡨ࠴࠭৶") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡋࡊ࡚ࠧ৷"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭৸"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৹"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh].replace(SE97R3Dpj6dPLweVKU(u"࠭࠯࠲࠱ࠪ৺"),Js61GTdX5wzMurUqi7Z(u"ࠧ࠰࠶࠲ࠫ৻"))
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡉࡈࡘࠬৼ"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧࠫ৽"))
			ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(RDwahqjPfbdyEiTtnLQu(u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৾"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu: return qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ৿"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]]
	elif bGzRdmOErkIylxALniq6(u"ࠬ࠵ࡲࡰ࡮ࡨ࠳ࠬ਀") in url:
		headers = {hPFcB6Uxmabj59Iq(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਁ"):jcZbnfXTDoymgClJqYiABS}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,RDwahqjPfbdyEiTtnLQu(u"ࠧࡈࡇࡗࠫਂ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠴ࡵࡪࠪਃ"))
		B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ਄")]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡋࡊ࡚ࠧਅ"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠸ࡸ࡭࠭ਆ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = zpBKltk4s6FE1q9O(B17r2fdFy9ns8tiOMLu,Sw0pOFoVhPeIxbl)
		return JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p
	elif jwzOabysh0Z(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩਇ") in url:
		vrEJRkchKxtDNiqO1b79mL5eT = url.replace(TzIj50KpohEOHx6CbZWqB(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪਈ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࠰ࡵࡦࡶ࡮ࡶࡴ࠰ࠩਉ"))
		HSNYwERMjzyxmrPku = {qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩਊ"):jcZbnfXTDoymgClJqYiABS}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡊࡉ࡙࠭਋"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠸ࡷ࡬ࠬ਌"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ਍"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡍࡅࡕࠩ਎"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠼ࡺࡨࠨਏ"))
			Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
			if oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩਐ") in list(UHqibFEGL8fjKhI.headers.keys()):
				B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ਑")]
				UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,Js61GTdX5wzMurUqi7Z(u"ࠩࡊࡉ࡙࠭਒"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠺ࡷ࡬ࠬਓ"))
				Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
				JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = zpBKltk4s6FE1q9O(B17r2fdFy9ns8tiOMLu,Sw0pOFoVhPeIxbl)
				if cb1fAztguv78n9LGhSWJFm5p: return JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p
			elif IOHSz7YPF9WusGgUt1Dq(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬਔ") in B17r2fdFy9ns8tiOMLu:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(SE97R3Dpj6dPLweVKU(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ਕ"),oVwa0kcqxj1e7mLplAfZdGT(u"࠭࠯࡫ࡹࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪਖ"))
				return XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਗ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	else: return phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਘ"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	return sH6BOz5wKRFcEg(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ਙ"),[],[]
def TAFQaICyVY(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,RDwahqjPfbdyEiTtnLQu(u"ࠪࡋࡊ࡚ࠧਚ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭ਛ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	data = fNntYJW45mEFSdRX8g.findall(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਜ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if data:
		ZRtI3x8MqN6wv,id,OZFqdGryS57piYtv0VNK1l = data[BewrUo9ANCa17G43Sn0LH5xh]
		data = YQNd4wejLSAVJ6T(u"࠭࡯ࡱ࠿ࠪਝ")+ZRtI3x8MqN6wv+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧࠧ࡫ࡧࡁࠬਞ")+id+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩਟ")+OZFqdGryS57piYtv0VNK1l
		headers = {aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨਠ"):Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩਡ")}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,sH6BOz5wKRFcEg(u"ࠫࡕࡕࡓࡕࠩਢ"),url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧਣ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਤ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: return RDwahqjPfbdyEiTtnLQu(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਥ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]]
	return Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬਦ"),[],[]
def JJpkL4ZuSH(url):
	headers = {EJgYdjbIiWe1apkQlZcR42(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬਧ"):BWfpRku7SsM6cbE0eG(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫਨ")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,BWfpRku7SsM6cbE0eG(u"ࠫࡌࡋࡔࠨ਩"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰࠵ࡸࡺࠧਪ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਫ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh].replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo)
		return phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਬ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return IOHSz7YPF9WusGgUt1Dq(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬਭ"),[],[]
def usqkUlxVwh(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url.split(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪਮ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh].strip(fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡃࠬਯ")).strip(hPFcB6Uxmabj59Iq(u"ࠫ࠴࠭ਰ")).strip(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠬࠧ਱"))
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,items,rdQ5tOIzuelfvcYbNsM = [],[],[],sCHVtMAvqirbQ4BUK3cgWo
	headers = { gDETKVh8mZe09Nd(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਲ"):hPFcB6Uxmabj59Iq(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠧਲ਼") }
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,EJgYdjbIiWe1apkQlZcR42(u"ࠨࡉࡈࡘࠬ਴"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪਵ"))
	if gDETKVh8mZe09Nd(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬਸ਼") in list(UHqibFEGL8fjKhI.headers.keys()): rdQ5tOIzuelfvcYbNsM = UHqibFEGL8fjKhI.headers[TzIj50KpohEOHx6CbZWqB(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭਷")]
	if Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ࡮ࡴࡵࡲࠪਸ") in rdQ5tOIzuelfvcYbNsM:
		if t19ZOVHA4CpwFKaeiubcMGvz(u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧਹ") in url: rdQ5tOIzuelfvcYbNsM = rdQ5tOIzuelfvcYbNsM.replace(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࠰ࡨ࠲ࠫ਺"),gDETKVh8mZe09Nd(u"ࠨ࠱ࡹ࠳ࠬ਻"))
		NZHtkI2Csg7rSp5AP6fbO1uKE = vrEJRkchKxtDNiqO1b79mL5eT.split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀ਼ࠫ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		headers = { XxE4VAKW7LQzdk2Il3gUr1vwn(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ਽"):headers[qqw1upCsKM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਾ")] , IOHSz7YPF9WusGgUt1Dq(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬਿ"):bGzRdmOErkIylxALniq6(u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧੀ")+NZHtkI2Csg7rSp5AP6fbO1uKE }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡈࡇࡗࠫੁ"),rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,headers,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫੂ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠲ࡪ࠴࠭੃") in rdQ5tOIzuelfvcYbNsM: items = fNntYJW45mEFSdRX8g.findall(qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੄"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		elif GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࠴ࡼ࠯ࠨ੅") in rdQ5tOIzuelfvcYbNsM: items = fNntYJW45mEFSdRX8g.findall(YQNd4wejLSAVJ6T(u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੆"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if items: return [],[sCHVtMAvqirbQ4BUK3cgWo],[ items[BewrUo9ANCa17G43Sn0LH5xh] ]
		elif qqw1upCsKM(u"࠭࠼ࡩ࠳ࡁ࠸࠵࠺࠼࠰ࡪ࠴ࡂࠬੇ") in Sw0pOFoVhPeIxbl:
			return XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡆࡴࡵࡳࡷࡀࠠิ์ิๅึࠦวๅใํำ๏๎ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯฺ๋๋้ࠢีั่่๊ࠢࠥอไฦ่อี๋ะࠠศๆัหฺฯࠠษๅࠪੈ"),[],[]
	else: return IO7k2hZXSz(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗࠫ੉"),[],[]
def nE2ZGVzOhD(B17r2fdFy9ns8tiOMLu):
	cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(qqw1upCsKM(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ੊"),B17r2fdFy9ns8tiOMLu+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࠪࠫ࠭ੋ"),fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	uu4UgsMj01aImASoXpYDO9iQcfG,DvXq6pumzN7AyP50rU = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
	url = Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬੌ")+uu4UgsMj01aImASoXpYDO9iQcfG+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾੍ࠩ")+DvXq6pumzN7AyP50rU
	headers = { qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ੎"):sCHVtMAvqirbQ4BUK3cgWo , TzIj50KpohEOHx6CbZWqB(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ੏"):oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ੐") }
	vrEJRkchKxtDNiqO1b79mL5eT = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨੑ"))
	return zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭੒"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
def x9hXV5TpjR(url):
	smh8Qbf9jH = GABnmSFOwtsu37(url,aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡺࡸ࡬ࠨ੓"))
	HSNYwERMjzyxmrPku = {GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭੔"):smh8Qbf9jH,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ੕"):t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ੖")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(xCE0toTumIHWiLyMfF,fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡉࡈࡘࠬ੗"),url,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ੘"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫਖ਼"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = sCHVtMAvqirbQ4BUK3cgWo
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪਗ਼"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
		for title,B17r2fdFy9ns8tiOMLu in items:
			V9TdsglcWYv0X.append(title)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		if len(ss7YGDbuAIxgnqaQroTV)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: vrEJRkchKxtDNiqO1b79mL5eT = ss7YGDbuAIxgnqaQroTV[BewrUo9ANCa17G43Sn0LH5xh]
		elif len(ss7YGDbuAIxgnqaQroTV)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(qeG16a4pbSHziNVQ2uFXrs(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪਜ਼"), V9TdsglcWYv0X)
			if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫੜ"),[],[]
			vrEJRkchKxtDNiqO1b79mL5eT = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੝"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: vrEJRkchKxtDNiqO1b79mL5eT = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
	if not vrEJRkchKxtDNiqO1b79mL5eT: return SIkwCEdJHTD9v1(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪਫ਼"),[],[]
	return IO7k2hZXSz(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ੟"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
def ww0XZepxIaWkygRHdUPN3qcVojQ(url):
	smh8Qbf9jH = GABnmSFOwtsu37(url,qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡹࡷࡲࠧ੠"))
	HSNYwERMjzyxmrPku = {bGzRdmOErkIylxALniq6(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ੡"):smh8Qbf9jH,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ੢"):BWfpRku7SsM6cbE0eG(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭੣")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(xCE0toTumIHWiLyMfF,IOHSz7YPF9WusGgUt1Dq(u"ࠧࡈࡇࡗࠫ੤"),url,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ੥"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(RDwahqjPfbdyEiTtnLQu(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ੦"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = sCHVtMAvqirbQ4BUK3cgWo
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
		items = fNntYJW45mEFSdRX8g.findall(Js61GTdX5wzMurUqi7Z(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ੧"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
		for title,B17r2fdFy9ns8tiOMLu in items:
			V9TdsglcWYv0X.append(title)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
		if len(ss7YGDbuAIxgnqaQroTV)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: vrEJRkchKxtDNiqO1b79mL5eT = ss7YGDbuAIxgnqaQroTV[BewrUo9ANCa17G43Sn0LH5xh]
		elif len(ss7YGDbuAIxgnqaQroTV)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(gDETKVh8mZe09Nd(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ੨"),V9TdsglcWYv0X)
			if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ੩"),[],[]
			vrEJRkchKxtDNiqO1b79mL5eT = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	if not vrEJRkchKxtDNiqO1b79mL5eT:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ੪"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: vrEJRkchKxtDNiqO1b79mL5eT = oPnz7Zt4xLHTwR[BewrUo9ANCa17G43Sn0LH5xh]
	if not vrEJRkchKxtDNiqO1b79mL5eT: return YQNd4wejLSAVJ6T(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ੫"),[],[]
	return phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੬"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
def q2Z5n1Y0lG(B17r2fdFy9ns8tiOMLu):
	cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ੭"),B17r2fdFy9ns8tiOMLu+TzIj50KpohEOHx6CbZWqB(u"ࠪࠪࠫ࠭੮"),fNntYJW45mEFSdRX8g.DOTALL)
	url,uu4UgsMj01aImASoXpYDO9iQcfG,DvXq6pumzN7AyP50rU = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
	data = {SE97R3Dpj6dPLweVKU(u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬ੯"):uu4UgsMj01aImASoXpYDO9iQcfG,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡹࡥࡳࡸࡨࡶࠬੰ"):DvXq6pumzN7AyP50rU}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,BWfpRku7SsM6cbE0eG(u"࠭ࡐࡐࡕࡗࠫੱ"),url,data,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩੲ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ੳ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
	return Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬੴ"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
def W8pDvYTJXN(url):
	B17r2fdFy9ns8tiOMLu = url
	if BWfpRku7SsM6cbE0eG(u"ࠪࡃࡸ࡫ࡲࡷ࠿ࠪੵ") in url:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡌࡋࡔࠨ੶"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࠷ࡳࡵࠩ੷"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(Js61GTdX5wzMurUqi7Z(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੸"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		else: return bGzRdmOErkIylxALniq6(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭੹"),[],[]
	return hPFcB6Uxmabj59Iq(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ੺"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def yhdRrYV18l(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,Js61GTdX5wzMurUqi7Z(u"ࠩࡊࡉ࡙࠭੻"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭੼"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(IOHSz7YPF9WusGgUt1Dq(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੽"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		if B17r2fdFy9ns8tiOMLu: return SE97R3Dpj6dPLweVKU(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ੾"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return hPFcB6Uxmabj59Iq(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ੿"),[],[]
def aaTnje6zcV(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,BWfpRku7SsM6cbE0eG(u"ࠧࡈࡇࡗࠫ઀"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪઁ"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨં"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
	return jwzOabysh0Z(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ઃ"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def l1lgZCVGrv(url):
	OLN043hZlvyaB = GABnmSFOwtsu37(url,zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡺࡸ࡬ࠨ઄"))
	if XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬઅ") in url:
		headers = {zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧઆ"):OLN043hZlvyaB}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,zLjWeKu6JgNO7vocUD0Qpy(u"ࠧࡈࡇࡗࠫઇ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩઈ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧઉ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if vrEJRkchKxtDNiqO1b79mL5eT:
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]
			if bGzRdmOErkIylxALniq6(u"ࠪ࡬ࡹࡺࡰࠨઊ") not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = IOHSz7YPF9WusGgUt1Dq(u"ࠫ࡭ࡺࡴࡱ࠼ࠪઋ")+vrEJRkchKxtDNiqO1b79mL5eT
			if YQNd4wejLSAVJ6T(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ઌ") in vrEJRkchKxtDNiqO1b79mL5eT:
				UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,qqw1upCsKM(u"࠭ࡇࡆࡖࠪઍ"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ઎"))
				ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
				items = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧએ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
				if not items:
					oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall(Js61GTdX5wzMurUqi7Z(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࡠࡠ࠮࠮ࠫࡁࠬࡠࡢࡢ࠮ࠨઐ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
					if oPnz7Zt4xLHTwR:
						MtCcgLOoBTGp4nqzVhYJliX8Zva6s = oPnz7Zt4xLHTwR[SE97R3Dpj6dPLweVKU(u"࠶ໃ")]
						items = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠦࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮ࠨࠧઑ"),MtCcgLOoBTGp4nqzVhYJliX8Zva6s,fNntYJW45mEFSdRX8g.DOTALL)
						if items:
							GfozJtV9eSgpU65HyaKvMT,ZnNrmUO0JYwfF8CKquAl2B = zip(*items)
							items = list(zip(ZnNrmUO0JYwfF8CKquAl2B,GfozJtV9eSgpU65HyaKvMT))
				V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
				ffnlE3miaPHCj6NU40zvh7QFwsI2 = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡺࡸ࡬ࠨ઒"))
				for B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA in reversed(items):
					B17r2fdFy9ns8tiOMLu = ffnlE3miaPHCj6NU40zvh7QFwsI2+B17r2fdFy9ns8tiOMLu+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨઓ")+ffnlE3miaPHCj6NU40zvh7QFwsI2
					V9TdsglcWYv0X.append(XO7Zr2W6kwieA)
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
				return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
			else: return iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩઔ"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	vrEJRkchKxtDNiqO1b79mL5eT = url+jwzOabysh0Z(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪક")+OLN043hZlvyaB
	if t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡪࡷࡸࡵ࠭ખ") not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡫ࡸࡹࡶ࠺ࠨગ")+vrEJRkchKxtDNiqO1b79mL5eT
	return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
def je8zmIGqHYLwXOMFPn4hp(B17r2fdFy9ns8tiOMLu):
	OLN043hZlvyaB = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡹࡷࡲࠧઘ"))
	if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫઙ") in B17r2fdFy9ns8tiOMLu:
		cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫચ"),B17r2fdFy9ns8tiOMLu+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࠦࠧࠩછ"),fNntYJW45mEFSdRX8g.DOTALL)
		url,uu4UgsMj01aImASoXpYDO9iQcfG,DvXq6pumzN7AyP50rU = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
		data = {iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡪࡦࠪજ"):uu4UgsMj01aImASoXpYDO9iQcfG,hPFcB6Uxmabj59Iq(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨઝ"):DvXq6pumzN7AyP50rU}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,SIkwCEdJHTD9v1(u"ࠩࡓࡓࡘ࡚ࠧઞ"),url,data,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫટ"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩઠ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
		if oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ડ") in vrEJRkchKxtDNiqO1b79mL5eT:
			headers = {GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧઢ"):OLN043hZlvyaB,Js61GTdX5wzMurUqi7Z(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫણ"):sCHVtMAvqirbQ4BUK3cgWo}
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,hPFcB6Uxmabj59Iq(u"ࠨࡉࡈࡘࠬત"),vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪથ"))
			ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
			items = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩદ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
			ffnlE3miaPHCj6NU40zvh7QFwsI2 = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,SIkwCEdJHTD9v1(u"ࠫࡺࡸ࡬ࠨધ"))
			for B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA in reversed(items):
				B17r2fdFy9ns8tiOMLu = ffnlE3miaPHCj6NU40zvh7QFwsI2+B17r2fdFy9ns8tiOMLu+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨન")+ffnlE3miaPHCj6NU40zvh7QFwsI2
				V9TdsglcWYv0X.append(XO7Zr2W6kwieA)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
		else: return aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ઩"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	else:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+bGzRdmOErkIylxALniq6(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪપ")+OLN043hZlvyaB
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
def F9YthIPSBJ(B17r2fdFy9ns8tiOMLu):
	if Js61GTdX5wzMurUqi7Z(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨફ") in B17r2fdFy9ns8tiOMLu:
		cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫબ"),B17r2fdFy9ns8tiOMLu+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠪࠫ࠭ભ"),fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		uu4UgsMj01aImASoXpYDO9iQcfG,DvXq6pumzN7AyP50rU = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
		fznBtNGxTDEmI = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡺࡸ࡬ࠨમ"))
		url = fznBtNGxTDEmI+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪય")+uu4UgsMj01aImASoXpYDO9iQcfG+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪર")+DvXq6pumzN7AyP50rU
		headers = { sH6BOz5wKRFcEg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ઱"):sCHVtMAvqirbQ4BUK3cgWo , t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫલ"):EJgYdjbIiWe1apkQlZcR42(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪળ") }
		vrEJRkchKxtDNiqO1b79mL5eT = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬ઴"))
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo)
		return EJgYdjbIiWe1apkQlZcR42(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧવ"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	elif GVurlv8HeoXEzPRiQB7Ty(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩશ") in B17r2fdFy9ns8tiOMLu:
		ffpXyPnsrkNAgIq = BewrUo9ANCa17G43Sn0LH5xh
		while TzIj50KpohEOHx6CbZWqB(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪષ") in B17r2fdFy9ns8tiOMLu and ffpXyPnsrkNAgIq<IO7k2hZXSz(u"࠵ໄ"):
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,TzIj50KpohEOHx6CbZWqB(u"ࠧࡈࡇࡗࠫસ"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪહ"))
			if SIkwCEdJHTD9v1(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ઺") in list(UHqibFEGL8fjKhI.headers.keys()): B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers[SIkwCEdJHTD9v1(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ઻")]
			ffpXyPnsrkNAgIq += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	else: return jwzOabysh0Z(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ઼"),[],[]
def wNUC3haOcZ(url):
	smh8Qbf9jH = GABnmSFOwtsu37(url,qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡻࡲ࡭ࠩઽ"))
	headers = {aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧા"):smh8Qbf9jH,aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫિ"):OOsacGDt4owXd52q7gC8l()}
	if SE97R3Dpj6dPLweVKU(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩી") in url:
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫુ"))
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૂ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if B17r2fdFy9ns8tiOMLu:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh].replace(SIkwCEdJHTD9v1(u"ࠫ࡭ࡺࡴࡱࡵࠪૃ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࡮ࡴࡵࡲࠪૄ"))
			return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	else:
		LglnZ4sP7Ja6UXBrSmERIohdVib = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,IOHSz7YPF9WusGgUt1Dq(u"࠭ࡇࡆࡖࠪૅ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ૆"))
		Sw0pOFoVhPeIxbl = LglnZ4sP7Ja6UXBrSmERIohdVib.content
		HSNYwERMjzyxmrPku = headers.copy()
		if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡡ࡯ࡲࡰࡥࠧે") in str(LglnZ4sP7Ja6UXBrSmERIohdVib.cookies):
			cookies = LglnZ4sP7Ja6UXBrSmERIohdVib.cookies
			HSNYwERMjzyxmrPku[gDETKVh8mZe09Nd(u"ࠩࡆࡳࡴࡱࡩࡦࠩૈ")] = mSeoVfgRpNF9PKrJ(JePn6VTBrLMDmsCzX(cookies))
		B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ૉ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not B17r2fdFy9ns8tiOMLu: return Js61GTdX5wzMurUqi7Z(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૊"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
		else:
			B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh])+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࠬࡤ࠾࠳ࠪો")
			CxP3d82yUTnMa = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡇࡆࡖࠪૌ"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩ્ࠩ"))
			Sw0pOFoVhPeIxbl = CxP3d82yUTnMa.content
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ૎"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu:
				B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh])
				if gDETKVh8mZe09Nd(u"ࠩࡰࡴ࠹࠭૏") in B17r2fdFy9ns8tiOMLu and hPFcB6Uxmabj59Iq(u"ࠪ࠳ࡩ࠵ࠧૐ") in B17r2fdFy9ns8tiOMLu: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
				else: return jwzOabysh0Z(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૑"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩ૒"),[],[]
def n8RHJpFYok(B17r2fdFy9ns8tiOMLu):
	if aYH620Dh48GEsTFfOBSQ7r(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪ૓") in B17r2fdFy9ns8tiOMLu:
		headers = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ૔"):sH6BOz5wKRFcEg(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ૕")}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡊࡉ࡙࠭૖"),B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬ૗"))
		url = UHqibFEGL8fjKhI.content
		if url: return zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૘"),[sCHVtMAvqirbQ4BUK3cgWo],[url]
	else:
		cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭૙"),B17r2fdFy9ns8tiOMLu,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if not cuIJ3axEtVWvs: cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ૚"),B17r2fdFy9ns8tiOMLu,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		uu4UgsMj01aImASoXpYDO9iQcfG,DvXq6pumzN7AyP50rU = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
		smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡶࡴ࡯ࠫ૛"))
		url = smh8Qbf9jH+SE97R3Dpj6dPLweVKU(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ૜")
		data = {Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࡬ࡨࠬ૝"):uu4UgsMj01aImASoXpYDO9iQcfG,GVurlv8HeoXEzPRiQB7Ty(u"ࠪ࡭ࠬ૞"):DvXq6pumzN7AyP50rU}
		headers = {fvYGxnZNUiyP4HJkMIoS25(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ૟"):sH6BOz5wKRFcEg(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ૠ"),SE97R3Dpj6dPLweVKU(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧૡ"):B17r2fdFy9ns8tiOMLu}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡑࡑࡖࡘࠬૢ"),url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪૣ"))
		ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
		vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall(hPFcB6Uxmabj59Iq(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૤"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if vrEJRkchKxtDNiqO1b79mL5eT:
			vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh]
			return EJgYdjbIiWe1apkQlZcR42(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭૥"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	return fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ૦"),[],[]
def Uf0NASCGgF3B(hxobYIUHTNFQ):
	kkrXlnGjiM2phFOILdmusqZyHPoz = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(jwzOabysh0Z(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭૧"))
	headers = {SE97R3Dpj6dPLweVKU(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭૨"):kkrXlnGjiM2phFOILdmusqZyHPoz} if kkrXlnGjiM2phFOILdmusqZyHPoz else sCHVtMAvqirbQ4BUK3cgWo
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,RDwahqjPfbdyEiTtnLQu(u"ࠧࡈࡇࡗࠫ૩"),hxobYIUHTNFQ,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨ૪"))
	FDnxA39bYV6dOg = UHqibFEGL8fjKhI.content
	a2NXecRx5HCTU = str(UHqibFEGL8fjKhI.headers)
	SKvJgBbUCh0ks = a2NXecRx5HCTU+FDnxA39bYV6dOg
	if t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩ࠱ࡱࡵ࠺ࠧ૫") in SKvJgBbUCh0ks: vVU3etr1sKREmPkX9z26D0qoJ = ndkUxG9LtewJ
	else:
		BaRPinC5IUr0gXxvKJM,iigMzLZxRm6npGVfCvb0,GG1Y4F9sQrT,oQgt8NLAEcTeOqhBICYDF,vVU3etr1sKREmPkX9z26D0qoJ = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK
		captcha = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૬"),FDnxA39bYV6dOg,fNntYJW45mEFSdRX8g.DOTALL)
		if captcha: GG1Y4F9sQrT,oQgt8NLAEcTeOqhBICYDF = captcha[BewrUo9ANCa17G43Sn0LH5xh]
		v05PfSYG8VsRhy1b2 = Q1siCkTZyw.SITESURLS[SE97R3Dpj6dPLweVKU(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ૭")][YQNd4wejLSAVJ6T(u"࠸໅")]
		if BewrUo9ANCa17G43Sn0LH5xh:
			data = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡻࡳࡦࡴࠪ૮"):Q1siCkTZyw.AV_CLIENT_IDS,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ૯"):WHzJr591Ka8gRdbiLmBp0hT3S,GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡶࡴ࡯ࠫ૰"):hxobYIUHTNFQ,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࡭ࡨࡽࠬ૱"):oQgt8NLAEcTeOqhBICYDF,aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࡬ࡨࠬ૲"):sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"ࠪ࡮ࡴࡨࠧ૳"):YQNd4wejLSAVJ6T(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬ૴")}
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡖࡏࡔࡖࠪ૵"),v05PfSYG8VsRhy1b2,data,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭૶"))
			Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		Sw0pOFoVhPeIxbl = sCHVtMAvqirbQ4BUK3cgWo
		if Sw0pOFoVhPeIxbl.startswith(bGzRdmOErkIylxALniq6(u"ࠧࡖࡔࡏࡗࡂ࠭૷")):
			fH6PnGusaZ4M0Vb = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࡮࡬ࡷࡹ࠭૸"),Sw0pOFoVhPeIxbl.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡘࡖࡑ࡙࠽ࠨૹ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
			for n1WYDtVC8dRHbXJkMa in fH6PnGusaZ4M0Vb:
				url = n1WYDtVC8dRHbXJkMa[IOHSz7YPF9WusGgUt1Dq(u"ࠪࡹࡷࡲࠧૺ")]
				iwTyLWxRlNrO1vG9u03MeJSk = n1WYDtVC8dRHbXJkMa[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡲ࡫ࡴࡩࡱࡧࠫૻ")]
				data = n1WYDtVC8dRHbXJkMa[SIkwCEdJHTD9v1(u"ࠬࡪࡡࡵࡣࠪૼ")]
				headers = n1WYDtVC8dRHbXJkMa[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧ૽")]
				UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,iwTyLWxRlNrO1vG9u03MeJSk,url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ૾"))
				FDnxA39bYV6dOg = UHqibFEGL8fjKhI.content
				if zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ࠰ࡰࡴ࠹࠭૿") in FDnxA39bYV6dOg:
					vVU3etr1sKREmPkX9z26D0qoJ = ndkUxG9LtewJ
					break
				a2NXecRx5HCTU = str(UHqibFEGL8fjKhI.headers)
				SKvJgBbUCh0ks = a2NXecRx5HCTU+FDnxA39bYV6dOg
				BaRPinC5IUr0gXxvKJM = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ଀"),SKvJgBbUCh0ks,fNntYJW45mEFSdRX8g.DOTALL)
				iigMzLZxRm6npGVfCvb0 = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫଁ"),SKvJgBbUCh0ks,fNntYJW45mEFSdRX8g.DOTALL)
				if iigMzLZxRm6npGVfCvb0: iigMzLZxRm6npGVfCvb0 = iigMzLZxRm6npGVfCvb0[BewrUo9ANCa17G43Sn0LH5xh]
				if BaRPinC5IUr0gXxvKJM or iigMzLZxRm6npGVfCvb0: break
		if not vVU3etr1sKREmPkX9z26D0qoJ:
			if not BaRPinC5IUr0gXxvKJM:
				if captcha and not iigMzLZxRm6npGVfCvb0:
					if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: iigMzLZxRm6npGVfCvb0 = xrX1JKVBjC6LvFha0Yq8p(oQgt8NLAEcTeOqhBICYDF,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡦࡸࠧଂ"),hxobYIUHTNFQ)
					else:
						if not Sw0pOFoVhPeIxbl.startswith(EJgYdjbIiWe1apkQlZcR42(u"ࠬࡏࡄ࠾ࠩଃ")):
							data = {Js61GTdX5wzMurUqi7Z(u"࠭ࡵࡴࡧࡵࠫ଄"):Q1siCkTZyw.AV_CLIENT_IDS,hPFcB6Uxmabj59Iq(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨଅ"):WHzJr591Ka8gRdbiLmBp0hT3S,oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡷࡵࡰࠬଆ"):hxobYIUHTNFQ,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࡮ࡩࡾ࠭ଇ"):oQgt8NLAEcTeOqhBICYDF,fvYGxnZNUiyP4HJkMIoS25(u"ࠪ࡭ࡩ࠭ଈ"):sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"ࠫ࡯ࡵࡢࠨଉ"):Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ࡭ࡥࡵ࡫ࡧࠫଊ")}
							UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡐࡐࡕࡗࠫଋ"),v05PfSYG8VsRhy1b2,data,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧଌ"))
							Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
						else: Sw0pOFoVhPeIxbl = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩ଍")
						if Sw0pOFoVhPeIxbl.startswith(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡌࡈࡂ࠭଎")):
							uofbX7TRiNE = fNntYJW45mEFSdRX8g.findall(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩଏ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
							vgbZBClct2RIQKm0OpdqFaA,YNRdyxs6T5EKlf8 = uofbX7TRiNE[BewrUo9ANCa17G43Sn0LH5xh]
							Iqm6XAWBlF = EJgYdjbIiWe1apkQlZcR42(u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩଐ")+YNRdyxs6T5EKlf8+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࠦหศ่ํอࠬ଑")
							USk4nVycGqThQJ6u12daMIHxsoP = xSIYZduC9imekB7c0J6oOa82FVnNU()
							USk4nVycGqThQJ6u12daMIHxsoP.create(IO7k2hZXSz(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ଒"),Iqm6XAWBlF)
							BmO9pikwDd6KlJ5ztMou2 = hDjf1Ubgq629nXlOvcFLH4Jw.time()
							nwdblrKQNECPB9t,LMODBI3dskrv = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
							while nwdblrKQNECPB9t<int(YNRdyxs6T5EKlf8):
								TM0y8CGwSR9ANHLEdXI4uqmeJt5(USk4nVycGqThQJ6u12daMIHxsoP,int(nwdblrKQNECPB9t/int(YNRdyxs6T5EKlf8)*wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠳࠳࠴ໆ")),Iqm6XAWBlF,sCHVtMAvqirbQ4BUK3cgWo,YNRdyxs6T5EKlf8+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࠡ࠱ࠣࠫଓ")+str(int(nwdblrKQNECPB9t))+EJgYdjbIiWe1apkQlZcR42(u"ࠨࠢࠣฯฬ์๊สࠩଔ"))
								if nwdblrKQNECPB9t>LMODBI3dskrv+zLjWeKu6JgNO7vocUD0Qpy(u"࠴࠴໇"):
									data = {phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡸࡷࡪࡸࠧକ"):Q1siCkTZyw.AV_CLIENT_IDS,YQNd4wejLSAVJ6T(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫଖ"):WHzJr591Ka8gRdbiLmBp0hT3S,EJgYdjbIiWe1apkQlZcR42(u"ࠫࡺࡸ࡬ࠨଗ"):hxobYIUHTNFQ,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡱࡥࡺࠩଘ"):oQgt8NLAEcTeOqhBICYDF,bGzRdmOErkIylxALniq6(u"࠭ࡩࡥࠩଙ"):vgbZBClct2RIQKm0OpdqFaA,hPFcB6Uxmabj59Iq(u"ࠧ࡫ࡱࡥࠫଚ"):Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪଛ")}
									UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡓࡓࡘ࡚ࠧଜ"),v05PfSYG8VsRhy1b2,data,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪଝ"))
									Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
									if Sw0pOFoVhPeIxbl.startswith(XxE4VAKW7LQzdk2Il3gUr1vwn(u"࡙ࠫࡕࡋࡆࡐࡀࠫଞ")):
										iigMzLZxRm6npGVfCvb0 = Sw0pOFoVhPeIxbl.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࡚ࠬࡏࡌࡇࡑࡁࠬଟ"),fvYGxnZNUiyP4HJkMIoS25(u"࠵່"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
										break
									LMODBI3dskrv = nwdblrKQNECPB9t
								else: hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
								nwdblrKQNECPB9t = hDjf1Ubgq629nXlOvcFLH4Jw.time()-BmO9pikwDd6KlJ5ztMou2
							USk4nVycGqThQJ6u12daMIHxsoP.close()
				if iigMzLZxRm6npGVfCvb0:
					Cig0Z19QFBNA6zD3 = UHqibFEGL8fjKhI.cookies
					oL5VwdErqXSmxBcYat9M4J = fNntYJW45mEFSdRX8g.findall(TzIj50KpohEOHx6CbZWqB(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭ଠ"),SKvJgBbUCh0ks,fNntYJW45mEFSdRX8g.DOTALL)
					if oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧଡ") in list(Cig0Z19QFBNA6zD3.keys()): oL5VwdErqXSmxBcYat9M4J = Cig0Z19QFBNA6zD3[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨଢ")]
					elif oL5VwdErqXSmxBcYat9M4J: oL5VwdErqXSmxBcYat9M4J = oL5VwdErqXSmxBcYat9M4J[BewrUo9ANCa17G43Sn0LH5xh]
					captcha = fNntYJW45mEFSdRX8g.findall(sH6BOz5wKRFcEg(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧଣ"),FDnxA39bYV6dOg,fNntYJW45mEFSdRX8g.DOTALL)
					if captcha: GG1Y4F9sQrT,oQgt8NLAEcTeOqhBICYDF = captcha[BewrUo9ANCa17G43Sn0LH5xh]
					if oL5VwdErqXSmxBcYat9M4J and captcha:
						headers = {aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪତ"):XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬଥ")+oL5VwdErqXSmxBcYat9M4J,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ଦ"):hxobYIUHTNFQ,SIkwCEdJHTD9v1(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬଧ"):EJgYdjbIiWe1apkQlZcR42(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ନ")}
						data = SIkwCEdJHTD9v1(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ଩")+iigMzLZxRm6npGVfCvb0
						UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡓࡓࡘ࡚ࠧପ"),GG1Y4F9sQrT,data,headers,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪଫ"))
						FDnxA39bYV6dOg = UHqibFEGL8fjKhI.content
						try: cookies = UHqibFEGL8fjKhI.cookies
						except: cookies = {}
						BaRPinC5IUr0gXxvKJM = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥବ"),str(cookies),fNntYJW45mEFSdRX8g.DOTALL)
			if BaRPinC5IUr0gXxvKJM:
				hoVitY5TylJ7GBEIZNOQg8pukq,BaRPinC5IUr0gXxvKJM = BaRPinC5IUr0gXxvKJM[BewrUo9ANCa17G43Sn0LH5xh]
				kkrXlnGjiM2phFOILdmusqZyHPoz = hoVitY5TylJ7GBEIZNOQg8pukq+jwzOabysh0Z(u"ࠬࡃࠧଭ")+BaRPinC5IUr0gXxvKJM
				fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting(hPFcB6Uxmabj59Iq(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧମ"),kkrXlnGjiM2phFOILdmusqZyHPoz)
				ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,qeG16a4pbSHziNVQ2uFXrs(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥหๆิษ้ࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษะี๊ࠥ์สศศฯࠤ์ึวࠡษ็ๅา฻ࠠๅๅํࠤ๏ูสฯั่๋ฬࠦไศฯๅหࠥ࠴࠮๊ࠡ็หࠥะ่อัࠣัฬาษࠡๆศ฽ฬีษ้ࠡำหࠥอไโฯุࠤ้฿ฯสࠢฦุ์ืࠠ࡝ࡰ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้็อึࠢึ์ๆ๊ࠦหๅิีࠥ็๊ࠡฯส่ฮࠦส฻์ิࠤึฮืࠡษ็ะ์อาࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣษ฼็วยࠢิหํะัࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢไู้ࠦำๅๅࠣห้ืว้ฬิࠤ࠳࠴ࠠฤ๊ࠣหุะฮะษ่ࠤ࡛ࡖࡎࠡล๋ࠤอื่ไีํࠫଯ"))
				if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠰ࡰࡴ࠹࠭ର") not in FDnxA39bYV6dOg:
					headers = {Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡆࡳࡴࡱࡩࡦࠩ଱"):kkrXlnGjiM2phFOILdmusqZyHPoz}
					UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡋࡊ࡚ࠧଲ"),hxobYIUHTNFQ,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫଳ"))
					FDnxA39bYV6dOg = UHqibFEGL8fjKhI.content
		if captcha and not vVU3etr1sKREmPkX9z26D0qoJ and not kkrXlnGjiM2phFOILdmusqZyHPoz: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢไัฺࠦร็ษࠣวู๋ว็ࠢ࠱࠲ࠥำว้ๆࠣษ฾อฯสࠢส่฾๋ไ๋ห้ࠣึฯࠠฤะิํࠥฮวิฬัำฬ๋ࠠ็ใึࠤฬ๊แ๋ัํ์ࠥษ่ࠡใํำ๏๎ࠠ฻์ิ๋๋ࠥๆ่ࠡไืࠥอไๆ๊ๅ฽ࠬ଴"))
	return FDnxA39bYV6dOg
def jARZX7M1ml(url,ScEpZwINx93VJ5aWfb4,XO7Zr2W6kwieA):
	cb1fAztguv78n9LGhSWJFm5p,tryU7sQv0e91cVL3h2xKRpqHdm6 = [],[]
	hxobYIUHTNFQ = url
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,jwzOabysh0Z(u"࠭ࡇࡆࡖࠪଵ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭ଶ"))
	ssUAzo3RibtgDv7O0x = UHqibFEGL8fjKhI.content
	lrVCoQfbLmkX2wsiGPjKt7WJyB8eI = []
	if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩଷ") in ssUAzo3RibtgDv7O0x or XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ସ") in ssUAzo3RibtgDv7O0x:
		Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠱࠮ࡄࡂ࠯ࡢࡀࠪହ"),ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		if Jae64ky3REO57A2MvVHB90:
			for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
				PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ଺"),Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in PXFtqmw5lBGQNa0IV8:
					if B17r2fdFy9ns8tiOMLu in cb1fAztguv78n9LGhSWJFm5p: continue
					if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭଻") not in B17r2fdFy9ns8tiOMLu and wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱଼ࠪ") not in B17r2fdFy9ns8tiOMLu: continue
					if oVwa0kcqxj1e7mLplAfZdGT(u"ࠧศࠩଽ") not in title:
						lrVCoQfbLmkX2wsiGPjKt7WJyB8eI.append((title,B17r2fdFy9ns8tiOMLu))
						continue
					title = title.replace(gDETKVh8mZe09Nd(u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩା"),sCHVtMAvqirbQ4BUK3cgWo).replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࠣ࠱ࠥ࠭ି"),sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
					if TzIj50KpohEOHx6CbZWqB(u"ࠪࡷࡵࡧ࡮ࠨୀ") in title: continue
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
					tryU7sQv0e91cVL3h2xKRpqHdm6.append(title)
			for title,B17r2fdFy9ns8tiOMLu in lrVCoQfbLmkX2wsiGPjKt7WJyB8eI:
				if B17r2fdFy9ns8tiOMLu not in cb1fAztguv78n9LGhSWJFm5p:
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
					tryU7sQv0e91cVL3h2xKRpqHdm6.append(title)
			jQLzA92KFEcpw = BewrUo9ANCa17G43Sn0LH5xh
			if len(cb1fAztguv78n9LGhSWJFm5p)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫอ฿ึ่ษࠣ๎าะวอࠢ࠹࠴ࠥัว็์ฬࠫୁ"),tryU7sQv0e91cVL3h2xKRpqHdm6)
				if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return Js61GTdX5wzMurUqi7Z(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪୂ"),[],[]
			if cb1fAztguv78n9LGhSWJFm5p and jQLzA92KFEcpw>=BewrUo9ANCa17G43Sn0LH5xh: hxobYIUHTNFQ = cb1fAztguv78n9LGhSWJFm5p[jQLzA92KFEcpw]
	FDnxA39bYV6dOg = Uf0NASCGgF3B(hxobYIUHTNFQ)
	ss7YGDbuAIxgnqaQroTV,V9TdsglcWYv0X = [],[]
	if ScEpZwINx93VJ5aWfb4==t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨୃ"):
		EENfA09ZQbxs8TL47gGXiy = fNntYJW45mEFSdRX8g.findall(SE97R3Dpj6dPLweVKU(u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬୄ"),FDnxA39bYV6dOg,fNntYJW45mEFSdRX8g.DOTALL)
		if EENfA09ZQbxs8TL47gGXiy:
			B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(EENfA09ZQbxs8TL47gGXiy[BewrUo9ANCa17G43Sn0LH5xh])
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			V9TdsglcWYv0X.append(XO7Zr2W6kwieA)
	elif ScEpZwINx93VJ5aWfb4==BWfpRku7SsM6cbE0eG(u"ࠨࡹࡤࡸࡨ࡮ࠧ୅"):
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୆"),FDnxA39bYV6dOg,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,size in PXFtqmw5lBGQNa0IV8:
			if not B17r2fdFy9ns8tiOMLu: continue
			if XO7Zr2W6kwieA in size:
				V9TdsglcWYv0X.append(size)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
				break
		if not ss7YGDbuAIxgnqaQroTV:
			for B17r2fdFy9ns8tiOMLu,size in PXFtqmw5lBGQNa0IV8:
				if not B17r2fdFy9ns8tiOMLu: continue
				V9TdsglcWYv0X.append(size)
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if not ss7YGDbuAIxgnqaQroTV: return RDwahqjPfbdyEiTtnLQu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫେ"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def Tj607v5yLp(url,hoVitY5TylJ7GBEIZNOQg8pukq):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,IO7k2hZXSz(u"ࠫࡌࡋࡔࠨୈ"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫ୉"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	cookies = UHqibFEGL8fjKhI.cookies
	if bGzRdmOErkIylxALniq6(u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭୊") in list(cookies.keys()):
		kkrXlnGjiM2phFOILdmusqZyHPoz = cookies[IO7k2hZXSz(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧୋ")]
		kkrXlnGjiM2phFOILdmusqZyHPoz = mSeoVfgRpNF9PKrJ(EEH4kBfGY0FuZUjeNn(kkrXlnGjiM2phFOILdmusqZyHPoz))
		items = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩୌ"),kkrXlnGjiM2phFOILdmusqZyHPoz,fNntYJW45mEFSdRX8g.DOTALL)
		vrEJRkchKxtDNiqO1b79mL5eT = items[BewrUo9ANCa17G43Sn0LH5xh].replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩ࡟࠳୍ࠬ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪ࠳ࠬ୎"))
		vrEJRkchKxtDNiqO1b79mL5eT = EEH4kBfGY0FuZUjeNn(vrEJRkchKxtDNiqO1b79mL5eT)
	else: vrEJRkchKxtDNiqO1b79mL5eT = url
	if SIkwCEdJHTD9v1(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭୏") in vrEJRkchKxtDNiqO1b79mL5eT:
		FPUgVuv9xDmQbsKh = vrEJRkchKxtDNiqO1b79mL5eT.split(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࠫ࠲ࡇࠩ୐"))[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		vrEJRkchKxtDNiqO1b79mL5eT = fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩ୑")+FPUgVuv9xDmQbsKh
		return XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ୒"),[sCHVtMAvqirbQ4BUK3cgWo],[vrEJRkchKxtDNiqO1b79mL5eT]
	else:
		website = Q1siCkTZyw.SITESURLS[IO7k2hZXSz(u"ࠨࡃࡎࡓࡆࡓࠧ୓")][BewrUo9ANCa17G43Sn0LH5xh]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,BWfpRku7SsM6cbE0eG(u"ࠩࡊࡉ࡙࠭୔"),website,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ndkUxG9LtewJ,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠸࡮ࡥࠩ୕"))
		c4phgilzsNH2qSCPI5eMfR6ydjX = UHqibFEGL8fjKhI.url
		RNtikpO10duLoQ = vrEJRkchKxtDNiqO1b79mL5eT.split(aenpKvQCGVzhLXEdWiDIZ(u"ࠫ࠴࠭ୖ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		sPu6Xlt8bQozKi = c4phgilzsNH2qSCPI5eMfR6ydjX.split(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠵ࠧୗ"))[rgpY5VUqKbeFOCD9Nki2SmGvxEja]
		rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT.replace(RNtikpO10duLoQ,sPu6Xlt8bQozKi)
		headers = { t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ୘"):sCHVtMAvqirbQ4BUK3cgWo , aenpKvQCGVzhLXEdWiDIZ(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ୙"):gDETKVh8mZe09Nd(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ୚") , XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ୛"):rdQ5tOIzuelfvcYbNsM }
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,jwzOabysh0Z(u"ࠪࡔࡔ࡙ࡔࠨଡ଼"), rdQ5tOIzuelfvcYbNsM, sCHVtMAvqirbQ4BUK3cgWo, headers, lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪଢ଼"))
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		items = fNntYJW45mEFSdRX8g.findall(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ୞"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if not items:
			items = fNntYJW45mEFSdRX8g.findall(qqw1upCsKM(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧୟ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
			if not items:
				items = fNntYJW45mEFSdRX8g.findall(YQNd4wejLSAVJ6T(u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧୠ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
		if items:
			B17r2fdFy9ns8tiOMLu = items[BewrUo9ANCa17G43Sn0LH5xh].replace(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ࡞࠲ࠫୡ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࠲ࠫୢ"))
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.rstrip(SIkwCEdJHTD9v1(u"ࠪ࠳ࠬୣ"))
			if TzIj50KpohEOHx6CbZWqB(u"ࠫ࡭ࡺࡴࡱࠩ୤") not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬ࡮ࡴࡵࡲ࠽ࠫ୥") + B17r2fdFy9ns8tiOMLu
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ୦"),sH6BOz5wKRFcEg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ୧"))
			if hoVitY5TylJ7GBEIZNOQg8pukq==sCHVtMAvqirbQ4BUK3cgWo: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
			else: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = BWfpRku7SsM6cbE0eG(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ୨"),[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
		else: JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = IO7k2hZXSz(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡏࡂࡏࠪ୩"),[],[]
		return JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def E7rbaKcWdp852HeilwzNIXDtMY9(url):
	headers = { sH6BOz5wKRFcEg(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ୪") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ୫"))
	items = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭୬"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,errno = [],[],sCHVtMAvqirbQ4BUK3cgWo
	if items:
		for B17r2fdFy9ns8tiOMLu,c4yVMkzYb0 in items:
			V9TdsglcWYv0X.append(c4yVMkzYb0)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓࠬ୭"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def GqpA4HZMxteErOJgR(url):
	ISfWanzRV0GLEpY7e9Tl4FBsv1u = url.split(IO7k2hZXSz(u"ࠧ࠰ࠩ୮"))[RDwahqjPfbdyEiTtnLQu(u"࠸້")]
	data = aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠦࡪࡦࡀࠫ୯")+ISfWanzRV0GLEpY7e9Tl4FBsv1u
	headers = {Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ୰"):qqw1upCsKM(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩୱ")}
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,gDETKVh8mZe09Nd(u"ࠫࡕࡕࡓࡕࠩ୲"),url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡕࡈࡑ࠳࠱ࡴࡶࠪ୳"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall(sH6BOz5wKRFcEg(u"࠭ࡡࡥࡤ࡯ࡳࡨࡱ࡟ࡥࡧࡷࡩࡨࡺࡥࡥ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ୴"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		url = items[BewrUo9ANCa17G43Sn0LH5xh]
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	return XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡖࡉࡒࠧ୵"),[],[]
def C580OnlQcx7veMwUoJjsiyqDpzg9b(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,hPFcB6Uxmabj59Iq(u"ࠨࡉࡈࡘࠬ୶"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡋ࠮࠳ࡶࡸࠬ୷"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	try: Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.decode(zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡹࡹ࡬࠸ࠨ୸"),Js61GTdX5wzMurUqi7Z(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ୹"))
	except: pass
	items = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡪ࡯ࡤࡵࡢࡲࡴࡥࡰࡳࡧࡹ࡭ࡪࡽ࡟ࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭୺"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		url = items[BewrUo9ANCa17G43Sn0LH5xh]
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	else:
		JbShzsakZ5M1i = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࠢࡷ࡫ࡧࡩࡴࡥࡥࡹࡶࡢࡱࡸ࡭ࠢ࠿࡞ࡱ࠯࠭࠴ࠪࡀࠫ࡟ࡲ࠰ࡂࠧ୻"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if JbShzsakZ5M1i: return JbShzsakZ5M1i[GVurlv8HeoXEzPRiQB7Ty(u"࠶໊")][:Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠷࠱໋")],[],[]
	return wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡏࠬ୼"),[],[]
def T2qmsON9Gdp(url):
	headers = {qqw1upCsKM(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ୽"):sCHVtMAvqirbQ4BUK3cgWo}
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ୾"))
	items = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୿"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		url = items[BewrUo9ANCa17G43Sn0LH5xh]+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ஀")+url
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	return SE97R3Dpj6dPLweVKU(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡓࡏࡓࡆࡊࠧ஁"),[],[]
def lvWsDdUpkqZ(url):
	url = url.strip(sH6BOz5wKRFcEg(u"࠭࠯ࠨஂ"))
	if XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨஃ") in url: FPUgVuv9xDmQbsKh = url.split(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࠱ࠪ஄"))[kK7gj9HE462hADJbvr]
	else: FPUgVuv9xDmQbsKh = url.split(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩ࠲ࠫஅ"))[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	url = SE97R3Dpj6dPLweVKU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡩࡳࡵࡴࡨࡥࡲ࠴ࡴࡰ࠱ࡳࡰࡦࡿࡥࡳࡁࡩ࡭ࡩࡃࠧஆ") + FPUgVuv9xDmQbsKh
	headers = { IO7k2hZXSz(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨஇ") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧஈ"))
	Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace(hPFcB6Uxmabj59Iq(u"࠭࡜࡝ࠩஉ"),sCHVtMAvqirbQ4BUK3cgWo)
	items = fNntYJW45mEFSdRX8g.findall(sH6BOz5wKRFcEg(u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧஊ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ items[BewrUo9ANCa17G43Sn0LH5xh] ]
	return GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ஋"),[],[]
def MMKgQNDkWRYF(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,SIkwCEdJHTD9v1(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ஌"))
	items = fNntYJW45mEFSdRX8g.findall(bGzRdmOErkIylxALniq6(u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ஍"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	for B17r2fdFy9ns8tiOMLu,c4yVMkzYb0,pSj9fZbRmO2NLEy in items:
		V9TdsglcWYv0X.append(c4yVMkzYb0+AAh0X3OCacr4HpifRGLZKT+pSj9fZbRmO2NLEy)
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭எ"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def bRFCyLBgtolzVH28rsdYqwU4(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩஏ"))
	items = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡂ࠯ࡵࡦࡁࠦஐ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	items = set(items)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	for FPUgVuv9xDmQbsKh,QQ8kHjYnKEDU3sxft9S5iRoB,X9N6jM0enGgu3osO8b,c4yVMkzYb0,pSj9fZbRmO2NLEy in items:
		url = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳ࠳ࡻࡳ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ஑")+FPUgVuv9xDmQbsKh+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨஒ")+QQ8kHjYnKEDU3sxft9S5iRoB+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩஓ")+X9N6jM0enGgu3osO8b
		Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧஔ"))
		items = fNntYJW45mEFSdRX8g.findall(IO7k2hZXSz(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪக"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu in items:
			V9TdsglcWYv0X.append(c4yVMkzYb0+AAh0X3OCacr4HpifRGLZKT+pSj9fZbRmO2NLEy)
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if len(ss7YGDbuAIxgnqaQroTV)==BewrUo9ANCa17G43Sn0LH5xh: return SIkwCEdJHTD9v1(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ஖"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def llb0GQWFiusfn1P49(url):
	B17r2fdFy9ns8tiOMLu = sCHVtMAvqirbQ4BUK3cgWo
	if TzIj50KpohEOHx6CbZWqB(u"࠭ࡋࡦࡻࡀࠫ஗") not in url:
		vrEJRkchKxtDNiqO1b79mL5eT = url.replace(SE97R3Dpj6dPLweVKU(u"ࠧࡶࡲࡥࡳࡲ࠴࡬ࡪࡸࡨࠫ஘"),YQNd4wejLSAVJ6T(u"ࠨࡷࡳࡴࡴࡳ࠮࡭࡫ࡹࡩࠬங"))
		vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT.split(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࠲ࠫச"))
		FPUgVuv9xDmQbsKh = vrEJRkchKxtDNiqO1b79mL5eT[vUnJhT2NO8yirHcAmg]
		vrEJRkchKxtDNiqO1b79mL5eT = GVurlv8HeoXEzPRiQB7Ty(u"ࠪ࠳ࠬ஛").join(vrEJRkchKxtDNiqO1b79mL5eT[BewrUo9ANCa17G43Sn0LH5xh:kK7gj9HE462hADJbvr])
		rnCzKJiBSsgGhj = {hPFcB6Uxmabj59Iq(u"ࠫ࡮ࡪࠧஜ"):FPUgVuv9xDmQbsKh,RDwahqjPfbdyEiTtnLQu(u"ࠬࡵࡰࠨ஝"):TzIj50KpohEOHx6CbZWqB(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩஞ"),Js61GTdX5wzMurUqi7Z(u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬட"):iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ஠")}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,bGzRdmOErkIylxALniq6(u"ࠩࡓࡓࡘ࡚ࠧ஡"),vrEJRkchKxtDNiqO1b79mL5eT,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ஢"))
		B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers.get(aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ண")) or UHqibFEGL8fjKhI.headers.get(bGzRdmOErkIylxALniq6(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧத")) or sCHVtMAvqirbQ4BUK3cgWo
		if not B17r2fdFy9ns8tiOMLu and UHqibFEGL8fjKhI.succeeded:
			Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(gDETKVh8mZe09Nd(u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ஥"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡈࡇࡗࠫ஦"),url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ஧"))
		B17r2fdFy9ns8tiOMLu = UHqibFEGL8fjKhI.headers.get(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫந")) or UHqibFEGL8fjKhI.headers.get(RDwahqjPfbdyEiTtnLQu(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬன")) or sCHVtMAvqirbQ4BUK3cgWo
	if B17r2fdFy9ns8tiOMLu: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	return t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬப"),[],[]
def HHEymeCxoNY3s(url):
	headers = { bGzRdmOErkIylxALniq6(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ஫") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,qeG16a4pbSHziNVQ2uFXrs(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ஬"))
	items = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭஭"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	if items:
		V9TdsglcWYv0X.append(aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࡯ࡳ࠸ࠬம"))
		ss7YGDbuAIxgnqaQroTV.append(items[BewrUo9ANCa17G43Sn0LH5xh][zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
		V9TdsglcWYv0X.append(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡰ࠷ࡺ࠾ࠧய"))
		ss7YGDbuAIxgnqaQroTV.append(items[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh])
		return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
	else: return IO7k2hZXSz(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧர"),[],[]
def nmITaXcljkPYM(url):
	J2ZmsnUi316jb0 = url.split(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࠴࠭ற"))[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	J2ZmsnUi316jb0 = J2ZmsnUi316jb0.split(SIkwCEdJHTD9v1(u"ࠬࠬࠧல"))[BewrUo9ANCa17G43Sn0LH5xh]
	J2ZmsnUi316jb0 = J2ZmsnUi316jb0.replace(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨள"),sCHVtMAvqirbQ4BUK3cgWo)
	aaMsmzE6evBxU = Q1siCkTZyw.SITESURLS[oVwa0kcqxj1e7mLplAfZdGT(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨழ")][BewrUo9ANCa17G43Sn0LH5xh]+gDETKVh8mZe09Nd(u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫவ")+J2ZmsnUi316jb0
	i3ithFKTgz = BWfpRku7SsM6cbE0eG(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬஶ")+J2ZmsnUi316jb0
	FFlXsxdANwVr4,Yf6BpWXurQLMyVwsF0gj4d3Hm = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	grKs0LT7p8YCRWnlzF = sCHVtMAvqirbQ4BUK3cgWo
	v9vnIBuKTip7sk,DJ1elACSdx0LbI73yrG9ajZWg2VtX = sCHVtMAvqirbQ4BUK3cgWo,{}
	B384BRaP2g5xn6Fytob,C47CGwcnzF6 = sCHVtMAvqirbQ4BUK3cgWo,{}
	headers = {SIkwCEdJHTD9v1(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧஷ"):sCHVtMAvqirbQ4BUK3cgWo}
	if BewrUo9ANCa17G43Sn0LH5xh:
		WcjFD4Ur7NMJn8RV6P = SE97R3Dpj6dPLweVKU(u"࠲໌")
		for ruCEzOyVgmGt9WHI7BSofF6d8 in range(WcjFD4Ur7NMJn8RV6P):
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡌࡋࡔࠨஸ"),aaMsmzE6evBxU,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭ஹ"))
			Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		zcoVyl0XFamiKfEWYtjQJC = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡖ࡬ࡢࡻࡨࡶࡗ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ஺"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		v9vnIBuKTip7sk = zcoVyl0XFamiKfEWYtjQJC[BewrUo9ANCa17G43Sn0LH5xh] if zcoVyl0XFamiKfEWYtjQJC else Sw0pOFoVhPeIxbl
		DJ1elACSdx0LbI73yrG9ajZWg2VtX = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡥ࡫ࡦࡸࠬ஻"),v9vnIBuKTip7sk)
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡉࡈࡘࠬ஼"),aaMsmzE6evBxU,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,Js61GTdX5wzMurUqi7Z(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠶ࡵࡪࠪ஽"))
		grKs0LT7p8YCRWnlzF = UHqibFEGL8fjKhI.content
		vyV6iO3z2NeJnITK0fLhcP,CmrgLskyhIYdioRS28pBc = sCHVtMAvqirbQ4BUK3cgWo,None
		Kxley6a2pF4qzdWthA8fVo7 = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬா"),grKs0LT7p8YCRWnlzF,fNntYJW45mEFSdRX8g.DOTALL)
		if Kxley6a2pF4qzdWthA8fVo7:
			Kxley6a2pF4qzdWthA8fVo7 = Q1siCkTZyw.SITESURLS[BWfpRku7SsM6cbE0eG(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬி")][BewrUo9ANCa17G43Sn0LH5xh]+Kxley6a2pF4qzdWthA8fVo7[BewrUo9ANCa17G43Sn0LH5xh]
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,gDETKVh8mZe09Nd(u"ࠬࡍࡅࡕࠩீ"),Kxley6a2pF4qzdWthA8fVo7,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠼ࡹ࡮ࠧு"))
			vyV6iO3z2NeJnITK0fLhcP = UHqibFEGL8fjKhI.content
			ztXW78rPu2qj6BS3n = fNntYJW45mEFSdRX8g.search(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࡲࠨࠪࡂ࠾ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࡾࡶࡸࡸ࠯࡜ࡴࠬ࠽ࡠࡸ࠰ࠨࡀࡒ࠿ࡷࡹࡹ࠾࡜࠲࠰࠽ࡢࢁ࠵ࡾࠫࠪூ"), vyV6iO3z2NeJnITK0fLhcP)
			if ztXW78rPu2qj6BS3n: CmrgLskyhIYdioRS28pBc = ztXW78rPu2qj6BS3n.group(SE97R3Dpj6dPLweVKU(u"ࠨࡵࡷࡷࠬ௃"))
			else:
				if l9823lCxMk: raise ValueError(BWfpRku7SsM6cbE0eG(u"ࠤࡍࡗࠥࡶ࡬ࡢࡻࡨࡶࠥࡹࡩࡨࡰࡤࡸࡺࡸࡥࠡࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠢ௄"))
				CmrgLskyhIYdioRS28pBc = None
		rdQ5tOIzuelfvcYbNsM = Q1siCkTZyw.SITESURLS[SIkwCEdJHTD9v1(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ௅")][BewrUo9ANCa17G43Sn0LH5xh]+sH6BOz5wKRFcEg(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡴࡱࡧࡹࡦࡴࡂࡴࡷ࡫ࡴࡵࡻࡓࡶ࡮ࡴࡴ࠾ࡨࡤࡰࡸ࡫ࠧெ")
		ITntMLVEOb = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(qqw1upCsKM(u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧே"))
		if ITntMLVEOb.count(YQNd4wejLSAVJ6T(u"࠭࠺࠻࠼ࠪை"))==zLjWeKu6JgNO7vocUD0Qpy(u"࠶ໍ"):
			L0kWgirzRe4NXJv,key,OJNI3s4dBaj,LidS4P2AqOtD7z,iigMzLZxRm6npGVfCvb0 = ITntMLVEOb.split(IOHSz7YPF9WusGgUt1Dq(u"ࠧ࠻࠼࠽ࠫ௉"))
			headers[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࡚࠰ࡋࡴࡵࡧ࠮ࡘ࡬ࡷ࡮ࡺ࡯ࡳ࠯ࡌࡨࠬொ")] = L0kWgirzRe4NXJv
		headers[IOHSz7YPF9WusGgUt1Dq(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨோ")] = sH6BOz5wKRFcEg(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ௌ")
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			MAR96O0yHe7jiIlEXB = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࢀࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡖ࡙ࡌ࡙ࡓࡌ࠶ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠹࠱࠶࠵࠸࠵࠱࠻࠳࠶࠳࠶࠸࠯࠲࠳ࠦࢂࢃࠬࠡࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨ்ࠧ")+J2ZmsnUi316jb0+Js61GTdX5wzMurUqi7Z(u"ࠬࠨࠬࠡࠤࡳࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥࡲࡲࡹ࡫࡮ࡵࡒ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡗ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠧࡀࠠࠨ௎")+CmrgLskyhIYdioRS28pBc+qqw1upCsKM(u"࠭ࡽࡾࡿࠪ௏")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࡑࡑࡖࡘࠬௐ"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩ௑"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if BWfpRku7SsM6cbE0eG(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ௒") in zcoVyl0XFamiKfEWYtjQJC:
				v9vnIBuKTip7sk = zcoVyl0XFamiKfEWYtjQJC.replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ௓"),SIkwCEdJHTD9v1(u"ࠫࠫ࠭௔"))
				DJ1elACSdx0LbI73yrG9ajZWg2VtX = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡪࡩࡤࡶࠪ௕"),v9vnIBuKTip7sk)
		if BewrUo9ANCa17G43Sn0LH5xh:
			MAR96O0yHe7jiIlEXB = aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡻࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡘ࡛ࡎࡔࡎࡎ࠸ࡣࡘࡏࡍࡑࡎ࡜ࠦ࠱ࠦࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠵࠳࠶ࠢࡾࡿ࠯ࠤࠧࡼࡩࡥࡧࡲࡍࡩࠨ࠺ࠡࠤࠪ௖")+J2ZmsnUi316jb0+SIkwCEdJHTD9v1(u"ࠧࠣ࠮ࠣࠦࡵࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡴࡴࡴࡦࡰࡷࡔࡱࡧࡹࡣࡣࡦ࡯ࡈࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࡙࡯࡭ࡦࡵࡷࡥࡲࡶࠢ࠻ࠢࠪௗ")+CmrgLskyhIYdioRS28pBc+fvYGxnZNUiyP4HJkMIoS25(u"ࠨࡿࢀࢁࠬ௘")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,BWfpRku7SsM6cbE0eG(u"ࠩࡓࡓࡘ࡚ࠧ௙"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫ௚"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if Js61GTdX5wzMurUqi7Z(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ௛") in zcoVyl0XFamiKfEWYtjQJC:
				v9vnIBuKTip7sk = zcoVyl0XFamiKfEWYtjQJC.replace(EJgYdjbIiWe1apkQlZcR42(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭௜"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠦࠨ௝"))
				DJ1elACSdx0LbI73yrG9ajZWg2VtX = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡥ࡫ࡦࡸࠬ௞"),v9vnIBuKTip7sk)
		if BewrUo9ANCa17G43Sn0LH5xh:
			MAR96O0yHe7jiIlEXB = BWfpRku7SsM6cbE0eG(u"ࠨࡽࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡏࡏࡔࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠴࠳࠲࠶࠶࠮࠵ࠤࢀࢁ࠱ࠦࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬ௟")+J2ZmsnUi316jb0+GVurlv8HeoXEzPRiQB7Ty(u"ࠩࠥ࠰ࠥࠨࡰ࡭ࡣࡼࡦࡦࡩ࡫ࡄࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡯࡯ࡶࡨࡲࡹࡖ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡔࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠤ࠽ࠤࠬ௠")+CmrgLskyhIYdioRS28pBc+RDwahqjPfbdyEiTtnLQu(u"ࠪࢁࢂࢃࠧ௡")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡕࡕࡓࡕࠩ௢"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠶ࡶࡩ࠭௣"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if SIkwCEdJHTD9v1(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭௤") in zcoVyl0XFamiKfEWYtjQJC:
				B384BRaP2g5xn6Fytob = zcoVyl0XFamiKfEWYtjQJC.replace(sH6BOz5wKRFcEg(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ௥"),qqw1upCsKM(u"ࠨࠨࠪ௦"))
				C47CGwcnzF6 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡧ࡭ࡨࡺࠧ௧"),B384BRaP2g5xn6Fytob)
		if BewrUo9ANCa17G43Sn0LH5xh and IO7k2hZXSz(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ௨") not in v9vnIBuKTip7sk:
			v9vnIBuKTip7sk,DJ1elACSdx0LbI73yrG9ajZWg2VtX,DJ1elACSdx0LbI73yrG9ajZWg2VtX = sCHVtMAvqirbQ4BUK3cgWo,{},{}
			MAR96O0yHe7jiIlEXB = qqw1upCsKM(u"ࠫࢀࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡏ࡚ࡉࡇࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠸࠮࠳࠲࠵࠹࠵࠹࠱࠲࠰࠳࠷࠳࠶࠰ࠣࡿࢀ࠰ࠥࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫ௩")+J2ZmsnUi316jb0+RDwahqjPfbdyEiTtnLQu(u"ࠬࠨࠬࠡࠤࡳࡰࡦࡿࡢࡢࡥ࡮ࡇࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥࡲࡲࡹ࡫࡮ࡵࡒ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡗ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠧࡀࠠࠨ௪")+CmrgLskyhIYdioRS28pBc+E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡽࡾࡿࠪ௫")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡑࡑࡖࡘࠬ௬"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠺ࡴࡩࠩ௭"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ௮") in zcoVyl0XFamiKfEWYtjQJC:
				v9vnIBuKTip7sk = zcoVyl0XFamiKfEWYtjQJC.replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ௯"),IO7k2hZXSz(u"ࠫࠫ࠭௰"))
				DJ1elACSdx0LbI73yrG9ajZWg2VtX = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡪࡩࡤࡶࠪ௱"),v9vnIBuKTip7sk)
		if BewrUo9ANCa17G43Sn0LH5xh and phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭௲") not in v9vnIBuKTip7sk:
			v9vnIBuKTip7sk,DJ1elACSdx0LbI73yrG9ajZWg2VtX,DJ1elACSdx0LbI73yrG9ajZWg2VtX = sCHVtMAvqirbQ4BUK3cgWo,{},{}
			MAR96O0yHe7jiIlEXB = SE97R3Dpj6dPLweVKU(u"ࠧࡼࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦ࡜ࡋࡂࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠳࠰࠵࠴࠷࠻࠰࠺࠲࠶࠲࠵࠺࠮࠱࠲ࠥࢁࢂ࠲ࠠࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭௳")+J2ZmsnUi316jb0+TzIj50KpohEOHx6CbZWqB(u"ࠨࠤ࠯ࠤࠧࡶ࡬ࡢࡻࡥࡥࡨࡱࡃࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡵ࡮ࡵࡧࡱࡸࡕࡲࡡࡺࡤࡤࡧࡰࡉ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࡚ࡩ࡮ࡧࡶࡸࡦࡳࡰࠣ࠼ࠣࠫ௴")+CmrgLskyhIYdioRS28pBc+jwzOabysh0Z(u"ࠩࢀࢁࢂ࠭௵")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡔࡔ࡙ࡔࠨ௶"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠶ࡷ࡬ࠬ௷"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if RDwahqjPfbdyEiTtnLQu(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ௸") in zcoVyl0XFamiKfEWYtjQJC:
				v9vnIBuKTip7sk = zcoVyl0XFamiKfEWYtjQJC.replace(gDETKVh8mZe09Nd(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ௹"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧࠧࠩ௺"))
				DJ1elACSdx0LbI73yrG9ajZWg2VtX = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(SIkwCEdJHTD9v1(u"ࠨࡦ࡬ࡧࡹ࠭௻"),v9vnIBuKTip7sk)
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU and zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ௼") not in B384BRaP2g5xn6Fytob:
			B384BRaP2g5xn6Fytob,C47CGwcnzF6,C47CGwcnzF6 = sCHVtMAvqirbQ4BUK3cgWo,{},{}
			MAR96O0yHe7jiIlEXB = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡿࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠦࠢࡂࡐࡇࡖࡔࡏࡄࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠳࠲࠱࠵࠵࠴࠳࠹ࠤࢀࢁ࠱ࠦࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬ௽")+J2ZmsnUi316jb0+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࠧ࠲ࠠࠣࡲ࡯ࡥࡾࡨࡡࡤ࡭ࡆࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤࡱࡱࡸࡪࡴࡴࡑ࡮ࡤࡽࡧࡧࡣ࡬ࡅࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡳࡪࡩࡱࡥࡹࡻࡲࡦࡖ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠦ࠿ࠦࠧ௾")+CmrgLskyhIYdioRS28pBc+EJgYdjbIiWe1apkQlZcR42(u"ࠬࢃࡽࡾࠩ௿")
			UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,bGzRdmOErkIylxALniq6(u"࠭ࡐࡐࡕࡗࠫఀ"),rdQ5tOIzuelfvcYbNsM,MAR96O0yHe7jiIlEXB,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨఁ"))
			zcoVyl0XFamiKfEWYtjQJC = UHqibFEGL8fjKhI.content
			if TzIj50KpohEOHx6CbZWqB(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨం") in zcoVyl0XFamiKfEWYtjQJC:
				B384BRaP2g5xn6Fytob = zcoVyl0XFamiKfEWYtjQJC.replace(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪః"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࠪࠬఄ"))
				C47CGwcnzF6 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡩ࡯ࡣࡵࠩఅ"),B384BRaP2g5xn6Fytob)
	TPNZ2Y9OQR,ra0MC5PqEJsRVmk2OjtuvAh,IIDUseRPxGQZgL7124JhKf,oo9jqirLQz0pXEFVJ = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[],[]
	DWqrTk6UcXVyK,neUFXNjiOvmwRh,U2QrkEVh3l1H0JOWBFn8bZX5yq,IBUyG0RwDoKEvz7Pu = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[],[]
	try: ra0MC5PqEJsRVmk2OjtuvAh = DJ1elACSdx0LbI73yrG9ajZWg2VtX[oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬఆ")][qqw1upCsKM(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧఇ")]
	except: pass
	try: neUFXNjiOvmwRh = C47CGwcnzF6[YQNd4wejLSAVJ6T(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧఈ")][XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩఉ")]
	except: pass
	try: TPNZ2Y9OQR = DJ1elACSdx0LbI73yrG9ajZWg2VtX[oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩఊ")][aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬఋ")]
	except: pass
	try: DWqrTk6UcXVyK = C47CGwcnzF6[bGzRdmOErkIylxALniq6(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫఌ")][t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡪࡡࡴࡪࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ఍")]
	except: pass
	try: IIDUseRPxGQZgL7124JhKf = DJ1elACSdx0LbI73yrG9ajZWg2VtX[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ఎ")][aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨఏ")]
	except: pass
	try: U2QrkEVh3l1H0JOWBFn8bZX5yq = C47CGwcnzF6[aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨఐ")][t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ఑")]
	except: pass
	try: oo9jqirLQz0pXEFVJ = DJ1elACSdx0LbI73yrG9ajZWg2VtX[gDETKVh8mZe09Nd(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪఒ")][XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭ఓ")]
	except: pass
	try: IBUyG0RwDoKEvz7Pu = C47CGwcnzF6[oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬఔ")][aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨక")]
	except: pass
	if not any([ra0MC5PqEJsRVmk2OjtuvAh,neUFXNjiOvmwRh,TPNZ2Y9OQR,DWqrTk6UcXVyK,IIDUseRPxGQZgL7124JhKf,U2QrkEVh3l1H0JOWBFn8bZX5yq,oo9jqirLQz0pXEFVJ,IBUyG0RwDoKEvz7Pu]):
		xFNW2M6ijZbhzuoHgPC0Ba = fNntYJW45mEFSdRX8g.findall(YQNd4wejLSAVJ6T(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪఖ"),grKs0LT7p8YCRWnlzF,fNntYJW45mEFSdRX8g.DOTALL)
		N6yp1C9H8R = fNntYJW45mEFSdRX8g.findall(qqw1upCsKM(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩగ"),grKs0LT7p8YCRWnlzF,fNntYJW45mEFSdRX8g.DOTALL)
		D6kU7MfbGhxpWgB2CzlR1cqJs0 = fNntYJW45mEFSdRX8g.findall(YQNd4wejLSAVJ6T(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఘ"),grKs0LT7p8YCRWnlzF,fNntYJW45mEFSdRX8g.DOTALL)
		W3AlVjrGIZ6Q1u2awYNPLcpRgvyX = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬఙ"),grKs0LT7p8YCRWnlzF,fNntYJW45mEFSdRX8g.DOTALL)
		hJa6B8OyePM97A4,x5xRmbLfZiNMdWrwUH6pz7og29DB,UUwFWgkPvHNMX = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		try: hJa6B8OyePM97A4 = DJ1elACSdx0LbI73yrG9ajZWg2VtX[t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨచ")][iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪఛ")][Js61GTdX5wzMurUqi7Z(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧజ")][iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡵ࡫ࡷࡰࡪ࠭ఝ")][t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡴࡸࡲࡸ࠭ఞ")][BewrUo9ANCa17G43Sn0LH5xh][IO7k2hZXSz(u"ࠩࡷࡩࡽࡺࠧట")]
		except:
			try: hJa6B8OyePM97A4 = C47CGwcnzF6[jwzOabysh0Z(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧఠ")][qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩడ")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ఢ")][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡴࡪࡶ࡯ࡩࠬణ")][sH6BOz5wKRFcEg(u"ࠧࡳࡷࡱࡷࠬత")][BewrUo9ANCa17G43Sn0LH5xh][IO7k2hZXSz(u"ࠨࡶࡨࡼࡹ࠭థ")]
			except: pass
		try: x5xRmbLfZiNMdWrwUH6pz7og29DB = DJ1elACSdx0LbI73yrG9ajZWg2VtX[zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭ద")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨధ")][t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬన")][TzIj50KpohEOHx6CbZWqB(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭఩")][BewrUo9ANCa17G43Sn0LH5xh][XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࡲࡶࡰࡶࠫప")][BewrUo9ANCa17G43Sn0LH5xh][RDwahqjPfbdyEiTtnLQu(u"ࠧࡵࡧࡻࡸࠬఫ")]
		except:
			try: x5xRmbLfZiNMdWrwUH6pz7og29DB = C47CGwcnzF6[sH6BOz5wKRFcEg(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬబ")][t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧభ")][EJgYdjbIiWe1apkQlZcR42(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫమ")][SE97R3Dpj6dPLweVKU(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬయ")][BewrUo9ANCa17G43Sn0LH5xh][iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡸࡵ࡯ࡵࠪర")][BewrUo9ANCa17G43Sn0LH5xh][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡴࡦࡺࡷࠫఱ")]
			except: pass
		try: UUwFWgkPvHNMX = DJ1elACSdx0LbI73yrG9ajZWg2VtX[qqw1upCsKM(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫల")][Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡴࡨࡥࡸࡵ࡮ࠨళ")]
		except:
			try: UUwFWgkPvHNMX = C47CGwcnzF6[aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭ఴ")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡶࡪࡧࡳࡰࡰࠪవ")]
			except: pass
		br7FAlUB2QZo4eXucsPnw1q0vHfjz = sCHVtMAvqirbQ4BUK3cgWo
		emNdSTjoQlqEah53bA8DziX = VXWOCAE6ns3paJ8DLG479NQfMu+jwzOabysh0Z(u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦๅีๅ็อࠥ࠴࠮ࠡล๋ࠤ฿๐ัࠡ็็หห๋ࠠๅส฼ฺࠥอไๆีอาิ๋๊็ࠢ࠱࠲ࠥษ่ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็ࠢ࠱࠲ࠥษ่ࠡ์๋ฮ๏๎ศࠡ์ะฮฬาࠠี์ฤࠤ๊ำฯะࠢ࠱࠲ࠥษ่ࠡ์๋ฮ๏๎ศࠡ฼ํี่ࠥวะำࠣว๋๊ࠦี฼็ࠤฬ๊แ๋ัํ์ࠥอไร่ࠪశ")+B8alA5nvIhTxQ
		if xFNW2M6ijZbhzuoHgPC0Ba or N6yp1C9H8R or D6kU7MfbGhxpWgB2CzlR1cqJs0 or W3AlVjrGIZ6Q1u2awYNPLcpRgvyX or hJa6B8OyePM97A4 or x5xRmbLfZiNMdWrwUH6pz7og29DB or UUwFWgkPvHNMX:
			if   xFNW2M6ijZbhzuoHgPC0Ba: Iqm6XAWBlF = xFNW2M6ijZbhzuoHgPC0Ba[BewrUo9ANCa17G43Sn0LH5xh]
			elif N6yp1C9H8R: Iqm6XAWBlF = N6yp1C9H8R[BewrUo9ANCa17G43Sn0LH5xh]
			elif D6kU7MfbGhxpWgB2CzlR1cqJs0: Iqm6XAWBlF = D6kU7MfbGhxpWgB2CzlR1cqJs0[BewrUo9ANCa17G43Sn0LH5xh]
			elif W3AlVjrGIZ6Q1u2awYNPLcpRgvyX: Iqm6XAWBlF = W3AlVjrGIZ6Q1u2awYNPLcpRgvyX[BewrUo9ANCa17G43Sn0LH5xh]
			elif hJa6B8OyePM97A4: Iqm6XAWBlF = hJa6B8OyePM97A4
			elif x5xRmbLfZiNMdWrwUH6pz7og29DB: Iqm6XAWBlF = x5xRmbLfZiNMdWrwUH6pz7og29DB
			elif UUwFWgkPvHNMX: Iqm6XAWBlF = UUwFWgkPvHNMX
			br7FAlUB2QZo4eXucsPnw1q0vHfjz = Iqm6XAWBlF.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
			emNdSTjoQlqEah53bA8DziX += jwzOabysh0Z(u"ࠬࡢ࡮࡝ࡰࠪష")+F7Fe63KbGjaz2TcmCNHPdo5QiXO+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ัิษ็อ๋ࠥๆࠡ์๋ฮ๏๎ศࠨస")+B8alA5nvIhTxQ+slFfrUIWCowaBA7tce3iZbj8xn+br7FAlUB2QZo4eXucsPnw1q0vHfjz
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IO7k2hZXSz(u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺ๋ࠢห้๋ศา็ฯࠫహ"),emNdSTjoQlqEah53bA8DziX)
		if br7FAlUB2QZo4eXucsPnw1q0vHfjz: br7FAlUB2QZo4eXucsPnw1q0vHfjz = SE97R3Dpj6dPLweVKU(u"ࠨ࠼ࠣࠫ఺")+br7FAlUB2QZo4eXucsPnw1q0vHfjz
		return t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ఻")+br7FAlUB2QZo4eXucsPnw1q0vHfjz,[],[]
	osyGOj5uFL,CWB4ISRmwJf,IvibBZT49cOF = [],[],[]
	q2oK8MyOUi7uZj9b3vFdpaQxJ = [ra0MC5PqEJsRVmk2OjtuvAh,neUFXNjiOvmwRh]
	wfpuA0xUBTcanjVGYh97N2F6rdLH = [TPNZ2Y9OQR,DWqrTk6UcXVyK]
	GQkoWhXOlsSVIp0Z,PinyaVS5G2 = [],[]
	for Or8bHzxEWwPBpQ1cJ2Ano9a in IIDUseRPxGQZgL7124JhKf+U2QrkEVh3l1H0JOWBFn8bZX5yq:
		if Or8bHzxEWwPBpQ1cJ2Ano9a[SIkwCEdJHTD9v1(u"ࠪ࡭ࡹࡧࡧࠨ఼")] not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(Or8bHzxEWwPBpQ1cJ2Ano9a[TzIj50KpohEOHx6CbZWqB(u"ࠫ࡮ࡺࡡࡨࠩఽ")])
			PinyaVS5G2.append(Or8bHzxEWwPBpQ1cJ2Ano9a)
	GQkoWhXOlsSVIp0Z,S5h1Y0BtRPEcrebulMzI3NwnokH = [],[]
	for Or8bHzxEWwPBpQ1cJ2Ano9a in oo9jqirLQz0pXEFVJ+IBUyG0RwDoKEvz7Pu:
		if Or8bHzxEWwPBpQ1cJ2Ano9a[gDETKVh8mZe09Nd(u"ࠬ࡯ࡴࡢࡩࠪా")] not in GQkoWhXOlsSVIp0Z:
			GQkoWhXOlsSVIp0Z.append(Or8bHzxEWwPBpQ1cJ2Ano9a[hPFcB6Uxmabj59Iq(u"࠭ࡩࡵࡣࡪࠫి")])
			S5h1Y0BtRPEcrebulMzI3NwnokH.append(Or8bHzxEWwPBpQ1cJ2Ano9a)
	for dict in PinyaVS5G2+S5h1Y0BtRPEcrebulMzI3NwnokH:
		if EJgYdjbIiWe1apkQlZcR42(u"ࠧࡶࡴ࡯ࠫీ") not in list(dict.keys()): continue
		if IOHSz7YPF9WusGgUt1Dq(u"ࠨ࡫ࡷࡥ࡬࠭ు") in list(dict.keys()): dict[SE97R3Dpj6dPLweVKU(u"ࠩ࡬ࡸࡦ࡭ࠧూ")] = str(dict[aenpKvQCGVzhLXEdWiDIZ(u"ࠪ࡭ࡹࡧࡧࠨృ")])
		if t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࡫ࡶࡳࠨౄ") in list(dict.keys()): dict[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡬ࡰࡴࠩ౅")] = str(dict[IOHSz7YPF9WusGgUt1Dq(u"࠭ࡦࡱࡵࠪె")])
		if fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩే") in list(dict.keys()): dict[IOHSz7YPF9WusGgUt1Dq(u"ࠨࡶࡼࡴࡪ࠭ై")] = dict[fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ౉")]
		if qqw1upCsKM(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬొ") in list(dict.keys()): dict[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨో")] = str(dict[jwzOabysh0Z(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧౌ")])
		if TzIj50KpohEOHx6CbZWqB(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ్࠭") in list(dict.keys()): dict[TzIj50KpohEOHx6CbZWqB(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ౎")] = str(dict[SE97R3Dpj6dPLweVKU(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ౏")])
		if YQNd4wejLSAVJ6T(u"ࠩࡺ࡭ࡩࡺࡨࠨ౐") in list(dict.keys()): dict[IO7k2hZXSz(u"ࠪࡷ࡮ࢀࡥࠨ౑")] = str(dict[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡼ࡯ࡤࡵࡪࠪ౒")])+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡾࠧ౓")+str(dict[jwzOabysh0Z(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭౔")])
		if IOHSz7YPF9WusGgUt1Dq(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧౕࠪ") in list(dict.keys()): dict[sH6BOz5wKRFcEg(u"ࠨ࡫ࡱ࡭ࡹౖ࠭")] = dict[oVwa0kcqxj1e7mLplAfZdGT(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ౗")][qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡷࡹࡧࡲࡵࠩౘ")]+GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࠲࠭ౙ")+dict[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨౚ")][jwzOabysh0Z(u"࠭ࡥ࡯ࡦࠪ౛")]
		if RDwahqjPfbdyEiTtnLQu(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ౜") in list(dict.keys()): dict[EJgYdjbIiWe1apkQlZcR42(u"ࠨ࡫ࡱࡨࡪࡾࠧౝ")] = dict[SE97R3Dpj6dPLweVKU(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭౞")][SIkwCEdJHTD9v1(u"ࠪࡷࡹࡧࡲࡵࠩ౟")]+SIkwCEdJHTD9v1(u"ࠫ࠲࠭ౠ")+dict[qqw1upCsKM(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩౡ")][Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡥ࡯ࡦࠪౢ")]
		if GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨౣ") in list(dict.keys()): dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ౤")] = dict[gDETKVh8mZe09Nd(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ౥")]
		if sH6BOz5wKRFcEg(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ౦") in list(dict.keys()) and int(dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ౧")])>IO7k2hZXSz(u"࠴࠵࠶࠸࠲࠳࠵࠶࠷໎"): del dict[fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭౨")]
		if qqw1upCsKM(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ౩") in list(dict.keys()):
			rAN9Oh8Bot6eYcfMyH5kdSva04 = dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ౪")].split(qqw1upCsKM(u"ࠨࠨࠪ౫"))
			for UqKgalXPCz7eQAL08foMx1R in rAN9Oh8Bot6eYcfMyH5kdSva04:
				key,value = UqKgalXPCz7eQAL08foMx1R.split(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡀࠫ౬"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠵໏"))
				dict[key] = mSeoVfgRpNF9PKrJ(value)
		osyGOj5uFL.append(dict)
	if vyV6iO3z2NeJnITK0fLhcP:
		if SE97R3Dpj6dPLweVKU(u"ࠪࡷࡵࡃࡳࡪࡩࠪ౭") in v9vnIBuKTip7sk+B384BRaP2g5xn6Fytob:
			try:
				import youtube_signature.cipher as OaJlrMB75fiV6h2YxE,youtube_signature.json_script_engine as BhrfcoWOdxeJL4kRE8CMli3F
				rAN9Oh8Bot6eYcfMyH5kdSva04 = KMsri6ZefnqkVwh074XyELbBPItH.rAN9Oh8Bot6eYcfMyH5kdSva04.Cipher()
				rAN9Oh8Bot6eYcfMyH5kdSva04._object_cache = {}
				rLlTZm0fju = rAN9Oh8Bot6eYcfMyH5kdSva04._load_javascript(vyV6iO3z2NeJnITK0fLhcP)
				gM019JIbEwNUmO6W5 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡸࡺࡲࠨ౮"),str(rLlTZm0fju))
				SH4XB2IQ68 = KMsri6ZefnqkVwh074XyELbBPItH.nF4jDyvYPkRBG0uwt1dp.JsonScriptEngine(gM019JIbEwNUmO6W5)
			except: pass
		if BewrUo9ANCa17G43Sn0LH5xh:
			MyvTBu7OS98olzUYkpihsa = sCHVtMAvqirbQ4BUK3cgWo
			j57boOc6MmG = fNntYJW45mEFSdRX8g.findall(
				SIkwCEdJHTD9v1(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࡢ࠮ࡨࡧࡷࡠ࠭ࠨ࡮ࠣ࡞ࠬࡠ࠮ࠬࠦ࡝ࠪࡥࡁࢁࠐࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉࡣ࠿ࡖࡸࡷ࡯࡮ࡨ࡞࠱ࡪࡷࡵ࡭ࡄࡪࡤࡶࡈࡵࡤࡦ࡞ࠫ࠵࠶࠶࡜ࠪࡾࠍࠍࠎࠏࠉࠊࠋࠫࡃࡕࡂࡳࡵࡴࡢ࡭ࡩࡾ࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩ࠴࡝ࠬࠫࠩࠪࡡ࠮ࡢ࠾ࠤࡱࡲࠧࡢ࡛࡝࠭ࠫࡃࡕࡃࡳࡵࡴࡢ࡭ࡩࡾࠩ࡝࡟ࠍࠍࠎࠏࠉࠊࠫࠍࠍࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࠍ࠱ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰ࡢࠨࡢ࡞ࠬ࠭ࡄ࠲ࡣ࠾ࡣ࡟࠲ࠏࠏࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉࠊࡩࡨࡸࡡ࠮ࡢ࡝ࠫࡿࠎࠎࠏࠉࠊࠋࠌࠍࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡࡡࡢ࡝࡟࡟ࢀࡡࢂ࡮ࡶ࡮࡯ࠎࠎࠏࠉࠊࠋࠌ࠭ࡡ࠯ࠦࠧ࡞ࠫࡧࡂࢂࠊࠊࠋࠌࠍࠎࡢࡢࠩࡁࡓࡀࡻࡧࡲ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫࡀࠎࠎࠏࠉࠊࠫࠫࡃࡕࡂ࡮ࡧࡷࡱࡧࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯ࠨࡀ࠼࡟࡟࠭ࡅࡐ࠽࡫ࡧࡼࡃࡢࡤࠬࠫ࡟ࡡ࠮ࡅ࡜ࠩ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࡟࠭ࠏࠏࠉࠊࠋࠫࡃ࠭ࡼࡡࡳࠫ࠯࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࡠ࠳ࡹࡥࡵ࡞ࠫࠬࡄࡀࠢ࡯࠭ࠥࢀࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮ࡢࠬࠩࡁࡓࡁࡻࡧࡲࠪ࡞ࠬ࠭ࠬ࠭ࠧ౯"),vyV6iO3z2NeJnITK0fLhcP)
			if not j57boOc6MmG:
				j57boOc6MmG = fNntYJW45mEFSdRX8g.findall(
					aYH620Dh48GEsTFfOBSQ7r(u"ࡸࠧࠨࠩࠫࡃࡽࡹࠩࠋࠋࠌࠍࠎࠏ࠻࡝ࡵ࠭ࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜ࡴࠬࡀࡠࡸ࠰ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠭ࠏࠏࠉࠊࠋࠌࡠࡸ࠰࡜ࡼࠪࡂ࠾࠭ࡅࠡࡾ࠽ࠬ࠲࠮࠱࠿ࡳࡧࡷࡹࡷࡴ࡜ࡴࠬࠫࡃࡕࡂࡱ࠿࡝ࠥࠫࡢ࠯࡛࡝ࡹ࠰ࡡ࠰ࡥࡷ࠹ࡡࠫࡃࡕࡃࡱࠪ࡞ࡶ࠮ࡡ࠱࡜ࡴࠬ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠪࠫࠬ౰"),
					vyV6iO3z2NeJnITK0fLhcP)
			j57boOc6MmG = fNntYJW45mEFSdRX8g.findall(j57boOc6MmG[BewrUo9ANCa17G43Sn0LH5xh][rgpY5VUqKbeFOCD9Nki2SmGvxEja]+fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࠾࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫ౱"),vyV6iO3z2NeJnITK0fLhcP,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
		else:
			def _HPzcrnZitIfxETAdmq2bLNjFW(AbmCVjhycUPswQ9kHZaMJ6p0LxG):
				import ast as JS6p9hN1FCv7tgGA8wiLj2
				Qvg1NJW8TZkt = aenpKvQCGVzhLXEdWiDIZ(u"ࡳࠩࠪࠫ࠭ࡅࡸࠪࠌࠌࠍࠎࠏࠉࠩࡁࡓࡀࡶ࠷࠾࡜ࠤ࡟ࠫࡢ࠯ࡵࡴࡧ࡟ࡷ࠰ࡹࡴࡳ࡫ࡦࡸ࠭ࡅࡐ࠾ࡳ࠴࠭ࡀࡢࡳࠫࠌࠌࠍࠎࠏࠉࠩࡁࡓࡀࡨࡵࡤࡦࡀࠍࠍࠎࠏࠉࠊࠋࡹࡥࡷࡢࡳࠬࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡࡹࠪ࠾࡞ࡶ࠮ࠏࠏࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡸࡤࡰࡺ࡫࠾ࠋࠋࠌࠍࠎࠏࠉࠊࠪࡂࡔࡁࡷ࠲࠿࡝ࠥࡠࠬࡣࠩࠩࡁ࠽ࠬࡄࠧࠨࡀࡒࡀࡵ࠷࠯ࠩ࠯ࡾ࡟ࡠ࠳࠯ࠫࠩࡁࡓࡁࡶ࠸ࠩࠋࠋࠌࠍࠎࠏࠉࠊ࡞࠱ࡷࡵࡲࡩࡵ࡞ࠫࠬࡄࡖ࠼ࡲ࠵ࡁ࡟ࠧ࠭࡝ࠪࠪࡂ࠾࠭ࡅࠡࠩࡁࡓࡁࡶ࠹ࠩࠪ࠰ࠬ࠯࠭ࡅࡐ࠾ࡳ࠶࠭ࡡ࠯ࠊࠊࠋࠌࠍࠎࠏࠉࡽࠌࠌࠍࠎࠏࠉࠊࠋ࡟࡟ࡡࡹࠪࠩࡁ࠽ࠬࡄࡖ࠼ࡲ࠶ࡁ࡟ࠧࡢࠧ࡞ࠫࠫࡃ࠿࠮࠿ࠢࠪࡂࡔࡂࡷ࠴ࠪࠫ࠱ࢀࡡࡢ࠮ࠪࠬࠫࡃࡕࡃࡱ࠵ࠫ࡟ࡷ࠯࠲࠿࡝ࡵ࠭࠭࠰ࡢ࡝ࠋࠋࠌࠍࠎࠏࠉࠪࠌࠌࠍࠎࠏࠉࠪ࡝࠾࠰ࡢࠐࠉࠊࠋࠌࠫࠬ࠭౲")
				ztXW78rPu2qj6BS3n = fNntYJW45mEFSdRX8g.search(Qvg1NJW8TZkt, AbmCVjhycUPswQ9kHZaMJ6p0LxG)
				if not ztXW78rPu2qj6BS3n: return None, None
				eWOEtfaJCL7015UYq = ztXW78rPu2qj6BS3n.group(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡱࡥࡲ࡫ࠧ౳"))
				Tm2uMDCavFnB31wGgetOKoSd = ztXW78rPu2qj6BS3n.group(SIkwCEdJHTD9v1(u"ࠪࡺࡦࡲࡵࡦࠩ౴")).strip()
				VDBHXOahf9bYik8J5xNFsWATCwz = fNntYJW45mEFSdRX8g.match(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࡶࠬ࠭ࠧࠩࡁࡻ࠭ࠏࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡲࡀ࡞ࠦࠬࡣࠩࠩࡁࡓࡀࡸࡺࡲࡪࡰࡪࡂ࠳࠰࠿ࠪࠪࡂࡔࡂࡷࠩ࡝࠰ࡶࡴࡱ࡯ࡴ࡝ࠪࠫࡃࡕࡂࡱ࠳ࡀ࡞ࠦࠬࡣࠩࠩࡁࡓࡀࡸ࡫ࡰ࠿࠰࠭ࡃ࠮࠮࠿ࡑ࠿ࡴ࠶࠮ࡢࠩࠋࠋࠌࠍࠎ࠭ࠧࠨ౵"), Tm2uMDCavFnB31wGgetOKoSd)
				if VDBHXOahf9bYik8J5xNFsWATCwz:
					hpwzbO1JuTc = VDBHXOahf9bYik8J5xNFsWATCwz.group(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡹࡴࡳ࡫ࡱ࡫ࠬ౶"))
					cAgFmrk4H9 = VDBHXOahf9bYik8J5xNFsWATCwz.group(SIkwCEdJHTD9v1(u"࠭ࡳࡦࡲࠪ౷"))
					return eWOEtfaJCL7015UYq, hpwzbO1JuTc.split(cAgFmrk4H9)
				if Tm2uMDCavFnB31wGgetOKoSd.startswith(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠢ࡜ࠤ౸")) and Tm2uMDCavFnB31wGgetOKoSd.endswith(GVurlv8HeoXEzPRiQB7Ty(u"ࠣ࡟ࠥ౹")):
					try:
						wlzmr4inO3TGcDYqWa = JS6p9hN1FCv7tgGA8wiLj2.literal_eval(Tm2uMDCavFnB31wGgetOKoSd)
						return eWOEtfaJCL7015UYq, wlzmr4inO3TGcDYqWa
					except: return eWOEtfaJCL7015UYq, None
				return eWOEtfaJCL7015UYq, None
			def _xM1U4859t0QeuGWmKLbpE(AbmCVjhycUPswQ9kHZaMJ6p0LxG):
				eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu = _HPzcrnZitIfxETAdmq2bLNjFW(AbmCVjhycUPswQ9kHZaMJ6p0LxG)
				FyxG6LNA4bI = None
				if L7Oh1Nc32pZBo5iTu:
					try: basestring
					except NameError: basestring = str
					for I3qosYg7HjWda1uEJexb0wOPhlFn8B in L7Oh1Nc32pZBo5iTu:
						if isinstance(I3qosYg7HjWda1uEJexb0wOPhlFn8B, basestring) and I3qosYg7HjWda1uEJexb0wOPhlFn8B.endswith(gDETKVh8mZe09Nd(u"ࠩ࠰ࡣࡼ࠾࡟ࠨ౺")):
							FyxG6LNA4bI = I3qosYg7HjWda1uEJexb0wOPhlFn8B
							break
				if FyxG6LNA4bI:
					Qvg1NJW8TZkt = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࡵࠫࠬ࠭ࠨࡀࡺࠬࠎࠎࠏࠉࠊࠋࠌࡠࢀࡢࡳࠫࡴࡨࡸࡺࡸ࡮࡝ࡵ࠮ࠩࡸࡢ࡛ࠦࡦ࡟ࡡࡡࡹࠪ࡝࠭࡟ࡷ࠯࠮࠿ࡑ࠾ࡤࡶ࡬ࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡࡹࠪ࡝ࡿࠍࠍࠎࠏࠉࠊࠩࠪࠫ౻") % (fNntYJW45mEFSdRX8g.escape(eWOEtfaJCL7015UYq), L7Oh1Nc32pZBo5iTu.index(FyxG6LNA4bI))
					match = fNntYJW45mEFSdRX8g.search(Qvg1NJW8TZkt, AbmCVjhycUPswQ9kHZaMJ6p0LxG)
					if match:
						Qvg1NJW8TZkt = Js61GTdX5wzMurUqi7Z(u"ࡶࠬ࠭ࠧࠩࡁࡻ࠭ࠏࠏࠉࠊࠋࠌࠍࠎࡢࡻ࡝ࡵ࠭ࡠ࠮ࠫࡳ࡝ࠪ࡟ࡷ࠯ࠐࠉࠊࠋࠌࠍࠎࠏࠨࡀ࠼ࠍࠍࠎࠏࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡨࡸࡲࡨࡴࡡ࡮ࡧࡢࡥࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜ࡴࠬࡱࡳ࡮ࡺࡣ࡯ࡷࡩࡠࡸ࠰ࠊࠊࠋࠌࠍࠎࠏࠉࠊࡾࡱࡳ࡮ࡺࡣ࡯ࡷࡩࡠࡸ࠰࠽࡝ࡵ࠭ࠬࡄࡖ࠼ࡧࡷࡱࡧࡳࡧ࡭ࡦࡡࡥࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯࠮࠮࠿࠻࡞ࡶ࠯ࡷࡧࡶࠪࡁࠍࠍࠎࠏࠉࠊࠋࠌ࠭ࡠࡁ࡜࡯࡟ࠍࠍࠎࠏࠉࠊࠋࠪࠫࠬ౼") % fNntYJW45mEFSdRX8g.escape(match.group(jwzOabysh0Z(u"ࠬࡧࡲࡨࡰࡤࡱࡪ࠭౽"))[::-Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠶໐")])
						NgLfJGiyXEOewo = fNntYJW45mEFSdRX8g.search(Qvg1NJW8TZkt, AbmCVjhycUPswQ9kHZaMJ6p0LxG[match.start()::-jwzOabysh0Z(u"࠷໑")])
						if NgLfJGiyXEOewo:
							WRBJCFc6Yg, cce6g1pARrUxGuEySF4 = NgLfJGiyXEOewo.group(aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡦࡶࡰࡦࡲࡦࡳࡥࡠࡣࠪ౾"), Js61GTdX5wzMurUqi7Z(u"ࠧࡧࡷࡱࡧࡳࡧ࡭ࡦࡡࡥࠫ౿"))
							return (WRBJCFc6Yg or cce6g1pARrUxGuEySF4)[::-zLjWeKu6JgNO7vocUD0Qpy(u"࠱໒")], eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu
				PKIDLO9ZsGaw03icp5e6Yq = fNntYJW45mEFSdRX8g.compile(Js61GTdX5wzMurUqi7Z(u"ࡳࠩࠪࠫ࠭ࡅࡸࠪࠌࠌࠍࠎࠏࠉࠩࡁ࠽ࠎࠎࠏࠉࠊࠋࠌࡠ࠳࡭ࡥࡵ࡞ࠫࠦࡳࠨ࡜ࠪ࡞ࠬࠪࠫࡢࠨࡣ࠿ࡿࠎࠎࠏࠉࠊࠋࠌࠬࡄࡀࠊࠊࠋࠌࠍࠎࠏࠉࡣ࠿ࡖࡸࡷ࡯࡮ࡨ࡞࠱ࡪࡷࡵ࡭ࡄࡪࡤࡶࡈࡵࡤࡦ࡞ࠫ࠵࠶࠶࡜ࠪࡾࠍࠍࠎࠏࠉࠊࠋࠌࠬࡄࡖ࠼ࡴࡶࡵࡣ࡮ࡪࡸ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࠮࡞࠭ࠬࠪࠫࡢࠨࡣ࠿ࠥࡲࡳࠨ࡜࡜࡞࠮ࠬࡄࡖ࠽ࡴࡶࡵࡣ࡮ࡪࡸࠪ࡞ࡠࠎࠎࠏࠉࠊࠋࠌ࠭ࠏࠏࠉࠊࠋࠌࠍ࠭ࡅ࠺ࠋࠋࠌࠍࠎࠏࠉࠊ࠮࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟ࠬࡦࡢࠩࠪࡁ࠯ࡧࡂࡧ࡜࠯ࠌࠌࠍࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎࠏࠉࡨࡧࡷࡠ࠭ࡨ࡜ࠪࡾࠍࠍࠎࠏࠉࠊࠋࠌࠍࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡࡡࡢ࡝࡟࡟ࢀࡡࢂ࡮ࡶ࡮࡯ࠎࠎࠏࠉࠊࠋࠌࠍ࠮ࡢࠩࠧࠨ࡟ࠬࡨࡃࡼࠋࠋࠌࠍࠎࠏࠉ࡝ࡤࠫࡃࡕࡂࡶࡢࡴࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡂࠐࠉࠊࠋࠌࠍ࠮࠮࠿ࡑ࠾ࡱࡪࡺࡴࡣ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫࠫࡃ࠿ࡢ࡛ࠩࡁࡓࡀ࡮ࡪࡸ࠿࡞ࡧ࠯࠮ࡢ࡝ࠪࡁ࡟ࠬࡠࡧ࠭ࡻࡃ࠰࡞ࡢࡢࠩࠋࠋࠌࠍࠎࠏࠨࡀࠪࡹࡥࡷ࠯ࠬ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࠰ࡶࡩࡹࡢࠨࠩࡁ࠽ࠦࡳ࠱ࠢࡽ࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡤࠪ࡝ࠬࠫ࡟࠰࠭ࡅࡐ࠾ࡸࡤࡶ࠮ࡢࠩࠪࠌࠌࠍࠎࠏࠧࠨࠩಀ"))
				match = PKIDLO9ZsGaw03icp5e6Yq.search(AbmCVjhycUPswQ9kHZaMJ6p0LxG)
				USLV9vK6umtAZGyIN8Wg, oYTBMPpewq6ZmCO27tiD4HEzJKy = (None, None)
				if match:
					USLV9vK6umtAZGyIN8Wg = match.group(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡱࡪࡺࡴࡣࠨಁ"))
					oYTBMPpewq6ZmCO27tiD4HEzJKy = match.group(SE97R3Dpj6dPLweVKU(u"ࠪ࡭ࡩࡾࠧಂ"))
				if not USLV9vK6umtAZGyIN8Wg:
					print(GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡋࡧ࡬࡭࡫ࡱ࡫ࠥࡨࡡࡤ࡭ࠣࡸࡴࠦࡧࡦࡰࡨࡶ࡮ࡩࠠ࡯ࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡸ࡫ࡡࡳࡥ࡫ࠫಃ"))
					VPiuZ0BlKJnHQYpgsXb = fNntYJW45mEFSdRX8g.search(qqw1upCsKM(u"ࡷ࠭ࠧࠨࠪࡂࡼࡸ࠯ࠊࠊࠋࠌࠍࠎࠏ࠻࡝ࡵ࠭ࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯࡜ࡴࠬࡀࡠࡸ࠰ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠭ࠏࠏࠉࠊࠋࠌࠍࡡࡹࠪ࡝ࡽࠫࡃ࠿࠮࠿ࠢࡿ࠾࠭࠳࠯ࠫࡀࡴࡨࡸࡺࡸ࡮࡝ࡵ࠭ࠬࡄࡖ࠼ࡲࡀ࡞ࠦࠬࡣࠩ࡜࡞ࡺ࠱ࡢ࠱࡟ࡸ࠺ࡢࠬࡄࡖ࠽ࡲࠫ࡟ࡷ࠯ࡢࠫ࡝ࡵ࠭࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮ࠎࠎࠏࠉࠊࠋࠪࠫࠬ಄"), AbmCVjhycUPswQ9kHZaMJ6p0LxG)
					if VPiuZ0BlKJnHQYpgsXb: return VPiuZ0BlKJnHQYpgsXb.group(aenpKvQCGVzhLXEdWiDIZ(u"࠭࡮ࡢ࡯ࡨࠫಅ")), eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu
					return None,None,None
				elif not oYTBMPpewq6ZmCO27tiD4HEzJKy: return USLV9vK6umtAZGyIN8Wg, eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu
				XDWVLpOofZva6Tb8JGBQ3S = fNntYJW45mEFSdRX8g.search(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࡲࠨࡸࡤࡶࠥࢁࡽ࡝࡞ࡶ࠮ࡂࡢ࡜ࡴࠬࠫࡠࡡࡡ࠮ࠬࡁ࡟ࡠࡢ࠯࡜࡝ࡵ࠭࡟࠱ࡁ࡝ࠨಆ").format(fNntYJW45mEFSdRX8g.escape(USLV9vK6umtAZGyIN8Wg)), AbmCVjhycUPswQ9kHZaMJ6p0LxG)
				if XDWVLpOofZva6Tb8JGBQ3S: return Kdnrl9JHV0cFaGzC5bN.loads(DQn7vefpB3(XDWVLpOofZva6Tb8JGBQ3S.group(YQNd4wejLSAVJ6T(u"࠲໓"))))[int(oYTBMPpewq6ZmCO27tiD4HEzJKy)], eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu
				return None, eWOEtfaJCL7015UYq, L7Oh1Nc32pZBo5iTu
			j57boOc6MmG, MyvTBu7OS98olzUYkpihsa, L7Oh1Nc32pZBo5iTu = _xM1U4859t0QeuGWmKLbpE(vyV6iO3z2NeJnITK0fLhcP)
			SMDQP8oO1CgB93YkpuFljEt = Kdnrl9JHV0cFaGzC5bN.dumps(L7Oh1Nc32pZBo5iTu)
			QsfPlTBz5yw3kWu4Na0RMKVm = vyV6iO3z2NeJnITK0fLhcP.find(j57boOc6MmG+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠿ࡩࡹࡳࡩࡴࡪࡱࡱࠬࠬಇ"))
			VCNpi5JZXQv2Mxo7szfIeHjhK = vyV6iO3z2NeJnITK0fLhcP.find(hPFcB6Uxmabj59Iq(u"ࠩࢀ࠿ࠬಈ"), QsfPlTBz5yw3kWu4Na0RMKVm)
			X105wgIbC6yRSa = vyV6iO3z2NeJnITK0fLhcP[QsfPlTBz5yw3kWu4Na0RMKVm:VCNpi5JZXQv2Mxo7szfIeHjhK]+IOHSz7YPF9WusGgUt1Dq(u"ࠪࢁࡀ࠭ಉ")
			xcW7UHYgNilVzCepEkBmh1dsF = fNntYJW45mEFSdRX8g.findall(bGzRdmOErkIylxALniq6(u"ࡶࠬ࡯ࡦ࡝ࠪࡷࡽࡵ࡫࡯ࡧࠢ࠱࠮ࡄࡃ࠽࠾࠰࠭ࡃࡡ࠯ࡲࡦࡶࡸࡶࡳࠦ࠮࠼ࠩಊ"), X105wgIbC6yRSa, fNntYJW45mEFSdRX8g.DOTALL)
			if xcW7UHYgNilVzCepEkBmh1dsF: X105wgIbC6yRSa = X105wgIbC6yRSa.replace(xcW7UHYgNilVzCepEkBmh1dsF[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠲໔")],XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠭ಋ"))
			if not MyvTBu7OS98olzUYkpihsa: MyvTBu7OS98olzUYkpihsa = fNntYJW45mEFSdRX8g.findall(RDwahqjPfbdyEiTtnLQu(u"࠭ࡶࡢࡴࠣ࠲࠯ࡅ࠽ࠩ࠰࠭ࡃ࠮ࡢ࠮ࠨಌ"),X105wgIbC6yRSa,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
			X105wgIbC6yRSa = RDwahqjPfbdyEiTtnLQu(u"ࠢࡷࡣࡵࠤࢀࢃࠠ࠾ࠢࡾࢁࡀࡢ࡮ࡼࡿࠥ಍").format(MyvTBu7OS98olzUYkpihsa, SMDQP8oO1CgB93YkpuFljEt, X105wgIbC6yRSa)
			MMJc7OYbNkTj = {}
			u85uJviYhCReWAzXdDpyU1jroS7k = []
			for jjuIXCe4szB9USAfWKkgMrx5GpFVh in osyGOj5uFL:
				url = jjuIXCe4szB9USAfWKkgMrx5GpFVh[TzIj50KpohEOHx6CbZWqB(u"ࠨࡷࡵࡰࠬಎ")]
				if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࠩࡲࡂ࠭ಏ") in url:
					vcu3HlQwVBKfMdqYeC = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠪࠪࡳࡃࠨ࠯ࠬࡂ࠭ࠫ࠭ಐ"),url,fNntYJW45mEFSdRX8g.DOTALL)[BewrUo9ANCa17G43Sn0LH5xh]
					if vcu3HlQwVBKfMdqYeC not in list(MMJc7OYbNkTj.keys()):
						Ksk6U1TWJ0N8faAj7xvQHSVFeXGRp = iFhUJ1tGmzoRjK(X105wgIbC6yRSa,[j57boOc6MmG,vcu3HlQwVBKfMdqYeC])
						MMJc7OYbNkTj[vcu3HlQwVBKfMdqYeC] = Ksk6U1TWJ0N8faAj7xvQHSVFeXGRp
					else: Ksk6U1TWJ0N8faAj7xvQHSVFeXGRp = MMJc7OYbNkTj[vcu3HlQwVBKfMdqYeC]
					jjuIXCe4szB9USAfWKkgMrx5GpFVh[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡺࡸ࡬ࠨ಑")] = url.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࠬ࡮࠾ࠩಒ")+vcu3HlQwVBKfMdqYeC+GVurlv8HeoXEzPRiQB7Ty(u"࠭ࠦࠨಓ"),SIkwCEdJHTD9v1(u"ࠧࠧࡰࡀࠫಔ")+Ksk6U1TWJ0N8faAj7xvQHSVFeXGRp+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࠨࠪಕ"))
				u85uJviYhCReWAzXdDpyU1jroS7k.append(jjuIXCe4szB9USAfWKkgMrx5GpFVh)
			osyGOj5uFL = u85uJviYhCReWAzXdDpyU1jroS7k.copy()
	for dict in osyGOj5uFL:
		url = dict[TzIj50KpohEOHx6CbZWqB(u"ࠩࡸࡶࡱ࠭ಖ")]
		if qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧಗ") in url or url.count(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡸ࡯ࡧ࠾ࠩಘ"))>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			CWB4ISRmwJf.append(dict)
		elif vyV6iO3z2NeJnITK0fLhcP and oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡹࠧಙ") in list(dict.keys()) and phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡳࡱࠩಚ") in list(dict.keys()):
			kZfoa6Yyc5gVWHJLp48CKsxn73 = SH4XB2IQ68.execute(dict[bGzRdmOErkIylxALniq6(u"ࠧࡴࠩಛ")])
			if kZfoa6Yyc5gVWHJLp48CKsxn73!=dict[EJgYdjbIiWe1apkQlZcR42(u"ࠨࡵࠪಜ")]:
				dict[oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡸࡶࡱ࠭ಝ")] = url+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࠪࠬಞ")+dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡸࡶࠧಟ")]+hPFcB6Uxmabj59Iq(u"ࠬࡃࠧಠ")+kZfoa6Yyc5gVWHJLp48CKsxn73
				CWB4ISRmwJf.append(dict)
	for dict in CWB4ISRmwJf:
		ccDFuk5NAjMTqo3hv,v6vEJozatcXnq9lCZKgNhGrdTfHjQ,VqACnoPRiEy,Ffh8yTQ3d6sp,pTLD9IsRc3MXJASKPu,qlu4QIrH7GwzJ5LTn8jKA = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧಡ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨಢ"),jwzOabysh0Z(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩಣ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪತ"),sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"ࠪ࠴ࠬಥ")
		try:
			y8G6BfEtKM = dict[RDwahqjPfbdyEiTtnLQu(u"ࠫࡹࡿࡰࡦࠩದ")]
			y8G6BfEtKM = y8G6BfEtKM.replace(SIkwCEdJHTD9v1(u"ࠬ࠱ࠧಧ"),sCHVtMAvqirbQ4BUK3cgWo)
			items = fNntYJW45mEFSdRX8g.findall(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨನ"),y8G6BfEtKM,fNntYJW45mEFSdRX8g.DOTALL)
			Ffh8yTQ3d6sp,ccDFuk5NAjMTqo3hv,pTLD9IsRc3MXJASKPu = items[BewrUo9ANCa17G43Sn0LH5xh]
			kjqdTSZhLita3r = pTLD9IsRc3MXJASKPu.split(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ࠭ࠩ಩"))
			v6vEJozatcXnq9lCZKgNhGrdTfHjQ = sCHVtMAvqirbQ4BUK3cgWo
			for UqKgalXPCz7eQAL08foMx1R in kjqdTSZhLita3r: v6vEJozatcXnq9lCZKgNhGrdTfHjQ += UqKgalXPCz7eQAL08foMx1R.split(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࠰ࠪಪ"))[BewrUo9ANCa17G43Sn0LH5xh]+sH6BOz5wKRFcEg(u"ࠩ࠯ࠫಫ")
			v6vEJozatcXnq9lCZKgNhGrdTfHjQ = v6vEJozatcXnq9lCZKgNhGrdTfHjQ.strip(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪ࠰ࠬಬ"))
			if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬಭ") in list(dict.keys()): qlu4QIrH7GwzJ5LTn8jKA = str(int(dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ಮ")])//sH6BOz5wKRFcEg(u"࠴࠴࠷࠺໕"))+TzIj50KpohEOHx6CbZWqB(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ಯ")
			else: qlu4QIrH7GwzJ5LTn8jKA = sCHVtMAvqirbQ4BUK3cgWo
			if Ffh8yTQ3d6sp==EJgYdjbIiWe1apkQlZcR42(u"ࠧࡵࡧࡻࡸࠬರ"): continue
			elif SIkwCEdJHTD9v1(u"ࠨ࠮ࠪಱ") in y8G6BfEtKM:
				Ffh8yTQ3d6sp = aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡄ࠯࡛࠭ಲ")
				VqACnoPRiEy = ccDFuk5NAjMTqo3hv+LvzD9S8RPyGeukZQqb2T0B+qlu4QIrH7GwzJ5LTn8jKA+dict[IOHSz7YPF9WusGgUt1Dq(u"ࠪࡷ࡮ࢀࡥࠨಳ")].split(hPFcB6Uxmabj59Iq(u"ࠫࡽ࠭಴"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			elif Ffh8yTQ3d6sp==sH6BOz5wKRFcEg(u"ࠬࡼࡩࡥࡧࡲࠫವ"):
				Ffh8yTQ3d6sp = jwzOabysh0Z(u"࠭ࡖࡪࡦࡨࡳࠬಶ")
				VqACnoPRiEy = qlu4QIrH7GwzJ5LTn8jKA+dict[GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡴ࡫ࡽࡩࠬಷ")].split(EJgYdjbIiWe1apkQlZcR42(u"ࠨࡺࠪಸ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]+LvzD9S8RPyGeukZQqb2T0B+dict[IO7k2hZXSz(u"ࠩࡩࡴࡸ࠭ಹ")]+GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡪࡵࡹࠧ಺")+LvzD9S8RPyGeukZQqb2T0B+ccDFuk5NAjMTqo3hv
			elif Ffh8yTQ3d6sp==YQNd4wejLSAVJ6T(u"ࠫࡦࡻࡤࡪࡱࠪ಻"):
				Ffh8yTQ3d6sp = jwzOabysh0Z(u"ࠬࡇࡵࡥ࡫ࡲ಼ࠫ")
				VqACnoPRiEy = qlu4QIrH7GwzJ5LTn8jKA+str(int(dict[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪಽ")])/TzIj50KpohEOHx6CbZWqB(u"࠵࠵࠶࠰໖"))+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࡬ࡪࡽࠤࠥ࠭ಾ")+dict[Js61GTdX5wzMurUqi7Z(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩಿ")]+BWfpRku7SsM6cbE0eG(u"ࠩࡦ࡬ࠬೀ")+LvzD9S8RPyGeukZQqb2T0B+ccDFuk5NAjMTqo3hv
		except:
			Ro2CsQFGOj14wKIgcuHJ = xlRuE56JKzkBeZbX1AqYUGrCfy0apj.format_exc()
			if Ro2CsQFGOj14wKIgcuHJ!=gDETKVh8mZe09Nd(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ು"): xlOFiKpdTI1Vjw5YN.stderr.write(Ro2CsQFGOj14wKIgcuHJ)
		if iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡩࡻࡲ࠾ࠩೂ") in dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡻࡲ࡭ࠩೃ")]: yAMScJ6z3E8 = round(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠶࠮࠶໘")+float(dict[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡵࡳ࡮ࠪೄ")].split(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡥࡷࡵࡁࠬ೅"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠶໗"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].split(aYH620Dh48GEsTFfOBSQ7r(u"ࠨࠨࠪೆ"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[BewrUo9ANCa17G43Sn0LH5xh]))
		elif iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬೇ") in list(dict.keys()): yAMScJ6z3E8 = round(oVwa0kcqxj1e7mLplAfZdGT(u"࠰࠯࠷໙")+float(dict[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭ೈ")])/Js61GTdX5wzMurUqi7Z(u"࠲࠲࠳࠴໚"))
		else: yAMScJ6z3E8 = zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࠵࠭೉")
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ೊ") not in list(dict.keys()): qlu4QIrH7GwzJ5LTn8jKA = dict[TzIj50KpohEOHx6CbZWqB(u"࠭ࡳࡪࡼࡨࠫೋ")].split(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡹࠩೌ"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		else: qlu4QIrH7GwzJ5LTn8jKA = str(int(dict[aYH620Dh48GEsTFfOBSQ7r(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦ್ࠩ")])//XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠳࠳࠶࠹໛"))
		if Js61GTdX5wzMurUqi7Z(u"ࠩ࡬ࡲ࡮ࡺࠧ೎") not in list(dict.keys()): dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪ࡭ࡳ࡯ࡴࠨ೏")] = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࠵࠳࠰ࠨ೐")
		dict[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡺࡩࡵ࡮ࡨࠫ೑")] = Ffh8yTQ3d6sp+XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࠺ࠡࠢࠪ೒")+VqACnoPRiEy+BWfpRku7SsM6cbE0eG(u"ࠧࠡࠢࠫࠫ೓")+v6vEJozatcXnq9lCZKgNhGrdTfHjQ+hPFcB6Uxmabj59Iq(u"ࠨ࠮ࠪ೔")+dict[IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡬ࡸࡦ࡭ࠧೕ")]+YQNd4wejLSAVJ6T(u"ࠪ࠭ࠬೖ")
		dict[t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ೗")] = VqACnoPRiEy.split(LvzD9S8RPyGeukZQqb2T0B)[BewrUo9ANCa17G43Sn0LH5xh].split(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡱࡢࡱࡵࠪ೘"))[BewrUo9ANCa17G43Sn0LH5xh]
		dict[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡴࡺࡲࡨ࠶ࠬ೙")] = Ffh8yTQ3d6sp
		dict[SE97R3Dpj6dPLweVKU(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ೚")] = ccDFuk5NAjMTqo3hv
		dict[aenpKvQCGVzhLXEdWiDIZ(u"ࠨࡥࡲࡨࡪࡩࡳࠨ೛")] = pTLD9IsRc3MXJASKPu
		dict[oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ೜")] = yAMScJ6z3E8
		dict[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫೝ")] = qlu4QIrH7GwzJ5LTn8jKA
		IvibBZT49cOF.append(dict)
	cfIloQAC52Yk6wgGnPNZ,RSHE5Qpoe4c2ki,NrKkUPaJ41qCO2jypBRl,MgFk13BDAoxrvuIlp,yxzhsqHpbIDVBT7ENAdl0OrawL = [],[],[],[],[]
	w65wP4VkmvNIlcUeuY,pmg89l7PQJRIa,yhpBLDoPTfsde6Gvg2Ha,yJrYRMbFPjW9o4aNxl3ncsekhf,ddtklBKAvZIzTVig30OUocEG6Xf = [],[],[],[],[]
	for wSRsL5uY93n6Cx08tPTGMNAVq4 in wfpuA0xUBTcanjVGYh97N2F6rdLH:
		if not wSRsL5uY93n6Cx08tPTGMNAVq4: continue
		dict = {}
		dict[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡹࡿࡰࡦ࠴ࠪೞ")] = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡇࠫࡗࠩ೟")
		dict[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨೠ")] = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࡮ࡲࡧࠫೡ")
		dict[wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡶ࡬ࡸࡱ࡫ࠧೢ")] = dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡷࡽࡵ࡫࠲ࠨೣ")]+zLjWeKu6JgNO7vocUD0Qpy(u"ࠪ࠾ࠥࠦࠧ೤")+dict[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭೥")]+LvzD9S8RPyGeukZQqb2T0B+Js61GTdX5wzMurUqi7Z(u"ࠬา่ะหࠣิ่๐ษࠨ೦")
		dict[IOHSz7YPF9WusGgUt1Dq(u"࠭ࡵࡳ࡮ࠪ೧")] = wSRsL5uY93n6Cx08tPTGMNAVq4
		dict[IO7k2hZXSz(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ೨")] = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨ࠲ࠪ೩")
		dict[SIkwCEdJHTD9v1(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ೪")] = IOHSz7YPF9WusGgUt1Dq(u"ࠪ࠵࠶࠷࠲࠳࠴࠶࠷࠸࠭೫")
		IvibBZT49cOF.append(dict)
	for jQEWmUBnNaIcCsoVuSp in q2oK8MyOUi7uZj9b3vFdpaQxJ:
		if not jQEWmUBnNaIcCsoVuSp: continue
		FLVObYDAIwx1,ZNnRHC1ldwyafz9JvSB7oFTcrAmq = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,jQEWmUBnNaIcCsoVuSp)
		uxzFHaohVPtAq = list(zip(FLVObYDAIwx1,ZNnRHC1ldwyafz9JvSB7oFTcrAmq))
		for title,B17r2fdFy9ns8tiOMLu in uxzFHaohVPtAq:
			dict = {}
			dict[bGzRdmOErkIylxALniq6(u"ࠫࡹࡿࡰࡦ࠴ࠪ೬")] = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡇࠫࡗࠩ೭")
			dict[bGzRdmOErkIylxALniq6(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ೮")] = EJgYdjbIiWe1apkQlZcR42(u"ࠧ࡮࠵ࡸ࠼ࠬ೯")
			dict[TzIj50KpohEOHx6CbZWqB(u"ࠨࡷࡵࡰࠬ೰")] = B17r2fdFy9ns8tiOMLu
			if E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࡮ࡦࡵࡹࠧೱ") in title: dict[qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫೲ")] = title.split(GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡰࡨࡰࡴࠩೳ"))[BewrUo9ANCa17G43Sn0LH5xh].rsplit(LvzD9S8RPyGeukZQqb2T0B)[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			else: dict[SIkwCEdJHTD9v1(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭೴")] = zLjWeKu6JgNO7vocUD0Qpy(u"࠭࠱࠱ࠩ೵")
			if title.count(LvzD9S8RPyGeukZQqb2T0B)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				XO7Zr2W6kwieA = title.rsplit(LvzD9S8RPyGeukZQqb2T0B)[-vUnJhT2NO8yirHcAmg]
				if XO7Zr2W6kwieA.isdigit(): dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ೶")] = XO7Zr2W6kwieA
				else: dict[sH6BOz5wKRFcEg(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ೷")] = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠳࠴࠵࠶ࠧ೸")
			if title==Js61GTdX5wzMurUqi7Z(u"ࠪ࠱࠶࠭೹"): dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ೺")] = dict[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡺࡹࡱࡧ࠵ࠫ೻")]+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭࠺ࠡࠢࠪ೼")+dict[oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ೽")]+LvzD9S8RPyGeukZQqb2T0B+hPFcB6Uxmabj59Iq(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ೾")
			else: dict[sH6BOz5wKRFcEg(u"ࠩࡷ࡭ࡹࡲࡥࠨ೿")] = dict[RDwahqjPfbdyEiTtnLQu(u"ࠪࡸࡾࡶࡥ࠳ࠩഀ")]+GVurlv8HeoXEzPRiQB7Ty(u"ࠫ࠿ࠦࠠࠨഁ")+dict[IOHSz7YPF9WusGgUt1Dq(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧം")]+LvzD9S8RPyGeukZQqb2T0B+dict[sH6BOz5wKRFcEg(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧഃ")]+qqw1upCsKM(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧഄ")+dict[BWfpRku7SsM6cbE0eG(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩഅ")]
			IvibBZT49cOF.append(dict)
	IvibBZT49cOF = sorted(IvibBZT49cOF,reverse=ndkUxG9LtewJ,key=lambda key: int(key[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪആ")]))
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [YQNd4wejLSAVJ6T(u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧഇ")],[sCHVtMAvqirbQ4BUK3cgWo]
	try: S0JdP2i3bsZtm94jHKnhDTWE7aBNU = DJ1elACSdx0LbI73yrG9ajZWg2VtX[aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭ഈ")][TzIj50KpohEOHx6CbZWqB(u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩഉ")][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭ഊ")]
	except: S0JdP2i3bsZtm94jHKnhDTWE7aBNU = []
	try: DEIBRxtJqnUWy2QS7 = DJ1elACSdx0LbI73yrG9ajZWg2VtX[Js61GTdX5wzMurUqi7Z(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩഋ")][phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬഌ")][t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩ഍")]
	except: DEIBRxtJqnUWy2QS7 = []
	for SS6wt7fJCAuYk1M4 in S0JdP2i3bsZtm94jHKnhDTWE7aBNU+DEIBRxtJqnUWy2QS7:
		try:
			B17r2fdFy9ns8tiOMLu = SS6wt7fJCAuYk1M4[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫഎ")]
			try: title = SS6wt7fJCAuYk1M4[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡳࡧ࡭ࡦࠩഏ")][IO7k2hZXSz(u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩഐ")]
			except: title = SS6wt7fJCAuYk1M4[EJgYdjbIiWe1apkQlZcR42(u"࠭࡮ࡢ࡯ࡨࠫ഑")][EJgYdjbIiWe1apkQlZcR42(u"ࠧࡳࡷࡱࡷࠬഒ")][BewrUo9ANCa17G43Sn0LH5xh][XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡶࡨࡼࡹ࠭ഓ")]
		except: continue
		if title not in V9TdsglcWYv0X:
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			V9TdsglcWYv0X.append(title)
	if len(V9TdsglcWYv0X)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(TzIj50KpohEOHx6CbZWqB(u"ࠩสาฯืࠠศๆอีั๋ษࠡࠪࠪഔ")+str(len(V9TdsglcWYv0X))+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࠤ๊๊แࠪࠩക"),V9TdsglcWYv0X)
		if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩഖ"),[],[]
		elif jQLzA92KFEcpw!=BewrUo9ANCa17G43Sn0LH5xh:
			B17r2fdFy9ns8tiOMLu = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]+sH6BOz5wKRFcEg(u"ࠬࠬࠧഗ")
			SP8btdzAOqi = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫഘ"),B17r2fdFy9ns8tiOMLu)
			if SP8btdzAOqi: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(SP8btdzAOqi[BewrUo9ANCa17G43Sn0LH5xh],SE97R3Dpj6dPLweVKU(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨങ"))
			else: B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+sH6BOz5wKRFcEg(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩച")
			FFlXsxdANwVr4 = B17r2fdFy9ns8tiOMLu.strip(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࠩࠫഛ"))
	zhi6So8CxtLT = []
	for dict in IvibBZT49cOF:
		if dict[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠪࡸࡾࡶࡥ࠳ࠩജ")]==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࡛ࠫ࡯ࡤࡦࡱࠪഝ"):
			cfIloQAC52Yk6wgGnPNZ.append(dict[phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡺࡩࡵ࡮ࡨࠫഞ")])
			w65wP4VkmvNIlcUeuY.append(dict)
		elif dict[SIkwCEdJHTD9v1(u"࠭ࡴࡺࡲࡨ࠶ࠬട")]==fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡂࡷࡧ࡭ࡴ࠭ഠ"):
			RSHE5Qpoe4c2ki.append(dict[Js61GTdX5wzMurUqi7Z(u"ࠨࡶ࡬ࡸࡱ࡫ࠧഡ")])
			pmg89l7PQJRIa.append(dict)
		elif dict[jwzOabysh0Z(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫഢ")]==qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡱࡵࡪࠧണ"):
			title = dict[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡹ࡯ࡴ࡭ࡧࠪത")].replace(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࡇࠫࡗ࠼ࠣࠤࠬഥ"),sCHVtMAvqirbQ4BUK3cgWo)
			if fvYGxnZNUiyP4HJkMIoS25(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧദ") not in list(dict.keys()): qlu4QIrH7GwzJ5LTn8jKA = BWfpRku7SsM6cbE0eG(u"ࠧ࠱ࠩധ")
			else: qlu4QIrH7GwzJ5LTn8jKA = dict[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩന")]
			zhi6So8CxtLT.append([dict,{},title,qlu4QIrH7GwzJ5LTn8jKA])
		else:
			title = dict[fvYGxnZNUiyP4HJkMIoS25(u"ࠩࡷ࡭ࡹࡲࡥࠨഩ")].replace(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪപ"),sCHVtMAvqirbQ4BUK3cgWo)
			if GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬഫ") not in list(dict.keys()): qlu4QIrH7GwzJ5LTn8jKA = sH6BOz5wKRFcEg(u"ࠬ࠶ࠧബ")
			else: qlu4QIrH7GwzJ5LTn8jKA = dict[TzIj50KpohEOHx6CbZWqB(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧഭ")]
			zhi6So8CxtLT.append([dict,{},title,qlu4QIrH7GwzJ5LTn8jKA])
			NrKkUPaJ41qCO2jypBRl.append(title)
			yhpBLDoPTfsde6Gvg2Ha.append(dict)
		c0LyAWNTu8B2pZvw9FnHKMiR = ndkUxG9LtewJ
		if TzIj50KpohEOHx6CbZWqB(u"ࠧࡤࡱࡧࡩࡨࡹࠧമ") in list(dict.keys()):
			if qqw1upCsKM(u"ࠨࡣࡹ࠴ࠬയ") in dict[t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩര")]: c0LyAWNTu8B2pZvw9FnHKMiR = lvzrYTpcBaK
			elif A4AOrGi8QL<qqw1upCsKM(u"࠴࠼ໜ") and bGzRdmOErkIylxALniq6(u"ࠪࡥࡻࡩࠧറ") not in dict[zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡨࡵࡤࡦࡥࡶࠫല")] and wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡳࡰ࠵ࡣࠪള") not in dict[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ഴ")]: c0LyAWNTu8B2pZvw9FnHKMiR = lvzrYTpcBaK
		if c0LyAWNTu8B2pZvw9FnHKMiR and dict[jwzOabysh0Z(u"ࠧࡵࡻࡳࡩ࠷࠭വ")]==IOHSz7YPF9WusGgUt1Dq(u"ࠨࡘ࡬ࡨࡪࡵࠧശ") and dict[jwzOabysh0Z(u"ࠩ࡬ࡲ࡮ࡺࠧഷ")]!=qqw1upCsKM(u"ࠪ࠴࠲࠶ࠧസ"):
			yxzhsqHpbIDVBT7ENAdl0OrawL.append(dict[qqw1upCsKM(u"ࠫࡹ࡯ࡴ࡭ࡧࠪഹ")])
			ddtklBKAvZIzTVig30OUocEG6Xf.append(dict)
		elif c0LyAWNTu8B2pZvw9FnHKMiR and dict[qqw1upCsKM(u"ࠬࡺࡹࡱࡧ࠵ࠫഺ")]==TzIj50KpohEOHx6CbZWqB(u"࠭ࡁࡶࡦ࡬ࡳ഻ࠬ") and dict[EJgYdjbIiWe1apkQlZcR42(u"ࠧࡪࡰ࡬ࡸ഼ࠬ")]!=YQNd4wejLSAVJ6T(u"ࠨ࠲࠰࠴ࠬഽ"):
			MgFk13BDAoxrvuIlp.append(dict[qqw1upCsKM(u"ࠩࡷ࡭ࡹࡲࡥࠨാ")])
			yJrYRMbFPjW9o4aNxl3ncsekhf.append(dict)
	for EEIv0FOyotfY7UDjhs in yJrYRMbFPjW9o4aNxl3ncsekhf:
		i6Pagty1A2S5LJx = EEIv0FOyotfY7UDjhs[IOHSz7YPF9WusGgUt1Dq(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫി")]
		for KpCfd8EGrwhkic2n571H3aDPozUtvL in ddtklBKAvZIzTVig30OUocEG6Xf:
			IWetJVFc0DLGlkOmE3CQsN = KpCfd8EGrwhkic2n571H3aDPozUtvL[GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬീ")]
			qlu4QIrH7GwzJ5LTn8jKA = int(IWetJVFc0DLGlkOmE3CQsN)+int(i6Pagty1A2S5LJx)
			title = KpCfd8EGrwhkic2n571H3aDPozUtvL[SIkwCEdJHTD9v1(u"ࠬࡺࡩࡵ࡮ࡨࠫു")].replace(YQNd4wejLSAVJ6T(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨൂ"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧ࡮ࡲࡧࠤࠥ࠭ൃ"))
			title = title.replace(KpCfd8EGrwhkic2n571H3aDPozUtvL[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪൄ")]+LvzD9S8RPyGeukZQqb2T0B,sCHVtMAvqirbQ4BUK3cgWo)
			title = title.replace(IWetJVFc0DLGlkOmE3CQsN+TzIj50KpohEOHx6CbZWqB(u"ࠩ࡮ࡦࡵࡹࠧ൅"),str(qlu4QIrH7GwzJ5LTn8jKA)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪ࡯ࡧࡶࡳࠨെ"))
			title = title+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࠭࠭േ")+EEIv0FOyotfY7UDjhs[XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡺࡩࡵ࡮ࡨࠫൈ")].split(BWfpRku7SsM6cbE0eG(u"࠭ࠨࠨ൉"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			zhi6So8CxtLT.append([KpCfd8EGrwhkic2n571H3aDPozUtvL,EEIv0FOyotfY7UDjhs,title,qlu4QIrH7GwzJ5LTn8jKA])
	W3MR1OLTGDxIqZApenrC5zk = []
	for stream in zhi6So8CxtLT:
		KpCfd8EGrwhkic2n571H3aDPozUtvL,EEIv0FOyotfY7UDjhs,title,qlu4QIrH7GwzJ5LTn8jKA = stream
		gZYmIQjku63s4txUAecER = title[:vUnJhT2NO8yirHcAmg]
		if bGzRdmOErkIylxALniq6(u"ࠧัๅํอࠬൊ") in title: gZYmIQjku63s4txUAecER += Js61GTdX5wzMurUqi7Z(u"ࠨ࠭ࠪോ")
		W3MR1OLTGDxIqZApenrC5zk.append([stream,gZYmIQjku63s4txUAecER,int(qlu4QIrH7GwzJ5LTn8jKA)])
	CC9XfIcJpTO = lvzrYTpcBaK
	MHud0pzYQ1B52LerJAKOEIo = ju4rw9S8bBylgdK1AOoIh5Dvzf(Ll1m0nJoaAPvHsXqyRE,W3MR1OLTGDxIqZApenrC5zk)
	if MHud0pzYQ1B52LerJAKOEIo:
		EBkcWIwKCApjJU1ybZTO27eLg5,EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj,title,qlu4QIrH7GwzJ5LTn8jKA = MHud0pzYQ1B52LerJAKOEIo[BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh]
		Yf6BpWXurQLMyVwsF0gj4d3Hm = EBkcWIwKCApjJU1ybZTO27eLg5[Js61GTdX5wzMurUqi7Z(u"ࠩࡸࡶࡱ࠭ൌ")]
		if gDETKVh8mZe09Nd(u"ࠪࡱࡵࡪ്ࠧ") in title and Yf6BpWXurQLMyVwsF0gj4d3Hm!=wSRsL5uY93n6Cx08tPTGMNAVq4: CC9XfIcJpTO = ndkUxG9LtewJ
		jaDlZyYguW10CvG6 = title
	else:
		d4xV85PtbL6UBNm7yEwgZSFk1l = ju4rw9S8bBylgdK1AOoIh5Dvzf(Ll1m0nJoaAPvHsXqyRE,W3MR1OLTGDxIqZApenrC5zk,IOHSz7YPF9WusGgUt1Dq(u"࠵࠺࠶࠰ໝ"))
		d4xV85PtbL6UBNm7yEwgZSFk1l,sfyLahiENMJ6nd5Hxpc4lYwS0m2,OEJViylR8QT941jLG = zip(*d4xV85PtbL6UBNm7yEwgZSFk1l)
		FFOye3tYUIb6mC2Q1JlV,ac8T1lMdGmYOb,YLPN3aMnlwrQHudjqSc = [],[],BewrUo9ANCa17G43Sn0LH5xh
		zhi6So8CxtLT = sorted(zhi6So8CxtLT, reverse=ndkUxG9LtewJ, key=lambda key: float(key[vUnJhT2NO8yirHcAmg]))
		Zaw0JbCPGm12Mtej96dvTI,XXeLBHsE8xic49oVdbrSj,xmBdTMOp9wy6bisSh = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
		try: Zaw0JbCPGm12Mtej96dvTI = DJ1elACSdx0LbI73yrG9ajZWg2VtX[GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪൎ")][aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡧࡵࡵࡪࡲࡶࠬ൏")]
		except:
			try: Zaw0JbCPGm12Mtej96dvTI = C47CGwcnzF6[Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ൐")][RDwahqjPfbdyEiTtnLQu(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧ൑")]
			except: pass
		try: XXeLBHsE8xic49oVdbrSj = DJ1elACSdx0LbI73yrG9ajZWg2VtX[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ൒")][YQNd4wejLSAVJ6T(u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ൓")]
		except:
			try: XXeLBHsE8xic49oVdbrSj = C47CGwcnzF6[TzIj50KpohEOHx6CbZWqB(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩൔ")][fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧൕ")]
			except: pass
		if Zaw0JbCPGm12Mtej96dvTI and XXeLBHsE8xic49oVdbrSj:
			YLPN3aMnlwrQHudjqSc += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			title = VXWOCAE6ns3paJ8DLG479NQfMu+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡕࡗࡏࡇࡕ࠾ࠥࠦࠧൖ")+Zaw0JbCPGm12Mtej96dvTI+B8alA5nvIhTxQ
			B17r2fdFy9ns8tiOMLu = Q1siCkTZyw.SITESURLS[IOHSz7YPF9WusGgUt1Dq(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧൗ")][BewrUo9ANCa17G43Sn0LH5xh]+YQNd4wejLSAVJ6T(u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ൘")+XXeLBHsE8xic49oVdbrSj
			FFOye3tYUIb6mC2Q1JlV.append(title)
			ac8T1lMdGmYOb.append(B17r2fdFy9ns8tiOMLu)
			try: xmBdTMOp9wy6bisSh = DJ1elACSdx0LbI73yrG9ajZWg2VtX[bGzRdmOErkIylxALniq6(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ൙")][IOHSz7YPF9WusGgUt1Dq(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ൚")][jwzOabysh0Z(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ൛")][-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU][wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡺࡸ࡬ࠨ൜")]
			except:
				try: xmBdTMOp9wy6bisSh = C47CGwcnzF6[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ൝")][gDETKVh8mZe09Nd(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ൞")][Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫൟ")][-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU][GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡷࡵࡰࠬൠ")]
				except: pass
		for KpCfd8EGrwhkic2n571H3aDPozUtvL,EEIv0FOyotfY7UDjhs,title,qlu4QIrH7GwzJ5LTn8jKA in d4xV85PtbL6UBNm7yEwgZSFk1l:
			FFOye3tYUIb6mC2Q1JlV.append(title) ; ac8T1lMdGmYOb.append(SE97R3Dpj6dPLweVKU(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪൡ"))
		if NrKkUPaJ41qCO2jypBRl: FFOye3tYUIb6mC2Q1JlV.append(EJgYdjbIiWe1apkQlZcR42(u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬൢ")) ; ac8T1lMdGmYOb.append(GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡲࡻࡸࡦࡦࠪൣ"))
		if zhi6So8CxtLT: FFOye3tYUIb6mC2Q1JlV.append(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ൤")) ; ac8T1lMdGmYOb.append(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡡ࡭࡮ࠪ൥"))
		if yxzhsqHpbIDVBT7ENAdl0OrawL: FFOye3tYUIb6mC2Q1JlV.append(aYH620Dh48GEsTFfOBSQ7r(u"ࠧศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬ൦")) ; ac8T1lMdGmYOb.append(aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࡯ࡳࡨࠬ൧"))
		if cfIloQAC52Yk6wgGnPNZ: FFOye3tYUIb6mC2Q1JlV.append(TzIj50KpohEOHx6CbZWqB(u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ൨")) ; ac8T1lMdGmYOb.append(Js61GTdX5wzMurUqi7Z(u"ࠪࡺ࡮ࡪࡥࡰࠩ൩"))
		if RSHE5Qpoe4c2ki: FFOye3tYUIb6mC2Q1JlV.append(qeG16a4pbSHziNVQ2uFXrs(u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ൪")) ; ac8T1lMdGmYOb.append(oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡧࡵࡥ࡫ࡲࠫ൫"))
		while ndkUxG9LtewJ:
			jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(i3ithFKTgz,FFOye3tYUIb6mC2Q1JlV)
			if jQLzA92KFEcpw==-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return aYH620Dh48GEsTFfOBSQ7r(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ൬"),[],[]
			elif jQLzA92KFEcpw==BewrUo9ANCa17G43Sn0LH5xh and Zaw0JbCPGm12Mtej96dvTI:
				B17r2fdFy9ns8tiOMLu = ac8T1lMdGmYOb[jQLzA92KFEcpw]
				p71LjtPSvMAnW = xlOFiKpdTI1Vjw5YN.argv[BewrUo9ANCa17G43Sn0LH5xh]+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ൭")+IgCGzHw45TJ7PeuO1EKl(Zaw0JbCPGm12Mtej96dvTI)+bGzRdmOErkIylxALniq6(u"ࠨࠨࡸࡶࡱࡃࠧ൮")+B17r2fdFy9ns8tiOMLu
				if xmBdTMOp9wy6bisSh: p71LjtPSvMAnW = p71LjtPSvMAnW+fvYGxnZNUiyP4HJkMIoS25(u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ൯")+IgCGzHw45TJ7PeuO1EKl(xmBdTMOp9wy6bisSh)
				FoiwfTEhGD8ulS25HeUvnI.executebuiltin(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ൰")+p71LjtPSvMAnW+jwzOabysh0Z(u"ࠦ࠮ࠨ൱"))
				return RDwahqjPfbdyEiTtnLQu(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ൲"),[],[]
			KTxQcnwvOF0pqt = ac8T1lMdGmYOb[jQLzA92KFEcpw]
			jaDlZyYguW10CvG6 = FFOye3tYUIb6mC2Q1JlV[jQLzA92KFEcpw]
			if KTxQcnwvOF0pqt==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭ࡤࡢࡵ࡫ࠫ൳"):
				Yf6BpWXurQLMyVwsF0gj4d3Hm = wSRsL5uY93n6Cx08tPTGMNAVq4
				break
			elif KTxQcnwvOF0pqt in [BWfpRku7SsM6cbE0eG(u"ࠧࡢࡷࡧ࡭ࡴ࠭൴"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡸ࡬ࡨࡪࡵࠧ൵"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡰࡹࡽ࡫ࡤࠨ൶")]:
				if KTxQcnwvOF0pqt==XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡱࡺࡾࡥࡥࠩ൷"): V9TdsglcWYv0X,G5mP2ugdOCfWX3LBqYMUna = NrKkUPaJ41qCO2jypBRl,yhpBLDoPTfsde6Gvg2Ha
				elif KTxQcnwvOF0pqt==RDwahqjPfbdyEiTtnLQu(u"ࠫࡻ࡯ࡤࡦࡱࠪ൸"): V9TdsglcWYv0X,G5mP2ugdOCfWX3LBqYMUna = cfIloQAC52Yk6wgGnPNZ,w65wP4VkmvNIlcUeuY
				elif KTxQcnwvOF0pqt==aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡧࡵࡥ࡫ࡲࠫ൹"): V9TdsglcWYv0X,G5mP2ugdOCfWX3LBqYMUna = RSHE5Qpoe4c2ki,pmg89l7PQJRIa
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬൺ")+str(len(V9TdsglcWYv0X))+oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࠡ็็ๅ࠮࠭ൻ"),V9TdsglcWYv0X)
				if jQLzA92KFEcpw!=-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
					Yf6BpWXurQLMyVwsF0gj4d3Hm = G5mP2ugdOCfWX3LBqYMUna[jQLzA92KFEcpw][YQNd4wejLSAVJ6T(u"ࠨࡷࡵࡰࠬർ")]
					jaDlZyYguW10CvG6 = V9TdsglcWYv0X[jQLzA92KFEcpw]
					break
			elif KTxQcnwvOF0pqt==SIkwCEdJHTD9v1(u"ࠩࡰࡴࡩ࠭ൽ"):
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(aYH620Dh48GEsTFfOBSQ7r(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࠦࠨࠨൾ")+str(len(yxzhsqHpbIDVBT7ENAdl0OrawL))+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"๋ࠫࠥไโࠫࠪൿ"),yxzhsqHpbIDVBT7ENAdl0OrawL)
				if jQLzA92KFEcpw!=-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
					jaDlZyYguW10CvG6 = yxzhsqHpbIDVBT7ENAdl0OrawL[jQLzA92KFEcpw]
					EBkcWIwKCApjJU1ybZTO27eLg5 = ddtklBKAvZIzTVig30OUocEG6Xf[jQLzA92KFEcpw]
					jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(EJgYdjbIiWe1apkQlZcR42(u"ࠬอฮหำࠣะํีษࠡษ็ูํะࠠࠩࠩ඀")+str(len(MgFk13BDAoxrvuIlp))+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠠๆๆไ࠭ࠬඁ"),MgFk13BDAoxrvuIlp)
					if jQLzA92KFEcpw!=-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
						jaDlZyYguW10CvG6 += EJgYdjbIiWe1apkQlZcR42(u"ࠧࠡ࠭ࠣࠫං")+MgFk13BDAoxrvuIlp[jQLzA92KFEcpw]
						EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj = yJrYRMbFPjW9o4aNxl3ncsekhf[jQLzA92KFEcpw]
						CC9XfIcJpTO = ndkUxG9LtewJ
						break
			elif KTxQcnwvOF0pqt==GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡣ࡯ࡰࠬඃ"):
				FE5dOgiwGJ,TTYFv6UrbSmAHIWCPZo9icyBKE1fz,xouY0SplbEOrie8ULvI,ZUH7nxVSd8D = list(zip(*zhi6So8CxtLT))
				jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c(GVurlv8HeoXEzPRiQB7Ty(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨ඄")+str(len(xouY0SplbEOrie8ULvI))+zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࠤ๊๊แࠪࠩඅ"),xouY0SplbEOrie8ULvI)
				if jQLzA92KFEcpw!=-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
					jaDlZyYguW10CvG6 = xouY0SplbEOrie8ULvI[jQLzA92KFEcpw]
					EBkcWIwKCApjJU1ybZTO27eLg5 = FE5dOgiwGJ[jQLzA92KFEcpw]
					if zLjWeKu6JgNO7vocUD0Qpy(u"ࠫࡲࡶࡤࠨආ") in xouY0SplbEOrie8ULvI[jQLzA92KFEcpw] and EBkcWIwKCApjJU1ybZTO27eLg5[gDETKVh8mZe09Nd(u"ࠬࡻࡲ࡭ࠩඇ")]!=wSRsL5uY93n6Cx08tPTGMNAVq4:
						EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj = TTYFv6UrbSmAHIWCPZo9icyBKE1fz[jQLzA92KFEcpw]
						CC9XfIcJpTO = ndkUxG9LtewJ
					else: Yf6BpWXurQLMyVwsF0gj4d3Hm = EBkcWIwKCApjJU1ybZTO27eLg5[zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡵࡳ࡮ࠪඈ")]
					break
			elif KTxQcnwvOF0pqt==oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨඉ"):
				FE5dOgiwGJ,TTYFv6UrbSmAHIWCPZo9icyBKE1fz,xouY0SplbEOrie8ULvI,ZUH7nxVSd8D = list(zip(*d4xV85PtbL6UBNm7yEwgZSFk1l))
				EBkcWIwKCApjJU1ybZTO27eLg5 = FE5dOgiwGJ[jQLzA92KFEcpw-YLPN3aMnlwrQHudjqSc]
				if IO7k2hZXSz(u"ࠨ࡯ࡳࡨࠬඊ") in xouY0SplbEOrie8ULvI[jQLzA92KFEcpw-YLPN3aMnlwrQHudjqSc] and EBkcWIwKCApjJU1ybZTO27eLg5[t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡸࡶࡱ࠭උ")]!=wSRsL5uY93n6Cx08tPTGMNAVq4:
					EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj = TTYFv6UrbSmAHIWCPZo9icyBKE1fz[jQLzA92KFEcpw-YLPN3aMnlwrQHudjqSc]
					CC9XfIcJpTO = ndkUxG9LtewJ
				else: Yf6BpWXurQLMyVwsF0gj4d3Hm = EBkcWIwKCApjJU1ybZTO27eLg5[oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡹࡷࡲࠧඌ")]
				jaDlZyYguW10CvG6 = xouY0SplbEOrie8ULvI[jQLzA92KFEcpw-YLPN3aMnlwrQHudjqSc]
				break
	if CC9XfIcJpTO:
		MpeaJcKtEOow5APYuky = int(EBkcWIwKCApjJU1ybZTO27eLg5[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ඍ")])
		lpoMnDfTsLC2RArXG3NJZd = int(EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧඎ")])
		yAMScJ6z3E8 = str(max(MpeaJcKtEOow5APYuky,lpoMnDfTsLC2RArXG3NJZd))
		aaMsmzE6evBxU = EBkcWIwKCApjJU1ybZTO27eLg5[RDwahqjPfbdyEiTtnLQu(u"࠭ࡵࡳ࡮ࠪඏ")].replace(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠧࠩඐ"),hPFcB6Uxmabj59Iq(u"ࠨࠨࡤࡱࡵࡁࠧඑ"))
		flOGu0P79cJmXHUBiZYFN3EKMSrenW = EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[Js61GTdX5wzMurUqi7Z(u"ࠩࡸࡶࡱ࠭ඒ")].replace(gDETKVh8mZe09Nd(u"ࠪࠪࠬඓ"),EJgYdjbIiWe1apkQlZcR42(u"ࠫࠫࡧ࡭ࡱ࠽ࠪඔ"))
		mpd = oVwa0kcqxj1e7mLplAfZdGT(u"ࠬࡂࡍࡑࡆࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࠣࡱࡪࡪࡩࡢࡒࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࡄࡶࡴࡤࡸ࡮ࡵ࡮࠾ࠤࡓࡘࠬඕ")+yAMScJ6z3E8+zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡓࠣࡀ࡟ࡲࠬඖ")
		mpd += qeG16a4pbSHziNVQ2uFXrs(u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤࠡ࡫ࡧࡁࠧ࡜ࡩࡥࡧࡲ࠯ࡆࡻࡤࡪࡱࠥࡂࡡࡴࠧ඗")
		mpd += GVurlv8HeoXEzPRiQB7Ty(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬ඘")+EBkcWIwKCApjJU1ybZTO27eLg5[GVurlv8HeoXEzPRiQB7Ty(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ඙")]+RDwahqjPfbdyEiTtnLQu(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧක")+EBkcWIwKCApjJU1ybZTO27eLg5[fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡨࡵࡤࡦࡥࡶࠫඛ")]+IOHSz7YPF9WusGgUt1Dq(u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩග")
		mpd += XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧࡼࡩࡥࡧࡲ࠵ࠧࡄ࡜࡯ࠩඝ")
		mpd += t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪඞ")+aaMsmzE6evBxU+zLjWeKu6JgNO7vocUD0Qpy(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧඟ")
		mpd += t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧච")+EBkcWIwKCApjJU1ybZTO27eLg5[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠪ࡭ࡳࡪࡥࡹࠩඡ")]+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࠧࡄ࡜࡯ࠩජ")
		mpd += qqw1upCsKM(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨඣ")+EBkcWIwKCApjJU1ybZTO27eLg5[IO7k2hZXSz(u"࠭ࡩ࡯࡫ࡷࠫඤ")]+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧඥ")
		mpd += wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫඦ")
		mpd += phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨට")
		mpd += IOHSz7YPF9WusGgUt1Dq(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨඨ")
		mpd += YQNd4wejLSAVJ6T(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨඩ")+EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[fvYGxnZNUiyP4HJkMIoS25(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧඪ")]+YQNd4wejLSAVJ6T(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪණ")+EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[bGzRdmOErkIylxALniq6(u"ࠧࡤࡱࡧࡩࡨࡹࠧඬ")]+aYH620Dh48GEsTFfOBSQ7r(u"ࠨࠤࠣࡷࡹࡧࡲࡵ࡙࡬ࡸ࡭࡙ࡁࡑ࠿ࠥ࠵ࠧࠦࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬත")
		mpd += SIkwCEdJHTD9v1(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࡣࡸࡨ࡮ࡵ࠱ࠣࡀ࡟ࡲࠬථ")
		mpd += jwzOabysh0Z(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭ද")+flOGu0P79cJmXHUBiZYFN3EKMSrenW+SE97R3Dpj6dPLweVKU(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪධ")
		mpd += SIkwCEdJHTD9v1(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪන")+EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[jwzOabysh0Z(u"࠭ࡩ࡯ࡦࡨࡼࠬ඲")]+qeG16a4pbSHziNVQ2uFXrs(u"ࠧࠣࡀ࡟ࡲࠬඳ")
		mpd += sH6BOz5wKRFcEg(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫප")+EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[IO7k2hZXSz(u"ࠩ࡬ࡲ࡮ࡺࠧඵ")]+SIkwCEdJHTD9v1(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪබ")
		mpd += fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧභ")
		mpd += SIkwCEdJHTD9v1(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫම")
		mpd += phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫඹ")
		mpd += t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬය")
		mpd += qqw1upCsKM(u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪර")
		if I5VKjrFL0Bk97:
			import http.server as iAZodSLc0GlhFWeY1juqaM9s
			import http.client as CQLt3nI5qsWEDpPrT1vkVfia6Sj
		else:
			import BaseHTTPServer as iAZodSLc0GlhFWeY1juqaM9s
			import httplib as CQLt3nI5qsWEDpPrT1vkVfia6Sj
		class MJZvPdN23jRAtl1WLw(iAZodSLc0GlhFWeY1juqaM9s.HTTPServer):
			def __init__(RJa8ne9fq3YXGDQcioTZu5srmkKd,ip=aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ඼"),port=sH6BOz5wKRFcEg(u"࠺࠻࠰࠶࠷ໞ"),mpd=IOHSz7YPF9WusGgUt1Dq(u"ࠪࡀࡃ࠭ල")):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.ip = ip
				RJa8ne9fq3YXGDQcioTZu5srmkKd.port = port
				RJa8ne9fq3YXGDQcioTZu5srmkKd.mpd = mpd
				iAZodSLc0GlhFWeY1juqaM9s.HTTPServer.__init__(RJa8ne9fq3YXGDQcioTZu5srmkKd,(RJa8ne9fq3YXGDQcioTZu5srmkKd.ip,RJa8ne9fq3YXGDQcioTZu5srmkKd.port),xlkiSB9zgrjAsU43pMCN1ahdJ)
				RJa8ne9fq3YXGDQcioTZu5srmkKd.mpdurl = aYH620Dh48GEsTFfOBSQ7r(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ඾")+ip+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡀࠧ඿")+str(port)+IO7k2hZXSz(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬව")
			def start(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.threads = kGX9IF07jirosWYaf3c(lvzrYTpcBaK)
				RJa8ne9fq3YXGDQcioTZu5srmkKd.threads.pQfd3FT4Jz7G(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,RJa8ne9fq3YXGDQcioTZu5srmkKd.fBgtmDEJoFGYL63br1c)
			def fBgtmDEJoFGYL63br1c(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.keeprunning = ndkUxG9LtewJ
				while RJa8ne9fq3YXGDQcioTZu5srmkKd.keeprunning:
					RJa8ne9fq3YXGDQcioTZu5srmkKd.handle_request()
			def stop(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.keeprunning = lvzrYTpcBaK
				RJa8ne9fq3YXGDQcioTZu5srmkKd.ZYsXt6aFm5C9czrNbPB()
			def ZVgyroFTiPWI17bCavEM(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.stop()
				RJa8ne9fq3YXGDQcioTZu5srmkKd.j1W9U4Ekxs0cYo7Aw2fzdyVgnb6.close()
				RJa8ne9fq3YXGDQcioTZu5srmkKd.server_close()
			def vdyGsZapImKn2WFxYf(RJa8ne9fq3YXGDQcioTZu5srmkKd,mpd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.mpd = mpd
			def ZYsXt6aFm5C9czrNbPB(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				lxGwZhDLdoySA1avUN5 = CQLt3nI5qsWEDpPrT1vkVfia6Sj.HTTPConnection(RJa8ne9fq3YXGDQcioTZu5srmkKd.ip+YQNd4wejLSAVJ6T(u"ࠧ࠻ࠩශ")+str(RJa8ne9fq3YXGDQcioTZu5srmkKd.port))
				lxGwZhDLdoySA1avUN5.request(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠣࡊࡈࡅࡉࠨෂ"), sH6BOz5wKRFcEg(u"ࠤ࠲ࠦස"))
		class xlkiSB9zgrjAsU43pMCN1ahdJ(iAZodSLc0GlhFWeY1juqaM9s.BaseHTTPRequestHandler):
			def h6Ej80KUZvuSnILyVs(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.send_response(jwzOabysh0Z(u"࠸࠰࠱ໟ"))
				RJa8ne9fq3YXGDQcioTZu5srmkKd.send_header(jwzOabysh0Z(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩහ"),BWfpRku7SsM6cbE0eG(u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨළ"))
				RJa8ne9fq3YXGDQcioTZu5srmkKd.end_headers()
				RJa8ne9fq3YXGDQcioTZu5srmkKd.wfile.write(RJa8ne9fq3YXGDQcioTZu5srmkKd.smh8Qbf9jH.mpd.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT))
				hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
				if RJa8ne9fq3YXGDQcioTZu5srmkKd.path==t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫෆ"): RJa8ne9fq3YXGDQcioTZu5srmkKd.smh8Qbf9jH.ZVgyroFTiPWI17bCavEM()
				if RJa8ne9fq3YXGDQcioTZu5srmkKd.path==fvYGxnZNUiyP4HJkMIoS25(u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ෇"): RJa8ne9fq3YXGDQcioTZu5srmkKd.smh8Qbf9jH.ZVgyroFTiPWI17bCavEM()
			def ISe6HPqy4VX(RJa8ne9fq3YXGDQcioTZu5srmkKd):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.send_response(bGzRdmOErkIylxALniq6(u"࠲࠱࠲໠"))
				RJa8ne9fq3YXGDQcioTZu5srmkKd.end_headers()
		yBXqH1SW6M0gsfKAdc8GDrFUmo = MJZvPdN23jRAtl1WLw(jwzOabysh0Z(u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪ෈"),fvYGxnZNUiyP4HJkMIoS25(u"࠶࠷࠳࠹࠺໡"),mpd)
		Yf6BpWXurQLMyVwsF0gj4d3Hm = yBXqH1SW6M0gsfKAdc8GDrFUmo.mpdurl
		yBXqH1SW6M0gsfKAdc8GDrFUmo.start()
	else: yBXqH1SW6M0gsfKAdc8GDrFUmo = sCHVtMAvqirbQ4BUK3cgWo
	if I5VKjrFL0Bk97: rOXf2I5ndGkL7ZMQ1j3ANBwFRDKb6,eZMYb278t6ULVR1gyWrEAC0aquho = sCHVtMAvqirbQ4BUK3cgWo,jwzOabysh0Z(u"ࠨ࡞ࡷࠫ෉")
	else: rOXf2I5ndGkL7ZMQ1j3ANBwFRDKb6,eZMYb278t6ULVR1gyWrEAC0aquho = aenpKvQCGVzhLXEdWiDIZ(u"ࠩ࡟ࡸ්ࠬ"),sCHVtMAvqirbQ4BUK3cgWo
	svUiJXDfol0WVaM54NuSqbxIRBencT = rOXf2I5ndGkL7ZMQ1j3ANBwFRDKb6+SE97R3Dpj6dPLweVKU(u"ࠪࡅࡺࡪࡩࡰ࠼ࠣ࡟ࠥ࠭෋")+EGwc7zKU1bxfPsNt0L8i6vB9gWdqOj[SIkwCEdJHTD9v1(u"ࠫࡺࡸ࡬ࠨ෌")]+aenpKvQCGVzhLXEdWiDIZ(u"ࠬࠦ࡝࡝ࡰ࡟ࡸࡡࡺࠧ෍")+eZMYb278t6ULVR1gyWrEAC0aquho+aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ෎")+EBkcWIwKCApjJU1ybZTO27eLg5[aenpKvQCGVzhLXEdWiDIZ(u"ࠧࡶࡴ࡯ࠫා")]+EJgYdjbIiWe1apkQlZcR42(u"ࠨࠢࡠࠫැ") if CC9XfIcJpTO else rOXf2I5ndGkL7ZMQ1j3ANBwFRDKb6+zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡄ࠯࡛ࡀࠠ࡜ࠢࠪෑ")+Yf6BpWXurQLMyVwsF0gj4d3Hm+gDETKVh8mZe09Nd(u"ࠪࠤࡢ࠭ි")
	SH6EVn0T9d8bKCUMLl1sJOFR(CRxa3v2o1wMXzZLu8FDinm6gsr,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠫࡡࡺࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡶࡵࡩࡦࡳ࠺ࠡ࡝ࠣࠫී")+jaDlZyYguW10CvG6+aenpKvQCGVzhLXEdWiDIZ(u"ࠬࠦ࡝ࠡࠢࠣࠫු")+svUiJXDfol0WVaM54NuSqbxIRBencT)
	if not Yf6BpWXurQLMyVwsF0gj4d3Hm: return SE97R3Dpj6dPLweVKU(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭෕"),[],[]
	return sCHVtMAvqirbQ4BUK3cgWo,[jaDlZyYguW10CvG6],[[Yf6BpWXurQLMyVwsF0gj4d3Hm,FFlXsxdANwVr4,yBXqH1SW6M0gsfKAdc8GDrFUmo]]
def IH8J1pOMvqaFA7L(url):
	headers = { hPFcB6Uxmabj59Iq(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫූ") : sCHVtMAvqirbQ4BUK3cgWo }
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,SIkwCEdJHTD9v1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨ෗"))
	items = fNntYJW45mEFSdRX8g.findall(qqw1upCsKM(u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭ෘ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	items = set(items)
	items = sorted(items, reverse=ndkUxG9LtewJ, key=lambda key: key[rgpY5VUqKbeFOCD9Nki2SmGvxEja])
	FLVObYDAIwx1,V9TdsglcWYv0X,ZNnRHC1ldwyafz9JvSB7oFTcrAmq,ss7YGDbuAIxgnqaQroTV = [],[],[],[]
	if not items: return qqw1upCsKM(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡄࡒࡆࠬෙ"),[],[]
	for B17r2fdFy9ns8tiOMLu,qLbRrEtgenpSi,c4yVMkzYb0 in items:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫේ"),sH6BOz5wKRFcEg(u"ࠬ࡮ࡴࡵࡲ࠽ࠫෛ"))
		if hPFcB6Uxmabj59Iq(u"࠭࠮࡮࠵ࡸ࠼ࠬො") in B17r2fdFy9ns8tiOMLu:
			FLVObYDAIwx1,ZNnRHC1ldwyafz9JvSB7oFTcrAmq = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,B17r2fdFy9ns8tiOMLu)
			ss7YGDbuAIxgnqaQroTV = ss7YGDbuAIxgnqaQroTV + ZNnRHC1ldwyafz9JvSB7oFTcrAmq
			if FLVObYDAIwx1[BewrUo9ANCa17G43Sn0LH5xh]==RDwahqjPfbdyEiTtnLQu(u"ࠧ࠮࠳ࠪෝ"): V9TdsglcWYv0X.append(GVurlv8HeoXEzPRiQB7Ty(u"ࠨีํีๆืࠠฯษุࠫෞ")+Js61GTdX5wzMurUqi7Z(u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪෟ"))
			else:
				for title in FLVObYDAIwx1:
					V9TdsglcWYv0X.append(EJgYdjbIiWe1apkQlZcR42(u"ࠪื๏ืแาࠢัหฺ࠭෠")+OUmtsIB1zyF+title)
		else:
			title = aYH620Dh48GEsTFfOBSQ7r(u"ุࠫ๐ัโำࠣาฬ฻ࠧ෡")+YQNd4wejLSAVJ6T(u"ࠬࠦࠠࠡ࡯ࡳ࠸ࠥࠦࠠࠨ෢")+c4yVMkzYb0
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
			V9TdsglcWYv0X.append(title)
	return sCHVtMAvqirbQ4BUK3cgWo,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
def zpBKltk4s6FE1q9O(url,Sw0pOFoVhPeIxbl):
	tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p,flhEbDnAeVC4JF7YMKcGPxBTU,sTnCDNGi3hy0W78,PXFtqmw5lBGQNa0IV8 = [],[],[],[],[]
	if not isinstance(Sw0pOFoVhPeIxbl,str): Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,bGzRdmOErkIylxALniq6(u"࠭ࡩࡨࡰࡲࡶࡪ࠭෣"))
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ෤"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu and not FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]): B17r2fdFy9ns8tiOMLu = []
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෥"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu and not FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]): B17r2fdFy9ns8tiOMLu = []
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall(oVwa0kcqxj1e7mLplAfZdGT(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ෦"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu and not FA0Y1k9va5O2zmU6By(B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]): B17r2fdFy9ns8tiOMLu = []
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[BewrUo9ANCa17G43Sn0LH5xh]
		title = B17r2fdFy9ns8tiOMLu.rsplit(Js61GTdX5wzMurUqi7Z(u"ࠪ࠲ࠬ෧"),aYH620Dh48GEsTFfOBSQ7r(u"࠳໢"))[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
		tryU7sQv0e91cVL3h2xKRpqHdm6.append(title)
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	else:
		Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦࠪࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠪ෨"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not Jae64ky3REO57A2MvVHB90: Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡼࡡࡳࠢࡶࡳࡺࡸࡣࡦࡵࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨ෩"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not Jae64ky3REO57A2MvVHB90: Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡶࡢࡴࠣ࡮ࡼࠦ࠽ࠡࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࠫ෪"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not Jae64ky3REO57A2MvVHB90: Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall(E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧࡷࡣࡵࠤࡵࡲࡡࡺࡧࡵࠤࡂࠦ࠮ࠫࡁ࡟ࠬ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯࡜ࠪࠩ෫"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if Jae64ky3REO57A2MvVHB90:
			Jae64ky3REO57A2MvVHB90 = Jae64ky3REO57A2MvVHB90[BewrUo9ANCa17G43Sn0LH5xh]
			Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.sub(BWfpRku7SsM6cbE0eG(u"ࡳࠩࠫ࡟ࡡࢁ࡜࠭࡟࡞ࡠࡹࡢࡳ࡝ࡰ࡟ࡶࡢ࠰ࠩࠩ࡞ࡺ࠯ࡠࡢࡴ࡝ࡵࡠ࠮࠮ࡀࠧ෬"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࡴࠪࡠ࠶ࠨ࡜࠳ࠤ࠽ࠫ෭"),Jae64ky3REO57A2MvVHB90)
			Jae64ky3REO57A2MvVHB90 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX(zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡨ࡮ࡩࡴࠨ෮"),Jae64ky3REO57A2MvVHB90)
			if isinstance(Jae64ky3REO57A2MvVHB90,dict): Jae64ky3REO57A2MvVHB90 = [Jae64ky3REO57A2MvVHB90]
			for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
				oERHNrY5aIJ9CtSxnTkmds84DO,B17r2fdFy9ns8tiOMLu = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
				if isinstance(Po9h3gWFuLR2,dict):
					keys = list(Po9h3gWFuLR2.keys())
					if   SIkwCEdJHTD9v1(u"ࠫࡹࡿࡰࡦࠩ෯") in keys: oERHNrY5aIJ9CtSxnTkmds84DO = str(Po9h3gWFuLR2[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡺࡹࡱࡧࠪ෰")])
					if   SIkwCEdJHTD9v1(u"࠭ࡦࡪ࡮ࡨࠫ෱") in keys: B17r2fdFy9ns8tiOMLu = Po9h3gWFuLR2[bGzRdmOErkIylxALniq6(u"ࠧࡧ࡫࡯ࡩࠬෲ")]
					elif Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡪ࡯ࡷࠬෳ") in keys: B17r2fdFy9ns8tiOMLu = Po9h3gWFuLR2[E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩ࡫ࡰࡸ࠭෴")]
					elif YQNd4wejLSAVJ6T(u"ࠪࡷࡷࡩࠧ෵") in keys: B17r2fdFy9ns8tiOMLu = Po9h3gWFuLR2[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫࡸࡸࡣࠨ෶")]
					if   EJgYdjbIiWe1apkQlZcR42(u"ࠬࡲࡡࡣࡧ࡯ࠫ෷") in keys: title = str(Po9h3gWFuLR2[YQNd4wejLSAVJ6T(u"࠭࡬ࡢࡤࡨࡰࠬ෸")])
					elif wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭෹") in keys: title = str(Po9h3gWFuLR2[RDwahqjPfbdyEiTtnLQu(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡩࡧ࡬࡫࡭ࡺࠧ෺")])
					elif IO7k2hZXSz(u"ࠩ࠱ࠫ෻") in B17r2fdFy9ns8tiOMLu: title = B17r2fdFy9ns8tiOMLu.rsplit(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪ࠲ࠬ෼"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
					else: title = B17r2fdFy9ns8tiOMLu
				elif isinstance(Po9h3gWFuLR2,str):
					B17r2fdFy9ns8tiOMLu = Po9h3gWFuLR2
					title = B17r2fdFy9ns8tiOMLu.rsplit(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࠳࠭෽"),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
					tryU7sQv0e91cVL3h2xKRpqHdm6.append(title+LvzD9S8RPyGeukZQqb2T0B+oERHNrY5aIJ9CtSxnTkmds84DO)
					cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	for B17r2fdFy9ns8tiOMLu,title in list(zip(cb1fAztguv78n9LGhSWJFm5p,tryU7sQv0e91cVL3h2xKRpqHdm6)):
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡢ࡜࠰ࠩ෾"),SE97R3Dpj6dPLweVKU(u"࠭࠯ࠨ෿"))
		smh8Qbf9jH = GABnmSFOwtsu37(url,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡶࡴ࡯ࠫ฀"))
		MMKTiky7N3vVPdx6GIzHFOf2Yjq = OOsacGDt4owXd52q7gC8l()
		if gDETKVh8mZe09Nd(u"ࠨࡪࡷࡸࡵ࠭ก") not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = smh8Qbf9jH+B17r2fdFy9ns8tiOMLu
		if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨข") in B17r2fdFy9ns8tiOMLu:
			headers = {aYH620Dh48GEsTFfOBSQ7r(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧฃ"):MMKTiky7N3vVPdx6GIzHFOf2Yjq,iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬค"):smh8Qbf9jH}
			LthCg86KXRd7QSY5zo4MvUqOi0sc,ttiruedcm9 = KyzU5RhvoJMQwd8j3asD(Ll1m0nJoaAPvHsXqyRE,B17r2fdFy9ns8tiOMLu,headers)
			sTnCDNGi3hy0W78 += ttiruedcm9
			flhEbDnAeVC4JF7YMKcGPxBTU += LthCg86KXRd7QSY5zo4MvUqOi0sc
		else:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+gDETKVh8mZe09Nd(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫฅ")+MMKTiky7N3vVPdx6GIzHFOf2Yjq+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩฆ")+smh8Qbf9jH
			sTnCDNGi3hy0W78.append(B17r2fdFy9ns8tiOMLu)
			flhEbDnAeVC4JF7YMKcGPxBTU.append(title)
	JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = sCHVtMAvqirbQ4BUK3cgWo,[],[]
	if sTnCDNGi3hy0W78: JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p = sCHVtMAvqirbQ4BUK3cgWo,flhEbDnAeVC4JF7YMKcGPxBTU,sTnCDNGi3hy0W78
	else:
		if t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧ࠽ࠩง") not in Sw0pOFoVhPeIxbl and len(Sw0pOFoVhPeIxbl)<GVurlv8HeoXEzPRiQB7Ty(u"࠴࠴࠵໣") and Sw0pOFoVhPeIxbl: JbShzsakZ5M1i = Sw0pOFoVhPeIxbl
		else:
			msg = fNntYJW45mEFSdRX8g.findall(SIkwCEdJHTD9v1(u"ࠨ࠾ࡧ࡭ࡻࠦࡳࡵࡻ࡯ࡩࡂࠨ࠮ࠫࡁࠥࡂ࠭ࡌࡩ࡭ࡧ࠱࠮ࡄ࠯࠼ࠨจ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if not msg: msg = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡷࡲࡢࡺ࡮ࡪࡥࡰࡡࡶࡸࡺࡨ࡟ࡵࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬฉ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if not msg: msg = fNntYJW45mEFSdRX8g.findall(YQNd4wejLSAVJ6T(u"ࠪࡀ࡭࠸࠾ࠩࡕࡲࡶࡷࡿ࠮ࠫࡁࠬࡀࠬช"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if msg: JbShzsakZ5M1i = msg[BewrUo9ANCa17G43Sn0LH5xh]
	return JbShzsakZ5M1i,tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p
def WWTX7BCkt4aygo(Gj9Uz05RebqClhLdX7xMkma4FpoJDW,url):
	global cvV7Kb49CqRoz68yN1fU
	url = url.strip(SE97R3Dpj6dPLweVKU(u"ࠫ࠴࠭ซ"))
	Pgj5yWUqHhn,rnCzKJiBSsgGhj = sCHVtMAvqirbQ4BUK3cgWo,{}
	headers = {qeG16a4pbSHziNVQ2uFXrs(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩฌ"):OOsacGDt4owXd52q7gC8l()}
	headers[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧญ")] = GABnmSFOwtsu37(url,bGzRdmOErkIylxALniq6(u"ࠧࡶࡴ࡯ࠫฎ"))
	headers[iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪฏ")] = qeG16a4pbSHziNVQ2uFXrs(u"ࠩࡨࡲ࠱ࡧࡲ࠼ࡳࡀ࠴࠳࠿ࠧฐ")
	headers[YQNd4wejLSAVJ6T(u"ࠪࡗࡪࡩ࠭ࡇࡧࡷࡧ࡭࠳ࡄࡦࡵࡷࠫฑ")] = oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫฒ")
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡍࡅࡕࠩณ"),url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨด"))
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Ayi1QRLxgN4EpXUGb8hueqOHF = UHqibFEGL8fjKhI.code
	if not isinstance(Sw0pOFoVhPeIxbl,str): Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,bGzRdmOErkIylxALniq6(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧต"))
	if IO7k2hZXSz(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࠧถ") in Sw0pOFoVhPeIxbl:
		A1kThCgL4f = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭࡝ࡧࡶࡢ࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬท"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if A1kThCgL4f:
			try: Pgj5yWUqHhn = wpsnGYEcj5dqy6rOSDFkHJzf(A1kThCgL4f[BewrUo9ANCa17G43Sn0LH5xh])
			except: Pgj5yWUqHhn = sCHVtMAvqirbQ4BUK3cgWo
	if phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴࠬࠫธ") in Sw0pOFoVhPeIxbl:
		A1kThCgL4f = fNntYJW45mEFSdRX8g.findall(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫน"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if A1kThCgL4f:
			try: Pgj5yWUqHhn = IY54gnc6DzOS(A1kThCgL4f[BewrUo9ANCa17G43Sn0LH5xh])
			except: Pgj5yWUqHhn = sCHVtMAvqirbQ4BUK3cgWo
	ssUAzo3RibtgDv7O0x = Sw0pOFoVhPeIxbl+Pgj5yWUqHhn
	if SIkwCEdJHTD9v1(u"ࠬࠨࡩࡥ࠴ࠥࠫบ") in ssUAzo3RibtgDv7O0x or qeG16a4pbSHziNVQ2uFXrs(u"࠭ࠢࡪࡦࠥࠫป") in ssUAzo3RibtgDv7O0x:
		MNZPX8DQpmeH0VnB = url.split(EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠰ࠩผ"))[vUnJhT2NO8yirHcAmg].replace(hPFcB6Uxmabj59Iq(u"ࠨࡧࡰࡦࡪࡪ࠭ࠨฝ"),sCHVtMAvqirbQ4BUK3cgWo).replace(TzIj50KpohEOHx6CbZWqB(u"ࠩ࠱࡬ࡹࡳ࡬ࠨพ"),sCHVtMAvqirbQ4BUK3cgWo)
		if sH6BOz5wKRFcEg(u"ࠪࠦ࡮ࡪ࠲ࠣࠩฟ") in ssUAzo3RibtgDv7O0x: rnCzKJiBSsgGhj = {oVwa0kcqxj1e7mLplAfZdGT(u"ࠫ࡮ࡪ࠲ࠨภ"):MNZPX8DQpmeH0VnB,hPFcB6Uxmabj59Iq(u"ࠬࡵࡰࠨม"):oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩย")}
		elif t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠣ࡫ࡧࠦࠬร") in ssUAzo3RibtgDv7O0x: rnCzKJiBSsgGhj = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨ࡫ࡧࠫฤ"):MNZPX8DQpmeH0VnB,SIkwCEdJHTD9v1(u"ࠩࡲࡴࠬล"):phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭ฦ")}
		HSNYwERMjzyxmrPku = headers.copy()
		HSNYwERMjzyxmrPku[SIkwCEdJHTD9v1(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪว")] = qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫศ")
		CxP3d82yUTnMa = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,IO7k2hZXSz(u"࠭ࡐࡐࡕࡗࠫษ"),url,rnCzKJiBSsgGhj,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,lvzrYTpcBaK,RDwahqjPfbdyEiTtnLQu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩส"))
		ssUAzo3RibtgDv7O0x = CxP3d82yUTnMa.content
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = zpBKltk4s6FE1q9O(url,ssUAzo3RibtgDv7O0x)
	cvV7Kb49CqRoz68yN1fU[Gj9Uz05RebqClhLdX7xMkma4FpoJDW] = JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV,Ayi1QRLxgN4EpXUGb8hueqOHF
	return
cvV7Kb49CqRoz68yN1fU,CTvupVthHk3lRJ = {},BewrUo9ANCa17G43Sn0LH5xh
def JJqiRCW6DHKfkV0wgEGO3nAXY1(url):
	global cvV7Kb49CqRoz68yN1fU,CTvupVthHk3lRJ
	CTvupVthHk3lRJ += E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠵࠵࠶໤")
	EZoeYMmJGdn1c4wAIbC5s80 = CTvupVthHk3lRJ
	PXFtqmw5lBGQNa0IV8 = [(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,url)]
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace(aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩห"),gDETKVh8mZe09Nd(u"ࠩ࠲ࠫฬ"))
	cuIJ3axEtVWvs = fNntYJW45mEFSdRX8g.findall(EJgYdjbIiWe1apkQlZcR42(u"ࠪࡢ࠭࠴ࠪࡀ࠼࠲࠳࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯ࠤࠨอ"),vrEJRkchKxtDNiqO1b79mL5eT+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫ࠴࠭ฮ"),fNntYJW45mEFSdRX8g.DOTALL)
	try: start,jlpoTeAsguGJXH5N6ZOUBq,end = cuIJ3axEtVWvs[BewrUo9ANCa17G43Sn0LH5xh]
	except: return Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡗࡏࡘࡎࡥࡘࡔࡊࡄࡖࡎࡔࡇࠨฯ"),[],[]
	end = end.strip(t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭࠯ࠨะ"))
	MWBnOfg8uAT3YFm = len(jlpoTeAsguGJXH5N6ZOUBq)<kK7gj9HE462hADJbvr or jlpoTeAsguGJXH5N6ZOUBq in [GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡧ࡫࡯ࡩࠬั"),sH6BOz5wKRFcEg(u"ࠨࡸ࡬ࡨࡪࡵࠧา"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡹ࡭ࡩ࡫࡯ࡦ࡯ࡥࡩࡩ࠭ำ"),aenpKvQCGVzhLXEdWiDIZ(u"ࠪࡥ࡯ࡧࡸࠨิ"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫี"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠬࡳࡩࡳࡴࡲࡶࠬึ")]
	if not MWBnOfg8uAT3YFm: PXFtqmw5lBGQNa0IV8.append([rgpY5VUqKbeFOCD9Nki2SmGvxEja,start+TzIj50KpohEOHx6CbZWqB(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧื")+jlpoTeAsguGJXH5N6ZOUBq+fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࠰ุࠩ")+end])
	if end: PXFtqmw5lBGQNa0IV8.append([vUnJhT2NO8yirHcAmg,start+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨ࠱ูࠪ")+jlpoTeAsguGJXH5N6ZOUBq+SE97R3Dpj6dPLweVKU(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ฺࠪ")+end])
	if IOHSz7YPF9WusGgUt1Dq(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ฻") in jlpoTeAsguGJXH5N6ZOUBq:
		qqFaUjgeA40YJ3 = jlpoTeAsguGJXH5N6ZOUBq.replace(zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ฼"),sCHVtMAvqirbQ4BUK3cgWo)
		PXFtqmw5lBGQNa0IV8.append([kK7gj9HE462hADJbvr,start+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬ࠵ࠧ฽")+qqFaUjgeA40YJ3+IOHSz7YPF9WusGgUt1Dq(u"࠭࠯ࠨ฾")+end])
		PXFtqmw5lBGQNa0IV8.append([phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠺໥"),start+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ฿")+qqFaUjgeA40YJ3+GVurlv8HeoXEzPRiQB7Ty(u"ࠨ࠱ࠪเ")+end])
		if end: PXFtqmw5lBGQNa0IV8.append([Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠼໦"),start+bGzRdmOErkIylxALniq6(u"ࠩ࠲ࠫแ")+qqFaUjgeA40YJ3+Js61GTdX5wzMurUqi7Z(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫโ")+end])
	elif hPFcB6Uxmabj59Iq(u"ࠫ࠳࡮ࡴ࡮࡮ࠪใ") in end:
		B1s7dHz2C83QnWPeqRNpTV = end.replace(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬ࠴ࡨࡵ࡯࡯ࠫไ"),sCHVtMAvqirbQ4BUK3cgWo)
		PXFtqmw5lBGQNa0IV8.append([aenpKvQCGVzhLXEdWiDIZ(u"࠷໧"),start+Js61GTdX5wzMurUqi7Z(u"࠭࠯ࠨๅ")+jlpoTeAsguGJXH5N6ZOUBq+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧ࠰ࠩๆ")+B1s7dHz2C83QnWPeqRNpTV])
		if not MWBnOfg8uAT3YFm: PXFtqmw5lBGQNa0IV8.append([phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠹໨"),start+BWfpRku7SsM6cbE0eG(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ็")+jlpoTeAsguGJXH5N6ZOUBq+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩ࠲่ࠫ")+B1s7dHz2C83QnWPeqRNpTV])
		PXFtqmw5lBGQNa0IV8.append([sH6BOz5wKRFcEg(u"࠻໩"),start+bGzRdmOErkIylxALniq6(u"ࠪ࠳้ࠬ")+jlpoTeAsguGJXH5N6ZOUBq+zLjWeKu6JgNO7vocUD0Qpy(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱๊ࠬ")+B1s7dHz2C83QnWPeqRNpTV])
	else:
		if not MWBnOfg8uAT3YFm: PXFtqmw5lBGQNa0IV8.append([IO7k2hZXSz(u"࠴࠴໪"),start+gDETKVh8mZe09Nd(u"ࠬ࠵๋ࠧ")+jlpoTeAsguGJXH5N6ZOUBq+TzIj50KpohEOHx6CbZWqB(u"࠭࠮ࡩࡶࡰࡰࠬ์")])
		if not MWBnOfg8uAT3YFm: PXFtqmw5lBGQNa0IV8.append([iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠵࠶໫"),start+qeG16a4pbSHziNVQ2uFXrs(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨํ")+jlpoTeAsguGJXH5N6ZOUBq+XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨ࠰࡫ࡸࡲࡲࠧ๎")])
		if end: PXFtqmw5lBGQNa0IV8.append([aYH620Dh48GEsTFfOBSQ7r(u"࠶࠸໬"),start+jwzOabysh0Z(u"ࠩ࠲ࠫ๏")+jlpoTeAsguGJXH5N6ZOUBq+TzIj50KpohEOHx6CbZWqB(u"ࠪ࠳ࠬ๐")+end+sH6BOz5wKRFcEg(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ๑")])
		if end: PXFtqmw5lBGQNa0IV8.append([gDETKVh8mZe09Nd(u"࠷࠳໭"),start+BWfpRku7SsM6cbE0eG(u"ࠬ࠵ࠧ๒")+jlpoTeAsguGJXH5N6ZOUBq+E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ๓")+end+Js61GTdX5wzMurUqi7Z(u"ࠧ࠯ࡪࡷࡱࡱ࠭๔")])
	if MWBnOfg8uAT3YFm and end:
		end = end.replace(oVwa0kcqxj1e7mLplAfZdGT(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ๕"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠩ࠲ࠫ๖"))
		PXFtqmw5lBGQNa0IV8.append([SIkwCEdJHTD9v1(u"࠱࠵໮"),start+oVwa0kcqxj1e7mLplAfZdGT(u"ࠪ࠳ࠬ๗")+end])
		PXFtqmw5lBGQNa0IV8.append([phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠲࠷໯"),start+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ๘")+end])
		if wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ๙") in end:
			B1s7dHz2C83QnWPeqRNpTV = end.replace(hPFcB6Uxmabj59Iq(u"࠭࠮ࡩࡶࡰࡰࠬ๚"),sCHVtMAvqirbQ4BUK3cgWo)
			PXFtqmw5lBGQNa0IV8.append([phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠳࠹໰"),start+fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࠰ࠩ๛")+B1s7dHz2C83QnWPeqRNpTV])
			PXFtqmw5lBGQNa0IV8.append([E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠴࠻໱"),start+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ๜")+B1s7dHz2C83QnWPeqRNpTV])
		else:
			PXFtqmw5lBGQNa0IV8.append([Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠵࠽໲"),start+hPFcB6Uxmabj59Iq(u"ࠩ࠲ࠫ๝")+end+YQNd4wejLSAVJ6T(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ๞")])
			PXFtqmw5lBGQNa0IV8.append([bGzRdmOErkIylxALniq6(u"࠶࠿໳"),start+jwzOabysh0Z(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ๟")+end+XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ๠")])
	VfPQaGbrYu3pw = []
	for ISfWanzRV0GLEpY7e9Tl4FBsv1u,NroHCBWaxUZOfbgqMzAL4vJ2 in PXFtqmw5lBGQNa0IV8:
		cvV7Kb49CqRoz68yN1fU[EZoeYMmJGdn1c4wAIbC5s80+ISfWanzRV0GLEpY7e9Tl4FBsv1u] = [ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK,ZetiSjBQ9bTnF23pzsmXcyWuK]
		BPKAUSDwVk7j0pExa = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=WWTX7BCkt4aygo,args=(EZoeYMmJGdn1c4wAIbC5s80+ISfWanzRV0GLEpY7e9Tl4FBsv1u,NroHCBWaxUZOfbgqMzAL4vJ2))
		VfPQaGbrYu3pw.append(BPKAUSDwVk7j0pExa)
	def wJ2SXGBCYsgIp1():
		vfrjqSsdFHxQOBtEl1uJ = lvzrYTpcBaK
		for YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z in cvV7Kb49CqRoz68yN1fU:
			if not YIQlWv3FH7RKjLJfEaTPrt4Dkc6Z: break
		else: vfrjqSsdFHxQOBtEl1uJ = ndkUxG9LtewJ
		sxjn4kIyMur8fw9KUTFDiB3 = FoiwfTEhGD8ulS25HeUvnI.Player().isPlaying() if Q1siCkTZyw.resolveonly else ndkUxG9LtewJ
		return vfrjqSsdFHxQOBtEl1uJ or not sxjn4kIyMur8fw9KUTFDiB3
	Tgpqkx7DH6w30r(VfPQaGbrYu3pw,jjPTvSMUJYuhgaC4XHOEFb7xc6rI0,jkYp9crn3R2IA6GL58vNMPX1JeQK,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,wJ2SXGBCYsgIp1)
	JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = sCHVtMAvqirbQ4BUK3cgWo,[],[]
	VIMqOjdWywSBvK = []
	for ISfWanzRV0GLEpY7e9Tl4FBsv1u,B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
		LIxFD0APbYoQK4fUmMz,oB06y73UabNjEqJdR,ggS2s0uWLMAbz,XCh8OgP7adGZymFr = cvV7Kb49CqRoz68yN1fU[EZoeYMmJGdn1c4wAIbC5s80+ISfWanzRV0GLEpY7e9Tl4FBsv1u]
		if not ss7YGDbuAIxgnqaQroTV and ggS2s0uWLMAbz: V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = oB06y73UabNjEqJdR,ggS2s0uWLMAbz
		if not JbShzsakZ5M1i and LIxFD0APbYoQK4fUmMz: JbShzsakZ5M1i = LIxFD0APbYoQK4fUmMz
		if XCh8OgP7adGZymFr: VIMqOjdWywSBvK.append(XCh8OgP7adGZymFr)
	VIMqOjdWywSBvK = list(set(VIMqOjdWywSBvK))
	if not JbShzsakZ5M1i and len(VIMqOjdWywSBvK)==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		Ayi1QRLxgN4EpXUGb8hueqOHF = VIMqOjdWywSBvK[BewrUo9ANCa17G43Sn0LH5xh]
		if Ayi1QRLxgN4EpXUGb8hueqOHF!=Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠸࠰࠱໴"):
			if Ayi1QRLxgN4EpXUGb8hueqOHF<BewrUo9ANCa17G43Sn0LH5xh: JbShzsakZ5M1i = bGzRdmOErkIylxALniq6(u"࠭ࡖࡪࡦࡨࡳࠥࡶࡡࡨࡧ࠲ࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࡨࡩࡥࡴࡵ࡬ࡦࡱ࡫ࠧ๡")
			else:
				JbShzsakZ5M1i = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡉࡖࡗࡔࠥࡋࡲࡳࡱࡵ࠾ࠥ࠭๢")+str(Ayi1QRLxgN4EpXUGb8hueqOHF)
				if I5VKjrFL0Bk97: import http.client as CQLt3nI5qsWEDpPrT1vkVfia6Sj
				else: import httplib as CQLt3nI5qsWEDpPrT1vkVfia6Sj
				try: JbShzsakZ5M1i += zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢࠫࠤࠬ๣")+CQLt3nI5qsWEDpPrT1vkVfia6Sj.responses[Ayi1QRLxgN4EpXUGb8hueqOHF]+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩࠣ࠭ࠬ๤")
				except: pass
	hDjf1Ubgq629nXlOvcFLH4Jw.sleep(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
	return JbShzsakZ5M1i,V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV
class zju57SPeqFlBH6rM(qqtbjl02E5pUOdQ1yMn8xABJsVG67w.WindowDialog):
	def __init__(RJa8ne9fq3YXGDQcioTZu5srmkKd, *args, **cTQl2aZmAUB8Ir7N91sRkpMnFoJG):
		Qykn0S4sTuJFMiv5zPEKpjI9YcloV1 = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV, qqw1upCsKM(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭๥"), EJgYdjbIiWe1apkQlZcR42(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨ๦"), GVurlv8HeoXEzPRiQB7Ty(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡧ࡭࠮ࡱࡰࡪࠫ๧"))
		Oc9JFn2T3gIH7xs6VAKmCd = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV, XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ๨"), SIkwCEdJHTD9v1(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫ๩"), BWfpRku7SsM6cbE0eG(u"ࠨࡵࡨࡰࡪࡩࡴࡦࡦ࠱ࡴࡳ࡭ࠧ๪"))
		nnoeVXEPBiItSFdyhDKf = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV, TzIj50KpohEOHx6CbZWqB(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬ๫"), XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧ๬"), Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫࡧࡻࡴࡵࡱࡱࡪࡴ࠴ࡰ࡯ࡩࠪ๭"))
		jjwkBqsatzinM6OSWJxYN9fmE7UI = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV, YQNd4wejLSAVJ6T(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ๮"), t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪ๯"), bGzRdmOErkIylxALniq6(u"ࠧࡣࡷࡷࡸࡴࡴ࡮ࡧ࠰ࡳࡲ࡬࠭๰"))
		wihUNLSTsZqkRmMW4 = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ffBvikd9sV, XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ๱"), E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭๲"), Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡦࡺࡺࡴࡰࡰࡥ࡫࠳ࡶ࡮ࡨࠩ๳"))
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelled = lvzrYTpcBaK
		RJa8ne9fq3YXGDQcioTZu5srmkKd.chk = [BewrUo9ANCa17G43Sn0LH5xh] * YQNd4wejLSAVJ6T(u"࠹໵")
		RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton = [BewrUo9ANCa17G43Sn0LH5xh] * t19ZOVHA4CpwFKaeiubcMGvz(u"࠺໶")
		RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate = [lvzrYTpcBaK] * qqw1upCsKM(u"࠻໷")
		iA0BSn9LEs1pd4, A3RUlwBhEu, rcLzgn5SFOmakBNHM, bb3kNw4rv8yo = aYH620Dh48GEsTFfOBSQ7r(u"࠵࠹࠵໸"), BewrUo9ANCa17G43Sn0LH5xh, SIkwCEdJHTD9v1(u"࠻࠵࠶໹"), qqw1upCsKM(u"࠼࠼࠰໺")
		CKM3cnDvuR8gjiQrxIEU = iA0BSn9LEs1pd4+rcLzgn5SFOmakBNHM//rgpY5VUqKbeFOCD9Nki2SmGvxEja
		Q0EWOrDjK1GF2LNs9i, XCPZMuhUF9HoSxcrkOq7ETafn, pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG, dHmWrAsqeQchVBCtlzuE0yv5fIgOj = SIkwCEdJHTD9v1(u"࠳࠶࠷໼"), zLjWeKu6JgNO7vocUD0Qpy(u"࠷࠲࠱໻"), XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠶࠲࠳໽"), XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠶࠲࠳໽")
		v4vXxaRPAgLsJGWTc = Q0EWOrDjK1GF2LNs9i+pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG//rgpY5VUqKbeFOCD9Nki2SmGvxEja
		h8h3JUM7BWL, qd7ZLSbxRWt6kvHzrEB1mPF9, IwdQDAYB1bCzMaO5Roj, qMcOTveu0HgUVawAYBCKIf = t19ZOVHA4CpwFKaeiubcMGvz(u"࠴࠴࠵໿"), aenpKvQCGVzhLXEdWiDIZ(u"࠺࠺࠻ༀ"), BWfpRku7SsM6cbE0eG(u"࠳࠸࠴໾"), aenpKvQCGVzhLXEdWiDIZ(u"࠺࠶༁")
		RkK4BFItCLh8WjiuYA3E0zyeoH15fw = CKM3cnDvuR8gjiQrxIEU-IwdQDAYB1bCzMaO5Roj-h8h3JUM7BWL//rgpY5VUqKbeFOCD9Nki2SmGvxEja
		YsHjPWncru3ZdVD9pb6oG41R0e = CKM3cnDvuR8gjiQrxIEU+h8h3JUM7BWL//rgpY5VUqKbeFOCD9Nki2SmGvxEja
		hyXqYr9I2jtnNLO, YNlW5FDLP0jwk7HGxa4h8, A6yNJuXY8svVSzhW1oB, wwQgSjMXeC4ETPHyzR = SE97R3Dpj6dPLweVKU(u"࠹࠵࠶༂"), qeG16a4pbSHziNVQ2uFXrs(u"࠳࠱༃"), aYH620Dh48GEsTFfOBSQ7r(u"࠷࠳࠴༅"), TzIj50KpohEOHx6CbZWqB(u"࠶࠲༄")
		adi1qBP9eEn6MOL, PDpzXjxrGLuHKeQg3C, Sylt0jpN7AgM4UzFxCs61Hv2YGD8, kj4S9h27K8pvWDOnmI = RDwahqjPfbdyEiTtnLQu(u"࠶࠹࠺༆"), Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"࠽࠰༉"), phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠺࠶࠰༈"), hPFcB6Uxmabj59Iq(u"࠹࠵༇")
		kxpD1MbESRVaOH0qQ = Js61GTdX5wzMurUqi7Z(u"࠰࠯࠻༊")
		iA0BSn9LEs1pd4, A3RUlwBhEu, rcLzgn5SFOmakBNHM, bb3kNw4rv8yo = int(iA0BSn9LEs1pd4*kxpD1MbESRVaOH0qQ), int(A3RUlwBhEu*kxpD1MbESRVaOH0qQ), int(rcLzgn5SFOmakBNHM*kxpD1MbESRVaOH0qQ), int(bb3kNw4rv8yo*kxpD1MbESRVaOH0qQ)
		Q0EWOrDjK1GF2LNs9i, XCPZMuhUF9HoSxcrkOq7ETafn, pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG, dHmWrAsqeQchVBCtlzuE0yv5fIgOj = int(Q0EWOrDjK1GF2LNs9i*kxpD1MbESRVaOH0qQ), int(XCPZMuhUF9HoSxcrkOq7ETafn*kxpD1MbESRVaOH0qQ), int(pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG*kxpD1MbESRVaOH0qQ), int(dHmWrAsqeQchVBCtlzuE0yv5fIgOj*kxpD1MbESRVaOH0qQ)
		RkK4BFItCLh8WjiuYA3E0zyeoH15fw, z3jDqLBJAMvVSpCfPsy, KkGShVumXrwiMOfJog0WqbY9, xg8sFekhVuGzofDOCUQ0mTc7 = int(RkK4BFItCLh8WjiuYA3E0zyeoH15fw*kxpD1MbESRVaOH0qQ), int(qd7ZLSbxRWt6kvHzrEB1mPF9*kxpD1MbESRVaOH0qQ), int(IwdQDAYB1bCzMaO5Roj*kxpD1MbESRVaOH0qQ), int(qMcOTveu0HgUVawAYBCKIf*kxpD1MbESRVaOH0qQ)
		YsHjPWncru3ZdVD9pb6oG41R0e, Vet5KuY1mj89ZTaszqWf, AjzSUoNvnJPRDCKkpXmTL8ulG, LIZ5kGCyBqjdMrSQlfPm3XA = int(YsHjPWncru3ZdVD9pb6oG41R0e*kxpD1MbESRVaOH0qQ), int(qd7ZLSbxRWt6kvHzrEB1mPF9*kxpD1MbESRVaOH0qQ), int(IwdQDAYB1bCzMaO5Roj*kxpD1MbESRVaOH0qQ), int(qMcOTveu0HgUVawAYBCKIf*kxpD1MbESRVaOH0qQ)
		hyXqYr9I2jtnNLO, YNlW5FDLP0jwk7HGxa4h8, A6yNJuXY8svVSzhW1oB, wwQgSjMXeC4ETPHyzR = int(hyXqYr9I2jtnNLO*kxpD1MbESRVaOH0qQ), int(YNlW5FDLP0jwk7HGxa4h8*kxpD1MbESRVaOH0qQ), int(A6yNJuXY8svVSzhW1oB*kxpD1MbESRVaOH0qQ), int(wwQgSjMXeC4ETPHyzR*kxpD1MbESRVaOH0qQ)
		adi1qBP9eEn6MOL, PDpzXjxrGLuHKeQg3C, Sylt0jpN7AgM4UzFxCs61Hv2YGD8, kj4S9h27K8pvWDOnmI = int(adi1qBP9eEn6MOL*kxpD1MbESRVaOH0qQ), int(PDpzXjxrGLuHKeQg3C*kxpD1MbESRVaOH0qQ), int(Sylt0jpN7AgM4UzFxCs61Hv2YGD8*kxpD1MbESRVaOH0qQ), int(kj4S9h27K8pvWDOnmI*kxpD1MbESRVaOH0qQ)
		eLzj9DBXH4bOI7 = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlImage(iA0BSn9LEs1pd4, A3RUlwBhEu, rcLzgn5SFOmakBNHM, bb3kNw4rv8yo, Qykn0S4sTuJFMiv5zPEKpjI9YcloV1)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(eLzj9DBXH4bOI7)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.iteration = cTQl2aZmAUB8Ir7N91sRkpMnFoJG.get(qqw1upCsKM(u"ࠫ࡮ࡺࡥࡳࡣࡷ࡭ࡴࡴࠧ๴"))
		XzjcGCfHKw6We9QUBtIgJisA8p = F7Fe63KbGjaz2TcmCNHPdo5QiXO+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ๎ไิฬࠣีํฮ่หࠢࠣࠤࠥࠦࠠࠡࠢࠣࠫ๵")+RDwahqjPfbdyEiTtnLQu(u"࠭วๅ็ะหํ๊ษࠡำๅ้ࠥࠦࠧ๶")+str(RJa8ne9fq3YXGDQcioTZu5srmkKd.iteration)+B8alA5nvIhTxQ
		RJa8ne9fq3YXGDQcioTZu5srmkKd.strActionInfo = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlLabel(hyXqYr9I2jtnNLO, YNlW5FDLP0jwk7HGxa4h8, A6yNJuXY8svVSzhW1oB, wwQgSjMXeC4ETPHyzR, XzjcGCfHKw6We9QUBtIgJisA8p, bGzRdmOErkIylxALniq6(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧ๷"))
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.strActionInfo)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlImage(Q0EWOrDjK1GF2LNs9i, XCPZMuhUF9HoSxcrkOq7ETafn, pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG, dHmWrAsqeQchVBCtlzuE0yv5fIgOj, cTQl2aZmAUB8Ir7N91sRkpMnFoJG.get(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡥࡤࡴࡹࡩࡨࡢࠩ๸")))
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		MMjwcuYDzZvxV1AH8k6hWOgilaN = F7Fe63KbGjaz2TcmCNHPdo5QiXO+cTQl2aZmAUB8Ir7N91sRkpMnFoJG.get(jwzOabysh0Z(u"ࠩࡰࡷ࡬࠭๹"))+B8alA5nvIhTxQ
		RJa8ne9fq3YXGDQcioTZu5srmkKd.strActionInfo = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlLabel(adi1qBP9eEn6MOL, PDpzXjxrGLuHKeQg3C, Sylt0jpN7AgM4UzFxCs61Hv2YGD8, kj4S9h27K8pvWDOnmI, MMjwcuYDzZvxV1AH8k6hWOgilaN, GVurlv8HeoXEzPRiQB7Ty(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪ๺"))
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.strActionInfo)
		text = F7Fe63KbGjaz2TcmCNHPdo5QiXO+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠫำื่อࠩ๻")+B8alA5nvIhTxQ
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlButton(RkK4BFItCLh8WjiuYA3E0zyeoH15fw, z3jDqLBJAMvVSpCfPsy, KkGShVumXrwiMOfJog0WqbY9, xg8sFekhVuGzofDOCUQ0mTc7, text, focusTexture=wihUNLSTsZqkRmMW4, noFocusTexture=nnoeVXEPBiItSFdyhDKf, alignment=oVwa0kcqxj1e7mLplAfZdGT(u"࠳་"))
		text = F7Fe63KbGjaz2TcmCNHPdo5QiXO+hPFcB6Uxmabj59Iq(u"ࠬอำห็ิหึ࠭๼")+B8alA5nvIhTxQ
		RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlButton(YsHjPWncru3ZdVD9pb6oG41R0e, Vet5KuY1mj89ZTaszqWf, AjzSUoNvnJPRDCKkpXmTL8ulG, LIZ5kGCyBqjdMrSQlfPm3XA, text, focusTexture=wihUNLSTsZqkRmMW4, noFocusTexture=nnoeVXEPBiItSFdyhDKf, alignment=wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠴༌"))
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton)
		CwGgkdajs2o, wERbPXmtGBel3rsC4U1v0cY9gzQ = dHmWrAsqeQchVBCtlzuE0yv5fIgOj//vUnJhT2NO8yirHcAmg, pyxKrnc9JhBk6HQIaNX3P0vAsS4YCG//vUnJhT2NO8yirHcAmg
		for XMIo9vWSBymeLJnK6YsU in range(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠼།")):
			JeK9I7SbN4 = XMIo9vWSBymeLJnK6YsU // vUnJhT2NO8yirHcAmg
			juFqJ7m5gdC = XMIo9vWSBymeLJnK6YsU % vUnJhT2NO8yirHcAmg
			DpB2l7cAUJkN08E5HFX = Q0EWOrDjK1GF2LNs9i + (wERbPXmtGBel3rsC4U1v0cY9gzQ * juFqJ7m5gdC)
			NNzHegbWMJI5iTr6DE28y7 = XCPZMuhUF9HoSxcrkOq7ETafn + (CwGgkdajs2o * JeK9I7SbN4)
			RJa8ne9fq3YXGDQcioTZu5srmkKd.chk[XMIo9vWSBymeLJnK6YsU] = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlImage(DpB2l7cAUJkN08E5HFX, NNzHegbWMJI5iTr6DE28y7, wERbPXmtGBel3rsC4U1v0cY9gzQ, CwGgkdajs2o, Oc9JFn2T3gIH7xs6VAKmCd)
			RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.chk[XMIo9vWSBymeLJnK6YsU])
			RJa8ne9fq3YXGDQcioTZu5srmkKd.chk[XMIo9vWSBymeLJnK6YsU].setVisible(lvzrYTpcBaK)
			RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU] = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ControlButton(DpB2l7cAUJkN08E5HFX, NNzHegbWMJI5iTr6DE28y7, wERbPXmtGBel3rsC4U1v0cY9gzQ, CwGgkdajs2o, str(XMIo9vWSBymeLJnK6YsU + zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU), font=TzIj50KpohEOHx6CbZWqB(u"࠭ࡦࡰࡰࡷ࠵࠸࠭๽"), focusTexture=nnoeVXEPBiItSFdyhDKf, noFocusTexture=jjwkBqsatzinM6OSWJxYN9fmE7UI)
			RJa8ne9fq3YXGDQcioTZu5srmkKd.addControl(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU])
		for XMIo9vWSBymeLJnK6YsU in range(aYH620Dh48GEsTFfOBSQ7r(u"࠽༎")):
			jH4qeMtcUL = (XMIo9vWSBymeLJnK6YsU // vUnJhT2NO8yirHcAmg) * vUnJhT2NO8yirHcAmg
			L2mACjFgkJcDo = jH4qeMtcUL + (XMIo9vWSBymeLJnK6YsU + zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU) % vUnJhT2NO8yirHcAmg
			ijBouFmRDEG = jH4qeMtcUL + (XMIo9vWSBymeLJnK6YsU - zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU) % vUnJhT2NO8yirHcAmg
			q3pDe7sGFH2tE = (XMIo9vWSBymeLJnK6YsU - vUnJhT2NO8yirHcAmg) % gDETKVh8mZe09Nd(u"࠾༏")
			kl7bWO1zT2NCSr = (XMIo9vWSBymeLJnK6YsU + vUnJhT2NO8yirHcAmg) % hPFcB6Uxmabj59Iq(u"࠿༐")
			RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlRight(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[L2mACjFgkJcDo])
			RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlLeft(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[ijBouFmRDEG])
			if XMIo9vWSBymeLJnK6YsU <= rgpY5VUqKbeFOCD9Nki2SmGvxEja:
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlUp(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
			else:
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlUp(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[q3pDe7sGFH2tE])
			if XMIo9vWSBymeLJnK6YsU >= XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠶༑"):
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlDown(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
			else:
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XMIo9vWSBymeLJnK6YsU].controlDown(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[kl7bWO1zT2NCSr])
		RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton.controlLeft(RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton.controlRight(RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton.controlLeft(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton.controlRight(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
		RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton.controlDown(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[rgpY5VUqKbeFOCD9Nki2SmGvxEja])
		RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton.controlUp(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠹༒")])
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton.controlDown(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[BewrUo9ANCa17G43Sn0LH5xh])
		RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton.controlUp(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkbutton[gDETKVh8mZe09Nd(u"࠸༓")])
		RJa8ne9fq3YXGDQcioTZu5srmkKd.setFocus(RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton)
	def get(RJa8ne9fq3YXGDQcioTZu5srmkKd):
		RJa8ne9fq3YXGDQcioTZu5srmkKd.doModal()
		RJa8ne9fq3YXGDQcioTZu5srmkKd.close()
		if not RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelled:
			return [XMIo9vWSBymeLJnK6YsU for XMIo9vWSBymeLJnK6YsU in range(aenpKvQCGVzhLXEdWiDIZ(u"࠼༔")) if RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate[XMIo9vWSBymeLJnK6YsU]]
	def onControl(RJa8ne9fq3YXGDQcioTZu5srmkKd, Z9rf2vLtAkVoHTq0WIsDPQmU8ExSai):
		if Z9rf2vLtAkVoHTq0WIsDPQmU8ExSai.getId() == RJa8ne9fq3YXGDQcioTZu5srmkKd.okbutton.getId() and any(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate):
			RJa8ne9fq3YXGDQcioTZu5srmkKd.close()
		elif Z9rf2vLtAkVoHTq0WIsDPQmU8ExSai.getId() == RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelbutton.getId():
			RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelled = ndkUxG9LtewJ
			RJa8ne9fq3YXGDQcioTZu5srmkKd.close()
		else:
			c4yVMkzYb0 = Z9rf2vLtAkVoHTq0WIsDPQmU8ExSai.getLabel()
			if c4yVMkzYb0.isnumeric():
				index = int(c4yVMkzYb0) - zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate[index] = not RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate[index]
				RJa8ne9fq3YXGDQcioTZu5srmkKd.chk[index].setVisible(RJa8ne9fq3YXGDQcioTZu5srmkKd.chkstate[index])
	def onAction(RJa8ne9fq3YXGDQcioTZu5srmkKd, J0FI8ovETc4iqelhzpjR2XSY7DBPHd):
		if J0FI8ovETc4iqelhzpjR2XSY7DBPHd == IOHSz7YPF9WusGgUt1Dq(u"࠵࠵༕"):
			RJa8ne9fq3YXGDQcioTZu5srmkKd.cancelled = ndkUxG9LtewJ
			RJa8ne9fq3YXGDQcioTZu5srmkKd.close()
def xrX1JKVBjC6LvFha0Yq8p(key,TTtDQFAY086Gop1WbuXsHJkwxU,url):
	headers = {XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ๾"):url,IOHSz7YPF9WusGgUt1Dq(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ๿"):TTtDQFAY086Gop1WbuXsHJkwxU}
	NRM2cTIFV197js8XiPhrSBzf = aYH620Dh48GEsTFfOBSQ7r(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠵ࡡࡱ࡫࠲ࡪࡦࡲ࡬ࡣࡣࡦ࡯ࡄࡱ࠽ࠨ຀")+key
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡋࡊ࡚ࠧກ"),NRM2cTIFV197js8XiPhrSBzf,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠲ࡵࡷࠫຂ"))
	iigMzLZxRm6npGVfCvb0,iteration = sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh
	while ndkUxG9LtewJ:
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		rnCzKJiBSsgGhj = fNntYJW45mEFSdRX8g.findall(XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠬࠨࠨ࠰ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠳ࡦࡶࡩ࠳࠱ࡳࡥࡾࡲ࡯ࡢࡦ࡞ࡢࠧࡣࠫࠪࠩ຃"), Sw0pOFoVhPeIxbl)
		iteration += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		message = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"࠭࠼࡭ࡣࡥࡩࡱࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡴࡦࡺࡷࠦࡠࡤ࠾࡞ࠬࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰࡦࡨࡥ࡭ࡀࠪຄ"), Sw0pOFoVhPeIxbl)
		if not message: message = fNntYJW45mEFSdRX8g.findall(XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧ࠽ࡦ࡬ࡺࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲࡫ࡲࡳࡱࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ຅"), Sw0pOFoVhPeIxbl)
		if not message:
			iigMzLZxRm6npGVfCvb0 = fNntYJW45mEFSdRX8g.findall(t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࡴࡨࡥࡩࡵ࡮࡭ࡻࡁࠬ࠳࠰࠿ࠪ࠾ࠪຆ"), Sw0pOFoVhPeIxbl)[BewrUo9ANCa17G43Sn0LH5xh]
			break
		else:
			message = message[BewrUo9ANCa17G43Sn0LH5xh]
			rnCzKJiBSsgGhj = rnCzKJiBSsgGhj[BewrUo9ANCa17G43Sn0LH5xh]
		LX0l1UZiFOBHSuV869wNA = fNntYJW45mEFSdRX8g.findall(BWfpRku7SsM6cbE0eG(u"ࡴࠪࡲࡦࡳࡥ࠾ࠤࡦࠦࡡࡹࠫࡷࡣ࡯ࡹࡪࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠨງ"), Sw0pOFoVhPeIxbl)[BewrUo9ANCa17G43Sn0LH5xh]
		tU40xgDc9qplHdaMKnbjCIViWT1J = bGzRdmOErkIylxALniq6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱࠪࡹࠧຈ") % (rnCzKJiBSsgGhj.replace(SIkwCEdJHTD9v1(u"ࠫࠫࡧ࡭ࡱ࠽ࠪຉ"), t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠬࠧຊ")))
		message = fNntYJW45mEFSdRX8g.sub(SE97R3Dpj6dPLweVKU(u"࠭࠼࠰ࡁࠫࡨ࡮ࡼࡼࡴࡶࡵࡳࡳ࡭ࠩ࡜ࡠࡁࡡ࠯ࡄࠧ຋"), sCHVtMAvqirbQ4BUK3cgWo, message)
		kAiVEZm2jxMNI0Of = zju57SPeqFlBH6rM(captcha=tU40xgDc9qplHdaMKnbjCIViWT1J, msg=message, iteration=iteration)
		H76CX9xIyrREA5QT = kAiVEZm2jxMNI0Of.get()
		if not H76CX9xIyrREA5QT: break
		data = {iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡤࠩຌ"): LX0l1UZiFOBHSuV869wNA, qeG16a4pbSHziNVQ2uFXrs(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪຍ"): H76CX9xIyrREA5QT}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࡓࡓࡘ࡚ࠧຎ"),NRM2cTIFV197js8XiPhrSBzf,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠲࡯ࡦࠪຏ"))
	return iigMzLZxRm6npGVfCvb0
def yymfrBhUikM6sA7wo2eHFNcn9TY(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡑࡕࡁࡅࡕ࠰࠵ࡸࡺࠧຐ"))
	items = fNntYJW45mEFSdRX8g.findall(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪຑ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ items[BewrUo9ANCa17G43Sn0LH5xh] ]
	else: return oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫຒ"),[],[]
def C26pQc1wHYT7eFSzsNugLfhod(url):
	return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
def P0RtZUW9yIKdvfXg(url):
	smh8Qbf9jH = url.split(EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠰ࠩຓ"))
	qJIFYh4u5xc0ljArsDvmeWN2TM = BWfpRku7SsM6cbE0eG(u"ࠨ࠱ࠪດ").join(smh8Qbf9jH[BewrUo9ANCa17G43Sn0LH5xh:vUnJhT2NO8yirHcAmg])
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭ຕ"))
	items = fNntYJW45mEFSdRX8g.findall(zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬຖ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa,xx70Ghuj86CrSbqlPi2DeHJT,oRrC9eQcdy3S14wEBUm80,ZZOoxNvhJfSegcGA47sz8P,QqPc8o6ixLaZVJ = items[BewrUo9ANCa17G43Sn0LH5xh]
		b7bwuO6YAD = int(oFtKYZryln32AsLqcjBgWODwpa) % int(xx70Ghuj86CrSbqlPi2DeHJT) + int(oRrC9eQcdy3S14wEBUm80) % int(ZZOoxNvhJfSegcGA47sz8P)
		url = qJIFYh4u5xc0ljArsDvmeWN2TM + YUjl8EuWXnh47ZrA90xKztRMVLeGd + str(b7bwuO6YAD) + QqPc8o6ixLaZVJ
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[url]
	else: return IO7k2hZXSz(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࡚ࠦࡊࡒࡓ࡝ࡘࡎࡁࡓࡇࠪທ"),[],[]
def ee3IWH4taxSDJ5FscGlARVidgOqm(url):
	id = url.split(Js61GTdX5wzMurUqi7Z(u"ࠬ࠵ࠧຘ"))[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	headers = { YQNd4wejLSAVJ6T(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬນ") : fvYGxnZNUiyP4HJkMIoS25(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ບ") }
	rnCzKJiBSsgGhj = { SIkwCEdJHTD9v1(u"ࠣ࡫ࡧࠦປ"):id , t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠤࡲࡴࠧຜ"):RDwahqjPfbdyEiTtnLQu(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷ࠨຝ") }
	n1WYDtVC8dRHbXJkMa = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡕࡕࡓࡕࠩພ"), url, rnCzKJiBSsgGhj, headers, sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡓ࠸࡚ࡖࡌࡐࡃࡇ࠱࠶ࡹࡴࠨຟ"))
	if Js61GTdX5wzMurUqi7Z(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨຠ") in list(n1WYDtVC8dRHbXJkMa.headers.keys()): B17r2fdFy9ns8tiOMLu = n1WYDtVC8dRHbXJkMa.headers[qqw1upCsKM(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩມ")]
	else: B17r2fdFy9ns8tiOMLu = url
	if B17r2fdFy9ns8tiOMLu: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[B17r2fdFy9ns8tiOMLu]
	else: return oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭ຢ"),[],[]
def sRIMoWQFbOycT5hSVJEBkL1(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬຣ"))
	items = fNntYJW45mEFSdRX8g.findall(aYH620Dh48GEsTFfOBSQ7r(u"ࠪࡱࡵ࠺࠺ࠡ࡞࡞ࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭຤"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ items[BewrUo9ANCa17G43Sn0LH5xh] ]
	else: return aenpKvQCGVzhLXEdWiDIZ(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡊࡐࡗ࡚ࡑࡏࡖࡆࠩລ"),[],[]
def gx5yt6po1JCmdsTzPFBZ7OvYckw4Uh(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭຦"))
	items = fNntYJW45mEFSdRX8g.findall(aenpKvQCGVzhLXEdWiDIZ(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫວ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		url = url = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭ຨ") + items[BewrUo9ANCa17G43Sn0LH5xh]
		return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ url ]
	else: return hPFcB6Uxmabj59Iq(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫຩ"),[],[]
def czLHKf32QOIE0XADM(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪສ"))
	items = fNntYJW45mEFSdRX8g.findall(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪຫ"),Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items: return sCHVtMAvqirbQ4BUK3cgWo,[sCHVtMAvqirbQ4BUK3cgWo],[ items[BewrUo9ANCa17G43Sn0LH5xh] ]
	else: return RDwahqjPfbdyEiTtnLQu(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡔࡖࡕࡉࡆࡓࠧຬ"),[],[]
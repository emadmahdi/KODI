﻿# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ALMAAREF'
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
Z0BYJQghVL1v87CAem = '_MRF_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def dBHD1Vl7hQuNOY(mode,url,text,mRwrKW6fNZV):
	if   mode==40: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==41: ka7jz96YCdTBnQOLVPuJG3285MHf = I2IfwUGCn68MRT3QFhWNjsDxrb()
	elif mode==42: ka7jz96YCdTBnQOLVPuJG3285MHf = CF4ApKUR6jdmsuoMlV(text,mRwrKW6fNZV)
	elif mode==43: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==44: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(text,mRwrKW6fNZV)
	elif mode==49: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,49)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'البث الحي لقناة المعارف',sCHVtMAvqirbQ4BUK3cgWo,41)
	CF4ApKUR6jdmsuoMlV(sCHVtMAvqirbQ4BUK3cgWo,'1')
	return
def QJ0S7Lszr9U6aRFE4(Z2VkQhiPAOuboSRB,o93oRMjVuwqODcsnm7t):
	search,sort,XJiqmptnOTc,B4SziFvRIXpPeGmfZDw3aVWJMAKNc,JI38OgFpmXqHuzMyn1NWwxajsAErk = sCHVtMAvqirbQ4BUK3cgWo,[],[],[],[]
	qLbRrEtgenpSi,ZVFm9TRXPdokw0 = muXAzTa365Mjklef1ZP7JiWrIR(Z2VkQhiPAOuboSRB)
	for CCzds3YbQDjKUFxfA5RHMIyBaSt in list(ZVFm9TRXPdokw0.keys()):
		value = ZVFm9TRXPdokw0[CCzds3YbQDjKUFxfA5RHMIyBaSt]
		if not value: continue
		if   CCzds3YbQDjKUFxfA5RHMIyBaSt=='sort': sort = [value]
		elif CCzds3YbQDjKUFxfA5RHMIyBaSt=='series': XJiqmptnOTc = [value]
		elif CCzds3YbQDjKUFxfA5RHMIyBaSt=='search': search = value
		elif CCzds3YbQDjKUFxfA5RHMIyBaSt=='category': B4SziFvRIXpPeGmfZDw3aVWJMAKNc = [value]
		elif CCzds3YbQDjKUFxfA5RHMIyBaSt=='specialist': JI38OgFpmXqHuzMyn1NWwxajsAErk = [value]
	rnCzKJiBSsgGhj = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":B4SziFvRIXpPeGmfZDw3aVWJMAKNc,"specialist":JI38OgFpmXqHuzMyn1NWwxajsAErk,"series":XJiqmptnOTc,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(o93oRMjVuwqODcsnm7t)}}
	rnCzKJiBSsgGhj = Kdnrl9JHV0cFaGzC5bN.dumps(rnCzKJiBSsgGhj)
	B17r2fdFy9ns8tiOMLu = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',B17r2fdFy9ns8tiOMLu,rnCzKJiBSsgGhj,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	data = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',Sw0pOFoVhPeIxbl)
	return data
def CF4ApKUR6jdmsuoMlV(Z2VkQhiPAOuboSRB,level):
	Jae64ky3REO57A2MvVHB90 = QJ0S7Lszr9U6aRFE4(Z2VkQhiPAOuboSRB,'1')
	Po9h3gWFuLR2 = Jae64ky3REO57A2MvVHB90['facets']
	if level=='1':
		Po9h3gWFuLR2 = Po9h3gWFuLR2['video_categories']
		items = fNntYJW45mEFSdRX8g.findall('<div(.*?)/div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for UqKgalXPCz7eQAL08foMx1R in items:
			AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',UqKgalXPCz7eQAL08foMx1R+'<',fNntYJW45mEFSdRX8g.DOTALL)
			if not AHhdOiGao5UZ: AHhdOiGao5UZ = fNntYJW45mEFSdRX8g.findall('data-value=\\"(.*?)\\">(.*?)<',UqKgalXPCz7eQAL08foMx1R+'<',fNntYJW45mEFSdRX8g.DOTALL)
			B4SziFvRIXpPeGmfZDw3aVWJMAKNc,title = AHhdOiGao5UZ[0]
			if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
			if not Z2VkQhiPAOuboSRB: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,42,sCHVtMAvqirbQ4BUK3cgWo,'2','?category='+B4SziFvRIXpPeGmfZDw3aVWJMAKNc)
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,42,sCHVtMAvqirbQ4BUK3cgWo,'2',Z2VkQhiPAOuboSRB+'&category='+B4SziFvRIXpPeGmfZDw3aVWJMAKNc)
	if level=='2':
		Po9h3gWFuLR2 = Po9h3gWFuLR2['specialist']
		items = fNntYJW45mEFSdRX8g.findall('value="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for JI38OgFpmXqHuzMyn1NWwxajsAErk,title in items:
			if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
			if not JI38OgFpmXqHuzMyn1NWwxajsAErk: title = title = 'الجميع'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,42,sCHVtMAvqirbQ4BUK3cgWo,'3',Z2VkQhiPAOuboSRB+'&specialist='+JI38OgFpmXqHuzMyn1NWwxajsAErk)
	elif level=='3':
		Po9h3gWFuLR2 = Po9h3gWFuLR2['series']
		items = fNntYJW45mEFSdRX8g.findall('value="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for XJiqmptnOTc,title in items:
			if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
			if not XJiqmptnOTc: title = title = 'الجميع'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,42,sCHVtMAvqirbQ4BUK3cgWo,'4',Z2VkQhiPAOuboSRB+'&series='+XJiqmptnOTc)
	elif level=='4':
		Po9h3gWFuLR2 = Po9h3gWFuLR2['sort_video']
		items = fNntYJW45mEFSdRX8g.findall('value="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for sort,title in items:
			if not sort: continue
			if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,sCHVtMAvqirbQ4BUK3cgWo,44,sCHVtMAvqirbQ4BUK3cgWo,'1',Z2VkQhiPAOuboSRB+'&sort='+sort)
	return
def fs7D0d3QyAT(Z2VkQhiPAOuboSRB,o93oRMjVuwqODcsnm7t):
	Jae64ky3REO57A2MvVHB90 = QJ0S7Lszr9U6aRFE4(Z2VkQhiPAOuboSRB,o93oRMjVuwqODcsnm7t)
	Po9h3gWFuLR2 = Jae64ky3REO57A2MvVHB90['template']
	items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,43,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	Po9h3gWFuLR2 = Jae64ky3REO57A2MvVHB90['facets']['pagination']
	items = fNntYJW45mEFSdRX8g.findall('data-page="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for mRwrKW6fNZV,title in items:
		if o93oRMjVuwqODcsnm7t==mRwrKW6fNZV: continue
		if qdUK5ioJyrO1T: title = EEH4kBfGY0FuZUjeNn(title)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,sCHVtMAvqirbQ4BUK3cgWo,44,sCHVtMAvqirbQ4BUK3cgWo,mRwrKW6fNZV,Z2VkQhiPAOuboSRB)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMAAREF-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('<video src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('youtube_url.*?(http.*?)&',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	cb1fAztguv78n9LGhSWJFm5p = []
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0].replace('\/','/')
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def I2IfwUGCn68MRT3QFhWNjsDxrb():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8+'/بث-مباشر',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'ALMAAREF-LIVE-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	url = fNntYJW45mEFSdRX8g.findall('"svpPlayer".*?(http.*?)&',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	url = url[0].replace('\\',sCHVtMAvqirbQ4BUK3cgWo)
	CeXLtzElr5DHhs(url,Ll1m0nJoaAPvHsXqyRE,'live')
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	e82P3ihJkbX7gA516unIZVlLqwR = False
	if search==sCHVtMAvqirbQ4BUK3cgWo:
		search = UyBdvjGrFxDWMpmLOXn()
		e82P3ihJkbX7gA516unIZVlLqwR = True
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	if not e82P3ihJkbX7gA516unIZVlLqwR: fs7D0d3QyAT('?search='+search,'1')
	else: CF4ApKUR6jdmsuoMlV('?search='+search,'1')
	return
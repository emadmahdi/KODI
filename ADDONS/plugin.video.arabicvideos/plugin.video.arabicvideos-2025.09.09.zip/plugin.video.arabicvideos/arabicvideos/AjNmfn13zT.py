# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'FASELHD1'
headers = {'User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
Z0BYJQghVL1v87CAem = '_FH1_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['جوائز الأوسكار','المراجعات','wwe']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==570: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==571: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==572: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==573: ka7jz96YCdTBnQOLVPuJG3285MHf = kAUpK78mJRgoWZQytrNXeh5xf3v(url,text)
	elif mode==576: ka7jz96YCdTBnQOLVPuJG3285MHf = NNq5VBrDKEfJ8he()
	elif mode==579: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('link',Z0BYJQghVL1v87CAem+'لماذا الموقع بطيء',sCHVtMAvqirbQ4BUK3cgWo,576)
	aeBQsh4fzLr8XM5xou1gcyE,url = gAVl1vUmus8,gAVl1vUmus8
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD1-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',aeBQsh4fzLr8XM5xou1gcyE,579,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'المميزة',aeBQsh4fzLr8XM5xou1gcyE,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured1')
	items = fNntYJW45mEFSdRX8g.findall('class="h3">(.*?)<.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for title,B17r2fdFy9ns8tiOMLu in items:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'details1')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"menu-primary"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		T490LUzt3RyObrnIoVjPFAmYZf = fNntYJW45mEFSdRX8g.findall('<li (.*?)</li>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		j1fNops7G2uO6PWb = [sCHVtMAvqirbQ4BUK3cgWo,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		ruCEzOyVgmGt9WHI7BSofF6d8 = 0
		for qsPRMmI7pHU2Ax4b98GgBTv in T490LUzt3RyObrnIoVjPFAmYZf:
			if ruCEzOyVgmGt9WHI7BSofF6d8>0: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',qsPRMmI7pHU2Ax4b98GgBTv,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
				if title==sCHVtMAvqirbQ4BUK3cgWo: continue
				if any(value in title.lower() for value in MqARWHDkmiT4nlz): continue
				title = j1fNops7G2uO6PWb[ruCEzOyVgmGt9WHI7BSofF6d8]+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'details2')
			ruCEzOyVgmGt9WHI7BSofF6d8 += 1
	return
def NNq5VBrDKEfJ8he():
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD1-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('class="h4">(.*?)</div>(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not iUtXlDhSVoBZJrPTQAwcER9nfMkN: return
	if type=='filters':
		oPnz7Zt4xLHTwR = [Sw0pOFoVhPeIxbl.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"homeSlide"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		WaYw6lHCObXNjc,PXFtqmw5lBGQNa0IV8,J4EIW0hU16YCcqn92uatb3 = zip(*items)
		items = zip(PXFtqmw5lBGQNa0IV8,WaYw6lHCObXNjc,J4EIW0hU16YCcqn92uatb3)
	elif type=='featured2':
		title,Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	elif type=='details2' and len(iUtXlDhSVoBZJrPTQAwcER9nfMkN)>1:
		title = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0][0]
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured2')
		title = iUtXlDhSVoBZJrPTQAwcER9nfMkN[1][0]
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'details3')
		return
	else:
		title,Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[-1]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		if any(value in title.lower() for value in MqARWHDkmiT4nlz): continue
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = EEH4kBfGY0FuZUjeNn(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.split('?resize=')[0]
		title = tt36wUe4HTPFmfs5hcbr(title)
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if '/collections/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,571,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and type==sCHVtMAvqirbQ4BUK3cgWo:
			title = '_MOD_'+bbFPOJrmkCaE6ul37XiKU[0][0]
			title = title.strip(' –')
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,573,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif 'episodes/' in B17r2fdFy9ns8tiOMLu or 'movies/' in B17r2fdFy9ns8tiOMLu or 'hindi/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,572,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,573,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if type=='filters':
		Djhn7VkYUeNaz = fNntYJW45mEFSdRX8g.findall('"more_button_page":(.*?),',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if Djhn7VkYUeNaz:
			count = Djhn7VkYUeNaz[0]
			B17r2fdFy9ns8tiOMLu = url+'/offset/'+count
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة أخرى',B17r2fdFy9ns8tiOMLu,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'filters')
	elif 'details' in type:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("class='pagination(.*?)</div>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall("href='(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = 'صفحة '+tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,571,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'details4')
	return
def kAUpK78mJRgoWZQytrNXeh5xf3v(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD1-SEASONS_EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	bFNze460jv = False
	if not type:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"seasonList"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if len(items)>1:
				aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
				bFNze460jv = True
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,name,title in items:
					name = tt36wUe4HTPFmfs5hcbr(name)
					if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+B17r2fdFy9ns8tiOMLu
					title = name+' - '+title
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,573,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,'episodes')
	if type=='episodes' or not bFNze460jv:
		Qp3jGv8leCbuiEU5Im = fNntYJW45mEFSdRX8g.findall('"posterImg".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if Qp3jGv8leCbuiEU5Im: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Qp3jGv8leCbuiEU5Im[0]
		else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = sCHVtMAvqirbQ4BUK3cgWo
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"epAll"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,572,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p,Uhsr1gY3uKa9W8N5zwPVRm6SA,sTnCDNGi3hy0W78 = [],[],[]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'FASELHD1-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	parekFWPdl = fNntYJW45mEFSdRX8g.findall('مستوى المشاهدة.*?">(.*?)</span>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if parekFWPdl:
		twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('"tag">(.*?)</a>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"videoRow"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('&img=')[0]
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named=__embed')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="streamHeader(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall("href = '(.*?)'.*?</i>(.*?)</a>",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('&img=')[0]
			name = name.strip(AAh0X3OCacr4HpifRGLZKT)
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__watch')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="downloadLinks(.*?)blackwindow',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</span>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.split('&img=')[0]
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+name+'__download')
	for KKHeUdhFn5jbykSRGIXAfm8z2lCsc in cb1fAztguv78n9LGhSWJFm5p:
		B17r2fdFy9ns8tiOMLu,name = KKHeUdhFn5jbykSRGIXAfm8z2lCsc.split('?named')
		if B17r2fdFy9ns8tiOMLu not in Uhsr1gY3uKa9W8N5zwPVRm6SA:
			Uhsr1gY3uKa9W8N5zwPVRm6SA.append(B17r2fdFy9ns8tiOMLu)
			sTnCDNGi3hy0W78.append(KKHeUdhFn5jbykSRGIXAfm8z2lCsc)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(sTnCDNGi3hy0W78,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(vrEJRkchKxtDNiqO1b79mL5eT,'details5')
	return
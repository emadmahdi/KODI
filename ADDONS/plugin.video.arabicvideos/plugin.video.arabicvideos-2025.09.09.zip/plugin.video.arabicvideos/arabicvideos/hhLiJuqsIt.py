# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
qsActmwjBGK4Ia1OFihlnCz = 'EXCLUDES'
def vRKwdHChabq1uLniJX(hoVitY5TylJ7GBEIZNOQg8pukq,z6zM3bBhaK):
	z6zM3bBhaK = z6zM3bBhaK.replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(' '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
	GJkufTZPadnNs8HmM0LltV = fNntYJW45mEFSdRX8g.findall('[a-zA-Z]',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
	if 'بحث IPTV - ' in hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace('بحث IPTV - ',aU23gVSeZ8QMl+'بحث IPTV - '+aU23gVSeZ8QMl)
	elif ' IPTV' in hoVitY5TylJ7GBEIZNOQg8pukq and z6zM3bBhaK=='IPT': hoVitY5TylJ7GBEIZNOQg8pukq = aU23gVSeZ8QMl+hoVitY5TylJ7GBEIZNOQg8pukq
	elif 'بحث M3U - ' in hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace('بحث M3U - ',aU23gVSeZ8QMl+'بحث M3U - '+aU23gVSeZ8QMl)
	elif ' M3U' in hoVitY5TylJ7GBEIZNOQg8pukq and z6zM3bBhaK=='M3U': hoVitY5TylJ7GBEIZNOQg8pukq = aU23gVSeZ8QMl+hoVitY5TylJ7GBEIZNOQg8pukq
	elif 'بحث ' in hoVitY5TylJ7GBEIZNOQg8pukq and ' - ' in hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = aU23gVSeZ8QMl+hoVitY5TylJ7GBEIZNOQg8pukq
	elif not GJkufTZPadnNs8HmM0LltV:
		oUdIphMAfwjFHEg7 = fNntYJW45mEFSdRX8g.findall('^( *?)(.*?)( *?)$',hoVitY5TylJ7GBEIZNOQg8pukq)
		TR0W8bVfAMJ7i1skm,Xq0wpSjWUZI,xJsE54kbmnXzDpMjOZVAFTHqahutY = oUdIphMAfwjFHEg7[BewrUo9ANCa17G43Sn0LH5xh]
		aaSpmIYznO5r = fNntYJW45mEFSdRX8g.findall('^([!-~])',Xq0wpSjWUZI)
		if aaSpmIYznO5r: hoVitY5TylJ7GBEIZNOQg8pukq = TR0W8bVfAMJ7i1skm+t0ozNJUhjCVgRmMp89KGaWvfl3AS+Xq0wpSjWUZI+xJsE54kbmnXzDpMjOZVAFTHqahutY
		else: hoVitY5TylJ7GBEIZNOQg8pukq = xJsE54kbmnXzDpMjOZVAFTHqahutY+aU23gVSeZ8QMl+Xq0wpSjWUZI+TR0W8bVfAMJ7i1skm
	else:
		import bidi.algorithm as KKIAFzsoVcRrT9
		if zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
			cDSAeInCZ4Q2WPo7HzgprJ = hoVitY5TylJ7GBEIZNOQg8pukq
			if qdUK5ioJyrO1T: cDSAeInCZ4Q2WPo7HzgprJ = cDSAeInCZ4Q2WPo7HzgprJ.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT,'ignore')
			Sz8nYbpOKuQ9aRo = KKIAFzsoVcRrT9.get_display(cDSAeInCZ4Q2WPo7HzgprJ,base_dir='L')
			ddoRfFPmp4Y6 = cDSAeInCZ4Q2WPo7HzgprJ.split(AAh0X3OCacr4HpifRGLZKT)
			u837FDtg51Zx9sM = Sz8nYbpOKuQ9aRo.split(AAh0X3OCacr4HpifRGLZKT)
			elDUyd2ESBkTLgFKwucCHqPvOf,ggFhfawL5Rbqs74xMtiNDHpSn3A0G,QyDOE8TMeAuBtmlbKqFjzfRU,MMoaXUdpwZ = [],[],sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
			xrI6KyQ4bNs1WV = zip(ddoRfFPmp4Y6,u837FDtg51Zx9sM)
			for VshDCtOkcomgI7l8A,Gn8VwuWEMNY0zSOf9h6 in xrI6KyQ4bNs1WV:
				if VshDCtOkcomgI7l8A==Gn8VwuWEMNY0zSOf9h6==sCHVtMAvqirbQ4BUK3cgWo and MMoaXUdpwZ:
					QyDOE8TMeAuBtmlbKqFjzfRU += AAh0X3OCacr4HpifRGLZKT
					continue
				if VshDCtOkcomgI7l8A==Gn8VwuWEMNY0zSOf9h6:
					X7Z9vq0wd2nFmopl4U18kS6ix = 'EN'
					if MMoaXUdpwZ==X7Z9vq0wd2nFmopl4U18kS6ix: QyDOE8TMeAuBtmlbKqFjzfRU += AAh0X3OCacr4HpifRGLZKT+VshDCtOkcomgI7l8A
					elif VshDCtOkcomgI7l8A:
						if QyDOE8TMeAuBtmlbKqFjzfRU:
							ggFhfawL5Rbqs74xMtiNDHpSn3A0G.append(QyDOE8TMeAuBtmlbKqFjzfRU)
							elDUyd2ESBkTLgFKwucCHqPvOf.append(sCHVtMAvqirbQ4BUK3cgWo)
						QyDOE8TMeAuBtmlbKqFjzfRU = VshDCtOkcomgI7l8A
				else:
					X7Z9vq0wd2nFmopl4U18kS6ix = 'AR'
					if MMoaXUdpwZ==X7Z9vq0wd2nFmopl4U18kS6ix: QyDOE8TMeAuBtmlbKqFjzfRU += AAh0X3OCacr4HpifRGLZKT+VshDCtOkcomgI7l8A
					elif VshDCtOkcomgI7l8A:
						if QyDOE8TMeAuBtmlbKqFjzfRU:
							elDUyd2ESBkTLgFKwucCHqPvOf.append(QyDOE8TMeAuBtmlbKqFjzfRU)
							ggFhfawL5Rbqs74xMtiNDHpSn3A0G.append(sCHVtMAvqirbQ4BUK3cgWo)
						QyDOE8TMeAuBtmlbKqFjzfRU = VshDCtOkcomgI7l8A
				MMoaXUdpwZ = X7Z9vq0wd2nFmopl4U18kS6ix
			if X7Z9vq0wd2nFmopl4U18kS6ix=='EN':
				elDUyd2ESBkTLgFKwucCHqPvOf.append(QyDOE8TMeAuBtmlbKqFjzfRU)
				ggFhfawL5Rbqs74xMtiNDHpSn3A0G.append(sCHVtMAvqirbQ4BUK3cgWo)
			else:
				ggFhfawL5Rbqs74xMtiNDHpSn3A0G.append(QyDOE8TMeAuBtmlbKqFjzfRU)
				elDUyd2ESBkTLgFKwucCHqPvOf.append(sCHVtMAvqirbQ4BUK3cgWo)
			eeRAOfiF1o = sCHVtMAvqirbQ4BUK3cgWo
			xrI6KyQ4bNs1WV = zip(elDUyd2ESBkTLgFKwucCHqPvOf,ggFhfawL5Rbqs74xMtiNDHpSn3A0G)
			import bidi.mirror as utUOIXVmq7WLRSTMwEBKgYQCvbA
			for D1L2c3v4ibpICaAKUYnGqFhkujg7x,ssHhA4JbO8 in xrI6KyQ4bNs1WV:
				if D1L2c3v4ibpICaAKUYnGqFhkujg7x: eeRAOfiF1o += AAh0X3OCacr4HpifRGLZKT+D1L2c3v4ibpICaAKUYnGqFhkujg7x
				else:
					aaSpmIYznO5r = fNntYJW45mEFSdRX8g.findall('([!-~]) *$',ssHhA4JbO8)
					if aaSpmIYznO5r:
						aaSpmIYznO5r = aaSpmIYznO5r[BewrUo9ANCa17G43Sn0LH5xh]
						try:
							ntLP3r2qQ4i8Td0WkmHsZ69KyVjR = utUOIXVmq7WLRSTMwEBKgYQCvbA.MIRRORED[aaSpmIYznO5r]
							oUdIphMAfwjFHEg7 = fNntYJW45mEFSdRX8g.findall('^( *?)(.*?)( *?)$',ssHhA4JbO8)
							if oUdIphMAfwjFHEg7: TR0W8bVfAMJ7i1skm,ssHhA4JbO8,xJsE54kbmnXzDpMjOZVAFTHqahutY = oUdIphMAfwjFHEg7[BewrUo9ANCa17G43Sn0LH5xh]
							ssHhA4JbO8 = TR0W8bVfAMJ7i1skm+ntLP3r2qQ4i8Td0WkmHsZ69KyVjR+ssHhA4JbO8[:-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]+xJsE54kbmnXzDpMjOZVAFTHqahutY
						except: pass
					eeRAOfiF1o += AAh0X3OCacr4HpifRGLZKT+ssHhA4JbO8
			hoVitY5TylJ7GBEIZNOQg8pukq = eeRAOfiF1o[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
			if qdUK5ioJyrO1T: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		else:
			if qdUK5ioJyrO1T: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			hoVitY5TylJ7GBEIZNOQg8pukq = KKIAFzsoVcRrT9.get_display(hoVitY5TylJ7GBEIZNOQg8pukq)
			cDSAeInCZ4Q2WPo7HzgprJ,Sz8nYbpOKuQ9aRo = hoVitY5TylJ7GBEIZNOQg8pukq,hoVitY5TylJ7GBEIZNOQg8pukq
			if 1:
				MMoaXUdpwZ,qUYOC7V9fW4TgmtcAx = sCHVtMAvqirbQ4BUK3cgWo,[]
				LY5qrxIAXbHWpzGM7CUPh9SVuF = hoVitY5TylJ7GBEIZNOQg8pukq.split(AAh0X3OCacr4HpifRGLZKT)
				for jQGoEi4HPVkK3svrM5Z in LY5qrxIAXbHWpzGM7CUPh9SVuF:
					if not jQGoEi4HPVkK3svrM5Z:
						if qUYOC7V9fW4TgmtcAx: qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] += AAh0X3OCacr4HpifRGLZKT
						else: qUYOC7V9fW4TgmtcAx.append(sCHVtMAvqirbQ4BUK3cgWo)
						continue
					nyRTqItz4Y2ir = fNntYJW45mEFSdRX8g.findall('[!-~]',jQGoEi4HPVkK3svrM5Z[BewrUo9ANCa17G43Sn0LH5xh])
					if nyRTqItz4Y2ir==MMoaXUdpwZ and qUYOC7V9fW4TgmtcAx: qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] += AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z
					else:
						if qUYOC7V9fW4TgmtcAx:
							LJlhN8GK7S6AY4O = fNntYJW45mEFSdRX8g.findall('[^!-~]',qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
							if LJlhN8GK7S6AY4O:
								qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = KKIAFzsoVcRrT9.get_display(qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
								Q9DAzfHTihydXcg8EKCu = fNntYJW45mEFSdRX8g.findall('^ +',qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
								if Q9DAzfHTihydXcg8EKCu: qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU].lstrip(AAh0X3OCacr4HpifRGLZKT)+Q9DAzfHTihydXcg8EKCu[BewrUo9ANCa17G43Sn0LH5xh]
						qUYOC7V9fW4TgmtcAx.append(jQGoEi4HPVkK3svrM5Z)
					MMoaXUdpwZ = nyRTqItz4Y2ir
				if qUYOC7V9fW4TgmtcAx: qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU] = KKIAFzsoVcRrT9.get_display(qUYOC7V9fW4TgmtcAx[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
				hoVitY5TylJ7GBEIZNOQg8pukq = AAh0X3OCacr4HpifRGLZKT.join(qUYOC7V9fW4TgmtcAx)
			if qdUK5ioJyrO1T: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	return hoVitY5TylJ7GBEIZNOQg8pukq
def ssl5G716uoc(B3MJcwXj9yYhz,zOsvCrVEyIn3h,XOPyKljWMvxoa95):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,NGSORQdiu6mCvWy8BelHsYK,P4Am7irq3VuCnbJINTYDHk,hzwScpHQRnB5Z,bK0LycGjJxiVCD = B3MJcwXj9yYhz
	QQ8kHjYnKEDU3sxft9S5iRoB = int(QQ8kHjYnKEDU3sxft9S5iRoB)
	LbK1Fg3YHM = fNntYJW45mEFSdRX8g.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
	if LbK1Fg3YHM:
		LbK1Fg3YHM,TuwOld95X4Jm3AfhsF7,Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0 = LbK1Fg3YHM[BewrUo9ANCa17G43Sn0LH5xh]
		hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(LbK1Fg3YHM,sCHVtMAvqirbQ4BUK3cgWo)
	bCdLizjkV34A5S = hoVitY5TylJ7GBEIZNOQg8pukq
	z6zM3bBhaK = fNntYJW45mEFSdRX8g.findall('^_(\w\w\w)_(.*?)$',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
	if z6zM3bBhaK:
		z6zM3bBhaK,hoVitY5TylJ7GBEIZNOQg8pukq = z6zM3bBhaK[BewrUo9ANCa17G43Sn0LH5xh]
		IQV5fDzu6X9qCaAS1sht = '_MOD_' in hoVitY5TylJ7GBEIZNOQg8pukq
		n0mErNiResZbqGAJBv9MD = iHPTUWrX1nbg=='folder'
		if IQV5fDzu6X9qCaAS1sht and n0mErNiResZbqGAJBv9MD: tSXdaJgy24fl = ';'
		elif IQV5fDzu6X9qCaAS1sht and not n0mErNiResZbqGAJBv9MD: tSXdaJgy24fl = zzXbKjEJ47ysUgH2LPl3dnt
		elif not IQV5fDzu6X9qCaAS1sht and n0mErNiResZbqGAJBv9MD: tSXdaJgy24fl = ','
		elif not IQV5fDzu6X9qCaAS1sht and not n0mErNiResZbqGAJBv9MD: tSXdaJgy24fl = AAh0X3OCacr4HpifRGLZKT
		hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace('_MOD_',sCHVtMAvqirbQ4BUK3cgWo)
		z6zM3bBhaK = tSXdaJgy24fl+VXWOCAE6ns3paJ8DLG479NQfMu+z6zM3bBhaK+' '+B8alA5nvIhTxQ
	else: z6zM3bBhaK = sCHVtMAvqirbQ4BUK3cgWo
	if LbK1Fg3YHM:
		if qdUK5ioJyrO1T:
			LbK1Fg3YHM = F7Fe63KbGjaz2TcmCNHPdo5QiXO+TuwOld95X4Jm3AfhsF7+AAh0X3OCacr4HpifRGLZKT+Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0+B8alA5nvIhTxQ
			if z6zM3bBhaK: hoVitY5TylJ7GBEIZNOQg8pukq = LbK1Fg3YHM+AAh0X3OCacr4HpifRGLZKT+aU23gVSeZ8QMl+z6zM3bBhaK+hoVitY5TylJ7GBEIZNOQg8pukq
			else: hoVitY5TylJ7GBEIZNOQg8pukq = LbK1Fg3YHM+aU23gVSeZ8QMl+hoVitY5TylJ7GBEIZNOQg8pukq+AAh0X3OCacr4HpifRGLZKT
		elif I5VKjrFL0Bk97:
			if z6zM3bBhaK:
				LbK1Fg3YHM = F7Fe63KbGjaz2TcmCNHPdo5QiXO+TuwOld95X4Jm3AfhsF7+AAh0X3OCacr4HpifRGLZKT+Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0+B8alA5nvIhTxQ
				hoVitY5TylJ7GBEIZNOQg8pukq = LbK1Fg3YHM+AAh0X3OCacr4HpifRGLZKT+z6zM3bBhaK+hoVitY5TylJ7GBEIZNOQg8pukq
			else:
				LbK1Fg3YHM = F7Fe63KbGjaz2TcmCNHPdo5QiXO+Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0+AAh0X3OCacr4HpifRGLZKT+TuwOld95X4Jm3AfhsF7+B8alA5nvIhTxQ
				hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq+AAh0X3OCacr4HpifRGLZKT+aU23gVSeZ8QMl+LbK1Fg3YHM
	elif z6zM3bBhaK:
		hoVitY5TylJ7GBEIZNOQg8pukq = vRKwdHChabq1uLniJX(hoVitY5TylJ7GBEIZNOQg8pukq,z6zM3bBhaK)
		hoVitY5TylJ7GBEIZNOQg8pukq = z6zM3bBhaK+hoVitY5TylJ7GBEIZNOQg8pukq
	B3MJcwXj9yYhz = iHPTUWrX1nbg,bCdLizjkV34A5S,qhWpTazQ9ws,str(QQ8kHjYnKEDU3sxft9S5iRoB),yNbi4akQM9EHO8wSlCGoJZx,NGSORQdiu6mCvWy8BelHsYK,P4Am7irq3VuCnbJINTYDHk,hzwScpHQRnB5Z,bK0LycGjJxiVCD
	nd9oaf6MJkeXYGIh7EQ = {'type':sCHVtMAvqirbQ4BUK3cgWo,'mode':sCHVtMAvqirbQ4BUK3cgWo,'url':sCHVtMAvqirbQ4BUK3cgWo,'text':sCHVtMAvqirbQ4BUK3cgWo,'page':sCHVtMAvqirbQ4BUK3cgWo,'name':sCHVtMAvqirbQ4BUK3cgWo,'image':sCHVtMAvqirbQ4BUK3cgWo,'context':sCHVtMAvqirbQ4BUK3cgWo,'infodict':sCHVtMAvqirbQ4BUK3cgWo}
	if I5VKjrFL0Bk97: bCdLizjkV34A5S = bCdLizjkV34A5S.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT,'ignore').decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	nd9oaf6MJkeXYGIh7EQ['name'] = IgCGzHw45TJ7PeuO1EKl(bCdLizjkV34A5S)
	nd9oaf6MJkeXYGIh7EQ['type'] = iHPTUWrX1nbg.strip(AAh0X3OCacr4HpifRGLZKT)
	nd9oaf6MJkeXYGIh7EQ['mode'] = str(QQ8kHjYnKEDU3sxft9S5iRoB).strip(AAh0X3OCacr4HpifRGLZKT)
	if iHPTUWrX1nbg=='folder' and NGSORQdiu6mCvWy8BelHsYK: nd9oaf6MJkeXYGIh7EQ['page'] = IgCGzHw45TJ7PeuO1EKl(NGSORQdiu6mCvWy8BelHsYK.strip(AAh0X3OCacr4HpifRGLZKT))
	if hzwScpHQRnB5Z: nd9oaf6MJkeXYGIh7EQ['context'] = hzwScpHQRnB5Z.strip(AAh0X3OCacr4HpifRGLZKT)
	if P4Am7irq3VuCnbJINTYDHk: nd9oaf6MJkeXYGIh7EQ['text'] = IgCGzHw45TJ7PeuO1EKl(P4Am7irq3VuCnbJINTYDHk.strip(AAh0X3OCacr4HpifRGLZKT))
	if yNbi4akQM9EHO8wSlCGoJZx: nd9oaf6MJkeXYGIh7EQ['image'] = IgCGzHw45TJ7PeuO1EKl(yNbi4akQM9EHO8wSlCGoJZx.strip(AAh0X3OCacr4HpifRGLZKT))
	if bK0LycGjJxiVCD:
		bK0LycGjJxiVCD = str(bK0LycGjJxiVCD)
		nd9oaf6MJkeXYGIh7EQ['infodict'] = IgCGzHw45TJ7PeuO1EKl(bK0LycGjJxiVCD.strip(AAh0X3OCacr4HpifRGLZKT))
		bK0LycGjJxiVCD = eval(bK0LycGjJxiVCD)
	else: bK0LycGjJxiVCD = {}
	if qhWpTazQ9ws: nd9oaf6MJkeXYGIh7EQ['url'] = IgCGzHw45TJ7PeuO1EKl(qhWpTazQ9ws.strip(AAh0X3OCacr4HpifRGLZKT))
	jWLQGzOihpd = {'name':sCHVtMAvqirbQ4BUK3cgWo,'context_menu':sCHVtMAvqirbQ4BUK3cgWo,'plot':sCHVtMAvqirbQ4BUK3cgWo,'stars':sCHVtMAvqirbQ4BUK3cgWo,'image':sCHVtMAvqirbQ4BUK3cgWo,'type':sCHVtMAvqirbQ4BUK3cgWo,'isFolder':sCHVtMAvqirbQ4BUK3cgWo,'newpath':sCHVtMAvqirbQ4BUK3cgWo,'duration':sCHVtMAvqirbQ4BUK3cgWo}
	Ub7ksGAtFdrOev04 = []
	noSRFcJ8VzQLeYwHDC9xNrX1 = 'plugin://'+Xkp839QMmYzrsoWTyca+'/?type='+nd9oaf6MJkeXYGIh7EQ['type']+'&mode='+nd9oaf6MJkeXYGIh7EQ['mode']
	if nd9oaf6MJkeXYGIh7EQ['page']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&page='+nd9oaf6MJkeXYGIh7EQ['page']
	if nd9oaf6MJkeXYGIh7EQ['name']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&name='+nd9oaf6MJkeXYGIh7EQ['name']
	if nd9oaf6MJkeXYGIh7EQ['text']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&text='+nd9oaf6MJkeXYGIh7EQ['text']
	if nd9oaf6MJkeXYGIh7EQ['infodict']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&infodict='+nd9oaf6MJkeXYGIh7EQ['infodict']
	if nd9oaf6MJkeXYGIh7EQ['image']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&image='+nd9oaf6MJkeXYGIh7EQ['image']
	if nd9oaf6MJkeXYGIh7EQ['url']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&url='+nd9oaf6MJkeXYGIh7EQ['url']
	if QQ8kHjYnKEDU3sxft9S5iRoB not in [265,533]: jWLQGzOihpd['favorites'] = ndkUxG9LtewJ
	else: jWLQGzOihpd['favorites'] = lvzrYTpcBaK
	if nd9oaf6MJkeXYGIh7EQ['context']: noSRFcJ8VzQLeYwHDC9xNrX1 += '&context='+nd9oaf6MJkeXYGIh7EQ['context']
	if QQ8kHjYnKEDU3sxft9S5iRoB in [235,238] and iHPTUWrX1nbg=='live' and 'EPG' in hzwScpHQRnB5Z:
		ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?mode=238&text=SHORT_EPG&url='+qhWpTazQ9ws
		Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'البرامج القادمة'+B8alA5nvIhTxQ
		MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
		Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if QQ8kHjYnKEDU3sxft9S5iRoB==265:
		dxGQUo7NmTRhBXkOEs = zOsvCrVEyIn3h(P4Am7irq3VuCnbJINTYDHk,ndkUxG9LtewJ)
		if dxGQUo7NmTRhBXkOEs>BewrUo9ANCa17G43Sn0LH5xh:
			ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?mode=266&text='+P4Am7irq3VuCnbJINTYDHk
			Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'مسح قائمة آخر 50 '+g7k6hjSBrX4oOElJW59c2bUZpMquw(P4Am7irq3VuCnbJINTYDHk)+B8alA5nvIhTxQ
			MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
			Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if iHPTUWrX1nbg=='video' and QQ8kHjYnKEDU3sxft9S5iRoB!=331:
		ppGZYbou4v2DRK9BSMJgFfwhI = noSRFcJ8VzQLeYwHDC9xNrX1+'&context=6_DOWNLOAD'
		Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'تحميل ملف الفيديو'+B8alA5nvIhTxQ
		MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
		Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if QQ8kHjYnKEDU3sxft9S5iRoB==331:
		ppGZYbou4v2DRK9BSMJgFfwhI = noSRFcJ8VzQLeYwHDC9xNrX1+'&context=6_DELETE'
		Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'حذف ملف الفيديو'+B8alA5nvIhTxQ
		MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
		Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if iHPTUWrX1nbg=='folder' and QQ8kHjYnKEDU3sxft9S5iRoB==540:
		wkfu2FmOZsh4JniNY3q = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_SPLITTED_ALL')
		if wkfu2FmOZsh4JniNY3q:
			ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?context=7'
			Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'مسح كلمات بحث المواقع'+B8alA5nvIhTxQ
			MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
			Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if iHPTUWrX1nbg=='folder' and QQ8kHjYnKEDU3sxft9S5iRoB==1010:
		wkfu2FmOZsh4JniNY3q = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if wkfu2FmOZsh4JniNY3q:
			ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?context=10'
			Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'مسح كلمات بحث جوجل'+B8alA5nvIhTxQ
			MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
			Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	onOPfuKQsIh4iNgVHLwz3xta9eT8p = [9990,9999,rgpY5VUqKbeFOCD9Nki2SmGvxEja,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,536,537,538,540,710,719,761,762,1010,1022,1101,1103]
	if QQ8kHjYnKEDU3sxft9S5iRoB not in onOPfuKQsIh4iNgVHLwz3xta9eT8p:
		ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?context=8&mode=260'
		Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'القائمة الرئيسية'+B8alA5nvIhTxQ
		MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
		Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	nncWt8Rzbd = QQ8kHjYnKEDU3sxft9S5iRoB-QQ8kHjYnKEDU3sxft9S5iRoB%10
	if QQ8kHjYnKEDU3sxft9S5iRoB%10:
		if nncWt8Rzbd==280: nncWt8Rzbd = 230
		if nncWt8Rzbd==410: nncWt8Rzbd = 400
		if nncWt8Rzbd==520: nncWt8Rzbd = 510
		if nncWt8Rzbd not in QjhUnOyxC3YtGv7gSbPlwazB2o1MA8:
			ppGZYbou4v2DRK9BSMJgFfwhI = 'plugin://'+Xkp839QMmYzrsoWTyca+'?context=8&mode='+str(nncWt8Rzbd)
			Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'قائمة الموقع'+B8alA5nvIhTxQ
			MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
			Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	ppGZYbou4v2DRK9BSMJgFfwhI = noSRFcJ8VzQLeYwHDC9xNrX1+'&context=9'
	Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'تحديث القائمة'+B8alA5nvIhTxQ
	MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
	Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if iHPTUWrX1nbg in ['video','live']:
		ppGZYbou4v2DRK9BSMJgFfwhI = noSRFcJ8VzQLeYwHDC9xNrX1+'&context=18'
		Yj35fOV4A6brQTlL = F7Fe63KbGjaz2TcmCNHPdo5QiXO+'إظهار قوائم الجودة'+B8alA5nvIhTxQ
		MQcPNVpGCnF8735j = (Yj35fOV4A6brQTlL,'RunPlugin('+ppGZYbou4v2DRK9BSMJgFfwhI+')')
		Ub7ksGAtFdrOev04.append(MQcPNVpGCnF8735j)
	if iHPTUWrX1nbg in ['link','video','live']: bOJorWRfsekl0 = lvzrYTpcBaK
	elif iHPTUWrX1nbg=='folder': bOJorWRfsekl0 = ndkUxG9LtewJ
	jWLQGzOihpd['name'] = hoVitY5TylJ7GBEIZNOQg8pukq
	jWLQGzOihpd['context_menu'] = Ub7ksGAtFdrOev04
	if 'plot' in list(bK0LycGjJxiVCD.keys()): jWLQGzOihpd['plot'] = bK0LycGjJxiVCD['plot']
	if 'stars' in list(bK0LycGjJxiVCD.keys()): jWLQGzOihpd['stars'] = bK0LycGjJxiVCD['stars']
	if yNbi4akQM9EHO8wSlCGoJZx: jWLQGzOihpd['image'] = yNbi4akQM9EHO8wSlCGoJZx
	if iHPTUWrX1nbg=='video' and NGSORQdiu6mCvWy8BelHsYK:
		OjyQrecApZ8 = fNntYJW45mEFSdRX8g.findall('[\d:]+',NGSORQdiu6mCvWy8BelHsYK,fNntYJW45mEFSdRX8g.DOTALL)
		if OjyQrecApZ8:
			OjyQrecApZ8 = '0:0:0:0:0:'+OjyQrecApZ8[BewrUo9ANCa17G43Sn0LH5xh]
			FFvbXzryi3TRG5wEM6t9SD,L1LkQ6SyMjBKaurPcwGdh,lRIDwWVCuZML,ggjkhQVlNdmnPR8,Ev5Rdbw2c8oOp0 = OjyQrecApZ8.rsplit(':',kK7gj9HE462hADJbvr)
			sWFNnd7rSULkilBJAv2 = int(L1LkQ6SyMjBKaurPcwGdh)*24*YYAdZjDy5erLEOa3Vh02Ux+int(lRIDwWVCuZML)*YYAdZjDy5erLEOa3Vh02Ux+int(ggjkhQVlNdmnPR8)*60+int(Ev5Rdbw2c8oOp0)
			jWLQGzOihpd['duration'] = sWFNnd7rSULkilBJAv2
	jWLQGzOihpd['type'] = iHPTUWrX1nbg
	jWLQGzOihpd['isFolder'] = bOJorWRfsekl0
	jWLQGzOihpd['newpath'] = noSRFcJ8VzQLeYwHDC9xNrX1
	jWLQGzOihpd['menuItem'] = B3MJcwXj9yYhz
	jWLQGzOihpd['mode'] = QQ8kHjYnKEDU3sxft9S5iRoB
	return jWLQGzOihpd
def QLDTHI1XbtJ9qPBad2rG5zYxOmEf(zOsvCrVEyIn3h):
	VG1gpb0kOQhPzEuMFjdUA,wrvU1Ey2cBPqOW5QRJpdDt = [],sCHVtMAvqirbQ4BUK3cgWo
	from gRQYBo5zxp import MMsJqwRifEADm1P879,aQjwYZ6HEpTSActsI5Wl
	XOPyKljWMvxoa95 = MMsJqwRifEADm1P879()
	VCYw96jJq4Gk = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.status.refresh')
	if ERbOfw2FjKUAZGo and (not VCYw96jJq4Gk or VCYw96jJq4Gk=='REFRESH_CACHE'): VCYw96jJq4Gk = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'str','FOLDERS_SORT',ERbOfw2FjKUAZGo)
	if VCYw96jJq4Gk:
		if   '_PERM' in VCYw96jJq4Gk: wrvU1Ey2cBPqOW5QRJpdDt = 'دائمي'
		elif '_TEMP' in VCYw96jJq4Gk: wrvU1Ey2cBPqOW5QRJpdDt = 'مؤقت'
		if   '_REVERSED_' in VCYw96jJq4Gk: XXqGLnKo8vWYh1IMz9C0 = 'عكسي' ; Q1siCkTZyw.menuItemsLIST[:] = reversed(Q1siCkTZyw.menuItemsLIST)
		elif '_ASCENDED_' in VCYw96jJq4Gk: XXqGLnKo8vWYh1IMz9C0 = 'تصاعدي' ; Q1siCkTZyw.menuItemsLIST[:] = sorted(Q1siCkTZyw.menuItemsLIST,reverse=lvzrYTpcBaK,key=lambda key:key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
		elif '_DESCENDED_' in VCYw96jJq4Gk: XXqGLnKo8vWYh1IMz9C0 = 'تنازلي' ; Q1siCkTZyw.menuItemsLIST[:] = sorted(Q1siCkTZyw.menuItemsLIST,reverse=ndkUxG9LtewJ,key=lambda key:key[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU])
		elif '_RANDOMIZED_' in VCYw96jJq4Gk: XXqGLnKo8vWYh1IMz9C0 = 'عشوائي' ; VXOZgPsjrQ4Y7UtlRNGAp2aeIW0hC.shuffle(Q1siCkTZyw.menuItemsLIST)
	name = 'ترتيب '+XXqGLnKo8vWYh1IMz9C0+AAh0X3OCacr4HpifRGLZKT+wrvU1Ey2cBPqOW5QRJpdDt if wrvU1Ey2cBPqOW5QRJpdDt else 'بدون ترتيب (أصلي)'
	name = F7Fe63KbGjaz2TcmCNHPdo5QiXO+name+B8alA5nvIhTxQ
	if VCYw96jJq4Gk in ZZmTYCnwygl3aXzbA2EJ9: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.status.refresh',sCHVtMAvqirbQ4BUK3cgWo)
	ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	QQ8kHjYnKEDU3sxft9S5iRoB = int(GLrDUZJWtdSzaoeQNfw)
	nncWt8Rzbd = QQ8kHjYnKEDU3sxft9S5iRoB-QQ8kHjYnKEDU3sxft9S5iRoB%10
	if QQ8kHjYnKEDU3sxft9S5iRoB%10 and nncWt8Rzbd not in QjhUnOyxC3YtGv7gSbPlwazB2o1MA8 and len(Q1siCkTZyw.menuItemsLIST)>1:
		Q1siCkTZyw.menuItemsLIST[:] = [('link',name,'',533,'','',ERbOfw2FjKUAZGo,'','')]+Q1siCkTZyw.menuItemsLIST
	for B3MJcwXj9yYhz in Q1siCkTZyw.menuItemsLIST:
		jWLQGzOihpd = ssl5G716uoc(B3MJcwXj9yYhz,zOsvCrVEyIn3h,XOPyKljWMvxoa95)
		if jWLQGzOihpd['favorites']:
			YYrhyHTVLUkAnBFjNKlg5Wz8tx = aQjwYZ6HEpTSActsI5Wl(XOPyKljWMvxoa95,jWLQGzOihpd['menuItem'],jWLQGzOihpd['newpath'])
			jWLQGzOihpd['context_menu'] = YYrhyHTVLUkAnBFjNKlg5Wz8tx+jWLQGzOihpd['context_menu']
		VG1gpb0kOQhPzEuMFjdUA.append(jWLQGzOihpd)
	V3JeOCaoXifQdFPkcq6pmR = lvzrYTpcBaK if '_TEMP' in VCYw96jJq4Gk else ndkUxG9LtewJ
	return VG1gpb0kOQhPzEuMFjdUA,V3JeOCaoXifQdFPkcq6pmR
def lF7pGXVQe2RwUrWdy6TIijDzuEc9S(PCS2siEhbL):
	tSXdaJgy24fl,GM9dJS6TFsUHapqnmljX, = [],sCHVtMAvqirbQ4BUK3cgWo
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		if not QXeuCy5v3cK4qEVBLzPabFUlAfGN0m: tSXdaJgy24fl.append(sCHVtMAvqirbQ4BUK3cgWo)
		else: break
	PCS2siEhbL = PCS2siEhbL[len(tSXdaJgy24fl):]
	T67f3LG49xpP8zcN = '\n\n\n\n'.join(PCS2siEhbL)
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('===== ===== =====','000001')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(VXWOCAE6ns3paJ8DLG479NQfMu,'000002')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,'000003')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(B8alA5nvIhTxQ,'000004')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RIGHT]','000005')
	eC9s1fQEKDF4jnw0zVPrJ3db = 100000
	SKeBVoWyYwrcHIFXiPUdMbz8 = {}
	NmVIlkUJwESYMQK0tZj7Xs = fNntYJW45mEFSdRX8g.findall('http.*?[\r\n ]',T67f3LG49xpP8zcN,fNntYJW45mEFSdRX8g.DOTALL)
	for pJVlG0jiInRwbECfroHdk9cQ6F in NmVIlkUJwESYMQK0tZj7Xs:
		eC9s1fQEKDF4jnw0zVPrJ3db += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(pJVlG0jiInRwbECfroHdk9cQ6F,str(eC9s1fQEKDF4jnw0zVPrJ3db))
		SKeBVoWyYwrcHIFXiPUdMbz8[str(eC9s1fQEKDF4jnw0zVPrJ3db)] = pJVlG0jiInRwbECfroHdk9cQ6F
	for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(BewrUo9ANCa17G43Sn0LH5xh,len(T67f3LG49xpP8zcN),4800):
		tg5rM7qp6NHTuKChDWL = T67f3LG49xpP8zcN[qT1ZRz0VMiXQhxFUPdJC2u9asvrN:qT1ZRz0VMiXQhxFUPdJC2u9asvrN+4800]
		vr6aJ5xiRcd1GUpQOqHgC4EwLBu = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
		qhWpTazQ9ws = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+vr6aJ5xiRcd1GUpQOqHgC4EwLBu
		f6cPGkTodE = {'Content-Type':'text/plain'}
		Gbi1Lkq3Uraty0fVK2lQuzNoYgv = tg5rM7qp6NHTuKChDWL.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'POST',qhWpTazQ9ws,Gbi1Lkq3Uraty0fVK2lQuzNoYgv,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if qg3X0dy7CDRQmIGvk.succeeded:
			BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
			UnD36RdxX5JKE = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',BJ0mjN2OU8)
			if UnD36RdxX5JKE:
				UnD36RdxX5JKE = UnD36RdxX5JKE['translation']
				UnD36RdxX5JKE = EEH4kBfGY0FuZUjeNn(UnD36RdxX5JKE)
				for k4k13tbwsvEyH6 in range(len(UnD36RdxX5JKE)):
					GM9dJS6TFsUHapqnmljX += UnD36RdxX5JKE[k4k13tbwsvEyH6][BewrUo9ANCa17G43Sn0LH5xh]
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000001','===== ===== =====')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000002',VXWOCAE6ns3paJ8DLG479NQfMu)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000003',F7Fe63KbGjaz2TcmCNHPdo5QiXO)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000004',B8alA5nvIhTxQ)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000005','[RIGHT]')
	for eC9s1fQEKDF4jnw0zVPrJ3db in list(SKeBVoWyYwrcHIFXiPUdMbz8.keys()):
		pJVlG0jiInRwbECfroHdk9cQ6F = SKeBVoWyYwrcHIFXiPUdMbz8[eC9s1fQEKDF4jnw0zVPrJ3db]
		GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace(eC9s1fQEKDF4jnw0zVPrJ3db,pJVlG0jiInRwbECfroHdk9cQ6F)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.split('\n\n\n\n')
	return tSXdaJgy24fl+GM9dJS6TFsUHapqnmljX
def po1WiTrKqYBaO2gRdxuJNySAUwV(PCS2siEhbL):
	tSXdaJgy24fl,GM9dJS6TFsUHapqnmljX, = [],sCHVtMAvqirbQ4BUK3cgWo
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		if not QXeuCy5v3cK4qEVBLzPabFUlAfGN0m: tSXdaJgy24fl.append(sCHVtMAvqirbQ4BUK3cgWo)
		else: break
	PCS2siEhbL = PCS2siEhbL[len(tSXdaJgy24fl):]
	T67f3LG49xpP8zcN = '\\n\\n\\n\\n'.join(PCS2siEhbL)
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('كلا','no')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('استمرار','continue')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('===== ===== =====','000001')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(VXWOCAE6ns3paJ8DLG479NQfMu,'000002')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,'000003')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(B8alA5nvIhTxQ,'000004')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RIGHT]','000005')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[CENTER]','000006')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RTL]','000007')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace("'","\\\\\\'")
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('"','\\\\\\"')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(slFfrUIWCowaBA7tce3iZbj8xn,'\\n')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(f6fsIXQonhvcGg1p,'\\\\r')
	for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(BewrUo9ANCa17G43Sn0LH5xh,len(T67f3LG49xpP8zcN),4800):
		tg5rM7qp6NHTuKChDWL = T67f3LG49xpP8zcN[qT1ZRz0VMiXQhxFUPdJC2u9asvrN:qT1ZRz0VMiXQhxFUPdJC2u9asvrN+4800]
		qhWpTazQ9ws = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		f6cPGkTodE = {'Content-Type':'application/x-www-form-urlencoded'}
		vr6aJ5xiRcd1GUpQOqHgC4EwLBu = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
		Gbi1Lkq3Uraty0fVK2lQuzNoYgv = 'f.req='+IgCGzHw45TJ7PeuO1EKl('[[["MkEWBc","[[\\"'+tg5rM7qp6NHTuKChDWL+'\\",\\"ar\\",\\"'+vr6aJ5xiRcd1GUpQOqHgC4EwLBu+'\\",1],[]]",null,"generic"]]]',sCHVtMAvqirbQ4BUK3cgWo)
		Gbi1Lkq3Uraty0fVK2lQuzNoYgv = Gbi1Lkq3Uraty0fVK2lQuzNoYgv.replace('%5Cn','%5C%5Cn')
		qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'POST',qhWpTazQ9ws,Gbi1Lkq3Uraty0fVK2lQuzNoYgv,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if qg3X0dy7CDRQmIGvk.succeeded:
			BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
			BJ0mjN2OU8 = BJ0mjN2OU8.split(slFfrUIWCowaBA7tce3iZbj8xn)[-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			UnD36RdxX5JKE = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',BJ0mjN2OU8)[BewrUo9ANCa17G43Sn0LH5xh][rgpY5VUqKbeFOCD9Nki2SmGvxEja]
			if UnD36RdxX5JKE:
				UnD36RdxX5JKE = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('str',UnD36RdxX5JKE)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU][BewrUo9ANCa17G43Sn0LH5xh][BewrUo9ANCa17G43Sn0LH5xh][tBMCpcY2vUV1dEjZ7PDG]
				UnD36RdxX5JKE = EEH4kBfGY0FuZUjeNn(UnD36RdxX5JKE)
				for k4k13tbwsvEyH6 in range(len(UnD36RdxX5JKE)):
					GM9dJS6TFsUHapqnmljX += UnD36RdxX5JKE[k4k13tbwsvEyH6][BewrUo9ANCa17G43Sn0LH5xh]
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('00000','0000').replace('0000','000')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0001','===== ===== =====')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0002',VXWOCAE6ns3paJ8DLG479NQfMu)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0003',F7Fe63KbGjaz2TcmCNHPdo5QiXO)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0004',B8alA5nvIhTxQ)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0005','[RIGHT]')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0006','[CENTER]')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0007','[RTL]')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.split('\n\n\n\n')
	return tSXdaJgy24fl+GM9dJS6TFsUHapqnmljX
def U8ifFJdlO29YzKA(PCS2siEhbL):
	tSXdaJgy24fl,vh7os5Ln9W3tB48mGbAgrj = [],[]
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		if not QXeuCy5v3cK4qEVBLzPabFUlAfGN0m: tSXdaJgy24fl.append(sCHVtMAvqirbQ4BUK3cgWo)
		else: break
	PCS2siEhbL = PCS2siEhbL[len(tSXdaJgy24fl):]
	T67f3LG49xpP8zcN = '\n\n\n\n'.join(PCS2siEhbL)
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('كلا','no')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('استمرار','continue')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('أدناه','below')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(VXWOCAE6ns3paJ8DLG479NQfMu,'00001')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,'00002')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(B8alA5nvIhTxQ,'00003')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('=====','00004')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(',','00005')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RTL]','00009')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[CENTER]','0000A')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(f6fsIXQonhvcGg1p,'0000B')
	PCS2siEhbL = T67f3LG49xpP8zcN.split(slFfrUIWCowaBA7tce3iZbj8xn)
	T67f3LG49xpP8zcN,GM9dJS6TFsUHapqnmljX = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
		if len(T67f3LG49xpP8zcN+QXeuCy5v3cK4qEVBLzPabFUlAfGN0m)<1800: T67f3LG49xpP8zcN += slFfrUIWCowaBA7tce3iZbj8xn+QXeuCy5v3cK4qEVBLzPabFUlAfGN0m
		else:
			vh7os5Ln9W3tB48mGbAgrj.append(T67f3LG49xpP8zcN)
			T67f3LG49xpP8zcN = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m
	vh7os5Ln9W3tB48mGbAgrj.append(T67f3LG49xpP8zcN)
	for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in vh7os5Ln9W3tB48mGbAgrj:
		f6cPGkTodE = {'Content-Type':'application/json','User-Agent':sCHVtMAvqirbQ4BUK3cgWo}
		qhWpTazQ9ws = 'https://api.reverso.net/translate/v1/translation'
		vr6aJ5xiRcd1GUpQOqHgC4EwLBu = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
		Gbi1Lkq3Uraty0fVK2lQuzNoYgv = {"format":"text","from":"ara","to":vr6aJ5xiRcd1GUpQOqHgC4EwLBu,"input":QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,"options":{"sentenceSplitter":ndkUxG9LtewJ,"origin":"translation.web","contextResults":lvzrYTpcBaK,"languageDetection":lvzrYTpcBaK}}
		Gbi1Lkq3Uraty0fVK2lQuzNoYgv = Kdnrl9JHV0cFaGzC5bN.dumps(Gbi1Lkq3Uraty0fVK2lQuzNoYgv)
		qg3X0dy7CDRQmIGvk = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'POST',qhWpTazQ9ws,Gbi1Lkq3Uraty0fVK2lQuzNoYgv,f6cPGkTodE,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'LIBRARY-REVERSO_TRANSLATE-1st')
		if qg3X0dy7CDRQmIGvk.succeeded:
			BJ0mjN2OU8 = qg3X0dy7CDRQmIGvk.content
			BJ0mjN2OU8 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',BJ0mjN2OU8)
			GM9dJS6TFsUHapqnmljX += slFfrUIWCowaBA7tce3iZbj8xn+sCHVtMAvqirbQ4BUK3cgWo.join(BJ0mjN2OU8['translation'])
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX[rgpY5VUqKbeFOCD9Nki2SmGvxEja:]
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000000','00000').replace('00000','0000').replace('0000','000')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0001',VXWOCAE6ns3paJ8DLG479NQfMu)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0002',F7Fe63KbGjaz2TcmCNHPdo5QiXO)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0003',B8alA5nvIhTxQ)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0004','=====')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0005',',')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('0009','[RTL]')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000A','[CENTER]')
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.replace('000B',f6fsIXQonhvcGg1p)
	GM9dJS6TFsUHapqnmljX = GM9dJS6TFsUHapqnmljX.split('\n\n\n\n')
	return tSXdaJgy24fl+GM9dJS6TFsUHapqnmljX
def J7YQHOxiBW0SrcXCwaN5dmf2ZRAKp(PCS2siEhbL):
	lnd8TJjXS4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.translate')
	if not lnd8TJjXS4 or not PCS2siEhbL: return PCS2siEhbL
	VVwQgNjJAehI2KSPLs4Y60B = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.provider')
	vr6aJ5xiRcd1GUpQOqHgC4EwLBu = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
	nvdcQ0N81aBuVwW = vr6aJ5xiRcd1GUpQOqHgC4EwLBu+'__'+str(PCS2siEhbL)
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.language.translate',sCHVtMAvqirbQ4BUK3cgWo)
	GM9dJS6TFsUHapqnmljX = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','TRANSLATE_'+VVwQgNjJAehI2KSPLs4Y60B,nvdcQ0N81aBuVwW)
	if not GM9dJS6TFsUHapqnmljX:
		if VVwQgNjJAehI2KSPLs4Y60B=='GOOGLE': GM9dJS6TFsUHapqnmljX = po1WiTrKqYBaO2gRdxuJNySAUwV(PCS2siEhbL)
		elif VVwQgNjJAehI2KSPLs4Y60B=='REVERSO': GM9dJS6TFsUHapqnmljX = U8ifFJdlO29YzKA(PCS2siEhbL)
		elif VVwQgNjJAehI2KSPLs4Y60B=='GLOSBE': GM9dJS6TFsUHapqnmljX = lF7pGXVQe2RwUrWdy6TIijDzuEc9S(PCS2siEhbL)
		if len(PCS2siEhbL)==len(GM9dJS6TFsUHapqnmljX):
			kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'TRANSLATE_'+VVwQgNjJAehI2KSPLs4Y60B,nvdcQ0N81aBuVwW,GM9dJS6TFsUHapqnmljX,gQtzWRX97wZHiJ)
		else:
			GM9dJS6TFsUHapqnmljX = PCS2siEhbL
			iRaHzNpJhSx6ZnCfrvD7j93lks('الترجمة فشلت','Translation Failed')
	fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.language.translate','1')
	return GM9dJS6TFsUHapqnmljX
def rfyFvhxA94H(B3MJcwXj9yYhz,VG1gpb0kOQhPzEuMFjdUA,mO0jXV8KQFIGyCvSBWkDq2uo5flR,NGMHUZz3IiA0WaVlc,Ugv9tp41iZ8G7OSenfbQ):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD = B3MJcwXj9yYhz
	OWdKQDByFxChM = []
	lnd8TJjXS4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.translate')
	if lnd8TJjXS4:
		ZFnCLgvpIyszujeQAHNKwTt,niu8mCtaGZV,DD70VXZChy69dqKAPJmcTGswWptu = [],[],[]
		if not OWdKQDByFxChM:
			for jWLQGzOihpd in VG1gpb0kOQhPzEuMFjdUA:
				hoVitY5TylJ7GBEIZNOQg8pukq = jWLQGzOihpd['name'].replace(aU23gVSeZ8QMl,sCHVtMAvqirbQ4BUK3cgWo).replace(t0ozNJUhjCVgRmMp89KGaWvfl3AS,sCHVtMAvqirbQ4BUK3cgWo)
				LbK1Fg3YHM = fNntYJW45mEFSdRX8g.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
				if LbK1Fg3YHM:
					tSXdaJgy24fl,TuwOld95X4Jm3AfhsF7,Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0,HHATo0NhxR7mabDcgYBvX,hoVitY5TylJ7GBEIZNOQg8pukq = LbK1Fg3YHM[BewrUo9ANCa17G43Sn0LH5xh]
					LbK1Fg3YHM = tSXdaJgy24fl+TuwOld95X4Jm3AfhsF7+AAh0X3OCacr4HpifRGLZKT+Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0+HHATo0NhxR7mabDcgYBvX+AAh0X3OCacr4HpifRGLZKT
				else:
					LbK1Fg3YHM = fNntYJW45mEFSdRX8g.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
					if LbK1Fg3YHM:
						hoVitY5TylJ7GBEIZNOQg8pukq,tSXdaJgy24fl,Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0,TuwOld95X4Jm3AfhsF7,HHATo0NhxR7mabDcgYBvX = LbK1Fg3YHM[BewrUo9ANCa17G43Sn0LH5xh]
						LbK1Fg3YHM = tSXdaJgy24fl+TuwOld95X4Jm3AfhsF7+AAh0X3OCacr4HpifRGLZKT+Juao3UM5g6Cj1Pzi7BT8fv2mXZRbK0+HHATo0NhxR7mabDcgYBvX+AAh0X3OCacr4HpifRGLZKT
					else: LbK1Fg3YHM = sCHVtMAvqirbQ4BUK3cgWo
				z6zM3bBhaK = fNntYJW45mEFSdRX8g.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
				if z6zM3bBhaK: z6zM3bBhaK,hoVitY5TylJ7GBEIZNOQg8pukq = z6zM3bBhaK[BewrUo9ANCa17G43Sn0LH5xh]
				else: z6zM3bBhaK = sCHVtMAvqirbQ4BUK3cgWo
				ZFnCLgvpIyszujeQAHNKwTt.append(LbK1Fg3YHM+z6zM3bBhaK)
				niu8mCtaGZV.append(hoVitY5TylJ7GBEIZNOQg8pukq)
			DD70VXZChy69dqKAPJmcTGswWptu = J7YQHOxiBW0SrcXCwaN5dmf2ZRAKp(niu8mCtaGZV)
			if DD70VXZChy69dqKAPJmcTGswWptu:
				for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(len(VG1gpb0kOQhPzEuMFjdUA)):
					jWLQGzOihpd = VG1gpb0kOQhPzEuMFjdUA[qT1ZRz0VMiXQhxFUPdJC2u9asvrN]
					jWLQGzOihpd['name'] = ZFnCLgvpIyszujeQAHNKwTt[qT1ZRz0VMiXQhxFUPdJC2u9asvrN]+DD70VXZChy69dqKAPJmcTGswWptu[qT1ZRz0VMiXQhxFUPdJC2u9asvrN]
					OWdKQDByFxChM.append(jWLQGzOihpd)
	if OWdKQDByFxChM: VG1gpb0kOQhPzEuMFjdUA = OWdKQDByFxChM
	EG6ekSP9XApyzOFQlg5q4d8ju,rezGQkyOENmgIP,ggPNKmUbkfZjo7qzWV2SI3 = [],BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
	z814KylixXbRPSM0cV = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.status.menusimages')
	a3bgPVJhG7siKrHx0DClAEzLTeNW6 = z814KylixXbRPSM0cV!='STOP'
	viz9YdUHoZSt = []
	if a3bgPVJhG7siKrHx0DClAEzLTeNW6:
		PP0Fx2UclCidVKMOo78ewI6pfar4Tk = YYEXZsUWhf52vz7HLxc0qGJ.path.join(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,QQ8kHjYnKEDU3sxft9S5iRoB)
		try: viz9YdUHoZSt = YYEXZsUWhf52vz7HLxc0qGJ.listdir(PP0Fx2UclCidVKMOo78ewI6pfar4Tk)
		except:
			if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(PP0Fx2UclCidVKMOo78ewI6pfar4Tk):
				try: YYEXZsUWhf52vz7HLxc0qGJ.makedirs(PP0Fx2UclCidVKMOo78ewI6pfar4Tk)
				except: pass
	EuKx6eflvsTz2Fct3nmGrYqZ = e756M1PWwU('menu_item')
	RXPvpF1CmVfG = viz9YdUHoZSt
	if qdUK5ioJyrO1T and xlOFiKpdTI1Vjw5YN.platform=='win32':
		RXPvpF1CmVfG = []
		for kzfJ52qLPICs30OY in viz9YdUHoZSt:
			kzfJ52qLPICs30OY = kzfJ52qLPICs30OY.decode(c3dXNBfyhSZCow1ia0RjVWUOg9).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			RXPvpF1CmVfG.append(kzfJ52qLPICs30OY)
	for jWLQGzOihpd in VG1gpb0kOQhPzEuMFjdUA:
		hoVitY5TylJ7GBEIZNOQg8pukq = jWLQGzOihpd['name']
		if I5VKjrFL0Bk97: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT,'ignore').decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		Ub7ksGAtFdrOev04 = jWLQGzOihpd['context_menu']
		tthL9Y1i53HOjJCsPnqN2b8BFWS = jWLQGzOihpd['plot']
		nnpDmYPl9Rt5geOJ = jWLQGzOihpd['stars']
		yNbi4akQM9EHO8wSlCGoJZx = jWLQGzOihpd['image']
		iHPTUWrX1nbg = jWLQGzOihpd['type']
		OjyQrecApZ8 = jWLQGzOihpd['duration']
		bOJorWRfsekl0 = jWLQGzOihpd['isFolder']
		noSRFcJ8VzQLeYwHDC9xNrX1 = jWLQGzOihpd['newpath']
		LLeE2A6ltBpWU7TykZYmO = qqtbjl02E5pUOdQ1yMn8xABJsVG67w.ListItem(hoVitY5TylJ7GBEIZNOQg8pukq)
		LLeE2A6ltBpWU7TykZYmO.addContextMenuItems(Ub7ksGAtFdrOev04)
		gnUHS3KvABuzfiIProOlJRm = lvzrYTpcBaK if a3bgPVJhG7siKrHx0DClAEzLTeNW6 else ndkUxG9LtewJ
		if yNbi4akQM9EHO8wSlCGoJZx:
			LLeE2A6ltBpWU7TykZYmO.setArt({'icon':yNbi4akQM9EHO8wSlCGoJZx,'thumb':yNbi4akQM9EHO8wSlCGoJZx,'fanart':yNbi4akQM9EHO8wSlCGoJZx,'banner':yNbi4akQM9EHO8wSlCGoJZx,'clearart':yNbi4akQM9EHO8wSlCGoJZx,'poster':yNbi4akQM9EHO8wSlCGoJZx,'clearlogo':yNbi4akQM9EHO8wSlCGoJZx,'landscape':yNbi4akQM9EHO8wSlCGoJZx})
			gnUHS3KvABuzfiIProOlJRm = lvzrYTpcBaK
		elif not gnUHS3KvABuzfiIProOlJRm:
			gnUHS3KvABuzfiIProOlJRm = ndkUxG9LtewJ
			hoVitY5TylJ7GBEIZNOQg8pukq = qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(lvzrYTpcBaK,hoVitY5TylJ7GBEIZNOQg8pukq)
			hoVitY5TylJ7GBEIZNOQg8pukq = ij3WwceDrmqafJy6Lsx4S9GCFuP(hoVitY5TylJ7GBEIZNOQg8pukq)
			FHrYRshzUvxmq31NA5TyD = hoVitY5TylJ7GBEIZNOQg8pukq+'.png'
			PwoN7WT1UF = YYEXZsUWhf52vz7HLxc0qGJ.path.join(PP0Fx2UclCidVKMOo78ewI6pfar4Tk,FHrYRshzUvxmq31NA5TyD)
			if FHrYRshzUvxmq31NA5TyD in RXPvpF1CmVfG:
				LLeE2A6ltBpWU7TykZYmO.setArt({'icon':PwoN7WT1UF,'thumb':PwoN7WT1UF,'fanart':PwoN7WT1UF,'banner':PwoN7WT1UF,'clearart':PwoN7WT1UF,'poster':PwoN7WT1UF,'clearlogo':PwoN7WT1UF,'landscape':PwoN7WT1UF})
				gnUHS3KvABuzfiIProOlJRm = lvzrYTpcBaK
			elif rezGQkyOENmgIP<40 and ggPNKmUbkfZjo7qzWV2SI3<=vUnJhT2NO8yirHcAmg:
				try:
					HH0DAPjIetYMV3 = WiD0ZTYyQJFdbOhsLPza36(EuKx6eflvsTz2Fct3nmGrYqZ,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,hoVitY5TylJ7GBEIZNOQg8pukq,'menu_item','center',lvzrYTpcBaK,PwoN7WT1UF)
					LLeE2A6ltBpWU7TykZYmO.setArt({'icon':PwoN7WT1UF,'thumb':PwoN7WT1UF,'fanart':PwoN7WT1UF,'banner':PwoN7WT1UF,'clearart':PwoN7WT1UF,'poster':PwoN7WT1UF,'clearlogo':PwoN7WT1UF,'landscape':PwoN7WT1UF})
					rezGQkyOENmgIP += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
					gnUHS3KvABuzfiIProOlJRm = lvzrYTpcBaK
					RXPvpF1CmVfG.append(FHrYRshzUvxmq31NA5TyD)
					if rezGQkyOENmgIP==tBMCpcY2vUV1dEjZ7PDG: iRaHzNpJhSx6ZnCfrvD7j93lks('إضافة الكتابة لصور القائمة','انتظار',hDjf1Ubgq629nXlOvcFLH4Jw=500)
				except: ggPNKmUbkfZjo7qzWV2SI3 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
		if gnUHS3KvABuzfiIProOlJRm:
			LLeE2A6ltBpWU7TykZYmO.setArt({'icon':vcUEd8DY4u6zXiO1o,'thumb':vcUEd8DY4u6zXiO1o,'fanart':vcUEd8DY4u6zXiO1o,'banner':vcUEd8DY4u6zXiO1o,'clearart':vcUEd8DY4u6zXiO1o,'poster':vcUEd8DY4u6zXiO1o,'clearlogo':vcUEd8DY4u6zXiO1o,'landscape':vcUEd8DY4u6zXiO1o})
		if A4AOrGi8QL<20:
			if tthL9Y1i53HOjJCsPnqN2b8BFWS: LLeE2A6ltBpWU7TykZYmO.setInfo('video',{'Plot':tthL9Y1i53HOjJCsPnqN2b8BFWS,'PlotOutline':tthL9Y1i53HOjJCsPnqN2b8BFWS})
			if nnpDmYPl9Rt5geOJ: LLeE2A6ltBpWU7TykZYmO.setInfo('video',{'Rating':nnpDmYPl9Rt5geOJ})
			if not yNbi4akQM9EHO8wSlCGoJZx:
				LLeE2A6ltBpWU7TykZYmO.setInfo('video',{'Title':hoVitY5TylJ7GBEIZNOQg8pukq})
			if iHPTUWrX1nbg=='video':
				LLeE2A6ltBpWU7TykZYmO.setInfo('video',{'mediatype':'tvshow'})
				if OjyQrecApZ8: LLeE2A6ltBpWU7TykZYmO.setInfo('video',{'duration':OjyQrecApZ8})
				LLeE2A6ltBpWU7TykZYmO.setProperty('IsPlayable','true')
		else:
			uunbfmUBHcdwilq05zY3WV7 = LLeE2A6ltBpWU7TykZYmO.getVideoInfoTag()
			if nnpDmYPl9Rt5geOJ: uunbfmUBHcdwilq05zY3WV7.setRating(float(nnpDmYPl9Rt5geOJ))
			if not yNbi4akQM9EHO8wSlCGoJZx:
				uunbfmUBHcdwilq05zY3WV7.setTitle(hoVitY5TylJ7GBEIZNOQg8pukq)
			if iHPTUWrX1nbg=='video':
				uunbfmUBHcdwilq05zY3WV7.setMediaType('tvshow')
				if OjyQrecApZ8: uunbfmUBHcdwilq05zY3WV7.setDuration(OjyQrecApZ8)
				LLeE2A6ltBpWU7TykZYmO.setProperty('IsPlayable','true')
		EG6ekSP9XApyzOFQlg5q4d8ju.append((noSRFcJ8VzQLeYwHDC9xNrX1,LLeE2A6ltBpWU7TykZYmO,bOJorWRfsekl0))
	RPtvgsXL0EzbhIr.setContent(ZWaC4pLbOV1QEMrof08eu,'tvshows')
	VfSBmdiW713OJXUxDohbqGn = RPtvgsXL0EzbhIr.addDirectoryItems(ZWaC4pLbOV1QEMrof08eu,EG6ekSP9XApyzOFQlg5q4d8ju)
	RPtvgsXL0EzbhIr.endOfDirectory(ZWaC4pLbOV1QEMrof08eu,mO0jXV8KQFIGyCvSBWkDq2uo5flR,NGMHUZz3IiA0WaVlc,Ugv9tp41iZ8G7OSenfbQ)
	return VfSBmdiW713OJXUxDohbqGn
def XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx=sCHVtMAvqirbQ4BUK3cgWo,Ml0wzrY8uFeLOaPQyxmbX9=sCHVtMAvqirbQ4BUK3cgWo,T67f3LG49xpP8zcN=sCHVtMAvqirbQ4BUK3cgWo,hzwScpHQRnB5Z=sCHVtMAvqirbQ4BUK3cgWo,bK0LycGjJxiVCD={}):
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace('\t',sCHVtMAvqirbQ4BUK3cgWo)
	qhWpTazQ9ws = qhWpTazQ9ws.replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace('\t',sCHVtMAvqirbQ4BUK3cgWo)
	if '_SCRIPT_' in hoVitY5TylJ7GBEIZNOQg8pukq:
		qsActmwjBGK4Ia1OFihlnCz,hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.split('_SCRIPT_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
		if qsActmwjBGK4Ia1OFihlnCz not in list(Q1siCkTZyw.menuItemsDICT.keys()): Q1siCkTZyw.menuItemsDICT[qsActmwjBGK4Ia1OFihlnCz] = []
		Q1siCkTZyw.menuItemsDICT[qsActmwjBGK4Ia1OFihlnCz].append([iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD])
	Q1siCkTZyw.menuItemsLIST.append([iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD])
	return
def tt36wUe4HTPFmfs5hcbr(ACcKtH3E1rvSy):
	if I5VKjrFL0Bk97: from html import unescape as _AnosLXFfv6yOJ7
	else:
		from HTMLParser import HTMLParser as HVJ5jCtE0y2
		_AnosLXFfv6yOJ7 = HVJ5jCtE0y2().unescape
	if '&' in ACcKtH3E1rvSy and ';' in ACcKtH3E1rvSy:
		if qdUK5ioJyrO1T: ACcKtH3E1rvSy = ACcKtH3E1rvSy.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		ACcKtH3E1rvSy = _AnosLXFfv6yOJ7(ACcKtH3E1rvSy)
		if qdUK5ioJyrO1T: ACcKtH3E1rvSy = ACcKtH3E1rvSy.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	return ACcKtH3E1rvSy
def EEH4kBfGY0FuZUjeNn(ACcKtH3E1rvSy):
	if '\\u' in ACcKtH3E1rvSy:
		if qdUK5ioJyrO1T: ACcKtH3E1rvSy = ACcKtH3E1rvSy.decode('unicode_escape','ignore').encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		elif I5VKjrFL0Bk97: ACcKtH3E1rvSy = ACcKtH3E1rvSy.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT).decode('unicode_escape','ignore')
	return ACcKtH3E1rvSy
def xYsdFIBfqz3P(oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv):
	nBPJmCSwXRef = YYEXZsUWhf52vz7HLxc0qGJ.path.dirname(TubPMk85WZRwzrqJI1FAlv)
	if not YYEXZsUWhf52vz7HLxc0qGJ.path.exists(nBPJmCSwXRef):
		try: YYEXZsUWhf52vz7HLxc0qGJ.makedirs(nBPJmCSwXRef)
		except: pass
	nzPTctjDi7pvrS81 = e756M1PWwU(RRtlz6e2I8jnc)
	HH0DAPjIetYMV3 = WiD0ZTYyQJFdbOhsLPza36(nzPTctjDi7pvrS81,oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv)
	return HH0DAPjIetYMV3
def e756M1PWwU(RRtlz6e2I8jnc):
	hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo = tBMCpcY2vUV1dEjZ7PDG
	a29fyUe57Fj8qVrKigEoBtMA = 20
	fB37CUp54Rn0NzGglHurjvAXVw = 20
	ck5DG3KwtvBzIj = BewrUo9ANCa17G43Sn0LH5xh
	IIq0PATcrX6lido8UeC1y7jHu = 'center'
	XObuCsJgLwGYz0eM375vVA = BewrUo9ANCa17G43Sn0LH5xh
	MVxSXB9JWbji1 = 19
	mmVStIAKqJhLWcR7UEM3TsYefN = 30
	KHkXJioWAjl4whu96GPpOE5cL = 8
	w3OosjS6Agbi5EL = ndkUxG9LtewJ
	uej7Hh39ET = 375
	TTdJmk5aCOb4ZSRxwLHAjl = 410
	Znv64F7myW2CLEPGeXzikuDTxo1 = 50
	jAeKE1l3kTUPsIq6NWi = 280
	i5Zpxoulz3WYBQeHGa9r7sFw = 28
	rMnHFaW7cT9hxye5g0uPCU = tBMCpcY2vUV1dEjZ7PDG
	AuBxtZPOI4F2MCseSrLyGg3vnE6 = BewrUo9ANCa17G43Sn0LH5xh
	Bu8xLVHPbSiK3EfG64QrYDngjI = 31
	h7a1PcOKrIjni0kb9gl3me6CL = [36,32,28]
	from PIL import ImageDraw as BfexTtRADqZL8iFSwVoYN2yHaMvOn,ImageFont as MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye,Image as liLRuEyc2G9no
	if 'notification' in RRtlz6e2I8jnc:
		if RRtlz6e2I8jnc=='notification_regular':
			oMI7Z1rWmNaJgze = 117
			IIq0PATcrX6lido8UeC1y7jHu = 'left'
			w3OosjS6Agbi5EL = lvzrYTpcBaK
		elif RRtlz6e2I8jnc=='notification_auto':
			oMI7Z1rWmNaJgze = 'UPPER'
			IIq0PATcrX6lido8UeC1y7jHu = 'right'
			ck5DG3KwtvBzIj = 10
		LTIt1XG4rZCh0 = 720
		h7a1PcOKrIjni0kb9gl3me6CL = [33,33,33]
		fB37CUp54Rn0NzGglHurjvAXVw = 20
		a29fyUe57Fj8qVrKigEoBtMA = BewrUo9ANCa17G43Sn0LH5xh
		mmVStIAKqJhLWcR7UEM3TsYefN = 20
		MVxSXB9JWbji1 = 35
	elif RRtlz6e2I8jnc=='menu_item':
		h7a1PcOKrIjni0kb9gl3me6CL,LTIt1XG4rZCh0,oMI7Z1rWmNaJgze = [28,28,28],200,250
		XObuCsJgLwGYz0eM375vVA,mmVStIAKqJhLWcR7UEM3TsYefN,MVxSXB9JWbji1, = BewrUo9ANCa17G43Sn0LH5xh,-12,-30
		a29fyUe57Fj8qVrKigEoBtMA = BewrUo9ANCa17G43Sn0LH5xh
		VVXWPnLj3h8Iz5q0ATb7M = liLRuEyc2G9no.open(vcUEd8DY4u6zXiO1o)
		dIuwilQVa6T1FBc = liLRuEyc2G9no.new('RGBA',(LTIt1XG4rZCh0,oMI7Z1rWmNaJgze),(255,BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh,255))
	elif RRtlz6e2I8jnc=='confirm_smallfont': h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [28,24,20],500,900
	elif RRtlz6e2I8jnc=='confirm_mediumfont': h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [32,28,24],500,900
	elif RRtlz6e2I8jnc=='confirm_bigfont': h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [36,32,28],500,900
	elif RRtlz6e2I8jnc=='textview_bigfont': oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = 740,1270
	elif RRtlz6e2I8jnc=='textview_bigfont_long': oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = 'UPPER',1270
	elif RRtlz6e2I8jnc=='textview_smallfont': h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [28,23,18],740,1270
	elif RRtlz6e2I8jnc=='textview_smallfont_long': h7a1PcOKrIjni0kb9gl3me6CL,oMI7Z1rWmNaJgze,LTIt1XG4rZCh0 = [28,23,18],'UPPER',1270
	wnaDyx7CM9vzYJmG0SfXU1jdsOH,ox1ZuFje7l2fkL0i,TOkXQumgw35BFioY6njpJtMEyD0qb = h7a1PcOKrIjni0kb9gl3me6CL
	b6b1UxHaEDWyoYqeL2PRuS5XNtMOl = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=wnaDyx7CM9vzYJmG0SfXU1jdsOH)
	NrVZ3LRFPs5 = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=ox1ZuFje7l2fkL0i)
	dBkIzjaxtmA19PyHCNuX67fn8 = MMU4oXQ7E9GLWiqCd1bDjSgJBf5Ye.truetype(elBiEOg5o8Vbn1wJ96LZcysxtqYF,size=TOkXQumgw35BFioY6njpJtMEyD0qb)
	UckbZ20dDejFg = LTIt1XG4rZCh0-mmVStIAKqJhLWcR7UEM3TsYefN*rgpY5VUqKbeFOCD9Nki2SmGvxEja
	RnoqYA81baVHQwvJZhkieCPgL3XtE = liLRuEyc2G9no.new('RGBA',(UckbZ20dDejFg,100),(255,255,255,BewrUo9ANCa17G43Sn0LH5xh))
	ggh2EzTxfV8c5sl47 = BfexTtRADqZL8iFSwVoYN2yHaMvOn.Draw(RnoqYA81baVHQwvJZhkieCPgL3XtE)
	kDRFWdOxeM059oCH3zXV4,nHF4m1bZYrcjstGUPa = ggh2EzTxfV8c5sl47.textsize('HHH BBB 888 000',font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl)
	MdbzSxVDFPB,LAnc5aRsbQ8feCqO = ggh2EzTxfV8c5sl47.textsize('HHH BBB 888 000',font=NrVZ3LRFPs5)
	QRSuEI6CMYNd8B7hgkTrqc = {'delete_harakat':lvzrYTpcBaK,'support_ligatures':ndkUxG9LtewJ,'ARABIC LIGATURE ALLAH':lvzrYTpcBaK}
	from arabic_reshaper import ArabicReshaper as SS4x90XTKF5prLd3PvhHM
	hvXMB9VWELz8l = SS4x90XTKF5prLd3PvhHM(configuration=QRSuEI6CMYNd8B7hgkTrqc)
	nzPTctjDi7pvrS81 = {}
	G20KTjWFfs9V = locals()
	for FCYq34IhByUnfKRi1GS5pmD6Vzd7ju in G20KTjWFfs9V: nzPTctjDi7pvrS81[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju] = G20KTjWFfs9V[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju]
	return nzPTctjDi7pvrS81
def WiD0ZTYyQJFdbOhsLPza36(nzPTctjDi7pvrS81,oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN,RRtlz6e2I8jnc,JUTpkxOQHBVZ5,fVwySktquzhxdBRn03D,TubPMk85WZRwzrqJI1FAlv):
	for FCYq34IhByUnfKRi1GS5pmD6Vzd7ju in nzPTctjDi7pvrS81: globals()[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju] = nzPTctjDi7pvrS81[FCYq34IhByUnfKRi1GS5pmD6Vzd7ju]
	global i5Zpxoulz3WYBQeHGa9r7sFw,rMnHFaW7cT9hxye5g0uPCU
	if RRtlz6e2I8jnc!='menu_item':
		lnd8TJjXS4 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.translate')
		if lnd8TJjXS4:
			if oIra9JvSTHjFx1Z=='نعم  Yes': oIra9JvSTHjFx1Z = 'Yes'
			elif oIra9JvSTHjFx1Z=='كلا  No': oIra9JvSTHjFx1Z = 'No'
			if Wrh9Yna5jc=='نعم  Yes': Wrh9Yna5jc = 'Yes'
			elif Wrh9Yna5jc=='كلا  No': Wrh9Yna5jc = 'No'
			if CXsBGz3FiMS601LyJOc4oKjbT5Rh=='نعم  Yes': CXsBGz3FiMS601LyJOc4oKjbT5Rh = 'Yes'
			elif CXsBGz3FiMS601LyJOc4oKjbT5Rh=='كلا  No': CXsBGz3FiMS601LyJOc4oKjbT5Rh = 'No'
			PaQp3oz49JfRdYbywq = J7YQHOxiBW0SrcXCwaN5dmf2ZRAKp([oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN])
			if PaQp3oz49JfRdYbywq: oIra9JvSTHjFx1Z,Wrh9Yna5jc,CXsBGz3FiMS601LyJOc4oKjbT5Rh,II2lAsxMPkyUH8,T67f3LG49xpP8zcN = PaQp3oz49JfRdYbywq
	if qdUK5ioJyrO1T:
		T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		II2lAsxMPkyUH8 = II2lAsxMPkyUH8.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		oIra9JvSTHjFx1Z = oIra9JvSTHjFx1Z.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		Wrh9Yna5jc = Wrh9Yna5jc.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		CXsBGz3FiMS601LyJOc4oKjbT5Rh = CXsBGz3FiMS601LyJOc4oKjbT5Rh.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	SmFfYHy6tZVB = II2lAsxMPkyUH8.count(slFfrUIWCowaBA7tce3iZbj8xn)+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	TXfVLgQsJOMPkEC95GjUuiYpn = a29fyUe57Fj8qVrKigEoBtMA+SmFfYHy6tZVB*(nHF4m1bZYrcjstGUPa+ck5DG3KwtvBzIj)-ck5DG3KwtvBzIj
	if T67f3LG49xpP8zcN:
		LUZugd8opYADI = LAnc5aRsbQ8feCqO+KHkXJioWAjl4whu96GPpOE5cL
		IrgvU0ZftXsmnYTpwH = hvXMB9VWELz8l.reshape(T67f3LG49xpP8zcN)
		if w3OosjS6Agbi5EL:
			jiBcXPaIq8sEx6n9 = o5IXWZjB6fQu7T1NdA(ggh2EzTxfV8c5sl47,NrVZ3LRFPs5,IrgvU0ZftXsmnYTpwH,ox1ZuFje7l2fkL0i,UckbZ20dDejFg,LUZugd8opYADI)
			Yji8HZntyzO2TUr9d = CvZSWkKsoRNYmnp7IhgOufr4(jiBcXPaIq8sEx6n9)
			RyB8Wbcr3zgSP1UJwk = Yji8HZntyzO2TUr9d.count(slFfrUIWCowaBA7tce3iZbj8xn)+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			CQKfX8hTSap = MVxSXB9JWbji1+RyB8Wbcr3zgSP1UJwk*LUZugd8opYADI-KHkXJioWAjl4whu96GPpOE5cL
		else:
			CQKfX8hTSap = MVxSXB9JWbji1+LAnc5aRsbQ8feCqO
			Yji8HZntyzO2TUr9d = IrgvU0ZftXsmnYTpwH.split(slFfrUIWCowaBA7tce3iZbj8xn)[BewrUo9ANCa17G43Sn0LH5xh]
			jiBcXPaIq8sEx6n9 = IrgvU0ZftXsmnYTpwH.split(slFfrUIWCowaBA7tce3iZbj8xn)[BewrUo9ANCa17G43Sn0LH5xh]
	else: CQKfX8hTSap = MVxSXB9JWbji1
	QYk0XERuxAbmNrDH49yov = AuBxtZPOI4F2MCseSrLyGg3vnE6+Bu8xLVHPbSiK3EfG64QrYDngjI
	if fVwySktquzhxdBRn03D:
		fcyQv5Ud0m3IPnOgM7zT = TTdJmk5aCOb4ZSRxwLHAjl-uej7Hh39ET
		QYk0XERuxAbmNrDH49yov += fcyQv5Ud0m3IPnOgM7zT
	else: fcyQv5Ud0m3IPnOgM7zT = BewrUo9ANCa17G43Sn0LH5xh
	if oIra9JvSTHjFx1Z or Wrh9Yna5jc or CXsBGz3FiMS601LyJOc4oKjbT5Rh: QYk0XERuxAbmNrDH49yov += Znv64F7myW2CLEPGeXzikuDTxo1
	HH0DAPjIetYMV3 = oMI7Z1rWmNaJgze if oMI7Z1rWmNaJgze!='UPPER' else TXfVLgQsJOMPkEC95GjUuiYpn+CQKfX8hTSap+QYk0XERuxAbmNrDH49yov
	RnoqYA81baVHQwvJZhkieCPgL3XtE = liLRuEyc2G9no.new('RGBA',(LTIt1XG4rZCh0,HH0DAPjIetYMV3),(255,255,255,BewrUo9ANCa17G43Sn0LH5xh))
	MMv0dpRCFlxcYTn5 = BfexTtRADqZL8iFSwVoYN2yHaMvOn.Draw(RnoqYA81baVHQwvJZhkieCPgL3XtE)
	LnBWoMKYASTqgjGQvNs5DrH4 = HH0DAPjIetYMV3-TXfVLgQsJOMPkEC95GjUuiYpn-QYk0XERuxAbmNrDH49yov-MVxSXB9JWbji1
	if not Wrh9Yna5jc and oIra9JvSTHjFx1Z and CXsBGz3FiMS601LyJOc4oKjbT5Rh:
		i5Zpxoulz3WYBQeHGa9r7sFw += 105
		rMnHFaW7cT9hxye5g0uPCU -= 110
	import bidi.algorithm as KKIAFzsoVcRrT9
	if II2lAsxMPkyUH8:
		GZLdR4CbNqyiUQekun = a29fyUe57Fj8qVrKigEoBtMA
		II2lAsxMPkyUH8 = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(II2lAsxMPkyUH8))
		PCS2siEhbL = II2lAsxMPkyUH8.splitlines()
		for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in PCS2siEhbL:
			if QXeuCy5v3cK4qEVBLzPabFUlAfGN0m:
				rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl)
				if IIq0PATcrX6lido8UeC1y7jHu=='center': duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+(LTIt1XG4rZCh0-rhkm6OzYH87QTCJcs0DiR4Mox)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
				elif IIq0PATcrX6lido8UeC1y7jHu=='right': duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+LTIt1XG4rZCh0-rhkm6OzYH87QTCJcs0DiR4Mox-fB37CUp54Rn0NzGglHurjvAXVw
				elif IIq0PATcrX6lido8UeC1y7jHu=='left': duNxLa39T2C = hYEi6yJ7Lk9S41F3ngZq5rTeNxjRo+fB37CUp54Rn0NzGglHurjvAXVw
				MMv0dpRCFlxcYTn5.text((duNxLa39T2C,GZLdR4CbNqyiUQekun),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=b6b1UxHaEDWyoYqeL2PRuS5XNtMOl,fill='yellow')
			GZLdR4CbNqyiUQekun += wnaDyx7CM9vzYJmG0SfXU1jdsOH+ck5DG3KwtvBzIj
	if oIra9JvSTHjFx1Z or Wrh9Yna5jc or CXsBGz3FiMS601LyJOc4oKjbT5Rh:
		qS64NgRWvMrJ8DF1Ibwjc = TXfVLgQsJOMPkEC95GjUuiYpn+LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1+fcyQv5Ud0m3IPnOgM7zT+AuBxtZPOI4F2MCseSrLyGg3vnE6
		if oIra9JvSTHjFx1Z:
			oIra9JvSTHjFx1Z = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(oIra9JvSTHjFx1Z))
			c0VoSDtgiuFHI5pZ,OF04hqeDzIi9nQpR38gCKtSo = MMv0dpRCFlxcYTn5.textsize(oIra9JvSTHjFx1Z,font=dBkIzjaxtmA19PyHCNuX67fn8)
			SSMtFvgcGNo2jDT9HwuYkrOnl5hU8 = i5Zpxoulz3WYBQeHGa9r7sFw+BewrUo9ANCa17G43Sn0LH5xh*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-c0VoSDtgiuFHI5pZ)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((SSMtFvgcGNo2jDT9HwuYkrOnl5hU8,qS64NgRWvMrJ8DF1Ibwjc),oIra9JvSTHjFx1Z,font=dBkIzjaxtmA19PyHCNuX67fn8,fill='yellow')
		if Wrh9Yna5jc:
			Wrh9Yna5jc = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(Wrh9Yna5jc))
			QQyUd9r38FNbGc,hZKdzHwa3nuykf4JRMc = MMv0dpRCFlxcYTn5.textsize(Wrh9Yna5jc,font=dBkIzjaxtmA19PyHCNuX67fn8)
			o2TFuvnzqcI15XyYGsaSkg = i5Zpxoulz3WYBQeHGa9r7sFw+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-QQyUd9r38FNbGc)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((o2TFuvnzqcI15XyYGsaSkg,qS64NgRWvMrJ8DF1Ibwjc),Wrh9Yna5jc,font=dBkIzjaxtmA19PyHCNuX67fn8,fill='yellow')
		if CXsBGz3FiMS601LyJOc4oKjbT5Rh:
			CXsBGz3FiMS601LyJOc4oKjbT5Rh = KKIAFzsoVcRrT9.get_display(hvXMB9VWELz8l.reshape(CXsBGz3FiMS601LyJOc4oKjbT5Rh))
			Zare87wiP0do4lpIcFG,TcD6haEQXJl = MMv0dpRCFlxcYTn5.textsize(CXsBGz3FiMS601LyJOc4oKjbT5Rh,font=dBkIzjaxtmA19PyHCNuX67fn8)
			XeQazj5mr7n = i5Zpxoulz3WYBQeHGa9r7sFw+rgpY5VUqKbeFOCD9Nki2SmGvxEja*(rMnHFaW7cT9hxye5g0uPCU+jAeKE1l3kTUPsIq6NWi)+(jAeKE1l3kTUPsIq6NWi-Zare87wiP0do4lpIcFG)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			MMv0dpRCFlxcYTn5.text((XeQazj5mr7n,qS64NgRWvMrJ8DF1Ibwjc),CXsBGz3FiMS601LyJOc4oKjbT5Rh,font=dBkIzjaxtmA19PyHCNuX67fn8,fill='yellow')
	if T67f3LG49xpP8zcN:
		nhapAbW6evX5tCi,OiX96NRy8HB1I0ZnFaJht3rpGTWM = [],[]
		jiBcXPaIq8sEx6n9 = BBYXwHyqUiTLCG3fhcZzgQ8(jiBcXPaIq8sEx6n9)
		bKXvpdiOwloPZzhFA5aI9trNx4nCM = jiBcXPaIq8sEx6n9.split('_sss__newline_')
		for bjIwotHlkAWc1ZCsgPJQV6eui7x in bKXvpdiOwloPZzhFA5aI9trNx4nCM:
			gJHQDsfcEPjBwd82t3Y = JUTpkxOQHBVZ5
			if   '_sss__lineleft_' in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = 'left'
			elif '_sss__lineright_' in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = 'right'
			elif '_sss__linecenter_' in bjIwotHlkAWc1ZCsgPJQV6eui7x: gJHQDsfcEPjBwd82t3Y = 'center'
			RzDbac7IKWfBXm9ZPMtw = bjIwotHlkAWc1ZCsgPJQV6eui7x
			j1rxPg56UYSCIhR7ZkVeKL = fNntYJW45mEFSdRX8g.findall('_sss__.*?_',bjIwotHlkAWc1ZCsgPJQV6eui7x,fNntYJW45mEFSdRX8g.DOTALL)
			for apym85Pd0MzHq64ItJEVOT in j1rxPg56UYSCIhR7ZkVeKL: RzDbac7IKWfBXm9ZPMtw = RzDbac7IKWfBXm9ZPMtw.replace(apym85Pd0MzHq64ItJEVOT,sCHVtMAvqirbQ4BUK3cgWo)
			if RzDbac7IKWfBXm9ZPMtw==sCHVtMAvqirbQ4BUK3cgWo: rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = BewrUo9ANCa17G43Sn0LH5xh,LUZugd8opYADI
			else: rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(RzDbac7IKWfBXm9ZPMtw,font=NrVZ3LRFPs5)
			if   gJHQDsfcEPjBwd82t3Y=='left': dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN
			elif gJHQDsfcEPjBwd82t3Y=='right': dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN+UckbZ20dDejFg-rhkm6OzYH87QTCJcs0DiR4Mox
			elif gJHQDsfcEPjBwd82t3Y=='center': dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN+(UckbZ20dDejFg-rhkm6OzYH87QTCJcs0DiR4Mox)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			if dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1<mmVStIAKqJhLWcR7UEM3TsYefN: dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = XObuCsJgLwGYz0eM375vVA+mmVStIAKqJhLWcR7UEM3TsYefN
			nhapAbW6evX5tCi.append(dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1)
			OiX96NRy8HB1I0ZnFaJht3rpGTWM.append(rhkm6OzYH87QTCJcs0DiR4Mox)
		dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = nhapAbW6evX5tCi[BewrUo9ANCa17G43Sn0LH5xh]
		RNWfyoQawsSxDmL = jiBcXPaIq8sEx6n9.split('_sss_')
		g96zSBYUm37lLn = (255,255,255,255)
		wXzR7vmOngylaDd9EH2qftMpsb0Wuo = g96zSBYUm37lLn
		boMtO7FXAdlEag,SoNdClO5PAnEhkwVR9KXr = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
		ySU0z7cBD3mMxdCPi = lvzrYTpcBaK
		AkvaK6WezXLFRjqxtM3T8d7oc1uQD = BewrUo9ANCa17G43Sn0LH5xh
		iVEPe8hHw6fZ9aop4Lmv = TXfVLgQsJOMPkEC95GjUuiYpn+MVxSXB9JWbji1/rgpY5VUqKbeFOCD9Nki2SmGvxEja
		if CQKfX8hTSap<(LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1):
			SMAKGqJDtu7g = (LnBWoMKYASTqgjGQvNs5DrH4+MVxSXB9JWbji1-CQKfX8hTSap)/rgpY5VUqKbeFOCD9Nki2SmGvxEja
			iVEPe8hHw6fZ9aop4Lmv = TXfVLgQsJOMPkEC95GjUuiYpn+MVxSXB9JWbji1+SMAKGqJDtu7g-LAnc5aRsbQ8feCqO/rgpY5VUqKbeFOCD9Nki2SmGvxEja
		for QXeuCy5v3cK4qEVBLzPabFUlAfGN0m in RNWfyoQawsSxDmL:
			if not QXeuCy5v3cK4qEVBLzPabFUlAfGN0m or (QXeuCy5v3cK4qEVBLzPabFUlAfGN0m and ord(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[BewrUo9ANCa17G43Sn0LH5xh])==65279): continue
			HJ8lCvFKsbQn5IYqxDt7 = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_newline_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			TslkEYuPemcq = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_newcolor',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			xUfZnApo4RcCbw1NleaOIry5DBL9GY = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_endcolor_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			lBOgrhU3IJA1aXfcNH = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_linertl_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			XBdwygbaAhVN = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_lineleft_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			iGTynS50DLflzduKbO17kx6QA = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_lineright_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			fQcSnmUrwPH39g = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m.split('_linecenter_',zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
			if len(HJ8lCvFKsbQn5IYqxDt7)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				AkvaK6WezXLFRjqxtM3T8d7oc1uQD += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = HJ8lCvFKsbQn5IYqxDt7[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				boMtO7FXAdlEag = BewrUo9ANCa17G43Sn0LH5xh
				dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1 = nhapAbW6evX5tCi[AkvaK6WezXLFRjqxtM3T8d7oc1uQD]
				SoNdClO5PAnEhkwVR9KXr += LUZugd8opYADI
				ySU0z7cBD3mMxdCPi = lvzrYTpcBaK
			elif len(TslkEYuPemcq)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = TslkEYuPemcq[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[BewrUo9ANCa17G43Sn0LH5xh:8]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = '#'+wXzR7vmOngylaDd9EH2qftMpsb0Wuo[rgpY5VUqKbeFOCD9Nki2SmGvxEja:]
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = QXeuCy5v3cK4qEVBLzPabFUlAfGN0m[9:]
			elif len(xUfZnApo4RcCbw1NleaOIry5DBL9GY)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = xUfZnApo4RcCbw1NleaOIry5DBL9GY[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				wXzR7vmOngylaDd9EH2qftMpsb0Wuo = g96zSBYUm37lLn
			elif len(lBOgrhU3IJA1aXfcNH)>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = lBOgrhU3IJA1aXfcNH[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
				ySU0z7cBD3mMxdCPi = ndkUxG9LtewJ
				boMtO7FXAdlEag = OiX96NRy8HB1I0ZnFaJht3rpGTWM[AkvaK6WezXLFRjqxtM3T8d7oc1uQD]
			elif len(XBdwygbaAhVN)>1: QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = XBdwygbaAhVN[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			elif len(iGTynS50DLflzduKbO17kx6QA)>1: QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = iGTynS50DLflzduKbO17kx6QA[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			elif len(fQcSnmUrwPH39g)>1: QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = fQcSnmUrwPH39g[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
			if QXeuCy5v3cK4qEVBLzPabFUlAfGN0m:
				fUypeQitldr7 = iVEPe8hHw6fZ9aop4Lmv+SoNdClO5PAnEhkwVR9KXr
				QXeuCy5v3cK4qEVBLzPabFUlAfGN0m = KKIAFzsoVcRrT9.get_display(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m)
				rhkm6OzYH87QTCJcs0DiR4Mox,tXLs1TqmDu4cynj7OZ9SrK = MMv0dpRCFlxcYTn5.textsize(QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5)
				if ySU0z7cBD3mMxdCPi: boMtO7FXAdlEag -= rhkm6OzYH87QTCJcs0DiR4Mox
				otdpUiax59SIP6ebhcLqD7FuZJVr = dgaCvy7uwkRtQU6Do9ZbfAnXGx0YI1+boMtO7FXAdlEag
				MMv0dpRCFlxcYTn5.text((otdpUiax59SIP6ebhcLqD7FuZJVr,fUypeQitldr7),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5,fill=wXzR7vmOngylaDd9EH2qftMpsb0Wuo)
				if RRtlz6e2I8jnc=='menu_item': MMv0dpRCFlxcYTn5.text((otdpUiax59SIP6ebhcLqD7FuZJVr+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,fUypeQitldr7+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU),QXeuCy5v3cK4qEVBLzPabFUlAfGN0m,font=NrVZ3LRFPs5,fill=wXzR7vmOngylaDd9EH2qftMpsb0Wuo)
				if not ySU0z7cBD3mMxdCPi: boMtO7FXAdlEag += rhkm6OzYH87QTCJcs0DiR4Mox
				if fUypeQitldr7>LnBWoMKYASTqgjGQvNs5DrH4+LUZugd8opYADI: break
	if RRtlz6e2I8jnc=='menu_item':
		S4UZknpfuJt5brycwPj = VVXWPnLj3h8Iz5q0ATb7M.copy()
		hDjf1Ubgq629nXlOvcFLH4Jw.sleep(0.05)
		S4UZknpfuJt5brycwPj.paste(dIuwilQVa6T1FBc,(BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh),mask=RnoqYA81baVHQwvJZhkieCPgL3XtE)
	else: S4UZknpfuJt5brycwPj = RnoqYA81baVHQwvJZhkieCPgL3XtE
	if qdUK5ioJyrO1T: TubPMk85WZRwzrqJI1FAlv = TubPMk85WZRwzrqJI1FAlv.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	try: S4UZknpfuJt5brycwPj.save(TubPMk85WZRwzrqJI1FAlv)
	except UnicodeError:
		if qdUK5ioJyrO1T:
			TubPMk85WZRwzrqJI1FAlv = TubPMk85WZRwzrqJI1FAlv.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			S4UZknpfuJt5brycwPj.save(TubPMk85WZRwzrqJI1FAlv)
	return HH0DAPjIetYMV3
def o5IXWZjB6fQu7T1NdA(ggh2EzTxfV8c5sl47,NrVZ3LRFPs5,rtkvdDL8Hugy,owFcBgpMP3nzTfO,UckbZ20dDejFg,veDZ67muyJp):
	R8gkMNxsIaLDfoXjyOnQhe,bbjSo3FKdYRxa4g7rzIsiThBOQ,KKZRWLAOlvbMTo98nzhESrIV5cj2mH = sCHVtMAvqirbQ4BUK3cgWo,BewrUo9ANCa17G43Sn0LH5xh,15000
	rtkvdDL8Hugy = rtkvdDL8Hugy.replace('[COLOR ','[COLOR:::')
	Or4zBtT5yjoGkR69QmFngqb = UckbZ20dDejFg-owFcBgpMP3nzTfO*rgpY5VUqKbeFOCD9Nki2SmGvxEja
	for ryszSPJMwcRiQXEumZ in rtkvdDL8Hugy.splitlines():
		bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
		X8TVbKNQOvChRcwAUzqnuG,rrjF0lpnM1 = BewrUo9ANCa17G43Sn0LH5xh,sCHVtMAvqirbQ4BUK3cgWo
		for jQGoEi4HPVkK3svrM5Z in ryszSPJMwcRiQXEumZ.split(AAh0X3OCacr4HpifRGLZKT):
			d5FhmKRjuvGSt = CvZSWkKsoRNYmnp7IhgOufr4(AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z)
			FFaP9lE0MnWjskZeNoR21B8vx,qgbc3JhIZkF46SWiXRYzVdUA = ggh2EzTxfV8c5sl47.textsize(d5FhmKRjuvGSt,font=NrVZ3LRFPs5)
			if X8TVbKNQOvChRcwAUzqnuG+FFaP9lE0MnWjskZeNoR21B8vx<Or4zBtT5yjoGkR69QmFngqb:
				if not rrjF0lpnM1: rrjF0lpnM1 += jQGoEi4HPVkK3svrM5Z
				else: rrjF0lpnM1 += AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z
				X8TVbKNQOvChRcwAUzqnuG += FFaP9lE0MnWjskZeNoR21B8vx
			else:
				if FFaP9lE0MnWjskZeNoR21B8vx<Or4zBtT5yjoGkR69QmFngqb:
					rrjF0lpnM1 += '\n '+jQGoEi4HPVkK3svrM5Z
					bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
					X8TVbKNQOvChRcwAUzqnuG = FFaP9lE0MnWjskZeNoR21B8vx
				else:
					while FFaP9lE0MnWjskZeNoR21B8vx>Or4zBtT5yjoGkR69QmFngqb:
						for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU,len(AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z),zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU):
							wGQ1UViarZt8TK6zF9Rp = AAh0X3OCacr4HpifRGLZKT+jQGoEi4HPVkK3svrM5Z[:qT1ZRz0VMiXQhxFUPdJC2u9asvrN]
							D3MxqnLQjZFRg0yNH8vC = jQGoEi4HPVkK3svrM5Z[qT1ZRz0VMiXQhxFUPdJC2u9asvrN:]
							gYaToe6zSu4nc1NWCXv8 = CvZSWkKsoRNYmnp7IhgOufr4(wGQ1UViarZt8TK6zF9Rp)
							c1hmuk36stDWNvE49ipYC7rZUS,nnms1w34hSFzDQToCJ = ggh2EzTxfV8c5sl47.textsize(gYaToe6zSu4nc1NWCXv8,font=NrVZ3LRFPs5)
							if X8TVbKNQOvChRcwAUzqnuG+c1hmuk36stDWNvE49ipYC7rZUS>Or4zBtT5yjoGkR69QmFngqb:
								eTSMFJpPkcOvb = FFaP9lE0MnWjskZeNoR21B8vx-c1hmuk36stDWNvE49ipYC7rZUS
								rrjF0lpnM1 += wGQ1UViarZt8TK6zF9Rp+slFfrUIWCowaBA7tce3iZbj8xn
								bbjSo3FKdYRxa4g7rzIsiThBOQ += veDZ67muyJp
								FFaP9lE0MnWjskZeNoR21B8vx = eTSMFJpPkcOvb
								if eTSMFJpPkcOvb>Or4zBtT5yjoGkR69QmFngqb:
									X8TVbKNQOvChRcwAUzqnuG = BewrUo9ANCa17G43Sn0LH5xh
									jQGoEi4HPVkK3svrM5Z = D3MxqnLQjZFRg0yNH8vC
								else:
									X8TVbKNQOvChRcwAUzqnuG = eTSMFJpPkcOvb
									rrjF0lpnM1 += D3MxqnLQjZFRg0yNH8vC
								break
				if bbjSo3FKdYRxa4g7rzIsiThBOQ>KKZRWLAOlvbMTo98nzhESrIV5cj2mH: break
		R8gkMNxsIaLDfoXjyOnQhe += slFfrUIWCowaBA7tce3iZbj8xn+rrjF0lpnM1
		if bbjSo3FKdYRxa4g7rzIsiThBOQ>KKZRWLAOlvbMTo98nzhESrIV5cj2mH: break
	R8gkMNxsIaLDfoXjyOnQhe = R8gkMNxsIaLDfoXjyOnQhe[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:]
	R8gkMNxsIaLDfoXjyOnQhe = R8gkMNxsIaLDfoXjyOnQhe.replace('[COLOR:::','[COLOR ')
	return R8gkMNxsIaLDfoXjyOnQhe
def CvZSWkKsoRNYmnp7IhgOufr4(jQGoEi4HPVkK3svrM5Z):
	if '[' in jQGoEi4HPVkK3svrM5Z and ']' in jQGoEi4HPVkK3svrM5Z:
		j1rxPg56UYSCIhR7ZkVeKL = [B8alA5nvIhTxQ,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		IWLR5Qnlhv9O2dNUsb4cmtSgJVEiGu = fNntYJW45mEFSdRX8g.findall('\[COLOR .*?\]',jQGoEi4HPVkK3svrM5Z,fNntYJW45mEFSdRX8g.DOTALL)
		nnsAL2wpV6ax1fiSYX5GlqPot7 = fNntYJW45mEFSdRX8g.findall('\[COLOR:::.*?\]',jQGoEi4HPVkK3svrM5Z,fNntYJW45mEFSdRX8g.DOTALL)
		Bc0xOiyM2fv5 = j1rxPg56UYSCIhR7ZkVeKL+IWLR5Qnlhv9O2dNUsb4cmtSgJVEiGu+nnsAL2wpV6ax1fiSYX5GlqPot7
		for apym85Pd0MzHq64ItJEVOT in Bc0xOiyM2fv5: jQGoEi4HPVkK3svrM5Z = jQGoEi4HPVkK3svrM5Z.replace(apym85Pd0MzHq64ItJEVOT,sCHVtMAvqirbQ4BUK3cgWo)
	return jQGoEi4HPVkK3svrM5Z
def BBYXwHyqUiTLCG3fhcZzgQ8(T67f3LG49xpP8zcN):
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(slFfrUIWCowaBA7tce3iZbj8xn,'_sss__newline_')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RTL]','_sss__linertl_')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[LEFT]','_sss__lineleft_')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[RIGHT]','_sss__lineright_')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[CENTER]','_sss__linecenter_')
	T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace(B8alA5nvIhTxQ,'_sss__endcolor_')
	bBQXe49Icj = fNntYJW45mEFSdRX8g.findall('\[COLOR (.*?)\]',T67f3LG49xpP8zcN,fNntYJW45mEFSdRX8g.DOTALL)
	for p64PCz0clvJ8Z5nXOxDEaQuI3k2i in bBQXe49Icj: T67f3LG49xpP8zcN = T67f3LG49xpP8zcN.replace('[COLOR '+p64PCz0clvJ8Z5nXOxDEaQuI3k2i+']','_sss__newcolor'+p64PCz0clvJ8Z5nXOxDEaQuI3k2i+'_')
	return T67f3LG49xpP8zcN
def qqNWVf6hw1YaFX0Sg4lROcTCHsdvM(PRhHG8UngNFxAWQmKkp,hoVitY5TylJ7GBEIZNOQg8pukq=sCHVtMAvqirbQ4BUK3cgWo):
	if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Label')
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(bRa9TlJO4fPdsUAj,AAh0X3OCacr4HpifRGLZKT).replace(OUmtsIB1zyF,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).strip(AAh0X3OCacr4HpifRGLZKT)
	if PRhHG8UngNFxAWQmKkp: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace('[COLOR ',sCHVtMAvqirbQ4BUK3cgWo).replace(']',sCHVtMAvqirbQ4BUK3cgWo)
	else: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(F7Fe63KbGjaz2TcmCNHPdo5QiXO,sCHVtMAvqirbQ4BUK3cgWo).replace(VXWOCAE6ns3paJ8DLG479NQfMu,sCHVtMAvqirbQ4BUK3cgWo).replace(ppPYj60nQOTlIut3X59FGZd,sCHVtMAvqirbQ4BUK3cgWo).replace(YA9GohfEca42kZOB6FN5t3y70JxMQg,sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).replace(f6fsIXQonhvcGg1p,sCHVtMAvqirbQ4BUK3cgWo).replace(B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo)
	hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.replace(aU23gVSeZ8QMl,sCHVtMAvqirbQ4BUK3cgWo).replace(t0ozNJUhjCVgRmMp89KGaWvfl3AS,sCHVtMAvqirbQ4BUK3cgWo)
	VSzDZiYCvW9Fyf5dtjoGpM3w = fNntYJW45mEFSdRX8g.findall('\d\d:\d\d ',hoVitY5TylJ7GBEIZNOQg8pukq,fNntYJW45mEFSdRX8g.DOTALL)
	if VSzDZiYCvW9Fyf5dtjoGpM3w: hoVitY5TylJ7GBEIZNOQg8pukq = hoVitY5TylJ7GBEIZNOQg8pukq.split(VSzDZiYCvW9Fyf5dtjoGpM3w[BewrUo9ANCa17G43Sn0LH5xh],zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)[zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU]
	if not hoVitY5TylJ7GBEIZNOQg8pukq: hoVitY5TylJ7GBEIZNOQg8pukq = 'Main Menu'
	return hoVitY5TylJ7GBEIZNOQg8pukq
def ij3WwceDrmqafJy6Lsx4S9GCFuP(spngGR4jdhTFkJD2Sx1iva):
	R6LDWx2iFVlJUfOseSk5HyPnmIvcXg = sCHVtMAvqirbQ4BUK3cgWo.join(qT1ZRz0VMiXQhxFUPdJC2u9asvrN for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in spngGR4jdhTFkJD2Sx1iva if qT1ZRz0VMiXQhxFUPdJC2u9asvrN not in '\/":*?<>|'+zzXbKjEJ47ysUgH2LPl3dnt)
	return R6LDWx2iFVlJUfOseSk5HyPnmIvcXg
def CucRkH5KZqofAMWUgBFYVIz2jewbO(Ml0wzrY8uFeLOaPQyxmbX9,hoVitY5TylJ7GBEIZNOQg8pukq='adilbo_HTML_encoder'):
	Gbi1Lkq3Uraty0fVK2lQuzNoYgv = fNntYJW45mEFSdRX8g.findall(hoVitY5TylJ7GBEIZNOQg8pukq+"(.*?)/g.....(.*?)\)",Ml0wzrY8uFeLOaPQyxmbX9,fNntYJW45mEFSdRX8g.S)
	if Gbi1Lkq3Uraty0fVK2lQuzNoYgv:
		uAMPjykshwml2z7,CCgRTZGz1yDhk2aVHfM9SntX = Gbi1Lkq3Uraty0fVK2lQuzNoYgv[BewrUo9ANCa17G43Sn0LH5xh]
		uAMPjykshwml2z7 = fNntYJW45mEFSdRX8g.findall("=[\r\n\s\t]+'(.*?)';", uAMPjykshwml2z7, fNntYJW45mEFSdRX8g.S)[BewrUo9ANCa17G43Sn0LH5xh]
		if uAMPjykshwml2z7 and CCgRTZGz1yDhk2aVHfM9SntX:
			nc3zm8T2VobipLPyJjdSH9AaWFtvG = uAMPjykshwml2z7.replace("'",sCHVtMAvqirbQ4BUK3cgWo).replace("+",sCHVtMAvqirbQ4BUK3cgWo).replace("\n",sCHVtMAvqirbQ4BUK3cgWo).replace("\r",sCHVtMAvqirbQ4BUK3cgWo)
			LU4dFjp82qDtsz1OiJRTwB = nc3zm8T2VobipLPyJjdSH9AaWFtvG.split('.')
			Ml0wzrY8uFeLOaPQyxmbX9 = sCHVtMAvqirbQ4BUK3cgWo
			for VhB17esxEqD8lQSbUkm in LU4dFjp82qDtsz1OiJRTwB:
				Mly3bGKRHJTA01zeiLx = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(VhB17esxEqD8lQSbUkm+'==').decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
				j3jyGH6UEmk0JfVQq = fNntYJW45mEFSdRX8g.findall('\d+', Mly3bGKRHJTA01zeiLx, fNntYJW45mEFSdRX8g.S)
				if j3jyGH6UEmk0JfVQq:
					IWcdigKOxU6Ekbu8fY3e2D7 = int(j3jyGH6UEmk0JfVQq[BewrUo9ANCa17G43Sn0LH5xh])
					IWcdigKOxU6Ekbu8fY3e2D7 += int(CCgRTZGz1yDhk2aVHfM9SntX)
					Ml0wzrY8uFeLOaPQyxmbX9 = Ml0wzrY8uFeLOaPQyxmbX9 + chr(IWcdigKOxU6Ekbu8fY3e2D7)
			if I5VKjrFL0Bk97: Ml0wzrY8uFeLOaPQyxmbX9 = Ml0wzrY8uFeLOaPQyxmbX9.encode('iso-8859-1').decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	return Ml0wzrY8uFeLOaPQyxmbX9
def m7mdZMySHFgANK2tOxrV(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q,kkJoBAxwN3VrDH,c4yVMkzYb0,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs):
	yyJCfDW83PZHQx76qcspmeXTLN = int(kkJoBAxwN3VrDH%10)
	Wi8Izh1wT0aoryCMVDY2splStF9uc3 = int(kkJoBAxwN3VrDH/10)
	OhD2fSz5YEWLgAv8qM = ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,sCHVtMAvqirbQ4BUK3cgWo,ZQC69Pyo4BOamJlwSLtAWINg7q
	XHhlp8fFLq0JvCsO5tag1 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.status.menuscache')
	if not XHhlp8fFLq0JvCsO5tag1: fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.status.menuscache','AUTO')
	VCYw96jJq4Gk = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.status.refresh')
	kS9s3KBpxE548V2 = nnXGrIdCOuVxENgQz3lsckS(c4yVMkzYb0)
	EqdRSfJPH7OoMrNALuz = [BewrUo9ANCa17G43Sn0LH5xh,15,17,19,26,34,50,53]
	lXumYS2AReq = Wi8Izh1wT0aoryCMVDY2splStF9uc3 not in EqdRSfJPH7OoMrNALuz
	XGKCaHpnSD = Wi8Izh1wT0aoryCMVDY2splStF9uc3 in [23,28,71,72]
	ALRoV0sb75PxF = kkJoBAxwN3VrDH in [265,270]
	UU8715SsCl = (lXumYS2AReq or XGKCaHpnSD) and not ALRoV0sb75PxF
	vb3dyRgizEpwk8HP9Y6Qq4s0B = (VCYw96jJq4Gk or not IFYonX8LZUfz3VJyuQlxgE) and VCYw96jJq4Gk not in ['REFRESH_CACHE']+ZZmTYCnwygl3aXzbA2EJ9
	pByELAGHxqF5wn8j = 'type=' in VCYw96jJq4Gk
	NbmiB6v4gj = kkJoBAxwN3VrDH in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	RsxrGI1pcyY3UXTSLiC = yyJCfDW83PZHQx76qcspmeXTLN==9 or kkJoBAxwN3VrDH in [145,516,523,45]
	uq0c3FKIeN8UdfG1m56JAvaRyn = not NbmiB6v4gj
	t3XdlyqLpFc = not RsxrGI1pcyY3UXTSLiC
	OKYz3QW9py = kS9s3KBpxE548V2 in [sCHVtMAvqirbQ4BUK3cgWo,'..']
	LXdzBiF7RKVmAvnhkgp = OKYz3QW9py or uq0c3FKIeN8UdfG1m56JAvaRyn
	hvEIZ01f82B5nzyGla = OKYz3QW9py or t3XdlyqLpFc or pByELAGHxqF5wn8j
	a9p38GCSb6U04WAjzFkdRgMxlq5tv = kkJoBAxwN3VrDH not in [260,261,265,270,330,536,537,538,540,1010,1101,1103]
	if XHhlp8fFLq0JvCsO5tag1=='STOP': OM932yKULzb = RsxrGI1pcyY3UXTSLiC or NbmiB6v4gj
	else: OM932yKULzb = ndkUxG9LtewJ
	ZcUBy2Ff7rYA8EKz = Wi8Izh1wT0aoryCMVDY2splStF9uc3 in [74,75,108]
	NNWoe6OXEUlqk43Lh78ImczDG = kkJoBAxwN3VrDH in [280,720]
	vRnlbE1KaWt3ZiLcy75 = not ZcUBy2Ff7rYA8EKz and not NNWoe6OXEUlqk43Lh78ImczDG
	o7OWe5sfjbCNGqct6zuUmgrhpS = LXdzBiF7RKVmAvnhkgp and hvEIZ01f82B5nzyGla and a9p38GCSb6U04WAjzFkdRgMxlq5tv and OM932yKULzb and vRnlbE1KaWt3ZiLcy75
	QM2PzfUoVTJmZXGRNpWavY40D = a9p38GCSb6U04WAjzFkdRgMxlq5tv and OM932yKULzb and vRnlbE1KaWt3ZiLcy75
	XtlhpEmrFy40uMS = QM2PzfUoVTJmZXGRNpWavY40D
	YHakRg6Flvr4toSVswx3ubhTyPei = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.provider')
	ggbIlnr0tyfBACsaO3hERKVe7 = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting('av.language.code')
	oEl4uLWVdyhcOvIGtBzQ30x = lvzrYTpcBaK
	if vb3dyRgizEpwk8HP9Y6Qq4s0B and o7OWe5sfjbCNGqct6zuUmgrhpS:
		Q9hWn4j3BDLApkvU50P = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','MENUS_CACHE_'+YHakRg6Flvr4toSVswx3ubhTyPei+'_'+ggbIlnr0tyfBACsaO3hERKVe7,OhD2fSz5YEWLgAv8qM)
		if Q9hWn4j3BDLApkvU50P:
			SH6EVn0T9d8bKCUMLl1sJOFR(sCHVtMAvqirbQ4BUK3cgWo,'.\tMENUS_CACHE_'+YHakRg6Flvr4toSVswx3ubhTyPei+'_'+ggbIlnr0tyfBACsaO3hERKVe7+'   Loading menu from cache')
			if pByELAGHxqF5wn8j:
				hhdmnRVKkucb8w5QNq = []
				from E2mWUgOe8f import zyV0KWNRrFosC1bx7IXewiOYc
				from gRQYBo5zxp import MMsJqwRifEADm1P879,aQjwYZ6HEpTSActsI5Wl
				TTp6PVKQX1dbsNawYr = zyV0KWNRrFosC1bx7IXewiOYc
				PTHSKnRZIf3 = MMsJqwRifEADm1P879()
				EmepW16qtAN = VCYw96jJq4Gk
				OBcW0tUmNdxg36MIs9l7ebk2ywSoi,CfQkqBngJ8LOR7ViZzGj5H2PN,wOGgo7biXETAy1Yz0U6ZWfhs,zYZinAdeK9tWu8xchvL,GGdr0O32cAYiTge6HJQ,KoGOADzfisLJ419uwve,wqi16QEfcOCaVkhG,xonZY2v74B,CqzOAatQWX1KMPcr3Rgy = g5FNRVqWzdHSAZGuoMe1YxETD3h(EmepW16qtAN)
				vKF42BUmoYR0wzdPcWILrHJfT = OBcW0tUmNdxg36MIs9l7ebk2ywSoi,CfQkqBngJ8LOR7ViZzGj5H2PN,wOGgo7biXETAy1Yz0U6ZWfhs,zYZinAdeK9tWu8xchvL,GGdr0O32cAYiTge6HJQ,KoGOADzfisLJ419uwve,wqi16QEfcOCaVkhG,sCHVtMAvqirbQ4BUK3cgWo,CqzOAatQWX1KMPcr3Rgy
				for SE678YerhV0octBMOlqs in Q9hWn4j3BDLApkvU50P:
					xA032XTUv1SJlhIBywNcFqV = SE678YerhV0octBMOlqs['menuItem']
					if xA032XTUv1SJlhIBywNcFqV==vKF42BUmoYR0wzdPcWILrHJfT or SE678YerhV0octBMOlqs['mode'] in [265,270]:
						SE678YerhV0octBMOlqs = ssl5G716uoc(xA032XTUv1SJlhIBywNcFqV,TTp6PVKQX1dbsNawYr,PTHSKnRZIf3)
						if SE678YerhV0octBMOlqs['favorites']:
							xEh63Udg1IfFJSqOBKzRtLaiHm = aQjwYZ6HEpTSActsI5Wl(PTHSKnRZIf3,xA032XTUv1SJlhIBywNcFqV,SE678YerhV0octBMOlqs['newpath'])
							SE678YerhV0octBMOlqs['context_menu'] = xEh63Udg1IfFJSqOBKzRtLaiHm+SE678YerhV0octBMOlqs['context_menu']
					hhdmnRVKkucb8w5QNq.append(SE678YerhV0octBMOlqs)
				fDQNTKLnvHaWw2BEAIzg0FPMjyq.setSetting('av.status.refresh',sCHVtMAvqirbQ4BUK3cgWo)
				if ScEpZwINx93VJ5aWfb4=='folder': kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'MENUS_CACHE_'+YHakRg6Flvr4toSVswx3ubhTyPei+'_'+ggbIlnr0tyfBACsaO3hERKVe7,OhD2fSz5YEWLgAv8qM,hhdmnRVKkucb8w5QNq,NjPWfJS7CUoTsz4lKk0hg)
			else: hhdmnRVKkucb8w5QNq = Q9hWn4j3BDLApkvU50P
			if ScEpZwINx93VJ5aWfb4=='folder' and kS9s3KBpxE548V2!='..' and UU8715SsCl: ngmFwvKdSq4lNZoITsyJ3PGE2X6u()
			oEl4uLWVdyhcOvIGtBzQ30x = rfyFvhxA94H(OhD2fSz5YEWLgAv8qM,hhdmnRVKkucb8w5QNq,bEZlOa1inyrUgdTw9BKNtcMCLYI,n0I1sFqQjXcKMkl3fDWg,GGd83wRNLFMieC70vlxcWs)
	elif ScEpZwINx93VJ5aWfb4=='folder' and VCYw96jJq4Gk not in ['REFRESH_CACHE']+ZZmTYCnwygl3aXzbA2EJ9 and QM2PzfUoVTJmZXGRNpWavY40D:
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'MENUS_CACHE_'+YHakRg6Flvr4toSVswx3ubhTyPei+'_'+ggbIlnr0tyfBACsaO3hERKVe7,OhD2fSz5YEWLgAv8qM)
	return oEl4uLWVdyhcOvIGtBzQ30x,VCYw96jJq4Gk,OhD2fSz5YEWLgAv8qM,kS9s3KBpxE548V2,UU8715SsCl,XtlhpEmrFy40uMS,YHakRg6Flvr4toSVswx3ubhTyPei,ggbIlnr0tyfBACsaO3hERKVe7
def Wwod49PBvQO(ScEpZwINx93VJ5aWfb4,zz17bL8m9dw2kIcNqR5ortGiXnKj4,ZvWwXBJxzk3Qi9uAHKTD8hY2,GLrDUZJWtdSzaoeQNfw,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q):
	kkJoBAxwN3VrDH = int(GLrDUZJWtdSzaoeQNfw)
	Wi8Izh1wT0aoryCMVDY2splStF9uc3 = int(kkJoBAxwN3VrDH//10)
	if   Wi8Izh1wT0aoryCMVDY2splStF9uc3==BewrUo9ANCa17G43Sn0LH5xh:  from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:  from ms5uRvCM3J 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==rgpY5VUqKbeFOCD9Nki2SmGvxEja:  from ppqt7r6ZCE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==vUnJhT2NO8yirHcAmg:  from cZSK5HMeRw 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==kK7gj9HE462hADJbvr:  from jSQ1pFam8A 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,mRwrKW6fNZV)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==tBMCpcY2vUV1dEjZ7PDG:  from QQdkySvpmf 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==6:  from CCr6xo5qzU 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==7:  from Tj607v5yLp 			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==8:  from xb2NoaQ9Zy 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==9:  from cS5xb9FMyp		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==10: from ueZX4hr0sn 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==11: from n8RHJpFYok 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==12: from usqkUlxVwh 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==13: from nAUyG7RDzd		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==14: from QS6ZRAyXrc 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV,zz17bL8m9dw2kIcNqR5ortGiXnKj4,Qp3jGv8leCbuiEU5Im)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==15: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==16: from NbmiB6v4gj		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==17: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==18: from zPhl8d3j2c		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==19: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==20: from F9YthIPSBJ		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==21: from nE2ZGVzOhD	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==22: from ZFDkPVgTsz		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==23: from ebtl4A2fjS			import wLkpI14XdRKiGohZ; ka7jz96YCdTBnQOLVPuJG3285MHf = wLkpI14XdRKiGohZ(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==24: from jARZX7M1ml 			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==25: from wNUC3haOcZ 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==26: from E2mWUgOe8f 			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==27: from gRQYBo5zxp		import wLkpI14XdRKiGohZ; ka7jz96YCdTBnQOLVPuJG3285MHf = wLkpI14XdRKiGohZ(kkJoBAxwN3VrDH,IFYonX8LZUfz3VJyuQlxgE)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==28: from ebtl4A2fjS			import wLkpI14XdRKiGohZ; ka7jz96YCdTBnQOLVPuJG3285MHf = wLkpI14XdRKiGohZ(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==29: from jUrtF1V8fW	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==30: from l1lgZCVGrv		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==31: from XtYQV6UoLh		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==32: from Fu5bY3i9qa		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==33: from mJ8GoRh0Vl		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==34: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==35: from q2Z5n1Y0lG		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==36: from x9hXV5TpjR			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==37: from hhLbd2NzOM			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==38: from tiYMKpXwQd 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==39: from dmn76SaZ0E		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==40: from mf9uYb3GgD	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==41: from mf9uYb3GgD	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==42: from iZ67teKPJ2			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==43: from yMvNSb80wf			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==44: from JfPDVnRtmv		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==45: from X2ikalSeLH		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==46: from ygrODsPR43			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==47: from yhdRrYV18l		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==48: from q9qglSBkTG		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==49: from aaTnje6zcV		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==50: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==51: from xwcG7MVrQW 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==52: from xwcG7MVrQW 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==53: from E2mWUgOe8f 			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==54: from PG9FRcxAEz	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,mRwrKW6fNZV)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==55: from F9iSmYecgb 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==56: from p917vUklSE		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==57: from AjNmfn13zT		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==58: from W8pDvYTJXN		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==59: from V7UpJAqcw2		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==60: from FWPvQSmib2			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==61: from XHGUixIV15			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==62: from EES5aBWVF2		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==63: from rdOtXv5GaM	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==64: from q0Y34fJ7Uc			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==65: from LVRH6rwKZs			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==66: from u9XB0pRhsC			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==67: from LLxy1itIZw		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==68: from sP3HGvTXiC		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==69: from xpnBkIXMyR		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==70: from zqxwGS0RVE			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==71: from Sce6q5zwUj			import wLkpI14XdRKiGohZ; ka7jz96YCdTBnQOLVPuJG3285MHf = wLkpI14XdRKiGohZ(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==72: from Sce6q5zwUj			import wLkpI14XdRKiGohZ; ka7jz96YCdTBnQOLVPuJG3285MHf = wLkpI14XdRKiGohZ(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,ScEpZwINx93VJ5aWfb4,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==73: from mkoePUv2GJ	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==74: from vMJ3Q54rbl		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==75: from vMJ3Q54rbl		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==76: from NbmiB6v4gj		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF,mRwrKW6fNZV,ZQC69Pyo4BOamJlwSLtAWINg7q)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==77: from pptqZhrQWd 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==78: from z8Zxb5UIV6 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==79: from TAFQaICyVY 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==80: from JJpkL4ZuSH 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==81: from PrAIsOzcUJ 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==82: from QEwz0xoOij		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,mRwrKW6fNZV,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==83: from RXNoxvIq0f		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==84: from BnFQtDGrve		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==85: from PPy8eUQk7I		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==86: from XWpCdiOMY7		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==87: from GU5gDRVTpP			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==88: from Sd1Nl0aFVK			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==89: from bJxvjiPuw9		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==90: from So1tmHRnIe	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==91: from vOduzMJrZE		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==92: from FDXgRQWdmE		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==93: from NK9LFjVnrW		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==94: from RPH2VIMztg			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==95: from ZcfKHF79DV			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==96: from G7GM8rJD5L		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==97: from f4GMVdHIem		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==98: from J3ZvWq0ipG		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==99: from VXe9Ul7Oa5		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==100: from cqd2Poybkf		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==101: from Im8RhG6yKo	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==102: from i5kNU6T7vE 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==103: from OxXZUQmTly	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==104: from NdFX5QSV3L		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==105: from mfFJQNIMUj			import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==106: from KVZaNo2zEF		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==107: from ncL0p324ZN		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==108: from vMJ3Q54rbl		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==109: from ocIxB1kEzR 	import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	elif Wi8Izh1wT0aoryCMVDY2splStF9uc3==110: from E2mWUgOe8f 		import dBHD1Vl7hQuNOY	; ka7jz96YCdTBnQOLVPuJG3285MHf = dBHD1Vl7hQuNOY(kkJoBAxwN3VrDH,ZvWwXBJxzk3Qi9uAHKTD8hY2,TqNvzBxf1KpPDg3SRA4yj2mwcVF)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = None
	return ka7jz96YCdTBnQOLVPuJG3285MHf
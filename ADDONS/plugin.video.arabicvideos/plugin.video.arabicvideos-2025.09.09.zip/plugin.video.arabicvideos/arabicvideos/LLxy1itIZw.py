# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'KATKOUTE'
Z0BYJQghVL1v87CAem = '_KTK_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الصفحة الرئيسية','Sign in','الأقسام']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==670: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==671: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==672: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==673: ka7jz96YCdTBnQOLVPuJG3285MHf = E5mTvMgjPFJKs1noB7we8i(url,text)
	elif mode==674: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==679: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,679,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"navslide-divider"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,mode)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	items = MpKIfTitvZC2YxsD(gAVl1vUmus8+'/watch/browse.html')
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,674,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def MpKIfTitvZC2YxsD(url):
	tF8cULEI3N7 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','KATKOUTE','CATEGORIES')
	if tF8cULEI3N7: return tF8cULEI3N7
	tF8cULEI3N7 = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-CATEGORIES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"category-header"(.*?)<footer>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		tF8cULEI3N7 = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if tF8cULEI3N7: kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'KATKOUTE','CATEGORIES',tF8cULEI3N7,OOht4Ly9dmZMIz)
	return tF8cULEI3N7
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"presentation"','</ul>')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = [(sCHVtMAvqirbQ4BUK3cgWo,Po9h3gWFuLR2)]
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' فرز أو فلتر أو ترتيب '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		for J8noyr10GLB9exORpmSIHTWiFPc,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if J8noyr10GLB9exORpmSIHTWiFPc: J8noyr10GLB9exORpmSIHTWiFPc = J8noyr10GLB9exORpmSIHTWiFPc+': '
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = J8noyr10GLB9exORpmSIHTWiFPc+title
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,671)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"pm-category-subcats"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)<30:
			XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			for B17r2fdFy9ns8tiOMLu,title in items:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,671)
	if not GzRKsiw5PBIe1NlrqmQy9STx and not iUtXlDhSVoBZJrPTQAwcER9nfMkN: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',url,data,headers,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-TITLES-1st')
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-TITLES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	Po9h3gWFuLR2,items = sCHVtMAvqirbQ4BUK3cgWo,[]
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	if n1WYDtVC8dRHbXJkMa=='ajax-search':
		Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	elif n1WYDtVC8dRHbXJkMa=='featured':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pm-video-watch-featured"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_episodes':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	elif n1WYDtVC8dRHbXJkMa=='new_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-ul-browse-videos(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if len(oPnz7Zt4xLHTwR)>1: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
	elif n1WYDtVC8dRHbXJkMa=='featured_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Y0WVJ5CTpDO = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in Y0WVJ5CTpDO: items.append((sCHVtMAvqirbQ4BUK3cgWo,B17r2fdFy9ns8tiOMLu,title))
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(data-echo=".*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR: Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if Po9h3gWFuLR2 and not items: items = fNntYJW45mEFSdRX8g.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: return
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,672,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif n1WYDtVC8dRHbXJkMa=='new_episodes':
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,672,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,673,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movseries/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,671,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,673,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if B17r2fdFy9ns8tiOMLu=='#': continue
			if 'http' not in B17r2fdFy9ns8tiOMLu:
				vrEJRkchKxtDNiqO1b79mL5eT = url.rsplit('/',1)[0]
				B17r2fdFy9ns8tiOMLu = vrEJRkchKxtDNiqO1b79mL5eT+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,671,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,n1WYDtVC8dRHbXJkMa)
	return
def E5mTvMgjPFJKs1noB7we8i(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+'تشغيل الفيديو',url,672)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	tF8cULEI3N7 = MpKIfTitvZC2YxsD(gAVl1vUmus8+'/watch/browse.html')
	IdQL9bcisSnjpm,WEKxVDgnsvtGcaMu85jQqrh,fFKmMBZCgvP4q89 = zip(*tF8cULEI3N7)
	op76dMJmVLYAFGZyj = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-EPISODES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"row pm-video-heading"(.*?)id="player"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in PXFtqmw5lBGQNa0IV8:
			if B17r2fdFy9ns8tiOMLu not in IdQL9bcisSnjpm:
				UqKgalXPCz7eQAL08foMx1R = (B17r2fdFy9ns8tiOMLu,title)
				op76dMJmVLYAFGZyj.append(UqKgalXPCz7eQAL08foMx1R)
		if len(op76dMJmVLYAFGZyj)==1:
			B17r2fdFy9ns8tiOMLu,title = op76dMJmVLYAFGZyj[0]
			fs7D0d3QyAT(B17r2fdFy9ns8tiOMLu,'new_episodes')
			return
		else:
			for B17r2fdFy9ns8tiOMLu,title in op76dMJmVLYAFGZyj:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,671,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'new_episodes')
	if not op76dMJmVLYAFGZyj: fs7D0d3QyAT(url,'new_episodes')
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'KATKOUTE-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('sources:(.*?)flashplayer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('file: "(.*?)".*?label: "(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA in PXFtqmw5lBGQNa0IV8:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named=__watch__'+XO7Zr2W6kwieA
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('"embedded-video".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not PXFtqmw5lBGQNa0IV8: PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall("file: '(.*?)'",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if PXFtqmw5lBGQNa0IV8:
		B17r2fdFy9ns8tiOMLu = PXFtqmw5lBGQNa0IV8[0]
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named=__embed')
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/watch/search.php?keywords='+search
	fs7D0d3QyAT(url,'search')
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHOOFNET'
Z0BYJQghVL1v87CAem = '_SNT_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الرئيسية','يلا شوت','دكتنا','فيديو نسائم']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==840: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==841: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==842: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==843: ka7jz96YCdTBnQOLVPuJG3285MHf = ddDLz2MFtS9Irsy5gi7CwvJ8c(url)
	elif mode==849: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFNET-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,849,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"primary-links"(.*?)</u',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,841)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"list-categories"(.*?)</u',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,841)
	return
def fs7D0d3QyAT(url,ScEpZwINx93VJ5aWfb4=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFNET-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"home-content"(.*?)"footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('"overlay"','"duration"><')
		items = fNntYJW45mEFSdRX8g.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8,B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(' ')
			title = tt36wUe4HTPFmfs5hcbr(title)
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة).\d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if 'episodes' not in ScEpZwINx93VJ5aWfb4 and bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
				title = title.replace('اون لاين',sCHVtMAvqirbQ4BUK3cgWo)
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,843,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,842,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,yAMScJ6z3E8)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('''["']pagination["'](.*?)["']footer["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		ScEpZwINx93VJ5aWfb4 = 'episodes_pages' if 'episodes' in ScEpZwINx93VJ5aWfb4 else 'pages'
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,841,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ScEpZwINx93VJ5aWfb4)
	return
def ddDLz2MFtS9Irsy5gi7CwvJ8c(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFNET-SERIES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"category".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu: fs7D0d3QyAT(B17r2fdFy9ns8tiOMLu[0],'episodes')
	return
def YH54mqkD2eU06(url):
	cb1fAztguv78n9LGhSWJFm5p = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFNET-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	uu4UgsMj01aImASoXpYDO9iQcfG = fNntYJW45mEFSdRX8g.findall("var post_id	= '(.*?)'",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if uu4UgsMj01aImASoXpYDO9iQcfG:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/wp-admin/admin-ajax.php?action=video_info&post_id='+uu4UgsMj01aImASoXpYDO9iQcfG[0]
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFNET-PLAY-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		items = fNntYJW45mEFSdRX8g.findall('"name":"(.*?)","src":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			title = EEH4kBfGY0FuZUjeNn(title)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('\\/','/')
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	url = gAVl1vUmus8+'/?s='+search
	fs7D0d3QyAT(url,'search')
	return
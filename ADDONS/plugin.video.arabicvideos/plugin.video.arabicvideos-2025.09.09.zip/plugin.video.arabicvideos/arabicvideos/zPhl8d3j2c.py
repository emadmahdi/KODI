# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'MOVIZLAND'
headers = { 'User-Agent' : sCHVtMAvqirbQ4BUK3cgWo }
Z0BYJQghVL1v87CAem = '_MVZ_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
DbmJ9I0ZfXgcFlO8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][1]
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==180: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==181: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==182: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==183: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==188: ka7jz96YCdTBnQOLVPuJG3285MHf = mqWXn7kf4l3Q5sOtuzZP()
	elif mode==189: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def mqWXn7kf4l3Q5sOtuzZP():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,message)
	return
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,189,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'بوكس اوفيس موفيز لاند',gAVl1vUmus8,181,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'box-office')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أحدث الافلام',gAVl1vUmus8,181,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'latest-movies')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'تليفزيون موفيز لاند',gAVl1vUmus8,181,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'tv')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الاكثر مشاهدة',gAVl1vUmus8,181,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'top-views')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أقوى الافلام الحالية',gAVl1vUmus8,181,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'top-movies')
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-MENU-1st')
	items = fNntYJW45mEFSdRX8g.findall('<h2><a href="(.*?)".*?">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,181)
	return Sw0pOFoVhPeIxbl
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	elif type=='box-office': Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	elif type=='top-movies': Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('btn-2-overlay(.*?)<style>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	elif type=='top-views': Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	elif type=='tv': Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	else: Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
	if type in ['top-views','top-movies']:
		items = fNntYJW45mEFSdRX8g.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	else: items = fNntYJW45mEFSdRX8g.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	a4NmDS7WutoLk = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa,xx70Ghuj86CrSbqlPi2DeHJT in items:
		if type in ['top-views','top-movies']:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,NroHCBWaxUZOfbgqMzAL4vJ2,title = Mx0TQvmZAsedaGj4opVDJu5by8RUwS,YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa,xx70Ghuj86CrSbqlPi2DeHJT
		else: Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,B17r2fdFy9ns8tiOMLu,NroHCBWaxUZOfbgqMzAL4vJ2 = Mx0TQvmZAsedaGj4opVDJu5by8RUwS,YUjl8EuWXnh47ZrA90xKztRMVLeGd,oFtKYZryln32AsLqcjBgWODwpa,xx70Ghuj86CrSbqlPi2DeHJT
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('?view=true',sCHVtMAvqirbQ4BUK3cgWo)
		title = tt36wUe4HTPFmfs5hcbr(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',sCHVtMAvqirbQ4BUK3cgWo).replace('بجوده ',sCHVtMAvqirbQ4BUK3cgWo)
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if 'الحلقة' in title or 'الحلقه' in title:
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|الحلقه) \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if bbFPOJrmkCaE6ul37XiKU:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0][0]
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,183,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif any(value in title for value in a4NmDS7WutoLk):
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu + '?servers=' + NroHCBWaxUZOfbgqMzAL4vJ2
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,182,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu + '?servers=' + NroHCBWaxUZOfbgqMzAL4vJ2
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,183,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if type==sCHVtMAvqirbQ4BUK3cgWo:
		items = fNntYJW45mEFSdRX8g.findall('\n<li><a href="(.*?)".*?>(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = tt36wUe4HTPFmfs5hcbr(title)
			title = title.replace('الصفحة ',sCHVtMAvqirbQ4BUK3cgWo)
			if title!=sCHVtMAvqirbQ4BUK3cgWo:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,181)
	return
def VzOBjnIkZSH7ft(url):
	vrEJRkchKxtDNiqO1b79mL5eT = url.split('?servers=')[0]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-EPISODES-1st')
	Po9h3gWFuLR2 = fNntYJW45mEFSdRX8g.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	title,qLbRrEtgenpSi,Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Po9h3gWFuLR2[0]
	name = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,fNntYJW45mEFSdRX8g.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="episodesNumbers"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu in items:
			B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
			title = fNntYJW45mEFSdRX8g.findall('(الحلقة|الحلقه)-([0-9]+)',B17r2fdFy9ns8tiOMLu.split('/')[-2],fNntYJW45mEFSdRX8g.DOTALL)
			if not title: title = fNntYJW45mEFSdRX8g.findall('()-([0-9]+)',B17r2fdFy9ns8tiOMLu.split('/')[-2],fNntYJW45mEFSdRX8g.DOTALL)
			if title: title = AAh0X3OCacr4HpifRGLZKT + title[0][1]
			else: title = sCHVtMAvqirbQ4BUK3cgWo
			title = name + ' - ' + 'الحلقة' + title
			title = tt36wUe4HTPFmfs5hcbr(title)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,182,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if not items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',sCHVtMAvqirbQ4BUK3cgWo).replace('بجوده ',sCHVtMAvqirbQ4BUK3cgWo)
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,182,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	fH6PnGusaZ4M0Vb = url.split('?servers=')
	vrEJRkchKxtDNiqO1b79mL5eT = fH6PnGusaZ4M0Vb[0]
	del fH6PnGusaZ4M0Vb[0]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-PLAY-1st')
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('font-size: 25px;" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	if B17r2fdFy9ns8tiOMLu not in fH6PnGusaZ4M0Vb: fH6PnGusaZ4M0Vb.append(B17r2fdFy9ns8tiOMLu)
	ss7YGDbuAIxgnqaQroTV = []
	for B17r2fdFy9ns8tiOMLu in fH6PnGusaZ4M0Vb:
		if '://moshahda.' in B17r2fdFy9ns8tiOMLu:
			Gqpm5hXDUSf3jAudELZtbxWBMavn = B17r2fdFy9ns8tiOMLu
			ss7YGDbuAIxgnqaQroTV.append(Gqpm5hXDUSf3jAudELZtbxWBMavn+'?named=Main')
	for B17r2fdFy9ns8tiOMLu in fH6PnGusaZ4M0Vb:
		if '://vb.movizland.' in B17r2fdFy9ns8tiOMLu:
			Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,B17r2fdFy9ns8tiOMLu,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-PLAY-2nd')
			Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.decode(c3dXNBfyhSZCow1ia0RjVWUOg9).encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			Sw0pOFoVhPeIxbl = Sw0pOFoVhPeIxbl.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			if oPnz7Zt4xLHTwR:
				Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb,EPhoOUqS1MxVfbR8s6gud = [],[]
				if len(oPnz7Zt4xLHTwR)==1:
					title = sCHVtMAvqirbQ4BUK3cgWo
					Po9h3gWFuLR2 = Sw0pOFoVhPeIxbl
				else:
					for Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
						MtCcgLOoBTGp4nqzVhYJliX8Zva6s = fNntYJW45mEFSdRX8g.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
						if MtCcgLOoBTGp4nqzVhYJliX8Zva6s: Po9h3gWFuLR2 = 'src="/uploads/13721411411.png"  \n  ' + MtCcgLOoBTGp4nqzVhYJliX8Zva6s[0][1]
						MtCcgLOoBTGp4nqzVhYJliX8Zva6s = fNntYJW45mEFSdRX8g.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
						if MtCcgLOoBTGp4nqzVhYJliX8Zva6s: Po9h3gWFuLR2 = 'src="/uploads/13721411411.png"  \n  ' + MtCcgLOoBTGp4nqzVhYJliX8Zva6s[0]
						MtCcgLOoBTGp4nqzVhYJliX8Zva6s = fNntYJW45mEFSdRX8g.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
						if MtCcgLOoBTGp4nqzVhYJliX8Zva6s: Po9h3gWFuLR2 = MtCcgLOoBTGp4nqzVhYJliX8Zva6s[0] + '  \n  src="/uploads/13721411411.png"'
						kc9l1YL05uI4XZ3zHCANM6bpD = fNntYJW45mEFSdRX8g.findall('<(.*?)http://up.movizland.(online|com)/uploads/',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
						title = fNntYJW45mEFSdRX8g.findall('> *([^<>]+) *<',kc9l1YL05uI4XZ3zHCANM6bpD[0][0],fNntYJW45mEFSdRX8g.DOTALL)
						title = AAh0X3OCacr4HpifRGLZKT.join(title)
						title = title.strip(AAh0X3OCacr4HpifRGLZKT)
						title = title.replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
						Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb.append(title)
					jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('أختر الفيديو المطلوب:', Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb)
					if jQLzA92KFEcpw == -1 : return
					title = Z8Z2veNVnHFt3yDIU7z5hJaEXrOCb[jQLzA92KFEcpw]
					Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[jQLzA92KFEcpw]
				B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('href="(http://moshahda\..*?/\w+.html)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				XLEC8NvlPhiU51d4Wtmw9jIOHB = B17r2fdFy9ns8tiOMLu[0]
				ss7YGDbuAIxgnqaQroTV.append(XLEC8NvlPhiU51d4Wtmw9jIOHB+'?named=Forum')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('ـ',sCHVtMAvqirbQ4BUK3cgWo)
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Po9h3gWFuLR2 = Po9h3gWFuLR2.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				IaDq5nCf08P3tMhRJB6omrUHF7jZ = fNntYJW45mEFSdRX8g.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
				for rCgcPVJYqkTLnydS13 in IaDq5nCf08P3tMhRJB6omrUHF7jZ:
					type = fNntYJW45mEFSdRX8g.findall(' typetype="(.*?)" ',rCgcPVJYqkTLnydS13)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = sCHVtMAvqirbQ4BUK3cgWo
					items = fNntYJW45mEFSdRX8g.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',rCgcPVJYqkTLnydS13,fNntYJW45mEFSdRX8g.DOTALL)
					for y1kME3o6geAhGIauQ8bnciHW,B17r2fdFy9ns8tiOMLu in items:
						title = fNntYJW45mEFSdRX8g.findall('(\w+[ \w]*)<',y1kME3o6geAhGIauQ8bnciHW)
						title = title[-1]
						B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu + '?named=' + title + type
						ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	rdQ5tOIzuelfvcYbNsM = vrEJRkchKxtDNiqO1b79mL5eT.replace(gAVl1vUmus8,DbmJ9I0ZfXgcFlO8)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-PLAY-3rd')
	items = fNntYJW45mEFSdRX8g.findall('" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		BcRuPxZQ0hOEl3fJ4TGwm = items[-1]
		ss7YGDbuAIxgnqaQroTV.append(BcRuPxZQ0hOEl3fJ4TGwm+'?named=Mobile')
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,headers,sCHVtMAvqirbQ4BUK3cgWo,'MOVIZLAND-SEARCH-1st')
	items = fNntYJW45mEFSdRX8g.findall('<option value="(.*?)">(.*?)</option>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Hd85VysXBIoUpn6eDF2ZA3rGwOY = [ sCHVtMAvqirbQ4BUK3cgWo ]
	HJn8RBau4CU1hoPZWyQclD = [ 'الكل وبدون فلتر' ]
	for B4SziFvRIXpPeGmfZDw3aVWJMAKNc,title in items:
		Hd85VysXBIoUpn6eDF2ZA3rGwOY.append(B4SziFvRIXpPeGmfZDw3aVWJMAKNc)
		HJn8RBau4CU1hoPZWyQclD.append(title)
	if B4SziFvRIXpPeGmfZDw3aVWJMAKNc:
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('اختر الفلتر المناسب:', HJn8RBau4CU1hoPZWyQclD)
		if jQLzA92KFEcpw == -1 : return
		B4SziFvRIXpPeGmfZDw3aVWJMAKNc = Hd85VysXBIoUpn6eDF2ZA3rGwOY[jQLzA92KFEcpw]
	else: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = sCHVtMAvqirbQ4BUK3cgWo
	url = gAVl1vUmus8 + '/?s='+search+'&mcat='+B4SziFvRIXpPeGmfZDw3aVWJMAKNc
	fs7D0d3QyAT(url)
	return
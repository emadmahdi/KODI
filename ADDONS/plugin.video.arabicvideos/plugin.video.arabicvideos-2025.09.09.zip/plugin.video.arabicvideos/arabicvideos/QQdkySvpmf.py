# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHOOFMAX'
Z0BYJQghVL1v87CAem = '_SHM_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
DbmJ9I0ZfXgcFlO8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][1]
RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][2]
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==50: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==51: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==52: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==53: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==55: ka7jz96YCdTBnQOLVPuJG3285MHf = AAB3dgpTGwqbtrcHXP7hJof()
	elif mode==56: ka7jz96YCdTBnQOLVPuJG3285MHf = M0pz1KutBDqkovIxGyhifVUAs()
	elif mode==57: ka7jz96YCdTBnQOLVPuJG3285MHf = jWXMJvDftU2zxVTh9G3QE7oZ0B(url,1)
	elif mode==58: ka7jz96YCdTBnQOLVPuJG3285MHf = jWXMJvDftU2zxVTh9G3QE7oZ0B(url,2)
	elif mode==59: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,59,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المسلسلات',sCHVtMAvqirbQ4BUK3cgWo,56)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الافلام',sCHVtMAvqirbQ4BUK3cgWo,55)
	return sCHVtMAvqirbQ4BUK3cgWo
def AAB3dgpTGwqbtrcHXP7hJof():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أفلام مرتبة بسنة الإنتاج',gAVl1vUmus8+'/movie/1/yop',57)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أفلام مرتبة بالأفضل تقييم',gAVl1vUmus8+'/movie/1/review',57)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أفلام مرتبة بالأكثر مشاهدة',gAVl1vUmus8+'/movie/1/views',57)
	return
def M0pz1KutBDqkovIxGyhifVUAs():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات مرتبة بسنة الإنتاج',gAVl1vUmus8+'/series/1/yop',57)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات مرتبة بالأفضل تقييم',gAVl1vUmus8+'/series/1/review',57)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسلات مرتبة بالأكثر مشاهدة',gAVl1vUmus8+'/series/1/views',57)
	return
def fs7D0d3QyAT(url):
	if '?' in url:
		cuIJ3axEtVWvs = url.split('?')
		url = cuIJ3axEtVWvs[0]
		filter = '?' + IgCGzHw45TJ7PeuO1EKl(cuIJ3axEtVWvs[1],'=&:/%')
	else: filter = sCHVtMAvqirbQ4BUK3cgWo
	type,mRwrKW6fNZV,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': RvEJc0WgkhHQ29U743OKZa='فيلم'
		elif type=='series': RvEJc0WgkhHQ29U743OKZa='مسلسل'
		url = gAVl1vUmus8 + '/genre/filter/' + IgCGzHw45TJ7PeuO1EKl(RvEJc0WgkhHQ29U743OKZa) + '/' + mRwrKW6fNZV + '/' + sort + filter
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-TITLES-1st')
		items = fNntYJW45mEFSdRX8g.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		eGmij1zPJBMQlaIcp=0
		for id,title,RCyF19tAUB7fW4caeZIVrdHSjYi,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			eGmij1zPJBMQlaIcp += 1
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f + '/v2/img/program/main/' + Mx0TQvmZAsedaGj4opVDJu5by8RUwS + '-2.jpg'
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + '/program/' + id
			if type=='movie': XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,53,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			if type=='series': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسل '+title,B17r2fdFy9ns8tiOMLu+'?ep='+RCyF19tAUB7fW4caeZIVrdHSjYi+'='+title+'='+Mx0TQvmZAsedaGj4opVDJu5by8RUwS,52,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		if type=='movie': RvEJc0WgkhHQ29U743OKZa='movies'
		elif type=='series': RvEJc0WgkhHQ29U743OKZa='series'
		url = DbmJ9I0ZfXgcFlO8 + '/json/selected/' + sort + '-' + RvEJc0WgkhHQ29U743OKZa + '-WW.json'
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-TITLES-2nd')
		items = fNntYJW45mEFSdRX8g.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		eGmij1zPJBMQlaIcp=0
		for id,RCyF19tAUB7fW4caeZIVrdHSjYi,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			eGmij1zPJBMQlaIcp += 1
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = DbmJ9I0ZfXgcFlO8 + '/img/program/' + Mx0TQvmZAsedaGj4opVDJu5by8RUwS + '-2.jpg'
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + '/program/' + id
			if type=='movie': XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,53,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			elif type=='series': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مسلسل '+title,B17r2fdFy9ns8tiOMLu+'?ep='+RCyF19tAUB7fW4caeZIVrdHSjYi+'='+title+'='+Mx0TQvmZAsedaGj4opVDJu5by8RUwS,52,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	title='صفحة '
	if eGmij1zPJBMQlaIcp==16:
		for D87M5ZyVCNoJbehEpsY3luRKaF in range(1,13) :
			if not mRwrKW6fNZV==str(D87M5ZyVCNoJbehEpsY3luRKaF):
				url = gAVl1vUmus8+'/genre/filter/'+type+'/'+str(D87M5ZyVCNoJbehEpsY3luRKaF)+'/'+sort+filter
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title+str(D87M5ZyVCNoJbehEpsY3luRKaF),url,51)
	return
def VzOBjnIkZSH7ft(url):
	cuIJ3axEtVWvs = url.split('=')
	RCyF19tAUB7fW4caeZIVrdHSjYi = int(cuIJ3axEtVWvs[1])
	name = mSeoVfgRpNF9PKrJ(cuIJ3axEtVWvs[2])
	name = name.replace('_MOD_مسلسل ',sCHVtMAvqirbQ4BUK3cgWo)
	Mx0TQvmZAsedaGj4opVDJu5by8RUwS = cuIJ3axEtVWvs[3]
	url = url.split('?')[0]
	if RCyF19tAUB7fW4caeZIVrdHSjYi==0:
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-EPISODES-1st')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<select(.*?)</select>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('option value="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		RCyF19tAUB7fW4caeZIVrdHSjYi = int(items[-1])
	for bbFPOJrmkCaE6ul37XiKU in range(RCyF19tAUB7fW4caeZIVrdHSjYi,0,-1):
		B17r2fdFy9ns8tiOMLu = url + '?ep=' + str(bbFPOJrmkCaE6ul37XiKU)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(bbFPOJrmkCaE6ul37XiKU)
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,53,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-PLAY-1st')
	ce3wVCimxYKSNq1Iv = fNntYJW45mEFSdRX8g.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if ce3wVCimxYKSNq1Iv:
		hDjf1Ubgq629nXlOvcFLH4Jw = ce3wVCimxYKSNq1Iv[1].replace('T',bRa9TlJO4fPdsUAj)
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+slFfrUIWCowaBA7tce3iZbj8xn+hDjf1Ubgq629nXlOvcFLH4Jw)
		return
	n2nogshaiX4cLK6,ViU6N4Zroqf = [],[]
	AODtGXp2sYUn = fNntYJW45mEFSdRX8g.findall('var origin_link = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	wjVpJGRLO1bDWKiYSTZxHvfCnqrFol = fNntYJW45mEFSdRX8g.findall('var backup_origin_link = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)[0]
	PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('hls: (.*?)_link\+"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for smh8Qbf9jH,B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
		if 'backup' in smh8Qbf9jH:
			smh8Qbf9jH = 'backup server'
			url = wjVpJGRLO1bDWKiYSTZxHvfCnqrFol + B17r2fdFy9ns8tiOMLu
		else:
			smh8Qbf9jH = 'main server'
			url = AODtGXp2sYUn + B17r2fdFy9ns8tiOMLu
		if '.m3u8' in url:
			n2nogshaiX4cLK6.append(url)
			ViU6N4Zroqf.append('m3u8  '+smh8Qbf9jH)
	PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	PXFtqmw5lBGQNa0IV8 += fNntYJW45mEFSdRX8g.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for smh8Qbf9jH,B17r2fdFy9ns8tiOMLu in PXFtqmw5lBGQNa0IV8:
		filename = B17r2fdFy9ns8tiOMLu.split('/')[-1]
		filename = filename.replace('fallback',sCHVtMAvqirbQ4BUK3cgWo)
		filename = filename.replace('.mp4',sCHVtMAvqirbQ4BUK3cgWo)
		filename = filename.replace('-',sCHVtMAvqirbQ4BUK3cgWo)
		if 'backup' in smh8Qbf9jH:
			smh8Qbf9jH = 'backup server'
			url = wjVpJGRLO1bDWKiYSTZxHvfCnqrFol + B17r2fdFy9ns8tiOMLu
		else:
			smh8Qbf9jH = 'main server'
			url = AODtGXp2sYUn + B17r2fdFy9ns8tiOMLu
		n2nogshaiX4cLK6.append(url)
		ViU6N4Zroqf.append('mp4  '+smh8Qbf9jH+LvzD9S8RPyGeukZQqb2T0B+filename)
	jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('Select Video Quality:', ViU6N4Zroqf)
	if jQLzA92KFEcpw == -1 : return
	url = n2nogshaiX4cLK6[jQLzA92KFEcpw]
	CeXLtzElr5DHhs(url,Ll1m0nJoaAPvHsXqyRE,'video')
	return
def jWXMJvDftU2zxVTh9G3QE7oZ0B(url,type):
	if 'series' in url: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8 + '/genre/مسلسل'
	else: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8 + '/genre/فيلم'
	vrEJRkchKxtDNiqO1b79mL5eT = IgCGzHw45TJ7PeuO1EKl(vrEJRkchKxtDNiqO1b79mL5eT)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-FILTERS-1st')
	if type==1: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('subgenre(.*?)div',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	elif type==2: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('country(.*?)div',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('option value="(.*?)">(.*?)</option',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if type==1:
		for gwN7XGHBi9To6e3V2SR0l,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url+'?subgenre='+gwN7XGHBi9To6e3V2SR0l,58)
	elif type==2:
		url,gwN7XGHBi9To6e3V2SR0l = url.split('?')
		for AAegc4nriYPDjplE2FToBqG5xsWv,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url+'?country='+AAegc4nriYPDjplE2FToBqG5xsWv+'&'+gwN7XGHBi9To6e3V2SR0l,51)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search: search = UyBdvjGrFxDWMpmLOXn()
	if not search: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	url = gAVl1vUmus8+'/search?q='+ktT4O0VJm8UaDNlxKvinoBYFgdH
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,sCHVtMAvqirbQ4BUK3cgWo,'SHOOFMAX-SEARCH-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('general-body(.*?)search-bottom-padding',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			url = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+IgCGzHw45TJ7PeuO1EKl(title)+'='+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,52,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				else:
					title = '_MOD_فيلم '+title
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,53,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
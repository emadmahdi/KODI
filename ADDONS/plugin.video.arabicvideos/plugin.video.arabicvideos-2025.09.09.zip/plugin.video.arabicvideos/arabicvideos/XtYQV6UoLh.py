# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'SHIAVOICE'
Z0BYJQghVL1v87CAem = '_SHV_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
headers = {'User-Agent':None}
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==310: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==311: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==312: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==313: ka7jz96YCdTBnQOLVPuJG3285MHf = wYhv0GCQL8r(url)
	elif mode==314: ka7jz96YCdTBnQOLVPuJG3285MHf = dh1kDr9texw6szfNu(text)
	elif mode==319: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,319,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="menulinks"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	items = fNntYJW45mEFSdRX8g.findall('<h5>(.*?)</h5>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
	for nkjHK2zQeb4vBuoaxPZTqIALW5S1 in range(len(items)):
		title = items[nkjHK2zQeb4vBuoaxPZTqIALW5S1].strip(AAh0X3OCacr4HpifRGLZKT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,gAVl1vUmus8,314,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,str(nkjHK2zQeb4vBuoaxPZTqIALW5S1+1))
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'مقاطع شهر',gAVl1vUmus8,314,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'0')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<B>(.*?)</B>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,311)
	return Sw0pOFoVhPeIxbl
def dh1kDr9texw6szfNu(nkjHK2zQeb4vBuoaxPZTqIALW5S1):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-LATEST-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if nkjHK2zQeb4vBuoaxPZTqIALW5S1=='0':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="tab-content"(.*?)</table>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name,title in items:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			name = name.strip(AAh0X3OCacr4HpifRGLZKT)
			title = title+' ('+name+')'
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312)
	elif nkjHK2zQeb4vBuoaxPZTqIALW5S1 in ['1','2','3']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(<h5>.*?)<div class="col-lg',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Nm1vT6ZIB0M2bqkaW95 = int(nkjHK2zQeb4vBuoaxPZTqIALW5S1)-1
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[Nm1vT6ZIB0M2bqkaW95]
		if nkjHK2zQeb4vBuoaxPZTqIALW5S1=='1': items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		else: items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,name in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = gAVl1vUmus8+'/'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			name = name.strip(AAh0X3OCacr4HpifRGLZKT)
			title = title+' ('+name+')'
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,311,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif nkjHK2zQeb4vBuoaxPZTqIALW5S1 in ['4','5','6']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(<h5>.*?)</table>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		nkjHK2zQeb4vBuoaxPZTqIALW5S1 = int(nkjHK2zQeb4vBuoaxPZTqIALW5S1)-4
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[nkjHK2zQeb4vBuoaxPZTqIALW5S1]
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,wrvU1Ey2cBPqOW5QRJpdDt,title,XXqGLnKo8vWYh1IMz9C0 in items:
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = gAVl1vUmus8+'/'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			wrvU1Ey2cBPqOW5QRJpdDt = wrvU1Ey2cBPqOW5QRJpdDt.strip(AAh0X3OCacr4HpifRGLZKT)
			XXqGLnKo8vWYh1IMz9C0 = XXqGLnKo8vWYh1IMz9C0.strip(AAh0X3OCacr4HpifRGLZKT)
			if wrvU1Ey2cBPqOW5QRJpdDt: name = wrvU1Ey2cBPqOW5QRJpdDt
			else: name = XXqGLnKo8vWYh1IMz9C0
			title = title+' ('+name+')'
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def fs7D0d3QyAT(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('ibox-heading"(.*?)class="float-right',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if 'catsum-mobile' in Po9h3gWFuLR2:
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title,count in items:
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = gAVl1vUmus8+'/'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
				B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
				count = count.replace(' الصوتية: ',':')
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				title = title+' ('+count+')'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,311,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	else:
		items = fNntYJW45mEFSdRX8g.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,xO0jtnR1JlYWzbm28AQuUIk9,yAMScJ6z3E8 in items:
			if title==sCHVtMAvqirbQ4BUK3cgWo or xO0jtnR1JlYWzbm28AQuUIk9==sCHVtMAvqirbQ4BUK3cgWo: continue
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
			title = title+' ('+yAMScJ6z3E8+')'
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312)
	if not items: VzOBjnIkZSH7ft(Sw0pOFoVhPeIxbl)
	return
def VzOBjnIkZSH7ft(Sw0pOFoVhPeIxbl):
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="ibox-content"(.*?)class="pagination',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title,name,count,yAMScJ6z3E8 in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		name = name.strip(AAh0X3OCacr4HpifRGLZKT)
		title = title+' ('+name+')'
		XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312,sCHVtMAvqirbQ4BUK3cgWo,yAMScJ6z3E8)
	return
def wYhv0GCQL8r(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-SEARCH_ITEMS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="ibox-content p-1"(.*?)class="ibox-content"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR:
		fs7D0d3QyAT(url)
		return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<strong>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+'/'+B17r2fdFy9ns8tiOMLu
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		if '/play-' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,311)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('<audio.*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('<video.*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu[0]
	CeXLtzElr5DHhs(B17r2fdFy9ns8tiOMLu,Ll1m0nJoaAPvHsXqyRE,'video')
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	RC7LvIr6GTc0golNJ = ['&t=a','&t=c','&t=s']
	if showDialogs:
		vzxJSWowXb5uQEGIyrqeUYhPV = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('موقع صوت الشيعة - أختر البحث', vzxJSWowXb5uQEGIyrqeUYhPV)
		if jQLzA92KFEcpw == -1: return
	elif '_SHIAVOICE-PERSONS_' in Z2VkQhiPAOuboSRB: jQLzA92KFEcpw = 0
	elif '_SHIAVOICE-ALBUMS_' in Z2VkQhiPAOuboSRB: jQLzA92KFEcpw = 1
	elif '_SHIAVOICE-AUDIOS_' in Z2VkQhiPAOuboSRB: jQLzA92KFEcpw = 2
	else: return
	type = RC7LvIr6GTc0golNJ[jQLzA92KFEcpw]
	url = gAVl1vUmus8+'/search.php?q='+search+type
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'SHIAVOICE-SEARCH-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="ibox-content"(.*?)class="ibox-content"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		if jQLzA92KFEcpw in [0,1]:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,name in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				name = name.strip(AAh0X3OCacr4HpifRGLZKT)
				title = title+' ('+name+')'
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,313,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif jQLzA92KFEcpw==2:
			items = fNntYJW45mEFSdRX8g.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title,name in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				name = name.strip(AAh0X3OCacr4HpifRGLZKT)
				title = title+' ('+name+')'
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,312)
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'GLOBALSEARCH'
Z0BYJQghVL1v87CAem = '_GLS_'
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB,qhWpTazQ9ws,T67f3LG49xpP8zcN,mRwrKW6fNZV):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==540: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==541: ka7jz96YCdTBnQOLVPuJG3285MHf = oeDVYvl206pBJfAyKLnCzFhkxd(T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==542: ka7jz96YCdTBnQOLVPuJG3285MHf = WceYBZH6GpR(T67f3LG49xpP8zcN,qhWpTazQ9ws,mRwrKW6fNZV)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==543: ka7jz96YCdTBnQOLVPuJG3285MHf = ssSRfWtjcpeTUwyhqnl0LG()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==548: ka7jz96YCdTBnQOLVPuJG3285MHf = ppcLXmGj4MxKg16ikYdDA(qhWpTazQ9ws,T67f3LG49xpP8zcN)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==549: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(T67f3LG49xpP8zcN)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder','بحث جديد لجميع المواقع',sCHVtMAvqirbQ4BUK3cgWo,549)
	XAozRfZ68H9x2OsiP3LmIaql1('link','كيف يعمل بحث جميع المواقع','',543)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'==== كلمات البحث المخزنة ===='+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	mCB7EzlZ8fqUdGLoODPcyYAwF = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if mCB7EzlZ8fqUdGLoODPcyYAwF:
		mCB7EzlZ8fqUdGLoODPcyYAwF = mCB7EzlZ8fqUdGLoODPcyYAwF['__SEQUENCED_COLUMNS__']
		for W7jZKBiSIo0shrXl4y9pFT in reversed(mCB7EzlZ8fqUdGLoODPcyYAwF):
			XAozRfZ68H9x2OsiP3LmIaql1('folder',W7jZKBiSIo0shrXl4y9pFT,sCHVtMAvqirbQ4BUK3cgWo,549,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,W7jZKBiSIo0shrXl4y9pFT)
	return
def RsxrGI1pcyY3UXTSLiC(W7jZKBiSIo0shrXl4y9pFT):
	if not W7jZKBiSIo0shrXl4y9pFT:
		W7jZKBiSIo0shrXl4y9pFT = UyBdvjGrFxDWMpmLOXn()
		if not W7jZKBiSIo0shrXl4y9pFT: return
		W7jZKBiSIo0shrXl4y9pFT = W7jZKBiSIo0shrXl4y9pFT.lower()
	P9YiS4ysOIjdLz2C = W7jZKBiSIo0shrXl4y9pFT.replace(Z0BYJQghVL1v87CAem,sCHVtMAvqirbQ4BUK3cgWo)
	KQIGDxw2ZMJBmkT6iLyj0(P9YiS4ysOIjdLz2C,'_ALL',True)
	XAozRfZ68H9x2OsiP3LmIaql1('link','بحث جماعي للمواقع - '+P9YiS4ysOIjdLz2C,'search_sites_all',542,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','بحث منفرد للمواقع - '+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,541,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','نتائج البحث مفصلة - '+P9YiS4ysOIjdLz2C,'opened_sites_all',542,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','نتائج البحث مقسمة - '+P9YiS4ysOIjdLz2C,'listed_sites_all',542,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,P9YiS4ysOIjdLz2C)
	return
def KQIGDxw2ZMJBmkT6iLyj0(DDNRjgHTCBp1tW7nbfkzmE,cDNtgESGl7,BjYhgxs0yp72aT9):
	if cDNtgESGl7=='_ALL': KeCRIfU5r3iYTnu1 = '_GLS_'
	elif cDNtgESGl7=='_GOOGLE': KeCRIfU5r3iYTnu1 = '_GOS_'
	ZLxPfWtbJ6 = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_SPLITTED'+cDNtgESGl7,DDNRjgHTCBp1tW7nbfkzmE)
	Ef9ai2hj8y5xDv7BZSA = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_SPLITTED'+cDNtgESGl7,KeCRIfU5r3iYTnu1+DDNRjgHTCBp1tW7nbfkzmE)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7,DDNRjgHTCBp1tW7nbfkzmE)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7,KeCRIfU5r3iYTnu1+DDNRjgHTCBp1tW7nbfkzmE)
	agLrc18KhMNZxdViR7UjqOI = ZLxPfWtbJ6+Ef9ai2hj8y5xDv7BZSA
	if agLrc18KhMNZxdViR7UjqOI and BjYhgxs0yp72aT9: DDNRjgHTCBp1tW7nbfkzmE = KeCRIfU5r3iYTnu1+DDNRjgHTCBp1tW7nbfkzmE
	kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7,DDNRjgHTCBp1tW7nbfkzmE,agLrc18KhMNZxdViR7UjqOI,gQtzWRX97wZHiJ)
	return
def FBeYAuIGlPr08Rxsgcd7ijJ32K(cDNtgESGl7):
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if bR4jqNrpMesHt93OgGKi6WDVaQA!=1: return
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DETAILED'+cDNtgESGl7)
	aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DIVIDED'+cDNtgESGl7)
	if cDNtgESGl7=='_GOOGLE': aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GOOGLESEARCH_RESULTS')
	ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def WceYBZH6GpR(ooLh9VaT1B,nfjN8uepi3tYEKI,GURZoFmr3A7MDy=sCHVtMAvqirbQ4BUK3cgWo,ssVr5jE0WeCYOlmQt4iqH=lAF6gQMxJOK,fAJZGmtPbOUxDB0liC81YW={}):
	cav7dDnjo8EYg,XfuNCjzqH3bg7SVUR9kWEctT1OLAew,Pt4ice0Hj9Xop,ssU4wuONGSz5vxFPmbA8,v0DZzfGCA8T1mycBb5l = [],{},{},{},{}
	if '_all' in nfjN8uepi3tYEKI: cDNtgESGl7,XMygx0kDvOtKWn6I,KeCRIfU5r3iYTnu1 = '_ALL','_all','_GLS_'
	elif '_google' in nfjN8uepi3tYEKI: cDNtgESGl7,XMygx0kDvOtKWn6I,KeCRIfU5r3iYTnu1 = '_GOOGLE','_google','_GOS_'
	if nfjN8uepi3tYEKI in ['listed_sites'+XMygx0kDvOtKWn6I,'opened_sites'+XMygx0kDvOtKWn6I,'closed_sites'+XMygx0kDvOtKWn6I]:
		if nfjN8uepi3tYEKI=='listed_sites'+XMygx0kDvOtKWn6I: cav7dDnjo8EYg = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_SPLITTED'+cDNtgESGl7,KeCRIfU5r3iYTnu1+ooLh9VaT1B)
		elif nfjN8uepi3tYEKI=='opened_sites'+XMygx0kDvOtKWn6I: cav7dDnjo8EYg = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_DETAILED'+cDNtgESGl7,ooLh9VaT1B)
		elif nfjN8uepi3tYEKI=='closed_sites'+XMygx0kDvOtKWn6I: cav7dDnjo8EYg = JKCrO8x7ZyIfwVgSvX(qD1l8d3bQVN2uanhBLpyWTtcx,'list','GLOBALSEARCH_DIVIDED'+cDNtgESGl7,(GURZoFmr3A7MDy,ooLh9VaT1B))
	if not cav7dDnjo8EYg:
		xFNW2M6ijZbhzuoHgPC0Ba = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		N6yp1C9H8R = 'هل تريد الآن البحث في جميع المواقع عن \n "'+F7Fe63KbGjaz2TcmCNHPdo5QiXO+AAh0X3OCacr4HpifRGLZKT+ooLh9VaT1B+AAh0X3OCacr4HpifRGLZKT+B8alA5nvIhTxQ+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if nfjN8uepi3tYEKI=='search_sites'+XMygx0kDvOtKWn6I: Iqm6XAWBlF = N6yp1C9H8R
		else: Iqm6XAWBlF = xFNW2M6ijZbhzuoHgPC0Ba+N6yp1C9H8R
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Iqm6XAWBlF)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=1: return
		YgJ3ybSlEOxXUL7m(VMB1l2JKvI,VMB1l2JKvI,VMB1l2JKvI)
		SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+'   Search For: [ '+ooLh9VaT1B+' ]')
		tHBplo6w9augGMm = 1
		for oT2iHwjfBx0FPX5ZCph9aWs38 in ssVr5jE0WeCYOlmQt4iqH:
			m74O1we2KvNWZMCaTp = fAJZGmtPbOUxDB0liC81YW[oT2iHwjfBx0FPX5ZCph9aWs38] if fAJZGmtPbOUxDB0liC81YW else ooLh9VaT1B
			try: lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
			except: continue
			XfuNCjzqH3bg7SVUR9kWEctT1OLAew[oT2iHwjfBx0FPX5ZCph9aWs38] = []
			mHY2EseIvtnoF6Ax0KWdQVrLP = '_NODIALOGS_'
			if '-' in oT2iHwjfBx0FPX5ZCph9aWs38: mHY2EseIvtnoF6Ax0KWdQVrLP = mHY2EseIvtnoF6Ax0KWdQVrLP+'_REMEMBERRESULTS__'+oT2iHwjfBx0FPX5ZCph9aWs38+'_'
			if tHBplo6w9augGMm:
				hDjf1Ubgq629nXlOvcFLH4Jw.sleep(0.75)
				v0DZzfGCA8T1mycBb5l[oT2iHwjfBx0FPX5ZCph9aWs38] = P6q4YZs5pCFr7aiOv8mlV1UktWXISd(daemon=ndkUxG9LtewJ,target=bHSQRo5vFEuWUw1978CLY,args=(m74O1we2KvNWZMCaTp+mHY2EseIvtnoF6Ax0KWdQVrLP,))
				v0DZzfGCA8T1mycBb5l[oT2iHwjfBx0FPX5ZCph9aWs38].start()
			else: bHSQRo5vFEuWUw1978CLY(m74O1we2KvNWZMCaTp+mHY2EseIvtnoF6Ax0KWdQVrLP)
			iRaHzNpJhSx6ZnCfrvD7j93lks(g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38),sCHVtMAvqirbQ4BUK3cgWo,hDjf1Ubgq629nXlOvcFLH4Jw=1000)
		if tHBplo6w9augGMm:
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(2)
			for oT2iHwjfBx0FPX5ZCph9aWs38 in ssVr5jE0WeCYOlmQt4iqH: v0DZzfGCA8T1mycBb5l[oT2iHwjfBx0FPX5ZCph9aWs38].join(10)
			hDjf1Ubgq629nXlOvcFLH4Jw.sleep(2)
		for oT2iHwjfBx0FPX5ZCph9aWs38 in ssVr5jE0WeCYOlmQt4iqH:
			try: lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
			except: continue
			for yFgOx69L2tnTUvoNu0V5ZGrkRJ in Q1siCkTZyw.menuItemsLIST:
				iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q = yFgOx69L2tnTUvoNu0V5ZGrkRJ
				if o0wDANXvUE7fS2Z in hoVitY5TylJ7GBEIZNOQg8pukq:
					if 'IPTV-' in oT2iHwjfBx0FPX5ZCph9aWs38 and (239>=QQ8kHjYnKEDU3sxft9S5iRoB>=230 or 289>=QQ8kHjYnKEDU3sxft9S5iRoB>=280):
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['IPTV-LIVE']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['IPTV-MOVIES']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['IPTV-SERIES']: continue
						if 'صفحة' not in hoVitY5TylJ7GBEIZNOQg8pukq:
							if   iHPTUWrX1nbg=='live': oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-LIVE'
							elif iHPTUWrX1nbg=='video': oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-MOVIES'
							elif iHPTUWrX1nbg=='folder': oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-SERIES'
						else:
							if   'LIVE' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-LIVE'
							elif 'MOVIES' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-MOVIES'
							elif 'SERIES' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'IPTV-SERIES'
					elif 'M3U-' in oT2iHwjfBx0FPX5ZCph9aWs38 and 729>=QQ8kHjYnKEDU3sxft9S5iRoB>=710:
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['M3U-LIVE']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['M3U-MOVIES']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['M3U-SERIES']: continue
						if 'صفحة' not in hoVitY5TylJ7GBEIZNOQg8pukq:
							if   iHPTUWrX1nbg=='live': oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-LIVE'
							elif iHPTUWrX1nbg=='video': oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-MOVIES'
							elif iHPTUWrX1nbg=='folder': oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-SERIES'
						else:
							if   'LIVE' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-LIVE'
							elif 'MOVIES' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-MOVIES'
							elif 'SERIES' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'M3U-SERIES'
					elif 'YOUTUBE-' in oT2iHwjfBx0FPX5ZCph9aWs38 and 149>=QQ8kHjYnKEDU3sxft9S5iRoB>=140:
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['YOUTUBE-CHANNELS']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['YOUTUBE-PLAYLISTS']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in hoVitY5TylJ7GBEIZNOQg8pukq or ':: ' in hoVitY5TylJ7GBEIZNOQg8pukq:
							continue
						else:
							if   QQ8kHjYnKEDU3sxft9S5iRoB==144 and 'USER' in hoVitY5TylJ7GBEIZNOQg8pukq: oT2iHwjfBx0FPX5ZCph9aWs38 = 'YOUTUBE-CHANNELS'
							elif QQ8kHjYnKEDU3sxft9S5iRoB==144 and 'CHNL' in hoVitY5TylJ7GBEIZNOQg8pukq: oT2iHwjfBx0FPX5ZCph9aWs38 = 'YOUTUBE-CHANNELS'
							elif QQ8kHjYnKEDU3sxft9S5iRoB==144 and 'LIST' in hoVitY5TylJ7GBEIZNOQg8pukq: oT2iHwjfBx0FPX5ZCph9aWs38 = 'YOUTUBE-PLAYLISTS'
							elif QQ8kHjYnKEDU3sxft9S5iRoB==143: oT2iHwjfBx0FPX5ZCph9aWs38 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in oT2iHwjfBx0FPX5ZCph9aWs38 and 419>=QQ8kHjYnKEDU3sxft9S5iRoB>=400:
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['DAILYMOTION-PLAYLISTS']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['DAILYMOTION-CHANNELS']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['DAILYMOTION-VIDEOS']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['DAILYMOTION-LIVES']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['DAILYMOTION-HASHTAGS']: continue
						if   QQ8kHjYnKEDU3sxft9S5iRoB in [401,405]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'DAILYMOTION-PLAYLISTS'
						elif QQ8kHjYnKEDU3sxft9S5iRoB in [402,406]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'DAILYMOTION-CHANNELS'
						elif QQ8kHjYnKEDU3sxft9S5iRoB in [404]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'DAILYMOTION-VIDEOS'
						elif QQ8kHjYnKEDU3sxft9S5iRoB in [415]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'DAILYMOTION-LIVES'
						elif QQ8kHjYnKEDU3sxft9S5iRoB in [416]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in oT2iHwjfBx0FPX5ZCph9aWs38 and 39>=QQ8kHjYnKEDU3sxft9S5iRoB>=30:
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['PANET-SERIES']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['PANET-MOVIES']: continue
						if   QQ8kHjYnKEDU3sxft9S5iRoB in [32,39]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'PANET-SERIES'
						elif QQ8kHjYnKEDU3sxft9S5iRoB in [33,39]: oT2iHwjfBx0FPX5ZCph9aWs38 = 'PANET-MOVIES'
					elif 'IFILM-' in oT2iHwjfBx0FPX5ZCph9aWs38 and 29>=QQ8kHjYnKEDU3sxft9S5iRoB>=20:
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['IFILM-ARABIC']: continue
						if yFgOx69L2tnTUvoNu0V5ZGrkRJ in XfuNCjzqH3bg7SVUR9kWEctT1OLAew['IFILM-ENGLISH']: continue
						if   '/ar.' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'IFILM-ARABIC'
						elif '/en.' in qhWpTazQ9ws: oT2iHwjfBx0FPX5ZCph9aWs38 = 'IFILM-ENGLISH'
					XfuNCjzqH3bg7SVUR9kWEctT1OLAew[oT2iHwjfBx0FPX5ZCph9aWs38].append(yFgOx69L2tnTUvoNu0V5ZGrkRJ)
		for oT2iHwjfBx0FPX5ZCph9aWs38 in list(XfuNCjzqH3bg7SVUR9kWEctT1OLAew.keys()):
			Pt4ice0Hj9Xop[oT2iHwjfBx0FPX5ZCph9aWs38] = []
			ssU4wuONGSz5vxFPmbA8[oT2iHwjfBx0FPX5ZCph9aWs38] = []
			for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in XfuNCjzqH3bg7SVUR9kWEctT1OLAew[oT2iHwjfBx0FPX5ZCph9aWs38]:
				yFgOx69L2tnTUvoNu0V5ZGrkRJ = (iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
				if 'صفحة' in hoVitY5TylJ7GBEIZNOQg8pukq and iHPTUWrX1nbg=='folder': ssU4wuONGSz5vxFPmbA8[oT2iHwjfBx0FPX5ZCph9aWs38].append(yFgOx69L2tnTUvoNu0V5ZGrkRJ)
				else: Pt4ice0Hj9Xop[oT2iHwjfBx0FPX5ZCph9aWs38].append(yFgOx69L2tnTUvoNu0V5ZGrkRJ)
		CCKvi9IAuzGobc7OFeSHVWnJsPRE,ggr8CZLtaK3wnVN7y6pYOGHjTQE = [],[]
		ZBlesVYJcG = list(Pt4ice0Hj9Xop.keys())
		LWMxiQoXg6vsFT1AK = zATVmaxnLvJf6E5So9cFNB(ZBlesVYJcG)
		eeVSO5ZDUk7ybwd2Cmogx = []
		for oT2iHwjfBx0FPX5ZCph9aWs38 in LWMxiQoXg6vsFT1AK:
			if isinstance(oT2iHwjfBx0FPX5ZCph9aWs38,tuple):
				eeVSO5ZDUk7ybwd2Cmogx = [oT2iHwjfBx0FPX5ZCph9aWs38]
				continue
			if oT2iHwjfBx0FPX5ZCph9aWs38 not in ssVr5jE0WeCYOlmQt4iqH: continue
			if Pt4ice0Hj9Xop[oT2iHwjfBx0FPX5ZCph9aWs38]:
				RWdPTZ2xmB1g0Ms6j4ypoNvrGKce = g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38)
				xeT6fQgVtCcsnSH3E = [('link',F7Fe63KbGjaz2TcmCNHPdo5QiXO+'===== '+RWdPTZ2xmB1g0Ms6j4ypoNvrGKce+' ====='+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)]
				if 0: Jca7lXRqeosSmHNAi03fLE5C = ooLh9VaT1B+' - '+'بحث'+AAh0X3OCacr4HpifRGLZKT+RWdPTZ2xmB1g0Ms6j4ypoNvrGKce
				else: Jca7lXRqeosSmHNAi03fLE5C = 'بحث'+AAh0X3OCacr4HpifRGLZKT+RWdPTZ2xmB1g0Ms6j4ypoNvrGKce+' - '+ooLh9VaT1B
				if len(Pt4ice0Hj9Xop[oT2iHwjfBx0FPX5ZCph9aWs38])<8: qAfSlgHQ01WzPm8 = []
				else:
					DGoIJpEbKMtw3VnNTc4xfRCASFyq = VXWOCAE6ns3paJ8DLG479NQfMu+Jca7lXRqeosSmHNAi03fLE5C+B8alA5nvIhTxQ
					qAfSlgHQ01WzPm8 = [('folder',KeCRIfU5r3iYTnu1+DGoIJpEbKMtw3VnNTc4xfRCASFyq,'closed_sites'+XMygx0kDvOtKWn6I,542,sCHVtMAvqirbQ4BUK3cgWo,oT2iHwjfBx0FPX5ZCph9aWs38,ooLh9VaT1B,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)]
				r7HJigUK5qt4Ne = Pt4ice0Hj9Xop[oT2iHwjfBx0FPX5ZCph9aWs38]+ssU4wuONGSz5vxFPmbA8[oT2iHwjfBx0FPX5ZCph9aWs38]
				WSkHrApw15MZiRqo9jEdIh0F6mO = eeVSO5ZDUk7ybwd2Cmogx+xeT6fQgVtCcsnSH3E+r7HJigUK5qt4Ne[:7]+qAfSlgHQ01WzPm8
				CCKvi9IAuzGobc7OFeSHVWnJsPRE += WSkHrApw15MZiRqo9jEdIh0F6mO
				onQJKAWwzOXI6BxMeUE3vTS = [('folder',KeCRIfU5r3iYTnu1+Jca7lXRqeosSmHNAi03fLE5C,'closed_sites'+XMygx0kDvOtKWn6I,542,sCHVtMAvqirbQ4BUK3cgWo,oT2iHwjfBx0FPX5ZCph9aWs38,ooLh9VaT1B,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo)]
				llMa7qhceFn6uDGyXtHY9Txg = eeVSO5ZDUk7ybwd2Cmogx+onQJKAWwzOXI6BxMeUE3vTS
				ggr8CZLtaK3wnVN7y6pYOGHjTQE += llMa7qhceFn6uDGyXtHY9Txg
				kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DIVIDED'+cDNtgESGl7,(oT2iHwjfBx0FPX5ZCph9aWs38,ooLh9VaT1B),r7HJigUK5qt4Ne,gQtzWRX97wZHiJ)
				eeVSO5ZDUk7ybwd2Cmogx = []
		kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_DETAILED'+cDNtgESGl7,ooLh9VaT1B,CCKvi9IAuzGobc7OFeSHVWnJsPRE,gQtzWRX97wZHiJ)
		aDIrWXnPZ7zY8ulSpedh9tfEKb(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7,ooLh9VaT1B)
		kPQB6UJMiVGmHoT9w8(qD1l8d3bQVN2uanhBLpyWTtcx,'GLOBALSEARCH_SPLITTED'+cDNtgESGl7,KeCRIfU5r3iYTnu1+ooLh9VaT1B,ggr8CZLtaK3wnVN7y6pYOGHjTQE,gQtzWRX97wZHiJ)
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		cav7dDnjo8EYg = ggr8CZLtaK3wnVN7y6pYOGHjTQE if nfjN8uepi3tYEKI=='listed_sites'+XMygx0kDvOtKWn6I and ggr8CZLtaK3wnVN7y6pYOGHjTQE else CCKvi9IAuzGobc7OFeSHVWnJsPRE
	if nfjN8uepi3tYEKI in ['listed_sites'+XMygx0kDvOtKWn6I,'opened_sites'+XMygx0kDvOtKWn6I,'closed_sites'+XMygx0kDvOtKWn6I]:
		for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q in cav7dDnjo8EYg:
			if nfjN8uepi3tYEKI in ['listed_sites'+XMygx0kDvOtKWn6I,'opened_sites'+XMygx0kDvOtKWn6I] and 'صفحة' in hoVitY5TylJ7GBEIZNOQg8pukq and iHPTUWrX1nbg=='folder': continue
			XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,Qp3jGv8leCbuiEU5Im,mRwrKW6fNZV,T67f3LG49xpP8zcN,IFYonX8LZUfz3VJyuQlxgE,ZQC69Pyo4BOamJlwSLtAWINg7q)
	YgJ3ybSlEOxXUL7m(K3nC0rDSptmG,K3nC0rDSptmG,K3nC0rDSptmG)
	return
def oeDVYvl206pBJfAyKLnCzFhkxd(search):
	LWMxiQoXg6vsFT1AK = zATVmaxnLvJf6E5So9cFNB(imU5I1ewc4dEHvkQ8)
	for oT2iHwjfBx0FPX5ZCph9aWs38 in LWMxiQoXg6vsFT1AK:
		if '-' in oT2iHwjfBx0FPX5ZCph9aWs38: continue
		if isinstance(oT2iHwjfBx0FPX5ZCph9aWs38,tuple):
			Q1siCkTZyw.menuItemsLIST.append(oT2iHwjfBx0FPX5ZCph9aWs38)
			continue
		lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
		name = g7k6hjSBrX4oOElJW59c2bUZpMquw(oT2iHwjfBx0FPX5ZCph9aWs38)+' - '+search
		XAozRfZ68H9x2OsiP3LmIaql1('folder',o0wDANXvUE7fS2Z+name,oT2iHwjfBx0FPX5ZCph9aWs38,548,'','',search)
	return
def ppcLXmGj4MxKg16ikYdDA(oT2iHwjfBx0FPX5ZCph9aWs38,search):
	lDt71RPxgnZs0LzHurJAdqU,bHSQRo5vFEuWUw1978CLY,o0wDANXvUE7fS2Z = miFKkRal0pOjqCzbZ3hsTXE12gGD4(oT2iHwjfBx0FPX5ZCph9aWs38)
	bHSQRo5vFEuWUw1978CLY(search)
	return
def ssSRfWtjcpeTUwyhqnl0LG():
	ZZDswXvceNFRhafpUtWELYCP('','',OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def OwNRFeu3T7vIiE(ooLh9VaT1B=sCHVtMAvqirbQ4BUK3cgWo):
	W7jZKBiSIo0shrXl4y9pFT,mHY2EseIvtnoF6Ax0KWdQVrLP,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(ooLh9VaT1B)
	if not W7jZKBiSIo0shrXl4y9pFT:
		W7jZKBiSIo0shrXl4y9pFT = UyBdvjGrFxDWMpmLOXn()
		if not W7jZKBiSIo0shrXl4y9pFT: return
		W7jZKBiSIo0shrXl4y9pFT = W7jZKBiSIo0shrXl4y9pFT.lower()
	SH6EVn0T9d8bKCUMLl1sJOFR(lIm9XbGnwLkdi5q,JEHeDu3xiYbGMo(Ll1m0nJoaAPvHsXqyRE)+'   Search For: [ '+W7jZKBiSIo0shrXl4y9pFT+' ]')
	ktT4O0VJm8UaDNlxKvinoBYFgdH = W7jZKBiSIo0shrXl4y9pFT+mHY2EseIvtnoF6Ax0KWdQVrLP
	if 0: nlIBqwOVtF49yiN7XDvj3KkcuZgx0f,P9YiS4ysOIjdLz2C = W7jZKBiSIo0shrXl4y9pFT+' - ',sCHVtMAvqirbQ4BUK3cgWo
	else: nlIBqwOVtF49yiN7XDvj3KkcuZgx0f,P9YiS4ysOIjdLz2C = sCHVtMAvqirbQ4BUK3cgWo,' - '+W7jZKBiSIo0shrXl4y9pFT
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'مواقع سيرفرات خاصة - قليلة المشاكل'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,157)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_M3U_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث M3U'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,719,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_IPT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث IPTV'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,239,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_BKR_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع بكرا'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,379,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_ART_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع تونز عربية'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,739,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_KRB_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع قناة كربلاء'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,329,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FH2_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فاصل الثاني'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,599,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_KTV_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع كتكوت تيفي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,819,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_EB1_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع ايجي بيست 1'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,779,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_EB2_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع ايجي بيست 2'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,789,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_IFL_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'  بحث موقع قناة آي فيلم'+P9YiS4ysOIjdLz2C+LvzD9S8RPyGeukZQqb2T0B,sCHVtMAvqirbQ4BUK3cgWo,29,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_AKO_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع أكوام القديم'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,79,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_AKW_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع أكوام الجديد'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,249,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_MRF_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع قناة المعارف'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,49,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SHM_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شوف ماكس'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,59,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,157)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_LRZ_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع لاروزا'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,709,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FJS_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+' بحث موقع فجر شو'+P9YiS4ysOIjdLz2C+AAh0X3OCacr4HpifRGLZKT,sCHVtMAvqirbQ4BUK3cgWo,399,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TVF_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع تيفي فان'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,469,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_LDN_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع لودي نت'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,459,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CMN_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما ناو'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,309,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SHN_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شاهد نيوز'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,589,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH+'_NODIALOGS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_ARS_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع عرب سييد'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,259,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CCB_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما كلوب'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,829,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SH4_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شاهد فوريو'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,119,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH+'_NODIALOGS_')
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SHT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شوفها تيفي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,649,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_WC1_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع وي سيما 1'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,569,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_WC2_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع وي سيما 2'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,1009,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'مواقع سيرفرات عامة - كثيرة المشاكل'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,157)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_TKT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع تكات'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,949,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FST_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فوستا'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,609,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FBK_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فبركة'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,629,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_YQT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع ياقوت'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,669,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SHB_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شبكتي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,969,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_VRB_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فاربون'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,879,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_BRS_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع برستيج'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,659,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_KRM_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع كرمالك'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,929,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_ANZ_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع انمي زد'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,979,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FSK_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فارسكو'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,999,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_HLC_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع هلا سيما'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,89,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_MST_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع المصطبة'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,869,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SNT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع شوف نت'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,849,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_DR7_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع دراما صح'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,689,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CFR_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما فري'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,839,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CMF_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما فانز'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,99,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CML_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما لايت'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,479,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_C4H_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما 400'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,699,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_ABD_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما عبدو'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,559,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_AKT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع اكوام تيوب'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,859,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_DCF_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع دراما كافيه'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,939,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FTV_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فوشار تيفي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,919,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_CWB_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما وبس'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,989,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_AHK_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع أهواك تيفي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,619,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_SRT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيريس تايم'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,899,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_FVD_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع فوشار فيديو'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,909,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_C4P_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع سيما فور بي'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,889,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_EB4_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع ايجي بيست 4'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,809,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+'مواقع سيرفرات خاصة - قليلة المشاكل'+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,157)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_YUT_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع يوتيوب'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,149,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	XAozRfZ68H9x2OsiP3LmIaql1('folder','_DLM_'+nlIBqwOVtF49yiN7XDvj3KkcuZgx0f+'بحث موقع دايلي موشن'+P9YiS4ysOIjdLz2C,sCHVtMAvqirbQ4BUK3cgWo,409,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,ktT4O0VJm8UaDNlxKvinoBYFgdH)
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'ALKAWTHAR'
Z0BYJQghVL1v87CAem = '_KWT_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==130: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==131: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url)
	elif mode==132: ka7jz96YCdTBnQOLVPuJG3285MHf = MpKIfTitvZC2YxsD(url)
	elif mode==133: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url,mRwrKW6fNZV)
	elif mode==134: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==135: ka7jz96YCdTBnQOLVPuJG3285MHf = I2IfwUGCn68MRT3QFhWNjsDxrb()
	elif mode==139: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text,url)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,139,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-MENU-1st')
	oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('dropdown-menu(.*?)dropdown-toggle',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[1]
	items=fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if '/conductor' in B17r2fdFy9ns8tiOMLu: continue
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		url = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
		if '/category/' in url: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,132)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,131)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المسلسلات',gAVl1vUmus8+'/category/543',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'الأفلام',gAVl1vUmus8+'/category/628',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'برامج الصغار والشباب',gAVl1vUmus8+'/category/517',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'ابرز البرامج',gAVl1vUmus8+'/category/1763',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'المحاضرات',gAVl1vUmus8+'/category/943',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'عاشوراء',gAVl1vUmus8+'/category/1353',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'البرامج الاجتماعية',gAVl1vUmus8+'/category/501',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'البرامج الدينية',gAVl1vUmus8+'/category/509',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'البرامج الوثائقية',gAVl1vUmus8+'/category/553',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'البرامج السياسية',gAVl1vUmus8+'/category/545',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'كتب',gAVl1vUmus8+'/category/291',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'تعلم الفارسية',gAVl1vUmus8+'/category/88',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+'أرشيف البرامج',gAVl1vUmus8+'/category/1279',132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	return
def fs7D0d3QyAT(url):
	z4aTqOuFyZejsK3gWYArIUmk6 = ['/religious','/social','/political','/films','/series']
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-TITLES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('titlebar(.*?)titlebar',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if any(value in url for value in z4aTqOuFyZejsK3gWYArIUmk6):
		items = fNntYJW45mEFSdRX8g.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,133,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'1')
	elif '/docs' in url:
		items = fNntYJW45mEFSdRX8g.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,B17r2fdFy9ns8tiOMLu in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,133,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'1')
	return
def MpKIfTitvZC2YxsD(url):
	B4SziFvRIXpPeGmfZDw3aVWJMAKNc = url.split('/')[-1]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-CATEGORIES-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('parentcat(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR:
		VzOBjnIkZSH7ft(url,'1')
		return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall("href='(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = title.strip(AAh0X3OCacr4HpifRGLZKT)
		B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,132,sCHVtMAvqirbQ4BUK3cgWo,'1')
	return
def VzOBjnIkZSH7ft(url,mRwrKW6fNZV):
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-EPISODES-1st')
	items = fNntYJW45mEFSdRX8g.findall('totalpagecount=[\'"](.*?)[\'"]',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not items:
		url = fNntYJW45mEFSdRX8g.findall('class="news-detail-body".*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,134)
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	tdGI65Xbm7cqOMogkfZlYuxS = int(items[0])
	name = fNntYJW45mEFSdRX8g.findall('main-title.*?</a> >(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if name: name = name[0].strip(AAh0X3OCacr4HpifRGLZKT)
	else: name = FoiwfTEhGD8ulS25HeUvnI.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		B4SziFvRIXpPeGmfZDw3aVWJMAKNc = url.split('/')[-1]
		if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = gAVl1vUmus8 + '/category/' + B4SziFvRIXpPeGmfZDw3aVWJMAKNc + '/' + mRwrKW6fNZV
		ssUAzo3RibtgDv7O0x = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-EPISODES-2nd')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('currentpagenumber(.*?)pagination',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,type,B17r2fdFy9ns8tiOMLu,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',sCHVtMAvqirbQ4BUK3cgWo)
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8 + B17r2fdFy9ns8tiOMLu
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='628': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,133,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'1')
			else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,134,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif '/episode/' in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('playlist(.*?)col-md-12',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,134,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif '/category/628' in Sw0pOFoVhPeIxbl:
				title = '_MOD_' + 'ملف التشغيل'
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,url,134)
		else:
			items = fNntYJW45mEFSdRX8g.findall('id="Categories.*?href=\'(.*?)\'',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			B4SziFvRIXpPeGmfZDw3aVWJMAKNc = items[0].split('/')[-1]
			url = gAVl1vUmus8 + '/category/' + B4SziFvRIXpPeGmfZDw3aVWJMAKNc
			MpKIfTitvZC2YxsD(url)
			return
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		WdOkgLCxqNDG = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in WdOkgLCxqNDG:
			B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('&amp;','&')
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,133)
	return
def YH54mqkD2eU06(url):
	if '/news/' in url or '/episode/' in url:
		Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-PLAY-1st')
		items = fNntYJW45mEFSdRX8g.findall("mobilevideopath.*?value='(.*?)'",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if items: url = items[0]
	CeXLtzElr5DHhs(url,Ll1m0nJoaAPvHsXqyRE,'video')
	return
def I2IfwUGCn68MRT3QFhWNjsDxrb():
	url = gAVl1vUmus8+'/live'
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-LIVE-1st')
	vrEJRkchKxtDNiqO1b79mL5eT = fNntYJW45mEFSdRX8g.findall('live-container.*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT[0]
	HSNYwERMjzyxmrPku = {'Referer':gAVl1vUmus8}
	CxP3d82yUTnMa = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,True,'ALKAWTHAR-LIVE-2nd')
	ssUAzo3RibtgDv7O0x = CxP3d82yUTnMa.content
	iigMzLZxRm6npGVfCvb0 = fNntYJW45mEFSdRX8g.findall('csrf-token" content="(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
	iigMzLZxRm6npGVfCvb0 = iigMzLZxRm6npGVfCvb0[0]
	VYxiElZqdGyDAMgeL6S = GABnmSFOwtsu37(vrEJRkchKxtDNiqO1b79mL5eT,'url')
	rdQ5tOIzuelfvcYbNsM = fNntYJW45mEFSdRX8g.findall("playUrl = '(.*?)'",ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
	rdQ5tOIzuelfvcYbNsM = VYxiElZqdGyDAMgeL6S+rdQ5tOIzuelfvcYbNsM[0]
	HSrmwdqBFbvkVJ = {'X-CSRF-TOKEN':iigMzLZxRm6npGVfCvb0}
	GGySQr6d3Tn7iLDkXAINbF2M = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'POST',rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,HSrmwdqBFbvkVJ,False,True,'ALKAWTHAR-LIVE-3rd')
	jk5PAl7HEyFn83JNBvewYf2 = GGySQr6d3Tn7iLDkXAINbF2M.content
	Ow0mUS9ZFyzuian = fNntYJW45mEFSdRX8g.findall('"(.*?)"',jk5PAl7HEyFn83JNBvewYf2,fNntYJW45mEFSdRX8g.DOTALL)
	Ow0mUS9ZFyzuian = Ow0mUS9ZFyzuian[0].replace('\/','/')
	CeXLtzElr5DHhs(Ow0mUS9ZFyzuian,Ll1m0nJoaAPvHsXqyRE,'live')
	return
def RsxrGI1pcyY3UXTSLiC(search,url=sCHVtMAvqirbQ4BUK3cgWo):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if url==sCHVtMAvqirbQ4BUK3cgWo:
		if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
		if search==sCHVtMAvqirbQ4BUK3cgWo: return
		search = IgCGzHw45TJ7PeuO1EKl(search)
		url = gAVl1vUmus8+'/search?q='+search
		VzOBjnIkZSH7ft(url,sCHVtMAvqirbQ4BUK3cgWo)
		return
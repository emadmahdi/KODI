# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'CIMALIGHT'
Z0BYJQghVL1v87CAem = '_CML_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['قنوات فضائية']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==470: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==471: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==472: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==473: ka7jz96YCdTBnQOLVPuJG3285MHf = E5mTvMgjPFJKs1noB7we8i(url,text)
	elif mode==474: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==479: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,479,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"content"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		title = title.replace(LvzD9S8RPyGeukZQqb2T0B,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('cat=online-movies1','cat=online-movies')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,474)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('/category.php">(.*?)"navslide-divider"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall("'dropdown-menu'(.*?)</ul>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if title in MqARWHDkmiT4nlz: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,474)
	return
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	if 'topvideos.php' in url: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)id="pm-grid"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	else: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"caret"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'topvideos.php' in B17r2fdFy9ns8tiOMLu:
				if 'topvideos.php?c=english-movies' in B17r2fdFy9ns8tiOMLu: continue
				if 'topvideos.php?c=online-movies1' in B17r2fdFy9ns8tiOMLu: continue
				if 'topvideos.php?c=misc' in B17r2fdFy9ns8tiOMLu: continue
				if 'topvideos.php?c=tv-channel' in B17r2fdFy9ns8tiOMLu: continue
				if 'منذ البداية' in title and 'do=rating' not in B17r2fdFy9ns8tiOMLu: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,471)
	else: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,n1WYDtVC8dRHbXJkMa=sCHVtMAvqirbQ4BUK3cgWo):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = []
	if n1WYDtVC8dRHbXJkMa=='featured_movies':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"container-fluid"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		PXFtqmw5lBGQNa0IV8,J4EIW0hU16YCcqn92uatb3,h4QMqrlJvuEHPS = zip(*items)
		items = zip(h4QMqrlJvuEHPS,PXFtqmw5lBGQNa0IV8,J4EIW0hU16YCcqn92uatb3)
	elif n1WYDtVC8dRHbXJkMa=='featured_series':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('المسلسلات المميزة(.*?)<style>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		PXFtqmw5lBGQNa0IV8,J4EIW0hU16YCcqn92uatb3,h4QMqrlJvuEHPS = zip(*items)
		items = zip(h4QMqrlJvuEHPS,PXFtqmw5lBGQNa0IV8,J4EIW0hU16YCcqn92uatb3)
	else:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('(data-echo=".*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"BlocksList"(.*?)"titleSectionCon"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="pm-grid"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('id="pm-related"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pm-ul-browse-videos(.*?)clearfix',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if not oPnz7Zt4xLHTwR: return
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not items: items = fNntYJW45mEFSdRX8g.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	if not items: items = fNntYJW45mEFSdRX8g.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		title = title.replace('ماي سيما',sCHVtMAvqirbQ4BUK3cgWo).replace('مشاهدة',sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT)
		if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
		if 'http' not in Mx0TQvmZAsedaGj4opVDJu5by8RUwS: Mx0TQvmZAsedaGj4opVDJu5by8RUwS = aeBQsh4fzLr8XM5xou1gcyE+'/'+Mx0TQvmZAsedaGj4opVDJu5by8RUwS.strip('/')
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) (الحلقة|حلقة) \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if any(value in title for value in chRY3biUoxnVltIk):
			title = '_MOD_'+title
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,472,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'حلقة' in title:
			title = '_MOD_'+bbFPOJrmkCaE6ul37XiKU[0][0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,473,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movseries/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,471,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,473,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if n1WYDtVC8dRHbXJkMa not in ['featured_movies','featured_series']:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=='#': continue
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				title = tt36wUe4HTPFmfs5hcbr(title)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,471)
		fMlokB12KS3wrF = fNntYJW45mEFSdRX8g.findall('showmore" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if fMlokB12KS3wrF:
			B17r2fdFy9ns8tiOMLu = fMlokB12KS3wrF[0]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مشاهدة المزيد',B17r2fdFy9ns8tiOMLu,471)
	return
def E5mTvMgjPFJKs1noB7we8i(url,Obes76wjH9LRyEqc2NWPTSphZz34K):
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(url,'url')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-EPISODES-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"SeasonsBox"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	items = []
	if GzRKsiw5PBIe1NlrqmQy9STx and not Obes76wjH9LRyEqc2NWPTSphZz34K:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"series-header".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0] if Mx0TQvmZAsedaGj4opVDJu5by8RUwS else sCHVtMAvqirbQ4BUK3cgWo
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if len(items)==1: Obes76wjH9LRyEqc2NWPTSphZz34K = items[0][0]
		elif len(items)>1:
			for Obes76wjH9LRyEqc2NWPTSphZz34K,title in items: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,473,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,sCHVtMAvqirbQ4BUK3cgWo,Obes76wjH9LRyEqc2NWPTSphZz34K)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('id="'+Obes76wjH9LRyEqc2NWPTSphZz34K+'"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iUtXlDhSVoBZJrPTQAwcER9nfMkN and len(items)<2:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"series-header".*?src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0] if Mx0TQvmZAsedaGj4opVDJu5by8RUwS else sCHVtMAvqirbQ4BUK3cgWo
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.replace('ماي سيما',sCHVtMAvqirbQ4BUK3cgWo).replace('مسلسل',sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,472,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/'+B17r2fdFy9ns8tiOMLu.strip('/')
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,472,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if 'id="pm-related"' in Sw0pOFoVhPeIxbl:
		if items: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'مواضيع ذات صلة',url,471)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<div itemprop="description">(.*?)href=',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('<p>(.*?)</p>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7,True): return
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/watch.php','/play.php')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-PLAY-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ypiQgUh7kcjnMzs5xo8aDd = []
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('"embedURL" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		if B17r2fdFy9ns8tiOMLu and B17r2fdFy9ns8tiOMLu not in ypiQgUh7kcjnMzs5xo8aDd:
			ypiQgUh7kcjnMzs5xo8aDd.append(B17r2fdFy9ns8tiOMLu)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named=__embed'
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	items = fNntYJW45mEFSdRX8g.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu not in ypiQgUh7kcjnMzs5xo8aDd:
			ypiQgUh7kcjnMzs5xo8aDd.append(B17r2fdFy9ns8tiOMLu)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
			ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/watch.php','/downloads.php')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMALIGHT-PLAY-3rd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downloadlist"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<strong>(.*?)</strong>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if B17r2fdFy9ns8tiOMLu not in ypiQgUh7kcjnMzs5xo8aDd:
				ypiQgUh7kcjnMzs5xo8aDd.append(B17r2fdFy9ns8tiOMLu)
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__download'
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	smh8Qbf9jH = GABnmSFOwtsu37(gAVl1vUmus8,'url')
	url = smh8Qbf9jH+'/search.php?keywords='+search
	fs7D0d3QyAT(url,'search')
	return
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'IFILM'
Z0BYJQghVL1v87CAem = '_IFL_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
DbmJ9I0ZfXgcFlO8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][1]
RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][2]
JcHIgS70XANB5EpubYs = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][3]
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==20: ka7jz96YCdTBnQOLVPuJG3285MHf = L52M80igVbsWBS()
	elif mode==21: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak(url)
	elif mode==22: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV)
	elif mode==23: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url,mRwrKW6fNZV)
	elif mode==24: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url,text)
	elif mode==25: ka7jz96YCdTBnQOLVPuJG3285MHf = NKzxrYp1H9o0ia3S6LfW2R8y4k(url)
	elif mode==27: ka7jz96YCdTBnQOLVPuJG3285MHf = I2IfwUGCn68MRT3QFhWNjsDxrb(url)
	elif mode==28: ka7jz96YCdTBnQOLVPuJG3285MHf = k0WrUsC4Bc7q6Gd1Ve3vjY()
	elif mode==29: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def L52M80igVbsWBS():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'عربي',gAVl1vUmus8,21,sCHVtMAvqirbQ4BUK3cgWo,'101')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'English',DbmJ9I0ZfXgcFlO8,21,sCHVtMAvqirbQ4BUK3cgWo,'101')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فارسى',RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f,21,sCHVtMAvqirbQ4BUK3cgWo,'101')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فارسى 2',JcHIgS70XANB5EpubYs,21,sCHVtMAvqirbQ4BUK3cgWo,'101')
	return
def k0WrUsC4Bc7q6Gd1Ve3vjY():
	XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'عربي',gAVl1vUmus8,27)
	XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'English',DbmJ9I0ZfXgcFlO8,27)
	XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'فارسى',RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f,27)
	XAozRfZ68H9x2OsiP3LmIaql1('live',Z0BYJQghVL1v87CAem+'فارسى 2',JcHIgS70XANB5EpubYs,27)
	return
def PMKv9oB6gJZak(AumFXji8b9d4B7DTCP):
	Ll1m0nJoaAPvHsXqyRE = AumFXji8b9d4B7DTCP
	if AumFXji8b9d4B7DTCP=='IFILM-ARABIC': AumFXji8b9d4B7DTCP = gAVl1vUmus8
	elif AumFXji8b9d4B7DTCP=='IFILM-ENGLISH': AumFXji8b9d4B7DTCP = DbmJ9I0ZfXgcFlO8
	else: Ll1m0nJoaAPvHsXqyRE = sCHVtMAvqirbQ4BUK3cgWo
	TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(AumFXji8b9d4B7DTCP)
	if TTtDQFAY086Gop1WbuXsHJkwxU=='ar' or Ll1m0nJoaAPvHsXqyRE=='IFILM-ARABIC':
		ED5GQrJmv2ChBigPA4x = 'بحث في الموقع'
		wrvU1Ey2cBPqOW5QRJpdDt = 'مسلسلات - حالية'
		XXqGLnKo8vWYh1IMz9C0 = 'مسلسلات - أحدث'
		oTdCnO9jtL5VfFi7UlhJIgk = 'مسلسلات - أبجدي'
		tBin8IN9Gxl = 'بث حي آي فيلم'
		k9ynmqlBRV = 'أفلام'
		ENgur0wIZKBb4je = 'موسيقى'
		eRVdMXf1x09AyzIrnQo = 'برامج'
	elif TTtDQFAY086Gop1WbuXsHJkwxU=='en' or Ll1m0nJoaAPvHsXqyRE=='IFILM-ENGLISH':
		ED5GQrJmv2ChBigPA4x = 'Search in site'
		wrvU1Ey2cBPqOW5QRJpdDt = 'Series - Current'
		XXqGLnKo8vWYh1IMz9C0 = 'Series - Latest'
		oTdCnO9jtL5VfFi7UlhJIgk = 'Series - Alphabet'
		tBin8IN9Gxl = 'Live iFilm channel'
		k9ynmqlBRV = 'Movies'
		ENgur0wIZKBb4je = 'Music'
		eRVdMXf1x09AyzIrnQo = 'Shows'
	elif TTtDQFAY086Gop1WbuXsHJkwxU in ['fa','fa2']:
		ED5GQrJmv2ChBigPA4x = 'جستجو در سایت'
		wrvU1Ey2cBPqOW5QRJpdDt = 'سريال - جاری'
		XXqGLnKo8vWYh1IMz9C0 = 'سريال - آخرین'
		oTdCnO9jtL5VfFi7UlhJIgk = 'سريال - الفبا'
		tBin8IN9Gxl = 'پخش زنده اي فيلم'
		k9ynmqlBRV = 'فيلم'
		ENgur0wIZKBb4je = 'موسيقى'
		eRVdMXf1x09AyzIrnQo = 'برنامه ها'
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+ED5GQrJmv2ChBigPA4x,AumFXji8b9d4B7DTCP,29,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('live',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+tBin8IN9Gxl,AumFXji8b9d4B7DTCP,27)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	qsPRMmI7pHU2Ax4b98GgBTv = ['Series','Program','Music']
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,AumFXji8b9d4B7DTCP+'/home',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-MENU-1st')
	oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('button-menu(.*?)/Contact',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if any(value in B17r2fdFy9ns8tiOMLu for value in qsPRMmI7pHU2Ax4b98GgBTv):
				url = AumFXji8b9d4B7DTCP+B17r2fdFy9ns8tiOMLu
				if 'Series' in B17r2fdFy9ns8tiOMLu:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,url,22,sCHVtMAvqirbQ4BUK3cgWo,'100')
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+XXqGLnKo8vWYh1IMz9C0,url,22,sCHVtMAvqirbQ4BUK3cgWo,'101')
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+oTdCnO9jtL5VfFi7UlhJIgk,url,22,sCHVtMAvqirbQ4BUK3cgWo,'201')
				elif 'Film' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+k9ynmqlBRV,url,22,sCHVtMAvqirbQ4BUK3cgWo,'100')
				elif 'Music' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+ENgur0wIZKBb4je,url,25,sCHVtMAvqirbQ4BUK3cgWo,'101')
				elif 'Program' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+eRVdMXf1x09AyzIrnQo,url,22,sCHVtMAvqirbQ4BUK3cgWo,'101')
	return Sw0pOFoVhPeIxbl
def NKzxrYp1H9o0ia3S6LfW2R8y4k(url):
	AumFXji8b9d4B7DTCP = P2CxmQMAoviZF3s1(url)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-MUSIC_MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('Music-tools-header(.*?)Music-body',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	title = fNntYJW45mEFSdRX8g.findall('<p>(.*?)</p>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)[0]
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,22,sCHVtMAvqirbQ4BUK3cgWo,'101')
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		B17r2fdFy9ns8tiOMLu = AumFXji8b9d4B7DTCP + B17r2fdFy9ns8tiOMLu
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,23,sCHVtMAvqirbQ4BUK3cgWo,'101')
	return
def fs7D0d3QyAT(url,mRwrKW6fNZV):
	AumFXji8b9d4B7DTCP = P2CxmQMAoviZF3s1(url)
	TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(url)
	type = url.split('/')[-1]
	cuqjQlU0fzkLNvTI9m = str(int(mRwrKW6fNZV)//100)
	mRwrKW6fNZV = str(int(mRwrKW6fNZV)%100)
	if type=='Series' and mRwrKW6fNZV=='0':
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-TITLES-1st')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('serial-body(.*?)class="row',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			title = EEH4kBfGY0FuZUjeNn(title)
			title = tt36wUe4HTPFmfs5hcbr(title)
			B17r2fdFy9ns8tiOMLu = AumFXji8b9d4B7DTCP + B17r2fdFy9ns8tiOMLu
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = AumFXji8b9d4B7DTCP + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,23,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,cuqjQlU0fzkLNvTI9m+'01')
	eGmij1zPJBMQlaIcp=0
	if type=='Series': B4SziFvRIXpPeGmfZDw3aVWJMAKNc='3'
	if type=='Film': B4SziFvRIXpPeGmfZDw3aVWJMAKNc='5'
	if type=='Program': B4SziFvRIXpPeGmfZDw3aVWJMAKNc='7'
	if type in ['Series','Program','Film'] and mRwrKW6fNZV!='0':
		vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Home/PageingItem?category='+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'&page='+mRwrKW6fNZV+'&size=30&orderby='+cuqjQlU0fzkLNvTI9m
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-TITLES-2nd')
		items = fNntYJW45mEFSdRX8g.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for id,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			title = EEH4kBfGY0FuZUjeNn(title)
			title = title.replace('\\',sCHVtMAvqirbQ4BUK3cgWo)
			title = title.replace('"',sCHVtMAvqirbQ4BUK3cgWo)
			eGmij1zPJBMQlaIcp += 1
			B17r2fdFy9ns8tiOMLu = AumFXji8b9d4B7DTCP + '/' + type + '/Content/' + id
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = AumFXji8b9d4B7DTCP + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			if type=='Film': XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,24,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,cuqjQlU0fzkLNvTI9m+'01')
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,23,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,cuqjQlU0fzkLNvTI9m+'01')
	if type=='Music':
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,AumFXji8b9d4B7DTCP+'/Music/Index?page='+mRwrKW6fNZV,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-TITLES-3rd')
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('pagination-demo(.*?)pagination-demo',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			eGmij1zPJBMQlaIcp += 1
			Mx0TQvmZAsedaGj4opVDJu5by8RUwS = AumFXji8b9d4B7DTCP + Mx0TQvmZAsedaGj4opVDJu5by8RUwS
			B17r2fdFy9ns8tiOMLu = AumFXji8b9d4B7DTCP + B17r2fdFy9ns8tiOMLu
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,23,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'101')
	if eGmij1zPJBMQlaIcp>20:
		title='صفحة '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='en': title = 'Page '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa': title = 'صفحه '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': title = 'صفحه '
		for D87M5ZyVCNoJbehEpsY3luRKaF in range(1,11) :
			if not mRwrKW6fNZV==str(D87M5ZyVCNoJbehEpsY3luRKaF):
				IKhW9EMpvrmNOiHd1ge = '0'+str(D87M5ZyVCNoJbehEpsY3luRKaF)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title+str(D87M5ZyVCNoJbehEpsY3luRKaF),url,22,sCHVtMAvqirbQ4BUK3cgWo,cuqjQlU0fzkLNvTI9m+IKhW9EMpvrmNOiHd1ge[-2:])
	return
def VzOBjnIkZSH7ft(url,mRwrKW6fNZV):
	if not mRwrKW6fNZV: mRwrKW6fNZV = 0
	AumFXji8b9d4B7DTCP = P2CxmQMAoviZF3s1(url)
	AApqPfNKwRLY2CIdmc6zly = P2CxmQMAoviZF3s1(url)
	TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(url)
	cuIJ3axEtVWvs = url.split('/')
	id,type = cuIJ3axEtVWvs[-1],cuIJ3axEtVWvs[3]
	cuqjQlU0fzkLNvTI9m = str(int(mRwrKW6fNZV)//100)
	mRwrKW6fNZV = str(int(mRwrKW6fNZV)%100)
	eGmij1zPJBMQlaIcp = 0
	if type=='Series':
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-1st')
		items = fNntYJW45mEFSdRX8g.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		title = ' - الحلقة '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='en': title = ' - Episode '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa': title = ' - قسمت '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': title = ' - قسمت '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa': H39JceFYkwvTNSyCBn5jgrD = sCHVtMAvqirbQ4BUK3cgWo
		else: H39JceFYkwvTNSyCBn5jgrD = TTtDQFAY086Gop1WbuXsHJkwxU
		yyhJgCouzfli6KAXMpwVGIW4F = fNntYJW45mEFSdRX8g.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for name,count,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu in items:
			for bbFPOJrmkCaE6ul37XiKU in range(int(count),0,-1):
				bbVQhHcktxYBK9SRazqvyWgE2of = Mx0TQvmZAsedaGj4opVDJu5by8RUwS + H39JceFYkwvTNSyCBn5jgrD + id + '/' + str(bbFPOJrmkCaE6ul37XiKU) + '.png'
				wrvU1Ey2cBPqOW5QRJpdDt = name + title + str(bbFPOJrmkCaE6ul37XiKU)
				wrvU1Ey2cBPqOW5QRJpdDt = tt36wUe4HTPFmfs5hcbr(wrvU1Ey2cBPqOW5QRJpdDt)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,url,24,bbVQhHcktxYBK9SRazqvyWgE2of,sCHVtMAvqirbQ4BUK3cgWo,str(bbFPOJrmkCaE6ul37XiKU))
	elif type=='Program':
		vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+mRwrKW6fNZV+'&size=30&orderby=1'
		Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-2nd')
		items = fNntYJW45mEFSdRX8g.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		title = ' - الحلقة '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='en': title = ' - Episode '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa': title = ' - قسمت '
		if TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': title = ' - قسمت '
		for bbFPOJrmkCaE6ul37XiKU,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,X1k7d2UKnDW,name in items:
			eGmij1zPJBMQlaIcp += 1
			bbVQhHcktxYBK9SRazqvyWgE2of = AApqPfNKwRLY2CIdmc6zly + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			name = EEH4kBfGY0FuZUjeNn(name)
			wrvU1Ey2cBPqOW5QRJpdDt = name + title + str(bbFPOJrmkCaE6ul37XiKU)
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,vrEJRkchKxtDNiqO1b79mL5eT,24,bbVQhHcktxYBK9SRazqvyWgE2of,sCHVtMAvqirbQ4BUK3cgWo,str(eGmij1zPJBMQlaIcp))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Music/GetTracksBy?id='+str(id)+'&page='+mRwrKW6fNZV+'&size=30&type=0'
			Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-3rd')
			items = fNntYJW45mEFSdRX8g.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,name,title in items:
				eGmij1zPJBMQlaIcp += 1
				bbVQhHcktxYBK9SRazqvyWgE2of = AApqPfNKwRLY2CIdmc6zly + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				wrvU1Ey2cBPqOW5QRJpdDt = name + ' - ' + title
				wrvU1Ey2cBPqOW5QRJpdDt = wrvU1Ey2cBPqOW5QRJpdDt.strip(AAh0X3OCacr4HpifRGLZKT)
				wrvU1Ey2cBPqOW5QRJpdDt = EEH4kBfGY0FuZUjeNn(wrvU1Ey2cBPqOW5QRJpdDt)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,vrEJRkchKxtDNiqO1b79mL5eT,24,bbVQhHcktxYBK9SRazqvyWgE2of,sCHVtMAvqirbQ4BUK3cgWo,str(eGmij1zPJBMQlaIcp))
		elif 'Clips' in url:
			vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Music/GetTracksBy?id=0&page='+mRwrKW6fNZV+'&size=30&type=15'
			Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-4th')
			items = fNntYJW45mEFSdRX8g.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title,B17r2fdFy9ns8tiOMLu in items:
				eGmij1zPJBMQlaIcp += 1
				bbVQhHcktxYBK9SRazqvyWgE2of = AApqPfNKwRLY2CIdmc6zly + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				wrvU1Ey2cBPqOW5QRJpdDt = title.strip(AAh0X3OCacr4HpifRGLZKT)
				wrvU1Ey2cBPqOW5QRJpdDt = EEH4kBfGY0FuZUjeNn(wrvU1Ey2cBPqOW5QRJpdDt)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,vrEJRkchKxtDNiqO1b79mL5eT,24,bbVQhHcktxYBK9SRazqvyWgE2of,sCHVtMAvqirbQ4BUK3cgWo,str(eGmij1zPJBMQlaIcp))
		elif 'category' in url:
			if 'category=6' in url:
				vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Music/GetTracksBy?id=0&page='+mRwrKW6fNZV+'&size=30&type=6'
				Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				vrEJRkchKxtDNiqO1b79mL5eT = AumFXji8b9d4B7DTCP+'/Music/GetTracksBy?id=0&page='+mRwrKW6fNZV+'&size=30&type=4'
				Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-EPISODES-6th')
			items = fNntYJW45mEFSdRX8g.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B17r2fdFy9ns8tiOMLu,name,title in items:
				eGmij1zPJBMQlaIcp += 1
				bbVQhHcktxYBK9SRazqvyWgE2of = AApqPfNKwRLY2CIdmc6zly + IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				wrvU1Ey2cBPqOW5QRJpdDt = name + ' - ' + title
				wrvU1Ey2cBPqOW5QRJpdDt = wrvU1Ey2cBPqOW5QRJpdDt.strip(AAh0X3OCacr4HpifRGLZKT)
				wrvU1Ey2cBPqOW5QRJpdDt = EEH4kBfGY0FuZUjeNn(wrvU1Ey2cBPqOW5QRJpdDt)
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+wrvU1Ey2cBPqOW5QRJpdDt,vrEJRkchKxtDNiqO1b79mL5eT,24,bbVQhHcktxYBK9SRazqvyWgE2of,sCHVtMAvqirbQ4BUK3cgWo,str(eGmij1zPJBMQlaIcp))
	if type=='Music' or type=='Program':
		if eGmij1zPJBMQlaIcp>25:
			title='صفحة '
			if TTtDQFAY086Gop1WbuXsHJkwxU=='en': title = ' Page '
			if TTtDQFAY086Gop1WbuXsHJkwxU=='fa': title = ' صفحه '
			if TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': title = ' صفحه '
			for D87M5ZyVCNoJbehEpsY3luRKaF in range(1,11):
				if not mRwrKW6fNZV==str(D87M5ZyVCNoJbehEpsY3luRKaF):
					IKhW9EMpvrmNOiHd1ge = '0'+str(D87M5ZyVCNoJbehEpsY3luRKaF)
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title+str(D87M5ZyVCNoJbehEpsY3luRKaF),url,23,sCHVtMAvqirbQ4BUK3cgWo,cuqjQlU0fzkLNvTI9m+IKhW9EMpvrmNOiHd1ge[-2:])
	return
def YH54mqkD2eU06(url,bbFPOJrmkCaE6ul37XiKU):
	AApqPfNKwRLY2CIdmc6zly = P2CxmQMAoviZF3s1(url)
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-PLAY-1st')
	items = fNntYJW45mEFSdRX8g.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(url)
		cuIJ3axEtVWvs = url.split('/')
		id,type = cuIJ3axEtVWvs[-1],cuIJ3axEtVWvs[3]
		B17r2fdFy9ns8tiOMLu = items[0][0]+TTtDQFAY086Gop1WbuXsHJkwxU+id+'/,'+bbFPOJrmkCaE6ul37XiKU+','+bbFPOJrmkCaE6ul37XiKU+'_'+items[0][2]
		V9TdsglcWYv0X.append('m3u8')
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	items = fNntYJW45mEFSdRX8g.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(url)
		cuIJ3axEtVWvs = url.split('/')
		id,type = cuIJ3axEtVWvs[-1],cuIJ3axEtVWvs[3]
		B17r2fdFy9ns8tiOMLu = items[0][0]+TTtDQFAY086Gop1WbuXsHJkwxU+id+'/'+bbFPOJrmkCaE6ul37XiKU+items[0][2]
		V9TdsglcWYv0X.append('mp4 url')
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	items = fNntYJW45mEFSdRX8g.findall('source src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu in items:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.replace('//','/')
		V9TdsglcWYv0X.append('mp4 src')
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	items = fNntYJW45mEFSdRX8g.findall('VideoAddress":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		B17r2fdFy9ns8tiOMLu = items[int(bbFPOJrmkCaE6ul37XiKU)-1]
		B17r2fdFy9ns8tiOMLu = AApqPfNKwRLY2CIdmc6zly+IgCGzHw45TJ7PeuO1EKl(B17r2fdFy9ns8tiOMLu)
		V9TdsglcWYv0X.append('mp4 address')
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	items = fNntYJW45mEFSdRX8g.findall('VoiceAddress":"(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		B17r2fdFy9ns8tiOMLu = items[int(bbFPOJrmkCaE6ul37XiKU)-1]
		B17r2fdFy9ns8tiOMLu = AApqPfNKwRLY2CIdmc6zly+IgCGzHw45TJ7PeuO1EKl(B17r2fdFy9ns8tiOMLu)
		V9TdsglcWYv0X.append('mp3 address')
		ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	if len(ss7YGDbuAIxgnqaQroTV)==1: B17r2fdFy9ns8tiOMLu = ss7YGDbuAIxgnqaQroTV[0]
	else:
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('اختر الفيديو المناسب:', V9TdsglcWYv0X)
		if jQLzA92KFEcpw == -1 : return
		B17r2fdFy9ns8tiOMLu = ss7YGDbuAIxgnqaQroTV[jQLzA92KFEcpw]
	CeXLtzElr5DHhs(B17r2fdFy9ns8tiOMLu,Ll1m0nJoaAPvHsXqyRE,'video')
	return
def P2CxmQMAoviZF3s1(url):
	if gAVl1vUmus8 in url: oT2iHwjfBx0FPX5ZCph9aWs38 = gAVl1vUmus8
	elif DbmJ9I0ZfXgcFlO8 in url: oT2iHwjfBx0FPX5ZCph9aWs38 = DbmJ9I0ZfXgcFlO8
	elif RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f in url: oT2iHwjfBx0FPX5ZCph9aWs38 = RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f
	elif JcHIgS70XANB5EpubYs in url: oT2iHwjfBx0FPX5ZCph9aWs38 = JcHIgS70XANB5EpubYs
	else: oT2iHwjfBx0FPX5ZCph9aWs38 = sCHVtMAvqirbQ4BUK3cgWo
	return oT2iHwjfBx0FPX5ZCph9aWs38
def OwYDCQce0WHKbqPg(url):
	if   gAVl1vUmus8 in url: TTtDQFAY086Gop1WbuXsHJkwxU = 'ar'
	elif DbmJ9I0ZfXgcFlO8 in url: TTtDQFAY086Gop1WbuXsHJkwxU = 'en'
	elif RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f in url: TTtDQFAY086Gop1WbuXsHJkwxU = 'fa'
	elif JcHIgS70XANB5EpubYs in url: TTtDQFAY086Gop1WbuXsHJkwxU = 'fa2'
	else: TTtDQFAY086Gop1WbuXsHJkwxU = sCHVtMAvqirbQ4BUK3cgWo
	return TTtDQFAY086Gop1WbuXsHJkwxU
def I2IfwUGCn68MRT3QFhWNjsDxrb(url):
	TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(url)
	vrEJRkchKxtDNiqO1b79mL5eT = url + '/Home/Live'
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-LIVE-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items = fNntYJW45mEFSdRX8g.findall('source src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	rdQ5tOIzuelfvcYbNsM = items[0]
	CeXLtzElr5DHhs(rdQ5tOIzuelfvcYbNsM,Ll1m0nJoaAPvHsXqyRE,'live')
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search:
		search = UyBdvjGrFxDWMpmLOXn()
		if not search: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	if showDialogs:
		iS3R0plk9urC7zGODJL8 = [ gAVl1vUmus8 , DbmJ9I0ZfXgcFlO8 , RRCclHyZr1K0UTbYxwvmF7PGsz3Q6f , JcHIgS70XANB5EpubYs ]
		CChFzu9SVf5UT4paLAKtEmJj = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		jQLzA92KFEcpw = Wdlg19qZ4apQtYFCINvBeML0c('اختر اللغة المناسبة:', CChFzu9SVf5UT4paLAKtEmJj)
		if jQLzA92KFEcpw == -1 : return
		website = iS3R0plk9urC7zGODJL8[jQLzA92KFEcpw]
	else:
		if '_IFILM-ARABIC_' in Z2VkQhiPAOuboSRB: website = gAVl1vUmus8
		elif '_IFILM-ENGLISH_' in Z2VkQhiPAOuboSRB: website = DbmJ9I0ZfXgcFlO8
		else: website = sCHVtMAvqirbQ4BUK3cgWo
	if not website: return
	TTtDQFAY086Gop1WbuXsHJkwxU = OwYDCQce0WHKbqPg(website)
	vrEJRkchKxtDNiqO1b79mL5eT = website + "/Home/Search?searchstring=" + ktT4O0VJm8UaDNlxKvinoBYFgdH
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'IFILM-SEARCH-1st')
	items = fNntYJW45mEFSdRX8g.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if items:
		for Mx0TQvmZAsedaGj4opVDJu5by8RUwS,B4SziFvRIXpPeGmfZDw3aVWJMAKNc,id,title in items:
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc in ['3','7']:
				title = title.replace('\\',sCHVtMAvqirbQ4BUK3cgWo)
				title = title.replace('"',sCHVtMAvqirbQ4BUK3cgWo)
				if B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='3':
					type = 'Series'
					if TTtDQFAY086Gop1WbuXsHJkwxU=='ar': name = 'مسلسل : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='en': name = 'Series : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa': name = 'سريال ها : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': name = 'سريال ها : '
				elif B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='5':
					type = 'Film'
					if TTtDQFAY086Gop1WbuXsHJkwxU=='ar': name = 'فيلم : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='en': name = 'Movie : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa': name = 'فيلم : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': name = 'فلم ها : '
				elif B4SziFvRIXpPeGmfZDw3aVWJMAKNc=='7':
					type = 'Program'
					if TTtDQFAY086Gop1WbuXsHJkwxU=='ar': name = 'برنامج : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='en': name = 'Program : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa': name = 'برنامه ها : '
					elif TTtDQFAY086Gop1WbuXsHJkwxU=='fa2': name = 'برنامه ها : '
				title = name + title
				B17r2fdFy9ns8tiOMLu = website + '/' + type + '/Content/' + id
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = IgCGzHw45TJ7PeuO1EKl(Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = website+Mx0TQvmZAsedaGj4opVDJu5by8RUwS
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,23,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'101')
	return
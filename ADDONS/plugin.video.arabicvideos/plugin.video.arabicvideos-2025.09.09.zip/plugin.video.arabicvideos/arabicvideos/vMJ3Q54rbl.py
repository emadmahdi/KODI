# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = fvYGxnZNUiyP4HJkMIoS25(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
Z0BYJQghVL1v87CAem = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
bojL8GTBgtMFR7HS3VvqW4kKY5cwy = YYEXZsUWhf52vz7HLxc0qGJ.path.join(Tv3HwUmSdkPOKaC5QulpJcDqy,SIkwCEdJHTD9v1(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
h1h4YaCvAmGFUr5VRZ = YYEXZsUWhf52vz7HLxc0qGJ.path.join(Tv3HwUmSdkPOKaC5QulpJcDqy,SIkwCEdJHTD9v1(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
xCqOYoZGHIwLDvtA1 = YYEXZsUWhf52vz7HLxc0qGJ.path.join(T169TYotn5V,jwzOabysh0Z(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),bGzRdmOErkIylxALniq6(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
L8cUEy6C0eV = hPFcB6Uxmabj59Iq(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
p1lGnjONoyMF3EaHD = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
kGphIxD89a2eY = RDwahqjPfbdyEiTtnLQu(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
sXro6TtgZpInHfC = SE97R3Dpj6dPLweVKU(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
DDEz0KV2oIOYNhB3nwlSkHCvg1 = EJgYdjbIiWe1apkQlZcR42(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
X4MfVKSCbdEYk0jB8qTvDQ35G = Js61GTdX5wzMurUqi7Z(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
DkhAYimsyVbS38j = rNq1RX4ZwSpgcM35tPG60Hl8bFdhk
Qh5rVmFxBf = XX4rMRSnQdbZ1NJiKu8pOfvDla
b0gemK2H87XMr6iYay = Y9Y7tpco2OSwMr5h4eZ3siT
def dBHD1Vl7hQuNOY(QQ8kHjYnKEDU3sxft9S5iRoB):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠹࠷࠴ࣉ"): ka7jz96YCdTBnQOLVPuJG3285MHf = zRx2OHPNa056WeY()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠺࠸࠶࣊"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(bojL8GTBgtMFR7HS3VvqW4kKY5cwy,ndkUxG9LtewJ,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==jwzOabysh0Z(u"࠻࠹࠸࣋"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(h1h4YaCvAmGFUr5VRZ,ndkUxG9LtewJ,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==SIkwCEdJHTD9v1(u"࠼࠺࠳࣌"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(xCqOYoZGHIwLDvtA1,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==IOHSz7YPF9WusGgUt1Dq(u"࠽࠴࠵࣍"): ka7jz96YCdTBnQOLVPuJG3285MHf = iA37QsOpfBYLEPhnm9DVa(ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠷࠵࠷࣎"): ka7jz96YCdTBnQOLVPuJG3285MHf = uFf3N5gCA6dVEWOwmUaLTJKGIip9(ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==jwzOabysh0Z(u"࠸࠶࠹࣏"): ka7jz96YCdTBnQOLVPuJG3285MHf = eeAS3qY7BV9ZXmFxJEDNbt(ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==zLjWeKu6JgNO7vocUD0Qpy(u"࠹࠸࠴࣐"): ka7jz96YCdTBnQOLVPuJG3285MHf = FFBy4HUcMaY2z1eEwASnRNJ6()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠺࠹࠶࣑"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(L8cUEy6C0eV,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==YQNd4wejLSAVJ6T(u"࠻࠺࠸࣒"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(p1lGnjONoyMF3EaHD,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==gDETKVh8mZe09Nd(u"࠼࠻࠳࣓"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(kGphIxD89a2eY,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠽࠵࠵ࣔ"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(sXro6TtgZpInHfC,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠷࠶࠷ࣕ"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(DDEz0KV2oIOYNhB3nwlSkHCvg1,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==oVwa0kcqxj1e7mLplAfZdGT(u"࠸࠷࠹ࣖ"): ka7jz96YCdTBnQOLVPuJG3285MHf = W0BFzMOVpdNxnmer5aZfs(X4MfVKSCbdEYk0jB8qTvDQ35G,lvzrYTpcBaK,ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qqw1upCsKM(u"࠹࠸࠻ࣗ"): ka7jz96YCdTBnQOLVPuJG3285MHf = EEa6Qdysp8SAt4rw(ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qeG16a4pbSHziNVQ2uFXrs(u"࠺࠹࠽ࣘ"): ka7jz96YCdTBnQOLVPuJG3285MHf = p81oimO3h6zDM2YI4HvZLQF0nAB();sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==oVwa0kcqxj1e7mLplAfZdGT(u"࠵࠵࠾࠰ࣙ"): ka7jz96YCdTBnQOLVPuJG3285MHf = jYic4ow5eTf7Mu3gv()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠶࠶࠸࠲ࣚ"): ka7jz96YCdTBnQOLVPuJG3285MHf = TRjz4QZhgPeSfA(ndkUxG9LtewJ);sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==qeG16a4pbSHziNVQ2uFXrs(u"࠷࠰࠹࠴ࣛ"): ka7jz96YCdTBnQOLVPuJG3285MHf = YSLDsNGeH8IZ4PbkRi();sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==sH6BOz5wKRFcEg(u"࠱࠱࠺࠶ࣜ"): ka7jz96YCdTBnQOLVPuJG3285MHf = MunsCSHyzRablkhUV6B5rcmKPjQA();sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==EJgYdjbIiWe1apkQlZcR42(u"࠲࠲࠻࠸ࣝ"): ka7jz96YCdTBnQOLVPuJG3285MHf = U2WMd83xw7yS1Zlbko();sS3wNx2O1ZQLyPcku8E5Tm7GW(ka7jz96YCdTBnQOLVPuJG3285MHf)
	elif QQ8kHjYnKEDU3sxft9S5iRoB==TzIj50KpohEOHx6CbZWqB(u"࠳࠳࠼࠺ࣞ"): ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif QQ8kHjYnKEDU3sxft9S5iRoB==XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠴࠴࠽࠼ࣟ"): ka7jz96YCdTBnQOLVPuJG3285MHf = YhDRf6Fxir3wX9u8ML1GOClo()
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = lvzrYTpcBaK
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def YhDRf6Fxir3wX9u8ML1GOClo():
	fri6g5k2WyC = IO7k2hZXSz(u"࠵࠵࠸࠴࣠")*IO7k2hZXSz(u"࠵࠵࠸࠴࣠")
	jWdq5GD1lFbH706miPhVEptB = T1eyjvbtkBKJhRmXqYCDcfHia()//fri6g5k2WyC
	oexJyAHb3DrE0Vl4svWgFTdZwPa = jWdq5GD1lFbH706miPhVEptB<YQNd4wejLSAVJ6T(u"࠺࠶࣡")
	size = VXWOCAE6ns3paJ8DLG479NQfMu+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(jWdq5GD1lFbH706miPhVEptB)+gDETKVh8mZe09Nd(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+B8alA5nvIhTxQ
	if oexJyAHb3DrE0Vl4svWgFTdZwPa:
		SH6EVn0T9d8bKCUMLl1sJOFR(wdyXQbPWRMOrg82,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(jWdq5GD1lFbH706miPhVEptB)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,oVwa0kcqxj1e7mLplAfZdGT(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return oexJyAHb3DrE0Vl4svWgFTdZwPa
def sS3wNx2O1ZQLyPcku8E5Tm7GW(aa0t2BHrOX8sdCm):
	if aa0t2BHrOX8sdCm: Ims96cLXkvKOx0GD(ndkUxG9LtewJ)
	return
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1(hPFcB6Uxmabj59Iq(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"࠷࠰࠹࠸࣢"))
	XAozRfZ68H9x2OsiP3LmIaql1(bGzRdmOErkIylxALniq6(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),jwzOabysh0Z(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"࠷࠶࠲ࣣ"))
	XAozRfZ68H9x2OsiP3LmIaql1(BWfpRku7SsM6cbE0eG(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),qqw1upCsKM(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),sCHVtMAvqirbQ4BUK3cgWo,SE97R3Dpj6dPLweVKU(u"࠸࠶࠳ࣤ"))
	XAozRfZ68H9x2OsiP3LmIaql1(bGzRdmOErkIylxALniq6(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"࠳࠳࠼࠵ࣥ"))
	return
def jYic4ow5eTf7Mu3gv():
	GfsyqYe3uNtzXCKSVn0T8D,qphvbDJWHnoAZ7ajde4tI8lg = ylW3f6Ru4xsKd5zS19GJQBVO(DkhAYimsyVbS38j)
	jgaNFU6OZtxXPMTh4DWI,x1iFdU4kutEJPODIjWnyM37s2bC9z = ylW3f6Ru4xsKd5zS19GJQBVO(Qh5rVmFxBf)
	Y6SR1VgikdjJ,KVfpMWtx5lbycgNIid8 = kAxsioNSB6w5cDaKGlueOjXd(b0gemK2H87XMr6iYay)
	WgIURhYzx32obrGt6kcBLXP85qsOjK,dlZz6BoTWFJRxbpCnY1Ij0GvQ = GfsyqYe3uNtzXCKSVn0T8D+jgaNFU6OZtxXPMTh4DWI+Y6SR1VgikdjJ,qphvbDJWHnoAZ7ajde4tI8lg+x1iFdU4kutEJPODIjWnyM37s2bC9z+KVfpMWtx5lbycgNIid8
	fSHCW2FmqlKVN = SIkwCEdJHTD9v1(u"ࠩࠣࠬࠬࠚ")+S6QPHy8gqKcMCNWdus7(GfsyqYe3uNtzXCKSVn0T8D)+qeG16a4pbSHziNVQ2uFXrs(u"ࠪࠤ࠲ࠦࠧࠛ")+str(qphvbDJWHnoAZ7ajde4tI8lg)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	pnXGs1DmPvYJE2SliMLB = Js61GTdX5wzMurUqi7Z(u"ࠬࠦࠨࠨࠝ")+S6QPHy8gqKcMCNWdus7(jgaNFU6OZtxXPMTh4DWI)+fvYGxnZNUiyP4HJkMIoS25(u"࠭ࠠ࠮ࠢࠪࠞ")+str(x1iFdU4kutEJPODIjWnyM37s2bC9z)+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	yzQK57YoRave9u0TGlJWA8MNrU2 = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࠢࠫࠫࠠ")+S6QPHy8gqKcMCNWdus7(Y6SR1VgikdjJ)+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(KVfpMWtx5lbycgNIid8)+SIkwCEdJHTD9v1(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	Z69c1xJwW27UR = hPFcB6Uxmabj59Iq(u"ࠫࠥ࠮ࠧࠣ")+S6QPHy8gqKcMCNWdus7(WgIURhYzx32obrGt6kcBLXP85qsOjK)+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࠦ࠭ࠡࠩࠤ")+str(dlZz6BoTWFJRxbpCnY1Ij0GvQ)+t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	XAozRfZ68H9x2OsiP3LmIaql1(GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),Z0BYJQghVL1v87CAem+EJgYdjbIiWe1apkQlZcR42(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠴࠴࠽࠺ࣦ"))
	XAozRfZ68H9x2OsiP3LmIaql1(bGzRdmOErkIylxALniq6(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),VXWOCAE6ns3paJ8DLG479NQfMu+Js61GTdX5wzMurUqi7Z(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,oVwa0kcqxj1e7mLplAfZdGT(u"࠽࠾࠿࠹ࣧ"))
	XAozRfZ68H9x2OsiP3LmIaql1(RDwahqjPfbdyEiTtnLQu(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),Z0BYJQghVL1v87CAem+gDETKVh8mZe09Nd(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+fSHCW2FmqlKVN,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠶࠶࠸࠲ࣨ"))
	XAozRfZ68H9x2OsiP3LmIaql1(IOHSz7YPF9WusGgUt1Dq(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),Z0BYJQghVL1v87CAem+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+pnXGs1DmPvYJE2SliMLB,sCHVtMAvqirbQ4BUK3cgWo,YQNd4wejLSAVJ6T(u"࠷࠰࠹࠴ࣩ"))
	XAozRfZ68H9x2OsiP3LmIaql1(IO7k2hZXSz(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),Z0BYJQghVL1v87CAem+aenpKvQCGVzhLXEdWiDIZ(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+yzQK57YoRave9u0TGlJWA8MNrU2,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠱࠱࠺࠶࣪"))
	XAozRfZ68H9x2OsiP3LmIaql1(phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),Z0BYJQghVL1v87CAem+zLjWeKu6JgNO7vocUD0Qpy(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"࠲࠲࠻࠸࣫"))
	return
def U2WMd83xw7yS1Zlbko():
	aa0t2BHrOX8sdCm = lvzrYTpcBaK
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA:
		wwQ6HZ27l5iPk0Xd4fjRB8MGJ = MunsCSHyzRablkhUV6B5rcmKPjQA()
		nE3LZpgxBG4DNU6fh1alO5KsHu8y = W0BFzMOVpdNxnmer5aZfs(XX4rMRSnQdbZ1NJiKu8pOfvDla,ndkUxG9LtewJ,lvzrYTpcBaK)
		aa0t2BHrOX8sdCm = wwQ6HZ27l5iPk0Xd4fjRB8MGJ and nE3LZpgxBG4DNU6fh1alO5KsHu8y
		if aa0t2BHrOX8sdCm: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SIkwCEdJHTD9v1(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return aa0t2BHrOX8sdCm
def YSLDsNGeH8IZ4PbkRi():
	import i5kNU6T7vE
	i5kNU6T7vE.uqkXOJBAitwLZfCoQsKPIdyV0Tj7zR()
	bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(EJgYdjbIiWe1apkQlZcR42(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IO7k2hZXSz(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),IOHSz7YPF9WusGgUt1Dq(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		bEZlOa1inyrUgdTw9BKNtcMCLYI = W0BFzMOVpdNxnmer5aZfs(XX4rMRSnQdbZ1NJiKu8pOfvDla,ndkUxG9LtewJ,lvzrYTpcBaK)
		if bEZlOa1inyrUgdTw9BKNtcMCLYI: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SE97R3Dpj6dPLweVKU(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IOHSz7YPF9WusGgUt1Dq(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def MunsCSHyzRablkhUV6B5rcmKPjQA():
	bEZlOa1inyrUgdTw9BKNtcMCLYI = lvzrYTpcBaK
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(IO7k2hZXSz(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧิฦส่ࠬ࠻"),YQNd4wejLSAVJ6T(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		try:
			YYEXZsUWhf52vz7HLxc0qGJ.remove(Y9Y7tpco2OSwMr5h4eZ3siT)
			bEZlOa1inyrUgdTw9BKNtcMCLYI = ndkUxG9LtewJ
		except: pass
		if bEZlOa1inyrUgdTw9BKNtcMCLYI: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,gDETKVh8mZe09Nd(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return bEZlOa1inyrUgdTw9BKNtcMCLYI
def jYic4ow5eTf7Mu3gv():
	GfsyqYe3uNtzXCKSVn0T8D,qphvbDJWHnoAZ7ajde4tI8lg = ylW3f6Ru4xsKd5zS19GJQBVO(DkhAYimsyVbS38j)
	jgaNFU6OZtxXPMTh4DWI,x1iFdU4kutEJPODIjWnyM37s2bC9z = ylW3f6Ru4xsKd5zS19GJQBVO(Qh5rVmFxBf)
	Y6SR1VgikdjJ,KVfpMWtx5lbycgNIid8 = kAxsioNSB6w5cDaKGlueOjXd(b0gemK2H87XMr6iYay)
	WgIURhYzx32obrGt6kcBLXP85qsOjK,dlZz6BoTWFJRxbpCnY1Ij0GvQ = GfsyqYe3uNtzXCKSVn0T8D+jgaNFU6OZtxXPMTh4DWI+Y6SR1VgikdjJ,qphvbDJWHnoAZ7ajde4tI8lg+x1iFdU4kutEJPODIjWnyM37s2bC9z+KVfpMWtx5lbycgNIid8
	fSHCW2FmqlKVN = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࠥ࠮ࠧ࠿")+S6QPHy8gqKcMCNWdus7(GfsyqYe3uNtzXCKSVn0T8D)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࠦ࠭ࠡࠩࡀ")+str(qphvbDJWHnoAZ7ajde4tI8lg)+t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	pnXGs1DmPvYJE2SliMLB = sH6BOz5wKRFcEg(u"ࠧࠡࠪࠪࡂ")+S6QPHy8gqKcMCNWdus7(jgaNFU6OZtxXPMTh4DWI)+oVwa0kcqxj1e7mLplAfZdGT(u"ࠨࠢ࠰ࠤࠬࡃ")+str(x1iFdU4kutEJPODIjWnyM37s2bC9z)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	yzQK57YoRave9u0TGlJWA8MNrU2 = Js61GTdX5wzMurUqi7Z(u"ࠪࠤ࠭࠭ࡅ")+S6QPHy8gqKcMCNWdus7(Y6SR1VgikdjJ)+GVurlv8HeoXEzPRiQB7Ty(u"ࠫࠥ࠳ࠠࠨࡆ")+str(KVfpMWtx5lbycgNIid8)+bGzRdmOErkIylxALniq6(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	Z69c1xJwW27UR = bGzRdmOErkIylxALniq6(u"࠭ࠠࠩࠩࡈ")+S6QPHy8gqKcMCNWdus7(WgIURhYzx32obrGt6kcBLXP85qsOjK)+sH6BOz5wKRFcEg(u"ࠧࠡ࠯ࠣࠫࡉ")+str(dlZz6BoTWFJRxbpCnY1Ij0GvQ)+Js61GTdX5wzMurUqi7Z(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	XAozRfZ68H9x2OsiP3LmIaql1(RDwahqjPfbdyEiTtnLQu(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),Z0BYJQghVL1v87CAem+qeG16a4pbSHziNVQ2uFXrs(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,hPFcB6Uxmabj59Iq(u"࠳࠳࠼࠹࣬"))
	XAozRfZ68H9x2OsiP3LmIaql1(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),VXWOCAE6ns3paJ8DLG479NQfMu+SIkwCEdJHTD9v1(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,IO7k2hZXSz(u"࠼࠽࠾࠿࣭"))
	XAozRfZ68H9x2OsiP3LmIaql1(fvYGxnZNUiyP4HJkMIoS25(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),Z0BYJQghVL1v87CAem+sH6BOz5wKRFcEg(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+fSHCW2FmqlKVN,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"࠵࠵࠾࠱࣮"))
	XAozRfZ68H9x2OsiP3LmIaql1(Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),Z0BYJQghVL1v87CAem+YQNd4wejLSAVJ6T(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+pnXGs1DmPvYJE2SliMLB,sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠶࠶࠸࠳࣯"))
	XAozRfZ68H9x2OsiP3LmIaql1(gDETKVh8mZe09Nd(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),Z0BYJQghVL1v87CAem+bGzRdmOErkIylxALniq6(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+yzQK57YoRave9u0TGlJWA8MNrU2,sCHVtMAvqirbQ4BUK3cgWo,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠷࠰࠹࠵ࣰ"))
	XAozRfZ68H9x2OsiP3LmIaql1(qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),Z0BYJQghVL1v87CAem+IOHSz7YPF9WusGgUt1Dq(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,qqw1upCsKM(u"࠱࠱࠺࠷ࣱ"))
	return
def zRx2OHPNa056WeY():
	GfsyqYe3uNtzXCKSVn0T8D,qphvbDJWHnoAZ7ajde4tI8lg = ylW3f6Ru4xsKd5zS19GJQBVO(bojL8GTBgtMFR7HS3VvqW4kKY5cwy)
	jgaNFU6OZtxXPMTh4DWI,x1iFdU4kutEJPODIjWnyM37s2bC9z = ylW3f6Ru4xsKd5zS19GJQBVO(h1h4YaCvAmGFUr5VRZ)
	Y6SR1VgikdjJ,KVfpMWtx5lbycgNIid8 = ylW3f6Ru4xsKd5zS19GJQBVO(xCqOYoZGHIwLDvtA1)
	WgIURhYzx32obrGt6kcBLXP85qsOjK,dlZz6BoTWFJRxbpCnY1Ij0GvQ = kAxsioNSB6w5cDaKGlueOjXd(n0neOuhY3xdkSvFQXwoHf4i2l19q)
	WgIURhYzx32obrGt6kcBLXP85qsOjK -= TzIj50KpohEOHx6CbZWqB(u"࠴࠸࠻࠺࠹ࣲ")
	dlZz6BoTWFJRxbpCnY1Ij0GvQ -= zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	y0k6SDdtf5PiGXEFuH = str(YYEXZsUWhf52vz7HLxc0qGJ.listdir(ns962b50AYBo8k))
	CzP6R02emKxJn7wr = y0k6SDdtf5PiGXEFuH.count(IO7k2hZXSz(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+y0k6SDdtf5PiGXEFuH.count(aYH620Dh48GEsTFfOBSQ7r(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	fSHCW2FmqlKVN = phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࡙ࠩࠣࠬࠬ")+S6QPHy8gqKcMCNWdus7(GfsyqYe3uNtzXCKSVn0T8D)+aenpKvQCGVzhLXEdWiDIZ(u"ࠪࠤ࠲࡚ࠦࠧ")+str(qphvbDJWHnoAZ7ajde4tI8lg)+aenpKvQCGVzhLXEdWiDIZ(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	pnXGs1DmPvYJE2SliMLB = aYH620Dh48GEsTFfOBSQ7r(u"ࠬࠦࠨࠨ࡜")+S6QPHy8gqKcMCNWdus7(jgaNFU6OZtxXPMTh4DWI)+SE97R3Dpj6dPLweVKU(u"࠭ࠠ࠮ࠢࠪ࡝")+str(x1iFdU4kutEJPODIjWnyM37s2bC9z)+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	yzQK57YoRave9u0TGlJWA8MNrU2 = aYH620Dh48GEsTFfOBSQ7r(u"ࠨࠢࠫࠫ࡟")+S6QPHy8gqKcMCNWdus7(Y6SR1VgikdjJ)+fvYGxnZNUiyP4HJkMIoS25(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(KVfpMWtx5lbycgNIid8)+BWfpRku7SsM6cbE0eG(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	Z69c1xJwW27UR = IOHSz7YPF9WusGgUt1Dq(u"ࠫࠥ࠮ࠧࡢ")+S6QPHy8gqKcMCNWdus7(WgIURhYzx32obrGt6kcBLXP85qsOjK)+sH6BOz5wKRFcEg(u"ࠬ࠯ࠧࡣ")
	Z8ZeoXj9CAtQVkWNnOgBYM = t19ZOVHA4CpwFKaeiubcMGvz(u"࠭ࠠࠩࠩࡤ")+str(CzP6R02emKxJn7wr)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	nsH0Kw8EN6OMS9A7 = GfsyqYe3uNtzXCKSVn0T8D+jgaNFU6OZtxXPMTh4DWI+Y6SR1VgikdjJ+WgIURhYzx32obrGt6kcBLXP85qsOjK
	l1ybzmhn4Pt5qKTrY = qphvbDJWHnoAZ7ajde4tI8lg+x1iFdU4kutEJPODIjWnyM37s2bC9z+KVfpMWtx5lbycgNIid8+dlZz6BoTWFJRxbpCnY1Ij0GvQ+CzP6R02emKxJn7wr
	T67f3LG49xpP8zcN = t19ZOVHA4CpwFKaeiubcMGvz(u"ࠨࠢࠫࠫࡦ")+S6QPHy8gqKcMCNWdus7(nsH0Kw8EN6OMS9A7)+qqw1upCsKM(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(l1ybzmhn4Pt5qKTrY)+hPFcB6Uxmabj59Iq(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	XAozRfZ68H9x2OsiP3LmIaql1(EJgYdjbIiWe1apkQlZcR42(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),Z0BYJQghVL1v87CAem+IO7k2hZXSz(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,aYH620Dh48GEsTFfOBSQ7r(u"࠹࠷࠹ࣳ"))
	XAozRfZ68H9x2OsiP3LmIaql1(TzIj50KpohEOHx6CbZWqB(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),VXWOCAE6ns3paJ8DLG479NQfMu+aenpKvQCGVzhLXEdWiDIZ(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,aenpKvQCGVzhLXEdWiDIZ(u"࠼࠽࠾࠿ࣴ"))
	XAozRfZ68H9x2OsiP3LmIaql1(aenpKvQCGVzhLXEdWiDIZ(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),Z0BYJQghVL1v87CAem+aYH620Dh48GEsTFfOBSQ7r(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+fSHCW2FmqlKVN,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"࠻࠹࠷ࣵ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),Z0BYJQghVL1v87CAem+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+pnXGs1DmPvYJE2SliMLB,sCHVtMAvqirbQ4BUK3cgWo,bGzRdmOErkIylxALniq6(u"࠼࠺࠲ࣶ"))
	XAozRfZ68H9x2OsiP3LmIaql1(bGzRdmOErkIylxALniq6(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),Z0BYJQghVL1v87CAem+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+yzQK57YoRave9u0TGlJWA8MNrU2,sCHVtMAvqirbQ4BUK3cgWo,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠽࠴࠴ࣷ"))
	XAozRfZ68H9x2OsiP3LmIaql1(GVurlv8HeoXEzPRiQB7Ty(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),Z0BYJQghVL1v87CAem+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,EJgYdjbIiWe1apkQlZcR42(u"࠷࠵࠶ࣸ"))
	XAozRfZ68H9x2OsiP3LmIaql1(IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),Z0BYJQghVL1v87CAem+TzIj50KpohEOHx6CbZWqB(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+Z8ZeoXj9CAtQVkWNnOgBYM,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"࠸࠶࠹ࣹ"))
	return
def FFBy4HUcMaY2z1eEwASnRNJ6():
	YRtnaC5AoUZ = ndkUxG9LtewJ if qeG16a4pbSHziNVQ2uFXrs(u"ࠫ࠴࠭ࡷ") in T169TYotn5V else lvzrYTpcBaK
	if not YRtnaC5AoUZ:
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SE97R3Dpj6dPLweVKU(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	VCYw96jJq4Gk = fDQNTKLnvHaWw2BEAIzg0FPMjyq.getSetting(hPFcB6Uxmabj59Iq(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not VCYw96jJq4Gk: p81oimO3h6zDM2YI4HvZLQF0nAB()
	GfsyqYe3uNtzXCKSVn0T8D,qphvbDJWHnoAZ7ajde4tI8lg = ylW3f6Ru4xsKd5zS19GJQBVO(L8cUEy6C0eV)
	jgaNFU6OZtxXPMTh4DWI,x1iFdU4kutEJPODIjWnyM37s2bC9z = ylW3f6Ru4xsKd5zS19GJQBVO(p1lGnjONoyMF3EaHD)
	Y6SR1VgikdjJ,KVfpMWtx5lbycgNIid8 = ylW3f6Ru4xsKd5zS19GJQBVO(kGphIxD89a2eY)
	WgIURhYzx32obrGt6kcBLXP85qsOjK,dlZz6BoTWFJRxbpCnY1Ij0GvQ = ylW3f6Ru4xsKd5zS19GJQBVO(sXro6TtgZpInHfC)
	OtVkjfFdX1ewgznLEbHSRp2oUyqx,CzP6R02emKxJn7wr = ylW3f6Ru4xsKd5zS19GJQBVO(DDEz0KV2oIOYNhB3nwlSkHCvg1)
	O30gjlUPa2h6fnmR,vWiBSTVnApJX5lshcuH1z3xrN = ylW3f6Ru4xsKd5zS19GJQBVO(X4MfVKSCbdEYk0jB8qTvDQ35G)
	fSHCW2FmqlKVN = qqw1upCsKM(u"ࠧࠡࠪࠪࡺ")+S6QPHy8gqKcMCNWdus7(GfsyqYe3uNtzXCKSVn0T8D)+sH6BOz5wKRFcEg(u"ࠨࠢ࠰ࠤࠬࡻ")+str(qphvbDJWHnoAZ7ajde4tI8lg)+SIkwCEdJHTD9v1(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	pnXGs1DmPvYJE2SliMLB = BWfpRku7SsM6cbE0eG(u"ࠪࠤ࠭࠭ࡽ")+S6QPHy8gqKcMCNWdus7(jgaNFU6OZtxXPMTh4DWI)+fvYGxnZNUiyP4HJkMIoS25(u"ࠫࠥ࠳ࠠࠨࡾ")+str(x1iFdU4kutEJPODIjWnyM37s2bC9z)+hPFcB6Uxmabj59Iq(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	yzQK57YoRave9u0TGlJWA8MNrU2 = SIkwCEdJHTD9v1(u"࠭ࠠࠩࠩࢀ")+S6QPHy8gqKcMCNWdus7(Y6SR1VgikdjJ)+oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࠡ࠯ࠣࠫࢁ")+str(KVfpMWtx5lbycgNIid8)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	Z69c1xJwW27UR = gDETKVh8mZe09Nd(u"ࠩࠣࠬࠬࢃ")+S6QPHy8gqKcMCNWdus7(WgIURhYzx32obrGt6kcBLXP85qsOjK)+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࠤ࠲ࠦࠧࢄ")+str(dlZz6BoTWFJRxbpCnY1Ij0GvQ)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	Z8ZeoXj9CAtQVkWNnOgBYM = IO7k2hZXSz(u"ࠬࠦࠨࠨࢆ")+S6QPHy8gqKcMCNWdus7(OtVkjfFdX1ewgznLEbHSRp2oUyqx)+IO7k2hZXSz(u"࠭ࠠ࠮ࠢࠪࢇ")+str(CzP6R02emKxJn7wr)+hPFcB6Uxmabj59Iq(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	KVYnfTSEv7uCkeb1o6 = zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࠢࠫࠫࢉ")+S6QPHy8gqKcMCNWdus7(O30gjlUPa2h6fnmR)+GVurlv8HeoXEzPRiQB7Ty(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(vWiBSTVnApJX5lshcuH1z3xrN)+zLjWeKu6JgNO7vocUD0Qpy(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	nsH0Kw8EN6OMS9A7 = GfsyqYe3uNtzXCKSVn0T8D+jgaNFU6OZtxXPMTh4DWI+Y6SR1VgikdjJ+WgIURhYzx32obrGt6kcBLXP85qsOjK+OtVkjfFdX1ewgznLEbHSRp2oUyqx+O30gjlUPa2h6fnmR
	l1ybzmhn4Pt5qKTrY = qphvbDJWHnoAZ7ajde4tI8lg+x1iFdU4kutEJPODIjWnyM37s2bC9z+KVfpMWtx5lbycgNIid8+dlZz6BoTWFJRxbpCnY1Ij0GvQ+CzP6R02emKxJn7wr+vWiBSTVnApJX5lshcuH1z3xrN
	T67f3LG49xpP8zcN = qeG16a4pbSHziNVQ2uFXrs(u"ࠫࠥ࠮ࠧࢌ")+S6QPHy8gqKcMCNWdus7(nsH0Kw8EN6OMS9A7)+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࠦ࠭ࠡࠩࢍ")+str(l1ybzmhn4Pt5qKTrY)+qeG16a4pbSHziNVQ2uFXrs(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	XAozRfZ68H9x2OsiP3LmIaql1(qqw1upCsKM(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),Z0BYJQghVL1v87CAem+gDETKVh8mZe09Nd(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),sCHVtMAvqirbQ4BUK3cgWo,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠹࠸࠼ࣺ"))
	XAozRfZ68H9x2OsiP3LmIaql1(iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),Z0BYJQghVL1v87CAem+SE97R3Dpj6dPLweVKU(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,sH6BOz5wKRFcEg(u"࠺࠹࠼ࣻ"))
	XAozRfZ68H9x2OsiP3LmIaql1(qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),VXWOCAE6ns3paJ8DLG479NQfMu+t19ZOVHA4CpwFKaeiubcMGvz(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,RDwahqjPfbdyEiTtnLQu(u"࠽࠾࠿࠹ࣼ"))
	XAozRfZ68H9x2OsiP3LmIaql1(IO7k2hZXSz(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),Z0BYJQghVL1v87CAem+Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+fSHCW2FmqlKVN,sCHVtMAvqirbQ4BUK3cgWo,fvYGxnZNUiyP4HJkMIoS25(u"࠼࠻࠱ࣽ"))
	XAozRfZ68H9x2OsiP3LmIaql1(fvYGxnZNUiyP4HJkMIoS25(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),Z0BYJQghVL1v87CAem+E2QIcUfmlwa3xR17DFrkezBSsyh(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+pnXGs1DmPvYJE2SliMLB,sCHVtMAvqirbQ4BUK3cgWo,GVurlv8HeoXEzPRiQB7Ty(u"࠽࠵࠳ࣾ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Js61GTdX5wzMurUqi7Z(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),Z0BYJQghVL1v87CAem+iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+yzQK57YoRave9u0TGlJWA8MNrU2,sCHVtMAvqirbQ4BUK3cgWo,BWfpRku7SsM6cbE0eG(u"࠷࠶࠵ࣿ"))
	XAozRfZ68H9x2OsiP3LmIaql1(Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),Z0BYJQghVL1v87CAem+RDwahqjPfbdyEiTtnLQu(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+Z69c1xJwW27UR,sCHVtMAvqirbQ4BUK3cgWo,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠸࠷࠷ऀ"))
	XAozRfZ68H9x2OsiP3LmIaql1(hPFcB6Uxmabj59Iq(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),Z0BYJQghVL1v87CAem+IOHSz7YPF9WusGgUt1Dq(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+Z8ZeoXj9CAtQVkWNnOgBYM,sCHVtMAvqirbQ4BUK3cgWo,zLjWeKu6JgNO7vocUD0Qpy(u"࠹࠸࠹ँ"))
	XAozRfZ68H9x2OsiP3LmIaql1(fvYGxnZNUiyP4HJkMIoS25(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),Z0BYJQghVL1v87CAem+GVurlv8HeoXEzPRiQB7Ty(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+KVYnfTSEv7uCkeb1o6,sCHVtMAvqirbQ4BUK3cgWo,TzIj50KpohEOHx6CbZWqB(u"࠺࠹࠻ं"))
	return
def TRjz4QZhgPeSfA(showDialogs):
	if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,Js61GTdX5wzMurUqi7Z(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	btF2UVrDu0OhLKd,OmgRUsj7ZTqlNQcWaDKBPvreG2 = [],BewrUo9ANCa17G43Sn0LH5xh
	for gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd,p3Av2RJfhITqyOMa14xGLEjXkm,rvQJnhfgX4FaNeA8yutLl7sO in YYEXZsUWhf52vz7HLxc0qGJ.walk(rNq1RX4ZwSpgcM35tPG60Hl8bFdhk,topdown=lvzrYTpcBaK):
		U6HkgWC01ds2FGB = len(rvQJnhfgX4FaNeA8yutLl7sO)
		if U6HkgWC01ds2FGB>YQNd4wejLSAVJ6T(u"࠹࠵࠶ः"): btF2UVrDu0OhLKd.append(p3Av2RJfhITqyOMa14xGLEjXkm)
		OmgRUsj7ZTqlNQcWaDKBPvreG2 += U6HkgWC01ds2FGB
	SXVNwyeb5fRcz = OmgRUsj7ZTqlNQcWaDKBPvreG2>XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = VXWOCAE6ns3paJ8DLG479NQfMu+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(OmgRUsj7ZTqlNQcWaDKBPvreG2)+Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+B8alA5nvIhTxQ
		if not btF2UVrDu0OhLKd and not SXVNwyeb5fRcz: bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: bR4jqNrpMesHt93OgGKi6WDVaQA = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
	if bR4jqNrpMesHt93OgGKi6WDVaQA==zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU:
		if SXVNwyeb5fRcz: W0BFzMOVpdNxnmer5aZfs(gkmTAa1u4f7oyeWIBZLSH2RQ5C3Vvd,lvzrYTpcBaK,lvzrYTpcBaK)
		elif btF2UVrDu0OhLKd:
			for p3Av2RJfhITqyOMa14xGLEjXkm in btF2UVrDu0OhLKd: W0BFzMOVpdNxnmer5aZfs(p3Av2RJfhITqyOMa14xGLEjXkm,lvzrYTpcBaK,lvzrYTpcBaK)
	return
def p81oimO3h6zDM2YI4HvZLQF0nAB():
	aa0t2BHrOX8sdCm = lvzrYTpcBaK
	bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,gDETKVh8mZe09Nd(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if bR4jqNrpMesHt93OgGKi6WDVaQA==-iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠷अ"): return
	if bR4jqNrpMesHt93OgGKi6WDVaQA:
		import subprocess as n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx
		try:
			n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.Popen(BWfpRku7SsM6cbE0eG(u"ࠪࡷࡺ࠭ࢧ"))
			aa0t2BHrOX8sdCm = ndkUxG9LtewJ
		except: pass
		if aa0t2BHrOX8sdCm:
			xtSlB2jwa3ULO6CuAk = L8cUEy6C0eV+AAh0X3OCacr4HpifRGLZKT+p1lGnjONoyMF3EaHD+AAh0X3OCacr4HpifRGLZKT+kGphIxD89a2eY+AAh0X3OCacr4HpifRGLZKT+sXro6TtgZpInHfC+AAh0X3OCacr4HpifRGLZKT+DDEz0KV2oIOYNhB3nwlSkHCvg1+AAh0X3OCacr4HpifRGLZKT+X4MfVKSCbdEYk0jB8qTvDQ35G
			AAabjHUIdWB3e5QhPyz4 = n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.Popen(IO7k2hZXSz(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+xtSlB2jwa3ULO6CuAk+YQNd4wejLSAVJ6T(u"ࠬࠨࠧࢩ"),shell=ndkUxG9LtewJ,stdin=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE,stdout=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE,stderr=n7P3zoZlpWTr9VBNIQc2tOHAJ40Rx.PIPE)
			ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IO7k2hZXSz(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return aa0t2BHrOX8sdCm
def S6QPHy8gqKcMCNWdus7(nsH0Kw8EN6OMS9A7):
	for pkO5dBQveUZuJFt0 in [YQNd4wejLSAVJ6T(u"ࠨࡄࠪࢬ"),aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡎࡆࠬࢭ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠪࡑࡇ࠭ࢮ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠫࡌࡈࠧࢯ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࡚ࠬࡂࠨࢰ")]:
		if nsH0Kw8EN6OMS9A7<IOHSz7YPF9WusGgUt1Dq(u"࠱࠱࠴࠷आ"): break
		else: nsH0Kw8EN6OMS9A7 /= TzIj50KpohEOHx6CbZWqB(u"࠲࠲࠵࠸࠳࠶इ")
	T67f3LG49xpP8zcN = bGzRdmOErkIylxALniq6(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(nsH0Kw8EN6OMS9A7,pkO5dBQveUZuJFt0)
	return T67f3LG49xpP8zcN
def ylW3f6Ru4xsKd5zS19GJQBVO(qyVsFcwBI2oHbNUnS4laWz=oVwa0kcqxj1e7mLplAfZdGT(u"ࠧ࠯ࠩࢲ")):
	global LLsn7pTBwfOGxd1tR9PjVqJCyk,vMp96CPXhBFJndU1
	LLsn7pTBwfOGxd1tR9PjVqJCyk,vMp96CPXhBFJndU1 = BewrUo9ANCa17G43Sn0LH5xh,BewrUo9ANCa17G43Sn0LH5xh
	def yysVugaCPFolUTciQGmnWOf1(qyVsFcwBI2oHbNUnS4laWz):
		global LLsn7pTBwfOGxd1tR9PjVqJCyk,vMp96CPXhBFJndU1
		if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(qyVsFcwBI2oHbNUnS4laWz):
			if BewrUo9ANCa17G43Sn0LH5xh and jwzOabysh0Z(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(YYEXZsUWhf52vz7HLxc0qGJ):
				for IMKF20LRkE18clhbJX3 in YYEXZsUWhf52vz7HLxc0qGJ.scandir(qyVsFcwBI2oHbNUnS4laWz):
					if IMKF20LRkE18clhbJX3.is_dir(follow_symlinks=lvzrYTpcBaK):
						yysVugaCPFolUTciQGmnWOf1(IMKF20LRkE18clhbJX3.path)
					elif IMKF20LRkE18clhbJX3.is_file(follow_symlinks=lvzrYTpcBaK):
						LLsn7pTBwfOGxd1tR9PjVqJCyk += IMKF20LRkE18clhbJX3.stat().st_size
						vMp96CPXhBFJndU1 += zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			else:
				for IMKF20LRkE18clhbJX3 in YYEXZsUWhf52vz7HLxc0qGJ.listdir(qyVsFcwBI2oHbNUnS4laWz):
					VI319xM5FmX = YYEXZsUWhf52vz7HLxc0qGJ.path.abspath(YYEXZsUWhf52vz7HLxc0qGJ.path.join(qyVsFcwBI2oHbNUnS4laWz,IMKF20LRkE18clhbJX3))
					if YYEXZsUWhf52vz7HLxc0qGJ.path.isdir(VI319xM5FmX):
						yysVugaCPFolUTciQGmnWOf1(VI319xM5FmX)
					elif YYEXZsUWhf52vz7HLxc0qGJ.path.isfile(VI319xM5FmX):
						nsH0Kw8EN6OMS9A7,l1ybzmhn4Pt5qKTrY = kAxsioNSB6w5cDaKGlueOjXd(VI319xM5FmX)
						LLsn7pTBwfOGxd1tR9PjVqJCyk += nsH0Kw8EN6OMS9A7
						vMp96CPXhBFJndU1 += l1ybzmhn4Pt5qKTrY
		return
	try: yysVugaCPFolUTciQGmnWOf1(qyVsFcwBI2oHbNUnS4laWz)
	except: pass
	return LLsn7pTBwfOGxd1tR9PjVqJCyk,vMp96CPXhBFJndU1
def uFf3N5gCA6dVEWOwmUaLTJKGIip9(showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,VXWOCAE6ns3paJ8DLG479NQfMu+phlEoViHIrU5ajAkv1DNGXfyqMB9(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+slFfrUIWCowaBA7tce3iZbj8xn+qeG16a4pbSHziNVQ2uFXrs(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+slFfrUIWCowaBA7tce3iZbj8xn+E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫฤࠧࠡࠨࢶ")+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return
	MweNfdicjkgpGzoJVLTOD = W0BFzMOVpdNxnmer5aZfs(bojL8GTBgtMFR7HS3VvqW4kKY5cwy,ndkUxG9LtewJ,lvzrYTpcBaK)
	H5iLZGEv3PaFMtSYjNe = W0BFzMOVpdNxnmer5aZfs(h1h4YaCvAmGFUr5VRZ,ndkUxG9LtewJ,lvzrYTpcBaK)
	ZzNgeikb4CQd = W0BFzMOVpdNxnmer5aZfs(xCqOYoZGHIwLDvtA1,lvzrYTpcBaK,lvzrYTpcBaK)
	i3buwHQmaZAPyhSDpGXMg8jBEO = iA37QsOpfBYLEPhnm9DVa(lvzrYTpcBaK)
	BBywvhHKCQDdZ7f = eeAS3qY7BV9ZXmFxJEDNbt(lvzrYTpcBaK)
	succeeded = all([MweNfdicjkgpGzoJVLTOD,H5iLZGEv3PaFMtSYjNe,ZzNgeikb4CQd,i3buwHQmaZAPyhSDpGXMg8jBEO,BBywvhHKCQDdZ7f])
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IO7k2hZXSz(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,SE97R3Dpj6dPLweVKU(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def EEa6Qdysp8SAt4rw(showDialogs):
	if showDialogs:
		xtSlB2jwa3ULO6CuAk = L8cUEy6C0eV+slFfrUIWCowaBA7tce3iZbj8xn+p1lGnjONoyMF3EaHD+slFfrUIWCowaBA7tce3iZbj8xn+kGphIxD89a2eY+slFfrUIWCowaBA7tce3iZbj8xn+sXro6TtgZpInHfC+slFfrUIWCowaBA7tce3iZbj8xn+DDEz0KV2oIOYNhB3nwlSkHCvg1+slFfrUIWCowaBA7tce3iZbj8xn+X4MfVKSCbdEYk0jB8qTvDQ35G
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,VXWOCAE6ns3paJ8DLG479NQfMu+RDwahqjPfbdyEiTtnLQu(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+xtSlB2jwa3ULO6CuAk+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return
	MweNfdicjkgpGzoJVLTOD = W0BFzMOVpdNxnmer5aZfs(L8cUEy6C0eV,lvzrYTpcBaK,lvzrYTpcBaK)
	H5iLZGEv3PaFMtSYjNe = W0BFzMOVpdNxnmer5aZfs(p1lGnjONoyMF3EaHD,lvzrYTpcBaK,lvzrYTpcBaK)
	ZzNgeikb4CQd = W0BFzMOVpdNxnmer5aZfs(kGphIxD89a2eY,lvzrYTpcBaK,lvzrYTpcBaK)
	i3buwHQmaZAPyhSDpGXMg8jBEO = W0BFzMOVpdNxnmer5aZfs(sXro6TtgZpInHfC,lvzrYTpcBaK,lvzrYTpcBaK)
	BBywvhHKCQDdZ7f = W0BFzMOVpdNxnmer5aZfs(DDEz0KV2oIOYNhB3nwlSkHCvg1,lvzrYTpcBaK,lvzrYTpcBaK)
	UUSE9fVRljXuiWw1pvY2O = W0BFzMOVpdNxnmer5aZfs(X4MfVKSCbdEYk0jB8qTvDQ35G,lvzrYTpcBaK,lvzrYTpcBaK)
	succeeded = all([MweNfdicjkgpGzoJVLTOD,H5iLZGEv3PaFMtSYjNe,ZzNgeikb4CQd,i3buwHQmaZAPyhSDpGXMg8jBEO,BBywvhHKCQDdZ7f,UUSE9fVRljXuiWw1pvY2O])
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,bGzRdmOErkIylxALniq6(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,RDwahqjPfbdyEiTtnLQu(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def iA37QsOpfBYLEPhnm9DVa(showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,VXWOCAE6ns3paJ8DLG479NQfMu+wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=aYH620Dh48GEsTFfOBSQ7r(u"࠳ई"): return YQNd4wejLSAVJ6T(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = YQNd4wejLSAVJ6T(u"ࡘࡷࡻࡥऊ")
		lxGwZhDLdoySA1avUN5 = jcNEqrxW4uBOgHKhvU3dnMfXTFm.connect(n0neOuhY3xdkSvFQXwoHf4i2l19q)
		lxGwZhDLdoySA1avUN5.text_factory = str
		Fy1DHCosVPbSNMnWl0RQaiLtxB = lxGwZhDLdoySA1avUN5.cursor()
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(gDETKVh8mZe09Nd(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		lxGwZhDLdoySA1avUN5.commit()
		Fy1DHCosVPbSNMnWl0RQaiLtxB.execute(hPFcB6Uxmabj59Iq(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		lxGwZhDLdoySA1avUN5.close()
	except: succeeded = jwzOabysh0Z(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,IO7k2hZXSz(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def eeAS3qY7BV9ZXmFxJEDNbt(showDialogs):
	if showDialogs:
		bR4jqNrpMesHt93OgGKi6WDVaQA = NVjFvLmZCYRu1S893eTf6dUbqJl(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,aYH620Dh48GEsTFfOBSQ7r(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+slFfrUIWCowaBA7tce3iZbj8xn+slFfrUIWCowaBA7tce3iZbj8xn+VXWOCAE6ns3paJ8DLG479NQfMu+RDwahqjPfbdyEiTtnLQu(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+B8alA5nvIhTxQ)
		if bR4jqNrpMesHt93OgGKi6WDVaQA!=zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: return hPFcB6Uxmabj59Iq(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࡔࡳࡷࡨऍ")
	for file in YYEXZsUWhf52vz7HLxc0qGJ.listdir(ns962b50AYBo8k):
		if bGzRdmOErkIylxALniq6(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		YCSV1Wce7fqnBbEFT90p4zX5v = YYEXZsUWhf52vz7HLxc0qGJ.path.join(ns962b50AYBo8k,file)
		try: YYEXZsUWhf52vz7HLxc0qGJ.remove(YCSV1Wce7fqnBbEFT90p4zX5v)
		except Exception as QQa32JB7je0XdftAuz6yvxZsrViPo:
			succeeded = qqw1upCsKM(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,str(QQa32JB7je0XdftAuz6yvxZsrViPo))
	if showDialogs:
		if succeeded: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,jwzOabysh0Z(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded
# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
qsActmwjBGK4Ia1OFihlnCz = 'FAVORITES'
def wLkpI14XdRKiGohZ(QQ8kHjYnKEDU3sxft9S5iRoB,V8pKYuIwiUWbFfyzrZ1RB7HPM):
	if   QQ8kHjYnKEDU3sxft9S5iRoB==270: PaQp3oz49JfRdYbywq = AtylB0o7GnY9ui1UQSqNdPL4r(V8pKYuIwiUWbFfyzrZ1RB7HPM)
	else: PaQp3oz49JfRdYbywq = False
	return PaQp3oz49JfRdYbywq
def xlatCDi92hr0nNjVqgcSvp84(hzwScpHQRnB5Z,V8pKYuIwiUWbFfyzrZ1RB7HPM,CGD9mXwSVq8f3KRP2):
	if not hzwScpHQRnB5Z: return
	if   CGD9mXwSVq8f3KRP2=='UP1'	: SdO45omwKlu6tg(V8pKYuIwiUWbFfyzrZ1RB7HPM,True,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
	elif CGD9mXwSVq8f3KRP2=='DOWN1'	: SdO45omwKlu6tg(V8pKYuIwiUWbFfyzrZ1RB7HPM,False,zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU)
	elif CGD9mXwSVq8f3KRP2=='UP4'	: SdO45omwKlu6tg(V8pKYuIwiUWbFfyzrZ1RB7HPM,True,kK7gj9HE462hADJbvr)
	elif CGD9mXwSVq8f3KRP2=='DOWN4'	: SdO45omwKlu6tg(V8pKYuIwiUWbFfyzrZ1RB7HPM,False,kK7gj9HE462hADJbvr)
	elif CGD9mXwSVq8f3KRP2=='ADD1'	: pboS4Ns8e51MajD2WE(V8pKYuIwiUWbFfyzrZ1RB7HPM)
	elif CGD9mXwSVq8f3KRP2=='REMOVE1': OOguW5q0G8DmIv2ot9hz1Nl6yTHUes(V8pKYuIwiUWbFfyzrZ1RB7HPM)
	elif CGD9mXwSVq8f3KRP2=='DELETELIST': ddAtNh1K4IufC2cSP5(V8pKYuIwiUWbFfyzrZ1RB7HPM)
	return
def AtylB0o7GnY9ui1UQSqNdPL4r(V8pKYuIwiUWbFfyzrZ1RB7HPM):
	FFPIBnwqev3k5xCo9 = MMsJqwRifEADm1P879()
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()):
		try:
			SjCvuT1UfEnDQwWN4HeK6px2OIYyqg = FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]
			if BewrUo9ANCa17G43Sn0LH5xh and V8pKYuIwiUWbFfyzrZ1RB7HPM in ['5','11','12','13']:
				for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD in SjCvuT1UfEnDQwWN4HeK6px2OIYyqg:
					if iHPTUWrX1nbg=='video':
						XAozRfZ68H9x2OsiP3LmIaql1('video',VXWOCAE6ns3paJ8DLG479NQfMu+'تشغيل من الأعلى إلى الأسفل'+B8alA5nvIhTxQ,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z)
						XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
						break
			for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD in SjCvuT1UfEnDQwWN4HeK6px2OIYyqg:
				XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD)
		except:
			FFPIBnwqev3k5xCo9 = IV2b9wBsc0SmCaUEkNDK(u3yGxS2mRw1fW54N7DchIvEoaq)
			SjCvuT1UfEnDQwWN4HeK6px2OIYyqg = FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]
			for iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD in SjCvuT1UfEnDQwWN4HeK6px2OIYyqg:
				XAozRfZ68H9x2OsiP3LmIaql1(iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD)
	return
def pboS4Ns8e51MajD2WE(V8pKYuIwiUWbFfyzrZ1RB7HPM):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in ['5','11','12','13'] and iHPTUWrX1nbg!='video':
		ZZDswXvceNFRhafpUtWELYCP('','',OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	B3MJcwXj9yYhz = iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,bK0LycGjJxiVCD
	FFPIBnwqev3k5xCo9 = MMsJqwRifEADm1P879()
	b53FxP0trWYAJk2MEjNsq4mp6u9XO = {}
	for gqraU0VKuxWzkyGwscojFH in list(FFPIBnwqev3k5xCo9.keys()):
		if gqraU0VKuxWzkyGwscojFH!=V8pKYuIwiUWbFfyzrZ1RB7HPM: b53FxP0trWYAJk2MEjNsq4mp6u9XO[gqraU0VKuxWzkyGwscojFH] = FFPIBnwqev3k5xCo9[gqraU0VKuxWzkyGwscojFH]
		else:
			if hoVitY5TylJ7GBEIZNOQg8pukq and hoVitY5TylJ7GBEIZNOQg8pukq!='..':
				aa8CJTwFo0SDiAmjbxZh1dEQ = FFPIBnwqev3k5xCo9[gqraU0VKuxWzkyGwscojFH]
				if B3MJcwXj9yYhz in aa8CJTwFo0SDiAmjbxZh1dEQ:
					o2fzWRFUm1Xsg4jDBbAxEerQG = aa8CJTwFo0SDiAmjbxZh1dEQ.index(B3MJcwXj9yYhz)
					del aa8CJTwFo0SDiAmjbxZh1dEQ[o2fzWRFUm1Xsg4jDBbAxEerQG]
				hPX1MvuaF9SbkI5jqr2 = aa8CJTwFo0SDiAmjbxZh1dEQ+[B3MJcwXj9yYhz]
				b53FxP0trWYAJk2MEjNsq4mp6u9XO[gqraU0VKuxWzkyGwscojFH] = hPX1MvuaF9SbkI5jqr2
			else: b53FxP0trWYAJk2MEjNsq4mp6u9XO[gqraU0VKuxWzkyGwscojFH] = FFPIBnwqev3k5xCo9[gqraU0VKuxWzkyGwscojFH]
	if V8pKYuIwiUWbFfyzrZ1RB7HPM not in list(b53FxP0trWYAJk2MEjNsq4mp6u9XO.keys()): b53FxP0trWYAJk2MEjNsq4mp6u9XO[V8pKYuIwiUWbFfyzrZ1RB7HPM] = [B3MJcwXj9yYhz]
	XT2M5f7eS6tOdKaRHg94UrP = str(b53FxP0trWYAJk2MEjNsq4mp6u9XO)
	if I5VKjrFL0Bk97: XT2M5f7eS6tOdKaRHg94UrP = XT2M5f7eS6tOdKaRHg94UrP.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
	open(u3yGxS2mRw1fW54N7DchIvEoaq,'wb').write(XT2M5f7eS6tOdKaRHg94UrP)
	return
def OOguW5q0G8DmIv2ot9hz1Nl6yTHUes(V8pKYuIwiUWbFfyzrZ1RB7HPM):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	B3MJcwXj9yYhz = iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,bK0LycGjJxiVCD
	FFPIBnwqev3k5xCo9 = MMsJqwRifEADm1P879()
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()) and B3MJcwXj9yYhz in FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]:
		FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM].remove(B3MJcwXj9yYhz)
		if len(FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM])==BewrUo9ANCa17G43Sn0LH5xh: del FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]
		XT2M5f7eS6tOdKaRHg94UrP = str(FFPIBnwqev3k5xCo9)
		if I5VKjrFL0Bk97: XT2M5f7eS6tOdKaRHg94UrP = XT2M5f7eS6tOdKaRHg94UrP.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open(u3yGxS2mRw1fW54N7DchIvEoaq,'wb').write(XT2M5f7eS6tOdKaRHg94UrP)
	return
def SdO45omwKlu6tg(V8pKYuIwiUWbFfyzrZ1RB7HPM,Tev8KDlOtY4,dVH6lwkGjrcEWsIq7B):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD = g5FNRVqWzdHSAZGuoMe1YxETD3h(ERbOfw2FjKUAZGo)
	B3MJcwXj9yYhz = iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,sCHVtMAvqirbQ4BUK3cgWo,bK0LycGjJxiVCD
	FFPIBnwqev3k5xCo9 = MMsJqwRifEADm1P879()
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()):
		aa8CJTwFo0SDiAmjbxZh1dEQ = FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]
		if B3MJcwXj9yYhz not in aa8CJTwFo0SDiAmjbxZh1dEQ: return
		nsH0Kw8EN6OMS9A7 = len(aa8CJTwFo0SDiAmjbxZh1dEQ)
		for qT1ZRz0VMiXQhxFUPdJC2u9asvrN in range(BewrUo9ANCa17G43Sn0LH5xh,dVH6lwkGjrcEWsIq7B):
			nuXNyeDWhJ5gTmwxEGB6 = aa8CJTwFo0SDiAmjbxZh1dEQ.index(B3MJcwXj9yYhz)
			if Tev8KDlOtY4: yUnc5G3KrxwN1I4z = nuXNyeDWhJ5gTmwxEGB6-zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			else: yUnc5G3KrxwN1I4z = nuXNyeDWhJ5gTmwxEGB6+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
			if yUnc5G3KrxwN1I4z>=nsH0Kw8EN6OMS9A7: yUnc5G3KrxwN1I4z = yUnc5G3KrxwN1I4z-nsH0Kw8EN6OMS9A7
			if yUnc5G3KrxwN1I4z<BewrUo9ANCa17G43Sn0LH5xh: yUnc5G3KrxwN1I4z = yUnc5G3KrxwN1I4z+nsH0Kw8EN6OMS9A7
			aa8CJTwFo0SDiAmjbxZh1dEQ.insert(yUnc5G3KrxwN1I4z, aa8CJTwFo0SDiAmjbxZh1dEQ.pop(nuXNyeDWhJ5gTmwxEGB6))
		FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM] = aa8CJTwFo0SDiAmjbxZh1dEQ
		XT2M5f7eS6tOdKaRHg94UrP = str(FFPIBnwqev3k5xCo9)
		if I5VKjrFL0Bk97: XT2M5f7eS6tOdKaRHg94UrP = XT2M5f7eS6tOdKaRHg94UrP.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open(u3yGxS2mRw1fW54N7DchIvEoaq,'wb').write(XT2M5f7eS6tOdKaRHg94UrP)
	return
def Clpx6evkToaIz8DYLhbKEy7(V8pKYuIwiUWbFfyzrZ1RB7HPM):
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in ['1','2','3','4']: zz2KSy0Rlkq7phJxfgQMVn,clHSEh5gizMD7YUpeJPn04 = 'مفضلة',V8pKYuIwiUWbFfyzrZ1RB7HPM
	elif V8pKYuIwiUWbFfyzrZ1RB7HPM in ['5']: zz2KSy0Rlkq7phJxfgQMVn,clHSEh5gizMD7YUpeJPn04 = 'تشغيل','1'
	elif V8pKYuIwiUWbFfyzrZ1RB7HPM in ['11']: zz2KSy0Rlkq7phJxfgQMVn,clHSEh5gizMD7YUpeJPn04 = 'تشغيل','2'
	else: zz2KSy0Rlkq7phJxfgQMVn,clHSEh5gizMD7YUpeJPn04 = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	rWYApU4BlsVPc9HD0eRxo2 = zz2KSy0Rlkq7phJxfgQMVn+AAh0X3OCacr4HpifRGLZKT+clHSEh5gizMD7YUpeJPn04
	return rWYApU4BlsVPc9HD0eRxo2
def ddAtNh1K4IufC2cSP5(V8pKYuIwiUWbFfyzrZ1RB7HPM):
	rWYApU4BlsVPc9HD0eRxo2 = Clpx6evkToaIz8DYLhbKEy7(V8pKYuIwiUWbFfyzrZ1RB7HPM)
	PemgFp6AyMXlb = NVjFvLmZCYRu1S893eTf6dUbqJl('center',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'هل تريد فعلا مسح جميع محتويات قائمة '+rWYApU4BlsVPc9HD0eRxo2+' ؟!')
	if PemgFp6AyMXlb!=1: return
	FFPIBnwqev3k5xCo9 = MMsJqwRifEADm1P879()
	if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()):
		del FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]
		XT2M5f7eS6tOdKaRHg94UrP = str(FFPIBnwqev3k5xCo9)
		if I5VKjrFL0Bk97: XT2M5f7eS6tOdKaRHg94UrP = XT2M5f7eS6tOdKaRHg94UrP.encode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		open(u3yGxS2mRw1fW54N7DchIvEoaq,'wb').write(XT2M5f7eS6tOdKaRHg94UrP)
		ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,OODdgcrlh8KQo0A7M2eEvViwPqpkR,'تم مسح جميع محتويات قائمة '+rWYApU4BlsVPc9HD0eRxo2)
	return
def MMsJqwRifEADm1P879():
	FFPIBnwqev3k5xCo9 = {}
	if YYEXZsUWhf52vz7HLxc0qGJ.path.exists(u3yGxS2mRw1fW54N7DchIvEoaq):
		nRCpfDMoE3GYSyb41 = open(u3yGxS2mRw1fW54N7DchIvEoaq,'rb').read()
		if I5VKjrFL0Bk97: nRCpfDMoE3GYSyb41 = nRCpfDMoE3GYSyb41.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
		FFPIBnwqev3k5xCo9 = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',nRCpfDMoE3GYSyb41)
	return FFPIBnwqev3k5xCo9
def aQjwYZ6HEpTSActsI5Wl(FFPIBnwqev3k5xCo9,B3MJcwXj9yYhz,fUIxaLjts7OeMkr4Jg61ZN8FbAy):
	iHPTUWrX1nbg,hoVitY5TylJ7GBEIZNOQg8pukq,qhWpTazQ9ws,QQ8kHjYnKEDU3sxft9S5iRoB,yNbi4akQM9EHO8wSlCGoJZx,Ml0wzrY8uFeLOaPQyxmbX9,T67f3LG49xpP8zcN,hzwScpHQRnB5Z,bK0LycGjJxiVCD = B3MJcwXj9yYhz
	if not QQ8kHjYnKEDU3sxft9S5iRoB: iHPTUWrX1nbg,QQ8kHjYnKEDU3sxft9S5iRoB = 'folder','260'
	KGuSDIB8zmt,V8pKYuIwiUWbFfyzrZ1RB7HPM = [],sCHVtMAvqirbQ4BUK3cgWo
	if 'context=' in ERbOfw2FjKUAZGo:
		VSzDZiYCvW9Fyf5dtjoGpM3w = fNntYJW45mEFSdRX8g.findall('context=(\d+)',ERbOfw2FjKUAZGo,fNntYJW45mEFSdRX8g.DOTALL)
		if VSzDZiYCvW9Fyf5dtjoGpM3w: V8pKYuIwiUWbFfyzrZ1RB7HPM = str(VSzDZiYCvW9Fyf5dtjoGpM3w[BewrUo9ANCa17G43Sn0LH5xh])
	if QQ8kHjYnKEDU3sxft9S5iRoB=='270':
		V8pKYuIwiUWbFfyzrZ1RB7HPM = hzwScpHQRnB5Z
		if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()):
			rWYApU4BlsVPc9HD0eRxo2 = Clpx6evkToaIz8DYLhbKEy7(V8pKYuIwiUWbFfyzrZ1RB7HPM)
			KGuSDIB8zmt.append(('مسح قائمة '+rWYApU4BlsVPc9HD0eRxo2,'RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_DELETELIST'+')'))
	else:
		if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()):
			count = len(FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM])
			if count>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: KGuSDIB8zmt.append(('تحريك 1 للأعلى','RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_UP1)'))
			if count>kK7gj9HE462hADJbvr: KGuSDIB8zmt.append(('تحريك 4 للأعلى','RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_UP4)'))
			if count>zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU: KGuSDIB8zmt.append(('تحريك 1 للأسفل','RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_DOWN1)'))
			if count>kK7gj9HE462hADJbvr: KGuSDIB8zmt.append(('تحريك 4 للأسفل','RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_DOWN4)'))
		for V8pKYuIwiUWbFfyzrZ1RB7HPM in ['1','2','3','4','5','11']:
			rWYApU4BlsVPc9HD0eRxo2 = Clpx6evkToaIz8DYLhbKEy7(V8pKYuIwiUWbFfyzrZ1RB7HPM)
			if V8pKYuIwiUWbFfyzrZ1RB7HPM in list(FFPIBnwqev3k5xCo9.keys()) and B3MJcwXj9yYhz in FFPIBnwqev3k5xCo9[V8pKYuIwiUWbFfyzrZ1RB7HPM]:
				KGuSDIB8zmt.append(('مسح من '+rWYApU4BlsVPc9HD0eRxo2,'RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_REMOVE1)'))
			else: KGuSDIB8zmt.append(('إضافة ل'+rWYApU4BlsVPc9HD0eRxo2,'RunPlugin('+fUIxaLjts7OeMkr4Jg61ZN8FbAy+'&context='+V8pKYuIwiUWbFfyzrZ1RB7HPM+'_ADD1)'))
	fJRvXdbFBWhxktE5mrwpyiMGAa0SYL = []
	for ltq3wUIb1YkvhD,wwx4RT6EaoskGPiLg in KGuSDIB8zmt:
		ltq3wUIb1YkvhD = F7Fe63KbGjaz2TcmCNHPdo5QiXO+ltq3wUIb1YkvhD+B8alA5nvIhTxQ
		fJRvXdbFBWhxktE5mrwpyiMGAa0SYL.append((ltq3wUIb1YkvhD,wwx4RT6EaoskGPiLg,))
	return fJRvXdbFBWhxktE5mrwpyiMGAa0SYL
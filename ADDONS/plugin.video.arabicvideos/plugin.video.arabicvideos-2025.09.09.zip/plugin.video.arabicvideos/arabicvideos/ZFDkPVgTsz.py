# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYBESTVIP'
Z0BYJQghVL1v87CAem = '_EGV_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==220: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==221: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV)
	elif mode==222: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==223: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==224: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url)
	elif mode==229: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,229,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="i i-home"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)"(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,222)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="ba(.*?)<script',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,221)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'html' not in B17r2fdFy9ns8tiOMLu: continue
			if not B17r2fdFy9ns8tiOMLu.endswith('/'): XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,221)
	return Sw0pOFoVhPeIxbl
def ffy5vVCNau6FWgbmp(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-SUBMENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="rs_scroll"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,224)
	return
def mke5qXIUM8Fd2Ljb4Rv3y(url):
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع',url,221)
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-FILTERS_MENU-1st')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="sub_nav(.*?)id="movies',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".+?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if B17r2fdFy9ns8tiOMLu=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,221)
	else: fs7D0d3QyAT(url)
	return
def fs7D0d3QyAT(url,mRwrKW6fNZV='1'):
	if mRwrKW6fNZV==sCHVtMAvqirbQ4BUK3cgWo: mRwrKW6fNZV = '1'
	if '/search' in url or '?' in url: vrEJRkchKxtDNiqO1b79mL5eT = url + '&'
	else: vrEJRkchKxtDNiqO1b79mL5eT = url + '?'
	vrEJRkchKxtDNiqO1b79mL5eT = vrEJRkchKxtDNiqO1b79mL5eT + 'page=' + mRwrKW6fNZV
	Sw0pOFoVhPeIxbl = OXZtmCgx20(NjPWfJS7CUoTsz4lKk0hg,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('class="pda"(.*?)div',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[-1]
	elif '/series/' in url:
		oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('class="owl-carousel owl-carousel(.*?)div',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	else:
		oPnz7Zt4xLHTwR=fNntYJW45mEFSdRX8g.findall('id="movies(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[-1]
	items = fNntYJW45mEFSdRX8g.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
		title = tt36wUe4HTPFmfs5hcbr(title)
		if '/movie/' in B17r2fdFy9ns8tiOMLu or '/episode' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu.rstrip('/'),223,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,221,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if len(items)>=16:
		dViU7LaKFE9vtQy3jm8S2zHCqBP = ['/movies','/tv','/search','/trending']
		mRwrKW6fNZV = int(mRwrKW6fNZV)
		if any(value in url for value in dViU7LaKFE9vtQy3jm8S2zHCqBP):
			for TYeRU0bcKNwuWzsfJCjPZi in range(0,1000,100):
				if int(mRwrKW6fNZV/100)*100==TYeRU0bcKNwuWzsfJCjPZi:
					for XMIo9vWSBymeLJnK6YsU in range(TYeRU0bcKNwuWzsfJCjPZi,TYeRU0bcKNwuWzsfJCjPZi+100,10):
						if int(mRwrKW6fNZV/10)*10==XMIo9vWSBymeLJnK6YsU:
							for xukLvBPUIn in range(XMIo9vWSBymeLJnK6YsU,XMIo9vWSBymeLJnK6YsU+10,1):
								if not mRwrKW6fNZV==xukLvBPUIn and xukLvBPUIn!=0:
									XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+str(xukLvBPUIn),url,221,sCHVtMAvqirbQ4BUK3cgWo,str(xukLvBPUIn))
						elif XMIo9vWSBymeLJnK6YsU!=0: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+str(XMIo9vWSBymeLJnK6YsU),url,221,sCHVtMAvqirbQ4BUK3cgWo,str(XMIo9vWSBymeLJnK6YsU))
						else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+str(1),url,221,sCHVtMAvqirbQ4BUK3cgWo,str(1))
				elif TYeRU0bcKNwuWzsfJCjPZi!=0: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+str(TYeRU0bcKNwuWzsfJCjPZi),url,221,sCHVtMAvqirbQ4BUK3cgWo,str(TYeRU0bcKNwuWzsfJCjPZi))
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+str(1),url,221)
	return
def YH54mqkD2eU06(url):
	V9TdsglcWYv0X,ss7YGDbuAIxgnqaQroTV = [],[]
	Sw0pOFoVhPeIxbl = OXZtmCgx20(OOht4Ly9dmZMIz,url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-PLAY-1st')
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('<td>التصنيف</td>.*?">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	Qph1lem4wZHEvyt8,C1E2lnuoH64Q = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	F04LOGyXfrI5Pn,nJQxaImKPOjY1h0szC2qNt = Sw0pOFoVhPeIxbl,Sw0pOFoVhPeIxbl
	D4vsNEUrah2AtSq = fNntYJW45mEFSdRX8g.findall('show_dl api" href="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if D4vsNEUrah2AtSq:
		for B17r2fdFy9ns8tiOMLu in D4vsNEUrah2AtSq:
			if '/watch/' in B17r2fdFy9ns8tiOMLu: Qph1lem4wZHEvyt8 = B17r2fdFy9ns8tiOMLu
			elif '/download/' in B17r2fdFy9ns8tiOMLu: C1E2lnuoH64Q = B17r2fdFy9ns8tiOMLu
		if Qph1lem4wZHEvyt8!=sCHVtMAvqirbQ4BUK3cgWo: F04LOGyXfrI5Pn = OXZtmCgx20(OOht4Ly9dmZMIz,Qph1lem4wZHEvyt8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-PLAY-2nd')
		if C1E2lnuoH64Q!=sCHVtMAvqirbQ4BUK3cgWo: nJQxaImKPOjY1h0szC2qNt = OXZtmCgx20(OOht4Ly9dmZMIz,C1E2lnuoH64Q,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-PLAY-3rd')
	RkFfGxzr3DC9LaIpc = fNntYJW45mEFSdRX8g.findall('id="video".*?data-src="(.*?)"',F04LOGyXfrI5Pn,fNntYJW45mEFSdRX8g.DOTALL)
	if RkFfGxzr3DC9LaIpc:
		vrEJRkchKxtDNiqO1b79mL5eT = RkFfGxzr3DC9LaIpc[0]
		if vrEJRkchKxtDNiqO1b79mL5eT!=sCHVtMAvqirbQ4BUK3cgWo and 'uploaded.egybest.download' in vrEJRkchKxtDNiqO1b79mL5eT and '/?id=_' not in vrEJRkchKxtDNiqO1b79mL5eT:
			ssUAzo3RibtgDv7O0x = OXZtmCgx20(OOht4Ly9dmZMIz,vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-PLAY-4th')
			iyCRUo4rJIpL269BNWQ = fNntYJW45mEFSdRX8g.findall('source src="(.*?)" title="(.*?)"',ssUAzo3RibtgDv7O0x,fNntYJW45mEFSdRX8g.DOTALL)
			if iyCRUo4rJIpL269BNWQ:
				for B17r2fdFy9ns8tiOMLu,XO7Zr2W6kwieA in iyCRUo4rJIpL269BNWQ:
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu+'?named=ed.egybest.do__watch__mp4__'+XO7Zr2W6kwieA)
			else:
				smh8Qbf9jH = vrEJRkchKxtDNiqO1b79mL5eT.split('/')[2]
				ss7YGDbuAIxgnqaQroTV.append(vrEJRkchKxtDNiqO1b79mL5eT+'?named='+smh8Qbf9jH+'__watch')
		elif vrEJRkchKxtDNiqO1b79mL5eT!=sCHVtMAvqirbQ4BUK3cgWo:
			smh8Qbf9jH = vrEJRkchKxtDNiqO1b79mL5eT.split('/')[2]
			ss7YGDbuAIxgnqaQroTV.append(vrEJRkchKxtDNiqO1b79mL5eT+'?named='+smh8Qbf9jH+'__watch')
	e0jYLSHxDkcJFoO4i = fNntYJW45mEFSdRX8g.findall('<table class="dls_table(.*?)</table>',nJQxaImKPOjY1h0szC2qNt,fNntYJW45mEFSdRX8g.DOTALL)
	if e0jYLSHxDkcJFoO4i:
		e0jYLSHxDkcJFoO4i = e0jYLSHxDkcJFoO4i[0]
		jpdlaUP6HOGs7nT0NMRyXDZbuVwf = fNntYJW45mEFSdRX8g.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',e0jYLSHxDkcJFoO4i,fNntYJW45mEFSdRX8g.DOTALL)
		if jpdlaUP6HOGs7nT0NMRyXDZbuVwf:
			for XO7Zr2W6kwieA,B17r2fdFy9ns8tiOMLu in jpdlaUP6HOGs7nT0NMRyXDZbuVwf:
				if 'myegyvip' not in B17r2fdFy9ns8tiOMLu: continue
				if B17r2fdFy9ns8tiOMLu.count('/')>=2:
					smh8Qbf9jH = B17r2fdFy9ns8tiOMLu.split('/')[2]
					ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__download__mp4__'+XO7Zr2W6kwieA)
	iIdvU69jyWzCs = []
	for B17r2fdFy9ns8tiOMLu in ss7YGDbuAIxgnqaQroTV:
		iIdvU69jyWzCs.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(iIdvU69jyWzCs,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'+')
	Sw0pOFoVhPeIxbl = OXZtmCgx20(EGwIN9K6n5rVsjpLC4qvSUTyo3Z2,gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBESTVIP-SEARCH-1st')
	iigMzLZxRm6npGVfCvb0 = fNntYJW45mEFSdRX8g.findall('name="_token" value="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if iigMzLZxRm6npGVfCvb0:
		url = gAVl1vUmus8+'/search?_token='+iigMzLZxRm6npGVfCvb0[0]+'&q='+ktT4O0VJm8UaDNlxKvinoBYFgdH
		fs7D0d3QyAT(url)
	return
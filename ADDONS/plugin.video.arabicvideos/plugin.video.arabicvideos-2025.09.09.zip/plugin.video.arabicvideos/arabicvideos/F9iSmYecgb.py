# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'CIMAABDO'
Z0BYJQghVL1v87CAem = '_ABD_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['الرئيسية','افلام للكبار فقط +18']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==550: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==551: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==552: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==553: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==559: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8+'/home',sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(gAVl1vUmus8,'url')
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,559,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'اخترنا لك',aeBQsh4fzLr8XM5xou1gcyE+'/home',551,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'featured')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-content(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('data-name="(.*?)".*?</i>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for pm4F0M2Dsuh6otP7Zi5NXT,title in items:
		B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/ajax/getItem?item='+pm4F0M2Dsuh6otP7Zi5NXT+'&Ajax=1'
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,551)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"nav-main"(.*?)</nav>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu=='#': continue
		if title in MqARWHDkmiT4nlz: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,551)
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	for B17r2fdFy9ns8tiOMLu,title in items:
		if B17r2fdFy9ns8tiOMLu=='#': continue
		if title in MqARWHDkmiT4nlz: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,551)
	return
def fs7D0d3QyAT(url,pm4F0M2Dsuh6otP7Zi5NXT=sCHVtMAvqirbQ4BUK3cgWo):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(url)
		HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-TITLES-1st')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		oPnz7Zt4xLHTwR = [Sw0pOFoVhPeIxbl]
	else:
		UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-TITLES-2nd')
		Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
		if pm4F0M2Dsuh6otP7Zi5NXT=='featured':
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"container"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		elif '"section-post mb-10"' in Sw0pOFoVhPeIxbl:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"section-post mb-10"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		else:
			oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('<article(.*?)"pagination"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if not oPnz7Zt4xLHTwR: return
	Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
	if not items:
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if not items: items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
	chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
		B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu).strip('/')
		bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in chRY3biUoxnVltIk):
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,552,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		elif bbFPOJrmkCaE6ul37XiKU and 'الحلقة' in title:
			title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
			if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,553,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
				AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
		elif '/movies/' in B17r2fdFy9ns8tiOMLu:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,551,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,553,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if pm4F0M2Dsuh6otP7Zi5NXT==sCHVtMAvqirbQ4BUK3cgWo:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)<footer',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if B17r2fdFy9ns8tiOMLu=="": continue
				if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'هناك المزيد',url,551)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	GzRKsiw5PBIe1NlrqmQy9STx = fNntYJW45mEFSdRX8g.findall('"getSeasonsBySeries(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	iUtXlDhSVoBZJrPTQAwcER9nfMkN = fNntYJW45mEFSdRX8g.findall('"list-episodes"(.*?)"container"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if GzRKsiw5PBIe1NlrqmQy9STx and '/series/' not in url:
		Po9h3gWFuLR2 = GzRKsiw5PBIe1NlrqmQy9STx[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title,Mx0TQvmZAsedaGj4opVDJu5by8RUwS in items:
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,553,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	elif iUtXlDhSVoBZJrPTQAwcER9nfMkN:
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = fNntYJW45mEFSdRX8g.findall('"image" src="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS[0]
		Po9h3gWFuLR2 = iUtXlDhSVoBZJrPTQAwcER9nfMkN[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,552,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	return
def YH54mqkD2eU06(url):
	rdQ5tOIzuelfvcYbNsM = url.replace('/movies/','/watch_movies/')
	rdQ5tOIzuelfvcYbNsM = rdQ5tOIzuelfvcYbNsM.replace('/episodes/','/watch_episodes/')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',rdQ5tOIzuelfvcYbNsM,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	aeBQsh4fzLr8XM5xou1gcyE = GABnmSFOwtsu37(rdQ5tOIzuelfvcYbNsM,'url')
	cb1fAztguv78n9LGhSWJFm5p = []
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('''<iframe.*?src=["'](.*?)["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		smh8Qbf9jH = GABnmSFOwtsu37(B17r2fdFy9ns8tiOMLu,'url')
		cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__embed')
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"servers"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		uu4UgsMj01aImASoXpYDO9iQcfG = fNntYJW45mEFSdRX8g.findall('postID = "(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		uu4UgsMj01aImASoXpYDO9iQcfG = uu4UgsMj01aImASoXpYDO9iQcfG[0]
		items = fNntYJW45mEFSdRX8g.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for smh8Qbf9jH,title in items:
				title = title.replace(slFfrUIWCowaBA7tce3iZbj8xn,sCHVtMAvqirbQ4BUK3cgWo).strip(AAh0X3OCacr4HpifRGLZKT)
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/ajax/getPlayer?server='+smh8Qbf9jH+'&postID='+uu4UgsMj01aImASoXpYDO9iQcfG+'&Ajax=1'
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+title+'__watch'
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
		else:
			items = fNntYJW45mEFSdRX8g.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				smh8Qbf9jH,gEXf70ZHId,title = items[0]
				B17r2fdFy9ns8tiOMLu = aeBQsh4fzLr8XM5xou1gcyE+'/ajax/getPlayerByName?server='+smh8Qbf9jH+'&multipleServers='+gEXf70ZHId+'&postID='+uu4UgsMj01aImASoXpYDO9iQcfG+'&Ajax=1'
				vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE = muXAzTa365Mjklef1ZP7JiWrIR(B17r2fdFy9ns8tiOMLu)
				HSNYwERMjzyxmrPku = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'POST',vrEJRkchKxtDNiqO1b79mL5eT,i68iPmaHVAZknGv2SNpyzCwcFE,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-PLAY-2nd')
				Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
				PDwk9XvU7CeV = fNntYJW45mEFSdRX8g.findall('''<iframe src=["'](.*?)["']''',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL|fNntYJW45mEFSdRX8g.IGNORECASE)
				NroHCBWaxUZOfbgqMzAL4vJ2 = PDwk9XvU7CeV[0] if PDwk9XvU7CeV else sCHVtMAvqirbQ4BUK3cgWo
				if '/iframe/' in NroHCBWaxUZOfbgqMzAL4vJ2:
					UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',NroHCBWaxUZOfbgqMzAL4vJ2,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-PLAY-3rd')
					Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
					KKaOGUP8NXcmDpTxL6SviZBd = fNntYJW45mEFSdRX8g.findall('version&quot;:&quot;(.*?)&',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
					KKaOGUP8NXcmDpTxL6SviZBd = KKaOGUP8NXcmDpTxL6SviZBd[0]
					HSNYwERMjzyxmrPku = {}
					HSNYwERMjzyxmrPku['X-Inertia-Partial-Component'] = 'files/mirror/video'
					HSNYwERMjzyxmrPku['X-Inertia'] = 'true'
					HSNYwERMjzyxmrPku['X-Inertia-Partial-Data'] = 'streams'
					HSNYwERMjzyxmrPku['X-Inertia-Version'] = KKaOGUP8NXcmDpTxL6SviZBd
					UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',NroHCBWaxUZOfbgqMzAL4vJ2,sCHVtMAvqirbQ4BUK3cgWo,HSNYwERMjzyxmrPku,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'CIMAABDO-PLAY-4th')
					Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
					W9275Ooji4kzeIUCL = FHyPhGQ6O13K7jUeTq4WapdAVYfvX('dict',Sw0pOFoVhPeIxbl)
					groups = W9275Ooji4kzeIUCL['props']['streams']['data']
					for group in groups:
						XO7Zr2W6kwieA = group['label'].replace(' (source)',sCHVtMAvqirbQ4BUK3cgWo)
						OHgRaW9c1DAGL0 = group['mirrors']
						for PxqACUN20ohb in OHgRaW9c1DAGL0:
							smh8Qbf9jH = PxqACUN20ohb['driver']
							B17r2fdFy9ns8tiOMLu = 'http:'+PxqACUN20ohb['link']+'?named='+smh8Qbf9jH+'__watch____'+XO7Zr2W6kwieA
							cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"downs"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,name in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__download'
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if search==sCHVtMAvqirbQ4BUK3cgWo: search = UyBdvjGrFxDWMpmLOXn()
	if search==sCHVtMAvqirbQ4BUK3cgWo: return
	search = search.replace(AAh0X3OCacr4HpifRGLZKT,'-')
	url = gAVl1vUmus8+'/search/'+search+'.html'
	fs7D0d3QyAT(url)
	return
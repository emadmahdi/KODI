# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'TVFUN'
Z0BYJQghVL1v87CAem = '_TVF_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['بث مباشر']
def dBHD1Vl7hQuNOY(mode,url,text):
	if   mode==460: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==461: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,text)
	elif mode==462: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==463: ka7jz96YCdTBnQOLVPuJG3285MHf = VzOBjnIkZSH7ft(url)
	elif mode==469: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'TVFUN-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,469,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"menu-btn"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in MqARWHDkmiT4nlz: continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,461)
	return
def fs7D0d3QyAT(url,pm4F0M2Dsuh6otP7Zi5NXT=sCHVtMAvqirbQ4BUK3cgWo):
	items = []
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'TVFUN-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="head-title"(.*?)id="footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ = []
		chRY3biUoxnVltIk = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
			title = '_MOD_'+title.replace('<br>',AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).strip(AAh0X3OCacr4HpifRGLZKT)
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
			bbFPOJrmkCaE6ul37XiKU = fNntYJW45mEFSdRX8g.findall('(.*?) الحلقة \d+',title,fNntYJW45mEFSdRX8g.DOTALL)
			if any(value in title for value in chRY3biUoxnVltIk):
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,462,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			elif bbFPOJrmkCaE6ul37XiKU and 'الحلقة' in title:
				title = '_MOD_' + bbFPOJrmkCaE6ul37XiKU[0]
				if title not in AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,463,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
					AgfhUiL6MHqWmOjXysEt3KGrSDIFYZ.append(title)
			else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,463,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
	if pm4F0M2Dsuh6otP7Zi5NXT!='latest':
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('<a href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.strip(AAh0X3OCacr4HpifRGLZKT)
				if B17r2fdFy9ns8tiOMLu=="": continue
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
				if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,461)
	return
def VzOBjnIkZSH7ft(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'TVFUN-EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('class="head-title"(.*?)id="footer"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		if items:
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				title = '_MOD_'+title.replace('<br>',AAh0X3OCacr4HpifRGLZKT).replace(LvzD9S8RPyGeukZQqb2T0B,AAh0X3OCacr4HpifRGLZKT).strip(AAh0X3OCacr4HpifRGLZKT)
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,462,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
		else:
			items = fNntYJW45mEFSdRX8g.findall('class="episode.*?href="(.*?)" title="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
				XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,462)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('"pagination"(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?>(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu.strip(AAh0X3OCacr4HpifRGLZKT)
			if B17r2fdFy9ns8tiOMLu=="": continue
			if 'http' not in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if title!=sCHVtMAvqirbQ4BUK3cgWo: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'صفحة '+title,B17r2fdFy9ns8tiOMLu,463)
	return
def YH54mqkD2eU06(url):
	ss7YGDbuAIxgnqaQroTV = []
	vrEJRkchKxtDNiqO1b79mL5eT = url.replace('/video/','/watch/')
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',vrEJRkchKxtDNiqO1b79mL5eT,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'TVFUN-PLAY-2nd')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('VideoServers"(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for j8JSKTwtLXWaAi1muP,name in PXFtqmw5lBGQNa0IV8:
			j8JSKTwtLXWaAi1muP = j8JSKTwtLXWaAi1muP[2:]
			if qdUK5ioJyrO1T: j8JSKTwtLXWaAi1muP = j8JSKTwtLXWaAi1muP.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			j8JSKTwtLXWaAi1muP = JzkVPibWdBTRMGo15CjtnlUy9Hu8fX.b64decode(j8JSKTwtLXWaAi1muP)
			if I5VKjrFL0Bk97: j8JSKTwtLXWaAi1muP = j8JSKTwtLXWaAi1muP.decode(sFCqDzfS562gpyMjnLicrPWhB8oXT)
			B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('src="(.*?)"',j8JSKTwtLXWaAi1muP,fNntYJW45mEFSdRX8g.DOTALL)
			B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
			if 'http' not in B17r2fdFy9ns8tiOMLu:
				if '//' in B17r2fdFy9ns8tiOMLu: B17r2fdFy9ns8tiOMLu = 'http:'+B17r2fdFy9ns8tiOMLu
				else: B17r2fdFy9ns8tiOMLu = gAVl1vUmus8+B17r2fdFy9ns8tiOMLu
			if B17r2fdFy9ns8tiOMLu not in ss7YGDbuAIxgnqaQroTV:
				B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu+'?named='+name+'__watch'
				ss7YGDbuAIxgnqaQroTV.append(B17r2fdFy9ns8tiOMLu)
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(ss7YGDbuAIxgnqaQroTV,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search:
		search = UyBdvjGrFxDWMpmLOXn()
		if not search: return
	if AAh0X3OCacr4HpifRGLZKT in search:
		if showDialogs: ZZDswXvceNFRhafpUtWELYCP(sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = gAVl1vUmus8+'/q/'+search+'/'
	fs7D0d3QyAT(url)
	return
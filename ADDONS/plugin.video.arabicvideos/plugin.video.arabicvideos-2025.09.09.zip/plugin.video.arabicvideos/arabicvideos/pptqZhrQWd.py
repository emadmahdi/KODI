# -*- coding: utf-8 -*-
from CCKRSEkHBw import *
Ll1m0nJoaAPvHsXqyRE = 'EGYBEST1'
Z0BYJQghVL1v87CAem = '_EB1_'
gAVl1vUmus8 = Q1siCkTZyw.SITESURLS[Ll1m0nJoaAPvHsXqyRE][0]
MqARWHDkmiT4nlz = ['مكتبتي','ايجي بست']
def dBHD1Vl7hQuNOY(mode,url,mRwrKW6fNZV,text):
	if   mode==770: ka7jz96YCdTBnQOLVPuJG3285MHf = PMKv9oB6gJZak()
	elif mode==771: ka7jz96YCdTBnQOLVPuJG3285MHf = fs7D0d3QyAT(url,mRwrKW6fNZV)
	elif mode==772: ka7jz96YCdTBnQOLVPuJG3285MHf = ffy5vVCNau6FWgbmp(url)
	elif mode==773: ka7jz96YCdTBnQOLVPuJG3285MHf = YH54mqkD2eU06(url)
	elif mode==774: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'FULL_FILTER___'+text)
	elif mode==775: ka7jz96YCdTBnQOLVPuJG3285MHf = mke5qXIUM8Fd2Ljb4Rv3y(url,'DEFINED_FILTER___'+text)
	elif mode==776: ka7jz96YCdTBnQOLVPuJG3285MHf = kAUpK78mJRgoWZQytrNXeh5xf3v(url,mRwrKW6fNZV)
	elif mode==779: ka7jz96YCdTBnQOLVPuJG3285MHf = RsxrGI1pcyY3UXTSLiC(text,url)
	else: ka7jz96YCdTBnQOLVPuJG3285MHf = False
	return ka7jz96YCdTBnQOLVPuJG3285MHf
def PMKv9oB6gJZak():
	XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث في الموقع',sCHVtMAvqirbQ4BUK3cgWo,779,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'_REMEMBERRESULTS_')
	XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',gAVl1vUmus8,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST1-MENU-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('nav-list(.*?)</ul>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?<span>(.*?)</span>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			if any(value in title for value in MqARWHDkmiT4nlz): continue
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,771)
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-article(.*?)social-box',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('main-title.*?">(.*?)<.*?href="(.*?)"',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for title,B17r2fdFy9ns8tiOMLu in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,771,sCHVtMAvqirbQ4BUK3cgWo,'mainmenu')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-menu(.*?)</div></div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,title in items:
			title = title.strip(AAh0X3OCacr4HpifRGLZKT)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Ll1m0nJoaAPvHsXqyRE+'_SCRIPT_'+Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,771)
	return Sw0pOFoVhPeIxbl
def kAUpK78mJRgoWZQytrNXeh5xf3v(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST1-SEASONS_EPISODES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-article".*?">(.*?)<(.*?)article',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		bFNze460jv,pWu3ti618zVAbjdf7,items = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,[]
		for name,Po9h3gWFuLR2 in oPnz7Zt4xLHTwR:
			if 'حلقات' in name: pWu3ti618zVAbjdf7 = Po9h3gWFuLR2
			if 'مواسم' in name: bFNze460jv = Po9h3gWFuLR2
		if bFNze460jv and not type:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',bFNze460jv,fNntYJW45mEFSdRX8g.DOTALL)
			if len(items)>1:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,776,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
		if pWu3ti618zVAbjdf7 and len(items)<2:
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
			if items:
				for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,773,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			else:
				items = fNntYJW45mEFSdRX8g.findall('href="(.*?)">(.*?)<',pWu3ti618zVAbjdf7,fNntYJW45mEFSdRX8g.DOTALL)
				for B17r2fdFy9ns8tiOMLu,title in items:
					XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,773)
	return
def fs7D0d3QyAT(url,type=sCHVtMAvqirbQ4BUK3cgWo):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(NjPWfJS7CUoTsz4lKk0hg,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST1-TITLES-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	items,hwGsDZtO93Qm1IkdYinj,W6WgK7nGvCuozqhaSkFMXiye = [],False,False
	if not type:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('main-content(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?</i>(.*?)</a>',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,title in items:
				title = title.strip(AAh0X3OCacr4HpifRGLZKT)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,771,sCHVtMAvqirbQ4BUK3cgWo,'submenu')
				hwGsDZtO93Qm1IkdYinj = True
	if not type and 'p=' not in url:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('searchform(.*?)</form>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			if hwGsDZtO93Qm1IkdYinj: XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر محدد',url,775,sCHVtMAvqirbQ4BUK3cgWo,'filter')
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'فلتر كامل',url,774,sCHVtMAvqirbQ4BUK3cgWo,'filter')
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'بحث',url,779)
			XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
			W6WgK7nGvCuozqhaSkFMXiye = True
	if not hwGsDZtO93Qm1IkdYinj:
		oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('blocks(.*?)article',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
		if oPnz7Zt4xLHTwR:
			Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
			items = fNntYJW45mEFSdRX8g.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
			for B17r2fdFy9ns8tiOMLu,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,title in items:
				Mx0TQvmZAsedaGj4opVDJu5by8RUwS = Mx0TQvmZAsedaGj4opVDJu5by8RUwS.strip(slFfrUIWCowaBA7tce3iZbj8xn)
				B17r2fdFy9ns8tiOMLu = mSeoVfgRpNF9PKrJ(B17r2fdFy9ns8tiOMLu)
				if '/serie/' in B17r2fdFy9ns8tiOMLu: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,776,Mx0TQvmZAsedaGj4opVDJu5by8RUwS,'season')
				else: XAozRfZ68H9x2OsiP3LmIaql1('video',Z0BYJQghVL1v87CAem+title,B17r2fdFy9ns8tiOMLu,773,Mx0TQvmZAsedaGj4opVDJu5by8RUwS)
			mRwrKW6fNZV = '1'
			if 'p=' in url: url,mRwrKW6fNZV = url.split('p=',1)
			lxGwZhDLdoySA1avUN5 = '&' if '?' in url else '?'
			url = url+lxGwZhDLdoySA1avUN5
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(mRwrKW6fNZV)+1)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الصفحة التالية',url,771)
			elif mRwrKW6fNZV!='1':
				url = url+'p='+str(int(mRwrKW6fNZV)-1)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الصفحة السابقة',url,771)
	return
def YH54mqkD2eU06(url):
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(UTCXGnK7Fs4Y5pNkt2ARDWuw,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST1-PLAY-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	twBMfGAxJOELq6oHj5S2d7 = fNntYJW45mEFSdRX8g.findall('<label>التصنيف</label>.*?">(.*?)<',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if twBMfGAxJOELq6oHj5S2d7 and NNwUI8zLc39CGi2Mle(Ll1m0nJoaAPvHsXqyRE,url,twBMfGAxJOELq6oHj5S2d7): return
	tryU7sQv0e91cVL3h2xKRpqHdm6,cb1fAztguv78n9LGhSWJFm5p,y2EPKIcgxi8do3NOu6zbZ = [],[],[]
	B17r2fdFy9ns8tiOMLu = fNntYJW45mEFSdRX8g.findall('download-section.*?action="(.*?)"',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if B17r2fdFy9ns8tiOMLu:
		B17r2fdFy9ns8tiOMLu = B17r2fdFy9ns8tiOMLu[0]
		if B17r2fdFy9ns8tiOMLu not in y2EPKIcgxi8do3NOu6zbZ:
			y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
			cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named=__embed______'+IgCGzHw45TJ7PeuO1EKl(url))
	Jae64ky3REO57A2MvVHB90 = fNntYJW45mEFSdRX8g.findall('WatchServers(.*?)</div>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	for Po9h3gWFuLR2 in Jae64ky3REO57A2MvVHB90:
		PXFtqmw5lBGQNa0IV8 = fNntYJW45mEFSdRX8g.findall("url='(.*?)'.*?>(.*?)<",Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		for B17r2fdFy9ns8tiOMLu,smh8Qbf9jH in PXFtqmw5lBGQNa0IV8:
			if B17r2fdFy9ns8tiOMLu not in y2EPKIcgxi8do3NOu6zbZ:
				y2EPKIcgxi8do3NOu6zbZ.append(B17r2fdFy9ns8tiOMLu)
				cb1fAztguv78n9LGhSWJFm5p.append(B17r2fdFy9ns8tiOMLu+'?named='+smh8Qbf9jH+'__both______'+IgCGzHw45TJ7PeuO1EKl(url))
	import c27OeP8ifd
	c27OeP8ifd.xV5YHaP4TF9L20zy68RdfQ1(cb1fAztguv78n9LGhSWJFm5p,Ll1m0nJoaAPvHsXqyRE,'video',url)
	return
def RsxrGI1pcyY3UXTSLiC(search,url=sCHVtMAvqirbQ4BUK3cgWo):
	search,Z2VkQhiPAOuboSRB,showDialogs = KwmOrR2yNXpGFiCv4fMthB5(search)
	if not search: search = UyBdvjGrFxDWMpmLOXn()
	if not search: return
	ktT4O0VJm8UaDNlxKvinoBYFgdH = search.replace(AAh0X3OCacr4HpifRGLZKT,'%20')
	if not url: url = gAVl1vUmus8+'/search?query='+ktT4O0VJm8UaDNlxKvinoBYFgdH
	else: url = url+'?title='+ktT4O0VJm8UaDNlxKvinoBYFgdH+'&genre=&year=&lang='
	fs7D0d3QyAT(url,'search')
	return
def J6qLc3tuKiNQS1gdma45IFTo(url):
	url = url.split('/smartemadfilter?')[0]
	UHqibFEGL8fjKhI = ttRBeVWLbpMzNQO75Zox4PXu8EGg(OOht4Ly9dmZMIz,'GET',url,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	Sw0pOFoVhPeIxbl = UHqibFEGL8fjKhI.content
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = []
	oPnz7Zt4xLHTwR = fNntYJW45mEFSdRX8g.findall('form-row(.*?)</form>',Sw0pOFoVhPeIxbl,fNntYJW45mEFSdRX8g.DOTALL)
	if oPnz7Zt4xLHTwR:
		Po9h3gWFuLR2 = oPnz7Zt4xLHTwR[0]
		ssNoPMBKbeHfzu09G7vpDgyEZiIm = fNntYJW45mEFSdRX8g.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
		FFvHkxXiG5WMAC,IAEfYnUaKMF7DhW,Jae64ky3REO57A2MvVHB90 = zip(*ssNoPMBKbeHfzu09G7vpDgyEZiIm)
		ssNoPMBKbeHfzu09G7vpDgyEZiIm = zip(IAEfYnUaKMF7DhW,FFvHkxXiG5WMAC,Jae64ky3REO57A2MvVHB90)
	return ssNoPMBKbeHfzu09G7vpDgyEZiIm
def qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2):
	items = fNntYJW45mEFSdRX8g.findall('value="(.*?)">(.*?)<',Po9h3gWFuLR2,fNntYJW45mEFSdRX8g.DOTALL)
	return items
def nAbzRa5pNYyi(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
M1ej6JW4PYpQZoGkl9vI5w = ['year','lang','genre']
Gkd2TqBMoRVwu7 = ['year','lang','genre']
def mke5qXIUM8Fd2Ljb4Rv3y(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==sCHVtMAvqirbQ4BUK3cgWo: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo
	else: Z0qKkbyjJFCIBWgApm4s2YrzedTiX,RLkAVfXyplPhsSgb9760oCZW = filter.split('___')
	if type=='DEFINED_FILTER':
		if Gkd2TqBMoRVwu7[0]+'=' not in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = Gkd2TqBMoRVwu7[0]
		for XMIo9vWSBymeLJnK6YsU in range(len(Gkd2TqBMoRVwu7[0:-1])):
			if Gkd2TqBMoRVwu7[XMIo9vWSBymeLJnK6YsU]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX: B4SziFvRIXpPeGmfZDw3aVWJMAKNc = Gkd2TqBMoRVwu7[XMIo9vWSBymeLJnK6YsU+1]
		QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+B4SziFvRIXpPeGmfZDw3aVWJMAKNc+'=0'
		IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP.strip('&')+'___'+nGjoKRMy1mDqUx0.strip('&')
		ukGBUJAz02tOe = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+ukGBUJAz02tOe
	elif type=='FULL_FILTER':
		IV4WZjAdBYtUPL = Tir6PYcGvKsX7o(Z0qKkbyjJFCIBWgApm4s2YrzedTiX,'modified_values')
		IV4WZjAdBYtUPL = mSeoVfgRpNF9PKrJ(IV4WZjAdBYtUPL)
		if RLkAVfXyplPhsSgb9760oCZW: RLkAVfXyplPhsSgb9760oCZW = Tir6PYcGvKsX7o(RLkAVfXyplPhsSgb9760oCZW,'all')
		if not RLkAVfXyplPhsSgb9760oCZW: vrEJRkchKxtDNiqO1b79mL5eT = url
		else: vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+RLkAVfXyplPhsSgb9760oCZW
		rdQ5tOIzuelfvcYbNsM = nAbzRa5pNYyi(vrEJRkchKxtDNiqO1b79mL5eT)
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'أظهار قائمة الفيديو التي تم اختيارها ',rdQ5tOIzuelfvcYbNsM,771,sCHVtMAvqirbQ4BUK3cgWo,'filter')
		XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+' [[   '+IV4WZjAdBYtUPL+'   ]]',rdQ5tOIzuelfvcYbNsM,771,sCHVtMAvqirbQ4BUK3cgWo,'filter')
		XAozRfZ68H9x2OsiP3LmIaql1('link',VXWOCAE6ns3paJ8DLG479NQfMu+' ===== ===== ===== '+B8alA5nvIhTxQ,sCHVtMAvqirbQ4BUK3cgWo,9999)
	ssNoPMBKbeHfzu09G7vpDgyEZiIm = J6qLc3tuKiNQS1gdma45IFTo(url)
	dict = {}
	for name,ppWPYnc0JHvsmuTBqCXDEkzyN8,Po9h3gWFuLR2 in ssNoPMBKbeHfzu09G7vpDgyEZiIm:
		name = name.replace('كل ',sCHVtMAvqirbQ4BUK3cgWo)
		items = qiOp4f7E6TcZAtRFQlnaU2wPhvrjLD(Po9h3gWFuLR2)
		if '=' not in vrEJRkchKxtDNiqO1b79mL5eT: vrEJRkchKxtDNiqO1b79mL5eT = url
		if type=='DEFINED_FILTER':
			if B4SziFvRIXpPeGmfZDw3aVWJMAKNc!=ppWPYnc0JHvsmuTBqCXDEkzyN8: continue
			elif len(items)<2:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==Gkd2TqBMoRVwu7[-1]:
					rdQ5tOIzuelfvcYbNsM = nAbzRa5pNYyi(vrEJRkchKxtDNiqO1b79mL5eT)
					fs7D0d3QyAT(rdQ5tOIzuelfvcYbNsM)
				else: mke5qXIUM8Fd2Ljb4Rv3y(vrEJRkchKxtDNiqO1b79mL5eT,'DEFINED_FILTER___'+IbT0kDnP1LRa3j5yOpdwEifCoK)
				return
			else:
				if ppWPYnc0JHvsmuTBqCXDEkzyN8==Gkd2TqBMoRVwu7[-1]:
					rdQ5tOIzuelfvcYbNsM = nAbzRa5pNYyi(vrEJRkchKxtDNiqO1b79mL5eT)
					XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',rdQ5tOIzuelfvcYbNsM,771,sCHVtMAvqirbQ4BUK3cgWo,'filter')
				else: XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع ',vrEJRkchKxtDNiqO1b79mL5eT,775,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		elif type=='FULL_FILTER':
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'=0'
			IbT0kDnP1LRa3j5yOpdwEifCoK = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+'الجميع :'+name,vrEJRkchKxtDNiqO1b79mL5eT,774,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,IbT0kDnP1LRa3j5yOpdwEifCoK)
		dict[ppWPYnc0JHvsmuTBqCXDEkzyN8] = {}
		for value,CCzds3YbQDjKUFxfA5RHMIyBaSt in items:
			if not value: continue
			if CCzds3YbQDjKUFxfA5RHMIyBaSt in MqARWHDkmiT4nlz: continue
			dict[ppWPYnc0JHvsmuTBqCXDEkzyN8][value] = CCzds3YbQDjKUFxfA5RHMIyBaSt
			QzTKtoO2aCSJEjHiAuWZRqP = Z0qKkbyjJFCIBWgApm4s2YrzedTiX+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+CCzds3YbQDjKUFxfA5RHMIyBaSt
			nGjoKRMy1mDqUx0 = RLkAVfXyplPhsSgb9760oCZW+'&'+ppWPYnc0JHvsmuTBqCXDEkzyN8+'='+value
			C9fPDyiTbN4 = QzTKtoO2aCSJEjHiAuWZRqP+'___'+nGjoKRMy1mDqUx0
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'#+dict[ppWPYnc0JHvsmuTBqCXDEkzyN8]['0']
			title = CCzds3YbQDjKUFxfA5RHMIyBaSt+' :'+name
			if type=='FULL_FILTER': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,774,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
			elif type=='DEFINED_FILTER' and Gkd2TqBMoRVwu7[-2]+'=' in Z0qKkbyjJFCIBWgApm4s2YrzedTiX:
				ukGBUJAz02tOe = Tir6PYcGvKsX7o(nGjoKRMy1mDqUx0,'modified_filters')
				vrEJRkchKxtDNiqO1b79mL5eT = url+'/smartemadfilter?'+ukGBUJAz02tOe
				rdQ5tOIzuelfvcYbNsM = nAbzRa5pNYyi(vrEJRkchKxtDNiqO1b79mL5eT)
				XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,rdQ5tOIzuelfvcYbNsM,771,sCHVtMAvqirbQ4BUK3cgWo,'filter')
			elif type=='DEFINED_FILTER': XAozRfZ68H9x2OsiP3LmIaql1('folder',Z0BYJQghVL1v87CAem+title,url,775,sCHVtMAvqirbQ4BUK3cgWo,sCHVtMAvqirbQ4BUK3cgWo,C9fPDyiTbN4)
	return
def Tir6PYcGvKsX7o(W6WgK7nGvCuozqhaSkFMXiye,mode):
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.replace('=&','=0&')
	W6WgK7nGvCuozqhaSkFMXiye = W6WgK7nGvCuozqhaSkFMXiye.strip('&')
	RI3oQTg7X4E1K6qYcFhvLsJpD = {}
	if '=' in W6WgK7nGvCuozqhaSkFMXiye:
		items = W6WgK7nGvCuozqhaSkFMXiye.split('&')
		for UqKgalXPCz7eQAL08foMx1R in items:
			b7bwuO6YAD,value = UqKgalXPCz7eQAL08foMx1R.split('=')
			RI3oQTg7X4E1K6qYcFhvLsJpD[b7bwuO6YAD] = value
	FQZjpoeBUGkTShcbE3d = sCHVtMAvqirbQ4BUK3cgWo
	for key in M1ej6JW4PYpQZoGkl9vI5w:
		if key in list(RI3oQTg7X4E1K6qYcFhvLsJpD.keys()): value = RI3oQTg7X4E1K6qYcFhvLsJpD[key]
		else: value = '0'
		if '%' not in value: value = IgCGzHw45TJ7PeuO1EKl(value)
		if mode=='modified_values' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+' + '+value
		elif mode=='modified_filters' and value!='0': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
		elif mode=='all': FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d+'&'+key+'='+value
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip(' + ')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.strip('&')
	FQZjpoeBUGkTShcbE3d = FQZjpoeBUGkTShcbE3d.replace('=0','=')
	return FQZjpoeBUGkTShcbE3d
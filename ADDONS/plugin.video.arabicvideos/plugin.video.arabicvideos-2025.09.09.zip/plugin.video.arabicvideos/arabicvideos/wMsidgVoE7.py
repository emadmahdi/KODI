# -*- coding: utf-8 -*-
import sys as xlOFiKpdTI1Vjw5YN
q5WgH7aDzCRSyXvxuQ98nLsTJ = xlOFiKpdTI1Vjw5YN.version_info [0] == 2
QK3RyWUFwzPjCXZ = 2048
okWmV3tyR24eENHdqLrpZu = 7
def ely7R248pix3gkI9nTdEVQ5v (Q9Y3wxshvq):
	global CChJnPfFMRgmYlqsLHVD0SxZ6bizt
	TzVXKQSqLny0ZhIF3WgcMGP85H1t = ord (Q9Y3wxshvq [-1])
	gMDVTSYJvpazxm5E4k8L67ZoRq3lW = Q9Y3wxshvq [:-1]
	ozBVWQkSpdFGP7JDf0N = TzVXKQSqLny0ZhIF3WgcMGP85H1t % len (gMDVTSYJvpazxm5E4k8L67ZoRq3lW)
	HfwNXDtlkB1PxYhjc3oOE = gMDVTSYJvpazxm5E4k8L67ZoRq3lW [:ozBVWQkSpdFGP7JDf0N] + gMDVTSYJvpazxm5E4k8L67ZoRq3lW [ozBVWQkSpdFGP7JDf0N:]
	if q5WgH7aDzCRSyXvxuQ98nLsTJ:
		SSCIVEzmQ5JdoK = unicode () .join ([unichr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	else:
		SSCIVEzmQ5JdoK = str () .join ([chr (ord (LTahHwp6kPNJRAq5sCSDnIfK) - QK3RyWUFwzPjCXZ - (R6Rt8MWw4ojFVp + TzVXKQSqLny0ZhIF3WgcMGP85H1t) % okWmV3tyR24eENHdqLrpZu) for R6Rt8MWw4ojFVp, LTahHwp6kPNJRAq5sCSDnIfK in enumerate (HfwNXDtlkB1PxYhjc3oOE)])
	return eval (SSCIVEzmQ5JdoK)
fvYGxnZNUiyP4HJkMIoS25,bGzRdmOErkIylxALniq6,YQNd4wejLSAVJ6T=ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v,ely7R248pix3gkI9nTdEVQ5v
iicy4NfseqSCjHuD7ZIFPO9aYpU,SE97R3Dpj6dPLweVKU,phlEoViHIrU5ajAkv1DNGXfyqMB9=YQNd4wejLSAVJ6T,bGzRdmOErkIylxALniq6,fvYGxnZNUiyP4HJkMIoS25
XdGj3PYNmuBC42ZeMvqlW8bAi6LJV,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,t19ZOVHA4CpwFKaeiubcMGvz=phlEoViHIrU5ajAkv1DNGXfyqMB9,SE97R3Dpj6dPLweVKU,iicy4NfseqSCjHuD7ZIFPO9aYpU
RDwahqjPfbdyEiTtnLQu,XxE4VAKW7LQzdk2Il3gUr1vwn,TzIj50KpohEOHx6CbZWqB=t19ZOVHA4CpwFKaeiubcMGvz,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV
aYH620Dh48GEsTFfOBSQ7r,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,qeG16a4pbSHziNVQ2uFXrs=TzIj50KpohEOHx6CbZWqB,XxE4VAKW7LQzdk2Il3gUr1vwn,RDwahqjPfbdyEiTtnLQu
aenpKvQCGVzhLXEdWiDIZ,qqw1upCsKM,Hg6i4BsbFlRwhU0MyY1L3t8JZA=qeG16a4pbSHziNVQ2uFXrs,Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J,aYH620Dh48GEsTFfOBSQ7r
Js61GTdX5wzMurUqi7Z,IOHSz7YPF9WusGgUt1Dq,EJgYdjbIiWe1apkQlZcR42=Hg6i4BsbFlRwhU0MyY1L3t8JZA,qqw1upCsKM,aenpKvQCGVzhLXEdWiDIZ
IO7k2hZXSz,gDETKVh8mZe09Nd,SIkwCEdJHTD9v1=EJgYdjbIiWe1apkQlZcR42,IOHSz7YPF9WusGgUt1Dq,Js61GTdX5wzMurUqi7Z
BWfpRku7SsM6cbE0eG,zLjWeKu6JgNO7vocUD0Qpy,E2QIcUfmlwa3xR17DFrkezBSsyh=SIkwCEdJHTD9v1,gDETKVh8mZe09Nd,IO7k2hZXSz
GVurlv8HeoXEzPRiQB7Ty,sH6BOz5wKRFcEg,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN=E2QIcUfmlwa3xR17DFrkezBSsyh,zLjWeKu6JgNO7vocUD0Qpy,BWfpRku7SsM6cbE0eG
oVwa0kcqxj1e7mLplAfZdGT,hPFcB6Uxmabj59Iq,jwzOabysh0Z=t6JFqo2UXLjC8QYRngZ1PrKpyS05VN,sH6BOz5wKRFcEg,GVurlv8HeoXEzPRiQB7Ty
BewrUo9ANCa17G43Sn0LH5xh = Js61GTdX5wzMurUqi7Z(u"࠵৤")
zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU = SIkwCEdJHTD9v1(u"࠷৥")
rgpY5VUqKbeFOCD9Nki2SmGvxEja = zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
vUnJhT2NO8yirHcAmg = rgpY5VUqKbeFOCD9Nki2SmGvxEja+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
kK7gj9HE462hADJbvr = vUnJhT2NO8yirHcAmg+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
tBMCpcY2vUV1dEjZ7PDG = kK7gj9HE462hADJbvr+zuNowXqPi3n8sIa5Qdj7l2KOE6pLTU
sCHVtMAvqirbQ4BUK3cgWo = gDETKVh8mZe09Nd(u"ࠩࠪए")
AAh0X3OCacr4HpifRGLZKT = EJgYdjbIiWe1apkQlZcR42(u"ࠪࠤࠬऐ")
LvzD9S8RPyGeukZQqb2T0B = AAh0X3OCacr4HpifRGLZKT*rgpY5VUqKbeFOCD9Nki2SmGvxEja
OUmtsIB1zyF = AAh0X3OCacr4HpifRGLZKT*vUnJhT2NO8yirHcAmg
bRa9TlJO4fPdsUAj = AAh0X3OCacr4HpifRGLZKT*kK7gj9HE462hADJbvr
ZetiSjBQ9bTnF23pzsmXcyWuK = None
ndkUxG9LtewJ = Js61GTdX5wzMurUqi7Z(u"࡙ࡸࡵࡦਇ")
lvzrYTpcBaK = zLjWeKu6JgNO7vocUD0Qpy(u"ࡌࡡ࡭ࡵࡨਈ")
lbyqTk2FBWLnKOtICNRM9jpfxvh0GP = gDETKVh8mZe09Nd(u"ࠫࡹࡸࡵࡦࠩऑ")
VMB1l2JKvI = SE97R3Dpj6dPLweVKU(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
EctkVfa3Tr6PdbX9UJ2 = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
K3nC0rDSptmG = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
VXWOCAE6ns3paJ8DLG479NQfMu = SIkwCEdJHTD9v1(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
F7Fe63KbGjaz2TcmCNHPdo5QiXO = SE97R3Dpj6dPLweVKU(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
ppPYj60nQOTlIut3X59FGZd = aenpKvQCGVzhLXEdWiDIZ(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
YA9GohfEca42kZOB6FN5t3y70JxMQg = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
VU8su1fdMzlHvyA0B = fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
B8alA5nvIhTxQ = aenpKvQCGVzhLXEdWiDIZ(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
sFCqDzfS562gpyMjnLicrPWhB8oXT = aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡶࡶࡩ࠼ࠬछ")
sfaeVtLiZh3xYJ9P = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩज")
c3dXNBfyhSZCow1ia0RjVWUOg9 = sH6BOz5wKRFcEg(u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨझ")
lIm9XbGnwLkdi5q = RDwahqjPfbdyEiTtnLQu(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪञ")
CRxa3v2o1wMXzZLu8FDinm6gsr = SIkwCEdJHTD9v1(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪट")
oom21Pvk6Q59d = Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠬࡋࡒࡓࡑࡕࠫठ")
wdyXQbPWRMOrg82 = oVwa0kcqxj1e7mLplAfZdGT(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫड")
slFfrUIWCowaBA7tce3iZbj8xn = fvYGxnZNUiyP4HJkMIoS25(u"ࠧ࡝ࡰࠪढ")
f6fsIXQonhvcGg1p = E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨ࡞ࡵࠫण")
OODdgcrlh8KQo0A7M2eEvViwPqpkR = gDETKVh8mZe09Nd(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬत")
jkYp9crn3R2IA6GL58vNMPX1JeQK = BWfpRku7SsM6cbE0eG(u"࠱০")
favJM9wCN6Q1BxjmVUP = aenpKvQCGVzhLXEdWiDIZ(u"࠱࠰࠸১")
AAwX4J3uM1fH59mIhkBqexLSKyzb = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠳࠸২")
AWvIZYNDLM2wP = XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠶࠴৩")
jjPTvSMUJYuhgaC4XHOEFb7xc6rI0 = BWfpRku7SsM6cbE0eG(u"࠵࠵৪")
QL2JgXnCN3Di = iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠶࠸࠰৫")
tX4b7VxPQv5hyf18iwlBGWNOrIU = [
						 iicy4NfseqSCjHuD7ZIFPO9aYpU(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗࡗ࠲࠷ࡳࡵࠩथ")
						,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨद")
						,EJgYdjbIiWe1apkQlZcR42(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭ध")
						,E2QIcUfmlwa3xR17DFrkezBSsyh(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧन")
						,sH6BOz5wKRFcEg(u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩऩ")
						,XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫप")
						,aenpKvQCGVzhLXEdWiDIZ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭फ")
						,IOHSz7YPF9WusGgUt1Dq(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧब")
						,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨभ")
						,hPFcB6Uxmabj59Iq(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩम")
						,t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭य")
						,BWfpRku7SsM6cbE0eG(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧर")
						,SE97R3Dpj6dPLweVKU(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧऱ")
						,E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫल")
						,IO7k2hZXSz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬळ")
						]
KAgokEa3RwmuHiWsJ0 = tX4b7VxPQv5hyf18iwlBGWNOrIU+[
				 EJgYdjbIiWe1apkQlZcR42(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ऴ")
				,SIkwCEdJHTD9v1(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪव")
				,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩश")
				,IOHSz7YPF9WusGgUt1Dq(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪष")
				,phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫस")
				,Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬह")
				,TzIj50KpohEOHx6CbZWqB(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬऺ")
				,aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭ऻ")
				,aYH620Dh48GEsTFfOBSQ7r(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪ़ࠧ")
				,wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪऽ")
				,Js61GTdX5wzMurUqi7Z(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪा")
				,sH6BOz5wKRFcEg(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫि")
				,BWfpRku7SsM6cbE0eG(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬी")
				,hPFcB6Uxmabj59Iq(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨु")
				,qqw1upCsKM(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬू")
				,fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧृ")
				]
K4b0LHxYq2 = [
						 Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨॄ")
						,XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩॅ")
						,zLjWeKu6JgNO7vocUD0Qpy(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॆ")
						]
cjJXgt71A5 = tBMCpcY2vUV1dEjZ7PDG
dTacwSXg2MOGtHY = [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ุࠩๅึ࠭े"),BWfpRku7SsM6cbE0eG(u"ࠪวํ๊ࠧै"),TzIj50KpohEOHx6CbZWqB(u"ࠫะอๆ๋ࠩॉ"),qqw1upCsKM(u"ࠬัวๅอࠪॊ"),jwzOabysh0Z(u"࠭ัศส฼ࠫो"),TzIj50KpohEOHx6CbZWqB(u"ࠧฯษ่ืࠬौ"),qqw1upCsKM(u"ࠨีสำ्ุ࠭"),Js61GTdX5wzMurUqi7Z(u"ࠩึหอ฿ࠧॎ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠪฯฬ๋ๆࠨॏ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠫฯอำฺࠩॐ"),RDwahqjPfbdyEiTtnLQu(u"ࠬ฿วีำࠪ॑")]
b8bawyn2WtGE6RAivPoOLMzN0 = fvYGxnZNUiyP4HJkMIoS25(u"࠼࠰৬")
YYAdZjDy5erLEOa3Vh02Ux = t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"࠶࠱৭")*b8bawyn2WtGE6RAivPoOLMzN0
qYPWJUCGENXH = EJgYdjbIiWe1apkQlZcR42(u"࠳࠶৮")*YYAdZjDy5erLEOa3Vh02Ux
KAMS1dYvc8bqlJoiGrsQn6fjR7Z = hPFcB6Uxmabj59Iq(u"࠵࠳৯")*qYPWJUCGENXH
UTCXGnK7Fs4Y5pNkt2ARDWuw = BewrUo9ANCa17G43Sn0LH5xh
xCE0toTumIHWiLyMfF = BWfpRku7SsM6cbE0eG(u"࠶࠴ৰ")*b8bawyn2WtGE6RAivPoOLMzN0
EGwIN9K6n5rVsjpLC4qvSUTyo3Z2 = rgpY5VUqKbeFOCD9Nki2SmGvxEja*YYAdZjDy5erLEOa3Vh02Ux
NjPWfJS7CUoTsz4lKk0hg = qeG16a4pbSHziNVQ2uFXrs(u"࠵࠻ৱ")*YYAdZjDy5erLEOa3Vh02Ux
OOht4Ly9dmZMIz = vUnJhT2NO8yirHcAmg*qYPWJUCGENXH
gQtzWRX97wZHiJ = jwzOabysh0Z(u"࠸࠶৲")*qYPWJUCGENXH
IfAkw39UvaYWEDXLthFrbSzG = GVurlv8HeoXEzPRiQB7Ty(u"࠷࠲৳")*KAMS1dYvc8bqlJoiGrsQn6fjR7Z
LLg3oeFAZujGWitdBw0DOsRmhlVk = YYAdZjDy5erLEOa3Vh02Ux
YJ278hjZdxsvmIzGkVnOwl = [YQNd4wejLSAVJ6T(u"࠭ࡂࡐࡍࡕࡅ॒ࠬ"),TzIj50KpohEOHx6CbZWqB(u"ࠧࡑࡃࡑࡉ࡙࠭॓"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭॔"),aYH620Dh48GEsTFfOBSQ7r(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬॕ"),Js61GTdX5wzMurUqi7Z(u"ࠪࡍࡋࡏࡌࡎࠩॖ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪॗ"),jwzOabysh0Z(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬक़")]
YJ278hjZdxsvmIzGkVnOwl += [Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬख़"),TzIj50KpohEOHx6CbZWqB(u"ࠧࡂࡍࡒࡅࡒ࠭ग़"),IOHSz7YPF9WusGgUt1Dq(u"ࠨࡃࡎ࡛ࡆࡓࠧज़"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫड़"),fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬढ़")]
Z59KfHyb6eJkaYV7 = [sH6BOz5wKRFcEg(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫफ़"),YQNd4wejLSAVJ6T(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨय़"),bGzRdmOErkIylxALniq6(u"࠭ࡔࡗࡈࡘࡒࠬॠ"),hPFcB6Uxmabj59Iq(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨॡ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩॢ"),EJgYdjbIiWe1apkQlZcR42(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ॣ"),qqw1upCsKM(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ।")]
Z59KfHyb6eJkaYV7 += [YQNd4wejLSAVJ6T(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭॥"),jwzOabysh0Z(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ०"),Js61GTdX5wzMurUqi7Z(u"࠭ࡓࡉࡑࡉࡌࡆ࠭१"),aYH620Dh48GEsTFfOBSQ7r(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨ२"),bGzRdmOErkIylxALniq6(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩ३")]
qu43FwoECrH5QZn = [hPFcB6Uxmabj59Iq(u"ࠩࡗࡍࡐࡇࡁࡕࠩ४"),SIkwCEdJHTD9v1(u"ࠪࡅ࡞ࡒࡏࡍࠩ५"),YQNd4wejLSAVJ6T(u"ࠫࡋࡕࡓࡕࡃࠪ६"),gDETKVh8mZe09Nd(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭७"),Js61GTdX5wzMurUqi7Z(u"࡙࠭ࡂࡓࡒࡘࠬ८"),YQNd4wejLSAVJ6T(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪ९"),GVurlv8HeoXEzPRiQB7Ty(u"ࠨࡘࡄࡖࡇࡕࡎࠨ॰"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩॱ")]
qu43FwoECrH5QZn += [fvYGxnZNUiyP4HJkMIoS25(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫॲ"),Js61GTdX5wzMurUqi7Z(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ॳ"),fvYGxnZNUiyP4HJkMIoS25(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ॴ"),zLjWeKu6JgNO7vocUD0Qpy(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨॵ"),gDETKVh8mZe09Nd(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨॶ"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪॷ"),RDwahqjPfbdyEiTtnLQu(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪॸ")]
qu43FwoECrH5QZn += [RDwahqjPfbdyEiTtnLQu(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬॹ"),TzIj50KpohEOHx6CbZWqB(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ॺ"),Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨॻ"),gDETKVh8mZe09Nd(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧॼ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪॽ"),Js61GTdX5wzMurUqi7Z(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩॾ"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫॿ")]
qu43FwoECrH5QZn += [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ঀ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧঁ"),YQNd4wejLSAVJ6T(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨং"),iicy4NfseqSCjHuD7ZIFPO9aYpU(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨঃ"),SE97R3Dpj6dPLweVKU(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ঄"),jwzOabysh0Z(u"ࠨࡃࡋ࡛ࡆࡑࠧঅ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫআ"),IO7k2hZXSz(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧই")]
qu43FwoECrH5QZn += [aYH620Dh48GEsTFfOBSQ7r(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ঈ"),qqw1upCsKM(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩউ"),SE97R3Dpj6dPLweVKU(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫঊ"),t19ZOVHA4CpwFKaeiubcMGvz(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧঋ"),sH6BOz5wKRFcEg(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪঌ"),TzIj50KpohEOHx6CbZWqB(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ঍"),SE97R3Dpj6dPLweVKU(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ঎"),YQNd4wejLSAVJ6T(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭এ")]
nCEFGzWMilkr51vs4jad8bm6O = [sH6BOz5wKRFcEg(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ঐ"),oVwa0kcqxj1e7mLplAfZdGT(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ঑"),sH6BOz5wKRFcEg(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ঒"),jwzOabysh0Z(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫও")]
nCEFGzWMilkr51vs4jad8bm6O += [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঔ"),EJgYdjbIiWe1apkQlZcR42(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨক"),IOHSz7YPF9WusGgUt1Dq(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬখ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬগ"),RDwahqjPfbdyEiTtnLQu(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡑࡏࡖࡆࡕࠪঘ"),GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡎࡁࡔࡊࡗࡅࡌ࡙ࠧঙ")]
ccehpQ8jEwfV1garCtYiOHS6PzqKyk = [IO7k2hZXSz(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩচ")]+YJ278hjZdxsvmIzGkVnOwl+[qqw1upCsKM(u"ࠩࡐࡍ࡝ࡋࡄࠨছ")]+Z59KfHyb6eJkaYV7+[Hg6i4BsbFlRwhU0MyY1L3t8JZA(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪজ")]+qu43FwoECrH5QZn+[Js61GTdX5wzMurUqi7Z(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ")]+nCEFGzWMilkr51vs4jad8bm6O
c2AfoVUiyCw7xE = [qqw1upCsKM(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫঞ")]
TJ9y6KsRV12Lo0ZwbOkHgulEmhrSj = [jwzOabysh0Z(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧট"),IO7k2hZXSz(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঠ"),sH6BOz5wKRFcEg(u"ࠨࡒࡘࡆࡑࡏࡃࠨড")]
vbEcAhaFDduIU1 = [RDwahqjPfbdyEiTtnLQu(u"ࠩࡐ࠷࡚࠭ঢ"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"ࠪࡍࡕ࡚ࡖࠨণ"),YQNd4wejLSAVJ6T(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩত"),YQNd4wejLSAVJ6T(u"ࠬࡏࡆࡊࡎࡐࠫথ"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧদ")]
ghpNR6ucvP  = [GVurlv8HeoXEzPRiQB7Ty(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬধ"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩন"),wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঩"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧপ"),RDwahqjPfbdyEiTtnLQu(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫফ")]
ghpNR6ucvP += [t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫব"),Q24QVGfx8kTBsdRS1Ky5zCLHYeZ0J(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ভ")]
ghpNR6ucvP += [XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨম"),TzIj50KpohEOHx6CbZWqB(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬয"),SE97R3Dpj6dPLweVKU(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬর")]
ghpNR6ucvP += [IOHSz7YPF9WusGgUt1Dq(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭঱"),gDETKVh8mZe09Nd(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩল"),qeG16a4pbSHziNVQ2uFXrs(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ঳")]
ghpNR6ucvP += [TzIj50KpohEOHx6CbZWqB(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ঴"),bGzRdmOErkIylxALniq6(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ঵"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬশ")]
HIFfB2t0g5OU4kzdY = list(filter(lambda pkO5dBQveUZuJFt0: pkO5dBQveUZuJFt0 not in ghpNR6ucvP+c2AfoVUiyCw7xE+TJ9y6KsRV12Lo0ZwbOkHgulEmhrSj+vbEcAhaFDduIU1,ccehpQ8jEwfV1garCtYiOHS6PzqKyk))
imU5I1ewc4dEHvkQ8 = HIFfB2t0g5OU4kzdY+vbEcAhaFDduIU1
lAF6gQMxJOK = HIFfB2t0g5OU4kzdY+ghpNR6ucvP
yy2piuoUNchWGelADxq7Q1 = lAF6gQMxJOK+c2AfoVUiyCw7xE
P0SFzyBJp94qMnNH3hQ1aDfZT82x = imU5I1ewc4dEHvkQ8+c2AfoVUiyCw7xE
ygksQzPTubHYiDG0SOmrXqlKVJMfv = [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡄࡏࡔࡇࡍࠨষ"),YQNd4wejLSAVJ6T(u"ࠪࡅࡐ࡝ࡁࡎࠩস"),bGzRdmOErkIylxALniq6(u"ࠫࡎࡌࡉࡍࡏࠪহ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ঺"),GVurlv8HeoXEzPRiQB7Ty(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ঻"),SIkwCEdJHTD9v1(u"ࠧࡔࡊࡒࡓࡋࡓࡁ়࡙ࠩ"),TzIj50KpohEOHx6CbZWqB(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫঽ"),IOHSz7YPF9WusGgUt1Dq(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪা"),IO7k2hZXSz(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨি"),IOHSz7YPF9WusGgUt1Dq(u"ࠫࡒ࠹ࡕࠨী"),EJgYdjbIiWe1apkQlZcR42(u"ࠬࡏࡐࡕࡘࠪু"),bGzRdmOErkIylxALniq6(u"࠭ࡂࡐࡍࡕࡅࠬূ"),gDETKVh8mZe09Nd(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩৃ"),bGzRdmOErkIylxALniq6(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ৄ")]
NOT_TO_TEST_ALL_SERVERS = [wZ8xmFEXbo0AqiDW5JLGa4Vr2UsN(u"ࠩࡢࡅࡐࡕ࡟ࠨ৅"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠪࡣࡆࡑࡗࡠࠩ৆"),GVurlv8HeoXEzPRiQB7Ty(u"ࠫࡤࡏࡆࡍࡡࠪে"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠬࡥࡋࡓࡄࡢࠫৈ"),oVwa0kcqxj1e7mLplAfZdGT(u"࠭࡟ࡎࡔࡉࡣࠬ৉"),IO7k2hZXSz(u"ࠧࡠࡕࡋࡑࡤ࠭৊"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"ࠨࡡࡖࡌ࡛ࡥࠧো"),zLjWeKu6JgNO7vocUD0Qpy(u"ࠩࡢ࡝࡚࡚࡟ࠨৌ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠪࡣࡉࡒࡍࡠ্ࠩ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠫࡤࡓࡕࠨৎ"),t6JFqo2UXLjC8QYRngZ1PrKpyS05VN(u"ࠬࡥࡉࡑࠩ৏"),jwzOabysh0Z(u"࠭࡟ࡃࡍࡕࡣࠬ৐"),oVwa0kcqxj1e7mLplAfZdGT(u"ࠧࡠࡇࡏࡇࡤ࠭৑"),Js61GTdX5wzMurUqi7Z(u"ࠨࡡࡄࡖ࡙ࡥࠧ৒")]
ZZmTYCnwygl3aXzbA2EJ9 = [YQNd4wejLSAVJ6T(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ৓"),hPFcB6Uxmabj59Iq(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৔"),YQNd4wejLSAVJ6T(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ৕"),YQNd4wejLSAVJ6T(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ৖"),TzIj50KpohEOHx6CbZWqB(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫৗ"),qeG16a4pbSHziNVQ2uFXrs(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),RDwahqjPfbdyEiTtnLQu(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ৙"),qqw1upCsKM(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ৚")]
QjhUnOyxC3YtGv7gSbPlwazB2o1MA8 = [BewrUo9ANCa17G43Sn0LH5xh,t19ZOVHA4CpwFKaeiubcMGvz(u"࠱࠶࠲৴"),RDwahqjPfbdyEiTtnLQu(u"࠲࠸࠳ਃ"),Js61GTdX5wzMurUqi7Z(u"࠵࠼࠶ਆ"),oVwa0kcqxj1e7mLplAfZdGT(u"࠱࠺࠲৻"),t19ZOVHA4CpwFKaeiubcMGvz(u"࠵࠺࠵৾"),Js61GTdX5wzMurUqi7Z(u"࠲࠹࠲ਂ"),GVurlv8HeoXEzPRiQB7Ty(u"࠴࠵࠳ৼ"),IO7k2hZXSz(u"࠷࠹࠶৿"),IOHSz7YPF9WusGgUt1Dq(u"࠵࠳࠳৵"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠸࠴࠵ਅ"),t19ZOVHA4CpwFKaeiubcMGvz(u"࠻࠲࠱৺"),SE97R3Dpj6dPLweVKU(u"࠻࠳࠱ਁ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"࠷࠷࠴৽"),qeG16a4pbSHziNVQ2uFXrs(u"࠹࠹࠴਄"),gDETKVh8mZe09Nd(u"࠶࠶࠱࠱৹"),XxE4VAKW7LQzdk2Il3gUr1vwn(u"࠽࠾࠿࠰৸"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"࠳࠳࠶࠵৶"),YQNd4wejLSAVJ6T(u"࠴࠴࠽࠶৷"),TzIj50KpohEOHx6CbZWqB(u"࠶࠷࠰࠱਀")]
iSlmE0M1pBkwuq9D8CWtOrAK = [SIkwCEdJHTD9v1(u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ৛"),gDETKVh8mZe09Nd(u"ࠫ࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹࠭ড়"),SE97R3Dpj6dPLweVKU(u"ࠬ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠧঢ়"),IO7k2hZXSz(u"࠭࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࠫ৞"),XdGj3PYNmuBC42ZeMvqlW8bAi6LJV(u"ࠧ࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠬয়"),qqw1upCsKM(u"ࠨࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠪৠ"),phlEoViHIrU5ajAkv1DNGXfyqMB9(u"ࠩ࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠧৡ"),hPFcB6Uxmabj59Iq(u"ࠪࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷ࠬৢ"),E2QIcUfmlwa3xR17DFrkezBSsyh(u"ࠫ࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾࠭ৣ")]
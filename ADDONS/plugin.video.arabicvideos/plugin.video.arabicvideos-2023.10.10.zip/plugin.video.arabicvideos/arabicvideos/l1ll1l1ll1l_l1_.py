# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭❞")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡇࡄࡎࡣࠬ❟")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ❠"),l11ll1_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ❡")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l11111_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l1llll1_l1_(url,text)
	elif mode==624: results = l1l111_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1lll1_l1_(l11l1l_l1_,l11ll1_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ❢"),l11ll1_l1_ (u"ࠪๅอืใสࠢࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ❣"),l11ll1_l1_ (u"ࠫࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠫ❤"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❥"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭❦"),l11ll1_l1_ (u"ࠧࠨ❧"),629,l11ll1_l1_ (u"ࠨࠩ❨"),l11ll1_l1_ (u"ࠩࠪ❩"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ❪"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ❫"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ❬"),l11ll1_l1_ (u"࠭ࠧ❭"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❮"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❯")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่๊๋๊ำหࠪ❰"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠪࠫ❱"),l11ll1_l1_ (u"ࠫࠬ❲"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ❳"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❴"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ❵")+l111l1_l1_+l11ll1_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ❶"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠩࠪ❷"),l11ll1_l1_ (u"ࠪࠫ❸"),l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ❹"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❺"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ❻")+l111l1_l1_+l11ll1_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭❼"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠨࠩ❽"),l11ll1_l1_ (u"ࠩࠪ❾"),l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ❿"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➀"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ➁")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪ➂"),l1ll111_l1_,621,l11ll1_l1_ (u"ࠧࠨ➃"),l11ll1_l1_ (u"ࠨࠩ➄"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ➅"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ➆"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ➇"),l11ll1_l1_ (u"ࠬ࠭➈"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ➉"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ➊"),l11ll1_l1_ (u"ࠨࠩ➋"),l11ll1_l1_ (u"่ࠩ์็฿ࠠโสิ็ฮ࠭➌"),l11ll1_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭➍"))
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ➎"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➏"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ➐")+l111l1_l1_+title,l1lllll_l1_,624)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ➑"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➒"),l11ll1_l1_ (u"ࠩࠪ➓"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ➔"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ➕"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠬ࠭➖"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ➗"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➘"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ➙")+l111l1_l1_+title,l1lllll_l1_,624)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭➚"),url,l11ll1_l1_ (u"ࠪࠫ➛"),l11ll1_l1_ (u"ࠫࠬ➜"),l11ll1_l1_ (u"ࠬ࠭➝"),l11ll1_l1_ (u"࠭ࠧ➞"),l11ll1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭➟"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ➠"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪ➡"),l11ll1_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ➢"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ➣"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠬ࠭➤"),block)]
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➥"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ➦"),l11ll1_l1_ (u"ࠨࠩ➧"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ➨"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭➩")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➪"),l111l1_l1_+title,l1lllll_l1_,621)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ➫"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ➬"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ➭"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➮"),l11ll1_l1_ (u"ࠩࠪ➯"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➰"),l111l1_l1_+title,l1lllll_l1_,621)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠫࠬ➱")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭➲"),l11ll1_l1_ (u"࠭ࠧ➳"),request,url)
	if request==l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ➴"):
		url,search = url.split(l11ll1_l1_ (u"ࠨࡁࠪ➵"),1)
		data = l11ll1_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ➶")+search
		headers = {l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ➷"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ➸")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ➹"),url,data,headers,l11ll1_l1_ (u"࠭ࠧ➺"),l11ll1_l1_ (u"ࠧࠨ➻"),l11ll1_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭➼"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭➽"),url,l11ll1_l1_ (u"ࠪࠫ➾"),l11ll1_l1_ (u"ࠫࠬ➿"),l11ll1_l1_ (u"ࠬ࠭⟀"),l11ll1_l1_ (u"࠭ࠧ⟁"),l11ll1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⟂"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠨࠩ⟃"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⟄"))
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ⟅"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⟆"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠬ࠭⟇"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⟈"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⟉"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⟊"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⟋"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⟌"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⟍"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ⟎"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ⟏"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⟐"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩ⟑"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⟒"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⟓"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ⟔"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ⟕"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ⟖"),l11ll1_l1_ (u"ࠧไๆํฬࠬ⟗"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ⟘"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ⟙"),l11ll1_l1_ (u"้ࠪออัศหࠪ⟚"),l11ll1_l1_ (u"ࠫ฾ืึࠨ⟛"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ⟜"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ⟝"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧ⟞")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ⟟"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⟠") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ⟡")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭⟢"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⟣") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ⟤")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ⟥"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ⟦"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⟧"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⟨"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⟩"):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⟪"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⟫") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟬"),l111l1_l1_+title,l1lllll_l1_,623,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭⟭") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⟮"),l111l1_l1_+title,l1lllll_l1_,621,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟯"),l111l1_l1_+title,l1lllll_l1_,623,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⟰"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ⟱")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⟲"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⟳"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ⟴"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ⟵")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ⟶"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟷"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ⟸")+title,l1lllll_l1_,621)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⟹"),l11ll1_l1_ (u"ࠧࠨ⟺"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ⟻"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⟼"),url,l11ll1_l1_ (u"ࠪࠫ⟽"),l11ll1_l1_ (u"ࠫࠬ⟾"),l11ll1_l1_ (u"ࠬ࠭⟿"),l11ll1_l1_ (u"࠭ࠧ⠀"),l11ll1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ⠁"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ⠂"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⠃"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠪࠫ⠄")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࠬ࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ⠅"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠩࠧ⠆"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⠇"),l111l1_l1_+title,url,623,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ⠈"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭⠉")+l1l1l_l1_+l11ll1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⠊"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠫࠬ࡮ࡲࡦࡨࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪࠫࠬ⠋"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		if not items: items = re.findall(l11ll1_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⠌"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ⠍")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ⠎"))
			title = title.replace(l11ll1_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ⠏"),l11ll1_l1_ (u"ࠨࠢࠪ⠐"))
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⠑"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ⠒"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⠓") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ⠔")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ⠕"))
		#		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⠖"),l111l1_l1_+title,l1lllll_l1_,622,l1lll1_l1_)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ⠗"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⠘"),url,l11ll1_l1_ (u"ࠪࠫ⠙"),l11ll1_l1_ (u"ࠫࠬ⠚"),l11ll1_l1_ (u"ࠬ࠭⠛"),l11ll1_l1_ (u"࠭ࠧ⠜"),l11ll1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⠝"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⠞"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	post = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࡳࡳࡸࡺ࠽ࠨ⠟"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⠠"))
	post = EVAL(l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⠡"),post)
	l1l1_l1_ = post[l11ll1_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭⠢")]
	l11lll_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l1111l_l1_ = zip(l11lll_l1_,l1l1_l1_)
	for title,l1lllll_l1_ in l1111l_l1_:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⠣")+title+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⠤")
		l1llll_l1_.append(l1lllll_l1_)
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࠩࡩࡧࠢ࡯࡭ࡳࡱࠠࡢࡰࡧࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪ࠯ࡱ࡯࡮࡬ࠌࠌ࡬ࡦࡹࡨࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨࡪࡤࡷ࡭ࡃࠧࠪ࡝࠴ࡡࠏࠏࡰࡢࡴࡷࡷࠥࡃࠠࡩࡣࡶ࡬࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࠨࠫࠍࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡱࡣࡵࡸࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫࡴࡦࡸࡴࠬࠩࡀࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡵࡧࡲࡵࠢࡀࠤࡵࡧࡲࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡳࡥࡷࡺࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣࡾࡿࢀ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠲࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࡀࡂࠥ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ⠥")
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⠦"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⠧"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ⠨"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭⠩"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ⠪"),l11ll1_l1_ (u"ࠧࠬࠩ⠫"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ⠬")+search
	l1ll111_l1_,l111lll_l1_,l1ll1111l_l1_ = l1ll1l1lll1_l1_(url,l11ll1_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ⠭"),l11ll1_l1_ (u"ࠪๅอืใสࠢࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ⠮"),l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵࠧ⠯"))
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⠰"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ⠱")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ⠲"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
import bs4
script_name = l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ⓿")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡈࡐࡈࡥࠧ─")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1ll1ll11ll_l1_(url)
	elif mode==512: results = l1lll1ll111_l1_(url)
	elif mode==513: results = l1lll1l1lll_l1_(url)
	elif mode==514: results = l1ll1ll1l1l_l1_(url,l11ll1_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ━")+text)
	elif mode==515: results = l1ll1ll1l1l_l1_(url,l11ll1_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ│")+text)
	elif mode==516: results = l1lll111ll1_l1_(text)
	elif mode==517: results = l1lll11llll_l1_(url)
	elif mode==518: results = l1lll1l1111_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1lll11l11l_l1_(url)
	elif mode==521: results = l1ll1ll11l1_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1ll1lll111_l1_(text)
	elif mode==524: results = l1ll1lll1ll_l1_()
	elif mode==525: results = l1lll1l1ll1_l1_()
	elif mode==526: results = l1lll11l111_l1_()
	elif mode==527: results = l1ll1llll11_l1_()
	else: results = False
	return results
def MENU(l1l1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬ┃")):
	if not l1l1l1l1_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┄"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭┅"),l11ll1_l1_ (u"ࠧࠨ┆"),519)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭┇"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ┈"),l11ll1_l1_ (u"ࠪࠫ┉"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┊"),l111l1_l1_+l11ll1_l1_ (u"๋่ࠬิ๊฼อࠥอไฤ฻่ห้࠭┋"),l11ll1_l1_ (u"࠭ࠧ┌"),525)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┍"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็วูิวึࠩ┎"),l11ll1_l1_ (u"ࠩࠪ┏"),526)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┐"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊ๅึ่ไหฯ࠭┑"),l11ll1_l1_ (u"ࠬ࠭┒"),527)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆ่๊ํ฿วหࠩ└"),l11ll1_l1_ (u"ࠨࠩ┕"),524)
	return
def l1ll1lll1ll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┖"),l111l1_l1_+l11ll1_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦ࠭ࠡะสูฮ࠭┗"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࠫ┘"),520)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┙"),l111l1_l1_+l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡ࠯ࠣวาีหࠨ┚"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯࡭ࡣࡷࡩࡸࡺࠧ┛"),521)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ├"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรใั่ࠫ┝"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡳࡱࡪࡥࡴࡶࠪ┞"),521)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┟"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦ็ะืࠠๆึส๋ิฯࠧ┠"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࡶࡪࡧࡺࡷࠬ┡"),521)
	return
def l1lll1l1ll1_l1_():
	l11ll1_l1_ (u"ࠢࠣࠤࠐࠎࠎࡺࡹࡱࡧࠣࡁࠥ࠷ࠠࠤࠢࡤࡧࡹࡵࡲࡴࠏࠍࠍࡹࡿࡰࡦࠢࡀࠤ࠷ࠦࠣࠡࡸ࡬ࡨࡪࡵࡳࠎࠌࠌࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠ࠲ࠢࠦࠤࡲࡵࡶࡪࡧࡶࠑࠏࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࠷ࠥࠩࠠࡴࡧࡵ࡭ࡪࡹࠍࠋࠋࡩࡳࡷ࡫ࡩࡨࡰࠣࡁࠥ࡬ࡡ࡭ࡵࡨࠤࠨࠦࡡࡳࡣࡥ࡭ࡨࠓࠊࠊࡨࡲࡶࡪ࡯ࡧ࡯ࠢࡀࠤࡹࡸࡵࡦࠢࠦࠤࡪࡴࡧ࡭࡫ࡶ࡬ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊ࠥษแๅษ่ࠤ฾ืศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠳࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡ฻ิฬ๏࠭ࠬ࡭࡫ࡱ࡯࠸࠲࠵࠲࠳ࠬࠑࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮๊๋ࠫหๅ์้ࠤศ็ไศ็ࠣหั์ศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠵࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡษฯ๊อ๐ࠧ࠭࡮࡬ࡲࡰ࠻ࠬ࠶࠳࠴࠭ࠒࠐࠉ࡭࡫ࡱ࡯࠶ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠸ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠹ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠺ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠺ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏࠢࠣࠤ┢")
	l1ll1ll1ll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪ┣")
	l1lll1111l1_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬ┤")
	l1lll1l1l1l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭┥")
	l1ll1llll1l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭┦")
	l1ll1lllll1_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧ┧")
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┨"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆื้ๅฬะࠠฤใ็หู๊ࠦาสํࠫ┩"),l1lll1111l1_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┪"),l111l1_l1_+l11ll1_l1_ (u"ู่๋ࠩ็วห่ࠢืู้ไศฬࠣ฽ึฮ๊ࠨ┫"),l1lll1l1l1l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┬"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ฻ๆโษอࠤศ็ไศ็ࠣหั์ศ๋ࠩ┭"),l1ll1llll1l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┮"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅึ่ไหฯࠦๅิๆึ่ฬะࠠศฮ้ฬ๏࠭┯"),l1ll1lllll1_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ┰"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ┱"),l11ll1_l1_ (u"ࠩࠪ┲"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┳"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆํัิࠢฦ฽๊อไࠡลหะิ๐ࠧ┴"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬ┵"),517)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┶"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ้ิืࠥࠦศๅัࠣห้หๆหษฯࠫ┷"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡣࡰࡷࡱࡸࡷࡿࠧ┸"),517)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┹"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ์ืำࠡษ็่฿ฯࠧ┺"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ┻"),517)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┼"),l111l1_l1_+l11ll1_l1_ (u"࠭แ่ำึࠤ๊฻ๆโษอࠤฬู๊ๆๆࠪ┽"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴࡭ࡥ࡯ࡴࡨࠫ┾"),517)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┿"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๋ึูࠠิ่ฬࠤฬ๊ลึัสีࠬ╀"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡴࡨࡰࡪࡧࡳࡦࡡࡼࡩࡦࡸࠧ╁"),517)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ╂"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ╃"),l11ll1_l1_ (u"࠭ࠧ╄"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╅"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็๋หุ๋ࠠ࠮ࠢไ่ฯืࠠๆฯาำࠬ╆"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭╇"),515)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╈"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎วิ็ࠣ࠱ࠥ็ไหำࠣ็ฬ๋ไࠨ╉"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡧ࡬ࡴࠩ╊"),514)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ╋"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠶ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠳࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ╌"),l11ll1_l1_ (u"ࠨࠩ╍"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╎"),l111l1_l1_+l11ll1_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨ╏"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ═"),515)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ║"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫ╒"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ╓"),514)
	return
def l1ll1llll11_l1_():
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ╔"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ╕"),l11ll1_l1_ (u"ࠪࠫ╖"),l11ll1_l1_ (u"ࠫࠬ╗"),l11ll1_l1_ (u"ࠬ࠭╘"),l11ll1_l1_ (u"࠭ࠧ╙"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ╚"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭╛"),multi_valued_attributes=None)
	block = l1ll1ll111l_l1_.find(l11ll1_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵࠩ╜"),attrs={l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ╝"):l11ll1_l1_ (u"ࠫࡹࡧࡧࠨ╞")})	# <select name=l11ll1_l1_ (u"ࠬࡺࡡࡨࠩ╟")>
	options = block.find_all(l11ll1_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳ࠭╠"))
	for option in options:
		value = option.get(l11ll1_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭╡"))		# or option[l11ll1_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ╢")] l1l1l1ll1l_l1_ it will l1lll1l111l_l1_ if not l1l1l1111_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ╣"))
			value = value.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ╤"))
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸ࠬࡴࡺࡲࡨࡁࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨ╥")+value
		title = title.replace(l11ll1_l1_ (u"่ࠬวว็ฬࠤࠬ╦"),l11ll1_l1_ (u"࠭ࠧ╧"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╨"),l111l1_l1_+title,l1lllll_l1_,511)
	return
def l1lll11l111_l1_():
	l1ll1ll1ll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪ╩")
	l1lll11111l_l1_ = l1ll1ll1ll1_l1_+l11ll1_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭╪")
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╫"),l111l1_l1_+l11ll1_l1_ (u"๊ࠫ฻ๆโษอࠤศฺฮศืࠪ╬"),l1lll11111l_l1_,511)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ╭"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ╮"),l11ll1_l1_ (u"ࠧࠨ╯"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ╰"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๋ึูࠠฤึัหฺࠦรษฮา๎ࠬ╱"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬ╲"),517)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╳"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็็าี้ࠣํ฽ๆࠨ╴"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵࡮ࡢࡶ࡬ࡳࡳࡧ࡬ࡪࡶࡼࠫ╵"),517)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╶"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ๊ีุࠦࠠหษิ๎ำࠦวๅ็ํ่ฬีࠧ╷"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡥ࡭ࡷࡺࡨࡠࡻࡨࡥࡷ࠭╸"),517)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╹"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆํัิࠢࠣฮฬื๊ฯࠢส่ํ็วสࠩ╺"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡪࡥࡢࡶ࡫ࡣࡾ࡫ࡡࡳࠩ╻"),517)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ╼"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠲࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ╽"),l11ll1_l1_ (u"ࠨࠩ╾"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╿"),l111l1_l1_+l11ll1_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨ▀"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ▁"),515)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▂"),l111l1_l1_+l11ll1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫ▃"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ▄"),514)
	return
def l1ll1ll11ll_l1_(url):
	if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ▅") in url: index = 0
	elif l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ▆") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ▇"),url,l11ll1_l1_ (u"ࠫࠬ█"),l11ll1_l1_ (u"ࠬ࠭▉"),l11ll1_l1_ (u"࠭ࠧ▊"),l11ll1_l1_ (u"ࠧࠨ▋"),l11ll1_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭▌"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ▍"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠪ࡮ࡺࡳࡢࡰ࠯ࡷ࡬ࡪࡧࡴࡦࡴࠣࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠬ▎"))
	for block in l1111l1_l1_:
		title = block.find_all(l11ll1_l1_ (u"ࠫࡦ࠭▏"))[index].text
		l1lllll_l1_ = l11l1l_l1_+block.find_all(l11ll1_l1_ (u"ࠬࡧࠧ▐"))[index].get(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࠫ░"))
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ▒"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭▓"))
		if not l1111l1_l1_:
			l1lll1ll111_l1_(l1lllll_l1_)
			return
		else:
			title = title.replace(l11ll1_l1_ (u"ࠩๅหห๋ษࠡࠩ▔"),l11ll1_l1_ (u"ࠪࠫ▕"))
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▖"),l111l1_l1_+title,l1lllll_l1_,512)
	PAGINATION(l1ll1ll111l_l1_,511)
	return
def PAGINATION(l1ll1ll111l_l1_,mode):
	block = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ▗"))
	if block:
		l1l1l1lll_l1_ = block.find_all(l11ll1_l1_ (u"࠭ࡡࠨ▘"))
		l1ll1ll1111_l1_ = block.find_all(l11ll1_l1_ (u"ࠧ࡭࡫ࠪ▙"))
		l1lll111lll_l1_ = list(zip(l1l1l1lll_l1_,l1ll1ll1111_l1_))
		l11ll11111_l1_ = -1
		length = len(l1lll111lll_l1_)
		for l1ll111ll_l1_,l1ll1ll1lll_l1_ in l1lll111lll_l1_:
			l11ll11111_l1_ += 1
			l1ll1ll1lll_l1_ = l1ll1ll1lll_l1_[l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ▚")]
			if l11ll1_l1_ (u"ࠩࡸࡲࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠧ▛") in l1ll1ll1lll_l1_ or l11ll1_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࠫ▜") in l1ll1ll1lll_l1_: continue
			l1ll1lll1l1_l1_ = l1ll111ll_l1_.text
			l1lllll11l_l1_ = l11l1l_l1_+l1ll111ll_l1_.get(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ▝"))
			if kodi_version<19:
				l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ▞"))
				l1lllll11l_l1_ = l1lllll11l_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ▟"))
			if   l11ll11111_l1_==0: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠧฤ๊็ํࠬ■")
			elif l11ll11111_l1_==1: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠨีสฬ็ฯࠧ□")
			elif l11ll11111_l1_==length-2: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠩ็หา่ษࠨ▢")
			elif l11ll11111_l1_==length-1: l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠪวำ๐ัสࠩ▣")
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▤"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ▥")+l1ll1lll1l1_l1_,l1lllll11l_l1_,mode)
	return
def l1lll1ll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ▦"),url,l11ll1_l1_ (u"ࠧࠨ▧"),l11ll1_l1_ (u"ࠨࠩ▨"),l11ll1_l1_ (u"ࠩࠪ▩"),l11ll1_l1_ (u"ࠪࠫ▪"),l11ll1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠷࠭࠲ࡵࡷࠫ▫"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ▬"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"࠭ࡲࡰࡹࠪ▭"))
	items,first = [],True
	for block in l1111l1_l1_:
		if not block.find(class_=l11ll1_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫ▮")): continue
		if first: first = False ; continue
		l1lll11lll1_l1_ = []
		l1ll1l1llll_l1_ = block.find_all(class_=[l11ll1_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡸࡥࡥࠩ▯"),l11ll1_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡰࡶࡴࡳࡰࡪ࠭▰")])
		for l1ll1lll11l_l1_ in l1ll1l1llll_l1_:
			l1ll1ll111_l1_ = l1ll1lll11l_l1_.find_all(l11ll1_l1_ (u"ࠪࡰ࡮࠭▱"))[1].text
			if kodi_version<19:
				l1ll1ll111_l1_ = l1ll1ll111_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ▲"))
			l1lll11lll1_l1_.append(l1ll1ll111_l1_)
		if not l11l1l1_l1_(script_name,l11ll1_l1_ (u"ࠬ࠭△"),l1lll11lll1_l1_,False):
			l111_l1_ = block.find(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠪ▴")).get(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ▵"))
			title = block.find(l11ll1_l1_ (u"ࠨࡪ࠶ࠫ▶"))
			name = title.find(l11ll1_l1_ (u"ࠩࡤࠫ▷")).text
			l1lllll_l1_ = l11l1l_l1_+title.find(l11ll1_l1_ (u"ࠪࡥࠬ▸")).get(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ▹"))
			l1ll1llllll_l1_ = block.find(class_=l11ll1_l1_ (u"ࠬࡴ࡯࠮࡯ࡤࡶ࡬࡯࡮ࠨ►"))
			l1lll111111_l1_ = block.find(class_=l11ll1_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭▻"))
			if l1ll1llllll_l1_: l1ll1llllll_l1_ = l1ll1llllll_l1_.text
			if l1lll111111_l1_: l1lll111111_l1_ = l1lll111111_l1_.text
			if kodi_version<19:
				l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ▼"))
				name = name.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭▽"))
				l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▾"))
				if l1ll1llllll_l1_: l1ll1llllll_l1_ = l1ll1llllll_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▿"))
			l1ll1ll1l11_l1_ = {}
			if l1lll111111_l1_: l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠫࡸࡺࡡࡳࡵࠪ◀")] = l1lll111111_l1_
			if l1ll1llllll_l1_:
				l1ll1llllll_l1_ = l1ll1llllll_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ◁"),l11ll1_l1_ (u"࠭ࠠ࠯࠰ࠣࠫ◂"))
				l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡱ࡮ࡲࡸࠬ◃")] = l1ll1llllll_l1_.replace(l11ll1_l1_ (u"ࠨ࠰࠱࠲ฬ่ัฤࠢสุ่๊๊ะࠩ◄"),l11ll1_l1_ (u"ࠩࠪ◅"))
			if l11ll1_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪ◆") in l1lllll_l1_:
				#name = l11ll1_l1_ (u"ࠫอำหࠡ฻้ࠤࠬ◇")+name
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◈"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"࠭ࠧ◉"),name,l11ll1_l1_ (u"ࠧࠨ◊"),l1ll1ll1l11_l1_)
			elif l11ll1_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ○") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◌"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"ࠪࠫ◍"),name,l11ll1_l1_ (u"ࠫࠬ◎"),l1ll1ll1l11_l1_)
	PAGINATION(l1ll1ll111l_l1_,512)
	return
def l1lll1l1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ●"),url,l11ll1_l1_ (u"࠭ࠧ◐"),l11ll1_l1_ (u"ࠧࠨ◑"),l11ll1_l1_ (u"ࠨࠩ◒"),l11ll1_l1_ (u"ࠩࠪ◓"),l11ll1_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠷࠳࠱ࡴࡶࠪ◔"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ◕"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(l11ll1_l1_ (u"ࠬࡲࡩࠨ◖"))
	names,items = [],[]
	for block in l1111l1_l1_:
		if not block.find(class_=l11ll1_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪ◗")): continue
		if not block.find(class_=[l11ll1_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠩ◘"),l11ll1_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠣࡸࡪࡾࡴ࠮ࡥࡨࡲࡹ࡫ࡲࠨ◙")]): continue
		if block.find(class_=l11ll1_l1_ (u"ࠩ࡫࡭ࡩ࡫ࠧ◚")): continue
		title = block.find(class_=[l11ll1_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠬ◛"),l11ll1_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩࠦࡴࡦࡺࡷ࠱ࡨ࡫࡮ࡵࡧࡵࠫ◜")])
		name = title.find(l11ll1_l1_ (u"ࠬࡧࠧ◝")).text
		if name in names: continue
		names.append(name)
		l1lllll_l1_ = l11l1l_l1_+title.find(l11ll1_l1_ (u"࠭ࡡࠨ◞")).get(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࠬ◟"))
		if l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨ◠") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭◡")).get(l11ll1_l1_ (u"ࠪࡷࡷࡩࠧ◢"))
		elif l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭◣") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠬ࡯࡭ࡨࠩ◤")).get(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ◥"))
		elif l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ◦") in url: l111_l1_ = block.find(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠬ◧")).get(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ◨"))
		else: l111_l1_ = block.find(l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ◩")).get(l11ll1_l1_ (u"ࠫࡸࡸࡣࠨ◪"))
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ◫"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ◬"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ◭"))
		name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ◮"))
		items.append((name,l1lllll_l1_,l111_l1_))
	if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ◯") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1lllll_l1_,l111_l1_ in items:
		if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ◰") in url: addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ◱"),l111l1_l1_+name,l1lllll_l1_,522,l111_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ◲") in url: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◳"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"ࠧࠨ◴"),name)
		else: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◵"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"ࠩࠪ◶"),name)
	return
def l1lll111ll1_l1_(text):
	text = text.replace(l11ll1_l1_ (u"ࠪห้หูๅษ้ࠫ◷"),l11ll1_l1_ (u"ࠫࠬ◸")).replace(l11ll1_l1_ (u"๊ࠬแ๋ๆ่ࠫ◹"),l11ll1_l1_ (u"࠭ࠧ◺")).replace(l11ll1_l1_ (u"ࠧศๆิื๊๐ࠧ◻"),l11ll1_l1_ (u"ࠨࠩ◼"))
	text = text.replace(l11ll1_l1_ (u"ࠩศ฽้อๆࠨ◽"),l11ll1_l1_ (u"ࠪࠫ◾")).replace(l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ◿"),l11ll1_l1_ (u"ࠬ࠭☀")).replace(l11ll1_l1_ (u"࠭วๅสิ์๊๎ࠧ☁"),l11ll1_l1_ (u"ࠧࠨ☂"))
	text = text.replace(l11ll1_l1_ (u"ࠨษ็ฮู๎๊ใ์ࠪ☃"),l11ll1_l1_ (u"ࠩࠪ☄")).replace(l11ll1_l1_ (u"ู่๊ࠪไิๆࠪ★"),l11ll1_l1_ (u"ࠫࠬ☆")).replace(l11ll1_l1_ (u"๋ࠬำๅี็ࠫ☇"),l11ll1_l1_ (u"࠭ࠧ☈"))
	text = text.replace(l11ll1_l1_ (u"ࠧ࠻ࠩ☉"),l11ll1_l1_ (u"ࠨࠩ☊")).replace(l11ll1_l1_ (u"ࠩࠬࠫ☋"),l11ll1_l1_ (u"ࠪࠫ☌")).replace(l11ll1_l1_ (u"ࠫ࠭࠭☍"),l11ll1_l1_ (u"ࠬ࠭☎")).replace(l11ll1_l1_ (u"࠭ࠬࠨ☏"),l11ll1_l1_ (u"ࠧࠨ☐"))
	text = text.replace(l11ll1_l1_ (u"ࠨࡡࠪ☑"),l11ll1_l1_ (u"ࠩࠪ☒")).replace(l11ll1_l1_ (u"ࠪ࠿ࠬ☓"),l11ll1_l1_ (u"ࠫࠬ☔")).replace(l11ll1_l1_ (u"ࠬ࠳ࠧ☕"),l11ll1_l1_ (u"࠭ࠧ☖")).replace(l11ll1_l1_ (u"ࠧ࠯ࠩ☗"),l11ll1_l1_ (u"ࠨࠩ☘"))
	text = text.replace(l11ll1_l1_ (u"ࠩ࡟ࠫࠬ☙"),l11ll1_l1_ (u"ࠪࠫ☚")).replace(l11ll1_l1_ (u"ࠫࡡࠨࠧ☛"),l11ll1_l1_ (u"ࠬ࠭☜"))
	text = text.replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠫ☝"),l11ll1_l1_ (u"ࠧࠡࠩ☞")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ☟"),l11ll1_l1_ (u"ࠩࠣࠫ☠")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭☡"),l11ll1_l1_ (u"ࠫࠥ࠭☢"))
	text = text.strip(l11ll1_l1_ (u"ࠬࠦࠧ☣"))
	l1lll1l1l11_l1_ = text.count(l11ll1_l1_ (u"࠭ࠠࠨ☤"))+1
	if l1lll1l1l11_l1_==1:
		l1ll1lll111_l1_(text)
		return
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ☥"),l111l1_l1_+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๅๆหัะࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ☦"),l11ll1_l1_ (u"ࠩࠪ☧"),9999)
	l1lll111l11_l1_ = text.split(l11ll1_l1_ (u"ࠪࠤࠬ☨"))
	l1lll1l11ll_l1_ = pow(2,l1lll1l1l11_l1_)
	l1lll11l1ll_l1_ = []
	def l1lll1111ll_l1_(a,b):
		if a==l11ll1_l1_ (u"ࠫ࠶࠭☩"): return b
		return l11ll1_l1_ (u"ࠬ࠭☪")
	for l11ll11111_l1_ in range(l1lll1l11ll_l1_,0,-1):
		l1lll11l1l1_l1_ = list(l1lll1l1l11_l1_*l11ll1_l1_ (u"࠭࠰ࠨ☫")+bin(l11ll11111_l1_)[2:])[-l1lll1l1l11_l1_:]
		l1lll11l1l1_l1_ = reversed(l1lll11l1l1_l1_)
		result = map(l1lll1111ll_l1_,l1lll11l1l1_l1_,l1lll111l11_l1_)
		title = l11ll1_l1_ (u"ࠧࠡࠩ☬").join(filter(None,result))
		if kodi_version<19: l1lll1l1l_l1_ = title.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭☭"))
		else: l1lll1l1l_l1_ = title
		if len(l1lll1l1l_l1_)>2 and title not in l1lll11l1ll_l1_:
			l1lll11l1ll_l1_.append(title)
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☮"),l111l1_l1_+title,l11ll1_l1_ (u"ࠪࠫ☯"),523,l11ll1_l1_ (u"ࠫࠬ☰"),l11ll1_l1_ (u"ࠬ࠭☱"),title)
	return
def l1ll1lll111_l1_(l1lll1l11l1_l1_):
	if kodi_version<19:
		l1lll1l11l1_l1_ = l1lll1l11l1_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ☲"))
		import arabic_reshaper
		l1lll1l11l1_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1lll1l11l1_l1_)
		l1lll1l11l1_l1_ = bidi.algorithm.get_display(l1lll1l11l1_l1_)
	import l1lll11ll1l_l1_
	l1lll1l11l1_l1_ = OPEN_KEYBOARD(default=l1lll1l11l1_l1_)
	l1lll11ll1l_l1_.SEARCH(l1lll1l11l1_l1_)
	return
def l1lll11llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ☳"),url,l11ll1_l1_ (u"ࠨࠩ☴"),l11ll1_l1_ (u"ࠩࠪ☵"),l11ll1_l1_ (u"ࠪࠫ☶"),l11ll1_l1_ (u"ࠫࠬ☷"),l11ll1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ☸"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ☹"),multi_valued_attributes=None)
	block = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸ࠲ࡹࡥࡱࡣࡵࡥࡹࡵࡲࠡ࡮࡬ࡷࡹ࠳ࡴࡪࡶ࡯ࡩࠬ☺"))
	l11lll_l1_ = block.find_all(l11ll1_l1_ (u"ࠨࡣࠪ☻"))
	items = []
	for title in l11lll_l1_:
		name = title.text
		l1lllll_l1_ = l11l1l_l1_+title.get(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ☼"))
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ☽"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ☾"))
		if l11ll1_l1_ (u"ࠬࠩࠧ☿") not in l1lllll_l1_: items.append((name,l1lllll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1lllll_l1_ = item
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♀"),l111l1_l1_+name,l1lllll_l1_,518)
	return
def l1lll1l1111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ♁"),url,l11ll1_l1_ (u"ࠨࠩ♂"),l11ll1_l1_ (u"ࠩࠪ♃"),l11ll1_l1_ (u"ࠪࠫ♄"),l11ll1_l1_ (u"ࠫࠬ♅"),l11ll1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ♆"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ♇"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠧࡦࡺࡳࡥࡳࡪࠧ♈")).find_all(l11ll1_l1_ (u"ࠨࡶࡵࠫ♉"))
	for block in l1111l1_l1_:
		l1lll111l1l_l1_ = block.find_all(l11ll1_l1_ (u"ࠩࡤࠫ♊"))
		if not l1lll111l1l_l1_: continue
		l111_l1_ = block.find(l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ♋")).get(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭♌"))
		name = l1lll111l1l_l1_[1].text
		l1lllll_l1_ = l11l1l_l1_+l1lll111l1l_l1_[1].get(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ♍"))
		l1lll111111_l1_ = block.find(class_=l11ll1_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭♎"))
		if l1lll111111_l1_: l1lll111111_l1_ = l1lll111111_l1_.text
		if kodi_version<19:
			name = name.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♏"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭♐"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♑"))
		l1ll1ll1l11_l1_ = {}
		if l1lll111111_l1_: l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩ♒")] = l1lll111111_l1_
		if l11ll1_l1_ (u"ࠫ࠴ࡽ࡯ࡳ࡭࠲ࠫ♓") in l1lllll_l1_:
			#name = l11ll1_l1_ (u"ࠬฮอฬࠢ฼๊ࠥ࠭♔")+name
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♕"),l111l1_l1_+name,l1lllll_l1_,516,l111_l1_,l11ll1_l1_ (u"ࠧࠨ♖"),name,l11ll1_l1_ (u"ࠨࠩ♗"),l1ll1ll1l11_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ♘") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♙"),l111l1_l1_+name,l1lllll_l1_,513,l111_l1_,l11ll1_l1_ (u"ࠫࠬ♚"),name,l11ll1_l1_ (u"ࠬ࠭♛"),l1ll1ll1l11_l1_)
	PAGINATION(l1ll1ll111l_l1_,518)
	return
def l1lll11l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ♜"),url,l11ll1_l1_ (u"ࠧࠨ♝"),l11ll1_l1_ (u"ࠨࠩ♞"),l11ll1_l1_ (u"ࠩࠪ♟"),l11ll1_l1_ (u"ࠪࠫ♠"),l11ll1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡖࡊࡆࡈࡓࡘࡥࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ♡"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ♢"),multi_valued_attributes=None)
	l11lll_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡵ࡫ࡷࡰࡪࠦࡩ࡯࡮࡬ࡲࡪ࠭♣"))
	l1l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴࠠࡨࡴࡨࡩࡳࠦࡳ࡮ࡣ࡯ࡰࠥࡸࡩࡨࡪࡷࠫ♤"))
	items = zip(l11lll_l1_,l1l1_l1_)
	for title,l1lllll_l1_ in items:
		title = title.text
		l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_.get(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫࠭♥"))
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♦"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♧"))
		title = title.replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ♨"),l11ll1_l1_ (u"ࠬࠦࠧ♩")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ♪"),l11ll1_l1_ (u"ࠧࠡࠩ♫")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ♬"),l11ll1_l1_ (u"ࠩࠣࠫ♭"))
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♮"),l111l1_l1_+title,l1lllll_l1_,521)
	return
def l1ll1ll11l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ♯"),url,l11ll1_l1_ (u"ࠬ࠭♰"),l11ll1_l1_ (u"࠭ࠧ♱"),l11ll1_l1_ (u"ࠧࠨ♲"),l11ll1_l1_ (u"ࠨࠩ♳"),l11ll1_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡛ࡏࡄࡆࡑࡖࡣ࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ♴"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ♵"),multi_valued_attributes=None)
	l1lll1ll11l_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"ࠫࡱࡧࡲࡨࡧ࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠵ࠢࡰࡩࡩ࡯ࡵ࡮࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡࡵࡰࡥࡱࡲ࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠷࠭♶"))
	l1111l1_l1_ = l1lll1ll11l_l1_.find_all(l11ll1_l1_ (u"ࠬࡲࡩࠨ♷"))
	for block in l1111l1_l1_:
		title = block.find(class_=l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ♸")).text
		l1lllll_l1_ = l11l1l_l1_+block.find(l11ll1_l1_ (u"ࠧࡢࠩ♹")).get(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫࠭♺"))
		l111_l1_ = block.find(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭♻")).get(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ♼"))
		l1l11lll1_l1_ = block.find(class_=l11ll1_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭♽")).text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♾"))
			l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ♿"))
			l111_l1_ = l111_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚀"))
			l1l11lll1_l1_ = l1l11lll1_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚁"))
		l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ⚂"),l11ll1_l1_ (u"ࠪࠫ⚃")).strip(l11ll1_l1_ (u"ࠫࠥ࠭⚄"))
		addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⚅"),l111l1_l1_+title,l1lllll_l1_,522,l111_l1_,l1l11lll1_l1_)
	PAGINATION(l1ll1ll111l_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⚆"),url,l11ll1_l1_ (u"ࠧࠨ⚇"),l11ll1_l1_ (u"ࠨࠩ⚈"),l11ll1_l1_ (u"ࠩࠪ⚉"),l11ll1_l1_ (u"ࠪࠫ⚊"),l11ll1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⚋"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⚌"),multi_valued_attributes=None)
	l1lllll_l1_ = l1ll1ll111l_l1_.find(class_=l11ll1_l1_ (u"࠭ࡦ࡭ࡧࡻ࠱ࡻ࡯ࡤࡦࡱࠪ⚍")).find(l11ll1_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠧ⚎")).get(l11ll1_l1_ (u"ࠨࡵࡵࡧࠬ⚏"))
	if kodi_version<19: l1lllll_l1_ = l1lllll_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚐"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚑"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ⚒"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭⚓"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ⚔"),l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫ⚕"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡂࡵࡂ࠭⚖")+search
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⚗"),url,l11ll1_l1_ (u"ࠪࠫ⚘"),l11ll1_l1_ (u"ࠫࠬ⚙"),l11ll1_l1_ (u"ࠬ࠭⚚"),l11ll1_l1_ (u"࠭ࠧ⚛"),l11ll1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭⚜"))
	html = response.content
	l1ll1ll111l_l1_ = bs4.BeautifulSoup(html,l11ll1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⚝"),multi_valued_attributes=None)
	l1111l1_l1_ = l1ll1ll111l_l1_.find_all(class_=l11ll1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰ࠰ࡸ࡮ࡺ࡬ࡦࠢ࡯ࡩ࡫ࡺࠧ⚞"))
	for block in l1111l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚟"))
		title = title.split(l11ll1_l1_ (u"ࠫ࠭࠭⚠"),1)[0].strip(l11ll1_l1_ (u"ࠬࠦࠧ⚡"))
		if   l11ll1_l1_ (u"࠭รฺ็ส่ࠬ⚢") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⚣"),l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨ⚤"))
		elif l11ll1_l1_ (u"ࠩฦุำอีࠨ⚥") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⚦"),l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⚧"))
		#elif l11ll1_l1_ (u"ࠬษอะษฮࠫ⚨") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⚩"),l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡧࡹࡩࡳࡺ࠯ࠨ⚪"))
		#elif l11ll1_l1_ (u"ࠨ็๊ีัอๆศฬࠪ⚫") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⚬"),l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳࡫࡫ࡳࡵ࡫ࡹࡥࡱ࠵ࠧ⚭"))
		elif l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯ࠭⚮") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⚯"),l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ⚰"))
		#elif l11ll1_l1_ (u"ࠧฤะหหึ࠭⚱") in title: l1lllll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⚲"),l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡸࡴࡶࡩࡤ࠱ࠪ⚳"))
		else: continue
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚴"),l111l1_l1_+title,l1lllll_l1_,513)
	return
# ===========================================
#     l1lll1llll_l1_ l1lll1lll1_l1_ l1llll1111_l1_
# ===========================================
def l1ll1ll1l1l_l1_(url,text):
	global l1l11l1l_l1_,l1ll111l_l1_
	if l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ⚵") in url:
		l1l11l1l_l1_ = [l11ll1_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ⚶"),l11ll1_l1_ (u"࠭ࡹࡦࡣࡵࠫ⚷"),l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⚸")]
		l1ll111l_l1_ = [l11ll1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ⚹"),l11ll1_l1_ (u"ࠩࡼࡩࡦࡸࠧ⚺"),l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⚻")]
	elif l11ll1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ⚼") in url:
		l1l11l1l_l1_ = [l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⚽"),l11ll1_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ⚾"),l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ⚿")]
		l1ll111l_l1_ = [l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⛀"),l11ll1_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ⛁"),l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ⛂")]
	l1lll111_l1_(url,text)
	return
def l1llllll11_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⛃"))[0]
	#l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ⛄"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ⛅"),url,l11ll1_l1_ (u"ࠧࠨ⛆"),l11ll1_l1_ (u"ࠨࠩ⛇"),l11ll1_l1_ (u"ࠩࠪ⛈"),l11ll1_l1_ (u"ࠪࠫ⛉"),l11ll1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ⛊"))
	html = response.content
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࠣࡥࡨࡺࡩࡰࡰࡀࠦ࠴࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ⛋"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# name + category + options block
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺࠠ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⛌"),block,re.DOTALL)
	return l1ll1lll_l1_
def l1llll11ll_l1_(block):
	# value + name
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⛍"),block,re.DOTALL)
	return items
def l1llll1l11_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠨࡥࡤࡸࡂ࠭⛎"),l11ll1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ⛏"))
	l1lllll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⛐"))[0]
	l1llll1l1l_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ⛑"))
	#url = url.replace(l1lllll1l1_l1_,l1llll1l1l_l1_)
	url = url.replace(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⛒"),l11ll1_l1_ (u"࠭࠯ࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠨࠪ⛓"))
	return url
def l11111ll1l_l1_(l1l1ll1l_l1_,url):
	l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⛔")) # l1llllll1ll_l1_ be l1lllllllll_l1_
	l11l111_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⛕")+l11lllll_l1_
	l11l111_l1_ = l1llll1l11_l1_(l11l111_l1_)
	return l11l111_l1_
def l1lll111_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⛖"),l11ll1_l1_ (u"ࠪࠫ⛗"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⛘"),l11ll1_l1_ (u"ࠬ࠭⛙"),filter,url)
	if l11ll1_l1_ (u"࠭࠿ࠨ⛚") in url: url = url.split(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⛛"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ⛜"),1)
	if filter==l11ll1_l1_ (u"ࠩࠪ⛝"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ⛞"),l11ll1_l1_ (u"ࠫࠬ⛟")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ⛠"))
	if type==l11ll1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⛡"):
		if l1l11l1l_l1_[0]+l11ll1_l1_ (u"ࠧ࠾ࠩ⛢") not in l1l111ll_l1_: category = l1l11l1l_l1_[0]
		for i in range(len(l1l11l1l_l1_[0:-1])):
			if l1l11l1l_l1_[i]+l11ll1_l1_ (u"ࠨ࠿ࠪ⛣") in l1l111ll_l1_: category = l1l11l1l_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ⛤")+category+l11ll1_l1_ (u"ࠪࡁ࠵࠭⛥")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭⛦")+category+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ⛧")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨ⛨"))+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ⛩")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪ⛪"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⛫")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⛬")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ⛭"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⛮")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"࠭ࠧ⛯"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⛰")) # l1llllll1l1_l1_ l1111l11ll_l1_ not l11l111l11_l1_
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠨࠩ⛱"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⛲")+l1l111l1_l1_
		l111lll_l1_ = l1llll1l11_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛳"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ⛴"),l111lll_l1_,511)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛵"),l111l1_l1_+l11ll1_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭⛶")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭⛷"),l111lll_l1_,511)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⛸"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⛹"),l11ll1_l1_ (u"ࠪࠫ⛺"),9999)
	l1ll1lll_l1_ = l1llllll11_l1_(url)
	dict = {}
	for name,l1ll1l1l_l1_,block in l1ll1lll_l1_:
		name = name.replace(l11ll1_l1_ (u"ࠫ࠲࠳ࠧ⛻"),l11ll1_l1_ (u"ࠬ࠭⛼"))
		items = l1llll11ll_l1_(block)
		if l11ll1_l1_ (u"࠭࠽ࠨ⛽") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⛾"):
			if l1ll1l1l_l1_ not in l1l11l1l_l1_: continue
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<2:
				if l1ll1l1l_l1_==l1l11l1l_l1_[-1]:
					url = l1llll1l11_l1_(url)
					l1lll1ll111_l1_(url)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⛿")+l1l11lll_l1_)
				return
			else:
				l111lll_l1_ = l1llll1l11_l1_(l111lll_l1_)
				if l1ll1l1l_l1_==l1l11l1l_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✀"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠪ✁"),l111lll_l1_,511)
				else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✂"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬ✃"),l111lll_l1_,515,l11ll1_l1_ (u"࠭ࠧ✄"),l11ll1_l1_ (u"ࠧࠨ✅"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ✆"):
			if l1ll1l1l_l1_ not in l1ll111l_l1_: continue
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫ✇")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁ࠵࠭✈")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫ࠭✉")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠰ࠨ✊")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ✋")+l1l1ll1l_l1_
			if   name==l11ll1_l1_ (u"ࠧࡵࡻࡳࡩࠬ✌"): name = l11ll1_l1_ (u"ࠨษ็๊ํ฿ࠧ✍")
			elif name==l11ll1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ✎"): name = l11ll1_l1_ (u"ࠪห้฿ๅๅࠩ✏")
			elif name==l11ll1_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ✐"): name = l11ll1_l1_ (u"ࠬอไๅ฼ฬࠫ✑")
			elif name==l11ll1_l1_ (u"࠭ࡹࡦࡣࡵࠫ✒"): name = l11ll1_l1_ (u"ࠧศๆึ๊ฮ࠭✓")
			elif name==l11ll1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ✔"): name = l11ll1_l1_ (u"ࠩส่๊๎ำๆࠩ✕")
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ✖"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬๆ์฼࠾ࠥ࠭✗")+name,l111lll_l1_,514,l11ll1_l1_ (u"ࠬ࠭✘"),l11ll1_l1_ (u"࠭ࠧ✙"),l1l11lll_l1_)		# +l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ✚"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			if option in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠨ็ุ๊ๆอสࠡลัี๎࠭✛") in option: continue
			if l11ll1_l1_ (u"ࠩส่่๊ࠧ✜") in option: continue
			if l11ll1_l1_ (u"ࠪหฺ้๊สࠩ✝") in option: continue
			option = option.replace(l11ll1_l1_ (u"ࠫ็อฦๆหࠣࠫ✞"),l11ll1_l1_ (u"ࠬ࠭✟"))
			if   name==l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ✠"): name = l11ll1_l1_ (u"ࠧศๆ้์฾࠭✡")
			elif name==l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ✢"): name = l11ll1_l1_ (u"ࠩส่฾๋ไࠨ✣")
			elif name==l11ll1_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ✤"): name = l11ll1_l1_ (u"ࠫฬ๊ไ฻หࠪ✥")
			elif name==l11ll1_l1_ (u"ࠬࡿࡥࡢࡴࠪ✦"): name = l11ll1_l1_ (u"࠭วๅี้อࠬ✧")
			elif name==l11ll1_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ✨"): name = l11ll1_l1_ (u"ࠨษ็้ํูๅࠨ✩")
			#if l11ll1_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ✪") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ✫"),value,re.DOTALL)[0]
			dict[l1ll1l1l_l1_][value] = option
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫ࠭✬")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃࠧ✭")+option
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠨ✮")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾ࠩ✯")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ✰")+l1l1ll1l_l1_
			if name: title = option+l11ll1_l1_ (u"ࠩࠣ࠾ࠬ✱")+name
			else: title = option   #+dict[l1ll1l1l_l1_][l11ll1_l1_ (u"ࠪ࠴ࠬ✲")]
			if type==l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ✳"): addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✴"),l111l1_l1_+title,url,514,l11ll1_l1_ (u"࠭ࠧ✵"),l11ll1_l1_ (u"ࠧࠨ✶"),l1ll1l11_l1_)		# +l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ✷"))
			elif type==l11ll1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ✸") and l1l11l1l_l1_[-2]+l11ll1_l1_ (u"ࠪࡁࠬ✹") in l1l111ll_l1_:
				l11l111_l1_ = l11111ll1l_l1_(l1l1ll1l_l1_,url)
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✺"),l111l1_l1_+title,l11l111_l1_,511)
			else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✻"),l111l1_l1_+title,url,515,l11ll1_l1_ (u"࠭ࠧ✼"),l11ll1_l1_ (u"ࠧࠨ✽"),l1ll1l11_l1_)
	return
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ✾"),l11ll1_l1_ (u"ࠩࠪ✿"),filters,l11ll1_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫ❀"))
	# mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭❁")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ❂")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ❃")			all l1l1l1ll_l1_ & l1lllll111_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠧ࠾ࠨࠪ❄"),l11ll1_l1_ (u"ࠨ࠿࠳ࠪࠬ❅"))
	filters = filters.strip(l11ll1_l1_ (u"ࠩࠩࠫ❆"))
	l1l11l11_l1_ = {}
	if l11ll1_l1_ (u"ࠪࡁࠬ❇") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠫࠫ࠭❈"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠬࡃࠧ❉"))
			l1l11l11_l1_[var] = value
	l1ll11ll_l1_ = l11ll1_l1_ (u"࠭ࠧ❊")
	for key in l1ll111l_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠧ࠱ࠩ❋")
		if l11ll1_l1_ (u"ࠨࠧࠪ❌") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ❍") and value!=l11ll1_l1_ (u"ࠪ࠴ࠬ❎"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠱ࠠࠨ❏")+value
		elif mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ❐") and value!=l11ll1_l1_ (u"࠭࠰ࠨ❑"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࠧࠩ❒")+key+l11ll1_l1_ (u"ࠨ࠿ࠪ❓")+value
		elif mode==l11ll1_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ❔"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠪࠬ❕")+key+l11ll1_l1_ (u"ࠫࡂ࠭❖")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠫࠡࠩ❗"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠨ❘"))
	l1ll11ll_l1_ = l1ll11ll_l1_.replace(l11ll1_l1_ (u"ࠧ࠾࠲ࠪ❙"),l11ll1_l1_ (u"ࠨ࠿ࠪ❚"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ❛"),l11ll1_l1_ (u"ࠪࠫ❜"),filters,l11ll1_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬ❝"))
	return l1ll11ll_l1_
l1l11l1l_l1_ = []
l1ll111l_l1_ = []
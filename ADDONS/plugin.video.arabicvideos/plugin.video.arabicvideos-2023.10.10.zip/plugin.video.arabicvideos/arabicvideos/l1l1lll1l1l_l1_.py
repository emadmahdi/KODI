# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ⺬")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭⺭")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l11l_l1_ = l1l1lll_l1_[script_name][2]
l1l1ll1l1ll_l1_ = l1l1lll_l1_[script_name][3]
#l1l1lll111l_l1_  = l1l1lll_l1_[script_name][4]
#l1l1lll111l_l1_  = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==20: results = l1l1ll1ll11_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l11111_l1_(url,l1l1111_l1_)
	elif mode==23: results = l1llll1l_l1_(url,l1l1111_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l1ll11111_l1_(url)
	elif mode==27: results = l1l1ll1ll_l1_(url)
	elif mode==28: results = l1l1ll1llll_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l1ll1ll11_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⺮"),l111l1_l1_+l11ll1_l1_ (u"ࠩ฼ีอ๐ࠧ⺯"),l11l1l_l1_,21,l11ll1_l1_ (u"ࠪࠫ⺰"),l11ll1_l1_ (u"ࠫ࠶࠶࠱ࠨ⺱"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺲"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ⺳"),l11lllll1l_l1_,21,l11ll1_l1_ (u"ࠧࠨ⺴"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⺵"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺶"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅฬืำ๊ࠩ⺷"),l1l1ll1l11l_l1_,21,l11ll1_l1_ (u"ࠫࠬ⺸"),l11ll1_l1_ (u"ࠬ࠷࠰࠲ࠩ⺹"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺺"),l111l1_l1_+l11ll1_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ⺻"),l1l1ll1l1ll_l1_,21,l11ll1_l1_ (u"ࠨࠩ⺼"),l11ll1_l1_ (u"ࠩ࠴࠴࠶࠭⺽"))
	return
def l1l1ll1llll_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⺾"),l111l1_l1_+l11ll1_l1_ (u"ࠫ฾ืศ๋ࠩ⺿"),l11l1l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ⻀"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ⻁"),l11lllll1l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⻂"),l111l1_l1_+l11ll1_l1_ (u"ࠨใสีุ๏ࠧ⻃"),l1l1ll1l11l_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⻄"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⻅"),l1l1ll1l1ll_l1_,27)
	return
def MENU(l1l1lll1111_l1_):
	script_name = l1l1lll1111_l1_
	if l1l1lll1111_l1_==l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⻆"): l1l1lll1111_l1_ = l11l1l_l1_
	elif l1l1lll1111_l1_==l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⻇"): l1l1lll1111_l1_ = l11lllll1l_l1_
	else: script_name = l11ll1_l1_ (u"࠭ࠧ⻈")
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(l1l1lll1111_l1_)
	if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡢࡴࠪ⻉") or script_name==l11ll1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⻊"):
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⻋")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠤ࠲ࠦอศๆํอࠬ⻌")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥ࠳ࠠฤฯาฯࠬ⻍")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡลหะิ๐ࠧ⻎")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"࠭ศฬࠢะ๎ࠥศ๊ࠡใํ่๊࠭⻏")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"ࠧฤใ็ห๊࠭⻐")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"ࠨ็๋ื๏่้ࠨ⻑")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"ࠩหีฬ๋ฬࠨ⻒")
	elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡩࡳ࠭⻓") or script_name==l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ⻔"):
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡯࡮ࠡࡵ࡬ࡸࡪ࠭⻕")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠭ࠡࡅࡸࡶࡷ࡫࡮ࡵࠩ⻖")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠮ࠢࡏࡥࡹ࡫ࡳࡵࠩ⻗")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡅࡱࡶࡨࡢࡤࡨࡸࠬ⻘")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"ࠩࡏ࡭ࡻ࡫ࠠࡪࡈ࡬ࡰࡲࠦࡣࡩࡣࡱࡲࡪࡲࠧ⻙")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"ࠪࡑࡴࡼࡩࡦࡵࠪ⻚")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⻛")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"࡙ࠬࡨࡰࡹࡶࠫ⻜")
	elif l1ll1l1ll11_l1_ in [l11ll1_l1_ (u"࠭ࡦࡢࠩ⻝"),l11ll1_l1_ (u"ࠧࡧࡣ࠵ࠫ⻞")]:
		l1l1ll111l1_l1_ = l11ll1_l1_ (u"ࠨฮึฮั๎ࠠะำࠣืฬ໒สࠨ⻟")
		l1l1ll1111l_l1_ = l11ll1_l1_ (u"ࠩึี๏อไࠡ࠯ࠣะฬื໌ࠨ⻠")
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠪืึ๐วๅࠢ࠰ࠤวิัໍ่ࠪ⻡")
		l1l1ll111ll_l1_ = l11ll1_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥอไโสสࠫ⻢")
		l1l1ll11l1l_l1_ = l11ll1_l1_ (u"ࠬຄฮีࠢี๊ิํࠠศ์ࠣๅ๏๊ๅࠨ⻣")
		l1l1ll11l11_l1_ = l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ⻤")
		l1l1ll11lll_l1_ = l11ll1_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ⻥")
		l1l1ll11ll1_l1_ = l11ll1_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠫ⻦")
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⻧"),l111l1_l1_+l1l1ll111l1_l1_,l1l1lll1111_l1_,29,l11ll1_l1_ (u"ࠪࠫ⻨"),l11ll1_l1_ (u"ࠫࠬ⻩"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⻪"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡸࡨࠫ⻫"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⻬")+l111l1_l1_+l1l1ll11l1l_l1_,l1l1lll1111_l1_,27)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⻭"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⻮"),l11ll1_l1_ (u"ࠪࠫ⻯"),9999)
	menu = [l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⻰"),l11ll1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⻱"),l11ll1_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⻲")]
	html = OPENURL_CACHED(l1llllll_l1_,l1l1lll1111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭⻳"),l11ll1_l1_ (u"ࠨࠩ⻴"),l11ll1_l1_ (u"ࠩࠪ⻵"),l11ll1_l1_ (u"ࠪࠫ⻶"),l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⻷"))
	l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠬࡨࡵࡵࡶࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠰ࡅࡲࡲࡹࡧࡣࡵࠩ⻸"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⻹"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if any(value in l1lllll_l1_ for value in menu):
				url = l1l1lll1111_l1_+l1lllll_l1_
				if l11ll1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⻺") in l1lllll_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⻻"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⻼")+l111l1_l1_+l1l1ll1111l_l1_,url,22,l11ll1_l1_ (u"ࠪࠫ⻽"),l11ll1_l1_ (u"ࠫ࠶࠶࠰ࠨ⻾"))
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻿"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼀")+l111l1_l1_+l1ll1lll1l1_l1_,url,22,l11ll1_l1_ (u"ࠧࠨ⼁"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⼂"))
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼃"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⼄")+l111l1_l1_+l1l1ll111ll_l1_,url,22,l11ll1_l1_ (u"ࠫࠬ⼅"),l11ll1_l1_ (u"ࠬ࠸࠰࠲ࠩ⼆"))
				elif l11ll1_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⼇") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼈"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⼉")+l111l1_l1_+l1l1ll11l11_l1_,url,22,l11ll1_l1_ (u"ࠩࠪ⼊"),l11ll1_l1_ (u"ࠪ࠵࠵࠶ࠧ⼋"))
				elif l11ll1_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⼌") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼍"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼎")+l111l1_l1_+l1l1ll11lll_l1_,url,25,l11ll1_l1_ (u"ࠧࠨ⼏"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⼐"))
				elif l11ll1_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⼑") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼒"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⼓")+l111l1_l1_+l1l1ll11ll1_l1_,url,22,l11ll1_l1_ (u"ࠬ࠭⼔"),l11ll1_l1_ (u"࠭࠱࠱࠳ࠪ⼕"))
	return html
def l1l1ll11111_l1_(url):
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠧࠨ⼖"),l11ll1_l1_ (u"ࠨࠩ⼗"),l11ll1_l1_ (u"ࠩࠪ⼘"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡐ࡙ࡘࡏࡃࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⼙"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡒࡻࡳࡪࡥ࠰ࡸࡴࡵ࡬ࡴ࠯࡫ࡩࡦࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶࡵ࡬ࡧ࠲ࡨ࡯ࡥࡻࠪ⼚"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	title = re.findall(l11ll1_l1_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ⼛"),block,re.DOTALL)[0]
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼜"),l111l1_l1_+title,url,22,l11ll1_l1_ (u"ࠧࠨ⼝"),l11ll1_l1_ (u"ࠨ࠳࠳࠵ࠬ⼞"))
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⼟"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼠"),l111l1_l1_+title,l1lllll_l1_,23,l11ll1_l1_ (u"ࠫࠬ⼡"),l11ll1_l1_ (u"ࠬ࠷࠰࠲ࠩ⼢"))
	return
def l11111_l1_(url,l1l1111_l1_):
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	type = url.split(l11ll1_l1_ (u"࠭࠯ࠨ⼣"))[-1]
	l1l1l1lll1l_l1_ = str(int(l1l1111_l1_)//100)
	l1l1111_l1_ = str(int(l1l1111_l1_)%100)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ⼤"),l11ll1_l1_ (u"ࠨࠩ⼥"),url, type)
	if type==l11ll1_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⼦") and l1l1111_l1_==l11ll1_l1_ (u"ࠪ࠴ࠬ⼧"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ⼨"),l11ll1_l1_ (u"ࠬ࠭⼩"),l11ll1_l1_ (u"࠭ࠧ⼪"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⼫"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠧ⼬"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ⼭"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
			l1lll1_l1_ = l1l1lll1111_l1_ + QUOTE(l1lll1_l1_)
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼮"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠫ࠵࠷ࠧ⼯"))
	l1l1l1llll1_l1_=0
	if type==l11ll1_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⼰"): category=l11ll1_l1_ (u"࠭࠳ࠨ⼱")
	if type==l11ll1_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⼲"): category=l11ll1_l1_ (u"ࠨ࠷ࠪ⼳")
	if type==l11ll1_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⼴"): category=l11ll1_l1_ (u"ࠪ࠻ࠬ⼵")
	if type in [l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⼶"),l11ll1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⼷"),l11ll1_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⼸")] and l1l1111_l1_!=l11ll1_l1_ (u"ࠧ࠱ࠩ⼹"):
		l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡊࡶࡨࡱࡄࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ⼺")+category+l11ll1_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ⼻")+l1l1111_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃࠧ⼼")+l1l1l1lll1l_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⼽"),l11ll1_l1_ (u"ࠬ࠭⼾"),l11ll1_l1_ (u"࠭ࠧ⼿"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⽀"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⽁"),l11ll1_l1_ (u"ࠩࠪ⽂"),l111lll_l1_, html)
		items = re.findall(l11ll1_l1_ (u"ࠪࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯࠭ࡂࠦࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⽃"),html,re.DOTALL)
		for id,title,l1lll1_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ࠫࡡࡢࠧ⽄"),l11ll1_l1_ (u"ࠬ࠭⽅"))
			title = title.replace(l11ll1_l1_ (u"࠭ࠢࠨ⽆"),l11ll1_l1_ (u"ࠧࠨ⽇"))
			l1l1l1llll1_l1_ += 1
			l1lllll_l1_ = l1l1lll1111_l1_ + l11ll1_l1_ (u"ࠨ࠱ࠪ⽈") + type + l11ll1_l1_ (u"ࠩ࠲ࡇࡴࡴࡴࡦࡰࡷ࠳ࠬ⽉") + id
			l1lll1_l1_ = l1l1lll1111_l1_ + QUOTE(l1lll1_l1_)
			if type==l11ll1_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⽊"): addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⽋"),l111l1_l1_+title,l1lllll_l1_,24,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠬ࠶࠱ࠨ⽌"))
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⽍"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l1l1l1lll1l_l1_+l11ll1_l1_ (u"ࠧ࠱࠳ࠪ⽎"))
	if type==l11ll1_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⽏"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l1lll1111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡌࡲࡩ࡫ࡸࡀࡲࡤ࡫ࡪࡃࠧ⽐")+l1l1111_l1_,l11ll1_l1_ (u"ࠪࠫ⽑"),l11ll1_l1_ (u"ࠫࠬ⽒"),l11ll1_l1_ (u"ࠬ࠭⽓"),l11ll1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ⽔"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ࠱ࡩ࡫࡭ࡰࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࠰ࡨࡪࡳ࡯ࠨ⽕"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⽖"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1l1l1llll1_l1_ += 1
			l1lll1_l1_ = l1l1lll1111_l1_ + l1lll1_l1_
			l1lllll_l1_ = l1l1lll1111_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽗"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l11ll1_l1_ (u"ࠪ࠵࠵࠷ࠧ⽘"))
	if l1l1l1llll1_l1_>20:
		title=l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ⽙")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡫࡮ࠨ⽚"): title = l11ll1_l1_ (u"࠭ࡐࡢࡩࡨࠤࠬ⽛")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡧࡣࠪ⽜"): title = l11ll1_l1_ (u"ࠨืไั์ࠦࠧ⽝")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡩࡥ࠷࠭⽞"): title = l11ll1_l1_ (u"ูࠪๆำ็ࠡࠩ⽟")
		for l1l1ll1l1l1_l1_ in range(1,11) :
			if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
				l1l1l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࠵࠭⽠")+str(l1l1ll1l1l1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⽡"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,22,l11ll1_l1_ (u"࠭ࠧ⽢"),l1l1l1lll1l_l1_+l1l1l1lllll_l1_[-2:])
	return
def l1llll1l_l1_(url,l1l1111_l1_):
	if not l1l1111_l1_: l1l1111_l1_ = 0
	l1l1lll1111_l1_ = l1l1ll1l111_l1_(url)
	l1l1lll111l_l1_ = l1l1ll1l111_l1_(url)
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	parts = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ⽣"))
	id,type = parts[-1],parts[3]
	l1l1l1lll1l_l1_ = str(int(l1l1111_l1_)//100)
	l1l1111_l1_ = str(int(l1l1111_l1_)%100)
	l1l1l1llll1_l1_ = 0
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ⽤"),l11ll1_l1_ (u"ࠩࠪ⽥"),url, type)
	if type==l11ll1_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⽦"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ⽧"),l11ll1_l1_ (u"ࠬ࠭⽨"),l11ll1_l1_ (u"࠭ࠧ⽩"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⽪"))
		items = re.findall(l11ll1_l1_ (u"ࠨࡅࡲࡱࡲ࡫࡮ࡵࡡࡳࡥࡳ࡫࡬ࡠࡋࡷࡩࡲ࠴ࠪࡀࡲࡁࠬ࠳࠰࠿ࠪ࠾࡬࠲࠰ࡅࡶࡢࡴࠣ࡭ࡳࡺࡥࡳࡡࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫ࡟ࠫࠬ⽫"),html,re.DOTALL)
		title = l11ll1_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭⽬")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡩࡳ࠭⽭"): title = l11ll1_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ⽮")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡࠨ⽯"): title = l11ll1_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⽰")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡧࡣ࠵ࠫ⽱"): title = l11ll1_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⽲")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡩࡥࠬ⽳"): l1l1ll1ll1l_l1_ = l11ll1_l1_ (u"ࠪࠫ⽴")
		else: l1l1ll1ll1l_l1_ = l1ll1l1ll11_l1_
		l1l1lll11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩ࡫࡯࠾ࠤࠫ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࡡࠬࠬ࠳࠰࠿ࠪࠤࡁࠫ⽵"),html,re.DOTALL)
		for name,count,l1lll1_l1_,l1lllll_l1_ in items:
			for l1ll1l1_l1_ in range(int(count),0,-1):
				l1l11ll11_l1_ = l1lll1_l1_ + l1l1ll1ll1l_l1_ + id + l11ll1_l1_ (u"ࠬ࠵ࠧ⽶") + str(l1ll1l1_l1_) + l11ll1_l1_ (u"࠭࠮ࡱࡰࡪࠫ⽷")
				#l1lll11111l_l1_ = l1l1lll11ll_l1_[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"ࠧ࠰࠮ࠪ⽸")+str(l1ll1l1_l1_)+l11ll1_l1_ (u"ࠨ࠮ࠪ⽹")+str(l1ll1l1_l1_)+l11ll1_l1_ (u"ࠩࡢࠫ⽺")+l1l1lll11ll_l1_[0][2]
				l1l1ll1111l_l1_ = name + title + str(l1ll1l1_l1_)
				l1l1ll1111l_l1_ = unescapeHTML(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⽻"),l111l1_l1_+l1l1ll1111l_l1_,url,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠫࠬ⽼"),str(l1ll1l1_l1_))
	elif type==l11ll1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⽽"):
		l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡖࡡࡨࡧ࡬ࡲ࡬ࡇࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡋࡷࡩࡲࡅࡩࡥ࠿ࠪ⽾")+str(id)+l11ll1_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ⽿")+l1l1111_l1_+l11ll1_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡳࡷࡪࡥࡳࡤࡼࡁ࠶࠭⾀")
		html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ⾁"),l11ll1_l1_ (u"ࠪࠫ⾂"),l11ll1_l1_ (u"ࠫࠬ⾃"),l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⾄"))
		items = re.findall(l11ll1_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡉ࡯ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⾅"),html,re.DOTALL)
		title = l11ll1_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ⾆")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡧࡱࠫ⾇"): title = l11ll1_l1_ (u"ࠩࠣ࠱ࠥࡋࡰࡪࡵࡲࡨࡪࠦࠧ⾈")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡪࡦ࠭⾉"): title = l11ll1_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⾊")
		if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⾋"): title = l11ll1_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⾌")
		for l1ll1l1_l1_,l1lll1_l1_,l1lllll_l1_,desc,name in items:
			l1l1l1llll1_l1_ += 1
			l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
			#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
			name = escapeUNICODE(name)
			l1l1ll1111l_l1_ = name + title + str(l1ll1l1_l1_)
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⾍"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠨࠩ⾎"),str(l1l1l1llll1_l1_))
	elif type==l11ll1_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⾏"):
		if l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷࠫ⾐") in url and l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⾑") not in url:
			l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃࠧ⾒")+str(id)+l11ll1_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⾓")+l1l1111_l1_+l11ll1_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠱ࠩ⾔")
			html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ⾕"),l11ll1_l1_ (u"ࠩࠪ⾖"),l11ll1_l1_ (u"ࠪࠫ⾗"),l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩ⾘"))
			items = re.findall(l11ll1_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⾙"),html,re.DOTALL)
			for l1lll1_l1_,l1lllll_l1_,name,title in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = name + l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪ⾚") + title
				l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ⾛"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⾜"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠩࠪ⾝"),str(l1l1l1llll1_l1_))
		elif l11ll1_l1_ (u"ࠪࡇࡱ࡯ࡰࡴࠩ⾞") in url:
			l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭⾟")+l1l1111_l1_+l11ll1_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠷࠵ࠨ⾠")
			html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ⾡"),l11ll1_l1_ (u"ࠧࠨ⾢"),l11ll1_l1_ (u"ࠨࠩ⾣"),l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠸ࡹ࡮ࠧ⾤"))
			items = re.findall(l11ll1_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⾥"),html,re.DOTALL)
			for l1lll1_l1_,title,l1lllll_l1_ in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭⾦"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⾧"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"࠭ࠧ⾨"),str(l1l1l1llll1_l1_))
		elif l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⾩") in url:
			if l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠺ࠬ⾪") in url:
				l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⾫")+l1l1111_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠺ࠬ⾬")
				html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⾭"),l11ll1_l1_ (u"ࠬ࠭⾮"),l11ll1_l1_ (u"࠭ࠧ⾯"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠷ࡷ࡬ࠬ⾰"))
			elif l11ll1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠸ࠬ⾱") in url:
				l111lll_l1_ = l1l1lll1111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⾲")+l1l1111_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠸ࠬ⾳")
				html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⾴"),l11ll1_l1_ (u"ࠬ࠭⾵"),l11ll1_l1_ (u"࠭ࠧ⾶"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠸ࡷ࡬ࠬ⾷"))
			items = re.findall(l11ll1_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⾸"),html,re.DOTALL)
			for l1lll1_l1_,l1lllll_l1_,name,title in items:
				l1l1l1llll1_l1_ += 1
				l1l11ll11_l1_ = l1l1lll111l_l1_ + QUOTE(l1lll1_l1_)
				#l1lll11111l_l1_ = l1l1lll111l_l1_ + QUOTE(l1lllll_l1_)
				l1l1ll1111l_l1_ = name + l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭⾹") + title
				l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ⾺"))
				l1l1ll1111l_l1_ = escapeUNICODE(l1l1ll1111l_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⾻"),l111l1_l1_+l1l1ll1111l_l1_,l111lll_l1_,24,l1l11ll11_l1_,l11ll1_l1_ (u"ࠬ࠭⾼"),str(l1l1l1llll1_l1_))
	if type==l11ll1_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⾽") or type==l11ll1_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⾾"):
		if l1l1l1llll1_l1_>25:
			title=l11ll1_l1_ (u"ࠨืไัฮࠦࠧ⾿")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡨࡲࠬ⿀"): title = l11ll1_l1_ (u"ࠪࠤࡕࡧࡧࡦࠢࠪ⿁")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫ࡫ࡧࠧ⿂"): title = l11ll1_l1_ (u"ࠬࠦีโฯ๊ࠤࠬ⿃")
			if l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡦࡢ࠴ࠪ⿄"): title = l11ll1_l1_ (u"ࠧࠡืไั์ࠦࠧ⿅")
			for l1l1ll1l1l1_l1_ in range(1,11):
				if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
					l1l1l1lllll_l1_ = l11ll1_l1_ (u"ࠨ࠲ࠪ⿆")+str(l1l1ll1l1l1_l1_)
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿇"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,23,l11ll1_l1_ (u"ࠪࠫ⿈"),l1l1l1lll1l_l1_+l1l1l1lllll_l1_[-2:])
	return
def PLAY(url,l1ll1l1_l1_):
	l1l1lll111l_l1_ = l1l1ll1l111_l1_(url)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ⿉"),l11ll1_l1_ (u"ࠬ࠭⿊"),l11ll1_l1_ (u"࠭ࠧ⿋"),l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⿌"))
	# l1l11_l1_ l1llll111_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ⿍"),html,re.DOTALL)
	if items:
		l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
		parts = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ⿎"))
		id,type = parts[-1],parts[3]
		l1lllll_l1_ = items[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"ࠪ࠳࠱࠭⿏")+l1ll1l1_l1_+l11ll1_l1_ (u"ࠫ࠱࠭⿐")+l1ll1l1_l1_+l11ll1_l1_ (u"ࠬࡥࠧ⿑")+items[0][2]
		l1lll11l_l1_.append(l11ll1_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ⿒"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l11_l1_ l1111l1l_l1_ url
	items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭ࠩࠩ࡞࠱࠲࠯ࡅࠩࠣࠩ⿓"),html,re.DOTALL)
	if items:
		l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
		parts = url.split(l11ll1_l1_ (u"ࠨ࠱ࠪ⿔"))
		id,type = parts[-1],parts[3]
		l1lllll_l1_ = items[0][0]+l1ll1l1ll11_l1_+id+l11ll1_l1_ (u"ࠩ࠲ࠫ⿕")+l1ll1l1_l1_+items[0][2]
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪࡱࡵ࠺ࠠࡶࡴ࡯ࠫ⿖"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l11_l1_ l1111l1l_l1_ src
	items = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⿗"),html,re.DOTALL)
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬ࠵࠯ࠨ⿘"),l11ll1_l1_ (u"࠭࠯ࠨ⿙"))
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡸࡸࡣࠨ⿚"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l1ll1lll1_l1_ l1111l1l_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⿛"),html,re.DOTALL)
	if items:
		l1lllll_l1_ = items[int(l1ll1l1_l1_)-1]
		l1lllll_l1_ = l1l1lll111l_l1_+QUOTE(l1lllll_l1_)
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠩࡰࡴ࠹ࠦࡡࡥࡦࡵࡩࡸࡹࠧ⿜"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l1ll1lll1_l1_ l1l1lll1l11_l1_ l1l1_l1_
	items = re.findall(l11ll1_l1_ (u"࡚ࠪࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⿝"),html,re.DOTALL)
	if items:
		l1lllll_l1_ = items[int(l1ll1l1_l1_)-1]
		l1lllll_l1_ = l1l1lll111l_l1_+QUOTE(l1lllll_l1_)
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠫࡲࡶ࠳ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ⿞"))
		l1llll_l1_.append(l1lllll_l1_)
	# l1l_l1_
	if len(l1llll_l1_)==1: l1lllll_l1_ = l1llll_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭⿟"), l1lll11l_l1_)
		if l1l_l1_ == -1 : return
		l1lllll_l1_ = l1llll_l1_[l1l_l1_]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⿠"))
	return
def l1l1ll1l111_l1_(url):
	if l11l1l_l1_ in url: l1ll111l111_l1_ = l11l1l_l1_
	elif l11lllll1l_l1_ in url: l1ll111l111_l1_ = l11lllll1l_l1_
	elif l1l1ll1l11l_l1_ in url: l1ll111l111_l1_ = l1l1ll1l11l_l1_
	elif l1l1ll1l1ll_l1_ in url: l1ll111l111_l1_ = l1l1ll1l1ll_l1_
	else: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠧࠨ⿡")
	return l1ll111l111_l1_
def l1l1lll11l1_l1_(url):
	if   l11l1l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠨࡣࡵࠫ⿢")
	elif l11lllll1l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠩࡨࡲࠬ⿣")
	elif l1l1ll1l11l_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠪࡪࡦ࠭⿤")
	elif l1l1ll1l1ll_l1_ in url: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⿥")
	else: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠬ࠭⿦")
	return l1ll1l1ll11_l1_
def l1l1ll1ll_l1_(url):
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(url)
	l111lll_l1_ = url + l11ll1_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡒࡩࡷࡧࠪ⿧")
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ⿨"),l111lll_l1_,l11ll1_l1_ (u"ࠨࠩ⿩"),l11ll1_l1_ (u"ࠩࠪ⿪"),l11ll1_l1_ (u"ࠪࠫ⿫"),l11ll1_l1_ (u"ࠫࠬ⿬"),l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭⿭"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⿮"),html,re.DOTALL)
	l11l111_l1_ = items[0]
	PLAY_VIDEO(l11l111_l1_,script_name,l11ll1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⿯"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ⿰"),l11ll1_l1_ (u"ࠩ࠮ࠫ⿱"))
	if l1ll_l1_:
		l1ll1ll1l1_l1_ = [ l11l1l_l1_ , l11lllll1l_l1_ , l1l1ll1l11l_l1_ , l1l1ll1l1ll_l1_ ]
		l1l11l11l_l1_ = [ l11ll1_l1_ (u"ࠪ฽ึฮ๊ࠨ⿲") , l11ll1_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⿳") , l11ll1_l1_ (u"ࠬ็วาี์ࠫ⿴") , l11ll1_l1_ (u"࠭แศำึํࠥ࠸ࠧ⿵") ]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไๅ฼ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ⿶"), l1l11l11l_l1_)
		if l1l_l1_ == -1 : return
		l1l1l1l1_l1_ = l1ll1ll1l1_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠨࡡࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࡠࠩ⿷") in options: l1l1l1l1_l1_ = l11l1l_l1_
		elif l11ll1_l1_ (u"ࠩࡢࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࡢࠫ⿸") in options: l1l1l1l1_l1_ = l11lllll1l_l1_
		else: l1l1l1l1_l1_ = l11ll1_l1_ (u"ࠪࠫ⿹")
	if not l1l1l1l1_l1_: return
	l1ll1l1ll11_l1_ = l1l1lll11l1_l1_(l1l1l1l1_l1_)
	l111lll_l1_ = l1l1l1l1_l1_ + l11ll1_l1_ (u"ࠦ࠴ࡎ࡯࡮ࡧ࠲ࡗࡪࡧࡲࡤࡪࡂࡷࡪࡧࡲࡤࡪࡶࡸࡷ࡯࡮ࡨ࠿ࠥ⿺") + l1111ll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⿻"),l11ll1_l1_ (u"࠭ࠧ⿼"),l1ll1l1ll11_l1_,l111lll_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ⿽"),l11ll1_l1_ (u"ࠨࠩ⿾"),l11ll1_l1_ (u"ࠩࠪ⿿"),l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭　"))
	items = re.findall(l11ll1_l1_ (u"ࠫࠧࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡈࡧࡴࡦࡩࡲࡶࡾࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠨ、"),html,re.DOTALL)
	if items:
		for l1lll1_l1_,category,id,title in items:
			#if category in [l11ll1_l1_ (u"ࠬ࠹ࠧ。"),l11ll1_l1_ (u"࠭࠵ࠨ〃"),l11ll1_l1_ (u"ࠧ࠸ࠩ〄")]:
			if category in [l11ll1_l1_ (u"ࠨ࠵ࠪ々"),l11ll1_l1_ (u"ࠩ࠺ࠫ〆")]:
				title = title.replace(l11ll1_l1_ (u"ࠪࡠࡡ࠭〇"),l11ll1_l1_ (u"ࠫࠬ〈"))
				title = title.replace(l11ll1_l1_ (u"ࠬࠨࠧ〉"),l11ll1_l1_ (u"࠭ࠧ《"))
				if category==l11ll1_l1_ (u"ࠧ࠴ࠩ》"):
					type = l11ll1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ「")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡤࡶࠬ」"): name = l11ll1_l1_ (u"ุ้๊ࠪำๅࠢ࠽ࠤࠬ『")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫࡪࡴࠧ』"): name = l11ll1_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥࡀࠠࠨ【")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"࠭ࡦࡢࠩ】"): name = l11ll1_l1_ (u"ࠧิำํห้ࠦ็ศࠢ࠽ࠤࠬ〒")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡨࡤ࠶ࠬ〓"): name = l11ll1_l1_ (u"ࠩึี๏อไ้ࠡสࠤ࠿ࠦࠧ〔")
				elif category==l11ll1_l1_ (u"ࠪ࠹ࠬ〕"):
					type = l11ll1_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ〖")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬࡧࡲࠨ〗"): name = l11ll1_l1_ (u"࠭แ๋ๆ่ࠤ࠿ࠦࠧ〘")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡦࡰࠪ〙"): name = l11ll1_l1_ (u"ࠨࡏࡲࡺ࡮࡫ࠠ࠻ࠢࠪ〚")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠩࡩࡥࠬ〛"): name = l11ll1_l1_ (u"ࠪๅ๏๊ๅࠡ࠼ࠣࠫ〜")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠫ࡫ࡧ࠲ࠨ〝"): name = l11ll1_l1_ (u"ࠬ็ไๆ๊ࠢหࠥࡀࠠࠨ〞")
				elif category==l11ll1_l1_ (u"࠭࠷ࠨ〟"):
					type = l11ll1_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ〠")
					if l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠨࡣࡵࠫ〡"): name = l11ll1_l1_ (u"ࠩหี๋อๅอࠢ࠽ࠤࠬ〢")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠪࡩࡳ࠭〣"): name = l11ll1_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠥࡀࠠࠨ〤")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠬ࡬ࡡࠨ〥"): name = l11ll1_l1_ (u"࠭ศา่ส้์ࠦ็ศࠢ࠽ࠤࠬ〦")
					elif l1ll1l1ll11_l1_==l11ll1_l1_ (u"ࠧࡧࡣ࠵ࠫ〧"): name = l11ll1_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠤ࠿ࠦࠧ〨")
				title = name + title
				l1lllll_l1_ = l1l1l1l1_l1_ + l11ll1_l1_ (u"ࠩ࠲ࠫ〩") + type + l11ll1_l1_ (u"ࠪ࠳ࡈࡵ࡮ࡵࡧࡱࡸ࠴〪࠭") + id
				l1lll1_l1_ = QUOTE(l1lll1_l1_)
				l1lll1_l1_ = l1l1l1l1_l1_+l1lll1_l1_
				#LOG_THIS(l11ll1_l1_ (u"〫ࠫࠬ"),l1lll1_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〬"),l111l1_l1_+title,l1lllll_l1_,23,l1lll1_l1_,l11ll1_l1_ (u"࠭࠱࠱࠳〭ࠪ"))
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ〮"),l11ll1_l1_ (u"ࠨ〯ࠩ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ〰"),,لا توجد نتائج للبحث')
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭䲤")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡏ࠷࡙ࡤ࠭䲥")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ้์ฬ฿ࠠศใ็ห๊࠭䲦"),l11ll1_l1_ (u"ࠩฯ์ิอสࠡษไ่ฬ๋ࠧ䲧")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11111_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llll1l_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲨"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䲩"),l11ll1_l1_ (u"ࠬ࠭䲪"),389,l11ll1_l1_ (u"࠭ࠧ䲫"),l11ll1_l1_ (u"ࠧࠨ䲬"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䲭"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䲮"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䲯"),l11ll1_l1_ (u"ࠫࠬ䲰"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䲱"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䲲")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่้๏ุษࠨ䲳"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠨࠩ䲴"),l11ll1_l1_ (u"ࠩࠪ䲵"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䲶"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䲷"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䲸")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮส๊อ๐ษࠨ䲹"),l11l1l_l1_,381,l11ll1_l1_ (u"ࠧࠨ䲺"),l11ll1_l1_ (u"ࠨࠩ䲻"),l11ll1_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ䲼"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䲽"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ䲾"),l11ll1_l1_ (u"ࠬ࠭䲿"),l11ll1_l1_ (u"࠭ࠧ䳀"),l11ll1_l1_ (u"ࠧࠨ䳁"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䳂"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䳃"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳄"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䳅")+l111l1_l1_+title,l11l1l_l1_,381,l11ll1_l1_ (u"ࠬ࠭䳆"),l11ll1_l1_ (u"࠭ࠧ䳇"),l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ䳈")+str(seq))
	block = l11ll1_l1_ (u"ࠨࠩ䳉")
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ䳊"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡣࡶ࡭ࡩ࡫ࠧ䳋"),html,re.DOTALL)
	if l1l1l11_l1_: block += l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䳌"),block,re.DOTALL)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䳍"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䳎"),l11ll1_l1_ (u"ࠧࠨ䳏"),9999)
	first = True
	for l1lllll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11ll1_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ䳐"):
			if first:
				title = l11ll1_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ䳑")+title
				first = False
			else: title = l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ䳒")+title
		if title not in l1l11l_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳓"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䳔")+l111l1_l1_+title,l1lllll_l1_,381)
	return html
def l11111_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䳕"),l11ll1_l1_ (u"ࠧࠨ䳖"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䳗"),url,l11ll1_l1_ (u"ࠩࠪ䳘"),l11ll1_l1_ (u"ࠪࠫ䳙"),l11ll1_l1_ (u"ࠫࠬ䳚"),l11ll1_l1_ (u"ࠬ࠭䳛"),l11ll1_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䳜"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ䳝"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡷࡩࡨ࠮ࡲࡤ࡫ࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ䳞"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䳟"),block,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ䳠"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠨ䳡"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		z = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䳢"),block,re.DOTALL)
		l1llll_l1_,l1l1111l1_l1_,l1lll11l_l1_ = zip(*z)
		items = zip(l1l1111l1_l1_,l1llll_l1_,l1lll11l_l1_)
	elif type==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䳣"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࡶ࠱ࡹࡼࡳࡩࡱࡺࡷࠧ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ䳤"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䳥"),block,re.DOTALL)
	elif l11ll1_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ䳦") in type:
		seq = int(type[-1:])
		html = html.replace(l11ll1_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ䳧"),l11ll1_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡷࡹࡧࡲࡵࡀࠪ䳨"))
		html = html.replace(l11ll1_l1_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䳩"),l11ll1_l1_ (u"࠭࠼ࡦࡰࡧࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䳪"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡷࡥࡷࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡯ࡦࡁࠫ䳫"),html,re.DOTALL)
		block = l1l1l11_l1_[seq]
		if seq==2: items = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳬"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࢂࡳࡪࡦࡨࡦࡦࡸࠩࠨ䳭"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0][0]
			if l11ll1_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ䳮") in url:
				items = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䳯"),block,re.DOTALL)
			elif l11ll1_l1_ (u"ࠬ࠵ࡱࡶࡣ࡯࡭ࡹࡿ࠯ࠨ䳰") in url:
				items = re.findall(l11ll1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䳱"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䳲"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࠧ䳳") in title:
			title = re.findall(l11ll1_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡥࡳ࡫ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䳴"),title,re.DOTALL)
			title = title[0][1]#+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧ䳵")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䳶")+title
		l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠭䳷"),title,re.DOTALL)
		if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0]
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ䳸") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䳹"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䳺") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳻"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭䳼") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳽"),l111l1_l1_+title,l1lllll_l1_,383,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ䳾") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳿"),l111l1_l1_+title,l1lllll_l1_,381,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䴀"),l111l1_l1_+title,l1lllll_l1_,382,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡒࡤ࡫ࡪࠦࠨ࠯ࠬࡂ࠭ࠥࡵࡦࠡࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䴁"),html,re.DOTALL)
	if l1l1l11_l1_:
		current = l1l1l11_l1_[0][0]
		last = l1l1l11_l1_[0][1]
		block = l1l1l11_l1_[0][2]
		items = re.findall(l11ll1_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦ䴂"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title==l11ll1_l1_ (u"ࠪࠫ䴃") or title==last: continue
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䴄"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ䴅")+title,l1lllll_l1_,381,l11ll1_l1_ (u"࠭ࠧ䴆"),l11ll1_l1_ (u"ࠧࠨ䴇"),type)
		#if title==last:
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䴈")+title+l11ll1_l1_ (u"ࠩ࠲ࠫ䴉"),l11ll1_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪ䴊")+last+l11ll1_l1_ (u"ࠫ࠴࠭䴋"))
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴌"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯำูࠣๆำษࠡࠩ䴍")+last,l1lllll_l1_,381,l11ll1_l1_ (u"ࠧࠨ䴎"),l11ll1_l1_ (u"ࠨࠩ䴏"),type)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䴐"),url,l11ll1_l1_ (u"ࠪࠫ䴑"),l11ll1_l1_ (u"ࠫࠬ䴒"),l11ll1_l1_ (u"ࠬ࠭䴓"),l11ll1_l1_ (u"࠭ࠧ䴔"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䴕"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䴖"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_,False):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䴗"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ำๅี็ࠤ้๊ใษษิࠤํอไๆสิ้ัࠦๅ็฻๊ࠫ䴘"),l11ll1_l1_ (u"ࠫࠬ䴙"),9999)
		return
	if l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ䴚") in url or l11ll1_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ䴛") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩ࡬ࡸࡪࡳࠧ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬ䴜"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[1]
			l1llll1l_l1_(l111lll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸ࠭ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡤࡷࡹࠨࠧࠨࠩ䴝"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡳࡻ࡭ࡦࡴࡤࡲࡩࡵࠧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫ䴞"),block,re.DOTALL)
		for l1lll1_l1_,l1ll1l1_l1_,l1lllll_l1_,name in items:
			title = l1ll1l1_l1_+l11ll1_l1_ (u"ࠪࠤ࠿ࠦࠧ䴟")+name+l11ll1_l1_ (u"ࠫࠥอไฮๆๅอࠬ䴠")
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䴡"),l111l1_l1_+title,l1lllll_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ䴢"),url,l11ll1_l1_ (u"ࠧࠨ䴣"),l11ll1_l1_ (u"ࠨࠩ䴤"),l11ll1_l1_ (u"ࠩࠪ䴥"),l11ll1_l1_ (u"ࠪࠫ䴦"),l11ll1_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䴧"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴨"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠢࠣ࡫ࡧࡁࠬࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠧࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁ࠭ࠨࡳࡩࡧࡤࡨࡪࡸࠢࡽࠩࡳࡥ࡬ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࠫࠥࠦࠧ䴩"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0][0]
		items = re.findall(l11ll1_l1_ (u"ࠢࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡹࡥࡳࡸࡨࡶࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨ䴪"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䴫")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䴬")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮࠰ࡧࡱࡵࡳࡦࠤࠪ䴭"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡤࡥ࡟ࡥ࡮ࡢ࡫ࡩࡸࡩࡷࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䴮"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䴯")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䴰")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䴱"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䴲"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠩࠪ䴳"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠪࠫ䴴"): return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭䴵"),l11ll1_l1_ (u"ࠬ࠱ࠧ䴶"))
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡀࡵࡀࠫ䴷")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ䴸"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from l11lll1l1l1_l1_ import *
script_name = l11ll1_l1_ (u"ࠧࡊࡐࡌࡘࠬ煐")
LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ煑"),l11ll1_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠧ煒"))
l1ll1111l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
l1l1lllll1ll_l1_ = int(mode)
l1ll1l1l1ll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ煓"))
l1ll1l1l1ll1_l1_ = l1ll1l1l1ll1_l1_.replace(ltr,l11ll1_l1_ (u"ࠫࠬ煔")).replace(rtl,l11ll1_l1_ (u"ࠬ࠭煕"))
if l1l1lllll1ll_l1_==260: message = l11ll1_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ煖")+l11llll111l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ煗")+l1l111l1l1l_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ煘")
else:
	l1ll1l11ll111_l1_ = l1111_l1_(addon_path).replace(l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ煙"),l11ll1_l1_ (u"ࠪࠫ煚")).replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ煛"),l11ll1_l1_ (u"ࠬ࠭煜"))
	l1ll1l11ll111_l1_ = l1ll1l11ll111_l1_.replace(l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ煝"),l11ll1_l1_ (u"ࠧࠨ煞")).strip(l11ll1_l1_ (u"ࠨࠢࠪ煟"))
	l1ll1l11ll111_l1_ = l1ll1l11ll111_l1_.replace(l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ煠"),l11ll1_l1_ (u"ࠪࠤࠬ煡")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ煢"),l11ll1_l1_ (u"ࠬࠦࠧ煣")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ煤"),l11ll1_l1_ (u"ࠧࠡࠩ煥"))
	message = l11ll1_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ煦")+l1ll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ照")+mode+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ煨")+l1ll1l11ll111_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ煩")
LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ煪"),LOGGING(script_name)+message)
l1l1lll11l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ煫"))
l1llllllllll_l1_ = True if l1l1lll11l1l_l1_==l11llll111l_l1_ else False
if not l1llllllllll_l1_ and l1l1lllll1ll_l1_ in [235,715]:
	l1lll111l11l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ煬")])
	script_name = l11ll1_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭煭") if l1l1lllll1ll_l1_==235 else l11ll1_l1_ (u"ࠩࡰ࠷ࡺ࠭煮")
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࠧ煯")+script_name+l11ll1_l1_ (u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ煰")+l1lll111l11l_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࠩ煱")+script_name+l11ll1_l1_ (u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ煲")+l1lll111l11l_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠧࡽࠩ煳")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ煴")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ煵")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"ࠪࢀࠫ࠭煶"),l11ll1_l1_ (u"ࠫࢁ࠭煷"))
	l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࠩ煸")+script_name+l11ll1_l1_ (u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ煹")+l1lll111l11l_l1_)
	if l1111l1l11_l1_:
		l1l111111l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ煺"),url,re.DOTALL)
		url = url.replace(l1l111111l1l_l1_[0],l1111l1l11_l1_)
	script_name = script_name.upper()
	l1l11l11l11_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lllll1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩ煻")
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ煼"))
	try: l1lll1llll1l_l1_(l1ll1111l1l_l1_,l1ll1l1l1ll1_l1_)
	except Exception as error: l1lllll1lll1_l1_ = traceback.format_exc()
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠪࡷࡹࡵࡰࠨ煽"))
	l1ll1111llll_l1_(l1lllll1lll1_l1_)
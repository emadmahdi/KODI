# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ拑")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭拒")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ拓"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11111_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1ll1lllll1l1_l1_(url)
	elif mode==314: results = l1llll1ll_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ拔"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ拕"),l11ll1_l1_ (u"ࠫࠬ拖"),319,l11ll1_l1_ (u"ࠬ࠭拗"),l11ll1_l1_ (u"࠭ࠧ拘"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ拙"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ拚"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠧ招"),l11ll1_l1_ (u"ࠪࠫ拜"),114,l11l1l_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ拝"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭拞"),l11ll1_l1_ (u"࠭ࠧ拟"),l11ll1_l1_ (u"ࠧࠨ拠"),l11ll1_l1_ (u"ࠨࠩ拡"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ拢"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ拣"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ拤"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ拥"),l11ll1_l1_ (u"࠭ࠧ拦"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ拧"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11ll1_l1_ (u"ࠨࠢࠪ拨"))
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ择"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ拪")+l111l1_l1_+title,l11l1l_l1_,314,l11ll1_l1_ (u"ࠫࠬ拫"),l11ll1_l1_ (u"ࠬ࠭括"),str(seq+1))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭拭"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ拮")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ๅห฼฿ࠠี้ิࠫ拯"),l11l1l_l1_,314,l11ll1_l1_ (u"ࠩࠪ拰"),l11ll1_l1_ (u"ࠪࠫ拱"),l11ll1_l1_ (u"ࠫ࠵࠭拲"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ拳"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭拴"),l11ll1_l1_ (u"ࠧࠨ拵"),9999)
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡆࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡈ࠾ࠨ拶"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ拷")+l1lllll_l1_
		#title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ拸"))
		#url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡆ࡭ࡲࡧࡎࡰࡹ࠲ࡍࡳࡺࡥࡳࡨࡤࡧࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠴ࡰࡩࡲࠪ拹")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ拺"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ拻")+l111l1_l1_+title,l1lllll_l1_,311)
	return html
def l1llll1ll_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ拼"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ拽"),l11ll1_l1_ (u"ࠩࠪ拾"),l11ll1_l1_ (u"ࠪࠫ拿"),l11ll1_l1_ (u"ࠫࠬ挀"),l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ持"))
	html = response.content
	if seq==l11ll1_l1_ (u"࠭࠰ࠨ挂"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ挃"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ挄"),block,re.DOTALL)
		for l1lllll_l1_,name,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ挅")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ挆"))
			name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭指"))
			title = title+l11ll1_l1_ (u"ࠬࠦࠨࠨ挈")+name+l11ll1_l1_ (u"࠭ࠩࠨ按")
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭挊"),l111l1_l1_+title,l1lllll_l1_,312)
	elif seq in [l11ll1_l1_ (u"ࠨ࠳ࠪ挋"),l11ll1_l1_ (u"ࠩ࠵ࠫ挌"),l11ll1_l1_ (u"ࠪ࠷ࠬ挍")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡮ࡪࠫ挎"),html,re.DOTALL)
		l1ll1lllll11l_l1_ = int(seq)-1
		block = l1l1l11_l1_[l1ll1lllll11l_l1_]
		if seq==l11ll1_l1_ (u"ࠬ࠷ࠧ挏"): items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ挐"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ挑"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,name in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࠪ挒")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ挓")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ挔"))
			name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭挕"))
			title = title+l11ll1_l1_ (u"ࠬࠦࠨࠨ挖")+name+l11ll1_l1_ (u"࠭ࠩࠨ挗")
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ挘"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	elif seq in [l11ll1_l1_ (u"ࠨ࠶ࠪ挙"),l11ll1_l1_ (u"ࠩ࠸ࠫ挚"),l11ll1_l1_ (u"ࠪ࠺ࠬ挛")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ挜"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1l11_l1_[seq]
		items = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ挝"),block,re.DOTALL)
		for l1lll1_l1_,l1lllll_l1_,l1l1ll1111l_l1_,title,l1ll1lll1l1_l1_ in items:
			l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ挞")+l1lll1_l1_
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ挟")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ挠"))
			l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11ll1_l1_ (u"ࠩࠣࠫ挡"))
			l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ挢"))
			if l1l1ll1111l_l1_: name = l1l1ll1111l_l1_
			else: name = l1ll1lll1l1_l1_
			title = title+l11ll1_l1_ (u"ࠫࠥ࠮ࠧ挣")+name+l11ll1_l1_ (u"ࠬ࠯ࠧ挤")
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ挥"),l111l1_l1_+title,l1lllll_l1_,312,l1lll1_l1_)
	return
def l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ挦"),url,l11ll1_l1_ (u"ࠨࠩ挧"),l11ll1_l1_ (u"ࠩࠪ挨"),l11ll1_l1_ (u"ࠪࠫ挩"),l11ll1_l1_ (u"ࠫࠬ挪"),l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ挫"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡣࡱࡻ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡵࡡࡵ࠯ࡵ࡭࡬࡮ࡴࠨ挬"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	if l11ll1_l1_ (u"ࠧࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠧ挭") in block:
		items = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ挮"),block,re.DOTALL)
		if items:
			for l1lll1_l1_,l1lllll_l1_,title,count in items:
				l1lll1_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ振")+l1lll1_l1_
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ挰")+l1lllll_l1_
				count = count.replace(l11ll1_l1_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ挱"),l11ll1_l1_ (u"ࠬࡀࠧ挲"))
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ挳"))
				title = title+l11ll1_l1_ (u"ࠧࠡࠪࠪ挴")+count+l11ll1_l1_ (u"ࠨࠫࠪ挵")
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挶"),l111l1_l1_+title,l1lllll_l1_,311,l1lll1_l1_)
	else:
		items = re.findall(l11ll1_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ挷"),block,re.DOTALL)
		for l1lllll_l1_,title,l1ll1lllll1ll_l1_,l1l11lll1_l1_ in items:
			if title==l11ll1_l1_ (u"ࠫࠬ挸") or l1ll1lllll1ll_l1_==l11ll1_l1_ (u"ࠬ࠭挹"): continue
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ挺")+l1lllll_l1_
			title = title+l11ll1_l1_ (u"ࠧࠡࠪࠪ挻")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠨࠫࠪ挼")
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ挽"),l111l1_l1_+title,l1lllll_l1_,312)
	if not items: l1llll1l_l1_(html)
	return
def l1llll1l_l1_(html):
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ挾"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ挿"),block,re.DOTALL)
	for l1lllll_l1_,title,name,count,l1l11lll1_l1_ in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ捀")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ捁"))
		name = name.strip(l11ll1_l1_ (u"ࠧࠡࠩ捂"))
		title = title+l11ll1_l1_ (u"ࠨࠢࠫࠫ捃")+name+l11ll1_l1_ (u"ࠩࠬࠫ捄")
		addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ捅"),l111l1_l1_+title,l1lllll_l1_,312,l11ll1_l1_ (u"ࠫࠬ捆"),l1l11lll1_l1_)
	return
def l1ll1lllll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ捇"),url,l11ll1_l1_ (u"࠭ࠧ捈"),l11ll1_l1_ (u"ࠧࠨ捉"),l11ll1_l1_ (u"ࠨࠩ捊"),l11ll1_l1_ (u"ࠩࠪ捋"),l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍࡥࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ捌"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠣࡴ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ捍"),html,re.DOTALL)
	if not l1l1l11_l1_:
		l11111_l1_(url)
		return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ捎"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࠨ捏")+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ捐"))
		if l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠭ࠨ捑") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ捒"),l111l1_l1_+title,l1lllll_l1_,312)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ捓"),l111l1_l1_+title,l1lllll_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ捔"),url,l11ll1_l1_ (u"ࠬ࠭捕"),l11ll1_l1_ (u"࠭ࠧ捖"),l11ll1_l1_ (u"ࠧࠨ捗"),l11ll1_l1_ (u"ࠨࠩ捘"),l11ll1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ捙"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡦࡻࡤࡪࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ捚"),html,re.DOTALL)
	if not l1lllll_l1_: l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ捛"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ捜"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧ捝"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ捞"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ损"),l11ll1_l1_ (u"ࠩ࠮ࠫ捠"))
	l11llll1ll11_l1_ = [l11ll1_l1_ (u"ࠪࠪࡹࡃࡡࠨ捡"),l11ll1_l1_ (u"ࠫࠫࡺ࠽ࡤࠩ换"),l11ll1_l1_ (u"ࠬࠬࡴ࠾ࡵࠪ捣")]
	if l1ll_l1_:
		l1l11111l1ll_l1_ = [l11ll1_l1_ (u"࠭โศำษࠫ捤"),l11ll1_l1_ (u"ࠧฦืาหึࠦ࠯ࠡ็ฯ่ิ࠭捥"),l11ll1_l1_ (u"ࠨ็ๅ฻฾ࠦวๅื๋ฮ๏࠭捦")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ࠲ࠦรฯฬิࠤฬ๊ศฮอࠪ捧"), l1l11111l1ll_l1_)
		if l1l_l1_ == -1: return
	elif l11ll1_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࡠࠩ捨") in options: l1l_l1_ = 0
	elif l11ll1_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ捩") in options: l1l_l1_ = 1
	elif l11ll1_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ捪") in options: l1l_l1_ = 2
	else: return
	type = l11llll1ll11_l1_[l1l_l1_]
	url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ捫")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ捬"),url,l11ll1_l1_ (u"ࠨࠩ捭"),l11ll1_l1_ (u"ࠩࠪ据"),l11ll1_l1_ (u"ࠪࠫ捯"),l11ll1_l1_ (u"ࠫࠬ捰"),l11ll1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ捱"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ捲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ捳"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ捴"))
				name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ捵"))
				title = title+l11ll1_l1_ (u"ࠪࠤ࠭࠭捶")+name+l11ll1_l1_ (u"ࠫ࠮࠭捷")
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ捸"),l111l1_l1_+title,l1lllll_l1_,313,l1lll1_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠬ捹"),block,re.DOTALL)
			for l1lllll_l1_,title,name in items:
				title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ捺"))
				name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ捻"))
				title = title+l11ll1_l1_ (u"ࠩࠣࠬࠬ捼")+name+l11ll1_l1_ (u"ࠪ࠭ࠬ捽")
				addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ捾"),l111l1_l1_+title,l1lllll_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ捿")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡔࡊࡗࡣࠬ掀")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ掁"),l11ll1_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ掂"),l11ll1_l1_ (u"ࠩฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬ掃")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l11111_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l1llll1_l1_(url,text)
	elif mode==644: results = l1l111_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ掄"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ掅"),l11ll1_l1_ (u"ࠬ࠭掆"),l11ll1_l1_ (u"࠭ࠧ掇"),l11ll1_l1_ (u"ࠧࠨ授"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ掉"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掊"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ掋"),l11ll1_l1_ (u"ࠫࠬ掌"),649,l11ll1_l1_ (u"ࠬ࠭掍"),l11ll1_l1_ (u"࠭ࠧ掎"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ掏"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭掐"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ掑"),l11ll1_l1_ (u"ࠪࠫ排"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ掓"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ掔")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧ掕"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠧࠨ掖"),l11ll1_l1_ (u"ࠨࠩ掗"),l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ掘"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ掙"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭掚")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้๋่ใ฻ࠪ掛"),l11l1l_l1_,641,l11ll1_l1_ (u"࠭ࠧ掜"),l11ll1_l1_ (u"ࠧࠨ掝"),l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ掞"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ掟"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ掠")+l111l1_l1_+l11ll1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪ採"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠬ࠭探"),l11ll1_l1_ (u"࠭ࠧ掣"),l11ll1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ掤"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ接"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ掦")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧ控"),l11l1l_l1_,641,l11ll1_l1_ (u"ࠫࠬ推"),l11ll1_l1_ (u"ࠬ࠭掩"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ措"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ掫"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ掬"),l11ll1_l1_ (u"ࠩࠪ掭"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ掮"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ掯"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ掰"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ掱")+l111l1_l1_+title,l1lllll_l1_,644)
	#addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ掲"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ掳"),l11ll1_l1_ (u"ࠩࠪ掴"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ掵"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ掶"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠬ࠭掷"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ掸"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ掹"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ掺")+l111l1_l1_+title,l1lllll_l1_,644)
	return
def l1l111_l1_(url):
	l1111l1ll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭掻"),url,l11ll1_l1_ (u"ࠪࠫ掼"),l11ll1_l1_ (u"ࠫࠬ掽"),l11ll1_l1_ (u"ࠬ࠭掾"),l11ll1_l1_ (u"࠭ࠧ掿"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ揀"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ揁"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪ揂"),l11ll1_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ揃"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ揄"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠬ࠭揅"),block)]
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ揆"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ揇"),l11ll1_l1_ (u"ࠨࠩ揈"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			l1111l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ揉"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭揊")
			for l1lllll_l1_,title in l1111l1ll_l1_:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ揋"),l111l1_l1_+title,l1lllll_l1_,641)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ揌"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ揍"),block,re.DOTALL)
		if len(l1l1l1l_l1_)<30:
			if l1111l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ揎"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ描"),l11ll1_l1_ (u"ࠩࠪ提"),9999)
			for l1lllll_l1_,title in l1l1l1l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ揑"),l111l1_l1_+title,l1lllll_l1_,641)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠫࠬ插")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭揓"),l11ll1_l1_ (u"࠭ࠧ揔"),request,url)
	if request==l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ揕"):
		url,search = url.split(l11ll1_l1_ (u"ࠨࡁࠪ揖"),1)
		data = l11ll1_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ揗")+search
		headers = {l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ揘"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ揙")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ揚"),url,data,headers,l11ll1_l1_ (u"࠭ࠧ換"),l11ll1_l1_ (u"ࠧࠨ揜"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ揝"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭揞"),url,l11ll1_l1_ (u"ࠪࠫ揟"),l11ll1_l1_ (u"ࠫࠬ揠"),l11ll1_l1_ (u"ࠬ࠭握"),l11ll1_l1_ (u"࠭ࠧ揢"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ揣"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠨࠩ揤"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭揥"))
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ揦"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭揧"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠬ࠭揨"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ揩"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ揪"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ揫"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ揬"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ揭"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ揮"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ揯"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ揰"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ揱"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩ揲"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ揳"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ援"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ揵"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ揶"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ揷"),l11ll1_l1_ (u"ࠧไๆํฬࠬ揸"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧ揹"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧ揺"),l11ll1_l1_ (u"้ࠪออัศหࠪ揻"),l11ll1_l1_ (u"ࠫ฾ืึࠨ揼"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬ揽"),l11ll1_l1_ (u"࠭วๅส๋้ࠬ揾"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧ揿")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ搀"))
		#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ搁") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ搂")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭搃"))
		#if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ搄") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ搅")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ搆"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ搇"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ搈"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ搉"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ搊"):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ搋"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ搌") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ損"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
				l11l_l1_.append(title)
		#elif l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭搎") in l1lllll_l1_:
		#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ搏"),l111l1_l1_+title,l1lllll_l1_,641,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ搐"),l111l1_l1_+title,l1lllll_l1_,643,l1lll1_l1_)
	if 1: #if request not in [l11ll1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ搑"),l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ搒")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ搓"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ搔"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ搕"): continue
				if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ搖") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ搗")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭搘"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ搙"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ搚")+title,l1lllll_l1_,641)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ搛"),l11ll1_l1_ (u"ࠨࠩ搜"),l1l1l_l1_,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭搝"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ搞"),url,l11ll1_l1_ (u"ࠫࠬ搟"),l11ll1_l1_ (u"ࠬ࠭搠"),l11ll1_l1_ (u"࠭ࠧ搡"),l11ll1_l1_ (u"ࠧࠨ搢"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ搣"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ搤"),html,re.DOTALL)
	l111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ搥"),html,re.DOTALL)
	if l111_l1_: l1lll1_l1_ = l111_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠫࠬ搦")
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ搧"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"࠭ࠣࠨ搨"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ搩"),l111l1_l1_+title,url,643,l1lll1_l1_,l11ll1_l1_ (u"ࠨࠩ搪"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ搫")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ搬"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭搭"),block,re.DOTALL)
		items = []
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l1lllll_l1_,title,l1lll1_l1_))
		#if not items: items = re.findall(l11ll1_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ搮"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ搯") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ搰")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ搱"))
			title = title.replace(l11ll1_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀ࠿ࡩࡲࡄࠧ搲"),l11ll1_l1_ (u"ࠪࠤࠬ搳"))
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ搴"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
		#else:
		#	items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭搵"),block,re.DOTALL)
		#	for l1lllll_l1_,title,l1lll1_l1_ in items:
		#		if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫ搶") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ搷")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ搸"))
		#		addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ搹"),l111l1_l1_+title,l1lllll_l1_,642,l1lll1_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l11l11l_l1_,l1llll11_l1_ = [],[],[]
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ携"),l11ll1_l1_ (u"ࠫ࠴ࡼࡩࡦࡹ࠱ࡴ࡭ࡶࠧ搻"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ搼"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ搽"),l11ll1_l1_ (u"ࠧࠨ搾"),l11ll1_l1_ (u"ࠨࠩ搿"),l11ll1_l1_ (u"ࠩࠪ摀"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ摁"))
	html = response.content
	# l1l111l1l_l1_ l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡨࡪࡪ࠭ࡷ࡫ࡧࡩࡴࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ摂"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ摃"),block,re.DOTALL)
		if l1l1_l1_:
			l1lllll_l1_ = l1l1_l1_[0]
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ摄"))
				l1llll_l1_.append(l1lllll_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ摅"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨ摆"),block,re.DOTALL)
		block = block.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠧ࠭摇"),l11ll1_l1_ (u"ࠪࠦࠬ摈")).replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ摉"),l11ll1_l1_ (u"ࠬ࠵ࠧ摊"))
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࠽࡫ࡩࡶࡦࡳࡥ࠯ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭摋"),block,re.DOTALL)
		if len(l11111l11_l1_)==len(l1l1_l1_):
			for id,title in l11111l11_l1_:
				l1lllll_l1_ = l1l1_l1_[int(id)]
				if l1lllll_l1_ not in l1llll_l1_:
					l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ摌")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ摍"))
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ摎"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ摏"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1llll_l1_:
				l1l11l11l_l1_.append(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ摐")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ摑"))
				l1llll_l1_.append(l1lllll_l1_)
	l1111l_l1_ = zip(l1llll_l1_,l1l11l11l_l1_)
	for l1lllll_l1_,name in l1111l_l1_: l1llll11_l1_.append(l1lllll_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ摒"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭摓"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ摔"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ摕"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ摖"),l11ll1_l1_ (u"ࠫ࠰࠭摗"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭摘")+search
	l11111_l1_(url,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭摙"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫ摚")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭摛"))
	return
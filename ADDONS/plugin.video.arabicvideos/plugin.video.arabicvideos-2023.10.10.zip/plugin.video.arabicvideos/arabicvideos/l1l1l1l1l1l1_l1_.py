# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗࠬ侈")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡌࡔࡖࡢࠫ侉")
l11l1lllll1l_l1_ = 5
l11l1lll111l_l1_ = 10
def MAIN(mode,url,text,l1l1111_l1_,l1ll1ll1l11_l1_):
	try: l1lll111l11l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侊")])
	except: l1lll111l11l_l1_ = l11ll1_l1_ (u"ࠧࠨ例")
	if   mode==160: results = MENU()
	elif mode==161: results = l11ll111l1l1_l1_(text)
	elif mode==162: results = l11l1ll11l1l_l1_(text,162)
	elif mode==163: results = l11l1ll11l1l_l1_(text,163)
	elif mode==164: results = l11ll111l111_l1_(text)
	elif mode==165: results = l11l1lllll11_l1_(l1lll111l11l_l1_,text,l1l1111_l1_)
	elif mode==166: results = l11ll111111l_l1_(url,text)
	elif mode==167: results = l11l1l1ll1ll_l1_(url,text)
	elif mode==168: results = l11l1l1l1111_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侌"),l11ll1_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪ侍"),l11ll1_l1_ (u"ࠪࠫ侎"),161,l11ll1_l1_ (u"ࠫࠬ侏"),l11ll1_l1_ (u"ࠬ࠭侐"),l11ll1_l1_ (u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ侑"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侒"),l11ll1_l1_ (u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ侓"),l11ll1_l1_ (u"ࠩࠪ侔"),162,l11ll1_l1_ (u"ࠪࠫ侕"),l11ll1_l1_ (u"ࠫࠬ侖"),l11ll1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ侗"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侘"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋หࠪ侙"),l11ll1_l1_ (u"ࠨࠩ侚"),163,l11ll1_l1_ (u"ࠩࠪ供"),l11ll1_l1_ (u"ࠪࠫ侜"),l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ依"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侞"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎ࠬ侟"),l11ll1_l1_ (u"ࠧࠨ侠"),164,l11ll1_l1_ (u"ࠨࠩ価"),l11ll1_l1_ (u"ࠩࠪ侢"),l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ侣"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侤"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ侥"),l11ll1_l1_ (u"࠭ࠧ侦"),165,l11ll1_l1_ (u"ࠧࠨ侧"),l11ll1_l1_ (u"ࠨࠩ侨"),l11ll1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫ侩"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ侪"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ侫"),l11ll1_l1_ (u"ࠬ࠭侬"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侭"),l11ll1_l1_ (u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ侮"),l11ll1_l1_ (u"ࠨࠩ侯"),163,l11ll1_l1_ (u"ࠩࠪ侰"),l11ll1_l1_ (u"ࠪࠫ侱"),l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭侲"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侳"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ࠭侴"),l11ll1_l1_ (u"ࠧࠨ侵"),163,l11ll1_l1_ (u"ࠨࠩ侶"),l11ll1_l1_ (u"ࠩࠪ侷"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ侸"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侹"),l11ll1_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬ侺"),l11ll1_l1_ (u"࠭ࠧ侻"),162,l11ll1_l1_ (u"ࠧࠨ侼"),l11ll1_l1_ (u"ࠨࠩ侽"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ侾"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ便"),l11ll1_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ俀"),l11ll1_l1_ (u"ࠬ࠭俁"),162,l11ll1_l1_ (u"࠭ࠧ係"),l11ll1_l1_ (u"ࠧࠨ促"),l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俄"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俅"),l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭俆"),l11ll1_l1_ (u"ࠫࠬ俇"),164,l11ll1_l1_ (u"ࠬ࠭俈"),l11ll1_l1_ (u"࠭ࠧ俉"),l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ俊"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俋"),l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ俌"),l11ll1_l1_ (u"ࠪࠫ俍"),165,l11ll1_l1_ (u"ࠫࠬ俎"),l11ll1_l1_ (u"ࠬ࠭俏"),l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ俐"))
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ俑"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ俒"),l11ll1_l1_ (u"ࠩࠪ俓"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俔"),l11ll1_l1_ (u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ俕"),l11ll1_l1_ (u"ࠬ࠭俖"),163,l11ll1_l1_ (u"࠭ࠧ俗"),l11ll1_l1_ (u"ࠧࠨ俘"),l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俙"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俚"),l11ll1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫ俛"),l11ll1_l1_ (u"ࠫࠬ俜"),163,l11ll1_l1_ (u"ࠬ࠭保"),l11ll1_l1_ (u"࠭ࠧ俞"),l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ俟"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ俠"),l11ll1_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ信"),l11ll1_l1_ (u"ࠪࠫ俢"),162,l11ll1_l1_ (u"ࠫࠬ俣"),l11ll1_l1_ (u"ࠬ࠭俤"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俥"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ俦"),l11ll1_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ俧"),l11ll1_l1_ (u"ࠩࠪ俨"),162,l11ll1_l1_ (u"ࠪࠫ俩"),l11ll1_l1_ (u"ࠫࠬ俪"),l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俫"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俬"),l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠠษฯฮࠤ฾ฺ่ศศํࠫ俭"),l11ll1_l1_ (u"ࠨࠩ修"),164,l11ll1_l1_ (u"ࠩࠪ俯"),l11ll1_l1_ (u"ࠪࠫ俰"),l11ll1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俱"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俲"),l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ俳"),l11ll1_l1_ (u"ࠧࠨ俴"),165,l11ll1_l1_ (u"ࠨࠩ俵"),l11ll1_l1_ (u"ࠩࠪ俶"),l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ俷"))
	return
def l11ll111l1l1_l1_(options):
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ俸"),l11ll1_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไ้์ฬะฺࠠึ๋หห๐ษࠨ俹"),l11ll1_l1_ (u"࠭ࠧ俺"),161,l11ll1_l1_ (u"ࠧࠨ俻"),l11ll1_l1_ (u"ࠨࠩ俼"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ俽"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ俾"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ俿"),l11ll1_l1_ (u"ࠬ࠭倀"),9999)
	l1l1ll11l111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭倁"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣ࡝࡚࡚ࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ倂")+l11ll1_l1_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ倃"),l11ll1_l1_ (u"ࠩࠪ倄"),147)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倅"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࡚ࠠࡗࡗࠤ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ倆")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ倇"),l11ll1_l1_ (u"࠭ࠧ倈"),148)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ倉"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡎࡌࡌࠡࠢࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倊")+l11ll1_l1_ (u"ࠩๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ็้ࠤ๊๎โฺ้่ࠫ個"),l11ll1_l1_ (u"ࠪࠫ倌"),28)
	#addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ倍"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡࡏࡕࡊ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ倎")+l11ll1_l1_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ倏"),l11ll1_l1_ (u"ࠧࠨ倐"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭們"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡑࡗࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ倒")+l11ll1_l1_ (u"ࠪๆ๋อษࠡษ็็ํััࠡ็้ࠤ๊๎โฺ้่ࠫ倓"),l11ll1_l1_ (u"ࠫࠬ倔"),135)
	import l1ll1l1l1l11_l1_
	l1ll1l1l1l11_l1_.ITEMS(l11ll1_l1_ (u"ࠬ࠶ࠧ倕"),False)
	l1ll1l1l1l11_l1_.ITEMS(l11ll1_l1_ (u"࠭࠱ࠨ倖"),False)
	l1ll1l1l1l11_l1_.ITEMS(l11ll1_l1_ (u"ࠧ࠳ࠩ倗"),False)
	#l1ll1l1l1l11_l1_.ITEMS(l11ll1_l1_ (u"ࠨ࠵ࠪ倘"),False)
	if l11ll1_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ候") in options:
		menuItemsLIST[:] = l11l1ll1l111_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11l1lllll1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1lllll1l_l1_)
	menuItemsLIST[:] = l1l1ll11l111_l1_+menuItemsLIST
	return
def l11ll111l111_l1_(options):
	options = options.replace(l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倚"),l11ll1_l1_ (u"ࠫࠬ倛")).replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ倜"),l11ll1_l1_ (u"࠭ࠧ倝"))
	headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ倞") : l11ll1_l1_ (u"ࠨࠩ借") }
	url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨ倠")
	payload = { l11ll1_l1_ (u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬ倡") : l11ll1_l1_ (u"ࠫ࠺࠶ࠧ倢") }
	data = l1ll1l11l_l1_(payload)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭倣"),l11ll1_l1_ (u"࠭ࠧ値"),l11ll1_l1_ (u"ࠧࠨ倥"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ倦"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ倧"),l11ll1_l1_ (u"ࠪࠫ倨"),l11ll1_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭倩"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧ倪"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ倫"),block,re.DOTALL)
	l11l1l11ll1l_l1_,l11l1l1ll11l_l1_ = list(zip(*items))
	l11ll11111ll_l1_ = []
	l11ll1111lll_l1_ = [l11ll1_l1_ (u"ࠧࠡࠩ倬"),l11ll1_l1_ (u"ࠨࠤࠪ倭"),l11ll1_l1_ (u"ࠩࡣࠫ倮"),l11ll1_l1_ (u"ࠪ࠰ࠬ倯"),l11ll1_l1_ (u"ࠫ࠳࠭倰"),l11ll1_l1_ (u"ࠬࡀࠧ倱"),l11ll1_l1_ (u"࠭࠻ࠨ倲"),l11ll1_l1_ (u"ࠢࠨࠤ倳"),l11ll1_l1_ (u"ࠨ࠯ࠪ倴")]
	l11l1llll1l1_l1_ = l11l1l1ll11l_l1_+l11l1l11ll1l_l1_
	for word in l11l1llll1l1_l1_:
		if word in l11l1l1ll11l_l1_: l11l1lll1l11_l1_ = 2
		if word in l11l1l11ll1l_l1_: l11l1lll1l11_l1_ = 4
		l11ll1111l11_l1_ = [i in word for i in l11ll1111lll_l1_]
		if any(l11ll1111l11_l1_):
			index = l11ll1111l11_l1_.index(True)
			l11l1l1llll1_l1_ = l11ll1111lll_l1_[index]
			l11l1lllllll_l1_ = l11ll1_l1_ (u"ࠩࠪ倵")
			if word.count(l11l1l1llll1_l1_)>1: l11ll1111111_l1_,l11l1llllll1_l1_,l11l1lllllll_l1_ = word.split(l11l1l1llll1_l1_,2)
			else: l11ll1111111_l1_,l11l1llllll1_l1_ = word.split(l11l1l1llll1_l1_,1)
			if len(l11ll1111111_l1_)>l11l1lll1l11_l1_: l11ll11111ll_l1_.append(l11ll1111111_l1_.lower())
			if len(l11l1llllll1_l1_)>l11l1lll1l11_l1_: l11ll11111ll_l1_.append(l11l1llllll1_l1_.lower())
			if len(l11l1lllllll_l1_)>l11l1lll1l11_l1_: l11ll11111ll_l1_.append(l11l1lllllll_l1_.lower())
		elif len(word)>l11l1lll1l11_l1_: l11ll11111ll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11ll11111ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll11111ll_l1_)),l11ll11111ll_l1_)
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉ࡭࡫ࡶࡸࠥࡃࠠ࡜ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢ฼ีอ๐ษࠨ࠮ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣษ๋้ไ๋ิํอࠬࡣࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦใๅ็ฬࠤ้๊ศฮอࠣ฽๋ํว࠻ࠩ࠯ࠤࡱ࡯ࡳࡵ࠴ࠬࠎࠎࡲࡩࡴࡶ࠴ࠤࡂ࡛ࠦ࡞ࠌࠌࡧࡴࡻ࡮ࡵࡵࠣࡁࠥࡲࡥ࡯ࠪ࡯࡭ࡸࡺ࠲ࠪࠌࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡨࡵࡵ࡯ࡶࡶ࠮࠺࠯࠺ࠡࡴࡤࡲࡩࡵ࡭࠯ࡵ࡫ࡹ࡫࡬࡬ࡦࠪ࡯࡭ࡸࡺ࠲ࠪࠌࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡱ࡫࡮ࡨࡶ࡫࠭࠿ࠦ࡬ࡪࡵࡷ࠵࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ใๅ็ฬࠤ฾ฺ่ศศํอࠥืโๆࠢࠪ࠯ࡸࡺࡲࠩ࡫ࠬ࠭ࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠎࠎࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊ไ฻ห࠽ࠫ࠱ࠦ࡬ࡪࡵࡷ࠭ࠏࠏࠉࠤ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࠋࠦࡩࡱ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࡁࡂ࠶࠺ࠡ࡮࡬ࡷࡹ࠸ࠠ࠾ࠢࡤࡶࡧࡒࡉࡔࡖࠍࠍࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡲࡩࡴࡶ࠵ࠤࡂࠦࡥ࡯ࡩࡏࡍࡘ࡚ࠊࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦใๅ็ฬࠤ้๊ศฮอࠣ฽๋ํว࠻ࠩ࠯ࠤࡱ࡯ࡳࡵ࠳ࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࠧ࠽ࠡ࠯࠴࠾ࠥࡨࡲࡦࡣ࡮ࠎࠎࠏࡥ࡭࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࡵࡨࡥࡷࡩࡨࠡ࠿ࠣࡰ࡮ࡹࡴ࠳࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࠣࠤࠥ倶")
	if l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ倷") in options:
		l11l1ll1ll11_l1_ = l1l1llll1ll1_l1_
	elif l11ll1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ倸") in options:
		l11l1ll1ll11_l1_ = [l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ倹")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠧࠨ债"),True): return
	elif l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ倻") in options:
		l11l1ll1ll11_l1_ = [l11ll1_l1_ (u"ࠩࡐ࠷࡚࠭值")]
		import l1l1l1111lll_l1_
		if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠪࠫ倽"),True): return
	count,l11l1l11lll1_l1_ = 0,0
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ倾"),l11ll1_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠ࠻ࠢ࡞ࠤࠥࡣࠧ倿"),l11ll1_l1_ (u"࠭ࠧ偀"),164,l11ll1_l1_ (u"ࠧࠨ偁"),l11ll1_l1_ (u"ࠨࠩ偂"),l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ偃")+options)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ偄"),l11ll1_l1_ (u"ࠫส฿วะหࠣห้ฮอฬࠢส่฾ฺ่ศศํࠫ偅"),l11ll1_l1_ (u"ࠬ࠭偆"),164,l11ll1_l1_ (u"࠭ࠧ假"),l11ll1_l1_ (u"ࠧࠨ偈"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭偉")+options)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ偊"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ偋"),l11ll1_l1_ (u"ࠫࠬ偌"),9999)
	l11l1l11ll11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11ll1111ll1_l1_ = []
	for word in l11ll11111ll_l1_:
		l11l1llllll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡡࠠ࡝࠮࡟࠿ࡡࡀ࡜࠮࡞࠮ࡠࡂࡢࠢ࡝ࠩ࡟࡟ࡡࡣ࡜ࠩ࡞ࠬࡠࢀࡢࡽ࡝ࠣ࡟ࡄࡡࠩ࡜ࠥ࡞ࠨࡠࡣࡢࠦ࡝ࠬ࡟ࡣࡡࡂ࡜࠿࡟ࠪ偍"),word,re.DOTALL)
		if l11l1llllll1_l1_: word = word.split(l11l1llllll1_l1_[0],1)[0]
		l11l1llll11l_l1_ = word.replace(l11ll1_l1_ (u"࠭๑ࠨ偎"),l11ll1_l1_ (u"ࠧࠨ偏")).replace(l11ll1_l1_ (u"ࠨ๐ࠪ偐"),l11ll1_l1_ (u"ࠩࠪ偑")).replace(l11ll1_l1_ (u"ࠪ๏ࠬ偒"),l11ll1_l1_ (u"ࠫࠬ偓")).replace(l11ll1_l1_ (u"ࠬ๕ࠧ偔"),l11ll1_l1_ (u"࠭ࠧ偕")).replace(l11ll1_l1_ (u"ࠧํࠩ偖"),l11ll1_l1_ (u"ࠨࠩ偗"))
		l11l1llll11l_l1_ = l11l1llll11l_l1_.replace(l11ll1_l1_ (u"ࠩ๓ࠫ偘"),l11ll1_l1_ (u"ࠪࠫ偙")).replace(l11ll1_l1_ (u"ࠫ๒࠭做"),l11ll1_l1_ (u"ࠬ࠭偛")).replace(l11ll1_l1_ (u"࠭๒ࠨ停"),l11ll1_l1_ (u"ࠧࠨ偝")).replace(l11ll1_l1_ (u"ࠨฎࠪ偞"),l11ll1_l1_ (u"ࠩࠪ偟")).replace(l11ll1_l1_ (u"ࠪไࠬ偠"),l11ll1_l1_ (u"ࠫࠬ偡"))
		if l11l1llll11l_l1_: l11ll1111ll1_l1_.append(l11l1llll11l_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11ll1111ll1_l1_)),l11ll1111ll1_l1_)
	l11l1lll1lll_l1_ = []
	for l11ll11111_l1_ in range(0,20):
		search = random.sample(l11ll1111ll1_l1_,1)[0]
		if search in l11l1lll1lll_l1_: continue
		l11l1lll1lll_l1_.append(search)
		l1ll111l111_l1_ = random.sample(l11l1ll1ll11_l1_,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ偢"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩ偣")+str(l1ll111l111_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪ偤")+search)
		#results = l1l1ll11lll1_l1_(l11ll1_l1_ (u"ࠨࠩ健"),l11ll1_l1_ (u"ࠩࠪ偦"),l11ll1_l1_ (u"ࠪࠫ偧"),l1ll111l111_l1_,l11ll1_l1_ (u"ࠫࠬ偨"),l11ll1_l1_ (u"ࠬ࠭偩"),search+l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ偪"),l11ll1_l1_ (u"ࠧࠨ偫"),l11ll1_l1_ (u"ࠨࠩ偬"))
		l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
		l1ll1111lll_l1_(search+l11ll1_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ偭"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ偮"),l11ll1_l1_ (u"ࠫࠬ偯"))
	l11l1l11ll11_l1_[0][1] = l11ll1_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ偰")+search+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ฬาัฺ่ࠠࠣ࠾ࠥࡡࠠࠨ偱")
	menuItemsLIST[:] = l11l1ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11l1lllll1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1lllll1l_l1_)
	menuItemsLIST[:] = l11l1l11ll11_l1_+menuItemsLIST
	#import l1lll11ll1l_l1_
	#l1lll11ll1l_l1_.SEARCH(search)
	return
def l11ll1111l1l_l1_(l1ll111l111_l1_):
	l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
	try:
		if l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭偲") in l1ll111l111_l1_: l1l1lllllll_l1_(l1ll111l111_l1_)
		else: l1l1lllllll_l1_()
		l11l1lll1ll1_l1_ = False
	except: l11l1lll1ll1_l1_ = True
	l1ll111l111_l1_ = TRANSLATE(l1ll111l111_l1_)
	if l11l1lll1ll1_l1_: DIALOG_NOTIFICATION(l1ll111l111_l1_,l11ll1_l1_ (u"ࠨใื่ࠥฮ็ัษࠣห้๋่ใ฻ࠪ偳"),time=2000)
	else: DIALOG_NOTIFICATION(l1ll111l111_l1_,l11ll1_l1_ (u"ࠩอ้ࠥาไษࠢส่ศ่ำศ็ࠪ側"),time=2000)
	return l11l1lll1ll1_l1_
def l11l1l1l11ll_l1_(l11l1lll11l1_l1_=True):
	if not l11l1lll11l1_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ偵"),l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ偶"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭偷"))
		if results:
			contentsDICT = results
			return
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭偸"),l11ll1_l1_ (u"ࠧࠨ偹"),l11ll1_l1_ (u"ࠨࠩ偺"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ偻"),l11ll1_l1_ (u"่่ࠪ๐ࠠห็็สࠥํะ่ࠢส่็อฦๆหࠣ࠲ࠥอไษำ้ห๊า๋ࠠฯอหัࠦร็ࠢํๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์ࠥอไห์ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐ำหะิะ๋ࠥๆ่ษࠣๅ็฽ࠠศๆฦๆุอๅࠡษ็ีห๐ำ๋หࠣ࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰ࠣ฽๊๊๊ส่่ࠢหࠦฬๆ์฼ࠤฬ๊รใีส้ࠥะอหษฯࠤ฾อฯสࠢฦๆ้ࠦๅ็ࠢ࠶ࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠศๆล๊ࠥลࠧ偼"))
	if l1ll111ll1_l1_!=1: return
	l11l1l1l1l1l_l1_ = menuItemsLIST[:]
	l11l1ll1l1ll_l1_,l11l1ll1l11l_l1_ = 0,l11ll1_l1_ (u"ࠫࠬ偽")
	for l1ll111l111_l1_ in l11ll1l1lll_l1_:
		l11l1lll1ll1_l1_ = l11ll1111l1l_l1_(l1ll111l111_l1_)
		if l11l1lll1ll1_l1_:
			l11l1ll1l1ll_l1_ += 1
			l11l1ll1l11l_l1_ += l11ll1_l1_ (u"ࠬࠦࠧ偾")+l1ll111l111_l1_
			if l11l1ll1l1ll_l1_>=l11l1lll111l_l1_: break
	menuItemsLIST[:] = l11l1l1l1l1l_l1_
	if l11l1ll1l1ll_l1_>=l11l1lll111l_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ偿"),l11ll1_l1_ (u"ࠧࠨ傀"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ傁"),l11ll1_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ傂")+str(l11l1ll1l1ll_l1_)+l11ll1_l1_ (u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ傃")+l11l1ll1l11l_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ傄"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭傅"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ傆"),l11ll1_l1_ (u"ࠧࠨ傇"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ傈"),l11ll1_l1_ (u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ傉"))
	return
def l11l1ll111ll_l1_(l1lll111l11l_l1_,options):
	if l11ll1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ傊") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ傋"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ傌"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ傍")+l1lll111l11l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ傎")
	import IPTV
	if l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ傏") in options and l11ll1_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ傐") not in options:
		try: IPTV.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ傑"),l11ll1_l1_ (u"ࠫࠬ傒"),l11ll1_l1_ (u"ࠬ࠭傓"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ傔"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ傕"),l11ll1_l1_ (u"ࠨࠩ傖"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ傗"),message)
		try: IPTV.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ傘"),l11ll1_l1_ (u"ࠫࠬ備"),l11ll1_l1_ (u"ࠬ࠭傚"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ傛"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ傜"),l11ll1_l1_ (u"ࠨࠩ傝"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ傞"),message)
		try: IPTV.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ傟"),l11ll1_l1_ (u"ࠫࠬ傠"),l11ll1_l1_ (u"ࠬ࠭傡"),options+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ傢"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ傣"),l11ll1_l1_ (u"ࠨࠩ傤"),l11ll1_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ傥"),message)
	if l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ傦") in options and l11ll1_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ傧") not in options:
		try: IPTV.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ储"),l11ll1_l1_ (u"࠭ࠧ傩"),l11ll1_l1_ (u"ࠧࠨ傪"),options+l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭傫"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ催"),l11ll1_l1_ (u"ࠪࠫ傭"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ傮"),message)
		try: IPTV.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ傯"),l11ll1_l1_ (u"࠭ࠧ傰"),l11ll1_l1_ (u"ࠧࠨ傱"),options+l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭傲"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ傳"),l11ll1_l1_ (u"ࠪࠫ傴"),l11ll1_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ債"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ傶"),l11ll1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ傷")+l1lll111l11l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11l1ll1llll_l1_(l1lll111l11l_l1_,options):
	if l11ll1_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ傸") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭傹"),l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ傺"),l11ll1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ傻")+l1lll111l11l_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11ll1_l1_ (u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ傼")
	import l1l1l1111lll_l1_
	if l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ傽") in options and l11ll1_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭傾") not in options:
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭傿"),l11ll1_l1_ (u"ࠨࠩ僀"),l11ll1_l1_ (u"ࠩࠪ僁"),options+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僂"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ僃"),l11ll1_l1_ (u"ࠬ࠭僄"),l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭僅"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ僆"),l11ll1_l1_ (u"ࠨࠩ僇"),l11ll1_l1_ (u"ࠩࠪ僈"),options+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僉"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ僊"),l11ll1_l1_ (u"ࠬ࠭僋"),l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭僌"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ働"),l11ll1_l1_ (u"ࠨࠩ僎"),l11ll1_l1_ (u"ࠩࠪ像"),options+l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僐"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ僑"),l11ll1_l1_ (u"ࠬ࠭僒"),l11ll1_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭僓"),message)
	if l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭僔") in options and l11ll1_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ僕") not in options:
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ僖"),l11ll1_l1_ (u"ࠪࠫ僗"),l11ll1_l1_ (u"ࠫࠬ僘"),options+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ僙"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ僚"),l11ll1_l1_ (u"ࠧࠨ僛"),l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ僜"),message)
		try: l1l1l1111lll_l1_.GROUPS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ僝"),l11ll1_l1_ (u"ࠪࠫ僞"),l11ll1_l1_ (u"ࠫࠬ僟"),options+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ僠"),False)
		except: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ僡"),l11ll1_l1_ (u"ࠧࠨ僢"),l11ll1_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ僣"),message)
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ僤"),l11ll1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ僥")+l1lll111l11l_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l11l1lllll11_l1_(l1lll111l11l_l1_,options,l11l1l1lll1l_l1_):
	if l11ll1_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ僦") in options:
		if l11ll1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ僧") in options and l11l1l1lll1l_l1_==l11ll1_l1_ (u"࠭ࠧ僨"): l11l1l1l11ll_l1_(True)
		elif l11l1l1lll1l_l1_: l11l1l1l11ll_l1_(False)
		#if contentsDICT=={}: return
	l11l1lll11ll_l1_ = options.replace(l11ll1_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ僩"),l11ll1_l1_ (u"ࠨࠩ僪")).replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ僫"),l11ll1_l1_ (u"ࠪࠫ僬")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ僭"),l11ll1_l1_ (u"ࠬ࠭僮"))
	if not l11l1l1lll1l_l1_:
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ僯"),l11ll1_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ僰"),l11ll1_l1_ (u"ࠨࠩ僱"),165,l11ll1_l1_ (u"ࠩࠪ僲"),l11ll1_l1_ (u"ࠪࠫ僳"),l11ll1_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ僴")+l11l1lll11ll_l1_,l11ll1_l1_ (u"ࠬ࠭僵"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僶"):l1lll111l11l_l1_})
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ僷"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ僸"),l11ll1_l1_ (u"ࠩࠪ價"),9999)
	if l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ僺") in options:
		l1ll1l1111_l1_ = [l11ll1_l1_ (u"ࠫศ็ไศ็ࠪ僻"),l11ll1_l1_ (u"๋ࠬำๅี็หฯ࠭僼"),l11ll1_l1_ (u"࠭ๅิำะ๎ฬะࠧ僽"),l11ll1_l1_ (u"ࠧษำส้ั࠭僾"),l11ll1_l1_ (u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧ僿"),l11ll1_l1_ (u"ࠩิ้฻อๆࠨ儀"),l11ll1_l1_ (u"ࠪวาีห࠮ลัีࠬ儁"),l11ll1_l1_ (u"ุ๊ࠫวิๆࠪ儂"),l11ll1_l1_ (u"๋่ࠬิ์ๅํࠬ儃"),l11ll1_l1_ (u"࠭รี้ิ࠱ศ้หาࠩ億"),l11ll1_l1_ (u"ࠧศๆล๊ࠬ儅"),l11ll1_l1_ (u"ࠨุะ็ࠬ儆"),l11ll1_l1_ (u"ࠩิ๎ฬ฼ษࠨ儇"),l11ll1_l1_ (u"๊ࠪ๏ะแๅๅึࠫ儈"),l11ll1_l1_ (u"๊๋ࠫหๅ์้ࠫ儉"),l11ll1_l1_ (u"ࠬฮหࠡฯํࠫ儊"),l11ll1_l1_ (u"࠭ฯ๋่ํอࠬ儋"),l11ll1_l1_ (u"ࠧิ่๋หฯ࠭儌"),l11ll1_l1_ (u"ࠨลัี๎࠭儍")]
		l11l1l1l1ll1_l1_ = [l11ll1_l1_ (u"ࠩสๅ้อๅࠨ儎"),l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ儏"),l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ儐"),l11ll1_l1_ (u"ࠬ็ไๆࠩ儑")]
		l11l1ll11111_l1_ = [l11ll1_l1_ (u"࠭ๅิๆึ่ࠬ儒"),l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ儓")]
		l11ll111l11l_l1_ = [l11ll1_l1_ (u"ࠨ็ึหึำࠧ儔"),l11ll1_l1_ (u"่ࠩืึำ๊ศฬࠪ儕")]
		l11l1l1lllll_l1_ = [l11ll1_l1_ (u"ࠪฬึอๅอࠩ儖"),l11ll1_l1_ (u"ࠫࡸ࡮࡯ࡸࠩ儗"),l11ll1_l1_ (u"ࠬะไโิํ์๋࠭儘"),l11ll1_l1_ (u"࠭สๅ์ไึ๏๎ๆࠨ儙")]
		l11l1llll111_l1_ = [l11ll1_l1_ (u"ࠧศ่่๎ࠬ儚"),l11ll1_l1_ (u"ࠨๅิฮํ์ࠧ儛"),l11ll1_l1_ (u"ࠩๆหึะ่็ࠩ儜"),l11ll1_l1_ (u"ࠪ࡯࡮ࡪࡳࠨ儝"),l11ll1_l1_ (u"ࠫ฼็ไࠨ儞"),l11ll1_l1_ (u"ࠬอืโษ็ࠫ償")]
		l1111ll1_l1_ = [l11ll1_l1_ (u"࠭ัๆุส๊ࠬ儠")]
		l1llll1ll_l1_ = [l11ll1_l1_ (u"ࠧศฯาฯࠬ儡"),l11ll1_l1_ (u"ࠨษัีࠬ儢"),l11ll1_l1_ (u"่ࠩ์ำืࠧ儣"),l11ll1_l1_ (u"ࠪะิ๐ฯࠨ儤"),l11ll1_l1_ (u"๊ࠫ฼วโࠩ儥"),l11ll1_l1_ (u"ࠬำฯ๋อࠪ儦")]
		l11l1ll11l11_l1_ = [l11ll1_l1_ (u"࠭ำๅษึ่ࠬ儧"),l11ll1_l1_ (u"ࠧิๆึ่์࠭儨")]
		l11l1l11llll_l1_ = [l11ll1_l1_ (u"ࠨษ฽ห๋๐ࠧ儩"),l11ll1_l1_ (u"่ࠩ์ุ๐โ๊ࠩ優"),l11ll1_l1_ (u"ࠪ็้๐ศࠨ儫"),l11ll1_l1_ (u"ࠫา็ไࠨ儬"),l11ll1_l1_ (u"ࠬࡳࡵࡴ࡫ࡦࠫ儭")]
		l111111l1_l1_ = [l11ll1_l1_ (u"࠭วไอิࠫ儮"),l11ll1_l1_ (u"ࠧศึ๊ีࠬ儯"),l11ll1_l1_ (u"ࠨ็่๎ืํࠧ儰"),l11ll1_l1_ (u"ࠩส฽้๏ࠧ儱"),l11ll1_l1_ (u"้ࠪำะวา้ࠪ儲"),l11ll1_l1_ (u"๊ࠫิสศำสฮࠬ儳"),l11ll1_l1_ (u"ࠬอโ้๋ࠪ儴")]
		l11l1l1l1l11_l1_ = [l11ll1_l1_ (u"࠭วๅษ้ࠫ儵"),l11ll1_l1_ (u"ࠧฮษ็๎ࠬ儶"),l11ll1_l1_ (u"ࠨ็ฮฬฯ࠭儷"),l11ll1_l1_ (u"ࠩิหหาࠧ儸")]
		l11l1l1l11l1_l1_ = [l11ll1_l1_ (u"ฺࠪา้ࠧ儹"),l11ll1_l1_ (u"่ࠫ๎ๅ๋ัํࠫ儺")]
		l11l1l1l1lll_l1_ = [l11ll1_l1_ (u"ࠬื๊ศุ๊ࠫ儻"),l11ll1_l1_ (u"࠭ใ้ำ๊ࠫ儼"),l11ll1_l1_ (u"ࠧๆืสี฾ํࠧ儽"),l11ll1_l1_ (u"ࠨึ๋ฮࠬ儾"),l11ll1_l1_ (u"ࠩิ๎ฬ฼ษࠨ儿")]
		l11l1lll1l1l_l1_ = [l11ll1_l1_ (u"๊ࠪ๏ะแๅๅึࠫ兀"),l11ll1_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬ允"),l11ll1_l1_ (u"ࠬ์๊หใ็๎ู่ࠧ兂")]
		l11l1ll1lll1_l1_ = [l11ll1_l1_ (u"࠭ๅๆอ็๎๋࠭元"),l11ll1_l1_ (u"ࠧศึัหฺ࠭兄"),l11ll1_l1_ (u"ࠨ่ฯ์๊࠭充")]
		l1l1ll1ll_l1_ = [l11ll1_l1_ (u"ࠩหฯࠥำ๊ࠨ兆"),l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ兇"),l11ll1_l1_ (u"ࠫ็์ว่ࠩ先"),l11ll1_l1_ (u"่ࠬๆ้ษอࠫ光")]
		l11l1lll1111_l1_ = [l11ll1_l1_ (u"࠭ฯ๋่ࠪ兊"),l11ll1_l1_ (u"ࠧศั฼๎์࠭克"),l11ll1_l1_ (u"ࠨิํหึอสࠨ兌"),l11ll1_l1_ (u"ࠩ็฻๊๐วหࠩ免"),l11ll1_l1_ (u"ࠪำ฾อมࠨ兎"),l11ll1_l1_ (u"ࠫ็ืว็ࠩ兏"),l11ll1_l1_ (u"่ࠬีศศาࠫ児"),l11ll1_l1_ (u"࠭ัฬษฤࠫ兑"),l11ll1_l1_ (u"ࠧๆำฯ฽๏ํࠧ兒"),l11ll1_l1_ (u"ࠨษำห๋࠭兓"),l11ll1_l1_ (u"ࠩสื้อๅࠨ兔"),l11ll1_l1_ (u"ࠪฮํอิ๋ฯࠪ兕"),l11ll1_l1_ (u"ࠫำ฽ศࠨ兖"),l11ll1_l1_ (u"ࠬำ่ำ๊ํࠫ兗"),l11ll1_l1_ (u"ู࠭หสสฮࠬ兘"),l11ll1_l1_ (u"ࠧๆ๊ส่๏ีࠧ兙"),l11ll1_l1_ (u"ࠨ่๋ห฾๐ࠧ党"),l11ll1_l1_ (u"ࠩ฼ๆฬฬฯࠨ兛"),l11ll1_l1_ (u"ࠪห๋อิ๋ัࠪ兜")]
		l11l1llll1ll_l1_ = [l11ll1_l1_ (u"ࠫ࠶࠿ࠧ兝"),l11ll1_l1_ (u"ࠬ࠸࠰ࠨ兞"),l11ll1_l1_ (u"࠭࠲࠲ࠩ兟"),l11ll1_l1_ (u"ࠧ࠳࠴ࠪ兠"),l11ll1_l1_ (u"ࠨ࠴࠶ࠫ兡"),l11ll1_l1_ (u"ࠩ࠵࠸ࠬ兢"),l11ll1_l1_ (u"ࠪ࠶࠺࠭兣"),l11ll1_l1_ (u"ࠫ࠷࠼ࠧ兤")]
		if not l11l1l1lll1l_l1_:
			l11l1l1lll1l_l1_ = 0
			for l11l1ll1ll1l_l1_ in l1ll1l1111_l1_:
				l11l1l1lll1l_l1_ += 1
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ入"),l111l1_l1_+l11l1ll1ll1l_l1_,l11ll1_l1_ (u"࠭ࠧ兦"),165,l11ll1_l1_ (u"ࠧࠨ內"),str(l11l1l1lll1l_l1_),l11l1lll11ll_l1_,l11ll1_l1_ (u"ࠨࠩ全"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ兩"):l1lll111l11l_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1lll1l1_l1_ = name.lower()
				category = []
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l1ll1_l1_): category.append(1)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll11111_l1_): category.append(2)
				if any(value in l1ll1lll1l1_l1_ for value in l11ll111l11l_l1_): category.append(3)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1lllll_l1_): category.append(4)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1llll111_l1_): category.append(5)
				if any(value in l1ll1lll1l1_l1_ for value in l1111ll1_l1_): category.append(6)
				if any(value in l1ll1lll1l1_l1_ for value in l1llll1ll_l1_) and l1ll1lll1l1_l1_ not in [l11ll1_l1_ (u"ࠪหำื้ࠨ兪")]: category.append(7)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll11l11_l1_): category.append(8)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l11llll_l1_): category.append(9)
				if any(value in l1ll1lll1l1_l1_ for value in l111111l1_l1_): category.append(10)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l1l11_l1_): category.append(11)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l11l1_l1_): category.append(12)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1l1l1lll_l1_): category.append(13)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll1l1l_l1_): category.append(14)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1ll1lll1_l1_): category.append(15)
				if any(value in l1ll1lll1l1_l1_ for value in l1l1ll1ll_l1_): category.append(16)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1lll1111_l1_): category.append(17)
				if any(value in l1ll1lll1l1_l1_ for value in l11l1llll1ll_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l11l1l1lll1l_l1_:
						addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ八"),l111l1_l1_+name,name,166,l11ll1_l1_ (u"ࠬ࠭公"),l11ll1_l1_ (u"࠭ࠧ六"),l11l1lll11ll_l1_+l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ兮"))
	elif l11ll1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ兯") in options:
		import IPTV
		#if l11ll1_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ兰") in options:
		l11l1l1l111l_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111l11l_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1lll111l11l_l1_,True): return
			l11l1ll111ll_l1_(l1lll111l11l_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠪࠫ共"),True): return
			for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
				l11l1ll111ll_l1_(str(l1lll111l11l_l1_),options)
			#else: l11l1l1l111l_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1l111l_l1_+menuItemsLIST[:]
	elif l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ兲") in options:
		import l1l1l1111lll_l1_
		#if l11ll1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ关") in options:
		l11l1l1l111l_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1lll111l11l_l1_:
			if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l1lll111l11l_l1_,True): return
			l11l1ll1llll_l1_(l1lll111l11l_l1_,options)
		else:
			if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"࠭ࠧ兴"),True): return
			for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
				l11l1ll1llll_l1_(str(l1lll111l11l_l1_),options)
			#else: l11l1l1l111l_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11l1l1l111l_l1_+menuItemsLIST[:]
	return
def l11ll111111l_l1_(l11l1l1lll11_l1_,options):
	l11l1l1lll11_l1_ = l11l1l1lll11_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭兵"),l11ll1_l1_ (u"ࠨࠩ其"))
	options = options.replace(l11ll1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ具"),l11ll1_l1_ (u"ࠪࠫ典")).replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ兹"),l11ll1_l1_ (u"ࠬ࠭兺"))
	l11l1l1l11ll_l1_(False)
	if contentsDICT=={}: return
	if l11ll1_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ养") in options:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ兼"),l11ll1_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭兽")+l11l1l1lll11_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊โิ็ࠣ࠾ࠥࡡࠠࠨ兾"),l11l1l1lll11_l1_,166,l11ll1_l1_ (u"ࠪࠫ兿"),l11ll1_l1_ (u"ࠫࠬ冀"),l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ冁")+options)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭冂"),l11ll1_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭冃"),l11l1l1lll11_l1_,166,l11ll1_l1_ (u"ࠨࠩ冄"),l11ll1_l1_ (u"ࠩࠪ内"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ円")+options)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ冇"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冈"),l11ll1_l1_ (u"࠭ࠧ冉"),9999)
	for l1l1l1l1_l1_ in sorted(list(contentsDICT[l11l1l1lll11_l1_].keys())):
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1l1lll11_l1_][l1l1l1l1_l1_]
		if l11ll1_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ冊") in options or len(contentsDICT[l11l1l1lll11_l1_])==1:
			l1l1ll11lll1_l1_(type,l11ll1_l1_ (u"ࠨࠩ冋"),url,l1l1llllll11_l1_,l11ll1_l1_ (u"ࠩࠪ册"),l1l1111_l1_,text,l11ll1_l1_ (u"ࠪࠫ再"),l11ll1_l1_ (u"ࠫࠬ冎"))
			menuItemsLIST[:] = l11l1ll1l111_l1_(menuItemsLIST)
			l11l1l1l111l_l1_,l1llll11ll1_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1llll11ll1_l1_)
			if l11ll1_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ冏") in options: menuItemsLIST[:] = l11l1l1l111l_l1_+l1llll11ll1_l1_[:l11l1lllll1l_l1_]
			else: menuItemsLIST[:] = l11l1l1l111l_l1_+l1llll11ll1_l1_
		elif l11ll1_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ冐") in options: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冑"),l1l1l1l1_l1_,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_)
	return
def l11l1ll11l1l_l1_(options,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ冒"),l11ll1_l1_ (u"ࠩࠪ冓"),str(mode),options)
	options = options.replace(l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ冔"),l11ll1_l1_ (u"ࠫࠬ冕")).replace(l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ冖"),l11ll1_l1_ (u"࠭ࠧ冗"))
	name,l11l1ll111l1_l1_ = l11ll1_l1_ (u"ࠧࠨ冘"),[]
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ写"),l11ll1_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ冚")+name+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ军"),l11ll1_l1_ (u"ࠫࠬ农"),mode,l11ll1_l1_ (u"ࠬ࠭冝"),l11ll1_l1_ (u"࠭ࠧ冞"),l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ冟")+options)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ冠"),l11ll1_l1_ (u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩ冡"),l11ll1_l1_ (u"ࠪࠫ冢"),mode,l11ll1_l1_ (u"ࠫࠬ冣"),l11ll1_l1_ (u"ࠬ࠭冤"),l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ冥")+options)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ冦"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ冧"),l11ll1_l1_ (u"ࠩࠪ冨"),9999)
	l11l1l1l111l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11ll1_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ冩") in options:
		l11l1l1l11ll_l1_(False)
		if contentsDICT=={}: return
		l11l1ll11lll_l1_ = list(contentsDICT.keys())
		l11l1l1lll11_l1_ = random.sample(l11l1ll11lll_l1_,1)[0]
		l11ll11111ll_l1_ = list(contentsDICT[l11l1l1lll11_l1_].keys())
		l1l1l1l1_l1_ = random.sample(l11ll11111ll_l1_,1)[0]
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ = contentsDICT[l11l1l1lll11_l1_][l1l1l1l1_l1_]
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ冪"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡽࡥࡣࡵ࡬ࡸࡪࡀࠠࠨ冫")+l1l1l1l1_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ冬")+name+l11ll1_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ冭")+url+l11ll1_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ冮")+str(l1l1llllll11_l1_))
	elif l11ll1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ冯") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠪࠫ冰"),True): return
		for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
			l11l1ll111ll_l1_(str(l1lll111l11l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ冱"),LOGGING(script_name)+l11ll1_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ冲")+name+l11ll1_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ决")+url+l11ll1_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ冴")+str(l1l1llllll11_l1_))
	elif l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ况") in options:
		import l1l1l1111lll_l1_
		if not l1l1l1111lll_l1_.CHECK_TABLES_EXIST(l11ll1_l1_ (u"ࠩࠪ冶"),True): return
		for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
			l11l1ll1llll_l1_(str(l1lll111l11l_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ冷"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ冸")+name+l11ll1_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ冹")+url+l11ll1_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ冺")+str(l1l1llllll11_l1_))
	l11l1ll1111l_l1_ = name
	l11l1ll1l1l1_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ冻"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ冼")+name+l11ll1_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ冽")+url+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭冾")+str(l1l1llllll11_l1_))
		menuItemsLIST[:] = []
		if l1l1llllll11_l1_==234 and l11ll1_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ冿") in text: l1l1llllll11_l1_ = 233
		if l1l1llllll11_l1_==714 and l11ll1_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ净") in text: l1l1llllll11_l1_ = 713
		if l1l1llllll11_l1_==144: l1l1llllll11_l1_ = 291
		html = l1l1ll11lll1_l1_(type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_)
		#if l11ll1_l1_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ凁") in html: l11l1ll11l1l_l1_(options,mode)
		if l11ll1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ凂") in options and l1l1llllll11_l1_==167: del menuItemsLIST[:3]
		if l11ll1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ凃") in options and l1l1llllll11_l1_==168: del menuItemsLIST[:3]
		l11l1ll111l1_l1_[:] = l11l1ll1l111_l1_(menuItemsLIST)
		if l11l1ll1l1l1_l1_ and l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡷࠪั้่ษࠨ凄")) in str(l11l1ll111l1_l1_) or l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡸࠫา๊โ่ࠩ凅")) in str(l11l1ll111l1_l1_):
			name = l11l1ll1111l_l1_
			l11l1ll111l1_l1_[:] = l11l1ll1l1l1_l1_
			break
		l11l1ll1111l_l1_ = name
		l11l1ll1l1l1_l1_ = l11l1ll111l1_l1_[:]
		if str(l11l1ll111l1_l1_).count(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ准"))>0: break
		if str(l11l1ll111l1_l1_).count(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ凇"))>0: break
		if l1l1llllll11_l1_==233: break	# iptv l111l1l1_l1_ names l11lll1l1ll_l1_ of l1l11_l1_ name
		if l1l1llllll11_l1_==713: break	# l11l1l1ll1l1_l1_ l111l1l1_l1_ names l11lll1l1ll_l1_ of l1l11_l1_ name
		if l1l1llllll11_l1_==291: break	# l1ll1ll1l_l1_ l11ll11111l1_l1_ names l11lll1l1ll_l1_ of l1ll1ll1l_l1_ l11ll11111l1_l1_ contents
		if l11l1ll111l1_l1_: type,name,url,l1l1llllll11_l1_,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ = random.sample(l11l1ll111l1_l1_,1)[0]
	if not name: name = l11ll1_l1_ (u"࠭࠮࠯࠰࠱ࠫ凈")
	elif name.count(l11ll1_l1_ (u"ࠧࡠࠩ凉"))>1: name = name.split(l11ll1_l1_ (u"ࠨࡡࠪ凊"),2)[2]
	name = name.replace(l11ll1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐ࠽ࠤࠬ凋"),l11ll1_l1_ (u"ࠪࠫ凌"))#.replace(l11ll1_l1_ (u"ࠫ࠱ࡓࡏࡗࡋࡈࡗ࠿ࠦࠧ凍"),l11ll1_l1_ (u"ࠬ࠭凎")).replace(l11ll1_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ减"),l11ll1_l1_ (u"ࠧࠨ凐")).replace(l11ll1_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ凑"),l11ll1_l1_ (u"ࠩࠪ凒"))
	name = name.replace(l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ凓"),l11ll1_l1_ (u"ࠫࠬ凔"))
	l11l1l1l111l_l1_[0][1] = l11ll1_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ凕")+name+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ凖")
	for i in range(9): random.shuffle(l11l1ll111l1_l1_)
	if l11ll1_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ凗") in options: menuItemsLIST[:] = l11l1l1l111l_l1_+l11l1ll111l1_l1_[:l11l1lllll1l_l1_]
	else: menuItemsLIST[:] = l11l1l1l111l_l1_+l11l1ll111l1_l1_
	return
def l11l1l1ll1ll_l1_(l11llllll1ll_l1_,l1l1111ll11l_l1_):
	l1l1111ll11l_l1_ = l1l1111ll11l_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ凘"),l11ll1_l1_ (u"ࠩࠪ凙")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凚"),l11ll1_l1_ (u"ࠫࠬ凛"))
	l11l1ll11ll1_l1_ = l1l1111ll11l_l1_
	if l11ll1_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭凜") in l1l1111ll11l_l1_:
		l11l1ll11ll1_l1_ = l1l1111ll11l_l1_.split(l11ll1_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ凝"))[0]
		type = l11ll1_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ凞")
	elif l11ll1_l1_ (u"ࠨࡘࡒࡈࠬ凟") in l11llllll1ll_l1_: type = l11ll1_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ几")
	elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ凡") in l11llllll1ll_l1_: type = l11ll1_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ凢")
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ凣"),l11ll1_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ凤")+type+l11l1ll11ll1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭凥"),l11llllll1ll_l1_,167,l11ll1_l1_ (u"ࠨࠩ処"),l11ll1_l1_ (u"ࠩࠪ凧"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ凨")+l1l1111ll11l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ凩"),l11ll1_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ凪"),l11llllll1ll_l1_,167,l11ll1_l1_ (u"࠭ࠧ凫"),l11ll1_l1_ (u"ࠧࠨ凬"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭凭")+l1l1111ll11l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ凮"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ凯"),l11ll1_l1_ (u"ࠫࠬ凰"),9999)
	import IPTV
	for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭凱") in l1l1111ll11l_l1_: IPTV.GROUPS(str(l1lll111l11l_l1_),l11llllll1ll_l1_,l1l1111ll11l_l1_,l11ll1_l1_ (u"࠭ࠧ凲"),False)
		else: IPTV.ITEMS(str(l1lll111l11l_l1_),l11llllll1ll_l1_,l1l1111ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ凳"),False)
	menuItemsLIST[:] = l11l1ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1lllll1l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1lllll1l_l1_)
	return
def l11l1l1l1111_l1_(l11llllll1ll_l1_,l1l1111ll11l_l1_):
	l1l1111ll11l_l1_ = l1l1111ll11l_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ凴"),l11ll1_l1_ (u"ࠩࠪ凵")).replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凶"),l11ll1_l1_ (u"ࠫࠬ凷"))
	l11l1ll11ll1_l1_ = l1l1111ll11l_l1_
	if l11ll1_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ凸") in l1l1111ll11l_l1_:
		l11l1ll11ll1_l1_ = l1l1111ll11l_l1_.split(l11ll1_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭凹"))[0]
		type = l11ll1_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ出")
	elif l11ll1_l1_ (u"ࠨࡘࡒࡈࠬ击") in l11llllll1ll_l1_: type = l11ll1_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ凼")
	elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ函") in l11llllll1ll_l1_: type = l11ll1_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ凾")
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ凿"),l11ll1_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ刀")+type+l11l1ll11ll1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭刁"),l11llllll1ll_l1_,168,l11ll1_l1_ (u"ࠨࠩ刂"),l11ll1_l1_ (u"ࠩࠪ刃"),l11ll1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ刄")+l1l1111ll11l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ刅"),l11ll1_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ分"),l11llllll1ll_l1_,168,l11ll1_l1_ (u"࠭ࠧ切"),l11ll1_l1_ (u"ࠧࠨ刈"),l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭刉")+l1l1111ll11l_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ刊"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ刋"),l11ll1_l1_ (u"ࠫࠬ刌"),9999)
	import l1l1l1111lll_l1_
	for l1lll111l11l_l1_ in range(FOLDERS_COUNT):
		if l11ll1_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ刍") in l1l1111ll11l_l1_: l1l1l1111lll_l1_.GROUPS(str(l1lll111l11l_l1_),l11llllll1ll_l1_,l1l1111ll11l_l1_,l11ll1_l1_ (u"࠭ࠧ刎"),False)
		else: l1l1l1111lll_l1_.ITEMS(str(l1lll111l11l_l1_),l11llllll1ll_l1_,l1l1111ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ刏"),False)
	menuItemsLIST[:] = l11l1ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1lllll1l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1lllll1l_l1_)
	return
def l11l1ll1l111_l1_(menuItemsLIST):
	l11l1ll111l1_l1_ = []
	for type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_ in menuItemsLIST:
		if l11ll1_l1_ (u"ࠨืไัฮ࠭刐") in name or l11ll1_l1_ (u"ุࠩๅาํࠧ刑") in name or l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ划") in name.lower(): continue
		l11l1ll111l1_l1_.append([type,name,url,mode,l111_l1_,l1l1111_l1_,text,l11l1l1ll111_l1_,l1ll1ll1l11_l1_])
	return l11l1ll111l1_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭䮺")
headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䮻") : l11ll1_l1_ (u"ࠬ࠭䮼") }
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡎࡘ࡝ࡣࠬ䮽")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11111_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llll1l_l1_(url)
	elif mode==188: results = l11ll11ll11l_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11ll11ll11l_l1_():
	message = l11ll1_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ䮾")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䮿"),l11ll1_l1_ (u"ࠩࠪ䯀"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䯁"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䯂"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䯃"),l11ll1_l1_ (u"࠭ࠧ䯄"),189,l11ll1_l1_ (u"ࠧࠨ䯅"),l11ll1_l1_ (u"ࠨࠩ䯆"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䯇"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䯈"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䯉")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิ࠭䯊"),l11l1l_l1_,181,l11ll1_l1_ (u"࠭ࠧ䯋"),l11ll1_l1_ (u"ࠧࠨ䯌"),l11ll1_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬ䯍"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䯎"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䯏")+l111l1_l1_+l11ll1_l1_ (u"ࠫศำฯฬࠢส่ฬ็ไศ็ࠪ䯐"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠬ࠭䯑"),l11ll1_l1_ (u"࠭ࠧ䯒"),l11ll1_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䯓"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯔"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䯕")+l111l1_l1_+l11ll1_l1_ (u"ࠪฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะࠩ䯖"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠫࠬ䯗"),l11ll1_l1_ (u"ࠬ࠭䯘"),l11ll1_l1_ (u"࠭ࡴࡷࠩ䯙"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䯚"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䯛")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่ฬ้หาุ่ࠢฬํฯสࠩ䯜"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠪࠫ䯝"),l11ll1_l1_ (u"ࠫࠬ䯞"),l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䯟"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯠"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䯡")+l111l1_l1_+l11ll1_l1_ (u"ࠨลๅ์๎ࠦวๅษไ่ฬ๋ࠠศๆะห้๐ษࠨ䯢"),l11l1l_l1_,181,l11ll1_l1_ (u"ࠩࠪ䯣"),l11ll1_l1_ (u"ࠪࠫ䯤"),l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䯥"))
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭䯦"),headers,l11ll1_l1_ (u"࠭ࠧ䯧"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䯨"))
	items = re.findall(l11ll1_l1_ (u"ࠨ࠾࡫࠶ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䯩"),html,re.DOTALL)
	for l1lllll_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䯪"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䯫")+l111l1_l1_+title,l1lllll_l1_,181)
	return html
def l11111_l1_(url,type=l11ll1_l1_ (u"ࠫࠬ䯬")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠬ࠭䯭"),headers,l11ll1_l1_ (u"࠭ࠧ䯮"),l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䯯"))
	if type==l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䯰"): block = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀฦัิัࠠศๆฦๅ้อๅ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧ䯱"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ䯲"): block = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࡪ࠴ࠫ䯳"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䯴"): block = re.findall(l11ll1_l1_ (u"࠭ࡢࡵࡰ࠰࠶࠲ࡵࡶࡦࡴ࡯ࡥࡾ࠮࠮ࠫࡁࠬࡀࡸࡺࡹ࡭ࡧࡁࠫ䯵"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䯶"): block = re.findall(l11ll1_l1_ (u"ࠨࡤࡷࡲ࠲࠷ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠬ࠳࠰࠿ࠪࡤࡷࡲ࠲࠸ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠫ䯷"),html,re.DOTALL)[0]
	elif type==l11ll1_l1_ (u"ࠩࡷࡺࠬ䯸"): block = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡪࠦࠬ䯹"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11ll1_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䯺"),l11ll1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䯻")]:
		items = re.findall(l11ll1_l1_ (u"࠭ࡳࡵࡻ࡯ࡩࡂࠨࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡱࡷࡸࡴࡳ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䯼"),block,re.DOTALL)
	else: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺ࠽ࠣ࠵࡞࠴࠲࠿࡝ࠬࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯽"),block,re.DOTALL)
	l11l_l1_ = []
	l111lll11_l1_ = [l11ll1_l1_ (u"ࠨใํ่๊࠭䯾"),l11ll1_l1_ (u"ࠩส่า๊โสࠩ䯿"),l11ll1_l1_ (u"ࠪห้ำไใ้ࠪ䰀"),l11ll1_l1_ (u"ࠫ฾ืึࠨ䰁"),l11ll1_l1_ (u"ࠬࡘࡡࡸࠩ䰂"),l11ll1_l1_ (u"࠭ࡓ࡮ࡣࡦ࡯ࡉࡵࡷ࡯ࠩ䰃"),l11ll1_l1_ (u"ࠧศ฻็ห๋࠭䰄"),l11ll1_l1_ (u"ࠨษฯึฬวࠧ䰅")]
	for l1lll1_l1_,l11ll111lll1_l1_,l11ll11ll1l1_l1_,l11ll11ll1ll_l1_ in items:
		if type in [l11ll1_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䰆"),l11ll1_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䰇")]:
			l1lll1_l1_,l1lllll_l1_,l1lllll11l_l1_,title = l1lll1_l1_,l11ll111lll1_l1_,l11ll11ll1l1_l1_,l11ll11ll1ll_l1_
		else: l1lll1_l1_,title,l1lllll_l1_,l1lllll11l_l1_ = l1lll1_l1_,l11ll111lll1_l1_,l11ll11ll1l1_l1_,l11ll11ll1ll_l1_
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠫࡄࡼࡩࡦࡹࡀࡸࡷࡻࡥࠨ䰈"),l11ll1_l1_ (u"ࠬ࠭䰉"))
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䰊"),l11ll1_l1_ (u"ࠧࠨ䰋"),l1lllll_l1_,l1lllll11l_l1_)
		title = unescapeHTML(title)
		#l1lll1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠨษฮ๋ำฮࢂศอ๊า๋࠮࠭䰌"),title,re.DOTALL)
		#if l1lll1l1l_l1_: title = l1lll1l1l_l1_[0][0]
		if l11ll1_l1_ (u"ࠩหะํีษࠡࠩ䰍") in title or l11ll1_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䰎") in title:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䰏") + title.replace(l11ll1_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䰐"),l11ll1_l1_ (u"࠭ࠧ䰑")).replace(l11ll1_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ䰒"),l11ll1_l1_ (u"ࠨࠩ䰓"))
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ䰔"))
		if l11ll1_l1_ (u"ࠪห้ำไใหࠪ䰕") in title or l11ll1_l1_ (u"ࠫฬ๊อๅไ๊ࠫ䰖") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁอไฮๆๅ๋࠮ࠦ࡜ࡥ࠭ࠪ䰗"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䰘") + l1ll1l1_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䰙"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111lll11_l1_):
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䰚") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䰛"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭䰜") + l1lllll11l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䰝"),l111l1_l1_+title,l1lllll_l1_,183,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠬ࠭䰞"):
		items = re.findall(l11ll1_l1_ (u"࠭࡜࡯࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䰟"),html,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠧศๆุๅาฯࠠࠨ䰠"),l11ll1_l1_ (u"ࠨࠩ䰡"))
			if title!=l11ll1_l1_ (u"ࠩࠪ䰢"):
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰣"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ䰤")+title,l1lllll_l1_,181)
	return
def l1llll1l_l1_(url):
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䰥"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ䰦"),headers,l11ll1_l1_ (u"ࠧࠨ䰧"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䰨"))
	block = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿࠰࠭ࡃ࡭࡫ࡩࡨࡪࡷࡁࠧ࠮࡛࠱࠯࠼ࡡ࠰࠯ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰩"),html,re.DOTALL)
	title,dummy,l1lll1_l1_ = block[0]
	name = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡠ࠶࠭࠺࡟࠮ࠫ䰪"),title,re.DOTALL)
	if name: name = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䰫") + name[0][0]
	else: name = title
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰࡪࡵࡲࡨࡪࡹࡎࡶ࡯ࡥࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䰬"),html,re.DOTALL)
	if l1l1l11_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䰭"),l11ll1_l1_ (u"ࠧࠨ䰮"),l111lll_l1_,str(l1l1l11_l1_))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰯"),block,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_)
			title = re.findall(l11ll1_l1_ (u"ࠩࠫห้ำไใหࡿห้ำไใ้ࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䰰"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ䰱"))[-2],re.DOTALL)
			if not title: title = re.findall(l11ll1_l1_ (u"ࠫ࠭࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ䰲"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ䰳"))[-2],re.DOTALL)
			if title: title = l11ll1_l1_ (u"࠭ࠠࠨ䰴") + title[0][1]
			else: title = l11ll1_l1_ (u"ࠧࠨ䰵")
			title = name + l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬ䰶") + l11ll1_l1_ (u"ࠩส่า๊โสࠩ䰷") + title
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䰸"),l111l1_l1_+title,l1lllll_l1_,182,l1lll1_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11ll1_l1_ (u"ࠫอา่ะหࠣࠫ䰹") in title or l11ll1_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䰺") in title:
			title = l11ll1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䰻") + title.replace(l11ll1_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䰼"),l11ll1_l1_ (u"ࠨࠩ䰽")).replace(l11ll1_l1_ (u"ࠩหะํี็ࠡࠩ䰾"),l11ll1_l1_ (u"ࠪࠫ䰿"))
		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䱀"),l111l1_l1_+title,url,182,l1lll1_l1_)
	return
def PLAY(url):
	l11ll11lll11_l1_ = url.split(l11ll1_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䱁"))
	l111lll_l1_ = l11ll11lll11_l1_[0]
	del l11ll11lll11_l1_[0]
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ䱂"),headers,l11ll1_l1_ (u"ࠧࠨ䱃"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䱄"))
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡩࡳࡳࡺ࠭ࡴ࡫ࡽࡩ࠿ࠦ࠲࠶ࡲࡻ࠿ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱅"),html,re.DOTALL)[0]
	if l1lllll_l1_ not in l11ll11lll11_l1_: l11ll11lll11_l1_.append(l1lllll_l1_)
	l1llll_l1_ = []
	# l11ll11l1ll1_l1_
	for l1lllll_l1_ in l11ll11lll11_l1_:
		if l11ll1_l1_ (u"ࠪ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ䱆") in l1lllll_l1_:
			l11ll11l1ll1_l1_ = l1lllll_l1_
			l1llll_l1_.append(l11ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡒࡧࡩ࡯ࠩ䱇"))
	# l11ll11l1l1l_l1_
	for l1lllll_l1_ in l11ll11lll11_l1_:
		if l11ll1_l1_ (u"ࠬࡀ࠯࠰ࡸࡥ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠨ䱈") in l1lllll_l1_:
			html = OPENURL_CACHED(l1llllll_l1_,l1lllll_l1_,l11ll1_l1_ (u"࠭ࠧ䱉"),headers,l11ll1_l1_ (u"ࠧࠨ䱊"),l11ll1_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭䱋"))
			html = html.decode(l11ll1_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨ䱌")).encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䱍"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11ll111ll1l_l1_><l11ll11l111l_l1_ /><l11ll111ll1l_l1_ l11ll11ll111_l1_=l11ll1_l1_ (u"ࠦࡨ࡫࡮ࡵࡧࡵࠦ䱎")>(\*\*\*\*\*\*\*\*|13721411411.l11ll111l1ll_l1_|)
			html = html.replace(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䱏"),l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䱐"))
			html = html.replace(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䱑"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䱒"))
			html = html.replace(l11ll1_l1_ (u"ࠩ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃࡂࡢࡳࠢ࠲ࡂࡁࡪࡩࡷࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࡁࠫ䱓"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䱔"))
			html = html.replace(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹࡨ࡯ࡳࡦࡨࡶࠧࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠧ䱕"),l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䱖"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䱗"),html,re.DOTALL)
			if l1l1l11_l1_:
				#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䱘"),l11ll1_l1_ (u"ࠨࠩ䱙"),url,str(len(l1l1l11_l1_)))
				l11ll111ll11_l1_,l11ll11l1l11_l1_ = [],[]
				if len(l1l1l11_l1_)==1:
					title = l11ll1_l1_ (u"ࠩࠪ䱚")
					block = html
				else:
					for block in l1l1l11_l1_:
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠯ࠬࡂࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭࠯࠭࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䱛"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䱜") + l111l_l1_[0][1]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠭࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䱝"),block,re.DOTALL)
						if l111l_l1_: block = l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࠨ䱞") + l111l_l1_[0]
						l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂ࠭ࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴ࠤࠣ࠳ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䱟"),block,re.DOTALL)
						if l111l_l1_: block = l111l_l1_[0] + l11ll1_l1_ (u"ࠨࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䱠")
						l11ll11l1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࠬ࠳࠰࠿ࠪࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯ࠨ䱡"),block,re.DOTALL)
						title = re.findall(l11ll1_l1_ (u"ࠪࡂࠥ࠰ࠨ࡜ࡠ࠿ࡂࡢ࠱ࠩࠡࠬ࠿ࠫ䱢"),l11ll11l1lll_l1_[0][0],re.DOTALL)
						title = l11ll1_l1_ (u"ࠫࠥ࠭䱣").join(title)
						title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ䱤"))
						title = title.replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䱥"),l11ll1_l1_ (u"ࠧࠡࠩ䱦")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䱧"),l11ll1_l1_ (u"ࠩࠣࠫ䱨")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭䱩"),l11ll1_l1_ (u"ࠫࠥ࠭䱪")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䱫"),l11ll1_l1_ (u"࠭ࠠࠨ䱬")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䱭"),l11ll1_l1_ (u"ࠨࠢࠪ䱮"))
						l11ll111ll11_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษ࠼ࠪ䱯"), l11ll111ll11_l1_)
					if l1l_l1_ == -1 : return
					title = l11ll111ll11_l1_[l1l_l1_]
					block = l1l1l11_l1_[l1l_l1_]
				l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰ࠮ࠨࠧ䱰"),block,re.DOTALL)
				l11ll11l11l1_l1_ = l1lllll_l1_[0]
				l1llll_l1_.append(l11ll11l11l1_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡋࡵࡲࡶ࡯ࠪ䱱"))
				block = block.replace(l11ll1_l1_ (u"ࠬๆࠧ䱲"),l11ll1_l1_ (u"࠭ࠧ䱳"))
				block = block.replace(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ䱴"),l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䱵"))
				block = block.replace(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࡣࡰ࡯࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ䱶"),l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䱷"))
				block = block.replace(l11ll1_l1_ (u"ุࠫ๐ัโำสฮࠥอไหฯ่๎้࠭䱸"),l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ䱹"))
				block = block.replace(l11ll1_l1_ (u"࠭ั้ษห฻ࠥอไหฯ่๎้࠭䱺"),l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ䱻"))
				block = block.replace(l11ll1_l1_ (u"ࠨีํีๆืวหࠢสฺ่๊ว่ัࠪ䱼"),l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䱽"))
				block = block.replace(l11ll1_l1_ (u"ࠪีํอศุࠢสฺ่๊ว่ัࠪ䱾"),l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ䱿"))
				l11ll111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࡝ࡦ࠮ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䲀"),block,re.DOTALL)
				for l11ll11l11ll_l1_ in l11ll111llll_l1_:
					#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䲁"),l11ll1_l1_ (u"ࠧࠨ䲂"),l11ll1_l1_ (u"ࠨࠩ䲃"),str(l11ll11l11ll_l1_))
					type = re.findall(l11ll1_l1_ (u"ࠩࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࠧ䲄"),l11ll11l11ll_l1_)
					if type:
						if type[0]!=l11ll1_l1_ (u"ࠪࡦࡴࡺࡨࠨ䲅"): type = l11ll1_l1_ (u"ࠫࡤࡥࠧ䲆")+type[0]
						else: type = l11ll1_l1_ (u"ࠬ࠭䲇")
					items = re.findall(l11ll1_l1_ (u"࠭ࠨࡀ࠾ࠤ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯ࠪࠪ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮ࡁ࠵ࡦࡰࡰࡷࡂ࠳࠰࠿ࡽ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀࡧࡸࠠ࠰ࡀ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠲࠯ࡅࠩࠣࠩ䲈"),l11ll11l11ll_l1_,re.DOTALL)
					for l11ll11l1111_l1_,l1lllll_l1_ in items:
						title = re.findall(l11ll1_l1_ (u"ࠧࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭࠭ࡁ࠭䲉"),l11ll11l1111_l1_)
						title = title[-1]
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䲊") + title + type
						l1llll_l1_.append(l1lllll_l1_)
	# l11ll11lll1l_l1_
	l11l111_l1_ = l111lll_l1_.replace(l11l1l_l1_,l11lllll1l_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠩࠪ䲋"),headers,l11ll1_l1_ (u"ࠪࠫ䲌"),l11ll1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ䲍"))
	items = re.findall(l11ll1_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲎"),html,re.DOTALL)
	#l11lll1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰ࡧࡰࡦࡪࡪࡍ࠮ࠪ࡟ࡻ࠰࠯࠭࠯ࠬࡂ࠲࡭ࡺ࡭࡭ࠫࠪ䲏"),html,re.DOTALL)
	#if l11lll1l11_l1_:
	if items:
		#l11ll11lll1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࠪ䲐") + l11lll1l11_l1_[-1] + l11ll1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䲑")
		l11ll11lll1l_l1_ = items[-1]
		l1llll_l1_.append(l11ll11lll1l_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡐࡳࡧ࡯࡬ࡦࠩ䲒"))
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䲓"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠫࠬ䲔"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠬ࠭䲕"): return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ䲖"),l11ll1_l1_ (u"ࠧࠬࠩ䲗"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ䲘"),headers,l11ll1_l1_ (u"ࠩࠪ䲙"),l11ll1_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䲚"))
	items = re.findall(l11ll1_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࡃ࠭䲛"),html,re.DOTALL)
	l111ll1l1_l1_ = [ l11ll1_l1_ (u"ࠬ࠭䲜") ]
	l111l11l1_l1_ = [ l11ll1_l1_ (u"࠭วๅๅ็ࠤํฮฯ้่ࠣๅ้ะัࠨ䲝") ]
	for category,title in items:
		l111ll1l1_l1_.append(category)
		l111l11l1_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥอไโๆอีࠥอไๆ่สือࡀࠧ䲞"), l111l11l1_l1_)
		if l1l_l1_ == -1 : return
		category = l111ll1l1_l1_[l1l_l1_]
	else: category = l11ll1_l1_ (u"ࠨࠩ䲟")
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ䲠")+search+l11ll1_l1_ (u"ࠪࠪࡲࡩࡡࡵ࠿ࠪ䲡")+category
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䲢"),l11ll1_l1_ (u"ࠬ࠭䲣"),url,url)
	l11111_l1_(url)
	return
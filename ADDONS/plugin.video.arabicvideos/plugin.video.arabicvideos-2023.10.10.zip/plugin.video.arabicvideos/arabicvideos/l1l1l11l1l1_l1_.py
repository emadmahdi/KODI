﻿# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#import unicodedata,simplejson
def MAIN(mode,l1l1l1l111l_l1_):
	if l1l1l1l111l_l1_==l11ll1_l1_ (u"ࠨࠩㅜ"): return
	if mode==1:
		l1l1l1l1111_l1_ = xbmcgui.l1l1l11llll_l1_()
		l1l1l11lll1_l1_ = xbmcgui.l1l1l111ll1_l1_(l1l1l1l1111_l1_)
		l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		l1l1l11lll1_l1_.getControl(311).l1l1l1l11ll_l1_(l1l1l1l111l_l1_)
	if mode==0:
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪㅝ"))
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨㅞ"))
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㅟ"))
		l1l1l11l111_l1_=l11ll1_l1_ (u"ࠬ࡞ࠧㅠ")
		if kodi_version>18.99: check = isinstance(l1l1l1l111l_l1_,str)
		else: check = isinstance(l1l1l1l111l_l1_,unicode)
		if check==True: l1l1l11l111_l1_=l11ll1_l1_ (u"࠭ࡕࠨㅡ")
		l1l1l111lll_l1_=str(type(l1l1l1l111l_l1_))+l11ll1_l1_ (u"ࠧࠡࠩㅢ")+l1l1l1l111l_l1_+l11ll1_l1_ (u"ࠨࠢࠪㅣ")+l1l1l11l111_l1_+l11ll1_l1_ (u"ࠩࠣࠫㅤ")
		for i in range(0,len(l1l1l1l111l_l1_),1):
			l1l1l111lll_l1_ += hex(ord(l1l1l1l111l_l1_[i])).replace(l11ll1_l1_ (u"ࠪ࠴ࡽ࠭ㅥ"),l11ll1_l1_ (u"ࠫࠬㅦ"))+l11ll1_l1_ (u"ࠬࠦࠧㅧ")
		l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫㅨ"))
		l1l1l11l111_l1_=l11ll1_l1_ (u"࡙ࠧࠩㅩ")
		if kodi_version>18.99: check = isinstance(l1l1l1l111l_l1_, str)
		else: check = isinstance(l1l1l1l111l_l1_, unicode)
		if check==True: l1l1l11l111_l1_=l11ll1_l1_ (u"ࠨࡗࠪㅪ")
		l1l1l11l11l_l1_=str(type(l1l1l1l111l_l1_))+l11ll1_l1_ (u"ࠩࠣࠫㅫ")+l1l1l1l111l_l1_+l11ll1_l1_ (u"ࠪࠤࠬㅬ")+l1l1l11l111_l1_+l11ll1_l1_ (u"ࠫࠥ࠭ㅭ")
		for i in range(0,len(l1l1l1l111l_l1_),1):
			l1l1l11l11l_l1_ += hex(ord(l1l1l1l111l_l1_[i])).replace(l11ll1_l1_ (u"ࠬ࠶ࡸࠨㅮ"),l11ll1_l1_ (u"࠭ࠧㅯ"))+l11ll1_l1_ (u"ࠧࠡࠩㅰ")
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㅱ"),l11ll1_l1_ (u"ࠩࠪㅲ"),l1l1l111lll_l1_,l1l1l11l11l_l1_)
	return
	#for i in range(0,len(l1l1l1l111l_l1_)-2,3):
	#	string=hex(ord(l1l1l1l111l_l1_[i+0]))+l11ll1_l1_ (u"ࠪࠤࠥ࠭ㅳ")+hex(ord(l1l1l1l111l_l1_[i+1]))+l11ll1_l1_ (u"ࠫࠥࠦࠧㅴ")+hex(ord(l1l1l1l111l_l1_[i+2]))
	#	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ㅵ"),l11ll1_l1_ (u"࠭ࠧㅶ"),l11ll1_l1_ (u"ࠧࠨㅷ"),string)
	#return
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㅸ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪㅹ"),l11ll1_l1_ (u"ࠪࠫㅺ"),l11ll1_l1_ (u"ࠫࠬㅻ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪㅼ"))
	#l1l1l1l111l_l1_ = unicodedata.normalize(l11ll1_l1_ (u"࠭ࡎࡇࡍࡇࠫㅽ"),l1l1l1l111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨㅾ"),l11ll1_l1_ (u"ࠨࠩㅿ"),l11ll1_l1_ (u"ࠩࠪㆀ"),   hex(  unicodedata.combining(l1l1l1l111l_l1_[0])  )   )
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㆁ"),l11ll1_l1_ (u"ࠫࠬㆂ"),l1l1l1l111l_l1_,   hex(ord(  l1l1l1l111l_l1_[0]  ))   )
	#new = l11ll1_l1_ (u"ࠬ࠭ㆃ")
	#for l1l1l11l1ll_l1_ in l1l1l1l111l_l1_:
	#	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧㆄ"),l11ll1_l1_ (u"ࠧࠨㆅ"),l11ll1_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨㆆ"),unicodedata.decomposition(l1l1l11l1ll_l1_) )
	#	new += l11ll1_l1_ (u"ࠩ࡟ࡹ࠵࠭ㆇ") + hex(ord(l1l1l11l1ll_l1_)).replace(l11ll1_l1_ (u"ࠪ࠴ࡽ࠭ㆈ"),l11ll1_l1_ (u"ࠫࠬㆉ"))
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ㆊ"),l11ll1_l1_ (u"࠭ࠧㆋ"),l11ll1_l1_ (u"ࠧࠨㆌ"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"ࠨࠩㆍ")
	#for i in range(len(l1l1l1l111l_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪㆎ"),l11ll1_l1_ (u"ࠪࠫ㆏"),l11ll1_l1_ (u"ࠫࠬ㆐"),str(i))
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1] + l1l1l1l111l_l1_[i+2] + l1l1l1l111l_l1_[i+3] + l1l1l1l111l_l1_[i+4] + l1l1l1l111l_l1_[i+5]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㆑"),l11ll1_l1_ (u"࠭ࠧ㆒"),l11ll1_l1_ (u"ࠧࠨ㆓"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㆔"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㆕"),l11ll1_l1_ (u"ࠪࠫ㆖"),l11ll1_l1_ (u"ࠫࠬ㆗"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㆘"))
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㆙"),l11ll1_l1_ (u"ࠧࠨ㆚"),l11ll1_l1_ (u"ࠨࠩ㆛"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l11ll1_l1_ (u"ࠩࡨࡱࡦࡪࠧ㆜")
	#l1l1l11ll11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡌࡲࡵࡻࡴ࠯ࡕࡨࡲࡩ࡚ࡥࡹࡶࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠩ㆝")+l1l1l1l111l_l1_+l11ll1_l1_ (u"ࠫࠧ࠲ࠢࡥࡱࡱࡩࠧࡀࡦࡢ࡮ࡶࡩࢂ࠲ࠢࡪࡦࠥ࠾࠶ࢃࠧ㆞"))
	#simplejson.loads(l1l1l11ll11_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㆟"))
	#new = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧㆠ"))
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨㆡ"),l11ll1_l1_ (u"ࠨࠩㆢ"),l11ll1_l1_ (u"ࠩࠪㆣ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㆤ"),l11ll1_l1_ (u"ࠫࠬㆥ"),l11ll1_l1_ (u"ࠬ࠭ㆦ"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"࠭ࠧㆧ")
	#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨㆨ"),l11ll1_l1_ (u"ࠨࠩㆩ"),l11ll1_l1_ (u"ࠩࠪㆪ"),l1l1l1l111l_l1_)
	#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㆫ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬㆬ"),l11ll1_l1_ (u"ࠬ࠭ㆭ"),l11ll1_l1_ (u"࠭ࠧㆮ"),l1l1l1l111l_l1_)
	#new = l11ll1_l1_ (u"ࠧࠨㆯ")
	#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
	#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
	#l1l1l1l111l_l1_ = new
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㆰ"),l11ll1_l1_ (u"ࠩࠪㆱ"),l11ll1_l1_ (u"ࠪࠫㆲ"),l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.replace(l11ll1_l1_ (u"ࠫࠥ࠭ㆳ"),l11ll1_l1_ (u"ࠬ࠭ㆴ"))
		#new = l11ll1_l1_ (u"࠭ࠧㆵ")
		#for i in range(len(l1l1l1l111l_l1_)-3,-2,-3):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1] + l1l1l1l111l_l1_[i+2]
		#l1l1l1l111l_l1_ = new
		#new = l11ll1_l1_ (u"ࠧࠨㆶ")
		#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
		#l1l1l1l111l_l1_ = new
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩㆷ"),l11ll1_l1_ (u"ࠩࠪㆸ"),l11ll1_l1_ (u"ࠪࠫㆹ"),l1l1l1l111l_l1_)
		#l1l1l1l111l_l1_ = l1l1l1l111l_l1_.l1l1l1l11l1_l1_(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㆺ"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ㆻ"),l11ll1_l1_ (u"࠭ࠧㆼ"),str(ord(l1l1l1l111l_l1_[0]))+l11ll1_l1_ (u"ࠧࠡࠩㆽ")+str(ord(l1l1l1l111l_l1_[1]))+l11ll1_l1_ (u"ࠨࠢࠪㆾ")+str(ord(l1l1l1l111l_l1_[2])),str(len(l1l1l1l111l_l1_)))
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪㆿ"),l11ll1_l1_ (u"ࠪࠫ㇀"),l11ll1_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠤࡑ࡫ࡴࡵࡧࡵࡷࠬ㇁"),l1l1l1l111l_l1_)
		#new = l11ll1_l1_ (u"ࠬ࠭㇂")
		#for i in range(len(l1l1l1l111l_l1_)-2,-1,-2):
		#	new += l1l1l1l111l_l1_[i] + l1l1l1l111l_l1_[i+1]
		#l1l1l1l111l_l1_ = new
		#new = l1l1l1l111l_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㇃"))
		#new = new.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㇄"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㇅"),l11ll1_l1_ (u"ࠩࠪ㇆"),l11ll1_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㇇"),new )
		#l1l1l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ㇈")
		#for l1l1l11l1ll_l1_ in new:
		#	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㇉"),l11ll1_l1_ (u"࠭ࠧ㇊"),l11ll1_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ㇋"),unicodedata.decomposition(l1l1l11l1ll_l1_) )
		#	l1l1l111lll_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡸࠫ㇌") + hex(ord(l1l1l11l1ll_l1_)).replace(l11ll1_l1_ (u"ࠩࡻࠫ㇍"),l11ll1_l1_ (u"ࠪࠫ㇎"))
		#l1l1l111lll_l1_ = l1l1l111lll_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㇏"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㇐"),l11ll1_l1_ (u"࠭ࠧ㇑"),l11ll1_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ㇒"),l1l1l111lll_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l1l11ll1l_l1_(new)
		#l1l1l1l111l_l1_ = new.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㇓"))
		#new = new.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㇔")) #.decode(l11ll1_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㇕"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㇖"),l11ll1_l1_ (u"ࠬ࠭㇗"),l11ll1_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭㇘"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㇙")))   )
		#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(new)
		#l1l1l1l111l_l1_ = l1l1l11ll1l_l1_(l1l1l1l111l_l1_)
		#method=l11ll1_l1_ (u"ࠣࡋࡱࡴࡺࡺ࠮ࡔࡧࡱࡨ࡙࡫ࡸࡵࠤ㇚")
		#params=l11ll1_l1_ (u"ࠩࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠪࡹࠢ࠭ࠢࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾࠩ㇛") % l1l1l1l111l_l1_
		#l1l1l11ll11_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠡࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠤࠧࠫࡳࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࠦࠥࡴ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ㇜") % (method, params))
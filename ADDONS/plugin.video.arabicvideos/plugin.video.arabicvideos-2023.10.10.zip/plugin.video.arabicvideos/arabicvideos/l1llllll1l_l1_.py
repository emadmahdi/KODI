# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᗊ")
headers = {l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᗋ"):l11ll1_l1_ (u"ࠨࠩᗌ")}
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨᗍ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧᗎ"),l11ll1_l1_ (u"ࠫฬิั๋ࠩᗏ"),l11ll1_l1_ (u"ࠬอฮา๋ࠪᗐ"),l11ll1_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᗑ"),l11ll1_l1_ (u"ࠧษั๋๊ࠥหฮห์สีࠬᗒ"),l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠧᗓ"),l11ll1_l1_ (u"่ࠩืู้ไศฬࠪᗔ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l11111_l1_(url,text)
	elif mode==422: results = l1lll1ll1l_l1_(url)
	elif mode==423: results = l1llll1l_l1_(url)
	elif mode==424: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᗕ")+text)
	elif mode==425: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗖ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l1llll111l_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1llll1lll_l1_(l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᗗ"),l11l1l_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧᗘ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᗙ"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩᗚ"),l11ll1_l1_ (u"ࠩࠪᗛ"),l11ll1_l1_ (u"ࠪࠫᗜ"),l11ll1_l1_ (u"ࠫࠬᗝ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᗞ"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᗟ"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"ࠧ࠰ࠩᗠ"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᗡ"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᗣ"),l11ll1_l1_ (u"ࠫࠬᗤ"),429,l11ll1_l1_ (u"ࠬ࠭ᗥ"),l11ll1_l1_ (u"࠭ࠧᗦ"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᗧ"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗨ"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᗩ"),l1ll111_l1_,425)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗪ"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᗫ"),l1ll111_l1_,424)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᗬ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᗭ"),l11ll1_l1_ (u"ࠧࠨᗮ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗯ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗰ")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้ืฦ๋ีํอࠬᗱ"),l1ll111_l1_,421)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗲ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᗳ")+l111l1_l1_+l11ll1_l1_ (u"࠭รโๆส้ࠥอไ็ฮ๋้ࠬᗴ"),l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳ࠰ࠩᗵ"),421)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗶ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗷ")+l111l1_l1_+l11ll1_l1_ (u"๊ࠪ๏ะแๅๅึࠫᗸ"),l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴ࡴࡥࡵࡨ࡯࡭ࡽ࠵ࠧᗹ"),421)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᗺ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗻ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳࠨᗼ") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠠศๆ้ะํ๋ࠧᗽ")
		elif l11ll1_l1_ (u"ࠩ࠲ࡲࡪࡺࡦ࡭࡫ࡻࠫᗾ") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠪวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๋๐สโๆๆืࠬᗿ")
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘀ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᘁ")+l111l1_l1_+title,l1lllll_l1_,421)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘂ"),l111l1_l1_+l11ll1_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧᘃ"),l1ll111_l1_,427)
	return
def l1llll111l_l1_(l1l1l1l1_l1_=l11ll1_l1_ (u"ࠨࠩᘄ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᘅ"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫᘆ"),l11ll1_l1_ (u"ࠫࠬᘇ"),l11ll1_l1_ (u"ࠬ࠭ᘈ"),l11ll1_l1_ (u"࠭ࠧᘉ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᘊ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡘ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᘋ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᘌ"),block,re.DOTALL)
	for category,id,l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		if l11ll1_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻ࠱ࡲࡵࡶࡪࡧࡶࠫᘍ") in l1lllll_l1_: title = l11ll1_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫᘎ")
		elif l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠲ࡴࡥࡵࡨ࡯࡭ࡽ࠭ᘏ") in l1lllll_l1_: title = l11ll1_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᘐ")
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘑ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᘒ")+l111l1_l1_+title,l1lllll_l1_,421,l11ll1_l1_ (u"ࠩࠪᘓ"),l11ll1_l1_ (u"ࠪࠫᘔ"),category+l11ll1_l1_ (u"ࠫࢁ࠭ᘕ")+id)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠬ࠭ᘖ")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᘗ"),l11ll1_l1_ (u"ࠧࠨᘘ"),l1lll1l1l1_l1_,url)
	if l11ll1_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫᘙ") in url: url = url.strip(l11ll1_l1_ (u"ࠩ࠲ࠫᘚ"))+l11ll1_l1_ (u"ࠪ࠳ࡲࡶࡡࡢ࠱ࡩࡥࡲ࡯࡬ࡺ࠱ࠪᘛ")
	items = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨᘜ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᘝ"),url,l11ll1_l1_ (u"࠭ࠧᘞ"),headers,l11ll1_l1_ (u"ࠧࠨᘟ"),l11ll1_l1_ (u"ࠨࠩᘠ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᘡ"))
	html = response.content
	if not l1lll1l1l1_l1_ or l11ll1_l1_ (u"ࠪࢀࠬᘢ") in l1lll1l1l1_l1_:
		#if l11ll1_l1_ (u"ࠫࡒࡻ࡬ࡵ࡫ࡉ࡭ࡱࡺࡥࡳࠩᘣ") in html:
		#	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘤ"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩᘥ"),url,425)
		#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘦ"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫᘧ"),url,424)
		#	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᘨ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᘩ"),l11ll1_l1_ (u"ࠫࠬᘪ"),9999)
		if l11ll1_l1_ (u"ࠬࢂࠧᘫ") not in l1lll1l1l1_l1_: l1lll1ll11_l1_ = l11ll1_l1_ (u"࠭ࠧᘬ")
		else: l1lll1ll11_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠱ࠪᘭ")+l1lll1l1l1_l1_
		separator = False
		if l11ll1_l1_ (u"ࠨࡒ࡬ࡲࡘࡲࡩࡥࡧࡵࠫᘮ") in html:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘯ"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᘰ"),url,421,l11ll1_l1_ (u"ࠫࠬᘱ"),l11ll1_l1_ (u"ࠬ࠭ᘲ"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᘳ"))
			separator = True
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸࠬᘴ"),html,re.DOTALL)
		if l1l1l11_l1_:
			l111l_l1_ = l1l1l11_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡤࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᘵ"),l111l_l1_,re.DOTALL)
			for l1lllll1ll_l1_,l1lll1l1l_l1_ in l1l1l1l_l1_:
				l1lllll11l_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡤࡧࡱࡸࡪࡸ࠯ࡢࡥࡷ࡭ࡴࡴ࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࡶࡤࡦ࠴࠭ᘶ")+l1lllll1ll_l1_+l1lll1ll11_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬᘷ")
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘸ"),l111l1_l1_+l1lll1l1l_l1_,l1lllll11l_l1_,421)
				separator = True
		if separator: addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᘹ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᘺ"),l11ll1_l1_ (u"ࠧࠨᘻ"),9999)
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᘼ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠧᘽ"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᘾ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: block = l11ll1_l1_ (u"ࠫࠬᘿ")
	elif l11ll1_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᙀ") in url or l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࡣࡦࡰࡷࡩࡷ࠵ࠧᙁ") in url:
		block = html
	elif l11ll1_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩᙂ") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠬࠪᙃ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵࠪᙄ") in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡔࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠰ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠮ࠬᙅ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠫ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡅࡨࡺ࡯ࡳࡐࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙆ"),block,re.DOTALL)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡉࡩ࡮ࡣ࠷ࡹࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࠬᙇ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: block = l11ll1_l1_ (u"࠭ࠧᙈ")
	if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠫࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠰࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠮ࠫࡁࡅࡳࡽ࡚ࡩࡵ࡮ࡨࡍࡳ࡬࡯࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙉ"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᙊ"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if not title: continue
		if l11ll1_l1_ (u"ࠩࡂࡲࡪࡽࡳ࠾ࠩᙋ") in l1lllll_l1_: continue
		title = title.replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠣࠫᙌ"),l11ll1_l1_ (u"ࠫࠬᙍ"))
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭ᙎ"),title,re.DOTALL)
		if l1ll1l1_l1_ and l11ll1_l1_ (u"࠭อๅไฬࠫᙏ") in title:
			title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᙐ") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙑ"),l111l1_l1_+title,l1lllll_l1_,422,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪᙒ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙓ"),l111l1_l1_+title,l1lllll_l1_,421,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙔ"),l111l1_l1_+title,l1lllll_l1_,422,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙕ"),html,re.DOTALL)
	if l1l1l11_l1_ and l1lll1l1l1_l1_!=l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᙖ"):
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡ࡜ࠨ࡞ࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࡢࠢ࡞ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙗ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠨษ็ูๆำษࠡࠩᙘ"),l11ll1_l1_ (u"ࠩࠪᙙ"))
			if title!=l11ll1_l1_ (u"ࠪࠫᙚ"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙛ"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫᙜ")+title,l1lllll_l1_,421)
	l1llll1ll1_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼࠰࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙝ"),html,re.DOTALL)
	if l1llll1ll1_l1_:
		l1lllll_l1_,title = l1llll1ll1_l1_[0]
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙞ"),l111l1_l1_+title,l1lllll_l1_,421)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᙟ"),url,l11ll1_l1_ (u"ࠩࠪᙠ"),l11ll1_l1_ (u"ࠪࠫᙡ"),l11ll1_l1_ (u"ࠫࠬᙢ"),l11ll1_l1_ (u"ࠬ࠭ᙣ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫᙤ"))
	html = response.content
	# l11l1l1ll_l1_/download main l11l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡔ࡯ࡸࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᙥ"),html,re.DOTALL)
	if l1l1l11_l1_:
		url = l1l1l11_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᙦ"),url,l11ll1_l1_ (u"ࠩࠪᙧ"),l11ll1_l1_ (u"ࠪࠫᙨ"),l11ll1_l1_ (u"ࠫࠬᙩ"),l11ll1_l1_ (u"ࠬ࠭ᙪ"),l11ll1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠳ࡰࡧࠫᙫ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᙬ"),l11ll1_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ᙭"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡖࡩࡦࡹ࡯࡯ࡵࡖࡩࡨࡺࡩࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭᙮"),html,re.DOTALL)
	# l1llll11l1_l1_ l1lll1l1ll_l1_
	if l11ll1_l1_ (u"ࠪ࠳ࡹࡧࡧ࠰ࠩᙯ") in url or l11ll1_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵࠫᙰ") in url:
		l11111_l1_(url)
	# l1lll1l_l1_
	elif l1l1l11_l1_:
		l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭ᙱ"))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧᙲ"),block,re.DOTALL)
		l1lllllll1_l1_ = [l11ll1_l1_ (u"ࠧๆี็ื้࠭ᙳ"),l11ll1_l1_ (u"ࠨ็๋ื๊࠭ᙴ"),l11ll1_l1_ (u"ࠩหี๋อๅอࠩᙵ"),l11ll1_l1_ (u"ࠪั้่ษࠨᙶ")]
		for l1lllll_l1_,title in items:
			if any(value in title for value in l1lllllll1_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙷ"),l111l1_l1_+title,l1lllll_l1_,423,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᙸ"),l111l1_l1_+title,l1lllll_l1_,426,l1lll1_l1_)
	else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᙹ"),url,l11ll1_l1_ (u"ࠧࠨᙺ"),l11ll1_l1_ (u"ࠨࠩᙻ"),l11ll1_l1_ (u"ࠩࠪᙼ"),l11ll1_l1_ (u"ࠪࠫᙽ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᙾ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᙿ"),l11ll1_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ "))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᚁ"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩᚂ")
	# l1l11_l1_
	l1l11llll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚃ"),html,re.DOTALL)
	if l1l11llll_l1_:
		block = l1l11llll_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚄ"),block,re.DOTALL)
		for l1lllll_l1_,title,l1ll1l1_l1_ in items:
			title = title+l11ll1_l1_ (u"ࠫࠥ࠭ᚅ")+l1ll1l1_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᚆ"),l111l1_l1_+title,l1lllll_l1_,426,l1lll1_l1_)
	else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚇ"),l111l1_l1_+l11ll1_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭ᚈ"),url,426,l1lll1_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᚉ"),url,l11ll1_l1_ (u"ࠩࠪᚊ"),headers,l11ll1_l1_ (u"ࠪࠫᚋ"),l11ll1_l1_ (u"ࠫࠬᚌ"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᚍ"))
	html = response.content
	#newurl = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡶࡼࡰࡪࡹࡨࡦࡧࡷࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᚎ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᚏ"))
	l1ll111_l1_ = SERVER(newurl,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᚐ"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	#if kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᚑ"),l11ll1_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᚒ"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡜ࡧࡴࡤࡪࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᚓ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠥࠤ࠴ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᚔ"),block,re.DOTALL)
		for l11llll1_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨᚕ"))
			if l11ll1_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭ᚖ") in title.lower(): title = l11ll1_l1_ (u"ࠨะสูࠥ࠭ᚗ")+title
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡹࡸࡵࡤࡶࡸࡶࡪ࠵ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧᚘ")+l11llll1_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᚙ")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᚚ")
			#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡥ࠹ࡻ࠮ࡪࡥࡸࠫ᚛"),l11ll1_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠴࡭ࡹࠩ᚜"))
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࡝ࡴࠪ᚝"),l11ll1_l1_ (u"ࠨࠩ᚞"))
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ᚟"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠥࠤ࠴ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᚠ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᚡ"))
			if l11ll1_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫᚢ") in title.lower(): l1lll1l1l_l1_ = l11ll1_l1_ (u"࠭࡟ࡠะสูࠬᚣ")
			else: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠧࠨᚤ")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᚥ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᚦ")+l1lll1l1l_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡷ࠭ᚧ"),l11ll1_l1_ (u"ࠫࠬᚨ"))
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᚩ"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚪ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨᚫ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩᚬ"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫᚭ"),l11ll1_l1_ (u"ࠪ࠯ࠬᚮ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭ᚯ")+search+l11ll1_l1_ (u"ࠬ࠵ࠧᚰ")
	l11111_l1_(url,l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᚱ"))
	return
# ===========================================
#     l1lll1llll_l1_ l1lll1lll1_l1_ l1llll1111_l1_
# ===========================================
def l1llllll11_l1_(url):
	if l11ll1_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩᚲ") not in url: url = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᚳ"))
	else: url = url.split(l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᚴ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧᚵ"),url,l11ll1_l1_ (u"ࠫࠬᚶ"),l11ll1_l1_ (u"ࠬ࠭ᚷ"),l11ll1_l1_ (u"࠭ࠧᚸ"),l11ll1_l1_ (u"ࠧࠨᚹ"),l11ll1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪᚺ"))
	html = response.content
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᚻ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	# name + options block + category
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᚼ"),block,re.DOTALL)
	return l1ll1lll_l1_
def l1llll11ll_l1_(block):
	# id + title
	items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᚽ"),block,re.DOTALL)
	return items
def l1llll1l11_l1_(url):
	l1lllll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᚾ"))[0]
	l1llll1l1l_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪᚿ"))
	url = url.replace(l1lllll1l1_l1_,l1llll1l1l_l1_)
	url = url.replace(l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᛀ"),l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᛁ"))
	url = url.replace(l11ll1_l1_ (u"ࠩࡀࠫᛂ"),l11ll1_l1_ (u"ࠪ࠳ࠬᛃ")).replace(l11ll1_l1_ (u"ࠫࠫ࠭ᛄ"),l11ll1_l1_ (u"ࠬ࠵ࠧᛅ"))
	url = url+l11ll1_l1_ (u"࠭࠯ࠨᛆ")
	return url
l1l11l1l_l1_ = [l11ll1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᛇ"),l11ll1_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧᛈ"),l11ll1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᛉ")]
l1ll111l_l1_ = [l11ll1_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᛊ"),l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᛋ"),l11ll1_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᛌ"),l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᛍ")]
def l1lll111_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᛎ"),l11ll1_l1_ (u"ࠨࠩᛏ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪᛐ"),l11ll1_l1_ (u"ࠪࠫᛑ"),filter,url)
	if l11ll1_l1_ (u"ࠫࡄ࠭ᛒ") in url: url = url.split(l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᛓ"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪᛔ"),1)
	if filter==l11ll1_l1_ (u"ࠧࠨᛕ"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠨࠩᛖ"),l11ll1_l1_ (u"ࠩࠪᛗ")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠪࡣࡤࡥࠧᛘ"))
	if type==l11ll1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᛙ"):
		if l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᛚ") in url:
			global l1l11l1l_l1_
			l1l11l1l_l1_ = l1l11l1l_l1_[1:]
		if l1l11l1l_l1_[0]+l11ll1_l1_ (u"࠭࠽ࠨᛛ") not in l1l111ll_l1_: category = l1l11l1l_l1_[0]
		for i in range(len(l1l11l1l_l1_[0:-1])):
			if l1l11l1l_l1_[i]+l11ll1_l1_ (u"ࠧ࠾ࠩᛜ") in l1l111ll_l1_: category = l1l11l1l_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠨࠨࠪᛝ")+category+l11ll1_l1_ (u"ࠩࡀ࠴ࠬᛞ")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠬᛟ")+category+l11ll1_l1_ (u"ࠫࡂ࠶ࠧᛠ")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠬࠬࠧᛡ"))+l11ll1_l1_ (u"࠭࡟ࡠࡡࠪᛢ")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠩᛣ"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᛤ"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᛥ")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᛦ"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᛧ"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠬ࠭ᛨ"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᛩ"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠧࠨᛪ"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ᛫")+l1l111l1_l1_
		l111lll_l1_ = l1llll1l11_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᛬"),l111l1_l1_+l11ll1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭᛭"),l111lll_l1_,421,l11ll1_l1_ (u"ࠫࠬᛮ"),l11ll1_l1_ (u"ࠬ࠭ᛯ"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᛰ"))
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛱ"),l111l1_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᛲ")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᛳ"),l111lll_l1_,421,l11ll1_l1_ (u"ࠪࠫᛴ"),l11ll1_l1_ (u"ࠫࠬᛵ"),l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᛶ"))
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᛷ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᛸ"),l11ll1_l1_ (u"ࠨࠩ᛹"),9999)
	l1ll1lll_l1_ = l1llllll11_l1_(url)
	dict = {}
	for name,block,l1ll1l1l_l1_ in l1ll1lll_l1_:
		if l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭᛺") in url and l1ll1l1l_l1_==l11ll1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ᛻"): continue
		name = name.replace(l11ll1_l1_ (u"ࠫ࠲࠳ࠧ᛼"),l11ll1_l1_ (u"ࠬ࠭᛽"))
		items = l1llll11ll_l1_(block)
		if l11ll1_l1_ (u"࠭࠽ࠨ᛾") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ᛿"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<2:
				if l1ll1l1l_l1_==l1l11l1l_l1_[-1]:
					url = l1llll1l11_l1_(url)
					l11111_l1_(url)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᜀ")+l1l11lll_l1_)
				return
			else:
				l111lll_l1_ = l1llll1l11_l1_(l111lll_l1_)
				if l1ll1l1l_l1_==l1l11l1l_l1_[-1]: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜁ"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้าๅ๋฻ࠪᜂ"),l111lll_l1_,421,l11ll1_l1_ (u"ࠫࠬᜃ"),l11ll1_l1_ (u"ࠬ࠭ᜄ"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᜅ"))
				else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜆ"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨᜇ"),l111lll_l1_,425,l11ll1_l1_ (u"ࠩࠪᜈ"),l11ll1_l1_ (u"ࠪࠫᜉ"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᜊ"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠬࠬࠧᜋ")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠱ࠩᜌ")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩᜍ")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨ࠿࠳ࠫᜎ")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭ᜏ")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜐ"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᜑ")+name,l111lll_l1_,424,l11ll1_l1_ (u"ࠬ࠭ᜒ"),l11ll1_l1_ (u"࠭ࠧᜓ"),l1l11lll_l1_)		# +l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠ᜔ࠩ"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨ᜕"): option = l11ll1_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩ᜖")
			elif value==l11ll1_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪ᜗"): option = l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭᜘")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ᜙") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᜚"),value,re.DOTALL)[0]
			dict[l1ll1l1l_l1_][value] = option
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠧࠧࠩ᜛")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ᜜")+option
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫ᜝")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࠬ᜞")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨᜟ")+l1l1ll1l_l1_
			title = option+l11ll1_l1_ (u"ࠬࠦ࠺ࠨᜠ")#+dict[l1ll1l1l_l1_][l11ll1_l1_ (u"࠭࠰ࠨᜡ")]
			title = option+l11ll1_l1_ (u"ࠧࠡ࠼ࠪᜢ")+name
			if type==l11ll1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᜣ"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜤ"),l111l1_l1_+title,url,424,l11ll1_l1_ (u"ࠪࠫᜥ"),l11ll1_l1_ (u"ࠫࠬᜦ"),l1ll1l11_l1_)		# +l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᜧ"))
			elif type==l11ll1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᜨ") and l1l11l1l_l1_[-2]+l11ll1_l1_ (u"ࠧ࠾ࠩᜩ") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᜪ"))
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᜫ")+l11lllll_l1_
				l11l111_l1_ = l1llll1l11_l1_(l11l111_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜬ"),l111l1_l1_+title,l11l111_l1_,421,l11ll1_l1_ (u"ࠫࠬᜭ"),l11ll1_l1_ (u"ࠬ࠭ᜮ"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᜯ"))
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜰ"),l111l1_l1_+title,url,425,l11ll1_l1_ (u"ࠨࠩᜱ"),l11ll1_l1_ (u"ࠩࠪᜲ"),l1ll1l11_l1_)
	return
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᜳ"),l11ll1_l1_ (u"᜴ࠫࠬ"),filters,l11ll1_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭᜵"))
	# mode==l11ll1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ᜶")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ᜷")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠨࡣ࡯ࡰࠬ᜸")					all l1l1l1ll_l1_ & l1lllll111_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠩࡀࠪࠬ᜹"),l11ll1_l1_ (u"ࠪࡁ࠵ࠬࠧ᜺"))
	filters = filters.strip(l11ll1_l1_ (u"ࠫࠫ࠭᜻"))
	l1l11l11_l1_ = {}
	if l11ll1_l1_ (u"ࠬࡃࠧ᜼") in filters:
		items = filters.split(l11ll1_l1_ (u"࠭ࠦࠨ᜽"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠧ࠾ࠩ᜾"))
			l1l11l11_l1_[var] = value
	l1ll11ll_l1_ = l11ll1_l1_ (u"ࠨࠩ᜿")
	for key in l1ll111l_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠩ࠳ࠫᝀ")
		if l11ll1_l1_ (u"ࠪࠩࠬᝁ") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᝂ") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧᝃ"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠠࠬࠢࠪᝄ")+value
		elif mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᝅ") and value!=l11ll1_l1_ (u"ࠨ࠲ࠪᝆ"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࠫᝇ")+key+l11ll1_l1_ (u"ࠪࡁࠬᝈ")+value
		elif mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨᝉ"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠬࠧᝊ")+key+l11ll1_l1_ (u"࠭࠽ࠨᝋ")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫᝌ"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠪᝍ"))
	l1ll11ll_l1_ = l1ll11ll_l1_.replace(l11ll1_l1_ (u"ࠩࡀ࠴ࠬᝎ"),l11ll1_l1_ (u"ࠪࡁࠬᝏ"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᝐ"),l11ll1_l1_ (u"ࠬ࠭ᝑ"),filters,l11ll1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᝒ"))
	return l1ll11ll_l1_
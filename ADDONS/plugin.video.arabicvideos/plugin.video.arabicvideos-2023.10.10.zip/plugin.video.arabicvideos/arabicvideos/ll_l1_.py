# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ刓")
#l111l1l1l11l_l1_ = [ l11ll1_l1_ (u"ࠬࡳࡹࡴࡶࡵࡩࡦࡳࠧ刔"),l11ll1_l1_ (u"࠭ࡶࡪ࡯ࡳࡰࡪ࠭刕"),l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡳࠧ刖"),l11ll1_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭列") ]
l111l1l1l11l_l1_ = []
headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭刘"):l11ll1_l1_ (u"ࠪࠫ则")}
def l11_l1_(l1llll11_l1_,source,type,url):
	#DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่ึอศุࠢส่๊์วิสࠪ刚"),l1llll11_l1_)
	if not l1llll11_l1_:
		LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ创"),LOGGING(script_name)+l11ll1_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭刜")+source+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨ初")+type+l11ll1_l1_ (u"ࠨࠢࡠࠫ刞"))
		l111lll1lll1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ刟"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭删"),l11ll1_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ刡"))
		datetime = time.strftime(l11ll1_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭刢"),time.gmtime(now))
		line = datetime,url
		key = source+l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠫ刣")+l11llll111l_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࠤࠬ判")+str(kodi_version)
		message = l11ll1_l1_ (u"ࠨࠩ別")
		if key not in list(l111lll1lll1_l1_.keys()): l111lll1lll1_l1_[key] = [line]
		else:
			if url not in str(l111lll1lll1_l1_[key]): l111lll1lll1_l1_[key].append(line)
			else: message = l11ll1_l1_ (u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧ刦")
		total = 0
		for key in list(l111lll1lll1_l1_.keys()):
			l111lll1lll1_l1_[key] = list(set(l111lll1lll1_l1_[key]))
			total += len(l111lll1lll1_l1_[key])
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ刧"),l11ll1_l1_ (u"ࠫࠬ刨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ利"),l11ll1_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ刪")+message+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭别")+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭刬")+l11ll1_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ刭")+str(total))
		if total>=5:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ刮"),l11ll1_l1_ (u"ࠫࠬ刯"),l11ll1_l1_ (u"ࠬ࠭到"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ刱"),l11ll1_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ刲"))
			if l1ll111ll1_l1_==1:
				l111llll1111_l1_ = l11ll1_l1_ (u"ࠨࠩ刳")
				for key in list(l111lll1lll1_l1_.keys()):
					l111llll1111_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ刴")+key
					l1111111l1l1_l1_ = sorted(l111lll1lll1_l1_[key],reverse=False,key=lambda l11llll11111_l1_: l11llll11111_l1_[0])
					for datetime,url in l1111111l1l1_l1_:
						l111llll1111_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭刵")+datetime+l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ制")+l1111_l1_(url)
					l111llll1111_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ刷")
				import l1l1111ll1l_l1_
				succeeded = l1l1111ll1l_l1_.l111ll11111_l1_(l11ll1_l1_ (u"࠭ࡖࡪࡦࡨࡳࡸ࠭券"),l11ll1_l1_ (u"ࠧࠨ刹"),False,l11ll1_l1_ (u"ࠨࠩ刺"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭刻"),l11ll1_l1_ (u"ࠪࠫ刼"),l111llll1111_l1_)
				if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ刽"),l11ll1_l1_ (u"ࠬ࠭刾"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ刿"),l11ll1_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ剀"))
				else: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ剁"),l11ll1_l1_ (u"ࠩࠪ剂"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭剃"),l11ll1_l1_ (u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩ剄"))
			if l1ll111ll1_l1_!=-1:
				l111lll1lll1_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ剅"),l11ll1_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ剆"))
		if l111lll1lll1_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ則"),l11ll1_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ剈"),l111lll1lll1_l1_,PERMANENT_CACHE)
		return
	l1llll11_l1_ = list(set(l1llll11_l1_))
	l1lll11l_l1_,l1llll_l1_ = l11111l1111l_l1_(l1llll11_l1_,source)
	l1111111l11l_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ剉"))
	l11111l11ll1_l1_ = str(l1llll_l1_).count(l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ削"))
	l1111111ll11_l1_ = len(l1llll_l1_)-l1111111l11l_l1_-l11111l11ll1_l1_
	l11111ll1111_l1_ = l11ll1_l1_ (u"ฺ๊ࠫว่ัฬ࠾ࠬ剋")+str(l1111111l11l_l1_)+l11ll1_l1_ (u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩ剌")+str(l11111l11ll1_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࠢࠣวำื้࠻ࠩ前")+str(l1111111ll11_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ剎"),l11ll1_l1_ (u"ࠨࠩ剏"),str(l1111111l11l_l1_),str(l11111l11ll1_l1_))
	#l1l_l1_ = DIALOG_SELECT(l11111ll1111_l1_, l1llll_l1_)
	if not l1llll_l1_: result,l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭剐"),l11ll1_l1_ (u"ࠪࠫ剑")
	else:
		while True:
			l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠫࠬ剒")
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11111ll1111_l1_,l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ剓")
			else:
				title = l1lll11l_l1_[l1l_l1_]
				l1lllll_l1_ = l1llll_l1_[l1l_l1_]
				#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ剔"),l11ll1_l1_ (u"ࠧࠨ剕"),title,l1lllll_l1_)
				if l11ll1_l1_ (u"ࠨีํีๆืࠧ剖") in title and l11ll1_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ剗") in title:
					LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ剘"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ剙")+title+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ剚")+l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ剛"))
					import l1l1111ll1l_l1_
					l1l1111ll1l_l1_.MAIN(156)
					result = l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ剜")
				else:
					LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ剝"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ剞")+title+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ剟")+l1lllll_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ剠"))
					result,l11l11ll1l1l_l1_,l11ll11l1l11_l1_ = l11111llll11_l1_(l1lllll_l1_,source,type)
					#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭剡"),l11ll1_l1_ (u"࠭ࠧ剢"),result,l11l11ll1l1l_l1_)
			if l11ll1_l1_ (u"ࠧ࡝ࡰࠪ剣") not in l11l11ll1l1l_l1_: l11l111llll1_l1_,l11l111ll1l_l1_ = l11l11ll1l1l_l1_,l11ll1_l1_ (u"ࠨࠩ剤")
			else: l11l111llll1_l1_,l11l111ll1l_l1_ = l11l11ll1l1l_l1_.split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ剥"),1)
			if result in [l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ剦"),l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭剧"),l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭剨"),l11ll1_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ剩")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ剪"),l11ll1_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ剫"),l11ll1_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ剬")]: break
			elif result not in [l11ll1_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ剭"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ剮")]: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭副"),l11ll1_l1_ (u"࠭ࠧ剰"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剱"),l11ll1_l1_ (u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࠫ割")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ剳")+l11l111llll1_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭剴")+l11l111ll1l_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ創"),l11ll1_l1_ (u"ࠬ࠭剶"),l11ll1_l1_ (u"࠭ࠧ剷"),str(l11ll11l1l11_l1_))
	if result==l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ剸") and len(l1lll11l_l1_)>0: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ剹"),l11ll1_l1_ (u"ࠩࠪ剺"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭剻"),l11ll1_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ剼")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ剽")+l11l11ll1l1l_l1_)
	elif result in [l11ll1_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭剾"),l11ll1_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ剿")] and l11l11ll1l1l_l1_!=l11ll1_l1_ (u"ࠨࠩ劀"): DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ劁"),l11ll1_l1_ (u"ࠪࠫ劂"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ劃"),l11l11ll1l1l_l1_)
	#elif l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠬࡘࡅࡕࡗࡕࡒࡤ࡚ࡏࡠ࡛ࡒ࡙࡙࡛ࡂࡆࠩ劄"): result = l11ll11l1l11_l1_
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡱࠤࡠ࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ࠰ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩࡠ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࡗࡩࡸࡺ࠺ࠡࠢࠣࠫ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠱࡟࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠸࡝ࠪࠌࠌࠍࡽࡨ࡭ࡤࡲ࡯ࡹ࡬࡯࡮࠯ࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࡤࡨࡩࡵ࡮ࡠࡪࡤࡲࡩࡲࡥ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭࠯ࠩࠋࠋࠌࡴࡱࡧࡹࡠ࡫ࡷࡩࡲࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬࡵࡧࡴࡩ࠿ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡃࡲࡵࡤࡦ࠿࠴࠸࠸ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࠪ࠹ࡆࡷࠧ࠶ࡈ࡬ࡽࡢ࠲ࡲࡻ࡚ࡹࡽ࠹ࡒࠩࠬࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡰ࡭ࡣࡼࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࡭ࡸ࠴࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰࡫ࡳ࡬ࡴࡴࡥ࠰࠳࠵࠷࠹࠺࠷࠯࡯ࡳ࠸ࠬ࠲ࡰ࡭ࡣࡼࡣ࡮ࡺࡥ࡮ࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไศๆ฽หฦ࠭ࠬࠨࠩࠬࠎࠎࠨࠢࠣ劅")
	return result
	#if source==l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ劆"): l111l1_l1_ = l11ll1_l1_ (u"ࠨࡊࡏࡅࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ劇")
	#elif source==l11ll1_l1_ (u"ࠩ࠷ࡌࡊࡒࡁࡍࠩ劈"): l111l1_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡎࡅࡍࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ劉")
	#elif source==l11ll1_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ劊"): l111l1_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡂࡍࡐࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭劋")
	#elif source==l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ劌"): l111l1_l1_ = l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡖࡌ࠹ࠦࠧ劍")
	#size = len(l1ll1ll1l1_l1_)
	#for i in range(0,size):
	#	title = l11l11ll11ll_l1_[i]
	#	l1lllll_l1_ = l1ll1ll1l1_l1_[i]
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ劎"),l111l1_l1_+title,l1lllll_l1_,160,l11ll1_l1_ (u"ࠩࠪ劏"),l11ll1_l1_ (u"ࠪࠫ劐"),source)
def l11111llll11_l1_(url,source,type=l11ll1_l1_ (u"ࠫࠬ劑")):
	url = url.strip(l11ll1_l1_ (u"ࠬࠦࠧ劒")).strip(l11ll1_l1_ (u"࠭ࠦࠨ劓")).strip(l11ll1_l1_ (u"ࠧࡀࠩ劔")).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ劕"))
	l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllllll11l_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ劖"),l11ll1_l1_ (u"ࠪࠫ劗"),url,l11l11ll1l1l_l1_)
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ劘"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ劙"), l1lll11l_l1_)
			if l1l_l1_==-1: result = l11ll1_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ劚")
			else:
				l1111lllll1l_l1_ = l1llll_l1_[l1l_l1_]
				title = l1lll11l_l1_[l1l_l1_]
				LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ力"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡥ࡭ࡧࡦࡸࡪࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ劜")+title+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ劝")+str(l1111lllll1l_l1_)+l11ll1_l1_ (u"ࠪࠤࡢ࠭办"))
				if l11ll1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ功") in l1111lllll1l_l1_ and l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ加") in l1111lllll1l_l1_:
					l111l11lll11_l1_,l11ll111ll11_l1_,l11ll11l1l11_l1_ = l111llllll1l_l1_(l1111lllll1l_l1_)
					if l11ll11l1l11_l1_: l1111lllll1l_l1_ = l11ll11l1l11_l1_[0]
					else: l1111lllll1l_l1_ = l11ll1_l1_ (u"࠭ࠧ务")
				if not l1111lllll1l_l1_: result = l11ll1_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ劢")
				else: result = PLAY_VIDEO(l1111lllll1l_l1_,source,type)
			if result in [l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ劣"),l11ll1_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭劤")] or len(l1llll_l1_)==1: break
			elif result in [l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ劥"),l11ll1_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ劦"),l11ll1_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ劧")]: break
			else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ动"),l11ll1_l1_ (u"ࠧࠨ助"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ努"),l11ll1_l1_ (u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨ劫"))
	else:
		result = l11ll1_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ劬")
		l111lll1l1_l1_ = l11l1lll11_l1_(url)
		if l111lll1l1_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11l11ll1l1l_l1_,l1llll_l1_
	#title = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ劭") )
	#if l11ll1_l1_ (u"ู๊ࠬาใิࠤ฾อๅࠡ็ฯ๋ํ๊ࠧ劮") in title:
	#	import l1l1111ll1l_l1_
	#	l1l1111ll1l_l1_.MAIN(156)
	#	return l11ll1_l1_ (u"࠭ࠧ劯")
def l1llllll1111l_l1_(url,source):
	# url = url+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ劰")+name+l11ll1_l1_ (u"ࠨࡡࡢࠫ励")+type+l11ll1_l1_ (u"ࠩࡢࡣࠬ劲")+l11lll1_l1_+l11ll1_l1_ (u"ࠪࡣࡤ࠭劳")+l111llll_l1_
	# url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺ࠿࡯ࡣࡰࡩࡩࡃࡡ࡬ࡹࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣ࠼࠸࠰ࠨ労")
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111lll_l1_,name,type,l11lll1_l1_,l111llll_l1_ = url,l11ll1_l1_ (u"ࠬ࠭劵"),l11ll1_l1_ (u"࠭ࠧ劶"),l11ll1_l1_ (u"ࠧࠨ劷"),l11ll1_l1_ (u"ࠨࠩ劸"),l11ll1_l1_ (u"ࠩࠪ効"),l11ll1_l1_ (u"ࠪࠫ劺"),l11ll1_l1_ (u"ࠫࠬ劻")
	#source = source.lower()
	if l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭劼") in url:
		l111lll_l1_,l11l1111l1l1_l1_ = url.split(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ劽"),1)
		l11l1111l1l1_l1_ = l11l1111l1l1_l1_+l11ll1_l1_ (u"ࠧࡠࡡࠪ劾")+l11ll1_l1_ (u"ࠨࡡࡢࠫ势")+l11ll1_l1_ (u"ࠩࡢࡣࠬ勀")+l11ll1_l1_ (u"ࠪࡣࡤ࠭勁")
		l11l1111l1l1_l1_ = l11l1111l1l1_l1_.lower()
		name,type,l11lll1_l1_,l111llll_l1_,l1llll11llll_l1_ = l11l1111l1l1_l1_.split(l11ll1_l1_ (u"ࠫࡤࡥࠧ勂"))[:5]
	if l111llll_l1_==l11ll1_l1_ (u"ࠬ࠭勃"): l111llll_l1_ = l11ll1_l1_ (u"࠭࠰ࠨ勄")
	else: l111llll_l1_ = l111llll_l1_.replace(l11ll1_l1_ (u"ࠧࡱࠩ勅"),l11ll1_l1_ (u"ࠨࠩ勆")).replace(l11ll1_l1_ (u"ࠩࠣࠫ勇"),l11ll1_l1_ (u"ࠪࠫ勈"))
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠫࡄ࠭勉")).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ勊")).strip(l11ll1_l1_ (u"࠭ࠦࠨ勋"))
	server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠧࡩࡱࡶࡸࠬ勌"))
	if name: l111l1111lll_l1_ = name
	#elif source: l111l1111lll_l1_ = source
	else: l111l1111lll_l1_ = server
	l111l1111lll_l1_ = SERVER(l111l1111lll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭勍"))
	name = name.replace(l11ll1_l1_ (u"่ࠩฬฬฺัࠨ勎"),l11ll1_l1_ (u"ࠪࠫ勏")).replace(l11ll1_l1_ (u"ุࠫ๐ัโำࠪ勐"),l11ll1_l1_ (u"ࠬ࠭勑")).replace(l11ll1_l1_ (u"࠭วๅࠢࠪ勒"),l11ll1_l1_ (u"ࠧࠡࠩ勓")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ勔"),l11ll1_l1_ (u"ࠩࠣࠫ動"))
	l11l1111l1l1_l1_ = l11l1111l1l1_l1_.replace(l11ll1_l1_ (u"้ࠪออิาࠩ勖"),l11ll1_l1_ (u"ࠫࠬ勗")).replace(l11ll1_l1_ (u"ู๊ࠬาใิࠫ勘"),l11ll1_l1_ (u"࠭ࠧ務")).replace(l11ll1_l1_ (u"ࠧศๆࠣࠫ勚"),l11ll1_l1_ (u"ࠨࠢࠪ勛")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ勜"),l11ll1_l1_ (u"ࠪࠤࠬ勝"))
	l111l1111lll_l1_ = l111l1111lll_l1_.replace(l11ll1_l1_ (u"๊ࠫฮวีำࠪ勞"),l11ll1_l1_ (u"ࠬ࠭募")).replace(l11ll1_l1_ (u"࠭ำ๋ำไีࠬ勠"),l11ll1_l1_ (u"ࠧࠨ勡")).replace(l11ll1_l1_ (u"ࠨษ็ࠤࠬ勢"),l11ll1_l1_ (u"ࠩࠣࠫ勣")).replace(l11ll1_l1_ (u"ࠪࠤࠥ࠭勤"),l11ll1_l1_ (u"ࠫࠥ࠭勥"))
	return l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111lll_l1_,name,type,l11lll1_l1_,l111llll_l1_
def l11l11l1ll1l_l1_(url,source):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭勦"),l11ll1_l1_ (u"࠭ࠧ勧"),url,l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ勨"))
	# l1lll1l11_l1_	: سيرفر خاص
	# l11l111l1lll_l1_		: سيرفر محدد
	# l11l1111l111_l1_		: سيرفر عام معروف
	# l1ll1l1l1_l1_	: سيرفر عام خارجي
	# l111111l1111_l1_	: سيرفر عام خارجي
	l1111lll11ll_l1_,name,l1lll1l11_l1_,l11l1111l111_l1_,l1ll1l1l1_l1_,l11l111l1lll_l1_,l111111l1111_l1_ = l11ll1_l1_ (u"ࠨࠩ勩"),l11ll1_l1_ (u"ࠩࠪ勪"),None,None,None,None,None
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111lll_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1llllll1111l_l1_(url,source)
	if l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ勫") in url:
		if   type==l11ll1_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ勬"): type = l11ll1_l1_ (u"ࠬࠦࠧ勭")+l11ll1_l1_ (u"࠭ๅโุ็ࠫ勮")
		elif type==l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭勯"): type = l11ll1_l1_ (u"ࠨࠢࠪ勰")+l11ll1_l1_ (u"ࠩࠨู้อ็ะหࠪ勱")
		elif type==l11ll1_l1_ (u"ࠪࡦࡴࡺࡨࠨ勲"): type = l11ll1_l1_ (u"ࠫࠥ࠭勳")+l11ll1_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ勴")
		elif type==l11ll1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ勵"): type = l11ll1_l1_ (u"ࠧࠡࠩ勶")+l11ll1_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ勷")
		elif type==l11ll1_l1_ (u"ࠩࠪ勸"): type = l11ll1_l1_ (u"ࠪࠤࠬ勹")+l11ll1_l1_ (u"ࠫࠪࠫࠥࠦࠩ勺")
		if l11lll1_l1_!=l11ll1_l1_ (u"ࠬ࠭勻"):
			if l11ll1_l1_ (u"࠭࡭ࡱ࠶ࠪ勼") not in l11lll1_l1_: l11lll1_l1_ = l11ll1_l1_ (u"ࠧࠦࠩ勽")+l11lll1_l1_
			l11lll1_l1_ = l11ll1_l1_ (u"ࠨࠢࠪ勾")+l11lll1_l1_
		if l111llll_l1_!=l11ll1_l1_ (u"ࠩࠪ勿"):
			l111llll_l1_ = l11ll1_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭匀")+l111llll_l1_
			l111llll_l1_ = l11ll1_l1_ (u"ࠫࠥ࠭匁")+l111llll_l1_[-9:]
	#if any(value in server for value in l111l1l1l11l_l1_): return l11ll1_l1_ (u"ࠬ࠭匂")
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ匃"),l11ll1_l1_ (u"ࠧࠨ匄"),name,l111l1111lll_l1_)
	if   l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ包")		in source: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ匆")		in source: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ匇")
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭匈")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ匉")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ匊")	in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ匋")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ匌")
	#elif l11ll1_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ匍") in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ匎")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ匏")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	#elif l11ll1_l1_ (u"ࠬࡶࡣࡳࡧࡹ࡭ࡪࡽࠧ匐")	in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ匑")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ匒")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ匓")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ匔")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ匕")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ化")	in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ北")
	elif l11ll1_l1_ (u"࠭แอำࠪ匘")			in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭匙")
	elif l11ll1_l1_ (u"ࠨใ็ื฼๐ๆࠨ匚")		in name:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬ匛")
	elif l11ll1_l1_ (u"ࠪ࡫ࡩࡸࡩࡷࡧࠪ匜")		in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ匝")
	elif l11ll1_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ匞")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭匟")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ匠")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ匡")		in name:   l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ匢")	in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ匣")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ匤")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ匥")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ匦")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ匧")		in server: l1lll1l11_l1_	= l111l1111lll_l1_
	#elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭匨")	in l111lll_l1_:   l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࠣࠫ匩")
	elif l11ll1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ匪")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭匫")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ匬")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭匭")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ匮")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ匯")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ匰")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ匱")
	elif l11ll1_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ匲")	 	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭匳")
	elif l11ll1_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ匴")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ匵")
	elif l11ll1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ匶")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ匷")
	elif l11ll1_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ匸")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭匹")
	elif l11ll1_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ区")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ医")
	elif l11ll1_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ匼")	in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ匽")
	elif l11ll1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ匾")		in server: l1lll1l11_l1_	= l11ll1_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ匿")
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ區")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ十")
	elif l11ll1_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ卂")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ千")
	elif l11ll1_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ卄")	 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡦࡥࡹࡩࡨࠨ卅")
	elif l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ卆")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ升")
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ午")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ卉")
	elif l11ll1_l1_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭半")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧ卋")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ卌")		in server: l11l111l1lll_l1_	= l111l1111lll_l1_
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ卍")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭华")
	elif l11ll1_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ协")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ卐")
	elif l11ll1_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ卑") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ卒")
	elif l11ll1_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ卓")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭協")
	elif l11ll1_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ单")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ卖")
	elif l11ll1_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ南") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ単")
	elif l11ll1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ卙")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ博")
	elif l11ll1_l1_ (u"ࠪࡹࡵࡶࠧ卛") 			in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ卜")
	elif l11ll1_l1_ (u"ࠬࡻࡰࡣࠩ卝") 			in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ卞")
	elif l11ll1_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ卟") 		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ占")
	elif l11ll1_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ卡") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ卢")
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ卣")		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ卤")
	elif l11ll1_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭卥") 		in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ卦")
	elif l11ll1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ卧") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭卨")
	elif l11ll1_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ卩")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ卪")
	elif l11ll1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ卫")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ卬")
	#elif l11ll1_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ卭") 	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ卮")
	#elif l11ll1_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭卯")	in server: l11l1111l111_l1_	= l11ll1_l1_ (u"ࠪࡹࡵࡺ࡯ࡴࡶࡵࡩࡦࡳࠧ印")
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡶࡴ࡯࠯ࠬࡃ࠽࠾ࠩ࠮ࡹࡷࡲ࠲ࠪࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠴ࡈࡰࡵࡷࡩࡩࡓࡥࡥ࡫ࡤࡊ࡮ࡲࡥࠩࡷࡵࡰ࠷࠯࠮ࡷࡣ࡯࡭ࡩࡥࡵࡳ࡮ࠫ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࡴ࠽ࠎࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠱࠲࠳࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠭ࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡌࡡ࡭ࡵࡨࠎࠎࠏࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡲ࠮ࡰࡴࡪࠎࠎࠏࠉ࡭࡫ࡶࡸࡤࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡵࡦ࡯࠱ࡴࡸࡧ࠯ࡩ࡬ࡸ࡭ࡻࡢ࠯࡫ࡲ࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠰ࡵࡸࡴࡵࡵࡲࡵࡧࡧࡷ࡮ࡺࡥࡴ࠰࡫ࡸࡲࡲࠧࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮࡯࡭ࡸࡺ࡟ࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊ࡙ࡏࡍࡘࡄࡆࡑࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࡟࠵ࡣ࠮࡭ࡱࡺࡩࡷ࠮ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࡬ࡪࡀࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠳࠴࠵࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࠌࡴࡦࡸࡴࡴࠢࡀࠤࡸ࡫ࡲࡷࡧࡵ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠳࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡲࡤࡶࡹ࠯࠼࠵࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࠌࡩࡱ࡯ࡦࠡࡲࡤࡶࡹࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࠍࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠍࠎࠏࠉࠊࡤࡵࡩࡦࡱࠊࠊࠤࠥࠦ危")
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭卲"),l11ll1_l1_ (u"࠭ࠧ即"),url,l111lll_l1_)
	if   l1lll1l11_l1_:	l1111lll11ll_l1_,name = l11ll1_l1_ (u"ࠧฯษุࠫ却"),l1lll1l11_l1_
	elif l11l111l1lll_l1_:		l1111lll11ll_l1_,name = l11ll1_l1_ (u"ࠨ่ࠧัิีࠧ卵"),l11l111l1lll_l1_
	elif l11l1111l111_l1_:		l1111lll11ll_l1_,name = l11ll1_l1_ (u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ卶"),l11l1111l111_l1_
	elif l1ll1l1l1_l1_:	l1111lll11ll_l1_,name = l11ll1_l1_ (u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ卷"),l1ll1l1l1_l1_
	elif l111111l1111_l1_:	l1111lll11ll_l1_,name = l11ll1_l1_ (u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ卸"),l111l1111lll_l1_
	else:			l1111lll11ll_l1_,name = l11ll1_l1_ (u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭卹"),l111l1111lll_l1_
	return l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉࡱࡴ࡬ࡺࡦࡺࡥࠡ࠿ࠣࠫ࡭࡫࡬ࡢ࡮ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠍࠍࡪࡲࡩࡧࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸࡨࡺࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠢࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡩࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠎࠎࠨࠢࠣ卺")
def l1111l11l1l1_l1_(url,source):
	l111lll_l1_,l11l1111l1l1_l1_,server,l111l1111lll_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l1llllll1111l_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ卻"),l11ll1_l1_ (u"ࠨࠩ卼"),l11l111l1lll_l1_,server)
	#if l11ll1_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ卽")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ卾"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ卿"))
	#if any(value in server for value in l111l1l1l11l_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡅࡔࡑࡏ࡚ࡊࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࠢࡷ࡬࡮ࡹࠠࡴࡧࡵࡺࡪࡸࠧ厀")],[]
	if   l11ll1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ厁")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11llll_l1_(l111lll_l1_,name)
	elif l11ll1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭厂")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1_l1_(l111lll_l1_,type,l111llll_l1_)
	elif l11ll1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ厃")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ厄")		in source: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ厅")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l1l1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ历")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ厇")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11l11l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ厈")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ厉")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111111_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ厊")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll111ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ压")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll1lll11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ厌")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ厍")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧ厎")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll111l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ厏")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1lll1ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ厐")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lll11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ厑")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1l11ll11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ厒")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111111111l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡺࡸ࠺ࡵࠨ厓")			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1llll1l11_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ厔")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭厕")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧ厖")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫ厗")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ厘")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ厙")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll11lll11l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ厚")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1l1ll111lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ厛")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111lll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ厜")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ厝")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ厞")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡵࡧࡦ࡬ࠬ原")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠩࡪࡹࡱ࡬ࡴࡦࡥ࡫ࠫ厠")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡵࡥࡹ࡫ࠧ厡")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡵࡩࡲࡦࡸ࡬ࡩࡼ࠭厢")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ厣")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll1ll_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ厤")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࠨ厥"),[l11ll1_l1_ (u"ࠨࠩ厦")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ厧")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩ厨")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1l1l_l1_(l111lll_l1_)
	elif l11ll1_l1_ (u"ࠫࡺࡶࡢࡢ࡯ࠪ厩") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬ࠭厪"),[l11ll1_l1_ (u"࠭ࠧ厫")],[l111lll_l1_]
	else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ厬"),[l11ll1_l1_ (u"ࠨࠩ厭")],[l111lll_l1_]
	return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
def l11l11111ll1_l1_(url,source):
	server = SERVER(url,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ厮"))
	#if l11ll1_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ厯")	in server: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ厰"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ厱"))
	#if any(value in server for value in l111l1l1l11l_l1_): l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ厲")],[]
	l1111l11l11l_l1_ = False
	if   l11ll1_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭厳")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ厴")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l1l1l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠭厵") in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l111l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ厶")	in url: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1l1l1ll_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭厷")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ厸")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11ll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ厹")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11lll1l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ厺")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llllll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ去")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1ll1l1l111_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ厼")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ厽")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll11l111_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ厾")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1llll_l1_(url)
	elif l11ll1_l1_ (u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ县")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll111l1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ叀")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ叁")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111lll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ参")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ參")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ叄")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ叅")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ叆")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ叇")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ又")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ叉")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll1llll1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ及") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠪࠫ友"),[l11ll1_l1_ (u"ࠫࠬ双")],[url]
	#elif l11ll1_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ反")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllll111lll_l1_(url)
	elif l11ll1_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ収") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1l11ll1_l1_(url)
	elif l11ll1_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ叏")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111ll111lll_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࡮࡯ࠨ叐")in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l11111l1_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭发") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111llll11ll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ叒")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l1l11ll_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡺࡶࡢࠨ叓") 			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll1llll1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡻࡰࡱࠩ叔") 			in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llll1llll1l_l1_(url)
	#elif l11ll1_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ叕") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1l1l1_l1_(url)
	#elif l11ll1_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ取")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1l1l1_l1_(url)
	elif l11ll1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ受") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111l11111_l1_(url)
	elif l11ll1_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ变") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l11lllll_l1_(url)
	elif l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ叙")		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l111l11_l1_(url)
	elif l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ叚") 		in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111ll1l1l_l1_(url)
	elif l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ叛") 	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l111l1lllll1_l1_(url)
	elif l11ll1_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ叜")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11111l11l11_l1_(url)
	elif l11ll1_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ叝")	in server: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111ll1lll1_l1_(url)
	else: l1111l11l11l_l1_ = True
	if l1111l11l11l_l1_ or l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ叞") in l11l11ll1l1l_l1_:
		l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ叟"),[],[]
	return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	l11ll1_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈࡗ࡙ࡘࡅࡂࡏࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡇࡐࡗࡑࡐࡎࡓࡉࡕࡇࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡊࡐࡗࡓ࡚ࡖࡌࡐࡃࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁ࡚ࠥࡈࡆࡘࡌࡈࡊࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡇ࡙ࡍࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡵࡲࡡࡺࡴ࠱࠸࡭࡫࡬ࡢ࡮ࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡌࡊࡒࡁࡍࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡇࡕࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡌࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡗࡍࡇࡒࡆࠪࡸࡶࡱ࠯ࠊࠊࠤࠥࠦ叠")
def	l111l11ll111_l1_(l11ll11lll11_l1_):
	if l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ叡") in str(type(l11ll11lll11_l1_)):
		l1l1_l1_ = []
		for l1lllll_l1_ in l11ll11lll11_l1_:
			if l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ叢") in str(type(l1lllll_l1_)):
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ口"),l11ll1_l1_ (u"ࠧࠨ古")).replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ句"),l11ll1_l1_ (u"ࠩࠪ另")).strip(l11ll1_l1_ (u"ࠪࠤࠬ叧"))
			l1l1_l1_.append(l1lllll_l1_)
	else: l1l1_l1_ = l11ll11lll11_l1_.replace(l11ll1_l1_ (u"ࠫࡡࡸࠧ叨"),l11ll1_l1_ (u"ࠬ࠭叩")).replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ只"),l11ll1_l1_ (u"ࠧࠨ叫")).strip(l11ll1_l1_ (u"ࠨࠢࠪ召"))
	return l1l1_l1_
def l1llllllll11l_l1_(url,source):
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ叭"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ叮")+url+l11ll1_l1_ (u"ࠫࠥࡣࠧ可"))
	l111111l1111_l1_,l1lllll_l1_,l111l11ll11l_l1_ = l11ll1_l1_ (u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩ台"),l11ll1_l1_ (u"࠭ࠧ叱"),l11ll1_l1_ (u"ࠧࠨ史")
	l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1111l11l1l1_l1_(url,source)
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ右"),l11ll1_l1_ (u"ࠩࠪ叴"),l11ll1_l1_ (u"ࠪࠫ叵"),l11l11ll1l1l_l1_)
	l1llll_l1_ = l111l11ll111_l1_(l1llll_l1_)
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ叶"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	elif l1llll_l1_: l1lllll_l1_ = l1llll_l1_[0]
	if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ号"):
		#l11l11ll1l1l_l1_ = l11l11ll1l1l_l1_.replace(l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ司"),l11ll1_l1_ (u"ࠧࠨ叹"))
		l111111l1111_l1_ = l11ll1_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ叺")
		l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111ll1_l1_(l1lllll_l1_,source)
		l1llll_l1_ = l111l11ll111_l1_(l1llll_l1_)
		if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ叻"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
		elif l11ll1_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ叼") in l11l11ll1l1l_l1_:
			l111l11ll11l_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠬ叽")+l11l11ll1l1l_l1_
			l111111l1111_l1_ = l11ll1_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ叾")
			l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111l1l_l1_(l1lllll_l1_,source)
			l1llll_l1_ = l111l11ll111_l1_(l1llll_l1_)
			if l11l11ll1l1l_l1_==l11ll1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ叿"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
			elif l11ll1_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭吀") in l11l11ll1l1l_l1_:
				l111l11ll11l_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸࠺ࠡࠩ吁")+l11l11ll1l1l_l1_
				l111111l1111_l1_ = l11ll1_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ吂")
				l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11l11111l11_l1_(l1lllll_l1_,source)
				l1llll_l1_ = l111l11ll111_l1_(l1llll_l1_)
				if l11l11ll1l1l_l1_==l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ吃"): return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
				elif l11ll1_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ各") in l11l11ll1l1l_l1_:
					l111l11ll11l_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥ࠭吅")+l11l11ll1l1l_l1_
	elif l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ吆") in l11l11ll1l1l_l1_: l111l11ll11l_l1_ = l11ll1_l1_ (u"ࠧࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠳࠾ࠥ࠭吇")+l11l11ll1l1l_l1_
	if l1llll_l1_: LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ合"),LOGGING(script_name)+l11ll1_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ吉")+l111111l1111_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ吊")+url+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ吋")+l1lllll_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹࡵ࡭ࡶࡶ࠾ࠥࡡࠠࠨ同")+str(l1llll_l1_)+l11ll1_l1_ (u"࠭ࠠ࡞ࠩ名"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ后"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ吏")+url+l11ll1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ吐")+l1lllll_l1_+l11ll1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡇࡵࡶࡴࡸࡳ࠻ࠢ࡞ࠤࠬ向")+l111l11ll11l_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ吒"))
	l111l11ll11l_l1_ = l1111_l1_(l111l11ll11l_l1_)
	return l111l11ll11l_l1_,l1lll11l_l1_,l1llll_l1_
def l11111l1111l_l1_(l11ll11l1l11_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ吓"),l11ll11l1l11_l1_)
	l1l111llll1_l1_ = l1llllll_l1_
	data = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ吔"),l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ吕"),l11ll11l1l11_l1_)
	if data:
		l1lll11l_l1_,l1llll_l1_ = list(zip(*data))
		return l1lll11l_l1_,l1llll_l1_
	l1lll11l_l1_,l1llll_l1_,l11l11ll11ll_l1_ = [],[],[]
	for l1lllll_l1_ in l11ll11l1l11_l1_:
		if l11ll1_l1_ (u"ࠨ࠱࠲ࠫ吖") not in l1lllll_l1_: continue
		l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_ = l11l11l1ll1l_l1_(l1lllll_l1_,source)
		l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨ࠰࠭吗"),l111llll_l1_,re.DOTALL)
		if l111llll_l1_: l111llll_l1_ = int(l111llll_l1_[0])
		else: l111llll_l1_ = 0
		#if l111llll_l1_:
		#	l111lllll1l1_l1_ = sorted(l111llll_l1_,reverse=True,key=lambda key: int(key))
		#	l111llll_l1_ = int(l111lllll1l1_l1_[0])
		#else: l111llll_l1_ = 0
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ吘"))
		l11l11ll11ll_l1_.append([l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server])
	if l11l11ll11ll_l1_:
		#l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_ = zip(*l11l11ll11ll_l1_)
		#name = reversed(name)
		#l11l11ll11ll_l1_ = zip(l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_)
		l1llll11l1l1_l1_ = sorted(l11l11ll11ll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111l11l11l1_l1_ = []
		for line in l1llll11l1l1_l1_:
			if line not in l111l11l11l1_l1_:
				l111l11l11l1_l1_.append(line)
				#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ吙"),str(line))
		for l1111lll11ll_l1_,name,type,l11lll1_l1_,l111llll_l1_,l1lllll_l1_,server in l111l11l11l1_l1_:
			if l111llll_l1_: l111llll_l1_ = str(l111llll_l1_)
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠬ࠭吚")
			#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ君"),l11ll1_l1_ (u"ࠧࠨ吜"),name,l1lllll_l1_)
			title = l11ll1_l1_ (u"ࠨีํีๆืࠧ吝")+l11ll1_l1_ (u"ࠩࠣࠫ吞")+type+l11ll1_l1_ (u"ࠪࠤࠬ吟")+l1111lll11ll_l1_+l11ll1_l1_ (u"ࠫࠥ࠭吠")+l111llll_l1_+l11ll1_l1_ (u"ࠬࠦࠧ吡")+l11lll1_l1_+l11ll1_l1_ (u"࠭ࠠࠨ吢")+name
			if server not in title: title = title+l11ll1_l1_ (u"ࠧࠡࠩ吣")+server
			title = title.replace(l11ll1_l1_ (u"ࠨࠧࠪ吤"),l11ll1_l1_ (u"ࠩࠪ吥")).strip(l11ll1_l1_ (u"ࠪࠤࠬ否")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ吧"),l11ll1_l1_ (u"ࠬࠦࠧ吨")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ吩"),l11ll1_l1_ (u"ࠧࠡࠩ吪")).replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ含"),l11ll1_l1_ (u"ࠩࠣࠫ听"))
			if l1lllll_l1_ not in l1llll_l1_:
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		if l1llll_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ吭"),l1llll_l1_)
			data = list(zip(l1lll11l_l1_,l1llll_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ吮"),l11ll11l1l11_l1_,data,l1l111llll1_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭启"),l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠾࠷ࡀࠠࠡࠢࠪ吰")+str(data))
	return l1lll11l_l1_,l1llll_l1_
def	l11l11111l1l_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ吱")
	l1lllll1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩ吲")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l111ll111_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lllll1lll1_l1_ = str(error)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ吳"),l11ll1_l1_ (u"ࠪࠫ吴"),l11ll1_l1_ (u"ࠫࠬ吵"),str(results))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭吶"),l11ll1_l1_ (u"࠭ࠧ吷"),l11ll1_l1_ (u"ࠧࠨ吸"),str(l1lllll1lll1_l1_))
	# resolveurl l1111l1l1l_l1_ l1lll1l111l_l1_ l1111lllll11_l1_ with l1lllll1l1l1l_l1_ error or l111l11llll1_l1_ value False
	if not results:
		if l1lllll1lll1_l1_==l11ll1_l1_ (u"ࠨࠩ吹"):
			l1lllll1lll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ吺"),l11ll1_l1_ (u"ࠪࠫ吻"),l11ll1_l1_ (u"ࠫࠬ吼"),str(l1lllll1lll1_l1_))
		l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠤࡋࡧࡩ࡭ࡧࡧࠫ吽")
		l11l11ll1l1l_l1_ += l11ll1_l1_ (u"࠭ࠠࠨ吾")+l1lllll1lll1_l1_.splitlines()[-1]
		return l11l11ll1l1l_l1_,[],[]
	return l11ll1_l1_ (u"ࠧࠨ吿"),[l11ll1_l1_ (u"ࠨࠩ呀")],[results]
def	l11l11111l11_l1_(url,source):
	#url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡈࡡࡘࡡ࡭ࡩࡳࡵࡺࡌࡥࠪ呁")
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯࠲ࡺ࡮ࡪࡥࡰ࠱ࡻ࠻ࡾࡿ࠴࠲ࡵࠪ呂")
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ呃"),l11ll1_l1_ (u"ࠬ࠭呄"),url,l11ll1_l1_ (u"࠭ࠧ呅"))
	#return l11ll1_l1_ (u"ࠧࠨ呆"),[],[]
	l1lllll1lll1_l1_ = l11ll1_l1_ (u"ࠨࠩ呇")
	results = False
	try:
		import youtube_dl
		l11l11l11ll1_l1_ = youtube_dl.YoutubeDL({l11ll1_l1_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ呈"): True})
		results = l11l11l11ll1_l1_.extract_info(url,download=False)
	except Exception as error: l1lllll1lll1_l1_ = str(error)
	# youtube_dl l1111l1l1l_l1_ l1lll1l111l_l1_ l1111lllll11_l1_ with l1lllll1l1l1l_l1_ error or l111l11llll1_l1_ value False
	if not results or l11ll1_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ呉") not in list(results.keys()):
		if l1lllll1lll1_l1_==l11ll1_l1_ (u"ࠫࠬ告"):
			l1lllll1lll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭呋"),l11ll1_l1_ (u"࠭ࠧ呌"),l11ll1_l1_ (u"ࠧࠨ呍"),l1lllll1lll1_l1_)
		l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠠࡇࡣ࡬ࡰࡪࡪࠧ呎")
		l11l11ll1l1l_l1_ += l11ll1_l1_ (u"ࠩࠣࠫ呏")+l1lllll1lll1_l1_.splitlines()[-1]
		return l11l11ll1l1l_l1_,[],[]
	else:
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_ in results[l11ll1_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ呐")]:
			l1lll11l_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫ呑")])
			l1llll_l1_.append(l1lllll_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ呒")])
		return l11ll1_l1_ (u"࠭ࠧ呓"),l1lll11l_l1_,l1llll_l1_
def l11l11l11l11_l1_(url):
	if l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭呔") in url:
		l1lll11l_l1_,l1llll_l1_ = l11ll11l1l_l1_(url)
		if l1llll_l1_: return l11ll1_l1_ (u"ࠨࠩ呕"),l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡁࡓࡃࡅࠫ呖"),[],[]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭呗"),[l11ll1_l1_ (u"ࠫࠬ员")],[url]
def l1l1l1l1ll1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭呙"),l11ll1_l1_ (u"࠭ࠧ呚"),l11ll1_l1_ (u"ࠧࠨ呛"),url)
	l1llll11_l1_,l1111llll11l_l1_ = [],[]
	if l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴ࠰ࡰࡴ࠹ࡅࡶࡪࡦࡀࠫ呜") in url:
		# l111ll111l11_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_111111l11l1_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1111l1l_l1_?l1l1l1ll1l1_l1_=49e3a27b4
		# l1111ll111ll_l1_: https://l111l1l111l1_l1_.l1lll1lllll_l1_.l1lllll11lll1_l1_.l1llll111ll_l1_/15/items/40animeHD/l111l11ll1l1_l1_.l1111l1l_l1_
		# l111ll111l11_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l11111ll1ll1_l1_-l111l1ll11l1_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1111l1l_l1_?l1l1l1ll1l1_l1_=l1llllll1l1ll_l1_
		# l1111ll111ll_l1_: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l11ll11ll1_l1_/l111l111ll1l_l1_%20.l1111l1l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭呝"),url,l11ll1_l1_ (u"ࠪࠫ呞"),l11ll1_l1_ (u"ࠫࠬ呟"),False,l11ll1_l1_ (u"ࠬ࠭呠"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨ呡"))
		if l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ呢") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ呣")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ呤"))
			l1111llll11l_l1_.append(server)
	elif l11ll1_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ呥") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111ll111l11_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l111lll1l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1111ll1l_l1_&l1llllll11l11_l1_=
		# l111ll111l11_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?url=l1lllll1ll111_l1_==&sub=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111ll11l1l1_l1_/l1lllll1l1ll1_l1_.l1lllllll111l_l1_&l1llllll11l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111111ll1ll_l1_/l1lllll11111l_l1_-1.l11111ll11l1_l1_
		# l111ll111l11_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l111l11l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l1111lll1111_l1_/?url=https://photos.l11l11111ll_l1_.l111ll111111_l1_.l11l1l11l11l_l1_/l111l1l1111l_l1_&sub=&l1llllll11l11_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111111ll1ll_l1_/4723b8ebe-1.l11111ll11l1_l1_
		# l111ll111l11_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l11l111l1_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://l1l11ll1l11_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1111ll1l_l1_&sub=&l1llllll11l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111111ll1ll_l1_/2e8bc4c34-1.l11111ll11l1_l1_
		# l111ll111l11_l1_:
		# https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1111l111ll1_l1_.html
		# https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l11l11l1l11l_l1_/?l1lllll_l1_=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1111llll_l1_=l11l1111ll11_l1_&l1llllll11l11_l1_=https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111111ll1ll_l1_/l111ll1111ll_l1_-1.l11111ll11l1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ呦"),url,l11ll1_l1_ (u"ࠬ࠭呧"),l11ll1_l1_ (u"࠭ࠧ周"),l11ll1_l1_ (u"ࠧࠨ呩"),l11ll1_l1_ (u"ࠨࠩ呪"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠳ࡰࡧࠫ呫"))
		html = response.content
		l1ll1l1lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࡧࡠ࠮࠴ࠪࡀ࡞ࠬࡠ࠮࠯࠮࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ呬"),html,re.DOTALL)
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ呭"),str(l1ll1l1lll11_l1_))
		if l1ll1l1lll11_l1_:
			l1ll1l1lll11_l1_ = l1ll1l1lll11_l1_[0]
			l1l1lll1111l_l1_ = l1ll1111ll11_l1_(l1ll1l1lll11_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭呮"),str(l1l1lll1111l_l1_))
			l1l1ll11llll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ呯"),l1l1lll1111l_l1_,re.DOTALL)
			if l1l1ll11llll_l1_:
				l1l1ll11llll_l1_ = l1l1ll11llll_l1_[0]
				l1l1ll11llll_l1_ = EVAL(l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ呰"),l1l1ll11llll_l1_)
				for dict in l1l1ll11llll_l1_:
					l1lllll_l1_ = dict[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪ࠭呱")]
					l111llll_l1_ = dict[l11ll1_l1_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ呲")]
					#l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭味")+l111llll_l1_
					l1llll11_l1_.append(l1lllll_l1_)
					server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ呴"))
					l1111llll11l_l1_.append(l111llll_l1_+l11ll1_l1_ (u"ࠬࠦࠧ呵")+server)
		elif l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ呶") in response.headers:
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ呷")]
			l1llll11_l1_.append(l1lllll_l1_)
			server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭呸"))
			l1111llll11l_l1_.append(server)
		# l111ll111l11_l1_: 5
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111l111l11l_l1_.html
		# l1lllll_l1_: https://www.l1l1l1ll111_l1_.com/l1llllll1l1l1_l1_/l1111lll1111_l1_/?url=https://photos.l11l11111ll_l1_.l111ll111111_l1_.l11l1l11l11l_l1_/l111l1l1111l_l1_&sub=&l1llllll11l11_l1_=http://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1llllllll1ll_l1_/l111111ll1ll_l1_/4723b8ebe-1.l11111ll11l1_l1_
		if l11ll1_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ呹") in url:
			l1lllll_l1_ = url.split(l11ll1_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࠩ呺"))[1]
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࠫ࠭呻"))[0]
			if l1lllll_l1_:
				l1llll11_l1_.append(l1lllll_l1_)
				l1111llll11l_l1_.append(l11ll1_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ呼"))
	else:
		# l111ll111l11_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1llllll111l1_l1_.html
		# l1lllll_l1_: http://ok.l111ll11111l_l1_/l111ll1llll1_l1_/1676019108395
		# l111ll111l11_l1_:
		# url: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1llllll1l11l_l1_.html
		# l1lllll_l1_: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1111ll1l_l1_
		l1llll11_l1_.append(url)
		server = SERVER(url,l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ命"))
		l1111llll11l_l1_.append(server)
	if not l1llll11_l1_: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ呾"),[],[]
	elif len(l1llll11_l1_)==1: l1lllll_l1_ = l1llll11_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭呿"),l1111llll11l_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ咀"),[],[]
		l1lllll_l1_ = l1llll11_l1_[l1l_l1_]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭咁"),[l11ll1_l1_ (u"ࠫࠬ咂")],[l1lllll_l1_]
def l111l111l1ll_l1_(url):
	# test from: https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11l111l111l_l1_-l111l111lll1_l1_-l1111ll11l11_l1_-l11111l1l11l_l1_-l11111ll111l_l1_-l11ll11ll1_l1_-1-date.html
	# url = https://l111llll111l_l1_.l1lllll1111l1_l1_.com/l1111l1lll1l_l1_=l111l1l1llll_l1_
	headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ咃"):l11ll1_l1_ (u"࠭ࡋࡰࡦ࡬࠳ࠬ咄")+str(kodi_version)}
	for l11ll11111_l1_ in range(50):
		time.sleep(0.100)
		response = l1l111l1ll1_l1_(l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ咅"),url,l11ll1_l1_ (u"ࠨࠩ咆"),headers,False,l11ll1_l1_ (u"ࠩࠪ咇"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ咈"))
		if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咉") in list(response.headers.keys()):
			l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咊")]
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ咋")+headers[l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ和")]
			return l11ll1_l1_ (u"ࠨࠩ咍"),[l11ll1_l1_ (u"ࠩࠪ咎")],[l1lllll_l1_]
		if response.code!=429: break
	return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ咏"),[],[]
def l111l1l1l1ll_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ咐"),l11ll1_l1_ (u"ࠬ࠭咑"),l11ll1_l1_ (u"࠭ࠧ咒"),url)
	# https://photos.l11l11111ll_l1_.l111ll111111_l1_.l11l1l11l11l_l1_/l111l1l1111l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ咓"),url,l11ll1_l1_ (u"ࠨࠩ咔"),l11ll1_l1_ (u"ࠩࠪ咕"),l11ll1_l1_ (u"ࠪࠫ咖"),l11ll1_l1_ (u"ࠫࠬ咗"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫ咘"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ咙"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_,l111llll_l1_ = l1lllll_l1_[0]
		return l11ll1_l1_ (u"ࠧࠨ咚"),[l111llll_l1_],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩ咛"),[],[]
def l1ll1l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ咜"),l11ll1_l1_ (u"ࠪࠫ咝"),l11ll1_l1_ (u"ࠫࠬ咞"),url)
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡴࡴࡥ࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡪ࡫ࡨ࠷࠱࠺ࡦ࠵࠾࠸ࡣ࠳࠺ࡧ࠵࠶࠸࠰࠳ࡣࡧ࠵࠽ࡪࡤ࠲࠴ࡦ࠺࠽࠶࠶ࠨ咟")
	#url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡶࡩࡱ࡮ࡤ࠮ࡧࡰࡦࡪࡪ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡦ࠵࠷࠵࠺࠲࠷ࡥ࠽ࡧࡣࡧ࠹࠼࠹࠻ࡪ࠱ࡦ࠹࠹࠷࠵ࡨࡥ࠲࠹࠹࠹࠽࠽࠳ࠨ咠")
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ咡"),url,l11ll1_l1_ (u"ࠨࠩ咢"),l11ll1_l1_ (u"ࠩࠪ咣"),l11ll1_l1_ (u"ࠪࠫ咤"),l11ll1_l1_ (u"ࠫࠬ咥"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ咦"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧ咧"),html)
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ咨"),html,re.DOTALL)
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠨࠩ咩"),[l11ll1_l1_ (u"ࠩࠪ咪")],[l1lllll_l1_[0]]
	return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ咫"),[],[]
def l1llllll1l_l1_(url):
	if l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ咬") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ咭"),url,l11ll1_l1_ (u"࠭ࠧ咮"),l11ll1_l1_ (u"ࠧࠨ咯"),l11ll1_l1_ (u"ࠨࠩ咰"),l11ll1_l1_ (u"ࠩࠪ咱"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪ咲"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ咳"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0]
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ咴") in l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ咵"),[l11ll1_l1_ (u"ࠧࠨ咶")],[l1lllll_l1_]
		return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪ咷"),[],[]
	else: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ咸"),[l11ll1_l1_ (u"ࠪࠫ咹")],[url]
def l1lll1lll11_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ咺"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭咻"),l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ咼"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ咽")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭咾"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ咿"),l11ll1_l1_ (u"ࠪࠫ哀"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫ品"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ哂"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨ哃"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ哄"),[l11ll1_l1_ (u"ࠨࠩ哅")],[l1lllll_l1_]
def l1l1l11ll11l_l1_(url):
	headers = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ哆"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ哇")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ哈"),url,l11ll1_l1_ (u"ࠬ࠭哉"),headers,l11ll1_l1_ (u"࠭ࠧ哊"),l11ll1_l1_ (u"ࠧࠨ哋"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪ哌"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ响"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧ哎"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ哏"),[l11ll1_l1_ (u"ࠬ࠭哐")],[l1lllll_l1_]
def l1l1lll1ll1_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ哑"):l11ll1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ哒")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭哓"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠩࠪ哔"),l11ll1_l1_ (u"ࠪࠫ哕"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭哖"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ哗"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪ哘"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ哙") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ哚")+l1lllll_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ哛"),l11ll1_l1_ (u"ࠪࠫ哜"),l11ll1_l1_ (u"ࠫࠬ哝"),l1lllll_l1_)
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ哞"),[l11ll1_l1_ (u"࠭ࠧ哟")],[l1lllll_l1_]
def l1lll11ll1_l1_(url):
	l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭哠"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ員")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ哢"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠪࠫ哣"),l11ll1_l1_ (u"ࠫࠬ哤"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ哥"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ哦"),html,re.DOTALL|re.IGNORECASE)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡁࡃࡆࡒࠫ哧"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ哨"),[l11ll1_l1_ (u"ࠩࠪ哩")],[l1lllll_l1_]
def l1llll111l11_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ哪"),l11ll1_l1_ (u"ࠫࠬ哫"),l11ll1_l1_ (u"ࠬ࠭哬"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ哭"),url,l11ll1_l1_ (u"ࠧࠨ哮"),l11ll1_l1_ (u"ࠨࠩ哯"),l11ll1_l1_ (u"ࠩࠪ哰"),l11ll1_l1_ (u"ࠪࠫ哱"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪ哲"))
	html = response.content
	l1llllll111ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ哳"),html,re.DOTALL|re.IGNORECASE)
	if l1llllll111ll_l1_:
		l1llllll111ll_l1_ = l1llllll111ll_l1_[0][2:]
		#l1llllll111ll_l1_ = l1llllll111ll_l1_.decode(l11ll1_l1_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭哴"))
		l1llllll111ll_l1_ = base64.b64decode(l1llllll111ll_l1_)
		if kodi_version>18.99: l1llllll111ll_l1_ = l1llllll111ll_l1_.decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ哵"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭哶"),l1llllll111ll_l1_,re.DOTALL)
	else: l1lllll_l1_ = l11ll1_l1_ (u"ࠩࠪ哷")
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫ哸"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ哹") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ哺")+l1lllll_l1_
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ哻"),[l11ll1_l1_ (u"ࠧࠨ哼")],[l1lllll_l1_]
def l111111111l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ哽"),url,l11ll1_l1_ (u"ࠩࠪ哾"),l11ll1_l1_ (u"ࠪࠫ哿"),l11ll1_l1_ (u"ࠫࠬ唀"),l11ll1_l1_ (u"ࠬ࠭唁"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨ唂"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唃"),html,re.DOTALL)
	if not l1lllll_l1_: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬ唄"),[],[]
	l1lllll_l1_ = l1lllll_l1_[0]
	return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ唅"),[l11ll1_l1_ (u"ࠪࠫ唆")],[l1lllll_l1_]
def l11lll1l1l_l1_(url):
	id = url.split(l11ll1_l1_ (u"ࠫ࠴࠭唇"))[-1]
	if l11ll1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ唈") in url: url = url.replace(l11ll1_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭唉"),l11ll1_l1_ (u"ࠧࠨ唊"))
	url = url.replace(l11ll1_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࠧ唋"),l11ll1_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪ唌"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ唍"),url,l11ll1_l1_ (u"ࠫࠬ唎"),l11ll1_l1_ (u"ࠬ࠭唏"),l11ll1_l1_ (u"࠭ࠧ唐"),l11ll1_l1_ (u"ࠧࠨ唑"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭唒"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ唓"),url)
	l11l11ll1l1l_l1_ = l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ唔")
	error = re.findall(l11ll1_l1_ (u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ唕"),html,re.DOTALL)
	if error: l11l11ll1l1l_l1_ = error[0]
	url = re.findall(l11ll1_l1_ (u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ唖"),html,re.DOTALL)
	if not url and l11l11ll1l1l_l1_:
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ唗"),l11ll1_l1_ (u"ࠧࠨ唘"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠪ唙"),l11l11ll1l1l_l1_)
		return l11l11ll1l1l_l1_,[],[]
	l1lllll_l1_ = url[0].replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠬ唚"),l11ll1_l1_ (u"ࠪࠫ唛"))
	l11ll111ll11_l1_,l11ll11l1l11_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
	owner = re.findall(l11ll1_l1_ (u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿ࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ唜"),html,re.DOTALL)
	if owner: l1111l1ll1ll_l1_,l11l11l11l1l_l1_,l111ll1l1ll1_l1_ = owner[0]
	else: l1111l1ll1ll_l1_,l11l11l11l1l_l1_,l111ll1l1ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭唝"),l11ll1_l1_ (u"࠭ࠧ唞"),l11ll1_l1_ (u"ࠧࠨ唟")
	l111ll1l1ll1_l1_ = l111ll1l1ll1_l1_.replace(l11ll1_l1_ (u"ࠨ࡞࠲ࠫ唠"),l11ll1_l1_ (u"ࠩ࠲ࠫ唡"))
	l11l11l11l1l_l1_ = escapeUNICODE(l11l11l11l1l_l1_)
	l1lll11l_l1_ = [l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ唢")+l11l11l11l1l_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭唣")]+l11ll111ll11_l1_
	l1llll_l1_ = [l111ll1l1ll1_l1_]+l11ll11l1l11_l1_
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭唤")+str(len(l1llll_l1_)-1)+l11ll1_l1_ (u"࠭ࠠๆๆไ࠭ࠬ唥"),l1lll11l_l1_)
	if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ唦"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11ll1_l1_ (u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧ唧")+l111ll1l1ll1_l1_+l11ll1_l1_ (u"ࠩࠩࡸࡪࡾࡴ࠾ࠩ唨")+l11l11l11l1l_l1_
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ唩")+new_path+l11ll1_l1_ (u"ࠦ࠮ࠨ唪"))
		return l11ll1_l1_ (u"ࠬࡋࡘࡊࡖࠪ唫"),[],[]
	l1lllll_l1_ =  l1llll_l1_[l1l_l1_]
	return l11ll1_l1_ (u"࠭ࠧ唬"),[l11ll1_l1_ (u"ࠧࠨ唭")],[l1lllll_l1_]
def l11111lll_l1_(l1lllll_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ售"),l1lllll_l1_,l11ll1_l1_ (u"ࠩࠪ唯"),l11ll1_l1_ (u"ࠪࠫ唰"),l11ll1_l1_ (u"ࠫࠬ唱"),l11ll1_l1_ (u"ࠬ࠭唲"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅࡓࡐࡘࡁ࠮࠳ࡶࡸࠬ唳"))
	html = response.content
	if l11ll1_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭唴") in l1lllll_l1_: url = re.findall(l11ll1_l1_ (u"ࠨࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ唵"),html,re.DOTALL)
	else: url = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ唶"),html,re.DOTALL)
	if not url: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡏࡌࡔࡄࠫ唷"),[],[]
	url = url[0]
	if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ唸") not in url: url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ唹")+url
	return l11ll1_l1_ (u"࠭ࠧ唺"),[l11ll1_l1_ (u"ࠧࠨ唻")],[url]
def l111llllll1l_l1_(url):
	# http://l1111l11ll11_l1_.l1lll1ll1111_l1_/l11l11l1ll11_l1_.html?l11l111l1lll_l1_=l111l11l1111_l1_
	# http://l1111l11ll11_l1_.l1lll1ll1111_l1_/l111llllll11_l1_?op=l1lllll1l111l_l1_&id=l11l11l1ll11_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ唼") : l11ll1_l1_ (u"ࠩࠪ唽") }
	if l11ll1_l1_ (u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭唾") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ唿"),headers,l11ll1_l1_ (u"ࠬ࠭啀"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠶ࡹࡴࠨ啁"))
		#xbmc.log(html)
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ啂"),l11ll1_l1_ (u"ࠨࠩ啃"),url,html)
		items = re.findall(l11ll1_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ啄"),html,re.DOTALL)
		if items: return l11ll1_l1_ (u"ࠪࠫ啅"),[l11ll1_l1_ (u"ࠫࠬ商")],[items[0]]
		else:
			message = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ啇"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ啈"),l11ll1_l1_ (u"ࠧࠨ啉"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ啊"),message[0])
				return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ啋")+message[0],[],[]
	else:
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ啌"),l11ll1_l1_ (u"ࠫࠬ啍"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭啎"))
		#url,l1ll1lll1l1_l1_ = url.split(l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ問"))
		#l1ll1lll1l1_l1_ = l1ll1lll1l1_l1_.lower()
		l1ll1lll1l1_l1_ = l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ啐")
		# l11l1l1ll_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ啑"),headers,l11ll1_l1_ (u"ࠩࠪ啒"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬ啓"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭啔"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ啕"),[],[]
		l1lllll11l_l1_ = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		if l11ll1_l1_ (u"࠭࠮ࡳࡣࡵࠫ啖") in block or l11ll1_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ啗") in block: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭啘"),[],[]
		items = re.findall(l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ啙"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l11l_l1_(payload)
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll11l_l1_,data,headers,l11ll1_l1_ (u"ࠪࠫ啚"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭啛"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ啜"),html,re.DOTALL)
		if not l1l1l11_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ啝"),[],[]
		download = l1l1l11_l1_[0][0]
		block = l1l1l11_l1_[0][1]
		items = re.findall(l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ啞"),block,re.DOTALL)
		l1111111l1ll_l1_,l1lll11l_l1_,l11l1111l1ll_l1_,l1llll_l1_,l11111lll11l_l1_ = [],[],[],[],[]
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ啟") in l1lllll_l1_:
				l1111111l1ll_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11l1111l1ll_l1_
				if l1111111l1ll_l1_[0]==l11ll1_l1_ (u"ࠩ࠰࠵ࠬ啠"): l1lll11l_l1_.append(l11ll1_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ啡")+l11ll1_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ啢")+l1ll1lll1l1_l1_)
				else:
					for title in l1111111l1ll_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ啣")+l11ll1_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ啤")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠧࠡࠩ啥")+title)
			else:
				title = title.replace(l11ll1_l1_ (u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪ啦"),l11ll1_l1_ (u"ࠩࠪ啧"))
				title = title.strip(l11ll1_l1_ (u"ࠪࠦࠬ啨"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ啩"),l11ll1_l1_ (u"ࠬ࠭啪"),title,str(l11111lll11l_l1_))
				title = l11ll1_l1_ (u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ啫")+l11ll1_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭啬")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠨࠢࠪ啭")+title
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		# download l1l1_l1_
		l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ啮") + download
		html = OPENURL_CACHED(l1ll1lll1_l1_,l1lllll_l1_,l11ll1_l1_ (u"ࠪࠫ啯"),headers,l11ll1_l1_ (u"ࠫࠬ啰"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧ啱"))
		items = re.findall(l11ll1_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥ啲"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11ll1_l1_ (u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫ啳")+l11ll1_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ啴")+l1ll1lll1l1_l1_+l11ll1_l1_ (u"ࠩࠣࠫ啵")+resolution.split(l11ll1_l1_ (u"ࠪࡼࠬ啶"))[1]
			l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ啷")+id+l11ll1_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ啸")+mode+l11ll1_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭啹")+hash
			l11111lll11l_l1_.append(resolution)
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		l11111lll11l_l1_ = set(l11111lll11l_l1_)
		l1111l1l1111_l1_,l111ll1ll1l1_l1_ = [],[]
		for title in l1lll11l_l1_:
			#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ啺"),l11ll1_l1_ (u"ࠨࠩ啻"),title,l11ll1_l1_ (u"ࠩࠪ啼"))
			res = re.findall(l11ll1_l1_ (u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥ啽"),title+l11ll1_l1_ (u"ࠫࠫࠬࠧ啾"),re.DOTALL)
			for resolution in l11111lll11l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11ll1_l1_ (u"ࠬࡾࠧ啿"))[1])
			l1111l1l1111_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1llll_l1_)):
			items = re.findall(l11ll1_l1_ (u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢ喀"),l11ll1_l1_ (u"ࠧࠧࠨࠪ喁")+l1111l1l1111_l1_[i]+l11ll1_l1_ (u"ࠨࠨࠩࠫ喂"),re.DOTALL)
			l111ll1ll1l1_l1_.append( [l1111l1l1111_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l111ll1ll1l1_l1_ = sorted(l111ll1ll1l1_l1_, key=lambda x: x[3], reverse=True)
		l111ll1ll1l1_l1_ = sorted(l111ll1ll1l1_l1_, key=lambda x: x[2], reverse=False)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for i in range(len(l111ll1ll1l1_l1_)):
			l1lll11l_l1_.append(l111ll1ll1l1_l1_[i][0])
			l1llll_l1_.append(l111ll1ll1l1_l1_[i][1])
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭喃"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ善"),l1lll11l_l1_,l1llll_l1_
def l111lll111l1_l1_(url):
	# http://l1lllll1l1111_l1_.com/717254
	parts = url.split(l11ll1_l1_ (u"ࠫࡄ࠭喅"))
	l111lll_l1_ = parts[0]
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ喆") : l11ll1_l1_ (u"࠭ࠧ喇") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ喈"),headers,l11ll1_l1_ (u"ࠨࠩ喉"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩ喊"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ喋"),html,re.DOTALL)
	url = items[0]
	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllllll_l1_(url)
	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ喌"),[l11ll1_l1_ (u"ࠬ࠭喍")],[url]
def l1111ll1llll_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ喎") : l11ll1_l1_ (u"ࠧࠨ喏") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠨࠩ喐"),headers,l11ll1_l1_ (u"ࠩࠪ喑"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ喒"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ喓"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠬ࠭喔"),[l11ll1_l1_ (u"࠭ࠧ喕")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪ喖"),[],[]
def l111lll11ll1_l1_(url):
	# https://l1lllll1111_l1_.l1llll111ll_l1_/l1lllll11ll_l1_
	# https://l1llll11l11_l1_.cc/l1lllll11ll_l1_
	l1lll11l_l1_,l1llll_l1_ = [],[]
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ喗") : l11ll1_l1_ (u"ࠩࠪ喘") }
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠪࠫ喙"),headers,l11ll1_l1_ (u"ࠫࠬ喚"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ喛"))
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩ喜"),html,re.DOTALL)
	if l111lll_l1_: return l11ll1_l1_ (u"ࠧࠨ喝"),[l11ll1_l1_ (u"ࠨࠩ喞")],[l111lll_l1_[0]]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ喟"),[],[]
def l1ll1l1l1l1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ喠"),l11ll1_l1_ (u"ࠫࠬ喡"),l11ll1_l1_ (u"ࠬ࠭喢"),url)
	# l11l1l1ll_l1_    https://show.l1111l1lllll_l1_.com/l1111l1l1l1l_l1_-l1111l1l111l_l1_/l1111l1l111l_l1_-l111l1ll1l11_l1_.l1ll1lll1l_l1_?action=l11111lll1l1_l1_&post=32513&l1ll1l1l1ll_l1_=1&type=l1lllll111l_l1_
	# download https://show.l1111l1lllll_l1_.com/l1l1_l1_/l1lllllllll11_l1_
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"࠭ࠧ喣")
	# l11l1l1ll_l1_
	if l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࠫ喤") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ喥"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ喦")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ喧"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"ࠫࠬ喨"),l11ll1_l1_ (u"ࠬ࠭喩"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩ喪"))
		l11ll1ll_l1_ = response.content
		if l11ll1ll_l1_.startswith(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ喫")): l111lll_l1_ = l11ll1ll_l1_
		else:
			l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩ喬"),l11ll1ll_l1_,re.DOTALL)
			if l11l111_l1_:
				l111lll_l1_ = l11l111_l1_[0]
				l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩࠥࠩ喭"),l111lll_l1_,re.DOTALL)
				if l11l111_l1_:
					l111lll_l1_ = l1111_l1_(l11l111_l1_[0])
					return l11ll1_l1_ (u"ࠪࠫ單"),[l11ll1_l1_ (u"ࠫࠬ喯")],[l111lll_l1_]
	# download
	elif l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࠭喰") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ喱"),url,l11ll1_l1_ (u"ࠧࠨ喲"),l11ll1_l1_ (u"ࠨࠩ喳"),True,l11ll1_l1_ (u"ࠩࠪ喴"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠴ࡷࡹ࠭喵"))
		l11ll1ll_l1_ = response.content
		if l11ll1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭営") in list(response.headers.keys()): l111lll_l1_ = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ喷")]
		else: l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ喸"),l11ll1ll_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ喹"),l11ll1_l1_ (u"ࠨࠩ喺"),l111lll_l1_,str(2222))
	if l11ll1_l1_ (u"ࠩ࠲ࡺ࠴࠭喻") in l111lll_l1_ or l11ll1_l1_ (u"ࠪ࠳࡫࠵ࠧ喼") in l111lll_l1_:
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴࡬࠯ࠨ喽"),l11ll1_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ喾"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠯ࡷ࠱ࠪ喿"),l11ll1_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭嗀"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ嗁"),l11ll1_l1_ (u"ࠩࠪ嗂"),l111lll_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ嗃"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ嗄"),l11ll1_l1_ (u"ࠬ࠭嗅"),l11ll1_l1_ (u"࠭ࠧ嗆"),l11ll1_l1_ (u"ࠧࠨ嗇"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ嗈"))
		l11ll1ll_l1_ = response.content
		items = re.findall(l11ll1_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嗉"),l11ll1ll_l1_,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡡ࠭嗊"),l11ll1_l1_ (u"ࠫࠬ嗋"))
				l1lll11l_l1_.append(title)
				l1llll_l1_.append(l1lllll_l1_)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嗌"),l11ll1ll_l1_,re.DOTALL)
			if items:
				l1lllll_l1_ = items[0]
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜࡝ࠩ嗍"),l11ll1_l1_ (u"ࠧࠨ嗎"))
				l1lll11l_l1_.append(l11ll1_l1_ (u"ࠨࠩ嗏"))
				l1llll_l1_.append(l1lllll_l1_)
	else: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嗐"),[l11ll1_l1_ (u"ࠪࠫ嗑")],[l111lll_l1_]
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嗒"),l11ll1_l1_ (u"ࠬ࠭嗓"),str(l11ll11l1_l1_),l111lll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ嗔"),[],[]
	return l11ll1_l1_ (u"ࠧࠨ嗕"),l1lll11l_l1_,l1llll_l1_
def l1l1llll1l11_l1_(url):
	# l11l1l1ll_l1_ l1111l1l_l1_  https://l111l1111ll1_l1_.l11l1111l11l_l1_.l1llll111ll_l1_/l11llll1l11_l1_/l1llll1lllll1_l1_.l1ll1lll1l_l1_?s=07&id=l11l11lll111_l1_,&l1lll1_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l11111ll11l1_l1_&l111ll1l1111_l1_=l1llllll11111_l1_&l1111ll1l11l_l1_=l1lllll11l11l_l1_
	# l11l1l1ll_l1_ l1llll111_l1_ https://l11l1111lll1_l1_.l11l1111l11l_l1_.l1llll111ll_l1_/l11llll1l11_l1_/l1llllll1lll1_l1_.l1ll1lll1l_l1_?l111lll1llll_l1_=l1111l11ll1l_l1_&l111l11ll1ll_l1_=8a26a6cc61a884e89076504130c71626&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111ll11l1_l1_&l111ll1l1111_l1_=l1llllll11111_l1_&l1lll1_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111ll11l1_l1_&l111ll1l1111_l1_=l1llllll11111_l1_&l1111ll1l11l_l1_=l1111l11lll1_l1_
	# download https://www.l111lllll1ll_l1_.l1111l1l1ll1_l1_/l111ll1l1lll_l1_?server=l1llllll1ll11_l1_&id=l111l1l1ll1l_l1_,,
	# l1l111l1l_l1_ https://l111lllll1ll_l1_.l1lll1111l_l1_/l1l111l1l_l1_/l111ll11l11l_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ嗖"),url,l11ll1_l1_ (u"ࠩࠪ嗗"),l11ll1_l1_ (u"ࠪࠫ嗘"),l11ll1_l1_ (u"ࠫࠬ嗙"),l11ll1_l1_ (u"ࠬ࠭嗚"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭嗛"))
	html = response.content
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠧࠨ嗜")
	if l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ嗝") in url or l11ll1_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ嗞") in url:
		if l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭嗟") in url:
			l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗠"),html,re.DOTALL)
			l111lll_l1_ = l111lll_l1_[0]
		else: l111lll_l1_ = url
		if l11ll1_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ嗡") not in l111lll_l1_: return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嗢"),[l11ll1_l1_ (u"ࠧࠨ嗣")],[l111lll_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ嗤"),l111lll_l1_,l11ll1_l1_ (u"ࠩࠪ嗥"),l11ll1_l1_ (u"ࠪࠫ嗦"),l11ll1_l1_ (u"ࠫࠬ嗧"),l11ll1_l1_ (u"ࠬ࠭嗨"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭嗩"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪ嗪"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗫"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,l1ll1l1l1ll1_l1_ in items:
				l1lll11l_l1_.append(l1ll1l1l1ll1_l1_)
				l1llll_l1_.append(l1lllll_l1_)
	elif l11ll1_l1_ (u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫ嗬") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ嗭"),html,re.DOTALL)
		l111lll_l1_ = l111lll_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嗮"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭嗯"),l11ll1_l1_ (u"࠭ࠧ嗰"),l11ll1_l1_ (u"ࠧࠨ嗱"),l11ll1_l1_ (u"ࠨࠩ嗲"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ嗳"))
		html = response.content
		l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ嗴"),html,re.DOTALL)
		l11l111_l1_ = l11l111_l1_[0]
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠫࠬ嗵"))
		l1llll_l1_.append(l11l111_l1_)
	elif l11ll1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬ嗶") in url:
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗷"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嗸"),[l11ll1_l1_ (u"ࠨࠩ嗹")],[l111lll_l1_]
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ嗺"),[],[]
	return l11ll1_l1_ (u"ࠪࠫ嗻"),l1lll11l_l1_,l1llll_l1_
def l11111l1ll_l1_(url):
	# https://l111lll1l111_l1_.l1111ll1111l_l1_/l1l1111lll1_l1_?call=l111ll11ll11_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111l1lll_l1_=l111l111ll11_l1_
	# https://l111lll1l111_l1_.l1111ll1111l_l1_/l1l1111lll1_l1_?call=l111ll11ll11_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111l1lll_l1_=l1111l1l1l11_l1_
	l111lll_l1_ = url.split(l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嗼"),1)[0].strip(l11ll1_l1_ (u"ࠬࡅࠧ嗽")).strip(l11ll1_l1_ (u"࠭࠯ࠨ嗾")).strip(l11ll1_l1_ (u"ࠧࠧࠩ嗿"))
	l1lll11l_l1_,l1llll_l1_,items,l11l111_l1_ = [],[],[],l11ll1_l1_ (u"ࠨࠩ嘀")
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嘁"):l11ll1_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠪ嘂") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ嘃"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭嘄"),headers,True,l11ll1_l1_ (u"࠭ࠧ嘅"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠶ࡹࡴࠨ嘆"))
	if l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ嘇") in list(response.headers.keys()): l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ嘈")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嘉"),l11l111_l1_,l11ll1_l1_ (u"ࠫࠬ嘊"),headers,False,l11ll1_l1_ (u"ࠬ࠭嘋"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠶ࡳࡪࠧ嘌"))
	#if l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ嘍") in response.headers: l11l111_l1_ = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ嘎")]
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嘏"),l11ll1_l1_ (u"ࠪࠫ嘐"),l11l111_l1_,response.content)
	if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嘑") in l11l111_l1_:
		# https://l1111l111l_l1_.top/f/l111l1lll11l_l1_/?l111ll1111_l1_=l11l1l111l11_l1_
		# https://l1111l111l_l1_.top/v/l111l1lll11l_l1_/?l111ll1111_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嘒") in url: l11l111_l1_ = l11l111_l1_.replace(l11ll1_l1_ (u"࠭࠯ࡧ࠱ࠪ嘓"),l11ll1_l1_ (u"ࠧ࠰ࡸ࠲ࠫ嘔"))
		l11l111lll11_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪ嘕"))[1]
		headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嘖"):headers[l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ嘗")] , l11ll1_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ嘘"):l11ll1_l1_ (u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭嘙")+l11l111lll11_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ嘚"),l11l111_l1_,l11ll1_l1_ (u"ࠧࠨ嘛"),headers,False,l11ll1_l1_ (u"ࠨࠩ嘜"),l11ll1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ嘝"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1lll1_l1_,l11l111_l1_,l11ll1_l1_ (u"ࠪࠫ嘞"),headers,l11ll1_l1_ (u"ࠫࠬ嘟"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠶ࡶࡩ࠭嘠"))
		if l11ll1_l1_ (u"࠭࠯ࡧ࠱ࠪ嘡") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡪ࠵ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘢"),html,re.DOTALL)
		elif l11ll1_l1_ (u"ࠨ࠱ࡹ࠳ࠬ嘣") in l11l111_l1_: items = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘤"),html,re.DOTALL)
		if items: return [],[l11ll1_l1_ (u"ࠪࠫ嘥")],[ items[0] ]
		elif l11ll1_l1_ (u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪ嘦") in html:
			return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้หๆหำ้ฮࠥอไฯษุอࠥฮใࠨ嘧"),[],[]
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕࠩ嘨"),[],[]
	#xbmc.log(html)
def l1111ll1l1l_l1_(l1lllll_l1_):
	# https://l11l1l111lll_l1_.net/?l11lll11_l1_=147043&l11llll1_l1_=5
	parts = re.findall(l11ll1_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ嘩"),l1lllll_l1_+l11ll1_l1_ (u"ࠨࠨࠩࠫ嘪"),re.DOTALL|re.IGNORECASE)
	l11lll11_l1_,l11llll1_l1_ = parts[0]
	url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ嘫")+l11lll11_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ嘬")+l11llll1_l1_
	headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ嘭"):l11ll1_l1_ (u"ࠬ࠭嘮") , l11ll1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ嘯"):l11ll1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ嘰") }
	l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ嘱"),headers,l11ll1_l1_ (u"ࠩࠪ嘲"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩ嘳"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ嘴"),l11ll1_l1_ (u"ࠬ࠭嘵"),url,l111lll_l1_)
	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllllll_l1_(l111lll_l1_)
	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嘶"),[l11ll1_l1_ (u"ࠧࠨ嘷")],[l111lll_l1_]
def l1ll11lll11l_l1_(url):
	# https://l1lllll11ll1l_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111l1lll111_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111lll11111_l1_=1608181746
	server = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ嘸"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ嘹"):server,l11ll1_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ嘺"):l11ll1_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ嘻")}
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ嘼"),url,l11ll1_l1_ (u"࠭ࠧ嘽"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ嘾"),l11ll1_l1_ (u"ࠨࠩ嘿"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ噀"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ噁"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠫࠬ噂")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ噃"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ噄"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࠨ噅"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噆"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡃࡊࡏࡄࠫ噇"),[],[]
	return l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭噈"),[l11ll1_l1_ (u"ࠫࠬ噉")],[l111lll_l1_]
def l1l1ll111lll_l1_(url):
	# https://l11l1l11l111_l1_.l1111111111l_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111l1lll111_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111lll11111_l1_=1608181746
	# https://l11l1l11l111_l1_.l1111ll1111l_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111l1lll111_l1_=l11l11l1llll_l1_&l111lll11111_l1_=1684182121
	server = SERVER(url,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ噊"))
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ噋"):server,l11ll1_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ噌"):l11ll1_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨ噍")}
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭噎"),url,l11ll1_l1_ (u"ࠪࠫ噏"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠫࠬ噐"),l11ll1_l1_ (u"ࠬ࠭噑"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡉࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭噒"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨ噓"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠨࠩ噔")
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ噕"),block,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for title,l1lllll_l1_ in items:
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		if len(l1llll_l1_)==1: l111lll_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ噖"), l1lll11l_l1_)
			if l1l_l1_==-1: return l11ll1_l1_ (u"ࠫࠬ噗"),[],[]
			l111lll_l1_ = l1llll_l1_[l1l_l1_]
	if not l111lll_l1_:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ噘"),html,re.DOTALL)
		if l1l1l11_l1_: l111lll_l1_ = l1l1l11_l1_[0]
	if not l111lll_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁࠨ噙"),[],[]
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ噚"),[l11ll1_l1_ (u"ࠨࠩ噛")],[l111lll_l1_]
def l1l11ll1_l1_(l1lllll_l1_):
	# https://w.l1111l111l1l_l1_.l11l1111111l_l1_/l1111l1l1l1l_l1_-content/l11l11ll1lll_l1_/l1111l111111_l1_/l111llllllll_l1_/l11111llllll_l1_/l111l1111l1l_l1_/l1111l1ll111_l1_.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ噜"),l11ll1_l1_ (u"ࠪࠫ噝"),l1lllll_l1_,html)
	parts = re.findall(l11ll1_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ噞"),l1lllll_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ噟"),re.DOTALL)
	url,l11lll11_l1_,l11llll1_l1_ = parts[0]
	data = {l11ll1_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧ噠"):l11lll11_l1_,l11ll1_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ噡"):l11llll1_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭噢"),url,data,l11ll1_l1_ (u"ࠩࠪ噣"),l11ll1_l1_ (u"ࠪࠫ噤"),l11ll1_l1_ (u"ࠫࠬ噥"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ噦"))
	html = response.content
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噧"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ器"),[l11ll1_l1_ (u"ࠨࠩ噩")],[l111lll_l1_]
def l1ll1l1lll_l1_(url):
	# https://l111ll1lll11_l1_.l1lll11111_l1_-l111lll11lll_l1_.com/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1111ll1l1ll_l1_
	# https://l.l1111l1ll11l_l1_.l1111l1l1ll1_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭噪"),url,l11ll1_l1_ (u"ࠪࠫ噫"),l11ll1_l1_ (u"ࠫࠬ噬"),l11ll1_l1_ (u"ࠬ࠭噭"),l11ll1_l1_ (u"࠭ࠧ噮"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳࠱ࡴࡶࠪ噯"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ噰"),html,re.DOTALL)
	if l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_[0]
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ噱"),[l11ll1_l1_ (u"ࠪࠫ噲")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ噳"),[],[]
def l1lll111ll_l1_(url):
	# https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/l1111l1l1l1l_l1_-content/l11l11ll1lll_l1_/old/l1lll11_l1_/server.l1ll1lll1l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ噴"),url,l11ll1_l1_ (u"࠭ࠧ噵"),l11ll1_l1_ (u"ࠧࠨ噶"),l11ll1_l1_ (u"ࠨࠩ噷"),l11ll1_l1_ (u"ࠩࠪ噸"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬ噹"))
	html = response.content
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ噺"),html,re.DOTALL)[0]
	return l11ll1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ噻"),[l11ll1_l1_ (u"࠭ࠧ噼")],[l1lllll_l1_]
def l1ll1l1l1l_l1_(url):
	# https://l1l11l1l111_l1_.l1l11ll1l11l_l1_.cc/l1111l1l1l1l_l1_-content/l11l11ll1lll_l1_/l111111l1l11_l1_%20Now%20New/l1llllllll1l1_l1_.l1ll1lll1l_l1_?action=l111lll111ll_l1_&index=00&id=58504
	# https://l111l1ll1lll_l1_.l1l11ll1l11l_l1_.net/l1llllllll1ll_l1_/2021/04/05/_1111ll1ll1l_l1_-l11l1l1111l1_l1_.l1lllll111111_l1_ 200.l1lllllll11l1_l1_.2020.l11111111l1l_l1_/[l111111l1l11_l1_-l11l1l1111l1_l1_.l11111l111ll_l1_] 200.l1lllllll11l1_l1_.2020.l11111111l1l_l1_-360p.l1111l1l_l1_
	l1lllll1l1_l1_ = SERVER(url,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ噽"))
	if l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ噾") in url:
		headers = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ噿"):l1lllll1l1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嚀"),url,l11ll1_l1_ (u"ࠫࠬ嚁"),headers,l11ll1_l1_ (u"ࠬ࠭嚂"),l11ll1_l1_ (u"࠭ࠧ嚃"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ嚄"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嚅"),html,re.DOTALL)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			if l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ嚆") in l111lll_l1_:
				l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ嚇"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ嚈"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ嚉"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ嚊"),headers,l11ll1_l1_ (u"ࠧࠨ嚋"),l11ll1_l1_ (u"ࠨࠩ嚌"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ嚍"))
				l11ll1ll_l1_ = response.content
				items = re.findall(l11ll1_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚎"),l11ll1ll_l1_,re.DOTALL)
				l1lll11l_l1_,l1llll_l1_ = [],[]
				l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ嚏"))
				for l1lllll_l1_,l111llll_l1_ in reversed(items):
					l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ嚐")+l1llll1l1l_l1_
					l1lll11l_l1_.append(l111llll_l1_)
					l1llll_l1_.append(l1lllll_l1_)
				return l11ll1_l1_ (u"࠭ࠧ嚑"),l1lll11l_l1_,l1llll_l1_
			else: return l11ll1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嚒"),[l11ll1_l1_ (u"ࠨࠩ嚓")],[l111lll_l1_]
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ嚔")+l1lllll1l1_l1_
	return l11ll1_l1_ (u"ࠪࠫ嚕"),[l11ll1_l1_ (u"ࠫࠬ嚖")],[l111lll_l1_]
def l111l11l1lll_l1_(l1lllll_l1_):
	# https://l1l11ll1l11l_l1_.l11l1111111l_l1_/l1111l1l1l1l_l1_-content/l11l11ll1lll_l1_/l111lll1111l_l1_/l1lllllllll1l_l1_/server.l1ll1lll1l_l1_?l11lll11_l1_=42869&l11llll1_l1_=4
	# https://l11l111l1111_l1_.l1l11ll1l11l_l1_.net/l1llllllll1ll_l1_/2020/08/14/_1111ll1ll1l_l1_-l11l1l1111l1_l1_.l1lllll111111_l1_ l111111l111l_l1_.l111l111llll_l1_.2020.l1111lll1ll1_l1_-l111l11l1l11_l1_/[l111111l1l11_l1_-l11l1l1111l1_l1_.l11111l111ll_l1_] l111111l111l_l1_.l111l111llll_l1_.2020.l1111lll1ll1_l1_-l111l11l1l11_l1_-1080p.l1111l1l_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嚗"),l11ll1_l1_ (u"࠭ࠧ嚘"),url,html)
	l1lllll1l1_l1_ = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ嚙"))
	if l11ll1_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ嚚") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ嚛"),l1lllll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭嚜"),re.DOTALL)
		url,l11lll11_l1_,l11llll1_l1_ = parts[0]
		data = {l11ll1_l1_ (u"ࠫ࡮ࡪࠧ嚝"):l11lll11_l1_,l11ll1_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬ嚞"):l11llll1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ嚟"),url,data,l11ll1_l1_ (u"ࠧࠨ嚠"),l11ll1_l1_ (u"ࠨࠩ嚡"),l11ll1_l1_ (u"ࠩࠪ嚢"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ嚣"))
		html = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚤"),html,re.DOTALL)[0]
		if l11ll1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭嚥") in l111lll_l1_:
			headers = {l11ll1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ嚦"):l1lllll1l1_l1_,l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嚧"):l11ll1_l1_ (u"ࠨࠩ嚨")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭嚩"),l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ嚪"),headers,l11ll1_l1_ (u"ࠫࠬ嚫"),l11ll1_l1_ (u"ࠬ࠭嚬"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ嚭"))
			l11ll1ll_l1_ = response.content
			items = re.findall(l11ll1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嚮"),l11ll1ll_l1_,re.DOTALL)
			l1lll11l_l1_,l1llll_l1_ = [],[]
			l1llll1l1l_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ嚯"))
			for l1lllll_l1_,l111llll_l1_ in reversed(items):
				l1lllll_l1_ = l1llll1l1l_l1_+l1lllll_l1_+l11ll1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ嚰")+l1llll1l1l_l1_
				l1lll11l_l1_.append(l111llll_l1_)
				l1llll_l1_.append(l1lllll_l1_)
			return l11ll1_l1_ (u"ࠪࠫ嚱"),l1lll11l_l1_,l1llll_l1_
		else: return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ嚲"),[l11ll1_l1_ (u"ࠬ࠭嚳")],[l111lll_l1_]
	else:
		l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ嚴")+l1lllll1l1_l1_
		return l11ll1_l1_ (u"ࠧࠨ嚵"),[l11ll1_l1_ (u"ࠨࠩ嚶")],[l1lllll_l1_]
def l111ll1ll_l1_(l1lllll_l1_):
	# http://l11l11l1l1ll_l1_.tv/?l11lll11_l1_=159485&l11llll1_l1_=0
	if l11ll1_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ嚷") in l1lllll_l1_:
		parts = re.findall(l11ll1_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ嚸"),l1lllll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ嚹"),re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		host = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ嚺"))
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嚻"),l11ll1_l1_ (u"ࠧࠨ嚼"),l1lllll_l1_,host)
		url = host+l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭嚽")+l11lll11_l1_+l11ll1_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭嚾")+l11llll1_l1_
		headers = { l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ嚿"):l11ll1_l1_ (u"ࠫࠬ囀") , l11ll1_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ囁"):l11ll1_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ囂") }
		l111lll_l1_ = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ囃"),headers,l11ll1_l1_ (u"ࠨࠩ囄"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠲ࡵࡷࠫ囅"))
		l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭囆"),l11ll1_l1_ (u"ࠫࠬ囇")).replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ囈"),l11ll1_l1_ (u"࠭ࠧ囉"))
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ囊"),l11ll1_l1_ (u"ࠨࠩ囋"),url,l111lll_l1_)
		#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1lllllllllll_l1_(l111lll_l1_)
		#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
		return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ囌"),[l11ll1_l1_ (u"ࠪࠫ囍")],[l111lll_l1_]
	elif l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ囎") in l1lllll_l1_:
		counts = 0
		while l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ囏") in l1lllll_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ囐"),l1lllll_l1_,l11ll1_l1_ (u"ࠧࠨ囑"),l11ll1_l1_ (u"ࠨࠩ囒"),l11ll1_l1_ (u"ࠩࠪ囓"),l11ll1_l1_ (u"ࠪࠫ囔"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠵ࡲࡩ࠭囕"))
			if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ囖") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ囗")]
			counts += 1
		return l11ll1_l1_ (u"ࠧࠨ囘"),[l11ll1_l1_ (u"ࠨࠩ囙")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡂࡍࡋࡒࡒ࡟࠭囚"),[],[]
def l11l11ll1_l1_(url):
	# https://l1111ll111l1_l1_.l111111lllll_l1_.me/l/l11l11ll11l1_l1_=
	# https://l111ll11lll1_l1_.l11111111lll_l1_.net/l1l111l1l_l1_-l1l111l1l_l1_-l1111111ll1l_l1_.html
	# https://m.l11111111lll_l1_.net/l1111111ll1l_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ四"),l11ll1_l1_ (u"ࠫࠬ囜"),l11ll1_l1_ (u"ࠬ࠭囝"),url)
	server = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ回"))
	if l11ll1_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡲࡢࡶࡨࠫ囟") in url and l11ll1_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ因") not in url: url = server+l11ll1_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ囡")+url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ团"))[-1]+l11ll1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ団")
	headers = {l11ll1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭囤"):server,l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ囥"):l11llllll_l1_()}
	if l11ll1_l1_ (u"ࠧ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ囦") in url:
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ囧"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ囨")}
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ囩"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,True,l11ll1_l1_ (u"ࠫࠬ囪"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠵ࡸࡺࠧ囫"))
		html = response.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ囬"),html,re.DOTALL|re.IGNORECASE)
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠧࠨ园"),[l11ll1_l1_ (u"ࠨࠩ囮")],[l1lllll_l1_[0]]
	elif l11ll1_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ囯") in url:
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ困"),headers,l11ll1_l1_ (u"ࠫࠬ囱"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧ囲"))
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ図"),html,re.DOTALL)
		l1lllll_l1_ = l1lllll_l1_[0].replace(l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭围"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭囵"))
		if l1lllll_l1_: return l11ll1_l1_ (u"ࠩࠪ囶"),[l11ll1_l1_ (u"ࠪࠫ囷")],[l1lllll_l1_]
	else:
		l1111ll11l1l_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ囸"),url,l11ll1_l1_ (u"ࠬ࠭囹"),headers,l11ll1_l1_ (u"࠭ࠧ固"),l11ll1_l1_ (u"ࠧࠨ囻"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪ囼"))
		html = l1111ll11l1l_l1_.content
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ国"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])+l11ll1_l1_ (u"ࠪࠪࡩࡃ࠱ࠨ图")
			l1ll1111l_l1_ = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ囿"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭圀"),headers,l11ll1_l1_ (u"࠭ࠧ圁"),l11ll1_l1_ (u"ࠧࠨ圂"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪ圃"))
			html = l1ll1111l_l1_.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ圄"),html,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠪࠫ圅"),[l11ll1_l1_ (u"ࠫࠬ圆")],[l1lllll_l1_]
		if l11ll1_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ圇") in list(l1111ll11l1l_l1_.headers.keys()):
			cookies = l1111ll11l1l_l1_.headers[l11ll1_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ圈")]
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠴ࠪࡀ࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ圉"),cookies,re.DOTALL)
			if l1lllll_l1_:
				l1lllll_l1_ = l1111_l1_(l1lllll_l1_[0])
				return l11ll1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ圊"),[l11ll1_l1_ (u"ࠩࠪ國")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧ圌"),[],[]
	l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࠤࡳࡵࡴࠡࡹࡲࡶࡰ࡯࡮ࡨࠌࠌࠍࠨࠦࡩࡵࠢࡱࡩࡪࡪࡳࠡࡥࡲࡳࡰ࡯ࡥࠡࡨࡵࡳࡲࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠍࠍࠎࠩࠠࡄࡱࡲ࡯࡮࡫࠺ࠡࡥࡩࡣࡨࡲࡥࡢࡴࡤࡲࡨ࡫࠽ࡄࡏࡨ࠲ࡍࡑࡇࡒ࡭ࡰࡻࡳ࡙ࡖࡶࡰࡽ࡚ࡎࡶࡱࡰࡹࡴࡗࡆࡠࡣࡱࡰࡉ࠻࡯ࡈࡐࡖࡑࡔࡦ࡞ࡈࡆ࠱࠯࠴࠺࠻࠹࠱࠲࠴࠳࠴࠻࠳࠰࠮࠴࠸࠴ࠏࠏࠉࡴࡧࡵࡺࡪࡸࠠ࠾ࠢࡖࡉࡗ࡜ࡅࡓࠪࡸࡶࡱ࠲ࠧࡶࡴ࡯ࠫ࠮ࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠨࠪ࠮ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿ࡹࡥࡳࡸࡨࡶࢂࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧࠪࠌࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࡾࡵࡩ࠳ࡏࡇࡏࡑࡕࡉࡈࡇࡓࡆࠫࠍࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡥ࡮ࡤࡨࡨ࠲࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮࡞ࠫࠬࡣࠬ࡜࡮࡬ࡲࡰࡣࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡸࡶࡱࠦ࠽ࠡ࡮࡬ࡲࡰࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩ࠭ࡪࡷࡱࡱ࠯ࠊࠊࠋࠦࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࠏࠣࡪࡨࠣࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠥࠌࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠤࠋࡵࡩࡹࡻࡲ࡯ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡺࡸ࡬ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠋࠋࠥࠦࠧ圍")
	#if l11ll1_l1_ (u"ࠬ࠴࡭ࡱ࠶࠱࡬ࡹࡳ࡬ࠨ圎") in url:
	#	l1ll1l1lllll_l1_ = url.split(l11ll1_l1_ (u"࠭࠯ࠨ圏"))
	#	url = l11ll1_l1_ (u"ࠧ࠰ࠩ圐").join(l1ll1l1lllll_l1_[:4])
	#	tmp = re.findall(l11ll1_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࠲࠳࠳࠰࠿࠰ࠫࠫ࠲࠯ࡅࠩࠥࠩ圑"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11ll1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ園")+tmp[0][1]+l11ll1_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ圓")
	#	#return l11ll1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ圔"),[l11ll1_l1_ (u"ࠬ࠭圕")],[url]
	#	#l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l1llllll11ll1_l1_(url)
	#	#return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
	# l1l111l1l_l1_ l1lllll_l1_
	#return l11ll1_l1_ (u"࠭ࠧ圖"),[l11ll1_l1_ (u"ࠧࠨ圗")],[l1lllll_l1_]
def l1l1ll111111_l1_(l1lllll_l1_):
	# https://l1111lllllll_l1_.l111l11l1ll1_l1_/l1llll1lll1ll_l1_?_11111l11lll_l1_=l1lllll1l1lll_l1_&_11111llll1l_l1_=86046&l11llll1_l1_=0
	if l11ll1_l1_ (u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬ團") in l1lllll_l1_:
		headers = {l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ圙"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ圚")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ圛"),l1lllll_l1_,l11ll1_l1_ (u"ࠬ࠭圜"),headers,l11ll1_l1_ (u"࠭ࠧ圝"),l11ll1_l1_ (u"ࠧࠨ圞"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪ土"))
		url = response.content
		if url: return l11ll1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ圠"),[l11ll1_l1_ (u"ࠪࠫ圡")],[url]
	else:
		# https://l1111111l111_l1_.net/?l11lll11_l1_=142302&l11llll1_l1_=4
		parts = re.findall(l11ll1_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ圢"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11ll1_l1_ (u"ࠬࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ圣"),l1lllll_l1_,re.DOTALL|re.IGNORECASE)
		l11lll11_l1_,l11llll1_l1_ = parts[0]
		server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ圤"))
		#url = server+l11ll1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴࡙ࡨࡢࡪ࡬ࡨ࠹ࡻ࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ圥")
		url = server+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ圦")
		#url = server+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ圧")+l11lll11_l1_+l11ll1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ在")+l11llll1_l1_
		#data = {l11ll1_l1_ (u"ࠫ࡮ࡪࠧ圩"):l11lll11_l1_,l11ll1_l1_ (u"ࠬ࡯ࠧ圪"):l11llll1_l1_,l11ll1_l1_ (u"࠭࡭ࡦࡶࡤࠫ圫"):l11ll1_l1_ (u"ࠧࡰ࡮ࡧࡣࡸ࡫ࡲࡷࡧࡵࡷࠬ圬"),l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠭圭"):l11ll1_l1_ (u"ࠩࡲࡰࡩ࠭圮")}
		data = {l11ll1_l1_ (u"ࠪ࡭ࡩ࠭圯"):l11lll11_l1_,l11ll1_l1_ (u"ࠫ࡮࠭地"):l11llll1_l1_}
		headers = {l11ll1_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ圱"):l11ll1_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ圲"),l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ圳"):l1lllll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭圴"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ圵"),l11ll1_l1_ (u"ࠪࠫ圶"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠵ࡲࡩ࠭圷"))
		l11ll1ll_l1_ = response.content
		l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圸"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l111lll_l1_:
			l111lll_l1_ = l111lll_l1_[0]
			return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ圹"),[l11ll1_l1_ (u"ࠧࠨ场")],[l111lll_l1_]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ圻"),[],[]
def l111l1l11l11_l1_(l1lllllll1111_l1_):
	l11l1l111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭圼"),l11ll1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭圽"),l11ll1_l1_ (u"ࠫࡆࡑࡗࡂࡏࡢ࡚ࡊࡘࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠩ圾"))
	headers = {l11ll1_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ圿"):l11l1l111_l1_} if l11l1l111_l1_ else l11ll1_l1_ (u"࠭ࠧ址")
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ坁"),l1lllllll1111_l1_,l11ll1_l1_ (u"ࠨࠩ坂"),headers,l11ll1_l1_ (u"ࠩࠪ坃"),l11ll1_l1_ (u"ࠪࠫ坄"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠲ࡵࡷࠫ坅"))
	l1lllllll1l1l_l1_ = response.content
	l1111111llll_l1_ = str(response.headers)
	l11111l11l1l_l1_ = l1111111llll_l1_+l1lllllll1l1l_l1_
	if l11ll1_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ坆") in l11111l11l1l_l1_: l1ll1l1ll_l1_ = True
	else:
		l1lllll1ll1l1_l1_,token,l111lll11l1l_l1_,l11111lll111_l1_,l1ll1l1ll_l1_ = l11ll1_l1_ (u"࠭ࠧ均"),l11ll1_l1_ (u"ࠧࠨ坈"),l11ll1_l1_ (u"ࠨࠩ坉"),l11ll1_l1_ (u"ࠩࠪ坊"),False
		l111lllll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坋"),l1lllllll1l1l_l1_,re.DOTALL)
		if l111lllll11l_l1_: l111lll11l1l_l1_,l11111lll111_l1_ = l111lllll11l_l1_[0]
		l1111lll1l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ坌")][7]
		user = l1l11l111ll_l1_(32)
		if 0:
			data = {l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࠪ坍"):user,l11ll1_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ坎"):l11llll111l_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ坏"):l1lllllll1111_l1_,l11ll1_l1_ (u"ࠨ࡭ࡨࡽࠬ坐"):l11111lll111_l1_,l11ll1_l1_ (u"ࠩ࡬ࡨࠬ坑"):l11ll1_l1_ (u"ࠪࠫ坒"),l11ll1_l1_ (u"ࠫ࡯ࡵࡢࠨ坓"):l11ll1_l1_ (u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭坔")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ坕"),l1111lll1l1l_l1_,data,l11ll1_l1_ (u"ࠧࠨ坖"),l11ll1_l1_ (u"ࠨࠩ块"),l11ll1_l1_ (u"ࠩࠪ坘"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠲࡯ࡦࠪ坙"))
			html = response.content
		html = l11ll1_l1_ (u"ࠫࠬ坚")
		if html.startswith(l11ll1_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ坛")):
			l11ll11lll11_l1_ = EVAL(l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ坜"),html.split(l11ll1_l1_ (u"ࠧࡖࡔࡏࡗࡂ࠭坝"),1)[1])
			for request in l11ll11lll11_l1_:
				url = request[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ坞")]
				method = request[l11ll1_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࠩ坟")]
				data = request[l11ll1_l1_ (u"ࠪࡨࡦࡺࡡࠨ坠")]
				headers = request[l11ll1_l1_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ坡")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11ll1_l1_ (u"ࠬ࠭坢"),l11ll1_l1_ (u"࠭ࠧ坣"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ坤"))
				l1lllllll1l1l_l1_ = response.content
				if l11ll1_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭坥") in l1lllllll1l1l_l1_:
					l1ll1l1ll_l1_ = True
					break
				l1111111llll_l1_ = str(response.headers)
				l11111l11l1l_l1_ = l1111111llll_l1_+l1lllllll1l1l_l1_
				l1lllll1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ坦"),l11111l11l1l_l1_,re.DOTALL)
				token = re.findall(l11ll1_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ坧"),l11111l11l1l_l1_,re.DOTALL)
				if token: token = token[0]
				if l1lllll1ll1l1_l1_ or token: break
		if not l1ll1l1ll_l1_:
			if not l1lllll1ll1l1_l1_:
				if not token and l111lllll11l_l1_:
					if not html.startswith(l11ll1_l1_ (u"ࠫࡎࡊ࠽ࠨ坨")):
						data = {l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࠪ坩"):user,l11ll1_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ坪"):l11llll111l_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ坫"):l1lllllll1111_l1_,l11ll1_l1_ (u"ࠨ࡭ࡨࡽࠬ坬"):l11111lll111_l1_,l11ll1_l1_ (u"ࠩ࡬ࡨࠬ坭"):l11ll1_l1_ (u"ࠪࠫ坮"),l11ll1_l1_ (u"ࠫ࡯ࡵࡢࠨ坯"):l11ll1_l1_ (u"ࠬ࡭ࡥࡵ࡫ࡧࠫ坰")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ坱"),l1111lll1l1l_l1_,data,l11ll1_l1_ (u"ࠧࠨ坲"),l11ll1_l1_ (u"ࠨࠩ坳"),l11ll1_l1_ (u"ࠩࠪ坴"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪ坵"))
						html = response.content
					#html = l11ll1_l1_ (u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬ坶")
					if html.startswith(l11ll1_l1_ (u"ࠬࡏࡄ࠾ࠩ坷")):
						l11111l1l111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬ坸"),html,re.DOTALL)
						l11111lll1ll_l1_,timeout = l11111l1l111_l1_[0]
						message = l11ll1_l1_ (u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬ坹")+timeout+l11ll1_l1_ (u"ࠨࠢฮห๋๐ษࠨ坺")
						l11l1l1lll_l1_ = DIALOG_PROGRESS()
						l11l1l1lll_l1_.create(l11ll1_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨ坻"),message)
						t1 = time.time()
						l11111l1lll1_l1_ = 0
						while l11111l1lll1_l1_<int(timeout):
							data = {l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ坼"):user,l11ll1_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ坽"):l11llll111l_l1_,l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ坾"):l1lllllll1111_l1_,l11ll1_l1_ (u"࠭࡫ࡦࡻࠪ坿"):l11111lll111_l1_,l11ll1_l1_ (u"ࠧࡪࡦࠪ垀"):l11111lll1ll_l1_,l11ll1_l1_ (u"ࠨ࡬ࡲࡦࠬ垁"):l11ll1_l1_ (u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫ垂")}
							response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ垃"),l1111lll1l1l_l1_,data,l11ll1_l1_ (u"ࠫࠬ垄"),l11ll1_l1_ (u"ࠬ࠭垅"),l11ll1_l1_ (u"࠭ࠧ垆"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ垇"))
							html = response.content
							if html.startswith(l11ll1_l1_ (u"ࠨࡖࡒࡏࡊࡔ࠽ࠨ垈")):
								token = html.split(l11ll1_l1_ (u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ垉"),1)[1]
								break
							time.sleep(9)
							l11111l1lll1_l1_ = int(time.time()-t1)
							PROGRESS_UPDATE(l11l1l1lll_l1_,int(l11111l1lll1_l1_/int(timeout)*100),message,l11ll1_l1_ (u"ࠪࠫ垊"),str(l11111l1lll1_l1_)+l11ll1_l1_ (u"ࠫࠥัว็์ฬࠫ型"))
							if l11l1l1lll_l1_.iscanceled(): break
						l11l1l1lll_l1_.close()
				if token:
					l111lll1l11l_l1_ = response.cookies.get_dict()
					l1l111lllll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬ࠿ࠬ垌"),l11111l11l1l_l1_,re.DOTALL)
					if l11ll1_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭垍") in list(l111lll1l11l_l1_.keys()): l1l111lllll1_l1_ = l111lll1l11l_l1_[l11ll1_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ垎")]
					elif l1l111lllll1_l1_: l1l111lllll1_l1_ = l1l111lllll1_l1_[0]
					l111lllll11l_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垏"),l1lllllll1l1l_l1_,re.DOTALL)
					if l111lllll11l_l1_: l111lll11l1l_l1_,l11111lll111_l1_ = l111lllll11l_l1_[0]
					if l1l111lllll1_l1_ and l111lllll11l_l1_:
						headers = {l11ll1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ垐"):l11ll1_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠫ垑")+l1l111lllll1_l1_,l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ垒"):l1lllllll1111_l1_,l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ垓"):l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ垔")}
						data = l11ll1_l1_ (u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠨ垕")+token
						response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭垖"),l111lll11l1l_l1_,data,headers,False,l11ll1_l1_ (u"ࠩࠪ垗"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ垘"))
						l1lllllll1l1l_l1_ = response.content
						try: cookies = response.cookies.get_dict()
						except: cookies = {}
						l1lllll1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ垙"),str(cookies),re.DOTALL)
			if l1lllll1ll1l1_l1_:
				name,l1lllll1ll1l1_l1_ = l1lllll1ll1l1_l1_[0]
				l11l1l111_l1_ = name+l11ll1_l1_ (u"ࠬࡃࠧ垚")+l1lllll1ll1l1_l1_
				WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ垛"),l11ll1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒࡥࡖࡆࡔࡌࡊࡎࡉࡁࡕࡋࡒࡒࠬ垜"),l11l1l111_l1_,PERMANENT_CACHE)
				if l11ll1_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭垝") not in l1lllllll1l1l_l1_:
					headers = {l11ll1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ垞"):l11l1l111_l1_}
					response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ垟"),l1lllllll1111_l1_,l11ll1_l1_ (u"ࠫࠬ垠"),headers,l11ll1_l1_ (u"ࠬ࠭垡"),l11ll1_l1_ (u"࠭ࠧ垢"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠻ࡹ࡮ࠧ垣"))
					l1lllllll1l1l_l1_ = response.content
	if not l1ll1l1ll_l1_ and not l11l1l111_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ垤"),l11ll1_l1_ (u"ࠩࠪ垥"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭垦"),l11ll1_l1_ (u"ࠫ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣๅู๊สࠡ࠰࠱ࠤาอ่ๅࠢศ฽ฬีษࠡษ็฽๊๊๊ส่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦๆโีࠣห้็๊ะ์๋ࠤศ๎ࠠโ์า๎ํฺ๋ࠦำ๊ࠤ๊์ࠠ็ใึࠤฬ๊ๅ้ไ฼ࠫ垧"))
	return l1lllllll1l1l_l1_
def l1lllll1_l1_(url,type,l111llll_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭垨"),l11ll1_l1_ (u"࠭ࠧ垩"),url,type)
	# http://l1111ll11111_l1_.l11l111ll1ll_l1_.io/l1lllll_l1_/136530
	l1llll11_l1_,l1111llll11l_l1_ = [],[]
	#l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠧࠨ垪"),l11ll1_l1_ (u"ࠨࠩ垫"),True,l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨ垬"))
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ垭"),url,l11ll1_l1_ (u"ࠫࠬ垮"),l11ll1_l1_ (u"ࠬ࠭垯"),l11ll1_l1_ (u"࠭ࠧ垰"),l11ll1_l1_ (u"ࠧࠨ垱"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ垲"))
	l11ll1ll_l1_ = response.content
	l1111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠽࠱ࡤࡂࠬ垳"),l11ll1ll_l1_,re.DOTALL)
	for block in l1111l1_l1_:
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ垴"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ in l1llll11_l1_: continue
			if l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ垵") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ垶") not in l1lllll_l1_: continue
			title = title.replace(l11ll1_l1_ (u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧ垷"),l11ll1_l1_ (u"ࠧࠨ垸")).replace(l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬ垹"),l11ll1_l1_ (u"ࠩࠪ垺")).strip(l11ll1_l1_ (u"ࠪࠤࠬ垻")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ垼"),l11ll1_l1_ (u"ࠬࠦࠧ垽"))
			l1llll11_l1_.append(l1lllll_l1_)
			l1111llll11l_l1_.append(title)
	if len(l1llll11_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭垾"),l1111llll11l_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ垿"),[],[]
	elif len(l1llll11_l1_)==1: l1l_l1_ = 0
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ埀"),[],[]
	l1lllllll1111_l1_ = l1llll11_l1_[l1l_l1_]
	l1lllllll1l1l_l1_ = l111l1l11l11_l1_(l1lllllll1111_l1_)
	l1llll_l1_,l1lll11l_l1_ = [],[]
	if type==l11ll1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ埁"):
		l1111l1lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埂"),l1lllllll1l1l_l1_,re.DOTALL)
		if l1111l1lll11_l1_:
			l1lllll_l1_ = l1111_l1_(l1111l1lll11_l1_[0])
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(l111llll_l1_)
	elif type==l11ll1_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ埃"):
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埄"),l1lllllll1l1l_l1_,re.DOTALL)
		for l1lllll_l1_,size in l1l1_l1_:
			if not l1lllll_l1_: continue
			if l111llll_l1_ in size:
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
				break
		if not l1llll_l1_:
			for l1lllll_l1_,size in l1l1_l1_:
				if not l1lllll_l1_: continue
				l1lll11l_l1_.append(size)
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭ࡔࡆࡕࡗࠫ埅"),l1llll_l1_)
	if not l1llll_l1_: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ埆"),[],[]
	return l11ll1_l1_ (u"ࠨࠩ埇"),l1lll11l_l1_,l1llll_l1_
def l11llll_l1_(url,name):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ埈"),l11ll1_l1_ (u"ࠪࠫ埉"),url,l11l111l1lll_l1_)
	# http://l11ll1l11l1_l1_.l1111l111l1l_l1_.net/5cf68c23e6e79			?l11l111l1lll_l1_=			__11l11llllll_l1_
	# http://w.l11ll111_l1_.l1llll111ll_l1_/5e14fd0a2806e			?l11l111l1lll_l1_=			ok.l1111ll1l111_l1_
	#l11l111l1lll_l1_ = l11l111l1lll_l1_.replace(l11ll1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡢࡣࠬ埊"),l11ll1_l1_ (u"ࠬ࠭埋")).split(l11ll1_l1_ (u"࠭࡟ࡠࠩ埌"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ埍"),url,l11ll1_l1_ (u"ࠨࠩ城"),l11ll1_l1_ (u"ࠩࠪ埏"),True,l11ll1_l1_ (u"ࠪࠫ埐"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠱ࡴࡶࠪ埑"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ埒") in list(cookies.keys()):
		l11l1l111_l1_ = cookies[l11ll1_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭埓")]
		l11l1l111_l1_ = l1111_l1_(escapeUNICODE(l11l1l111_l1_))
		items = re.findall(l11ll1_l1_ (u"ࠧࡳࡱࡸࡸࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埔"),l11l1l111_l1_,re.DOTALL)
		l111lll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠨ࡞࠲ࠫ埕"),l11ll1_l1_ (u"ࠩ࠲ࠫ埖"))
		l111lll_l1_ = escapeUNICODE(l111lll_l1_)
	else: l111lll_l1_ = url
	if l11ll1_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ埗") in l111lll_l1_:
		id = l111lll_l1_.split(l11ll1_l1_ (u"ࠫࠪ࠸ࡆࠨ埘"))[-1]
		l111lll_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡡࡵࡥ࡫࠲࡮ࡹ࠯ࠨ埙")+id
		return l11ll1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ埚"),[l11ll1_l1_ (u"ࠧࠨ埛")],[l111lll_l1_]
	else:
		l1l1l1l1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ埜")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭埝"),l1l1l1l1_l1_,l11ll1_l1_ (u"ࠪࠫ埞"),l11ll1_l1_ (u"ࠫࠬ域"),True,l11ll1_l1_ (u"ࠬ࠭埠"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ埡"))
		l11l111l1l1l_l1_ = response.url
		#l11l111l1l1l_l1_ = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ埢")]
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ埣"),l11ll1_l1_ (u"ࠩࠪ埤"),response.url,l1l1l1l1_l1_)
		l1111lll1lll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠪ࠳ࠬ埥"))[2]#.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ埦"))
		l11l1l11l1l1_l1_ = l11l111l1l1l_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ埧"))[2]#.encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ埨"))
		l11l111_l1_ = l111lll_l1_.replace(l1111lll1lll_l1_,l11l1l11l1l1_l1_)
		headers = { l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ埩"):l11ll1_l1_ (u"ࠨࠩ埪") , l11ll1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ埫"):l11ll1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ埬") , l11ll1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ埭"):l11l111_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ埮"), l11l111_l1_, l11ll1_l1_ (u"࠭ࠧ埯"), headers, False,l11ll1_l1_ (u"ࠧࠨ埰"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧ埱"))
		html = response.content
		#xbmc.log(str(l11l111_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11ll1_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ埲"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11ll1_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ埳"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11ll1_l1_ (u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ埴"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭埵"),l11ll1_l1_ (u"࠭ࠧ埶"),str(items),html)
		if items:
			l1lllll_l1_ = items[0].replace(l11ll1_l1_ (u"ࠧ࡝࠱ࠪ執"),l11ll1_l1_ (u"ࠨ࠱ࠪ埸"))
			l1lllll_l1_ = l1lllll_l1_.rstrip(l11ll1_l1_ (u"ࠩ࠲ࠫ培"))
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ基") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ埻") + l1lllll_l1_
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭埼"),l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ埽"))
			if name==l11ll1_l1_ (u"ࠧࠨ埾"): l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠨࠩ埿"),[l11ll1_l1_ (u"ࠩࠪ堀")],[l1lllll_l1_]
			else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭堁"),[l11ll1_l1_ (u"ࠫࠬ堂")],[l1lllll_l1_]
		else: l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_ = l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭堃"),[],[]
		return l11l11ll1l1l_l1_,l1lll11l_l1_,l1llll_l1_
def l111llll11ll_l1_(url):
	# https://www.l11l111111ll_l1_.com/e/l1111111lll1_l1_
	headers = { l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ堄") : l11ll1_l1_ (u"ࠧࠨ堅") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠨࠩ堆"),headers,l11ll1_l1_ (u"ࠩࠪ堇"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ堈"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ堉"),l11ll1_l1_ (u"ࠬ࠭堊"),url,html)
	items = re.findall(l11ll1_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堋"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_,errno = [],[],l11ll1_l1_ (u"ࠧࠨ堌")
	if items:
		for l1lllll_l1_,l1ll1l1l1ll1_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1l1ll1_l1_)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧ堍"),[],[]
	return l11ll1_l1_ (u"ࠩࠪ堎"),l1lll11l_l1_,l1llll_l1_
def l11111l11111_l1_(url):
	# https://l1111l11llll_l1_.io/l1l111l1l_l1_-l11111l111l1_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ堏"),l11ll1_l1_ (u"ࠫࠬ堐"))
	headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ堑"):l11ll1_l1_ (u"࠭ࠧ堒")}
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ堓"),headers,l11ll1_l1_ (u"ࠨࠩ堔"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ堕"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ堖"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ堗"),l11ll1_l1_ (u"ࠬ࠭堘"),url,items[0])
	if items:
		url = items[0]+l11ll1_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ堙")+url
		return l11ll1_l1_ (u"ࠧࠨ堚"),[l11ll1_l1_ (u"ࠨࠩ堛")],[url]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡗࡌࡐࡃࡇࠫ堜"),[],[]
def l111l11lllll_l1_(url):
	# https://l1llll1llll11_l1_.to/l1l111l1l_l1_/5c83f14297d62
	url = url.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ堝"))
	if l11ll1_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ堞") in url: id = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ堟"))[4]
	else: id = url.split(l11ll1_l1_ (u"࠭࠯ࠨ堠"))[-1]
	url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡦࡷࡹࡸࡥࡢ࡯࠱ࡸࡴ࠵ࡰ࡭ࡣࡼࡩࡷࡅࡦࡪࡦࡀࠫ堡") + id
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ堢") : l11ll1_l1_ (u"ࠩࠪ堣") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ堤"),headers,l11ll1_l1_ (u"ࠫࠬ堥"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ堦"))
	html = html.replace(l11ll1_l1_ (u"࠭࡜࡝ࠩ堧"),l11ll1_l1_ (u"ࠧࠨ堨"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ堩"),l11ll1_l1_ (u"ࠩࠪ堪"),url,html)
	items = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ堫"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠫࠬ堬"),[l11ll1_l1_ (u"ࠬ࠭堭")],[ items[0] ]
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪ堮"),[],[]
def l11111ll1l1l_l1_(url):
	# https://l11l11l1l111_l1_.net/l1l111l1l_l1_-l111ll1lllll_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ堯"),l11ll1_l1_ (u"ࠨࠩ堰"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ報"),l11ll1_l1_ (u"ࠪࠫ堲"),l11ll1_l1_ (u"ࠫࠬ堳"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬ場"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堵"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for l1lllll_l1_,l1ll1l1l1ll1_l1_,res in items:
		l1lll11l_l1_.append(l1ll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠧࠡࠩ堶")+res)
		l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡏ࡛ࡃࠪ堷"),[],[]
	return l11ll1_l1_ (u"ࠩࠪ堸"),l1lll11l_l1_,l1llll_l1_
def l111l1lllll1_l1_(url):
	# https://l11l11ll1ll1_l1_.l1lll1lllll_l1_/l1l111l1l_l1_-l1111l1111ll_l1_.html
	url = url.replace(l11ll1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ堹"),l11ll1_l1_ (u"ࠫࠬ堺"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭堻"),l11ll1_l1_ (u"࠭ࠧ堼"),l11ll1_l1_ (u"ࠧࠨ堽"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ堾"))
	items = re.findall(l11ll1_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢ堿"),html,re.DOTALL)
	items = set(items)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1ll1l1l1ll1_l1_,res in items:
		url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ塀")+id+l11ll1_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ塁")+mode+l11ll1_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ塂")+hash
		html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ塃"),l11ll1_l1_ (u"ࠧࠨ塄"),l11ll1_l1_ (u"ࠨࠩ塅"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭塆"))
		items = re.findall(l11ll1_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ塇"),html,re.DOTALL)
		for l1lllll_l1_ in items:
			l1lll11l_l1_.append(l1ll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭塈")+res)
			l1llll_l1_.append(l1lllll_l1_)
	if len(l1llll_l1_)==0: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ塉"),[],[]
	return l11ll1_l1_ (u"࠭ࠧ塊"),l1lll11l_l1_,l1llll_l1_
def l1llll1llll1l_l1_(url):
	# https://l1lllll1ll11l_l1_.com:2053/l1lllll1lll1l_l1_/l11111lllll1_l1_.l111ll11l1ll_l1_.l11l1l111l1l_l1_.1080p.l11l11llll1l_l1_.l11l111l1ll1_l1_.l1lllll11ll11_l1_.l1111l1l_l1_.html?l111l1lll111_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111lll11111_l1_=1624070560
	# http://l1lllllll1lll_l1_.l111lll11l1_l1_/l111ll111l1l_l1_/l111ll11llll_l1_.l111l111l111_l1_.l11l1l11l1ll_l1_.2018.1080p.l1111lll1ll1_l1_-l111l11l1l11_l1_.l1lllllll1l11_l1_.l1111l1l_l1_.html
	l1lllll_l1_ = l11ll1_l1_ (u"ࠧࠨ塋")
	if 1 or l11ll1_l1_ (u"ࠨࡍࡨࡽࡂ࠭塌") not in url:
		l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭塍"),l11ll1_l1_ (u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ塎"))
		l111lll_l1_ = l111lll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭塏"))
		id = l111lll_l1_[3]
		l111lll_l1_ = l11ll1_l1_ (u"ࠬ࠵ࠧ塐").join(l111lll_l1_[0:4])
		#headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ塑"):l11llllll_l1_(),l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭塒"):l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ塓")}
		payload = {l11ll1_l1_ (u"ࠩ࡬ࡨࠬ塔"):id,l11ll1_l1_ (u"ࠪࡳࡵ࠭塕"):l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ塖"),l11ll1_l1_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ塗"):l11ll1_l1_ (u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭塘")}
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ塙"),l111lll_l1_,payload,l11ll1_l1_ (u"ࠨࠩ塚"),l11ll1_l1_ (u"ࠩࠪ塛"),l11ll1_l1_ (u"ࠪࠫ塜"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ塝"))
		if l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ塞") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ塟")]
		if not l1lllll_l1_ and response.succeeded:
			html = response.content
			l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ塠"),html,re.DOTALL)
			if l1lllll_l1_: l1lllll_l1_ = l1lllll_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ塡"),url,l11ll1_l1_ (u"ࠩࠪ塢"),l11ll1_l1_ (u"ࠪࠫ塣"),l11ll1_l1_ (u"ࠫࠬ塤"),l11ll1_l1_ (u"ࠬ࠭塥"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ塦"))
		if l11ll1_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ塧") in list(response.headers.keys()): l1lllll_l1_ = response.headers[l11ll1_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ塨")]
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠩࠪ塩"),[l11ll1_l1_ (u"ࠪࠫ塪")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ填"),[],[]
def l111l1l11ll1_l1_(url):
	# https://www.l111l111111l_l1_.com/012ocyw9li6g.html
	headers = { l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ塬") : l11ll1_l1_ (u"࠭ࠧ塭") }
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ塮"),headers,l11ll1_l1_ (u"ࠨࠩ塯"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ塰"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩ塱"),html,re.DOTALL)
	l1lll11l_l1_,l1llll_l1_ = [],[]
	if items:
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠫࡲࡶ࠴ࠨ塲"))
		l1llll_l1_.append(items[0][1])
		l1lll11l_l1_.append(l11ll1_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ塳"))
		l1llll_l1_.append(items[0][0])
		return l11ll1_l1_ (u"࠭ࠧ塴"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫ塵"),[],[]
def l11l1l1l1ll_l1_(url):
	# l111ll11l1l1_l1_ l11l11111111_l1_			url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡟࠷ࡘ࠶࠴࡚ࡒࡾࡹࡒࡇࠪ塶")
	# l1llllll11lll_l1_ .l11l1l111111_l1_ l11l11111111_l1_		url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡷ࡯ࡖࡒࡆࡿࡥࡺࡈࡌࠫ塷")
	# l111ll111ll1_l1_ l11l1l1l1l_l1_ .l1llll111_l1_ l11l11111111_l1_		url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡈࡨ࠵࠱ࡓ࡙ࡴࡔࡵࡑࡻࠬ塸")
	# l111l1l1ll11_l1_ l11l11111111_l1_			url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭塹")
	# l111l11l1l_l1_ files have l111l1l11111_l1_ l1l11l1ll1l1_l1_		url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࠴ࡻࡉࡘࡕࡗࡥࡖࡽࡤࡗࠧ塺")
	# url = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ塻")
	# url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺ࠴ࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ塼")
	# url = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ塽")
	# url = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ塾")
	# url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡱࡈࡈࡰࡰ࡯࡟ࡋ࠳࡜࡯ࠫࡧࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭࠿ࡊࡳࡱࡪࡥ࡯ࡎ࡬ࡲࡪ࡬࡯ࡳࡖ࡙ࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡡ࡯ࡦࡇ࡭ࡸࡺࡲࡪࡤࡸࡸ࡮ࡵ࡮ࡀࡵࡼࡲࡩ࡯ࡣࡢࡶ࡬ࡳࡳࡃ࠲࠸࠹࠸࠻࠺࠭塿")
	# l1ll1ll1l_l1_ l111111lll11_l1_ details   https://l1111l1111l1_l1_.me/l1lllll1l1l11_l1_/l1lllll111l1l_l1_-l1lllll1l11ll_l1_-l111111ll11l_l1_
	id = url.split(l11ll1_l1_ (u"ࠫ࠴࠭墀"))[-1]
	id = id.split(l11ll1_l1_ (u"ࠬࠬࠧ墁"))[0]
	id = id.replace(l11ll1_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ墂"),l11ll1_l1_ (u"ࠧࠨ境"))
	#id = l11ll1_l1_ (u"ࠨࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭墄")
	#url = l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭墅")+id
	#return l11ll1_l1_ (u"ࠪࠫ墆"),[l11ll1_l1_ (u"ࠫࠬ墇")],[url]
	l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭墈")][0]+l11ll1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ墉")+id
	l1llll1llllll_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ墊")+id
	l111l111l1l1_l1_,l1lllll1lll11_l1_,l11l1l111ll1_l1_,l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠨࠩ墋"),l11ll1_l1_ (u"ࠩࠪ墌"),l11ll1_l1_ (u"ࠪࠫ墍"),l11ll1_l1_ (u"ࠫࠬ墎")
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫࠬࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡢࠧ࠭ࠩࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠩ࠰࠭ࡃ࠮ࡪࡥࡧࡣࡸࡰࡹࡇࡵࡥ࡫ࡲࡘࡷࡧࡣ࡬ࡋࡱࡨࡪࡾࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࢁࠢ࡭ࡣࡱ࡫ࡺࡧࡧࡦࡅࡲࡨࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭࡝࠭࡝ࠪࠫࡢࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡢࡰࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡡ࡯ࡩࠬࠎࠎࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨ࠮ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠊࠊࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡱࡳࡹࠦࡩ࡯ࠢ࡞࠴࠱࠳࠱࡞࠼ࠍࠍࠎࠏࠉࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡨࡡࡴࡧࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒ࡛࠱࡟࠮ࠫࠫ࡬࡭ࡵ࠿ࡹࡸࡹࠬࡴࡺࡲࡨࡁࡹࡸࡡࡤ࡭ࠩࡸࡱࡧ࡮ࡨ࠿ࠪ࠯ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡤࡢࡵ࡫࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡳ࠰ࠩ࠯ࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡩ࡮ࡶ࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠩࡨࡵ࡯࡯࠶ࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡨ࡭ࡵࡘࡖࡑ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ࠭ࠏࠏࠉࠤ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮࡙ࠧ࠯ࡐࡉࡉࡏࡁ࠻ࡗࡕࡍࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠬࡈࡔࡒ࡙ࡕ࠳ࡉࡅ࠿ࠥࡺࡹࡺࠧ࠭ࡪࡷࡱࡱ࠸ࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠣࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠨ࠱ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠨࡷࡽࡵ࡫࠽ࡵࡴࡤࡧࡰࠬࡴ࡭ࡣࡱ࡫ࡂ࠭ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠭ࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮ࡾࢁࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡺࡸ࡬ࡠࡧࡱࡧࡴࡪࡥࡥࡡࡩࡱࡹࡥࡳࡵࡴࡨࡥࡲࡥ࡭ࡢࡲࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫࡟ࡧ࡯ࡷࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡬ࡪࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡤࡲࡩࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠥࡂࡡࠧࠨ࡟࠽ࠎࠎࠏࠉࡧ࡯ࡷࡣࡱ࡯ࡳࡵࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊࡨࡰࡸࡤ࡯ࡴࡢࡩࡶࠤࡂࠦࡦ࡮ࡶࡢࡰ࡮ࡹࡴ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠮ࠪ࠭ࠏࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡦ࡮ࡶࡢ࡭ࡹࡧࡧࡴ࠼ࠍࠍࠎࠏࠉࡪࡶࡤ࡫࠱ࡹࡩࡻࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪ࠳ࠬ࠯ࠊࠊࠋࠌࠍ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࡟࡮ࡺࡡࡨ࡟ࠣࡁࠥࡹࡩࡻࡧࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࡰ࡮ࡴࡥࡴࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰࡨࠤ࡮ࡴࠠ࡭࡫ࡱࡩࡸࡀࠊࠊࠋࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮ࠧ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࡰ࡮ࡴࡥ࠭࡮ࡨࡺࡪࡲ࠽ࡹࡤࡰࡧ࠳ࡒࡏࡈࡐࡒࡘࡎࡉࡅࠪࠌࠌࠍࠎࡲࡩ࡯ࡧࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰࡨ࠭ࠏࠏࠉࠊࡦ࡬ࡧࡹࠦ࠽ࠡࡽࢀࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡ࡮࡬ࡲࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠦࠧࠩࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࡦ࡬ࡧࡹࡡ࡫ࡦࡻࡠࠤࡂࠦࡶࡢ࡮ࡸࡩࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡻࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪࡷ࡮ࢀࡥࠨ࡟ࠣࡁࠥ࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࡠࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࡡࠏࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠯ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲ࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡩࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋࡩࡳࡷࠦࡢ࡭ࡱࡦ࡯ࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠦࠧࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡃࠢࠨ࠮ࠪࡁࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠥࠦࠬ࠲ࠧࠣࠩࠬࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠼ࡷࡶࡺ࡫ࠧ࠭ࠩ࠽ࡘࡷࡻࡥࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡀࡦࡢ࡮ࡶࡩࠬ࠲ࠧ࠻ࡈࡤࡰࡸ࡫ࠧࠪࠌࠌࠍ࡮࡬ࠠࠨ࡝ࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡧࡲ࡯ࡤ࡭ࠣࡁ࡛ࠥ࠭ࠨ࠭ࡥࡰࡴࡩ࡫ࠬࠩࡠࠫࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡇ࡙ࡅࡑ࠮ࠧ࡭࡫ࡶࡸࠬ࠲ࡢ࡭ࡱࡦ࡯࠮ࠐࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩࡷࡽࡵ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡀࠫ࠱࠭࠽ࠣࠩࠬ࠯ࠬࠨࠧࠋࠋࠌࠍ࡮࡬ࠠࠨࡨࡳࡷࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡦࡱࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡪࡵࡹࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡷࡪࡦࡷ࡬ࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡼࡨࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫࡼ࡯ࡤࡵࡪࠪࡡ࠮࠱ࠧࡹࠩ࠮ࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡳࡵࡣࡵࡸࠬࡣࠫࠨ࠯ࠪ࠯ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡨࡲࡩ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࡠ࡟ࠬ࡫࡮ࡥࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣ࠾࠲࠳࠴࠶࠷࠸࠳࠴࠵࠽ࠤࡩ࡫࡬ࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡨ࡯ࡰࡩࡧࡵࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࠩࠫ࠮ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡥ࡬ࡴ࡭࡫ࡲ࠻ࠌࠌࠍࠎࠏࠉ࡬ࡧࡼ࠰ࡻࡧ࡬ࡶࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪࡁࠬ࠲࠱ࠪࠌࠌࠍࠎࠏࠉࡥ࡫ࡦࡸࡠࡱࡥࡺ࡟ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡶࡢ࡮ࡸࡩ࠮ࠐࠉࠊࠋࠦ࡭࡫ࠦࠧࡶࡴ࡯ࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡻࡲ࡭ࠩࡠࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸࡠ࠭ࡵࡳ࡮ࠪࡡ࠮ࠐࠉࠊࠋࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺࠩࠋࠋࡸࡶࡱࡥ࡬ࡪࡵࡷ࠰ࡸࡺࡲࡦࡣࡰࡷ࠵࠲ࡳࡵࡴࡨࡥࡲࡹ࠱࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠠࡢࡰࡧࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵ࠳ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶ࡀࠊࠊࠋࠌࡹࡷࡲ࠱ࠡ࠿ࠣࡨ࡮ࡩࡴ࠲࡝ࠪࡹࡷࡲࠧ࡞࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠨࡻࡲ࡭࠳ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠶ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸ࠷ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠼ࠍࠍࠎࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋࠦࡹࡷࡲ࠲ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈ࡚ࠬࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࠵࡟ࠬࡻࡲ࡭ࠩࡠ࠭࠮ࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋ࡬ࡪࠥࡻࡲ࡭࠳ࡀࡁࡺࡸ࡬࠳ࠢࡤࡲࡩࠦࡵࡳ࡮࠴ࠤࡳࡵࡴࠡ࡫ࡱࠤࡺࡸ࡬ࡠ࡮࡬ࡷࡹࡀࠊࠊࠋࠌࠍࠎࡻࡲ࡭ࡡ࡯࡭ࡸࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠵࠮ࠐࠉࠊࠋࠌࠍࡩ࡯ࡣࡵ࠳࠱ࡹࡵࡪࡡࡵࡧࠫࡨ࡮ࡩࡴ࠳ࠫࠍࠍࠎࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴ࠲࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴ࠲ࠫࠍࠍࡪࡲࡳࡦ࠼ࠣࡷࡹࡸࡥࡢ࡯ࡶ࠴ࠥࡃࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠫࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸ࠊࠊࠤࠥࠦ墏")
	# l1lllllll11ll_l1_ json data
	# l1l111l1l_l1_ url l11l11111111_l1_:    https://www.l1ll1ll1l_l1_.com/l1l111l1l_l1_/l111ll1ll11l_l1_
	# list of l11l111111l1_l1_ & l1l11ll11111_l1_
	# https://github.com/l111111ll111_l1_-l1111llll1ll_l1_/l111111ll111_l1_-l1111llll1ll_l1_/blob/master/l111llll1l11_l1_/l111l11111ll_l1_/l1ll1ll1l_l1_.py
	# all the below l11111ll11ll_l1_ were l111l1l11l1l_l1_ using:	https://www.l1ll1ll1l_l1_.com/l11l111lllll_l1_/l1l1lll1l1l1_l1_/l11llll1l11_l1_?l1lllll111l11_l1_=l1llllll11111_l1_	&	l111lll1l1ll_l1_ = l111ll1ll11l_l1_
	# 3 l1ll11lllll1_l1_:	13KB:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ墐"): l11ll1_l1_ (u"ࠧࡊࡑࡖࡣࡈࡘࡅࡂࡖࡒࡖࠬ墑"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ墒"): l11ll1_l1_ (u"ࠩ࠵࠶࠳࠹࠳࠯࠳࠳࠵ࠬ墓")
	# 7 l1ll11lllll1_l1_		44KB:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ墔"): l11ll1_l1_ (u"ࠫࡎࡕࡓࡠࡏࡈࡗࡘࡇࡇࡆࡕࡢࡉ࡝࡚ࡅࡏࡕࡌࡓࡓ࠭墕"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ墖"): l11ll1_l1_ (u"࠭࠱࠸࠰࠶࠷࠳࠸ࠧ増")
	# 7 l1ll11lllll1_l1_		58KB:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ墘"): l11ll1_l1_ (u"ࠨࡋࡒࡗࠬ墙"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ墚"): l11ll1_l1_ (u"ࠪ࠵࠼࠴࠳࠴࠰࠵ࠫ墛")
	# 9 l1ll11lllll1_l1_		24KB:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ墜"): l11ll1_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡃࡓࡇࡄࡘࡔࡘࠧ墝"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭增"): l11ll1_l1_ (u"ࠧ࠳࠴࠱࠷࠵࠴࠱࠱࠲ࠪ墟")
	# no json file:		21 l1ll11lllll1_l1_	95KB:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ墠"): l11ll1_l1_ (u"࡚ࠩࡉࡇࡥࡃࡓࡇࡄࡘࡔࡘࠧ墡"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ墢"): l11ll1_l1_ (u"ࠫ࠶࠴࠲࠱࠴࠵࠴࠼࠸࠶࠯࠲࠳࠲࠵࠶ࠧ墣")
	# no json file:		21 l1ll11lllll1_l1_	121KB:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ墤"): l11ll1_l1_ (u"࠭ࡗࡆࡄࠪ墥"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ墦"): l11ll1_l1_ (u"ࠨ࠴࠱࠶࠵࠸࠲࠱࠺࠳࠵࠳࠶࠰࠯࠲࠳ࠫ墧")
	# no json file: 	26 l1ll11lllll1_l1_	115KB:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭墨"): l11ll1_l1_ (u"ࠪࡑ࡜ࡋࡂࠨ墩"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ墪"): l11ll1_l1_ (u"ࠬ࠸࠮࠳࠲࠵࠶࠵࠾࠰࠲࠰࠳࠴࠳࠶࠰ࠨ墫")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ墬"): l11ll1_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࠨ墭"),l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ墮"): l11ll1_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ墯")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ墰"): l11ll1_l1_ (u"ࠫ࡜ࡋࡂࡠࡔࡈࡑࡎ࡞ࠧ墱"),l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ墲"): l11ll1_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠹࠱࠴࠶࠴࠰࠱ࠩ墳")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ墴"): l11ll1_l1_ (u"ࠨ࡙ࡈࡆࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ墵"),l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ墶"): l11ll1_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠸࠷࠮࠱࠲࠱࠴࠵࠭墷")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ墸"): l11ll1_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡅࡎࡄࡈࡈࡉࡋࡄࡠࡒࡏࡅ࡞ࡋࡒࠨ墹"),l11ll1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭墺"): l11ll1_l1_ (u"ࠧ࠲࠹࠱࠷࠶࠴࠳࠶ࠩ墻")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ墼"): l11ll1_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡑ࡚࡙ࡉࡄࠩ墽"),l11ll1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ墾"): l11ll1_l1_ (u"ࠫ࠺࠴࠱࠷࠰࠸࠵ࠬ墿")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ壀"): l11ll1_l1_ (u"࠭ࡔࡗࡊࡗࡑࡑ࠻࡟ࡔࡋࡐࡔࡑ࡟࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ壁"),l11ll1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ壂"): l11ll1_l1_ (u"ࠨ࠴࠱࠴ࠬ壃")
	# l11l1lll1ll1_l1_:	l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭壄"): l11ll1_l1_ (u"ࠪࡍࡔ࡙࡟ࡎࡗࡖࡍࡈ࠭壅"),l11ll1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ壆"): l11ll1_l1_ (u"ࠬ࠻࠮࠳࠳ࠪ壇")
	# l111lll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ壈")][0]+l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷࡅࡰࡳࡧࡷࡸࡾࡖࡲࡪࡰࡷࡁࡹࡸࡵࡦࠩ壉")  # l1llllll11111_l1_ l1lll1111l1l_l1_ l1lllll1lllll_l1_ and l111111llll1_l1_ l1ll1l1ll1l1_l1_ l1l1l1ll1l_l1_ l11111111ll1_l1_ file size
	#l11ll11l1_l1_ = l11ll1_l1_ (u"ࠨࡽࠪ壊")l1lllll1111ll_l1_ (u"ࠩ࠽࡭ࡩ࠲ࠧ壋")l1111llll111_l1_ (u"ࠪ࠾ࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠣࡃࡑࡈࡗࡕࡉࡅࠤ࠯ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠨ࠱࠸࠰࠶࠵࠳࠹࠵ࠣࡿࢀࢁࠬ壌")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ壍"),l111lll_l1_,l11ll11l1_l1_,l11ll1_l1_ (u"ࠬ࠭壎"),l11ll1_l1_ (u"࠭ࠧ壏"),l11ll1_l1_ (u"ࠧࠨ壐"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩ壑"))
	#html = response.content
	for l11ll11111_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠩส่๊ำว้ๆฬࠤึ่ๅ࠻ࠢࠣࠫ壒")+str(l11ll11111_l1_+1),l11ll1_l1_ (u"ࠪࠫ壓"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ壔"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭壕"),l11ll1_l1_ (u"࠭ࠧ壖"),l11ll1_l1_ (u"ࠧࠨ壗"),l11ll1_l1_ (u"ࠨࠩ壘"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ壙"))
		html = response.content
		if l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ壚") in html: break
		time.sleep(2)
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬ壛"),html)
	l11lll11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ壜"),html,re.DOTALL)
	if l11lll11l1_l1_: l11lll11l1_l1_ = l11lll11l1_l1_[0]
	else: l11lll11l1_l1_ = html
	l11lll11l1_l1_ = l11lll11l1_l1_.replace(l11ll1_l1_ (u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ壝"),l11ll1_l1_ (u"ࠧࠧࠩ壞"))
	l111111l1l1l_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭壟"),l11lll11l1_l1_)
	#WRITE_THIS(l11ll1_l1_ (u"ࠩࠪ壠"),str(l111111l1l1l_l1_))
	# l1lllllll11ll_l1_ l111ll1lll1l_l1_ & l11l11lll1ll_l1_
	# l1ll1ll1l_l1_ l111ll11l1l1_l1_ l1lllll_l1_ l11lll1ll_l1_ l11ll1_l1_ (u"ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠬ壡") to l111l1l111_l1_ on l111ll11l11_l1_
	l1lll11l_l1_,l1llll_l1_ = [l11ll1_l1_ (u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ壢")],[l11ll1_l1_ (u"ࠬ࠭壣")]
	try:
		l111ll1lll1l_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ壤")][l11ll1_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ壥")][l11ll1_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ壦")]
		for l111l1l1lll1_l1_ in l111ll1lll1l_l1_:
			l1lllll_l1_ = l111l1l1lll1_l1_[l11ll1_l1_ (u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ壧")]
			try: title = l111l1l1lll1_l1_[l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ壨")][l11ll1_l1_ (u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ壩")]
			except: title = l111l1l1lll1_l1_[l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ壪")][l11ll1_l1_ (u"࠭ࡲࡶࡰࡶࠫ士")][0][l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࠬ壬")]
			l1llll_l1_.append(l1lllll_l1_)
			l1lll11l_l1_.append(title)
	except: pass
	if len(l1lll11l_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ壭"), l1lll11l_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ壮"),[],[]
		elif l1l_l1_!=0:
			l1lllll_l1_ = l1llll_l1_[l1l_l1_]+l11ll1_l1_ (u"ࠪࠪࠬ壯")
			l1111l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠫ࠮ࡦ࡮ࡶࡀ࠲࠯ࡅࠩࠧࠩ声"),l1lllll_l1_)
			if l1111l11l1ll_l1_: l1lllll_l1_ = l1lllll_l1_.replace(l1111l11l1ll_l1_[0],l11ll1_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭壱"))
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ売")
			l111l111l1l1_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧࠧࠩ壳"))
	formats,l11l11lll11l_l1_,l111llll1ll1_l1_,l111llll1lll_l1_,l111llll1l1l_l1_ = [],[],[],[],[]
	# l1lllllll11ll_l1_ l111l11l111l_l1_ l1ll11lllll1_l1_
	try: l1lllll1lll11_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ壴")][l11ll1_l1_ (u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ壵")]
	except: pass
	# l1lllllll11ll_l1_ l111ll111ll1_l1_ stream
	try: l11l1l111ll1_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ壶")][l11ll1_l1_ (u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ壷")]
	except: pass
	# l1lllllll11ll_l1_ l1ll1l11ll_l1_ l1111l1l_l1_ l1ll11lllll1_l1_
	try: formats = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ壸")][l11ll1_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ壹")]
	except: pass
	# l1lllllll11ll_l1_ l1ll1l11ll_l1_ l11l1l111111_l1_ l1ll11lllll1_l1_
	try: l11l11lll11l_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ壺")][l11ll1_l1_ (u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪ壻")]
	except: pass
	l111ll1111l1_l1_ = formats+l11l11lll11l_l1_
	for dict in l111ll1111l1_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ壼"),str(dict))
		if l11ll1_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ壽") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ壾")] = str(dict[l11ll1_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ壿")])
		if l11ll1_l1_ (u"࠭ࡦࡱࡵࠪ夀") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠧࡧࡲࡶࠫ夁")] = str(dict[l11ll1_l1_ (u"ࠨࡨࡳࡷࠬ夂")])
		if l11ll1_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ夃") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥࠨ处")] = dict[l11ll1_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭夅")]		#.replace(l11ll1_l1_ (u"ࠬࡃࠧ夆"),l11ll1_l1_ (u"࠭࠽ࠨ备"))+l11ll1_l1_ (u"ࠧࠣࠩ夈")
		if l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ変") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭夊")] = str(dict[l11ll1_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ夋")])
		if l11ll1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ夌") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭复")] = str(dict[l11ll1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭夎")])
		if l11ll1_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭夏") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭夐")] = str(dict[l11ll1_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ夑")])+l11ll1_l1_ (u"ࠪࡼࠬ夒")+str(dict[l11ll1_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ夓")])
		if l11ll1_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ夔") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ夕")] = dict[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ外")][l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ夗")]+l11ll1_l1_ (u"ࠩ࠰ࠫ夘")+dict[l11ll1_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭夙")][l11ll1_l1_ (u"ࠫࡪࡴࡤࠨ多")]
		if l11ll1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ夛") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ夜")] = dict[l11ll1_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ夝")][l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ夞")]+l11ll1_l1_ (u"ࠩ࠰ࠫ够")+dict[l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ夠")][l11ll1_l1_ (u"ࠫࡪࡴࡤࠨ夡")]
		if l11ll1_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭夢") in list(dict.keys()): dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ夣")] = dict[l11ll1_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ夤")]
		if l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ夥") in list(dict.keys()) and int(dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ夦")])>111222333: del dict[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ大")]
		if l11ll1_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭夨") in list(dict.keys()):
			cipher = dict[l11ll1_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ天")].split(l11ll1_l1_ (u"࠭ࠦࠨ太"))
			for item in cipher:
				key,value = item.split(l11ll1_l1_ (u"ࠧ࠾ࠩ夫"),1)
				dict[key] = l1111_l1_(value)
		if l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ夬") in list(dict.keys()): dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭夭")] = l1111_l1_(dict[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ央")])
		#if l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࡁࠬ夯") in dict[l11ll1_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ夰")]: dict[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭失")] = dict[l11ll1_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ夲")].split(l11ll1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳ࠾࡞ࠥࠫ夳"))[1].strip(l11ll1_l1_ (u"ࠩ࡟ࠦࠬ头"))
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ夵"),dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ夶")]+l11ll1_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥ࠭夷")+dict[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ夸")])
		l111llll1ll1_l1_.append(dict)
	l11l1ll11_l1_ = l11ll1_l1_ (u"ࠧࠨ夹")
	if l11ll1_l1_ (u"ࠨࡵࡳࡁࡸ࡯ࡧࠨ夺") in l11lll11l1_l1_:
		#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡼࡸࡸ࠵ࡪࡴࡤ࡬ࡲ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࠴ࠪࡀࠫࠥࠫ夻"),html,re.DOTALL)
		# l11l11111111_l1_:	/s/l11llll1l11_l1_/6dde7fb4/l11111111l11_l1_.l1111lll11l1_l1_/l111l11l1l1l_l1_/base.l11111111111_l1_
		#l11l111l11l1_l1_ = [l11ll1_l1_ (u"ࠪ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵ࡤ࠹࠹ࡧ࠹࠽࠷ࡦ࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠࡗࡖ࠳ࡧࡧࡳࡦ࠰࡭ࡷࠬ夼")]
		l11l111l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ夽"),html,re.DOTALL)
		if l11l111l11l1_l1_:
			l11l111l11l1_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭夾")][0]+l11l111l11l1_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ夿"),l11l111l11l1_l1_,l11ll1_l1_ (u"ࠧࠨ奀"),l11ll1_l1_ (u"ࠨࠩ奁"),l11ll1_l1_ (u"ࠩࠪ奂"),l11ll1_l1_ (u"ࠪࠫ奃"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ奄"))
			l11l1ll11_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1llllllll111_l1_ = cipher._load_javascript(l11l1ll11_l1_)
			l1lllll1ll1ll_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ奅"),str(l1llllllll111_l1_))
			l11111l1ll1l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1lllll1ll1ll_l1_)
	for dict in l111llll1ll1_l1_:
		url = dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ奆")]
		if l11ll1_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡀࠫ奇") in url or url.count(l11ll1_l1_ (u"ࠨࡵ࡬࡫ࡂ࠭奈"))>1:
			l111llll1lll_l1_.append(dict)
		elif l11l1ll11_l1_ and l11ll1_l1_ (u"ࠩࡶࠫ奉") in list(dict.keys()) and l11ll1_l1_ (u"ࠪࡷࡵ࠭奊") in list(dict.keys()):
			l111l1l1ll11_l1_ = l11111l1ll1l_l1_.execute(dict[l11ll1_l1_ (u"ࠫࡸ࠭奋")])
			if l111l1l1ll11_l1_!=dict[l11ll1_l1_ (u"ࠬࡹࠧ奌")]:
				dict[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ奍")] = url+l11ll1_l1_ (u"ࠧࠧࠩ奎")+dict[l11ll1_l1_ (u"ࠨࡵࡳࠫ奏")]+l11ll1_l1_ (u"ࠩࡀࠫ奐")+l111l1l1ll11_l1_
				l111llll1lll_l1_.append(dict)
	for dict in l111llll1lll_l1_:
		l11lll1_l1_,l111111l1ll1_l1_,l111111ll1l1_l1_,l11ll1l11_l1_,codecs,l11l11l111l_l1_ = l11ll1_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ契"),l11ll1_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ奒"),l11ll1_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭奓"),l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ奔"),l11ll1_l1_ (u"ࠧࠨ奕"),l11ll1_l1_ (u"ࠨ࠲ࠪ奖")
		try:
			l111lllll111_l1_ = dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ套")]
			l111lllll111_l1_ = l111lllll111_l1_.replace(l11ll1_l1_ (u"ࠪ࠯ࠬ奘"),l11ll1_l1_ (u"ࠫࠬ奙"))
			items = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奚"),l111lllll111_l1_,re.DOTALL)
			l11ll1l11_l1_,l11lll1_l1_,codecs = items[0]
			l11l11ll1111_l1_ = codecs.split(l11ll1_l1_ (u"࠭ࠬࠨ奛"))
			l111111l1ll1_l1_ = l11ll1_l1_ (u"ࠧࠨ奜")
			for item in l11l11ll1111_l1_: l111111l1ll1_l1_ += item.split(l11ll1_l1_ (u"ࠨ࠰ࠪ奝"))[0]+l11ll1_l1_ (u"ࠩ࠯ࠫ奞")
			l111111l1ll1_l1_ = l111111l1ll1_l1_.strip(l11ll1_l1_ (u"ࠪ࠰ࠬ奟"))
			if l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ奠") in list(dict.keys()): l11l11l111l_l1_ = str(float(dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭奡")]*10)//1024/10)+l11ll1_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭奢")
			else: l11l11l111l_l1_ = l11ll1_l1_ (u"ࠧࠨ奣")
			if l11ll1l11_l1_==l11ll1_l1_ (u"ࠨࡶࡨࡼࡹ࠭奤"): continue
			elif l11ll1_l1_ (u"ࠩ࠯ࠫ奥") in l111lllll111_l1_:
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠪࡅ࠰࡜ࠧ奦")
				l111111ll1l1_l1_ = l11lll1_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠧ奧")+l11l11l111l_l1_+dict[l11ll1_l1_ (u"ࠬࡹࡩࡻࡧࠪ奨")].split(l11ll1_l1_ (u"࠭ࡸࠨ奩"))[1]
			elif l11ll1l11_l1_==l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭奪"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ奫")
				l111111ll1l1_l1_ = l11l11l111l_l1_+dict[l11ll1_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ奬")].split(l11ll1_l1_ (u"ࠪࡼࠬ奭"))[1]+l11ll1_l1_ (u"ࠫࠥࠦࠧ奮")+dict[l11ll1_l1_ (u"ࠬ࡬ࡰࡴࠩ奯")]+l11ll1_l1_ (u"࠭ࡦࡱࡵࠪ奰")+l11ll1_l1_ (u"ࠧࠡࠢࠪ奱")+l11lll1_l1_
			elif l11ll1l11_l1_==l11ll1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ奲"):
				l11ll1l11_l1_ = l11ll1_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ女")
				l111111ll1l1_l1_ = l11l11l111l_l1_+str(int(dict[l11ll1_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ奴")])/1000)+l11ll1_l1_ (u"ࠫࡰ࡮ࡺࠡࠢࠪ奵")+dict[l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭奶")]+l11ll1_l1_ (u"࠭ࡣࡩࠩ奷")+l11ll1_l1_ (u"ࠧࠡࠢࠪ奸")+l11lll1_l1_
		except:
			l1lllll1lll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lllll1lll1_l1_)
		if l11ll1_l1_ (u"ࠨࡦࡸࡶࡂ࠭她") in dict[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭奺")]: l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ奻")].split(l11ll1_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ奼"),1)[1].split(l11ll1_l1_ (u"ࠬࠬࠧ好"),1)[0]))
		elif l11ll1_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ奾") in list(dict.keys()): l1l11lll1_l1_ = round(0.5+float(dict[l11ll1_l1_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ奿")])/1000)
		else: l1l11lll1_l1_ = l11ll1_l1_ (u"ࠨ࠲ࠪ妀")
		if l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ妁") not in list(dict.keys()): l11l11l111l_l1_ = dict[l11ll1_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ如")].split(l11ll1_l1_ (u"ࠫࡽ࠭妃"))[1]
		else: l11l11l111l_l1_ = dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭妄")]
		if l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ妅") not in list(dict.keys()): dict[l11ll1_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ妆")] = l11ll1_l1_ (u"ࠨ࠲࠰࠴ࠬ妇")
		dict[l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ妈")] = l11ll1l11_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ妉")+l111111ll1l1_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠨࠨ妊")+l111111l1ll1_l1_+l11ll1_l1_ (u"ࠬ࠲ࠧ妋")+dict[l11ll1_l1_ (u"࠭ࡩࡵࡣࡪࠫ妌")]+l11ll1_l1_ (u"ࠧࠪࠩ妍")
		dict[l11ll1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ妎")] = l111111ll1l1_l1_.split(l11ll1_l1_ (u"ࠩࠣࠤࠬ妏"))[0].split(l11ll1_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ妐"))[0]
		dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ妑")] = l11ll1l11_l1_
		dict[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ妒")] = l11lll1_l1_
		dict[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭妓")] = codecs
		dict[l11ll1_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ妔")] = l1l11lll1_l1_
		dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ妕")] = l11l11l111l_l1_
		l111llll1l1l_l1_.append(dict)
	l111l1llllll_l1_,l11l111l11ll_l1_,l11l1l11111l_l1_,l1111llll1l1_l1_,l111lll11l11_l1_ = [],[],[],[],[]
	l1111ll11lll_l1_,l111lllllll1_l1_,l1111l1l11l1_l1_,l11l11l1lll1_l1_,l11l11llll11_l1_ = [],[],[],[],[]
	if l1lllll1lll11_l1_:
		dict = {}
		dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ妖")] = l11ll1_l1_ (u"ࠪࡅ࠰࡜ࠧ妗")
		dict[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭妘")] = l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ妙")
		dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ妚")] = dict[l11ll1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭妛")]+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ妜")+dict[l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ妝")]+l11ll1_l1_ (u"ࠪࠤࠥ࠭妞")+l11ll1_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ妟")
		dict[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ妠")] = l1lllll1lll11_l1_
		dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ妡")] = l11ll1_l1_ (u"ࠧ࠱ࠩ妢") # for l11l1l11l1_l1_ l1lllll1lll11_l1_ any l1l111lll_l1_ will l111lll1l1l1_l1_ l11111l1llll_l1_ sort l1l1l1lll1l_l1_
		dict[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ妣")] = l11ll1_l1_ (u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭妤") # 20
		l111llll1l1l_l1_.append(dict)
	if l11l1l111ll1_l1_:
		l1111111l1ll_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l11l1l111ll1_l1_)
		l11l11l11111_l1_ = list(zip(l1111111l1ll_l1_,l11l1111l1ll_l1_))
		for title,l1lllll_l1_ in l11l11l11111_l1_:
			dict = {}
			dict[l11ll1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ妥")] = l11ll1_l1_ (u"ࠫࡆ࠱ࡖࠨ妦")
			dict[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ妧")] = l11ll1_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ妨")
			dict[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ妩")] = l1lllll_l1_
			#if l11ll1_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭妪") in title: dict[l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ妫")] = title.split(l11ll1_l1_ (u"ࠪࠤࠥ࠭妬"))[1].split(l11ll1_l1_ (u"ࠫࡰࡨࡰࡴࠩ妭"))[0]
			#if l11ll1_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ妮") in title: dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ妯")] = title.split(l11ll1_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭妰"))[1]
			# title = l11ll1_l1_ (u"ࠣ࠶࠵࠺࠼ࡱࡢࡱࡵࠣࠤ࠼࠸࠰ࠡࠢ࠱ࡱ࠸ࡻ࠸ࠣ妱")
			if l11ll1_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ妲") in title: dict[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ妳")] = title.split(l11ll1_l1_ (u"ࠫࡰࡨࡰࡴࠩ妴"))[0].rsplit(l11ll1_l1_ (u"ࠬࠦࠠࠨ妵"))[-1]
			else: dict[l11ll1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ妶")] = l11ll1_l1_ (u"ࠧ࠲࠲ࠪ妷")
			if title.count(l11ll1_l1_ (u"ࠨࠢࠣࠫ妸"))>1:
				l111llll_l1_ = title.rsplit(l11ll1_l1_ (u"ࠩࠣࠤࠬ妹"))[-3]
				if l111llll_l1_.isdigit(): dict[l11ll1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ妺")] = l111llll_l1_
				else: dict[l11ll1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ妻")] = l11ll1_l1_ (u"ࠬ࠶࠰࠱࠲ࠪ妼")
			#dict[l11ll1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ妽")] = title
			if title==l11ll1_l1_ (u"ࠧ࠮࠳ࠪ妾"): dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ妿")] = dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ姀")]+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ姁")+dict[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭姂")]+l11ll1_l1_ (u"ࠬࠦࠠࠨ姃")+l11ll1_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ姄")
			else: dict[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭姅")] = dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ姆")]+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭姇")+dict[l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ姈")]+l11ll1_l1_ (u"ࠫࠥࠦࠧ姉")+dict[l11ll1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭姊")]+l11ll1_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭始")+dict[l11ll1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ姌")]
			l111llll1l1l_l1_.append(dict)
	l111llll1l1l_l1_ = sorted(l111llll1l1l_l1_,reverse=True,key=lambda key: float(key[l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ姍")]))
	if not l111llll1l1l_l1_:
		l1ll11l11ll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ姎"),html,re.DOTALL)
		l1ll11l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ姏"),html,re.DOTALL)
		l111l1lll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ姐"),html,re.DOTALL)
		l111l1lll1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姑"),html,re.DOTALL)
		try: l111l1llll11_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ姒")][l11ll1_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ姓")][l11ll1_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ委")][l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ姕")][l11ll1_l1_ (u"ࠪࡶࡺࡴࡳࠨ姖")][0][l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ姗")]
		except: l111l1llll11_l1_ = l11ll1_l1_ (u"ࠬ࠭姘")
		try: l111l1llll1l_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ姙")][l11ll1_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ姚")][l11ll1_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ姛")][l11ll1_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ姜")][0][l11ll1_l1_ (u"ࠪࡶࡺࡴࡳࠨ姝")][0][l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ姞")]
		except: l111l1llll1l_l1_ = l11ll1_l1_ (u"ࠬ࠭姟")
		try: l11111l1ll11_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ姠")][l11ll1_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ姡")]
		except: l11111l1ll11_l1_ = l11ll1_l1_ (u"ࠨࠩ姢")
		if l1ll11l11ll_l1_ or l1ll11l1l11_l1_ or l111l1lll1l1_l1_ or l111l1lll1ll_l1_ or l111l1llll11_l1_ or l111l1llll1l_l1_ or l11111l1ll11_l1_:
			if   l1ll11l11ll_l1_: message = l1ll11l11ll_l1_[0]
			elif l1ll11l1l11_l1_: message = l1ll11l1l11_l1_[0]
			elif l111l1lll1l1_l1_: message = l111l1lll1l1_l1_[0]
			elif l111l1lll1ll_l1_: message = l111l1lll1ll_l1_[0]
			elif l111l1llll11_l1_: message = l111l1llll11_l1_
			elif l111l1llll1l_l1_: message = l111l1llll1l_l1_
			elif l11111l1ll11_l1_: message = l11111l1ll11_l1_
			l1111l111lll_l1_ = message.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ姣"),l11ll1_l1_ (u"ࠪࠫ姤")).strip(l11ll1_l1_ (u"ࠫࠥ࠭姥"))
			l111ll1ll111_l1_ = l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭姦")
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ姧"),l11ll1_l1_ (u"ࠧࠨ姨"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ姩"),l111ll1ll111_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ姪")+l1111l111lll_l1_)
			return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ姫")+l1111l111lll_l1_,[],[]
		else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ姬"),[],[]
	l111ll1ll1ll_l1_,l1lllll11l1l1_l1_,l111l1l1l111_l1_ = [],[],[]
	for dict in l111llll1l1l_l1_:
		if dict[l11ll1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ姭")]==l11ll1_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ姮"):
			l111l1llllll_l1_.append(dict[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭姯")])
			l1111ll11lll_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ姰")]==l11ll1_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ姱"):
			l11l111l11ll_l1_.append(dict[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ姲")])
			l111lllllll1_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭姳")]==l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ姴"):
			title = dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ姵")].replace(l11ll1_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ姶"),l11ll1_l1_ (u"ࠨࠩ姷"))
			if l11ll1_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ姸") not in list(dict.keys()): l11l11l111l_l1_ = l11ll1_l1_ (u"ࠪ࠴ࠬ姹")
			else: l11l11l111l_l1_ = dict[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ姺")]
			l111ll1ll1ll_l1_.append([dict,{},title,l11l11l111l_l1_])
		else:
			title = dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ姻")].replace(l11ll1_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭姼"),l11ll1_l1_ (u"ࠧࠨ姽"))
			if l11ll1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ姾") not in list(dict.keys()): l11l11l111l_l1_ = l11ll1_l1_ (u"ࠩ࠳ࠫ姿")
			else: l11l11l111l_l1_ = dict[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ娀")]
			l111ll1ll1ll_l1_.append([dict,{},title,l11l11l111l_l1_])
			l11l1l11111l_l1_.append(title)
			l1111l1l11l1_l1_.append(dict)
		l11l11l111ll_l1_ = True
		if l11ll1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ威") in list(dict.keys()):
			if l11ll1_l1_ (u"ࠬࡧࡶ࠱ࠩ娂") in dict[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭娃")]: l11l11l111ll_l1_ = False
			elif kodi_version<18:
				if l11ll1_l1_ (u"ࠧࡢࡸࡦࠫ娄") not in dict[l11ll1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ娅")] and l11ll1_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ娆") not in dict[l11ll1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ娇")]: l11l11l111ll_l1_ = False
		if dict[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ娈")]==l11ll1_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ娉") and dict[l11ll1_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ娊")]!=l11ll1_l1_ (u"ࠧ࠱࠯࠳ࠫ娋") and l11l11l111ll_l1_==True:
			l111lll11l11_l1_.append(dict[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ娌")])
			l11l11llll11_l1_.append(dict)
		elif dict[l11ll1_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ娍")]==l11ll1_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ娎") and dict[l11ll1_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ娏")]!=l11ll1_l1_ (u"ࠬ࠶࠭࠱ࠩ娐") and l11l11l111ll_l1_==True:
			l1111llll1l1_l1_.append(dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ娑")])
			l11l11l1lll1_l1_.append(dict)
		#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ娒"),l11ll1_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ娓")+dict[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ娔")])
	for l11l111ll1l1_l1_ in l11l11l1lll1_l1_:
		l1111llllll1_l1_ = l11l111ll1l1_l1_[l11ll1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ娕")]
		for l111l1ll1l1l_l1_ in l11l11llll11_l1_:
			l111111lll1l_l1_ = l111l1ll1l1l_l1_[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ娖")]
			l11l11l111l_l1_ = l111111lll1l_l1_+l1111llllll1_l1_
			title = l111l1ll1l1l_l1_[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ娗")].replace(l11ll1_l1_ (u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ娘"),l11ll1_l1_ (u"ࠧ࡮ࡲࡧࠤࠥ࠭娙"))
			title = title.replace(l111l1ll1l1l_l1_[l11ll1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ娚")]+l11ll1_l1_ (u"ࠩࠣࠤࠬ娛"),l11ll1_l1_ (u"ࠪࠫ娜"))
			title = title.replace(str((float(l111111lll1l_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠫࡰࡨࡰࡴࠩ娝"),str((float(l11l11l111l_l1_*10)//1024/10))+l11ll1_l1_ (u"ࠬࡱࡢࡱࡵࠪ娞"))
			title = title+l11ll1_l1_ (u"࠭ࠨࠨ娟")+l11l111ll1l1_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭娠")].split(l11ll1_l1_ (u"ࠨࠪࠪ娡"),1)[1]
			l111ll1ll1ll_l1_.append([l111l1ll1l1l_l1_,l11l111ll1l1_l1_,title,l11l11l111l_l1_])
	l111ll1ll1ll_l1_ = sorted(l111ll1ll1ll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111l1ll1l1l_l1_,l11l111ll1l1_l1_,title,l11l11l111l_l1_ in l111ll1ll1ll_l1_:
		l111llll11l1_l1_ = l111l1ll1l1l_l1_[l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ娢")]
		if l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ娣") in list(l11l111ll1l1_l1_.keys()):
			l111llll11l1_l1_ = l11ll1_l1_ (u"ࠫࡲࡶࡤࠨ娤")
			#l111llll11l1_l1_ = l111llll11l1_l1_+l11l111ll1l1_l1_[l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ娥")]
		if l111llll11l1_l1_ not in l111l1l1l111_l1_:
			l111l1l1l111_l1_.append(l111llll11l1_l1_)
			l1lllll11l1l1_l1_.append([l111l1ll1l1l_l1_,l11l111ll1l1_l1_,title,l11l11l111l_l1_])
			#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ娦"),str(l11l11l111l_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ娧")+title)
	#l1lllll11l1l1_l1_ = sorted(l1lllll11l1l1_l1_, reverse=True, key=lambda key: int(key[3]))
	l11111l1l1ll_l1_,l1111lll111l_l1_,shift = [],[],0
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࡳࡩ࡫ࡩࡸࠥ࠱࠽ࠡ࠳ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ࠰ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠶ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ娨")
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏ࡯ࡸࡰࡨࡶࡤࡩࡨࡢࡰࡱࡩࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰࡤࡰࡳࡰࡰ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡱࡺࡲࡪࡸ࡟࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡡࡶࡶ࡫ࡳࡷࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬ࡠ࡬ࡶࡳࡳ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨ࠾ࠏࠏࠉࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠧ࠮࠮ࠫࡁࠬࠦࡦࡲ࡬ࡰࡹࡕࡥࡹ࡯࡮ࡨࡵࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥ࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭࡫ࡰࡥ࡬࡫ࡳࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡶࡴ࡯࠾ࠥ࡯࡭ࡢࡩࡨࠤࡂࠦࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮࡞࠱࠶ࡣࠊࠊࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫࡛࠱࡟ࠍࠍࠎࡹࡨࡪࡨࡷࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ࠯ࡴࡽ࡮ࡦࡴ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾࡚ࠢࡉࡇ࡙ࡉࡕࡇࡖ࡟ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭࡝࡜࠲ࡠ࠯ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ࠭ࡲࡻࡳ࡫ࡲࡠࡥ࡫ࡥࡳࡴࡥ࡭࡝࠳ࡡࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡣࡩࡱ࡬ࡧࡪࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ娩")
	l11l11l11l1l_l1_,l111lll1ll11_l1_ = l11ll1_l1_ (u"ࠪࠫ娪"),l11ll1_l1_ (u"ࠫࠬ娫")
	try: l11l11l11l1l_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ娬")][l11ll1_l1_ (u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭娭")]
	except: l11l11l11l1l_l1_ = l11ll1_l1_ (u"ࠧࠨ娮")
	try: l1111l11l111_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ娯")][l11ll1_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ娰")]
	except: l1111l11l111_l1_ = l11ll1_l1_ (u"ࠪࠫ娱")
	if l11l11l11l1l_l1_ and l1111l11l111_l1_:
		shift += 1
		title = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ娲")+l11l11l11l1l_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ娳")
		l1lllll_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ娴")][0]+l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ娵")+l1111l11l111_l1_
		l11111l1l1ll_l1_.append(title)
		l1111lll111l_l1_.append(l1lllll_l1_)
		try: l111lll1ll11_l1_ = l111111l1l1l_l1_[l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ娶")][l11ll1_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ娷")][l11ll1_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ娸")][-1][l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ娹")]
		except: pass
	#if l1lllll1lll11_l1_:
	#	shift += 1
	#	l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ࠬࡳࡰࡥࠢฯ์ิฯࠠัๅํอࠬ娺")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ娻"))
	for l111l1ll1l1l_l1_,l11l111ll1l1_l1_,title,l11l11l111l_l1_ in l1lllll11l1l1_l1_:
		l11111l1l1ll_l1_.append(title) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ娼"))
	if l11l1l11111l_l1_: l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯะหࠪ娽")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ娾"))
	if l111ll1ll1ll_l1_: l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦวๅ็อ์ๆืࠧ娿")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ婀"))
	if l111lll11l11_l1_: l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ࠬࡳࡰࡥࠢสาฯืࠠศๆุ์ึฯ้ࠠษ็ูํะࠧ婁")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"࠭࡭ࡱࡦࠪ婂"))
	if l111l1llllll_l1_: l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ࠧึ๊ิอࠥฮฯู้่ࠣํะࠧ婃")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婄"))
	if l11l111l11ll_l1_: l11111l1l1ll_l1_.append(l11ll1_l1_ (u"ุࠩ์ฯࠦศะ๊้ࠤฺ๎ัสࠩ婅")) ; l1111lll111l_l1_.append(l11ll1_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ婆"))
	l11l1l1111ll_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1llll1llllll_l1_, l11111l1l1ll_l1_)
		if l1l_l1_==-1: return l11ll1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ婇"),[],[]
		elif l1l_l1_==0 and l11l11l11l1l_l1_:
			l1lllll_l1_ = l1111lll111l_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11ll1_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠶ࠬ࡮ࡢ࡯ࡨࡁࠬ婈")+QUOTE(l11l11l11l1l_l1_)+l11ll1_l1_ (u"࠭ࠦࡶࡴ࡯ࡁࠬ婉")+l1lllll_l1_
			if l111lll1ll11_l1_: new_path = new_path+l11ll1_l1_ (u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ婊")+QUOTE(l111lll1ll11_l1_)
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ婋")+new_path+l11ll1_l1_ (u"ࠤࠬࠦ婌"))
			return l11ll1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ婍"),[],[]
		choice = l1111lll111l_l1_[l1l_l1_]
		l111111111ll_l1_ = l11111l1l1ll_l1_[l1l_l1_]
		if choice==l11ll1_l1_ (u"ࠫࡩࡧࡳࡩࠩ婎"):
			l1llllll1ll1l_l1_ = l1lllll1lll11_l1_
			break
		elif choice in [l11ll1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ婏"),l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ婐"),l11ll1_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭婑")]:
			if choice==l11ll1_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ婒"): l1lll11l_l1_,l1111l1l1lll_l1_ = l11l1l11111l_l1_,l1111l1l11l1_l1_
			elif choice==l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ婓"): l1lll11l_l1_,l1111l1l1lll_l1_ = l111l1llllll_l1_,l1111ll11lll_l1_
			elif choice==l11ll1_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ婔"): l1lll11l_l1_,l1111l1l1lll_l1_ = l11l111l11ll_l1_,l111lllllll1_l1_
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ婕"), l1lll11l_l1_)
			if l1l_l1_!=-1:
				l1llllll1ll1l_l1_ = l1111l1l1lll_l1_[l1l_l1_][l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ婖")]
				l111111111ll_l1_ = l1lll11l_l1_[l1l_l1_]
				break
		elif choice==l11ll1_l1_ (u"࠭࡭ࡱࡦࠪ婗"):
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่าห࠽ࠫ婘"), l111lll11l11_l1_)
			if l1l_l1_!=-1:
				l111111111ll_l1_ = l111lll11l11_l1_[l1l_l1_]
				l111lll1ll1l_l1_ = l11l11llll11_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬ࠽ࠫ婙"), l1111llll1l1_l1_)
				if l1l_l1_!=-1:
					l111111111ll_l1_ += l11ll1_l1_ (u"ࠩࠣ࠯ࠥ࠭婚")+l1111llll1l1_l1_[l1l_l1_]
					l111l1ll11ll_l1_ = l11l11l1lll1_l1_[l1l_l1_]
					l11l1l1111ll_l1_ = True
					break
		elif choice==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ婛"):
			l11l11111lll_l1_,l111l1111l11_l1_,l1lllll11llll_l1_,l111ll1l1l11_l1_ = list(zip(*l111ll1ll1ll_l1_))
			l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ婜"), l1lllll11llll_l1_)
			if l1l_l1_!=-1:
				l111111111ll_l1_ = l1lllll11llll_l1_[l1l_l1_]
				l111lll1ll1l_l1_ = l11l11111lll_l1_[l1l_l1_]
				if l11ll1_l1_ (u"ࠬࡳࡰࡥࠩ婝") in l1lllll11llll_l1_[l1l_l1_] and l111lll1ll1l_l1_[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ婞")]!=l1lllll1lll11_l1_:
					l111l1ll11ll_l1_ = l111l1111l11_l1_[l1l_l1_]
					l11l1l1111ll_l1_ = True
				else: l1llllll1ll1l_l1_ = l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ婟")]
				break
		elif choice==l11ll1_l1_ (u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ婠"):
			#shift += 1
			l11l11111lll_l1_,l111l1111l11_l1_,l1lllll11llll_l1_,l111ll1l1l11_l1_ = list(zip(*l1lllll11l1l1_l1_))
			l111lll1ll1l_l1_ = l11l11111lll_l1_[l1l_l1_-shift]
			if l11ll1_l1_ (u"ࠩࡰࡴࡩ࠭婡") in l1lllll11llll_l1_[l1l_l1_-shift] and l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ婢")]!=l1lllll1lll11_l1_:
				l111l1ll11ll_l1_ = l111l1111l11_l1_[l1l_l1_-shift]
				l11l1l1111ll_l1_ = True
			else: l1llllll1ll1l_l1_ = l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ婣")]
			l111111111ll_l1_ = l1lllll11llll_l1_[l1l_l1_-shift]
			break
	if not l11l1l1111ll_l1_: l1llllll1l111_l1_ = l1llllll1ll1l_l1_
	else: l1llllll1l111_l1_ = l11ll1_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭婤")+l111lll1ll1l_l1_[l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ婥")]+l11ll1_l1_ (u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫ婦")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ婧")]
	if l11l1l1111ll_l1_:
		#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ婨"),l11ll1_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ婩")+str(l111lll1ll1l_l1_))
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ婪"),l11ll1_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ婫")+str(l111l1ll11ll_l1_))
		#if l11l11lll1l1_l1_>l111l1l111ll_l1_: l1l11lll1_l1_ = str(l11l11lll1l1_l1_)
		#else: l1l11lll1_l1_ = str(l111l1l111ll_l1_)
		#l1l11lll1_l1_ = str(l11l11lll1l1_l1_) if l11l11lll1l1_l1_>l111l1l111ll_l1_ else str(l111l1l111ll_l1_)
		l11l11lll1l1_l1_ = int(l111lll1ll1l_l1_[l11ll1_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ婬")])
		l111l1l111ll_l1_ = int(l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ婭")])
		l1l11lll1_l1_ = str(max(l11l11lll1l1_l1_,l111l1l111ll_l1_))
		l111l11l11ll_l1_ = l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ婮")].replace(l11ll1_l1_ (u"ࠩࠩࠫ婯"),l11ll1_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ婰"))		# +l11ll1_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ婱")
		l11l111l1l11_l1_ = l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ婲")].replace(l11ll1_l1_ (u"࠭ࠦࠨ婳"),l11ll1_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭婴"))		# +l11ll1_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ婵")
		l11l1l111111_l1_ = l11ll1_l1_ (u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨ婶")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫ婷")+l1l11lll1_l1_+l11ll1_l1_ (u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰࠪ婸")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ婹")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪ婺")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ婻")]+l11ll1_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ婼")		# l111l1l1l1l1_l1_=l11ll1_l1_ (u"ࠤ࠴ࠦ婽") l11l11lllll1_l1_=l11ll1_l1_ (u"ࠥࡸࡷࡻࡥࠣ婾") default=l11ll1_l1_ (u"ࠦࡹࡸࡵࡦࠤ婿")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ媀")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭媁")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ媂")]+l11ll1_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ媃")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ媄")]+l11ll1_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭媅")+str(l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ媆")])+l11ll1_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ媇")+str(l111lll1ll1l_l1_[l11ll1_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ媈")])+l11ll1_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ媉")+str(l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ媊")])+l11ll1_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ媋")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠪࡪࡵࡹࠧ媌")]+l11ll1_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ媍")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ媎")+l111l11l11ll_l1_+l11ll1_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ媏")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ媐")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ媑")]+l11ll1_l1_ (u"ࠩࠥࡂࡡࡴࠧ媒")	# l1lllll11l1ll_l1_=l11ll1_l1_ (u"ࠥࡸࡷࡻࡥࠣ媓")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ媔")+l111lll1ll1l_l1_[l11ll1_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ媕")]+l11ll1_l1_ (u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭媖")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ媗")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ媘")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ媙")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠳ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧ媚")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭媛")]+l11ll1_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ媜")		# l111l1l1l1l1_l1_=l11ll1_l1_ (u"ࠨ࠱ࠣ媝") l11l11lllll1_l1_=l11ll1_l1_ (u"ࠢࡵࡴࡸࡩࠧ媞") default=l11ll1_l1_ (u"ࠣࡶࡵࡹࡪࠨ媟")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ媠")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ媡")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ媢")]+l11ll1_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ媣")+l111l1ll11ll_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭媤")]+l11ll1_l1_ (u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ媥")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧ媦")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ媧")]+l11ll1_l1_ (u"ࠪࠦ࠴ࡄ࡜࡯ࠩ媨")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ媩")+l11l111l1l11_l1_+l11ll1_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ媪")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ媫")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭媬")]+l11ll1_l1_ (u"ࠨࠤࡁࡠࡳ࠭媭")	# l1lllll11l1ll_l1_=l11ll1_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ媮")>\n
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭媯")+l111l1ll11ll_l1_[l11ll1_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ媰")]+l11ll1_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ媱")
		l11l1l111111_l1_ += l11ll1_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ媲")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭媳")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭媴")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ媵")
		l11l1l111111_l1_ += l11ll1_l1_ (u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬ媶")
		#open(l11ll1_l1_ (u"ࠫࡸࡀ࡜࡝ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭媷"),l11ll1_l1_ (u"ࠬࡽࡢࠨ媸")).write(l11l1l111111_l1_)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ媹"),l11l1l111111_l1_)
		#l11l1l111111_l1_ = OPENURL_CACHED(NO_CACHE,l1lllll1lll11_l1_,l11ll1_l1_ (u"ࠧࠨ媺"),l11ll1_l1_ (u"ࠨࠩ媻"),l11ll1_l1_ (u"ࠩࠪ媼"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠺ࡶ࡫ࠫ媽"))
		if kodi_version>18.99:
			import http.server as l111ll11l111_l1_
			import http.client as l11111l1l1l1_l1_
		else:
			import BaseHTTPServer as l111ll11l111_l1_
			import httplib as l11111l1l1l1_l1_
		class l1llllllllll1_l1_(l111ll11l111_l1_.HTTPServer):
			#l11l1l111111_l1_ = l11ll1_l1_ (u"ࠫࡁࡄࠧ媾")
			def __init__(self,l1ll11111l1l_l1_=l11ll1_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ媿"),port=55055,l11l1l111111_l1_=l11ll1_l1_ (u"࠭࠼࠿ࠩ嫀")):
				self.l1ll11111l1l_l1_ = l1ll11111l1l_l1_
				self.port = port
				self.l11l1l111111_l1_ = l11l1l111111_l1_
				l111ll11l111_l1_.HTTPServer.__init__(self,(self.l1ll11111l1l_l1_,self.port),l1111lll1l11_l1_)
				self.l1lllllll1ll1_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ嫁")+l1ll11111l1l_l1_+l11ll1_l1_ (u"ࠨ࠼ࠪ嫂")+str(port)+l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ嫃")
				#print(l11ll1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡵࡱࠢࡱࡳࡼࠦ࡬ࡪࡵࡷࡩࡳ࡯࡮ࡨࠢࡲࡲࠥࡶ࡯ࡳࡶ࠽ࠤࠬ嫄")+str(port))
			def start(self):
				self.threads = l111l1l111l_l1_(False)
				self.threads.start_new_thread(1,self.l111l11lll1l_l1_)
			def l111l11lll1l_l1_(self):
				#print(l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡤࡶࡹ࡫ࡤࠨ嫅"))
				self.l1lllll111ll1_l1_ = True
				#l1l1l1lllll_l1_ = 0
				while self.l1lllll111ll1_l1_:
					#l1l1l1lllll_l1_ += 1
					#print(l11ll1_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡪࡤࡲࡩࡲࡥࡠࡴࡨࡵࡺ࡫ࡳࡵࠪࠬࠤࡳࡵࡷ࠻ࠢࠪ嫆")+str(l1l1l1lllll_l1_)+l11ll1_l1_ (u"࠭ࠧ嫇"))
					#settimeout l1111ll1ll_l1_ not l111l1l111_l1_ l1111l11111l_l1_ to error message if it l111111l11ll_l1_ l1lllll1l1l1l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111l11lll1l_l1_ l111l1l11lll_l1_ request l1llllll1llll_l1_ 60 seconds)
					self.handle_request()
				#print(l11ll1_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡵࡰࡱࡧࡧࡠࡳ࠭嫈"))
			def stop(self):
				self.l1lllll111ll1_l1_ = False
				self.l111l1ll1ll1_l1_()	# needed to l11l11ll111l_l1_ self.handle_request() to l111l11lll1l_l1_ l1111l1ll1l_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠢࡱࡳࡼࡢ࡮ࠨ嫉"))
			def load(self,l11l1l111111_l1_):
				self.l11l1l111111_l1_ = l11l1l111111_l1_
			def l111l1ll1ll1_l1_(self):
				conn = l11111l1l1l1_l1_.HTTPConnection(self.l1ll11111l1l_l1_+l11ll1_l1_ (u"ࠩ࠽ࠫ嫊")+str(self.port))
				conn.request(l11ll1_l1_ (u"ࠥࡌࡊࡇࡄࠣ嫋"), l11ll1_l1_ (u"ࠦ࠴ࠨ嫌"))
		class l1111lll1l11_l1_(l111ll11l111_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11ll1_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡌࡋࡔࠡࠢࠪ嫍")+self.path)
				self.send_response(200)
				self.send_header(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ嫎"),l11ll1_l1_ (u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ嫏"))
				self.end_headers()
				#self.wfile.write(self.path+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ嫐"))
				self.wfile.write(self.server.l11l1l111111_l1_.encode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ嫑")))
				time.sleep(1)
				if self.path==l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ嫒"): self.server.shutdown()
				if self.path==l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ嫓"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11ll1_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡍࡋࡁࡅࠢࠣࠫ嫔")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1llllllllll1_l1_(l11ll1_l1_ (u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ嫕"),55055,l11l1l111111_l1_)
		#httpd.load(l11l1l111111_l1_)
		l1llllll1ll1l_l1_ = httpd.l1lllllll1ll1_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮࡬ࡺࡪࡹࡩ࡮࠰ࡧࡥࡸ࡮ࡩࡧ࠰ࡲࡶ࡬࠵࡬ࡪࡸࡨࡷ࡮ࡳ࠯ࡤࡪࡸࡲࡰࡪࡵࡳࡡ࠴࠳ࡦࡺ࡯ࡠ࠹࠲ࡸࡪࡹࡴࡱ࡫ࡦ࠸ࡤ࠾ࡳ࠰ࡏࡤࡲ࡮࡬ࡥࡴࡶ࠱ࡱࡵࡪࠧ嫖")
		#l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡥࡸ࡮࠮ࡢ࡭ࡤࡱࡦ࡯ࡺࡦࡦ࠱ࡲࡪࡺ࠯ࡥࡣࡶ࡬࠷࠼࠴࠰ࡖࡨࡷࡹࡉࡡࡴࡧࡶ࠳࠷ࡩ࠯ࡲࡷࡤࡰࡨࡵ࡭࡮࠱࠴࠳ࡒࡻ࡬ࡵ࡫ࡕࡩࡸࡓࡐࡆࡉ࠵࠲ࡲࡶࡤࠨ嫗")
		#l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹࡹࡩ࠯ࡶࡨࡰࡪࡩ࡯࡮࠯ࡳࡥࡷ࡯ࡳࡵࡧࡦ࡬࠳࡬ࡲ࠰ࡩࡳࡥࡨ࠵ࡄࡂࡕࡋࡣࡈࡕࡎࡇࡑࡕࡑࡆࡔࡃࡆ࠱ࡗࡩࡱ࡫ࡣࡰ࡯ࡓࡥࡷ࡯ࡳࡕࡧࡦ࡬࠴ࡳࡰ࠵࠯࡯࡭ࡻ࡫࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠯ࡰࡴࡩ࠳ࡁࡗ࠯ࡅࡗ࠳ࡳࡰࡥࠩ嫘")
		#l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡶࡩࡳࡥࡥ࡫ࡤ࠲ࡧࡨࡣ࠯ࡥࡲ࠲ࡺࡱ࠯ࡥࡣࡶ࡬࠴ࡵ࡮ࡥࡧࡰࡥࡳࡪ࠯ࡵࡧࡶࡸࡨࡧࡲࡥ࠱࠴࠳ࡨࡲࡩࡦࡰࡷࡣࡲࡧ࡮ࡪࡨࡨࡷࡹ࠳ࡥࡷࡧࡱࡸࡸ࠳࡭ࡶ࡮ࡷ࡭ࡱࡧ࡮ࡨ࠰ࡰࡴࡩ࠭嫙")
		#l1llllll1ll1l_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ嫚")
	else: httpd = l11ll1_l1_ (u"ࠬ࠭嫛")
	if not l1llllll1ll1l_l1_: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭嫜"),[],[]
	return l11ll1_l1_ (u"ࠧࠨ嫝"),[l11ll1_l1_ (u"ࠨࠩ嫞")],[[l1llllll1ll1l_l1_,l111l111l1l1_l1_,httpd]]
def l1111l111l11_l1_(url):
	# https://l11l11l1l1l1_l1_.com/l1111ll11ll1_l1_
	headers = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嫟") : l11ll1_l1_ (u"ࠪࠫ嫠") }
	#url = url.replace(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ嫡"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ嫢"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ嫣"),headers,l11ll1_l1_ (u"ࠧࠨ嫤"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨ嫥"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭嫦"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1111111l1ll_l1_,l1lll11l_l1_,l11l1111l1ll_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1lllll_l1_,dummy,l1ll1l1l1ll1_l1_ in items:
			l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ嫧"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ嫨"))
			if l11ll1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ嫩") in l1lllll_l1_:
				l1111111l1ll_l1_,l11l1111l1ll_l1_ = l11ll11l1l_l1_(l1lllll_l1_)
				#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嫪"),l11ll1_l1_ (u"ࠧࠨ嫫"),str(l1llll_l1_),str(l11l1111l1ll_l1_))
				l1llll_l1_ = l1llll_l1_ + l11l1111l1ll_l1_
				if l1111111l1ll_l1_[0]==l11ll1_l1_ (u"ࠨ࠯࠴ࠫ嫬"): l1lll11l_l1_.append(l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ嫭")+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ嫮"))
				else:
					for title in l1111111l1ll_l1_:
						l1lll11l_l1_.append(l11ll1_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ嫯")+l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ嫰")+title)
			else:
				title = l11ll1_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ嫱")+l11ll1_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ嫲")+l1ll1l1l1ll1_l1_
				l1llll_l1_.append(l1lllll_l1_)
				l1lll11l_l1_.append(title)
		return l11ll1_l1_ (u"ࠨࠩ嫳"),l1lll11l_l1_,l1llll_l1_
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ嫴"),[],[]
def	l1lllll1llll1_l1_(url):
	# https://l11l11ll1l11_l1_.cc/l1l111l1l_l1_-1qrpoobdg7bu.html
	# https://l111l1ll111l_l1_.cc//l1l111l1l_l1_-l111ll1l1l1l_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嫵"),url,l11ll1_l1_ (u"ࠫࠬ嫶"),l11ll1_l1_ (u"ࠬ࠭嫷"),l11ll1_l1_ (u"࠭ࠧ嫸"),l11ll1_l1_ (u"ࠧࠨ嫹"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡜ࡉࡅࡇࡒࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ嫺"))
	html = response.content
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嫻"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		return l11ll1_l1_ (u"ࠪࠫ嫼"),[l11ll1_l1_ (u"ࠫࠬ嫽")],[l1lllll_l1_]
	return l11ll1_l1_ (u"ࠬ࠭嫾"),[],[]
def	l1llllll11ll1_l1_(url):
	# https://l1llllll11l1l_l1_.in/l111111l1lll_l1_
	# https://l1llllll11l1l_l1_.in/l1l111l1l_l1_-l111111l1lll_l1_.html
	# https://l111ll11ll1l_l1_.l11111ll1l11_l1_/l11l11l1111l_l1_
	# https://l111ll11ll1l_l1_.l11111ll1l11_l1_/l1l111l1l_l1_-l11l11l1111l_l1_.html
	# https://www.l11l11l11lll_l1_.com/l1l111l1l_l1_-l111l1111111_l1_.html
	url = url.replace(l11ll1_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭嫿"),l11ll1_l1_ (u"ࠧࠨ嬀")).replace(l11ll1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ嬁"),l11ll1_l1_ (u"ࠩࠪ嬂"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ嬃"),url,l11ll1_l1_ (u"ࠫࠬ嬄"),l11ll1_l1_ (u"ࠬ࠭嬅"),l11ll1_l1_ (u"࠭ࠧ嬆"),l11ll1_l1_ (u"ࠧࠨ嬇"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ嬈"))
	html = response.content
	l1ll1l1lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠨ嬉"),html,re.DOTALL)
	if l1ll1l1lll11_l1_:
		l1ll1l1lll11_l1_ = l1ll1l1lll11_l1_[0]
		l1l1lll1111l_l1_ = l1ll1111ll11_l1_(l1ll1l1lll11_l1_)
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ嬊"),l1l1lll1111l_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠭ࢂ࠭嬋"),l1l1lll1111l_l1_,re.DOTALL)
		l1lll11l_l1_,l1llll_l1_ = [],[]
		for l1lllll_l1_,title in l1l1_l1_:
			if not title: title = l1lllll_l1_.rsplit(l11ll1_l1_ (u"ࠬ࠴ࠧ嬌"),1)[1]
			l1lll11l_l1_.append(title)
			l1llll_l1_.append(l1lllll_l1_)
		return l11ll1_l1_ (u"࠭ࠧ嬍"),l1lll11l_l1_,l1llll_l1_
	id = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ嬎"))[3]
	headers = { l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嬏"):l11ll1_l1_ (u"ࠩࠪ嬐") , l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ嬑"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ嬒") }
	payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ嬓"):id , l11ll1_l1_ (u"࠭࡯ࡱࠩ嬔"):l11ll1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ嬕") }
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭嬖"),url,payload,headers,l11ll1_l1_ (u"ࠩࠪ嬗"),l11ll1_l1_ (u"ࠪࠫ嬘"),l11ll1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ嬙"))
	html = response.content
	items = re.findall(l11ll1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嬚"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"࠭ࠧ嬛"),[l11ll1_l1_ (u"ࠧࠨ嬜")],[ items[0] ]
	return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈࠩ嬝"),[],[]
l11ll1_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡊࡓ࡛ࡏࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵࡶࡪࡦ࠱ࡧࡴ࠵ࡶࡪࡦࡨࡳ࠴ࡶ࡬ࡢࡻ࠲ࡅࡆ࡜ࡅࡏࡦࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࠡ࠼ࠣࠫࠬࠦࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡖࡊࡆ࠰࠵ࡸࡺࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡪࠥ࠭࠮࡮࠵ࡸ࠼ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࡵࡧࡰࡴࡠ࠶࡝࠾࠿ࠪ࠱࠶࠭࠺ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧู๊ࠬࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠾ࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱࡵ࠺ࠧࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔ࡜ࡉࡅࠩ࠯࡟ࡢ࠲࡛࡞ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠲࡯࠱࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡹࡴࡳࡧࡤࡱ࠴࠸࠲࠺࠰ࡰ࠷ࡺ࠾ࠊࠣࠤࠥ嬞")
#####################################################
#    l11l111ll11l_l1_ l1111ll1ll11_l1_ l11111ll1lll_l1_
#    16-06-2019
#####################################################
def l1111l1llll1_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠪࠫ嬟"),l11ll1_l1_ (u"ࠫࠬ嬠"),l11ll1_l1_ (u"ࠬ࠭嬡"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩ嬢"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嬣"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠨࠩ嬤"),[l11ll1_l1_ (u"ࠩࠪ嬥")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨ嬦"),[],[]
def l1111l1l11ll_l1_(url):
	return l11ll1_l1_ (u"ࠫࠬ嬧"),[l11ll1_l1_ (u"ࠬ࠭嬨")],[ url ]
def l1111ll1lll1_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ嬩"),l11ll1_l1_ (u"ࠧࠨ嬪"),url,l11ll1_l1_ (u"ࠨࠩ嬫"))
	server = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ嬬"))
	basename = l11ll1_l1_ (u"ࠪ࠳ࠬ嬭").join(server[0:3])
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠫࠬ嬮"),l11ll1_l1_ (u"ࠬ࠭嬯"),l11ll1_l1_ (u"࠭ࠧ嬰"),l11ll1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ嬱"))
	items = re.findall(l11ll1_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ嬲"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ嬳"),l11ll1_l1_ (u"ࠪࠫ嬴"),url,str(var))
	if items:
		l11ll111lll1_l1_,l11ll11ll1l1_l1_,l11ll11ll1ll_l1_,l111ll1l11l1_l1_,l111ll1l11ll_l1_,l111ll1l111l_l1_ = items[0]
		var = int(l11ll11ll1l1_l1_) % int(l11ll11ll1ll_l1_) + int(l111ll1l11l1_l1_) % int(l111ll1l11ll_l1_)
		url = basename + l11ll111lll1_l1_ + str(var) + l111ll1l111l_l1_
		return l11ll1_l1_ (u"ࠫࠬ嬵"),[l11ll1_l1_ (u"ࠬ࠭嬶")],[url]
	else: return l11ll1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ嬷"),[],[]
def l111ll111lll_l1_(url):
	url = url.replace(l11ll1_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ嬸"),l11ll1_l1_ (u"ࠨࠩ嬹"))
	url = url.replace(l11ll1_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ嬺"),l11ll1_l1_ (u"ࠪࠫ嬻"))
	id = url.split(l11ll1_l1_ (u"ࠫ࠴࠭嬼"))[-1]
	headers = { l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ嬽") : l11ll1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ嬾") }
	payload = { l11ll1_l1_ (u"ࠢࡪࡦࠥ嬿"):id , l11ll1_l1_ (u"ࠣࡱࡳࠦ孀"):l11ll1_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ孁") }
	request = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ孂"), url, payload, headers, l11ll1_l1_ (u"ࠫࠬ孃"),l11ll1_l1_ (u"ࠬ࠭孄"),l11ll1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ孅"))
	if l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ孆") in list(request.headers.keys()): l1lllll_l1_ = request.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ孇")]
	else: l1lllll_l1_ = url
	if l1lllll_l1_: return l11ll1_l1_ (u"ࠩࠪ孈"),[l11ll1_l1_ (u"ࠪࠫ孉")],[l1lllll_l1_]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ孊"),[],[]
def l11111l11l11_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠬ࠭孋"),l11ll1_l1_ (u"࠭ࠧ孌"),l11ll1_l1_ (u"ࠧࠨ孍"),l11ll1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ孎"))
	items = re.findall(l11ll1_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ孏"),html,re.DOTALL)
	if items: return l11ll1_l1_ (u"ࠪࠫ子"),[l11ll1_l1_ (u"ࠫࠬ孑")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ孒"),[],[]
def l1lllll11l111_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"࠭ࠧ孓"),l11ll1_l1_ (u"ࠧࠨ孔"),l11ll1_l1_ (u"ࠨࠩ孕"),l11ll1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ孖"))
	items = re.findall(l11ll1_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ字"),html,re.DOTALL)
	#l111l1ll1111_l1_.l1lllll1l11l1_l1_(l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ存") + items[0])
	if items:
		url = url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ孙") + items[0]
		return l11ll1_l1_ (u"࠭ࠧ孚"),[l11ll1_l1_ (u"ࠧࠨ孛")],[ url ]
	else: return l11ll1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ孜"),[],[]
def l111l11111l1_l1_(url):
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠩࠪ孝"),l11ll1_l1_ (u"ࠪࠫ孞"),l11ll1_l1_ (u"ࠫࠬ孟"),l11ll1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖ࠰࠵ࡸࡺࠧ孠"))
	items = re.findall(l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭孡"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ孢"),l11ll1_l1_ (u"ࠨࠩ季"),str(items),html)
	if items: return l11ll1_l1_ (u"ࠩࠪ孤"),[l11ll1_l1_ (u"ࠪࠫ孥")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡖࡄࡏࡍࡈ࡜ࡉࡅࡇࡒࡌࡔ࡙ࡔࠨ学"),[],[]
def l1111l1ll1l1_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ孧"),l11ll1_l1_ (u"࠭ࠧ孨"))
	html = OPENURL_CACHED(l1ll1lll1_l1_,url,l11ll1_l1_ (u"ࠧࠨ孩"),l11ll1_l1_ (u"ࠨࠩ孪"),l11ll1_l1_ (u"ࠩࠪ孫"),l11ll1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ孬"))
	items = re.findall(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ孭"),html,re.DOTALL)
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭孮"),l11ll1_l1_ (u"࠭ࠧ孯"),items[0],items[0])
	if items: return l11ll1_l1_ (u"ࠧࠨ孰"),[l11ll1_l1_ (u"ࠨࠩ孱")],[ items[0] ]
	else: return l11ll1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ孲"),[],[]
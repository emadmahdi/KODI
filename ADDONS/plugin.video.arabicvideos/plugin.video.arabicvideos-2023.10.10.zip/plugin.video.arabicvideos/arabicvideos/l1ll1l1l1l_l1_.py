# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬᬁ")
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫᬂ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭โศศ่ฮ๏࠭ᬃ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l111_l1_(url)
	elif mode==302: results = l11111_l1_(url)
	elif mode==303: results = l1lll1ll1l_l1_(url)
	elif mode==304: results = l1llll1l_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll1l111l_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᬄ"),l111l1_l1_+l11ll1_l1_ (u"ࠨๆ่หีอࠠศๆ่์็฿ࠠษูํลࠬᬅ"),l11ll1_l1_ (u"ࠩࠪᬆ"),306)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᬇ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᬈ"),l11ll1_l1_ (u"ࠬ࠭ᬉ"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬊ"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᬋ"),l11ll1_l1_ (u"ࠨࠩᬌ"),309,l11ll1_l1_ (u"ࠩࠪᬍ"),l11ll1_l1_ (u"ࠪࠫᬎ"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᬏ"))
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᬐ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᬑ"),l11ll1_l1_ (u"ࠧࠨᬒ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬᬓ"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨᬔ"),l11ll1_l1_ (u"ࠪࠫᬕ"),l11ll1_l1_ (u"ࠫࠬᬖ"),l11ll1_l1_ (u"ࠬ࠭ᬗ"),l11ll1_l1_ (u"࠭ࠧᬘ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᬙ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠨࠩᬚ"),html)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬ࡪࡧࡤࡦࡴࡁࠫᬛ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᬜ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		#l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭ᬝ"))
		#if title==l11ll1_l1_ (u"ࠬืๅืษ้ࠫᬞ"): l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ิ้฻อๆ࠰ࠩᬟ")
		if not any(value in title for value in l1l11l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᬠ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᬡ")+l111l1_l1_+title,l1lllll_l1_,301)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᬢ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᬣ"),l11ll1_l1_ (u"ࠫࠬᬤ"),9999)
	l1l111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᬥ"),html)
	return html
def l1ll1l111l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧᬦ"),l11ll1_l1_ (u"ࠧࠨᬧ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᬨ"),l11ll1_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠢห฻๏วࠠๆ่ࠣห้๋ีะำࠣ࠲࠳ࠦศิสหࠤ็๐วๆࠢฦูาอศࠡษ็้ํู่ࠡสอุๆ๐ัࠡ็ะฮํ๐วหࠢฯ้๏฿ࠠึใะหฯࠦวๅ็๋ๆ฾ࠦ࠮࠯๋ࠢห้๎โหࠢส่฻อฦฺࠢํิ์ฮࠠโ์้ࠣ฾อไอหࠣฮู็๊าࠢสฺ่็อศฬࠣห้๋ิโำฬࠤ็ฮไࠡ฻ิฺ๋ࠥอห๊ํหฯํวࠡใํࠤ็๎วว็๋ࠣีอࠠศๆหี๋อๅอࠩᬩ"))
	return
def l1l111_l1_(url,html=l11ll1_l1_ (u"ࠪࠫᬪ")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᬫ"),url,l11ll1_l1_ (u"ࠬ࠭ᬬ"),l11ll1_l1_ (u"࠭ࠧᬭ"),l11ll1_l1_ (u"ࠧࠨᬮ"),l11ll1_l1_ (u"ࠨࠩᬯ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᬰ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮ࠫࡁ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠯ࠧᬱ"),html,re.DOTALL)
	if l1l1l11_l1_:
		for block in l1l1l11_l1_:
			seq += 1
			items = re.findall(l11ll1_l1_ (u"ࠫࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᬲ"),block,re.DOTALL)
			for title,test,l1lllll_l1_ in items:
				title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧᬳ"))
				if title==l11ll1_l1_ (u"᬴࠭ࠧ"): title = l11ll1_l1_ (u"ࠧษ๊๋์ํ๎ࠧᬵ")
				if l11ll1_l1_ (u"ࠨࡧࡰࡂࡁࡧࠧᬶ") not in test:
					if block.count(l11ll1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᬷ"))>0:
						l1ll1l1111_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᬸ"),block,re.DOTALL)
						for l1lllll_l1_ in l1ll1l1111_l1_:
							title = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫ࠴࠭ᬹ"))[-2]
							addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬺ"),l111l1_l1_+title,l1lllll_l1_,301)
						continue
					else: l1lllll_l1_ = url+l11ll1_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪᬻ")+str(seq)
				#l111l1111_l1_ = [l11ll1_l1_ (u"ࠧๆี็ื้อสࠡࠩᬼ"),l11ll1_l1_ (u"ࠨษไ่ฬ๋ࠠࠨᬽ"),l11ll1_l1_ (u"ࠩหีฬ๋ฬࠨᬾ"),l11ll1_l1_ (u"ࠪ฽ึ๎ึࠨᬿ"),l11ll1_l1_ (u"่๊๊ࠫษษอࠫᭀ"),l11ll1_l1_ (u"ࠬอฺศ่์ࠫᭁ")]
				#if any(value in title for value in l111l1111_l1_):
				if not any(value in title for value in l1l11l_l1_):
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᭂ"),l111l1_l1_+title,l1lllll_l1_,302)
	else: l11111_l1_(url,html)
	return
def l11111_l1_(url,html=l11ll1_l1_ (u"ࠧࠨᭃ")):
	if html==l11ll1_l1_ (u"ࠨ᭄ࠩ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ᭅ"),url,l11ll1_l1_ (u"ࠪࠫᭆ"),l11ll1_l1_ (u"ࠫࠬᭇ"),l11ll1_l1_ (u"ࠬ࠭ᭈ"),l11ll1_l1_ (u"࠭ࠧᭉ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᭊ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11ll1_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬᭋ") in url:
		url,seq = url.split(l11ll1_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ᭌ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮ࠫࡁ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠯ࠧ᭍"),html,re.DOTALL)
		block = l1l1l11_l1_[int(seq)-1]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡶ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡵࡤࡺࡀࠪ᭎"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠬࡂࡡ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᭏"),block,re.DOTALL)
	l11l_l1_ = []
	for l1lllll_l1_,data,l1lll1_l1_ in items:
		title = re.findall(l11ll1_l1_ (u"࠭࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠱࠮ࡄࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡱࡃ࠭᭐"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ᭑"),l11ll1_l1_ (u"ࠨࠩ᭒")).strip(l11ll1_l1_ (u"ࠩࠣࠫ᭓"))
		if not title or title==l11ll1_l1_ (u"ࠪࠫ᭔"):
			title = re.findall(l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥࡂ࠳࠰࠿࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬ᭕"),data,re.DOTALL)
			if title: title = title[0].replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ᭖"),l11ll1_l1_ (u"࠭ࠧ᭗")).strip(l11ll1_l1_ (u"ࠧࠡࠩ᭘"))
			if not title or title==l11ll1_l1_ (u"ࠨࠩ᭙"):
				title = re.findall(l11ll1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᭚"),data,re.DOTALL)
				title = title[0].replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭᭛"),l11ll1_l1_ (u"ࠫࠬ᭜")).strip(l11ll1_l1_ (u"ࠬࠦࠧ᭝"))
		title = unescapeHTML(title)
		#if title==l11ll1_l1_ (u"࠭ࠧ᭞"): continue
		if title not in l11l_l1_:
			l11l_l1_.append(title)
			l111l_l1_ = l1lllll_l1_+data+l1lll1_l1_
			if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩ᭟") in l111l_l1_ or l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ᭠") in l111l_l1_ or l11ll1_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࠦࠬ᭡") in l111l_l1_:
				if l11ll1_l1_ (u"ࠪฬึอๅอࠩ᭢") in data: title = l11ll1_l1_ (u"ࠫอืๆศ็ฯࠤࠬ᭣")+title
				elif l11ll1_l1_ (u"๋ࠬำๅี็ࠫ᭤") in data or l11ll1_l1_ (u"࠭ๅ้ี่ࠫ᭥") in data: title = l11ll1_l1_ (u"ࠧๆี็ื้ࠦࠧ᭦")+title
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᭧"),l111l1_l1_+title,l1lllll_l1_,303,l1lll1_l1_)
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᭨"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᭩"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᭪"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭫"),l111l1_l1_+l11ll1_l1_ (u"࠭ีโฯฬࠤ᭬ࠬ")+title,l1lllll_l1_,302)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ᭭"),url,l11ll1_l1_ (u"ࠨࠩ᭮"),l11ll1_l1_ (u"ࠩࠪ᭯"),l11ll1_l1_ (u"ࠪࠫ᭰"),l11ll1_l1_ (u"ࠫࠬ᭱"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫ᭲"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11ll1_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠭᭳"),html,re.DOTALL)
	name = name[0].replace(l11ll1_l1_ (u"ࠧࡽࠢึ๎๊อࠠ็ษ๋ࠫ᭴"),l11ll1_l1_ (u"ࠨࠩ᭵")).replace(l11ll1_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫ᭶"),l11ll1_l1_ (u"ࠪࠫ᭷")).strip(l11ll1_l1_ (u"ࠫࠥ࠭᭸")).replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ᭹"),l11ll1_l1_ (u"࠭ࠠࠨ᭺"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ᭻"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᭼"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠩࠣࠫ᭽")+title.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭᭾"),l11ll1_l1_ (u"ࠫࠬ᭿")).strip(l11ll1_l1_ (u"ࠬࠦࠧᮀ"))
				title = title.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩᮁ"),l11ll1_l1_ (u"ࠧࠨᮂ")).strip(l11ll1_l1_ (u"ࠨࠢࠪᮃ"))
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᮄ"),l111l1_l1_+title,l1lllll_l1_,304)
		else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬᮅ") not in url: url = url.strip(l11ll1_l1_ (u"ࠫ࠴࠭ᮆ"))+l11ll1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࡮ࡴࡧࠨᮇ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᮈ"),url,l11ll1_l1_ (u"ࠧࠨᮉ"),l11ll1_l1_ (u"ࠨࠩᮊ"),l11ll1_l1_ (u"ࠩࠪᮋ"),l11ll1_l1_ (u"ࠪࠫᮌ"),l11ll1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᮍ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭ᮎ"),html)
	if l11ll1_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨᮏ") not in url:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᮐ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᮑ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬᮒ"),l11ll1_l1_ (u"ࠪࠫᮓ")).strip(l11ll1_l1_ (u"ࠫࠥ࠭ᮔ"))
			title = l11ll1_l1_ (u"ࠬอไฮๆๅอࠥ࠭ᮕ")+title
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᮖ"),l111l1_l1_+title,l1lllll_l1_,305)
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡨࡸࡦ࡯࡬ࡴࠤࠫ࠲࠯ࡅࠩࠣࡴࡨࡰࡦࡺࡥࡥࠤࠪᮗ"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᮘ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬᮙ"),l11ll1_l1_ (u"ࠪࠫᮚ")).strip(l11ll1_l1_ (u"ࠫࠥ࠭ᮛ"))
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᮜ"),l111l1_l1_+title,l1lllll_l1_,305,l1lll1_l1_)
	return
def PLAY(url):
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠣࡩࡶࡰࡰࠥࡃࠠࡅࡇࡆࡓࡉࡋ࡟ࡂࡆࡌࡐࡇࡕ࡟ࡉࡖࡐࡐ࠭࡮ࡴ࡮࡮ࠬࠎࠎࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡨࡪࡰࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ࠩࠋࠋࡵࡩࡩ࡯ࡲࡦࡥࡷࡣ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡈࡊࡉࡏࡅࡇࡢࡅࡉࡏࡌࡃࡑࡢࡌ࡙ࡓࡌࠩࡴࡨࡨ࡮ࡸࡥࡤࡶࡢ࡬ࡹࡳ࡬ࠪࠌࠌࡧࡴࡵ࡫ࡪࡧࡶࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡳࡰ࡯ࡥࡴ࠰ࡪࡩࡹࡥࡤࡪࡥࡷࠬ࠮ࠐࠉࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࠣࡁࠥࡩ࡯ࡰ࡭࡬ࡩࡸࡡࠧࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࠪࡡࠏࠏࡶࡦࡴ࡬ࡪࡾࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠦ࡭ࡸࡥࡧࠢࡀࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ࠲ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬ࠢࡀࠤࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠲ࠧࡄࡱࡲ࡯࡮࡫ࠧ࠻ࠩࡓࡌࡕ࡙ࡅࡔࡕࡌࡈࡂ࠭ࠫࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࢀࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧࠪࠌࠌࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟ࡩࡶࡰࡰࠥࡃࠠࡅࡇࡆࡓࡉࡋ࡟ࡂࡆࡌࡐࡇࡕ࡟ࡉࡖࡐࡐ࠭ࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮ࠬࠎࠎࠩࡡࡥࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡦࡪࠢࠡࡶࡤࡶ࡬࡫ࡴ࠾ࠤࡢࡦࡱࡧ࡮࡬ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡢࡦࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡥࡩࡥ࡬ࡪࡰ࡮࡟࠵ࡣࠊࠊࠥࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡡࡥࡡ࡯࡭ࡳࡱࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩࠬࠎࠎࠩࡡࡥࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠣࡢࡦࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡈࡊࡉࡏࡅࡇࡢࡅࡉࡏࡌࡃࡑࡢࡌ࡙ࡓࡌࠩࡣࡧࡣ࡭ࡺ࡭࡭ࠫࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡧࡺ࡮ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡧ࡭ࡸࡶ࡬ࡢࡻ࠽ࠤࡳࡵ࡮ࡦ࠽ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶ࡠ࠶࡝ࠬࠩ࠲ࠫࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡦ࠳ࡩࡩ࡮ࡣࡹ࡭ࡩࡹ࠮࡭࡫ࡹࡩ࠴࠭ࡽࠋࠋࠥࠦࠧᮝ")
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࡯࡮ࡨ࠱ࠪᮞ")
	#server = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬᮟ"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᮠ"):None,l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᮡ"):server}
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᮢ"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭ᮣ"),l11ll1_l1_ (u"࠭ࠧᮤ"),l11ll1_l1_ (u"ࠧࠨᮥ"),l11ll1_l1_ (u"ࠨࠩᮦ"),l11ll1_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬᮧ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l111lll_l1_ = l1ll1l1l11_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠪࡰࡴࡽࡥࡳࠩᮨ"))
	#html = l1ll1l11l1_l1_(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨᮩ"),l111lll_l1_,l11ll1_l1_ (u"᮪ࠬ࠭"),l11ll1_l1_ (u"᮫࠭ࠧ"),l11ll1_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪᮬ"))
	#if html and kodi_version>18.99: html = html.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᮭ"))
	#html = DECODE_ADILBO_HTML(html)
	l1llll_l1_ = []
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᮮ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᮯ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ᮰"),l11ll1_l1_ (u"ࠬ࠭᮱")).strip(l11ll1_l1_ (u"࠭ࠠࠨ᮲"))
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ᮳"),title,re.DOTALL)
			if l111llll_l1_:
				l111llll_l1_ = l11ll1_l1_ (u"ࠨࡡࡢࡣࡤ࠭᮴")+l111llll_l1_[0]
				#title = l11ll1_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ᮵")
				title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨ᮶"))
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠫࠬ᮷")
			l1lllll11l_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᮸")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ᮹")+l111llll_l1_
			l1llll_l1_.append(l1lllll11l_l1_)
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡹࡤࡸࡨ࡮ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᮺ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# l1l111l1l_l1_ l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪ࠲࠳࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧᮻ"),block,re.DOTALL)
		for l1lllll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᮼ")+l1lllll_l1_
			title = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡲࡦࡳࡥࠨᮽ"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᮾ")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᮿ")
			l1llll_l1_.append(l1lllll_l1_)
		# l1ll1l11ll_l1_ l11l1l1ll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡡ࡫ࡣࡻࡠ࠭ࢁࡵࡳ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᯀ"),html,re.DOTALL)
		if l1l1_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࡮ࡥࡧࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩᯁ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫᯂ"),l11ll1_l1_ (u"ࠩࠪᯃ")).strip(l11ll1_l1_ (u"ࠪࠤࠬᯄ"))
				title = title.replace(l11ll1_l1_ (u"ࠫࡈ࡯࡭ࡢࠢࡑࡳࡼ࠭ᯅ"),l11ll1_l1_ (u"ࠬࡉࡩ࡮ࡣࡑࡳࡼ࠭ᯆ"))
				l1lllll_l1_ = l1l1_l1_[0]+l11ll1_l1_ (u"࠭࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡹ࡬ࡸࡨ࡮ࠦࡪࡰࡧࡩࡽࡃࠧᯇ")+index+l11ll1_l1_ (u"ࠧࠧ࡫ࡧࡁࠬᯈ")+id+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᯉ")+title+l11ll1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᯊ")
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᯋ"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᯌ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭ᯍ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧᯎ"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩᯏ"),l11ll1_l1_ (u"ࠨ࠭ࠪᯐ"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡃࡸࡃࠧᯑ")+search
	l11111_l1_(url)
	return
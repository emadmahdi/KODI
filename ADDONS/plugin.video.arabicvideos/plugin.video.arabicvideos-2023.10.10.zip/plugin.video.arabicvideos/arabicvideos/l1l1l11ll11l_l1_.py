# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ敫")
#headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ敬"):l11ll1_l1_ (u"ࠩࠪ敭")}
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡘࡎࡐࡠࠩ敮")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๊ࠫ฻วา฻ฬࠫ敯"),l11ll1_l1_ (u"ࠬฮหࠡ็หหูืࠧ数")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11111_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llll1l_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ敱"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨ敲"),l11ll1_l1_ (u"ࠨࠩ敳"),l11ll1_l1_ (u"ࠩࠪ整"),l11ll1_l1_ (u"ࠪࠫ敵"),l11ll1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ敶"))
	html = response.content
	l1ll111_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ敷"),html,re.DOTALL)
	l1ll111_l1_ = l1ll111_l1_[0].strip(l11ll1_l1_ (u"࠭࠯ࠨ數"))
	l1ll111_l1_ = SERVER(l1ll111_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ敹"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ敺"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ敻"),l1ll111_l1_,489,l11ll1_l1_ (u"ࠪࠫ敼"),l11ll1_l1_ (u"ࠫࠬ敽"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ敾"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ敿"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ斀"),l11ll1_l1_ (u"ࠨࠩ斁"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斂"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ斃")+l111l1_l1_+l11ll1_l1_ (u"ࠫศำฯฬࠢส่๊๎วื์฼ࠫ斄"),l1ll111_l1_,481)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡰࡽࡆࡩࡣࡰࡷࡱࡸࠧ࠭斅"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ斆"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠧࠤࠩ文"): continue
		if title in l1l11l_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ斈"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ斉")+l111l1_l1_+title,l1lllll_l1_,481)
	return html
def l11111_l1_(url,l1ll1lll1l1ll_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ斊"),url,l11ll1_l1_ (u"ࠫࠬ斋"),l11ll1_l1_ (u"ࠬ࠭斌"),l11ll1_l1_ (u"࠭ࠧ斍"),l11ll1_l1_ (u"ࠧࠨ斎"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ斏"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡴࡹࡴࠩ࠰࠭ࡃ࠮ࠨࡦࡰࡱࡷࡩࡷࠨࠧ斐"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ斑"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ斒"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪ斓"),l11ll1_l1_ (u"࠭ว฻่ํอࠬ斔"),l11ll1_l1_ (u"ࠧฤ฼้๎ฮ࠭斕"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭斖"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ斗"),l11ll1_l1_ (u"๋ࠪิอแࠨ斘"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ料"),l11ll1_l1_ (u"ࠬ฿ัืࠩ斚"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭斛"),l11ll1_l1_ (u"ࠧศๆห์๊࠭斜"),l11ll1_l1_ (u"ࠨ็ึีา๐ษࠨ斝")]
	l1ll1lll1ll11_l1_ = l11ll1_l1_ (u"ࠩ࠲ࠫ斞").join(l1ll1lll1l1ll_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ斟")).split(l11ll1_l1_ (u"ࠫ࠴࠭斠"))[4:]).split(l11ll1_l1_ (u"ࠬ࠳ࠧ斡"))
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		title = unescapeHTML(title)
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ斢"),title,re.DOTALL)
		if l1ll1lll1l1ll_l1_:
			l1lllll11l_l1_ = l11ll1_l1_ (u"ࠧ࠰ࠩ斣").join(l1lllll_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ斤")).split(l11ll1_l1_ (u"ࠩ࠲ࠫ斥"))[4:]).split(l11ll1_l1_ (u"ࠪ࠱ࠬ斦"))
			l1ll1lll1ll1l_l1_ = len([x for x in l1ll1lll1ll11_l1_ if x in l1lllll11l_l1_])
			if l1ll1lll1ll1l_l1_>2 and l11ll1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ斧") in l1lllll_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ斨"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
		else:
			if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ斩"),title,re.DOTALL)
			#if any(value in title for value in l1ll1l_l1_):
			if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ࠧๆี็ื้࠭斪") not in title:
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ斫"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
			elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠩะ่็ฯࠧ斬") in title:
				title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ断") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ斮"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭斯"),url)
					l11l_l1_.append(title)
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭新"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ斱"),url)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠣࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠦ斲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ斳"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠪห้฻แฮหࠣࠫ斴"),l11ll1_l1_ (u"ࠫࠬ斵"))
			if title!=l11ll1_l1_ (u"ࠬ࠭斶"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭斷"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭斸")+title,l1lllll_l1_,481,l11ll1_l1_ (u"ࠨࠩ方"),l11ll1_l1_ (u"ࠩࠪ斺"),l1ll1lll1l1ll_l1_)
	return
def l1llll1l_l1_(url,l111lll_l1_):
	headers = {l11ll1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭斻"):l11ll1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ於")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ施"),url,l11ll1_l1_ (u"࠭ࠧ斾"),headers,l11ll1_l1_ (u"ࠧࠨ斿"),l11ll1_l1_ (u"ࠨࠩ旀"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ旁"))
	html = response.content
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ旂"))
	l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧ࡯࡭ࡨ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ旃"),html,re.DOTALL)
	if l1lll1_l1_: l1lll1_l1_ = l1lll1_l1_[0]
	else: l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭旄"))
	l1ll1lll1l1l1_l1_ = True
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢ࡭࡫ࡶࡸࡘ࡫ࡡࡴࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ旅"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ旆") not in url:
		block = l1l11l1_l1_[0]
		count = block.count(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠬ旇"))
		if count==0: count = block.count(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠨ旈"))
		if count>1:
			l1ll1lll1l1l1_l1_ = False
			if l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠨ旉") in block:
				items = re.findall(l11ll1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ旊"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠲࠯ࡲ࡫ࡴࡄࡹ࡬ࡶࡩࡀࠫ旋")+id
					addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭旌"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
			else:
				items = re.findall(l11ll1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ旍"),block,re.DOTALL)
				for id,title in items:
					l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵ࡭ࡪࡹࡉࡅ࠿ࠪ旎")+id
					addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ族"),l111l1_l1_+title,l1lllll_l1_,483,l1lll1_l1_)
	# l1l11_l1_
	if l1ll1lll1l1l1_l1_:
		block = l11ll1_l1_ (u"ࠪࠫ旐")
		if l11ll1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ旑") in url: block = html
		else:
			l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡥࡱ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ旒"),html,re.DOTALL)
			if l1l111l_l1_: block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ旓"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ旔"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ旕"),l111l1_l1_+title,l1lllll_l1_,482,l1lll1_l1_)
	if not menuItemsLIST: l11111_l1_(l111lll_l1_,url)
	return
def PLAY(url):
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ旖"))+l11ll1_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡹࡤࡸࡨ࡮ࠧ旗")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ旘"),l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭旙"),l11ll1_l1_ (u"࠭ࠧ旚"),l11ll1_l1_ (u"ࠧࠨ旛"),l11ll1_l1_ (u"ࠨࠩ旜"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭旝"))
	html = response.content
	l1llll_l1_ = []
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ旞"))
	l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡻࡵ࡟ࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ旟"),html,re.DOTALL)
	if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ无"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ旡"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ既"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ旣"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲࡭࡫ࡸࡡ࡮ࡧ࠵࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ旤")+l1ll1llll1_l1_+l11ll1_l1_ (u"ࠪࠪࡻ࡯ࡤࡦࡱࡀࠫ日")+l1lll111l1_l1_[2:]+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ旦")+title+l11ll1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭旧")
			l1llll_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l11l1l1ll_l1_ l1lllll_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡨࡧࡷࡉࡲࡨࡥࡥࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ旨"),html,re.DOTALL)
	if l1lllll_l1_:
		title = SERVER(l1lllll_l1_[0],l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ早"))
		l1lllll_l1_ = l1lllll_l1_[0]+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ旪")+title+l11ll1_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ旫")
		l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l111lll_l1_ = url.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ旬"))+l11ll1_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ旭")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ旮"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ旯"),l11ll1_l1_ (u"ࠧࠨ旰"),l11ll1_l1_ (u"ࠨࠩ旱"),l11ll1_l1_ (u"ࠩࠪ旲"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ旳"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡺࡡࡣ࡮ࡨ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ旴"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ旵"),block,re.DOTALL)
		for title,l1lllll_l1_ in items:
			title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ时"))
			if l11ll1_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ旷") in l1lllll_l1_: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠨࡡࡢาฬ฻ࠧ旸")
			else: l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠩࠪ旹")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ旺")+title+l11ll1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ旻")+l1lll1l1l_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ旼"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ旽"),url)
	return
def SEARCH(search,l1ll111_l1_=l11ll1_l1_ (u"ࠧࠨ旾")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ旿"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ昀"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ昁"),l11ll1_l1_ (u"ࠫ࠰࠭昂"))
	if l1ll111_l1_==l11ll1_l1_ (u"ࠬ࠭昃"): l1ll111_l1_ = l11l1l_l1_
	url = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ昄")+search+l11ll1_l1_ (u"ࠧ࠰ࠩ昅")
	l11111_l1_(url,l11ll1_l1_ (u"ࠨࠩ昆"))
	return
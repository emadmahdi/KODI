# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3
#import l11lllll1l1_l1_ as pickle
script_name = l11ll1_l1_ (u"ࠪࡐࡎࡈࡓࡐࡐࡈࠫ㋑")
l1l111lll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"ࠫࡵࡧࡴࡩࠩ㋒"))
l11lll11l11_l1_ = os.path.join(l1l111lll1l_l1_,l11ll1_l1_ (u"ࠬࡶࡡࡤ࡭ࡤ࡫ࡪࡹࠧ㋓"))
sys.path.append(l11lll11l11_l1_)
l1l111l1l1l_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡂࡶ࡫࡯ࡨ࡛࡫ࡲࡴ࡫ࡲࡲࠧ㋔"))
kodi_version = re.findall(l11ll1_l1_ (u"ࠧࠩ࡞ࡧࡠࡩࡢ࠮࡝ࡦࠬࠫ㋕"),l1l111l1l1l_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11lll11111_l1_ = xbmc.LOGINFO
	ltr,rtl = l11ll1_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩ㋖"),l11ll1_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪ㋗")
	l1l1111ll11_l1_ = xbmcvfs.translatePath(l11ll1_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ㋘"))
	from urllib.parse import unquote as _1l111l1l11_l1_
else:
	l11lll11111_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l11ll1_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬ㋙").encode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㋚")),l11ll1_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ㋛").encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㋜"))
	l1l1111ll11_l1_ = xbmc.translatePath(l11ll1_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩ㋝"))
	from urllib import unquote as _1l111l1l11_l1_
l1l11ll111l_l1_ = 60
HOUR = 60*l1l11ll111l_l1_
l11lll1l11l_l1_ = 24*HOUR
l1l11l1l1ll_l1_ = 30*l11lll1l11l_l1_
l1llllll_l1_ = 3*l11lll1l11l_l1_
PERMANENT_CACHE = 12*l1l11l1l1ll_l1_
addon_id = sys.argv[0].split(l11ll1_l1_ (u"ࠩ࠲ࠫ㋞"))[2]	# plugin.video.l11lll11lll_l1_
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
l1l11ll1l1l_l1_ = addon_id.split(l11ll1_l1_ (u"ࠪ࠲ࠬ㋟"))[2]		# l11lll11lll_l1_
l11llll111l_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ㋠")+addon_id+l11ll1_l1_ (u"ࠬ࠯ࠧ㋡"))
addoncachefolder = os.path.join(l1l1111ll11_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11ll1_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫ㋢"))
l1l111l11l1_l1_ = os.path.join(addoncachefolder,l11ll1_l1_ (u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨ㋣"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1lll1l11l_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ㋤"),l11ll1_l1_ (u"ࠩࠪ㋥"),url,l11ll1_l1_ (u"࡙ࠪࡗࡒࡄࡆࡅࡒࡈࡊ࠭㋦"))
	if l11ll1_l1_ (u"ࠫࡂ࠭㋧") in url:
		if l11ll1_l1_ (u"ࠬࡅࠧ㋨") in url: l111lll_l1_,filters = url.split(l11ll1_l1_ (u"࠭࠿ࠨ㋩"))
		else: l111lll_l1_,filters = l11ll1_l1_ (u"ࠧࠨ㋪"),url
		filters = filters.split(l11ll1_l1_ (u"ࠨࠨࠪ㋫"))
		l11ll11l1_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㋬"),l11ll1_l1_ (u"ࠪࠫ㋭"),filter,str(filters))
			key,value = filter.split(l11ll1_l1_ (u"ࠫࡂ࠭㋮"))
			l11ll11l1_l1_[key] = value
	else: l111lll_l1_,l11ll11l1_l1_ = url,{}
	return l111lll_l1_,l11ll11l1_l1_
def l1111_l1_(urll):
	return _1l111l1l11_l1_(urll)
	#return urllib2.unquote(urll)
def EXTRACT_KODI_PATH(l11lll1l111_l1_):
	l1l1l11111l_l1_ = {l11ll1_l1_ (u"ࠬࡺࡹࡱࡧࠪ㋯"):l11ll1_l1_ (u"࠭ࠧ㋰"),l11ll1_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ㋱"):l11ll1_l1_ (u"ࠨࠩ㋲"),l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㋳"):l11ll1_l1_ (u"ࠪࠫ㋴"),l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ㋵"):l11ll1_l1_ (u"ࠬ࠭㋶"),l11ll1_l1_ (u"࠭ࡰࡢࡩࡨࠫ㋷"):l11ll1_l1_ (u"ࠧࠨ㋸"),l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭㋹"):l11ll1_l1_ (u"ࠩࠪ㋺"),l11ll1_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ㋻"):l11ll1_l1_ (u"ࠫࠬ㋼"),l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭㋽"):l11ll1_l1_ (u"࠭ࠧ㋾"),l11ll1_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ㋿"):l11ll1_l1_ (u"ࠨࠩ㌀")}
	if l11ll1_l1_ (u"ࠩࡂࠫ㌁") in l11lll1l111_l1_: l11lll1l111_l1_ = l11lll1l111_l1_.split(l11ll1_l1_ (u"ࠪࡃࠬ㌂"),1)[1]
	l111lll_l1_,l1l1l111111_l1_ = l1lll1l11l_l1_(l11lll1l111_l1_)
	args = dict(list(l1l1l11111l_l1_.items())+list(l1l1l111111_l1_.items()))
	l11lll11l1l_l1_ = args[l11ll1_l1_ (u"ࠫࡲࡵࡤࡦࠩ㌃")]
	l1l111ll11l_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ㌄")])
	l1l11111l1l_l1_ = l1111_l1_(args[l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࠫ㌅")])
	l11ll1llll1_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠧࡱࡣࡪࡩࠬ㌆")])
	l11ll1lll1l_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠨࡶࡼࡴࡪ࠭㌇")])
	l1l11111ll1_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㌈")])
	l1l11l111l1_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ㌉")])
	l1l111111ll_l1_ = args[l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ㌊")]
	l1l111l11ll_l1_ = l1111_l1_(args[l11ll1_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ㌋")])
	if l1l111l11ll_l1_: l1l111l11ll_l1_ = eval(l1l111l11ll_l1_)
	else: l1l111l11ll_l1_ = {}
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㌌"))
	#l111_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ㌍"))
	if not l11lll11l1l_l1_: l11ll1lll1l_l1_ = l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㌎") ; l11lll11l1l_l1_ = l11ll1_l1_ (u"ࠩ࠵࠺࠵࠭㌏")
	return l11ll1lll1l_l1_,l1l11111ll1_l1_,l1l111ll11l_l1_,l11lll11l1l_l1_,l1l11l111l1_l1_,l11ll1llll1_l1_,l1l11111l1l_l1_,l1l111111ll_l1_,l1l111l11ll_l1_
def LOGGING(script_name):
	l1l11111l11_l1_ = sys._getframe(1).f_code.co_name
	if not script_name or not l1l11111l11_l1_ or l1l11111l11_l1_==l11ll1_l1_ (u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ㌐"):
		return l11ll1_l1_ (u"ࠫࡠࠦࠧ㌑")+l1l11ll1l1l_l1_.upper()+l11ll1_l1_ (u"ࠬ࠳ࠧ㌒")+l11llll111l_l1_+l11ll1_l1_ (u"࠭࠭ࠨ㌓")+str(kodi_version)+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ㌔")
	return l11ll1_l1_ (u"ࠨ࠰ࠣࠤࠥ࠭㌕")+l1l11111l11_l1_
def LOG_THIS(level,message):
	l11llll11ll_l1_ = l11lll11111_l1_
	lines = [l11ll1_l1_ (u"ࠩࠪ㌖"),l11ll1_l1_ (u"ࠪࠫ㌗")]
	if level: message = message.replace(l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㌘"),l11ll1_l1_ (u"ࠬ࠭㌙")).replace(l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㌚"),l11ll1_l1_ (u"ࠧࠨ㌛")).replace(l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㌜"),l11ll1_l1_ (u"ࠩࠪ㌝"))
	else: level = l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㌞")
	l111l1ll11_l1_,sep,shift = l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ㌟"),l11ll1_l1_ (u"ࠬࠦࠠࠡࠩ㌠"),l11ll1_l1_ (u"࠭ࠧ㌡")
	if l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㌢") in level: l11llll11ll_l1_ = xbmc.LOGERROR
	if level==l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㌣"):
		message = message+sep
		lines = message.split(sep)
		shift = l111l1ll11_l1_
	elif level==l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㌤"):
		message = message.replace(l11ll1_l1_ (u"ࠪ࠲ࠬ㌥")+sep,l11ll1_l1_ (u"ࠫ࠳ࠦࠠࠨ㌦"))
		lines = message.split(sep)
		lines[0] = l11ll1_l1_ (u"ࠬ࠴ࠠࠨ㌧")+lines[0][1:]
		shift = l111l1ll11_l1_+sep
	elif level in [l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌨"),l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㌩")]: lines = message.split(l111l1ll11_l1_)
	shift += 6*l111l1ll11_l1_
	l11llll1lll_l1_ = 3*l111l1ll11_l1_
	if kodi_version>17.99: shift += 11*l11ll1_l1_ (u"ࠨࠢࠪ㌪")
	l1l11l1l1l1_l1_ = lines[0]
	for line in lines[1:]:
		if l11ll1_l1_ (u"ࠩ࡟ࡲࠬ㌫") in line: line = line.replace(l11ll1_l1_ (u"ࠪࡠࡳ࠭㌬"),l11ll1_l1_ (u"ࠫࡡࡴࠧ㌭")+l111l1ll11_l1_+l111l1ll11_l1_)
		l11llll1lll_l1_ += l111l1ll11_l1_
		l1l11l1l1l1_l1_ += l11ll1_l1_ (u"ࠬࡢࡲࠨ㌮")+shift+l11llll1lll_l1_+line
	l1l11l1l1l1_l1_ += l11ll1_l1_ (u"࠭ࠠࡠࠩ㌯")
	if l11ll1_l1_ (u"ࠧࠦࠩ㌰") in l1l11l1l1l1_l1_: l1l11l1l1l1_l1_ = l1111_l1_(l1l11l1l1l1_l1_)
	xbmc.log(l1l11l1l1l1_l1_,level=l11llll11ll_l1_)
	return
def l1l11lll111_l1_(l1l1ll111l_l1_):
	conn = sqlite3.connect(l1l1ll111l_l1_)
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡣ࡮ࡴࡤࡦࡺࡀࡲࡴࡁࠧ㌱"))
	cc.execute(l11ll1_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡩࡳࡷ࡫ࡩࡨࡰࡢ࡯ࡪࡿࡳ࠾ࡰࡲ࠿ࠬ㌲"))
	cc.execute(l11ll1_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭࡬ࡴ࡯ࡳࡧࡢࡧ࡭࡫ࡣ࡬ࡡࡦࡳࡳࡹࡴࡳࡣ࡬ࡲࡹࡹ࠽ࡺࡧࡶ࠿ࠬ㌳"))
	cc.execute(l11ll1_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡯ࡵࡵࡳࡰࡤࡰࡤࡳ࡯ࡥࡧࡀࡓࡋࡌ࠻ࠨ㌴"))
	cc.execute(l11ll1_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡺࡥ࡮ࡲࡢࡷࡹࡵࡲࡦ࠿ࡐࡉࡒࡕࡒ࡚࠽ࠪ㌵"))
	cc.execute(l11ll1_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡳࡺࡰࡦ࡬ࡷࡵ࡮ࡰࡷࡶࡁࡔࡌࡆ࠼ࠩ㌶"))
	conn.text_factory = str
	return conn,cc
def DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l1l111ll111_l1_=None):
	try: conn,cc = l1l11lll111_l1_(l1l1ll111l_l1_)
	except: return
	if l1l111ll111_l1_==None: cc.execute(l11ll1_l1_ (u"ࠧࡅࡔࡒࡔ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩ㌷")+table+l11ll1_l1_ (u"ࠨࠤࠣ࠿ࠬ㌸"))
	else:
		tt = (str(l1l111ll111_l1_),)
		try:
			if l11ll1_l1_ (u"ࠩࠨࠫ㌹") in l1l111ll111_l1_: cc.execute(l11ll1_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㌺")+table+l11ll1_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡲࡩ࡬ࡧࠣࡃࠥࡁࠧ㌻"),tt)
			else: cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㌼")+table+l11ll1_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㌽"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l11l1ll11_l1_(): pass
class l1l11lll1ll_l1_(l1l11l1ll11_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l11ll1_l1_ (u"ࠧࠨ㌾")
		self.content = l11ll1_l1_ (u"ࠨࠩ㌿")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l11ll1_l1_ (u"ࠩࠪ㍀")
def l1l111l1lll_l1_(type):
	if type==l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㍁"): data = {}
	elif type==l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㍂"): data = []
	elif type==l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ㍃"): data = l11ll1_l1_ (u"࠭ࠧ㍄")
	elif type==l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ㍅"): data = 0
	elif type==l11ll1_l1_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ㍆"): data = l1l11lll1ll_l1_()
	elif not type: data = None
	else: data = None
	return data
def READ_FROM_SQL3(l1l1ll111l_l1_,l1l111lllll_l1_,table,l1l111ll111_l1_=None):
	data = l1l111l1lll_l1_(l1l111lllll_l1_)
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㍇"))
	if l1l11llll1_l1_==l11ll1_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㍈") and table!=l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㍉") and l1l1ll111l_l1_==main_dbfile:
		DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l1l111ll111_l1_)
		return data
	l1l1l111l11_l1_ = 0
	cache = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㍊"))
	if cache==l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ㍋"): return data
	elif cache==l11ll1_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ㍌"): l1l1l111l11_l1_ = l11llll1111_l1_
	try: conn,cc = l1l11lll111_l1_(l1l1ll111l_l1_)
	except: return data
	l1l111l111l_l1_ = True
	try: cc.execute(l11ll1_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠤࠪ㍍")+table+l11ll1_l1_ (u"ࠩࠥࠤࡑࡏࡍࡊࡖࠣ࠵ࠥࡁࠧ㍎"))
	except: l1l111l111l_l1_ = False
	if l1l111l111l_l1_:
		if l1l1l111l11_l1_: cc.execute(l11ll1_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㍏")+table+l11ll1_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭㍐")+str(now+l1l1l111l11_l1_)+l11ll1_l1_ (u"ࠬࠦ࠻ࠨ㍑"))
		conn.commit()
		cc.execute(l11ll1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㍒")+table+l11ll1_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩ㍓")+str(now)+l11ll1_l1_ (u"ࠨࠢ࠾ࠫ㍔"))
		conn.commit()
		if l1l111ll111_l1_:
			tt = (str(l1l111ll111_l1_),)
			cc.execute(l11ll1_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ㍕")+table+l11ll1_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㍖"),tt)
			l1l1111l1ll_l1_ = cc.fetchall()
			if l1l1111l1ll_l1_:
				try:
					text = zlib.decompress(l1l1111l1ll_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11ll1_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ㍗")+table+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ㍘"))
			l1l1111l1ll_l1_ = cc.fetchall()
			if l1l1111l1ll_l1_:
				data,l1l11ll1lll_l1_ = {},[]
				for l1l11l1l11l_l1_,l11ll11l1_l1_ in l1l1111l1ll_l1_:
					l1l1l1ll11_l1_ = zlib.decompress(l11ll11l1_l1_)
					l11ll11l1_l1_ = pickle.loads(l1l1l1ll11_l1_)
					data[l1l11l1l11l_l1_] = l11ll11l1_l1_
					l1l11ll1lll_l1_.append(l1l11l1l11l_l1_)
				if l1l11ll1lll_l1_:
					data[l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ㍙")] = l1l11ll1lll_l1_
					if l1l111lllll_l1_==l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㍚"): data = l1l11ll1lll_l1_
	conn.close()
	return data
def l1l1111llll_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11l111ll_l1_(length,l1l11l1llll_l1_=True):
	#return l11ll1_l1_ (u"ࠨ࠻࠼࠴࠻࠳࠶࠱࠶࠶࠱࠸࠿࠶࠷࠯࠹࠴࠻࠽࠭࠳࠵࠵࠻ࠬ㍛")
	l11ll1lllll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡑࡩࡹࡽ࡯ࡳ࡭࠱ࡍࡕࡇࡤࡥࡴࡨࡷࡸ࠭㍜"))
	l1l11l11l1l_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩ㍝"))
	if l1l11l1llll_l1_:
		try: l11llll11l_l1_,l1l11ll11ll_l1_,l11llll1ll1_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㍞"),l11ll1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㍟"),l11ll1_l1_ (u"࠭ࡉࡅࡕࠪ㍠"))
		except: l11llll11l_l1_,l1l11ll11ll_l1_,l11llll1ll1_l1_ = l11ll1_l1_ (u"ࠧࠨ㍡"),l11ll1_l1_ (u"ࠨࠩ㍢"),l11ll1_l1_ (u"ࠩࠪ㍣")
		if l11llll11l_l1_ and l11ll1lllll_l1_==l1l11ll11ll_l1_ and l1l11l11l1l_l1_==l11llll1ll1_l1_: return l11llll11l_l1_
	#import uuid
	#node = str(uuid.getnode())
	#l1l11l11lll_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨ㍤"))
	#if l1l11l11lll_l1_.count(l11ll1_l1_ (u"ࠫ࠿࠭㍥"))==5 and l1l11l11lll_l1_.count(l11ll1_l1_ (u"ࠬ࠶ࠧ㍦"))<9: l11lllll111_l1_ = l1l11l11lll_l1_
	global mac
	length = length//2
	import threading
	l11lll1ll11_l1_ = threading.Thread(target=l1l1111llll_l1_,args=())
	l11lll1ll11_l1_.start()
	mac = l11ll1_l1_ (u"࠭ࠧ㍧")
	for l11ll11111_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11ll1_l1_ (u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪ㍨")
	else:
		mac = mac.replace(l11ll1_l1_ (u"ࠨ࠼ࠪ㍩"),l11ll1_l1_ (u"ࠩࠪ㍪"))
		node = str(int(mac,16))
	node = re.findall(l11ll1_l1_ (u"ࠪ࡟࠵࠳࠹࡞࠭ࠪ㍫"),node,re.DOTALL)
	node = length*l11ll1_l1_ (u"ࠫ࠵࠭㍬")+node[0]
	node = node[-length:]
	mm,ss = l11ll1_l1_ (u"ࠬ࠭㍭"),l11ll1_l1_ (u"࠭ࠧ㍮")
	l1l1111l111_l1_ = str(int(l11ll1_l1_ (u"ࠧ࠺ࠩ㍯")*(length+1))-int(node))[-length:]
	for l11ll11111_l1_ in list(range(0,length,4)):
		l11lll1llll_l1_ = l1l1111l111_l1_[l11ll11111_l1_:l11ll11111_l1_+4]
		mm += l11lll1llll_l1_+l11ll1_l1_ (u"ࠨ࠯ࠪ㍰")
		ss += str(sum(map(int,node[l11ll11111_l1_:l11ll11111_l1_+4]))%10)
	l1l11llll11_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㍱"),l11ll1_l1_ (u"ࠪࡍࡉ࡙ࠧ㍲"),[l1l11llll11_l1_,l11ll1lllll_l1_,l1l11l11l1l_l1_],l1llllll_l1_)
	return l1l11llll11_l1_
def l11lll1lll1_l1_(l1l11llllll_l1_):
	l11lllllll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㍳"))
	#l1l11llllll_l1_ = l1l11llllll_l1_.encode(l11ll1_l1_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬ㍴")).replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ㍵"),l11ll1_l1_ (u"ࠧࠨ㍶"))
	user = l1l11l111ll_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11ll1_l1_ (u"ࠨ࡚࠴࠽ࠬ㍷")+l1l11llllll_l1_+l11ll1_l1_ (u"ࠩ࠴࠼ࡂ࠭㍸")+user).encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㍹"))).hexdigest()[0:32]
	if md5 in l11lllllll1_l1_: return True
	return False
class l1l111lll11_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11ll1_l1_ (u"ࠫࠬ㍺")
		if l11lll1lll1_l1_(l11ll1_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭㍻")) or not l11lll1lll1_l1_(l11ll1_l1_ (u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ㍼")):
			self.status = l11ll1_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㍽")
			import l1l1111ll1l_l1_
			l1l1111ll1l_l1_.l1l111ll1ll_l1_(False)
	def onPlayBackStopped(self):
		self.status=l11ll1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㍾")
	def onPlayBackStarted(self):
		self.status = l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㍿")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11ll1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㎀")
	def onPlayBackEnded(self):
		self.status = l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㎁")
def l1l11l11111_l1_(l1l11111111_l1_,url,data,headers,source,method):
	l1l1ll11l_l1_ = str(headers)[0:250].replace(l11ll1_l1_ (u"ࠬࡢ࡮ࠨ㎂"),l11ll1_l1_ (u"࠭࡜࡝ࡰࠪ㎃")).replace(l11ll1_l1_ (u"ࠧ࡝ࡴࠪ㎄"),l11ll1_l1_ (u"ࠨ࡞࡟ࡶࠬ㎅")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠥࠦࠧ㎆"),l11ll1_l1_ (u"ࠪࠤࠬ㎇")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ㎈"),l11ll1_l1_ (u"ࠬࠦࠧ㎉"))
	if len(str(headers))>250: l1l1ll11l_l1_ = l1l1ll11l_l1_+l11ll1_l1_ (u"࠭ࠠ࠯࠰࠱ࠫ㎊")
	l11ll11l1_l1_ = str(data)[0:250].replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ㎋"),l11ll1_l1_ (u"ࠨ࡞࡟ࡲࠬ㎌")).replace(l11ll1_l1_ (u"ࠩ࡟ࡶࠬ㎍"),l11ll1_l1_ (u"ࠪࡠࡡࡸࠧ㎎")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ㎏"),l11ll1_l1_ (u"ࠬࠦࠧ㎐")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ㎑"),l11ll1_l1_ (u"ࠧࠡࠩ㎒"))
	if len(str(data))>250: l11ll11l1_l1_ = l11ll11l1_l1_+l11ll1_l1_ (u"ࠨࠢ࠱࠲࠳࠭㎓")
	if l1l11111111_l1_: LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㎔"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡒࡦࡣࡧ࡭ࡳ࡭ࠠࡄࡃࡆࡌࡊࡀࠠ࡜ࠢࠪ㎕")+url+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㎖")+source+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧ㎗")+method+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩ㎘")+str(l1l1ll11l_l1_)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧ㎙")+l11ll11l1_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ㎚"))
	else: LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㎛"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡏࡱࡧࡱ࡭ࡳ࡭ࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㎜")+url+l11ll1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㎝")+source+l11ll1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧ㎞")+method+l11ll1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩ㎟")+str(l1l1ll11l_l1_)+l11ll1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧ㎠")+l11ll11l1_l1_+l11ll1_l1_ (u"ࠨࠢࡠࠫ㎡"))
	return
def l1llll1lll_l1_(method,url,data=l11ll1_l1_ (u"ࠩࠪ㎢"),headers=l11ll1_l1_ (u"ࠪࠫ㎣"),source=l11ll1_l1_ (u"ࠫࠬ㎤")):
	l1l11l11111_l1_(False,url,data,headers,source,l11ll1_l1_ (u"ࠬ࠭㎥"))
	if kodi_version>18.99: import urllib.request as l1l11l1lll1_l1_
	else: import urllib2 as l1l11l1lll1_l1_
	if not headers: headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㎦"):l11ll1_l1_ (u"ࠧࠨ㎧")}
	if not data: data = {}
	if method==l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ㎨"):
		url = url+l11ll1_l1_ (u"ࠩࡂࠫ㎩")+l1ll1l11l_l1_(data)
		data = None
	elif method==l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㎪"): data = data.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㎫"))
	try:
		req = l1l11l1lll1_l1_.Request(url,headers=headers,data=data)
		http_response = l1l11l1lll1_l1_.urlopen(req)
		html = http_response.read()
	except: html = l11ll1_l1_ (u"ࠬ࠭㎬")
	#try:
	#	req = l1l11l1lll1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l1l11l1lll1_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l11ll1_l1_ (u"࠭ࠧ㎭")
	return html
def l1l11lllll1_l1_(script_name):
	# https://www.l1l11ll1l11_l1_.l11lllll11l_l1_.l11llllll11_l1_.com/l1l11l11ll1_l1_/l1l111111l1_l1_/http-l11lll111ll_l1_-l1l1111lll1_l1_
	# https://help.l11llllll11_l1_.com/l11llllllll_l1_/l1l11l1l111_l1_-l1lll1lllll_l1_/l1l11ll1111_l1_/215562387-l1l11111lll_l1_-property-l11ll1lll11_l1_
	# https://www.l1l11ll1l11_l1_.l11lllll11l_l1_.l11llllll11_l1_.com/l1l11l11ll1_l1_/l1l111111l1_l1_/l11llllll1l_l1_-rest-l1l1111lll1_l1_
	l11lllll1ll_l1_ = str(random.randrange(111111111111,999999999999))
	#l1l111l1111_l1_ = l11lll1111l_l1_()
	#l1l11llll1l_l1_ = l1l111l1111_l1_.split(l11ll1_l1_ (u"ࠧ࠭ࠩ㎮"),1)[0]
	headers = {l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㎯"):l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ㎰")}
	data = {l11ll1_l1_ (u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ㎱"):l11ll1_l1_ (u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩ㎲"),
			l11ll1_l1_ (u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤࠣ㎳"):l11lllll1ll_l1_,
			l11ll1_l1_ (u"ࠨࡥࡷࡧࡱࡸࡸࠨ㎴"): [{
				l11ll1_l1_ (u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣ㎵"):l1l11l111ll_l1_(32),
				l11ll1_l1_ (u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ㎶"):str(kodi_version),
				l11ll1_l1_ (u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ㎷"):l11llll111l_l1_,
				l11ll1_l1_ (u"ࠥࡧࡦࡸࡲࡪࡧࡵࠦ㎸"):l11llll111l_l1_,
				l11ll1_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣ㎹"):script_name,
				l11ll1_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㎺"):{l11ll1_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㎻"):script_name},
				l11ll1_l1_ (u"ࠢࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ㎼"): {l11ll1_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㎽"):script_name},
				l11ll1_l1_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࠦ㎾"): l11ll1_l1_ (u"ࠥࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࠥ㎿"),
				l11ll1_l1_ (u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥ㏀"):False,
				l11ll1_l1_ (u"ࠧ࡯ࡰࠣ㏁"): l11ll1_l1_ (u"ࠨࠤࡳࡧࡰࡳࡹ࡫ࠢ㏂")
			}]
		}
	url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩ㏃")
	import json
	data = json.dumps(data)
	#response = l1l111l1ll1_l1_(l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㏄"),url,data,headers,l11ll1_l1_ (u"ࠩࠪ㏅"),l11ll1_l1_ (u"ࠪࠫ㏆"),l11ll1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ㏇"),False,False)
	response = l1llll1lll_l1_(l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ㏈"),url,data,headers,script_name)
	return response
def l1l11l11l11_l1_(url,script_name,type):
	l11lll111l1_l1_ = xbmcgui.ListItem()
	l1l1111l11l_l1_ = l1l111lll11_l1_()
	if l1l1111l11l_l1_.status: LOG_THIS(l11ll1_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㏉"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㏊")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㏋"))
	else:
		if type==l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㏌"):
			l11lll111l1_l1_.setPath(url)
			LOG_THIS(l11ll1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㏍"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㏎")+url+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ㏏"))
			xbmcplugin.setResolvedUrl(addon_handle,True,l11lll111l1_l1_)
		else:
			LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㏐"),LOGGING(script_name)+l11ll1_l1_ (u"ࠧࠡࠢࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡰ࡮ࡼࡥࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡶ࡬ࡢࡻࠫ࠭ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㏑")+url+l11ll1_l1_ (u"ࠨࠢࡠࠫ㏒"))
			l1l1111l11l_l1_.play(url,l11lll111l1_l1_)
		l1l11l1111l_l1_()
		timeout = 5
		for l11ll11111_l1_ in range(timeout):
			# l11lll11ll1_l1_ l1l11lll1l1_l1_
			#	if using time.sleep() l11lll1l1ll_l1_ of xbmc.sleep() l1l11ll1ll1_l1_ the l11llll1l11_l1_ status
			#	l11ll1_l1_ (u"ࠤࡰࡽࡵࡲࡡࡺࡧࡵ࠲ࡸࡺࡡࡵࡷࡶࠦ㏓") will stop l1l1111l1l1_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l1l1111ll_l1_ = l1l1111l11l_l1_.status
			if l1l1l1111ll_l1_ in [l11ll1_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㏔"),l11ll1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㏕")]: break
		if l1l1l1111ll_l1_==l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㏖"): response = l1l11lllll1_l1_(script_name)
	return
def EVAL(l1l111lllll_l1_,text):
	#text = text.replace(l11ll1_l1_ (u"ࠨࡵࠨࠤ㏗"),l11ll1_l1_ (u"ࠢࠨࠤ㏘"))
	text = text.replace(l11ll1_l1_ (u"ࠨࡰࡸࡰࡱ࠭㏙"),l11ll1_l1_ (u"ࠩࡑࡳࡳ࡫ࠧ㏚"))
	text = text.replace(l11ll1_l1_ (u"ࠪࡸࡷࡻࡥࠨ㏛"),l11ll1_l1_ (u"࡙ࠫࡸࡵࡦࠩ㏜"))
	text = text.replace(l11ll1_l1_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ㏝"),l11ll1_l1_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ㏞"))
	text = text.replace(l11ll1_l1_ (u"ࠧ࡝࠱ࠪ㏟"),l11ll1_l1_ (u"ࠨ࠱ࠪ㏠"))
	try: l1l1l1ll11_l1_ = eval(text)
	except: l1l1l1ll11_l1_ = l1l111l1lll_l1_(l1l111lllll_l1_)
	return l1l1l1ll11_l1_
def l1l11l1111l_l1_():
	type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11ll1_l1_ (u"ࠩ࡟ࡨࡡࡪ࠺࡝ࡦ࡟ࡨࠥࡢ࡛࠰ࡅࡒࡐࡔࡘ࡜࡞ࠩ㏡"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11ll1_l1_ (u"ࠪࡣࠪࡳ࠮ࠦࡦࡢࠩࡍࡀࠥࡎࡡࠪ㏢"),time.localtime(now))
	name = name+datetime
	l1ll1111l1l_l1_ = type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_
	if os.path.exists(l1l111l11l1_l1_):
		l1l1111111l_l1_ = open(l1l111l11l1_l1_,l11ll1_l1_ (u"ࠫࡷࡨࠧ㏣")).read()
		if kodi_version>18.99: l1l1111111l_l1_ = l1l1111111l_l1_.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㏤"))
		l1l1111111l_l1_ = EVAL(l11ll1_l1_ (u"࠭ࡤࡪࡥࡷࠫ㏥"),l1l1111111l_l1_)
	else: l1l1111111l_l1_ = {}
	l11llll11l1_l1_ = {}
	for l1l11ll11l1_l1_ in list(l1l1111111l_l1_.keys()):
		if l1l11ll11l1_l1_!=type: l11llll11l1_l1_[l1l11ll11l1_l1_] = l1l1111111l_l1_[l1l11ll11l1_l1_]
		else:
			if name and name!=l11ll1_l1_ (u"ࠧ࠯࠰ࠪ㏦"):
				l11lll1ll1l_l1_ = l1l1111111l_l1_[l1l11ll11l1_l1_]
				if l1ll1111l1l_l1_ in l11lll1ll1l_l1_:
					index = l11lll1ll1l_l1_.index(l1ll1111l1l_l1_)
					del l11lll1ll1l_l1_[index]
				l1llll11ll1_l1_ = [l1ll1111l1l_l1_]+l11lll1ll1l_l1_
				l1llll11ll1_l1_ = l1llll11ll1_l1_[:50]
				l11llll11l1_l1_[l1l11ll11l1_l1_] = l1llll11ll1_l1_
			else: l11llll11l1_l1_[l1l11ll11l1_l1_] = l1l1111111l_l1_[l1l11ll11l1_l1_]
	if type not in list(l11llll11l1_l1_.keys()): l11llll11l1_l1_[type] = [l1ll1111l1l_l1_]
	l11llll11l1_l1_ = str(l11llll11l1_l1_)
	if kodi_version>18.99: l11llll11l1_l1_ = l11llll11l1_l1_.encode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭㏧"))
	open(l1l111l11l1_l1_,l11ll1_l1_ (u"ࠩࡺࡦࠬ㏨")).write(l11llll11l1_l1_)
	return
def WRITE_TO_SQL3(l1l1ll111l_l1_,table,l1l111ll111_l1_,data,l1l111llll1_l1_,l1l11l1ll1l_l1_=False):
	cache = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㏩"))
	if cache==l11ll1_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㏪") and l1l111llll1_l1_>l11llll1111_l1_: l1l111llll1_l1_ = l11llll1111_l1_
	if l1l11l1ll1l_l1_:
		l11l1ll1l_l1_,l11l1lll1_l1_ = [],[]
		for l11ll11111_l1_ in range(len(l1l111ll111_l1_)):
			text = pickle.dumps(data[l11ll11111_l1_])
			l11llll1l1l_l1_ = zlib.compress(text)
			l11l1ll1l_l1_.append((l1l111ll111_l1_[l11ll11111_l1_],))
			l11l1lll1_l1_.append((l1l111llll1_l1_+now,str(l1l111ll111_l1_[l11ll11111_l1_]),l11llll1l1l_l1_))
	else:
		text = pickle.dumps(data)
		l1l111ll1l1_l1_ = zlib.compress(text)
	try: conn,cc = l1l11lll111_l1_(l1l1ll111l_l1_)
	except: return
	while True:
		try:
			cc.execute(l11ll1_l1_ (u"ࠬࡈࡅࡈࡋࡑࠤࡎࡓࡍࡆࡆࡌࡅ࡙ࡋࠠࡕࡔࡄࡒࡘࡇࡃࡕࡋࡒࡒࠥࡁࠧ㏫"))
			break
		except: time.sleep(0.5)
	cc.execute(l11ll1_l1_ (u"࠭ࡃࡓࡇࡄࡘࡊࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡐࡒࡘࠥࡋࡘࡊࡕࡗࡗࠥࠨࠧ㏬")+table+l11ll1_l1_ (u"ࠧࠣࠢࠫࡩࡽࡶࡩࡳࡻ࠯ࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠪࠢ࠾ࠫ㏭"))
	if l1l11l1ll1l_l1_:
		cc.executemany(l11ll1_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㏮")+table+l11ll1_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㏯"),l11l1ll1l_l1_)
		cc.executemany(l11ll1_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪ㏰")+table+l11ll1_l1_ (u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩ㏱"),l11l1lll1_l1_)
	else:
		if l1l111llll1_l1_:
			tt = (str(l1l111ll111_l1_),)
			cc.execute(l11ll1_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㏲")+table+l11ll1_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㏳"),tt)
			tt = (l1l111llll1_l1_+now,str(l1l111ll111_l1_),l1l111ll1l1_l1_)
			cc.execute(l11ll1_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ㏴")+table+l11ll1_l1_ (u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭㏵"),tt)
		else:
			tt = (l1l111ll1l1_l1_,str(l1l111ll111_l1_))
			cc.execute(l11ll1_l1_ (u"ࠩࡘࡔࡉࡇࡔࡆࠢࠥࠫ㏶")+table+l11ll1_l1_ (u"࡙ࠪࠦࠥࡅࡕࠢࡧࡥࡹࡧࠠ࠾ࠢࡂࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㏷"),tt)
	conn.commit()
	conn.close()
	return
def l1ll1l11l_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l11lll11l_l1_
	else: import urllib as l1l11lll11l_l1_
	l1l1l1111l1_l1_ = l1l11lll11l_l1_.urlencode(data)
	return l1l1l1111l1_l1_
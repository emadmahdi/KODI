# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭惬")
headers = l11ll1_l1_ (u"ࠬ࠭惭") #{ l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ惮") : l11ll1_l1_ (u"ࠧࠨ惯") }
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧ惰")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ惱"),l11ll1_l1_ (u"ࠪห้้ไࠨ惲"),l11ll1_l1_ (u"ࠫฬ็ไศ็ࠪ想"),l11ll1_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ惴"),l11ll1_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ惵")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11111_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llll1l_l1_(url,True)
	elif mode==114: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ惶")+text)
	elif mode==115: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ惷")+text)
	elif mode==116: results = l1llll1l_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll111_l1_,url,response = l1ll1l1lll1_l1_(l11l1l_l1_,l11ll1_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ惸"),l11ll1_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ惹"),l11ll1_l1_ (u"ࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ惺"),headers)
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ惻"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭惼"),l11ll1_l1_ (u"ࠧࠨ惽"),119,l11ll1_l1_ (u"ࠨࠩ惾"),l11ll1_l1_ (u"ࠩࠪ惿"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ愀"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ愁"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ愂"),l1ll111_l1_,115)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭愃"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ愄"),l1ll111_l1_,114)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭愅"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ愆"),l11ll1_l1_ (u"ࠪࠫ愇"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ愈"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆ็ํึฮ࠭愉"),l1ll111_l1_,111,l11ll1_l1_ (u"࠭ࠧ愊"),l11ll1_l1_ (u"ࠧࠨ愋"),l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ愌"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠪ愍"),html,re.DOTALL)
	if not l1l1l11_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ愎"),l11ll1_l1_ (u"ࠫࠬ意"),l11ll1_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ愐"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส๐ฬศัࠣ฽๋๎ว็ࠢส่๊๎โฺࠢฦ์ࠥะีๆ์่ࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠩ愑"))
		return
	else:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭愒"),block,re.DOTALL)
		for filter,l1lll1_l1_,title in items:
			url = l1ll111_l1_+filter
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ愓"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ愔")+l111l1_l1_+title,url,111,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ愕"),filter)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ愖"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ愗"),l11ll1_l1_ (u"࠭ࠧ愘"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡴࡲࡴࡩࡵࡷ࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ愙"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ愚"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ愛"),l11ll1_l1_ (u"ࠪࠫ愜")).replace(l11ll1_l1_ (u"ࠫࡡࡸࠧ愝"),l11ll1_l1_ (u"ࠬ࠭愞")).strip(l11ll1_l1_ (u"࠭ࠠࠨ感"))
			if title in l1l11l_l1_: continue
			if l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ愠") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l1lllll_l1_
			if l11ll1_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ愡") in l1lllll_l1_: title = l11ll1_l1_ (u"้ࠩ๎ฯ็ไไีࠪ愢")
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ愣"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭愤")+l111l1_l1_+title,l1lllll_l1_,111)
	return html
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠬ࠭愥"),response=l11ll1_l1_ (u"࠭ࠧ愦")):
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ愧"):l11ll1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ愨")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭愩"),url,l11ll1_l1_ (u"ࠪࠫ愪"),headers,l11ll1_l1_ (u"ࠫࠬ愫"),l11ll1_l1_ (u"ࠬ࠭愬"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ愭"))
	html = response.content
	l1l1l11_l1_,items,l11l_l1_ = [],[],[]
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ愮"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡩ࡯࡭ࡩ࡫࡟ࡠࡵ࡯࡭ࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ愯"),html,re.DOTALL)
	#elif l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ愰"): l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡑࡪࡪࡩࡢࡉࡵ࡭ࡩ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ愱"),html,re.DOTALL)
	else: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ愲"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	#if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ愳"): items = re.findall(l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡣࡱࡻ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ愴"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄࠧ愵"),block,re.DOTALL)
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠨ็ืห์ีษࠨ愶"),l11ll1_l1_ (u"ࠩไ๎้๋ࠧ愷"),l11ll1_l1_ (u"ࠪห฿์๊สࠩ愸"),l11ll1_l1_ (u"่๊๊ࠫษࠩ愹"),l11ll1_l1_ (u"ࠬอูๅษ้ࠫ愺"),l11ll1_l1_ (u"࠭็ะษไࠫ愻"),l11ll1_l1_ (u"ࠧๆสสีฬฯࠧ愼"),l11ll1_l1_ (u"ࠨ฻ิฺࠬ愽"),l11ll1_l1_ (u"่๋ࠩึาว็ࠩ愾"),l11ll1_l1_ (u"ࠪห้ฮ่ๆࠩ愿")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ慀") in l1lllll_l1_: continue
		#if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ慁") in l1lllll_l1_: continue
		#l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭ࠦࠤ࠲࠶࠼ࡀ࠭慂"),l11ll1_l1_ (u"ࠧࠧࠩ慃"))
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ慄"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫ慅"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭慆"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠫๆ๐ไๆࠩ慇") in l1lllll_l1_ or any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ慈"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"࠭วๅฯ็ๆฮ࠭慉") in title and l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭慊") not in url:
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ態") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ慌"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴ࠲ࠫ慍") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ慎"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ慏") in l1lllll_l1_ and l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ慐") not in url:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭慑")
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ慒"),l111l1_l1_+title,l1lllll_l1_,111,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ慓") in url and l11ll1_l1_ (u"ࠪั้่ษࠨ慔") in title:
			addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ慕"),l111l1_l1_+title,l1lllll_l1_,112,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ慖"),l111l1_l1_+title,l1lllll_l1_,113,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ慗"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ慘"): items = re.findall(l11ll1_l1_ (u"ࠨࠪࡸࡴࡩࡧࡴࡦࡓࡸࡩࡷࡿࠩ࠯ࠬࡂࡂ࠭࠴ࠫࡀࠫ࠿ࠫ慙"),block,re.DOTALL)
		else: items = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ慚"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lll1l1l1_l1_!=l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ慛"):
				title = title.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ慜"),l11ll1_l1_ (u"ࠬ࠭慝")).replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ慞"),l11ll1_l1_ (u"ࠧࠨ慟"))
				if l11ll1_l1_ (u"ࠨࡁࠪ慠") in url: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ慡")+title
				else: l1lllll_l1_ = url+l11ll1_l1_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠪ慢")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ慣"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ慤")+title,l1lllll_l1_,111,l11ll1_l1_ (u"࠭ࠧ慥"),l11ll1_l1_ (u"ࠧࠨ慦"),l1lll1l1l1_l1_)
	return
def l1llll1l_l1_(url,l1lll11111l1l_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ慧"),url,l11ll1_l1_ (u"ࠩࠪ慨"),headers,l11ll1_l1_ (u"ࠪࠫ慩"),l11ll1_l1_ (u"ࠫࠬ慪"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭慫"))
	html = response.content
	# l1lll1l_l1_ & l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡷࠥࡪ࠭ࡧ࡮ࡨࡼ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ慬"),html,re.DOTALL)
	if len(l1l1l11_l1_)>1:
		if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ慭") in l1l1l11_l1_[0]: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[1]
		else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[1],l1l1l11_l1_[0]
	else: l1lll1l_l1_,l1l11_l1_ = l1l1l11_l1_[0],l1l1l11_l1_[0]
	for l11ll11111_l1_ in range(2):
		if l1lll11111l1l_l1_: mode,type,block = 116,l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ慮"),l1lll1l_l1_
		else: mode,type,block = 112,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ慯"),l1l11_l1_
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ慰"),block,re.DOTALL)
		if l1lll11111l1l_l1_ and len(items)<2:
			l1lll11111l1l_l1_ = False
			continue
		for l1lllll_l1_,l11l1l1l1_l1_,l1lll1l1l_l1_ in items:
			title = l11l1l1l1_l1_+l11ll1_l1_ (u"ࠫࠥ࠭慱")+l1lll1l1l_l1_
			addMenuItem(type,l111l1_l1_+title,l1lllll_l1_,mode)
		break
	# l1l11_l1_ l11l1l11_l1_
	if not items and l11ll1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ慲") in html:
		l1l11llll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡳࡧࡤࡨࡨࡸࡵ࡮ࡤࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ慳"),html,re.DOTALL)
		if l1l11llll_l1_:
			block = l1l11llll_l1_[0]
			l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭慴"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1lllll_l1_ = l1l1_l1_[2]+l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭慵")
				l11111_l1_(l1lllll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭慶"),url,l11ll1_l1_ (u"ࠪࠫ慷"),headers,l11ll1_l1_ (u"ࠫࠬ慸"),l11ll1_l1_ (u"ࠬ࠭慹"),l11ll1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ慺"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡢࡥࡷ࡭ࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ慻"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ慼"),block,re.DOTALL)
	l11l1l1ll_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ慽") in block
	download = l11ll1_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ慾") in block
	if   l11l1l1ll_l1_ and not download: l1lll1111111l_l1_,l111ll1l1lll_l1_ = l1l1_l1_[0],l11ll1_l1_ (u"ࠫࠬ慿")
	elif not l11l1l1ll_l1_ and download: l1lll1111111l_l1_,l111ll1l1lll_l1_ = l11ll1_l1_ (u"ࠬ࠭憀"),l1l1_l1_[0]
	elif l11l1l1ll_l1_ and download: l1lll1111111l_l1_,l111ll1l1lll_l1_ = l1l1_l1_[0],l1l1_l1_[1]
	else: l1lll1111111l_l1_,l111ll1l1lll_l1_ = l11ll1_l1_ (u"࠭ࠧ憁"),l11ll1_l1_ (u"ࠧࠨ憂")
	# l11l1l1ll_l1_
	if l11l1l1ll_l1_:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ憃"),l1lll1111111l_l1_,l11ll1_l1_ (u"ࠩࠪ憄"),headers,l11ll1_l1_ (u"ࠪࠫ憅"),l11ll1_l1_ (u"ࠫࠬ憆"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ憇"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭࡬ࡦࡶࠣࡷࡪࡸࡶࡦࡴࡶࠬ࠳࠰࠿ࠪࡲ࡯ࡥࡾ࡫ࡲࠨ憈"),l11ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ憉"),l111l_l1_,re.DOTALL)
			for title,l1lllll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠨ࡞࡟࠳ࠬ憊"),l11ll1_l1_ (u"ࠩ࠲ࠫ憋"))
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ憌")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ憍")
				l1llll_l1_.append(l1lllll_l1_)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ憎"),l111ll1l1lll_l1_,l11ll1_l1_ (u"࠭ࠧ憏"),headers,l11ll1_l1_ (u"ࠧࠨ憐"),l11ll1_l1_ (u"ࠨࠩ憑"),l11ll1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭憒"))
		l11ll1ll_l1_ = response.content
		l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬ࡭ࡳ࡬࡯࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫ憓"),l11ll1ll_l1_,re.DOTALL)
		if l1l111l_l1_:
			l111l_l1_ = l1l111l_l1_[0]
			l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼࠰࡫ࡁ࠲ࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ憔"),l111l_l1_,re.DOTALL)
			for l1lllll_l1_,title,l111llll_l1_ in l1l1l1l_l1_:
				l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭憕")+title+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ憖")+l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬ憗")+l111llll_l1_
				l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭憘"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ憙"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ憚"),l11ll1_l1_ (u"ࠫ࠰࠭憛"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ憜")+search
	l1ll111_l1_,l111lll_l1_,l1ll1111l_l1_ = l1ll1l1lll1_l1_(url,l11ll1_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ憝"),l11ll1_l1_ (u"ࠧีษ๊ำࠥ็่า์๋ࠤ࠲ࠦࡓࡩࡣ࡫࡭ࡩࠦ࠴ࡶࠩ憞"),l11ll1_l1_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨ憟"),headers)
	l11111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ憠"),l1ll1111l_l1_)
	return
# ===========================================
#     l1lll1llll_l1_ l1lll1lll1_l1_ l1llll1111_l1_
# ===========================================
def l1llllll11_l1_(url):
	url = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ憡"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ憢"),url,l11ll1_l1_ (u"ࠬ࠭憣"),headers,l11ll1_l1_ (u"࠭ࠧ憤"),l11ll1_l1_ (u"ࠧࠨ憥"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ憦"))
	html = response.content
	l1ll1lll_l1_ = []
	# all l1111l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡤࡨࡻ࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡷ࡭ࡵࡷࡴ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ憧"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		# name & category & options block
		l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡔࡹࡪࡸࡹ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴࠨ憨"),block,re.DOTALL)
		l1lll111111ll_l1_,names,l1111l1_l1_ = zip(*l1ll1lll_l1_)
		l1ll1lll_l1_ = zip(names,l1lll111111ll_l1_,l1111l1_l1_)
	return l1ll1lll_l1_
def l1llll11ll_l1_(block):
	# id & title
	items = re.findall(l11ll1_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾࡝ࡵ࠭ࠬ࠳࠰࠿ࠪ࡞ࡶ࠮ࡁ࠭憩"),block,re.DOTALL)
	return items
def l1lll11111111_l1_(url):
	#url = url.replace(l11ll1_l1_ (u"ࠬࡩࡡࡵ࠿ࠪ憪"),l11ll1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ憫"))
	if l11ll1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ憬") not in url: url = url+l11ll1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ憭")
	l1lllll1l1_l1_ = url.split(l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭憮"))[0]
	l1llll1l1l_l1_ = SERVER(url,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ憯"))
	url = url.replace(l1lllll1l1_l1_,l1llll1l1l_l1_)
	#url = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ憰"),l11ll1_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩ憱"))
	url = url.replace(l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ憲"),l11ll1_l1_ (u"ࠧ࠰ࡁࠪ憳"))
	return url
l1lll111111l1_l1_ = [l11ll1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ憴"),l11ll1_l1_ (u"ࠩࡼࡩࡦࡸࠧ憵"),l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ憶"),l11ll1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭憷")]
l1lll11111l11_l1_ = [l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ憸"),l11ll1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ憹"),l11ll1_l1_ (u"ࠧࡺࡧࡤࡶࠬ憺")]
def l1lll111_l1_(url,filter):
	#filter = filter.replace(l11ll1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ憻"),l11ll1_l1_ (u"ࠩࠪ憼"))
	url = url.split(l11ll1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ憽"))[0]
	type,filter = filter.split(l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ憾"),1)
	if filter==l11ll1_l1_ (u"ࠬ࠭憿"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"࠭ࠧ懀"),l11ll1_l1_ (u"ࠧࠨ懁")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ懂"))
	if type==l11ll1_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ懃"):
		if l1lll11111l11_l1_[0]+l11ll1_l1_ (u"ࠪࡁࠬ懄") not in l1l111ll_l1_: category = l1lll11111l11_l1_[0]
		for i in range(len(l1lll11111l11_l1_[0:-1])):
			if l1lll11111l11_l1_[i]+l11ll1_l1_ (u"ࠫࡂ࠭懅") in l1l111ll_l1_: category = l1lll11111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠬࠬࠧ懆")+category+l11ll1_l1_ (u"࠭࠽࠱ࠩ懇")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩ懈")+category+l11ll1_l1_ (u"ࠨ࠿࠳ࠫ應")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠫ懊"))+l11ll1_l1_ (u"ࠪࡣࡤࡥࠧ懋")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠫࠫ࠭懌"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ懍"))
		l111lll_l1_ = url+l11ll1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ懎")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ懏"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ懐"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"ࠩࠪ懑"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭懒"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠫࠬ懓"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ懔")+l1l111l1_l1_
		l11l111_l1_ = l1lll11111111_l1_(l111lll_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭懕"),l111l1_l1_+l11ll1_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ懖"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ懗"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ懘")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ懙"),l11l111_l1_,111)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ懚"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ懛"),l11ll1_l1_ (u"࠭ࠧ懜"),9999)
	l1ll1lll_l1_ = l1llllll11_l1_(url)
	dict = {}
	for name,l1ll1l1l_l1_,block in l1ll1lll_l1_:
		name = name.replace(l11ll1_l1_ (u"ࠧไๆࠣࠫ懝"),l11ll1_l1_ (u"ࠨࠩ懞"))
		items = l1llll11ll_l1_(block)
		if l11ll1_l1_ (u"ࠩࡀࠫ懟") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ懠"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<2:
				if l1ll1l1l_l1_==l1lll11111l11_l1_[-1]:
					l11l111_l1_ = l1lll11111111_l1_(l111lll_l1_)
					l11111_l1_(l11l111_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ懡")+l1l11lll_l1_)
				return
			else:
				if l1ll1l1l_l1_==l1lll11111l11_l1_[-1]:
					l11l111_l1_ = l1lll11111111_l1_(l111lll_l1_)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懢"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ懣"),l11l111_l1_,111)
				else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ懤"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ懥"),l111lll_l1_,115,l11ll1_l1_ (u"ࠩࠪ懦"),l11ll1_l1_ (u"ࠪࠫ懧"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ懨"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠬࠬࠧ懩")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠱ࠩ懪")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠧࠧࠩ懫")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨ࠿࠳ࠫ懬")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠩࡢࡣࡤ࠭懭")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ懮"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭懯")+name,l111lll_l1_,114,l11ll1_l1_ (u"ࠬ࠭懰"),l11ll1_l1_ (u"࠭ࠧ懱"),l1l11lll_l1_)		# +l11ll1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ懲"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			if value==l11ll1_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨ懳"): option = l11ll1_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩ懴")
			elif value==l11ll1_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪ懵"): option = l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭懶")
			if option in l1l11l_l1_: continue
			#if l11ll1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ懷") not in value: value = option
			#else: value = re.findall(l11ll1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ懸"),value,re.DOTALL)[0]
			dict[l1ll1l1l_l1_][value] = option
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠧࠧࠩ懹")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨ࠿ࠪ懺")+option
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠩࠩࠫ懻")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠪࡁࠬ懼")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠫࡤࡥ࡟ࠨ懽")+l1l1ll1l_l1_
			title = option+l11ll1_l1_ (u"ࠬࠦ࠺ࠨ懾")#+dict[l1ll1l1l_l1_][l11ll1_l1_ (u"࠭࠰ࠨ懿")]
			title = option+l11ll1_l1_ (u"ࠧࠡ࠼ࠪ戀")+name
			if type==l11ll1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭戁"): addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ戂"),l111l1_l1_+title,url,114,l11ll1_l1_ (u"ࠪࠫ戃"),l11ll1_l1_ (u"ࠫࠬ戄"),l1ll1l11_l1_)		# +l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ戅"))
			elif type==l11ll1_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ戆") and l1lll11111l11_l1_[-2]+l11ll1_l1_ (u"ࠧ࠾ࠩ戇") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ戈"))
				l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭戉")+l11lllll_l1_
				l11l111_l1_ = l1lll11111111_l1_(l111lll_l1_)
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ戊"),l111l1_l1_+title,l11l111_l1_,111)
			else: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ戋"),l111l1_l1_+title,url,115,l11ll1_l1_ (u"ࠬ࠭戌"),l11ll1_l1_ (u"࠭ࠧ戍"),l1ll1l11_l1_)
	return
def l1l11111_l1_(filters,mode):
	# mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ戎")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ戏")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠩࡤࡰࡱ࠭成")					all l1l1l1ll_l1_ & l1lllll111_l1_ filters
	filters = filters.replace(l11ll1_l1_ (u"ࠪࡁࠫ࠭我"),l11ll1_l1_ (u"ࠫࡂ࠶ࠦࠨ戒"))
	filters = filters.strip(l11ll1_l1_ (u"ࠬࠬࠧ戓"))
	l1l11l11_l1_ = {}
	if l11ll1_l1_ (u"࠭࠽ࠨ戔") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠧࠧࠩ戕"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠨ࠿ࠪ或"))
			l1l11l11_l1_[var] = value
	l1ll11ll_l1_ = l11ll1_l1_ (u"ࠩࠪ戗")
	for key in l1lll111111l1_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠪ࠴ࠬ战")
		if l11ll1_l1_ (u"ࠫࠪ࠭戙") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ戚") and value!=l11ll1_l1_ (u"࠭࠰ࠨ戛"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ戜")+value
		elif mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ戝") and value!=l11ll1_l1_ (u"ࠩ࠳ࠫ戞"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࠪࠬ戟")+key+l11ll1_l1_ (u"ࠫࡂ࠭戠")+value
		elif mode==l11ll1_l1_ (u"ࠬࡧ࡬࡭ࠩ戡"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠦࠨ戢")+key+l11ll1_l1_ (u"ࠧ࠾ࠩ戣")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠢ࠮ࠤࠬ戤"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠩࠩࠫ戥"))
	l1ll11ll_l1_ = l1ll11ll_l1_.replace(l11ll1_l1_ (u"ࠪࡁ࠵࠭戦"),l11ll1_l1_ (u"ࠫࡂ࠭戧"))
	return l1ll11ll_l1_
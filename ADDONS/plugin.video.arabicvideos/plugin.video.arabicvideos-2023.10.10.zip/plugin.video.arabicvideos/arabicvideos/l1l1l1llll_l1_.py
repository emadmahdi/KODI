# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡇࡑࡋࡁࡏࡇࡕࠫᯒ")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡉࡌࡏࡡࠪᯓ")
l1l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l11ll1_l1_ (u"ࠬࡺࡥ࡮ࡲࠪᯔ"))
l1l11l1ll1_l1_ = os.path.join(l1ll11llll_l1_,l11ll1_l1_ (u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨᯕ"))
l1l1ll1ll1_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩᯖ"),l11ll1_l1_ (u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬᯗ"))
l1l1l1111l_l1_ = l1ll111lll_l1_
l1l11l1lll_l1_ = l11ll1_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡵࡼࡷࡹ࡫࡭࠰ࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬᯘ")
l1l11ll111_l1_ = l11ll1_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡧࡶࡴࡶࡢࡰࡺࠪᯙ")
l1l1ll1l1l_l1_ = l11ll1_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠧᯚ")
l1l1lll11l_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡱࡵࡧࡨࡧࡵࠫᯛ")
l1l11ll1ll_l1_ = l11ll1_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࠩᯜ")
l1l11lll11_l1_ = l11ll1_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡡ࡯ࡴࠪᯝ")
def MAIN(mode):
	if   mode==740: results = l1ll11lll1_l1_()
	elif mode==741: results = l1ll11l1ll_l1_(l1l1lll111_l1_,True,True)
	elif mode==742: results = l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,True)
	elif mode==743: results = l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,True)
	elif mode==744: results = l1l11lllll_l1_(l1l1l1111l_l1_,True)
	elif mode==745: results = l1l11l1l11_l1_(True)
	elif mode==750: results = l1l1l1lll1_l1_()
	elif mode==751: results = l1ll11l1ll_l1_(l1l11l1lll_l1_,False,True)
	elif mode==752: results = l1ll11l1ll_l1_(l1l11ll111_l1_,False,True)
	elif mode==753: results = l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,True)
	elif mode==754: results = l1ll11l1ll_l1_(l1l1lll11l_l1_,False,True)
	elif mode==755: results = l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,True)
	elif mode==756: results = l1ll11l1ll_l1_(l1l11lll11_l1_,False,True)
	elif mode==757: results = l1l1ll1111_l1_(True)
	elif mode==758: results = l1l1l1l1l1_l1_()
	else: results = False
	return results
def l1ll11lll1_l1_():
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l1lll111_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11l1ll1_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1ll1_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l1l11ll1_l1_(l1l1l1111l_l1_)
	l1ll11111l_l1_ -= 36864
	l1l1l111l1_l1_ -= 1
	l1l11ll1l1_l1_ = l11ll1_l1_ (u"ࠨࠢࠫࠫᯞ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ᯟ")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᯠ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠫࠥ࠮ࠧᯡ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩᯢ")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᯣ")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠧࠡࠪࠪᯤ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᯥ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴ᯦ࠫࠪ")
	l1ll11ll1l_l1_ = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᯧ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11ll1_l1_ (u"ࠫ࠮࠭ᯨ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_
	text = l11ll1_l1_ (u"ࠬࠦࠨࠨᯩ")+l1ll11ll11_l1_(size)+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᯪ")+str(count)+l11ll1_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᯫ")
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᯬ"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦวๅฮ่๎฾࠭ᯭ")+text,l11ll1_l1_ (u"ࠪࠫᯮ"),745)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᯯ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᯰ"),l11ll1_l1_ (u"࠭ࠧᯱ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯᯲ࠬ"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯ᯳ࠧ")+l1l11ll1l1_l1_,l11ll1_l1_ (u"ࠩࠪ᯴"),741)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᯵"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫ᯶")+l1l1l1ll11_l1_,l11ll1_l1_ (u"ࠬ࠭᯷"),742)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᯸"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤฬ๊ี้ำࠣห้่ฯ๋็ฬࠫ᯹")+l1l1l1l1ll_l1_,l11ll1_l1_ (u"ࠨࠩ᯺"),743)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᯻"),l111l1_l1_+l11ll1_l1_ (u"ࠪฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ᯼")+l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠫࠬ᯽"),744)
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ᯾"),l11ll1_l1_ (u"࠭ࠧ᯿"))
	return
def l1l1l1lll1_l1_():
	l1ll11l11l_l1_ = True if l11ll1_l1_ (u"ࠧ࠰ࠩᰀ") in l1l1l11111_l1_ else False
	if not l1ll11l11l_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᰁ"),l11ll1_l1_ (u"ࠩࠪᰂ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᰃ"),l11ll1_l1_ (u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ่๋ࠡ฽ࠥ๐่็ๅึࠫᰄ"))
		return
	l1l11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᰅ"))
	if not l1l11llll1_l1_: l1l1l1l1l1_l1_()
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l11l1lll_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11ll111_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1l1l_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l11ll11l_l1_(l1l1lll11l_l1_)
	l1ll111111_l1_,l1l1l111ll_l1_ = l1l11ll11l_l1_(l1l11ll1ll_l1_)
	l1l1llllll_l1_,l1l1lll1l1_l1_ = l1l11ll11l_l1_(l1l11lll11_l1_)
	l1l11ll1l1_l1_ = l11ll1_l1_ (u"࠭ࠠࠩࠩᰆ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫᰇ")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᰈ")
	l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠩࠣࠬࠬᰉ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧᰊ")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᰋ")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠬࠦࠨࠨᰌ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪᰍ")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᰎ")
	l1ll11ll1l_l1_ = l11ll1_l1_ (u"ࠨࠢࠫࠫᰏ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭ᰐ")+str(l1l1l111l1_l1_)+l11ll1_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᰑ")
	l1l1l11lll_l1_ = l11ll1_l1_ (u"ࠫࠥ࠮ࠧᰒ")+l1ll11ll11_l1_(l1ll111111_l1_)+l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩᰓ")+str(l1l1l111ll_l1_)+l11ll1_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᰔ")
	l1l1l1l11l_l1_ = l11ll1_l1_ (u"ࠧࠡࠪࠪᰕ")+l1ll11ll11_l1_(l1l1llllll_l1_)+l11ll1_l1_ (u"ࠨࠢ࠰ࠤࠬᰖ")+str(l1l1lll1l1_l1_)+l11ll1_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᰗ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_+l1ll111111_l1_+l1l1llllll_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_+l1l1l111ll_l1_+l1l1lll1l1_l1_
	text = l11ll1_l1_ (u"ࠪࠤ࠭࠭ᰘ")+l1ll11ll11_l1_(size)+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨᰙ")+str(count)+l11ll1_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᰚ")
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰛ"),l111l1_l1_+l11ll1_l1_ (u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪᰜ"),l11ll1_l1_ (u"ࠨࠩᰝ"),758)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰞ"),l111l1_l1_+l11ll1_l1_ (u"ุ้ࠪำࠠศๆฯ้๏฿ࠧᰟ")+text,l11ll1_l1_ (u"ࠫࠬᰠ"),757)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰡ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᰢ"),l11ll1_l1_ (u"ࠧࠨᰣ"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰤ"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡻࡳࡢࡩࡨࡷࡹࡧࡴࡴࠩᰥ")+l1l11ll1l1_l1_,l11ll1_l1_ (u"ࠪࠫᰦ"),751)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰧ"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡦࡵࡳࡵࡨ࡯ࡹࠩᰨ")+l1l1l1ll11_l1_,l11ll1_l1_ (u"࠭ࠧᰩ"),752)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰪ"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨᰫ")+l1l1l1l1ll_l1_,l11ll1_l1_ (u"ࠩࠪᰬ"),753)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᰭ"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧᰮ")+l1ll11ll1l_l1_,l11ll1_l1_ (u"ࠬ࠭ᰯ"),754)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰰ"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧᰱ")+l1l1l11lll_l1_,l11ll1_l1_ (u"ࠨࠩᰲ"),755)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰳ"),l111l1_l1_+l11ll1_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪᰴ")+l1l1l1l11l_l1_,l11ll1_l1_ (u"ࠫࠬᰵ"),756)
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᰶ"),l11ll1_l1_ (u"᰷࠭ࠧ"))
	return
def l1l1l1l1l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ᰸"),l11ll1_l1_ (u"ࠨࠩ᰹"),l11ll1_l1_ (u"ࠩࠪ᰺"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᰻"),l11ll1_l1_ (u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫ᰼"))
	if l1ll111ll1_l1_==-1: return
	if l1ll111ll1_l1_:
		l1ll11l111_l1_ = True
		import subprocess
		try: subprocess.Popen(l11ll1_l1_ (u"ࠬࡹࡵࠨ᰽"))
		except: l1ll11l111_l1_ = False
		if l1ll11l111_l1_:
			l1l1ll11l1_l1_ = l1l11l1lll_l1_+l11ll1_l1_ (u"࠭ࠠࠨ᰾")+l1l11ll111_l1_+l11ll1_l1_ (u"ࠧࠡࠩ᰿")+l1l1ll1l1l_l1_+l11ll1_l1_ (u"ࠨࠢࠪ᱀")+l1l1lll11l_l1_+l11ll1_l1_ (u"ࠩࠣࠫ᱁")+l1l11ll1ll_l1_+l11ll1_l1_ (u"ࠪࠤࠬ᱂")+l1l11lll11_l1_
			proc = subprocess.Popen(l11ll1_l1_ (u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬ᱃")+l1l1ll11l1_l1_+l11ll1_l1_ (u"ࠬࠨࠧ᱄"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ᱅"),l11ll1_l1_ (u"ࠧࠨ᱆"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᱇"),l11ll1_l1_ (u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอࠬ᱈"))
			settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᱉"),l11ll1_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᱊"))
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᱋"))
		else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ᱌"),l11ll1_l1_ (u"ࠧࠨᱍ"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᱎ"),l11ll1_l1_ (u"ࠩ฼้้๐ษࠡว฼฻ฬวࠠาะุอࠥอไใำสลฮ่ࠦศๆๆฮฬฮษࠡฬะฮฬาࠠษำ้ห๊าࠠࠡࡴࡲࡳࡹࠦࠠฤ๊ࠣࠤࡸࡻࡰࡦࡴࡸࡷࡪࡸࠠࠡล๋ࠤࠥࡹࡵ๋ࠡࠢะ์อาไࠢ็หࠥ๐่อัࠣๅ๏ํ่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮࠯ࠢฦ์้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠩᱏ"))
	return
def l1ll11ll11_l1_(size):
	for x in [l11ll1_l1_ (u"ࠪࡆࠬ᱐"),l11ll1_l1_ (u"ࠫࡐࡈࠧ᱑"),l11ll1_l1_ (u"ࠬࡓࡂࠨ᱒"),l11ll1_l1_ (u"࠭ࡇࡃࠩ᱓"),l11ll1_l1_ (u"ࠧࡕࡄࠪ᱔")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11ll1_l1_ (u"ࠣࠧ࠶࠲࠶࡬ࠠࠦࡵࠥ᱕")%(size,x)
	return text
def l1l11ll11l_l1_(l1ll111l1l_l1_=l11ll1_l1_ (u"ࠩ࠱ࠫ᱖")):
	global l1l1ll1l11_l1_,l1ll1111ll_l1_
	l1l1ll1l11_l1_,l1ll1111ll_l1_ = 0,0
	def l1l1ll1lll_l1_(l1ll111l1l_l1_):
		global l1l1ll1l11_l1_,l1ll1111ll_l1_
		if os.path.exists(l1ll111l1l_l1_):
			if 0 and l11ll1_l1_ (u"ࠪࡷࡨࡧ࡮ࡥ࡫ࡵࠫ᱗") in dir(os):
				# using l1l1lll1ll_l1_ l11ll1_l1_ (u"ࠫࡴࡹ࠮ࡴࡥࡤࡲࡩ࡯ࡲࠨ᱘") method (new in version 3.5)
				for l1l11l1l1l_l1_ in os.scandir(l1ll111l1l_l1_):
					if l1l11l1l1l_l1_.l1ll111l11_l1_(follow_symlinks=False):
						l1l1ll1lll_l1_(l1l11l1l1l_l1_.path)
					elif l1l11l1l1l_l1_.l1l1l1l111_l1_(follow_symlinks=False):
						l1l1ll1l11_l1_ += l1l11l1l1l_l1_.stat().st_size
						l1ll1111ll_l1_ += 1
			else:
				# using l11lll1l1_l1_, l1l1l1ll1l_l1_ l1l11lll1l_l1_ l11ll1_l1_ (u"ࠬࡵࡳ࠯࡮࡬ࡷࡹࡪࡩࡳࠩ᱙") method
				for l1l11l1l1l_l1_ in os.listdir(l1ll111l1l_l1_):
					l1l11l11ll_l1_ = os.path.abspath(os.path.join(l1ll111l1l_l1_,l1l11l1l1l_l1_))
					if os.path.isdir(l1l11l11ll_l1_):
						l1l1ll1lll_l1_(l1l11l11ll_l1_)
					elif os.path.isfile(l1l11l11ll_l1_):
						size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
						l1l1ll1l11_l1_ += size
						l1ll1111ll_l1_ += count
		return
	try: l1l1ll1lll_l1_(l1ll111l1l_l1_)
	except: pass
	return l1l1ll1l11_l1_,l1ll1111ll_l1_
def l1ll1111l1_l1_(l1l1ll11ll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧᱚ"),l11ll1_l1_ (u"ࠧࠨᱛ"),l11ll1_l1_ (u"ࠨࠩᱜ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᱝ"),l1l1ll11ll_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨᱞ")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้้็ࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᱟ"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1ll11ll_l1_):
		try: os.remove(l1l1ll11ll_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭ᱠ"),l11ll1_l1_ (u"࠭ࠧᱡ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱢ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩᱣ"),l11ll1_l1_ (u"ࠩࠪᱤ"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᱥ"),l11ll1_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᱦ"))
		settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᱧ"),l11ll1_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᱨ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᱩ"))
	return
def l1l11l1l11_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࠩᱪ"),l11ll1_l1_ (u"ࠩࠪᱫ"),l11ll1_l1_ (u"ࠪࠫᱬ"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᱭ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠬᱮ")+l11ll1_l1_ (u"࠭࡜࡯ࠩᱯ")+l11ll1_l1_ (u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ᱰ")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫᱱ")+l11ll1_l1_ (u"ࠩยࠥࠦ࠭ᱲ")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᱳ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l1lll111_l1_,True,False)
	l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,False)
	l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,False)
	l1l11lllll_l1_(l1l1l1111l_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᱴ"),l11ll1_l1_ (u"ࠬ࠭ᱵ"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᱶ"),l11ll1_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᱷ"))
		settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᱸ"),l11ll1_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᱹ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᱺ"))
	return
def l1l1ll1111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬᱻ"),l11ll1_l1_ (u"ࠬ࠭ᱼ"),l11ll1_l1_ (u"࠭ࠧᱽ"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᱾"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อࠡ็็ๅฬะࠧ᱿")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬᲀ")+l11ll1_l1_ (u"ࠪࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠠ࠯࠰ࠣࡨࡷࡵࡰࡣࡱࡻࠤ࠳࠴ࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠤ࠳࠴ࠠ࡭ࡱࡪ࡫ࡪࡸࠠ࠯࠰ࠣࡰࡴ࡭ࠠ࠯࠰ࠣࡥࡳࡸࠧᲁ")+l11ll1_l1_ (u"ࠫࡡࡴࠧᲂ")+l11ll1_l1_ (u"ࠬࡅࠡࠢࠩᲃ")+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᲄ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l11l1lll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll111_l1_,False,False)
	l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,False)
	l1ll11l1ll_l1_(l1l1lll11l_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11lll11_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨᲅ"),l11ll1_l1_ (u"ࠨࠩᲆ"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᲇ"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᲈ"))
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᲉ"),l11ll1_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᲊ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ᲋"))
	return
def l1l11lllll_l1_(l1l1ll111l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ᲌"),l11ll1_l1_ (u"ࠨࠩ᲍"),l11ll1_l1_ (u"ࠩࠪ᲎"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᲏"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ๊ำส้์สฮ๋ࠥไโุࠢ์ึࠦวๅฮ็ำࠥลࠡࠢࠩᲐ")+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲑ"))
		if l1ll111ll1_l1_!=1: return
	conn = sqlite3.connect(l1l1ll111l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11ll1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪᲒ"))
	cc.execute(l11ll1_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬᲓ"))
	cc.execute(l11ll1_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨᲔ"))
	conn.commit()
	cc.execute(l11ll1_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪᲕ"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫᲖ"),l11ll1_l1_ (u"ࠫࠬᲗ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᲘ"),l11ll1_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧᲙ"))
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᲚ"),l11ll1_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᲛ"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭Ნ"))
	return
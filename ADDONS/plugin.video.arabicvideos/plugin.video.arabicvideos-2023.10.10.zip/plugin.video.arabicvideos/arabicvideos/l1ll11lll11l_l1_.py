# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ䴹")
headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䴺"):l11ll1_l1_ (u"ࠪࠫ䴻")}
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓࡃࡎࡡࠪ䴼")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ䴽"),l11ll1_l1_ (u"࠭ࡷࡸࡧࠪ䴾")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11111_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llll1l_l1_(url,text)
	elif mode==364: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䴿")+text)
	elif mode==365: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ䵀")+text)
	elif mode==366: results = l1l111_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭䵁"),l11l1l_l1_,l11ll1_l1_ (u"ࠪࠫ䵂"),l11ll1_l1_ (u"ࠫࠬ䵃"),False,l11ll1_l1_ (u"ࠬ࠭䵄"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䵅"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䵆")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠨ࠱ࠪ䵇"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䵈")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䵉"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ䵊"),l11ll1_l1_ (u"ࠬ࠭䵋"),l11ll1_l1_ (u"࠭ࠧ䵌"),l11ll1_l1_ (u"ࠧࠨ䵍"),l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䵎"))
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䵏"),l111l1_l1_+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䵐"),l11ll1_l1_ (u"ࠫࠬ䵑"),8)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䵒"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䵓"),l11ll1_l1_ (u"ࠧࠨ䵔"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䵕"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䵖"),l11l1l_l1_,369,l11ll1_l1_ (u"ࠪࠫ䵗"),l11ll1_l1_ (u"ࠫࠬ䵘"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䵙"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䵚"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ䵛"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䵜"),364)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䵝"),l111l1_l1_+l11ll1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭䵞"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䵟"),365)
	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䵠"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䵡"),l11ll1_l1_ (u"ࠧࠨ䵢"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䵣"):hostname,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䵤"):l11ll1_l1_ (u"ࠪࠫ䵥")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠫࡡ࠵ࠧ䵦"),l11ll1_l1_ (u"ࠬ࠵ࠧ䵧"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ䵨"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䵩"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ䵪") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䵫"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䵬")+l111l1_l1_+title,l1lllll_l1_,366)
	#	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䵭"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䵮"),l11ll1_l1_ (u"࠭ࠧ䵯"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䵰"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ䵱"),l11ll1_l1_ (u"ࠩࠪ䵲"),l11ll1_l1_ (u"ࠪࠫ䵳"),l11ll1_l1_ (u"ࠫࠬ䵴"),l11ll1_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ䵵"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ䵶"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䵷"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭䵸") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭䵹"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠪࠫ䵺"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵻"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䵼")+l111l1_l1_+title,l1lllll_l1_,366)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䵽"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䵾"),l11ll1_l1_ (u"ࠨࠩ䵿"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ䶀"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶁"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶂"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䶃")+l111l1_l1_+title,l1lllll_l1_,366,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䶄"),l11ll1_l1_ (u"ࠧࠨ䶅"),url,l11ll1_l1_ (u"ࠨࠩ䶆"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䶇"):url,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䶈"):l11ll1_l1_ (u"ࠫࠬ䶉")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䶊"),url,l11ll1_l1_ (u"࠭ࠧ䶋"),l11ll1_l1_ (u"ࠧࠨ䶌"),l11ll1_l1_ (u"ࠨࠩ䶍"),l11ll1_l1_ (u"ࠩࠪ䶎"),l11ll1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䶏"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶐"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ䶑"),url,364)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䶒"),l111l1_l1_+l11ll1_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ䶓"),url,365)
	if l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ䶔") in html:
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶕"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ䶖"),url,361,l11ll1_l1_ (u"ࠫࠬ䶗"),l11ll1_l1_ (u"ࠬ࠭䶘"),l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䶙"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䶚"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶛"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶜"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l11111_l1_(l1ll1l1l1111_l1_,type=l11ll1_l1_ (u"ࠪࠫ䶝")):
	if l11ll1_l1_ (u"ࠫ࠿ࡀࠧ䶞") in l1ll1l1l1111_l1_:
		l11l111_l1_,url = l1ll1l1l1111_l1_.split(l11ll1_l1_ (u"ࠬࡀ࠺ࠨ䶟"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ䶠"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l1111_l1_,l1ll1l1l1111_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䶡"):l11l111_l1_,l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䶢"):l11ll1_l1_ (u"ࠩࠪ䶣")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ䶤"),url,l11ll1_l1_ (u"ࠫࠬ䶥"),l11ll1_l1_ (u"ࠬ࠭䶦"),l11ll1_l1_ (u"࠭ࠧ䶧"),l11ll1_l1_ (u"ࠧࠨ䶨"),l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䶩"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䶪"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ䶫"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䶬"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"ࠬࡢ࡜࠰ࠩ䶭"),l11ll1_l1_ (u"࠭࠯ࠨ䶮")).replace(l11ll1_l1_ (u"ࠧ࡝࡞ࠥࠫ䶯"),l11ll1_l1_ (u"ࠨࠤࠪ䶰"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮ࡏࡼࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭䶱"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ䶲"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ䶳"),l11ll1_l1_ (u"ࠬ࠭䶴"))
			if l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䶵") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶶"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭䶷") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ䶸"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䶹") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶺"),l111l1_l1_+title,l1lllll_l1_,363,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䶻"),l111l1_l1_+title,l1lllll_l1_,362,l1lll1_l1_)
		if type==l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䶼"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ䶽"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ䶾")+count
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶿"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡลัี๎࠭䷀"),l1lllll_l1_,361,l11ll1_l1_ (u"ࠫࠬ䷁"),l11ll1_l1_ (u"ࠬ࠭䷂"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䷃"))
		elif type==l11ll1_l1_ (u"ࠧࠨ䷄"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䷅"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䷆"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䷇")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷈"),l111l1_l1_+title,l1lllll_l1_,361)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"ࠬ࠭䷉")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ䷊"),url,l11ll1_l1_ (u"ࠧࠨ䷋"),l11ll1_l1_ (u"ࠨࠩ䷌"),l11ll1_l1_ (u"ࠩࠪ䷍"),l11ll1_l1_ (u"ࠪࠫ䷎"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䷏"))
	html = response.content
	html = l1111_l1_(html)
	name = re.findall(l11ll1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣ࡫ࡷࡩࡲࠨࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠬ࠳࠰࠿ࠪࠤࠪ䷐"),html,re.DOTALL)
	if name: name = name[-1].replace(l11ll1_l1_ (u"࠭࠭ࠨ䷑"),l11ll1_l1_ (u"ࠧࠡࠩ䷒")).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ䷓"))
	if l11ll1_l1_ (u"่ࠩ์ุ๋ࠧ䷔") in name and type==l11ll1_l1_ (u"ࠪࠫ䷕"):
		name = name.split(l11ll1_l1_ (u"๊ࠫ๎ำๆࠩ䷖"))[0]
		name = name.replace(l11ll1_l1_ (u"๋ࠬิศ้าอࠬ䷗"),l11ll1_l1_ (u"࠭ࠧ䷘")).strip(l11ll1_l1_ (u"ࠧࠡࠩ䷙"))
	elif l11ll1_l1_ (u"ࠨฯ็ๆฮ࠭䷚") in name:
		name = name.split(l11ll1_l1_ (u"ࠩะ่็ฯࠧ䷛"))[0]
		name = name.replace(l11ll1_l1_ (u"ู้ࠪอ็ะหࠪ䷜"),l11ll1_l1_ (u"ࠫࠬ䷝")).strip(l11ll1_l1_ (u"ࠬࠦࠧ䷞"))
	else: name = name
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷ࡮ࡴࡧ࡭ࡧࡶࡩࡨࡺࡩࡰࡰࠪ䷟"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		if type==l11ll1_l1_ (u"ࠧࠨ䷠"):
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ䷡"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳࠨ䷢") in title: continue
				if l11ll1_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࠫ䷣") in title: continue
				title = name+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ䷤")+title
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷥"),l111l1_l1_+title,l1lllll_l1_,363,l11ll1_l1_ (u"࠭ࠧ䷦"),l11ll1_l1_ (u"ࠧࠨ䷧"),l11ll1_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䷨"))
		if len(menuItemsLIST)==0:
			l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠱࠲࡙ࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩࠧࠨࠪ䷩"),block+l11ll1_l1_ (u"ࠪࠪࠫ࠭䷪"),re.DOTALL)
			if l111l_l1_: block = l111l_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ䷫"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				title = title.strip(l11ll1_l1_ (u"ࠬࠦࠧ䷬"))
				title = name+l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪ䷭")+title
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䷮"),l111l1_l1_+title,l1lllll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䷯"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ䷰"),l11ll1_l1_ (u"ࠪࠫ䷱")).replace(l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ䷲"),l11ll1_l1_ (u"ࠬ࠭䷳"))
		else: title = l11ll1_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ䷴")
		addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䷵"),l111l1_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䷶"),url,l11ll1_l1_ (u"ࠩࠪ䷷"),l11ll1_l1_ (u"ࠪࠫ䷸"),l11ll1_l1_ (u"ࠫࠬ䷹"),l11ll1_l1_ (u"ࠬ࠭䷺"),l11ll1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䷻"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䷼"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ䷽"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䷾"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䷿") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ุࠫ๐ัโำ้ࠣฬ๐ࠠิ์่หࠬ一"): name = l11ll1_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ丁")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ丂")+name+l11ll1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ七")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭丄"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ丅"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ丆") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ万"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ丈")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"࠭ࠧ三")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽࡮ࡻࡦ࡭ࡲࡧࠧ上")+l11ll1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ下")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ丌"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ不"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠫࠬ与")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭丏"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ丐"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ丑"),l11ll1_l1_ (u"ࠨ࠭ࠪ丒"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ专"),l11ll1_l1_ (u"ࠪ࠳ࠬ且"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡷࡪࡸࡩࡦࡵࠪ丕"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡦࡴࡩ࡮ࡧࠪ世"),l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡺࡶࠨ丗")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"ࠧศๆๆ่ࠬ丘"),l11ll1_l1_ (u"ࠨษ็วๆ๊วๆࠩ丙"),l11ll1_l1_ (u"ࠩสู่๊ไิๆสฮࠬ业"),l11ll1_l1_ (u"ࠪห้อๆ๋็ํࠤํࠦวๅๅิฮํ์ࠧ丛"),l11ll1_l1_ (u"ࠫฬ๊ศาษ่ะࠥะไ๋ใี๎ํ์๊สࠩ东")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ丝"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11ll1_l1_ (u"࠭ࠧ丞"):
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ丟"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ丠"),l11ll1_l1_ (u"ࠩࠪ両"),False,l11ll1_l1_ (u"ࠪࠫ丢"),l11ll1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ丣"))
		hostname = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ两")]
		hostname = hostname.strip(l11ll1_l1_ (u"࠭࠯ࠨ严"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ並")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l1111_l1_,filter):
	if l11ll1_l1_ (u"ࠨࡁࡂࠫ丧") in l1ll1l1l1111_l1_: url = l1ll1l1l1111_l1_.split(l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ丨"))[0]
	else: url = l1ll1l1l1111_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ丩"):l1ll1l1l1111_l1_,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ个"):l11ll1_l1_ (u"ࠬ࠭丫")}
	filter = filter.replace(l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ丬"),l11ll1_l1_ (u"ࠧࠨ中"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ丮"),1)
	if filter==l11ll1_l1_ (u"ࠩࠪ丯"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ丰"),l11ll1_l1_ (u"ࠫࠬ丱")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ串"))
	if type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ丳"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ临") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ丵") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ丶")+category+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ丷")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ丸")+category+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ丹")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠧࠩ为"))+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ主")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫ丼"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ丽"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ举")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ丿"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ乀"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"࠭ࠧ乁"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ乂"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠨࠩ乃"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ乄")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ久"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ乆"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠬ࠭乇"),l11ll1_l1_ (u"࠭ࠧ么"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ义"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ乊"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ之")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ乌"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠫࠬ乍"),l11ll1_l1_ (u"ࠬ࠭乎"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ乏"))
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ乐"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ乑"),l11ll1_l1_ (u"ࠩࠪ乒"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ乓"),url,l11ll1_l1_ (u"ࠫࠬ乔"),l11ll1_l1_ (u"ࠬ࠭乕"),l11ll1_l1_ (u"࠭ࠧ乖"),l11ll1_l1_ (u"ࠧࠨ乗"),l11ll1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ乘"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠧ࠭乙"),l11ll1_l1_ (u"ࠪࠦࠬ乚")).replace(l11ll1_l1_ (u"ࠫࡡࡢ࠯ࠨ乛"),l11ll1_l1_ (u"ࠬ࠵ࠧ乜"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ九"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ乞"),block+l11ll1_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ也"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ习") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ乡"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠫࡂࡃࠧ乢") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ乣"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭乤")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1111_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乥"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨ书"),l1llllll1_l1_,361,l11ll1_l1_ (u"ࠩࠪ乧"),l11ll1_l1_ (u"ࠪࠫ乨"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ乩"))
				else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乪"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾࠭乫"),l111lll_l1_,364,l11ll1_l1_ (u"ࠧࠨ乬"),l11ll1_l1_ (u"ࠨࠩ乭"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ乮"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭乯")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ买")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ乱")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠾࠲ࠪ乲")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ乳")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ乴"),l111l1_l1_+name+l11ll1_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ乵"),l111lll_l1_,365,l11ll1_l1_ (u"ࠪࠫ乶"),l11ll1_l1_ (u"ࠫࠬ乷"),l1l11lll_l1_+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ乸"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"࠭ࡲࠨ乹") or value==l11ll1_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭乺"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭乻") in option: continue
			if l11ll1_l1_ (u"ࠩส่่๊ࠧ乼") in option: continue
			if l11ll1_l1_ (u"ࠪࡲ࠲ࡧࠧ乽") in value: continue
			#if value in [l11ll1_l1_ (u"ࠫࡷ࠭乾"),l11ll1_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ乿"),l11ll1_l1_ (u"࠭ࡴࡷ࠯ࡰࡥࠬ亀")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭亁"): option = value
			if option==l11ll1_l1_ (u"ࠨࠩ亂"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ亃"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l1l1_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭亄")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ亅")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ了")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ亇")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ予")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ争")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ亊"):
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ事"),l111l1_l1_+l1lll1l1l_l1_,url,365,l11ll1_l1_ (u"ࠫࠬ二"),l11ll1_l1_ (u"ࠬ࠭亍"),l1ll1l11_l1_+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ于"))
			elif type==l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ亏") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ亐") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ云"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ互"),l11ll1_l1_ (u"ࠫࠬ亓"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ五")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l1111_l1_)
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭井"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,361,l11ll1_l1_ (u"ࠧࠨ亖"),l11ll1_l1_ (u"ࠨࠩ亗"),l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ亘"))
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ亙"),l111l1_l1_+l1lll1l1l_l1_,url,364,l11ll1_l1_ (u"ࠫࠬ亚"),l11ll1_l1_ (u"ࠬ࠭些"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ亜"),l11ll1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭亝"),l11ll1_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ亞")]
l1l111111_l1_ = [l11ll1_l1_ (u"ࠩࡰࡴࡦࡧࠧ亟"),l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ亠"),l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ亡"),l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ亢"),l11ll1_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ亣"),l11ll1_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ交"),l11ll1_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ亥"),l11ll1_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ亦")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ产") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ亨"),l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭亩"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ亪"),l11ll1_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫ享"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨ࠿ࡀࠫ京"),l11ll1_l1_ (u"ࠩ࠲ࠫ亭"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪࠪࠫ࠭亮"),l11ll1_l1_ (u"ࠫ࠴࠭亯"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭亰"),l11ll1_l1_ (u"࠭ࠧ亱"),filters,l11ll1_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧ亲")+mode)
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ亳")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ亴")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ亵")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠫࠫࠬࠧ亶"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠬ࠭亷")
	if l11ll1_l1_ (u"࠭࠽࠾ࠩ亸") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠧࠧࠨࠪ亹"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠨ࠿ࡀࠫ人"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠩ࠳ࠫ亻")
		if l11ll1_l1_ (u"ࠪࠩࠬ亼") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭亽") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧ亾"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠠࠬࠢࠪ亿")+value
		elif mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ什") and value!=l11ll1_l1_ (u"ࠨ࠲ࠪ仁"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ仂")+key+l11ll1_l1_ (u"ࠪࡁࡂ࠭仃")+value
		elif mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ仄"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ仅")+key+l11ll1_l1_ (u"࠭࠽࠾ࠩ仆")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ仇"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫ仈"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ仉"),l11ll1_l1_ (u"ࠪࠫ今"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠫࡔ࡛ࡔࠨ介"))
	return l1ll11ll_l1_
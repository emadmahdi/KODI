# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ摜")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ摝")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l11lllll1l_l1_ = l1l1lll_l1_[script_name][1]
l1l1ll1l11l_l1_ = l1l1lll_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11111_l1_(url)
	elif mode==52: results = l1llll1l_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1ll1lllll111_l1_()
	elif mode==56: results = l1ll1llll1l11_l1_()
	elif mode==57: results = l1ll1llll1l1l_l1_(url,1)
	elif mode==58: results = l1ll1llll1l1l_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ摞"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ摟"),l11ll1_l1_ (u"࠭ࠧ摠"),59,l11ll1_l1_ (u"ࠧࠨ摡"),l11ll1_l1_ (u"ࠨࠩ摢"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭摣"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ摤"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ摥"),l11ll1_l1_ (u"ࠬ࠭摦"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭摧"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ摨")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ摩"),l11ll1_l1_ (u"ࠩࠪ摪"),56)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ摫"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭摬")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไศใ็ห๊࠭摭"),l11ll1_l1_ (u"࠭ࠧ摮"),55)
	return l11ll1_l1_ (u"ࠧࠨ摯")
def l1ll1lllll111_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ摰"),l111l1_l1_+l11ll1_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ摱"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ摲"),51)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ摳"),l111l1_l1_+l11ll1_l1_ (u"ࠬอแๅษ่ࠤึอฦอหࠪ摴"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ摵"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ摶"),l111l1_l1_+l11ll1_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไศใ็ห๊࠭摷"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ摸"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ摹"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ็ไศ็ࠣ็้อำ๋ๅํอࠬ摺"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ摻"),51)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ摼"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ摽"),l11ll1_l1_ (u"ࠨࠩ摾"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ摿"),l111l1_l1_+l11ll1_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสึ๊ฮࠦวๅษ้ฮฬาࠧ撀"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡹࡰࡲࠪ撁"),57)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撂"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศใู่ࠥะโ๋์่ࠫ撃"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ撄"),57)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撅"),l111l1_l1_+l11ll1_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็ห่ััࠡ็ืห์ีษࠨ撆"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ撇"),57)
	return
def l1ll1llll1l11_l1_():
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ撈"),l111l1_l1_+l11ll1_l1_ (u"ࠬออะอࠣห้๋ำๅี็หฯ࠭撉"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ撊"),51)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ撋"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วหࠢิหหาษࠨ撌"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭撍"),51)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撎"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็ุ้๊ำๅษอࠫ撏"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ撐"),51)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭撑"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡๅ็หุ๐ใ๋หࠪ撒"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ撓"),51)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ撔"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ撕"),l11ll1_l1_ (u"ࠫࠬ撖"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撗"),l111l1_l1_+l11ll1_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ撘"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡽࡴࡶࠧ撙"),57)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撚"),l111l1_l1_+l11ll1_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ撛"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭撜"),57)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ撝"),l111l1_l1_+l11ll1_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭撞"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ撟"),57)
	return
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ撠"),l11ll1_l1_ (u"ࠨࠩ撡"),url,url)
	if l11ll1_l1_ (u"ࠩࡂࠫ撢") in url:
		parts = url.split(l11ll1_l1_ (u"ࠪࡃࠬ撣"))
		url = parts[0]
		filter = l11ll1_l1_ (u"ࠫࡄ࠭撤") + QUOTE(parts[1],l11ll1_l1_ (u"ࠬࡃࠦ࠻࠱ࠨࠫ撥"))
	else: filter = l11ll1_l1_ (u"࠭ࠧ撦")
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ撧"),l11ll1_l1_ (u"ࠨࠩ撨"),filter,l11ll1_l1_ (u"ࠩࠪ撩"))
	parts = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ撪"))
	sort,l1l1111_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11ll1_l1_ (u"ࠫࡾࡵࡰࠨ撫"),l11ll1_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࠬ撬"),l11ll1_l1_ (u"࠭ࡶࡪࡧࡺࡷࠬ播")]:
		if type==l11ll1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭撮"): l11lll111_l1_=l11ll1_l1_ (u"ࠨใํ่๊࠭撯")
		elif type==l11ll1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ撰"): l11lll111_l1_=l11ll1_l1_ (u"ุ้๊ࠪำๅࠩ撱")
		#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠲ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨ撲") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠬ࠵ࠧ撳") + l1l1111_l1_ + l11ll1_l1_ (u"࠭࠯ࠨ撴") + sort + filter
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ撵") + QUOTE(l11lll111_l1_) + l11ll1_l1_ (u"ࠨ࠱ࠪ撶") + l1l1111_l1_ + l11ll1_l1_ (u"ࠩ࠲ࠫ撷") + sort + filter
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ撸"),l11ll1_l1_ (u"ࠫࠬ撹"),l11ll1_l1_ (u"ࠬ࠭撺"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"࠭ࠧ撻"),l11ll1_l1_ (u"ࠧࠨ撼"),l11ll1_l1_ (u"ࠨࠩ撽"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ撾"))
		#items = re.findall(l11ll1_l1_ (u"ࠪࠦࡷ࡫ࡦࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࠤࡱࡹࡲ࡫ࡰࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡵࡩࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ撿"),html,re.DOTALL)
		items = re.findall(l11ll1_l1_ (u"ࠫࠧࡶࡩࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡰࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࠦࡵ࡫ࡰࡪࡵࡲࡨࡪࡹࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡲࡵࡩࡸࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ擀"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,title,l1ll1llll1111_l1_,l1lll1_l1_ in items:
			l1l1l1llll1_l1_ += 1
			#l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ擁") + l1lll1_l1_ + l11ll1_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭擂")
			l1lll1_l1_ = l1l1ll1l11l_l1_ + l11ll1_l1_ (u"ࠧ࠰ࡸ࠵࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࡰࡥ࡮ࡴ࠯ࠨ擃") + l1lll1_l1_ + l11ll1_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ擄")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ擅") + id
			if type==l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ擆"): addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ擇"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			if type==l11ll1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ擈"): addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擉"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้ࠦࠧ擊")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡨࡴࡂ࠭擋")+l1ll1llll1111_l1_+l11ll1_l1_ (u"ࠩࡀࠫ擌")+title+l11ll1_l1_ (u"ࠪࡁࠬ操")+l1lll1_l1_,52,l1lll1_l1_)
	else:
		if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ擎"): l11lll111_l1_=l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ擏")
		elif type==l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭擐"): l11lll111_l1_=l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ擑")
		url = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ擒") + sort + l11ll1_l1_ (u"ࠩ࠰ࠫ擓") + l11lll111_l1_ + l11ll1_l1_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ擔")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ擕"),l11ll1_l1_ (u"ࠬ࠭擖"),l11ll1_l1_ (u"࠭ࠧ擗"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭擘"))
		items = re.findall(l11ll1_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭擙"),html,re.DOTALL)
		l1l1l1llll1_l1_=0
		for id,l1ll1llll1111_l1_,l1lll1_l1_,title in items:
			l1l1l1llll1_l1_ += 1
			l1lll1_l1_ = l11lllll1l_l1_ + l11ll1_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ據") + l1lll1_l1_ + l11ll1_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ擛")
			l1lllll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ擜") + id
			if type==l11ll1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ擝"): addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ擞"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
			elif type==l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ擟"): addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ擠"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืู้ไࠡࠩ擡")+title,l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ擢")+l1ll1llll1111_l1_+l11ll1_l1_ (u"ࠫࡂ࠭擣")+title+l11ll1_l1_ (u"ࠬࡃࠧ擤")+l1lll1_l1_,52,l1lll1_l1_)
	title=l11ll1_l1_ (u"࠭ีโฯฬࠤࠬ擥")
	if l1l1l1llll1_l1_==16:
		for l1l1ll1l1l1_l1_ in range(1,13) :
			if not l1l1111_l1_==str(l1l1ll1l1l1_l1_):
				#url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ擦")+type+l11ll1_l1_ (u"ࠨ࠱ࠪ擧")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠩ࠲ࠫ擨")+sort + filter
				url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ擩")+type+l11ll1_l1_ (u"ࠫ࠴࠭擪")+str(l1l1ll1l1l1_l1_)+l11ll1_l1_ (u"ࠬ࠵ࠧ擫")+sort + filter
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擬"),l111l1_l1_+title+str(l1l1ll1l1l1_l1_),url,51)
	return
def l1llll1l_l1_(url):
	parts = url.split(l11ll1_l1_ (u"ࠧ࠾ࠩ擭"))
	l1ll1llll1111_l1_ = int(parts[1])
	name = l1111_l1_(parts[2])
	name = name.replace(l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭擮"),l11ll1_l1_ (u"ࠩࠪ擯"))
	l1lll1_l1_ = parts[3]
	url = url.split(l11ll1_l1_ (u"ࠪࡃࠬ擰"))[0]
	if l1ll1llll1111_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ擱"),l11ll1_l1_ (u"ࠬ࠭擲"),l11ll1_l1_ (u"࠭ࠧ擳"),l11ll1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ擴"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴ࠿ࠩ擵"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ擶"),block,re.DOTALL)
		l1ll1llll1111_l1_ = int(items[-1])
		#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ擷"),l11ll1_l1_ (u"ࠫࠬ擸"),l1ll1llll1111_l1_,l11ll1_l1_ (u"ࠬ࠭擹"))
	#name = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡬ࡸࡱ࡫ࠢ擺") )
	#l1lll1_l1_ = xbmc.getInfoLabel( l11ll1_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠣ擻") )
	for l1ll1l1_l1_ in range(l1ll1llll1111_l1_,0,-1):
		l1lllll_l1_ = url + l11ll1_l1_ (u"ࠨࡁࡨࡴࡂ࠭擼") + str(l1ll1l1_l1_)
		title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ擽")+name+l11ll1_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦࠧ擾")+str(l1ll1l1_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ擿"),l111l1_l1_+title,l1lllll_l1_,53,l1lll1_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠬ࠭攀"),l11ll1_l1_ (u"࠭ࠧ攁"),l11ll1_l1_ (u"ࠧࠨ攂"),l11ll1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ攃"))
	l1ll1llll11ll_l1_ = re.findall(l11ll1_l1_ (u"่ࠩฮํ็ัࠡ฻็ํฺ่ࠥโ่ࠢหู่ࠠษ฻า࠲࠯ࡅ࡭ࡰ࡯ࡨࡲࡹࡢࠨࠣࠪ࠱࠮ࡄ࠯ࠢࠨ攄"),html,re.DOTALL)
	if l1ll1llll11ll_l1_:
		time = l1ll1llll11ll_l1_[1].replace(l11ll1_l1_ (u"ࠪࡘࠬ攅"),l11ll1_l1_ (u"ࠫࠥࠦࠠࠡࠩ攆"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭攇"),l11ll1_l1_ (u"࠭ࠧ攈"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩ攉"),l11ll1_l1_ (u"ࠨ้ำหࠥอไโ์า๎ํࠦำ๋ๅ๋๊๋ࠥส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี่ࠠาสࠤฬ๊่ใฬࠪ攊")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ攋")+time)
		return
	#if l11ll1_l1_ (u"๊ࠪ฾ะะาࠢ฼่๎่ࠦใ๊฼ࠤำ฽รࠨ攌") in html:
	#	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ攍"),l11ll1_l1_ (u"ࠬ࠭攎"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ攏"),l11ll1_l1_ (u"ࠧ็฻อิึูࠦๅ๋ࠣ์็๎ูࠡะฺวࠬ攐"))
	#	return
	l1ll1lll1lll1_l1_,l1ll1llll1ll1_l1_ = [],[]
	l1ll1llll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡸࡤࡶࠥࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭攑"),html,re.DOTALL)[0]
	l1ll1llll11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡹࡥࡷࠦࡢࡢࡥ࡮ࡹࡵࡥ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ攒"),html,re.DOTALL)[0]
	# l1llll111_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡱࡹ࠺ࠡࠪ࠱࠮ࡄ࠯࡟࡭࡫ࡱ࡯ࡡ࠱ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ攓"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		if l11ll1_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ攔") in server:
			server = l11ll1_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ攕")
			url = l1ll1llll11l1_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ攖")
			url = l1ll1llll1lll_l1_ + l1lllll_l1_
		if l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭攗") in url:
			l1ll1lll1lll1_l1_.append(url)
			l1ll1llll1ll1_l1_.append(l11ll1_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠠࠨ攘")+server)
		l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࡪࡨࠣࠫ࠳ࡳ࠳ࡶ࠺ࠪࠤ࡮ࡴࠠࡶࡴ࡯࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨࡶࡴ࡯࠭ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛࠱࡟ࡀࡁࠬ࠳࠱ࠨ࠼ࠍࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥࡵࡳ࡮࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲࠩࠋࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡳࡧ࡭ࡦ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪࡱ࠸ࡻ࠸ࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࠪࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠮࠯࠺ࠋࠋࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࡟࡮ࡣࠩࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡾࡶࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡࡩ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࠣࠫ࠮ࡡ࠰࡞ࠌࠌࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࡟࡮ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࡨ࡬ࡰࡪࡺࡹࡱࡧ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠢࠪ࠰ࠬࠦࠠࠨࠫࠍࠍࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟࡯ࡣࡰࡩ࠳ࡧࡰࡱࡧࡱࡨ࠭࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠫࠨࠢࠣࠫ࠰ࡹࡥࡳࡸࡨࡶ࠰࠭ࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠨࠢࠣ攙")
	# l1111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡣࡱ࡯࡮࡬࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ攚"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11ll1_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ攛"),html,re.DOTALL)
	for server,l1lllll_l1_ in l1l1_l1_:
		filename = l1lllll_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ攜"))[-1]
		filename = filename.replace(l11ll1_l1_ (u"࠭ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠨ攝"),l11ll1_l1_ (u"ࠧࠨ攞"))
		filename = filename.replace(l11ll1_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭攟"),l11ll1_l1_ (u"ࠩࠪ攠"))
		filename = filename.replace(l11ll1_l1_ (u"ࠪ࠱ࠬ攡"),l11ll1_l1_ (u"ࠫࠬ攢"))
		if l11ll1_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ攣") in server:
			server = l11ll1_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭攤")
			url = l1ll1llll11l1_l1_ + l1lllll_l1_
		else:
			server = l11ll1_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ攥")
			url = l1ll1llll1lll_l1_ + l1lllll_l1_
		l1ll1lll1lll1_l1_.append(url)
		l1ll1llll1ll1_l1_.append(l11ll1_l1_ (u"ࠨ࡯ࡳ࠸ࠥࠦࠧ攦")+server+l11ll1_l1_ (u"ࠩࠣࠤࠬ攧")+filename)
	l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡚ࠣ࡮ࡪࡥࡰࠢࡔࡹࡦࡲࡩࡵࡻ࠽ࠫ攨"), l1ll1llll1ll1_l1_)
	if l1l_l1_ == -1 : return
	url = l1ll1lll1lll1_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ攩"))
	return
def l1ll1llll1l1l_l1_(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭攪"),l11ll1_l1_ (u"࠭ࠧ攫"),url,url)
	if l11ll1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ攬") in url: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰็ึุ่๊ࠧ攭")
	else: l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ไ๎้๋ࠧ攮")
	l111lll_l1_ = QUOTE(l111lll_l1_)
	html = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠪࠫ支"),l11ll1_l1_ (u"ࠫࠬ攰"),l11ll1_l1_ (u"ࠬ࠭攱"),l11ll1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡈࡌࡐ࡙ࡋࡒࡔ࠯࠴ࡷࡹ࠭攲"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ攳"),l11ll1_l1_ (u"ࠨࠩ攴"),url,html)
	if type==1: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡶࡹࡧ࡭ࡥ࡯ࡴࡨࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ攵"),html,re.DOTALL)
	elif type==2: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ收"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࠫ攷"),block,re.DOTALL)
	if type==1:
		for l1ll1lll1llll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ攸"),l111l1_l1_+title,url+l11ll1_l1_ (u"࠭࠿ࡴࡷࡥ࡫ࡪࡴࡲࡦ࠿ࠪ改")+l1ll1lll1llll_l1_,58)
	elif type==2:
		url,l1ll1lll1llll_l1_ = url.split(l11ll1_l1_ (u"ࠧࡀࠩ攺"))
		for l1ll1l1111l1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攻"),l111l1_l1_+title,url+l11ll1_l1_ (u"ࠩࡂࡧࡴࡻ࡮ࡵࡴࡼࡁࠬ攼")+l1ll1l1111l1_l1_+l11ll1_l1_ (u"ࠪࠪࠬ攽")+l1ll1lll1llll_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ放"),l11ll1_l1_ (u"ࠬ࠭政"),search,search)
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ敀"),l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫ敁"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ敂"), l11l1l_l1_, l11ll1_l1_ (u"ࠩࠪ敃"), l11ll1_l1_ (u"ࠪࠫ敄"), True,l11ll1_l1_ (u"ࠫࠬ故"),l11ll1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ敆"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l1l111_l1_ = cookies[l11ll1_l1_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧ敇")]
	#l1ll1llll111l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡤࡵࡵࡪࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧ效"),html,re.DOTALL)
	#l1ll1llll111l_l1_ = l1ll1llll111l_l1_[0]
	#payload = l11ll1_l1_ (u"ࠨࡡࡦࡷࡷ࡬࠽ࠨ敉") + l1ll1llll111l_l1_ + l11ll1_l1_ (u"ࠩࠩࡵࡂ࠭敊") + QUOTE(l1111ll_l1_)
	#headers = { l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ敋"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ敌") , l11ll1_l1_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬ敍"):l11ll1_l1_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠨ敎")+l11l1l111_l1_ }
	#url = l11l1l_l1_ + l11ll1_l1_ (u"ࠢ࠰ࡵࡨࡥࡷࡩࡨࠣ敏")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭敐"), url, payload, headers, True,l11ll1_l1_ (u"ࠩࠪ救"),l11ll1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ敒"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ敓")+l1111ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ敔"),url,l11ll1_l1_ (u"࠭ࠧ敕"),l11ll1_l1_ (u"ࠧࠨ敖"),True,l11ll1_l1_ (u"ࠨࠩ敗"),l11ll1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ敘"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡥࡳࡣ࡯࠱ࡧࡵࡤࡺࠪ࠱࠮ࡄ࠯ࡳࡦࡣࡵࡧ࡭࠳ࡢࡰࡶࡷࡳࡲ࠳ࡰࡢࡦࡧ࡭ࡳ࡭ࠧ教"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ敚"),block,re.DOTALL)
	if items:
		for l1lllll_l1_,l1lll1_l1_,title in items:
			#title = title.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ敛")).encode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ敜"))
			url = l11l1l_l1_ + l1lllll_l1_
			if l11ll1_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ敝") in url:
				if l11ll1_l1_ (u"ࠨࡁࡨࡴࡂ࠭敞") in url:
					title = l11ll1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ敟")+title
					url = url.replace(l11ll1_l1_ (u"ࠪࡃࡪࡶ࠽࠲ࠩ敠"),l11ll1_l1_ (u"ࠫࡄ࡫ࡰ࠾࠲ࠪ敡"))
					url = url+l11ll1_l1_ (u"ࠬࡃࠧ敢")+QUOTE(title)+l11ll1_l1_ (u"࠭࠽ࠨ散")+l1lll1_l1_
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ敤"),l111l1_l1_+title,url,52,l1lll1_l1_)
				else:
					title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥแ๋ๆ่ࠤࠬ敥")+title
					addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ敦"),l111l1_l1_+title,url,53,l1lll1_l1_)
	#else: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ敧"),l11ll1_l1_ (u"ࠫࠬ敨"),l11ll1_l1_ (u"ࠬࡴ࡯ࠡࡴࡨࡷࡺࡲࡴࡴࠩ敩"),l11ll1_l1_ (u"࠭ไศࠢอ์ัีࠠ็ฬสสัࠦไๅสะฯࠬ敪"))
	return
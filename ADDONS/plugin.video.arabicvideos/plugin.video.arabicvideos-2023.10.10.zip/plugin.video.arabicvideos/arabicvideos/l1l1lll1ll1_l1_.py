# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ⸎")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩ⸏")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"๊ࠫ฻วา฻ฬࠫ⸐"),l11ll1_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫ⸑"),l11ll1_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬ⸒"),l11ll1_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭⸓")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l11111_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l1llll1l_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ⸔"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ⸕"),l11ll1_l1_ (u"ࠪࠫ⸖"),l11ll1_l1_ (u"ࠫࠬ⸗"),l11ll1_l1_ (u"ࠬ࠭⸘"),l11ll1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⸙"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ⸚"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸛"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⸜"),l11ll1_l1_ (u"ࠪࠫ⸝"),89,l11ll1_l1_ (u"ࠫࠬ⸞"),l11ll1_l1_ (u"ࠬ࠭⸟"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⸠"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸡"),l111l1_l1_+l11ll1_l1_ (u"ࠨษัฮึ์วࠡๆๆࠫ⸢"),l1ll111_l1_,81,l11ll1_l1_ (u"ࠩࠪ⸣"),l11ll1_l1_ (u"ࠪࠫ⸤"),l11ll1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⸥"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⸦"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⸧"),block,re.DOTALL)
	for l1lll1l1l1_l1_,title in items:
		l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭⸨")+l1lll1l1l1_l1_+l11ll1_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ⸩")
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸪"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⸫")+l111l1_l1_+title,l1lllll_l1_,81)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⸬"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⸭"),l11ll1_l1_ (u"࠭ࠧ⸮"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨⸯ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⸰"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if l1lllll_l1_==l11ll1_l1_ (u"ࠩࠦࠫ⸱"): continue
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸲"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⸳")+l111l1_l1_+title,l1lllll_l1_,81)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠬ࠭⸴")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ⸵"),l11ll1_l1_ (u"ࠧࠨ⸶"),url)
	items = []
	# l1lll11lll_l1_ l1lll1l111_l1_
	if l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ⸷") in url or l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ⸸") in url:
		l111lll_l1_,l11ll11l1_l1_ = l1lll1l11l_l1_(url)
		l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⸹"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ⸺")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ⸻"),l111lll_l1_,l11ll11l1_l1_,l1l1ll11l_l1_,l11ll1_l1_ (u"࠭ࠧ⸼"),l11ll1_l1_ (u"ࠧࠨ⸽"),l11ll1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⸾"))
		html = response.content
		l1l1l11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭⸿"),url,l11ll1_l1_ (u"ࠪࠫ⹀"),l11ll1_l1_ (u"ࠫࠬ⹁"),l11ll1_l1_ (u"ࠬ࠭⹂"),l11ll1_l1_ (u"࠭ࠧ⹃"),l11ll1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⹄"))
		html = response.content
		# l1lll1l1l1_l1_ items
		if l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⹅"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⹆"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⹇"),block,re.DOTALL)
			#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⹈"),l11ll1_l1_ (u"ࠬ࠭⹉"),l11ll1_l1_ (u"࠭ࠧ⹊"))
		# l1llll11l1_l1_ l111l1l1_l1_
		elif l11ll1_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠧ⹋") in html:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⹌"),html,re.DOTALL)
		else:
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ⹍"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items:
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⹎"),block,re.DOTALL)
		if not items: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⹏"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ⹐"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ⹑"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭⹒"),l11ll1_l1_ (u"ࠨๅ็๎อ࠭⹓"),l11ll1_l1_ (u"ࠩส฽้อๆࠨ⹔"),l11ll1_l1_ (u"๋ࠪิอแࠨ⹕"),l11ll1_l1_ (u"๊ࠫฮวาษฬࠫ⹖"),l11ll1_l1_ (u"ࠬ฿ัืࠩ⹗"),l11ll1_l1_ (u"࠭ๅ่ำฯห๋࠭⹘"),l11ll1_l1_ (u"ࠧศๆห์๊࠭⹙")]
	for l1lllll_l1_,title,l1lll1_l1_ in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠱ࠪ⹚"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ⹛"),title,re.DOTALL)
		if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⹜") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹝"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
		elif l11ll1_l1_ (u"ูࠬไศี็ࠫ⹞") not in url and any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⹟"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ⹠") in title:
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⹡") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹢"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ⹣") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹤"),l111l1_l1_+title,l1lllll_l1_,81,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹥"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࠧ⹦"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫ⹧"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⹨"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠤࠥ⹩"): continue
				#title = unescapeHTML(title)
				if title!=l11ll1_l1_ (u"ࠪࠫ⹪"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹫"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ⹬")+title,l1lllll_l1_,81)
	if l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⹭") in url or l11ll1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ⹮") in url:
		if l11ll1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ⹯") in url:
			url = url.replace(l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩ⹰"),l11ll1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫ⹱"))+l11ll1_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨ⹲")
		elif l11ll1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭⹳") in url:
			url,offset = url.split(l11ll1_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨ⹴"))
			offset = int(offset)+20
			url = url+l11ll1_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩ⹵")+str(offset)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹶"),l111l1_l1_+l11ll1_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧ⹷"),url,81)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⹸"),url,l11ll1_l1_ (u"ࠫࠬ⹹"),l11ll1_l1_ (u"ࠬ࠭⹺"),l11ll1_l1_ (u"࠭ࠧ⹻"),l11ll1_l1_ (u"ࠧࠨ⹼"),l11ll1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⹽"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⹾"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⹿"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⺀") not in url:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺁"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺂"),l111l1_l1_+title,l1lllll_l1_,83,l1lll1_l1_)
	# l1l11_l1_
	elif l1l111l_l1_:
		l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⺃"),html,re.DOTALL)
		l1lll1_l1_ = l1lll1_l1_[0]
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⺄"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#title = title.replace(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ⺅"),l11ll1_l1_ (u"ࠪࠫ⺆")).strip(l11ll1_l1_ (u"ࠫࠥ࠭⺇"))
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⺈"),l111l1_l1_+title,l1lllll_l1_,82,l1lll1_l1_)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ⺉"),l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ⺊"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ⺋"),l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ⺌"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ⺍"),l111lll_l1_,l11ll1_l1_ (u"ࠫࠬ⺎"),l11ll1_l1_ (u"ࠬ࠭⺏"),l11ll1_l1_ (u"࠭ࠧ⺐"),l11ll1_l1_ (u"ࠧࠨ⺑"),l11ll1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⺒"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭⺓"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⺔"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l11lll11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⺕"),html,re.DOTALL)
		l11lll11_l1_ = l11lll11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ⺖"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ⺗"),l11ll1_l1_ (u"ࠧࠨ⺘")).strip(l11ll1_l1_ (u"ࠨࠢࠪ⺙"))
			l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡃࡸ࡫ࡲࡷࡧࡵࡁࠬ⺚")+server+l11ll1_l1_ (u"ࠪࠪࡵࡵࡳࡵࡋࡇࡁࠬ⺛")+l11lll11_l1_+l11ll1_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬ⺜")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⺝")+title+l11ll1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⺞")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡦࡲࡻࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⺟"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⺠"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⺡")+name+l11ll1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⺢")
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⺣"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⺤"),url)
	return
l11ll1_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡐࡍࡃ࡜ࡣࡔࡒࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࡦࡤࡸࡦࠦ࠽ࠡࡽ࡚ࠪ࡮࡫ࡷࠨ࠼࠴ࢁࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࠾ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫࢂࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡒࡒࡗ࡙࠭ࠬࡶࡴ࡯࠰ࡩࡧࡴࡢ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠊࠊࠥࠣࡻࡦࡺࡣࡩࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡹࡤࡸࡨ࡮ࡁࡳࡧࡤࡑࡦࡹࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡲࡼࡲ࡯ࡢࡦ࠰ࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡸ࡫ࡲ࠮ࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩ࠱ࡷࡵࡢ࡮࡬ࡸࡾ࠲࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠱ࠧࡠࡡࡢࡣࠬ࠱ࡱࡶࡣ࡯࡭ࡹࡿࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊ࡫ࡩࠤࡱ࡫࡮ࠩ࡮࡬ࡲࡰࡒࡉࡔࡖࠬࡁࡂ࠶࠺ࠡࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠭ࠩส่ึอศุࠢ็๎ุࠦแ๋้ࠣๅ๏ี๊้ࠩࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࠍࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦ⺥")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨ⺦"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩ⺧"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫ⺨"),l11ll1_l1_ (u"ࠪ࠱ࠬ⺩"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⺪")+search+l11ll1_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ⺫")
	l11111_l1_(url)
	return
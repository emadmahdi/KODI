# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭ፇ")
l111l1_l1_ = l11ll1_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧፈ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ፉ"):l11ll1_l1_ (u"ࠪࠫፊ")}
l1l11l_l1_ = [l11ll1_l1_ (u"ࠫฬ็ไศ็่้้ࠣศศำࠪፋ"),l11ll1_l1_ (u"ࠬฮใาษࠣࡘ࡛࠭ፌ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l11111_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l11111ll1_l1_(url)
	elif mode==375: results = l111111l1_l1_(url)
	elif mode==376: results = l111111ll_l1_(0,url)
	elif mode==377: results = l111111ll_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪፍ"),l11l1l_l1_,l11ll1_l1_ (u"ࠧࠨፎ"),l11ll1_l1_ (u"ࠨࠩፏ"),l11ll1_l1_ (u"ࠩࠪፐ"),l11ll1_l1_ (u"ࠪࠫፑ"),l11ll1_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬፒ"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፓ"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ፔ"),l11ll1_l1_ (u"ࠧࠨፕ"),379,l11ll1_l1_ (u"ࠨࠩፖ"),l11ll1_l1_ (u"ࠩࠪፗ"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧፘ"))
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩፙ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬፚ"),l11ll1_l1_ (u"࠭ࠧ፛"),9999)
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠳ࡳࡪࡦࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ፜"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ፝"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፞"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፟")+l111l1_l1_+title,l1lllll_l1_,371)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፠"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፡")+l111l1_l1_+l11ll1_l1_ (u"࠭วๅ็่๎ืฯࠧ።"),l11l1l_l1_,375)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፣"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፤")+l111l1_l1_+l11ll1_l1_ (u"ࠩส่ศำฯฬࠩ፥"),l11l1l_l1_,376)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ፦"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭፧")+l111l1_l1_+l11ll1_l1_ (u"ࠬ๐ิศ้าࠤฬ๊ย็ࠩ፨"),l11l1l_l1_,377)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭፩"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ፪")+l111l1_l1_+l11ll1_l1_ (u"ࠨไสส๊ฯࠠศๆ่้ะ๊๊็ࠩ፫"),l11l1l_l1_,374)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ፬"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ፭"),l11ll1_l1_ (u"ࠫࠬ፮"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡴࡰࡲ࠰ࡱࡪࡴࡵࠨ፯"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ፰"),block,re.DOTALL)
		for l1lllll_l1_,title in items[7:]:
			title = title.strip(l11ll1_l1_ (u"ࠧࠡࠩ፱"))
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፲"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፳")+l111l1_l1_+title,l1lllll_l1_,371)
		for l1lllll_l1_,title in items[0:7]:
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ፴"))
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፵"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፶")+l111l1_l1_+title,l1lllll_l1_,371)
	return
def l11111ll1_l1_(l1l1l1l1_l1_=l11ll1_l1_ (u"࠭ࠧ፷")):
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ፸"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ፹"),l11ll1_l1_ (u"ࠩࠪ፺"),l11ll1_l1_ (u"ࠪࠫ፻"),l11ll1_l1_ (u"ࠫࠬ፼"),l11ll1_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡆࡉࡔࡐࡔࡖࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ፽"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠣࡧࡦࡺࠠࡕࡣࡪࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ፾"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭፿"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᎀ") in l1lllll_l1_: continue
			else: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎁ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᎂ")+l111l1_l1_+title,l1lllll_l1_,371)
	return
def l111111l1_l1_(l1l1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬᎃ")):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᎄ"),l11l1l_l1_,l11ll1_l1_ (u"࠭ࠧᎅ"),l11ll1_l1_ (u"ࠧࠨᎆ"),l11ll1_l1_ (u"ࠨࠩᎇ"),l11ll1_l1_ (u"ࠩࠪᎈ"),l11ll1_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡉࡉࡆ࡚ࡕࡓࡇࡇ࠱࠶ࡹࡴࠨᎉ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡓࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠷࠭ᎊ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡶࡪࡦࡳࡥ࡬࡫࡟࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪᎋ"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"࠭࠺࠰࠱ࠪᎌ"),l11ll1_l1_ (u"ࠧ࠻࠱࠲࠳ࠬᎍ")).replace(l11ll1_l1_ (u"ࠨ࠱࠲ࠫᎎ"),l11ll1_l1_ (u"ࠩ࠲ࠫᎏ")).replace(l11ll1_l1_ (u"ࠪࠤࠬ᎐"),l11ll1_l1_ (u"ࠫࠪ࠸࠰ࠨ᎑"))
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᎒"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᎓")+l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
	return
def l111111ll_l1_(id,l1l1l1l1_l1_=l11ll1_l1_ (u"ࠧࠨ᎔")):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ᎕"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ᎖"),l11ll1_l1_ (u"ࠪࠫ᎗"),l11ll1_l1_ (u"ࠫࠬ᎘"),l11ll1_l1_ (u"ࠬ࠭᎙"),l11ll1_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡝ࡁࡕࡅࡋࡍࡓࡍࡎࡐ࡙࠰࠵ࡸࡺࠧ᎚"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠶࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡳࡼ࠭᎛"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[id]
		items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫ᎜"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if not any(value in title for value in l1l11l_l1_):
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠩ࠽࠳࠴࠭᎝"),l11ll1_l1_ (u"ࠪ࠾࠴࠵࠯ࠨ᎞")).replace(l11ll1_l1_ (u"ࠫ࠴࠵ࠧ᎟"),l11ll1_l1_ (u"ࠬ࠵ࠧᎠ")).replace(l11ll1_l1_ (u"࠭ࠠࠨᎡ"),l11ll1_l1_ (u"ࠧࠦ࠴࠳ࠫᎢ"))
				addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᎣ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᎤ")+l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
	return
def l11111_l1_(url,l11lll111_l1_=l11ll1_l1_ (u"ࠪࠫᎥ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬᎦ"),l11ll1_l1_ (u"ࠬ࠭Ꭷ"),l11lll111_l1_,url)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ꭸ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫᎩ"),url,l11ll1_l1_ (u"ࠨࠩᎪ"),l11ll1_l1_ (u"ࠩࠪᎫ"),l11ll1_l1_ (u"ࠪࠫᎬ"),l11ll1_l1_ (u"ࠫࠬᎭ"),l11ll1_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᎮ"))
	html = response.content
	if l11ll1_l1_ (u"࠭ࡶࡪࡦࡳࡥ࡬࡫࡟ࠨᎯ") in url:
		l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠰ࡃ࡯ࡦࡺࡳ࠭࠯ࠬࡂ࠭ࠧ࠭Ꮀ"),html,re.DOTALL)
		if l1lllll_l1_:
			l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]
			l11111_l1_(l1lllll_l1_)
			return
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠢࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡳࡤ࠮࠵ࠪᎱ"),html,re.DOTALL)
	if l11lll111_l1_==l11ll1_l1_ (u"ࠩࠪᎲ") and l1l1l11_l1_ and l1l1l11_l1_[0].count(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨᎳ"))>1:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎴ"),l111l1_l1_+l11ll1_l1_ (u"ࠬอไอ็ํ฽ࠬᎵ"),url,371,l11ll1_l1_ (u"࠭ࠧᎶ"),l11ll1_l1_ (u"ࠧࠨᎷ"),l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࡳࠨᎸ"))
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᎹ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬᎺ")+l1lllll_l1_
			title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭Ꮋ"))
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᎼ"),l111l1_l1_+title,l1lllll_l1_,371)
	else:
		l11l_l1_ = []
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡱࡩ࠳࠳ࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡻࡷ࠲࠷࠲ࠨᎽ"),html,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠹ࠤࠫ࠲࠯ࡅࠩࡤࡱ࡯࠱ࡽࡹ࠭࠲࠴ࠪᎾ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠪᎿ"),block,re.DOTALL)
			l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࠊ࡫ࡷࡩࡲࡹ࠲ࠡ࠿ࠣ࡟ࡢࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰࡮ࡳࡧ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵࡴࡼ࠾ࠥࡩ࡯ࡶࡰࡷࠤࡂࠦࡩ࡯ࡶࠫࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨษ็ั้่ษࠡ࠭ࠫࡠࡩ࠱ࠩࠨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࡠ࠶࡝ࠪࠌࠌࠍࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡤࡱࡸࡲࡹࠦ࠽ࠡ࠯࠴ࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࠲࠯ࡣࡳࡴࡪࡴࡤࠩࠪ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠫࠬࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡵࡲࡶࡹ࡫ࡤࠩ࡫ࡷࡩࡲࡹ࠲࠭ࠢࡵࡩࡻ࡫ࡲࡴࡧࡀࡊࡦࡲࡳࡦ࠮ࠣ࡯ࡪࡿ࠽࡭ࡣࡰࡦࡩࡧࠠ࡬ࡧࡼ࠾ࠥࡱࡥࡺ࡝࠶ࡡ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰࡮ࡳࡧ࠭ࡶ࡬ࡸࡱ࡫ࠬࡤࡱࡸࡲࡹࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠨࠢࠣᏀ")
			for l1lllll_l1_,l1lll1_l1_,title in items:
				#LOG_THIS(l11ll1_l1_ (u"ࠪࠫᏁ"),l1lll1_l1_)
				l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭Ꮒ"))
				l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠬࡀ࠯࠰ࠩᏃ"),l11ll1_l1_ (u"࠭࠺࠰࠱࠲ࠫᏄ")).replace(l11ll1_l1_ (u"ࠧ࠰࠱ࠪᏅ"),l11ll1_l1_ (u"ࠨ࠱ࠪᏆ")).replace(l11ll1_l1_ (u"ࠩࠣࠫᏇ"),l11ll1_l1_ (u"ࠪࠩ࠷࠶ࠧᏈ"))
				if l11ll1_l1_ (u"ࠫ࠴ࡧ࡬ࡠࠩᏉ") in l1lllll_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏊ"),l111l1_l1_+title,l1lllll_l1_,371,l1lll1_l1_)
				elif l11ll1_l1_ (u"࠭วๅฯ็ๆฮ࠭Ꮛ") in title and (l11ll1_l1_ (u"ࠧ࠰ࡅࡤࡸ࠲࠭Ꮜ") in url or l11ll1_l1_ (u"ࠨ࠱ࡖࡩࡦࡸࡣࡩ࠱ࠪᏍ") in url):
					l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠯ࠣ࠯ฬ๊อๅไฬࠤ࠰ࡢࡤࠬࠩᏎ"),title,re.DOTALL)
					if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨᏏ")+l1ll1l1_l1_[0]
					if title not in l11l_l1_:
						l11l_l1_.append(title)
						addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᏐ"),l111l1_l1_+title,l1lllll_l1_,371,l1lll1_l1_)
				else: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᏑ"),l111l1_l1_+title,l1lllll_l1_,372,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᏒ"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᏓ"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
				title = l11ll1_l1_ (u"ࠨืไัฮࠦࠧᏔ")+unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏕ"),l111l1_l1_+title,l1lllll_l1_,371,l11ll1_l1_ (u"ࠪࠫᏖ"),l11ll1_l1_ (u"ࠫࠬᏗ"),l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡷࠬᏘ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪᏙ"),url,l11ll1_l1_ (u"ࠧࠨᏚ"),l11ll1_l1_ (u"ࠨࠩᏛ"),l11ll1_l1_ (u"ࠩࠪᏜ"),l11ll1_l1_ (u"ࠪࠫᏝ"),l11ll1_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᏞ"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡲࡡࡣࡧ࡯࠱ࡸࡻࡣࡤࡧࡶࡷࠥࡳࡲࡨ࠯ࡥࡸࡲ࠳࠵ࠡࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᏟ"),html,re.DOTALL)
	if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	l11l111_l1_ = l11ll1_l1_ (u"࠭ࠧᏠ")
	l111lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡷࡣࡵࠤࡺࡸ࡬ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᏡ"),html,re.DOTALL)
	if l111lll_l1_: l111lll_l1_ = l111lll_l1_[0]
	else: l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩࡶࡡࡨࡧࡢࠫᏢ"),l11ll1_l1_ (u"ࠩ࠲ࡔࡱࡧࡹ࠰ࠩᏣ"))
	if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᏤ") not in l111lll_l1_: l111lll_l1_ = l11l1l_l1_+l111lll_l1_
	l111lll_l1_ = l111lll_l1_.strip(l11ll1_l1_ (u"ࠫ࠲࠭Ꮵ"))
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩᏦ"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧᏧ"),l11ll1_l1_ (u"ࠧࠨᏨ"),l11ll1_l1_ (u"ࠨࠩᏩ"),l11ll1_l1_ (u"ࠩࠪᏪ"),l11ll1_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫᏫ"))
	l11ll1ll_l1_ = response.content
	l11l111_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᏬ"),l11ll1ll_l1_,re.DOTALL)
	if l11l111_l1_:
		l11l111_l1_ = l11l111_l1_[-1]
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᏭ") not in l11l111_l1_: l11l111_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᏮ")+l11l111_l1_
		if l11ll1_l1_ (u"ࠧ࠰ࡒࡏࡅ࡞࠵ࠧᏯ") not in l111lll_l1_:
			if l11ll1_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠮࡮࡫ࡱ࠲࡯ࡹࠧᏰ") in l11l111_l1_:
				l11111l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᏱ"),l11ll1ll_l1_,re.DOTALL)
				if l11111l11_l1_:
					l1111111l_l1_, l11111l1l_l1_ = l11111l11_l1_[0]
					l11l111_l1_ = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧᏲ"))+l11ll1_l1_ (u"ࠫ࠴ࡼ࠲࠰ࠩᏳ")+l1111111l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡣࡰࡰࡩ࡭࡬࠵ࠧᏴ")+l11111l1l_l1_+l11ll1_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬᏵ")
		import ll_l1_
		ll_l1_.l11_l1_([l11l111_l1_],script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᏶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ᏷"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪᏸ"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬᏹ"),l11ll1_l1_ (u"ࠫ࠰࠭ᏺ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡓࡦࡣࡵࡧ࡭࠵ࠧᏻ")+search
	l11111_l1_(url)
	return
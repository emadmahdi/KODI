# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
#l11l1l_l1_ = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ仌")
headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ仍"):l11ll1_l1_ (u"ࠧࠨ从")}
script_name = l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ仏")
l111l1_l1_ = l11ll1_l1_ (u"ࠩࡢࡔࡓ࡚࡟ࠨ仐")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,l1l1111_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11ll1_l1_ (u"ࠪ࠷ࠬ仑"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11ll1_l1_ (u"ࠫ࠶࠭仒"))
	elif mode==36: results = CATEGORIES(url,l11ll1_l1_ (u"ࠬ࠸ࠧ仓"))
	elif mode==37: results = CATEGORIES(url,l11ll1_l1_ (u"࠭࠴ࠨ仔"))
	elif mode==38: results = l1l1ll1ll_l1_()
	elif mode==39: results = SEARCH(text,l1l1111_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ仕"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ他"),l11ll1_l1_ (u"ࠩࠪ仗"),39,l11ll1_l1_ (u"ࠪࠫ付"),l11ll1_l1_ (u"ࠫࠬ仙"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ仚"))
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ仛"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ仜"),l11ll1_l1_ (u"ࠨࠩ仝"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ仞"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ仟")+l111l1_l1_+l11ll1_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭仠"),l11ll1_l1_ (u"ࠬ࠭仡"),38)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭仢"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ代")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วห๋ࠢฬึอๅอࠩ令"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ以"),31)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ仦"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭仧")+l111l1_l1_+l11ll1_l1_ (u"ࠬอไๆี็ื้อสࠡษ็ห่ััࠡ็ืห์ีษࠨ仨"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ仩"),37)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ仪"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ仫")+l111l1_l1_+l11ll1_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไ็๊฼ࠫ们"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ仭"),35)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ仮"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ仯")+l111l1_l1_+l11ll1_l1_ (u"࠭วโๆส้ࠥำำษࠢส่๊๋หๅࠩ仰"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ仱"),36)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ仲"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ仳")+l111l1_l1_+l11ll1_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩ仴"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ仵"),32)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ件"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ价")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆีิั๏อสࠨ仸"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰࠶࠲࠵ࠬ仹"),32)
	return l11ll1_l1_ (u"ࠩࠪ仺")
def CATEGORIES(url,select=l11ll1_l1_ (u"ࠪࠫ任")):
	type = url.split(l11ll1_l1_ (u"ࠫ࠴࠭仼"))[3]
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭份"),l11ll1_l1_ (u"࠭ࠧ仾"),type, url)
	if type==l11ll1_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ仿"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠨࠩ伀"),headers,l11ll1_l1_ (u"ࠩࠪ企"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪ伂"))
		if select==l11ll1_l1_ (u"ࠫ࠸࠭伃"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡷࡪࡸࡩࡦࡵࡉࡳࡷࡳࠧ伄"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ伅"),block,re.DOTALL)
			for l1lllll_l1_,name in items:
				if l11ll1_l1_ (u"ࠧไๆํฬฬะࠠๆุะ็ฮ࠭伆") in name: continue
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠨࠢࠪ伇"))
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伈"),l111l1_l1_+name,url,32)
		if select==l11ll1_l1_ (u"ࠪ࠸ࠬ伉"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡨࡪࡺࡡࡪ࡮ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡷࡀ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃ࠭伊"),html,re.DOTALL)
			block= l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ伋"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,title in items:
				url = l11l1l_l1_ + l1lllll_l1_
				title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ伌"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ伍"),l111l1_l1_+title,url,32,l1lll1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ伎"),l11ll1_l1_ (u"ࠩࠪ伏"),url,l11ll1_l1_ (u"ࠪࠫ伐"))
	if type==l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ休"):
		html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠬ࠭伒"),headers,l11ll1_l1_ (u"࠭ࠧ伓"),l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠶ࡳࡪࠧ伔"))
		if select==l11ll1_l1_ (u"ࠨ࠳ࠪ伕"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡉࡨࡲࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡥ࡭ࡧࡦࡸࠬ伖"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ众"),block,re.DOTALL)
			for value,name in items:
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳ࠬ优") + value
				name = name.strip(l11ll1_l1_ (u"ࠬࠦࠧ伙"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭会"),l111l1_l1_+name,url,32)
		elif select==l11ll1_l1_ (u"ࠧ࠳ࠩ伛"):
			l1l1l11_l1_=re.findall(l11ll1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡂࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ伜"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items=re.findall(l11ll1_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ伝"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11ll1_l1_ (u"ࠪࠤࠬ伞"))
				url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴ࡧࡣࡵࡱࡵ࠳ࠬ伟") + value
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ传"),l111l1_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ伡"),l11ll1_l1_ (u"ࠧࠨ伢"),url,l11ll1_l1_ (u"ࠨࠩ伣"))
	type = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ伤"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠪࠫ伥"),headers,l11ll1_l1_ (u"ࠫࠬ伦"),l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ伧"))
	if l11ll1_l1_ (u"࠭ࡨࡰ࡯ࡨࠫ伨") in url: type=l11ll1_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ伩")
	if type==l11ll1_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ伪"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷ࠭࠴ࠪࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ伫"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ伬"),block,re.DOTALL)
			for l1lllll_l1_,l1lll1_l1_,name in items:
				url = l11l1l_l1_ + l1lllll_l1_
				name = name.strip(l11ll1_l1_ (u"ࠫࠥ࠭伭"))
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伮"),l111l1_l1_+name,url,32,l1lll1_l1_)
	if type==l11ll1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭伯"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ估"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠬࡁࠬࠦࠬ伱"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,name in items:
			name = name.strip(l11ll1_l1_ (u"ࠩࠣࠫ伲"))
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ伳"),l111l1_l1_+name,url,33,l1lll1_l1_)
	if type==l11ll1_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭伴"):
		l1l1111_l1_ = url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ伵"))[-1]
		#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ伶"),l11ll1_l1_ (u"ࠧࠨ伷"),url,l11ll1_l1_ (u"ࠨࠩ伸"))
		if l1l1111_l1_==l11ll1_l1_ (u"ࠩ࠴ࠫ伹"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠨ伺"),html,re.DOTALL)
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࠬ伻"),block,re.DOTALL)
			count = 0
			for l1lllll_l1_,l1lll1_l1_,l1ll1l1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11ll1_l1_ (u"ࠬࠦ࠭ࠡࠩ似") + l1ll1l1_l1_
				url = l11l1l_l1_ + l1lllll_l1_
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ伽"),l111l1_l1_+name,url,33,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶ࠲࠯ࡅࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ伾"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࠩ伿"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title,l1ll1l1_l1_ in items:
			l1ll1l1_l1_ = l1ll1l1_l1_.strip(l11ll1_l1_ (u"ࠩࠣࠫ佀"))
			title = title.strip(l11ll1_l1_ (u"ࠪࠤࠬ佁"))
			name = title + l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ佂") + l1ll1l1_l1_
			url = l11l1l_l1_ + l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ佃"),l111l1_l1_+name,url,33,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡧ࡭ࡻࡳ࡬࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠯ࡄ࠯ࡤࡢࡶࡤ࠱ࡷ࡫ࡶࡪࡸࡨ࠱ࡿࡵ࡮ࡦ࡫ࡧࡁࠧ࠺ࠢࠨ佄"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭佅"),block,re.DOTALL)
	for l1lllll_l1_,l1l1111_l1_ in items:
		url = l11l1l_l1_ + l1lllll_l1_
		name = l11ll1_l1_ (u"ࠨืไัฮࠦࠧ但") + l1l1111_l1_
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ佇"),l111l1_l1_+name,url,32)
	return
def PLAY(url):
	if l11ll1_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ佈") in url:
		url = l11l1l_l1_ + l11ll1_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࡹ࠵࠴ࡹࡥࡳ࡫ࡨࡷࡑ࡯࡮࡬࠱ࠪ佉") + url.split(l11ll1_l1_ (u"ࠬ࠵ࠧ佊"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ佋"),url,l11ll1_l1_ (u"ࠧࠨ佌"),headers,l11ll1_l1_ (u"ࠨࠩ位"),l11ll1_l1_ (u"ࠩࠪ低"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ住"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ佐"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11ll1_l1_ (u"ࠬࡢ࠯ࠨ佑"),l11ll1_l1_ (u"࠭࠯ࠨ佒"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ体"),url,l11ll1_l1_ (u"ࠨࠩ佔"),headers,l11ll1_l1_ (u"ࠩࠪ何"),l11ll1_l1_ (u"ࠪࠫ佖"),l11ll1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ佗"))
		html = response.content
		items = re.findall(l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡒࡍࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ佘"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ余"))
	return
def SEARCH(search,l1l1111_l1_=l11ll1_l1_ (u"ࠧࠨ佚")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1111ll_l1_ = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ佛"),l11ll1_l1_ (u"ࠩࠨ࠶࠵࠭作"))
	l1l1lllll_l1_ = [l11ll1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ佝"),l11ll1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ佞")]
	if not l1l1111_l1_: l1l1111_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ佟")
	else: l1l1111_l1_,type = l1l1111_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ你"))
	if l1ll_l1_:
		l1l11l11l_l1_ = [ l11ll1_l1_ (u"ࠧษฯฮࠤ฾์ࠠศใ็ห๊࠭佡") , l11ll1_l1_ (u"ࠨสะฯࠥ฿ๆࠡ็ึุ่๊วหࠩ佢")]
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦ࠭ࠡษัฮึࠦวๅสะฯࠬ佣"), l1l11l11l_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lllll_l1_[l1l_l1_]
	else:
		if l11ll1_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࡢࠫ佤") in options: type = l11ll1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ佥")
		elif l11ll1_l1_ (u"ࠬࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭佦") in options: type = l11ll1_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭佧")
		else: return
	headers[l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭佨")] = l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ佩")
	data = {l11ll1_l1_ (u"ࠩࡴࡹࡪࡸࡹࠨ佪"):l1111ll_l1_ , l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡇࡳࡲࡧࡩ࡯ࠩ佫"):type}
	if l1l1111_l1_!=l11ll1_l1_ (u"ࠫ࠶࠭佬"): data[l11ll1_l1_ (u"ࠬ࡬ࡲࡰ࡯ࠪ佭")] = l1l1111_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ佮"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ佯"),data,headers,l11ll1_l1_ (u"ࠨࠩ佰"),l11ll1_l1_ (u"ࠩࠪ佱"),l11ll1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭佲"))
	html = response.content
	items=re.findall(l11ll1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ佳"),html,re.DOTALL)
	if items:
		for title,l1lllll_l1_ in items:
			url = l11l1l_l1_ + l1lllll_l1_.replace(l11ll1_l1_ (u"ࠬࡢ࠯ࠨ佴"),l11ll1_l1_ (u"࠭࠯ࠨ併"))
			if l11ll1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ佶") in url: addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ佷"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎้๋ࠠࠨ佸")+title,url,33)
			elif l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ佹") in url:
				url = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭佺"),l11ll1_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࠫ佻"))
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭佼"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้ࠦࠧ佽")+title,url+l11ll1_l1_ (u"ࠨ࠱࠴ࠫ佾"),32)
	count=re.findall(l11ll1_l1_ (u"ࠩࠥࡸࡴࡺࡡ࡭ࠤ࠽ࠬ࠳࠰࠿ࠪࡿࠪ使"),html,re.DOTALL)
	if count:
		l1l1l1lll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll111ll_l1_ in range(1,l1l1l1lll_l1_):
			l1ll111ll_l1_ = str(l1ll111ll_l1_)
			if l1ll111ll_l1_!=l1l1111_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侀"),l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ侁")+l1ll111ll_l1_,l11ll1_l1_ (u"ࠬ࠭侂"),39,l11ll1_l1_ (u"࠭ࠧ侃"),l1ll111ll_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩ侄")+type,search)
	return
def l1l1ll1ll_l1_():
	l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡣࡋࡖ࠵ࡩࡄࡰࡸࡏ࠶ࡩࢀࡤࡉࡌ࡯࡝࡜࠶࠰ࡍࡰࡅ࡬ࡧࡳࡖ࠱ࡎࡰࡒࡻࡒ࡭࡭ࡵࡏ࠶࡛ࡱ࡚࠳ࡘࡩ࡝࡜ࡐࡹࡍ࠴࡫࡬ࡧࡍࡆࡖࡘ࡬࠽ࡼࡨࡇࡇ࠷ࡥࡋࡱࢀࡤࡄ࠷ࡷࡑ࠸࡛࠴ࠨ侅")
	l1lllll_l1_ = base64.b64decode(l1lllll_l1_)
	l1lllll_l1_ = l1lllll_l1_.decode(l11ll1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ來"))
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ侇"))
	return
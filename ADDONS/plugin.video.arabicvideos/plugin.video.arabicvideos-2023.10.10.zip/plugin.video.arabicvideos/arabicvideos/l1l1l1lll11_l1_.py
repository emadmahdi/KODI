# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭〱")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡑࡒࡃࡡࠪ〲")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ〳"):l11ll1_l1_ (u"࠭ࠧ〴")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l11111_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ〵"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ〶"),l11ll1_l1_ (u"ࠩࠪ〷"),329,l11ll1_l1_ (u"ࠪࠫ〸"),l11ll1_l1_ (u"ࠫࠬ〹"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ〺"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ〻"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〼"),l11ll1_l1_ (u"ࠨࠩ〽"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭〾"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ〿"),l11ll1_l1_ (u"ࠫࠬ぀"),headers,l11ll1_l1_ (u"ࠬ࠭ぁ"),l11ll1_l1_ (u"࠭ࠧあ"),l11ll1_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬぃ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡦࡳࡳࡵ࠭ࡱ࡮ࡸࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩい"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨぅ"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title==l11ll1_l1_ (u"ࠪห้๋ใหสฬࠤฬ๊ๅาศํอࠬう"): continue
		l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫぇ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧえ")+l111l1_l1_+title,l1lllll_l1_,321)
	return html
def l11111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧぉ"),l11ll1_l1_ (u"ࠧࠨお"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬか"),url,l11ll1_l1_ (u"ࠩࠪが"),headers,l11ll1_l1_ (u"ࠪࠫき"),l11ll1_l1_ (u"ࠫࠬぎ"),l11ll1_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬく"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧぐ"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡳࡨ࠺ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࡬࠸࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪけ"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨげ"),block,re.DOTALL)
	for l1lllll_l1_,l1lll1_l1_,count,title in items:
		count = count.replace(l11ll1_l1_ (u"ࠩ฼ำิࠦࠧこ"),l11ll1_l1_ (u"ࠪࠫご")).replace(l11ll1_l1_ (u"ࠫࠥ࠭さ"),l11ll1_l1_ (u"ࠬ࠭ざ"))
		l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࠯ࠨし"),l11ll1_l1_ (u"ࠧࠨじ"))
		l1lll1_l1_ = l1lll1_l1_.replace(l11ll1_l1_ (u"ࠣࠩࠥす"),l11ll1_l1_ (u"ࠩࠪず"))
		if l11ll1_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨせ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧぜ")+l1lllll_l1_
		l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧそ")+l1lllll_l1_
		l1lll1_l1_ = l11l1l_l1_+l1lll1_l1_
		title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨぞ"))
		title = title+l11ll1_l1_ (u"ࠧࠡࠪࠪた")+count+l11ll1_l1_ (u"ࠨࠫࠪだ")
		if l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬち") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪぢ"),l111l1_l1_+title,l1lllll_l1_,321,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠫࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧっ") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫつ"),l111l1_l1_+title,l1lllll_l1_,322,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧづ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭て"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬで")+l1lllll_l1_
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩと"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩど")+title,l1lllll_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨな"),url,l11ll1_l1_ (u"ࠬ࠭に"),headers,l11ll1_l1_ (u"࠭ࠧぬ"),l11ll1_l1_ (u"ࠧࠨね"),l11ll1_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭の"))
	html = response.content
	#l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡥࡺࡪࡩࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩは"),html,re.DOTALL)
	#if not l1lllll_l1_:
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪば"),html,re.DOTALL)
	l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_[0]#+l11ll1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪぱ")+l11llllll_l1_()+l11ll1_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡸࡷࡻࡥࠨひ")
	PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬび"))
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"ࠧๆะอหึ࠭ぴ")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩふ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪぶ"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬぷ"),l11ll1_l1_ (u"ࠫ࠰࠭へ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭べ")+search
	l11111_l1_(url)
	return
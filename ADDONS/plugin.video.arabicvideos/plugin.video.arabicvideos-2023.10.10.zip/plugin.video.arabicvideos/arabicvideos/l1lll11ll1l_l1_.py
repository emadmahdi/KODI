# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬ⭖")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡉࡏࡗࡤ࠭⭗")
def MAIN(mode,url,text,l1l1111_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll11l11l1_l1_(text)
	elif mode==542: results = l1ll1111ll1_l1_(text,url,l1l1111_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭘"),l11ll1_l1_ (u"ࠩหัะࠦฬะ์าࠫ⭙"),l11ll1_l1_ (u"ࠪࠫ⭚"),549)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⭛"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ๊ิา็หࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭜"),l11ll1_l1_ (u"࠭ࠧ⭝"),9999)
	l1ll111ll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⭞"),l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⭟"))
	if l1ll111ll1l_l1_:
		l1ll111ll1l_l1_ = l1ll111ll1l_l1_[l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⭠")]
		for search in reversed(l1ll111ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭡"),search,l11ll1_l1_ (u"ࠫࠬ⭢"),549,l11ll1_l1_ (u"ࠬ࠭⭣"),l11ll1_l1_ (u"࠭ࠧ⭤"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll1l11l1_l1_ = search.replace(l111l1_l1_,l11ll1_l1_ (u"ࠧࠨ⭥"))
	l1l1llllll1_l1_(l1lll1l11l1_l1_)
	#l1l1llll11l_l1_ = search+options+l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⭦")
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⭧"),l11ll1_l1_ (u"ࠪ฽๊๊ࠠษฯฮࠤั๋วฺ์ࠣ࠱ࠥ࠭⭨")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪ⭩"),542,l11ll1_l1_ (u"ࠬ࠭⭪"),l11ll1_l1_ (u"࠭ࠧ⭫"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⭬"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭭"),l11ll1_l1_ (u"ࠩࠪ⭮"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭯"),l11ll1_l1_ (u"๋ࠫะววฮࠣห้ฮอฬ่ࠢๅฺ๊ษࠡ࠯ࠣࠫ⭰")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⭱"),542,l11ll1_l1_ (u"࠭ࠧ⭲"),l11ll1_l1_ (u"ࠧࠨ⭳"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭴"),l11ll1_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆไึ้ฮࠦ࠭ࠡࠩ⭵")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⭶"),542,l11ll1_l1_ (u"ࠫࠬ⭷"),l11ll1_l1_ (u"ࠬ࠭⭸"),l1lll1l11l1_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭹"),l11ll1_l1_ (u"ࠧษฯฮࠤ๊์แาัࠣ࠱ࠥ࠭⭺")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩ⭻"),541,l11ll1_l1_ (u"ࠩࠪ⭼"),l11ll1_l1_ (u"ࠪࠫ⭽"),l1lll1l11l1_l1_)
	return
def l1l1llllll1_l1_(l1ll11l1lll_l1_):
	l1ll11ll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⭾"),l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⭿"),l1ll11l1lll_l1_)
	l1ll11ll111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ⮀"),l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮁"),l111l1_l1_+l1ll11l1lll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮂"),l1ll11l1lll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮃"),l111l1_l1_+l1ll11l1lll_l1_)
	old_value = l1ll11ll11l_l1_+l1ll11ll111_l1_
	if old_value: l1ll11l1lll_l1_ = l111l1_l1_+l1ll11l1lll_l1_
	WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮄"),l1ll11l1lll_l1_,old_value,VERYLONG_CACHE)
	return
def l1ll11111l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ⮅"),l11ll1_l1_ (u"ࠬ࠭⮆"),l11ll1_l1_ (u"࠭ࠧ⮇"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⮈"),l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬ⮉"))
	if l1ll111ll1_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮊"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩ⮋"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⮌"))
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭⮍"),l11ll1_l1_ (u"࠭ࠧ⮎"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⮏"),l11ll1_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำࠠอ็ํ฽้ࠥไๆษอࠤฬ๊ศฮอࠣห้๋ฮำ่ฬࠤๆ๐ࠠศๆหี๋อๅอࠩ⮐"))
	return
def l1ll1111ll1_l1_(l1ll11111ll_l1_,action,l1ll111l111_l1_=l11ll1_l1_ (u"ࠩࠪ⮑")):
	l1ll111l11l_l1_,l1ll111l1l1_l1_,l1ll111llll_l1_,l1l1lll1lll_l1_,l1l1llll1l1_l1_,l1ll111lll1_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ⮒"):
		if action==l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⮓"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠬࡲࡩࡴࡶࠪ⮔"),l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮕"),l111l1_l1_+l1ll11111ll_l1_)
		elif action==l11ll1_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮖"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮗"),l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡑࡓࡉࡓࡋࡄࠨ⮘"),l1ll11111ll_l1_)
		elif action==l11ll1_l1_ (u"ࠪࡧࡱࡵࡳࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮙"): l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮚"),l11ll1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡈࡒࡏࡔࡇࡇࠫ⮛"),(l1ll111l111_l1_,l1ll11111ll_l1_))
	if not l1ll111llll_l1_:
		l1ll11l11ll_l1_ = l11ll1_l1_ (u"࠭็ัษࠣห้ฮอฬࠢ฽๎ึࠦๅ้ฮ๋ำࠥ็๊ࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲࡡࡴࠧ⮜")
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦวๅสะฯࠥ็๊ࠡฮ่๎฾ࠦวๅ็๋ห็฿ฺ่ࠠࠣࡠࡳࠦࠢ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣࠫ⮝")+l1ll11111ll_l1_+l11ll1_l1_ (u"ࠨࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࠥࡢ࡮ࠡ฻็้ฬࠦร็๊ࠢิฬࠦวๅสะฯ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠪ⮞")
		if action==l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⮟"): message = l1ll11l1l11_l1_
		else: message = l1ll11l11ll_l1_+l1ll11l1l11_l1_
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ⮠"),l11ll1_l1_ (u"ࠫࠬ⮡"),l11ll1_l1_ (u"ࠬ࠭⮢"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⮣"),message)
		if l1ll111ll1_l1_!=1: return
		LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ⮤"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡘ࡫ࡡࡳࡥ࡫ࠤࡋࡵࡲ࠻ࠢ࡞ࠤࠬ⮥")+l1ll11111ll_l1_+l11ll1_l1_ (u"ࠩࠣࡡࠬ⮦"))
		#global menuItemsLIST
		import threading
		#l1ll111ll11_l1_ = [l11ll1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ⮧"),l11ll1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭⮨"),l11ll1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭⮩")]
		l1ll11llll1_l1_ = 1
		for l1ll111l111_l1_ in l1ll111ll11_l1_:
			l1l1lll1lll_l1_[l1ll111l111_l1_] = []
			options = l11ll1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ⮪")
			if l11ll1_l1_ (u"ࠧ࠮ࠩ⮫") in l1ll111l111_l1_: options = options+l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤ࠭⮬")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠩࡢࠫ⮭")
			l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
			if l1ll11llll1_l1_:
				threads[l1ll111l111_l1_] = threading.Thread(target=l1ll1111lll_l1_,args=(l1ll11111ll_l1_+options,))
				threads[l1ll111l111_l1_].start()
			else: l1ll1111lll_l1_(l1ll11111ll_l1_+options)
			DIALOG_NOTIFICATION(TRANSLATE(l1ll111l111_l1_),l11ll1_l1_ (u"ࠪࠫ⮮"),time=1000)
		if l1ll11llll1_l1_:
			time.sleep(2)
			for l1ll111l111_l1_ in l1ll111ll11_l1_:
				threads[l1ll111l111_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ⮯"),l11ll1_l1_ (u"ࠬ࠭⮰"),l11ll1_l1_ (u"࠭ࡩࡵࡧࡰࡷࠥ࡬࡯ࡶࡰࡧࡩࡩࡀࠧ⮱"),str(len(menuItemsLIST)))
		for l1ll111l111_l1_ in l1ll111ll11_l1_:
			l1l1lllllll_l1_,l1ll1111lll_l1_,l1ll11lll1l_l1_ = l1l1llll1ll_l1_(l1ll111l111_l1_)
			for l1ll1111l1l_l1_ in menuItemsLIST:
				type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ = l1ll1111l1l_l1_
				if l1ll11lll1l_l1_ in name:
					if l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲࠭⮲") in l1ll111l111_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⮳")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⮴")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⮵")]: continue
						if l11ll1_l1_ (u"ฺࠫ็อสࠩ⮶") not in name:
							if   type==l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ⮷"): l1ll111l111_l1_ = l11ll1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⮸")
							elif type==l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⮹"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⮺")
							elif type==l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮻"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⮼")
						else:
							if   l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ⮽") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⮾")
							elif l11ll1_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭⮿") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⯀")
							elif l11ll1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ⯁") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯂")
					elif l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࠨ⯃") in l1ll111l111_l1_ and 729>=mode>=710:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭⯄")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯅")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ⯆")]: continue
						if l11ll1_l1_ (u"ࠧึใะอࠬ⯇") not in name:
							if   type==l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⯈"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ⯉")
							elif type==l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⯊"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⯋")
							elif type==l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯌"): l1ll111l111_l1_ = l11ll1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ⯍")
						else:
							if   l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ⯎") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⯏")
							elif l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ⯐") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯑")
							elif l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ⯒") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⯓")
					elif l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࠨ⯔") in l1ll111l111_l1_ and 149>=mode>=140:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯕")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯖")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ⯗")]: continue
						if l11ll1_l1_ (u"ูࠪๆำษࠡลัี๎࠭⯘") in name or l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ⯙") in name:
							continue
							#if   l111_l1_==l11ll1_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯚"): l1ll111l111_l1_ = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯛")
							#elif l111_l1_==l11ll1_l1_ (u"ࠧࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯜"): l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯝")
							#else: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ⯞")
						else:
							if   mode==144 and l11ll1_l1_ (u"࡙ࠪࡘࡋࡒࠨ⯟") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯠")
							elif mode==144 and l11ll1_l1_ (u"ࠬࡉࡈࡏࡎࠪ⯡") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯢")
							elif mode==144 and l11ll1_l1_ (u"ࠧࡍࡋࡖࡘࠬ⯣") in name: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯤")
							elif mode==143: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ⯥")
							else: continue
					elif l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࠩ⯦") in l1ll111l111_l1_ and 419>=mode>=400:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯧")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯨")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ⯩")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ⯪")]: continue
						if   mode in [401,405]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯫")
						elif mode in [402,406]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯬")
						elif mode in [403,404]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ⯭")
						elif mode in [412,413]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩ⯮")
					elif l11ll1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࠬ⯯") in l1ll111l111_l1_ and 39>=mode>=30:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ⯰")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭⯱")]: continue
						if   mode in [32,39]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯲")
						elif mode in [33,39]: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⯳")
					elif l11ll1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࠪ⯴") in l1ll111l111_l1_ and 29>=mode>=20:
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⯵")]: continue
						if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l11ll1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⯶")]: continue
						if   l11ll1_l1_ (u"࠭࠯ࡢࡴ࠱ࠫ⯷") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭⯸")
						elif l11ll1_l1_ (u"ࠨ࠱ࡨࡲ࠳࠭⯹") in url: l1ll111l111_l1_ = l11ll1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⯺")
					#elif l11ll1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࠧ⯻") in l1ll111l111_l1_ and 319>=mode>=310:
					#	if l1ll1111l1l_l1_ in l1l1lll1lll_l1_[l1ll111l111_l1_]: continue
					#	if mode==312: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"ࠫ࠲ࡇࡕࡅࡋࡒࡗࠬ⯼")
					#	elif l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶ࠰ࠫ⯽") in url: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"࠭࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ⯾")
					#	else: l1ll111l111_l1_ = l1ll1111111_l1_+l11ll1_l1_ (u"ࠧ࠮ࡒࡈࡖࡘࡕࡎࡔࠩ⯿")
					l1l1lll1lll_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
		menuItemsLIST[:] = []
		for l1ll111l111_l1_ in list(l1l1lll1lll_l1_.keys()):
			l1l1llll1l1_l1_[l1ll111l111_l1_] = []
			l1ll111lll1_l1_[l1ll111l111_l1_] = []
			for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ in l1l1lll1lll_l1_[l1ll111l111_l1_]:
				l1ll1111l1l_l1_ = (type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_)
				if l11ll1_l1_ (u"ࠨืไัฮ࠭Ⰰ") in name and type==l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰁ"): l1ll111lll1_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
				else: l1l1llll1l1_l1_[l1ll111l111_l1_].append(l1ll1111l1l_l1_)
		l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰂ"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰃ"),l11ll1_l1_ (u"ࠬ࠭Ⰴ"),157,l11ll1_l1_ (u"࠭ࠧⰅ"),l11ll1_l1_ (u"ࠧࠨⰆ"),l11ll1_l1_ (u"ࠨࠩⰇ"),l11ll1_l1_ (u"ࠩࠪⰈ"),l11ll1_l1_ (u"ࠪࠫⰉ"))]
		for l1ll111l111_l1_ in l1ll111l1ll_l1_:
			if l1ll111l111_l1_==l1ll111111l_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰊ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰋ"),l11ll1_l1_ (u"࠭ࠧⰌ"),157,l11ll1_l1_ (u"ࠧࠨⰍ"),l11ll1_l1_ (u"ࠨࠩⰎ"),l11ll1_l1_ (u"ࠩࠪⰏ"),l11ll1_l1_ (u"ࠪࠫⰐ"),l11ll1_l1_ (u"ࠫࠬⰑ"))]
			elif l1ll111l111_l1_==l1ll11ll1l1_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⰒ"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⰓ"),l11ll1_l1_ (u"ࠧࠨⰔ"),157,l11ll1_l1_ (u"ࠨࠩⰕ"),l11ll1_l1_ (u"ࠩࠪⰖ"),l11ll1_l1_ (u"ࠪࠫⰗ"),l11ll1_l1_ (u"ࠫࠬⰘ"),l11ll1_l1_ (u"ࠬ࠭Ⱉ"))]
			elif l1ll111l111_l1_==l1l1llll111_l1_[0]: l1ll11l111l_l1_ = [(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰚ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰛ"),l11ll1_l1_ (u"ࠨࠩⰜ"),157,l11ll1_l1_ (u"ࠩࠪⰝ"),l11ll1_l1_ (u"ࠪࠫⰞ"),l11ll1_l1_ (u"ࠫࠬⰟ"),l11ll1_l1_ (u"ࠬ࠭Ⱐ"),l11ll1_l1_ (u"࠭ࠧⰡ"))]
			if l1ll111l111_l1_ not in l1l1llll1l1_l1_.keys(): continue
			if l1l1llll1l1_l1_[l1ll111l111_l1_]:
				l1l1lllll1l_l1_ = TRANSLATE(l1ll111l111_l1_)
				l1ll1111l11_l1_ = [(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰢ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࡁࡂࡃ࠽࠾ࠢࠪⰣ")+l1l1lllll1l_l1_+l11ll1_l1_ (u"ࠩࠣࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰤ"),l11ll1_l1_ (u"ࠪࠫⰥ"),9999,l11ll1_l1_ (u"ࠫࠬⰦ"),l11ll1_l1_ (u"ࠬ࠭Ⱗ"),l11ll1_l1_ (u"࠭ࠧⰨ"),l11ll1_l1_ (u"ࠧࠨⰩ"),l11ll1_l1_ (u"ࠨࠩⰪ"))]
				if 0:
					l1ll11ll1ll_l1_ = l1ll11111ll_l1_+l11ll1_l1_ (u"ࠩࠣ࠱ࠥ࠭Ⱛ")+l11ll1_l1_ (u"ࠪฬาัࠧⰬ")+l11ll1_l1_ (u"ࠫࠥ࠭Ⱝ")+l1l1lllll1l_l1_
				else:
					l1ll11ll1ll_l1_ = l11ll1_l1_ (u"ࠬฮอฬࠩⰮ")+l11ll1_l1_ (u"࠭ࠠࠨⰯ")+l1l1lllll1l_l1_+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫⰰ")+l1ll11111ll_l1_
				if len(l1l1llll1l1_l1_[l1ll111l111_l1_])<8: l1ll11l1111_l1_ = []
				else:
					l1ll11lll11_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫⰱ")+l1ll11ll1ll_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰲ")
					l1ll11l1111_l1_ = [(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰳ"),l111l1_l1_+l1ll11lll11_l1_,l11ll1_l1_ (u"ࠫࡨࡲ࡯ࡴࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⰴ"),542,l11ll1_l1_ (u"ࠬ࠭ⰵ"),l1ll111l111_l1_,l1ll11111ll_l1_,l11ll1_l1_ (u"࠭ࠧⰶ"),l11ll1_l1_ (u"ࠧࠨⰷ"))]
				l1ll11l1l1l_l1_ = l1l1llll1l1_l1_[l1ll111l111_l1_]+l1ll111lll1_l1_[l1ll111l111_l1_]
				l1ll111l1l1_l1_ += l1ll11l111l_l1_+l1ll1111l11_l1_+l1ll11l1l1l_l1_[:7]+l1ll11l1111_l1_
				l1l1lllll11_l1_ = [(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰸ"),l111l1_l1_+l1ll11ll1ll_l1_,l11ll1_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨⰹ"),542,l11ll1_l1_ (u"ࠪࠫⰺ"),l1ll111l111_l1_,l1ll11111ll_l1_,l11ll1_l1_ (u"ࠫࠬⰻ"),l11ll1_l1_ (u"ࠬ࠭ⰼ"))]
				l1ll111l11l_l1_ += l1ll11l111l_l1_+l1l1lllll11_l1_
				l1ll11l111l_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡉࡌࡐࡕࡈࡈࠬⰽ"),(l1ll111l111_l1_,l1ll11111ll_l1_),l1ll11l1l1l_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭ⰾ"),l1ll11111ll_l1_,l1ll111l1l1_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭ⰿ"),l1ll11111ll_l1_)
		WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧⱀ"),l111l1_l1_+l1ll11111ll_l1_,l1ll111l11l_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫⱁ"),l11ll1_l1_ (u"ࠫࠬⱂ"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨⱃ"),l11ll1_l1_ (u"࠭วๅสะฯࠥอไอ็ส฽๏ࠦว็ฬ๊ํࠥฮๆอษะࠤࡡࡴ࡜࡯ࠢอ้ࠥะฮำ์้ࠤฬ๊ๆหษษะࠥ็๊ࠡๅสุࠥอไษำ้ห๊าࠠๅ็าอࠥัไศอํ๊ࠥ๐่ๆࠢ็็๏ࠦสิฬฺ๎฾ࠦวๅ฻๋ำฮࠦลๅ์๊หࠥฮฯ้่ࠣ฽๊๊ࠠษฯฮࠤัี๊ะࠩⱄ"))
		if action==l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱅ") and l1ll111l11l_l1_: l1ll111llll_l1_ = l1ll111l11l_l1_
		else: l1ll111llll_l1_ = l1ll111l1l1_l1_
	if action!=l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧⱆ"):
		for type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_ in l1ll111llll_l1_:
			if action in [l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨⱇ"),l11ll1_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⱈ")] and l11ll1_l1_ (u"ฺࠫ็อสࠩⱉ") in name and type==l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱊ"): continue
			addMenuItem(type,name,url,mode,l111_l1_,l1l1111_l1_,text,context,l1ll1ll1l11_l1_)
	return
def l1ll11l11l1_l1_(l1ll11111ll_l1_=l11ll1_l1_ (u"࠭ࠧⱋ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11ll1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧⱌ"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡘ࡫ࡡࡳࡥ࡫ࠤࡋࡵࡲ࠻ࠢ࡞ࠤࠬⱍ")+search+l11ll1_l1_ (u"ࠩࠣࡡࠬⱎ"))
	l1111ll_l1_ = search+options
	if 0:
		l1ll11l1ll1_l1_,l1lll1l11l1_l1_ = search+l11ll1_l1_ (u"ࠪࠤ࠲ࠦࠧⱏ"),l11ll1_l1_ (u"ࠫࠬⱐ")
	else:
		l1ll11l1ll1_l1_,l1lll1l11l1_l1_ = l11ll1_l1_ (u"ࠬ࠭ⱑ"),l11ll1_l1_ (u"࠭ࠠ࠮ࠢࠪⱒ")+search
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⱓ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⱔ"),l11ll1_l1_ (u"ࠩࠪⱕ"),157)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱖ"),l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪⱗ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢࡐ࠷࡚࠭ⱘ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⱙ"),719,l11ll1_l1_ (u"ࠧࠨⱚ"),l11ll1_l1_ (u"ࠨࠩⱛ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱜ"),l11ll1_l1_ (u"ࠪࡣࡎࡖࡔࡠࠩⱝ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡࡋࡓࡘ࡛࠭ⱞ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⱟ"),239,l11ll1_l1_ (u"࠭ࠧⱠ"),l11ll1_l1_ (u"ࠧࠨⱡ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱢ"),l11ll1_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨⱣ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥฮใาษࠪⱤ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⱥ"),379,l11ll1_l1_ (u"ࠬ࠭ⱦ"),l11ll1_l1_ (u"࠭ࠧⱧ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱨ"),l11ll1_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧⱩ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤออๆ๋ฬࠪⱪ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⱫ"),39,l11ll1_l1_ (u"ࠫࠬⱬ"),l11ll1_l1_ (u"ࠬ࠭Ɑ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ɱ"),l11ll1_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭Ɐ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨⱰ"),l11ll1_l1_ (u"ࠩࠪⱱ"),39,l11ll1_l1_ (u"ࠪࠫⱲ"),l11ll1_l1_ (u"ࠫࠬⱳ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࡡࠪⱴ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱶ"),l11ll1_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭ⱶ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬฬ์๊ห่ࠢืู้ไศฬࠪⱷ"),l11ll1_l1_ (u"ࠩࠪⱸ"),39,l11ll1_l1_ (u"ࠪࠫⱹ"),l11ll1_l1_ (u"ࠫࠬⱺ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࡡࠪⱻ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱼ"),l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭ⱽ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬⱾ"),l11ll1_l1_ (u"ࠩࠪⱿ"),149,l11ll1_l1_ (u"ࠪࠫⲀ"),l11ll1_l1_ (u"ࠫࠬⲁ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬⲂ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲃ"),l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭Ⲅ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩⲅ"),l11ll1_l1_ (u"ࠩࠪⲆ"),149,l11ll1_l1_ (u"ࠪࠫⲇ"),l11ll1_l1_ (u"ࠫࠬⲈ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨⲉ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲋ"),l11ll1_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭ⲋ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩⲌ"),l11ll1_l1_ (u"ࠩࠪⲍ"),149,l11ll1_l1_ (u"ࠪࠫⲎ"),l11ll1_l1_ (u"ࠫࠬⲏ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧⲐ"))
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l11ll1_l1_ (u"ࠧࡠࡍࡏࡅࡤ࠭Ⲓ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็้ࠦวๅ฻ิฬࠬⲓ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⲔ"),19,l11ll1_l1_ (u"ࠪࠫⲕ"),l11ll1_l1_ (u"ࠫࠬⲖ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲗ"),l11ll1_l1_ (u"࠭࡟ࡂࡔࡗࡣࠬⲘ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ⲙ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⲚ"),739,l11ll1_l1_ (u"ࠩࠪⲛ"),l11ll1_l1_ (u"ࠪࠫⲜ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲝ"),l11ll1_l1_ (u"ࠬࡥࡋࡓࡄࡢࠫⲞ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦใาส็หฦ࠭ⲟ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⲠ"),329,l11ll1_l1_ (u"ࠨࠩⲡ"),l11ll1_l1_ (u"ࠩࠪⲢ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲣ"),l11ll1_l1_ (u"ࠫࡤࡌࡈ࠲ࡡࠪⲤ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫⲥ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⲦ"),579,l11ll1_l1_ (u"ࠧࠨⲧ"),l11ll1_l1_ (u"ࠨࠩⲨ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲩ"),l11ll1_l1_ (u"ࠪࡣࡊࡍࡂࡠࠩⲪ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩⲫ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭Ⲭ"),129,l11ll1_l1_ (u"࠭ࠧⲭ"),l11ll1_l1_ (u"ࠧࠨⲮ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲯ"),l11ll1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨⲰ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪⲱ"),l11ll1_l1_ (u"ࠫࠬⲲ"),409,l11ll1_l1_ (u"ࠬ࠭ⲳ"),l11ll1_l1_ (u"࠭ࠧⲴ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࡢࠫⲵ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲶ"),l11ll1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨⲷ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧⲸ"),l11ll1_l1_ (u"ࠫࠬⲹ"),409,l11ll1_l1_ (u"ࠬ࠭Ⲻ"),l11ll1_l1_ (u"࠭ࠧⲻ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧⲼ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲽ"),l11ll1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨⲾ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧⲿ"),l11ll1_l1_ (u"ࠫࠬⳀ"),409,l11ll1_l1_ (u"ࠬ࠭ⳁ"),l11ll1_l1_ (u"࠭ࠧⳂ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭ⳃ"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳄ"),l11ll1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨⳅ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪࠤࠥฮอฬ่ࠢ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭Ⳇ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫࠥࠦࠧⳇ"),l11ll1_l1_ (u"ࠬ࠭Ⳉ"),29,l11ll1_l1_ (u"࠭ࠧⳉ"),l11ll1_l1_ (u"ࠧࠨⳊ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳋ"),l11ll1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨⳌ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩⳍ"),l11ll1_l1_ (u"ࠫࠬⳎ"),29,l11ll1_l1_ (u"ࠬ࠭ⳏ"),l11ll1_l1_ (u"࠭ࠧⳐ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࡣࠬⳑ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳒ"),l11ll1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨⳓ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬⳔ"),l11ll1_l1_ (u"ࠫࠬⳕ"),29,l11ll1_l1_ (u"ࠬ࠭Ⳗ"),l11ll1_l1_ (u"࠭ࠧⳗ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࡤ࠭Ⳙ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳙ"),l11ll1_l1_ (u"ࠩࡢࡅࡐࡕ࡟ࠨⳚ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫⳛ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⳜ"),79,l11ll1_l1_ (u"ࠬ࠭ⳝ"),l11ll1_l1_ (u"࠭ࠧⳞ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳟ"),l11ll1_l1_ (u"ࠨࡡࡄࡏ࡜ࡥࠧⳠ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪⳡ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⳢ"),249,l11ll1_l1_ (u"ࠫࠬⳣ"),l11ll1_l1_ (u"ࠬ࠭ⳤ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳥"),l11ll1_l1_ (u"ࠧࡠࡏࡕࡊࠬ⳦")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ⳧"),l11ll1_l1_ (u"ࠩࠪ⳨"),49,l11ll1_l1_ (u"ࠪࠫ⳩"),l11ll1_l1_ (u"ࠫࠬ⳪"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳫ"),l11ll1_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬⳬ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆࠦๅศๅึࠫⳭ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⳮ"),59,l11ll1_l1_ (u"ࠩࠪ⳯"),l11ll1_l1_ (u"ࠪࠫ⳰"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳱"),l11ll1_l1_ (u"ࠬࡥࡆࡕࡏࡢࠫⳲ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩⳳ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨ⳴"),69,l11ll1_l1_ (u"ࠨࠩ⳵"),l11ll1_l1_ (u"ࠩࠪ⳶"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳷"),l11ll1_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ⳸")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ⳹"),l11ll1_l1_ (u"࠭ࠧ⳺"),139,l11ll1_l1_ (u"ࠧࠨ⳻"),l11ll1_l1_ (u"ࠨࠩ⳼"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳽"),l11ll1_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ⳾")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪ⳿"),l11ll1_l1_ (u"ࠬ࠭ⴀ"),319,l11ll1_l1_ (u"࠭ࠧⴁ"),l11ll1_l1_ (u"ࠧࠨⴂ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴃ"),l11ll1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨⴄ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧⴅ"),l11ll1_l1_ (u"ࠫࠬⴆ"),319,l11ll1_l1_ (u"ࠬ࠭ⴇ"),l11ll1_l1_ (u"࠭ࠧⴈ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪⴉ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴊ"),l11ll1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨⴋ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูส่ࠢะ้ีࠧⴌ"),l11ll1_l1_ (u"ࠫࠬⴍ"),319,l11ll1_l1_ (u"ࠬ࠭ⴎ"),l11ll1_l1_ (u"࠭ࠧⴏ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩⴐ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴑ"),l11ll1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨⴒ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩⴓ"),l11ll1_l1_ (u"ࠫࠬⴔ"),319,l11ll1_l1_ (u"ࠬ࠭ⴕ"),l11ll1_l1_ (u"࠭ࠧⴖ"),l1111ll_l1_+l11ll1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࡠࠩⴗ"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴘ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⴙ"),l11ll1_l1_ (u"ࠪࠫⴚ"),157)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴛ"),l11ll1_l1_ (u"ࠬࡥࡋࡕࡍࡢࠫⴜ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅอ็ํะࠧⴝ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⴞ"),679,l11ll1_l1_ (u"ࠨࠩⴟ"),l11ll1_l1_ (u"ࠩࠪⴠ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴡ"),l11ll1_l1_ (u"ࠫࡤࡌࡊࡔࡡࠪⴢ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬࠦศฮอ้ࠣํู่ࠡใฯีฺ่ࠥࠨⴣ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ࠠࠨⴤ"),l11ll1_l1_ (u"ࠧࠨⴥ"),399,l11ll1_l1_ (u"ࠨࠩ⴦"),l11ll1_l1_ (u"ࠩࠪⴧ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l11ll1_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ⴩")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ⴪")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ⴫"),469,l11ll1_l1_ (u"ࠧࠨ⴬"),l11ll1_l1_ (u"ࠨࠩⴭ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l11ll1_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ⴯")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦไ้ัํࠤ๋ะࠧⴰ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⴱ"),459,l11ll1_l1_ (u"࠭ࠧⴲ"),l11ll1_l1_ (u"ࠧࠨⴳ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴴ"),l11ll1_l1_ (u"ࠩࡢࡇࡒࡔ࡟ࠨⴵ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧⴶ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⴷ"),309,l11ll1_l1_ (u"ࠬ࠭ⴸ"),l11ll1_l1_ (u"࠭ࠧⴹ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴺ"),l11ll1_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧⴻ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤํ๐ࠠิ์่หࠬⴼ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⴽ"),569,l11ll1_l1_ (u"ࠫࠬⴾ"),l11ll1_l1_ (u"ࠬ࠭ⴿ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵀ"),l11ll1_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭ⵁ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣฬํฯ่ࠡํ์ื࠭ⵂ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⵃ"),589,l11ll1_l1_ (u"ࠪࠫⵄ"),l11ll1_l1_ (u"ࠫࠬⵅ"),l1111ll_l1_+l11ll1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪⵆ"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵇ"),l11ll1_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭ⵈ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻้ࠣฬ๐ࠠิ์่หࠬⵉ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⵊ"),369,l11ll1_l1_ (u"ࠪࠫⵋ"),l11ll1_l1_ (u"ࠫࠬⵌ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵍ"),l11ll1_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬⵎ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆࠦศา๊ࠪⵏ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⵐ"),489,l11ll1_l1_ (u"ࠩࠪⵑ"),l11ll1_l1_ (u"ࠪࠫⵒ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵓ"),l11ll1_l1_ (u"ࠬࡥࡁࡓࡕࡢࠫⵔ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ฻ิฬู๊๋ࠥัࠪⵕ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⵖ"),259,l11ll1_l1_ (u"ࠨࠩⵗ"),l11ll1_l1_ (u"ࠩࠪⵘ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵙ"),l11ll1_l1_ (u"ࠫࡤࡉ࠴ࡖࡡࠪⵚ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็่า์๋ࠫⵛ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⵜ"),429,l11ll1_l1_ (u"ࠧࠨⵝ"),l11ll1_l1_ (u"ࠨࠩⵞ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵟ"),l11ll1_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩⵠ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪⵡ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⵢ"),119,l11ll1_l1_ (u"࠭ࠧⵣ"),l11ll1_l1_ (u"ࠧࠨⵤ"),l1111ll_l1_+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ⵥ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵦ"),l11ll1_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩⵧ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪ⵨"),l11ll1_l1_ (u"ࠬ࠭⵩"),389,l11ll1_l1_ (u"࠭ࠧ⵪"),l11ll1_l1_ (u"ࠧࠨ⵫"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵬"),l11ll1_l1_ (u"ࠩࡢࡉࡌ࡜࡟ࠨ⵭")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬ⵮"),l11ll1_l1_ (u"ࠫࠬⵯ"),229,l11ll1_l1_ (u"ࠬ࠭⵰"),l11ll1_l1_ (u"࠭ࠧ⵱"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⵲"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⵳"),l11ll1_l1_ (u"ࠩࠪ⵴"),157)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵵"),l11ll1_l1_ (u"ࠫࡤࡒࡒ࡛ࡡࠪ⵶")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๅษิ์ือࠧ⵷")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ⵸"),709,l11ll1_l1_ (u"ࠧࠨ⵹"),l11ll1_l1_ (u"ࠨࠩ⵺"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵻"),l11ll1_l1_ (u"ࠪࡣࡋ࡙ࡔࡠࠩ⵼")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแ้ีอหࠬ⵽")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭⵾"),609,l11ll1_l1_ (u"⵿࠭ࠧ"),l11ll1_l1_ (u"ࠧࠨⶀ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶁ"),l11ll1_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨⶂ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็ศาๅฬࠫⶃ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⶄ"),629,l11ll1_l1_ (u"ࠬ࠭ⶅ"),l11ll1_l1_ (u"࠭ࠧⶆ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶇ"),l11ll1_l1_ (u"ࠨࡡ࡜ࡕ࡙ࡥࠧⶈ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏อโ้ฬࠪⶉ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⶊ"),669,l11ll1_l1_ (u"ࠫࠬⶋ"),l11ll1_l1_ (u"ࠬ࠭ⶌ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶍ"),l11ll1_l1_ (u"ࠧࡠࡄࡕࡗࡤ࠭ⶎ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬึูส๋ฮࠪⶏ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⶐ"),659,l11ll1_l1_ (u"ࠪࠫⶑ"),l11ll1_l1_ (u"ࠫࠬⶒ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶓ"),l11ll1_l1_ (u"࠭࡟ࡉࡎࡆࡣࠬⶔ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๊่ࠢฬࠦำ๋็สࠫⶕ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⶖ"),89,l11ll1_l1_ (u"ࠩࠪ⶗"),l11ll1_l1_ (u"ࠪࠫ⶘"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⶙"),l11ll1_l1_ (u"ࠬࡥࡄࡓ࠹ࡢࠫ⶚")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัิห๊อࠠึฯࠪ⶛")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨ⶜"),689,l11ll1_l1_ (u"ࠨࠩ⶝"),l11ll1_l1_ (u"ࠩࠪ⶞"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶟"),l11ll1_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪⶠ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็ว็ิࠪⶡ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⶢ"),99,l11ll1_l1_ (u"ࠧࠨⶣ"),l11ll1_l1_ (u"ࠨࠩⶤ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶥ"),l11ll1_l1_ (u"ࠪࡣࡈࡓࡌࡠࠩⶦ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩ⶧")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⶨ"),479,l11ll1_l1_ (u"࠭ࠧⶩ"),l11ll1_l1_ (u"ࠧࠨⶪ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶫ"),l11ll1_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨⶬ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨⶭ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠫࠬⶮ"),559,l11ll1_l1_ (u"ࠬ࠭⶯"),l11ll1_l1_ (u"࠭ࠧⶰ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶱ"),l11ll1_l1_ (u"ࠨࡡࡆ࠸ࡍࡥࠧⶲ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭ⶳ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠪࠫⶴ"),699,l11ll1_l1_ (u"ࠫࠬⶵ"),l11ll1_l1_ (u"ࠬ࠭ⶶ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⶷"),l11ll1_l1_ (u"ࠧࡠࡃࡋࡏࡤ࠭ⶸ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧⶹ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠩࠪⶺ"),619,l11ll1_l1_ (u"ࠪࠫⶻ"),l11ll1_l1_ (u"ࠫࠬⶼ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶽ"),l11ll1_l1_ (u"࠭࡟ࡄࡅࡅࡣࠬⶾ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ⶿")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠨࠩⷀ"),639,l11ll1_l1_ (u"ࠩࠪⷁ"),l11ll1_l1_ (u"ࠪࠫⷂ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷃ"),l11ll1_l1_ (u"ࠬࡥࡓࡉࡖࡢࠫⷄ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬⷅ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨⷆ"),649,l11ll1_l1_ (u"ࠨࠩ⷇"),l11ll1_l1_ (u"ࠩࠪⷈ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷉ"),l11ll1_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪⷊ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩⷋ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧⷌ"),439,l11ll1_l1_ (u"ࠧࠨⷍ"),l11ll1_l1_ (u"ࠨࠩⷎ"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⷏"),l11ll1_l1_ (u"ࠪࡣࡋࡎ࠲ࡠࠩⷐ")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫⷑ")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠬ࠭ⷒ"),599,l11ll1_l1_ (u"࠭ࠧⷓ"),l11ll1_l1_ (u"ࠧࠨⷔ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷕ"),l11ll1_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨⷖ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧ⷗"),l11ll1_l1_ (u"ࠫࠬⷘ"),449,l11ll1_l1_ (u"ࠬ࠭ⷙ"),l11ll1_l1_ (u"࠭ࠧⷚ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷛ"),l11ll1_l1_ (u"ࠨࡡࡄࡏࡈࡥࠧⷜ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ้่ศ็ࠣ็ฬ๋ࠧⷝ"),l11ll1_l1_ (u"ࠪࠫⷞ"),359,l11ll1_l1_ (u"ࠫࠬ⷟"),l11ll1_l1_ (u"ࠬ࠭ⷠ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷡ"),l11ll1_l1_ (u"ࠧࡠࡅࡐࡇࡤ࠭ⷢ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๅ็์อ࠭ⷣ"),l11ll1_l1_ (u"ࠩࠪⷤ"),499,l11ll1_l1_ (u"ࠪࠫⷥ"),l11ll1_l1_ (u"ࠫࠬⷦ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷧ"),l11ll1_l1_ (u"࠭࡟ࡂࡔࡏࡣࠬⷨ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦไ๋๊้ึࠬⷩ"),l11ll1_l1_ (u"ࠨࠩⷪ"),209,l11ll1_l1_ (u"ࠩࠪⷫ"),l11ll1_l1_ (u"ࠪࠫⷬ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷭ"),l11ll1_l1_ (u"ࠬࡥࡈࡆࡎࡢࠫⷮ")+l1lll1l11l1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭ⷯ"),l11ll1_l1_ (u"ࠧࠨⷰ"),99,l11ll1_l1_ (u"ࠨࠩⷱ"),l11ll1_l1_ (u"ࠩࠪⷲ"),l1111ll_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷳ"),l11ll1_l1_ (u"ࠫࡤ࡙ࡆࡘࡡࠪⷴ")+search+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์ิ๎ุࠦแ้ำࠣ์ฯฺࠧⷵ"),l11ll1_l1_ (u"࠭ࠧⷶ"),218,l11ll1_l1_ (u"ࠧࠨⷷ"),l11ll1_l1_ (u"ࠨࠩⷸ"),search) # 219
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷹ"),l11ll1_l1_ (u"ࠪࡣࡒ࡜࡚ࡠࠩⷺ")+search+l11ll1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅ้ใํึ๊ࠥว็ัࠪⷻ"),l11ll1_l1_ (u"ࠬ࠭ⷼ"),188,l11ll1_l1_ (u"࠭ࠧⷽ"),l11ll1_l1_ (u"ࠧࠨⷾ"),search)# 189
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⷿ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⸀"),l11ll1_l1_ (u"ࠪࠫ⸁"),157)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸂"),l11ll1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ⸃")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠨ⸄")+l1lll1l11l1_l1_,l11ll1_l1_ (u"ࠧࠨ⸅"),149,l11ll1_l1_ (u"ࠨࠩ⸆"),l11ll1_l1_ (u"ࠩࠪ⸇"),l1111ll_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸈"),l11ll1_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ⸉")+l1ll11l1ll1_l1_+l11ll1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠪ⸊")+l1lll1l11l1_l1_,l11ll1_l1_ (u"࠭ࠧ⸋"),409,l11ll1_l1_ (u"ࠧࠨ⸌"),l11ll1_l1_ (u"ࠨࠩ⸍"),l1111ll_l1_)
	return
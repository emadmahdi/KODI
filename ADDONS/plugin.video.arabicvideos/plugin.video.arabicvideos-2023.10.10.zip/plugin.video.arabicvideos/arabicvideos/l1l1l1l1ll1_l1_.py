# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨぺ")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡍࡗࡏࡤ࠭ほ")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪぼ"),l11ll1_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪぽ"),l11ll1_l1_ (u"ࠪห้ษโิษ่ࠫま")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l11111_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l1llll1_l1_(url,text)
	elif mode==674: results = l1l111_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨみ"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭む"),l11ll1_l1_ (u"࠭ࠧめ"),l11ll1_l1_ (u"ࠧࠨも"),l11ll1_l1_ (u"ࠨࠩゃ"),l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭や"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪゅ"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫゆ"),l11ll1_l1_ (u"ࠬ࠭ょ"),679,l11ll1_l1_ (u"࠭ࠧよ"),l11ll1_l1_ (u"ࠧࠨら"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬり"))
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧる"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪれ"),l11ll1_l1_ (u"ࠫࠬろ"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬゎ"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨわ")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่้๏ุษࠨゐ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠨࠩゑ"),l11ll1_l1_ (u"ࠩࠪを"),l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬん"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫゔ"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧゕ")+l111l1_l1_+l11ll1_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬゖ"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠧࠨ゗"),l11ll1_l1_ (u"ࠨࠩ゘"),l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ゙"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ゚ࠪ"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭゛")+l111l1_l1_+l11ll1_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ゜"),l11l1l_l1_,671,l11ll1_l1_ (u"࠭ࠧゝ"),l11ll1_l1_ (u"ࠧࠨゞ"),l11ll1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬゟ"))
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ゠"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬァ")+l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨア"),l11l1l_l1_,671,l11ll1_l1_ (u"ࠬ࠭ィ"),l11ll1_l1_ (u"࠭ࠧイ"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩゥ"))
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ウ"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩェ"),l11ll1_l1_ (u"ࠪࠫエ"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬォ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧオ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if title in l1l11l_l1_: continue
			if title==l11ll1_l1_ (u"࠭วๅลๅืฬ๋ࠧカ"): mode = 675
			else: mode = 674
			addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧガ"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪキ")+l111l1_l1_+title,l1lllll_l1_,mode)
	#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧギ"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪク"),l11ll1_l1_ (u"ࠫࠬグ"),9999)
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩケ"),html,re.DOTALL)
	#block = l1l1l11_l1_[0]
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦゲ"),html,re.DOTALL)
	#for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"ࠧࠨコ"))
	#items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ゴ"),block,re.DOTALL)
	#for l1lllll_l1_,title in items:
	#	if title in l1l11l_l1_: continue
	#	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩサ"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬザ")+l111l1_l1_+title,l1lllll_l1_,674)
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩシ"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬジ"),l11ll1_l1_ (u"࠭ࠧス"),9999)
	items = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡣࡴࡲࡻࡸ࡫࠮ࡩࡶࡰࡰࠬズ"))
	for l1lllll_l1_,l1lll1_l1_,title in items:
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨセ"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫゼ")+l111l1_l1_+title,l1lllll_l1_,674,l1lll1_l1_)
	return
def CATEGORIES(url):
	l1ll1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨソ"),l11ll1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭ゾ"),l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩタ"))
	if l1ll1l1111_l1_: return l1ll1l1111_l1_
	#DIALOG_OK()
	l1ll1l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪダ"),url,l11ll1_l1_ (u"ࠧࠨチ"),l11ll1_l1_ (u"ࠨࠩヂ"),l11ll1_l1_ (u"ࠩࠪッ"),l11ll1_l1_ (u"ࠪࠫツ"),l11ll1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠵ࡸࡺࠧヅ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡪࡨࡥࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸ࠾ࠨテ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1ll1l1111_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪデ"),block,re.DOTALL)
		if l1ll1l1111_l1_: WRITE_TO_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩト"),l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬド"),l1ll1l1111_l1_,l1llllll_l1_)
	return l1ll1l1111_l1_
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ナ"),url,l11ll1_l1_ (u"ࠪࠫニ"),l11ll1_l1_ (u"ࠫࠬヌ"),l11ll1_l1_ (u"ࠬ࠭ネ"),l11ll1_l1_ (u"࠭ࠧノ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧハ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬバ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪパ"),l11ll1_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩヒ"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨビ"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"ࠬ࠭ピ"),block)]
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫフ"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬブ"),l11ll1_l1_ (u"ࠨࠩプ"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧヘ"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭ベ")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫペ"),l111l1_l1_+title,l1lllll_l1_,671)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩホ"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨボ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬポ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨマ"),l11ll1_l1_ (u"ࠩࠪミ"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪム"),l111l1_l1_+title,l1lllll_l1_,671)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠫࠬメ")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭モ"),l11ll1_l1_ (u"࠭ࠧャ"),request,url)
	if request==l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬヤ"):
		url,search = url.split(l11ll1_l1_ (u"ࠨࡁࠪュ"),1)
		data = l11ll1_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨユ")+search
		headers = {l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩョ"):l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫヨ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪラ"),url,data,headers,l11ll1_l1_ (u"࠭ࠧリ"),l11ll1_l1_ (u"ࠧࠨル"),l11ll1_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧレ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭ロ"),url,l11ll1_l1_ (u"ࠪࠫヮ"),l11ll1_l1_ (u"ࠫࠬワ"),l11ll1_l1_ (u"ࠬ࠭ヰ"),l11ll1_l1_ (u"࠭ࠧヱ"),l11ll1_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ヲ"))
	html = response.content
	block,items = l11ll1_l1_ (u"ࠨࠩン"),[]
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭ヴ"))
	if request==l11ll1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨヵ"):
		block = html
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ヶ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠬ࠭ヷ"),l1lllll_l1_,title))
	elif request==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨヸ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨヹ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧヺ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ・"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	elif request==l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧー"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫヽ"),html,re.DOTALL)
		if len(l1l1l11_l1_)>1: block = l1l1l11_l1_[1]
	elif request==l11ll1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧヾ"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨヿ"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		l1l1l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㄀"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1l1l_l1_: items.append((l11ll1_l1_ (u"ࠨࠩ㄁"),l1lllll_l1_,title))
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㄂"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
	if block and not items: items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㄃"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ฺ๊ࠫว่ัฬࠫ㄄"),l11ll1_l1_ (u"ࠬ็๊ๅ็ࠪㄅ"),l11ll1_l1_ (u"࠭ว฻่ํอࠬㄆ"),l11ll1_l1_ (u"ࠧไๆํฬࠬㄇ"),l11ll1_l1_ (u"ࠨษ฼่ฬ์ࠧㄈ"),l11ll1_l1_ (u"๊ࠩำฬ็ࠧㄉ"),l11ll1_l1_ (u"้ࠪออัศหࠪㄊ"),l11ll1_l1_ (u"ࠫ฾ืึࠨㄋ"),l11ll1_l1_ (u"๋ࠬ็าฮส๊ࠬㄌ"),l11ll1_l1_ (u"࠭วๅส๋้ࠬㄍ"),l11ll1_l1_ (u"ࠧๆีิั๏ฯࠧㄎ"),l11ll1_l1_ (u"ࠨใ็้ࠬㄏ")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		#l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠩ࠲ࠫㄐ"))
		#if l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨㄑ") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭ㄒ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧㄓ"))
		#if l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࠫㄔ") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠧ࠰ࠩㄕ")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠨ࠱ࠪㄖ"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠩࠣࠫㄗ"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ㄘ"),title,re.DOTALL)
		#addMenuItem(l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪㄙ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄚ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif request==l11ll1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬㄛ"):
			addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㄜ"),l111l1_l1_+title,l1lllll_l1_,672,l1lll1_l1_)
		elif l1ll1l1_l1_:
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧㄝ") + l1ll1l1_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄞ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨㄟ") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄠ"),l111l1_l1_+title,l1lllll_l1_,671,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄡ"),l111l1_l1_+title,l1lllll_l1_,673,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄢ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㄣ"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪㄤ"): continue
			if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧㄥ") not in l1lllll_l1_:
				l111lll_l1_ = url.rsplit(l11ll1_l1_ (u"ࠪ࠳ࠬㄦ"),1)[0]
				l1lllll_l1_ = l111lll_l1_+l11ll1_l1_ (u"ࠫ࠴࠭ㄧ")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧㄨ"))
			title = unescapeHTML(title)
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄩ"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭ㄪ")+title,l1lllll_l1_,671,l11ll1_l1_ (u"ࠨࠩㄫ"),l11ll1_l1_ (u"ࠩࠪㄬ"),request)
	return
def l1llll1_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫㄭ"),l11ll1_l1_ (u"ࠫࠬㄮ"),l1l1l_l1_,url)
	addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄯ"),l111l1_l1_+l11ll1_l1_ (u"࠭สี฼ํ่ࠥอไโ์า๎ํ࠭㄰"),url,672)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬㄱ"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨㄲ"),l11ll1_l1_ (u"ࠩࠪㄳ"),9999)
	l1ll1l1111_l1_ = CATEGORIES(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࡦࡷࡵࡷࡴࡧ࠱࡬ࡹࡳ࡬ࠨㄴ"))
	l1l1l1l1l1l_l1_,l1l1l1l1l11_l1_,l1l1l1ll1ll_l1_ = zip(*l1ll1l1111_l1_)
	l1l1l1l1lll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨㄵ"),url,l11ll1_l1_ (u"ࠬ࠭ㄶ"),l11ll1_l1_ (u"࠭ࠧㄷ"),l11ll1_l1_ (u"ࠧࠨㄸ"),l11ll1_l1_ (u"ࠨࠩㄹ"),l11ll1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪㄺ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰࡬ࡪࡧࡤࡪࡰࡪࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠧㄻ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡿࡂࡶࡶࡷࡳࡳࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㄼ"),block,re.DOTALL)
		for l1lllll_l1_,title in l1l1_l1_:
			if l1lllll_l1_ not in l1l1l1l1l1l_l1_:
				item = (l1lllll_l1_,title)
				l1l1l1l1lll_l1_.append(item)
		if len(l1l1l1l1lll_l1_)==1:
			l1lllll_l1_,title = l1l1l1l1lll_l1_[0]
			l11111_l1_(l1lllll_l1_,l11ll1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫㄽ"))
			return
		else:
			for l1lllll_l1_,title in l1l1l1l1lll_l1_:
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄾ"),l111l1_l1_+title,l1lllll_l1_,671,l11ll1_l1_ (u"ࠧࠨㄿ"),l11ll1_l1_ (u"ࠨࠩㅀ"),l11ll1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㅁ"))
	if not l1l1l1l1lll_l1_: l11111_l1_(url,l11ll1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㅂ"))
	return
#https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l11ll11ll1_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1l1l1ll11l_l1_
#https://www.l1l1l1ll111_l1_.com/l11l1l1ll_l1_/l1l111l1l_l1_.l1ll1lll1l_l1_?l1l1l1ll1l1_l1_=l1l1l1ll11l_l1_
def PLAY(url):
	l1llll11_l1_ = []
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭࠵แ๋ๆ่࠱่ืส้่࠰ฬฬืศ๋࠯ไ๎࠲ฺ๋ศ็ิอ࠲๋สๅล็สฮ࠳ๅะสࡢࡨ࠾࠽࠵ࡤࡤ࠺࠹࠸࠴ࡨࡵ࡯࡯ࠫㅃ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩㅄ"),url,l11ll1_l1_ (u"࠭ࠧㅅ"),l11ll1_l1_ (u"ࠧࠨㅆ"),l11ll1_l1_ (u"ࠨࠩㅇ"),l11ll1_l1_ (u"ࠩࠪㅈ"),l11ll1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧㅉ"))
	html = response.content
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬࡪࡱࡧࡳࡩࡲ࡯ࡥࡾ࡫ࡲࠨㅊ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅋ"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in l1l1_l1_:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠࠩㅌ")+l111llll_l1_
			l1llll11_l1_.append(l1lllll_l1_)
	# l1l111l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪㅍ"),html,re.DOTALL)
	if not l1l1_l1_: l1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠣࡨ࡬ࡰࡪࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣㅎ"),html,re.DOTALL)
	if l1l1_l1_:
		l1lllll_l1_ = l1l1_l1_[0]
		if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧㅏ") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩㅐ")+l1lllll_l1_
		l1llll11_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬㅑ"))
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪㅒ"),l1llll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll11_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㅓ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠧࠨㅔ"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠨࠩㅕ"): return
	search = search.replace(l11ll1_l1_ (u"ࠩࠣࠫㅖ"),l11ll1_l1_ (u"ࠪ࠯ࠬㅗ"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫㅘ")+search
	l11111_l1_(url,l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬㅙ"))
	#url = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪㅚ")+search
	#l11111_l1_(url,l11ll1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬㅛ"))
	return
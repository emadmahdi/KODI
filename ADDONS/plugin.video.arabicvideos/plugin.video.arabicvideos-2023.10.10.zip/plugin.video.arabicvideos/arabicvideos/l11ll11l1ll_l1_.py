# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㾙")
l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡎࡇࡒࡤ࠭㾚")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ㾛"),l11ll1_l1_ (u"ࠩสืฯ็ำศำอ็๊่ࠦࠡษ็฻้ฮวหࠩ㾜")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l11111_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1ll1l_l1_(url)
	elif mode==454: results = l1llll1l_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ㾝"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ㾞"),l11ll1_l1_ (u"ࠬ࠭㾟"),l11ll1_l1_ (u"࠭ࠧ㾠"),l11ll1_l1_ (u"ࠧࠨ㾡"),l11ll1_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㾢"))
	html = response.content
	l1ll111_l1_ = SERVER(l11l1l_l1_,l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭㾣"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾤"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㾥"),l11ll1_l1_ (u"ࠬ࠭㾦"),459,l11ll1_l1_ (u"࠭ࠧ㾧"),l11ll1_l1_ (u"ࠧࠨ㾨"),l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㾩"))
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㾪"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㾫")+l111l1_l1_+l11ll1_l1_ (u"๊ࠫัศหษอࠤ้๎ฯ๋้ࠢฮࠬ㾬"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠬ࠭㾭"),l11ll1_l1_ (u"࠭ࠧ㾮"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㾯"))
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾰"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㾱")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ㾲"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠫࠬ㾳"),l11ll1_l1_ (u"ࠬ࠭㾴"),l11ll1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㾵"))
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㾶"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㾷")+l111l1_l1_+l11ll1_l1_ (u"่้ࠩะ๊๊็ࠩ㾸"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠪࠫ㾹"),l11ll1_l1_ (u"ࠫࠬ㾺"),l11ll1_l1_ (u"ࠬࡧࡣࡵࡱࡵࡷࠬ㾻"))
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾼"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㾽")+l111l1_l1_+l11ll1_l1_ (u"ࠨ็ึุ่๊วห๊๊ࠢิ๐ษࠨ㾾"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠩࠪ㾿"),l11ll1_l1_ (u"ࠪࠫ㿀"),l11ll1_l1_ (u"ࠫ࠵࠭㿁"))
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿂"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㿃")+l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อส้้ࠡำ๏ฯࠠๆัห่ัฯࠧ㿄"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠨࠩ㿅"),l11ll1_l1_ (u"ࠩࠪ㿆"),l11ll1_l1_ (u"ࠪ࠵ࠬ㿇"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㿈"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㿉")+l111l1_l1_+l11ll1_l1_ (u"࠭วโๆส้ࠥํๆะ์ฬࠫ㿊"),l1ll111_l1_,451,l11ll1_l1_ (u"ࠧࠨ㿋"),l11ll1_l1_ (u"ࠨࠩ㿌"),l11ll1_l1_ (u"ࠩ࠵ࠫ㿍"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㿎"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㿏"),l11ll1_l1_ (u"ࠬ࠭㿐"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠭㿑"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿒"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			if l1lllll_l1_==l11ll1_l1_ (u"ࠨࠥࠪ㿓"): continue
			if title in l1l11l_l1_: continue
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㿔"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㿕")+l111l1_l1_+title,l1lllll_l1_,451)
	return
def l11111_l1_(url,l1lll1l1l1_l1_=l11ll1_l1_ (u"ࠫࠬ㿖")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㿗"),l11ll1_l1_ (u"࠭ࠧ㿘"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ㿙"),url,l11ll1_l1_ (u"ࠨࠩ㿚"),l11ll1_l1_ (u"ࠩࠪ㿛"),l11ll1_l1_ (u"ࠪࠫ㿜"),l11ll1_l1_ (u"ࠫࠬ㿝"),l11ll1_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㿞"))
	html = response.content
	if l1lll1l1l1_l1_==l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㿟"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡼࡧࡶࡦࡵࠥࠫ㿠"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l1lll1l1l1_l1_==l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㿡"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡖࡪࡩࡥ࡯ࡶࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ㿢"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	elif l11ll1_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ㿣") in html:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㿤"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࠤࡄࡧࡹࡵࡲࡏࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿥"),block,re.DOTALL)
	elif l1lll1l1l1_l1_ in [l11ll1_l1_ (u"࠭࠰ࠨ㿦"),l11ll1_l1_ (u"ࠧ࠲ࠩ㿧"),l11ll1_l1_ (u"ࠨ࠴ࠪ㿨")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭㿩"),html,re.DOTALL)
		block = l1l1l11_l1_[int(l1lll1l1l1_l1_)]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ㿪"),html,re.DOTALL)
		block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭㿫"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"๋ࠬิศ้าอࠬ㿬"),l11ll1_l1_ (u"࠭แ๋ๆ่ࠫ㿭"),l11ll1_l1_ (u"ࠧศ฼้๎ฮ࠭㿮"),l11ll1_l1_ (u"ࠨล฽๊๏ฯࠧ㿯"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧ㿰"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩ㿱"),l11ll1_l1_ (u"ࠫ์ีวโࠩ㿲"),l11ll1_l1_ (u"๋ࠬศศำสอࠬ㿳"),l11ll1_l1_ (u"ู࠭าุࠪ㿴"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧ㿵"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧ㿶")]
	for l1lllll_l1_,l1lll1_l1_,title in items:
		if l11ll1_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠨ㿷") in html and l11ll1_l1_ (u"ࠪࡷࡷࡩ࠽ࠨ㿸") in l1lll1_l1_:
			l1lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㿹"),l1lll1_l1_,re.DOTALL)
			l1lll1_l1_ = l1lll1_l1_[0]
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠬ࠵ࠧ㿺"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ㿻"),title,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㿼"),title,re.DOTALL)
		#if any(value in title for value in l1ll1l_l1_):
		if set(title.split()) & set(l1ll1l_l1_) and l11ll1_l1_ (u"ࠨ็ึุ่๊ࠧ㿽") not in title:
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㿾"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠪั้่ษࠨ㿿") in title:
			title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䀀") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䀁"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀂"),l111l1_l1_+title,l1lllll_l1_,453,l1lll1_l1_)
	if l1lll1l1l1_l1_ in [l11ll1_l1_ (u"ࠧࠨ䀃"),l11ll1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䀄")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䀅"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䀆"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ䀇"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠬ࠭䀈"):
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀉"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭䀊")+title,l1lllll_l1_,451)
	return
def l1lll1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ䀋"),url,l11ll1_l1_ (u"ࠩࠪ䀌"),l11ll1_l1_ (u"ࠪࠫ䀍"),l11ll1_l1_ (u"ࠫࠬ䀎"),l11ll1_l1_ (u"ࠬ࠭䀏"),l11ll1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䀐"))
	html = response.content
	# l1lll1l_l1_
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠧࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡖࡹࡧࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䀑"),html,re.DOTALL)
	if l1l11l1_l1_ and l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠧ䀒") in str(l1l11l1_l1_):
		title = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠮ࠩ䀓"),html,re.DOTALL)
		title = title[0].strip(l11ll1_l1_ (u"ࠪࠤࠬ䀔"))
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䀕"),l111l1_l1_+title,url,454)
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䀖"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀗"),l111l1_l1_+title,l1lllll_l1_,454)
	else: l1llll1l_l1_(url)
	return
def l1llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ䀘"),url,l11ll1_l1_ (u"ࠨࠩ䀙"),l11ll1_l1_ (u"ࠩࠪ䀚"),l11ll1_l1_ (u"ࠪࠫ䀛"),l11ll1_l1_ (u"ࠫࠬ䀜"),l11ll1_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䀝"))
	html = response.content
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭䀞"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ䀟"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䀠"),l111l1_l1_+title,l1lllll_l1_,452,l1lll1_l1_)
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䀡"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䀢"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				#if l1lllll_l1_==l11ll1_l1_ (u"ࠦࠧ䀣"): continue
				title = unescapeHTML(title)
				#if title!=l11ll1_l1_ (u"ࠬ࠭䀤"):
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀥"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭䀦")+title,l1lllll_l1_,454)
	return
def PLAY(url):
	l111lll_l1_ = url.replace(l11ll1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䀧"),l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䀨"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䀩"),l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䀪"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䀫"),l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ䀬"),l11ll1_l1_ (u"ࠧࠨ䀭"),l11ll1_l1_ (u"ࠨࠩ䀮"),l11ll1_l1_ (u"ࠩࠪ䀯"),l11ll1_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䀰"))
	html = response.content
	l1ll111_l1_ = SERVER(l111lll_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䀱"))
	l1llll_l1_ = []
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬࡙࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡸ࡯ࡤࡦࡀࠪ䀲"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ䀳"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䀴")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䀵")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡶࡩࡱࡧࡲࡺࠤࠪ䀶"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ䀷"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			name = unescapeHTML(name)
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䀸"),name,re.DOTALL)
			if l111llll_l1_:
				l111llll_l1_ = l11ll1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䀹")+l111llll_l1_[0]
				name = l11ll1_l1_ (u"࠭ࠧ䀺")
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠧࠨ䀻")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䀼")+name+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䀽")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䀾"),l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䀿"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠬ࠭䁀"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"࠭ࠧ䁁"): return
	search = search.replace(l11ll1_l1_ (u"ࠧࠡࠩ䁂"),l11ll1_l1_ (u"ࠨ࠭ࠪ䁃"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ䁄")+search
	l11111_l1_(url)
	return
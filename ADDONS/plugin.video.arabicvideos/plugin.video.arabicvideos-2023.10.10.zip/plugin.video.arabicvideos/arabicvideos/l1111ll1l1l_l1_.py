# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ孳")
headers = { l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ孴") : l11ll1_l1_ (u"ࠬ࠭孵") }
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ孶")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l11111_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llll1l_l1_(url)
	elif mode==214: results = l1llll1lll111_l1_(url)
	elif mode==215: results = l1llll1lll11l_l1_(url)
	elif mode==218: results = l11ll11ll11l_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11ll11ll11l_l1_():
	message = l11ll1_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ孷")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ學"),l11ll1_l1_ (u"ࠩࠪ孹"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭孺"),l11ll1_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ孻"),message)
	return
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孼"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭孽"),l11ll1_l1_ (u"ࠧࠨ孾"),219,l11ll1_l1_ (u"ࠨࠩ孿"),l11ll1_l1_ (u"ࠩࠪ宀"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ宁"))
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宂"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็ไหำࠪ它"),l11ll1_l1_ (u"࠭ࠧ宄"),114,l11l1l_l1_)
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡓ࡭ࡳࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࡰࡪࡰࠩࡰ࡮ࡳࡩࡵ࠿࠵࠹ࠬ宅")
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宆"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ宇")+l111l1_l1_+l11ll1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ守"),url,211)
	html = OPENURL_CACHED(l1llllll_l1_,l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ安"),headers,l11ll1_l1_ (u"ࠬ࠭宊"),l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ宋"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡇ࡫࡯ࡸࡪࡸࡳࡃࡷࡷࡸࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ完"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ宍"),block,re.DOTALL)
	for l1lllll_l1_,title in items:#[1:-1]:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂ࠭宎")+l1lllll_l1_
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宏"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭宐")+l111l1_l1_+title,url,211)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ宑"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	items = re.findall(l11ll1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ宒"),block,re.DOTALL)
	l1l11l_l1_ = [l11ll1_l1_ (u"ࠧๆี็ื้อสࠡษ้้๏࠭宓"),l11ll1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ宔")]
	#l111l1111_l1_ = [l11ll1_l1_ (u"่ࠩืู้ไศฬࠣࠫ宕"),l11ll1_l1_ (u"ࠪหๆ๊วๆࠢࠪ宖"),l11ll1_l1_ (u"ࠫอืวๆฮࠪ宗"),l11ll1_l1_ (u"ࠬ฿ัุ้ࠪ官"),l11ll1_l1_ (u"࠭ใๅ์หหฯ࠭宙"),l11ll1_l1_ (u"ࠧศ฼ส๊๎࠭定")]
	for l1lllll_l1_,title in items:
		title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ宛"))
		if not any(value in title for value in l1l11l_l1_):
		#	if any(value in title for value in l111l1111_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宜"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ宝")+l111l1_l1_+title,l1lllll_l1_,211)
	return html
def l11111_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"ࠫࠬ实"),headers,l11ll1_l1_ (u"ࠬ࠭実"),l11ll1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ宠"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ审"),l11ll1_l1_ (u"ࠨࠩ客"),url,html)
	if l11ll1_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫ宣") in url or l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ室") in url: block = html
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡒ࡫ࡤࡪࡣࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ宥"),html,re.DOTALL)
		if l1l1l11_l1_: block = l1l1l11_l1_[0]
		else: return
	items = re.findall(l11ll1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ宦"),block,re.DOTALL)
	l11l_l1_ = []
	l111lll11_l1_ = [l11ll1_l1_ (u"࠭ๅีษ๊ำฮ࠭宧"),l11ll1_l1_ (u"ࠧโ์็้ࠬ宨"),l11ll1_l1_ (u"ࠨษ฽๊๏ฯࠧ宩"),l11ll1_l1_ (u"ࠩๆ่๏ฮࠧ宪"),l11ll1_l1_ (u"ࠪห฾๊ว็ࠩ宫"),l11ll1_l1_ (u"ࠫ์ีวโࠩ宬"),l11ll1_l1_ (u"๋ࠬศศำสอࠬ宭"),l11ll1_l1_ (u"ู࠭าุࠪ宮"),l11ll1_l1_ (u"ࠧๆ้ิะฬ์ࠧ宯"),l11ll1_l1_ (u"ࠨษ็ฬํ๋ࠧ宰")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		if l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ宱") in l1lllll_l1_: continue
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠪ࠳ࠬ宲"))
		title = unescapeHTML(title)
		title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭害"))
		if l11ll1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬ宴") in l1lllll_l1_ or any(value in title for value in l111lll11_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ宵"),l111l1_l1_+title,l1lllll_l1_,212,l1lll1_l1_)
		elif l11ll1_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ家") in l1lllll_l1_ and l11ll1_l1_ (u"ࠨษ็ั้่ษࠨ宷") in title:
			l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ宸"),title,re.DOTALL)
			if l1ll1l1_l1_:
				title = l11ll1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ容") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宺"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
					l11l_l1_.append(title)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ宻"),l111l1_l1_+title,l1lllll_l1_,213,l1lll1_l1_)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ宼"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ宽"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11ll1_l1_ (u"ࠨษ็ูๆำษࠡࠩ宾"),l11ll1_l1_ (u"ࠩࠪ宿"))
			if title!=l11ll1_l1_ (u"ࠪࠫ寀"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寁"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ寂")+title,l1lllll_l1_,211)
	return
def l1llll1l_l1_(url):
	l111lllll_l1_,items,l1111lll_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11ll1_l1_ (u"࠭ࠧ寃"),headers,l11ll1_l1_ (u"ࠧࠨ寄"),l11ll1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭寅"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡷ࡭࠲ࡲࡩࡴࡶ࠰ࡲࡺࡳࡢࡦࡴࡨࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ密"),html,re.DOTALL)
	if l1l1l11_l1_:
		l1111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ寇").join(l1l1l11_l1_)
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ寈"),l1111l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭寉"))
	for l1lllll_l1_ in items:
		l1lllll_l1_ = l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ寊"))
		title = l11ll1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭寋") + l1lllll_l1_.split(l11ll1_l1_ (u"ࠨ࠱ࠪ富"))[-1].replace(l11ll1_l1_ (u"ࠩ࠰ࠫ寍"),l11ll1_l1_ (u"ࠪࠤࠬ寎"))
		l111l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠫฬ๊อๅไฬ࠱࠭ࡢࡤࠬࠫࠪ寏"),l1lllll_l1_.split(l11ll1_l1_ (u"ࠬ࠵ࠧ寐"))[-1],re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = l111l1ll_l1_[0]
		else: l111l1ll_l1_ = l11ll1_l1_ (u"࠭࠰ࠨ寑")
		l1111lll_l1_.append([l1lllll_l1_,title,l111l1ll_l1_])
	items = sorted(l1111lll_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lll1l_l1_ = str(items).count(l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ寒"))
	l111lllll_l1_ = str(items).count(l11ll1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ寓"))
	if l111lll1l_l1_>1 and l111lllll_l1_>0 and l11ll1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ寔") not in url:
		for l1lllll_l1_,title,l111l1ll_l1_ in items:
			if l11ll1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ寕") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寖"),l111l1_l1_+title,l1lllll_l1_,213)
	else:
		for l1lllll_l1_,title,l111l1ll_l1_ in items:
			if l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ寗") not in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ寘"),l111l1_l1_+title,l1lllll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l11ll1_l1_ (u"ࠧ࠰ࠩ寙"))
	html = OPENURL_CACHED(l1llllll_l1_,url,l11ll1_l1_ (u"ࠨࠩ寚"),headers,l11ll1_l1_ (u"ࠩࠪ寛"),l11ll1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ寜"))
	# l11l1l1ll_l1_ l1l1_l1_
	if l11ll1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ寝") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ寞"))
		l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"࠭ࠧ察"),headers,l11ll1_l1_ (u"ࠧࠨ寠"),l11ll1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ寡"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ寢"),l11ll1ll_l1_,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡳࡡࡨࡧࠥࡂࡡࡴࠨ࠯ࠬࡂ࠭ࡡࡴࠧ寣"),block,re.DOTALL)
			if items:
				id = re.findall(l11ll1_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬ寤"),l11ll1ll_l1_,re.DOTALL)
				if id:
					l11lll1l11_l1_ = id[0]
					for l1lllll_l1_,title in items:
						l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ寥")+l11lll1l11_l1_+l11ll1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ實")+l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ寧")+title+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ寨")
						l1llll_l1_.append(l1lllll_l1_)
			else:
				# https://l1llll1lll1l1_l1_.tv/l11l1l1ll_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11ll1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ審"),block,re.DOTALL)
				for l1lllll_l1_,dummy in items:
					l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	if l11ll1_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ寪") in html:
		l111lll_l1_ = url.replace(parts[3],l11ll1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭寫"))
		l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠬ࠭寬"),headers,l11ll1_l1_ (u"࠭ࠧ寭"),l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ寮"))
		id = re.findall(l11ll1_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ寯"),l11ll1ll_l1_,re.DOTALL)
		if id:
			l11lll1l11_l1_ = id[0]
			l1l1ll11l_l1_ = { l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭寰"):l11ll1_l1_ (u"ࠪࠫ寱") , l11ll1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ寲"):l11ll1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭寳") }
			l111lll_l1_ = l11l1l_l1_ + l11ll1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩ寴")+l11lll1l11_l1_
			l11ll1ll_l1_ = OPENURL_CACHED(l1llllll_l1_,l111lll_l1_,l11ll1_l1_ (u"ࠧࠨ寵"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠨࠩ寶"),l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ寷"))
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡀ࡭࠹࠮ࠫࡁࠫࡠࡩ࠱ࠩࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ寸"),l11ll1ll_l1_,re.DOTALL)
			if l1l1l11_l1_:
				for resolution,block in l1l1l11_l1_:
					items = re.findall(l11ll1_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ对"),block,re.DOTALL)
					for name,l1lllll_l1_ in items:
						l1llll_l1_.append(l1lllll_l1_+l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭寺")+name+l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ寻")+l11ll1_l1_ (u"ࠧࡠࡡࡢࡣࠬ导")+resolution)
			else:
				l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾࡫࠺࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ寽"),l11ll1ll_l1_,re.DOTALL)
				if not l1l1l11_l1_: l1l1l11_l1_ = [l11ll1ll_l1_]
				for block in l1l1l11_l1_:
					l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡨࡶࡻ࡫ࡲࡴࡖ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࡰࡤࡱࡪࡀࠊࠊࠋࠌࠍࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࡟࠲࠷࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪห้ีโสࠢࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠋࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨࠥࡂ࠭ࠧ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫ࠠࠬࠢࠪࠤๅࠦࠧࠋࠋࠌࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥ࠭ࠧࠋࠋࠌࠍࠎࠏࠢࠣࠤ対")
					name = l11ll1_l1_ (u"ࠪࠫ寿")
					items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ尀"),block,re.DOTALL)
					for l1lllll_l1_ in items:
						server = l11ll1_l1_ (u"ࠬࠬࠦࠨ封") + l1lllll_l1_.split(l11ll1_l1_ (u"࠭࠯ࠨ専"))[2].lower() + l11ll1_l1_ (u"ࠧࠧࠨࠪ尃")
						server = server.replace(l11ll1_l1_ (u"ࠨ࠰ࡦࡳࡲࠬࠦࠨ射"),l11ll1_l1_ (u"ࠩࠪ尅")).replace(l11ll1_l1_ (u"ࠪ࠲ࡨࡵࠦࠧࠩ将"),l11ll1_l1_ (u"ࠫࠬ將"))
						server = server.replace(l11ll1_l1_ (u"ࠬ࠴࡮ࡦࡶࠩࠪࠬ專"),l11ll1_l1_ (u"࠭ࠧ尉")).replace(l11ll1_l1_ (u"ࠧ࠯ࡱࡵ࡫ࠫࠬࠧ尊"),l11ll1_l1_ (u"ࠨࠩ尋"))
						server = server.replace(l11ll1_l1_ (u"ࠩ࠱ࡰ࡮ࡼࡥࠧࠨࠪ尌"),l11ll1_l1_ (u"ࠪࠫ對")).replace(l11ll1_l1_ (u"ࠫ࠳ࡵ࡮࡭࡫ࡱࡩࠫࠬࠧ導"),l11ll1_l1_ (u"ࠬ࠭小"))
						server = server.replace(l11ll1_l1_ (u"࠭ࠦࠧࡪࡧ࠲ࠬ尐"),l11ll1_l1_ (u"ࠧࠨ少")).replace(l11ll1_l1_ (u"ࠨࠨࠩࡻࡼࡽ࠮ࠨ尒"),l11ll1_l1_ (u"ࠩࠪ尓"))
						server = server.replace(l11ll1_l1_ (u"ࠪࠪࠫ࠭尔"),l11ll1_l1_ (u"ࠫࠬ尕"))
						l1lllll_l1_ = l1lllll_l1_ + l11ll1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭尖") + name + server + l11ll1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ尗")
						l1llll_l1_.append(l1lllll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭尘"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ尙"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ尚"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ尛"),l11ll1_l1_ (u"ࠫ࠰࠭尜"))
	url = l11l1l_l1_ + l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ尝")+search
	l11111_l1_(url)
	return
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡴࡧࡤࡶࡨ࡮ࠠࡴࡧࡦࡳࡳࡪࡡࡳࡻࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯ࡦࡥࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦ࡬ࡪࡩ࡫࡮ࡣࡵ࡯࠲ࡨ࡯࡭ࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠭ࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࠊࡨࡲࡶࠥࡩࡡࡵࡧࡪࡳࡷࡿࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡨࡧࡴࡦࡩࡲࡶࡾ࠯ࠊࠊࠋࠌࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ࠮ࠣࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚ࠩࠋࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࡁࠥ࠳࠱ࠡ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠉࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ࠮ࡷࡪࡧࡲࡤࡪ࠮ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ࠭ࡦࡥࡹ࡫ࡧࡰࡴࡼࠎࠎࠏࡔࡊࡖࡏࡉࡘ࠮ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤ尞")
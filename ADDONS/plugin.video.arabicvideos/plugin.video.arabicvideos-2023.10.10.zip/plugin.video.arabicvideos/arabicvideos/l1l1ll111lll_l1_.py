# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ暓")
headers = {l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ暔"):l11ll1_l1_ (u"ࠫࠬ暕")}
l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡗࡄࡏࡢࠫ暖")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ暗"),l11ll1_l1_ (u"ࠧࡸࡹࡨࠫ暘")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11111_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llll1l_l1_(url,text)
	elif mode==564: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ暙")+text)
	elif mode==565: results = l1lll111_l1_(url,l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭暚")+text)
	elif mode==566: results = l1l111_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ暛"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ暜"),l11ll1_l1_ (u"ࠬ࠭暝"),False,l11ll1_l1_ (u"࠭ࠧ暞"),l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ暟"))
	#hostname = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ暠")]
	#hostname = hostname.strip(l11ll1_l1_ (u"ࠩ࠲ࠫ暡"))
	#l1ll111_l1_ = l11l1l_l1_
	#url = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ暢")
	#url = l1ll111_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ暣"),l11l1l_l1_,l11ll1_l1_ (u"ࠬ࠭暤"),l11ll1_l1_ (u"࠭ࠧ暥"),l11ll1_l1_ (u"ࠧࠨ暦"),l11ll1_l1_ (u"ࠨࠩ暧"),l11ll1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ暨"))
	#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ暩"),l111l1_l1_+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ暪"),l11ll1_l1_ (u"ࠬ࠭暫"),8)
	#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ暬"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ暭"),l11ll1_l1_ (u"ࠨࠩ暮"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ暯"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ暰"),l11l1l_l1_,569,l11ll1_l1_ (u"ࠫࠬ暱"),l11ll1_l1_ (u"ࠬ࠭暲"),l11ll1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ暳"))
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ暴"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ暵"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ暶"),564)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ暷"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ暸"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ暹"),565)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ暺"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ暻"),l11ll1_l1_ (u"ࠨࠩ暼"),9999)
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ暽"):hostname,l11ll1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ暾"):l11ll1_l1_ (u"ࠫࠬ暿")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11ll1_l1_ (u"ࠬࡢ࠯ࠨ曀"),l11ll1_l1_ (u"࠭࠯ࠨ曁"))
	#l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡦࡪ࡮ࡷࡩࡷ࠭曂"),html,re.DOTALL)
	#if l1l1l11_l1_:
	#	block = l1l1l11_l1_[0]
	#	items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ曃"),block,re.DOTALL)
	#	for l1lllll_l1_,title in items:
	#		if l11ll1_l1_ (u"ࠩࠨࡨ࠾ࠫ࠸࠶ࠧࡧ࠼ࠪࡨ࠵ࠦࡦ࠻ࠩࡦ࠽ࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡥ࠽ࠪࡪ࠸ࠦࡣ࠼࠱ࠪࡪ࠸ࠦࡣࡧࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡡ࠺ࠩ曄") in l1lllll_l1_: continue
	#		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ曅"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭曆")+l111l1_l1_+title,l1lllll_l1_,566)
	#	addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ曇"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭曈"),l11ll1_l1_ (u"ࠧࠨ曉"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ曊"),l11l1l_l1_,l11ll1_l1_ (u"ࠩࠪ曋"),l11ll1_l1_ (u"ࠪࠫ曌"),l11ll1_l1_ (u"ࠫࠬ曍"),l11ll1_l1_ (u"ࠬ࠭曎"),l11ll1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ曏"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ曐"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ曑"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			#if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ曒") not in l1lllll_l1_:
			#	server = SERVER(l1lllll_l1_,l11ll1_l1_ (u"ࠪࡹࡷࡲࠧ曓"))
			#	l1lllll_l1_ = l1lllll_l1_.replace(server,l1ll111_l1_)
			if title==l11ll1_l1_ (u"ࠫࠬ曔"): continue
			if any(value in title.lower() for value in l1l11l_l1_): continue
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曕"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ曖")+l111l1_l1_+title,l1lllll_l1_,566)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ曗"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ曘"),l11ll1_l1_ (u"ࠩࠪ曙"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩࠬ曚"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ曛"),block,re.DOTALL)
		for l1lllll_l1_,l1lll1_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曜"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ曝")+l111l1_l1_+title,l1lllll_l1_,566,l1lll1_l1_)
	return html
def l1l111_l1_(url):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ曞"),l11ll1_l1_ (u"ࠨࠩ曟"),url,l11ll1_l1_ (u"ࠩࠪ曠"))
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ曡"):url,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ曢"):l11ll1_l1_ (u"ࠬ࠭曣")}
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ曤"),url,l11ll1_l1_ (u"ࠧࠨ曥"),l11ll1_l1_ (u"ࠨࠩ曦"),l11ll1_l1_ (u"ࠩࠪ曧"),l11ll1_l1_ (u"ࠪࠫ曨"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ曩"))
	html = response.content
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曪"),l111l1_l1_+l11ll1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ曫"),url,564)
	#addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ曬"),l111l1_l1_+l11ll1_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ曭"),url,565)
	if l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ曮") in html:
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ曯"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ曰"),url,561,l11ll1_l1_ (u"ࠬ࠭曱"),l11ll1_l1_ (u"࠭ࠧ曲"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ曳"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ更"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ曵"),block,re.DOTALL)
		for l1lllll_l1_,title in items:
			addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ曶"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l11111_l1_(l1ll1l1l1111_l1_,type=l11ll1_l1_ (u"ࠫࠬ曷")):
	if l11ll1_l1_ (u"ࠬࡀ࠺ࠨ書") in l1ll1l1l1111_l1_:
		l11l111_l1_,url = l1ll1l1l1111_l1_.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ曹"))
		server = SERVER(l11l111_l1_,l11ll1_l1_ (u"ࠧࡶࡴ࡯ࠫ曺"))
		url = server+url
	else: url,l11l111_l1_ = l1ll1l1l1111_l1_,l1ll1l1l1111_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ曻"):l11l111_l1_,l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭曼"):l11ll1_l1_ (u"ࠪࠫ曽")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ曾"),url,l11ll1_l1_ (u"ࠬ࠭替"),l11ll1_l1_ (u"࠭ࠧ最"),l11ll1_l1_ (u"ࠧࠨ朁"),l11ll1_l1_ (u"ࠨࠩ朂"),l11ll1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭會"))
	html = response.content
	if type==l11ll1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ朄"):
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠨ朅"),html,re.DOTALL)
	elif type==l11ll1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭朆"):
		l1l1l11_l1_ = [html.replace(l11ll1_l1_ (u"࠭࡜࡝࠱ࠪ朇"),l11ll1_l1_ (u"ࠧ࠰ࠩ月")).replace(l11ll1_l1_ (u"ࠨ࡞࡟ࠦࠬ有"),l11ll1_l1_ (u"ࠩࠥࠫ朊"))]
	else:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡋࡷ࡯ࡤ࠮࠯࡚ࡩࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ朋"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ朌"),block,re.DOTALL)
		for l1lllll_l1_,title,l1lll1_l1_ in items:
			if any(value in title.lower() for value in l1l11l_l1_): continue
			l1lll1_l1_ = escapeUNICODE(l1lll1_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11ll1_l1_ (u"๋ࠬิศ้าอࠥ࠭服"),l11ll1_l1_ (u"࠭ࠧ朎"))
			if l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ朏") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ朐"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			elif l11ll1_l1_ (u"ࠩะ่็ฯࠧ朑") in title:
				l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭朒"),title,re.DOTALL)
				if l1ll1l1_l1_: title = l11ll1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ朓") + l1ll1l1_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朔"),l111l1_l1_+title,l1lllll_l1_,563,l1lll1_l1_)
			else:
				addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ朕"),l111l1_l1_+title,l1lllll_l1_,562,l1lll1_l1_)
		if type==l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ朖"):
			l1ll1l111l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭朗"),block,re.DOTALL)
			if l1ll1l111l1_l1_:
				count = l1ll1l111l1_l1_[0]
				l1lllll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ朘")+count
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ朙"),l111l1_l1_+l11ll1_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ朚"),l1lllll_l1_,561,l11ll1_l1_ (u"ࠬ࠭望"),l11ll1_l1_ (u"࠭ࠧ朜"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ朝"))
		elif type==l11ll1_l1_ (u"ࠨࠩ朞"):
			l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ期"),html,re.DOTALL)
			if l1l1l11_l1_:
				block = l1l1l11_l1_[0]
				items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ朠"),block,re.DOTALL)
				for l1lllll_l1_,title in items:
					title = l11ll1_l1_ (u"ฺࠫ็อสࠢࠪ朡")+unescapeHTML(title)
					addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朢"),l111l1_l1_+title,l1lllll_l1_,561)
	return
def l1llll1l_l1_(url,type=l11ll1_l1_ (u"࠭ࠧ朣")):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ朤"),l11ll1_l1_ (u"ࠨࠩ朥"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭朦"),url,l11ll1_l1_ (u"ࠪࠫ朧"),l11ll1_l1_ (u"ࠫࠬ木"),l11ll1_l1_ (u"ࠬ࠭朩"),l11ll1_l1_ (u"࠭ࠧ未"),l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭末"))
	html = response.content
	html = l1111_l1_(html)
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡩࡵࡧࡰࠦࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡰࡤࡱࡪࡀࠠ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࡠ࠳࠱࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠲࠭ࠬࠨࠢࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬ࠵ࠧࠪࠌࠌ࡭࡫ࠦࠧๆ๊ึ้ࠬࠦࡩ࡯ࠢࡱࡥࡲ࡫ࠠࡢࡰࡧࠤࡳࡵࡴࠡࡶࡼࡴࡪࡀࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧๆ๊ึ้ࠬ࠯࡛࠱࡟ࠍࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ๋ࠬࠬิศ้าอࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧฮๆๅอࠬࠦࡩ࡯ࠢࡱࡥࡲ࡫࠺ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨฯ็ๆฮ࠭ࠩ࡜࠲ࡠࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ๅีษ๊ำฮ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠥࠦࠧ本")
	# l1lll1l_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ札"),html,re.DOTALL)
	if not type and l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ朮"),block,re.DOTALL)
		if len(items)>1:
			for l1lllll_l1_,title in items:
				#title = name+l11ll1_l1_ (u"ࠫࠥ࠳ࠠࠨ术")+title
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朰"),l111l1_l1_+title,l1lllll_l1_,563,l11ll1_l1_ (u"࠭ࠧ朱"),l11ll1_l1_ (u"ࠧࠨ朲"),l11ll1_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ朳"))
			return
	# l1l11_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠱࠲࡙ࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡵ࡬ࡲ࡬ࡲࡥࡴࡧࡦࡸ࡮ࡵ࡮ࡴࡀࠪ朴"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ朵"),block)
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂࠬ朶"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭朷"),str(items))
		for l1lllll_l1_,title in items:
			title = title.strip(l11ll1_l1_ (u"࠭ࠠࠨ朸"))
			#title = name+l11ll1_l1_ (u"ࠧࠡ࠯ࠣࠫ朹")+title
			addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ机"),l111l1_l1_+title,l1lllll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ朻"),html,re.DOTALL)
		if title: title = title[0].replace(l11ll1_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ朼"),l11ll1_l1_ (u"ࠫࠬ朽")).replace(l11ll1_l1_ (u"๋ࠬิศ้าอࠥ࠭朾"),l11ll1_l1_ (u"࠭ࠧ朿"))
		else: title = l11ll1_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ杀")
		addMenuItem(l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ杁"),l111l1_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭杂"),url,l11ll1_l1_ (u"ࠪࠫ权"),l11ll1_l1_ (u"ࠫࠬ杄"),l11ll1_l1_ (u"ࠬ࠭杅"),l11ll1_l1_ (u"࠭ࠧ杆"),l11ll1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ杇"))
	html = response.content
	l11l1ll_l1_ = re.findall(l11ll1_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ杈"),html,re.DOTALL)
	if l11l1ll_l1_:
		l11l1ll_l1_ = [l11l1ll_l1_[0][0],l11l1ll_l1_[0][1]]
		if l11l1ll_l1_ and l11l1l1_l1_(script_name,url,l11l1ll_l1_): return
	# l11l1l1ll_l1_ l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ杉"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ杊"),block,re.DOTALL)
		for l1lllll_l1_,name in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ杋") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			if name==l11ll1_l1_ (u"ู๊ࠬาใิࠤํ๐ࠠิ์่หࠬ杌"): name = l11ll1_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭杍")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ李")+name+l11ll1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ杏")
			l1llll_l1_.append(l1lllll_l1_)
	# download l1l1_l1_
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ材"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ村"),block,re.DOTALL)
		for l1lllll_l1_,l111llll_l1_ in items:
			if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ杒") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
			l111llll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭杓"),l111llll_l1_,re.DOTALL)
			if l111llll_l1_: l111llll_l1_ = l11ll1_l1_ (u"࠭࡟ࡠࡡࡢࠫ杔")+l111llll_l1_[0]
			else: l111llll_l1_ = l11ll1_l1_ (u"ࠧࠨ杕")
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡹࡨࡧ࡮ࡳࡡࠨ杖")+l11ll1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭杗")+l111llll_l1_
			l1llll_l1_.append(l1lllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ杘"), l1llll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ杙"),url)
	return
def SEARCH(search,hostname=l11ll1_l1_ (u"ࠬ࠭杚")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"࠭ࠧ杛"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠧࠨ杜"): return
	search = search.replace(l11ll1_l1_ (u"ࠨࠢࠪ杝"),l11ll1_l1_ (u"ࠩ࠮ࠫ杞"))
	l1llll_l1_ = [l11ll1_l1_ (u"ࠪ࠳ࠬ束"),l11ll1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡷࡪࡸࡩࡦࡵࠪ杠"),l11ll1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡦࡴࡩ࡮ࡧࠪ条"),l11ll1_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡺࡶࠨ杢"),l11ll1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭杣")]
	l1l11l11l_l1_ = [l11ll1_l1_ (u"ࠨลไ่ฬ๋ࠧ杤"),l11ll1_l1_ (u"่ࠩืู้ไศฬࠪ来"),l11ll1_l1_ (u"ࠪว๋๐ๅ๋๋ࠢ็ึะ่็ࠩ杦"),l11ll1_l1_ (u"ࠫอืวๆฮࠣฮ้๐แำ์๋๊ࠬ杧"),l11ll1_l1_ (u"๋ࠬำๅี็หฯ่ࠦฤ่ํ้๏࠭杨")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ杩"), l1l11l11l_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l1l_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ杪"),l11l1l_l1_,l11ll1_l1_ (u"ࠨࠩ杫"),l11ll1_l1_ (u"ࠩࠪ杬"),False,l11ll1_l1_ (u"ࠪࠫ杭"),l11ll1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ杮"))
		#hostname = response.headers[l11ll1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ杯")]
		#hostname = response.url
		#hostname = hostname.strip(l11ll1_l1_ (u"࠭࠯ࠨ杰"))
	l111lll_l1_ = hostname+l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ東")+search+l1llll_l1_[l1l_l1_]
	l11111_l1_(l111lll_l1_)
	return
def l1lll111_l1_(l1ll1l1l1111_l1_,filter):
	if l11ll1_l1_ (u"ࠨࡁࡂࠫ杲") in l1ll1l1l1111_l1_: url = l1ll1l1l1111_l1_.split(l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ杳"))[0]
	else: url = l1ll1l1l1111_l1_
	#l1l1ll11l_l1_ = {l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ杴"):l1ll1l1l1111_l1_,l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ杵"):l11ll1_l1_ (u"ࠬ࠭杶")}
	filter = filter.replace(l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ杷"),l11ll1_l1_ (u"ࠧࠨ杸"))
	type,filter = filter.split(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ杹"),1)
	if filter==l11ll1_l1_ (u"ࠩࠪ杺"): l1l111ll_l1_,l1l111l1_l1_ = l11ll1_l1_ (u"ࠪࠫ杻"),l11ll1_l1_ (u"ࠫࠬ杼")
	else: l1l111ll_l1_,l1l111l1_l1_ = filter.split(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ杽"))
	if type==l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ松"):
		if l1l111l11_l1_[0]+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ板") not in l1l111ll_l1_: category = l1l111l11_l1_[0]
		for i in range(len(l1l111l11_l1_[0:-1])):
			if l1l111l11_l1_[i]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ枀") in l1l111ll_l1_: category = l1l111l11_l1_[i+1]
		l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ极")+category+l11ll1_l1_ (u"ࠪࡁࡂ࠶ࠧ枂")
		l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ枃")+category+l11ll1_l1_ (u"ࠬࡃ࠽࠱ࠩ构")
		l1l11lll_l1_ = l1ll1111_l1_.strip(l11ll1_l1_ (u"࠭ࠦࠧࠩ枅"))+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ枆")+l1l1ll1l_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫ枇"))
		l11lllll_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ枈"))
		l111lll_l1_ = url+l11ll1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ枉")+l11lllll_l1_
	elif type==l11ll1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ枊"):
		l11ll1l1_l1_ = l1l11111_l1_(l1l111ll_l1_,l11ll1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ枋"))
		l11ll1l1_l1_ = l1111_l1_(l11ll1l1_l1_)
		if l1l111l1_l1_!=l11ll1_l1_ (u"࠭ࠧ枌"): l1l111l1_l1_ = l1l11111_l1_(l1l111l1_l1_,l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ枍"))
		if l1l111l1_l1_==l11ll1_l1_ (u"ࠨࠩ枎"): l111lll_l1_ = url
		else: l111lll_l1_ = url+l11ll1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ枏")+l1l111l1_l1_
		l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ析"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ枑"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠬ࠭枒"),l11ll1_l1_ (u"࠭ࠧ枓"),l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ枔"))
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枕"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ枖")+l11ll1l1_l1_+l11ll1_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ林"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠫࠬ枘"),l11ll1_l1_ (u"ࠬ࠭枙"),l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ枚"))
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ枛"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ果"),l11ll1_l1_ (u"ࠩࠪ枝"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llllll_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ枞"),url,l11ll1_l1_ (u"ࠫࠬ枟"),l11ll1_l1_ (u"ࠬ࠭枠"),l11ll1_l1_ (u"࠭ࠧ枡"),l11ll1_l1_ (u"ࠧࠨ枢"),l11ll1_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ枣"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠩ࡟ࡠࠧ࠭枤"),l11ll1_l1_ (u"ࠪࠦࠬ枥")).replace(l11ll1_l1_ (u"ࠫࡡࡢ࠯ࠨ枦"),l11ll1_l1_ (u"ࠬ࠵ࠧ枧"))
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"࠭࠼ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ枨"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	l1ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ枩"),block+l11ll1_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ枪"),re.DOTALL)
	dict = {}
	for l1ll1l1l_l1_,name,block in l1ll1lll_l1_:
		name = escapeUNICODE(name)
		if l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ枫") in l1ll1l1l_l1_: continue
		items = re.findall(l11ll1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ枬"),block,re.DOTALL)
		if l11ll1_l1_ (u"ࠫࡂࡃࠧ枭") not in l111lll_l1_: l111lll_l1_ = url
		if type==l11ll1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ枮"):
			if category!=l1ll1l1l_l1_: continue
			elif len(items)<=1:
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]: l11111_l1_(l111lll_l1_)
				else: l1lll111_l1_(l111lll_l1_,l11ll1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭枯")+l1l11lll_l1_)
				return
			else:
				l1llllll1_l1_ = l11ll1l1l_l1_(l111lll_l1_,l1ll1l1l1111_l1_)
				if l1ll1l1l_l1_==l1l111l11_l1_[-1]:
					addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ枰"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ะ๊๐ูࠨ枱"),l1llllll1_l1_,561,l11ll1_l1_ (u"ࠩࠪ枲"),l11ll1_l1_ (u"ࠪࠫ枳"),l11ll1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ枴"))
				else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ枵"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅฮ่๎฾࠭架"),l111lll_l1_,564,l11ll1_l1_ (u"ࠧࠨ枷"),l11ll1_l1_ (u"ࠨࠩ枸"),l1l11lll_l1_)
		elif type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ枹"):
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠪࠪࠫ࠭枺")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠫࡂࡃ࠰ࠨ枻")
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ枼")+l1ll1l1l_l1_+l11ll1_l1_ (u"࠭࠽࠾࠲ࠪ枽")
			l1l11lll_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ枾")+l1l1ll1l_l1_
			addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枿"),l111l1_l1_+name+l11ll1_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ柀"),l111lll_l1_,565,l11ll1_l1_ (u"ࠪࠫ柁"),l11ll1_l1_ (u"ࠫࠬ柂"),l1l11lll_l1_+l11ll1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ柃"))
		dict[l1ll1l1l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11ll1_l1_ (u"࠭ࡲࠨ柄") or value==l11ll1_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭柅"): continue
			if any(value in option.lower() for value in l1l11l_l1_): continue
			if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭柆") in option: continue
			if l11ll1_l1_ (u"ࠩส่่๊ࠧ柇") in option: continue
			if l11ll1_l1_ (u"ࠪࡲ࠲ࡧࠧ柈") in value: continue
			#if value in [l11ll1_l1_ (u"ࠫࡷ࠭柉"),l11ll1_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ柊"),l11ll1_l1_ (u"࠭ࡴࡷ࠯ࡰࡥࠬ柋")]: continue
			#if l1ll1l1l_l1_==l11ll1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭柌"): option = value
			if option==l11ll1_l1_ (u"ࠨࠩ柍"): option = value
			l11l1l1l1_l1_ = option
			l1l1ll1111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ柎"),option,re.DOTALL)
			if l1l1ll1111l_l1_: l11l1l1l1_l1_ = l1l1ll1111l_l1_[0]
			l1lll1l1l_l1_ = name+l11ll1_l1_ (u"ࠪ࠾ࠥ࠭柏")+l11l1l1l1_l1_
			dict[l1ll1l1l_l1_][value] = l1lll1l1l_l1_
			l1ll1111_l1_ = l1l111ll_l1_+l11ll1_l1_ (u"ࠫࠫࠬࠧ某")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠬࡃ࠽ࠨ柑")+l11l1l1l1_l1_
			l1l1ll1l_l1_ = l1l111l1_l1_+l11ll1_l1_ (u"࠭ࠦࠧࠩ柒")+l1ll1l1l_l1_+l11ll1_l1_ (u"ࠧ࠾࠿ࠪ染")+value
			l1ll1l11_l1_ = l1ll1111_l1_+l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ柔")+l1l1ll1l_l1_
			if type==l11ll1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ柕"):
				addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ柖"),l111l1_l1_+l1lll1l1l_l1_,url,565,l11ll1_l1_ (u"ࠫࠬ柗"),l11ll1_l1_ (u"ࠬ࠭柘"),l1ll1l11_l1_+l11ll1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ柙"))
			elif type==l11ll1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ柚") and l1l111l11_l1_[-2]+l11ll1_l1_ (u"ࠨ࠿ࡀࠫ柛") in l1l111ll_l1_:
				l11lllll_l1_ = l1l11111_l1_(l1l1ll1l_l1_,l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ柜"))
				#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ柝"),l11ll1_l1_ (u"ࠫࠬ柞"),l11lllll_l1_,l1l1ll1l_l1_)
				l11l111_l1_ = url+l11ll1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ柟")+l11lllll_l1_
				l1llllll1_l1_ = l11ll1l1l_l1_(l11l111_l1_,l1ll1l1l1111_l1_)
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭柠"),l111l1_l1_+l1lll1l1l_l1_,l1llllll1_l1_,561,l11ll1_l1_ (u"ࠧࠨ柡"),l11ll1_l1_ (u"ࠨࠩ柢"),l11ll1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ柣"))
			else: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ柤"),l111l1_l1_+l1lll1l1l_l1_,url,564,l11ll1_l1_ (u"ࠫࠬ查"),l11ll1_l1_ (u"ࠬ࠭柦"),l1ll1l11_l1_)
	return
l1l111l11_l1_ = [l11ll1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ柧"),l11ll1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭柨"),l11ll1_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ柩")]
l1l111111_l1_ = [l11ll1_l1_ (u"ࠩࡰࡴࡦࡧࠧ柪"),l11ll1_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ柫"),l11ll1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ柬"),l11ll1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ柭"),l11ll1_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ柮"),l11ll1_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ柯"),l11ll1_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ柰"),l11ll1_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ柱")]
def l11ll1l1l_l1_(l111lll_l1_,l11l111_l1_):
	if l11ll1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ柲") in l111lll_l1_: l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ柳"),l11ll1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭柴"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ柵"),l11ll1_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫ柶"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠨ࠿ࡀࠫ柷"),l11ll1_l1_ (u"ࠩ࠲ࠫ柸"))
	l111lll_l1_ = l111lll_l1_.replace(l11ll1_l1_ (u"ࠪࠪࠫ࠭柹"),l11ll1_l1_ (u"ࠫ࠴࠭柺"))
	return l111lll_l1_
def l1l11111_l1_(filters,mode):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭査"),l11ll1_l1_ (u"࠭ࠧ柼"),filters,l11ll1_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧ柽")+mode)
	# mode==l11ll1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ柾")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ values
	# mode==l11ll1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ柿")		l1l1lll1_l1_ l1l1l11l_l1_ l1l1l1ll_l1_ filters
	# mode==l11ll1_l1_ (u"ࠪࡥࡱࡲࠧ栀")					all filters (l11lll1l_l1_ l1l1l1ll_l1_ filter)
	filters = filters.strip(l11ll1_l1_ (u"ࠫࠫࠬࠧ栁"))
	l1l11l11_l1_,l1ll11ll_l1_ = {},l11ll1_l1_ (u"ࠬ࠭栂")
	if l11ll1_l1_ (u"࠭࠽࠾ࠩ栃") in filters:
		items = filters.split(l11ll1_l1_ (u"ࠧࠧࠨࠪ栄"))
		for item in items:
			var,value = item.split(l11ll1_l1_ (u"ࠨ࠿ࡀࠫ栅"))
			l1l11l11_l1_[var] = value
	for key in l1l111111_l1_:
		if key in list(l1l11l11_l1_.keys()): value = l1l11l11_l1_[key]
		else: value = l11ll1_l1_ (u"ࠩ࠳ࠫ栆")
		if l11ll1_l1_ (u"ࠪࠩࠬ标") not in value: value = QUOTE(value)
		if mode==l11ll1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭栈") and value!=l11ll1_l1_ (u"ࠬ࠶ࠧ栉"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"࠭ࠠࠬࠢࠪ栊")+value
		elif mode==l11ll1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ栋") and value!=l11ll1_l1_ (u"ࠨ࠲ࠪ栌"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠩࠩࠪࠬ栍")+key+l11ll1_l1_ (u"ࠪࡁࡂ࠭栎")+value
		elif mode==l11ll1_l1_ (u"ࠫࡦࡲ࡬ࠨ栏"): l1ll11ll_l1_ = l1ll11ll_l1_+l11ll1_l1_ (u"ࠬࠬࠦࠨ栐")+key+l11ll1_l1_ (u"࠭࠽࠾ࠩ树")+value
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠧࠡ࠭ࠣࠫ栒"))
	l1ll11ll_l1_ = l1ll11ll_l1_.strip(l11ll1_l1_ (u"ࠨࠨࠩࠫ栓"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ栔"),l11ll1_l1_ (u"ࠪࠫ栕"),l1ll11ll_l1_,l11ll1_l1_ (u"ࠫࡔ࡛ࡔࠨ栖"))
	return l1ll11ll_l1_
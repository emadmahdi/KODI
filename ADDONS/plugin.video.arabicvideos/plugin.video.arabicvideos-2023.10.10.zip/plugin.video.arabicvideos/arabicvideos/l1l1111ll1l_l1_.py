# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
#
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩ尟")
def MAIN(mode,text=l11ll1_l1_ (u"ࠨࠩ尠")):
	if   mode==  0: l1lll1l1ll111_l1_(text)
	elif mode==  2: l1ll111l1111_l1_(text)
	elif mode==  3: l1llll111l1ll_l1_()
	elif mode==  4: l1lll1l1ll11_l1_(text)
	elif mode==  5: l1lll1l1l1l11_l1_()
	elif mode==  6: l1llll11l1111_l1_()
	elif mode==  7: l1ll1l11ll11_l1_()
	elif mode==  8: l1lll1l11ll1l_l1_()
	elif mode==  9: l1lll1l11llll_l1_()
	elif mode==150: l1lll1l11111l_l1_()
	elif mode==151: l1lll1111l1l1_l1_()
	elif mode==152: l1lll1ll1l1ll_l1_()
	elif mode==153: l1llll1l1llll_l1_()
	elif mode==154: l1llll11ll1l1_l1_()
	elif mode==155: l1lll1l1lll11_l1_()
	elif mode==156: l1lll11111lll_l1_()
	elif mode==157: l1llll11l111l_l1_()
	elif mode==158: l1lll1ll1ll1l_l1_()
	elif mode==159: l1lll11lll1l1_l1_(True)
	elif mode==170: l1lll11lll1ll_l1_()
	elif mode==171: l1lll1llll1l1_l1_()
	elif mode==172: l1lll11l1l1ll_l1_(text,True,True)
	elif mode==173: l11l11ll1ll_l1_(l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ尡"),True)
	elif mode==174: l11l11ll1ll_l1_(l11ll1_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭尢"),True)
	elif mode==175: l1lll1ll111ll_l1_()
	elif mode==176: l1lll11l1ll11_l1_()
	elif mode==177: l1llll11l1lll_l1_(l11ll1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ尣"))
	elif mode==178: l1llll11l1lll_l1_(l11ll1_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ尤"))
	elif mode==179: l1llll11l1lll_l1_(l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭尥"))
	elif mode==190: l1lll1l1l1lll_l1_()
	elif mode==191: l1lll11l11111_l1_()
	elif mode==192: l1lll11l1ll1l_l1_()
	elif mode==193: l1lll1lllll11_l1_()
	elif mode==194: l1lll11l1l111_l1_()
	elif mode==195: l1lll1l111111_l1_()
	elif mode==196: l1lll1l1l11ll_l1_()
	elif mode==197: l1lll1l111lll_l1_()
	elif mode==198: l1lll1llll111_l1_()
	elif mode==199: l1lll1l111l1l_l1_()
	elif mode==340: l1lll111ll1l1_l1_(text)
	elif mode==341: l1l1l1ll111l_l1_()
	elif mode==342: l1lll1l1lllll_l1_()
	elif mode==343: l1lll1l11l111_l1_()
	elif mode==344: l1lll11l1111l_l1_(True)
	elif mode==345: l1lll1lll111l_l1_()
	elif mode==346: l1l111ll1ll_l1_(False)
	elif mode==347: l1l1l1l11l1l_l1_(True)
	elif mode==348: l1lll1llll1ll_l1_()
	elif mode==349: l1llll111l11l_l1_(l1l11l11lll1_l1_)
	elif mode==500: l1lll11l111l1_l1_()
	elif mode==501: l1lll111l11ll_l1_()
	elif mode==502: l1lll1lll1lll_l1_(l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭尦"),True)
	elif mode==503: l1llll111l11l_l1_(l1l111l11l1_l1_)
	elif mode==504: l1llll111l11l_l1_(favoritesfile)
	elif mode==505: l1lll1ll1111l_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1l1llll_l1_(text,l11ll1_l1_ (u"ࠨࠩ尧"),True)
	elif mode==508: l1lll1llll11l_l1_()
	elif mode==509: l1llll1l1ll11_l1_()
	return
def l1llll1l1ll11_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ尨"),l11ll1_l1_ (u"ࠪࠫ尩"),l11ll1_l1_ (u"ࠫࠬ尪"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ尫"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢฯ้๏฿ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ࠲࠳่ࠦๆีะࠤัฺ๋๊่่ࠢๆอสࠡษ็ฬึ์วๆฮࠣห้่ฯ๋็ฬࠤ࠳࠴ࠠๅๅํࠤ๏฿่ะࠢส่อืๆศ็ฯࠤส๊้ࠡฯส่ฮࠦวๅืไีࠥ࠴࠮ࠡ์฼๊๏ࠦสอัํำࠥอไษำ้ห๊า้ࠠฬุๅ๏ื็ฺ๊๋ࠡ฾ํࠠษฯส่ฮࠦวๅ็ุ๊฾ࠦวๅฬํࠤํ฼ู่ษࠣห้๋ศา็ฯࠤฤࠧࠡࠨ尬"))
	if l1ll111ll1_l1_:
		l1lll11l1111l_l1_(False)
		l1ll11l1ll_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ尭"),l11ll1_l1_ (u"ࠨࠩ尮"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ尯"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬ尰"))
	return
def l1l1l1l1llll_l1_(addon_id,function,l1ll_l1_):
	# function: l11ll1_l1_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࠫ就"),l11ll1_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭尲"),l11ll1_l1_ (u"࠭ࠧ尳")
	conn = sqlite3.connect(l1l1ll111ll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1lll11ll1111_l1_ = l11ll1_l1_ (u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪ尴")
	else: l1lll11ll1111_l1_ = l11ll1_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧ尵")
	cc.execute(l11ll1_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪ尶")+l1lll11ll1111_l1_+l11ll1_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ尷")+addon_id+l11ll1_l1_ (u"ࠫࠧࠦ࠻ࠨ尸"))
	l1l1111l1ll_l1_ = cc.fetchall()
	if l1l1111l1ll_l1_ and function in [l11ll1_l1_ (u"ࠬ࠭尹"),l11ll1_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭尺")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ尻"),l11ll1_l1_ (u"ࠨࠩ尼"),l11ll1_l1_ (u"ࠩࠪ尽"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭尾"),l11ll1_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ尿")+addon_id+l11ll1_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭局"))
		if l1ll111ll1_l1_!=1: return
		cc.execute(l11ll1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬ屁")+l1lll11ll1111_l1_+l11ll1_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ层")+addon_id+l11ll1_l1_ (u"ࠨࠤࠣ࠿ࠬ屃"))
	elif function in [l11ll1_l1_ (u"ࠩࠪ屄"),l11ll1_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࠫ居")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ屆"),l11ll1_l1_ (u"ࠬ࠭屇"),l11ll1_l1_ (u"࠭ࠧ屈"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ屉"),l11ll1_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ届")+addon_id+l11ll1_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭屋"))
		if l1ll111ll1_l1_!=1: return
		if kodi_version<19: cc.execute(l11ll1_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ屌")+addon_id+l11ll1_l1_ (u"ࠫࠧ࠯ࠠ࠼ࠩ屍"))
		else: cc.execute(l11ll1_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬ屎")+addon_id+l11ll1_l1_ (u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭屏"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ屐"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ屑"),l11ll1_l1_ (u"ࠩࠪ屒"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭屓"),l11ll1_l1_ (u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨ屔"))
	if function in [l11ll1_l1_ (u"ࠬ࠭展"),l11ll1_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭屖")]: l1lll11lll1l1_l1_(l1ll_l1_)
	return
def l1lll1ll1111l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ屗"),l11ll1_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ屘"))
	l1l1ll11ll1l_l1_ = l11l1lll111_l1_(False)
	l1lllllll11l_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡲࠬ屙")
	l1llll1ll11ll_l1_ = l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ屚")
	l1llll1ll1111_l1_ = l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ屛")
	for id,l1l11l11l1ll_l1_,l1l11lll111l_l1_,l111l11lll1_l1_,l111l111ll1_l1_,reason in reversed(l1l1ll11ll1l_l1_):
		if id==l11ll1_l1_ (u"ࠬ࠶ࠧ屜"):
			l1llll1lll11_l1_,l1llll1lll1l_l1_ = l111l11lll1_l1_.split(l11ll1_l1_ (u"࠭࡜࡯࠽࠾ࠫ屝"))
			continue
		if l1lllllll11l_l1_!=l11ll1_l1_ (u"ࠧ࡝ࡰࠪ属"): l1lllllll11l_l1_ += l1llll1ll1111_l1_
		l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ屟")+id+l11ll1_l1_ (u"ࠩࠣ࠾ࠥ࠭屠")+l11ll1_l1_ (u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭屡")+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭屢")+l1l11lll111l_l1_
		l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆฯ์ฬฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ屣")+l111l11lll1_l1_
		l111l1lll1l1_l1_ = l11ll1_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺวࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ層")+l111l111ll1_l1_
		l111l1lll1ll_l1_ = l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟สุ่ฮศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ履")+reason
		l1lllllll11l_l1_ += l1ll11l11ll_l1_+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ屦")+l1llll1ll11ll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ屧")+l111l1lll1l1_l1_+l111l1lll1ll_l1_+l11ll1_l1_ (u"ࠪࡠࡳ࠭屨")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ屩"),l1llll1lll1l_l1_,l1lllllll11l_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭屪"))
	return
def l1llll111l11l_l1_(file):
	if file==favoritesfile: l1lll1ll11ll1_l1_ = l11ll1_l1_ (u"࠭โ้ษษ้ࠥอไๆใู่ฮ࠭屫")
	elif file==l1l11l11lll1_l1_: l1lll1ll11ll1_l1_ = l11ll1_l1_ (u"ࠧศๆิืฬฬไࠨ屬")
	elif file==l1l111l11l1_l1_: l1lll1ll11ll1_l1_ = l11ll1_l1_ (u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨ屭")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ屮"),l11ll1_l1_ (u"ุ้ࠪำࠧ屯"),l11ll1_l1_ (u"ࠫส฻ไศฯࠪ屰"),l11ll1_l1_ (u"ࠬิั้ฮࠪ山"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ屲"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬ屳")+l1lll1ll11ll1_l1_+l11ll1_l1_ (u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨ屴"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ屵"),l11ll1_l1_ (u"ࠪࠫ屶"),l11ll1_l1_ (u"ࠫࠬ屷"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭屸"),l11ll1_l1_ (u"࠭ࠧ屹"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ屺"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭屻")+l1lll1ll11ll1_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ屼"),l11ll1_l1_ (u"ࠪࠫ屽"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ屾"),l11ll1_l1_ (u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬ屿")+l1lll1ll11ll1_l1_)
	return
def l1lll111l11ll_l1_():
	if kodi_version<18:
		message = l11ll1_l1_ (u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩ岀")+str(kodi_version)+l11ll1_l1_ (u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨ岁")
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岂"),l11ll1_l1_ (u"ࠩࠪ岃"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭岄"),message)
		return
	l111l11llll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ岅"))
	l1l11ll11111_l1_ = l1lll1l11l11_l1_([l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ岆")])
	l1l11l1111l1_l1_,l1llll1111ll1_l1_,l1llll111l111_l1_,l1llll1111lll_l1_,l1llll1111l11_l1_,l1lll111ll11l_l1_,l1llll1111l1l_l1_ = l1l11ll11111_l1_[l11ll1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ岇")]
	if l1l11l1111l1_l1_ or l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭岈") not in str(l111l11llll_l1_):
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ岉"),l11ll1_l1_ (u"ࠩࠪ岊"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭岋"),l11ll1_l1_ (u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ岌"))
		succeeded = l1lll1lll1lll_l1_(l11ll1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ岍"),True)
		if not succeeded: return
	l11l1l11l11_l1_(True)
	return
	l11ll1_l1_ (u"ࠨࠢࠣࠌࠌࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠧࠪࠌࠌ࡭࡫ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࡀࡁࠬ࠻࠴࠵ࠩ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩࠍࠍࡪࡲࡩࡧࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࡃ࠽ࠨ࠷࠸࠹ࠬࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤฬ๊ี้ำࠪࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡ็ฯ๋ํ๊ษࠨࠌࠌ࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠱࠼ࠌࠍࠨࠦࡡ࡯ࡻࠣࡳࡹ࡮ࡥࡳࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎࠏࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭ࠧࠋࠋࠌࠧ࡮ࡳࡰࡰࡴࡷࠤࡸࡷ࡬ࡪࡶࡨ࠷ࠏࠏࠉࡤࡱࡱࡲࠥࡃࠠࡴࡳ࡯࡭ࡹ࡫࠳࠯ࡥࡲࡲࡳ࡫ࡣࡵࠪࡹ࡭ࡪࡽࡳࡠࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࠍࡨࡩࠠ࠾ࠢࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪࠌࠌࠍࡨࡵ࡮࡯࠰ࡷࡩࡽࡺ࡟ࡧࡣࡦࡸࡴࡸࡹࠡ࠿ࠣࡷࡹࡸࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠳࠼࠻࠶࠷࠷ࠡ࠽ࠪ࠭ࠏࠏࠉࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࡻ࡯ࡥࡸࠤ࡛ࠣࡍࡋࡒࡆࠢࡹ࡭ࡪࡽࡍࡰࡦࡨࠤࡂࠦ࠶࠷࠲࠻࠴ࠥࡁࠧࠪࠌࠌࠍࡨࡵ࡮࡯࠰ࡦࡳࡲࡳࡩࡵࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࡥ࡭࡫ࡩࠤࡨ࡮࡯ࡪࡥࡨࡁࡂ࠷࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨ࠷࠷࠸ࠬࠏࠣࠡࠤࡏ࡭ࡸࡺࠠࡆ࡯ࡤࡨࠧࠦࡶࡪࡧࡺࡸࡾࡶࡥࠋࠋࡨࡰ࡮࡬ࠠࡤࡪࡲ࡭ࡨ࡫࠽࠾࠴࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠡ࠿ࠣࠫ࠺࠻࠵ࠨࠋࠦࠤࠧࡍࡡ࡭࡮ࡨࡶࡾࡥࡅ࡮ࡣࡧࠦࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠭ࠬࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇ࠭ࠏࠏࠢࠣࠤ岎")
def l11l1l11l11_l1_(l1ll_l1_=True):
	l111l11llll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ岏"))
	if l11ll1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ岐") not in str(l111l11llll_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ岑"),l11ll1_l1_ (u"ࠪࠫ岒"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ岓"),l11ll1_l1_ (u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ岔"))
		return
	l1llll111lll1_l1_ = os.path.join(l1l1l11111_l1_,l11ll1_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭岕"),l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭岖"),l11ll1_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭岗"),l11ll1_l1_ (u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪ岘"))
	if not os.path.exists(l1llll111lll1_l1_): return
	l1l1111111l_l1_ = open(l1llll111lll1_l1_,l11ll1_l1_ (u"ࠪࡶࡧ࠭岙")).read()
	if kodi_version>18.99: l1l1111111l_l1_ = l1l1111111l_l1_.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ岚"))
	l1lll111l1111_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠮࡜ࡥ࠭࠯ࡠࡩ࠱ࠬ࡝ࡦ࠮࠭࠱࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ岛"),l1l1111111l_l1_,re.DOTALL)
	l1lll111lll11_l1_,l1llll1l1lll1_l1_ = l1lll111l1111_l1_[0]
	l1llll11lll1l_l1_ = l11ll1_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ岜")+l1lll111lll11_l1_+l11ll1_l1_ (u"ࠧ࠭ࠩ岝")+l1llll1l1lll1_l1_+l11ll1_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ岞")
	if l1ll_l1_:
		l1llll11llll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡜ࡩࡦࡹࡰࡳࡩ࡫ࠧ岟"))
		if l1llll11llll1_l1_==l11ll1_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭岠"): l11l1lllll1_l1_ = l11ll1_l1_ (u"ࠫ็๎วว็ࠣห้้สศสฬࠫ岡")
		elif l1llll11llll1_l1_==l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ岢"): l11l1lllll1_l1_ = l11ll1_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ岣")
		else: l11l1lllll1_l1_ = l11ll1_l1_ (u"ࠧใ๊สส๊ࠦรฯำ์ࠫ岤")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ岥"),l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭岦"),l11ll1_l1_ (u"ࠪๆํอฦๆࠢส่่ะวษหࠪ岧"),l11ll1_l1_ (u"ࠫ็๎วว็ࠣห้฻่าࠩ岨"),l11ll1_l1_ (u"ࠬอๆหࠢะห้๐วࠡฬึฮำีๅࠡࠩ岩")+l11l1lllll1_l1_,l11ll1_l1_ (u"࠭ว็ฬࠣห้ศๆࠡฬึฮำีๅࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๋๋ࠢีอࠠๆ฻้ห์ࠦว็ๅࠣฮุะื๋฻ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦศะๆสࠤ๊์ࠠใ๊สส๊ࠦวๅๅอหอฯࠠ࠯๋ࠢว๏฼วࠡฬึฮ฼๐ูࠡวํๆฬ็็ศࠢไ๎ࠥษ๊๊ࠡๅฮࠥะิศรࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤศิสาࠢส่ว์ࠠ็๊฼ࠤฬ๊โ้ษษ้ࠥอไห์ࠣฮึ๐ฯࠡลึฮำีวๆ้สࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ岪"))
		if choice==1: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ岫")
		elif choice==2: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ岬")
		else: l1lll1ll11l11_l1_ = l11ll1_l1_ (u"ࠩࠪ岭")
	else:
		l1llll11llll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭岮"))
		if   l1llll11llll1_l1_==l11ll1_l1_ (u"ࠫࠬ岯"): choice = 0
		elif l1llll11llll1_l1_==l11ll1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ岰"): choice = 1
		elif l1llll11llll1_l1_==l11ll1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ岱"): choice = 2
		l1lll1ll11l11_l1_ = l1llll11llll1_l1_
	if   choice==0: l1lll1l1l1ll1_l1_ = l11ll1_l1_ (u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫ岲")
	elif choice==1: l1lll1l1l1ll1_l1_ = l11ll1_l1_ (u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬ岳")
	elif choice==2: l1lll1l1l1ll1_l1_ = l11ll1_l1_ (u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭岴")
	else: return
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭岵"),l1lll1ll11l11_l1_)
	l1lll11l11l11_l1_ = l11ll1_l1_ (u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬ岶")+l1lll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠬ࠲ࠧ岷")+l1llll1l1lll1_l1_+l11ll1_l1_ (u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ岸")
	l11llll11l1_l1_ = l1l1111111l_l1_.replace(l1llll11lll1l_l1_,l1lll11l11l11_l1_)
	if kodi_version>18.99: l11llll11l1_l1_ = l11llll11l1_l1_.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ岹"))
	open(l1llll111lll1_l1_,l11ll1_l1_ (u"ࠨࡹࡥࠫ岺")).write(l11llll11l1_l1_)
	LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ岻"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡔ࡭࡬ࡲࠥࡊࡥࡧࡣࡸࡰࡹࠦࡖࡪࡧࡺࡷ࠿࡛ࠦࠡࠩ岼")+l1lll1l1l1ll1_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ岽"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡘࡥ࡭ࡱࡤࡨࡘࡱࡩ࡯ࠪࠬࠫ岾"))
	return
def l1lll11l111l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ岿"),l11ll1_l1_ (u"ࠧไๆสࠫ峀"),l11ll1_l1_ (u"ࠨ่฼้ࠬ峁"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ峂"),l11ll1_l1_ (u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣว้หีะษิࠤ็ี๊ๆࠢ࠱࠲࠳ࠦร้ࠢส๊ฯࠦๅๆ่๋฽๋ࠥๆࠡษึฮำีวๆࠢส่อืๆศ็ฯࠤ࠳࠴࠮ࠡล๋ࠤ้ี๊ไุ่่๊ࠢษࠡลัี๎ࠦสฯืࠣะ์อาไࠢฦ๊ฯ่ࠦๅษࠣฮำ฻ࠠษไํอࠥิไใࠢส่้ํࠠ࡝ࡰ࡟ࡲࠥำว้ๆࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤศ๎ࠠศฬุ่ࠥฮวๅ็หี๊าࠠๅ็฼ีๆฯࠠิสหࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥอไหฯา๎ะอสࠡษ็ฦ๋ࠦฟࠨ峃"))
	if l1ll111ll1_l1_==1: l1ll1l11ll11_l1_()
	return
def l1lll1l11ll1l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ峄"),l11ll1_l1_ (u"ࠬ࠭峅"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ峆"),l11ll1_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆࠪ峇"))
	return
def l1lll1llll1ll_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ峈")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨ峉")
	l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭峊")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ峋")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩ峌")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ峍")
	message = l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭峎")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭峏")+l1ll11l1l11_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ峐"),l11ll1_l1_ (u"ࠪࠫ峑"),message)
	return
def l1l111ll1ll_l1_(l1l11l1llll_l1_):
	try: status = l111l11l111_l1_(l1l11l1llll_l1_,False)
	except: pass
	l1l1ll11ll1l_l1_ = l11l1lll111_l1_(l1l11l1llll_l1_)
	id,l1l11l11l1ll_l1_,l1l11lll111l_l1_,l111l11lll1_l1_,l111l111ll1_l1_,reason = l1l1ll11ll1l_l1_[0]
	l1llll1lll11_l1_,l1llll1lll1l_l1_ = l111l11lll1_l1_.split(l11ll1_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ峒"))
	l1ll11l1l11_l1_,l111l1lll1l1_l1_,l111l1lll1ll_l1_ = l111l111ll1_l1_.split(l11ll1_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ峓"))
	l1l11l11l111_l1_ = True
	while l1l11l11l111_l1_:
		l1lll1l1l111l_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ峔"),l11ll1_l1_ (u"ࠧฯำ๋ะࠬ峕"),l11ll1_l1_ (u"ࠨวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศ࠭峖"),l11ll1_l1_ (u"ࠩๅหห๋ษࠡษ็ฮอืูศฬࠪ峗"),l11ll1_l1_ (u"่ࠪส๐โศใࠣห้หูๅษ้หฯࠦโๆࠢหห้ะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ัࠦๅ็ࠢฯ๋ฬุใࠨ峘"),l1ll11l1l11_l1_)
		if l1lll1l1l111l_l1_==2: l1lll1l1l1111_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ峙"),l11ll1_l1_ (u"ࠬ࠭峚"),l11ll1_l1_ (u"ู้࠭ัฬࠫ峛"),l11ll1_l1_ (u"ࠧࠨ峜"),l11ll1_l1_ (u"ࠨษ็ห฾ะัศุࠣ฽้๏ࠠๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧ峝"),l111l1lll1l1_l1_,l11ll1_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭峞"))
		elif l1lll1l1l111l_l1_==1: l1ll111l1111_l1_()
		else: l1l11l11l111_l1_ = False
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ峟"))
	return
def l1lll11l1111l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ峠"),l11ll1_l1_ (u"ࠬ࠭峡"),l11ll1_l1_ (u"࠭ࠧ峢"),l11ll1_l1_ (u"ࠧิฦส่ࠬ峣"),l11ll1_l1_ (u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ峤"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_:
		succeeded = True
		if os.path.exists(l1ll1111111l_l1_):
			try: os.remove(l1ll1111111l_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ峥"),l11ll1_l1_ (u"ࠪࠫ峦"),l11ll1_l1_ (u"ࠫࠬ峧"),l11ll1_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤํะีโ์ิࠤ๊๊แࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ峨"))
		else: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ峩"),l11ll1_l1_ (u"ࠧࠨ峪"),l11ll1_l1_ (u"ࠨࠩ峫"),l11ll1_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่่ࠢๆࠦวๅว฼ำฬีวหࠩ峬"))
	return
def l1lll1lll111l_l1_():
	l1lll1l1l1lll_l1_()
	l1llll1l111ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ峭"))
	message = {}
	message[l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ峮")] = l11ll1_l1_ (u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫ峯")
	message[l11ll1_l1_ (u"࠭ࡓࡕࡑࡓࠫ峰")] = l11ll1_l1_ (u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭峱")
	message[l11ll1_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ峲")] = l11ll1_l1_ (u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪ峳")+str(l11llll1111_l1_/60)+l11ll1_l1_ (u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧ峴")
	l1lll11lll11l_l1_ = message[l1llll1l111ll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ峵"),l11ll1_l1_ (u"้ࠬวีࠢࠪ島")+str(l11llll1111_l1_/60)+l11ll1_l1_ (u"࠭ࠠะไํๆฮ࠭峷"),l11ll1_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭峸"),l11ll1_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ峹"),l1lll11lll11l_l1_,l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬ峺"))
	if choice==0: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ峻")
	elif choice==1: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ峼")
	elif choice==2: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ峽")
	else: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"࠭ࠧ峾")
	if l1lll11ll1ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ峿"),l1lll11ll1ll1_l1_)
		l1lll11l1l1l1_l1_ = message[l1lll11ll1ll1_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ崀"),l11ll1_l1_ (u"ࠩࠪ崁"),l11ll1_l1_ (u"ࠪࠫ崂"),l1lll11l1l1l1_l1_)
	return
def l1lll1l11l111_l1_():
	message = {}
	message[l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ崃")] = l11ll1_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪ崄")
	message[l11ll1_l1_ (u"࠭ࡁࡔࡍࠪ崅")] = l11ll1_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫ崆")
	message[l11ll1_l1_ (u"ࠨࡕࡗࡓࡕ࠭崇")] = l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ崈")
	l1llll11l11ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ崉"))
	l1llll1l111ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ崊"))
	l1lll11lll11l_l1_ = message[l1llll1l111ll_l1_]+l1llll11l11ll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭崋"),l11ll1_l1_ (u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ崌"),l11ll1_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭崍"),l11ll1_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ崎"),l1lll11lll11l_l1_,l11ll1_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭崏"))
	if choice==0: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠪࡅࡘࡑࠧ崐")
	elif choice==1: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ崑")
	elif choice==2: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"࡙ࠬࡔࡐࡒࠪ崒")
	if choice in [0,1]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭崓"),l11ll1_l1_ (u"ࠧิ์ิๅึࡀࠠࠨ崔")+l1llll1l1ll1_l1_[1],l11ll1_l1_ (u"ࠨีํีๆื࠺ࠡࠩ崕")+l1llll1l1ll1_l1_[0],l11ll1_l1_ (u"ࠩࠪ崖"),l11ll1_l1_ (u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩ崗"))
		if l1ll111ll1_l1_==1: l111l1lllll_l1_ = l1llll1l1ll1_l1_[0]
		else: l111l1lllll_l1_ = l1llll1l1ll1_l1_[1]
	elif choice==2: l111l1lllll_l1_ = l11ll1_l1_ (u"ࠫࠬ崘")
	else: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭崙")
	if l1lll11ll1ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭崚"),l1lll11ll1ll1_l1_)
		settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ崛"),l111l1lllll_l1_)
		l1lll11l1l1l1_l1_ = message[l1lll11ll1ll1_l1_]+l111l1lllll_l1_
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ崜"),l11ll1_l1_ (u"ࠩࠪ崝"),l11ll1_l1_ (u"ࠪࠫ崞"),l1lll11l1l1l1_l1_)
	return
def l1lll1l1lllll_l1_():
	l1llll1l111ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭崟"))
	message = {}
	message[l11ll1_l1_ (u"ࠬࡇࡕࡕࡑࠪ崠")] = l11ll1_l1_ (u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧ崡")
	message[l11ll1_l1_ (u"ࠧࡂࡕࡎࠫ崢")] = l11ll1_l1_ (u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩ崣")
	message[l11ll1_l1_ (u"ࠩࡖࡘࡔࡖࠧ崤")] = l11ll1_l1_ (u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ崥")
	l1lll11lll11l_l1_ = message[l1llll1l111ll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ崦"),l11ll1_l1_ (u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ崧"),l11ll1_l1_ (u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ崨"),l11ll1_l1_ (u"ࠧฦ์ๅหๆࠦใศ็็ࠫ崩"),l1lll11lll11l_l1_,l11ll1_l1_ (u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫ崪"))
	if choice==0: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠩࡄࡗࡐ࠭崫")
	elif choice==1: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ崬")
	elif choice==2: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ崭")
	else: l1lll11ll1ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭崮")
	if l1lll11ll1ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ崯"),l1lll11ll1ll1_l1_)
		l1lll11l1l1l1_l1_ = message[l1lll11ll1ll1_l1_]
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ崰"),l11ll1_l1_ (u"ࠨࠩ崱"),l11ll1_l1_ (u"ࠩࠪ崲"),l1lll11l1l1l1_l1_)
	return
def l1lll1llll11l_l1_():
	l1l11l1l11ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ崳"))
	if l1l11l1l11ll_l1_==l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ崴"): header = l11ll1_l1_ (u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ崵")
	else: header = l11ll1_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ崶")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࠨ崷"),l11ll1_l1_ (u"ࠨวํๆฬ็ࠧ崸"),l11ll1_l1_ (u"ࠩอๅ฾๐ไࠨ崹"),header,l11ll1_l1_ (u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮่ๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭崺"))
	if l1ll111ll1_l1_==-1: return
	elif l1ll111ll1_l1_:
		settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ崻"),l11ll1_l1_ (u"ࠬ࠭崼"))
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ崽"),l11ll1_l1_ (u"ࠧࠨ崾"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ崿"),l11ll1_l1_ (u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫ嵀"))
	else:
		settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ嵁"),l11ll1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ嵂"))
		DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭嵃"),l11ll1_l1_ (u"࠭ࠧ嵄"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嵅"),l11ll1_l1_ (u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ嵆"))
	return
def l1lll1l1ll111_l1_(text):
	if text!=l11ll1_l1_ (u"ࠩࠪ嵇"):
		text = l1l1l11ll1l_l1_(text)
		text = text.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ嵈")).encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嵉"))
		l1l1l1l1111_l1_ = 10103
		l1l1l11lll1_l1_ = xbmcgui.l1l1l111ll1_l1_(l1l1l1l1111_l1_)
		l1l1l11lll1_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l1111l11_l1_ = xbmcgui.WindowXMLDialog(l11ll1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡐ࡫ࡹࡣࡱࡤࡶࡩ࠸࠲࠯ࡺࡰࡰࠬ嵊"), xbmcaddon.Addon().getAddonInfo(l11ll1_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ嵋")).decode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嵌")),l11ll1_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ嵍"),l11ll1_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ嵎"))
		#l1l1l1111l11_l1_.show()
		#l1l1l1111l11_l1_.getControl(99991).setPosition(0,0)
		#l1l1l1111l11_l1_.getControl(311).l1l1l1l11ll_l1_(text)
		#l1l1l1111l11_l1_.getControl(5).l1lll11llll1_l1_(l1llll111llll_l1_)
		#width = xbmcgui.l1lll11ll11l1_l1_()
		#l1ll11ll1l1l_l1_ = xbmcgui.l1lll1ll1l1l1_l1_()
		#resolution = (0.0+width)/l1ll11ll1l1l_l1_
		#l1l1l1111l11_l1_.getControl(5).l1l11lll1ll1_l1_(width-180)
		#l1l1l1111l11_l1_.getControl(5).setHeight(l1ll11ll1l1l_l1_-180)
		#l1l1l1111l11_l1_.doModal()
		#del l1l1l1111l11_l1_
	return
l1lll111llll1_l1_ = [
			 l11ll1_l1_ (u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࠧࠨࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣ嵏")
			,l11ll1_l1_ (u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧ嵐")
			,l11ll1_l1_ (u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧ嵑")
			,l11ll1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨ嵒")
			,l11ll1_l1_ (u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨ嵓")
			,l11ll1_l1_ (u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪ嵔")
			,l11ll1_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠤࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧ嵕")
			,l11ll1_l1_ (u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭嵖")
			,l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡁ࠵ࠬࡴࡦࡺࡷࡁࠬ嵗")
			,l11ll1_l1_ (u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭嵘")
			,l11ll1_l1_ (u"࠭࡞࡟ࡠࡡࡢࠬ嵙")
			,l11ll1_l1_ (u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬ嵚")
			]
def l1lll1l11l1ll_l1_(line):
	if l11ll1_l1_ (u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭嵛") in line and l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ嵜") in line: return True
	for text in l1lll111llll1_l1_:
		if text in line: return True
	return False
def l1lll1111ll1l_l1_(data):
	data = data.replace(l11ll1_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ嵝")+51*l11ll1_l1_ (u"ࠫࠥ࠭嵞")+l11ll1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ嵟"),l11ll1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ嵠"))
	data = data.replace(l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嵡")+51*l11ll1_l1_ (u"ࠨࠢࠪ嵢")+l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ嵣"),l11ll1_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ嵤"))
	data = data.replace(l11ll1_l1_ (u"ࠫࡡࡴࠧ嵥")+51*l11ll1_l1_ (u"ࠬࠦࠧ嵦")+l11ll1_l1_ (u"࠭࡜࡯ࠩ嵧"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ嵨"))
	data = data.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ嵩")+51*l11ll1_l1_ (u"ࠩࠣࠫ嵪"),l11ll1_l1_ (u"ࠪࡠࡳ࠭嵫")+31*l11ll1_l1_ (u"ࠫࠥ࠭嵬"))
	#data = data.replace(l11ll1_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰࠰ࡃࡱࡨࡷࡵࡩࡥ࠱ࡧࡥࡹࡧ࠯ࡰࡴࡪ࠲ࡽࡨ࡭ࡤ࠰࡮ࡳࡩ࡯࠯ࡧ࡫࡯ࡩࡸ࠵࠮࡬ࡱࡧ࡭࠴ࡧࡤࡥࡱࡱࡷ࠴࠭嵭"),l11ll1_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠫ嵮"))
	data = data.replace(l11ll1_l1_ (u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭嵯"),l11ll1_l1_ (u"ࠨ࠼ࠣࠫ嵰"))
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠩࠪ嵱")
	for line in data.splitlines():
		delete = re.findall(l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ嵲"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11ll1_l1_ (u"ࠫࠬ嵳"))
		l11ll11l1_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ嵴")+line
	#WRITE_THIS(l11ll1_l1_ (u"࠭ࠧ嵵"),l11ll11l1_l1_)
	return l11ll11l1_l1_
def l1lll111ll1l1_l1_(l1lll1ll11l1l_l1_):
	if l11ll1_l1_ (u"ࠧࡐࡎࡇࠫ嵶") in l1lll1ll11l1l_l1_:
		l1llll11l1l11_l1_ = l1lll1l1l111_l1_
		header = l11ll1_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ嵷")
	else:
		l1llll11l1l11_l1_ = l1ll1llll1ll_l1_
		header = l11ll1_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ嵸")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࠫ嵹"),l11ll1_l1_ (u"ࠫࠬ嵺"),l11ll1_l1_ (u"ࠬ࠭嵻"),header,l11ll1_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ嵼"))
	if l1ll111ll1_l1_!=1: return
	l1lll111l111l_l1_,counts = [],0
	size,count = l1l1l11ll1_l1_(l1llll11l1l11_l1_)
	#size = os.path.getsize(l1llll11l1l11_l1_)
	file = open(l1llll11l1l11_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ嵽"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭嵾"))
	data = l1lll1111ll1l_l1_(data)
	lines = data.split(l11ll1_l1_ (u"ࠩ࡟ࡲࠬ嵿"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ嶀"))
		#if line.strip(l11ll1_l1_ (u"ࠫࠥ࠭嶁"))==l11ll1_l1_ (u"ࠬ࠭嶂"): continue
		ignore = l1lll1l11l1ll_l1_(line)
		if ignore: continue
		line = line.replace(l11ll1_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡤ࠭嶃"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ嶄"))
		line = line.replace(l11ll1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ嶅"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嶆"))
		l1lll1ll11lll_l1_ = l11ll1_l1_ (u"ࠪࠫ嶇")
		l1lll111lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ嶈"),line,re.DOTALL)
		if l1lll111lll1l_l1_:
			line = line.replace(l1lll111lll1l_l1_[0][0],l1lll111lll1l_l1_[0][1]).replace(l1lll111lll1l_l1_[0][2],l11ll1_l1_ (u"ࠬ࠭嶉"))
			l1lll1ll11lll_l1_ = l1lll111lll1l_l1_[0][1]
		else:
			l1lll111lll1l_l1_ = re.findall(l11ll1_l1_ (u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭嶊"),line,re.DOTALL)
			if l1lll111lll1l_l1_:
				line = line.replace(l1lll111lll1l_l1_[0][1],l11ll1_l1_ (u"ࠧࠨ嶋"))
				l1lll1ll11lll_l1_ = l1lll111lll1l_l1_[0][0]
		if l1lll1ll11lll_l1_: line = line.replace(l1lll1ll11lll_l1_,l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ嶌")+l1lll1ll11lll_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嶍"))
		l1lll111l111l_l1_.append(line)
		if len(str(l1lll111l111l_l1_))>50100: break
	l1lll111l111l_l1_ = reversed(l1lll111l111l_l1_)
	l1llll111llll_l1_ = l11ll1_l1_ (u"ࠪࡠࡳ࠭嶎").join(l1lll111l111l_l1_)
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ嶏"),l11ll1_l1_ (u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ嶐"),l1llll111llll_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ嶑"))
	return
def l1lll1l111l1l_l1_():
	l1llll11l1l1l_l1_ = open(l1ll1111lll1_l1_,l11ll1_l1_ (u"ࠧࡳࡤࠪ嶒")).read()
	if kodi_version>18.99: l1llll11l1l1l_l1_ = l1llll11l1l1l_l1_.decode(l11ll1_l1_ (u"ࠨࡷࡷࡪ࠽࠭嶓"))
	l1llll11l1l1l_l1_ = l1llll11l1l1l_l1_.replace(l11ll1_l1_ (u"ࠩ࡟ࡸࠬ嶔"),l11ll1_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬ嶕"))
	l1l11ll11111_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ嶖"),l1llll11l1l1l_l1_,re.DOTALL)
	for line in l1l11ll11111_l1_:
		l1llll11l1l1l_l1_ = l1llll11l1l1l_l1_.replace(line,l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ嶗")+line+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ嶘"))
	DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨ嶙"),l1llll11l1l1l_l1_)
	return
def l1lll1llll111_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪ嶚")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭嶛")
	l111l1lll1l1_l1_ = l11ll1_l1_ (u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭嶜")
	message = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ嶝")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࠦ࠮ࠡࠩ嶞")+l111l1lll1l1_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭嶟"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嶠"),message,l11ll1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ嶡"))
	return
def l111ll11111_l1_(type,message,l1ll_l1_=True,url=l11ll1_l1_ (u"ࠩࠪ嶢"),source=l11ll1_l1_ (u"ࠪࠫ嶣"),text=l11ll1_l1_ (u"ࠫࠬ嶤"),l111llll1111_l1_=l11ll1_l1_ (u"ࠬ࠭嶥")):
	l1lll1111l111_l1_ = True
	if not l11lll1lll1_l1_(l11ll1_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ嶦")):
		if l1ll_l1_:
			#if message.count(l11ll1_l1_ (u"ࠧ࡝࡞ࡱࠫ嶧"))>1: l1ll11l11l1l_l1_ = l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ嶨")
			#else: l1ll11l11l1l_l1_ = l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ嶩")
			l1lll11l11l1l_l1_ = (l11ll1_l1_ (u"ࠪหู้ืา࠼ࠪ嶪") in message and l11ll1_l1_ (u"ࠫฬ๊ๅไษ้࠾ࠬ嶫") in message and l11ll1_l1_ (u"ࠬอไๆๆไ࠾ࠬ嶬") in message and l11ll1_l1_ (u"࠭วๅะฺวࠬ嶭") in message and l11ll1_l1_ (u"ࠧศๆู่ิื࠺ࠨ嶮") in message)
			if not l1lll11l11l1l_l1_: l1lll1111l111_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ嶯"),l11ll1_l1_ (u"ࠩࠪ嶰"),l11ll1_l1_ (u"ࠪࠫ嶱"),l11ll1_l1_ (u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ嶲"),message.replace(l11ll1_l1_ (u"ࠬࡢ࡜࡯ࠩ嶳"),l11ll1_l1_ (u"࠭࡜࡯ࠩ嶴")))
	elif l1ll_l1_:
		message = l11ll1_l1_ (u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧ嶵")
		l1llll1l11ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ嶶"),l11ll1_l1_ (u"ࠩࠪ嶷"),l11ll1_l1_ (u"ࠪࠫ嶸"),l11ll1_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ嶹")+l11ll1_l1_ (u"ࠬࠦࠠ࠲࠱࠸ࠫ嶺"),l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ嶻"))
		l1llll1l11l1l_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ嶼"),l11ll1_l1_ (u"ࠨࠩ嶽"),l11ll1_l1_ (u"ࠩࠪ嶾"),l11ll1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ嶿")+l11ll1_l1_ (u"ࠫࠥࠦ࠲࠰࠷ࠪ巀"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ巁"))
		l1llll1l11l11_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭巂"),l11ll1_l1_ (u"ࠧࠨ巃"),l11ll1_l1_ (u"ࠨࠩ巄"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ巅")+l11ll1_l1_ (u"ࠪࠤࠥ࠹࠯࠶ࠩ巆"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ巇"))
		l1llll1l1l11l_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ巈"),l11ll1_l1_ (u"࠭ࠧ巉"),l11ll1_l1_ (u"ࠧࠨ巊"),l11ll1_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ巋")+l11ll1_l1_ (u"ࠩࠣࠤ࠹࠵࠵ࠨ巌"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ巍"))
		l1lll1111l111_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ巎"),l11ll1_l1_ (u"ࠬ࠭巏"),l11ll1_l1_ (u"࠭ࠧ巐"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ巑")+l11ll1_l1_ (u"ࠨࠢࠣ࠹࠴࠻ࠧ巒"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ巓"))
	user = l1l11l111ll_l1_(32,False)
	l1llll11111ll_l1_ = l11ll1_l1_ (u"ࠪࡅ࡛ࡀࠠࠨ巔")+user+l11ll1_l1_ (u"ࠫ࠲࠭巕")+type
	l1l11l1ll1l1_l1_ = True if l11ll1_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ巖") in text else False
	if not l1lll1111l111_l1_:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ巗"),l11ll1_l1_ (u"ࠧࠨ巘"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ巙"),l11ll1_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠥฮๆศรࠣ฽้๏ุࠠๆห็ࠬ巚"))
		return False
	l1llll1l1l1l1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩ巛"))
	message += l11ll1_l1_ (u"ࠫࠥࡢ࡜࡯࡞࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡢ࡜࡯ࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪ巜")+l11llll111l_l1_+l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ川")
	message += l11ll1_l1_ (u"࠭ࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧ州")+user+l11ll1_l1_ (u"ࠧࠡ࠼࡟ࡠࡳࡑ࡯ࡥ࡫࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭巟")+l1l111l1l1l_l1_+l11ll1_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ巠")
	message += l11ll1_l1_ (u"ࠩࡎࡳࡩ࡯ࠠࡏࡣࡰࡩ࠿ࠦࠧ巡")+l1llll1l1l1l1_l1_
	#l1l111l1111_l1_ = l11lll1111l_l1_(l11ll1_l1_ (u"ࠪ࠻࠻࠴࠶࠶࠰࠴࠷࠽࠴࠲࠴࠲ࠪ巢"))
	l1lllll11lll_l1_ = l11lll1111l_l1_()
	l1lllll11lll_l1_ = QUOTE(l1lllll11lll_l1_)
	if l1lllll11lll_l1_: message += l11ll1_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭巣")+l1lllll11lll_l1_
	if url: message += l11ll1_l1_ (u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩ巤")+url
	if source: message += l11ll1_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭工")+source
	message += l11ll1_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭左")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧ巧"),l11ll1_l1_ (u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫ巨"))
	if l111llll1111_l1_:
		l1llll111llll_l1_ = l111llll1111_l1_
		if kodi_version>18.99: l1llll111llll_l1_ = l1llll111llll_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ巩"))
		l1llll111llll_l1_ = base64.b64encode(l1llll111llll_l1_)
	elif l1l11l1ll1l1_l1_:
		if l11ll1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫ巪") in text: l1llll1l111l1_l1_ = l1lll1l1l111_l1_
		else: l1llll1l111l1_l1_ = l1ll1llll1ll_l1_
		if not os.path.exists(l1llll1l111l1_l1_):
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭巫"),l11ll1_l1_ (u"࠭ࠧ巬"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ巭"),l11ll1_l1_ (u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭差"))
			return False
		l1lll111l111l_l1_,counts = [],0
		size,count = l1l1l11ll1_l1_(l1llll1l111l1_l1_)
		#size = os.path.getsize(l1llll1l111l1_l1_)
		file = open(l1llll1l111l1_l1_,l11ll1_l1_ (u"ࠩࡵࡦࠬ巯"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ巰"))
		data = l1lll1111ll1l_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ己"))
			ignore = l1lll1l11l1ll_l1_(line)
			if ignore: continue
			l1lll111lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ已"),line,re.DOTALL)
			if l1lll111lll1l_l1_:
				line = line.replace(l1lll111lll1l_l1_[0][0],l1lll111lll1l_l1_[0][1]).replace(l1lll111lll1l_l1_[0][2],l11ll1_l1_ (u"࠭ࠧ巳"))
			else:
				l1lll111lll1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ巴"),line,re.DOTALL)
				if l1lll111lll1l_l1_: line = line.replace(l1lll111lll1l_l1_[0][1],l11ll1_l1_ (u"ࠨࠩ巵"))
			l1lll111l111l_l1_.append(line)
			if len(str(l1lll111l111l_l1_))>121000: break
		l1lll111l111l_l1_ = reversed(l1lll111l111l_l1_)
		l1llll111llll_l1_ = l11ll1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ巶").join(l1lll111l111l_l1_)
		l1llll111llll_l1_ = l1llll111llll_l1_.encode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ巷"))
		l1llll111llll_l1_ = base64.b64encode(l1llll111llll_l1_)
	else: l1llll111llll_l1_ = l11ll1_l1_ (u"ࠫࠬ巸")
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ巹")][2]
	payload = {l11ll1_l1_ (u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ巺"):l1llll11111ll_l1_,l11ll1_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ巻"):message,l11ll1_l1_ (u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ巼"):l1llll111llll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ巽"),url,payload,l11ll1_l1_ (u"ࠪࠫ巾"),l11ll1_l1_ (u"ࠫࠬ巿"),l11ll1_l1_ (u"ࠬ࠭帀"),l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ币"))
	#succeeded = response.succeeded
	html = response.content
	if l11ll1_l1_ (u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ市") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠬ布"),l11ll1_l1_ (u"ࠩห๊ัออࠨ帄"))
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ帅"),l11ll1_l1_ (u"ࠫࠬ帆"),l11ll1_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫ帇"),l11ll1_l1_ (u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ师"))
		else:
			DIALOG_NOTIFICATION(l11ll1_l1_ (u"ࠧๅๆฦืๆ࠭帉"),l11ll1_l1_ (u"ࠨใื่ࠥ็๊ࠡษ็ษึูวๅࠩ帊"))
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ帋"),l11ll1_l1_ (u"ࠪࠫ希"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ帍"),l11ll1_l1_ (u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ帎"))
	return succeeded
def l1lll1111l1l1_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ帏")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢส่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ帐")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ帑"),l11ll1_l1_ (u"ࠩࠪ帒"),l11ll1_l1_ (u"ࠪࡅࡷࡧࡢࡪࡥࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ帓"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ帔")+l1ll11l1l11_l1_)
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠬ࠸࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠫ帕")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"࠭࠲࠯ࠢࠣࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโไ่ࠤอะฺ๋์ิࠤฬ๊ฬๅัࠣฯ๊ࠦโๆࠢหฮ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡษ็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭帖")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ帗"),l11ll1_l1_ (u"ࠨࠩ帘"),l11ll1_l1_ (u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ帙"),l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ帚")+l1ll11l1l11_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ帛"),l11ll1_l1_ (u"ࠬ࠭帜"),l11ll1_l1_ (u"࠭ࠧ帝"),l11ll1_l1_ (u"ࠧࡇࡱࡱࡸࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧ帞"),l11ll1_l1_ (u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࡮ࡰࡹࠣࡃࠬ帟")+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ帠")+l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ะ่ษหࠤส๊้ࠡๆ๋ัฮࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤศ๊ย็มࠪ帡"))
	if l1ll111ll1_l1_==1: l1llll11l1111_l1_()
	return
def l1llll1l1llll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ帢"),l11ll1_l1_ (u"ࠬ࠭帣"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ帤"),l11ll1_l1_ (u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭帥"))
	return
def l1llll11ll1l1_l1_():
	message = l11ll1_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨ带")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ帧"),l11ll1_l1_ (u"ࠪࠫ帨"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ帩"),message)
	return
def l1lll1l1lll11_l1_():
	message = l11ll1_l1_ (u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ帪")
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ師"),l11ll1_l1_ (u"ࠧࠨ帬"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ席"),message)
	return
def l1lll11111lll_l1_():
	message = l11ll1_l1_ (u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭帮")
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ帯"),l11ll1_l1_ (u"ࠫࠬ帰"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ帱"),l11ll1_l1_ (u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨ帲"),message)
	return
def l1llll11l111l_l1_():
	message = l11ll1_l1_ (u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬ帳")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ帴"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ帵"),message,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭帶"))
	return
def l1lll1ll1ll1l_l1_():
	l1ll11l11ll_l1_ = l11ll1_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ帷")
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ常")
	l111l1lll1l1_l1_ = l11ll1_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ帹")
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ帺"),l11ll1_l1_ (u"ࠨࠩ帻"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ帼"),l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111l1lll1l1_l1_)
	return
def l1lll1l1l1lll_l1_():
	l1ll11l1l11_l1_ = l11ll1_l1_ (u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ帽")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ帾") + l11ll1_l1_ (u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ帿") + str(PERMANENT_CACHE/60/60/24/30) + l11ll1_l1_ (u"࠭ࠠี้ิࠫ幀")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰࠪ幁") + l11ll1_l1_ (u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ幂") + str(VERYLONG_CACHE/60/60/24) + l11ll1_l1_ (u"ࠩࠣ๎ํ๋ࠧ幃")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭幄") + l11ll1_l1_ (u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ幅") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"๊้ࠬࠦ็ࠪ幆")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࠩ幇") + l11ll1_l1_ (u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ幈") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"ࠨࠢึห฾ฯࠧ幉")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ幊") + l11ll1_l1_ (u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧ幋") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ูࠫࠥวฺหࠪ幌")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮ࠨ幍") + l11ll1_l1_ (u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ幎") + str(l1ll11ll11l1_l1_/60) + l11ll1_l1_ (u"ࠧࠡัๅ๎็ฯࠧ幏")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࠫ幐") + l11ll1_l1_ (u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ幑") + str(NO_CACHE) + l11ll1_l1_ (u"ࠪࠤิ่๊ใหࠪ幒")
	l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ幓") + l11ll1_l1_ (u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ幔") + str(REGULAR_CACHE/60/60) + l11ll1_l1_ (u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧ幕") + str(l1llllll_l1_/60/60/24) + l11ll1_l1_ (u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭幖") + str(l1ll1lll1_l1_/60/60) + l11ll1_l1_ (u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ幗") + str(l1ll11ll11l1_l1_/60) + l11ll1_l1_ (u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ幘") + str(NO_CACHE) + l11ll1_l1_ (u"ࠪࠤิ่๊ใหࠪ幙")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ幚"),l11ll1_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ幛"),l1ll11l1l11_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ幜"))
	return
def l1lll11l11111_l1_():
	message = l11ll1_l1_ (u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ幝")
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ幞"),l11ll1_l1_ (u"ࠩࠪ幟"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幠"),message)
	return
def l1lll11l1ll1l_l1_():
	message = l11ll1_l1_ (u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ幡")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭幢"),l11ll1_l1_ (u"࠭ࠧ幣"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ幤"),message)
	return
def l1lll1lllll11_l1_():
	message = l11ll1_l1_ (u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ幥")
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ幦"),l11ll1_l1_ (u"ࠪࠫ幧"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ幨"),message)
	return
def l1lll11l1l111_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭幩"),l11ll1_l1_ (u"࠭ࠧ幪"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ幫"),l11ll1_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭幬"))
	l11l11ll1ll_l1_(l11ll1_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ幭"),True)
	return
def l1lll1l111111_l1_():
	message  = l11ll1_l1_ (u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ幮")
	#message += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞๊๊ิฬࠦวๅ฻สส็ࠦ็้ࠢࡵࡩࡈࡇࡐࡕࡅࡋࡅࠥอไฯษุࠤอฺัไหࠣะําไ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ幯")
	#message += l11ll1_l1_ (u"ࠬ๎วๅาํࠤฺ์ูหุ้ࠣึ้ษࠡฮ๋ะ้ࠦฮึ์ุห๊ࠥๅ็฻ࠣฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ๊์ࠠหืไัࠥอไฦ่อี๋ะࠧ幰")
	message += l11ll1_l1_ (u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭幱")
	message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิั࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ干")
	message += l11ll1_l1_ (u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ平")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ年"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幵"),message,l11ll1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ并"))
	message = l11ll1_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ幷")
	message += l11ll1_l1_ (u"࠭࡜࡯ࠩ幸")+l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ幹")
	message += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭幺")+l11ll1_l1_ (u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ幻")
	message += l11ll1_l1_ (u"ࠪࡠࡳ࠭幼")+l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ幽")
	message += l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ幾")+l11ll1_l1_ (u"࠭วๅ็หี๊า้ࠠฮาࠤ฼ื๊ให่ࠣฯาว้ิࠣห้฿ววไࠣ์้้ๆ่ษࠣฮาะวอࠢฯ๋ิࠦใษ์ิࠤํอไๆสิ้ัู๊่ࠦࠣห้๋ิไๆฬࠤฺเ๊าหࠣ์้อࠠหีอั็ࠦวๅฬ฼ฬࠥ็ลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠษษ็ำำ๎ไࠡๆห฽฻ࠦวๅ็๋ห็฿้ࠠลํฺฬࠦไไ์ࠣ๎ฯ฼อࠡฯฯ้ࠥอไๆึๆ่ฮࠦࠧ广")
	message += l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟สีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ庀")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ庁"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庂"),message,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭広"))
	#l1ll111l1111_l1_(l11ll1_l1_ (u"ࠫࡎࡹࡐࡳࡱࡥࡰࡪࡳ࠽ࡇࡣ࡯ࡷࡪ࠭庄"))
	#message = l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ庅")+l11ll1_l1_ (u"่࠭ๅไาࠤ้ออู่สࠤฬ๐ึศࠢฦ๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠหะอ่ๆࠦศศะอ่ฬ็ࠠศๆห่ิ่ࠦหะอ่ๆࠦศศะอ่ฬ็ࠠีำๆอࠥอไศ่อี๋๐สࠡใํࠤี๊ใࠡษ็ฬ้ี้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์็ࠡฯอํ๊่ࠥࠡฬ่ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥࡖࡲࡰࡺࡼࠤศ๎ࠠฤ์ࠣ์ุ๐ไสࠢสาึ๏ࠠโษ้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦำ้ใࠣฮำะไโ๋่่ࠢ์็ศࠢ็๊ࠥะูๆๆࠣะ๊๐ู่ษࠪ庆")
	#message += l11ll1_l1_ (u"ࠧๅฯ็ࠤฬ๊ๅีๅ็อ่ࠥๅࠡส฼้้๐ๆ࠻ࠢࠣࠤࠥอไฤ๊็࠾ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า๊ࠩࠡส็ฯฮࠠๆ฻๊ࠤฬูๅࠡส็ำ่่ࠦศี่ࠤูืใสࠢส่ส์สา่ํฮࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠห฻่่ࠥ฿ๆะๅࠪ庇")
	#message += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭庈")+l11ll1_l1_ (u"๋ࠩห้ัว็์࠽ࠤัืศࠡษึฮำีวๆ࡙ࠢࡔࡓฺ่่ࠦาࠤฬ๊ศฺุࠣๆิࠦสฮฬสะࠥ็โุࠢอ฾๏๐ัࠡࡆࡑࡗࠥ๎วๅละื๋ࠦร็ࠢํ็ํ์ࠠโ์ࠣฬ้ีࠠศะิࠤ฾๊ๅศࠢส๊ࠥอำหะาห๊ࠦࡐࡳࡱࡻࡽ่ࠥฯࠡ์ะ่๋ࠥิไๆฬࠤอ฿ึࠡษ็้ํอโฺ๋่่ࠢ์ࠠๅ์ึࠤๆ๐ࠠอ็ํ฽ࠥอไะ๊็ࠫ庉")
	#DIALOG_TEXTVIEWER(l11ll1_l1_ (u"ู้้ࠪไสࠢ฼๊ิࠦศฺุࠣห้์วิࠩ床"),message)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ庋"),l11ll1_l1_ (u"ࠬ็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠨ庌"),l11ll1_l1_ (u"࠭็ัษࠣห้็อึ๊ࠢ์๊ࠥๅฺำไอࠥํไࠡษ็ู้้ไส่๊ࠢࠥ฿ๆะๅࠣห๊ࠦๅ็ࠢส่อืๆศ็ฯ࠲ู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ็อึ่ࠢ์ฬู่่่ࠢีฯ๐ๆࠡษ็วํ๊้ࠡสฺ๋฾้ࠠศๆฺฬ๏฿๊๊ࠡส่ะอๆ๋หࠣฬฬูสฯัส้ࠥฮั้ๅึ๎๋ࠥฬศ่ํࠤฬ์สࠡฬัฮฬื็ࠡ็้ࠤฬ๊โศศ่อࠥอไห์ࠣืฯ฾็าࠢ็หา่ว࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึลࠧ庍"),l11ll1_l1_ (u"ࠧࠨ庎"),l11ll1_l1_ (u"ࠨࠩ序"),l11ll1_l1_ (u"ࠩๆ่ฬ࠭庐"),l11ll1_l1_ (u"๊ࠪ฾๋ࠧ庑"))
	#if l1ll111ll1_l1_==1:
	#l1lll1ll111ll_l1_()
	return
def l1lll1l1l11ll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ庒"),l11ll1_l1_ (u"ࠬ࠭库"),l11ll1_l1_ (u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭应"),l11ll1_l1_ (u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥฮวิฬัำฬ๋ࠠศๆไ๎ุฮ่ไࠢฦำ๋อ็࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱวํࠦศศำึห้ࠦว๋็ํ่ࠥอไ๊ࠢฦำ๋อ็ࠡࠢ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ底"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ庖"),l11ll1_l1_ (u"ࠩࠪ店"),l11ll1_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ庘"),l11ll1_l1_ (u"ࠫ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹࡜࡯࡞ࡱ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼࡟࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ庙"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭庚"),l11ll1_l1_ (u"࠭ࠧ庛"),l11ll1_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ府"),l11ll1_l1_ (u"ࠨ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠳ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡ࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ庝"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ庞"),l11ll1_l1_ (u"ࠪࠫ废"),l11ll1_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ庠"),l11ll1_l1_ (u"ࠬ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠫ庡"))
	#text = l11ll1_l1_ (u"࠭ࠨࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࠡࠫࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠩ庢")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࠨ庣"),l11ll1_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ庤"),l11ll1_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ庥"),l11ll1_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ度"),l11ll1_l1_ (u"ࠫ࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸࠲࠳࠴࠵࠶ࠬ座"),text,l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ庨"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"࠭ࠧ庩"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ庪"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ庫"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ庬"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ庭"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ庮"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠬ࠭庯"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庰"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ庱"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ庲"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庳"),l11ll1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ庴"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࠬ庵"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ庶"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭康"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ庸"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庹"),l11ll1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庺"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠪࠫ庻"),l11ll1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ庼"),l11ll1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ庽"),l11ll1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭庾"),l11ll1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊ࡟ࡲࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ庿"),l11ll1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ廀"))
	return
def l1lll1l11llll_l1_():
	l1lll1l1l1lll_l1_()
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ廁"),l11ll1_l1_ (u"ࠪࠫ廂"),l11ll1_l1_ (u"ࠫࠬ廃"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡษ็็ฬฺࠠภࠩ廄"),l11ll1_l1_ (u"࠭วๅๅสุࠥ๐ำา฻ࠣ฽๊๊ࠠศๆหี๋อๅอุ๋้ࠢำ็ࠡ์฼๎ิࠦำฮสࠣห้฻แฮษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢ฼๊ิࠦวๅฯสะฮࠦลๅ์๊หࠥ๎วๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ๎วๅ็ึั๊ࠥวࠡ์ูีࠥ๎ๅๆๅ้ࠤ๏ำไࠡส฼ฺࠥอไๆึส็้࠭廅"))
	if l1ll111ll1_l1_==1:
		l111lllllll_l1_(True)
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ廆"),l11ll1_l1_ (u"ࠨࠩ廇"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡสส่่อๅๅࠩ廈"),l11ll1_l1_ (u"ࠪษีอࠠไษ้ฮࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥออะࠢส่๊๎วใ฻ࠣๅัืศࠡษ็้ํู่ࠡษ็ฦ๋ࠦ࠮࠯࠰ࠣ์ศึวࠡษ็ู้้ไส่ࠢืฯ๋ัสࠢไษี์ࠠศำึ่ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫ廉"))
	return l1ll111ll1_l1_
def l1lll1l1ll11_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ廊"),l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫ廋"),l11ll1_l1_ (u"࠭ࠧ廌"),l11ll1_l1_ (u"ࠧࠨ廍"),False,l11ll1_l1_ (u"ࠨࠩ廎"),l11ll1_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ廏"))
	#html = response.content
	if not response.succeeded:
		l1lll11llll1l_l1_ = False
		l11l1lll1l_l1_ = l11l1l1ll1_l1_()
		LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ廐"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡉࡖࡗࡔࡘࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡎࡤࡦࡪࡲ࠺࡜ࠩ廑")+l11l1lll1l_l1_+l11ll1_l1_ (u"ࠬࡣࠧ廒"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ廓"),l11ll1_l1_ (u"ࠧࠨ廔"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ廕"),l11ll1_l1_ (u"ࠩไัฺࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠ࠯࠰࠱ࠤฺ๊ใๅหࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠡ฻็ํ้่ࠥะ์ࠣ࠲࠳࠴้ࠠ฻้ำ่ࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭廖"))
	else:
		l1lll11llll1l_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ廗"),l11ll1_l1_ (u"ࠫࠬ廘"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ廙"),l11ll1_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪ廚"))
	if not l1lll11llll1l_l1_ and l1ll_l1_: l1lll1ll1l1ll_l1_()
	return l1lll11llll1l_l1_
def l1lll1ll1l1ll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ廛"),l11ll1_l1_ (u"ࠨࠩ廜"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ廝"),l11ll1_l1_ (u"ࠪฬ฾฼ࠠศๆ่์ฬู่ࠡฬะฮฬาࠠาสฺࠤฺ๊แา๋ࠢๆิ๊ࠦไ๊้ࠤัํวำๅࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢส่ึฮืࠡษ็ู้็ัࠡล๋ࠤ์์วไุ่่๊ࠢษࠡใํࠤูํวะหࠣห้ะิโ์ิࠤฬ๊ฮศืฬࠤอ้่ะ์ࠣ฽๋ีใࠡ฻็้ฬࠦว็้ࠣฮ๊ࠦแฮืࠣห้ฮั็ษ่ะࠥ฿ไ๊ࠢๆ์ิ๐ࠠศๆศูิอัศฬࠣࡠࡳࠦ࠱࠸࠰࠹ࠤࠥࠬࠠࠡ࠳࠻࠲ࡠ࠶࠭࠺࡟ࠣࠤࠫࠦࠠ࠲࠻࠱࡟࠵࠳࠳࡞ࠩ廞"))
	#l1ll11l1l11_l1_ = l11ll1_l1_ (u"ูࠫํวะหࠣห้ะิโ์ิࠤ์๐ࠠๆๆไࠤ๏ำส้์ࠣ฽้๏ࠠีใิอࠥิวึหࠣวํࠦส้ษๅ๎฾ࠦฮศืฬࠤฺ้ัไษอࠤ๊฿ั้ใฬࠤํ๊็ࠡฬสี๏ิࠠึๆสั๏ฯ้่ࠠไหี่ࠦศๆ฽ี฻ࠦๅ็้๋ࠣํࠦสษษา่ࠥอไๆ฻็์๊อสࠡสฺี๏่ษࠡ็ืๅึฯ๋ࠠื฼ฬࠥอฮหำสๆ์อ้ࠠใ๊้์อࠧ廟")
	l1lll1lllll1l_l1_()
	return
def l1ll111l1111_l1_(text=l11ll1_l1_ (u"ࠬ࠭廠")):
	l1l11l1ll1l1_l1_ = True
	if l11ll1_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ廡") not in text:
		l1l11l1ll1l1_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ廢"),l11ll1_l1_ (u"ࠨะิ์ั࠭廣"),l11ll1_l1_ (u"ࠩศีุอไࠡ็ื็้ฯࠧ廤"),l11ll1_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠨ廥"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ廦"),l11ll1_l1_ (u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨ廧"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l11l1ll1l1_l1_ = True
			text = l11ll1_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ廨")
	if l1l11l1ll1l1_l1_:
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ廩"),l11ll1_l1_ (u"ࠨࠩ廪"),l11ll1_l1_ (u"ࠩࠪ廫"),l11ll1_l1_ (u"ࠪษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠫ廬"),l11ll1_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ึฮ฼๐ูࠡษ็้อืๅอ่ࠢ฽ึ็ษࠡษ็ู้้ไส๋ࠢษฺ๊วฮ้สࠫ廭"))
		#if not l1ll111ll1_l1_:
		#	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭廮"),l11ll1_l1_ (u"࠭ࠧ廯"),l11ll1_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ廰"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ廱"))
		#	return
		l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࡷࡩࡽࡺࠠࠬ࠿ࠣࠫࡱࡵࡧࡴ࠿ࡼࡩࡸ࠭ࠊࠊࠋࠌࡽࡪࡹࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡ࡜ࡉࡘࡔࡏࠩࠩࡦࡩࡳࡺࡥࡳࠩ࠯ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ࠰่ࠬศๅࠢสีุอไࠡีฯ่ࠥอไศะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻็๎่ࠦว็ࠢอๆํ๋ࠠษฬื฾๏๊ࠠศๆไ๎ิ๐่ࠡษ๋ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢํ฽฼๐ใࠡษ็ู้้ไสࠢ็็๏๊ࠦห็ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅ࠯๊่ࠢࠥะั๋ัࠣห้อัิษ็ࠤฬ๊ว็ࠢยࠫ࠱࠭ࠧ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠍࠍࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠱࠼ࠍࠍࠎࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭สๆࠢส่฿อมࠡษ็หึูวๅࠩࠬࠎࠎࠏࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࠩࠪࠎࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࠰ࠬอะศࠢๆห๋ะࠠๅัํ็๋ࠥิไๆฬࠤๆอไาฮสล่ࠥัศรฬࠤ็ูๅࠡษ็ู้อใๅ๋ࠢห้อำวๆฬࠤํอะศࠢ็้ࠥะฬะࠢส่า๊่่ࠠส็ࠥ็อศ๊็ࠤ่ะวษหࠣะ๊๐ูࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧࠪࠌࠌࠍࠧࠨࠢ廲")
		if l11ll1_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ廳") not in text:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ廴"),l11ll1_l1_ (u"ࠬ࠭廵"),l11ll1_l1_ (u"࠭ࠧ延"),l11ll1_l1_ (u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧ廷"),l11ll1_l1_ (u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨ廸"))
			if l1ll111ll1_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ廹"),l11ll1_l1_ (u"ࠪࠫ建"),l11ll1_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧ廻"),l11ll1_l1_ (u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ廼"))
				return
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ廽"),l11ll1_l1_ (u"ࠧࠨ廾"),l11ll1_l1_ (u"ࠨๅอหอฯ้ࠠึิัࠥอไๆู๊์฾ࠦไๅ็หี๊าࠧ廿"),l11ll1_l1_ (u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆส๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭开"))
	search = OPEN_KEYBOARD(header=l11ll1_l1_ (u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࠦࠠศๅอฬࠥืำศๆฬࠫ弁"),source=script_name)
	if not search: return
	message = search
	if l1l11l1ll1l1_l1_: type = l11ll1_l1_ (u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬ异")
	else: type = l11ll1_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭弃")
	succeeded = l111ll11111_l1_(type,message,True,l11ll1_l1_ (u"࠭ࠧ弄"),l11ll1_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ弅"),text)
	#	url = l11ll1_l1_ (u"ࠨ࡯ࡼࠤࡆࡖࡉࠡࡣࡱࡨ࠴ࡵࡲࠡࡕࡐࡘࡕࠦࡳࡦࡴࡹࡩࡷ࠭弆")
	#	payload = l11ll1_l1_ (u"ࠩࡾࠦࡦࡶࡩࡠ࡭ࡨࡽࠧࡀࠢࡎ࡛ࠣࡅࡕࡏࠠࡌࡇ࡜ࠦ࠱ࠨࡴࡰࠤ࠽࡟ࠧࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠦࡢ࠲ࠢࡴࡧࡱࡨࡪࡸࠢ࠻ࠤࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠣ࠮ࠥࡷࡺࡨࡪࡦࡥࡷࠦ࠿ࠨࡆࡳࡱࡰࠤࡆࡸࡡࡣ࡫ࡦࠤ࡛࡯ࡤࡦࡱࡶࠦ࠱ࠨࡴࡦࡺࡷࡣࡧࡵࡤࡺࠤ࠽ࠦࠬ弇")+message+l11ll1_l1_ (u"ࠪࠦࢂ࠭弈")
	#	#auth=(l11ll1_l1_ (u"ࠦࡦࡶࡩࠣ弉"), l11ll1_l1_ (u"ࠧࡳࡹࠡࡲࡨࡶࡸࡵ࡮ࡢ࡮ࠣࡥࡵ࡯ࠠ࡬ࡧࡼࠦ弊")),
	#	import requests
	#	response = requests.request(l11ll1_l1_ (u"࠭ࡐࡐࡕࡗࠫ弋"),url, data=payload, headers=l11ll1_l1_ (u"ࠧࠨ弌"), auth=l11ll1_l1_ (u"ࠨࠩ弍"))
	#	response = requests.post(url, data=payload, headers=l11ll1_l1_ (u"ࠩࠪ弎"), auth=l11ll1_l1_ (u"ࠪࠫ式"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ弐"),l11ll1_l1_ (u"ࠬ࠭弑"),l11ll1_l1_ (u"࠭ࠧ弒"),l11ll1_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ弓"))
	#	else:
	#		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ弔"),l11ll1_l1_ (u"ࠩࠪ引"),l11ll1_l1_ (u"ࠪา฼ษࠠโ์ࠣห้หัิษ็ࠫ弖"),l11ll1_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࡿࢂࡀࠠࡼࠣࡵࢁࠬ弗").format(response.status_code, response.content))
	#	l1lll11ll1lll_l1_ = l11ll1_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ弘")
	#	l1lll1l1l11l1_l1_ = l11ll1_l1_ (u"࠭࡭ࡦࡂࡨࡱࡦ࡯࡬࠯ࡥࡲࡱࠬ弙")
	#	header = l11ll1_l1_ (u"ࠧࠨ弚")
	#	#header += l11ll1_l1_ (u"ࠨࡈࡵࡳࡲࡀࠠࠨ弛") + l1lll11ll1lll_l1_
	#	#header += l11ll1_l1_ (u"ࠩ࡟ࡲ࡙ࡵ࠺ࠡࠩ弜") + l1lll11111ll1_l1_
	#	#header += l11ll1_l1_ (u"ࠪࡠࡳࡉࡣ࠻ࠢࠪ弝") + l1lll11111ll1_l1_
	#	header += l11ll1_l1_ (u"ࠫࡡࡴࡓࡶࡤ࡭ࡩࡨࡺ࠺ࠡ็้ࠤ่๎ฯ๋ࠢส่ๆ๐ฯ๋๊ࠣห้฿ัษ์ࠪ弞")
	#	server = l1llll11lllll_l1_.l1lll1l1111l1_l1_(l11ll1_l1_ (u"ࠬࡹ࡭ࡵࡲ࠰ࡷࡪࡸࡶࡦࡴࠪ弟"),25)
	#	#server.l1lll1l1llll1_l1_()
	#	server.l1lll1ll111l1_l1_(l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥࠨ张"),l11ll1_l1_ (u"ࠧࡱࡣࡶࡷࡼࡵࡲࡥࠩ弡"))
	#	response = server.l1lll1lll11ll_l1_(l1lll11ll1lll_l1_,l1lll1l1l11l1_l1_, header + l11ll1_l1_ (u"ࠨ࡞ࡱࠫ弢") + message)
	#	server.quit()
	return
def l1llll111l1ll_l1_():
	text = l11ll1_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭弣")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ弤"),l11ll1_l1_ (u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫ弥"),text,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ弦"))
	text = l11ll1_l1_ (u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩ弧")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ弨"),l11ll1_l1_ (u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭弩"),text,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ弪"))
	return
def l1lll1ll11111_l1_(addon_id):
	#DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ弫"),l11ll1_l1_ (u"ࠫࠬ弬"),l11ll1_l1_ (u"ࠬ࠭弭"),addon_id)
	result = xbmc.executeJSONRPC(l11ll1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ弮")+addon_id+l11ll1_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭弯"))
	l1l11llll1_l1_ = True
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡹࡨࡶࡶ࡬ࡰࠏࠏࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡻࡦࡲࡩࡦࡰ࡮ࡧࡩࡷ࠲ࠧࡢࡦࡧࡳࡳࡹࠧ࠭ࡣࡧࡨࡴࡴ࡟ࡪࡦࠬࠎࠎ࡯ࡦࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰ࡨࡼ࡮ࡹࡴࡴࠪࡻࡦࡲࡩࡦࡪ࡮ࡨ࠭࠿ࠐࠉࠊࡵ࡫ࡹࡹ࡯࡬࠯ࡴࡰࡸࡷ࡫ࡥࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡲࡦࡨࡵࡩࡸ࡮ࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡺࡹࡥࡳࡨࡲࡰࡩ࡫ࡲ࠭ࠩࡤࡨࡩࡵ࡮ࡴࠩ࠯ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮ࠐࠉࡪࡨࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲ࡪࡾࡩࡴࡶࡶࠬࡺࡹࡥࡳࡨ࡬ࡰࡪ࠯࠺ࠋࠋࠌࡷ࡭ࡻࡴࡪ࡮࠱ࡶࡲࡺࡲࡦࡧࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡴࡨࡪࡷ࡫ࡳࡩࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠧ࡮ࡳࡰࡰࡴࡷࠤࡸࡷ࡬ࡪࡶࡨ࠷ࠏࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡣࡧࡨࡴࡴࡳࡠࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࡤࡥࠣࡁࠥࡩ࡯࡯ࡰ࠱ࡧࡺࡸࡳࡰࡴࠫ࠭ࠏࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡤࡨࡩࡵ࡮ࡴ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࠧࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡳࡧࡳࡳࡸࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠣࠢ࠾ࠫ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡯࡮࡯࡬ࡸ࠭࠯ࠊࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠤࠥࠦ弰")
	if l1l11llll1_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭弱"))
		time.sleep(1)
	return
def l1lll1llll1l1_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ弲"),l11ll1_l1_ (u"ࠫࠬ弳"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ弴"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫ張"))
	l1lll1lllll11_l1_()
	return
def l1lll1lllll1l_l1_():
	#	https://l111ll11l11_l1_.tv/download/849
	#   https://play.google.com/l1lll1l11l1l1_l1_/l1lll1l1lll1l_l1_/details?id=l1llll111ll_l1_.xbmc.l111ll11l11_l1_
	#	http://mirror.l1lll1lll1ll1_l1_.l1lll11lll111_l1_.l1llll1l1ll1l_l1_/l1lll1lll1111_l1_/xbmc/l1lll1l111ll1_l1_/l1lll1111ll11_l1_/l1lll1lll11l1_l1_
	#	http://l1lll11l1l11l_l1_.l1lll111l1lll_l1_.l1llll1l1ll1l_l1_/l111ll11l11_l1_/l1lll1l111ll1_l1_/l1lll1111ll11_l1_/l1lll1lll11l1_l1_
	url = l11ll1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬ弶")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠨࡉࡈࡘࠬ強"),url,l11ll1_l1_ (u"ࠩࠪ弸"),l11ll1_l1_ (u"ࠪࠫ弹"),l11ll1_l1_ (u"ࠫࠬ强"),l11ll1_l1_ (u"ࠬ࠭弻"),l11ll1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩ弼"))
	html = response.content
	l1lll111l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭弽"),html,re.DOTALL)
	l1lll111l1l11_l1_ = l1lll111l1l11_l1_[0].split(l11ll1_l1_ (u"ࠨ࠯ࠪ弾"))[0]
	l1llll1l1l111_l1_ = str(kodi_version)
	#l111l1lll1ll_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ弿")+l11ll1_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์฼้้ࠦๅฺࠢๆ์ิ๐ࠠฦืาหึࠦ࠱࠺๋้ࠢฬࠦศฺั๊ࠫ彀")+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭彁")
	l111l1lll1ll_l1_ = l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧ彂")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ彃")+l1lll111l1l11_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ彄")
	l111l1lll1ll_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭彅")+l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨ彆")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭彇")+l1llll1l1l111_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭彈")
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭彉"),l11ll1_l1_ (u"࠭ࠧ彊"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ彋"),l111l1lll1ll_l1_)
	return
def l1lll11l1ll11_l1_():
	# https://l11l1l1ll1l_l1_-l111ll1111l_l1_-l111lllll1l_l1_.l1llll1ll1l1l_l1_.com/request-l1lll1l1ll11l_l1_
	# https://l11l1l1ll1l_l1_-l111ll1111l_l1_-l111lllll1l_l1_.l1llll1ll1l1l_l1_.com/query-l1lll111l1l1l_l1_
	l1ll11l11ll_l1_,l1ll11l1l11_l1_,l111l1lll1l1_l1_,l111l1lll1ll_l1_,l1lll1lllllll_l1_,l1lll1111l1ll_l1_,l1lll1l1111ll_l1_ = l11ll1_l1_ (u"ࠨࠩ彌"),l11ll1_l1_ (u"ࠩࠪ彍"),l11ll1_l1_ (u"ࠪࠫ彎"),l11ll1_l1_ (u"ࠫࠬ彏"),l11ll1_l1_ (u"ࠬ࠭彐"),l11ll1_l1_ (u"࠭ࠧ彑"),l11ll1_l1_ (u"ࠧࠨ归")
	payload,l1lll111l1ll1_l1_,l1lll1ll1llll_l1_,l1lll1111lll1_l1_ = {l11ll1_l1_ (u"ࠨࡣࠪ当"):l11ll1_l1_ (u"ࠩࡤࠫ彔")},{},[],{}
	url = l1l1lll_l1_[l11ll1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ录")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ彖"),url,payload,l11ll1_l1_ (u"ࠬ࠭彗"),l11ll1_l1_ (u"࠭ࠧ彘"),l11ll1_l1_ (u"ࠧࠨ彙"),l11ll1_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭彚"))
	html = response.content
	html = html.replace(l11ll1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩ彛"),l11ll1_l1_ (u"࡙ࠪࡘࡇࠧ彜"))
	html = html.replace(l11ll1_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬ彝"),l11ll1_l1_ (u"࡛ࠬࡋࠨ彞"))
	html = html.replace(l11ll1_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭彟"),l11ll1_l1_ (u"ࠧࡖࡃࡈࠫ彠"))
	html = html.replace(l11ll1_l1_ (u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧ彡"),l11ll1_l1_ (u"ࠩࡎࡗࡆ࠭形"))
	html = html.replace(l11ll1_l1_ (u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ彣"),l11ll1_l1_ (u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ彤"))
	html = html.replace(l11ll1_l1_ (u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭彥"),l11ll1_l1_ (u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨ彦"))
	html = html.replace(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ彧"),l11ll1_l1_ (u"ࠨࠢࠣࠫ彨"))
	try: l1lll1ll1lll1_l1_ = EVAL(l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ彩"),html)
	except:
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ彪"),l11ll1_l1_ (u"ࠫࠬ彫"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彬"),l11ll1_l1_ (u"࠭แีๆࠣๅ๏ࠦฬๅส้ࠣาะ่๋ษอࠤฯ่ั๋ำࠣห้อำหะาห๊࠭彭"))
		return
	l1llll11ll111_l1_,l1llll1l1l1ll_l1_,l1lll1l1l1l1l_l1_ = l1lll1ll1lll1_l1_
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ彮"),str(l1llll11ll111_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ彯"),str(l1llll1l1l1ll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ彰"),str(l1lll1l1l1l1l_l1_))
	l1lll1111lll1_l1_ = {}
	l1llll1ll1ll1_l1_ = [l11ll1_l1_ (u"ࠪࡅࡑࡒࠧ影"),l11ll1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ彲"),l11ll1_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭彳"),l11ll1_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ彴"),l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭彵")]+l1llllll11l1_l1_+l111l1l1lll_l1_
	for l1ll111l111_l1_,l1llll1l11111_l1_,l1llll11l1ll1_l1_ in l1llll1l1l1ll_l1_:
		l1llll11l1ll1_l1_ = escapeUNICODE(l1llll11l1ll1_l1_)
		l1llll11l1ll1_l1_ = l1llll11l1ll1_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠪ彶")).strip(l11ll1_l1_ (u"ࠩࠣ࠲ࠬ彷"))
		l111l1lll1ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ彸")+l1ll111l111_l1_+l11ll1_l1_ (u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ役")+l1llll11l1ll1_l1_+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ彺")
		if l1llll1l11111_l1_.isdigit():
			l1lll1111lll1_l1_[l1ll111l111_l1_] = int(l1llll1l11111_l1_)
			if int(l1llll1l11111_l1_)>100: l1llll1l11111_l1_ = l11ll1_l1_ (u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ彻")
			else: l1llll1l11111_l1_ = l11ll1_l1_ (u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩ彼")
		if l1ll111l111_l1_ not in l1llll1ll1ll1_l1_:
			if   l1llll1l11111_l1_==l11ll1_l1_ (u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫ彽"): l1ll11l11ll_l1_ += l11ll1_l1_ (u"ࠩࠣࠤࠬ彾")+l1ll111l111_l1_
			elif l1llll1l11111_l1_==l11ll1_l1_ (u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ彿"): l1ll11l1l11_l1_ += l11ll1_l1_ (u"ࠫࠥࠦࠧ往")+l1ll111l111_l1_
	l1llll1ll1l11_l1_,l1lll11lllll1_l1_,l1lll1l111l11_l1_ = list(zip(*l1llll1l1l1ll_l1_))
	for l1ll111l111_l1_ in sorted(l1l1llll1ll1_l1_):
		if l1ll111l111_l1_ not in l1llll1ll1l11_l1_:
			l111l1lll1ll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ征")+l1ll111l111_l1_+l11ll1_l1_ (u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ徂")+l11ll1_l1_ (u"ࠧๅษࠣ๎ําฯࠨ徃")+l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭径")
			if l1ll111l111_l1_ not in l1llll1ll1ll1_l1_: l111l1lll1l1_l1_ += l11ll1_l1_ (u"ࠩࠣࠤࠬ待")+l1ll111l111_l1_
	for l1llll11l1ll1_l1_,counts in l1llll11ll111_l1_:
		l1llll11l1ll1_l1_ = escapeUNICODE(l1llll11l1ll1_l1_)
		l1lll1lllllll_l1_ += l1llll11l1ll1_l1_+l11ll1_l1_ (u"ࠪ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ徆")+str(counts)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠩ徇")
	l1ll11l11ll_l1_ = l1ll11l11ll_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ很"))
	l1ll11l1l11_l1_ = l1ll11l1l11_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ徉"))
	l111l1lll1l1_l1_ = l111l1lll1l1_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠩ徊"))
	l111l1llll1l_l1_ = l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠫ律")+l1ll11l1l11_l1_
	#l11111l1ll11_l1_  = l11ll1_l1_ (u"ࠩ࡟ࡲࡍ࡯ࡧࡩࡗࡶࡥ࡬࡫࠺ࠡ࡝ࠣࠫ後")+l1ll11l11ll_l1_+l11ll1_l1_ (u"ࠪࠤࡢ࠭徍")
	#l11111l1ll11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࡌࡰࡹࡘࡷࡦ࡭ࡥࠡ࠼ࠣ࡟ࠥ࠭徎")+l1ll11l1l11_l1_+l11ll1_l1_ (u"ࠬࠦ࡝ࠨ徏")
	#l11111l1ll11_l1_ += l11ll1_l1_ (u"࠭࡜࡯ࡐࡲ࡙ࡸࡧࡧࡦࠢࠣ࠾ࠥࡡࠠࠨ徐")+l111l1lll1l1_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ徑")
	l111l1llll11_l1_  = l11ll1_l1_ (u"ࠨ็๋ห็฿ࠠี฼็ࠤ๊์็ศࠢส่อืๆศ็ฯࠤฬ๊ศศำะอࠥ࠮๊้็ࠣวู๊ࠩࠡใํำ๏๎็ศฬࠣฬิ๎ๆࠡ็ืห่๊ࠧ徒")+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ従")+l11ll1_l1_ (u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨ徔")+l11ll1_l1_ (u"ࠫࡡࡴࠧ徕")
	l111l1llll11_l1_ += l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ徖")+l111l1llll1l_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ得")
	l111l1llll11_l1_ += l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦไๆࠢํุ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠศๆหหึำษࠡࠪํ์๊ࠦรๆีࠬࠤศ๐ࠠโ์า๎ํํวหࠩ徘")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ徙")+l11ll1_l1_ (u"๋๋ࠩีอࠠๆ฻้ห์ࠦวฮฬ่ห้ࠦใษ์ิࠤํา่ะุ่่๊ࠢษࠡใํࠤฬ๊ศา่ส้ั࠭徚")+l11ll1_l1_ (u"ࠪࡠࡳ࠭徛")
	l111l1llll11_l1_ += l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ徜")+l111l1lll1l1_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ徝")
	l1111l11l11_l1_,l1lll11l1lll1_l1_,l1lll1lll1l1l_l1_,l1lll11l11lll_l1_ = 0,0,0,0
	all = l1lll1111lll1_l1_[l11ll1_l1_ (u"࠭ࡁࡍࡎࠪ從")]
	if l11ll1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ徟") in list(l1lll1111lll1_l1_.keys()): l1111l11l11_l1_ = l1lll1111lll1_l1_[l11ll1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ徠")]
	if l11ll1_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ御") in list(l1lll1111lll1_l1_.keys()): l1lll11l1lll1_l1_ = l1lll1111lll1_l1_[l11ll1_l1_ (u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ徢")]
	if l11ll1_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ徣") in list(l1lll1111lll1_l1_.keys()): l1lll1lll1l1l_l1_ = l1lll1111lll1_l1_[l11ll1_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ徤")]
	if l11ll1_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ徥") in list(l1lll1111lll1_l1_.keys()): l1lll11l11lll_l1_ = l1lll1111lll1_l1_[l11ll1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭徦")]
	l11ll1llll11_l1_ = all-l1111l11l11_l1_-l1lll11l1lll1_l1_-l1lll1lll1l1l_l1_-l1lll11l11lll_l1_
	dummy,l1lll1ll1l11l_l1_ = l1lll1l1l1l1l_l1_[0]
	dummy,l1lll111lllll_l1_ = l1lll1l1l1l1l_l1_[1]
	l1lll11ll1l11_l1_ = l1lll1ll1l11l_l1_-l1lll111lllll_l1_
	l1lll1l1111ll_l1_ += l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ徧")+str(l1lll111lllll_l1_)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ徨")+l11ll1_l1_ (u"ࠪห้฿ฯะࠢส่า่๊ใ์่้ࠣษฬ่ิฬࠤ࠿ࠦࠧ復")
	l1lll1l1111ll_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ循")+str(l1lll11ll1l11_l1_)+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ徫")+l11ll1_l1_ (u"࠭ศศีอาิอๅࠡࡲࡵࡳࡽࡿࠠฤ๊ࠣࡺࡵࡴࠠ࠻ࠢࠪ徬")
	l1lll1l1111ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ徭")+str(l1lll1ll1l11l_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ微")+l11ll1_l1_ (u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪ徯")
	l1lll1l1111ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ徰")+str(len(l1lll1l1l1l1l_l1_[2:]))+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徱")+l11ll1_l1_ (u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪ徲")
	for l1ll1l1111l1_l1_,l1l11l11l1ll_l1_ in l1lll1l1l1l1l_l1_[2:]:
		l1ll1l1111l1_l1_ = escapeUNICODE(l1ll1l1111l1_l1_)
		l1ll1l1111l1_l1_ = l1ll1l1111l1_l1_.strip(l11ll1_l1_ (u"࠭ࠠࠨ徳")).strip(l11ll1_l1_ (u"ࠧࠡ࠰ࠪ徴"))
		l1lll1l1111ll_l1_ += l1ll1l1111l1_l1_+l11ll1_l1_ (u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭徵")+str(l1l11l11l1ll_l1_)+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧ徶")
	#l1lll1l1111ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠴ࠧ德")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ徸")+str(l11ll1llll11_l1_)+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ徹")+l11ll1_l1_ (u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫ徺")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ徻")+str(l1111l11l11_l1_)+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ徼")+l11ll1_l1_ (u"ฺ่ࠩออสࠡีํีๆืࠠษษํฯํ์ࠠ࠻ࠢࠪ徽")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ徾")+str(l1lll11l11lll_l1_)+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徿")+l11ll1_l1_ (u"ࠬ฽ไษษอࠤุ๐ัโำࠣห้๋ำห๊า฽ฬะࠠ࠻ࠢࠪ忀")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ忁")+str(l1lll11l1lll1_l1_)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ忂")+l11ll1_l1_ (u"ࠨฬฮฬ๏ะࠠหูห๎็ࠦใ้ัํࠤ฾๋วะࠢ࠽ࠤࠬ心")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ忄")+str(l1lll1lll1l1l_l1_)+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ必")+l11ll1_l1_ (u"ࠫฯัศ๋ฬࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠻ࠢࠪ忆")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ忇")+str(len(l1llll11ll111_l1_))+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ忈")+l11ll1_l1_ (u"ࠧะ๊็ࠤูเไหࠢไ๎ิ๐่่ษอࠤ࠿ࠦࠧ忉")
	#l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠨ࡞ࡱࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ忊")+l11ll1_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢส่฾อไๆࠢํ์๊ࠦรๆีࠣࠬฬ๊ศศำะอ࠮࠭忋")+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ忌")
	l1lll1111l1ll_l1_ += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ忍")+l1lll1lllllll_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ忎"),l11ll1_l1_ (u"ู࠭ะัࠣห้ษฬ่ิฬࠤฬ๊ส๋ࠢสืฯิฯๆฬ๋ࠣีอࠠศๆหี๋อๅอࠢส่ออัฮหࠣࠬ๏๎ๅࠡล่ื࠮ࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭忏"),l1lll1l1111ll_l1_,l11ll1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ忐"))
	#l11ll1l111_l1_(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ忑"),l11ll1_l1_ (u"ࠩฯ้๏฿่ࠠา๊ࠤฬ๊ราไส้ࠥะฮึࠢฦืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢࠣๅ็฽๋๊่ࠠࠤศ๋ำࠡࠪส่ออัฮหࠬࠫ忒"),l1lll1111l1ll_l1_,l11ll1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭忓"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ忔"),l11ll1_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢส่ออัฮหࠣࠬ๏๎ๅࠡล่ื࠮ࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭忕"),l1lll1111l1ll_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ忖"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ志"),l11ll1_l1_ (u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠศๆหหึำษࠡࠪํ์๊ࠦรๆีࠬࠤࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ忘"),l111l1llll11_l1_,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ忙"))
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ忚"),l11ll1_l1_ (u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭忛"),l111l1lll1ll_l1_,l11ll1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭応"))
	return
def l1lll1l111lll_l1_():
	message = l11ll1_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬ忝")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ忞"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忟"),message,l11ll1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ忠"))
	return
def l1l1l1ll111l_l1_():
	message = l11ll1_l1_ (u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨ忡")+l11ll1_l1_ (u"ࠫࡡࡴࠧ忢")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ忣")+l1l1lll_l1_[l11ll1_l1_ (u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ忤")][0]+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ忥")+l1l1lll_l1_[l11ll1_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ忦")][1]+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ忧")
	message += l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ忨")+l1l1lll_l1_[l11ll1_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ忩")][1]+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ忪")
	message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩ快")+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ忬")+l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ忭")+l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ忮")][2]+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ忯")
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ忰"),l11ll1_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ忱"),message,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ忲"))
	return
def l1llll11l1lll_l1_(l1llll11ll11l_l1_):
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭忳")+l1llll11ll11l_l1_+l11ll1_l1_ (u"ࠨࠫࠪ忴"), True)
	return
def l1llll11l1111_l1_():
	l1ll111l1_l1_(l11ll1_l1_ (u"ࠩࡶࡸࡴࡶࠧ念"))
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤ忶"))
	return
def l1lll1l1l1l11_l1_():
	xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪ忷"), True)
	return
def l1lll11lll1l1_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111ll1_l1_ = True
	else: l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ忸"),l11ll1_l1_ (u"࠭ࠧ忹"),l11ll1_l1_ (u"ࠧࠨ忺"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忻"),l11ll1_l1_ (u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩ忼"))
	if l1ll111ll1_l1_==1:
		xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭忽"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ忾"),l11ll1_l1_ (u"ࠬ࠭忿"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怀"),l11ll1_l1_ (u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧ态"))
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ怂"))
	return
def l1lll11lll1ll_l1_():
	DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ怃"),l11ll1_l1_ (u"ࠪࠫ怄"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ怅"),l11ll1_l1_ (u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬ怆"))
	return
def l1lll1l11111l_l1_():
	DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ怇"),l11ll1_l1_ (u"ࠧࠨ怈"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ怉"),l11ll1_l1_ (u"ࠩ็่ฯ฿วๆๆ้ࠣ฾ࠦวๅ็ไฺ้ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢอี๏ีࠠฦุสๅฯํࠠฤุ๊้ࠣำ็ࠡ็้ࠤ่ࠥวว็ฬࠤฬ๊ๅโุ็อࠥ๎ไไ่่ࠣฬࠦสื฼ฺࠤ฾๊๊่๋่ࠢฬࠦสี฼็๋ࠥ࠴้ࠠสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์ศ๋วࠡสสืฯิฯศ็ࠣࠦฬ๊ใ๋ส๋ีิࠨࠠโษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์๋็ำࠡษ็็้อๅ๊ࠡส่฼ื๊ใหࠣ฽๋ีࠠศๆอ฽ฬ๋ไࠡ็฼ࠤ๊ำส้์สฮ่่ࠥศศ่ࠤฬ๊ๅโุ็อࠬ怊"))
	return
#l1llll11ll1ll_l1_ 	  required	and l1llll11ll1ll_l1_     installed	and		not l1l11l1111l1_l1_		ignore
#l1llll11ll1ll_l1_ not required	and	l1llll11ll1ll_l1_ not installed 	and 	    l1l11l1111l1_l1_		ignore
#l1llll11ll1ll_l1_ not required	and	l1llll11ll1ll_l1_ not installed 	and 	not l1l11l1111l1_l1_		ignore
#l1llll11ll1ll_l1_ not required	and	l1llll11ll1ll_l1_     installed 	and 	not l1l11l1111l1_l1_		ignore
#l1llll11ll1ll_l1_     required	and	l1llll11ll1ll_l1_ not installed 	and 	    l1l11l1111l1_l1_		l111111lll_l1_ l1lll11l1lll1_l1_	l1llll1111111_l1_
#l1llll11ll1ll_l1_     required	and	l1llll11ll1ll_l1_ not installed 	and 	not l1l11l1111l1_l1_		l111111lll_l1_ l1lll11l1lll1_l1_	l1llll1111111_l1_
#l1llll11ll1ll_l1_     required 	and l1llll11ll1ll_l1_     installed 	and 	    l1l11l1111l1_l1_		l111111lll_l1_ l1llll1l11lll_l1_	l1llll1111111_l1_
#l1llll11ll1ll_l1_ not required	and	l1llll11ll1ll_l1_     installed 	and 	    l1l11l1111l1_l1_		l111111lll_l1_ l1llll1l11lll_l1_	l1llll1111111_l1_
#l1ll1ll1l1l1_l1_: required and not installed: l111111lll_l1_ l1lll11l1lll1_l1_
#l1ll1ll1l111_l1_: installed and l111111lll_l1_ update: l111111lll_l1_ l1llll1l11lll_l1_
def l1l1l1l11l1l_l1_(l1ll_l1_=True):
	l1l11ll11111_l1_ = l1lll1l11l11_l1_([l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ怋")])
	l1lll1lll1l11_l1_ = []
	for addon_id in [l11ll1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭怌")]:
		if addon_id not in list(l1l11ll11111_l1_.keys()): continue
		l1l11l1111l1_l1_,l1llllll1111_l1_,l1llll111l111_l1_,l1llll1111lll_l1_,l1llll1111l11_l1_,l1lll111ll11l_l1_,l1llll1111l1l_l1_ = l1l11ll11111_l1_[addon_id]
		if not l1llllll1111_l1_ or (l1llllll1111_l1_ and l1l11l1111l1_l1_): l1lll1lll1l11_l1_.append(addon_id)
	l1lll1111l11l_l1_ = len(l1lll1lll1l11_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1ll111ll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1llll111ll1l_l1_ = []
	for addon_id in l11ll1ll11l_l1_:
		cc.execute(l11ll1_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠦ࠶ࠨࠠࡢࡰࡧࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ怍")+addon_id+l11ll1_l1_ (u"࠭ࠢࠡ࠽ࠪ怎"))
		l1l1111l1ll_l1_ = cc.fetchall()
		if l1l1111l1ll_l1_: l1llll111ll1l_l1_.append(addon_id)
	l1lll1l11lll1_l1_ = len(l1llll111ll1l_l1_)>0
	for addon_id in l1llllllll1l_l1_:
		cc.execute(l11ll1_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ怏")+addon_id+l11ll1_l1_ (u"ࠨࠤࠣ࠿ࠬ怐"))
		l1llll1ll1lll_l1_ = cc.fetchall()
		if l1llll1ll1lll_l1_ and l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ怑") not in str(l1llll1ll1lll_l1_): l1lll1lll1l11_l1_.append(addon_id)
	l1lll11ll111l_l1_ = len(l1lll1lll1l11_l1_)>0
	l1lll1lll1l11_l1_ = list(set(l1lll1lll1l11_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ怒"),l11ll1_l1_ (u"ࠫࡳ࡫ࡥࡥࡡࡩ࡭ࡽ࡯࡮ࡨࡡࡵࡩࡵࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯࠼ࠣࠤࠬ怓")+str(l1lll1111l11l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭怔"),l11ll1_l1_ (u"࠭࡮ࡦࡧࡧࡣࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࡥ࡯࡭ࡦࡢࡥࡩࡪ࡯࡯ࡵ࠽ࠤࠥ࠭怕")+str(l1lll1l11lll1_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ怖"),l11ll1_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥ࡯ࡳ࡫ࡪ࡭ࡳࡀࠠࠡࠩ怗")+str(l1lll11ll111l_l1_))
	l1l11l1111l1_l1_ = False
	if l1lll1l11lll1_l1_ or l1lll11ll111l_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ怘"),l11ll1_l1_ (u"ࠪࠫ怙"),l11ll1_l1_ (u"ࠫࠬ怚"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ怛"),l11ll1_l1_ (u"࠭วๅสิ๊ฬ๋ฬ๊ࠡฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿วหࠢ฼้ฬีࠠฤู๊้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦวๅฤ้ࠤฤࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ怜"))
		if l1ll111ll1_l1_==1:
			l1llll1l1111l_l1_ = True
			if l1lll1111l11l_l1_:
				l1llll1l1111l_l1_ = l1lll11l1l1ll_l1_(l11ll1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ思"),False,False)
			l1lll1ll1ll11_l1_ = True
			if l1lll1l11lll1_l1_:
				for addon_id in l1llll111ll1l_l1_: l1lll1ll11111_l1_(addon_id)
				l1lll1ll1ll11_l1_ = True
			l1lll11l11ll1_l1_ = True
			if l1lll11ll111l_l1_:
				conn = sqlite3.connect(l1l1ll111ll1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1lll1lll1l11_l1_:
					if l11ll1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫ怞") in addon_id: l1llll1ll1lll_l1_ = addon_id
					else: l1llll1ll1lll_l1_ = l11ll1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ怟")
					try: cc.execute(l11ll1_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧ怠")+l1llll1ll1lll_l1_+l11ll1_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ怡")+addon_id+l11ll1_l1_ (u"ࠬࠨࠠ࠼ࠩ怢"))
					except: l1lll11l11ll1_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ怣"))
			time.sleep(1)
			if l1llll1l1111l_l1_ or l1lll1ll1ll11_l1_ or l1lll11l11ll1_l1_:
				l1l11l1111l1_l1_ = False
				DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ怤"),l11ll1_l1_ (u"ࠨࠩ急"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ怦"),l11ll1_l1_ (u"ࠪะ๏ีࠠ࠯࠰ࠣฮ๊ࠦศ็ฮสัࠥะแฺ์็ࠤํหีๅษะࠤฬ๊ๅิฬ๋ำ฾อส๊ࠡส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥฬๆ์฼ࠤส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ性"))
			else:
				l1l11l1111l1_l1_ = True
				DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ怨"),l11ll1_l1_ (u"ࠬ࠭怩"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ怪"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦลึๆสั๋ࠥำห๊า฽ฬะฺࠠ็สำࠥ๎ลึๆสัࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ怫"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ怬"),l11ll1_l1_ (u"ࠩࠪ怭"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭怮"),l11ll1_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอัู้้ࠣไสࠢไ๎๋ࠥำห๊า฽ฬะฺࠠ็สำࠥษ่ࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭怯"))
	return l1l11l1111l1_l1_
def l1lll11l1llll_l1_():
	l1lll1111llll_l1_,l1llll111l1l1_l1_,l1llll111111l_l1_ = False,l11ll1_l1_ (u"ࠬ࠭怰"),l11ll1_l1_ (u"࠭ࠧ怱")
	l1llll11lll11_l1_,l1lll1l1ll1ll_l1_,l1lll1ll1l111_l1_ = False,l11ll1_l1_ (u"ࠧࠨ怲"),l11ll1_l1_ (u"ࠨࠩ怳")
	l1l11ll11111_l1_ = l1lll1l11l11_l1_([l11ll1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ怴"),l11ll1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ怵"),l11ll1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ怶")])
	for addon_id in [l11ll1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ怷"),l11ll1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ怸"),l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭怹")]:
		if addon_id not in list(l1l11ll11111_l1_.keys()): continue
		l1l11l1111l1_l1_,l1llllll1111_l1_,l1111lllll1_l1_,l1ll1lll1ll1_l1_,l11l1l111ll_l1_,l11ll1l111l_l1_,l1l11l111111_l1_ = l1l11ll11111_l1_[addon_id]
		if addon_id==l11ll1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭怺"):
			l1llll11lll11_l1_ = l1l11l1111l1_l1_
			l1lll1l1ll1ll_l1_ = l11ll1_l1_ (u"ࠩࠫࠫ总")+l1llllll1111_l1_+l11ll1_l1_ (u"ࠪࠤࠬ怼")+TRANSLATE(l11ll1l111l_l1_)+l11ll1_l1_ (u"ࠫ࠮࠭怽")
			l1lll1ll1l111_l1_ = l1ll1lll1ll1_l1_
		elif addon_id==l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ怾"):
			l1lll1111llll_l1_ = l1lll1111llll_l1_ or l1l11l1111l1_l1_
			l1llll111l1l1_l1_ += l11ll1_l1_ (u"࠭ࠠࠡ࠮ࠣࠤ࠭࠭怿")+l1llllll1111_l1_+l11ll1_l1_ (u"ࠧࠡࠩ恀")+TRANSLATE(l11ll1l111l_l1_)+l11ll1_l1_ (u"ࠨࠫࠪ恁")
			l1llll111111l_l1_ += l11ll1_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ恂")+l1ll1lll1ll1_l1_
		elif addon_id==l11ll1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ恃"):
			l1lll1l11l11l_l1_ = l1l11l1111l1_l1_
			l1lll11llllll_l1_ = l11ll1_l1_ (u"ࠫ࠭࠭恄")+l1llllll1111_l1_+l11ll1_l1_ (u"ࠬࠦࠧ恅")+TRANSLATE(l11ll1l111l_l1_)+l11ll1_l1_ (u"࠭ࠩࠨ恆")
			l1lll1llllll1_l1_ = l1ll1lll1ll1_l1_
	l1llll111l1l1_l1_ = l1llll111l1l1_l1_.strip(l11ll1_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭恇"))
	l1llll111111l_l1_ = l1llll111111l_l1_.strip(l11ll1_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ恈"))
	l1l11ll1l1_l1_  = l11ll1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ恉")+l1lll1ll1l111_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ恊")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠫࡡࡴࠧ恋")+l11ll1_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ恌")+l1lll1l1ll1ll_l1_+l11ll1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ恍")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ恎")+l11ll1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ึฮํีูࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ恏")+l1llll111111l_l1_+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ恐")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠪࡠࡳ࠭恑")+l11ll1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆีอ์ิ฿ฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ恒")+l1llll111l1l1_l1_+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ恓")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ恔")+l11ll1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭恕")+l1lll1llllll1_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恖")
	l1l11ll1l1_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲࠬ恗")+l11ll1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭恘")+l1lll11llllll_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭恙")
	l1l11l1111l1_l1_ = (l1llll11lll11_l1_ or l1lll1111llll_l1_)
	if l1l11l1111l1_l1_:
		header = l11ll1_l1_ (u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧ恚")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧ恛")
	else:
		header = l11ll1_l1_ (u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨ恜")
		l1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪ恝")
	l1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ恞")
	l1ll11ll1l_l1_ = l1l11ll1l1_l1_+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ恟")+l1l1l1ll11_l1_+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ恠")+l1l1l1l1ll_l1_
	l11ll1l111_l1_(l11ll1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ恡"),header,l1ll11ll1l_l1_,l11ll1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ恢"))
	return
def l1ll1l11ll11_l1_(l1ll_l1_=True,l1lll11ll1l1l_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ恣"),l11ll1_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ恤"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ恥"),l11ll1_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ恦"))
	if l1ll_l1_:
		l1lll11l1llll_l1_()
		l1lll1lllll1l_l1_()
	if l1lll11ll1l1l_l1_:
		l1l1l1l11l1l_l1_(False)
		l1llll1ll111l_l1_,l1lll11l111ll_l1_,l1lll11ll11ll_l1_ = l1lll11l1l1ll_l1_(l11ll1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ恧"),True,False)
		l1llll1ll11l1_l1_,l1lll11l111ll_l1_,l1llll111ll11_l1_ = l1lll11l1l1ll_l1_(l11ll1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ恨"),True,False)
		l1lll11lll1l1_l1_(l1ll_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ恩"))
	return
def l1lll1lll1lll_l1_(l1llll11l11l1_l1_=l11ll1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭恪"),l1ll_l1_=True):
	l111l11llll_l1_ = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ恫"))
	import json
	data = json.loads(l111l11llll_l1_)
	l1lll111ll111_l1_ = data[l11ll1_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ恬")][l11ll1_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ恭")]
	if kodi_version<19: l1lll111ll111_l1_ = l1lll111ll111_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ恮"))
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬ࠭息"),l11ll1_l1_ (u"࠭ࠧ恰"),l11ll1_l1_ (u"ࠧࠨ恱"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ恲"),l11ll1_l1_ (u"๊่ࠩࠥะั๋ัࠣฮ฿๐๊าࠢฯ่ิࠦࠧ恳")+l1lll111ll111_l1_+l11ll1_l1_ (u"ࠪࠤฬ๊ะ๋่ࠢืฯิฯๆࠢส่ว์ࠠโ์ࠣ็ํี๊ࠡว็ํࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤࠬ恴")+l1llll11l11l1_l1_+l11ll1_l1_ (u"ࠫࠥลࠡࠨ恵"))
		if l1ll111ll1_l1_!=1: return False
	succeeded,l1llll11111l1_l1_,l1lll111ll1ll_l1_ = l1lll11l1l1ll_l1_(l1llll11l11l1_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭恶"),l11ll1_l1_ (u"࠭ࠧ恷"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ恸"),l11ll1_l1_ (u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪ恹"))
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭恺")+l1llll11l11l1_l1_+l11ll1_l1_ (u"ࠪࠦࢂࢃࠧ恻"))
		if l11ll1_l1_ (u"ࠫࡔࡑࠧ恼") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ恽"))
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ恾"),l11ll1_l1_ (u"ࠧࠨ恿"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ悀"),l11ll1_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤํะแฺ์็ࠤฬ๊ฬๅัࠣห้๋ืๅ๊หࠫ悁"))
	return succeeded
def l11l11ll1ll_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11ll1_l1_ (u"ࠪࠫ悂"): l1ll_l1_ = True
	#l1lll1111ll1_l1_ = xbmc.getCondVisibility(l11ll1_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠧ悃")+addon_id+l11ll1_l1_ (u"ࠬ࠯ࠧ悄"))
	l11l1l1lll1_l1_ = l1ll1111l111_l1_([addon_id])
	l11l1111111_l1_,l1lll1111ll1_l1_ = l11l1l1lll1_l1_[addon_id]
	if l1lll1111ll1_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ悅"),l11ll1_l1_ (u"ࠧࠨ悆"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ悇"),l11ll1_l1_ (u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫ悈")+addon_id+l11ll1_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭悉"))
	else:
		succeeded = False
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ悊"),l11ll1_l1_ (u"ࠬ࠭悋"),l11ll1_l1_ (u"࠭ࠧ悌"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悍"),l11ll1_l1_ (u"ࠨࠩ悎")+addon_id+l11ll1_l1_ (u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤ๏฿ๅๅࠢส่อืๆศ็ฯࠤ฾์ฯไࠢหูํืษࠡืะ๎าฯࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧ悏"))
		if l1ll111ll1_l1_==1:
			xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪ悐")+addon_id+l11ll1_l1_ (u"ࠫ࠮࠭悑"))
			time.sleep(1)
			xbmc.executebuiltin(l11ll1_l1_ (u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ悒"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11ll1_l1_ (u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪ悓")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ悔")+addon_id+l11ll1_l1_ (u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭悕"))
			if l11ll1_l1_ (u"ࠩࡒࡏࠬ悖") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ悗"),l11ll1_l1_ (u"ࠫࠬ悘"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ悙"),l11ll1_l1_ (u"࠭สๆࠢไัฺࠦร้ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬ悚"))
			elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ悛"),l11ll1_l1_ (u"ࠨࠩ悜"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ悝"),l11ll1_l1_ (u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬ悞"))
	return succeeded
def l1lll11llll11_l1_(addon_id,l1l11l111111_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࠬ悟"),l11ll1_l1_ (u"ࠬ࠭悠"),l11ll1_l1_ (u"࠭ࠧ悡"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悢"),l11ll1_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫ患"))
		if l1ll111ll1_l1_!=1: return False
	l1lll111l11l1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l111111_l1_,{},l1ll_l1_)
	if l1lll111l11l1_l1_:
		l1l11l11ll11_l1_ = os.path.join(l1ll11llll_l1_,addon_id)
		l1ll11l1ll_l1_(l1l11l11ll11_l1_,True,False)
		import zipfile,io
		l1lll1l1ll1l1_l1_ = io.BytesIO(l1lll111l11l1_l1_)
		zf = zipfile.ZipFile(l1lll1l1ll1l1_l1_)
		zf.extractall(l1ll11llll_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭悤"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭悥")+addon_id+l11ll1_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ悦"))
		if l11ll1_l1_ (u"ࠬࡕࡋࠨ悧") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ您"),l11ll1_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ悩"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ悪"),l11ll1_l1_ (u"ࠩࠪ悫"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭悬"),l11ll1_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ悭"))
		else: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭悮"),l11ll1_l1_ (u"࠭ࠧ悯"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悰"),l11ll1_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭悱"))
	return succeeded
def l1lll11l1l1ll_l1_(addon_id,l1ll_l1_,l1lll1l11ll11_l1_):
	l1ll111ll1_l1_,succeeded,l1llll11111l1_l1_,l1llllll1111_l1_ = True,False,l11ll1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ悲"),l11ll1_l1_ (u"ࠪࠫ悳")
	l1l11ll11111_l1_ = l1lll1l11l11_l1_([addon_id])
	if addon_id in list(l1l11ll11111_l1_.keys()):
		l1l11l1111l1_l1_,l1llllll1111_l1_,l1111lllll1_l1_,l1ll1lll1ll1_l1_,l11l1l111ll_l1_,l11ll1l111l_l1_,l1l11l111111_l1_ = l1l11ll11111_l1_[addon_id]
		if l11ll1l111l_l1_==l11ll1_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ悴"):
			succeeded,l1llll11111l1_l1_ = True,l11ll1_l1_ (u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭悵")
			if l1lll1l11ll11_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ悶"),l11ll1_l1_ (u"ࠧࠨ悷"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ悸"),l11ll1_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦใ้ัํࠤ๏ูสฯั่ࠤศิัࠡวุำฬืࠠๆฬ๋ๅึࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦไ่า๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩ悹")+addon_id)
		else:
			if l1ll_l1_:
				if l11ll1l111l_l1_==l11ll1_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ悺"): message = l11ll1_l1_ (u"๊ࠫะ่ใใฬࠫ悻")
				elif l11ll1l111l_l1_==l11ll1_l1_ (u"ࠬࡵ࡬ࡥࠩ悼"): message = l11ll1_l1_ (u"࠭โะ์่อࠬ悽")
				elif l11ll1l111l_l1_==l11ll1_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ悾"): message = l11ll1_l1_ (u"ࠨ฼ํี๋ࠥหษฬฬࠫ悿")
				l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠩࠪ惀"),l11ll1_l1_ (u"ࠪࠫ惁"),l11ll1_l1_ (u"ࠫࠬ惂"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ惃"),l11ll1_l1_ (u"࠭็ั้ࠣห้หึศใฬࠤࠬ惄")+message+l11ll1_l1_ (u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩ情")+addon_id)
			if not l1ll111ll1_l1_: l1llll11111l1_l1_ = l11ll1_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪ惆")
			else:
				if l11ll1l111l_l1_==l11ll1_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ惇"):
					results = xbmc.executeJSONRPC(l11ll1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭惈")+addon_id+l11ll1_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ惉"))
					if l11ll1_l1_ (u"ࠬࡕࡋࠨ惊") in results:
						succeeded,l1llll11111l1_l1_ = True,l11ll1_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧ惋")
						if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ惌"),l11ll1_l1_ (u"ࠨࠩ惍"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ惎"),l11ll1_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨ惏")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ惐"),l11ll1_l1_ (u"ࠬ࠭惑"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ惒"),l11ll1_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪ惓")+addon_id)
				elif l11ll1l111l_l1_ in [l11ll1_l1_ (u"ࠨࡱ࡯ࡨࠬ惔"),l11ll1_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ惕")]:
					succeeded = l1lll11llll11_l1_(addon_id,l1l11l111111_l1_,False)
					if succeeded:
						if l11ll1l111l_l1_==l11ll1_l1_ (u"ࠪࡳࡱࡪࠧ惖"): l1llll11111l1_l1_ = l11ll1_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬ惗")
						elif l11ll1l111l_l1_==l11ll1_l1_ (u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭惘"): l1llll11111l1_l1_ = l11ll1_l1_ (u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ惙")
						l1llllll1111_l1_ = l1ll1lll1ll1_l1_
						if l1ll_l1_:
							if l1llll11111l1_l1_==l11ll1_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ惚"): DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ惛"),l11ll1_l1_ (u"ࠩࠪ惜"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭惝"),l11ll1_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨ惞")+addon_id)
							elif l1llll11111l1_l1_==l11ll1_l1_ (u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨ惟"): DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ惠"),l11ll1_l1_ (u"ࠧࠨ惡"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ惢"),l11ll1_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠๅ็ࠣฮ่์ࠠๆ๊ฯ์ิฯࠠโ์ࠣ็ํี๊ࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะหษ์อ๋ฬࡢ࡮࡝ࡰࠪ惣")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ惤"),l11ll1_l1_ (u"ࠫࠬ惥"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ惦"),l11ll1_l1_ (u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩ惧")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ惨"),l11ll1_l1_ (u"ࠨࠩ惩"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ惪"),l11ll1_l1_ (u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧ惫")+addon_id)
	return succeeded,l1llll11111l1_l1_,l1llllll1111_l1_
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ戨")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬ戩")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
l1l11l_l1_ = [l11ll1_l1_ (u"ࠧใ่๋หฯࠦแืษษ๎ฮ࠭截"),l11ll1_l1_ (u"ࠨใสีุ้่ࠨ戫"),l11ll1_l1_ (u"ࠩࡖ࡬ࡴࡽࠠ࡮ࡱࡵࡩࠬ戬")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l11111_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1llll1l_l1_(url,text)
	elif mode==584: results = l1l111_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ戭"),l11l1l_l1_,l11ll1_l1_ (u"ࠫࠬ戮"),l11ll1_l1_ (u"ࠬ࠭戯"),l11ll1_l1_ (u"࠭ࠧ戰"),l11ll1_l1_ (u"ࠧࠨ戱"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ戲"))
	html = response.content
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ戳"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ戴"),l11ll1_l1_ (u"ࠫࠬ戵"),589,l11ll1_l1_ (u"ࠬ࠭戶"),l11ll1_l1_ (u"࠭ࠧ户"),l11ll1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ戸"))
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭戹"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ戺"),l11ll1_l1_ (u"ࠪࠫ戻"),9999)
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ戼"),html,re.DOTALL)
	block = l1l1l11_l1_[0]
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ戽"),html,re.DOTALL)
	for l111l_l1_ in l1l1l11_l1_: block = block.replace(l111l_l1_,l11ll1_l1_ (u"࠭ࠧ戾"))
	items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ房"),block,re.DOTALL)
	for l1lllll_l1_,title in items:
		if title in l1l11l_l1_: continue
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ所"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ扁")+l111l1_l1_+title,l1lllll_l1_,584)
	return
def l1l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ扂"),url,l11ll1_l1_ (u"ࠫࠬ扃"),l11ll1_l1_ (u"ࠬ࠭扄"),l11ll1_l1_ (u"࠭ࠧ扅"),l11ll1_l1_ (u"ࠧࠨ扆"),l11ll1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ扇"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭扈"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		block = block.replace(l11ll1_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ扉"),l11ll1_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ扊"))
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ手"),block,re.DOTALL)
		if not l1l1l11_l1_: l1l1l11_l1_ = [(l11ll1_l1_ (u"࠭ࠧ扌"),block)]
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ才"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭扎"),l11ll1_l1_ (u"ࠩࠪ扏"),9999)
		for l111ll_l1_,block in l1l1l11_l1_:
			items = re.findall(l11ll1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ扐"),block,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࠦࠧ扑")
			for l1lllll_l1_,title in items:
				title = l111ll_l1_+title
				addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ扒"),l111l1_l1_+title,l1lllll_l1_,581)
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ打"),html,re.DOTALL)
	if l1l111l_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ扔"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭払"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ扖"),l11ll1_l1_ (u"ࠪࠫ扗"),9999)
			for l1lllll_l1_,title in items:
				addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ托"),l111l1_l1_+title,l1lllll_l1_,581)
	if not l1l11l1_l1_ and not l1l111l_l1_: l11111_l1_(url)
	return
def l11111_l1_(url,request=l11ll1_l1_ (u"ࠬ࠭扙")):
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ扚"),l11ll1_l1_ (u"ࠧࠨ扛"),request,url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ扜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭扝"),url,l11ll1_l1_ (u"ࠪࠫ扞"),l11ll1_l1_ (u"ࠫࠬ扟"),l11ll1_l1_ (u"ࠬ࠭扠"),l11ll1_l1_ (u"࠭ࠧ扡"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ扢"))
	html = response.content
	items = []
	l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ扣"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ扤"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ扥"),html,re.DOTALL)
	if not l1l1l11_l1_: l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ扦"),html,re.DOTALL)
	if not l1l1l11_l1_: return
	block = l1l1l11_l1_[0]
	if not items: items = re.findall(l11ll1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭执"),block,re.DOTALL)
	if not items: items = re.findall(l11ll1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ扨"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll1l_l1_ = [l11ll1_l1_ (u"ࠧๆึส๋ิฯࠧ扩"),l11ll1_l1_ (u"ࠨใํ่๊࠭扪"),l11ll1_l1_ (u"ࠩส฾๋๐ษࠨ扫"),l11ll1_l1_ (u"ࠪ็้๐ศࠨ扬"),l11ll1_l1_ (u"ࠫฬ฿ไศ่ࠪ扭"),l11ll1_l1_ (u"ࠬํฯศใࠪ扮"),l11ll1_l1_ (u"࠭ๅษษิหฮ࠭扯"),l11ll1_l1_ (u"ฺࠧำูࠫ扰"),l11ll1_l1_ (u"ࠨ็๊ีัอๆࠨ扱"),l11ll1_l1_ (u"ࠩส่อ๎ๅࠨ扲"),l11ll1_l1_ (u"ุ้ࠪือ๋หࠪ扳")]
	for l1lll1_l1_,l1lllll_l1_,title in items:
		l1lllll_l1_ = l1111_l1_(l1lllll_l1_).strip(l11ll1_l1_ (u"ࠫ࠴࠭扴"))
		if l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ扵") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"࠭࠯ࠨ扶")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠧ࠰ࠩ扷"))
		if l11ll1_l1_ (u"ࠨࡪࡷࡸࡵ࠭扸") not in l1lll1_l1_: l1lll1_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠩ࠲ࠫ批")+l1lll1_l1_.strip(l11ll1_l1_ (u"ࠪ࠳ࠬ扺"))
		#l1lllll_l1_ = unescapeHTML(l1lllll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11ll1_l1_ (u"ࠫࠥ࠭扻"))
		l1ll1l1_l1_ = re.findall(l11ll1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ扼"),title,re.DOTALL)
		if any(value in title for value in l1ll1l_l1_):
			addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ扽"),l111l1_l1_+title,l1lllll_l1_,582,l1lll1_l1_)
		elif l1ll1l1_l1_ and l11ll1_l1_ (u"ࠧศๆะ่็ฯࠧ找") in title:
			title = l11ll1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ承") + l1ll1l1_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ技"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
				l11l_l1_.append(title)
		elif l11ll1_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ抁") in l1lllll_l1_:
			addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ抂"),l111l1_l1_+title,l1lllll_l1_,581,l1lll1_l1_)
		else: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ抃"),l111l1_l1_+title,l1lllll_l1_,583,l1lll1_l1_)
	if request not in [l11ll1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨ抄"),l11ll1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ抅")]:
		l1l1l11_l1_ = re.findall(l11ll1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ抆"),html,re.DOTALL)
		if l1l1l11_l1_:
			block = l1l1l11_l1_[0]
			items = re.findall(l11ll1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ抇"),block,re.DOTALL)
			for l1lllll_l1_,title in items:
				if l1lllll_l1_==l11ll1_l1_ (u"ࠪࠧࠬ抈"): continue
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠫ࠴࠭抉")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠬ࠵ࠧ把"))
				title = unescapeHTML(title)
				addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抋"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥ࠭抌")+title,l1lllll_l1_,581)
		l1llll1ll1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡵ࡫ࡳࡼࡳ࡯ࡳࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ抍"),html,re.DOTALL)
		if l1llll1ll1_l1_:
			l1lllll_l1_ = l1llll1ll1_l1_[0]
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ抎"),l111l1_l1_+l11ll1_l1_ (u"ู้ࠪอ็ะหࠣห้๋า๋ัࠪ抏"),l1lllll_l1_,581)
	return
def l1llll1l_l1_(url,l1l1l_l1_):
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ抐"),l11ll1_l1_ (u"ࠬ࠭抑"),l1l1l_l1_,url)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ抒"),l11ll1_l1_ (u"ࠧ࠲࠳࠴࠵ࠥࠦࠧ抓")+url)
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ抔"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭投"),url,l11ll1_l1_ (u"ࠪࠫ抖"),l11ll1_l1_ (u"ࠫࠬ抗"),l11ll1_l1_ (u"ࠬ࠭折"),l11ll1_l1_ (u"࠭ࠧ抙"),l11ll1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ抚"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11ll1_l1_ (u"ࠨࡰࡤࡺ࠲ࡹࡥࡢࡵࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ抛"),html,re.DOTALL)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ抜"),str(l1l1l_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ抝"),str(l1l111l_l1_))
	items = []
	# l1lll1l_l1_
	l11l1_l1_ = False
	if l1l11l1_l1_ and not l1l1l_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭択"),block,re.DOTALL)
		for l1l1l_l1_,title in items:
			l1l1l_l1_ = l1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠩࠧ抟"))
			if len(items)>1: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抠"),l111l1_l1_+title,url,583,l11ll1_l1_ (u"ࠧࠨ抡"),l11ll1_l1_ (u"ࠨࠩ抢"),l1l1l_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	# l1l11_l1_
	l1l111l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ抣")+l1l1l_l1_+l11ll1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ护"),html,re.DOTALL)
	if l1l111l_l1_ and l11l1_l1_:
		block = l1l111l_l1_[0]
		items = re.findall(l11ll1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ报"),block,re.DOTALL)
		if items:
			for l1lllll_l1_,title in items:
				l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ抦")+l1lllll_l1_.strip(l11ll1_l1_ (u"࠭࠯ࠨ抧"))
				addMenuItem(l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭抨"),l111l1_l1_+title,l1lllll_l1_,582)
		else:
			items = re.findall(l11ll1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ抩"),block,re.DOTALL)
			for l1lllll_l1_,title,l1lll1_l1_ in items:
				if l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ抪") not in l1lllll_l1_: l1lllll_l1_ = l1ll111_l1_+l11ll1_l1_ (u"ࠪ࠳ࠬ披")+l1lllll_l1_.strip(l11ll1_l1_ (u"ࠫ࠴࠭抬"))
				addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ抭"),l111l1_l1_+title,l1lllll_l1_,582)
	return
def PLAY(url):
	l1ll111_l1_ = SERVER(url,l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ抮"))
	l1llll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11ll1_l1_ (u"ࠧࡈࡇࡗࠫ抯"),url,l11ll1_l1_ (u"ࠨࠩ抰"),l11ll1_l1_ (u"ࠩࠪ抱"),l11ll1_l1_ (u"ࠪࠫ抲"),l11ll1_l1_ (u"ࠫࠬ抳"),l11ll1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ抴"))
	html = response.content
	# l1lll11_l1_ l1l1111_l1_
	l1lllll_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ抵"),html,re.DOTALL)
	l1lllll_l1_ = l1lllll_l1_[0]
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ抶") not in l1lllll_l1_: l1lllll_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ抷")+l1lllll_l1_
	#//www.l1ll1llllll1l_l1_.l1ll1llllll11_l1_/l1ll1lllllll1_l1_/?l1ll1llllllll_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩ࡫ࡥࡸ࡮࠽ࠨ抸"))[1]
	parts = hash.split(l11ll1_l1_ (u"ࠪࡣࡤ࠭抹"))
	l1l11lll11ll_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11ll1_l1_ (u"ࠫࡂ࠭抺"))
			if kodi_version>18.99: part = part.decode(l11ll1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ抻"))
			l1l11lll11ll_l1_.append(part)
		except: pass
	l1l1_l1_ = l11ll1_l1_ (u"࠭࠾ࠨ押").join(l1l11lll11ll_l1_)
	l1l1_l1_ = l1l1_l1_.splitlines()
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ抽"),str(l1l1_l1_))
	if l11ll1_l1_ (u"ࠨࡨࡤࡶࡸࡵ࡬ࠨ抾") not in str(l1l1_l1_):
		for l1lllll_l1_ in l1l1_l1_:
			title,l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠣࡁࡃࠦࠧ抿"))
			l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ拀")+title+l11ll1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ拁")
			l1llll_l1_.append(l1lllll_l1_)
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ拂"),l1llll_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1llll_l1_,script_name,l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ拃"),url)
	else:
		title,l1lllll_l1_ = l1l1_l1_[0].split(l11ll1_l1_ (u"ࠧࠡ࠿ࡁࠤࠬ拄"))
		DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ担"),l11ll1_l1_ (u"ࠩࠪ拆"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭拇"),l11ll1_l1_ (u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠪ拈")+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ拉")+l11ll1_l1_ (u"๊࠭าฮ์ࠤฬ๊ๅฮษ๋่ฮࠦไศฯๅหࠬ拊")+l11ll1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ拋")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11ll1_l1_ (u"ࠨࠩ拌"): search = OPEN_KEYBOARD()
	if search==l11ll1_l1_ (u"ࠩࠪ拍"): return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ拎"),l11ll1_l1_ (u"ࠫ࠰࠭拏"))
	url = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭拐")+search
	l11111_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ㹼")
l11l1l_l1_ = l1l1lll_l1_[l11ll1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㹽")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11ll1_l1_ (u"ࠪ࠴ࠬ㹾"),True)
	elif mode==102: results = ITEMS(l11ll1_l1_ (u"ࠫ࠶࠭㹿"),True)
	elif mode==103: results = ITEMS(l11ll1_l1_ (u"ࠬ࠸ࠧ㺀"),True)
	elif mode==104: results = ITEMS(l11ll1_l1_ (u"࠭࠳ࠨ㺁"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11ll1_l1_ (u"ࠧ࠵ࠩ㺂"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㺃"),l11ll1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㺄")+l11ll1_l1_ (u"่้๋ࠪิหำๆ๎๋ࠦศฯั่อࠥࡓ࠳ࡖࠩ㺅"),l11ll1_l1_ (u"ࠫࠬ㺆"),710)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺇"),l11ll1_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ㺈")+l11ll1_l1_ (u"ࠧๅๆุ่ฯืใ๋่ࠣฬำีๅสࠢࡌࡔ࡙࡜ࠧ㺉"),l11ll1_l1_ (u"ࠨࠩ㺊"),230)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺋"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠰ࡠࠩ㺌")+l11ll1_l1_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨ㺍"),l11ll1_l1_ (u"ࠬ࠭㺎"),101)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺏"),l11ll1_l1_ (u"ࠧࡠࡖ࡙࠸ࡤ࠭㺐")+l11ll1_l1_ (u"ࠨไ้์ฬะࠠๆะอหึฯࠠๆ่ࠣ๎ํะ๊้สࠪ㺑"),l11ll1_l1_ (u"ࠩࠪ㺒"),106)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺓"),l11ll1_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㺔")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤ฾ืศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㺕"),l11ll1_l1_ (u"࠭ࠧ㺖"),147)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㺗"),l11ll1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ㺘")+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡลฯ๊อ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㺙"),l11ll1_l1_ (u"ࠪࠫ㺚"),148)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺛"),l11ll1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㺜")+l11ll1_l1_ (u"࠭ࠠࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠣࠤࠬ㺝"),l11ll1_l1_ (u"ࠧࠨ㺞"),28)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㺟"),l11ll1_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨ㺠")+l11ll1_l1_ (u"ࠪๆ๋อษࠡษ็้฾อัโ่๊๋่ࠢࠥใ฻๊้ࠬ㺡"),l11ll1_l1_ (u"ࠫࠬ㺢"),41)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㺣"),l11ll1_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬ㺤")+l11ll1_l1_ (u"ࠧใ่สอࠥอไไ๊ฮี๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㺥"),l11ll1_l1_ (u"ࠨࠩ㺦"),135)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㺧"),l11ll1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ㺨")+l11ll1_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭㺩"),l11ll1_l1_ (u"ࠬ࠭㺪"),38)
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㺫"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㺬"),l11ll1_l1_ (u"ࠨࠩ㺭"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺮"),l11ll1_l1_ (u"ࠪࡣ࡙࡜࠱ࡠࠩ㺯")+l11ll1_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮูࠦศ็ฬࠫ㺰"),l11ll1_l1_ (u"ࠬ࠭㺱"),102)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺲"),l11ll1_l1_ (u"ࠧࡠࡖ࡙࠶ࡤ࠭㺳")+l11ll1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣาฬ฻ษࠨ㺴"),l11ll1_l1_ (u"ࠩࠪ㺵"),103)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺶"),l11ll1_l1_ (u"ࠫࡤ࡚ࡖ࠴ࡡࠪ㺷")+l11ll1_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠๅๆไัฺ࠭㺸"),l11ll1_l1_ (u"࠭ࠧ㺹"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111l1_l1_ = l11ll1_l1_ (u"ࠧࡠࡖ࡙ࠫ㺺")+menu+l11ll1_l1_ (u"ࠨࡡࠪ㺻")
	user = l1l11l111ll_l1_(32)
	payload = {l11ll1_l1_ (u"ࠩ࡬ࡨࠬ㺼"):l11ll1_l1_ (u"ࠪࠫ㺽"),l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㺾"):user,l11ll1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㺿"):l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㻀"),l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㻁"):menu}
	#data = l1ll1l11l_l1_(payload)
	#LOG_THIS(l11ll1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㻂"),str(payload))
	#LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㻃"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㻄"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠫࠬ㻅"), True,l11ll1_l1_ (u"ࠬ࠭㻆"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㻇"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㻈"),l11l1l_l1_,payload,l11ll1_l1_ (u"ࠨࠩ㻉"),l11ll1_l1_ (u"ࠩࠪ㻊"),l11ll1_l1_ (u"ࠪࠫ㻋"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㻌"))
	html = response.content
	#html = html.replace(l11ll1_l1_ (u"ࠬࡢࡲࠨ㻍"),l11ll1_l1_ (u"࠭ࠧ㻎"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ㻏"),l11ll1_l1_ (u"ࠨࠩ㻐"),html,html)
	#file = open(l11ll1_l1_ (u"ࠩࡶ࠾࠴࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ㻑"), l11ll1_l1_ (u"ࠪࡻࠬ㻒"))
	#file.write(html)
	#file.close()
	items = re.findall(l11ll1_l1_ (u"ࠫ࠭ࡡ࡞࠼࡞ࡵࡠࡳࡣࠫࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿ࠬ㻓"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11ll1_l1_ (u"ࠬࡧ࡬ࠨ㻔"),l11ll1_l1_ (u"࠭ࡁ࡭ࠩ㻕"))
			start = start.replace(l11ll1_l1_ (u"ࠧࡆ࡮ࠪ㻖"),l11ll1_l1_ (u"ࠨࡃ࡯ࠫ㻗"))
			start = start.replace(l11ll1_l1_ (u"ࠩࡄࡐࠬ㻘"),l11ll1_l1_ (u"ࠪࡅࡱ࠭㻙"))
			start = start.replace(l11ll1_l1_ (u"ࠫࡊࡒࠧ㻚"),l11ll1_l1_ (u"ࠬࡇ࡬ࠨ㻛"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11ll1_l1_ (u"࠭ࡁ࡭࠯ࠪ㻜"),l11ll1_l1_ (u"ࠧࡂ࡮ࠪ㻝"))
			start = start.replace(l11ll1_l1_ (u"ࠨࡃ࡯ࠤࠬ㻞"),l11ll1_l1_ (u"ࠩࡄࡰࠬ㻟"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1l11_l1_,name,l1lll1_l1_ in items:
			if l11ll1_l1_ (u"ࠪࠧࠬ㻠") in source: continue
			#if source in [l11ll1_l1_ (u"ࠫࡓ࡚ࠧ㻡"),l11ll1_l1_ (u"ࠬ࡟ࡕࠨ㻢"),l11ll1_l1_ (u"࠭ࡗࡔ࠲ࠪ㻣"),l11ll1_l1_ (u"ࠧࡓࡎ࠴ࠫ㻤"),l11ll1_l1_ (u"ࠨࡔࡏ࠶ࠬ㻥")]: continue
			if source!=l11ll1_l1_ (u"ࠩࡘࡖࡑ࠭㻦"): name = name+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠࠡࠩ㻧")+source+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㻨")
			url = source+l11ll1_l1_ (u"ࠬࡁ࠻ࠨ㻩")+server+l11ll1_l1_ (u"࠭࠻࠼ࠩ㻪")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠧ࠼࠽ࠪ㻫")+menu
			addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㻬"),l111l1_l1_+l11ll1_l1_ (u"ࠩࠪ㻭")+name,url,105,l1lll1_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㻮"),l111l1_l1_+l11ll1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㻯"),l11ll1_l1_ (u"ࠬ࠭㻰"),9999)
		#if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㻱"),l11ll1_l1_ (u"ࠧࠨ㻲"),l11ll1_l1_ (u"ࠨࠩ㻳"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㻴"))
		#addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㻵"),l111l1_l1_+l11ll1_l1_ (u"้๊ࠫริใ่ࠣฬࠦส้ฮาࠤ็์่ศฬࠣฮ้็า้่ํอ๊ࠥใࠨ㻶"),l11ll1_l1_ (u"ࠬ࠭㻷"),9999)
		#addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㻸"),l111l1_l1_+l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้ࠣอโาสสลࠥ๎วๅษุำ็อมࠡใๅ฻ࠬ㻹"),l11ll1_l1_ (u"ࠨࠩ㻺"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㻻"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㻼"),l11ll1_l1_ (u"ࠫࠬ㻽"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㻾"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡕ࡯ࡨࡲࡶࡹࡻ࡮ࡢࡶࡨࡰࡾ࠲ࠠ࡯ࡱࠣࡘ࡛ࠦࡣࡩࡣࡱࡲࡪࡲࡳࠡࡨࡲࡶࠥࡿ࡯ࡶࠩ㻿"),l11ll1_l1_ (u"ࠧࠨ㼀"),9999)
		#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㼁"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡌࡸࠥ࡯ࡳࠡࡨࡲࡶࠥࡸࡥ࡭ࡣࡷ࡭ࡻ࡫ࡳࠡࠨࠣࡪࡷ࡯ࡥ࡯ࡦࡶࠤࡴࡴ࡬ࡺࠩ㼂"),l11ll1_l1_ (u"ࠪࠫ㼃"),9999)
	return
def PLAY(id):
	source,server,l11lll1l11_l1_,menu = id.split(l11ll1_l1_ (u"ࠫࡀࡁࠧ㼄"))
	url = l11ll1_l1_ (u"ࠬ࠭㼅")
	user = l1l11l111ll_l1_(32)
	if source==l11ll1_l1_ (u"࠭ࡕࡓࡎࠪ㼆"): url = l11lll1l11_l1_
	elif source==l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㼇"):
		url = l1l1lll_l1_[l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㼈")][0]+l11ll1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ㼉")+l11lll1l11_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㼊"),url)
		return
	elif source==l11ll1_l1_ (u"ࠫࡌࡇࠧ㼋"):
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㼌") : l11ll1_l1_ (u"࠭ࠧ㼍"), l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࠬ㼎") : user , l11ll1_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㼏") : l11ll1_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠳ࠪ㼐") , l11ll1_l1_ (u"ࠪࡱࡪࡴࡵࠨ㼑") : l11ll1_l1_ (u"ࠫࠬ㼒") }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ㼓"),l11l1l_l1_,payload,l11ll1_l1_ (u"࠭ࠧ㼔"),False,l11ll1_l1_ (u"ࠧࠨ㼕"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㼖"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㼗"),l11ll1_l1_ (u"ࠪࠫ㼘"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㼙"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㼚"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l111lllll1_l1_ = cookies[l11ll1_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࠪ㼛")]
		url = response.headers[l11ll1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㼜")]
		payload = { l11ll1_l1_ (u"ࠨ࡫ࡧࠫ㼝") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㼞") : user , l11ll1_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㼟") : l11ll1_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠶ࠬ㼠") , l11ll1_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㼡") : l11ll1_l1_ (u"࠭ࠧ㼢") }
		headers = { l11ll1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ㼣") : l11ll1_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࡂ࠭㼤")+l1l111lllll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡊࡉ࡙࠭㼥"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠪࠫ㼦"),l11ll1_l1_ (u"ࠫࠬ㼧"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ㼨"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㼩"),l11ll1_l1_ (u"ࠧࠨ㼪"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㼫"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㼬"))
			return
		html = response.content
		url = re.findall(l11ll1_l1_ (u"ࠪࡶࡪࡹࡰࠣ࠼ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃࡲ࠹ࡵ࠹ࠫࠫ࠲࠯ࡅࠩࠣࠩ㼭"),html,re.DOTALL)
		l1lllll_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ㼮"),l11ll1_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭㼯")+l1lllll_l1_)
		#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ㼰"),l11ll1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠠࠨ㼱")+params)
		l1l111llll1l_l1_ = l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠵࠻࠲ࠬ㼲")+server+l11ll1_l1_ (u"ࠩ࠺࠻࠼࠵ࠧ㼳")+l11lll1l11_l1_+l11ll1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㼴")+params
		l1l111llll11_l1_ = l1l111llll1l_l1_.replace(l11ll1_l1_ (u"ࠫ࠸࠼࠺࠸ࠩ㼵"),l11ll1_l1_ (u"ࠬ࠺࠰࠻࠹ࠪ㼶")).replace(l11ll1_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㼷"),l11ll1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㼸"))
		l1l111llllll_l1_ = l1l111llll1l_l1_.replace(l11ll1_l1_ (u"ࠨ࠵࠹࠾࠼࠭㼹"),l11ll1_l1_ (u"ࠩ࠷࠶࠿࠽ࠧ㼺")).replace(l11ll1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㼻"),l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㼼"))
		l1lll11l_l1_ = [l11ll1_l1_ (u"ࠬࡎࡄࠨ㼽"),l11ll1_l1_ (u"࠭ࡓࡅ࠳ࠪ㼾"),l11ll1_l1_ (u"ࠧࡔࡆ࠵ࠫ㼿")]
		l1llll_l1_ = [l1l111llll1l_l1_,l1l111llll11_l1_,l1l111llllll_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ㽀"), l1lll11l_l1_)
		if l1l_l1_ == -1: return
		else: url = l1llll_l1_[l1l_l1_]
	elif source==l11ll1_l1_ (u"ࠩࡑࡘࠬ㽁"):
		headers = { l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㽂") : l11ll1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㽃") }
		payload = { l11ll1_l1_ (u"ࠬ࡯ࡤࠨ㽄") : l11lll1l11_l1_ , l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㽅") : user , l11ll1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㽆") : l11ll1_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨ㽇") , l11ll1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㽈") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㽉"), l11l1l_l1_, payload, headers, False,l11ll1_l1_ (u"ࠫࠬ㽊"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㽋"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ㽌"),l11ll1_l1_ (u"ࠧࠨ㽍"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㽎"),l11ll1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㽏"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㽐")]
		url = url.replace(l11ll1_l1_ (u"ࠫࠪ࠸࠰ࠨ㽑"),l11ll1_l1_ (u"ࠬࠦࠧ㽒"))
		url = url.replace(l11ll1_l1_ (u"࠭ࠥ࠴ࡆࠪ㽓"),l11ll1_l1_ (u"ࠧ࠾ࠩ㽔"))
		if l11ll1_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧ㽕") in l11lll1l11_l1_:
			url = url.replace(l11ll1_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪ㽖"),l11ll1_l1_ (u"ࠪࠫ㽗"))
			url = url.replace(l11ll1_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧ㽘"),l11ll1_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧ㽙"))
	elif source==l11ll1_l1_ (u"࠭ࡐࡍࠩ㽚"):
		#headers = { l11ll1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㽛") : l11ll1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㽜") }
		payload = { l11ll1_l1_ (u"ࠩ࡬ࡨࠬ㽝") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㽞") : user , l11ll1_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㽟") : l11ll1_l1_ (u"ࠬࡶ࡬ࡢࡻࡓࡐࠬ㽠") , l11ll1_l1_ (u"࠭࡭ࡦࡰࡸࠫ㽡") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㽢"), l11l1l_l1_, payload, l11ll1_l1_ (u"ࠨࠩ㽣"),False,l11ll1_l1_ (u"ࠩࠪ㽤"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ㽥"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ㽦"),l11ll1_l1_ (u"ࠬ࠭㽧"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㽨"),l11ll1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㽩"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㽪")]
		headers = {l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㽫"):response.headers[l11ll1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㽬")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㽭"),url, l11ll1_l1_ (u"ࠬ࠭㽮"),headers , l11ll1_l1_ (u"࠭ࠧ㽯"),l11ll1_l1_ (u"ࠧࠨ㽰"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ㽱"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ㽲"),l11ll1_l1_ (u"ࠪࠫ㽳"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㽴"),l11ll1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㽵"))
			return
		html = response.content
		items = re.findall(l11ll1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㽶"),html,re.DOTALL)
		url = items[0]
	elif source in [l11ll1_l1_ (u"ࠧࡕࡃࠪ㽷"),l11ll1_l1_ (u"ࠨࡈࡐࠫ㽸"),l11ll1_l1_ (u"ࠩ࡜࡙ࠬ㽹"),l11ll1_l1_ (u"࡛ࠪࡘ࠷ࠧ㽺"),l11ll1_l1_ (u"ࠫ࡜࡙࠲ࠨ㽻"),l11ll1_l1_ (u"ࠬࡘࡌ࠲ࠩ㽼"),l11ll1_l1_ (u"࠭ࡒࡍ࠴ࠪ㽽")]:
		if source==l11ll1_l1_ (u"ࠧࡕࡃࠪ㽾"): l11lll1l11_l1_ = id
		headers = { l11ll1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㽿") : l11ll1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㾀") }
		payload = { l11ll1_l1_ (u"ࠪ࡭ࡩ࠭㾁") : l11lll1l11_l1_ , l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㾂") : user , l11ll1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㾃") : l11ll1_l1_ (u"࠭ࡰ࡭ࡣࡼࠫ㾄")+source , l11ll1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㾅") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㾆"),l11l1l_l1_,payload,headers,l11ll1_l1_ (u"ࠩࠪ㾇"),l11ll1_l1_ (u"ࠪࠫ㾈"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠹ࡸ࡭࠭㾉"))
		if not response.succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭㾊"),l11ll1_l1_ (u"࠭ࠧ㾋"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㾌"),l11ll1_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㾍"))
			return
		html = response.content
		url = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㾎")]
		if source==l11ll1_l1_ (u"ࠪࡊࡒ࠭㾏"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ㾐"), url, l11ll1_l1_ (u"ࠬ࠭㾑"), l11ll1_l1_ (u"࠭ࠧ㾒"), False,l11ll1_l1_ (u"ࠧࠨ㾓"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪ㾔"))
			url = response.headers[l11ll1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㾕")]
			url = url.replace(l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㾖"),l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㾗"))
	PLAY_VIDEO(url,script_name,l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㾘"))
	return
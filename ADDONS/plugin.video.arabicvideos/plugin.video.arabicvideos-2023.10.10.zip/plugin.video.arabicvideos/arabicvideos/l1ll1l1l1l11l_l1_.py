# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭每")
l111l1_l1_ = l11ll1_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ毐")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠧࠨ毑")
#headers = {l11ll1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ毒"):l11ll1_l1_ (u"ࠩࠪ毓")}
def MAIN(mode,url,text,type,l1l1111_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11111ll_l1_(url)
	#elif mode==142: results = l1ll1l1l11l1l_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l1111_l1_)
	elif mode==145: results = l1ll1lll11111_l1_(url)
	elif mode==146: results = l1ll1l11lllll_l1_(url)
	elif mode==147: results = l1ll1ll11ll11_l1_()
	elif mode==148: results = l1ll1ll11lll1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࡐࡍࡆ࠶࡜ࡨ࡞ࡋࡃࡗࡶࡾࡱࡈࡴࡎࡕࡺࡊ࡫ࡠ࡚ࡗࡖࡏࡔࡐࢀࡺࡱࡴࡻࡓࡘ࠭比")
	#addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毕"),l111l1_l1_+l11ll1_l1_ (u"࡚ࠬࡅࡔࡖࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠫ毖"),url,144)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭毗"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡰ࡮ࡧࡩࡷࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠡࡰࡲࡸࠥࡲࡩࡴࡶ࡬ࡲ࡬ࠦ࡮ࡦࡹࡨࡶࠥࡶ࡬ࡺࡣ࡯࡭ࡸࡺࠧ毘"),l11ll1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡞ࡆࡱࡳࡨ࡝ࡿ࡞࡚ࡧ࡭ࠩࡰ࡮ࡹࡴ࠾ࡔࡇࡕࡒ࠼࠳ࡷࡊ࡭ࡔ࠵࡮ࡥࡕࡵࠪ毙"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毚"),l111l1_l1_+l11ll1_l1_ (u"้ࠪํู่ࠡใสี฿࠭毛"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࡕࡄࡶࡒࡺࡴࡴࡪ࠵ࡉࡼࡳࡵࡓࡔࡎࡄࡤ࠶࠸ࡷࡕࡤࡹࠪ毜"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毝"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭毞"),l11ll1_l1_ (u"ࠧࠨ毟"),149,l11ll1_l1_ (u"ࠨࠩ毠"),l11ll1_l1_ (u"ࠩࠪ毡"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ毢"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毣"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ毤")+l11ll1_l1_ (u"࠭࡟࡚ࡖࡆࡣࠬ毥")+l11ll1_l1_ (u"ࠧๆ๊สๆ฾ࠦวฯฬสี์อࠠศๆ่ฬึ๋ฬࠨ毦"),l11ll1_l1_ (u"ࠨࠩ毧"),290)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毨"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ毩")+l111l1_l1_+l11ll1_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤ๏๎ส๋๊หࠫ毪"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ毫"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭毬"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ毭")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ毮"),l11l1l_l1_,144,l11ll1_l1_ (u"ࠩࠪ毯"),l11ll1_l1_ (u"ࠪࠫ毰"),l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ毱"))
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毲"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ毳")+l111l1_l1_+l11ll1_l1_ (u"ࠧศๆ่ัฯ๎้ࠡษ็ีฬฬฬࠨ毴"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ毵"),146)
	addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ毶"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ毷"),l11ll1_l1_ (u"ࠫࠬ毸"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毹"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ毺")+l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤ฾ืศ๋หࠪ毻"),l11ll1_l1_ (u"ࠨࠩ毼"),147)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毽"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ毾")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ毿"),l11ll1_l1_ (u"ࠬ࠭氀"),148)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭氁"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ氂")+l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ氃"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ氄"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ氅"),script_name+l11ll1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭氆")+l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢสะ๋ฮ๊สࠩ氇"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽࡮ࡱࡹ࡭ࡪ࠭氈"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氉"),script_name+l11ll1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ氊")+l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ氋"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ氌"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ氍"),script_name+l11ll1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ氎")+l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥ฿ัษ์ฬࠫ氏"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึุ่๊ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ氐"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ民"),script_name+l11ll1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ氒")+l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ氓"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ气"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ氕"),script_name+l11ll1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ氖")+l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦใศำอ์๋࠭気"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๆหึะ่็ࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ氘"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ氙"),script_name+l11ll1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ氚")+l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ氛"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ氜"),144)
	#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭氝"),script_name+l11ll1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ氞")+l111l1_l1_+l11ll1_l1_ (u"ࠨษ็฽ึอโࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ氟"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑ࠺ࡪࡖࡳ࠹ࡴࡳࡍ࠳࠷ࡓ࡭ࡹ࡝ࡊࡨࡏࡰࡌࡰࡷ࡯ࡵࡻࡴࡲࡘࡋࡺ࡭ࡧࡴࠪ氠"),144)
	#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ氡"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ฿ฯศัสฮࠥอึศใฬࠤ๏๎ส๋๊หࠫ氢"),l11ll1_l1_ (u"ࠬ࠭氣"),144)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭氤"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭氥"),l11ll1_l1_ (u"ࠨ้ำหࠥอไศะอ๎ฬืࠠิ๊ไࠤ๏ิัอๅ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨ氦"),l11ll1_l1_ (u"ࠩ็ว๋ํࠠิ๊ไࠤ๏่่ๆࠢหฮูเ๊ๅࠢหี๋อๅอࠢํ์ฯ๐่ษࠩ氧"))
	#if l1ll111ll1_l1_==1:
	#	url = l11ll1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ氨")
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠩࠨ氩"))
	#	xbmc.executebuiltin(l11ll1_l1_ (u"ࠬࡘࡥࡱ࡮ࡤࡧࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡼࡩࡥࡧࡲࡷ࠱࠭氪")+url+l11ll1_l1_ (u"࠭ࠩࠨ氫"))
	#	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠧࡓࡷࡱࡅࡩࡪ࡯࡯ࠪࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠫࠪ氬"))
	return
l11ll1_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡏࡄࡍࡓࡖࡁࡈࡇࠫࡹࡷࡲࠩ࠻ࠌࠌ࡬ࡹࡳ࡬࠭ࡥࡦ࠰ࡩࡧࡴࡢࠢࡀࠤࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄࠬࡺࡸ࡬ࠪࠌࠌ࡭࡫ࠦࠧࡓࡧࡩࡥࡦࡺࠠࡂ࡮࠰ࡋࡦࡳ࡭ࡢ࡮ࠪࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠦࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡷࡵࡰ࠱࠭ࡹࡦࡵࠪ࠭ࠏࠏࡤࡥࠢࡀࠤࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡳࡧࡧࡦࠪ࡯ࡩࡳ࠮ࡤࡥࠫࠬ࠾ࠏࠏࠉࡪࡶࡨࡱࠥࡃࠠࡥࡦ࡞࡭ࡢࠐࠉࠊࡋࡑࡗࡊࡘࡔࡠࡋࡗࡉࡒࡥࡔࡐࡡࡐࡉࡓ࡛ࠨࡪࡶࡨࡱ࠮ࠐࠉࡊࡖࡈࡑࡘ࠮ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ氭")
def l1ll1ll11ll11_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬสฮࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ氮"))
	return
def l1ll1ll11lll1_l1_():
	ITEMS(l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡹࡼࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ氯"))
	return
def PLAY(url,type):
	#url = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭氰")
	#items = re.findall(l11ll1_l1_ (u"ࠬࡼ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ氱"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ氲")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭氳"))
	#return
	l11ll1_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡨࡶࡷࡵࡲࡴ࠮ࡷ࡭ࡹࡲࡥࡴ࠮࡯࡭ࡳࡱࡳࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷࠭ࡻࡲ࡭ࠫࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ水")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1l11lllll_l1_(url):
	html,cc,data = l1ll1ll111lll_l1_(url)
	dd = cc[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ氵")][l11ll1_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭氶")][l11ll1_l1_ (u"ࠫࡹࡧࡢࡴࠩ氷")]
	for l11ll11111_l1_ in range(len(dd)):
		item = dd[l11ll11111_l1_]
		l1ll1ll1ll1ll_l1_(item,url,str(l11ll11111_l1_))
	ee = dd[0][l11ll1_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ永")][l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ氹")][l11ll1_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭氺")][l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ氻")]
	s = 0
	for l11ll11111_l1_ in range(len(ee)):
		item = ee[l11ll11111_l1_][l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ氼")][l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ氽")][0]
		if list(item[l11ll1_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫ氾")][l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭氿")].keys())[0]==l11ll1_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ汀"): continue
		succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_ = l1ll1lll11l11_l1_(item)
		if not title:
			s += 1
			title = l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢิหหาษࠡࠩ汁")+str(s)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ求"),l111l1_l1_+title,url,144,l11ll1_l1_ (u"ࠩࠪ汃"),str(l11ll11111_l1_))
	key = re.findall(l11ll1_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ汄"),html,re.DOTALL)
	l111lll_l1_ = l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ汅")+key[0]
	html,cc,l11ll11l1_l1_ = l1ll1ll111lll_l1_(l111lll_l1_)
	for l1ll1l111ll1_l1_ in range(3,4):
		dd = cc[l11ll1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ汆")][l1ll1l111ll1_l1_][l11ll1_l1_ (u"࠭ࡧࡶ࡫ࡧࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭汇")][l11ll1_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭汈")]
		for l11ll11111_l1_ in range(len(dd)):
			item = dd[l11ll11111_l1_]
			if l11ll1_l1_ (u"ࠨ࡛ࡲࡹ࡙ࡻࡢࡦࠢࡓࡶࡪࡳࡩࡶ࡯ࠪ汉") in str(item): continue
			l1ll1ll1ll1ll_l1_(item)
	return
def ITEMS(url,data=l11ll1_l1_ (u"ࠩࠪ汊"),index=0):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ汋"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11ll1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ汌"),l11ll1_l1_ (u"ࠬ࠭汍"))
	html,cc,l11ll11l1_l1_ = l1ll1ll111lll_l1_(url,data)
	l1l1111111_l1_,ff = l11ll1_l1_ (u"࠭ࠧ汎"),l11ll1_l1_ (u"ࠧࠨ汏")
	#if l11ll1_l1_ (u"ࠨࡱࡺࡲࡪࡸࠧ汐") in html.lower(): DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ汑"),l11ll1_l1_ (u"ࠪࠫ汒"),l11ll1_l1_ (u"ࠫࡴࡽ࡮ࡦࡴࠣࡩࡽ࡯ࡳࡵࠩ汓"),l11ll1_l1_ (u"ࠬ࡯࡮ࠡࡪࡷࡱࡱ࠭汔"))
	owner = re.findall(l11ll1_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࡔࡡ࡮ࡧࠥ࠲࠯ࡅࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ汕"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ汖"),html,re.DOTALL)
	if not owner: owner = re.findall(l11ll1_l1_ (u"ࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡐࡩࡹࡧࡤࡢࡶࡤࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࡯ࡸࡰࡨࡶ࡚ࡸ࡬ࡴࠤ࠽ࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭汗"),html,re.DOTALL)
	if owner:
		l1l1111111_l1_ = l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ汘")+owner[0][0]+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ汙")
		l1lllll_l1_ = owner[0][1]
		if l11ll1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ汚") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
		#if l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ汛") in url and l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ汜") not in url and l11ll1_l1_ (u"ࠧ࠰ࡥ࠲ࠫ汝") not in url and l11ll1_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࠨ汞") not in url:
		if l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ江") in url: addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ池"),l111l1_l1_+l1l1111111_l1_,l1lllll_l1_,144)
	#if cc==l11ll1_l1_ (u"ࠫࠬ污"): l1ll1l1l11l11_l1_(url,html) ; return
	l1ll1l1l111l1_l1_ = [l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭汢"),l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ汣"),l11ll1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ汤"),l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ汥"),l11ll1_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ汦"),l11ll1_l1_ (u"ࠪࡷࡸࡃࠧ汧"),l11ll1_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ汨"),l11ll1_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ汩"),l11ll1_l1_ (u"࠭ࡢࡱ࠿ࠪ汪"),l11ll1_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ汫")]
	l1ll1l11lll1l_l1_ = not any(value in url for value in l1ll1l1l111l1_l1_)
	if l1ll1l11lll1l_l1_ and l1l1111111_l1_:
		l11l1l1l1_l1_ = l11ll1_l1_ (u"ࠨษ็ฬาัࠧ汬")
		l1lll1l1l_l1_ = l11ll1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ汭")
		l11l1l11l_l1_ = l11ll1_l1_ (u"ࠪห้็๊ะ์๋๋ฬะࠧ汮")
		l1ll1l11llll1_l1_ = l11ll1_l1_ (u"ࠫฬ๊โ็๊สฮࠬ汯")
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ汰"),l111l1_l1_+l1l1111111_l1_,url,9999)
		if l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣสะฯࠧ࠭汱") in html: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ汲"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠨࠩ汳"),l11ll1_l1_ (u"ࠩࠪ汴"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ汵"))
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ汶") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ汷"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ汸"),144)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่ๆ๐ฯ๋๊๊หฯࠨࠧ汹") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ決"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ汻"),144)
		if l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ汼") in html: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ汽"),l111l1_l1_+l1ll1l11llll1_l1_,url+l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ汾"),144)
		if l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡕࡨࡥࡷࡩࡨࠣࠩ汿") in html: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沀"),l111l1_l1_+l11l1l1l1_l1_,url,145,l11ll1_l1_ (u"ࠨࠩ沁"),l11ll1_l1_ (u"ࠩࠪ沂"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ沃"))
		if l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠤࠪ沄") in html: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ沅"),l111l1_l1_+l1lll1l1l_l1_,url+l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ沆"),144)
		if l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ沇") in html: addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ沈"),l111l1_l1_+l11l1l11l_l1_,url+l11ll1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ沉"),144)
		if l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡉࡨࡢࡰࡱࡩࡱࡹࠢࠨ沊") in html: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ沋"),l111l1_l1_+l1ll1l11llll1_l1_,url+l11ll1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ沌"),144)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ沍"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ沎"),l11ll1_l1_ (u"ࠨࠩ沏"),9999)
	if l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ沐") in url:
		dd = cc[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ沑")][l11ll1_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ沒")][l11ll1_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ沓")][l11ll1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ沔")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ沕")]
		l1ll1l11lll11_l1_ = 0
		for i in range(len(dd)):
			if l11ll1_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ沖") in list(dd[i].keys()):
				l1ll1l11ll1ll_l1_ = dd[i][l11ll1_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ沗")]
				length = len(str(l1ll1l11ll1ll_l1_))
				if length>l1ll1l11lll11_l1_:
					l1ll1l11lll11_l1_ = length
					ff = l1ll1l11ll1ll_l1_
		if l1ll1l11lll11_l1_==0: return
	elif l11ll1_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ沘") in url or l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ沙") in url or l11ll1_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ沚") in url or l11ll1_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ沛") in url or l11ll1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ沜") in url or url==l11l1l_l1_:
		l1ll1l1ll11ll_l1_ = []
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡆࡳࡲࡳࡡ࡯ࡦࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ沝"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ沞"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ沟"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ沠"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ没"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠮࠳ࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ沢"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ沣"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡝ࡡࡵࡥ࡫ࡒࡪࡾࡴࡓࡧࡶࡹࡱࡺࡳࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠫࡢࠨ沤"))
		l1ll1l1l1111l_l1_,ff = l1ll1l1l1l111_l1_(cc,l11ll1_l1_ (u"ࠩࠪ沥"),l1ll1l1ll11ll_l1_)
	if not ff:
		try:
			dd = cc[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ沦")][l11ll1_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ沧")][l11ll1_l1_ (u"ࠬࡺࡡࡣࡵࠪ沨")]
			l1ll1ll1l1l1_l1_ = l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ沩") in url or l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ沪") in url or l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ沫") in url
			l1ll1l1l1ll11_l1_ = l11ll1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ沬") in html or l11ll1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭沭") in html or l11ll1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ沮") in html
			l1ll1l1l1l1ll_l1_ = l11ll1_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡗ࡫ࡧࡩࡴࡹࠢࠨ沯") in html or l11ll1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ沰") in html or l11ll1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ沱") in html
			if l1ll1ll1l1l1_l1_ and (l1ll1l1l1ll11_l1_ or l1ll1l1l1l1ll_l1_):
				for l11ll11111_l1_ in range(len(dd)):
					if l11ll1_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭沲") not in list(dd[l11ll11111_l1_].keys()): continue
					ee = dd[l11ll11111_l1_][l11ll1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ河")]
					try: gg = ee[l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ沴")][l11ll1_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ沵")][l11ll1_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭沶")][l11ll1_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ沷")][l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡕࡻࡳࡩࡘࡻࡢࡎࡧࡱࡹࡎࡺࡥ࡮ࡵࠪ沸")][l11ll11111_l1_]
					except: gg = ee
					try: l1lllll_l1_ = gg[l11ll1_l1_ (u"ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪ油")][l11ll1_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ沺")][l11ll1_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ治")][l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ沼")]
					except: continue
					if   l11ll1_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭沽")		in l1lllll_l1_	and l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ沾")		in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ沿")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ泀")	in url: ee = dd[l11ll11111_l1_] ; break
					elif l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ況")	in l1lllll_l1_	and l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭泂")		in url: ee = dd[l11ll11111_l1_] ; break
					else: ee = dd[0]
			elif l11ll1_l1_ (u"ࠫࡧࡶ࠽ࠨ泃") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11ll1_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ泄")][l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ泅")]
		except: pass
	if not ff: return
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ泆"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ泇"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ泈"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ泉"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ泊"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ泋"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ泌"))
	if l11ll1_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭泍") not in url: l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡷࡥࡑࡪࡴࡵࠨ࡟࡞ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬࡣࠢ泎"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ泏"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ泐"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ泑"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ泒"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ泓"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ泔"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ法"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡩࡪࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ泖"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࠨ泗"))
	l111l1l11ll_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡹ้ࠬไࠡไ๋หห๋ࠠศๆอุ฿๐ไࠨ泘"))
	l111l1l1l11_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡺ࠭ใๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭泙"))
	l1ll1l1l11111_l1_ = l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡻࠧไๆࠣห้่ๆ้ษอࠫ泚"))
	l11l1ll11lll_l1_ = [l111l1l11ll_l1_,l111l1l1l11_l1_,l1ll1l1l11111_l1_,l11ll1_l1_ (u"ࠧࡂ࡮࡯ࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ泛"),l11ll1_l1_ (u"ࠨࡃ࡯ࡰࠥࡼࡩࡥࡧࡲࡷࠬ泜"),l11ll1_l1_ (u"ࠩࡄࡰࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠨ泝")]
	l1ll1l1l111ll_l1_,gg = l1ll1l1l1l111_l1_(ff,index,l1ll1l1ll11ll_l1_)
	if l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ泞") in str(type(gg)) and any(value in str(gg[0]) for value in l11l1ll11lll_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll1l1ll11ll_l1_ = []
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ泟"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ泠"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ泡"))
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ波"))		#4
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ泣"))		#7
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ泤"))		#6
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡩࡤࡱࡪࡉࡡࡳࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡨࡣࡰࡩࠬࡣࠢ泥"))		#5
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝ࠣ泦"))
		l1ll1l1l1111l_l1_,item = l1ll1l1l1l111_l1_(gg,index2,l1ll1l1ll11ll_l1_)
		#if l1ll1l1l1111l_l1_ not in [l11ll1_l1_ (u"ࠬ࠸ࠧ泧"),l11ll1_l1_ (u"࠭࠴ࠨ注"),l11ll1_l1_ (u"ࠧ࠶ࠩ泩")]: l1ll1ll1ll1ll_l1_(item)		# 2,4,7
		#else: l1ll1ll1ll1ll_l1_(item,url,str(index2))
		l1ll1ll1ll1ll_l1_(item,url,str(index2))
		if l1ll1l1l1111l_l1_==l11ll1_l1_ (u"ࠨ࠶ࠪ泪"):
			try:
				hh = item[l11ll1_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩ泫")][l11ll1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ泬")][l11ll1_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ泭")][l11ll1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ泮")]
				for l1ll1ll11l1l1_l1_ in range(len(hh)):
					l1ll1l1l11ll1_l1_ = hh[l1ll1ll11l1l1_l1_]
					l1ll1ll1ll1ll_l1_(l1ll1l1l11ll1_l1_)
			except: pass
	l1ll1l1lll1ll_l1_ = False
	if l11ll1_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ泯") not in url and l1ll1l1l111ll_l1_==l11ll1_l1_ (u"ࠧ࠹ࠩ泰"): l1ll1l1lll1ll_l1_ = True
	if l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ泱") in l11ll11l1_l1_: l1ll1ll1l11ll_l1_,key,l1ll1lll111ll_l1_,l1ll1ll11ll1l_l1_,token,l1ll1l1llllll_l1_ = l11ll11l1_l1_.split(l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭泲"))
	else: l1ll1ll1l11ll_l1_,key,l1ll1lll111ll_l1_,l1ll1ll11ll1l_l1_,token,l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠪࠫ泳"),l11ll1_l1_ (u"ࠫࠬ泴"),l11ll1_l1_ (u"ࠬ࠭泵"),l11ll1_l1_ (u"࠭ࠧ泶"),l11ll1_l1_ (u"ࠧࠨ泷"),l11ll1_l1_ (u"ࠨࠩ泸")
	l111lll_l1_,l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠩࠪ泹"),l11ll1_l1_ (u"ࠪࠫ泺")
	if menuItemsLIST:
		l1ll1l1l1l1l1_l1_ = str(menuItemsLIST[-1][1])
		if   l111l1_l1_+l11ll1_l1_ (u"ࠫࡈࡎࡎࡍࠩ泻") in l1ll1l1l1l1l1_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ泼")
		elif l111l1_l1_+l11ll1_l1_ (u"࠭ࡕࡔࡇࡕࠫ泽") in l1ll1l1l1l1l1_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ泾")
		elif l111l1_l1_+l11ll1_l1_ (u"ࠨࡎࡌࡗ࡙࠭泿") in l1ll1l1l1l1l1_l1_: l1ll1l111l1_l1_ = l11ll1_l1_ (u"ࠩࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ洀")
	if l11ll1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡶࠦࠬ洁") in html and l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ洂") not in url and not l1ll1l1lll1ll_l1_ and l11ll1_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪࠧ洃") not in url:	# and (index!=l11ll1_l1_ (u"࠭ࠧ洄") or l11ll1_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ洅") in url or l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ洆") in url or l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ洇") in url or l11ll1_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ洈") in url):
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡤࡧࡪࡢࡺࡂࡧࡹࡵ࡫ࡦࡰࡀࠫ洉")+l1ll1lll111ll_l1_
	elif l11ll1_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭洊") in html and l11ll1_l1_ (u"࠭ࡢࡱ࠿ࠪ洋") not in url and l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭洌") in url or l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭洍") in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭洎")+key
	elif l11ll1_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥࠫ洏") in html and l11ll1_l1_ (u"ࠫࡧࡶ࠽ࠨ洐") not in url:
		l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ洑")+key
	if l111lll_l1_: addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洒"),l111l1_l1_+l11ll1_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ洓"),l111lll_l1_,144,l1ll1l111l1_l1_,l11ll1_l1_ (u"ࠨࠩ洔"),l11ll11l1_l1_)
	return
def l1ll1l1l1l111_l1_(l11ll111lll1_l1_,l11ll11ll1l1_l1_,l1ll1l1llll11_l1_):
	cc = l11ll111lll1_l1_
	ff,index = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	gg,index2 = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	item,render = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	count = len(l1ll1l1llll11_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1l1llll11_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"ࠩࠪ洕")
			return str(l11ll11111_l1_+1),out
		except: pass
	return l11ll1_l1_ (u"ࠪࠫ洖"),l11ll1_l1_ (u"ࠫࠬ洗")
def l1ll1lll11l11_l1_(item):
	try: l1ll1ll1l1lll_l1_ = list(item.keys())[0]
	except: return False,l11ll1_l1_ (u"ࠬ࠭洘"),l11ll1_l1_ (u"࠭ࠧ洙"),l11ll1_l1_ (u"ࠧࠨ洚"),l11ll1_l1_ (u"ࠨࠩ洛"),l11ll1_l1_ (u"ࠩࠪ洜"),l11ll1_l1_ (u"ࠪࠫ洝"),l11ll1_l1_ (u"ࠫࠬ洞")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_ = False,l11ll1_l1_ (u"ࠬ࠭洟"),l11ll1_l1_ (u"࠭ࠧ洠"),l11ll1_l1_ (u"ࠧࠨ洡"),l11ll1_l1_ (u"ࠨࠩ洢"),l11ll1_l1_ (u"ࠩࠪ洣"),l11ll1_l1_ (u"ࠪࠫ洤"),l11ll1_l1_ (u"ࠫࠬ津")
	#WRITE_THIS(l11ll1_l1_ (u"ࠬ࠭洦"),str(item))
	render = item[l1ll1ll1l1lll_l1_]
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ洧"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ洨"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ洩"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ洪"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ洫"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ洬"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ洭"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ洮"))
	l1ll1l1l1111l_l1_,title = l1ll1l1l1l111_l1_(item,render,l1ll1l1ll11ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ洯"),l11ll1_l1_ (u"ࠨࠩ洰"),l11ll1_l1_ (u"ࠩࠪ洱"),title)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ洲"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ洳"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ洴"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ洵")) # required for l11ll11111l1_l1_ l1ll1l1lll1ll_l1_
	l1ll1l1l1111l_l1_,l1lllll_l1_ = l1ll1l1l1l111_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ洶"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ洷"))
	l1ll1l1l1111l_l1_,l1lll1_l1_ = l1ll1l1l1l111_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ洸"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ洹"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ洺"))
	l1ll1l1l1111l_l1_,count = l1ll1l1l1l111_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ活"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ洼"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ洽"))
	l1ll1l1l1111l_l1_,l1l11lll1_l1_ = l1ll1l1l1l111_l1_(item,render,l1ll1l1ll11ll_l1_)
	if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭派") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11l1_l1_ = l11ll1_l1_ (u"ࠩࠪ洿"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ浀")
	if l11ll1_l1_ (u"๊ࠫฮวีำࠪ流") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11l1_l1_ = l11ll1_l1_ (u"ࠬ࠭浂"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ浃")
	if l11ll1_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ浄") in list(render.keys()):
		l1ll1ll1lll11_l1_ = str(render[l11ll1_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ浅")])
		if l11ll1_l1_ (u"ࠩࡉࡶࡪ࡫ࠠࡸ࡫ࡷ࡬ࠥࡇࡤࡴࠩ浆") in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠪࠨ࠿࠭浇")
		if l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠢࡑࡓ࡜࠭浈") in l1ll1ll1lll11_l1_: l111lll11l1_l1_ = l11ll1_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭浉")
		if l11ll1_l1_ (u"࠭ࡂࡶࡻࠪ浊") in l1ll1ll1lll11_l1_ or l11ll1_l1_ (u"ࠧࡓࡧࡱࡸࠬ测") in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠨࠦࠧ࠾ࠬ浌")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡷ้ࠪออิาࠩ浍")) in l1ll1ll1lll11_l1_: l111lll11l1_l1_ = l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ济")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡹฺࠬัศรࠪ浏")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠬࠪࠤ࠻ࠩ浐")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡻࠧศีอสัอัࠨ浑")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠧࠥࠦ࠽ࠫ浒")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶࠩศ฽้อๆศฬࠪ浓")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠩࠧ࠾ࠬ浔")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ浕") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠫࡄ࠭浖"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ浗") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭浘")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll11l111_l1_: title = l1ll1ll11l111_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠪ浙")+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠨ࠮ࠪ浚"),l11ll1_l1_ (u"ࠩࠪ浛"))
	count = count.replace(l11ll1_l1_ (u"ࠪ࠰ࠬ浜"),l11ll1_l1_ (u"ࠫࠬ浝"))
	count = re.findall(l11ll1_l1_ (u"ࠬࡢࡤࠬࠩ浞"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"࠭ࠧ浟")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_
def l1ll1ll1ll1ll_l1_(item,url=l11ll1_l1_ (u"ࠧࠨ浠"),index=l11ll1_l1_ (u"ࠨࠩ浡")):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_ = l1ll1lll11l11_l1_(item)
	#if l11ll1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ浢") in url and index==l11ll1_l1_ (u"ࠪ࠴ࠬ浣"):
	#	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ浤"),l111l1_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ浥") in str(item): return	# l1ll1lll111ll_l1_ not items
	elif l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡖࡹࡷࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ浦") in str(item): return			# l1ll1ll1ll11l_l1_ not items
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭浧") in url: return			# separator l1ll1l11ll1l1_l1_ list not items
	elif title and not l1lllll_l1_ and (l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ浨") in url or l11ll1_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ浩") in str(item) or url==l11l1l_l1_):
		title = l11ll1_l1_ (u"ࠪࡁࡂࡃࠠࠨ浪")+title+l11ll1_l1_ (u"ࠫࠥࡃ࠽࠾ࠩ浫")
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ浬"),l111l1_l1_+title,l11ll1_l1_ (u"࠭ࠧ浭"),9999)
	elif title and l11ll1_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ浮") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭浯"),l111l1_l1_+title,l11ll1_l1_ (u"ࠩࠪ浰"),9999)
	elif l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ浱") in l1lllll_l1_: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ浲"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif not title: return
	elif l111lll11l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ浳"),l111l1_l1_+l111lll11l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	#elif l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ浴") in l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ浵") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡶࡀ࠴ࠬ浶") not in l1lllll_l1_:
	#	l1ll1ll11l11l_l1_ = re.findall(l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ海"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ浸")+l1ll1ll11l11l_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ浹"),l111l1_l1_+l11ll1_l1_ (u"ࠬࡒࡉࡔࡖࠪ浺")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ浻")+title,l1lllll_l1_,144,l1lll1_l1_)
	elif l11ll1_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ浼") in l1lllll_l1_ or l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ浽") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ浾") in l1lllll_l1_ and l11ll1_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ浿") not in l1lllll_l1_:
			l1ll1ll11l11l_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ涀"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ涁")+l1ll1ll11l11l_l1_
			addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涂"),l111l1_l1_+l11ll1_l1_ (u"ࠧࡍࡋࡖࡘࠬ涃")+count+l11ll1_l1_ (u"ࠨ࠼ࠣࠤࠬ涄")+title,l1lllll_l1_,144,l1lll1_l1_)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ涅"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ涆"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	else:
		type = l11ll1_l1_ (u"ࠫࠬ涇")
		if not l1lllll_l1_: l1lllll_l1_ = url
		#if l11ll1_l1_ (u"ࠬࡹࡳ࠾ࠩ消") in l1lllll_l1_: l1lllll_l1_ = url
		#elif l11ll1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ涉") in l1lllll_l1_: l1lllll_l1_ = url		# not needed it will stop l1ll1l1l11lll_l1_ l11ll11111l1_l1_ l1ll1l1lll1ll_l1_
		elif not any(value in l1lllll_l1_ for value in [l11ll1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ涊"),l11ll1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ涋"),l11ll1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ涌"),l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭涍"),l11ll1_l1_ (u"ࠫࡸࡹ࠽ࠨ涎"),l11ll1_l1_ (u"ࠬࡨࡰ࠾ࠩ涏")]):
			if l11ll1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ涐")	in l1lllll_l1_ or l11ll1_l1_ (u"ࠧ࠰ࡥ࠲ࠫ涑") in l1lllll_l1_: type = l11ll1_l1_ (u"ࠨࡅࡋࡒࡑ࠭涒")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭涓")
			if l11ll1_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ涔") in l1lllll_l1_: type = l11ll1_l1_ (u"࡚࡙ࠫࡅࡓࠩ涕")+count+l11ll1_l1_ (u"ࠬࡀࠠࠡࠩ涖")
			index,l1ll1ll1l111l_l1_ = l11ll1_l1_ (u"࠭ࠧ涗"),l11ll1_l1_ (u"ࠧࠨ涘")
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ涙"),l111l1_l1_+type+title,l1lllll_l1_,144,l1lll1_l1_,index)
	return
def l1ll1ll111lll_l1_(url,data=l11ll1_l1_ (u"ࠩࠪ涚"),request=l11ll1_l1_ (u"ࠪࠫ涛")):
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭涜"))
	#if l11ll1_l1_ (u"ࠬࡥ࡟ࠨ涝") in l1ll1ll1l111l_l1_: l1ll1ll1l111l_l1_ = l11ll1_l1_ (u"࠭ࠧ涞")
	#if l11ll1_l1_ (u"ࠧࡴࡵࡀࠫ涟") in url: url = url.split(l11ll1_l1_ (u"ࠨࡵࡶࡁࠬ涠"))[0]
	if request==l11ll1_l1_ (u"ࠩࠪ涡"): request = l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ涢")
	l111lll1ll_l1_ = l11llllll_l1_()
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ涣"):l111lll1ll_l1_,l11ll1_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ涤"):l11ll1_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ涥")}
	#l1l1ll11l_l1_ = headers.copy()
	if l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ润") in data: l1ll1ll1l11ll_l1_,key,l1ll1lll111ll_l1_,l1ll1ll11ll1l_l1_,token,l1ll1l1llllll_l1_ = data.split(l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ涧"))
	else: l1ll1ll1l11ll_l1_,key,l1ll1lll111ll_l1_,l1ll1ll11ll1l_l1_,token,l1ll1l1llllll_l1_ = l11ll1_l1_ (u"ࠩࠪ涨"),l11ll1_l1_ (u"ࠪࠫ涩"),l11ll1_l1_ (u"ࠫࠬ涪"),l11ll1_l1_ (u"ࠬ࠭涫"),l11ll1_l1_ (u"࠭ࠧ涬"),l11ll1_l1_ (u"ࠧࠨ涭")
	if l11ll1_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ涮") in url:
		l11ll11l1_l1_ = {}
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ涯")] = {l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ涰"):{l11ll1_l1_ (u"ࠦ࡭ࡲࠢ涱"):l11ll1_l1_ (u"ࠧࡧࡲࠣ液"),l11ll1_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ涳"):l11ll1_l1_ (u"ࠢࡘࡇࡅࠦ涴"),l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ涵"):l1ll1ll11ll1l_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ涶"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ涷"))
	elif l11ll1_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ涸") in url and l1ll1ll1l11ll_l1_:
		l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ涹"):token}
		l11ll11l1_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ涺")] = {l11ll1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ涻"):{l11ll1_l1_ (u"ࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ涼"):l1ll1ll1l11ll_l1_,l11ll1_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ涽"):l11ll1_l1_ (u"࡛ࠥࡊࡈࠢ涾"),l11ll1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ涿"):l1ll1ll11ll1l_l1_}}
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡖࡏࡔࡖࠪ淀"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠳ࡰࡧࠫ淁"))
	elif l11ll1_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ淂") in url and l1ll1l1llllll_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ淃"):l11ll1_l1_ (u"ࠩ࠴ࠫ淄"),l11ll1_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ淅"):l1ll1ll11ll1l_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ淆"):l11ll1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ淇")+l1ll1l1llllll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"࠭ࡇࡆࡖࠪ淈"),url,l11ll1_l1_ (u"ࠧࠨ淉"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠨࠩ淊"),l11ll1_l1_ (u"ࠩࠪ淋"),l11ll1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠸ࡸࡤࠨ淌"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡌࡋࡔࠨ淍"),url,l11ll1_l1_ (u"ࠬ࠭淎"),l1l1ll11l_l1_,l11ll1_l1_ (u"࠭ࠧ淏"),l11ll1_l1_ (u"ࠧࠨ淐"),l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠷ࡸ࡭࠭淑"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ淒"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ淓"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll11ll1l_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ淔"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ淕"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll1l11ll_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ淖"),html,re.DOTALL|re.I)
	if tmp: l1ll1lll111ll_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ淗") in list(cookies.keys()): l1ll1l1llllll_l1_ = cookies[l11ll1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭淘")]
	data = l1ll1ll1l11ll_l1_+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭淙")+key+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ淚")+l1ll1lll111ll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ淛")+l1ll1ll11ll1l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ淜")+token+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ淝")+l1ll1l1llllll_l1_
	if request==l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ淞") and l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ淟") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ淠"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ淡"),html,re.DOTALL)
		l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠫࡸࡺࡲࠨ淢"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ淣") and l11ll1_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ淤") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭淥"),html,re.DOTALL)
		l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠨࡵࡷࡶࠬ淦"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ淧") not in html: l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ淨"),html)
	else: l1ll1l1ll1l11_l1_ = l11ll1_l1_ (u"ࠫࠬ淩")
	#open(l11ll1_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲࡯ࡹ࡯࡯ࠩ淪"),l11ll1_l1_ (u"࠭ࡷࠨ淫")).write(str(l1ll1l1ll1l11_l1_))
	#open(l11ll1_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ淬"),l11ll1_l1_ (u"ࠨࡹࠪ淭")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ淮"),data)
	return html,l1ll1l1ll1l11_l1_,data
def l1ll1lll11111_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠪࠤࠬ淯"),l11ll1_l1_ (u"ࠫ࠰࠭淰"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭深")+search
	ITEMS(l111lll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ淲"),l11ll1_l1_ (u"ࠧࠬࠩ淳"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࠪ淴")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ淵") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡗࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ淶")
		elif l11ll1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪ混") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ淸")
		elif l11ll1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ淹") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡪࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ淺")
		l11l111_l1_ = l111lll_l1_+l1ll1ll11111l_l1_
	else:
		l1ll1ll111111_l1_,l1ll1l1ll1111_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠨࠩ添")
		l1ll1l1ll11l1_l1_ = [l11ll1_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭淼"),l11ll1_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ淽"),l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ淾"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ淿"),l11ll1_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ渀")]
		l1ll1ll1ll111_l1_ = [l11ll1_l1_ (u"ࠧࠨ渁"),l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ渂"),l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ渃"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ渄"),l11ll1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ清")]
		l1ll1ll1lll1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ渆"),l1ll1l1ll11l1_l1_)
		if l1ll1ll1lll1l_l1_ == -1: return
		l1ll1l1lllll1_l1_ = l1ll1ll1ll111_l1_[l1ll1ll1lll1l_l1_]
		html,c,data = l1ll1ll111lll_l1_(l111lll_l1_+l1ll1l1lllll1_l1_)
		if c:
			d = c[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ渇")][l11ll1_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ済")][l11ll1_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ渉")][l11ll1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ渊")][l11ll1_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ渋")][l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ渌")][l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ渍")]
			for l1ll1l1l1llll_l1_ in range(len(d)):
				group = d[l1ll1l1l1llll_l1_][l11ll1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ渎")][l11ll1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ渏")]
				for l1ll1lll1111l_l1_ in range(len(group)):
					render = group[l1ll1lll1111l_l1_][l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ渐")]
					if l11ll1_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ渑") in list(render.keys()):
						l1lllll_l1_ = render[l11ll1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ渒")][l11ll1_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭渓")][l11ll1_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ渔")][l11ll1_l1_ (u"࠭ࡵࡳ࡮ࠪ渕")]
						l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ渖"),l11ll1_l1_ (u"ࠨࠨࠪ渗"))
						title = render[l11ll1_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ渘")]
						title = title.replace(l11ll1_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭渙"),l11ll1_l1_ (u"ࠫࠬ渚"))
						if l11ll1_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ減") in title: continue
						if l11ll1_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ渜") in title:
							title = l11ll1_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ渝")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ渞") in title: continue
						title = title.replace(l11ll1_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ渟"),l11ll1_l1_ (u"ࠪࠫ渠"))
						if l11ll1_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ渡") in title: continue
						if l11ll1_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ渢") in title:
							title = l11ll1_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ渣")+title
							l1lll1l1l_l1_ = title
							l1lllll11l_l1_ = l1lllll_l1_
						if l11ll1_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ渤") in title: continue
						l1ll1ll111111_l1_.append(escapeUNICODE(title))
						l1ll1l1ll1111_l1_.append(l1lllll_l1_)
		if not l1lll1l1l_l1_: l1ll1ll1l1l1l_l1_ = l11ll1_l1_ (u"ࠨࠩ渥")
		else:
			l1ll1ll111111_l1_ = [l11ll1_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ渦"),l1lll1l1l_l1_]+l1ll1ll111111_l1_
			l1ll1l1ll1111_l1_ = [l11ll1_l1_ (u"ࠪࠫ渧"),l1lllll11l_l1_]+l1ll1l1ll1111_l1_
			l1ll1ll1lllll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ渨"),l1ll1ll111111_l1_)
			if l1ll1ll1lllll_l1_ == -1: return
			l1ll1ll1l1l1l_l1_ = l1ll1l1ll1111_l1_[l1ll1ll1lllll_l1_]
		if l1ll1ll1l1l1l_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1ll1l1l1l_l1_
		elif l1ll1l1lllll1_l1_: l11l111_l1_ = l111lll_l1_+l1ll1l1lllll1_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪ࡮ࡲࡴࡦࡴ࠰ࡨࡷࡵࡰࡥࡱࡺࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡩࡧࠢࠪࡖࡪࡳ࡯ࡷࡧࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠬ࠲ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡲࡶࡹࠦࡢࡺࠩ࠯ࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭ࠫࡵ࡫ࡷࡰࡪࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠢࠣࠤ温")
	ITEMS(l11l111_l1_)
	return
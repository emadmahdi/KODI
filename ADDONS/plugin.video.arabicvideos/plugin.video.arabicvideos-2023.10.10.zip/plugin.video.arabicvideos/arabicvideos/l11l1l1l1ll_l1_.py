# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ棻")
l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ棼")
l11l1l_l1_ = l1l1lll_l1_[script_name][0]
#headers = l11ll1_l1_ (u"ࠫࠬ棽")
#headers = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ棾"):l11ll1_l1_ (u"࠭ࠧ棿")}
l1ll1l1lll111_l1_ = 0
def MAIN(mode,url,text,type,l1l1111_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1l1ll1ll1_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11111_l1_(url,l1l1111_l1_,text)
	elif mode==145: results = l1ll1lll11111_l1_(url,l1l1111_l1_)
	elif mode==147: results = l1ll1ll11ll11_l1_()
	elif mode==148: results = l1ll1ll11lll1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ椀"),l111l1_l1_+l11ll1_l1_ (u"ࠨไสส๊ฯࠧ椁"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡇࡪ࠶ࡉࡶ࠼ࡋࡎ࠸࡛ࡰࡘࡦࡋ࠶ࡒࡗ࠯࠺ࡋ࠸ࡈ࡯ࡲࡋࡼ࡞ࡆ࠺ࡵࡔࡃࠪ椂"),144)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ椃"),l111l1_l1_+l11ll1_l1_ (u"ูࠫิีࠨ椄"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳࡙ࡉࡎࡰࡨࡩ࡭ࡨ࡯ࡡ࡭ࠩ椅"),144)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭椆"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆ๊ๅ฽ࠬ椇"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡷ࠵࠺ࡣࡊࡒࡸࡷ࠹ࡣࡤ࡫ࡻ࡛࡚ࡱ࠲ࡗࡷࡺ࡬ࡽࠧ椈"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ椉"),l111l1_l1_+l11ll1_l1_ (u"ࠪัุอศࠨ椊"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡆࡔࡩࡧࡖࡳࡨ࡯ࡡ࡭ࡅࡗ࡚ࠬ椋"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椌"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅ฻สฬࠬ植"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡩࡤࡱ࡮ࡴࡧࠨ椎"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ椏"),l111l1_l1_+l11ll1_l1_ (u"ࠩสๅ้อๅࠨ椐"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭椑"),144)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ椒"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬฮหษิหฯ࠭椓"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ椔"),144)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ椕"),l111l1_l1_+l11ll1_l1_ (u"ࠨไุ๎ึฯࠧ椖"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ椗"),144,l11ll1_l1_ (u"ࠪࠫ椘"),l11ll1_l1_ (u"ࠫࠬ椙"),l11ll1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ椚"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭椛"),l111l1_l1_+l11ll1_l1_ (u"ࠧหืไัࠬ検"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ椝"),144)
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ椞"),l111l1_l1_+l11ll1_l1_ (u"ࠪีห๐ำ๋หࠪ椟"),l11l1l_l1_+l11ll1_l1_ (u"ࠫࠬ椠"),144)
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椡"),l111l1_l1_+l11ll1_l1_ (u"࠭ัศศฯࠫ椢"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࡀࡤࡳࡁࠬ椣"),144)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭椤"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ椥"),l11ll1_l1_ (u"ࠪࠫ椦"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ椧"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ椨"),l11ll1_l1_ (u"࠭ࠧ椩"),149,l11ll1_l1_ (u"ࠧࠨ椪"),l11ll1_l1_ (u"ࠨࠩ椫"),l11ll1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭椬"))
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ椭"),l111l1_l1_+l11ll1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭椮"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠭椯"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭椰"),l111l1_l1_+l11ll1_l1_ (u"ࠧศๆิหหาษࠨ椱"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ椲"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ椳"),l111l1_l1_+l11ll1_l1_ (u"ࠪห้ะีโฯࠪ椴"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ椵"),144)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ椶"),l111l1_l1_+l11ll1_l1_ (u"࠭วๅไุ๎ึฯࠧ椷"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ椸"),144,l11ll1_l1_ (u"ࠨࠩ椹"),l11ll1_l1_ (u"ࠩࠪ椺"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ椻"))
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ椼"),l111l1_l1_+l11ll1_l1_ (u"๋ࠬฮหษิหฯ๊้ࠦฬํ์อ࠭椽"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ椾"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ椿"),l111l1_l1_+l11ll1_l1_ (u"ࠨ็ัฮฬืวหࠢส่อืๆศ็ฯࠫ楀"),l11ll1_l1_ (u"ࠩࠪ楁"),290)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ楂"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ楃"),l11ll1_l1_ (u"ࠬ࠭楄"),9999)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭楅"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤ฾ืศ๋หࠪ楆"),l11ll1_l1_ (u"ࠨࠩ楇"),147)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ楈"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ楉"),l11ll1_l1_ (u"ࠫࠬ楊"),148)
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ楋"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣ฽ึฮ๊สࠩ楌"),l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ใํ่๊࠭楍"),144)
	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楎"),l111l1_l1_+l11ll1_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭楏"),l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ楐"),144)
	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ楑"),l111l1_l1_+l11ll1_l1_ (u"ࠬฮอฬ࠼ุ้ࠣือ๋ษอࠤ฾ืศ๋หࠪ楒"),l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆีิั๏ฯࠧ楓"),144)
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ楔"),l111l1_l1_+l11ll1_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะฺࠠำห๎ฮ࠭楕"),l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้๊ำๅࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ楖"),144)
	addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楗"),l111l1_l1_+l11ll1_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣหั์ศ๋หࠪ楘"),l11l1l_l1_+l11ll1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡳࡦࡴ࡬ࡩࡸࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ楙"),144)
	addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭楚"),l111l1_l1_+l11ll1_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦใศำอ์๋࠭楛"),l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๆหึะ่็ࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ楜"),144)
	addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ楝"),l111l1_l1_+l11ll1_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ楞"),l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ楟"),144)
	return
def l1ll1l1ll1ll1_l1_(url,name,l111_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ楠"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡃࡉࡐࡏ࠾ࠥࠦࠧ楡")+name,url,144,l111_l1_)
	return
def l1ll1ll11ll11_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ศฬࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ楢"))
	return
def l1ll1ll11lll1_l1_():
	l11111_l1_(l11l1l_l1_+l11ll1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡷࡺࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ楣"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ楤"),l11ll1_l1_ (u"ࠪࠫ楥"),l11ll1_l1_ (u"ࠫࠬ楦"),url)
	#url = l11ll1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ楧")
	#items = re.findall(l11ll1_l1_ (u"࠭ࡶ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ楨"),url,re.DOTALL)
	#id = items[0]
	#l1lllll_l1_ = l11ll1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ楩")+id
	#PLAY_VIDEO(l1lllll_l1_,script_name,l11ll1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ楪"))
	#return
	l11ll1_l1_ (u"ࠤࠥࠦࠏࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠫࡹࡷࡲࠩࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠭ࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱ࡺࡹࡱࡧࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤ楫")
	url = url.split(l11ll1_l1_ (u"ࠪࠪࠬ楬"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1ll111l11_l1_(cc,url,index):
	level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = index.split(l11ll1_l1_ (u"ࠫ࠿ࡀࠧ業"))
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭楮"),l11ll1_l1_ (u"࠭ࠧ楯"),index,l11ll1_l1_ (u"ࠧࡇࡋࡕࡗ࡙࠭楰")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ楱")+url)
	l1ll1l1ll11ll_l1_,l1ll1l1ll1l1l_l1_ = [],[]
	# l1l1111lll1_l1_ l11l111l111l_l1_    should be the first item in the l1ll1l1ll11ll_l1_ list
	if l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ楲") in url: l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣࠢ楳"))
	# l1l1111lll1_l1_ search l1ll1lll111ll_l1_      should be the first item in the l1ll1l1ll11ll_l1_ list
	if l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ楴") in url: l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟ࠥ極"))
	# main l1l1111_l1_
	if level==l11ll1_l1_ (u"࠭࠱ࠨ楶"): l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ楷"))
	# search results
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ楸"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟ࠥ楹"))
	# l1ll1ll1l1111_l1_ l1ll1ll11l1ll_l1_ & main l1l1111_l1_ l1ll1ll11l1ll_l1_ l1ll1lll111ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡧࡨࡡࠧࡦࡰࡷࡶ࡮࡫ࡳࠨ࡟ࠥ楺"))
	# l1ll1ll111l1l_l1_ menu
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡨࡩ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞࡝࠶ࡡࡠ࠭ࡧࡶ࡫ࡧࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ楻"))
	l1ll1ll1l11l1_l1_,dd,l1ll1l1l1ll1l_l1_ = l1ll1l1ll111l_l1_(cc,l11ll1_l1_ (u"ࠬ࠭楼"),l1ll1l1ll11ll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ楽"),str(dd))
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ楾"),l11ll1_l1_ (u"ࠨࠩ楿"),l11ll1_l1_ (u"ࠩࠪ榀"),str(len(dd)))
	if level==l11ll1_l1_ (u"ࠪ࠵ࠬ榁") and l1ll1ll1l11l1_l1_:
		if len(dd)>1 and l11ll1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ概") not in url:
			for zz in range(len(dd)):
				l1ll1l1llll1l_l1_ = str(zz)
				l1ll1l1ll11ll_l1_ = []
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜ࠤ榃")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ榄"))
				# l1ll1ll1l1111_l1_ l1ll1ll11l1ll_l1_
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡥࡦ࡞ࠦ榅")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠣ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࠬࡣࠢ榆"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠࠨ榇")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠥࡡࠧ榈"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1ll111l_l1_(dd,l11ll1_l1_ (u"ࠫࠬ榉"),l1ll1l1ll11ll_l1_)
				if succeeded: l1ll1l1ll1l1l_l1_.append([item,url,l11ll1_l1_ (u"ࠬ࠸࠺࠻ࠩ榊")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭榋")])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll1ll_l1_(item,url,l11ll1_l1_ (u"ࠧ࠳࠼࠽ࠫ榌")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ榍"))
				#if l1l1l1l1lll1_l1_: l1ll11l1l1_l1_ += 1
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token = l1ll1lll11l11_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ榎"),l111l1_l1_+title,l1lllll_l1_,144,l11ll1_l1_ (u"ࠪࠫ榏"),l11ll1_l1_ (u"ࠫ࠷ࡀ࠺ࠨ榐")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ榑"))
				#l1ll11l1l1_l1_ += 1
			# main l1l1111_l1_ l1ll1ll11l1ll_l1_ l1ll1lll111ll_l1_
			l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࠧ榒"))
			succeeded,item,l111l1ll_l1_ = l1ll1l1ll111l_l1_(cc,l11ll1_l1_ (u"ࠧࠨ榓"),l1ll1l1ll11ll_l1_)
			#LOG_THIS(l11ll1_l1_ (u"ࠨࠩ榔"),str(cc))
			if succeeded and l1ll1l1ll1l1l_l1_ and l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ榕") in list(item.keys()):
				l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ榖")
				l1ll1l1ll1l1l_l1_.append([item,l1lllll_l1_,l11ll1_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ榗")])
	return dd,l1ll1ll1l11l1_l1_,l1ll1l1ll1l1l_l1_,l1ll1l1l1ll1l_l1_
def l1ll1l1l1lll1_l1_(cc,dd,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭榘"),l11ll1_l1_ (u"࠭ࠧ榙"),index,l11ll1_l1_ (u"ࠧࡔࡇࡆࡓࡓࡊࠧ榚")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ榛")+url)
	level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = index.split(l11ll1_l1_ (u"ࠩ࠽࠾ࠬ榜"))
	l1ll1l1ll11ll_l1_,l1ll1ll111ll1_l1_ = [],[]
	# search results
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ榝"))
	# main l1l1111_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ榞")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ榟"))
	# l11ll11111l1_l1_ l1ll1ll11l1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝࠴ࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ榠"))
	# l1l1111lll1_l1_ search & l11l111l111l_l1_ & l1ll1lll111ll_l1_
	if l11ll1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪ࠭榡") in url: l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ榢"))
	elif l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ榣") in url: l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ榤"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ榥")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ榦"))
	# l11ll11111l1_l1_ l11ll11ll1_l1_ & l1ll1ll11l1ll_l1_ filters
	if l11ll1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ榧") in url or (l11ll1_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ榨") in url and l11ll1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ榩") not in url):
		l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡧࡨࡠࠨ榪")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ榫"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡩࡪ࡛ࠣ榬")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ榭"))
	# l1ll1ll1l1111_l1_ search
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝ࠥ榮")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡤࡦࡱ࡫ࡔࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ榯"))
	# main l1l1111_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡦࡧ࡟ࠧ榰")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ榱"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡨࡩࡡࠢ榲")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠦࡢࠨ榳"))
	l1ll1ll11llll_l1_,ee,l1ll1ll1111l1_l1_ = l1ll1l1ll111l_l1_(dd,l11ll1_l1_ (u"ࠬ࠭榴"),l1ll1l1ll11ll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ榵"),str(ee))
	#DIALOG_OK()
	if level==l11ll1_l1_ (u"ࠧ࠳ࠩ榶") and l1ll1ll11llll_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll1l1ll11ll_l1_ = []
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ榷")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ榸"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ榹")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ榺"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ榻")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ榼"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ榽")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ榾"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ榿")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ槀"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ槁")+index2+l11ll1_l1_ (u"ࠧࡣࠢ槂"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1ll111l_l1_(ee,l11ll1_l1_ (u"࠭ࠧ槃"),l1ll1l1ll11ll_l1_)
				if succeeded: l1ll1ll111ll1_l1_.append([item,url,l11ll1_l1_ (u"ࠧ࠴࠼࠽ࠫ槄")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ槅")+index2+l11ll1_l1_ (u"ࠩ࠽࠾࠵࠭槆")])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll1ll_l1_(item,url,l11ll1_l1_ (u"ࠪ࠷࠿ࡀࠧ槇")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ槈")+index2+l11ll1_l1_ (u"ࠬࡀ࠺࠱ࠩ槉"))
				#if l1l1l1l1lll1_l1_: l1l1l11l11_l1_ += 1
				#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ槊"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ構")+str(item))
				#l1l1l11l11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token = l1ll1lll11l11_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ槌"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,l11ll1_l1_ (u"ࠩ࠶࠾࠿࠭槍")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭槎")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀ࠰ࠨ槏"))
			# search l1ll1lll111ll_l1_
			l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠴ࡡࠧ槐"))
			# search l1ll1lll111ll_l1_
			l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡤࡥ࡝࠴ࡡࠧ槑"))
			succeeded,item,l111l1ll_l1_ = l1ll1l1ll111l_l1_(dd,l11ll1_l1_ (u"ࠧࠨ槒"),l1ll1l1ll11ll_l1_)
			if succeeded and l1ll1ll111ll1_l1_ and l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ槓") in list(item.keys()):
				l1ll1ll111ll1_l1_.append([item,url,l11ll1_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭槔")])
			#l1l1l1l1lll1_l1_ = l1ll1ll1ll1ll_l1_(item,url,l11ll1_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ槕"))
			#if l1l1l1l1lll1_l1_: l1l1l11l11_l1_ += 1
			#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ槖"),str(item))
			#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭槗"),l1lllll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ様")+token)
	return ee,l1ll1ll11llll_l1_,l1ll1ll111ll1_l1_,l1ll1ll1111l1_l1_
def l1ll1l1ll1lll_l1_(cc,ee,url,index):
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ槙"),l11ll1_l1_ (u"ࠨࠩ槚"),index,l11ll1_l1_ (u"ࠩࡗࡌࡎࡘࡄࠨ槛")+l11ll1_l1_ (u"ࠪࡠࡳ࠭槜")+url)
	level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = index.split(l11ll1_l1_ (u"ࠫ࠿ࡀࠧ槝"))
	l1ll1l1ll11ll_l1_,l1ll1l1lll1l1_l1_ = [],[]
	# search results
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ槞")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡹࡩࡷࡺࡩࡤࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ槟"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞ࠦ槠")+index2+l11ll1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ槡"))
	# l1ll1ll1ll1l1_l1_ menu l1ll1ll11l1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠࠨ槢")+index2+l11ll1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ槣"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡪ࡫࡛ࠣ槤")+index2+l11ll1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ槥"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡥࡦ࡝ࠥ槦")+index2+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ槧"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟ࠧ槨")+index2+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ槩"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ槪")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ槫"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ槬")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ槭"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ槮"))
	# l1ll1ll1l1111_l1_ l1ll1lll11l1l_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ槯"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ槰"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡩࡪࡡࠢ槱")+index2+l11ll1_l1_ (u"ࠦࡢࡡࠧࡳࡧࡨࡰࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ槲"))
	# main l1l1111_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ槳")+index2+l11ll1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ槴"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡦࡧࠥ槵"))
	l1ll1ll1l1l11_l1_,ff,l1ll1lll111l1_l1_ = l1ll1l1ll111l_l1_(ee,l11ll1_l1_ (u"ࠨࠩ槶"),l1ll1l1ll11ll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠩࠪ槷"),str(ff))
	if level==l11ll1_l1_ (u"ࠪ࠷ࠬ槸") and l1ll1ll1l1l11_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1ll1ll11l1l1_l1_ = str(zz)
				#DIALOG_OK()
				l1ll1l1ll11ll_l1_ = []
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡫࡬࡛ࠣ槹")+l1ll1ll11l1l1_l1_+l11ll1_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ槺"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡦࡧ࡝ࠥ槻")+l1ll1ll11l1l1_l1_+l11ll1_l1_ (u"ࠢ࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ槼"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡨࡩ࡟ࠧ槽")+l1ll1ll11l1l1_l1_+l11ll1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ槾"))
				l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡪ࡫ࡡࠢ槿")+l1ll1ll11l1l1_l1_+l11ll1_l1_ (u"ࠦࡢࠨ樀"))
				succeeded,item,l111l1ll_l1_ = l1ll1l1ll111l_l1_(ff,l11ll1_l1_ (u"ࠬ࠭樁"),l1ll1l1ll11ll_l1_)
				#succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token = l1ll1lll11l11_l1_(item)
				#addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ樂"),l111l1_l1_+l1lllll_l1_,l1lllll_l1_,143,l1lll1_l1_)
				if succeeded: l1ll1l1lll1l1_l1_.append([item,url,l11ll1_l1_ (u"ࠧ࠵࠼࠽ࠫ樃")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ樄")+index2+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ樅")+l1ll1ll11l1l1_l1_])
				#l1l1l1l1lll1_l1_ = l1ll1ll1ll1ll_l1_(item,url,l11ll1_l1_ (u"ࠪ࠸࠿ࡀࠧ樆")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ樇")+index2+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ樈")+l1ll1ll11l1l1_l1_)
				#if l1l1l1l1lll1_l1_: l1l1l11l1l_l1_ += 1
	return ff,l1ll1ll1l1l11_l1_,l1ll1l1lll1l1_l1_,l1ll1lll111l1_l1_
def l1ll1l1ll111l_l1_(l11ll111lll1_l1_,l11ll11ll1l1_l1_,l1ll1l1llll11_l1_):
	cc,l11ll11ll1l1_l1_ = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	dd,l11ll11ll1l1_l1_ = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	ee,l11ll11ll1l1_l1_ = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	ff,l11ll11ll1l1_l1_ = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	item,render = l11ll111lll1_l1_,l11ll11ll1l1_l1_
	count = len(l1ll1l1llll11_l1_)
	for l11ll11111_l1_ in range(count):
		try:
			out = eval(l1ll1l1llll11_l1_[l11ll11111_l1_])
			#if isinstance(out,dict): out = l11ll1_l1_ (u"࠭ࠧ樉")
			return True,out,l11ll11111_l1_+1
		except: pass
	return False,l11ll1_l1_ (u"ࠧࠨ樊"),0
def l11111_l1_(url,index=l11ll1_l1_ (u"ࠨࠩ樋"),data=l11ll1_l1_ (u"ࠩࠪ樌")):
	l1ll1l1ll1l1l_l1_,l1ll1ll111ll1_l1_,l1ll1l1lll1l1_l1_ = [],[],[]
	if l11ll1_l1_ (u"ࠪ࠾࠿࠭樍") not in index: index = l11ll1_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ樎")
	level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = index.split(l11ll1_l1_ (u"ࠬࡀ࠺ࠨ樏"))
	if level==l11ll1_l1_ (u"࠭࠴ࠨ樐"): level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ樑"),l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_
	#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ樒"),l11ll1_l1_ (u"ࠩࠪ樓"),index,url)
	data = data.replace(l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ樔"),l11ll1_l1_ (u"ࠫࠬ樕"))
	html,cc,l11ll11l1_l1_ = l1ll1ll111lll_l1_(url,data)
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡪࠥ࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡳࡷࠦࠧ࠰ࡷࡶࡩࡷ࠵ࠧࠡ࡫ࡱࠤࡺࡸ࡬࠻ࠌࠌࠍࠨࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࡒࡦࡳࡥࠣ࠰࠭ࡃࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠤ࡫ࡩࠤࡳࡵࡴࠡࡱࡺࡲࡪࡸ࠺ࠡࠌࠌࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡒ࡫ࡴࡢࡦࡤࡸࡦࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡱࡺࡲࡪࡸࡕࡳ࡮ࡶࠦ࠿ࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣࡲࡴࡺࠠࡰࡹࡱࡩࡷࡀࠠࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࠉࡰࡹࡱࡩࡷࡔࡁࡎࡇࠣࡁࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟ࠬࠎࠎࠏࠉࡰࡹࡱࡩࡷࡔࡁࡎࡇࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ࠮ࡳࡼࡴࡥࡳࡐࡄࡑࡊ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠳ࡠࠎࠎࠏࠉࡪࡨࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰ࡲࡩ࡯࡭ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡲࡻࡳ࡫ࡲࡏࡃࡐࡉ࠱ࡲࡩ࡯࡭࠯࠵࠹࠺ࠩࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡰ࡮ࡴ࡫ࠨ࠮ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠰ࠬ࠭ࠬ࠺࠻࠼࠽࠮ࠐࠉࠣࠤࠥ樖")
	index = level+l11ll1_l1_ (u"࠭࠺࠻ࠩ樗")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ樘")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ標")+l1ll1ll11l1l1_l1_
	if level in [l11ll1_l1_ (u"ࠩ࠴ࠫ樚"),l11ll1_l1_ (u"ࠪ࠶ࠬ樛"),l11ll1_l1_ (u"ࠫ࠸࠭樜")]:
		dd,l1ll1ll1l11l1_l1_,l1ll1l1ll1l1l_l1_,l1ll1l1l1ll1l_l1_ = l1ll1ll111l11_l1_(cc,url,index)
		if not l1ll1ll1l11l1_l1_: return
		l1ll11l1l1_l1_ = len(l1ll1l1ll1l1l_l1_)
		if l1ll11l1l1_l1_<2:
			if level==l11ll1_l1_ (u"ࠬ࠷ࠧ樝"): level = l11ll1_l1_ (u"࠭࠲ࠨ樞")
			l1ll1l1ll1l1l_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ樟"),l11ll1_l1_ (u"ࠨࠩ樠"),index,l11ll1_l1_ (u"ࠩ࡯ࡩࡻ࡫࡬࠻ࠢ࠴ࡠࡳ࠭模")+l11ll1_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩ࠿ࠦࠧ樢")+str(l1ll1l1l1ll1l_l1_)+l11ll1_l1_ (u"ࠫࡡࡴࠧ樣")+l11ll1_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬࠿ࠦࠧ樤")+str(len(dd))+l11ll1_l1_ (u"࠭࡜࡯ࠩ樥")+l11ll1_l1_ (u"ࠧࡤࡱࡸࡲࡹࡀࠠࠨ樦")+str(l1ll11l1l1_l1_)+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ樧")+url)
	index = level+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ樨")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭権")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ横")+l1ll1ll11l1l1_l1_
	if level in [l11ll1_l1_ (u"ࠬ࠸ࠧ樫"),l11ll1_l1_ (u"࠭࠳ࠨ樬")]:
		ee,l1ll1ll11llll_l1_,l1ll1ll111ll1_l1_,l1ll1ll1111l1_l1_ = l1ll1l1l1lll1_l1_(cc,dd,url,index)
		if not l1ll1ll11llll_l1_: return
		l1l1l11l11_l1_ = len(l1ll1ll111ll1_l1_)
		if l1l1l11l11_l1_<2:
			if level==l11ll1_l1_ (u"ࠧ࠳ࠩ樭"): level = l11ll1_l1_ (u"ࠨ࠵ࠪ樮")
			l1ll1ll111ll1_l1_ = []
		#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ樯"),l11ll1_l1_ (u"ࠪࠫ樰"),index,l11ll1_l1_ (u"ࠫࡱ࡫ࡶࡦ࡮࠽ࠤ࠷ࡢ࡮ࠨ樱")+l11ll1_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ樲")+str(l1ll1ll1111l1_l1_)+l11ll1_l1_ (u"࠭࡜࡯ࠩ樳")+l11ll1_l1_ (u"ࠧ࡭ࡧࡱ࡫ࡹ࡮࠺ࠡࠩ樴")+str(len(ee))+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ樵")+l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴ࠻ࠢࠪ樶")+str(l1l1l11l11_l1_)+l11ll1_l1_ (u"ࠪࡠࡳ࠭樷")+url)
	index = level+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ樸")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ樹")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ樺")+l1ll1ll11l1l1_l1_
	if level in [l11ll1_l1_ (u"ࠧ࠴ࠩ樻")]:
		ff,l1ll1ll1l1l11_l1_,l1ll1l1lll1l1_l1_,l1ll1lll111l1_l1_ = l1ll1l1ll1lll_l1_(cc,ee,url,index)
		if not l1ll1ll1l1l11_l1_: return
		l1l1l11l1l_l1_ = len(l1ll1l1lll1l1_l1_)
		#DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ樼"),l11ll1_l1_ (u"ࠩࠪ樽"),index,l11ll1_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠷ࡡࡴࠧ樾")+l11ll1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ樿")+str(l1ll1lll111l1_l1_)+l11ll1_l1_ (u"ࠬࡢ࡮ࠨ橀")+l11ll1_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ橁")+str(len(ff))+l11ll1_l1_ (u"ࠧ࡝ࡰࠪ橂")+l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ橃")+str(l1l1l11l1l_l1_)+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ橄")+url)
	for item,url,index in l1ll1l1ll1l1l_l1_+l1ll1ll111ll1_l1_+l1ll1l1lll1l1_l1_:
		l1l1l1l1lll1_l1_ = l1ll1ll1ll1ll_l1_(item,url,index)
	return
def l1ll1ll1ll1ll_l1_(item,url=l11ll1_l1_ (u"ࠪࠫ橅"),index=l11ll1_l1_ (u"ࠫࠬ橆")):
	if l11ll1_l1_ (u"ࠬࡀ࠺ࠨ橇") in index: level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = index.split(l11ll1_l1_ (u"࠭࠺࠻ࠩ橈"))
	else: level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ橉"),l11ll1_l1_ (u"ࠨ࠲ࠪ橊"),l11ll1_l1_ (u"ࠩ࠳ࠫ橋"),l11ll1_l1_ (u"ࠪ࠴ࠬ橌")
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,l1ll1ll1llll1_l1_ = l1ll1lll11l11_l1_(item)
	#LOG_THIS(l11ll1_l1_ (u"ࠫࠬ橍"),url)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭橎"),l1lllll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"࠭ࠧ橏"),l1lllll_l1_+l11ll1_l1_ (u"ࠧࠡࠢࠣࠫ橐")+title)
	# needed for l1ll1ll1l1111_l1_ l1ll1lll11l1l_l1_ next l1l1111_l1_
	# and needed for l1ll1ll1l1111_l1_ l1ll1lll11l1l_l1_ sub-menu
	#if (l11ll1_l1_ (u"ࠨࡸ࡬ࡩࡼࡃ࠵࠱ࠩ橑") in l1lllll_l1_ or l11ll1_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽࠵࠻ࠪ橒") in l1lllll_l1_) and (l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠿ࠨ橓") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠿ࠨ橔") in l1lllll_l1_): l1lllll_l1_ = url
	l1ll1ll1l1l1_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸࡅࠧ橕") in l1lllll_l1_ or l11ll1_l1_ (u"࠭࠯ࡴࡶࡵࡩࡦࡳࡳࡀࠩ橖") in l1lllll_l1_ or l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ橗") in l1lllll_l1_
	l1ll1ll1l111_l1_ = l11ll1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ橘") in l1lllll_l1_ or l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࡂࠫ橙") in l1lllll_l1_
	if l1ll1ll1l1l1_l1_ or l1ll1ll1l111_l1_: l1lllll_l1_ = url
	l1ll1ll1l1l1_l1_ = l11ll1_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ橚") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭橛") not in l1lllll_l1_
	l1ll1ll1l111_l1_ = l11ll1_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭橜") not in l1lllll_l1_  and l11ll1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ橝") not in l1lllll_l1_
	if index[0:5]==l11ll1_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀࠧ橞") and l1ll1ll1l1l1_l1_ and l1ll1ll1l111_l1_: l1lllll_l1_ = url
	if l11ll1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ機") in url or l11ll1_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ橠") in l1lllll_l1_:
		level,l1ll1l1llll1l_l1_,index2,l1ll1ll11l1l1_l1_ = l11ll1_l1_ (u"ࠪ࠵ࠬ橡"),l11ll1_l1_ (u"ࠫ࠵࠭橢"),l11ll1_l1_ (u"ࠬ࠶ࠧ橣"),l11ll1_l1_ (u"࠭࠰ࠨ橤")
		index = l11ll1_l1_ (u"ࠧࠨ橥")
	l11ll11l1_l1_ = l11ll1_l1_ (u"ࠨࠩ橦")
	if l11ll1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ橧") in l1lllll_l1_ or l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ橨") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ橩") in url:
		data = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ橪"))
		if data.count(l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ橫"))==4:
			l1ll1ll1l11ll_l1_,key,l1ll1ll11ll1l_l1_,l1ll1l1llllll_l1_,token = data.split(l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ橬"))
			l11ll11l1_l1_ = l1ll1ll1l11ll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ橭")+key+l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭橮")+l1ll1ll11ll1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ橯")+l1ll1l1llllll_l1_+l11ll1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ橰")+l1ll1ll1llll1_l1_
			if l11ll1_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ橱") in url and not l1lllll_l1_: l1lllll_l1_ = url
			else: l1lllll_l1_ = l1lllll_l1_+l11ll1_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ橲")+key
	if not title:
		global l1ll1l1lll111_l1_
		l1ll1l1lll111_l1_ += 1
		title = l11ll1_l1_ (u"ࠧโ์า๎ํํวหࠢࠪ橳")+str(l1ll1l1lll111_l1_)
		index = l11ll1_l1_ (u"ࠨ࠵ࠪ橴")+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ橵")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠪ࠾࠿࠭橶")+index2+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ橷")+l1ll1ll11l1l1_l1_
	#if l11ll1_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫ橸") in url: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ橹"),l11ll1_l1_ (u"ࠧࠨ橺"),title,index+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ橻")+l1lllll_l1_)
	#if not l1lllll_l1_: l1lllll_l1_ = url
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ橼"),l11ll1_l1_ (u"ࠪࠫ橽"),str(succeeded),title+l11ll1_l1_ (u"ࠫࠥࡀ࠺࠻ࠢࠪ橾")+l1lllll_l1_)
	#if l11ll1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ橿") in url and index==l11ll1_l1_ (u"࠭࠰ࠨ檀"):
	#	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ檁"),l111l1_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11ll1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡑࡻࡹࡖࡪࡴࡤࡦࡴࡨࡶࠬ檂") in str(item): return False			# l1ll1ll1ll11l_l1_ not items
	elif l11ll1_l1_ (u"ࠩ࠲ࡥࡧࡵࡵࡵࠩ檃") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠪ࠳ࡨࡵ࡭࡮ࡷࡱ࡭ࡹࡿࠧ檄") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ檅") in list(item.keys()) or l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ檆") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11ll1_l1_ (u"࠭࠺࠻ࠩ檇")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠧ࠻࠼ࠪ檈")+index2+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ檉")+l1ll1ll11l1l1_l1_
		addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ檊"),l111l1_l1_+l11ll1_l1_ (u"ࠪ࠾࠿ࠦࠧ檋")+l11ll1_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ檌"),l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif l11ll1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭檍") in l1lllll_l1_:
		title = l11ll1_l1_ (u"࠭࠺࠻ࠢࠪ檎")+title
		index = l11ll1_l1_ (u"ࠧ࠴ࠩ檏")+l11ll1_l1_ (u"ࠨ࠼࠽ࠫ檐")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠩ࠽࠾ࠬ檑")+index2+l11ll1_l1_ (u"ࠪ࠾࠿࠭檒")+l1ll1ll11l1l1_l1_
		url = url.replace(l11ll1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ檓"),l11ll1_l1_ (u"ࠬ࠭檔"))
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檕"),l111l1_l1_+title,url,145,l11ll1_l1_ (u"ࠧࠨ檖"),index,l11ll1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ檗"))
	elif l11ll1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ檘") in url and not l1lllll_l1_:
		index = l11ll1_l1_ (u"ࠪ࠷ࠬ檙")+l11ll1_l1_ (u"ࠫ࠿ࡀࠧ檚")+l1ll1l1llll1l_l1_+l11ll1_l1_ (u"ࠬࡀ࠺ࠨ檛")+index2+l11ll1_l1_ (u"࠭࠺࠻ࠩ檜")+l1ll1ll11l1l1_l1_
		title = l11ll1_l1_ (u"ࠧ࠻࠼ࠣࠫ檝")+title
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檞"),l111l1_l1_+title,url,144,l1lll1_l1_,index,l11ll11l1_l1_)
	#elif l11ll1_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ檟") in l1lllll_l1_: return False
	elif l11ll1_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࠫ檠") in l1lllll_l1_ and url==l11l1l_l1_:
		title = l11ll1_l1_ (u"ࠫ࠿ࡀࠠࠨ檡")+title
		index = l11ll1_l1_ (u"ࠬ࠸࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ檢")
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檣"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	elif not l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ檤") in str(item):
		title = l11ll1_l1_ (u"ࠨ࠼࠽ࠤࠬ檥")+title
		index = l11ll1_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭檦")
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ檧"),l111l1_l1_+title,url,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭檨") in str(item):
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ檩"),l111l1_l1_+title,l11ll1_l1_ (u"࠭ࠧ檪"),9999)
	#elif l11ll1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ檫") in l1lllll_l1_ and l11ll1_l1_ (u"ࠨࡤࡳࡁࠬ檬") not in l1lllll_l1_:
	#	title = l11ll1_l1_ (u"ࠩ࠽࠾ࠥ࠭檭")+title
	#	index = l11ll1_l1_ (u"ࠪ࠶࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ檮")
	#	addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ檯"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l111lll11l1_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩࡷࡧࠪ檰"),l111l1_l1_+l111lll11l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_)
	elif l11ll1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ檱") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ檲"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡎࡌࡗ࡙࠭檳")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭檴")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	#elif l11ll1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ檵") in l1lllll_l1_ and l11ll1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ檶") not in l1lllll_l1_ and l11ll1_l1_ (u"ࠬࡺ࠽࠱ࠩ檷") not in l1lllll_l1_:
	#	l1ll1ll11l11l_l1_ = re.findall(l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ檸"),l1lllll_l1_,re.DOTALL)
	#	l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ檹")+l1ll1ll11l11l_l1_[0]
	#	addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檺"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ檻")+count+l11ll1_l1_ (u"ࠪ࠾ࠥࠦࠧ檼")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭檽") in l1lllll_l1_:
		l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ檾"),1)[0]
		addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ檿"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ櫀") in l1lllll_l1_:
		if l11ll1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ櫁") in l1lllll_l1_ and count:
			l1ll1ll11l11l_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ櫂"),1)[1]
			l1lllll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ櫃")+l1ll1ll11l11l_l1_
			index = l11ll1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ櫄")
			addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ櫅"),l111l1_l1_+l11ll1_l1_ (u"࠭ࡌࡊࡕࡗࠫ櫆")+count+l11ll1_l1_ (u"ࠧ࠻ࠢࠣࠫ櫇")+title,l1lllll_l1_,144,l1lll1_l1_,index)
		else:
			l1lllll_l1_ = l1lllll_l1_.split(l11ll1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ櫈"),1)[0]
			addMenuItem(l11ll1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ櫉"),l111l1_l1_+title,l1lllll_l1_,143,l1lll1_l1_,l1l11lll1_l1_)
	elif l11ll1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭櫊") in l1lllll_l1_ or l11ll1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ櫋") in l1lllll_l1_ or (l11ll1_l1_ (u"ࠬ࠵ࡀࠨ櫌") in l1lllll_l1_ and l1lllll_l1_.count(l11ll1_l1_ (u"࠭࠯ࠨ櫍"))==3):
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ櫎"),l111l1_l1_+l11ll1_l1_ (u"ࠨࡅࡋࡒࡑ࠭櫏")+count+l11ll1_l1_ (u"ࠩ࠽ࠤࠥ࠭櫐")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	elif l11ll1_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ櫑") in l1lllll_l1_:
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ櫒"),l111l1_l1_+l11ll1_l1_ (u"࡛ࠬࡓࡆࡔࠪ櫓")+count+l11ll1_l1_ (u"࠭࠺ࠡࠢࠪ櫔")+title,l1lllll_l1_,144,l1lll1_l1_,index)
	else:
		if not l1lllll_l1_: l1lllll_l1_ = url
		title = l11ll1_l1_ (u"ࠧ࠻࠼ࠣࠫ櫕")+title
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ櫖"),l111l1_l1_+title,l1lllll_l1_,144,l1lll1_l1_,index,l11ll11l1_l1_)
	return True
def l1ll1lll11l11_l1_(item):
	succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token = False,l11ll1_l1_ (u"ࠩࠪ櫗"),l11ll1_l1_ (u"ࠪࠫ櫘"),l11ll1_l1_ (u"ࠫࠬ櫙"),l11ll1_l1_ (u"ࠬ࠭櫚"),l11ll1_l1_ (u"࠭ࠧ櫛"),l11ll1_l1_ (u"ࠧࠨ櫜"),l11ll1_l1_ (u"ࠨࠩ櫝"),l11ll1_l1_ (u"ࠩࠪ櫞")
	#LOG_THIS(l11ll1_l1_ (u"ࠪࠫ櫟"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token
	for l1ll1ll1l1lll_l1_ in list(item.keys()):
		render = item[l1ll1ll1l1lll_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11ll1_l1_ (u"ࠫࠬ櫠"),str(render))
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭櫡"),str(render))
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ櫢"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ櫣"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪ࡬ࡪࡰࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ櫤"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ櫥"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ櫦"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ櫧"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ櫨"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ櫩"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ櫪"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ櫫"))
	# required for l11ll11111l1_l1_ l1ll1ll1111ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ櫬"))
	# l1ll1ll1l1111_l1_ l1ll1ll11l1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪࡡࠧ櫭"))
	succeeded,title,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ櫮"),l11ll1_l1_ (u"ࠬ࠭櫯"),l11ll1_l1_ (u"࠭ࠧ櫰"),str(l111l1ll_l1_))
	#LOG_THIS(l11ll1_l1_ (u"ࠧࠨ櫱"),str(l111l1ll_l1_)+l11ll1_l1_ (u"ࠨࠢࠣࠤࠬ櫲")+str(title))
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ櫳"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ櫴"))
	# l1ll1lll111ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ櫵"))
	# header feed
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ櫶"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ櫷"))
	# required for l11ll11111l1_l1_ l1ll1l1lll1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ櫸"))
	# l1ll1ll1l1111_l1_ l1ll1ll11l1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ櫹"))
	succeeded,l1lllll_l1_,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ櫺"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ櫻"))
	# l1ll1ll1l1111_l1_ l1ll1ll11l1ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ櫼"))
	succeeded,l1lll1_l1_,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	#LOG_THIS(l11ll1_l1_ (u"ࠬ࠭櫽"),str(l111l1ll_l1_)+l11ll1_l1_ (u"࠭ࠠࠡࠢࠪ櫾")+l1lll1_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸࠬࡣࠢ櫿"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ欀"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡄࡲࡸࡹࡵ࡭ࡑࡣࡱࡩࡱࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ欁"))
	succeeded,count,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ欂"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ欃"))
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ欄"))
	# l1ll1ll1l1ll1_l1_ l1ll1ll1l1111_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡤࡱࡱࠫࡢࡡࠧࡪࡥࡲࡲ࡙ࡿࡰࡦࠩࡠࠦ欅"))
	# l1ll1ll1l1ll1_l1_ l1ll1ll1l1111_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡶࡼࡰࡪ࠭࡝ࠣ欆"))
	succeeded,l1l11lll1_l1_,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	#l1ll1l1ll11ll_l1_ = []
	# l1ll1lll111ll_l1_
	#l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡬ࡪࡥ࡮ࡘࡷࡧࡣ࡬࡫ࡱ࡫ࡕࡧࡲࡢ࡯ࡶࠫࡢࠨ欇"))
	# l1l1111lll1_l1_ l11l111l111l_l1_
	#l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡹࡸࡡࡤ࡭࡬ࡲ࡬ࡖࡡࡳࡣࡰࡷࠬࡣࠢ欈"))
	#succeeded,l1ll1l1lll11l_l1_,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	l1ll1l1ll11ll_l1_ = []
	# l1l1111lll1_l1_ l11l111l111l_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ欉"))
	# l1ll1lll111ll_l1_
	l1ll1l1ll11ll_l1_.append(l11ll1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ權"))
	succeeded,token,l111l1ll_l1_ = l1ll1l1ll111l_l1_(item,render,l1ll1l1ll11ll_l1_)
	if l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࠪ欋") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11l1_l1_ = l11ll1_l1_ (u"࠭ࠧ欌"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ欍")
	if l11ll1_l1_ (u"ࠨ็หหูืࠧ欎") in l1l11lll1_l1_: l1l11lll1_l1_,l111lll11l1_l1_ = l11ll1_l1_ (u"ࠩࠪ欏"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ欐")
	if l11ll1_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ欑") in list(render.keys()):
		l1ll1ll1lll11_l1_ = str(render[l11ll1_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ欒")])
		if l11ll1_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭欓") in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ欔")
		if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭欕") in l1ll1ll1lll11_l1_: l111lll11l1_l1_ = l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ欖")
		if l11ll1_l1_ (u"ࠪࡆࡺࡿࠧ欗") in l1ll1ll1lll11_l1_ or l11ll1_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ欘") in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ欙")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡻࠧๆสสุึ࠭欚")) in l1ll1ll1lll11_l1_: l111lll11l1_l1_ = l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ欛")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡶࠩืีฬวࠧ欜")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ欝")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡸࠫฬูสวฮสีࠬ欞")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ欟")
		if l1l1l1l1l1ll_l1_(l11ll1_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ欠")) in l1ll1ll1lll11_l1_: l1ll1ll11l111_l1_ = l11ll1_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ次")
	l1lllll_l1_ = escapeUNICODE(l1lllll_l1_)
	if l1lllll_l1_ and l11ll1_l1_ (u"ࠧࡩࡶࡷࡴࠬ欢") not in l1lllll_l1_: l1lllll_l1_ = l11l1l_l1_+l1lllll_l1_
	l1lll1_l1_ = l1lll1_l1_.split(l11ll1_l1_ (u"ࠨࡁࠪ欣"))[0]
	if  l1lll1_l1_ and l11ll1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ欤") not in l1lll1_l1_: l1lll1_l1_ = l11ll1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ欥")+l1lll1_l1_
	title = escapeUNICODE(title)
	if l1ll1ll11l111_l1_: title = l1ll1ll11l111_l1_+title
	#title = unescapeHTML(title)
	l1l11lll1_l1_ = l1l11lll1_l1_.replace(l11ll1_l1_ (u"ࠫ࠱࠭欦"),l11ll1_l1_ (u"ࠬ࠭欧"))
	count = count.replace(l11ll1_l1_ (u"࠭ࠬࠨ欨"),l11ll1_l1_ (u"ࠧࠨ欩"))
	count = re.findall(l11ll1_l1_ (u"ࠨ࡞ࡧ࠯ࠬ欪"),count)
	if count: count = count[0]
	else: count = l11ll1_l1_ (u"ࠩࠪ欫")
	return True,title,l1lllll_l1_,l1lll1_l1_,count,l1l11lll1_l1_,l111lll11l1_l1_,l1ll1ll11l111_l1_,token
def l1ll1ll111lll_l1_(url,data=l11ll1_l1_ (u"ࠪࠫ欬"),request=l11ll1_l1_ (u"ࠫࠬ欭")):
	if request==l11ll1_l1_ (u"ࠬ࠭欮"): request = l11ll1_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭欯")
	#if l11ll1_l1_ (u"ࠧࡠࡡࠪ欰") in l1ll1ll1l111l_l1_: l1ll1ll1l111l_l1_ = l11ll1_l1_ (u"ࠨࠩ欱")
	#if l11ll1_l1_ (u"ࠩࡶࡷࡂ࠭欲") in url: url = url.split(l11ll1_l1_ (u"ࠪࡷࡸࡃࠧ欳"))[0]
	l111lll1ll_l1_ = l11llllll_l1_()
	#l111lll1ll_l1_ = l11ll1_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠳࠳࠽࠳࠶࠮࠱࠰࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠤࡊࡪࡧ࠰࠳࠳࠽࠳࠶࠮࠲࠷࠴࠼࠳࠽࠰ࠨ欴")
	l1l1ll11l_l1_ = {l11ll1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ欵"):l111lll1ll_l1_,l11ll1_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭欶"):l11ll1_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ欷")}
	#l1l1ll11l_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ欸"))
	if data.count(l11ll1_l1_ (u"ࠩ࠽࠾࠿࠭欹"))==4: l1ll1ll1l11ll_l1_,key,l1ll1ll11ll1l_l1_,l1ll1l1llllll_l1_,token = data.split(l11ll1_l1_ (u"ࠪ࠾࠿ࡀࠧ欺"))
	else: l1ll1ll1l11ll_l1_,key,l1ll1ll11ll1l_l1_,l1ll1l1llllll_l1_,token = l11ll1_l1_ (u"ࠫࠬ欻"),l11ll1_l1_ (u"ࠬ࠭欼"),l11ll1_l1_ (u"࠭ࠧ欽"),l11ll1_l1_ (u"ࠧࠨ款"),l11ll1_l1_ (u"ࠨࠩ欿")
	l11ll11l1_l1_ = {l11ll1_l1_ (u"ࠤࡦࡳࡳࡺࡥࡹࡶࠥ歀"):{l11ll1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ歁"):{l11ll1_l1_ (u"ࠦ࡭ࡲࠢ歂"):l11ll1_l1_ (u"ࠧࡧࡲࠣ歃"),l11ll1_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ歄"):l11ll1_l1_ (u"ࠢࡘࡇࡅࠦ歅"),l11ll1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ歆"):l1ll1ll11ll1l_l1_}}}
	if url==l11l1l_l1_+l11ll1_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ歇") or l11ll1_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ歈") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡶࡪ࡫࡬࠰ࡴࡨࡩࡱࡥࡷࡢࡶࡦ࡬ࡤࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ歉")+l11ll1_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ歊")+key
		l11ll11l1_l1_[l11ll1_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࡑࡣࡵࡥࡲࡹࠧ歋")] = l1ll1ll1l11ll_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠧࡑࡑࡖࡘࠬ歌"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭歍"))
	elif l11ll1_l1_ (u"ࠩ࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ歎") in url:
		url = l11l1l_l1_+l11ll1_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭歏")+key
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ歐"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ歑"))
	elif l11ll1_l1_ (u"࠭࡫ࡦࡻࡀࠫ歒") in url and l1ll1ll1l11ll_l1_:
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭歓")] = token
		l11ll11l1_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ歔")][l11ll1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࠩ歕")][l11ll1_l1_ (u"ࠪࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ歖")] = l1ll1ll1l11ll_l1_
		l11ll11l1_l1_ = str(l11ll11l1_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠫࡕࡕࡓࡕࠩ歗"),url,l11ll11l1_l1_,l1l1ll11l_l1_,True,True,l11ll1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ歘"))
	elif l11ll1_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ歙") in url and l1ll1l1llllll_l1_:
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ歚"):l11ll1_l1_ (u"ࠨ࠳ࠪ歛"),l11ll1_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭歜"):l1ll1ll11ll1l_l1_})
		l1l1ll11l_l1_.update({l11ll1_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ歝"):l11ll1_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ歞")+l1ll1l1llllll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ歟"),url,l11ll1_l1_ (u"࠭ࠧ歠"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠧࠨ歡"),l11ll1_l1_ (u"ࠨࠩ止"),l11ll1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠹ࡹ࡮ࠧ正"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1lll1_l1_,l11ll1_l1_ (u"ࠪࡋࡊ࡚ࠧ此"),url,l11ll1_l1_ (u"ࠫࠬ步"),l1l1ll11l_l1_,l11ll1_l1_ (u"ࠬ࠭武"),l11ll1_l1_ (u"࠭ࠧ歧"),l11ll1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠸ࡷ࡬ࠬ歨"))
	html = response.content
	tmp = re.findall(l11ll1_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ歩"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ歪"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll11ll1l_l1_ = tmp[0]
	tmp = re.findall(l11ll1_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭歫"),html,re.DOTALL|re.I)
	if tmp: l1ll1ll1l11ll_l1_ = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ歬"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11ll1_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ歭"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11ll1_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩࠨ࠺ࡼࠤࡷࡳࡰ࡫࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ歮"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ歯"),l11ll1_l1_ (u"ࠨࠩ歰"),l11ll1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ歱"),str(len(tmp)))
	#if tmp: l1ll1lll111ll_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11ll1_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ歲") in list(cookies.keys()): l1ll1l1llllll_l1_ = cookies[l11ll1_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ歳")]
	l11ll11ll_l1_ = l1ll1ll1l11ll_l1_+l11ll1_l1_ (u"ࠬࡀ࠺࠻ࠩ歴")+key+l11ll1_l1_ (u"࠭࠺࠻࠼ࠪ歵")+l1ll1ll11ll1l_l1_+l11ll1_l1_ (u"ࠧ࠻࠼࠽ࠫ歶")+l1ll1l1llllll_l1_+l11ll1_l1_ (u"ࠨ࠼࠽࠾ࠬ歷")+token
	if request==l11ll1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ歸") and l11ll1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ歹") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡠࡠࠨࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠨ࡜࡞ࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭歺"),html,re.DOTALL)
		if not l111ll1lll_l1_: l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭死"),html,re.DOTALL)
		l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"࠭ࡳࡵࡴࠪ歼"),l111ll1lll_l1_[0])
	elif request==l11ll1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ歽") and l11ll1_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭歾") in html:
		l111ll1lll_l1_ = re.findall(l11ll1_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ歿"),html,re.DOTALL)
		l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠪࡷࡹࡸࠧ殀"),l111ll1lll_l1_[0])
	elif l11ll1_l1_ (u"ࠫࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ殁") not in html: l1ll1l1ll1l11_l1_ = EVAL(l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ殂"),html)
	else: l1ll1l1ll1l11_l1_ = l11ll1_l1_ (u"࠭ࠧ殃")
	if 0:
		cc = str(l1ll1l1ll1l11_l1_)
		if kodi_version>18.99: cc = cc.encode(l11ll1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ殄"))
		open(l11ll1_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮ࡥࡣࡷࠫ殅"),l11ll1_l1_ (u"ࠩࡺࡦࠬ殆")).write(cc)
		#open(l11ll1_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ殇"),l11ll1_l1_ (u"ࠫࡼ࠭殈")).write(html)
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ殉"),l11ll11ll_l1_)
	return html,l1ll1l1ll1l11_l1_,l11ll11ll_l1_
def l1ll1lll11111_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11ll1_l1_ (u"࠭ࠠࠨ殊"),l11ll1_l1_ (u"ࠧࠬࠩ残"))
	l111lll_l1_ = url+l11ll1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ殌")+search
	l11111_l1_(l111lll_l1_,index)
	return
def SEARCH(search):
	#search = l11ll1_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ殍")+l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ殎")+l11ll1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ殏")+l11ll1_l1_ (u"ࠬࡥࠧ殐")+search
	#DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ殑"),l11ll1_l1_ (u"ࠧࠨ殒"),l11ll1_l1_ (u"ࠨࠩ殓"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ殔"),l11ll1_l1_ (u"ࠪࠫ殕"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11ll1_l1_ (u"ࠫࠥ࠭殖"),l11ll1_l1_ (u"ࠬ࠱ࠧ殗"))
	l111lll_l1_ = l11l1l_l1_+l11ll1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࠨ殘")+search
	if not l1ll_l1_:
		if l11ll1_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪ殙") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡕࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ殚")
		elif l11ll1_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨ殛") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ殜")
		elif l11ll1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩ殝") in options: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡨࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ殞")
		else: l1ll1ll11111l_l1_ = l11ll1_l1_ (u"࠭ࠧ殟")
		l11l111_l1_ = l111lll_l1_+l1ll1ll11111l_l1_
	else:
		l1ll1ll111111_l1_,l1ll1l1ll1111_l1_,l1lll1l1l_l1_ = [],[],l11ll1_l1_ (u"ࠧࠨ殠")
		l1ll1l1ll11l1_l1_ = [l11ll1_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ殡"),l11ll1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ殢"),l11ll1_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭殣"),l11ll1_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ殤"),l11ll1_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ殥")]
		l1ll1ll1ll111_l1_ = [l11ll1_l1_ (u"࠭ࠧ殦"),l11ll1_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭殧"),l11ll1_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ殨"),l11ll1_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ殩"),l11ll1_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ殪")]
		l1ll1ll1lll1l_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ殫"),l1ll1l1ll11l1_l1_)
		if l1ll1ll1lll1l_l1_ == -1: return
		l1ll1l1lllll1_l1_ = l1ll1ll1ll111_l1_[l1ll1ll1lll1l_l1_]
		html,c,data = l1ll1ll111lll_l1_(l111lll_l1_+l1ll1l1lllll1_l1_)
		if c:
			try:
				d = c[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ殬")][l11ll1_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ殭")][l11ll1_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ殮")][l11ll1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ殯")][l11ll1_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ殰")][l11ll1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ殱")][l11ll1_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ殲")]
				for l1ll1l1l1llll_l1_ in range(len(d)):
					group = d[l1ll1l1l1llll_l1_][l11ll1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ殳")][l11ll1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ殴")]
					for l1ll1lll1111l_l1_ in range(len(group)):
						render = group[l1ll1lll1111l_l1_][l11ll1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ段")]
						if l11ll1_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭殶") in list(render.keys()):
							l1lllll_l1_ = render[l11ll1_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ殷")][l11ll1_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ殸")][l11ll1_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ殹")][l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ殺")]
							l1lllll_l1_ = l1lllll_l1_.replace(l11ll1_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭殻"),l11ll1_l1_ (u"ࠧࠧࠩ殼"))
							title = render[l11ll1_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ殽")]
							title = title.replace(l11ll1_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ殾"),l11ll1_l1_ (u"ࠪࠫ殿"))
							if l11ll1_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ毀") in title: continue
							if l11ll1_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ毁") in title:
								title = l11ll1_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ毂")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"ࠧหำอ๎อࠦอิสࠪ毃") in title: continue
							title = title.replace(l11ll1_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭毄"),l11ll1_l1_ (u"ࠩࠪ毅"))
							if l11ll1_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ毆") in title: continue
							if l11ll1_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭毇") in title:
								title = l11ll1_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭毈")+title
								l1lll1l1l_l1_ = title
								l1lllll11l_l1_ = l1lllll_l1_
							if l11ll1_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ毉") in title: continue
							l1ll1ll111111_l1_.append(escapeUNICODE(title))
							l1ll1l1ll1111_l1_.append(l1lllll_l1_)
			except: pass
		if not l1lll1l1l_l1_: l1ll1ll1l1l1l_l1_ = l11ll1_l1_ (u"ࠧࠨ毊")
		else:
			l1ll1ll111111_l1_ = [l11ll1_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ毋"),l1lll1l1l_l1_]+l1ll1ll111111_l1_
			l1ll1l1ll1111_l1_ = [l11ll1_l1_ (u"ࠩࠪ毌"),l1lllll11l_l1_]+l1ll1l1ll1111_l1_
			l1ll1ll1lllll_l1_ = DIALOG_SELECT(l11ll1_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ母"),l1ll1ll111111_l1_)
			if l1ll1ll1lllll_l1_ == -1: return
			l1ll1ll1l1l1l_l1_ = l1ll1l1ll1111_l1_[l1ll1ll1lllll_l1_]
		if l1ll1ll1l1l1l_l1_: l11l111_l1_ = l11l1l_l1_+l1ll1ll1l1l1l_l1_
		elif l1ll1l1lllll1_l1_: l11l111_l1_ = l111lll_l1_+l1ll1l1lllll1_l1_
		else: l11l111_l1_ = l111lll_l1_
		l11ll1_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩ࡭ࡱࡺࡥࡳ࠯ࡧࡶࡴࡶࡤࡰࡹࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡳࡦࡥࡷ࡭ࡴࡴࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡲࡵࡶࡦࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡱࡵࡸࠥࡨࡹࠨ࠮ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ࠱ࡴࡪࡶ࡯ࡩࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠨࠢࠣ毎")
	#DIALOG_OK()
	l11111_l1_(l11l111_l1_)
	return
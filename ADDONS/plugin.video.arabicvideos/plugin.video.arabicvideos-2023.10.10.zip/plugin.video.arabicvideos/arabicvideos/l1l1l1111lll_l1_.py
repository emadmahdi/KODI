# -*- coding: utf-8 -*-
import sys
l1l1l1_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11ll_l1_ = 7
def l11ll1_l1_ (l1_l1_):
    global l1l11ll_l1_
    l1l1ll1_l1_ = ord (l1_l1_ [-1])
    l1l1ll_l1_ = l1_l1_ [:-1]
    l1ll1_l1_ = l1l1ll1_l1_ % len (l1l1ll_l1_)
    l1ll1ll_l1_ = l1l1ll_l1_ [:l1ll1_l1_] + l1l1ll_l1_ [l1ll1_l1_:]
    if l1l1l1_l1_:
        l11l11_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    else:
        l11l11_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1ll11_l1_ + l1l1ll1_l1_) % l11ll_l1_) for l1ll11_l1_, char in enumerate (l1ll1ll_l1_)])
    return eval (l11l11_l1_)
from LIBSTWO import *
script_name = l11ll1_l1_ (u"ࠪࡑ࠸࡛ࠧ䁅")
l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䁆")
l11lllll11ll_l1_ = [
		 l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䁇")
		,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䁈"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䁉")
		,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䁊"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䁋")
		#,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䁌"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䁍"),l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䁎")
		,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䁏"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䁐")
		,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䁑"),l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ䁒"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ䁓")
		,l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䁔"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䁕")
		,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䁖"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䁗")
		,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䁘"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ䁙"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ䁚")
		]
l11llll1lll1_l1_ = 4
def MAIN(mode,url,text,type,l1l1111_l1_,l1ll1ll1l11_l1_):
	global l111l1_l1_
	try:
		l1lll111l11l_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䁛")])
		l111l1_l1_ = l11ll1_l1_ (u"ࠬࡥࡍࡖࠩ䁜")+l1lll111l11l_l1_+l11ll1_l1_ (u"࠭࡟ࠨ䁝")
	except: l1lll111l11l_l1_ = l11ll1_l1_ (u"ࠧࠨ䁞")
	try: l111l1ll_l1_ = str(l1ll1ll1l11_l1_[l11ll1_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࠪ䁟")])
	except: l111l1ll_l1_ = l11ll1_l1_ (u"ࠩࠪ䁠")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1lll111l11l_l1_,l111l1ll_l1_)
	elif mode==712: results = l1l1111ll111_l1_(l1lll111l11l_l1_)
	elif mode==713: results = GROUPS(l1lll111l11l_l1_,url,text,l1l1111_l1_)
	elif mode==714: results = ITEMS(l1lll111l11l_l1_,url,text,l1l1111_l1_)
	elif mode==715: results = PLAY(l1lll111l11l_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1lll111l11l_l1_,True)
	elif mode==717: results = l1l111l1llll_l1_(l1lll111l11l_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1lll111l11l_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1lll111l11l_l1_,url,l1l1111_l1_)
	elif mode==720: results = MENU(l1lll111l11l_l1_)
	elif mode==721: results = l1l111111lll_l1_(l1lll111l11l_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1lll111l11l_l1_)
	elif mode==723: results = ADD_USERAGENT(l1lll111l11l_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==726: results = ADD_REFERER(l1lll111l11l_l1_)
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1lll111l11l_l1_,url,l1l1111_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1lll111l11l_l1_ in range(1,FOLDERS_COUNT+1):
		l11lllll1l11_l1_ = l11ll1_l1_ (u"ࠪࠤࡒ࠹ࡕࠨ䁡")+str(l1lll111l11l_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠫࡤࡓࡕࠨ䁢")+str(l1lll111l11l_l1_)+l11ll1_l1_ (u"ࠬࡥࠧ䁣")
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁤"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆฮ็ำࠥ࠭䁥")+text_numbers[l1lll111l11l_l1_]+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࠩ䁦"),720,l11ll1_l1_ (u"ࠩࠪ䁧"),l11ll1_l1_ (u"ࠪࠫ䁨"),l11ll1_l1_ (u"ࠫࠬ䁩"),l11ll1_l1_ (u"ࠬ࠭䁪"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁫"):l1lll111l11l_l1_})
	return
def SECTIONS_MENU():
	global l111l1_l1_
	addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁬"),l111l1_l1_+l11ll1_l1_ (u"ࠨฮ่๎฾ࠦรใีส้ࠬ䁭"),l11ll1_l1_ (u"ࠩࠪ䁮"),165,l11ll1_l1_ (u"ࠪࠫ䁯"),l11ll1_l1_ (u"ࠫࠬ䁰"),l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䁱"))
	addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䁲"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䁳"),l11ll1_l1_ (u"ࠨࠩ䁴"),9999)
	for l1lll111l11l_l1_ in range(1,FOLDERS_COUNT+1):
		l11lllll1l11_l1_ = l11ll1_l1_ (u"ࠩࠣࡑ࠸࡛ࠧ䁵")+str(l1lll111l11l_l1_)
		l111l1_l1_ = l11ll1_l1_ (u"ࠪࡣࡒ࡛ࠧ䁶")+str(l1lll111l11l_l1_)+l11ll1_l1_ (u"ࠫࡤ࠭䁷")
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁸"),l111l1_l1_+l11ll1_l1_ (u"࠭รใีส้๋ࠥฬๅัࠣࠫ䁹")+text_numbers[l1lll111l11l_l1_]+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࠨ䁺"),165,l11ll1_l1_ (u"ࠨࠩ䁻"),l11ll1_l1_ (u"ࠩࠪ䁼"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䁽"),l11ll1_l1_ (u"ࠫࠬ䁾"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁿"):l1lll111l11l_l1_})
	return
def MENU(l1lll111l11l_l1_=l11ll1_l1_ (u"࠭ࠧ䂀")):
	if l1lll111l11l_l1_:
		l11lll1ll111_l1_ = {l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂁"):l1lll111l11l_l1_}
		l11lllll1l11_l1_ = l11ll1_l1_ (u"ࠨࠩ䂂")  # l11ll1_l1_ (u"ࠩࠣࡑ࠸࡛ࠧ䂃")+str(l1lll111l11l_l1_)
	else:
		l11lll1ll111_l1_ = l11ll1_l1_ (u"ࠪࠫ䂄")
		l11lllll1l11_l1_ = l11ll1_l1_ (u"ࠫࠬ䂅")
	if CHECK_TABLES_EXIST(l1lll111l11l_l1_,True):
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂆"),l111l1_l1_+l11ll1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็็ๅฬะࠧ䂇")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࠨ䂈"),729,l11ll1_l1_ (u"ࠨࠩ䂉"),l11ll1_l1_ (u"ࠩࠪ䂊"),l11ll1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䂋"),l11ll1_l1_ (u"ࠫࠬ䂌"),l11lll1ll111_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂍"),l111l1_l1_+l11ll1_l1_ (u"࠭โศศ่อࠥษโิษ่ࠫ䂎")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࠨ䂏"),165,l11ll1_l1_ (u"ࠨࠩ䂐"),l11ll1_l1_ (u"ࠩࠪ䂑"),l11ll1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䂒"),l11ll1_l1_ (u"ࠫࠬ䂓"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䂔"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䂕"),l11ll1_l1_ (u"ࠧࠨ䂖"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂗"),l111l1_l1_+l11ll1_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠠๆ่ࠣวุ๋วว้สࠫ䂘")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ䂙"),713,l11ll1_l1_ (u"ࠫࠬ䂚"),l11ll1_l1_ (u"ࠬ࠭䂛"),l11ll1_l1_ (u"࠭ࠧ䂜"),l11ll1_l1_ (u"ࠧࠨ䂝"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂞"),l111l1_l1_+l11ll1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโห้๋ࠣࠦริ็สส์อࠧ䂟")+l11lllll1l11_l1_,l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ䂠"),713,l11ll1_l1_ (u"ࠫࠬ䂡"),l11ll1_l1_ (u"ࠬ࠭䂢"),l11ll1_l1_ (u"࠭ࠧ䂣"),l11ll1_l1_ (u"ࠧࠨ䂤"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䂥"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䂦"),l11ll1_l1_ (u"ࠪࠫ䂧"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂨"),l111l1_l1_+l11ll1_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโห้๋ࠣࠦรใีส้์อࠧ䂩")+l11lllll1l11_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ䂪"),713,l11ll1_l1_ (u"ࠧࠨ䂫"),l11ll1_l1_ (u"ࠨࠩ䂬"),l11ll1_l1_ (u"ࠩࠪ䂭"),l11ll1_l1_ (u"ࠪࠫ䂮"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䂯"),l111l1_l1_+l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢฦๆุอๅ่ษࠪ䂰")+l11lllll1l11_l1_,l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ䂱"),713,l11ll1_l1_ (u"ࠧࠨ䂲"),l11ll1_l1_ (u"ࠨࠩ䂳"),l11ll1_l1_ (u"ࠩࠪ䂴"),l11ll1_l1_ (u"ࠪࠫ䂵"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䂶"),l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䂷"),l11ll1_l1_ (u"࠭ࠧ䂸"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂹"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ๆ๋๎วหࠢส่ศ฻ไ๋หࠪ䂺")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䂻"),713,l11ll1_l1_ (u"ࠪࠫ䂼"),l11ll1_l1_ (u"ࠫࠬ䂽"),l11ll1_l1_ (u"ࠬ࠭䂾"),l11ll1_l1_ (u"࠭ࠧ䂿"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃀"),l111l1_l1_+l11ll1_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠥอไฤื็๎ฮ࠭䃁")+l11lllll1l11_l1_,l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䃂"),713,l11ll1_l1_ (u"ࠪࠫ䃃"),l11ll1_l1_ (u"ࠫࠬ䃄"),l11ll1_l1_ (u"ࠬ࠭䃅"),l11ll1_l1_ (u"࠭ࠧ䃆"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䃇"),l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䃈"),l11ll1_l1_ (u"ࠩࠪ䃉"),9999)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃊"),l111l1_l1_+l11ll1_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แสࠩ䃋")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䃌"),713,l11ll1_l1_ (u"࠭ࠧ䃍"),l11ll1_l1_ (u"ࠧࠨ䃎"),l11ll1_l1_ (u"ࠨࠩ䃏"),l11ll1_l1_ (u"ࠩࠪ䃐"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃑"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอࠬ䃒")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䃓"),713,l11ll1_l1_ (u"࠭ࠧ䃔"),l11ll1_l1_ (u"ࠧࠨ䃕"),l11ll1_l1_ (u"ࠨࠩ䃖"),l11ll1_l1_ (u"ࠩࠪ䃗"),l11lll1ll111_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃘"),l111l1_l1_+l11ll1_l1_ (u"ࠫศ็ไศ็ฺ้ࠣ์แสࠩ䃙")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䃚"),713,l11ll1_l1_ (u"࠭ࠧ䃛"),l11ll1_l1_ (u"ࠧࠨ䃜"),l11ll1_l1_ (u"ࠨࠩ䃝"),l11ll1_l1_ (u"ࠩࠪ䃞"),l11lll1ll111_l1_)
		#addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃟"),l111l1_l1_+l11ll1_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥี็ใฬࠫ䃠")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䃡"),713,l11ll1_l1_ (u"࠭ࠧ䃢"),l11ll1_l1_ (u"ࠧࠨ䃣"),l11ll1_l1_ (u"ࠨࠩ䃤"),l11ll1_l1_ (u"ࠩࠪ䃥"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃦"),l111l1_l1_+l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅอ้๋่ฮ࠭䃧")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䃨"),713,l11ll1_l1_ (u"࠭ࠧ䃩"),l11ll1_l1_ (u"ࠧࠨ䃪"),l11ll1_l1_ (u"ࠨࠩ䃫"),l11ll1_l1_ (u"ࠩࠪ䃬"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃭"),l111l1_l1_+l11ll1_l1_ (u"ࠫ็์่ศฬ้ࠣัํ่ๅหࠪ䃮")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䃯"),713,l11ll1_l1_ (u"࠭ࠧ䃰"),l11ll1_l1_ (u"ࠧࠨ䃱"),l11ll1_l1_ (u"ࠨࠩ䃲"),l11ll1_l1_ (u"ࠩࠪ䃳"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䃴"),l11ll1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䃵"),l11ll1_l1_ (u"ࠬ࠭䃶"),9999)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃷"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอࠥ๎ๅาฬหอࠬ䃸")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䃹"),713,l11ll1_l1_ (u"ࠩࠪ䃺"),l11ll1_l1_ (u"ࠪࠫ䃻"),l11ll1_l1_ (u"ࠫࠬ䃼"),l11ll1_l1_ (u"ࠬ࠭䃽"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃾"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ䃿")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䄀"),713,l11ll1_l1_ (u"ࠩࠪ䄁"),l11ll1_l1_ (u"ࠪࠫ䄂"),l11ll1_l1_ (u"ࠫࠬ䄃"),l11ll1_l1_ (u"ࠬ࠭䄄"),l11lll1ll111_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄅"),l111l1_l1_+l11ll1_l1_ (u"ࠧฤใ็ห๊ࠦๅึ่ไอࠥ๎ๅาฬหอࠬ䄆")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䄇"),713,l11ll1_l1_ (u"ࠩࠪ䄈"),l11ll1_l1_ (u"ࠪࠫ䄉"),l11ll1_l1_ (u"ࠫࠬ䄊"),l11ll1_l1_ (u"ࠬ࠭䄋"),l11lll1ll111_l1_)
		#addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄌"),l111l1_l1_+l11ll1_l1_ (u"ࠧๆี็ื้อสࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ䄍")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䄎"),713,l11ll1_l1_ (u"ࠩࠪ䄏"),l11ll1_l1_ (u"ࠪࠫ䄐"),l11ll1_l1_ (u"ࠫࠬ䄑"),l11ll1_l1_ (u"ࠬ࠭䄒"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄓"),l111l1_l1_+l11ll1_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไส๋้ࠢึะศสࠩ䄔")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䄕"),713,l11ll1_l1_ (u"ࠩࠪ䄖"),l11ll1_l1_ (u"ࠪࠫ䄗"),l11ll1_l1_ (u"ࠫࠬ䄘"),l11ll1_l1_ (u"ࠬ࠭䄙"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄚"),l111l1_l1_+l11ll1_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ่ࠦๆำอฬฮ࠭䄛")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䄜"),713,l11ll1_l1_ (u"ࠩࠪ䄝"),l11ll1_l1_ (u"ࠪࠫ䄞"),l11ll1_l1_ (u"ࠫࠬ䄟"),l11ll1_l1_ (u"ࠬ࠭䄠"),l11lll1ll111_l1_)
		addMenuItem(l11ll1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䄡"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䄢"),l11ll1_l1_ (u"ࠨࠩ䄣"),9999)
	for seq in range(1,l11llll1lll1_l1_+1):
		addMenuItem(l11ll1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䄤"),l111l1_l1_+l11ll1_l1_ (u"ࠪษ฻อแส๋ࠢฮ฿๐๊าࠢิหอ฽ࠧ䄥")+l11lllll1l11_l1_+l11ll1_l1_ (u"ࠫࠥ࠭䄦")+text_numbers[seq],l11ll1_l1_ (u"ࠬ࠭䄧"),711,l11ll1_l1_ (u"࠭ࠧ䄨"),l11ll1_l1_ (u"ࠧࠨ䄩"),l11ll1_l1_ (u"ࠨࠩ䄪"),l11ll1_l1_ (u"ࠩࠪ䄫"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䄬"):l1lll111l11l_l1_,l11ll1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭䄭"):seq})
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄮"),l111l1_l1_+l11ll1_l1_ (u"࠭ศาษ่ะࠥอไใ่๋หฯࠦࠨอั๋่ࠥ็โุࠫࠪ䄯")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䄰"),713,l11ll1_l1_ (u"ࠨࠩ䄱"),l11ll1_l1_ (u"ࠩࠪ䄲"),l11ll1_l1_ (u"ࠪࠫ䄳"),l11ll1_l1_ (u"ࠫࠬ䄴"),l11lll1ll111_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄵"),l111l1_l1_+l11ll1_l1_ (u"࠭ราึํๅࠥอไใ่๋หฯࠦไๅลํห๊ࠦวๅ็สฺ๏ฯࠧ䄶")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䄷"),713,l11ll1_l1_ (u"ࠨࠩ䄸"),l11ll1_l1_ (u"ࠩࠪ䄹"),l11ll1_l1_ (u"ࠪࠫ䄺"),l11ll1_l1_ (u"ࠫࠬ䄻"),l11lll1ll111_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄼"),l111l1_l1_+l11ll1_l1_ (u"࠭ราึํๅࠥฮัศ็ฯࠤฬ๊โ็๊สฮ๊ࠥไฤ์ส้ࠥอไๆษู๎ฮ࠭䄽")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䄾"),713,l11ll1_l1_ (u"ࠨࠩ䄿"),l11ll1_l1_ (u"ࠩࠪ䅀"),l11ll1_l1_ (u"ࠪࠫ䅁"),l11ll1_l1_ (u"ࠫࠬ䅂"),l11lll1ll111_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䅃"),l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䅄"),l11ll1_l1_ (u"ࠧࠨ䅅"),9999)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅆"),l111l1_l1_+l11ll1_l1_ (u"ࠩศฺฬ็ษࠡล๋ࠤฯเ๊๋ำࠣหูะัศๅࠪ䅇")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅈"),711,l11ll1_l1_ (u"ࠫࠬ䅉"),l11ll1_l1_ (u"ࠬ࠭䅊"),l11ll1_l1_ (u"࠭ࠧ䅋"),l11ll1_l1_ (u"ࠧࠨ䅌"),l11lll1ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅍"),l111l1_l1_+l11ll1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠨ䅎")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅏"),721,l11ll1_l1_ (u"ࠫࠬ䅐"),l11ll1_l1_ (u"ࠬ࠭䅑"),l11ll1_l1_ (u"࠭ࠧ䅒"),l11ll1_l1_ (u"ࠧࠨ䅓"),l11lll1ll111_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅔"),l111l1_l1_+l11ll1_l1_ (u"ࠩไัฺࠦวีฬิห่࠭䅕")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅖"),716,l11ll1_l1_ (u"ࠫࠬ䅗"),l11ll1_l1_ (u"ࠬ࠭䅘"),l11ll1_l1_ (u"࠭ࠧ䅙"),l11ll1_l1_ (u"ࠧࠨ䅚"),l11lll1ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅛"),l111l1_l1_+l11ll1_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠬ䅜")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅝"),712,l11ll1_l1_ (u"ࠫࠬ䅞"),l11ll1_l1_ (u"ࠬ࠭䅟"),l11ll1_l1_ (u"࠭ࠧ䅠"),l11ll1_l1_ (u"ࠧࠨ䅡"),l11lll1ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅢"),l111l1_l1_+l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠬ䅣")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅤"),717,l11ll1_l1_ (u"ࠫࠬ䅥"),l11ll1_l1_ (u"ࠬ࠭䅦"),l11ll1_l1_ (u"࠭ࠧ䅧"),l11ll1_l1_ (u"ࠧࠨ䅨"),l11lll1ll111_l1_)
	#addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅩"),l111l1_l1_+l11ll1_l1_ (u"ࠩสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊ริำ฼ࠫ䅪")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅫"),722,l11ll1_l1_ (u"ࠫࠬ䅬"),l11ll1_l1_ (u"ࠬ࠭䅭"),l11ll1_l1_ (u"࠭ࠧ䅮"),l11ll1_l1_ (u"ࠧࠨ䅯"),l11lll1ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅰"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦส฻์ํีࠬ䅱")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅲"),723,l11ll1_l1_ (u"ࠫࠬ䅳"),l11ll1_l1_ (u"ࠬ࠭䅴"),l11ll1_l1_ (u"࠭ࠧ䅵"),l11ll1_l1_ (u"ࠧࠨ䅶"),l11lll1ll111_l1_)
	addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅷"),l111l1_l1_+l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠣฮ฿๐๊าࠩ䅸")+l11lllll1l11_l1_,l11ll1_l1_ (u"ࠪࠫ䅹"),726,l11ll1_l1_ (u"ࠫࠬ䅺"),l11ll1_l1_ (u"ࠬ࠭䅻"),l11ll1_l1_ (u"࠭ࠧ䅼"),l11ll1_l1_ (u"ࠧࠨ䅽"),l11lll1ll111_l1_)
	return
def CHECK_ACCOUNT(l1lll111l11l_l1_,l1ll_l1_=True):
	ok,status = False,l11ll1_l1_ (u"ࠨࠩ䅾")
	l11lll1l1ll1_l1_,l1l111ll111l_l1_ = l11ll1_l1_ (u"ࠩࠪ䅿"),l11ll1_l1_ (u"ࠪࠫ䆀")
	l1l111lll11l_l1_,l11lllll1111_l1_,server,username,password = GET_URL(l1lll111l11l_l1_)
	if username==l11ll1_l1_ (u"ࠫࠬ䆁"): return
	headers = GET_HEADERS(l1lll111l11l_l1_)
	if l1l111lll11l_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11ll1_l1_ (u"ࠬࡍࡅࡕࠩ䆂"),l1l111lll11l_l1_,l11ll1_l1_ (u"࠭ࠧ䆃"),headers,False,l11ll1_l1_ (u"ࠧࠨ䆄"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ䆅"))
		html = response.content
		if response.succeeded:
			timestamp,l11lll1l111l_l1_,l11lll11ll11_l1_,l11ll1lll1ll_l1_,l11lllll11l1_l1_ = 0,0,l11ll1_l1_ (u"ࠩࠪ䆆"),l11ll1_l1_ (u"ࠪࠫ䆇"),l11ll1_l1_ (u"ࠫࠬ䆈")
			try:
				dict = EVAL(l11ll1_l1_ (u"ࠬࡪࡩࡤࡶࠪ䆉"),html)
				status = dict[l11ll1_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ䆊")][l11ll1_l1_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ䆋")]
				ok = True
				l11lll11ll11_l1_ = dict[l11ll1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䆌")][l11ll1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡟࡯ࡱࡺࠫ䆍")]
			except: pass
			if l11lll11ll11_l1_:
				try:
					struct = time.strptime(l11lll11ll11_l1_,l11ll1_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ䆎"))
					timestamp = int(time.mktime(struct))
					l11lll1l111l_l1_ = int(now-timestamp)
					l11lll1l111l_l1_ = int((l11lll1l111l_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䆏")][l11ll1_l1_ (u"ࠬࡩࡲࡦࡣࡷࡩࡩࡥࡡࡵࠩ䆐")]))
					l11ll1lll1ll_l1_ = time.strftime(l11ll1_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ䆑"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䆒")][l11ll1_l1_ (u"ࠨࡧࡻࡴࡤࡪࡡࡵࡧࠪ䆓")]))
					l11lllll11l1_l1_ = time.strftime(l11ll1_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭䆔"),struct)
				except: pass
			settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ䆕")+l1lll111l11l_l1_,str(now))
			settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫ࡥࠧ䆖")+l1lll111l11l_l1_,str(l11lll1l111l_l1_))
			try:
				l11llllll11l_l1_ = l11ll1_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠦ࠿࠭䆗")+html.split(l11ll1_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠧࡀࠧ䆘"))[1]
				l11llllll11l_l1_ = l11llllll11l_l1_.replace(l11ll1_l1_ (u"ࠧ࠻ࠩ䆙"),l11ll1_l1_ (u"ࠨ࠼ࠣࠫ䆚")).replace(l11ll1_l1_ (u"ࠩ࠯ࠫ䆛"),l11ll1_l1_ (u"ࠪ࠰ࠥ࠭䆜")).replace(l11ll1_l1_ (u"ࠫࢂࢃࠧ䆝"),l11ll1_l1_ (u"ࠬࢃࠧ䆞"))
				new = re.findall(l11ll1_l1_ (u"࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࠤࡳࡳࡷࡺࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䆟"),l11llllll11l_l1_,re.DOTALL)
				l11lll1l1ll1_l1_,l1l111ll111l_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11ll1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ䆠")][l11ll1_l1_ (u"ࠨ࡯ࡤࡼࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࡵࠪ䆡")]
				l1l111111111_l1_ = dict[l11ll1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ䆢")][l11ll1_l1_ (u"ࠪࡥࡨࡺࡩࡷࡧࡢࡧࡴࡴࡳࠨ䆣")]
				l1l11111llll_l1_ = dict[l11ll1_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䆤")][l11ll1_l1_ (u"ࠬ࡯ࡳࡠࡶࡵ࡭ࡦࡲࠧ䆥")]
				parts = l1l111lll11l_l1_.split(l11ll1_l1_ (u"࠭࠿ࠨ䆦"),1)
				message = l11ll1_l1_ (u"ࠧࡖࡔࡏ࠾࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆧")+l1l111lll11l_l1_+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆨")
				message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࡓࡵࡣࡷࡹࡸࡀࠠࠡࠩ䆩")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䆪")+status+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆫")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡕࡴ࡬ࡥࡱࡀࠠࠡࠢࠣࠫ䆬")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆭")+str(l1l11111llll_l1_==l11ll1_l1_ (u"ࠧ࠲ࠩ䆮"))+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆯")
				message += l11ll1_l1_ (u"ࠩ࡟ࡲࡈࡸࡥࡢࡶࡨࡨࠥࠦࡁࡵ࠼ࠣࠤࠬ䆰")+l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䆱")+l11ll1lll1ll_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆲")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡆࡺࡳ࡭ࡷࡿࠠࡅࡣࡷࡩ࠿ࠦࠠࠨ䆳")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆴")+l11lllll11l1_l1_+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䆵")
				message += l11ll1_l1_ (u"ࠨ࡞ࡱࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࡳࠡࠢࠣࠬࠥࡇࡣࡵ࡫ࡹࡩࠥ࠵ࠠࡎࡣࡻ࡭ࡲࡻ࡭ࠡࠫࠣ࠾ࠥࠦࠧ䆶")+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䆷")+l1l111111111_l1_+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䆸")+max+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆹")
				message += l11ll1_l1_ (u"ࠬࡢ࡮ࡂ࡮࡯ࡳࡼ࡫ࡤࠡࡑࡸࡸࡵࡻࡴࡴ࠼ࠣࠤࠥ࠭䆺")+l11ll1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䆻")+l11ll1_l1_ (u"ࠢࠡ࠮ࠣࠦ䆼").join(dict[l11ll1_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ䆽")][l11ll1_l1_ (u"ࠩࡤࡰࡱࡵࡷࡦࡦࡢࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡶࠫ䆾")])+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䆿")
				message += l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䇀")+l11llllll11l_l1_
				if status==l11ll1_l1_ (u"ࠬࡇࡣࡵ࡫ࡹࡩࠬ䇁"): DIALOG_TEXTVIEWER(l11ll1_l1_ (u"࠭วๅษืฮึอใࠡ์฼้้ࠦศะ๊้ࠤฺ๊วไๆࠪ䇂"),message)
				else: DIALOG_TEXTVIEWER(l11ll1_l1_ (u"๋ࠧสา์ࠥษๆ้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡษ็หูะัศๅࠪ䇃"),message)
	if l1l111lll11l_l1_ and ok and status==l11ll1_l1_ (u"ࠨࡃࡦࡸ࡮ࡼࡥࠨ䇄"):
		LOG_THIS(l11ll1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䇅"),l11ll1_l1_ (u"ࠪ࠲ࠥࠦࠠࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡐ࠷࡚ࠦࡕࡓࡎࠣࠤࠥࡡࠠࡎ࠵ࡘࠤࡦࡩࡣࡰࡷࡱࡸࠥ࡯ࡳࠡࡑࡎࠤࡢࠦࠠࠡ࡝ࠣࠫ䇆")+l1l111lll11l_l1_+l11ll1_l1_ (u"ࠫࠥࡣࠧ䇇"))
		succeeded = True
	else:
		LOG_THIS(l11ll1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䇈"),l11ll1_l1_ (u"࠭ࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡏ࠶࡙࡛ࠥࡒࡍࠢࠣࠤࡠࠦࡄࡰࡧࡶࠤࡳࡵࡴࠡࡹࡲࡶࡰࠦ࡝ࠡࠢࠣ࡟ࠥ࠭䇉")+l1l111lll11l_l1_+l11ll1_l1_ (u"ࠧࠡ࡟ࠪ䇊"))
		if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䇋"),l11ll1_l1_ (u"ࠩࠪ䇌"),l11ll1_l1_ (u"ࠪๅา฻ࠠศึอีฬ้ࠠแࡏ࠶࡙ࠬ䇍"),l11ll1_l1_ (u"ࠫึอศุࠢสุฯืวไࠢใࡑ࠸࡛ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡏ࠶࡙ࠥ๎โๆࠢหษ฻อแสࠢิหอ฽ࠠแࡏ࠶࡙ࠥาฯ๋ัࠣวํࠦโๆࠢหษฺ๊วฮࠢส่ึอศุࠢส่็ี๊ๆࠩ䇎"))
		succeeded = False
	return succeeded,l11lll1l1ll1_l1_,l1l111ll111l_l1_
def ITEMS(l1lll111l11l_l1_,l11llllll1ll_l1_,l1l1111ll11l_l1_,l11lll1ll1ll_l1_,l1ll_l1_=True):
	if not l11lll1ll1ll_l1_: l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ䇏")
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,l1ll_l1_): return
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11llllll1ll_l1_)
	l1ll11lllll1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭࡬ࡪࡵࡷࠫ䇐"),l11llllll1ll_l1_,l1l1111ll11l_l1_)
	end = int(l11lll1ll1ll_l1_)*100
	start = end-100
	for context,title,url,l1lll1_l1_ in l1ll11lllll1_l1_[start:end]:
		l1ll1ll1l1l1_l1_ = (l11ll1_l1_ (u"ࠧࡈࡔࡒ࡙ࡕࡋࡄࠨ䇑") in l11llllll1ll_l1_ or l11llllll1ll_l1_==l11ll1_l1_ (u"ࠨࡃࡏࡐࠬ䇒"))
		l1ll1ll1l111_l1_ = (l11ll1_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡆࡆࠪ䇓") not in l11llllll1ll_l1_ and l11llllll1ll_l1_!=l11ll1_l1_ (u"ࠪࡅࡑࡒࠧ䇔"))
		if l1ll1ll1l1l1_l1_ or l1ll1ll1l111_l1_:
			if   l11ll1_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䇕")  in l11llllll1ll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇖"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䇗"),l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䇘"),l11ll1_l1_ (u"ࠨࠩ䇙"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇚"):l1lll111l11l_l1_}])
			elif l11ll1_l1_ (u"ࠪࡉࡕࡍࠧ䇛") 		 in l11llllll1ll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇜"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠬ࠭䇝"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䇞"),l11ll1_l1_ (u"ࠧࠨ䇟"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇠"):l1lll111l11l_l1_}])
			elif l11ll1_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䇡") in l11llllll1ll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇢"),l111l1_l1_+title,url,718,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䇣"),l11ll1_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ䇤"),l11ll1_l1_ (u"࠭ࠧ䇥"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇦"):l1lll111l11l_l1_}])
			elif l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䇧") 	 in l11llllll1ll_l1_: menuItemsLIST.append([l11ll1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䇨"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠪࠫ䇩"),l11ll1_l1_ (u"ࠫࠬ䇪"),context,{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇫"):l1lll111l11l_l1_}])
			else: menuItemsLIST.append([l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䇬"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䇭"),l11ll1_l1_ (u"ࠨࠩ䇮"),l11ll1_l1_ (u"ࠩࠪ䇯"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇰"):l1lll111l11l_l1_}])
	total = len(l1ll11lllll1_l1_)
	PAGINATION(l1lll111l11l_l1_,l11lll1ll1ll_l1_,l11llllll1ll_l1_,714,total,l1l1111ll11l_l1_)
	return
def SHOW_EMPTY(l11lll11l1l1_l1_):
	addMenuItem(l11ll1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䇱"),l11lll11l1l1_l1_+l11ll1_l1_ (u"ࠬํะ่ࠢส่็อฦๆหࠣษ๊อࠠโษิ฾ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮ࠭䇲"),l11ll1_l1_ (u"࠭ࠧ䇳"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䇴"),l11lll11l1l1_l1_+l11ll1_l1_ (u"ࠨล๋ࠤฬ๊ฮะ็ฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤฬฺสาษๆ็ࠬ䇵"),l11ll1_l1_ (u"ࠩࠪ䇶"),9999)
	addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䇷"),l11lll11l1l1_l1_+l11ll1_l1_ (u"ࠫศ๎ࠠาษห฻ࠥࡓ࠳ࡖโࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ฿๐ัࠡืะ๎า࠭䇸"),l11ll1_l1_ (u"ࠬ࠭䇹"),9999)
	return
def GROUPS(l1lll111l11l_l1_,l11llllll1ll_l1_,l1l1111ll11l_l1_,l11lll1ll1ll_l1_,l1l1l1l1_l1_=l11ll1_l1_ (u"࠭ࠧ䇺"),l1ll_l1_=True):
	if not l11lll1ll1ll_l1_: l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠧ࠲ࠩ䇻")
	l11lll11l1l1_l1_ = l111l1_l1_
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,l1ll_l1_): return False
	if l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䇼") in l1l1111ll11l_l1_: l11lll1lllll_l1_,l11lll111ll1_l1_ = l1l1111ll11l_l1_.split(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䇽"))
	else: l11lll1lllll_l1_,l11lll111ll1_l1_ = l1l1111ll11l_l1_,l11ll1_l1_ (u"ࠪࠫ䇾")
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11llllll1ll_l1_)
	l1l1111111ll_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䇿"),l11llllll1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䈀"))
	if not l1l1111111ll_l1_: return False
	l1l111l11l1l_l1_ = []
	for group,l1lll1_l1_ in l1l1111111ll_l1_:
		if l1l1l1l1_l1_:
			if l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䈁") in group: l11lll11l1l1_l1_ = l11ll1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ䈂")
			elif l11ll1_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪ䈃") in group: l11lll11l1l1_l1_ = l11ll1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䈄")
			elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䈅") in l11llllll1ll_l1_: l11lll11l1l1_l1_ = l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࠩ䈆")
			else: l11lll11l1l1_l1_ = l11ll1_l1_ (u"ࠬ࡜ࡉࡅࡇࡒࡗࠬ䈇")
			l11lll11l1l1_l1_ = l11ll1_l1_ (u"࠭ࠬ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䈈")+l11lll11l1l1_l1_+l11ll1_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䈉")
		if l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䈊") in group: l1l1111l1l1l_l1_,l11ll1ll1ll1_l1_ = group.split(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䈋"))
		else: l1l1111l1l1l_l1_,l11ll1ll1ll1_l1_ = group,l11ll1_l1_ (u"ࠪࠫ䈌")
		if not l1l1111ll11l_l1_:
			if l1l1111l1l1l_l1_ in l1l111l11l1l_l1_: continue
			l1l111l11l1l_l1_.append(l1l1111l1l1l_l1_)
			if l11ll1_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࠫ䈍") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈎"),l11lll11l1l1_l1_+l1l1111l1l1l_l1_,l11llllll1ll_l1_,168,l11ll1_l1_ (u"࠭ࠧ䈏"),l11ll1_l1_ (u"ࠧ࠲ࠩ䈐"),group,l11ll1_l1_ (u"ࠨࠩ䈑"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈒"):l1lll111l11l_l1_})
			elif l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䈓") in group: addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䈔"),l11lll11l1l1_l1_+l1l1111l1l1l_l1_,l11llllll1ll_l1_,713,l11ll1_l1_ (u"ࠬ࠭䈕"),l11ll1_l1_ (u"࠭࠱ࠨ䈖"),group,l11ll1_l1_ (u"ࠧࠨ䈗"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈘"):l1lll111l11l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈙"),l11lll11l1l1_l1_+l1l1111l1l1l_l1_,l11llllll1ll_l1_,714,l11ll1_l1_ (u"ࠪࠫ䈚"),l11ll1_l1_ (u"ࠫ࠶࠭䈛"),group,l11ll1_l1_ (u"ࠬ࠭䈜"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈝"):l1lll111l11l_l1_})
		elif l11ll1_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䈞") in group and l1l1111l1l1l_l1_==l11lll1lllll_l1_:
			if l11ll1ll1ll1_l1_ in l1l111l11l1l_l1_: continue
			l1l111l11l1l_l1_.append(l11ll1ll1ll1_l1_)
			if l11ll1_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࠨ䈟") in l1l1l1l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈠"),l11lll11l1l1_l1_+l11ll1ll1ll1_l1_,l11llllll1ll_l1_,168,l11ll1_l1_ (u"ࠪࠫ䈡"),l11ll1_l1_ (u"ࠫ࠶࠭䈢"),group,l11ll1_l1_ (u"ࠬ࠭䈣"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈤"):l1lll111l11l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䈥"),l11lll11l1l1_l1_+l11ll1ll1ll1_l1_,l11llllll1ll_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"ࠨ࠳ࠪ䈦"),group,l11ll1_l1_ (u"ࠩࠪ䈧"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䈨"):l1lll111l11l_l1_})
	#if l11ll1_l1_ (u"ࠫࡘࡕࡒࡕࡇࡇࠫ䈩") in l11llllll1ll_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1l1l1_l1_:
		end = int(l11lll1ll1ll_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1lll111l11l_l1_,l11lll1ll1ll_l1_,l11llllll1ll_l1_,713,total,l1l1111ll11l_l1_)
	return True
def EPG_ITEMS(l1lll111l11l_l1_,url,function):
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,True): return
	headers = GET_HEADERS(l1lll111l11l_l1_)
	timestamp = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ䈪")+l1lll111l11l_l1_)
	if not timestamp or now-int(timestamp)>24*l11lll11l111_l1_:
		succeeded,l11lll1l1ll1_l1_,l1l111ll111l_l1_ = CHECK_ACCOUNT(l1lll111l11l_l1_,False)
		if not succeeded: return
	l11lll1l111l_l1_ = int(settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ䈫")+l1lll111l11l_l1_))
	server = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ䈬")+l1lll111l11l_l1_)
	username = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡴࡡ࡮ࡧࡢࠫ䈭")+l1lll111l11l_l1_)
	password = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡳࡥࡸࡹࡷࡰࡴࡧࡣࠬ䈮")+l1lll111l11l_l1_)
	l11lll1l1l11_l1_ = url.split(l11ll1_l1_ (u"ࠪ࠳ࠬ䈯"))
	l11ll1lll11l_l1_ = l11lll1l1l11_l1_[-1].replace(l11ll1_l1_ (u"ࠫ࠳ࡺࡳࠨ䈰"),l11ll1_l1_ (u"ࠬ࠭䈱")).replace(l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䈲"),l11ll1_l1_ (u"ࠧࠨ䈳"))
	if function==l11ll1_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ䈴"): l1l111l1l1ll_l1_ = l11ll1_l1_ (u"ࠩࡪࡩࡹࡥࡳࡩࡱࡵࡸࡤ࡫ࡰࡨࠩ䈵")
	else: l1l111l1l1ll_l1_ = l11ll1_l1_ (u"ࠪ࡫ࡪࡺ࡟ࡴ࡫ࡰࡴࡱ࡫࡟ࡥࡣࡷࡥࡤࡺࡡࡣ࡮ࡨࠫ䈶")
	l1l111lll11l_l1_,l11lllll1111_l1_,server,username,password = GET_URL(l1lll111l11l_l1_)
	if not username: return
	l11llll111l1_l1_ = l1l111lll11l_l1_+l11ll1_l1_ (u"ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࠭䈷")+l1l111l1l1ll_l1_+l11ll1_l1_ (u"ࠬࠬࡳࡵࡴࡨࡥࡲࡥࡩࡥ࠿ࠪ䈸")+l11ll1lll11l_l1_
	html = OPENURL_CACHED(NO_CACHE,l11llll111l1_l1_,l11ll1_l1_ (u"࠭ࠧ䈹"),headers,l11ll1_l1_ (u"ࠧࠨ䈺"),l11ll1_l1_ (u"ࠨࡏ࠶࡙࠲ࡋࡐࡈࡡࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬ䈻"))
	l11llllll111_l1_ = EVAL(l11ll1_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䈼"),html)
	l11lll111l11_l1_ = l11llllll111_l1_[l11ll1_l1_ (u"ࠪࡩࡵ࡭࡟࡭࡫ࡶࡸ࡮ࡴࡧࡴࠩ䈽")]
	l11llll1l11l_l1_ = []
	if function in [l11ll1_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䈾"),l11ll1_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ䈿")]:
		for dict in l11lll111l11_l1_:
			if dict[l11ll1_l1_ (u"࠭ࡨࡢࡵࡢࡥࡷࡩࡨࡪࡸࡨࠫ䉀")]==1:
				l11llll1l11l_l1_.append(dict)
				if function in [l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䉁")]: break
		if not l11llll1l11l_l1_: return
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䉂"),l111l1_l1_+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬ๊ๅๅใสฮࠥอไฤ๊็๎ࠥฮ็ั้ࠣห้่วว็ฬࠤ็ีࠠๅษࠣฮ฾๋ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䉃"),l11ll1_l1_ (u"ࠪࠫ䉄"),9999)
		if function in [l11ll1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䉅")]:
			l1l111l1lll1_l1_ = 2
			l11lll111lll_l1_ = l1l111l1lll1_l1_*l11lll11l111_l1_
			l11llll1l11l_l1_ = []
			l1l111ll1lll_l1_ = int(int(dict[l11ll1_l1_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ䉆")])/l11lll111lll_l1_)*l11lll111lll_l1_
			l1l1111l11ll_l1_ = now+l11lll111lll_l1_
			l11ll1llll11_l1_ = int((l1l1111l11ll_l1_-l1l111ll1lll_l1_)/l11lll11l111_l1_)
			for count in range(l11ll1llll11_l1_):
				if count>=6:
					if count%l1l111l1lll1_l1_!=0: continue
					l1l11lll1_l1_ = l11lll111lll_l1_
				else: l1l11lll1_l1_ = l11lll111lll_l1_//2
				l11ll1llllll_l1_ = l1l111ll1lll_l1_+count*l11lll11l111_l1_
				dict = {}
				dict[l11ll1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䉇")] = l11ll1_l1_ (u"ࠧࠨ䉈")
				struct = time.localtime(l11ll1llllll_l1_-l11lll1l111l_l1_-l11lll11l111_l1_)
				dict[l11ll1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䉉")] = time.strftime(l11ll1_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭䉊"),struct)
				dict[l11ll1_l1_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䉋")] = str(l11ll1llllll_l1_)
				dict[l11ll1_l1_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ䉌")] = str(l11ll1llllll_l1_+l1l11lll1_l1_)
				l11llll1l11l_l1_.append(dict)
	elif function in [l11ll1_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ䉍"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䉎")]: l11llll1l11l_l1_ = l11lll111l11_l1_
	if function==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ䉏") and len(l11llll1l11l_l1_)>0:
		addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䉐"),l111l1_l1_+l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึ็ࠡไสส๊ฯࠠษำส้ัࠦวๅไ้์ฬะࠠࠩฮา์้ࠦแใูࠬไࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䉑"),l11ll1_l1_ (u"ࠪࠫ䉒"),9999)
	l11llll11ll1_l1_ = []
	l1lll1_l1_ = xbmc.getInfoLabel(l11ll1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ䉓"))
	for dict in l11llll1l11l_l1_:
		title = base64.b64decode(dict[l11ll1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䉔")])
		if kodi_version>18.99: title = title.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䉕"))
		l11ll1llllll_l1_ = int(dict[l11ll1_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䉖")])
		l1l1111ll1ll_l1_ = int(dict[l11ll1_l1_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䉗")])
		l1l1111l1ll1_l1_ = str(int((l1l1111ll1ll_l1_-l11ll1llllll_l1_+59)/60))
		l1l111lll1ll_l1_ = dict[l11ll1_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ䉘")].replace(l11ll1_l1_ (u"ࠪࠤࠬ䉙"),l11ll1_l1_ (u"ࠫ࠿࠭䉚"))
		struct = time.localtime(l11ll1llllll_l1_-l11lll11l111_l1_)
		l1l11111ll11_l1_ = time.strftime(l11ll1_l1_ (u"ࠬࠫࡈ࠻ࠧࡐࠫ䉛"),struct)
		l1l1111l1lll_l1_ = time.strftime(l11ll1_l1_ (u"࠭ࠥࡢࠩ䉜"),struct)
		if function==l11ll1_l1_ (u"ࠧࡔࡊࡒࡖ࡙ࡥࡅࡑࡉࠪ䉝"): title = l11ll1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䉞")+l1l11111ll11_l1_+l11ll1_l1_ (u"ࠩࠣไࠥ࠭䉟")+title+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䉠")
		elif function==l11ll1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䉡"): title = l1l1111l1lll_l1_+l11ll1_l1_ (u"ࠬࠦࠧ䉢")+l1l11111ll11_l1_+l11ll1_l1_ (u"࠭ࠠࠩࠩ䉣")+l1l1111l1ll1_l1_+l11ll1_l1_ (u"ࠧ࡮࡫ࡱ࠭ࠬ䉤")
		else: title = l1l1111l1lll_l1_+l11ll1_l1_ (u"ࠨࠢࠪ䉥")+l1l11111ll11_l1_+l11ll1_l1_ (u"ࠩࠣࠬࠬ䉦")+l1l1111l1ll1_l1_+l11ll1_l1_ (u"ࠪࡱ࡮ࡴࠩࠡࠢࠣࠫ䉧")+title+l11ll1_l1_ (u"ࠫࠥๆࠧ䉨")
		if function in [l11ll1_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ䉩"),l11ll1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ䉪"),l11ll1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ䉫")]:
			l11lll11111l_l1_ = server+l11ll1_l1_ (u"ࠨ࠱ࡷ࡭ࡲ࡫ࡳࡩ࡫ࡩࡸ࠴࠭䉬")+username+l11ll1_l1_ (u"ࠩ࠲ࠫ䉭")+password+l11ll1_l1_ (u"ࠪ࠳ࠬ䉮")+l1l1111l1ll1_l1_+l11ll1_l1_ (u"ࠫ࠴࠭䉯")+l1l111lll1ll_l1_+l11ll1_l1_ (u"ࠬ࠵ࠧ䉰")+l11ll1lll11l_l1_+l11ll1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䉱")
			if function==l11ll1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ䉲"): addMenuItem(l11ll1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䉳"),l111l1_l1_+title,l11lll11111l_l1_,9999,l1lll1_l1_,l11ll1_l1_ (u"ࠩࠪ䉴"),l11ll1_l1_ (u"ࠪࠫ䉵"),l11ll1_l1_ (u"ࠫࠬ䉶"),{l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉷"):l1lll111l11l_l1_})
			else: addMenuItem(l11ll1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䉸"),l111l1_l1_+title,l11lll11111l_l1_,235,l1lll1_l1_,l11ll1_l1_ (u"ࠧࠨ䉹"),l11ll1_l1_ (u"ࠨࠩ䉺"),l11ll1_l1_ (u"ࠩࠪ䉻"),{l11ll1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉼"):l1lll111l11l_l1_})
		l11llll11ll1_l1_.append(title)
	if function==l11ll1_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ䉽") and l11llll11ll1_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11llll11ll1_l1_)
	return l11llll11ll1_l1_
def USE_FASTER_SERVER(l1lll111l11l_l1_):
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,True): return
	server,l11lll1l1l1l_l1_,l11lll11ll1l_l1_ = l11ll1_l1_ (u"ࠬ࠭䉾"),0,0
	succeeded,l11lll1l1ll1_l1_,l1l111ll111l_l1_ = CHECK_ACCOUNT(l1lll111l11l_l1_,False)
	if succeeded:
		l1l111l1l1l1_l1_ = DNS_RESOLVER(l11lll1l1ll1_l1_)
		l11lll1l1l1l_l1_ = PING(l1l111l1l1l1_l1_[0],int(l1l111ll111l_l1_))
		l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䉿"))
		groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䊀"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䊁"))
		l1ll11lllll1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䊂"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䊃"),groups[1])
		url = l1ll11lllll1_l1_[0][2]
		l1l11111lll1_l1_ = re.findall(l11ll1_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ䊄"),url,re.DOTALL)
		l1l11111lll1_l1_ = l1l11111lll1_l1_[0]
		if l11ll1_l1_ (u"ࠬࡀࠧ䊅") in l1l11111lll1_l1_: l11lllllll11_l1_,l1l111l1111l_l1_ = l1l11111lll1_l1_.split(l11ll1_l1_ (u"࠭࠺ࠨ䊆"))
		else: l11lllllll11_l1_,l1l111l1111l_l1_ = l1l11111lll1_l1_,l11ll1_l1_ (u"ࠧ࠹࠲ࠪ䊇")
		l11ll1llll1l_l1_ = DNS_RESOLVER(l11lllllll11_l1_)
		l11lll11ll1l_l1_ = PING(l11ll1llll1l_l1_[0],int(l1l111l1111l_l1_))
	if l11lll1l1l1l_l1_ and l11lll11ll1l_l1_:
		message = l11ll1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊รึๆํࠤศ๋ࠠศๆึ๎ึ็ัࠡษ็วุืูࠡมࠤࠥࠬ䊈")
		message += l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䊉")+l11ll1_l1_ (u"ࠪ์็ะࠠืษษ฽ࠥ็๊ࠡษ็ื๏ืแาࠢส่ศ฻ไ๋ࠩ䊊")+l11ll1_l1_ (u"ࠫࡡࡴࠧ䊋")+str(int(l11lll11ll1l_l1_*1000))+l11ll1_l1_ (u"ࠬࠦๅๅ์ࠣฯฬ์๊สࠩ䊌")
		message += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱࠫ䊍")+l11ll1_l1_ (u"้ࠧไอࠤ฻อฦฺࠢไ๎ࠥอไิ์ิๅึࠦวๅสา๎้࠭䊎")+l11ll1_l1_ (u"ࠨ࡞ࡱࠫ䊏")+str(int(l11lll1l1l1l_l1_*1000))+l11ll1_l1_ (u"้้ࠩࠣ๐ࠠฬษ้๎ฮ࠭䊐")
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䊑"),l11ll1_l1_ (u"ࠫฬ๊ำ๋ำไีࠥอไฤื็๎ࠬ䊒"),l11ll1_l1_ (u"ࠬอไิ์ิๅึࠦวๅลึี฾࠭䊓"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䊔"),message)
		if l1ll111ll1_l1_==1 and l11lll1l1l1l_l1_<l11lll11ll1l_l1_: server = l11lll1l1ll1_l1_+l11ll1_l1_ (u"ࠧ࠻ࠩ䊕")+l1l111ll111l_l1_
	else: DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䊖"),l11ll1_l1_ (u"ࠩࠪ䊗"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䊘"),l11ll1_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํะิࠦวๅีํีๆืࠠศๆหำ๏๊ࠧ䊙"))
	settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭䊚")+l1lll111l11l_l1_,server)
	return
def PLAY(l1lll111l11l_l1_,url,type):
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䊛")+l1lll111l11l_l1_)
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ䊜")+l1lll111l11l_l1_)
	if l111lll1ll_l1_ or l11l111lll_l1_:
		url += l11ll1_l1_ (u"ࠨࡾࠪ䊝")
		if l111lll1ll_l1_: url += l11ll1_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ䊞")+l111lll1ll_l1_
		if l11l111lll_l1_: url += l11ll1_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䊟")+l11l111lll_l1_
		url = url.replace(l11ll1_l1_ (u"ࠫࢁࠬࠧ䊠"),l11ll1_l1_ (u"ࠬࢂࠧ䊡"))
	#l1111l1l11_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ䊢")+l1lll111l11l_l1_)
	#if l1111l1l11_l1_:
	#	l1l111111l1l_l1_ = re.findall(l11ll1_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ䊣"),url,re.DOTALL)
	#	url = url.replace(l1l111111l1l_l1_[0],l1111l1l11_l1_)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(l1lll111l11l_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠨࠩ䊤"),l11ll1_l1_ (u"ࠩࠪ䊥"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䊦"),l11ll1_l1_ (u"ࠫฯำะ๋ำ้ࠣ์๋้้ࠠส้ࠥาฯศࠢ࠱ࠤ๏ืฬ๊ࠢ฼ำ๊ࠦส฻์ํี์ࠦลัษࠣ็๋ะࠠๅษࠣฮ฾ืแࠡ็สࠤ์๎ࠠ࠯ࠢࠣ์฾ีๅࠡฬ฽๎๏ื็ࠡว็หࠥ฿ๆะࠢส่฻ื่าหࠣห้่ี้๋ࠣ࠲ࠥอไฮษฯอ๊ࠥ็ัษࠣห้ะฺ๋์ิࠤ์๐ࠠโไฺࠤสึวูࠡ็ฬฯࠦๅ็ๅุࠣึ้ษࠡโࡐ࠷࡚ࠦร็ࠢอ฽๊๊่ࠠาสࠤฬ๊ส฻์ํีࠥ࠴้ࠠใๅ฻ࠥ฿ๆะ็สࠤฯูสฯั่ࠤำีๅสࠢใࡑ࠸࡛ࠠหฯอหัࠦเࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤำอีࠨ䊧"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䊨")+l1lll111l11l_l1_)
	l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䊩"),l11ll1_l1_ (u"ࠧศีอาิอๅࠡษ็วฺ๊๊ࠨ䊪"),l11ll1_l1_ (u"ࠨฬ฼ำ๏๊ࠠศๆๅำ๏๋ࠧ䊫"),l111lll1ll_l1_,l11ll1_l1_ (u"๊ࠩิฬࠦ็้ࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠศๆ่ืฯิฯๆࠢะห้๐วࠡ็฼ࠤๅࡓ࠳ࡖࠢส่ี๐ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะูะ์็๋ࠥษๅࠡฬิ๎ิࠦลฺษาฮ์ࠦลๅ๋ࠣ์฻฿๊สࠢส่ฯัศ๋ฬࠣห้ษีๅ์ࠣ์ฬ๊ส๋ࠢอๆึ๐ศศࠢอ๊ฬูศࠡฮ่๎฾ࠦิาๅสฮࠥๆࡍ࠴ࡗࠣรࠦ࠭䊬"))
	if l111l11lll1_l1_==1: l111lll1ll_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠪว่ะศࠡโࡐ࠷࡚ࠦࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣะิ๐ฯࠨ䊭"),l111lll1ll_l1_,True)
	else: l111lll1ll_l1_ = l11ll1_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ䊮")
	if l111lll1ll_l1_==l11ll1_l1_ (u"ࠬࠦࠧ䊯"):
		DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䊰"),l11ll1_l1_ (u"ࠧࠨ䊱"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䊲"),l11ll1_l1_ (u"ࠩ฽๎ึࠦๅิ็๋ัࠥษำหะาห๊ࠦแาษ฽ࠤ้๎อะ้ࠣวํูࠦะหࠣๅึอฺศฬ่ࠣํำฯ่ษࠣ࠲࠳࠴๋ࠠฮหࠤส๋วࠡฬิ็์ࠦแศำ฽ࠤฯ๋วๆษࠣวํࠦลืษไอࠥำัโࠢฦ์ࠥษ๊ࠡึํࠤวิัࠡ็฼๋ฬ࠭䊳"))
		return
	l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䊴"),l11ll1_l1_ (u"ࠫࠬ䊵"),l11ll1_l1_ (u"ࠬ࠭䊶"),l111lll1ll_l1_,l11ll1_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅ้ࠡำหࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣฬิ๊วࠡ็้ࠤࠥอไใัํ้ࠥลࠧ䊷"))
	if l111l11lll1_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䊸"),l11ll1_l1_ (u"ࠨࠩ䊹"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䊺"),l11ll1_l1_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧ䊻"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ䊼")+l1lll111l11l_l1_,l111lll1ll_l1_)
	#l1l1111ll111_l1_(l1lll111l11l_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_)
	return
def ADD_REFERER(l1lll111l11l_l1_):
	DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䊽"),l11ll1_l1_ (u"࠭ࠧ䊾"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䊿"),l11ll1_l1_ (u"ࠨฬะิ๏ืࠠๆ้่ࠤํํวๆࠢฯำฬࠦ࠮ࠡ์ิะ๎ูࠦะ็ࠣฮ฿๐๊า้ࠣษีอࠠไ่อࠤ้อࠠห฻ิๅ๋ࠥว้๋ࠡࠤ࠳้ࠦࠠ฻า้ࠥะฺ๋์ิ๋ࠥหไศࠢ฼๊ิࠦวๅุิ์ึฯࠠศๆๅูํ๏ࠠ࠯ࠢส่าอฬสࠢ็๋ีอࠠศๆอ฾๏๐ั้ࠡํࠤๆ่ืࠡวำหࠥ฽ไษฬ้๋้ࠣࠠีำๆอࠥๆࡍ࠴ࡗࠣว๋ࠦสฺ็็ࠤ์ึวࠡษ็ฮ฿๐๊าࠢ࠱ࠤํ็โุࠢ฼๊ิ๋วࠡฬึฮำีๅࠡะา้ฮࠦเࡎ࠵ࡘࠤฯำสศฮࠣไࡗ࡫ࡦࡦࡴࡨࡶࠥิวึࠩ䋀"))
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫ䋁")+l1lll111l11l_l1_)
	l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䋂"),l11ll1_l1_ (u"ࠫฬูสฯัส้ࠥอไฤื็๎ࠬ䋃"),l11ll1_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ䋄"),l11l111lll_l1_,l11ll1_l1_ (u"࠭็ัษ๋ࠣํࠦเࡓࡧࡩࡩࡷ࡫ࡲࠡษ็ุ้ะฮะ็ࠣัฬ๊๊ศ่ࠢ฽ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦสฺัํ่์ࠦรๆࠢอี๏ีࠠฦ฻สำฯํࠠฦๆ์ࠤํ฼ู๋หࠣห้ะหษ์อࠤฬ๊รึๆํࠤํอไห์ࠣฮ็ื๊ษษࠣฮ๋อำษࠢฯ้๏฿ࠠีำๆหฯࠦเࡎ࠵ࡘࠤฤࠧࠧ䋅"))
	if l111l11lll1_l1_==1: refererr = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠧฤๅอฬࠥๆࡍ࠴ࡗࠣࡖࡪ࡬ࡥࡳࡧࡵࠤัี๊ะࠩ䋆"),l11l111lll_l1_,True)
	else: l11l111lll_l1_ = l11ll1_l1_ (u"ࠨࠩ䋇")
	if l11l111lll_l1_==l11ll1_l1_ (u"ࠩࠣࠫ䋈"):
		DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䋉"),l11ll1_l1_ (u"ࠫࠬ䋊"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䋋"),l11ll1_l1_ (u"ฺ๋࠭ำุ้๋่ࠣฮࠢฦืฯิฯศ็ࠣๅึอฺࠡๆ๋ัิํࠠฤ๊ࠣ฽ิฯࠠโำส฾ฬะࠠๅ๊ะำ์อࠠ࠯࠰࠱ࠤ๏าศࠡว่หࠥะัไ้ࠣๅฬืฺࠡฬ่ห๊อࠠฤ๊ࠣษ฻อแสࠢะีๆࠦร้ࠢฦ๎ฺ๊ࠥࠡฤัีู๋่ࠥษࠪ䋌"))
		return
	l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䋍"),l11ll1_l1_ (u"ࠨࠩ䋎"),l11ll1_l1_ (u"ࠩࠪ䋏"),l11l111lll_l1_,l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥํะศࠢใࡖࡪ࡬ࡥࡳࡧࡵࠤอีไศ่๊ࠢࠥࠦวๅไา๎๊ࠦฟࠨ䋐"))
	if l111l11lll1_l1_!=1:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䋑"),l11ll1_l1_ (u"ࠬ࠭䋒"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䋓"),l11ll1_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ䋔"))
		return
	settings.setSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ䋕")+l1lll111l11l_l1_,l11l111lll_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_)
	return
def GET_URL(l1lll111l11l_l1_,l11lll111l1l_l1_=l11ll1_l1_ (u"ࠩࠪ䋖")):
	if not l11lll111l1l_l1_: l11lll111l1l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䋗")+l1lll111l11l_l1_)
	server = SERVER(l11lll111l1l_l1_,l11ll1_l1_ (u"ࠫࡺࡸ࡬ࠨ䋘"))
	username = re.findall(l11ll1_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ䋙"),l11lll111l1l_l1_+l11ll1_l1_ (u"࠭ࠦࠨ䋚"),re.DOTALL)
	password = re.findall(l11ll1_l1_ (u"ࠧࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠩ䋛"),l11lll111l1l_l1_+l11ll1_l1_ (u"ࠨࠨࠪ䋜"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䋝"),l11ll1_l1_ (u"ࠪࠫ䋞"),l11ll1_l1_ (u"ࠫๆำีࠡษืฮึอใࠡโࡐ࠷࡚࠭䋟"),l11ll1_l1_ (u"ࠬืวษูࠣหูะัศๅࠣไࡒ࠹ࡕࠡษ็ิ๏ࠦโๆฬࠣห๋ะࠠษวูหๆะ็ࠡว็ํࠥอไษำ้ห๊าࠠๅษࠣ๎฾๋ไࠡล๋ࠤฬ๊ัศสฺࠤ฿๐ัࠡ็๋ะํีࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴ࠠฤา๊ฬࠥหไ๊ࠢๅหห๋ษࠡษืฮึอใࠡโࡐ࠷่࡚ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡐ࠷࡚ࠦฬะ์าࠤศ๎ࠠใ็ࠣฬส฻ไศฯࠣห้ืวษูࠣห้่ฯ๋็ࠪ䋠"))
		return l11ll1_l1_ (u"࠭ࠧ䋡"),l11ll1_l1_ (u"ࠧࠨ䋢"),l11ll1_l1_ (u"ࠨࠩ䋣"),l11ll1_l1_ (u"ࠩࠪ䋤"),l11ll1_l1_ (u"ࠪࠫ䋥")
	username = username[0]
	password = password[0]
	l1l111lll11l_l1_ = server+l11ll1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻࡨࡶࡤࡧࡰࡪ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ䋦")+username+l11ll1_l1_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ䋧")+password
	l11lllll1111_l1_ = server+l11ll1_l1_ (u"࠭࠯ࡨࡧࡷ࠲ࡵ࡮ࡰࡀࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠫ䋨")+username+l11ll1_l1_ (u"ࠧࠧࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠫ䋩")+password+l11ll1_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࡮࠵ࡸࡣࡵࡲࡵࡴࠩ䋪")
	return l1l111lll11l_l1_,l11lllll1111_l1_,server,username,password
def GET_FILENAME(l1lll111l11l_l1_,l1l111l1l11l_l1_=l11ll1_l1_ (u"ࠩࠪ䋫")):
	l11lllllllll_l1_ = l1l111l1l11l_l1_.replace(l11ll1_l1_ (u"ࠪ࠳ࠬ䋬"),l11ll1_l1_ (u"ࠫࡤ࠭䋭")).replace(l11ll1_l1_ (u"ࠬࡀࠧ䋮"),l11ll1_l1_ (u"࠭࡟ࠨ䋯")).replace(l11ll1_l1_ (u"ࠧ࠯ࠩ䋰"),l11ll1_l1_ (u"ࠨࡡࠪ䋱"))
	l11lllllllll_l1_ = l11lllllllll_l1_.replace(l11ll1_l1_ (u"ࠩࡂࠫ䋲"),l11ll1_l1_ (u"ࠪࡣࠬ䋳")).replace(l11ll1_l1_ (u"ࠫࡂ࠭䋴"),l11ll1_l1_ (u"ࠬࡥࠧ䋵")).replace(l11ll1_l1_ (u"࠭ࠦࠨ䋶"),l11ll1_l1_ (u"ࠧࡠࠩ䋷"))
	l11lllllllll_l1_ = os.path.join(addoncachefolder,l11lllllllll_l1_).strip(l11ll1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠭䋸"))+l11ll1_l1_ (u"ࠩ࠱ࡱ࠸ࡻࠧ䋹")
	return l11lllllllll_l1_
def ADD_ACCOUNT(l1lll111l11l_l1_,l111l1ll_l1_):
	l1l1111l11l1_l1_ = l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䋺")
	if l111l1ll_l1_: l1l1111l11l1_l1_ = l11ll1_l1_ (u"ࠫส฼วโหࠣ์ฯเ๊๋ำࠣีฬฮืࠡࠩ䋻")+text_numbers[int(l111l1ll_l1_)]
	l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䋼"),l11ll1_l1_ (u"࠭ࠧ䋽"),l11ll1_l1_ (u"ࠧࠨ䋾"),l1l1111l11l1_l1_,l11ll1_l1_ (u"ࠨ้ำหࠥอไอิฤࠤ๊์ࠠศๆหี๋อๅอࠢํัฯอฬࠡำสฬ฼ࠦแ๋ัํ์์อสࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦร้ࠢฦุฯืวไ่ࠢำๆ๎ูࠡ็้ࠤฬ๊ิาๅสฮࠥอไห์ࠣฮอ๐ู่๋ࠢห้ืวษู้๋ࠣࠦๆ้฻ࠣࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞࡯࠶ࡹࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤํํะศ่ࠢฯฬ๊ࠠๅฬฺ๋๏ำࠠีๅ็ࠤ์ึวࠡษ็ีฬฮืࠡ࡞ࡱࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡰࡵࡸ࠰ࡳࡷ࡭࠮ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡪࡱ࠲࡭ࡵࡺࡶ࠰࡮ࡤࡲ࡬ࡻࡡࡨࡧࡶ࠳ࡦࡸࡡ࠯࡯࠶ࡹࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢศฺฬ็ษࠡล๋ࠤฯเ๊๋ำࠣวํࠦๅิฯࠣห้ืวษูࠣห้ศๆࠡมࠪ䋿"))
	if l111l11lll1_l1_!=1: return
	l1l111l11ll1_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ䌀")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䌁")+l111l1ll_l1_)
	l11lll11l11l_l1_ = True
	if l1l111l11ll1_l1_:
		l111l11lll1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䌂"),l11ll1_l1_ (u"้ࠬสศสฬࠤัี๊ะࠩ䌃"),l11ll1_l1_ (u"࠭สฺัํ่ࠥอไใัํ้ࠬ䌄"),l11ll1_l1_ (u"ࠧๆีะࠤฬ๊โะ์่ࠫ䌅"),l11ll1_l1_ (u"ࠨษ็ีฬฮืࠡษ็ัฬ๊๊้๋ࠡ࠾ࠬ䌆"),l11ll1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䌇")+l1l111l11ll1_l1_+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䌈")+l11ll1_l1_ (u"ࠫࡡࡴ࡜࡯๊ࠢิฬࠦ็้ࠢิหอ฽ࠠแࡏ࠶࡙ࠥอไๆีฯ่ࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬ฼ำ๏๊็ࠡล่ࠤฯื๊ะࠢๆฮฬฮษࠡำสฬ฼ࠦฬะ์าࠤฤࠧࠧ䌉"))
		if l111l11lll1_l1_==-1: return
		elif l111l11lll1_l1_==0: l1l111l11ll1_l1_ = l11ll1_l1_ (u"ࠬ࠭䌊")
		elif l111l11lll1_l1_==2:
			l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䌋"),l11ll1_l1_ (u"ࠧࠨ䌌"),l11ll1_l1_ (u"ࠨࠩ䌍"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䌎"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡษ็ีฬฮืࠡษ็ุ้าไࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠩ䌏"))
			if l111l11lll1_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䌐"),l11ll1_l1_ (u"ࠬ࠭䌑"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䌒"),l11ll1_l1_ (u"ࠧห็ุ้ࠣำࠠศๆิหอ฽ࠧ䌓"))
			l11lll11l11l_l1_ = False
			l11llll11lll_l1_ = l11ll1_l1_ (u"ࠨࠩ䌔")
	if l11lll11l11l_l1_:
		l11llll11lll_l1_ = OPEN_KEYBOARD(l11ll1_l1_ (u"ࠩส็ฯฮࠠาษห฻ࠥๆࡍ࠴ࡗࠣ็ฬ๋ไศࠩ䌕"),l1l111l11ll1_l1_)
		l11llll11lll_l1_ = l11llll11lll_l1_.strip(l11ll1_l1_ (u"ࠪࠤࠬ䌖"))
		if not l11llll11lll_l1_:
			l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䌗"),l11ll1_l1_ (u"ࠬ࠭䌘"),l11ll1_l1_ (u"࠭ࠧ䌙"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䌚"),l11ll1_l1_ (u"ࠨๆๅำ่ࠥๅหࠢหษิิวๅࠢิหอ฽ࠠโษิ฾ࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦวๅำสฬ฼ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ䌛"))
			if l111l11lll1_l1_ in [-1,0]: return
			DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䌜"),l11ll1_l1_ (u"ࠪࠫ䌝"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䌞"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥอไาษห฻ࠬ䌟"))
		else:
			#l1l111lll11l_l1_,l11lllll1111_l1_,server,username,password = GET_URL(l1lll111l11l_l1_)
			#if not username: return
			message = l11ll1_l1_ (u"࠭็ั้ࠣหู้๋ๅ๊่หฯࠦสๆࠢฦาีํวࠡ็้ࠤึอศุࠢใࡑ࠸࡛ࠠศๆำ๎ࠥอๆหࠢๆฮอะ็ࠡ࠰๋้ࠣࠦสา์าࠤฬูสฯัส้์อࠠภࠣ࡟ࡲࠬ䌠")
			#message += l11ll1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䌡")+server+l11ll1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟฼๊ํอๆࠡษ็ื๏ืแา࠼ࠣࠫ䌢")
			#message += l11ll1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䌣")+username+l11ll1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡฬูๅࠡษ็ุ้ะฮะ็࠽ࠤࠬ䌤")
			#message += l11ll1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䌥")+password+l11ll1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣใๅ็ฬࠤฬ๊ำา࠼ࠣࠫ䌦")
			l111l11lll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࠧ䌧"),l11ll1_l1_ (u"ࠧࠨ䌨"),l11ll1_l1_ (u"ࠨࠩ䌩"),l11ll1_l1_ (u"ࠩส่ึอศุࠢส่ัี๊ะ๊ࠢ์࠿࠭䌪"),l11ll1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䌫")+l11llll11lll_l1_+l11ll1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䌬")+l11ll1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䌭")+message)
			if l111l11lll1_l1_!=1:
				DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䌮"),l11ll1_l1_ (u"ࠧࠨ䌯"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌰"),l11ll1_l1_ (u"ࠩอ้ࠥอไฦๆ฽หฦ࠭䌱"))
				return
	settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䌲")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䌳")+l111l1ll_l1_,l11llll11lll_l1_)
	#settings.setSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ䌴")+l1lll111l11l_l1_,l11ll1_l1_ (u"࠭ࠧ䌵"))
	#settings.setSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡩ࡯ࡦࡧࡡࠪ䌶")+l1lll111l11l_l1_,l11ll1_l1_ (u"ࠨࠩ䌷"))
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭䌸")+l1lll111l11l_l1_)
	if not l111lll1ll_l1_: settings.setSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ䌹")+l1lll111l11l_l1_,l11ll1_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ䌺"))
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䌻"),l11ll1_l1_ (u"࠭ࠧ䌼"),l11ll1_l1_ (u"ࠧࠨ䌽"),l11ll1_l1_ (u"ࠨࠩ䌾"),l11llll11lll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࡡࡴสๆࠢอ฾๏ืࠠาษห฻ࠥอิหำส็ࠥๆࡍ࠴ࡗࠣษ้๏่ࠠาสࠤฬ๊ัศสฺࠤฬ๊ฬะ์าࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢไัฺࠦ็ัษࠣห้ืวษูࠣห้ศๆࠡมࠪ䌿"))
	#if l1ll111ll1_l1_==1: ok,l11lll1l1ll1_l1_,l1l111ll111l_l1_ = CHECK_ACCOUNT(l1lll111l11l_l1_,True)
	#l1l1111ll111_l1_(l1lll111l11l_l1_)
	DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_)
	return
def READ_ALL_LINES(lines,l1l111l1l111_l1_,l11lllllll1l_l1_,l11l1l1lll_l1_,length,l1ll1l111ll1_l1_,l11lllll1111_l1_):
	l1ll11lllll1_l1_,l11lll1111ll_l1_ = [],[]
	l11lll11lll1_l1_ = [l11ll1_l1_ (u"ࠪ࠲ࡦࡼࡩࠨ䍀"),l11ll1_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䍁"),l11ll1_l1_ (u"ࠬ࠴࡭࡬ࡸࠪ䍂"),l11ll1_l1_ (u"࠭࠮ࡧ࡮ࡹࠫ䍃"),l11ll1_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ䍄"),l11ll1_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ䍅")]
	for line in lines:
		if l1ll1l111ll1_l1_%473==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,40+int(10*l1ll1l111ll1_l1_/length),l11ll1_l1_ (u"ࠩๅีฬวษࠡษ็ๅ๏ี๊้้สฮࠬ䍆"),l11ll1_l1_ (u"ࠪห้็๊ะ์๋ࠤึ่ๅ࠻࠯ࠪ䍇"),str(l1ll1l111ll1_l1_)+l11ll1_l1_ (u"ࠫࠥ࠵ࠠࠨ䍈")+str(length))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None,None
		url = re.findall(l11ll1_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡡࡴࠫࠩࠪ࡫ࡸࡹࡶࡼࡩࡶࡷࡴࡸࢂࡲࡵ࡯ࡳ࠭࠳࠰࠿ࠪࠦࠪ䍉"),line,re.DOTALL)
		if url:
			line,url,dummy = url[0]
			url = url.replace(l11ll1_l1_ (u"࠭࡜࡯ࠩ䍊"),l11ll1_l1_ (u"ࠧࠨ䍋"))
			line = line.replace(l11ll1_l1_ (u"ࠨ࡞ࡱࠫ䍌"),l11ll1_l1_ (u"ࠩࠪ䍍"))
		else:
			l11lll1111ll_l1_.append({l11ll1_l1_ (u"ࠪࡰ࡮ࡴࡥࠨ䍎"):line})
			continue
		l1l1111l1111_l1_,context,group,title,type,l1l11111l11l_l1_ = {},l11ll1_l1_ (u"ࠫࠬ䍏"),l11ll1_l1_ (u"ࠬ࠭䍐"),l11ll1_l1_ (u"࠭ࠧ䍑"),l11ll1_l1_ (u"ࠧࠨ䍒"),False
		try:
			line,title = line.rsplit(l11ll1_l1_ (u"ࠨࠤ࠯ࠫ䍓"),1)
			line = line+l11ll1_l1_ (u"ࠩࠥࠫ䍔")
		except:
			try: line,title = line.rsplit(l11ll1_l1_ (u"ࠪ࠵࠱࠭䍕"),1)
			except: title = l11ll1_l1_ (u"ࠫࠬ䍖")
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬࡻࡲ࡭ࠩ䍗")] = url
		params = re.findall(l11ll1_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䍘"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11ll1_l1_ (u"ࠧࠣࠩ䍙"),l11ll1_l1_ (u"ࠨࠩ䍚")).strip(l11ll1_l1_ (u"ࠩࠣࠫ䍛"))
			l1l1111l1111_l1_[key] = value.strip(l11ll1_l1_ (u"ࠪࠤࠬ䍜"))
		keys = list(l1l1111l1111_l1_.keys())
		if not title:
			if l11ll1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䍝") in keys and l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䍞")]: title = l1l1111l1111_l1_[l11ll1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䍟")]
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䍠")] = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ䍡")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䍢"),l11ll1_l1_ (u"ࠪࠤࠬ䍣")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䍤"),l11ll1_l1_ (u"ࠬࠦࠧ䍥"))
		if l11ll1_l1_ (u"࠭࡬ࡰࡩࡲࠫ䍦") in keys:
			l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡪ࡯ࡪࠫ䍧")] = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭䍨")]
			del l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩ࡯ࡳ࡬ࡵࠧ䍩")]
		else: l1l1111l1111_l1_[l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ䍪")] = l11ll1_l1_ (u"ࠫࠬ䍫")
		if l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ䍬") in keys and l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䍭")]: group = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭䍮")]
		if any(value in url.lower() for value in l11lll11lll1_l1_): l1l11111l11l_l1_ = True
		if l1l11111l11l_l1_ or l11ll1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ䍯") in group or l11ll1_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭䍰") in group:
			type = l11ll1_l1_ (u"࡚ࠪࡔࡊࠧ䍱")
			if l11ll1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䍲") in group: type = type+l11ll1_l1_ (u"ࠬࡥࡓࡆࡔࡌࡉࡘ࠭䍳")
			elif l11ll1_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ䍴") in group: type = type+l11ll1_l1_ (u"ࠧࡠࡏࡒ࡚ࡎࡋࡓࠨ䍵")
			else: type = type+l11ll1_l1_ (u"ࠨࡡࡘࡒࡐࡔࡏࡘࡐࠪ䍶")
			group = group.replace(l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䍷"),l11ll1_l1_ (u"ࠪࠫ䍸")).replace(l11ll1_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ䍹"),l11ll1_l1_ (u"ࠬ࠭䍺"))
		else:
			type = l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䍻")
			if title in l1l111l1l111_l1_: context = context+l11ll1_l1_ (u"ࠧࡠࡇࡓࡋࠬ䍼")
			if title in l11lllllll1l_l1_: context = context+l11ll1_l1_ (u"ࠨࡡࡄࡖࡈࡎࡉࡗࡇࡇࠫ䍽")
			if not group: type = type+l11ll1_l1_ (u"ࠩࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ䍾")
			else: type = type+context
		group = group.strip(l11ll1_l1_ (u"ࠪࠤࠬ䍿")).replace(l11ll1_l1_ (u"ࠫࠥࠦࠧ䎀"),l11ll1_l1_ (u"ࠬࠦࠧ䎁")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䎂"),l11ll1_l1_ (u"ࠧࠡࠩ䎃"))
		if l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔࠧ䎄") in type: group = l11ll1_l1_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡍࡋ࡙ࡉࡤࡥࠡࠢࠩ䎅")
		elif l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࠨ䎆") in type: group = l11ll1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡ࡙ࡓࡉࡥ࡟ࠢࠣࠪ䎇")
		elif l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࠩ䎈") in type:
			l1l111l11l11_l1_ = re.findall(l11ll1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥࡡࡓࡴ࡟࡟ࡨ࠰ࠦࠫ࡜ࡇࡨࡡࡡࡪࠫࠨ䎉"),l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䎊")],re.DOTALL)
			if l1l111l11l11_l1_: l1l111l11l11_l1_ = l1l111l11l11_l1_[0]
			else: l1l111l11l11_l1_ = l11ll1_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠢࠣࠪ䎋")
			group = group+l11ll1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䎌")+l1l111l11l11_l1_
		l11lll1l11_l1_ = l11ll1_l1_ (u"ࠪࠫ䎍")
		if l11ll1_l1_ (u"ࠫ࡮ࡪࠧ䎎") in keys:
			l11lll1l11_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬ࡯ࡤࠨ䎏")]
			del l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡩࡥࠩ䎐")]
		if l11ll1_l1_ (u"ࠧࡊࡆࠪ䎑") in keys:
			l11lll1l11_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠨࡋࡇࠫ䎒")]
			del l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩࡌࡈࠬ䎓")]
		if l11ll1_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮ࡱࡵ࡫ࠬ䎔") in l11lllll1111_l1_ and l11ll1_l1_ (u"ࠫ࠳࠭䎕") in l11lll1l11_l1_:
			l11lll1l11_l1_ = l11lll1l11_l1_.rsplit(l11ll1_l1_ (u"ࠬ࠴ࠧ䎖"),1)[1]
			l11lll1l11_l1_ = l11ll1_l1_ (u"࠭ࡼࠨ䎗")+l11lll1l11_l1_.upper()+l11ll1_l1_ (u"ࠧࡽࠢࠪ䎘")
		if l11ll1_l1_ (u"ࠨࡰࡤࡱࡪ࠭䎙") in keys: del l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䎚")]
		title = l11lll1l11_l1_+l1l1111l1111_l1_[l11ll1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䎛")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l1ll1l1111l1_l1_,title = SPLIT_NAME(title)
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䎜")] = type
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭䎝")] = context
		l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䎞")] = group.upper()
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䎟")] = title.upper()
		try: l1l1111l1111_l1_[l11ll1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ䎠")] = COUNTRIES_CODES[l1ll1l1111l1_l1_.upper()]
		except: l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ䎡")] = l1ll1l1111l1_l1_.upper()
		#dictt1[l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䎢")] = countryy.upper()
		l1l1111l1111_l1_[l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䎣")] = language.upper()
		l1ll11lllll1_l1_.append(l1l1111l1111_l1_)
		l1ll1l111ll1_l1_ += 1
	return l1ll11lllll1_l1_,l1ll1l111ll1_l1_,l11lll1111ll_l1_
def CLEAN_NAME(title):
	title = title.replace(l11ll1_l1_ (u"ࠬࠦࠠࠨ䎤"),l11ll1_l1_ (u"࠭ࠠࠨ䎥")).replace(l11ll1_l1_ (u"ࠧࠡࠢࠪ䎦"),l11ll1_l1_ (u"ࠨࠢࠪ䎧")).replace(l11ll1_l1_ (u"ࠩࠣࠤࠬ䎨"),l11ll1_l1_ (u"ࠪࠤࠬ䎩"))
	title = title.replace(l11ll1_l1_ (u"ࠫࢁࢂࠧ䎪"),l11ll1_l1_ (u"ࠬࢂࠧ䎫")).replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ䎬"),l11ll1_l1_ (u"ࠧ࠻ࠩ䎭")).replace(l11ll1_l1_ (u"ࠨ࠯࠰ࠫ䎮"),l11ll1_l1_ (u"ࠩ࠰ࠫ䎯"))
	title = title.replace(l11ll1_l1_ (u"ࠪ࡟ࡠ࠭䎰"),l11ll1_l1_ (u"ࠫࡠ࠭䎱")).replace(l11ll1_l1_ (u"ࠬࡣ࡝ࠨ䎲"),l11ll1_l1_ (u"࠭࡝ࠨ䎳"))
	title = title.replace(l11ll1_l1_ (u"ࠧࠩࠪࠪ䎴"),l11ll1_l1_ (u"ࠨࠪࠪ䎵")).replace(l11ll1_l1_ (u"ࠩࠬ࠭ࠬ䎶"),l11ll1_l1_ (u"ࠪ࠭ࠬ䎷"))
	title = title.replace(l11ll1_l1_ (u"ࠫࡁࡂࠧ䎸"),l11ll1_l1_ (u"ࠬࡂࠧ䎹")).replace(l11ll1_l1_ (u"࠭࠾࠿ࠩ䎺"),l11ll1_l1_ (u"ࠧ࠿ࠩ䎻"))
	title = title.strip(l11ll1_l1_ (u"ࠨࠢࠪ䎼"))
	return title
def CREATE_GROUPED_STREAMS(l11llll1l1l1_l1_,l11l1l1lll_l1_,l111l1ll_l1_):
	l11llllllll1_l1_ = {}
	for l11lll111_l1_ in l11lllll11ll_l1_: l11llllllll1_l1_[l11lll111_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䎽")+l111l1ll_l1_] = []
	length = len(l11llll1l1l1_l1_)
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l111ll1_l1_ = 0
	l11lll1111ll_l1_ = []
	for l1l1111l1111_l1_ in l11llll1l1l1_l1_:
		if l1ll1l111ll1_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,50+int(5*l1ll1l111ll1_l1_/length),l11ll1_l1_ (u"ࠪฮฺ์๊โࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ฼ํี๋ࠥัหสฬࠫ䎾"),l11ll1_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ䎿"),str(l1ll1l111ll1_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䏀")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		group,context,title,url,l1lll1_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ䏁")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ䏂")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䏃")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩࡸࡶࡱ࠭䏄")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ䏅")]
		l1ll1l1111l1_l1_,language,l11lll111_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ䏆")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ䏇")],l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡴࡺࡲࡨࠫ䏈")]
		l1l1111lllll_l1_ = (group,context,title,url,l1lll1_l1_)
		l1lll1l111l_l1_ = False
		if l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䏉") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ䏊") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䏋")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			elif l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䏌") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䏍")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			else: l1lll1l111l_l1_ = True
			l11llllllll1_l1_[l11ll1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䏎")+l111l1ll_l1_].append(l1l1111lllll_l1_)
		elif l11ll1_l1_ (u"࠭ࡖࡐࡆࠪ䏏") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䏐") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࠨ䏑")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			elif l11ll1_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ䏒") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䏓")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			elif l11ll1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ䏔") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䏕")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			else: l1lll1l111l_l1_ = True
			l11llllllll1_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ䏖")+l111l1ll_l1_].append(l1l1111lllll_l1_)
		else: l1lll1l111l_l1_ = True
		if l1lll1l111l_l1_: l11lll1111ll_l1_.append(l1l1111l1111_l1_)
		l1ll1l111ll1_l1_ += 1
	l11lllll1lll_l1_ = sorted(l11llll1l1l1_l1_,reverse=False,key=lambda key: key[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䏗")].lower())
	del l11llll1l1l1_l1_
	l1l1l1l1ll_l1_ = str(length)
	l1ll1l111ll1_l1_ = 0
	for l1l1111l1111_l1_ in l11lllll1lll_l1_:
		l1ll1l111ll1_l1_ += 1
		if l1ll1l111ll1_l1_%873==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,55+int(5*l1ll1l111ll1_l1_/length),l11ll1_l1_ (u"ࠨฬุ๊๏็ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅาฬหอࠬ䏘"),l11ll1_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ䏙"),str(l1ll1l111ll1_l1_)+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䏚")+l1l1l1l1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return None,None
		l11lll111_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䏛")]
		group,context,title,url,l1lll1_l1_ = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ䏜")],l1l1111l1111_l1_[l11ll1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ䏝")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䏞")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠨࡷࡵࡰࠬ䏟")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠩ࡬ࡱ࡬࠭䏠")]
		l1ll1l1111l1_l1_,language = l1l1111l1111_l1_[l11ll1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䏡")],l1l1111l1111_l1_[l11ll1_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䏢")]
		l1l111l11111_l1_ = (group,context+l11ll1_l1_ (u"ࠬࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ䏣"),title,url,l1lll1_l1_)
		l1l1111lllll_l1_ = (group,context,title,url,l1lll1_l1_)
		l1l1111llll1_l1_ = (l1ll1l1111l1_l1_,context,title,url,l1lll1_l1_)
		l1l1111lll1l_l1_ = (language,context,title,url,l1lll1_l1_)
		if l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䏤") in l11lll111_l1_:
			if l11ll1_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䏥") in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏦")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			else: l11llllllll1_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏧")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			if l11ll1_l1_ (u"ࠪࡉࡕࡍࠧ䏨")		in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏩")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			if l11ll1_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ䏪")	in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䏫")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			if l11ll1_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䏬")	in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡔࡊࡏࡈࡗࡍࡏࡆࡕࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䏭")+l111l1ll_l1_].append(l1l111l11111_l1_)
			l11llllllll1_l1_[l11ll1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࡢࠫ䏮")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			l11llllllll1_l1_[l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䏯")+l111l1ll_l1_].append(l1l1111lll1l_l1_)
		elif l11ll1_l1_ (u"࡛ࠫࡕࡄࠨ䏰") in l11lll111_l1_:
			if   l11ll1_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓ࠭䏱")	in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䏲")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			elif l11ll1_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧ䏳")	in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ䏴")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			elif l11ll1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ䏵")	in l11lll111_l1_: l11llllllll1_l1_[l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䏶")+l111l1ll_l1_].append(l1l1111lllll_l1_)
			l11llllllll1_l1_[l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࡣࠬ䏷")+l111l1ll_l1_].append(l1l1111llll1_l1_)
			l11llllllll1_l1_[l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉࡥࠧ䏸")+l111l1ll_l1_].append(l1l1111lll1l_l1_)
	return l11llllllll1_l1_,l11lll1111ll_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l1ll11_l1_,sep = l11ll1_l1_ (u"࠭ࠧ䏹"),l11ll1_l1_ (u"ࠧࠨ䏺")
	l1lll1l1l_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11ll1_l1_ (u"ࠨࠪࠪ䏻"): sep = l11ll1_l1_ (u"ࠩࠬࠫ䏼")
	elif first==l11ll1_l1_ (u"ࠪ࡟ࠬ䏽"): sep = l11ll1_l1_ (u"ࠫࡢ࠭䏾")
	elif first==l11ll1_l1_ (u"ࠬࡂࠧ䏿"): sep = l11ll1_l1_ (u"࠭࠾ࠨ䐀")
	elif first==l11ll1_l1_ (u"ࠧࡽࠩ䐁"): sep = l11ll1_l1_ (u"ࠨࡾࠪ䐂")
	if sep and (sep in rest):
		l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = rest.split(sep,1)
		l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
		l1lll1l1l_l1_ = first+l1l1ll1lllll_l1_+sep+l11ll1_l1_ (u"ࠩࠣࠫ䐃")+l1l1ll1llll1_l1_
	elif title.count(l11ll1_l1_ (u"ࠪࢀࠬ䐄"))>=2:
		l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = title.split(l11ll1_l1_ (u"ࠫࢁ࠭䐅"),1)
		l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
		l1lll1l1l_l1_ = l1l1ll1lllll_l1_+l11ll1_l1_ (u"ࠬࠦࡼࠨ䐆")+l1l1ll1llll1_l1_
	else:
		sep = re.findall(l11ll1_l1_ (u"࠭࡞࡝ࡹࡾ࠶ࢂ࠮ࠠࡽ࡞࠽ࢀࡡ࠳ࡼ࡝ࡾࡿࡠࡢࢂ࡜ࠪࡾ࡟ࠧࢁࡢ࠮ࡽ࡞࠯ࢀࡡࠪࡼ࡝ࠩࡿࡠࠦࢂ࡜ࡁࡾ࡟ࠩࢁࡢࠦࡽ࡞࠭ࢀࡡࡤࠩࠨ䐇"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠧ࡟࡞ࡺࡿ࠸ࢃࠨࠡࡾ࡟࠾ࢁࡢ࠭ࡽ࡞ࡿࢀࡡࡣࡼ࡝ࠫࡿࡠࠨࢂ࡜࠯ࡾ࡟࠰ࢁࡢࠤࡽ࡞ࠪࢀࡡࠧࡼ࡝ࡂࡿࡠࠪࢂ࡜ࠧࡾ࡟࠮ࢁࡢ࡞ࠪࠩ䐈"),title,re.DOTALL)
		if not sep: sep = re.findall(l11ll1_l1_ (u"ࠨࡠ࡟ࡻࢀ࠺ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ䐉"),title,re.DOTALL)
		if sep:
			l1l1ll1lllll_l1_,l1l1ll1llll1_l1_ = title.split(sep[0],1)
			l1ll1l1ll11_l1_ = l1l1ll1lllll_l1_
			l1lll1l1l_l1_ = l1l1ll1lllll_l1_+l11ll1_l1_ (u"ࠩࠣࠫ䐊")+sep[0]+l11ll1_l1_ (u"ࠪࠤࠬ䐋")+l1l1ll1llll1_l1_
	l1lll1l1l_l1_ = l1lll1l1l_l1_.replace(l11ll1_l1_ (u"ࠫࠥࠦࠠࠨ䐌"),l11ll1_l1_ (u"ࠬࠦࠧ䐍")).replace(l11ll1_l1_ (u"࠭ࠠࠡࠩ䐎"),l11ll1_l1_ (u"ࠧࠡࠩ䐏"))
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.replace(l11ll1_l1_ (u"ࠨࠢࠣࠫ䐐"),l11ll1_l1_ (u"ࠩࠣࠫ䐑"))
	if not l1ll1l1ll11_l1_: l1ll1l1ll11_l1_ = l11ll1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡡࠤࠥࠬ䐒")
	l1ll1l1ll11_l1_ = l1ll1l1ll11_l1_.strip(l11ll1_l1_ (u"ࠫࠥ࠭䐓"))
	l1lll1l1l_l1_ = l1lll1l1l_l1_.strip(l11ll1_l1_ (u"ࠬࠦࠧ䐔"))
	return l1ll1l1ll11_l1_,l1lll1l1l_l1_
def GET_HEADERS(l1lll111l11l_l1_):
	headers = {}
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ䐕")+l1lll111l11l_l1_)
	if l111lll1ll_l1_: headers[l11ll1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䐖")] = l111lll1ll_l1_
	l11l111lll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ䐗")+l1lll111l11l_l1_)
	if l11l111lll_l1_: headers[l11ll1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䐘")] = l11l111lll_l1_
	return headers
def CREATE_STREAMS(l1lll111l11l_l1_,l111l1ll_l1_):
	global l11l1l1lll_l1_,l11llllllll1_l1_,l11ll1lll111_l1_,l1l111ll11l1_l1_,l1l111l1ll1l_l1_,groups,l11lll11llll_l1_,l11llll11111_l1_,l1l111l1ll11_l1_
	l11lllll1111_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䐙")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠫࡤ࠭䐚")+l111l1ll_l1_)
	#l1l111lll11l_l1_,l11lllll1111_l1_,server,username,password = GET_URL(l1lll111l11l_l1_)
	#if not username: return
	l111lll1ll_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ䐛")+l1lll111l11l_l1_)
	headers = {l11ll1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䐜"):l111lll1ll_l1_}
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䐝"),l11ll1_l1_ (u"ࠨࠩ䐞"),l11ll1_l1_ (u"ࠩࠪ䐟"),l11ll1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䐠"),l11ll1_l1_ (u"ࠫ฾๋ไ๋หࠣะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠣๆิࠦสฮฬสะࠥ฿ฯสࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ็ฬࠥอไๆๆไหฯࠦวๅฤ้ࠤฤ࠭䐡"))
	#if l1ll111ll1_l1_!=1: return
	l11lllllllll_l1_ = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"ࠬࡥ࡟ࡠࠩ䐢"),l11ll1_l1_ (u"࠭࡟ࠨ䐣")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠧࡠࠩ䐤")+l111l1ll_l1_)
	if 1:
		succeeded,l11lll1l1ll1_l1_,l1l111ll111l_l1_ = True,l11ll1_l1_ (u"ࠨࠩ䐥"),l11ll1_l1_ (u"ࠩࠪ䐦")
		if not succeeded:
			DIALOG_OK(l11ll1_l1_ (u"ࠪࠫ䐧"),l11ll1_l1_ (u"ࠫࠬ䐨"),l11ll1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䐩"),l11ll1_l1_ (u"࠭แีๆࠣฬุำศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥ࠴ࠠฤฯอ้ฬ๊ࠠาษห฻ࠥๆࡍ࠴ࡗࠣ฾๏ืࠠึฯํัࠥษ่ࠡไา๎๊ࠦร้ࠢ็หࠥ๐ูๆๆࠣ࠲࠳ูࠦๅ็สࠤศ์่ࠠา๊ࠤฬ๊ฮะ็ฬࠤฯำสศฮࠣหูะัศๅ้ࠣิ็ฺู่๋ࠢา๐อ๊ࠡํะอࠦร็ࠢอฺ๏็ࠠาษห฻ࠥอไศึอีฬ้ࠠษ่ไื่ࠦไๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣๆฬฬๅสࠢใࡑ࠸࡛ࠠศๆ่์ั๎ฯสࠢห๋ีอࠠศๆหี๋อๅอࠩ䐪"))
			if not l11lllll1111_l1_: LOG_THIS(l11ll1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䐫"),LOGGING(script_name)+l11ll1_l1_ (u"ࠨࠢࠣࠤࡓࡵࠠࡎ࠵ࡘࠤ࡚ࡘࡌࠡࡨࡲࡹࡳࡪࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡓ࠳ࡖࠢࡩ࡭ࡱ࡫ࡳࠨ䐬"))
			else: LOG_THIS(l11ll1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䐭"),LOGGING(script_name)+l11ll1_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡒ࠹ࡕࠡࡨ࡬ࡰࡪࡹࠧ䐮"))
			return
		l1l111lll1l1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11lllll1111_l1_,headers,True)
		if not l1l111lll1l1_l1_: return
		open(l11lllllllll_l1_,l11ll1_l1_ (u"ࠫࡼࡨࠧ䐯")).write(l1l111lll1l1_l1_)
	else: l1l111lll1l1_l1_ = open(l11lllllllll_l1_,l11ll1_l1_ (u"ࠬࡸࡢࠨ䐰")).read()
	if kodi_version>18.99 and l1l111lll1l1_l1_: l1l111lll1l1_l1_ = l1l111lll1l1_l1_.decode(l11ll1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䐱"))
	#l1l111lll1l1_l1_ = l1l111lll1l1_l1_[33000111:77000111]
	l11l1l1lll_l1_ = DIALOG_PROGRESS()
	l11l1l1lll_l1_.create(l11ll1_l1_ (u"ࠧอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ䐲"),l11ll1_l1_ (u"ࠨࠩ䐳"))
	PROGRESS_UPDATE(l11l1l1lll_l1_,15,l11ll1_l1_ (u"ࠩอ๊฽๐แࠡษ็้้็ࠠศๆิส๏ู๊ࠨ䐴"),l11ll1_l1_ (u"ࠪࠫ䐵"))
	l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l11ll1_l1_ (u"ࠫࠧࡺࡶࡨ࠯ࠪ䐶"),l11ll1_l1_ (u"ࠬࠨࠠࡵࡸࡪ࠱ࠬ䐷"))
	l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l11ll1_l1_ (u"࠭๎ࠨ䐸"),l11ll1_l1_ (u"ࠧࠨ䐹")).replace(l11ll1_l1_ (u"ࠨํࠪ䐺"),l11ll1_l1_ (u"ࠩࠪ䐻")).replace(l11ll1_l1_ (u"ࠪ๓ࠬ䐼"),l11ll1_l1_ (u"ࠫࠬ䐽")).replace(l11ll1_l1_ (u"ࠬ๒ࠧ䐾"),l11ll1_l1_ (u"࠭ࠧ䐿"))
	l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l11ll1_l1_ (u"ࠧ๒ࠩ䑀"),l11ll1_l1_ (u"ࠨࠩ䑁")).replace(l11ll1_l1_ (u"ࠩ๓ࠫ䑂"),l11ll1_l1_ (u"ࠪࠫ䑃")).replace(l11ll1_l1_ (u"ࠫ๒࠭䑄"),l11ll1_l1_ (u"ࠬ࠭䑅")).replace(l11ll1_l1_ (u"࠭๒ࠨ䑆"),l11ll1_l1_ (u"ࠧࠨ䑇"))
	l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l11ll1_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠧ䑈"),l11ll1_l1_ (u"ࠩࡪࡶࡴࡻࡰ࠾ࠩ䑉")).replace(l11ll1_l1_ (u"ࠪࡸࡻ࡭࠭ࠨ䑊"),l11ll1_l1_ (u"ࠫࠬ䑋"))
	l11lllllll1l_l1_,l1l111l1l111_l1_ = [],[]
	l11ll1_l1_ (u"ࠧࠨࠢࠋࠋࡓࡖࡔࡍࡒࡆࡕࡖࡣ࡚ࡖࡄࡂࡖࡈࠬࡵࡊࡩࡢ࡮ࡲ࡫࠱࠸࠰࠭ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊สࠩ࠯ࠫฬ๊ๅๅใࠣี็๋࠺࠮ࠩ࠯ࠫ࠶ࠦ࠯ࠡ࠵ࠪ࠭ࠏࠏࡩࡧࠢࡳࡈ࡮ࡧ࡬ࡰࡩ࠱࡭ࡸࡩࡡ࡯ࡥࡨࡰࡪࡪࠨࠪ࠼ࠍࠍࠎࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࡹࡷࡲࠠ࠾ࠢࡘࡖࡑࡥࡰ࡭ࡣࡼࡩࡷ࠱ࠧࠧࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡤࡹࡥࡳ࡫ࡨࡷࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠩࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡒ࠹ࡕ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏࡳࡦࡴ࡬ࡩࡸࡥࡧࡳࡱࡸࡴࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡪࡥ࡭ࠢ࡫ࡸࡲࡲࠊࠊࡨࡲࡶࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡴࠠࡴࡧࡵ࡭ࡪࡹ࡟ࡨࡴࡲࡹࡵࡹ࠺ࠋࠋࠌ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡀ࠶࠿࠺ࠡࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࡳ࠳ࡶࡡࡷࡩࡽࡺࠠ࠾ࠢࡰ࠷ࡺࡥࡴࡦࡺࡷ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡧࡳࡱࡸࡴࡂࠨࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠰ࠬ࡭ࡲࡰࡷࡳࡁࠧࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠯ࠊࠊࡦࡨࡰࠥࡹࡥࡳ࡫ࡨࡷࡤ࡭ࡲࡰࡷࡳࡷࠏࠏࡐࡓࡑࡊࡖࡊ࡙ࡓࡠࡗࡓࡈࡆ࡚ࡅࠩࡲࡇ࡭ࡦࡲ࡯ࡨ࠮࠵࠹࠱࠭ฬๅสࠣห้๋ไโษอࠤฬ๊หศ่๋๎ฮ࠭ࠬࠨษ็้้็ࠠาไ่࠾࠲࠭ࠬࠨ࠴ࠣ࠳ࠥ࠹ࠧࠪࠌࠌ࡭࡫ࠦࡰࡅ࡫ࡤࡰࡴ࡭࠮ࡪࡵࡦࡥࡳࡩࡥ࡭ࡧࡧࠬ࠮ࡀࠊࠊࠋࡳࡈ࡮ࡧ࡬ࡰࡩ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠐࠉࡶࡴ࡯ࠤࡂࠦࡕࡓࡎࡢࡴࡱࡧࡹࡦࡴ࠮ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡡࡹࡳࡩࡥࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠪࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡓ࠳ࡖ࠯ࡆࡖࡊࡇࡔࡆࡡࡖࡘࡗࡋࡁࡎࡕ࠰࠶ࡳࡪࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮ࠐࠉࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶࡾࡥ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣ࡫ࡷࡵࡵࡱࠢ࡬ࡲࠥࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴ࠼ࠍࠍࠎ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡂ࠱࠺࠼ࠣ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉ࡮࠵ࡸࡣࡹ࡫ࡸࡵࠢࡀࠤࡲ࠹ࡵࡠࡶࡨࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠲ࠧࡨࡴࡲࡹࡵࡃࠢࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧࠪࠌࠌࡨࡪࡲࠠࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠎࠎࡖࡒࡐࡉࡕࡉࡘ࡙࡟ࡖࡒࡇࡅ࡙ࡋࠨࡱࡆ࡬ࡥࡱࡵࡧ࠭࠵࠳࠰ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ࠲ࠧศๆ่่ๆࠦัใ็࠽࠱ࠬ࠲ࠧ࠴ࠢ࠲ࠤ࠸࠭ࠩࠋࠋ࡬ࡪࠥࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡩࡴࡥࡤࡲࡨ࡫࡬ࡦࡦࠫ࠭࠿ࠐࠉࠊࡲࡇ࡭ࡦࡲ࡯ࡨ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠏࠏࡵࡳ࡮ࠣࡁ࡛ࠥࡒࡍࡡࡳࡰࡦࡿࡥࡳ࠭ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠ࡮࡬ࡺࡪࡥࡳࡵࡴࡨࡥࡲࡹࠧࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡐ࠷࡚࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠴ࡴࡧࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡱ࡯ࡶࡦࡡࡤࡶࡨ࡮ࡩࡷࡧࡧࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶࡹࡣࡦࡸࡣࡩ࡫ࡹࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡯ࡣࡰࡩ࠱ࡧࡲࡤࡪ࡬ࡺࡪࡪࠠࡪࡰࠣࡰ࡮ࡼࡥࡠࡣࡵࡧ࡭࡯ࡶࡦࡦ࠽ࠎࠎࠏࡩࡧࠢࡤࡶࡨ࡮ࡩࡷࡧࡧࡁࡂ࠭࠱ࠨ࠼ࠣࡰ࡮ࡼࡥࡠࡣࡵࡧ࡭࡯ࡶࡦࡦࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡡ࡮ࡧࠬࠎࠎࡪࡥ࡭ࠢ࡯࡭ࡻ࡫࡟ࡢࡴࡦ࡬࡮ࡼࡥࡥࠌࠌࡰ࡮ࡼࡥࡠࡧࡳ࡫ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡨࡴ࡬ࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡰࡤࡱࡪ࠲ࡥࡱࡩࠣ࡭ࡳࠦ࡬ࡪࡸࡨࡣࡪࡶࡧ࠻ࠌࠌࠍ࡮࡬ࠠࡦࡲࡪࠥࡂ࠭࡮ࡶ࡮࡯ࠫ࠿ࠦ࡬ࡪࡸࡨࡣࡪࡶࡧࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡲࡦࡳࡥࠪࠌࠌࡨࡪࡲࠠ࡭࡫ࡹࡩࡤ࡫ࡰࡨࠌࠌࠦࠧࠨ䑌")
	l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l11ll1_l1_ (u"࠭࡜ࡳࠩ䑍"),l11ll1_l1_ (u"ࠧ࡝ࡰࠪ䑎"))
	lines = re.findall(l11ll1_l1_ (u"ࠨࡐࡉ࠾࠭࠴ࠫࡀࠫࠦࡉ࡝࡚ࡉࠨ䑏"),l1l111lll1l1_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠨࡋࡘࡕࡋࡑࡊ࠿࠭䑐"),re.DOTALL)
	if not lines:
		LOG_THIS(l11ll1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䑑"),LOGGING(script_name)+l11ll1_l1_ (u"ࠫࠥࠦࠠࡇࡱ࡯ࡨࡪࡸ࠺ࠨ䑒")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠬࠦࠠࡔࡧࡴࡹࡪࡴࡣࡦ࠼ࠪ䑓")+l111l1ll_l1_+l11ll1_l1_ (u"࠭ࠠࠡࠢࡑࡳࠥࡼࡩࡥࡧࡲࠤࡱ࡯࡮࡬ࡵࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡓ࠳ࡖࠢࡩ࡭ࡱ࡫ࠧ䑔"))
		DIALOG_OK(l11ll1_l1_ (u"ࠧࠨ䑕"),l11ll1_l1_ (u"ࠨࠩ䑖"),l11ll1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䑗"),l11ll1_l1_ (u"ࠪีฬฮืࠡโࡐ࠷࡚ࠦวๅาํࠤศ์สࠡลูๅฯํࠠๅษࠣฮําฯࠡใํ๋ࠥ็๊ะ์๋๋ฬะࠠ࠯࠰ࠣหาะๅศๆࠣีฬฮืࠡโࡐ࠷ฺ๋࡚ࠦำูࠣา๐อࠨ䑘")+l11ll1_l1_ (u"ࠫࡡࡴࠧ䑙")+l11ll1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䑚")+l11ll1_l1_ (u"࠭ัศสฺࠤึ่ๅࠡࠩ䑛")+str(int(l111l1ll_l1_)+1)+l11ll1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䑜"))
		l11l1l1lll_l1_.close()
		return
	l11ll11l11_l1_ = 1024*1024
	l1l11l1l1l1l_l1_ = 1+len(l1l111lll1l1_l1_)//l11ll11l11_l1_//10
	del l1l111lll1l1_l1_
	l11ll1lll1l1_l1_ = len(lines)
	l11lll1111l1_l1_ = SPLIT_BIGLIST(lines,l1l11l1l1l1l_l1_)
	del lines
	for l11ll11111_l1_ in range(l1l11l1l1l1l_l1_):
		PROGRESS_UPDATE(l11l1l1lll_l1_,35+int(5*l11ll11111_l1_/l1l11l1l1l1l_l1_),l11ll1_l1_ (u"ࠨฬๅ฻๏฿ࠠศๆ่่ๆࠦวๅำษ๎ุ๐ࠧ䑝"),l11ll1_l1_ (u"ࠩส่ัุมࠡำๅ้࠿࠳ࠧ䑞"),str(l11ll11111_l1_+1)+l11ll1_l1_ (u"ࠪࠤ࠴ࠦࠧ䑟")+str(l1l11l1l1l1l_l1_))
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l11lllll1ll1_l1_ = str(l11lll1111l1_l1_[l11ll11111_l1_])
		if kodi_version>18.99: l11lllll1ll1_l1_ = l11lllll1ll1_l1_.encode(l11ll1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䑠"))
		open(l11lllllllll_l1_+l11ll1_l1_ (u"ࠬ࠴࠰࠱ࠩ䑡")+str(l11ll11111_l1_),l11ll1_l1_ (u"࠭ࡷࡣࠩ䑢")).write(l11lllll1ll1_l1_)
	del l11lll1111l1_l1_,l11lllll1ll1_l1_
	l11ll1lllll1_l1_,l11llll1l1l1_l1_,l1ll1l111ll1_l1_ = [],[],0
	for l11ll11111_l1_ in range(l1l11l1l1l1l_l1_):
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		l11lllll1ll1_l1_ = open(l11lllllllll_l1_+l11ll1_l1_ (u"ࠧ࠯࠲࠳ࠫ䑣")+str(l11ll11111_l1_),l11ll1_l1_ (u"ࠨࡴࡥࠫ䑤")).read()
		time.sleep(1)
		try: os.remove(l11lllllllll_l1_+l11ll1_l1_ (u"ࠩ࠱࠴࠵࠭䑥")+str(l11ll11111_l1_))
		except: pass
		if kodi_version>18.99: l11lllll1ll1_l1_ = l11lllll1ll1_l1_.decode(l11ll1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䑦"))
		lines = EVAL(l11ll1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䑧"),l11lllll1ll1_l1_)
		del l11lllll1ll1_l1_
		l1ll11lllll1_l1_,l1ll1l111ll1_l1_,l11lll1111ll_l1_ = READ_ALL_LINES(lines,l1l111l1l111_l1_,l11lllllll1l_l1_,l11l1l1lll_l1_,l11ll1lll1l1_l1_,l1ll1l111ll1_l1_,l11lllll1111_l1_)
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
		if not l1ll11lllll1_l1_:
			l11l1l1lll_l1_.close()
			return
		l11llll1l1l1_l1_ += l1ll11lllll1_l1_
		l11ll1lllll1_l1_ += l11lll1111ll_l1_
	del lines,l1ll11lllll1_l1_
	l11llllllll1_l1_,l11lll1111ll_l1_ = CREATE_GROUPED_STREAMS(l11llll1l1l1_l1_,l11l1l1lll_l1_,l111l1ll_l1_)
	if l11l1l1lll_l1_.iscanceled():
		l11l1l1lll_l1_.close()
		return
	l11ll1lllll1_l1_ += l11lll1111ll_l1_
	del l11llll1l1l1_l1_,l11lll1111ll_l1_
	l1l111ll11l1_l1_,l1l111l1ll1l_l1_,groups,l11lll11llll_l1_,l11llll11111_l1_ = {},{},{},0,0
	l11lll1l11ll_l1_ = list(l11llllllll1_l1_.keys())
	l1l111l1ll11_l1_ = len(l11lll1l11ll_l1_)*3
	import threading
	if 1:
		threads = {}
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			threads[l11llllll1ll_l1_] = threading.Thread(target=CREATE_MENUS,args=(l11llllll1ll_l1_,))
			threads[l11llllll1ll_l1_].start()
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			threads[l11llllll1ll_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			CREATE_MENUS(l11llllll1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	DELETE_FILES(l1lll111l11l_l1_,l111l1ll_l1_,False)
	l11lll1l11ll_l1_ = list(l1l111ll11l1_l1_.keys())
	l11ll1lll111_l1_ = 0
	if 1:
		threads = {}
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			threads[l11llllll1ll_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1lll111l11l_l1_,l11llllll1ll_l1_))
			threads[l11llllll1ll_l1_].start()
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			threads[l11llllll1ll_l1_].join()
		if l11l1l1lll_l1_.iscanceled():
			l11l1l1lll_l1_.close()
			return
	else:
		for l11llllll1ll_l1_ in l11lll1l11ll_l1_:
			SAVE_MENUS(l1lll111l11l_l1_,l11llllll1ll_l1_)
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
	l11ll11111_l1_ = 0
	l1l111ll1l11_l1_ = len(l11ll1lllll1_l1_)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䑨"))
	for stream in l11ll1lllll1_l1_:
		if l11ll11111_l1_%27==0:
			PROGRESS_UPDATE(l11l1l1lll_l1_,95+int(5*l11ll11111_l1_//l1l111ll1l11_l1_),l11ll1_l1_ (u"࠭สฯิํ๊ࠥอไๆ้่่ฮ࠭䑩"),l11ll1_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ䑪"),str(l11ll11111_l1_)+l11ll1_l1_ (u"ࠨࠢ࠲ࠤࠬ䑫")+str(l1l111ll1l11_l1_))
			if l11l1l1lll_l1_.iscanceled():
				l11l1l1lll_l1_.close()
				return
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࡢࠫ䑬")+l111l1ll_l1_,str(stream),l11ll1_l1_ (u"ࠪࠫ䑭"),PERMANENT_CACHE)
		l11ll11111_l1_ += 1
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࡤ࠭䑮")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䑯"),str(l1l111ll1l11_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࡤ࠭䑰")+l111l1ll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䑱"),l11ll1_l1_ (u"ࠨ࠳ࠪ䑲"),PERMANENT_CACHE)
	#open(l1llll1lllll_l1_,l11ll1_l1_ (u"ࠩࡺࠫ䑳")).write(l11ll1_l1_ (u"ࠪࠫ䑴"))
	l11l1l1lll_l1_.close()
	time.sleep(1)
	#l11lll1lll11_l1_ = COUNTS(l1lll111l11l_l1_,l111l1ll_l1_)
	#DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䑵"),l11ll1_l1_ (u"ࠬ࠭䑶"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑷"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䑸")+l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ䑹")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䑺")+l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䑻")+l11lll1lll11_l1_)
	#xbmc.executebuiltin(l11ll1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䑼"))
	DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_)
	return
def CREATE_MENUS(l11llllll1ll_l1_):
	global l11l1l1lll_l1_,l11llllllll1_l1_,l11ll1lll111_l1_,l1l111ll11l1_l1_,l1l111l1ll1l_l1_,groups,l11lll11llll_l1_,l11llll11111_l1_,l1l111l1ll11_l1_
	l1l111ll11l1_l1_[l11llllll1ll_l1_] = {}
	l11lll1ll11l_l1_,l1l11111ll1l_l1_ = {},[]
	l11lll111111_l1_ = len(l11llllllll1_l1_[l11llllll1ll_l1_])
	l1l111ll11l1_l1_[l11llllll1ll_l1_][l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䑽")] = l11lll111111_l1_
	if l11lll111111_l1_>0:
		l1l1111ll1l1_l1_,l1l111lll111_l1_,l11ll1ll1l11_l1_,l1l111ll1l1l_l1_,l1l111111l11_l1_ = zip(*l11llllllll1_l1_[l11llllll1ll_l1_])
		del l1l111lll111_l1_,l11ll1ll1l11_l1_,l1l111ll1l1l_l1_
		l11llll1l1ll_l1_ = list(set(l1l1111ll1l1_l1_))
		for group in l11llll1l1ll_l1_:
			l11lll1ll11l_l1_[group] = l11ll1_l1_ (u"࠭ࠧ䑾")
			l1l111ll11l1_l1_[l11llllll1ll_l1_][group] = []
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll11111_l1_//l1l111l1ll11_l1_),l11ll1_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ䑿"),l11ll1_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭䒀"),str(l11llll11111_l1_)+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭䒁")+str(l1l111l1ll11_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11llll11111_l1_ += 1
		l11lll1l11l1_l1_ = len(l11llll1l1ll_l1_)
		del l11llll1l1ll_l1_
		l1l11111ll1l_l1_ = list(set(zip(l1l1111ll1l1_l1_,l1l111111l11_l1_)))
		del l1l1111ll1l1_l1_,l1l111111l11_l1_
		for group,l111_l1_ in l1l11111ll1l_l1_:
			if not l11lll1ll11l_l1_[group] and l111_l1_: l11lll1ll11l_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll11111_l1_//l1l111l1ll11_l1_),l11ll1_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่็๎วว็ࠪ䒂"),l11ll1_l1_ (u"ࠫฬ๊ฬำรࠣี็๋࠺࠮ࠩ䒃"),str(l11llll11111_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䒄")+str(l1l111l1ll11_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		l11llll11111_l1_ += 1
		l11llll11l1l_l1_ = list(l11lll1ll11l_l1_.keys())
		l11lll1l1111_l1_ = list(l11lll1ll11l_l1_.values())
		del l11lll1ll11l_l1_
		l1l11111ll1l_l1_ = list(zip(l11llll11l1l_l1_,l11lll1l1111_l1_))
		del l11llll11l1l_l1_,l11lll1l1111_l1_
		l1l11111ll1l_l1_ = sorted(l1l11111ll1l_l1_)
	else: l11llll11111_l1_ += 2
	l1l111ll11l1_l1_[l11llllll1ll_l1_][l11ll1_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ䒅")] = l1l11111ll1l_l1_
	del l1l11111ll1l_l1_
	for group,context,title,url,l1lll1_l1_ in l11llllllll1_l1_[l11llllll1ll_l1_]:
		l1l111ll11l1_l1_[l11llllll1ll_l1_][group].append((context,title,url,l1lll1_l1_))
	PROGRESS_UPDATE(l11l1l1lll_l1_,60+int(15*l11llll11111_l1_//l1l111l1ll11_l1_),l11ll1_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ䒆"),l11ll1_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭䒇"),str(l11llll11111_l1_)+l11ll1_l1_ (u"ࠩࠣ࠳ࠥ࠭䒈")+str(l1l111l1ll11_l1_))
	if l11l1l1lll_l1_.iscanceled(): return
	l11llll11111_l1_ += 1
	del l11llllllll1_l1_[l11llllll1ll_l1_]
	groups[l11llllll1ll_l1_] = list(l1l111ll11l1_l1_[l11llllll1ll_l1_].keys())
	l1l111l1ll1l_l1_[l11llllll1ll_l1_] = len(groups[l11llllll1ll_l1_])
	l11lll11llll_l1_ += l1l111l1ll1l_l1_[l11llllll1ll_l1_]
	return
def SAVE_MENUS(l1lll111l11l_l1_,l11llllll1ll_l1_):
	global l11l1l1lll_l1_,l11llllllll1_l1_,l11ll1lll111_l1_,l1l111ll11l1_l1_,l1l111l1ll1l_l1_,groups,l11lll11llll_l1_,l11llll11111_l1_,l1l111l1ll11_l1_
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11llllll1ll_l1_)
	for l1ll1l111ll1_l1_ in range(1+l1l111l1ll1l_l1_[l11llllll1ll_l1_]//173):
		l11lll11l1ll_l1_ = []
		l1l1111l111l_l1_ = groups[l11llllll1ll_l1_][0:273]
		for group in l1l1111l111l_l1_:
			l11lll11l1ll_l1_.append(l1l111ll11l1_l1_[l11llllll1ll_l1_][group])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1ll_l1_,l1l1111l111l_l1_,l11lll11l1ll_l1_,PERMANENT_CACHE,True)
		l11ll1lll111_l1_ += len(l1l1111l111l_l1_)
		PROGRESS_UPDATE(l11l1l1lll_l1_,75+int(20*l11ll1lll111_l1_//l11lll11llll_l1_),l11ll1_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็ࠪ䒉"),l11ll1_l1_ (u"ࠫฬ๊โศศ่อࠥืโๆ࠼࠰ࠫ䒊"),str(l11ll1lll111_l1_)+l11ll1_l1_ (u"ࠬࠦ࠯ࠡࠩ䒋")+str(l11lll11llll_l1_))
		if l11l1l1lll_l1_.iscanceled(): return
		del groups[l11llllll1ll_l1_][0:273]
	del l1l111ll11l1_l1_[l11llllll1ll_l1_],groups[l11llllll1ll_l1_],l1l111l1ll1l_l1_[l11llllll1ll_l1_]
	return
def COUNTS(l1lll111l11l_l1_,l111l1ll_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,l1ll_l1_): return
	l1l1111l11l1_l1_ = l11ll1_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠥาๅ๋฻ࠣห้ื่ศสฺࠫ䒌")
	l11lll1lll1l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䒍"))
	l1l11111111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䒎"))
	if l111l1ll_l1_:
		l1l1111l11l1_l1_ = l11ll1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠡำสฬ฼ࠦࠧ䒏")+text_numbers[int(l111l1ll_l1_)]
		l111l1ll_l1_ = l11ll1_l1_ (u"ࠪࡣࠬ䒐")+l111l1ll_l1_
	l1l111ll1l11_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䒑"),l11ll1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭䒒")+l111l1ll_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䒓"))
	l1l11111l111_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"ࠧࡪࡰࡷࠫ䒔"),l11ll1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䒕")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䒖"))
	l11ll1ll1l1l_l1_ = READ_FROM_SQL3(l1l11111111l_l1_,l11ll1_l1_ (u"ࠪ࡭ࡳࡺࠧ䒗"),l11ll1_l1_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒘")+l111l1ll_l1_,l11ll1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䒙"))
	l11llllll1l1_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"࠭ࡩ࡯ࡶࠪ䒚"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭䒛")+l111l1ll_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䒜"))
	l11lll1l1lll_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"ࠩ࡬ࡲࡹ࠭䒝"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䒞")+l111l1ll_l1_,l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䒟"))
	l1l1111lll11_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"ࠬ࡯࡮ࡵࠩ䒠"),l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒡")+l111l1ll_l1_,l11ll1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䒢"))
	l1l111ll11ll_l1_ = READ_FROM_SQL3(l1l11111111l_l1_,l11ll1_l1_ (u"ࠨ࡫ࡱࡸࠬ䒣"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䒤")+l111l1ll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䒥"))
	l11llll11l11_l1_ = READ_FROM_SQL3(l11lll1lll1l_l1_,l11ll1_l1_ (u"ࠫ࡮ࡴࡴࠨ䒦"),l11ll1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䒧")+l111l1ll_l1_,l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䒨"))
	groups = READ_FROM_SQL3(l1l11111111l_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䒩"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䒪")+l111l1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭䒫"))
	l11lllll111l_l1_ = []
	for group,l1lll1_l1_ in groups:
		l11llll1ll1l_l1_ = group.split(l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䒬"))[1]
		l11lllll111l_l1_.append(l11llll1ll1l_l1_)
	l1l1111111l1_l1_ = len(l11lllll111l_l1_)
	total = int(l1l1111lll11_l1_)+int(l1l111ll11ll_l1_)+int(l11llll11l11_l1_)+int(l11lll1l1lll_l1_)+int(l11llllll1l1_l1_)
	l11lll1lll11_l1_ = l11ll1_l1_ (u"ࠫࠬ䒭")
	l11lll1lll11_l1_ += l11ll1_l1_ (u"่ࠬๆ้ษอ࠾ࠥ࠭䒮")+str(l11llllll1l1_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦรโๆส้࠿ࠦࠧ䒯")+str(l1l1111lll11_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠧ࡝ࡰ่ืู้ไศฬ࠽ࠤࠬ䒰")+str(l1l1111111l1_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡฯ็ๆฬะ࠺ࠡࠩ䒱")+str(l1l111ll11ll_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠩ࡟ࡲ็์่ศฬ้ࠣัํ่ๅห࠽ࠤࠬ䒲")+str(l11lll1l1lll_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣๅ๏ี่่ษอࠤ๊า็้ๆฬ࠾ࠥ࠭䒳")+str(l11llll11l11_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠫࡡࡴๅอ็๋฽ࠥอไใ่๋หฯࡀࠠࠨ䒴")+str(l1l11111l111_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤ๋ࠥฬๆ๊฼ࠤฬ๊แ๋ัํ์์อส࠻ࠢࠪ䒵")+str(l11ll1ll1l1l_l1_)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"࠭࡜࡯࡞ࡱ้ัฺ๋่ࠢส่๊฼วโห࠽ࠤࠬ䒶")+str(total)
	l11lll1lll11_l1_ += l11ll1_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠๆฮ่์฾ࠦวๅ็๊้้ฯ࠺ࠡࠩ䒷")+str(l1l111ll1l11_l1_)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䒸"),l11ll1_l1_ (u"ࠩࠪ䒹"),l1l1111l11l1_l1_,l11lll1lll11_l1_)
	l11llll111ll_l1_ = l11lll1lll11_l1_.replace(l11ll1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䒺"),l11ll1_l1_ (u"ࠫࡡࡴࠧ䒻"))
	if not l111l1ll_l1_: l111l1ll_l1_ = l11ll1_l1_ (u"ࠬࡇ࡬࡭ࠩ䒼")
	else: l111l1ll_l1_ = l111l1ll_l1_[1]
	LOG_THIS(l11ll1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䒽"),l11ll1_l1_ (u"ࠧ࠯ࠢࠣࠤࡈࡵࡵ࡯ࡶࡶࠤࡴ࡬ࠠࡎ࠵ࡘࠤࡻ࡯ࡤࡦࡱࡶࠤࠥࠦࡆࡰ࡮ࡧࡩࡷࡀࠠࠨ䒾")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠨࠢࠣࠤࡘ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ䒿")+l111l1ll_l1_+l11ll1_l1_ (u"ࠩ࡟ࡲࠬ䓀")+l11llll111ll_l1_)
	return l11lll1lll11_l1_
def DELETE_FILES(l1lll111l11l_l1_,l111l1ll_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䓁"),l11ll1_l1_ (u"ࠫࠬ䓂"),l11ll1_l1_ (u"ࠬ࠭䓃"),l11ll1_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䓄"),l11ll1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯࠣห้๋ไโษอࠤฬ๊โะ์่อࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠠ࠯࠰ࠣ฽้๋วࠡษ้็ࠥะำหูํ฽ࠥ็๊ࠡลํࠤํ่สࠡษ็ำำ๎ไࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖ๋ࠢะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ䓅"))
		if l1ll111ll1_l1_!=1: return
		file = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"ࠨࡡࡢࡣࠬ䓆"),l11ll1_l1_ (u"ࠩࡢࠫ䓇")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䓈")+l111l1ll_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l11111l1l1_l1_)
	#except: pass
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠫࠬ䓉"))
	if l111l1ll_l1_:
		l11lllll1l1l_l1_ = []
		for l11ll1l11_l1_ in l11lllll11ll_l1_:
			l11lllll1l1l_l1_.append(l11ll1l11_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䓊")+l111l1ll_l1_)
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ䓋")+l111l1ll_l1_)
	else:
		l11lllll1l1l_l1_ = l11lllll11ll_l1_
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭䓌"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡉࡕࡓ࡚ࡖࡓࠨ䓍"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡌࡘࡊࡓࡓࠨ䓎"))
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࠪ䓏"))
		DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䓐"),l11ll1_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ䓑")+l1lll111l11l_l1_)
	for l11llllll1ll_l1_ in l11lllll1l1l_l1_:
		DELETE_FROM_SQL3(l1l1ll111l_l1_,l11llllll1ll_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"࠭ࠧ䓒"),l11ll1_l1_ (u"ࠧࠨ䓓"),l11ll1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䓔"),l11ll1_l1_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ䓕"))
	DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_)
	return
def CHECK_TABLES_EXIST(l1lll111l11l_l1_=l11ll1_l1_ (u"ࠪࠫ䓖"),l1ll_l1_=True):
	if l1lll111l11l_l1_:
		l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll111l11l_l1_),l11ll1_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ䓗"))
		dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠬࡹࡴࡳࠩ䓘"),l11ll1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䓙"),l11ll1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ䓚"))
		if dummy: return True
	else:
		for l1lll111l11l_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1ll111l_l1_ = GET_DBFILE_NAME(str(l1lll111l11l_l1_),l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䓛"))
			dummy = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭䓜"),l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䓝"),l11ll1_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ䓞"))
			if dummy: return True
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠬ࠭䓟"),l11ll1_l1_ (u"࠭ࠧ䓠"),l11ll1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䓡"),l11ll1_l1_ (u"ࠨษ้ฮࠥฮอศฮฬࠤส๊้ࠡษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣวูหๆฯࠠาษห฻ࠥษ่ࠡษืฮึอใࠡโࡐ࠷࡚ࠨࠠ࠯࠰๋ࠣีํࠠศๆิ์ฬฮืࠡษะฮ๊อไࠡฬฯำ์อࠠโ์ࠣห้หๆหำ้ฮࠥษ่ࠡฬืฮึ๐็ศฺ่๊ࠢࠥัไหࠣๅ๏ี๊้้สฮࠥࡢ࡮࡝ࡰࠣว๊อࠠฦาสࠤ็๋สࠡใ฼่ฬࠦศฦุสๅฮࠦวๅำสฬ฼ࠦแฦา้ࠤศ์สࠡสะหัฯࠠๅฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖ๋ࠢิ้้ࠠษษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢฮ้ࠥะึ฻ูࠣ฽้๏ࠠࠣฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠤ࠱ࠫ䓢"))
	#SHOW_EMPTY(l111l1_l1_)
	return False
def SEARCH(l1ll11111ll_l1_,l1lll111l11l_l1_=l11ll1_l1_ (u"ࠩࠪ䓣"),l11llllll1ll_l1_=l11ll1_l1_ (u"ࠪࠫ䓤"),l11lll1ll1ll_l1_=l11ll1_l1_ (u"ࠫࠬ䓥")):
	if not l11lll1ll1ll_l1_: l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠬ࠷ࠧ䓦")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llll1ll11_l1_ = [l11ll1_l1_ (u"࠭ࠧ䓧"),l11ll1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓨"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓩"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䓪"),l11ll1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䓫"),l11ll1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䓬")]
	if not l11llllll1ll_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࡠࠩ䓭") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[1]
			elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ䓮") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[2]
			elif l11ll1_l1_ (u"ࠧࡠࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ䓯") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[3]
			else: l11llllll1ll_l1_ = l11llll1ll11_l1_[0]
		else:
			l1l11111l1ll_l1_ = [l11ll1_l1_ (u"ࠨษ็็้࠭䓰"),l11ll1_l1_ (u"ࠩๅ๊ํอสࠨ䓱"),l11ll1_l1_ (u"ࠪวๆ๊วๆࠩ䓲"),l11ll1_l1_ (u"ู๊ࠫไิๆสฮࠬ䓳"),l11ll1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯࠧ䓴"),l11ll1_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ䓵")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䓶"), l1l11111l1ll_l1_)
			if choice==-1: return
			l11llllll1ll_l1_ = l11llll1ll11_l1_[choice]
	search = search+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䓷")
	if l1lll111l11l_l1_: SEARCH_ONE_FOLDER(search,l1lll111l11l_l1_,l11llllll1ll_l1_,l11lll1ll1ll_l1_)
	else:
		for l1lll111l11l_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1lll111l11l_l1_),l11llllll1ll_l1_,l11lll1ll1ll_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1ll11111ll_l1_,l1lll111l11l_l1_,l11llllll1ll_l1_=l11ll1_l1_ (u"ࠩࠪ䓸"),l11lll1ll1ll_l1_=l11ll1_l1_ (u"ࠪࠫ䓹")):
	if not l11lll1ll1ll_l1_: l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠫ࠶࠭䓺")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1ll11111ll_l1_)
	if not l1lll111l11l_l1_: return
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11llll1ll11_l1_ = [l11ll1_l1_ (u"ࠬ࠭䓻"),l11ll1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䓼"),l11ll1_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䓽"),l11ll1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䓾"),l11ll1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䓿"),l11ll1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䔀")]
	if not l11llllll1ll_l1_:
		if not l1ll_l1_:
			if   l11ll1_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋ࡟ࠨ䔁") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[1]
			elif l11ll1_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ䔂") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[2]
			elif l11ll1_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ䔃") in options: l11llllll1ll_l1_ = l11llll1ll11_l1_[3]
			else: l11llllll1ll_l1_ = l11llll1ll11_l1_[0]
		else:
			l1l11111l1ll_l1_ = [l11ll1_l1_ (u"ࠧศๆๆ่ࠬ䔄"),l11ll1_l1_ (u"ࠨไ้์ฬะࠧ䔅"),l11ll1_l1_ (u"ࠩฦๅ้อๅࠨ䔆"),l11ll1_l1_ (u"ุ้๊ࠪำๅษอࠫ䔇"),l11ll1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅอ้๋่ฮ࠭䔈"),l11ll1_l1_ (u"่ࠬๆ้ษอࠤ๊า็้ๆฬࠫ䔉")]
			choice = DIALOG_SELECT(l11ll1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䔊"), l1l11111l1ll_l1_)
			if choice==-1: return
			l11llllll1ll_l1_ = l11llll1ll11_l1_[choice]
	l11ll1ll1lll_l1_ = search.lower()
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ䔋"))
	results = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䔌"),l11ll1_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ䔍"),(l11llllll1ll_l1_,l11ll1ll1lll_l1_))
	if not results:
		l1l111l11lll_l1_,l11llll1llll_l1_ = [],[]
		if not l11llllll1ll_l1_: l11llll1111l_l1_ = [1,2,3,4,5]
		else: l11llll1111l_l1_ = [l11llll1ll11_l1_.index(l11llllll1ll_l1_)]
		for l11ll11111_l1_ in l11llll1111l_l1_:
			#l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11llll1ll11_l1_[l11ll11111_l1_])
			if l11ll11111_l1_!=3:
				l1ll11lllll1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䔎"),l11llll1ll11_l1_[l11ll11111_l1_])
				del l1ll11lllll1_l1_[l11ll1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䔏")]
				del l1ll11lllll1_l1_[l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䔐")]
				del l1ll11lllll1_l1_[l11ll1_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ䔑")]
				groups = list(l1ll11lllll1_l1_.keys())
				for group in groups:
					for context,title,url,l1lll1_l1_ in l1ll11lllll1_l1_[group]:
						if l11ll1ll1lll_l1_ in title.lower(): l11llll1llll_l1_.append((title,url,l1lll1_l1_))
					del l1ll11lllll1_l1_[group]
				del l1ll11lllll1_l1_
			else: groups = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䔒"),l11llll1ll11_l1_[l11ll11111_l1_],l11ll1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ䔓"))
			for group in groups:
				try: group,l1lll1_l1_ = group
				except: l1lll1_l1_ = l11ll1_l1_ (u"ࠩࠪ䔔")
				if l11ll1ll1lll_l1_ in group.lower():
					if l11ll11111_l1_!=3: l1l1111l1l11_l1_ = group
					else:
						l1l1111l1l1l_l1_,l11ll1ll1ll1_l1_ = group.split(l11ll1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䔕"))
						if l11ll1ll1lll_l1_ in l1l1111l1l1l_l1_.lower(): l1l1111l1l11_l1_ = l1l1111l1l1l_l1_
						else: l1l1111l1l11_l1_ = l11ll1ll1ll1_l1_
					l1l111l11lll_l1_.append((group,l1l1111l1l11_l1_,l11llll1ll11_l1_[l11ll11111_l1_],l1lll1_l1_))
			del groups
		l1l111l11lll_l1_ = set(l1l111l11lll_l1_)
		l11llll1llll_l1_ = set(l11llll1llll_l1_)
		l1l111l11lll_l1_ = sorted(l1l111l11lll_l1_,reverse=False,key=lambda key: key[1])
		l11llll1llll_l1_ = sorted(l11llll1llll_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ䔖"),(l11llllll1ll_l1_,l11ll1ll1lll_l1_),(l1l111l11lll_l1_,l11llll1llll_l1_),PERMANENT_CACHE)
	else: l1l111l11lll_l1_,l11llll1llll_l1_ = results
	groups = len(l1l111l11lll_l1_)
	l11lll_l1_ = len(l11llll1llll_l1_)
	l1l1111_l1_ = int(l11lll1ll1ll_l1_)
	s1 = max(0,(l1l1111_l1_-1)*100)
	e1 = max(0,l1l1111_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l1111l1l11_l1_,l1l111l111ll_l1_,l1lll1_l1_ in l1l111l11lll_l1_[s1:e1]:
		addMenuItem(l11ll1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔗"),l111l1_l1_+l1l1111l1l11_l1_,l1l111l111ll_l1_,714,l1lll1_l1_,l11ll1_l1_ (u"࠭࠱ࠨ䔘"),group,l11ll1_l1_ (u"ࠧࠨ䔙"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔚"):l1lll111l11l_l1_})
	del l1l111l11lll_l1_
	for title,url,l1lll1_l1_ in l11llll1llll_l1_[s2:e2]:
		l1l111l111l1_l1_ = url.split(l11ll1_l1_ (u"ࠩ࠲ࠫ䔛"))[-1]
		if l11ll1_l1_ (u"ࠪ࠲ࠬ䔜") in l1l111l111l1_l1_ and l11ll1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䔝") not in l1l111l111l1_l1_: addMenuItem(l11ll1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䔞"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"࠭ࠧ䔟"),l11ll1_l1_ (u"ࠧࠨ䔠"),l11ll1_l1_ (u"ࠨࠩ䔡"),{l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔢"):l1lll111l11l_l1_})
		else: addMenuItem(l11ll1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䔣"),l111l1_l1_+title,url,715,l1lll1_l1_,l11ll1_l1_ (u"ࠫࠬ䔤"),l11ll1_l1_ (u"ࠬ࠭䔥"),l11ll1_l1_ (u"࠭ࠧ䔦"),{l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔧"):l1lll111l11l_l1_})
	del l11llll1llll_l1_
	PAGINATION(l1lll111l11l_l1_,l11lll1ll1ll_l1_,l11llllll1ll_l1_,719,groups+l11lll_l1_,search+l11ll1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䔨"))
	return
def PAGINATION(l1lll111l11l_l1_,l11lll1ll1ll_l1_,l11llllll1ll_l1_,mode,total,text):
	if not l11lll1ll1ll_l1_: l11lll1ll1ll_l1_ = l11ll1_l1_ (u"ࠩ࠴ࠫ䔩")
	if l11lll1ll1ll_l1_!=l11ll1_l1_ (u"ࠪ࠵ࠬ䔪"): addMenuItem(l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔫"),l111l1_l1_+l11ll1_l1_ (u"ࠬ฻แฮหࠣࠫ䔬")+str(1),l11llllll1ll_l1_,mode,l11ll1_l1_ (u"࠭ࠧ䔭"),str(1),text,l11ll1_l1_ (u"ࠧࠨ䔮"),{l11ll1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔯"):l1lll111l11l_l1_})
	if not total: total = 0
	l1l1l1lll_l1_ = int(total/100)+1
	for l1l1111_l1_ in range(2,l1l1l1lll_l1_):
		l1ll1ll1l1l1_l1_ = (l1l1111_l1_%10==0 or int(l11lll1ll1ll_l1_)-4<l1l1111_l1_<int(l11lll1ll1ll_l1_)+4)
		l1ll1ll1l111_l1_ = (l1ll1ll1l1l1_l1_ and int(l11lll1ll1ll_l1_)-40<l1l1111_l1_<int(l11lll1ll1ll_l1_)+40)
		if str(l1l1111_l1_)!=l11lll1ll1ll_l1_ and (l1l1111_l1_%100==0 or l1ll1ll1l111_l1_):
			addMenuItem(l11ll1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔰"),l111l1_l1_+l11ll1_l1_ (u"ูࠪๆำษࠡࠩ䔱")+str(l1l1111_l1_),l11llllll1ll_l1_,mode,l11ll1_l1_ (u"ࠫࠬ䔲"),str(l1l1111_l1_),text,l11ll1_l1_ (u"ࠬ࠭䔳"),{l11ll1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔴"):l1lll111l11l_l1_})
	if str(l1l1l1lll_l1_)!=l11lll1ll1ll_l1_: addMenuItem(l11ll1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔵"),l111l1_l1_+l11ll1_l1_ (u"ࠨลัีࠥ฻แฮหࠣࠫ䔶")+str(l1l1l1lll_l1_),l11llllll1ll_l1_,mode,l11ll1_l1_ (u"ࠩࠪ䔷"),str(l1l1l1lll_l1_),text,l11ll1_l1_ (u"ࠪࠫ䔸"),{l11ll1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔹"):l1lll111l11l_l1_})
	return
def GET_DBFILE_NAME(l1lll111l11l_l1_,l11llllll1ll_l1_):
	#if l11ll1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ䔺") in l11llllll1ll_l1_ or l11ll1_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࠬ䔻") in l11llllll1ll_l1_: l1l1ll111l_l1_ = l1l1lll1l11l_l1_
	#else: l1l1ll111l_l1_ = l1l1lll1l11l_l1_
	l1l1ll111l_l1_ = l1l1lll1l11l_l1_.replace(l11ll1_l1_ (u"ࠧࡠࡡࡢࠫ䔼"),l11ll1_l1_ (u"ࠨࡡࠪ䔽")+l1lll111l11l_l1_)
	return l1l1ll111l_l1_
def l1l1111ll111_l1_(l1lll111l11l_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠩࠪ䔾"))
	l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䔿"),l11ll1_l1_ (u"ࠫࠬ䕀"),l11ll1_l1_ (u"ࠬ࠭䕁"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕂"),l11ll1_l1_ (u"ฺࠧ็็๎ฮࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮࠦโะࠢอัฯอฬࠡ฻าอࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮั๊ศࠡษ็้้็วหࠢส่ว์ࠠภࠩ䕃"))
	if l1ll111ll1_l1_!=1: return
	l1l111l1llll_l1_(l1lll111l11l_l1_,False)
	counts = [0]
	for seq in range(1,l11llll1lll1_l1_+1):
		l1l111l1l11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭䕄")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠩࡢࠫ䕅")+str(seq))
		if l1l111l1l11l_l1_: CREATE_STREAMS(l1lll111l11l_l1_,str(seq))
		counts.append(0)
	for l11llllll1ll_l1_ in l11lllll11ll_l1_:
		l11lll1ll1l1_l1_,l11lll1llll1_l1_,l1l111ll1ll1_l1_,l11llll1l111_l1_,l11lll1ll11l_l1_ = 0,{},[],[],[]
		for seq in range(1,l11llll1lll1_l1_+1):
			l1l111l111ll_l1_ = l11llllll1ll_l1_+l11ll1_l1_ (u"ࠪࡣࠬ䕆")+str(seq)
			l11llllllll1_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䕇"),l1l111l111ll_l1_)
			try:
				l1l111ll1111_l1_ = l11llllllll1_l1_[l11ll1_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ䕈")]
				count = l11llllllll1_l1_[l11ll1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䕉")]
			except:
				l1l111ll1111_l1_ = []
				count = l11ll1_l1_ (u"ࠧ࠱ࠩ䕊")
			for tuple in l1l111ll1111_l1_:
				group,l111_l1_ = tuple
				l1ll11lllll1_l1_ = l11llllllll1_l1_[group]
				if group not in l11llll1l111_l1_:
					l11llll1l111_l1_.append(group)
					l11lll1ll11l_l1_.append(tuple)
					l11lll1llll1_l1_[group] = []
				l11lll1llll1_l1_[group] += l1ll11lllll1_l1_
			DELETE_FROM_SQL3(l1l1ll111l_l1_,l1l111l111ll_l1_)
			WRITE_TO_SQL3(l1l1ll111l_l1_,l1l111l111ll_l1_,l11ll1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䕋"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11llll1l111_l1_:
			l1ll11lllll1_l1_ = list(set(l11lll1llll1_l1_[group]))
			l11lll1ll1l1_l1_ += len(l1ll11lllll1_l1_)
			l1l111ll1ll1_l1_.append(l1ll11lllll1_l1_)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1ll_l1_,l11ll1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䕌"),str(l11lll1ll1l1_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1ll_l1_,l11ll1_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䕍"),l11lll1ll11l_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll111l_l1_,l11llllll1ll_l1_,l11llll1l111_l1_,l1l111ll1ll1_l1_,PERMANENT_CACHE,True)
	l1l111111ll1_l1_ = False
	for seq in range(1,l11llll1lll1_l1_+1):
		if int(counts[seq])>0:
			l1l111l1l11l_l1_ = settings.getSetting(l11ll1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡸ࡬ࡠࠩ䕎")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠬࡥࠧ䕏")+str(seq))
			WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ䕐")+str(seq),l11ll1_l1_ (u"ࠧࡠࡡࡏࡍࡓࡑ࡟ࡠࠩ䕑"),l1l111l1l11l_l1_,PERMANENT_CACHE)
			l1l111111ll1_l1_ = True
	WRITE_TO_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䕒"),l11ll1_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ䕓"),l11ll1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䕔"),PERMANENT_CACHE)
	if l1l111111ll1_l1_:
		DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䕕"),l11ll1_l1_ (u"ࠬ࠭䕖"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕗"),l11ll1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䕘")+l11ll1_l1_ (u"ࠨฬ่ࠤั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ䕙")+l11ll1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䕚"))
		l1l111111lll_l1_(l1lll111l11l_l1_)
		xbmc.executebuiltin(l11ll1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䕛"))
	else: DIALOG_OK(l11ll1_l1_ (u"ࠫࠬ䕜"),l11ll1_l1_ (u"ࠬ࠭䕝"),l11ll1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕞"),l11ll1_l1_ (u"ࠧโึ็ࠤอูอษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦ࠮ࠡละฮ๊อไࠡำ๋หอ฽ࠠแࡏ࠶࡙ࠥอไห์ࠣว๋ะࠠฤุไฮ์อࠠๅๆหี๋อๅอࠢ฽๎ึࠦีฮ์ะอࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะ๋ࠥๆไࠢฦ๊ࠥะึ๋ใࠣห้ืวษูࠣฬ๋็ำไࠢ็่อืๆศ็ฯࠤออำหะาห๊ࠦโศศ่อࠥๆࡍ࠴ࡗࠣห้๋่อ๊าอࠥฮ็ัษࠣห้ฮั็ษ่ะࠬ䕟"))
	return
def l1l111111lll_l1_(l1lll111l11l_l1_):
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠨࠩ䕠"))
	if not CHECK_TABLES_EXIST(l1lll111l11l_l1_,True): return
	for seq in range(1,l11llll1lll1_l1_+1):
		l1l111l1l11l_l1_ = READ_FROM_SQL3(l1l1ll111l_l1_,l11ll1_l1_ (u"ࠩࡶࡸࡷ࠭䕡"),l11ll1_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ䕢")+str(seq),l11ll1_l1_ (u"ࠫࡤࡥࡌࡊࡐࡎࡣࡤ࠭䕣"))
		if l1l111l1l11l_l1_: l11lll1lll11_l1_ = COUNTS(l1lll111l11l_l1_,str(seq))
	COUNTS(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠬ࠭䕤"))
	return
def l1l111l1llll_l1_(l1lll111l11l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11ll1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䕥"),l11ll1_l1_ (u"ࠧࠨ䕦"),l11ll1_l1_ (u"ࠨࠩ䕧"),l11ll1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ䕨"),l11ll1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭䕩"))
		if l1ll111ll1_l1_!=1: return
	#for seq in range(1,l11llll1lll1_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11ll1_l1_ (u"ࠫࠬ䕪"),False)
	l1l1ll111l_l1_ = GET_DBFILE_NAME(l1lll111l11l_l1_,l11ll1_l1_ (u"ࠬ࠭䕫"))
	try: os.remove(l1l1ll111l_l1_)
	except: pass
	for seq in range(1,l11llll1lll1_l1_+1):
		filename = l1l1l1l1l11l_l1_.replace(l11ll1_l1_ (u"࠭࡟ࡠࡡࠪ䕬"),l11ll1_l1_ (u"ࠧࡠࠩ䕭")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠨࡡࠪ䕮")+str(seq))
		l1lll111l1ll_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1lll111l1ll_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11ll1_l1_ (u"ࠩࠪ䕯"),l11ll1_l1_ (u"ࠪࠫ䕰"),l11ll1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕱"),l11ll1_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䕲"))
	return
def DELETE_OLD_MENUS_CACHE(l1lll111l11l_l1_):
	trans_provider = settings.getSetting(l11ll1_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭䕳"))
	trans_code = settings.getSetting(l11ll1_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ䕴"))
	DELETE_FROM_SQL3(main_dbfile,l11ll1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ䕵")+trans_provider+l11ll1_l1_ (u"ࠩࡢࠫ䕶")+trans_code,l11ll1_l1_ (u"ࠪࠩࡤࡓࡕࠨ䕷")+l1lll111l11l_l1_+l11ll1_l1_ (u"ࠫࡤࠫࠧ䕸"))
	return
COUNTRIES_CODES = {
		 l11ll1_l1_ (u"ࠬࡇࡆࠨ䕹"):l11ll1_l1_ (u"࠭ࡁࡧࡩ࡫ࡥࡳ࡯ࡳࡵࡣࡱࠫ䕺")
		,l11ll1_l1_ (u"ࠧࡂࡎࠪ䕻"):l11ll1_l1_ (u"ࠨࡃ࡯ࡦࡦࡴࡩࡢࠩ䕼")
		,l11ll1_l1_ (u"ࠩࡇ࡞ࠬ䕽"):l11ll1_l1_ (u"ࠪࡅࡱ࡭ࡥࡳ࡫ࡤࠫ䕾")
		,l11ll1_l1_ (u"ࠫࡆ࡙ࠧ䕿"):l11ll1_l1_ (u"ࠬࡇ࡭ࡦࡴ࡬ࡧࡦࡴࠠࡔࡣࡰࡳࡦ࠭䖀")
		,l11ll1_l1_ (u"࠭ࡁࡅࠩ䖁"):l11ll1_l1_ (u"ࠧࡂࡰࡧࡳࡷࡸࡡࠨ䖂")
		,l11ll1_l1_ (u"ࠨࡃࡒࠫ䖃"):l11ll1_l1_ (u"ࠩࡄࡲ࡬ࡵ࡬ࡢࠩ䖄")
		,l11ll1_l1_ (u"ࠪࡅࡎ࠭䖅"):l11ll1_l1_ (u"ࠫࡆࡴࡧࡶ࡫࡯ࡰࡦ࠭䖆")
		,l11ll1_l1_ (u"ࠬࡇࡑࠨ䖇"):l11ll1_l1_ (u"࠭ࡁ࡯ࡶࡤࡶࡨࡺࡩࡤࡣࠪ䖈")
		,l11ll1_l1_ (u"ࠧࡂࡉࠪ䖉"):l11ll1_l1_ (u"ࠨࡃࡱࡸ࡮࡭ࡵࡢࠢࡤࡲࡩࠦࡂࡢࡴࡥࡹࡩࡧࠧ䖊")
		,l11ll1_l1_ (u"ࠩࡄࡖࠬ䖋"):l11ll1_l1_ (u"ࠪࡅࡷ࡭ࡥ࡯ࡶ࡬ࡲࡦ࠭䖌")
		,l11ll1_l1_ (u"ࠫࡆࡓࠧ䖍"):l11ll1_l1_ (u"ࠬࡇࡲ࡮ࡧࡱ࡭ࡦ࠭䖎")
		,l11ll1_l1_ (u"࠭ࡁࡘࠩ䖏"):l11ll1_l1_ (u"ࠧࡂࡴࡸࡦࡦ࠭䖐")
		,l11ll1_l1_ (u"ࠨࡃࡘࠫ䖑"):l11ll1_l1_ (u"ࠩࡄࡹࡸࡺࡲࡢ࡮࡬ࡥࠬ䖒")
		,l11ll1_l1_ (u"ࠪࡅ࡙࠭䖓"):l11ll1_l1_ (u"ࠫࡆࡻࡳࡵࡴ࡬ࡥࠬ䖔")
		,l11ll1_l1_ (u"ࠬࡇ࡚ࠨ䖕"):l11ll1_l1_ (u"࠭ࡁࡻࡧࡵࡦࡦ࡯ࡪࡢࡰࠪ䖖")
		,l11ll1_l1_ (u"ࠧࡃࡕࠪ䖗"):l11ll1_l1_ (u"ࠨࡄࡤ࡬ࡦࡳࡡࡴࠩ䖘")
		,l11ll1_l1_ (u"ࠩࡅࡌࠬ䖙"):l11ll1_l1_ (u"ࠪࡆࡦ࡮ࡲࡢ࡫ࡱࠫ䖚")
		,l11ll1_l1_ (u"ࠫࡇࡊࠧ䖛"):l11ll1_l1_ (u"ࠬࡈࡡ࡯ࡩ࡯ࡥࡩ࡫ࡳࡩࠩ䖜")
		,l11ll1_l1_ (u"࠭ࡂࡃࠩ䖝"):l11ll1_l1_ (u"ࠧࡃࡣࡵࡦࡦࡪ࡯ࡴࠩ䖞")
		,l11ll1_l1_ (u"ࠨࡄ࡜ࠫ䖟"):l11ll1_l1_ (u"ࠩࡅࡩࡱࡧࡲࡶࡵࠪ䖠")
		,l11ll1_l1_ (u"ࠪࡆࡊ࠭䖡"):l11ll1_l1_ (u"ࠫࡇ࡫࡬ࡨ࡫ࡸࡱࠬ䖢")
		,l11ll1_l1_ (u"ࠬࡈ࡚ࠨ䖣"):l11ll1_l1_ (u"࠭ࡂࡦ࡮࡬ࡾࡪ࠭䖤")
		,l11ll1_l1_ (u"ࠧࡃࡌࠪ䖥"):l11ll1_l1_ (u"ࠨࡄࡨࡲ࡮ࡴࠧ䖦")
		,l11ll1_l1_ (u"ࠩࡅࡑࠬ䖧"):l11ll1_l1_ (u"ࠪࡆࡪࡸ࡭ࡶࡦࡤࠫ䖨")
		,l11ll1_l1_ (u"ࠫࡇ࡚ࠧ䖩"):l11ll1_l1_ (u"ࠬࡈࡨࡶࡶࡤࡲࠬ䖪")
		,l11ll1_l1_ (u"࠭ࡂࡐࠩ䖫"):l11ll1_l1_ (u"ࠧࡃࡱ࡯࡭ࡻ࡯ࡡࠨ䖬")
		,l11ll1_l1_ (u"ࠨࡄࡔࠫ䖭"):l11ll1_l1_ (u"ࠩࡅࡳࡳࡧࡩࡳࡧࠪ䖮")
		,l11ll1_l1_ (u"ࠪࡆࡆ࠭䖯"):l11ll1_l1_ (u"ࠫࡇࡵࡳ࡯࡫ࡤࠤࡦࡴࡤࠡࡊࡨࡶࡿ࡫ࡧࡰࡸ࡬ࡲࡦ࠭䖰")
		,l11ll1_l1_ (u"ࠬࡈࡗࠨ䖱"):l11ll1_l1_ (u"࠭ࡂࡰࡶࡶࡻࡦࡴࡡࠨ䖲")
		,l11ll1_l1_ (u"ࠧࡃࡘࠪ䖳"):l11ll1_l1_ (u"ࠨࡄࡲࡹࡻ࡫ࡴࠡࡋࡶࡰࡦࡴࡤࠨ䖴")
		,l11ll1_l1_ (u"ࠩࡅࡖࠬ䖵"):l11ll1_l1_ (u"ࠪࡆࡷࡧࡺࡪ࡮ࠪ䖶")
		,l11ll1_l1_ (u"ࠫࡎࡕࠧ䖷"):l11ll1_l1_ (u"ࠬࡈࡲࡪࡶ࡬ࡷ࡭ࠦࡉ࡯ࡦ࡬ࡥࡳࠦࡏࡤࡧࡤࡲ࡚ࠥࡥࡳࡴ࡬ࡸࡴࡸࡹࠨ䖸")
		,l11ll1_l1_ (u"࠭ࡖࡈࠩ䖹"):l11ll1_l1_ (u"ࠧࡃࡴ࡬ࡸ࡮ࡹࡨࠡࡘ࡬ࡶ࡬࡯࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ䖺")
		,l11ll1_l1_ (u"ࠨࡄࡑࠫ䖻"):l11ll1_l1_ (u"ࠩࡅࡶࡺࡴࡥࡪࠩ䖼")
		,l11ll1_l1_ (u"ࠪࡆࡌ࠭䖽"):l11ll1_l1_ (u"ࠫࡇࡻ࡬ࡨࡣࡵ࡭ࡦ࠭䖾")
		,l11ll1_l1_ (u"ࠬࡈࡆࠨ䖿"):l11ll1_l1_ (u"࠭ࡂࡶࡴ࡮࡭ࡳࡧࠠࡇࡣࡶࡳࠬ䗀")
		,l11ll1_l1_ (u"ࠧࡃࡋࠪ䗁"):l11ll1_l1_ (u"ࠨࡄࡸࡶࡺࡴࡤࡪࠩ䗂")
		,l11ll1_l1_ (u"ࠩࡎࡌࠬ䗃"):l11ll1_l1_ (u"ࠪࡇࡦࡳࡢࡰࡦ࡬ࡥࠬ䗄")
		,l11ll1_l1_ (u"ࠫࡈࡓࠧ䗅"):l11ll1_l1_ (u"ࠬࡉࡡ࡮ࡧࡵࡳࡴࡴࠧ䗆")
		,l11ll1_l1_ (u"࠭ࡃࡂࠩ䗇"):l11ll1_l1_ (u"ࠧࡄࡣࡱࡥࡩࡧࠧ䗈")
		,l11ll1_l1_ (u"ࠨࡅ࡙ࠫ䗉"):l11ll1_l1_ (u"ࠩࡆࡥࡵ࡫ࠠࡗࡧࡵࡨࡪ࠭䗊")
		,l11ll1_l1_ (u"ࠪࡏ࡞࠭䗋"):l11ll1_l1_ (u"ࠫࡈࡧࡹ࡮ࡣࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䗌")
		,l11ll1_l1_ (u"ࠬࡉࡆࠨ䗍"):l11ll1_l1_ (u"࠭ࡃࡦࡰࡷࡶࡦࡲࠠࡂࡨࡵ࡭ࡨࡧ࡮ࠡࡔࡨࡴࡺࡨ࡬ࡪࡥࠪ䗎")
		,l11ll1_l1_ (u"ࠧࡕࡆࠪ䗏"):l11ll1_l1_ (u"ࠨࡅ࡫ࡥࡩ࠭䗐")
		,l11ll1_l1_ (u"ࠩࡆࡐࠬ䗑"):l11ll1_l1_ (u"ࠪࡇ࡭࡯࡬ࡦࠩ䗒")
		,l11ll1_l1_ (u"ࠫࡈࡔࠧ䗓"):l11ll1_l1_ (u"ࠬࡉࡨࡪࡰࡤࠫ䗔")
		,l11ll1_l1_ (u"࠭ࡃ࡙ࠩ䗕"):l11ll1_l1_ (u"ࠧࡄࡪࡵ࡭ࡸࡺ࡭ࡢࡵࠣࡍࡸࡲࡡ࡯ࡦࠪ䗖")
		,l11ll1_l1_ (u"ࠨࡅࡆࠫ䗗"):l11ll1_l1_ (u"ࠩࡆࡳࡨࡵࡳࠡࠪࡎࡩࡪࡲࡩ࡯ࡩࠬࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䗘")
		,l11ll1_l1_ (u"ࠪࡇࡔ࠭䗙"):l11ll1_l1_ (u"ࠫࡈࡵ࡬ࡰ࡯ࡥ࡭ࡦ࠭䗚")
		,l11ll1_l1_ (u"ࠬࡑࡍࠨ䗛"):l11ll1_l1_ (u"࠭ࡃࡰ࡯ࡲࡶࡴࡹࠧ䗜")
		,l11ll1_l1_ (u"ࠧࡄࡍࠪ䗝"):l11ll1_l1_ (u"ࠨࡅࡲࡳࡰࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䗞")
		,l11ll1_l1_ (u"ࠩࡆࡖࠬ䗟"):l11ll1_l1_ (u"ࠪࡇࡴࡹࡴࡢࠢࡕ࡭ࡨࡧࠧ䗠")
		,l11ll1_l1_ (u"ࠫࡍࡘࠧ䗡"):l11ll1_l1_ (u"ࠬࡉࡲࡰࡣࡷ࡭ࡦ࠭䗢")
		,l11ll1_l1_ (u"࠭ࡃࡖࠩ䗣"):l11ll1_l1_ (u"ࠧࡄࡷࡥࡥࠬ䗤")
		,l11ll1_l1_ (u"ࠨࡅ࡚ࠫ䗥"):l11ll1_l1_ (u"ࠩࡆࡹࡷࡧࡣࡢࡱࠪ䗦")
		,l11ll1_l1_ (u"ࠪࡇ࡞࠭䗧"):l11ll1_l1_ (u"ࠫࡈࡿࡰࡳࡷࡶࠫ䗨")
		,l11ll1_l1_ (u"ࠬࡉ࡚ࠨ䗩"):l11ll1_l1_ (u"࠭ࡃࡻࡧࡦ࡬ࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䗪")
		,l11ll1_l1_ (u"ࠧࡄࡆࠪ䗫"):l11ll1_l1_ (u"ࠨࡆࡨࡱࡴࡩࡲࡢࡶ࡬ࡧࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡄࡱࡱ࡫ࡴ࠭䗬")
		,l11ll1_l1_ (u"ࠩࡇࡏࠬ䗭"):l11ll1_l1_ (u"ࠪࡈࡪࡴ࡭ࡢࡴ࡮ࠫ䗮")
		,l11ll1_l1_ (u"ࠫࡉࡐࠧ䗯"):l11ll1_l1_ (u"ࠬࡊࡪࡪࡤࡲࡹࡹ࡯ࠧ䗰")
		,l11ll1_l1_ (u"࠭ࡄࡎࠩ䗱"):l11ll1_l1_ (u"ࠧࡅࡱࡰ࡭ࡳ࡯ࡣࡢࠩ䗲")
		,l11ll1_l1_ (u"ࠨࡆࡒࠫ䗳"):l11ll1_l1_ (u"ࠩࡇࡳࡲ࡯࡮ࡪࡥࡤࡲࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䗴")
		,l11ll1_l1_ (u"ࠪࡘࡑ࠭䗵"):l11ll1_l1_ (u"ࠫࡊࡧࡳࡵࠢࡗ࡭ࡲࡵࡲࠨ䗶")
		,l11ll1_l1_ (u"ࠬࡋࡃࠨ䗷"):l11ll1_l1_ (u"࠭ࡅࡤࡷࡤࡨࡴࡸࠧ䗸")
		,l11ll1_l1_ (u"ࠧࡆࡉࠪ䗹"):l11ll1_l1_ (u"ࠨࡇࡪࡽࡵࡺࠧ䗺")
		,l11ll1_l1_ (u"ࠩࡖ࡚ࠬ䗻"):l11ll1_l1_ (u"ࠪࡉࡱࠦࡓࡢ࡮ࡹࡥࡩࡵࡲࠨ䗼")
		,l11ll1_l1_ (u"ࠫࡌࡗࠧ䗽"):l11ll1_l1_ (u"ࠬࡋࡱࡶࡣࡷࡳࡷ࡯ࡡ࡭ࠢࡊࡹ࡮ࡴࡥࡢࠩ䗾")
		,l11ll1_l1_ (u"࠭ࡅࡓࠩ䗿"):l11ll1_l1_ (u"ࠧࡆࡴ࡬ࡸࡷ࡫ࡡࠨ䘀")
		,l11ll1_l1_ (u"ࠨࡇࡈࠫ䘁"):l11ll1_l1_ (u"ࠩࡈࡷࡹࡵ࡮ࡪࡣࠪ䘂")
		,l11ll1_l1_ (u"ࠪࡉ࡙࠭䘃"):l11ll1_l1_ (u"ࠫࡊࡺࡨࡪࡱࡳ࡭ࡦ࠭䘄")
		,l11ll1_l1_ (u"ࠬࡌࡋࠨ䘅"):l11ll1_l1_ (u"࠭ࡆࡢ࡮࡮ࡰࡦࡴࡤࠡࡋࡶࡰࡦࡴࡤࡴࠩ䘆")
		,l11ll1_l1_ (u"ࠧࡇࡑࠪ䘇"):l11ll1_l1_ (u"ࠨࡈࡤࡶࡴ࡫ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ䘈")
		,l11ll1_l1_ (u"ࠩࡉࡎࠬ䘉"):l11ll1_l1_ (u"ࠪࡊ࡮ࡰࡩࠨ䘊")
		,l11ll1_l1_ (u"ࠫࡋࡏࠧ䘋"):l11ll1_l1_ (u"ࠬࡌࡩ࡯࡮ࡤࡲࡩ࠭䘌")
		,l11ll1_l1_ (u"࠭ࡆࡓࠩ䘍"):l11ll1_l1_ (u"ࠧࡇࡴࡤࡲࡨ࡫ࠧ䘎")
		,l11ll1_l1_ (u"ࠨࡉࡉࠫ䘏"):l11ll1_l1_ (u"ࠩࡉࡶࡪࡴࡣࡩࠢࡊࡹ࡮ࡧ࡮ࡢࠩ䘐")
		,l11ll1_l1_ (u"ࠪࡔࡋ࠭䘑"):l11ll1_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡕࡵ࡬ࡺࡰࡨࡷ࡮ࡧࠧ䘒")
		,l11ll1_l1_ (u"࡚ࠬࡆࠨ䘓"):l11ll1_l1_ (u"࠭ࡆࡳࡧࡱࡧ࡭ࠦࡓࡰࡷࡷ࡬ࡪࡸ࡮ࠡࡖࡨࡶࡷ࡯ࡴࡰࡴ࡬ࡩࡸ࠭䘔")
		,l11ll1_l1_ (u"ࠧࡈࡃࠪ䘕"):l11ll1_l1_ (u"ࠨࡉࡤࡦࡴࡴࠧ䘖")
		,l11ll1_l1_ (u"ࠩࡊࡑࠬ䘗"):l11ll1_l1_ (u"ࠪࡋࡦࡳࡢࡪࡣࠪ䘘")
		,l11ll1_l1_ (u"ࠫࡌࡋࠧ䘙"):l11ll1_l1_ (u"ࠬࡍࡥࡰࡴࡪ࡭ࡦ࠭䘚")
		,l11ll1_l1_ (u"࠭ࡄࡆࠩ䘛"):l11ll1_l1_ (u"ࠧࡈࡧࡵࡱࡦࡴࡹࠨ䘜")
		,l11ll1_l1_ (u"ࠨࡉࡋࠫ䘝"):l11ll1_l1_ (u"ࠩࡊ࡬ࡦࡴࡡࠨ䘞")
		,l11ll1_l1_ (u"ࠪࡋࡎ࠭䘟"):l11ll1_l1_ (u"ࠫࡌ࡯ࡢࡳࡣ࡯ࡸࡦࡸࠧ䘠")
		,l11ll1_l1_ (u"ࠬࡍࡒࠨ䘡"):l11ll1_l1_ (u"࠭ࡇࡳࡧࡨࡧࡪ࠭䘢")
		,l11ll1_l1_ (u"ࠧࡈࡎࠪ䘣"):l11ll1_l1_ (u"ࠨࡉࡵࡩࡪࡴ࡬ࡢࡰࡧࠫ䘤")
		,l11ll1_l1_ (u"ࠩࡊࡈࠬ䘥"):l11ll1_l1_ (u"ࠪࡋࡷ࡫࡮ࡢࡦࡤࠫ䘦")
		,l11ll1_l1_ (u"ࠫࡌࡖࠧ䘧"):l11ll1_l1_ (u"ࠬࡍࡵࡢࡦࡨࡰࡴࡻࡰࡦࠩ䘨")
		,l11ll1_l1_ (u"࠭ࡇࡖࠩ䘩"):l11ll1_l1_ (u"ࠧࡈࡷࡤࡱࠬ䘪")
		,l11ll1_l1_ (u"ࠨࡉࡗࠫ䘫"):l11ll1_l1_ (u"ࠩࡊࡹࡦࡺࡥ࡮ࡣ࡯ࡥࠬ䘬")
		,l11ll1_l1_ (u"ࠪࡋࡌ࠭䘭"):l11ll1_l1_ (u"ࠫࡌࡻࡥࡳࡰࡶࡩࡾ࠭䘮")
		,l11ll1_l1_ (u"ࠬࡍࡎࠨ䘯"):l11ll1_l1_ (u"࠭ࡇࡶ࡫ࡱࡩࡦ࠭䘰")
		,l11ll1_l1_ (u"ࠧࡈ࡙ࠪ䘱"):l11ll1_l1_ (u"ࠨࡉࡸ࡭ࡳ࡫ࡡ࠮ࡄ࡬ࡷࡸࡧࡵࠨ䘲")
		,l11ll1_l1_ (u"ࠩࡊ࡝ࠬ䘳"):l11ll1_l1_ (u"ࠪࡋࡺࡿࡡ࡯ࡣࠪ䘴")
		,l11ll1_l1_ (u"ࠫࡍ࡚ࠧ䘵"):l11ll1_l1_ (u"ࠬࡎࡡࡪࡶ࡬ࠫ䘶")
		,l11ll1_l1_ (u"࠭ࡈࡎࠩ䘷"):l11ll1_l1_ (u"ࠧࡉࡧࡤࡶࡩࠦࡉࡴ࡮ࡤࡲࡩࠦࡡ࡯ࡦࠣࡑࡨࡊ࡯࡯ࡣ࡯ࡨࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䘸")
		,l11ll1_l1_ (u"ࠨࡊࡑࠫ䘹"):l11ll1_l1_ (u"ࠩࡋࡳࡳࡪࡵࡳࡣࡶࠫ䘺")
		,l11ll1_l1_ (u"ࠪࡌࡐ࠭䘻"):l11ll1_l1_ (u"ࠫࡍࡵ࡮ࡨࠢࡎࡳࡳ࡭ࠧ䘼")
		,l11ll1_l1_ (u"ࠬࡎࡕࠨ䘽"):l11ll1_l1_ (u"࠭ࡈࡶࡰࡪࡥࡷࡿࠧ䘾")
		,l11ll1_l1_ (u"ࠧࡊࡕࠪ䘿"):l11ll1_l1_ (u"ࠨࡋࡦࡩࡱࡧ࡮ࡥࠩ䙀")
		,l11ll1_l1_ (u"ࠩࡌࡒࠬ䙁"):l11ll1_l1_ (u"ࠪࡍࡳࡪࡩࡢࠩ䙂")
		,l11ll1_l1_ (u"ࠫࡎࡊࠧ䙃"):l11ll1_l1_ (u"ࠬࡏ࡮ࡥࡱࡱࡩࡸ࡯ࡡࠨ䙄")
		,l11ll1_l1_ (u"࠭ࡉࡓࠩ䙅"):l11ll1_l1_ (u"ࠧࡊࡴࡤࡲࠬ䙆")
		,l11ll1_l1_ (u"ࠨࡋࡔࠫ䙇"):l11ll1_l1_ (u"ࠩࡌࡶࡦࡷࠧ䙈")
		,l11ll1_l1_ (u"ࠪࡍࡊ࠭䙉"):l11ll1_l1_ (u"ࠫࡎࡸࡥ࡭ࡣࡱࡨࠬ䙊")
		,l11ll1_l1_ (u"ࠬࡏࡍࠨ䙋"):l11ll1_l1_ (u"࠭ࡉࡴ࡮ࡨࠤࡴ࡬ࠠࡎࡣࡱࠫ䙌")
		,l11ll1_l1_ (u"ࠧࡊࡎࠪ䙍"):l11ll1_l1_ (u"ࠨࡋࡶࡶࡦ࡫࡬ࠨ䙎")
		,l11ll1_l1_ (u"ࠩࡌࡘࠬ䙏"):l11ll1_l1_ (u"ࠪࡍࡹࡧ࡬ࡺࠩ䙐")
		,l11ll1_l1_ (u"ࠫࡈࡏࠧ䙑"):l11ll1_l1_ (u"ࠬࡏࡶࡰࡴࡼࠤࡈࡵࡡࡴࡶࠪ䙒")
		,l11ll1_l1_ (u"࠭ࡊࡎࠩ䙓"):l11ll1_l1_ (u"ࠧࡋࡣࡰࡥ࡮ࡩࡡࠨ䙔")
		,l11ll1_l1_ (u"ࠨࡌࡓࠫ䙕"):l11ll1_l1_ (u"ࠩࡍࡥࡵࡧ࡮ࠨ䙖")
		,l11ll1_l1_ (u"ࠪࡎࡊ࠭䙗"):l11ll1_l1_ (u"ࠫࡏ࡫ࡲࡴࡧࡼࠫ䙘")
		,l11ll1_l1_ (u"ࠬࡐࡏࠨ䙙"):l11ll1_l1_ (u"࠭ࡊࡰࡴࡧࡥࡳ࠭䙚")
		,l11ll1_l1_ (u"ࠧࡌ࡜ࠪ䙛"):l11ll1_l1_ (u"ࠨࡍࡤࡾࡦࡱࡨࡴࡶࡤࡲࠬ䙜")
		,l11ll1_l1_ (u"ࠩࡎࡉࠬ䙝"):l11ll1_l1_ (u"ࠪࡏࡪࡴࡹࡢࠩ䙞")
		,l11ll1_l1_ (u"ࠫࡐࡏࠧ䙟"):l11ll1_l1_ (u"ࠬࡑࡩࡳ࡫ࡥࡥࡹ࡯ࠧ䙠")
		,l11ll1_l1_ (u"࠭ࡘࡌࠩ䙡"):l11ll1_l1_ (u"ࠧࡌࡱࡶࡳࡻࡵࠧ䙢")
		,l11ll1_l1_ (u"ࠨࡍ࡚ࠫ䙣"):l11ll1_l1_ (u"ࠩࡎࡹࡼࡧࡩࡵࠩ䙤")
		,l11ll1_l1_ (u"ࠪࡏࡌ࠭䙥"):l11ll1_l1_ (u"ࠫࡐࡿࡲࡨࡻࡽࡷࡹࡧ࡮ࠨ䙦")
		,l11ll1_l1_ (u"ࠬࡒࡁࠨ䙧"):l11ll1_l1_ (u"࠭ࡌࡢࡱࡶࠫ䙨")
		,l11ll1_l1_ (u"ࠧࡍࡘࠪ䙩"):l11ll1_l1_ (u"ࠨࡎࡤࡸࡻ࡯ࡡࠨ䙪")
		,l11ll1_l1_ (u"ࠩࡏࡆࠬ䙫"):l11ll1_l1_ (u"ࠪࡐࡪࡨࡡ࡯ࡱࡱࠫ䙬")
		,l11ll1_l1_ (u"ࠫࡑ࡙ࠧ䙭"):l11ll1_l1_ (u"ࠬࡒࡥࡴࡱࡷ࡬ࡴ࠭䙮")
		,l11ll1_l1_ (u"࠭ࡌࡓࠩ䙯"):l11ll1_l1_ (u"ࠧࡍ࡫ࡥࡩࡷ࡯ࡡࠨ䙰")
		,l11ll1_l1_ (u"ࠨࡎ࡜ࠫ䙱"):l11ll1_l1_ (u"ࠩࡏ࡭ࡧࡿࡡࠨ䙲")
		,l11ll1_l1_ (u"ࠪࡐࡎ࠭䙳"):l11ll1_l1_ (u"ࠫࡑ࡯ࡥࡤࡪࡷࡩࡳࡹࡴࡦ࡫ࡱࠫ䙴")
		,l11ll1_l1_ (u"ࠬࡒࡔࠨ䙵"):l11ll1_l1_ (u"࠭ࡌࡪࡶ࡫ࡹࡦࡴࡩࡢࠩ䙶")
		,l11ll1_l1_ (u"ࠧࡍࡗࠪ䙷"):l11ll1_l1_ (u"ࠨࡎࡸࡼࡪࡳࡢࡰࡷࡵ࡫ࠬ䙸")
		,l11ll1_l1_ (u"ࠩࡐࡓࠬ䙹"):l11ll1_l1_ (u"ࠪࡑࡦࡩࡡࡰࠩ䙺")
		,l11ll1_l1_ (u"ࠫࡒࡍࠧ䙻"):l11ll1_l1_ (u"ࠬࡓࡡࡥࡣࡪࡥࡸࡩࡡࡳࠩ䙼")
		,l11ll1_l1_ (u"࠭ࡍࡘࠩ䙽"):l11ll1_l1_ (u"ࠧࡎࡣ࡯ࡥࡼ࡯ࠧ䙾")
		,l11ll1_l1_ (u"ࠨࡏ࡜ࠫ䙿"):l11ll1_l1_ (u"ࠩࡐࡥࡱࡧࡹࡴ࡫ࡤࠫ䚀")
		,l11ll1_l1_ (u"ࠪࡑ࡛࠭䚁"):l11ll1_l1_ (u"ࠫࡒࡧ࡬ࡥ࡫ࡹࡩࡸ࠭䚂")
		,l11ll1_l1_ (u"ࠬࡓࡌࠨ䚃"):l11ll1_l1_ (u"࠭ࡍࡢ࡮࡬ࠫ䚄")
		,l11ll1_l1_ (u"ࠧࡎࡖࠪ䚅"):l11ll1_l1_ (u"ࠨࡏࡤࡰࡹࡧࠧ䚆")
		,l11ll1_l1_ (u"ࠩࡐࡌࠬ䚇"):l11ll1_l1_ (u"ࠪࡑࡦࡸࡳࡩࡣ࡯ࡰࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䚈")
		,l11ll1_l1_ (u"ࠫࡒࡗࠧ䚉"):l11ll1_l1_ (u"ࠬࡓࡡࡳࡶ࡬ࡲ࡮ࡷࡵࡦࠩ䚊")
		,l11ll1_l1_ (u"࠭ࡍࡓࠩ䚋"):l11ll1_l1_ (u"ࠧࡎࡣࡸࡶ࡮ࡺࡡ࡯࡫ࡤࠫ䚌")
		,l11ll1_l1_ (u"ࠨࡏࡘࠫ䚍"):l11ll1_l1_ (u"ࠩࡐࡥࡺࡸࡩࡵ࡫ࡸࡷࠬ䚎")
		,l11ll1_l1_ (u"ࠪ࡝࡙࠭䚏"):l11ll1_l1_ (u"ࠫࡒࡧࡹࡰࡶࡷࡩࠬ䚐")
		,l11ll1_l1_ (u"ࠬࡓࡘࠨ䚑"):l11ll1_l1_ (u"࠭ࡍࡦࡺ࡬ࡧࡴ࠭䚒")
		,l11ll1_l1_ (u"ࠧࡇࡏࠪ䚓"):l11ll1_l1_ (u"ࠨࡏ࡬ࡧࡷࡵ࡮ࡦࡵ࡬ࡥࠬ䚔")
		,l11ll1_l1_ (u"ࠩࡐࡈࠬ䚕"):l11ll1_l1_ (u"ࠪࡑࡴࡲࡤࡰࡸࡤࠫ䚖")
		,l11ll1_l1_ (u"ࠫࡒࡉࠧ䚗"):l11ll1_l1_ (u"ࠬࡓ࡯࡯ࡣࡦࡳࠬ䚘")
		,l11ll1_l1_ (u"࠭ࡍࡏࠩ䚙"):l11ll1_l1_ (u"ࠧࡎࡱࡱ࡫ࡴࡲࡩࡢࠩ䚚")
		,l11ll1_l1_ (u"ࠨࡏࡈࠫ䚛"):l11ll1_l1_ (u"ࠩࡐࡳࡳࡺࡥ࡯ࡧࡪࡶࡴ࠭䚜")
		,l11ll1_l1_ (u"ࠪࡑࡘ࠭䚝"):l11ll1_l1_ (u"ࠫࡒࡵ࡮ࡵࡵࡨࡶࡷࡧࡴࠨ䚞")
		,l11ll1_l1_ (u"ࠬࡓࡁࠨ䚟"):l11ll1_l1_ (u"࠭ࡍࡰࡴࡲࡧࡨࡵࠧ䚠")
		,l11ll1_l1_ (u"ࠧࡎ࡜ࠪ䚡"):l11ll1_l1_ (u"ࠨࡏࡲࡾࡦࡳࡢࡪࡳࡸࡩࠬ䚢")
		,l11ll1_l1_ (u"ࠩࡐࡑࠬ䚣"):l11ll1_l1_ (u"ࠪࡑࡾࡧ࡮࡮ࡣࡵࠤ࠭ࡈࡵࡳ࡯ࡤ࠭ࠬ䚤")
		,l11ll1_l1_ (u"ࠫࡓࡇࠧ䚥"):l11ll1_l1_ (u"ࠬࡔࡡ࡮࡫ࡥ࡭ࡦ࠭䚦")
		,l11ll1_l1_ (u"࠭ࡎࡓࠩ䚧"):l11ll1_l1_ (u"ࠧࡏࡣࡸࡶࡺ࠭䚨")
		,l11ll1_l1_ (u"ࠨࡐࡓࠫ䚩"):l11ll1_l1_ (u"ࠩࡑࡩࡵࡧ࡬ࠨ䚪")
		,l11ll1_l1_ (u"ࠪࡒࡑ࠭䚫"):l11ll1_l1_ (u"ࠫࡓ࡫ࡴࡩࡧࡵࡰࡦࡴࡤࡴࠩ䚬")
		,l11ll1_l1_ (u"ࠬࡔࡃࠨ䚭"):l11ll1_l1_ (u"࠭ࡎࡦࡹࠣࡇࡦࡲࡥࡥࡱࡱ࡭ࡦ࠭䚮")
		,l11ll1_l1_ (u"ࠧࡏ࡜ࠪ䚯"):l11ll1_l1_ (u"ࠨࡐࡨࡻࠥࡠࡥࡢ࡮ࡤࡲࡩ࠭䚰")
		,l11ll1_l1_ (u"ࠩࡑࡍࠬ䚱"):l11ll1_l1_ (u"ࠪࡒ࡮ࡩࡡࡳࡣࡪࡹࡦ࠭䚲")
		,l11ll1_l1_ (u"ࠫࡓࡋࠧ䚳"):l11ll1_l1_ (u"ࠬࡔࡩࡨࡧࡵࠫ䚴")
		,l11ll1_l1_ (u"࠭ࡎࡈࠩ䚵"):l11ll1_l1_ (u"ࠧࡏ࡫ࡪࡩࡷ࡯ࡡࠨ䚶")
		,l11ll1_l1_ (u"ࠨࡐࡘࠫ䚷"):l11ll1_l1_ (u"ࠩࡑ࡭ࡺ࡫ࠧ䚸")
		,l11ll1_l1_ (u"ࠪࡒࡋ࠭䚹"):l11ll1_l1_ (u"ࠫࡓࡵࡲࡧࡱ࡯࡯ࠥࡏࡳ࡭ࡣࡱࡨࠬ䚺")
		,l11ll1_l1_ (u"ࠬࡑࡐࠨ䚻"):l11ll1_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ䚼")
		,l11ll1_l1_ (u"ࠧࡎࡍࠪ䚽"):l11ll1_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ䚾")
		,l11ll1_l1_ (u"ࠩࡐࡔࠬ䚿"):l11ll1_l1_ (u"ࠪࡒࡴࡸࡴࡩࡧࡵࡲࠥࡓࡡࡳ࡫ࡤࡲࡦࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䛀")
		,l11ll1_l1_ (u"ࠫࡓࡕࠧ䛁"):l11ll1_l1_ (u"ࠬࡔ࡯ࡳࡹࡤࡽࠬ䛂")
		,l11ll1_l1_ (u"࠭ࡏࡎࠩ䛃"):l11ll1_l1_ (u"ࠧࡐ࡯ࡤࡲࠬ䛄")
		,l11ll1_l1_ (u"ࠨࡒࡎࠫ䛅"):l11ll1_l1_ (u"ࠩࡓࡥࡰ࡯ࡳࡵࡣࡱࠫ䛆")
		,l11ll1_l1_ (u"ࠪࡔ࡜࠭䛇"):l11ll1_l1_ (u"ࠫࡕࡧ࡬ࡢࡷࠪ䛈")
		,l11ll1_l1_ (u"ࠬࡖࡓࠨ䛉"):l11ll1_l1_ (u"࠭ࡐࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䛊")
		,l11ll1_l1_ (u"ࠧࡑࡃࠪ䛋"):l11ll1_l1_ (u"ࠨࡒࡤࡲࡦࡳࡡࠨ䛌")
		,l11ll1_l1_ (u"ࠩࡓࡋࠬ䛍"):l11ll1_l1_ (u"ࠪࡔࡦࡶࡵࡢࠢࡑࡩࡼࠦࡇࡶ࡫ࡱࡩࡦ࠭䛎")
		,l11ll1_l1_ (u"ࠫࡕ࡟ࠧ䛏"):l11ll1_l1_ (u"ࠬࡖࡡࡳࡣࡪࡹࡦࡿࠧ䛐")
		,l11ll1_l1_ (u"࠭ࡐࡆࠩ䛑"):l11ll1_l1_ (u"ࠧࡑࡧࡵࡹࠬ䛒")
		,l11ll1_l1_ (u"ࠨࡒࡋࠫ䛓"):l11ll1_l1_ (u"ࠩࡓ࡬࡮ࡲࡩࡱࡲ࡬ࡲࡪࡹࠧ䛔")
		,l11ll1_l1_ (u"ࠪࡔࡓ࠭䛕"):l11ll1_l1_ (u"ࠫࡕ࡯ࡴࡤࡣ࡬ࡶࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䛖")
		,l11ll1_l1_ (u"ࠬࡖࡌࠨ䛗"):l11ll1_l1_ (u"࠭ࡐࡰ࡮ࡤࡲࡩ࠭䛘")
		,l11ll1_l1_ (u"ࠧࡑࡖࠪ䛙"):l11ll1_l1_ (u"ࠨࡒࡲࡶࡹࡻࡧࡢ࡮ࠪ䛚")
		,l11ll1_l1_ (u"ࠩࡓࡖࠬ䛛"):l11ll1_l1_ (u"ࠪࡔࡺ࡫ࡲࡵࡱࠣࡖ࡮ࡩ࡯ࠨ䛜")
		,l11ll1_l1_ (u"ࠫࡖࡇࠧ䛝"):l11ll1_l1_ (u"ࠬࡗࡡࡵࡣࡵࠫ䛞")
		,l11ll1_l1_ (u"࠭ࡃࡈࠩ䛟"):l11ll1_l1_ (u"ࠧࡓࡧࡳࡹࡧࡲࡩࡤࠢࡲࡪࠥࡺࡨࡦࠢࡆࡳࡳ࡭࡯ࠨ䛠")
		,l11ll1_l1_ (u"ࠨࡔࡒࠫ䛡"):l11ll1_l1_ (u"ࠩࡕࡳࡲࡧ࡮ࡪࡣࠪ䛢")
		,l11ll1_l1_ (u"ࠪࡖ࡚࠭䛣"):l11ll1_l1_ (u"ࠫࡗࡻࡳࡴ࡫ࡤࠫ䛤")
		,l11ll1_l1_ (u"ࠬࡘࡗࠨ䛥"):l11ll1_l1_ (u"࠭ࡒࡸࡣࡱࡨࡦ࠭䛦")
		,l11ll1_l1_ (u"ࠧࡓࡇࠪ䛧"):l11ll1_l1_ (u"ࠨࡔ࣬ࡹࡳ࡯࡯࡯ࠩ䛨")
		,l11ll1_l1_ (u"ࠩࡅࡐࠬ䛩"):l11ll1_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡅࡥࡷࡺࡨ࣪࡮ࡨࡱࡾ࠭䛪")
		,l11ll1_l1_ (u"ࠫࡘࡎࠧ䛫"):l11ll1_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡍ࡫࡬ࡦࡰࡤࠫ䛬")
		,l11ll1_l1_ (u"࠭ࡋࡏࠩ䛭"):l11ll1_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡋࡪࡶࡷࡷࠥࡧ࡮ࡥࠢࡑࡩࡻ࡯ࡳࠨ䛮")
		,l11ll1_l1_ (u"ࠨࡎࡆࠫ䛯"):l11ll1_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡎࡸࡧ࡮ࡧࠧ䛰")
		,l11ll1_l1_ (u"ࠪࡑࡋ࠭䛱"):l11ll1_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡑࡦࡸࡴࡪࡰࠪ䛲")
		,l11ll1_l1_ (u"ࠬࡖࡍࠨ䛳"):l11ll1_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡖࡩࡦࡴࡵࡩࠥࡧ࡮ࡥࠢࡐ࡭ࡶࡻࡥ࡭ࡱࡱࠫ䛴")
		,l11ll1_l1_ (u"ࠧࡗࡅࠪ䛵"):l11ll1_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡗ࡫ࡱࡧࡪࡴࡴࠡࡣࡱࡨࠥࡺࡨࡦࠢࡊࡶࡪࡴࡡࡥ࡫ࡱࡩࡸ࠭䛶")
		,l11ll1_l1_ (u"࡚ࠩࡗࠬ䛷"):l11ll1_l1_ (u"ࠪࡗࡦࡳ࡯ࡢࠩ䛸")
		,l11ll1_l1_ (u"ࠫࡘࡓࠧ䛹"):l11ll1_l1_ (u"࡙ࠬࡡ࡯ࠢࡐࡥࡷ࡯࡮ࡰࠩ䛺")
		,l11ll1_l1_ (u"࠭ࡓࡂࠩ䛻"):l11ll1_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭䛼")
		,l11ll1_l1_ (u"ࠨࡕࡑࠫ䛽"):l11ll1_l1_ (u"ࠩࡖࡩࡳ࡫ࡧࡢ࡮ࠪ䛾")
		,l11ll1_l1_ (u"ࠪࡖࡘ࠭䛿"):l11ll1_l1_ (u"ࠫࡘ࡫ࡲࡣ࡫ࡤࠫ䜀")
		,l11ll1_l1_ (u"࡙ࠬࡃࠨ䜁"):l11ll1_l1_ (u"࠭ࡓࡦࡻࡦ࡬ࡪࡲ࡬ࡦࡵࠪ䜂")
		,l11ll1_l1_ (u"ࠧࡔࡎࠪ䜃"):l11ll1_l1_ (u"ࠨࡕ࡬ࡩࡷࡸࡡࠡࡎࡨࡳࡳ࡫ࠧ䜄")
		,l11ll1_l1_ (u"ࠩࡖࡋࠬ䜅"):l11ll1_l1_ (u"ࠪࡗ࡮ࡴࡧࡢࡲࡲࡶࡪ࠭䜆")
		,l11ll1_l1_ (u"ࠫࡘ࡞ࠧ䜇"):l11ll1_l1_ (u"࡙ࠬࡩ࡯ࡶࠣࡑࡦࡧࡲࡵࡧࡱࠫ䜈")
		,l11ll1_l1_ (u"࠭ࡓࡌࠩ䜉"):l11ll1_l1_ (u"ࠧࡔ࡮ࡲࡺࡦࡱࡩࡢࠩ䜊")
		,l11ll1_l1_ (u"ࠨࡕࡌࠫ䜋"):l11ll1_l1_ (u"ࠩࡖࡰࡴࡼࡥ࡯࡫ࡤࠫ䜌")
		,l11ll1_l1_ (u"ࠪࡗࡇ࠭䜍"):l11ll1_l1_ (u"ࠫࡘࡵ࡬ࡰ࡯ࡲࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䜎")
		,l11ll1_l1_ (u"࡙ࠬࡏࠨ䜏"):l11ll1_l1_ (u"࠭ࡓࡰ࡯ࡤࡰ࡮ࡧࠧ䜐")
		,l11ll1_l1_ (u"࡛ࠧࡃࠪ䜑"):l11ll1_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡂࡨࡵ࡭ࡨࡧࠧ䜒")
		,l11ll1_l1_ (u"ࠩࡊࡗࠬ䜓"):l11ll1_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡊࡩࡴࡸࡧࡪࡣࠣࡥࡳࡪࠠࡵࡪࡨࠤࡘࡵࡵࡵࡪࠣࡗࡦࡴࡤࡸ࡫ࡦ࡬ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䜔")
		,l11ll1_l1_ (u"ࠫࡐࡘࠧ䜕"):l11ll1_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡐࡵࡲࡦࡣࠪ䜖")
		,l11ll1_l1_ (u"࠭ࡓࡔࠩ䜗"):l11ll1_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡓࡶࡦࡤࡲࠬ䜘")
		,l11ll1_l1_ (u"ࠨࡇࡖࠫ䜙"):l11ll1_l1_ (u"ࠩࡖࡴࡦ࡯࡮ࠨ䜚")
		,l11ll1_l1_ (u"ࠪࡐࡐ࠭䜛"):l11ll1_l1_ (u"ࠫࡘࡸࡩࠡࡎࡤࡲࡰࡧࠧ䜜")
		,l11ll1_l1_ (u"࡙ࠬࡄࠨ䜝"):l11ll1_l1_ (u"࠭ࡓࡶࡦࡤࡲࠬ䜞")
		,l11ll1_l1_ (u"ࠧࡔࡔࠪ䜟"):l11ll1_l1_ (u"ࠨࡕࡸࡶ࡮ࡴࡡ࡮ࡧࠪ䜠")
		,l11ll1_l1_ (u"ࠩࡖࡎࠬ䜡"):l11ll1_l1_ (u"ࠪࡗࡻࡧ࡬ࡣࡣࡵࡨࠥࡧ࡮ࡥࠢࡍࡥࡳࠦࡍࡢࡻࡨࡲࠬ䜢")
		,l11ll1_l1_ (u"ࠫࡘࡠࠧ䜣"):l11ll1_l1_ (u"࡙ࠬࡷࡢࡼ࡬ࡰࡦࡴࡤࠨ䜤")
		,l11ll1_l1_ (u"࠭ࡓࡆࠩ䜥"):l11ll1_l1_ (u"ࠧࡔࡹࡨࡨࡪࡴࠧ䜦")
		,l11ll1_l1_ (u"ࠨࡅࡋࠫ䜧"):l11ll1_l1_ (u"ࠩࡖࡻ࡮ࡺࡺࡦࡴ࡯ࡥࡳࡪࠧ䜨")
		,l11ll1_l1_ (u"ࠪࡗ࡞࠭䜩"):l11ll1_l1_ (u"ࠫࡘࡿࡲࡪࡣࠪ䜪")
		,l11ll1_l1_ (u"࡙ࠬࡔࠨ䜫"):l11ll1_l1_ (u"࠭ࡓࣤࡱࠣࡘࡴࡳࣩࠡࡣࡱࡨࠥࡖࡲ࣮ࡰࡦ࡭ࡵ࡫ࠧ䜬")
		,l11ll1_l1_ (u"ࠧࡕ࡙ࠪ䜭"):l11ll1_l1_ (u"ࠨࡖࡤ࡭ࡼࡧ࡮ࠨ䜮")
		,l11ll1_l1_ (u"ࠩࡗࡎࠬ䜯"):l11ll1_l1_ (u"ࠪࡘࡦࡰࡩ࡬࡫ࡶࡸࡦࡴࠧ䜰")
		,l11ll1_l1_ (u"࡙ࠫࡠࠧ䜱"):l11ll1_l1_ (u"࡚ࠬࡡ࡯ࡼࡤࡲ࡮ࡧࠧ䜲")
		,l11ll1_l1_ (u"࠭ࡔࡉࠩ䜳"):l11ll1_l1_ (u"ࠧࡕࡪࡤ࡭ࡱࡧ࡮ࡥࠩ䜴")
		,l11ll1_l1_ (u"ࠨࡖࡊࠫ䜵"):l11ll1_l1_ (u"ࠩࡗࡳ࡬ࡵࠧ䜶")
		,l11ll1_l1_ (u"ࠪࡘࡐ࠭䜷"):l11ll1_l1_ (u"࡙ࠫࡵ࡫ࡦ࡮ࡤࡹࠬ䜸")
		,l11ll1_l1_ (u"࡚ࠬࡏࠨ䜹"):l11ll1_l1_ (u"࠭ࡔࡰࡰࡪࡥࠬ䜺")
		,l11ll1_l1_ (u"ࠧࡕࡖࠪ䜻"):l11ll1_l1_ (u"ࠨࡖࡵ࡭ࡳ࡯ࡤࡢࡦࠣࡥࡳࡪࠠࡕࡱࡥࡥ࡬ࡵࠧ䜼")
		,l11ll1_l1_ (u"ࠩࡗࡒࠬ䜽"):l11ll1_l1_ (u"ࠪࡘࡺࡴࡩࡴ࡫ࡤࠫ䜾")
		,l11ll1_l1_ (u"࡙ࠫࡘࠧ䜿"):l11ll1_l1_ (u"࡚ࠬࡵࡳ࡭ࡨࡽࠬ䝀")
		,l11ll1_l1_ (u"࠭ࡔࡎࠩ䝁"):l11ll1_l1_ (u"ࠧࡕࡷࡵ࡯ࡲ࡫࡮ࡪࡵࡷࡥࡳ࠭䝂")
		,l11ll1_l1_ (u"ࠨࡖࡆࠫ䝃"):l11ll1_l1_ (u"ࠩࡗࡹࡷࡱࡳࠡࡣࡱࡨࠥࡉࡡࡪࡥࡲࡷࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䝄")
		,l11ll1_l1_ (u"ࠪࡘ࡛࠭䝅"):l11ll1_l1_ (u"࡙ࠫࡻࡶࡢ࡮ࡸࠫ䝆")
		,l11ll1_l1_ (u"࡛ࠬࡍࠨ䝇"):l11ll1_l1_ (u"࠭ࡕ࠯ࡕ࠱ࠤࡒ࡯࡮ࡰࡴࠣࡓࡺࡺ࡬ࡺ࡫ࡱ࡫ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䝈")
		,l11ll1_l1_ (u"ࠧࡗࡋࠪ䝉"):l11ll1_l1_ (u"ࠨࡗ࠱ࡗ࠳ࠦࡖࡪࡴࡪ࡭ࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䝊")
		,l11ll1_l1_ (u"ࠩࡘࡋࠬ䝋"):l11ll1_l1_ (u"࡙ࠪ࡬ࡧ࡮ࡥࡣࠪ䝌")
		,l11ll1_l1_ (u"࡚ࠫࡇࠧ䝍"):l11ll1_l1_ (u"࡛ࠬ࡫ࡳࡣ࡬ࡲࡪ࠭䝎")
		,l11ll1_l1_ (u"࠭ࡁࡆࠩ䝏"):l11ll1_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧ䝐")
		,l11ll1_l1_ (u"ࠨࡗࡎࠫ䝑"):l11ll1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ䝒")
		,l11ll1_l1_ (u"࡙ࠪࡘ࠭䝓"):l11ll1_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ䝔")
		,l11ll1_l1_ (u"࡛࡙ࠬࠨ䝕"):l11ll1_l1_ (u"࠭ࡕࡳࡷࡪࡹࡦࡿࠧ䝖")
		,l11ll1_l1_ (u"ࠧࡖ࡜ࠪ䝗"):l11ll1_l1_ (u"ࠨࡗࡽࡦࡪࡱࡩࡴࡶࡤࡲࠬ䝘")
		,l11ll1_l1_ (u"࡙࡙ࠩࠬ䝙"):l11ll1_l1_ (u"࡚ࠪࡦࡴࡵࡢࡶࡸࠫ䝚")
		,l11ll1_l1_ (u"࡛ࠫࡇࠧ䝛"):l11ll1_l1_ (u"ࠬ࡜ࡡࡵ࡫ࡦࡥࡳࠦࡃࡪࡶࡼࠫ䝜")
		,l11ll1_l1_ (u"࠭ࡖࡆࠩ䝝"):l11ll1_l1_ (u"ࠧࡗࡧࡱࡩࡿࡻࡥ࡭ࡣࠪ䝞")
		,l11ll1_l1_ (u"ࠨࡘࡑࠫ䝟"):l11ll1_l1_ (u"࡙ࠩ࡭ࡪࡺ࡮ࡢ࡯ࠪ䝠")
		,l11ll1_l1_ (u"࡛ࠪࡋ࠭䝡"):l11ll1_l1_ (u"ࠫ࡜ࡧ࡬࡭࡫ࡶࠤࡦࡴࡤࠡࡈࡸࡸࡺࡴࡡࠨ䝢")
		,l11ll1_l1_ (u"ࠬࡋࡈࠨ䝣"):l11ll1_l1_ (u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ䝤")
		,l11ll1_l1_ (u"࡚ࠧࡇࠪ䝥"):l11ll1_l1_ (u"ࠨ࡛ࡨࡱࡪࡴࠧ䝦")
		,l11ll1_l1_ (u"ࠩ࡝ࡑࠬ䝧"):l11ll1_l1_ (u"ࠪ࡞ࡦࡳࡢࡪࡣࠪ䝨")
		,l11ll1_l1_ (u"ࠫ࡟࡝ࠧ䝩"):l11ll1_l1_ (u"ࠬࡠࡩ࡮ࡤࡤࡦࡼ࡫ࠧ䝪")
		,l11ll1_l1_ (u"࠭ࡁ࡙ࠩ䝫"):l11ll1_l1_ (u"ࠧࣆ࡮ࡤࡲࡩ࠭䝬")
		}
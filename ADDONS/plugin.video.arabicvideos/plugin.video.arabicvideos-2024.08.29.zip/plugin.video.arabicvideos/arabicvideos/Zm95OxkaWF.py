# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SHOFHA'
r07r9xeEFASJXluImT = '_SHT_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==640: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==641: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==642: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==644: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==645: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==649: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,649,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',q3QVhZaDEuo8t2ASj5vkn,641,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'جديد الموقع',q3QVhZaDEuo8t2ASj5vkn+'/newvideos.php',641,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"navslide-divider"></div>(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if title in IVD2kBKhW8FeQLvxUm: continue
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,644)
	return
def VrWsaTmY2qZ(url):
	XcBhCImQ6r = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"caret"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('"presentation"','</ul>')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = [(eHdDoxhJCEPMZFVa2fg,cOUiow273ytu1GC5N0FJh)]
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		for NdupeIwhrAZ0kxW7ER,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			XcBhCImQ6r = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if NdupeIwhrAZ0kxW7ER: NdupeIwhrAZ0kxW7ER = NdupeIwhrAZ0kxW7ER+': '
			for apOKrFbP9IYHDyUVm7,title in XcBhCImQ6r:
				title = NdupeIwhrAZ0kxW7ER+title
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,641)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"pm-category-subcats"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if len(bLPGQ21sY8ie0fZ)<30:
			if XcBhCImQ6r: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
			for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,641)
	if not w69FNzXjsWm and not eFUZtGJawsxyA42SRXl8fkBrnjo: zRK9ruIt0ZFV4bgi(url)
	return
def zRK9ruIt0ZFV4bgi(url,mzfT1LoKkCy7g9wuSqV=eHdDoxhJCEPMZFVa2fg):
	if mzfT1LoKkCy7g9wuSqV=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-TITLES-1st')
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-TITLES-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	cOUiow273ytu1GC5N0FJh,items = eHdDoxhJCEPMZFVa2fg,[]
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	if mzfT1LoKkCy7g9wuSqV=='ajax-search':
		cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ: items.append((eHdDoxhJCEPMZFVa2fg,apOKrFbP9IYHDyUVm7,title))
	elif mzfT1LoKkCy7g9wuSqV=='featured':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pm-video-watch-featured"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif mzfT1LoKkCy7g9wuSqV=='new_episodes':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"row pm-ul-browse-videos(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif mzfT1LoKkCy7g9wuSqV=='new_movies':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"row pm-ul-browse-videos(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if len(RRztfCIs16MGxEHLJ25vDNAa7hpWT)>1: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[1]
	elif mzfT1LoKkCy7g9wuSqV=='featured_series':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ: items.append((eHdDoxhJCEPMZFVa2fg,apOKrFbP9IYHDyUVm7,title))
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(data-echo=".*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if cOUiow273ytu1GC5N0FJh and not items: items = cBawilJXvK1m.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if not items: return
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|حلقة).\d+',title,cBawilJXvK1m.DOTALL)
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,642,PeLqCN5Ek8bB)
		elif mzfT1LoKkCy7g9wuSqV=='new_episodes':
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,642,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0][0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,645,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,645,PeLqCN5Ek8bB)
	if 1:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7=='#': continue
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,641)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	e3XtKs70ifmRQY8VTLnpMdyr6 = cBawilJXvK1m.findall('"og:image" content="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if e3XtKs70ifmRQY8VTLnpMdyr6: PeLqCN5Ek8bB = e3XtKs70ifmRQY8VTLnpMdyr6[0]
	else: PeLqCN5Ek8bB = eHdDoxhJCEPMZFVa2fg
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('episodeNumber.*?</div>(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="eplist"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?><span>(.*?)</em>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if not items: items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.replace('</span><em>',avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,642,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW,zzSnQP3O5HIVpmji10gC4tY,wROf6m4Ix73jtsdnZ1vpCDuV = [],[],[]
	if '/watch.php' in url: E1Viom5L3684CTOFJ = url.replace('/watch.php','/view.php')
	else: E1Viom5L3684CTOFJ = url
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOFHA-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'embedded-video' in nR2B1Wye7luXb5:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"embedded-video"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if JCZVK86QTYwX4mfgOrod:
				apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[0]
				if apOKrFbP9IYHDyUVm7 not in ppQOjlq2gaPkW:
					zzSnQP3O5HIVpmji10gC4tY.append('?named=__embed')
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if 'WatchServers' in nR2B1Wye7luXb5:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"WatchServers"(.*?)</script>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			mEC2f4s1SGhZg9VAqnpO = cBawilJXvK1m.findall('id="(.*?)".*?</span>(.*?)</button>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('\\"','"').replace('\/','/')
			JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('"<iframe.src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if len(mEC2f4s1SGhZg9VAqnpO)==len(JCZVK86QTYwX4mfgOrod):
				for id,title in mEC2f4s1SGhZg9VAqnpO:
					apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[int(id)]
					if apOKrFbP9IYHDyUVm7 not in ppQOjlq2gaPkW:
						zzSnQP3O5HIVpmji10gC4tY.append('?named='+title+'__watch')
						ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if 'DownloadServer' in nR2B1Wye7luXb5:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"DownloadServer"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if not JCZVK86QTYwX4mfgOrod: JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
			for apOKrFbP9IYHDyUVm7,title in JCZVK86QTYwX4mfgOrod:
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+apOKrFbP9IYHDyUVm7
				if apOKrFbP9IYHDyUVm7 not in ppQOjlq2gaPkW:
					zzSnQP3O5HIVpmji10gC4tY.append('?named='+title+'__download')
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = zip(ppQOjlq2gaPkW,zzSnQP3O5HIVpmji10gC4tY)
	for apOKrFbP9IYHDyUVm7,name in FbL9lHaTVANMPd7hDJcw2o8QEX1mqu: wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+name)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search.php?keywords='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
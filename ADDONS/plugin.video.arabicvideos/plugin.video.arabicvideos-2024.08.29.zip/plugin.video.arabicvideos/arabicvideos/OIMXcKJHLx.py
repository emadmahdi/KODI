﻿# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK,kRK4wr6EajpcZx):
	if kRK4wr6EajpcZx==eHdDoxhJCEPMZFVa2fg: return
	if tWi3JH8rRhxcgnYuMVUK==1:
		RK364usNdcL98AE7YofBGaFpi0U2Cb = VVZgPQ2kYLoKe6jic5AEzqupG.getCurrentWindowDialogId()
		xL3IUZRst4F8 = VVZgPQ2kYLoKe6jic5AEzqupG.Window(RK364usNdcL98AE7YofBGaFpi0U2Cb)
		kRK4wr6EajpcZx = iVAXFDQ0NpolPYOZ(kRK4wr6EajpcZx)
		xL3IUZRst4F8.getControl(311).setLabel(kRK4wr6EajpcZx)
	if tWi3JH8rRhxcgnYuMVUK==0:
		fW4iNwld6COELJ10='X'
		if WHjh1POtMKlmgiy68RSqb: vYQXMzcoGpPu4 = isinstance(kRK4wr6EajpcZx,str)
		else: vYQXMzcoGpPu4 = isinstance(kRK4wr6EajpcZx,unicode)
		if vYQXMzcoGpPu4==True: fW4iNwld6COELJ10='U'
		KCTALnycGOap=str(type(kRK4wr6EajpcZx))+avcfIls8w7gk69hYUErHxzQTXtm24j+kRK4wr6EajpcZx+avcfIls8w7gk69hYUErHxzQTXtm24j+fW4iNwld6COELJ10+avcfIls8w7gk69hYUErHxzQTXtm24j
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(0,len(kRK4wr6EajpcZx),1):
			KCTALnycGOap += hex(ord(kRK4wr6EajpcZx[dhcGSyo8Kn1mHZwvEAkzJ7NUq])).replace('0x',eHdDoxhJCEPMZFVa2fg)+avcfIls8w7gk69hYUErHxzQTXtm24j
		kRK4wr6EajpcZx = iVAXFDQ0NpolPYOZ(kRK4wr6EajpcZx)
		fW4iNwld6COELJ10='X'
		if WHjh1POtMKlmgiy68RSqb: vYQXMzcoGpPu4 = isinstance(kRK4wr6EajpcZx, str)
		else: vYQXMzcoGpPu4 = isinstance(kRK4wr6EajpcZx, unicode)
		if vYQXMzcoGpPu4==True: fW4iNwld6COELJ10='U'
		QQW09IPvUROiun=str(type(kRK4wr6EajpcZx))+avcfIls8w7gk69hYUErHxzQTXtm24j+kRK4wr6EajpcZx+avcfIls8w7gk69hYUErHxzQTXtm24j+fW4iNwld6COELJ10+avcfIls8w7gk69hYUErHxzQTXtm24j
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(0,len(kRK4wr6EajpcZx),1):
			QQW09IPvUROiun += hex(ord(kRK4wr6EajpcZx[dhcGSyo8Kn1mHZwvEAkzJ7NUq])).replace('0x',eHdDoxhJCEPMZFVa2fg)+avcfIls8w7gk69hYUErHxzQTXtm24j
	return
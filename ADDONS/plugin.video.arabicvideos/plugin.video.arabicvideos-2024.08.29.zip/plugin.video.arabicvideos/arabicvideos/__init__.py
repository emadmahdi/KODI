# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from FUL4oWn9vq import *
EERWJf1adv67 = f90fGrlSEObDsuiA3U(u"ࠨࡋࡑࡍ࡙࠭೰")
NjUoV9ezOnfFDEdsx7GW3g1ryXc4p = t3coAp06zvHrTl49bUVgx(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩೱ")
fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
nP6tjJH5O17yGvYB38IaEVb = int(zVg9Tax3sjPSAvRJF7XHGy5hK8)
jZHGcWxXpdVO038fnt = ccwRLKk3hs0E.getInfoLabel(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫೲ"))
jZHGcWxXpdVO038fnt = jZHGcWxXpdVO038fnt.replace(Gd4fNUpaveYtQDxi,eHdDoxhJCEPMZFVa2fg).replace(EigLDrG278jQVcmy,eHdDoxhJCEPMZFVa2fg)
if nP6tjJH5O17yGvYB38IaEVb==RqLvTrID0yMVeClpYcnZ16i3X(u"࠴࠹࠴ഛ"): LM8kiTHh3rlG7XuDO2V9EnjRF1 = XugxFprC26zGM(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬೳ")+MCrWtwnF2TViZOD7z0pXgqI4+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬ೴")+UBgvOF9CZQSexLVGYKuNER+EX25Y0l8ILvz7QcRC(u"࠭ࠠ࡞ࠩ೵")
else:
	WGIV9jTJrOlgLko0SQK7h2qi3 = zrHeZWCqQMOymk1d7anKpu0vEx8(H4ys6we0jDn).replace(SbyWQGMDnV,eHdDoxhJCEPMZFVa2fg).replace(OR97bMGecfgDCqux3YdAZ6y,eHdDoxhJCEPMZFVa2fg)
	WGIV9jTJrOlgLko0SQK7h2qi3 = WGIV9jTJrOlgLko0SQK7h2qi3.replace(Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	WGIV9jTJrOlgLko0SQK7h2qi3 = WGIV9jTJrOlgLko0SQK7h2qi3.replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	LM8kiTHh3rlG7XuDO2V9EnjRF1 = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭೶")+jZHGcWxXpdVO038fnt+HkiMU0QrdzW3l6gwnT(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨ೷")+zVg9Tax3sjPSAvRJF7XHGy5hK8+ietolwsjpIPK7Fr(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ೸")+WGIV9jTJrOlgLko0SQK7h2qi3+jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠤࡢ࠭೹")
vR9cOpMtk51j(iwIlVQsgYezu,NjUoV9ezOnfFDEdsx7GW3g1ryXc4p+kDUv7ouWrcgMe6OipQJm+WMyqfm31ka2jICwiE(EERWJf1adv67)+LM8kiTHh3rlG7XuDO2V9EnjRF1)
if eNEhtuoi9gK8JaTpIXj(u"ࠫࡤ࠭೺") in YvJZXDaqbN: ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F = YvJZXDaqbN.split(ietolwsjpIPK7Fr(u"ࠬࡥࠧ೻"),bP01xn84BiQN(u"࠴ജ"))
else: ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F = YvJZXDaqbN,eHdDoxhJCEPMZFVa2fg
N1vK7PznWC6ka = rDceXBpHkfVUYRJ3tIx95Z
if ye7Oa1nIcm9FVxw3vjQsDuKb6 in [ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭࠱ࠨ೼"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࠳ࠩ೽"),CKUiyEe28zsZ(u"ࠨ࠵ࠪ೾"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ࠷ࠫ೿"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪ࠹ࠬഀ")] and (LyOR7f69iA(u"ࠫࡆࡊࡄࠨഁ") in SSN0rt6VGqc4fOnQijpb2F or jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡘࡅࡎࡑ࡙ࡉࠬം") in SSN0rt6VGqc4fOnQijpb2F or I5bUBGpPXn0W6(u"࠭ࡕࡑࠩഃ") in SSN0rt6VGqc4fOnQijpb2F or RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡅࡑ࡚ࡒࠬഄ") in SSN0rt6VGqc4fOnQijpb2F):
	from GIBQakgutV import yXofqcVp1Mhk
	yXofqcVp1Mhk(YvJZXDaqbN,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F)
	MoO74hKeqm8fFka.setSetting(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬഅ"),H4ys6we0jDn)
	N1vK7PznWC6ka = YchIv6N09BaWPEj4tieAnluKZrRXT
elif not tJWbQ0cyZoe and nP6tjJH5O17yGvYB38IaEVb in [w2vjZmdJuY7c(u"࠶࠸࠻ഝ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠼࠷࠵ഞ")]:
	f5fabpu27UKAx = str(ruWSoIZkeKA[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡩࡳࡱࡪࡥࡳࠩആ")])
	EERWJf1adv67 = EX25Y0l8ILvz7QcRC(u"ࠪࡍࡕ࡚ࡖࠨഇ") if nP6tjJH5O17yGvYB38IaEVb==ehfEsaiJBSvbcULtNPVgykA2(u"࠸࠳࠶ട") else t3coAp06zvHrTl49bUVgx(u"ࠫࡒ࠹ࡕࠨഈ")
	nla1P3FLvTMQ4KW87kYOtsRwS2 = EERWJf1adv67.lower()
	PPOaXI9Tr1fAD7luhFGYpKJ5q = MoO74hKeqm8fFka.getSetting(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡧࡶ࠯ࠩഉ")+nla1P3FLvTMQ4KW87kYOtsRwS2+wY1p9mP03S8drbcH64t5WQkv(u"࠭࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫഊ")+f5fabpu27UKAx)
	DfV0FjXSuriL6O1aM5hPZlQt8 = MoO74hKeqm8fFka.getSetting(f90fGrlSEObDsuiA3U(u"ࠧࡢࡸ࠱ࠫഋ")+nla1P3FLvTMQ4KW87kYOtsRwS2+LyOR7f69iA(u"ࠨ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫഌ")+f5fabpu27UKAx)
	if PPOaXI9Tr1fAD7luhFGYpKJ5q or DfV0FjXSuriL6O1aM5hPZlQt8:
		FeTJrG4SkMf09iVys8A += HkiMU0QrdzW3l6gwnT(u"ࠩࡿࠫ഍")
		if PPOaXI9Tr1fAD7luhFGYpKJ5q: FeTJrG4SkMf09iVys8A += LTN6DPEmrwehtZMy(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩഎ")+PPOaXI9Tr1fAD7luhFGYpKJ5q
		if DfV0FjXSuriL6O1aM5hPZlQt8: FeTJrG4SkMf09iVys8A += XugxFprC26zGM(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧഏ")+DfV0FjXSuriL6O1aM5hPZlQt8
		FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A.replace(w2vjZmdJuY7c(u"ࠬࢂࠦࠨഐ"),I5bUBGpPXn0W6(u"࠭ࡼࠨ഑"))
	yNYCDeHPsXl36jaJ0SMomQv5 = MoO74hKeqm8fFka.getSetting(NxXMrsTC5FniYuRBOK8(u"ࠧࡢࡸ࠱ࠫഒ")+nla1P3FLvTMQ4KW87kYOtsRwS2+ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠰ࡶࡩࡷࡼࡥࡳࡡࠪഓ")+f5fabpu27UKAx)
	if yNYCDeHPsXl36jaJ0SMomQv5:
		Bv5FtWYrRHwDKVqx16Nc = cBawilJXvK1m.findall(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬഔ"),FeTJrG4SkMf09iVys8A,cBawilJXvK1m.DOTALL)
		FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A.replace(Bv5FtWYrRHwDKVqx16Nc[x1Oa8bBf36EwsLMirtFc],yNYCDeHPsXl36jaJ0SMomQv5)
	IZkpyKSFVarcHwG1g6emqQv70h(FeTJrG4SkMf09iVys8A,EERWJf1adv67,fW4iNwld6COELJ10)
else:
	JqZhbG9Le2NQvziaPCx8wI = O8pF1bNVh2BTZDAawLJmyXul75jfk(d8De716ZlA2)
	import dIxmaLQn3F
	pw9fgsSRmnKId80YbU1PA = eHdDoxhJCEPMZFVa2fg
	try: dIxmaLQn3F.EWm9I6yoTUgp7FLfJDOtYzdKs5M84(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,JqZhbG9Le2NQvziaPCx8wI,nP6tjJH5O17yGvYB38IaEVb,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F,jZHGcWxXpdVO038fnt)
	except Exception as ACbjkvGL7Udh4RuToXPmeFVy: pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
	dIxmaLQn3F.FRPXKYtorIBuMJkZp(pw9fgsSRmnKId80YbU1PA)
	N1vK7PznWC6ka = dIxmaLQn3F.N1vK7PznWC6ka
if RNtanOkdbsT0:
	if LyOR7f69iA(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ക") in RNtanOkdbsT0 and eNEhtuoi9gK8JaTpIXj(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧഖ") in RNtanOkdbsT0 and TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧഗ") in RNtanOkdbsT0:
		rlw5DSv3P9mpc74oWz80andt6 = []
		for X9XxmHBLWPz in RNtanOkdbsT0:
			if X9XxmHBLWPz in [EX25Y0l8ILvz7QcRC(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩഘ"),S8i3sBYoHWdTURpAgN(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩങ")]: continue
			rlw5DSv3P9mpc74oWz80andt6.append(X9XxmHBLWPz)
	else: rlw5DSv3P9mpc74oWz80andt6 = RNtanOkdbsT0
	LG3QyMvjlx8J0VFRawcBWNIS7t = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=uubfnFKgCq,args=(rlw5DSv3P9mpc74oWz80andt6,))
	LG3QyMvjlx8J0VFRawcBWNIS7t.start()
if N1vK7PznWC6ka: ccwRLKk3hs0E.executebuiltin(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬച"))
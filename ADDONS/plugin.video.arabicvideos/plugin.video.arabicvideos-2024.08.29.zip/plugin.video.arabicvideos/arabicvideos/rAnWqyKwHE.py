# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'RANDOMS'
r07r9xeEFASJXluImT = '_LST_'
TDUb81xuL5K73QCna4MjEozNevkR = 4
qqbEF2GpcshLZWPzJBvV63fRCHxD = 10
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK,url,bkA4Xjzw7mJa,clAzmREWwXf6Gk,ruWSoIZkeKA):
	try: f5fabpu27UKAx = str(ruWSoIZkeKA['folder'])
	except: f5fabpu27UKAx = eHdDoxhJCEPMZFVa2fg
	if   tWi3JH8rRhxcgnYuMVUK==160: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif tWi3JH8rRhxcgnYuMVUK==161: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = sSFZKtInHxU(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==162: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = a967J8RywtGomhk1C4beDpPv(bkA4Xjzw7mJa,162)
	elif tWi3JH8rRhxcgnYuMVUK==163: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = a967J8RywtGomhk1C4beDpPv(bkA4Xjzw7mJa,163)
	elif tWi3JH8rRhxcgnYuMVUK==164: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = jjQpXPfni5hJxcaUWb8uweNMCYT1E(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==165: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = fgy6UV45jprouZnihBJKsRd(url,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==166: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = NjphryWwlP6t9CnOgL2D8MkeiQ4I(url,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==167: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = eQntD6PcGAF(url,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==168: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = RIVxoHYWJpXSwe3OfG2nL9BghU(url,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==761: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = jFlnD8cRzOPIMd()
	elif tWi3JH8rRhxcgnYuMVUK==762: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = baDphqsSXQA()
	elif tWi3JH8rRhxcgnYuMVUK==763: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = XbrVqgHDOQ7PR(f5fabpu27UKAx,bkA4Xjzw7mJa,clAzmREWwXf6Gk)
	elif tWi3JH8rRhxcgnYuMVUK==764: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = SSgxd8AE5qmV6JZUBLNKTciar(f5fabpu27UKAx,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==765: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = kq7L8R93i4rjCv(f5fabpu27UKAx,bkA4Xjzw7mJa)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder','قنوات تلفزيون عشوائية',eHdDoxhJCEPMZFVa2fg,161,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_LIVETV__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','قسم عشوائي',eHdDoxhJCEPMZFVa2fg,162,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_SITES__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات عشوائية',eHdDoxhJCEPMZFVa2fg,163,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_SITES__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات بحث عشوائي',eHdDoxhJCEPMZFVa2fg,164,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_SITES__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات عشوائية من قسم',eHdDoxhJCEPMZFVa2fg,763,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_SITES__RANDOM_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder','قنوات M3U عشوائية',eHdDoxhJCEPMZFVa2fg,163,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات M3U عشوائية',eHdDoxhJCEPMZFVa2fg,163,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','قسم قنوات M3U عشوائي',eHdDoxhJCEPMZFVa2fg,162,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__LIVE__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','قسم فيديو M3U عشوائي',eHdDoxhJCEPMZFVa2fg,162,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__VOD__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات M3U بحث عشوائي',eHdDoxhJCEPMZFVa2fg,164,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات M3U عشوائية من قسم',eHdDoxhJCEPMZFVa2fg,765,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_M3U__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder','قنوات IPTV عشوائية',eHdDoxhJCEPMZFVa2fg,163,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات IPTV عشوائية',eHdDoxhJCEPMZFVa2fg,163,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','قسم قنوات IPTV عشوائي',eHdDoxhJCEPMZFVa2fg,162,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__LIVE__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','قسم فيديو IPTV عشوائي',eHdDoxhJCEPMZFVa2fg,162,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__VOD__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات IPTV بحث عشوائي',eHdDoxhJCEPMZFVa2fg,164,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__RANDOM__REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder','فيديوهات IPTV عشوائية من قسم',eHdDoxhJCEPMZFVa2fg,764,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def jFlnD8cRzOPIMd():
	qfpnsHw19BiaSktcXWbGA('folder','_IPT_'+'فيديوهات جميع IPTV',eHdDoxhJCEPMZFVa2fg,764)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
		r07r9xeEFASJXluImT = '_IP'+str(f5fabpu27UKAx)+'_'
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' فيديوهات مجلد '+Fv7ouzCZdqTc95fJKBXA[f5fabpu27UKAx],eHdDoxhJCEPMZFVa2fg,764,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
	return
def baDphqsSXQA():
	qfpnsHw19BiaSktcXWbGA('folder','_M3U_'+'فيديوهات جميع M3U',eHdDoxhJCEPMZFVa2fg,765)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
		r07r9xeEFASJXluImT = '_MU'+str(f5fabpu27UKAx)+'_'
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' فيديوهات مجلد '+Fv7ouzCZdqTc95fJKBXA[f5fabpu27UKAx],eHdDoxhJCEPMZFVa2fg,765,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
	return
def IBqkM6C7lQUYRhtdZuzfi05T2A4(uujC2KDqoT3rGHzPpAW1mf):
	global DxaS6HVh4kMnmfWO7GXC9zyBbjc02,vvWImcTrU9ntN
	aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk = VqR1T8ZyLenuDtvEXz2Psip(uujC2KDqoT3rGHzPpAW1mf)
	try:
		if 'IFILM' in uujC2KDqoT3rGHzPpAW1mf: aw3VMqrfJ4(uujC2KDqoT3rGHzPpAW1mf)
		else: aw3VMqrfJ4()
		O5OGrvWqPNXFLnCK = False
	except:
		CCq2PhsRVwMmeL4YpcE7QxaWjoAlv()
		O5OGrvWqPNXFLnCK = True
	uujC2KDqoT3rGHzPpAW1mf = v9vBX6ZiQ0UHxfze8EjG4nmRW(uujC2KDqoT3rGHzPpAW1mf)
	if O5OGrvWqPNXFLnCK:
		dqKGMYgJxSF8Ub1kotlsP936Ww7B(uujC2KDqoT3rGHzPpAW1mf,'فشل للأسف',b8bLFaejUB=2000)
		DxaS6HVh4kMnmfWO7GXC9zyBbjc02 += 1
		vvWImcTrU9ntN += avcfIls8w7gk69hYUErHxzQTXtm24j+uujC2KDqoT3rGHzPpAW1mf
	else: dqKGMYgJxSF8Ub1kotlsP936Ww7B(uujC2KDqoT3rGHzPpAW1mf,eHdDoxhJCEPMZFVa2fg,b8bLFaejUB=1000)
	return
def EALkjiCfSbQwaYgFeJ3GsI710PnTM(qeZoUitfJXz6u1Wy=True):
	global DxaS6HVh4kMnmfWO7GXC9zyBbjc02,vvWImcTrU9ntN
	if not qeZoUitfJXz6u1Wy:
		global r3gYWiShzyHFb9MnPD1G8kfBvjp
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
			r3gYWiShzyHFb9MnPD1G8kfBvjp = JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
			return
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if zf7iFX1auw0bQU!=1: return
	Rpfbit9Qjk4zYoMu0q(False,False,False)
	LTZdOGAMl7Cq2NyvS9BKbn4D1uI3 = JXSlk8x495HmgiD
	DxaS6HVh4kMnmfWO7GXC9zyBbjc02,vvWImcTrU9ntN,threads = 0,eHdDoxhJCEPMZFVa2fg,{}
	for uujC2KDqoT3rGHzPpAW1mf in I75YTtmVrWsBxHO:
		b8bLFaejUB.sleep(0.75)
		threads[uujC2KDqoT3rGHzPpAW1mf] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=IBqkM6C7lQUYRhtdZuzfi05T2A4,args=(uujC2KDqoT3rGHzPpAW1mf,))
		threads[uujC2KDqoT3rGHzPpAW1mf].start()
		if DxaS6HVh4kMnmfWO7GXC9zyBbjc02>=qqbEF2GpcshLZWPzJBvV63fRCHxD: break
	else:
		for uujC2KDqoT3rGHzPpAW1mf in list(threads.keys()):
			threads[uujC2KDqoT3rGHzPpAW1mf].join()
	JXSlk8x495HmgiD[:] = LTZdOGAMl7Cq2NyvS9BKbn4D1uI3
	if DxaS6HVh4kMnmfWO7GXC9zyBbjc02>=qqbEF2GpcshLZWPzJBvV63fRCHxD: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','لديك مشكلة في '+str(DxaS6HVh4kMnmfWO7GXC9zyBbjc02)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+vvWImcTrU9ntN)
	else:
		CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS_SITES','SECTIONS_SITES_ALL',r3gYWiShzyHFb9MnPD1G8kfBvjp,ICRfWub2vqlor0Q)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	Rpfbit9Qjk4zYoMu0q(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)
	ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	return
def VJa0LylTCs6h(f5fabpu27UKAx,j2TA4h0FekYb3a5B):
	ssGzSv5CKWmpbITxfqjE6D4n0leo = False
	f7YoeVFgd9x = JXSlk8x495HmgiD
	JXSlk8x495HmgiD[:] = []
	if ssGzSv5CKWmpbITxfqjE6D4n0leo and '_CREATENEW_' not in j2TA4h0FekYb3a5B:
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+f5fabpu27UKAx)
	elif '_LIVE_' not in j2TA4h0FekYb3a5B or '_VOD_' not in j2TA4h0FekYb3a5B:
		import oocDvzUeSu
		sh3cDaZzUkKQFEAl74OryuPtGqJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in j2TA4h0FekYb3a5B:
			try: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_UNKNOWN_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـIPTV للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_MOVIES_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـIPTV للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_SERIES_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـIPTV للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if '_VOD_' not in j2TA4h0FekYb3a5B:
			try: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'LIVE_UNKNOWN_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـIPTV للقنوات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'LIVE_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـIPTV للقنوات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = JXSlk8x495HmgiD
		if ssGzSv5CKWmpbITxfqjE6D4n0leo: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS_IPTV','SECTIONS_IPTV_'+f5fabpu27UKAx,JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,ICRfWub2vqlor0Q)
	JXSlk8x495HmgiD[:] = f7YoeVFgd9x
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def PPsauxr8zN(f5fabpu27UKAx,j2TA4h0FekYb3a5B):
	ssGzSv5CKWmpbITxfqjE6D4n0leo = False
	f7YoeVFgd9x = JXSlk8x495HmgiD
	JXSlk8x495HmgiD[:] = []
	if ssGzSv5CKWmpbITxfqjE6D4n0leo and '_CREATENEW_' not in j2TA4h0FekYb3a5B:
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS_M3U','SECTIONS_M3U_'+f5fabpu27UKAx)
	elif '_LIVE_' not in j2TA4h0FekYb3a5B or '_VOD_' not in j2TA4h0FekYb3a5B:
		import jVcFvDeLay
		sh3cDaZzUkKQFEAl74OryuPtGqJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in j2TA4h0FekYb3a5B:
			try: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_UNKNOWN_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـM3U للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_MOVIES_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـM3U للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'VOD_SERIES_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـM3U للفيديوهات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if '_VOD_' not in j2TA4h0FekYb3a5B:
			try: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'LIVE_UNKNOWN_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـM3U للقنوات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
			try: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(f5fabpu27UKAx,'LIVE_GROUPED_SORTED',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,j2TA4h0FekYb3a5B+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع ـM3U للقنوات',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = JXSlk8x495HmgiD
		if ssGzSv5CKWmpbITxfqjE6D4n0leo: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_'+f5fabpu27UKAx,JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,ICRfWub2vqlor0Q)
	JXSlk8x495HmgiD[:] = f7YoeVFgd9x
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def XbrVqgHDOQ7PR(f5fabpu27UKAx,j2TA4h0FekYb3a5B,yyb6EVfokuleUpFDt4gaJnY9GCi):
	if '_CREATENEW_' in j2TA4h0FekYb3a5B and yyb6EVfokuleUpFDt4gaJnY9GCi==eHdDoxhJCEPMZFVa2fg: EALkjiCfSbQwaYgFeJ3GsI710PnTM(True)
	elif yyb6EVfokuleUpFDt4gaJnY9GCi: EALkjiCfSbQwaYgFeJ3GsI710PnTM(False)
	IsNfaMY6FSude8lZkGXny4HCQ = j2TA4h0FekYb3a5B.replace('_CREATENEW_',eHdDoxhJCEPMZFVa2fg).replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	if not yyb6EVfokuleUpFDt4gaJnY9GCi:
		qfpnsHw19BiaSktcXWbGA('link','تحديث هذه القائمة',eHdDoxhJCEPMZFVa2fg,763,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_CREATENEW_'+IsNfaMY6FSude8lZkGXny4HCQ,eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	EiABLjW8KhkIVC7vJGyf9scSq3rYtm = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	I1ckeumZ0s4RUVGObQtzMrT3 = ['افلام','movie','فيلم','فلم']
	Fl2VaUu6noQ9chyIPZG1YeSmsw4X5N = ['مسلسل','series']
	Gf26wicZjUX0 = ['مسارح','مسرحيات']
	IIsNTrhLkAt1cnHpyUJm6quf8C9 = ['برامج','show','تلفزيون','تليفزيون']
	t97lXUHLCZpoPI3qzVjYsD8cd1Awn = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	llfMmBhQsvWcDI6Gwa4S = ['رمضان']
	Cynto6K3SVucskU = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	oxkXS2VZO5KWR643GUmJujbIc8q = ['سلاسل','سلسله']
	KQrd7wFAPHO1sWu9b = ['اغاني','موسيقى','كليب','حفل','music']
	WWASncKJU42IiGCsEpM = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	iwIJ1UZ0knFAYPEqMbDTG9QsLH = ['الان','حالي','مثبت','رائج']
	WWTHtl02XGdY7n8suDZ1qzEe = ['ضحك','كوميدي']
	VHB6UMZiK17nGCAlcx0qwJNybRPt = ['رياضه','كوره','مصارعه','شوت','رياضة']
	my8f1dHLBQ7UjZM2xDoN = ['نيتفلكس','netflix','نيتفليكس']
	ttAnpHrkgzUmoRMyjKbPx = ['ممثلين','اشخاص','نجوم']
	ozPjuMtH32DEISFKQl = ['بث حي','live','قناه','قنوات']
	IPmQ7lKLc9ijOCD65RBUJZ = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	c3Sq9WpsJrd = ['19','20','21','22','23','24','25','26']
	if not yyb6EVfokuleUpFDt4gaJnY9GCi:
		yyb6EVfokuleUpFDt4gaJnY9GCi = 0
		for NNu1efc9VwxiUD87JSRCg4Z in EiABLjW8KhkIVC7vJGyf9scSq3rYtm:
			yyb6EVfokuleUpFDt4gaJnY9GCi += 1
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+NNu1efc9VwxiUD87JSRCg4Z,eHdDoxhJCEPMZFVa2fg,763,eHdDoxhJCEPMZFVa2fg,str(yyb6EVfokuleUpFDt4gaJnY9GCi),IsNfaMY6FSude8lZkGXny4HCQ,eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
	else:
		for Pe9ETSvwUGBnkC1hO in sorted(list(r3gYWiShzyHFb9MnPD1G8kfBvjp.keys())):
			TR3DAb6GkCsva1 = Pe9ETSvwUGBnkC1hO.lower()
			U3d2hkuwDIj56 = []
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in I1ckeumZ0s4RUVGObQtzMrT3): U3d2hkuwDIj56.append(1)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in Fl2VaUu6noQ9chyIPZG1YeSmsw4X5N): U3d2hkuwDIj56.append(2)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in Gf26wicZjUX0): U3d2hkuwDIj56.append(3)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IIsNTrhLkAt1cnHpyUJm6quf8C9): U3d2hkuwDIj56.append(4)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in t97lXUHLCZpoPI3qzVjYsD8cd1Awn): U3d2hkuwDIj56.append(5)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in llfMmBhQsvWcDI6Gwa4S): U3d2hkuwDIj56.append(6)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in Cynto6K3SVucskU) and TR3DAb6GkCsva1 not in ['اخرى']: U3d2hkuwDIj56.append(7)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in oxkXS2VZO5KWR643GUmJujbIc8q): U3d2hkuwDIj56.append(8)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in KQrd7wFAPHO1sWu9b): U3d2hkuwDIj56.append(9)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in WWASncKJU42IiGCsEpM): U3d2hkuwDIj56.append(10)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in iwIJ1UZ0knFAYPEqMbDTG9QsLH): U3d2hkuwDIj56.append(11)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in WWTHtl02XGdY7n8suDZ1qzEe): U3d2hkuwDIj56.append(12)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in VHB6UMZiK17nGCAlcx0qwJNybRPt): U3d2hkuwDIj56.append(13)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in my8f1dHLBQ7UjZM2xDoN): U3d2hkuwDIj56.append(14)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in ttAnpHrkgzUmoRMyjKbPx): U3d2hkuwDIj56.append(15)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in ozPjuMtH32DEISFKQl): U3d2hkuwDIj56.append(16)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IPmQ7lKLc9ijOCD65RBUJZ): U3d2hkuwDIj56.append(17)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in TR3DAb6GkCsva1 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in c3Sq9WpsJrd): U3d2hkuwDIj56.append(18)
			if not U3d2hkuwDIj56: U3d2hkuwDIj56 = [19]
			for LPdCM5OxYz in U3d2hkuwDIj56:
				if str(LPdCM5OxYz)==yyb6EVfokuleUpFDt4gaJnY9GCi:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+Pe9ETSvwUGBnkC1hO,Pe9ETSvwUGBnkC1hO,166,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,IsNfaMY6FSude8lZkGXny4HCQ+'_REMEMBERRESULTS_')
	return
def SSgxd8AE5qmV6JZUBLNKTciar(f5fabpu27UKAx,j2TA4h0FekYb3a5B):
	ssGzSv5CKWmpbITxfqjE6D4n0leo = False
	if ssGzSv5CKWmpbITxfqjE6D4n0leo:
		qfpnsHw19BiaSktcXWbGA('link','تحديث هذه القائمة',eHdDoxhJCEPMZFVa2fg,764,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_CREATENEW_',eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	f7YoeVFgd9x = JXSlk8x495HmgiD[:]
	import oocDvzUeSu
	if f5fabpu27UKAx:
		if not oocDvzUeSu.ffdr02bStCnz(f5fabpu27UKAx,True): return
		QXi5bkAqSY0KTPVLrJd = VJa0LylTCs6h(f5fabpu27UKAx,j2TA4h0FekYb3a5B)
		W1vLcHR5lO = sorted(QXi5bkAqSY0KTPVLrJd,reverse=False,key=lambda key: key[1].lower())
	else:
		if not oocDvzUeSu.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
		if ssGzSv5CKWmpbITxfqjE6D4n0leo and '_CREATENEW_' not in j2TA4h0FekYb3a5B:
			W1vLcHR5lO = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			t5lUD4c37wgKGQd,W1vLcHR5lO,QXi5bkAqSY0KTPVLrJd = [],[],[]
			for ZWIUewT8pBKAthfMRkzgH95VlN4nP in range(1,II0HXSngDhlLOuNQ9Vi+1):
				W1vLcHR5lO += VJa0LylTCs6h(str(ZWIUewT8pBKAthfMRkzgH95VlN4nP),j2TA4h0FekYb3a5B)
			for type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in W1vLcHR5lO:
				if bkA4Xjzw7mJa not in t5lUD4c37wgKGQd:
					t5lUD4c37wgKGQd.append(bkA4Xjzw7mJa)
					XXvypzAIhiENQgb4dPG3UwVk = type,Pe9ETSvwUGBnkC1hO,bkA4Xjzw7mJa,165,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,j2TA4h0FekYb3a5B,YvJZXDaqbN,ruWSoIZkeKA
					QXi5bkAqSY0KTPVLrJd.append(XXvypzAIhiENQgb4dPG3UwVk)
			W1vLcHR5lO = sorted(QXi5bkAqSY0KTPVLrJd,reverse=False,key=lambda key: key[1].lower())
			if ssGzSv5CKWmpbITxfqjE6D4n0leo: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',W1vLcHR5lO,ICRfWub2vqlor0Q)
	JXSlk8x495HmgiD[:] = f7YoeVFgd9x+W1vLcHR5lO
	AOwqYZ30sN1Mp(False)
	return
def kq7L8R93i4rjCv(f5fabpu27UKAx,j2TA4h0FekYb3a5B):
	ssGzSv5CKWmpbITxfqjE6D4n0leo = False
	if ssGzSv5CKWmpbITxfqjE6D4n0leo:
		qfpnsHw19BiaSktcXWbGA('link','تحديث هذه القائمة',eHdDoxhJCEPMZFVa2fg,765,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_CREATENEW_',eHdDoxhJCEPMZFVa2fg,{'folder':f5fabpu27UKAx})
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	f7YoeVFgd9x = JXSlk8x495HmgiD[:]
	import jVcFvDeLay
	if f5fabpu27UKAx:
		if not jVcFvDeLay.ffdr02bStCnz(f5fabpu27UKAx,True): return
		QXi5bkAqSY0KTPVLrJd = PPsauxr8zN(f5fabpu27UKAx,j2TA4h0FekYb3a5B)
		W1vLcHR5lO = sorted(QXi5bkAqSY0KTPVLrJd,reverse=False,key=lambda key: key[1].lower())
	else:
		if not jVcFvDeLay.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
		if ssGzSv5CKWmpbITxfqjE6D4n0leo and '_CREATENEW_' not in j2TA4h0FekYb3a5B:
			W1vLcHR5lO = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			t5lUD4c37wgKGQd,W1vLcHR5lO,QXi5bkAqSY0KTPVLrJd = [],[],[]
			for ZWIUewT8pBKAthfMRkzgH95VlN4nP in range(1,II0HXSngDhlLOuNQ9Vi+1):
				W1vLcHR5lO += PPsauxr8zN(str(ZWIUewT8pBKAthfMRkzgH95VlN4nP),j2TA4h0FekYb3a5B)
			for type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in W1vLcHR5lO:
				if bkA4Xjzw7mJa not in t5lUD4c37wgKGQd:
					t5lUD4c37wgKGQd.append(bkA4Xjzw7mJa)
					XXvypzAIhiENQgb4dPG3UwVk = type,Pe9ETSvwUGBnkC1hO,bkA4Xjzw7mJa,165,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,j2TA4h0FekYb3a5B,YvJZXDaqbN,ruWSoIZkeKA
					QXi5bkAqSY0KTPVLrJd.append(XXvypzAIhiENQgb4dPG3UwVk)
			W1vLcHR5lO = sorted(QXi5bkAqSY0KTPVLrJd,reverse=False,key=lambda key: key[1].lower())
			if ssGzSv5CKWmpbITxfqjE6D4n0leo: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_ALL',W1vLcHR5lO,ICRfWub2vqlor0Q)
	JXSlk8x495HmgiD[:] = f7YoeVFgd9x+W1vLcHR5lO
	AOwqYZ30sN1Mp(False)
	return
def fgy6UV45jprouZnihBJKsRd(group,j2TA4h0FekYb3a5B):
	ssGzSv5CKWmpbITxfqjE6D4n0leo = False
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = []
	fQcRgZYDUPVx = '_IPTV_' if 'IPTV' in j2TA4h0FekYb3a5B else '_M3U_'
	if ssGzSv5CKWmpbITxfqjE6D4n0leo: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS'+fQcRgZYDUPVx[:-1],group)
	if not JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
		for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
			if ssGzSv5CKWmpbITxfqjE6D4n0leo: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 += EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','SECTIONS'+fQcRgZYDUPVx[:-1],'SECTIONS'+fQcRgZYDUPVx+str(f5fabpu27UKAx))
			elif fQcRgZYDUPVx=='_IPTV_': JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 += VJa0LylTCs6h(str(f5fabpu27UKAx),'_CREATENEW_')
			elif fQcRgZYDUPVx=='_M3U_': JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 += PPsauxr8zN(str(f5fabpu27UKAx),'_CREATENEW_')
		for type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
			if bkA4Xjzw7mJa==group: AsMupEf5dOTc1BvrnUatLiX3P4(type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA)
		items,bLPGQ21sY8ie0fZ = [],[]
		for type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in JXSlk8x495HmgiD:
			AJQxD8aRgjWPUlbfChZ36Is0B2 = type,Pe9ETSvwUGBnkC1hO[4:],url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,eHdDoxhJCEPMZFVa2fg
			if AJQxD8aRgjWPUlbfChZ36Is0B2 not in bLPGQ21sY8ie0fZ:
				bLPGQ21sY8ie0fZ.append(AJQxD8aRgjWPUlbfChZ36Is0B2)
				AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ = type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA
				items.append(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ)
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if ssGzSv5CKWmpbITxfqjE6D4n0leo: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'SECTIONS'+fQcRgZYDUPVx[:-1],group,JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,ICRfWub2vqlor0Q)
	if '_RANDOM_' in j2TA4h0FekYb3a5B and len(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1)>TDUb81xuL5K73QCna4MjEozNevkR:
		JXSlk8x495HmgiD[:] = []
		qfpnsHw19BiaSktcXWbGA('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,fQcRgZYDUPVx+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		qfpnsHw19BiaSktcXWbGA('folder','إعادة الطلب العشوائي من نفس القسم',group,165,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,fQcRgZYDUPVx+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = JXSlk8x495HmgiD+GljITSOwLKW36.sample(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,TDUb81xuL5K73QCna4MjEozNevkR)
	JXSlk8x495HmgiD[:] = JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
	AOwqYZ30sN1Mp(False)
	return
def sSFZKtInHxU(j2TA4h0FekYb3a5B):
	qfpnsHw19BiaSktcXWbGA('folder','إعادة طلب قنوات عشوائية',eHdDoxhJCEPMZFVa2fg,161,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	ydhZkIBoYgEAS4MrLUwvPjq5tc = JXSlk8x495HmgiD[:]
	JXSlk8x495HmgiD[:] = []
	import EZ6VKpTQse
	EZ6VKpTQse.EGoutUTNgihIRDYqyAn798cS4('0',False)
	EZ6VKpTQse.EGoutUTNgihIRDYqyAn798cS4('1',False)
	EZ6VKpTQse.EGoutUTNgihIRDYqyAn798cS4('2',False)
	if '_RANDOM_' in j2TA4h0FekYb3a5B:
		JXSlk8x495HmgiD[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
		if len(JXSlk8x495HmgiD)>TDUb81xuL5K73QCna4MjEozNevkR: JXSlk8x495HmgiD[:] = GljITSOwLKW36.sample(JXSlk8x495HmgiD,TDUb81xuL5K73QCna4MjEozNevkR)
	JXSlk8x495HmgiD[:] = ydhZkIBoYgEAS4MrLUwvPjq5tc+JXSlk8x495HmgiD
	return
def jjQpXPfni5hJxcaUWb8uweNMCYT1E(j2TA4h0FekYb3a5B):
	j2TA4h0FekYb3a5B = j2TA4h0FekYb3a5B.replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = GHIgY9AomX(data)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(OclpauhMYPIx502SgUe1X7EWd,'GET',url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="content"(.*?)class="clearfix"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	Y5vQo9NtbKkLZRH3UiB7le8,TWYDNx72XKmdOnQlUiEog = list(zip(*items))
	NmLfZ3U5KgDtnAr = []
	OGEJLiyTKmjMf9ou7BRHkCnI2cZel = [avcfIls8w7gk69hYUErHxzQTXtm24j,'"','`',',','.',':',';',"'",'-']
	AnFpLUrK9QvHf4zY7DcS = TWYDNx72XKmdOnQlUiEog+Y5vQo9NtbKkLZRH3UiB7le8
	for nhY80pPdW7Zy in AnFpLUrK9QvHf4zY7DcS:
		if nhY80pPdW7Zy in TWYDNx72XKmdOnQlUiEog: TqrPW4AfwJbCUDux7nd3 = 2
		if nhY80pPdW7Zy in Y5vQo9NtbKkLZRH3UiB7le8: TqrPW4AfwJbCUDux7nd3 = 4
		zuiR9ODa6M0qIXwGvrnNdo7 = [dhcGSyo8Kn1mHZwvEAkzJ7NUq in nhY80pPdW7Zy for dhcGSyo8Kn1mHZwvEAkzJ7NUq in OGEJLiyTKmjMf9ou7BRHkCnI2cZel]
		if any(zuiR9ODa6M0qIXwGvrnNdo7):
			WmUKzewgdt7nOa3VlBC19 = zuiR9ODa6M0qIXwGvrnNdo7.index(True)
			RcEHNS8o0sQC5nFil = OGEJLiyTKmjMf9ou7BRHkCnI2cZel[WmUKzewgdt7nOa3VlBC19]
			vlm8LVM5yp7s6o3XuCqDejFgExK = eHdDoxhJCEPMZFVa2fg
			if nhY80pPdW7Zy.count(RcEHNS8o0sQC5nFil)>1: Dxdhwj2esmUYtkpy7aLuWFJ,bb9SjZrQqAszfa06eo4IydT,vlm8LVM5yp7s6o3XuCqDejFgExK = nhY80pPdW7Zy.split(RcEHNS8o0sQC5nFil,2)
			else: Dxdhwj2esmUYtkpy7aLuWFJ,bb9SjZrQqAszfa06eo4IydT = nhY80pPdW7Zy.split(RcEHNS8o0sQC5nFil,1)
			if len(Dxdhwj2esmUYtkpy7aLuWFJ)>TqrPW4AfwJbCUDux7nd3: NmLfZ3U5KgDtnAr.append(Dxdhwj2esmUYtkpy7aLuWFJ.lower())
			if len(bb9SjZrQqAszfa06eo4IydT)>TqrPW4AfwJbCUDux7nd3: NmLfZ3U5KgDtnAr.append(bb9SjZrQqAszfa06eo4IydT.lower())
			if len(vlm8LVM5yp7s6o3XuCqDejFgExK)>TqrPW4AfwJbCUDux7nd3: NmLfZ3U5KgDtnAr.append(vlm8LVM5yp7s6o3XuCqDejFgExK.lower())
		elif len(nhY80pPdW7Zy)>TqrPW4AfwJbCUDux7nd3: NmLfZ3U5KgDtnAr.append(nhY80pPdW7Zy.lower())
	for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(9): GljITSOwLKW36.shuffle(NmLfZ3U5KgDtnAr)
	if '_SITES_' in j2TA4h0FekYb3a5B:
		O2AoWcTykStHQ1EV3jUCB48 = LSPX4bazoBtC9kh
	elif '_IPTV_' in j2TA4h0FekYb3a5B:
		O2AoWcTykStHQ1EV3jUCB48 = ['IPTV']
		import oocDvzUeSu
		if not oocDvzUeSu.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
	elif '_M3U_' in j2TA4h0FekYb3a5B:
		O2AoWcTykStHQ1EV3jUCB48 = ['M3U']
		import jVcFvDeLay
		if not jVcFvDeLay.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
	count,IngprOf8Yta = 0,0
	qfpnsHw19BiaSktcXWbGA('folder','[  ] :البحث عن',eHdDoxhJCEPMZFVa2fg,164,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
	qfpnsHw19BiaSktcXWbGA('folder','إعادة البحث العشوائي',eHdDoxhJCEPMZFVa2fg,164,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	q6U2NxGj9mMKJbpR3IltcFSdXg1Y5 = JXSlk8x495HmgiD[:]
	JXSlk8x495HmgiD[:] = []
	xoW9Q3zlqXTgmIkOtPFCMV = []
	for nhY80pPdW7Zy in NmLfZ3U5KgDtnAr:
		bb9SjZrQqAszfa06eo4IydT = cBawilJXvK1m.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',nhY80pPdW7Zy,cBawilJXvK1m.DOTALL)
		if bb9SjZrQqAszfa06eo4IydT: nhY80pPdW7Zy = nhY80pPdW7Zy.split(bb9SjZrQqAszfa06eo4IydT[0],1)[0]
		r76BZd8nHQ0fI1 = nhY80pPdW7Zy.replace('ّ',eHdDoxhJCEPMZFVa2fg).replace('َ',eHdDoxhJCEPMZFVa2fg).replace('ً',eHdDoxhJCEPMZFVa2fg).replace('ُ',eHdDoxhJCEPMZFVa2fg).replace('ٌ',eHdDoxhJCEPMZFVa2fg)
		r76BZd8nHQ0fI1 = r76BZd8nHQ0fI1.replace('ِ',eHdDoxhJCEPMZFVa2fg).replace('ٍ',eHdDoxhJCEPMZFVa2fg).replace('ْ',eHdDoxhJCEPMZFVa2fg).replace('،',eHdDoxhJCEPMZFVa2fg).replace('ـ',eHdDoxhJCEPMZFVa2fg)
		if r76BZd8nHQ0fI1: xoW9Q3zlqXTgmIkOtPFCMV.append(r76BZd8nHQ0fI1)
	nA3eiCbcDyENpmutGqw = []
	for gMmB3iopS0ZXrOFewhcxt in range(0,20):
		search = GljITSOwLKW36.sample(xoW9Q3zlqXTgmIkOtPFCMV,1)[0]
		if search in nA3eiCbcDyENpmutGqw: continue
		nA3eiCbcDyENpmutGqw.append(search)
		uujC2KDqoT3rGHzPpAW1mf = GljITSOwLKW36.sample(O2AoWcTykStHQ1EV3jUCB48,1)[0]
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Random Video Search   site:'+str(uujC2KDqoT3rGHzPpAW1mf)+'  search:'+search)
		aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk = VqR1T8ZyLenuDtvEXz2Psip(uujC2KDqoT3rGHzPpAW1mf)
		rKXOTbZdRQ(search+'_NODIALOGS_')
		if len(JXSlk8x495HmgiD)>0: break
	search = search.replace('_MOD_',eHdDoxhJCEPMZFVa2fg)
	q6U2NxGj9mMKJbpR3IltcFSdXg1Y5[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	JXSlk8x495HmgiD[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
	if len(JXSlk8x495HmgiD)>TDUb81xuL5K73QCna4MjEozNevkR: JXSlk8x495HmgiD[:] = GljITSOwLKW36.sample(JXSlk8x495HmgiD,TDUb81xuL5K73QCna4MjEozNevkR)
	JXSlk8x495HmgiD[:] = q6U2NxGj9mMKJbpR3IltcFSdXg1Y5+JXSlk8x495HmgiD
	return
def NjphryWwlP6t9CnOgL2D8MkeiQ4I(oohb1r2EqtXDwIUFMeAL0cvipuz6,j2TA4h0FekYb3a5B):
	oohb1r2EqtXDwIUFMeAL0cvipuz6 = oohb1r2EqtXDwIUFMeAL0cvipuz6.replace('_MOD_',eHdDoxhJCEPMZFVa2fg)
	j2TA4h0FekYb3a5B = j2TA4h0FekYb3a5B.replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	EALkjiCfSbQwaYgFeJ3GsI710PnTM(False)
	if r3gYWiShzyHFb9MnPD1G8kfBvjp=={}: return
	if '_RANDOM_' in j2TA4h0FekYb3a5B:
		qfpnsHw19BiaSktcXWbGA('folder','[[COLOR FFC89008]'+oohb1r2EqtXDwIUFMeAL0cvipuz6+'[/COLOR] :القسم]',oohb1r2EqtXDwIUFMeAL0cvipuz6,166,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
		qfpnsHw19BiaSktcXWbGA('folder','إعادة الطلب العشوائي من نفس القسم',oohb1r2EqtXDwIUFMeAL0cvipuz6,166,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	for website in sorted(list(r3gYWiShzyHFb9MnPD1G8kfBvjp[oohb1r2EqtXDwIUFMeAL0cvipuz6].keys())):
		type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = r3gYWiShzyHFb9MnPD1G8kfBvjp[oohb1r2EqtXDwIUFMeAL0cvipuz6][website]
		if '_RANDOM_' in j2TA4h0FekYb3a5B or len(r3gYWiShzyHFb9MnPD1G8kfBvjp[oohb1r2EqtXDwIUFMeAL0cvipuz6])==1:
			AsMupEf5dOTc1BvrnUatLiX3P4(type,eHdDoxhJCEPMZFVa2fg,url,JvfrAebh43x5cTipPjdLF0s17tO,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)
			JXSlk8x495HmgiD[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
			f7YoeVFgd9x,W1vLcHR5lO = JXSlk8x495HmgiD[:3],JXSlk8x495HmgiD[3:]
			for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(9): GljITSOwLKW36.shuffle(W1vLcHR5lO)
			if '_RANDOM_' in j2TA4h0FekYb3a5B: JXSlk8x495HmgiD[:] = f7YoeVFgd9x+W1vLcHR5lO[:TDUb81xuL5K73QCna4MjEozNevkR]
			else: JXSlk8x495HmgiD[:] = f7YoeVFgd9x+W1vLcHR5lO
		elif '_SITES_' in j2TA4h0FekYb3a5B: qfpnsHw19BiaSktcXWbGA('folder',website,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA)
	return
def a967J8RywtGomhk1C4beDpPv(j2TA4h0FekYb3a5B,tWi3JH8rRhxcgnYuMVUK):
	j2TA4h0FekYb3a5B = j2TA4h0FekYb3a5B.replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	Pe9ETSvwUGBnkC1hO,fYoKlURINeiDL837x914 = eHdDoxhJCEPMZFVa2fg,[]
	qfpnsHw19BiaSktcXWbGA('folder','[[COLOR FFC89008]'+Pe9ETSvwUGBnkC1hO+'[/COLOR] :القسم]',eHdDoxhJCEPMZFVa2fg,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
	qfpnsHw19BiaSktcXWbGA('folder','إعادة طلب قسم عشوائي',eHdDoxhJCEPMZFVa2fg,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+j2TA4h0FekYb3a5B)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	f7YoeVFgd9x = JXSlk8x495HmgiD[:]
	JXSlk8x495HmgiD[:] = []
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = []
	if '_SITES_' in j2TA4h0FekYb3a5B:
		EALkjiCfSbQwaYgFeJ3GsI710PnTM(False)
		if r3gYWiShzyHFb9MnPD1G8kfBvjp=={}: return
		oaNKRdjYGhkDwBWFCXHz5OEUv = list(r3gYWiShzyHFb9MnPD1G8kfBvjp.keys())
		oohb1r2EqtXDwIUFMeAL0cvipuz6 = GljITSOwLKW36.sample(oaNKRdjYGhkDwBWFCXHz5OEUv,1)[0]
		NmLfZ3U5KgDtnAr = list(r3gYWiShzyHFb9MnPD1G8kfBvjp[oohb1r2EqtXDwIUFMeAL0cvipuz6].keys())
		website = GljITSOwLKW36.sample(NmLfZ3U5KgDtnAr,1)[0]
		type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = r3gYWiShzyHFb9MnPD1G8kfBvjp[oohb1r2EqtXDwIUFMeAL0cvipuz6][website]
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Random Category   website: '+website+'   name: '+Pe9ETSvwUGBnkC1hO+'   url: '+url+'   mode: '+str(JvfrAebh43x5cTipPjdLF0s17tO))
	elif '_IPTV_' in j2TA4h0FekYb3a5B:
		import oocDvzUeSu
		if not oocDvzUeSu.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
		for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
			JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 += VJa0LylTCs6h(str(f5fabpu27UKAx),j2TA4h0FekYb3a5B)
		if not JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1: return
		type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = GljITSOwLKW36.sample(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,1)[0]
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Random Category   name: '+Pe9ETSvwUGBnkC1hO+'   url: '+url+'   mode: '+str(JvfrAebh43x5cTipPjdLF0s17tO))
	elif '_M3U_' in j2TA4h0FekYb3a5B:
		import jVcFvDeLay
		if not jVcFvDeLay.ffdr02bStCnz(eHdDoxhJCEPMZFVa2fg,True): return
		for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
			JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 += PPsauxr8zN(str(f5fabpu27UKAx),j2TA4h0FekYb3a5B)
		if not JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1: return
		type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = GljITSOwLKW36.sample(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,1)[0]
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Random Category   name: '+Pe9ETSvwUGBnkC1hO+'   url: '+url+'   mode: '+str(JvfrAebh43x5cTipPjdLF0s17tO))
	EagPOL7uf5lXDVk3re4SBGIjH = Pe9ETSvwUGBnkC1hO
	GCj4tEMz8eQAwsBdLTaH62x = []
	for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(0,10):
		if dhcGSyo8Kn1mHZwvEAkzJ7NUq>0: vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Random Category   name: '+Pe9ETSvwUGBnkC1hO+'   url: '+url+'   mode: '+str(JvfrAebh43x5cTipPjdLF0s17tO))
		JXSlk8x495HmgiD[:] = []
		if JvfrAebh43x5cTipPjdLF0s17tO==234 and '__IPTVSeries__' in bkA4Xjzw7mJa: JvfrAebh43x5cTipPjdLF0s17tO = 233
		if JvfrAebh43x5cTipPjdLF0s17tO==714 and '__M3USeries__' in bkA4Xjzw7mJa: JvfrAebh43x5cTipPjdLF0s17tO = 713
		if JvfrAebh43x5cTipPjdLF0s17tO==144: JvfrAebh43x5cTipPjdLF0s17tO = 291
		ppxnlrkDsXUmKQWFt = AsMupEf5dOTc1BvrnUatLiX3P4(type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA)
		if '_IPTV_' in j2TA4h0FekYb3a5B and JvfrAebh43x5cTipPjdLF0s17tO==167: del JXSlk8x495HmgiD[:3]
		if '_M3U_' in j2TA4h0FekYb3a5B and JvfrAebh43x5cTipPjdLF0s17tO==168: del JXSlk8x495HmgiD[:3]
		fYoKlURINeiDL837x914[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
		if GCj4tEMz8eQAwsBdLTaH62x and ZJPiId12qkesLNTvQW9H(u'حلقة') in str(fYoKlURINeiDL837x914) or ZJPiId12qkesLNTvQW9H(u'حلقه') in str(fYoKlURINeiDL837x914):
			Pe9ETSvwUGBnkC1hO = EagPOL7uf5lXDVk3re4SBGIjH
			fYoKlURINeiDL837x914[:] = GCj4tEMz8eQAwsBdLTaH62x
			break
		EagPOL7uf5lXDVk3re4SBGIjH = Pe9ETSvwUGBnkC1hO
		GCj4tEMz8eQAwsBdLTaH62x = fYoKlURINeiDL837x914
		if str(fYoKlURINeiDL837x914).count('video')>0: break
		if str(fYoKlURINeiDL837x914).count('live')>0: break
		if JvfrAebh43x5cTipPjdLF0s17tO==233: break
		if JvfrAebh43x5cTipPjdLF0s17tO==713: break
		if JvfrAebh43x5cTipPjdLF0s17tO==291: break
		if fYoKlURINeiDL837x914: type,Pe9ETSvwUGBnkC1hO,url,JvfrAebh43x5cTipPjdLF0s17tO,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = GljITSOwLKW36.sample(fYoKlURINeiDL837x914,1)[0]
	if not Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = '....'
	elif Pe9ETSvwUGBnkC1hO.count('_')>1: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.split('_',2)[2]
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace('UNKNOWN: ',eHdDoxhJCEPMZFVa2fg)
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace('_MOD_',eHdDoxhJCEPMZFVa2fg)
	f7YoeVFgd9x[0][1] = '[[COLOR FFC89008]'+Pe9ETSvwUGBnkC1hO+'[/COLOR] :القسم]'
	for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(9): GljITSOwLKW36.shuffle(fYoKlURINeiDL837x914)
	if '_RANDOM_' in j2TA4h0FekYb3a5B: JXSlk8x495HmgiD[:] = f7YoeVFgd9x+fYoKlURINeiDL837x914[:TDUb81xuL5K73QCna4MjEozNevkR]
	else: JXSlk8x495HmgiD[:] = f7YoeVFgd9x+fYoKlURINeiDL837x914
	return
def eQntD6PcGAF(QuKZiV572MUk3XjRd6,JsHA09OvlZeXF):
	JsHA09OvlZeXF = JsHA09OvlZeXF.replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	kgyBszifwSR2UTqQFejKLWZcJoP = JsHA09OvlZeXF
	if '__IPTVSeries__' in JsHA09OvlZeXF:
		kgyBszifwSR2UTqQFejKLWZcJoP = JsHA09OvlZeXF.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in QuKZiV572MUk3XjRd6: type = ',VIDEOS: '
	elif 'LIVE' in QuKZiV572MUk3XjRd6: type = ',LIVE: '
	qfpnsHw19BiaSktcXWbGA('folder','[[COLOR FFC89008]'+type+kgyBszifwSR2UTqQFejKLWZcJoP+'[/COLOR] :القسم]',QuKZiV572MUk3XjRd6,167,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+JsHA09OvlZeXF)
	qfpnsHw19BiaSktcXWbGA('folder','إعادة الطلب العشوائي من نفس القسم',QuKZiV572MUk3XjRd6,167,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+JsHA09OvlZeXF)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	import oocDvzUeSu
	for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
		if '__IPTVSeries__' in JsHA09OvlZeXF: oocDvzUeSu.qGLa71o5AwfKDdeIbPsQBUTC3(str(f5fabpu27UKAx),QuKZiV572MUk3XjRd6,JsHA09OvlZeXF,eHdDoxhJCEPMZFVa2fg,False)
		else: oocDvzUeSu.EGoutUTNgihIRDYqyAn798cS4(str(f5fabpu27UKAx),QuKZiV572MUk3XjRd6,JsHA09OvlZeXF,eHdDoxhJCEPMZFVa2fg,False)
	JXSlk8x495HmgiD[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
	if len(JXSlk8x495HmgiD)>(TDUb81xuL5K73QCna4MjEozNevkR+3): JXSlk8x495HmgiD[:] = JXSlk8x495HmgiD[:3]+GljITSOwLKW36.sample(JXSlk8x495HmgiD[3:],TDUb81xuL5K73QCna4MjEozNevkR)
	return
def RIVxoHYWJpXSwe3OfG2nL9BghU(QuKZiV572MUk3XjRd6,JsHA09OvlZeXF):
	JsHA09OvlZeXF = JsHA09OvlZeXF.replace('_FORGETRESULTS_',eHdDoxhJCEPMZFVa2fg).replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	kgyBszifwSR2UTqQFejKLWZcJoP = JsHA09OvlZeXF
	if '__M3USeries__' in JsHA09OvlZeXF:
		kgyBszifwSR2UTqQFejKLWZcJoP = JsHA09OvlZeXF.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in QuKZiV572MUk3XjRd6: type = ',VIDEOS: '
	elif 'LIVE' in QuKZiV572MUk3XjRd6: type = ',LIVE: '
	qfpnsHw19BiaSktcXWbGA('folder','[[COLOR FFC89008]'+type+kgyBszifwSR2UTqQFejKLWZcJoP+'[/COLOR] :القسم]',QuKZiV572MUk3XjRd6,168,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+JsHA09OvlZeXF)
	qfpnsHw19BiaSktcXWbGA('folder','إعادة الطلب العشوائي من نفس القسم',QuKZiV572MUk3XjRd6,168,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_FORGETRESULTS__REMEMBERRESULTS_'+JsHA09OvlZeXF)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	import jVcFvDeLay
	for f5fabpu27UKAx in range(1,II0HXSngDhlLOuNQ9Vi+1):
		if '__M3USeries__' in JsHA09OvlZeXF: jVcFvDeLay.qGLa71o5AwfKDdeIbPsQBUTC3(str(f5fabpu27UKAx),QuKZiV572MUk3XjRd6,JsHA09OvlZeXF,eHdDoxhJCEPMZFVa2fg,False)
		else: jVcFvDeLay.EGoutUTNgihIRDYqyAn798cS4(str(f5fabpu27UKAx),QuKZiV572MUk3XjRd6,JsHA09OvlZeXF,eHdDoxhJCEPMZFVa2fg,False)
	JXSlk8x495HmgiD[:] = WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD)
	if len(JXSlk8x495HmgiD)>(TDUb81xuL5K73QCna4MjEozNevkR+3): JXSlk8x495HmgiD[:] = JXSlk8x495HmgiD[:3]+GljITSOwLKW36.sample(JXSlk8x495HmgiD[3:],TDUb81xuL5K73QCna4MjEozNevkR)
	return
def WGl2qgDnFVUAQtkJy8KambhzSw4L(JXSlk8x495HmgiD):
	fYoKlURINeiDL837x914 = []
	for type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in JXSlk8x495HmgiD:
		if 'صفحة' in Pe9ETSvwUGBnkC1hO or 'صفحه' in Pe9ETSvwUGBnkC1hO or 'page' in Pe9ETSvwUGBnkC1hO.lower(): continue
		fYoKlURINeiDL837x914.append([type,Pe9ETSvwUGBnkC1hO,url,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA])
	return fYoKlURINeiDL837x914
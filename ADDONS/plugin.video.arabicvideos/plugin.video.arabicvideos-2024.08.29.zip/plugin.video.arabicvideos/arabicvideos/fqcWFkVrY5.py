# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SHIAVOICE'
r07r9xeEFASJXluImT = '_SHV_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
headers = {'User-Agent':None}
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==310: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==311: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==312: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==313: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = o5e2z4fgjxRB3CI7cPmYtdLlK(url)
	elif mode==314: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Cynto6K3SVucskU(text)
	elif mode==319: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,319,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="menulinks"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	items = cBawilJXvK1m.findall('<h5>(.*?)</h5>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	for SDZB9uCEYwg4osN in range(len(items)):
		title = items[SDZB9uCEYwg4osN].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,q3QVhZaDEuo8t2ASj5vkn,314,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,str(SDZB9uCEYwg4osN+1))
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مقاطع شهر',q3QVhZaDEuo8t2ASj5vkn,314,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'0')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	items = cBawilJXvK1m.findall('href="(.*?)".*?<B>(.*?)</B>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,311)
	return nR2B1Wye7luXb5
def Cynto6K3SVucskU(SDZB9uCEYwg4osN):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-LATEST-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if SDZB9uCEYwg4osN=='0':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="tab-content"(.*?)</table>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,name,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			title = title+' ('+name+')'
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312)
	elif SDZB9uCEYwg4osN in ['1','2','3']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(<h5>.*?)<div class="col-lg',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		LLcT4RbDZXG8gpuJA6OEBnxoVvS0mQ = int(SDZB9uCEYwg4osN)-1
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[LLcT4RbDZXG8gpuJA6OEBnxoVvS0mQ]
		if SDZB9uCEYwg4osN=='1': items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		else: items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title,name in items:
			PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			title = title+' ('+name+')'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,311,PeLqCN5Ek8bB)
	elif SDZB9uCEYwg4osN in ['4','5','6']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(<h5>.*?)</table>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		SDZB9uCEYwg4osN = int(SDZB9uCEYwg4osN)-4
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[SDZB9uCEYwg4osN]
		items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,qWG25bhluDH8xzJLytcISf1,title,TR3DAb6GkCsva1 in items:
			PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qWG25bhluDH8xzJLytcISf1 = qWG25bhluDH8xzJLytcISf1.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			TR3DAb6GkCsva1 = TR3DAb6GkCsva1.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if qWG25bhluDH8xzJLytcISf1: name = qWG25bhluDH8xzJLytcISf1
			else: name = TR3DAb6GkCsva1
			title = title+' ('+name+')'
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312,PeLqCN5Ek8bB)
	return
def zRK9ruIt0ZFV4bgi(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('ibox-heading"(.*?)class="float-right',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if 'catsum-mobile' in cOUiow273ytu1GC5N0FJh:
		items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title,count in items:
				PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
				count = count.replace(' الصوتية: ',':')
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				title = title+' ('+count+')'
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,311,PeLqCN5Ek8bB)
	else:
		items = cBawilJXvK1m.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title,DbN8sHURqWxI27zev1wFKZTt6LC,WWPgm9fvlH2oIOnrD1 in items:
			if title==eHdDoxhJCEPMZFVa2fg or DbN8sHURqWxI27zev1wFKZTt6LC==eHdDoxhJCEPMZFVa2fg: continue
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title+' ('+WWPgm9fvlH2oIOnrD1+')'
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312)
	if not items: tcJeirkgjMal25ofbE8zF4nxmOBw(nR2B1Wye7luXb5)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(nR2B1Wye7luXb5):
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="ibox-content"(.*?)class="pagination',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title,name,count,WWPgm9fvlH2oIOnrD1 in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		title = title+' ('+name+')'
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312,eHdDoxhJCEPMZFVa2fg,WWPgm9fvlH2oIOnrD1)
	return
def o5e2z4fgjxRB3CI7cPmYtdLlK(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-SEARCH_ITEMS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="ibox-content p-1"(.*?)class="ibox-content"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		zRK9ruIt0ZFV4bgi(url)
		return
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?<strong>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if '/play-' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,311)
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('<audio.*?src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('<video.*?src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7[0]
	IZkpyKSFVarcHwG1g6emqQv70h(apOKrFbP9IYHDyUVm7,EERWJf1adv67,'video')
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	zdVfFYtSmbnMq7vZAIOajuJNwRl4Hp = ['&t=a','&t=c','&t=s']
	if showDialogs:
		VXgyU6vFeANw78BaxLM4JCp0 = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('موقع صوت الشيعة - أختر البحث', VXgyU6vFeANw78BaxLM4JCp0)
		if iLcCSnPyKYWs3xkQ0p14 == -1: return
	elif '_SHIAVOICE-PERSONS_' in WWLbVhETM9ZCwm85f: iLcCSnPyKYWs3xkQ0p14 = 0
	elif '_SHIAVOICE-ALBUMS_' in WWLbVhETM9ZCwm85f: iLcCSnPyKYWs3xkQ0p14 = 1
	elif '_SHIAVOICE-AUDIOS_' in WWLbVhETM9ZCwm85f: iLcCSnPyKYWs3xkQ0p14 = 2
	else: return
	type = zdVfFYtSmbnMq7vZAIOajuJNwRl4Hp[iLcCSnPyKYWs3xkQ0p14]
	url = q3QVhZaDEuo8t2ASj5vkn+'/search.php?q='+search+type
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHIAVOICE-SEARCH-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="ibox-content"(.*?)class="ibox-content"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		if iLcCSnPyKYWs3xkQ0p14 in [0,1]:
			items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title,name in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				title = title+' ('+name+')'
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,313,PeLqCN5Ek8bB)
		elif iLcCSnPyKYWs3xkQ0p14==2:
			items = cBawilJXvK1m.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title,name in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				title = title+' ('+name+')'
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,312)
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'CIMAABDO'
r07r9xeEFASJXluImT = '_ABD_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الرئيسية']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==550: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==551: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==552: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==553: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==559: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn+'/home',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(q3QVhZaDEuo8t2ASj5vkn,'url')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,559,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'اخترنا لك',rPxSTcgYVul1sqkwtD8HC62vZ4+'/home',551,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-content(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('data-name="(.*?)".*?</i>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for ff8WuQ0HaAmPEdo6SnMXr1sCeTzR,title in items:
		apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/ajax/getItem?item='+ff8WuQ0HaAmPEdo6SnMXr1sCeTzR+'&Ajax=1'
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,551)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"nav-main"(.*?)</nav>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if apOKrFbP9IYHDyUVm7=='#': continue
		if title in IVD2kBKhW8FeQLvxUm: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,551)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	for apOKrFbP9IYHDyUVm7,title in items:
		if apOKrFbP9IYHDyUVm7=='#': continue
		if title in IVD2kBKhW8FeQLvxUm: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,551)
	return
def zRK9ruIt0ZFV4bgi(url,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=eHdDoxhJCEPMZFVa2fg):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
		W9PzsMeLJTc83mS45G17n = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-TITLES-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = [nR2B1Wye7luXb5]
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-TITLES-2nd')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=='featured':
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"container"(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		elif '"section-post mb-10"' in nR2B1Wye7luXb5:
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"section-post mb-10"(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		else:
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<article(.*?)"pagination"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if not items:
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if not items: items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in items:
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7).strip('/')
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
		if 'سلاسل' not in url and any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,552,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and 'الحلقة' in title:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,553,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		elif '/movies/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,551,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,553,PeLqCN5Ek8bB)
	if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR==eHdDoxhJCEPMZFVa2fg:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)<footer',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7=="": continue
				if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'هناك المزيد',url,551)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"getSeasonsBySeries(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"list-episodes"(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm and '/series/' not in url:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,553,PeLqCN5Ek8bB)
	elif eFUZtGJawsxyA42SRXl8fkBrnjo:
		PeLqCN5Ek8bB = cBawilJXvK1m.findall('"image" src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		PeLqCN5Ek8bB = PeLqCN5Ek8bB[0]
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,552,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	ajHR9ABQl2buvm = url.replace('/movies/','/watch_movies/')
	ajHR9ABQl2buvm = ajHR9ABQl2buvm.replace('/episodes/','/watch_episodes/')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(ajHR9ABQl2buvm,'url')
	wROf6m4Ix73jtsdnZ1vpCDuV = []
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('''<iframe.*?src=["'](.*?)["']''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
		GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'url')
		wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__embed')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"servers"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		CJAVOZo730iHxPXp = cBawilJXvK1m.findall('postID = "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		CJAVOZo730iHxPXp = CJAVOZo730iHxPXp[0]
		items = cBawilJXvK1m.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for GfhcsvCWIon,title in items:
				title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/ajax/getPlayer?server='+GfhcsvCWIon+'&postID='+CJAVOZo730iHxPXp+'&Ajax=1'
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
		else:
			items = cBawilJXvK1m.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if items:
				GfhcsvCWIon,eOn9wjkAC6lqBI2XsuU4yrfZ7MQz,title = items[0]
				apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/ajax/getPlayerByName?server='+GfhcsvCWIon+'&multipleServers='+eOn9wjkAC6lqBI2XsuU4yrfZ7MQz+'&postID='+CJAVOZo730iHxPXp+'&Ajax=1'
				E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(apOKrFbP9IYHDyUVm7)
				W9PzsMeLJTc83mS45G17n = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-PLAY-2nd')
				nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
				ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('''<iframe src=["'](.*?)["']''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
				bmsN7D3kPQ8Beh5RS0M4ng2FcY = ge4hFRp51QsUPtGTnBuzka[0] if ge4hFRp51QsUPtGTnBuzka else eHdDoxhJCEPMZFVa2fg
				if '/iframe/' in bmsN7D3kPQ8Beh5RS0M4ng2FcY:
					aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',bmsN7D3kPQ8Beh5RS0M4ng2FcY,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-PLAY-3rd')
					nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
					lOCvdxGam0D = cBawilJXvK1m.findall('version&quot;:&quot;(.*?)&',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
					lOCvdxGam0D = lOCvdxGam0D[0]
					W9PzsMeLJTc83mS45G17n = {}
					W9PzsMeLJTc83mS45G17n['X-Inertia-Partial-Component'] = 'files/mirror/video'
					W9PzsMeLJTc83mS45G17n['X-Inertia'] = 'true'
					W9PzsMeLJTc83mS45G17n['X-Inertia-Partial-Data'] = 'streams'
					W9PzsMeLJTc83mS45G17n['X-Inertia-Version'] = lOCvdxGam0D
					aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',bmsN7D3kPQ8Beh5RS0M4ng2FcY,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAABDO-PLAY-4th')
					nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
					keF5Ct3D2IsgdvSb4QE = DIpuHqsKGS3ErJvk9taCRiX80('dict',nR2B1Wye7luXb5)
					groups = keF5Ct3D2IsgdvSb4QE['props']['streams']['data']
					for group in groups:
						s0s2bIZtWx8w3 = group['label'].replace(' (source)',eHdDoxhJCEPMZFVa2fg)
						r41Oqy0kaepNM9JuFQdv2ClSRc = group['mirrors']
						for P0uARJptg3 in r41Oqy0kaepNM9JuFQdv2ClSRc:
							GfhcsvCWIon = P0uARJptg3['driver']
							apOKrFbP9IYHDyUVm7 = 'http:'+P0uARJptg3['link']+'?named='+GfhcsvCWIon+'__watch____'+s0s2bIZtWx8w3
							wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"downs"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,name in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__download'
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'-')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'.html'
	zRK9ruIt0ZFV4bgi(url)
	return
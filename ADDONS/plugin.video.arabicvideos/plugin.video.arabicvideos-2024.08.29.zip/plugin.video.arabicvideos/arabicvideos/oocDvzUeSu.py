# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
FO8SKWr40dDexHgbfRUGBi = 'IPTV'
pWmZEI8VqwO3eS5H1BizLCAy = '_IPT_'
ga2Cxd7Bulrb = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def wt29MA4RWa8NOedvnpocQEfC1Hg(tWi3JH8rRhxcgnYuMVUK,Nn360bq79W2kzUt,bkA4Xjzw7mJa,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,d9c6BWV3J2bQDMRELgX,ICOyNkVjwdXS5TFKH6WgZAn4):
	global pWmZEI8VqwO3eS5H1BizLCAy
	try:
		C47G3hXaRMFLfOAEpV = str(ICOyNkVjwdXS5TFKH6WgZAn4['folder'])
		pWmZEI8VqwO3eS5H1BizLCAy = '_IP'+C47G3hXaRMFLfOAEpV+'_'
	except: C47G3hXaRMFLfOAEpV = eHdDoxhJCEPMZFVa2fg
	if   tWi3JH8rRhxcgnYuMVUK==230: pGiyauNHUVlRTnP = RaBNy15ftbPcOWj3()
	elif tWi3JH8rRhxcgnYuMVUK==231: pGiyauNHUVlRTnP = CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==232: pGiyauNHUVlRTnP = IIXfKPZEkUOFwLR4mxQ05jnH(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==233: pGiyauNHUVlRTnP = qGLa71o5AwfKDdeIbPsQBUTC3(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==234: pGiyauNHUVlRTnP = EGoutUTNgihIRDYqyAn798cS4(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==235: pGiyauNHUVlRTnP = bbmQeYGSTIv(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9)
	elif tWi3JH8rRhxcgnYuMVUK==236: pGiyauNHUVlRTnP = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==237: pGiyauNHUVlRTnP = wAYOZDQ2dPyL9GW14HBa0ImT(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==238: pGiyauNHUVlRTnP = yCRcxseONua57QS4In3lt(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==239: pGiyauNHUVlRTnP = A1AxPpad9tTLBbeIiOSQs2yq87hFW(bkA4Xjzw7mJa,C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==280: pGiyauNHUVlRTnP = ZZUK8FJ4RTYCoVeg(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==281: pGiyauNHUVlRTnP = Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==282: pGiyauNHUVlRTnP = mX9BxIuzQT0Ld7pw4(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==283: pGiyauNHUVlRTnP = bb9ikrhNVoXypm0f(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==285: pGiyauNHUVlRTnP = MSwPisjOZBz(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==286: pGiyauNHUVlRTnP = UMXb9i8NgvdGcQDpxnHE1l(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==289: pGiyauNHUVlRTnP = dwS0voDrOHFbWN7TkJVRIfM(bkA4Xjzw7mJa,C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,d9c6BWV3J2bQDMRELgX)
	else: pGiyauNHUVlRTnP = False
	return pGiyauNHUVlRTnP
def RaBNy15ftbPcOWj3():
	for C47G3hXaRMFLfOAEpV in range(1,II0HXSngDhlLOuNQ9Vi+1):
		pWmZEI8VqwO3eS5H1BizLCAy = '_IP'+str(C47G3hXaRMFLfOAEpV)+'_'
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قائمة مجلد '+Fv7ouzCZdqTc95fJKBXA[C47G3hXaRMFLfOAEpV],eHdDoxhJCEPMZFVa2fg,280,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	return
def ZZUK8FJ4RTYCoVeg(C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=eHdDoxhJCEPMZFVa2fg):
	if C47G3hXaRMFLfOAEpV:
		XfMk7rHsRnFqtvUQGoTAw31SEuz = {'folder':C47G3hXaRMFLfOAEpV}
		bb6cBW5yweZGvuXo0NQlM = eHdDoxhJCEPMZFVa2fg
	else:
		XfMk7rHsRnFqtvUQGoTAw31SEuz = eHdDoxhJCEPMZFVa2fg
		bb6cBW5yweZGvuXo0NQlM = eHdDoxhJCEPMZFVa2fg
	KKtj56DpzRl13Oe9dFCVLox = ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w)
	if not KKtj56DpzRl13Oe9dFCVLox:
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+bb6cBW5yweZGvuXo0NQlM+' [/COLOR]',eHdDoxhJCEPMZFVa2fg,231,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFFFFF00] جلب ملفات'+bb6cBW5yweZGvuXo0NQlM+' [/COLOR]',eHdDoxhJCEPMZFVa2fg,232,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	else:
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'بحث في الملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,289,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'LIVE_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة من القسم'+bb6cBW5yweZGvuXo0NQlM,'LIVE_FROM_GROUP_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة من الاسم'+bb6cBW5yweZGvuXo0NQlM,'LIVE_FROM_NAME_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_ORIGINAL_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مجهولة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'LIVE_UNKNOWN_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مجهولة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_UNKNOWN_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أفلام مصنفة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_MOVIES_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أفلام مصنفة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'VOD_MOVIES_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'مسلسلات مصنفة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_SERIES_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'مسلسلات مصنفة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'VOD_SERIES_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_ORIGINAL_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مصنفة من القسم'+bb6cBW5yweZGvuXo0NQlM,'VOD_FROM_GROUP_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مصنفة من الاسم'+bb6cBW5yweZGvuXo0NQlM,'VOD_FROM_NAME_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مجهولة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_UNKNOWN_GROUPED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مجهولة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'VOD_UNKNOWN_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'برامج القنوات (جدول فقط)'+bb6cBW5yweZGvuXo0NQlM,'LIVE_EPG_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أرشيف القنوات للأيام الماضية'+bb6cBW5yweZGvuXo0NQlM,'LIVE_TIMESHIFT_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أرشيف برامج القنوات للأيام الماضية'+bb6cBW5yweZGvuXo0NQlM,'LIVE_ARCHIVED_GROUPED_SORTED',233,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'إضافة أو تغيير اشتراك'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,231,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'جلب ملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,232,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'مسح ملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,237,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'فحص اشتراك'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,236,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'عدد فيديوهات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,281,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'Referer تغيير'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,286,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'User-Agent تغيير'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,283,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'استخدم السيرفر الأسرع'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,282,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	return
def kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w=True):
	AlPsWV4GxSn,lWQtTG59CI1fxdgLZpHU = False,eHdDoxhJCEPMZFVa2fg
	sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if aKnyXZfMFDJViN1OtpLk==eHdDoxhJCEPMZFVa2fg: return False,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	if Z4qAYlatIBdvQ9HbkoK1ewSnM:
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'GET',Z4qAYlatIBdvQ9HbkoK1ewSnM,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,False,eHdDoxhJCEPMZFVa2fg,'IPTV-CHECK_ACCOUNT-1st')
		yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
		if W1B5olYNHxq03IShy.succeeded:
			LdNw5aPHVpf,CKna7WLojgpR,bcAijs0KItM9d21lzQBToY,zzYa3rdb7IAuSTBOKZXghDeQ,HtpDeK3un29q1kTc4dzlA5LVWPU = 0,0,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
			try:
				wzDS1uGyNR = DIpuHqsKGS3ErJvk9taCRiX80('dict',yu26R85ckHMoK3reLVwSd)
				lWQtTG59CI1fxdgLZpHU = wzDS1uGyNR['user_info']['status']
				AlPsWV4GxSn = True
				bcAijs0KItM9d21lzQBToY = wzDS1uGyNR['server_info']['time_now']
			except: pass
			if bcAijs0KItM9d21lzQBToY:
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.strptime(bcAijs0KItM9d21lzQBToY,'%Y.%m.%d %H:%M:%S')
					LdNw5aPHVpf = int(b8bLFaejUB.mktime(kkdSqXlNpHzJPsoa))
					CKna7WLojgpR = int(a8HLTkO2ns49yGNgiroS-LdNw5aPHVpf)
					CKna7WLojgpR = int((CKna7WLojgpR+900)/1800)*1800
				except: pass
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(int(wzDS1uGyNR['user_info']['created_at']))
					zzYa3rdb7IAuSTBOKZXghDeQ = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				except: pass
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(int(wzDS1uGyNR['user_info']['exp_date']))
					HtpDeK3un29q1kTc4dzlA5LVWPU = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				except: pass
			MoO74hKeqm8fFka.setSetting('av.iptv.timestamp_'+C47G3hXaRMFLfOAEpV,str(a8HLTkO2ns49yGNgiroS))
			MoO74hKeqm8fFka.setSetting('av.iptv.timediff_'+C47G3hXaRMFLfOAEpV,str(CKna7WLojgpR))
			try:
				sWni2tcQXN9CK5r1 = '"server_info":'+yu26R85ckHMoK3reLVwSd.split('"server_info":')[1]
				sWni2tcQXN9CK5r1 = sWni2tcQXN9CK5r1.replace(':',': ').replace(',',', ').replace('}}','}')
				LnsdGf5Fxm10zEhWBoRYy7kgIDO923 = cBawilJXvK1m.findall('"url": "(.*?)", "port": "(.*?)"',sWni2tcQXN9CK5r1,cBawilJXvK1m.DOTALL)
				sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = LnsdGf5Fxm10zEhWBoRYy7kgIDO923[0]
			except: AlPsWV4GxSn = False
			if AlPsWV4GxSn and UzF4sIShoZEgRjc7LK8w:
				max = wzDS1uGyNR['user_info']['max_connections']
				ygOxvQwUiAFl8RDcNKdnbV = wzDS1uGyNR['user_info']['active_cons']
				notjG1dg0QfY8VlJ7IZc3mPxK4B = wzDS1uGyNR['user_info']['is_trial']
				kg8NQEiLAFDbf4JjzquICPWO2Vshyd = Z4qAYlatIBdvQ9HbkoK1ewSnM.split('?',1)
				sh3cDaZzUkKQFEAl74OryuPtGqJ = 'URL:  [COLOR FFC89008]'+Z4qAYlatIBdvQ9HbkoK1ewSnM+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\nStatus:  '+SbyWQGMDnV+lWQtTG59CI1fxdgLZpHU+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nTrial:    '+SbyWQGMDnV+str(notjG1dg0QfY8VlJ7IZc3mPxK4B=='1')+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nCreated  At:  '+SbyWQGMDnV+zzYa3rdb7IAuSTBOKZXghDeQ+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nExpiry Date:  '+SbyWQGMDnV+HtpDeK3un29q1kTc4dzlA5LVWPU+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nConnections   ( Active / Maximum ) :  '+SbyWQGMDnV+ygOxvQwUiAFl8RDcNKdnbV+' / '+max+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nAllowed Outputs:   '+SbyWQGMDnV+" , ".join(wzDS1uGyNR['user_info']['allowed_output_formats'])+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+sWni2tcQXN9CK5r1
				if lWQtTG59CI1fxdgLZpHU=='Active': lZGwNzPT1m9i2XJEW4tqKeDjA75a('الاشتراك يعمل بدون مشاكل',sh3cDaZzUkKQFEAl74OryuPtGqJ)
				else: lZGwNzPT1m9i2XJEW4tqKeDjA75a('يبدو أن هناك مشكلة في الاشتراك',sh3cDaZzUkKQFEAl74OryuPtGqJ)
	if Z4qAYlatIBdvQ9HbkoK1ewSnM and AlPsWV4GxSn and lWQtTG59CI1fxdgLZpHU=='Active':
		vR9cOpMtk51j(iwIlVQsgYezu,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+Z4qAYlatIBdvQ9HbkoK1ewSnM+' ]')
		UUQjG45NHzSqZuDe2vYIdTMlJOyc = True
	else:
		vR9cOpMtk51j(bGQ2Ok7RNi,'Checking IPTV URL   [ Does not work ]   [ '+Z4qAYlatIBdvQ9HbkoK1ewSnM+' ]')
		if UzF4sIShoZEgRjc7LK8w: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		UUQjG45NHzSqZuDe2vYIdTMlJOyc = False
	return UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM
def EGoutUTNgihIRDYqyAn798cS4(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH,sxFw3Wz7DhVL,UzF4sIShoZEgRjc7LK8w=True):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH)
	pphAT0S9wnjNGsQUfl6WExoc7b = int(sxFw3Wz7DhVL)*100
	i5YMPKuS1WUQ4xctTE6rbJvD = pphAT0S9wnjNGsQUfl6WExoc7b-100
	for GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in KcogByxTmuNDInYwXALarEjUli7eOR[i5YMPKuS1WUQ4xctTE6rbJvD:pphAT0S9wnjNGsQUfl6WExoc7b]:
		E2tAkO0pMVgD = ('GROUPED' in PiD9gwCG7zxRHVKkaeldoUbZr or PiD9gwCG7zxRHVKkaeldoUbZr=='ALL')
		res2HUZzg4opdqQai7KSGyctLBY0 = ('GROUPED' not in PiD9gwCG7zxRHVKkaeldoUbZr and PiD9gwCG7zxRHVKkaeldoUbZr!='ALL')
		if E2tAkO0pMVgD or res2HUZzg4opdqQai7KSGyctLBY0:
			if   'ARCHIVED'  in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,238,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'ARCHIVED',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'EPG' 		 in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,238,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'FULL_EPG',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'TIMESHIFT' in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,238,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'TIMESHIFT',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'LIVE' 	 in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['live',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,235,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GsPYQbREvLAFw3aJ5XghmV,{'folder':C47G3hXaRMFLfOAEpV}])
			else: JXSlk8x495HmgiD.append(['video',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,235,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
	RVOyUD2s8Bk9FLCwu4MSKJgt = len(KcogByxTmuNDInYwXALarEjUli7eOR)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,234,RVOyUD2s8Bk9FLCwu4MSKJgt,lUXjebduy9AOMcg0rmQDkVH)
	return
def WK4nH6mpNaD31d8QsBXvTqxjuV(WWbrKSHUmJw1dZngOpFxlz):
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'هذه القائمة إما فارغة أو غير موجودة',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'أو الخدمة غير موجودة في اشتراكك',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',eHdDoxhJCEPMZFVa2fg,9999)
	return
def qGLa71o5AwfKDdeIbPsQBUTC3(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH,sxFw3Wz7DhVL,IGajwMJYPOUdL8oK=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=True):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	WWbrKSHUmJw1dZngOpFxlz = pWmZEI8VqwO3eS5H1BizLCAy
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return False
	if '__SERIES__' in lUXjebduy9AOMcg0rmQDkVH: KKJiXTerDa7VhBbdLY82AklNzp,TN1zgbcDXFLGhokjZYH8297 = lUXjebduy9AOMcg0rmQDkVH.split('__SERIES__')
	else: KKJiXTerDa7VhBbdLY82AklNzp,TN1zgbcDXFLGhokjZYH8297 = lUXjebduy9AOMcg0rmQDkVH,eHdDoxhJCEPMZFVa2fg
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	gHekBtYzlJoCFOwK = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',PiD9gwCG7zxRHVKkaeldoUbZr,'__GROUPS__')
	if not gHekBtYzlJoCFOwK: return False
	apqKdVHu4nWY9 = []
	for L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF in gHekBtYzlJoCFOwK:
		if IGajwMJYPOUdL8oK:
			if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: WWbrKSHUmJw1dZngOpFxlz = 'SERIES'
			elif '!!__UNKNOWN__!!' in L5DdYNZBtexX29zGHgQVoCiEJ: WWbrKSHUmJw1dZngOpFxlz = 'UNKNOWN'
			elif 'LIVE' in PiD9gwCG7zxRHVKkaeldoUbZr: WWbrKSHUmJw1dZngOpFxlz = 'LIVE'
			else: WWbrKSHUmJw1dZngOpFxlz = 'VIDEOS'
			WWbrKSHUmJw1dZngOpFxlz = ',[COLOR FFC89008]'+WWbrKSHUmJw1dZngOpFxlz+': [/COLOR]'
		if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')
		else: RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg
		if not lUXjebduy9AOMcg0rmQDkVH:
			if RqP1jLcQ0Z7pik in apqKdVHu4nWY9: continue
			apqKdVHu4nWY9.append(RqP1jLcQ0Z7pik)
			if 'RANDOM' in IGajwMJYPOUdL8oK: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,167,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			elif '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,233,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,234,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
		elif '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ and RqP1jLcQ0Z7pik==KKJiXTerDa7VhBbdLY82AklNzp:
			if XskPiv4uWLdOyohJZqgI6UC7 in apqKdVHu4nWY9: continue
			apqKdVHu4nWY9.append(XskPiv4uWLdOyohJZqgI6UC7)
			if 'RANDOM' in IGajwMJYPOUdL8oK: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+XskPiv4uWLdOyohJZqgI6UC7,PiD9gwCG7zxRHVKkaeldoUbZr,167,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+XskPiv4uWLdOyohJZqgI6UC7,PiD9gwCG7zxRHVKkaeldoUbZr,234,Ufd6obSCcXF,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	JXSlk8x495HmgiD[:] = sorted(JXSlk8x495HmgiD,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1].lower())
	if not IGajwMJYPOUdL8oK:
		pphAT0S9wnjNGsQUfl6WExoc7b = int(sxFw3Wz7DhVL)*100
		i5YMPKuS1WUQ4xctTE6rbJvD = pphAT0S9wnjNGsQUfl6WExoc7b-100
		RVOyUD2s8Bk9FLCwu4MSKJgt = len(JXSlk8x495HmgiD)
		JXSlk8x495HmgiD[:] = JXSlk8x495HmgiD[i5YMPKuS1WUQ4xctTE6rbJvD:pphAT0S9wnjNGsQUfl6WExoc7b]
		dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,233,RVOyUD2s8Bk9FLCwu4MSKJgt,lUXjebduy9AOMcg0rmQDkVH)
	return True
def yCRcxseONua57QS4In3lt(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,FStg5PE8Vmy):
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,True): return
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	LdNw5aPHVpf = MoO74hKeqm8fFka.getSetting('av.iptv.timestamp_'+C47G3hXaRMFLfOAEpV)
	if not LdNw5aPHVpf or a8HLTkO2ns49yGNgiroS-int(LdNw5aPHVpf)>24*xvjre5b4yREScf:
		UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,False)
		if not UUQjG45NHzSqZuDe2vYIdTMlJOyc: return
	CKna7WLojgpR = int(MoO74hKeqm8fFka.getSetting('av.iptv.timediff_'+C47G3hXaRMFLfOAEpV))
	YJ6CzR2VT4ckFjPySvqUpWGgI = MoO74hKeqm8fFka.getSetting('av.iptv.server_'+C47G3hXaRMFLfOAEpV)
	aKnyXZfMFDJViN1OtpLk = MoO74hKeqm8fFka.getSetting('av.iptv.username_'+C47G3hXaRMFLfOAEpV)
	gojXxJqFmu6f = MoO74hKeqm8fFka.getSetting('av.iptv.password_'+C47G3hXaRMFLfOAEpV)
	bjCEsJdIwZ83mcGTepPAMvl9 = Nn360bq79W2kzUt.split('/')
	bb9EjiWfS3Zt62 = bjCEsJdIwZ83mcGTepPAMvl9[-1].replace('.ts',eHdDoxhJCEPMZFVa2fg).replace('.m3u8',eHdDoxhJCEPMZFVa2fg)
	if FStg5PE8Vmy=='SHORT_EPG': BD34N6e0tzJcfbkFG = 'get_short_epg'
	else: BD34N6e0tzJcfbkFG = 'get_simple_data_table'
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if not aKnyXZfMFDJViN1OtpLk: return
	HHsbIdpC2e1TNcZvi8VK = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action='+BD34N6e0tzJcfbkFG+'&stream_id='+bb9EjiWfS3Zt62
	yu26R85ckHMoK3reLVwSd = jwIOCa53Eb(ZAl2gePWifs3IXG,HHsbIdpC2e1TNcZvi8VK,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,'IPTV-EPG_ITEMS-2nd')
	BzPQ14LFmMeDw = DIpuHqsKGS3ErJvk9taCRiX80('dict',yu26R85ckHMoK3reLVwSd)
	bv74hDozKXOM3ifInlAUekjyR = BzPQ14LFmMeDw['epg_listings']
	b8yfIWt2q7hedP3AjukmU0MQOT = []
	if FStg5PE8Vmy in ['ARCHIVED','TIMESHIFT']:
		for wzDS1uGyNR in bv74hDozKXOM3ifInlAUekjyR:
			if wzDS1uGyNR['has_archive']==1:
				b8yfIWt2q7hedP3AjukmU0MQOT.append(wzDS1uGyNR)
				if FStg5PE8Vmy in ['TIMESHIFT']: break
		if not b8yfIWt2q7hedP3AjukmU0MQOT: return
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		if FStg5PE8Vmy in ['TIMESHIFT']:
			gKqRJds7nmDhb = 2
			ZURVzForc0AL = gKqRJds7nmDhb*xvjre5b4yREScf
			b8yfIWt2q7hedP3AjukmU0MQOT = []
			njS0D1VfWqZ2mYoIA3PR = int(int(wzDS1uGyNR['start_timestamp'])/ZURVzForc0AL)*ZURVzForc0AL
			OuV8JivWNP9DFMH = a8HLTkO2ns49yGNgiroS+ZURVzForc0AL
			LqBi8hP6pR1cfUNAQtwY0njW5bar = int((OuV8JivWNP9DFMH-njS0D1VfWqZ2mYoIA3PR)/xvjre5b4yREScf)
			for czAy10w728nRUoaYfdNJPjStpq in range(LqBi8hP6pR1cfUNAQtwY0njW5bar):
				if czAy10w728nRUoaYfdNJPjStpq>=6:
					if czAy10w728nRUoaYfdNJPjStpq%gKqRJds7nmDhb!=0: continue
					slaTNFr0xXbBPyG5ndKCevfZ = ZURVzForc0AL
				else: slaTNFr0xXbBPyG5ndKCevfZ = ZURVzForc0AL//2
				stZaKcdPJMyCf4wHpb = njS0D1VfWqZ2mYoIA3PR+czAy10w728nRUoaYfdNJPjStpq*xvjre5b4yREScf
				wzDS1uGyNR = {}
				wzDS1uGyNR['title'] = eHdDoxhJCEPMZFVa2fg
				kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(stZaKcdPJMyCf4wHpb-CKna7WLojgpR-xvjre5b4yREScf)
				wzDS1uGyNR['start'] = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				wzDS1uGyNR['start_timestamp'] = str(stZaKcdPJMyCf4wHpb)
				wzDS1uGyNR['stop_timestamp'] = str(stZaKcdPJMyCf4wHpb+slaTNFr0xXbBPyG5ndKCevfZ)
				b8yfIWt2q7hedP3AjukmU0MQOT.append(wzDS1uGyNR)
	elif FStg5PE8Vmy in ['SHORT_EPG','FULL_EPG']: b8yfIWt2q7hedP3AjukmU0MQOT = bv74hDozKXOM3ifInlAUekjyR
	if FStg5PE8Vmy=='FULL_EPG' and len(b8yfIWt2q7hedP3AjukmU0MQOT)>0:
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	gJWDbVRpSe2n1F8l6jLKH = []
	Ufd6obSCcXF = ccwRLKk3hs0E.getInfoLabel('ListItem.Icon')
	for wzDS1uGyNR in b8yfIWt2q7hedP3AjukmU0MQOT:
		hgE9MlmDou = HHP76VFiKDS2xphlGsqN48j1.b64decode(wzDS1uGyNR['title'])
		if WHjh1POtMKlmgiy68RSqb: hgE9MlmDou = hgE9MlmDou.decode(m6PFtLblInpNZ8x)
		stZaKcdPJMyCf4wHpb = int(wzDS1uGyNR['start_timestamp'])
		BGEXq7PRMi1CcklZHKFeN6bUVvy3 = int(wzDS1uGyNR['stop_timestamp'])
		O9zB32Advt7E = str(int((BGEXq7PRMi1CcklZHKFeN6bUVvy3-stZaKcdPJMyCf4wHpb+59)/60))
		F0QgXY4bw6HIk9zonWfCcU5jvxK81a = wzDS1uGyNR['start'].replace(avcfIls8w7gk69hYUErHxzQTXtm24j,':')
		kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(stZaKcdPJMyCf4wHpb-xvjre5b4yREScf)
		wNnGJfLil5ry2BETMkV4bHvu8 = b8bLFaejUB.strftime('%H:%M',kkdSqXlNpHzJPsoa)
		U5iRE2rcZ3lIgHtzfPsj9 = b8bLFaejUB.strftime('%a',kkdSqXlNpHzJPsoa)
		if FStg5PE8Vmy=='SHORT_EPG': hgE9MlmDou = OR97bMGecfgDCqux3YdAZ6y+wNnGJfLil5ry2BETMkV4bHvu8+' ـ '+hgE9MlmDou+Nat0Dx9puRUWCsgz6JyFhY3
		elif FStg5PE8Vmy=='TIMESHIFT': hgE9MlmDou = U5iRE2rcZ3lIgHtzfPsj9+avcfIls8w7gk69hYUErHxzQTXtm24j+wNnGJfLil5ry2BETMkV4bHvu8+' ('+O9zB32Advt7E+'min)'
		else: hgE9MlmDou = U5iRE2rcZ3lIgHtzfPsj9+avcfIls8w7gk69hYUErHxzQTXtm24j+wNnGJfLil5ry2BETMkV4bHvu8+' ('+O9zB32Advt7E+'min)   '+hgE9MlmDou+' ـ'
		if FStg5PE8Vmy in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			IvU9e6f0Mu47wpFYz3Holx = YJ6CzR2VT4ckFjPySvqUpWGgI+'/timeshift/'+aKnyXZfMFDJViN1OtpLk+'/'+gojXxJqFmu6f+'/'+O9zB32Advt7E+'/'+F0QgXY4bw6HIk9zonWfCcU5jvxK81a+'/'+bb9EjiWfS3Zt62+'.m3u8'
			if FStg5PE8Vmy=='FULL_EPG': qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,IvU9e6f0Mu47wpFYz3Holx,9999,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('video',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,IvU9e6f0Mu47wpFYz3Holx,235,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
		gJWDbVRpSe2n1F8l6jLKH.append(hgE9MlmDou)
	if FStg5PE8Vmy=='SHORT_EPG' and gJWDbVRpSe2n1F8l6jLKH: lOtGFrbsSEDVNw2 = ToWx9yLluKgEASQDt(gJWDbVRpSe2n1F8l6jLKH)
	return gJWDbVRpSe2n1F8l6jLKH
def mX9BxIuzQT0Ld7pw4(C47G3hXaRMFLfOAEpV):
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,True): return
	YJ6CzR2VT4ckFjPySvqUpWGgI,mnGPhFpUN9BakfO6g8Yw375jLeIJAb,II9aoztRxlVXCmdyLwGH3EFe0hf = eHdDoxhJCEPMZFVa2fg,0,0
	UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,False)
	if UUQjG45NHzSqZuDe2vYIdTMlJOyc:
		XnjARw7MEty2q = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(sVvnE3SLxqUc2iQ1dNe)
		mnGPhFpUN9BakfO6g8Yw375jLeIJAb = vd3T7NboyCKmIhSZLAukRGn8Et(XnjARw7MEty2q[0],int(sVNw9Jv7gtH5aC4QjcWAYUM))
		vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'LIVE_GROUPED')
		E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','LIVE_GROUPED')
		KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','LIVE_GROUPED',E2ELD9hkvJfmeOo075IS1[1])
		Nn360bq79W2kzUt = KcogByxTmuNDInYwXALarEjUli7eOR[0][2]
		BBP5JWgHVesyaEU3Ozl = cBawilJXvK1m.findall('://(.*?)/',Nn360bq79W2kzUt,cBawilJXvK1m.DOTALL)
		BBP5JWgHVesyaEU3Ozl = BBP5JWgHVesyaEU3Ozl[0]
		if ':' in BBP5JWgHVesyaEU3Ozl: hb4vaRmE7UPwrY0IAFy6kgfsjcW3,hx6vrZYEAodzjW0tpL8DH = BBP5JWgHVesyaEU3Ozl.split(':')
		else: hb4vaRmE7UPwrY0IAFy6kgfsjcW3,hx6vrZYEAodzjW0tpL8DH = BBP5JWgHVesyaEU3Ozl,'80'
		sJAEDoz75iPduFtHjI = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(hb4vaRmE7UPwrY0IAFy6kgfsjcW3)
		II9aoztRxlVXCmdyLwGH3EFe0hf = vd3T7NboyCKmIhSZLAukRGn8Et(sJAEDoz75iPduFtHjI[0],int(hx6vrZYEAodzjW0tpL8DH))
	if mnGPhFpUN9BakfO6g8Yw375jLeIJAb and II9aoztRxlVXCmdyLwGH3EFe0hf:
		sh3cDaZzUkKQFEAl74OryuPtGqJ = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+'وقت ضائع في السيرفر الأصلي'+kDUv7ouWrcgMe6OipQJm+str(int(II9aoztRxlVXCmdyLwGH3EFe0hf*1000))+' ملي ثانية'
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+'وقت ضائع في السيرفر البديل'+kDUv7ouWrcgMe6OipQJm+str(int(mnGPhFpUN9BakfO6g8Yw375jLeIJAb*1000))+' ملي ثانية'
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if kMnoXVxN5byYJSzPrsu==1 and mnGPhFpUN9BakfO6g8Yw375jLeIJAb<II9aoztRxlVXCmdyLwGH3EFe0hf: YJ6CzR2VT4ckFjPySvqUpWGgI = sVvnE3SLxqUc2iQ1dNe+':'+sVNw9Jv7gtH5aC4QjcWAYUM
	else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	MoO74hKeqm8fFka.setSetting('av.iptv.server_'+C47G3hXaRMFLfOAEpV,YJ6CzR2VT4ckFjPySvqUpWGgI)
	return
def bbmQeYGSTIv(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9):
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV)
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.iptv.referer_'+C47G3hXaRMFLfOAEpV)
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o or T4JSyRP1bD25NGq8lOc7XhkA0iudt:
		Nn360bq79W2kzUt += '|'
		if dCKxX4PEzlZ6bNO7aB1nYqQLv835o: Nn360bq79W2kzUt += '&User-Agent='+dCKxX4PEzlZ6bNO7aB1nYqQLv835o
		if T4JSyRP1bD25NGq8lOc7XhkA0iudt: Nn360bq79W2kzUt += '&Referer='+T4JSyRP1bD25NGq8lOc7XhkA0iudt
		Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace('|&','|')
	wwOFvJDjUVz9Rt168baf = MoO74hKeqm8fFka.getSetting('av.iptv.server_'+C47G3hXaRMFLfOAEpV)
	if wwOFvJDjUVz9Rt168baf:
		XqdOWQva5yIh4cG0km2 = cBawilJXvK1m.findall('://(.*?)/',Nn360bq79W2kzUt,cBawilJXvK1m.DOTALL)
		Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace(XqdOWQva5yIh4cG0km2[0],wwOFvJDjUVz9Rt168baf)
	IZkpyKSFVarcHwG1g6emqQv70h(Nn360bq79W2kzUt,FO8SKWr40dDexHgbfRUGBi,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9)
	return
def bb9ikrhNVoXypm0f(C47G3hXaRMFLfOAEpV):
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV)
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center','استخدام الأصلي','تعديل القديم',dCKxX4PEzlZ6bNO7aB1nYqQLv835o,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if EU3GmLta4FcQPY9rOlpSe6uh7==1: dCKxX4PEzlZ6bNO7aB1nYqQLv835o = mJ1lHWKUPcZGezML7X2u9S('أكتب ـIPTV User-Agent جديد',dCKxX4PEzlZ6bNO7aB1nYqQLv835o,True)
	else: dCKxX4PEzlZ6bNO7aB1nYqQLv835o = 'Unknown'
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o==avcfIls8w7gk69hYUErHxzQTXtm24j:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dCKxX4PEzlZ6bNO7aB1nYqQLv835o,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
		return
	MoO74hKeqm8fFka.setSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV,dCKxX4PEzlZ6bNO7aB1nYqQLv835o)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def UMXb9i8NgvdGcQDpxnHE1l(C47G3hXaRMFLfOAEpV):
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.iptv.referer_'+C47G3hXaRMFLfOAEpV)
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center','استخدام الأصلي','تعديل القديم',T4JSyRP1bD25NGq8lOc7XhkA0iudt,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if EU3GmLta4FcQPY9rOlpSe6uh7==1: T4JSyRP1bD25NGq8lOc7XhkA0iudt = mJ1lHWKUPcZGezML7X2u9S('أكتب ـIPTV Referer جديد',T4JSyRP1bD25NGq8lOc7XhkA0iudt,True)
	else: T4JSyRP1bD25NGq8lOc7XhkA0iudt = eHdDoxhJCEPMZFVa2fg
	if T4JSyRP1bD25NGq8lOc7XhkA0iudt==avcfIls8w7gk69hYUErHxzQTXtm24j:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,T4JSyRP1bD25NGq8lOc7XhkA0iudt,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
		return
	MoO74hKeqm8fFka.setSetting('av.iptv.referer_'+C47G3hXaRMFLfOAEpV,T4JSyRP1bD25NGq8lOc7XhkA0iudt)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV,GJjtkMi9h7m6s4vEXCwb2grK3V=eHdDoxhJCEPMZFVa2fg):
	if not GJjtkMi9h7m6s4vEXCwb2grK3V: GJjtkMi9h7m6s4vEXCwb2grK3V = MoO74hKeqm8fFka.getSetting('av.iptv.url_'+C47G3hXaRMFLfOAEpV)
	YJ6CzR2VT4ckFjPySvqUpWGgI = b31wAB8mhaz2rXHoJFlfvDugtsOj(GJjtkMi9h7m6s4vEXCwb2grK3V,'url')
	aKnyXZfMFDJViN1OtpLk = cBawilJXvK1m.findall('username=(.*?)&',GJjtkMi9h7m6s4vEXCwb2grK3V+'&',cBawilJXvK1m.DOTALL)
	gojXxJqFmu6f = cBawilJXvK1m.findall('password=(.*?)&',GJjtkMi9h7m6s4vEXCwb2grK3V+'&',cBawilJXvK1m.DOTALL)
	if not aKnyXZfMFDJViN1OtpLk or not gojXxJqFmu6f:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	aKnyXZfMFDJViN1OtpLk = aKnyXZfMFDJViN1OtpLk[0]
	gojXxJqFmu6f = gojXxJqFmu6f[0]
	Z4qAYlatIBdvQ9HbkoK1ewSnM = YJ6CzR2VT4ckFjPySvqUpWGgI+'/player_api.php?username='+aKnyXZfMFDJViN1OtpLk+'&password='+gojXxJqFmu6f
	JIR9i57ld1yOUPcjzVv = YJ6CzR2VT4ckFjPySvqUpWGgI+'/get.php?username='+aKnyXZfMFDJViN1OtpLk+'&password='+gojXxJqFmu6f+'&type=m3u_plus'
	return Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f
def l9byZ04Phe6E8tvGRnS5HcNj(C47G3hXaRMFLfOAEpV,TWo6cYv7ZdHIqjFRDwaL=eHdDoxhJCEPMZFVa2fg):
	YYx8Ik4ETmW = TWo6cYv7ZdHIqjFRDwaL.replace('/','_').replace(':','_').replace('.','_')
	YYx8Ik4ETmW = YYx8Ik4ETmW.replace('?','_').replace('=','_').replace('&','_')
	YYx8Ik4ETmW = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,YYx8Ik4ETmW).strip('.m3u')+'.m3u'
	return YYx8Ik4ETmW
def CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV):
	PPkjeglVstfCUqK1 = MoO74hKeqm8fFka.getSetting('av.iptv.url_'+C47G3hXaRMFLfOAEpV)
	ccHod7fq84uXZRkEx = True
	if PPkjeglVstfCUqK1:
		EU3GmLta4FcQPY9rOlpSe6uh7 = vKD1rqZCXUbcR7n38VyatMSEL('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',SbyWQGMDnV+PPkjeglVstfCUqK1+Nat0Dx9puRUWCsgz6JyFhY3+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if EU3GmLta4FcQPY9rOlpSe6uh7==-1: return
		elif EU3GmLta4FcQPY9rOlpSe6uh7==0: PPkjeglVstfCUqK1 = eHdDoxhJCEPMZFVa2fg
		elif EU3GmLta4FcQPY9rOlpSe6uh7==2:
			EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EU3GmLta4FcQPY9rOlpSe6uh7 in [-1,0]: return
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح الرابط')
			ccHod7fq84uXZRkEx = False
			OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = eHdDoxhJCEPMZFVa2fg
	if ccHod7fq84uXZRkEx:
		OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = mJ1lHWKUPcZGezML7X2u9S('اكتب رابط ـIPTV كاملا',PPkjeglVstfCUqK1)
		OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = OOi8lyrfzvSkgQUT1jDbo0LCVXB3.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not OOi8lyrfzvSkgQUT1jDbo0LCVXB3:
			EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EU3GmLta4FcQPY9rOlpSe6uh7 in [-1,0]: return
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح الرابط')
	else:
		Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV,OOi8lyrfzvSkgQUT1jDbo0LCVXB3)
		if not aKnyXZfMFDJViN1OtpLk: return
		sh3cDaZzUkKQFEAl74OryuPtGqJ = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n[COLOR FFFFFF00]'+YJ6CzR2VT4ckFjPySvqUpWGgI+'[/COLOR]عنوان السيرفر: '
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n[COLOR FFFFFF00]'+aKnyXZfMFDJViN1OtpLk+'[/COLOR]اسم المستخدم: '
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n[COLOR FFFFFF00]'+gojXxJqFmu6f+'[/COLOR]كلمة السر: '
		EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('right',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'الرابط الجديد هو:',SbyWQGMDnV+OOi8lyrfzvSkgQUT1jDbo0LCVXB3+Nat0Dx9puRUWCsgz6JyFhY3+'\n\n'+sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
			return
	MoO74hKeqm8fFka.setSetting('av.iptv.url_'+C47G3hXaRMFLfOAEpV,OOi8lyrfzvSkgQUT1jDbo0LCVXB3)
	MoO74hKeqm8fFka.setSetting('av.iptv.timestamp_'+C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting('av.iptv.timediff_'+C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV)
	if not dCKxX4PEzlZ6bNO7aB1nYqQLv835o: MoO74hKeqm8fFka.setSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV,'Unknown')
	Tf37xteWqo5Invm2iYB = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,OOi8lyrfzvSkgQUT1jDbo0LCVXB3+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if Tf37xteWqo5Invm2iYB==1: UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,True)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def OOUVS5wbcN(xp7ejmzyYGO9ShDsid6RZ,ult1ETRQCWc7dILqY4eDVF9wikx3h,wPnNdxH34ZaC0mOlGsf,OiFse6HmrT1Iga9D0XwMfR,bsr1VEvZf7wR,GWv6itIHy0RUwgQzxbMN,JIR9i57ld1yOUPcjzVv):
	KcogByxTmuNDInYwXALarEjUli7eOR,ME9eavOwmHNguFlL = [],[]
	VfIUnK9OoPN7yFXsrD = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if GWv6itIHy0RUwgQzxbMN%473==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,40+int(10*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'قراءة الفيديوهات','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+str(bsr1VEvZf7wR))
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None,None
		Nn360bq79W2kzUt = cBawilJXvK1m.findall('^(.*?)\n+((http|https|rtmp).*?)$',KyujWR9edp0HVxJ,cBawilJXvK1m.DOTALL)
		if Nn360bq79W2kzUt:
			KyujWR9edp0HVxJ,Nn360bq79W2kzUt,bRaH8UFOVKAN1MBX3J05ynuGqjeIf = Nn360bq79W2kzUt[0]
			Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg)
			KyujWR9edp0HVxJ = KyujWR9edp0HVxJ.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg)
		else:
			ME9eavOwmHNguFlL.append({'line':KyujWR9edp0HVxJ})
			continue
		QwzsWf9dISmA0eMxr2G,GsPYQbREvLAFw3aJ5XghmV,L5DdYNZBtexX29zGHgQVoCiEJ,hgE9MlmDou,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,knmtBWZsi0fg2pwyFu = {},eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,False
		try:
			KyujWR9edp0HVxJ,hgE9MlmDou = KyujWR9edp0HVxJ.rsplit('",',1)
			KyujWR9edp0HVxJ = KyujWR9edp0HVxJ+'"'
		except:
			try: KyujWR9edp0HVxJ,hgE9MlmDou = KyujWR9edp0HVxJ.rsplit('1,',1)
			except: hgE9MlmDou = eHdDoxhJCEPMZFVa2fg
		QwzsWf9dISmA0eMxr2G['url'] = Nn360bq79W2kzUt
		dd27rpAXR8FhuHDqoSecZwBC3Qsy = cBawilJXvK1m.findall(' (.*?)="(.*?)"',KyujWR9edp0HVxJ,cBawilJXvK1m.DOTALL)
		for ddmHpyREIePbf5wAU,iS0cNMfBdTqAmJX3zh8nr4Y9 in dd27rpAXR8FhuHDqoSecZwBC3Qsy:
			ddmHpyREIePbf5wAU = ddmHpyREIePbf5wAU.replace('"',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			QwzsWf9dISmA0eMxr2G[ddmHpyREIePbf5wAU] = iS0cNMfBdTqAmJX3zh8nr4Y9.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		iVxlvCL28w = list(QwzsWf9dISmA0eMxr2G.keys())
		if not hgE9MlmDou:
			if 'name' in iVxlvCL28w and QwzsWf9dISmA0eMxr2G['name']: hgE9MlmDou = QwzsWf9dISmA0eMxr2G['name']
		QwzsWf9dISmA0eMxr2G['title'] = hgE9MlmDou.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'logo' in iVxlvCL28w:
			QwzsWf9dISmA0eMxr2G['img'] = QwzsWf9dISmA0eMxr2G['logo']
			del QwzsWf9dISmA0eMxr2G['logo']
		else: QwzsWf9dISmA0eMxr2G['img'] = eHdDoxhJCEPMZFVa2fg
		if 'group' in iVxlvCL28w and QwzsWf9dISmA0eMxr2G['group']: L5DdYNZBtexX29zGHgQVoCiEJ = QwzsWf9dISmA0eMxr2G['group']
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in Nn360bq79W2kzUt.lower() for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in VfIUnK9OoPN7yFXsrD):
			knmtBWZsi0fg2pwyFu = True if 'm3u' not in Nn360bq79W2kzUt else False
		if knmtBWZsi0fg2pwyFu or '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ or '__MOVIES__' in L5DdYNZBtexX29zGHgQVoCiEJ:
			IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'VOD'
			if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_SERIES'
			elif '__MOVIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_MOVIES'
			else: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_UNKNOWN'
			L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.replace('__SERIES__',eHdDoxhJCEPMZFVa2fg).replace('__MOVIES__',eHdDoxhJCEPMZFVa2fg)
		else:
			IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'LIVE'
			if hgE9MlmDou in ult1ETRQCWc7dILqY4eDVF9wikx3h: GsPYQbREvLAFw3aJ5XghmV = GsPYQbREvLAFw3aJ5XghmV+'_EPG'
			if hgE9MlmDou in wPnNdxH34ZaC0mOlGsf: GsPYQbREvLAFw3aJ5XghmV = GsPYQbREvLAFw3aJ5XghmV+'_ARCHIVED'
			if not L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_UNKNOWN'
			else: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+GsPYQbREvLAFw3aJ5XghmV
		L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'LIVE_UNKNOWN' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9: L5DdYNZBtexX29zGHgQVoCiEJ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9: L5DdYNZBtexX29zGHgQVoCiEJ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9:
			Fxr4eJsb70QZ = cBawilJXvK1m.findall('(.*?) [Ss]\d+ +[Ee]\d+',QwzsWf9dISmA0eMxr2G['title'],cBawilJXvK1m.DOTALL)
			if Fxr4eJsb70QZ: Fxr4eJsb70QZ = Fxr4eJsb70QZ[0]
			else: Fxr4eJsb70QZ = '!!__UNKNOWN_SERIES__!!'
			L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ+'__SERIES__'+Fxr4eJsb70QZ
		if 'id' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['id']
		if 'ID' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['ID']
		if 'name' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['name']
		hgE9MlmDou = QwzsWf9dISmA0eMxr2G['title']
		hgE9MlmDou = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(hgE9MlmDou)
		hgE9MlmDou = QCVBvbhYerZWxHumPIa8i1kGq(hgE9MlmDou)
		oit8rylYd3Q6ReqxHDOU2vXsgA,L5DdYNZBtexX29zGHgQVoCiEJ = I79o6neSfOlXmL(L5DdYNZBtexX29zGHgQVoCiEJ)
		HdmksvabBKMuS,hgE9MlmDou = I79o6neSfOlXmL(hgE9MlmDou)
		QwzsWf9dISmA0eMxr2G['type'] = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9
		QwzsWf9dISmA0eMxr2G['context'] = GsPYQbREvLAFw3aJ5XghmV
		QwzsWf9dISmA0eMxr2G['group'] = L5DdYNZBtexX29zGHgQVoCiEJ.upper()
		QwzsWf9dISmA0eMxr2G['title'] = hgE9MlmDou.upper()
		QwzsWf9dISmA0eMxr2G['country'] = HdmksvabBKMuS.upper()
		QwzsWf9dISmA0eMxr2G['language'] = oit8rylYd3Q6ReqxHDOU2vXsgA.upper()
		KcogByxTmuNDInYwXALarEjUli7eOR.append(QwzsWf9dISmA0eMxr2G)
		GWv6itIHy0RUwgQzxbMN += 1
	return KcogByxTmuNDInYwXALarEjUli7eOR,GWv6itIHy0RUwgQzxbMN,ME9eavOwmHNguFlL
def QCVBvbhYerZWxHumPIa8i1kGq(hgE9MlmDou):
	hgE9MlmDou = hgE9MlmDou.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	hgE9MlmDou = hgE9MlmDou.replace('||','|').replace('___',':').replace('--','-')
	hgE9MlmDou = hgE9MlmDou.replace('[[','[').replace(']]',']')
	hgE9MlmDou = hgE9MlmDou.replace('((','(').replace('))',')')
	hgE9MlmDou = hgE9MlmDou.replace('<<','<').replace('>>','>')
	hgE9MlmDou = hgE9MlmDou.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	return hgE9MlmDou
def l1dv7FkD8BN0Ay32KMGaiTfW4uJ(gLoId1uPvFDK,OiFse6HmrT1Iga9D0XwMfR):
	aaH5voLOlVU8F = {}
	for PcwEmo0dXj7vu8zypFefxDMr in ga2Cxd7Bulrb: aaH5voLOlVU8F[PcwEmo0dXj7vu8zypFefxDMr] = []
	bsr1VEvZf7wR = len(gLoId1uPvFDK)
	VVLvyiKDt0eoW = str(bsr1VEvZf7wR)
	GWv6itIHy0RUwgQzxbMN = 0
	ME9eavOwmHNguFlL = []
	for QwzsWf9dISmA0eMxr2G in gLoId1uPvFDK:
		if GWv6itIHy0RUwgQzxbMN%873==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,50+int(5*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+VVLvyiKDt0eoW)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None
		L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF = QwzsWf9dISmA0eMxr2G['group'],QwzsWf9dISmA0eMxr2G['context'],QwzsWf9dISmA0eMxr2G['title'],QwzsWf9dISmA0eMxr2G['url'],QwzsWf9dISmA0eMxr2G['img']
		HdmksvabBKMuS,oit8rylYd3Q6ReqxHDOU2vXsgA,PcwEmo0dXj7vu8zypFefxDMr = QwzsWf9dISmA0eMxr2G['country'],QwzsWf9dISmA0eMxr2G['language'],QwzsWf9dISmA0eMxr2G['type']
		u5g2qtGyeaocXSp4Mn = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		EVfiWGwHpCReXt4x3PU7cMmyhBJ = False
		if 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_UNKNOWN_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
			elif 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
			else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
			aaH5voLOlVU8F['LIVE_ORIGINAL_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
		elif 'VOD' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_UNKNOWN_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
			elif 'MOVIES' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_MOVIES_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
			elif 'SERIES' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_SERIES_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
			else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
			aaH5voLOlVU8F['VOD_ORIGINAL_GROUPED'].append(u5g2qtGyeaocXSp4Mn)
		else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
		if EVfiWGwHpCReXt4x3PU7cMmyhBJ: ME9eavOwmHNguFlL.append(QwzsWf9dISmA0eMxr2G)
		GWv6itIHy0RUwgQzxbMN += 1
	uypTh5gjEmkGSNPo2QeJZYRiFM = sorted(gLoId1uPvFDK,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU['title'].lower())
	del gLoId1uPvFDK
	VVLvyiKDt0eoW = str(bsr1VEvZf7wR)
	GWv6itIHy0RUwgQzxbMN = 0
	for QwzsWf9dISmA0eMxr2G in uypTh5gjEmkGSNPo2QeJZYRiFM:
		GWv6itIHy0RUwgQzxbMN += 1
		if GWv6itIHy0RUwgQzxbMN%873==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,55+int(5*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+VVLvyiKDt0eoW)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None
		PcwEmo0dXj7vu8zypFefxDMr = QwzsWf9dISmA0eMxr2G['type']
		L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF = QwzsWf9dISmA0eMxr2G['group'],QwzsWf9dISmA0eMxr2G['context'],QwzsWf9dISmA0eMxr2G['title'],QwzsWf9dISmA0eMxr2G['url'],QwzsWf9dISmA0eMxr2G['img']
		HdmksvabBKMuS,oit8rylYd3Q6ReqxHDOU2vXsgA = QwzsWf9dISmA0eMxr2G['country'],QwzsWf9dISmA0eMxr2G['language']
		OO0R75zfjaSAEVGyYtpe6kK = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV+'_TIMESHIFT',hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		u5g2qtGyeaocXSp4Mn = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		Q8wpZlFh0NzC = (HdmksvabBKMuS,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		mrBwnbvZVGSahquMf7PE3yXCt = (oit8rylYd3Q6ReqxHDOU2vXsgA,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		if 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_UNKNOWN_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			else: aaH5voLOlVU8F['LIVE_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			if 'EPG'		in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_EPG_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			if 'ARCHIVED'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_ARCHIVED_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			if 'ARCHIVED'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_TIMESHIFT_GROUPED_SORTED'].append(OO0R75zfjaSAEVGyYtpe6kK)
			aaH5voLOlVU8F['LIVE_FROM_NAME_SORTED'].append(Q8wpZlFh0NzC)
			aaH5voLOlVU8F['LIVE_FROM_GROUP_SORTED'].append(mrBwnbvZVGSahquMf7PE3yXCt)
		elif 'VOD' in PcwEmo0dXj7vu8zypFefxDMr:
			if   'UNKNOWN'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_UNKNOWN_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			elif 'MOVIES'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_MOVIES_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			elif 'SERIES'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_SERIES_GROUPED_SORTED'].append(u5g2qtGyeaocXSp4Mn)
			aaH5voLOlVU8F['VOD_FROM_NAME_SORTED'].append(Q8wpZlFh0NzC)
			aaH5voLOlVU8F['VOD_FROM_GROUP_SORTED'].append(mrBwnbvZVGSahquMf7PE3yXCt)
	return aaH5voLOlVU8F,ME9eavOwmHNguFlL
def I79o6neSfOlXmL(hgE9MlmDou):
	if len(hgE9MlmDou)<3: return hgE9MlmDou,hgE9MlmDou
	TsH70GYWil9bp3MCEXQc,CuF4Ef9vHh15ULo68rJmxyAbnW = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	qF1gt9sVAvQOpUHBR6rLfx0X = hgE9MlmDou
	NBAPne0hvwuSM6L32ot7Jrmdbq = hgE9MlmDou[:1]
	XX3juewvVBR2iQg8lnGHP = hgE9MlmDou[1:]
	if   NBAPne0hvwuSM6L32ot7Jrmdbq=='(': CuF4Ef9vHh15ULo68rJmxyAbnW = ')'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='[': CuF4Ef9vHh15ULo68rJmxyAbnW = ']'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='<': CuF4Ef9vHh15ULo68rJmxyAbnW = '>'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='|': CuF4Ef9vHh15ULo68rJmxyAbnW = '|'
	if CuF4Ef9vHh15ULo68rJmxyAbnW and (CuF4Ef9vHh15ULo68rJmxyAbnW in XX3juewvVBR2iQg8lnGHP):
		urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = XX3juewvVBR2iQg8lnGHP.split(CuF4Ef9vHh15ULo68rJmxyAbnW,1)
		TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
		qF1gt9sVAvQOpUHBR6rLfx0X = NBAPne0hvwuSM6L32ot7Jrmdbq+urfMB9ZIJX8e1kWibaNoEd+CuF4Ef9vHh15ULo68rJmxyAbnW+avcfIls8w7gk69hYUErHxzQTXtm24j+EXbh38gFq1wJoVRvckO0Mi
	elif hgE9MlmDou.count('|')>=2:
		urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = hgE9MlmDou.split('|',1)
		TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
		qF1gt9sVAvQOpUHBR6rLfx0X = urfMB9ZIJX8e1kWibaNoEd+' |'+EXbh38gFq1wJoVRvckO0Mi
	else:
		CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if not CuF4Ef9vHh15ULo68rJmxyAbnW: CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if not CuF4Ef9vHh15ULo68rJmxyAbnW: CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if CuF4Ef9vHh15ULo68rJmxyAbnW:
			urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = hgE9MlmDou.split(CuF4Ef9vHh15ULo68rJmxyAbnW[0],1)
			TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
			qF1gt9sVAvQOpUHBR6rLfx0X = urfMB9ZIJX8e1kWibaNoEd+avcfIls8w7gk69hYUErHxzQTXtm24j+CuF4Ef9vHh15ULo68rJmxyAbnW[0]+avcfIls8w7gk69hYUErHxzQTXtm24j+EXbh38gFq1wJoVRvckO0Mi
	qF1gt9sVAvQOpUHBR6rLfx0X = qF1gt9sVAvQOpUHBR6rLfx0X.replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	TsH70GYWil9bp3MCEXQc = TsH70GYWil9bp3MCEXQc.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	if not TsH70GYWil9bp3MCEXQc: TsH70GYWil9bp3MCEXQc = '!!__UNKNOWN__!!'
	TsH70GYWil9bp3MCEXQc = TsH70GYWil9bp3MCEXQc.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	qF1gt9sVAvQOpUHBR6rLfx0X = qF1gt9sVAvQOpUHBR6rLfx0X.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	return TsH70GYWil9bp3MCEXQc,qF1gt9sVAvQOpUHBR6rLfx0X
def vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV):
	bJ4IumHdZTPlG6 = {}
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.iptv.useragent_'+C47G3hXaRMFLfOAEpV)
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o: bJ4IumHdZTPlG6['User-Agent'] = dCKxX4PEzlZ6bNO7aB1nYqQLv835o
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.iptv.referer_'+C47G3hXaRMFLfOAEpV)
	if T4JSyRP1bD25NGq8lOc7XhkA0iudt: bJ4IumHdZTPlG6['Referer'] = T4JSyRP1bD25NGq8lOc7XhkA0iudt
	return bJ4IumHdZTPlG6
def IIXfKPZEkUOFwLR4mxQ05jnH(C47G3hXaRMFLfOAEpV):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if not aKnyXZfMFDJViN1OtpLk: return
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if kMnoXVxN5byYJSzPrsu!=1: return
	YYx8Ik4ETmW = MvwZCzPqKXpJoeIHxmnBs976.replace('___','_'+C47G3hXaRMFLfOAEpV)
	if 1:
		UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,False)
		if not UUQjG45NHzSqZuDe2vYIdTMlJOyc:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not JIR9i57ld1yOUPcjzVv: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(FO8SKWr40dDexHgbfRUGBi)+'   No IPTV URL found to download IPTV files')
			else: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(FO8SKWr40dDexHgbfRUGBi)+'   Failed to download IPTV files')
			return
		UbmXqGrFh9wPWxaTD80ysegdQut = L7IPyDUvXQwA2e9fChNruZcYM50(JIR9i57ld1yOUPcjzVv,bJ4IumHdZTPlG6,True)
		if not UbmXqGrFh9wPWxaTD80ysegdQut: return
		open(YYx8Ik4ETmW,'wb').write(UbmXqGrFh9wPWxaTD80ysegdQut)
	else: UbmXqGrFh9wPWxaTD80ysegdQut = open(YYx8Ik4ETmW,'rb').read()
	if WHjh1POtMKlmgiy68RSqb and UbmXqGrFh9wPWxaTD80ysegdQut: UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.decode(m6PFtLblInpNZ8x)
	OiFse6HmrT1Iga9D0XwMfR = R62V7GXNPvf8()
	OiFse6HmrT1Iga9D0XwMfR.create('جلب ملفات ـIPTV جديدة',eHdDoxhJCEPMZFVa2fg)
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,15,'تنظيف الملف الرئيسي',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('"tvg-','" tvg-')
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('َ',eHdDoxhJCEPMZFVa2fg).replace('ً',eHdDoxhJCEPMZFVa2fg).replace('ُ',eHdDoxhJCEPMZFVa2fg).replace('ٌ',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('ّ',eHdDoxhJCEPMZFVa2fg).replace('ِ',eHdDoxhJCEPMZFVa2fg).replace('ٍ',eHdDoxhJCEPMZFVa2fg).replace('ْ',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('group-title=','group=').replace('tvg-',eHdDoxhJCEPMZFVa2fg)
	wPnNdxH34ZaC0mOlGsf,ult1ETRQCWc7dILqY4eDVF9wikx3h = [],[]
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_series_categories'
	W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',Nn360bq79W2kzUt,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IPTV-CREATE_STREAMS-1st')
	yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
	yu26R85ckHMoK3reLVwSd = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(yu26R85ckHMoK3reLVwSd)
	kkfqNzXMa0m6QnYjJGTDRcUbdVohl = cBawilJXvK1m.findall('category_name":"(.*?)"',yu26R85ckHMoK3reLVwSd,cBawilJXvK1m.DOTALL)
	del yu26R85ckHMoK3reLVwSd
	for L5DdYNZBtexX29zGHgQVoCiEJ in kkfqNzXMa0m6QnYjJGTDRcUbdVohl:
		L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.replace('\/','/')
		if lHfbysRrUV7m4CLSdkxc382n: L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
		UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('group="'+L5DdYNZBtexX29zGHgQVoCiEJ+'"','group="__SERIES__'+L5DdYNZBtexX29zGHgQVoCiEJ+'"')
	del kkfqNzXMa0m6QnYjJGTDRcUbdVohl
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_vod_categories'
	W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',Nn360bq79W2kzUt,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IPTV-CREATE_STREAMS-2nd')
	yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
	yu26R85ckHMoK3reLVwSd = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(yu26R85ckHMoK3reLVwSd)
	IxrNG6Y204K = cBawilJXvK1m.findall('category_name":"(.*?)"',yu26R85ckHMoK3reLVwSd,cBawilJXvK1m.DOTALL)
	del yu26R85ckHMoK3reLVwSd
	for L5DdYNZBtexX29zGHgQVoCiEJ in IxrNG6Y204K:
		L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.replace('\/','/')
		if lHfbysRrUV7m4CLSdkxc382n: L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
		UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('group="'+L5DdYNZBtexX29zGHgQVoCiEJ+'"','group="__MOVIES__'+L5DdYNZBtexX29zGHgQVoCiEJ+'"')
	del IxrNG6Y204K
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_live_streams'
	W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',Nn360bq79W2kzUt,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IPTV-CREATE_STREAMS-3rd')
	yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
	yu26R85ckHMoK3reLVwSd = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(yu26R85ckHMoK3reLVwSd)
	iu1TlgcPEn0BZbDdNAyGUMImv8tSF = cBawilJXvK1m.findall('"name":"(.*?)".*?"tv_archive":(.*?),',yu26R85ckHMoK3reLVwSd,cBawilJXvK1m.DOTALL)
	for Pe9ETSvwUGBnkC1hO,zWbwBHSf6aT5k1XvKOY8N in iu1TlgcPEn0BZbDdNAyGUMImv8tSF:
		if zWbwBHSf6aT5k1XvKOY8N=='1': wPnNdxH34ZaC0mOlGsf.append(Pe9ETSvwUGBnkC1hO)
	del iu1TlgcPEn0BZbDdNAyGUMImv8tSF
	OPbKI9Jn6RCokTYAj4Nlg5cpF = cBawilJXvK1m.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',yu26R85ckHMoK3reLVwSd,cBawilJXvK1m.DOTALL)
	del yu26R85ckHMoK3reLVwSd
	for Pe9ETSvwUGBnkC1hO,ycdSb9LzAKPi04hWOCDHeQT3ta in OPbKI9Jn6RCokTYAj4Nlg5cpF:
		if ycdSb9LzAKPi04hWOCDHeQT3ta!='null': ult1ETRQCWc7dILqY4eDVF9wikx3h.append(Pe9ETSvwUGBnkC1hO)
	del OPbKI9Jn6RCokTYAj4Nlg5cpF
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace(y1fVB2E63aLnJgkWeCZHujY,kDUv7ouWrcgMe6OipQJm)
	xp7ejmzyYGO9ShDsid6RZ = cBawilJXvK1m.findall('NF:(.+?)'+'#'+'EXTI',UbmXqGrFh9wPWxaTD80ysegdQut+'\n+'+'#'+'EXTINF:',cBawilJXvK1m.DOTALL)
	if not xp7ejmzyYGO9ShDsid6RZ:
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(FO8SKWr40dDexHgbfRUGBi)+'   Folder:'+C47G3hXaRMFLfOAEpV+'   No video links found in IPTV file')
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+'مجلد رقم '+C47G3hXaRMFLfOAEpV)
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	uumEKnHI2SDRTZx4 = []
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U = KyujWR9edp0HVxJ.lower()
		if 'adult' in SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U: continue
		if 'xxx' in SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U: continue
		uumEKnHI2SDRTZx4.append(KyujWR9edp0HVxJ)
	xp7ejmzyYGO9ShDsid6RZ = uumEKnHI2SDRTZx4
	del uumEKnHI2SDRTZx4
	KNTh6j0Zz7JysSbq8vYHAg = 1024*1024
	HCqy9hx1AjMb = 1+len(UbmXqGrFh9wPWxaTD80ysegdQut)//KNTh6j0Zz7JysSbq8vYHAg//10
	del UbmXqGrFh9wPWxaTD80ysegdQut
	kHo1zyqQnOXeKYBvVf = len(xp7ejmzyYGO9ShDsid6RZ)
	ccna6s18WuQwJTriSdCN = OyNBvcZVXKnLsJbupPQzm0rAES6g7(xp7ejmzyYGO9ShDsid6RZ,HCqy9hx1AjMb)
	del xp7ejmzyYGO9ShDsid6RZ
	for eMVgaSfkty1AwQT6Obo in range(HCqy9hx1AjMb):
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,35+int(5*eMVgaSfkty1AwQT6Obo/HCqy9hx1AjMb),'تقطيع الملف الرئيسي','الجزء رقم:-',str(eMVgaSfkty1AwQT6Obo+1)+' / '+str(HCqy9hx1AjMb))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		cn4JlBthS58RGbNVkzLWgyfjI0q = str(ccna6s18WuQwJTriSdCN[eMVgaSfkty1AwQT6Obo])
		if WHjh1POtMKlmgiy68RSqb: cn4JlBthS58RGbNVkzLWgyfjI0q = cn4JlBthS58RGbNVkzLWgyfjI0q.encode(m6PFtLblInpNZ8x)
		open(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo),'wb').write(cn4JlBthS58RGbNVkzLWgyfjI0q)
	del ccna6s18WuQwJTriSdCN,cn4JlBthS58RGbNVkzLWgyfjI0q
	YAotNvdI7EQ,gLoId1uPvFDK,GWv6itIHy0RUwgQzxbMN = [],[],0
	for eMVgaSfkty1AwQT6Obo in range(HCqy9hx1AjMb):
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		cn4JlBthS58RGbNVkzLWgyfjI0q = open(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo),'rb').read()
		b8bLFaejUB.sleep(1)
		try: RRydns1CErYlIhwSx7.remove(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo))
		except: pass
		if WHjh1POtMKlmgiy68RSqb: cn4JlBthS58RGbNVkzLWgyfjI0q = cn4JlBthS58RGbNVkzLWgyfjI0q.decode(m6PFtLblInpNZ8x)
		LDByuEM3xXdFfvQAz = DIpuHqsKGS3ErJvk9taCRiX80('list',cn4JlBthS58RGbNVkzLWgyfjI0q)
		del cn4JlBthS58RGbNVkzLWgyfjI0q
		KcogByxTmuNDInYwXALarEjUli7eOR,GWv6itIHy0RUwgQzxbMN,ME9eavOwmHNguFlL = OOUVS5wbcN(LDByuEM3xXdFfvQAz,ult1ETRQCWc7dILqY4eDVF9wikx3h,wPnNdxH34ZaC0mOlGsf,OiFse6HmrT1Iga9D0XwMfR,kHo1zyqQnOXeKYBvVf,GWv6itIHy0RUwgQzxbMN,JIR9i57ld1yOUPcjzVv)
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		if not KcogByxTmuNDInYwXALarEjUli7eOR:
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		gLoId1uPvFDK += KcogByxTmuNDInYwXALarEjUli7eOR
		YAotNvdI7EQ += ME9eavOwmHNguFlL
	del LDByuEM3xXdFfvQAz,KcogByxTmuNDInYwXALarEjUli7eOR
	aaH5voLOlVU8F,ME9eavOwmHNguFlL = l1dv7FkD8BN0Ay32KMGaiTfW4uJ(gLoId1uPvFDK,OiFse6HmrT1Iga9D0XwMfR)
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	YAotNvdI7EQ += ME9eavOwmHNguFlL
	del gLoId1uPvFDK,ME9eavOwmHNguFlL
	EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG = {},{},{},0,0
	npBKIJvWu7dtoaOMEHGFzqQc32 = list(aaH5voLOlVU8F.keys())
	wAUgWxSDf75O6eyvkVRj8KFnc = len(npBKIJvWu7dtoaOMEHGFzqQc32)*3
	if 1:
		dWpNKnGlcgOzVHm6CU7texM4u = {}
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=XMWRpq7Zo1IQrDVmCdKncUT9xawHgh,args=(PiD9gwCG7zxRHVKkaeldoUbZr,))
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].start()
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].join()
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
	else:
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			XMWRpq7Zo1IQrDVmCdKncUT9xawHgh(PiD9gwCG7zxRHVKkaeldoUbZr)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
	wAYOZDQ2dPyL9GW14HBa0ImT(C47G3hXaRMFLfOAEpV,False)
	npBKIJvWu7dtoaOMEHGFzqQc32 = list(EVtvDQNMeaWTjYrfc.keys())
	k8zbSQC9Hy = 0
	if 1:
		dWpNKnGlcgOzVHm6CU7texM4u = {}
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=l8C3RMLkBVaNdOX,args=(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr))
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].start()
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].join()
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
	else:
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			l8C3RMLkBVaNdOX(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
	eMVgaSfkty1AwQT6Obo = 0
	eesaApIdPixtmo84 = len(YAotNvdI7EQ)
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'IGNORED')
	for DEQjoMf425u in YAotNvdI7EQ:
		if eMVgaSfkty1AwQT6Obo%27==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,95+int(5*eMVgaSfkty1AwQT6Obo//eesaApIdPixtmo84),'تخزين المهملة','الفيديو رقم:-',str(eMVgaSfkty1AwQT6Obo)+' / '+str(eesaApIdPixtmo84))
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'IGNORED',str(DEQjoMf425u),eHdDoxhJCEPMZFVa2fg,ICRfWub2vqlor0Q)
		eMVgaSfkty1AwQT6Obo += 1
	CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'IGNORED','__COUNT__',str(eesaApIdPixtmo84),ICRfWub2vqlor0Q)
	CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'DUMMY','__DUMMY__','1',ICRfWub2vqlor0Q)
	OiFse6HmrT1Iga9D0XwMfR.close()
	b8bLFaejUB.sleep(1)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY = Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV,False)
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج',OR97bMGecfgDCqux3YdAZ6y+'تم جلب ملفات ـIPTV جديدة'+Nat0Dx9puRUWCsgz6JyFhY3+'\n\n'+NTtEhHMqpnBZwWguVLab7l2x8KRiY)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	wJ0l2uCDMF8IiEzsvykhP(False)
	AOwqYZ30sN1Mp(False)
	return
def XMWRpq7Zo1IQrDVmCdKncUT9xawHgh(PiD9gwCG7zxRHVKkaeldoUbZr):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr] = {}
	NYnyxQmgDj5olfO,mWI4dnz0eLRfvSOwPcTNlxFi = {},[]
	cciVhzZTlebn3gJ0LRd8PsQxMr = len(aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr])
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr]['__COUNT__'] = cciVhzZTlebn3gJ0LRd8PsQxMr
	if cciVhzZTlebn3gJ0LRd8PsQxMr>0:
		XdpkxWuNMV,GdVXLWH1FCx,XH21YrVwGz7JBim0o,sCdaDQGUPubiWqcZ12IHJNOVmpRn,JKS31UGHTnPC0fOAFIR6vwikobMsmu = zip(*aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr])
		del GdVXLWH1FCx,XH21YrVwGz7JBim0o,sCdaDQGUPubiWqcZ12IHJNOVmpRn
		ggorpqK2ea = list(set(XdpkxWuNMV))
		for L5DdYNZBtexX29zGHgQVoCiEJ in ggorpqK2ea:
			NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] = eHdDoxhJCEPMZFVa2fg
			EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ] = []
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		bb0VqFsOEBAIjG += 1
		Xy4EgaIKekwGYFphn8 = len(ggorpqK2ea)
		del ggorpqK2ea
		mWI4dnz0eLRfvSOwPcTNlxFi = list(set(zip(XdpkxWuNMV,JKS31UGHTnPC0fOAFIR6vwikobMsmu)))
		del XdpkxWuNMV,JKS31UGHTnPC0fOAFIR6vwikobMsmu
		for L5DdYNZBtexX29zGHgQVoCiEJ,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV in mWI4dnz0eLRfvSOwPcTNlxFi:
			if not NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] and Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV: NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] = Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		bb0VqFsOEBAIjG += 1
		UfOnBo6t5LcwvD23 = list(NYnyxQmgDj5olfO.keys())
		vg1CXkFzB5IZe = list(NYnyxQmgDj5olfO.values())
		del NYnyxQmgDj5olfO
		mWI4dnz0eLRfvSOwPcTNlxFi = list(zip(UfOnBo6t5LcwvD23,vg1CXkFzB5IZe))
		del UfOnBo6t5LcwvD23,vg1CXkFzB5IZe
		mWI4dnz0eLRfvSOwPcTNlxFi = sorted(mWI4dnz0eLRfvSOwPcTNlxFi)
	else: bb0VqFsOEBAIjG += 2
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr]['__GROUPS__'] = mWI4dnz0eLRfvSOwPcTNlxFi
	del mWI4dnz0eLRfvSOwPcTNlxFi
	for L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr]:
		EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ].append((GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF))
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
	bb0VqFsOEBAIjG += 1
	del aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr]
	E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr] = list(EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr].keys())
	erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr] = len(E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr])
	bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j += erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]
	return
def l8C3RMLkBVaNdOX(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	for GWv6itIHy0RUwgQzxbMN in range(1+erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]//273):
		TpLkUNGBs9q = []
		zzstBhr73YXEqRVH0UZDg = E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr][0:273]
		for L5DdYNZBtexX29zGHgQVoCiEJ in zzstBhr73YXEqRVH0UZDg:
			TpLkUNGBs9q.append(EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ])
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr,zzstBhr73YXEqRVH0UZDg,TpLkUNGBs9q,ICRfWub2vqlor0Q,True)
		k8zbSQC9Hy += len(zzstBhr73YXEqRVH0UZDg)
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,75+int(20*k8zbSQC9Hy//bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j),'تخزين القوائم','القائمة رقم:-',str(k8zbSQC9Hy)+' / '+str(bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		del E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr][0:273]
	del EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr],E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr],erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]
	return
def Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w=True):
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	Vs8fbBNJaykLqQvg1Y5IFoGWj6d0 = 'رسالة من المبرمج'
	f0fp9q1PHnwTjraIxBC5c7d = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'LIVE_ORIGINAL_GROUPED')
	bWnMG2tvludPcH = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'VOD_ORIGINAL_GROUPED')
	eesaApIdPixtmo84 = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','IGNORED','__COUNT__')
	bBsVrfxLyMK2ia3gX = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	oQp0jiDc9WPbHnL7f8rtkFG4yMZ = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	KbUCLf2FYW0 = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_GROUPED','__COUNT__')
	gNC246pFbMUJGP1KOzwVDkmEZ = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	LLo7SuZ9JbXE3nxPY2DWVAq = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','VOD_MOVIES_GROUPED','__COUNT__')
	DXjEwvTW9UJgnQ = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'int','VOD_SERIES_GROUPED','__COUNT__')
	dO2VQ4ixR76HrqUIBSsfJuozF = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'list','VOD_SERIES_GROUPED','__GROUPS__')
	wwbYcPyiLgGH8kIUzZ = []
	for L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF in E2ELD9hkvJfmeOo075IS1:
		GGA495Cqbj = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')[1]
		wwbYcPyiLgGH8kIUzZ.append(GGA495Cqbj)
	BJ2hqwH93uKI = len(wwbYcPyiLgGH8kIUzZ)
	RVOyUD2s8Bk9FLCwu4MSKJgt = int(LLo7SuZ9JbXE3nxPY2DWVAq)+int(DXjEwvTW9UJgnQ)+int(dO2VQ4ixR76HrqUIBSsfJuozF)+int(gNC246pFbMUJGP1KOzwVDkmEZ)+int(KbUCLf2FYW0)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY = eHdDoxhJCEPMZFVa2fg
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += 'قنوات: '+str(KbUCLf2FYW0)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   أفلام: '+str(LLo7SuZ9JbXE3nxPY2DWVAq)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nمسلسلات: '+str(BJ2hqwH93uKI)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   حلقات: '+str(DXjEwvTW9UJgnQ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nقنوات مجهولة: '+str(gNC246pFbMUJGP1KOzwVDkmEZ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   فيدوهات مجهولة: '+str(dO2VQ4ixR76HrqUIBSsfJuozF)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nمجموع القنوات: '+str(bBsVrfxLyMK2ia3gX)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   مجموع الفيديوهات: '+str(oQp0jiDc9WPbHnL7f8rtkFG4yMZ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\n\nمجموع المضافة: '+str(RVOyUD2s8Bk9FLCwu4MSKJgt)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   مجموع المهملة: '+str(eesaApIdPixtmo84)
	if UzF4sIShoZEgRjc7LK8w: dXINKZJp6Tbu7wmS('center',eHdDoxhJCEPMZFVa2fg,Vs8fbBNJaykLqQvg1Y5IFoGWj6d0,NTtEhHMqpnBZwWguVLab7l2x8KRiY)
	FAQoDZUr0CEYdO1eHXS5hLft8sGPKb = NTtEhHMqpnBZwWguVLab7l2x8KRiY.replace('\n\n',kDUv7ouWrcgMe6OipQJm)
	vR9cOpMtk51j(iwIlVQsgYezu,'.\tCounts of IPTV videos   Folder: '+C47G3hXaRMFLfOAEpV+kDUv7ouWrcgMe6OipQJm+FAQoDZUr0CEYdO1eHXS5hLft8sGPKb)
	return NTtEhHMqpnBZwWguVLab7l2x8KRiY
def wAYOZDQ2dPyL9GW14HBa0ImT(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w=True):
	if UzF4sIShoZEgRjc7LK8w:
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if kMnoXVxN5byYJSzPrsu!=1: return
		zzPjQDgvuq = MvwZCzPqKXpJoeIHxmnBs976.replace('___','_'+C47G3hXaRMFLfOAEpV)
		try: RRydns1CErYlIhwSx7.remove(zzPjQDgvuq)
		except: pass
	zzPjQDgvuq = wAR4O5i9os3q.replace('___','_'+C47G3hXaRMFLfOAEpV)
	try: RRydns1CErYlIhwSx7.remove(zzPjQDgvuq)
	except: pass
	zzPjQDgvuq = lsZrOnAhvFNgoWXi7Czd2q8YpIDE.replace('___','_'+C47G3hXaRMFLfOAEpV)
	try: RRydns1CErYlIhwSx7.remove(zzPjQDgvuq)
	except: pass
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_IPTV','SECTIONS_IPTV_'+C47G3hXaRMFLfOAEpV)
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	wJ0l2uCDMF8IiEzsvykhP(False)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	if UzF4sIShoZEgRjc7LK8w:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		AOwqYZ30sN1Mp(False)
	return
def ffdr02bStCnz(C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=True):
	if C47G3hXaRMFLfOAEpV:
		vXSV4tIkDzNC = K0sLrB3qvJn9Edt(str(C47G3hXaRMFLfOAEpV),'DUMMY')
		bRaH8UFOVKAN1MBX3J05ynuGqjeIf = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'str','DUMMY','__DUMMY__')
		if bRaH8UFOVKAN1MBX3J05ynuGqjeIf: return True
	else:
		C47G3hXaRMFLfOAEpV = '1'
		for bb6cBW5yweZGvuXo0NQlM in range(1,II0HXSngDhlLOuNQ9Vi+1):
			vXSV4tIkDzNC = K0sLrB3qvJn9Edt(str(bb6cBW5yweZGvuXo0NQlM),'DUMMY')
			bRaH8UFOVKAN1MBX3J05ynuGqjeIf = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'str','DUMMY','__DUMMY__')
			if bRaH8UFOVKAN1MBX3J05ynuGqjeIf: return True
	if UzF4sIShoZEgRjc7LK8w:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		Vs8fbBNJaykLqQvg1Y5IFoGWj6d0 = 'إضافة وتغيير رابط '+Fv7ouzCZdqTc95fJKBXA[1]+' (مجلد '+Fv7ouzCZdqTc95fJKBXA[int(C47G3hXaRMFLfOAEpV)]+')'
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Vs8fbBNJaykLqQvg1Y5IFoGWj6d0,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if kMnoXVxN5byYJSzPrsu==1: CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV)
	return False
def A1AxPpad9tTLBbeIiOSQs2yq87hFW(m0Qu6qaroU,C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,PiD9gwCG7zxRHVKkaeldoUbZr=eHdDoxhJCEPMZFVa2fg,sxFw3Wz7DhVL=eHdDoxhJCEPMZFVa2fg):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	ZrzxY0D21f9ACB65S,j2TA4h0FekYb3a5B,UzF4sIShoZEgRjc7LK8w = F1T64yBoQa5b(m0Qu6qaroU)
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
	Liao5DfByHKGuW = [eHdDoxhJCEPMZFVa2fg,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not PiD9gwCG7zxRHVKkaeldoUbZr:
		if not UzF4sIShoZEgRjc7LK8w:
			if   '_IPTV-LIVE_' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[1]
			elif '_IPTV-MOVIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[2]
			elif '_IPTV-SERIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[3]
			else: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[0]
		else:
			hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			iL3sKTVC7EZgM9kDajU1FYGBqWrdc = ZZhzstQTSCXRg('أختر البحث المناسب', hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ)
			if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==-1: return
			PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[iL3sKTVC7EZgM9kDajU1FYGBqWrdc]
	ZrzxY0D21f9ACB65S = ZrzxY0D21f9ACB65S+'_NODIALOGS_'
	if C47G3hXaRMFLfOAEpV: dwS0voDrOHFbWN7TkJVRIfM(ZrzxY0D21f9ACB65S,C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,sxFw3Wz7DhVL)
	else:
		for C47G3hXaRMFLfOAEpV in range(1,II0HXSngDhlLOuNQ9Vi+1):
			dwS0voDrOHFbWN7TkJVRIfM(ZrzxY0D21f9ACB65S,str(C47G3hXaRMFLfOAEpV),PiD9gwCG7zxRHVKkaeldoUbZr,sxFw3Wz7DhVL)
		JXSlk8x495HmgiD[:] = sorted(JXSlk8x495HmgiD,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1].lower())
	return
def dwS0voDrOHFbWN7TkJVRIfM(m0Qu6qaroU,C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr=eHdDoxhJCEPMZFVa2fg,sxFw3Wz7DhVL=eHdDoxhJCEPMZFVa2fg):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	ZrzxY0D21f9ACB65S,j2TA4h0FekYb3a5B,UzF4sIShoZEgRjc7LK8w = F1T64yBoQa5b(m0Qu6qaroU)
	if not C47G3hXaRMFLfOAEpV: return
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
	Liao5DfByHKGuW = [eHdDoxhJCEPMZFVa2fg,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not PiD9gwCG7zxRHVKkaeldoUbZr:
		if not UzF4sIShoZEgRjc7LK8w:
			if   '_IPTV-LIVE_' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[1]
			elif '_IPTV-MOVIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[2]
			elif '_IPTV-SERIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[3]
			else: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[0]
		else:
			hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			iL3sKTVC7EZgM9kDajU1FYGBqWrdc = ZZhzstQTSCXRg('أختر البحث المناسب', hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ)
			if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==-1: return
			PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[iL3sKTVC7EZgM9kDajU1FYGBqWrdc]
	ef4gxwCU2PzmJsSYtbA5 = ZrzxY0D21f9ACB65S.lower()
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'SEARCH')
	pGiyauNHUVlRTnP = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','SEARCH',(PiD9gwCG7zxRHVKkaeldoUbZr,ef4gxwCU2PzmJsSYtbA5))
	if not pGiyauNHUVlRTnP:
		y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE = [],[]
		if not PiD9gwCG7zxRHVKkaeldoUbZr: GKXgtfTnhRzHe0ZkJVdQ5ouE2y = [1,2,3,4,5]
		else: GKXgtfTnhRzHe0ZkJVdQ5ouE2y = [Liao5DfByHKGuW.index(PiD9gwCG7zxRHVKkaeldoUbZr)]
		for eMVgaSfkty1AwQT6Obo in GKXgtfTnhRzHe0ZkJVdQ5ouE2y:
			vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo])
			if eMVgaSfkty1AwQT6Obo!=3:
				KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'dict',Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo])
				del KcogByxTmuNDInYwXALarEjUli7eOR['__COUNT__']
				del KcogByxTmuNDInYwXALarEjUli7eOR['__GROUPS__']
				del KcogByxTmuNDInYwXALarEjUli7eOR['__SEQUENCED_COLUMNS__']
				E2ELD9hkvJfmeOo075IS1 = list(KcogByxTmuNDInYwXALarEjUli7eOR.keys())
				for L5DdYNZBtexX29zGHgQVoCiEJ in E2ELD9hkvJfmeOo075IS1:
					for GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in KcogByxTmuNDInYwXALarEjUli7eOR[L5DdYNZBtexX29zGHgQVoCiEJ]:
						if ef4gxwCU2PzmJsSYtbA5 in hgE9MlmDou.lower(): Inuo5YDT9b14cqeZJdVWKt860jE.append((hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF))
					del KcogByxTmuNDInYwXALarEjUli7eOR[L5DdYNZBtexX29zGHgQVoCiEJ]
				del KcogByxTmuNDInYwXALarEjUli7eOR
			else: E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo],'__GROUPS__')
			for L5DdYNZBtexX29zGHgQVoCiEJ in E2ELD9hkvJfmeOo075IS1:
				try: L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF = L5DdYNZBtexX29zGHgQVoCiEJ
				except: Ufd6obSCcXF = eHdDoxhJCEPMZFVa2fg
				if ef4gxwCU2PzmJsSYtbA5 in L5DdYNZBtexX29zGHgQVoCiEJ.lower():
					if eMVgaSfkty1AwQT6Obo!=3: Tc3yt7NQUCfpqb9ueB2HrO = L5DdYNZBtexX29zGHgQVoCiEJ
					else:
						RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')
						if ef4gxwCU2PzmJsSYtbA5 in RqP1jLcQ0Z7pik.lower(): Tc3yt7NQUCfpqb9ueB2HrO = RqP1jLcQ0Z7pik
						else: Tc3yt7NQUCfpqb9ueB2HrO = XskPiv4uWLdOyohJZqgI6UC7
					y8aJjOzEMdX.append((L5DdYNZBtexX29zGHgQVoCiEJ,Tc3yt7NQUCfpqb9ueB2HrO,Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo],Ufd6obSCcXF))
			del E2ELD9hkvJfmeOo075IS1
		y8aJjOzEMdX = set(y8aJjOzEMdX)
		Inuo5YDT9b14cqeZJdVWKt860jE = set(Inuo5YDT9b14cqeZJdVWKt860jE)
		y8aJjOzEMdX = sorted(y8aJjOzEMdX,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1])
		Inuo5YDT9b14cqeZJdVWKt860jE = sorted(Inuo5YDT9b14cqeZJdVWKt860jE,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[0])
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'SEARCH',(PiD9gwCG7zxRHVKkaeldoUbZr,ef4gxwCU2PzmJsSYtbA5),(y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE),ICRfWub2vqlor0Q)
	else: y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE = pGiyauNHUVlRTnP
	E2ELD9hkvJfmeOo075IS1 = len(y8aJjOzEMdX)
	FFQP9MfNAi4IqcnvwZ = len(Inuo5YDT9b14cqeZJdVWKt860jE)
	d9c6BWV3J2bQDMRELgX = int(sxFw3Wz7DhVL)
	fH97sVgW5RJ6jxrChUqFz8Ymb = max(0,(d9c6BWV3J2bQDMRELgX-1)*100)
	NzgKbhHGdmEAZD = max(0,d9c6BWV3J2bQDMRELgX*100)
	Guk3tVX9l7wKJmy6c2bvS5N = max(0,fH97sVgW5RJ6jxrChUqFz8Ymb-E2ELD9hkvJfmeOo075IS1)
	rYsUwADyic2fTMZECmK = max(0,NzgKbhHGdmEAZD-E2ELD9hkvJfmeOo075IS1)
	for L5DdYNZBtexX29zGHgQVoCiEJ,Tc3yt7NQUCfpqb9ueB2HrO,PPNwoZhRrODFpXQVcKA,Ufd6obSCcXF in y8aJjOzEMdX[fH97sVgW5RJ6jxrChUqFz8Ymb:NzgKbhHGdmEAZD]:
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+Tc3yt7NQUCfpqb9ueB2HrO,PPNwoZhRrODFpXQVcKA,234,Ufd6obSCcXF,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	del y8aJjOzEMdX
	for hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in Inuo5YDT9b14cqeZJdVWKt860jE[Guk3tVX9l7wKJmy6c2bvS5N:rYsUwADyic2fTMZECmK]:
		GBxY7Qljt3nUmeNwyg = llr1C3SIFjViqLDtZP(Nn360bq79W2kzUt)
		IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'live'
		if '.mkv' in GBxY7Qljt3nUmeNwyg or 'VOD' in PiD9gwCG7zxRHVKkaeldoUbZr: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'video'
		qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,235,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	del Inuo5YDT9b14cqeZJdVWKt860jE
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,239,E2ELD9hkvJfmeOo075IS1+FFQP9MfNAi4IqcnvwZ,ZrzxY0D21f9ACB65S+'_NODIALOGS_')
	return
def dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,RVOyUD2s8Bk9FLCwu4MSKJgt,bkA4Xjzw7mJa):
	if sxFw3Wz7DhVL!='1': qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'صفحة '+str(1),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(1),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	if not RVOyUD2s8Bk9FLCwu4MSKJgt: RVOyUD2s8Bk9FLCwu4MSKJgt = 0
	aNbi0e4uvl6CrW8ZB7 = int(RVOyUD2s8Bk9FLCwu4MSKJgt/100)+1
	for d9c6BWV3J2bQDMRELgX in range(2,aNbi0e4uvl6CrW8ZB7):
		E2tAkO0pMVgD = (d9c6BWV3J2bQDMRELgX%10==0 or int(sxFw3Wz7DhVL)-4<d9c6BWV3J2bQDMRELgX<int(sxFw3Wz7DhVL)+4)
		res2HUZzg4opdqQai7KSGyctLBY0 = (E2tAkO0pMVgD and int(sxFw3Wz7DhVL)-40<d9c6BWV3J2bQDMRELgX<int(sxFw3Wz7DhVL)+40)
		if str(d9c6BWV3J2bQDMRELgX)!=sxFw3Wz7DhVL and (d9c6BWV3J2bQDMRELgX%100==0 or res2HUZzg4opdqQai7KSGyctLBY0):
			qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'صفحة '+str(d9c6BWV3J2bQDMRELgX),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(d9c6BWV3J2bQDMRELgX),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	if str(aNbi0e4uvl6CrW8ZB7)!=sxFw3Wz7DhVL: qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أخر صفحة '+str(aNbi0e4uvl6CrW8ZB7),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(aNbi0e4uvl6CrW8ZB7),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	return
def K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr):
	if 'SERIES' in PiD9gwCG7zxRHVKkaeldoUbZr or 'VOD_ORIGINAL' in PiD9gwCG7zxRHVKkaeldoUbZr: vXSV4tIkDzNC = lsZrOnAhvFNgoWXi7Czd2q8YpIDE
	else: vXSV4tIkDzNC = wAR4O5i9os3q
	vXSV4tIkDzNC = vXSV4tIkDzNC.replace('___','_'+C47G3hXaRMFLfOAEpV)
	return vXSV4tIkDzNC
def MSwPisjOZBz(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH):
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if not aKnyXZfMFDJViN1OtpLk: return
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	if   PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_LIVE_GROUPS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_live_categories'
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_VOD_GROUPS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_vod_categories'
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_SERIES_GROUPS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_series_categories'
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_LIVE_ITEMS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_live_streams&category_id='+lUXjebduy9AOMcg0rmQDkVH
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_VOD_ITEMS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_vod_streams&category_id='+lUXjebduy9AOMcg0rmQDkVH
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_SERIES_ITEMS': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_series&category_id='+lUXjebduy9AOMcg0rmQDkVH
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_EPISODES': Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action=get_series_info&series_id='+lUXjebduy9AOMcg0rmQDkVH
	else: return
	W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',Nn360bq79W2kzUt,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IPTV-XTREAM_MENUS-1st')
	yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
	if lHfbysRrUV7m4CLSdkxc382n: yu26R85ckHMoK3reLVwSd = yu26R85ckHMoK3reLVwSd.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
	nmBjlP5r9FUJua2f7sEhG1Lxc = DIpuHqsKGS3ErJvk9taCRiX80('list',yu26R85ckHMoK3reLVwSd)
	if 'GROUPS' in PiD9gwCG7zxRHVKkaeldoUbZr:
		PiD9gwCG7zxRHVKkaeldoUbZr = PiD9gwCG7zxRHVKkaeldoUbZr.replace('_GROUPS','_ITEMS')
		nmBjlP5r9FUJua2f7sEhG1Lxc = sorted(nmBjlP5r9FUJua2f7sEhG1Lxc,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU['category_name'].lower())
		for L5DdYNZBtexX29zGHgQVoCiEJ in nmBjlP5r9FUJua2f7sEhG1Lxc:
			ZzYmHLMSUBAN = L5DdYNZBtexX29zGHgQVoCiEJ['category_id']
			hgE9MlmDou = L5DdYNZBtexX29zGHgQVoCiEJ['category_name']
			qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,PiD9gwCG7zxRHVKkaeldoUbZr,285,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,str(ZzYmHLMSUBAN),eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_SERIES_ITEMS':
		nmBjlP5r9FUJua2f7sEhG1Lxc = sorted(nmBjlP5r9FUJua2f7sEhG1Lxc,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU['name'].lower())
		for LcGSPA8pmT7WNsXvyra6Zu3D5dRxO in nmBjlP5r9FUJua2f7sEhG1Lxc:
			hgE9MlmDou = LcGSPA8pmT7WNsXvyra6Zu3D5dRxO['name']
			Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV = LcGSPA8pmT7WNsXvyra6Zu3D5dRxO['cover']
			ZzYmHLMSUBAN = LcGSPA8pmT7WNsXvyra6Zu3D5dRxO['series_id']
			qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,'XTREAM_EPISODES',285,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,eHdDoxhJCEPMZFVa2fg,str(ZzYmHLMSUBAN),eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	elif PiD9gwCG7zxRHVKkaeldoUbZr=='XTREAM_EPISODES':
		Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV = nmBjlP5r9FUJua2f7sEhG1Lxc['info']['cover']
		Pe9ETSvwUGBnkC1hO = nmBjlP5r9FUJua2f7sEhG1Lxc['info']['name']
		s16ctVmr4ozl9GeQxH0 = nmBjlP5r9FUJua2f7sEhG1Lxc['episodes']
		for mfdYwCzjINJD in s16ctVmr4ozl9GeQxH0:
			YPOVFyQk2mC3wc654TIAhlJd = s16ctVmr4ozl9GeQxH0[mfdYwCzjINJD]
			for IkA8VLYrtGxXjhpzogun in YPOVFyQk2mC3wc654TIAhlJd:
				hgE9MlmDou = IkA8VLYrtGxXjhpzogun['title']
				nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1 = cBawilJXvK1m.findall('\d+.(S\d+E\d+)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
				if nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1: hgE9MlmDou = Pe9ETSvwUGBnkC1hO+avcfIls8w7gk69hYUErHxzQTXtm24j+nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1[0]
				ZzYmHLMSUBAN = IkA8VLYrtGxXjhpzogun['id']
				FFprnSYWVywKiUgQhslzva7T = IkA8VLYrtGxXjhpzogun['container_extension']
				Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM.split('/player_api.php')[0]+'/series/'+aKnyXZfMFDJViN1OtpLk+'/'+gojXxJqFmu6f+'/'+str(ZzYmHLMSUBAN)+'.'+FFprnSYWVywKiUgQhslzva7T
				qfpnsHw19BiaSktcXWbGA('video',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,235,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	elif 'ITEMS' in PiD9gwCG7zxRHVKkaeldoUbZr:
		IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'live' if 'LIVE' in PiD9gwCG7zxRHVKkaeldoUbZr else 'video'
		nmBjlP5r9FUJua2f7sEhG1Lxc = sorted(nmBjlP5r9FUJua2f7sEhG1Lxc,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU['name'].lower())
		for BK2rtHczOhLGdMnCYjsweJfq in nmBjlP5r9FUJua2f7sEhG1Lxc:
			hgE9MlmDou = BK2rtHczOhLGdMnCYjsweJfq['name']
			Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV = BK2rtHczOhLGdMnCYjsweJfq['stream_icon']
			ZzYmHLMSUBAN = BK2rtHczOhLGdMnCYjsweJfq['stream_id']
			try:
				FFprnSYWVywKiUgQhslzva7T = BK2rtHczOhLGdMnCYjsweJfq['container_extension']
				if FFprnSYWVywKiUgQhslzva7T: FFprnSYWVywKiUgQhslzva7T = '.'+FFprnSYWVywKiUgQhslzva7T
			except: FFprnSYWVywKiUgQhslzva7T = eHdDoxhJCEPMZFVa2fg
			if BK2rtHczOhLGdMnCYjsweJfq['stream_type']=='live': PcwEmo0dXj7vu8zypFefxDMr,wbVBXodaQk = eHdDoxhJCEPMZFVa2fg,'live'
			elif BK2rtHczOhLGdMnCYjsweJfq['stream_type']=='movie': PcwEmo0dXj7vu8zypFefxDMr,wbVBXodaQk = 'movie/','video'
			Nn360bq79W2kzUt = Z4qAYlatIBdvQ9HbkoK1ewSnM.split('/player_api.php')[0]+'/'+PcwEmo0dXj7vu8zypFefxDMr+aKnyXZfMFDJViN1OtpLk+'/'+gojXxJqFmu6f+'/'+str(ZzYmHLMSUBAN)+FFprnSYWVywKiUgQhslzva7T
			qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,235,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	return
def F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV):
	eyx7SQN1RLtvjIkHcd5m436rBKOb = MoO74hKeqm8fFka.getSetting('av.language.provider')
	QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
	k5L96NenKBwpSYWv(pyifuNFdxe,'MENUS_CACHE_'+eyx7SQN1RLtvjIkHcd5m436rBKOb+'_'+QRW3ABgXKOzL51VdTsP,'%_IP'+C47G3hXaRMFLfOAEpV+'_%')
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
EERWJf1adv67 = 'AKOAM'
r07r9xeEFASJXluImT = '_AKO_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
q0xiDuFhOQClpk = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==70: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==71: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = uzPkaSBtgeiCYwnbE8f(url)
	elif mode==72: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==73: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = kOMYI6sdwxRZVlbt(url)
	elif mode==74: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==79: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,79,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'سلسلة افلام',eHdDoxhJCEPMZFVa2fg,79,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'سلسلة افلام')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'سلاسل منوعة',eHdDoxhJCEPMZFVa2fg,79,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'سلسلة')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	IVD2kBKhW8FeQLvxUm = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'AKOAM-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="partions"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title not in IVD2kBKhW8FeQLvxUm:
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,71)
	return nR2B1Wye7luXb5
def uzPkaSBtgeiCYwnbE8f(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'AKOAM-CATEGORIES-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('sect_parts(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,72)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'جميع الفروع',url,72)
	else: zRK9ruIt0ZFV4bgi(url,eHdDoxhJCEPMZFVa2fg)
	return
def zRK9ruIt0ZFV4bgi(url,type):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('section_title featured_title(.*?)subjects-crousel',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='search':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('akoam_result(.*?)<script',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='more':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('section_title more_title(.*?)footer_bottom_services',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('navigation(.*?)<script',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not items and RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		title = zJRbA1YW2Eor(title)
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in q0xiDuFhOQClpk): qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,73,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,73,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall("</li><li >.*?href='(.*?)'>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,72,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def Odr7u1nS4VZvKX(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKOAM-SECTIONS-2nd')
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('"href","(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[1]
	return E1Viom5L3684CTOFJ
def kOMYI6sdwxRZVlbt(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKOAM-SECTIONS-1st')
	bJxzHh6rWo = cBawilJXvK1m.findall('"(https*://akwam.net/\w+.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	do5Ol4i6B0tbegzAYcs = cBawilJXvK1m.findall('"(https*://underurl.com/\w+.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if bJxzHh6rWo or do5Ol4i6B0tbegzAYcs:
		if bJxzHh6rWo: ajHR9ABQl2buvm = bJxzHh6rWo[0]
		elif do5Ol4i6B0tbegzAYcs: ajHR9ABQl2buvm = Odr7u1nS4VZvKX(do5Ol4i6B0tbegzAYcs[0])
		ajHR9ABQl2buvm = zrHeZWCqQMOymk1d7anKpu0vEx8(ajHR9ABQl2buvm)
		import CUTcRwrWs9
		if '/series/' in ajHR9ABQl2buvm or '/shows/' in ajHR9ABQl2buvm: CUTcRwrWs9.tcJeirkgjMal25ofbE8zF4nxmOBw(ajHR9ABQl2buvm)
		else: CUTcRwrWs9.bbmQeYGSTIv(ajHR9ABQl2buvm)
		return
	i2qmOCHN5goZ = cBawilJXvK1m.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	items = cBawilJXvK1m.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		title = zJRbA1YW2Eor(title)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,73)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		dqKGMYgJxSF8Ub1kotlsP936Ww7B('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,PeLqCN5Ek8bB,cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	if 'sub_epsiode_title' in cOUiow273ytu1GC5N0FJh:
		items = cBawilJXvK1m.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	else:
		HHPmU5KxDISd6RskypurNX2M = cBawilJXvK1m.findall('sub_file_title\'>(.*?) - <i>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		items = []
		for filename in HHPmU5KxDISd6RskypurNX2M:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',eHdDoxhJCEPMZFVa2fg) ]
	count = 0
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,tzH0qiIug5bhjCMyUKasLrNoG = [],[]
	size = len(items)
	for title,filename in items:
		N63IHpMe8P = eHdDoxhJCEPMZFVa2fg
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: N63IHpMe8P = filename.split('.')[-1]
		title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
		tzH0qiIug5bhjCMyUKasLrNoG.append(count)
		count += 1
	if size>0:
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in name for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in q0xiDuFhOQClpk):
			if size==1:
				iLcCSnPyKYWs3xkQ0p14 = 0
			else:
				iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('اختر الفيديو المناسب:', FBITEXGDfe2mcCxnQs6ktMdy9HJh)
				if iLcCSnPyKYWs3xkQ0p14 == -1: return
			bbmQeYGSTIv(url+'?section='+str(1+tzH0qiIug5bhjCMyUKasLrNoG[size-iLcCSnPyKYWs3xkQ0p14-1]))
		else:
			for dhcGSyo8Kn1mHZwvEAkzJ7NUq in reversed(range(size)):
				title = name + ' - ' + FBITEXGDfe2mcCxnQs6ktMdy9HJh[dhcGSyo8Kn1mHZwvEAkzJ7NUq]
				title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				apOKrFbP9IYHDyUVm7 = url + '?section='+str(size-dhcGSyo8Kn1mHZwvEAkzJ7NUq)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,74,PeLqCN5Ek8bB)
	else:
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+'الرابط ليس فيديو',eHdDoxhJCEPMZFVa2fg,9999,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	E1Viom5L3684CTOFJ,vQ2LDF3UyXZbhu97Y = url.split('?section=')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,True,eHdDoxhJCEPMZFVa2fg,'AKOAM-PLAY_AKOAM-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	IUQajudylJeN6TDVB1bnXqc = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	IUQajudylJeN6TDVB1bnXqc = IUQajudylJeN6TDVB1bnXqc + 'direct_link_box'
	ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall('epsoide_box(.*?)direct_link_box',IUQajudylJeN6TDVB1bnXqc,cBawilJXvK1m.DOTALL)
	vQ2LDF3UyXZbhu97Y = len(ekNMoIJzswUSDVQf564)-int(vQ2LDF3UyXZbhu97Y)
	cOUiow273ytu1GC5N0FJh = ekNMoIJzswUSDVQf564[vQ2LDF3UyXZbhu97Y]
	wROf6m4Ix73jtsdnZ1vpCDuV = []
	VszlmkYA2gJ1Wvop7 = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = cBawilJXvK1m.findall("class='download_btn.*?href='(.*?)'",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7 in items:
		wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named=________akoam')
	items = cBawilJXvK1m.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for VgCmi03FWtOd85ZDka,apOKrFbP9IYHDyUVm7 in items:
		VgCmi03FWtOd85ZDka = VgCmi03FWtOd85ZDka.split('/')[-1]
		VgCmi03FWtOd85ZDka = VgCmi03FWtOd85ZDka.split('.')[0]
		if VgCmi03FWtOd85ZDka in VszlmkYA2gJ1Wvop7:
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+VszlmkYA2gJ1Wvop7[VgCmi03FWtOd85ZDka]+'________akoam')
		else: wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+VgCmi03FWtOd85ZDka+'________akoam')
	if not wROf6m4Ix73jtsdnZ1vpCDuV:
		message = cBawilJXvK1m.findall('sub-no-file.*?\n(.*?)\n',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if message: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من الموقع الاصلي',message[0])
	else:
		import SOnwRtkA74
		SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	url = q3QVhZaDEuo8t2ASj5vkn + '/search/'+diojk6J5vzuRNDKmw
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,'search')
	return
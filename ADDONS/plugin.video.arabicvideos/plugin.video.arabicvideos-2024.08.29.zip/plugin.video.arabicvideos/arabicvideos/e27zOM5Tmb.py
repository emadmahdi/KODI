# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'YOUTUBE'
r07r9xeEFASJXluImT = '_YUT_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
xPwdjCnOGNQz7fZhlY3 = 0
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text,type,clAzmREWwXf6Gk,name,e3XtKs70ifmRQY8VTLnpMdyr6):
	if	 mode==140: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==141: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = QG3qJCajSpom1RBbcf9KOy(url,name,e3XtKs70ifmRQY8VTLnpMdyr6)
	elif mode==143: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url,type)
	elif mode==144: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk,text)
	elif mode==145: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = HGZCvr0u53x(url,clAzmREWwXf6Gk)
	elif mode==147: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ONDWKQVR7qwFBr4()
	elif mode==148: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGD8lw0JKPjNROXqa7ox9Z4i()
	elif mode==149: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	if 0:
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'قائمة',q3QVhZaDEuo8t2ASj5vkn+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'شخص',q3QVhZaDEuo8t2ASj5vkn+'/user/TCNofficial',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'موقع',q3QVhZaDEuo8t2ASj5vkn+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'حساب',q3QVhZaDEuo8t2ASj5vkn+'/@TheSocialCTV',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'العاب',q3QVhZaDEuo8t2ASj5vkn+'/gaming',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'افلام',q3QVhZaDEuo8t2ASj5vkn+'/feed/storefront',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مختارات',q3QVhZaDEuo8t2ASj5vkn+'/feed/guide_builder',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'قصيرة',q3QVhZaDEuo8t2ASj5vkn+'/shorts',144,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'تصفح',q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/guide?key=',144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'رئيسية',q3QVhZaDEuo8t2ASj5vkn+eHdDoxhJCEPMZFVa2fg,144)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'رائج',q3QVhZaDEuo8t2ASj5vkn+'/feed/trending?bp=',144)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,149,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الرائجة',q3QVhZaDEuo8t2ASj5vkn+'/feed/trending',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'التصفح',q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/guide?key=',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'القصيرة',q3QVhZaDEuo8t2ASj5vkn+'/shorts',144,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مختارات يوتيوب',q3QVhZaDEuo8t2ASj5vkn+'/feed/guide_builder',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مختارات البرنامج',eHdDoxhJCEPMZFVa2fg,290)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: قنوات عربية',eHdDoxhJCEPMZFVa2fg,147)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: قنوات أجنبية',eHdDoxhJCEPMZFVa2fg,148)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: افلام عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=فيلم',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: افلام اجنبية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=movie',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: مسرحيات عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=مسرحية',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: مسلسلات عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: مسلسلات اجنبية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=series&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: مسلسلات كارتون',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=كارتون&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث: خطبة المرجعية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def QG3qJCajSpom1RBbcf9KOy(url,name,e3XtKs70ifmRQY8VTLnpMdyr6):
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'CHNL:  '+name,url,144,e3XtKs70ifmRQY8VTLnpMdyr6)
	return
def ONDWKQVR7qwFBr4():
	zRK9ruIt0ZFV4bgi(q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def EGD8lw0JKPjNROXqa7ox9Z4i():
	zRK9ruIt0ZFV4bgi(q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=tv&sp=EgJAAQ==')
	return
def bbmQeYGSTIv(url,type):
	url = url.split('&',1)[0]
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([url],EERWJf1adv67,type,url)
	return
def ze8HZYB73kEDUP(kq4ESlfZtHyY,url,WmUKzewgdt7nOa3VlBC19):
	level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = WmUKzewgdt7nOa3VlBC19.split('::')
	eZlo7XvRDyM,kISTn9ZbMWvxC5qD7o = [],[]
	if '/youtubei/v1/browse' in url: eZlo7XvRDyM.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: eZlo7XvRDyM.append("yccc['onResponseReceivedCommands']")
	eZlo7XvRDyM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': eZlo7XvRDyM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	eZlo7XvRDyM.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	eZlo7XvRDyM.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	eZlo7XvRDyM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	eZlo7XvRDyM.append("yccc['entries']")
	eZlo7XvRDyM.append("yccc['items'][3]['guideSectionRenderer']['items']")
	KK09m4EyQspDhblYA1WHti,k3SXbnyUvQzugpLrDemhjH6GC9Pc8,dEb9eODpPcmVGIFWvS = uSsx1vNJaWDI(kq4ESlfZtHyY,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
	if level=='1' and KK09m4EyQspDhblYA1WHti:
		if len(k3SXbnyUvQzugpLrDemhjH6GC9Pc8)>1 and 'search_query' not in url:
			for eWof5aHlLJXkKID28phNGQqZrR in range(len(k3SXbnyUvQzugpLrDemhjH6GC9Pc8)):
				bd1QTzoVurHBm2Uxe = str(eWof5aHlLJXkKID28phNGQqZrR)
				eZlo7XvRDyM = []
				eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['reloadContinuationItemsCommand']['continuationItems']")
				eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['command']")
				eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]")
				gZdOM2jYEfV,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(k3SXbnyUvQzugpLrDemhjH6GC9Pc8,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
				if gZdOM2jYEfV: kISTn9ZbMWvxC5qD7o.append([AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,'2::'+bd1QTzoVurHBm2Uxe+'::0::0'])
			eZlo7XvRDyM.append("yccc['continuationEndpoint']")
			gZdOM2jYEfV,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(kq4ESlfZtHyY,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
			if gZdOM2jYEfV and kISTn9ZbMWvxC5qD7o and 'continuationCommand' in list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys()):
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/my_main_page_shorts_link'
				kISTn9ZbMWvxC5qD7o.append([AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,apOKrFbP9IYHDyUVm7,'1::0::0::0'])
	return k3SXbnyUvQzugpLrDemhjH6GC9Pc8,KK09m4EyQspDhblYA1WHti,kISTn9ZbMWvxC5qD7o,dEb9eODpPcmVGIFWvS
def pD4JxqjvG3oWb(kq4ESlfZtHyY,k3SXbnyUvQzugpLrDemhjH6GC9Pc8,url,WmUKzewgdt7nOa3VlBC19):
	level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = WmUKzewgdt7nOa3VlBC19.split('::')
	eZlo7XvRDyM,VcPrCzGAh4RDbI9 = [],[]
	eZlo7XvRDyM.append("yddd[0]['itemSectionRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['reloadContinuationItemsCommand']['continuationItems']")
	eZlo7XvRDyM.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: eZlo7XvRDyM.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: eZlo7XvRDyM.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	eZlo7XvRDyM.append("yddd["+bd1QTzoVurHBm2Uxe+"]")
	Lw25olDHduEK,JJ4YgvGIX5e1M62Wtyz,glwT5zmdZUBb9yf0I = uSsx1vNJaWDI(k3SXbnyUvQzugpLrDemhjH6GC9Pc8,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
	if level=='2' and Lw25olDHduEK:
		if len(JJ4YgvGIX5e1M62Wtyz)>1:
			for eWof5aHlLJXkKID28phNGQqZrR in range(len(JJ4YgvGIX5e1M62Wtyz)):
				qXbQg1fweajEnp835cvur6JstHdVMo = str(eWof5aHlLJXkKID28phNGQqZrR)
				eZlo7XvRDyM = []
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['richSectionRenderer']['content']")
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]")
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['richItemRenderer']['content']")
				eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]")
				gZdOM2jYEfV,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(JJ4YgvGIX5e1M62Wtyz,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
				if gZdOM2jYEfV: VcPrCzGAh4RDbI9.append([AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,'3::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::0'])
			eZlo7XvRDyM.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			eZlo7XvRDyM.append("yddd[1]")
			gZdOM2jYEfV,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(k3SXbnyUvQzugpLrDemhjH6GC9Pc8,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
			if gZdOM2jYEfV and VcPrCzGAh4RDbI9 and 'continuationItemRenderer' in list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys()):
				VcPrCzGAh4RDbI9.append([AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,'3::0::0::0'])
	return JJ4YgvGIX5e1M62Wtyz,Lw25olDHduEK,VcPrCzGAh4RDbI9,glwT5zmdZUBb9yf0I
def wPOk70zq8c14sb3RCfU5iHa6KVBN(kq4ESlfZtHyY,JJ4YgvGIX5e1M62Wtyz,url,WmUKzewgdt7nOa3VlBC19):
	level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = WmUKzewgdt7nOa3VlBC19.split('::')
	eZlo7XvRDyM,rrbwNElpS7vc20LHUkJoOF = [],[]
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	eZlo7XvRDyM.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	eZlo7XvRDyM.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	eZlo7XvRDyM.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['reelShelfRenderer']['items']")
	eZlo7XvRDyM.append("yeee["+qXbQg1fweajEnp835cvur6JstHdVMo+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	eZlo7XvRDyM.append("yeee")
	TTPDxHazUmJ8YXkhnWpOFGe,zze3wFDC8mYVuTlIv5rx79,SZ3z4NjowUKAREFlvf = uSsx1vNJaWDI(JJ4YgvGIX5e1M62Wtyz,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
	if level=='3' and TTPDxHazUmJ8YXkhnWpOFGe:
		if len(zze3wFDC8mYVuTlIv5rx79)>0:
			for eWof5aHlLJXkKID28phNGQqZrR in range(len(zze3wFDC8mYVuTlIv5rx79)):
				VxuziIhdo8F = str(eWof5aHlLJXkKID28phNGQqZrR)
				eZlo7XvRDyM = []
				eZlo7XvRDyM.append("yfff["+VxuziIhdo8F+"]['richItemRenderer']['content']")
				eZlo7XvRDyM.append("yfff["+VxuziIhdo8F+"]['gameCardRenderer']['game']")
				eZlo7XvRDyM.append("yfff["+VxuziIhdo8F+"]['itemSectionRenderer']['contents'][0]")
				eZlo7XvRDyM.append("yfff["+VxuziIhdo8F+"]")
				gZdOM2jYEfV,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(zze3wFDC8mYVuTlIv5rx79,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
				if gZdOM2jYEfV: rrbwNElpS7vc20LHUkJoOF.append([AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,'4::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F])
	return zze3wFDC8mYVuTlIv5rx79,TTPDxHazUmJ8YXkhnWpOFGe,rrbwNElpS7vc20LHUkJoOF,SZ3z4NjowUKAREFlvf
def uSsx1vNJaWDI(DDY4vSW3UQ,pxVBnJRzq0,YyzjRvC5SAwh):
	kq4ESlfZtHyY,pxVBnJRzq0 = DDY4vSW3UQ,pxVBnJRzq0
	k3SXbnyUvQzugpLrDemhjH6GC9Pc8,pxVBnJRzq0 = DDY4vSW3UQ,pxVBnJRzq0
	JJ4YgvGIX5e1M62Wtyz,pxVBnJRzq0 = DDY4vSW3UQ,pxVBnJRzq0
	zze3wFDC8mYVuTlIv5rx79,pxVBnJRzq0 = DDY4vSW3UQ,pxVBnJRzq0
	AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b = DDY4vSW3UQ,pxVBnJRzq0
	count = len(YyzjRvC5SAwh)
	for gMmB3iopS0ZXrOFewhcxt in range(count):
		try:
			iQGPlFW0h1kJ5En4 = eval(YyzjRvC5SAwh[gMmB3iopS0ZXrOFewhcxt])
			return True,iQGPlFW0h1kJ5En4,gMmB3iopS0ZXrOFewhcxt+1
		except: pass
	return False,eHdDoxhJCEPMZFVa2fg,0
def zRK9ruIt0ZFV4bgi(url,WmUKzewgdt7nOa3VlBC19=eHdDoxhJCEPMZFVa2fg,data=eHdDoxhJCEPMZFVa2fg):
	kISTn9ZbMWvxC5qD7o,VcPrCzGAh4RDbI9,rrbwNElpS7vc20LHUkJoOF = [],[],[]
	if '::' not in WmUKzewgdt7nOa3VlBC19: WmUKzewgdt7nOa3VlBC19 = '1::0::0::0'
	level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = WmUKzewgdt7nOa3VlBC19.split('::')
	if level=='4': level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = '1',bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F
	data = data.replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	nR2B1Wye7luXb5,kq4ESlfZtHyY,LbAmEhrdt7eRV2Y = DgtIMC6QPGenbFWNa3X(url,data)
	WmUKzewgdt7nOa3VlBC19 = level+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
	if level in ['1','2','3']:
		k3SXbnyUvQzugpLrDemhjH6GC9Pc8,KK09m4EyQspDhblYA1WHti,kISTn9ZbMWvxC5qD7o,dEb9eODpPcmVGIFWvS = ze8HZYB73kEDUP(kq4ESlfZtHyY,url,WmUKzewgdt7nOa3VlBC19)
		if not KK09m4EyQspDhblYA1WHti: return
		zS2kMh0dq5wmy7BAxIcHXpioP = len(kISTn9ZbMWvxC5qD7o)
		if zS2kMh0dq5wmy7BAxIcHXpioP<2:
			if level=='1': level = '2'
			kISTn9ZbMWvxC5qD7o = []
	WmUKzewgdt7nOa3VlBC19 = level+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
	if level in ['2','3']:
		JJ4YgvGIX5e1M62Wtyz,Lw25olDHduEK,VcPrCzGAh4RDbI9,glwT5zmdZUBb9yf0I = pD4JxqjvG3oWb(kq4ESlfZtHyY,k3SXbnyUvQzugpLrDemhjH6GC9Pc8,url,WmUKzewgdt7nOa3VlBC19)
		if not Lw25olDHduEK: return
		b8E9XywiKlAMCqsUYhDcGVJfg = len(VcPrCzGAh4RDbI9)
		if b8E9XywiKlAMCqsUYhDcGVJfg<2:
			if level=='2': level = '3'
			VcPrCzGAh4RDbI9 = []
	WmUKzewgdt7nOa3VlBC19 = level+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
	if level in ['3']:
		zze3wFDC8mYVuTlIv5rx79,TTPDxHazUmJ8YXkhnWpOFGe,rrbwNElpS7vc20LHUkJoOF,SZ3z4NjowUKAREFlvf = wPOk70zq8c14sb3RCfU5iHa6KVBN(kq4ESlfZtHyY,JJ4YgvGIX5e1M62Wtyz,url,WmUKzewgdt7nOa3VlBC19)
		if not TTPDxHazUmJ8YXkhnWpOFGe: return
		QGhtNm0u5Ro4wbaElHCBI = len(rrbwNElpS7vc20LHUkJoOF)
	for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,WmUKzewgdt7nOa3VlBC19 in kISTn9ZbMWvxC5qD7o+VcPrCzGAh4RDbI9+rrbwNElpS7vc20LHUkJoOF:
		dlu49cgYnN7fW2OaKzJsiSX8Qw = V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,WmUKzewgdt7nOa3VlBC19)
	return
def V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url=eHdDoxhJCEPMZFVa2fg,WmUKzewgdt7nOa3VlBC19=eHdDoxhJCEPMZFVa2fg):
	if '::' in WmUKzewgdt7nOa3VlBC19: level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = WmUKzewgdt7nOa3VlBC19.split('::')
	else: level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = '1','0','0','0'
	gZdOM2jYEfV,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN,ggdZY2fOCPUI = NNXIxBVDljT57043mSfRbrYzdEH(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ)
	ZEihvxcN7XBjIrT4YytVmFgP1 = '/videos?' in apOKrFbP9IYHDyUVm7 or '/streams?' in apOKrFbP9IYHDyUVm7 or '/playlists?' in apOKrFbP9IYHDyUVm7
	HHVLQX4TlGu9m = '/channels?' in apOKrFbP9IYHDyUVm7 or '/shorts?' in apOKrFbP9IYHDyUVm7
	if ZEihvxcN7XBjIrT4YytVmFgP1 or HHVLQX4TlGu9m: apOKrFbP9IYHDyUVm7 = url
	ZEihvxcN7XBjIrT4YytVmFgP1 = 'watch?v=' not in apOKrFbP9IYHDyUVm7 and '/playlist?list=' not in apOKrFbP9IYHDyUVm7
	HHVLQX4TlGu9m = '/gaming' not in apOKrFbP9IYHDyUVm7  and '/feed/storefront' not in apOKrFbP9IYHDyUVm7
	if WmUKzewgdt7nOa3VlBC19[0:5]=='3::0::' and ZEihvxcN7XBjIrT4YytVmFgP1 and HHVLQX4TlGu9m: apOKrFbP9IYHDyUVm7 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in apOKrFbP9IYHDyUVm7:
		level,bd1QTzoVurHBm2Uxe,qXbQg1fweajEnp835cvur6JstHdVMo,VxuziIhdo8F = '1','0','0','0'
		WmUKzewgdt7nOa3VlBC19 = eHdDoxhJCEPMZFVa2fg
	LbAmEhrdt7eRV2Y = eHdDoxhJCEPMZFVa2fg
	if '/youtubei/v1/browse' in apOKrFbP9IYHDyUVm7 or '/youtubei/v1/search' in apOKrFbP9IYHDyUVm7 or '/my_main_page_shorts_link' in url:
		data = MoO74hKeqm8fFka.getSetting('av.youtube.data')
		if data.count(':::')==4:
			wc4ZxY9y65vfQLoNWK0hC,key,KourIHz3U7i,BNlxAUgK0Rjp1X,L6GuZYmNyAEUBi1sQ = data.split(':::')
			LbAmEhrdt7eRV2Y = wc4ZxY9y65vfQLoNWK0hC+':::'+key+':::'+KourIHz3U7i+':::'+BNlxAUgK0Rjp1X+':::'+ggdZY2fOCPUI
			if '/my_main_page_shorts_link' in url and not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = url
			else: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?key='+key
	if not title:
		global xPwdjCnOGNQz7fZhlY3
		xPwdjCnOGNQz7fZhlY3 += 1
		title = 'فيديوهات '+str(xPwdjCnOGNQz7fZhlY3)
		WmUKzewgdt7nOa3VlBC19 = '3'+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
	if not gZdOM2jYEfV: return False
	elif 'searchPyvRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ): return False
	elif '/about' in apOKrFbP9IYHDyUVm7: return False
	elif '/community' in apOKrFbP9IYHDyUVm7: return False
	elif 'continuationItemRenderer' in list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys()) or 'continuationCommand' in list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys()):
		if int(level)>1: level = str(int(level)-1)
		WmUKzewgdt7nOa3VlBC19 = level+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: '+'صفحة أخرى',apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19,LbAmEhrdt7eRV2Y)
	elif '/search' in apOKrFbP9IYHDyUVm7:
		title = ':: '+title
		WmUKzewgdt7nOa3VlBC19 = '3'+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
		url = url.replace('/search',eHdDoxhJCEPMZFVa2fg)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,145,eHdDoxhJCEPMZFVa2fg,WmUKzewgdt7nOa3VlBC19,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not apOKrFbP9IYHDyUVm7:
		WmUKzewgdt7nOa3VlBC19 = '3'+'::'+bd1QTzoVurHBm2Uxe+'::'+qXbQg1fweajEnp835cvur6JstHdVMo+'::'+VxuziIhdo8F
		title = ':: '+title
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19,LbAmEhrdt7eRV2Y)
	elif '/browse' in apOKrFbP9IYHDyUVm7 and url==q3QVhZaDEuo8t2ASj5vkn:
		title = ':: '+title
		WmUKzewgdt7nOa3VlBC19 = '2::0::0::0'
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19,LbAmEhrdt7eRV2Y)
	elif not apOKrFbP9IYHDyUVm7 and 'horizontalMovieListRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ):
		title = ':: '+title
		WmUKzewgdt7nOa3VlBC19 = '3::0::0::0'
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19)
	elif 'messageRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ):
		qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,9999)
	elif r0EKZGtfBUdOvqnSNhFA:
		qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+r0EKZGtfBUdOvqnSNhFA+title,apOKrFbP9IYHDyUVm7,143,PeLqCN5Ek8bB)
	elif '/playlist?list=' in apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('&playnext=1',eHdDoxhJCEPMZFVa2fg)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'LIST'+count+':  '+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19)
	elif '/shorts/' in apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&list=',1)[0]
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,143,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
	elif '/watch?v=' in apOKrFbP9IYHDyUVm7:
		if '&list=' in apOKrFbP9IYHDyUVm7 and count:
			WWlySEYmJPD87p3sUBLtaF2ozAdji = apOKrFbP9IYHDyUVm7.split('&list=',1)[1]
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/playlist?list='+WWlySEYmJPD87p3sUBLtaF2ozAdji
			WmUKzewgdt7nOa3VlBC19 = '3::0::0::0'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'LIST'+count+':  '+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19)
		else:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&list=',1)[0]
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,143,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
	elif '/channel/' in apOKrFbP9IYHDyUVm7 or '/c/' in apOKrFbP9IYHDyUVm7 or ('/@' in apOKrFbP9IYHDyUVm7 and apOKrFbP9IYHDyUVm7.count('/')==3):
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.decode(m6PFtLblInpNZ8x).encode('raw_unicode_escape')
			title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'CHNL'+count+':  '+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19)
	elif '/user/' in apOKrFbP9IYHDyUVm7:
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'USER'+count+':  '+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19)
	else:
		if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = url
		title = ':: '+title
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,WmUKzewgdt7nOa3VlBC19,LbAmEhrdt7eRV2Y)
	return True
def NNXIxBVDljT57043mSfRbrYzdEH(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ):
	gZdOM2jYEfV,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN,L6GuZYmNyAEUBi1sQ = False,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if not isinstance(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,dict): return gZdOM2jYEfV,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN,L6GuZYmNyAEUBi1sQ
	for svA7DYyJKC in list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys()):
		ALjRnHYOeE6U12b = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ[svA7DYyJKC]
		if isinstance(ALjRnHYOeE6U12b,dict): break
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	eZlo7XvRDyM.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	eZlo7XvRDyM.append("yrender['header']['richListHeaderRenderer']['title']")
	eZlo7XvRDyM.append("yrender['headline']['simpleText']")
	eZlo7XvRDyM.append("yrender['unplayableText']['simpleText']")
	eZlo7XvRDyM.append("yrender['formattedTitle']['simpleText']")
	eZlo7XvRDyM.append("yrender['title']['simpleText']")
	eZlo7XvRDyM.append("yrender['title']['runs'][0]['text']")
	eZlo7XvRDyM.append("yrender['text']['simpleText']")
	eZlo7XvRDyM.append("yrender['text']['runs'][0]['text']")
	eZlo7XvRDyM.append("yrender['title']")
	eZlo7XvRDyM.append("item['title']")
	eZlo7XvRDyM.append("item['reelWatchEndpoint']['videoId']")
	gZdOM2jYEfV,title,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	eZlo7XvRDyM.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	eZlo7XvRDyM.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("item['commandMetadata']['webCommandMetadata']['url']")
	gZdOM2jYEfV,apOKrFbP9IYHDyUVm7,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['thumbnail']['thumbnails'][0]['url']")
	eZlo7XvRDyM.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	eZlo7XvRDyM.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	gZdOM2jYEfV,PeLqCN5Ek8bB,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['videoCount']")
	eZlo7XvRDyM.append("yrender['videoCountText']['runs'][0]['text']")
	eZlo7XvRDyM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	gZdOM2jYEfV,count,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	eZlo7XvRDyM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	eZlo7XvRDyM.append("yrender['lengthText']['simpleText']")
	eZlo7XvRDyM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	eZlo7XvRDyM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	gZdOM2jYEfV,WWPgm9fvlH2oIOnrD1,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	eZlo7XvRDyM.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	gZdOM2jYEfV,L6GuZYmNyAEUBi1sQ,VVhKsWQ0jvAS = uSsx1vNJaWDI(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,ALjRnHYOeE6U12b,eZlo7XvRDyM)
	if 'LIVE' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA = eHdDoxhJCEPMZFVa2fg,'LIVE:  '
	if 'مباشر' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA = eHdDoxhJCEPMZFVa2fg,'LIVE:  '
	if 'badges' in list(ALjRnHYOeE6U12b.keys()):
		zECDMijlvbRWQh32 = str(ALjRnHYOeE6U12b['badges'])
		if 'Free with Ads' in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$:  '
		if 'LIVE' in zECDMijlvbRWQh32: r0EKZGtfBUdOvqnSNhFA = 'LIVE:  '
		if 'Buy' in zECDMijlvbRWQh32 or 'Rent' in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:  '
		if ZJPiId12qkesLNTvQW9H(u'مباشر') in zECDMijlvbRWQh32: r0EKZGtfBUdOvqnSNhFA = 'LIVE:  '
		if ZJPiId12qkesLNTvQW9H(u'شراء') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:  '
		if ZJPiId12qkesLNTvQW9H(u'استئجار') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:  '
		if ZJPiId12qkesLNTvQW9H(u'إعلانات') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$:  '
	apOKrFbP9IYHDyUVm7 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(apOKrFbP9IYHDyUVm7)
	if apOKrFbP9IYHDyUVm7 and 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
	PeLqCN5Ek8bB = PeLqCN5Ek8bB.split('?')[0]
	if  PeLqCN5Ek8bB and 'http' not in PeLqCN5Ek8bB: PeLqCN5Ek8bB = 'https:'+PeLqCN5Ek8bB
	title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
	if HAaeWXKhS7uLMFBxk4PzN: title = HAaeWXKhS7uLMFBxk4PzN+title
	WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace(',',eHdDoxhJCEPMZFVa2fg)
	count = count.replace(',',eHdDoxhJCEPMZFVa2fg)
	count = cBawilJXvK1m.findall('\d+',count)
	if count: count = count[0]
	else: count = eHdDoxhJCEPMZFVa2fg
	return True,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN,L6GuZYmNyAEUBi1sQ
def DgtIMC6QPGenbFWNa3X(url,data=eHdDoxhJCEPMZFVa2fg,mzfT1LoKkCy7g9wuSqV=eHdDoxhJCEPMZFVa2fg):
	if mzfT1LoKkCy7g9wuSqV==eHdDoxhJCEPMZFVa2fg: mzfT1LoKkCy7g9wuSqV = 'ytInitialData'
	PPOaXI9Tr1fAD7luhFGYpKJ5q = qq62QA8h3pGxzCwWVeXIF7glKf()
	W9PzsMeLJTc83mS45G17n = {'User-Agent':PPOaXI9Tr1fAD7luhFGYpKJ5q,'Cookie':'PREF=hl=ar'}
	global MoO74hKeqm8fFka
	if not data: data = MoO74hKeqm8fFka.getSetting('av.youtube.data')
	if data.count(':::')==4: wc4ZxY9y65vfQLoNWK0hC,key,KourIHz3U7i,BNlxAUgK0Rjp1X,L6GuZYmNyAEUBi1sQ = data.split(':::')
	else: wc4ZxY9y65vfQLoNWK0hC,key,KourIHz3U7i,BNlxAUgK0Rjp1X,L6GuZYmNyAEUBi1sQ = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	LbAmEhrdt7eRV2Y = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":KourIHz3U7i}}}
	if url==q3QVhZaDEuo8t2ASj5vkn+'/shorts' or '/my_main_page_shorts_link' in url:
		url = q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		LbAmEhrdt7eRV2Y['sequenceParams'] = wc4ZxY9y65vfQLoNWK0hC
		LbAmEhrdt7eRV2Y = str(LbAmEhrdt7eRV2Y)
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',url,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/guide?key='+key
		LbAmEhrdt7eRV2Y = str(LbAmEhrdt7eRV2Y)
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',url,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and wc4ZxY9y65vfQLoNWK0hC:
		LbAmEhrdt7eRV2Y['continuation'] = L6GuZYmNyAEUBi1sQ
		LbAmEhrdt7eRV2Y['context']['client']['visitorData'] = wc4ZxY9y65vfQLoNWK0hC
		LbAmEhrdt7eRV2Y = str(LbAmEhrdt7eRV2Y)
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',url,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and BNlxAUgK0Rjp1X:
		W9PzsMeLJTc83mS45G17n.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':KourIHz3U7i})
		W9PzsMeLJTc83mS45G17n.update({'Cookie':'VISITOR_INFO1_LIVE='+BNlxAUgK0Rjp1X})
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'YOUTUBE-GET_PAGE_DATA-6th')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('"innertubeApiKey".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if hPYnfjbqWDJNSAeyQaBrOZt68: key = hPYnfjbqWDJNSAeyQaBrOZt68[0]
	hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('"cver".*?"value".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if hPYnfjbqWDJNSAeyQaBrOZt68: KourIHz3U7i = hPYnfjbqWDJNSAeyQaBrOZt68[0]
	hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('"visitorData".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if hPYnfjbqWDJNSAeyQaBrOZt68: wc4ZxY9y65vfQLoNWK0hC = hPYnfjbqWDJNSAeyQaBrOZt68[0]
	cookies = aP8bLqZJsQlH3ivWKc.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): BNlxAUgK0Rjp1X = cookies['VISITOR_INFO1_LIVE']
	RaJf24z7sOkrApTlSCPi3 = wc4ZxY9y65vfQLoNWK0hC+':::'+key+':::'+KourIHz3U7i+':::'+BNlxAUgK0Rjp1X+':::'+L6GuZYmNyAEUBi1sQ
	if mzfT1LoKkCy7g9wuSqV=='ytInitialData' and 'ytInitialData' in nR2B1Wye7luXb5:
		KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('window\["ytInitialData"\] = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not KErxXWyFfhN8iwM6aksq7AUR: KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('var ytInitialData = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',KErxXWyFfhN8iwM6aksq7AUR[0])
	elif mzfT1LoKkCy7g9wuSqV=='ytInitialGuideData' and 'ytInitialGuideData' in nR2B1Wye7luXb5:
		KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('var ytInitialGuideData = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',KErxXWyFfhN8iwM6aksq7AUR[0])
	elif '</script>' not in nR2B1Wye7luXb5: x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',nR2B1Wye7luXb5)
	else: x62zYRXwPJGOt0ZNHdSuBmv = eHdDoxhJCEPMZFVa2fg
	if 0:
		kq4ESlfZtHyY = str(x62zYRXwPJGOt0ZNHdSuBmv)
		if WHjh1POtMKlmgiy68RSqb: kq4ESlfZtHyY = kq4ESlfZtHyY.encode(m6PFtLblInpNZ8x)
		open('S:\\0000emad.dat','wb').write(kq4ESlfZtHyY)
	MoO74hKeqm8fFka.setSetting('av.youtube.data',RaJf24z7sOkrApTlSCPi3)
	return nR2B1Wye7luXb5,x62zYRXwPJGOt0ZNHdSuBmv,RaJf24z7sOkrApTlSCPi3
def HGZCvr0u53x(url,WmUKzewgdt7nOa3VlBC19):
	search = mJ1lHWKUPcZGezML7X2u9S()
	if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	E1Viom5L3684CTOFJ = url+'/search?query='+search
	zRK9ruIt0ZFV4bgi(E1Viom5L3684CTOFJ,WmUKzewgdt7nOa3VlBC19)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAg%253D%253D'
		else: DA125SHdNYBzUiamRkbIM = eHdDoxhJCEPMZFVa2fg
		ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+DA125SHdNYBzUiamRkbIM
	else:
		cM1BHTSIon4Caj3DxLQrqiON5W,wAhKQCb5IscE49R8SrzHUiV3Y17g,uVpKOk8ZM0LvQ6UI = [],[],eHdDoxhJCEPMZFVa2fg
		SSQHzxRsZLcPEVn9Tg5o4kOduUqB7 = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		Rf1h8zZUJ5AulnQoWCIt30veS = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		PPCH4BXe0co2ONhV = ZZhzstQTSCXRg('اختر البحث المناسب',SSQHzxRsZLcPEVn9Tg5o4kOduUqB7)
		if PPCH4BXe0co2ONhV == -1: return
		OOXyANTiCmL8EfVnKb = Rf1h8zZUJ5AulnQoWCIt30veS[PPCH4BXe0co2ONhV]
		nR2B1Wye7luXb5,ZMx0IJnBmA3T,data = DgtIMC6QPGenbFWNa3X(E1Viom5L3684CTOFJ+OOXyANTiCmL8EfVnKb)
		if ZMx0IJnBmA3T:
			try:
				OE9QR6mXSAri7Ngx38tB5Mn0jP = ZMx0IJnBmA3T['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for rBWPLyvhmbizDR6I1gjuKXld3EJV in range(len(OE9QR6mXSAri7Ngx38tB5Mn0jP)):
					group = OE9QR6mXSAri7Ngx38tB5Mn0jP[rBWPLyvhmbizDR6I1gjuKXld3EJV]['searchFilterGroupRenderer']['filters']
					for ejCPEwlu2SnafcKthYBDM in range(len(group)):
						ALjRnHYOeE6U12b = group[ejCPEwlu2SnafcKthYBDM]['searchFilterRenderer']
						if 'navigationEndpoint' in list(ALjRnHYOeE6U12b.keys()):
							apOKrFbP9IYHDyUVm7 = ALjRnHYOeE6U12b['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('\u0026','&')
							title = ALjRnHYOeE6U12b['tooltip']
							title = title.replace('البحث عن ',eHdDoxhJCEPMZFVa2fg)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								uVpKOk8ZM0LvQ6UI = title
								bmsN7D3kPQ8Beh5RS0M4ng2FcY = apOKrFbP9IYHDyUVm7
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',eHdDoxhJCEPMZFVa2fg)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								uVpKOk8ZM0LvQ6UI = title
								bmsN7D3kPQ8Beh5RS0M4ng2FcY = apOKrFbP9IYHDyUVm7
							if 'Sort by' in title: continue
							cM1BHTSIon4Caj3DxLQrqiON5W.append(XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title))
							wAhKQCb5IscE49R8SrzHUiV3Y17g.append(apOKrFbP9IYHDyUVm7)
			except: pass
		if not uVpKOk8ZM0LvQ6UI: Xfej5cMiNb6AzLZUhBTuDQwo1dYV = eHdDoxhJCEPMZFVa2fg
		else:
			cM1BHTSIon4Caj3DxLQrqiON5W = ['بدون فلتر',uVpKOk8ZM0LvQ6UI]+cM1BHTSIon4Caj3DxLQrqiON5W
			wAhKQCb5IscE49R8SrzHUiV3Y17g = [eHdDoxhJCEPMZFVa2fg,bmsN7D3kPQ8Beh5RS0M4ng2FcY]+wAhKQCb5IscE49R8SrzHUiV3Y17g
			EJbNYtRsZiBDH7G2leUwjQAP0xfd = ZZhzstQTSCXRg('موقع يوتيوب - اختر الفلتر',cM1BHTSIon4Caj3DxLQrqiON5W)
			if EJbNYtRsZiBDH7G2leUwjQAP0xfd == -1: return
			Xfej5cMiNb6AzLZUhBTuDQwo1dYV = wAhKQCb5IscE49R8SrzHUiV3Y17g[EJbNYtRsZiBDH7G2leUwjQAP0xfd]
		if Xfej5cMiNb6AzLZUhBTuDQwo1dYV: ajHR9ABQl2buvm = q3QVhZaDEuo8t2ASj5vkn+Xfej5cMiNb6AzLZUhBTuDQwo1dYV
		elif OOXyANTiCmL8EfVnKb: ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+OOXyANTiCmL8EfVnKb
		else: ajHR9ABQl2buvm = E1Viom5L3684CTOFJ
	zRK9ruIt0ZFV4bgi(ajHR9ABQl2buvm)
	return
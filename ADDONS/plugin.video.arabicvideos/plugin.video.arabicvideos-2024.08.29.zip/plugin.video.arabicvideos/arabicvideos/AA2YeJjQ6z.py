# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'YOUTUBE'
r07r9xeEFASJXluImT = '_YUT_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text,type,clAzmREWwXf6Gk):
	if	 mode==140: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==143: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url,type)
	elif mode==144: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4(url,text,clAzmREWwXf6Gk)
	elif mode==145: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = HGZCvr0u53x(url)
	elif mode==146: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = he31C6BjsgWboZ(url)
	elif mode==147: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ONDWKQVR7qwFBr4()
	elif mode==148: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGD8lw0JKPjNROXqa7ox9Z4i()
	elif mode==149: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,149,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج',eHdDoxhJCEPMZFVa2fg,290)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مواقع اختارها يوتيوب',q3QVhZaDEuo8t2ASj5vkn+'/feed/guide_builder',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الصفحة الرئيسية',q3QVhZaDEuo8t2ASj5vkn,144,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المحتوى الرائج',q3QVhZaDEuo8t2ASj5vkn+'/feed/trending',146)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: قنوات عربية',eHdDoxhJCEPMZFVa2fg,147)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: قنوات أجنبية',eHdDoxhJCEPMZFVa2fg,148)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: افلام عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=فيلم',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: افلام اجنبية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=movie',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: مسرحيات عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=مسرحية',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: مسلسلات عربية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: مسلسلات اجنبية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=series&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: مسلسلات كارتون',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=كارتون&sp=EgIQAw==',144)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بحث: خطبة المرجعية',q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def ONDWKQVR7qwFBr4():
	EGoutUTNgihIRDYqyAn798cS4(q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def EGD8lw0JKPjNROXqa7ox9Z4i():
	EGoutUTNgihIRDYqyAn798cS4(q3QVhZaDEuo8t2ASj5vkn+'/results?search_query=tv&sp=EgJAAQ==')
	return
def bbmQeYGSTIv(url,type):
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([url],EERWJf1adv67,type,url)
	return
def he31C6BjsgWboZ(url):
	nR2B1Wye7luXb5,O4OfQzkx1KmeIHrjT97E0byA,data = DgtIMC6QPGenbFWNa3X(url)
	uPOi5kYAqsZdNfoJ = O4OfQzkx1KmeIHrjT97E0byA['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for gMmB3iopS0ZXrOFewhcxt in range(len(uPOi5kYAqsZdNfoJ)):
		AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt]
		V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,str(gMmB3iopS0ZXrOFewhcxt))
	NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	wXz6YAZITjhHUK7 = 0
	for gMmB3iopS0ZXrOFewhcxt in range(len(NEpklxn2bweoBgUHZtPhqdWzD3cyC)):
		AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ = NEpklxn2bweoBgUHZtPhqdWzD3cyC[gMmB3iopS0ZXrOFewhcxt]['itemSectionRenderer']['contents'][0]
		if list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		UUQjG45NHzSqZuDe2vYIdTMlJOyc,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN = NNXIxBVDljT57043mSfRbrYzdEH(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ)
		if not title:
			wXz6YAZITjhHUK7 += 1
			title = 'فيديوهات رائجة '+str(wXz6YAZITjhHUK7)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,144,eHdDoxhJCEPMZFVa2fg,str(gMmB3iopS0ZXrOFewhcxt))
	key = cBawilJXvK1m.findall('"innertubeApiKey":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	nR2B1Wye7luXb5,O4OfQzkx1KmeIHrjT97E0byA,LbAmEhrdt7eRV2Y = DgtIMC6QPGenbFWNa3X(E1Viom5L3684CTOFJ)
	for nxNPDeuVwTb3 in range(3,4):
		uPOi5kYAqsZdNfoJ = O4OfQzkx1KmeIHrjT97E0byA['items'][nxNPDeuVwTb3]['guideSectionRenderer']['items']
		for gMmB3iopS0ZXrOFewhcxt in range(len(uPOi5kYAqsZdNfoJ)):
			AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt]
			if 'YouTube Premium' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ): continue
			V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ)
	return
def EGoutUTNgihIRDYqyAn798cS4(url,data=eHdDoxhJCEPMZFVa2fg,index=0):
	global MoO74hKeqm8fFka
	if not data: data = MoO74hKeqm8fFka.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg)
	nR2B1Wye7luXb5,O4OfQzkx1KmeIHrjT97E0byA,LbAmEhrdt7eRV2Y = DgtIMC6QPGenbFWNa3X(url,data)
	dEQ6I4ixalFU,sFH9w07PmI4Y = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	lPbeIkcm9Ows2U54NhGFL = cBawilJXvK1m.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not lPbeIkcm9Ows2U54NhGFL: lPbeIkcm9Ows2U54NhGFL = cBawilJXvK1m.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not lPbeIkcm9Ows2U54NhGFL: lPbeIkcm9Ows2U54NhGFL = cBawilJXvK1m.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if lPbeIkcm9Ows2U54NhGFL:
		dEQ6I4ixalFU = SbyWQGMDnV+lPbeIkcm9Ows2U54NhGFL[0][0]+Nat0Dx9puRUWCsgz6JyFhY3
		apOKrFbP9IYHDyUVm7 = lPbeIkcm9Ows2U54NhGFL[0][1]
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
		if 'list=' in url: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+dEQ6I4ixalFU,apOKrFbP9IYHDyUVm7,144)
	LS38ndajmGWNX4ZHcwf = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	JZBWrhOuMzAGYH12q = not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in url for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in LS38ndajmGWNX4ZHcwf)
	if JZBWrhOuMzAGYH12q and dEQ6I4ixalFU:
		C8Qb5HdOey9Maf60Y3xZKGmhlDc1 = 'البحث'
		uVpKOk8ZM0LvQ6UI = 'قوائم التشغيل'
		qg3DwCuZVcyLpnzEjtvFaHKkMs = 'الفيديوهات'
		loy1KS7HJhjC36wfsTiqQM = 'القنوات'
		qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+dEQ6I4ixalFU,url,9999)
		if '"title":"بحث"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+C8Qb5HdOey9Maf60Y3xZKGmhlDc1,url,145,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,url+'/playlists',144)
		if '"title":"الفيديوهات"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+qg3DwCuZVcyLpnzEjtvFaHKkMs,url+'/videos',144)
		if '"title":"القنوات"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+loy1KS7HJhjC36wfsTiqQM,url+'/channels',144)
		if '"title":"Search"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+C8Qb5HdOey9Maf60Y3xZKGmhlDc1,url,145,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
		if '"title":"Playlists"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,url+'/playlists',144)
		if '"title":"Videos"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+qg3DwCuZVcyLpnzEjtvFaHKkMs,url+'/videos',144)
		if '"title":"Channels"' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+loy1KS7HJhjC36wfsTiqQM,url+'/channels',144)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	if 'search_query' in url:
		uPOi5kYAqsZdNfoJ = O4OfQzkx1KmeIHrjT97E0byA['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		td4a9SWNVkiRAXesnbhP8 = 0
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(uPOi5kYAqsZdNfoJ)):
			if 'itemSectionRenderer' in list(uPOi5kYAqsZdNfoJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq].keys()):
				hrpbt92JHIWLqnRK1STPzxsV = uPOi5kYAqsZdNfoJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq]['itemSectionRenderer']
				R2apkdt0qg41 = len(str(hrpbt92JHIWLqnRK1STPzxsV))
				if R2apkdt0qg41>td4a9SWNVkiRAXesnbhP8:
					td4a9SWNVkiRAXesnbhP8 = R2apkdt0qg41
					sFH9w07PmI4Y = hrpbt92JHIWLqnRK1STPzxsV
		if td4a9SWNVkiRAXesnbhP8==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==q3QVhZaDEuo8t2ASj5vkn:
		eZlo7XvRDyM = []
		eZlo7XvRDyM.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		eZlo7XvRDyM.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		eZlo7XvRDyM.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		eZlo7XvRDyM.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		eZlo7XvRDyM.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		eZlo7XvRDyM.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		eZlo7XvRDyM.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		eZlo7XvRDyM.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		EES7AofkCO0McYK2vbtjB8XP9Nw,sFH9w07PmI4Y = FFW4gOshlGDuPtCeN70ByvaIjLTpm(O4OfQzkx1KmeIHrjT97E0byA,eHdDoxhJCEPMZFVa2fg,eZlo7XvRDyM)
	if not sFH9w07PmI4Y:
		try:
			uPOi5kYAqsZdNfoJ = O4OfQzkx1KmeIHrjT97E0byA['contents']['twoColumnBrowseResultsRenderer']['tabs']
			ZEihvxcN7XBjIrT4YytVmFgP1 = '/videos' in url or '/playlists' in url or '/channels' in url
			EEdrq7pItw8f1hOTvBjyuLlNiQ5SFG = '"title":"الفيديوهات"' in nR2B1Wye7luXb5 or '"title":"قوائم التشغيل"' in nR2B1Wye7luXb5 or '"title":"القنوات"' in nR2B1Wye7luXb5
			CrkWoSBixvbj0dfqF8g = '"title":"Videos"' in nR2B1Wye7luXb5 or '"title":"Playlists"' in nR2B1Wye7luXb5 or '"title":"Channels"' in nR2B1Wye7luXb5
			if ZEihvxcN7XBjIrT4YytVmFgP1 and (EEdrq7pItw8f1hOTvBjyuLlNiQ5SFG or CrkWoSBixvbj0dfqF8g):
				for gMmB3iopS0ZXrOFewhcxt in range(len(uPOi5kYAqsZdNfoJ)):
					if 'tabRenderer' not in list(uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt].keys()): continue
					NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt]['tabRenderer']
					try: MhYat4s2GRvDfAl1rVw7J = NEpklxn2bweoBgUHZtPhqdWzD3cyC['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][gMmB3iopS0ZXrOFewhcxt]
					except: MhYat4s2GRvDfAl1rVw7J = NEpklxn2bweoBgUHZtPhqdWzD3cyC
					try: apOKrFbP9IYHDyUVm7 = MhYat4s2GRvDfAl1rVw7J['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in apOKrFbP9IYHDyUVm7	and '/videos'		in url: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt] ; break
					elif '/playlists'	in apOKrFbP9IYHDyUVm7	and '/playlists'	in url: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt] ; break
					elif '/channels'	in apOKrFbP9IYHDyUVm7	and '/channels'		in url: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[gMmB3iopS0ZXrOFewhcxt] ; break
					else: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[0]
			elif 'bp=' in url: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[index]
			else: NEpklxn2bweoBgUHZtPhqdWzD3cyC = uPOi5kYAqsZdNfoJ[0]
			sFH9w07PmI4Y = NEpklxn2bweoBgUHZtPhqdWzD3cyC['tabRenderer']['content']
		except: pass
	if not sFH9w07PmI4Y: return
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: eZlo7XvRDyM.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']['contents']")
	eZlo7XvRDyM.append("ff['sectionListRenderer']")
	eZlo7XvRDyM.append("ff['richGridRenderer']['contents']")
	eZlo7XvRDyM.append("ff['contents']")
	eZlo7XvRDyM.append("ff")
	PPtp5MCB7VaXlx6gvA = ZJPiId12qkesLNTvQW9H(u'كل قوائم التشغيل')
	FUYe2Pr8dBGVo5fSm9nMyi = ZJPiId12qkesLNTvQW9H(u'كل الفيديوهات')
	iSlTAjRZIanym5q3Wgvts = ZJPiId12qkesLNTvQW9H(u'كل القنوات')
	oaNKRdjYGhkDwBWFCXHz5OEUv = [PPtp5MCB7VaXlx6gvA,FUYe2Pr8dBGVo5fSm9nMyi,iSlTAjRZIanym5q3Wgvts,'All playlists','All videos','All channels']
	IyziSZVbmKoq49YD8,MhYat4s2GRvDfAl1rVw7J = FFW4gOshlGDuPtCeN70ByvaIjLTpm(sFH9w07PmI4Y,index,eZlo7XvRDyM)
	if 'list' in str(type(MhYat4s2GRvDfAl1rVw7J)) and any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in str(MhYat4s2GRvDfAl1rVw7J[0]) for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in oaNKRdjYGhkDwBWFCXHz5OEUv): del MhYat4s2GRvDfAl1rVw7J[0]
	for qXbQg1fweajEnp835cvur6JstHdVMo in range(len(MhYat4s2GRvDfAl1rVw7J)):
		eZlo7XvRDyM = []
		eZlo7XvRDyM.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		eZlo7XvRDyM.append("gg[index2]['itemSectionRenderer']['header']")
		eZlo7XvRDyM.append("gg[index2]['horizontalCardListRenderer']['header']")
		eZlo7XvRDyM.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		eZlo7XvRDyM.append("gg[index2]['richSectionRenderer']['content']")
		eZlo7XvRDyM.append("gg[index2]['richItemRenderer']['content']")
		eZlo7XvRDyM.append("gg[index2]['gameCardRenderer']['game']")
		eZlo7XvRDyM.append("gg[index2]")
		EES7AofkCO0McYK2vbtjB8XP9Nw,AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ = FFW4gOshlGDuPtCeN70ByvaIjLTpm(MhYat4s2GRvDfAl1rVw7J,qXbQg1fweajEnp835cvur6JstHdVMo,eZlo7XvRDyM)
		V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url,str(qXbQg1fweajEnp835cvur6JstHdVMo))
		if EES7AofkCO0McYK2vbtjB8XP9Nw=='4':
			try:
				gnUfzkQBOSaV9uT36h8Ki5Yol = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for VxuziIhdo8F in range(len(gnUfzkQBOSaV9uT36h8Ki5Yol)):
					AJQxD8aRgjWPUlbfChZ36Is0B2 = gnUfzkQBOSaV9uT36h8Ki5Yol[VxuziIhdo8F]
					V3Vk6WBfxgjiYAeTphM4w8N2(AJQxD8aRgjWPUlbfChZ36Is0B2)
			except: pass
	sCVKdvo76plYG9hkz = False
	if 'view=' not in url and IyziSZVbmKoq49YD8=='8': sCVKdvo76plYG9hkz = True
	if ':::' in LbAmEhrdt7eRV2Y: wc4ZxY9y65vfQLoNWK0hC,key,sgHWGXSUBv8uFkCPR9Zwch4T,KourIHz3U7i,L6GuZYmNyAEUBi1sQ,BNlxAUgK0Rjp1X = LbAmEhrdt7eRV2Y.split(':::')
	else: wc4ZxY9y65vfQLoNWK0hC,key,sgHWGXSUBv8uFkCPR9Zwch4T,KourIHz3U7i,L6GuZYmNyAEUBi1sQ,BNlxAUgK0Rjp1X = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	E1Viom5L3684CTOFJ,JbBOjkDXHWQqrnGIz5RYNd = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if JXSlk8x495HmgiD:
		SLMATC1aWZ5wDHO2UcoqQGFly = str(JXSlk8x495HmgiD[-1][1])
		if   r07r9xeEFASJXluImT+'CHNL' in SLMATC1aWZ5wDHO2UcoqQGFly: JbBOjkDXHWQqrnGIz5RYNd = 'CHANNELS'
		elif r07r9xeEFASJXluImT+'USER' in SLMATC1aWZ5wDHO2UcoqQGFly: JbBOjkDXHWQqrnGIz5RYNd = 'CHANNELS'
		elif r07r9xeEFASJXluImT+'LIST' in SLMATC1aWZ5wDHO2UcoqQGFly: JbBOjkDXHWQqrnGIz5RYNd = 'PLAYLISTS'
	if '"continuations"' in nR2B1Wye7luXb5 and '&list=' not in url and not sCVKdvo76plYG9hkz and 'shelf_id' not in url:
		E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/browse_ajax?ctoken='+sgHWGXSUBv8uFkCPR9Zwch4T
	elif '"token"' in nR2B1Wye7luXb5 and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/search?key='+key
	elif '"token"' in nR2B1Wye7luXb5 and 'bp=' not in url:
		E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/youtubei/v1/browse?key='+key
	if E1Viom5L3684CTOFJ: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة أخرى',E1Viom5L3684CTOFJ,144,JbBOjkDXHWQqrnGIz5RYNd,eHdDoxhJCEPMZFVa2fg,LbAmEhrdt7eRV2Y)
	return
def FFW4gOshlGDuPtCeN70ByvaIjLTpm(DDY4vSW3UQ,pxVBnJRzq0,YyzjRvC5SAwh):
	O4OfQzkx1KmeIHrjT97E0byA = DDY4vSW3UQ
	sFH9w07PmI4Y,index = DDY4vSW3UQ,pxVBnJRzq0
	MhYat4s2GRvDfAl1rVw7J,qXbQg1fweajEnp835cvur6JstHdVMo = DDY4vSW3UQ,pxVBnJRzq0
	AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63 = DDY4vSW3UQ,pxVBnJRzq0
	count = len(YyzjRvC5SAwh)
	for gMmB3iopS0ZXrOFewhcxt in range(count):
		try:
			iQGPlFW0h1kJ5En4 = eval(YyzjRvC5SAwh[gMmB3iopS0ZXrOFewhcxt])
			return str(gMmB3iopS0ZXrOFewhcxt+1),iQGPlFW0h1kJ5En4
		except: pass
	return eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
def NNXIxBVDljT57043mSfRbrYzdEH(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ):
	try: svA7DYyJKC = list(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.keys())[0]
	except: return False,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	UUQjG45NHzSqZuDe2vYIdTMlJOyc,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN = False,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	AFWRBzHQ9PVl71M2k0vTLjgerJD63 = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ[svA7DYyJKC]
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("render['unplayableText']['simpleText']")
	eZlo7XvRDyM.append("render['formattedTitle']['simpleText']")
	eZlo7XvRDyM.append("render['title']['simpleText']")
	eZlo7XvRDyM.append("render['title']['runs'][0]['text']")
	eZlo7XvRDyM.append("render['text']['simpleText']")
	eZlo7XvRDyM.append("render['text']['runs'][0]['text']")
	eZlo7XvRDyM.append("render['title']")
	eZlo7XvRDyM.append("item['title']")
	EES7AofkCO0McYK2vbtjB8XP9Nw,title = FFW4gOshlGDuPtCeN70ByvaIjLTpm(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	eZlo7XvRDyM.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	EES7AofkCO0McYK2vbtjB8XP9Nw,apOKrFbP9IYHDyUVm7 = FFW4gOshlGDuPtCeN70ByvaIjLTpm(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("render['thumbnail']['thumbnails'][0]['url']")
	eZlo7XvRDyM.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	EES7AofkCO0McYK2vbtjB8XP9Nw,PeLqCN5Ek8bB = FFW4gOshlGDuPtCeN70ByvaIjLTpm(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("render['videoCount']")
	eZlo7XvRDyM.append("render['videoCountText']['runs'][0]['text']")
	eZlo7XvRDyM.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	EES7AofkCO0McYK2vbtjB8XP9Nw,count = FFW4gOshlGDuPtCeN70ByvaIjLTpm(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63,eZlo7XvRDyM)
	eZlo7XvRDyM = []
	eZlo7XvRDyM.append("render['lengthText']['simpleText']")
	eZlo7XvRDyM.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	eZlo7XvRDyM.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	EES7AofkCO0McYK2vbtjB8XP9Nw,WWPgm9fvlH2oIOnrD1 = FFW4gOshlGDuPtCeN70ByvaIjLTpm(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,AFWRBzHQ9PVl71M2k0vTLjgerJD63,eZlo7XvRDyM)
	if 'LIVE' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA = eHdDoxhJCEPMZFVa2fg,'LIVE:  '
	if 'مباشر' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA = eHdDoxhJCEPMZFVa2fg,'LIVE:  '
	if 'badges' in list(AFWRBzHQ9PVl71M2k0vTLjgerJD63.keys()):
		zECDMijlvbRWQh32 = str(AFWRBzHQ9PVl71M2k0vTLjgerJD63['badges'])
		if 'Free with Ads' in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$:'
		if 'LIVE NOW' in zECDMijlvbRWQh32: r0EKZGtfBUdOvqnSNhFA = 'LIVE:  '
		if 'Buy' in zECDMijlvbRWQh32 or 'Rent' in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:'
		if ZJPiId12qkesLNTvQW9H(u'مباشر') in zECDMijlvbRWQh32: r0EKZGtfBUdOvqnSNhFA = 'LIVE:  '
		if ZJPiId12qkesLNTvQW9H(u'شراء') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:'
		if ZJPiId12qkesLNTvQW9H(u'استئجار') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$$:'
		if ZJPiId12qkesLNTvQW9H(u'إعلانات') in zECDMijlvbRWQh32: HAaeWXKhS7uLMFBxk4PzN = '$:'
	apOKrFbP9IYHDyUVm7 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(apOKrFbP9IYHDyUVm7)
	if apOKrFbP9IYHDyUVm7 and 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
	PeLqCN5Ek8bB = PeLqCN5Ek8bB.split('?')[0]
	if  PeLqCN5Ek8bB and 'http' not in PeLqCN5Ek8bB: PeLqCN5Ek8bB = 'https:'+PeLqCN5Ek8bB
	title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
	if HAaeWXKhS7uLMFBxk4PzN: title = HAaeWXKhS7uLMFBxk4PzN+KwJyZLDzC4FbHhXgTfI+title
	WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace(',',eHdDoxhJCEPMZFVa2fg)
	count = count.replace(',',eHdDoxhJCEPMZFVa2fg)
	count = cBawilJXvK1m.findall('\d+',count)
	if count: count = count[0]
	else: count = eHdDoxhJCEPMZFVa2fg
	return True,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN
def V3Vk6WBfxgjiYAeTphM4w8N2(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ,url=eHdDoxhJCEPMZFVa2fg,index=eHdDoxhJCEPMZFVa2fg):
	UUQjG45NHzSqZuDe2vYIdTMlJOyc,title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,count,WWPgm9fvlH2oIOnrD1,r0EKZGtfBUdOvqnSNhFA,HAaeWXKhS7uLMFBxk4PzN = NNXIxBVDljT57043mSfRbrYzdEH(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ)
	if not UUQjG45NHzSqZuDe2vYIdTMlJOyc: return
	elif 'continuationItemRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ): return
	elif 'searchPyvRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ): return
	elif not apOKrFbP9IYHDyUVm7 and 'search_query' in url: return
	elif title and not apOKrFbP9IYHDyUVm7 and ('search_query' in url or 'horizontalMovieListRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ) or url==q3QVhZaDEuo8t2ASj5vkn):
		title = '=== '+title+' ==='
		qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,9999)
	elif title and 'messageRenderer' in str(AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ):
		qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,9999)
	elif '/feed/trending' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,index)
	elif not title: return
	elif r0EKZGtfBUdOvqnSNhFA: qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+r0EKZGtfBUdOvqnSNhFA+title,apOKrFbP9IYHDyUVm7,143,PeLqCN5Ek8bB)
	elif 'watch?v=' in apOKrFbP9IYHDyUVm7 or '/shorts/' in apOKrFbP9IYHDyUVm7:
		if '&list=' in apOKrFbP9IYHDyUVm7 and 'index=' not in apOKrFbP9IYHDyUVm7:
			WWlySEYmJPD87p3sUBLtaF2ozAdji = apOKrFbP9IYHDyUVm7.split('&list=',1)[1]
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/playlist?list='+WWlySEYmJPD87p3sUBLtaF2ozAdji
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'LIST'+count+':  '+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB)
		else:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&list=',1)[0]
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,143,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
	else:
		type = eHdDoxhJCEPMZFVa2fg
		if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = url
		elif not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in apOKrFbP9IYHDyUVm7 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in apOKrFbP9IYHDyUVm7 or '/c/' in apOKrFbP9IYHDyUVm7: type = 'CHNL'+count+':  '
			if '/user/' in apOKrFbP9IYHDyUVm7: type = 'USER'+count+':  '
			index,lR78kdczrfaGusnjy3U1WFqETOHYK = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+type+title,apOKrFbP9IYHDyUVm7,144,PeLqCN5Ek8bB,index)
	return
def DgtIMC6QPGenbFWNa3X(url,data=eHdDoxhJCEPMZFVa2fg,mzfT1LoKkCy7g9wuSqV=eHdDoxhJCEPMZFVa2fg):
	global MoO74hKeqm8fFka
	if not data: data = MoO74hKeqm8fFka.getSetting('av.youtube.data')
	if mzfT1LoKkCy7g9wuSqV==eHdDoxhJCEPMZFVa2fg: mzfT1LoKkCy7g9wuSqV = 'ytInitialData'
	PPOaXI9Tr1fAD7luhFGYpKJ5q = qq62QA8h3pGxzCwWVeXIF7glKf()
	W9PzsMeLJTc83mS45G17n = {'User-Agent':PPOaXI9Tr1fAD7luhFGYpKJ5q,'Cookie':'PREF=hl=ar'}
	if ':::' in data: wc4ZxY9y65vfQLoNWK0hC,key,sgHWGXSUBv8uFkCPR9Zwch4T,KourIHz3U7i,L6GuZYmNyAEUBi1sQ,BNlxAUgK0Rjp1X = data.split(':::')
	else: wc4ZxY9y65vfQLoNWK0hC,key,sgHWGXSUBv8uFkCPR9Zwch4T,KourIHz3U7i,L6GuZYmNyAEUBi1sQ,BNlxAUgK0Rjp1X = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if 'guide?key=' in url:
		LbAmEhrdt7eRV2Y = {}
		LbAmEhrdt7eRV2Y['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":KourIHz3U7i}}
		LbAmEhrdt7eRV2Y = str(LbAmEhrdt7eRV2Y)
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',url,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and wc4ZxY9y65vfQLoNWK0hC:
		LbAmEhrdt7eRV2Y = {'continuation':L6GuZYmNyAEUBi1sQ}
		LbAmEhrdt7eRV2Y['context'] = {"client":{"visitorData":wc4ZxY9y65vfQLoNWK0hC,"clientName":"WEB","clientVersion":KourIHz3U7i}}
		LbAmEhrdt7eRV2Y = str(LbAmEhrdt7eRV2Y)
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',url,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and BNlxAUgK0Rjp1X:
		W9PzsMeLJTc83mS45G17n.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':KourIHz3U7i})
		W9PzsMeLJTc83mS45G17n.update({'Cookie':'VISITOR_INFO1_LIVE='+BNlxAUgK0Rjp1X})
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'YOUTUBE-GET_PAGE_DATA-4th')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('"innertubeApiKey".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if ge4hFRp51QsUPtGTnBuzka: key = ge4hFRp51QsUPtGTnBuzka[0]
	ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('"cver".*?"value".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if ge4hFRp51QsUPtGTnBuzka: KourIHz3U7i = ge4hFRp51QsUPtGTnBuzka[0]
	ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('"token".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if ge4hFRp51QsUPtGTnBuzka: L6GuZYmNyAEUBi1sQ = ge4hFRp51QsUPtGTnBuzka[0]
	ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('"visitorData".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if ge4hFRp51QsUPtGTnBuzka: wc4ZxY9y65vfQLoNWK0hC = ge4hFRp51QsUPtGTnBuzka[0]
	ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall('"continuation".*?"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.I)
	if ge4hFRp51QsUPtGTnBuzka: sgHWGXSUBv8uFkCPR9Zwch4T = ge4hFRp51QsUPtGTnBuzka[0]
	cookies = aP8bLqZJsQlH3ivWKc.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): BNlxAUgK0Rjp1X = cookies['VISITOR_INFO1_LIVE']
	data = wc4ZxY9y65vfQLoNWK0hC+':::'+key+':::'+sgHWGXSUBv8uFkCPR9Zwch4T+':::'+KourIHz3U7i+':::'+L6GuZYmNyAEUBi1sQ+':::'+BNlxAUgK0Rjp1X
	if mzfT1LoKkCy7g9wuSqV=='ytInitialData' and 'ytInitialData' in nR2B1Wye7luXb5:
		KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('window\["ytInitialData"\] = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not KErxXWyFfhN8iwM6aksq7AUR: KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('var ytInitialData = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',KErxXWyFfhN8iwM6aksq7AUR[0])
	elif mzfT1LoKkCy7g9wuSqV=='ytInitialGuideData' and 'ytInitialGuideData' in nR2B1Wye7luXb5:
		KErxXWyFfhN8iwM6aksq7AUR = cBawilJXvK1m.findall('var ytInitialGuideData = ({.*?});',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',KErxXWyFfhN8iwM6aksq7AUR[0])
	elif '</script>' not in nR2B1Wye7luXb5: x62zYRXwPJGOt0ZNHdSuBmv = DIpuHqsKGS3ErJvk9taCRiX80('str',nR2B1Wye7luXb5)
	else: x62zYRXwPJGOt0ZNHdSuBmv = eHdDoxhJCEPMZFVa2fg
	MoO74hKeqm8fFka.setSetting('av.youtube.data',data)
	return nR2B1Wye7luXb5,x62zYRXwPJGOt0ZNHdSuBmv,data
def HGZCvr0u53x(url):
	search = mJ1lHWKUPcZGezML7X2u9S()
	if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	E1Viom5L3684CTOFJ = url+'/search?query='+search
	EGoutUTNgihIRDYqyAn798cS4(E1Viom5L3684CTOFJ)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in WWLbVhETM9ZCwm85f: DA125SHdNYBzUiamRkbIM = '&sp=EgIQAg%253D%253D'
		ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+DA125SHdNYBzUiamRkbIM
	else:
		cM1BHTSIon4Caj3DxLQrqiON5W,wAhKQCb5IscE49R8SrzHUiV3Y17g,uVpKOk8ZM0LvQ6UI = [],[],eHdDoxhJCEPMZFVa2fg
		SSQHzxRsZLcPEVn9Tg5o4kOduUqB7 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		Rf1h8zZUJ5AulnQoWCIt30veS = [eHdDoxhJCEPMZFVa2fg,'&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		PPCH4BXe0co2ONhV = ZZhzstQTSCXRg('موقع يوتيوب - اختر الترتيب',SSQHzxRsZLcPEVn9Tg5o4kOduUqB7)
		if PPCH4BXe0co2ONhV == -1: return
		OOXyANTiCmL8EfVnKb = Rf1h8zZUJ5AulnQoWCIt30veS[PPCH4BXe0co2ONhV]
		nR2B1Wye7luXb5,ZMx0IJnBmA3T,data = DgtIMC6QPGenbFWNa3X(E1Viom5L3684CTOFJ+OOXyANTiCmL8EfVnKb)
		if ZMx0IJnBmA3T:
			OE9QR6mXSAri7Ngx38tB5Mn0jP = ZMx0IJnBmA3T['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for rBWPLyvhmbizDR6I1gjuKXld3EJV in range(len(OE9QR6mXSAri7Ngx38tB5Mn0jP)):
				group = OE9QR6mXSAri7Ngx38tB5Mn0jP[rBWPLyvhmbizDR6I1gjuKXld3EJV]['searchFilterGroupRenderer']['filters']
				for ejCPEwlu2SnafcKthYBDM in range(len(group)):
					AFWRBzHQ9PVl71M2k0vTLjgerJD63 = group[ejCPEwlu2SnafcKthYBDM]['searchFilterRenderer']
					if 'navigationEndpoint' in list(AFWRBzHQ9PVl71M2k0vTLjgerJD63.keys()):
						apOKrFbP9IYHDyUVm7 = AFWRBzHQ9PVl71M2k0vTLjgerJD63['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('\u0026','&')
						title = AFWRBzHQ9PVl71M2k0vTLjgerJD63['tooltip']
						title = title.replace('البحث عن ',eHdDoxhJCEPMZFVa2fg)
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							uVpKOk8ZM0LvQ6UI = title
							bmsN7D3kPQ8Beh5RS0M4ng2FcY = apOKrFbP9IYHDyUVm7
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ',eHdDoxhJCEPMZFVa2fg)
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							uVpKOk8ZM0LvQ6UI = title
							bmsN7D3kPQ8Beh5RS0M4ng2FcY = apOKrFbP9IYHDyUVm7
						if 'Sort by' in title: continue
						cM1BHTSIon4Caj3DxLQrqiON5W.append(XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title))
						wAhKQCb5IscE49R8SrzHUiV3Y17g.append(apOKrFbP9IYHDyUVm7)
		if not uVpKOk8ZM0LvQ6UI: Xfej5cMiNb6AzLZUhBTuDQwo1dYV = eHdDoxhJCEPMZFVa2fg
		else:
			cM1BHTSIon4Caj3DxLQrqiON5W = ['بدون فلتر',uVpKOk8ZM0LvQ6UI]+cM1BHTSIon4Caj3DxLQrqiON5W
			wAhKQCb5IscE49R8SrzHUiV3Y17g = [eHdDoxhJCEPMZFVa2fg,bmsN7D3kPQ8Beh5RS0M4ng2FcY]+wAhKQCb5IscE49R8SrzHUiV3Y17g
			EJbNYtRsZiBDH7G2leUwjQAP0xfd = ZZhzstQTSCXRg('موقع يوتيوب - اختر الفلتر',cM1BHTSIon4Caj3DxLQrqiON5W)
			if EJbNYtRsZiBDH7G2leUwjQAP0xfd == -1: return
			Xfej5cMiNb6AzLZUhBTuDQwo1dYV = wAhKQCb5IscE49R8SrzHUiV3Y17g[EJbNYtRsZiBDH7G2leUwjQAP0xfd]
		if Xfej5cMiNb6AzLZUhBTuDQwo1dYV: ajHR9ABQl2buvm = q3QVhZaDEuo8t2ASj5vkn+Xfej5cMiNb6AzLZUhBTuDQwo1dYV
		elif OOXyANTiCmL8EfVnKb: ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+OOXyANTiCmL8EfVnKb
		else: ajHR9ABQl2buvm = E1Viom5L3684CTOFJ
	EGoutUTNgihIRDYqyAn798cS4(ajHR9ABQl2buvm)
	return
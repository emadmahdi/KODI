# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from dIxmaLQn3F import *
EERWJf1adv67 = w2vjZmdJuY7c(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢨ")
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK,Nn360bq79W2kzUt):
	if   tWi3JH8rRhxcgnYuMVUK==jUcmHhgVvW0EdYOIfXeaDF(u"࠵࠶࠴ह"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = cMjfa01KTDZeVB3rup()
	elif tWi3JH8rRhxcgnYuMVUK==Cp6c5tZe8I0PxnAW(u"࠶࠷࠶ऺ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(Nn360bq79W2kzUt)
	elif tWi3JH8rRhxcgnYuMVUK==NxXMrsTC5FniYuRBOK8(u"࠷࠸࠸ऻ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = vKCHqnUJXi9e2L3sA7f()
	elif tWi3JH8rRhxcgnYuMVUK==KQ3sCe9Pzh(u"࠸࠹࠳़"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = LqNfHpvi2oXc4WTCSO731()
	elif tWi3JH8rRhxcgnYuMVUK==LTN6DPEmrwehtZMy(u"࠹࠳࠵ऽ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wn8LDTtVW6UKlf(Nn360bq79W2kzUt)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = rDceXBpHkfVUYRJ3tIx95Z
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def wn8LDTtVW6UKlf(a1aOWQRZEJ6bL4iNqxX2T):
	try: RRydns1CErYlIhwSx7.remove(a1aOWQRZEJ6bL4iNqxX2T.decode(m6PFtLblInpNZ8x))
	except: RRydns1CErYlIhwSx7.remove(a1aOWQRZEJ6bL4iNqxX2T)
	return
def bbmQeYGSTIv(Nn360bq79W2kzUt):
	IZkpyKSFVarcHwG1g6emqQv70h(Nn360bq79W2kzUt,EERWJf1adv67,XugxFprC26zGM(u"ࠬࡼࡩࡥࡧࡲࠫࢩ"))
	return
def LqNfHpvi2oXc4WTCSO731():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = XugxFprC26zGM(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢪ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢫ"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def cMjfa01KTDZeVB3rup():
	qfpnsHw19BiaSktcXWbGA(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨ࡮࡬ࡲࡰ࠭ࢬ"),SbyWQGMDnV+RqLvTrID0yMVeClpYcnZ16i3X(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢭ")+Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳࠴࠵ा"))
	qfpnsHw19BiaSktcXWbGA(EX25Y0l8ILvz7QcRC(u"ࠪࡰ࡮ࡴ࡫ࠨࢮ"),SbyWQGMDnV+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢯ")+Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"࠴࠵࠵ि"))
	qfpnsHw19BiaSktcXWbGA(bP01xn84BiQN(u"ࠬࡲࡩ࡯࡭ࠪࢰ"),SbyWQGMDnV+TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢱ")+Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"࠻࠼࠽࠾ी"))
	nJj0g3Psa4kF = n915RQOkKPVT()
	qXcoaR9vBht3ikudrK2E = RRydns1CErYlIhwSx7.stat(nJj0g3Psa4kF).st_mtime
	FefZKgxmYVLjkWN4yhod79 = []
	if WHjh1POtMKlmgiy68RSqb: MB1t7XpEnq3jQa = RRydns1CErYlIhwSx7.listdir(nJj0g3Psa4kF.encode(m6PFtLblInpNZ8x))
	else: MB1t7XpEnq3jQa = RRydns1CErYlIhwSx7.listdir(nJj0g3Psa4kF.decode(m6PFtLblInpNZ8x))
	for cepLvEox93aUI in MB1t7XpEnq3jQa:
		if WHjh1POtMKlmgiy68RSqb: cepLvEox93aUI = cepLvEox93aUI.decode(m6PFtLblInpNZ8x)
		if not cepLvEox93aUI.startswith(NxXMrsTC5FniYuRBOK8(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢲ")): continue
		jjY0VC86A1kw2UyGR = RRydns1CErYlIhwSx7.path.join(nJj0g3Psa4kF,cepLvEox93aUI)
		qXcoaR9vBht3ikudrK2E = RRydns1CErYlIhwSx7.path.getmtime(jjY0VC86A1kw2UyGR)
		FefZKgxmYVLjkWN4yhod79.append([cepLvEox93aUI,qXcoaR9vBht3ikudrK2E])
	FefZKgxmYVLjkWN4yhod79 = sorted(FefZKgxmYVLjkWN4yhod79,reverse=YchIv6N09BaWPEj4tieAnluKZrRXT,key=lambda key: key[NSudqlOzja])
	for cepLvEox93aUI,qXcoaR9vBht3ikudrK2E in FefZKgxmYVLjkWN4yhod79:
		if lHfbysRrUV7m4CLSdkxc382n:
			try: cepLvEox93aUI = cepLvEox93aUI.decode(m6PFtLblInpNZ8x)
			except: pass
			cepLvEox93aUI = cepLvEox93aUI.encode(m6PFtLblInpNZ8x)
		jjY0VC86A1kw2UyGR = RRydns1CErYlIhwSx7.path.join(nJj0g3Psa4kF,cepLvEox93aUI)
		qfpnsHw19BiaSktcXWbGA(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡸ࡬ࡨࡪࡵࠧࢳ"),cepLvEox93aUI,jjY0VC86A1kw2UyGR,w2vjZmdJuY7c(u"࠶࠷࠶ु"))
	return
def n915RQOkKPVT():
	nJj0g3Psa4kF = MoO74hKeqm8fFka.getSetting(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢴ"))
	if nJj0g3Psa4kF: return nJj0g3Psa4kF
	MoO74hKeqm8fFka.setSetting(KW5bYS20wTF1LyCs9(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢵ"),oX9h2wrQe5)
	return oX9h2wrQe5
def vKCHqnUJXi9e2L3sA7f():
	nJj0g3Psa4kF = n915RQOkKPVT()
	ODCiVn13BqwWStFEIGvL0 = VinwUNFtrZTh0oPs2zm(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢶ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢷ"),OR97bMGecfgDCqux3YdAZ6y+nJj0g3Psa4kF+Nat0Dx9puRUWCsgz6JyFhY3+egY8Jti0smdLM3h1VQRSW(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢸ"))
	if ODCiVn13BqwWStFEIGvL0==CKUiyEe28zsZ(u"࠵ू"):
		Qc7RKvLdjlTzwPIFfuUt1JGsBSM06 = QQXiBT8HLl4PY(XugxFprC26zGM(u"࠸ृ"),NxXMrsTC5FniYuRBOK8(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢹ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ࡮ࡲࡧࡦࡲࠧࢺ"),eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT,nJj0g3Psa4kF)
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(egY8Jti0smdLM3h1VQRSW(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢻ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢼ"),OR97bMGecfgDCqux3YdAZ6y+nJj0g3Psa4kF+Nat0Dx9puRUWCsgz6JyFhY3+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢽ"))
		if zf7iFX1auw0bQU==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷ॄ"):
			MoO74hKeqm8fFka.setSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢾ"),Qc7RKvLdjlTzwPIFfuUt1JGsBSM06)
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢿ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࣀ"))
	return
def u2VEfGDOpbW0rCJ6(Nn360bq79W2kzUt,JGtX1fiayl9R=eHdDoxhJCEPMZFVa2fg,website=eHdDoxhJCEPMZFVa2fg):
	vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+Cp6c5tZe8I0PxnAW(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࣁ")+Nn360bq79W2kzUt+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࠣࡡࠬࣂ"))
	if not JGtX1fiayl9R: JGtX1fiayl9R = llr1C3SIFjViqLDtZP(Nn360bq79W2kzUt)
	nJj0g3Psa4kF = n915RQOkKPVT()
	wEiDnMUNsWC = r17Z5qKTw3gQ()
	cepLvEox93aUI = wEiDnMUNsWC.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡣࠬࣃ"))
	cepLvEox93aUI = gTFGf5IRwYWns8QHcKzoBAvC(cepLvEox93aUI)
	cepLvEox93aUI = wY1p9mP03S8drbcH64t5WQkv(u"ࠫ࡫࡯࡬ࡦࡡࠪࣄ")+str(int(a8HLTkO2ns49yGNgiroS))[-J7divaGOCgq2SLfXpDzZYN58wc(u"࠴ॅ"):]+wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡥࠧࣅ")+cepLvEox93aUI+JGtX1fiayl9R
	MWQylDn3241c = RRydns1CErYlIhwSx7.path.join(nJj0g3Psa4kF,cepLvEox93aUI)
	bJ4IumHdZTPlG6 = {}
	bJ4IumHdZTPlG6[CKUiyEe28zsZ(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࣆ")] = eHdDoxhJCEPMZFVa2fg
	bJ4IumHdZTPlG6[w2vjZmdJuY7c(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣇ")] = f90fGrlSEObDsuiA3U(u"ࠨࠬ࠲࠮ࠬࣈ")
	Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace(ietolwsjpIPK7Fr(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡆࡢ࡮ࡶࡩࠬࣉ"),eHdDoxhJCEPMZFVa2fg)
	if Cp6c5tZe8I0PxnAW(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ࣊") in Nn360bq79W2kzUt:
		E1Viom5L3684CTOFJ,PPOaXI9Tr1fAD7luhFGYpKJ5q = Nn360bq79W2kzUt.rsplit(NxXMrsTC5FniYuRBOK8(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ࣋"),HkiMU0QrdzW3l6gwnT(u"࠲ॆ"))
		PPOaXI9Tr1fAD7luhFGYpKJ5q = PPOaXI9Tr1fAD7luhFGYpKJ5q.replace(Cp6c5tZe8I0PxnAW(u"ࠬࢂࠧ࣌"),eHdDoxhJCEPMZFVa2fg).replace(ilBWK5nXxg1do4jENGC07Zq(u"࠭ࠦࠨ࣍"),eHdDoxhJCEPMZFVa2fg)
	else: E1Viom5L3684CTOFJ,PPOaXI9Tr1fAD7luhFGYpKJ5q = Nn360bq79W2kzUt,None
	if not PPOaXI9Tr1fAD7luhFGYpKJ5q: PPOaXI9Tr1fAD7luhFGYpKJ5q = qq62QA8h3pGxzCwWVeXIF7glKf()
	if PPOaXI9Tr1fAD7luhFGYpKJ5q: bJ4IumHdZTPlG6[NxXMrsTC5FniYuRBOK8(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࣎")] = PPOaXI9Tr1fAD7luhFGYpKJ5q
	if ietolwsjpIPK7Fr(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࣏ࠪ") in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ,DfV0FjXSuriL6O1aM5hPZlQt8 = E1Viom5L3684CTOFJ.rsplit(eNEhtuoi9gK8JaTpIXj(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀ࣐ࠫ"),I5bUBGpPXn0W6(u"࠳े"))
	else: E1Viom5L3684CTOFJ,DfV0FjXSuriL6O1aM5hPZlQt8 = E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.strip(Cp6c5tZe8I0PxnAW(u"ࠪࢀ࣑ࠬ")).strip(KW5bYS20wTF1LyCs9(u"࣒ࠫࠫ࠭")).strip(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࢂ࣓ࠧ")).strip(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࠦࠨࣔ"))
	DfV0FjXSuriL6O1aM5hPZlQt8 = DfV0FjXSuriL6O1aM5hPZlQt8.replace(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡽࠩࣕ"),eHdDoxhJCEPMZFVa2fg).replace(S8i3sBYoHWdTURpAgN(u"ࠨࠨࠪࣖ"),eHdDoxhJCEPMZFVa2fg)
	if DfV0FjXSuriL6O1aM5hPZlQt8:	bJ4IumHdZTPlG6[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣗ")] = DfV0FjXSuriL6O1aM5hPZlQt8
	vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+ietolwsjpIPK7Fr(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫࣘ")+E1Viom5L3684CTOFJ+wY1p9mP03S8drbcH64t5WQkv(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧࣙ")+str(bJ4IumHdZTPlG6)+eNEhtuoi9gK8JaTpIXj(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬࣚ")+MWQylDn3241c+bP01xn84BiQN(u"࠭ࠠ࡞ࠩࣛ"))
	PRdz7Yfy1GOgBV98KDbt0SvUj = eNEhtuoi9gK8JaTpIXj(u"࠴࠴࠷࠺ै")*eNEhtuoi9gK8JaTpIXj(u"࠴࠴࠷࠺ै")
	O7whG9EXaZ = LyOR7f69iA(u"࠴ॉ")
	try:
		MuAO8aNdVZpnQUW4coTl =	ccwRLKk3hs0E.getInfoLabel(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣜ"))
		MuAO8aNdVZpnQUW4coTl = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠨ࡞ࡧ࠯ࠬࣝ"),MuAO8aNdVZpnQUW4coTl)
		O7whG9EXaZ = int(MuAO8aNdVZpnQUW4coTl[x1Oa8bBf36EwsLMirtFc])
	except: pass
	if not O7whG9EXaZ:
		try:
			TUNXVdxoPqe6Iikc48ju3BJvr = RRydns1CErYlIhwSx7.statvfs(nJj0g3Psa4kF)
			O7whG9EXaZ = TUNXVdxoPqe6Iikc48ju3BJvr.f_frsize*TUNXVdxoPqe6Iikc48ju3BJvr.f_bavail//PRdz7Yfy1GOgBV98KDbt0SvUj
		except: pass
	if not O7whG9EXaZ:
		try:
			TUNXVdxoPqe6Iikc48ju3BJvr = RRydns1CErYlIhwSx7.fstatvfs(nJj0g3Psa4kF)
			O7whG9EXaZ = TUNXVdxoPqe6Iikc48ju3BJvr.f_frsize*TUNXVdxoPqe6Iikc48ju3BJvr.f_bavail//PRdz7Yfy1GOgBV98KDbt0SvUj
		except: pass
	if not O7whG9EXaZ:
		try:
			import shutil as njHVSe1FTsq
			lgowIShzeXtTAD31dOaRKGy,sskP2M6lLjpcq0,p9meVMzuJfy1EhBlNtTr6nW = njHVSe1FTsq.disk_usage(nJj0g3Psa4kF)
			O7whG9EXaZ = p9meVMzuJfy1EhBlNtTr6nW//PRdz7Yfy1GOgBV98KDbt0SvUj
		except: pass
	if not O7whG9EXaZ:
		YTUtDCvHs6eQEPi1FJ(egY8Jti0smdLM3h1VQRSW(u"ࠩࡵ࡭࡬࡮ࡴࠨࣞ"),t3coAp06zvHrTl49bUVgx(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣟ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨ࣠"),Cp6c5tZe8I0PxnAW(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣡"))
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+HkiMU0QrdzW3l6gwnT(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧ࣢"))
		return rDceXBpHkfVUYRJ3tIx95Z
	if JGtX1fiayl9R==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࠯࡯࠶ࡹ࠽ࣣ࠭"):
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YY02fhEdJNI5cCpw1nUMj(E1Viom5L3684CTOFJ,bJ4IumHdZTPlG6)
		if len(FBITEXGDfe2mcCxnQs6ktMdy9HJh)==t3coAp06zvHrTl49bUVgx(u"࠵ॊ"):
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(ilBWK5nXxg1do4jENGC07Zq(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣤ"),eHdDoxhJCEPMZFVa2fg)
			return rDceXBpHkfVUYRJ3tIx95Z
		elif len(FBITEXGDfe2mcCxnQs6ktMdy9HJh)==RqLvTrID0yMVeClpYcnZ16i3X(u"࠷ो"): iLcCSnPyKYWs3xkQ0p14 = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠰ौ")
		elif len(FBITEXGDfe2mcCxnQs6ktMdy9HJh)>LyOR7f69iA(u"࠲्"):
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(I5bUBGpPXn0W6(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣥ"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14 == -t3coAp06zvHrTl49bUVgx(u"࠳ॎ") :
				dqKGMYgJxSF8Ub1kotlsP936Ww7B(Cp6c5tZe8I0PxnAW(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้ࣦ࠭"),eHdDoxhJCEPMZFVa2fg)
				return rDceXBpHkfVUYRJ3tIx95Z
		E1Viom5L3684CTOFJ = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F = eNEhtuoi9gK8JaTpIXj(u"࠳ॏ")
	import requests as sOGcCTIoQ85ARH6
	if JGtX1fiayl9R==KW5bYS20wTF1LyCs9(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࣧ"):
		MWQylDn3241c = MWQylDn3241c.rsplit(CKUiyEe28zsZ(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࣨ"))[x1Oa8bBf36EwsLMirtFc]+ehfEsaiJBSvbcULtNPVgykA2(u"࠭࠮࡮ࡲ࠷ࣩࠫ")
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,I5bUBGpPXn0W6(u"ࠧࡈࡇࡗࠫ࣪"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ࣫"))
		LLcdUC147PImyQDGe0jATWl = W1B5olYNHxq03IShy.content
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ࣬"),LLcdUC147PImyQDGe0jATWl+NxXMrsTC5FniYuRBOK8(u"ࠪࡠࡳࡢࡲࠨ࣭"),cBawilJXvK1m.DOTALL)
		if not JCZVK86QTYwX4mfgOrod:
			vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+Cp6c5tZe8I0PxnAW(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠ࣮ࠦࠧ")+E1Viom5L3684CTOFJ+eNEhtuoi9gK8JaTpIXj(u"ࠬࠦ࡝ࠨ࣯"))
			return rDceXBpHkfVUYRJ3tIx95Z
		apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[x1Oa8bBf36EwsLMirtFc]
		if not apOKrFbP9IYHDyUVm7.startswith(ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡨࡵࡶࡳࣰࠫ")):
			if apOKrFbP9IYHDyUVm7.startswith(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧ࠰࠱ࣱࠪ")): apOKrFbP9IYHDyUVm7 = E1Viom5L3684CTOFJ.split(egY8Jti0smdLM3h1VQRSW(u"ࠨ࠼ࣲࠪ"),XugxFprC26zGM(u"࠵ॐ"))[x1Oa8bBf36EwsLMirtFc]+KW5bYS20wTF1LyCs9(u"ࠩ࠽ࠫࣳ")+apOKrFbP9IYHDyUVm7
			elif apOKrFbP9IYHDyUVm7.startswith(Cp6c5tZe8I0PxnAW(u"ࠪ࠳ࠬࣴ")): apOKrFbP9IYHDyUVm7 = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,egY8Jti0smdLM3h1VQRSW(u"ࠫࡺࡸ࡬ࠨࣵ"))+apOKrFbP9IYHDyUVm7
			else: apOKrFbP9IYHDyUVm7 = E1Viom5L3684CTOFJ.rsplit(LyOR7f69iA(u"ࠬ࠵ࣶࠧ"),NxXMrsTC5FniYuRBOK8(u"࠶॑"))[x1Oa8bBf36EwsLMirtFc]+Cp6c5tZe8I0PxnAW(u"࠭࠯ࠨࣷ")+apOKrFbP9IYHDyUVm7
		W1B5olYNHxq03IShy = sOGcCTIoQ85ARH6.request(wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡈࡇࡗࠫࣸ"),apOKrFbP9IYHDyUVm7,headers=bJ4IumHdZTPlG6,verify=rDceXBpHkfVUYRJ3tIx95Z)
		Dk5mebsFhuy1v4GLqEwnYXId = W1B5olYNHxq03IShy.content
		GL89aUN1C04BQKgrYeulp6q53wotM = len(Dk5mebsFhuy1v4GLqEwnYXId)
		c5gG4NyMTUzL = len(JCZVK86QTYwX4mfgOrod)
		RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F = GL89aUN1C04BQKgrYeulp6q53wotM*c5gG4NyMTUzL
	else:
		GL89aUN1C04BQKgrYeulp6q53wotM = jUcmHhgVvW0EdYOIfXeaDF(u"࠷॒")*PRdz7Yfy1GOgBV98KDbt0SvUj
		W1B5olYNHxq03IShy = sOGcCTIoQ85ARH6.request(NxXMrsTC5FniYuRBOK8(u"ࠨࡉࡈࡘࣹࠬ"),E1Viom5L3684CTOFJ,headers=bJ4IumHdZTPlG6,verify=rDceXBpHkfVUYRJ3tIx95Z,stream=YchIv6N09BaWPEj4tieAnluKZrRXT)
		if jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࣺࠪ") in W1B5olYNHxq03IShy.headers: RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F = int(W1B5olYNHxq03IShy.headers[KW5bYS20wTF1LyCs9(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣻ")])
		c5gG4NyMTUzL = int(RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F//GL89aUN1C04BQKgrYeulp6q53wotM)
	ylMUSErbOBa = int(RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F//PRdz7Yfy1GOgBV98KDbt0SvUj)+ehfEsaiJBSvbcULtNPVgykA2(u"࠱॓")
	if RYIc1Du5dKOoTlQ9jnk0GZJqptgH2F<LyOR7f69iA(u"࠳࠳࠳࠴࠵॔"):
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+KQ3sCe9Pzh(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣼ")+E1Viom5L3684CTOFJ+ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(ylMUSErbOBa)+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(O7whG9EXaZ)+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣿ")+MWQylDn3241c+EX25Y0l8ILvz7QcRC(u"ࠨࠢࡠࠫऀ"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬँ"),LyOR7f69iA(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬं"))
		return rDceXBpHkfVUYRJ3tIx95Z
	TzVtRnXF7oC3 = XugxFprC26zGM(u"࠶࠳࠴ॕ")
	LmozIOrc17lWypeRhiu0PBd6v5sjS = O7whG9EXaZ-ylMUSErbOBa
	if LmozIOrc17lWypeRhiu0PBd6v5sjS<TzVtRnXF7oC3:
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪः")+E1Viom5L3684CTOFJ+jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩऄ")+str(ylMUSErbOBa)+ilBWK5nXxg1do4jENGC07Zq(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬअ")+str(O7whG9EXaZ)+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧआ")+str(TzVtRnXF7oC3)+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫइ")+MWQylDn3241c+ietolwsjpIPK7Fr(u"ࠩࠣࡡࠬई"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪउ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪऊ")+str(ylMUSErbOBa)+ietolwsjpIPK7Fr(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऋ")+str(O7whG9EXaZ)+ietolwsjpIPK7Fr(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ऌ")+str(TzVtRnXF7oC3)+CKUiyEe28zsZ(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩऍ"))
		return rDceXBpHkfVUYRJ3tIx95Z
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(CKUiyEe28zsZ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऎ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪए"),ietolwsjpIPK7Fr(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩऐ")+str(ylMUSErbOBa)+KW5bYS20wTF1LyCs9(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऑ")+str(O7whG9EXaZ)+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऒ"))
	if zf7iFX1auw0bQU!=QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠴ॖ"):
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫओ"))
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+ilBWK5nXxg1do4jENGC07Zq(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऔ")+E1Viom5L3684CTOFJ+ietolwsjpIPK7Fr(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨक")+MWQylDn3241c+w2vjZmdJuY7c(u"ࠩࠣࡡࠬख"))
		return rDceXBpHkfVUYRJ3tIx95Z
	vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+EX25Y0l8ILvz7QcRC(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨग"))
	nNHfB2iT893EUZtSd = R62V7GXNPvf8()
	nNHfB2iT893EUZtSd.create(MWQylDn3241c,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬघ"))
	DnmAvoS3EQPXFlRza4erwWfVg = YchIv6N09BaWPEj4tieAnluKZrRXT
	B0ZiepTkgjAq8lWxCKyX1 = b8bLFaejUB.time()
	if WHjh1POtMKlmgiy68RSqb: zzPjQDgvuq = open(MWQylDn3241c,t3coAp06zvHrTl49bUVgx(u"ࠬࡽࡢࠨङ"))
	else: zzPjQDgvuq = open(MWQylDn3241c.decode(m6PFtLblInpNZ8x),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡷࡣࠩच"))
	if JGtX1fiayl9R==J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠯࡯࠶ࡹ࠽࠭छ"):
		for gMmB3iopS0ZXrOFewhcxt in range(ilBWK5nXxg1do4jENGC07Zq(u"࠵ॗ"),c5gG4NyMTUzL+ilBWK5nXxg1do4jENGC07Zq(u"࠵ॗ")):
			apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[gMmB3iopS0ZXrOFewhcxt-ietolwsjpIPK7Fr(u"࠶क़")]
			if not apOKrFbP9IYHDyUVm7.startswith(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡪࡷࡸࡵ࠭ज")):
				if apOKrFbP9IYHDyUVm7.startswith(EX25Y0l8ILvz7QcRC(u"ࠩ࠲࠳ࠬझ")): apOKrFbP9IYHDyUVm7 = E1Viom5L3684CTOFJ.split(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪ࠾ࠬञ"),S8i3sBYoHWdTURpAgN(u"࠷ख़"))[x1Oa8bBf36EwsLMirtFc]+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫ࠿࠭ट")+apOKrFbP9IYHDyUVm7
				elif apOKrFbP9IYHDyUVm7.startswith(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࠵ࠧठ")): apOKrFbP9IYHDyUVm7 = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,ietolwsjpIPK7Fr(u"࠭ࡵࡳ࡮ࠪड"))+apOKrFbP9IYHDyUVm7
				else: apOKrFbP9IYHDyUVm7 = E1Viom5L3684CTOFJ.rsplit(KW5bYS20wTF1LyCs9(u"ࠧ࠰ࠩढ"),XugxFprC26zGM(u"࠱ग़"))[x1Oa8bBf36EwsLMirtFc]+wY1p9mP03S8drbcH64t5WQkv(u"ࠨ࠱ࠪण")+apOKrFbP9IYHDyUVm7
			W1B5olYNHxq03IShy = sOGcCTIoQ85ARH6.request(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡊࡉ࡙࠭त"),apOKrFbP9IYHDyUVm7,headers=bJ4IumHdZTPlG6,verify=rDceXBpHkfVUYRJ3tIx95Z)
			Dk5mebsFhuy1v4GLqEwnYXId = W1B5olYNHxq03IShy.content
			W1B5olYNHxq03IShy.close()
			zzPjQDgvuq.write(Dk5mebsFhuy1v4GLqEwnYXId)
			ihnG1xOrTuDwRmQKVMAkb3ELZq = b8bLFaejUB.time()
			KkNefIE37M6sr2AX0xaG519qPwd = ihnG1xOrTuDwRmQKVMAkb3ELZq-B0ZiepTkgjAq8lWxCKyX1
			BBueaqDrHw4XQFUl8yg0fvxoNV2KpY = KkNefIE37M6sr2AX0xaG519qPwd//gMmB3iopS0ZXrOFewhcxt
			aaxO3gpKjqhP4RskQEAVSWb59H = BBueaqDrHw4XQFUl8yg0fvxoNV2KpY*(c5gG4NyMTUzL+Cp6c5tZe8I0PxnAW(u"࠲ज़"))
			bnY9owjPS8uKaOBDvAG = aaxO3gpKjqhP4RskQEAVSWb59H-KkNefIE37M6sr2AX0xaG519qPwd
			evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,int(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠴࠴࠵ढ़")*gMmB3iopS0ZXrOFewhcxt//(c5gG4NyMTUzL+t3coAp06zvHrTl49bUVgx(u"࠳ड़"))),LTN6DPEmrwehtZMy(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫथ"),egY8Jti0smdLM3h1VQRSW(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫद"),str(gMmB3iopS0ZXrOFewhcxt*GL89aUN1C04BQKgrYeulp6q53wotM//PRdz7Yfy1GOgBV98KDbt0SvUj)+ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ࠵ࠧध")+str(ylMUSErbOBa)+ilBWK5nXxg1do4jENGC07Zq(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫन")+b8bLFaejUB.strftime(KQ3sCe9Pzh(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤऩ"),b8bLFaejUB.gmtime(bnY9owjPS8uKaOBDvAG))+LTN6DPEmrwehtZMy(u"ࠨࠢใࠫप"))
			if nNHfB2iT893EUZtSd.iscanceled():
				DnmAvoS3EQPXFlRza4erwWfVg = rDceXBpHkfVUYRJ3tIx95Z
				break
	else:
		gMmB3iopS0ZXrOFewhcxt = eNEhtuoi9gK8JaTpIXj(u"࠴फ़")
		for Dk5mebsFhuy1v4GLqEwnYXId in W1B5olYNHxq03IShy.iter_content(chunk_size=GL89aUN1C04BQKgrYeulp6q53wotM):
			zzPjQDgvuq.write(Dk5mebsFhuy1v4GLqEwnYXId)
			gMmB3iopS0ZXrOFewhcxt = gMmB3iopS0ZXrOFewhcxt+I5bUBGpPXn0W6(u"࠶य़")
			ihnG1xOrTuDwRmQKVMAkb3ELZq = b8bLFaejUB.time()
			KkNefIE37M6sr2AX0xaG519qPwd = ihnG1xOrTuDwRmQKVMAkb3ELZq-B0ZiepTkgjAq8lWxCKyX1
			BBueaqDrHw4XQFUl8yg0fvxoNV2KpY = KkNefIE37M6sr2AX0xaG519qPwd/gMmB3iopS0ZXrOFewhcxt
			aaxO3gpKjqhP4RskQEAVSWb59H = BBueaqDrHw4XQFUl8yg0fvxoNV2KpY*(c5gG4NyMTUzL+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷ॠ"))
			bnY9owjPS8uKaOBDvAG = aaxO3gpKjqhP4RskQEAVSWb59H-KkNefIE37M6sr2AX0xaG519qPwd
			evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,int(CKUiyEe28zsZ(u"࠲࠲࠳ॢ")*gMmB3iopS0ZXrOFewhcxt/(c5gG4NyMTUzL+J7divaGOCgq2SLfXpDzZYN58wc(u"࠱ॡ"))),t3coAp06zvHrTl49bUVgx(u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪफ"),HkiMU0QrdzW3l6gwnT(u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪब"),str(gMmB3iopS0ZXrOFewhcxt*GL89aUN1C04BQKgrYeulp6q53wotM//PRdz7Yfy1GOgBV98KDbt0SvUj)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࠴࠭भ")+str(ylMUSErbOBa)+Cp6c5tZe8I0PxnAW(u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪम")+b8bLFaejUB.strftime(CKUiyEe28zsZ(u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣय"),b8bLFaejUB.gmtime(bnY9owjPS8uKaOBDvAG))+t3coAp06zvHrTl49bUVgx(u"ࠧࠡโࠪर"))
			if nNHfB2iT893EUZtSd.iscanceled():
				DnmAvoS3EQPXFlRza4erwWfVg = rDceXBpHkfVUYRJ3tIx95Z
				break
		W1B5olYNHxq03IShy.close()
	zzPjQDgvuq.close()
	nNHfB2iT893EUZtSd.close()
	if not DnmAvoS3EQPXFlRza4erwWfVg:
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+EX25Y0l8ILvz7QcRC(u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬऱ")+E1Viom5L3684CTOFJ+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+MWQylDn3241c+jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠤࡢ࠭ळ"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩऴ"))
		return YchIv6N09BaWPEj4tieAnluKZrRXT
	vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+EX25Y0l8ILvz7QcRC(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫव")+E1Viom5L3684CTOFJ+TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭श")+MWQylDn3241c+NxXMrsTC5FniYuRBOK8(u"ࠧࠡ࡟ࠪष"))
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠨฬ่ࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡส้ะฬำࠧस"))
	return YchIv6N09BaWPEj4tieAnluKZrRXT
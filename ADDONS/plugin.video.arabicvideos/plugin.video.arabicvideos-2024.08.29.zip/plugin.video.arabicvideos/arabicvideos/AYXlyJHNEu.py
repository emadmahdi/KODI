# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'AHWAK'
r07r9xeEFASJXluImT = '_AHK_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الصفحة الرئيسية','Sign in']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==610: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==611: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==612: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==613: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = E6cwy5XKiUpCzGP(url,text)
	elif mode==614: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==619: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,619,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',q3QVhZaDEuo8t2ASj5vkn,611,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المسلسلات المميزة',q3QVhZaDEuo8t2ASj5vkn,611,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured_series')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('/category.php">(.*?)"navslide-divider"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("'dropdown-menu'(.*?)</ul>",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for KUTgdRBshwIZcbuv0LVC4 in RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace(KUTgdRBshwIZcbuv0LVC4,eHdDoxhJCEPMZFVa2fg)
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if title in IVD2kBKhW8FeQLvxUm: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,614)
	return
def VrWsaTmY2qZ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"caret"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('"presentation"','</ul>')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = [(eHdDoxhJCEPMZFVa2fg,cOUiow273ytu1GC5N0FJh)]
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		for NdupeIwhrAZ0kxW7ER,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if NdupeIwhrAZ0kxW7ER: NdupeIwhrAZ0kxW7ER = NdupeIwhrAZ0kxW7ER+': '
			for apOKrFbP9IYHDyUVm7,title in items:
				title = NdupeIwhrAZ0kxW7ER+title
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,611)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"pm-category-subcats"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if len(items)<30:
			qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
			for apOKrFbP9IYHDyUVm7,title in items:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,611)
	if not w69FNzXjsWm and not eFUZtGJawsxyA42SRXl8fkBrnjo: zRK9ruIt0ZFV4bgi(url)
	return
def zRK9ruIt0ZFV4bgi(url,mzfT1LoKkCy7g9wuSqV=eHdDoxhJCEPMZFVa2fg):
	if mzfT1LoKkCy7g9wuSqV=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-TITLES-1st')
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-TITLES-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	cOUiow273ytu1GC5N0FJh,items = eHdDoxhJCEPMZFVa2fg,[]
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	if mzfT1LoKkCy7g9wuSqV=='ajax-search':
		cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ: items.append((eHdDoxhJCEPMZFVa2fg,apOKrFbP9IYHDyUVm7,title))
	elif mzfT1LoKkCy7g9wuSqV=='featured':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pm-video-watch-featured"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif mzfT1LoKkCy7g9wuSqV=='new_episodes':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"row pm-ul-browse-videos(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif mzfT1LoKkCy7g9wuSqV=='new_movies':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"row pm-ul-browse-videos(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if len(RRztfCIs16MGxEHLJ25vDNAa7hpWT)>1: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[1]
	elif mzfT1LoKkCy7g9wuSqV=='featured_series':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ: items.append((eHdDoxhJCEPMZFVa2fg,apOKrFbP9IYHDyUVm7,title))
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(data-echo=".*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if cOUiow273ytu1GC5N0FJh and not items: items = cBawilJXvK1m.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if not items: return
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|حلقة).\d+',title,cBawilJXvK1m.DOTALL)
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,612,PeLqCN5Ek8bB)
		elif mzfT1LoKkCy7g9wuSqV=='new_episodes':
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,612,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0][0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,613,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,613,PeLqCN5Ek8bB)
	if 1:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7=='#': continue
				apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,611)
	return
def E6cwy5XKiUpCzGP(url,o2o6QJMUYDfXOvy1sIPetg):
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-EPISODES-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	e3XtKs70ifmRQY8VTLnpMdyr6 = cBawilJXvK1m.findall('preview_image_url: "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if e3XtKs70ifmRQY8VTLnpMdyr6: PeLqCN5Ek8bB = e3XtKs70ifmRQY8VTLnpMdyr6[0]
	else: PeLqCN5Ek8bB = eHdDoxhJCEPMZFVa2fg
	items = []
	lcquURp9SBMDz = False
	if w69FNzXjsWm and not o2o6QJMUYDfXOvy1sIPetg:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for o2o6QJMUYDfXOvy1sIPetg,title in items:
			o2o6QJMUYDfXOvy1sIPetg = o2o6QJMUYDfXOvy1sIPetg.strip('#')
			if len(items)>1: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,613,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,o2o6QJMUYDfXOvy1sIPetg)
			else: lcquURp9SBMDz = True
	else: lcquURp9SBMDz = True
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('id="'+o2o6QJMUYDfXOvy1sIPetg+'"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo and lcquURp9SBMDz:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('''title=["'](.*?)["'].*?href=['"](.*?)['"]''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		items = []
		for title,apOKrFbP9IYHDyUVm7 in bLPGQ21sY8ie0fZ: items.append((apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB))
		if not items: items = cBawilJXvK1m.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in items:
			apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
			title = title.replace('</em><span>',avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,612,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	wROf6m4Ix73jtsdnZ1vpCDuV,QT4iU37M8FpR26qhBXlVOSwrxzLv = [],[]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'post=' in nR2B1Wye7luXb5:
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('id="player".*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
		V5VgYoCK6sT = apOKrFbP9IYHDyUVm7.split('post=')[1]
		V5VgYoCK6sT = HHP76VFiKDS2xphlGsqN48j1.b64decode(V5VgYoCK6sT)
		if WHjh1POtMKlmgiy68RSqb: V5VgYoCK6sT = V5VgYoCK6sT.decode(m6PFtLblInpNZ8x)
		V5VgYoCK6sT = DIpuHqsKGS3ErJvk9taCRiX80('dict',V5VgYoCK6sT)
		JCZVK86QTYwX4mfgOrod = V5VgYoCK6sT['servers']
		RnjhvEwkQqYtb94WpBxX5P = list(JCZVK86QTYwX4mfgOrod.keys())
		JCZVK86QTYwX4mfgOrod = list(JCZVK86QTYwX4mfgOrod.values())
		FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = zip(RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod)
		for title,apOKrFbP9IYHDyUVm7 in FbL9lHaTVANMPd7hDJcw2o8QEX1mqu:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	else:
		E1Viom5L3684CTOFJ = url.replace('watch.php','see.php')
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AHWAK-PLAY2-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('<iframe src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
			if apOKrFbP9IYHDyUVm7 not in QT4iU37M8FpR26qhBXlVOSwrxzLv:
				QT4iU37M8FpR26qhBXlVOSwrxzLv.append(apOKrFbP9IYHDyUVm7)
				GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__embed'
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"WatchList"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7 not in QT4iU37M8FpR26qhBXlVOSwrxzLv:
					QT4iU37M8FpR26qhBXlVOSwrxzLv.append(apOKrFbP9IYHDyUVm7)
					GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
					apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__watch'
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
		if 'pm-download' not in nR2B1Wye7luXb5:
			E1Viom5L3684CTOFJ = url.replace('watch.php','downloads.php')
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,False,'AHWAK-PLAY-2nd')
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('pm-download(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('download-url="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7 not in QT4iU37M8FpR26qhBXlVOSwrxzLv:
					QT4iU37M8FpR26qhBXlVOSwrxzLv.append(apOKrFbP9IYHDyUVm7)
					GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
					apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__download'
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search.php?keywords='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'CIMALIGHT'
r07r9xeEFASJXluImT = '_CML_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['قنوات فضائية']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==470: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==471: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==472: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==473: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = E6cwy5XKiUpCzGP(url,text)
	elif mode==474: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==479: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = cBawilJXvK1m.findall('"url": "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	rPxSTcgYVul1sqkwtD8HC62vZ4 = rPxSTcgYVul1sqkwtD8HC62vZ4[0].strip('/')
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(rPxSTcgYVul1sqkwtD8HC62vZ4,'url')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,479,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"content"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		title = title.replace(KwJyZLDzC4FbHhXgTfI,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('cat=online-movies1','cat=online-movies')
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,474)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('/category.php">(.*?)"navslide-divider"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("'dropdown-menu'(.*?)</ul>",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if title in IVD2kBKhW8FeQLvxUm: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,474)
	return
def VrWsaTmY2qZ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'topvideos.php' in url: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"caret"(.*?)id="pm-grid"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"caret"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if 'topvideos.php' in apOKrFbP9IYHDyUVm7:
				if 'topvideos.php?c=english-movies' in apOKrFbP9IYHDyUVm7: continue
				if 'topvideos.php?c=online-movies1' in apOKrFbP9IYHDyUVm7: continue
				if 'topvideos.php?c=misc' in apOKrFbP9IYHDyUVm7: continue
				if 'topvideos.php?c=tv-channel' in apOKrFbP9IYHDyUVm7: continue
				if 'منذ البداية' in title and 'do=rating' not in apOKrFbP9IYHDyUVm7: continue
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,471)
	else: zRK9ruIt0ZFV4bgi(url)
	return
def zRK9ruIt0ZFV4bgi(url,mzfT1LoKkCy7g9wuSqV=eHdDoxhJCEPMZFVa2fg):
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = []
	if mzfT1LoKkCy7g9wuSqV=='featured_movies':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"container-fluid"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		JCZVK86QTYwX4mfgOrod,RnjhvEwkQqYtb94WpBxX5P,ekhBKa2J3UqG = zip(*items)
		items = zip(ekhBKa2J3UqG,JCZVK86QTYwX4mfgOrod,RnjhvEwkQqYtb94WpBxX5P)
	elif mzfT1LoKkCy7g9wuSqV=='featured_series':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('المسلسلات المميزة(.*?)<style>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		JCZVK86QTYwX4mfgOrod,RnjhvEwkQqYtb94WpBxX5P,ekhBKa2J3UqG = zip(*items)
		items = zip(ekhBKa2J3UqG,JCZVK86QTYwX4mfgOrod,RnjhvEwkQqYtb94WpBxX5P)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(data-echo=".*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"BlocksList"(.*?)"titleSectionCon"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="pm-grid"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="pm-related"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('pm-ul-browse-videos(.*?)clearfix',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if not items: items = cBawilJXvK1m.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if not items: items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7).strip('/')
		title = title.replace('ماي سيما',eHdDoxhJCEPMZFVa2fg).replace('مشاهدة',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
		if 'http' not in PeLqCN5Ek8bB: PeLqCN5Ek8bB = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+PeLqCN5Ek8bB.strip('/')
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|حلقة) \d+',title,cBawilJXvK1m.DOTALL)
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			title = '_MOD_'+title
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,472,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and 'حلقة' in title:
			title = '_MOD_'+vQ2LDF3UyXZbhu97Y[0][0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,473,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		elif '/movseries/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,471,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,473,PeLqCN5Ek8bB)
	if mzfT1LoKkCy7g9wuSqV not in ['featured_movies','featured_series']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7=='#': continue
				apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,471)
		YMGNw4kjgz28HobiIl7qcafd65K = cBawilJXvK1m.findall('showmore" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if YMGNw4kjgz28HobiIl7qcafd65K:
			apOKrFbP9IYHDyUVm7 = YMGNw4kjgz28HobiIl7qcafd65K[0]
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مشاهدة المزيد',apOKrFbP9IYHDyUVm7,471)
	return
def E6cwy5XKiUpCzGP(url,o2o6QJMUYDfXOvy1sIPetg):
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-EPISODES-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"SeasonsBox"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	items = []
	if w69FNzXjsWm and not o2o6QJMUYDfXOvy1sIPetg:
		PeLqCN5Ek8bB = cBawilJXvK1m.findall('"series-header".*?src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		PeLqCN5Ek8bB = PeLqCN5Ek8bB[0] if PeLqCN5Ek8bB else eHdDoxhJCEPMZFVa2fg
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if len(items)==1: o2o6QJMUYDfXOvy1sIPetg = items[0][0]
		elif len(items)>1:
			for o2o6QJMUYDfXOvy1sIPetg,title in items: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,473,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,o2o6QJMUYDfXOvy1sIPetg)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('id="'+o2o6QJMUYDfXOvy1sIPetg+'"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo and len(items)<2:
		PeLqCN5Ek8bB = cBawilJXvK1m.findall('"series-header".*?src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		PeLqCN5Ek8bB = PeLqCN5Ek8bB[0] if PeLqCN5Ek8bB else eHdDoxhJCEPMZFVa2fg
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for apOKrFbP9IYHDyUVm7,title in items:
				title = title.replace('ماي سيما',eHdDoxhJCEPMZFVa2fg).replace('مسلسل',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,472,PeLqCN5Ek8bB)
		else:
			items = cBawilJXvK1m.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in items:
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/'+apOKrFbP9IYHDyUVm7.strip('/')
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,472,PeLqCN5Ek8bB)
	if 'id="pm-related"' in nR2B1Wye7luXb5:
		if items: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مواضيع ذات صلة',url,471)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<div itemprop="description">(.*?)href=',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		i2qmOCHN5goZ = cBawilJXvK1m.findall('<p>(.*?)</p>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ,True): return
	E1Viom5L3684CTOFJ = url.replace('/watch.php','/play.php')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-PLAY-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	tErBdv0hYZuC5FJ = []
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('"embedURL" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
		if apOKrFbP9IYHDyUVm7 and apOKrFbP9IYHDyUVm7 not in tErBdv0hYZuC5FJ:
			tErBdv0hYZuC5FJ.append(apOKrFbP9IYHDyUVm7)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named=__embed'
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	items = cBawilJXvK1m.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if apOKrFbP9IYHDyUVm7 not in tErBdv0hYZuC5FJ:
			tErBdv0hYZuC5FJ.append(apOKrFbP9IYHDyUVm7)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	E1Viom5L3684CTOFJ = url.replace('/watch.php','/downloads.php')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMALIGHT-PLAY-3rd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"downloadlist"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<strong>(.*?)</strong>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if apOKrFbP9IYHDyUVm7 not in tErBdv0hYZuC5FJ:
				tErBdv0hYZuC5FJ.append(apOKrFbP9IYHDyUVm7)
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download'
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(q3QVhZaDEuo8t2ASj5vkn,'url')
	url = GfhcsvCWIon+'/search.php?keywords='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'CIMAFANS'
headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
r07r9xeEFASJXluImT = '_CMF_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==90: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==91: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4(url)
	elif mode==92: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==94: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Cynto6K3SVucskU()
	elif mode==95: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==99: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,99,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المضاف حديثا',eHdDoxhJCEPMZFVa2fg,94)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الأحدث',q3QVhZaDEuo8t2ASj5vkn+'/?type=latest',91)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الأعلى تقيماً',q3QVhZaDEuo8t2ASj5vkn+'/?type=imdb',91)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الأكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn+'/?type=view',91)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المثبت',q3QVhZaDEuo8t2ASj5vkn+'/?type=pin',91)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'جديد الأفلام',q3QVhZaDEuo8t2ASj5vkn+'/?type=newMovies',91)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'جديد الحلقات',q3QVhZaDEuo8t2ASj5vkn+'/?type=newEpisodes',91)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="mainmenu(.*?)nav',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('<li><a href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	IVD2kBKhW8FeQLvxUm = ['افلام للكبار فقط']
	for apOKrFbP9IYHDyUVm7,title in items:
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,91)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="f-cats"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('<li><a href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,91)
	return nR2B1Wye7luXb5
def EGoutUTNgihIRDYqyAn798cS4(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-ITEMS-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	else:
		headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-ITEMS-2nd')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="movies-items(.*?)class="listfoot"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	else: cOUiow273ytu1GC5N0FJh = eHdDoxhJCEPMZFVa2fg
	items = cBawilJXvK1m.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة [0-9]+',title,cBawilJXvK1m.DOTALL)
			if vQ2LDF3UyXZbhu97Y:
				title = '_MOD_'+vQ2LDF3UyXZbhu97Y[0]
				if title not in adU3exogvimBLnCQOwz:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,95,PeLqCN5Ek8bB)
					adU3exogvimBLnCQOwz.append(title)
		elif '/video/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,92,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,91,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="pagination(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('<a href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = zJRbA1YW2Eor(title)
			title = title.replace('الصفحة ',eHdDoxhJCEPMZFVa2fg)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,91)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-EPISODES-1st')
	PeLqCN5Ek8bB = cBawilJXvK1m.findall('img src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	PeLqCN5Ek8bB = PeLqCN5Ek8bB[0]
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="episodes-panel(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		name = cBawilJXvK1m.findall('itemprop="title">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if name: name = name[1]
		else:
			name = ccwRLKk3hs0E.getInfoLabel('ListItem.Label')
			if Nat0Dx9puRUWCsgz6JyFhY3 in name: name = name.split(Nat0Dx9puRUWCsgz6JyFhY3,1)[1]
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?name">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+name+' - '+title,apOKrFbP9IYHDyUVm7,92,PeLqCN5Ek8bB)
	else:
		hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('class="movietitle"><a href="(.*?)">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if hPYnfjbqWDJNSAeyQaBrOZt68: apOKrFbP9IYHDyUVm7,title = hPYnfjbqWDJNSAeyQaBrOZt68[0]
		else: apOKrFbP9IYHDyUVm7,title = url,name
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,92,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW,j54hMaE2YWq = [],[]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-PLAY-1st')
	i2qmOCHN5goZ = cBawilJXvK1m.findall('text-shadow: none;">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="links-panel(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?__download'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('nav-tabs"(.*?)video-panel-more',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('id="(.*?)".*?embed src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,apOKrFbP9IYHDyUVm7 in items:
			title = 'سيرفر '+id
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		items = cBawilJXvK1m.findall('data-server-src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in items:
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
			apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def Cynto6K3SVucskU():
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'CIMAFANS-LATEST-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="index-last-movie(.*?)id="index-slider-movie',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if '/video/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,92,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,91,PeLqCN5Ek8bB)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn + '/search.php?t='+search
	EGoutUTNgihIRDYqyAn798cS4(url)
	return
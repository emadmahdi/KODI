# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
EERWJf1adv67 = 'AKWAM'
r07r9xeEFASJXluImT = '_AKW_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
Ti7F3zGSreCdhHauWt = eHdDoxhJCEPMZFVa2fg
IVD2kBKhW8FeQLvxUm = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==240: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==241: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==242: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==243: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==244: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'FILTERS___'+text)
	elif mode==245: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'CATEGORIES___'+text)
	elif mode==246: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = meWNbQYZdH9yJ4l7GP(url)
	elif mode==247: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = vvZ45Q8rREiJITyekbdP0(url)
	elif mode==248: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = m7oRkJHW9A5XlTCraMiF4pnLBw()
	elif mode==249: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def m7oRkJHW9A5XlTCraMiF4pnLBw():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AKWAM-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	dATLVpQC3bjer5v9R8kixhg = cBawilJXvK1m.findall('home-site-btn-container.*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if dATLVpQC3bjer5v9R8kixhg: dATLVpQC3bjer5v9R8kixhg = dATLVpQC3bjer5v9R8kixhg[0]
	else: dATLVpQC3bjer5v9R8kixhg = q3QVhZaDEuo8t2ASj5vkn
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',dATLVpQC3bjer5v9R8kixhg,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'AKWAM-MENU-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,249,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر محدد',q3QVhZaDEuo8t2ASj5vkn,246)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر كامل',q3QVhZaDEuo8t2ASj5vkn,247)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',dATLVpQC3bjer5v9R8kixhg,241,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	recent = cBawilJXvK1m.findall('recently-container.*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	apOKrFbP9IYHDyUVm7 = recent[0]
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أضيف حديثا',apOKrFbP9IYHDyUVm7,241)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,name,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		if name in IVD2kBKhW8FeQLvxUm: continue
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,241)
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title in IVD2kBKhW8FeQLvxUm: continue
			title = name+avcfIls8w7gk69hYUErHxzQTXtm24j+title
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,241)
	return
def meWNbQYZdH9yJ4l7GP(website=eHdDoxhJCEPMZFVa2fg):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'AKWAM-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="menu(.*?)<nav',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?text">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title not in IVD2kBKhW8FeQLvxUm:
				title = title+' مصنفة'
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,245)
		if website==eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	return nR2B1Wye7luXb5
def vvZ45Q8rREiJITyekbdP0(website=eHdDoxhJCEPMZFVa2fg):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'AKWAM-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="menu(.*?)<nav',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?text">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title not in IVD2kBKhW8FeQLvxUm:
				title = title+' مفلترة'
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,244)
		if website==eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('swiper-container(.*?)swiper-button-prev',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="widget"(.*?)main-footer',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if not items:
			items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
			if '/series/' in apOKrFbP9IYHDyUVm7 or '/shows/' in apOKrFbP9IYHDyUVm7:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,242,PeLqCN5Ek8bB)
			elif '/movies/' in apOKrFbP9IYHDyUVm7:
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,243,PeLqCN5Ek8bB)
			elif '/games/' not in apOKrFbP9IYHDyUVm7:
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,243,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('pagination(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			apOKrFbP9IYHDyUVm7 = zJRbA1YW2Eor(apOKrFbP9IYHDyUVm7)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,241)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	url = q3QVhZaDEuo8t2ASj5vkn + '/search?q='+diojk6J5vzuRNDKmw
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in nR2B1Wye7luXb5:
		PeLqCN5Ek8bB = ccwRLKk3hs0E.getInfoLabel('ListItem.Icon')
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+'رابط التشغيل',url,243,PeLqCN5Ek8bB)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('-episodes">(.*?)<div class="widget-4',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		Tfo9biLauWAQBSXw3GmeqkV = cBawilJXvK1m.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in Tfo9biLauWAQBSXw3GmeqkV:
			title = title.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,242,PeLqCN5Ek8bB)
			else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,243,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKWAM-PLAY-1st')
	i2qmOCHN5goZ = cBawilJXvK1m.findall('badge-danger.*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	qcWnziRSuQpBdX50DsMV1lH7htvUmb = cBawilJXvK1m.findall('li><a href="#(.*?)".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ekNMoIJzswUSDVQf564,U3RhqmxAl6wyknci9pa = [],[],[],[]
	if qcWnziRSuQpBdX50DsMV1lH7htvUmb:
		N63IHpMe8P = 'mp4'
		for jtvkg7nKcpCuofIG2E8ybd5zrL4x,s0s2bIZtWx8w3 in qcWnziRSuQpBdX50DsMV1lH7htvUmb:
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('tab-content quality" id="'+jtvkg7nKcpCuofIG2E8ybd5zrL4x+'".*?</div>.\s*</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			ekNMoIJzswUSDVQf564.append(cOUiow273ytu1GC5N0FJh)
			U3RhqmxAl6wyknci9pa.append(s0s2bIZtWx8w3)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="qualities(.*?)<h3.*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			cOUiow273ytu1GC5N0FJh,filename = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			AiUEhB3wfpcvbQzDO = ['zip','rar','txt','pdf','htm','tar','iso','html']
			N63IHpMe8P = filename.rsplit('.',1)[1].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if N63IHpMe8P in AiUEhB3wfpcvbQzDO:
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		ekNMoIJzswUSDVQf564.append(cOUiow273ytu1GC5N0FJh)
		U3RhqmxAl6wyknci9pa.append(eHdDoxhJCEPMZFVa2fg)
	for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(ekNMoIJzswUSDVQf564)):
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('href="(.*?)".*?icon-(.*?)"',ekNMoIJzswUSDVQf564[dhcGSyo8Kn1mHZwvEAkzJ7NUq],cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,bh4u12N3lif0ZQgCyX9ndYSv78 in JCZVK86QTYwX4mfgOrod:
			if 'torrent' in bh4u12N3lif0ZQgCyX9ndYSv78: continue
			elif 'download' in bh4u12N3lif0ZQgCyX9ndYSv78: type = 'download'
			elif 'play' in bh4u12N3lif0ZQgCyX9ndYSv78: type = 'watch'
			else: type = 'unknown'
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named=__'+type+'____'+U3RhqmxAl6wyknci9pa[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'__akwam'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def bbkDE5p9zlX6aV(url,filter):
	o7Dz5MbRWPmEeLVpiJ = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==eHdDoxhJCEPMZFVa2fg: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	else: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = filter.split('___')
	if type=='CATEGORIES':
		if o7Dz5MbRWPmEeLVpiJ[0]+'=' not in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = o7Dz5MbRWPmEeLVpiJ[0]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(o7Dz5MbRWPmEeLVpiJ[0:-1])):
			if o7Dz5MbRWPmEeLVpiJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'=' in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = o7Dz5MbRWPmEeLVpiJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq+1]
		aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+U3d2hkuwDIj56+'=0'
		e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+U3d2hkuwDIj56+'=0'
		r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7.strip('&')+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM.strip('&')
		jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'all')
		E1Viom5L3684CTOFJ = url+'?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	elif type=='FILTERS':
		aSF3HMlugcs9G7Yz = QRKwbZae0G3m(goUS2aiGbZX1OQ,'modified_values')
		aSF3HMlugcs9G7Yz = zrHeZWCqQMOymk1d7anKpu0vEx8(aSF3HMlugcs9G7Yz)
		if JVw3Ug6xQykdj2oM50!=eHdDoxhJCEPMZFVa2fg: JVw3Ug6xQykdj2oM50 = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'all')
		if JVw3Ug6xQykdj2oM50==eHdDoxhJCEPMZFVa2fg: E1Viom5L3684CTOFJ = url
		else: E1Viom5L3684CTOFJ = url+'?'+JVw3Ug6xQykdj2oM50
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أظهار قائمة الفيديو التي تم اختيارها',E1Viom5L3684CTOFJ,241,eHdDoxhJCEPMZFVa2fg,'1')
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' [[   '+aSF3HMlugcs9G7Yz+'   ]]',E1Viom5L3684CTOFJ,241,eHdDoxhJCEPMZFVa2fg,'1')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,True,'AKWAM-FILTERS_MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<form id(.*?)</form>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = cBawilJXvK1m.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	dict = {}
	for BYy2jD5CQfh3rdxTAFzJ84Vk6E,name,cOUiow273ytu1GC5N0FJh in IVnCEBUYx5s3oleJkmdr2zWa0Ni:
		items = cBawilJXvK1m.findall('<option(.*?)>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if '=' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = url
		if type=='CATEGORIES':
			if U3d2hkuwDIj56!=BYy2jD5CQfh3rdxTAFzJ84Vk6E: continue
			elif len(items)<=1:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==o7Dz5MbRWPmEeLVpiJ[-1]: zRK9ruIt0ZFV4bgi(E1Viom5L3684CTOFJ)
				else: bbkDE5p9zlX6aV(E1Viom5L3684CTOFJ,'CATEGORIES___'+r3bWKiRBqwE54ayCf0utvhDlx)
				return
			else:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==o7Dz5MbRWPmEeLVpiJ[-1]: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',E1Viom5L3684CTOFJ,241,eHdDoxhJCEPMZFVa2fg,'1')
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',E1Viom5L3684CTOFJ,245,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		elif type=='FILTERS':
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع : '+name,E1Viom5L3684CTOFJ,244,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E] = {}
		for q5qDOCzEe0Lv4ZyJbWnaPcpVsB,gW0v8nMxdq2 in items:
			if gW0v8nMxdq2 in IVD2kBKhW8FeQLvxUm: continue
			if 'value' not in q5qDOCzEe0Lv4ZyJbWnaPcpVsB: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = gW0v8nMxdq2
			else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = cBawilJXvK1m.findall('"(.*?)"',q5qDOCzEe0Lv4ZyJbWnaPcpVsB,cBawilJXvK1m.DOTALL)[0]
			dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E][q5qDOCzEe0Lv4ZyJbWnaPcpVsB] = gW0v8nMxdq2
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+gW0v8nMxdq2
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			nSjP8erv4yop = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			title = gW0v8nMxdq2+' : '#+dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E]['0']
			title = gW0v8nMxdq2+' : '+name
			if type=='FILTERS': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,244,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
			elif type=='CATEGORIES' and o7Dz5MbRWPmEeLVpiJ[-2]+'=' in goUS2aiGbZX1OQ:
				jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(e2mXDvCIA45Hp81FPKhaiWJGuM,'all')
				ajHR9ABQl2buvm = url+'?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,ajHR9ABQl2buvm,241,eHdDoxhJCEPMZFVa2fg,'1')
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,245,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
	return
def QRKwbZae0G3m(yTtrwivOXY68ECP7ZHQgNdJ1,mode):
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.strip('&')
	f8TRa4pzuVmo7c9gZ1j6rtPYOXqe = {}
	if '=' in yTtrwivOXY68ECP7ZHQgNdJ1:
		items = yTtrwivOXY68ECP7ZHQgNdJ1.split('&')
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			WW4LlMgICSbVYDfXKQdtzik,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split('=')
			f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[WW4LlMgICSbVYDfXKQdtzik] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = eHdDoxhJCEPMZFVa2fg
	WAUF7ftHbcrPEIDn1oyRMm95Td0YX = ['section','category','rating','year','language','formats','quality']
	for key in WAUF7ftHbcrPEIDn1oyRMm95Td0YX:
		if key in list(f8TRa4pzuVmo7c9gZ1j6rtPYOXqe.keys()): q5qDOCzEe0Lv4ZyJbWnaPcpVsB = f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[key]
		else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = '0'
		if mode=='modified_values' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+' + '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='modified_filters' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='all': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip(' + ')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip('&')
	return Q2OrNnmvR5HfY
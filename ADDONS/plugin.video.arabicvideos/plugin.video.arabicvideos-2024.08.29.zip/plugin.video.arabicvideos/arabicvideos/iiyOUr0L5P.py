# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'CIMANOW'
r07r9xeEFASJXluImT = '_CMN_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['قائمتي']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==300: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==301: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==302: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==303: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = igwApoWIt2m(url)
	elif mode==304: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==305: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==306: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = PkzcEBODuXtHLjYvMZ()
	elif mode==309: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'لماذا الموقع بطيء',eHdDoxhJCEPMZFVa2fg,306)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,309,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn+'/home',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<header>(.*?)</header>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('<li><a href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,301)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	VrWsaTmY2qZ(q3QVhZaDEuo8t2ASj5vkn+'/home',nR2B1Wye7luXb5)
	return nR2B1Wye7luXb5
def PkzcEBODuXtHLjYvMZ():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def VrWsaTmY2qZ(url,nR2B1Wye7luXb5=eHdDoxhJCEPMZFVa2fg):
	if not nR2B1Wye7luXb5:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-SUBMENU-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	SDZB9uCEYwg4osN = 0
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(<section>.*?</section>)',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		for cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			SDZB9uCEYwg4osN += 1
			items = cBawilJXvK1m.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for title,oIepM8vLif43R1z,apOKrFbP9IYHDyUVm7 in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				if title==eHdDoxhJCEPMZFVa2fg: title = 'بووووو'
				if 'em><a' not in oIepM8vLif43R1z:
					if cOUiow273ytu1GC5N0FJh.count('/category/')>0:
						EiABLjW8KhkIVC7vJGyf9scSq3rYtm = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
						for apOKrFbP9IYHDyUVm7 in EiABLjW8KhkIVC7vJGyf9scSq3rYtm:
							title = apOKrFbP9IYHDyUVm7.split('/')[-2]
							qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,301)
						continue
					else: apOKrFbP9IYHDyUVm7 = url+'?sequence='+str(SDZB9uCEYwg4osN)
				if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,302)
	else: zRK9ruIt0ZFV4bgi(url,nR2B1Wye7luXb5)
	return
def zRK9ruIt0ZFV4bgi(url,nR2B1Wye7luXb5=eHdDoxhJCEPMZFVa2fg):
	if nR2B1Wye7luXb5==eHdDoxhJCEPMZFVa2fg:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-TITLES-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if '?sequence=' in url:
		url,SDZB9uCEYwg4osN = url.split('?sequence=')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(<section>.*?</section>)',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[int(SDZB9uCEYwg4osN)-1]
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"posts"(.*?)</body>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for apOKrFbP9IYHDyUVm7,data,PeLqCN5Ek8bB in items:
		title = cBawilJXvK1m.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,cBawilJXvK1m.DOTALL)
		if title: title = title[0][2].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not title or title==eHdDoxhJCEPMZFVa2fg:
			title = cBawilJXvK1m.findall('title">.*?</em>(.*?)<',data,cBawilJXvK1m.DOTALL)
			if title: title = title[0].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if not title or title==eHdDoxhJCEPMZFVa2fg:
				title = cBawilJXvK1m.findall('title">(.*?)<',data,cBawilJXvK1m.DOTALL)
				title = title[0].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		title = zJRbA1YW2Eor(title)
		title = title.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if title not in adU3exogvimBLnCQOwz:
			adU3exogvimBLnCQOwz.append(title)
			KUTgdRBshwIZcbuv0LVC4 = apOKrFbP9IYHDyUVm7+data+PeLqCN5Ek8bB
			if '/selary/' in KUTgdRBshwIZcbuv0LVC4 or 'مسلسل' in KUTgdRBshwIZcbuv0LVC4 or '"episode"' in KUTgdRBshwIZcbuv0LVC4:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,303,PeLqCN5Ek8bB)
			else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,305,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('<li><a href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,302)
	return
def igwApoWIt2m(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-SEASONS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	name = cBawilJXvK1m.findall('<title>(.*?)</title>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	name = name[0].replace('| سيما ناو',eHdDoxhJCEPMZFVa2fg).replace('Cima Now',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	name = name.split('الحلقة')[0].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<section(.*?)</section>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if len(items)>1:
			for apOKrFbP9IYHDyUVm7,title in items:
				title = name+' - '+title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,304)
		else: tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if '/selary/' not in url:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"episodes"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			title = 'الحلقة '+title
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,305)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"details"(.*?)"related"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,305,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	E1Viom5L3684CTOFJ = url+'watching/'
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMANOW-PLAY-5th')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	ppQOjlq2gaPkW = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"download"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			s0s2bIZtWx8w3 = cBawilJXvK1m.findall('\d\d\d+',title,cBawilJXvK1m.DOTALL)
			if s0s2bIZtWx8w3:
				s0s2bIZtWx8w3 = '____'+s0s2bIZtWx8w3[0]
				title = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
			else: s0s2bIZtWx8w3 = eHdDoxhJCEPMZFVa2fg
			bmsN7D3kPQ8Beh5RS0M4ng2FcY = apOKrFbP9IYHDyUVm7+'?named='+title+'__download'+s0s2bIZtWx8w3
			ppQOjlq2gaPkW.append(bmsN7D3kPQ8Beh5RS0M4ng2FcY)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"watch"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('"embed".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod:
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
			title = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__embed'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		JCZVK86QTYwX4mfgOrod = [q3QVhZaDEuo8t2ASj5vkn+'/wp-content/themes/Cima%20Now%20New/core.php']
		if JCZVK86QTYwX4mfgOrod:
			items = cBawilJXvK1m.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for WmUKzewgdt7nOa3VlBC19,id,title in items:
				title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[0]+'?action=switch&index='+WmUKzewgdt7nOa3VlBC19+'&id='+id+'?named='+title+'__watch'
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn + '/?s='+search
	zRK9ruIt0ZFV4bgi(url)
	return
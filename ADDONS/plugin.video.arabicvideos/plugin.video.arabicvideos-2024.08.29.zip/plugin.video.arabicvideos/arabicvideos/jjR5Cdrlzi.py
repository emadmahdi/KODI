# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'CIMACLUP'
r07r9xeEFASJXluImT = '_CMC_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['موقع نتفليكس']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==490: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==491: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==492: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==493: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==494: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==499: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text,url)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = cBawilJXvK1m.findall('href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	rPxSTcgYVul1sqkwtD8HC62vZ4 = rPxSTcgYVul1sqkwtD8HC62vZ4[0].strip('/')
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(rPxSTcgYVul1sqkwtD8HC62vZ4,'url')
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"filter AjaxifyFilter"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('data-filter="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title in IVD2kBKhW8FeQLvxUm: continue
			apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/wp-content/themes/old/filter/'+apOKrFbP9IYHDyUVm7+'.php'
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,491)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أفلام',rPxSTcgYVul1sqkwtD8HC62vZ4+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مسلسلات',rPxSTcgYVul1sqkwtD8HC62vZ4+'/category/مسلسلات/مسلسلات-اجنبى',494,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="navigation-menu"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		if apOKrFbP9IYHDyUVm7=='/': continue
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+apOKrFbP9IYHDyUVm7
		if title in IVD2kBKhW8FeQLvxUm: continue
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,491)
	return nR2B1Wye7luXb5
def VrWsaTmY2qZ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"filter"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title in IVD2kBKhW8FeQLvxUm: continue
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,491)
	return
def zRK9ruIt0ZFV4bgi(url,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=eHdDoxhJCEPMZFVa2fg):
	items = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	cOUiow273ytu1GC5N0FJh = eHdDoxhJCEPMZFVa2fg
	if '.php' in url: cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
	elif '?s=' in url:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"blocks(.*?)"manifest"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"Blocks(.*?)"manifest"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if not cOUiow273ytu1GC5N0FJh: return
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		title = zJRbA1YW2Eor(title)
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) حلقة \d+',title,cBawilJXvK1m.DOTALL)
		if not vQ2LDF3UyXZbhu97Y: vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
		if not vQ2LDF3UyXZbhu97Y or any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,492,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and 'حلقة' in title:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,493,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,493,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('<li><a href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = zJRbA1YW2Eor(title)
			title = title.replace('الصفحة ',eHdDoxhJCEPMZFVa2fg)
			if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,491)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('"ButtonsBarCo".*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if E1Viom5L3684CTOFJ:
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[0]
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-EPISODES-2nd')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	PeLqCN5Ek8bB = cBawilJXvK1m.findall('"img-responsive" src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB[0]
	else: PeLqCN5Ek8bB = ccwRLKk3hs0E.getInfoLabel('ListItem.Thumb')
	w69FNzXjsWm = cBawilJXvK1m.findall('"filter"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"Blocks(.*?)class="pagination"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm and '/series/' not in url:
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,493,PeLqCN5Ek8bB)
	elif eFUZtGJawsxyA42SRXl8fkBrnjo:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,492,PeLqCN5Ek8bB)
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = zJRbA1YW2Eor(title)
				title = title.replace('الصفحة ',eHdDoxhJCEPMZFVa2fg)
				if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,491)
	return
def bbmQeYGSTIv(url):
	E1Viom5L3684CTOFJ = url.strip('/')+'/?view=1'
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'CIMACLUP-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	ppQOjlq2gaPkW = []
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	jDosQa7ltiz2Y5ZrBxvVLEeu9I = cBawilJXvK1m.findall("data: 'q=(.*?)&",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	jDosQa7ltiz2Y5ZrBxvVLEeu9I = jDosQa7ltiz2Y5ZrBxvVLEeu9I[0]
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"serversList"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('data-server="(.*?)">(.*?)</li>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for L80HjQ37BkDcr6xWKwYZodX,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+'/wp-content/themes/old/servers/server.php?q='+jDosQa7ltiz2Y5ZrBxvVLEeu9I+'&i='+L80HjQ37BkDcr6xWKwYZodX+'?named='+title+'__watch'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('"embedServer".*?SRC="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		title = 'مفضل'
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]+'?named=__embed__'+title
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"downloadsList"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('<td>(.*?)</td>.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7 in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if 'anavidz' in apOKrFbP9IYHDyUVm7: uVpKOk8ZM0LvQ6UI = '__خاص'
			else: uVpKOk8ZM0LvQ6UI = eHdDoxhJCEPMZFVa2fg
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download'+uVpKOk8ZM0LvQ6UI
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search,rPxSTcgYVul1sqkwtD8HC62vZ4=eHdDoxhJCEPMZFVa2fg):
	if not rPxSTcgYVul1sqkwtD8HC62vZ4: rPxSTcgYVul1sqkwtD8HC62vZ4 = q3QVhZaDEuo8t2ASj5vkn
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = rPxSTcgYVul1sqkwtD8HC62vZ4+'/index.php?s='+search
	zRK9ruIt0ZFV4bgi(url)
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'LODYNET'
r07r9xeEFASJXluImT = '_LDN_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الرئيسية','استفسارتكم و الطلبات']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==450: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==451: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==452: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==453: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = igwApoWIt2m(url)
	elif mode==454: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==459: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LODYNET-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(q3QVhZaDEuo8t2ASj5vkn,'url')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,459,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مثبتات لودي نت',rPxSTcgYVul1sqkwtD8HC62vZ4,451,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المضاف حديثا',rPxSTcgYVul1sqkwtD8HC62vZ4,451,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'latest')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"MainMenu"(.*?)"SiteSlider"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if apOKrFbP9IYHDyUVm7=='#': continue
			if title in IVD2kBKhW8FeQLvxUm: continue
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,451)
	return
def zRK9ruIt0ZFV4bgi(url,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=eHdDoxhJCEPMZFVa2fg):
	items = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LODYNET-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=='featured':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"SiteSlider"(.*?)"waves"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=='latest':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"RecentPosts"(.*?)"pagination"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif '"ActorsList"' in nR2B1Wye7luXb5:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"ActorsList"(.*?)"text/javascript"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif ff8WuQ0HaAmPEdo6SnMXr1sCeTzR in ['0','1','2']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"Section"(.*?)</li></ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[int(ff8WuQ0HaAmPEdo6SnMXr1sCeTzR)]
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"BlocksArea"(.*?)"text/javascript"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if not items: items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if '"ActorsList"' in nR2B1Wye7luXb5 and 'src=' in PeLqCN5Ek8bB:
			PeLqCN5Ek8bB = cBawilJXvK1m.findall('src="(.*?)"',PeLqCN5Ek8bB,cBawilJXvK1m.DOTALL)
			PeLqCN5Ek8bB = PeLqCN5Ek8bB[0]
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7).strip('/')
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) حلقة \d+',title,cBawilJXvK1m.DOTALL)
		if not vQ2LDF3UyXZbhu97Y: vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
		if set(title.split()) & set(L5aGZx9Y8zy6V2U) and 'مسلسل' not in title:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,452,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and 'حلقة' in title:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,453,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,453,PeLqCN5Ek8bB)
	if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR in [eHdDoxhJCEPMZFVa2fg,'latest']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,451)
	return
def igwApoWIt2m(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LODYNET-SEASONS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	w69FNzXjsWm = cBawilJXvK1m.findall('"CategorySubLinks"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if w69FNzXjsWm and 'href=' in str(w69FNzXjsWm):
		title = cBawilJXvK1m.findall('<title>(.*?)-',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		title = title[0].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,454)
		cOUiow273ytu1GC5N0FJh = w69FNzXjsWm[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,454)
	else: tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LODYNET-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"BlocksArea"(.*?)"text/javascript"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if eFUZtGJawsxyA42SRXl8fkBrnjo:
		cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,452,PeLqCN5Ek8bB)
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,454)
	return
def bbmQeYGSTIv(url):
	E1Viom5L3684CTOFJ = url.replace('/movies/','/watch_movies/')
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.replace('/episodes/','/watch_episodes/')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LODYNET-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,'url')
	ppQOjlq2gaPkW = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"WatchTitle"(.*?)</aside>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('data-embed="(.*?)">(.*?)</li>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"DownloadLinks"(.*?)"selary"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,name in items:
			name = zJRbA1YW2Eor(name)
			s0s2bIZtWx8w3 = cBawilJXvK1m.findall('\d\d\d+',name,cBawilJXvK1m.DOTALL)
			if s0s2bIZtWx8w3:
				s0s2bIZtWx8w3 = '____'+s0s2bIZtWx8w3[0]
				name = eHdDoxhJCEPMZFVa2fg
			else: s0s2bIZtWx8w3 = eHdDoxhJCEPMZFVa2fg
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__download'+s0s2bIZtWx8w3
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search
	zRK9ruIt0ZFV4bgi(url)
	return
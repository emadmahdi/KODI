# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'FAJERSHOW'
r07r9xeEFASJXluImT = '_FJS_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==390: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==391: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==392: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==393: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==399: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,399,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FAJERSHOW-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = cBawilJXvK1m.findall('<header>.*?<h2>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for SDZB9uCEYwg4osN in range(len(items)):
		title = items[SDZB9uCEYwg4osN]
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,q3QVhZaDEuo8t2ASj5vkn,391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'latest'+str(SDZB9uCEYwg4osN))
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مختارات عشوائية',q3QVhZaDEuo8t2ASj5vkn,391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'randoms')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أعلى الأفلام تقييماً',q3QVhZaDEuo8t2ASj5vkn,391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'top_imdb_movies')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أعلى المسلسلات تقييماً',q3QVhZaDEuo8t2ASj5vkn,391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'top_imdb_series')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أفلام مميزة',q3QVhZaDEuo8t2ASj5vkn+'/movies',391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured_movies')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مسلسلات مميزة',q3QVhZaDEuo8t2ASj5vkn+'/tvshows',391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured_tvshows')
	cOUiow273ytu1GC5N0FJh = eHdDoxhJCEPMZFVa2fg
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="menu"(.*?)id="contenedor"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh += RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn+'/movies',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FAJERSHOW-MENU-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="releases"(.*?)aside',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh += RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	HLjG0evOkWzBoa3F5UXdTi = True
	for apOKrFbP9IYHDyUVm7,title in items:
		title = zJRbA1YW2Eor(title)
		if title=='الأعلى مشاهدة':
			if HLjG0evOkWzBoa3F5UXdTi:
				title = 'الافلام '+title
				HLjG0evOkWzBoa3F5UXdTi = False
			else: title = 'المسلسلات '+title
		if title not in IVD2kBKhW8FeQLvxUm:
			if title=='أفلام': qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,q3QVhZaDEuo8t2ASj5vkn+'/movies',391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'all_movies_tvshows')
			elif title=='مسلسلات': qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,q3QVhZaDEuo8t2ASj5vkn+'/tvshows',391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'all_movies_tvshows')
			else: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,391)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url,type):
	cOUiow273ytu1GC5N0FJh,items = [],[]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FAJERSHOW-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if type in ['featured_movies','featured_tvshows']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="content"(.*?)id="archive-content"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif type=='all_movies_tvshows':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="archive-content"(.*?)class="pagination"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	elif type=='top_imdb_movies':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='top_imdb_series':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("class='top-imdb-list tright(.*?)footer",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='search':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="search-page"(.*?)class="sidebar',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='sider':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="widget(.*?)class="widget',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = cBawilJXvK1m.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		ppQOjlq2gaPkW,JN1MdQFh5iArSHPsEquaxO0CG6U,FBITEXGDfe2mcCxnQs6ktMdy9HJh = zip(*FbL9lHaTVANMPd7hDJcw2o8QEX1mqu)
		items = zip(JN1MdQFh5iArSHPsEquaxO0CG6U,ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh)
	elif type=='randoms':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="slider-movies-tvshows"(.*?)<header>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif 'latest' in type:
		SDZB9uCEYwg4osN = int(type[-1:])
		nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('<header>','<end><start>')
		nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('</div></div></div>','</div></div></div><end>')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<start>(.*?)<end>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[SDZB9uCEYwg4osN]
		if SDZB9uCEYwg4osN==6:
			FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = cBawilJXvK1m.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			JN1MdQFh5iArSHPsEquaxO0CG6U,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = zip(*FbL9lHaTVANMPd7hDJcw2o8QEX1mqu)
			items = zip(JN1MdQFh5iArSHPsEquaxO0CG6U,ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="content"(.*?)class="(pagination|sidebar)',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][0]
			if '/collection/' in url:
				items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			elif '/quality/' in url:
				items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if not items and cOUiow273ytu1GC5N0FJh:
		items = cBawilJXvK1m.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = cBawilJXvK1m.findall('^(.*?)<.*?serie">(.*?)<',title,cBawilJXvK1m.DOTALL)
			title = title[0][1]
			if title in adU3exogvimBLnCQOwz: continue
			adU3exogvimBLnCQOwz.append(title)
			title = '_MOD_'+title
		uVpKOk8ZM0LvQ6UI = cBawilJXvK1m.findall('^(.*?)<',title,cBawilJXvK1m.DOTALL)
		if uVpKOk8ZM0LvQ6UI: title = uVpKOk8ZM0LvQ6UI[0]
		title = zJRbA1YW2Eor(title)
		if '/tvshows/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,393,PeLqCN5Ek8bB)
		elif '/episodes/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,393,PeLqCN5Ek8bB)
		elif '/seasons/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,393,PeLqCN5Ek8bB)
		elif '/collection/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,391,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,392,PeLqCN5Ek8bB)
	if type not in ['featured_movies','featured_tvshows']:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,391,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	url = url.replace(GfhcsvCWIon,q3QVhZaDEuo8t2ASj5vkn)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FAJERSHOW-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	i2qmOCHN5goZ = cBawilJXvK1m.findall('class="C rated".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<ul class="episodios">(.*?)</ul></div></div></div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,392,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	nR2B1Wye7luXb5 = KRSoWMhk08fzBe(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FAJERSHOW-PLAY-1st')
	i2qmOCHN5goZ = cBawilJXvK1m.findall('class="C rated".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	ppQOjlq2gaPkW = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][0]
		items = cBawilJXvK1m.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for type,V5VgYoCK6sT,hDQeCpgblu7BPNtkm,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+V5VgYoCK6sT+'&nume='+hDQeCpgblu7BPNtkm+'&type='+type
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3,qStMGnRJL0exKZjiW6dC19p5 in items:
			if '=' in PeLqCN5Ek8bB:
				XmWBjLi8A2qhzKCJ7p6r = PeLqCN5Ek8bB.split('=')[1]
				title = b31wAB8mhaz2rXHoJFlfvDugtsOj(XmWBjLi8A2qhzKCJ7p6r,'host')
			else: title = eHdDoxhJCEPMZFVa2fg
			title = qStMGnRJL0exKZjiW6dC19p5+avcfIls8w7gk69hYUErHxzQTXtm24j+title
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download____'+s0s2bIZtWx8w3
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/?s='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
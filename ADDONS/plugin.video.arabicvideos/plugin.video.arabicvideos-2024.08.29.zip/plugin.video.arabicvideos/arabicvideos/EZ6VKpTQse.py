# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'LIVETV'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9['PYTHON'][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url):
	if   mode==100: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==101: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4('0',True)
	elif mode==102: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4('1',True)
	elif mode==103: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4('2',True)
	elif mode==104: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4('3',True)
	elif mode==105: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==106: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EGoutUTNgihIRDYqyAn798cS4('4',True)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder','_M3U_'+'قوائم فيديوهات M3U',eHdDoxhJCEPMZFVa2fg,762)
	qfpnsHw19BiaSktcXWbGA('folder','_IPT_'+'قوائم فيديوهات IPTV',eHdDoxhJCEPMZFVa2fg,761)
	qfpnsHw19BiaSktcXWbGA('folder','_TV0_'+'قنوات من مواقعها الأصلية',eHdDoxhJCEPMZFVa2fg,101)
	qfpnsHw19BiaSktcXWbGA('folder','_TV4_'+'قنوات مختارة من يوتيوب',eHdDoxhJCEPMZFVa2fg,106)
	qfpnsHw19BiaSktcXWbGA('folder','_YUT_'+'قنوات عربية من يوتيوب',eHdDoxhJCEPMZFVa2fg,147)
	qfpnsHw19BiaSktcXWbGA('folder','_YUT_'+'قنوات أجنبية من يوتيوب',eHdDoxhJCEPMZFVa2fg,148)
	qfpnsHw19BiaSktcXWbGA('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',eHdDoxhJCEPMZFVa2fg,28)
	qfpnsHw19BiaSktcXWbGA('live','_MRF_'+'قناة المعارف من موقعهم',eHdDoxhJCEPMZFVa2fg,41)
	qfpnsHw19BiaSktcXWbGA('live','_PNT_'+'قناة هلا من موقع بانيت',eHdDoxhJCEPMZFVa2fg,38)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder','_TV1_'+'قنوات تلفزيونية عامة',eHdDoxhJCEPMZFVa2fg,102)
	qfpnsHw19BiaSktcXWbGA('folder','_TV2_'+'قنوات تلفزيونية خاصة',eHdDoxhJCEPMZFVa2fg,103)
	qfpnsHw19BiaSktcXWbGA('folder','_TV3_'+'قنوات تلفزيونية للفحص',eHdDoxhJCEPMZFVa2fg,104)
	return
def EGoutUTNgihIRDYqyAn798cS4(H0zbLoi34hNU,showDialogs=True):
	r07r9xeEFASJXluImT = '_TV'+H0zbLoi34hNU+'_'
	j6KOlzWGugZqmx0sPS = {'id':eHdDoxhJCEPMZFVa2fg,'user':ZylBO1ktRGvdJ0,'function':'list','menu':H0zbLoi34hNU}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',q3QVhZaDEuo8t2ASj5vkn,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIVETV-ITEMS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = cBawilJXvK1m.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(items)):
			name = items[dhcGSyo8Kn1mHZwvEAkzJ7NUq][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[dhcGSyo8Kn1mHZwvEAkzJ7NUq] = items[dhcGSyo8Kn1mHZwvEAkzJ7NUq][0],items[dhcGSyo8Kn1mHZwvEAkzJ7NUq][1],items[dhcGSyo8Kn1mHZwvEAkzJ7NUq][2],name,items[dhcGSyo8Kn1mHZwvEAkzJ7NUq][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for Oyg3pZGAHdws7RWm4e6S,GfhcsvCWIon,bAQX4RoUJYDEVqKMgLW56F7Zh9z,name,PeLqCN5Ek8bB in items:
			if '#' in Oyg3pZGAHdws7RWm4e6S: continue
			if Oyg3pZGAHdws7RWm4e6S!='URL': name = name+SbyWQGMDnV+D8OnEGLjecaXw+Oyg3pZGAHdws7RWm4e6S+Nat0Dx9puRUWCsgz6JyFhY3
			url = Oyg3pZGAHdws7RWm4e6S+';;'+GfhcsvCWIon+';;'+bAQX4RoUJYDEVqKMgLW56F7Zh9z+';;'+H0zbLoi34hNU
			qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+eHdDoxhJCEPMZFVa2fg+name,url,105,PeLqCN5Ek8bB)
	else:
		if showDialogs: qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'هذه الخدمة مخصصة للمبرمج فقط',eHdDoxhJCEPMZFVa2fg,9999)
	return
def bbmQeYGSTIv(id):
	Oyg3pZGAHdws7RWm4e6S,GfhcsvCWIon,bAQX4RoUJYDEVqKMgLW56F7Zh9z,H0zbLoi34hNU = id.split(';;')
	url = eHdDoxhJCEPMZFVa2fg
	if Oyg3pZGAHdws7RWm4e6S=='URL': url = bAQX4RoUJYDEVqKMgLW56F7Zh9z
	elif Oyg3pZGAHdws7RWm4e6S=='YOUTUBE':
		url = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9['YOUTUBE'][0]+'/watch?v='+bAQX4RoUJYDEVqKMgLW56F7Zh9z
		import SOnwRtkA74
		SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([url],EERWJf1adv67,'live',url)
		return
	elif Oyg3pZGAHdws7RWm4e6S=='GA':
		j6KOlzWGugZqmx0sPS = { 'id' : eHdDoxhJCEPMZFVa2fg, 'user' : ZylBO1ktRGvdJ0 , 'function' : 'playGA1' , 'menu' : eHdDoxhJCEPMZFVa2fg }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,False,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-1st')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		cookies = aP8bLqZJsQlH3ivWKc.cookies
		CknO1y0jpJ9uoYsL6GQfRiv = cookies['ASP.NET_SessionId']
		url = aP8bLqZJsQlH3ivWKc.headers['Location']
		j6KOlzWGugZqmx0sPS = { 'id' : bAQX4RoUJYDEVqKMgLW56F7Zh9z , 'user' : ZylBO1ktRGvdJ0 , 'function' : 'playGA2' , 'menu' : eHdDoxhJCEPMZFVa2fg }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+CknO1y0jpJ9uoYsL6GQfRiv }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,j6KOlzWGugZqmx0sPS,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-2nd')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		url = cBawilJXvK1m.findall('resp":"(http.*?m3u8)(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		apOKrFbP9IYHDyUVm7 = url[0][0]
		Cnb6hvgaBtGw8yuJd0xW9A = url[0][1]
		hhsZTu3Xg61NzBMbk4ER5I = 'http://38.'+GfhcsvCWIon+'777/'+bAQX4RoUJYDEVqKMgLW56F7Zh9z+'_HD.m3u8'+Cnb6hvgaBtGw8yuJd0xW9A
		qqenEZCGlIgcHxdafK3Dbv4FXj = hhsZTu3Xg61NzBMbk4ER5I.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		ppzjmKYFRxvqA2TSX = hhsZTu3Xg61NzBMbk4ER5I.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		FBITEXGDfe2mcCxnQs6ktMdy9HJh = ['HD','SD1','SD2']
		ppQOjlq2gaPkW = [hhsZTu3Xg61NzBMbk4ER5I,qqenEZCGlIgcHxdafK3Dbv4FXj,ppzjmKYFRxvqA2TSX]
		iLcCSnPyKYWs3xkQ0p14 = 0
		if iLcCSnPyKYWs3xkQ0p14 == -1: return
		else: url = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	elif Oyg3pZGAHdws7RWm4e6S=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		j6KOlzWGugZqmx0sPS = { 'id' : bAQX4RoUJYDEVqKMgLW56F7Zh9z , 'user' : ZylBO1ktRGvdJ0 , 'function' : 'playNT' , 'menu' : H0zbLoi34hNU }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST', q3QVhZaDEuo8t2ASj5vkn, j6KOlzWGugZqmx0sPS, headers, False,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-3rd')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		url = aP8bLqZJsQlH3ivWKc.headers['Location']
		url = url.replace('%20',avcfIls8w7gk69hYUErHxzQTXtm24j)
		url = url.replace('%3D','=')
		if 'Learn' in bAQX4RoUJYDEVqKMgLW56F7Zh9z:
			url = url.replace('NTNNile',eHdDoxhJCEPMZFVa2fg)
			url = url.replace('learning1','Learning')
	elif Oyg3pZGAHdws7RWm4e6S=='PL':
		j6KOlzWGugZqmx0sPS = { 'id' : bAQX4RoUJYDEVqKMgLW56F7Zh9z , 'user' : ZylBO1ktRGvdJ0 , 'function' : 'playPL' , 'menu' : H0zbLoi34hNU }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST', q3QVhZaDEuo8t2ASj5vkn, j6KOlzWGugZqmx0sPS, eHdDoxhJCEPMZFVa2fg,False,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-4th')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		url = aP8bLqZJsQlH3ivWKc.headers['Location']
		headers = {'Referer':aP8bLqZJsQlH3ivWKc.headers['Referer']}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'POST',url, eHdDoxhJCEPMZFVa2fg,headers , eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-5th')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		items = cBawilJXvK1m.findall('source src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		url = items[0]
	elif Oyg3pZGAHdws7RWm4e6S in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if Oyg3pZGAHdws7RWm4e6S=='TA': bAQX4RoUJYDEVqKMgLW56F7Zh9z = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		j6KOlzWGugZqmx0sPS = { 'id' : bAQX4RoUJYDEVqKMgLW56F7Zh9z , 'user' : ZylBO1ktRGvdJ0 , 'function' : 'play'+Oyg3pZGAHdws7RWm4e6S , 'menu' : H0zbLoi34hNU }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',q3QVhZaDEuo8t2ASj5vkn,j6KOlzWGugZqmx0sPS,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-6th')
		if not aP8bLqZJsQlH3ivWKc.succeeded:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		url = aP8bLqZJsQlH3ivWKc.headers['Location']
		if Oyg3pZGAHdws7RWm4e6S=='FM':
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'GET', url, eHdDoxhJCEPMZFVa2fg, eHdDoxhJCEPMZFVa2fg, False,eHdDoxhJCEPMZFVa2fg,'LIVETV-PLAY-7th')
			url = aP8bLqZJsQlH3ivWKc.headers['Location']
			url = url.replace('https','http')
	IZkpyKSFVarcHwG1g6emqQv70h(url,EERWJf1adv67,'live')
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'FASELHD1'
headers = {'User-Agent':eHdDoxhJCEPMZFVa2fg}
r07r9xeEFASJXluImT = '_FH1_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['جوائز الأوسكار','المراجعات','wwe']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==570: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==571: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==572: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==573: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,text)
	elif mode==576: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = PkzcEBODuXtHLjYvMZ()
	elif mode==579: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'لماذا الموقع بطيء',eHdDoxhJCEPMZFVa2fg,576)
	rPxSTcgYVul1sqkwtD8HC62vZ4,url = q3QVhZaDEuo8t2ASj5vkn,q3QVhZaDEuo8t2ASj5vkn
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FASELHD1-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',rPxSTcgYVul1sqkwtD8HC62vZ4,579,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'المميزة',rPxSTcgYVul1sqkwtD8HC62vZ4,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured1')
	items = cBawilJXvK1m.findall('class="h3">(.*?)<.*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for title,apOKrFbP9IYHDyUVm7 in items:
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'details1')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"menu-primary"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		mWVqscjSXBepGZzEhvLHniR1D2 = cBawilJXvK1m.findall('<li (.*?)</li>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		IyqSwnbGtU95r3 = [eHdDoxhJCEPMZFVa2fg,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		gMmB3iopS0ZXrOFewhcxt = 0
		for H0zbLoi34hNU in mWVqscjSXBepGZzEhvLHniR1D2:
			if gMmB3iopS0ZXrOFewhcxt>0: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',H0zbLoi34hNU,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if apOKrFbP9IYHDyUVm7=='#': continue
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+apOKrFbP9IYHDyUVm7
				if title==eHdDoxhJCEPMZFVa2fg: continue
				if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title.lower() for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
				title = IyqSwnbGtU95r3[gMmB3iopS0ZXrOFewhcxt]+title
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'details2')
			gMmB3iopS0ZXrOFewhcxt += 1
	return
def PkzcEBODuXtHLjYvMZ():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FASELHD1-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('class="h4">(.*?)</div>(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not eFUZtGJawsxyA42SRXl8fkBrnjo: return
	if type=='filters':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = [nR2B1Wye7luXb5.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"homeSlide"(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		UlDc6wMK03mHh,JCZVK86QTYwX4mfgOrod,RnjhvEwkQqYtb94WpBxX5P = zip(*items)
		items = zip(JCZVK86QTYwX4mfgOrod,UlDc6wMK03mHh,RnjhvEwkQqYtb94WpBxX5P)
	elif type=='featured2':
		title,cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='details2' and len(eFUZtGJawsxyA42SRXl8fkBrnjo)>1:
		title = eFUZtGJawsxyA42SRXl8fkBrnjo[0][0]
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured2')
		title = eFUZtGJawsxyA42SRXl8fkBrnjo[1][0]
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'details3')
		return
	else:
		title,cOUiow273ytu1GC5N0FJh = eFUZtGJawsxyA42SRXl8fkBrnjo[-1]
		items = cBawilJXvK1m.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title.lower() for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
		PeLqCN5Ek8bB = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(PeLqCN5Ek8bB)
		PeLqCN5Ek8bB = PeLqCN5Ek8bB.split('?resize=')[0]
		title = zJRbA1YW2Eor(title)
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|حلقة).\d+',title,cBawilJXvK1m.DOTALL)
		if '/collections/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,571,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and type==eHdDoxhJCEPMZFVa2fg:
			title = '_MOD_'+vQ2LDF3UyXZbhu97Y[0][0]
			title = title.strip(' –')
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,573,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		elif 'episodes/' in apOKrFbP9IYHDyUVm7 or 'movies/' in apOKrFbP9IYHDyUVm7 or 'hindi/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,572,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,573,PeLqCN5Ek8bB)
	if type=='filters':
		JbBOjkDXHWQqrnGIz5RYNd = cBawilJXvK1m.findall('"more_button_page":(.*?),',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if JbBOjkDXHWQqrnGIz5RYNd:
			count = JbBOjkDXHWQqrnGIz5RYNd[0]
			apOKrFbP9IYHDyUVm7 = url+'/offset/'+count
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة أخرى',apOKrFbP9IYHDyUVm7,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'filters')
	elif 'details' in type:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("class='pagination(.*?)</div>",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall("href='(.*?)'.*?>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = 'صفحة '+zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,571,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'details4')
	return
def CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FASELHD1-SEASONS_EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	MMHTKqYVvSrLojUt = False
	if not type:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"seasonList"(.*?)"container"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if len(items)>1:
				rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
				MMHTKqYVvSrLojUt = True
				for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,name,title in items:
					name = zJRbA1YW2Eor(name)
					if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+apOKrFbP9IYHDyUVm7
					title = name+' - '+title
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,573,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,'episodes')
	if type=='episodes' or not MMHTKqYVvSrLojUt:
		e3XtKs70ifmRQY8VTLnpMdyr6 = cBawilJXvK1m.findall('"posterImg".*?src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if e3XtKs70ifmRQY8VTLnpMdyr6: PeLqCN5Ek8bB = e3XtKs70ifmRQY8VTLnpMdyr6[0]
		else: PeLqCN5Ek8bB = eHdDoxhJCEPMZFVa2fg
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"epAll"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				title = zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,572,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	wROf6m4Ix73jtsdnZ1vpCDuV,EeaIorLu6z4Zq3,YdRivB5jFXMNpakxz4rUKQu7J8V0S = [],[],[]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'FASELHD1-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	BZVHWp0qXmFPtx7wAfejN = cBawilJXvK1m.findall('مستوى المشاهدة.*?">(.*?)</span>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if BZVHWp0qXmFPtx7wAfejN:
		i2qmOCHN5goZ = cBawilJXvK1m.findall('"tag">(.*?)</a>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"videoRow"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&img=')[0]
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named=__embed')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="streamHeader(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall("href = '(.*?)'.*?</i>(.*?)</a>",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,name in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&img=')[0]
			name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+name+'__watch')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="downloadLinks(.*?)blackwindow',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?</span>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,name in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('&img=')[0]
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+name+'__download')
	for UAzqnaJwBovX0lZmS1dThC4 in wROf6m4Ix73jtsdnZ1vpCDuV:
		apOKrFbP9IYHDyUVm7,name = UAzqnaJwBovX0lZmS1dThC4.split('?named')
		if apOKrFbP9IYHDyUVm7 not in EeaIorLu6z4Zq3:
			EeaIorLu6z4Zq3.append(apOKrFbP9IYHDyUVm7)
			YdRivB5jFXMNpakxz4rUKQu7J8V0S.append(UAzqnaJwBovX0lZmS1dThC4)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(YdRivB5jFXMNpakxz4rUKQu7J8V0S,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/?s='+search
	zRK9ruIt0ZFV4bgi(E1Viom5L3684CTOFJ,'details5')
	return
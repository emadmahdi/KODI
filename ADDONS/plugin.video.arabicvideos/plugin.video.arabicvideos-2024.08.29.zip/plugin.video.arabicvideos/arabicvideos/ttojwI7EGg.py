# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
import bs4 as pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc
EERWJf1adv67 = 'ELCINEMA'
r07r9xeEFASJXluImT = '_ELC_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
headers = {'Referer':q3QVhZaDEuo8t2ASj5vkn}
IVD2kBKhW8FeQLvxUm = []
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==510: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==511: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = HpBeiSP4mu1lXxhrsNCE(url)
	elif mode==512: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ekoIKtMc4iFQAvs(url)
	elif mode==513: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = AASROZeMBrWp3y(url)
	elif mode==514: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ySvYgTHdL4cCQsbWhqADMzBNIVO0(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ySvYgTHdL4cCQsbWhqADMzBNIVO0(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = R0kKNyjg7EavlqsX(text)
	elif mode==517: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = T0iqCBb81kVj4(url)
	elif mode==518: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Tx8rUW3iI0OjQ7wtd6l5BpCzmg(url)
	elif mode==519: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	elif mode==520: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = j9uWgcqDZ1s5UiHbQJ(url)
	elif mode==521: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = PljuFY6X7k5Q2Ei4KMa8(url)
	elif mode==522: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==523: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = skqZ5fSIaxFCH(text)
	elif mode==524: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = sIxCoKSEFhlaTQNOu()
	elif mode==525: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = IjzZiw6lUs1QGr28Ta()
	elif mode==526: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = M956AlUtvOcaKhzrEbNI3iDYdfxZ8()
	elif mode==527: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = vzwohE2tWM()
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث بموسوعة السينما',eHdDoxhJCEPMZFVa2fg,519)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'موسوعة الأعمال',eHdDoxhJCEPMZFVa2fg,525)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'موسوعة الأشخاص',eHdDoxhJCEPMZFVa2fg,526)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'موسوعة المصنفات',eHdDoxhJCEPMZFVa2fg,527)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'موسوعة المنوعات',eHdDoxhJCEPMZFVa2fg,524)
	return
def sIxCoKSEFhlaTQNOu():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' فيديوهات - خاصة',q3QVhZaDEuo8t2ASj5vkn+'/video',520)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فيديوهات - أحدث',q3QVhZaDEuo8t2ASj5vkn+'/video/latest',521)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فيديوهات - أقدم',q3QVhZaDEuo8t2ASj5vkn+'/video/oldest',521)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فيديوهات - أكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn+'/video/views',521)
	return
def IjzZiw6lUs1QGr28Ta():
	X5ftPTuLn7Vs3F = q3QVhZaDEuo8t2ASj5vkn+'/lineup?utf8=%E2%9C%93'
	eTobBqr3RGLf2SyPtONHkMplzx9E = X5ftPTuLn7Vs3F+'&type=2&category=1&foreign=false&tag='
	gZ78JsCrty4x20wq = X5ftPTuLn7Vs3F+'&type=2&category=3&foreign=false&tag='
	YtZWdoMX1kDSwRyOjHEUfAn7b4C2m = X5ftPTuLn7Vs3F+'&type=2&category=1&foreign=true&tag='
	jksWFNHlJ2XMnCzRUZ5 = X5ftPTuLn7Vs3F+'&type=2&category=3&foreign=true&tag='
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات أفلام عربي',eTobBqr3RGLf2SyPtONHkMplzx9E,511)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات مسلسلات عربي',gZ78JsCrty4x20wq,511)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات أفلام اجنبي',YtZWdoMX1kDSwRyOjHEUfAn7b4C2m,511)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات مسلسلات اجنبي',jksWFNHlJ2XMnCzRUZ5,511)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس أعمال أبجدي',q3QVhZaDEuo8t2ASj5vkn+'/index/work/alphabet',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس  بلد الإنتاج',q3QVhZaDEuo8t2ASj5vkn+'/index/work/country',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس اللغة',q3QVhZaDEuo8t2ASj5vkn+'/index/work/language',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس مصنفات العمل',q3QVhZaDEuo8t2ASj5vkn+'/index/work/genre',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس سنة الإصدار',q3QVhZaDEuo8t2ASj5vkn+'/index/work/release_year',517)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مواسم - فلتر محدد',q3QVhZaDEuo8t2ASj5vkn+'/seasonals',515)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مواسم - فلتر كامل',q3QVhZaDEuo8t2ASj5vkn+'/seasonals',514)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات - فلتر محدد',q3QVhZaDEuo8t2ASj5vkn+'/lineup',515)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات - فلتر كامل',q3QVhZaDEuo8t2ASj5vkn+'/lineup',514)
	return
def vzwohE2tWM():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn+'/lineup',eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	cOUiow273ytu1GC5N0FJh = jyquAFlGSpJg.find('select',attrs={'name':'tag'})
	WWLbVhETM9ZCwm85f = cOUiow273ytu1GC5N0FJh.find_all('option')
	for gW0v8nMxdq2 in WWLbVhETM9ZCwm85f:
		q5qDOCzEe0Lv4ZyJbWnaPcpVsB = gW0v8nMxdq2.get('value')
		if not q5qDOCzEe0Lv4ZyJbWnaPcpVsB: continue
		title = gW0v8nMxdq2.text
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.encode(m6PFtLblInpNZ8x)
			q5qDOCzEe0Lv4ZyJbWnaPcpVsB = q5qDOCzEe0Lv4ZyJbWnaPcpVsB.encode(m6PFtLblInpNZ8x)
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		title = title.replace('قائمة ',eHdDoxhJCEPMZFVa2fg)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,511)
	return
def M956AlUtvOcaKhzrEbNI3iDYdfxZ8():
	X5ftPTuLn7Vs3F = q3QVhZaDEuo8t2ASj5vkn+'/lineup?utf8=%E2%9C%93'
	V7ZHYcKbMl6dPqLOuS = X5ftPTuLn7Vs3F+'&type=1&category=&foreign=&tag='
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات أشخاص',V7ZHYcKbMl6dPqLOuS,511)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس أشخاص أبجدي',q3QVhZaDEuo8t2ASj5vkn+'/index/person/alphabet',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس موطن',q3QVhZaDEuo8t2ASj5vkn+'/index/person/nationality',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس  تاريخ الميلاد',q3QVhZaDEuo8t2ASj5vkn+'/index/person/birth_year',517)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فهرس  تاريخ الوفاة',q3QVhZaDEuo8t2ASj5vkn+'/index/person/death_year',517)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات - فلتر محدد',q3QVhZaDEuo8t2ASj5vkn+'/lineup',515)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مصنفات - فلتر كامل',q3QVhZaDEuo8t2ASj5vkn+'/lineup',514)
	return
def HpBeiSP4mu1lXxhrsNCE(url):
	if '/seasonals' in url: WmUKzewgdt7nOa3VlBC19 = 0
	elif '/lineup' in url: WmUKzewgdt7nOa3VlBC19 = 1
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-LISTS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ekNMoIJzswUSDVQf564 = jyquAFlGSpJg.find_all(class_='jumbo-theater clearfix')
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		title = cOUiow273ytu1GC5N0FJh.find_all('a')[WmUKzewgdt7nOa3VlBC19].text
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+cOUiow273ytu1GC5N0FJh.find_all('a')[WmUKzewgdt7nOa3VlBC19].get('href')
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
		if not ekNMoIJzswUSDVQf564:
			ekoIKtMc4iFQAvs(apOKrFbP9IYHDyUVm7)
			return
		else:
			title = title.replace('قائمة ',eHdDoxhJCEPMZFVa2fg)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,512)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(jyquAFlGSpJg,511)
	return
def dCpDJKyatOq5AwvVo7iTY31lEBmMs(jyquAFlGSpJg,mode):
	cOUiow273ytu1GC5N0FJh = jyquAFlGSpJg.find(class_='pagination')
	if cOUiow273ytu1GC5N0FJh:
		XZieAqt65KEhc0jF9GdgPn = cOUiow273ytu1GC5N0FJh.find_all('a')
		pUIzkqhuEitRyvgH3C = cOUiow273ytu1GC5N0FJh.find_all('li')
		hhRZDTIcHLyVwjg8f05r1zEn7tCGuo = list(zip(XZieAqt65KEhc0jF9GdgPn,pUIzkqhuEitRyvgH3C))
		gMmB3iopS0ZXrOFewhcxt = -1
		R2apkdt0qg41 = len(hhRZDTIcHLyVwjg8f05r1zEn7tCGuo)
		for TTSQZBHtnbfOeLuxm3IqE,M54o8AgB1cbE620tNCvyYazePZid in hhRZDTIcHLyVwjg8f05r1zEn7tCGuo:
			gMmB3iopS0ZXrOFewhcxt += 1
			M54o8AgB1cbE620tNCvyYazePZid = M54o8AgB1cbE620tNCvyYazePZid['class']
			if 'unavailable' in M54o8AgB1cbE620tNCvyYazePZid or 'current' in M54o8AgB1cbE620tNCvyYazePZid: continue
			TR3DAb6GkCsva1 = TTSQZBHtnbfOeLuxm3IqE.text
			bmsN7D3kPQ8Beh5RS0M4ng2FcY = q3QVhZaDEuo8t2ASj5vkn+TTSQZBHtnbfOeLuxm3IqE.get('href')
			if lHfbysRrUV7m4CLSdkxc382n:
				TR3DAb6GkCsva1 = TR3DAb6GkCsva1.encode(m6PFtLblInpNZ8x)
				bmsN7D3kPQ8Beh5RS0M4ng2FcY = bmsN7D3kPQ8Beh5RS0M4ng2FcY.encode(m6PFtLblInpNZ8x)
			if   gMmB3iopS0ZXrOFewhcxt==0: TR3DAb6GkCsva1 = 'أولى'
			elif gMmB3iopS0ZXrOFewhcxt==1: TR3DAb6GkCsva1 = 'سابقة'
			elif gMmB3iopS0ZXrOFewhcxt==R2apkdt0qg41-2: TR3DAb6GkCsva1 = 'لاحقة'
			elif gMmB3iopS0ZXrOFewhcxt==R2apkdt0qg41-1: TR3DAb6GkCsva1 = 'أخيرة'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+TR3DAb6GkCsva1,bmsN7D3kPQ8Beh5RS0M4ng2FcY,mode)
	return
def ekoIKtMc4iFQAvs(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-TITLES1-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ekNMoIJzswUSDVQf564 = jyquAFlGSpJg.find_all(class_='row')
	items,HLjG0evOkWzBoa3F5UXdTi = [],True
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		if not cOUiow273ytu1GC5N0FJh.find(class_='thumbnail-wrapper'): continue
		if HLjG0evOkWzBoa3F5UXdTi: HLjG0evOkWzBoa3F5UXdTi = False ; continue
		qPVkaWQbmd6gJ4Ni5e = []
		n0jtMCIqp7aFR6WluZB = cOUiow273ytu1GC5N0FJh.find_all(class_=['censorship red','censorship purple'])
		for f9HedwrqYntvV0hyz in n0jtMCIqp7aFR6WluZB:
			FTiGWEHst5zpjKmwN1yRge = f9HedwrqYntvV0hyz.find_all('li')[1].text
			if lHfbysRrUV7m4CLSdkxc382n:
				FTiGWEHst5zpjKmwN1yRge = FTiGWEHst5zpjKmwN1yRge.encode(m6PFtLblInpNZ8x)
			qPVkaWQbmd6gJ4Ni5e.append(FTiGWEHst5zpjKmwN1yRge)
		if not ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,eHdDoxhJCEPMZFVa2fg,qPVkaWQbmd6gJ4Ni5e,False):
			e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('data-src')
			title = cOUiow273ytu1GC5N0FJh.find('h3')
			name = title.find('a').text
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+title.find('a').get('href')
			NYuiGTbpVxC60 = cOUiow273ytu1GC5N0FJh.find(class_='no-margin')
			k8gafbjYOXMGtr64W7qzp = cOUiow273ytu1GC5N0FJh.find(class_='legend')
			if NYuiGTbpVxC60: NYuiGTbpVxC60 = NYuiGTbpVxC60.text
			if k8gafbjYOXMGtr64W7qzp: k8gafbjYOXMGtr64W7qzp = k8gafbjYOXMGtr64W7qzp.text
			if lHfbysRrUV7m4CLSdkxc382n:
				e3XtKs70ifmRQY8VTLnpMdyr6 = e3XtKs70ifmRQY8VTLnpMdyr6.encode(m6PFtLblInpNZ8x)
				name = name.encode(m6PFtLblInpNZ8x)
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
				if NYuiGTbpVxC60: NYuiGTbpVxC60 = NYuiGTbpVxC60.encode(m6PFtLblInpNZ8x)
			ruWSoIZkeKA = {}
			if k8gafbjYOXMGtr64W7qzp: ruWSoIZkeKA['stars'] = k8gafbjYOXMGtr64W7qzp
			if NYuiGTbpVxC60:
				NYuiGTbpVxC60 = NYuiGTbpVxC60.replace(kDUv7ouWrcgMe6OipQJm,' .. ')
				ruWSoIZkeKA['plot'] = NYuiGTbpVxC60.replace('...اقرأ المزيد',eHdDoxhJCEPMZFVa2fg)
			if '/work/' in apOKrFbP9IYHDyUVm7:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,516,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA)
			elif '/person/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,513,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(jyquAFlGSpJg,512)
	return
def AASROZeMBrWp3y(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-TITLES2-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ekNMoIJzswUSDVQf564 = jyquAFlGSpJg.find_all('li')
	yZOpoR4Ph53fHFAJbzv,items = [],[]
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		if not cOUiow273ytu1GC5N0FJh.find(class_='thumbnail-wrapper'): continue
		if not cOUiow273ytu1GC5N0FJh.find(class_=['unstyled','unstyled text-center']): continue
		if cOUiow273ytu1GC5N0FJh.find(class_='hide'): continue
		title = cOUiow273ytu1GC5N0FJh.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in yZOpoR4Ph53fHFAJbzv: continue
		yZOpoR4Ph53fHFAJbzv.append(name)
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+title.find('a').get('href')
		if '/search/work/' in url: e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('src')
		elif '/search/person/' in url: e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('data-src')
		elif '/search/video/' in url: e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('data-src')
		else: e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('src')
		if lHfbysRrUV7m4CLSdkxc382n:
			name = name.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
			e3XtKs70ifmRQY8VTLnpMdyr6 = e3XtKs70ifmRQY8VTLnpMdyr6.encode(m6PFtLblInpNZ8x)
		name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		items.append((name,apOKrFbP9IYHDyUVm7,e3XtKs70ifmRQY8VTLnpMdyr6))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,apOKrFbP9IYHDyUVm7,e3XtKs70ifmRQY8VTLnpMdyr6 in items:
		if '/search/video/' in url: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,522,e3XtKs70ifmRQY8VTLnpMdyr6)
		elif '/search/person/' in url: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,513,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,516,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name)
	return
def R0kKNyjg7EavlqsX(text):
	text = text.replace('الإعلان',eHdDoxhJCEPMZFVa2fg).replace('لفيلم',eHdDoxhJCEPMZFVa2fg).replace('الرسمي',eHdDoxhJCEPMZFVa2fg)
	text = text.replace('إعلان',eHdDoxhJCEPMZFVa2fg).replace('فيلم',eHdDoxhJCEPMZFVa2fg).replace('البرومو',eHdDoxhJCEPMZFVa2fg)
	text = text.replace('التشويقي',eHdDoxhJCEPMZFVa2fg).replace('لمسلسل',eHdDoxhJCEPMZFVa2fg).replace('مسلسل',eHdDoxhJCEPMZFVa2fg)
	text = text.replace(':',eHdDoxhJCEPMZFVa2fg).replace(')',eHdDoxhJCEPMZFVa2fg).replace('(',eHdDoxhJCEPMZFVa2fg).replace(',',eHdDoxhJCEPMZFVa2fg)
	text = text.replace('_',eHdDoxhJCEPMZFVa2fg).replace(';',eHdDoxhJCEPMZFVa2fg).replace('-',eHdDoxhJCEPMZFVa2fg).replace('.',eHdDoxhJCEPMZFVa2fg)
	text = text.replace('\'',eHdDoxhJCEPMZFVa2fg).replace('\"',eHdDoxhJCEPMZFVa2fg)
	text = text.replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	text = text.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	or03Fk1JsX = text.count(avcfIls8w7gk69hYUErHxzQTXtm24j)+1
	if or03Fk1JsX==1:
		skqZ5fSIaxFCH(text)
		return
	qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	THtWFkg6bDlGRPwsN = text.split(avcfIls8w7gk69hYUErHxzQTXtm24j)
	eFgJ1RTrytqfaKEcdX3jvlPp9WbA = pow(2,or03Fk1JsX)
	dWT8c2lFeXUoE3nV7xgmqr = []
	def E5sokGQNyR6TCuv0miF9H(SZW6GRbrjFacLndM,MdADX78ZcjEt2g1uqiS09WQUJP):
		if SZW6GRbrjFacLndM=='1': return MdADX78ZcjEt2g1uqiS09WQUJP
		return eHdDoxhJCEPMZFVa2fg
	for gMmB3iopS0ZXrOFewhcxt in range(eFgJ1RTrytqfaKEcdX3jvlPp9WbA,0,-1):
		gDjlNOz6RuXTFA7CKtIZQyrc = list(or03Fk1JsX*'0'+bin(gMmB3iopS0ZXrOFewhcxt)[2:])[-or03Fk1JsX:]
		gDjlNOz6RuXTFA7CKtIZQyrc = reversed(gDjlNOz6RuXTFA7CKtIZQyrc)
		zbiGC4DUKEx = map(E5sokGQNyR6TCuv0miF9H,gDjlNOz6RuXTFA7CKtIZQyrc,THtWFkg6bDlGRPwsN)
		title = avcfIls8w7gk69hYUErHxzQTXtm24j.join(filter(None,zbiGC4DUKEx))
		if lHfbysRrUV7m4CLSdkxc382n: uVpKOk8ZM0LvQ6UI = title.decode(m6PFtLblInpNZ8x)
		else: uVpKOk8ZM0LvQ6UI = title
		if len(uVpKOk8ZM0LvQ6UI)>2 and title not in dWT8c2lFeXUoE3nV7xgmqr:
			dWT8c2lFeXUoE3nV7xgmqr.append(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,523,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,title)
	return
def skqZ5fSIaxFCH(BZsDGR7weXK):
	if lHfbysRrUV7m4CLSdkxc382n:
		BZsDGR7weXK = BZsDGR7weXK.decode(m6PFtLblInpNZ8x)
		import arabic_reshaper as eeyXdzvhHAKFRLwSiYBDU4kuxEnqb,bidi.algorithm as QQXsP3duLNJl5eK0ixBbcmwAo
		BZsDGR7weXK = eeyXdzvhHAKFRLwSiYBDU4kuxEnqb.ArabicReshaper().reshape(BZsDGR7weXK)
		BZsDGR7weXK = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(BZsDGR7weXK)
	import fdhmjHnwLQ
	BZsDGR7weXK = mJ1lHWKUPcZGezML7X2u9S(c5tymh3W6Ba1OP=BZsDGR7weXK)
	fdhmjHnwLQ.ZZG8yFCkvXnPTgR6Jc(BZsDGR7weXK)
	return
def T0iqCBb81kVj4(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-INDEXES_LISTS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	cOUiow273ytu1GC5N0FJh = jyquAFlGSpJg.find(class_='list-separator list-title')
	RnjhvEwkQqYtb94WpBxX5P = cOUiow273ytu1GC5N0FJh.find_all('a')
	items = []
	for title in RnjhvEwkQqYtb94WpBxX5P:
		name = title.text
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+title.get('href')
		if lHfbysRrUV7m4CLSdkxc382n:
			name = name.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
		if '#' not in apOKrFbP9IYHDyUVm7: items.append((name,apOKrFbP9IYHDyUVm7))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
		name,apOKrFbP9IYHDyUVm7 = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,518)
	return
def Tx8rUW3iI0OjQ7wtd6l5BpCzmg(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-INDEXES_TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ekNMoIJzswUSDVQf564 = jyquAFlGSpJg.find(class_='expand').find_all('tr')
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		HiAsWxX2LdnrMObS4jRh = cOUiow273ytu1GC5N0FJh.find_all('a')
		if not HiAsWxX2LdnrMObS4jRh: continue
		e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('data-src')
		name = HiAsWxX2LdnrMObS4jRh[1].text
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+HiAsWxX2LdnrMObS4jRh[1].get('href')
		k8gafbjYOXMGtr64W7qzp = cOUiow273ytu1GC5N0FJh.find(class_='legend')
		if k8gafbjYOXMGtr64W7qzp: k8gafbjYOXMGtr64W7qzp = k8gafbjYOXMGtr64W7qzp.text
		if lHfbysRrUV7m4CLSdkxc382n:
			name = name.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
			e3XtKs70ifmRQY8VTLnpMdyr6 = e3XtKs70ifmRQY8VTLnpMdyr6.encode(m6PFtLblInpNZ8x)
		ruWSoIZkeKA = {}
		if k8gafbjYOXMGtr64W7qzp: ruWSoIZkeKA['stars'] = k8gafbjYOXMGtr64W7qzp
		if '/work/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,516,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA)
		elif '/person/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+name,apOKrFbP9IYHDyUVm7,513,e3XtKs70ifmRQY8VTLnpMdyr6,eHdDoxhJCEPMZFVa2fg,name,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(jyquAFlGSpJg,518)
	return
def j9uWgcqDZ1s5UiHbQJ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-VIDEOS_LISTS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	RnjhvEwkQqYtb94WpBxX5P = jyquAFlGSpJg.find_all(class_='section-title inline')
	JCZVK86QTYwX4mfgOrod = jyquAFlGSpJg.find_all(class_='button green small right')
	items = zip(RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod)
	for title,apOKrFbP9IYHDyUVm7 in items:
		title = title.text
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7.get('href')
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
		title = title.replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,521)
	return
def PljuFY6X7k5Q2Ei4KMa8(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-VIDEOS_TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ZqPTa32lL7zGeIrHWDmti9OYCsQvRg = jyquAFlGSpJg.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	ekNMoIJzswUSDVQf564 = ZqPTa32lL7zGeIrHWDmti9OYCsQvRg.find_all('li')
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		title = cOUiow273ytu1GC5N0FJh.find(class_='title').text
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+cOUiow273ytu1GC5N0FJh.find('a').get('href')
		e3XtKs70ifmRQY8VTLnpMdyr6 = cOUiow273ytu1GC5N0FJh.find('img').get('data-src')
		WWPgm9fvlH2oIOnrD1 = cOUiow273ytu1GC5N0FJh.find(class_='duration').text
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.encode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
			e3XtKs70ifmRQY8VTLnpMdyr6 = e3XtKs70ifmRQY8VTLnpMdyr6.encode(m6PFtLblInpNZ8x)
			WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.encode(m6PFtLblInpNZ8x)
		WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,522,e3XtKs70ifmRQY8VTLnpMdyr6,WWPgm9fvlH2oIOnrD1)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(jyquAFlGSpJg,521)
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	apOKrFbP9IYHDyUVm7 = jyquAFlGSpJg.find(class_='flex-video').find('iframe').get('src')
	if lHfbysRrUV7m4CLSdkxc382n: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.encode(m6PFtLblInpNZ8x)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([apOKrFbP9IYHDyUVm7],EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/?q='+search
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-SEARCH-1st')
	if not aP8bLqZJsQlH3ivWKc.succeeded:
		V7ZHYcKbMl6dPqLOuS = q3QVhZaDEuo8t2ASj5vkn+'/search_entity/?q='+search+'&entity=work'
		bmsN7D3kPQ8Beh5RS0M4ng2FcY = q3QVhZaDEuo8t2ASj5vkn+'/search_entity/?q='+search+'&entity=person'
		RWksc38o1dJzAmeaQj7uGxbvKlZhUL = q3QVhZaDEuo8t2ASj5vkn+'/search_entity/?q='+search+'&entity=video'
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن أعمال',V7ZHYcKbMl6dPqLOuS,513,eHdDoxhJCEPMZFVa2fg,search)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن أشخاص',bmsN7D3kPQ8Beh5RS0M4ng2FcY,513,eHdDoxhJCEPMZFVa2fg,search)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن فيديوهات',RWksc38o1dJzAmeaQj7uGxbvKlZhUL,513,eHdDoxhJCEPMZFVa2fg,search)
		return
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	jyquAFlGSpJg = pkAFKlW7vxVq8Cdu2OrzInQNgPfHEc.BeautifulSoup(nR2B1Wye7luXb5,'html.parser',multi_valued_attributes=None)
	ekNMoIJzswUSDVQf564 = jyquAFlGSpJg.find_all(class_='section-title left')
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		title = cOUiow273ytu1GC5N0FJh.text
		if lHfbysRrUV7m4CLSdkxc382n:
			title = title.encode(m6PFtLblInpNZ8x)
		title = title.split('(',1)[0].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if   'أعمال' in title: apOKrFbP9IYHDyUVm7 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: apOKrFbP9IYHDyUVm7 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: apOKrFbP9IYHDyUVm7 = url.replace('/search/','/search/video/')
		else: continue
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,513)
	return
def ySvYgTHdL4cCQsbWhqADMzBNIVO0(url,text):
	global o7Dz5MbRWPmEeLVpiJ,WAUF7ftHbcrPEIDn1oyRMm95Td0YX
	if '/seasonals' in url:
		o7Dz5MbRWPmEeLVpiJ = ['seasonal','year','category']
		WAUF7ftHbcrPEIDn1oyRMm95Td0YX = ['seasonal','year','category']
	elif '/lineup' in url:
		o7Dz5MbRWPmEeLVpiJ = ['category','foreign','type']
		WAUF7ftHbcrPEIDn1oyRMm95Td0YX = ['category','foreign','type']
	bbkDE5p9zlX6aV(url,text)
	return
def FADrXnGJYOuZlzU4t(url):
	url = url.split('/smartemadfilter?')[0]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('form action="/(.*?)</form>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = cBawilJXvK1m.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	return IVnCEBUYx5s3oleJkmdr2zWa0Ni
def SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh):
	items = cBawilJXvK1m.findall('<option value="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	return items
def P6KuOCM0b5vf3DAmH2YZRa(url):
	gXxmlY6uF78d4pHVhSMKyUCae2f = url.split('/smartemadfilter?')[0]
	qGa7FvNptsk = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def fs2a41hl58xoCQnZm3bLB(e2mXDvCIA45Hp81FPKhaiWJGuM,url):
	jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(e2mXDvCIA45Hp81FPKhaiWJGuM,'all_filters')
	ajHR9ABQl2buvm = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	ajHR9ABQl2buvm = P6KuOCM0b5vf3DAmH2YZRa(ajHR9ABQl2buvm)
	return ajHR9ABQl2buvm
def bbkDE5p9zlX6aV(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==eHdDoxhJCEPMZFVa2fg: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	else: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if o7Dz5MbRWPmEeLVpiJ[0]+'=' not in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = o7Dz5MbRWPmEeLVpiJ[0]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(o7Dz5MbRWPmEeLVpiJ[0:-1])):
			if o7Dz5MbRWPmEeLVpiJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'=' in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = o7Dz5MbRWPmEeLVpiJ[dhcGSyo8Kn1mHZwvEAkzJ7NUq+1]
		aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+U3d2hkuwDIj56+'=0'
		e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+U3d2hkuwDIj56+'=0'
		r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7.strip('&')+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM.strip('&')
		jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	elif type=='ALL_ITEMS_FILTER':
		aSF3HMlugcs9G7Yz = QRKwbZae0G3m(goUS2aiGbZX1OQ,'modified_values')
		aSF3HMlugcs9G7Yz = zrHeZWCqQMOymk1d7anKpu0vEx8(aSF3HMlugcs9G7Yz)
		if JVw3Ug6xQykdj2oM50!=eHdDoxhJCEPMZFVa2fg: JVw3Ug6xQykdj2oM50 = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		if JVw3Ug6xQykdj2oM50==eHdDoxhJCEPMZFVa2fg: E1Viom5L3684CTOFJ = url
		else: E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+JVw3Ug6xQykdj2oM50
		E1Viom5L3684CTOFJ = P6KuOCM0b5vf3DAmH2YZRa(E1Viom5L3684CTOFJ)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أظهار قائمة الفيديو التي تم اختيارها ',E1Viom5L3684CTOFJ,511)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' [[   '+aSF3HMlugcs9G7Yz+'   ]]',E1Viom5L3684CTOFJ,511)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = FADrXnGJYOuZlzU4t(url)
	dict = {}
	for name,BYy2jD5CQfh3rdxTAFzJ84Vk6E,cOUiow273ytu1GC5N0FJh in IVnCEBUYx5s3oleJkmdr2zWa0Ni:
		name = name.replace('--',eHdDoxhJCEPMZFVa2fg)
		items = SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh)
		if '=' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = url
		if type=='SPECIFIED_FILTER':
			if BYy2jD5CQfh3rdxTAFzJ84Vk6E not in o7Dz5MbRWPmEeLVpiJ: continue
			if U3d2hkuwDIj56!=BYy2jD5CQfh3rdxTAFzJ84Vk6E: continue
			elif len(items)<2:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==o7Dz5MbRWPmEeLVpiJ[-1]:
					url = P6KuOCM0b5vf3DAmH2YZRa(url)
					ekoIKtMc4iFQAvs(url)
				else: bbkDE5p9zlX6aV(E1Viom5L3684CTOFJ,'SPECIFIED_FILTER___'+r3bWKiRBqwE54ayCf0utvhDlx)
				return
			else:
				E1Viom5L3684CTOFJ = P6KuOCM0b5vf3DAmH2YZRa(E1Viom5L3684CTOFJ)
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==o7Dz5MbRWPmEeLVpiJ[-1]: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',E1Viom5L3684CTOFJ,511)
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',E1Viom5L3684CTOFJ,515,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		elif type=='ALL_ITEMS_FILTER':
			if BYy2jD5CQfh3rdxTAFzJ84Vk6E not in WAUF7ftHbcrPEIDn1oyRMm95Td0YX: continue
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع: '+name,E1Viom5L3684CTOFJ,514,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E] = {}
		for q5qDOCzEe0Lv4ZyJbWnaPcpVsB,gW0v8nMxdq2 in items:
			if gW0v8nMxdq2 in IVD2kBKhW8FeQLvxUm: continue
			if 'مصنفات أخرى' in gW0v8nMxdq2: continue
			if 'الكل' in gW0v8nMxdq2: continue
			if 'اللغة' in gW0v8nMxdq2: continue
			gW0v8nMxdq2 = gW0v8nMxdq2.replace('قائمة ',eHdDoxhJCEPMZFVa2fg)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E][q5qDOCzEe0Lv4ZyJbWnaPcpVsB] = gW0v8nMxdq2
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+gW0v8nMxdq2
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			nSjP8erv4yop = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			if name: title = gW0v8nMxdq2+' :'+name
			else: title = gW0v8nMxdq2
			if type=='ALL_ITEMS_FILTER': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,514,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
			elif type=='SPECIFIED_FILTER' and o7Dz5MbRWPmEeLVpiJ[-2]+'=' in goUS2aiGbZX1OQ:
				ajHR9ABQl2buvm = fs2a41hl58xoCQnZm3bLB(e2mXDvCIA45Hp81FPKhaiWJGuM,url)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,ajHR9ABQl2buvm,511)
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,515,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
	return
def QRKwbZae0G3m(yTtrwivOXY68ECP7ZHQgNdJ1,mode):
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.replace('=&','=0&')
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.strip('&')
	f8TRa4pzuVmo7c9gZ1j6rtPYOXqe = {}
	if '=' in yTtrwivOXY68ECP7ZHQgNdJ1:
		items = yTtrwivOXY68ECP7ZHQgNdJ1.split('&')
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			WW4LlMgICSbVYDfXKQdtzik,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split('=')
			f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[WW4LlMgICSbVYDfXKQdtzik] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = eHdDoxhJCEPMZFVa2fg
	for key in WAUF7ftHbcrPEIDn1oyRMm95Td0YX:
		if key in list(f8TRa4pzuVmo7c9gZ1j6rtPYOXqe.keys()): q5qDOCzEe0Lv4ZyJbWnaPcpVsB = f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[key]
		else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = '0'
		if '%' not in q5qDOCzEe0Lv4ZyJbWnaPcpVsB: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = vFDQstemyYANa(q5qDOCzEe0Lv4ZyJbWnaPcpVsB)
		if mode=='modified_values' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+' + '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='modified_filters' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='all_filters': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip(' + ')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip('&')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.replace('=0','=')
	return Q2OrNnmvR5HfY
o7Dz5MbRWPmEeLVpiJ = []
WAUF7ftHbcrPEIDn1oyRMm95Td0YX = []
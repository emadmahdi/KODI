# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'LODYNET'
ToYWiIbruzUaNKRPZLG16cAj = '_LDN_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['الرئيسية','استفسارتكم و الطلبات']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==450: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==451: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==452: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==453: rr60PDpqbMehZsYVuHmiAtN = Zo7UmLDVAaduH2IC9xTQbqcXjNh(url)
	elif mode==454: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==459: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','LODYNET-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(aaeRjxiYcqOI6Sf8,'url')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',459,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مثبتات لودي نت',BdSZn7YxiHaUcf1Rzt5o,451,'','','featured')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المضاف حديثا',BdSZn7YxiHaUcf1Rzt5o,451,'','','latest')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"MainMenu"(.*?)"SiteSlider"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if ZcAK0askvzIWr4R=='#': continue
			if title in C1pRb6K8Qs: continue
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,451)
	return
def KKlnDcetq8Rrp3GY0(url,YGBW78utSU1gJ0pD=''):
	items = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','LODYNET-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if YGBW78utSU1gJ0pD=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"SiteSlider"(.*?)"waves"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif YGBW78utSU1gJ0pD=='latest':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"RecentPosts"(.*?)"pagination"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif '"ActorsList"' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"ActorsList"(.*?)"text/javascript"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif YGBW78utSU1gJ0pD in ['0','1','2']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Section"(.*?)</li></ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[int(YGBW78utSU1gJ0pD)]
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"BlocksArea"(.*?)"text/javascript"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not items: items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if '"ActorsList"' in BsJ71WIxDtdFKveTcRPrqM4Cwb and 'src=' in pjMZ802XQCSxYVk:
			pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('src="(.*?)"',pjMZ802XQCSxYVk,SomeI8i56FaDMGPE.DOTALL)
			pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) حلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if not iHPhR4wCQ1oINaL: iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if set(title.split()) & set(W2XL1cnGkuqaZx) and 'مسلسل' not in title:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,452,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'حلقة' in title:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,453,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,453,pjMZ802XQCSxYVk)
	if YGBW78utSU1gJ0pD in ['','latest']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,451)
	return
def Zo7UmLDVAaduH2IC9xTQbqcXjNh(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','LODYNET-SEASONS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"CategorySubLinks"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and 'href=' in str(q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ):
		title = SomeI8i56FaDMGPE.findall('<title>(.*?)-',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		title = title[0].strip(' ')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,454)
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,454)
	else: ooLCwrlF3n0vBjpA(url)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','LODYNET-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"BlocksArea"(.*?)"text/javascript"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,452,pjMZ802XQCSxYVk)
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,454)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/movies/','/watch_movies/')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace('/episodes/','/watch_episodes/')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','LODYNET-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"WatchTitle"(.*?)</aside>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-embed="(.*?)">(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"DownloadLinks"(.*?)"selary"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name in items:
			name = dCFP41Kxv9j8EHM(name)
			AfejZJoKh4D7k5G1P9gCwxTz = SomeI8i56FaDMGPE.findall('\d\d\d+',name,SomeI8i56FaDMGPE.DOTALL)
			if AfejZJoKh4D7k5G1P9gCwxTz:
				AfejZJoKh4D7k5G1P9gCwxTz = '____'+AfejZJoKh4D7k5G1P9gCwxTz[0]
				name = ''
			else: AfejZJoKh4D7k5G1P9gCwxTz = ''
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+name+'__download'+AfejZJoKh4D7k5G1P9gCwxTz
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search/'+search
	KKlnDcetq8Rrp3GY0(url)
	return
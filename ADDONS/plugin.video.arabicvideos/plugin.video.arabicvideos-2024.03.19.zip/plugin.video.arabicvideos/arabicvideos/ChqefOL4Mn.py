# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
headers = { 'User-Agent' : '' }
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'AKOAMCAM'
ToYWiIbruzUaNKRPZLG16cAj = '_AKC_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['مصارعة']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==350: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==351: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==352: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==353: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==354: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FILTERS___'+text)
	elif mode==355: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'CATEGORIES___'+text)
	elif mode==356: rr60PDpqbMehZsYVuHmiAtN = d1khRjeU3XYs5IT069Kb(url)
	elif mode==357: rr60PDpqbMehZsYVuHmiAtN = f3vj2GuqF4A1NhKO(url)
	elif mode==359: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',aaeRjxiYcqOI6Sf8,356)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',aaeRjxiYcqOI6Sf8,357)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,aaeRjxiYcqOI6Sf8,'',headers,'','AKOAMCAM-MENU-1st')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('recently-container.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'اضيف حديثا',vfIB6ib8q1hFX5GweRrVPNTjY2E,351)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('@id":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',vfIB6ib8q1hFX5GweRrVPNTjY2E,351,'','','featured')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-categories-list(.*?)main-categories-list',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?class="font.*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,351)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="categories-box(.*?)<footer',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
			if title not in C1pRb6K8Qs: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,351)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def d1khRjeU3XYs5IT069Kb(website=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','AKOAMCAM-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu(.*?)<nav',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?text">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs:
				title = title+' مصنفة'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,355)
		if website=='': UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def f3vj2GuqF4A1NhKO(website=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','AKOAMCAM-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu(.*?)<nav',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?text">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs:
				title = title+' مفلترة'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,354)
		if website=='': UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(fyIAplJLe9MGiPosBvrEOtZUm6,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('swiper-container(.*?)swiper-button-prev',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="container"(.*?)main-footer',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		oojL40IJtK = []
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|الحلقه) \d+',title,SomeI8i56FaDMGPE.DOTALL)
				if iHPhR4wCQ1oINaL:
					title = '_MOD_' + iHPhR4wCQ1oINaL[0][0]
					if title not in oojL40IJtK:
						UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,352,pjMZ802XQCSxYVk)
						oojL40IJtK.append(title)
			elif 'مسلسل' in title:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,352,pjMZ802XQCSxYVk)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,353,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href=["\'](.*?)["\'].*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,351)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + '/?s='+u9DhgpinLBfmjG3NtMalq7Y
	rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	return
def ooLCwrlF3n0vBjpA(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('text-white">الحلقات(.*?)<header',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		gbRaTlfw5quES79COD2yPhJXzie6 = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in gbRaTlfw5quES79COD2yPhJXzie6:
			if 'الحلقة' in title or 'الحلقه' in title: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,353,pjMZ802XQCSxYVk)
	else:
		pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Icon')
		if BsJ71WIxDtdFKveTcRPrqM4Cwb.count('<title>')>1: title = SomeI8i56FaDMGPE.findall('<title>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[1]
		else: title = 'رابط التشغيل'
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,353,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD = [],[]
	B5oeMHl2w3NEsyPQfmSL7hnWRp = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = B5oeMHl2w3NEsyPQfmSL7hnWRp.content
	mm6xWVDlReK7d = SomeI8i56FaDMGPE.findall('post_id=(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if mm6xWVDlReK7d:
		mm6xWVDlReK7d = mm6xWVDlReK7d[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':mm6xWVDlReK7d}
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		xr70XZVK43Fbdwh5YBQyIzo6P8L = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,data,headers,'','','AKOAMCAM-PLAY-1st')
		ppq6Bg4vPbVs = xr70XZVK43Fbdwh5YBQyIzo6P8L.content
		items = SomeI8i56FaDMGPE.findall('data-server="(.*?)".*?class="text">(.*?)<',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		for YcBS69pDzGFTlHE,name in items:
			ZcAK0askvzIWr4R = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?postid='+mm6xWVDlReK7d+'&serverid='+YcBS69pDzGFTlHE+'?named='+name+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			r79xJG6jXHD.append(name)
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		xr70XZVK43Fbdwh5YBQyIzo6P8L = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,data,headers,'','','AKOAMCAM-PLAY-1st')
		ppq6Bg4vPbVs = xr70XZVK43Fbdwh5YBQyIzo6P8L.content
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?class="text">(.*?)<',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.strip(' ')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			r79xJG6jXHD.append(title)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	tE62imyGZoBe = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='CATEGORIES':
		if tE62imyGZoBe[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[0]
		for zz5ZOaoyATpS893tvdXE in range(len(tE62imyGZoBe[0:-1])):
			if tE62imyGZoBe[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FILTERS':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها',vfIB6ib8q1hFX5GweRrVPNTjY2E,351,'','1')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',vfIB6ib8q1hFX5GweRrVPNTjY2E,351,'','1')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<form id(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	dict = {}
	for mjcA3DUe9IJV4bk,name,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		items = SomeI8i56FaDMGPE.findall('<option(.*?)>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='CATEGORIES':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<=1:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'CATEGORIES___'+ecMSxgw2QqpvI)
				return
			else:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,351,'','1')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,355,'','',ecMSxgw2QqpvI)
		elif type=='FILTERS':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع : '+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,354,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			if 'value' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = irE1qv3BUYZMo5
			else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = SomeI8i56FaDMGPE.findall('"(.*?)"',EPwT39HrS1tU6Ng8YBGpJADixzLV5C,SomeI8i56FaDMGPE.DOTALL)[0]
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' : '#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' : '+name
			if type=='FILTERS': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,354,'','',L6iYCRsI1U4ytrW)
			elif type=='CATEGORIES' and tE62imyGZoBe[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'all')
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,351,'','1')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,355,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	JR6bW8Bc7ig = ['cat','genre','release-year','quality','orderby']
	for key in JR6bW8Bc7ig:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	return y4rSdac1zC26FA9IZnuO7WRU
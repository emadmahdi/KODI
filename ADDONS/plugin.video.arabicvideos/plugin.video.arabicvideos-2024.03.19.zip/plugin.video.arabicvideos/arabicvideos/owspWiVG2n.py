# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = eaF2N0jWLdvHIs8r(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
ToYWiIbruzUaNKRPZLG16cAj = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
VzQIBqvCd17JyOWo5g = Dh9MOxeTj6FW.path.join(COjW7yrR8DhcLg4IadwBU,IPkQW7LojF3HO18V(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ppe3WvYK7D = Dh9MOxeTj6FW.path.join(COjW7yrR8DhcLg4IadwBU,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
VDMZGlXES6f = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,eaF2N0jWLdvHIs8r(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),hxSBTdGpyNVbfu4tr9(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
KvdTINjy5g = aDtrsUMWmguPoJHSE9qi2
cPEAdiaR3h8u5vFBTSGsKD = Jbu2G0Qax8PYWpg(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
HtilD1fJm4koRYZTGh7CM9UPSa2 = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
txf6zY2RilG7Z5yQLrC = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
ohIvQu4EObgedt3Jk1 = Y5npATFarf1H9wBjc87(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
yTeYAkDCqdLK9pUxh6 = Q2ZyGqCNYsftTc4MR7n(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
X0eP9l4sZfotjQyOLVp3 = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def GI13aCFr0qimdOT(mode):
	if   lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠹࠷࠴ࣉ"): rr60PDpqbMehZsYVuHmiAtN = Yp2jF15CH3tZgrUiInOm()
	elif lOH3hXsnQiFCRjbN12==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠺࠸࠶࣊"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(VzQIBqvCd17JyOWo5g,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡖࡵࡹࡪࣳ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡖࡵࡹࡪࣳ"))
	elif lOH3hXsnQiFCRjbN12==Rz34c0NP5BGo1WuTZxSfOKj(u"࠻࠹࠸࣋"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(ppe3WvYK7D,d0HDrq8Rtk16AlInw4TXb(u"ࡗࡶࡺ࡫ࣴ"),d0HDrq8Rtk16AlInw4TXb(u"ࡗࡶࡺ࡫ࣴ"))
	elif lOH3hXsnQiFCRjbN12==Jbu2G0Qax8PYWpg(u"࠼࠺࠳࣌"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(VDMZGlXES6f,IPkQW7LojF3HO18V(u"ࡋࡧ࡬ࡴࡧࣶ"),lh6URegmQNq8LWX0HaK5(u"ࡘࡷࡻࡥࣵ"))
	elif lOH3hXsnQiFCRjbN12==gy9NA3CROZolfEt4vVzMr(u"࠽࠴࠵࣍"): rr60PDpqbMehZsYVuHmiAtN = SSjxuWINHrzsg8o3hQ(KvdTINjy5g,Jbu2G0Qax8PYWpg(u"࡚ࡲࡶࡧࣷ"))
	elif lOH3hXsnQiFCRjbN12==onweDvmTOUj(u"࠷࠵࠷࣎"): rr60PDpqbMehZsYVuHmiAtN = jfTMXsUqYctu1A3dmg9Gb(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡔࡳࡷࡨࣸ"))
	elif lOH3hXsnQiFCRjbN12==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠸࠷࠳࣏"): rr60PDpqbMehZsYVuHmiAtN = DIy9r3lcRTw7m0O()
	elif lOH3hXsnQiFCRjbN12==LsG7EDcei1gMShH2aVOCo(u"࠹࠸࠵࣐"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(cPEAdiaR3h8u5vFBTSGsKD,mtEXp14ijx(u"ࡈࡤࡰࡸ࡫ࣺ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࡕࡴࡸࡩࣹ"))
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠺࠹࠷࣑"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(HtilD1fJm4koRYZTGh7CM9UPSa2,gy9NA3CROZolfEt4vVzMr(u"ࡊࡦࡲࡳࡦࣼ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡗࡶࡺ࡫ࣻ"))
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠻࠺࠹࣒"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(txf6zY2RilG7Z5yQLrC,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡌࡡ࡭ࡵࡨࣾ"),lh6URegmQNq8LWX0HaK5(u"࡙ࡸࡵࡦࣽ"))
	elif lOH3hXsnQiFCRjbN12==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠼࠻࠴࣓"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(ohIvQu4EObgedt3Jk1,gy9NA3CROZolfEt4vVzMr(u"ࡇࡣ࡯ࡷࡪऀ"),Sj1PYDmIpCUXO26(u"ࡔࡳࡷࡨࣿ"))
	elif lOH3hXsnQiFCRjbN12==gy9NA3CROZolfEt4vVzMr(u"࠽࠵࠶ࣔ"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(yTeYAkDCqdLK9pUxh6,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡉࡥࡱࡹࡥं"),Q2ZyGqCNYsftTc4MR7n(u"ࡖࡵࡹࡪँ"))
	elif lOH3hXsnQiFCRjbN12==hxSBTdGpyNVbfu4tr9(u"࠷࠶࠸ࣕ"): rr60PDpqbMehZsYVuHmiAtN = IlTEWy8f4bpjLa7UR0c2qDY6S15Q(X0eP9l4sZfotjQyOLVp3,IPkQW7LojF3HO18V(u"ࡋࡧ࡬ࡴࡧऄ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࡘࡷࡻࡥः"))
	elif lOH3hXsnQiFCRjbN12==OnvTrikzfEsY7qU8pgaRBtZy(u"࠸࠷࠺ࣖ"): rr60PDpqbMehZsYVuHmiAtN = TcNU8GP0LVF7ubaeR5JAyM(IPkQW7LojF3HO18V(u"࡚ࡲࡶࡧअ"))
	elif lOH3hXsnQiFCRjbN12==Sj1PYDmIpCUXO26(u"࠹࠸࠼ࣗ"): rr60PDpqbMehZsYVuHmiAtN = LPqmKcbvBQOXkayCV()
	else: rr60PDpqbMehZsYVuHmiAtN = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡆࡢ࡮ࡶࡩआ")
	return rr60PDpqbMehZsYVuHmiAtN
def Yp2jF15CH3tZgrUiInOm():
	zL4NgZauo8j5h1yOSdW2p,Ev4juIUTHtDqQhnX = waBQd8iEUAODXRJulSgPsHNb0(VzQIBqvCd17JyOWo5g)
	eAip8j6GyZ,rEwbAFfU6TozaiV39Hj5lL = waBQd8iEUAODXRJulSgPsHNb0(ppe3WvYK7D)
	Jl1NpAqiMac5Q6jev8bHF4hVGDr,lKNoz6wZCgLJbO = waBQd8iEUAODXRJulSgPsHNb0(VDMZGlXES6f)
	dm9IlW43nOyaBL7Jp1jTbQf50rD,U2t0VZDgJWsTdbKnp3o1zR5OPa = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(KvdTINjy5g)
	dm9IlW43nOyaBL7Jp1jTbQf50rD -= gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠺࠽࠼࠴ࣘ")
	U2t0VZDgJWsTdbKnp3o1zR5OPa -= RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠵ࣙ")
	IM0OJWo2Ef3ga6nrS = d0HDrq8Rtk16AlInw4TXb(u"ࠩࠣࠬࠬࠌ")+zic8FXKmaZ5kOepsHPNLj9dG(zL4NgZauo8j5h1yOSdW2p)+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࠤ࠲ࠦࠧࠍ")+str(Ev4juIUTHtDqQhnX)+RS7ZoyGAq1c(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	zawksMKvuS = B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࠦࠨࠨࠏ")+zic8FXKmaZ5kOepsHPNLj9dG(eAip8j6GyZ)+eaF2N0jWLdvHIs8r(u"࠭ࠠ࠮ࠢࠪࠐ")+str(rEwbAFfU6TozaiV39Hj5lL)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	TqfupLx1VejQN6nzyiHvoO5wd8U = mtEXp14ijx(u"ࠨࠢࠫࠫࠒ")+zic8FXKmaZ5kOepsHPNLj9dG(Jl1NpAqiMac5Q6jev8bHF4hVGDr)+Y5npATFarf1H9wBjc87(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(lKNoz6wZCgLJbO)+RS7ZoyGAq1c(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	YSr7Gq3EjLAV2JvM1tn5UPKZWw = hxSBTdGpyNVbfu4tr9(u"ࠫࠥ࠮ࠧࠕ")+zic8FXKmaZ5kOepsHPNLj9dG(dm9IlW43nOyaBL7Jp1jTbQf50rD)+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬ࠯ࠧࠖ")
	ffIg3vtxK2zjs6mZbBupoeQYGTPVL = zL4NgZauo8j5h1yOSdW2p+eAip8j6GyZ+Jl1NpAqiMac5Q6jev8bHF4hVGDr+dm9IlW43nOyaBL7Jp1jTbQf50rD
	P12PCQDTINg = Ev4juIUTHtDqQhnX+rEwbAFfU6TozaiV39Hj5lL+lKNoz6wZCgLJbO+U2t0VZDgJWsTdbKnp3o1zR5OPa
	yy42JUqszVIO89i = FZBX5WcC3msIDv4hobLd8(u"࠭ࠠࠩࠩࠗ")+zic8FXKmaZ5kOepsHPNLj9dG(ffIg3vtxK2zjs6mZbBupoeQYGTPVL)+onweDvmTOUj(u"ࠧࠡ࠯ࠣࠫ࠘")+str(P12PCQDTINg)+Sj1PYDmIpCUXO26(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	UZ8LYnm5jsl9uKM0xDX(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),ToYWiIbruzUaNKRPZLG16cAj+Q2ZyGqCNYsftTc4MR7n(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+yy42JUqszVIO89i,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠬࠜ"),Q2ZyGqCNYsftTc4MR7n(u"࠼࠺࠵ࣚ"))
	UZ8LYnm5jsl9uKM0xDX(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨࠟ"),IPkQW7LojF3HO18V(u"࠿࠹࠺࠻ࣛ"))
	UZ8LYnm5jsl9uKM0xDX(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),ToYWiIbruzUaNKRPZLG16cAj+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+IM0OJWo2Ef3ga6nrS,onweDvmTOUj(u"ࠪࠫࠢ"),LsG7EDcei1gMShH2aVOCo(u"࠷࠵࠳ࣜ"))
	UZ8LYnm5jsl9uKM0xDX(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),ToYWiIbruzUaNKRPZLG16cAj+gy9NA3CROZolfEt4vVzMr(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+zawksMKvuS,MOwK1lpyNfCgqksX3jhV(u"࠭ࠧࠥ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠸࠶࠵ࣝ"))
	UZ8LYnm5jsl9uKM0xDX(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),ToYWiIbruzUaNKRPZLG16cAj+gy9NA3CROZolfEt4vVzMr(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+TqfupLx1VejQN6nzyiHvoO5wd8U,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࠪࠨ"),lh6URegmQNq8LWX0HaK5(u"࠹࠷࠷ࣞ"))
	UZ8LYnm5jsl9uKM0xDX(mtEXp14ijx(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),ToYWiIbruzUaNKRPZLG16cAj+onweDvmTOUj(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+YSr7Gq3EjLAV2JvM1tn5UPKZWw,Y5npATFarf1H9wBjc87(u"ࠬ࠭ࠫ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠺࠸࠹ࣟ"))
	LCIFdjzi5kVmRwehouHQ.setSetting(Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨ࠭"))
	return
def DIy9r3lcRTw7m0O():
	KnR8ODL4mT0jEVYgcyaBFfv6tPh = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡖࡵࡹࡪई") if nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࠱ࠪ࠮") in mKdhSjzZPWany else onweDvmTOUj(u"ࡇࡣ࡯ࡷࡪइ")
	if not KnR8ODL4mT0jEVYgcyaBFfv6tPh:
		ztgqWUaDpe8CE9N(MOwK1lpyNfCgqksX3jhV(u"ࠩࠪ࠯"),onweDvmTOUj(u"ࠪࠫ࠰"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),IPkQW7LojF3HO18V(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	sF0NOtG4b1RY = LCIFdjzi5kVmRwehouHQ.getSetting(B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not sF0NOtG4b1RY: LPqmKcbvBQOXkayCV()
	zL4NgZauo8j5h1yOSdW2p,Ev4juIUTHtDqQhnX = waBQd8iEUAODXRJulSgPsHNb0(cPEAdiaR3h8u5vFBTSGsKD)
	eAip8j6GyZ,rEwbAFfU6TozaiV39Hj5lL = waBQd8iEUAODXRJulSgPsHNb0(HtilD1fJm4koRYZTGh7CM9UPSa2)
	Jl1NpAqiMac5Q6jev8bHF4hVGDr,lKNoz6wZCgLJbO = waBQd8iEUAODXRJulSgPsHNb0(txf6zY2RilG7Z5yQLrC)
	dm9IlW43nOyaBL7Jp1jTbQf50rD,U2t0VZDgJWsTdbKnp3o1zR5OPa = waBQd8iEUAODXRJulSgPsHNb0(ohIvQu4EObgedt3Jk1)
	y9ycI0ATjo6uEDN,aPIEqC3r5xnBLNmWAjpdsVQMG = waBQd8iEUAODXRJulSgPsHNb0(yTeYAkDCqdLK9pUxh6)
	NAws7fISMKkhRqtdOr8Q0Ec1u,A8AlDL4NSofkmwRI2hJqOcnUPZ = waBQd8iEUAODXRJulSgPsHNb0(X0eP9l4sZfotjQyOLVp3)
	IM0OJWo2Ef3ga6nrS = Sj1PYDmIpCUXO26(u"ࠧࠡࠪࠪ࠴")+zic8FXKmaZ5kOepsHPNLj9dG(zL4NgZauo8j5h1yOSdW2p)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠢ࠰ࠤࠬ࠵")+str(Ev4juIUTHtDqQhnX)+eaF2N0jWLdvHIs8r(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	zawksMKvuS = hxSBTdGpyNVbfu4tr9(u"ࠪࠤ࠭࠭࠷")+zic8FXKmaZ5kOepsHPNLj9dG(eAip8j6GyZ)+d0HDrq8Rtk16AlInw4TXb(u"ࠫࠥ࠳ࠠࠨ࠸")+str(rEwbAFfU6TozaiV39Hj5lL)+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	TqfupLx1VejQN6nzyiHvoO5wd8U = B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࠠࠩࠩ࠺")+zic8FXKmaZ5kOepsHPNLj9dG(Jl1NpAqiMac5Q6jev8bHF4hVGDr)+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࠡ࠯ࠣࠫ࠻")+str(lKNoz6wZCgLJbO)+d0HDrq8Rtk16AlInw4TXb(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	YSr7Gq3EjLAV2JvM1tn5UPKZWw = NQ4hg16DPUxtOyo5iGb(u"ࠩࠣࠬࠬ࠽")+zic8FXKmaZ5kOepsHPNLj9dG(dm9IlW43nOyaBL7Jp1jTbQf50rD)+hxSBTdGpyNVbfu4tr9(u"ࠪࠤ࠲ࠦࠧ࠾")+str(U2t0VZDgJWsTdbKnp3o1zR5OPa)+Y5npATFarf1H9wBjc87(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	k4kFg6wdIzfQmZ = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࠦࠨࠨࡀ")+zic8FXKmaZ5kOepsHPNLj9dG(y9ycI0ATjo6uEDN)+Y5npATFarf1H9wBjc87(u"࠭ࠠ࠮ࠢࠪࡁ")+str(aPIEqC3r5xnBLNmWAjpdsVQMG)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	rnJI9WQ32KY57fZ0DpwFg4heGuTXV = eaF2N0jWLdvHIs8r(u"ࠨࠢࠫࠫࡃ")+zic8FXKmaZ5kOepsHPNLj9dG(NAws7fISMKkhRqtdOr8Q0Ec1u)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(A8AlDL4NSofkmwRI2hJqOcnUPZ)+Y5npATFarf1H9wBjc87(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	ffIg3vtxK2zjs6mZbBupoeQYGTPVL = zL4NgZauo8j5h1yOSdW2p+eAip8j6GyZ+Jl1NpAqiMac5Q6jev8bHF4hVGDr+dm9IlW43nOyaBL7Jp1jTbQf50rD+y9ycI0ATjo6uEDN+NAws7fISMKkhRqtdOr8Q0Ec1u
	P12PCQDTINg = Ev4juIUTHtDqQhnX+rEwbAFfU6TozaiV39Hj5lL+lKNoz6wZCgLJbO+U2t0VZDgJWsTdbKnp3o1zR5OPa+aPIEqC3r5xnBLNmWAjpdsVQMG+A8AlDL4NSofkmwRI2hJqOcnUPZ
	yy42JUqszVIO89i = hxSBTdGpyNVbfu4tr9(u"ࠫࠥ࠮ࠧࡆ")+zic8FXKmaZ5kOepsHPNLj9dG(ffIg3vtxK2zjs6mZbBupoeQYGTPVL)+QQSULIva4ljNO73mFcWw(u"ࠬࠦ࠭ࠡࠩࡇ")+str(P12PCQDTINg)+gy9NA3CROZolfEt4vVzMr(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	UZ8LYnm5jsl9uKM0xDX(Q2ZyGqCNYsftTc4MR7n(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),ToYWiIbruzUaNKRPZLG16cAj+Jbu2G0Qax8PYWpg(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࠪࡋ"),mtEXp14ijx(u"࠻࠺࠾࣠"))
	UZ8LYnm5jsl9uKM0xDX(MOwK1lpyNfCgqksX3jhV(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),ToYWiIbruzUaNKRPZLG16cAj+Jbu2G0Qax8PYWpg(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+yy42JUqszVIO89i,MOwK1lpyNfCgqksX3jhV(u"ࠬ࠭ࡎ"),Sj1PYDmIpCUXO26(u"࠼࠻࠷࣡"))
	UZ8LYnm5jsl9uKM0xDX(Jbu2G0Qax8PYWpg(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠩࡑ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠿࠹࠺࠻࣢"))
	UZ8LYnm5jsl9uKM0xDX(IPkQW7LojF3HO18V(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),ToYWiIbruzUaNKRPZLG16cAj+B2vCEI9FAVP15R8eUbDJdySc(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+IM0OJWo2Ef3ga6nrS,IPkQW7LojF3HO18V(u"ࠫࠬࡔ"),RS7ZoyGAq1c(u"࠷࠶࠳ࣣ"))
	UZ8LYnm5jsl9uKM0xDX(NQ4hg16DPUxtOyo5iGb(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),ToYWiIbruzUaNKRPZLG16cAj+Jbu2G0Qax8PYWpg(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+zawksMKvuS,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࠨࡗ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠸࠷࠵ࣤ"))
	UZ8LYnm5jsl9uKM0xDX(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),ToYWiIbruzUaNKRPZLG16cAj+mtEXp14ijx(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+TqfupLx1VejQN6nzyiHvoO5wd8U,gy9NA3CROZolfEt4vVzMr(u"࡚ࠪࠫ"),MOwK1lpyNfCgqksX3jhV(u"࠹࠸࠷ࣥ"))
	UZ8LYnm5jsl9uKM0xDX(Jbu2G0Qax8PYWpg(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),ToYWiIbruzUaNKRPZLG16cAj+q6yUEoKVDb0fXmc8vhrMk7N(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+YSr7Gq3EjLAV2JvM1tn5UPKZWw,Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠧ࡝"),Sj1PYDmIpCUXO26(u"࠺࠹࠹ࣦ"))
	UZ8LYnm5jsl9uKM0xDX(d0HDrq8Rtk16AlInw4TXb(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),ToYWiIbruzUaNKRPZLG16cAj+Sj1PYDmIpCUXO26(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+k4kFg6wdIzfQmZ,MOwK1lpyNfCgqksX3jhV(u"ࠩࠪࡠ"),lh6URegmQNq8LWX0HaK5(u"࠻࠺࠻ࣧ"))
	UZ8LYnm5jsl9uKM0xDX(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),ToYWiIbruzUaNKRPZLG16cAj+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+rnJI9WQ32KY57fZ0DpwFg4heGuTXV,Jbu2G0Qax8PYWpg(u"ࠬ࠭ࡣ"),NQ4hg16DPUxtOyo5iGb(u"࠼࠻࠶ࣨ"))
	LCIFdjzi5kVmRwehouHQ.setSetting(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࠨࡥ"))
	return
def LPqmKcbvBQOXkayCV():
	svOyXbipkwY = nEYJ5OCXG0gcNy(MOwK1lpyNfCgqksX3jhV(u"ࠨࠩࡦ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪࡧ"),onweDvmTOUj(u"ࠪࠫࡨ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),WWbmNvI40sM9Khlp25Ae(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if svOyXbipkwY==-LsG7EDcei1gMShH2aVOCo(u"࠷ࣩ"): return
	if svOyXbipkwY:
		import subprocess as RRLAOGFmUyjJ2cnVPgTMoYbehv
		try:
			RRLAOGFmUyjJ2cnVPgTMoYbehv.Popen(MOwK1lpyNfCgqksX3jhV(u"࠭ࡳࡶࠩ࡫"))
			PiIYU2DSbktQdlOoyHhnXJLas8KvET = lh6URegmQNq8LWX0HaK5(u"ࡗࡶࡺ࡫उ")
		except: PiIYU2DSbktQdlOoyHhnXJLas8KvET = eaF2N0jWLdvHIs8r(u"ࡊࡦࡲࡳࡦऊ")
		if PiIYU2DSbktQdlOoyHhnXJLas8KvET:
			d4xkIvmasjZVuBSy13t2b60Fe9r8 = cPEAdiaR3h8u5vFBTSGsKD+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࠡࠩ࡬")+HtilD1fJm4koRYZTGh7CM9UPSa2+d0HDrq8Rtk16AlInw4TXb(u"ࠨࠢࠪ࡭")+txf6zY2RilG7Z5yQLrC+mtEXp14ijx(u"ࠩࠣࠫ࡮")+ohIvQu4EObgedt3Jk1+LsG7EDcei1gMShH2aVOCo(u"ࠪࠤࠬ࡯")+yTeYAkDCqdLK9pUxh6+RS7ZoyGAq1c(u"ࠫࠥ࠭ࡰ")+X0eP9l4sZfotjQyOLVp3
			AANukQm7UGprgHBn1Z = RRLAOGFmUyjJ2cnVPgTMoYbehv.Popen(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+d4xkIvmasjZVuBSy13t2b60Fe9r8+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠢࠨࡲ"),shell=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࡙ࡸࡵࡦऋ"),stdin=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE,stdout=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE,stderr=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE)
			ztgqWUaDpe8CE9N(onweDvmTOUj(u"ࠧࠨࡳ"),Sj1PYDmIpCUXO26(u"ࠨࠩࡴ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			LCIFdjzi5kVmRwehouHQ.setSetting(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: ztgqWUaDpe8CE9N(Sj1PYDmIpCUXO26(u"ࠧࠨࡺ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࠩࡻ"),RS7ZoyGAq1c(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),lh6URegmQNq8LWX0HaK5(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def zic8FXKmaZ5kOepsHPNLj9dG(ffIg3vtxK2zjs6mZbBupoeQYGTPVL):
	for IWKVTarP4wnMUtBX6q2185OGHDJ in [eaF2N0jWLdvHIs8r(u"ࠫࡇ࠭ࡾ"),QQSULIva4ljNO73mFcWw(u"ࠬࡑࡂࠨࡿ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡍࡃࠩࢀ"),Q2ZyGqCNYsftTc4MR7n(u"ࠧࡈࡄࠪࢁ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡖࡅࠫࢂ")]:
		if ffIg3vtxK2zjs6mZbBupoeQYGTPVL<NQ4hg16DPUxtOyo5iGb(u"࠱࠱࠴࠷࣪"): break
		else: ffIg3vtxK2zjs6mZbBupoeQYGTPVL /= onweDvmTOUj(u"࠲࠲࠵࠸࠳࠶࣫")
	yy42JUqszVIO89i = Sj1PYDmIpCUXO26(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(ffIg3vtxK2zjs6mZbBupoeQYGTPVL,IWKVTarP4wnMUtBX6q2185OGHDJ)
	return yy42JUqszVIO89i
def waBQd8iEUAODXRJulSgPsHNb0(YfhPNyOvDr=hxSBTdGpyNVbfu4tr9(u"ࠪ࠲ࠬࢄ")):
	global J4jMyUP619prxbRHLgi3oaszF7,ACWopfziEaFI5v
	J4jMyUP619prxbRHLgi3oaszF7,ACWopfziEaFI5v = LsG7EDcei1gMShH2aVOCo(u"࠲࣬"),LsG7EDcei1gMShH2aVOCo(u"࠲࣬")
	def L64LyergCJSfoavb7wF(YfhPNyOvDr):
		global J4jMyUP619prxbRHLgi3oaszF7,ACWopfziEaFI5v
		if Dh9MOxeTj6FW.path.exists(YfhPNyOvDr):
			if MOwK1lpyNfCgqksX3jhV(u"࠳࣭") and hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(Dh9MOxeTj6FW):
				for eet2bAFksLz6VlhRpj40 in Dh9MOxeTj6FW.scandir(YfhPNyOvDr):
					if eet2bAFksLz6VlhRpj40.is_dir(follow_symlinks=Jbu2G0Qax8PYWpg(u"ࡌࡡ࡭ࡵࡨऌ")):
						L64LyergCJSfoavb7wF(eet2bAFksLz6VlhRpj40.path)
					elif eet2bAFksLz6VlhRpj40.is_file(follow_symlinks=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡆࡢ࡮ࡶࡩऍ")):
						J4jMyUP619prxbRHLgi3oaszF7 += eet2bAFksLz6VlhRpj40.stat().st_size
						ACWopfziEaFI5v += WWbmNvI40sM9Khlp25Ae(u"࠵࣮")
			else:
				for eet2bAFksLz6VlhRpj40 in Dh9MOxeTj6FW.listdir(YfhPNyOvDr):
					jcBsZavptIGEAC = Dh9MOxeTj6FW.path.abspath(Dh9MOxeTj6FW.path.join(YfhPNyOvDr,eet2bAFksLz6VlhRpj40))
					if Dh9MOxeTj6FW.path.isdir(jcBsZavptIGEAC):
						L64LyergCJSfoavb7wF(jcBsZavptIGEAC)
					elif Dh9MOxeTj6FW.path.isfile(jcBsZavptIGEAC):
						ffIg3vtxK2zjs6mZbBupoeQYGTPVL,P12PCQDTINg = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(jcBsZavptIGEAC)
						J4jMyUP619prxbRHLgi3oaszF7 += ffIg3vtxK2zjs6mZbBupoeQYGTPVL
						ACWopfziEaFI5v += P12PCQDTINg
		return
	try: L64LyergCJSfoavb7wF(YfhPNyOvDr)
	except: pass
	return J4jMyUP619prxbRHLgi3oaszF7,ACWopfziEaFI5v
def yy80NrDmqvhQukZOSgKpa4Pi6(j5uDsvCGyNM7HY8rW09tF2fV1mxK,showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(MOwK1lpyNfCgqksX3jhV(u"ࠬ࠭ࢆ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࠧࢇ"),FZBX5WcC3msIDv4hobLd8(u"ࠧࠨ࢈"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),j5uDsvCGyNM7HY8rW09tF2fV1mxK+hxSBTdGpyNVbfu4tr9(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+mtEXp14ijx(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if svOyXbipkwY!=Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠶࣯"): return
	cN6EZAOa4rjQeu7Bxynw = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࡇࡣ࡯ࡷࡪऎ")
	if Dh9MOxeTj6FW.path.exists(j5uDsvCGyNM7HY8rW09tF2fV1mxK):
		try: Dh9MOxeTj6FW.remove(j5uDsvCGyNM7HY8rW09tF2fV1mxK)
		except Exception as GlHXgIOFsCToAchz89Q17jx2k3V:
			if showDialogs: ztgqWUaDpe8CE9N(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࠬࢌ"),hxSBTdGpyNVbfu4tr9(u"ࠬ࠭ࢍ"),LsG7EDcei1gMShH2aVOCo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(GlHXgIOFsCToAchz89Q17jx2k3V))
			cN6EZAOa4rjQeu7Bxynw = eaF2N0jWLdvHIs8r(u"ࡖࡵࡹࡪए")
	if showDialogs and not cN6EZAOa4rjQeu7Bxynw:
		ztgqWUaDpe8CE9N(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨ࢏"),Sj1PYDmIpCUXO26(u"ࠨࠩ࢐"),Sj1PYDmIpCUXO26(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),eaF2N0jWLdvHIs8r(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		LCIFdjzi5kVmRwehouHQ.setSetting(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(QQSULIva4ljNO73mFcWw(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def jfTMXsUqYctu1A3dmg9Gb(showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨ࢖"),Jbu2G0Qax8PYWpg(u"ࠨࠩࢗ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࠪ࢘"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡢ࡮ࠨ࢛")+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+mtEXp14ijx(u"ࠧ࡝ࡰࠪ࢝")+Jbu2G0Qax8PYWpg(u"ࠨมࠤࠥࠬ࢞")+d0HDrq8Rtk16AlInw4TXb(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if svOyXbipkwY!=Y5npATFarf1H9wBjc87(u"࠷ࣰ"): return
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(VzQIBqvCd17JyOWo5g,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡘࡷࡻࡥऑ"),Sj1PYDmIpCUXO26(u"ࡉࡥࡱࡹࡥऐ"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(ppe3WvYK7D,IPkQW7LojF3HO18V(u"࡚ࡲࡶࡧओ"),NQ4hg16DPUxtOyo5iGb(u"ࡋࡧ࡬ࡴࡧऒ"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(VDMZGlXES6f,mtEXp14ijx(u"ࡆࡢ࡮ࡶࡩऔ"),mtEXp14ijx(u"ࡆࡢ࡮ࡶࡩऔ"))
	SSjxuWINHrzsg8o3hQ(KvdTINjy5g,hxSBTdGpyNVbfu4tr9(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		ztgqWUaDpe8CE9N(Jbu2G0Qax8PYWpg(u"ࠪࠫࢠ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࠬࢡ"),gy9NA3CROZolfEt4vVzMr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),Sj1PYDmIpCUXO26(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Jbu2G0Qax8PYWpg(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),MOwK1lpyNfCgqksX3jhV(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(eaF2N0jWLdvHIs8r(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def TcNU8GP0LVF7ubaeR5JAyM(showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠫࢧ"),RS7ZoyGAq1c(u"ࠫࠬࢨ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭ࢩ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),NQ4hg16DPUxtOyo5iGb(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+mtEXp14ijx(u"ࠨ࡞ࡱࠫࢬ")+gy9NA3CROZolfEt4vVzMr(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+MOwK1lpyNfCgqksX3jhV(u"ࠪࡠࡳ࠭ࢮ")+d0HDrq8Rtk16AlInw4TXb(u"ࠫࡄࠧࠡࠨࢯ")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if svOyXbipkwY!=LsG7EDcei1gMShH2aVOCo(u"࠱ࣱ"): return
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(cPEAdiaR3h8u5vFBTSGsKD,QQSULIva4ljNO73mFcWw(u"ࡈࡤࡰࡸ࡫ख"),QQSULIva4ljNO73mFcWw(u"ࡈࡤࡰࡸ࡫ख"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(HtilD1fJm4koRYZTGh7CM9UPSa2,QQSULIva4ljNO73mFcWw(u"ࡉࡥࡱࡹࡥग"),QQSULIva4ljNO73mFcWw(u"ࡉࡥࡱࡹࡥग"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(txf6zY2RilG7Z5yQLrC,B2vCEI9FAVP15R8eUbDJdySc(u"ࡊࡦࡲࡳࡦघ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࡊࡦࡲࡳࡦघ"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(ohIvQu4EObgedt3Jk1,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡋࡧ࡬ࡴࡧङ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡋࡧ࡬ࡴࡧङ"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(yTeYAkDCqdLK9pUxh6,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡌࡡ࡭ࡵࡨच"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡌࡡ࡭ࡵࡨच"))
	IlTEWy8f4bpjLa7UR0c2qDY6S15Q(X0eP9l4sZfotjQyOLVp3,gy9NA3CROZolfEt4vVzMr(u"ࡆࡢ࡮ࡶࡩछ"),gy9NA3CROZolfEt4vVzMr(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		ztgqWUaDpe8CE9N(FZBX5WcC3msIDv4hobLd8(u"࠭ࠧࢱ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࠨࢲ"),QQSULIva4ljNO73mFcWw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(eaF2N0jWLdvHIs8r(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),IPkQW7LojF3HO18V(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def SSjxuWINHrzsg8o3hQ(wl4oO8z5SgGnF3HJEDjbUh,showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠧࢸ"),Q2ZyGqCNYsftTc4MR7n(u"ࠧࠨࢹ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࠩࢺ"),LsG7EDcei1gMShH2aVOCo(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if svOyXbipkwY!=WWbmNvI40sM9Khlp25Ae(u"࠲ࣲ"): return
	Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(wl4oO8z5SgGnF3HJEDjbUh)
	Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
	lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
	lU7cFRC6jSwkVLTmIM.execute(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	lU7cFRC6jSwkVLTmIM.execute(NQ4hg16DPUxtOyo5iGb(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	lU7cFRC6jSwkVLTmIM.execute(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	Iof8U0xDKbVslWATpzR4OvBe9.commit()
	lU7cFRC6jSwkVLTmIM.execute(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	if showDialogs:
		ztgqWUaDpe8CE9N(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࠪࣂ"),onweDvmTOUj(u"ࠪࠫࣃ"),Jbu2G0Qax8PYWpg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),FZBX5WcC3msIDv4hobLd8(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(lh6URegmQNq8LWX0HaK5(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
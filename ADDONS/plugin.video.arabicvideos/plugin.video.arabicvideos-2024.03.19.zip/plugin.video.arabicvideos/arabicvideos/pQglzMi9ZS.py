# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'IFILM'
ToYWiIbruzUaNKRPZLG16cAj = '_IFL_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
n9dWOLMBkl = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][1]
dghDltko0P2 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][2]
EEOkr4vgUXI = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][3]
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==20: rr60PDpqbMehZsYVuHmiAtN = Lah2PHNq3e()
	elif mode==21: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq(url)
	elif mode==22: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==23: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,SSGEc76fBan2)
	elif mode==24: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,text)
	elif mode==25: rr60PDpqbMehZsYVuHmiAtN = NM02zrxw3toSE8AGk(url)
	elif mode==27: rr60PDpqbMehZsYVuHmiAtN = AAtcZRiU7anLkDGsb5Bv9CIKEhW(url)
	elif mode==28: rr60PDpqbMehZsYVuHmiAtN = iunaS9zbOP4L75KI()
	elif mode==29: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def Lah2PHNq3e():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'عربي',aaeRjxiYcqOI6Sf8,21,'','101')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'English',n9dWOLMBkl,21,'','101')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فارسى',dghDltko0P2,21,'','101')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فارسى 2',EEOkr4vgUXI,21,'','101')
	return
def iunaS9zbOP4L75KI():
	UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'عربي',aaeRjxiYcqOI6Sf8,27)
	UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'English',n9dWOLMBkl,27)
	UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'فارسى',dghDltko0P2,27)
	UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'فارسى 2',EEOkr4vgUXI,27)
	return
def De6s5ngUzirypRbLmKcdq(dd9HXcV5OkfCeLrjBmDsYKnAt):
	HmvY29bj4dNgF7wZqr1lzkeQxiEasu = dd9HXcV5OkfCeLrjBmDsYKnAt
	if dd9HXcV5OkfCeLrjBmDsYKnAt=='IFILM-ARABIC': dd9HXcV5OkfCeLrjBmDsYKnAt = aaeRjxiYcqOI6Sf8
	elif dd9HXcV5OkfCeLrjBmDsYKnAt=='IFILM-ENGLISH': dd9HXcV5OkfCeLrjBmDsYKnAt = n9dWOLMBkl
	else: HmvY29bj4dNgF7wZqr1lzkeQxiEasu = ''
	bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(dd9HXcV5OkfCeLrjBmDsYKnAt)
	if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='ar' or HmvY29bj4dNgF7wZqr1lzkeQxiEasu=='IFILM-ARABIC':
		b96sOLHJlramdu = 'بحث في الموقع'
		LmVdjhDqCzb4e2y5YOr = 'مسلسلات - حالية'
		Fc3PbKsrWIt150De4wYGqmay82X = 'مسلسلات - أحدث'
		sLCzqfGYE80koT = 'مسلسلات - أبجدي'
		m8YlP3OA0xzkaZwnbh6sX1GVi = 'بث حي آي فيلم'
		SbQBigCv96T2UWYNzxsen1GOPXd = 'أفلام'
		ck6fiUhFx3m4vZeE = 'موسيقى'
		SzaTC6WMxU59vdhfVetQGXO0 = 'برامج'
	elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en' or HmvY29bj4dNgF7wZqr1lzkeQxiEasu=='IFILM-ENGLISH':
		b96sOLHJlramdu = 'Search in site'
		LmVdjhDqCzb4e2y5YOr = 'Series - Current'
		Fc3PbKsrWIt150De4wYGqmay82X = 'Series - Latest'
		sLCzqfGYE80koT = 'Series - Alphabet'
		m8YlP3OA0xzkaZwnbh6sX1GVi = 'Live iFilm channel'
		SbQBigCv96T2UWYNzxsen1GOPXd = 'Movies'
		ck6fiUhFx3m4vZeE = 'Music'
		SzaTC6WMxU59vdhfVetQGXO0 = 'Shows'
	elif bjPvhSAfNTOJWk2yCMt1xasVYFr9 in ['fa','fa2']:
		b96sOLHJlramdu = 'جستجو در سایت'
		LmVdjhDqCzb4e2y5YOr = 'سريال - جاری'
		Fc3PbKsrWIt150De4wYGqmay82X = 'سريال - آخرین'
		sLCzqfGYE80koT = 'سريال - الفبا'
		m8YlP3OA0xzkaZwnbh6sX1GVi = 'پخش زنده اي فيلم'
		SbQBigCv96T2UWYNzxsen1GOPXd = 'فيلم'
		ck6fiUhFx3m4vZeE = 'موسيقى'
		SzaTC6WMxU59vdhfVetQGXO0 = 'برنامه ها'
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+b96sOLHJlramdu,dd9HXcV5OkfCeLrjBmDsYKnAt,29,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('live',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+m8YlP3OA0xzkaZwnbh6sX1GVi,dd9HXcV5OkfCeLrjBmDsYKnAt,27)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	hmedxznGXRHt1L = ['Series','Program','Music']
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,dd9HXcV5OkfCeLrjBmDsYKnAt+'/home','','','','IFILM-MENU-1st')
	pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('button-menu(.*?)/Contact',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in ZcAK0askvzIWr4R for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in hmedxznGXRHt1L):
				url = dd9HXcV5OkfCeLrjBmDsYKnAt+ZcAK0askvzIWr4R
				if 'Series' in ZcAK0askvzIWr4R:
					UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,url,22,'','100')
					UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+Fc3PbKsrWIt150De4wYGqmay82X,url,22,'','101')
					UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+sLCzqfGYE80koT,url,22,'','201')
				elif 'Film' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+SbQBigCv96T2UWYNzxsen1GOPXd,url,22,'','100')
				elif 'Music' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+ck6fiUhFx3m4vZeE,url,25,'','101')
				elif 'Program' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+SzaTC6WMxU59vdhfVetQGXO0,url,22,'','101')
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def NM02zrxw3toSE8AGk(url):
	dd9HXcV5OkfCeLrjBmDsYKnAt = oNikmGhYsf0PUv9Vpecl2Ca7Rr(url)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','','','IFILM-MUSIC_MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('Music-tools-header(.*?)Music-body',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	title = SomeI8i56FaDMGPE.findall('<p>(.*?)</p>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)[0]
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,22,'','101')
	items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = dd9HXcV5OkfCeLrjBmDsYKnAt + ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,23,'','101')
	return
def KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2):
	dd9HXcV5OkfCeLrjBmDsYKnAt = oNikmGhYsf0PUv9Vpecl2Ca7Rr(url)
	bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(url)
	type = url.split('/')[-1]
	oohf8DwZLb = str(int(SSGEc76fBan2)//100)
	SSGEc76fBan2 = str(int(SSGEc76fBan2)%100)
	if type=='Series' and SSGEc76fBan2=='0':
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','IFILM-TITLES-1st')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('serial-body(.*?)class="row',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			title = c8Fvb4IfHW9XkG1mLK5Z(title)
			title = dCFP41Kxv9j8EHM(title)
			ZcAK0askvzIWr4R = dd9HXcV5OkfCeLrjBmDsYKnAt + ZcAK0askvzIWr4R
			pjMZ802XQCSxYVk = dd9HXcV5OkfCeLrjBmDsYKnAt + TbEVs6mLPHF(pjMZ802XQCSxYVk)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,23,pjMZ802XQCSxYVk,oohf8DwZLb+'01')
	FlkNmICyPuaD46AMG5weBxqnpv=0
	if type=='Series': g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B='3'
	if type=='Film': g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B='5'
	if type=='Program': g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B='7'
	if type in ['Series','Program','Film'] and SSGEc76fBan2!='0':
		vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Home/PageingItem?category='+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'&page='+SSGEc76fBan2+'&size=30&orderby='+oohf8DwZLb
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-TITLES-2nd')
		items = SomeI8i56FaDMGPE.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for id,title,pjMZ802XQCSxYVk in items:
			title = c8Fvb4IfHW9XkG1mLK5Z(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			FlkNmICyPuaD46AMG5weBxqnpv += 1
			ZcAK0askvzIWr4R = dd9HXcV5OkfCeLrjBmDsYKnAt + '/' + type + '/Content/' + id
			pjMZ802XQCSxYVk = dd9HXcV5OkfCeLrjBmDsYKnAt + TbEVs6mLPHF(pjMZ802XQCSxYVk)
			if type=='Film': UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,24,pjMZ802XQCSxYVk,oohf8DwZLb+'01')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,23,pjMZ802XQCSxYVk,oohf8DwZLb+'01')
	if type=='Music':
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,dd9HXcV5OkfCeLrjBmDsYKnAt+'/Music/Index?page='+SSGEc76fBan2,'','','','IFILM-TITLES-3rd')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination-demo(.*?)pagination-demo',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			FlkNmICyPuaD46AMG5weBxqnpv += 1
			pjMZ802XQCSxYVk = dd9HXcV5OkfCeLrjBmDsYKnAt + pjMZ802XQCSxYVk
			ZcAK0askvzIWr4R = dd9HXcV5OkfCeLrjBmDsYKnAt + ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,23,pjMZ802XQCSxYVk,'101')
	if FlkNmICyPuaD46AMG5weBxqnpv>20:
		title='صفحة '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': title = 'Page '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': title = 'صفحه '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': title = 'صفحه '
		for IXxzM6Hy9PW in range(1,11) :
			if not SSGEc76fBan2==str(IXxzM6Hy9PW):
				WWn9JtiqSwTUQXape0A = '0'+str(IXxzM6Hy9PW)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title+str(IXxzM6Hy9PW),url,22,'',oohf8DwZLb+WWn9JtiqSwTUQXape0A[-2:])
	return
def ooLCwrlF3n0vBjpA(url,SSGEc76fBan2):
	if not SSGEc76fBan2: SSGEc76fBan2 = 0
	dd9HXcV5OkfCeLrjBmDsYKnAt = oNikmGhYsf0PUv9Vpecl2Ca7Rr(url)
	rr39GFcXaRNtjDAIVquO = oNikmGhYsf0PUv9Vpecl2Ca7Rr(url)
	bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(url)
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('/')
	id,type = u3gUQexlvJM86CS0bXGRBoEFrkZiP[-1],u3gUQexlvJM86CS0bXGRBoEFrkZiP[3]
	oohf8DwZLb = str(int(SSGEc76fBan2)//100)
	SSGEc76fBan2 = str(int(SSGEc76fBan2)%100)
	FlkNmICyPuaD46AMG5weBxqnpv = 0
	if type=='Series':
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','IFILM-EPISODES-1st')
		items = SomeI8i56FaDMGPE.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		title = ' - الحلقة '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': title = ' - Episode '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': title = ' - قسمت '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': title = ' - قسمت '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': MQmS9CKXqy7aIUARcPrG4 = ''
		else: MQmS9CKXqy7aIUARcPrG4 = bjPvhSAfNTOJWk2yCMt1xasVYFr9
		fmS2qUkDKy8PJg5pH = SomeI8i56FaDMGPE.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for name,count,pjMZ802XQCSxYVk,ZcAK0askvzIWr4R in items:
			for iHPhR4wCQ1oINaL in range(int(count),0,-1):
				Za92UPTIr1i8kDMBgXcbKmR = pjMZ802XQCSxYVk + MQmS9CKXqy7aIUARcPrG4 + id + '/' + str(iHPhR4wCQ1oINaL) + '.png'
				LmVdjhDqCzb4e2y5YOr = name + title + str(iHPhR4wCQ1oINaL)
				LmVdjhDqCzb4e2y5YOr = dCFP41Kxv9j8EHM(LmVdjhDqCzb4e2y5YOr)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,url,24,Za92UPTIr1i8kDMBgXcbKmR,'',str(iHPhR4wCQ1oINaL))
	elif type=='Program':
		vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+SSGEc76fBan2+'&size=30&orderby=1'
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-EPISODES-2nd')
		items = SomeI8i56FaDMGPE.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		title = ' - الحلقة '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': title = ' - Episode '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': title = ' - قسمت '
		if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': title = ' - قسمت '
		for iHPhR4wCQ1oINaL,pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,PwYhEWXl2gqc8FJD,name in items:
			FlkNmICyPuaD46AMG5weBxqnpv += 1
			Za92UPTIr1i8kDMBgXcbKmR = rr39GFcXaRNtjDAIVquO + TbEVs6mLPHF(pjMZ802XQCSxYVk)
			name = c8Fvb4IfHW9XkG1mLK5Z(name)
			LmVdjhDqCzb4e2y5YOr = name + title + str(iHPhR4wCQ1oINaL)
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,vfIB6ib8q1hFX5GweRrVPNTjY2E,24,Za92UPTIr1i8kDMBgXcbKmR,'',str(FlkNmICyPuaD46AMG5weBxqnpv))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Music/GetTracksBy?id='+str(id)+'&page='+SSGEc76fBan2+'&size=30&type=0'
			BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-EPISODES-3rd')
			items = SomeI8i56FaDMGPE.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,name,title in items:
				FlkNmICyPuaD46AMG5weBxqnpv += 1
				Za92UPTIr1i8kDMBgXcbKmR = rr39GFcXaRNtjDAIVquO + TbEVs6mLPHF(pjMZ802XQCSxYVk)
				LmVdjhDqCzb4e2y5YOr = name + ' - ' + title
				LmVdjhDqCzb4e2y5YOr = LmVdjhDqCzb4e2y5YOr.strip(' ')
				LmVdjhDqCzb4e2y5YOr = c8Fvb4IfHW9XkG1mLK5Z(LmVdjhDqCzb4e2y5YOr)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,vfIB6ib8q1hFX5GweRrVPNTjY2E,24,Za92UPTIr1i8kDMBgXcbKmR,'',str(FlkNmICyPuaD46AMG5weBxqnpv))
		elif 'Clips' in url:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Music/GetTracksBy?id=0&page='+SSGEc76fBan2+'&size=30&type=15'
			BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-EPISODES-4th')
			items = SomeI8i56FaDMGPE.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			for pjMZ802XQCSxYVk,title,ZcAK0askvzIWr4R in items:
				FlkNmICyPuaD46AMG5weBxqnpv += 1
				Za92UPTIr1i8kDMBgXcbKmR = rr39GFcXaRNtjDAIVquO + TbEVs6mLPHF(pjMZ802XQCSxYVk)
				LmVdjhDqCzb4e2y5YOr = title.strip(' ')
				LmVdjhDqCzb4e2y5YOr = c8Fvb4IfHW9XkG1mLK5Z(LmVdjhDqCzb4e2y5YOr)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,vfIB6ib8q1hFX5GweRrVPNTjY2E,24,Za92UPTIr1i8kDMBgXcbKmR,'',str(FlkNmICyPuaD46AMG5weBxqnpv))
		elif 'category' in url:
			if 'category=6' in url:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Music/GetTracksBy?id=0&page='+SSGEc76fBan2+'&size=30&type=6'
				BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = dd9HXcV5OkfCeLrjBmDsYKnAt+'/Music/GetTracksBy?id=0&page='+SSGEc76fBan2+'&size=30&type=4'
				BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-EPISODES-6th')
			items = SomeI8i56FaDMGPE.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,name,title in items:
				FlkNmICyPuaD46AMG5weBxqnpv += 1
				Za92UPTIr1i8kDMBgXcbKmR = rr39GFcXaRNtjDAIVquO + TbEVs6mLPHF(pjMZ802XQCSxYVk)
				LmVdjhDqCzb4e2y5YOr = name + ' - ' + title
				LmVdjhDqCzb4e2y5YOr = LmVdjhDqCzb4e2y5YOr.strip(' ')
				LmVdjhDqCzb4e2y5YOr = c8Fvb4IfHW9XkG1mLK5Z(LmVdjhDqCzb4e2y5YOr)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+LmVdjhDqCzb4e2y5YOr,vfIB6ib8q1hFX5GweRrVPNTjY2E,24,Za92UPTIr1i8kDMBgXcbKmR,'',str(FlkNmICyPuaD46AMG5weBxqnpv))
	if type=='Music' or type=='Program':
		if FlkNmICyPuaD46AMG5weBxqnpv>25:
			title='صفحة '
			if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': title = ' Page '
			if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': title = ' صفحه '
			if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': title = ' صفحه '
			for IXxzM6Hy9PW in range(1,11):
				if not SSGEc76fBan2==str(IXxzM6Hy9PW):
					WWn9JtiqSwTUQXape0A = '0'+str(IXxzM6Hy9PW)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title+str(IXxzM6Hy9PW),url,23,'',oohf8DwZLb+WWn9JtiqSwTUQXape0A[-2:])
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,iHPhR4wCQ1oINaL):
	rr39GFcXaRNtjDAIVquO = oNikmGhYsf0PUv9Vpecl2Ca7Rr(url)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','IFILM-PLAY-1st')
	items = SomeI8i56FaDMGPE.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(url)
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('/')
		id,type = u3gUQexlvJM86CS0bXGRBoEFrkZiP[-1],u3gUQexlvJM86CS0bXGRBoEFrkZiP[3]
		ZcAK0askvzIWr4R = items[0][0]+bjPvhSAfNTOJWk2yCMt1xasVYFr9+id+'/,'+iHPhR4wCQ1oINaL+','+iHPhR4wCQ1oINaL+'_'+items[0][2]
		r79xJG6jXHD.append('m3u8')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	items = SomeI8i56FaDMGPE.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(url)
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('/')
		id,type = u3gUQexlvJM86CS0bXGRBoEFrkZiP[-1],u3gUQexlvJM86CS0bXGRBoEFrkZiP[3]
		ZcAK0askvzIWr4R = items[0][0]+bjPvhSAfNTOJWk2yCMt1xasVYFr9+id+'/'+iHPhR4wCQ1oINaL+items[0][2]
		r79xJG6jXHD.append('mp4 url')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	items = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R in items:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('//','/')
		r79xJG6jXHD.append('mp4 src')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	items = SomeI8i56FaDMGPE.findall('VideoAddress":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		ZcAK0askvzIWr4R = items[int(iHPhR4wCQ1oINaL)-1]
		ZcAK0askvzIWr4R = rr39GFcXaRNtjDAIVquO+TbEVs6mLPHF(ZcAK0askvzIWr4R)
		r79xJG6jXHD.append('mp4 address')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	items = SomeI8i56FaDMGPE.findall('VoiceAddress":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		ZcAK0askvzIWr4R = items[int(iHPhR4wCQ1oINaL)-1]
		ZcAK0askvzIWr4R = rr39GFcXaRNtjDAIVquO+TbEVs6mLPHF(ZcAK0askvzIWr4R)
		r79xJG6jXHD.append('mp3 address')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==1: ZcAK0askvzIWr4R = aFyREdMQk7Ys95rX6uJieDGLS2[0]
	else:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الفيديو المناسب:', r79xJG6jXHD)
		if I7mfbGiWNFcBVJOn == -1 : return
		ZcAK0askvzIWr4R = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	kFygcp2jqSUCiNRnur71xMZI96(ZcAK0askvzIWr4R,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def oNikmGhYsf0PUv9Vpecl2Ca7Rr(url):
	if aaeRjxiYcqOI6Sf8 in url: yPRGDCnXhJbwYalz7fZepiUcA = aaeRjxiYcqOI6Sf8
	elif n9dWOLMBkl in url: yPRGDCnXhJbwYalz7fZepiUcA = n9dWOLMBkl
	elif dghDltko0P2 in url: yPRGDCnXhJbwYalz7fZepiUcA = dghDltko0P2
	elif EEOkr4vgUXI in url: yPRGDCnXhJbwYalz7fZepiUcA = EEOkr4vgUXI
	else: yPRGDCnXhJbwYalz7fZepiUcA = ''
	return yPRGDCnXhJbwYalz7fZepiUcA
def RRezdI0bhK3PtMEBfv(url):
	if   aaeRjxiYcqOI6Sf8 in url: bjPvhSAfNTOJWk2yCMt1xasVYFr9 = 'ar'
	elif n9dWOLMBkl in url: bjPvhSAfNTOJWk2yCMt1xasVYFr9 = 'en'
	elif dghDltko0P2 in url: bjPvhSAfNTOJWk2yCMt1xasVYFr9 = 'fa'
	elif EEOkr4vgUXI in url: bjPvhSAfNTOJWk2yCMt1xasVYFr9 = 'fa2'
	else: bjPvhSAfNTOJWk2yCMt1xasVYFr9 = ''
	return bjPvhSAfNTOJWk2yCMt1xasVYFr9
def AAtcZRiU7anLkDGsb5Bv9CIKEhW(url):
	bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(url)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url + '/Home/Live'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','IFILM-LIVE-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = items[0]
	kFygcp2jqSUCiNRnur71xMZI96(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'live')
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	if showDialogs:
		ZVP39ulQKcFEjq1MRvhGXbeAwWT = [ aaeRjxiYcqOI6Sf8 , n9dWOLMBkl , dghDltko0P2 , EEOkr4vgUXI ]
		JiRmpe1Pwx = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر اللغة المناسبة:', JiRmpe1Pwx)
		if I7mfbGiWNFcBVJOn == -1 : return
		website = ZVP39ulQKcFEjq1MRvhGXbeAwWT[I7mfbGiWNFcBVJOn]
	else:
		if '_IFILM-ARABIC_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: website = aaeRjxiYcqOI6Sf8
		elif '_IFILM-ENGLISH_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: website = n9dWOLMBkl
		else: website = ''
	if not website: return
	bjPvhSAfNTOJWk2yCMt1xasVYFr9 = RRezdI0bhK3PtMEBfv(website)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = website + "/Home/Search?searchstring=" + u9DhgpinLBfmjG3NtMalq7Y
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','IFILM-SEARCH-1st')
	items = SomeI8i56FaDMGPE.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		for pjMZ802XQCSxYVk,g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,id,title in items:
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='3':
					type = 'Series'
					if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='ar': name = 'مسلسل : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': name = 'Series : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': name = 'سريال ها : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': name = 'سريال ها : '
				elif g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='5':
					type = 'Film'
					if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='ar': name = 'فيلم : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': name = 'Movie : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': name = 'فيلم : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': name = 'فلم ها : '
				elif g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='7':
					type = 'Program'
					if bjPvhSAfNTOJWk2yCMt1xasVYFr9=='ar': name = 'برنامج : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='en': name = 'Program : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa': name = 'برنامه ها : '
					elif bjPvhSAfNTOJWk2yCMt1xasVYFr9=='fa2': name = 'برنامه ها : '
				title = name + title
				ZcAK0askvzIWr4R = website + '/' + type + '/Content/' + id
				pjMZ802XQCSxYVk = TbEVs6mLPHF(pjMZ802XQCSxYVk)
				pjMZ802XQCSxYVk = website+pjMZ802XQCSxYVk
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,23,pjMZ802XQCSxYVk,'101')
	return
# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from A7vZ89SBgK import *
import bidi.algorithm as Xpa41TEJ2Wl,bidi.mirror as q7N3zjv5lfR6Z,base64 as jjsSA3nOp2Qz5MdX7Nf9vHDy1V,requests as UYkMoz0DGsTwIdKxnfS5ryR23Pp
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ౫")
w1wlgpYj6tbWLhxD = {}
nUTgq0SFfC9 = []
if ZZxLpCcmqhyT6NuMWelkbSvr0H:
	wCZNUYSm40Hrhv5oP = bPsqMHSitNmy3uZQ.translatePath(Q2ZyGqCNYsftTc4MR7n(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ౬"))
	mKdhSjzZPWany = bPsqMHSitNmy3uZQ.translatePath(hxSBTdGpyNVbfu4tr9(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ౭"))
	WTUQXjmAGzB0dFyu6 = bPsqMHSitNmy3uZQ.translatePath(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ౮"))
	hvGPU2bmasopzFJxIEqfRYW41uQ6y = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,onweDvmTOUj(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ౯"),lh6URegmQNq8LWX0HaK5(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ౰"),lh6URegmQNq8LWX0HaK5(u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ౱"))
	hMAoTDq3VFzImX8PSlYa9Bn6 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,LsG7EDcei1gMShH2aVOCo(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ౲"),RS7ZoyGAq1c(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ౳"),hxSBTdGpyNVbfu4tr9(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ౴"))
	aDtrsUMWmguPoJHSE9qi2 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,Jbu2G0Qax8PYWpg(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౵"),MOwK1lpyNfCgqksX3jhV(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౶"),IPkQW7LojF3HO18V(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭౷"))
	xWa5bZGlqdDAFP2y = LsG7EDcei1gMShH2aVOCo(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ౸")
	from urllib.parse import quote as _6t8C3Q1Wu7e
else:
	wCZNUYSm40Hrhv5oP = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.translatePath(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ౹"))
	mKdhSjzZPWany = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.translatePath(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ౺"))
	WTUQXjmAGzB0dFyu6 = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.translatePath(d0HDrq8Rtk16AlInw4TXb(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ౻"))
	hvGPU2bmasopzFJxIEqfRYW41uQ6y = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౼"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౽"),Y5npATFarf1H9wBjc87(u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ౾"))
	hMAoTDq3VFzImX8PSlYa9Bn6 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,eaF2N0jWLdvHIs8r(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ౿"),IPkQW7LojF3HO18V(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪಀ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩಁ"))
	aDtrsUMWmguPoJHSE9qi2 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,WWbmNvI40sM9Khlp25Ae(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),WWbmNvI40sM9Khlp25Ae(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ಄"))
	xWa5bZGlqdDAFP2y = B2vCEI9FAVP15R8eUbDJdySc(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧಅ").encode(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡶࡶࡩ࠼ࠬಆ"))
	from urllib import quote as _6t8C3Q1Wu7e
SSiIRuULQTe6taoBd = Dh9MOxeTj6FW.path.join(WTUQXjmAGzB0dFyu6,WWbmNvI40sM9Khlp25Ae(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪಇ"))
rrJcyI8Zl90 = Dh9MOxeTj6FW.path.join(WTUQXjmAGzB0dFyu6,lh6URegmQNq8LWX0HaK5(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨಈ"))
kXGhUfiR05psnmdEgeIJTo3wx8Aq = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಉ"))
P8dChnk34pva6NYRrI9Vz = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,lh6URegmQNq8LWX0HaK5(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಊ"))
UWteSXYca7 = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,mtEXp14ijx(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಋ"))
YbTWJNjEGPC12RZzHioatgvu = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧಌ"))
AauGlFWnZcPHKLgR4k7 = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,NQ4hg16DPUxtOyo5iGb(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ಍"))
ao80nC2gE3LkOFvI9BTxXqQW5N = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩಎ"))
nnyfJE0MzRWolCuK68rxd = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,B2vCEI9FAVP15R8eUbDJdySc(u"ࠩ࡬ࡱࡦ࡭ࡥࡴࠩಏ"))
qqlirVhUTbGnC5vN2H = Dh9MOxeTj6FW.path.join(nnyfJE0MzRWolCuK68rxd,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫಐ"))
nA9zdBHP4q8XrVLi3CR = Dh9MOxeTj6FW.path.join(qqlirVhUTbGnC5vN2H,RS7ZoyGAq1c(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ಑"))
gyXBVnYKzm4 = VmrWjDNze5tadycvpHOGnTb.Addon().getAddonInfo(QQSULIva4ljNO73mFcWw(u"ࠬࡶࡡࡵࡪࠪಒ"))
z8UmNpEWYicXg10Ql = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,eaF2N0jWLdvHIs8r(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨಓ"))
OhqLsI3oamdWniz0kp9KE = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪಔ"))
Q8QUpl41kEIC2O = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬಕ"))
v0wCsoZl4OxmE5n9bqrA37KuhY8Lg = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,hxSBTdGpyNVbfu4tr9(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭ಖ"))
q8SNAgXnfwb0dOVv = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,Sj1PYDmIpCUXO26(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪಗ"))
TIy4RwCMzvoY9h3eEg8jXKQ = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,IPkQW7LojF3HO18V(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨಘ"))
foEqUAadQ43yWx8KFvOSVjTn0X6H5 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬಙ"))
XX7nyCZhWm8 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,NQ4hg16DPUxtOyo5iGb(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬಚ"))
GGmAxq9Dh2Kgpl = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,QQSULIva4ljNO73mFcWw(u"ࠧ࡮ࡧࡱࡹ࠳ࡶ࡮ࡨࠩಛ"))
ondphfgrlZ = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨಜ"))
COjW7yrR8DhcLg4IadwBU = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩಝ"))
cj6P0SH4bTkwt2sIWqKYXaRNQCGJ5 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,RS7ZoyGAq1c(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಞ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨಟ"),giwrh4jLPc,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫಠ"))
RlYCb3esZKO01 = Dh9MOxeTj6FW.path.join(wCZNUYSm40Hrhv5oP,eaF2N0jWLdvHIs8r(u"࠭࡭ࡦࡦ࡬ࡥࠬಡ"),hxSBTdGpyNVbfu4tr9(u"ࠧࡇࡱࡱࡸࡸ࠭ಢ"),mtEXp14ijx(u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫಣ"))
gx4WbX9yDPm6lk = B2vCEI9FAVP15R8eUbDJdySc(u"࠷ᒠ")
h6OYx3P5fiRXg2LoBK8 = [LsG7EDcei1gMShH2aVOCo(u"ุࠩๅึ࠭ತ"),Q2ZyGqCNYsftTc4MR7n(u"ࠪวํ๊ࠧಥ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫะอๆ๋ࠩದ"),LsG7EDcei1gMShH2aVOCo(u"ࠬัวๅอࠪಧ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ัศส฼ࠫನ"),mtEXp14ijx(u"ࠧฯษ่ืࠬ಩"),QQSULIva4ljNO73mFcWw(u"ࠨีสำุ࠭ಪ"),RS7ZoyGAq1c(u"ࠩึหอ฿ࠧಫ"),LsG7EDcei1gMShH2aVOCo(u"ࠪฯฬ๋ๆࠨಬ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫฯอำฺࠩಭ"),gy9NA3CROZolfEt4vVzMr(u"ࠬ฿วีำࠪಮ")]
FxHYTeJn0BCc6m3R9WZaGXAzQL = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭⸻ࠡ⼟ࠣ⸮ࠥ⹁ࠧಯ")
fyIAplJLe9MGiPosBvrEOtZUm6 = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠳ᒡ")
AlcR9Gvo3QZsLnpfjS = Rz34c0NP5BGo1WuTZxSfOKj(u"࠷࠵ᒢ")*IawroWLYiTh2UCODE7zfNlGBKHk3
sJF0ga5tzvlRZWK3Xb9 = IPkQW7LojF3HO18V(u"࠷ᒣ")*nh1uLlGma8wJVsAMyKxkjC9N
wwSaAipunqYIgcH = mtEXp14ijx(u"࠹࠰ᒤ")*EEx5baCQn6rPzBvkFRoqT
gfKLySYJpj9 = OnvTrikzfEsY7qU8pgaRBtZy(u"࠱ᒥ")*nh1uLlGma8wJVsAMyKxkjC9N
cCoslu39nL5hgjGvt1fN = [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ರ")]
ckES0htPVXejwG = [RS7ZoyGAq1c(u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪಱ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬಲ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧಳ"),eaF2N0jWLdvHIs8r(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ಴"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨವ"),lh6URegmQNq8LWX0HaK5(u"࠭ࡍࡐࡘࡖ࠸࡚࠭ಶ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡎ࡛ࡆࡍࡒࡇࠧಷ"),RS7ZoyGAq1c(u"ࠨࡎࡄࡖࡔࡠࡁࠨಸ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫಹ")]
ckES0htPVXejwG += [RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡌࡊࡒࡁࡍࠩ಺"),eaF2N0jWLdvHIs8r(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ಻"),hxSBTdGpyNVbfu4tr9(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ಼ࠧ"),MOwK1lpyNfCgqksX3jhV(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧಽ"),Jbu2G0Qax8PYWpg(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩಾ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨಿ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫೀ"),IPkQW7LojF3HO18V(u"ࠪࡔࡆࡔࡅࡕࠩು"),FZBX5WcC3msIDv4hobLd8(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫೂ"),RS7ZoyGAq1c(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫೃ")]
lVhjYeTAFNyiRctHgmPQXvC9k2qJu = [IPkQW7LojF3HO18V(u"࠭ࡉࡑࡖ࡙ࠫೄ"),gy9NA3CROZolfEt4vVzMr(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ೅"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭ೆ"),NQ4hg16DPUxtOyo5iGb(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧೇ")]
lVhjYeTAFNyiRctHgmPQXvC9k2qJu += [mtEXp14ijx(u"ࠪࡑ࠸࡛ࠧೈ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭೉"),eaF2N0jWLdvHIs8r(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩೊ"),LsG7EDcei1gMShH2aVOCo(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪೋ")]
lVhjYeTAFNyiRctHgmPQXvC9k2qJu += [WWbmNvI40sM9Khlp25Ae(u"ࠧࡊࡈࡌࡐࡒ࠭ೌ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉ್ࠧ"),NQ4hg16DPUxtOyo5iGb(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ೎")]
lVhjYeTAFNyiRctHgmPQXvC9k2qJu += [a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡅࡑࡇࡒࡂࡄࠪ೏"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡆࡑࡗࡂࡏࠪ೐"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ೑"),Jbu2G0Qax8PYWpg(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ೒"),gy9NA3CROZolfEt4vVzMr(u"ࠧࡂࡍࡒࡅࡒ࠭೓"),d0HDrq8Rtk16AlInw4TXb(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ೔")]
lVhjYeTAFNyiRctHgmPQXvC9k2qJu += [lh6URegmQNq8LWX0HaK5(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬೕ"),Y5npATFarf1H9wBjc87(u"ࠪࡆࡔࡑࡒࡂࠩೖ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭೗"),FZBX5WcC3msIDv4hobLd8(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ೘"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ೙"),mtEXp14ijx(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ೚")]
EctWpi0OkMgIHX = [S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ೛"),Q2ZyGqCNYsftTc4MR7n(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ೜"),LsG7EDcei1gMShH2aVOCo(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧೝ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧೞ")]
EctWpi0OkMgIHX += [B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೟"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫೠ"),mtEXp14ijx(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨೡ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨೢ"),eaF2N0jWLdvHIs8r(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧೣ"),mtEXp14ijx(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ೤")]
dHw8OxjqMKbTNVZrtvofy4RC = [eaF2N0jWLdvHIs8r(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೥"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೦"),FZBX5WcC3msIDv4hobLd8(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ೧"),Q2ZyGqCNYsftTc4MR7n(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ೨"),eaF2N0jWLdvHIs8r(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ೩")]
dHw8OxjqMKbTNVZrtvofy4RC += [RS7ZoyGAq1c(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ೪"),Jbu2G0Qax8PYWpg(u"ࠪࡘ࡛ࡌࡕࡏࠩ೫"),IPkQW7LojF3HO18V(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ೬"),Y5npATFarf1H9wBjc87(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ೭"),RS7ZoyGAq1c(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ೮")]
LZKTCp21UVlbDQiH7s9xRj3 = [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ೯"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ೰"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬೱ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪࡊࡔ࡙ࡔࡂࠩೲ"),WWbmNvI40sM9Khlp25Ae(u"ࠫࡆࡎࡗࡂࡍࠪೳ"),onweDvmTOUj(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭೴")]
LZKTCp21UVlbDQiH7s9xRj3 += [q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡓࡉࡑࡉࡌࡆ࠭೵"),WWbmNvI40sM9Khlp25Ae(u"ࠧࡃࡔࡖࡘࡊࡐࠧ೶"),gy9NA3CROZolfEt4vVzMr(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ೷"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ೸"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ೹"),WWbmNvI40sM9Khlp25Ae(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭೺"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ೻")]
MFyptHzDV8m6ANEox1nS0hcJj7Q  = [onweDvmTOUj(u"࠭ࡁࡌ࡙ࡄࡑࠬ೼"),RS7ZoyGAq1c(u"ࠧࡂࡎࡄࡖࡆࡈࠧ೽"),NQ4hg16DPUxtOyo5iGb(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ೾"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡅࡓࡐࡘࡁࠨ೿"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡅࡐࡕࡁࡎࠩഀ"),mtEXp14ijx(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ഁ"),d0HDrq8Rtk16AlInw4TXb(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧം"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧഃ")]
MFyptHzDV8m6ANEox1nS0hcJj7Q += [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩഄ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫഅ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪആ"),RS7ZoyGAq1c(u"࡛ࠪࡊࡉࡉࡎࡃࠪഇ"),WWbmNvI40sM9Khlp25Ae(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨഈ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡌࡏࡔࡖࡄࠫഉ"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࡁࡉ࡙ࡄࡏࠬഊ")]
MFyptHzDV8m6ANEox1nS0hcJj7Q += [MOwK1lpyNfCgqksX3jhV(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪഋ"),NQ4hg16DPUxtOyo5iGb(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫഌ"),onweDvmTOUj(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ഍"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬഎ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ഏ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧഐ"),MOwK1lpyNfCgqksX3jhV(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ഑")]
MFyptHzDV8m6ANEox1nS0hcJj7Q += [Q2ZyGqCNYsftTc4MR7n(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨഒ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪഓ"),RS7ZoyGAq1c(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫഔ"),Sj1PYDmIpCUXO26(u"ࠪࡘ࡛ࡌࡕࡏࠩക"),Sj1PYDmIpCUXO26(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ഖ"),IPkQW7LojF3HO18V(u"࡙ࠬࡈࡐࡈࡋࡅࠬഗ")]
MFyptHzDV8m6ANEox1nS0hcJj7Q += [Jbu2G0Qax8PYWpg(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ഘ"),B2vCEI9FAVP15R8eUbDJdySc(u"࡚ࠧࡃࡔࡓ࡙࠭ങ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩച"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪഛ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨജ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ഝ"),onweDvmTOUj(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧഞ")]
Ustrv8LpF4uBKYbfkqNdaP  = [q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫട"),mtEXp14ijx(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨഠ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨഡ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧഢ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧണ")]
Ustrv8LpF4uBKYbfkqNdaP += [aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪത"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬഥ")]
Ustrv8LpF4uBKYbfkqNdaP += [Rz34c0NP5BGo1WuTZxSfOKj(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧദ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫധ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫന")]
Ustrv8LpF4uBKYbfkqNdaP += [Y5npATFarf1H9wBjc87(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬഩ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨപ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩഫ")]
Ustrv8LpF4uBKYbfkqNdaP += [Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧബ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪഭ"),d0HDrq8Rtk16AlInw4TXb(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫമ")]
OP70NnGp8SqzyCJIx1hc = [MOwK1lpyNfCgqksX3jhV(u"ࠨࡏ࠶࡙ࠬയ"),IPkQW7LojF3HO18V(u"ࠩࡌࡔ࡙࡜ࠧര"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨറ"),Sj1PYDmIpCUXO26(u"ࠫࡎࡌࡉࡍࡏࠪല"),onweDvmTOUj(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ള")]
ScedY1IpRnvosT9xJwD = MFyptHzDV8m6ANEox1nS0hcJj7Q+Ustrv8LpF4uBKYbfkqNdaP
VqCjboemktrAKgz = MFyptHzDV8m6ANEox1nS0hcJj7Q+OP70NnGp8SqzyCJIx1hc
IEisp6QDSzu1HfZTAGKM8Rle37V = MFyptHzDV8m6ANEox1nS0hcJj7Q+Ustrv8LpF4uBKYbfkqNdaP
yhwiz64qkKYO5 = lVhjYeTAFNyiRctHgmPQXvC9k2qJu+dHw8OxjqMKbTNVZrtvofy4RC+LZKTCp21UVlbDQiH7s9xRj3+EctWpi0OkMgIHX
xZgkz5Av3rKiXu9jaPJw = [
						QQSULIva4ljNO73mFcWw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨഴ")
						,RS7ZoyGAq1c(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩവ")
						,Y5npATFarf1H9wBjc87(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩശ")
						]
wV1DKnFCZBU236 = [
						Jbu2G0Qax8PYWpg(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧഷ")
						,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧസ")
						,Sj1PYDmIpCUXO26(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬഹ")
						,RS7ZoyGAq1c(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭ഺ")
						,Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ഻")
						,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶ഼ࠪ")
						,MOwK1lpyNfCgqksX3jhV(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬഽ")
						,mtEXp14ijx(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭ാ")
						,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧി")
						,Jbu2G0Qax8PYWpg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨീ")
						,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬു")
						,eaF2N0jWLdvHIs8r(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠸ࡸ࡭࠭ൂ")
						,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ൃ")
						]
zdB0Ze19GUobW = wV1DKnFCZBU236+[
				 hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪൄ")
				,Y5npATFarf1H9wBjc87(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ൅")
				,lh6URegmQNq8LWX0HaK5(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭െ")
				,onweDvmTOUj(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧേ")
				,WWbmNvI40sM9Khlp25Ae(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨൈ")
				,Sj1PYDmIpCUXO26(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ൉")
				,Y5npATFarf1H9wBjc87(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩൊ")
				,IPkQW7LojF3HO18V(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪോ")
				,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫൌ")
				,LsG7EDcei1gMShH2aVOCo(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺ്ࠧ")
				,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧൎ")
				,LsG7EDcei1gMShH2aVOCo(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ൏")
				,hxSBTdGpyNVbfu4tr9(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ൐")
				,mtEXp14ijx(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ൑")
				,NQ4hg16DPUxtOyo5iGb(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൒")
				,B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ൓")
				]
urVJDsPi2IFh = [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫൔ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬൕ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭ൖ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧൗ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ൘"),FZBX5WcC3msIDv4hobLd8(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ൙")]
ZEgwHfRnFV4 = {
			 S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࡄࡏࡔࡇࡍࠨ൚")		:[Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸ࠲ࡳࡱࡪࠧ൛")]
			,QQSULIva4ljNO73mFcWw(u"ࠫࡆࡎࡗࡂࡍࠪ൜")		:[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧ൝")]
			,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡁࡌ࡙ࡄࡑࠬ൞")		:[lh6URegmQNq8LWX0HaK5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧൟ")]
			,Jbu2G0Qax8PYWpg(u"ࠨࡃࡏࡅࡗࡇࡂࠨൠ")		:[d0HDrq8Rtk16AlInw4TXb(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰࠫൡ")]
			,WWbmNvI40sM9Khlp25Ae(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬൢ")		:[NQ4hg16DPUxtOyo5iGb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲࡦࡢࡶ࡬ࡱ࡮࠴ࡴࡷࠩൣ")]
			,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ൤")		:[Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬ൥")]
			,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ൦")	:[Jbu2G0Qax8PYWpg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡲࡢࡤ࡬ࡧ࠲ࡺ࡯ࡰࡰࡶ࠲ࡨࡵ࡭ࠨ൧")]
			,IPkQW7LojF3HO18V(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ൨")		:[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡡࡣࡵࡨࡩࡩ࠴࡮ࡦࡶࠪ൩")]
			,lh6URegmQNq8LWX0HaK5(u"ࠫࡇࡕࡋࡓࡃࠪ൪")		:[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨࡰࡱࡩࡺࡴࡪ࠮ࡤࡱࡰࠫ൫")]
			,B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡂࡓࡕࡗࡉࡏ࠭൬")		:[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ൭")]
			,FZBX5WcC3msIDv4hobLd8(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ൮")		:[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ൯")]
			,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ൰")		:[Y5npATFarf1H9wBjc87(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪ൱")]
			,onweDvmTOUj(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ൲")		:[onweDvmTOUj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭൳")]
			,Jbu2G0Qax8PYWpg(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ൴")		:[RS7ZoyGAq1c(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡸࡱࡩ࡯ࠩ൵")]
			,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ൶")	:[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨ൷")]
			,hxSBTdGpyNVbfu4tr9(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭൸")		:[MOwK1lpyNfCgqksX3jhV(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯࡮ࠩ൹")]
			,d0HDrq8Rtk16AlInw4TXb(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩൺ")	:[gy9NA3CROZolfEt4vVzMr(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠺࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪൻ")]
			,QQSULIva4ljNO73mFcWw(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩർ")		:[Sj1PYDmIpCUXO26(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧൽ")]
			,onweDvmTOUj(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨൾ")	:[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫൿ"),hxSBTdGpyNVbfu4tr9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭඀")]
			,mtEXp14ijx(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧඁ")		:[WWbmNvI40sM9Khlp25Ae(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩං")]
			,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪඃ")		:[IPkQW7LojF3HO18V(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡲ࠲࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ඄")]
			,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬඅ")		:[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡡࡤࡶࡲࡶࠬආ")]
			,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧඇ")		:[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭ඈ")]
			,QQSULIva4ljNO73mFcWw(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩඉ")		:[IPkQW7LojF3HO18V(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨඊ")]
			,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪඋ")		:[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪඌ")]
			,eaF2N0jWLdvHIs8r(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ඍ")		:[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬඎ")]
			,MOwK1lpyNfCgqksX3jhV(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧඏ")		:[Sj1PYDmIpCUXO26(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬඐ")]
			,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫඑ")	:[eaF2N0jWLdvHIs8r(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧඒ")]
			,Sj1PYDmIpCUXO26(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬඓ")		:[d0HDrq8Rtk16AlInw4TXb(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡰ࡮ࡴ࡫ࠨඔ")]
			,Q2ZyGqCNYsftTc4MR7n(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧඕ")		:[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬඖ")]
			,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡇࡑࡖࡘࡆ࠭඗")		:[wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬ඘")]
			,IPkQW7LojF3HO18V(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ඙")		:[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬක")]
			,QQSULIva4ljNO73mFcWw(u"ࠫࡎࡌࡉࡍࡏࠪඛ")		:[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ග"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧඝ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨඞ"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪඟ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩච")]
			,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ඡ")	:[RS7ZoyGAq1c(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬජ")]
			,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧඣ")		:[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡲ࠲ࡰ࡯ࡴ࡬ࡱࡷ࠲ࡹࡼࠧඤ")]
			,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ඥ")	:[eaF2N0jWLdvHIs8r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬඦ"),lh6URegmQNq8LWX0HaK5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨට")]
			,Y5npATFarf1H9wBjc87(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫඨ")		:[IPkQW7LojF3HO18V(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴ࡣࡢ࡯ࠪඩ")]
			,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡖࡁࡏࡇࡗࠫඪ")		:[QQSULIva4ljNO73mFcWw(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨණ")]
			,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩඬ")		:[Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦࡧ࠮ࡤࡣࡰࠫත")]
			,hxSBTdGpyNVbfu4tr9(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ථ")	:[hxSBTdGpyNVbfu4tr9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࠴ࡳࡩ࠶ࡸ࠲ࡳ࡫ࡷࡴࠩද")]
			,NQ4hg16DPUxtOyo5iGb(u"ࠫࡘࡎࡏࡇࡊࡄࠫධ")		:[MOwK1lpyNfCgqksX3jhV(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭න")]
			,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ඲")		:[FZBX5WcC3msIDv4hobLd8(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧඳ"),MOwK1lpyNfCgqksX3jhV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨප"),WWbmNvI40sM9Khlp25Ae(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬඵ")]
			,mtEXp14ijx(u"ࠪࡘ࡛ࡌࡕࡏࠩබ")		:[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩභ")]
			,gy9NA3CROZolfEt4vVzMr(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬම")		:[lh6URegmQNq8LWX0HaK5(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡹࡰ࠰࠱࠲࠳࠭࠮ࡰࡽࡩࡧࡩࡡ࠶ࡩࡧ࠻ࡴࡪࡥ࠱ࡤ࡬࡫ࡱ࡮࠮࡮ࡻࡦ࡭࡮ࡳࡡ࠮ࡹࡨࡧ࡮࡯࡭ࡢ࠰ࡶ࡬ࡴࡶࠧඹ")]
			,Y5npATFarf1H9wBjc87(u"࡚ࠧࡃࡔࡓ࡙࠭ය")		:[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭ර")]
			,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ඼")		:[Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭ල")]
			,LsG7EDcei1gMShH2aVOCo(u"ࠫࡗࡋࡐࡐࡕࠪ඾")		:[B2vCEI9FAVP15R8eUbDJdySc(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ඿"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪව"),RS7ZoyGAq1c(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫශ")]
			,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫෂ")	:[FZBX5WcC3msIDv4hobLd8(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧස"),Y5npATFarf1H9wBjc87(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬහ"),gy9NA3CROZolfEt4vVzMr(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ළ")]
			,Y5npATFarf1H9wBjc87(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ෆ")		:[wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭෇"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬ෈"),QQSULIva4ljNO73mFcWw(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫ෉")]
			}
if OnvTrikzfEsY7qU8pgaRBtZy(u"࠲ᒦ"):
	ZEgwHfRnFV4[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࡓ࡝࡙ࡎࡏࡏ්ࠩ")] = [hxSBTdGpyNVbfu4tr9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ෋"),QQSULIva4ljNO73mFcWw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෌"),NQ4hg16DPUxtOyo5iGb(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෍"),Y5npATFarf1H9wBjc87(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෎"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫා"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧැ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪෑ"),hxSBTdGpyNVbfu4tr9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫි"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬී")]
	ZEgwHfRnFV4[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩු")] = [NQ4hg16DPUxtOyo5iGb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ෕"),mtEXp14ijx(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ූ"),MOwK1lpyNfCgqksX3jhV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ෗"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨෘ"),hxSBTdGpyNVbfu4tr9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨෙ"),MOwK1lpyNfCgqksX3jhV(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫේ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧෛ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨො"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩෝ")]
else:
	ZEgwHfRnFV4[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨෞ")] = [lh6URegmQNq8LWX0HaK5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬෟ"),WWbmNvI40sM9Khlp25Ae(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෠"),d0HDrq8Rtk16AlInw4TXb(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෡"),LsG7EDcei1gMShH2aVOCo(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෢"),Q2ZyGqCNYsftTc4MR7n(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ෣"),Q2ZyGqCNYsftTc4MR7n(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ෤"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ෥"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ෦"),Jbu2G0Qax8PYWpg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ෧")]
	ZEgwHfRnFV4[B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ෨")] = [Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ෩"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ෪"),onweDvmTOUj(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ෫"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ෬"),Sj1PYDmIpCUXO26(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ෭"),Sj1PYDmIpCUXO26(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ෮"),mtEXp14ijx(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭෯"),MOwK1lpyNfCgqksX3jhV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ෰"),NQ4hg16DPUxtOyo5iGb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ෱")]
aiwHkjxJEgl0WDeonX1U6fzbuLCp2M = [eaF2N0jWLdvHIs8r(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩෲ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡔࡈࡔࡔࡘࡔࡔࠩෳ"),hxSBTdGpyNVbfu4tr9(u"ࠩࡈࡑࡆࡏࡌࡔࠩ෴"),Sj1PYDmIpCUXO26(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ෵"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࡎ࡙ࡌࡂࡏࡌࡇࡘ࠭෶"),MOwK1lpyNfCgqksX3jhV(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ෷"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡋࡏࡑ࡚ࡒࡊࡘࡒࡐࡔࡖࠫ෸"),QQSULIva4ljNO73mFcWw(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨ෹"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡖࡈࡗ࡙ࡏࡎࡈࠩ෺")]
b9GYdZJsgNV6oF7 = [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡄࡈࡉࡕࡎࡔࠩ෻"),Sj1PYDmIpCUXO26(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬ෼"),RS7ZoyGAq1c(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭෽")]
class eZHYr0ioAk5KjvDU4bBxcud3S7f(RNxwXqM38FQEIzP4in6oeJyOcvSjZh):
	def __init__(KETCehUc1vtORaPl03xDwV,*aargs,**kkwargs):
		KETCehUc1vtORaPl03xDwV.choiceID = -mtEXp14ijx(u"࠳ᒧ")
	def onClick(KETCehUc1vtORaPl03xDwV,e5MjBHhfzOJCcTd4o):
		if e5MjBHhfzOJCcTd4o>=MOwK1lpyNfCgqksX3jhV(u"࠼࠴࠶࠶ᒨ"): KETCehUc1vtORaPl03xDwV.choiceID = e5MjBHhfzOJCcTd4o-MOwK1lpyNfCgqksX3jhV(u"࠼࠴࠶࠶ᒨ")
		KETCehUc1vtORaPl03xDwV.LqeRihS0pKogOI6GvTjB8FkCZQ()
	def NBQJf0u7rSc1eIUvYWtKx(KETCehUc1vtORaPl03xDwV,*aargs):
		KETCehUc1vtORaPl03xDwV.button0,KETCehUc1vtORaPl03xDwV.button1,KETCehUc1vtORaPl03xDwV.button2 = aargs[onweDvmTOUj(u"࠵ᒪ")],aargs[Y5npATFarf1H9wBjc87(u"࠵ᒩ")],aargs[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠸ᒫ")]
		KETCehUc1vtORaPl03xDwV.header,KETCehUc1vtORaPl03xDwV.text = aargs[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠳ᒬ")],aargs[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵ᒭ")]
		KETCehUc1vtORaPl03xDwV.profile,KETCehUc1vtORaPl03xDwV.direction = aargs[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷ᒮ")],aargs[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠹ᒯ")]
		KETCehUc1vtORaPl03xDwV.buttonstimeout,KETCehUc1vtORaPl03xDwV.closetimeout = aargs[onweDvmTOUj(u"࠼ᒱ")],aargs[QQSULIva4ljNO73mFcWw(u"࠼ᒰ")]
		if KETCehUc1vtORaPl03xDwV.buttonstimeout>NQ4hg16DPUxtOyo5iGb(u"࠶ᒲ") or KETCehUc1vtORaPl03xDwV.closetimeout>NQ4hg16DPUxtOyo5iGb(u"࠶ᒲ"): KETCehUc1vtORaPl03xDwV.enable_progressbar = hxSBTdGpyNVbfu4tr9(u"࡙ࡸࡵࡦᛯ")
		else: KETCehUc1vtORaPl03xDwV.enable_progressbar = Y5npATFarf1H9wBjc87(u"ࡌࡡ࡭ࡵࡨᛰ")
		KETCehUc1vtORaPl03xDwV.image_filename = nA9zdBHP4q8XrVLi3CR.replace(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ෾"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࡟ࠨ෿")+str(p1BoraOuWL.time())+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡠࠩ฀"))
		KETCehUc1vtORaPl03xDwV.image_filename = KETCehUc1vtORaPl03xDwV.image_filename.replace(eaF2N0jWLdvHIs8r(u"ࠨ࡞࡟ࠫก"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩ࡟ࡠࡡࡢࠧข")).replace(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪ࠳࠴࠭ฃ"),IPkQW7LojF3HO18V(u"ࠫ࠴࠵࠯࠰ࠩค"))
		KETCehUc1vtORaPl03xDwV.image_height = DkzsprAlwfGdgqHMhNtZvO5i6Rba(KETCehUc1vtORaPl03xDwV.button0,KETCehUc1vtORaPl03xDwV.button1,KETCehUc1vtORaPl03xDwV.button2,KETCehUc1vtORaPl03xDwV.header,KETCehUc1vtORaPl03xDwV.text,KETCehUc1vtORaPl03xDwV.profile,KETCehUc1vtORaPl03xDwV.direction,KETCehUc1vtORaPl03xDwV.enable_progressbar,KETCehUc1vtORaPl03xDwV.image_filename)
		KETCehUc1vtORaPl03xDwV.show()
		KETCehUc1vtORaPl03xDwV.getControl(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠹࠱࠷࠳ᒳ")).setImage(KETCehUc1vtORaPl03xDwV.image_filename)
		KETCehUc1vtORaPl03xDwV.getControl(eaF2N0jWLdvHIs8r(u"࠺࠲࠸࠴ᒴ")).setHeight(KETCehUc1vtORaPl03xDwV.image_height)
		if not KETCehUc1vtORaPl03xDwV.button1 and KETCehUc1vtORaPl03xDwV.button0 and KETCehUc1vtORaPl03xDwV.button2: KETCehUc1vtORaPl03xDwV.getControl(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠼࠴࠶࠸ᒶ")).setPosition(-mtEXp14ijx(u"࠶࠷࠶ᒷ"),mtEXp14ijx(u"࠲ᒵ"))
		return KETCehUc1vtORaPl03xDwV.image_filename,KETCehUc1vtORaPl03xDwV.image_height
	def Fo5M6h80aQvRd9eHcSptXJwnsAGj(KETCehUc1vtORaPl03xDwV):
		if KETCehUc1vtORaPl03xDwV.buttonstimeout:
			KETCehUc1vtORaPl03xDwV.th1 = RrCB5k9XV6hYNSlIKJ2.Thread(target=KETCehUc1vtORaPl03xDwV.IIOSFRsMUm,args=())
			KETCehUc1vtORaPl03xDwV.th1.start()
		else: KETCehUc1vtORaPl03xDwV.DjoK1WrSavpe7yg()
	def IIOSFRsMUm(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.getControl(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠾࠶࠲࠱ᒸ")).setEnabled(hxSBTdGpyNVbfu4tr9(u"ࡔࡳࡷࡨᛱ"))
		for jUSuZAztxy34TB5CIP2 in range(Y5npATFarf1H9wBjc87(u"࠷ᒹ"),KETCehUc1vtORaPl03xDwV.buttonstimeout+Y5npATFarf1H9wBjc87(u"࠷ᒹ")):
			p1BoraOuWL.sleep(lh6URegmQNq8LWX0HaK5(u"࠱ᒺ"))
			j9MQLB6RHDGVTAN8koYUrih = int(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠲࠲࠳ᒻ")*jUSuZAztxy34TB5CIP2/KETCehUc1vtORaPl03xDwV.buttonstimeout)
			KETCehUc1vtORaPl03xDwV.glvIEarDZW3S(j9MQLB6RHDGVTAN8koYUrih)
			if KETCehUc1vtORaPl03xDwV.choiceID>MOwK1lpyNfCgqksX3jhV(u"࠲ᒼ"): break
		KETCehUc1vtORaPl03xDwV.DjoK1WrSavpe7yg()
	def XP2O6mQDER(KETCehUc1vtORaPl03xDwV):
		if KETCehUc1vtORaPl03xDwV.closetimeout:
			KETCehUc1vtORaPl03xDwV.th2 = RrCB5k9XV6hYNSlIKJ2.Thread(target=KETCehUc1vtORaPl03xDwV.zAojn5lrJiDWtKIOMHbZ,args=())
			KETCehUc1vtORaPl03xDwV.th2.start()
		else: KETCehUc1vtORaPl03xDwV.DjoK1WrSavpe7yg()
	def zAojn5lrJiDWtKIOMHbZ(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.getControl(Q2ZyGqCNYsftTc4MR7n(u"࠼࠴࠷࠶ᒽ")).setEnabled(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡕࡴࡸࡩᛲ"))
		p1BoraOuWL.sleep(KETCehUc1vtORaPl03xDwV.buttonstimeout)
		for jUSuZAztxy34TB5CIP2 in range(KETCehUc1vtORaPl03xDwV.closetimeout-FZBX5WcC3msIDv4hobLd8(u"࠵ᒾ"),-FZBX5WcC3msIDv4hobLd8(u"࠵ᒾ"),-FZBX5WcC3msIDv4hobLd8(u"࠵ᒾ")):
			p1BoraOuWL.sleep(Y5npATFarf1H9wBjc87(u"࠶ᒿ"))
			j9MQLB6RHDGVTAN8koYUrih = int(gy9NA3CROZolfEt4vVzMr(u"࠷࠰࠱ᓀ")*jUSuZAztxy34TB5CIP2/KETCehUc1vtORaPl03xDwV.closetimeout)
			KETCehUc1vtORaPl03xDwV.glvIEarDZW3S(j9MQLB6RHDGVTAN8koYUrih)
			if KETCehUc1vtORaPl03xDwV.choiceID>lh6URegmQNq8LWX0HaK5(u"࠰ᓁ"): break
		if KETCehUc1vtORaPl03xDwV.closetimeout>hxSBTdGpyNVbfu4tr9(u"࠱ᓂ"): KETCehUc1vtORaPl03xDwV.choiceID = LsG7EDcei1gMShH2aVOCo(u"࠳࠳ᓃ")
		KETCehUc1vtORaPl03xDwV.LqeRihS0pKogOI6GvTjB8FkCZQ()
	def glvIEarDZW3S(KETCehUc1vtORaPl03xDwV,j9MQLB6RHDGVTAN8koYUrih):
		KETCehUc1vtORaPl03xDwV.precent = j9MQLB6RHDGVTAN8koYUrih
		KETCehUc1vtORaPl03xDwV.getControl(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠼࠴࠷࠶ᓄ")).setPercent(KETCehUc1vtORaPl03xDwV.precent)
	def DjoK1WrSavpe7yg(KETCehUc1vtORaPl03xDwV):
		if KETCehUc1vtORaPl03xDwV.button0: KETCehUc1vtORaPl03xDwV.getControl(MOwK1lpyNfCgqksX3jhV(u"࠽࠵࠷࠰ᓅ")).setEnabled(OnvTrikzfEsY7qU8pgaRBtZy(u"ࡖࡵࡹࡪᛳ"))
		if KETCehUc1vtORaPl03xDwV.button1: KETCehUc1vtORaPl03xDwV.getControl(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠾࠶࠱࠲ᓆ")).setEnabled(d0HDrq8Rtk16AlInw4TXb(u"ࡗࡶࡺ࡫ᛴ"))
		if KETCehUc1vtORaPl03xDwV.button2: KETCehUc1vtORaPl03xDwV.getControl(WWbmNvI40sM9Khlp25Ae(u"࠿࠰࠲࠴ᓇ")).setEnabled(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡘࡷࡻࡥᛵ"))
	def LqeRihS0pKogOI6GvTjB8FkCZQ(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.close()
		try: Dh9MOxeTj6FW.remove(KETCehUc1vtORaPl03xDwV.image_filename)
		except: pass
class jIoHl6d5pfVXu():
	def __init__(KETCehUc1vtORaPl03xDwV,showDialogs=eaF2N0jWLdvHIs8r(u"ࡌࡡ࡭ࡵࡨᛷ"),logErrors=MOwK1lpyNfCgqksX3jhV(u"࡙ࡸࡵࡦᛶ")):
		KETCehUc1vtORaPl03xDwV.showDialogs = showDialogs
		KETCehUc1vtORaPl03xDwV.logErrors = logErrors
		KETCehUc1vtORaPl03xDwV.finishedLIST,KETCehUc1vtORaPl03xDwV.failedLIST = [],[]
		KETCehUc1vtORaPl03xDwV.statusDICT,KETCehUc1vtORaPl03xDwV.resultsDICT = {},{}
		KETCehUc1vtORaPl03xDwV.processesLIST = []
		KETCehUc1vtORaPl03xDwV.starttimeDICT,KETCehUc1vtORaPl03xDwV.finishtimeDICT,KETCehUc1vtORaPl03xDwV.elpasedtimeDICT = {},{},{}
	def ppeLl851aw34zyqGMKmQOsVBFYPkA(KETCehUc1vtORaPl03xDwV,RGlxXTgCOBAseZ,cvbPywgE8x15NqieoSmRFK2,*aargs):
		RGlxXTgCOBAseZ = str(RGlxXTgCOBAseZ)
		KETCehUc1vtORaPl03xDwV.statusDICT[RGlxXTgCOBAseZ] = eaF2N0jWLdvHIs8r(u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭ฅ")
		if KETCehUc1vtORaPl03xDwV.showDialogs: NCXj2ri3Unm6TFWIgwh(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠧฆ"),RGlxXTgCOBAseZ)
		RBnCc1b5JA = RrCB5k9XV6hYNSlIKJ2.Thread(target=KETCehUc1vtORaPl03xDwV.spAS53U2NkyK1YHjJnV9zF8t6mgDI,args=(RGlxXTgCOBAseZ,cvbPywgE8x15NqieoSmRFK2,aargs))
		KETCehUc1vtORaPl03xDwV.processesLIST.append(RBnCc1b5JA)
		return RBnCc1b5JA
	def FghEzWo26wCTxOYmsAQPl9d(KETCehUc1vtORaPl03xDwV,RGlxXTgCOBAseZ,cvbPywgE8x15NqieoSmRFK2,*aargs):
		RBnCc1b5JA = KETCehUc1vtORaPl03xDwV.ppeLl851aw34zyqGMKmQOsVBFYPkA(RGlxXTgCOBAseZ,cvbPywgE8x15NqieoSmRFK2,*aargs)
		RBnCc1b5JA.start()
	def spAS53U2NkyK1YHjJnV9zF8t6mgDI(KETCehUc1vtORaPl03xDwV,RGlxXTgCOBAseZ,cvbPywgE8x15NqieoSmRFK2,aargs):
		RGlxXTgCOBAseZ = str(RGlxXTgCOBAseZ)
		KETCehUc1vtORaPl03xDwV.starttimeDICT[RGlxXTgCOBAseZ] = p1BoraOuWL.time()
		try:
			KETCehUc1vtORaPl03xDwV.resultsDICT[RGlxXTgCOBAseZ] = cvbPywgE8x15NqieoSmRFK2(*aargs)
			if Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨง") in str(cvbPywgE8x15NqieoSmRFK2) and not KETCehUc1vtORaPl03xDwV.resultsDICT[RGlxXTgCOBAseZ].succeeded:
				YosJW4Tklp2IyQ0jPnam(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹࠦࡤࡶࡧࠣࡸࡴࠦࡴࡩࡴࡨࡥࡩ࡫ࡤࠡࡑࡓࡉࡓ࡛ࡒࡍࠢࡩࡥ࡮ࡲࠧจ"))
			KETCehUc1vtORaPl03xDwV.finishedLIST.append(RGlxXTgCOBAseZ)
			KETCehUc1vtORaPl03xDwV.statusDICT[RGlxXTgCOBAseZ] = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠫฉ")
		except Exception as wl7sKIoZfU:
			if KETCehUc1vtORaPl03xDwV.logErrors:
				zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
				if zi68Y9T7ngdIXKALbv3fjVEeOJm!=Sj1PYDmIpCUXO26(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ช"): EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
			KETCehUc1vtORaPl03xDwV.failedLIST.append(RGlxXTgCOBAseZ)
			KETCehUc1vtORaPl03xDwV.statusDICT[RGlxXTgCOBAseZ] = WWbmNvI40sM9Khlp25Ae(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫซ")
		KETCehUc1vtORaPl03xDwV.finishtimeDICT[RGlxXTgCOBAseZ] = p1BoraOuWL.time()
		KETCehUc1vtORaPl03xDwV.elpasedtimeDICT[RGlxXTgCOBAseZ] = KETCehUc1vtORaPl03xDwV.finishtimeDICT[RGlxXTgCOBAseZ] - KETCehUc1vtORaPl03xDwV.starttimeDICT[RGlxXTgCOBAseZ]
	def hvl3ywiB0ugt2XbTLmk6fZcr(KETCehUc1vtORaPl03xDwV):
		for g83awKWHVdSA6n in KETCehUc1vtORaPl03xDwV.processesLIST:
			g83awKWHVdSA6n.start()
	def Xs7m4RhoVbwx5ZtzI8LlBCe(KETCehUc1vtORaPl03xDwV):
		while nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭ฌ") in list(KETCehUc1vtORaPl03xDwV.statusDICT.values()): p1BoraOuWL.sleep(Jbu2G0Qax8PYWpg(u"࠱࠯࠲࠳࠴ᓈ"))
def oLbyIu20K5BSF3k():
	fdk8NJMDbPh = LCIFdjzi5kVmRwehouHQ.getSetting(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪญ"))
	if fdk8NJMDbPh==Y0Uhv2t8E67:
		R1kGLDdY24ZyopjNWhfK5arUm,Q3PT7xKFt6ZCy9NdopYrAeR0vfU = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪฎ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡆࡢ࡮ࡶࡩᛸ")
		return R1kGLDdY24ZyopjNWhfK5arUm,Q3PT7xKFt6ZCy9NdopYrAeR0vfU
	try: Dh9MOxeTj6FW.makedirs(Vd1J5lD9uAsMUoXW)
	except: pass
	R1kGLDdY24ZyopjNWhfK5arUm,Q3PT7xKFt6ZCy9NdopYrAeR0vfU = eaF2N0jWLdvHIs8r(u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭ฏ"),eaF2N0jWLdvHIs8r(u"ࡕࡴࡸࡩ᛹")
	XEsTIxytD8MGkOVo = [Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩ࠻࠲࠺࠴࠰ࠨฐ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪ࠶࠵࠸࠱࠯࠳࠳࠲࠶࠿ࠧฑ"),MOwK1lpyNfCgqksX3jhV(u"ࠫ࠷࠶࠲࠲࠰࠴࠵࠳࠸࠴ࡢࠩฒ"),lh6URegmQNq8LWX0HaK5(u"ࠬ࠸࠰࠳࠳࠱࠵࠷࠴࠳࠱ࠩณ"),LsG7EDcei1gMShH2aVOCo(u"࠭࠲࠱࠴࠵࠲࠵࠸࠮࠱࠴ࠪด"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧ࠳࠲࠵࠶࠳࠷࠰࠯࠴࠵ࠫต"),eaF2N0jWLdvHIs8r(u"ࠨ࠴࠳࠶࠸࠴࠰࠴࠰࠳࠺ࠬถ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩ࠵࠴࠷࠹࠮࠱࠷࠱࠵࠻࠭ท"),gy9NA3CROZolfEt4vVzMr(u"ࠪ࠶࠵࠸࠳࠯࠲࠹࠲࠵࠼ࠧธ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫ࠷࠶࠲࠴࠰࠴࠴࠳࠸࠸ࠨน"),QQSULIva4ljNO73mFcWw(u"ࠬ࠸࠰࠳࠶࠱࠴࠶࠴࠱࠵ࠩบ")]
	oHTWevmdpzU0C4iFZ1Y = XEsTIxytD8MGkOVo[-Rz34c0NP5BGo1WuTZxSfOKj(u"࠲ᓉ")]
	qq86brMnIWQDdJH = rlSHPhqT6UBnxLkMft0iWYspV(oHTWevmdpzU0C4iFZ1Y)
	PoLp79UazRdOiCsGVJwmfZMW1vHBe = rlSHPhqT6UBnxLkMft0iWYspV(Y0Uhv2t8E67)
	if PoLp79UazRdOiCsGVJwmfZMW1vHBe>qq86brMnIWQDdJH:
		R1kGLDdY24ZyopjNWhfK5arUm = aSf0iWG1kA7FsqjHbuC8NXB(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭ป")
	return R1kGLDdY24ZyopjNWhfK5arUm,Q3PT7xKFt6ZCy9NdopYrAeR0vfU
def PtoIGCUhApmdzjnSarDK04NWg5Biky():
	if aSf0iWG1kA7FsqjHbuC8NXB(u"࠳ᓊ"):
		ACWopfziEaFI5v = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠳ᓋ")
		for e6O2FCPu54lBwk,AuoU3pNCiLWxlKYOHh8QmwqS41kz,ggpYWrvRkuJCa5z1eP49OBHsm in Dh9MOxeTj6FW.walk(nnyfJE0MzRWolCuK68rxd,topdown=B2vCEI9FAVP15R8eUbDJdySc(u"ࡈࡤࡰࡸ࡫᛺")):
			ACWopfziEaFI5v += len(ggpYWrvRkuJCa5z1eP49OBHsm)
	if ACWopfziEaFI5v>d0HDrq8Rtk16AlInw4TXb(u"࠹࠵࠶࠰ᓌ"): IlTEWy8f4bpjLa7UR0c2qDY6S15Q(nnyfJE0MzRWolCuK68rxd,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡘࡷࡻࡥ᛼"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࡉࡥࡱࡹࡥ᛻"))
	return
def pmefPx7TZo1HYKUBJ9azqhMcQFid(hpnDbQ9u8ztEJ0fBaxv,p5YZ2bOGk7KPuMrD4acHlFUdBCN):
	sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG = NQ4hg16DPUxtOyo5iGb(u"࡚ࡲࡶࡧ᛾"),gy9NA3CROZolfEt4vVzMr(u"ࡋࡧ࡬ࡴࡧ᛽"),gy9NA3CROZolfEt4vVzMr(u"ࡋࡧ࡬ࡴࡧ᛽")
	DQs7pSx58I4n,x0LXdHBFwj7EtMfu,wnpJZgr3dKeoyuQUXsvM60B2T9N8,h9h3xqMnC56kjUOKGgBbWQ4,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = hpnDbQ9u8ztEJ0fBaxv
	sLHoSMrQmzu5y9EtUIY3O0aJgidk = DQs7pSx58I4n,x0LXdHBFwj7EtMfu,wnpJZgr3dKeoyuQUXsvM60B2T9N8,h9h3xqMnC56kjUOKGgBbWQ4,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,FbewQr7IVXqN0ijhOtm2vAnauzZT,hxSBTdGpyNVbfu4tr9(u"ࠧࠨผ"),MIe5q0WmGnJF9wp2tfk
	JtU3cDMkSF = int(h9h3xqMnC56kjUOKGgBbWQ4)
	PKHabnks3tlVJvwISMWG2mo6z = int(JtU3cDMkSF%NQ4hg16DPUxtOyo5iGb(u"࠶࠶ᓍ"))
	deBF2JXw4DVnTl = int(JtU3cDMkSF/Jbu2G0Qax8PYWpg(u"࠷࠰ᓎ"))
	exWqyzvc6BgsXV = LCIFdjzi5kVmRwehouHQ.getSetting(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨฝ"))
	if not exWqyzvc6BgsXV: LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩพ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡅ࡚࡚ࡏࠨฟ"))
	njEfKlRrLoyqwt0,Q3PT7xKFt6ZCy9NdopYrAeR0vfU = oLbyIu20K5BSF3k()
	if Q3PT7xKFt6ZCy9NdopYrAeR0vfU:
		ztgqWUaDpe8CE9N(d0HDrq8Rtk16AlInw4TXb(u"ࠫࠬภ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࠭ม"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩย"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧร")+Y0Uhv2t8E67)
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫฤ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬล"))
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ฦ"),IPkQW7LojF3HO18V(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬว"))
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,Sj1PYDmIpCUXO26(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨศ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫษ"))
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪส"),NQ4hg16DPUxtOyo5iGb(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ห"))
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,onweDvmTOUj(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬฬ"),Sj1PYDmIpCUXO26(u"ࠪࡗࡎ࡚ࡅࡔࡡ࡙ࡉࡗࡏࡆ࡚ࠩอ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬࡯ࡴࡶࡤࠫฮ"),LsG7EDcei1gMShH2aVOCo(u"ࠬ࠭ฯ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨะ"),WWbmNvI40sM9Khlp25Ae(u"ࠧࠨั"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Q2ZyGqCNYsftTc4MR7n(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫา"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࠪำ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Sj1PYDmIpCUXO26(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭ิ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠬี"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Y5npATFarf1H9wBjc87(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹࠧึ"),lh6URegmQNq8LWX0HaK5(u"࠭ࠧื"))
		LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴุࠩ"),Jbu2G0Qax8PYWpg(u"ࠨูࠩ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬ฺ࠭"),Jbu2G0Qax8PYWpg(u"ࠪࠫ฻"))
		LCIFdjzi5kVmRwehouHQ.setSetting(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫ฼"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭฽"))
		LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ฾"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࠨ฿"))
		LCIFdjzi5kVmRwehouHQ.setSetting(Q2ZyGqCNYsftTc4MR7n(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪเ"),onweDvmTOUj(u"ࠩࠪแ"))
		import G4zaNTEvFt
		if njEfKlRrLoyqwt0==WWbmNvI40sM9Khlp25Ae(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪโ"):
			xrFqGMab4uLKZcS(gy9NA3CROZolfEt4vVzMr(u"ࠫࡓࡕࡔࡊࡅࡈࠫใ"),IPkQW7LojF3HO18V(u"ࠬ࠴ࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡔࡋࡐࡔࡑࡋࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫไ")+StrQOzK40pE8Dbgdj95U+QQSULIva4ljNO73mFcWw(u"࠭ࠠ࡞ࠩๅ"))
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,hxSBTdGpyNVbfu4tr9(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨๆ"))
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ็"))
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ่"))
			wh7i1HEySabUpQJ6frj3lVX(IPkQW7LojF3HO18V(u"ࡔࡳࡷࡨ᛿"),[qQ4BC6vW5YOfo])
		else:
			xrFqGMab4uLKZcS(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡒࡔ࡚ࡉࡄࡇ้ࠪ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫ࠳ࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ๊")+StrQOzK40pE8Dbgdj95U+LsG7EDcei1gMShH2aVOCo(u"ࠬࠦ࡝ࠨ๋"))
			ztgqWUaDpe8CE9N(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠧ์"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨํ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ๎"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ๏"))
			wh7i1HEySabUpQJ6frj3lVX(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡇࡣ࡯ࡷࡪᜀ"),[])
			W2sm89LliTnf(hxSBTdGpyNVbfu4tr9(u"ࡈࡤࡰࡸ࡫ᜁ"))
			G4zaNTEvFt.z9bBQFsXTWgGtlC8PoryMw1pfnAL0V()
			G4zaNTEvFt.cPzAIOrxUw5XlveWpHSEhR(MOwK1lpyNfCgqksX3jhV(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ๐"),gy9NA3CROZolfEt4vVzMr(u"ࡉࡥࡱࡹࡥᜂ"))
			G4zaNTEvFt.cPzAIOrxUw5XlveWpHSEhR(Q2ZyGqCNYsftTc4MR7n(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ๑"),WWbmNvI40sM9Khlp25Ae(u"ࡊࡦࡲࡳࡦᜃ"))
			G4zaNTEvFt.hceUB9uxLZ(Y5npATFarf1H9wBjc87(u"ࡋࡧ࡬ࡴࡧᜄ"))
			G4zaNTEvFt.pdHeIDkWABLxGiFhzturXRMZ97K(LsG7EDcei1gMShH2aVOCo(u"ࡌࡡ࡭ࡵࡨᜅ"))
			G4zaNTEvFt.kkvSXEJ68UA0uFD(LsG7EDcei1gMShH2aVOCo(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ๒"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭๓"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡆࡢ࡮ࡶࡩᜆ"))
			try:
				omPWgHiduVj2QvEI5b = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,gy9NA3CROZolfEt4vVzMr(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ๔"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ๕"),RS7ZoyGAq1c(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭๖"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ๗"))
				A9AHaS2wuVdJxqs1NicolkYI = VmrWjDNze5tadycvpHOGnTb.Addon(id=NQ4hg16DPUxtOyo5iGb(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ๘"))
				A9AHaS2wuVdJxqs1NicolkYI.setSetting(d0HDrq8Rtk16AlInw4TXb(u"ࠬࡧࡶ࠯ࡣࡸࡸࡴࡥࡰࡪࡥ࡮ࠫ๙"),RS7ZoyGAq1c(u"࠭ࡦࡢ࡮ࡶࡩࠬ๚"))
			except: pass
			try:
				omPWgHiduVj2QvEI5b = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ๛"),QQSULIva4ljNO73mFcWw(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ๜"),Sj1PYDmIpCUXO26(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭๝"),gy9NA3CROZolfEt4vVzMr(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ๞"))
				A9AHaS2wuVdJxqs1NicolkYI = VmrWjDNze5tadycvpHOGnTb.Addon(id=WWbmNvI40sM9Khlp25Ae(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ๟"))
				A9AHaS2wuVdJxqs1NicolkYI.setSetting(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡧࡶ࠯ࡸ࡬ࡨࡪࡵ࡟ࡲࡷࡤࡰ࡮ࡺࡹࠨ๠"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭࠳ࠨ๡"))
			except: pass
			try:
				omPWgHiduVj2QvEI5b = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,Jbu2G0Qax8PYWpg(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ๢"),eaF2N0jWLdvHIs8r(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ๣"),WWbmNvI40sM9Khlp25Ae(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๤"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ๥"))
				A9AHaS2wuVdJxqs1NicolkYI = VmrWjDNze5tadycvpHOGnTb.Addon(id=MOwK1lpyNfCgqksX3jhV(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ๦"))
				A9AHaS2wuVdJxqs1NicolkYI.setSetting(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡧࡶ࠯ࡕࡗࡖࡊࡇࡍࡔࡇࡏࡉࡈ࡚ࡉࡐࡐࠪ๧"),Y5npATFarf1H9wBjc87(u"࠭࠲ࠨ๨"))
			except: pass
		oo76muA1GlEh9s0ZHNT4yMXQzipP = itTndG7sM4oAk90qEX83(kRpnCV8cqdhDew2suUxPfaQTA5)
		oo76muA1GlEh9s0ZHNT4yMXQzipP = itTndG7sM4oAk90qEX83(YbTWJNjEGPC12RZzHioatgvu)
		LCIFdjzi5kVmRwehouHQ.setSetting(Jbu2G0Qax8PYWpg(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ๩"),Y0Uhv2t8E67)
		G4zaNTEvFt.arkQJHYMfi0RIKz3m4hG17ZPup9U(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡇࡣ࡯ࡷࡪᜇ"))
		return
	sF0NOtG4b1RY = LCIFdjzi5kVmRwehouHQ.getSetting(mtEXp14ijx(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ๪"))
	UMlKSYDNfaR0Z1sbFvPwp = JphHZ4KdkcF19vtoVlTYx5LPM(p5YZ2bOGk7KPuMrD4acHlFUdBCN)
	onHbevfWF7j3EIA = JphHZ4KdkcF19vtoVlTYx5LPM(x0LXdHBFwj7EtMfu)
	MZQCVwjDvFN = [onweDvmTOUj(u"࠰ᓖ"),WWbmNvI40sM9Khlp25Ae(u"࠲࠷ᓐ"),Jbu2G0Qax8PYWpg(u"࠳࠺ᓑ"),mtEXp14ijx(u"࠴࠽ᓒ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠲࠷ᓏ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠹࠴ᓕ"),hxSBTdGpyNVbfu4tr9(u"࠹࠵ᓓ"),Jbu2G0Qax8PYWpg(u"࠺࠹ᓔ")]
	UZKwLyEjDgcl = [B2vCEI9FAVP15R8eUbDJdySc(u"࠱ᓞ"),onweDvmTOUj(u"࠳࠸ᓘ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠴࠻ᓙ"),LsG7EDcei1gMShH2aVOCo(u"࠵࠾ᓚ"),hxSBTdGpyNVbfu4tr9(u"࠳࠸ᓗ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠳࠵ᓝ"),Y5npATFarf1H9wBjc87(u"࠺࠶ᓛ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠻࠳ᓜ")]
	SSxWq1rjFQfRBg = deBF2JXw4DVnTl not in UZKwLyEjDgcl
	UOroI5nQtAfPlp9MsmXLyRqbixG2 = deBF2JXw4DVnTl in [hxSBTdGpyNVbfu4tr9(u"࠷࠹ᓢ"),NQ4hg16DPUxtOyo5iGb(u"࠴࠻ᓟ"),RS7ZoyGAq1c(u"࠻࠶ᓡ"),lh6URegmQNq8LWX0HaK5(u"࠺࠶ᓠ")]
	CG4IH23zKaLWOXV = JtU3cDMkSF in [LsG7EDcei1gMShH2aVOCo(u"࠲࠷࠷ᓤ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠸࠷࠱ᓣ")]
	GdEU6pL40ibF7yQolXHNgMRknB = (SSxWq1rjFQfRBg or UOroI5nQtAfPlp9MsmXLyRqbixG2) and not CG4IH23zKaLWOXV
	EExMb51ql9zCOaJ0K = sF0NOtG4b1RY!=LsG7EDcei1gMShH2aVOCo(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ๫") and (sF0NOtG4b1RY or not yboV6YS5n9WtE1arxOed)
	UWFqlOVrQ5xM7JZc8X9 = d0HDrq8Rtk16AlInw4TXb(u"ࠪࡸࡾࡶࡥ࠾ࠩ๬") in sF0NOtG4b1RY
	yg5CFvk7xd = JtU3cDMkSF in [q6yUEoKVDb0fXmc8vhrMk7N(u"࠵࠻࠷ᓯ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠶࠼࠲ᓰ"),IPkQW7LojF3HO18V(u"࠷࠶࠴ᓱ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠱࠷࠶ᓫ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࠲࠸࠸ᓬ"),Sj1PYDmIpCUXO26(u"࠳࠹࠺ᓭ"),LsG7EDcei1gMShH2aVOCo(u"࠴࠺࠼ᓮ"),hxSBTdGpyNVbfu4tr9(u"࠷࠶࠹ᓪ"),Jbu2G0Qax8PYWpg(u"࠺࠺࠶ᓧ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࠸࠸࠵ᓥ"),onweDvmTOUj(u"࠹࠹࠷ᓦ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠻࠻࠺ᓨ"),FZBX5WcC3msIDv4hobLd8(u"࠼࠼࠵ᓩ")]
	kV5Wue06vFixocBhPIZY9z = PKHabnks3tlVJvwISMWG2mo6z==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠹ᓲ") or JtU3cDMkSF in [Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠳࠷࠹ᓴ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠹࠶࠼ᓶ"),LsG7EDcei1gMShH2aVOCo(u"࠸࠶࠸ᓵ"),Q2ZyGqCNYsftTc4MR7n(u"࠵࠷ᓳ")]
	PYpfEGdmi7 = not yg5CFvk7xd
	Wzds9HV8Uahvcgbi7JfrFDynxt6 = not kV5Wue06vFixocBhPIZY9z
	E3ENOn5GcABit9Pu8Cfy = UMlKSYDNfaR0Z1sbFvPwp in [NQ4hg16DPUxtOyo5iGb(u"ࠫࠬ๭"),FZBX5WcC3msIDv4hobLd8(u"ࠬ࠴࠮ࠨ๮")]
	I5ogcAKl2SLZbOWaUzd1X3B4xN = E3ENOn5GcABit9Pu8Cfy or PYpfEGdmi7
	S6vIGTDHsY1hMxwda0t9Wr2jmUzyX = E3ENOn5GcABit9Pu8Cfy or Wzds9HV8Uahvcgbi7JfrFDynxt6 or UWFqlOVrQ5xM7JZc8X9
	YxeGWwXB0EvFjftT21mk38irKs = JtU3cDMkSF not in [wKdxVbTc0X9NSiespM8OvHGUhf(u"࠴࠹࠴ᓻ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠷࠼࠱ᓷ"),d0HDrq8Rtk16AlInw4TXb(u"࠵࠺࠺ᓼ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠲࠸࠲ᓹ"),Y5npATFarf1H9wBjc87(u"࠹࠳࠱ᓸ"),LsG7EDcei1gMShH2aVOCo(u"࠶࠶࠳ᓺ")]
	if exWqyzvc6BgsXV==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡓࡕࡑࡓࠫ๯"): YDyJI1oOFtW46NXih = kV5Wue06vFixocBhPIZY9z or yg5CFvk7xd
	else: YDyJI1oOFtW46NXih = Y5npATFarf1H9wBjc87(u"ࡖࡵࡹࡪᜈ")
	owspWiVG2n = deBF2JXw4DVnTl in [Rz34c0NP5BGo1WuTZxSfOKj(u"࠼࠺ᓾ"),Y5npATFarf1H9wBjc87(u"࠻࠺ᓽ")]
	lAYw2i46g9r = JtU3cDMkSF in [Y5npATFarf1H9wBjc87(u"࠸࠸࠱ᓿ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠷࠳࠲ᔀ")]
	TjewJCnXKLERo2Afh3zvtZ7clkU = not owspWiVG2n and not lAYw2i46g9r
	S4pVKUIoj1wBQl5T68tZHP2 = I5ogcAKl2SLZbOWaUzd1X3B4xN and S6vIGTDHsY1hMxwda0t9Wr2jmUzyX and YxeGWwXB0EvFjftT21mk38irKs and YDyJI1oOFtW46NXih and TjewJCnXKLERo2Afh3zvtZ7clkU
	rtgeuo8v3CXnIlHJVNpG6dDhqOY0Q = YxeGWwXB0EvFjftT21mk38irKs and YDyJI1oOFtW46NXih and TjewJCnXKLERo2Afh3zvtZ7clkU
	u5pvoJr1lz = rtgeuo8v3CXnIlHJVNpG6dDhqOY0Q
	fwVcgrzYhUP3 = LCIFdjzi5kVmRwehouHQ.getSetting(hxSBTdGpyNVbfu4tr9(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡶࡲࡰࡸ࡬ࡨࡪࡸࠧ๰"))
	ZZ3eIHOtKyjs = LCIFdjzi5kVmRwehouHQ.getSetting(Jbu2G0Qax8PYWpg(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡣࡰࡦࡨࠫ๱"))
	if Y5npATFarf1H9wBjc87(u"࠲ᔁ") and EExMb51ql9zCOaJ0K and S4pVKUIoj1wBQl5T68tZHP2:
		NNiTvyBp08496qZC3mKeHjP5uGLnFX = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,gy9NA3CROZolfEt4vVzMr(u"ࠩ࡯࡭ࡸࡺࠧ๲"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ๳")+fwVcgrzYhUP3+RS7ZoyGAq1c(u"ࠫࡤ࠭๴")+ZZ3eIHOtKyjs,sLHoSMrQmzu5y9EtUIY3O0aJgidk)
		if NNiTvyBp08496qZC3mKeHjP5uGLnFX:
			xrFqGMab4uLKZcS(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬ࠭๵"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭࠮ࠡࠢࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ๶")+fwVcgrzYhUP3+Jbu2G0Qax8PYWpg(u"ࠧࡠࠩ๷")+ZZ3eIHOtKyjs+gy9NA3CROZolfEt4vVzMr(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧ๸"))
			if KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠳ᔂ") and UWFqlOVrQ5xM7JZc8X9:
				ppyur8heDIZa = []
				from WrbQPqX0ZI import ETnUfAe98O
				from fV1iMs36rd import k4tn3CNwPDRBoIpzY2gT,gLaEjQd2H6NtxW8DB37YivFTAe
				r2IswzSn0XuejkRHvExDOTBW9C5F = ETnUfAe98O
				AvRadWC9eo2zcfD31Isrq = k4tn3CNwPDRBoIpzY2gT()
				m82pFXUdhw76tyD9 = sF0NOtG4b1RY
				SK50j3yiJ9H2F8Oe,sU4hGzDJQHSaP,rFDufNnUYwzM3WaqH1L0P6,Wk5UqvLps8wZFt9O20fE,XB9df5zvwR4oIiY3q,HHCwMWZuI2j,Hj1bJkegOqZ5VxpUstCz7S84NlQ,d6algfcmBQyuRLx1O,GTAnecCDR7jgLEx = miyYvukojaRTM0gDtbCfK(m82pFXUdhw76tyD9)
				K9KGXEpfHVkMz5yC6DOlaxR0w = SK50j3yiJ9H2F8Oe,sU4hGzDJQHSaP,rFDufNnUYwzM3WaqH1L0P6,Wk5UqvLps8wZFt9O20fE,XB9df5zvwR4oIiY3q,HHCwMWZuI2j,Hj1bJkegOqZ5VxpUstCz7S84NlQ,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࠪ๹"),GTAnecCDR7jgLEx
				for hMQmYWxFLXsdT7U in NNiTvyBp08496qZC3mKeHjP5uGLnFX:
					LGabR8CFqY9VDwNWBlnvg = hMQmYWxFLXsdT7U[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡱࡪࡴࡵࡊࡶࡨࡱࠬ๺")]
					if LGabR8CFqY9VDwNWBlnvg==K9KGXEpfHVkMz5yC6DOlaxR0w or hMQmYWxFLXsdT7U[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡲࡵࡤࡦࠩ๻")] in [S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠶࠻࠻ᔄ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠵࠻࠵ᔃ")]:
						hMQmYWxFLXsdT7U = T8xIzFDE1dGX4tfeS(LGabR8CFqY9VDwNWBlnvg,r2IswzSn0XuejkRHvExDOTBW9C5F,AvRadWC9eo2zcfD31Isrq)
						if hMQmYWxFLXsdT7U[d0HDrq8Rtk16AlInw4TXb(u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ๼")]:
							U1qEtJfkZprl4d = gLaEjQd2H6NtxW8DB37YivFTAe(AvRadWC9eo2zcfD31Isrq,LGabR8CFqY9VDwNWBlnvg,hMQmYWxFLXsdT7U[Jbu2G0Qax8PYWpg(u"࠭࡮ࡦࡹࡳࡥࡹ࡮ࠧ๽")])
							hMQmYWxFLXsdT7U[Jbu2G0Qax8PYWpg(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭๾")] = U1qEtJfkZprl4d+hMQmYWxFLXsdT7U[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ๿")]
					ppyur8heDIZa.append(hMQmYWxFLXsdT7U)
				LCIFdjzi5kVmRwehouHQ.setSetting(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭຀"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࠫກ"))
				if DQs7pSx58I4n==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫຂ"): F4QxJHhsMj(qQ4BC6vW5YOfo,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ຃")+fwVcgrzYhUP3+aSf0iWG1kA7FsqjHbuC8NXB(u"࠭࡟ࠨຄ")+ZZ3eIHOtKyjs,sLHoSMrQmzu5y9EtUIY3O0aJgidk,ppyur8heDIZa,jj0C6IlvPFh)
			else: ppyur8heDIZa = NNiTvyBp08496qZC3mKeHjP5uGLnFX
			if DQs7pSx58I4n==lh6URegmQNq8LWX0HaK5(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ຅") and UMlKSYDNfaR0Z1sbFvPwp!=Y5npATFarf1H9wBjc87(u"ࠨ࠰࠱ࠫຆ") and GdEU6pL40ibF7yQolXHNgMRknB: nkG2ayRoAj53eCPYVc()
			hoMRAuVUeO = hN4mtYQX8rI(sLHoSMrQmzu5y9EtUIY3O0aJgidk,ppyur8heDIZa,sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG)
			return
	elif DQs7pSx58I4n==WWbmNvI40sM9Khlp25Ae(u"ࠩࡩࡳࡱࡪࡥࡳࠩງ") and sF0NOtG4b1RY==d0HDrq8Rtk16AlInw4TXb(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ຈ") and rtgeuo8v3CXnIlHJVNpG6dDhqOY0Q:
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪຉ")+fwVcgrzYhUP3+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡥࠧຊ")+ZZ3eIHOtKyjs,sLHoSMrQmzu5y9EtUIY3O0aJgidk)
	if yboV6YS5n9WtE1arxOed:
		if a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࡟ࠨ຋") in yboV6YS5n9WtE1arxOed: AiBZtChlrkc,hcRydbO5xIwneM4DFK2zosv = yboV6YS5n9WtE1arxOed.split(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡠࠩຌ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠶ᔅ"))
		else: AiBZtChlrkc,hcRydbO5xIwneM4DFK2zosv = yboV6YS5n9WtE1arxOed,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࠩຍ")
		if AiBZtChlrkc in [OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩ࠴ࠫຎ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪ࠶ࠬຏ"),lh6URegmQNq8LWX0HaK5(u"ࠫ࠸࠭ຐ"),hxSBTdGpyNVbfu4tr9(u"ࠬ࠺ࠧຑ"),FZBX5WcC3msIDv4hobLd8(u"࠭࠵ࠨຒ")] and hcRydbO5xIwneM4DFK2zosv:
			from fV1iMs36rd import cbk7C68fFEadM1De3
			cbk7C68fFEadM1De3(yboV6YS5n9WtE1arxOed)
			LCIFdjzi5kVmRwehouHQ.setSetting(MOwK1lpyNfCgqksX3jhV(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫຓ"),StrQOzK40pE8Dbgdj95U)
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(Y5npATFarf1H9wBjc87(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬດ"))
			return
		elif AiBZtChlrkc==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩ࠹ࠫຕ"):
			if hcRydbO5xIwneM4DFK2zosv==NQ4hg16DPUxtOyo5iGb(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬຖ"): NCXj2ri3Unm6TFWIgwh(hxSBTdGpyNVbfu4tr9(u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫທ"),Jbu2G0Qax8PYWpg(u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬຘ"))
			elif hcRydbO5xIwneM4DFK2zosv==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡄࡆࡎࡈࡘࡊ࠭ນ"): JtU3cDMkSF = RS7ZoyGAq1c(u"࠹࠳࠵ᔆ")
			rr60PDpqbMehZsYVuHmiAtN = ZQJPushbmqFz(DQs7pSx58I4n,onHbevfWF7j3EIA,wnpJZgr3dKeoyuQUXsvM60B2T9N8,JtU3cDMkSF,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫບ"))
			return
		elif yboV6YS5n9WtE1arxOed==OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ࠹ࠪປ"):
			from CPxLIa1p4F import A5wDbNlaCi2
			A5wDbNlaCi2()
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ຜ"))
			return
		elif yboV6YS5n9WtE1arxOed==IPkQW7LojF3HO18V(u"ࠪ࠼ࠬຝ"):
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(eaF2N0jWLdvHIs8r(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪພ")+giwrh4jLPc+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡅ࡭ࡰࡦࡨࡁࠬຟ")+str(h9h3xqMnC56kjUOKGgBbWQ4)+hxSBTdGpyNVbfu4tr9(u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭ຠ"))
			return
		elif yboV6YS5n9WtE1arxOed==q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧ࠺ࠩມ"):
			LCIFdjzi5kVmRwehouHQ.setSetting(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬຢ"),LsG7EDcei1gMShH2aVOCo(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬຣ"))
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ຤"))
			return
	if LCIFdjzi5kVmRwehouHQ.getSetting(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪລ")) not in [gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡇࡕࡕࡑࠪ຦"),MOwK1lpyNfCgqksX3jhV(u"࠭ࡓࡕࡑࡓࠫວ"),lh6URegmQNq8LWX0HaK5(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨຨ")]:
		LCIFdjzi5kVmRwehouHQ.setSetting(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧຩ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࡄ࡙࡙ࡕࠧສ"))
	if not LCIFdjzi5kVmRwehouHQ.getSetting(hxSBTdGpyNVbfu4tr9(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪຫ")): LCIFdjzi5kVmRwehouHQ.setSetting(NQ4hg16DPUxtOyo5iGb(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫຬ"),urVJDsPi2IFh[q6yUEoKVDb0fXmc8vhrMk7N(u"࠰ᔇ")])
	PPbdnj7iWzHINTLZrg9XU02mwQ3x = LCIFdjzi5kVmRwehouHQ.getSetting(lh6URegmQNq8LWX0HaK5(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬອ"))
	PPbdnj7iWzHINTLZrg9XU02mwQ3x = eaF2N0jWLdvHIs8r(u"࠱ᔈ") if not PPbdnj7iWzHINTLZrg9XU02mwQ3x else int(PPbdnj7iWzHINTLZrg9XU02mwQ3x)
	if not PPbdnj7iWzHINTLZrg9XU02mwQ3x or B2vCEI9FAVP15R8eUbDJdySc(u"࠲ᔉ")>=CHhSItjbXy-PPbdnj7iWzHINTLZrg9XU02mwQ3x>=jj0C6IlvPFh:
		RBnCc1b5JA = RrCB5k9XV6hYNSlIKJ2.Thread(target=PtoIGCUhApmdzjnSarDK04NWg5Biky)
		RBnCc1b5JA.start()
		LCIFdjzi5kVmRwehouHQ.setSetting(gy9NA3CROZolfEt4vVzMr(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ຮ"),str(CHhSItjbXy))
	MYXjL2ZRk0Eg = LCIFdjzi5kVmRwehouHQ.getSetting(lh6URegmQNq8LWX0HaK5(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫຯ"))
	MYXjL2ZRk0Eg = FZBX5WcC3msIDv4hobLd8(u"࠳ᔊ") if not MYXjL2ZRk0Eg else int(MYXjL2ZRk0Eg)
	if not MYXjL2ZRk0Eg or FZBX5WcC3msIDv4hobLd8(u"࠴ᔋ")>=CHhSItjbXy-MYXjL2ZRk0Eg>=IIbavC96MQ1nHq3Pjx:
		import G4zaNTEvFt
		G4zaNTEvFt.wwnd49zbIZB(Y5npATFarf1H9wBjc87(u"ࡊࡦࡲࡳࡦᜊ"),hxSBTdGpyNVbfu4tr9(u"ࡗࡶࡺ࡫ᜉ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬະ"),str(CHhSItjbXy))
	H0AY1fPDyW = LCIFdjzi5kVmRwehouHQ.getSetting(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧັ"))
	F0d38O9mcHguPtow1r = dX3jmwBTHhEp5UW2MAZ4fzk6(LCIFdjzi5kVmRwehouHQ.getSetting(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫາ")))
	F0d38O9mcHguPtow1r = onweDvmTOUj(u"࠵ᔌ") if not F0d38O9mcHguPtow1r else int(F0d38O9mcHguPtow1r)
	if H0AY1fPDyW in [B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࠬຳ"),onweDvmTOUj(u"ࠬࡋࡒࡓࡑࡕࠫິ")] or not F0d38O9mcHguPtow1r or wKdxVbTc0X9NSiespM8OvHGUhf(u"࠶ᔍ")>=CHhSItjbXy-F0d38O9mcHguPtow1r>=sJF0ga5tzvlRZWK3Xb9:
		wwPFYEbqCt = JoTFl8d72rKjpI0NY6x(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡋࡧ࡬ࡴࡧᜋ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡋࡧ࡬ࡴࡧᜋ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(RS7ZoyGAq1c(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧີ"),QwCLPy3hNTm(CHhSItjbXy))
		if wwPFYEbqCt:
			NCXj2ri3Unm6TFWIgwh(QQSULIva4ljNO73mFcWw(u"ࠧอำหࠤ๊ืษࠡลัี๎࠭ຶ"),FZBX5WcC3msIDv4hobLd8(u"ࠨࡖࡵࡽࠥࡧࡧࡢ࡫ࡱࠫື"),p1BoraOuWL=wKdxVbTc0X9NSiespM8OvHGUhf(u"࠱࠱࠲࠳ᔎ"))
			return
	ppiGeJNUL73KCn5M = dX3jmwBTHhEp5UW2MAZ4fzk6(LCIFdjzi5kVmRwehouHQ.getSetting(gy9NA3CROZolfEt4vVzMr(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶຸࠫ")))
	ppiGeJNUL73KCn5M = eaF2N0jWLdvHIs8r(u"࠱ᔏ") if not ppiGeJNUL73KCn5M else int(ppiGeJNUL73KCn5M)
	ccLSXUHfOtE = dX3jmwBTHhEp5UW2MAZ4fzk6(LCIFdjzi5kVmRwehouHQ.getSetting(WWbmNvI40sM9Khlp25Ae(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷູࠬ")))
	ccLSXUHfOtE = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠲ᔐ") if not ccLSXUHfOtE else int(ccLSXUHfOtE)
	if not ppiGeJNUL73KCn5M or not ccLSXUHfOtE or FZBX5WcC3msIDv4hobLd8(u"࠳ᔑ")>=CHhSItjbXy-ccLSXUHfOtE>=ppiGeJNUL73KCn5M:
		VyebKDrPuvCdFk8L1nIwT65O3 = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠵ᔒ")
		jihFfDZ6UWMIlNqu0bOr3 = LsG7EDcei1gMShH2aVOCo(u"ࡆࡢ࡮ࡶࡩᜍ") if tvwmlYcDnVybgPHKU84GOFI0uAq(Jbu2G0Qax8PYWpg(u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜຺ࠬ")) else d0HDrq8Rtk16AlInw4TXb(u"࡚ࡲࡶࡧᜌ")
		if jihFfDZ6UWMIlNqu0bOr3:
			PPtQZgSW3H7pbKk5lhiV = iFD752WvpSOGkxd6LlR0fZTQUb4CE(mtEXp14ijx(u"ࡕࡴࡸࡩᜎ"))
			if len(PPtQZgSW3H7pbKk5lhiV)>nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠶ᔓ"):
				xrFqGMab4uLKZcS(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡔࡏࡕࡋࡆࡉࠬົ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭࠮ࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩຼ")+StrQOzK40pE8Dbgdj95U+onweDvmTOUj(u"ࠧࠡ࡟ࠪຽ"))
				RGlxXTgCOBAseZ,OjIPm0do31CZ,rT84VWkePRZBIUab2oQn,j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP,rreason = PPtQZgSW3H7pbKk5lhiV[RS7ZoyGAq1c(u"࠶ᔔ")]
				GYMFoOBcHCEpfJ0j,E5EzWlp7eDOALB8r1jyFQiw = j2jpfQzAmwUo6G.split(FZBX5WcC3msIDv4hobLd8(u"ࠨ࡞ࡱ࠿ࡀ࠭຾"))
				del PPtQZgSW3H7pbKk5lhiV[NQ4hg16DPUxtOyo5iGb(u"࠰ᔕ")]
				B3BbTIZ0vq1 = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(PPtQZgSW3H7pbKk5lhiV,gy9NA3CROZolfEt4vVzMr(u"࠲ᔖ"))
				RGlxXTgCOBAseZ,OjIPm0do31CZ,rT84VWkePRZBIUab2oQn,j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP,rreason = B3BbTIZ0vq1[lh6URegmQNq8LWX0HaK5(u"࠲ᔗ")]
				rT84VWkePRZBIUab2oQn = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠾ࠥ࠭຿")+RGlxXTgCOBAseZ+WWbmNvI40sM9Khlp25Ae(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬເ")+rT84VWkePRZBIUab2oQn
				ctQaYd8BKeVT4qLHxNRkjUIgP = LsG7EDcei1gMShH2aVOCo(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪແ")
				FxHYTeJn0BCc6m3R9WZaGXAzQL = onweDvmTOUj(u"ࠬอไหสิ฽ฬะࠧໂ")
				button0,button1 = j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP
				Mcjk2V1hHFmRGrLyiCNZSu = [button0,button1,FxHYTeJn0BCc6m3R9WZaGXAzQL]
				OApuwiJSCbKtWaq1 = onweDvmTOUj(u"࠴ᔘ") if tvwmlYcDnVybgPHKU84GOFI0uAq(onweDvmTOUj(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧໃ")) else nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵࠵ᔙ")
				DDZR5PlzeiyonWaCGfv67uqj2btEN = -Rz34c0NP5BGo1WuTZxSfOKj(u"࠾ᔚ")
				while DDZR5PlzeiyonWaCGfv67uqj2btEN<a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠶ᔛ"):
					W2KUbAq396P7VSyEsB = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(Mcjk2V1hHFmRGrLyiCNZSu,gy9NA3CROZolfEt4vVzMr(u"࠳ᔜ"))
					DDZR5PlzeiyonWaCGfv67uqj2btEN = bxBWM9d53zOAcar(QQSULIva4ljNO73mFcWw(u"ࠧࠨໄ"),W2KUbAq396P7VSyEsB[eaF2N0jWLdvHIs8r(u"࠲ᔞ")],W2KUbAq396P7VSyEsB[gy9NA3CROZolfEt4vVzMr(u"࠲ᔝ")],W2KUbAq396P7VSyEsB[mtEXp14ijx(u"࠵ᔟ")],GYMFoOBcHCEpfJ0j,rT84VWkePRZBIUab2oQn,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ໅"),OApuwiJSCbKtWaq1,Rz34c0NP5BGo1WuTZxSfOKj(u"࠺࠵ᔠ"))
					if DDZR5PlzeiyonWaCGfv67uqj2btEN==onweDvmTOUj(u"࠶࠶ᔡ"): break
					from G4zaNTEvFt import bbP5YM4p3QCHhi6,XfdG8SZ1laKkut
					if DDZR5PlzeiyonWaCGfv67uqj2btEN>=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠰ᔣ") and W2KUbAq396P7VSyEsB[DDZR5PlzeiyonWaCGfv67uqj2btEN]==Mcjk2V1hHFmRGrLyiCNZSu[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠷ᔢ")]:
						bbP5YM4p3QCHhi6()
						if DDZR5PlzeiyonWaCGfv67uqj2btEN>=Q2ZyGqCNYsftTc4MR7n(u"࠲ᔥ"): DDZR5PlzeiyonWaCGfv67uqj2btEN = -gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠺ᔤ")
					elif DDZR5PlzeiyonWaCGfv67uqj2btEN>=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠳ᔦ") and W2KUbAq396P7VSyEsB[DDZR5PlzeiyonWaCGfv67uqj2btEN]==Mcjk2V1hHFmRGrLyiCNZSu[WWbmNvI40sM9Khlp25Ae(u"࠶ᔧ")]:
						XfdG8SZ1laKkut(FZBX5WcC3msIDv4hobLd8(u"ࡈࡤࡰࡸ࡫ᜏ"))
					if DDZR5PlzeiyonWaCGfv67uqj2btEN==-gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶ᔨ"): ztgqWUaDpe8CE9N(Jbu2G0Qax8PYWpg(u"ࠩࠪໆ"),WWbmNvI40sM9Khlp25Ae(u"ࠪࠫ໇"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า່ࠧ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ฯำ๋ะࠥิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯ້ࠧ"))
				VyebKDrPuvCdFk8L1nIwT65O3 = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠷ᔩ")
			else: VyebKDrPuvCdFk8L1nIwT65O3 = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠰ᔪ")
		F4QxJHhsMj(qQ4BC6vW5YOfo,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎ໊ࠩ"),lh6URegmQNq8LWX0HaK5(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗ໋ࠬ"),VyebKDrPuvCdFk8L1nIwT65O3,bY2n5MtVA4cjpkFSxZ6K)
	rr60PDpqbMehZsYVuHmiAtN = ZQJPushbmqFz(DQs7pSx58I4n,onHbevfWF7j3EIA,wnpJZgr3dKeoyuQUXsvM60B2T9N8,h9h3xqMnC56kjUOKGgBbWQ4,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
	if hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ໌") in FbewQr7IVXqN0ijhOtm2vAnauzZT: yTeWrgfPFSVGEHu3 = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡗࡶࡺ࡫ᜐ")
	if DQs7pSx58I4n==RS7ZoyGAq1c(u"ࠩࡩࡳࡱࡪࡥࡳࠩໍ"):
		if UMlKSYDNfaR0Z1sbFvPwp!=RS7ZoyGAq1c(u"ࠪ࠲࠳࠭໎") and GdEU6pL40ibF7yQolXHNgMRknB: nkG2ayRoAj53eCPYVc()
		if yR8fePHkvJnx3K0FQVs>-S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠲ᔫ"):
			if (yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫ࡮ࡴࡴࠨ໏"),LsG7EDcei1gMShH2aVOCo(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ໐"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ໑")) or JtU3cDMkSF not in MZQCVwjDvFN) and not tvwmlYcDnVybgPHKU84GOFI0uAq(Q2ZyGqCNYsftTc4MR7n(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ໒")):
				from WrbQPqX0ZI import ETnUfAe98O
				NNiTvyBp08496qZC3mKeHjP5uGLnFX = Zv2Sq7k0Bl(ETnUfAe98O)
				hoMRAuVUeO = hN4mtYQX8rI(sLHoSMrQmzu5y9EtUIY3O0aJgidk,NNiTvyBp08496qZC3mKeHjP5uGLnFX,sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG)
				if OnvTrikzfEsY7qU8pgaRBtZy(u"࠳ᔬ") and NNiTvyBp08496qZC3mKeHjP5uGLnFX and u5pvoJr1lz:
					F4QxJHhsMj(qQ4BC6vW5YOfo,Sj1PYDmIpCUXO26(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ໓")+fwVcgrzYhUP3+B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡢࠫ໔")+ZZ3eIHOtKyjs,sLHoSMrQmzu5y9EtUIY3O0aJgidk,NNiTvyBp08496qZC3mKeHjP5uGLnFX,jj0C6IlvPFh)
			else:
				YRyCdPm9JnNZ5vf.addDirectoryItem(yR8fePHkvJnx3K0FQVs,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭໕")+giwrh4jLPc+Q2ZyGqCNYsftTc4MR7n(u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ໖"),N7zpvB3VIPrwcSDEC.ListItem(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫ໗")))
				YRyCdPm9JnNZ5vf.addDirectoryItem(yR8fePHkvJnx3K0FQVs,FZBX5WcC3msIDv4hobLd8(u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ໘")+giwrh4jLPc+Q2ZyGqCNYsftTc4MR7n(u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ໙"),N7zpvB3VIPrwcSDEC.ListItem(lh6URegmQNq8LWX0HaK5(u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ໚")))
			YRyCdPm9JnNZ5vf.endOfDirectory(yR8fePHkvJnx3K0FQVs,sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG)
	return
def ZQJPushbmqFz(DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk):
	JtU3cDMkSF = int(h9h3xqMnC56kjUOKGgBbWQ4)
	deBF2JXw4DVnTl = int(JtU3cDMkSF//gy9NA3CROZolfEt4vVzMr(u"࠴࠴ᔭ"))
	if   deBF2JXw4DVnTl==Jbu2G0Qax8PYWpg(u"࠴ᔮ"):  from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠶ᔯ"):  from cBd1reQDjq 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hxSBTdGpyNVbfu4tr9(u"࠸ᔰ"):  from pQglzMi9ZS 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==FZBX5WcC3msIDv4hobLd8(u"࠳ᔱ"):  from cq8QVrWXTm 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Q2ZyGqCNYsftTc4MR7n(u"࠵ᔲ"):  from MTGUFwWLXY 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,SSGEc76fBan2)
	elif deBF2JXw4DVnTl==MOwK1lpyNfCgqksX3jhV(u"࠷ᔳ"):  from QOoVeYIPrS 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠹ᔴ"):  from acKn9I1HBV 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠻ᔵ"):  from xuBOFde24X 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==aSf0iWG1kA7FsqjHbuC8NXB(u"࠽ᔶ"):  from TqzA2cb9Fh 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠿ᔷ"):  from B6jExwRWqP		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠱࠱ᔸ"): from vpgnkoN7IH 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	elif deBF2JXw4DVnTl==IPkQW7LojF3HO18V(u"࠲࠳ᔹ"): from g3fxlLcTwp 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Sj1PYDmIpCUXO26(u"࠳࠵ᔺ"): from rrwJN21upY 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==eaF2N0jWLdvHIs8r(u"࠴࠷ᔻ"): from YMZBptbgfC		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Y5npATFarf1H9wBjc87(u"࠵࠹ᔼ"): from tHSNcldqrQ 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2,x0LXdHBFwj7EtMfu,NmX0ZP715phHsSiCzvxR3IB)
	elif deBF2JXw4DVnTl==FZBX5WcC3msIDv4hobLd8(u"࠶࠻ᔽ"): from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==OnvTrikzfEsY7qU8pgaRBtZy(u"࠷࠶ᔾ"): from yg5CFvk7xd		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==IPkQW7LojF3HO18V(u"࠱࠸ᔿ"): from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==WWbmNvI40sM9Khlp25Ae(u"࠲࠺ᕀ"): from lsh9fuQS5H		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠳࠼ᕁ"): from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵࠴ᕂ"): from YRUMjINH0s		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==MOwK1lpyNfCgqksX3jhV(u"࠶࠶ᕃ"): from BmKp37VSQA	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠷࠸ᕄ"): from S6iI8r9vWM		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Y5npATFarf1H9wBjc87(u"࠸࠳ᕅ"): from xTnWLMwOlD	import PLhWMCuV7DtB	; rr60PDpqbMehZsYVuHmiAtN = PLhWMCuV7DtB(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠲࠵ᕆ"): from vfhp39d4er 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==OnvTrikzfEsY7qU8pgaRBtZy(u"࠳࠷ᕇ"): from HBmivPUk2O 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠴࠹ᕈ"): from WrbQPqX0ZI 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠵࠻ᕉ"): from fV1iMs36rd	import PLhWMCuV7DtB	; rr60PDpqbMehZsYVuHmiAtN = PLhWMCuV7DtB(JtU3cDMkSF,yboV6YS5n9WtE1arxOed)
	elif deBF2JXw4DVnTl==aSf0iWG1kA7FsqjHbuC8NXB(u"࠶࠽ᕊ"): from xTnWLMwOlD	import PLhWMCuV7DtB	; rr60PDpqbMehZsYVuHmiAtN = PLhWMCuV7DtB(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==Q2ZyGqCNYsftTc4MR7n(u"࠷࠿ᕋ"): from DJpT2hU7ml	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Sj1PYDmIpCUXO26(u"࠹࠰ᕌ"): from QkSEbr6RM7		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠳࠲ᕍ"): from l19akWUDfA		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Y5npATFarf1H9wBjc87(u"࠴࠴ᕎ"): from gSKh6MiQ8e		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵࠶ᕏ"): from TVMrfO0tCI		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	elif deBF2JXw4DVnTl==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠶࠸ᕐ"): from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==FZBX5WcC3msIDv4hobLd8(u"࠷࠺ᕑ"): from ChqefOL4Mn		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==NQ4hg16DPUxtOyo5iGb(u"࠸࠼ᕒ"): from oFz1gSBjXr			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==IPkQW7LojF3HO18V(u"࠹࠷ᕓ"): from dWvezyn71D			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==RS7ZoyGAq1c(u"࠳࠹ᕔ"): from rJCbLy7F40 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==WWbmNvI40sM9Khlp25Ae(u"࠴࠻ᕕ"): from g4OzlXIh9V		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==d0HDrq8Rtk16AlInw4TXb(u"࠶࠳ᕖ"): from Y3jywo7Lua	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2)
	elif deBF2JXw4DVnTl==gy9NA3CROZolfEt4vVzMr(u"࠷࠵ᕗ"): from Y3jywo7Lua	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2)
	elif deBF2JXw4DVnTl==Sj1PYDmIpCUXO26(u"࠸࠷ᕘ"): from yFBWmcKp2k			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hxSBTdGpyNVbfu4tr9(u"࠹࠹ᕙ"): from K5ZxXC167D			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hxSBTdGpyNVbfu4tr9(u"࠺࠴ᕚ"): from y6de8biYgq		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠴࠶ᕛ"): from OTbwzXCtuY		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==d0HDrq8Rtk16AlInw4TXb(u"࠵࠸ᕜ"): from z18cJRCTX5			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠶࠺ᕝ"): from M9lTLt28So		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠷࠼ᕞ"): from ZynRajS6D2		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Sj1PYDmIpCUXO26(u"࠸࠾ᕟ"): from wHGJb31Nsn		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠺࠶ᕠ"): from G4zaNTEvFt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==IPkQW7LojF3HO18V(u"࠻࠱ᕡ"): from kkuqFPDoO7 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠵࠳ᕢ"): from kkuqFPDoO7 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==mtEXp14ijx(u"࠶࠵ᕣ"): from WrbQPqX0ZI 			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==FZBX5WcC3msIDv4hobLd8(u"࠷࠷ᕤ"): from CPxLIa1p4F	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,SSGEc76fBan2)
	elif deBF2JXw4DVnTl==B2vCEI9FAVP15R8eUbDJdySc(u"࠸࠹ᕥ"): from F4ZG65u8Dt 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠹࠻ᕦ"): from VxXWc4O2be			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠺࠽ᕧ"): from Jp96cr4yVB		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==d0HDrq8Rtk16AlInw4TXb(u"࠻࠸ᕨ"): from aNEKUJgbPs		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==onweDvmTOUj(u"࠵࠺ᕩ"): from Air8LD14X5		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==LsG7EDcei1gMShH2aVOCo(u"࠷࠲ᕪ"): from v3umM87oYB			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==B2vCEI9FAVP15R8eUbDJdySc(u"࠸࠴ᕫ"): from j7ZLMSmv4w			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠹࠶ᕬ"): from GHFRBa9spT		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠺࠸ᕭ"): from adxJKPkW7Y	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==LsG7EDcei1gMShH2aVOCo(u"࠻࠺ᕮ"): from FeDQWiYyqn			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==IPkQW7LojF3HO18V(u"࠼࠵ᕯ"): from EESoF8cn9d			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==eaF2N0jWLdvHIs8r(u"࠶࠷ᕰ"): from JM0lSHOxe7			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==eaF2N0jWLdvHIs8r(u"࠷࠹ᕱ"): from HDkQ23TwVc		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==LsG7EDcei1gMShH2aVOCo(u"࠸࠻ᕲ"): from vB7hFr6qwH		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==mtEXp14ijx(u"࠹࠽ᕳ"): from vOpxrUYFyG		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==hxSBTdGpyNVbfu4tr9(u"࠻࠵ᕴ"): from B3GZSdnP6q			import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠼࠷ᕵ"): from oI5xiFN7h4	import PLhWMCuV7DtB	; rr60PDpqbMehZsYVuHmiAtN = PLhWMCuV7DtB(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==QQSULIva4ljNO73mFcWw(u"࠽࠲ᕶ"): from oI5xiFN7h4	import PLhWMCuV7DtB	; rr60PDpqbMehZsYVuHmiAtN = PLhWMCuV7DtB(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,DQs7pSx58I4n,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==RS7ZoyGAq1c(u"࠷࠴ᕷ"): from LEtrckHMKz	import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==LsG7EDcei1gMShH2aVOCo(u"࠸࠶ᕸ"): from owspWiVG2n		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF)
	elif deBF2JXw4DVnTl==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠹࠸ᕹ"): from owspWiVG2n		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF)
	elif deBF2JXw4DVnTl==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠺࠺ᕺ"): from yg5CFvk7xd		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk)
	elif deBF2JXw4DVnTl==NQ4hg16DPUxtOyo5iGb(u"࠻࠼ᕻ"): from NT4RbrmaI5 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Rz34c0NP5BGo1WuTZxSfOKj(u"࠼࠾ᕼ"): from E3jtTkvHVn 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==q6yUEoKVDb0fXmc8vhrMk7N(u"࠽࠹ᕽ"): from DDwJuxKcqi 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==RS7ZoyGAq1c(u"࠸࠱ᕾ"): from xNDBjfpOeh 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==Y5npATFarf1H9wBjc87(u"࠹࠳ᕿ"): from ZEmdj2N85z 		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	elif deBF2JXw4DVnTl==OnvTrikzfEsY7qU8pgaRBtZy(u"࠺࠵ᖀ"): from XnEphROtxM		import GI13aCFr0qimdOT	; rr60PDpqbMehZsYVuHmiAtN = GI13aCFr0qimdOT(JtU3cDMkSF,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT)
	else: rr60PDpqbMehZsYVuHmiAtN = None
	return rr60PDpqbMehZsYVuHmiAtN
def UiZhKQ6o7YwAOWmd8jXxNy(E9eFvJPDwq,rreason,ucGVEfRSBY,showDialogs):
	Ir3WTjlbGkicSQ = LCIFdjzi5kVmRwehouHQ.getSetting(QQSULIva4ljNO73mFcWw(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ໛"))
	LCIFdjzi5kVmRwehouHQ.setSetting(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫໜ"),LsG7EDcei1gMShH2aVOCo(u"ࠫࠬໝ"))
	if aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠳ࠧໞ") in ucGVEfRSBY: yPRGDCnXhJbwYalz7fZepiUcA = ucGVEfRSBY.split(Jbu2G0Qax8PYWpg(u"࠭࠭ࠨໟ"),Q2ZyGqCNYsftTc4MR7n(u"࠴ᖁ"))[Sj1PYDmIpCUXO26(u"࠴ᖂ")]
	else: yPRGDCnXhJbwYalz7fZepiUcA = ucGVEfRSBY
	H5g3aMit8Gx2n = E9eFvJPDwq in [Sj1PYDmIpCUXO26(u"࠸ᖆ"),d0HDrq8Rtk16AlInw4TXb(u"࠷࠱࠱࠲࠴ᖄ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠶࠷࠰࠱࠴ᖃ"),eaF2N0jWLdvHIs8r(u"࠱࠱࠲࠸࠸ᖅ")]
	pwHeyCZNvE4nOlrDV = rreason.lower()
	cm3AJSWYXg5oRyvU = E9eFvJPDwq in [Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠲ᖇ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠶࠶࠴ᖊ"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠴࠴࠵࠼࠱ᖈ"),IPkQW7LojF3HO18V(u"࠵࠶࠷ᖉ")]
	Aob4hlcxPU5DSveNYdwrJ329zI = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ໠") in pwHeyCZNvE4nOlrDV
	BKEjlaLDc81bOpMZi23IUXv9AP = Sj1PYDmIpCUXO26(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ໡") in pwHeyCZNvE4nOlrDV
	yWBPNsKOz8vxuGbck2p = eaF2N0jWLdvHIs8r(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ໢") in pwHeyCZNvE4nOlrDV
	ikeStsbaVfnXCP3jGZ = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ໣") in pwHeyCZNvE4nOlrDV
	AJfxpLw90WU4n5E = LCIFdjzi5kVmRwehouHQ.getSetting(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ໤"))
	c9Bj6ViC0tmHFNKuALp8 = LCIFdjzi5kVmRwehouHQ.getSetting(MOwK1lpyNfCgqksX3jhV(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ໥"))
	xBCQw51AMysiXJeITtfY0vW8bFR = OnvTrikzfEsY7qU8pgaRBtZy(u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ໦")
	j3dJy8xUwrBtomAgaTZ2CqI = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡆࡴࡵࡳࡷࠦࠧ໧")+str(E9eFvJPDwq)+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ࠼ࠣࠫ໨")+rreason
	j3dJy8xUwrBtomAgaTZ2CqI = aDebGvrkdptunqTM8m4(j3dJy8xUwrBtomAgaTZ2CqI)
	if cm3AJSWYXg5oRyvU or Aob4hlcxPU5DSveNYdwrJ329zI or BKEjlaLDc81bOpMZi23IUXv9AP or yWBPNsKOz8vxuGbck2p or ikeStsbaVfnXCP3jGZ:
		xBCQw51AMysiXJeITtfY0vW8bFR += Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ໩")
	if H5g3aMit8Gx2n: xBCQw51AMysiXJeITtfY0vW8bFR += LsG7EDcei1gMShH2aVOCo(u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ໪")
	j3dJy8xUwrBtomAgaTZ2CqI = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ໫")+j3dJy8xUwrBtomAgaTZ2CqI+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ໬")
	if AJfxpLw90WU4n5E==q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡁࡔࡍࠪ໭") or c9Bj6ViC0tmHFNKuALp8==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡂࡕࡎࠫ໮"):
		xBCQw51AMysiXJeITtfY0vW8bFR += Jbu2G0Qax8PYWpg(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ໯")
	f1t8cXIiQTR9pUyzaEdBrYDA5wq = hxSBTdGpyNVbfu4tr9(u"ࡊࡦࡲࡳࡦᜑ")
	if showDialogs and ucGVEfRSBY not in wV1DKnFCZBU236:
		if AJfxpLw90WU4n5E==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡄࡗࡐ࠭໰") or c9Bj6ViC0tmHFNKuALp8==lh6URegmQNq8LWX0HaK5(u"ࠪࡅࡘࡑࠧ໱"):
			DDZR5PlzeiyonWaCGfv67uqj2btEN = bxBWM9d53zOAcar(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ໲"),Sj1PYDmIpCUXO26(u"ࠬิั้ฮࠪ໳"),Jbu2G0Qax8PYWpg(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬ໴"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧฦื็หาࠦวๅ็ื็้ฯࠧ໵"),yPRGDCnXhJbwYalz7fZepiUcA+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠢࠣࠤࠬ໶")+AFuJDPbZhS134etQfj(yPRGDCnXhJbwYalz7fZepiUcA),xBCQw51AMysiXJeITtfY0vW8bFR+mtEXp14ijx(u"ࠩ࡟ࡲࠬ໷")+j3dJy8xUwrBtomAgaTZ2CqI)
			if DDZR5PlzeiyonWaCGfv67uqj2btEN==B2vCEI9FAVP15R8eUbDJdySc(u"࠷ᖋ"):
				from G4zaNTEvFt import bbP5YM4p3QCHhi6
				bbP5YM4p3QCHhi6()
			elif DDZR5PlzeiyonWaCGfv67uqj2btEN==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠲ᖌ"): f1t8cXIiQTR9pUyzaEdBrYDA5wq = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࡙ࡸࡵࡦᜒ")
		else: ztgqWUaDpe8CE9N(B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࠫ໸"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠬ໹"),yPRGDCnXhJbwYalz7fZepiUcA+hxSBTdGpyNVbfu4tr9(u"ࠬࠦࠠࠡࠩ໺")+AFuJDPbZhS134etQfj(yPRGDCnXhJbwYalz7fZepiUcA),xBCQw51AMysiXJeITtfY0vW8bFR,j3dJy8xUwrBtomAgaTZ2CqI)
	LCIFdjzi5kVmRwehouHQ.setSetting(B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ໻"),Ir3WTjlbGkicSQ)
	return f1t8cXIiQTR9pUyzaEdBrYDA5wq
def wh7i1HEySabUpQJ6frj3lVX(KFYmkbU0clvu8hSn=lh6URegmQNq8LWX0HaK5(u"ࡌࡡ࡭ࡵࡨᜓ"),IrTlweb043LMW=[]):
	IIDvduQ1kXghE6NqazGUfO3e = [kRpnCV8cqdhDew2suUxPfaQTA5,YbTWJNjEGPC12RZzHioatgvu]+IrTlweb043LMW
	for khUXCHlV1sPY0gevy in Dh9MOxeTj6FW.listdir(Vd1J5lD9uAsMUoXW):
		if KFYmkbU0clvu8hSn and (khUXCHlV1sPY0gevy.startswith(QQSULIva4ljNO73mFcWw(u"ࠧࡪࡲࡷࡺࠬ໼")) or khUXCHlV1sPY0gevy.startswith(NQ4hg16DPUxtOyo5iGb(u"ࠨ࡯࠶ࡹࠬ໽"))): continue
		if khUXCHlV1sPY0gevy.startswith(mtEXp14ijx(u"ࠩࡩ࡭ࡱ࡫࡟ࠨ໾")): continue
		dGerh60yW25 = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,khUXCHlV1sPY0gevy)
		if dGerh60yW25 in IIDvduQ1kXghE6NqazGUfO3e: continue
		try: Dh9MOxeTj6FW.remove(dGerh60yW25)
		except: pass
	if nnyfJE0MzRWolCuK68rxd not in IIDvduQ1kXghE6NqazGUfO3e: IlTEWy8f4bpjLa7UR0c2qDY6S15Q(nnyfJE0MzRWolCuK68rxd,FZBX5WcC3msIDv4hobLd8(u"ࡕࡴࡸࡩ᜕"),mtEXp14ijx(u"ࡆࡢ࡮ࡶࡩ᜔"))
	p1BoraOuWL.sleep(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠲ᖍ"))
	return
def tKLh9z8MXWPZAQqu3U1dgcjafm(alZAjySu6tgqRh75IP8dHr3U,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,ucGVEfRSBY,GrW7YhVIBTu=QQSULIva4ljNO73mFcWw(u"ࡖࡵࡹࡪ᜖"),Nu5VfTLAMGnKbPD7kJzXWY=QQSULIva4ljNO73mFcWw(u"ࡖࡵࡹࡪ᜖")):
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ໿")+alZAjySu6tgqRh75IP8dHr3U
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,ucGVEfRSBY,GrW7YhVIBTu,Nu5VfTLAMGnKbPD7kJzXWY)
	if xTFHrZ1nGWa9fdqsSA5y4htgJNmX in Plx6mbKYD71aCsfTdukWy2Q.content: Plx6mbKYD71aCsfTdukWy2Q.succeeded = Y5npATFarf1H9wBjc87(u"ࡉࡥࡱࡹࡥ᜗")
	if not Plx6mbKYD71aCsfTdukWy2Q.succeeded:
		YosJW4Tklp2IyQ0jPnam(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡍ࡚ࡔࡑࠢࡕࡩࡶࡻࡥࡴࡶࠣࡊࡦ࡯࡬ࡶࡴࡨࠫༀ"))
	return Plx6mbKYD71aCsfTdukWy2Q
def IjagJyLBMVsUfZlAcm(xTFHrZ1nGWa9fdqsSA5y4htgJNmX):
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,mtEXp14ijx(u"ࠬࡍࡅࡕࠩ༁"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࠧ༂"),MOwK1lpyNfCgqksX3jhV(u"ࠧࠨ༃"),LsG7EDcei1gMShH2aVOCo(u"࡙ࡸࡵࡦ᜙"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠩ༄"),eaF2N0jWLdvHIs8r(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ༅"),LsG7EDcei1gMShH2aVOCo(u"࡙ࡸࡵࡦ᜙"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡊࡦࡲࡳࡦ᜘"))
	cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X = []
	if Plx6mbKYD71aCsfTdukWy2Q.succeeded:
		mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
		TVvLWC6d8qiExnX53SgojMcADuK = SomeI8i56FaDMGPE.findall(lh6URegmQNq8LWX0HaK5(u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭༆"),mmhS2KFYI4eC6HWgk1trq)
		if TVvLWC6d8qiExnX53SgojMcADuK: mmhS2KFYI4eC6HWgk1trq = WWbmNvI40sM9Khlp25Ae(u"ࠫࡡࡴࠧ༇").join(TVvLWC6d8qiExnX53SgojMcADuK)
		M2AyUhuxgbs0SaG97woLzr = mmhS2KFYI4eC6HWgk1trq.replace(LsG7EDcei1gMShH2aVOCo(u"ࠬࡢࡲࠨ༈"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࠧ༉")).strip(mtEXp14ijx(u"ࠧ࡝ࡰࠪ༊")).split(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࡞ࡱࠫ་"))
		cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X = []
		for alZAjySu6tgqRh75IP8dHr3U in M2AyUhuxgbs0SaG97woLzr:
			if alZAjySu6tgqRh75IP8dHr3U.count(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩ࠱ࠫ༌"))==aSf0iWG1kA7FsqjHbuC8NXB(u"࠵ᖎ"): cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X.append(alZAjySu6tgqRh75IP8dHr3U)
	return cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X
def LkG0l1oXUZ3(*aargs):
	z5KGgv6RlhFSDEANyHQ2kLfMIp7bin = gy9NA3CROZolfEt4vVzMr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ།")
	YHlL5p6T2REFCbkeBPhI1rw4Uc = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨ༎")
	VVumzJfjSNQ4kIU9PWZw = IjagJyLBMVsUfZlAcm(YHlL5p6T2REFCbkeBPhI1rw4Uc)
	cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X = IjagJyLBMVsUfZlAcm(z5KGgv6RlhFSDEANyHQ2kLfMIp7bin)
	ipIBhXCeYEu = VVumzJfjSNQ4kIU9PWZw+cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X
	xrFqGMab4uLKZcS(QQSULIva4ljNO73mFcWw(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ༏"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬ༐")+str(len(VVumzJfjSNQ4kIU9PWZw))+MOwK1lpyNfCgqksX3jhV(u"ࠧࠬࠩ༑")+str(len(cK2wDW0x1mzMOVdChNsGvjaLBYkJ4X))+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠢࡠࠫ༒"))
	alZAjySu6tgqRh75IP8dHr3U = LCIFdjzi5kVmRwehouHQ.getSetting(hxSBTdGpyNVbfu4tr9(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ༓"))
	Plx6mbKYD71aCsfTdukWy2Q = KKTc4gCGlPOW2F36ibxUd8NVDHB()
	LCIFdjzi5kVmRwehouHQ.setSetting(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ༔"),MOwK1lpyNfCgqksX3jhV(u"ࠫࠬ༕"))
	if alZAjySu6tgqRh75IP8dHr3U or ipIBhXCeYEu:
		RGlxXTgCOBAseZ,Egi7k41QIqDK6NouH = LsG7EDcei1gMShH2aVOCo(u"࠳ᖏ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠵࠵ᖐ")
		CAyWtjw9FsqDa806XG = len(ipIBhXCeYEu)
		YQ2ts87RVKI06M = Egi7k41QIqDK6NouH
		if CAyWtjw9FsqDa806XG>YQ2ts87RVKI06M: i61iovH5zU8F0JOCcXKxlkLPdfYQbt = YQ2ts87RVKI06M
		else: i61iovH5zU8F0JOCcXKxlkLPdfYQbt = CAyWtjw9FsqDa806XG
		b2ZifEuU7zpVr = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(ipIBhXCeYEu,i61iovH5zU8F0JOCcXKxlkLPdfYQbt)
		if alZAjySu6tgqRh75IP8dHr3U: b2ZifEuU7zpVr = [alZAjySu6tgqRh75IP8dHr3U]+b2ZifEuU7zpVr
		xxWtDTOcs5whlMn = jIoHl6d5pfVXu(q6yUEoKVDb0fXmc8vhrMk7N(u"ࡌࡡ࡭ࡵࡨ᜚"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࡌࡡ࡭ࡵࡨ᜚"))
		mlKGZXF5ybUTOrQNMua = p1BoraOuWL.time()
		while p1BoraOuWL.time()-mlKGZXF5ybUTOrQNMua<=Egi7k41QIqDK6NouH and not xxWtDTOcs5whlMn.finishedLIST:
			if RGlxXTgCOBAseZ<i61iovH5zU8F0JOCcXKxlkLPdfYQbt:
				alZAjySu6tgqRh75IP8dHr3U = b2ZifEuU7zpVr[RGlxXTgCOBAseZ]
				xxWtDTOcs5whlMn.FghEzWo26wCTxOYmsAQPl9d(RGlxXTgCOBAseZ,tKLh9z8MXWPZAQqu3U1dgcjafm,alZAjySu6tgqRh75IP8dHr3U,*aargs)
			p1BoraOuWL.sleep(q6yUEoKVDb0fXmc8vhrMk7N(u"࠶ᖑ"))
			RGlxXTgCOBAseZ += Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠷ᖒ")
			xrFqGMab4uLKZcS(Q2ZyGqCNYsftTc4MR7n(u"ࠬࡔࡏࡕࡋࡆࡉࠬ༖"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+mtEXp14ijx(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ༗")+alZAjySu6tgqRh75IP8dHr3U+eaF2N0jWLdvHIs8r(u"ࠧࠡ࡟༘ࠪ"))
		finishedLIST = xxWtDTOcs5whlMn.finishedLIST
		if finishedLIST:
			resultsDICT = xxWtDTOcs5whlMn.resultsDICT
			RRyj4cDHqQMrmKS0ExoL7XhpFl = finishedLIST[lh6URegmQNq8LWX0HaK5(u"࠰ᖓ")]
			Plx6mbKYD71aCsfTdukWy2Q = resultsDICT[RRyj4cDHqQMrmKS0ExoL7XhpFl]
			alZAjySu6tgqRh75IP8dHr3U = b2ZifEuU7zpVr[int(RRyj4cDHqQMrmKS0ExoL7XhpFl)]
			LCIFdjzi5kVmRwehouHQ.setSetting(LsG7EDcei1gMShH2aVOCo(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༙"),alZAjySu6tgqRh75IP8dHr3U)
			if RRyj4cDHqQMrmKS0ExoL7XhpFl!=eaF2N0jWLdvHIs8r(u"࠱ᖔ"): xrFqGMab4uLKZcS(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ༚"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༛")+alZAjySu6tgqRh75IP8dHr3U+onweDvmTOUj(u"ࠫࠥࡣࠧ༜"))
			else: xrFqGMab4uLKZcS(d0HDrq8Rtk16AlInw4TXb(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ༝"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+gy9NA3CROZolfEt4vVzMr(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ༞")+alZAjySu6tgqRh75IP8dHr3U+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠡ࡟ࠪ༟"))
	return Plx6mbKYD71aCsfTdukWy2Q
def OGfB3t4IJrUxl7u9oEeiD5jPWbKAR(bmSxrBYNkDKupeo4EvI9FgWh,CmiVNjBLoJd2A8pgPkHvnZrX5D):
	tC7UeGlBpgF4adEh = bmSxrBYNkDKupeo4EvI9FgWh.create_connection
	def J9XLjzceMsC(BB4EpAYsW10vedRrgD,*aargs,**kkwargs):
		XXfrWZnRsmx47VOwcLe,K5MukmIpEfvJV9jLTgB = BB4EpAYsW10vedRrgD
		ip = XxmdGKqvtUIgCbP34ahMfoJrR2W8ZQ(XXfrWZnRsmx47VOwcLe,CmiVNjBLoJd2A8pgPkHvnZrX5D)
		if ip: XXfrWZnRsmx47VOwcLe = ip[FZBX5WcC3msIDv4hobLd8(u"࠲ᖕ")]
		else:
			if CmiVNjBLoJd2A8pgPkHvnZrX5D in urVJDsPi2IFh: urVJDsPi2IFh.remove(CmiVNjBLoJd2A8pgPkHvnZrX5D)
			if urVJDsPi2IFh:
				drUE9MPj3NogG4tkFWlfI = urVJDsPi2IFh[q6yUEoKVDb0fXmc8vhrMk7N(u"࠳ᖖ")]
				ip = XxmdGKqvtUIgCbP34ahMfoJrR2W8ZQ(XXfrWZnRsmx47VOwcLe,drUE9MPj3NogG4tkFWlfI)
				if ip: XXfrWZnRsmx47VOwcLe = ip[MOwK1lpyNfCgqksX3jhV(u"࠴ᖗ")]
		BB4EpAYsW10vedRrgD = (XXfrWZnRsmx47VOwcLe,K5MukmIpEfvJV9jLTgB)
		return tC7UeGlBpgF4adEh(BB4EpAYsW10vedRrgD,*aargs,**kkwargs)
	bmSxrBYNkDKupeo4EvI9FgWh.create_connection = J9XLjzceMsC
	return tC7UeGlBpgF4adEh
def Eze5AqaSRHbwV3(xTFHrZ1nGWa9fdqsSA5y4htgJNmX):
	b6ijsy9F7VLY,SZwJY96t0mFlbHCT5h42VqBej = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.split(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࠱ࠪ༠"))[hxSBTdGpyNVbfu4tr9(u"࠸ᖙ")],Rz34c0NP5BGo1WuTZxSfOKj(u"࠽࠶ᖘ")
	if NQ4hg16DPUxtOyo5iGb(u"ࠩ࠽ࠫ༡") in b6ijsy9F7VLY: b6ijsy9F7VLY,SZwJY96t0mFlbHCT5h42VqBej = b6ijsy9F7VLY.split(B2vCEI9FAVP15R8eUbDJdySc(u"ࠪ࠾ࠬ༢"))
	gM4dUcT1yWa7pbxLlst = aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫ࠴࠭༣")+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬ࠵ࠧ༤").join(xTFHrZ1nGWa9fdqsSA5y4htgJNmX.split(IPkQW7LojF3HO18V(u"࠭࠯ࠨ༥"))[Jbu2G0Qax8PYWpg(u"࠳ᖚ"):])
	ZuCJj5EwDPROkb7UXNypofl = Jbu2G0Qax8PYWpg(u"ࠧࡈࡇࡗࠤࠬ༦")+gM4dUcT1yWa7pbxLlst+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ༧")
	ZuCJj5EwDPROkb7UXNypofl += hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ༨")+b6ijsy9F7VLY+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡠࡷࡢ࡮ࠨ༩")
	ZuCJj5EwDPROkb7UXNypofl += OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡡࡸ࡜࡯ࠩ༪")
	from socket import socket as g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS,AF_INET as A63OvTSBM5xduK4m8yorhjPYqw,SOCK_STREAM as Zm7N6Rv39POxEg8jQnpoKHzlD12G
	try:
		IqErwi6HaSAOGRbxcLsB = g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS(A63OvTSBM5xduK4m8yorhjPYqw,Zm7N6Rv39POxEg8jQnpoKHzlD12G)
		IqErwi6HaSAOGRbxcLsB.connect((b6ijsy9F7VLY,SZwJY96t0mFlbHCT5h42VqBej))
		IqErwi6HaSAOGRbxcLsB.send(ZuCJj5EwDPROkb7UXNypofl.encode(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡻࡴࡧ࠺ࠪ༫")))
		nPLkFgsBpbv1hU6XMcDV = IqErwi6HaSAOGRbxcLsB.recv(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠶࠳࠽࠻ᖜ")*Q2ZyGqCNYsftTc4MR7n(u"࠲࠲࠵࠸ᖛ"))
		mmhS2KFYI4eC6HWgk1trq = repr(nPLkFgsBpbv1hU6XMcDV)
	except: mmhS2KFYI4eC6HWgk1trq = hxSBTdGpyNVbfu4tr9(u"࠭ࠧ༬")
	return mmhS2KFYI4eC6HWgk1trq
def DRom9hFTZXKuvfr2(sDCfutRY03p6ZNclVLJqIrQ,DQs7pSx58I4n):
	if hxSBTdGpyNVbfu4tr9(u"ࠧ࠯ࠩ༭") not in sDCfutRY03p6ZNclVLJqIrQ: return sDCfutRY03p6ZNclVLJqIrQ
	sDCfutRY03p6ZNclVLJqIrQ = sDCfutRY03p6ZNclVLJqIrQ+lh6URegmQNq8LWX0HaK5(u"ࠨ࠱ࠪ༮")
	PkOFSBRydAMtrpjE4NwahnY,kZuYqmvFAh1JWT8ozf6 = sDCfutRY03p6ZNclVLJqIrQ.split(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩ࠱ࠫ༯"),d0HDrq8Rtk16AlInw4TXb(u"࠴ᖝ"))
	IgSDB5rkhuVdMeFn4sEU,XtKfMboNyl3CsWagrBT2UD059wSkp = kZuYqmvFAh1JWT8ozf6.split(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪ࠳ࠬ༰"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵ᖞ"))
	WrlVQE8dsBzZ = PkOFSBRydAMtrpjE4NwahnY+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫ࠳࠭༱")+IgSDB5rkhuVdMeFn4sEU
	if DQs7pSx58I4n in [QQSULIva4ljNO73mFcWw(u"ࠬ࡮࡯ࡴࡶࠪ༲"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭࡮ࡢ࡯ࡨࠫ༳")] and RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧ࠰ࠩ༴") in WrlVQE8dsBzZ: WrlVQE8dsBzZ = WrlVQE8dsBzZ.rsplit(WWbmNvI40sM9Khlp25Ae(u"ࠨ࠱༵ࠪ"),FZBX5WcC3msIDv4hobLd8(u"࠶ᖟ"))[FZBX5WcC3msIDv4hobLd8(u"࠶ᖟ")]
	if DQs7pSx58I4n==gy9NA3CROZolfEt4vVzMr(u"ࠩࡱࡥࡲ࡫ࠧ༶") and a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪ࠲༷ࠬ") in WrlVQE8dsBzZ:
		zE5Pi19p6ywMJmsIC3NRl0gknQ = WrlVQE8dsBzZ.split(FZBX5WcC3msIDv4hobLd8(u"ࠫ࠳࠭༸"))
		wwbWlQeZCfk9tG = len(zE5Pi19p6ywMJmsIC3NRl0gknQ)
		if wwbWlQeZCfk9tG<=mtEXp14ijx(u"࠲ᖡ") or wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ༹ࠪ") in WrlVQE8dsBzZ: zE5Pi19p6ywMJmsIC3NRl0gknQ = zE5Pi19p6ywMJmsIC3NRl0gknQ[WWbmNvI40sM9Khlp25Ae(u"࠶ᖠ")]
		elif wwbWlQeZCfk9tG>=a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠵ᖣ"): zE5Pi19p6ywMJmsIC3NRl0gknQ = zE5Pi19p6ywMJmsIC3NRl0gknQ[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠲ᖢ")]
		if len(zE5Pi19p6ywMJmsIC3NRl0gknQ)>NQ4hg16DPUxtOyo5iGb(u"࠴ᖤ"): WrlVQE8dsBzZ = zE5Pi19p6ywMJmsIC3NRl0gknQ
	return WrlVQE8dsBzZ
def MMjrDyLdKhUb7V(tRaw8ODgnKvMlAx):
	oo1q2JEvCGnR4ZQ6aNVPHhItiAz = repr(tRaw8ODgnKvMlAx.encode(B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡵࡵࡨ࠻ࠫ༺"))).replace(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠢࠨࠤ༻"),QQSULIva4ljNO73mFcWw(u"ࠨࠩ༼"))
	return oo1q2JEvCGnR4ZQ6aNVPHhItiAz
def s8sONHML19B5oh(AYpOWlLEaM1bVP3hyN25oKxZn):
	IInDJdENe6GxoAcraY = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࠪ༽")
	if BhTAck1bPFYGuUqRW: AYpOWlLEaM1bVP3hyN25oKxZn = AYpOWlLEaM1bVP3hyN25oKxZn.decode(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡹࡹ࡬࠸ࠨ༾"))
	from unicodedata import decomposition as zzPFaJUs14uBk5RiSYL
	for UOnow647kYPjhLeB0upmDy9r in AYpOWlLEaM1bVP3hyN25oKxZn:
		if   UOnow647kYPjhLeB0upmDy9r==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࡹࠬศࠧ༿"): wc5HbqKl6EIofjLZJzdghGDkUB = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭ཀ")
		elif UOnow647kYPjhLeB0upmDy9r==B2vCEI9FAVP15R8eUbDJdySc(u"ࡻࠧฤࠩཁ"): wc5HbqKl6EIofjLZJzdghGDkUB = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨག")
		elif UOnow647kYPjhLeB0upmDy9r==LsG7EDcei1gMShH2aVOCo(u"ࡶࠩวࠫགྷ"): wc5HbqKl6EIofjLZJzdghGDkUB = lh6URegmQNq8LWX0HaK5(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪང")
		elif UOnow647kYPjhLeB0upmDy9r==MOwK1lpyNfCgqksX3jhV(u"ࡸࠫส࠭ཅ"): wc5HbqKl6EIofjLZJzdghGDkUB = Jbu2G0Qax8PYWpg(u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬཆ")
		elif UOnow647kYPjhLeB0upmDy9r==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡺ࠭ฦࠨཇ"): wc5HbqKl6EIofjLZJzdghGDkUB = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ཈")
		else:
			ww2qPUkTbefFuE = zzPFaJUs14uBk5RiSYL(UOnow647kYPjhLeB0upmDy9r)
			if KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠡࠩཉ") in ww2qPUkTbefFuE: wc5HbqKl6EIofjLZJzdghGDkUB = B2vCEI9FAVP15R8eUbDJdySc(u"ࠨ࡞࡟ࡹࠬཊ")+ww2qPUkTbefFuE.split(IPkQW7LojF3HO18V(u"ࠩࠣࠫཋ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠵ᖥ"))[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠵ᖥ")]
			else:
				wc5HbqKl6EIofjLZJzdghGDkUB = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪ࠴࠵࠶࠰ࠨཌ")+hex(ord(UOnow647kYPjhLeB0upmDy9r)).replace(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫ࠵ࡾࠧཌྷ"),Y5npATFarf1H9wBjc87(u"ࠬ࠭ཎ"))
				wc5HbqKl6EIofjLZJzdghGDkUB = IPkQW7LojF3HO18V(u"࠭࡜࡝ࡷࠪཏ")+wc5HbqKl6EIofjLZJzdghGDkUB[-KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠹ᖦ"):]
		IInDJdENe6GxoAcraY += wc5HbqKl6EIofjLZJzdghGDkUB
	IInDJdENe6GxoAcraY = IInDJdENe6GxoAcraY.replace(QQSULIva4ljNO73mFcWw(u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨཐ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ࠩད"))
	if BhTAck1bPFYGuUqRW: IInDJdENe6GxoAcraY = IInDJdENe6GxoAcraY.decode(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪདྷ")).encode(Y5npATFarf1H9wBjc87(u"ࠪࡹࡹ࡬࠸ࠨན"))
	else: IInDJdENe6GxoAcraY = IInDJdENe6GxoAcraY.encode(Sj1PYDmIpCUXO26(u"ࠫࡺࡺࡦ࠹ࠩཔ")).decode(mtEXp14ijx(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ཕ"))
	return IInDJdENe6GxoAcraY
def ymH9jzg2KId5MCvw8lXBZn(header=LsG7EDcei1gMShH2aVOCo(u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭བ"),default=onweDvmTOUj(u"ࠧࠨབྷ"),H0STyVegkOjoCpBP4s=IPkQW7LojF3HO18V(u"ࡆࡢ࡮ࡶࡩ᜛"),source=onweDvmTOUj(u"ࠨࠩམ")):
	FbewQr7IVXqN0ijhOtm2vAnauzZT = IAP1at62B4vOxbQYCNF0Ro(header,default,type=N7zpvB3VIPrwcSDEC.INPUT_ALPHANUM)
	FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠣࠤࠬཙ"),QQSULIva4ljNO73mFcWw(u"ࠪࠤࠬཚ")).replace(LsG7EDcei1gMShH2aVOCo(u"ࠫࠥࠦࠧཛ"),d0HDrq8Rtk16AlInw4TXb(u"ࠬࠦࠧཛྷ")).replace(d0HDrq8Rtk16AlInw4TXb(u"࠭ࠠࠡࠩཝ"),QQSULIva4ljNO73mFcWw(u"ࠧࠡࠩཞ"))
	if not FbewQr7IVXqN0ijhOtm2vAnauzZT and not H0STyVegkOjoCpBP4s:
		xrFqGMab4uLKZcS(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡐࡒࡘࡎࡉࡅࠨཟ"),Q2ZyGqCNYsftTc4MR7n(u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭འ")+FbewQr7IVXqN0ijhOtm2vAnauzZT+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࠦࠬཡ"))
		ztgqWUaDpe8CE9N(WWbmNvI40sM9Khlp25Ae(u"ࠫࠬར"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭ལ"),QQSULIva4ljNO73mFcWw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཤ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧห็ࠣษ้เวยࠢส่สีฮศๆࠪཥ"))
		return Jbu2G0Qax8PYWpg(u"ࠨࠩས")
	if FbewQr7IVXqN0ijhOtm2vAnauzZT not in [hxSBTdGpyNVbfu4tr9(u"ࠩࠪཧ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࠤࠬཨ")]:
		FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.strip(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࠥ࠭ཀྵ"))
		FbewQr7IVXqN0ijhOtm2vAnauzZT = s8sONHML19B5oh(FbewQr7IVXqN0ijhOtm2vAnauzZT)
	if source!=mtEXp14ijx(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧཪ") and d0HtblNDaOnv4Py9QhkA5iS1omGI(Q2ZyGqCNYsftTc4MR7n(u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨཫ"),LsG7EDcei1gMShH2aVOCo(u"ࠧࠨཬ"),[FbewQr7IVXqN0ijhOtm2vAnauzZT],Y5npATFarf1H9wBjc87(u"ࡇࡣ࡯ࡷࡪ᜜")):
		xrFqGMab4uLKZcS(gy9NA3CROZolfEt4vVzMr(u"ࠨࡐࡒࡘࡎࡉࡅࠨ཭"),IPkQW7LojF3HO18V(u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬ཮")+FbewQr7IVXqN0ijhOtm2vAnauzZT+mtEXp14ijx(u"ࠪࠦࠬ཯"))
		ztgqWUaDpe8CE9N(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠬ཰"),lh6URegmQNq8LWX0HaK5(u"ཱࠬ࠭"),Sj1PYDmIpCUXO26(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอིࠩ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหཱིࠩ"))
		return Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨུࠩ")
	xrFqGMab4uLKZcS(gy9NA3CROZolfEt4vVzMr(u"ࠩࡑࡓ࡙ࡏࡃࡆཱུࠩ"),NQ4hg16DPUxtOyo5iGb(u"ࠪ࠲ࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ྲྀ")+FbewQr7IVXqN0ijhOtm2vAnauzZT+eaF2N0jWLdvHIs8r(u"ࠫࠧ࠭ཷ"))
	return FbewQr7IVXqN0ijhOtm2vAnauzZT
def I1IwMGlyuaB9XTe(vfIB6ib8q1hFX5GweRrVPNTjY2E,mgDoj8ZAqe0uBLxP4Kzp={}):
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX,YsJL1vp47e3XxtNhuno2gZ,crf9moYRDNxwtyJ,tuHhwQaqRdYIn5O = vfIB6ib8q1hFX5GweRrVPNTjY2E,{},{},gy9NA3CROZolfEt4vVzMr(u"ࠬ࠭ླྀ")
	if RS7ZoyGAq1c(u"࠭ࡼࠨཹ") in vfIB6ib8q1hFX5GweRrVPNTjY2E: xTFHrZ1nGWa9fdqsSA5y4htgJNmX,YsJL1vp47e3XxtNhuno2gZ = RyQ1vTDniwqI7jCNMHmtcLaVK(vfIB6ib8q1hFX5GweRrVPNTjY2E,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡽེࠩ"))
	QnHBhm8Szb74fNF0oU2 = list(set(list(mgDoj8ZAqe0uBLxP4Kzp.keys())+list(YsJL1vp47e3XxtNhuno2gZ.keys())))
	for Y9orNmEJt8OWyM72vGafZleg5z4 in QnHBhm8Szb74fNF0oU2:
		if Y9orNmEJt8OWyM72vGafZleg5z4 in list(YsJL1vp47e3XxtNhuno2gZ.keys()): crf9moYRDNxwtyJ[Y9orNmEJt8OWyM72vGafZleg5z4] = YsJL1vp47e3XxtNhuno2gZ[Y9orNmEJt8OWyM72vGafZleg5z4]
		else: crf9moYRDNxwtyJ[Y9orNmEJt8OWyM72vGafZleg5z4] = mgDoj8ZAqe0uBLxP4Kzp[Y9orNmEJt8OWyM72vGafZleg5z4]
	if MOwK1lpyNfCgqksX3jhV(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸཻࠬ") not in QnHBhm8Szb74fNF0oU2: crf9moYRDNxwtyJ[NQ4hg16DPUxtOyo5iGb(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹོ࠭")] = W5h0lzIcY3gMqrZpb7C()
	if FZBX5WcC3msIDv4hobLd8(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵཽࠫ") not in QnHBhm8Szb74fNF0oU2: crf9moYRDNxwtyJ[B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬཾ")] = DRom9hFTZXKuvfr2(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡻࡲ࡭ࠩཿ"))
	for Y9orNmEJt8OWyM72vGafZleg5z4 in list(crf9moYRDNxwtyJ.keys()): tuHhwQaqRdYIn5O += a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠦࠨྀ")+Y9orNmEJt8OWyM72vGafZleg5z4+mtEXp14ijx(u"ࠧ࠾ཱྀࠩ")+crf9moYRDNxwtyJ[Y9orNmEJt8OWyM72vGafZleg5z4]
	if tuHhwQaqRdYIn5O: tuHhwQaqRdYIn5O = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡾࠪྂ")+tuHhwQaqRdYIn5O[IPkQW7LojF3HO18V(u"࠷ᖧ"):]
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(AlcR9Gvo3QZsLnpfjS,Y5npATFarf1H9wBjc87(u"ࠩࡊࡉ࡙࠭ྃ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"྄ࠪࠫ"),crf9moYRDNxwtyJ,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࠬ྅"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭྆"),MOwK1lpyNfCgqksX3jhV(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ྇"),Q2ZyGqCNYsftTc4MR7n(u"ࡈࡤࡰࡸ࡫᜝"),Q2ZyGqCNYsftTc4MR7n(u"ࡈࡤࡰࡸ࡫᜝"))
	mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
	if Q2ZyGqCNYsftTc4MR7n(u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫྈ") not in mmhS2KFYI4eC6HWgk1trq: return [q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࠯࠴ࠫྉ")],[xTFHrZ1nGWa9fdqsSA5y4htgJNmX+tuHhwQaqRdYIn5O]
	if aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭ྊ") in mmhS2KFYI4eC6HWgk1trq: return [gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪ࠱࠶࠭ྋ")],[xTFHrZ1nGWa9fdqsSA5y4htgJNmX+tuHhwQaqRdYIn5O]
	if S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨྌ") in mmhS2KFYI4eC6HWgk1trq: return [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠳࠱ࠨྍ")],[xTFHrZ1nGWa9fdqsSA5y4htgJNmX+tuHhwQaqRdYIn5O]
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,T4TvYoeyUW97xCgz,k8VjP3gerqFR = [],[],[],[]
	IozWafE1PiOCyMLjR = SomeI8i56FaDMGPE.findall(QQSULIva4ljNO73mFcWw(u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧྎ"),mmhS2KFYI4eC6HWgk1trq+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧ࡝ࡰࠪྏ"),SomeI8i56FaDMGPE.DOTALL)
	if not IozWafE1PiOCyMLjR: return [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࠯࠴ࠫྐ")],[xTFHrZ1nGWa9fdqsSA5y4htgJNmX+tuHhwQaqRdYIn5O]
	for DUaE01KxW4A9rtwTizg2OV,sDCfutRY03p6ZNclVLJqIrQ in IozWafE1PiOCyMLjR:
		P8YQJzOtVxsnHuk1G,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl,AfejZJoKh4D7k5G1P9gCwxTz = {},-S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠱ᖨ"),-S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠱ᖨ")
		LL8sAHjK6hJovr5i = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪྑ")
		fJaoqEl9dID2Hr7ByZwVOk8stN = DUaE01KxW4A9rtwTizg2OV.split(MOwK1lpyNfCgqksX3jhV(u"ࠪ࠰ࠬྒ"))
		for iJe1DukCLnsTtyRZp in fJaoqEl9dID2Hr7ByZwVOk8stN:
			if QQSULIva4ljNO73mFcWw(u"ࠫࡂ࠭ྒྷ") in iJe1DukCLnsTtyRZp:
				Y9orNmEJt8OWyM72vGafZleg5z4,V0UzjKdk3gOnmN4GYt5vix2e = iJe1DukCLnsTtyRZp.split(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡃࠧྔ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠲ᖩ"))
				P8YQJzOtVxsnHuk1G[Y9orNmEJt8OWyM72vGafZleg5z4.lower()] = V0UzjKdk3gOnmN4GYt5vix2e
		if IPkQW7LojF3HO18V(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྕ") in DUaE01KxW4A9rtwTizg2OV.lower():
			Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = int(P8YQJzOtVxsnHuk1G[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྖ")])//RS7ZoyGAq1c(u"࠳࠳࠶࠹ᖪ")
			LL8sAHjK6hJovr5i += str(Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl)+RS7ZoyGAq1c(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨྗ")
		elif FZBX5WcC3msIDv4hobLd8(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ྘") in DUaE01KxW4A9rtwTizg2OV.lower():
			Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = int(P8YQJzOtVxsnHuk1G[FZBX5WcC3msIDv4hobLd8(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ྙ")])//q6yUEoKVDb0fXmc8vhrMk7N(u"࠴࠴࠷࠺ᖫ")
			LL8sAHjK6hJovr5i += str(Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl)+d0HDrq8Rtk16AlInw4TXb(u"ࠫࡰࡨࡰࡴࠢࠣࠫྚ")
		if onweDvmTOUj(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩྛ") in DUaE01KxW4A9rtwTizg2OV.lower():
			AfejZJoKh4D7k5G1P9gCwxTz = int(P8YQJzOtVxsnHuk1G[FZBX5WcC3msIDv4hobLd8(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪྜ")].split(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡹࠩྜྷ"))[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠵ᖬ")])
			LL8sAHjK6hJovr5i += str(AfejZJoKh4D7k5G1P9gCwxTz)+onweDvmTOUj(u"ࠨࠢࠣࠫྞ")
		LL8sAHjK6hJovr5i = LL8sAHjK6hJovr5i.strip(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠣࠤࠬྟ"))
		if not LL8sAHjK6hJovr5i: LL8sAHjK6hJovr5i = wKdxVbTc0X9NSiespM8OvHGUhf(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫྠ")
		if not sDCfutRY03p6ZNclVLJqIrQ.startswith(hxSBTdGpyNVbfu4tr9(u"ࠫ࡭ࡺࡴࡱࠩྡ")):
			if sDCfutRY03p6ZNclVLJqIrQ.startswith(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠵࠯ࠨྡྷ")): sDCfutRY03p6ZNclVLJqIrQ = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.split(hxSBTdGpyNVbfu4tr9(u"࠭࠺ࠨྣ"),RS7ZoyGAq1c(u"࠶ᖭ"))[B2vCEI9FAVP15R8eUbDJdySc(u"࠶ᖮ")]+MOwK1lpyNfCgqksX3jhV(u"ࠧ࠻ࠩྤ")+sDCfutRY03p6ZNclVLJqIrQ
			elif sDCfutRY03p6ZNclVLJqIrQ.startswith(eaF2N0jWLdvHIs8r(u"ࠨ࠱ࠪྥ")): sDCfutRY03p6ZNclVLJqIrQ = DRom9hFTZXKuvfr2(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,IPkQW7LojF3HO18V(u"ࠩࡸࡶࡱ࠭ྦ"))+sDCfutRY03p6ZNclVLJqIrQ
			else: sDCfutRY03p6ZNclVLJqIrQ = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.rsplit(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪ࠳ࠬྦྷ"),Q2ZyGqCNYsftTc4MR7n(u"࠱ᖯ"))[Q2ZyGqCNYsftTc4MR7n(u"࠱ᖰ")]+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫ࠴࠭ྨ")+sDCfutRY03p6ZNclVLJqIrQ
		if a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧྩ") in list(P8YQJzOtVxsnHuk1G.keys()):
			spdYctk0fWD1Z = P8YQJzOtVxsnHuk1G[lh6URegmQNq8LWX0HaK5(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨྪ")]
			spdYctk0fWD1Z = spdYctk0fWD1Z.replace(d0HDrq8Rtk16AlInw4TXb(u"ࠧࠣࠩྫ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࠩྫྷ")).replace(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠤࠪࠦྭ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࠫྮ")).split(FZBX5WcC3msIDv4hobLd8(u"ࠫࠨ࠭ྯ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠳ᖱ"))[QQSULIva4ljNO73mFcWw(u"࠳ᖲ")]
			MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(spdYctk0fWD1Z)
			if MMQ7S0sAgzHIumcqWUx: U2iQmHMJzoNkjORTGY7c51vZ = LL8sAHjK6hJovr5i+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࠦࠠࠨྰ")+MMQ7S0sAgzHIumcqWUx
			else: U2iQmHMJzoNkjORTGY7c51vZ = LL8sAHjK6hJovr5i
			U2iQmHMJzoNkjORTGY7c51vZ = U2iQmHMJzoNkjORTGY7c51vZ+WWbmNvI40sM9Khlp25Ae(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭ྱ")
			U2iQmHMJzoNkjORTGY7c51vZ = U2iQmHMJzoNkjORTGY7c51vZ+QQSULIva4ljNO73mFcWw(u"ࠧࠡࠢࠪྲ")+DRom9hFTZXKuvfr2(spdYctk0fWD1Z,hxSBTdGpyNVbfu4tr9(u"ࠨࡰࡤࡱࡪ࠭ླ"))
			r79xJG6jXHD.append(U2iQmHMJzoNkjORTGY7c51vZ)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(spdYctk0fWD1Z)
			T4TvYoeyUW97xCgz.append(AfejZJoKh4D7k5G1P9gCwxTz)
			k8VjP3gerqFR.append(Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl)
		sDCfutRY03p6ZNclVLJqIrQ = sDCfutRY03p6ZNclVLJqIrQ.split(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠦࠫྴ"),LsG7EDcei1gMShH2aVOCo(u"࠵ᖳ"))[Jbu2G0Qax8PYWpg(u"࠵ᖴ")]
		MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(sDCfutRY03p6ZNclVLJqIrQ)
		if MMQ7S0sAgzHIumcqWUx: LL8sAHjK6hJovr5i = LL8sAHjK6hJovr5i+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠤࠥ࠭ྵ")+MMQ7S0sAgzHIumcqWUx
		LL8sAHjK6hJovr5i = LL8sAHjK6hJovr5i+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠥࠦࠧྶ")+DRom9hFTZXKuvfr2(sDCfutRY03p6ZNclVLJqIrQ,FZBX5WcC3msIDv4hobLd8(u"ࠬࡴࡡ࡮ࡧࠪྷ"))
		r79xJG6jXHD.append(LL8sAHjK6hJovr5i)
		aFyREdMQk7Ys95rX6uJieDGLS2.append(sDCfutRY03p6ZNclVLJqIrQ)
		T4TvYoeyUW97xCgz.append(AfejZJoKh4D7k5G1P9gCwxTz)
		k8VjP3gerqFR.append(Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl)
	XTPzvZdUymK2axoEu8W73BjMcheQf = list(zip(r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,T4TvYoeyUW97xCgz,k8VjP3gerqFR))
	XTPzvZdUymK2axoEu8W73BjMcheQf = sorted(XTPzvZdUymK2axoEu8W73BjMcheQf, reverse=gy9NA3CROZolfEt4vVzMr(u"ࡗࡶࡺ࡫᜞"), key=lambda key: key[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠹ᖵ")])
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,T4TvYoeyUW97xCgz,k8VjP3gerqFR = list(zip(*XTPzvZdUymK2axoEu8W73BjMcheQf))
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = list(r79xJG6jXHD),list(aFyREdMQk7Ys95rX6uJieDGLS2)
	DGcdskjBKixNSwlW5O7rpM = []
	for sDCfutRY03p6ZNclVLJqIrQ in aFyREdMQk7Ys95rX6uJieDGLS2: DGcdskjBKixNSwlW5O7rpM.append(sDCfutRY03p6ZNclVLJqIrQ+tuHhwQaqRdYIn5O)
	return r79xJG6jXHD,DGcdskjBKixNSwlW5O7rpM
def XxmdGKqvtUIgCbP34ahMfoJrR2W8ZQ(XXfrWZnRsmx47VOwcLe,CmiVNjBLoJd2A8pgPkHvnZrX5D=Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠧྸ")):
	if not CmiVNjBLoJd2A8pgPkHvnZrX5D: CmiVNjBLoJd2A8pgPkHvnZrX5D = urVJDsPi2IFh[MOwK1lpyNfCgqksX3jhV(u"࠰ᖶ")]
	if XXfrWZnRsmx47VOwcLe.replace(MOwK1lpyNfCgqksX3jhV(u"ࠧ࠯ࠩྐྵ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࠩྺ")).isdigit(): return [XXfrWZnRsmx47VOwcLe]
	from struct import pack as jiu1xadg3w7SUE,unpack_from as HWyPANtckJ6L5KFV78mI
	from socket import socket as g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS,AF_INET as A63OvTSBM5xduK4m8yorhjPYqw,SOCK_DGRAM as aaeisMrV8BfDTyXY
	try:
		BBu5dUXHa3Tb4GtDZI0n = jiu1xadg3w7SUE(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠤࡁࡌࠧྻ"), Rz34c0NP5BGo1WuTZxSfOKj(u"࠲࠴࠳࠸࠾ᖷ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(lh6URegmQNq8LWX0HaK5(u"ࠥࡂࡍࠨྼ"), lh6URegmQNq8LWX0HaK5(u"࠴࠸࠺ᖸ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(NQ4hg16DPUxtOyo5iGb(u"ࠦࡃࡎࠢ྽"), B2vCEI9FAVP15R8eUbDJdySc(u"࠴ᖹ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(hxSBTdGpyNVbfu4tr9(u"ࠧࡄࡈࠣ྾"), hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠴ᖺ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(LsG7EDcei1gMShH2aVOCo(u"ࠨ࠾ࡉࠤ྿"), RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠵ᖻ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(IPkQW7LojF3HO18V(u"ࠢ࠿ࡊࠥ࿀"), aSf0iWG1kA7FsqjHbuC8NXB(u"࠶ᖼ"))
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: xvAG8EdqHOWcKnLru = XXfrWZnRsmx47VOwcLe.split(onweDvmTOUj(u"ࠨ࠰ࠪ࿁"))
		else: xvAG8EdqHOWcKnLru = XXfrWZnRsmx47VOwcLe.decode(Q2ZyGqCNYsftTc4MR7n(u"ࠩࡸࡸ࡫࠾ࠧ࿂")).split(Q2ZyGqCNYsftTc4MR7n(u"ࠪ࠲ࠬ࿃"))
		for PPnCglVy4epdS2iXmht in xvAG8EdqHOWcKnLru:
			tD5ovMzSdjLxBP4QynliVOEAKW = PPnCglVy4epdS2iXmht.encode(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡺࡺࡦ࠹ࠩ࿄"))
			BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(RS7ZoyGAq1c(u"ࠧࡈࠢ࿅"), len(PPnCglVy4epdS2iXmht))
			for bZHiKk6EYAwfstzWQ38CnT9R0de in PPnCglVy4epdS2iXmht:
				BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(WWbmNvI40sM9Khlp25Ae(u"ࠨࡣ࿆ࠣ"), bZHiKk6EYAwfstzWQ38CnT9R0de.encode(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡶࡶࡩ࠼ࠬ࿇")))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(WWbmNvI40sM9Khlp25Ae(u"ࠣࡄࠥ࿈"), d0HDrq8Rtk16AlInw4TXb(u"࠰ᖽ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠤࡁࡌࠧ࿉"), KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠲ᖾ"))
		BBu5dUXHa3Tb4GtDZI0n += jiu1xadg3w7SUE(Sj1PYDmIpCUXO26(u"ࠥࡂࡍࠨ࿊"), RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠳ᖿ"))
		SSroljfb3u = g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS(A63OvTSBM5xduK4m8yorhjPYqw,aaeisMrV8BfDTyXY)
		SSroljfb3u.sendto(bytes(BBu5dUXHa3Tb4GtDZI0n), (CmiVNjBLoJd2A8pgPkHvnZrX5D, d0HDrq8Rtk16AlInw4TXb(u"࠸࠷ᗀ")))
		SSroljfb3u.settimeout(FZBX5WcC3msIDv4hobLd8(u"࠺ᗁ"))
		oo76muA1GlEh9s0ZHNT4yMXQzipP, Ct0M1wedQqksU3X = SSroljfb3u.recvfrom(eaF2N0jWLdvHIs8r(u"࠶࠶࠲࠵ᗂ"))
		SSroljfb3u.close()
		IHGWmOjgEvP = HWyPANtckJ6L5KFV78mI(RS7ZoyGAq1c(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ࿋"), oo76muA1GlEh9s0ZHNT4yMXQzipP, lh6URegmQNq8LWX0HaK5(u"࠶ᗃ"))
		R1rQB9Vlymcp3YU = IHGWmOjgEvP[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠳ᗄ")]
		Io2jwJA1BgYnk = len(XXfrWZnRsmx47VOwcLe)+lh6URegmQNq8LWX0HaK5(u"࠲࠺ᗅ")
		j2jpfQzAmwUo6G = []
		for _zjRKGNQViCEMBLpD in range(R1rQB9Vlymcp3YU):
			REnsNiUx9GcmyWFDkJKXl38QbZu6 = Io2jwJA1BgYnk
			ewsLUO8GaKiI6fVlTzWj = Y5npATFarf1H9wBjc87(u"࠳ᗆ")
			J4JhczsulUK6R = FZBX5WcC3msIDv4hobLd8(u"ࡊࡦࡲࡳࡦᜟ")
			while nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࡙ࡸࡵࡦᜠ"):
				bZHiKk6EYAwfstzWQ38CnT9R0de = HWyPANtckJ6L5KFV78mI(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡄࡂࠣ࿌"), oo76muA1GlEh9s0ZHNT4yMXQzipP, REnsNiUx9GcmyWFDkJKXl38QbZu6)[RS7ZoyGAq1c(u"࠳ᗇ")]
				if bZHiKk6EYAwfstzWQ38CnT9R0de == wKdxVbTc0X9NSiespM8OvHGUhf(u"࠴ᗈ"):
					REnsNiUx9GcmyWFDkJKXl38QbZu6 += Rz34c0NP5BGo1WuTZxSfOKj(u"࠶ᗉ")
					break
				if bZHiKk6EYAwfstzWQ38CnT9R0de >= NQ4hg16DPUxtOyo5iGb(u"࠷࠹࠳ᗊ"):
					HHT3AuGgIwRqjMNfeLb8Dc7 = HWyPANtckJ6L5KFV78mI(MOwK1lpyNfCgqksX3jhV(u"ࠨ࠾ࡃࠤ࿍"), oo76muA1GlEh9s0ZHNT4yMXQzipP, REnsNiUx9GcmyWFDkJKXl38QbZu6 + Sj1PYDmIpCUXO26(u"࠱ᗋ"))[d0HDrq8Rtk16AlInw4TXb(u"࠱ᗌ")]
					REnsNiUx9GcmyWFDkJKXl38QbZu6 = ((bZHiKk6EYAwfstzWQ38CnT9R0de << d0HDrq8Rtk16AlInw4TXb(u"࠻ᗎ")) + HHT3AuGgIwRqjMNfeLb8Dc7 - 0xc000) - hxSBTdGpyNVbfu4tr9(u"࠳ᗍ")
					J4JhczsulUK6R = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࡚ࡲࡶࡧᜡ")
				REnsNiUx9GcmyWFDkJKXl38QbZu6 += IPkQW7LojF3HO18V(u"࠵ᗏ")
				if J4JhczsulUK6R == RS7ZoyGAq1c(u"ࡆࡢ࡮ࡶࡩᜢ"): ewsLUO8GaKiI6fVlTzWj += hxSBTdGpyNVbfu4tr9(u"࠶ᗐ")
			if J4JhczsulUK6R == lh6URegmQNq8LWX0HaK5(u"ࡕࡴࡸࡩᜣ"): ewsLUO8GaKiI6fVlTzWj += RS7ZoyGAq1c(u"࠷ᗑ")
			Io2jwJA1BgYnk = Io2jwJA1BgYnk + ewsLUO8GaKiI6fVlTzWj
			pJZitMsmbSaTx2cguUCW = HWyPANtckJ6L5KFV78mI(IPkQW7LojF3HO18V(u"ࠢ࠿ࡊࡋࡍࡍࠨ࿎"), oo76muA1GlEh9s0ZHNT4yMXQzipP, Io2jwJA1BgYnk)
			Io2jwJA1BgYnk = Io2jwJA1BgYnk + MOwK1lpyNfCgqksX3jhV(u"࠱࠱ᗒ")
			wIviBcHp0snPRuWdNGL = pJZitMsmbSaTx2cguUCW[IPkQW7LojF3HO18V(u"࠱ᗓ")]
			y9fbIJBvd5TMHoDelnzksFr = pJZitMsmbSaTx2cguUCW[onweDvmTOUj(u"࠵ᗔ")]
			if wIviBcHp0snPRuWdNGL == Jbu2G0Qax8PYWpg(u"࠴ᗕ"):
				pXYGsStRCVDE = HWyPANtckJ6L5KFV78mI(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠣࡀࠥ࿏")+Y5npATFarf1H9wBjc87(u"ࠤࡅࠦ࿐")*y9fbIJBvd5TMHoDelnzksFr, oo76muA1GlEh9s0ZHNT4yMXQzipP, Io2jwJA1BgYnk)
				ip = Y5npATFarf1H9wBjc87(u"ࠪࠫ࿑")
				for bZHiKk6EYAwfstzWQ38CnT9R0de in pXYGsStRCVDE: ip += str(bZHiKk6EYAwfstzWQ38CnT9R0de) + d0HDrq8Rtk16AlInw4TXb(u"ࠫ࠳࠭࿒")
				ip = ip[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠵ᗗ"):-WWbmNvI40sM9Khlp25Ae(u"࠵ᗖ")]
				j2jpfQzAmwUo6G.append(ip)
			if wIviBcHp0snPRuWdNGL in [mtEXp14ijx(u"࠲ᗚ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࠴ᗛ"),WWbmNvI40sM9Khlp25Ae(u"࠸ᗜ"),WWbmNvI40sM9Khlp25Ae(u"࠺ᗝ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠷࠵ᗘ"),IPkQW7LojF3HO18V(u"࠲࠹ᗙ")]: Io2jwJA1BgYnk = Io2jwJA1BgYnk + y9fbIJBvd5TMHoDelnzksFr
	except: j2jpfQzAmwUo6G = []
	if not j2jpfQzAmwUo6G: xrFqGMab4uLKZcS(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࿓"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬ࿔")+XXfrWZnRsmx47VOwcLe+Jbu2G0Qax8PYWpg(u"ࠧࠡ࡟ࠪ࿕"))
	return j2jpfQzAmwUo6G
def d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,Wch421XkoTwA,showDialogs=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡖࡵࡹࡪᜤ")):
	if Wch421XkoTwA:
		XiFHKC5Rq6DJrezAl = [eaF2N0jWLdvHIs8r(u"ࠨๅหหึ࠭࿖"),Sj1PYDmIpCUXO26(u"ࠩหห้เࠧ࿗"),lh6URegmQNq8LWX0HaK5(u"ࠪࡥࡩࡻ࡬ࡵࠩ࿘"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࡽࡾࠧ࿙"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡹࡥࡹࠩ࿚")]
		if HmvY29bj4dNgF7wZqr1lzkeQxiEasu!=FZBX5WcC3msIDv4hobLd8(u"࠭ࡂࡐࡍࡕࡅࠬ࿛"):
			XiFHKC5Rq6DJrezAl += [lh6URegmQNq8LWX0HaK5(u"ࠧࡳ࠼ࠪ࿜"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡴ࠰ࠫ࿝"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩ࠰ࡱࡦ࠭࿞")]
			XiFHKC5Rq6DJrezAl += [RS7ZoyGAq1c(u"ࠪ࠾ࡷ࠭࿟"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫ࠲ࡸࠧ࿠"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬࡳࡡ࠮ࠩ࿡")]
		for dTsUxZbrBYVlazjgmf9Kw2 in Wch421XkoTwA:
			if QQSULIva4ljNO73mFcWw(u"࠭ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨ࿢") in dTsUxZbrBYVlazjgmf9Kw2: continue
			if Y5npATFarf1H9wBjc87(u"ࠧฮๆๅอࠬ࿣") in dTsUxZbrBYVlazjgmf9Kw2: continue
			dTsUxZbrBYVlazjgmf9Kw2 = dTsUxZbrBYVlazjgmf9Kw2.lower()
			if BhTAck1bPFYGuUqRW: dTsUxZbrBYVlazjgmf9Kw2 = dTsUxZbrBYVlazjgmf9Kw2.decode(onweDvmTOUj(u"ࠨࡷࡷࡪ࠽࠭࿤")).encode(gy9NA3CROZolfEt4vVzMr(u"ࠩࡸࡸ࡫࠾ࠧ࿥"))
			dTsUxZbrBYVlazjgmf9Kw2 = dTsUxZbrBYVlazjgmf9Kw2.replace(onweDvmTOUj(u"ࠪ࠾ࠬ࿦"),RS7ZoyGAq1c(u"ࠫࠬ࿧"))
			TA3fFwVbzK6 = SomeI8i56FaDMGPE.findall(lh6URegmQNq8LWX0HaK5(u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩ࿨"),dTsUxZbrBYVlazjgmf9Kw2,SomeI8i56FaDMGPE.DOTALL)
			ERqmyV3xlt7cfTWPgwXAar2COno = d0HDrq8Rtk16AlInw4TXb(u"ࡉࡥࡱࡹࡥᜥ")
			for rWI3gNoCLaO0K2ixMsJyvAunbzw in TA3fFwVbzK6:
				if len(rWI3gNoCLaO0K2ixMsJyvAunbzw)==d0HDrq8Rtk16AlInw4TXb(u"࠷ᗞ"):
					ERqmyV3xlt7cfTWPgwXAar2COno = q6yUEoKVDb0fXmc8vhrMk7N(u"ࡘࡷࡻࡥᜦ")
					break
			if q6yUEoKVDb0fXmc8vhrMk7N(u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩ࿩") in dTsUxZbrBYVlazjgmf9Kw2: continue
			elif a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨ࿪") in dTsUxZbrBYVlazjgmf9Kw2: continue
			elif Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨ฼ํี๋ࠥี็ใࠪ࿫") in dTsUxZbrBYVlazjgmf9Kw2: continue
			elif tvwmlYcDnVybgPHKU84GOFI0uAq(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫ࿬")): continue
			elif dTsUxZbrBYVlazjgmf9Kw2 in [mtEXp14ijx(u"ࠪࡶࠬ࿭")] or ERqmyV3xlt7cfTWPgwXAar2COno or any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in dTsUxZbrBYVlazjgmf9Kw2 for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in XiFHKC5Rq6DJrezAl):
				xrFqGMab4uLKZcS(Y5npATFarf1H9wBjc87(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ࿮"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+IPkQW7LojF3HO18V(u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ࿯")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+QQSULIva4ljNO73mFcWw(u"࠭ࠠ࡞ࠩ࿰"))
				if showDialogs: NCXj2ri3Unm6TFWIgwh(WWbmNvI40sM9Khlp25Ae(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࿱"),eaF2N0jWLdvHIs8r(u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ࿲"))
				return B2vCEI9FAVP15R8eUbDJdySc(u"࡙ࡸࡵࡦᜧ")
	return Rz34c0NP5BGo1WuTZxSfOKj(u"ࡌࡡ࡭ࡵࡨᜨ")
def ztgqWUaDpe8CE9N(*aargs,**kkwargs):
	if aargs:
		direction = aargs[eaF2N0jWLdvHIs8r(u"࠶ᗟ")]
		tPR1pvIJFDrYgVoqGXWixZL0SEb2MU = aargs[aSf0iWG1kA7FsqjHbuC8NXB(u"࠱ᗠ")]
		if not direction: direction = NQ4hg16DPUxtOyo5iGb(u"ࠩࡦࡩࡳࡺࡥࡳࠩ࿳")
		if not tPR1pvIJFDrYgVoqGXWixZL0SEb2MU: tPR1pvIJFDrYgVoqGXWixZL0SEb2MU = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪหุะๅาษิࠫ࿴")
		I89adFKf7CJ4BOQ = aargs[onweDvmTOUj(u"࠳ᗡ")]
		FbewQr7IVXqN0ijhOtm2vAnauzZT = lh6URegmQNq8LWX0HaK5(u"ࠫࡡࡴࠧ࿵").join(aargs[RS7ZoyGAq1c(u"࠵ᗢ"):])
	else: direction,tPR1pvIJFDrYgVoqGXWixZL0SEb2MU,I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࠭࿶"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡏࡌࠩ࿷"),Sj1PYDmIpCUXO26(u"ࠧࠨ࿸"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࠩ࿹")
	bxBWM9d53zOAcar(direction,onweDvmTOUj(u"ࠩࠪ࿺"),tPR1pvIJFDrYgVoqGXWixZL0SEb2MU,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࠫ࿻"),I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,**kkwargs)
	return
def nEYJ5OCXG0gcNy(*aargs,**kkwargs):
	direction = aargs[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠳ᗣ")]
	dhePA17X5z = aargs[NQ4hg16DPUxtOyo5iGb(u"࠵ᗤ")]
	SbfVOA8rzhEw7WiKP1tYcx = aargs[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠷ᗥ")]
	if SbfVOA8rzhEw7WiKP1tYcx or dhePA17X5z: afseyO9WGmPKq5tSprXn = lh6URegmQNq8LWX0HaK5(u"ࡔࡳࡷࡨᜩ")
	else: afseyO9WGmPKq5tSprXn = mtEXp14ijx(u"ࡇࡣ࡯ࡷࡪᜪ")
	I89adFKf7CJ4BOQ = aargs[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠹ᗦ")]
	FbewQr7IVXqN0ijhOtm2vAnauzZT = aargs[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴ᗧ")]
	if not direction: direction = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿼")
	if not dhePA17X5z: dhePA17X5z = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"้ࠬไศࠢࠣࡒࡴ࠭࿽")
	if not SbfVOA8rzhEw7WiKP1tYcx: SbfVOA8rzhEw7WiKP1tYcx = RS7ZoyGAq1c(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨ࿾")
	if len(aargs)>=gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠸ᗩ"): FbewQr7IVXqN0ijhOtm2vAnauzZT += q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧ࡝ࡰࠪ࿿")+aargs[Y5npATFarf1H9wBjc87(u"࠶ᗨ")]
	if len(aargs)>=d0HDrq8Rtk16AlInw4TXb(u"࠺ᗪ"): FbewQr7IVXqN0ijhOtm2vAnauzZT += Jbu2G0Qax8PYWpg(u"ࠨ࡞ࡱࠫက")+aargs[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠺ᗫ")]
	DDZR5PlzeiyonWaCGfv67uqj2btEN = bxBWM9d53zOAcar(direction,dhePA17X5z,Y5npATFarf1H9wBjc87(u"ࠩࠪခ"),SbfVOA8rzhEw7WiKP1tYcx,I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,**kkwargs)
	if DDZR5PlzeiyonWaCGfv67uqj2btEN==-Rz34c0NP5BGo1WuTZxSfOKj(u"࠶ᗬ") and afseyO9WGmPKq5tSprXn: DDZR5PlzeiyonWaCGfv67uqj2btEN = -Rz34c0NP5BGo1WuTZxSfOKj(u"࠶ᗬ")
	elif DDZR5PlzeiyonWaCGfv67uqj2btEN==-Q2ZyGqCNYsftTc4MR7n(u"࠷ᗭ") and not afseyO9WGmPKq5tSprXn: DDZR5PlzeiyonWaCGfv67uqj2btEN = mtEXp14ijx(u"ࡈࡤࡰࡸ࡫ᜫ")
	elif DDZR5PlzeiyonWaCGfv67uqj2btEN==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠰ᗮ"): DDZR5PlzeiyonWaCGfv67uqj2btEN = Y5npATFarf1H9wBjc87(u"ࡉࡥࡱࡹࡥᜬ")
	elif DDZR5PlzeiyonWaCGfv67uqj2btEN==Rz34c0NP5BGo1WuTZxSfOKj(u"࠳ᗯ"): DDZR5PlzeiyonWaCGfv67uqj2btEN = LsG7EDcei1gMShH2aVOCo(u"ࡘࡷࡻࡥᜭ")
	return DDZR5PlzeiyonWaCGfv67uqj2btEN
def wKxBD1f6FgH54qRvTYP0c2eJbS3X(*aargs,**kkwargs):
	return N7zpvB3VIPrwcSDEC.Dialog().select(*aargs,**kkwargs)
def NCXj2ri3Unm6TFWIgwh(*aargs,**kkwargs):
	I89adFKf7CJ4BOQ = aargs[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠲ᗰ")]
	FbewQr7IVXqN0ijhOtm2vAnauzZT = aargs[NQ4hg16DPUxtOyo5iGb(u"࠴ᗱ")]
	if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡸ࡮ࡳࡥࠨဂ") in list(kkwargs.keys()): kO8Go2J6A9ig = kkwargs[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡹ࡯࡭ࡦࠩဃ")]
	else: kO8Go2J6A9ig = d0HDrq8Rtk16AlInw4TXb(u"࠵࠵࠶࠰ᗲ")
	if len(aargs)>Jbu2G0Qax8PYWpg(u"࠷ᗳ") and RS7ZoyGAq1c(u"ࠬࡺࡩ࡮ࡧࠪင") not in aargs[Jbu2G0Qax8PYWpg(u"࠷ᗳ")]: profile = aargs[Jbu2G0Qax8PYWpg(u"࠷ᗳ")]
	else: profile = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬစ")
	bbSkQlgLOdyw9XvRVCZirh = RNxwXqM38FQEIzP4in6oeJyOcvSjZh(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧဆ"),gyXBVnYKzm4,FZBX5WcC3msIDv4hobLd8(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩဇ"),hxSBTdGpyNVbfu4tr9(u"ࠩ࠺࠶࠵ࡶࠧဈ"))
	image_filename = nA9zdBHP4q8XrVLi3CR.replace(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪဉ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡤ࠭ည")+str(p1BoraOuWL.time())+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡥࠧဋ"))
	image_filename = image_filename.replace(Sj1PYDmIpCUXO26(u"࠭࡜࡝ࠩဌ"),IPkQW7LojF3HO18V(u"ࠧ࡝࡞࡟ࡠࠬဍ")).replace(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࠱࠲ࠫဎ"),mtEXp14ijx(u"ࠩ࠲࠳࠴࠵ࠧဏ"))
	image_height = DkzsprAlwfGdgqHMhNtZvO5i6Rba(eaF2N0jWLdvHIs8r(u"ࠪࠫတ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࠬထ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬ࠭ဒ"),I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile,mtEXp14ijx(u"࠭࡬ࡦࡨࡷࠫဓ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࡋࡧ࡬ࡴࡧᜮ"),image_filename)
	bbSkQlgLOdyw9XvRVCZirh.show()
	if profile==Sj1PYDmIpCUXO26(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨန"):
		bbSkQlgLOdyw9XvRVCZirh.getControl(gy9NA3CROZolfEt4vVzMr(u"࠹࠱࠶࠳ᗵ")).setHeight(lh6URegmQNq8LWX0HaK5(u"࠸࠱࠶ᗴ"))
		bbSkQlgLOdyw9XvRVCZirh.getControl(Jbu2G0Qax8PYWpg(u"࠼࠴࠹࠶ᗸ")).setPosition(gy9NA3CROZolfEt4vVzMr(u"࠶࠷ᗶ"),-KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠺࠳ᗷ"))
		bbSkQlgLOdyw9XvRVCZirh.getControl(q6yUEoKVDb0fXmc8vhrMk7N(u"࠽࠵࠻࠰ᗹ")).setPosition(NQ4hg16DPUxtOyo5iGb(u"࠶࠸࠰ᗺ"),-eaF2N0jWLdvHIs8r(u"࠼࠰ᗻ"))
		bbSkQlgLOdyw9XvRVCZirh.getControl(B2vCEI9FAVP15R8eUbDJdySc(u"࠶࠳࠴ᗾ")).setPosition(MOwK1lpyNfCgqksX3jhV(u"࠹࠱ᗼ"),-IPkQW7LojF3HO18V(u"࠴࠷ᗽ"))
	bbSkQlgLOdyw9XvRVCZirh.getControl(OnvTrikzfEsY7qU8pgaRBtZy(u"࠷࠴࠶ᗿ")).setVisible(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡌࡡ࡭ࡵࡨᜯ"))
	bbSkQlgLOdyw9XvRVCZirh.getControl(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠸࠵࠸ᘀ")).setVisible(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡆࡢ࡮ࡶࡩᜰ"))
	bbSkQlgLOdyw9XvRVCZirh.getControl(mtEXp14ijx(u"࠾࠶࠵࠱ᘁ")).setImage(image_filename)
	bbSkQlgLOdyw9XvRVCZirh.getControl(q6yUEoKVDb0fXmc8vhrMk7N(u"࠿࠰࠶࠲ᘂ")).setHeight(image_height)
	RBnCc1b5JA = RrCB5k9XV6hYNSlIKJ2.Thread(target=YTDGd7V4ZvIWUX5emwfEsqQL,args=(bbSkQlgLOdyw9XvRVCZirh,image_filename,kO8Go2J6A9ig))
	RBnCc1b5JA.start()
	return
def YTDGd7V4ZvIWUX5emwfEsqQL(bbSkQlgLOdyw9XvRVCZirh,image_filename,kO8Go2J6A9ig):
	p1BoraOuWL.sleep(kO8Go2J6A9ig//gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠱࠱࠲࠳࠲࠵ᘃ"))
	p1BoraOuWL.sleep(mtEXp14ijx(u"࠱࠰࠴࠴࠵ᘄ"))
	if Dh9MOxeTj6FW.path.exists(image_filename):
		try: Dh9MOxeTj6FW.remove(image_filename)
		except: pass
	return
def CvFLQP9JtbqH(*aargs,**kkwargs):
	I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile,direction = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠩပ"),gy9NA3CROZolfEt4vVzMr(u"ࠩࠪဖ"),mtEXp14ijx(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫဗ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡱ࡫ࡦࡵࠩဘ")
	if len(aargs)>=lh6URegmQNq8LWX0HaK5(u"࠳ᘅ"): I89adFKf7CJ4BOQ = aargs[lh6URegmQNq8LWX0HaK5(u"࠳ᘆ")]
	if len(aargs)>=NQ4hg16DPUxtOyo5iGb(u"࠷ᘈ"): FbewQr7IVXqN0ijhOtm2vAnauzZT = aargs[Sj1PYDmIpCUXO26(u"࠵ᘇ")]
	if len(aargs)>=d0HDrq8Rtk16AlInw4TXb(u"࠹ᘉ"): profile = aargs[onweDvmTOUj(u"࠲ᘊ")]
	if len(aargs)>=aSf0iWG1kA7FsqjHbuC8NXB(u"࠶ᘌ"): direction = aargs[NQ4hg16DPUxtOyo5iGb(u"࠴ᘋ")]
	return DPfOyNk6YarWmFKU2ezZlAiG(direction,I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile)
def FfdZsHWK0SnY6yzEANbmXco8hO(*aargs,**kkwargs):
	return N7zpvB3VIPrwcSDEC.Dialog().contextmenu(*aargs,**kkwargs)
def gsaPufAIEOSHtMUz1Ln5w(*aargs,**kkwargs):
	return N7zpvB3VIPrwcSDEC.Dialog().browseSingle(*aargs,**kkwargs)
def IAP1at62B4vOxbQYCNF0Ro(*aargs,**kkwargs):
	return N7zpvB3VIPrwcSDEC.Dialog().input(*aargs,**kkwargs)
def AAGT9IPy4BoZN7(*aargs,**kkwargs):
	return N7zpvB3VIPrwcSDEC.DialogProgress(*aargs,**kkwargs)
def xmYBAMKujEkvWUpV(vk2TKbyG43hR6QpPYjmU):
	if Qf8xsJSwoKaUNc>MOwK1lpyNfCgqksX3jhV(u"࠴࠻࠳࠿࠹ᘍ"): bbSkQlgLOdyw9XvRVCZirh = FZBX5WcC3msIDv4hobLd8(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪမ")
	else: bbSkQlgLOdyw9XvRVCZirh = IPkQW7LojF3HO18V(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪယ")
	vk2TKbyG43hR6QpPYjmU = vk2TKbyG43hR6QpPYjmU.lower()
	if vk2TKbyG43hR6QpPYjmU==RS7ZoyGAq1c(u"ࠧࡴࡶࡤࡶࡹ࠭ရ"): WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪလ")+bbSkQlgLOdyw9XvRVCZirh+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࠬࠫဝ"))
	elif vk2TKbyG43hR6QpPYjmU==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡷࡹࡵࡰࠨသ"): WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(FZBX5WcC3msIDv4hobLd8(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫဟ")+bbSkQlgLOdyw9XvRVCZirh+eaF2N0jWLdvHIs8r(u"ࠬ࠯ࠧဠ"))
	return
def bxBWM9d53zOAcar(direction,button0=RS7ZoyGAq1c(u"࠭ࠧအ"),button1=mtEXp14ijx(u"ࠧࠨဢ"),button2=S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠩဣ"),I89adFKf7CJ4BOQ=NQ4hg16DPUxtOyo5iGb(u"ࠩࠪဤ"),FbewQr7IVXqN0ijhOtm2vAnauzZT=Sj1PYDmIpCUXO26(u"ࠪࠫဥ"),profile=hxSBTdGpyNVbfu4tr9(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭ဦ"),pTd0qumgLet5c1CfIHXoy=a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴ᘎ"),hhLDk0CuR6Ip=a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴ᘎ")):
	if not direction: direction = hxSBTdGpyNVbfu4tr9(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬဧ")
	bbSkQlgLOdyw9XvRVCZirh = eZHYr0ioAk5KjvDU4bBxcud3S7f(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨဨ"),gyXBVnYKzm4,Jbu2G0Qax8PYWpg(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨဩ"),d0HDrq8Rtk16AlInw4TXb(u"ࠨ࠹࠵࠴ࡵ࠭ဪ"))
	bbSkQlgLOdyw9XvRVCZirh.NBQJf0u7rSc1eIUvYWtKx(button0,button1,button2,I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile,direction,pTd0qumgLet5c1CfIHXoy,hhLDk0CuR6Ip)
	if pTd0qumgLet5c1CfIHXoy>nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵ᘏ"): bbSkQlgLOdyw9XvRVCZirh.Fo5M6h80aQvRd9eHcSptXJwnsAGj()
	if hhLDk0CuR6Ip>gy9NA3CROZolfEt4vVzMr(u"࠶ᘐ"): bbSkQlgLOdyw9XvRVCZirh.XP2O6mQDER()
	if pTd0qumgLet5c1CfIHXoy==Q2ZyGqCNYsftTc4MR7n(u"࠰ᘑ") and hhLDk0CuR6Ip==Q2ZyGqCNYsftTc4MR7n(u"࠰ᘑ"): bbSkQlgLOdyw9XvRVCZirh.DjoK1WrSavpe7yg()
	bbSkQlgLOdyw9XvRVCZirh.doModal()
	DDZR5PlzeiyonWaCGfv67uqj2btEN = bbSkQlgLOdyw9XvRVCZirh.choiceID
	return DDZR5PlzeiyonWaCGfv67uqj2btEN
def DPfOyNk6YarWmFKU2ezZlAiG(direction,I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile=lh6URegmQNq8LWX0HaK5(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪါ")):
	if not direction: direction = LsG7EDcei1gMShH2aVOCo(u"ࠪࡰࡪ࡬ࡴࠨာ")
	bbSkQlgLOdyw9XvRVCZirh = RNxwXqM38FQEIzP4in6oeJyOcvSjZh(WWbmNvI40sM9Khlp25Ae(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧိ"),gyXBVnYKzm4,MOwK1lpyNfCgqksX3jhV(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ီ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭࠷࠳࠲ࡳࠫု"))
	image_filename = nA9zdBHP4q8XrVLi3CR.replace(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧူ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡡࠪေ")+str(p1BoraOuWL.time())+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࡢࠫဲ"))
	image_filename = image_filename.replace(RS7ZoyGAq1c(u"ࠪࡠࡡ࠭ဳ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡡࡢ࡜࡝ࠩဴ")).replace(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠵࠯ࠨဵ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࠯࠰࠱࠲ࠫံ"))
	image_height = DkzsprAlwfGdgqHMhNtZvO5i6Rba(d0HDrq8Rtk16AlInw4TXb(u"ࠧࠨ့"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࠩး"),lh6URegmQNq8LWX0HaK5(u"္ࠩࠪ"),I89adFKf7CJ4BOQ,FbewQr7IVXqN0ijhOtm2vAnauzZT,profile,direction,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡇࡣ࡯ࡷࡪᜱ"),image_filename)
	bbSkQlgLOdyw9XvRVCZirh.show()
	bbSkQlgLOdyw9XvRVCZirh.getControl(OnvTrikzfEsY7qU8pgaRBtZy(u"࠺࠲࠸࠴ᘒ")).setHeight(image_height)
	bbSkQlgLOdyw9XvRVCZirh.getControl(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠻࠳࠹࠵ᘓ")).setImage(image_filename)
	jjDtkT6qOMFN8lzXieyvmQfEoLR9 = bbSkQlgLOdyw9XvRVCZirh.doModal()
	try: Dh9MOxeTj6FW.remove(image_filename)
	except: pass
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def W5h0lzIcY3gMqrZpb7C(vW4n87lAE53KHBLUsFjRIySV=aSf0iWG1kA7FsqjHbuC8NXB(u"ࡖࡵࡹࡪᜲ")):
	if vW4n87lAE53KHBLUsFjRIySV:
		Jhilqrw8nstB7 = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,LsG7EDcei1gMShH2aVOCo(u"ࠪࡷࡹࡸ်ࠧ"),hxSBTdGpyNVbfu4tr9(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧျ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨြ"))
		if Jhilqrw8nstB7: return Jhilqrw8nstB7
	FbewQr7IVXqN0ijhOtm2vAnauzZT = onweDvmTOUj(u"࠭ࠧွ")
	if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠳ᘔ") and Plx6mbKYD71aCsfTdukWy2Q.succeeded:
		mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
		PmtdDvIykT7qxfB = mmhS2KFYI4eC6HWgk1trq.count(d0HDrq8Rtk16AlInw4TXb(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨှ"))
		if PmtdDvIykT7qxfB>d0HDrq8Rtk16AlInw4TXb(u"࠼࠵ᘕ"):
			FbewQr7IVXqN0ijhOtm2vAnauzZT = SomeI8i56FaDMGPE.findall(RS7ZoyGAq1c(u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪဿ"),mmhS2KFYI4eC6HWgk1trq,SomeI8i56FaDMGPE.DOTALL)
			FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠵ᘖ")]
	if not FbewQr7IVXqN0ijhOtm2vAnauzZT:
		oLIiebAHlXa65 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,onweDvmTOUj(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ၀"),mtEXp14ijx(u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫ၁"))
		FbewQr7IVXqN0ijhOtm2vAnauzZT = open(oLIiebAHlXa65,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡷࡨࠧ၂")).read()
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.decode(Q2ZyGqCNYsftTc4MR7n(u"ࠬࡻࡴࡧ࠺ࠪ၃"))
		FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(Jbu2G0Qax8PYWpg(u"࠭࡜ࡳࠩ၄"),Sj1PYDmIpCUXO26(u"ࠧࠨ၅"))
	rsXW4JFgkpKHNzOu7UVn95jMGPaAI = SomeI8i56FaDMGPE.findall(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ၆"),FbewQr7IVXqN0ijhOtm2vAnauzZT,SomeI8i56FaDMGPE.DOTALL)
	OFHVZBY0Gq = []
	for DUaE01KxW4A9rtwTizg2OV in rsXW4JFgkpKHNzOu7UVn95jMGPaAI:
		mmQuO1adSbg968okchGeNHZl = DUaE01KxW4A9rtwTizg2OV.lower()
		if aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ၇") in mmQuO1adSbg968okchGeNHZl: continue
		if gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ၈") in mmQuO1adSbg968okchGeNHZl: continue
		if Q2ZyGqCNYsftTc4MR7n(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ၉") in mmQuO1adSbg968okchGeNHZl: continue
		if nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡩࡲࡰࡵࠪ၊") in mmQuO1adSbg968okchGeNHZl: continue
		OFHVZBY0Gq.append(DUaE01KxW4A9rtwTizg2OV)
	Jhilqrw8nstB7 = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(OFHVZBY0Gq,wKdxVbTc0X9NSiespM8OvHGUhf(u"࠷ᘗ"))
	Jhilqrw8nstB7 = Jhilqrw8nstB7[mtEXp14ijx(u"࠰ᘘ")]
	F4QxJHhsMj(qQ4BC6vW5YOfo,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ။"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ၌"),Jhilqrw8nstB7,jj0C6IlvPFh)
	return Jhilqrw8nstB7
def xxEnCy9DI0(zi68Y9T7ngdIXKALbv3fjVEeOJm=Q2ZyGqCNYsftTc4MR7n(u"ࠨࠩ၍")):
	if not zi68Y9T7ngdIXKALbv3fjVEeOJm: zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
	if zi68Y9T7ngdIXKALbv3fjVEeOJm!=hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ၎"): EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
	IozWafE1PiOCyMLjR = zi68Y9T7ngdIXKALbv3fjVEeOJm.splitlines()
	ESuf43dwJmkx1NtG = IozWafE1PiOCyMLjR[-QQSULIva4ljNO73mFcWw(u"࠲ᘙ")]
	cJr1KWzl05fAivbQLjTyPN = open(SSiIRuULQTe6taoBd,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡶࡧ࠭၏")).read()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: cJr1KWzl05fAivbQLjTyPN = cJr1KWzl05fAivbQLjTyPN.decode(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡺࡺࡦ࠹ࠩၐ"))
	cJr1KWzl05fAivbQLjTyPN = cJr1KWzl05fAivbQLjTyPN[-FZBX5WcC3msIDv4hobLd8(u"࠺࠳࠴࠵ᘚ"):]
	RFfh93jdt8ora = hxSBTdGpyNVbfu4tr9(u"ࠬࡃࠧၑ")*WWbmNvI40sM9Khlp25Ae(u"࠴࠴࠵ᘛ")
	if RFfh93jdt8ora in cJr1KWzl05fAivbQLjTyPN: cJr1KWzl05fAivbQLjTyPN = cJr1KWzl05fAivbQLjTyPN.rsplit(RFfh93jdt8ora,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵ᘜ"))[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵ᘜ")]
	if ESuf43dwJmkx1NtG in cJr1KWzl05fAivbQLjTyPN: cJr1KWzl05fAivbQLjTyPN = cJr1KWzl05fAivbQLjTyPN.rsplit(ESuf43dwJmkx1NtG,MOwK1lpyNfCgqksX3jhV(u"࠶ᘝ"))[eaF2N0jWLdvHIs8r(u"࠶ᘞ")]
	PapRrI6zEoVhdFfJNW4lbYm85euy = SomeI8i56FaDMGPE.findall(mtEXp14ijx(u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬၒ"),cJr1KWzl05fAivbQLjTyPN,SomeI8i56FaDMGPE.DOTALL)
	for d32l7Smpge1i5NnVcXOJoxMtwYZjCa,ucGVEfRSBY in reversed(PapRrI6zEoVhdFfJNW4lbYm85euy):
		if ucGVEfRSBY: break
	else: ucGVEfRSBY = Y5npATFarf1H9wBjc87(u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧၓ")
	upZ1BNCklGOvjiJ8Q,DUaE01KxW4A9rtwTizg2OV,cvbPywgE8x15NqieoSmRFK2 = MOwK1lpyNfCgqksX3jhV(u"ࠨࠩၔ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࠪၕ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࠫၖ")
	Kegr5N2EzTl08iucY = WWbmNvI40sM9Khlp25Ae(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၗ")+ESuf43dwJmkx1NtG
	AbaM4YmJZvf8V5hNL2jkd7nUogDXs = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၘ")+ucGVEfRSBY
	for ggxLs3QdhRwAFuU in reversed(IozWafE1PiOCyMLjR):
		if IPkQW7LojF3HO18V(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭ၙ") in ggxLs3QdhRwAFuU and OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ၚ") in ggxLs3QdhRwAFuU: break
	ggxLs3QdhRwAFuU = SomeI8i56FaDMGPE.findall(MOwK1lpyNfCgqksX3jhV(u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫၛ"),ggxLs3QdhRwAFuU,SomeI8i56FaDMGPE.DOTALL)
	if ggxLs3QdhRwAFuU:
		upZ1BNCklGOvjiJ8Q,DUaE01KxW4A9rtwTizg2OV,cvbPywgE8x15NqieoSmRFK2 = ggxLs3QdhRwAFuU[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠰ᘟ")]
		if B2vCEI9FAVP15R8eUbDJdySc(u"ࠩ࠲ࠫၜ") in upZ1BNCklGOvjiJ8Q: upZ1BNCklGOvjiJ8Q = upZ1BNCklGOvjiJ8Q.rsplit(eaF2N0jWLdvHIs8r(u"ࠪ࠳ࠬၝ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠲ᘠ"))[q6yUEoKVDb0fXmc8vhrMk7N(u"࠲ᘠ")]
		else: upZ1BNCklGOvjiJ8Q = upZ1BNCklGOvjiJ8Q.rsplit(lh6URegmQNq8LWX0HaK5(u"ࠫࡡࡢࠧၞ"),LsG7EDcei1gMShH2aVOCo(u"࠳ᘡ"))[LsG7EDcei1gMShH2aVOCo(u"࠳ᘡ")]
		qIhPeSam6KN0EZHpfyUBlCjd9LW1n = MOwK1lpyNfCgqksX3jhV(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨၟ")+upZ1BNCklGOvjiJ8Q
		BRgy8xjbEfCdhT4W2Lmzq9 = LsG7EDcei1gMShH2aVOCo(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၠ")+DUaE01KxW4A9rtwTizg2OV
		hBZwQP8jnGLJFObW = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫၡ")+cvbPywgE8x15NqieoSmRFK2
		bbGFjX9JChOciNq = qIhPeSam6KN0EZHpfyUBlCjd9LW1n+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨ࡞ࡱࠫၢ")+BRgy8xjbEfCdhT4W2Lmzq9+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࡟ࡲࠬၣ")+hBZwQP8jnGLJFObW+MOwK1lpyNfCgqksX3jhV(u"ࠪࡠࡳ࠭ၤ")+AbaM4YmJZvf8V5hNL2jkd7nUogDXs+B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡡࡴࠧၥ")+Kegr5N2EzTl08iucY
		DYmU41J0NGjAkhZdfvlO32p = BRgy8xjbEfCdhT4W2Lmzq9+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡢ࡮ࠨၦ")+AbaM4YmJZvf8V5hNL2jkd7nUogDXs+Q2ZyGqCNYsftTc4MR7n(u"࠭࡜࡯ࠩၧ")+Kegr5N2EzTl08iucY+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧ࡝ࡰࠪၨ")+qIhPeSam6KN0EZHpfyUBlCjd9LW1n+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨ࡞ࡱࠫၩ")+hBZwQP8jnGLJFObW
		sqockdvLWPJhmnDe5aCSG6Rr7 = BRgy8xjbEfCdhT4W2Lmzq9+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩ࡟ࡲࠬၪ")+Kegr5N2EzTl08iucY+NQ4hg16DPUxtOyo5iGb(u"ࠪࡠࡳ࠭ၫ")+qIhPeSam6KN0EZHpfyUBlCjd9LW1n+LsG7EDcei1gMShH2aVOCo(u"ࠫࡡࡴࠧၬ")+hBZwQP8jnGLJFObW
	else:
		qIhPeSam6KN0EZHpfyUBlCjd9LW1n,BRgy8xjbEfCdhT4W2Lmzq9,hBZwQP8jnGLJFObW = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭ၭ"),B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࠧၮ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨၯ")
		bbGFjX9JChOciNq = AbaM4YmJZvf8V5hNL2jkd7nUogDXs+IPkQW7LojF3HO18V(u"ࠨ࡞ࡱࡠࡳ࠭ၰ")+Kegr5N2EzTl08iucY
		DYmU41J0NGjAkhZdfvlO32p = AbaM4YmJZvf8V5hNL2jkd7nUogDXs+eaF2N0jWLdvHIs8r(u"ࠩ࡟ࡲࡡࡴࠧၱ")+Kegr5N2EzTl08iucY
		sqockdvLWPJhmnDe5aCSG6Rr7 = Kegr5N2EzTl08iucY
	JJYEV4vDIWPftljor369 = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧၲ")+QQSULIva4ljNO73mFcWw(u"ࠫࡡࡴࠧၳ")
	bhs5SyPzcla = ehEpy3JgW410OmiV5oz9M2H8RFNbka()
	imkzOjogBZS83q7MI496R = []
	rr60PDpqbMehZsYVuHmiAtN = bhs5SyPzcla[MOwK1lpyNfCgqksX3jhV(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၴ")]
	PoLp79UazRdOiCsGVJwmfZMW1vHBe = rlSHPhqT6UBnxLkMft0iWYspV(Y0Uhv2t8E67)
	if Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၵ") in list(bhs5SyPzcla.keys()):
		for fdk8NJMDbPh,pAYf09hxgcXVP3ZzlRSamLdQWEHDMU,irvwh35TtgqQUX7NCHGL1P in rr60PDpqbMehZsYVuHmiAtN: imkzOjogBZS83q7MI496R = max(imkzOjogBZS83q7MI496R,pAYf09hxgcXVP3ZzlRSamLdQWEHDMU)
		if PoLp79UazRdOiCsGVJwmfZMW1vHBe<imkzOjogBZS83q7MI496R:
			I89adFKf7CJ4BOQ = IPkQW7LojF3HO18V(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪၶ")
			DDZR5PlzeiyonWaCGfv67uqj2btEN = bxBWM9d53zOAcar(lh6URegmQNq8LWX0HaK5(u"ࠨࡴ࡬࡫࡭ࡺࠧၷ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭ၸ"),RS7ZoyGAq1c(u"ࠪฮาี๊ฬࠩၹ"),LsG7EDcei1gMShH2aVOCo(u"ࠫำื่อࠩၺ"),JJYEV4vDIWPftljor369+I89adFKf7CJ4BOQ,bbGFjX9JChOciNq)
			if DDZR5PlzeiyonWaCGfv67uqj2btEN==Rz34c0NP5BGo1WuTZxSfOKj(u"࠳ᘢ"):
				svOyXbipkwY = nEYJ5OCXG0gcNy(Sj1PYDmIpCUXO26(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၻ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ฮา๊ฯࠫၼ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧหฯา๎ะ࠭ၽ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩၾ"),I89adFKf7CJ4BOQ)
				if svOyXbipkwY==QQSULIva4ljNO73mFcWw(u"࠵ᘣ"): DDZR5PlzeiyonWaCGfv67uqj2btEN = QQSULIva4ljNO73mFcWw(u"࠵ᘣ")
			if DDZR5PlzeiyonWaCGfv67uqj2btEN==B2vCEI9FAVP15R8eUbDJdySc(u"࠶ᘤ"):
				import G4zaNTEvFt
				G4zaNTEvFt.wwnd49zbIZB(FZBX5WcC3msIDv4hobLd8(u"ࡗࡶࡺ࡫ᜳ"),FZBX5WcC3msIDv4hobLd8(u"ࡗࡶࡺ࡫ᜳ"))
			return
	ooyzJqBxRHOCi8mMWX = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࡯࡭ࡸࡺࠧၿ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ႀ"),eaF2N0jWLdvHIs8r(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭ႁ"))
	if not ooyzJqBxRHOCi8mMWX: ooyzJqBxRHOCi8mMWX = []
	DYmU41J0NGjAkhZdfvlO32p = DYmU41J0NGjAkhZdfvlO32p.replace(Sj1PYDmIpCUXO26(u"ࠬࡢ࡮ࠨႂ"),WWbmNvI40sM9Khlp25Ae(u"࠭࡜࡝ࡰࠪႃ")).replace(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧ࡜ࡔࡗࡐࡢ࠭ႄ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠩႅ")).replace(MOwK1lpyNfCgqksX3jhV(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬႆ"),WWbmNvI40sM9Khlp25Ae(u"ࠪࠫႇ")).replace(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ႈ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭ႉ"))
	sqockdvLWPJhmnDe5aCSG6Rr7 = sqockdvLWPJhmnDe5aCSG6Rr7.replace(WWbmNvI40sM9Khlp25Ae(u"࠭࡜࡯ࠩႊ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧ࡝࡞ࡱࠫႋ")).replace(d0HDrq8Rtk16AlInw4TXb(u"ࠨ࡝ࡕࡘࡑࡣࠧႌ"),lh6URegmQNq8LWX0HaK5(u"ႍࠩࠪ")).replace(Sj1PYDmIpCUXO26(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ႎ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࠬႏ")).replace(RS7ZoyGAq1c(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ႐"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠧ႑"))
	tbj1uMJzm60D4xUhpol3OH9fB = Y0Uhv2t8E67+Jbu2G0Qax8PYWpg(u"ࠧ࠻࠼ࠪ႒")+sqockdvLWPJhmnDe5aCSG6Rr7
	if tbj1uMJzm60D4xUhpol3OH9fB in ooyzJqBxRHOCi8mMWX:
		I89adFKf7CJ4BOQ = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭႓")
		ztgqWUaDpe8CE9N(MOwK1lpyNfCgqksX3jhV(u"ࠩࡵ࡭࡬࡮ࡴࠨ႔"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࠫ႕"),JJYEV4vDIWPftljor369+I89adFKf7CJ4BOQ,bbGFjX9JChOciNq)
		return
	bU50wFPOsXcnruRKa3817 = str(Qf8xsJSwoKaUNc).split(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫ࠳࠭႖"))[FZBX5WcC3msIDv4hobLd8(u"࠶ᘥ")]
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = ZEgwHfRnFV4[Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ႗")][hxSBTdGpyNVbfu4tr9(u"࠶ᘦ")]
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,Q2ZyGqCNYsftTc4MR7n(u"࠭ࡐࡐࡕࡗࠫ႘"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,WWbmNvI40sM9Khlp25Ae(u"ࠧࠨ႙"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩႚ"),RS7ZoyGAq1c(u"ࠩࠪႛ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࠫႜ"),Jbu2G0Qax8PYWpg(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬႝ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡊࡦࡲࡳࡦ᜴"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡊࡦࡲࡳࡦ᜴"))
	mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
	fQcD9nbSlVkaNIKH7B0A2uU1rjRpmJ = SomeI8i56FaDMGPE.findall(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ႞"),mmhS2KFYI4eC6HWgk1trq,SomeI8i56FaDMGPE.DOTALL)
	for UaDS9MFJ4H7Y0P,QQaAqDVXKSOgknG,PA0gGV4aQrHFd,yQpKG46x7DmBfwHRueZj in fQcD9nbSlVkaNIKH7B0A2uU1rjRpmJ:
		UaDS9MFJ4H7Y0P = UaDS9MFJ4H7Y0P.split(NQ4hg16DPUxtOyo5iGb(u"࠭ࠫࠨ႟"))
		PA0gGV4aQrHFd = PA0gGV4aQrHFd.split(gy9NA3CROZolfEt4vVzMr(u"ࠧࠬࠩႠ"))
		yQpKG46x7DmBfwHRueZj = yQpKG46x7DmBfwHRueZj.split(MOwK1lpyNfCgqksX3jhV(u"ࠨ࠭ࠪႡ"))
		if DUaE01KxW4A9rtwTizg2OV in UaDS9MFJ4H7Y0P and ESuf43dwJmkx1NtG==QQaAqDVXKSOgknG and Y0Uhv2t8E67 in PA0gGV4aQrHFd and bU50wFPOsXcnruRKa3817 in yQpKG46x7DmBfwHRueZj:
			I89adFKf7CJ4BOQ = IPkQW7LojF3HO18V(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧႢ")
			svOyXbipkwY = nEYJ5OCXG0gcNy(FZBX5WcC3msIDv4hobLd8(u"ࠪࡶ࡮࡭ࡨࡵࠩႣ"),lh6URegmQNq8LWX0HaK5(u"ࠫำื่อࠩႤ"),Sj1PYDmIpCUXO26(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩႥ"),JJYEV4vDIWPftljor369+I89adFKf7CJ4BOQ,bbGFjX9JChOciNq)
			if svOyXbipkwY==FZBX5WcC3msIDv4hobLd8(u"࠲ᘧ"): ztgqWUaDpe8CE9N(Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ⴆ"),d0HDrq8Rtk16AlInw4TXb(u"ࠧࠨႧ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠩႨ"),I89adFKf7CJ4BOQ)
			return
	I89adFKf7CJ4BOQ = Q2ZyGqCNYsftTc4MR7n(u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩႩ")
	ztgqWUaDpe8CE9N(LsG7EDcei1gMShH2aVOCo(u"ࠪࡶ࡮࡭ࡨࡵࠩႪ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨႫ"),JJYEV4vDIWPftljor369+I89adFKf7CJ4BOQ,bbGFjX9JChOciNq)
	svOyXbipkwY = nEYJ5OCXG0gcNy(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬႬ"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧႭ"),Y5npATFarf1H9wBjc87(u"ࠧࠨႮ"),FZBX5WcC3msIDv4hobLd8(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႯ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪႰ"))
	if svOyXbipkwY==Sj1PYDmIpCUXO26(u"࠳ᘨ"): fjrgCSVBFcNdAaoWMOv = FZBX5WcC3msIDv4hobLd8(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭Ⴑ")
	else:
		ztgqWUaDpe8CE9N(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႲ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠭Ⴓ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႴ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬႵ"))
		return
	RkL9ljZpIhdrutK0OmN7Uc = DYmU41J0NGjAkhZdfvlO32p
	from G4zaNTEvFt import sOki9wK4yjEg3oHa
	sycSign827ZrEldIB = sOki9wK4yjEg3oHa(MOwK1lpyNfCgqksX3jhV(u"ࠨࡇࡵࡶࡴࡸࡳࠨႶ"),RkL9ljZpIhdrutK0OmN7Uc,eaF2N0jWLdvHIs8r(u"࡙ࡸࡵࡦ᜵"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࠪႷ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪႸ"),fjrgCSVBFcNdAaoWMOv)
	if sycSign827ZrEldIB and fjrgCSVBFcNdAaoWMOv:
		ooyzJqBxRHOCi8mMWX.append(tbj1uMJzm60D4xUhpol3OH9fB)
		F4QxJHhsMj(qQ4BC6vW5YOfo,mtEXp14ijx(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧႹ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧႺ"),ooyzJqBxRHOCi8mMWX,bY2n5MtVA4cjpkFSxZ6K)
	return
def NowJe4Dfrx(oo76muA1GlEh9s0ZHNT4yMXQzipP):
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: oo76muA1GlEh9s0ZHNT4yMXQzipP = oo76muA1GlEh9s0ZHNT4yMXQzipP.encode(MOwK1lpyNfCgqksX3jhV(u"࠭ࡵࡵࡨ࠻ࠫႻ"))
	khUXCHlV1sPY0gevy = Q2ZyGqCNYsftTc4MR7n(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧႼ")+str(p1BoraOuWL.time())+Q2ZyGqCNYsftTc4MR7n(u"ࠨ࠰ࡧࡥࡹ࠭Ⴝ")
	open(khUXCHlV1sPY0gevy,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࡺࡦࠬႾ")).write(oo76muA1GlEh9s0ZHNT4yMXQzipP)
	return
def iFD752WvpSOGkxd6LlR0fZTQUb4CE(ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3):
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3:
		PPtQZgSW3H7pbKk5lhiV = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡰ࡮ࡹࡴࠨႿ"),Jbu2G0Qax8PYWpg(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧჀ"),Jbu2G0Qax8PYWpg(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨჁ"))
		if PPtQZgSW3H7pbKk5lhiV: return PPtQZgSW3H7pbKk5lhiV
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = ZEgwHfRnFV4[gy9NA3CROZolfEt4vVzMr(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭Ⴢ")][FZBX5WcC3msIDv4hobLd8(u"࠸ᘩ")]
	OjIPm0do31CZ = vT7q0oj96p(B2vCEI9FAVP15R8eUbDJdySc(u"࠷࠷ᘪ"),ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3)
	JDvtTgnMmr3GhfSLVoWzd9N = dNGVlWsQaB23Y4vtRZ70c()
	Jo8iROg3wQsBTMCjGz1hZAtpm = JDvtTgnMmr3GhfSLVoWzd9N.split(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧ࠭ࠩჃ"))[gy9NA3CROZolfEt4vVzMr(u"࠷ᘫ")]
	NeL59EbIAzM3 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧჄ"))
	SSIxOHeF0Y = xEv1tpZ0cFroC6NY8J()
	IWndjXJfpb1cCUP7RA2QrDLqEBt = {d0HDrq8Rtk16AlInw4TXb(u"ࠩࡸࡷࡪࡸࠧჅ"):OjIPm0do31CZ,MOwK1lpyNfCgqksX3jhV(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ჆"):Y0Uhv2t8E67,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬჇ"):Jo8iROg3wQsBTMCjGz1hZAtpm,Y5npATFarf1H9wBjc87(u"ࠬ࡯ࡤࡴࠩ჈"):QwCLPy3hNTm(SSIxOHeF0Y)}
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,IPkQW7LojF3HO18V(u"࠭ࡐࡐࡕࡗࠫ჉"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,IWndjXJfpb1cCUP7RA2QrDLqEBt,MOwK1lpyNfCgqksX3jhV(u"ࠧࠨ჊"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࠩ჋"),eaF2N0jWLdvHIs8r(u"ࠩࠪ჌"),FZBX5WcC3msIDv4hobLd8(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨჍ"))
	PPtQZgSW3H7pbKk5lhiV = []
	if Plx6mbKYD71aCsfTdukWy2Q.succeeded:
		mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
		PPtQZgSW3H7pbKk5lhiV = mmhS2KFYI4eC6HWgk1trq.replace(mtEXp14ijx(u"ࠫࡡࡢࡲࠨ჎"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡢ࡮ࠨ჏")).replace(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࡜࡝ࡰࠪა"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧ࡝ࡰࠪბ")).replace(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨ࡞ࡵࡠࡳ࠭გ"),WWbmNvI40sM9Khlp25Ae(u"ࠩ࡟ࡲࠬდ")).replace(LsG7EDcei1gMShH2aVOCo(u"ࠪࡠࡷ࠭ე"),RS7ZoyGAq1c(u"ࠫࡡࡴࠧვ"))
		PPtQZgSW3H7pbKk5lhiV = SomeI8i56FaDMGPE.findall(q6yUEoKVDb0fXmc8vhrMk7N(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨზ"),PPtQZgSW3H7pbKk5lhiV,SomeI8i56FaDMGPE.DOTALL)
		if PPtQZgSW3H7pbKk5lhiV:
			PPtQZgSW3H7pbKk5lhiV = sorted(PPtQZgSW3H7pbKk5lhiV,reverse=a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡌࡡ࡭ࡵࡨ᜶"),key=lambda key: int(key[LsG7EDcei1gMShH2aVOCo(u"࠶ᘬ")]))
			RGlxXTgCOBAseZ,OjIPm0do31CZ,rT84VWkePRZBIUab2oQn,j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP,rreason = PPtQZgSW3H7pbKk5lhiV[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠰ᘭ")]
			QV3Px2SGZJnL = rreason if tvwmlYcDnVybgPHKU84GOFI0uAq(wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬთ")) else rT84VWkePRZBIUab2oQn
			LCIFdjzi5kVmRwehouHQ.setSetting(Y5npATFarf1H9wBjc87(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩი"),QV3Px2SGZJnL)
			F4QxJHhsMj(qQ4BC6vW5YOfo,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫკ"),d0HDrq8Rtk16AlInw4TXb(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬლ"),PPtQZgSW3H7pbKk5lhiV,jj0C6IlvPFh)
			LCIFdjzi5kVmRwehouHQ.setSetting(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬმ"),QwCLPy3hNTm(CHhSItjbXy))
	return PPtQZgSW3H7pbKk5lhiV
def ms076oaLEyUPNXIHkTuBnWjipCeS8R(fJaoqEl9dID2Hr7ByZwVOk8stN,WGtjI842wsgq=FZBX5WcC3msIDv4hobLd8(u"࠱ᘮ"),udAtoYXBcUVvxi5MCyNzKDHT2m8nG=FZBX5WcC3msIDv4hobLd8(u"࠱ᘮ")):
	if WGtjI842wsgq and not udAtoYXBcUVvxi5MCyNzKDHT2m8nG: udAtoYXBcUVvxi5MCyNzKDHT2m8nG = len(fJaoqEl9dID2Hr7ByZwVOk8stN)//WGtjI842wsgq
	aj2GHIsFCJx8rUbTtg03dvADYPX6hN,jUSuZAztxy34TB5CIP2,G1GqcAg9EQrhXMdkDfwOW = [],-NQ4hg16DPUxtOyo5iGb(u"࠳ᘯ"),onweDvmTOUj(u"࠳ᘰ")
	for iJe1DukCLnsTtyRZp in fJaoqEl9dID2Hr7ByZwVOk8stN:
		if G1GqcAg9EQrhXMdkDfwOW%udAtoYXBcUVvxi5MCyNzKDHT2m8nG==Y5npATFarf1H9wBjc87(u"࠴ᘱ"):
			jUSuZAztxy34TB5CIP2 += gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶ᘲ")
			aj2GHIsFCJx8rUbTtg03dvADYPX6hN.append([])
		aj2GHIsFCJx8rUbTtg03dvADYPX6hN[jUSuZAztxy34TB5CIP2].append(iJe1DukCLnsTtyRZp)
		G1GqcAg9EQrhXMdkDfwOW += eaF2N0jWLdvHIs8r(u"࠷ᘳ")
	return aj2GHIsFCJx8rUbTtg03dvADYPX6hN
def Fs27fiZOpRlm5ENWLgu(khUXCHlV1sPY0gevy,oo76muA1GlEh9s0ZHNT4yMXQzipP):
	XR8BCkPdMhOY7y1VpWoNsuG = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,khUXCHlV1sPY0gevy)
	if QQSULIva4ljNO73mFcWw(u"࠱ᘴ") or mtEXp14ijx(u"ࠫࡎࡖࡔࡗࡡࠪნ") not in khUXCHlV1sPY0gevy or RS7ZoyGAq1c(u"ࠬࡓ࠳ࡖࡡࠪო") not in khUXCHlV1sPY0gevy: FbewQr7IVXqN0ijhOtm2vAnauzZT = str(oo76muA1GlEh9s0ZHNT4yMXQzipP)
	else:
		aj2GHIsFCJx8rUbTtg03dvADYPX6hN = ms076oaLEyUPNXIHkTuBnWjipCeS8R(oo76muA1GlEh9s0ZHNT4yMXQzipP,MOwK1lpyNfCgqksX3jhV(u"࠹ᘵ"))
		FbewQr7IVXqN0ijhOtm2vAnauzZT = lh6URegmQNq8LWX0HaK5(u"࠭ࠧპ")
		for gda062UFEH in aj2GHIsFCJx8rUbTtg03dvADYPX6hN:
			FbewQr7IVXqN0ijhOtm2vAnauzZT += str(gda062UFEH)+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ჟ")
		FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.strip(Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧრ"))
	ptuM3debrgNJ4 = oLY8VsFGH7NCfujRnEa5r.compress(FbewQr7IVXqN0ijhOtm2vAnauzZT)
	open(XR8BCkPdMhOY7y1VpWoNsuG,RS7ZoyGAq1c(u"ࠩࡺࡦࠬს")).write(ptuM3debrgNJ4)
	return
def Ae4OXdCtp1ioW(GasjKh87f3YMCeI,khUXCHlV1sPY0gevy):
	if GasjKh87f3YMCeI==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡨ࡮ࡩࡴࠨტ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = {}
	elif GasjKh87f3YMCeI==gy9NA3CROZolfEt4vVzMr(u"ࠫࡱ࡯ࡳࡵࠩუ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = []
	elif GasjKh87f3YMCeI==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡹࡴࡳࠩფ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = NQ4hg16DPUxtOyo5iGb(u"࠭ࠧქ")
	elif GasjKh87f3YMCeI==Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡪࡰࡷࠫღ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = Y5npATFarf1H9wBjc87(u"࠲ᘶ")
	else: oo76muA1GlEh9s0ZHNT4yMXQzipP = None
	XR8BCkPdMhOY7y1VpWoNsuG = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,khUXCHlV1sPY0gevy)
	ptuM3debrgNJ4 = open(XR8BCkPdMhOY7y1VpWoNsuG,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡴࡥࠫყ")).read()
	FbewQr7IVXqN0ijhOtm2vAnauzZT = oLY8VsFGH7NCfujRnEa5r.decompress(ptuM3debrgNJ4)
	if gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨშ") not in FbewQr7IVXqN0ijhOtm2vAnauzZT: oo76muA1GlEh9s0ZHNT4yMXQzipP = eval(FbewQr7IVXqN0ijhOtm2vAnauzZT)
	else:
		aj2GHIsFCJx8rUbTtg03dvADYPX6hN = FbewQr7IVXqN0ijhOtm2vAnauzZT.split(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩჩ"))
		del FbewQr7IVXqN0ijhOtm2vAnauzZT
		oo76muA1GlEh9s0ZHNT4yMXQzipP = []
		dwPORkhHtyi = jIoHl6d5pfVXu()
		RGlxXTgCOBAseZ = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠳ᘷ")
		for gda062UFEH in aj2GHIsFCJx8rUbTtg03dvADYPX6hN:
			dwPORkhHtyi.ppeLl851aw34zyqGMKmQOsVBFYPkA(str(RGlxXTgCOBAseZ),eval,gda062UFEH)
			RGlxXTgCOBAseZ += q6yUEoKVDb0fXmc8vhrMk7N(u"࠵ᘸ")
		del aj2GHIsFCJx8rUbTtg03dvADYPX6hN
		dwPORkhHtyi.hvl3ywiB0ugt2XbTLmk6fZcr()
		dwPORkhHtyi.Xs7m4RhoVbwx5ZtzI8LlBCe()
		JElwmSuZBpaOCn = list(dwPORkhHtyi.resultsDICT.keys())
		Upiys1QwY64 = sorted(JElwmSuZBpaOCn,reverse=WWbmNvI40sM9Khlp25Ae(u"ࡆࡢ࡮ࡶࡩ᜷"),key=lambda key: int(key))
		for RGlxXTgCOBAseZ in Upiys1QwY64:
			oo76muA1GlEh9s0ZHNT4yMXQzipP += dwPORkhHtyi.resultsDICT[RGlxXTgCOBAseZ]
	return oo76muA1GlEh9s0ZHNT4yMXQzipP
def bbY2Ui8zem6I(giwrh4jLPc):
	uWlXjhvCb7EJp = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,WWbmNvI40sM9Khlp25Ae(u"ࠫࡦࡪࡤࡰࡰࡶࠫც"),giwrh4jLPc,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨძ"))
	try: E3VQTp8NZmoe = open(uWlXjhvCb7EJp,Q2ZyGqCNYsftTc4MR7n(u"࠭ࡲࡣࠩწ")).read()
	except:
		PPL1UICXkroiBeMwQYpO = Dh9MOxeTj6FW.path.join(wCZNUYSm40Hrhv5oP,Q2ZyGqCNYsftTc4MR7n(u"ࠧࡢࡦࡧࡳࡳࡹࠧჭ"),giwrh4jLPc,QQSULIva4ljNO73mFcWw(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫხ"))
		try: E3VQTp8NZmoe = open(PPL1UICXkroiBeMwQYpO,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࡵࡦࠬჯ")).read()
		except: return S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࠫჰ"),[]
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: E3VQTp8NZmoe = E3VQTp8NZmoe.decode(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡺࡺࡦ࠹ࠩჱ"))
	nbOjUofFuz = SomeI8i56FaDMGPE.findall(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩჲ"),E3VQTp8NZmoe,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if not nbOjUofFuz: return a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠧჳ"),[]
	h9tOvg5pu3EYQTaVyWz,Ux3OWwoiymMeRbVL2lZhEP = nbOjUofFuz[QQSULIva4ljNO73mFcWw(u"࠵ᘹ")],rlSHPhqT6UBnxLkMft0iWYspV(nbOjUofFuz[QQSULIva4ljNO73mFcWw(u"࠵ᘹ")])
	return h9tOvg5pu3EYQTaVyWz,Ux3OWwoiymMeRbVL2lZhEP
def ehEpy3JgW410OmiV5oz9M2H8RFNbka():
	vWcmTgxtECNX2F = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡥ࡫ࡦࡸࠬჴ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫჵ"),FZBX5WcC3msIDv4hobLd8(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪჶ"))
	if vWcmTgxtECNX2F: return vWcmTgxtECNX2F
	bhs5SyPzcla,vWcmTgxtECNX2F = {},{}
	PapRrI6zEoVhdFfJNW4lbYm85euy = [ZEgwHfRnFV4[aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡖࡊࡖࡏࡔࠩჷ")][gy9NA3CROZolfEt4vVzMr(u"࠶ᘺ")]]
	if Qf8xsJSwoKaUNc>Q2ZyGqCNYsftTc4MR7n(u"࠲࠹࠱࠽࠾ᘼ"): PapRrI6zEoVhdFfJNW4lbYm85euy.append(ZEgwHfRnFV4[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡗࡋࡐࡐࡕࠪჸ")][gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠱ᘻ")])
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: PapRrI6zEoVhdFfJNW4lbYm85euy.append(ZEgwHfRnFV4[eaF2N0jWLdvHIs8r(u"ࠬࡘࡅࡑࡑࡖࠫჹ")][wKdxVbTc0X9NSiespM8OvHGUhf(u"࠴ᘽ")])
	for wMOb8NIrQq9RcCGpViP in PapRrI6zEoVhdFfJNW4lbYm85euy:
		Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,QQSULIva4ljNO73mFcWw(u"࠭ࡇࡆࡖࠪჺ"),wMOb8NIrQq9RcCGpViP,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࠨ჻"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩჼ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪჽ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠫჾ"),IPkQW7LojF3HO18V(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨჿ"))
		if Plx6mbKYD71aCsfTdukWy2Q.succeeded:
			mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
			zqJoAZ9VPwbatu7siFI4pLH8 = wMOb8NIrQq9RcCGpViP.rsplit(Jbu2G0Qax8PYWpg(u"ࠬ࠵ࠧᄀ"),QQSULIva4ljNO73mFcWw(u"࠴ᘾ"))[IPkQW7LojF3HO18V(u"࠴ᘿ")]
			FVf3mdgDYzR20MxSo9N4yr6B = SomeI8i56FaDMGPE.findall(MOwK1lpyNfCgqksX3jhV(u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᄁ"),mmhS2KFYI4eC6HWgk1trq,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
			for giwrh4jLPc,paRATl7yXODwkif0Ju in FVf3mdgDYzR20MxSo9N4yr6B:
				PPyimf7dbrAelKJTpg4a8q9HUzvXBh = zqJoAZ9VPwbatu7siFI4pLH8+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧ࠰ࠩᄂ")+giwrh4jLPc+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨ࠱ࠪᄃ")+giwrh4jLPc+B2vCEI9FAVP15R8eUbDJdySc(u"ࠩ࠰ࠫᄄ")+paRATl7yXODwkif0Ju+RS7ZoyGAq1c(u"ࠪ࠲ࡿ࡯ࡰࠨᄅ")
				if giwrh4jLPc not in list(bhs5SyPzcla.keys()):
					bhs5SyPzcla[giwrh4jLPc] = []
					vWcmTgxtECNX2F[giwrh4jLPc] = []
				wVd1MHzrPLA0YRux = rlSHPhqT6UBnxLkMft0iWYspV(paRATl7yXODwkif0Ju)
				bhs5SyPzcla[giwrh4jLPc].append((paRATl7yXODwkif0Ju,wVd1MHzrPLA0YRux,PPyimf7dbrAelKJTpg4a8q9HUzvXBh))
	for giwrh4jLPc in list(bhs5SyPzcla.keys()):
		vWcmTgxtECNX2F[giwrh4jLPc] = sorted(bhs5SyPzcla[giwrh4jLPc],reverse=MOwK1lpyNfCgqksX3jhV(u"ࡕࡴࡸࡩ᜸"),key=lambda key: key[onweDvmTOUj(u"࠶ᙀ")])
	F4QxJHhsMj(qQ4BC6vW5YOfo,RS7ZoyGAq1c(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄆ"),MOwK1lpyNfCgqksX3jhV(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ᄇ"),vWcmTgxtECNX2F,jj0C6IlvPFh)
	return vWcmTgxtECNX2F
def rlSHPhqT6UBnxLkMft0iWYspV(paRATl7yXODwkif0Ju):
	wVd1MHzrPLA0YRux = []
	irwPuXKA8xZeT = paRATl7yXODwkif0Ju.split(d0HDrq8Rtk16AlInw4TXb(u"࠭࠮ࠨᄈ"))
	for RzpSfwWMoND3UXlhG9ZnJe2 in irwPuXKA8xZeT:
		tD5ovMzSdjLxBP4QynliVOEAKW = SomeI8i56FaDMGPE.findall(IPkQW7LojF3HO18V(u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫᄉ"),RzpSfwWMoND3UXlhG9ZnJe2,SomeI8i56FaDMGPE.DOTALL)
		KcyYsJPRCZ3V = []
		for PPnCglVy4epdS2iXmht in tD5ovMzSdjLxBP4QynliVOEAKW:
			if PPnCglVy4epdS2iXmht.isdigit(): PPnCglVy4epdS2iXmht = int(PPnCglVy4epdS2iXmht)
			KcyYsJPRCZ3V.append(PPnCglVy4epdS2iXmht)
		wVd1MHzrPLA0YRux.append(KcyYsJPRCZ3V)
	return wVd1MHzrPLA0YRux
def Q9W3JVfALIrY4s7qSpGH(wVd1MHzrPLA0YRux):
	paRATl7yXODwkif0Ju = Jbu2G0Qax8PYWpg(u"ࠨࠩᄊ")
	for RzpSfwWMoND3UXlhG9ZnJe2 in wVd1MHzrPLA0YRux:
		for PPnCglVy4epdS2iXmht in RzpSfwWMoND3UXlhG9ZnJe2: paRATl7yXODwkif0Ju += str(PPnCglVy4epdS2iXmht)
		paRATl7yXODwkif0Ju += KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩ࠱ࠫᄋ")
	paRATl7yXODwkif0Ju = paRATl7yXODwkif0Ju.strip(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪ࠲ࠬᄌ"))
	return paRATl7yXODwkif0Ju
def mGk5l3R8KAPgZ7vyQ1rFNxUsT(llOADhoufJ):
	jcx62oQkzE5gIy = {}
	bhs5SyPzcla = ehEpy3JgW410OmiV5oz9M2H8RFNbka()
	bLauGzhFlVrgdR0xU3kHTBQ8 = BONw71npD8mETluiGLPkdZM6rS0zoC(llOADhoufJ)
	for giwrh4jLPc in llOADhoufJ:
		if giwrh4jLPc not in list(bhs5SyPzcla.keys()): continue
		vWcmTgxtECNX2F = bhs5SyPzcla[giwrh4jLPc]
		JyVfD4seCUq9,O9sUkGbIecLPrT5d,qqEfQzCNO3KJpu7iLeHd8FoTM = vWcmTgxtECNX2F[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠶ᙁ")]
		bbY4m9hSGQ3TFXg,fSqR6GPpTUFuIt48ZcgneB7Yi = bbY2Ui8zem6I(giwrh4jLPc)
		syBXTWJwnh7,j64jagcTHPLQN2m = bLauGzhFlVrgdR0xU3kHTBQ8[giwrh4jLPc]
		iXfJ57eqNzRdp3bFHK2t4CkrZ0MA = O9sUkGbIecLPrT5d>fSqR6GPpTUFuIt48ZcgneB7Yi and syBXTWJwnh7
		lSf5UiBMyzRED2nbPO7Ytpxdaw = aSf0iWG1kA7FsqjHbuC8NXB(u"ࡖࡵࡹࡪ᜹")
		if not syBXTWJwnh7: EEhw76zSm9n = onweDvmTOUj(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᄍ")
		elif not j64jagcTHPLQN2m: EEhw76zSm9n = onweDvmTOUj(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᄎ")
		elif iXfJ57eqNzRdp3bFHK2t4CkrZ0MA: EEhw76zSm9n = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࡯࡭ࡦࠪᄏ")
		else:
			EEhw76zSm9n = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࡨࡱࡲࡨࠬᄐ")
			lSf5UiBMyzRED2nbPO7Ytpxdaw = MOwK1lpyNfCgqksX3jhV(u"ࡉࡥࡱࡹࡥ᜺")
		jcx62oQkzE5gIy[giwrh4jLPc] = (lSf5UiBMyzRED2nbPO7Ytpxdaw,bbY4m9hSGQ3TFXg,fSqR6GPpTUFuIt48ZcgneB7Yi,JyVfD4seCUq9,O9sUkGbIecLPrT5d,EEhw76zSm9n,qqEfQzCNO3KJpu7iLeHd8FoTM)
	return jcx62oQkzE5gIy
def AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,AegqQIc06d,wU4aeuJpFr8CVfHdhBRIqb2vzSk7G=IPkQW7LojF3HO18V(u"ࠨࠩᄑ"),BRgy8xjbEfCdhT4W2Lmzq9=QQSULIva4ljNO73mFcWw(u"ࠩࠪᄒ"),UaDS9MFJ4H7Y0P=LsG7EDcei1gMShH2aVOCo(u"ࠪࠫᄓ")):
	if BhTAck1bPFYGuUqRW: IIheUfDrYngWFbdtjxvpPyN8.update(AegqQIc06d,wU4aeuJpFr8CVfHdhBRIqb2vzSk7G,BRgy8xjbEfCdhT4W2Lmzq9,UaDS9MFJ4H7Y0P)
	else: IIheUfDrYngWFbdtjxvpPyN8.update(AegqQIc06d,wU4aeuJpFr8CVfHdhBRIqb2vzSk7G+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡡࡴࠧᄔ")+BRgy8xjbEfCdhT4W2Lmzq9+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡢ࡮ࠨᄕ")+UaDS9MFJ4H7Y0P)
	return
def CVW8t72PJBfeiaTrxdNv0(H9fQyK5nmW8c4LgvpG7):
	def jpN5bMR97JTZYFustHe8km(CC8o27x9S4qBe0gAa5yMbvtGI,CAOVeJHpRqzgnx4MG,Gw7Pjl6fdsAREKbTCgN5q9va=MOwK1lpyNfCgqksX3jhV(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨᄖ")):
		return ((CC8o27x9S4qBe0gAa5yMbvtGI == Jbu2G0Qax8PYWpg(u"࠰ᙂ")) and Gw7Pjl6fdsAREKbTCgN5q9va[Jbu2G0Qax8PYWpg(u"࠰ᙂ")]) or (jpN5bMR97JTZYFustHe8km(CC8o27x9S4qBe0gAa5yMbvtGI // CAOVeJHpRqzgnx4MG, CAOVeJHpRqzgnx4MG, Gw7Pjl6fdsAREKbTCgN5q9va).lstrip(Gw7Pjl6fdsAREKbTCgN5q9va[Jbu2G0Qax8PYWpg(u"࠰ᙂ")]) + Gw7Pjl6fdsAREKbTCgN5q9va[CC8o27x9S4qBe0gAa5yMbvtGI % CAOVeJHpRqzgnx4MG])
	def ppxRaM8eUKDJ1PVfWNGE2QCb(L9LpnVFr4ThKBd7HqxvCGgUO0o, kP0sCD5ZML7viFtzIR8, g0gpLbIY2UnPud4WjsQKryM6wA, NXnEIuiTA0WoQz, A0evhaiRLw87DkBb=None, s8sD4OlCoeIjYg3hNbUX72Qa1=None, m6p1QdGBMTZVqOnik=None):
		while (g0gpLbIY2UnPud4WjsQKryM6wA):
			g0gpLbIY2UnPud4WjsQKryM6wA-=Rz34c0NP5BGo1WuTZxSfOKj(u"࠲ᙃ")
			if (NXnEIuiTA0WoQz[g0gpLbIY2UnPud4WjsQKryM6wA]): L9LpnVFr4ThKBd7HqxvCGgUO0o = SomeI8i56FaDMGPE.sub(Q2ZyGqCNYsftTc4MR7n(u"ࠢ࡝࡞ࡥࠦᄗ") + jpN5bMR97JTZYFustHe8km(g0gpLbIY2UnPud4WjsQKryM6wA, kP0sCD5ZML7viFtzIR8) + a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠣ࡞࡟ࡦࠧᄘ"),  NXnEIuiTA0WoQz[g0gpLbIY2UnPud4WjsQKryM6wA], L9LpnVFr4ThKBd7HqxvCGgUO0o)
		return L9LpnVFr4ThKBd7HqxvCGgUO0o
	H9fQyK5nmW8c4LgvpG7 = H9fQyK5nmW8c4LgvpG7.split(IPkQW7LojF3HO18V(u"ࠩࢀࠬࠬᄙ"))[RS7ZoyGAq1c(u"࠳ᙄ")]
	H9fQyK5nmW8c4LgvpG7 = H9fQyK5nmW8c4LgvpG7.rsplit(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪࡷࡵࡲࡩࡵࠩᄚ"))[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠳ᙅ")]+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠦࡸࡶ࡬ࡪࡶࠫࠫࢁ࠭ࠩࠪࠤᄛ")
	NTpDCUuRGVc = eval(NQ4hg16DPUxtOyo5iGb(u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭ᄜ")+H9fQyK5nmW8c4LgvpG7,{KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡢࡢࡵࡨࡒࠬᄝ"):jpN5bMR97JTZYFustHe8km,d0HDrq8Rtk16AlInw4TXb(u"ࠧࡶࡰࡳࡥࡨࡱࠧᄞ"):ppxRaM8eUKDJ1PVfWNGE2QCb})
	return NTpDCUuRGVc
def Uw5g8Pjhvxfs(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,m7rfEd2vOteonuqpH=gy9NA3CROZolfEt4vVzMr(u"ࠨࠩᄟ")):
	if m7rfEd2vOteonuqpH==onweDvmTOUj(u"ࠩ࡯ࡳࡼ࡫ࡲࠨᄠ"): xTFHrZ1nGWa9fdqsSA5y4htgJNmX = SomeI8i56FaDMGPE.sub(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪᄡ"),lambda x4sw1CfieHI: x4sw1CfieHI.group(eaF2N0jWLdvHIs8r(u"࠴ᙆ")).lower(),xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	elif m7rfEd2vOteonuqpH==onweDvmTOUj(u"ࠫࡺࡶࡰࡦࡴࠪᄢ"): xTFHrZ1nGWa9fdqsSA5y4htgJNmX = SomeI8i56FaDMGPE.sub(hxSBTdGpyNVbfu4tr9(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬᄣ"),lambda x4sw1CfieHI: x4sw1CfieHI.group(Q2ZyGqCNYsftTc4MR7n(u"࠵ᙇ")).upper(),xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	return xTFHrZ1nGWa9fdqsSA5y4htgJNmX
def BONw71npD8mETluiGLPkdZM6rS0zoC(llOADhoufJ):
	uuOinmyLKNY0texBkF2R3,RWCtJZhxruFMnVXzl2EdmoQB = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡊࡦࡲࡳࡦ᜻"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡊࡦࡲࡳࡦ᜻")
	Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(hvGPU2bmasopzFJxIEqfRYW41uQ6y)
	Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
	lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
	if len(llOADhoufJ)==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠷ᙈ"): EM5UWq26DSoZlbwr8a39JQPAtk41fF = lh6URegmQNq8LWX0HaK5(u"࠭ࠨࠣࠩᄤ")+llOADhoufJ[gy9NA3CROZolfEt4vVzMr(u"࠰ᙉ")]+d0HDrq8Rtk16AlInw4TXb(u"ࠧࠣࠫࠪᄥ")
	else: EM5UWq26DSoZlbwr8a39JQPAtk41fF = str(tuple(llOADhoufJ))
	lU7cFRC6jSwkVLTmIM.execute(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨᄦ")+EM5UWq26DSoZlbwr8a39JQPAtk41fF+mtEXp14ijx(u"ࠩࠣ࠿ࠬᄧ"))
	TiF5HCp4Zzf6ubclUONXI1AEL = lU7cFRC6jSwkVLTmIM.fetchall()
	bLauGzhFlVrgdR0xU3kHTBQ8 = {}
	for giwrh4jLPc in llOADhoufJ: bLauGzhFlVrgdR0xU3kHTBQ8[giwrh4jLPc] = (LsG7EDcei1gMShH2aVOCo(u"ࡋࡧ࡬ࡴࡧ᜼"),LsG7EDcei1gMShH2aVOCo(u"ࡋࡧ࡬ࡴࡧ᜼"))
	for giwrh4jLPc,RWCtJZhxruFMnVXzl2EdmoQB in TiF5HCp4Zzf6ubclUONXI1AEL:
		uuOinmyLKNY0texBkF2R3 = Q2ZyGqCNYsftTc4MR7n(u"࡚ࡲࡶࡧ᜽")
		RWCtJZhxruFMnVXzl2EdmoQB = RWCtJZhxruFMnVXzl2EdmoQB==mtEXp14ijx(u"࠲ᙊ")
		bLauGzhFlVrgdR0xU3kHTBQ8[giwrh4jLPc] = (uuOinmyLKNY0texBkF2R3,RWCtJZhxruFMnVXzl2EdmoQB)
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	return bLauGzhFlVrgdR0xU3kHTBQ8
def itTndG7sM4oAk90qEX83(upZ1BNCklGOvjiJ8Q):
	rr60PDpqbMehZsYVuHmiAtN = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࠫᄨ")
	if Dh9MOxeTj6FW.path.exists(upZ1BNCklGOvjiJ8Q):
		P8wc1gZWR7KV = open(upZ1BNCklGOvjiJ8Q,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡷࡨࠧᄩ")).read()
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: P8wc1gZWR7KV = P8wc1gZWR7KV.decode(onweDvmTOUj(u"ࠬࡻࡴࡧ࠺ࠪᄪ"))
		SsMl0xOyY6WZAVuX1hwp = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡤࡪࡥࡷࠫᄫ"),P8wc1gZWR7KV)
		if SsMl0xOyY6WZAVuX1hwp:
			rr60PDpqbMehZsYVuHmiAtN = {}
			for Y9orNmEJt8OWyM72vGafZleg5z4 in SsMl0xOyY6WZAVuX1hwp.keys():
				rr60PDpqbMehZsYVuHmiAtN[Y9orNmEJt8OWyM72vGafZleg5z4] = []
				for BWeP7RsfDkTL in SsMl0xOyY6WZAVuX1hwp[Y9orNmEJt8OWyM72vGafZleg5z4]:
					DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = Sj1PYDmIpCUXO26(u"ࠧࠨᄬ"),LsG7EDcei1gMShH2aVOCo(u"ࠨࠩᄭ"),Sj1PYDmIpCUXO26(u"ࠩࠪᄮ"),RS7ZoyGAq1c(u"ࠪࠫᄯ"),hxSBTdGpyNVbfu4tr9(u"ࠫࠬᄰ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠭ᄱ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࠧᄲ"),FZBX5WcC3msIDv4hobLd8(u"ࠧࠨᄳ"),IPkQW7LojF3HO18V(u"ࠨࠩᄴ")
					DQs7pSx58I4n = BWeP7RsfDkTL[Y5npATFarf1H9wBjc87(u"࠲ᙋ")]
					x0LXdHBFwj7EtMfu = BWeP7RsfDkTL[LsG7EDcei1gMShH2aVOCo(u"࠴ᙌ")]
					x0LXdHBFwj7EtMfu = JphHZ4KdkcF19vtoVlTYx5LPM(x0LXdHBFwj7EtMfu)
					xTFHrZ1nGWa9fdqsSA5y4htgJNmX = BWeP7RsfDkTL[gy9NA3CROZolfEt4vVzMr(u"࠶ᙍ")]
					h9h3xqMnC56kjUOKGgBbWQ4 = BWeP7RsfDkTL[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠸ᙎ")]
					NmX0ZP715phHsSiCzvxR3IB = BWeP7RsfDkTL[Y5npATFarf1H9wBjc87(u"࠺ᙏ")]
					SSGEc76fBan2 = BWeP7RsfDkTL[FZBX5WcC3msIDv4hobLd8(u"࠵ᙐ")]
					if len(BWeP7RsfDkTL)>nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠷ᙑ"): FbewQr7IVXqN0ijhOtm2vAnauzZT = BWeP7RsfDkTL[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠷ᙑ")]
					if len(BWeP7RsfDkTL)>gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠹ᙒ"): yboV6YS5n9WtE1arxOed = BWeP7RsfDkTL[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠹ᙒ")]
					if len(BWeP7RsfDkTL)>QQSULIva4ljNO73mFcWw(u"࠻ᙓ"): MIe5q0WmGnJF9wp2tfk = BWeP7RsfDkTL[QQSULIva4ljNO73mFcWw(u"࠻ᙓ")]
					if upZ1BNCklGOvjiJ8Q==YbTWJNjEGPC12RZzHioatgvu: hk4Tw3vj6PcaL = DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,gy9NA3CROZolfEt4vVzMr(u"ࠩࠪᄵ"),MIe5q0WmGnJF9wp2tfk
					else: hk4Tw3vj6PcaL = DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk
					rr60PDpqbMehZsYVuHmiAtN[Y9orNmEJt8OWyM72vGafZleg5z4].append(hk4Tw3vj6PcaL)
		fwvNpHLU8jziVcdKuSmQatAWrF = str(rr60PDpqbMehZsYVuHmiAtN)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: fwvNpHLU8jziVcdKuSmQatAWrF = fwvNpHLU8jziVcdKuSmQatAWrF.encode(RS7ZoyGAq1c(u"ࠪࡹࡹ࡬࠸ࠨᄶ"))
		open(upZ1BNCklGOvjiJ8Q,onweDvmTOUj(u"ࠫࡼࡨࠧᄷ")).write(fwvNpHLU8jziVcdKuSmQatAWrF)
	return rr60PDpqbMehZsYVuHmiAtN
def YfxSMg0mF9ZkoBthUHs3Rz6CaeO(yPRGDCnXhJbwYalz7fZepiUcA):
	DDnvU8oPNuBJ01ehMFdkLyxSHKO = yPRGDCnXhJbwYalz7fZepiUcA.split(MOwK1lpyNfCgqksX3jhV(u"ࠬ࠳ࠧᄸ"),Sj1PYDmIpCUXO26(u"࠵ᙔ"))[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠵ᙕ")]
	Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd = eaF2N0jWLdvHIs8r(u"࠭ࠧᄹ"),eaF2N0jWLdvHIs8r(u"ࠧࠨᄺ"),Y5npATFarf1H9wBjc87(u"ࠨࠩᄻ")
	if   DDnvU8oPNuBJ01ehMFdkLyxSHKO==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡄࡌ࡜ࡇࡋࠨᄼ")		:	from j7ZLMSmv4w			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==QQSULIva4ljNO73mFcWw(u"ࠪࡅࡐࡕࡁࡎࠩᄽ")		:	from xuBOFde24X			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==d0HDrq8Rtk16AlInw4TXb(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ᄾ")	:	from ChqefOL4Mn		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡇࡋࡘࡃࡐࠫᄿ")		:	from vfhp39d4er			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Q2ZyGqCNYsftTc4MR7n(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ᅀ")	:	from cBd1reQDjq			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==QQSULIva4ljNO73mFcWw(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩᅁ")	:	from acKn9I1HBV		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==LsG7EDcei1gMShH2aVOCo(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫᅂ")	: 	from YMZBptbgfC		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==RS7ZoyGAq1c(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫᅃ")	:	from MTGUFwWLXY		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨᅄ"):	from LEtrckHMKz	import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==MOwK1lpyNfCgqksX3jhV(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ᅅ")	:	from HBmivPUk2O		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==WWbmNvI40sM9Khlp25Ae(u"ࠬࡈࡏࡌࡔࡄࠫᅆ")		:	from dWvezyn71D			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==FZBX5WcC3msIDv4hobLd8(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ᅇ")	:	from EESoF8cn9d			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gy9NA3CROZolfEt4vVzMr(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨᅈ")	:	from vOpxrUYFyG		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨᅉ")	:	from yFBWmcKp2k			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==eaF2N0jWLdvHIs8r(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫᅊ")	:	from F4ZG65u8Dt		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᅋ"):	from adxJKPkW7Y	import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==onweDvmTOUj(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ᅌ"):		from XnEphROtxM		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧᅍ")	:	from wHGJb31Nsn		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==hxSBTdGpyNVbfu4tr9(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨᅎ")	:	from B6jExwRWqP		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᅏ")	:	from M9lTLt28So		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==IPkQW7LojF3HO18V(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩᅐ")	:	from QkSEbr6RM7		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==QQSULIva4ljNO73mFcWw(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧᅑ"):	from Y3jywo7Lua	import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==MOwK1lpyNfCgqksX3jhV(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫᅒ")	:	from vB7hFr6qwH		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬᅓ")	:	from rrwJN21upY		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᅔ")	:	from NT4RbrmaI5		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==RS7ZoyGAq1c(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨᅕ")	:	from E3jtTkvHVn		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩᅖ")	:	from DDwJuxKcqi		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==mtEXp14ijx(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪᅗ")	:	from xNDBjfpOeh		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪᅘ")	:	from y6de8biYgq		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪᅙ")	:	from K5ZxXC167D			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==MOwK1lpyNfCgqksX3jhV(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬᅚ")	:	from GHFRBa9spT		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨᅛ")	:	from g4OzlXIh9V		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==aSf0iWG1kA7FsqjHbuC8NXB(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᅜ")	:	from Jp96cr4yVB		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==LsG7EDcei1gMShH2aVOCo(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩᅝ")	:	from Air8LD14X5		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡈࡒࡗ࡙ࡇࠧᅞ")		:	from v3umM87oYB			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gy9NA3CROZolfEt4vVzMr(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫᅟ")	:	from TqzA2cb9Fh		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡍࡋࡏࡌࡎࠩᅠ")		:	from pQglzMi9ZS			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==IPkQW7LojF3HO18V(u"ࠫࡎࡖࡔࡗࠩᅡ")		:	from xTnWLMwOlD	import f8i6KDmBoAz as Nmq7bQ4yEIoaCM1u32hArxPkp,YnCWskJzK9IRacANQ0UgZ as RPSrjovJkFNiMEGOWIxUdu8lVp,T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==FZBX5WcC3msIDv4hobLd8(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨᅢ")	:	from gSKh6MiQ8e		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==d0HDrq8Rtk16AlInw4TXb(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨᅣ")	:	from ZEmdj2N85z		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Q2ZyGqCNYsftTc4MR7n(u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩᅤ")	:	from HDkQ23TwVc		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==WWbmNvI40sM9Khlp25Ae(u"ࠨࡎࡄࡖࡔࡠࡁࠨᅥ")	:	from B3GZSdnP6q			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪᅦ")	:	from OTbwzXCtuY		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡑ࠸࡛ࠧᅧ")		:	from oI5xiFN7h4	import f8i6KDmBoAz as Nmq7bQ4yEIoaCM1u32hArxPkp,YnCWskJzK9IRacANQ0UgZ as RPSrjovJkFNiMEGOWIxUdu8lVp,T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gy9NA3CROZolfEt4vVzMr(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫᅨ")	:	from rJCbLy7F40			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==eaF2N0jWLdvHIs8r(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬᅩ")	:	from oFz1gSBjXr			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡐࡂࡐࡈࡘࠬᅪ")		:	from cq8QVrWXTm			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==FZBX5WcC3msIDv4hobLd8(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᅫ")	:	from g3fxlLcTwp		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬᅬ"):	from aNEKUJgbPs		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬᅭ")	:	from l19akWUDfA		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==LsG7EDcei1gMShH2aVOCo(u"ࠪࡗࡍࡕࡆࡉࡃࠪᅮ")	:	from FeDQWiYyqn			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ᅯ")	:	from QOoVeYIPrS		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==Jbu2G0Qax8PYWpg(u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧᅰ")	:	from ZynRajS6D2		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==QQSULIva4ljNO73mFcWw(u"࠭ࡔࡗࡈࡘࡒࠬᅱ")		:	from z18cJRCTX5			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gy9NA3CROZolfEt4vVzMr(u"ࠧࡘࡇࡆࡍࡒࡇࠧᅲ")	:	from VxXWc4O2be			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࡛ࡄࡕࡔ࡚ࠧᅳ")		:	from JM0lSHOxe7			import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==lh6URegmQNq8LWX0HaK5(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪᅴ")	:	from tHSNcldqrQ		import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp,kV5Wue06vFixocBhPIZY9z as RPSrjovJkFNiMEGOWIxUdu8lVp,ToYWiIbruzUaNKRPZLG16cAj as IlVzmjAwygYQeK1LC2qFd
	elif DDnvU8oPNuBJ01ehMFdkLyxSHKO==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩᅵ"):	from DJpT2hU7ml	import De6s5ngUzirypRbLmKcdq as Nmq7bQ4yEIoaCM1u32hArxPkp
	return Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd
def rycVB75alp(IItzT2knpKVOevJylmdcACgZYoBL,eGxC8vzYKkT9Zw2,showDialogs):
	xrFqGMab4uLKZcS(lh6URegmQNq8LWX0HaK5(u"ࠫࡓࡕࡔࡊࡅࡈࠫᅶ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪᅷ")+IItzT2knpKVOevJylmdcACgZYoBL+q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩᅸ")+str(eGxC8vzYKkT9Zw2)+MOwK1lpyNfCgqksX3jhV(u"ࠧࠡ࡟ࠪᅹ"))
	IIheUfDrYngWFbdtjxvpPyN8 = AAGT9IPy4BoZN7()
	IIheUfDrYngWFbdtjxvpPyN8.create(QQSULIva4ljNO73mFcWw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅺ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫᅻ"))
	PHIz0DXOcLqFu = RS7ZoyGAq1c(u"࠷࠰࠳࠶ᙖ")*RS7ZoyGAq1c(u"࠷࠰࠳࠶ᙖ")
	ivk2cBLqsmTDanf3pY4NKwt6jM = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠱ᙗ")*PHIz0DXOcLqFu
	Plx6mbKYD71aCsfTdukWy2Q = UYkMoz0DGsTwIdKxnfS5ryR23Pp.get(IItzT2knpKVOevJylmdcACgZYoBL,stream=RS7ZoyGAq1c(u"ࡔࡳࡷࡨ᜾"),headers=eGxC8vzYKkT9Zw2)
	MGlE7zwxr2s04CFA = Plx6mbKYD71aCsfTdukWy2Q.headers
	Plx6mbKYD71aCsfTdukWy2Q.close()
	We7avNz4crxQ = bytes()
	if not MGlE7zwxr2s04CFA:
		if showDialogs: ztgqWUaDpe8CE9N(eaF2N0jWLdvHIs8r(u"ࠪࠫᅼ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࠬᅽ"),MOwK1lpyNfCgqksX3jhV(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅾ"),gy9NA3CROZolfEt4vVzMr(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩᅿ"))
		IIheUfDrYngWFbdtjxvpPyN8.close()
	else:
		if NQ4hg16DPUxtOyo5iGb(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᆀ") not in list(MGlE7zwxr2s04CFA.keys()): ISeRP6bFLHs0qWvz = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠱ᙘ")
		else: ISeRP6bFLHs0qWvz = int(MGlE7zwxr2s04CFA[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᆁ")])
		WFTvYhHQxK6542gc1qpNka = str(int(NQ4hg16DPUxtOyo5iGb(u"࠴࠴࠵࠶ᙚ")*ISeRP6bFLHs0qWvz/PHIz0DXOcLqFu)/RS7ZoyGAq1c(u"࠳࠳࠴࠵࠴࠰ᙙ"))
		SksqwzmpAvoVFDQ = int(ISeRP6bFLHs0qWvz/ivk2cBLqsmTDanf3pY4NKwt6jM)+wKdxVbTc0X9NSiespM8OvHGUhf(u"࠵ᙛ")
		if Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩᆂ") in list(MGlE7zwxr2s04CFA.keys()) and ISeRP6bFLHs0qWvz>PHIz0DXOcLqFu:
			I8ILjZdiBb5NaWotu9vclFpTRhAMJr = RS7ZoyGAq1c(u"ࡕࡴࡸࡩ᜿")
			Ez4Ivf2a670SAriotMPgOde = []
			rQROgc7iCu0d3SN6JlhkWbsIUmYZ = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠶࠶ᙜ")
			Ez4Ivf2a670SAriotMPgOde.append(str(OnvTrikzfEsY7qU8pgaRBtZy(u"࠰ᙞ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪ࠱ࠬᆃ")+str(Sj1PYDmIpCUXO26(u"࠷ᙝ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-Sj1PYDmIpCUXO26(u"࠷ᙝ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(wKdxVbTc0X9NSiespM8OvHGUhf(u"࠲ᙟ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫ࠲࠭ᆄ")+str(hxSBTdGpyNVbfu4tr9(u"࠴ᙠ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-wKdxVbTc0X9NSiespM8OvHGUhf(u"࠲ᙟ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(Rz34c0NP5BGo1WuTZxSfOKj(u"࠷ᙣ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬ࠳ࠧᆅ")+str(RS7ZoyGAq1c(u"࠷ᙢ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-LsG7EDcei1gMShH2aVOCo(u"࠴ᙡ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠳ᙥ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+IPkQW7LojF3HO18V(u"࠭࠭ࠨᆆ")+str(Sj1PYDmIpCUXO26(u"࠵ᙦ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-Rz34c0NP5BGo1WuTZxSfOKj(u"࠷ᙤ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(q6yUEoKVDb0fXmc8vhrMk7N(u"࠸ᙩ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧ࠮ࠩᆇ")+str(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠸ᙨ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠳ᙧ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(NQ4hg16DPUxtOyo5iGb(u"࠻ᙫ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+LsG7EDcei1gMShH2aVOCo(u"ࠨ࠯ࠪᆈ")+str(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠶ᙬ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-LsG7EDcei1gMShH2aVOCo(u"࠶ᙪ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(WWbmNvI40sM9Khlp25Ae(u"࠹ᙯ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+Q2ZyGqCNYsftTc4MR7n(u"ࠩ࠰ࠫᆉ")+str(onweDvmTOUj(u"࠹᙮")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-OnvTrikzfEsY7qU8pgaRBtZy(u"࠲᙭")))
			Ez4Ivf2a670SAriotMPgOde.append(str(RS7ZoyGAq1c(u"࠽ᙲ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+WWbmNvI40sM9Khlp25Ae(u"ࠪ࠱ࠬᆊ")+str(eaF2N0jWLdvHIs8r(u"࠽ᙱ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-OnvTrikzfEsY7qU8pgaRBtZy(u"࠵ᙰ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(gy9NA3CROZolfEt4vVzMr(u"࠹ᙴ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫ࠲࠭ᆋ")+str(Sj1PYDmIpCUXO26(u"࠹ᙳ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ-q6yUEoKVDb0fXmc8vhrMk7N(u"࠳ᙵ")))
			Ez4Ivf2a670SAriotMPgOde.append(str(LsG7EDcei1gMShH2aVOCo(u"࠼ᙶ")*ISeRP6bFLHs0qWvz//rQROgc7iCu0d3SN6JlhkWbsIUmYZ)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬ࠳ࠧᆌ"))
			I15QZ7vnV4UKqwMmcLWGt8goaARj = float(SksqwzmpAvoVFDQ)/rQROgc7iCu0d3SN6JlhkWbsIUmYZ
			vZpyaJHLtSKU6DkM8jQI2cW = I15QZ7vnV4UKqwMmcLWGt8goaARj/int(Sj1PYDmIpCUXO26(u"࠵ᙷ")+I15QZ7vnV4UKqwMmcLWGt8goaARj)
		else:
			I8ILjZdiBb5NaWotu9vclFpTRhAMJr = aSf0iWG1kA7FsqjHbuC8NXB(u"ࡈࡤࡰࡸ࡫ᝀ")
			rQROgc7iCu0d3SN6JlhkWbsIUmYZ = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠶ᙸ")
			vZpyaJHLtSKU6DkM8jQI2cW = hxSBTdGpyNVbfu4tr9(u"࠷ᙹ")
		xrFqGMab4uLKZcS(Jbu2G0Qax8PYWpg(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᆍ"),lh6URegmQNq8LWX0HaK5(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨᆎ")+str(I8ILjZdiBb5NaWotu9vclFpTRhAMJr)+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᆏ")+str(ISeRP6bFLHs0qWvz)+QQSULIva4ljNO73mFcWw(u"ࠩࠣࡡࠬᆐ"))
		jUSuZAztxy34TB5CIP2,w1gJBAPOZ3yijnaz2HVDuF = Jbu2G0Qax8PYWpg(u"࠰ᙺ"),Jbu2G0Qax8PYWpg(u"࠰ᙺ")
		for G1GqcAg9EQrhXMdkDfwOW in range(rQROgc7iCu0d3SN6JlhkWbsIUmYZ):
			mgDoj8ZAqe0uBLxP4Kzp = eGxC8vzYKkT9Zw2.copy()
			if I8ILjZdiBb5NaWotu9vclFpTRhAMJr: mgDoj8ZAqe0uBLxP4Kzp[Sj1PYDmIpCUXO26(u"ࠪࡖࡦࡴࡧࡦࠩᆑ")] = IPkQW7LojF3HO18V(u"ࠫࡧࡿࡴࡦࡵࡀࠫᆒ")+Ez4Ivf2a670SAriotMPgOde[G1GqcAg9EQrhXMdkDfwOW]
			Plx6mbKYD71aCsfTdukWy2Q = UYkMoz0DGsTwIdKxnfS5ryR23Pp.get(IItzT2knpKVOevJylmdcACgZYoBL,stream=FZBX5WcC3msIDv4hobLd8(u"ࡗࡶࡺ࡫ᝁ"),headers=mgDoj8ZAqe0uBLxP4Kzp,timeout=FZBX5WcC3msIDv4hobLd8(u"࠴࠲࠳ᙻ"))
			for JJl9ifowBhFINR80KDQPZetW in Plx6mbKYD71aCsfTdukWy2Q.iter_content(chunk_size=ivk2cBLqsmTDanf3pY4NKwt6jM):
				if IIheUfDrYngWFbdtjxvpPyN8.iscanceled():
					xrFqGMab4uLKZcS(FZBX5WcC3msIDv4hobLd8(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆓ"),B2vCEI9FAVP15R8eUbDJdySc(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ᆔ"))
					break
				jUSuZAztxy34TB5CIP2 += vZpyaJHLtSKU6DkM8jQI2cW
				We7avNz4crxQ += JJl9ifowBhFINR80KDQPZetW
				if not w1gJBAPOZ3yijnaz2HVDuF: w1gJBAPOZ3yijnaz2HVDuF = len(JJl9ifowBhFINR80KDQPZetW)
				if ISeRP6bFLHs0qWvz: AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,wKdxVbTc0X9NSiespM8OvHGUhf(u"࠳࠳࠴ᙼ")*jUSuZAztxy34TB5CIP2//SksqwzmpAvoVFDQ,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨᆕ"),str(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠴࠴࠵࠴࠰ᙽ")*w1gJBAPOZ3yijnaz2HVDuF*jUSuZAztxy34TB5CIP2//ivk2cBLqsmTDanf3pY4NKwt6jM//gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠴࠴࠵࠴࠰ᙽ"))+Q2ZyGqCNYsftTc4MR7n(u"ࠨࠢ࠲ࠤࠬᆖ")+WFTvYhHQxK6542gc1qpNka+NQ4hg16DPUxtOyo5iGb(u"ࠩࠣࡑࡇ࠭ᆗ"))
				else: AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,w1gJBAPOZ3yijnaz2HVDuF*jUSuZAztxy34TB5CIP2//ivk2cBLqsmTDanf3pY4NKwt6jM,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠨᆘ"),str(mtEXp14ijx(u"࠵࠵࠶࠮࠱ᙾ")*w1gJBAPOZ3yijnaz2HVDuF*jUSuZAztxy34TB5CIP2//ivk2cBLqsmTDanf3pY4NKwt6jM//mtEXp14ijx(u"࠵࠵࠶࠮࠱ᙾ"))+FZBX5WcC3msIDv4hobLd8(u"ࠫࠥࡓࡂࠨᆙ"))
			Plx6mbKYD71aCsfTdukWy2Q.close()
		IIheUfDrYngWFbdtjxvpPyN8.close()
		if len(We7avNz4crxQ)<ISeRP6bFLHs0qWvz and ISeRP6bFLHs0qWvz>Sj1PYDmIpCUXO26(u"࠵ᙿ"):
			xrFqGMab4uLKZcS(MOwK1lpyNfCgqksX3jhV(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆚ"),d0HDrq8Rtk16AlInw4TXb(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩᆛ")+str(len(We7avNz4crxQ)//PHIz0DXOcLqFu)+mtEXp14ijx(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬᆜ")+WFTvYhHQxK6542gc1qpNka+IPkQW7LojF3HO18V(u"ࠨࠢࡐࡆࠥࡣࠧᆝ"))
			DDZR5PlzeiyonWaCGfv67uqj2btEN = bxBWM9d53zOAcar(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪᆞ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪษ้เวย๋ࠢาึ๎ฬࠨᆟ"),QQSULIva4ljNO73mFcWw(u"ࠫฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠫᆠ"),Q2ZyGqCNYsftTc4MR7n(u"ࠬหูศัฬࠤั๊ศࠡษ็้้็ࠧᆡ"),Sj1PYDmIpCUXO26(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆢ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧโึ็ࠤๆ๐ࠠอๆหࠤฬ๊ๅๅใࠣࡠࡳࠦไๅลึๅࠥำฯฬࠢั฻ศࠦแ๋ࠢอั๊๐ไࠡษ็้้็ࠠ࡝ࡰࠣฮ๊ࠦฬๅสࠣࠫᆣ")+str(len(We7avNz4crxQ)//PHIz0DXOcLqFu)+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ่ࠢ๎฿อศศ์อࠤ๊์ࠠๆฮ่์฾ࠦࠧᆤ")+WFTvYhHQxK6542gc1qpNka+WWbmNvI40sM9Khlp25Ae(u"้ࠩࠣ๏เวษษํฮࠥࡢ࡮ࠡฮิฬࠥาไษࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠣࡠࡳࠦ็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠠภࠣࠤࠫᆥ"))
			if DDZR5PlzeiyonWaCGfv67uqj2btEN==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠸ "): We7avNz4crxQ = rycVB75alp(IItzT2knpKVOevJylmdcACgZYoBL,eGxC8vzYKkT9Zw2,showDialogs)
			elif DDZR5PlzeiyonWaCGfv67uqj2btEN==hxSBTdGpyNVbfu4tr9(u"࠱ᚁ"): xrFqGMab4uLKZcS(B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆦ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫ࠳ࠦࠠࡏࡱࡷࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡧࡣࡤࡧࡳࡸࡪࡪࠠࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡦࠪᆧ"))
			else: return RS7ZoyGAq1c(u"ࠬ࠭ᆨ")
			if not We7avNz4crxQ: return Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠧᆩ")
		else: xrFqGMab4uLKZcS(hxSBTdGpyNVbfu4tr9(u"ࠧࡏࡑࡗࡍࡈࡋࠧᆪ"),mtEXp14ijx(u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᆫ")+WFTvYhHQxK6542gc1qpNka+QQSULIva4ljNO73mFcWw(u"ࠩࠣࡑࡇࠦ࡝ࠨᆬ"))
	return We7avNz4crxQ
def DhZSdVFKc2X7Nf(HmvY29bj4dNgF7wZqr1lzkeQxiEasu):
	return Plx6mbKYD71aCsfTdukWy2Q
def dNGVlWsQaB23Y4vtRZ70c(ip=wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࠫᆭ")):
	nghk7Wp5bCw93ZoTPLU4scAIQ,Jo8iROg3wQsBTMCjGz1hZAtpm,KVnqJP4LkZ3jiucFQM8lxra,oxc9OgNe1zFQv3X,ZATDyev09mr4dqs,ejrlpVTQR0WHhCmUDJLyn = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࠬᆮ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬ࠭ᆯ"),RS7ZoyGAq1c(u"࠭ࠧᆰ"),Jbu2G0Qax8PYWpg(u"ࠧࠨᆱ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࠩᆲ"),Q2ZyGqCNYsftTc4MR7n(u"ࠩࠪᆳ")
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭ᆴ")+ip+Jbu2G0Qax8PYWpg(u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩᆵ")
	eGxC8vzYKkT9Zw2 = {eaF2N0jWLdvHIs8r(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᆶ"):d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧᆷ")}
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,Q2ZyGqCNYsftTc4MR7n(u"ࠧࡈࡇࡗࠫᆸ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,LsG7EDcei1gMShH2aVOCo(u"ࠨࠩᆹ"),eGxC8vzYKkT9Zw2,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪᆺ"),FZBX5WcC3msIDv4hobLd8(u"ࠪࠫᆻ"),RS7ZoyGAq1c(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧᆼ"))
	if not Plx6mbKYD71aCsfTdukWy2Q.succeeded: JDvtTgnMmr3GhfSLVoWzd9N = ip+QQSULIva4ljNO73mFcWw(u"ࠬ࠲ࠧᆽ")+nghk7Wp5bCw93ZoTPLU4scAIQ+RS7ZoyGAq1c(u"࠭ࠬࠨᆾ")+Jo8iROg3wQsBTMCjGz1hZAtpm+gy9NA3CROZolfEt4vVzMr(u"ࠧ࠭ࠩᆿ")+oxc9OgNe1zFQv3X+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࠮ࠪᇀ")+ZATDyev09mr4dqs+lh6URegmQNq8LWX0HaK5(u"ࠩ࠯ࠫᇁ")+ejrlpVTQR0WHhCmUDJLyn
	else:
		mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
		mmhS2KFYI4eC6HWgk1trq = SomeI8i56FaDMGPE.findall(Sj1PYDmIpCUXO26(u"ࠪࡠࢀ࠴ࠪࡀ࡞ࢀࡠࢂ࠭ᇂ"),mmhS2KFYI4eC6HWgk1trq,SomeI8i56FaDMGPE.DOTALL)
		if mmhS2KFYI4eC6HWgk1trq:
			mmhS2KFYI4eC6HWgk1trq = mmhS2KFYI4eC6HWgk1trq[q6yUEoKVDb0fXmc8vhrMk7N(u"࠱ᚂ")]
			QODtajlyikPB = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡩ࡯ࡣࡵࠩᇃ"),mmhS2KFYI4eC6HWgk1trq)
			BBaCwudlA9pbRENPIv3in2cOqsUMhK = list(QODtajlyikPB.keys())
			if IPkQW7LojF3HO18V(u"ࠬ࡯ࡰࠨᇄ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: ip = QODtajlyikPB[lh6URegmQNq8LWX0HaK5(u"࠭ࡩࡱࠩᇅ")]
			if eaF2N0jWLdvHIs8r(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪᇆ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: nghk7Wp5bCw93ZoTPLU4scAIQ = QODtajlyikPB[B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫᇇ")]
			if lh6URegmQNq8LWX0HaK5(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᇈ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: Jo8iROg3wQsBTMCjGz1hZAtpm = QODtajlyikPB[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᇉ")]
			if B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪᇊ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: KVnqJP4LkZ3jiucFQM8lxra = QODtajlyikPB[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫᇋ")]
			if eaF2N0jWLdvHIs8r(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ᇌ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: oxc9OgNe1zFQv3X = QODtajlyikPB[wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧᇍ")]
			if OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡥ࡬ࡸࡾ࠭ᇎ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK: ZATDyev09mr4dqs = QODtajlyikPB[QQSULIva4ljNO73mFcWw(u"ࠩࡦ࡭ࡹࡿࠧᇏ")]
			if aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬᇐ") in BBaCwudlA9pbRENPIv3in2cOqsUMhK:
				ejrlpVTQR0WHhCmUDJLyn = QODtajlyikPB[onweDvmTOUj(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ᇑ")][hxSBTdGpyNVbfu4tr9(u"ࠬࡻࡴࡤࠩᇒ")]
				if ejrlpVTQR0WHhCmUDJLyn[aSf0iWG1kA7FsqjHbuC8NXB(u"࠲ᚃ")] not in [IPkQW7LojF3HO18V(u"࠭࠭ࠨᇓ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࠬࠩᇔ")]: ejrlpVTQR0WHhCmUDJLyn = eaF2N0jWLdvHIs8r(u"ࠨ࠭ࠪᇕ")+ejrlpVTQR0WHhCmUDJLyn
			JDvtTgnMmr3GhfSLVoWzd9N = ip+Q2ZyGqCNYsftTc4MR7n(u"ࠩ࠯ࠫᇖ")+nghk7Wp5bCw93ZoTPLU4scAIQ+eaF2N0jWLdvHIs8r(u"ࠪ࠰ࠬᇗ")+Jo8iROg3wQsBTMCjGz1hZAtpm+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫ࠱࠭ᇘ")+oxc9OgNe1zFQv3X+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬ࠲ࠧᇙ")+ZATDyev09mr4dqs+Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠬࠨᇚ")+ejrlpVTQR0WHhCmUDJLyn
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: JDvtTgnMmr3GhfSLVoWzd9N = JDvtTgnMmr3GhfSLVoWzd9N.encode(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡶࡶࡩ࠼ࠬᇛ")).decode(FZBX5WcC3msIDv4hobLd8(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩᇜ"))
	JDvtTgnMmr3GhfSLVoWzd9N = c8Fvb4IfHW9XkG1mLK5Z(JDvtTgnMmr3GhfSLVoWzd9N)
	return JDvtTgnMmr3GhfSLVoWzd9N
def Xj2G0VZ876Idy(i3RwaYDZdtubAy):
	JqZMsmjXz4T1BWFcGVgO0Rr,showDialogs = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪᇝ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡘࡷࡻࡥᝂ")
	if i3RwaYDZdtubAy.count(RS7ZoyGAq1c(u"ࠪࡣࠬᇞ"))>=FZBX5WcC3msIDv4hobLd8(u"࠵ᚄ"):
		i3RwaYDZdtubAy,JqZMsmjXz4T1BWFcGVgO0Rr = i3RwaYDZdtubAy.split(hxSBTdGpyNVbfu4tr9(u"ࠫࡤ࠭ᇟ"),gy9NA3CROZolfEt4vVzMr(u"࠵ᚅ"))
		JqZMsmjXz4T1BWFcGVgO0Rr = mtEXp14ijx(u"ࠬࡥࠧᇠ")+JqZMsmjXz4T1BWFcGVgO0Rr
		if WWbmNvI40sM9Khlp25Ae(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫᇡ") in JqZMsmjXz4T1BWFcGVgO0Rr: showDialogs = LsG7EDcei1gMShH2aVOCo(u"ࡋࡧ࡬ࡴࡧᝃ")
		else: showDialogs = RS7ZoyGAq1c(u"࡚ࡲࡶࡧᝄ")
	return i3RwaYDZdtubAy,JqZMsmjXz4T1BWFcGVgO0Rr,showDialogs
def xEv1tpZ0cFroC6NY8J():
	NeL59EbIAzM3 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,FZBX5WcC3msIDv4hobLd8(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᇢ"))
	SSIxOHeF0Y = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠵ᚆ")
	if Dh9MOxeTj6FW.path.exists(NeL59EbIAzM3):
		for khUXCHlV1sPY0gevy in Dh9MOxeTj6FW.listdir(NeL59EbIAzM3):
			if mtEXp14ijx(u"ࠨ࠰ࡳࡽࡴ࠭ᇣ") in khUXCHlV1sPY0gevy: continue
			if WWbmNvI40sM9Khlp25Ae(u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧᇤ") in khUXCHlV1sPY0gevy: continue
			jcBsZavptIGEAC = Dh9MOxeTj6FW.path.join(NeL59EbIAzM3,khUXCHlV1sPY0gevy)
			VjkbN2rgJM7C3RX,PmtdDvIykT7qxfB = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(jcBsZavptIGEAC)
			SSIxOHeF0Y += VjkbN2rgJM7C3RX
	return SSIxOHeF0Y
def JoTFl8d72rKjpI0NY6x(ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3,showDialogs):
	xzIrWbct7smF4y = LCIFdjzi5kVmRwehouHQ.getSetting(NQ4hg16DPUxtOyo5iGb(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨᇥ"))
	r4rqUbZFoCOR1dKet = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡸࡺࡲࠨᇦ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᇧ"),Y5npATFarf1H9wBjc87(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᇨ"))
	AAohB91sTn2cGluX6ig0bPZNe,txfbVz0L4mDZCpNPkj = xzIrWbct7smF4y,r4rqUbZFoCOR1dKet
	b2N8faHvRlqsroMI,MZchIJ23D50bEm8 = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࠨᇩ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩᇪ")
	if not ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 or not r4rqUbZFoCOR1dKet or xzIrWbct7smF4y in [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪᇫ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡉࡗࡘࡏࡓࠩᇬ")]:
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX = ZEgwHfRnFV4[mtEXp14ijx(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᇭ")][mtEXp14ijx(u"࠹ᚇ")]
		OjIPm0do31CZ = vT7q0oj96p(QQSULIva4ljNO73mFcWw(u"࠳࠳ᚈ"),ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3)
		JDvtTgnMmr3GhfSLVoWzd9N = dNGVlWsQaB23Y4vtRZ70c()
		Jo8iROg3wQsBTMCjGz1hZAtpm = JDvtTgnMmr3GhfSLVoWzd9N.split(Y5npATFarf1H9wBjc87(u"ࠬ࠲ࠧᇮ"))[Sj1PYDmIpCUXO26(u"࠳ᚉ")]
		SSIxOHeF0Y = xEv1tpZ0cFroC6NY8J()
		IWndjXJfpb1cCUP7RA2QrDLqEBt = {KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡵࡴࡧࡵࠫᇯ"):OjIPm0do31CZ,hxSBTdGpyNVbfu4tr9(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨᇰ"):Y0Uhv2t8E67,QQSULIva4ljNO73mFcWw(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᇱ"):Jo8iROg3wQsBTMCjGz1hZAtpm,hxSBTdGpyNVbfu4tr9(u"ࠩ࡬ࡨࡸ࠭ᇲ"):QwCLPy3hNTm(SSIxOHeF0Y)}
		Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,WWbmNvI40sM9Khlp25Ae(u"ࠪࡔࡔ࡙ࡔࠨᇳ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,IWndjXJfpb1cCUP7RA2QrDLqEBt,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࠬᇴ"),mtEXp14ijx(u"ࠬ࠭ᇵ"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠧᇶ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫᇷ"))
		if not Plx6mbKYD71aCsfTdukWy2Q.succeeded: AAohB91sTn2cGluX6ig0bPZNe = Jbu2G0Qax8PYWpg(u"ࠨࡇࡕࡖࡔࡘࠧᇸ")
		else:
			OdhVRnmIr7LZ4xe6N3XvpPFCHg = Plx6mbKYD71aCsfTdukWy2Q.content
			OdhVRnmIr7LZ4xe6N3XvpPFCHg = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩ࡯࡭ࡸࡺࠧᇹ"),OdhVRnmIr7LZ4xe6N3XvpPFCHg)
			OdhVRnmIr7LZ4xe6N3XvpPFCHg = sorted(OdhVRnmIr7LZ4xe6N3XvpPFCHg,reverse=QQSULIva4ljNO73mFcWw(u"ࡔࡳࡷࡨᝅ"),key=lambda key: int(key[gy9NA3CROZolfEt4vVzMr(u"࠲ᚊ")]))
			MZchIJ23D50bEm8,txfbVz0L4mDZCpNPkj = IPkQW7LojF3HO18V(u"ࠪࠫᇺ"),LsG7EDcei1gMShH2aVOCo(u"ࠫࠬᇻ")
			for gNZ7j5iahBlLUGYH63mn0T1pxREyeW,bckS2lAUXqyoZxWNrdK5Op9P,RkL9ljZpIhdrutK0OmN7Uc in OdhVRnmIr7LZ4xe6N3XvpPFCHg:
				if gNZ7j5iahBlLUGYH63mn0T1pxREyeW==Sj1PYDmIpCUXO26(u"ࠬ࠶ࠧᇼ"):
					MZchIJ23D50bEm8 += RkL9ljZpIhdrutK0OmN7Uc+d0HDrq8Rtk16AlInw4TXb(u"࠭࠺࠻ࠩᇽ")
					continue
				if txfbVz0L4mDZCpNPkj: txfbVz0L4mDZCpNPkj += FZBX5WcC3msIDv4hobLd8(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨᇾ")
				QPDUm4s92C = RkL9ljZpIhdrutK0OmN7Uc.split(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨ࡞ࡱࠫᇿ"))[FZBX5WcC3msIDv4hobLd8(u"࠳ᚋ")]
				Cb8tNQ4aRSu2 = B2vCEI9FAVP15R8eUbDJdySc(u"ࠩิืฬ๊ษࠡะสูฮࠦไไࠢไๆ฼࠭ሀ") if bckS2lAUXqyoZxWNrdK5Op9P else a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࠫሁ")
				txfbVz0L4mDZCpNPkj += RkL9ljZpIhdrutK0OmN7Uc.replace(QPDUm4s92C,lh6URegmQNq8LWX0HaK5(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧሂ")+QPDUm4s92C+Cb8tNQ4aRSu2+WWbmNvI40sM9Khlp25Ae(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧሃ"))+FZBX5WcC3msIDv4hobLd8(u"࠭࡜࡯ࠩሄ")
			txfbVz0L4mDZCpNPkj = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧ࡝ࡰࠪህ")+txfbVz0L4mDZCpNPkj+hxSBTdGpyNVbfu4tr9(u"ࠨ࡞ࡱࡠࡳ࠭ሆ")
			MZchIJ23D50bEm8 = MZchIJ23D50bEm8.strip(Sj1PYDmIpCUXO26(u"ࠩ࠽࠾ࠬሇ"))
			b2N8faHvRlqsroMI = LCIFdjzi5kVmRwehouHQ.getSetting(NQ4hg16DPUxtOyo5iGb(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬለ"))
			if txfbVz0L4mDZCpNPkj!=r4rqUbZFoCOR1dKet or xzIrWbct7smF4y in [gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࠬሉ"),LsG7EDcei1gMShH2aVOCo(u"ࠬࡋࡒࡓࡑࡕࠫሊ")]: AAohB91sTn2cGluX6ig0bPZNe = RS7ZoyGAq1c(u"࠭ࡎࡆ࡙ࠪላ")
			F4QxJHhsMj(qQ4BC6vW5YOfo,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪሌ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪል"),txfbVz0L4mDZCpNPkj,bY2n5MtVA4cjpkFSxZ6K)
			LCIFdjzi5kVmRwehouHQ.setSetting(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶࠫሎ"),MZchIJ23D50bEm8)
			LCIFdjzi5kVmRwehouHQ.setSetting(gy9NA3CROZolfEt4vVzMr(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫሏ"),QwCLPy3hNTm(CHhSItjbXy))
	if showDialogs:
		if AAohB91sTn2cGluX6ig0bPZNe==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡊࡘࡒࡐࡔࠪሐ"):
			ztgqWUaDpe8CE9N(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠭ሑ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠧሒ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪሓ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨሔ"))
		else:
			DPfOyNk6YarWmFKU2ezZlAiG(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡵ࡭࡬࡮ࡴࠨሕ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭ሖ"),txfbVz0L4mDZCpNPkj,gy9NA3CROZolfEt4vVzMr(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬሗ"))
			AAohB91sTn2cGluX6ig0bPZNe = FZBX5WcC3msIDv4hobLd8(u"ࠬࡕࡌࡅࠩመ")
	if AAohB91sTn2cGluX6ig0bPZNe!=xzIrWbct7smF4y:
		LCIFdjzi5kVmRwehouHQ.setSetting(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫሙ"),AAohB91sTn2cGluX6ig0bPZNe)
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(QQSULIva4ljNO73mFcWw(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫሚ"))
	wwPFYEbqCt = lh6URegmQNq8LWX0HaK5(u"ࡖࡵࡹࡪᝇ") if MZchIJ23D50bEm8!=b2N8faHvRlqsroMI else Y5npATFarf1H9wBjc87(u"ࡇࡣ࡯ࡷࡪᝆ")
	return wwPFYEbqCt
def N1NR5zebmAEyxPQ97l(XXfrWZnRsmx47VOwcLe,K5MukmIpEfvJV9jLTgB):
	from socket import socket as g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS,AF_INET as A63OvTSBM5xduK4m8yorhjPYqw,SOCK_STREAM as Zm7N6Rv39POxEg8jQnpoKHzlD12G
	SSroljfb3u = g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS(A63OvTSBM5xduK4m8yorhjPYqw,Zm7N6Rv39POxEg8jQnpoKHzlD12G)
	SSroljfb3u.settimeout(aSf0iWG1kA7FsqjHbuC8NXB(u"࠵ᚌ"))
	SSP1lDkxZjzm2t,OAZYz8gT2knR4D1t = QQSULIva4ljNO73mFcWw(u"ࡗࡶࡺ࡫ᝈ"),onweDvmTOUj(u"࠵ᚍ")
	mlKGZXF5ybUTOrQNMua = p1BoraOuWL.time()
	try: SSroljfb3u.connect((XXfrWZnRsmx47VOwcLe,K5MukmIpEfvJV9jLTgB))
	except: SSP1lDkxZjzm2t = IPkQW7LojF3HO18V(u"ࡊࡦࡲࡳࡦᝉ")
	k3s1pEmCLF7dIzV5MZeGvO = p1BoraOuWL.time()
	if SSP1lDkxZjzm2t: OAZYz8gT2knR4D1t = k3s1pEmCLF7dIzV5MZeGvO-mlKGZXF5ybUTOrQNMua
	return OAZYz8gT2knR4D1t
def W2sm89LliTnf(showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(Y5npATFarf1H9wBjc87(u"ࠨࠩማ"),eaF2N0jWLdvHIs8r(u"ࠩࠪሜ"),onweDvmTOUj(u"ࠪࠫም"),Y5npATFarf1H9wBjc87(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሞ"),lh6URegmQNq8LWX0HaK5(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫሟ"))
	else: svOyXbipkwY = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࡙ࡸࡵࡦᝊ")
	if svOyXbipkwY==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠷ᚎ"):
		for khUXCHlV1sPY0gevy in Dh9MOxeTj6FW.listdir(Vd1J5lD9uAsMUoXW):
			if khUXCHlV1sPY0gevy.endswith(Jbu2G0Qax8PYWpg(u"࠭࠮ࡥࡤࠪሠ")) and WWbmNvI40sM9Khlp25Ae(u"ࠧࡥࡣࡷࡥࠬሡ") in khUXCHlV1sPY0gevy:
				wl4oO8z5SgGnF3HJEDjbUh = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,khUXCHlV1sPY0gevy)
				try: Iof8U0xDKbVslWATpzR4OvBe9,lU7cFRC6jSwkVLTmIM = NLCg4kvQr2Yz8Bue3dhXwA(wl4oO8z5SgGnF3HJEDjbUh)
				except: return
				lU7cFRC6jSwkVLTmIM.execute(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡱࡸࡪ࡭ࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭࠾ࠫሢ"))
				lU7cFRC6jSwkVLTmIM.execute(IPkQW7LojF3HO18V(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡲࡴࡹ࡯࡭ࡪࡼࡨ࠿ࠬሣ"))
				lU7cFRC6jSwkVLTmIM.execute(B2vCEI9FAVP15R8eUbDJdySc(u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫሤ"))
				Iof8U0xDKbVslWATpzR4OvBe9.commit()
				Iof8U0xDKbVslWATpzR4OvBe9.close()
		if showDialogs:
			ztgqWUaDpe8CE9N(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࠬሥ"),mtEXp14ijx(u"ࠬ࠭ሦ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩሧ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨረ"))
	return
def PPEIqwl1Hk7nJKre(rkVAOsDqRlyLHtJMwc3UKQ,R2B4vngqKZrCiuyzaSQ0d,showDialogs):
	if rkVAOsDqRlyLHtJMwc3UKQ!=None:
		global SWTM0ljAcO6KYZVa
		SWTM0ljAcO6KYZVa = rkVAOsDqRlyLHtJMwc3UKQ
	if R2B4vngqKZrCiuyzaSQ0d!=None:
		global dV6Jtnobaj3sByrS7u1ei
		dV6Jtnobaj3sByrS7u1ei = R2B4vngqKZrCiuyzaSQ0d
	if showDialogs!=None:
		global fgDRq7naN4lmAuVzpoZ
		fgDRq7naN4lmAuVzpoZ = showDialogs
	return
SWTM0ljAcO6KYZVa,dV6Jtnobaj3sByrS7u1ei,fgDRq7naN4lmAuVzpoZ = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩሩ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࠪሪ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠫራ")
def K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,ucGVEfRSBY,GrW7YhVIBTu=Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࠬሬ"),Nu5VfTLAMGnKbPD7kJzXWY=IPkQW7LojF3HO18V(u"ࠬ࠭ር")):
	global ZEgwHfRnFV4
	if showDialogs==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠧሮ"): showDialogs = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࡚ࡲࡶࡧᝋ") if fgDRq7naN4lmAuVzpoZ==FZBX5WcC3msIDv4hobLd8(u"ࠧࠨሯ") else fgDRq7naN4lmAuVzpoZ
	if Nu5VfTLAMGnKbPD7kJzXWY==eaF2N0jWLdvHIs8r(u"ࠨࠩሰ"): Nu5VfTLAMGnKbPD7kJzXWY = RS7ZoyGAq1c(u"ࡔࡳࡷࡨᝌ") if dV6Jtnobaj3sByrS7u1ei==B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࠪሱ") else dV6Jtnobaj3sByrS7u1ei
	if GrW7YhVIBTu==RS7ZoyGAq1c(u"ࠪࠫሲ"): GrW7YhVIBTu = gy9NA3CROZolfEt4vVzMr(u"ࡕࡴࡸࡩᝍ") if SWTM0ljAcO6KYZVa==Y5npATFarf1H9wBjc87(u"ࠫࠬሳ") else SWTM0ljAcO6KYZVa
	if ZP8LaN3fjk1HvoUFJspG==LsG7EDcei1gMShH2aVOCo(u"ࠬ࠭ሴ"): IeWHCsBh2LG43xmwKU = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡖࡵࡹࡪᝎ")
	else: IeWHCsBh2LG43xmwKU = ZP8LaN3fjk1HvoUFJspG
	if oo76muA1GlEh9s0ZHNT4yMXQzipP==None: ZZm1hsDV9ba = None
	elif oo76muA1GlEh9s0ZHNT4yMXQzipP==Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠧስ"): ZZm1hsDV9ba = {}
	else: ZZm1hsDV9ba = oo76muA1GlEh9s0ZHNT4yMXQzipP
	if eGxC8vzYKkT9Zw2==None: mgDoj8ZAqe0uBLxP4Kzp = None
	elif eGxC8vzYKkT9Zw2==wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࠨሶ"): mgDoj8ZAqe0uBLxP4Kzp = {}
	else: mgDoj8ZAqe0uBLxP4Kzp = eGxC8vzYKkT9Zw2
	qAtGJl2nF163sZDL5C = list(mgDoj8ZAqe0uBLxP4Kzp.keys())
	if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬሷ") not in qAtGJl2nF163sZDL5C: mgDoj8ZAqe0uBLxP4Kzp[gy9NA3CROZolfEt4vVzMr(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ሸ")] = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡄࡅࡆࡓࡌࡋࡓࡣࡍࡋࡁࡅࡇࡕࡄࡅࡆࠧሹ")
	vfIB6ib8q1hFX5GweRrVPNTjY2E,bINq5DWsFP7yY29ioHwX8ECS,XXifFpsbwRoKkZx8aQ0AI7dHty5M,aKNfrBALZy8o = TJz3Sp4aIx5V(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	CmiVNjBLoJd2A8pgPkHvnZrX5D = LCIFdjzi5kVmRwehouHQ.getSetting(Jbu2G0Qax8PYWpg(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫሺ"))
	c9Bj6ViC0tmHFNKuALp8 = LCIFdjzi5kVmRwehouHQ.getSetting(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨሻ"))
	AJfxpLw90WU4n5E = LCIFdjzi5kVmRwehouHQ.getSetting(LsG7EDcei1gMShH2aVOCo(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫሼ"))
	WWV1l94XJPLTrpj = (bINq5DWsFP7yY29ioHwX8ECS==None and XXifFpsbwRoKkZx8aQ0AI7dHty5M==None)
	lmqyA6d81UvRKjcDBf2uGbx359t = ZEgwHfRnFV4[Sj1PYDmIpCUXO26(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧሽ")]
	fDRFh4OEBzPNM5QVuYvUcTyiamwlg = vfIB6ib8q1hFX5GweRrVPNTjY2E in lmqyA6d81UvRKjcDBf2uGbx359t
	Vwlpk4WjeABQKsHxYi7LJnP8ohOR92 = ZEgwHfRnFV4[RS7ZoyGAq1c(u"ࠨࡔࡈࡔࡔ࡙ࠧሾ")]
	oAVu301m7J5H = vfIB6ib8q1hFX5GweRrVPNTjY2E in Vwlpk4WjeABQKsHxYi7LJnP8ohOR92
	E2yZq7LghoVnpA1eW5v8MzmB9d = fDRFh4OEBzPNM5QVuYvUcTyiamwlg or oAVu301m7J5H
	if WWV1l94XJPLTrpj and E2yZq7LghoVnpA1eW5v8MzmB9d:
		if fDRFh4OEBzPNM5QVuYvUcTyiamwlg:
			UyCZqeTWw2hIa3BEKcSHD = lmqyA6d81UvRKjcDBf2uGbx359t.index(vfIB6ib8q1hFX5GweRrVPNTjY2E)
			eeg1l9nHNGFJmVUcaEhpy = ZEgwHfRnFV4[Y5npATFarf1H9wBjc87(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭ሿ")][UyCZqeTWw2hIa3BEKcSHD]
			xcgJLW163nGTKZz5yoYkEDpUj = aiwHkjxJEgl0WDeonX1U6fzbuLCp2M[UyCZqeTWw2hIa3BEKcSHD]
		elif oAVu301m7J5H:
			UyCZqeTWw2hIa3BEKcSHD = Vwlpk4WjeABQKsHxYi7LJnP8ohOR92.index(vfIB6ib8q1hFX5GweRrVPNTjY2E)
			eeg1l9nHNGFJmVUcaEhpy = ZEgwHfRnFV4[FZBX5WcC3msIDv4hobLd8(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭ቀ")][UyCZqeTWw2hIa3BEKcSHD]
			xcgJLW163nGTKZz5yoYkEDpUj = b9GYdZJsgNV6oF7[UyCZqeTWw2hIa3BEKcSHD]
	if XXifFpsbwRoKkZx8aQ0AI7dHty5M==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࠬቁ"): XXifFpsbwRoKkZx8aQ0AI7dHty5M = CmiVNjBLoJd2A8pgPkHvnZrX5D
	elif XXifFpsbwRoKkZx8aQ0AI7dHty5M==None and c9Bj6ViC0tmHFNKuALp8 in [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡇࡕࡕࡑࠪቂ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨቃ")] and GrW7YhVIBTu: XXifFpsbwRoKkZx8aQ0AI7dHty5M = CmiVNjBLoJd2A8pgPkHvnZrX5D
	dKnTRJAZkf9SNl6ogIzbHcX = vfIB6ib8q1hFX5GweRrVPNTjY2E==ZEgwHfRnFV4[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧቄ")][Sj1PYDmIpCUXO26(u"࠷ᚏ")]
	OO5k7AXU8iWK9SD4yqHfwuVrtvbCNL = bINq5DWsFP7yY29ioHwX8ECS and KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡵࡦࡶࡦࡶࡥࠨቅ") in bINq5DWsFP7yY29ioHwX8ECS
	if OO5k7AXU8iWK9SD4yqHfwuVrtvbCNL: Egi7k41QIqDK6NouH = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠷࠲ᚐ")
	elif fDRFh4OEBzPNM5QVuYvUcTyiamwlg or oAVu301m7J5H: Egi7k41QIqDK6NouH = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠳࠸ᚑ")
	elif ucGVEfRSBY in wV1DKnFCZBU236: Egi7k41QIqDK6NouH = onweDvmTOUj(u"࠴࠴ᚒ")
	elif ucGVEfRSBY==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫቆ"): Egi7k41QIqDK6NouH = Sj1PYDmIpCUXO26(u"࠶࠵ᚓ")
	elif ucGVEfRSBY==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫቇ"): Egi7k41QIqDK6NouH = d0HDrq8Rtk16AlInw4TXb(u"࠷࠶ᚔ")
	elif Sj1PYDmIpCUXO26(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭ቈ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = aSf0iWG1kA7FsqjHbuC8NXB(u"࠽࠰ᚕ")
	elif hxSBTdGpyNVbfu4tr9(u"࡙ࠬࡈࡐࡈࡋࡅࠬ቉") in ucGVEfRSBY: Egi7k41QIqDK6NouH = NQ4hg16DPUxtOyo5iGb(u"࠷࠶ᚖ")
	elif Y5npATFarf1H9wBjc87(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ቊ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = onweDvmTOUj(u"࠳࠷ᚗ")
	elif Sj1PYDmIpCUXO26(u"ࠧࡂࡊ࡚ࡅࡐ࠭ቋ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = eaF2N0jWLdvHIs8r(u"࠴࠳ᚘ")
	elif a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫቌ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠵࠴ᚙ")
	elif Sj1PYDmIpCUXO26(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨቍ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = WWbmNvI40sM9Khlp25Ae(u"࠷࠵ᚚ")
	elif aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡅࡐࡕࡁࡎࠩ቎") in ucGVEfRSBY: Egi7k41QIqDK6NouH = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷࠻᚛")
	elif LsG7EDcei1gMShH2aVOCo(u"ࠫࡆࡑࡗࡂࡏࠪ቏") in ucGVEfRSBY: Egi7k41QIqDK6NouH = B2vCEI9FAVP15R8eUbDJdySc(u"࠹࠰᚜")
	elif hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧቐ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = onweDvmTOUj(u"࠲࠱᚝")
	elif Q2ZyGqCNYsftTc4MR7n(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨቑ") in ucGVEfRSBY: Egi7k41QIqDK6NouH = wKdxVbTc0X9NSiespM8OvHGUhf(u"࠷࠲᚞")
	else: Egi7k41QIqDK6NouH = OnvTrikzfEsY7qU8pgaRBtZy(u"࠳࠸᚟")
	if Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩቒ") in ucGVEfRSBY and not ZZm1hsDV9ba and aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠨࠪቓ") not in vfIB6ib8q1hFX5GweRrVPNTjY2E and LsG7EDcei1gMShH2aVOCo(u"ࠩࡂࠫቔ") not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.rstrip(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪ࠳ࠬቕ"))+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫ࠴࠭ቖ")
	QD1GLs4AhWpxfcZv0U29Oj = (bINq5DWsFP7yY29ioHwX8ECS!=None)
	QmL6RWHJ5oD = (XXifFpsbwRoKkZx8aQ0AI7dHty5M!=None and c9Bj6ViC0tmHFNKuALp8!=Jbu2G0Qax8PYWpg(u"࡙ࠬࡔࡐࡒࠪ቗"))
	if QD1GLs4AhWpxfcZv0U29Oj and not OO5k7AXU8iWK9SD4yqHfwuVrtvbCNL: NCXj2ri3Unm6TFWIgwh(onweDvmTOUj(u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩቘ"),bINq5DWsFP7yY29ioHwX8ECS)
	elif QmL6RWHJ5oD: NCXj2ri3Unm6TFWIgwh(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧ቙"),XXifFpsbwRoKkZx8aQ0AI7dHty5M)
	if QD1GLs4AhWpxfcZv0U29Oj:
		M2AyUhuxgbs0SaG97woLzr = {Q2ZyGqCNYsftTc4MR7n(u"ࠣࡪࡷࡸࡵࠨቚ"):bINq5DWsFP7yY29ioHwX8ECS,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠤ࡫ࡸࡹࡶࡳࠣቛ"):bINq5DWsFP7yY29ioHwX8ECS}
		Zqh6SC7WsB4b2J = bINq5DWsFP7yY29ioHwX8ECS
	else: M2AyUhuxgbs0SaG97woLzr,Zqh6SC7WsB4b2J = {},MOwK1lpyNfCgqksX3jhV(u"ࠪࠫቜ")
	if QmL6RWHJ5oD:
		import urllib3.util.connection as bmSxrBYNkDKupeo4EvI9FgWh
		tC7UeGlBpgF4adEh = OGfB3t4IJrUxl7u9oEeiD5jPWbKAR(bmSxrBYNkDKupeo4EvI9FgWh,CmiVNjBLoJd2A8pgPkHvnZrX5D)
	uAcmU5iKsXx6H,AbaM4YmJZvf8V5hNL2jkd7nUogDXs,IbKoj8ugFPlDT,I4ImOkL76adCKJBYq,uk2GL84wIjaTN69erFcQtzMldObBC7,verify = IeWHCsBh2LG43xmwKU,ucGVEfRSBY,QOS2sIxvb8JZ70,onweDvmTOUj(u"ࡉࡥࡱࡹࡥᝏ"),onweDvmTOUj(u"ࡉࡥࡱࡹࡥᝏ"),aKNfrBALZy8o
	if dKnTRJAZkf9SNl6ogIzbHcX: uk2GL84wIjaTN69erFcQtzMldObBC7 = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡘࡷࡻࡥᝐ")
	if E2yZq7LghoVnpA1eW5v8MzmB9d or IeWHCsBh2LG43xmwKU: uAcmU5iKsXx6H = eaF2N0jWLdvHIs8r(u"ࡋࡧ࡬ࡴࡧᝑ")
	if fDRFh4OEBzPNM5QVuYvUcTyiamwlg: IbKoj8ugFPlDT = FZBX5WcC3msIDv4hobLd8(u"ࠫࡕࡕࡓࡕࠩቝ")
	E9eFvJPDwq,rreason = -OnvTrikzfEsY7qU8pgaRBtZy(u"࠴ᚠ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ቞")
	for jUSuZAztxy34TB5CIP2 in range(d0HDrq8Rtk16AlInw4TXb(u"࠽ᚡ")):
		ggi38WqJtzbO = gy9NA3CROZolfEt4vVzMr(u"࡚ࡲࡶࡧᝒ")
		sycSign827ZrEldIB = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡆࡢ࡮ࡶࡩᝓ")
		try:
			if jUSuZAztxy34TB5CIP2: AbaM4YmJZvf8V5hNL2jkd7nUogDXs = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧ቟")
			if OO5k7AXU8iWK9SD4yqHfwuVrtvbCNL or not QD1GLs4AhWpxfcZv0U29Oj: wFhHDd7gy6kesnTY4AVMLiU5aXGu8(eaF2N0jWLdvHIs8r(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡓࡕࡋࡎࡠࡗࡕࡐࠬበ"),vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,AbaM4YmJZvf8V5hNL2jkd7nUogDXs,IbKoj8ugFPlDT)
			try: Plx6mbKYD71aCsfTdukWy2Q.close()
			except: pass
			XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E
			Plx6mbKYD71aCsfTdukWy2Q = UYkMoz0DGsTwIdKxnfS5ryR23Pp.request(IbKoj8ugFPlDT,vfIB6ib8q1hFX5GweRrVPNTjY2E,data=ZZm1hsDV9ba,headers=mgDoj8ZAqe0uBLxP4Kzp,verify=verify,allow_redirects=uAcmU5iKsXx6H,timeout=Egi7k41QIqDK6NouH,proxies=M2AyUhuxgbs0SaG97woLzr)
			if onweDvmTOUj(u"࠸࠶࠰ᚢ")<=Plx6mbKYD71aCsfTdukWy2Q.status_code<=NQ4hg16DPUxtOyo5iGb(u"࠹࠹࠺ᚣ"):
				if not I4ImOkL76adCKJBYq:
					tDn7uG6I0Oih4NXe = list(Plx6mbKYD71aCsfTdukWy2Q.headers.keys())
					if nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪቡ") in tDn7uG6I0Oih4NXe: vfIB6ib8q1hFX5GweRrVPNTjY2E = Plx6mbKYD71aCsfTdukWy2Q.headers[mtEXp14ijx(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫቢ")]
					elif a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬባ") in tDn7uG6I0Oih4NXe: vfIB6ib8q1hFX5GweRrVPNTjY2E = Plx6mbKYD71aCsfTdukWy2Q.headers[eaF2N0jWLdvHIs8r(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ቤ")]
					else: I4ImOkL76adCKJBYq = OnvTrikzfEsY7qU8pgaRBtZy(u"ࡕࡴࡸࡩ᝔")
					if not I4ImOkL76adCKJBYq: vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.encode(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭ብ"),onweDvmTOUj(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ቦ")).decode(gy9NA3CROZolfEt4vVzMr(u"ࠧࡶࡶࡩ࠼ࠬቧ"),MOwK1lpyNfCgqksX3jhV(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨቨ"))
					if E2yZq7LghoVnpA1eW5v8MzmB9d and Plx6mbKYD71aCsfTdukWy2Q.status_code==B2vCEI9FAVP15R8eUbDJdySc(u"࠳࠱࠹ᚤ"):
						uAcmU5iKsXx6H = IeWHCsBh2LG43xmwKU
						IbKoj8ugFPlDT = QOS2sIxvb8JZ70
						I4ImOkL76adCKJBYq = MOwK1lpyNfCgqksX3jhV(u"ࡖࡵࡹࡪ᝕")
						e1eCcoHs6lwhXTp9q3SZ4RWY
				if not I4ImOkL76adCKJBYq or IeWHCsBh2LG43xmwKU:
					if mtEXp14ijx(u"ࠩ࡫ࡸࡹࡶࠧቩ") not in vfIB6ib8q1hFX5GweRrVPNTjY2E:
						WrlVQE8dsBzZ = DRom9hFTZXKuvfr2(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡹࡷࡲࠧቪ"))
						vfIB6ib8q1hFX5GweRrVPNTjY2E = WrlVQE8dsBzZ+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫ࠴࠭ቫ")+vfIB6ib8q1hFX5GweRrVPNTjY2E.lstrip(WWbmNvI40sM9Khlp25Ae(u"ࠬ࠵ࠧቬ"))
				if not I4ImOkL76adCKJBYq and IeWHCsBh2LG43xmwKU:
					MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					if MMQ7S0sAgzHIumcqWUx not in [FZBX5WcC3msIDv4hobLd8(u"࠭࠮ࡢࡸ࡬ࠫቭ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧ࠯ࡶࡶࠫቮ"),Jbu2G0Qax8PYWpg(u"ࠨ࠰ࡰࡴ࠹࠭ቯ"),Y5npATFarf1H9wBjc87(u"ࠩ࠱ࡥࡦࡩࠧተ"),Q2ZyGqCNYsftTc4MR7n(u"ࠪ࠲ࡲࡱࡶࠨቱ"),IPkQW7LojF3HO18V(u"ࠫ࠳ࡳࡰ࠴ࠩቲ"),gy9NA3CROZolfEt4vVzMr(u"ࠬ࠴ࡷࡦࡤࡰࠫታ")]: e1eCcoHs6lwhXTp9q3SZ4RWY
			elif RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠷࠸࠴ᚦ")<=Plx6mbKYD71aCsfTdukWy2Q.status_code<=NQ4hg16DPUxtOyo5iGb(u"࠶࠻࠼ᚥ"):
				Plx6mbKYD71aCsfTdukWy2Q.rreason = Plx6mbKYD71aCsfTdukWy2Q.content
				uk2GL84wIjaTN69erFcQtzMldObBC7 = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡗࡶࡺ࡫᝖")
			XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = Plx6mbKYD71aCsfTdukWy2Q.url
			E9eFvJPDwq = Plx6mbKYD71aCsfTdukWy2Q.status_code
			rreason = Plx6mbKYD71aCsfTdukWy2Q.reason
			Plx6mbKYD71aCsfTdukWy2Q.raise_for_status()
			sycSign827ZrEldIB = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡘࡷࡻࡥ᝗")
		except UYkMoz0DGsTwIdKxnfS5ryR23Pp.exceptions.HTTPError as wl7sKIoZfU:
			pass
		except UYkMoz0DGsTwIdKxnfS5ryR23Pp.exceptions.Timeout as wl7sKIoZfU:
			if BhTAck1bPFYGuUqRW: rreason = str(wl7sKIoZfU.message).split(wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭࠺ࠡࠩቴ"))[MOwK1lpyNfCgqksX3jhV(u"࠴ᚧ")]
			else: rreason = str(wl7sKIoZfU).split(mtEXp14ijx(u"ࠧ࠻ࠢࠪት"))[B2vCEI9FAVP15R8eUbDJdySc(u"࠵ᚨ")]
		except UYkMoz0DGsTwIdKxnfS5ryR23Pp.exceptions.ConnectionError as wl7sKIoZfU:
			try:
				ESuf43dwJmkx1NtG = wl7sKIoZfU.message[mtEXp14ijx(u"࠵ᚩ")]
				rreason = ESuf43dwJmkx1NtG
				if MOwK1lpyNfCgqksX3jhV(u"ࠨࡇࡵࡶࡳࡵࠧቶ") in ESuf43dwJmkx1NtG: E9eFvJPDwq,rreason = SomeI8i56FaDMGPE.findall(IPkQW7LojF3HO18V(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦቷ"),ESuf43dwJmkx1NtG)[Sj1PYDmIpCUXO26(u"࠶ᚪ")]
				elif aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪ࠰ࠥ࡫ࡲࡳࡱࡵࠬࠬቸ") in ESuf43dwJmkx1NtG: E9eFvJPDwq,rreason = SomeI8i56FaDMGPE.findall(QQSULIva4ljNO73mFcWw(u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢቹ"),ESuf43dwJmkx1NtG)[lh6URegmQNq8LWX0HaK5(u"࠰ᚫ")]
				elif ESuf43dwJmkx1NtG.count(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡀࠧቺ"))>=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠴ᚭ"): rreason,E9eFvJPDwq = SomeI8i56FaDMGPE.findall(Q2ZyGqCNYsftTc4MR7n(u"࠭࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪࠩቻ"),ESuf43dwJmkx1NtG)[RS7ZoyGAq1c(u"࠱ᚬ")]
			except: pass
		except UYkMoz0DGsTwIdKxnfS5ryR23Pp.exceptions.RequestException as wl7sKIoZfU:
			if BhTAck1bPFYGuUqRW: rreason = wl7sKIoZfU.message
			else: rreason = str(wl7sKIoZfU)
		except:
			ggi38WqJtzbO = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡋࡧ࡬ࡴࡧ᝘")
			try: E9eFvJPDwq = Plx6mbKYD71aCsfTdukWy2Q.status_code
			except: pass
			try: rreason = Plx6mbKYD71aCsfTdukWy2Q.reason
			except: pass
		rreason = str(rreason)
		xrFqGMab4uLKZcS(B2vCEI9FAVP15R8eUbDJdySc(u"ࠧࡏࡑࡗࡍࡈࡋࠧቼ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ች")+str(E9eFvJPDwq)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫቾ")+rreason+QQSULIva4ljNO73mFcWw(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬቿ")+ucGVEfRSBY+Y5npATFarf1H9wBjc87(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪኀ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࠦ࡝ࠨኁ"))
		if WWV1l94XJPLTrpj and E2yZq7LghoVnpA1eW5v8MzmB9d and ggi38WqJtzbO and not uk2GL84wIjaTN69erFcQtzMldObBC7 and E9eFvJPDwq!=mtEXp14ijx(u"࠵࠴࠵ᚮ"):
			vfIB6ib8q1hFX5GweRrVPNTjY2E = eeg1l9nHNGFJmVUcaEhpy
			uk2GL84wIjaTN69erFcQtzMldObBC7 = lh6URegmQNq8LWX0HaK5(u"࡚ࡲࡶࡧ᝙")
			continue
		if ggi38WqJtzbO: break
	if XXifFpsbwRoKkZx8aQ0AI7dHty5M!=None and c9Bj6ViC0tmHFNKuALp8!=B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡓࡕࡑࡓࠫኂ"): bmSxrBYNkDKupeo4EvI9FgWh.create_connection = tC7UeGlBpgF4adEh
	if c9Bj6ViC0tmHFNKuALp8==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧኃ") and GrW7YhVIBTu: XXifFpsbwRoKkZx8aQ0AI7dHty5M = None
	if not sycSign827ZrEldIB and bINq5DWsFP7yY29ioHwX8ECS==None and ucGVEfRSBY not in wV1DKnFCZBU236:
		zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
		if zi68Y9T7ngdIXKALbv3fjVEeOJm!=aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫኄ"): EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
	RKBm27pOP0frivqSgzwMA58 = KKTc4gCGlPOW2F36ibxUd8NVDHB()
	RKBm27pOP0frivqSgzwMA58.url = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv
	try: WkQUEwcqVr02g9tLhFz = Plx6mbKYD71aCsfTdukWy2Q.content
	except: WkQUEwcqVr02g9tLhFz = Jbu2G0Qax8PYWpg(u"ࠩࠪኅ")
	try: crf9moYRDNxwtyJ = Plx6mbKYD71aCsfTdukWy2Q.headers
	except: crf9moYRDNxwtyJ = {}
	try: GyuUHLex8zTnXYaki60wKV5D = Plx6mbKYD71aCsfTdukWy2Q.cookies.get_dict()
	except: GyuUHLex8zTnXYaki60wKV5D = {}
	try: Plx6mbKYD71aCsfTdukWy2Q.close()
	except: pass
	if ZZxLpCcmqhyT6NuMWelkbSvr0H:
		try: WkQUEwcqVr02g9tLhFz = WkQUEwcqVr02g9tLhFz.decode(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡹࡹ࡬࠸ࠨኆ"))
		except: pass
	E9eFvJPDwq = int(E9eFvJPDwq)
	RKBm27pOP0frivqSgzwMA58.code = E9eFvJPDwq
	RKBm27pOP0frivqSgzwMA58.reason = rreason
	RKBm27pOP0frivqSgzwMA58.content = WkQUEwcqVr02g9tLhFz
	RKBm27pOP0frivqSgzwMA58.headers = crf9moYRDNxwtyJ
	RKBm27pOP0frivqSgzwMA58.cookies = GyuUHLex8zTnXYaki60wKV5D
	RKBm27pOP0frivqSgzwMA58.succeeded = sycSign827ZrEldIB
	if BhTAck1bPFYGuUqRW or isinstance(RKBm27pOP0frivqSgzwMA58.content,str): fpJhNjMrPsT4aOcqA2Ytw3Cu = RKBm27pOP0frivqSgzwMA58.content.lower()
	else: fpJhNjMrPsT4aOcqA2Ytw3Cu = MOwK1lpyNfCgqksX3jhV(u"ࠫࠬኇ")
	juYczFWVTx49yiP6DdUms2BSQkpROJ = (q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩኈ") in fpJhNjMrPsT4aOcqA2Ytw3Cu or a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡧࡰࡱࡪࡰࡪ࠭኉") in fpJhNjMrPsT4aOcqA2Ytw3Cu) and fpJhNjMrPsT4aOcqA2Ytw3Cu.count(MOwK1lpyNfCgqksX3jhV(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪኊ"))>QQSULIva4ljNO73mFcWw(u"࠶ᚯ") and WWbmNvI40sM9Khlp25Ae(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪኋ") not in ucGVEfRSBY and FZBX5WcC3msIDv4hobLd8(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱࠫኌ") not in fpJhNjMrPsT4aOcqA2Ytw3Cu and not OO5k7AXU8iWK9SD4yqHfwuVrtvbCNL
	if E9eFvJPDwq==hxSBTdGpyNVbfu4tr9(u"࠷࠶࠰ᚰ") and juYczFWVTx49yiP6DdUms2BSQkpROJ: RKBm27pOP0frivqSgzwMA58.succeeded = QQSULIva4ljNO73mFcWw(u"ࡆࡢ࡮ࡶࡩ᝚")
	if RKBm27pOP0frivqSgzwMA58.succeeded and WWV1l94XJPLTrpj and E2yZq7LghoVnpA1eW5v8MzmB9d:
		if dKnTRJAZkf9SNl6ogIzbHcX: xcgJLW163nGTKZz5yoYkEDpUj = lh6URegmQNq8LWX0HaK5(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫኍ")+ZZm1hsDV9ba[LsG7EDcei1gMShH2aVOCo(u"ࠫ࡯ࡵࡢࠨ኎")].upper().replace(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡍࡅࡕࠩ኏"),onweDvmTOUj(u"࠭ࠧነ"))
		ry5LDgQtWUwXnCeHsSJk0x = jWC2KvXiT7hetLkIxGlazq3(xcgJLW163nGTKZz5yoYkEDpUj)
	if not RKBm27pOP0frivqSgzwMA58.succeeded and WWV1l94XJPLTrpj:
		S1jH5qx8zv3tl = (QQSULIva4ljNO73mFcWw(u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫኑ") in fpJhNjMrPsT4aOcqA2Ytw3Cu and q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡴࡤࡽࠥ࡯ࡤ࠻ࠢࠪኒ") in fpJhNjMrPsT4aOcqA2Ytw3Cu)
		JnkTS5GhM2 = (lh6URegmQNq8LWX0HaK5(u"ࠩ࠸ࠤࡸ࡫ࡣࠨና") in fpJhNjMrPsT4aOcqA2Ytw3Cu and gy9NA3CROZolfEt4vVzMr(u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫኔ") in fpJhNjMrPsT4aOcqA2Ytw3Cu)
		UKogE0espkJxi1IRc = (E9eFvJPDwq in [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠺࠰࠴ᚱ")] and Jbu2G0Qax8PYWpg(u"ࠫࡪࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢ࠴࠴࠷࠶ࠧን") in fpJhNjMrPsT4aOcqA2Ytw3Cu)
		fu1ishQSBAe = (QQSULIva4ljNO73mFcWw(u"ࠬࡥࡣࡧࡡࡦ࡬ࡱࡥࠧኖ") in fpJhNjMrPsT4aOcqA2Ytw3Cu and hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࠯ࠪኗ") in fpJhNjMrPsT4aOcqA2Ytw3Cu)
		if   juYczFWVTx49yiP6DdUms2BSQkpROJ: rreason = WWbmNvI40sM9Khlp25Ae(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧኘ")
		elif S1jH5qx8zv3tl: rreason = onweDvmTOUj(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩኙ")
		elif JnkTS5GhM2: rreason = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩኚ")
		elif UKogE0espkJxi1IRc: rreason = FZBX5WcC3msIDv4hobLd8(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶࠤࡩ࡫࡮ࡪࡧࡧࠫኛ")
		elif fu1ishQSBAe: rreason = hxSBTdGpyNVbfu4tr9(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭ኜ")
		else: rreason = str(rreason)
		if ucGVEfRSBY in xZgkz5Av3rKiXu9jaPJw: pass
		elif ucGVEfRSBY in wV1DKnFCZBU236:
			xrFqGMab4uLKZcS(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫኝ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩኞ")+str(E9eFvJPDwq)+Sj1PYDmIpCUXO26(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨኟ")+rreason+NQ4hg16DPUxtOyo5iGb(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪአ")+ucGVEfRSBY+mtEXp14ijx(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨኡ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࠤࡢ࠭ኢ"))
		else: xrFqGMab4uLKZcS(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩኣ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩኤ")+str(E9eFvJPDwq)+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧእ")+rreason+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩኦ")+ucGVEfRSBY+onweDvmTOUj(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧኧ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࠣࡡࠬከ"))
		FAwDKiHOcoNBY23LZ7ybs = aDebGvrkdptunqTM8m4(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		if BhTAck1bPFYGuUqRW and isinstance(FAwDKiHOcoNBY23LZ7ybs,unicode): FAwDKiHOcoNBY23LZ7ybs = FAwDKiHOcoNBY23LZ7ybs.encode(mtEXp14ijx(u"ࠪࡹࡹ࡬࠸ࠨኩ"))
		if E2yZq7LghoVnpA1eW5v8MzmB9d: FAwDKiHOcoNBY23LZ7ybs = FAwDKiHOcoNBY23LZ7ybs.split(lh6URegmQNq8LWX0HaK5(u"ࠫ࠴࠭ኪ"))[-nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠱ᚲ")]
		mk3MUWB17KFAVcOPYvjLq6DHa = rreason
		rreason = str(rreason)+MOwK1lpyNfCgqksX3jhV(u"ࠬࡢ࡮ࠩࠢࠪካ")+FAwDKiHOcoNBY23LZ7ybs+OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠠࠪࠩኬ")
		if juYczFWVTx49yiP6DdUms2BSQkpROJ or S1jH5qx8zv3tl or JnkTS5GhM2 or UKogE0espkJxi1IRc or fu1ishQSBAe:
			E9eFvJPDwq = -Sj1PYDmIpCUXO26(u"࠳ᚳ")
			RKBm27pOP0frivqSgzwMA58.code = E9eFvJPDwq
			RKBm27pOP0frivqSgzwMA58.reason = rreason
			if Nu5VfTLAMGnKbPD7kJzXWY:
				xrFqGMab4uLKZcS(d0HDrq8Rtk16AlInw4TXb(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ክ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Y5npATFarf1H9wBjc87(u"ࠨࠢࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪኮ")+str(E9eFvJPDwq)+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪኯ")+mk3MUWB17KFAVcOPYvjLq6DHa+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬኰ")+ucGVEfRSBY+NQ4hg16DPUxtOyo5iGb(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ኱")+vfIB6ib8q1hFX5GweRrVPNTjY2E+QQSULIva4ljNO73mFcWw(u"ࠬࠦ࡝ࠨኲ"))
				NCXj2ri3Unm6TFWIgwh(IPkQW7LojF3HO18V(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥอไโฯุࠤฬ๊รๆ่ํࠫኳ"),onweDvmTOUj(u"ࠧࠨኴ"),p1BoraOuWL=OnvTrikzfEsY7qU8pgaRBtZy(u"࠳࠸࠴࠵ᚴ"))
				KrtTXBECF3i5WhRfIywHJGbQukM0P6 = LCIFdjzi5kVmRwehouHQ.getSetting(Sj1PYDmIpCUXO26(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠶࠭ኵ"))
				c2h3TFQvRLMf7lUAqoY9ut0O1D = LCIFdjzi5kVmRwehouHQ.getSetting(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡨࡴ࠸ࠧ኶"))
				KrtTXBECF3i5WhRfIywHJGbQukM0P6 = Q2ZyGqCNYsftTc4MR7n(u"࠼࠽࠾࠿ᚵ") if not KrtTXBECF3i5WhRfIywHJGbQukM0P6 else int(KrtTXBECF3i5WhRfIywHJGbQukM0P6)
				c2h3TFQvRLMf7lUAqoY9ut0O1D = B2vCEI9FAVP15R8eUbDJdySc(u"࠽࠾࠿࠹ᚶ") if not c2h3TFQvRLMf7lUAqoY9ut0O1D else int(c2h3TFQvRLMf7lUAqoY9ut0O1D)
				VFXz38w9iGDQYp0T7C4O = []
				if KrtTXBECF3i5WhRfIywHJGbQukM0P6>RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠷࠰ᚸ"): VFXz38w9iGDQYp0T7C4O.append(B2vCEI9FAVP15R8eUbDJdySc(u"࠶ᚷ"))
				if c2h3TFQvRLMf7lUAqoY9ut0O1D>wKdxVbTc0X9NSiespM8OvHGUhf(u"࠱࠱ᚹ"): VFXz38w9iGDQYp0T7C4O.append(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠳ᚺ"))
				VFXz38w9iGDQYp0T7C4O.append(d0HDrq8Rtk16AlInw4TXb(u"࠵ᚻ"))
				FqhdyWLlnOMH2Jk0mSrewx = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(VFXz38w9iGDQYp0T7C4O,LsG7EDcei1gMShH2aVOCo(u"࠴ᚼ"))[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴ᚽ")]
				if FqhdyWLlnOMH2Jk0mSrewx==hxSBTdGpyNVbfu4tr9(u"࠶ᚾ"):
					d9q2YNoHGVx8znu = QQSULIva4ljNO73mFcWw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭኷")
					jx63XqgpYedEM1lZ = vfIB6ib8q1hFX5GweRrVPNTjY2E+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫኸ")+d9q2YNoHGVx8znu+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬኹ")
					FFtTOWuejrNfDAQPxBSpXEwCm = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,jx63XqgpYedEM1lZ,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,B2vCEI9FAVP15R8eUbDJdySc(u"ࡇࡣ࡯ࡷࡪ᝛"),FZBX5WcC3msIDv4hobLd8(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧኺ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࡇࡣ࡯ࡷࡪ᝛"),B2vCEI9FAVP15R8eUbDJdySc(u"ࡇࡣ࡯ࡷࡪ᝛"))
				elif FqhdyWLlnOMH2Jk0mSrewx==lh6URegmQNq8LWX0HaK5(u"࠸ᚿ"):
					d9q2YNoHGVx8znu = LsG7EDcei1gMShH2aVOCo(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪኻ")
					jx63XqgpYedEM1lZ = vfIB6ib8q1hFX5GweRrVPNTjY2E+Y5npATFarf1H9wBjc87(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨኼ")+d9q2YNoHGVx8znu+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩኽ")
					FFtTOWuejrNfDAQPxBSpXEwCm = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,jx63XqgpYedEM1lZ,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,gy9NA3CROZolfEt4vVzMr(u"ࡈࡤࡰࡸ࡫᝜"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠴ࡴࡧࠫኾ"),gy9NA3CROZolfEt4vVzMr(u"ࡈࡤࡰࡸ࡫᝜"),gy9NA3CROZolfEt4vVzMr(u"ࡈࡤࡰࡸ࡫᝜"))
				elif FqhdyWLlnOMH2Jk0mSrewx==eaF2N0jWLdvHIs8r(u"࠳ᛀ"):
					d9q2YNoHGVx8znu = Q2ZyGqCNYsftTc4MR7n(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩ࠻࠹࠹ࡦ࠹࡬ࡣ࠴࠶ࡩࡧࡩ࠷࠹ࡥ࠻ࡦ࠹࠺ࡧ࠱࠶ࡨ࠶࠺࠵࠺ࡣࡥ࠻࠴࠸ࡨࡆࡰࡳࡱࡻࡽ࠲ࡹࡥࡳࡸࡨࡶ࠳ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰ࡦࡳࡲࡀ࠸࠱࠲࠴ࠫ኿")
					jx63XqgpYedEM1lZ = vfIB6ib8q1hFX5GweRrVPNTjY2E+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬዀ")+d9q2YNoHGVx8znu+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭዁")
					FFtTOWuejrNfDAQPxBSpXEwCm = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,jx63XqgpYedEM1lZ,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,QQSULIva4ljNO73mFcWw(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠹ࡺࡨࠨዂ"),IPkQW7LojF3HO18V(u"ࡉࡥࡱࡹࡥ᝝"),IPkQW7LojF3HO18V(u"ࡉࡥࡱࡹࡥ᝝"))
				else: FFtTOWuejrNfDAQPxBSpXEwCm = RKBm27pOP0frivqSgzwMA58
				E9eFvJPDwq,rreason = FFtTOWuejrNfDAQPxBSpXEwCm.code,FFtTOWuejrNfDAQPxBSpXEwCm.reason
				if not FFtTOWuejrNfDAQPxBSpXEwCm.succeeded:
					xrFqGMab4uLKZcS(MOwK1lpyNfCgqksX3jhV(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧዃ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+onweDvmTOUj(u"ࠩࠣࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫዄ")+str(E9eFvJPDwq)+WWbmNvI40sM9Khlp25Ae(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫዅ")+rreason+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭዆")+ucGVEfRSBY+Q2ZyGqCNYsftTc4MR7n(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ዇")+jx63XqgpYedEM1lZ+FZBX5WcC3msIDv4hobLd8(u"࠭ࠠ࡞ࠩወ"))
					NCXj2ri3Unm6TFWIgwh(QQSULIva4ljNO73mFcWw(u"ࠧๅๆฦืๆࠦแีๆࠣห้็อึࠢส่ศ๋ๆ๋ࠩዉ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨฮิฬ๋ࠥัสࠢฦาึ๏ࠧዊ"),p1BoraOuWL=Sj1PYDmIpCUXO26(u"࠳࠲࠳࠴ᛁ"))
				else:
					xrFqGMab4uLKZcS(B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨዋ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨዌ")+ucGVEfRSBY+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪው")+jx63XqgpYedEM1lZ+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࠦ࡝ࠨዎ"))
					if FqhdyWLlnOMH2Jk0mSrewx in [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠳ᛂ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠵ᛃ")]:
						y8cIMf9BXkg0 = FFtTOWuejrNfDAQPxBSpXEwCm.headers[Q2ZyGqCNYsftTc4MR7n(u"࠭ࡓࡤࡴࡤࡴࡪ࠴ࡤࡰ࠯ࡕࡩࡲࡧࡩ࡯࡫ࡱ࡫࠲ࡉࡲࡦࡦ࡬ࡸࡸ࠭ዏ")]
						if FqhdyWLlnOMH2Jk0mSrewx==lh6URegmQNq8LWX0HaK5(u"࠵ᛄ"): LCIFdjzi5kVmRwehouHQ.setSetting(onweDvmTOUj(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠵ࠬዐ"),y8cIMf9BXkg0)
						if FqhdyWLlnOMH2Jk0mSrewx==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠷ᛅ"): LCIFdjzi5kVmRwehouHQ.setSetting(LsG7EDcei1gMShH2aVOCo(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠷࠭ዑ"),y8cIMf9BXkg0)
					NCXj2ri3Unm6TFWIgwh(MOwK1lpyNfCgqksX3jhV(u"้ࠩะาࠦวๅใะูࠥอไฤ็้๎ࠬዒ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫዓ"),p1BoraOuWL=QQSULIva4ljNO73mFcWw(u"࠸࠰࠱࠲ᛆ"))
					return FFtTOWuejrNfDAQPxBSpXEwCm
		svOyXbipkwY = Y5npATFarf1H9wBjc87(u"ࡘࡷࡻࡥ᝞")
		if (c9Bj6ViC0tmHFNKuALp8==onweDvmTOUj(u"ࠫࡆ࡙ࡋࠨዔ") or AJfxpLw90WU4n5E==IPkQW7LojF3HO18V(u"ࠬࡇࡓࡌࠩዕ")) and (GrW7YhVIBTu or Nu5VfTLAMGnKbPD7kJzXWY):
			svOyXbipkwY = UiZhKQ6o7YwAOWmd8jXxNy(E9eFvJPDwq,rreason,ucGVEfRSBY,showDialogs)
			if svOyXbipkwY and c9Bj6ViC0tmHFNKuALp8==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡁࡔࡍࠪዖ"): c9Bj6ViC0tmHFNKuALp8 = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ዗")
			else: c9Bj6ViC0tmHFNKuALp8 = FZBX5WcC3msIDv4hobLd8(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪዘ")
			if svOyXbipkwY and AJfxpLw90WU4n5E==LsG7EDcei1gMShH2aVOCo(u"ࠩࡄࡗࡐ࠭ዙ"): AJfxpLw90WU4n5E = NQ4hg16DPUxtOyo5iGb(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬዚ")
			else: AJfxpLw90WU4n5E = IPkQW7LojF3HO18V(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ዛ")
			LCIFdjzi5kVmRwehouHQ.setSetting(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨዜ"),c9Bj6ViC0tmHFNKuALp8)
			LCIFdjzi5kVmRwehouHQ.setSetting(Jbu2G0Qax8PYWpg(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫዝ"),AJfxpLw90WU4n5E)
		if svOyXbipkwY:
			gCnc2jM98v6HQL = Y5npATFarf1H9wBjc87(u"࡙ࡸࡵࡦ᝟")
			if E9eFvJPDwq==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠸ᛇ") and Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡩࡶࡷࡴࡸ࠭ዞ") in vfIB6ib8q1hFX5GweRrVPNTjY2E and gCnc2jM98v6HQL:
				if showDialogs: NCXj2ri3Unm6TFWIgwh(IPkQW7LojF3HO18V(u"ࠨฬไ฽๏๊ࠠโฯุࠤูํวะหࠣห้ะิโ์ิࠤࡘ࡙ࡌࠨዟ"),lh6URegmQNq8LWX0HaK5(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫዠ"),p1BoraOuWL=aSf0iWG1kA7FsqjHbuC8NXB(u"࠳࠲࠳࠴ᛈ"))
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪዡ")
				ry5LDgQtWUwXnCeHsSJk0x = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,WWbmNvI40sM9Khlp25Ae(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠷ࡷ࡬ࠬዢ"))
				if ry5LDgQtWUwXnCeHsSJk0x.succeeded:
					RKBm27pOP0frivqSgzwMA58 = ry5LDgQtWUwXnCeHsSJk0x
					xrFqGMab4uLKZcS(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫዣ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨዤ")+ucGVEfRSBY+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዥ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+Q2ZyGqCNYsftTc4MR7n(u"ࠨࠢࡠࠫዦ"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(B2vCEI9FAVP15R8eUbDJdySc(u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ዧ"),lh6URegmQNq8LWX0HaK5(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬየ"),p1BoraOuWL=Y5npATFarf1H9wBjc87(u"࠴࠳࠴࠵ᛉ"))
				else:
					xrFqGMab4uLKZcS(d0HDrq8Rtk16AlInw4TXb(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩዩ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+IPkQW7LojF3HO18V(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫዪ")+ucGVEfRSBY+d0HDrq8Rtk16AlInw4TXb(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬያ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+Jbu2G0Qax8PYWpg(u"ࠧࠡ࡟ࠪዬ"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(LsG7EDcei1gMShH2aVOCo(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫይ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫዮ"),p1BoraOuWL=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠵࠴࠵࠶ᛊ"))
			if not RKBm27pOP0frivqSgzwMA58.succeeded and AJfxpLw90WU4n5E in [hxSBTdGpyNVbfu4tr9(u"ࠪࡅ࡚࡚ࡏࠨዯ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ደ")] and Nu5VfTLAMGnKbPD7kJzXWY:
				if showDialogs: NCXj2ri3Unm6TFWIgwh(eaF2N0jWLdvHIs8r(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬዱ"),IPkQW7LojF3HO18V(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨዲ"),p1BoraOuWL=hxSBTdGpyNVbfu4tr9(u"࠶࠵࠶࠰ᛋ"))
				ry5LDgQtWUwXnCeHsSJk0x = LkG0l1oXUZ3(QOS2sIxvb8JZ70,vfIB6ib8q1hFX5GweRrVPNTjY2E,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,MOwK1lpyNfCgqksX3jhV(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠻ࡺࡨࠨዳ"))
				if ry5LDgQtWUwXnCeHsSJk0x.succeeded:
					RKBm27pOP0frivqSgzwMA58 = ry5LDgQtWUwXnCeHsSJk0x
					xrFqGMab4uLKZcS(onweDvmTOUj(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧዴ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+FZBX5WcC3msIDv4hobLd8(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩድ")+ucGVEfRSBY+MOwK1lpyNfCgqksX3jhV(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩዶ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+Jbu2G0Qax8PYWpg(u"ࠫࠥࡣࠧዷ"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(RS7ZoyGAq1c(u"ࠬ์ฬศฯࠣื๏ืแาษอࠤอื่ไีํࠫዸ"),d0HDrq8Rtk16AlInw4TXb(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨዹ"),p1BoraOuWL=eaF2N0jWLdvHIs8r(u"࠷࠶࠰࠱ᛌ"))
				else:
					xrFqGMab4uLKZcS(hxSBTdGpyNVbfu4tr9(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬዺ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬዻ")+ucGVEfRSBY+onweDvmTOUj(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዼ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+hxSBTdGpyNVbfu4tr9(u"ࠪࠤࡢ࠭ዽ"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(Q2ZyGqCNYsftTc4MR7n(u"ࠫๆฺไࠡีํีๆืวหࠢหีํ้ำ๋ࠩዾ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧዿ"),p1BoraOuWL=NQ4hg16DPUxtOyo5iGb(u"࠸࠰࠱࠲ᛍ"))
			if not RKBm27pOP0frivqSgzwMA58.succeeded and c9Bj6ViC0tmHFNKuALp8 in [RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡁࡖࡖࡒࠫጀ"),QQSULIva4ljNO73mFcWw(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩጁ")] and GrW7YhVIBTu:
				if showDialogs: NCXj2ri3Unm6TFWIgwh(Q2ZyGqCNYsftTc4MR7n(u"ࠨฬไ฽๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠪጂ"),IPkQW7LojF3HO18V(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጃ"),p1BoraOuWL=RS7ZoyGAq1c(u"࠲࠱࠲࠳ᛎ"))
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+Sj1PYDmIpCUXO26(u"ࠪࢀࢁࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨጄ")
				ry5LDgQtWUwXnCeHsSJk0x = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠹ࡷ࡬ࠬጅ"))
				if ry5LDgQtWUwXnCeHsSJk0x.succeeded:
					RKBm27pOP0frivqSgzwMA58 = ry5LDgQtWUwXnCeHsSJk0x
					xrFqGMab4uLKZcS(LsG7EDcei1gMShH2aVOCo(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫጆ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+NQ4hg16DPUxtOyo5iGb(u"࠭ࠠࠡࠢࡇࡒࡘࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ጇ")+CmiVNjBLoJd2A8pgPkHvnZrX5D+QQSULIva4ljNO73mFcWw(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩገ")+ucGVEfRSBY+QQSULIva4ljNO73mFcWw(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧጉ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࠣࡡࠬጊ"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(Jbu2G0Qax8PYWpg(u"๊ࠪัออࠡีํีๆืࠠࡅࡐࡖࠫጋ"),LsG7EDcei1gMShH2aVOCo(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጌ"),p1BoraOuWL=Rz34c0NP5BGo1WuTZxSfOKj(u"࠳࠲࠳࠴ᛏ"))
				else:
					xrFqGMab4uLKZcS(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪግ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+onweDvmTOUj(u"࠭ࠠࠡࠢࡇࡒࡘࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪጎ")+CmiVNjBLoJd2A8pgPkHvnZrX5D+eaF2N0jWLdvHIs8r(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩጏ")+ucGVEfRSBY+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧጐ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+WWbmNvI40sM9Khlp25Ae(u"ࠩࠣࡡࠬ጑"))
					if showDialogs: NCXj2ri3Unm6TFWIgwh(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪๅู๊ࠠิ์ิๅึࠦࡄࡏࡕࠪጒ"),mtEXp14ijx(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጓ"),p1BoraOuWL=a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴࠳࠴࠵ᛐ"))
		if AJfxpLw90WU4n5E==wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧጔ") or c9Bj6ViC0tmHFNKuALp8==MOwK1lpyNfCgqksX3jhV(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨጕ"): showDialogs = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡌࡡ࡭ࡵࡨᝠ")
		if not RKBm27pOP0frivqSgzwMA58.succeeded:
			if showDialogs: f1t8cXIiQTR9pUyzaEdBrYDA5wq = UiZhKQ6o7YwAOWmd8jXxNy(E9eFvJPDwq,rreason,ucGVEfRSBY,showDialogs)
			if E9eFvJPDwq!=FZBX5WcC3msIDv4hobLd8(u"࠵࠴࠵ᛑ") and ucGVEfRSBY not in zdB0Ze19GUobW and Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࠫ጖") not in ucGVEfRSBY:
				YosJW4Tklp2IyQ0jPnam(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹࠦࡤࡶࡧࠣࡸࡴࠦ࡮ࡦࡶࡺࡳࡷࡱࠠࡪࡵࡶࡹࡪࡹࠠࡸ࡫ࡷ࡬࠿ࠦࠧ጗")+ucGVEfRSBY)
	if LCIFdjzi5kVmRwehouHQ.getSetting(d0HDrq8Rtk16AlInw4TXb(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬጘ")) not in [wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡅ࡚࡚ࡏࠨጙ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࡘ࡚ࡏࡑࠩጚ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡇࡓࡌࠩጛ")]: LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩጜ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࡂࡕࡎࠫጝ"))
	if LCIFdjzi5kVmRwehouHQ.getSetting(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ጞ")) not in [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡄ࡙࡙ࡕࠧጟ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡗ࡙ࡕࡐࠨጠ"),IPkQW7LojF3HO18V(u"ࠫࡆ࡙ࡋࠨጡ")]: LCIFdjzi5kVmRwehouHQ.setSetting(Y5npATFarf1H9wBjc87(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪጢ"),lh6URegmQNq8LWX0HaK5(u"࠭ࡁࡔࡍࠪጣ"))
	return RKBm27pOP0frivqSgzwMA58
def eWltKEO6ar3XBdZ(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,ucGVEfRSBY,GrW7YhVIBTu=hxSBTdGpyNVbfu4tr9(u"ࠧࠨጤ"),Nu5VfTLAMGnKbPD7kJzXWY=Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠩጥ")):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,bINq5DWsFP7yY29ioHwX8ECS,XXifFpsbwRoKkZx8aQ0AI7dHty5M,aKNfrBALZy8o = TJz3Sp4aIx5V(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	iJe1DukCLnsTtyRZp = QOS2sIxvb8JZ70,vfIB6ib8q1hFX5GweRrVPNTjY2E,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG
	if LLfosSIikqUgKAG9hOVTZWrel6mHu:
		Plx6mbKYD71aCsfTdukWy2Q = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫጦ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭ጧ"),iJe1DukCLnsTtyRZp)
		if Plx6mbKYD71aCsfTdukWy2Q.succeeded:
			wFhHDd7gy6kesnTY4AVMLiU5aXGu8(lh6URegmQNq8LWX0HaK5(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫጨ"),vfIB6ib8q1hFX5GweRrVPNTjY2E,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY,QOS2sIxvb8JZ70)
			return Plx6mbKYD71aCsfTdukWy2Q
	Plx6mbKYD71aCsfTdukWy2Q = K8tfnJSR56O9ENghiVGYQZjoDX(QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ZP8LaN3fjk1HvoUFJspG,showDialogs,ucGVEfRSBY,GrW7YhVIBTu,Nu5VfTLAMGnKbPD7kJzXWY)
	if Plx6mbKYD71aCsfTdukWy2Q.succeeded:
		if gy9NA3CROZolfEt4vVzMr(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ጩ") in ucGVEfRSBY: Plx6mbKYD71aCsfTdukWy2Q.content = rZdXbWjBNth8U(Plx6mbKYD71aCsfTdukWy2Q.content)
		if LLfosSIikqUgKAG9hOVTZWrel6mHu: F4QxJHhsMj(qQ4BC6vW5YOfo,IPkQW7LojF3HO18V(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩጪ"),iJe1DukCLnsTtyRZp,Plx6mbKYD71aCsfTdukWy2Q,LLfosSIikqUgKAG9hOVTZWrel6mHu)
	return Plx6mbKYD71aCsfTdukWy2Q
def aax105ZrnJG(LLfosSIikqUgKAG9hOVTZWrel6mHu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,showDialogs,ucGVEfRSBY):
	if not oo76muA1GlEh9s0ZHNT4yMXQzipP or isinstance(oo76muA1GlEh9s0ZHNT4yMXQzipP,dict): QOS2sIxvb8JZ70 = hxSBTdGpyNVbfu4tr9(u"ࠧࡈࡇࡗࠫጫ")
	else:
		QOS2sIxvb8JZ70 = gy9NA3CROZolfEt4vVzMr(u"ࠨࡒࡒࡗ࡙࠭ጬ")
		oo76muA1GlEh9s0ZHNT4yMXQzipP = aDebGvrkdptunqTM8m4(oo76muA1GlEh9s0ZHNT4yMXQzipP)
		fcwhmqvVAG,oo76muA1GlEh9s0ZHNT4yMXQzipP = RyQ1vTDniwqI7jCNMHmtcLaVK(oo76muA1GlEh9s0ZHNT4yMXQzipP)
	Plx6mbKYD71aCsfTdukWy2Q = eWltKEO6ar3XBdZ(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,Sj1PYDmIpCUXO26(u"ࡔࡳࡷࡨᝡ"),showDialogs,ucGVEfRSBY)
	mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.content
	mmhS2KFYI4eC6HWgk1trq = str(mmhS2KFYI4eC6HWgk1trq)
	return mmhS2KFYI4eC6HWgk1trq
def TJz3Sp4aIx5V(xTFHrZ1nGWa9fdqsSA5y4htgJNmX):
	ggqvwIeiAVO = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.split(B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡿࢀࠬጭ"))
	vfIB6ib8q1hFX5GweRrVPNTjY2E,bINq5DWsFP7yY29ioHwX8ECS,XXifFpsbwRoKkZx8aQ0AI7dHty5M,aKNfrBALZy8o = ggqvwIeiAVO[d0HDrq8Rtk16AlInw4TXb(u"࠴ᛒ")],None,None,B2vCEI9FAVP15R8eUbDJdySc(u"ࡕࡴࡸࡩᝢ")
	for iJe1DukCLnsTtyRZp in ggqvwIeiAVO:
		if OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨጮ") in iJe1DukCLnsTtyRZp: bINq5DWsFP7yY29ioHwX8ECS = iJe1DukCLnsTtyRZp.split(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡂ࠭ጯ"))[hxSBTdGpyNVbfu4tr9(u"࠶ᛓ")]
		elif lh6URegmQNq8LWX0HaK5(u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨጰ") in iJe1DukCLnsTtyRZp: XXifFpsbwRoKkZx8aQ0AI7dHty5M = iJe1DukCLnsTtyRZp.split(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭࠽ࠨጱ"))[WWbmNvI40sM9Khlp25Ae(u"࠷ᛔ")]
		elif Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬጲ") in iJe1DukCLnsTtyRZp: aKNfrBALZy8o = LsG7EDcei1gMShH2aVOCo(u"ࡈࡤࡰࡸ࡫ᝣ")
	return vfIB6ib8q1hFX5GweRrVPNTjY2E,bINq5DWsFP7yY29ioHwX8ECS,XXifFpsbwRoKkZx8aQ0AI7dHty5M,aKNfrBALZy8o
def JphHZ4KdkcF19vtoVlTYx5LPM(x0LXdHBFwj7EtMfu):
	bxYGWv4zRo1E7kc,yPRGDCnXhJbwYalz7fZepiUcA,I4WQZDwcFYfC0UkS7hJGHzebv = QQSULIva4ljNO73mFcWw(u"ࠨࠩጳ"),lh6URegmQNq8LWX0HaK5(u"ࠩࠪጴ"),QQSULIva4ljNO73mFcWw(u"ࠪࠫጵ")
	x0LXdHBFwj7EtMfu = x0LXdHBFwj7EtMfu.replace(H02Qqy4XO9L3Dui6S8PGWxJt,LsG7EDcei1gMShH2aVOCo(u"ࠫࠬጶ")).replace(spTWfEz2PU9AL,MOwK1lpyNfCgqksX3jhV(u"ࠬ࠭ጷ"))
	T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall(gy9NA3CROZolfEt4vVzMr(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ጸ"),x0LXdHBFwj7EtMfu,SomeI8i56FaDMGPE.DOTALL)
	if T9PyERLBA8wiVN30QjU14mW: bxYGWv4zRo1E7kc,yPRGDCnXhJbwYalz7fZepiUcA,x0LXdHBFwj7EtMfu = T9PyERLBA8wiVN30QjU14mW[B2vCEI9FAVP15R8eUbDJdySc(u"࠰ᛕ")]
	if bxYGWv4zRo1E7kc not in [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠡࠩጹ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࠮ࠪጺ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࠪጻ")]: I4WQZDwcFYfC0UkS7hJGHzebv = hxSBTdGpyNVbfu4tr9(u"ࠪࡣࡒࡕࡄࡠࠩጼ")
	if yPRGDCnXhJbwYalz7fZepiUcA: yPRGDCnXhJbwYalz7fZepiUcA = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡤ࠭ጽ")+yPRGDCnXhJbwYalz7fZepiUcA+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡥࠧጾ")
	x0LXdHBFwj7EtMfu = yPRGDCnXhJbwYalz7fZepiUcA+I4WQZDwcFYfC0UkS7hJGHzebv+x0LXdHBFwj7EtMfu
	return x0LXdHBFwj7EtMfu
def PP2QEmwzKue6nol57v(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,Iw5j2aDesOBkEGvpM1NK,uzGaHXD0W46wRFek9rCcNJAbP,JymsxIcQoZeitf,eGxC8vzYKkT9Zw2=gy9NA3CROZolfEt4vVzMr(u"࠭ࠧጿ")):
	NNzeidlj6fkLuGvWIxqbTC = DRom9hFTZXKuvfr2(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,RS7ZoyGAq1c(u"ࠧࡶࡴ࡯ࠫፀ"))
	LPpdqHBWN8DZU9o2cza30Xw4 = LCIFdjzi5kVmRwehouHQ.getSetting(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪፁ")+Iw5j2aDesOBkEGvpM1NK)
	if NNzeidlj6fkLuGvWIxqbTC==LPpdqHBWN8DZU9o2cza30Xw4: LCIFdjzi5kVmRwehouHQ.setSetting(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫፂ")+Iw5j2aDesOBkEGvpM1NK,mtEXp14ijx(u"ࠪࠫፃ"))
	if LPpdqHBWN8DZU9o2cza30Xw4: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(NNzeidlj6fkLuGvWIxqbTC,LPpdqHBWN8DZU9o2cza30Xw4)
	else:
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = xTFHrZ1nGWa9fdqsSA5y4htgJNmX
		LPpdqHBWN8DZU9o2cza30Xw4 = NNzeidlj6fkLuGvWIxqbTC
	ry5LDgQtWUwXnCeHsSJk0x = eWltKEO6ar3XBdZ(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,FZBX5WcC3msIDv4hobLd8(u"ࠫࠬፄ"),eGxC8vzYKkT9Zw2,mtEXp14ijx(u"ࠬ࠭ፅ"),LsG7EDcei1gMShH2aVOCo(u"࠭ࠧፆ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫፇ"))
	mmhS2KFYI4eC6HWgk1trq = ry5LDgQtWUwXnCeHsSJk0x.content
	if ZZxLpCcmqhyT6NuMWelkbSvr0H:
		try: mmhS2KFYI4eC6HWgk1trq = mmhS2KFYI4eC6HWgk1trq.decode(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࡷࡷࡪ࠽࠭ፈ"),Jbu2G0Qax8PYWpg(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩፉ"))
		except: pass
	E9eFvJPDwq = ry5LDgQtWUwXnCeHsSJk0x.code
	if E9eFvJPDwq!=-Jbu2G0Qax8PYWpg(u"࠳ᛖ") and (not ry5LDgQtWUwXnCeHsSJk0x.succeeded or JymsxIcQoZeitf not in mmhS2KFYI4eC6HWgk1trq):
		uzGaHXD0W46wRFek9rCcNJAbP = uzGaHXD0W46wRFek9rCcNJAbP.replace(Jbu2G0Qax8PYWpg(u"ࠪࠤࠬፊ"),QQSULIva4ljNO73mFcWw(u"ࠫ࠰࠭ፋ"))
		vfIB6ib8q1hFX5GweRrVPNTjY2E = onweDvmTOUj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪፌ")+uzGaHXD0W46wRFek9rCcNJAbP
		mgDoj8ZAqe0uBLxP4Kzp = {a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪፍ"):Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠨፎ")}
		RKBm27pOP0frivqSgzwMA58 = eWltKEO6ar3XBdZ(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,vfIB6ib8q1hFX5GweRrVPNTjY2E,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࠩፏ"),mgDoj8ZAqe0uBLxP4Kzp,Q2ZyGqCNYsftTc4MR7n(u"ࠩࠪፐ"),Jbu2G0Qax8PYWpg(u"ࠪࠫፑ"),QQSULIva4ljNO73mFcWw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠷ࡴࡤࠨፒ"))
		if RKBm27pOP0frivqSgzwMA58.succeeded:
			mmhS2KFYI4eC6HWgk1trq = RKBm27pOP0frivqSgzwMA58.content
			if ZZxLpCcmqhyT6NuMWelkbSvr0H:
				try: mmhS2KFYI4eC6HWgk1trq = mmhS2KFYI4eC6HWgk1trq.decode(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬࡻࡴࡧ࠺ࠪፓ"),QQSULIva4ljNO73mFcWw(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ፔ"))
				except: pass
			ZZHhmdtY1g = SomeI8i56FaDMGPE.findall(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡠࡼ࠰࡜ࡀ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨፕ"),mmhS2KFYI4eC6HWgk1trq,SomeI8i56FaDMGPE.DOTALL)
			AwYsWOXSQjRv1zkTtq6Zx = [LPpdqHBWN8DZU9o2cza30Xw4]
			vr0a7dTpe9Rhw = [WWbmNvI40sM9Khlp25Ae(u"ࠨࡣࡳ࡯ࠬፖ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩፗ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡸࡼ࡯ࡴࡵࡧࡵࠫፘ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬፙ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧፚ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡰࡩࡲࠪ፛"),lh6URegmQNq8LWX0HaK5(u"ࠧࡢࡶ࡯ࡥࡶ࠭፜"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡵ࡬ࡸࡪ࡯࡮ࡥ࡫ࡦࡩࡸ࠭፝"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡶࡹࡷ࠴࡬ࡺࠩ፞"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡦࡱࡵࡧࡴࡲࡲࡸࠬ፟"),LsG7EDcei1gMShH2aVOCo(u"ࠫ࡮ࡴࡦࡰࡴࡰࡩࡷ࠭፠"),QQSULIva4ljNO73mFcWw(u"ࠬࡹࡩࡵࡧ࡯࡭ࡰ࡫ࠧ፡"),mtEXp14ijx(u"࠭ࡩ࡯ࡵࡷࡥ࡬ࡸࡡ࡮ࠩ።"),d0HDrq8Rtk16AlInw4TXb(u"ࠧࡴࡰࡤࡴࡨ࡮ࡡࡵࠩ፣"),QQSULIva4ljNO73mFcWw(u"ࠨࡪࡷࡸࡵ࠳ࡥࡲࡷ࡬ࡺࠬ፤"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡩࡥࡸ࡫࡬ࡱ࡮ࡸࡷࠬ፥")]
			for sDCfutRY03p6ZNclVLJqIrQ in ZZHhmdtY1g:
				if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in sDCfutRY03p6ZNclVLJqIrQ for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in vr0a7dTpe9Rhw): continue
				LPpdqHBWN8DZU9o2cza30Xw4 = DRom9hFTZXKuvfr2(sDCfutRY03p6ZNclVLJqIrQ,WWbmNvI40sM9Khlp25Ae(u"ࠪࡹࡷࡲࠧ፦"))
				if LPpdqHBWN8DZU9o2cza30Xw4 in AwYsWOXSQjRv1zkTtq6Zx: continue
				if len(AwYsWOXSQjRv1zkTtq6Zx)==MOwK1lpyNfCgqksX3jhV(u"࠻ᛗ"):
					xrFqGMab4uLKZcS(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ፧"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+eaF2N0jWLdvHIs8r(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ፨")+Iw5j2aDesOBkEGvpM1NK+LsG7EDcei1gMShH2aVOCo(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫ፩")+NNzeidlj6fkLuGvWIxqbTC+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࠡ࡟ࠪ፪"))
					LCIFdjzi5kVmRwehouHQ.setSetting(FZBX5WcC3msIDv4hobLd8(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ፫")+Iw5j2aDesOBkEGvpM1NK,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠪ፬"))
					break
				AwYsWOXSQjRv1zkTtq6Zx.append(LPpdqHBWN8DZU9o2cza30Xw4)
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(NNzeidlj6fkLuGvWIxqbTC,LPpdqHBWN8DZU9o2cza30Xw4)
				ry5LDgQtWUwXnCeHsSJk0x = eWltKEO6ar3XBdZ(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,Sj1PYDmIpCUXO26(u"ࠪࠫ፭"),eGxC8vzYKkT9Zw2,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࠬ፮"),mtEXp14ijx(u"ࠬ࠭፯"),onweDvmTOUj(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ፰"))
				mmhS2KFYI4eC6HWgk1trq = ry5LDgQtWUwXnCeHsSJk0x.content
				if ry5LDgQtWUwXnCeHsSJk0x.succeeded and JymsxIcQoZeitf in mmhS2KFYI4eC6HWgk1trq:
					xrFqGMab4uLKZcS(gy9NA3CROZolfEt4vVzMr(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭፱"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Jbu2G0Qax8PYWpg(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤ࡫ࡵࡵ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ፲")+Iw5j2aDesOBkEGvpM1NK+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠣࡡࠥࠦࠠࡏࡧࡺ࠾ࠥࡡࠠࠨ፳")+LPpdqHBWN8DZU9o2cza30Xw4+mtEXp14ijx(u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨ፴")+NNzeidlj6fkLuGvWIxqbTC+WWbmNvI40sM9Khlp25Ae(u"ࠫࠥࡣࠧ፵"))
					LCIFdjzi5kVmRwehouHQ.setSetting(hxSBTdGpyNVbfu4tr9(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ፶")+Iw5j2aDesOBkEGvpM1NK,LPpdqHBWN8DZU9o2cza30Xw4)
					break
	return LPpdqHBWN8DZU9o2cza30Xw4,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,ry5LDgQtWUwXnCeHsSJk0x
def AFuJDPbZhS134etQfj(FbewQr7IVXqN0ijhOtm2vAnauzZT):
	BBfZsykd59zUX4HL7l0qDcuM = {
	 FZBX5WcC3msIDv4hobLd8(u"࠭࡯࡭ࡦࠪ፷")			:NQ4hg16DPUxtOyo5iGb(u"ࠧใัํ้ࠬ፸")
	,Jbu2G0Qax8PYWpg(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ፹")		:KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"่ࠩฮํ่แࠨ፺")
	,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ፻")		:B2vCEI9FAVP15R8eUbDJdySc(u"๊ࠫ็โ้ัࠪ፼")
	,Jbu2G0Qax8PYWpg(u"ࠬ࡭࡯ࡰࡦࠪ፽")			:KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ฬ๋ัࠪ፾")
	,mtEXp14ijx(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ፿")		:RS7ZoyGAq1c(u"ࠨใื่ࠬᎀ")
	,eaF2N0jWLdvHIs8r(u"ࠩࡩࡳࡱࡪࡥࡳࠩᎁ")		:d0HDrq8Rtk16AlInw4TXb(u"้ࠪั๊ฯࠨᎂ")
	,eaF2N0jWLdvHIs8r(u"ࠫࡻ࡯ࡤࡦࡱࠪᎃ")		:QQSULIva4ljNO73mFcWw(u"ࠬ็๊ะ์๋ࠫᎄ")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"࠭࡬ࡪࡸࡨࠫᎅ")			:RS7ZoyGAq1c(u"ࠧใ่สอࠬᎆ")
	,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࡣ࡮ࡳࡦࡳࠧᎇ")		:Y5npATFarf1H9wBjc87(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅไา๎๊࠭ᎈ")
	,FZBX5WcC3msIDv4hobLd8(u"ࠪࡥࡰࡽࡡ࡮ࠩᎉ")		:aSf0iWG1kA7FsqjHbuC8NXB(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨᎊ")
	,mtEXp14ijx(u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧᎋ")		:a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧᎌ")
	,RS7ZoyGAq1c(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧᎍ")		:RS7ZoyGAq1c(u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨᎎ")
	,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫᎏ")		:B2vCEI9FAVP15R8eUbDJdySc(u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩ᎐")
	,B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧ᎑")	:QQSULIva4ljNO73mFcWw(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨ᎒")
	,LsG7EDcei1gMShH2aVOCo(u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨ᎓")		:d0HDrq8Rtk16AlInw4TXb(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫ᎔")
	,WWbmNvI40sM9Khlp25Ae(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ᎕")		:a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪ᎖")
	,FZBX5WcC3msIDv4hobLd8(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧ᎗")	:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥࡼࡩࡱࠩ᎘")
	,eaF2N0jWLdvHIs8r(u"ࠬ࡫࡬ࡤ࡫ࡱࡩࡲࡧࠧ᎙")		:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ๅ้ไ฼ࠤฬ๊ำ๋่่หࠬ᎚")
	,RS7ZoyGAq1c(u"ࠧࡩࡧ࡯ࡥࡱ࠭᎛")		:gy9NA3CROZolfEt4vVzMr(u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫ᎜")
	,WWbmNvI40sM9Khlp25Ae(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫ᎝")		:IPkQW7LojF3HO18V(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫ᎞")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭᎟")		:Q2ZyGqCNYsftTc4MR7n(u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧᎠ")
	,Q2ZyGqCNYsftTc4MR7n(u"࠭ࡳࡩࡱࡲࡪࡲࡧࡸࠨᎡ")		:MOwK1lpyNfCgqksX3jhV(u"ࠧๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧᎢ")
	,d0HDrq8Rtk16AlInw4TXb(u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪᎣ")		:Rz34c0NP5BGo1WuTZxSfOKj(u"่ࠩ์็฿ฺࠠำหࠤุ๐๊ะࠩᎤ")
	,Sj1PYDmIpCUXO26(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫᎥ")		:lh6URegmQNq8LWX0HaK5(u"๊ࠫ๎โฺࠢึ๎๊อࠠ็ษ๋ࠫᎦ")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡱࡡࡳࡤࡤࡰࡦࡺࡶࠨᎧ")	:Jbu2G0Qax8PYWpg(u"࠭ๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩᎨ")
	,Y5npATFarf1H9wBjc87(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭Ꭹ")	:eaF2N0jWLdvHIs8r(u"ࠨ็๋ห็฿๋๊ࠠอ๎ํฮࠧᎪ")
	,lh6URegmQNq8LWX0HaK5(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩᎫ")		:RS7ZoyGAq1c(u"้ࠪํู่ࠡ็ส๎ู๊ࠥๆษࠪᎬ")
	,hxSBTdGpyNVbfu4tr9(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫᎭ")		:onweDvmTOUj(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠫᎮ")
	,FZBX5WcC3msIDv4hobLd8(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨᎯ")		:mtEXp14ijx(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩᎰ")
	,eaF2N0jWLdvHIs8r(u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠴ࠪᎱ")		:S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"่ࠩ์็฿ࠠโษุ่ࠥอไฬษ้๎ࠬᎲ")
	,eaF2N0jWLdvHIs8r(u"ࠪࡦࡴࡱࡲࡢࠩᎳ")		:q6yUEoKVDb0fXmc8vhrMk7N(u"๊ࠫ๎โฺࠢห็ึอࠧᎴ")
	,IPkQW7LojF3HO18V(u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧᎵ")		:q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧᎶ")
	,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧ࡭࡫ࡹࡩࡹࡼࠧᎷ")		:lh6URegmQNq8LWX0HaK5(u"ࠨ็็ๅࠬᎸ")
	,FZBX5WcC3msIDv4hobLd8(u"ࠩ࡯࡭ࡧࡸࡡࡳࡻࠪᎹ")		:onweDvmTOUj(u"้้ࠪ็ࠧᎺ")
	,RS7ZoyGAq1c(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫᎻ")		:q6yUEoKVDb0fXmc8vhrMk7N(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧᎼ")
	,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡦࡢ࡬ࡨࡶࡸ࡮࡯ࡸࠩᎽ")	:B2vCEI9FAVP15R8eUbDJdySc(u"ࠧๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬᎾ")
	,mtEXp14ijx(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩᎿ")		:gy9NA3CROZolfEt4vVzMr(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠪᏀ")
	,B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬᏁ")		:RWnd79GQpKM1gV5xAO2amZkTrL8F(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠷ࠧᏂ")
	,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠸ࠧᏃ")		:Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠳ࠩᏄ")
	,LsG7EDcei1gMShH2aVOCo(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠴ࠩᏅ")		:aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫᏆ")
	,WWbmNvI40sM9Khlp25Ae(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠷ࠫᏇ")		:Q2ZyGqCNYsftTc4MR7n(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠹࠭Ꮘ")
	,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫᏉ")		:nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧᏊ")
	,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࡥࡨࡻࡱࡳࡼ࠭Ꮛ")		:RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧๆ๊ๅ฽ࠥห๊อ์๊ࠣฬ๎ࠧᏌ")
	,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡧࡪࡽࡩ࡫ࡡࡥࠩᏍ")		:lh6URegmQNq8LWX0HaK5(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩᏎ")
	,lh6URegmQNq8LWX0HaK5(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬᏏ")		:Y5npATFarf1H9wBjc87(u"๊ࠫ๎โฺ๊่ࠢฬࠦำ๋็สࠫᏐ")
	,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭Ꮡ")		:RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬᏒ")
	,QQSULIva4ljNO73mFcWw(u"ࠧࡵࡸࡩࡹࡳ࠭Ꮣ")		:Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨᏔ")
	,QQSULIva4ljNO73mFcWw(u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬᏕ")	:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"้ࠪํู่ࠡีํ้ฬࠦไศ์อࠫᏖ")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡸ࡮ࡡࡩ࡫ࡧࡲࡪࡽࡳࠨᏗ")	:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"๋่ࠬใ฻ุࠣฬํฯ่ࠡํ์ื࠭Ꮨ")
	,lh6URegmQNq8LWX0HaK5(u"࠭ࡦࡰࡵࡷࡥࠬᏙ")		:LsG7EDcei1gMShH2aVOCo(u"ࠧๆ๊ๅ฽ࠥ็่ิฬสࠫᏚ")
	,hxSBTdGpyNVbfu4tr9(u"ࠨࡣ࡫ࡻࡦࡱࠧᏛ")		:QQSULIva4ljNO73mFcWw(u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫᏜ")
	,B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫᏝ")		:q6yUEoKVDb0fXmc8vhrMk7N(u"๊ࠫ๎โฺࠢไฬึ้ษࠨᏞ")
	,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫᏟ")	:nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫᏠ")
	,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡣࠩᏡ")		:IPkQW7LojF3HO18V(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩᏢ")
	,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡶ࡬ࡴ࡬ࡨࡢࠩᏣ")		:q6yUEoKVDb0fXmc8vhrMk7N(u"้ࠪํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬᏤ")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡧࡸࡳࡵࡧ࡭ࠫᏥ")		:WWbmNvI40sM9Khlp25Ae(u"๋่ࠬใ฻ࠣฬึูส๋ฮࠪᏦ")
	,LsG7EDcei1gMShH2aVOCo(u"࠭ࡣࡪ࡯ࡤ࠸࠵࠶ࠧᏧ")		:QQSULIva4ljNO73mFcWw(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧᏨ")
	,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࡮ࡤࡶࡴࢀࡡࠨᏩ")		:Q1QS6w8saLEuPW0O7XjlipekBTbq(u"่ࠩ์็฿ࠠๅษิ์ือࠧᏪ")
	,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡽࡦࡷ࡯ࡵࠩᏫ")		:Q1QS6w8saLEuPW0O7XjlipekBTbq(u"๊ࠫ๎โฺࠢํห็๎สࠨᏬ")
	,B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧᏭ")		:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪᏮ")
	,onweDvmTOUj(u"ࠧ࡬ࡣࡷ࡯ࡴࡺࡴࡷࠩᏯ")		:Q2ZyGqCNYsftTc4MR7n(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠥะ๊โ์ࠪᏰ")
	,mtEXp14ijx(u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧᏱ")	:hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬᏲ")
	,onweDvmTOUj(u"ࠫࡩࡸࡡ࡮ࡣࡶ࠻ࠬᏳ")		:d0HDrq8Rtk16AlInw4TXb(u"๋่ࠬใ฻ࠣำึอๅศุࠢัࠬᏴ")
	,gy9NA3CROZolfEt4vVzMr(u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨᏵ")		:lh6URegmQNq8LWX0HaK5(u"ࠧๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭᏶")
	,mtEXp14ijx(u"ࠨ࡫ࡩ࡭ࡱࡳࠧ᏷")				:Q2ZyGqCNYsftTc4MR7n(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭ᏸ")
	,eaF2N0jWLdvHIs8r(u"ࠪ࡭࡫࡯࡬࡮࠯ࡤࡶࡦࡨࡩࡤࠩᏹ")			:gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ᏺ")
	,d0HDrq8Rtk16AlInw4TXb(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡪࡴࡧ࡭࡫ࡶ࡬ࠬᏻ")		:RS7ZoyGAq1c(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣห๋าไ๋ิํࠫᏼ")
	,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡱࡣࡱࡩࡹ࠭ᏽ")				:WWbmNvI40sM9Khlp25Ae(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠬ᏾")
	,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡳࡥࡳ࡫ࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ᏿")			:aSf0iWG1kA7FsqjHbuC8NXB(u"้ࠪํู่ࠡสส๊๏ะࠠศใ็ห๊࠭᐀")
	,lh6URegmQNq8LWX0HaK5(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡷࡪࡸࡩࡦࡵࠪᐁ")			:a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"๋่ࠬใ฻ࠣฬฬ์๊ห่ࠢืู้ไศฬࠪᐂ")
	,d0HDrq8Rtk16AlInw4TXb(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᐃ")				:LsG7EDcei1gMShH2aVOCo(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬᐄ")
	,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠩᐅ")		:WWbmNvI40sM9Khlp25Ae(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩᐆ")
	,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧᐇ")	:a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨᐈ")
	,eaF2N0jWLdvHIs8r(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨᐉ")		:a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪᐊ")
	,onweDvmTOUj(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧࠪᐋ")			:gy9NA3CROZolfEt4vVzMr(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪᐌ")
	,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡶࡥࡳࡵࡲࡲࡸ࠭ᐍ")	:OnvTrikzfEsY7qU8pgaRBtZy(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪᐎ")
	,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧᐏ")		:nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭ᐐ")
	,eaF2N0jWLdvHIs8r(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩᐑ")		:Sj1PYDmIpCUXO26(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩᐒ")
	,NQ4hg16DPUxtOyo5iGb(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ᐓ")			:Jbu2G0Qax8PYWpg(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠪᐔ")
	,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨᐕ")	:MOwK1lpyNfCgqksX3jhV(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧᐖ")
	,onweDvmTOUj(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ᐗ"):RS7ZoyGAq1c(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠใ๊สส๊࠭ᐘ")
	,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧᐙ")	:KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ๊ํอสࠨᐚ")
	,B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡵࡱࡳ࡭ࡨࡹࠧᐛ")	:Jbu2G0Qax8PYWpg(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫᐜ")
	,LsG7EDcei1gMShH2aVOCo(u"ࠫ࡮ࡶࡴࡷࠩᐝ")					:eaF2N0jWLdvHIs8r(u"ࠬࡏࡐࡕࡘࠪᐞ")
	,aSf0iWG1kA7FsqjHbuC8NXB(u"࠭ࡩࡱࡶࡹ࠱ࡱ࡯ࡶࡦࠩᐟ")			:lh6URegmQNq8LWX0HaK5(u"ࠧࡊࡒࡗ่࡚ࠥๆ้ษอࠫᐠ")
	,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࡫ࡳࡸࡻ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᐡ")			:QQSULIva4ljNO73mFcWw(u"ࠩࡌࡔ࡙࡜ࠠฤใ็ห๊࠭ᐢ")
	,Jbu2G0Qax8PYWpg(u"ࠪ࡭ࡵࡺࡶ࠮ࡵࡨࡶ࡮࡫ࡳࠨᐣ")			:S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡎࡖࡔࡗ่ࠢืู้ไศฬࠪᐤ")
	,onweDvmTOUj(u"ࠬࡳ࠳ࡶࠩᐥ")					:OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡍ࠴ࡗࠪᐦ")
	,mtEXp14ijx(u"ࠧ࡮࠵ࡸ࠱ࡱ࡯ࡶࡦࠩᐧ")				:Sj1PYDmIpCUXO26(u"ࠨࡏ࠶่࡙ࠥๆ้ษอࠫᐨ")
	,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡰ࠷ࡺ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᐩ")			:WWbmNvI40sM9Khlp25Ae(u"ࠪࡑ࠸࡛ࠠฤใ็ห๊࠭ᐪ")
	,Sj1PYDmIpCUXO26(u"ࠫࡲ࠹ࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠨᐫ")			:Q2ZyGqCNYsftTc4MR7n(u"ࠬࡓ࠳ࡖ่ࠢืู้ไศฬࠪᐬ")
	}
	try: jjDtkT6qOMFN8lzXieyvmQfEoLR9 = BBfZsykd59zUX4HL7l0qDcuM[FbewQr7IVXqN0ijhOtm2vAnauzZT.lower()]
	except: jjDtkT6qOMFN8lzXieyvmQfEoLR9 = onweDvmTOUj(u"࠭ࠧᐭ")
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def YosJW4Tklp2IyQ0jPnam(RkL9ljZpIhdrutK0OmN7Uc=gy9NA3CROZolfEt4vVzMr(u"ࠧࠨᐮ")):
	f8CtAYn6NTQc()
	if not RkL9ljZpIhdrutK0OmN7Uc: RkL9ljZpIhdrutK0OmN7Uc = NQ4hg16DPUxtOyo5iGb(u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡇࡻ࡭ࡹ࠭ᐯ")
	xrFqGMab4uLKZcS(RS7ZoyGAq1c(u"ࠩࠪᐰ"),Q2ZyGqCNYsftTc4MR7n(u"ࠪࡠࡳ࠭ᐱ")+RkL9ljZpIhdrutK0OmN7Uc+NQ4hg16DPUxtOyo5iGb(u"ࠫࡡࡴࠧᐲ"))
	try: EuOf9ozUdyP.exit()
	except: pass
	return
def TbEVs6mLPHF(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,HHKyRAzcLUEipGn1Yrs=LsG7EDcei1gMShH2aVOCo(u"ࠬࡀ࠯ࠨᐳ")):
	return _6t8C3Q1Wu7e(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,HHKyRAzcLUEipGn1Yrs)
def aIztR1qB5nEuyWDGmvj7ibK(heXizOAPcHCdLZnwBVoql7py):
	if heXizOAPcHCdLZnwBVoql7py in [nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࠧᐴ"),Sj1PYDmIpCUXO26(u"ࠧ࠱ࠩᐵ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠳ᛘ")]: return gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࠩᐶ")
	heXizOAPcHCdLZnwBVoql7py = int(heXizOAPcHCdLZnwBVoql7py)
	vKmLBs2rPqQzIwHD6bnx7tj = heXizOAPcHCdLZnwBVoql7py^IIbavC96MQ1nHq3Pjx
	PZy5dgXqHze7O3UCD6cN = heXizOAPcHCdLZnwBVoql7py^jj0C6IlvPFh
	WT3gDkPVsqNYZFtCh8vQS15iAuxL = heXizOAPcHCdLZnwBVoql7py^sJF0ga5tzvlRZWK3Xb9
	jjDtkT6qOMFN8lzXieyvmQfEoLR9 = str(vKmLBs2rPqQzIwHD6bnx7tj)+str(PZy5dgXqHze7O3UCD6cN)+str(WT3gDkPVsqNYZFtCh8vQS15iAuxL)
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def Pe0ILG984ZC1vcyFpKX25DNwdzEHa(heXizOAPcHCdLZnwBVoql7py):
	if heXizOAPcHCdLZnwBVoql7py in [WWbmNvI40sM9Khlp25Ae(u"ࠩࠪᐷ"),hxSBTdGpyNVbfu4tr9(u"ࠪ࠴ࠬᐸ"),gy9NA3CROZolfEt4vVzMr(u"࠴ᛙ")]: return NQ4hg16DPUxtOyo5iGb(u"ࠫࠬᐹ")
	heXizOAPcHCdLZnwBVoql7py = str(heXizOAPcHCdLZnwBVoql7py)
	jjDtkT6qOMFN8lzXieyvmQfEoLR9 = d0HDrq8Rtk16AlInw4TXb(u"ࠬ࠭ᐺ")
	if len(heXizOAPcHCdLZnwBVoql7py)==onweDvmTOUj(u"࠶࠻ᛚ"):
		vKmLBs2rPqQzIwHD6bnx7tj,PZy5dgXqHze7O3UCD6cN,WT3gDkPVsqNYZFtCh8vQS15iAuxL = heXizOAPcHCdLZnwBVoql7py[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠰ᛜ"):lh6URegmQNq8LWX0HaK5(u"࠵ᛝ")],heXizOAPcHCdLZnwBVoql7py[lh6URegmQNq8LWX0HaK5(u"࠵ᛝ"):gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠿ᛛ")],heXizOAPcHCdLZnwBVoql7py[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠿ᛛ"):]
		vKmLBs2rPqQzIwHD6bnx7tj = int(vKmLBs2rPqQzIwHD6bnx7tj)^sJF0ga5tzvlRZWK3Xb9
		PZy5dgXqHze7O3UCD6cN = int(PZy5dgXqHze7O3UCD6cN)^jj0C6IlvPFh
		WT3gDkPVsqNYZFtCh8vQS15iAuxL = int(WT3gDkPVsqNYZFtCh8vQS15iAuxL)^IIbavC96MQ1nHq3Pjx
		if vKmLBs2rPqQzIwHD6bnx7tj==PZy5dgXqHze7O3UCD6cN==WT3gDkPVsqNYZFtCh8vQS15iAuxL: jjDtkT6qOMFN8lzXieyvmQfEoLR9 = str(vKmLBs2rPqQzIwHD6bnx7tj*Rz34c0NP5BGo1WuTZxSfOKj(u"࠸࠳ᛞ"))
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def QwCLPy3hNTm(heXizOAPcHCdLZnwBVoql7py,IcqAEG0aFgeXh9W=hxSBTdGpyNVbfu4tr9(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᐻ")):
	if heXizOAPcHCdLZnwBVoql7py==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࠨᐼ"): return QQSULIva4ljNO73mFcWw(u"ࠨࠩᐽ")
	heXizOAPcHCdLZnwBVoql7py = int(heXizOAPcHCdLZnwBVoql7py)+int(IcqAEG0aFgeXh9W)
	vKmLBs2rPqQzIwHD6bnx7tj = heXizOAPcHCdLZnwBVoql7py^IIbavC96MQ1nHq3Pjx
	PZy5dgXqHze7O3UCD6cN = heXizOAPcHCdLZnwBVoql7py^jj0C6IlvPFh
	WT3gDkPVsqNYZFtCh8vQS15iAuxL = heXizOAPcHCdLZnwBVoql7py^sJF0ga5tzvlRZWK3Xb9
	jjDtkT6qOMFN8lzXieyvmQfEoLR9 = str(vKmLBs2rPqQzIwHD6bnx7tj)+str(PZy5dgXqHze7O3UCD6cN)+str(WT3gDkPVsqNYZFtCh8vQS15iAuxL)
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def dX3jmwBTHhEp5UW2MAZ4fzk6(heXizOAPcHCdLZnwBVoql7py,IcqAEG0aFgeXh9W=QQSULIva4ljNO73mFcWw(u"ࠩ࠹࠷࠽࠺࠱࠹࠴࠶ࠫᐾ")):
	if heXizOAPcHCdLZnwBVoql7py==IPkQW7LojF3HO18V(u"ࠪࠫᐿ"): return q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࠬᑀ")
	heXizOAPcHCdLZnwBVoql7py = str(heXizOAPcHCdLZnwBVoql7py)
	wwbWlQeZCfk9tG = int(len(heXizOAPcHCdLZnwBVoql7py)/aSf0iWG1kA7FsqjHbuC8NXB(u"࠶ᛟ"))
	vKmLBs2rPqQzIwHD6bnx7tj = int(heXizOAPcHCdLZnwBVoql7py[MOwK1lpyNfCgqksX3jhV(u"࠴ᛠ"):wwbWlQeZCfk9tG])^IIbavC96MQ1nHq3Pjx
	PZy5dgXqHze7O3UCD6cN = int(heXizOAPcHCdLZnwBVoql7py[wwbWlQeZCfk9tG:IPkQW7LojF3HO18V(u"࠷ᛡ")*wwbWlQeZCfk9tG])^jj0C6IlvPFh
	WT3gDkPVsqNYZFtCh8vQS15iAuxL = int(heXizOAPcHCdLZnwBVoql7py[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠲ᛣ")*wwbWlQeZCfk9tG:nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠹ᛢ")*wwbWlQeZCfk9tG])^sJF0ga5tzvlRZWK3Xb9
	jjDtkT6qOMFN8lzXieyvmQfEoLR9 = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭ᑁ")
	if vKmLBs2rPqQzIwHD6bnx7tj==PZy5dgXqHze7O3UCD6cN==WT3gDkPVsqNYZFtCh8vQS15iAuxL: jjDtkT6qOMFN8lzXieyvmQfEoLR9 = str(int(vKmLBs2rPqQzIwHD6bnx7tj)-int(IcqAEG0aFgeXh9W))
	return jjDtkT6qOMFN8lzXieyvmQfEoLR9
def P8URX9agvseubL7xqFKthZ(VV1mHn6RZE):
	yin3vDq14HhxOVpLWU = ZEgwHfRnFV4[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᑂ")][RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠹ᛤ")]
	xLe7j4MsN9A8l0aciOTbRDSIP3mUFt = vT7q0oj96p(Rz34c0NP5BGo1WuTZxSfOKj(u"࠵࠵ᛥ"))
	mjJCe1x8d0OSgFwTBhY2 = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪᑃ"),hxSBTdGpyNVbfu4tr9(u"ࠨࡵ࡮࡭ࡳࡹࠧᑄ"),RS7ZoyGAq1c(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪᑅ"),eaF2N0jWLdvHIs8r(u"ࠪ࠻࠷࠶ࡰࠨᑆ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ᑇ"))
	LwyiOGpzqKvDZRncebQJj,cU9q0h2AC46XBHrbsd8jkRF = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(mjJCe1x8d0OSgFwTBhY2)
	LwyiOGpzqKvDZRncebQJj = QwCLPy3hNTm(LwyiOGpzqKvDZRncebQJj,IPkQW7LojF3HO18V(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨᑈ"))
	FHbOaNZMmTGPxD7rUA = {mtEXp14ijx(u"࠭ࡩࡥࡵࠪᑉ"):a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡅࡋࡄࡐࡔࡍࠧᑊ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡷࡶࡶࠬᑋ"):xLe7j4MsN9A8l0aciOTbRDSIP3mUFt,IPkQW7LojF3HO18V(u"ࠩࡹࡩࡷ࠭ᑌ"):Y0Uhv2t8E67,mtEXp14ijx(u"ࠪࡷࡨࡸࠧᑍ"):VV1mHn6RZE,B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡸ࡯ࡺࠨᑎ"):LwyiOGpzqKvDZRncebQJj}
	BBhWlEOckbS = {RS7ZoyGAq1c(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᑏ"):gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᑐ")}
	eCYQwR7qX03iA8fZn = eWltKEO6ar3XBdZ(jj0C6IlvPFh,FZBX5WcC3msIDv4hobLd8(u"ࠧࡑࡑࡖࡘࠬᑑ"),yin3vDq14HhxOVpLWU,FHbOaNZMmTGPxD7rUA,BBhWlEOckbS,mtEXp14ijx(u"ࠨࠩᑒ"),gy9NA3CROZolfEt4vVzMr(u"ࠩࠪᑓ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡓࡐࡆ࡟࡟ࡅࡋࡄࡐࡔࡍ࠭࠲ࡵࡷࠫᑔ"))
	AdsV6xRZgFyCcLvtfEX7r = eCYQwR7qX03iA8fZn.content
	try:
		if not AdsV6xRZgFyCcLvtfEX7r: x7qROKQnBmsukvjpS
		QTaBxnovq8ugPkw = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(lh6URegmQNq8LWX0HaK5(u"ࠫࡩ࡯ࡣࡵࠩᑕ"),AdsV6xRZgFyCcLvtfEX7r)
		zpawJstogxZNBHVCeE = QTaBxnovq8ugPkw[FZBX5WcC3msIDv4hobLd8(u"ࠬࡳࡳࡨࠩᑖ")]
		xxMoF6aNJlB = QTaBxnovq8ugPkw[Sj1PYDmIpCUXO26(u"࠭ࡳࡦࡥࠪᑗ")]
		VKD2oOcte930wIh4FxyrX = QTaBxnovq8ugPkw[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡴࡶࡳࠫᑘ")]
		xxMoF6aNJlB = int(dX3jmwBTHhEp5UW2MAZ4fzk6(xxMoF6aNJlB,eaF2N0jWLdvHIs8r(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᑙ")))
		VKD2oOcte930wIh4FxyrX = int(dX3jmwBTHhEp5UW2MAZ4fzk6(VKD2oOcte930wIh4FxyrX,Jbu2G0Qax8PYWpg(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᑚ")))
		for gkm9ud42G3Dz0p in range(xxMoF6aNJlB,QQSULIva4ljNO73mFcWw(u"࠳ᛦ"),-VKD2oOcte930wIh4FxyrX):
			if not eval(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠬ࠮࠭ᑛ"),{gy9NA3CROZolfEt4vVzMr(u"ࠫࡽࡨ࡭ࡤࠩᑜ"):WCdaXB2bfwyI0S3Fqet1LQoO5Rhv}): x7qROKQnBmsukvjpS
			NCXj2ri3Unm6TFWIgwh(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬฮวใ์่้ࠣะฬาสฬࠤํอไโฯุࠫᑝ"),str(gkm9ud42G3Dz0p)+Sj1PYDmIpCUXO26(u"࠭ࠠࠡอส๊๏ฯࠧᑞ"),p1BoraOuWL=q6yUEoKVDb0fXmc8vhrMk7N(u"࠷࠵࠶ᛧ")*VKD2oOcte930wIh4FxyrX)
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.sleep(WWbmNvI40sM9Khlp25Ae(u"࠶࠶࠰࠱ᛨ")*VKD2oOcte930wIh4FxyrX)
		if eval(LsG7EDcei1gMShH2aVOCo(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪᑟ"),{LsG7EDcei1gMShH2aVOCo(u"ࠨࡺࡥࡱࡨ࠭ᑠ"):WCdaXB2bfwyI0S3Fqet1LQoO5Rhv}):
			zpawJstogxZNBHVCeE = zpawJstogxZNBHVCeE.replace(MOwK1lpyNfCgqksX3jhV(u"ࠩ࡟ࡲࠬᑡ"),QQSULIva4ljNO73mFcWw(u"ࠪࡠࡡࡴࠧᑢ")).replace(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡡࡸࠧᑣ"),mtEXp14ijx(u"ࠬࡢ࡜ࡳࠩᑤ"))
			ztgqWUaDpe8CE9N(Y5npATFarf1H9wBjc87(u"࠭ࠧᑥ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧฯำ๋ะࠬᑦ"),FZBX5WcC3msIDv4hobLd8(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᑧ"),zpawJstogxZNBHVCeE)
		x7qROKQnBmsukvjpS
	except: exec(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩᑨ"),{onweDvmTOUj(u"ࠪࡼࡧࡳࡣࠨᑩ"):WCdaXB2bfwyI0S3Fqet1LQoO5Rhv})
	return
def AVqEo6OQfidWSLhvJjPke0RYtaM2gz():
	exec(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࠬ࠭ࠍࠋࡶࡵࡽ࠿ࠓࠊࠊࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶ࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡘ࡫ࡱࡨࡴࡽࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࡺ࡬࡮ࡲࡥࠡࡖࡵࡹࡪࡀࠍࠋࠋࠌࡼࡧࡳࡣ࠯ࡵ࡯ࡩࡪࡶࠨ࠲࠲࠳࠴࠮ࠓࠊࠊࠋࡷࡶࡾࡀࠠࡸ࡫ࡱࡨࡴࡽ࠱࠳࠵࠱࡫ࡪࡺࡆࡰࡥࡸࡷ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡥࡶࡪࡧ࡫ࠎࠌࠌࡾࡨࡸࡥࡢࡶࡨࡣࡪࡸ࡯ࡳࡴࠐࠎࡪࡾࡣࡦࡲࡷ࠾ࠥࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠒࠐࠧࠨࠩᑪ"),{nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡾࡢ࡮ࡥࡪࡹ࡮࠭ᑫ"):N7zpvB3VIPrwcSDEC,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡸࡣ࡯ࡦࠫᑬ"):WCdaXB2bfwyI0S3Fqet1LQoO5Rhv})
	return
def Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(upZ1BNCklGOvjiJ8Q):
	VjkbN2rgJM7C3RX,PmtdDvIykT7qxfB = hxSBTdGpyNVbfu4tr9(u"࠶ᛩ"),hxSBTdGpyNVbfu4tr9(u"࠶ᛩ")
	if Dh9MOxeTj6FW.path.exists(upZ1BNCklGOvjiJ8Q):
		try: VjkbN2rgJM7C3RX = Dh9MOxeTj6FW.path.getsize(upZ1BNCklGOvjiJ8Q)
		except: pass
		if not VjkbN2rgJM7C3RX:
			try: VjkbN2rgJM7C3RX = Dh9MOxeTj6FW.stat(upZ1BNCklGOvjiJ8Q).st_size
			except: pass
		if not VjkbN2rgJM7C3RX:
			try:
				from pathlib import Path as ljEvUcT5V6D3RWpGZh4JLyfCXYur
				VjkbN2rgJM7C3RX = ljEvUcT5V6D3RWpGZh4JLyfCXYur(upZ1BNCklGOvjiJ8Q).stat().st_size
			except: pass
		if VjkbN2rgJM7C3RX: PmtdDvIykT7qxfB = q6yUEoKVDb0fXmc8vhrMk7N(u"࠱ᛪ")
	return VjkbN2rgJM7C3RX,PmtdDvIykT7qxfB
def IlTEWy8f4bpjLa7UR0c2qDY6S15Q(GGSlhCZrtEU5uwido0KFXmnQ,I0lGwDgQhb,showDialogs):
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(Y5npATFarf1H9wBjc87(u"ࠧࠨᑭ"),Q2ZyGqCNYsftTc4MR7n(u"ࠨࠩᑮ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠪᑯ"),Sj1PYDmIpCUXO26(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᑰ"),GGSlhCZrtEU5uwido0KFXmnQ+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡡࡴ࡜࡯ࠩᑱ")+eaF2N0jWLdvHIs8r(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑲ"))
		if svOyXbipkwY!=gy9NA3CROZolfEt4vVzMr(u"࠲᛫"): return
	ESuf43dwJmkx1NtG = d0HDrq8Rtk16AlInw4TXb(u"ࡉࡥࡱࡹࡥᝤ")
	if Dh9MOxeTj6FW.path.exists(GGSlhCZrtEU5uwido0KFXmnQ):
		for e6O2FCPu54lBwk,AuoU3pNCiLWxlKYOHh8QmwqS41kz,ggpYWrvRkuJCa5z1eP49OBHsm in Dh9MOxeTj6FW.walk(GGSlhCZrtEU5uwido0KFXmnQ,topdown=hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡊࡦࡲࡳࡦᝥ")):
			for upZ1BNCklGOvjiJ8Q in ggpYWrvRkuJCa5z1eP49OBHsm:
				XR8BCkPdMhOY7y1VpWoNsuG = Dh9MOxeTj6FW.path.join(e6O2FCPu54lBwk,upZ1BNCklGOvjiJ8Q)
				try: Dh9MOxeTj6FW.remove(XR8BCkPdMhOY7y1VpWoNsuG)
				except Exception as wl7sKIoZfU:
					if showDialogs and not ESuf43dwJmkx1NtG: ztgqWUaDpe8CE9N(WWbmNvI40sM9Khlp25Ae(u"࠭ࠧᑳ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࠨᑴ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᑵ"),str(wl7sKIoZfU))
					ESuf43dwJmkx1NtG = B2vCEI9FAVP15R8eUbDJdySc(u"࡙ࡸࡵࡦᝦ")
			if I0lGwDgQhb:
				for dir in AuoU3pNCiLWxlKYOHh8QmwqS41kz:
					unB4qv2689foKhaEZPkH = Dh9MOxeTj6FW.path.join(e6O2FCPu54lBwk,dir)
					try: Dh9MOxeTj6FW.rmdir(unB4qv2689foKhaEZPkH)
					except: pass
		if I0lGwDgQhb:
			try: Dh9MOxeTj6FW.rmdir(e6O2FCPu54lBwk)
			except: pass
	if showDialogs and not ESuf43dwJmkx1NtG:
		ztgqWUaDpe8CE9N(Jbu2G0Qax8PYWpg(u"ࠩࠪᑶ"),onweDvmTOUj(u"ࠪࠫᑷ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᑸ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᑹ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᑺ"),Sj1PYDmIpCUXO26(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᑻ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᑼ"))
	return
def f8CtAYn6NTQc(zi68Y9T7ngdIXKALbv3fjVEeOJm=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪᑽ")):
	xmYBAMKujEkvWUpV(lh6URegmQNq8LWX0HaK5(u"ࠪࡷࡹࡵࡰࠨᑾ"))
	if zi68Y9T7ngdIXKALbv3fjVEeOJm:
		Ir3WTjlbGkicSQ = LCIFdjzi5kVmRwehouHQ.getSetting(NQ4hg16DPUxtOyo5iGb(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᑿ"))
		LCIFdjzi5kVmRwehouHQ.setSetting(hxSBTdGpyNVbfu4tr9(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ᒀ"),MOwK1lpyNfCgqksX3jhV(u"࠭ࠧᒁ"))
		xxEnCy9DI0(zi68Y9T7ngdIXKALbv3fjVEeOJm)
		LCIFdjzi5kVmRwehouHQ.setSetting(Y5npATFarf1H9wBjc87(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨᒂ"),Ir3WTjlbGkicSQ)
	sF0NOtG4b1RY = LCIFdjzi5kVmRwehouHQ.getSetting(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᒃ"))
	if sF0NOtG4b1RY==Jbu2G0Qax8PYWpg(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬᒄ"): LCIFdjzi5kVmRwehouHQ.setSetting(LsG7EDcei1gMShH2aVOCo(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᒅ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧᒆ"))
	elif sF0NOtG4b1RY==Jbu2G0Qax8PYWpg(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨᒇ"): LCIFdjzi5kVmRwehouHQ.setSetting(gy9NA3CROZolfEt4vVzMr(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᒈ"),QQSULIva4ljNO73mFcWw(u"ࠧࠨᒉ"))
	if LCIFdjzi5kVmRwehouHQ.getSetting(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᒊ")) not in [RS7ZoyGAq1c(u"ࠩࡄ࡙࡙ࡕࠧᒋ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡗ࡙ࡕࡐࠨᒌ"),MOwK1lpyNfCgqksX3jhV(u"ࠫࡆ࡙ࡋࠨᒍ")]: LCIFdjzi5kVmRwehouHQ.setSetting(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᒎ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡁࡔࡍࠪᒏ"))
	if LCIFdjzi5kVmRwehouHQ.getSetting(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᒐ")) not in [hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡃࡘࡘࡔ࠭ᒑ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡖࡘࡔࡖࠧᒒ"),eaF2N0jWLdvHIs8r(u"ࠪࡅࡘࡑࠧᒓ")]: LCIFdjzi5kVmRwehouHQ.setSetting(lh6URegmQNq8LWX0HaK5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᒔ"),RS7ZoyGAq1c(u"ࠬࡇࡓࡌࠩᒕ"))
	zfvDmBkquSpdIYwhoK = LCIFdjzi5kVmRwehouHQ.getSetting(eaF2N0jWLdvHIs8r(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫᒖ"))
	IuorNOL7BDiSbPlJQkh4jZ6Fapm = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(IPkQW7LojF3HO18V(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᒗ"))
	if IPkQW7LojF3HO18V(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᒘ") in str(IuorNOL7BDiSbPlJQkh4jZ6Fapm) and zfvDmBkquSpdIYwhoK in [WWbmNvI40sM9Khlp25Ae(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬᒙ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩᒚ")]:
		p1BoraOuWL.sleep(gy9NA3CROZolfEt4vVzMr(u"࠲࠱࠵࠵࠶᛬"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨᒛ"))
	if LsG7EDcei1gMShH2aVOCo(u"࠴ᛮ") and yR8fePHkvJnx3K0FQVs>-eaF2N0jWLdvHIs8r(u"࠴᛭"):
		YRyCdPm9JnNZ5vf.setResolvedUrl(yR8fePHkvJnx3K0FQVs,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࡌࡡ࡭ࡵࡨᝧ"),N7zpvB3VIPrwcSDEC.ListItem())
		sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG = q6yUEoKVDb0fXmc8vhrMk7N(u"ࡆࡢ࡮ࡶࡩᝨ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࡆࡢ࡮ࡶࡩᝨ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࡆࡢ࡮ࡶࡩᝨ")
		YRyCdPm9JnNZ5vf.endOfDirectory(yR8fePHkvJnx3K0FQVs,sycSign827ZrEldIB,yTeWrgfPFSVGEHu3,LPTX2VA6NHqh0KOG)
	return
def Gtm9xLq6A5YoceJfb3P(LLfosSIikqUgKAG9hOVTZWrel6mHu,QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,bINq5DWsFP7yY29ioHwX8ECS,XXifFpsbwRoKkZx8aQ0AI7dHty5M,aKNfrBALZy8o = TJz3Sp4aIx5V(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	iJe1DukCLnsTtyRZp = QOS2sIxvb8JZ70,vfIB6ib8q1hFX5GweRrVPNTjY2E,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2
	if LLfosSIikqUgKAG9hOVTZWrel6mHu:
		mmhS2KFYI4eC6HWgk1trq = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,d0HDrq8Rtk16AlInw4TXb(u"ࠬࡹࡴࡳࠩᒜ"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᒝ"),iJe1DukCLnsTtyRZp)
		if mmhS2KFYI4eC6HWgk1trq:
			wFhHDd7gy6kesnTY4AVMLiU5aXGu8(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬᒞ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY,QOS2sIxvb8JZ70)
			return mmhS2KFYI4eC6HWgk1trq
	mmhS2KFYI4eC6HWgk1trq = EEXl7ByjFiqO(QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY)
	if mmhS2KFYI4eC6HWgk1trq and LLfosSIikqUgKAG9hOVTZWrel6mHu: F4QxJHhsMj(qQ4BC6vW5YOfo,Sj1PYDmIpCUXO26(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩᒟ"),iJe1DukCLnsTtyRZp,mmhS2KFYI4eC6HWgk1trq,LLfosSIikqUgKAG9hOVTZWrel6mHu)
	return mmhS2KFYI4eC6HWgk1trq
from n8VlQEiJj5 import *
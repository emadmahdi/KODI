# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SHIAVOICE'
ToYWiIbruzUaNKRPZLG16cAj = '_SHV_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
headers = {'User-Agent':None}
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==310: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==311: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==312: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==313: rr60PDpqbMehZsYVuHmiAtN = oGQkR1PAiMTNpq2c(url)
	elif mode==314: rr60PDpqbMehZsYVuHmiAtN = DrWQf8PNSAwocLyKviszal(text)
	elif mode==319: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','SHIAVOICE-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="menulinks"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = SomeI8i56FaDMGPE.findall('<h5>(.*?)</h5>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	for XBMyFqAriL in range(len(items)):
		title = items[XBMyFqAriL].strip(' ')
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,aaeRjxiYcqOI6Sf8,314,'','',str(XBMyFqAriL+1))
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مقاطع شهر',aaeRjxiYcqOI6Sf8,314,'','','0')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<B>(.*?)</B>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,311)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def DrWQf8PNSAwocLyKviszal(XBMyFqAriL):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,'','','','','SHIAVOICE-LATEST-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if XBMyFqAriL=='0':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="tab-content"(.*?)</table>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312)
	elif XBMyFqAriL in ['1','2','3']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(<h5>.*?)<div class="col-lg',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		iiAUovLVTfHpcZ9b1qw = int(XBMyFqAriL)-1
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[iiAUovLVTfHpcZ9b1qw]
		if XBMyFqAriL=='1': items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		else: items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title,name in items:
			pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,311,pjMZ802XQCSxYVk)
	elif XBMyFqAriL in ['4','5','6']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(<h5>.*?)</table>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		XBMyFqAriL = int(XBMyFqAriL)-4
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[XBMyFqAriL]
		items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,LmVdjhDqCzb4e2y5YOr,title,Fc3PbKsrWIt150De4wYGqmay82X in items:
			pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title.strip(' ')
			LmVdjhDqCzb4e2y5YOr = LmVdjhDqCzb4e2y5YOr.strip(' ')
			Fc3PbKsrWIt150De4wYGqmay82X = Fc3PbKsrWIt150De4wYGqmay82X.strip(' ')
			if LmVdjhDqCzb4e2y5YOr: name = LmVdjhDqCzb4e2y5YOr
			else: name = Fc3PbKsrWIt150De4wYGqmay82X
			title = title+' ('+name+')'
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312,pjMZ802XQCSxYVk)
	return
def KKlnDcetq8Rrp3GY0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('ibox-heading"(.*?)class="float-right',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if 'catsum-mobile' in L0Uwx52bTBM:
		items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title,count in items:
				pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,311,pjMZ802XQCSxYVk)
	else:
		items = SomeI8i56FaDMGPE.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,zs81DFhIYlwni3UPKxWLVuOAf6BT2N,DD1IVWFZbr7TlzYto5s in items:
			if title=='' or zs81DFhIYlwni3UPKxWLVuOAf6BT2N=='': continue
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title+' ('+DD1IVWFZbr7TlzYto5s+')'
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312)
	if not items: ooLCwrlF3n0vBjpA(BsJ71WIxDtdFKveTcRPrqM4Cwb)
	return
def ooLCwrlF3n0vBjpA(BsJ71WIxDtdFKveTcRPrqM4Cwb):
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="ibox-content"(.*?)class="pagination',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title,name,count,DD1IVWFZbr7TlzYto5s in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312,'',DD1IVWFZbr7TlzYto5s)
	return
def oGQkR1PAiMTNpq2c(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="ibox-content p-1"(.*?)class="ibox-content"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd:
		KKlnDcetq8Rrp3GY0(url)
		return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<strong>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
		title = title.strip(' ')
		if '/play-' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,311)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<audio.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<video.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R[0]
	kFygcp2jqSUCiNRnur71xMZI96(ZcAK0askvzIWr4R,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	rracOF9vjlY = ['&t=a','&t=c','&t=s']
	if showDialogs:
		Hgj7JEvyUisXckz = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع صوت الشيعة - أختر البحث', Hgj7JEvyUisXckz)
		if I7mfbGiWNFcBVJOn == -1: return
	elif '_SHIAVOICE-PERSONS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: I7mfbGiWNFcBVJOn = 0
	elif '_SHIAVOICE-ALBUMS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: I7mfbGiWNFcBVJOn = 1
	elif '_SHIAVOICE-AUDIOS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: I7mfbGiWNFcBVJOn = 2
	else: return
	type = rracOF9vjlY[I7mfbGiWNFcBVJOn]
	url = aaeRjxiYcqOI6Sf8+'/search.php?q='+search+type
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="ibox-content"(.*?)class="ibox-content"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		if I7mfbGiWNFcBVJOn in [0,1]:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,313,pjMZ802XQCSxYVk)
		elif I7mfbGiWNFcBVJOn==2:
			items = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,312)
	return
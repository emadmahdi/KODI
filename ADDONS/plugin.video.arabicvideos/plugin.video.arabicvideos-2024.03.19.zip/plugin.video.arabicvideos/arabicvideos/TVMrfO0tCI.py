# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = WWbmNvI40sM9Khlp25Ae(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def GI13aCFr0qimdOT(lOH3hXsnQiFCRjbN12,eesaHQO5yPGNvopTtWzR):
	if   lOH3hXsnQiFCRjbN12==eaF2N0jWLdvHIs8r(u"࠷࠸࠶৪"): rr60PDpqbMehZsYVuHmiAtN = Ablt4aoY9LTDNrRXc1WJ2P56()
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠸࠹࠱৫"): rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(eesaHQO5yPGNvopTtWzR)
	elif lOH3hXsnQiFCRjbN12==LsG7EDcei1gMShH2aVOCo(u"࠹࠳࠳৬"): rr60PDpqbMehZsYVuHmiAtN = icBSd3e9LXjJyG6()
	elif lOH3hXsnQiFCRjbN12==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠳࠴࠵৭"): rr60PDpqbMehZsYVuHmiAtN = dmCWX4IfxzHpYjts6iUaQL7Zcu1bM()
	elif lOH3hXsnQiFCRjbN12==OnvTrikzfEsY7qU8pgaRBtZy(u"࠴࠵࠷৮"): rr60PDpqbMehZsYVuHmiAtN = yy80NrDmqvhQukZOSgKpa4Pi6(eesaHQO5yPGNvopTtWzR)
	else: rr60PDpqbMehZsYVuHmiAtN = hxSBTdGpyNVbfu4tr9(u"ࡋࡧ࡬ࡴࡧਜ")
	return rr60PDpqbMehZsYVuHmiAtN
def yy80NrDmqvhQukZOSgKpa4Pi6(XOSoqUF6k8EL):
	try: Dh9MOxeTj6FW.remove(XOSoqUF6k8EL.decode(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: Dh9MOxeTj6FW.remove(XOSoqUF6k8EL)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(eesaHQO5yPGNvopTtWzR):
	kFygcp2jqSUCiNRnur71xMZI96(eesaHQO5yPGNvopTtWzR,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def dmCWX4IfxzHpYjts6iUaQL7Zcu1bM():
	QQONb7aR2M6L = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	ztgqWUaDpe8CE9N(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠭ठ"),RS7ZoyGAq1c(u"࠭ࠧड"),IPkQW7LojF3HO18V(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),QQONb7aR2M6L)
	return
def Ablt4aoY9LTDNrRXc1WJ2P56():
	UZ8LYnm5jsl9uKM0xDX(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࡮࡬ࡲࡰ࠭ण"),WWbmNvI40sM9Khlp25Ae(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),MOwK1lpyNfCgqksX3jhV(u"ࠪࠫथ"),onweDvmTOUj(u"࠵࠶࠷৯"))
	UZ8LYnm5jsl9uKM0xDX(LsG7EDcei1gMShH2aVOCo(u"ࠫࡱ࡯࡮࡬ࠩद"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),FZBX5WcC3msIDv4hobLd8(u"࠭ࠧन"),FZBX5WcC3msIDv4hobLd8(u"࠶࠷࠷ৰ"))
	UZ8LYnm5jsl9uKM0xDX(NQ4hg16DPUxtOyo5iGb(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),onweDvmTOUj(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࠪफ"),gy9NA3CROZolfEt4vVzMr(u"࠽࠾࠿࠹ৱ"))
	D4jfaVBEepvMZY6brJgkNn = YoCFRMX0ZvUTuBl()
	BBkjhOKFs0W4Pp = Dh9MOxeTj6FW.stat(D4jfaVBEepvMZY6brJgkNn).st_mtime
	ggpYWrvRkuJCa5z1eP49OBHsm = []
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: OZnRIc1w7Yr8iP9TQjW = Dh9MOxeTj6FW.listdir(D4jfaVBEepvMZY6brJgkNn.encode(Jbu2G0Qax8PYWpg(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: OZnRIc1w7Yr8iP9TQjW = Dh9MOxeTj6FW.listdir(D4jfaVBEepvMZY6brJgkNn.decode(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for SDQjzmxGXefu3pKyI in OZnRIc1w7Yr8iP9TQjW:
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: SDQjzmxGXefu3pKyI = SDQjzmxGXefu3pKyI.decode(lh6URegmQNq8LWX0HaK5(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not SDQjzmxGXefu3pKyI.startswith(NQ4hg16DPUxtOyo5iGb(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		ooL8tkbPqXfhcr = Dh9MOxeTj6FW.path.join(D4jfaVBEepvMZY6brJgkNn,SDQjzmxGXefu3pKyI)
		BBkjhOKFs0W4Pp = Dh9MOxeTj6FW.path.getmtime(ooL8tkbPqXfhcr)
		ggpYWrvRkuJCa5z1eP49OBHsm.append([SDQjzmxGXefu3pKyI,BBkjhOKFs0W4Pp])
	ggpYWrvRkuJCa5z1eP49OBHsm = sorted(ggpYWrvRkuJCa5z1eP49OBHsm,reverse=B2vCEI9FAVP15R8eUbDJdySc(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[Y5npATFarf1H9wBjc87(u"࠶৲")])
	for SDQjzmxGXefu3pKyI,BBkjhOKFs0W4Pp in ggpYWrvRkuJCa5z1eP49OBHsm:
		if BhTAck1bPFYGuUqRW:
			try: SDQjzmxGXefu3pKyI = SDQjzmxGXefu3pKyI.decode(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			SDQjzmxGXefu3pKyI = SDQjzmxGXefu3pKyI.encode(WWbmNvI40sM9Khlp25Ae(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		ooL8tkbPqXfhcr = Dh9MOxeTj6FW.path.join(D4jfaVBEepvMZY6brJgkNn,SDQjzmxGXefu3pKyI)
		UZ8LYnm5jsl9uKM0xDX(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),SDQjzmxGXefu3pKyI,ooL8tkbPqXfhcr,NQ4hg16DPUxtOyo5iGb(u"࠹࠳࠲৳"))
	return
def YoCFRMX0ZvUTuBl():
	D4jfaVBEepvMZY6brJgkNn = LCIFdjzi5kVmRwehouHQ.getSetting(NQ4hg16DPUxtOyo5iGb(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if D4jfaVBEepvMZY6brJgkNn: return D4jfaVBEepvMZY6brJgkNn
	LCIFdjzi5kVmRwehouHQ.setSetting(IPkQW7LojF3HO18V(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),Vd1J5lD9uAsMUoXW)
	return Vd1J5lD9uAsMUoXW
def icBSd3e9LXjJyG6():
	D4jfaVBEepvMZY6brJgkNn = YoCFRMX0ZvUTuBl()
	EsRvIHPl9rpGUiTqY = nEYJ5OCXG0gcNy(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),IPkQW7LojF3HO18V(u"࠭ࠧश"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࠨष"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),QQSULIva4ljNO73mFcWw(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+D4jfaVBEepvMZY6brJgkNn+eaF2N0jWLdvHIs8r(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if EsRvIHPl9rpGUiTqY==hxSBTdGpyNVbfu4tr9(u"࠱৴"):
		nni1op9bvI5GCAOWt8XlZu2m = gsaPufAIEOSHtMUz1Ln5w(mtEXp14ijx(u"࠴৵"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),Jbu2G0Qax8PYWpg(u"࠭ࠧऽ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡇࡣ࡯ࡷࡪਟ"),Y5npATFarf1H9wBjc87(u"ࡔࡳࡷࡨਞ"),D4jfaVBEepvMZY6brJgkNn)
		svOyXbipkwY = nEYJ5OCXG0gcNy(WWbmNvI40sM9Khlp25Ae(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠩि"),MOwK1lpyNfCgqksX3jhV(u"ࠩࠪी"),FZBX5WcC3msIDv4hobLd8(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),hxSBTdGpyNVbfu4tr9(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+D4jfaVBEepvMZY6brJgkNn+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if svOyXbipkwY==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠳৶"):
			LCIFdjzi5kVmRwehouHQ.setSetting(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),nni1op9bvI5GCAOWt8XlZu2m)
			ztgqWUaDpe8CE9N(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨॅ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠩॆ"),d0HDrq8Rtk16AlInw4TXb(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),gy9NA3CROZolfEt4vVzMr(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def hVHiX8JNWe4SYp9PZBmqK53rl(eesaHQO5yPGNvopTtWzR,MMQ7S0sAgzHIumcqWUx=aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࠬॉ"),website=OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬ࠭ॊ")):
	xrFqGMab4uLKZcS(lh6URegmQNq8LWX0HaK5(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+eesaHQO5yPGNvopTtWzR+WWbmNvI40sM9Khlp25Ae(u"ࠨࠢࡠ्ࠫ"))
	if not MMQ7S0sAgzHIumcqWUx: MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(eesaHQO5yPGNvopTtWzR)
	D4jfaVBEepvMZY6brJgkNn = YoCFRMX0ZvUTuBl()
	UMlKSYDNfaR0Z1sbFvPwp = JA5CtfUvW3ljmExIYFog()
	SDQjzmxGXefu3pKyI = UMlKSYDNfaR0Z1sbFvPwp.replace(eaF2N0jWLdvHIs8r(u"ࠩࠣࠫॎ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࡣࠬॏ"))
	SDQjzmxGXefu3pKyI = Hc4VBGR3XzyljCZWvn(SDQjzmxGXefu3pKyI)
	SDQjzmxGXefu3pKyI = IPkQW7LojF3HO18V(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(CHhSItjbXy))[-RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠷৷"):]+Y5npATFarf1H9wBjc87(u"ࠬࡥࠧ॑")+SDQjzmxGXefu3pKyI+MMQ7S0sAgzHIumcqWUx
	h142KiqInpyW = Dh9MOxeTj6FW.path.join(D4jfaVBEepvMZY6brJgkNn,SDQjzmxGXefu3pKyI)
	zqbfFORL9jgys3Q = {}
	zqbfFORL9jgys3Q[Q2ZyGqCNYsftTc4MR7n(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨ॓")
	zqbfFORL9jgys3Q[RS7ZoyGAq1c(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = FZBX5WcC3msIDv4hobLd8(u"ࠩ࠭࠳࠯࠭ॕ")
	eesaHQO5yPGNvopTtWzR = eesaHQO5yPGNvopTtWzR.replace(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࠬॗ"))
	if LsG7EDcei1gMShH2aVOCo(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in eesaHQO5yPGNvopTtWzR:
		vfIB6ib8q1hFX5GweRrVPNTjY2E,Jhilqrw8nstB7 = eesaHQO5yPGNvopTtWzR.rsplit(d0HDrq8Rtk16AlInw4TXb(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵৸"))
		Jhilqrw8nstB7 = Jhilqrw8nstB7.replace(d0HDrq8Rtk16AlInw4TXb(u"ࠧࡽࠩग़"),NQ4hg16DPUxtOyo5iGb(u"ࠨࠩज़")).replace(gy9NA3CROZolfEt4vVzMr(u"ࠩࠩࠫड़"),FZBX5WcC3msIDv4hobLd8(u"ࠪࠫढ़"))
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E,Jhilqrw8nstB7 = eesaHQO5yPGNvopTtWzR,None
	if not Jhilqrw8nstB7: Jhilqrw8nstB7 = W5h0lzIcY3gMqrZpb7C()
	if Jhilqrw8nstB7: zqbfFORL9jgys3Q[onweDvmTOUj(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = Jhilqrw8nstB7
	if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E,LF56ulcIz2kYqE83Cf = vfIB6ib8q1hFX5GweRrVPNTjY2E.rsplit(B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),d0HDrq8Rtk16AlInw4TXb(u"࠶৹"))
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E,LF56ulcIz2kYqE83Cf = vfIB6ib8q1hFX5GweRrVPNTjY2E,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࠨॡ")
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.strip(MOwK1lpyNfCgqksX3jhV(u"ࠨࡾࠪॢ")).strip(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠩࠫॣ")).strip(Y5npATFarf1H9wBjc87(u"ࠪࢀࠬ।")).strip(gy9NA3CROZolfEt4vVzMr(u"ࠫࠫ࠭॥"))
	LF56ulcIz2kYqE83Cf = LF56ulcIz2kYqE83Cf.replace(eaF2N0jWLdvHIs8r(u"ࠬࢂࠧ०"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠧ१")).replace(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࠧࠩ२"),eaF2N0jWLdvHIs8r(u"ࠨࠩ३"))
	if LF56ulcIz2kYqE83Cf:	zqbfFORL9jgys3Q[KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = LF56ulcIz2kYqE83Cf
	xrFqGMab4uLKZcS(QQSULIva4ljNO73mFcWw(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+vfIB6ib8q1hFX5GweRrVPNTjY2E+d0HDrq8Rtk16AlInw4TXb(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(zqbfFORL9jgys3Q)+FZBX5WcC3msIDv4hobLd8(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+h142KiqInpyW+onweDvmTOUj(u"ࠧࠡ࡟ࠪ९"))
	PHIz0DXOcLqFu = LsG7EDcei1gMShH2aVOCo(u"࠷࠰࠳࠶৺")*LsG7EDcei1gMShH2aVOCo(u"࠷࠰࠳࠶৺")
	SG4cfX076AlD58auprVRJ2z3g9Uvn = mtEXp14ijx(u"࠰৻")
	try:
		GNp7JW0tXe92m =	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		GNp7JW0tXe92m = SomeI8i56FaDMGPE.findall(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩ࡟ࡨ࠰࠭ॱ"),GNp7JW0tXe92m)
		SG4cfX076AlD58auprVRJ2z3g9Uvn = int(GNp7JW0tXe92m[Rz34c0NP5BGo1WuTZxSfOKj(u"࠱ৼ")])
	except: pass
	if not SG4cfX076AlD58auprVRJ2z3g9Uvn:
		try:
			G9pfhJHIaC7l = Dh9MOxeTj6FW.statvfs(D4jfaVBEepvMZY6brJgkNn)
			SG4cfX076AlD58auprVRJ2z3g9Uvn = G9pfhJHIaC7l.f_frsize*G9pfhJHIaC7l.f_bavail//PHIz0DXOcLqFu
		except: pass
	if not SG4cfX076AlD58auprVRJ2z3g9Uvn:
		try:
			G9pfhJHIaC7l = Dh9MOxeTj6FW.fstatvfs(D4jfaVBEepvMZY6brJgkNn)
			SG4cfX076AlD58auprVRJ2z3g9Uvn = G9pfhJHIaC7l.f_frsize*G9pfhJHIaC7l.f_bavail//PHIz0DXOcLqFu
		except: pass
	if not SG4cfX076AlD58auprVRJ2z3g9Uvn:
		try:
			import shutil as XKwh02WkIuNplcMHdnv4C6RG1aDiQ
			m3E4KGelZVsdkRQbhXuaNcI,GGEwJnAUzmu3r,sGhawVy9joUHLWc = XKwh02WkIuNplcMHdnv4C6RG1aDiQ.disk_usage(D4jfaVBEepvMZY6brJgkNn)
			SG4cfX076AlD58auprVRJ2z3g9Uvn = sGhawVy9joUHLWc//PHIz0DXOcLqFu
		except: pass
	if not SG4cfX076AlD58auprVRJ2z3g9Uvn:
		DPfOyNk6YarWmFKU2ezZlAiG(MOwK1lpyNfCgqksX3jhV(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),NQ4hg16DPUxtOyo5iGb(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),Q2ZyGqCNYsftTc4MR7n(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		xrFqGMab4uLKZcS(onweDvmTOUj(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return OnvTrikzfEsY7qU8pgaRBtZy(u"ࡈࡤࡰࡸ࡫ਠ")
	if MMQ7S0sAgzHIumcqWUx==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = I1IwMGlyuaB9XTe(vfIB6ib8q1hFX5GweRrVPNTjY2E,zqbfFORL9jgys3Q)
		if len(r79xJG6jXHD)==onweDvmTOUj(u"࠲৽"):
			NCXj2ri3Unm6TFWIgwh(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),hxSBTdGpyNVbfu4tr9(u"ࠫࠬॺ"))
			return LsG7EDcei1gMShH2aVOCo(u"ࡉࡥࡱࡹࡥਡ")
		elif len(r79xJG6jXHD)==Y5npATFarf1H9wBjc87(u"࠴৾"): I7mfbGiWNFcBVJOn = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠴৿")
		elif len(r79xJG6jXHD)>Jbu2G0Qax8PYWpg(u"࠶਀"):
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn == -B2vCEI9FAVP15R8eUbDJdySc(u"࠷ਁ") :
				NCXj2ri3Unm6TFWIgwh(QQSULIva4ljNO73mFcWw(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),IPkQW7LojF3HO18V(u"ࠧࠨॽ"))
				return Jbu2G0Qax8PYWpg(u"ࡊࡦࡲࡳࡦਢ")
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	u43Ais26CGlzIm = RS7ZoyGAq1c(u"࠰ਂ")
	if MMQ7S0sAgzHIumcqWUx==MOwK1lpyNfCgqksX3jhV(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		h142KiqInpyW = h142KiqInpyW.rsplit(Jbu2G0Qax8PYWpg(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[LsG7EDcei1gMShH2aVOCo(u"࠱ਃ")]+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		fcZNbeuJHKY = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡌࡋࡔࠨঁ"),vfIB6ib8q1hFX5GweRrVPNTjY2E,lh6URegmQNq8LWX0HaK5(u"ࠬ࠭ং"),zqbfFORL9jgys3Q,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠧঃ"),FZBX5WcC3msIDv4hobLd8(u"ࠧࠨ঄"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		ORnwBPsJKWbuo7gvVlyE3tzc1HSh = fcZNbeuJHKY.content
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall(B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),ORnwBPsJKWbuo7gvVlyE3tzc1HSh+WWbmNvI40sM9Khlp25Ae(u"ࠪࡠࡳࡢࡲࠨই"),SomeI8i56FaDMGPE.DOTALL)
		if not ZZHhmdtY1g:
			xrFqGMab4uLKZcS(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+Jbu2G0Qax8PYWpg(u"࠭ࠠ࡞ࠩঊ"))
			return MOwK1lpyNfCgqksX3jhV(u"ࡋࡧ࡬ࡴࡧਣ")
		ZcAK0askvzIWr4R = ZZHhmdtY1g[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠲਄")]
		if not ZcAK0askvzIWr4R.startswith(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if ZcAK0askvzIWr4R.startswith(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࠱࠲ࠫঌ")): ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E.split(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩ࠽ࠫ঍"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠴ਅ"))[gy9NA3CROZolfEt4vVzMr(u"࠴ਆ")]+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪ࠾ࠬ঎")+ZcAK0askvzIWr4R
			elif ZcAK0askvzIWr4R.startswith(Q2ZyGqCNYsftTc4MR7n(u"ࠫ࠴࠭এ")): ZcAK0askvzIWr4R = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,FZBX5WcC3msIDv4hobLd8(u"ࠬࡻࡲ࡭ࠩঐ"))+ZcAK0askvzIWr4R
			else: ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E.rsplit(Q2ZyGqCNYsftTc4MR7n(u"࠭࠯ࠨ঑"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠶ਇ"))[hxSBTdGpyNVbfu4tr9(u"࠶ਈ")]+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧ࠰ࠩ঒")+ZcAK0askvzIWr4R
		fcZNbeuJHKY = UYkMoz0DGsTwIdKxnfS5ryR23Pp.request(Jbu2G0Qax8PYWpg(u"ࠨࡉࡈࡘࠬও"),ZcAK0askvzIWr4R,headers=zqbfFORL9jgys3Q,verify=lh6URegmQNq8LWX0HaK5(u"ࡌࡡ࡭ࡵࡨਤ"))
		Jec9iz2QY8j = fcZNbeuJHKY.content
		w5waUZQSPF3oIRms = len(Jec9iz2QY8j)
		SksqwzmpAvoVFDQ = len(ZZHhmdtY1g)
		u43Ais26CGlzIm = w5waUZQSPF3oIRms*SksqwzmpAvoVFDQ
	else:
		w5waUZQSPF3oIRms = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠱ਉ")*PHIz0DXOcLqFu
		fcZNbeuJHKY = UYkMoz0DGsTwIdKxnfS5ryR23Pp.request(Q2ZyGqCNYsftTc4MR7n(u"ࠩࡊࡉ࡙࠭ঔ"),vfIB6ib8q1hFX5GweRrVPNTjY2E,headers=zqbfFORL9jgys3Q,verify=onweDvmTOUj(u"ࡇࡣ࡯ࡷࡪਦ"),stream=lh6URegmQNq8LWX0HaK5(u"ࡔࡳࡷࡨਥ"))
		if Q2ZyGqCNYsftTc4MR7n(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in fcZNbeuJHKY.headers: u43Ais26CGlzIm = int(fcZNbeuJHKY.headers[WWbmNvI40sM9Khlp25Ae(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		SksqwzmpAvoVFDQ = int(u43Ais26CGlzIm//w5waUZQSPF3oIRms)
	WFTvYhHQxK6542gc1qpNka = int(u43Ais26CGlzIm//PHIz0DXOcLqFu)+QQSULIva4ljNO73mFcWw(u"࠲ਊ")
	if u43Ais26CGlzIm<a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴࠴࠴࠵࠶਋"):
		xrFqGMab4uLKZcS(WWbmNvI40sM9Khlp25Ae(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Q2ZyGqCNYsftTc4MR7n(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+LsG7EDcei1gMShH2aVOCo(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(WFTvYhHQxK6542gc1qpNka)+Q2ZyGqCNYsftTc4MR7n(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(SG4cfX076AlD58auprVRJ2z3g9Uvn)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+h142KiqInpyW+B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࠤࡢ࠭জ"))
		ztgqWUaDpe8CE9N(MOwK1lpyNfCgqksX3jhV(u"ࠫࠬঝ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬ࠭ঞ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return LsG7EDcei1gMShH2aVOCo(u"ࡈࡤࡰࡸ࡫ਧ")
	mmxKacVs0OMjT8lNwZkPny5 = hxSBTdGpyNVbfu4tr9(u"࠷࠴࠵਌")
	ukwgOKWQRGbCp1Fq4tdPHvhc = SG4cfX076AlD58auprVRJ2z3g9Uvn-WFTvYhHQxK6542gc1qpNka
	if ukwgOKWQRGbCp1Fq4tdPHvhc<mmxKacVs0OMjT8lNwZkPny5:
		xrFqGMab4uLKZcS(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Y5npATFarf1H9wBjc87(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+onweDvmTOUj(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(WFTvYhHQxK6542gc1qpNka)+mtEXp14ijx(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(SG4cfX076AlD58auprVRJ2z3g9Uvn)+eaF2N0jWLdvHIs8r(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(mmxKacVs0OMjT8lNwZkPny5)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+h142KiqInpyW+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࠡ࡟ࠪধ"))
		ztgqWUaDpe8CE9N(IPkQW7LojF3HO18V(u"ࠨࠩন"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪ঩"),WWbmNvI40sM9Khlp25Ae(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),Sj1PYDmIpCUXO26(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(WFTvYhHQxK6542gc1qpNka)+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(SG4cfX076AlD58auprVRJ2z3g9Uvn)+d0HDrq8Rtk16AlInw4TXb(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(mmxKacVs0OMjT8lNwZkPny5)+QQSULIva4ljNO73mFcWw(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡉࡥࡱࡹࡥਨ")
	svOyXbipkwY = nEYJ5OCXG0gcNy(MOwK1lpyNfCgqksX3jhV(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪর"),Sj1PYDmIpCUXO26(u"ࠪࠫ঱"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),Q2ZyGqCNYsftTc4MR7n(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(WFTvYhHQxK6542gc1qpNka)+QQSULIva4ljNO73mFcWw(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(SG4cfX076AlD58auprVRJ2z3g9Uvn)+lh6URegmQNq8LWX0HaK5(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if svOyXbipkwY!=gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵਍"):
		ztgqWUaDpe8CE9N(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠩশ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࠪষ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪࠫস"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		xrFqGMab4uLKZcS(gy9NA3CROZolfEt4vVzMr(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+vfIB6ib8q1hFX5GweRrVPNTjY2E+gy9NA3CROZolfEt4vVzMr(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+h142KiqInpyW+QQSULIva4ljNO73mFcWw(u"ࠨࠢࡠࠫঽ"))
		return FZBX5WcC3msIDv4hobLd8(u"ࡊࡦࡲࡳࡦ਩")
	xrFqGMab4uLKZcS(lh6URegmQNq8LWX0HaK5(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+NQ4hg16DPUxtOyo5iGb(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	IIheUfDrYngWFbdtjxvpPyN8 = AAGT9IPy4BoZN7()
	IIheUfDrYngWFbdtjxvpPyN8.create(h142KiqInpyW,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	Ag8D9X42ZF5rc10tNbzQP6UCvayp = Sj1PYDmIpCUXO26(u"࡙ࡸࡵࡦਪ")
	mlKGZXF5ybUTOrQNMua = p1BoraOuWL.time()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: nxDfqd3TusCM69Otel = open(h142KiqInpyW,Y5npATFarf1H9wBjc87(u"ࠬࡽࡢࠨু"))
	else: nxDfqd3TusCM69Otel = open(h142KiqInpyW.decode(gy9NA3CROZolfEt4vVzMr(u"࠭ࡵࡵࡨ࠻ࠫূ")),lh6URegmQNq8LWX0HaK5(u"ࠧࡸࡤࠪৃ"))
	if MMQ7S0sAgzHIumcqWUx==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for jUSuZAztxy34TB5CIP2 in range(QQSULIva4ljNO73mFcWw(u"࠶਎"),SksqwzmpAvoVFDQ+QQSULIva4ljNO73mFcWw(u"࠶਎")):
			ZcAK0askvzIWr4R = ZZHhmdtY1g[jUSuZAztxy34TB5CIP2-Rz34c0NP5BGo1WuTZxSfOKj(u"࠷ਏ")]
			if not ZcAK0askvzIWr4R.startswith(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if ZcAK0askvzIWr4R.startswith(Y5npATFarf1H9wBjc87(u"ࠪ࠳࠴࠭৆")): ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E.split(hxSBTdGpyNVbfu4tr9(u"ࠫ࠿࠭ে"),FZBX5WcC3msIDv4hobLd8(u"࠱ਐ"))[Q2ZyGqCNYsftTc4MR7n(u"࠱਑")]+Sj1PYDmIpCUXO26(u"ࠬࡀࠧৈ")+ZcAK0askvzIWr4R
				elif ZcAK0askvzIWr4R.startswith(gy9NA3CROZolfEt4vVzMr(u"࠭࠯ࠨ৉")): ZcAK0askvzIWr4R = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,hxSBTdGpyNVbfu4tr9(u"ࠧࡶࡴ࡯ࠫ৊"))+ZcAK0askvzIWr4R
				else: ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E.rsplit(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨ࠱ࠪো"),gy9NA3CROZolfEt4vVzMr(u"࠳਒"))[Rz34c0NP5BGo1WuTZxSfOKj(u"࠳ਓ")]+Sj1PYDmIpCUXO26(u"ࠩ࠲ࠫৌ")+ZcAK0askvzIWr4R
			fcZNbeuJHKY = UYkMoz0DGsTwIdKxnfS5ryR23Pp.request(lh6URegmQNq8LWX0HaK5(u"ࠪࡋࡊ্࡚ࠧ"),ZcAK0askvzIWr4R,headers=zqbfFORL9jgys3Q,verify=RS7ZoyGAq1c(u"ࡌࡡ࡭ࡵࡨਫ"))
			Jec9iz2QY8j = fcZNbeuJHKY.content
			fcZNbeuJHKY.close()
			nxDfqd3TusCM69Otel.write(Jec9iz2QY8j)
			k3s1pEmCLF7dIzV5MZeGvO = p1BoraOuWL.time()
			oxNv9MVRbLm7XnKQq1gDOTFEjUfPc = k3s1pEmCLF7dIzV5MZeGvO-mlKGZXF5ybUTOrQNMua
			ZolKaCvV0fOP3B8yng2dJY9WwU = oxNv9MVRbLm7XnKQq1gDOTFEjUfPc//jUSuZAztxy34TB5CIP2
			ooAWLMmtvsxXjqu5Yyze763 = ZolKaCvV0fOP3B8yng2dJY9WwU*(SksqwzmpAvoVFDQ+LsG7EDcei1gMShH2aVOCo(u"࠵ਔ"))
			G0n1k96to8MdeTQiCWLHcDJZbAw = ooAWLMmtvsxXjqu5Yyze763-oxNv9MVRbLm7XnKQq1gDOTFEjUfPc
			AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,int(B2vCEI9FAVP15R8eUbDJdySc(u"࠷࠰࠱ਖ")*jUSuZAztxy34TB5CIP2//(SksqwzmpAvoVFDQ+lh6URegmQNq8LWX0HaK5(u"࠶ਕ"))),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),gy9NA3CROZolfEt4vVzMr(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(jUSuZAztxy34TB5CIP2*w5waUZQSPF3oIRms//PHIz0DXOcLqFu)+Sj1PYDmIpCUXO26(u"࠭࠯ࠨ৐")+str(WFTvYhHQxK6542gc1qpNka)+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+p1BoraOuWL.strftime(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),p1BoraOuWL.gmtime(G0n1k96to8MdeTQiCWLHcDJZbAw))+FZBX5WcC3msIDv4hobLd8(u"ࠩࠣไࠬ৓"))
			if IIheUfDrYngWFbdtjxvpPyN8.iscanceled():
				Ag8D9X42ZF5rc10tNbzQP6UCvayp = Jbu2G0Qax8PYWpg(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		jUSuZAztxy34TB5CIP2 = onweDvmTOUj(u"࠰ਗ")
		for Jec9iz2QY8j in fcZNbeuJHKY.iter_content(chunk_size=w5waUZQSPF3oIRms):
			nxDfqd3TusCM69Otel.write(Jec9iz2QY8j)
			jUSuZAztxy34TB5CIP2 = jUSuZAztxy34TB5CIP2+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠲ਘ")
			k3s1pEmCLF7dIzV5MZeGvO = p1BoraOuWL.time()
			oxNv9MVRbLm7XnKQq1gDOTFEjUfPc = k3s1pEmCLF7dIzV5MZeGvO-mlKGZXF5ybUTOrQNMua
			ZolKaCvV0fOP3B8yng2dJY9WwU = oxNv9MVRbLm7XnKQq1gDOTFEjUfPc/jUSuZAztxy34TB5CIP2
			ooAWLMmtvsxXjqu5Yyze763 = ZolKaCvV0fOP3B8yng2dJY9WwU*(SksqwzmpAvoVFDQ+eaF2N0jWLdvHIs8r(u"࠳ਙ"))
			G0n1k96to8MdeTQiCWLHcDJZbAw = ooAWLMmtvsxXjqu5Yyze763-oxNv9MVRbLm7XnKQq1gDOTFEjUfPc
			AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,int(Rz34c0NP5BGo1WuTZxSfOKj(u"࠵࠵࠶ਛ")*jUSuZAztxy34TB5CIP2/(SksqwzmpAvoVFDQ+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴ਚ"))),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),QQSULIva4ljNO73mFcWw(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(jUSuZAztxy34TB5CIP2*w5waUZQSPF3oIRms//PHIz0DXOcLqFu)+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࠵ࠧ৖")+str(WFTvYhHQxK6542gc1qpNka)+WWbmNvI40sM9Khlp25Ae(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+p1BoraOuWL.strftime(gy9NA3CROZolfEt4vVzMr(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),p1BoraOuWL.gmtime(G0n1k96to8MdeTQiCWLHcDJZbAw))+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠢใࠫ৙"))
			if IIheUfDrYngWFbdtjxvpPyN8.iscanceled():
				Ag8D9X42ZF5rc10tNbzQP6UCvayp = d0HDrq8Rtk16AlInw4TXb(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		fcZNbeuJHKY.close()
	nxDfqd3TusCM69Otel.close()
	IIheUfDrYngWFbdtjxvpPyN8.close()
	if not Ag8D9X42ZF5rc10tNbzQP6UCvayp:
		xrFqGMab4uLKZcS(Jbu2G0Qax8PYWpg(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+vfIB6ib8q1hFX5GweRrVPNTjY2E+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+h142KiqInpyW+QQSULIva4ljNO73mFcWw(u"ࠬࠦ࡝ࠨঢ়"))
		ztgqWUaDpe8CE9N(RS7ZoyGAq1c(u"࠭ࠧ৞"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࠨয়"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩৠ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return MOwK1lpyNfCgqksX3jhV(u"ࡖࡵࡹࡪਮ")
	xrFqGMab4uLKZcS(hxSBTdGpyNVbfu4tr9(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+vfIB6ib8q1hFX5GweRrVPNTjY2E+Sj1PYDmIpCUXO26(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+h142KiqInpyW+Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠠ࡞ࠩ৥"))
	ztgqWUaDpe8CE9N(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࠨ০"),lh6URegmQNq8LWX0HaK5(u"ࠨࠩ১"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࠪ২"),gy9NA3CROZolfEt4vVzMr(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return gy9NA3CROZolfEt4vVzMr(u"ࡗࡶࡺ࡫ਯ")
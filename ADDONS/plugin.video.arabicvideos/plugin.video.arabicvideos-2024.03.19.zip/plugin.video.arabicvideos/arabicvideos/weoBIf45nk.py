# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'YOUTUBE'
ToYWiIbruzUaNKRPZLG16cAj = '_YUT_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,text,type,SSGEc76fBan2):
	if	 mode==140: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==143: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,type)
	elif mode==144: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq(url,text,SSGEc76fBan2)
	elif mode==145: rr60PDpqbMehZsYVuHmiAtN = jjhXvULEoJkxIzae3(url)
	elif mode==146: rr60PDpqbMehZsYVuHmiAtN = UUoMtVKiTsDH3BabvNqcE8WI(url)
	elif mode==147: rr60PDpqbMehZsYVuHmiAtN = nXQuijKDxewFdbyHpt90qA()
	elif mode==148: rr60PDpqbMehZsYVuHmiAtN = eEwufNiGmHq()
	elif mode==149: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مواقع اختارها يوتيوب',aaeRjxiYcqOI6Sf8+'/feed/guide_builder',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الصفحة الرئيسية',aaeRjxiYcqOI6Sf8,144,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المحتوى الرائج',aaeRjxiYcqOI6Sf8+'/feed/trending',146)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: قنوات عربية','',147)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: قنوات أجنبية','',148)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: افلام عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=فيلم',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: افلام اجنبية',aaeRjxiYcqOI6Sf8+'/results?search_query=movie',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسرحيات عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=مسرحية',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات اجنبية',aaeRjxiYcqOI6Sf8+'/results?search_query=series&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات كارتون',aaeRjxiYcqOI6Sf8+'/results?search_query=كارتون&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بحث: خطبة المرجعية',aaeRjxiYcqOI6Sf8+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def nXQuijKDxewFdbyHpt90qA():
	rum8gIeCX3hYq(aaeRjxiYcqOI6Sf8+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def eEwufNiGmHq():
	rum8gIeCX3hYq(aaeRjxiYcqOI6Sf8+'/results?search_query=tv&sp=EgJAAQ==')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,type):
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK([url],HmvY29bj4dNgF7wZqr1lzkeQxiEasu,type,url)
	return
def UUoMtVKiTsDH3BabvNqcE8WI(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb,lU7cFRC6jSwkVLTmIM,data = LyYjEfISpORQXlaD7PuoAzc24H0d9(url)
	QFInUtzBPq2hT5JdkaONvV7H8W9E = lU7cFRC6jSwkVLTmIM['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for jUSuZAztxy34TB5CIP2 in range(len(QFInUtzBPq2hT5JdkaONvV7H8W9E)):
		MMeFJKLQG4HdIwObZ1l9 = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2]
		S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9,url,str(jUSuZAztxy34TB5CIP2))
	qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	uyFCoI0j9iQY7Nk = 0
	for jUSuZAztxy34TB5CIP2 in range(len(qx1ve0mafw)):
		MMeFJKLQG4HdIwObZ1l9 = qx1ve0mafw[jUSuZAztxy34TB5CIP2]['itemSectionRenderer']['contents'][0]
		if list(MMeFJKLQG4HdIwObZ1l9['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		TbESvC7xMBAzRyamKtU6uLwI,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt = pv1anL23bl6uFwJmcN(MMeFJKLQG4HdIwObZ1l9)
		if not title:
			uyFCoI0j9iQY7Nk += 1
			title = 'فيديوهات رائجة '+str(uyFCoI0j9iQY7Nk)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,144,'',str(jUSuZAztxy34TB5CIP2))
	key = SomeI8i56FaDMGPE.findall('"innertubeApiKey":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	BsJ71WIxDtdFKveTcRPrqM4Cwb,lU7cFRC6jSwkVLTmIM,ZZm1hsDV9ba = LyYjEfISpORQXlaD7PuoAzc24H0d9(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	for G1GqcAg9EQrhXMdkDfwOW in range(3,4):
		QFInUtzBPq2hT5JdkaONvV7H8W9E = lU7cFRC6jSwkVLTmIM['items'][G1GqcAg9EQrhXMdkDfwOW]['guideSectionRenderer']['items']
		for jUSuZAztxy34TB5CIP2 in range(len(QFInUtzBPq2hT5JdkaONvV7H8W9E)):
			MMeFJKLQG4HdIwObZ1l9 = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2]
			if 'YouTube Premium' in str(MMeFJKLQG4HdIwObZ1l9): continue
			S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9)
	return
def rum8gIeCX3hYq(url,data='',index=0):
	global LCIFdjzi5kVmRwehouHQ
	if not data: data = LCIFdjzi5kVmRwehouHQ.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	BsJ71WIxDtdFKveTcRPrqM4Cwb,lU7cFRC6jSwkVLTmIM,ZZm1hsDV9ba = LyYjEfISpORQXlaD7PuoAzc24H0d9(url,data)
	Vbj25gIOTdPhSu4nka9JCY,ILkTWejdlbAN8Y = '',''
	YmaiRV2dCwZnS87U = SomeI8i56FaDMGPE.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not YmaiRV2dCwZnS87U: YmaiRV2dCwZnS87U = SomeI8i56FaDMGPE.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not YmaiRV2dCwZnS87U: YmaiRV2dCwZnS87U = SomeI8i56FaDMGPE.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if YmaiRV2dCwZnS87U:
		Vbj25gIOTdPhSu4nka9JCY = '[COLOR FFC89008]'+YmaiRV2dCwZnS87U[0][0]+'[/COLOR]'
		ZcAK0askvzIWr4R = YmaiRV2dCwZnS87U[0][1]
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
		if 'list=' in url: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+Vbj25gIOTdPhSu4nka9JCY,ZcAK0askvzIWr4R,144)
	Rl3FIbGqVJtEfH0ndm8sZgPxkTj = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	yEJkt6V5uKs0BGZM = not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in url for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Rl3FIbGqVJtEfH0ndm8sZgPxkTj)
	if yEJkt6V5uKs0BGZM and Vbj25gIOTdPhSu4nka9JCY:
		uZfwDbhTs2V5dp = 'البحث'
		U2iQmHMJzoNkjORTGY7c51vZ = 'قوائم التشغيل'
		mHuqifFKcryG6CEWkUXSt7Z1p = 'الفيديوهات'
		NIiZom2VP3Q8vRCYFJMXwc7E6rfuHk = 'القنوات'
		UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+Vbj25gIOTdPhSu4nka9JCY,url,9999)
		if '"title":"بحث"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+uZfwDbhTs2V5dp,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,url+'/playlists',144)
		if '"title":"الفيديوهات"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+mHuqifFKcryG6CEWkUXSt7Z1p,url+'/videos',144)
		if '"title":"القنوات"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+NIiZom2VP3Q8vRCYFJMXwc7E6rfuHk,url+'/channels',144)
		if '"title":"Search"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+uZfwDbhTs2V5dp,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,url+'/playlists',144)
		if '"title":"Videos"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+mHuqifFKcryG6CEWkUXSt7Z1p,url+'/videos',144)
		if '"title":"Channels"' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+NIiZom2VP3Q8vRCYFJMXwc7E6rfuHk,url+'/channels',144)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		QFInUtzBPq2hT5JdkaONvV7H8W9E = lU7cFRC6jSwkVLTmIM['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		AQJ3Nwn2hWVclbLof78DOr6uvq4 = 0
		for zz5ZOaoyATpS893tvdXE in range(len(QFInUtzBPq2hT5JdkaONvV7H8W9E)):
			if 'itemSectionRenderer' in list(QFInUtzBPq2hT5JdkaONvV7H8W9E[zz5ZOaoyATpS893tvdXE].keys()):
				evuqEswXGW61SYhtdFTKlzxjr8kZUP = QFInUtzBPq2hT5JdkaONvV7H8W9E[zz5ZOaoyATpS893tvdXE]['itemSectionRenderer']
				E2EtAT9INQC8Gwkgs7 = len(str(evuqEswXGW61SYhtdFTKlzxjr8kZUP))
				if E2EtAT9INQC8Gwkgs7>AQJ3Nwn2hWVclbLof78DOr6uvq4:
					AQJ3Nwn2hWVclbLof78DOr6uvq4 = E2EtAT9INQC8Gwkgs7
					ILkTWejdlbAN8Y = evuqEswXGW61SYhtdFTKlzxjr8kZUP
		if AQJ3Nwn2hWVclbLof78DOr6uvq4==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==aaeRjxiYcqOI6Sf8:
		oXyje2LgxZld0Mwas = []
		oXyje2LgxZld0Mwas.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		oXyje2LgxZld0Mwas.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		oXyje2LgxZld0Mwas.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		oXyje2LgxZld0Mwas.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		oXyje2LgxZld0Mwas.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		oXyje2LgxZld0Mwas.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		oXyje2LgxZld0Mwas.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		oXyje2LgxZld0Mwas.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		eh9YaHs4rI3JGQtUpSMfcqyv5m,ILkTWejdlbAN8Y = wLIuV9bEraGMmySfiQPZJ0(lU7cFRC6jSwkVLTmIM,'',oXyje2LgxZld0Mwas)
	if not ILkTWejdlbAN8Y:
		try:
			QFInUtzBPq2hT5JdkaONvV7H8W9E = lU7cFRC6jSwkVLTmIM['contents']['twoColumnBrowseResultsRenderer']['tabs']
			juYczFWVTx49yiP6DdUms2BSQkpROJ = '/videos' in url or '/playlists' in url or '/channels' in url
			OAhzo7XLF1tKDM4eEpIrq5nBj = '"title":"الفيديوهات"' in BsJ71WIxDtdFKveTcRPrqM4Cwb or '"title":"قوائم التشغيل"' in BsJ71WIxDtdFKveTcRPrqM4Cwb or '"title":"القنوات"' in BsJ71WIxDtdFKveTcRPrqM4Cwb
			rrxLCF3dn8DKVy2 = '"title":"Videos"' in BsJ71WIxDtdFKveTcRPrqM4Cwb or '"title":"Playlists"' in BsJ71WIxDtdFKveTcRPrqM4Cwb or '"title":"Channels"' in BsJ71WIxDtdFKveTcRPrqM4Cwb
			if juYczFWVTx49yiP6DdUms2BSQkpROJ and (OAhzo7XLF1tKDM4eEpIrq5nBj or rrxLCF3dn8DKVy2):
				for jUSuZAztxy34TB5CIP2 in range(len(QFInUtzBPq2hT5JdkaONvV7H8W9E)):
					if 'tabRenderer' not in list(QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2].keys()): continue
					qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2]['tabRenderer']
					try: ztDjMsIWEwacoinK26 = qx1ve0mafw['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][jUSuZAztxy34TB5CIP2]
					except: ztDjMsIWEwacoinK26 = qx1ve0mafw
					try: ZcAK0askvzIWr4R = ztDjMsIWEwacoinK26['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in ZcAK0askvzIWr4R	and '/videos'		in url: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2] ; break
					elif '/playlists'	in ZcAK0askvzIWr4R	and '/playlists'	in url: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2] ; break
					elif '/channels'	in ZcAK0askvzIWr4R	and '/channels'		in url: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[jUSuZAztxy34TB5CIP2] ; break
					else: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[0]
			elif 'bp=' in url: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[index]
			else: qx1ve0mafw = QFInUtzBPq2hT5JdkaONvV7H8W9E[0]
			ILkTWejdlbAN8Y = qx1ve0mafw['tabRenderer']['content']
		except: pass
	if not ILkTWejdlbAN8Y: return
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("ff['sectionListRenderer']")
	oXyje2LgxZld0Mwas.append("ff['richGridRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("ff['contents']")
	oXyje2LgxZld0Mwas.append("ff")
	tRaw8ODgnKvMlAx = MMjrDyLdKhUb7V(u'كل قوائم التشغيل')
	oo1q2JEvCGnR4ZQ6aNVPHhItiAz = MMjrDyLdKhUb7V(u'كل الفيديوهات')
	LsRN3jT4f2ox = MMjrDyLdKhUb7V(u'كل القنوات')
	CT398UpMbnHI = [tRaw8ODgnKvMlAx,oo1q2JEvCGnR4ZQ6aNVPHhItiAz,LsRN3jT4f2ox,'All playlists','All videos','All channels']
	XnwrjRK5Du1zFJGZN69Ubx3aAIi8t,ztDjMsIWEwacoinK26 = wLIuV9bEraGMmySfiQPZJ0(ILkTWejdlbAN8Y,index,oXyje2LgxZld0Mwas)
	if 'list' in str(type(ztDjMsIWEwacoinK26)) and any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in str(ztDjMsIWEwacoinK26[0]) for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in CT398UpMbnHI): del ztDjMsIWEwacoinK26[0]
	for PPSeanH6bGrtwfdgBm in range(len(ztDjMsIWEwacoinK26)):
		oXyje2LgxZld0Mwas = []
		oXyje2LgxZld0Mwas.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		oXyje2LgxZld0Mwas.append("gg[index2]['itemSectionRenderer']['header']")
		oXyje2LgxZld0Mwas.append("gg[index2]['horizontalCardListRenderer']['header']")
		oXyje2LgxZld0Mwas.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		oXyje2LgxZld0Mwas.append("gg[index2]['richSectionRenderer']['content']")
		oXyje2LgxZld0Mwas.append("gg[index2]['richItemRenderer']['content']")
		oXyje2LgxZld0Mwas.append("gg[index2]['gameCardRenderer']['game']")
		oXyje2LgxZld0Mwas.append("gg[index2]")
		eh9YaHs4rI3JGQtUpSMfcqyv5m,MMeFJKLQG4HdIwObZ1l9 = wLIuV9bEraGMmySfiQPZJ0(ztDjMsIWEwacoinK26,PPSeanH6bGrtwfdgBm,oXyje2LgxZld0Mwas)
		S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9,url,str(PPSeanH6bGrtwfdgBm))
		if eh9YaHs4rI3JGQtUpSMfcqyv5m=='4':
			try:
				waeinU6RXVyOQov7kHDz = MMeFJKLQG4HdIwObZ1l9['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for ULA5FVjJO6MTeGWi3 in range(len(waeinU6RXVyOQov7kHDz)):
					uZA1NeSrTv = waeinU6RXVyOQov7kHDz[ULA5FVjJO6MTeGWi3]
					S9wrU6jxteTgdo0BfhVbNa(uZA1NeSrTv)
			except: pass
	EEQy35Z2dq6DHvLKXA = False
	if 'view=' not in url and XnwrjRK5Du1zFJGZN69Ubx3aAIi8t=='8': EEQy35Z2dq6DHvLKXA = True
	if ':::' in ZZm1hsDV9ba: i1vYajMAKUOEl0HQ,key,S5Up21BfobmtXau,iCQpJnV5mBPakXTgW8ufE2hF,ii1SRMJ8xhIz5yl0Xptb9a,DFVGW9wgzKuLRJOUQX1k28yZrb3M = ZZm1hsDV9ba.split(':::')
	else: i1vYajMAKUOEl0HQ,key,S5Up21BfobmtXau,iCQpJnV5mBPakXTgW8ufE2hF,ii1SRMJ8xhIz5yl0Xptb9a,DFVGW9wgzKuLRJOUQX1k28yZrb3M = '','','','','',''
	vfIB6ib8q1hFX5GweRrVPNTjY2E,rTcXIjKgMCUdaPSWkn = '',''
	if nUTgq0SFfC9:
		ppfclbG7eFj = str(nUTgq0SFfC9[-1][1])
		if   ToYWiIbruzUaNKRPZLG16cAj+'CHNL' in ppfclbG7eFj: rTcXIjKgMCUdaPSWkn = 'CHANNELS'
		elif ToYWiIbruzUaNKRPZLG16cAj+'USER' in ppfclbG7eFj: rTcXIjKgMCUdaPSWkn = 'CHANNELS'
		elif ToYWiIbruzUaNKRPZLG16cAj+'LIST' in ppfclbG7eFj: rTcXIjKgMCUdaPSWkn = 'PLAYLISTS'
	if '"continuations"' in BsJ71WIxDtdFKveTcRPrqM4Cwb and '&list=' not in url and not EEQy35Z2dq6DHvLKXA and 'shelf_id' not in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/browse_ajax?ctoken='+S5Up21BfobmtXau
	elif '"token"' in BsJ71WIxDtdFKveTcRPrqM4Cwb and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/youtubei/v1/search?key='+key
	elif '"token"' in BsJ71WIxDtdFKveTcRPrqM4Cwb and 'bp=' not in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/youtubei/v1/browse?key='+key
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة أخرى',vfIB6ib8q1hFX5GweRrVPNTjY2E,144,rTcXIjKgMCUdaPSWkn,'',ZZm1hsDV9ba)
	return
def wLIuV9bEraGMmySfiQPZJ0(ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,fSHI5xZBcpsGMhb93V6uz):
	lU7cFRC6jSwkVLTmIM = ZUshXQ1nwIHbLMP
	ILkTWejdlbAN8Y,index = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	ztDjMsIWEwacoinK26,PPSeanH6bGrtwfdgBm = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2 = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	count = len(fSHI5xZBcpsGMhb93V6uz)
	for jUSuZAztxy34TB5CIP2 in range(count):
		try:
			HWcGFfnKESdOeY3LDz4sq = eval(fSHI5xZBcpsGMhb93V6uz[jUSuZAztxy34TB5CIP2])
			return str(jUSuZAztxy34TB5CIP2+1),HWcGFfnKESdOeY3LDz4sq
		except: pass
	return '',''
def pv1anL23bl6uFwJmcN(MMeFJKLQG4HdIwObZ1l9):
	try: chJis9v4U5fW0ZVQY1t = list(MMeFJKLQG4HdIwObZ1l9.keys())[0]
	except: return False,'','','','','','',''
	TbESvC7xMBAzRyamKtU6uLwI,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt = False,'','','','','','',''
	TfyP0Z7gOHWGCYN3dexu2 = MMeFJKLQG4HdIwObZ1l9[chJis9v4U5fW0ZVQY1t]
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("render['unplayableText']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['formattedTitle']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['title']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['title']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("render['text']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['text']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("render['title']")
	oXyje2LgxZld0Mwas.append("item['title']")
	eh9YaHs4rI3JGQtUpSMfcqyv5m,title = wLIuV9bEraGMmySfiQPZJ0(MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	eh9YaHs4rI3JGQtUpSMfcqyv5m,ZcAK0askvzIWr4R = wLIuV9bEraGMmySfiQPZJ0(MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("render['thumbnail']['thumbnails'][0]['url']")
	oXyje2LgxZld0Mwas.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	eh9YaHs4rI3JGQtUpSMfcqyv5m,pjMZ802XQCSxYVk = wLIuV9bEraGMmySfiQPZJ0(MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("render['videoCount']")
	oXyje2LgxZld0Mwas.append("render['videoCountText']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	eh9YaHs4rI3JGQtUpSMfcqyv5m,count = wLIuV9bEraGMmySfiQPZJ0(MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("render['lengthText']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	oXyje2LgxZld0Mwas.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	eh9YaHs4rI3JGQtUpSMfcqyv5m,DD1IVWFZbr7TlzYto5s = wLIuV9bEraGMmySfiQPZJ0(MMeFJKLQG4HdIwObZ1l9,TfyP0Z7gOHWGCYN3dexu2,oXyje2LgxZld0Mwas)
	if 'LIVE' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M = '','LIVE:  '
	if 'مباشر' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M = '','LIVE:  '
	if 'badges' in list(TfyP0Z7gOHWGCYN3dexu2.keys()):
		PrGydBOaRV = str(TfyP0Z7gOHWGCYN3dexu2['badges'])
		if 'Free with Ads' in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$:'
		if 'LIVE NOW' in PrGydBOaRV: wnNUzQihpqAXKyR8jelWfPCOuxI7M = 'LIVE:  '
		if 'Buy' in PrGydBOaRV or 'Rent' in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:'
		if MMjrDyLdKhUb7V(u'مباشر') in PrGydBOaRV: wnNUzQihpqAXKyR8jelWfPCOuxI7M = 'LIVE:  '
		if MMjrDyLdKhUb7V(u'شراء') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:'
		if MMjrDyLdKhUb7V(u'استئجار') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:'
		if MMjrDyLdKhUb7V(u'إعلانات') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$:'
	ZcAK0askvzIWr4R = c8Fvb4IfHW9XkG1mLK5Z(ZcAK0askvzIWr4R)
	if ZcAK0askvzIWr4R and 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
	pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.split('?')[0]
	if  pjMZ802XQCSxYVk and 'http' not in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = 'https:'+pjMZ802XQCSxYVk
	title = c8Fvb4IfHW9XkG1mLK5Z(title)
	if SSEYfZm4b0IUyg2PJXnt: title = SSEYfZm4b0IUyg2PJXnt+'  '+title
	DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace(',','')
	count = count.replace(',','')
	count = SomeI8i56FaDMGPE.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt
def S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9,url='',index=''):
	TbESvC7xMBAzRyamKtU6uLwI,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt = pv1anL23bl6uFwJmcN(MMeFJKLQG4HdIwObZ1l9)
	if not TbESvC7xMBAzRyamKtU6uLwI: return
	elif 'continuationItemRenderer' in str(MMeFJKLQG4HdIwObZ1l9): return
	elif 'searchPyvRenderer' in str(MMeFJKLQG4HdIwObZ1l9): return
	elif not ZcAK0askvzIWr4R and 'search_query' in url: return
	elif title and not ZcAK0askvzIWr4R and ('search_query' in url or 'horizontalMovieListRenderer' in str(MMeFJKLQG4HdIwObZ1l9) or url==aaeRjxiYcqOI6Sf8):
		title = '=== '+title+' ==='
		UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+title,'',9999)
	elif title and 'messageRenderer' in str(MMeFJKLQG4HdIwObZ1l9):
		UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+title,'',9999)
	elif '/feed/trending' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,index)
	elif not title: return
	elif wnNUzQihpqAXKyR8jelWfPCOuxI7M: UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+wnNUzQihpqAXKyR8jelWfPCOuxI7M+title,ZcAK0askvzIWr4R,143,pjMZ802XQCSxYVk)
	elif 'watch?v=' in ZcAK0askvzIWr4R or '/shorts/' in ZcAK0askvzIWr4R:
		if '&list=' in ZcAK0askvzIWr4R and 'index=' not in ZcAK0askvzIWr4R:
			xxE95jdKlbA = ZcAK0askvzIWr4R.split('&list=',1)[1]
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/playlist?list='+xxE95jdKlbA
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'LIST'+count+':  '+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk)
		else:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&list=',1)[0]
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,143,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s)
	else:
		type = ''
		if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = url
		elif not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in ZcAK0askvzIWr4R for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in ZcAK0askvzIWr4R or '/c/' in ZcAK0askvzIWr4R: type = 'CHNL'+count+':  '
			if '/user/' in ZcAK0askvzIWr4R: type = 'USER'+count+':  '
			index,C5rxenQTBY0Ls8wqfu3KjDhM = '',''
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+type+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,index)
	return
def LyYjEfISpORQXlaD7PuoAzc24H0d9(url,data='',ZuCJj5EwDPROkb7UXNypofl=''):
	global LCIFdjzi5kVmRwehouHQ
	if not data: data = LCIFdjzi5kVmRwehouHQ.getSetting('av.youtube.data')
	if ZuCJj5EwDPROkb7UXNypofl=='': ZuCJj5EwDPROkb7UXNypofl = 'ytInitialData'
	Jhilqrw8nstB7 = W5h0lzIcY3gMqrZpb7C()
	mgDoj8ZAqe0uBLxP4Kzp = {'User-Agent':Jhilqrw8nstB7,'Cookie':'PREF=hl=ar'}
	if ':::' in data: i1vYajMAKUOEl0HQ,key,S5Up21BfobmtXau,iCQpJnV5mBPakXTgW8ufE2hF,ii1SRMJ8xhIz5yl0Xptb9a,DFVGW9wgzKuLRJOUQX1k28yZrb3M = data.split(':::')
	else: i1vYajMAKUOEl0HQ,key,S5Up21BfobmtXau,iCQpJnV5mBPakXTgW8ufE2hF,ii1SRMJ8xhIz5yl0Xptb9a,DFVGW9wgzKuLRJOUQX1k28yZrb3M = '','','','','',''
	if 'guide?key=' in url:
		ZZm1hsDV9ba = {}
		ZZm1hsDV9ba['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":iCQpJnV5mBPakXTgW8ufE2hF}}
		ZZm1hsDV9ba = str(ZZm1hsDV9ba)
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and i1vYajMAKUOEl0HQ:
		ZZm1hsDV9ba = {'continuation':ii1SRMJ8xhIz5yl0Xptb9a}
		ZZm1hsDV9ba['context'] = {"client":{"visitorData":i1vYajMAKUOEl0HQ,"clientName":"WEB","clientVersion":iCQpJnV5mBPakXTgW8ufE2hF}}
		ZZm1hsDV9ba = str(ZZm1hsDV9ba)
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and DFVGW9wgzKuLRJOUQX1k28yZrb3M:
		mgDoj8ZAqe0uBLxP4Kzp.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':iCQpJnV5mBPakXTgW8ufE2hF})
		mgDoj8ZAqe0uBLxP4Kzp.update({'Cookie':'VISITOR_INFO1_LIVE='+DFVGW9wgzKuLRJOUQX1k28yZrb3M})
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','YOUTUBE-GET_PAGE_DATA-4th')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	QoKtPvxChMrqL1z0BbwI63 = SomeI8i56FaDMGPE.findall('"innertubeApiKey".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if QoKtPvxChMrqL1z0BbwI63: key = QoKtPvxChMrqL1z0BbwI63[0]
	QoKtPvxChMrqL1z0BbwI63 = SomeI8i56FaDMGPE.findall('"cver".*?"value".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if QoKtPvxChMrqL1z0BbwI63: iCQpJnV5mBPakXTgW8ufE2hF = QoKtPvxChMrqL1z0BbwI63[0]
	QoKtPvxChMrqL1z0BbwI63 = SomeI8i56FaDMGPE.findall('"token".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if QoKtPvxChMrqL1z0BbwI63: ii1SRMJ8xhIz5yl0Xptb9a = QoKtPvxChMrqL1z0BbwI63[0]
	QoKtPvxChMrqL1z0BbwI63 = SomeI8i56FaDMGPE.findall('"visitorData".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if QoKtPvxChMrqL1z0BbwI63: i1vYajMAKUOEl0HQ = QoKtPvxChMrqL1z0BbwI63[0]
	QoKtPvxChMrqL1z0BbwI63 = SomeI8i56FaDMGPE.findall('"continuation".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if QoKtPvxChMrqL1z0BbwI63: S5Up21BfobmtXau = QoKtPvxChMrqL1z0BbwI63[0]
	cookies = ttpgqJBdkoxeKOcwaiP.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): DFVGW9wgzKuLRJOUQX1k28yZrb3M = cookies['VISITOR_INFO1_LIVE']
	data = i1vYajMAKUOEl0HQ+':::'+key+':::'+S5Up21BfobmtXau+':::'+iCQpJnV5mBPakXTgW8ufE2hF+':::'+ii1SRMJ8xhIz5yl0Xptb9a+':::'+DFVGW9wgzKuLRJOUQX1k28yZrb3M
	if ZuCJj5EwDPROkb7UXNypofl=='ytInitialData' and 'ytInitialData' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('window\["ytInitialData"\] = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not E1EoaDmpGKdi0zqWL5: E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('var ytInitialData = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',E1EoaDmpGKdi0zqWL5[0])
	elif ZuCJj5EwDPROkb7UXNypofl=='ytInitialGuideData' and 'ytInitialGuideData' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('var ytInitialGuideData = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',E1EoaDmpGKdi0zqWL5[0])
	elif '</script>' not in BsJ71WIxDtdFKveTcRPrqM4Cwb: CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',BsJ71WIxDtdFKveTcRPrqM4Cwb)
	else: CMtQ3TBJbXupf6P8ED = ''
	LCIFdjzi5kVmRwehouHQ.setSetting('av.youtube.data',data)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb,CMtQ3TBJbXupf6P8ED,data
def jjhXvULEoJkxIzae3(url):
	search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	search = search.replace(' ','+')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/search?query='+search
	rum8gIeCX3hYq(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	search = search.replace(' ','+')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAg%253D%253D'
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+BBsrSqFtMjDpoIKY9
	else:
		T2ZbMNA18WvOsyYSqLBQ4u0ol,ZIBjPHy9Muh,U2iQmHMJzoNkjORTGY7c51vZ = [],[],''
		mmrthQVHnLyUICib2F7fMzk3cBjglN = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		ynpKB512VbIQqmloa = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		vwmcuz9bM7npdBSiW = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع يوتيوب - اختر الترتيب',mmrthQVHnLyUICib2F7fMzk3cBjglN)
		if vwmcuz9bM7npdBSiW == -1: return
		Mwmvh4Z2rYbyeUNpP78REOcis = ynpKB512VbIQqmloa[vwmcuz9bM7npdBSiW]
		BsJ71WIxDtdFKveTcRPrqM4Cwb,g0gpLbIY2UnPud4WjsQKryM6wA,data = LyYjEfISpORQXlaD7PuoAzc24H0d9(vfIB6ib8q1hFX5GweRrVPNTjY2E+Mwmvh4Z2rYbyeUNpP78REOcis)
		if g0gpLbIY2UnPud4WjsQKryM6wA:
			s8sD4OlCoeIjYg3hNbUX72Qa1 = g0gpLbIY2UnPud4WjsQKryM6wA['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for CBnGvrs1AaVy0RqoT9t7Ph in range(len(s8sD4OlCoeIjYg3hNbUX72Qa1)):
				group = s8sD4OlCoeIjYg3hNbUX72Qa1[CBnGvrs1AaVy0RqoT9t7Ph]['searchFilterGroupRenderer']['filters']
				for jFnksu7ADcYreEGH38SioI9vPK4 in range(len(group)):
					TfyP0Z7gOHWGCYN3dexu2 = group[jFnksu7ADcYreEGH38SioI9vPK4]['searchFilterRenderer']
					if 'navigationEndpoint' in list(TfyP0Z7gOHWGCYN3dexu2.keys()):
						ZcAK0askvzIWr4R = TfyP0Z7gOHWGCYN3dexu2['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\u0026','&')
						title = TfyP0Z7gOHWGCYN3dexu2['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							U2iQmHMJzoNkjORTGY7c51vZ = title
							spdYctk0fWD1Z = ZcAK0askvzIWr4R
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							U2iQmHMJzoNkjORTGY7c51vZ = title
							spdYctk0fWD1Z = ZcAK0askvzIWr4R
						if 'Sort by' in title: continue
						T2ZbMNA18WvOsyYSqLBQ4u0ol.append(c8Fvb4IfHW9XkG1mLK5Z(title))
						ZIBjPHy9Muh.append(ZcAK0askvzIWr4R)
		if not U2iQmHMJzoNkjORTGY7c51vZ: ddfhrSPgUbLGHk4IKMY67oV9qDsx = ''
		else:
			T2ZbMNA18WvOsyYSqLBQ4u0ol = ['بدون فلتر',U2iQmHMJzoNkjORTGY7c51vZ]+T2ZbMNA18WvOsyYSqLBQ4u0ol
			ZIBjPHy9Muh = ['',spdYctk0fWD1Z]+ZIBjPHy9Muh
			SRNpwdbg4EDv9e2 = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع يوتيوب - اختر الفلتر',T2ZbMNA18WvOsyYSqLBQ4u0ol)
			if SRNpwdbg4EDv9e2 == -1: return
			ddfhrSPgUbLGHk4IKMY67oV9qDsx = ZIBjPHy9Muh[SRNpwdbg4EDv9e2]
		if ddfhrSPgUbLGHk4IKMY67oV9qDsx: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = aaeRjxiYcqOI6Sf8+ddfhrSPgUbLGHk4IKMY67oV9qDsx
		elif Mwmvh4Z2rYbyeUNpP78REOcis: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+Mwmvh4Z2rYbyeUNpP78REOcis
		else: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E
	rum8gIeCX3hYq(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
	return
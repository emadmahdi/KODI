# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ARABSEED'
headers = {'User-Agent':W5h0lzIcY3gMqrZpb7C()}
ToYWiIbruzUaNKRPZLG16cAj = '_ARS_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==250: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==251: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==252: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==253: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==254: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'CATEGORIES___'+text)
	elif mode==255: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FILTERS___'+text)
	elif mode==256: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url,text)
	elif mode==259: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8+'/main','',headers,'','','ARABSEED-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',aaeRjxiYcqOI6Sf8+'/category/اخرى',254)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',aaeRjxiYcqOI6Sf8+'/category/اخرى',255)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',aaeRjxiYcqOI6Sf8+'/main',251,'','','featured_main')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'جديد الأفلام',aaeRjxiYcqOI6Sf8+'/main',251,'','','new_movies')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'جديد الحلقات',aaeRjxiYcqOI6Sf8+'/main',251,'','','new_episodes')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المضاف حديثاً',aaeRjxiYcqOI6Sf8+'/latest',251,'','','lastest')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('class="MenuHeader"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	K1KV5U7JFXNPsl4h0HBd = EFOPTCNHpGvMYuS[0]
	BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR:
		title = dCFP41Kxv9j8EHM(title)
		if title not in C1pRb6K8Qs and title!='':
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,256)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def OJuEhdBtkzi5C8NfmGKgoAL0(url,type):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if 'class="SliderInSection' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in BsJ71WIxDtdFKveTcRPrqM4Cwb: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="LinksList(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			if len(pDTlIgyewF1XV69R8kd)>1 and type=='new_episodes': L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[1]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)"(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				U2iQmHMJzoNkjORTGY7c51vZ = SomeI8i56FaDMGPE.findall('</i>(.*?)<span>(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
				try: mlKGZXF5ybUTOrQNMua = U2iQmHMJzoNkjORTGY7c51vZ[0][0]
				except: mlKGZXF5ybUTOrQNMua = ''
				try: FYC61QobeDJLZwVWxB5PnuUk3NO = U2iQmHMJzoNkjORTGY7c51vZ[0][1]
				except: FYC61QobeDJLZwVWxB5PnuUk3NO = ''
				U2iQmHMJzoNkjORTGY7c51vZ = mlKGZXF5ybUTOrQNMua+FYC61QobeDJLZwVWxB5PnuUk3NO
				U2iQmHMJzoNkjORTGY7c51vZ = U2iQmHMJzoNkjORTGY7c51vZ.replace('\n','')
				if '<strong>' in title:
					mHuqifFKcryG6CEWkUXSt7Z1p = SomeI8i56FaDMGPE.findall('</i>(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
					if mHuqifFKcryG6CEWkUXSt7Z1p: U2iQmHMJzoNkjORTGY7c51vZ = mHuqifFKcryG6CEWkUXSt7Z1p[0]
				if not U2iQmHMJzoNkjORTGY7c51vZ:
					mHuqifFKcryG6CEWkUXSt7Z1p = SomeI8i56FaDMGPE.findall('alt="(.*?)"',title,SomeI8i56FaDMGPE.DOTALL)
					if mHuqifFKcryG6CEWkUXSt7Z1p: U2iQmHMJzoNkjORTGY7c51vZ = mHuqifFKcryG6CEWkUXSt7Z1p[0]
				if U2iQmHMJzoNkjORTGY7c51vZ:
					if 'key=' in ZcAK0askvzIWr4R: type = ZcAK0askvzIWr4R.split('key=')[1]
					else: type = 'newest'
					U2iQmHMJzoNkjORTGY7c51vZ = U2iQmHMJzoNkjORTGY7c51vZ.strip(' ')
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,ZcAK0askvzIWr4R,251,'','',type)
	return
def KKlnDcetq8Rrp3GY0(url,type):
	GlzqSCbyxBmVNK,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			IbKoj8ugFPlDT,ZZm1hsDV9ba = 'POST',{}
			vfIB6ib8q1hFX5GweRrVPNTjY2E,cO6niKSRzGEUTp32X1IP = url.split('?')
			IozWafE1PiOCyMLjR = cO6niKSRzGEUTp32X1IP.split('&')
			for BNvjADpPbo8fXZ6E4xLnczuWHT in IozWafE1PiOCyMLjR:
				key,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = BNvjADpPbo8fXZ6E4xLnczuWHT.split('=')
				ZZm1hsDV9ba[key] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			if IozWafE1PiOCyMLjR: GlzqSCbyxBmVNK,url,data = IbKoj8ugFPlDT,vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,GlzqSCbyxBmVNK,url,data,headers,'','','ARABSEED-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if type=='filters': pDTlIgyewF1XV69R8kd = [BsJ71WIxDtdFKveTcRPrqM4Cwb]
	elif 'featured' in type: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="MainSlides(.*?)class="LinksList',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	elif type=='new_movies': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	elif type=='new_episodes': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	elif type=='most': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="SliderInSection(.*?)class="LinksList',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="Blocks-UL"(.*?)class="AboElSeed"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if 'featured' in type:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		YyjV8EL0Gum6Jz2Wr4S = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if YyjV8EL0Gum6Jz2Wr4S:
			aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD,xxfvFunPMGQKgJ1,rJGefkS38DKoi7HIx26P = zip(*YyjV8EL0Gum6Jz2Wr4S)
			items = zip(aFyREdMQk7Ys95rX6uJieDGLS2,rJGefkS38DKoi7HIx26P,r79xJG6jXHD)
	else:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if 'WWE' in title: continue
		title = dCFP41Kxv9j8EHM(title)
		if 'الحلقة' in title:
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if iHPhR4wCQ1oINaL:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0]
				if title not in oojL40IJtK:
					oojL40IJtK.append(title)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,253,pjMZ802XQCSxYVk)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,252,pjMZ802XQCSxYVk)
		elif '/selary/' in ZcAK0askvzIWr4R or 'مسلسل' in title:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,253,pjMZ802XQCSxYVk)
		else:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,252,pjMZ802XQCSxYVk)
	if type in ['newest','best','most']:
		items = SomeI8i56FaDMGPE.findall('page-numbers" href="(.*?)">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,251,'','',type)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb[10000:]
	items = SomeI8i56FaDMGPE.findall('data-src="(.*?)".*?alt="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not items: return
	pjMZ802XQCSxYVk,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="ContainerEpisodesList"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<em>(.*?)</em>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,iHPhR4wCQ1oINaL in items:
			title = name+' - الحلقة رقم '+iHPhR4wCQ1oINaL
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,252,pjMZ802XQCSxYVk)
	else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+'ملف التشغيل',url,252,pjMZ802XQCSxYVk)
	return
def UdXlVt4Zh6B931(title,ZcAK0askvzIWr4R):
	U2iQmHMJzoNkjORTGY7c51vZ = SomeI8i56FaDMGPE.findall('[a-zA-Z-]+',title,SomeI8i56FaDMGPE.DOTALL)
	if U2iQmHMJzoNkjORTGY7c51vZ: title = U2iQmHMJzoNkjORTGY7c51vZ[0]
	else: title = title+' '+DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	vfIB6ib8q1hFX5GweRrVPNTjY2E = ttpgqJBdkoxeKOcwaiP.url
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
	headers['Referer'] = FglT5H2faVGm6IqpcXS9vQsojPLu+'/'
	TbYW7z8kxgVln,o9EhkpbY08dez3t,aFyREdMQk7Ys95rX6uJieDGLS2 = '','',[]
	xWhbwZYyir6ncsRtS = SomeI8i56FaDMGPE.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if xWhbwZYyir6ncsRtS: TbYW7z8kxgVln,hv54R8NjbFqzOS6x9PIsu,o9EhkpbY08dez3t,C4CEWLV96T8Dwzd = xWhbwZYyir6ncsRtS[0]
	else:
		xWhbwZYyir6ncsRtS = SomeI8i56FaDMGPE.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if xWhbwZYyir6ncsRtS:
			ZcAK0askvzIWr4R,hv54R8NjbFqzOS6x9PIsu = xWhbwZYyir6ncsRtS[0]
			if 'watch' in hv54R8NjbFqzOS6x9PIsu: TbYW7z8kxgVln = ZcAK0askvzIWr4R
			else: o9EhkpbY08dez3t = ZcAK0askvzIWr4R
	if TbYW7z8kxgVln:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',TbYW7z8kxgVln,'',headers,'','','ARABSEED-PLAY-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="WatcherArea"(.*?</ul>)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			YYUcMwIjuEJLqGVK5hzpAl = pDTlIgyewF1XV69R8kd[0]
			YYUcMwIjuEJLqGVK5hzpAl = YYUcMwIjuEJLqGVK5hzpAl.replace('</ul>','<h3>')
			YYUcMwIjuEJLqGVK5hzpAl = YYUcMwIjuEJLqGVK5hzpAl.replace('<h3>','<h3><h3>')
			UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('<h3>.*?(\d+)(.*?)<h3>',YYUcMwIjuEJLqGVK5hzpAl,SomeI8i56FaDMGPE.DOTALL)
			if not UUTVrGP7Y31a: UUTVrGP7Y31a = [('',YYUcMwIjuEJLqGVK5hzpAl)]
			for AfejZJoKh4D7k5G1P9gCwxTz,L0Uwx52bTBM in UUTVrGP7Y31a:
				if AfejZJoKh4D7k5G1P9gCwxTz: AfejZJoKh4D7k5G1P9gCwxTz = '____'+AfejZJoKh4D7k5G1P9gCwxTz
				items = SomeI8i56FaDMGPE.findall('data-link="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				for ZcAK0askvzIWr4R,name in items:
					if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
					ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+name+'__watch'+AfejZJoKh4D7k5G1P9gCwxTz
					aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not ZZHhmdtY1g: ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if ZZHhmdtY1g:
			ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz = ZZHhmdtY1g[0]
			name = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			if '%' in AfejZJoKh4D7k5G1P9gCwxTz: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+name+'__embed__'
			else: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+name+'__embed____'+AfejZJoKh4D7k5G1P9gCwxTz
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if o9EhkpbY08dez3t:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',o9EhkpbY08dez3t,'',headers,'','','ARABSEED-PLAY-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="DownloadArea"(.*?)function',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title,AfejZJoKh4D7k5G1P9gCwxTz in items:
				if not ZcAK0askvzIWr4R: continue
				if 'reviewstation' in ZcAK0askvzIWr4R: continue
				ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download____'+AfejZJoKh4D7k5G1P9gCwxTz
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	Mv0XhUDOJKmGqg4H7C3Zt = str(aFyREdMQk7Ys95rX6uJieDGLS2)
	qda6xUMKZRXEQOs5m1gzV0Y2tLNWk = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Mv0XhUDOJKmGqg4H7C3Zt for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in qda6xUMKZRXEQOs5m1gzV0Y2tLNWk):
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search: search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/find/?find='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='CATEGORIES':
		if ya53wlDEI9coHnh[0]+'==' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = ya53wlDEI9coHnh[0]
		for zz5ZOaoyATpS893tvdXE in range(len(ya53wlDEI9coHnh[0:-1])):
			if ya53wlDEI9coHnh[zz5ZOaoyATpS893tvdXE]+'==' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = ya53wlDEI9coHnh[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'==0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'==0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'//getposts??'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FILTERS':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'//getposts??'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		jx63XqgpYedEM1lZ = T5TpS7oqBAFtvgdVxwHlN(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',jx63XqgpYedEM1lZ,251,'','','filters')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',jx63XqgpYedEM1lZ,251,'','','filters')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	raez5nldYotLRUuMmwNX = SomeI8i56FaDMGPE.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	ruTRcfGbpM8ojD = SomeI8i56FaDMGPE.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = raez5nldYotLRUuMmwNX+ruTRcfGbpM8ojD
	dict = {}
	for name,mjcA3DUe9IJV4bk,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		items = SomeI8i56FaDMGPE.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('data-rate="(.*?)".*?<em>(.*?)</em>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			items = []
			for irE1qv3BUYZMo5,EPwT39HrS1tU6Ng8YBGpJADixzLV5C in BAHbWtFdwNps9ZVUfvR: items.append([irE1qv3BUYZMo5,'',EPwT39HrS1tU6Ng8YBGpJADixzLV5C])
			mjcA3DUe9IJV4bk = 'rate'
			name = 'التقييم'
		else: mjcA3DUe9IJV4bk = items[0][1]
		if '==' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='CATEGORIES':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<=1:
				if mjcA3DUe9IJV4bk==ya53wlDEI9coHnh[-1]: KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'CATEGORIES___'+ecMSxgw2QqpvI)
				return
			else:
				jx63XqgpYedEM1lZ = T5TpS7oqBAFtvgdVxwHlN(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				if mjcA3DUe9IJV4bk==ya53wlDEI9coHnh[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',jx63XqgpYedEM1lZ,251,'','','filters')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',vfIB6ib8q1hFX5GweRrVPNTjY2E,254,'','',ecMSxgw2QqpvI)
		elif type=='FILTERS':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&&'+mjcA3DUe9IJV4bk+'==0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&&'+mjcA3DUe9IJV4bk+'==0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,255,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for irE1qv3BUYZMo5,fYZzomwSjkedXVcEvLDqKHMt9rFnN,EPwT39HrS1tU6Ng8YBGpJADixzLV5C in items:
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			if 'الكل' in irE1qv3BUYZMo5: continue
			irE1qv3BUYZMo5 = dCFP41Kxv9j8EHM(irE1qv3BUYZMo5)
			uZfwDbhTs2V5dp,U2iQmHMJzoNkjORTGY7c51vZ = irE1qv3BUYZMo5,irE1qv3BUYZMo5
			U2iQmHMJzoNkjORTGY7c51vZ = name+': '+uZfwDbhTs2V5dp
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = U2iQmHMJzoNkjORTGY7c51vZ
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&&'+mjcA3DUe9IJV4bk+'=='+uZfwDbhTs2V5dp
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&&'+mjcA3DUe9IJV4bk+'=='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			if type=='FILTERS':
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,url,255,'','',L6iYCRsI1U4ytrW)
			elif type=='CATEGORIES' and ya53wlDEI9coHnh[-2]+'==' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'//getposts??'+rm1tgvkXOihGYpLJnzuHwyPSZA
				jx63XqgpYedEM1lZ = T5TpS7oqBAFtvgdVxwHlN(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,jx63XqgpYedEM1lZ,251,'','','filters')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,url,254,'','',L6iYCRsI1U4ytrW)
	return
ya53wlDEI9coHnh = ['category','country','release-year']
XXT7AYQdyE4pMluhBRjwUekcCziFLS = ['category','country','genre','release-year','language','quality','rate']
def T5TpS7oqBAFtvgdVxwHlN(url):
	z3wH8u4Em5ZK7 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',z3wH8u4Em5ZK7)
	url = url.replace('/category/اخرى','')
	if z3wH8u4Em5ZK7 not in url: url = url+z3wH8u4Em5ZK7
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&&')
	tSCH1cAvm5Ki,y4rSdac1zC26FA9IZnuO7WRU = {},''
	if '==' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('==')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	for key in XXT7AYQdyE4pMluhBRjwUekcCziFLS:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&&'+key+'=='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&&'+key+'=='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&&')
	return y4rSdac1zC26FA9IZnuO7WRU
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMANOW'
ToYWiIbruzUaNKRPZLG16cAj = '_CMN_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['قائمتي']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==300: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==301: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==302: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==303: rr60PDpqbMehZsYVuHmiAtN = Zo7UmLDVAaduH2IC9xTQbqcXjNh(url)
	elif mode==304: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==305: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==306: rr60PDpqbMehZsYVuHmiAtN = oXUTNd8L3b0iD()
	elif mode==309: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'لماذا الموقع بطيء','',306)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8+'/home','','','','','CIMANOW-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<header>(.*?)</header>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('<li><a href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		title = title.strip(' ')
		if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,301)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	OJuEhdBtkzi5C8NfmGKgoAL0(aaeRjxiYcqOI6Sf8+'/home',BsJ71WIxDtdFKveTcRPrqM4Cwb)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def oXUTNd8L3b0iD():
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def OJuEhdBtkzi5C8NfmGKgoAL0(url,BsJ71WIxDtdFKveTcRPrqM4Cwb=''):
	if not BsJ71WIxDtdFKveTcRPrqM4Cwb:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	XBMyFqAriL = 0
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(<section>.*?</section>)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		for L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			XBMyFqAriL += 1
			items = SomeI8i56FaDMGPE.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for title,YKIqlLpOB0xsf,ZcAK0askvzIWr4R in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in YKIqlLpOB0xsf:
					if L0Uwx52bTBM.count('/category/')>0:
						L8nS9WGlViQCEJxsfFj4RgM = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
						for ZcAK0askvzIWr4R in L8nS9WGlViQCEJxsfFj4RgM:
							title = ZcAK0askvzIWr4R.split('/')[-2]
							UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,301)
						continue
					else: ZcAK0askvzIWr4R = url+'?sequence='+str(XBMyFqAriL)
				if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,302)
	else: KKlnDcetq8Rrp3GY0(url,BsJ71WIxDtdFKveTcRPrqM4Cwb)
	return
def KKlnDcetq8Rrp3GY0(url,BsJ71WIxDtdFKveTcRPrqM4Cwb=''):
	if BsJ71WIxDtdFKveTcRPrqM4Cwb=='':
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMANOW-TITLES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if '?sequence=' in url:
		url,XBMyFqAriL = url.split('?sequence=')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(<section>.*?</section>)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[int(XBMyFqAriL)-1]
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"posts"(.*?)</body>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for ZcAK0askvzIWr4R,data,pjMZ802XQCSxYVk in items:
		title = SomeI8i56FaDMGPE.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,SomeI8i56FaDMGPE.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = SomeI8i56FaDMGPE.findall('title">.*?</em>(.*?)<',data,SomeI8i56FaDMGPE.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = SomeI8i56FaDMGPE.findall('title">(.*?)<',data,SomeI8i56FaDMGPE.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = dCFP41Kxv9j8EHM(title)
		if title not in oojL40IJtK:
			oojL40IJtK.append(title)
			K1KV5U7JFXNPsl4h0HBd = ZcAK0askvzIWr4R+data+pjMZ802XQCSxYVk
			if '/selary/' in K1KV5U7JFXNPsl4h0HBd or 'مسلسل' in K1KV5U7JFXNPsl4h0HBd or '"episode"' in K1KV5U7JFXNPsl4h0HBd:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,303,pjMZ802XQCSxYVk)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,305,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<li><a href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,302)
	return
def Zo7UmLDVAaduH2IC9xTQbqcXjNh(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	name = SomeI8i56FaDMGPE.findall('<title>(.*?)</title>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"seasons"(.*?)</section>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if len(items)>1:
			for ZcAK0askvzIWr4R,title in items:
				title = title.replace('\n','').strip(' ')
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,304)
		else: ooLCwrlF3n0vBjpA(url)
	return
def ooLCwrlF3n0vBjpA(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if '/selary/' not in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"episodes"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,305)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"details"(.*?)"related"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			title = title.replace('\n','').strip(' ')
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,305,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'watching/'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMANOW-PLAY-5th')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"download"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.replace('\n','').strip(' ')
			AfejZJoKh4D7k5G1P9gCwxTz = SomeI8i56FaDMGPE.findall('\d\d\d+',title,SomeI8i56FaDMGPE.DOTALL)
			if AfejZJoKh4D7k5G1P9gCwxTz:
				AfejZJoKh4D7k5G1P9gCwxTz = '____'+AfejZJoKh4D7k5G1P9gCwxTz[0]
				title = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			else: AfejZJoKh4D7k5G1P9gCwxTz = ''
			spdYctk0fWD1Z = ZcAK0askvzIWr4R+'?named='+title+'__download'+AfejZJoKh4D7k5G1P9gCwxTz
			aFyREdMQk7Ys95rX6uJieDGLS2.append(spdYctk0fWD1Z)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"watch"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('"embed".*?src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in ZZHhmdtY1g:
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
			title = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__embed'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		ZZHhmdtY1g = [aaeRjxiYcqOI6Sf8+'/wp-content/themes/Cima%20Now%20New/core.php']
		if ZZHhmdtY1g:
			items = SomeI8i56FaDMGPE.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for fMGn2cXPKw9SyUY,id,title in items:
				title = title.replace('\n','').strip(' ')
				ZcAK0askvzIWr4R = ZZHhmdtY1g[0]+'?action=switch&index='+fMGn2cXPKw9SyUY+'&id='+id+'?named='+title+'__watch'
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + '/?s='+search
	KKlnDcetq8Rrp3GY0(url)
	return
# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
import xbmc as WCdaXB2bfwyI0S3Fqet1LQoO5Rhv,re as SomeI8i56FaDMGPE,sys as EuOf9ozUdyP,xbmcaddon as VmrWjDNze5tadycvpHOGnTb,random as ttczT0JFy9xID3iLGMXoQm2hjB4,os as Dh9MOxeTj6FW,xbmcvfs as bPsqMHSitNmy3uZQ,time as p1BoraOuWL,pickle as KKHQRVq2XvWbsap7Tx,zlib as oLY8VsFGH7NCfujRnEa5r,xbmcgui as N7zpvB3VIPrwcSDEC,xbmcplugin as YRyCdPm9JnNZ5vf,sqlite3 as RH0kWPhBvOFlu3m1eSqEj9,traceback as AXKHbaOBizntvlsSqP3E5D,threading as RrCB5k9XV6hYNSlIKJ2
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = eaF2N0jWLdvHIs8r(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
gyXBVnYKzm4 = VmrWjDNze5tadycvpHOGnTb.Addon().getAddonInfo(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࡶࡡࡵࡪࠪ਱"))
Zz2HFsAUjy = Dh9MOxeTj6FW.path.join(gyXBVnYKzm4,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
EuOf9ozUdyP.path.append(Zz2HFsAUjy)
StEXpdf2BL3wkh1izc8snHFMNAPWql = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(gy9NA3CROZolfEt4vVzMr(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
Qf8xsJSwoKaUNc = SomeI8i56FaDMGPE.findall(FZBX5WcC3msIDv4hobLd8(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),StEXpdf2BL3wkh1izc8snHFMNAPWql,SomeI8i56FaDMGPE.DOTALL)
Qf8xsJSwoKaUNc = float(Qf8xsJSwoKaUNc[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠱௴")])
IMwE4bxTmG0t6pnRQXLkZ5J7Ndsjuq = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.Player
RNxwXqM38FQEIzP4in6oeJyOcvSjZh = N7zpvB3VIPrwcSDEC.WindowXMLDialog
BhTAck1bPFYGuUqRW = Qf8xsJSwoKaUNc<FZBX5WcC3msIDv4hobLd8(u"࠳࠼௵")
ZZxLpCcmqhyT6NuMWelkbSvr0H = Qf8xsJSwoKaUNc>Y5npATFarf1H9wBjc87(u"࠴࠼࠳࠿࠹௶")
if ZZxLpCcmqhyT6NuMWelkbSvr0H:
	QN8g0ETaHRW2d39FivOKhyoDUkm4sA = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.LOGINFO
	H02Qqy4XO9L3Dui6S8PGWxJt,spTWfEz2PU9AL = IPkQW7LojF3HO18V(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),NQ4hg16DPUxtOyo5iGb(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	tkTwOUN6i3zfmosJjR = bPsqMHSitNmy3uZQ.translatePath(Y5npATFarf1H9wBjc87(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _kJ62nAb1OX4sgFRwGdM9mcSo3
else:
	QN8g0ETaHRW2d39FivOKhyoDUkm4sA = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.LOGNOTICE
	H02Qqy4XO9L3Dui6S8PGWxJt,spTWfEz2PU9AL = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(QQSULIva4ljNO73mFcWw(u"࠭ࡵࡵࡨ࠻ࠫਹ")),hxSBTdGpyNVbfu4tr9(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡷࡷࡪ࠽࠭਻"))
	tkTwOUN6i3zfmosJjR = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.translatePath(onweDvmTOUj(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _kJ62nAb1OX4sgFRwGdM9mcSo3
IawroWLYiTh2UCODE7zfNlGBKHk3 = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠺࠵௷")
nh1uLlGma8wJVsAMyKxkjC9N = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠻࠶௸")*IawroWLYiTh2UCODE7zfNlGBKHk3
EEx5baCQn6rPzBvkFRoqT = Sj1PYDmIpCUXO26(u"࠸࠴௹")*nh1uLlGma8wJVsAMyKxkjC9N
FLMk6f3zuVh9jQYX5BJGvgnIyb = lh6URegmQNq8LWX0HaK5(u"࠳࠱௺")*EEx5baCQn6rPzBvkFRoqT
jj0C6IlvPFh = MOwK1lpyNfCgqksX3jhV(u"࠲࠸௻")*nh1uLlGma8wJVsAMyKxkjC9N
IIbavC96MQ1nHq3Pjx = onweDvmTOUj(u"࠵௼")*EEx5baCQn6rPzBvkFRoqT
bY2n5MtVA4cjpkFSxZ6K = QQSULIva4ljNO73mFcWw(u"࠴࠶௽")*FLMk6f3zuVh9jQYX5BJGvgnIyb
giwrh4jLPc = EuOf9ozUdyP.argv[wKdxVbTc0X9NSiespM8OvHGUhf(u"࠴௾")].split(LsG7EDcei1gMShH2aVOCo(u"ࠪ࠳ࠬ਽"))[B2vCEI9FAVP15R8eUbDJdySc(u"࠷௿")]
yR8fePHkvJnx3K0FQVs = int(EuOf9ozUdyP.argv[lh6URegmQNq8LWX0HaK5(u"࠷ఀ")])
StrQOzK40pE8Dbgdj95U = EuOf9ozUdyP.argv[aSf0iWG1kA7FsqjHbuC8NXB(u"࠲ఁ")]
dVm0TRNy8soH9QXqrgiPUe = giwrh4jLPc.split(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫ࠳࠭ਾ"))[Sj1PYDmIpCUXO26(u"࠳ం")]
Y0Uhv2t8E67 = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(FZBX5WcC3msIDv4hobLd8(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+giwrh4jLPc+RS7ZoyGAq1c(u"࠭ࠩࠨੀ"))
Vd1J5lD9uAsMUoXW = Dh9MOxeTj6FW.path.join(tkTwOUN6i3zfmosJjR,giwrh4jLPc)
qQ4BC6vW5YOfo = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,FZBX5WcC3msIDv4hobLd8(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
kRpnCV8cqdhDew2suUxPfaQTA5 = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,Jbu2G0Qax8PYWpg(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
CHhSItjbXy = int(p1BoraOuWL.time())
LCIFdjzi5kVmRwehouHQ = VmrWjDNze5tadycvpHOGnTb.Addon(id=giwrh4jLPc)
def RyQ1vTDniwqI7jCNMHmtcLaVK(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,RFfh93jdt8ora=MOwK1lpyNfCgqksX3jhV(u"ࠩࡂࠫ੃")):
	if Y5npATFarf1H9wBjc87(u"ࠪࡁࠬ੄") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX:
		if RFfh93jdt8ora in xTFHrZ1nGWa9fdqsSA5y4htgJNmX: vfIB6ib8q1hFX5GweRrVPNTjY2E,dWtJP0yIT5KLQHbf = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.split(RFfh93jdt8ora,FZBX5WcC3msIDv4hobLd8(u"࠳ః"))
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E,dWtJP0yIT5KLQHbf = Y5npATFarf1H9wBjc87(u"ࠫࠬ੅"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX
		dWtJP0yIT5KLQHbf = dWtJP0yIT5KLQHbf.split(eaF2N0jWLdvHIs8r(u"ࠬࠬࠧ੆"))
		ZZm1hsDV9ba = {}
		for I4fRaQvPOd1hJwu0Mp5SYlToCD3i in dWtJP0yIT5KLQHbf:
			Y9orNmEJt8OWyM72vGafZleg5z4,V0UzjKdk3gOnmN4GYt5vix2e = I4fRaQvPOd1hJwu0Mp5SYlToCD3i.split(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࠽ࠨੇ"),d0HDrq8Rtk16AlInw4TXb(u"࠴ఄ"))
			ZZm1hsDV9ba[Y9orNmEJt8OWyM72vGafZleg5z4] = V0UzjKdk3gOnmN4GYt5vix2e
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = xTFHrZ1nGWa9fdqsSA5y4htgJNmX,{}
	return vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba
def aDebGvrkdptunqTM8m4(xTFHrZ1nGWa9fdqsSA5y4htgJNmX):
	return _kJ62nAb1OX4sgFRwGdM9mcSo3(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
def miyYvukojaRTM0gDtbCfK(ifDUw1Im4VRlg5zpaOXAPZQyqH7xo):
	GiSIk6LgrEOsRMUnx2V9HzfDJoaBN = {FZBX5WcC3msIDv4hobLd8(u"ࠧࡵࡻࡳࡩࠬੈ"):KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࠩ੉"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡰࡳࡩ࡫ࠧ੊"):LsG7EDcei1gMShH2aVOCo(u"ࠪࠫੋ"),Y5npATFarf1H9wBjc87(u"ࠫࡺࡸ࡬ࠨੌ"):d0HDrq8Rtk16AlInw4TXb(u"੍ࠬ࠭"),QQSULIva4ljNO73mFcWw(u"࠭ࡴࡦࡺࡷࠫ੎"):RS7ZoyGAq1c(u"ࠧࠨ੏"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡲࡤ࡫ࡪ࠭੐"):MOwK1lpyNfCgqksX3jhV(u"ࠩࠪੑ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡲࡦࡳࡥࠨ੒"):WWbmNvI40sM9Khlp25Ae(u"ࠫࠬ੓"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):onweDvmTOUj(u"࠭ࠧ੕"),Y5npATFarf1H9wBjc87(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):lh6URegmQNq8LWX0HaK5(u"ࠨࠩ੗"),NQ4hg16DPUxtOyo5iGb(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):Sj1PYDmIpCUXO26(u"ࠪࠫਖ਼")}
	if a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡄ࠭ਗ਼") in ifDUw1Im4VRlg5zpaOXAPZQyqH7xo: ifDUw1Im4VRlg5zpaOXAPZQyqH7xo = ifDUw1Im4VRlg5zpaOXAPZQyqH7xo.split(QQSULIva4ljNO73mFcWw(u"ࠬࡅࠧਜ਼"),mtEXp14ijx(u"࠵అ"))[mtEXp14ijx(u"࠵అ")]
	vfIB6ib8q1hFX5GweRrVPNTjY2E,WYbSemBvDao491RuwOVc3A = RyQ1vTDniwqI7jCNMHmtcLaVK(ifDUw1Im4VRlg5zpaOXAPZQyqH7xo)
	aargs = dict(list(GiSIk6LgrEOsRMUnx2V9HzfDJoaBN.items())+list(WYbSemBvDao491RuwOVc3A.items()))
	R6ROsBCycLjFMtYDk04A = aargs[MOwK1lpyNfCgqksX3jhV(u"࠭࡭ࡰࡦࡨࠫੜ")]
	wnpJZgr3dKeoyuQUXsvM60B2T9N8 = aDebGvrkdptunqTM8m4(aargs[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࡶࡴ࡯ࠫ੝")])
	YYodOrv6EGWm0p8ls3UFKwaZtSufX = aDebGvrkdptunqTM8m4(aargs[QQSULIva4ljNO73mFcWw(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	YHAzVdDlb0Ea2CMyO39 = aDebGvrkdptunqTM8m4(aargs[IPkQW7LojF3HO18V(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	ldnozWtegYayOjGq249SU3X6xuJfZk = aDebGvrkdptunqTM8m4(aargs[d0HDrq8Rtk16AlInw4TXb(u"ࠪࡸࡾࡶࡥࠨ੠")])
	onHbevfWF7j3EIA = aDebGvrkdptunqTM8m4(aargs[wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	HhYcglIx1BQ7R = aDebGvrkdptunqTM8m4(aargs[MOwK1lpyNfCgqksX3jhV(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	z8gRkejGf9s3WLNwunliYITEXyaqM = aargs[d0HDrq8Rtk16AlInw4TXb(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	AzZe4BbaCFKNYw = aDebGvrkdptunqTM8m4(aargs[hxSBTdGpyNVbfu4tr9(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if AzZe4BbaCFKNYw: AzZe4BbaCFKNYw = eval(AzZe4BbaCFKNYw)
	else: AzZe4BbaCFKNYw = {}
	if not R6ROsBCycLjFMtYDk04A: ldnozWtegYayOjGq249SU3X6xuJfZk = hxSBTdGpyNVbfu4tr9(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; R6ROsBCycLjFMtYDk04A = d0HDrq8Rtk16AlInw4TXb(u"ࠩ࠵࠺࠵࠭੦")
	return ldnozWtegYayOjGq249SU3X6xuJfZk,onHbevfWF7j3EIA,wnpJZgr3dKeoyuQUXsvM60B2T9N8,R6ROsBCycLjFMtYDk04A,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,YYodOrv6EGWm0p8ls3UFKwaZtSufX,z8gRkejGf9s3WLNwunliYITEXyaqM,AzZe4BbaCFKNYw
def zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu):
	XW9e24ufgPSBqIhZ3m6v = EuOf9ozUdyP._getframe(wKdxVbTc0X9NSiespM8OvHGUhf(u"࠶ఆ")).f_code.co_name
	if not HmvY29bj4dNgF7wZqr1lzkeQxiEasu or not XW9e24ufgPSBqIhZ3m6v or XW9e24ufgPSBqIhZ3m6v==LsG7EDcei1gMShH2aVOCo(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡠࠦࠧ੨")+dVm0TRNy8soH9QXqrgiPUe.upper()+Sj1PYDmIpCUXO26(u"ࠬ࠳ࠧ੩")+Y0Uhv2t8E67+FZBX5WcC3msIDv4hobLd8(u"࠭࠭ࠨ੪")+str(Qf8xsJSwoKaUNc)+IPkQW7LojF3HO18V(u"ࠧࠡ࡟ࠪ੫")
	return MOwK1lpyNfCgqksX3jhV(u"ࠨ࠰ࠣࠤࠬ੬")+XW9e24ufgPSBqIhZ3m6v
def xrFqGMab4uLKZcS(b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm,RkL9ljZpIhdrutK0OmN7Uc):
	if BhTAck1bPFYGuUqRW: RkL9ljZpIhdrutK0OmN7Uc = RkL9ljZpIhdrutK0OmN7Uc.decode(mtEXp14ijx(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(IPkQW7LojF3HO18V(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	I8hgZVsmYyaq9KpBlC0 = QN8g0ETaHRW2d39FivOKhyoDUkm4sA
	IozWafE1PiOCyMLjR = [LsG7EDcei1gMShH2aVOCo(u"ࠫࠬ੯"),RS7ZoyGAq1c(u"ࠬ࠭ੰ")]
	if b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm: RkL9ljZpIhdrutK0OmN7Uc = RkL9ljZpIhdrutK0OmN7Uc.replace(wKdxVbTc0X9NSiespM8OvHGUhf(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠨੲ")).replace(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࠪੴ")).replace(eaF2N0jWLdvHIs8r(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࠬ੶"))
	else: b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	AAwdBvW7c34FZmUg5,RFfh93jdt8ora,FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠠࠡࠢࠣࠫ੸"),IPkQW7LojF3HO18V(u"ࠧࠡࠢࠣࠫ੹"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࠩ੺")
	if hxSBTdGpyNVbfu4tr9(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm: I8hgZVsmYyaq9KpBlC0 = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.LOGERROR
	if b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		RkL9ljZpIhdrutK0OmN7Uc = RkL9ljZpIhdrutK0OmN7Uc+RFfh93jdt8ora
		IozWafE1PiOCyMLjR = RkL9ljZpIhdrutK0OmN7Uc.split(RFfh93jdt8ora)
		FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx = AAwdBvW7c34FZmUg5
	elif b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm==q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		RkL9ljZpIhdrutK0OmN7Uc = RkL9ljZpIhdrutK0OmN7Uc.replace(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࠴ࠧ੾")+RFfh93jdt8ora,RS7ZoyGAq1c(u"࠭࠮ࠡࠢࠪ੿"))
		IozWafE1PiOCyMLjR = RkL9ljZpIhdrutK0OmN7Uc.split(RFfh93jdt8ora)
		IozWafE1PiOCyMLjR[Y5npATFarf1H9wBjc87(u"࠰ఈ")] = d0HDrq8Rtk16AlInw4TXb(u"ࠧ࠯ࠩ઀")+IozWafE1PiOCyMLjR[Y5npATFarf1H9wBjc87(u"࠰ఈ")][Jbu2G0Qax8PYWpg(u"࠷ఇ"):]
		FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx = AAwdBvW7c34FZmUg5+RFfh93jdt8ora
	elif b6tHI8PQx1zpTUKLeCV4c5AjhiMqrm in [q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡈࡖࡗࡕࡒࠨં")]: IozWafE1PiOCyMLjR = RkL9ljZpIhdrutK0OmN7Uc.split(AAwdBvW7c34FZmUg5)
	FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx += onweDvmTOUj(u"࠷ఉ")*AAwdBvW7c34FZmUg5
	NiOE5pD9hLlQZ = MOwK1lpyNfCgqksX3jhV(u"࠵ఊ")*AAwdBvW7c34FZmUg5
	if Qf8xsJSwoKaUNc>IPkQW7LojF3HO18V(u"࠵࠼࠴࠹࠺ఌ"): FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx += lh6URegmQNq8LWX0HaK5(u"࠴࠵ఋ")*FZBX5WcC3msIDv4hobLd8(u"ࠪࠤࠬઃ")
	YtFZqT9pcQR1HLjyMDsi = IozWafE1PiOCyMLjR[FZBX5WcC3msIDv4hobLd8(u"࠵఍")]
	for DUaE01KxW4A9rtwTizg2OV in IozWafE1PiOCyMLjR[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷ఎ"):]:
		if OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡡࡴࠧ઄") in DUaE01KxW4A9rtwTizg2OV: DUaE01KxW4A9rtwTizg2OV = DUaE01KxW4A9rtwTizg2OV.replace(Q2ZyGqCNYsftTc4MR7n(u"ࠬࡢ࡮ࠨઅ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭࡜࡯ࠩઆ")+AAwdBvW7c34FZmUg5+AAwdBvW7c34FZmUg5)
		NiOE5pD9hLlQZ += AAwdBvW7c34FZmUg5
		YtFZqT9pcQR1HLjyMDsi += Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧ࡝ࡴࠪઇ")+FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx+NiOE5pD9hLlQZ+DUaE01KxW4A9rtwTizg2OV
	YtFZqT9pcQR1HLjyMDsi += aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠢࡢࠫઈ")
	if Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࠨࠫઉ") in YtFZqT9pcQR1HLjyMDsi: YtFZqT9pcQR1HLjyMDsi = aDebGvrkdptunqTM8m4(YtFZqT9pcQR1HLjyMDsi)
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.log(YtFZqT9pcQR1HLjyMDsi,level=I8hgZVsmYyaq9KpBlC0)
	return
def NLCg4kvQr2Yz8Bue3dhXwA(wl4oO8z5SgGnF3HJEDjbUh):
	Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(wl4oO8z5SgGnF3HJEDjbUh)
	lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
	lU7cFRC6jSwkVLTmIM.execute(eaF2N0jWLdvHIs8r(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	lU7cFRC6jSwkVLTmIM.execute(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	lU7cFRC6jSwkVLTmIM.execute(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	lU7cFRC6jSwkVLTmIM.execute(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	lU7cFRC6jSwkVLTmIM.execute(Sj1PYDmIpCUXO26(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	lU7cFRC6jSwkVLTmIM.execute(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
	return Iof8U0xDKbVslWATpzR4OvBe9,lU7cFRC6jSwkVLTmIM
def ppr4YNOjLsDUF1K6Zh9mkbwXaH(wl4oO8z5SgGnF3HJEDjbUh,SQpdvB5OGRJwP,W5WfNIgQVnzB7cPOkZE=None):
	try: Iof8U0xDKbVslWATpzR4OvBe9,lU7cFRC6jSwkVLTmIM = NLCg4kvQr2Yz8Bue3dhXwA(wl4oO8z5SgGnF3HJEDjbUh)
	except: return
	if W5WfNIgQVnzB7cPOkZE==None: lU7cFRC6jSwkVLTmIM.execute(d0HDrq8Rtk16AlInw4TXb(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+SQpdvB5OGRJwP+gy9NA3CROZolfEt4vVzMr(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		K38mQ0viwSnkBFaGpTZj = (str(W5WfNIgQVnzB7cPOkZE),)
		try:
			if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࠪ࠭઒") in W5WfNIgQVnzB7cPOkZE: lU7cFRC6jSwkVLTmIM.execute(Jbu2G0Qax8PYWpg(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+SQpdvB5OGRJwP+Q2ZyGqCNYsftTc4MR7n(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),K38mQ0viwSnkBFaGpTZj)
			else: lU7cFRC6jSwkVLTmIM.execute(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+SQpdvB5OGRJwP+eaF2N0jWLdvHIs8r(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),K38mQ0viwSnkBFaGpTZj)
		except: pass
	Iof8U0xDKbVslWATpzR4OvBe9.commit()
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	return
class uuU7W1qvpS5GjPxanJ(): pass
class KKTc4gCGlPOW2F36ibxUd8NVDHB(uuU7W1qvpS5GjPxanJ):
	def __init__(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.url = hxSBTdGpyNVbfu4tr9(u"ࠩࠪગ")
		KETCehUc1vtORaPl03xDwV.code = -eaF2N0jWLdvHIs8r(u"࠹࠺ఏ")
		KETCehUc1vtORaPl03xDwV.reason = onweDvmTOUj(u"ࠪࠫઘ")
		KETCehUc1vtORaPl03xDwV.content = d0HDrq8Rtk16AlInw4TXb(u"ࠫࠬઙ")
		KETCehUc1vtORaPl03xDwV.headers = {}
		KETCehUc1vtORaPl03xDwV.cookies = {}
		KETCehUc1vtORaPl03xDwV.succeeded = lh6URegmQNq8LWX0HaK5(u"ࡇࡣ࡯ࡷࡪౖ")
def wWMgaIdEk1s0uHGnSc8(DQs7pSx58I4n):
	if DQs7pSx58I4n==Sj1PYDmIpCUXO26(u"ࠬࡪࡩࡤࡶࠪચ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = {}
	elif DQs7pSx58I4n==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭࡬ࡪࡵࡷࠫછ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = []
	elif DQs7pSx58I4n==q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࡴࡶࡵࠫજ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = RS7ZoyGAq1c(u"ࠨࠩઝ")
	elif DQs7pSx58I4n==Y5npATFarf1H9wBjc87(u"ࠩ࡬ࡲࡹ࠭ઞ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠱ఐ")
	elif DQs7pSx58I4n==onweDvmTOUj(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = KKTc4gCGlPOW2F36ibxUd8NVDHB()
	elif not DQs7pSx58I4n: oo76muA1GlEh9s0ZHNT4yMXQzipP = None
	else: oo76muA1GlEh9s0ZHNT4yMXQzipP = None
	return oo76muA1GlEh9s0ZHNT4yMXQzipP
def tvwmlYcDnVybgPHKU84GOFI0uAq(GbXaDx7CQ39VzHpcNgPSZhAMRBJ2):
	from hashlib import md5 as v0vrR8AL5UbCzsFQdlo
	WWnxl3b90UcQiuZzqdICNvOsaB7 = LCIFdjzi5kVmRwehouHQ.getSetting(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	SaCnW14s6emKoUO7PuvTLB = vT7q0oj96p(onweDvmTOUj(u"࠵࠵఑")).splitlines()
	PuoWQnmaDdJ70As825hxGyr = str(CHhSItjbXy*hxSBTdGpyNVbfu4tr9(u"࠶࠶࠰࠱࠲࠳࠲࠵ఔ")/RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠸࠸࠸࠰࠱࠲ఓ"))[lh6URegmQNq8LWX0HaK5(u"࠳ఒ"):eaF2N0jWLdvHIs8r(u"࠺క")]
	for r64TFJvgaYLQHXyqIlMSU1E9K in SaCnW14s6emKoUO7PuvTLB:
		TWf82bYVv7PlFxL = QQSULIva4ljNO73mFcWw(u"ࠬ࡞࠱࠺ࠩડ")+GbXaDx7CQ39VzHpcNgPSZhAMRBJ2+OnvTrikzfEsY7qU8pgaRBtZy(u"࠭࠱࠹࠿ࠪઢ")+r64TFJvgaYLQHXyqIlMSU1E9K[-Sj1PYDmIpCUXO26(u"࠲࠵ఖ"):]+Y0Uhv2t8E67+PuoWQnmaDdJ70As825hxGyr
		TWf82bYVv7PlFxL = v0vrR8AL5UbCzsFQdlo(TWf82bYVv7PlFxL.encode(d0HDrq8Rtk16AlInw4TXb(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:FZBX5WcC3msIDv4hobLd8(u"࠴࠴గ")]
		if TWf82bYVv7PlFxL in WWnxl3b90UcQiuZzqdICNvOsaB7: return IPkQW7LojF3HO18V(u"ࡖࡵࡹࡪ౗")
	return WWbmNvI40sM9Khlp25Ae(u"ࡉࡥࡱࡹࡥౘ")
def yu1pYA2VRHzr876gPJdDw(wl4oO8z5SgGnF3HJEDjbUh,GasjKh87f3YMCeI,SQpdvB5OGRJwP,W5WfNIgQVnzB7cPOkZE=None):
	oo76muA1GlEh9s0ZHNT4yMXQzipP = wWMgaIdEk1s0uHGnSc8(GasjKh87f3YMCeI)
	LLfosSIikqUgKAG9hOVTZWrel6mHu = LCIFdjzi5kVmRwehouHQ.getSetting(Jbu2G0Qax8PYWpg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if SQpdvB5OGRJwP!=q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and wl4oO8z5SgGnF3HJEDjbUh==qQ4BC6vW5YOfo:
		if LLfosSIikqUgKAG9hOVTZWrel6mHu==Q2ZyGqCNYsftTc4MR7n(u"ࠪࡗ࡙ࡕࡐࠨદ"): return oo76muA1GlEh9s0ZHNT4yMXQzipP
		sF0NOtG4b1RY = LCIFdjzi5kVmRwehouHQ.getSetting(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if sF0NOtG4b1RY==d0HDrq8Rtk16AlInw4TXb(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(wl4oO8z5SgGnF3HJEDjbUh,SQpdvB5OGRJwP,W5WfNIgQVnzB7cPOkZE)
			return oo76muA1GlEh9s0ZHNT4yMXQzipP
	tOzXJZ2Khlp7Rvc8bMoHs1Cm3 = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠲ఘ")
	if LLfosSIikqUgKAG9hOVTZWrel6mHu==lh6URegmQNq8LWX0HaK5(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): tOzXJZ2Khlp7Rvc8bMoHs1Cm3 = gfKLySYJpj9
	try: Iof8U0xDKbVslWATpzR4OvBe9,lU7cFRC6jSwkVLTmIM = NLCg4kvQr2Yz8Bue3dhXwA(wl4oO8z5SgGnF3HJEDjbUh)
	except: return oo76muA1GlEh9s0ZHNT4yMXQzipP
	h4V7I9BFCrvA = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࡘࡷࡻࡥౙ")
	try: lU7cFRC6jSwkVLTmIM.execute(Q2ZyGqCNYsftTc4MR7n(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+SQpdvB5OGRJwP+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: h4V7I9BFCrvA = Jbu2G0Qax8PYWpg(u"ࡋࡧ࡬ࡴࡧౚ")
	if h4V7I9BFCrvA:
		if tOzXJZ2Khlp7Rvc8bMoHs1Cm3: lU7cFRC6jSwkVLTmIM.execute(gy9NA3CROZolfEt4vVzMr(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+SQpdvB5OGRJwP+QQSULIva4ljNO73mFcWw(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(CHhSItjbXy+tOzXJZ2Khlp7Rvc8bMoHs1Cm3)+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࠥࡁࠧમ"))
		Iof8U0xDKbVslWATpzR4OvBe9.commit()
		lU7cFRC6jSwkVLTmIM.execute(d0HDrq8Rtk16AlInw4TXb(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+SQpdvB5OGRJwP+RS7ZoyGAq1c(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(CHhSItjbXy)+LsG7EDcei1gMShH2aVOCo(u"ࠧࠡ࠽ࠪ઱"))
		Iof8U0xDKbVslWATpzR4OvBe9.commit()
		if W5WfNIgQVnzB7cPOkZE:
			K38mQ0viwSnkBFaGpTZj = (str(W5WfNIgQVnzB7cPOkZE),)
			lU7cFRC6jSwkVLTmIM.execute(Jbu2G0Qax8PYWpg(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+SQpdvB5OGRJwP+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),K38mQ0viwSnkBFaGpTZj)
			TiF5HCp4Zzf6ubclUONXI1AEL = lU7cFRC6jSwkVLTmIM.fetchall()
			if TiF5HCp4Zzf6ubclUONXI1AEL:
				try:
					FbewQr7IVXqN0ijhOtm2vAnauzZT = oLY8VsFGH7NCfujRnEa5r.decompress(TiF5HCp4Zzf6ubclUONXI1AEL[RS7ZoyGAq1c(u"࠳ఙ")][RS7ZoyGAq1c(u"࠳ఙ")])
					oo76muA1GlEh9s0ZHNT4yMXQzipP = KKHQRVq2XvWbsap7Tx.loads(FbewQr7IVXqN0ijhOtm2vAnauzZT)
				except: pass
		else:
			lU7cFRC6jSwkVLTmIM.execute(LsG7EDcei1gMShH2aVOCo(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+SQpdvB5OGRJwP+WWbmNvI40sM9Khlp25Ae(u"ࠫࠧࠦ࠻ࠨવ"))
			TiF5HCp4Zzf6ubclUONXI1AEL = lU7cFRC6jSwkVLTmIM.fetchall()
			if TiF5HCp4Zzf6ubclUONXI1AEL:
				oo76muA1GlEh9s0ZHNT4yMXQzipP,Hg7RhBN49rnmtvqVif = {},[]
				for HHB8nrlmz0cKdJ5ehVSxEM1T,ZZm1hsDV9ba in TiF5HCp4Zzf6ubclUONXI1AEL:
					zawksMKvuS = oLY8VsFGH7NCfujRnEa5r.decompress(ZZm1hsDV9ba)
					ZZm1hsDV9ba = KKHQRVq2XvWbsap7Tx.loads(zawksMKvuS)
					oo76muA1GlEh9s0ZHNT4yMXQzipP[HHB8nrlmz0cKdJ5ehVSxEM1T] = ZZm1hsDV9ba
					Hg7RhBN49rnmtvqVif.append(HHB8nrlmz0cKdJ5ehVSxEM1T)
				if Hg7RhBN49rnmtvqVif:
					oo76muA1GlEh9s0ZHNT4yMXQzipP[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = Hg7RhBN49rnmtvqVif
					if GasjKh87f3YMCeI==QQSULIva4ljNO73mFcWw(u"࠭࡬ࡪࡵࡷࠫષ"): oo76muA1GlEh9s0ZHNT4yMXQzipP = Hg7RhBN49rnmtvqVif
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	return oo76muA1GlEh9s0ZHNT4yMXQzipP
class OciaCEXkgKsWvLB(IMwE4bxTmG0t6pnRQXLkZ5J7Ndsjuq):
	def __init__(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.ENbfonq76dhWeGBFaV3ui = tvwmlYcDnVybgPHKU84GOFI0uAq(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		KETCehUc1vtORaPl03xDwV.E7XBoCmsAMdkjSL6qGbtghO8URYl = tvwmlYcDnVybgPHKU84GOFI0uAq(Y5npATFarf1H9wBjc87(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		KETCehUc1vtORaPl03xDwV.w2TChF9y8ZxV15esdQraH6 = tvwmlYcDnVybgPHKU84GOFI0uAq(RS7ZoyGAq1c(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if KETCehUc1vtORaPl03xDwV.ENbfonq76dhWeGBFaV3ui else Q2ZyGqCNYsftTc4MR7n(u"઼ࠫࠬ")
	def yygCt7ir4x6UF1OjZBsJAYDEcPu(KETCehUc1vtORaPl03xDwV,VV1mHn6RZE): KETCehUc1vtORaPl03xDwV.VV1mHn6RZE = VV1mHn6RZE
	def onPlayBackStopped(KETCehUc1vtORaPl03xDwV): KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(KETCehUc1vtORaPl03xDwV): KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = MOwK1lpyNfCgqksX3jhV(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(KETCehUc1vtORaPl03xDwV): KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(KETCehUc1vtORaPl03xDwV):
		KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = Jbu2G0Qax8PYWpg(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		ICZPq2exKMkcOnaB = RrCB5k9XV6hYNSlIKJ2.Thread(target=KETCehUc1vtORaPl03xDwV.i9ioIrUAWF7emKlxHnaNLB,args=())
		ICZPq2exKMkcOnaB.start()
	def onAVStarted(KETCehUc1vtORaPl03xDwV):
		if KETCehUc1vtORaPl03xDwV.E7XBoCmsAMdkjSL6qGbtghO8URYl: KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = lh6URegmQNq8LWX0HaK5(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def i9ioIrUAWF7emKlxHnaNLB(KETCehUc1vtORaPl03xDwV):
		from FJKmvLp8Tl import P8URX9agvseubL7xqFKthZ,AVqEo6OQfidWSLhvJjPke0RYtaM2gz,xmYBAMKujEkvWUpV
		xmYBAMKujEkvWUpV(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		M1CljGWvbr9TqxHY2D5 = d0HDrq8Rtk16AlInw4TXb(u"࠴చ")
		while not eval(NQ4hg16DPUxtOyo5iGb(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{onweDvmTOUj(u"࠭ࡸࡣ࡯ࡦࠫૅ"):WCdaXB2bfwyI0S3Fqet1LQoO5Rhv}) and KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs==NQ4hg16DPUxtOyo5iGb(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.sleep(q6yUEoKVDb0fXmc8vhrMk7N(u"࠶࠶࠰࠱ఛ"))
			M1CljGWvbr9TqxHY2D5 += KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠷జ")
			if M1CljGWvbr9TqxHY2D5>FZBX5WcC3msIDv4hobLd8(u"࠶࠱ఝ"): return
		if KETCehUc1vtORaPl03xDwV.ENbfonq76dhWeGBFaV3ui: KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = RS7ZoyGAq1c(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif KETCehUc1vtORaPl03xDwV.E7XBoCmsAMdkjSL6qGbtghO8URYl: KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = Q2ZyGqCNYsftTc4MR7n(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif KETCehUc1vtORaPl03xDwV.w2TChF9y8ZxV15esdQraH6:
			KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			NOKrGwXjsEfblVg26Tke5AS = RrCB5k9XV6hYNSlIKJ2.Thread(target=P8URX9agvseubL7xqFKthZ,args=(KETCehUc1vtORaPl03xDwV.VV1mHn6RZE,))
			NOKrGwXjsEfblVg26Tke5AS.start()
			dB1nACriqcOFU4kwJ = RrCB5k9XV6hYNSlIKJ2.Thread(target=AVqEo6OQfidWSLhvJjPke0RYtaM2gz,args=())
			dB1nACriqcOFU4kwJ.start()
		else: KETCehUc1vtORaPl03xDwV.XwKOH4gVcujSTY2Rs = IPkQW7LojF3HO18V(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def Pa92WVmnA8SE6vODQTid5UxJgt1B():
	EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠭ો"),Sj1PYDmIpCUXO26(u"࠭ࠧૌ")
	zMqo9HkDvx2RdGj5f6V1y8KQUFl = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(mtEXp14ijx(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		a2zKMUSTiGZ9AQyErPkwjxqe7Yv6b = open(IPkQW7LojF3HO18V(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࡵࡦࠬ૏")).read()
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: a2zKMUSTiGZ9AQyErPkwjxqe7Yv6b = a2zKMUSTiGZ9AQyErPkwjxqe7Yv6b.decode(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		EFqevdG64a9lMQ = SomeI8i56FaDMGPE.findall(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),a2zKMUSTiGZ9AQyErPkwjxqe7Yv6b,SomeI8i56FaDMGPE.IGNORECASE)
		if EFqevdG64a9lMQ: EgOFksnlSphyaC5LrjAu8 = EFqevdG64a9lMQ[B2vCEI9FAVP15R8eUbDJdySc(u"࠱ఞ")]
	except: pass
	try:
		import subprocess as RRLAOGFmUyjJ2cnVPgTMoYbehv
		g83awKWHVdSA6n = RRLAOGFmUyjJ2cnVPgTMoYbehv.Popen(lh6URegmQNq8LWX0HaK5(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=Q2ZyGqCNYsftTc4MR7n(u"࡚ࡲࡶࡧ౛"),stdin=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE,stdout=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE,stderr=RRLAOGFmUyjJ2cnVPgTMoYbehv.PIPE)
		e9owWK3uM1H8kNgfa6Xd4zyGlx = g83awKWHVdSA6n.stdout.read()
		if e9owWK3uM1H8kNgfa6Xd4zyGlx:
			if ZZxLpCcmqhyT6NuMWelkbSvr0H:
				e9owWK3uM1H8kNgfa6Xd4zyGlx = e9owWK3uM1H8kNgfa6Xd4zyGlx.decode(mtEXp14ijx(u"࠭ࡵࡵࡨ࠻ࠫ૓"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			PeO9q2kLhp0RvVscKgDFaA = SomeI8i56FaDMGPE.findall(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),e9owWK3uM1H8kNgfa6Xd4zyGlx,SomeI8i56FaDMGPE.IGNORECASE)
			if PeO9q2kLhp0RvVscKgDFaA: bg0ZziWGhyEa3uHp = min(PeO9q2kLhp0RvVscKgDFaA)
	except: pass
	return zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp
def vT7q0oj96p(wwbWlQeZCfk9tG,ZJkjKdgMaCT36OUiDSV=Q2ZyGqCNYsftTc4MR7n(u"ࡔࡳࡷࡨ౜")):
	mHUQhfGz9IgciFXaxAKEpLyRjdl = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡕࡴࡸࡩౝ")
	if ZJkjKdgMaCT36OUiDSV:
		jZUKfH49d6AaJo = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,MOwK1lpyNfCgqksX3jhV(u"ࠩ࡯࡭ࡸࡺࠧ૖"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),Q2ZyGqCNYsftTc4MR7n(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if jZUKfH49d6AaJo:
			SaCnW14s6emKoUO7PuvTLB,ZskyWSnr57,pdSLfEDxV7Mm,e5p81TrlydQAU4069nugBYtx = jZUKfH49d6AaJo
			mHUQhfGz9IgciFXaxAKEpLyRjdl = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡲࡩࡴࡶࠪ૙"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),RS7ZoyGAq1c(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if mHUQhfGz9IgciFXaxAKEpLyRjdl: zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp = mHUQhfGz9IgciFXaxAKEpLyRjdl
			else: zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp = Pa92WVmnA8SE6vODQTid5UxJgt1B()
			if (ZskyWSnr57,pdSLfEDxV7Mm,e5p81TrlydQAU4069nugBYtx)==(zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp): return LsG7EDcei1gMShH2aVOCo(u"ࠨ࡞ࡱࠫ૜").join(SaCnW14s6emKoUO7PuvTLB)
	if mHUQhfGz9IgciFXaxAKEpLyRjdl: zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp = Pa92WVmnA8SE6vODQTid5UxJgt1B()
	global h8TBJKDFgviRmnIx63,cc5KLRVluESzknba
	h8TBJKDFgviRmnIx63,cc5KLRVluESzknba,bdI5oXR0zcsJp8V3ktrijL = FZBX5WcC3msIDv4hobLd8(u"ࠩࠪ૝"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࠫ૞"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࠬ૟")
	wwbWlQeZCfk9tG = wwbWlQeZCfk9tG//Sj1PYDmIpCUXO26(u"࠴ట")
	RrCB5k9XV6hYNSlIKJ2.Thread(target=tGSpZqUPfHoMzDWTujr).start()
	RrCB5k9XV6hYNSlIKJ2.Thread(target=cdUvQVDFHywpgl1GY23hXCnu).start()
	for jUSuZAztxy34TB5CIP2 in range(lh6URegmQNq8LWX0HaK5(u"࠴࠴ఠ")):
		p1BoraOuWL.sleep(onweDvmTOUj(u"࠴࠳࠻డ"))
		if not bdI5oXR0zcsJp8V3ktrijL:
			try:
				CnFOvb3M5T6t8HmjfkUgu2AXwRKY = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(RS7ZoyGAq1c(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if CnFOvb3M5T6t8HmjfkUgu2AXwRKY.count(WWbmNvI40sM9Khlp25Ae(u"࠭࠺ࠨૡ"))==Q2ZyGqCNYsftTc4MR7n(u"࠻ణ") and CnFOvb3M5T6t8HmjfkUgu2AXwRKY.count(NQ4hg16DPUxtOyo5iGb(u"ࠧ࠱ࠩૢ"))<Rz34c0NP5BGo1WuTZxSfOKj(u"࠾ఢ"):
					CnFOvb3M5T6t8HmjfkUgu2AXwRKY = CnFOvb3M5T6t8HmjfkUgu2AXwRKY.lower().replace(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࠼ࠪૣ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠪ૤"))
					bdI5oXR0zcsJp8V3ktrijL = str(int(CnFOvb3M5T6t8HmjfkUgu2AXwRKY,d0HDrq8Rtk16AlInw4TXb(u"࠱࠷త")))
			except: pass
		if h8TBJKDFgviRmnIx63 and cc5KLRVluESzknba and bdI5oXR0zcsJp8V3ktrijL: break
	MMOADQfFKio8NU = [h8TBJKDFgviRmnIx63,cc5KLRVluESzknba,bdI5oXR0zcsJp8V3ktrijL,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࠫ૥"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࠬ૦"),onweDvmTOUj(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if EgOFksnlSphyaC5LrjAu8 or bg0ZziWGhyEa3uHp:
		from hashlib import md5 as v0vrR8AL5UbCzsFQdlo
		AZke1aP9QsB2uzWKFcVY = [(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠶ద"),EgOFksnlSphyaC5LrjAu8),(QQSULIva4ljNO73mFcWw(u"࠶థ"),bg0ZziWGhyEa3uHp)]
		for Y9orNmEJt8OWyM72vGafZleg5z4,V0UzjKdk3gOnmN4GYt5vix2e in AZke1aP9QsB2uzWKFcVY:
			V0UzjKdk3gOnmN4GYt5vix2e = V0UzjKdk3gOnmN4GYt5vix2e.strip(Sj1PYDmIpCUXO26(u"࠭࠰ࠨ૨"))
			if V0UzjKdk3gOnmN4GYt5vix2e:
				if ZZxLpCcmqhyT6NuMWelkbSvr0H: V0UzjKdk3gOnmN4GYt5vix2e = V0UzjKdk3gOnmN4GYt5vix2e.encode(gy9NA3CROZolfEt4vVzMr(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				V0UzjKdk3gOnmN4GYt5vix2e = str(int(v0vrR8AL5UbCzsFQdlo(V0UzjKdk3gOnmN4GYt5vix2e).hexdigest(),MOwK1lpyNfCgqksX3jhV(u"࠶࠺ధ")))
				I0xuYR4rKvd53Woq = [int(V0UzjKdk3gOnmN4GYt5vix2e[uxM5eTqvFVLPNQJ2dEX:uxM5eTqvFVLPNQJ2dEX+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠶࠻఩")]) for uxM5eTqvFVLPNQJ2dEX in range(len(V0UzjKdk3gOnmN4GYt5vix2e)) if uxM5eTqvFVLPNQJ2dEX%a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠶࠻఩")==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠴న")]
				MMOADQfFKio8NU[Y9orNmEJt8OWyM72vGafZleg5z4-Sj1PYDmIpCUXO26(u"࠷ప")] = str(sum(I0xuYR4rKvd53Woq))
	SaCnW14s6emKoUO7PuvTLB,ztDWf7MveRLH8YpJqO6xk = [],mtEXp14ijx(u"ࡈࡤࡰࡸ࡫౞")
	for LumgTPohzHl7xA860d in range(len(MMOADQfFKio8NU)):
		I0xuYR4rKvd53Woq = MMOADQfFKio8NU[LumgTPohzHl7xA860d]
		if not I0xuYR4rKvd53Woq: continue
		if ztDWf7MveRLH8YpJqO6xk and I0xuYR4rKvd53Woq==MMOADQfFKio8NU[-Q2ZyGqCNYsftTc4MR7n(u"࠱ఫ")]: continue
		ztDWf7MveRLH8YpJqO6xk = mtEXp14ijx(u"ࡗࡶࡺ࡫౟")
		I0xuYR4rKvd53Woq = wwbWlQeZCfk9tG*onweDvmTOUj(u"ࠨ࠲ࠪ૪")+I0xuYR4rKvd53Woq
		I0xuYR4rKvd53Woq = I0xuYR4rKvd53Woq[-wwbWlQeZCfk9tG:]
		ddSeXBAIGzHWwhLiU0PTlqtrvs3m,kkZU34rGNdt7K = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࠪ૫"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࠫ૬")
		kk2ym6JM7PfveIC9QYBTGnxhUSpROs = str(int(lh6URegmQNq8LWX0HaK5(u"ࠫ࠾࠭૭")*(wwbWlQeZCfk9tG+q6yUEoKVDb0fXmc8vhrMk7N(u"࠲బ")))-int(I0xuYR4rKvd53Woq))[-wwbWlQeZCfk9tG:]
		for juqtWiLzIUx4kNAPJ6nBX7OhCgr in list(range(RS7ZoyGAq1c(u"࠲భ"),wwbWlQeZCfk9tG,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠷మ"))):
			arc6XsFSPQBtA1yDvkVlMJ = kk2ym6JM7PfveIC9QYBTGnxhUSpROs[juqtWiLzIUx4kNAPJ6nBX7OhCgr:juqtWiLzIUx4kNAPJ6nBX7OhCgr+FZBX5WcC3msIDv4hobLd8(u"࠸య")]
			ddSeXBAIGzHWwhLiU0PTlqtrvs3m += arc6XsFSPQBtA1yDvkVlMJ+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬ࠳ࠧ૮")
			kkZU34rGNdt7K += str(sum(map(int,I0xuYR4rKvd53Woq[juqtWiLzIUx4kNAPJ6nBX7OhCgr:juqtWiLzIUx4kNAPJ6nBX7OhCgr+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠺ఱ")]))%q6yUEoKVDb0fXmc8vhrMk7N(u"࠶࠶ర"))
		r64TFJvgaYLQHXyqIlMSU1E9K = str(LumgTPohzHl7xA860d)+ddSeXBAIGzHWwhLiU0PTlqtrvs3m+kkZU34rGNdt7K
		SaCnW14s6emKoUO7PuvTLB.append(r64TFJvgaYLQHXyqIlMSU1E9K)
	F4QxJHhsMj(qQ4BC6vW5YOfo,lh6URegmQNq8LWX0HaK5(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp],jj0C6IlvPFh)
	F4QxJHhsMj(qQ4BC6vW5YOfo,Y5npATFarf1H9wBjc87(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),Y5npATFarf1H9wBjc87(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[SaCnW14s6emKoUO7PuvTLB,zMqo9HkDvx2RdGj5f6V1y8KQUFl,EgOFksnlSphyaC5LrjAu8,bg0ZziWGhyEa3uHp],IIbavC96MQ1nHq3Pjx)
	return aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡠࡳ࠭૳").join(SaCnW14s6emKoUO7PuvTLB)
def wFhHDd7gy6kesnTY4AVMLiU5aXGu8(DQs7pSx58I4n,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY,QOS2sIxvb8JZ70):
	mgDoj8ZAqe0uBLxP4Kzp = str(eGxC8vzYKkT9Zw2)[FZBX5WcC3msIDv4hobLd8(u"࠰ల"):wKdxVbTc0X9NSiespM8OvHGUhf(u"࠳࠷࠳ళ")].replace(lh6URegmQNq8LWX0HaK5(u"ࠫࡡࡴࠧ૴"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࡢ࡜࡯ࠩ૵")).replace(QQSULIva4ljNO73mFcWw(u"࠭࡜ࡳࠩ૶"),RS7ZoyGAq1c(u"ࠧ࡝࡞ࡵࠫ૷")).replace(eaF2N0jWLdvHIs8r(u"ࠨࠢࠣࠤࠥ࠭૸"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࠣࠫૹ")).replace(FZBX5WcC3msIDv4hobLd8(u"ࠪࠤࠥࠦࠧૺ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫࠥ࠭ૻ"))
	if len(str(eGxC8vzYKkT9Zw2))>lh6URegmQNq8LWX0HaK5(u"࠴࠸࠴ఴ"): mgDoj8ZAqe0uBLxP4Kzp = mgDoj8ZAqe0uBLxP4Kzp+WWbmNvI40sM9Khlp25Ae(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	ZZm1hsDV9ba = str(oo76muA1GlEh9s0ZHNT4yMXQzipP)[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠳వ"):KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠶࠺࠶శ")].replace(B2vCEI9FAVP15R8eUbDJdySc(u"࠭࡜࡯ࠩ૽"),mtEXp14ijx(u"ࠧ࡝࡞ࡱࠫ૾")).replace(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨ࡞ࡵࠫ૿"),LsG7EDcei1gMShH2aVOCo(u"ࠩ࡟ࡠࡷ࠭଀")).replace(lh6URegmQNq8LWX0HaK5(u"ࠪࠤࠥࠦࠠࠨଁ"),mtEXp14ijx(u"ࠫࠥ࠭ଂ")).replace(Q2ZyGqCNYsftTc4MR7n(u"ࠬࠦࠠࠡࠩଃ"),WWbmNvI40sM9Khlp25Ae(u"࠭ࠠࠨ଄"))
	if len(str(oo76muA1GlEh9s0ZHNT4yMXQzipP))>nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠷࠻࠰ష"): ZZm1hsDV9ba = ZZm1hsDV9ba+hxSBTdGpyNVbfu4tr9(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	xrFqGMab4uLKZcS(MOwK1lpyNfCgqksX3jhV(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),QQSULIva4ljNO73mFcWw(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+DQs7pSx58I4n+WWbmNvI40sM9Khlp25Ae(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+ucGVEfRSBY+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+QOS2sIxvb8JZ70+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(mgDoj8ZAqe0uBLxP4Kzp)+hxSBTdGpyNVbfu4tr9(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+ZZm1hsDV9ba+FZBX5WcC3msIDv4hobLd8(u"ࠨࠢࡠࠫ଍"))
	return
def tGSpZqUPfHoMzDWTujr():
	global h8TBJKDFgviRmnIx63
	import getmac82 as DklC5f4nwo6KNY7hR
	try:
		cR25PftiAZFKICTDpneQ3S = DklC5f4nwo6KNY7hR.get_mac_address()
		if cR25PftiAZFKICTDpneQ3S.count(RS7ZoyGAq1c(u"ࠩ࠽ࠫ଎"))==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠵హ") and cR25PftiAZFKICTDpneQ3S.count(d0HDrq8Rtk16AlInw4TXb(u"ࠪ࠴ࠬଏ"))<d0HDrq8Rtk16AlInw4TXb(u"࠿స"):
			cR25PftiAZFKICTDpneQ3S = cR25PftiAZFKICTDpneQ3S.lower().replace(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫ࠿࠭ଐ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࠭଑"))
			h8TBJKDFgviRmnIx63 = str(int(cR25PftiAZFKICTDpneQ3S,d0HDrq8Rtk16AlInw4TXb(u"࠲࠸఺")))
	except: pass
	return
def cdUvQVDFHywpgl1GY23hXCnu():
	global cc5KLRVluESzknba
	import getmac94 as v1WakUGNlx7FV2Rhm3
	try:
		ks40DaUt6eXfFjzBQmHZI7x2OdliKp = v1WakUGNlx7FV2Rhm3.get_mac_address()
		if ks40DaUt6eXfFjzBQmHZI7x2OdliKp.count(hxSBTdGpyNVbfu4tr9(u"࠭࠺ࠨ଒"))==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠸఼") and ks40DaUt6eXfFjzBQmHZI7x2OdliKp.count(RS7ZoyGAq1c(u"ࠧ࠱ࠩଓ"))<Y5npATFarf1H9wBjc87(u"࠻఻"):
			ks40DaUt6eXfFjzBQmHZI7x2OdliKp = ks40DaUt6eXfFjzBQmHZI7x2OdliKp.lower().replace(MOwK1lpyNfCgqksX3jhV(u"ࠨ࠼ࠪଔ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࠪକ"))
			cc5KLRVluESzknba = str(int(ks40DaUt6eXfFjzBQmHZI7x2OdliKp,gy9NA3CROZolfEt4vVzMr(u"࠵࠻ఽ")))
	except: pass
	return
def EEXl7ByjFiqO(QOS2sIxvb8JZ70,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP=Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠫଖ"),eGxC8vzYKkT9Zw2=onweDvmTOUj(u"ࠫࠬଗ"),ucGVEfRSBY=aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠭ଘ")):
	wFhHDd7gy6kesnTY4AVMLiU5aXGu8(gy9NA3CROZolfEt4vVzMr(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,ucGVEfRSBY,QOS2sIxvb8JZ70)
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: import urllib.request as ZkxL28zU6g4dKCvcqVB9wjh7SXTrp
	else: import urllib2 as ZkxL28zU6g4dKCvcqVB9wjh7SXTrp
	if not eGxC8vzYKkT9Zw2: eGxC8vzYKkT9Zw2 = {Jbu2G0Qax8PYWpg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࠩଛ")}
	if not oo76muA1GlEh9s0ZHNT4yMXQzipP: oo76muA1GlEh9s0ZHNT4yMXQzipP = {}
	if QOS2sIxvb8JZ70==IPkQW7LojF3HO18V(u"ࠩࡊࡉ࡙࠭ଜ"):
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+RS7ZoyGAq1c(u"ࠪࡃࠬଝ")+iOyTz1Jgbh25fW7NAdE(oo76muA1GlEh9s0ZHNT4yMXQzipP)
		oo76muA1GlEh9s0ZHNT4yMXQzipP = None
	elif QOS2sIxvb8JZ70==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࡕࡕࡓࡕࠩଞ") and FZBX5WcC3msIDv4hobLd8(u"ࠬࡰࡳࡰࡰࠪଟ") in str(eGxC8vzYKkT9Zw2):
		from json import dumps as A63OvTSBM5xduK4m8yorhjPYqw
		oo76muA1GlEh9s0ZHNT4yMXQzipP = A63OvTSBM5xduK4m8yorhjPYqw(oo76muA1GlEh9s0ZHNT4yMXQzipP)
		oo76muA1GlEh9s0ZHNT4yMXQzipP = str(oo76muA1GlEh9s0ZHNT4yMXQzipP).encode(Q2ZyGqCNYsftTc4MR7n(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif QOS2sIxvb8JZ70==MOwK1lpyNfCgqksX3jhV(u"ࠧࡑࡑࡖࡘࠬଡ"):
		oo76muA1GlEh9s0ZHNT4yMXQzipP = iOyTz1Jgbh25fW7NAdE(oo76muA1GlEh9s0ZHNT4yMXQzipP)
		oo76muA1GlEh9s0ZHNT4yMXQzipP = oo76muA1GlEh9s0ZHNT4yMXQzipP.encode(gy9NA3CROZolfEt4vVzMr(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		erKiyt7wAYTj6MSa5 = ZkxL28zU6g4dKCvcqVB9wjh7SXTrp.Request(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,headers=eGxC8vzYKkT9Zw2,data=oo76muA1GlEh9s0ZHNT4yMXQzipP)
		Plx6mbKYD71aCsfTdukWy2Q = ZkxL28zU6g4dKCvcqVB9wjh7SXTrp.urlopen(erKiyt7wAYTj6MSa5)
		mmhS2KFYI4eC6HWgk1trq = Plx6mbKYD71aCsfTdukWy2Q.read()
		E9eFvJPDwq,rreason = Y5npATFarf1H9wBjc87(u"࠷࠶࠰ా"),Y5npATFarf1H9wBjc87(u"ࠩࡒࡏࠬଣ")
	except:
		mmhS2KFYI4eC6HWgk1trq = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࠫତ")
		E9eFvJPDwq,rreason = -gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠷ి"),q6yUEoKVDb0fXmc8vhrMk7N(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	xrFqGMab4uLKZcS(eaF2N0jWLdvHIs8r(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(E9eFvJPDwq)+IPkQW7LojF3HO18V(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+rreason+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+ucGVEfRSBY+Q2ZyGqCNYsftTc4MR7n(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࠤࡢ࠭ଫ"))
	if mmhS2KFYI4eC6HWgk1trq and ZZxLpCcmqhyT6NuMWelkbSvr0H: mmhS2KFYI4eC6HWgk1trq = mmhS2KFYI4eC6HWgk1trq.decode(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return mmhS2KFYI4eC6HWgk1trq
def jWC2KvXiT7hetLkIxGlazq3(sstvU4JSFVfqo,sQHRWaKTJwMl5SCDgoE32YdBNvz8=OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬ࠭ଭ")):
	pVe6TaiylkvRnLuNz9FYHO = str(ttczT0JFy9xID3iLGMXoQm2hjB4.randrange(gy9NA3CROZolfEt4vVzMr(u"࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵ీ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾ు")))
	eGxC8vzYKkT9Zw2 = {Sj1PYDmIpCUXO26(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	d1cMuTiI6kQ8 = {	hxSBTdGpyNVbfu4tr9(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):vT7q0oj96p(gy9NA3CROZolfEt4vVzMr(u"࠶࠶ృ")).splitlines()[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴ౄ")][-S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴࠷ూ"):],
				NQ4hg16DPUxtOyo5iGb(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(Qf8xsJSwoKaUNc),
				aSf0iWG1kA7FsqjHbuC8NXB(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):Y0Uhv2t8E67,
				QQSULIva4ljNO73mFcWw(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):Y0Uhv2t8E67,
				Sj1PYDmIpCUXO26(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):sstvU4JSFVfqo,
				RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): Y0Uhv2t8E67,
				RS7ZoyGAq1c(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):Q2ZyGqCNYsftTc4MR7n(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				MOwK1lpyNfCgqksX3jhV(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{QQSULIva4ljNO73mFcWw(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):sstvU4JSFVfqo},
				MOwK1lpyNfCgqksX3jhV(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {q6yUEoKVDb0fXmc8vhrMk7N(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):sstvU4JSFVfqo},
				FZBX5WcC3msIDv4hobLd8(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):Y5npATFarf1H9wBjc87(u"ࡊࡦࡲࡳࡦౠ"),
				LsG7EDcei1gMShH2aVOCo(u"ࠢࡪࡲࠥଽ"): Jbu2G0Qax8PYWpg(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not sQHRWaKTJwMl5SCDgoE32YdBNvz8: UL9TmOlPS8hodyZ3cvEJt = [d1cMuTiI6kQ8]
	else:
		LLcbWJYwgRkM5Hz = d1cMuTiI6kQ8.copy()
		LLcbWJYwgRkM5Hz[OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = sQHRWaKTJwMl5SCDgoE32YdBNvz8
		LLcbWJYwgRkM5Hz[LsG7EDcei1gMShH2aVOCo(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):sQHRWaKTJwMl5SCDgoE32YdBNvz8}
		LLcbWJYwgRkM5Hz[hxSBTdGpyNVbfu4tr9(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {hxSBTdGpyNVbfu4tr9(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):sQHRWaKTJwMl5SCDgoE32YdBNvz8}
		UL9TmOlPS8hodyZ3cvEJt = [d1cMuTiI6kQ8,LLcbWJYwgRkM5Hz]
	oo76muA1GlEh9s0ZHNT4yMXQzipP = {aSf0iWG1kA7FsqjHbuC8NXB(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):onweDvmTOUj(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			Q2ZyGqCNYsftTc4MR7n(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):pVe6TaiylkvRnLuNz9FYHO,
			Sj1PYDmIpCUXO26(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): UL9TmOlPS8hodyZ3cvEJt
		}
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	mmhS2KFYI4eC6HWgk1trq = EEXl7ByjFiqO(eaF2N0jWLdvHIs8r(u"ࠬࡖࡏࡔࡖࠪ୉"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,oo76muA1GlEh9s0ZHNT4yMXQzipP,eGxC8vzYKkT9Zw2,Y5npATFarf1H9wBjc87(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return mmhS2KFYI4eC6HWgk1trq
def sX8pkIh2J4MCZHtcr0ERmlqWDL16O(GasjKh87f3YMCeI,FbewQr7IVXqN0ijhOtm2vAnauzZT):
	FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),lh6URegmQNq8LWX0HaK5(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡷࡶࡺ࡫୍ࠧ"),RS7ZoyGAq1c(u"ࠪࡘࡷࡻࡥࠨ୎"))
	FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(LsG7EDcei1gMShH2aVOCo(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	FbewQr7IVXqN0ijhOtm2vAnauzZT = FbewQr7IVXqN0ijhOtm2vAnauzZT.replace(onweDvmTOUj(u"࠭࡜࠰ࠩ୑"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧ࠰ࠩ୒"))
	try: zawksMKvuS = eval(FbewQr7IVXqN0ijhOtm2vAnauzZT)
	except: zawksMKvuS = wWMgaIdEk1s0uHGnSc8(GasjKh87f3YMCeI)
	return zawksMKvuS
def nkG2ayRoAj53eCPYVc():
	DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
	T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall(eaF2N0jWLdvHIs8r(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),x0LXdHBFwj7EtMfu,SomeI8i56FaDMGPE.DOTALL)
	if T9PyERLBA8wiVN30QjU14mW: x0LXdHBFwj7EtMfu = x0LXdHBFwj7EtMfu.split(T9PyERLBA8wiVN30QjU14mW[QQSULIva4ljNO73mFcWw(u"࠶ె")],Q2ZyGqCNYsftTc4MR7n(u"࠶౅"))[Q2ZyGqCNYsftTc4MR7n(u"࠶౅")]
	kkWLjQKlRyJbig2XuG = p1BoraOuWL.strftime(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),p1BoraOuWL.localtime(CHhSItjbXy))
	x0LXdHBFwj7EtMfu = x0LXdHBFwj7EtMfu+kkWLjQKlRyJbig2XuG
	hpnDbQ9u8ztEJ0fBaxv = DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk
	if Dh9MOxeTj6FW.path.exists(kRpnCV8cqdhDew2suUxPfaQTA5):
		P8wc1gZWR7KV = open(kRpnCV8cqdhDew2suUxPfaQTA5,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡶࡧ࠭୕")).read()
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: P8wc1gZWR7KV = P8wc1gZWR7KV.decode(NQ4hg16DPUxtOyo5iGb(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		P8wc1gZWR7KV = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(Sj1PYDmIpCUXO26(u"ࠬࡪࡩࡤࡶࠪୗ"),P8wc1gZWR7KV)
	else: P8wc1gZWR7KV = {}
	fwvNpHLU8jziVcdKuSmQatAWrF = {}
	for cHEJ3g41hdrFso8YKjZiGOQ in list(P8wc1gZWR7KV.keys()):
		if cHEJ3g41hdrFso8YKjZiGOQ!=DQs7pSx58I4n: fwvNpHLU8jziVcdKuSmQatAWrF[cHEJ3g41hdrFso8YKjZiGOQ] = P8wc1gZWR7KV[cHEJ3g41hdrFso8YKjZiGOQ]
		else:
			if x0LXdHBFwj7EtMfu and x0LXdHBFwj7EtMfu!=MOwK1lpyNfCgqksX3jhV(u"࠭࠮࠯ࠩ୘"):
				N01NWxQClmLiYvGoyH5FD4IzbT = P8wc1gZWR7KV[cHEJ3g41hdrFso8YKjZiGOQ]
				if hpnDbQ9u8ztEJ0fBaxv in N01NWxQClmLiYvGoyH5FD4IzbT:
					fMGn2cXPKw9SyUY = N01NWxQClmLiYvGoyH5FD4IzbT.index(hpnDbQ9u8ztEJ0fBaxv)
					del N01NWxQClmLiYvGoyH5FD4IzbT[fMGn2cXPKw9SyUY]
				lzqkARwVGHcsx8gN = [hpnDbQ9u8ztEJ0fBaxv]+N01NWxQClmLiYvGoyH5FD4IzbT
				lzqkARwVGHcsx8gN = lzqkARwVGHcsx8gN[:Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠵࠱ే")]
				fwvNpHLU8jziVcdKuSmQatAWrF[cHEJ3g41hdrFso8YKjZiGOQ] = lzqkARwVGHcsx8gN
			else: fwvNpHLU8jziVcdKuSmQatAWrF[cHEJ3g41hdrFso8YKjZiGOQ] = P8wc1gZWR7KV[cHEJ3g41hdrFso8YKjZiGOQ]
	if DQs7pSx58I4n not in list(fwvNpHLU8jziVcdKuSmQatAWrF.keys()): fwvNpHLU8jziVcdKuSmQatAWrF[DQs7pSx58I4n] = [hpnDbQ9u8ztEJ0fBaxv]
	fwvNpHLU8jziVcdKuSmQatAWrF = str(fwvNpHLU8jziVcdKuSmQatAWrF)
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: fwvNpHLU8jziVcdKuSmQatAWrF = fwvNpHLU8jziVcdKuSmQatAWrF.encode(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(kRpnCV8cqdhDew2suUxPfaQTA5,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡹࡥࠫ୚")).write(fwvNpHLU8jziVcdKuSmQatAWrF)
	return
def F4QxJHhsMj(wl4oO8z5SgGnF3HJEDjbUh,SQpdvB5OGRJwP,W5WfNIgQVnzB7cPOkZE,oo76muA1GlEh9s0ZHNT4yMXQzipP,l5N0ornX1f2LDdOVWU,lItYzmNCw2Ag1h8WKe=lh6URegmQNq8LWX0HaK5(u"ࡋࡧ࡬ࡴࡧౡ")):
	LLfosSIikqUgKAG9hOVTZWrel6mHu = LCIFdjzi5kVmRwehouHQ.getSetting(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if LLfosSIikqUgKAG9hOVTZWrel6mHu==B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and l5N0ornX1f2LDdOVWU>gfKLySYJpj9: l5N0ornX1f2LDdOVWU = gfKLySYJpj9
	if lItYzmNCw2Ag1h8WKe:
		mlKGZXF5ybUTOrQNMua,FYC61QobeDJLZwVWxB5PnuUk3NO = [],[]
		for jUSuZAztxy34TB5CIP2 in range(len(W5WfNIgQVnzB7cPOkZE)):
			FbewQr7IVXqN0ijhOtm2vAnauzZT = KKHQRVq2XvWbsap7Tx.dumps(oo76muA1GlEh9s0ZHNT4yMXQzipP[jUSuZAztxy34TB5CIP2])
			g50KUSOLZrqG9vAiImHhwCc = oLY8VsFGH7NCfujRnEa5r.compress(FbewQr7IVXqN0ijhOtm2vAnauzZT)
			mlKGZXF5ybUTOrQNMua.append((W5WfNIgQVnzB7cPOkZE[jUSuZAztxy34TB5CIP2],))
			FYC61QobeDJLZwVWxB5PnuUk3NO.append((l5N0ornX1f2LDdOVWU+CHhSItjbXy,str(W5WfNIgQVnzB7cPOkZE[jUSuZAztxy34TB5CIP2]),g50KUSOLZrqG9vAiImHhwCc))
	else:
		FbewQr7IVXqN0ijhOtm2vAnauzZT = KKHQRVq2XvWbsap7Tx.dumps(oo76muA1GlEh9s0ZHNT4yMXQzipP)
		ptuM3debrgNJ4 = oLY8VsFGH7NCfujRnEa5r.compress(FbewQr7IVXqN0ijhOtm2vAnauzZT)
	try: Iof8U0xDKbVslWATpzR4OvBe9,lU7cFRC6jSwkVLTmIM = NLCg4kvQr2Yz8Bue3dhXwA(wl4oO8z5SgGnF3HJEDjbUh)
	except: return
	while d0HDrq8Rtk16AlInw4TXb(u"࡚ࡲࡶࡧౢ"):
		try:
			lU7cFRC6jSwkVLTmIM.execute(Sj1PYDmIpCUXO26(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: p1BoraOuWL.sleep(LsG7EDcei1gMShH2aVOCo(u"࠱࠰࠸ై"))
	lU7cFRC6jSwkVLTmIM.execute(hxSBTdGpyNVbfu4tr9(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+SQpdvB5OGRJwP+wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if lItYzmNCw2Ag1h8WKe:
		lU7cFRC6jSwkVLTmIM.executemany(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+SQpdvB5OGRJwP+LsG7EDcei1gMShH2aVOCo(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),mlKGZXF5ybUTOrQNMua)
		lU7cFRC6jSwkVLTmIM.executemany(mtEXp14ijx(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+SQpdvB5OGRJwP+Sj1PYDmIpCUXO26(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),FYC61QobeDJLZwVWxB5PnuUk3NO)
	else:
		if l5N0ornX1f2LDdOVWU:
			K38mQ0viwSnkBFaGpTZj = (str(W5WfNIgQVnzB7cPOkZE),)
			lU7cFRC6jSwkVLTmIM.execute(QQSULIva4ljNO73mFcWw(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+SQpdvB5OGRJwP+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),K38mQ0viwSnkBFaGpTZj)
			K38mQ0viwSnkBFaGpTZj = (l5N0ornX1f2LDdOVWU+CHhSItjbXy,str(W5WfNIgQVnzB7cPOkZE),ptuM3debrgNJ4)
			lU7cFRC6jSwkVLTmIM.execute(d0HDrq8Rtk16AlInw4TXb(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+SQpdvB5OGRJwP+NQ4hg16DPUxtOyo5iGb(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),K38mQ0viwSnkBFaGpTZj)
		else:
			K38mQ0viwSnkBFaGpTZj = (ptuM3debrgNJ4,str(W5WfNIgQVnzB7cPOkZE))
			lU7cFRC6jSwkVLTmIM.execute(QQSULIva4ljNO73mFcWw(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+SQpdvB5OGRJwP+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),K38mQ0viwSnkBFaGpTZj)
	Iof8U0xDKbVslWATpzR4OvBe9.commit()
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	return
def iOyTz1Jgbh25fW7NAdE(oo76muA1GlEh9s0ZHNT4yMXQzipP):
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: import urllib.parse as yKpbiTSznZW
	else: import urllib as yKpbiTSznZW
	HXl4hkOpK7YW8cJ5VZdnuPz = yKpbiTSznZW.urlencode(oo76muA1GlEh9s0ZHNT4yMXQzipP)
	return HXl4hkOpK7YW8cJ5VZdnuPz
XwKOH4gVcujSTY2Rs = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࠫ୪")
def kFygcp2jqSUCiNRnur71xMZI96(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,rr39GFcXaRNtjDAIVquO=OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࠬ୫"),ldnozWtegYayOjGq249SU3X6xuJfZk=Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬ࠭୬")):
	UkRMDOPhBcle2sAHT891SYW = rr39GFcXaRNtjDAIVquO not in [a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡍ࠴ࡗࠪ୭"),hxSBTdGpyNVbfu4tr9(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global XwKOH4gVcujSTY2Rs
	if not ldnozWtegYayOjGq249SU3X6xuJfZk: ldnozWtegYayOjGq249SU3X6xuJfZk = eaF2N0jWLdvHIs8r(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	XwKOH4gVcujSTY2Rs,r5vyHOGqnjbiouQNR,iTZJ7smKIA5EvUORp = gy9NA3CROZolfEt4vVzMr(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),FZBX5WcC3msIDv4hobLd8(u"ࠪࠫୱ"),hxSBTdGpyNVbfu4tr9(u"ࠫࠬ୲")
	if len(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)==mtEXp14ijx(u"࠵౉"):
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX,JOpzyu62qNtvT1cn3P,iTZJ7smKIA5EvUORp = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv
		if JOpzyu62qNtvT1cn3P: r5vyHOGqnjbiouQNR = lh6URegmQNq8LWX0HaK5(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+JOpzyu62qNtvT1cn3P+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࠠ࡞ࠩ୴")
	else: xTFHrZ1nGWa9fdqsSA5y4htgJNmX,JOpzyu62qNtvT1cn3P,iTZJ7smKIA5EvUORp = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,QQSULIva4ljNO73mFcWw(u"ࠧࠨ୵"),gy9NA3CROZolfEt4vVzMr(u"ࠨࠩ୶")
	xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࠨ࠶࠵࠭୷"),NQ4hg16DPUxtOyo5iGb(u"ࠪࠤࠬ୸"))
	MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
	if rr39GFcXaRNtjDAIVquO not in [RS7ZoyGAq1c(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if rr39GFcXaRNtjDAIVquO!=wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(hxSBTdGpyNVbfu4tr9(u"ࠧࠡࠩ୼"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠧ࠵࠴ࠬ୽"))
		xrFqGMab4uLKZcS(LsG7EDcei1gMShH2aVOCo(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+hxSBTdGpyNVbfu4tr9(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+RS7ZoyGAq1c(u"ࠫࠥࡣࠧ஀")+r5vyHOGqnjbiouQNR)
		if MMQ7S0sAgzHIumcqWUx==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and rr39GFcXaRNtjDAIVquO not in [QQSULIva4ljNO73mFcWw(u"࠭ࡉࡑࡖ࡙ࠫஂ"),NQ4hg16DPUxtOyo5iGb(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from FJKmvLp8Tl import I1IwMGlyuaB9XTe,wKxBD1f6FgH54qRvTYP0c2eJbS3X,NCXj2ri3Unm6TFWIgwh
			r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = I1IwMGlyuaB9XTe(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
			PmtdDvIykT7qxfB = len(aFyREdMQk7Ys95rX6uJieDGLS2)
			if PmtdDvIykT7qxfB>q6yUEoKVDb0fXmc8vhrMk7N(u"࠴ొ"):
				I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(PmtdDvIykT7qxfB)+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"้้ࠩࠣ็ࠩࠨஅ"), r79xJG6jXHD)
				if I7mfbGiWNFcBVJOn==-LsG7EDcei1gMShH2aVOCo(u"࠵ో"):
					NCXj2ri3Unm6TFWIgwh(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࠬஇ"))
					return XwKOH4gVcujSTY2Rs
			else: I7mfbGiWNFcBVJOn = Sj1PYDmIpCUXO26(u"࠵ౌ")
			xTFHrZ1nGWa9fdqsSA5y4htgJNmX = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
			if r79xJG6jXHD[FZBX5WcC3msIDv4hobLd8(u"࠶్")]!=hxSBTdGpyNVbfu4tr9(u"ࠬ࠳࠱ࠨஈ"):
				xrFqGMab4uLKZcS(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+gy9NA3CROZolfEt4vVzMr(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+r79xJG6jXHD[I7mfbGiWNFcBVJOn]+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+gy9NA3CROZolfEt4vVzMr(u"ࠩࠣࡡࠬ஌"))
		if Q2ZyGqCNYsftTc4MR7n(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX: xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+mtEXp14ijx(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif d0HDrq8Rtk16AlInw4TXb(u"ࠬ࡮ࡴࡵࡲࠪஏ") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX.lower() and MOwK1lpyNfCgqksX3jhV(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX and Jbu2G0Qax8PYWpg(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX:
			if hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX and KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX.lower():
				if q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࢀࠬஔ") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX: xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+MOwK1lpyNfCgqksX3jhV(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX.lower() and rr39GFcXaRNtjDAIVquO not in [wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡊࡒࡗ࡚ࠬ஘"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡏ࠶࡙ࠬங")]:
				if gy9NA3CROZolfEt4vVzMr(u"ࠩࡿࠫச") not in xTFHrZ1nGWa9fdqsSA5y4htgJNmX: xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+d0HDrq8Rtk16AlInw4TXb(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX+WWbmNvI40sM9Khlp25Ae(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	xrFqGMab4uLKZcS(d0HDrq8Rtk16AlInw4TXb(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+NQ4hg16DPUxtOyo5iGb(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+QQSULIva4ljNO73mFcWw(u"ࠧࠡ࡟ࠪட"))
	TwHVsKRx2gz9ctyjAUfYCmO3 = N7zpvB3VIPrwcSDEC.ListItem()
	ldnozWtegYayOjGq249SU3X6xuJfZk,onHbevfWF7j3EIA,wnpJZgr3dKeoyuQUXsvM60B2T9N8,R6ROsBCycLjFMtYDk04A,HhYcglIx1BQ7R,YHAzVdDlb0Ea2CMyO39,YYodOrv6EGWm0p8ls3UFKwaZtSufX,z8gRkejGf9s3WLNwunliYITEXyaqM,AzZe4BbaCFKNYw = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
	if rr39GFcXaRNtjDAIVquO not in [S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),gy9NA3CROZolfEt4vVzMr(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if BhTAck1bPFYGuUqRW: e48SAKiHG37o0gk5ycpz9n = onweDvmTOUj(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: e48SAKiHG37o0gk5ycpz9n = lh6URegmQNq8LWX0HaK5(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		TwHVsKRx2gz9ctyjAUfYCmO3.setProperty(e48SAKiHG37o0gk5ycpz9n, S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭த"))
		TwHVsKRx2gz9ctyjAUfYCmO3.setMimeType(WWbmNvI40sM9Khlp25Ae(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if Qf8xsJSwoKaUNc<Y5npATFarf1H9wBjc87(u"࠲࠱౎"): TwHVsKRx2gz9ctyjAUfYCmO3.setInfo(FZBX5WcC3msIDv4hobLd8(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{FZBX5WcC3msIDv4hobLd8(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):gy9NA3CROZolfEt4vVzMr(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			FF1vtEbdJp0wokVh = TwHVsKRx2gz9ctyjAUfYCmO3.getVideoInfoTag()
			FF1vtEbdJp0wokVh.setMediaType(d0HDrq8Rtk16AlInw4TXb(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		TwHVsKRx2gz9ctyjAUfYCmO3.setArt({mtEXp14ijx(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):HhYcglIx1BQ7R,NQ4hg16DPUxtOyo5iGb(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):HhYcglIx1BQ7R,B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):HhYcglIx1BQ7R,Jbu2G0Qax8PYWpg(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):HhYcglIx1BQ7R,Q2ZyGqCNYsftTc4MR7n(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):HhYcglIx1BQ7R,onweDvmTOUj(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):HhYcglIx1BQ7R,d0HDrq8Rtk16AlInw4TXb(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):HhYcglIx1BQ7R,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫ࡮ࡩ࡯࡯ࠩற"):HhYcglIx1BQ7R})
		if MMQ7S0sAgzHIumcqWUx in [eaF2N0jWLdvHIs8r(u"ࠬ࠴࡭ࡱࡦࠪல"),onweDvmTOUj(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: TwHVsKRx2gz9ctyjAUfYCmO3.setContentLookup(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡔࡳࡷࡨౣ"))
		else: TwHVsKRx2gz9ctyjAUfYCmO3.setContentLookup(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡇࡣ࡯ࡷࡪ౤"))
		from G4zaNTEvFt import cPzAIOrxUw5XlveWpHSEhR
		if RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡳࡶࡰࡴࠬழ") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX:
			cPzAIOrxUw5XlveWpHSEhR(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡈࡤࡰࡸ࡫౥"))
		elif MMQ7S0sAgzHIumcqWUx==wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࠱ࡱࡵࡪࠧஶ") or hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in xTFHrZ1nGWa9fdqsSA5y4htgJNmX:
			cPzAIOrxUw5XlveWpHSEhR(LsG7EDcei1gMShH2aVOCo(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),lh6URegmQNq8LWX0HaK5(u"ࡉࡥࡱࡹࡥ౦"))
			TwHVsKRx2gz9ctyjAUfYCmO3.setProperty(e48SAKiHG37o0gk5ycpz9n,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			TwHVsKRx2gz9ctyjAUfYCmO3.setProperty(LsG7EDcei1gMShH2aVOCo(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),RS7ZoyGAq1c(u"ࠧ࡮ࡲࡧࠫ஻"))
		if JOpzyu62qNtvT1cn3P:
			TwHVsKRx2gz9ctyjAUfYCmO3.setSubtitles([JOpzyu62qNtvT1cn3P])
	if ldnozWtegYayOjGq249SU3X6xuJfZk==wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and rr39GFcXaRNtjDAIVquO==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		XwKOH4gVcujSTY2Rs = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		rr39GFcXaRNtjDAIVquO = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif ldnozWtegYayOjGq249SU3X6xuJfZk==q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࡼࡩࡥࡧࡲࠫீ") and z8gRkejGf9s3WLNwunliYITEXyaqM.startswith(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭࠶ࠨு")):
		XwKOH4gVcujSTY2Rs = NQ4hg16DPUxtOyo5iGb(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		rr39GFcXaRNtjDAIVquO = rr39GFcXaRNtjDAIVquO+FZBX5WcC3msIDv4hobLd8(u"ࠨࡡࡇࡐࠬ௃")
	if XwKOH4gVcujSTY2Rs!=gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): nkG2ayRoAj53eCPYVc()
	SsfCjQHtzp9Md5JknPoLUhFZX = OciaCEXkgKsWvLB()
	if SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs: return mtEXp14ijx(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	SsfCjQHtzp9Md5JknPoLUhFZX.yygCt7ir4x6UF1OjZBsJAYDEcPu(rr39GFcXaRNtjDAIVquO)
	if ldnozWtegYayOjGq249SU3X6xuJfZk==OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not z8gRkejGf9s3WLNwunliYITEXyaqM.startswith(gy9NA3CROZolfEt4vVzMr(u"ࠬ࠼ࠧே")):
		TwHVsKRx2gz9ctyjAUfYCmO3.setPath(xTFHrZ1nGWa9fdqsSA5y4htgJNmX)
		xrFqGMab4uLKZcS(QQSULIva4ljNO73mFcWw(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+OnvTrikzfEsY7qU8pgaRBtZy(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠢࡠࠫொ"))
		YRyCdPm9JnNZ5vf.setResolvedUrl(yR8fePHkvJnx3K0FQVs,Rz34c0NP5BGo1WuTZxSfOKj(u"ࡘࡷࡻࡥ౧"),TwHVsKRx2gz9ctyjAUfYCmO3)
	elif ldnozWtegYayOjGq249SU3X6xuJfZk==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		xrFqGMab4uLKZcS(Jbu2G0Qax8PYWpg(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+eaF2N0jWLdvHIs8r(u"ࠬࠦ࡝ࠨ௎"))
		SsfCjQHtzp9Md5JknPoLUhFZX.play(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,TwHVsKRx2gz9ctyjAUfYCmO3)
	sycSign827ZrEldIB = gy9NA3CROZolfEt4vVzMr(u"ࡋࡧ࡬ࡴࡧ౨")
	if XwKOH4gVcujSTY2Rs==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from TVMrfO0tCI import hVHiX8JNWe4SYp9PZBmqK53rl
		sycSign827ZrEldIB = hVHiX8JNWe4SYp9PZBmqK53rl(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,MMQ7S0sAgzHIumcqWUx,rr39GFcXaRNtjDAIVquO)
		if sycSign827ZrEldIB: nkG2ayRoAj53eCPYVc()
	else:
		Egi7k41QIqDK6NouH,XwKOH4gVcujSTY2Rs,W0hnrBlw5MXZjQPHiKoaNeYVDT,UDZ0qGxKOWEgSoCkH4eLsf5jTJav,DTw3t58aOLNbgHlxk6 = NQ4hg16DPUxtOyo5iGb(u"࠱౏"),gy9NA3CROZolfEt4vVzMr(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡌࡡ࡭ࡵࡨ౩"),Sj1PYDmIpCUXO26(u"࠴࠴࠵࠶౑"),q6yUEoKVDb0fXmc8vhrMk7N(u"࠵࠳࠴࠵࠶౐")
		if UkRMDOPhBcle2sAHT891SYW: from FJKmvLp8Tl import NCXj2ri3Unm6TFWIgwh
		while Egi7k41QIqDK6NouH<DTw3t58aOLNbgHlxk6:
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.sleep(UDZ0qGxKOWEgSoCkH4eLsf5jTJav)
			Egi7k41QIqDK6NouH += UDZ0qGxKOWEgSoCkH4eLsf5jTJav
			if SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs==LsG7EDcei1gMShH2aVOCo(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not W0hnrBlw5MXZjQPHiKoaNeYVDT:
				if UkRMDOPhBcle2sAHT891SYW: NCXj2ri3Unm6TFWIgwh(aSf0iWG1kA7FsqjHbuC8NXB(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),MOwK1lpyNfCgqksX3jhV(u"ࠪࠫ௓"),p1BoraOuWL=B2vCEI9FAVP15R8eUbDJdySc(u"࠻࠺࠶౒"))
				xrFqGMab4uLKZcS(hxSBTdGpyNVbfu4tr9(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Jbu2G0Qax8PYWpg(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+WWbmNvI40sM9Khlp25Ae(u"࠭ࠠ࡞ࠩ௖")+r5vyHOGqnjbiouQNR)
				W0hnrBlw5MXZjQPHiKoaNeYVDT = hxSBTdGpyNVbfu4tr9(u"ࡔࡳࡷࡨ౪")
			elif SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs in [RS7ZoyGAq1c(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),hxSBTdGpyNVbfu4tr9(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				xrFqGMab4uLKZcS(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+QQSULIva4ljNO73mFcWw(u"ࠫࠥࡣࠧ௛")+r5vyHOGqnjbiouQNR)
				break
			elif SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				xrFqGMab4uLKZcS(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+QQSULIva4ljNO73mFcWw(u"ࠨࠢࡠࠫ௟")+r5vyHOGqnjbiouQNR)
				if UkRMDOPhBcle2sAHT891SYW: NCXj2ri3Unm6TFWIgwh(Jbu2G0Qax8PYWpg(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),LsG7EDcei1gMShH2aVOCo(u"ࠪࠫ௡"),p1BoraOuWL=B2vCEI9FAVP15R8eUbDJdySc(u"࠶࠸࠵࠱౓"))
				break
			elif SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				xrFqGMab4uLKZcS(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if UkRMDOPhBcle2sAHT891SYW: NCXj2ri3Unm6TFWIgwh(d0HDrq8Rtk16AlInw4TXb(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࠪ௧"),p1BoraOuWL=onweDvmTOUj(u"࠷࠲࠶࠲౔"))
			xrFqGMab4uLKZcS(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+LsG7EDcei1gMShH2aVOCo(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+xTFHrZ1nGWa9fdqsSA5y4htgJNmX+IPkQW7LojF3HO18V(u"ࠬࠦ࡝ࠨ௪")+r5vyHOGqnjbiouQNR)
			XwKOH4gVcujSTY2Rs = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if XwKOH4gVcujSTY2Rs in [MOwK1lpyNfCgqksX3jhV(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs in [IPkQW7LojF3HO18V(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),eaF2N0jWLdvHIs8r(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or sycSign827ZrEldIB:
		if SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): rr39GFcXaRNtjDAIVquO = rr39GFcXaRNtjDAIVquO+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡤ࡚ࡓࠨ௰")
		Plx6mbKYD71aCsfTdukWy2Q = jWC2KvXiT7hetLkIxGlazq3(rr39GFcXaRNtjDAIVquO)
	else: exec(gy9NA3CROZolfEt4vVzMr(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return SsfCjQHtzp9Md5JknPoLUhFZX.XwKOH4gVcujSTY2Rs
def jjCeNxAVJ9RpqzDI3Yg6dy(xTFHrZ1nGWa9fdqsSA5y4htgJNmX):
	MMQ7S0sAgzHIumcqWUx = SomeI8i56FaDMGPE.findall(Jbu2G0Qax8PYWpg(u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭௲"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX.lower(),SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if MMQ7S0sAgzHIumcqWUx: MMQ7S0sAgzHIumcqWUx = MMQ7S0sAgzHIumcqWUx[lh6URegmQNq8LWX0HaK5(u"࠰ౕ")][lh6URegmQNq8LWX0HaK5(u"࠰ౕ")]
	else: MMQ7S0sAgzHIumcqWUx = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࠨ௳")
	return MMQ7S0sAgzHIumcqWUx
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ALFATIMI'
ToYWiIbruzUaNKRPZLG16cAj = '_FTM_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
tiSvkFBCPojVfcgQD80GKIN = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
XT4brcDt1MuiaUw = ['3030','628']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==60: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==61: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==62: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==63: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==64: rr60PDpqbMehZsYVuHmiAtN = WMxNbOL5tcQ2739pd6GRn4Phyo(text)
	elif mode==69: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'ما يتم مشاهدته الان',aaeRjxiYcqOI6Sf8,64,'','','recent_viewed_vids')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الاكثر مشاهدة',aaeRjxiYcqOI6Sf8,64,'','','most_viewed_vids')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'اضيفت مؤخرا',aaeRjxiYcqOI6Sf8,64,'','','recently_added_vids')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'فيديو عشوائي',aaeRjxiYcqOI6Sf8,64,'','','random_vids')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'افلام ومسلسلات',aaeRjxiYcqOI6Sf8,61,'','','-1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'البرامج الدينية',aaeRjxiYcqOI6Sf8,61,'','','-2')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'English Videos',aaeRjxiYcqOI6Sf8,61,'','','-3')
	return ''
def KKlnDcetq8Rrp3GY0(url,g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B):
	LqRjzmSOEUhB76o = ''
	if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B not in ['-1','-2','-3']: LqRjzmSOEUhB76o = '?cat='+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B
	vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/menu_level.php'+LqRjzmSOEUhB76o
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','ALFATIMI-TITLES-1st')
	items = SomeI8i56FaDMGPE.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	j6dcUR7qInze1BGxZt3X,y10vlPSzDYb2BA6HJhi = False,False
	for ZcAK0askvzIWr4R,title,count in items:
		title = dCFP41Kxv9j8EHM(title)
		title = title.strip(' ')
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
		LqRjzmSOEUhB76o = SomeI8i56FaDMGPE.findall('cat=(.*?)&',ZcAK0askvzIWr4R,SomeI8i56FaDMGPE.DOTALL)[0]
		if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B==LqRjzmSOEUhB76o: j6dcUR7qInze1BGxZt3X = True
		elif j6dcUR7qInze1BGxZt3X 	or (g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='-1' and LqRjzmSOEUhB76o in tiSvkFBCPojVfcgQD80GKIN)  						or (g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='-2' and LqRjzmSOEUhB76o not in XT4brcDt1MuiaUw and LqRjzmSOEUhB76o not in tiSvkFBCPojVfcgQD80GKIN)  						or (g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='-3' and LqRjzmSOEUhB76o in XT4brcDt1MuiaUw):
							if count=='1': UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,63)
							else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,61,'','',LqRjzmSOEUhB76o)
							y10vlPSzDYb2BA6HJhi = True
	if not y10vlPSzDYb2BA6HJhi: ooLCwrlF3n0vBjpA(url)
	return
def ooLCwrlF3n0vBjpA(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','',True,'ALFATIMI-EPISODES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)id="footer',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	ZcAK0askvzIWr4R = ''
	for pjMZ802XQCSxYVk,title,ZcAK0askvzIWr4R in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,63,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('(.*?)div',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM=pDTlIgyewF1XV69R8kd[0]
	L0Uwx52bTBM=SomeI8i56FaDMGPE.findall('pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	items=SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.split('?')[0]
	for ZcAK0askvzIWr4R,i0anImls2WOQ79MyZFf in items:
		ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E + ZcAK0askvzIWr4R
		title = dCFP41Kxv9j8EHM(i0anImls2WOQ79MyZFf)
		title = 'صفحة ' + title
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,62)
	return ZcAK0askvzIWr4R
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	if 'videos.php' in url: url = ooLCwrlF3n0vBjpA(url)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','',True,'ALFATIMI-PLAY-1st')
	items = SomeI8i56FaDMGPE.findall('playlistfile:"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	kFygcp2jqSUCiNRnur71xMZI96(url,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def WMxNbOL5tcQ2739pd6GRn4Phyo(g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B):
	P8AGL4xSd9rWD1Vz = { 'mode' : g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = iOyTz1Jgbh25fW7NAdE(P8AGL4xSd9rWD1Vz)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
		title = title.strip(' ')
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,63,pjMZ802XQCSxYVk)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + '/search_result.php?query=' + u9DhgpinLBfmjG3NtMalq7Y
	ooLCwrlF3n0vBjpA(url)
	return
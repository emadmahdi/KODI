# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMACLUB'
ToYWiIbruzUaNKRPZLG16cAj = '_CCB_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['عروض المصارعه','للكبار فقط +18','الرئيسية','افلام للكبار فقط','DMCA']
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==820: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==821: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==822: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==823: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,text)
	elif mode==824: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FULL_FILTER___'+text)
	elif mode==825: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'DEFINED_FILTER___'+text)
	elif mode==829: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMACLUB-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع',aaeRjxiYcqOI6Sf8,829,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/sliderhome.php'
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',ZcAK0askvzIWr4R,821,'','featured','_REMEMBERRESULTS_')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Tabs"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('get="(.*?)".*?<span>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for data,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/getposts?type=one&data='+data
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,821,'','highest')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('navigation-menu(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if '/' not in ZcAK0askvzIWr4R: continue
			if title in C1pRb6K8Qs: continue
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,821)
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	L0Uwx52bTBM,items = '',[]
	if type=='featured':
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		P8AGL4xSd9rWD1Vz = 'get'
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,P8AGL4xSd9rWD1Vz,headers,'','','CIMACLUB-TITLES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		items = SomeI8i56FaDMGPE.findall('"image":"(.*?)".*?"title":"(.*?)".*?"url":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		VrYb6FeavCBJlZOim91x7U,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g = zip(*items)
		items = zip(ZZHhmdtY1g,VrYb6FeavCBJlZOim91x7U,R3Rinqky4ouBgYEtZh)
	elif type=='highest':
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUB-TITLES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUB-TITLES-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('media-block(.*?)footer-menu',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not L0Uwx52bTBM: L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	if not items: items = SomeI8i56FaDMGPE.findall('content-box.*?href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	uWakC4XPIiZqNGlMS3FJnO = []
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R.replace('\/','/')
		pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('\/','/')
		ZcAK0askvzIWr4R = c8Fvb4IfHW9XkG1mLK5Z(ZcAK0askvzIWr4R)
		title = c8Fvb4IfHW9XkG1mLK5Z(title)
		if '/episode/' in ZcAK0askvzIWr4R:
			wYVpAWjH3EiLDzyaO = SomeI8i56FaDMGPE.findall('(.*?) (موسم|الموسم)',title,SomeI8i56FaDMGPE.DOTALL)
			if wYVpAWjH3EiLDzyaO: title = wYVpAWjH3EiLDzyaO[0][0]
			else:
				iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (حلقة|الحلقة)',title,SomeI8i56FaDMGPE.DOTALL)
				if iHPhR4wCQ1oINaL: title = iHPhR4wCQ1oINaL[0][0]
			if title in uWakC4XPIiZqNGlMS3FJnO: continue
			uWakC4XPIiZqNGlMS3FJnO.append(title)
			title = '_MOD_'+title.strip(' – ')
		if '/episodes' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,821,pjMZ802XQCSxYVk)
		elif '/seasons' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,821,pjMZ802XQCSxYVk)
		elif '/serie/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,823,pjMZ802XQCSxYVk)
		elif '/anime-serie/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,823,pjMZ802XQCSxYVk)
		elif '/season/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,823,pjMZ802XQCSxYVk)
		elif '/episode/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,823,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,822,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if title: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,821)
	return
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,HHhXlVCJAa4gisn9mxZt16P):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUB-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('poster-image.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0] if pjMZ802XQCSxYVk else ''
	items = []
	if not HHhXlVCJAa4gisn9mxZt16P:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Seasons"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('<li.*?data-season="(.*?)" data-S="(.*?)" data-B="(.*?)".*?title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				for HHhXlVCJAa4gisn9mxZt16P,bBnpA46fsCcxtjJZuYFK1P3v8yDV,xC1PWbcS4gK2DhTy3a7nG5iIAFdme,title in items:
					title = title.replace('  ',' ')
					ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/ajaxCenter?_action=GetSeasonEp&_season='+HHhXlVCJAa4gisn9mxZt16P+'&_S='+bBnpA46fsCcxtjJZuYFK1P3v8yDV+'&_B='+xC1PWbcS4gK2DhTy3a7nG5iIAFdme
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,823,pjMZ802XQCSxYVk,'',HHhXlVCJAa4gisn9mxZt16P)
	if len(items)<2:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Episodes selected"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: Cmkb7B9FsfhHNWdZTlwux,L0Uwx52bTBM = '',pDTlIgyewF1XV69R8kd[0]
		else: Cmkb7B9FsfhHNWdZTlwux,L0Uwx52bTBM = 'موسم '+HHhXlVCJAa4gisn9mxZt16P,BsJ71WIxDtdFKveTcRPrqM4Cwb
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?<em>(.*?)</em>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,iHPhR4wCQ1oINaL in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			title = Cmkb7B9FsfhHNWdZTlwux+' حلقة '+iHPhR4wCQ1oINaL.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,822,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	url = url.replace('/episode/','/watch/').replace('/anime/','/watch/').replace('/movie/','/watch/')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUB-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TbFRyPoVlrQAw7n3h8BukmfHNq,ZqrDM2pIkCR89FP3On = [],[]
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('player-wraper.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
		FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__embed')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('servers-tabs(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-embedd="(.*?)".*?<em>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&img=',1)[0]
			title = title.strip(' ')
			if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
				ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+title+'__watch')
	items = SomeI8i56FaDMGPE.findall('download-block.*?href="(.*?)".*?<h3>(.*?)</h3>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
			ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
			title = title.replace('<span>',' ').replace('</span>','').replace('<i>','').replace('</i>',' ')
			title = title.strip(' ')
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+title+'__download')
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search: search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search?s='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	url = url.split('/smartemadfilter?')[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','CIMACLUB-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('advanced-search(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('select-menu">.*?">(.*?)<.*?data-tax="(.*?)"(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		wwpNZP87O2YjJIFT0rH95Al43RCWzi,prjZqOoMUE,UUTVrGP7Y31a = zip(*v3mSnRD6XCqOjksGlP2MuxpKUt4)
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = zip(wwpNZP87O2YjJIFT0rH95Al43RCWzi,prjZqOoMUE,UUTVrGP7Y31a)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('cat="(.*?)".*?bold">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def wV2LqDT14MiOYa(url):
	if '/smartemadfilter?' in url:
		url,LE0VmiWeMGS4dHJ3 = url.split('/smartemadfilter?')
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/getposts?'+LE0VmiWeMGS4dHJ3
	else: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8
	return ZcAK0askvzIWr4R
xupe2PJyhdBkTXR9iVN3tZQ5azU1E4 = ['category','release-year','genre','quality']
y8nICQWej1Z6qTv234Y9koOcbg7 = ['category','release-year','genre']
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='DEFINED_FILTER':
		if y8nICQWej1Z6qTv234Y9koOcbg7[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[0]
		for zz5ZOaoyATpS893tvdXE in range(len(y8nICQWej1Z6qTv234Y9koOcbg7[0:-1])):
			if y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FULL_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO: efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if not efhkATx13dQgs4LyFMGpZYRaJ08iUO: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,821,'','filter')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,821,'','filter')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,mjcA3DUe9IJV4bk,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		name = name.replace('كل ','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='DEFINED_FILTER':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					KKlnDcetq8Rrp3GY0(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,'filter')
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'DEFINED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,821,'','filter')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',vfIB6ib8q1hFX5GweRrVPNTjY2E,825,'','',ecMSxgw2QqpvI)
		elif type=='FULL_FILTER':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,824,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if not EPwT39HrS1tU6Ng8YBGpJADixzLV5C: continue
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' :'#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' :'+name
			if type=='FULL_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,824,'','',L6iYCRsI1U4ytrW)
			elif type=='DEFINED_FILTER' and y8nICQWej1Z6qTv234Y9koOcbg7[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
				vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,821,'','filter')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,825,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in xupe2PJyhdBkTXR9iVN3tZQ5azU1E4:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
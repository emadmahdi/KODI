# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'YOUTUBE'
ToYWiIbruzUaNKRPZLG16cAj = '_YUT_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
YVfRirjA4kQylT = 0
def GI13aCFr0qimdOT(mode,url,text,type,SSGEc76fBan2,name,NmX0ZP715phHsSiCzvxR3IB):
	if	 mode==140: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==141: rr60PDpqbMehZsYVuHmiAtN = k0tQAgw5uZoc67xKIX3dyp(url,name,NmX0ZP715phHsSiCzvxR3IB)
	elif mode==143: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,type)
	elif mode==144: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2,text)
	elif mode==145: rr60PDpqbMehZsYVuHmiAtN = jjhXvULEoJkxIzae3(url,SSGEc76fBan2)
	elif mode==147: rr60PDpqbMehZsYVuHmiAtN = nXQuijKDxewFdbyHpt90qA()
	elif mode==148: rr60PDpqbMehZsYVuHmiAtN = eEwufNiGmHq()
	elif mode==149: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	if 0:
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'قائمة',aaeRjxiYcqOI6Sf8+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'شخص',aaeRjxiYcqOI6Sf8+'/user/TCNofficial',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'موقع',aaeRjxiYcqOI6Sf8+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'حساب',aaeRjxiYcqOI6Sf8+'/@TheSocialCTV',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'العاب',aaeRjxiYcqOI6Sf8+'/gaming',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'افلام',aaeRjxiYcqOI6Sf8+'/feed/storefront',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مختارات',aaeRjxiYcqOI6Sf8+'/feed/guide_builder',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'قصيرة',aaeRjxiYcqOI6Sf8+'/shorts',144,'','','_REMEMBERRESULTS_')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'تصفح',aaeRjxiYcqOI6Sf8+'/youtubei/v1/guide?key=',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'رئيسية',aaeRjxiYcqOI6Sf8+'',144)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'رائج',aaeRjxiYcqOI6Sf8+'/feed/trending?bp=',144)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الرئيسية',aaeRjxiYcqOI6Sf8+'',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الرائجة',aaeRjxiYcqOI6Sf8+'/feed/trending',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'التصفح',aaeRjxiYcqOI6Sf8+'/youtubei/v1/guide?key=',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'القصيرة',aaeRjxiYcqOI6Sf8+'/shorts',144,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مختارات يوتيوب',aaeRjxiYcqOI6Sf8+'/feed/guide_builder',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مختارات البرنامج','',290)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: قنوات عربية','',147)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: قنوات أجنبية','',148)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: افلام عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=فيلم',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: افلام اجنبية',aaeRjxiYcqOI6Sf8+'/results?search_query=movie',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسرحيات عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=مسرحية',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات عربية',aaeRjxiYcqOI6Sf8+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات اجنبية',aaeRjxiYcqOI6Sf8+'/results?search_query=series&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: مسلسلات كارتون',aaeRjxiYcqOI6Sf8+'/results?search_query=كارتون&sp=EgIQAw==',144)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث: خطبة المرجعية',aaeRjxiYcqOI6Sf8+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def k0tQAgw5uZoc67xKIX3dyp(url,name,NmX0ZP715phHsSiCzvxR3IB):
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'CHNL:  '+name,url,144,NmX0ZP715phHsSiCzvxR3IB)
	return
def nXQuijKDxewFdbyHpt90qA():
	KKlnDcetq8Rrp3GY0(aaeRjxiYcqOI6Sf8+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def eEwufNiGmHq():
	KKlnDcetq8Rrp3GY0(aaeRjxiYcqOI6Sf8+'/results?search_query=tv&sp=EgJAAQ==')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,type):
	url = url.split('&',1)[0]
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK([url],HmvY29bj4dNgF7wZqr1lzkeQxiEasu,type,url)
	return
def B7APWMgdhc1LD4Vi(FDI8OfiZBHqXK3lYpdEg,url,fMGn2cXPKw9SyUY):
	level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = fMGn2cXPKw9SyUY.split('::')
	oXyje2LgxZld0Mwas,H8OB3ntljWobfLJUax5Zsv = [],[]
	if '/youtubei/v1/browse' in url: oXyje2LgxZld0Mwas.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: oXyje2LgxZld0Mwas.append("yccc['onResponseReceivedCommands']")
	if level=='1': oXyje2LgxZld0Mwas.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	oXyje2LgxZld0Mwas.append("yccc['entries']")
	oXyje2LgxZld0Mwas.append("yccc['items'][3]['guideSectionRenderer']['items']")
	DSQBfczGHwLtZaeg0xyCI4,KUcHAZLked8CV,qFaLJNTR1g6OBMHV3pK580Wuv = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(FDI8OfiZBHqXK3lYpdEg,'',oXyje2LgxZld0Mwas)
	if level=='1' and DSQBfczGHwLtZaeg0xyCI4:
		if len(KUcHAZLked8CV)>1 and 'search_query' not in url:
			for YyjV8EL0Gum6Jz2Wr4S in range(len(KUcHAZLked8CV)):
				pMoilv2IDUhNFxV5u9 = str(YyjV8EL0Gum6Jz2Wr4S)
				oXyje2LgxZld0Mwas = []
				oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['reloadContinuationItemsCommand']['continuationItems']")
				oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['command']")
				oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]")
				sycSign827ZrEldIB,MMeFJKLQG4HdIwObZ1l9,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(KUcHAZLked8CV,'',oXyje2LgxZld0Mwas)
				if sycSign827ZrEldIB: H8OB3ntljWobfLJUax5Zsv.append([MMeFJKLQG4HdIwObZ1l9,url,'2::'+pMoilv2IDUhNFxV5u9+'::0::0'])
			oXyje2LgxZld0Mwas.append("yccc['continuationEndpoint']")
			sycSign827ZrEldIB,MMeFJKLQG4HdIwObZ1l9,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(FDI8OfiZBHqXK3lYpdEg,'',oXyje2LgxZld0Mwas)
			if sycSign827ZrEldIB and H8OB3ntljWobfLJUax5Zsv and 'continuationCommand' in list(MMeFJKLQG4HdIwObZ1l9.keys()):
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/my_main_page_shorts_link'
				H8OB3ntljWobfLJUax5Zsv.append([MMeFJKLQG4HdIwObZ1l9,ZcAK0askvzIWr4R,'1::0::0::0'])
	return KUcHAZLked8CV,DSQBfczGHwLtZaeg0xyCI4,H8OB3ntljWobfLJUax5Zsv,qFaLJNTR1g6OBMHV3pK580Wuv
def gyYsj1Rn7MXOZmCSvG6k(FDI8OfiZBHqXK3lYpdEg,KUcHAZLked8CV,url,fMGn2cXPKw9SyUY):
	level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = fMGn2cXPKw9SyUY.split('::')
	oXyje2LgxZld0Mwas,AenuDhXBN2RLo6FM = [],[]
	oXyje2LgxZld0Mwas.append("yddd[0]['itemSectionRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['reloadContinuationItemsCommand']['continuationItems']")
	oXyje2LgxZld0Mwas.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: oXyje2LgxZld0Mwas.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: oXyje2LgxZld0Mwas.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yddd["+pMoilv2IDUhNFxV5u9+"]")
	X7XKvpdEriunht8k,Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,EEuf06XNt2aYmdzThx = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(KUcHAZLked8CV,'',oXyje2LgxZld0Mwas)
	if level=='2' and X7XKvpdEriunht8k:
		if len(Q0Nzm9ehwOHflgyE8LGDbIu43BSMj)>1:
			for YyjV8EL0Gum6Jz2Wr4S in range(len(Q0Nzm9ehwOHflgyE8LGDbIu43BSMj)):
				PPSeanH6bGrtwfdgBm = str(YyjV8EL0Gum6Jz2Wr4S)
				oXyje2LgxZld0Mwas = []
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['richSectionRenderer']['content']")
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]")
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['richItemRenderer']['content']")
				oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]")
				sycSign827ZrEldIB,MMeFJKLQG4HdIwObZ1l9,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,'',oXyje2LgxZld0Mwas)
				if sycSign827ZrEldIB: AenuDhXBN2RLo6FM.append([MMeFJKLQG4HdIwObZ1l9,url,'3::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::0'])
			oXyje2LgxZld0Mwas.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			oXyje2LgxZld0Mwas.append("yddd[1]")
			sycSign827ZrEldIB,MMeFJKLQG4HdIwObZ1l9,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(KUcHAZLked8CV,'',oXyje2LgxZld0Mwas)
			if sycSign827ZrEldIB and AenuDhXBN2RLo6FM and 'continuationItemRenderer' in list(MMeFJKLQG4HdIwObZ1l9.keys()):
				AenuDhXBN2RLo6FM.append([MMeFJKLQG4HdIwObZ1l9,url,'3::0::0::0'])
	return Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,X7XKvpdEriunht8k,AenuDhXBN2RLo6FM,EEuf06XNt2aYmdzThx
def U3UpJoF6297mEw4dzMhgbk(FDI8OfiZBHqXK3lYpdEg,Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,url,fMGn2cXPKw9SyUY):
	level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = fMGn2cXPKw9SyUY.split('::')
	oXyje2LgxZld0Mwas,tafYd7ugxhen5EmsyW9PSQM4kTX = [],[]
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['reelShelfRenderer']['items']")
	oXyje2LgxZld0Mwas.append("yeee["+PPSeanH6bGrtwfdgBm+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	oXyje2LgxZld0Mwas.append("yeee")
	Nt04zbx5AmM3,zKCnW5xdAmh0E,l8SXonVRir0AcBmZfqwNGMF9L = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,'',oXyje2LgxZld0Mwas)
	if level=='3' and Nt04zbx5AmM3:
		if len(zKCnW5xdAmh0E)>0:
			for YyjV8EL0Gum6Jz2Wr4S in range(len(zKCnW5xdAmh0E)):
				ULA5FVjJO6MTeGWi3 = str(YyjV8EL0Gum6Jz2Wr4S)
				oXyje2LgxZld0Mwas = []
				oXyje2LgxZld0Mwas.append("yfff["+ULA5FVjJO6MTeGWi3+"]['richItemRenderer']['content']")
				oXyje2LgxZld0Mwas.append("yfff["+ULA5FVjJO6MTeGWi3+"]['gameCardRenderer']['game']")
				oXyje2LgxZld0Mwas.append("yfff["+ULA5FVjJO6MTeGWi3+"]['itemSectionRenderer']['contents'][0]")
				oXyje2LgxZld0Mwas.append("yfff["+ULA5FVjJO6MTeGWi3+"]")
				sycSign827ZrEldIB,MMeFJKLQG4HdIwObZ1l9,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(zKCnW5xdAmh0E,'',oXyje2LgxZld0Mwas)
				if sycSign827ZrEldIB: tafYd7ugxhen5EmsyW9PSQM4kTX.append([MMeFJKLQG4HdIwObZ1l9,url,'4::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3])
	return zKCnW5xdAmh0E,Nt04zbx5AmM3,tafYd7ugxhen5EmsyW9PSQM4kTX,l8SXonVRir0AcBmZfqwNGMF9L
def Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,fSHI5xZBcpsGMhb93V6uz):
	FDI8OfiZBHqXK3lYpdEg,v7vlUSFEWZs8Bd5 = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	KUcHAZLked8CV,v7vlUSFEWZs8Bd5 = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,v7vlUSFEWZs8Bd5 = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	zKCnW5xdAmh0E,v7vlUSFEWZs8Bd5 = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk = ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5
	count = len(fSHI5xZBcpsGMhb93V6uz)
	for jUSuZAztxy34TB5CIP2 in range(count):
		try:
			HWcGFfnKESdOeY3LDz4sq = eval(fSHI5xZBcpsGMhb93V6uz[jUSuZAztxy34TB5CIP2])
			return True,HWcGFfnKESdOeY3LDz4sq,jUSuZAztxy34TB5CIP2+1
		except: pass
	return False,'',0
def KKlnDcetq8Rrp3GY0(url,fMGn2cXPKw9SyUY='',data=''):
	H8OB3ntljWobfLJUax5Zsv,AenuDhXBN2RLo6FM,tafYd7ugxhen5EmsyW9PSQM4kTX = [],[],[]
	if '::' not in fMGn2cXPKw9SyUY: fMGn2cXPKw9SyUY = '1::0::0::0'
	level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = fMGn2cXPKw9SyUY.split('::')
	if level=='4': level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = '1',pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3
	data = data.replace('_REMEMBERRESULTS_','')
	BsJ71WIxDtdFKveTcRPrqM4Cwb,FDI8OfiZBHqXK3lYpdEg,ZZm1hsDV9ba = LyYjEfISpORQXlaD7PuoAzc24H0d9(url,data)
	fMGn2cXPKw9SyUY = level+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
	if level in ['1','2','3']:
		KUcHAZLked8CV,DSQBfczGHwLtZaeg0xyCI4,H8OB3ntljWobfLJUax5Zsv,qFaLJNTR1g6OBMHV3pK580Wuv = B7APWMgdhc1LD4Vi(FDI8OfiZBHqXK3lYpdEg,url,fMGn2cXPKw9SyUY)
		if not DSQBfczGHwLtZaeg0xyCI4: return
		Ev4juIUTHtDqQhnX = len(H8OB3ntljWobfLJUax5Zsv)
		if Ev4juIUTHtDqQhnX<2:
			if level=='1': level = '2'
			H8OB3ntljWobfLJUax5Zsv = []
	fMGn2cXPKw9SyUY = level+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
	if level in ['2','3']:
		Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,X7XKvpdEriunht8k,AenuDhXBN2RLo6FM,EEuf06XNt2aYmdzThx = gyYsj1Rn7MXOZmCSvG6k(FDI8OfiZBHqXK3lYpdEg,KUcHAZLked8CV,url,fMGn2cXPKw9SyUY)
		if not X7XKvpdEriunht8k: return
		rEwbAFfU6TozaiV39Hj5lL = len(AenuDhXBN2RLo6FM)
		if rEwbAFfU6TozaiV39Hj5lL<2:
			if level=='2': level = '3'
			AenuDhXBN2RLo6FM = []
	fMGn2cXPKw9SyUY = level+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
	if level in ['3']:
		zKCnW5xdAmh0E,Nt04zbx5AmM3,tafYd7ugxhen5EmsyW9PSQM4kTX,l8SXonVRir0AcBmZfqwNGMF9L = U3UpJoF6297mEw4dzMhgbk(FDI8OfiZBHqXK3lYpdEg,Q0Nzm9ehwOHflgyE8LGDbIu43BSMj,url,fMGn2cXPKw9SyUY)
		if not Nt04zbx5AmM3: return
		lKNoz6wZCgLJbO = len(tafYd7ugxhen5EmsyW9PSQM4kTX)
	for MMeFJKLQG4HdIwObZ1l9,url,fMGn2cXPKw9SyUY in H8OB3ntljWobfLJUax5Zsv+AenuDhXBN2RLo6FM+tafYd7ugxhen5EmsyW9PSQM4kTX:
		SSP1lDkxZjzm2t = S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9,url,fMGn2cXPKw9SyUY)
	return
def S9wrU6jxteTgdo0BfhVbNa(MMeFJKLQG4HdIwObZ1l9,url='',fMGn2cXPKw9SyUY=''):
	if '::' in fMGn2cXPKw9SyUY: level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = fMGn2cXPKw9SyUY.split('::')
	else: level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = '1','0','0','0'
	sycSign827ZrEldIB,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt,V12Ny0lDZ9gMKYP7n4I8xpHfro = pv1anL23bl6uFwJmcN(MMeFJKLQG4HdIwObZ1l9)
	juYczFWVTx49yiP6DdUms2BSQkpROJ = '/videos?' in ZcAK0askvzIWr4R or '/streams?' in ZcAK0askvzIWr4R or '/playlists?' in ZcAK0askvzIWr4R
	S1jH5qx8zv3tl = '/channels?' in ZcAK0askvzIWr4R or '/shorts?' in ZcAK0askvzIWr4R
	if juYczFWVTx49yiP6DdUms2BSQkpROJ or S1jH5qx8zv3tl: ZcAK0askvzIWr4R = url
	juYczFWVTx49yiP6DdUms2BSQkpROJ = 'watch?v=' not in ZcAK0askvzIWr4R and '/playlist?list=' not in ZcAK0askvzIWr4R
	S1jH5qx8zv3tl = '/gaming' not in ZcAK0askvzIWr4R  and '/feed/storefront' not in ZcAK0askvzIWr4R
	if fMGn2cXPKw9SyUY[0:5]=='3::0::' and juYczFWVTx49yiP6DdUms2BSQkpROJ and S1jH5qx8zv3tl: ZcAK0askvzIWr4R = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ZcAK0askvzIWr4R:
		level,pMoilv2IDUhNFxV5u9,PPSeanH6bGrtwfdgBm,ULA5FVjJO6MTeGWi3 = '1','0','0','0'
		fMGn2cXPKw9SyUY = ''
	ZZm1hsDV9ba = ''
	if '/youtubei/v1/browse' in ZcAK0askvzIWr4R or '/youtubei/v1/search' in ZcAK0askvzIWr4R or '/my_main_page_shorts_link' in url:
		data = LCIFdjzi5kVmRwehouHQ.getSetting('av.youtube.data')
		if data.count(':::')==4:
			i1vYajMAKUOEl0HQ,key,iCQpJnV5mBPakXTgW8ufE2hF,DFVGW9wgzKuLRJOUQX1k28yZrb3M,ii1SRMJ8xhIz5yl0Xptb9a = data.split(':::')
			ZZm1hsDV9ba = i1vYajMAKUOEl0HQ+':::'+key+':::'+iCQpJnV5mBPakXTgW8ufE2hF+':::'+DFVGW9wgzKuLRJOUQX1k28yZrb3M+':::'+V12Ny0lDZ9gMKYP7n4I8xpHfro
			if '/my_main_page_shorts_link' in url and not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = url
			else: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?key='+key
	if not title:
		global YVfRirjA4kQylT
		YVfRirjA4kQylT += 1
		title = 'فيديوهات '+str(YVfRirjA4kQylT)
		fMGn2cXPKw9SyUY = '3'+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
	if not sycSign827ZrEldIB: return False
	elif 'searchPyvRenderer' in str(MMeFJKLQG4HdIwObZ1l9): return False
	elif '/about' in ZcAK0askvzIWr4R: return False
	elif '/community' in ZcAK0askvzIWr4R: return False
	elif 'continuationItemRenderer' in list(MMeFJKLQG4HdIwObZ1l9.keys()) or 'continuationCommand' in list(MMeFJKLQG4HdIwObZ1l9.keys()):
		if int(level)>1: level = str(int(level)-1)
		fMGn2cXPKw9SyUY = level+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: '+'صفحة أخرى',ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY,ZZm1hsDV9ba)
	elif '/search' in ZcAK0askvzIWr4R:
		title = ':: '+title
		fMGn2cXPKw9SyUY = '3'+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
		url = url.replace('/search','')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,145,'',fMGn2cXPKw9SyUY,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ZcAK0askvzIWr4R:
		fMGn2cXPKw9SyUY = '3'+'::'+pMoilv2IDUhNFxV5u9+'::'+PPSeanH6bGrtwfdgBm+'::'+ULA5FVjJO6MTeGWi3
		title = ':: '+title
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY,ZZm1hsDV9ba)
	elif '/browse' in ZcAK0askvzIWr4R and url==aaeRjxiYcqOI6Sf8:
		title = ':: '+title
		fMGn2cXPKw9SyUY = '2::0::0::0'
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY,ZZm1hsDV9ba)
	elif not ZcAK0askvzIWr4R and 'horizontalMovieListRenderer' in str(MMeFJKLQG4HdIwObZ1l9):
		title = ':: '+title
		fMGn2cXPKw9SyUY = '3::0::0::0'
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY)
	elif 'messageRenderer' in str(MMeFJKLQG4HdIwObZ1l9):
		UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+title,'',9999)
	elif wnNUzQihpqAXKyR8jelWfPCOuxI7M:
		UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+wnNUzQihpqAXKyR8jelWfPCOuxI7M+title,ZcAK0askvzIWr4R,143,pjMZ802XQCSxYVk)
	elif '/playlist?list=' in ZcAK0askvzIWr4R:
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'LIST'+count+':  '+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY)
	elif '/shorts/' in ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&list=',1)[0]
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,143,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s)
	elif '/watch?v=' in ZcAK0askvzIWr4R:
		if '&list=' in ZcAK0askvzIWr4R and count:
			xxE95jdKlbA = ZcAK0askvzIWr4R.split('&list=',1)[1]
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/playlist?list='+xxE95jdKlbA
			fMGn2cXPKw9SyUY = '3::0::0::0'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'LIST'+count+':  '+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY)
		else:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&list=',1)[0]
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,143,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s)
	elif '/channel/' in ZcAK0askvzIWr4R or '/c/' in ZcAK0askvzIWr4R or ('/@' in ZcAK0askvzIWr4R and ZcAK0askvzIWr4R.count('/')==3):
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'CHNL'+count+':  '+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY)
	elif '/user/' in ZcAK0askvzIWr4R:
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'USER'+count+':  '+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY)
	else:
		if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = url
		title = ':: '+title
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,144,pjMZ802XQCSxYVk,fMGn2cXPKw9SyUY,ZZm1hsDV9ba)
	return True
def pv1anL23bl6uFwJmcN(MMeFJKLQG4HdIwObZ1l9):
	sycSign827ZrEldIB,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt,ii1SRMJ8xhIz5yl0Xptb9a = False,'','','','','','','',''
	if not isinstance(MMeFJKLQG4HdIwObZ1l9,dict): return sycSign827ZrEldIB,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt,ii1SRMJ8xhIz5yl0Xptb9a
	for chJis9v4U5fW0ZVQY1t in list(MMeFJKLQG4HdIwObZ1l9.keys()):
		WPiTF7Bufrdk = MMeFJKLQG4HdIwObZ1l9[chJis9v4U5fW0ZVQY1t]
		if isinstance(WPiTF7Bufrdk,dict): break
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['header']['richListHeaderRenderer']['title']")
	oXyje2LgxZld0Mwas.append("yrender['headline']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['unplayableText']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['formattedTitle']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['title']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['title']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("yrender['text']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['text']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("yrender['title']")
	oXyje2LgxZld0Mwas.append("item['title']")
	oXyje2LgxZld0Mwas.append("item['reelWatchEndpoint']['videoId']")
	sycSign827ZrEldIB,title,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	oXyje2LgxZld0Mwas.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	oXyje2LgxZld0Mwas.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	oXyje2LgxZld0Mwas.append("item['commandMetadata']['webCommandMetadata']['url']")
	sycSign827ZrEldIB,ZcAK0askvzIWr4R,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['thumbnail']['thumbnails'][0]['url']")
	oXyje2LgxZld0Mwas.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	oXyje2LgxZld0Mwas.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	sycSign827ZrEldIB,pjMZ802XQCSxYVk,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['videoCount']")
	oXyje2LgxZld0Mwas.append("yrender['videoCountText']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	sycSign827ZrEldIB,count,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	oXyje2LgxZld0Mwas.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['lengthText']['simpleText']")
	oXyje2LgxZld0Mwas.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	oXyje2LgxZld0Mwas.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	sycSign827ZrEldIB,DD1IVWFZbr7TlzYto5s,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	oXyje2LgxZld0Mwas = []
	oXyje2LgxZld0Mwas.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	oXyje2LgxZld0Mwas.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	sycSign827ZrEldIB,ii1SRMJ8xhIz5yl0Xptb9a,Ydt0oPpx4QAj = Sr2bZgKAwQe7f9quWcM0xyHGFEX4V8(MMeFJKLQG4HdIwObZ1l9,WPiTF7Bufrdk,oXyje2LgxZld0Mwas)
	if 'LIVE' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M = '','LIVE:  '
	if 'مباشر' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M = '','LIVE:  '
	if 'badges' in list(WPiTF7Bufrdk.keys()):
		PrGydBOaRV = str(WPiTF7Bufrdk['badges'])
		if 'Free with Ads' in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$:  '
		if 'LIVE' in PrGydBOaRV: wnNUzQihpqAXKyR8jelWfPCOuxI7M = 'LIVE:  '
		if 'Buy' in PrGydBOaRV or 'Rent' in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:  '
		if MMjrDyLdKhUb7V(u'مباشر') in PrGydBOaRV: wnNUzQihpqAXKyR8jelWfPCOuxI7M = 'LIVE:  '
		if MMjrDyLdKhUb7V(u'شراء') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:  '
		if MMjrDyLdKhUb7V(u'استئجار') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$$:  '
		if MMjrDyLdKhUb7V(u'إعلانات') in PrGydBOaRV: SSEYfZm4b0IUyg2PJXnt = '$:  '
	ZcAK0askvzIWr4R = c8Fvb4IfHW9XkG1mLK5Z(ZcAK0askvzIWr4R)
	if ZcAK0askvzIWr4R and 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
	pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.split('?')[0]
	if  pjMZ802XQCSxYVk and 'http' not in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = 'https:'+pjMZ802XQCSxYVk
	title = c8Fvb4IfHW9XkG1mLK5Z(title)
	if SSEYfZm4b0IUyg2PJXnt: title = SSEYfZm4b0IUyg2PJXnt+title
	DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace(',','')
	count = count.replace(',','')
	count = SomeI8i56FaDMGPE.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,count,DD1IVWFZbr7TlzYto5s,wnNUzQihpqAXKyR8jelWfPCOuxI7M,SSEYfZm4b0IUyg2PJXnt,ii1SRMJ8xhIz5yl0Xptb9a
def LyYjEfISpORQXlaD7PuoAzc24H0d9(url,data='',ZuCJj5EwDPROkb7UXNypofl=''):
	if ZuCJj5EwDPROkb7UXNypofl=='': ZuCJj5EwDPROkb7UXNypofl = 'ytInitialData'
	Jhilqrw8nstB7 = W5h0lzIcY3gMqrZpb7C()
	mgDoj8ZAqe0uBLxP4Kzp = {'User-Agent':Jhilqrw8nstB7,'Cookie':'PREF=hl=ar'}
	global LCIFdjzi5kVmRwehouHQ
	if not data: data = LCIFdjzi5kVmRwehouHQ.getSetting('av.youtube.data')
	if data.count(':::')==4: i1vYajMAKUOEl0HQ,key,iCQpJnV5mBPakXTgW8ufE2hF,DFVGW9wgzKuLRJOUQX1k28yZrb3M,ii1SRMJ8xhIz5yl0Xptb9a = data.split(':::')
	else: i1vYajMAKUOEl0HQ,key,iCQpJnV5mBPakXTgW8ufE2hF,DFVGW9wgzKuLRJOUQX1k28yZrb3M,ii1SRMJ8xhIz5yl0Xptb9a = '','','','',''
	ZZm1hsDV9ba = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":iCQpJnV5mBPakXTgW8ufE2hF}}}
	if url==aaeRjxiYcqOI6Sf8+'/shorts' or '/my_main_page_shorts_link' in url:
		url = aaeRjxiYcqOI6Sf8+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		ZZm1hsDV9ba['sequenceParams'] = i1vYajMAKUOEl0HQ
		ZZm1hsDV9ba = str(ZZm1hsDV9ba)
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = aaeRjxiYcqOI6Sf8+'/youtubei/v1/guide?key='+key
		ZZm1hsDV9ba = str(ZZm1hsDV9ba)
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and i1vYajMAKUOEl0HQ:
		ZZm1hsDV9ba['continuation'] = ii1SRMJ8xhIz5yl0Xptb9a
		ZZm1hsDV9ba['context']['client']['visitorData'] = i1vYajMAKUOEl0HQ
		ZZm1hsDV9ba = str(ZZm1hsDV9ba)
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and DFVGW9wgzKuLRJOUQX1k28yZrb3M:
		mgDoj8ZAqe0uBLxP4Kzp.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':iCQpJnV5mBPakXTgW8ufE2hF})
		mgDoj8ZAqe0uBLxP4Kzp.update({'Cookie':'VISITOR_INFO1_LIVE='+DFVGW9wgzKuLRJOUQX1k28yZrb3M})
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','YOUTUBE-GET_PAGE_DATA-6th')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('"innertubeApiKey".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if T9PyERLBA8wiVN30QjU14mW: key = T9PyERLBA8wiVN30QjU14mW[0]
	T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('"cver".*?"value".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if T9PyERLBA8wiVN30QjU14mW: iCQpJnV5mBPakXTgW8ufE2hF = T9PyERLBA8wiVN30QjU14mW[0]
	T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('"visitorData".*?"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.I)
	if T9PyERLBA8wiVN30QjU14mW: i1vYajMAKUOEl0HQ = T9PyERLBA8wiVN30QjU14mW[0]
	cookies = ttpgqJBdkoxeKOcwaiP.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): DFVGW9wgzKuLRJOUQX1k28yZrb3M = cookies['VISITOR_INFO1_LIVE']
	cO6niKSRzGEUTp32X1IP = i1vYajMAKUOEl0HQ+':::'+key+':::'+iCQpJnV5mBPakXTgW8ufE2hF+':::'+DFVGW9wgzKuLRJOUQX1k28yZrb3M+':::'+ii1SRMJ8xhIz5yl0Xptb9a
	if ZuCJj5EwDPROkb7UXNypofl=='ytInitialData' and 'ytInitialData' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('window\["ytInitialData"\] = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not E1EoaDmpGKdi0zqWL5: E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('var ytInitialData = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',E1EoaDmpGKdi0zqWL5[0])
	elif ZuCJj5EwDPROkb7UXNypofl=='ytInitialGuideData' and 'ytInitialGuideData' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		E1EoaDmpGKdi0zqWL5 = SomeI8i56FaDMGPE.findall('var ytInitialGuideData = ({.*?});',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',E1EoaDmpGKdi0zqWL5[0])
	elif '</script>' not in BsJ71WIxDtdFKveTcRPrqM4Cwb: CMtQ3TBJbXupf6P8ED = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',BsJ71WIxDtdFKveTcRPrqM4Cwb)
	else: CMtQ3TBJbXupf6P8ED = ''
	if 0:
		FDI8OfiZBHqXK3lYpdEg = str(CMtQ3TBJbXupf6P8ED)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: FDI8OfiZBHqXK3lYpdEg = FDI8OfiZBHqXK3lYpdEg.encode('utf8')
		open('S:\\0000emad.dat','wb').write(FDI8OfiZBHqXK3lYpdEg)
	LCIFdjzi5kVmRwehouHQ.setSetting('av.youtube.data',cO6niKSRzGEUTp32X1IP)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb,CMtQ3TBJbXupf6P8ED,cO6niKSRzGEUTp32X1IP
def jjhXvULEoJkxIzae3(url,fMGn2cXPKw9SyUY):
	search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	search = search.replace(' ','+')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/search?query='+search
	KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E,fMGn2cXPKw9SyUY)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	search = search.replace(' ','+')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: BBsrSqFtMjDpoIKY9 = '&sp=EgIQAg%253D%253D'
		else: BBsrSqFtMjDpoIKY9 = ''
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+BBsrSqFtMjDpoIKY9
	else:
		T2ZbMNA18WvOsyYSqLBQ4u0ol,ZIBjPHy9Muh,U2iQmHMJzoNkjORTGY7c51vZ = [],[],''
		mmrthQVHnLyUICib2F7fMzk3cBjglN = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		ynpKB512VbIQqmloa = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		vwmcuz9bM7npdBSiW = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع يوتيوب - اختر الترتيب',mmrthQVHnLyUICib2F7fMzk3cBjglN)
		if vwmcuz9bM7npdBSiW == -1: return
		Mwmvh4Z2rYbyeUNpP78REOcis = ynpKB512VbIQqmloa[vwmcuz9bM7npdBSiW]
		BsJ71WIxDtdFKveTcRPrqM4Cwb,g0gpLbIY2UnPud4WjsQKryM6wA,data = LyYjEfISpORQXlaD7PuoAzc24H0d9(vfIB6ib8q1hFX5GweRrVPNTjY2E+Mwmvh4Z2rYbyeUNpP78REOcis)
		if g0gpLbIY2UnPud4WjsQKryM6wA:
			try:
				s8sD4OlCoeIjYg3hNbUX72Qa1 = g0gpLbIY2UnPud4WjsQKryM6wA['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for CBnGvrs1AaVy0RqoT9t7Ph in range(len(s8sD4OlCoeIjYg3hNbUX72Qa1)):
					group = s8sD4OlCoeIjYg3hNbUX72Qa1[CBnGvrs1AaVy0RqoT9t7Ph]['searchFilterGroupRenderer']['filters']
					for jFnksu7ADcYreEGH38SioI9vPK4 in range(len(group)):
						WPiTF7Bufrdk = group[jFnksu7ADcYreEGH38SioI9vPK4]['searchFilterRenderer']
						if 'navigationEndpoint' in list(WPiTF7Bufrdk.keys()):
							ZcAK0askvzIWr4R = WPiTF7Bufrdk['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\u0026','&')
							title = WPiTF7Bufrdk['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								U2iQmHMJzoNkjORTGY7c51vZ = title
								spdYctk0fWD1Z = ZcAK0askvzIWr4R
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								U2iQmHMJzoNkjORTGY7c51vZ = title
								spdYctk0fWD1Z = ZcAK0askvzIWr4R
							if 'Sort by' in title: continue
							T2ZbMNA18WvOsyYSqLBQ4u0ol.append(c8Fvb4IfHW9XkG1mLK5Z(title))
							ZIBjPHy9Muh.append(ZcAK0askvzIWr4R)
			except: pass
		if not U2iQmHMJzoNkjORTGY7c51vZ: ddfhrSPgUbLGHk4IKMY67oV9qDsx = ''
		else:
			T2ZbMNA18WvOsyYSqLBQ4u0ol = ['بدون فلتر',U2iQmHMJzoNkjORTGY7c51vZ]+T2ZbMNA18WvOsyYSqLBQ4u0ol
			ZIBjPHy9Muh = ['',spdYctk0fWD1Z]+ZIBjPHy9Muh
			SRNpwdbg4EDv9e2 = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع يوتيوب - اختر الفلتر',T2ZbMNA18WvOsyYSqLBQ4u0ol)
			if SRNpwdbg4EDv9e2 == -1: return
			ddfhrSPgUbLGHk4IKMY67oV9qDsx = ZIBjPHy9Muh[SRNpwdbg4EDv9e2]
		if ddfhrSPgUbLGHk4IKMY67oV9qDsx: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = aaeRjxiYcqOI6Sf8+ddfhrSPgUbLGHk4IKMY67oV9qDsx
		elif Mwmvh4Z2rYbyeUNpP78REOcis: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E+Mwmvh4Z2rYbyeUNpP78REOcis
		else: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E
	KKlnDcetq8Rrp3GY0(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
	return
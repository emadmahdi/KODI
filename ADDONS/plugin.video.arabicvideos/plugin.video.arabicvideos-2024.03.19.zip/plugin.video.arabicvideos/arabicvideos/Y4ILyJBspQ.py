# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'RESOLVERS'
BQ5oeZnzx3I0gSH9haNuP7WKc = []
headers = {'User-Agent':''}
GSILyuaVqAT4DB2ekrF7ptdKZgzEh = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,source,type,url):
	if not TbFRyPoVlrQAw7n3h8BukmfHNq:
		xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		Gw9Bln1CveWbRjV5SEpDmz4yoqTPM = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'dict','MISC_PERM','SITES_ERRORS')
		kkWLjQKlRyJbig2XuG = p1BoraOuWL.strftime('%Y.%m.%d %H:%M',p1BoraOuWL.gmtime(CHhSItjbXy))
		BNvjADpPbo8fXZ6E4xLnczuWHT = kkWLjQKlRyJbig2XuG,url
		key = source+'    '+Y0Uhv2t8E67+'    '+str(Qf8xsJSwoKaUNc)
		QQONb7aR2M6L = ''
		if key not in list(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM.keys()): Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key] = [BNvjADpPbo8fXZ6E4xLnczuWHT]
		else:
			if url not in str(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key]): Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key].append(BNvjADpPbo8fXZ6E4xLnczuWHT)
			else: QQONb7aR2M6L = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		m3E4KGelZVsdkRQbhXuaNcI = 0
		for key in list(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM.keys()):
			Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key] = list(set(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key]))
			m3E4KGelZVsdkRQbhXuaNcI += len(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key])
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+QQONb7aR2M6L+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(m3E4KGelZVsdkRQbhXuaNcI))
		if m3E4KGelZVsdkRQbhXuaNcI>=5:
			svOyXbipkwY = nEYJ5OCXG0gcNy('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if svOyXbipkwY==1:
				Sp56QBE7k483g9hWRTD = ''
				for key in list(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM.keys()):
					Sp56QBE7k483g9hWRTD += '\n'+key
					lcRNsyTPHK69X = sorted(Gw9Bln1CveWbRjV5SEpDmz4yoqTPM[key],reverse=False,key=lambda NUexTKfAj2ry9: NUexTKfAj2ry9[0])
					for kkWLjQKlRyJbig2XuG,url in lcRNsyTPHK69X:
						Sp56QBE7k483g9hWRTD += '\n'+kkWLjQKlRyJbig2XuG+'    '+aDebGvrkdptunqTM8m4(url)
					Sp56QBE7k483g9hWRTD += '\n\n'
				import G4zaNTEvFt
				sycSign827ZrEldIB = G4zaNTEvFt.sOki9wK4yjEg3oHa('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',Sp56QBE7k483g9hWRTD)
				if sycSign827ZrEldIB: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if svOyXbipkwY!=-1:
				Gw9Bln1CveWbRjV5SEpDmz4yoqTPM = {}
				ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'MISC_PERM','SITES_ERRORS')
		if Gw9Bln1CveWbRjV5SEpDmz4yoqTPM: F4QxJHhsMj(qQ4BC6vW5YOfo,'MISC_PERM','SITES_ERRORS',Gw9Bln1CveWbRjV5SEpDmz4yoqTPM,bY2n5MtVA4cjpkFSxZ6K)
		return
	TbFRyPoVlrQAw7n3h8BukmfHNq = list(set(TbFRyPoVlrQAw7n3h8BukmfHNq))
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = LcJz69M4gIRD7K0obrpNfe5a(TbFRyPoVlrQAw7n3h8BukmfHNq,source)
	t391nYF6H0pGXC = str(aFyREdMQk7Ys95rX6uJieDGLS2).count('__watch')
	dGFEP029e5uY6oC3Hhkpx = str(aFyREdMQk7Ys95rX6uJieDGLS2).count('__download')
	bYuENs5wUQLrRq4Gyi = len(aFyREdMQk7Ys95rX6uJieDGLS2)-t391nYF6H0pGXC-dGFEP029e5uY6oC3Hhkpx
	cxZza3oswrD4uWXOELykVB5FK = 'مشاهدة:'+str(t391nYF6H0pGXC)+'    تحميل:'+str(dGFEP029e5uY6oC3Hhkpx)+'    أخرى:'+str(bYuENs5wUQLrRq4Gyi)
	if not aFyREdMQk7Ys95rX6uJieDGLS2: PcwChNBYmt4ruvsIEo,hHg7JwGuXDfxIVz5kYa1bpjMPA = 'unresolved',''
	else:
		add = 0
		if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in source for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in GSILyuaVqAT4DB2ekrF7ptdKZgzEh):
			add = 1
			aFyREdMQk7Ys95rX6uJieDGLS2 = ['RESOLVE_ALL_LINKS']+list(aFyREdMQk7Ys95rX6uJieDGLS2)
			r79xJG6jXHD = ['فحص جميع السيرفرات']+list(r79xJG6jXHD)
		while True:
			hHg7JwGuXDfxIVz5kYa1bpjMPA,PcwChNBYmt4ruvsIEo = '',''
			if add and len(aFyREdMQk7Ys95rX6uJieDGLS2)==2: I7mfbGiWNFcBVJOn = 1
			else: I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X(cxZza3oswrD4uWXOELykVB5FK,r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn==-1: PcwChNBYmt4ruvsIEo = 'canceled_1st_menu'
			elif add and I7mfbGiWNFcBVJOn==0:
				PcwChNBYmt4ruvsIEo = 'canceled_2nd_menu'
				rr60PDpqbMehZsYVuHmiAtN = Gx13ReXudv960BsN(r79xJG6jXHD[add:],aFyREdMQk7Ys95rX6uJieDGLS2[add:],source)
				if rr60PDpqbMehZsYVuHmiAtN:
					ss16Rb8vLq3UpEu = []
					for mHuqifFKcryG6CEWkUXSt7Z1p,z9O4PeyH6JbLto8cgvVFwhWn7E,mvAdGW4pVwDNhiYIKkaCrTbSOLf5,nSwh3oVv4AXG8WarL,DOXgZtLo7HzKfmGb3T8CM6 in rr60PDpqbMehZsYVuHmiAtN:
						if DOXgZtLo7HzKfmGb3T8CM6: ss16Rb8vLq3UpEu.append((mHuqifFKcryG6CEWkUXSt7Z1p,z9O4PeyH6JbLto8cgvVFwhWn7E,mvAdGW4pVwDNhiYIKkaCrTbSOLf5,nSwh3oVv4AXG8WarL,DOXgZtLo7HzKfmGb3T8CM6))
					if ss16Rb8vLq3UpEu: r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,errors,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g = zip(*ss16Rb8vLq3UpEu)
					else:
						ztgqWUaDpe8CE9N('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						PcwChNBYmt4ruvsIEo = 'failed'
						break
					cxZza3oswrD4uWXOELykVB5FK = 'السيرفرات الجيدة ( '+str(len(aFyREdMQk7Ys95rX6uJieDGLS2))+' )'
					add = 0
					continue
			else:
				rr60PDpqbMehZsYVuHmiAtN = Gx13ReXudv960BsN([r79xJG6jXHD[I7mfbGiWNFcBVJOn]],[aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]],source)
				if rr60PDpqbMehZsYVuHmiAtN:
					title,ZcAK0askvzIWr4R,errors,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g = rr60PDpqbMehZsYVuHmiAtN[0]
					if not ZZHhmdtY1g: errors,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g = zSwZHbDlvpfLXRQO4n(ZcAK0askvzIWr4R,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+ZcAK0askvzIWr4R+' ]')
						import G4zaNTEvFt
						G4zaNTEvFt.FeKLjQHTNsb139Wo8hx4()
						PcwChNBYmt4ruvsIEo = 'unresolved'
					else:
						xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+ZcAK0askvzIWr4R+' ]')
						PcwChNBYmt4ruvsIEo,hHg7JwGuXDfxIVz5kYa1bpjMPA,DGcdskjBKixNSwlW5O7rpM = U3iFQk1vm2RnaIY6rqfEbZVGg(title,ZcAK0askvzIWr4R,errors,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g,source,type)
			if PcwChNBYmt4ruvsIEo in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(aFyREdMQk7Ys95rX6uJieDGLS2)==1+add: break
			elif PcwChNBYmt4ruvsIEo in ['failed','timeout','tried']: break
			elif PcwChNBYmt4ruvsIEo not in ['canceled_2nd_menu','https']:
				if '\n' in hHg7JwGuXDfxIVz5kYa1bpjMPA: hHg7JwGuXDfxIVz5kYa1bpjMPA = '[LEFT]  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','\n[LEFT]  ')
				ztgqWUaDpe8CE9N('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+hHg7JwGuXDfxIVz5kYa1bpjMPA,profile='confirm_mediumfont')
	if PcwChNBYmt4ruvsIEo=='unresolved' and len(r79xJG6jXHD)>0: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+hHg7JwGuXDfxIVz5kYa1bpjMPA,profile='confirm_mediumfont')
	elif PcwChNBYmt4ruvsIEo in ['failed','timeout'] and hHg7JwGuXDfxIVz5kYa1bpjMPA!='': ztgqWUaDpe8CE9N('','','رسالة من المبرمج',hHg7JwGuXDfxIVz5kYa1bpjMPA,profile='confirm_mediumfont')
	return PcwChNBYmt4ruvsIEo
def Gx13ReXudv960BsN(W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq,source):
	global hT0LcdxErVusXjJyz9lWCBQIFbtSv
	hT0LcdxErVusXjJyz9lWCBQIFbtSv,rr60PDpqbMehZsYVuHmiAtN,SzAhQXWn2i1stNDI5dUbVxmlGPv,new = [],[],[],[]
	PPEIqwl1Hk7nJKre(False,False,False)
	count = len(TbFRyPoVlrQAw7n3h8BukmfHNq)
	for juqtWiLzIUx4kNAPJ6nBX7OhCgr in range(count):
		hT0LcdxErVusXjJyz9lWCBQIFbtSv.append(None)
		title = W0WLuDcR5UI6K[juqtWiLzIUx4kNAPJ6nBX7OhCgr]
		ZcAK0askvzIWr4R = TbFRyPoVlrQAw7n3h8BukmfHNq[juqtWiLzIUx4kNAPJ6nBX7OhCgr].strip(' ').strip('&').strip('?').strip('/')
		if count>1: NCXj2ri3Unm6TFWIgwh('فحص سيرفر رقم  '+str(juqtWiLzIUx4kNAPJ6nBX7OhCgr+1),title)
		awvmyHebrZDuLxiA3kYS = ZcAK0askvzIWr4R.split('?named=',1)[0]
		qqOvMBajEu = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','RESOLVED',awvmyHebrZDuLxiA3kYS)
		if qqOvMBajEu and 'AKWAM' not in source:
			hT0LcdxErVusXjJyz9lWCBQIFbtSv[juqtWiLzIUx4kNAPJ6nBX7OhCgr] = qqOvMBajEu
		else:
			qMoYbwexIHsu9BQSj4c71C8 = RrCB5k9XV6hYNSlIKJ2.Thread(target=zSwZHbDlvpfLXRQO4n,args=(ZcAK0askvzIWr4R,source,juqtWiLzIUx4kNAPJ6nBX7OhCgr))
			qMoYbwexIHsu9BQSj4c71C8.start()
			p1BoraOuWL.sleep(0.5)
			SzAhQXWn2i1stNDI5dUbVxmlGPv.append(qMoYbwexIHsu9BQSj4c71C8)
			new.append(juqtWiLzIUx4kNAPJ6nBX7OhCgr)
	timeout = 20
	for qMoYbwexIHsu9BQSj4c71C8 in SzAhQXWn2i1stNDI5dUbVxmlGPv: qMoYbwexIHsu9BQSj4c71C8.join(timeout)
	for juqtWiLzIUx4kNAPJ6nBX7OhCgr in range(count):
		title = W0WLuDcR5UI6K[juqtWiLzIUx4kNAPJ6nBX7OhCgr]
		ZcAK0askvzIWr4R = TbFRyPoVlrQAw7n3h8BukmfHNq[juqtWiLzIUx4kNAPJ6nBX7OhCgr].strip(' ').strip('&').strip('?').strip('/')
		if hT0LcdxErVusXjJyz9lWCBQIFbtSv[juqtWiLzIUx4kNAPJ6nBX7OhCgr]: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = hT0LcdxErVusXjJyz9lWCBQIFbtSv[juqtWiLzIUx4kNAPJ6nBX7OhCgr]
		else: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		rr60PDpqbMehZsYVuHmiAtN.append([title,ZcAK0askvzIWr4R,hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2])
		if juqtWiLzIUx4kNAPJ6nBX7OhCgr in new:
			awvmyHebrZDuLxiA3kYS = ZcAK0askvzIWr4R.split('?named=',1)[0]
			F4QxJHhsMj(qQ4BC6vW5YOfo,'RESOLVED',awvmyHebrZDuLxiA3kYS,[hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2],jj0C6IlvPFh)
	PPEIqwl1Hk7nJKre('','','')
	return rr60PDpqbMehZsYVuHmiAtN
def zSwZHbDlvpfLXRQO4n(url,source,tt7LgzAD3j6VwBud=0):
	global hT0LcdxErVusXjJyz9lWCBQIFbtSv
	xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Resolving started   Original: [ '+url+' ]')
	ZcAK0askvzIWr4R,F5KESco1hzO74Dp2Uvndqk = url,''
	GHb4f6ZAd8 = 'INTERNAL_RESOLVER'
	hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = pSxFTVZLXQcr1z9M(url,source)
	if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER':
		F5KESco1hzO74Dp2Uvndqk = '\nResolver 1:  Exit'
		hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		return F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	elif 'NEED_EXTERNAL_RESOLVERS' in hHg7JwGuXDfxIVz5kYa1bpjMPA:
		F5KESco1hzO74Dp2Uvndqk = '\nResolver 1:  Need External Resolver'
		ZcAK0askvzIWr4R = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)[0]
		hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		GHb4f6ZAd8,F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = hhAbUWNF3D2zS9G8OptPXBrdkKEij(F5KESco1hzO74Dp2Uvndqk,ZcAK0askvzIWr4R,source,tt7LgzAD3j6VwBud)
	elif hHg7JwGuXDfxIVz5kYa1bpjMPA: F5KESco1hzO74Dp2Uvndqk = 'Resolver 1:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','').replace('\r','')[:80]
	if aFyREdMQk7Ys95rX6uJieDGLS2:
		aFyREdMQk7Ys95rX6uJieDGLS2 = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Resolving succeeded   Resolver: [ '+GHb4f6ZAd8+' ]   Original: [ '+url+' ]   Link: [ '+ZcAK0askvzIWr4R+' ]   Results: [ '+str(aFyREdMQk7Ys95rX6uJieDGLS2)+' ]')
	else: xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+ZcAK0askvzIWr4R+' ]   Errors: [ '+F5KESco1hzO74Dp2Uvndqk+' ]')
	F5KESco1hzO74Dp2Uvndqk = aDebGvrkdptunqTM8m4(F5KESco1hzO74Dp2Uvndqk)
	hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	return F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def hhAbUWNF3D2zS9G8OptPXBrdkKEij(F5KESco1hzO74Dp2Uvndqk,url,source,tt7LgzAD3j6VwBud):
	global hT0LcdxErVusXjJyz9lWCBQIFbtSv
	GHb4f6ZAd8 = 'EXTERNAL_RESOLVER_2'
	hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = MJhlwTycLiV4XnQrEfm2(url,source)
	aFyREdMQk7Ys95rX6uJieDGLS2 = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)
	hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	elif 'Failed:' in hHg7JwGuXDfxIVz5kYa1bpjMPA:
		F5KESco1hzO74Dp2Uvndqk += '\nResolver 2:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','').replace('\r','')[:80]
		GHb4f6ZAd8 = 'EXTERNAL_RESOLVER_3'
		hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = b2btBx0YwmAVWGzQC5rXo(url,source)
		aFyREdMQk7Ys95rX6uJieDGLS2 = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)
		hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		elif 'Failed:' in hHg7JwGuXDfxIVz5kYa1bpjMPA:
			F5KESco1hzO74Dp2Uvndqk += '\nResolver 3:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','').replace('\r','')[:80]
			GHb4f6ZAd8 = 'EXTERNAL_RESOLVER_4'
			hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = JteGA6iuza2YxDqkn7yXN(url,source)
			aFyREdMQk7Ys95rX6uJieDGLS2 = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)
			hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
			if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
			elif 'Failed:' in hHg7JwGuXDfxIVz5kYa1bpjMPA:
				F5KESco1hzO74Dp2Uvndqk += '\nResolver 4:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','').replace('\r','')[:80]
				GHb4f6ZAd8 = 'EXTERNAL_RESOLVER_5'
				hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = qq7CBRnIw2PxV(url,source)
				aFyREdMQk7Ys95rX6uJieDGLS2 = ee8GVXCIuxaoYiOyvnZJ7k36(aFyREdMQk7Ys95rX6uJieDGLS2)
				hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
				if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
				elif 'Failed:' in hHg7JwGuXDfxIVz5kYa1bpjMPA:
					F5KESco1hzO74Dp2Uvndqk += '\nResolver 5:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA.replace('\n','').replace('\r','')[:80]
	hT0LcdxErVusXjJyz9lWCBQIFbtSv[tt7LgzAD3j6VwBud] = F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	return GHb4f6ZAd8,F5KESco1hzO74Dp2Uvndqk,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def U3iFQk1vm2RnaIY6rqfEbZVGg(title,ZcAK0askvzIWr4R,hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,source,type=''):
	if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	elif aFyREdMQk7Ys95rX6uJieDGLS2:
		while True:
			if len(aFyREdMQk7Ys95rX6uJieDGLS2)==1: I7mfbGiWNFcBVJOn = 0
			else: I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الملف المناسب:', r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn==-1: PcwChNBYmt4ruvsIEo = 'tried'
			else:
				cziPFMVok0K1NWS = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
				title = r79xJG6jXHD[I7mfbGiWNFcBVJOn]
				xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(cziPFMVok0K1NWS)+' ]')
				if 'moshahda.' in cziPFMVok0K1NWS and 'download_orig' in cziPFMVok0K1NWS:
					mg2uznQtDvTcLjJhEyWePxK9rR,VyGZnrjdiz,DGcdskjBKixNSwlW5O7rpM = qNYMlAQp3ZLXSw7fFdVchDG(cziPFMVok0K1NWS)
					if DGcdskjBKixNSwlW5O7rpM: cziPFMVok0K1NWS = DGcdskjBKixNSwlW5O7rpM[0]
					else: cziPFMVok0K1NWS = ''
				if not cziPFMVok0K1NWS: PcwChNBYmt4ruvsIEo = 'unresolved'
				else: PcwChNBYmt4ruvsIEo = kFygcp2jqSUCiNRnur71xMZI96(cziPFMVok0K1NWS,source,type)
			if PcwChNBYmt4ruvsIEo in ['playing','testing','canceled_2nd_menu'] or len(aFyREdMQk7Ys95rX6uJieDGLS2)==1: break
			elif PcwChNBYmt4ruvsIEo in ['failed','timeout','tried']: break
			else: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		PcwChNBYmt4ruvsIEo = 'unresolved'
		MMQ7S0sAgzHIumcqWUx = jjCeNxAVJ9RpqzDI3Yg6dy(ZcAK0askvzIWr4R)
		if MMQ7S0sAgzHIumcqWUx: PcwChNBYmt4ruvsIEo = kFygcp2jqSUCiNRnur71xMZI96(ZcAK0askvzIWr4R,source,type)
	return PcwChNBYmt4ruvsIEo,hHg7JwGuXDfxIVz5kYa1bpjMPA,aFyREdMQk7Ys95rX6uJieDGLS2
def XF9joOI5nxJe14S7Q3YR(url,source):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,luScaRNOojMmskGr5g3Z,FglT5H2faVGm6IqpcXS9vQsojPLu,DK4VbNthgoX7TGP,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz = url,'','','','','','',''
	if '?named=' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E,luScaRNOojMmskGr5g3Z = url.split('?named=',1)
		luScaRNOojMmskGr5g3Z = luScaRNOojMmskGr5g3Z+'__'+'__'+'__'+'__'
		luScaRNOojMmskGr5g3Z = luScaRNOojMmskGr5g3Z.lower()
		CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz,AbaM4YmJZvf8V5hNL2jkd7nUogDXs = luScaRNOojMmskGr5g3Z.split('__')[:5]
	if AfejZJoKh4D7k5G1P9gCwxTz=='': AfejZJoKh4D7k5G1P9gCwxTz = '0'
	else: AfejZJoKh4D7k5G1P9gCwxTz = AfejZJoKh4D7k5G1P9gCwxTz.replace('p','').replace(' ','')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.strip('?').strip('/').strip('&')
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'host')
	if CH3VkKb5LiB1cZUsoE: DK4VbNthgoX7TGP = CH3VkKb5LiB1cZUsoE
	else: DK4VbNthgoX7TGP = FglT5H2faVGm6IqpcXS9vQsojPLu
	DK4VbNthgoX7TGP = DRom9hFTZXKuvfr2(DK4VbNthgoX7TGP,'name')
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	luScaRNOojMmskGr5g3Z = luScaRNOojMmskGr5g3Z.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	DK4VbNthgoX7TGP = DK4VbNthgoX7TGP.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return vfIB6ib8q1hFX5GweRrVPNTjY2E,luScaRNOojMmskGr5g3Z,FglT5H2faVGm6IqpcXS9vQsojPLu,DK4VbNthgoX7TGP,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz
def THatB0FuGSXvgKYkRhxIr(url,source):
	i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE,Cb8tNQ4aRSu2,sFigdLlBT8SDqpR2tZGz4Hf,jrQB65lgdy2kLV9S8iE,SSjiRA7WV09LMIsDToGEUYqfgkK8tu,GHb4f6ZAd8 = '','',None,None,None,None,None
	vfIB6ib8q1hFX5GweRrVPNTjY2E,luScaRNOojMmskGr5g3Z,FglT5H2faVGm6IqpcXS9vQsojPLu,DK4VbNthgoX7TGP,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz = XF9joOI5nxJe14S7Q3YR(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if CxhvM0I7d3kcrD9aeTBESPG!='':
			if 'mp4' not in CxhvM0I7d3kcrD9aeTBESPG: CxhvM0I7d3kcrD9aeTBESPG = '%'+CxhvM0I7d3kcrD9aeTBESPG
			CxhvM0I7d3kcrD9aeTBESPG = ' '+CxhvM0I7d3kcrD9aeTBESPG
		if AfejZJoKh4D7k5G1P9gCwxTz!='':
			AfejZJoKh4D7k5G1P9gCwxTz = '%%%%%%%%%'+AfejZJoKh4D7k5G1P9gCwxTz
			AfejZJoKh4D7k5G1P9gCwxTz = ' '+AfejZJoKh4D7k5G1P9gCwxTz[-9:]
	if   'AKOAM'		in source: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'AKWAM'		in source: Cb8tNQ4aRSu2	= 'akwam'
	elif 'katkoute'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'photos.app.g'	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'arabseed'		in source: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'alarab'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'fasel'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 't7meel'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'movs4u'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'myegyvip'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'fajer'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'فجر'			in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= 'fajer'
	elif 'فلسطين'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= 'palestine'
	elif 'gdrive'		in vfIB6ib8q1hFX5GweRrVPNTjY2E:   Cb8tNQ4aRSu2	= 'google'
	elif 'mycima'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'wecima'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'cimanow'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'newcima'		in CH3VkKb5LiB1cZUsoE:   Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'dailymotion'	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'bokra'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'tvfun'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'tvksa'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'anavidz'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'shoofpro'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= DK4VbNthgoX7TGP
	elif 'shahid4u'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'shahed4u'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'cima4u'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'egynow'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'halacima'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'cimaabdo'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'youtu'	 	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'youtube'
	elif 'y2u.be'	 	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'youtube'
	elif 'd.egybest.d'	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'egybestvip'
	elif 'egy.best'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'egybest1'
	elif 'egybest'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'egybest3'
	elif 'moshahda'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'moshahda'
	elif 'facultybooks'	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'facultybooks'
	elif 'inflam.cc'	in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'inflam'
	elif 'buzzvrl'		in FglT5H2faVGm6IqpcXS9vQsojPLu: Cb8tNQ4aRSu2	= 'buzzvrl'
	elif 'arabloads'	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'arabloads'
	elif 'archive'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'archive'
	elif 'catch.is'	 	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'catch'
	elif 'filerio'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'filerio'
	elif 'vidbm'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'vidbm'
	elif 'vidhd'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'myvid'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'myviid'		in FglT5H2faVGm6IqpcXS9vQsojPLu: SSjiRA7WV09LMIsDToGEUYqfgkK8tu	= DK4VbNthgoX7TGP
	elif 'videobin'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'videobin'
	elif 'govid'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'govid'
	elif 'liivideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'liivideo'
	elif 'mp4upload'	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'mp4upload'
	elif 'publicvideo'	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'publicvideo'
	elif 'rapidvideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'rapidvideo'
	elif 'top4top'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'top4top'
	elif 'upp' 			in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'upbom'
	elif 'upb' 			in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'upbom'
	elif 'uqload' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'uqload'
	elif 'vcstream' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'vcstream'
	elif 'vidbob'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'vidbob'
	elif 'vidoza' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'vidoza'
	elif 'watchvideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'watchvideo'
	elif 'wintv.live'	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'wintv.live'
	elif 'zippyshare'	in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'zippyshare'
	elif 'hd-cdn'		in FglT5H2faVGm6IqpcXS9vQsojPLu: sFigdLlBT8SDqpR2tZGz4Hf	= 'hd-cdn'
	if   Cb8tNQ4aRSu2:	i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = 'خاص',Cb8tNQ4aRSu2
	elif SSjiRA7WV09LMIsDToGEUYqfgkK8tu:		i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = '%محدد',SSjiRA7WV09LMIsDToGEUYqfgkK8tu
	elif sFigdLlBT8SDqpR2tZGz4Hf:		i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = '%%عام معروف',sFigdLlBT8SDqpR2tZGz4Hf
	elif jrQB65lgdy2kLV9S8iE:	i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = '%%%عام خارجي',jrQB65lgdy2kLV9S8iE
	elif GHb4f6ZAd8:	i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = '%%%%عام خارجي',DK4VbNthgoX7TGP
	else:			i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE = '%%%%%عام مجهول',DK4VbNthgoX7TGP
	return i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz
def pSxFTVZLXQcr1z9M(url,source):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,SSjiRA7WV09LMIsDToGEUYqfgkK8tu,FglT5H2faVGm6IqpcXS9vQsojPLu,DK4VbNthgoX7TGP,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz = XF9joOI5nxJe14S7Q3YR(url,source)
	if   'AKOAM'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = xuBOFde24X(vfIB6ib8q1hFX5GweRrVPNTjY2E,CH3VkKb5LiB1cZUsoE)
	elif 'AKWAM'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = vfhp39d4er(vfIB6ib8q1hFX5GweRrVPNTjY2E,type,AfejZJoKh4D7k5G1P9gCwxTz)
	elif 'FASELHD1'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Jp96cr4yVB(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'CIMA4U'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = yFBWmcKp2k(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'CIMACLUB'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = XnEphROtxM(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'ARABSEED'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = HBmivPUk2O(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'CIMAABDO'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = F4ZG65u8Dt(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'SHOFHA'		in source: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = FeDQWiYyqn(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'katkoute'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = HDkQ23TwVc(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'akoam.cam'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = ChqefOL4Mn(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'alarab'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = aTENLGIzUuwJCSkBxWe(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'shahid4u'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = g3fxlLcTwp(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'shahed4u'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = g3fxlLcTwp(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'egynow'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = K5ZxXC167D(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'tvfun'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = z18cJRCTX5(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'tvksa'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = z18cJRCTX5(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'tv-f.com'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = z18cJRCTX5(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'halacima'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = TqzA2cb9Fh(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'shoofpro'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = ZynRajS6D2(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'myegyvip'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = fJikLFHth9(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'vs4u'			in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = rJCbLy7F40(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'fajer'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = g4OzlXIh9V(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'cimanow'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = QkSEbr6RM7(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'newcima'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = QkSEbr6RM7(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'cima-light'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = M9lTLt28So(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'cimalight'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = M9lTLt28So(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'mycima'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = oFz1gSBjXr(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'wecima'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = VxXWc4O2be(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'bokra'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = dWvezyn71D(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'dailymotion'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Y3jywo7Lua(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'arblionz'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = YRUMjINH0s(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'd.egybest.d'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	elif 'egy.best'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = NT4RbrmaI5(url)
	elif 'egybest'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = DDwJuxKcqi(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'series4watch'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = BmKp37VSQA(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	elif 'upbam' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	else: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	return 'Failed:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def MJhlwTycLiV4XnQrEfm2(url,source):
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'name')
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	if   'youtu'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = tHSNcldqrQ(url)
	elif 'y2u.be'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = tHSNcldqrQ(url)
	elif 'googleuserco' in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = oxTmFq7rOi3zv9V(url)
	elif 'photos.app.g'	in url   : hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = bEYuFQ6A7hXq3I1P9an(url)
	elif 'dailymotion'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Y3jywo7Lua(url)
	elif 'moshahda'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = qNYMlAQp3ZLXSw7fFdVchDG(url)
	elif 'faselhd'		in url   : hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Jp96cr4yVB(url)
	elif 'arabloads'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = pW2J8N9V5nxoGuCLy4Bb(url)
	elif 'archive'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = hXJPoEBedi0x7MLD2IgAlKjzT(url)
	elif 'buzzvrl'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = FqW5AxK67eBijVtb3MOpQE4G(url)
	elif 'e5tsar'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = mja4IdRGzFgrsXWMfAYey86lV1DB(url)
	elif 'facultybooks'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Q4UtArB7F3hi52MoT8OE6k91qG(url)
	elif 'inflam.cc'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Q4UtArB7F3hi52MoT8OE6k91qG(url)
	elif 'upbam' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '',[''],[url]
	elif 'liivideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = TiDnEJbQmol4c(url)
	elif 'mp4upload'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = P10srT7zKdSlH5bWRMvtVwC(url)
	elif 'rapidvideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = Mx746y9KWizTAabd3Q(url)
	elif 'top4top'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = aVKcbyQrfIqmURs5(url)
	elif 'upb' 			in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = nStie7hYMxvq1LP(url)
	elif 'upp' 			in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = nStie7hYMxvq1LP(url)
	elif 'uqload' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = cLOj0h7ogDU6SJGsEdwQ3aTl(url)
	elif 'vcstream' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = B9qVtGcmih8sSnexAgjoT6O(url)
	elif 'vidbob'		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = as5vKcmMO4wXYn8r27qH1oepQTVfFB(url)
	elif 'vidoza' 		in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = mm0BywIhQN1xkpj5UVAdE3uJz2YLK(url)
	elif 'watchvideo' 	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = q1qTitM53YpoD4dlZsnrEkIQXJSAe0(url)
	elif 'wintv.live'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = rnLybOwsYl2AhCIc16qTP(url)
	elif 'zippyshare'	in FglT5H2faVGm6IqpcXS9vQsojPLu: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = EW7zXIsfvdRipxK1boegcLFuH85(url)
	if aFyREdMQk7Ys95rX6uJieDGLS2: return 'Failed: '+hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	return 'Failed:  ',[],[]
def b2btBx0YwmAVWGzQC5rXo(url,source):
	hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = gUc4iXZjWDydLHNYnCJxMwF3t(url)
	if aFyREdMQk7Ys95rX6uJieDGLS2: return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	if hHg7JwGuXDfxIVz5kYa1bpjMPA=='EXIT_RESOLVER': hHg7JwGuXDfxIVz5kYa1bpjMPA = ''
	return 'Failed:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA,[],[]
def ee8GVXCIuxaoYiOyvnZJ7k36(esJu5o91dDibMxQzlfmKR6hAPqyY2):
	if 'list' in str(type(esJu5o91dDibMxQzlfmKR6hAPqyY2)):
		ZZHhmdtY1g = []
		for ZcAK0askvzIWr4R in esJu5o91dDibMxQzlfmKR6hAPqyY2:
			if 'str' in str(type(ZcAK0askvzIWr4R)):
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\r','').replace('\n','').strip(' ')
			ZZHhmdtY1g.append(ZcAK0askvzIWr4R)
	else: ZZHhmdtY1g = esJu5o91dDibMxQzlfmKR6hAPqyY2.replace('\r','').replace('\n','').strip(' ')
	return ZZHhmdtY1g
def LcJz69M4gIRD7K0obrpNfe5a(DGcdskjBKixNSwlW5O7rpM,source):
	l5N0ornX1f2LDdOVWU = IIbavC96MQ1nHq3Pjx
	data = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SERVERS',DGcdskjBKixNSwlW5O7rpM)
	if data:
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = list(zip(*data))
		return r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,dd7p32qILrThKxcaJzQBXnU9HSsvO = [],[],[]
	for ZcAK0askvzIWr4R in DGcdskjBKixNSwlW5O7rpM:
		if '//' not in ZcAK0askvzIWr4R: continue
		i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz = THatB0FuGSXvgKYkRhxIr(ZcAK0askvzIWr4R,source)
		AfejZJoKh4D7k5G1P9gCwxTz = SomeI8i56FaDMGPE.findall('\d+',AfejZJoKh4D7k5G1P9gCwxTz,SomeI8i56FaDMGPE.DOTALL)
		if AfejZJoKh4D7k5G1P9gCwxTz: AfejZJoKh4D7k5G1P9gCwxTz = int(AfejZJoKh4D7k5G1P9gCwxTz[0])
		else: AfejZJoKh4D7k5G1P9gCwxTz = 0
		FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
		dd7p32qILrThKxcaJzQBXnU9HSsvO.append([i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R,FglT5H2faVGm6IqpcXS9vQsojPLu])
	if dd7p32qILrThKxcaJzQBXnU9HSsvO:
		NpuRnSrkGTDOAtZw7 = sorted(dd7p32qILrThKxcaJzQBXnU9HSsvO,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		GFbywmIp85BPu = []
		for BNvjADpPbo8fXZ6E4xLnczuWHT in NpuRnSrkGTDOAtZw7:
			if BNvjADpPbo8fXZ6E4xLnczuWHT not in GFbywmIp85BPu:
				GFbywmIp85BPu.append(BNvjADpPbo8fXZ6E4xLnczuWHT)
		for i80idZeNDlICuVb,CH3VkKb5LiB1cZUsoE,type,CxhvM0I7d3kcrD9aeTBESPG,AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R,FglT5H2faVGm6IqpcXS9vQsojPLu in GFbywmIp85BPu:
			if AfejZJoKh4D7k5G1P9gCwxTz: AfejZJoKh4D7k5G1P9gCwxTz = str(AfejZJoKh4D7k5G1P9gCwxTz)
			else: AfejZJoKh4D7k5G1P9gCwxTz = ''
			title = 'سيرفر'+' '+type+' '+i80idZeNDlICuVb+' '+AfejZJoKh4D7k5G1P9gCwxTz+' '+CxhvM0I7d3kcrD9aeTBESPG+' '+CH3VkKb5LiB1cZUsoE
			if FglT5H2faVGm6IqpcXS9vQsojPLu not in title: title = title+' '+FglT5H2faVGm6IqpcXS9vQsojPLu
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if ZcAK0askvzIWr4R not in aFyREdMQk7Ys95rX6uJieDGLS2:
				r79xJG6jXHD.append(title)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		if aFyREdMQk7Ys95rX6uJieDGLS2:
			data = list(zip(r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2))
			if data: F4QxJHhsMj(qQ4BC6vW5YOfo,'SERVERS',DGcdskjBKixNSwlW5O7rpM,data,l5N0ornX1f2LDdOVWU)
	return r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def JteGA6iuza2YxDqkn7yXN(url,source):
	zi68Y9T7ngdIXKALbv3fjVEeOJm = ''
	rr60PDpqbMehZsYVuHmiAtN = False
	try:
		import resolveurl as xnV4iYgqSEa7fIkOGmry
		rr60PDpqbMehZsYVuHmiAtN = xnV4iYgqSEa7fIkOGmry.resolve(url)
	except Exception as XRvfoBsrKyh06: zi68Y9T7ngdIXKALbv3fjVEeOJm = str(XRvfoBsrKyh06)
	if not rr60PDpqbMehZsYVuHmiAtN:
		if zi68Y9T7ngdIXKALbv3fjVEeOJm=='':
			zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
			if zi68Y9T7ngdIXKALbv3fjVEeOJm!='NoneType: None\n': EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
		hHg7JwGuXDfxIVz5kYa1bpjMPA = zi68Y9T7ngdIXKALbv3fjVEeOJm.splitlines()[-1]
		return 'Failed:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA,[],[]
	return '',[''],[rr60PDpqbMehZsYVuHmiAtN]
def qq7CBRnIw2PxV(url,source):
	zi68Y9T7ngdIXKALbv3fjVEeOJm = ''
	rr60PDpqbMehZsYVuHmiAtN = False
	try:
		import youtube_dl as xGbvYZUPRmqd
		uF5RqJEtGxdYiH6MKAb3BOmo = xGbvYZUPRmqd.YoutubeDL({'no_color': True})
		rr60PDpqbMehZsYVuHmiAtN = uF5RqJEtGxdYiH6MKAb3BOmo.extract_info(url,download=False)
	except Exception as XRvfoBsrKyh06: zi68Y9T7ngdIXKALbv3fjVEeOJm = str(XRvfoBsrKyh06)
	if not rr60PDpqbMehZsYVuHmiAtN or 'formats' not in list(rr60PDpqbMehZsYVuHmiAtN.keys()):
		if zi68Y9T7ngdIXKALbv3fjVEeOJm=='':
			zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
			if zi68Y9T7ngdIXKALbv3fjVEeOJm!='NoneType: None\n': EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
		hHg7JwGuXDfxIVz5kYa1bpjMPA = zi68Y9T7ngdIXKALbv3fjVEeOJm.splitlines()[-1]
		return 'Failed:  '+hHg7JwGuXDfxIVz5kYa1bpjMPA,[],[]
	else:
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
		for ZcAK0askvzIWr4R in rr60PDpqbMehZsYVuHmiAtN['formats']:
			r79xJG6jXHD.append(ZcAK0askvzIWr4R['format'])
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R['url'])
		return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def aTENLGIzUuwJCSkBxWe(url):
	if '.m3u8' in url:
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = I1IwMGlyuaB9XTe(url)
		if aFyREdMQk7Ys95rX6uJieDGLS2: return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def HDkQ23TwVc(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq,W0WLuDcR5UI6K = [],[]
	if '/videos.mp4?vid=' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in ttpgqJBdkoxeKOcwaiP.headers:
			ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['Location']
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
			FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			W0WLuDcR5UI6K.append(FglT5H2faVGm6IqpcXS9vQsojPLu)
	elif 'katkoute.com' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		H9fQyK5nmW8c4LgvpG7 = SomeI8i56FaDMGPE.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if H9fQyK5nmW8c4LgvpG7:
			H9fQyK5nmW8c4LgvpG7 = H9fQyK5nmW8c4LgvpG7[0]
			NTpDCUuRGVc = CVW8t72PJBfeiaTrxdNv0(H9fQyK5nmW8c4LgvpG7)
			PapRrI6zEoVhdFfJNW4lbYm85euy = SomeI8i56FaDMGPE.findall('sources:(\[.*?\]),',NTpDCUuRGVc,SomeI8i56FaDMGPE.DOTALL)
			if PapRrI6zEoVhdFfJNW4lbYm85euy:
				PapRrI6zEoVhdFfJNW4lbYm85euy = PapRrI6zEoVhdFfJNW4lbYm85euy[0]
				PapRrI6zEoVhdFfJNW4lbYm85euy = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('list',PapRrI6zEoVhdFfJNW4lbYm85euy)
				for dict in PapRrI6zEoVhdFfJNW4lbYm85euy:
					ZcAK0askvzIWr4R = dict['file']
					AfejZJoKh4D7k5G1P9gCwxTz = dict['label']
					TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
					FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
					W0WLuDcR5UI6K.append(AfejZJoKh4D7k5G1P9gCwxTz+' '+FglT5H2faVGm6IqpcXS9vQsojPLu)
		elif 'Location' in ttpgqJBdkoxeKOcwaiP.headers:
			ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['Location']
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
			FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			W0WLuDcR5UI6K.append(FglT5H2faVGm6IqpcXS9vQsojPLu)
		if '?url=https://photos.app.goo' in url:
			ZcAK0askvzIWr4R = url.split('?url=')[1]
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&')[0]
			if ZcAK0askvzIWr4R:
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
				W0WLuDcR5UI6K.append('photos google')
	else:
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(url)
		FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'name')
		W0WLuDcR5UI6K.append(FglT5H2faVGm6IqpcXS9vQsojPLu)
	if not TbFRyPoVlrQAw7n3h8BukmfHNq: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(TbFRyPoVlrQAw7n3h8BukmfHNq)==1: ZcAK0askvzIWr4R = TbFRyPoVlrQAw7n3h8BukmfHNq[0]
	else:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر الملف المناسب',W0WLuDcR5UI6K)
		if I7mfbGiWNFcBVJOn==-1: return 'EXIT_RESOLVER',[],[]
		ZcAK0askvzIWr4R = TbFRyPoVlrQAw7n3h8BukmfHNq[I7mfbGiWNFcBVJOn]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def oxTmFq7rOi3zv9V(url):
	headers = {'User-Agent':'Kodi/'+str(Qf8xsJSwoKaUNc)}
	for jUSuZAztxy34TB5CIP2 in range(50):
		p1BoraOuWL.sleep(0.100)
		ttpgqJBdkoxeKOcwaiP = K8tfnJSR56O9ENghiVGYQZjoDX('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()):
			ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['Location']
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'|User-Agent='+headers['User-Agent']
			return '',[''],[ZcAK0askvzIWr4R]
		if ttpgqJBdkoxeKOcwaiP.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def bEYuFQ6A7hXq3I1P9an(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz = ZcAK0askvzIWr4R[0]
		return '',[AfejZJoKh4D7k5G1P9gCwxTz],[ZcAK0askvzIWr4R]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def Jp96cr4yVB(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BsJ71WIxDtdFKveTcRPrqM4Cwb = rZdXbWjBNth8U(BsJ71WIxDtdFKveTcRPrqM4Cwb)
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"file":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R: return '',[''],[ZcAK0askvzIWr4R[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def FeDQWiYyqn(url):
	if '/down.php' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('video-wrapper.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		url = ZcAK0askvzIWr4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def yFBWmcKp2k(url):
	if 'server.php' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		if 'http' in ZcAK0askvzIWr4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def K5ZxXC167D(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
	mgDoj8ZAqe0uBLxP4Kzp = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-EGYNOW-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: return 'Error: Resolver Failed EGYNOW',[],[]
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def ZynRajS6D2(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if not ZcAK0askvzIWr4R: return 'Error: Resolver Failed SHOOFPRO',[],[]
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def TqzA2cb9Fh(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
	mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-HALACIMA-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('''<iframe src=["'](.*?)["']''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if not ZcAK0askvzIWr4R: return 'Error: Resolver Failed HALACIMA',[],[]
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def F4ZG65u8Dt(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
	mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-CIMAABDO-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('''<iframe src=["'](.*?)["']''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	else: ZcAK0askvzIWr4R = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def z18cJRCTX5(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	YYDWUJxdrt = SomeI8i56FaDMGPE.findall("var fserv =.*?'(.*?)'",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	if YYDWUJxdrt:
		YYDWUJxdrt = YYDWUJxdrt[0][2:]
		YYDWUJxdrt = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(YYDWUJxdrt)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: YYDWUJxdrt = YYDWUJxdrt.decode('utf8')
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',YYDWUJxdrt,SomeI8i56FaDMGPE.DOTALL)
	else: ZcAK0askvzIWr4R = ''
	if not ZcAK0askvzIWr4R: return 'Error: Resolver Failed TVFUN',[],[]
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def fJikLFHth9(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('class="col-sm-12".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: return 'Error: Resolver Failed MYEGYVIP',[],[]
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def Y3jywo7Lua(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	hHg7JwGuXDfxIVz5kYa1bpjMPA = 'Error: Resolver Failed DAILYMOTION'
	XRvfoBsrKyh06 = SomeI8i56FaDMGPE.findall('"error".*?"messagee":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if XRvfoBsrKyh06: hHg7JwGuXDfxIVz5kYa1bpjMPA = XRvfoBsrKyh06[0]
	url = SomeI8i56FaDMGPE.findall('x-mpegURL","url":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not url and hHg7JwGuXDfxIVz5kYa1bpjMPA:
		return hHg7JwGuXDfxIVz5kYa1bpjMPA,[],[]
	ZcAK0askvzIWr4R = url[0].replace('\\','')
	VyGZnrjdiz,DGcdskjBKixNSwlW5O7rpM = I1IwMGlyuaB9XTe(ZcAK0askvzIWr4R)
	YmaiRV2dCwZnS87U = SomeI8i56FaDMGPE.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if YmaiRV2dCwZnS87U: ytB5J0sVT36Oof,jjKBfUNRoe3G1kwH9JcvxSYnA4,NM8IZ0Udl9BHKsEfzjih = YmaiRV2dCwZnS87U[0]
	else: ytB5J0sVT36Oof,jjKBfUNRoe3G1kwH9JcvxSYnA4,NM8IZ0Udl9BHKsEfzjih = '','',''
	NM8IZ0Udl9BHKsEfzjih = NM8IZ0Udl9BHKsEfzjih.replace('\/','/')
	jjKBfUNRoe3G1kwH9JcvxSYnA4 = c8Fvb4IfHW9XkG1mLK5Z(jjKBfUNRoe3G1kwH9JcvxSYnA4)
	r79xJG6jXHD = ['[COLOR FFC89008]OWNER:  '+jjKBfUNRoe3G1kwH9JcvxSYnA4+'[/COLOR]']+VyGZnrjdiz
	aFyREdMQk7Ys95rX6uJieDGLS2 = [NM8IZ0Udl9BHKsEfzjih]+DGcdskjBKixNSwlW5O7rpM
	I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الملف المناسب: ('+str(len(aFyREdMQk7Ys95rX6uJieDGLS2)-1)+' ملف)',r79xJG6jXHD)
	if I7mfbGiWNFcBVJOn==-1: return 'EXIT_RESOLVER',[],[]
	elif I7mfbGiWNFcBVJOn==0:
		yEcG42CjsFnLRIwmANiYzve513xr = EuOf9ozUdyP.argv[0]+'?type=folder&mode=402&url='+NM8IZ0Udl9BHKsEfzjih+'&textt='+jjKBfUNRoe3G1kwH9JcvxSYnA4
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin("Container.Update("+yEcG42CjsFnLRIwmANiYzve513xr+")")
		return 'EXIT_RESOLVER',[],[]
	ZcAK0askvzIWr4R =  aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	return '',[''],[ZcAK0askvzIWr4R]
def dWvezyn71D(ZcAK0askvzIWr4R):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',ZcAK0askvzIWr4R,'','','','','RESOLVERS-BOKRA-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if '.json' in ZcAK0askvzIWr4R: url = SomeI8i56FaDMGPE.findall('"src":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: url = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def qNYMlAQp3ZLXSw7fFdVchDG(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = SomeI8i56FaDMGPE.findall('direct link.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			QQONb7aR2M6L = SomeI8i56FaDMGPE.findall('class="err">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if QQONb7aR2M6L:
				ztgqWUaDpe8CE9N('','','رسالة من الموقع الاصلي',QQONb7aR2M6L[0])
				return 'Error: '+QQONb7aR2M6L[0],[],[]
	else:
		Fc3PbKsrWIt150De4wYGqmay82X = 'movizland'
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('Form method="POST" action=\'(.*?)\'(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: return 'Error: Resolver Failed MOSHAHDA',[],[]
		spdYctk0fWD1Z = pDTlIgyewF1XV69R8kd[0][0]
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][1]
		if '.rar' in L0Uwx52bTBM or '.zip' in L0Uwx52bTBM: return 'Error: MOSHAHDA Not a video file',[],[]
		items = SomeI8i56FaDMGPE.findall('name="(.*?)".*?value="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		P8AGL4xSd9rWD1Vz = {}
		for CH3VkKb5LiB1cZUsoE,EPwT39HrS1tU6Ng8YBGpJADixzLV5C in items:
			P8AGL4xSd9rWD1Vz[CH3VkKb5LiB1cZUsoE] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		data = iOyTz1Jgbh25fW7NAdE(P8AGL4xSd9rWD1Vz)
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,spdYctk0fWD1Z,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = pDTlIgyewF1XV69R8kd[0][0]
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][1]
		items = SomeI8i56FaDMGPE.findall('file:"(.*?)"(,label:".*?"|)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		aa4L9ehJSUHpOobQnvWsrwFEMl3g,r79xJG6jXHD,ZZsU1qnQxidCg6u,aFyREdMQk7Ys95rX6uJieDGLS2,RbVL3OHN7X = [],[],[],[],[]
		for ZcAK0askvzIWr4R,title in items:
			if '.m3u8' in ZcAK0askvzIWr4R:
				aa4L9ehJSUHpOobQnvWsrwFEMl3g,ZZsU1qnQxidCg6u = I1IwMGlyuaB9XTe(ZcAK0askvzIWr4R)
				aFyREdMQk7Ys95rX6uJieDGLS2 = aFyREdMQk7Ys95rX6uJieDGLS2 + ZZsU1qnQxidCg6u
				if aa4L9ehJSUHpOobQnvWsrwFEMl3g[0]=='-1': r79xJG6jXHD.append(' سيرفر خاص '+'m3u8 '+Fc3PbKsrWIt150De4wYGqmay82X)
				else:
					for title in aa4L9ehJSUHpOobQnvWsrwFEMl3g:
						r79xJG6jXHD.append(' سيرفر خاص '+'m3u8 '+Fc3PbKsrWIt150De4wYGqmay82X+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+Fc3PbKsrWIt150De4wYGqmay82X+' '+title
				r79xJG6jXHD.append(title)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		ZcAK0askvzIWr4R = 'http://moshahda.online' + download
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,ZcAK0askvzIWr4R,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = SomeI8i56FaDMGPE.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for id,lOH3hXsnQiFCRjbN12,hash,p1Ti6cA2L0uU7eJvO in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+Fc3PbKsrWIt150De4wYGqmay82X+' '+p1Ti6cA2L0uU7eJvO.split('x')[1]
			ZcAK0askvzIWr4R = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+lOH3hXsnQiFCRjbN12+'&hash='+hash
			RbVL3OHN7X.append(p1Ti6cA2L0uU7eJvO)
			r79xJG6jXHD.append(title)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		RbVL3OHN7X = set(RbVL3OHN7X)
		N3NHOX6Zgswer512kMzTyP4VDda7o,AepoUEHdm2YaK7lwgxRByZhJ1OkS = [],[]
		for title in r79xJG6jXHD:
			cxaSV0vPI8nh1w = SomeI8i56FaDMGPE.findall(" (\d*x|\d*)&&",title+'&&',SomeI8i56FaDMGPE.DOTALL)
			for p1Ti6cA2L0uU7eJvO in RbVL3OHN7X:
				if cxaSV0vPI8nh1w[0] in p1Ti6cA2L0uU7eJvO:
					title = title.replace(cxaSV0vPI8nh1w[0],p1Ti6cA2L0uU7eJvO.split('x')[1])
			N3NHOX6Zgswer512kMzTyP4VDda7o.append(title)
		for zz5ZOaoyATpS893tvdXE in range(len(aFyREdMQk7Ys95rX6uJieDGLS2)):
			items = SomeI8i56FaDMGPE.findall("&&(.*?)(\d*)&&",'&&'+N3NHOX6Zgswer512kMzTyP4VDda7o[zz5ZOaoyATpS893tvdXE]+'&&',SomeI8i56FaDMGPE.DOTALL)
			AepoUEHdm2YaK7lwgxRByZhJ1OkS.append( [N3NHOX6Zgswer512kMzTyP4VDda7o[zz5ZOaoyATpS893tvdXE],aFyREdMQk7Ys95rX6uJieDGLS2[zz5ZOaoyATpS893tvdXE],items[0][0],items[0][1]] )
		AepoUEHdm2YaK7lwgxRByZhJ1OkS = sorted(AepoUEHdm2YaK7lwgxRByZhJ1OkS, key=lambda IWKVTarP4wnMUtBX6q2185OGHDJ: IWKVTarP4wnMUtBX6q2185OGHDJ[3], reverse=True)
		AepoUEHdm2YaK7lwgxRByZhJ1OkS = sorted(AepoUEHdm2YaK7lwgxRByZhJ1OkS, key=lambda IWKVTarP4wnMUtBX6q2185OGHDJ: IWKVTarP4wnMUtBX6q2185OGHDJ[2], reverse=False)
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
		for zz5ZOaoyATpS893tvdXE in range(len(AepoUEHdm2YaK7lwgxRByZhJ1OkS)):
			r79xJG6jXHD.append(AepoUEHdm2YaK7lwgxRByZhJ1OkS[zz5ZOaoyATpS893tvdXE][0])
			aFyREdMQk7Ys95rX6uJieDGLS2.append(AepoUEHdm2YaK7lwgxRByZhJ1OkS[zz5ZOaoyATpS893tvdXE][1])
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def mja4IdRGzFgrsXWMfAYey86lV1DB(url):
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('?')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = SomeI8i56FaDMGPE.findall('Please wait.*?href=\'(.*?)\'',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def FqW5AxK67eBijVtb3MOpQE4G(url):
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('redirect_url.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: return '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def Q4UtArB7F3hi52MoT8OE6k91qG(url):
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('href","(htt.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: return '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def g4OzlXIh9V(url):
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,errno = [],[],''
	if '/wp-admin/' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
		mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-FAJERSHOW-2nd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		if ppq6Bg4vPbVs.startswith('http'): vfIB6ib8q1hFX5GweRrVPNTjY2E = ppq6Bg4vPbVs
		else:
			XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = SomeI8i56FaDMGPE.findall('''src=['"](.*?)['"]''',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if XuItmjBhoUDa3fRO9nQsbNYrpG1cdv:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv[0]
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = SomeI8i56FaDMGPE.findall('source=(.*?)[&$]',vfIB6ib8q1hFX5GweRrVPNTjY2E,SomeI8i56FaDMGPE.DOTALL)
				if XuItmjBhoUDa3fRO9nQsbNYrpG1cdv:
					vfIB6ib8q1hFX5GweRrVPNTjY2E = aDebGvrkdptunqTM8m4(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv[0])
					return '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	elif '/links/' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		if 'Location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()): vfIB6ib8q1hFX5GweRrVPNTjY2E = ttpgqJBdkoxeKOcwaiP.headers['Location']
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('id="link".*?href="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)[0]
	if '/v/' in vfIB6ib8q1hFX5GweRrVPNTjY2E or '/f/' in vfIB6ib8q1hFX5GweRrVPNTjY2E:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace('/f/','/api/source/')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace('/v/','/api/source/')
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','RESOLVERS-FAJERSHOW-3rd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		items = SomeI8i56FaDMGPE.findall('"file":"(.*?)","label":"(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for ZcAK0askvzIWr4R,title in items:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\\','')
				r79xJG6jXHD.append(title)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		else:
			items = SomeI8i56FaDMGPE.findall('"file":"(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if items:
				ZcAK0askvzIWr4R = items[0]
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\\','')
				r79xJG6jXHD.append('')
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def rJCbLy7F40(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if 'movs4u' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','RESOLVERS-MOVS4U-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="player"(.*?)videojs',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<source src="(.*?)".*?label="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for ZcAK0askvzIWr4R,p5YZ2bOGk7KPuMrD4acHlFUdBCN in items:
				r79xJG6jXHD.append(p5YZ2bOGk7KPuMrD4acHlFUdBCN)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	elif 'main_player.php' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('url=(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','RESOLVERS-MOVS4U-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = SomeI8i56FaDMGPE.findall('"file": "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv[0]
		r79xJG6jXHD.append('')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
	elif 'download_link' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('<center><a href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if vfIB6ib8q1hFX5GweRrVPNTjY2E:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def XnEphROtxM(url):
	website = ZEgwHfRnFV4['CIMACLUB'][0]
	headers = {'Referer':website}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'url')
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('download=.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall("sources: \['(.*?)'",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall("file:'(.*?)'",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]+'|Referer='+website
		return '',[''],[ZcAK0askvzIWr4R]
	if 'name="Xtoken"' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		n9WcYAQjg8G7HD6f1a = SomeI8i56FaDMGPE.findall('name="Xtoken" content="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if n9WcYAQjg8G7HD6f1a:
			ZcAK0askvzIWr4R = n9WcYAQjg8G7HD6f1a[0]
			ZcAK0askvzIWr4R = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(ZcAK0askvzIWr4R)
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.decode('utf8','ignore')
			ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('http.*?(http.*?),',ZcAK0askvzIWr4R,SomeI8i56FaDMGPE.DOTALL)
			if ZcAK0askvzIWr4R:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]+'|Referer='+website
				return '',[''],[ZcAK0askvzIWr4R]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def NT4RbrmaI5(url):
	W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq = [],[]
	if '/1/' in url:
		ZcAK0askvzIWr4R = url.replace('/1/','/4/')
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',ZcAK0askvzIWr4R,'','',False,'','RESOLVERS-EGYBEST1-1st')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<video(.*?)</video>',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?size="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz in items:
				if ZcAK0askvzIWr4R not in TbFRyPoVlrQAw7n3h8BukmfHNq:
					TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
					FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
					W0WLuDcR5UI6K.append(FglT5H2faVGm6IqpcXS9vQsojPLu+'  '+AfejZJoKh4D7k5G1P9gCwxTz)
			return '',W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq
	elif '/d/' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<iframe.*?src="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0].replace('/1/','/4/')
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',ZcAK0askvzIWr4R,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
			ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('class.*?href="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if ZcAK0askvzIWr4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def DDwJuxKcqi(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	data = SomeI8i56FaDMGPE.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if data:
		O8ohzl2GsnQ,id,NsBH5A7cWChe9MymbEZUXilOK4 = data[0]
		data = 'op='+O8ohzl2GsnQ+'&id='+id+'&fname='+NsBH5A7cWChe9MymbEZUXilOK4
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"referer" value="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def rrwJN21upY(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,items,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()): XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = ttpgqJBdkoxeKOcwaiP.headers['Location']
	if 'http' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv:
		if '__watch' in url: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv.replace('/f/','/v/')
		RdP9osXDtelJ = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+RdP9osXDtelJ }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,'',headers,False,'','EGYBEST-PLAY-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		if '/f/' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv: items = SomeI8i56FaDMGPE.findall('<h2>.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		elif '/v/' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv: items = SomeI8i56FaDMGPE.findall('id="video".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def BmKp37VSQA(ZcAK0askvzIWr4R):
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('postid=(.*?)&serverid=(.*?)&&',ZcAK0askvzIWr4R+'&&',SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
	mm6xWVDlReK7d,YcBS69pDzGFTlHE = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+mm6xWVDlReK7d+'&serverid='+YcBS69pDzGFTlHE
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	vfIB6ib8q1hFX5GweRrVPNTjY2E = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
def oFz1gSBjXr(url):
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'url')
	mgDoj8ZAqe0uBLxP4Kzp = {'Referer':FglT5H2faVGm6IqpcXS9vQsojPLu,'Accept-Encoding':'gzip, deflate'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(AlcR9Gvo3QZsLnpfjS,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-MYCIMA-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('player.qualityselector(.*?)formats:',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = ''
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('format: \'(\d.*?)\', src: "(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
		for title,ZcAK0askvzIWr4R in items:
			r79xJG6jXHD.append(title)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		if len(aFyREdMQk7Ys95rX6uJieDGLS2)==1: vfIB6ib8q1hFX5GweRrVPNTjY2E = aFyREdMQk7Ys95rX6uJieDGLS2[0]
		elif len(aFyREdMQk7Ys95rX6uJieDGLS2)>1:
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر الملف المناسب', r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn==-1: return '',[],[]
			vfIB6ib8q1hFX5GweRrVPNTjY2E = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: vfIB6ib8q1hFX5GweRrVPNTjY2E = pDTlIgyewF1XV69R8kd[0]
	if not vfIB6ib8q1hFX5GweRrVPNTjY2E: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
def VxXWc4O2be(url):
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'url')
	mgDoj8ZAqe0uBLxP4Kzp = {'Referer':FglT5H2faVGm6IqpcXS9vQsojPLu,'Accept-Encoding':'gzip, deflate'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(AlcR9Gvo3QZsLnpfjS,'GET',url,'',mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-WECIMA-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('player.qualityselector(.*?)formats:',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = ''
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('format: \'(\d.*?)\', src: "(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
		for title,ZcAK0askvzIWr4R in items:
			r79xJG6jXHD.append(title)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		if len(aFyREdMQk7Ys95rX6uJieDGLS2)==1: vfIB6ib8q1hFX5GweRrVPNTjY2E = aFyREdMQk7Ys95rX6uJieDGLS2[0]
		elif len(aFyREdMQk7Ys95rX6uJieDGLS2)>1:
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر الملف المناسب', r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn==-1: return '',[],[]
			vfIB6ib8q1hFX5GweRrVPNTjY2E = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	if not vfIB6ib8q1hFX5GweRrVPNTjY2E:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: vfIB6ib8q1hFX5GweRrVPNTjY2E = pDTlIgyewF1XV69R8kd[0]
	if not vfIB6ib8q1hFX5GweRrVPNTjY2E: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
def ChqefOL4Mn(ZcAK0askvzIWr4R):
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ZcAK0askvzIWr4R+'&&',SomeI8i56FaDMGPE.DOTALL)
	url,mm6xWVDlReK7d,YcBS69pDzGFTlHE = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
	data = {'post_id':mm6xWVDlReK7d,'server':YcBS69pDzGFTlHE}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('iframe src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
def M9lTLt28So(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<iframe.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		if ZcAK0askvzIWr4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def wHGJb31Nsn(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<IFRAME SRC="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
def QkSEbr6RM7(url):
	nnjrtO4FdM = DRom9hFTZXKuvfr2(url,'url')
	if 'index=' in url:
		headers = {'Referer':nnjrtO4FdM}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if vfIB6ib8q1hFX5GweRrVPNTjY2E:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
			if 'cimanow' in vfIB6ib8q1hFX5GweRrVPNTjY2E:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace('https://','http://')
				ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
				items = SomeI8i56FaDMGPE.findall('source src="(.*?)".*?size="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
				r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
				guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
				for ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz in reversed(items):
					ZcAK0askvzIWr4R = guUzYdHnWLVvGlQA+ZcAK0askvzIWr4R+'|Referer='+guUzYdHnWLVvGlQA
					r79xJG6jXHD.append(AfejZJoKh4D7k5G1P9gCwxTz)
					aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
				return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'|Referer='+nnjrtO4FdM
	return '',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
def oorFGYfOvJmnb(ZcAK0askvzIWr4R):
	nnjrtO4FdM = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'url')
	if 'postid' in ZcAK0askvzIWr4R:
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',ZcAK0askvzIWr4R+'&&',SomeI8i56FaDMGPE.DOTALL)
		url,mm6xWVDlReK7d,YcBS69pDzGFTlHE = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
		data = {'id':mm6xWVDlReK7d,'server':YcBS69pDzGFTlHE}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('iframe src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
		if 'cimanow' in vfIB6ib8q1hFX5GweRrVPNTjY2E:
			headers = {'Referer':nnjrtO4FdM,'User-Agent':''}
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
			items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?size="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
			guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
			for ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz in reversed(items):
				ZcAK0askvzIWr4R = guUzYdHnWLVvGlQA+ZcAK0askvzIWr4R+'|Referer='+guUzYdHnWLVvGlQA
				r79xJG6jXHD.append(AfejZJoKh4D7k5G1P9gCwxTz)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	else:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'|Referer='+nnjrtO4FdM
		return '',[''],[ZcAK0askvzIWr4R]
def YRUMjINH0s(ZcAK0askvzIWr4R):
	if 'postid' in ZcAK0askvzIWr4R:
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('postid=(.*?)&serverid=(.*?)&&',ZcAK0askvzIWr4R+'&&',SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		mm6xWVDlReK7d,YcBS69pDzGFTlHE = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
		yIS3kMN0pU = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'url')
		url = yIS3kMN0pU+'/ajaxCenter?_action=getserver&_post_id='+mm6xWVDlReK7d+'&serverid='+YcBS69pDzGFTlHE
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		vfIB6ib8q1hFX5GweRrVPNTjY2E = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	elif '/redirect/' in ZcAK0askvzIWr4R:
		ZKaC36j9WkcqXeML = 0
		while '/redirect/' in ZcAK0askvzIWr4R and ZKaC36j9WkcqXeML<5:
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',ZcAK0askvzIWr4R,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()): ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['Location']
			ZKaC36j9WkcqXeML += 1
		return '',[''],[ZcAK0askvzIWr4R]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def HBmivPUk2O(url):
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'url')
	headers = {'Referer':FglT5H2faVGm6IqpcXS9vQsojPLu,'User-Agent':W5h0lzIcY3gMqrZpb7C()}
	if '/embed-' in url:
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0].replace('https','http')
			return '',[''],[ZcAK0askvzIWr4R]
	else:
		uz8RdLtEqTs = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = uz8RdLtEqTs.content
		mgDoj8ZAqe0uBLxP4Kzp = headers.copy()
		if '_lnk_' in str(uz8RdLtEqTs.cookies):
			cookies = uz8RdLtEqTs.cookies
			mgDoj8ZAqe0uBLxP4Kzp['Cookie'] = aDebGvrkdptunqTM8m4(iOyTz1Jgbh25fW7NAdE(cookies))
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('link.href = "(http.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not ZcAK0askvzIWr4R: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R[0])+'&d=1'
			RKBm27pOP0frivqSgzwMA58 = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',ZcAK0askvzIWr4R,'',mgDoj8ZAqe0uBLxP4Kzp,'','','RESOLVERS-ARABSEED-4th')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = RKBm27pOP0frivqSgzwMA58.content
			ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('id="btn".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if ZcAK0askvzIWr4R:
				ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R[0])
				if 'mp4' in ZcAK0askvzIWr4R and '/d/' in ZcAK0askvzIWr4R: return '',[''],[ZcAK0askvzIWr4R]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
	return 'Error: Resolver Failed ARABSEED',[],[]
def g3fxlLcTwp(ZcAK0askvzIWr4R):
	if '_action=getserver' in ZcAK0askvzIWr4R:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',ZcAK0askvzIWr4R,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = ttpgqJBdkoxeKOcwaiP.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('postid=(.*?)&serverid=(.*?)$',ZcAK0askvzIWr4R,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		if not u3gUQexlvJM86CS0bXGRBoEFrkZiP: u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('_post_id=(.*?)&serverid=(.*?)$',ZcAK0askvzIWr4R,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		mm6xWVDlReK7d,YcBS69pDzGFTlHE = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
		FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'url')
		url = FglT5H2faVGm6IqpcXS9vQsojPLu+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':mm6xWVDlReK7d,'i':YcBS69pDzGFTlHE}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':ZcAK0askvzIWr4R}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('src="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		if vfIB6ib8q1hFX5GweRrVPNTjY2E:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def j6e3BLUrEVuCqIwnb7Foa2K9QlWg(c9HeXnPxwrOGuMACJvk6):
	p8nUi0haBgymzcY4NX7P = LCIFdjzi5kVmRwehouHQ.getSetting('av.akwam.verification')
	headers = {'Cookie':p8nUi0haBgymzcY4NX7P} if p8nUi0haBgymzcY4NX7P else ''
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',c9HeXnPxwrOGuMACJvk6,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	D13s4oPZ78NUGA = ttpgqJBdkoxeKOcwaiP.content
	VLd40kxiNYhQjf7zBXK9l1S5 = str(ttpgqJBdkoxeKOcwaiP.headers)
	sKYpl24huD8A3JdM = VLd40kxiNYhQjf7zBXK9l1S5+D13s4oPZ78NUGA
	if '.mp4' in sKYpl24huD8A3JdM: y10vlPSzDYb2BA6HJhi = True
	else:
		qXnCUBpERjt,ii1SRMJ8xhIz5yl0Xptb9a,E7eNMImVCKkThd5t9Bap6xR,iS2ePM9xhHYw8fXrE,y10vlPSzDYb2BA6HJhi = '','','','',False
		nUj92G7ZiXk = SomeI8i56FaDMGPE.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',D13s4oPZ78NUGA,SomeI8i56FaDMGPE.DOTALL)
		if nUj92G7ZiXk: E7eNMImVCKkThd5t9Bap6xR,iS2ePM9xhHYw8fXrE = nUj92G7ZiXk[0]
		o7UHhX5YEwa1BS = ZEgwHfRnFV4['PYTHON'][7]
		OjIPm0do31CZ = vT7q0oj96p(32)
		if 0:
			data = {'user':OjIPm0do31CZ,'version':Y0Uhv2t8E67,'url':c9HeXnPxwrOGuMACJvk6,'key':iS2ePM9xhHYw8fXrE,'id':'','job':'geturls'}
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',o7UHhX5YEwa1BS,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ''
		if BsJ71WIxDtdFKveTcRPrqM4Cwb.startswith('URLS='):
			esJu5o91dDibMxQzlfmKR6hAPqyY2 = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('list',BsJ71WIxDtdFKveTcRPrqM4Cwb.split('URLS=',1)[1])
			for ZuCJj5EwDPROkb7UXNypofl in esJu5o91dDibMxQzlfmKR6hAPqyY2:
				url = ZuCJj5EwDPROkb7UXNypofl['url']
				GlzqSCbyxBmVNK = ZuCJj5EwDPROkb7UXNypofl['method']
				data = ZuCJj5EwDPROkb7UXNypofl['data']
				headers = ZuCJj5EwDPROkb7UXNypofl['headers']
				ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,GlzqSCbyxBmVNK,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				D13s4oPZ78NUGA = ttpgqJBdkoxeKOcwaiP.content
				if '.mp4' in D13s4oPZ78NUGA:
					y10vlPSzDYb2BA6HJhi = True
					break
				VLd40kxiNYhQjf7zBXK9l1S5 = str(ttpgqJBdkoxeKOcwaiP.headers)
				sKYpl24huD8A3JdM = VLd40kxiNYhQjf7zBXK9l1S5+D13s4oPZ78NUGA
				qXnCUBpERjt = SomeI8i56FaDMGPE.findall('(akwamVerification\w+).*?"(eyJ.*?)"',sKYpl24huD8A3JdM,SomeI8i56FaDMGPE.DOTALL)
				ii1SRMJ8xhIz5yl0Xptb9a = SomeI8i56FaDMGPE.findall('recaptcha-token.*?"(03A.*?)"',sKYpl24huD8A3JdM,SomeI8i56FaDMGPE.DOTALL)
				if ii1SRMJ8xhIz5yl0Xptb9a: ii1SRMJ8xhIz5yl0Xptb9a = ii1SRMJ8xhIz5yl0Xptb9a[0]
				if qXnCUBpERjt or ii1SRMJ8xhIz5yl0Xptb9a: break
		if not y10vlPSzDYb2BA6HJhi:
			if not qXnCUBpERjt:
				if not ii1SRMJ8xhIz5yl0Xptb9a and nUj92G7ZiXk:
					if 1 and not BsJ71WIxDtdFKveTcRPrqM4Cwb.startswith('ID='):
						data = {'user':OjIPm0do31CZ,'version':Y0Uhv2t8E67,'url':c9HeXnPxwrOGuMACJvk6,'key':iS2ePM9xhHYw8fXrE,'id':'','job':'getid'}
						ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',o7UHhX5YEwa1BS,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
						BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
					else: BsJ71WIxDtdFKveTcRPrqM4Cwb = 'ID=1234::::TIMEOUT=45'
					if BsJ71WIxDtdFKveTcRPrqM4Cwb.startswith('ID='):
						FJ54Nv7RKftrlBDVIEA0ykwTiWs6e = SomeI8i56FaDMGPE.findall('ID=(.*?)::::TIMEOUT=(.*?)$',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
						zYE1tw8Vq2IdF9H6Ps0bRTGn43K,Egi7k41QIqDK6NouH = FJ54Nv7RKftrlBDVIEA0ykwTiWs6e[0]
						QQONb7aR2M6L = 'هذه العملية تحتاج وقت من 10 إلى '+Egi7k41QIqDK6NouH+' ثانية'
						IIheUfDrYngWFbdtjxvpPyN8 = AAGT9IPy4BoZN7()
						IIheUfDrYngWFbdtjxvpPyN8.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',QQONb7aR2M6L)
						R2Urlzo59WKO = p1BoraOuWL.time()
						eQ5sRmu9XKvHqNGlhdV,YDiFzGqLtws6 = 0,0
						while eQ5sRmu9XKvHqNGlhdV<int(Egi7k41QIqDK6NouH):
							AYqVCTWQcUuB18DzLR97OtHo(IIheUfDrYngWFbdtjxvpPyN8,int(eQ5sRmu9XKvHqNGlhdV/int(Egi7k41QIqDK6NouH)*100),QQONb7aR2M6L,'',Egi7k41QIqDK6NouH+' / '+str(int(eQ5sRmu9XKvHqNGlhdV))+'  ثانية')
							if eQ5sRmu9XKvHqNGlhdV>YDiFzGqLtws6+10:
								data = {'user':OjIPm0do31CZ,'version':Y0Uhv2t8E67,'url':c9HeXnPxwrOGuMACJvk6,'key':iS2ePM9xhHYw8fXrE,'id':zYE1tw8Vq2IdF9H6Ps0bRTGn43K,'job':'gettoken'}
								ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',o7UHhX5YEwa1BS,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
								BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
								if BsJ71WIxDtdFKveTcRPrqM4Cwb.startswith('TOKEN='):
									ii1SRMJ8xhIz5yl0Xptb9a = BsJ71WIxDtdFKveTcRPrqM4Cwb.split('TOKEN=',1)[1]
									break
								YDiFzGqLtws6 = eQ5sRmu9XKvHqNGlhdV
							else: p1BoraOuWL.sleep(1)
							eQ5sRmu9XKvHqNGlhdV = p1BoraOuWL.time()-R2Urlzo59WKO
						IIheUfDrYngWFbdtjxvpPyN8.close()
				if ii1SRMJ8xhIz5yl0Xptb9a:
					TYb9KMyqD0rAliRJhcInaEFOjLN = ttpgqJBdkoxeKOcwaiP.cookies
					XIaUAzCwD0HqcNGWM7Jpn6l39vRo = SomeI8i56FaDMGPE.findall('akwam_session=(.*?);',sKYpl24huD8A3JdM,SomeI8i56FaDMGPE.DOTALL)
					if 'akwam_session' in list(TYb9KMyqD0rAliRJhcInaEFOjLN.keys()): XIaUAzCwD0HqcNGWM7Jpn6l39vRo = TYb9KMyqD0rAliRJhcInaEFOjLN['akwam_session']
					elif XIaUAzCwD0HqcNGWM7Jpn6l39vRo: XIaUAzCwD0HqcNGWM7Jpn6l39vRo = XIaUAzCwD0HqcNGWM7Jpn6l39vRo[0]
					nUj92G7ZiXk = SomeI8i56FaDMGPE.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',D13s4oPZ78NUGA,SomeI8i56FaDMGPE.DOTALL)
					if nUj92G7ZiXk: E7eNMImVCKkThd5t9Bap6xR,iS2ePM9xhHYw8fXrE = nUj92G7ZiXk[0]
					if XIaUAzCwD0HqcNGWM7Jpn6l39vRo and nUj92G7ZiXk:
						headers = {'Cookie':'akwam_session='+XIaUAzCwD0HqcNGWM7Jpn6l39vRo,'Referer':c9HeXnPxwrOGuMACJvk6,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+ii1SRMJ8xhIz5yl0Xptb9a
						ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'POST',E7eNMImVCKkThd5t9Bap6xR,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						D13s4oPZ78NUGA = ttpgqJBdkoxeKOcwaiP.content
						try: cookies = ttpgqJBdkoxeKOcwaiP.cookies
						except: cookies = {}
						qXnCUBpERjt = SomeI8i56FaDMGPE.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),SomeI8i56FaDMGPE.DOTALL)
			if qXnCUBpERjt:
				CH3VkKb5LiB1cZUsoE,qXnCUBpERjt = qXnCUBpERjt[0]
				p8nUi0haBgymzcY4NX7P = CH3VkKb5LiB1cZUsoE+'='+qXnCUBpERjt
				LCIFdjzi5kVmRwehouHQ.setSetting('av.akwam.verification',p8nUi0haBgymzcY4NX7P)
				ztgqWUaDpe8CE9N('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in D13s4oPZ78NUGA:
					headers = {'Cookie':p8nUi0haBgymzcY4NX7P}
					ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',c9HeXnPxwrOGuMACJvk6,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					D13s4oPZ78NUGA = ttpgqJBdkoxeKOcwaiP.content
	if not y10vlPSzDYb2BA6HJhi and not p8nUi0haBgymzcY4NX7P: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','عملية فحص أنا أنسان فشلت .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return D13s4oPZ78NUGA
def vfhp39d4er(url,type,AfejZJoKh4D7k5G1P9gCwxTz):
	TbFRyPoVlrQAw7n3h8BukmfHNq,W0WLuDcR5UI6K = [],[]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
	UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('<a href=".*?</a>',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in ZZHhmdtY1g:
			if ZcAK0askvzIWr4R in TbFRyPoVlrQAw7n3h8BukmfHNq: continue
			if '/watch/' not in ZcAK0askvzIWr4R and '/download/' not in ZcAK0askvzIWr4R: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
			W0WLuDcR5UI6K.append(title)
	if len(TbFRyPoVlrQAw7n3h8BukmfHNq)>1:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('بعضها يحتاج 60 ثانية',W0WLuDcR5UI6K)
		if I7mfbGiWNFcBVJOn==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(TbFRyPoVlrQAw7n3h8BukmfHNq)==1: I7mfbGiWNFcBVJOn = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	c9HeXnPxwrOGuMACJvk6 = TbFRyPoVlrQAw7n3h8BukmfHNq[I7mfbGiWNFcBVJOn]
	D13s4oPZ78NUGA = j6e3BLUrEVuCqIwnb7Foa2K9QlWg(c9HeXnPxwrOGuMACJvk6)
	aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD = [],[]
	if type=='download':
		GMyVSk1PDEAgO = SomeI8i56FaDMGPE.findall('btn-loader.*?href="(.*?)"',D13s4oPZ78NUGA,SomeI8i56FaDMGPE.DOTALL)
		if GMyVSk1PDEAgO:
			ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(GMyVSk1PDEAgO[0])
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			r79xJG6jXHD.append(AfejZJoKh4D7k5G1P9gCwxTz)
	elif type=='watch':
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('<source.*?src="(.*?)".*?size="(.*?)"',D13s4oPZ78NUGA,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,size in ZZHhmdtY1g:
			if not ZcAK0askvzIWr4R: continue
			if AfejZJoKh4D7k5G1P9gCwxTz in size:
				r79xJG6jXHD.append(size)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
				break
		if not aFyREdMQk7Ys95rX6uJieDGLS2:
			for ZcAK0askvzIWr4R,size in ZZHhmdtY1g:
				if not ZcAK0askvzIWr4R: continue
				r79xJG6jXHD.append(size)
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if not aFyREdMQk7Ys95rX6uJieDGLS2: return 'Error: Resolver Failed AKWAM',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def xuBOFde24X(url,CH3VkKb5LiB1cZUsoE):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	cookies = ttpgqJBdkoxeKOcwaiP.cookies
	if 'golink' in list(cookies.keys()):
		p8nUi0haBgymzcY4NX7P = cookies['golink']
		p8nUi0haBgymzcY4NX7P = aDebGvrkdptunqTM8m4(c8Fvb4IfHW9XkG1mLK5Z(p8nUi0haBgymzcY4NX7P))
		items = SomeI8i56FaDMGPE.findall('route":"(.*?)"',p8nUi0haBgymzcY4NX7P,SomeI8i56FaDMGPE.DOTALL)
		vfIB6ib8q1hFX5GweRrVPNTjY2E = items[0].replace('\/','/')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = c8Fvb4IfHW9XkG1mLK5Z(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
	if 'catch.is' in vfIB6ib8q1hFX5GweRrVPNTjY2E:
		id = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('%2F')[-1]
		vfIB6ib8q1hFX5GweRrVPNTjY2E = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[vfIB6ib8q1hFX5GweRrVPNTjY2E]
	else:
		website = ZEgwHfRnFV4['AKOAM'][0]
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		jBni6QP0f41vJwCXOWu = ttpgqJBdkoxeKOcwaiP.url
		gyMF6kIrYSQT4OzLfJeCZvR7 = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('/')[2]
		Onwi4vjc03b = jBni6QP0f41vJwCXOWu.split('/')[2]
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace(gyMF6kIrYSQT4OzLfJeCZvR7,Onwi4vjc03b)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':XuItmjBhoUDa3fRO9nQsbNYrpG1cdv }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST', XuItmjBhoUDa3fRO9nQsbNYrpG1cdv, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		items = SomeI8i56FaDMGPE.findall('direct_link":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		if not items:
			items = SomeI8i56FaDMGPE.findall('<iframe.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
			if not items:
				items = SomeI8i56FaDMGPE.findall('<embed.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		if items:
			ZcAK0askvzIWr4R = items[0].replace('\/','/')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.rstrip('/')
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:' + ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('http://','https://')
			if CH3VkKb5LiB1cZUsoE=='': hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '',[''],[ZcAK0askvzIWr4R]
			else: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = 'NEED_EXTERNAL_RESOLVERS',[''],[ZcAK0askvzIWr4R]
		else: hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = 'Error: Resolver Failed AKOAM',[],[]
		return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def Mx746y9KWizTAabd3Q(url):
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = SomeI8i56FaDMGPE.findall('<source src="(.*?)".*?label="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2,errno = [],[],''
	if items:
		for ZcAK0askvzIWr4R,p5YZ2bOGk7KPuMrD4acHlFUdBCN in items:
			r79xJG6jXHD.append(p5YZ2bOGk7KPuMrD4acHlFUdBCN)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def cLOj0h7ogDU6SJGsEdwQ3aTl(url):
	headers = {'User-Agent':''}
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = SomeI8i56FaDMGPE.findall('sources: \["(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def B9qVtGcmih8sSnexAgjoT6O(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('\\','')
	items = SomeI8i56FaDMGPE.findall('file":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def mm0BywIhQN1xkpj5UVAdE3uJz2YLK(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-VIDOZA-1st')
	items = SomeI8i56FaDMGPE.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	for ZcAK0askvzIWr4R,p5YZ2bOGk7KPuMrD4acHlFUdBCN,cxaSV0vPI8nh1w in items:
		r79xJG6jXHD.append(p5YZ2bOGk7KPuMrD4acHlFUdBCN+' '+cxaSV0vPI8nh1w)
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def q1qTitM53YpoD4dlZsnrEkIQXJSAe0(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = SomeI8i56FaDMGPE.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	items = set(items)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	for id,lOH3hXsnQiFCRjbN12,hash,p5YZ2bOGk7KPuMrD4acHlFUdBCN,cxaSV0vPI8nh1w in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+lOH3hXsnQiFCRjbN12+'&hash='+hash
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = SomeI8i56FaDMGPE.findall('direct link.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in items:
			r79xJG6jXHD.append(p5YZ2bOGk7KPuMrD4acHlFUdBCN+' '+cxaSV0vPI8nh1w)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if len(aFyREdMQk7Ys95rX6uJieDGLS2)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def nStie7hYMxvq1LP(url):
	ZcAK0askvzIWr4R = ''
	if 1 or 'Key=' not in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('upbom.live','uppom.live')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('/')
		id = vfIB6ib8q1hFX5GweRrVPNTjY2E[3]
		vfIB6ib8q1hFX5GweRrVPNTjY2E = '/'.join(vfIB6ib8q1hFX5GweRrVPNTjY2E[0:4])
		P8AGL4xSd9rWD1Vz = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,P8AGL4xSd9rWD1Vz,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()): ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['Location']
		if not ZcAK0askvzIWr4R and ttpgqJBdkoxeKOcwaiP.succeeded:
			BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
			ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('id="direct_link".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(ttpgqJBdkoxeKOcwaiP.headers.keys()): ZcAK0askvzIWr4R = ttpgqJBdkoxeKOcwaiP.headers['location']
	if ZcAK0askvzIWr4R: return '',[''],[ZcAK0askvzIWr4R]
	return 'Error: Resolver Failed UPBOM',[],[]
def TiDnEJbQmol4c(url):
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = SomeI8i56FaDMGPE.findall('sources:.*?"(.*?)","(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	if items:
		r79xJG6jXHD.append('mp4')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(items[0][1])
		r79xJG6jXHD.append('m3u8')
		aFyREdMQk7Ys95rX6uJieDGLS2.append(items[0][0])
		return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def tHSNcldqrQ(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = ZEgwHfRnFV4['YOUTUBE'][0]+'/watch?v='+id
	TNKkyhJWA219c3iQgpE = 'http://youtu.be/'+id
	BMr1uaYKIpqgz36y9clv4,qVrY0SPskm,UoiTQIAcw9gKOZ8fHFMhlGeuNm,OOrGxwbDU3Rzc4TVY8 = '','','',''
	for jUSuZAztxy34TB5CIP2 in range(5):
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','RESOLVERS-YOUTUBE-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		if 'itag' in BsJ71WIxDtdFKveTcRPrqM4Cwb: break
		p1BoraOuWL.sleep(2)
	YY0QqVKEhGunm2O19HRrMjyBcv = SomeI8i56FaDMGPE.findall('var ytInitialPlayerResponse = (.*?);</script>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if YY0QqVKEhGunm2O19HRrMjyBcv: YY0QqVKEhGunm2O19HRrMjyBcv = YY0QqVKEhGunm2O19HRrMjyBcv[0]
	else: YY0QqVKEhGunm2O19HRrMjyBcv = BsJ71WIxDtdFKveTcRPrqM4Cwb
	YY0QqVKEhGunm2O19HRrMjyBcv = YY0QqVKEhGunm2O19HRrMjyBcv.replace('\\u0026','&')
	cF0hVt1jBeOKXkz2HaM = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',YY0QqVKEhGunm2O19HRrMjyBcv)
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = ['بدون ترجمة يوتيوب'],['']
	try:
		XhSPwK73sg95Tj = cF0hVt1jBeOKXkz2HaM['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for DHF9vEjWGd57UnOXMscoy in XhSPwK73sg95Tj:
			ZcAK0askvzIWr4R = DHF9vEjWGd57UnOXMscoy['baseUrl']
			try: title = DHF9vEjWGd57UnOXMscoy['name']['simpleText']
			except: title = DHF9vEjWGd57UnOXMscoy['name']['runs'][0]['textt']
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			r79xJG6jXHD.append(title)
	except: pass
	if len(r79xJG6jXHD)>1:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الترجمة المناسبة:', r79xJG6jXHD)
		if I7mfbGiWNFcBVJOn==-1: return 'EXIT_RESOLVER',[],[]
		elif I7mfbGiWNFcBVJOn!=0:
			ZcAK0askvzIWr4R = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]+'&'
			uwNGYxSdJDLbX58M = SomeI8i56FaDMGPE.findall('&(fmt=.*?)&',ZcAK0askvzIWr4R)
			if uwNGYxSdJDLbX58M: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace(uwNGYxSdJDLbX58M[0],'fmt=vtt')
			else: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'fmt=vtt'
			BMr1uaYKIpqgz36y9clv4 = ZcAK0askvzIWr4R.strip('&')
	dQgEjSn7fP2b,QDEeg0Fw3MRZOdWXVyJpU2j,NzfxPsBSOCZL6ltuG3AKE5I,qJ1spl5KObRXSUd4aF7L3hGYT,nKqlE0oFQY = [],[],[],[],[]
	try: qVrY0SPskm = cF0hVt1jBeOKXkz2HaM['streamingData']['dashManifestUrl']
	except: pass
	try: UoiTQIAcw9gKOZ8fHFMhlGeuNm = cF0hVt1jBeOKXkz2HaM['streamingData']['hlsManifestUrl']
	except: pass
	try: dQgEjSn7fP2b = cF0hVt1jBeOKXkz2HaM['streamingData']['formats']
	except: pass
	try: QDEeg0Fw3MRZOdWXVyJpU2j = cF0hVt1jBeOKXkz2HaM['streamingData']['adaptiveFormats']
	except: pass
	IVhbQ5igcH = dQgEjSn7fP2b+QDEeg0Fw3MRZOdWXVyJpU2j
	for dict in IVhbQ5igcH:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			nFdI9RtPgvMOz0a5 = dict['signatureCipher'].split('&')
			for MMeFJKLQG4HdIwObZ1l9 in nFdI9RtPgvMOz0a5:
				key,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=',1)
				dict[key] = aDebGvrkdptunqTM8m4(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if 'url' in list(dict.keys()): dict['url'] = aDebGvrkdptunqTM8m4(dict['url'])
		NzfxPsBSOCZL6ltuG3AKE5I.append(dict)
	ys4YA3IXb50VRtcF = ''
	if 'sp=sig' in YY0QqVKEhGunm2O19HRrMjyBcv:
		woa70ml21e38MXbBWZrj = SomeI8i56FaDMGPE.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if woa70ml21e38MXbBWZrj:
			woa70ml21e38MXbBWZrj = ZEgwHfRnFV4['YOUTUBE'][0]+woa70ml21e38MXbBWZrj[0]
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',woa70ml21e38MXbBWZrj,'','','','','RESOLVERS-YOUTUBE-2nd')
			ys4YA3IXb50VRtcF = ttpgqJBdkoxeKOcwaiP.content
			import youtube_signature.cipher as qyWAj5XwblEnJg8Cfh7ts0uie,youtube_signature.json_script_engine as WTF053LxQ6qGrtCVO4sdpe
			nFdI9RtPgvMOz0a5 = vbPRVcTLpl4.nFdI9RtPgvMOz0a5.Cipher()
			nFdI9RtPgvMOz0a5._object_cache = {}
			r3E0HyCKGWAvSFna1Qkgsox5qBP2Lp = nFdI9RtPgvMOz0a5._load_javascript(ys4YA3IXb50VRtcF)
			MMYIjSl5f2PiQJA1emVOkdREg = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',str(r3E0HyCKGWAvSFna1Qkgsox5qBP2Lp))
			nnLFXVGEDwU3v60hpYr = vbPRVcTLpl4.H58HNmGzPJYAT7KyDgs6vbuF.JsonScriptEngine(MMYIjSl5f2PiQJA1emVOkdREg)
	for dict in NzfxPsBSOCZL6ltuG3AKE5I:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			qJ1spl5KObRXSUd4aF7L3hGYT.append(dict)
		elif ys4YA3IXb50VRtcF and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			Q9wg8bzGVFeY = nnLFXVGEDwU3v60hpYr.execute(dict['s'])
			if Q9wg8bzGVFeY!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+Q9wg8bzGVFeY
				qJ1spl5KObRXSUd4aF7L3hGYT.append(dict)
	for dict in qJ1spl5KObRXSUd4aF7L3hGYT:
		CxhvM0I7d3kcrD9aeTBESPG,VpquZlJaTtEQOKxcC952GFPediBYH4,AEZ593FKoXIzuSMwD,C4CEWLV96T8Dwzd,y1bsUHd9keIPm,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = 'unknown','unknown','unknown','Unknown','','0'
		try:
			o374wczInB2R = dict['type']
			o374wczInB2R = o374wczInB2R.replace('+','')
			items = SomeI8i56FaDMGPE.findall('(.*?)/(.*?);.*?"(.*?)"',o374wczInB2R,SomeI8i56FaDMGPE.DOTALL)
			C4CEWLV96T8Dwzd,CxhvM0I7d3kcrD9aeTBESPG,y1bsUHd9keIPm = items[0]
			E2ZiuI8RKhwSD6vqgsz = y1bsUHd9keIPm.split(',')
			VpquZlJaTtEQOKxcC952GFPediBYH4 = ''
			for MMeFJKLQG4HdIwObZ1l9 in E2ZiuI8RKhwSD6vqgsz: VpquZlJaTtEQOKxcC952GFPediBYH4 += MMeFJKLQG4HdIwObZ1l9.split('.')[0]+','
			VpquZlJaTtEQOKxcC952GFPediBYH4 = VpquZlJaTtEQOKxcC952GFPediBYH4.strip(',')
			if 'bitrate' in list(dict.keys()): Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = ''
			if C4CEWLV96T8Dwzd=='textt': continue
			elif ',' in o374wczInB2R:
				C4CEWLV96T8Dwzd = 'A+V'
				AEZ593FKoXIzuSMwD = CxhvM0I7d3kcrD9aeTBESPG+'  '+Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl+dict['size'].split('x')[1]
			elif C4CEWLV96T8Dwzd=='video':
				C4CEWLV96T8Dwzd = 'Video'
				AEZ593FKoXIzuSMwD = Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+CxhvM0I7d3kcrD9aeTBESPG
			elif C4CEWLV96T8Dwzd=='audio':
				C4CEWLV96T8Dwzd = 'Audio'
				AEZ593FKoXIzuSMwD = Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+CxhvM0I7d3kcrD9aeTBESPG
		except:
			zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
			if zi68Y9T7ngdIXKALbv3fjVEeOJm!='NoneType: None\n': EuOf9ozUdyP.stderr.write(zi68Y9T7ngdIXKALbv3fjVEeOJm)
		if 'dur=' in dict['url']: DD1IVWFZbr7TlzYto5s = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): DD1IVWFZbr7TlzYto5s = round(0.5+float(dict['approxDurationMs'])/1000)
		else: DD1IVWFZbr7TlzYto5s = '0'
		if 'bitrate' not in list(dict.keys()): Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = dict['size'].split('x')[1]
		else: Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = C4CEWLV96T8Dwzd+':  '+AEZ593FKoXIzuSMwD+'  ('+VpquZlJaTtEQOKxcC952GFPediBYH4+','+dict['itag']+')'
		dict['quality'] = AEZ593FKoXIzuSMwD.split('  ')[0].split('kbps')[0]
		dict['type2'] = C4CEWLV96T8Dwzd
		dict['filetype'] = CxhvM0I7d3kcrD9aeTBESPG
		dict['codecs'] = y1bsUHd9keIPm
		dict['duration'] = DD1IVWFZbr7TlzYto5s
		dict['bitrate'] = Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl
		nKqlE0oFQY.append(dict)
	vHb29mza0n53Oo,hDZLqQ5TjJ,VIrqhJ0BTcCvjOu,AXphdq6sgJFyQmKoxz,wsmp6I1d5lntYNrCG3 = [],[],[],[],[]
	zf9qEYygnFXbhHICLKexWoNUQRB,AAZfvLSwxJ3Xadu,pDzAsgLXSriya7u629Eo4KQclOJNdm,llTfRK0p5Avg1rwNIdqYsX3D,TYnModumQy5baXc0fSe = [],[],[],[],[]
	if qVrY0SPskm:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = qVrY0SPskm
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		nKqlE0oFQY.append(dict)
	if UoiTQIAcw9gKOZ8fHFMhlGeuNm:
		aa4L9ehJSUHpOobQnvWsrwFEMl3g,ZZsU1qnQxidCg6u = I1IwMGlyuaB9XTe(UoiTQIAcw9gKOZ8fHFMhlGeuNm)
		kkQSzwsxAV9hGRC6OvqPKnatHrcWUF = list(zip(aa4L9ehJSUHpOobQnvWsrwFEMl3g,ZZsU1qnQxidCg6u))
		for title,ZcAK0askvzIWr4R in kkQSzwsxAV9hGRC6OvqPKnatHrcWUF:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = ZcAK0askvzIWr4R
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				AfejZJoKh4D7k5G1P9gCwxTz = title.rsplit('  ')[-3]
				if AfejZJoKh4D7k5G1P9gCwxTz.isdigit(): dict['quality'] = AfejZJoKh4D7k5G1P9gCwxTz
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			nKqlE0oFQY.append(dict)
	nKqlE0oFQY = sorted(nKqlE0oFQY,reverse=True,key=lambda key: float(key['bitrate']))
	if not nKqlE0oFQY:
		Bro7jZXa2qAFulQW9IkPL = SomeI8i56FaDMGPE.findall('class="messagee">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		yQMg7VfFNB4l9UcpqiX = SomeI8i56FaDMGPE.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		p2sfgbe9xhl3JXnkLc = SomeI8i56FaDMGPE.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		KXHul4UAnW = SomeI8i56FaDMGPE.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		try: ftK0R1imCykY6nrH = cF0hVt1jBeOKXkz2HaM['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: ftK0R1imCykY6nrH = ''
		try: w9w1i4Fq7sPxO5jSURAEg0CQLM = cF0hVt1jBeOKXkz2HaM['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: w9w1i4Fq7sPxO5jSURAEg0CQLM = ''
		try: ILfNSgT8h1JAtD429BmsUK = cF0hVt1jBeOKXkz2HaM['playabilityStatus']['reason']
		except: ILfNSgT8h1JAtD429BmsUK = ''
		if Bro7jZXa2qAFulQW9IkPL or yQMg7VfFNB4l9UcpqiX or p2sfgbe9xhl3JXnkLc or KXHul4UAnW or ftK0R1imCykY6nrH or w9w1i4Fq7sPxO5jSURAEg0CQLM or ILfNSgT8h1JAtD429BmsUK:
			if   Bro7jZXa2qAFulQW9IkPL: QQONb7aR2M6L = Bro7jZXa2qAFulQW9IkPL[0]
			elif yQMg7VfFNB4l9UcpqiX: QQONb7aR2M6L = yQMg7VfFNB4l9UcpqiX[0]
			elif p2sfgbe9xhl3JXnkLc: QQONb7aR2M6L = p2sfgbe9xhl3JXnkLc[0]
			elif KXHul4UAnW: QQONb7aR2M6L = KXHul4UAnW[0]
			elif ftK0R1imCykY6nrH: QQONb7aR2M6L = ftK0R1imCykY6nrH
			elif w9w1i4Fq7sPxO5jSURAEg0CQLM: QQONb7aR2M6L = w9w1i4Fq7sPxO5jSURAEg0CQLM
			elif ILfNSgT8h1JAtD429BmsUK: QQONb7aR2M6L = ILfNSgT8h1JAtD429BmsUK
			ePR0K8Va4S2QWsJIjZYUTGl1Ni = QQONb7aR2M6L.replace('\n','').strip(' ')
			UOjEabqGCguLDry = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			ztgqWUaDpe8CE9N('','','رسالة من الموقع والمبرمج',UOjEabqGCguLDry+'\n\n'+ePR0K8Va4S2QWsJIjZYUTGl1Ni)
			return 'Error    : Resolver YOUTUBE Failed: '+ePR0K8Va4S2QWsJIjZYUTGl1Ni,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	YtXT2UvRW78dyFjzerCoQKsm015k,SS17hIFw6jYods,GQoalbVFrU4TpW1XcMKx2SqZz5m = [],[],[]
	for dict in nKqlE0oFQY:
		if dict['type2']=='Video':
			vHb29mza0n53Oo.append(dict['title'])
			zf9qEYygnFXbhHICLKexWoNUQRB.append(dict)
		elif dict['type2']=='Audio':
			hDZLqQ5TjJ.append(dict['title'])
			AAZfvLSwxJ3Xadu.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = '0'
			else: Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = dict['bitrate']
			YtXT2UvRW78dyFjzerCoQKsm015k.append([dict,{},title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = '0'
			else: Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = dict['bitrate']
			YtXT2UvRW78dyFjzerCoQKsm015k.append([dict,{},title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl])
			VIrqhJ0BTcCvjOu.append(title)
			pDzAsgLXSriya7u629Eo4KQclOJNdm.append(dict)
		WWkRbwTnFr = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: WWkRbwTnFr = False
			elif Qf8xsJSwoKaUNc<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: WWkRbwTnFr = False
		if dict['type2']=='Video' and dict['init']!='0-0' and WWkRbwTnFr==True:
			wsmp6I1d5lntYNrCG3.append(dict['title'])
			TYnModumQy5baXc0fSe.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and WWkRbwTnFr==True:
			AXphdq6sgJFyQmKoxz.append(dict['title'])
			llTfRK0p5Avg1rwNIdqYsX3D.append(dict)
	for eGtvziUgj1PWYEu3p in llTfRK0p5Avg1rwNIdqYsX3D:
		z3GEIVLPrT6dp9JujnRAscgftQ = eGtvziUgj1PWYEu3p['bitrate']
		for MMjfPAvteHU7I0xlaz5 in TYnModumQy5baXc0fSe:
			viGU27TXpjLzqh1scrWuColmwB = MMjfPAvteHU7I0xlaz5['bitrate']
			Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl = viGU27TXpjLzqh1scrWuColmwB+z3GEIVLPrT6dp9JujnRAscgftQ
			title = MMjfPAvteHU7I0xlaz5['title'].replace('Video:  ','mpd  ')
			title = title.replace(MMjfPAvteHU7I0xlaz5['filetype']+'  ','')
			title = title.replace(str((float(viGU27TXpjLzqh1scrWuColmwB*10)//1024/10))+'kbps',str((float(Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl*10)//1024/10))+'kbps')
			title = title+'('+eGtvziUgj1PWYEu3p['title'].split('(',1)[1]
			YtXT2UvRW78dyFjzerCoQKsm015k.append([MMjfPAvteHU7I0xlaz5,eGtvziUgj1PWYEu3p,title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl])
	YtXT2UvRW78dyFjzerCoQKsm015k = sorted(YtXT2UvRW78dyFjzerCoQKsm015k, reverse=True, key=lambda key: float(key[3]))
	for MMjfPAvteHU7I0xlaz5,eGtvziUgj1PWYEu3p,title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl in YtXT2UvRW78dyFjzerCoQKsm015k:
		WPNbDuHZ3CxsGJ8Fh = MMjfPAvteHU7I0xlaz5['filetype']
		if 'filetype' in list(eGtvziUgj1PWYEu3p.keys()):
			WPNbDuHZ3CxsGJ8Fh = 'mpd'
		if WPNbDuHZ3CxsGJ8Fh not in GQoalbVFrU4TpW1XcMKx2SqZz5m:
			GQoalbVFrU4TpW1XcMKx2SqZz5m.append(WPNbDuHZ3CxsGJ8Fh)
			SS17hIFw6jYods.append([MMjfPAvteHU7I0xlaz5,eGtvziUgj1PWYEu3p,title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl])
	gg47cflqAL6ZMXOone,aVYuINwlUDzipOcngK,FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx = [],[],0
	jjKBfUNRoe3G1kwH9JcvxSYnA4,ZgDC71oXHzFBqhM6fJplmjuW8a = '',''
	try: jjKBfUNRoe3G1kwH9JcvxSYnA4 = cF0hVt1jBeOKXkz2HaM['videoDetails']['author']
	except: jjKBfUNRoe3G1kwH9JcvxSYnA4 = ''
	try: JzpbmEhqvl3kcG = cF0hVt1jBeOKXkz2HaM['videoDetails']['channelId']
	except: JzpbmEhqvl3kcG = ''
	if jjKBfUNRoe3G1kwH9JcvxSYnA4 and JzpbmEhqvl3kcG:
		FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx += 1
		title = '[COLOR FFC89008]OWNER:  '+jjKBfUNRoe3G1kwH9JcvxSYnA4+'[/COLOR]'
		ZcAK0askvzIWr4R = ZEgwHfRnFV4['YOUTUBE'][0]+'/channel/'+JzpbmEhqvl3kcG
		gg47cflqAL6ZMXOone.append(title)
		aVYuINwlUDzipOcngK.append(ZcAK0askvzIWr4R)
		try: ZgDC71oXHzFBqhM6fJplmjuW8a = cF0hVt1jBeOKXkz2HaM['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for MMjfPAvteHU7I0xlaz5,eGtvziUgj1PWYEu3p,title,Yv0tm9GJpxQ2TIbycoZzDUX86F3Kl in SS17hIFw6jYods:
		gg47cflqAL6ZMXOone.append(title) ; aVYuINwlUDzipOcngK.append('highest')
	if VIrqhJ0BTcCvjOu: gg47cflqAL6ZMXOone.append('صورة وصوت محددة') ; aVYuINwlUDzipOcngK.append('muxed')
	if YtXT2UvRW78dyFjzerCoQKsm015k: gg47cflqAL6ZMXOone.append('صورة وصوت المتوفر') ; aVYuINwlUDzipOcngK.append('all')
	if wsmp6I1d5lntYNrCG3: gg47cflqAL6ZMXOone.append('mpd اختر الصورة والصوت') ; aVYuINwlUDzipOcngK.append('mpd')
	if vHb29mza0n53Oo: gg47cflqAL6ZMXOone.append('صورة بدون صوت') ; aVYuINwlUDzipOcngK.append('video')
	if hDZLqQ5TjJ: gg47cflqAL6ZMXOone.append('صوت بدون صورة') ; aVYuINwlUDzipOcngK.append('audio')
	O5zikR8ZpEaXDvgyQC7st1KofSeJ4B = False
	while True:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X(TNKkyhJWA219c3iQgpE, gg47cflqAL6ZMXOone)
		if I7mfbGiWNFcBVJOn==-1: return 'EXIT_RESOLVER',[],[]
		elif I7mfbGiWNFcBVJOn==0 and jjKBfUNRoe3G1kwH9JcvxSYnA4:
			ZcAK0askvzIWr4R = aVYuINwlUDzipOcngK[I7mfbGiWNFcBVJOn]
			yEcG42CjsFnLRIwmANiYzve513xr = EuOf9ozUdyP.argv[0]+'?type=folder&mode=141&name='+TbEVs6mLPHF(jjKBfUNRoe3G1kwH9JcvxSYnA4)+'&url='+ZcAK0askvzIWr4R
			if ZgDC71oXHzFBqhM6fJplmjuW8a: yEcG42CjsFnLRIwmANiYzve513xr = yEcG42CjsFnLRIwmANiYzve513xr+'&image='+TbEVs6mLPHF(ZgDC71oXHzFBqhM6fJplmjuW8a)
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin("Container.Update("+yEcG42CjsFnLRIwmANiYzve513xr+")")
			return 'EXIT_RESOLVER',[],[]
		U94D8BejHMsrLzO27IRpFEhC6wP = aVYuINwlUDzipOcngK[I7mfbGiWNFcBVJOn]
		p7ox3Z5eXbclAtqOwTiCj = gg47cflqAL6ZMXOone[I7mfbGiWNFcBVJOn]
		if U94D8BejHMsrLzO27IRpFEhC6wP=='dash':
			OOrGxwbDU3Rzc4TVY8 = qVrY0SPskm
			break
		elif U94D8BejHMsrLzO27IRpFEhC6wP in ['audio','video','muxed']:
			if U94D8BejHMsrLzO27IRpFEhC6wP=='muxed': r79xJG6jXHD,Bkad92ZqszQV7w5Ku0WISe = VIrqhJ0BTcCvjOu,pDzAsgLXSriya7u629Eo4KQclOJNdm
			elif U94D8BejHMsrLzO27IRpFEhC6wP=='video': r79xJG6jXHD,Bkad92ZqszQV7w5Ku0WISe = vHb29mza0n53Oo,zf9qEYygnFXbhHICLKexWoNUQRB
			elif U94D8BejHMsrLzO27IRpFEhC6wP=='audio': r79xJG6jXHD,Bkad92ZqszQV7w5Ku0WISe = hDZLqQ5TjJ,AAZfvLSwxJ3Xadu
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الملف المناسب:', r79xJG6jXHD)
			if I7mfbGiWNFcBVJOn!=-1:
				OOrGxwbDU3Rzc4TVY8 = Bkad92ZqszQV7w5Ku0WISe[I7mfbGiWNFcBVJOn]['url']
				p7ox3Z5eXbclAtqOwTiCj = r79xJG6jXHD[I7mfbGiWNFcBVJOn]
				break
		elif U94D8BejHMsrLzO27IRpFEhC6wP=='mpd':
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر جودة الصورة:', wsmp6I1d5lntYNrCG3)
			if I7mfbGiWNFcBVJOn!=-1:
				p7ox3Z5eXbclAtqOwTiCj = wsmp6I1d5lntYNrCG3[I7mfbGiWNFcBVJOn]
				wbzrUgMFjBK7aSTyfN34O9pcZmlG = TYnModumQy5baXc0fSe[I7mfbGiWNFcBVJOn]
				I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر جودة الصوت:', AXphdq6sgJFyQmKoxz)
				if I7mfbGiWNFcBVJOn!=-1:
					p7ox3Z5eXbclAtqOwTiCj += ' + '+AXphdq6sgJFyQmKoxz[I7mfbGiWNFcBVJOn]
					qQHXGvtkiJUl4Dx89s = llTfRK0p5Avg1rwNIdqYsX3D[I7mfbGiWNFcBVJOn]
					O5zikR8ZpEaXDvgyQC7st1KofSeJ4B = True
					break
		elif U94D8BejHMsrLzO27IRpFEhC6wP=='all':
			tEARWdPwesr9VGy2Up7k3M,YDiIfXrCbUK0V5oQEcR1zs,drRI6kj5XObVta,wu0NUzBtPeLM = list(zip(*YtXT2UvRW78dyFjzerCoQKsm015k))
			I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الملف المناسب:', drRI6kj5XObVta)
			if I7mfbGiWNFcBVJOn!=-1:
				p7ox3Z5eXbclAtqOwTiCj = drRI6kj5XObVta[I7mfbGiWNFcBVJOn]
				wbzrUgMFjBK7aSTyfN34O9pcZmlG = tEARWdPwesr9VGy2Up7k3M[I7mfbGiWNFcBVJOn]
				if 'mpd' in drRI6kj5XObVta[I7mfbGiWNFcBVJOn] and wbzrUgMFjBK7aSTyfN34O9pcZmlG['url']!=qVrY0SPskm:
					qQHXGvtkiJUl4Dx89s = YDiIfXrCbUK0V5oQEcR1zs[I7mfbGiWNFcBVJOn]
					O5zikR8ZpEaXDvgyQC7st1KofSeJ4B = True
				else: OOrGxwbDU3Rzc4TVY8 = wbzrUgMFjBK7aSTyfN34O9pcZmlG['url']
				break
		elif U94D8BejHMsrLzO27IRpFEhC6wP=='highest':
			tEARWdPwesr9VGy2Up7k3M,YDiIfXrCbUK0V5oQEcR1zs,drRI6kj5XObVta,wu0NUzBtPeLM = list(zip(*SS17hIFw6jYods))
			wbzrUgMFjBK7aSTyfN34O9pcZmlG = tEARWdPwesr9VGy2Up7k3M[I7mfbGiWNFcBVJOn-FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx]
			if 'mpd' in drRI6kj5XObVta[I7mfbGiWNFcBVJOn-FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx] and wbzrUgMFjBK7aSTyfN34O9pcZmlG['url']!=qVrY0SPskm:
				qQHXGvtkiJUl4Dx89s = YDiIfXrCbUK0V5oQEcR1zs[I7mfbGiWNFcBVJOn-FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx]
				O5zikR8ZpEaXDvgyQC7st1KofSeJ4B = True
			else: OOrGxwbDU3Rzc4TVY8 = wbzrUgMFjBK7aSTyfN34O9pcZmlG['url']
			p7ox3Z5eXbclAtqOwTiCj = drRI6kj5XObVta[I7mfbGiWNFcBVJOn-FE7Dkt0RdPiynGmrXZQwKhOgeIqHlx]
			break
	if not O5zikR8ZpEaXDvgyQC7st1KofSeJ4B: X0Lz3y5xmeFMCrEJNwZ8PA = OOrGxwbDU3Rzc4TVY8
	else: X0Lz3y5xmeFMCrEJNwZ8PA = 'Video: '+wbzrUgMFjBK7aSTyfN34O9pcZmlG['url']+' + Audio: '+qQHXGvtkiJUl4Dx89s['url']
	if O5zikR8ZpEaXDvgyQC7st1KofSeJ4B:
		bgWplkaKIYRcf5 = int(wbzrUgMFjBK7aSTyfN34O9pcZmlG['duration'])
		SKWthsjw1k = int(qQHXGvtkiJUl4Dx89s['duration'])
		DD1IVWFZbr7TlzYto5s = str(max(bgWplkaKIYRcf5,SKWthsjw1k))
		Q7NlPGvqDE8wynH1guKA6L5OaY4MeT = wbzrUgMFjBK7aSTyfN34O9pcZmlG['url'].replace('&','&amp;')
		oq8RcQIfD9dMmabhJt2W35XOeK = qQHXGvtkiJUl4Dx89s['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+DD1IVWFZbr7TlzYto5s+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['itag']+'" codecs="'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['codecs']+'" startWithSAP="1" bandwidth="'+str(wbzrUgMFjBK7aSTyfN34O9pcZmlG['bitrate'])+'" width="'+str(wbzrUgMFjBK7aSTyfN34O9pcZmlG['width'])+'" height="'+str(wbzrUgMFjBK7aSTyfN34O9pcZmlG['height'])+'" frameRate="'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['fps']+'">\n'
		mpd += '<BaseURL>'+Q7NlPGvqDE8wynH1guKA6L5OaY4MeT+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['index']+'">\n'
		mpd += '<Initialization range="'+wbzrUgMFjBK7aSTyfN34O9pcZmlG['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+qQHXGvtkiJUl4Dx89s['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+qQHXGvtkiJUl4Dx89s['itag']+'" codecs="'+qQHXGvtkiJUl4Dx89s['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+qQHXGvtkiJUl4Dx89s['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+oq8RcQIfD9dMmabhJt2W35XOeK+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+qQHXGvtkiJUl4Dx89s['index']+'">\n'
		mpd += '<Initialization range="'+qQHXGvtkiJUl4Dx89s['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if ZZxLpCcmqhyT6NuMWelkbSvr0H:
			import http.server as GEKodqiQR0uOfyAb4XJrl
			import http.client as D8byvBrQLReSzMpWInl2gXfoacGu
		else:
			import BaseHTTPServer as GEKodqiQR0uOfyAb4XJrl
			import httplib as D8byvBrQLReSzMpWInl2gXfoacGu
		class PrxtewgjnQoE(GEKodqiQR0uOfyAb4XJrl.HTTPServer):
			def __init__(F1HBpuELn7R93OrxvqI,ip='localhost',port=55055,mpd='<>'):
				F1HBpuELn7R93OrxvqI.ip = ip
				F1HBpuELn7R93OrxvqI.port = port
				F1HBpuELn7R93OrxvqI.mpd = mpd
				GEKodqiQR0uOfyAb4XJrl.HTTPServer.__init__(F1HBpuELn7R93OrxvqI,(F1HBpuELn7R93OrxvqI.ip,F1HBpuELn7R93OrxvqI.port),ll2kmMPnehvwTG5sNdA0RYt4K)
				F1HBpuELn7R93OrxvqI.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.threads = jIoHl6d5pfVXu(False)
				F1HBpuELn7R93OrxvqI.threads.FghEzWo26wCTxOYmsAQPl9d(1,F1HBpuELn7R93OrxvqI.sWLl31XhxT6CH9vi)
			def sWLl31XhxT6CH9vi(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.keeprunning = True
				while F1HBpuELn7R93OrxvqI.keeprunning:
					F1HBpuELn7R93OrxvqI.handle_request()
			def stop(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.keeprunning = False
				F1HBpuELn7R93OrxvqI.JSBgRX169vPoAZurC5()
			def U9Zk5Xt7jovSQDwdcGPHJm(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.stop()
				F1HBpuELn7R93OrxvqI.g8dpaPZ3iLGyrxW51eXFKjcqCUD9uS.close()
				F1HBpuELn7R93OrxvqI.server_close()
			def BPmpnaARDyX(F1HBpuELn7R93OrxvqI,mpd):
				F1HBpuELn7R93OrxvqI.mpd = mpd
			def JSBgRX169vPoAZurC5(F1HBpuELn7R93OrxvqI):
				Iof8U0xDKbVslWATpzR4OvBe9 = D8byvBrQLReSzMpWInl2gXfoacGu.HTTPConnection(F1HBpuELn7R93OrxvqI.ip+':'+str(F1HBpuELn7R93OrxvqI.port))
				Iof8U0xDKbVslWATpzR4OvBe9.request("HEAD", "/")
		class ll2kmMPnehvwTG5sNdA0RYt4K(GEKodqiQR0uOfyAb4XJrl.BaseHTTPRequestHandler):
			def qsy8pbBxUVZCO3JFweiPaKcjhrfNd(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.send_response(200)
				F1HBpuELn7R93OrxvqI.send_header('Content-type','textt/plain')
				F1HBpuELn7R93OrxvqI.end_headers()
				F1HBpuELn7R93OrxvqI.wfile.write(F1HBpuELn7R93OrxvqI.FglT5H2faVGm6IqpcXS9vQsojPLu.mpd.encode('utf8'))
				p1BoraOuWL.sleep(1)
				if F1HBpuELn7R93OrxvqI.path=='/youtube.mpd': F1HBpuELn7R93OrxvqI.FglT5H2faVGm6IqpcXS9vQsojPLu.U9Zk5Xt7jovSQDwdcGPHJm()
				if F1HBpuELn7R93OrxvqI.path=='/shutdown': F1HBpuELn7R93OrxvqI.FglT5H2faVGm6IqpcXS9vQsojPLu.U9Zk5Xt7jovSQDwdcGPHJm()
			def TwkPHM7nWfzOJ8DxXvU5iZaYmb0ue(F1HBpuELn7R93OrxvqI):
				F1HBpuELn7R93OrxvqI.send_response(200)
				F1HBpuELn7R93OrxvqI.end_headers()
		iTZJ7smKIA5EvUORp = PrxtewgjnQoE('127.0.0.1',55055,mpd)
		OOrGxwbDU3Rzc4TVY8 = iTZJ7smKIA5EvUORp.mpdurl
		iTZJ7smKIA5EvUORp.start()
	else: iTZJ7smKIA5EvUORp = ''
	if not OOrGxwbDU3Rzc4TVY8: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[OOrGxwbDU3Rzc4TVY8,BMr1uaYKIpqgz36y9clv4,iTZJ7smKIA5EvUORp]]
def as5vKcmMO4wXYn8r27qH1oepQTVfFB(url):
	headers = { 'User-Agent' : '' }
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = SomeI8i56FaDMGPE.findall('file:"(.*?)"(,label:"(.*?)"|)\}',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	aa4L9ehJSUHpOobQnvWsrwFEMl3g,r79xJG6jXHD,ZZsU1qnQxidCg6u,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for ZcAK0askvzIWr4R,fYZzomwSjkedXVcEvLDqKHMt9rFnN,p5YZ2bOGk7KPuMrD4acHlFUdBCN in items:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('https:','http:')
		if '.m3u8' in ZcAK0askvzIWr4R:
			aa4L9ehJSUHpOobQnvWsrwFEMl3g,ZZsU1qnQxidCg6u = I1IwMGlyuaB9XTe(ZcAK0askvzIWr4R)
			aFyREdMQk7Ys95rX6uJieDGLS2 = aFyREdMQk7Ys95rX6uJieDGLS2 + ZZsU1qnQxidCg6u
			if aa4L9ehJSUHpOobQnvWsrwFEMl3g[0]=='-1': r79xJG6jXHD.append('سيرفر خاص'+'   m3u8')
			else:
				for title in aa4L9ehJSUHpOobQnvWsrwFEMl3g:
					r79xJG6jXHD.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+p5YZ2bOGk7KPuMrD4acHlFUdBCN
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			r79xJG6jXHD.append(title)
	return '',r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def rLlNXGEyZQWjFw3ahPoAtm7c0zD(url,BsJ71WIxDtdFKveTcRPrqM4Cwb):
	W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq,nEXl8y9AGFROx6TiaUBcgWqNo,AH37UN2zyfhutGmL4JkajnF9eT,ZZHhmdtY1g = [],[],[],[],[]
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<video preload.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('direct_link.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		title = ZcAK0askvzIWr4R.rsplit('.',1)[1]
		W0WLuDcR5UI6K.append(title)
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	else:
		UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('sources: *(\[.*?\])',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not UUTVrGP7Y31a: UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('var sources = (\{.*?\})',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not UUTVrGP7Y31a: UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('var jw = (\{.*?\})',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not UUTVrGP7Y31a: UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('var player = .*?\((\{.*?\})\)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if UUTVrGP7Y31a:
			UUTVrGP7Y31a = UUTVrGP7Y31a[0]
			Qc569LKX7dbsvy82F = SomeI8i56FaDMGPE.findall('[,\{] *(\w+):',UUTVrGP7Y31a,SomeI8i56FaDMGPE.DOTALL)
			for key in list(set(Qc569LKX7dbsvy82F)): UUTVrGP7Y31a = UUTVrGP7Y31a.replace(key+':','"'+key+'":')
			UUTVrGP7Y31a = eval(UUTVrGP7Y31a)
			if isinstance(UUTVrGP7Y31a,dict): UUTVrGP7Y31a = [UUTVrGP7Y31a]
			for L0Uwx52bTBM in UUTVrGP7Y31a:
				if isinstance(L0Uwx52bTBM,dict):
					keys = list(L0Uwx52bTBM.keys())
					if 'file' in keys: ZcAK0askvzIWr4R = L0Uwx52bTBM['file']
					elif 'hls' in keys: ZcAK0askvzIWr4R = L0Uwx52bTBM['hls']
					if 'label' in keys: title = str(L0Uwx52bTBM['label'])
					elif 'video_height' in keys: title = str(L0Uwx52bTBM['video_height'])
					else: title = ZcAK0askvzIWr4R.rsplit('.',1)[1]
				elif isinstance(L0Uwx52bTBM,str):
					ZcAK0askvzIWr4R = L0Uwx52bTBM
					title = ZcAK0askvzIWr4R.rsplit('.',1)[1]
				W0WLuDcR5UI6K.append(title)
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	for ZcAK0askvzIWr4R,title in zip(TbFRyPoVlrQAw7n3h8BukmfHNq,W0WLuDcR5UI6K):
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\\/','/')
		LF56ulcIz2kYqE83Cf = DRom9hFTZXKuvfr2(url,'url')
		Jhilqrw8nstB7 = W5h0lzIcY3gMqrZpb7C()
		if '.m3u8' in ZcAK0askvzIWr4R:
			headers = {'User-Agent':Jhilqrw8nstB7,'Referer':LF56ulcIz2kYqE83Cf}
			L0KswXDp5cg,v35nsWzfAoeJxYR = I1IwMGlyuaB9XTe(ZcAK0askvzIWr4R,headers)
			AH37UN2zyfhutGmL4JkajnF9eT += v35nsWzfAoeJxYR
			nEXl8y9AGFROx6TiaUBcgWqNo += L0KswXDp5cg
		else:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'|User-Agent='+Jhilqrw8nstB7+'&Referer='+LF56ulcIz2kYqE83Cf
			AH37UN2zyfhutGmL4JkajnF9eT.append(ZcAK0askvzIWr4R)
			nEXl8y9AGFROx6TiaUBcgWqNo.append(title)
	hHg7JwGuXDfxIVz5kYa1bpjMPA,W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq = '',[],[]
	if AH37UN2zyfhutGmL4JkajnF9eT: hHg7JwGuXDfxIVz5kYa1bpjMPA,W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq = '',nEXl8y9AGFROx6TiaUBcgWqNo,AH37UN2zyfhutGmL4JkajnF9eT
	else:
		if '<' not in BsJ71WIxDtdFKveTcRPrqM4Cwb and len(BsJ71WIxDtdFKveTcRPrqM4Cwb)<100 and BsJ71WIxDtdFKveTcRPrqM4Cwb: hHg7JwGuXDfxIVz5kYa1bpjMPA = BsJ71WIxDtdFKveTcRPrqM4Cwb
		else:
			msg = SomeI8i56FaDMGPE.findall('<div style=".*?">(File.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if not msg: msg = SomeI8i56FaDMGPE.findall('<div class="vp_video_stub_txt">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if not msg: msg = SomeI8i56FaDMGPE.findall('<h2>(Sorry.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if msg: hHg7JwGuXDfxIVz5kYa1bpjMPA = msg[0]
	return hHg7JwGuXDfxIVz5kYa1bpjMPA,W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq
def oV6Kb4FWNXOUS(ru9lfSKCahDL5Ix0YGJneT8w,url):
	global UbKtImf1i7LOpVlB
	url = url.strip('/')
	NTpDCUuRGVc,P8AGL4xSd9rWD1Vz = '',{}
	headers = {'User-Agent':W5h0lzIcY3gMqrZpb7C(),'Accept-Language':'en-US,en;q=0.9'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	HVgyklbi72tJQ = ttpgqJBdkoxeKOcwaiP.code
	if not isinstance(BsJ71WIxDtdFKveTcRPrqM4Cwb,str): BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		H9fQyK5nmW8c4LgvpG7 = SomeI8i56FaDMGPE.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if H9fQyK5nmW8c4LgvpG7:
			try: NTpDCUuRGVc = CVW8t72PJBfeiaTrxdNv0(H9fQyK5nmW8c4LgvpG7[0])
			except: NTpDCUuRGVc = ''
	ppq6Bg4vPbVs = BsJ71WIxDtdFKveTcRPrqM4Cwb+NTpDCUuRGVc
	if '"id2"' in ppq6Bg4vPbVs or '"id"' in ppq6Bg4vPbVs:
		ccIGQxOMUpWiXsFYK2R8a = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in ppq6Bg4vPbVs: P8AGL4xSd9rWD1Vz = {'id2':ccIGQxOMUpWiXsFYK2R8a,'op':'download2'}
		elif '"id"' in ppq6Bg4vPbVs: P8AGL4xSd9rWD1Vz = {'id':ccIGQxOMUpWiXsFYK2R8a,'op':'download2'}
		mgDoj8ZAqe0uBLxP4Kzp = headers.copy()
		mgDoj8ZAqe0uBLxP4Kzp['Content-Type'] = 'application/x-www-form-urlencoded'
		RKBm27pOP0frivqSgzwMA58 = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',url,P8AGL4xSd9rWD1Vz,mgDoj8ZAqe0uBLxP4Kzp,'',False,'RESOLVERS-XSHARING-2nd')
		ppq6Bg4vPbVs = RKBm27pOP0frivqSgzwMA58.content
	cb0khytrvgEnsRNZ3xF7eoSwB58,zpIHdQ65GKO2c0khmL8q3,f9AMOqsjzXkv06colw1nKYZby = rLlNXGEyZQWjFw3ahPoAtm7c0zD(url,ppq6Bg4vPbVs)
	UbKtImf1i7LOpVlB[ru9lfSKCahDL5Ix0YGJneT8w] = cb0khytrvgEnsRNZ3xF7eoSwB58,zpIHdQ65GKO2c0khmL8q3,f9AMOqsjzXkv06colw1nKYZby,HVgyklbi72tJQ
	return
UbKtImf1i7LOpVlB,tkwMAZpFiE8Yv0GSP61g = {},0
def gUc4iXZjWDydLHNYnCJxMwF3t(url):
	global UbKtImf1i7LOpVlB,tkwMAZpFiE8Yv0GSP61g
	ZZHhmdtY1g,threads = [],[]
	tkwMAZpFiE8Yv0GSP61g += 100
	ned8KI9ENk4orHmFbOhf = tkwMAZpFiE8Yv0GSP61g
	ZZHhmdtY1g.append([1,url])
	UbKtImf1i7LOpVlB[ned8KI9ENk4orHmFbOhf+1] = [None,None,None,None]
	EEA9jhB5ZPMfJ = RrCB5k9XV6hYNSlIKJ2.Thread(target=oV6Kb4FWNXOUS,args=(ned8KI9ENk4orHmFbOhf+1,url))
	EEA9jhB5ZPMfJ.start()
	EEA9jhB5ZPMfJ.join(10)
	if not UbKtImf1i7LOpVlB[ned8KI9ENk4orHmFbOhf+1][2]:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/embed-','/')
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = SomeI8i56FaDMGPE.findall('^(.*?://.*?)/(.*?)/(.*?)$',vfIB6ib8q1hFX5GweRrVPNTjY2E+'/',SomeI8i56FaDMGPE.DOTALL)
		start,kWXbZD6LuQyMJfCv7H9ljEOnchV0dS,end = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
		end = end.strip('/')
		vDQ5TaV1bn9AluqLm = len(kWXbZD6LuQyMJfCv7H9ljEOnchV0dS)<4 or kWXbZD6LuQyMJfCv7H9ljEOnchV0dS in ['file','video','videoembed']
		if not vDQ5TaV1bn9AluqLm: ZZHhmdtY1g.append([2,start+'/embed-'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/'+end])
		if end: ZZHhmdtY1g.append([3,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/embed-'+end])
		if '.html' in kWXbZD6LuQyMJfCv7H9ljEOnchV0dS:
			qvLUurFPasjTlJX = kWXbZD6LuQyMJfCv7H9ljEOnchV0dS.replace('.html','')
			ZZHhmdtY1g.append([4,start+'/'+qvLUurFPasjTlJX+'/'+end])
			ZZHhmdtY1g.append([5,start+'/embed-'+qvLUurFPasjTlJX+'/'+end])
			if end: ZZHhmdtY1g.append([6,start+'/'+qvLUurFPasjTlJX+'/embed-'+end])
		elif '.html' in end:
			vV6ZUxjlb3RyoC = end.replace('.html','')
			ZZHhmdtY1g.append([7,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/'+vV6ZUxjlb3RyoC])
			if not vDQ5TaV1bn9AluqLm: ZZHhmdtY1g.append([8,start+'/embed-'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/'+vV6ZUxjlb3RyoC])
			ZZHhmdtY1g.append([9,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/embed-'+vV6ZUxjlb3RyoC])
		else:
			if not vDQ5TaV1bn9AluqLm: ZZHhmdtY1g.append([10,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'.html'])
			if not vDQ5TaV1bn9AluqLm: ZZHhmdtY1g.append([11,start+'/embed-'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'.html'])
			if end: ZZHhmdtY1g.append([12,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/'+end+'.html'])
			if end: ZZHhmdtY1g.append([13,start+'/'+kWXbZD6LuQyMJfCv7H9ljEOnchV0dS+'/embed-'+end+'.html'])
		if vDQ5TaV1bn9AluqLm and end:
			end = end.replace('/embed-','/')
			ZZHhmdtY1g.append([14,start+'/'+end])
			ZZHhmdtY1g.append([15,start+'/embed-'+end])
			if '.html' in end:
				vV6ZUxjlb3RyoC = end.replace('.html','')
				ZZHhmdtY1g.append([16,start+'/'+vV6ZUxjlb3RyoC])
				ZZHhmdtY1g.append([17,start+'/embed-'+vV6ZUxjlb3RyoC])
			else:
				ZZHhmdtY1g.append([18,start+'/'+end+'.html'])
				ZZHhmdtY1g.append([19,start+'/embed-'+end+'.html'])
		for iBI9R4HkNw6pZvdqMtGTjnUEXulhxy,ZcAK0askvzIWr4R in ZZHhmdtY1g[1:]:
			UbKtImf1i7LOpVlB[ned8KI9ENk4orHmFbOhf+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy] = [None,None,None,None]
			EEA9jhB5ZPMfJ = RrCB5k9XV6hYNSlIKJ2.Thread(target=oV6Kb4FWNXOUS,args=(ned8KI9ENk4orHmFbOhf+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy,ZcAK0askvzIWr4R))
			EEA9jhB5ZPMfJ.start()
			p1BoraOuWL.sleep(0.5)
			threads.append(EEA9jhB5ZPMfJ)
		for EEA9jhB5ZPMfJ in threads: EEA9jhB5ZPMfJ.join(10)
	hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = '',[],[]
	Jsr7lSQNYF1gf0 = []
	for iBI9R4HkNw6pZvdqMtGTjnUEXulhxy,ZcAK0askvzIWr4R in ZZHhmdtY1g:
		FKT9rWdsokV8xalQ,NIiZom2VP3Q8vRCYFJMXwc7E6rfuHk,Tx9cAkJNfvYgmnW75L,SS9J2ndW01j6iF = UbKtImf1i7LOpVlB[ned8KI9ENk4orHmFbOhf+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy]
		if not aFyREdMQk7Ys95rX6uJieDGLS2 and Tx9cAkJNfvYgmnW75L: r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = NIiZom2VP3Q8vRCYFJMXwc7E6rfuHk,Tx9cAkJNfvYgmnW75L
		if not hHg7JwGuXDfxIVz5kYa1bpjMPA and FKT9rWdsokV8xalQ: hHg7JwGuXDfxIVz5kYa1bpjMPA = FKT9rWdsokV8xalQ
		if SS9J2ndW01j6iF: Jsr7lSQNYF1gf0.append(SS9J2ndW01j6iF)
	Jsr7lSQNYF1gf0 = list(set(Jsr7lSQNYF1gf0))
	if not hHg7JwGuXDfxIVz5kYa1bpjMPA and len(Jsr7lSQNYF1gf0)==1:
		HVgyklbi72tJQ = Jsr7lSQNYF1gf0[0]
		if HVgyklbi72tJQ!=200:
			if HVgyklbi72tJQ<0: hHg7JwGuXDfxIVz5kYa1bpjMPA = 'Video page/server is not accessible'
			else:
				hHg7JwGuXDfxIVz5kYa1bpjMPA = 'HTTP Error: '+str(HVgyklbi72tJQ)
				if ZZxLpCcmqhyT6NuMWelkbSvr0H: import http.client as D8byvBrQLReSzMpWInl2gXfoacGu
				else: import httplib as D8byvBrQLReSzMpWInl2gXfoacGu
				hHg7JwGuXDfxIVz5kYa1bpjMPA += ' ( '+D8byvBrQLReSzMpWInl2gXfoacGu.responses[HVgyklbi72tJQ]+' )'
	p1BoraOuWL.sleep(1)
	return hHg7JwGuXDfxIVz5kYa1bpjMPA,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2
def pW2J8N9V5nxoGuCLy4Bb(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = SomeI8i56FaDMGPE.findall('color="red">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def aVKcbyQrfIqmURs5(url):
	return '',[''],[ url ]
def EW7zXIsfvdRipxK1boegcLFuH85(url):
	FglT5H2faVGm6IqpcXS9vQsojPLu = url.split('/')
	BD9Ur1hxEen5fdsz6I2 = '/'.join(FglT5H2faVGm6IqpcXS9vQsojPLu[0:3])
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = SomeI8i56FaDMGPE.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,ozslnOGQXvf2c10AWw9NLy,TLWs37IZYxGk0clSQ2t1,bnELflK1svIiZFzSCh4jVJNY,LdA9snZJEOi8rwzm1VC2IcQpujtq4 = items[0]
		kuywHRSrgAUlWN0C7svj94ZOm6 = int(v7vlUSFEWZs8Bd5) % int(ozslnOGQXvf2c10AWw9NLy) + int(TLWs37IZYxGk0clSQ2t1) % int(bnELflK1svIiZFzSCh4jVJNY)
		url = BD9Ur1hxEen5fdsz6I2 + ZUshXQ1nwIHbLMP + str(kuywHRSrgAUlWN0C7svj94ZOm6) + LdA9snZJEOi8rwzm1VC2IcQpujtq4
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def P10srT7zKdSlH5bWRMvtVwC(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	P8AGL4xSd9rWD1Vz = { "id":id , "op":"download2" }
	ZuCJj5EwDPROkb7UXNypofl = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST', url, P8AGL4xSd9rWD1Vz, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(ZuCJj5EwDPROkb7UXNypofl.headers.keys()): ZcAK0askvzIWr4R = ZuCJj5EwDPROkb7UXNypofl.headers['Location']
	else: ZcAK0askvzIWr4R = url
	if ZcAK0askvzIWr4R: return '',[''],[ZcAK0askvzIWr4R]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def rnLybOwsYl2AhCIc16qTP(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = SomeI8i56FaDMGPE.findall('mp4: \[\'(.*?)\'',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def hXJPoEBedi0x7MLD2IgAlKjzT(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def ruM3AxawHI6G2KBFyZDnjhtkLsQJ(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'','','','RESOLVERS-ESTREAM-1st')
	items = SomeI8i56FaDMGPE.findall('video preload.*?src=.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
AdKBOaFs5gt3RoNkwLj = 'M3U'
T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB = '_M3U_'
H56tOjf2BZNiSCUKYsozXA4gdvGuxR = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
ooH4RO9l3nDvcds2zLf1x = 4
def PLhWMCuV7DtB(lOH3hXsnQiFCRjbN12,eesaHQO5yPGNvopTtWzR,yy42JUqszVIO89i,jPqMvmNDgsYiWUyxo,B2Axl9aIWKdUXNTEtc0YjCR5yPF,AFbdWemQRHznuiv60):
	global T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB
	try:
		mOEzG4cJoV9erugyXbLI = str(AFbdWemQRHznuiv60['folder'])
		T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB = '_MU'+mOEzG4cJoV9erugyXbLI+'_'
	except: mOEzG4cJoV9erugyXbLI = ''
	try: mutkxRodSEY0l8DJVAP = str(AFbdWemQRHznuiv60['sequence'])
	except: mutkxRodSEY0l8DJVAP = ''
	if   lOH3hXsnQiFCRjbN12==710: EIBNGzDg8LUe4w = zHeSkTAta5W7wnEQ1FpP()
	elif lOH3hXsnQiFCRjbN12==711: EIBNGzDg8LUe4w = kGUQdpiLTEWPezxKDv9hNAf(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP)
	elif lOH3hXsnQiFCRjbN12==712: EIBNGzDg8LUe4w = snxaPmhUME(mOEzG4cJoV9erugyXbLI)
	elif lOH3hXsnQiFCRjbN12==713: EIBNGzDg8LUe4w = KksoXzFiaIwnRqQZSWUm03HpBtxV(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,yy42JUqszVIO89i,B2Axl9aIWKdUXNTEtc0YjCR5yPF)
	elif lOH3hXsnQiFCRjbN12==714: EIBNGzDg8LUe4w = rum8gIeCX3hYq(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,yy42JUqszVIO89i,B2Axl9aIWKdUXNTEtc0YjCR5yPF)
	elif lOH3hXsnQiFCRjbN12==715: EIBNGzDg8LUe4w = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,jPqMvmNDgsYiWUyxo)
	elif lOH3hXsnQiFCRjbN12==716: EIBNGzDg8LUe4w = viLtfVUqM9ewyB6THCDdcx2nKW(mOEzG4cJoV9erugyXbLI,True)
	elif lOH3hXsnQiFCRjbN12==717: EIBNGzDg8LUe4w = bfBW9emaQpcn2r1IUKy(mOEzG4cJoV9erugyXbLI,True)
	elif lOH3hXsnQiFCRjbN12==718: EIBNGzDg8LUe4w = Kw1iOYJ2rxy80BlWteICmN7fTd5Dp(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==719: EIBNGzDg8LUe4w = YnCWskJzK9IRacANQ0UgZ(yy42JUqszVIO89i,mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,B2Axl9aIWKdUXNTEtc0YjCR5yPF)
	elif lOH3hXsnQiFCRjbN12==720: EIBNGzDg8LUe4w = f8i6KDmBoAz(mOEzG4cJoV9erugyXbLI,True)
	elif lOH3hXsnQiFCRjbN12==721: EIBNGzDg8LUe4w = u7fDqHj4N8(mOEzG4cJoV9erugyXbLI)
	elif lOH3hXsnQiFCRjbN12==722: EIBNGzDg8LUe4w = E1ECNJ4Wyowu(mOEzG4cJoV9erugyXbLI)
	elif lOH3hXsnQiFCRjbN12==723: EIBNGzDg8LUe4w = nsa2PZqyOTQrlIeULSfhvwbt(mOEzG4cJoV9erugyXbLI)
	elif lOH3hXsnQiFCRjbN12==726: EIBNGzDg8LUe4w = QH4l09LW7Jp(mOEzG4cJoV9erugyXbLI)
	elif lOH3hXsnQiFCRjbN12==729: EIBNGzDg8LUe4w = EvJm4oHYlu0FLe7AUi1Ws8MCaGq(yy42JUqszVIO89i,mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,B2Axl9aIWKdUXNTEtc0YjCR5yPF)
	else: EIBNGzDg8LUe4w = False
	return EIBNGzDg8LUe4w
def zHeSkTAta5W7wnEQ1FpP():
	for mOEzG4cJoV9erugyXbLI in range(1,gx4WbX9yDPm6lk+1):
		T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB = '_MU'+str(mOEzG4cJoV9erugyXbLI)+'_'
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قائمة مجلد '+h6OYx3P5fiRXg2LoBK8[mOEzG4cJoV9erugyXbLI],'',720,'','','','',{'folder':mOEzG4cJoV9erugyXbLI})
	return
def f8i6KDmBoAz(mOEzG4cJoV9erugyXbLI='',SKyG3D4CgRJW7qArbhHljzi6Q=''):
	if mOEzG4cJoV9erugyXbLI:
		zqcM7fgPCU06VDQXSLounbr4vEFe9T = {'folder':mOEzG4cJoV9erugyXbLI}
		NNnMxcRFDbEiuB3LzYoGa8XhsCrT = ''
	else:
		zqcM7fgPCU06VDQXSLounbr4vEFe9T = ''
		NNnMxcRFDbEiuB3LzYoGa8XhsCrT = ''
	zN1UCH85hbIQx = G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q)
	if not zN1UCH85hbIQx:
		UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'[COLOR FFFFFF00] إضافة وتغيير رابط'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT+' '+h6OYx3P5fiRXg2LoBK8[1]+' [/COLOR]','',711,'','','','',{'folder':mOEzG4cJoV9erugyXbLI,'sequence':1})
		UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'[COLOR FFFFFF00] جلب ملفات'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT+' [/COLOR]','',712,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'بحث في الملفات'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',729,'','','_REMEMBERRESULTS_','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مصنفة مرتبة'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_GROUPED_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مصنفة من القسم'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_FROM_GROUP_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مصنفة من الاسم'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_FROM_NAME_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مصنفة بلا ترتيب'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_GROUPED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات بلا ترتيب'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_ORIGINAL_GROUPED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مجهولة مرتبة'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'قنوات مجهولة بلا ترتيب'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'LIVE_UNKNOWN_GROUPED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'فيديوهات بلا ترتيب'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'VOD_ORIGINAL_GROUPED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'فيديوهات مصنفة القسم'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'VOD_FROM_GROUP_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'فيديوهات مصنفة من الاسم'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'VOD_FROM_NAME_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'فيديوهات مجهولة بلا ترتيب'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'VOD_UNKNOWN_GROUPED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'فيديوهات مجهولة مرتبة'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
		UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'إضافة وتغيير رابط'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT+' '+h6OYx3P5fiRXg2LoBK8[tt7LgzAD3j6VwBud],'',711,'','','','',{'folder':mOEzG4cJoV9erugyXbLI,'sequence':tt7LgzAD3j6VwBud})
	UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'جلب ملفات'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',712,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
	UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'مسح ملفات'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',717,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
	UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'عدد فيديوهات'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',721,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
	UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'Referer تغيير'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',726,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
	UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'User-Agent تغيير'+NNnMxcRFDbEiuB3LzYoGa8XhsCrT,'',723,'','','','',zqcM7fgPCU06VDQXSLounbr4vEFe9T)
	return
def viLtfVUqM9ewyB6THCDdcx2nKW(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q=True):
	ih8u7PEMbVw59Lnrkf,nhq7juWRd50QTDFYCPZXE3wlSKi6 = False,''
	tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw = '',''
	im25Lj7IMUF3V8OPzSy,TAgweYM7k9I6WOB1VEU,gFBkdMnrPxstuyhjGLZa9JC7eHTW2l,BrVCQJ2Pmzuq,YTfQSHvFE4tl58jKsuac = mJr63xY2v1bNFjBXMsUSk(mOEzG4cJoV9erugyXbLI)
	if BrVCQJ2Pmzuq=='': return False,'',''
	zqbfFORL9jgys3Q = sfp0ID4RdwWQOXbhy(mOEzG4cJoV9erugyXbLI)
	if im25Lj7IMUF3V8OPzSy:
		fcZNbeuJHKY = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',im25Lj7IMUF3V8OPzSy,'',zqbfFORL9jgys3Q,False,'','M3U-CHECK_ACCOUNT-1st')
		CGXtvdWw4RHqkMLmeN = fcZNbeuJHKY.content
		if fcZNbeuJHKY.succeeded:
			ZbjTctYfXuh9P,W6SneU8ckuC4GolEOaRFK9MB3Ih,FYOjGXTqsg4xhRVA6JW,aFfT3nV6pPil0WoOD9JKe,VVaZTfP9jb6GSuDW = 0,0,'','',''
			try:
				yWkFpCvl3aEGoScNzfb2AL69K = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',CGXtvdWw4RHqkMLmeN)
				nhq7juWRd50QTDFYCPZXE3wlSKi6 = yWkFpCvl3aEGoScNzfb2AL69K['user_info']['status']
				ih8u7PEMbVw59Lnrkf = True
				FYOjGXTqsg4xhRVA6JW = yWkFpCvl3aEGoScNzfb2AL69K['server_info']['time_now']
			except: pass
			if FYOjGXTqsg4xhRVA6JW:
				try:
					Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe = p1BoraOuWL.strptime(FYOjGXTqsg4xhRVA6JW,'%Y.%m.%d %H:%M:%S')
					ZbjTctYfXuh9P = int(p1BoraOuWL.mktime(Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe))
					W6SneU8ckuC4GolEOaRFK9MB3Ih = int(CHhSItjbXy-ZbjTctYfXuh9P)
					W6SneU8ckuC4GolEOaRFK9MB3Ih = int((W6SneU8ckuC4GolEOaRFK9MB3Ih+900)/1800)*1800
				except: pass
				try:
					Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe = p1BoraOuWL.localtime(int(yWkFpCvl3aEGoScNzfb2AL69K['user_info']['created_at']))
					aFfT3nV6pPil0WoOD9JKe = p1BoraOuWL.strftime('%Y.%m.%d %H:%M:%S',Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe)
				except: pass
				try:
					Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe = p1BoraOuWL.localtime(int(yWkFpCvl3aEGoScNzfb2AL69K['user_info']['exp_date']))
					VVaZTfP9jb6GSuDW = p1BoraOuWL.strftime('%Y.%m.%d %H:%M:%S',Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe)
				except: pass
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.timestamp_'+mOEzG4cJoV9erugyXbLI,str(CHhSItjbXy))
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.timediff_'+mOEzG4cJoV9erugyXbLI,str(W6SneU8ckuC4GolEOaRFK9MB3Ih))
			try:
				qqBienV5b2l9TwXImCO0 = '"server_info":'+CGXtvdWw4RHqkMLmeN.split('"server_info":')[1]
				qqBienV5b2l9TwXImCO0 = qqBienV5b2l9TwXImCO0.replace(':',': ').replace(',',', ').replace('}}','}')
				R43AjLvQ2XkupdqGCPUDaWN = SomeI8i56FaDMGPE.findall('"url": "(.*?)", "port": "(.*?)"',qqBienV5b2l9TwXImCO0,SomeI8i56FaDMGPE.DOTALL)
				tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw = R43AjLvQ2XkupdqGCPUDaWN[0]
			except: ih8u7PEMbVw59Lnrkf = False
			if ih8u7PEMbVw59Lnrkf and SKyG3D4CgRJW7qArbhHljzi6Q:
				max = yWkFpCvl3aEGoScNzfb2AL69K['user_info']['max_connections']
				IAeFYZmWGH3ly1NB = yWkFpCvl3aEGoScNzfb2AL69K['user_info']['active_cons']
				UUi9hPgBw8NHlzt = yWkFpCvl3aEGoScNzfb2AL69K['user_info']['is_trial']
				qqNcgYDrb7hs = im25Lj7IMUF3V8OPzSy.split('?',1)
				QQONb7aR2M6L = 'URL:  [COLOR FFC89008]'+im25Lj7IMUF3V8OPzSy+'[/COLOR]'
				QQONb7aR2M6L += '\n\nStatus:  '+'[COLOR FFC89008]'+nhq7juWRd50QTDFYCPZXE3wlSKi6+'[/COLOR]'
				QQONb7aR2M6L += '\nTrial:    '+'[COLOR FFC89008]'+str(UUi9hPgBw8NHlzt=='1')+'[/COLOR]'
				QQONb7aR2M6L += '\nCreated  At:  '+'[COLOR FFC89008]'+aFfT3nV6pPil0WoOD9JKe+'[/COLOR]'
				QQONb7aR2M6L += '\nExpiry Date:  '+'[COLOR FFC89008]'+VVaZTfP9jb6GSuDW+'[/COLOR]'
				QQONb7aR2M6L += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+IAeFYZmWGH3ly1NB+' / '+max+'[/COLOR]'
				QQONb7aR2M6L += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(yWkFpCvl3aEGoScNzfb2AL69K['user_info']['allowed_output_formats'])+'[/COLOR]'
				QQONb7aR2M6L += '\n\n'+qqBienV5b2l9TwXImCO0
				if nhq7juWRd50QTDFYCPZXE3wlSKi6=='Active': CvFLQP9JtbqH('الاشتراك يعمل بدون مشاكل',QQONb7aR2M6L)
				else: CvFLQP9JtbqH('يبدو أن هناك مشكلة في الاشتراك',QQONb7aR2M6L)
	if im25Lj7IMUF3V8OPzSy and ih8u7PEMbVw59Lnrkf and nhq7juWRd50QTDFYCPZXE3wlSKi6=='Active':
		xrFqGMab4uLKZcS('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+im25Lj7IMUF3V8OPzSy+' ]')
		TbESvC7xMBAzRyamKtU6uLwI = True
	else:
		xrFqGMab4uLKZcS('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+im25Lj7IMUF3V8OPzSy+' ]')
		if SKyG3D4CgRJW7qArbhHljzi6Q: ztgqWUaDpe8CE9N('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		TbESvC7xMBAzRyamKtU6uLwI = False
	return TbESvC7xMBAzRyamKtU6uLwI,tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw
def rum8gIeCX3hYq(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh,aUFbOPBjHnm3hg8EcK,vUHwKfh5mz6,SKyG3D4CgRJW7qArbhHljzi6Q=True):
	if not vUHwKfh5mz6: vUHwKfh5mz6 = '1'
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q): return
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh)
	VVxRSC9foEJiOlUNIh = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list',sDadiY5cfA3MjkwbyungURQ4HCh,aUFbOPBjHnm3hg8EcK)
	urWCk7QVnP53KsENpOb8aY = int(vUHwKfh5mz6)*100
	JToZ7jmNBHbIxzV1Yf853uL9M = urWCk7QVnP53KsENpOb8aY-100
	for lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 in VVxRSC9foEJiOlUNIh[JToZ7jmNBHbIxzV1Yf853uL9M:urWCk7QVnP53KsENpOb8aY]:
		VVQ1IikqU0CDjxJE2tvTONM3G7l = ('GROUPED' in sDadiY5cfA3MjkwbyungURQ4HCh or sDadiY5cfA3MjkwbyungURQ4HCh=='ALL')
		jjsYDcpbFiOlNh1AXqG = ('GROUPED' not in sDadiY5cfA3MjkwbyungURQ4HCh and sDadiY5cfA3MjkwbyungURQ4HCh!='ALL')
		if VVQ1IikqU0CDjxJE2tvTONM3G7l or jjsYDcpbFiOlNh1AXqG:
			if   'ARCHIVED'  in sDadiY5cfA3MjkwbyungURQ4HCh: nUTgq0SFfC9.append(['folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,718,ixHfKALJzXyoYt0,'','ARCHIVED','',{'folder':mOEzG4cJoV9erugyXbLI}])
			elif 'EPG' 		 in sDadiY5cfA3MjkwbyungURQ4HCh: nUTgq0SFfC9.append(['folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,718,ixHfKALJzXyoYt0,'','FULL_EPG','',{'folder':mOEzG4cJoV9erugyXbLI}])
			elif 'TIMESHIFT' in sDadiY5cfA3MjkwbyungURQ4HCh: nUTgq0SFfC9.append(['folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,718,ixHfKALJzXyoYt0,'','TIMESHIFT','',{'folder':mOEzG4cJoV9erugyXbLI}])
			elif 'LIVE' 	 in sDadiY5cfA3MjkwbyungURQ4HCh: nUTgq0SFfC9.append(['live',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,715,ixHfKALJzXyoYt0,'','',lsfFwOE5rvtgxQCBo14VU,{'folder':mOEzG4cJoV9erugyXbLI}])
			else: nUTgq0SFfC9.append(['video',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,715,ixHfKALJzXyoYt0,'','','',{'folder':mOEzG4cJoV9erugyXbLI}])
	uHKTyMEW7ZGYvnFSaBINcs0XpO = len(VVxRSC9foEJiOlUNIh)
	ooUYi4IHuh7alWz(mOEzG4cJoV9erugyXbLI,vUHwKfh5mz6,sDadiY5cfA3MjkwbyungURQ4HCh,714,uHKTyMEW7ZGYvnFSaBINcs0XpO,aUFbOPBjHnm3hg8EcK)
	return
def cLId8T3X4xg9RsOKSnPANuC5F0(jrk6M12dXWJex):
	UZ8LYnm5jsl9uKM0xDX('link',jrk6M12dXWJex+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	UZ8LYnm5jsl9uKM0xDX('link',jrk6M12dXWJex+'أو الخدمة غير موجودة في اشتراكك','',9999)
	UZ8LYnm5jsl9uKM0xDX('link',jrk6M12dXWJex+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def KksoXzFiaIwnRqQZSWUm03HpBtxV(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh,aUFbOPBjHnm3hg8EcK,vUHwKfh5mz6,xtHngiswaJEelDTA3vmzyu6N5RhGq='',SKyG3D4CgRJW7qArbhHljzi6Q=True):
	if not vUHwKfh5mz6: vUHwKfh5mz6 = '1'
	jrk6M12dXWJex = T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q): return False
	if '__SERIES__' in aUFbOPBjHnm3hg8EcK: SnrsLbT2W9v4,FMo1Ah2xuQYGpezg347y = aUFbOPBjHnm3hg8EcK.split('__SERIES__')
	else: SnrsLbT2W9v4,FMo1Ah2xuQYGpezg347y = aUFbOPBjHnm3hg8EcK,''
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh)
	c1I6r5wo2qpUvkaJ4ML3X0PGdjRCQF = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list',sDadiY5cfA3MjkwbyungURQ4HCh,'__GROUPS__')
	if not c1I6r5wo2qpUvkaJ4ML3X0PGdjRCQF: return False
	VXFshrlDA2Rmji6w8fJvk = []
	for kvbO7aXiqA0H2JUPoRh,ixHfKALJzXyoYt0 in c1I6r5wo2qpUvkaJ4ML3X0PGdjRCQF:
		if '===== ===== =====' in kvbO7aXiqA0H2JUPoRh:
			UZ8LYnm5jsl9uKM0xDX('link',jrk6M12dXWJex+kvbO7aXiqA0H2JUPoRh,'',9999)
			UZ8LYnm5jsl9uKM0xDX('link',jrk6M12dXWJex+kvbO7aXiqA0H2JUPoRh,'',9999)
			continue
		if xtHngiswaJEelDTA3vmzyu6N5RhGq:
			if '__SERIES__' in kvbO7aXiqA0H2JUPoRh: jrk6M12dXWJex = 'SERIES'
			elif '!!__UNKNOWN__!!' in kvbO7aXiqA0H2JUPoRh: jrk6M12dXWJex = 'UNKNOWN'
			elif 'LIVE' in sDadiY5cfA3MjkwbyungURQ4HCh: jrk6M12dXWJex = 'LIVE'
			else: jrk6M12dXWJex = 'VIDEOS'
			jrk6M12dXWJex = ',[COLOR FFC89008]'+jrk6M12dXWJex+': [/COLOR]'
		if '__SERIES__' in kvbO7aXiqA0H2JUPoRh: JxrDXO2qHYIpaAP9kj3CRNnSW4l,OkQ5sDUVeht = kvbO7aXiqA0H2JUPoRh.split('__SERIES__')
		else: JxrDXO2qHYIpaAP9kj3CRNnSW4l,OkQ5sDUVeht = kvbO7aXiqA0H2JUPoRh,''
		if not aUFbOPBjHnm3hg8EcK:
			if JxrDXO2qHYIpaAP9kj3CRNnSW4l in VXFshrlDA2Rmji6w8fJvk: continue
			VXFshrlDA2Rmji6w8fJvk.append(JxrDXO2qHYIpaAP9kj3CRNnSW4l)
			if 'RANDOM' in xtHngiswaJEelDTA3vmzyu6N5RhGq: UZ8LYnm5jsl9uKM0xDX('folder',jrk6M12dXWJex+JxrDXO2qHYIpaAP9kj3CRNnSW4l,sDadiY5cfA3MjkwbyungURQ4HCh,168,'','1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
			elif '__SERIES__' in kvbO7aXiqA0H2JUPoRh: UZ8LYnm5jsl9uKM0xDX('folder',jrk6M12dXWJex+JxrDXO2qHYIpaAP9kj3CRNnSW4l,sDadiY5cfA3MjkwbyungURQ4HCh,713,'','1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
			else: UZ8LYnm5jsl9uKM0xDX('folder',jrk6M12dXWJex+JxrDXO2qHYIpaAP9kj3CRNnSW4l,sDadiY5cfA3MjkwbyungURQ4HCh,714,'','1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
		elif '__SERIES__' in kvbO7aXiqA0H2JUPoRh and JxrDXO2qHYIpaAP9kj3CRNnSW4l==SnrsLbT2W9v4:
			if OkQ5sDUVeht in VXFshrlDA2Rmji6w8fJvk: continue
			VXFshrlDA2Rmji6w8fJvk.append(OkQ5sDUVeht)
			if 'RANDOM' in xtHngiswaJEelDTA3vmzyu6N5RhGq: UZ8LYnm5jsl9uKM0xDX('folder',jrk6M12dXWJex+OkQ5sDUVeht,sDadiY5cfA3MjkwbyungURQ4HCh,168,'','1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
			else: UZ8LYnm5jsl9uKM0xDX('folder',jrk6M12dXWJex+OkQ5sDUVeht,sDadiY5cfA3MjkwbyungURQ4HCh,714,ixHfKALJzXyoYt0,'1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
	nUTgq0SFfC9[:] = sorted(nUTgq0SFfC9,reverse=False,key=lambda VVKGWbIES9Ns5dwuiUBt2re: VVKGWbIES9Ns5dwuiUBt2re[1].lower())
	if not xtHngiswaJEelDTA3vmzyu6N5RhGq:
		urWCk7QVnP53KsENpOb8aY = int(vUHwKfh5mz6)*100
		JToZ7jmNBHbIxzV1Yf853uL9M = urWCk7QVnP53KsENpOb8aY-100
		uHKTyMEW7ZGYvnFSaBINcs0XpO = len(nUTgq0SFfC9)
		nUTgq0SFfC9[:] = nUTgq0SFfC9[JToZ7jmNBHbIxzV1Yf853uL9M:urWCk7QVnP53KsENpOb8aY]
		ooUYi4IHuh7alWz(mOEzG4cJoV9erugyXbLI,vUHwKfh5mz6,sDadiY5cfA3MjkwbyungURQ4HCh,713,uHKTyMEW7ZGYvnFSaBINcs0XpO,aUFbOPBjHnm3hg8EcK)
	return True
def Kw1iOYJ2rxy80BlWteICmN7fTd5Dp(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,MpXKjS3FZv1LTfPIam0skE):
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,True): return
	zqbfFORL9jgys3Q = sfp0ID4RdwWQOXbhy(mOEzG4cJoV9erugyXbLI)
	ZbjTctYfXuh9P = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.timestamp_'+mOEzG4cJoV9erugyXbLI)
	if not ZbjTctYfXuh9P or CHhSItjbXy-int(ZbjTctYfXuh9P)>24*nh1uLlGma8wJVsAMyKxkjC9N:
		TbESvC7xMBAzRyamKtU6uLwI,tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw = viLtfVUqM9ewyB6THCDdcx2nKW(mOEzG4cJoV9erugyXbLI,False)
		if not TbESvC7xMBAzRyamKtU6uLwI: return
	W6SneU8ckuC4GolEOaRFK9MB3Ih = int(LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.timediff_'+mOEzG4cJoV9erugyXbLI))
	gFBkdMnrPxstuyhjGLZa9JC7eHTW2l = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.server_'+mOEzG4cJoV9erugyXbLI)
	BrVCQJ2Pmzuq = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.username_'+mOEzG4cJoV9erugyXbLI)
	YTfQSHvFE4tl58jKsuac = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.password_'+mOEzG4cJoV9erugyXbLI)
	P2pOcvxI4RsBWqFy0hVEk3 = eesaHQO5yPGNvopTtWzR.split('/')
	IHuNcAEBzhwt4UgRL = P2pOcvxI4RsBWqFy0hVEk3[-1].replace('.ts','').replace('.m3u8','')
	if MpXKjS3FZv1LTfPIam0skE=='SHORT_EPG': gQkwhbt18v5OW = 'get_short_epg'
	else: gQkwhbt18v5OW = 'get_simple_data_table'
	im25Lj7IMUF3V8OPzSy,TAgweYM7k9I6WOB1VEU,gFBkdMnrPxstuyhjGLZa9JC7eHTW2l,BrVCQJ2Pmzuq,YTfQSHvFE4tl58jKsuac = mJr63xY2v1bNFjBXMsUSk(mOEzG4cJoV9erugyXbLI)
	if not BrVCQJ2Pmzuq: return
	KGi1VasJg3RUbO5XMzfY78r4EoWFNB = im25Lj7IMUF3V8OPzSy+'&action='+gQkwhbt18v5OW+'&stream_id='+IHuNcAEBzhwt4UgRL
	CGXtvdWw4RHqkMLmeN = m3j7nzuCGTbXdVZMr5h(fyIAplJLe9MGiPosBvrEOtZUm6,KGi1VasJg3RUbO5XMzfY78r4EoWFNB,'',zqbfFORL9jgys3Q,'','M3U-EPG_ITEMS-2nd')
	R0Yk3B1jzodOExrs5U9Q2GF4ybWN = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',CGXtvdWw4RHqkMLmeN)
	kks0Za6wbenf4PxVAcd = R0Yk3B1jzodOExrs5U9Q2GF4ybWN['epg_listings']
	lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh = []
	if MpXKjS3FZv1LTfPIam0skE in ['ARCHIVED','TIMESHIFT']:
		for yWkFpCvl3aEGoScNzfb2AL69K in kks0Za6wbenf4PxVAcd:
			if yWkFpCvl3aEGoScNzfb2AL69K['has_archive']==1:
				lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh.append(yWkFpCvl3aEGoScNzfb2AL69K)
				if MpXKjS3FZv1LTfPIam0skE in ['TIMESHIFT']: break
		if not lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh: return
		UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if MpXKjS3FZv1LTfPIam0skE in ['TIMESHIFT']:
			GGAoFy01W7zjsdhequmDHK = 2
			WTaSliHenZv389AzDb = GGAoFy01W7zjsdhequmDHK*nh1uLlGma8wJVsAMyKxkjC9N
			lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh = []
			a7YtfoZJ5MG19U26rAelByD = int(int(yWkFpCvl3aEGoScNzfb2AL69K['start_timestamp'])/WTaSliHenZv389AzDb)*WTaSliHenZv389AzDb
			k3oyCZuH2Ji10v8zXG4TldwqAPWaht = CHhSItjbXy+WTaSliHenZv389AzDb
			CuE6bQMRjfvKc = int((k3oyCZuH2Ji10v8zXG4TldwqAPWaht-a7YtfoZJ5MG19U26rAelByD)/nh1uLlGma8wJVsAMyKxkjC9N)
			for P12PCQDTINg in range(CuE6bQMRjfvKc):
				if P12PCQDTINg>=6:
					if P12PCQDTINg%GGAoFy01W7zjsdhequmDHK!=0: continue
					ekjmsPHpfun07D6cAqISKZQ1dl = WTaSliHenZv389AzDb
				else: ekjmsPHpfun07D6cAqISKZQ1dl = WTaSliHenZv389AzDb//2
				sFKnPVh6RSqQO0BZI9m1cJfWtCdA = a7YtfoZJ5MG19U26rAelByD+P12PCQDTINg*nh1uLlGma8wJVsAMyKxkjC9N
				yWkFpCvl3aEGoScNzfb2AL69K = {}
				yWkFpCvl3aEGoScNzfb2AL69K['title'] = ''
				Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe = p1BoraOuWL.localtime(sFKnPVh6RSqQO0BZI9m1cJfWtCdA-W6SneU8ckuC4GolEOaRFK9MB3Ih-nh1uLlGma8wJVsAMyKxkjC9N)
				yWkFpCvl3aEGoScNzfb2AL69K['start'] = p1BoraOuWL.strftime('%Y.%m.%d %H:%M:%S',Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe)
				yWkFpCvl3aEGoScNzfb2AL69K['start_timestamp'] = str(sFKnPVh6RSqQO0BZI9m1cJfWtCdA)
				yWkFpCvl3aEGoScNzfb2AL69K['stop_timestamp'] = str(sFKnPVh6RSqQO0BZI9m1cJfWtCdA+ekjmsPHpfun07D6cAqISKZQ1dl)
				lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh.append(yWkFpCvl3aEGoScNzfb2AL69K)
	elif MpXKjS3FZv1LTfPIam0skE in ['SHORT_EPG','FULL_EPG']: lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh = kks0Za6wbenf4PxVAcd
	if MpXKjS3FZv1LTfPIam0skE=='FULL_EPG' and len(lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh)>0:
		UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	oEDzjqWAJhTpOlKM6VQe4HNPnxGy = []
	ixHfKALJzXyoYt0 = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Icon')
	for yWkFpCvl3aEGoScNzfb2AL69K in lFZ0Ccv5E83HedmpIXsWwi9Bu7GSh:
		PrfpcmRL8AHyk = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(yWkFpCvl3aEGoScNzfb2AL69K['title'])
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: PrfpcmRL8AHyk = PrfpcmRL8AHyk.decode('utf8')
		sFKnPVh6RSqQO0BZI9m1cJfWtCdA = int(yWkFpCvl3aEGoScNzfb2AL69K['start_timestamp'])
		WGODomLwcxX = int(yWkFpCvl3aEGoScNzfb2AL69K['stop_timestamp'])
		CkKoIragHl = str(int((WGODomLwcxX-sFKnPVh6RSqQO0BZI9m1cJfWtCdA+59)/60))
		AAwBQh3XoxEmncrlpORbMqgT1 = yWkFpCvl3aEGoScNzfb2AL69K['start'].replace(' ',':')
		Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe = p1BoraOuWL.localtime(sFKnPVh6RSqQO0BZI9m1cJfWtCdA-nh1uLlGma8wJVsAMyKxkjC9N)
		FKr2gzsCvXbGd8IUOn = p1BoraOuWL.strftime('%H:%M',Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe)
		DD8j79HukJbhVXoya = p1BoraOuWL.strftime('%a',Pr97LNAwdQ5c30mTYa2RSkJWqhbgMe)
		if MpXKjS3FZv1LTfPIam0skE=='SHORT_EPG': PrfpcmRL8AHyk = '[COLOR FFFFFF00]'+FKr2gzsCvXbGd8IUOn+' ـ '+PrfpcmRL8AHyk+'[/COLOR]'
		elif MpXKjS3FZv1LTfPIam0skE=='TIMESHIFT': PrfpcmRL8AHyk = DD8j79HukJbhVXoya+' '+FKr2gzsCvXbGd8IUOn+' ('+CkKoIragHl+'min)'
		else: PrfpcmRL8AHyk = DD8j79HukJbhVXoya+' '+FKr2gzsCvXbGd8IUOn+' ('+CkKoIragHl+'min)   '+PrfpcmRL8AHyk+' ـ'
		if MpXKjS3FZv1LTfPIam0skE in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			zMvRZxq3I2DHndaEAGY5piL6g8sK = gFBkdMnrPxstuyhjGLZa9JC7eHTW2l+'/timeshift/'+BrVCQJ2Pmzuq+'/'+YTfQSHvFE4tl58jKsuac+'/'+CkKoIragHl+'/'+AAwBQh3XoxEmncrlpORbMqgT1+'/'+IHuNcAEBzhwt4UgRL+'.m3u8'
			if MpXKjS3FZv1LTfPIam0skE=='FULL_EPG': UZ8LYnm5jsl9uKM0xDX('link',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,zMvRZxq3I2DHndaEAGY5piL6g8sK,9999,ixHfKALJzXyoYt0,'','','',{'folder':mOEzG4cJoV9erugyXbLI})
			else: UZ8LYnm5jsl9uKM0xDX('video',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,zMvRZxq3I2DHndaEAGY5piL6g8sK,715,ixHfKALJzXyoYt0,'','','',{'folder':mOEzG4cJoV9erugyXbLI})
		oEDzjqWAJhTpOlKM6VQe4HNPnxGy.append(PrfpcmRL8AHyk)
	if MpXKjS3FZv1LTfPIam0skE=='SHORT_EPG' and oEDzjqWAJhTpOlKM6VQe4HNPnxGy: wkUL1znr5AdBJHy7jVN = FfdZsHWK0SnY6yzEANbmXco8hO(oEDzjqWAJhTpOlKM6VQe4HNPnxGy)
	return oEDzjqWAJhTpOlKM6VQe4HNPnxGy
def E1ECNJ4Wyowu(mOEzG4cJoV9erugyXbLI):
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,True): return
	gFBkdMnrPxstuyhjGLZa9JC7eHTW2l,xQ1grCETawMP0pDzKOV86,a7oulkvpAOK = '',0,0
	TbESvC7xMBAzRyamKtU6uLwI,tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw = viLtfVUqM9ewyB6THCDdcx2nKW(mOEzG4cJoV9erugyXbLI,False)
	if TbESvC7xMBAzRyamKtU6uLwI:
		TTUAZNkMpQtwY6uF2rEnS9 = XxmdGKqvtUIgCbP34ahMfoJrR2W8ZQ(tSVQqxk67glzK1Zfc)
		xQ1grCETawMP0pDzKOV86 = N1NR5zebmAEyxPQ97l(TTUAZNkMpQtwY6uF2rEnS9[0],int(kyO6F5pcQt1q3bw))
		c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'LIVE_GROUPED')
		ZQVLBS5JyxsHIgleF370 = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list','LIVE_GROUPED')
		VVxRSC9foEJiOlUNIh = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list','LIVE_GROUPED',ZQVLBS5JyxsHIgleF370[1])
		eesaHQO5yPGNvopTtWzR = VVxRSC9foEJiOlUNIh[0][2]
		Ip9Sdyeb3iWRxVP1 = SomeI8i56FaDMGPE.findall('://(.*?)/',eesaHQO5yPGNvopTtWzR,SomeI8i56FaDMGPE.DOTALL)
		Ip9Sdyeb3iWRxVP1 = Ip9Sdyeb3iWRxVP1[0]
		if ':' in Ip9Sdyeb3iWRxVP1: Tgt18Sm9en,ixw34dUg7jtBNOK8oJ = Ip9Sdyeb3iWRxVP1.split(':')
		else: Tgt18Sm9en,ixw34dUg7jtBNOK8oJ = Ip9Sdyeb3iWRxVP1,'80'
		bxuRgpzZ9wyI8LX6 = XxmdGKqvtUIgCbP34ahMfoJrR2W8ZQ(Tgt18Sm9en)
		a7oulkvpAOK = N1NR5zebmAEyxPQ97l(bxuRgpzZ9wyI8LX6[0],int(ixw34dUg7jtBNOK8oJ))
	if xQ1grCETawMP0pDzKOV86 and a7oulkvpAOK:
		QQONb7aR2M6L = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		QQONb7aR2M6L += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(a7oulkvpAOK*1000))+' ملي ثانية'
		QQONb7aR2M6L += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(xQ1grCETawMP0pDzKOV86*1000))+' ملي ثانية'
		yka0pczgxUV = nEYJ5OCXG0gcNy('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',QQONb7aR2M6L)
		if yka0pczgxUV==1 and xQ1grCETawMP0pDzKOV86<a7oulkvpAOK: gFBkdMnrPxstuyhjGLZa9JC7eHTW2l = tSVQqxk67glzK1Zfc+':'+kyO6F5pcQt1q3bw
	else: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.server_'+mOEzG4cJoV9erugyXbLI,gFBkdMnrPxstuyhjGLZa9JC7eHTW2l)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(mOEzG4cJoV9erugyXbLI,eesaHQO5yPGNvopTtWzR,jPqMvmNDgsYiWUyxo):
	BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI)
	ERsLJomNOCf32bB9zKMQlP1TcUqXpi = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.referer_'+mOEzG4cJoV9erugyXbLI)
	if BBdeFJGxahsozUmQKycwV2Ak4SE6Ru or ERsLJomNOCf32bB9zKMQlP1TcUqXpi:
		eesaHQO5yPGNvopTtWzR += '|'
		if BBdeFJGxahsozUmQKycwV2Ak4SE6Ru: eesaHQO5yPGNvopTtWzR += '&User-Agent='+BBdeFJGxahsozUmQKycwV2Ak4SE6Ru
		if ERsLJomNOCf32bB9zKMQlP1TcUqXpi: eesaHQO5yPGNvopTtWzR += '&Referer='+ERsLJomNOCf32bB9zKMQlP1TcUqXpi
		eesaHQO5yPGNvopTtWzR = eesaHQO5yPGNvopTtWzR.replace('|&','|')
	kFygcp2jqSUCiNRnur71xMZI96(eesaHQO5yPGNvopTtWzR,AdKBOaFs5gt3RoNkwLj,jPqMvmNDgsYiWUyxo)
	return
def nsa2PZqyOTQrlIeULSfhvwbt(mOEzG4cJoV9erugyXbLI):
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI)
	YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','استخدام الأصلي','تعديل القديم',BBdeFJGxahsozUmQKycwV2Ak4SE6Ru,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if YWmv0Rx39zB4LKF5Ie==1: BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = ymH9jzg2KId5MCvw8lXBZn('أكتب ـM3U User-Agent جديد',BBdeFJGxahsozUmQKycwV2Ak4SE6Ru,True)
	else: BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = 'Unknown'
	if BBdeFJGxahsozUmQKycwV2Ak4SE6Ru==' ':
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','','',BBdeFJGxahsozUmQKycwV2Ak4SE6Ru,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if YWmv0Rx39zB4LKF5Ie!=1:
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم الإلغاء')
		return
	LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI,BBdeFJGxahsozUmQKycwV2Ak4SE6Ru)
	e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI)
	return
def QH4l09LW7Jp(mOEzG4cJoV9erugyXbLI):
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	ERsLJomNOCf32bB9zKMQlP1TcUqXpi = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.referer_'+mOEzG4cJoV9erugyXbLI)
	YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','استخدام الأصلي','تعديل القديم',ERsLJomNOCf32bB9zKMQlP1TcUqXpi,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if YWmv0Rx39zB4LKF5Ie==1: ERsLJomNOCf32bB9zKMQlP1TcUqXpi = ymH9jzg2KId5MCvw8lXBZn('أكتب ـM3U Referer جديد',ERsLJomNOCf32bB9zKMQlP1TcUqXpi,True)
	else: ERsLJomNOCf32bB9zKMQlP1TcUqXpi = ''
	if ERsLJomNOCf32bB9zKMQlP1TcUqXpi==' ':
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','','',ERsLJomNOCf32bB9zKMQlP1TcUqXpi,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if YWmv0Rx39zB4LKF5Ie!=1:
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم الإلغاء')
		return
	LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.referer_'+mOEzG4cJoV9erugyXbLI,ERsLJomNOCf32bB9zKMQlP1TcUqXpi)
	e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI)
	return
def mJr63xY2v1bNFjBXMsUSk(mOEzG4cJoV9erugyXbLI,ZVTUnDSrbte1f=''):
	if not zDmq6bjR9slQf45WBPghULo2XZFw: zDmq6bjR9slQf45WBPghULo2XZFw = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI)
	gFBkdMnrPxstuyhjGLZa9JC7eHTW2l = DRom9hFTZXKuvfr2(zDmq6bjR9slQf45WBPghULo2XZFw,'url')
	BrVCQJ2Pmzuq = SomeI8i56FaDMGPE.findall('username=(.*?)&',zDmq6bjR9slQf45WBPghULo2XZFw+'&',SomeI8i56FaDMGPE.DOTALL)
	YTfQSHvFE4tl58jKsuac = SomeI8i56FaDMGPE.findall('password=(.*?)&',zDmq6bjR9slQf45WBPghULo2XZFw+'&',SomeI8i56FaDMGPE.DOTALL)
	if not BrVCQJ2Pmzuq or not YTfQSHvFE4tl58jKsuac:
		ztgqWUaDpe8CE9N('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	BrVCQJ2Pmzuq = BrVCQJ2Pmzuq[0]
	YTfQSHvFE4tl58jKsuac = YTfQSHvFE4tl58jKsuac[0]
	im25Lj7IMUF3V8OPzSy = gFBkdMnrPxstuyhjGLZa9JC7eHTW2l+'/player_api.php?username='+BrVCQJ2Pmzuq+'&password='+YTfQSHvFE4tl58jKsuac
	TAgweYM7k9I6WOB1VEU = gFBkdMnrPxstuyhjGLZa9JC7eHTW2l+'/get.php?username='+BrVCQJ2Pmzuq+'&password='+YTfQSHvFE4tl58jKsuac+'&type=m3u_plus'
	return im25Lj7IMUF3V8OPzSy,TAgweYM7k9I6WOB1VEU,gFBkdMnrPxstuyhjGLZa9JC7eHTW2l,BrVCQJ2Pmzuq,YTfQSHvFE4tl58jKsuac
def zF5iVQIHCNT(mOEzG4cJoV9erugyXbLI,vtFnO6UX2f1o4sZbhAMKjdQ0mwYP=''):
	p7kLF2JIu6wYno = vtFnO6UX2f1o4sZbhAMKjdQ0mwYP.replace('/','_').replace(':','_').replace('.','_')
	p7kLF2JIu6wYno = p7kLF2JIu6wYno.replace('?','_').replace('=','_').replace('&','_')
	p7kLF2JIu6wYno = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,p7kLF2JIu6wYno).strip('.m3u')+'.m3u'
	return p7kLF2JIu6wYno
def kGUQdpiLTEWPezxKDv9hNAf(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP):
	iWuS5rgyxGCQ = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI+'_'+mutkxRodSEY0l8DJVAP)
	DHBkgT17UJ = True
	if iWuS5rgyxGCQ:
		YWmv0Rx39zB4LKF5Ie = bxBWM9d53zOAcar('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+iWuS5rgyxGCQ+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if YWmv0Rx39zB4LKF5Ie==-1: return
		elif YWmv0Rx39zB4LKF5Ie==0: iWuS5rgyxGCQ = ''
		elif YWmv0Rx39zB4LKF5Ie==2:
			YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if YWmv0Rx39zB4LKF5Ie in [-1,0]: return
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم مسح الرابط')
			DHBkgT17UJ = False
			EEs6YHaSibnD = ''
	if DHBkgT17UJ:
		EEs6YHaSibnD = ymH9jzg2KId5MCvw8lXBZn('اكتب رابط M3U كاملا',iWuS5rgyxGCQ)
		EEs6YHaSibnD = EEs6YHaSibnD.strip(' ')
		if not EEs6YHaSibnD:
			YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if YWmv0Rx39zB4LKF5Ie in [-1,0]: return
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			QQONb7aR2M6L = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			YWmv0Rx39zB4LKF5Ie = nEYJ5OCXG0gcNy('','','','الرابط الجديد هو:','[COLOR FFC89008]'+EEs6YHaSibnD+'[/COLOR]'+'\n\n'+QQONb7aR2M6L)
			if YWmv0Rx39zB4LKF5Ie!=1:
				ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم الإلغاء')
				return
	LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI+'_'+mutkxRodSEY0l8DJVAP,EEs6YHaSibnD)
	BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI)
	if not BBdeFJGxahsozUmQKycwV2Ak4SE6Ru: LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI,'Unknown')
	e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI)
	return
def dEeZpTURnmGkF(ZSkChYJp2a1P,cO5eQrXZbC8JNop1Fjla,g82fwN6CxAdTl7juk,Z8VWRjcHi2OlSwMx9TG4eh6,Q9mNtOP03df7FKIrcvBSs8q4iDX5y,Ef9XDLmV7wByGWshRqnb654Z,TAgweYM7k9I6WOB1VEU):
	VVxRSC9foEJiOlUNIh,ffrwHxIuDmyiW0FVtR = [],[]
	dYWHGioARtn07S3JpMbq = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		if Ef9XDLmV7wByGWshRqnb654Z%473==0:
			AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,40+int(10*Ef9XDLmV7wByGWshRqnb654Z/Q9mNtOP03df7FKIrcvBSs8q4iDX5y),'قراءة الفيديوهات','الفيديو رقم:-',str(Ef9XDLmV7wByGWshRqnb654Z)+' / '+str(Q9mNtOP03df7FKIrcvBSs8q4iDX5y))
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return None,None,None
		eesaHQO5yPGNvopTtWzR = SomeI8i56FaDMGPE.findall('^(.*?)\n+((http|https|rtmp).*?)$',bDuvmIw28GRWVCBaOsT3HneLSt,SomeI8i56FaDMGPE.DOTALL)
		if eesaHQO5yPGNvopTtWzR:
			bDuvmIw28GRWVCBaOsT3HneLSt,eesaHQO5yPGNvopTtWzR,LL5opKn1gkuEZPf = eesaHQO5yPGNvopTtWzR[0]
			eesaHQO5yPGNvopTtWzR = eesaHQO5yPGNvopTtWzR.replace('\n','')
			bDuvmIw28GRWVCBaOsT3HneLSt = bDuvmIw28GRWVCBaOsT3HneLSt.replace('\n','')
		else:
			ffrwHxIuDmyiW0FVtR.append({'line':bDuvmIw28GRWVCBaOsT3HneLSt})
			continue
		DtMcf0418TgS7UmdnI,lsfFwOE5rvtgxQCBo14VU,kvbO7aXiqA0H2JUPoRh,PrfpcmRL8AHyk,jPqMvmNDgsYiWUyxo,tF0IuB7La4V69phQTRcqH = {},'','','','',False
		try:
			bDuvmIw28GRWVCBaOsT3HneLSt,PrfpcmRL8AHyk = bDuvmIw28GRWVCBaOsT3HneLSt.rsplit('",',1)
			bDuvmIw28GRWVCBaOsT3HneLSt = bDuvmIw28GRWVCBaOsT3HneLSt+'"'
		except:
			try: bDuvmIw28GRWVCBaOsT3HneLSt,PrfpcmRL8AHyk = bDuvmIw28GRWVCBaOsT3HneLSt.rsplit('1,',1)
			except: PrfpcmRL8AHyk = ''
		DtMcf0418TgS7UmdnI['url'] = eesaHQO5yPGNvopTtWzR
		jYhwa7y85PH09VgJkvAGQinBeS = SomeI8i56FaDMGPE.findall(' (.*?)="(.*?)"',bDuvmIw28GRWVCBaOsT3HneLSt,SomeI8i56FaDMGPE.DOTALL)
		for VVKGWbIES9Ns5dwuiUBt2re,y3QD6VRYHqX in jYhwa7y85PH09VgJkvAGQinBeS:
			VVKGWbIES9Ns5dwuiUBt2re = VVKGWbIES9Ns5dwuiUBt2re.replace('"','').strip(' ')
			DtMcf0418TgS7UmdnI[VVKGWbIES9Ns5dwuiUBt2re] = y3QD6VRYHqX.strip(' ')
		yH7kwjGWDMo4YXpg1eN = list(DtMcf0418TgS7UmdnI.keys())
		if not PrfpcmRL8AHyk:
			if 'name' in yH7kwjGWDMo4YXpg1eN and DtMcf0418TgS7UmdnI['name']: PrfpcmRL8AHyk = DtMcf0418TgS7UmdnI['name']
		DtMcf0418TgS7UmdnI['title'] = PrfpcmRL8AHyk.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in yH7kwjGWDMo4YXpg1eN:
			DtMcf0418TgS7UmdnI['img'] = DtMcf0418TgS7UmdnI['logo']
			del DtMcf0418TgS7UmdnI['logo']
		else: DtMcf0418TgS7UmdnI['img'] = ''
		if 'group' in yH7kwjGWDMo4YXpg1eN and DtMcf0418TgS7UmdnI['group']: kvbO7aXiqA0H2JUPoRh = DtMcf0418TgS7UmdnI['group']
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in eesaHQO5yPGNvopTtWzR.lower() for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in dYWHGioARtn07S3JpMbq):
			tF0IuB7La4V69phQTRcqH = True if 'm3u' not in eesaHQO5yPGNvopTtWzR else False
		if tF0IuB7La4V69phQTRcqH or '__SERIES__' in kvbO7aXiqA0H2JUPoRh or '__MOVIES__' in kvbO7aXiqA0H2JUPoRh:
			jPqMvmNDgsYiWUyxo = 'VOD'
			if '__SERIES__' in kvbO7aXiqA0H2JUPoRh: jPqMvmNDgsYiWUyxo = jPqMvmNDgsYiWUyxo+'_SERIES'
			elif '__MOVIES__' in kvbO7aXiqA0H2JUPoRh: jPqMvmNDgsYiWUyxo = jPqMvmNDgsYiWUyxo+'_MOVIES'
			else: jPqMvmNDgsYiWUyxo = jPqMvmNDgsYiWUyxo+'_UNKNOWN'
			kvbO7aXiqA0H2JUPoRh = kvbO7aXiqA0H2JUPoRh.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			jPqMvmNDgsYiWUyxo = 'LIVE'
			if PrfpcmRL8AHyk in cO5eQrXZbC8JNop1Fjla: lsfFwOE5rvtgxQCBo14VU = lsfFwOE5rvtgxQCBo14VU+'_EPG'
			if PrfpcmRL8AHyk in g82fwN6CxAdTl7juk: lsfFwOE5rvtgxQCBo14VU = lsfFwOE5rvtgxQCBo14VU+'_ARCHIVED'
			if not kvbO7aXiqA0H2JUPoRh: jPqMvmNDgsYiWUyxo = jPqMvmNDgsYiWUyxo+'_UNKNOWN'
			else: jPqMvmNDgsYiWUyxo = jPqMvmNDgsYiWUyxo+lsfFwOE5rvtgxQCBo14VU
		kvbO7aXiqA0H2JUPoRh = kvbO7aXiqA0H2JUPoRh.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in jPqMvmNDgsYiWUyxo: kvbO7aXiqA0H2JUPoRh = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in jPqMvmNDgsYiWUyxo: kvbO7aXiqA0H2JUPoRh = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in jPqMvmNDgsYiWUyxo:
			AYoOPSfmpbjK8NlhGt9Q1v = SomeI8i56FaDMGPE.findall('(.*?) [Ss]\d+ +[Ee]\d+',DtMcf0418TgS7UmdnI['title'],SomeI8i56FaDMGPE.DOTALL)
			if AYoOPSfmpbjK8NlhGt9Q1v: AYoOPSfmpbjK8NlhGt9Q1v = AYoOPSfmpbjK8NlhGt9Q1v[0]
			else: AYoOPSfmpbjK8NlhGt9Q1v = '!!__UNKNOWN_SERIES__!!'
			kvbO7aXiqA0H2JUPoRh = kvbO7aXiqA0H2JUPoRh+'__SERIES__'+AYoOPSfmpbjK8NlhGt9Q1v
		if 'id' in yH7kwjGWDMo4YXpg1eN: del DtMcf0418TgS7UmdnI['id']
		if 'ID' in yH7kwjGWDMo4YXpg1eN: del DtMcf0418TgS7UmdnI['ID']
		if 'name' in yH7kwjGWDMo4YXpg1eN: del DtMcf0418TgS7UmdnI['name']
		PrfpcmRL8AHyk = DtMcf0418TgS7UmdnI['title']
		PrfpcmRL8AHyk = c8Fvb4IfHW9XkG1mLK5Z(PrfpcmRL8AHyk)
		PrfpcmRL8AHyk = ppeHG1uZqRh7Md(PrfpcmRL8AHyk)
		rd270eAQIf6W,kvbO7aXiqA0H2JUPoRh = QQ70Aa4Ch2E1p6DNvnTPIMVtj(kvbO7aXiqA0H2JUPoRh)
		gdOrQk8SzFE0eXb,PrfpcmRL8AHyk = QQ70Aa4Ch2E1p6DNvnTPIMVtj(PrfpcmRL8AHyk)
		DtMcf0418TgS7UmdnI['type'] = jPqMvmNDgsYiWUyxo
		DtMcf0418TgS7UmdnI['context'] = lsfFwOE5rvtgxQCBo14VU
		DtMcf0418TgS7UmdnI['group'] = kvbO7aXiqA0H2JUPoRh.upper()
		DtMcf0418TgS7UmdnI['title'] = PrfpcmRL8AHyk.upper()
		DtMcf0418TgS7UmdnI['country'] = gdOrQk8SzFE0eXb.upper()
		DtMcf0418TgS7UmdnI['language'] = rd270eAQIf6W.upper()
		VVxRSC9foEJiOlUNIh.append(DtMcf0418TgS7UmdnI)
		Ef9XDLmV7wByGWshRqnb654Z += 1
	return VVxRSC9foEJiOlUNIh,Ef9XDLmV7wByGWshRqnb654Z,ffrwHxIuDmyiW0FVtR
def ppeHG1uZqRh7Md(PrfpcmRL8AHyk):
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.replace('||','|').replace('___',':').replace('--','-')
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.replace('[[','[').replace(']]',']')
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.replace('((','(').replace('))',')')
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.replace('<<','<').replace('>>','>')
	PrfpcmRL8AHyk = PrfpcmRL8AHyk.strip(' ')
	return PrfpcmRL8AHyk
def t6C0gUaPvzjyxeoYup7rSEXOVWhnkD(mmGDKu7NynFI6QYLOiSrXf5Hcwt,Z8VWRjcHi2OlSwMx9TG4eh6,mutkxRodSEY0l8DJVAP):
	OcZztLHx3P67bIMGv25T = {}
	for YJeXGTPVbZMSphqumF5iO8wA3D4r in H56tOjf2BZNiSCUKYsozXA4gdvGuxR: OcZztLHx3P67bIMGv25T[YJeXGTPVbZMSphqumF5iO8wA3D4r+'_'+mutkxRodSEY0l8DJVAP] = []
	Q9mNtOP03df7FKIrcvBSs8q4iDX5y = len(mmGDKu7NynFI6QYLOiSrXf5Hcwt)
	y7AJeqF4pD9 = str(Q9mNtOP03df7FKIrcvBSs8q4iDX5y)
	Ef9XDLmV7wByGWshRqnb654Z = 0
	ffrwHxIuDmyiW0FVtR = []
	for DtMcf0418TgS7UmdnI in mmGDKu7NynFI6QYLOiSrXf5Hcwt:
		if Ef9XDLmV7wByGWshRqnb654Z%873==0:
			AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,50+int(5*Ef9XDLmV7wByGWshRqnb654Z/Q9mNtOP03df7FKIrcvBSs8q4iDX5y),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(Ef9XDLmV7wByGWshRqnb654Z)+' / '+y7AJeqF4pD9)
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return None,None
		kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 = DtMcf0418TgS7UmdnI['group'],DtMcf0418TgS7UmdnI['context'],DtMcf0418TgS7UmdnI['title'],DtMcf0418TgS7UmdnI['url'],DtMcf0418TgS7UmdnI['img']
		gdOrQk8SzFE0eXb,rd270eAQIf6W,YJeXGTPVbZMSphqumF5iO8wA3D4r = DtMcf0418TgS7UmdnI['country'],DtMcf0418TgS7UmdnI['language'],DtMcf0418TgS7UmdnI['type']
		l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W = (kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0)
		eqa50xgIWwNSbrOd = False
		if 'LIVE' in YJeXGTPVbZMSphqumF5iO8wA3D4r:
			if 'UNKNOWN' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_UNKNOWN_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			elif 'LIVE' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			else: eqa50xgIWwNSbrOd = True
			OcZztLHx3P67bIMGv25T['LIVE_ORIGINAL_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
		elif 'VOD' in YJeXGTPVbZMSphqumF5iO8wA3D4r:
			if 'UNKNOWN' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_UNKNOWN_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			elif 'MOVIES' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_MOVIES_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			elif 'SERIES' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_SERIES_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			else: eqa50xgIWwNSbrOd = True
			OcZztLHx3P67bIMGv25T['VOD_ORIGINAL_GROUPED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
		else: eqa50xgIWwNSbrOd = True
		if eqa50xgIWwNSbrOd: ffrwHxIuDmyiW0FVtR.append(DtMcf0418TgS7UmdnI)
		Ef9XDLmV7wByGWshRqnb654Z += 1
	AA0sEaKHPOzBd9MfNW4QUhuo = sorted(mmGDKu7NynFI6QYLOiSrXf5Hcwt,reverse=False,key=lambda VVKGWbIES9Ns5dwuiUBt2re: VVKGWbIES9Ns5dwuiUBt2re['title'].lower())
	del mmGDKu7NynFI6QYLOiSrXf5Hcwt
	y7AJeqF4pD9 = str(Q9mNtOP03df7FKIrcvBSs8q4iDX5y)
	Ef9XDLmV7wByGWshRqnb654Z = 0
	for DtMcf0418TgS7UmdnI in AA0sEaKHPOzBd9MfNW4QUhuo:
		Ef9XDLmV7wByGWshRqnb654Z += 1
		if Ef9XDLmV7wByGWshRqnb654Z%873==0:
			AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,55+int(5*Ef9XDLmV7wByGWshRqnb654Z/Q9mNtOP03df7FKIrcvBSs8q4iDX5y),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(Ef9XDLmV7wByGWshRqnb654Z)+' / '+y7AJeqF4pD9)
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return None,None
		YJeXGTPVbZMSphqumF5iO8wA3D4r = DtMcf0418TgS7UmdnI['type']
		kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 = DtMcf0418TgS7UmdnI['group'],DtMcf0418TgS7UmdnI['context'],DtMcf0418TgS7UmdnI['title'],DtMcf0418TgS7UmdnI['url'],DtMcf0418TgS7UmdnI['img']
		gdOrQk8SzFE0eXb,rd270eAQIf6W = DtMcf0418TgS7UmdnI['country'],DtMcf0418TgS7UmdnI['language']
		FYJaOLufhMwNog9UDkXEV30txIWpc = (kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU+'_TIMESHIFT',PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0)
		l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W = (kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0)
		W6WUs1kFXN0VuDmiJGZSxl4RT = (gdOrQk8SzFE0eXb,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0)
		todEMR5OGxQuwB6vNWPAhkHcCYI = (rd270eAQIf6W,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0)
		if 'LIVE' in YJeXGTPVbZMSphqumF5iO8wA3D4r:
			if 'UNKNOWN' in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_UNKNOWN_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			else: OcZztLHx3P67bIMGv25T['LIVE_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			if 'EPG'		in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_EPG_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			if 'ARCHIVED'	in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_ARCHIVED_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			if 'ARCHIVED'	in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['LIVE_TIMESHIFT_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(FYJaOLufhMwNog9UDkXEV30txIWpc)
			OcZztLHx3P67bIMGv25T['LIVE_FROM_NAME_SORTED_'+mutkxRodSEY0l8DJVAP].append(W6WUs1kFXN0VuDmiJGZSxl4RT)
			OcZztLHx3P67bIMGv25T['LIVE_FROM_GROUP_SORTED_'+mutkxRodSEY0l8DJVAP].append(todEMR5OGxQuwB6vNWPAhkHcCYI)
		elif 'VOD' in YJeXGTPVbZMSphqumF5iO8wA3D4r:
			if   'UNKNOWN'	in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_UNKNOWN_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			elif 'MOVIES'	in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_MOVIES_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			elif 'SERIES'	in YJeXGTPVbZMSphqumF5iO8wA3D4r: OcZztLHx3P67bIMGv25T['VOD_SERIES_GROUPED_SORTED_'+mutkxRodSEY0l8DJVAP].append(l6lz8dTKkcmIEyAqBUpYGnQgVoFs5W)
			OcZztLHx3P67bIMGv25T['VOD_FROM_NAME_SORTED_'+mutkxRodSEY0l8DJVAP].append(W6WUs1kFXN0VuDmiJGZSxl4RT)
			OcZztLHx3P67bIMGv25T['VOD_FROM_GROUP_SORTED_'+mutkxRodSEY0l8DJVAP].append(todEMR5OGxQuwB6vNWPAhkHcCYI)
	return OcZztLHx3P67bIMGv25T,ffrwHxIuDmyiW0FVtR
def QQ70Aa4Ch2E1p6DNvnTPIMVtj(PrfpcmRL8AHyk):
	if len(PrfpcmRL8AHyk)<3: return PrfpcmRL8AHyk,PrfpcmRL8AHyk
	di8fwIJ3qEjT6zN7,jjNnuQGsJch = '',''
	Pc1HqfYB6rh8jmtw = PrfpcmRL8AHyk
	BBvG2i1MtWz8dOaCDkTZy = PrfpcmRL8AHyk[:1]
	RV6bL8nldCUc = PrfpcmRL8AHyk[1:]
	if   BBvG2i1MtWz8dOaCDkTZy=='(': jjNnuQGsJch = ')'
	elif BBvG2i1MtWz8dOaCDkTZy=='[': jjNnuQGsJch = ']'
	elif BBvG2i1MtWz8dOaCDkTZy=='<': jjNnuQGsJch = '>'
	elif BBvG2i1MtWz8dOaCDkTZy=='|': jjNnuQGsJch = '|'
	if jjNnuQGsJch and (jjNnuQGsJch in RV6bL8nldCUc):
		hhfiHp4dMNOYSo5bwIuzQ,RU2t5qOrX9yTcbdzGF = RV6bL8nldCUc.split(jjNnuQGsJch,1)
		di8fwIJ3qEjT6zN7 = hhfiHp4dMNOYSo5bwIuzQ
		Pc1HqfYB6rh8jmtw = BBvG2i1MtWz8dOaCDkTZy+hhfiHp4dMNOYSo5bwIuzQ+jjNnuQGsJch+' '+RU2t5qOrX9yTcbdzGF
	elif PrfpcmRL8AHyk.count('|')>=2:
		hhfiHp4dMNOYSo5bwIuzQ,RU2t5qOrX9yTcbdzGF = PrfpcmRL8AHyk.split('|',1)
		di8fwIJ3qEjT6zN7 = hhfiHp4dMNOYSo5bwIuzQ
		Pc1HqfYB6rh8jmtw = hhfiHp4dMNOYSo5bwIuzQ+' |'+RU2t5qOrX9yTcbdzGF
	else:
		jjNnuQGsJch = SomeI8i56FaDMGPE.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',PrfpcmRL8AHyk,SomeI8i56FaDMGPE.DOTALL)
		if not jjNnuQGsJch: jjNnuQGsJch = SomeI8i56FaDMGPE.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',PrfpcmRL8AHyk,SomeI8i56FaDMGPE.DOTALL)
		if not jjNnuQGsJch: jjNnuQGsJch = SomeI8i56FaDMGPE.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',PrfpcmRL8AHyk,SomeI8i56FaDMGPE.DOTALL)
		if jjNnuQGsJch:
			hhfiHp4dMNOYSo5bwIuzQ,RU2t5qOrX9yTcbdzGF = PrfpcmRL8AHyk.split(jjNnuQGsJch[0],1)
			di8fwIJ3qEjT6zN7 = hhfiHp4dMNOYSo5bwIuzQ
			Pc1HqfYB6rh8jmtw = hhfiHp4dMNOYSo5bwIuzQ+' '+jjNnuQGsJch[0]+' '+RU2t5qOrX9yTcbdzGF
	Pc1HqfYB6rh8jmtw = Pc1HqfYB6rh8jmtw.replace('   ',' ').replace('  ',' ')
	di8fwIJ3qEjT6zN7 = di8fwIJ3qEjT6zN7.replace('  ',' ')
	if not di8fwIJ3qEjT6zN7: di8fwIJ3qEjT6zN7 = '!!__UNKNOWN__!!'
	di8fwIJ3qEjT6zN7 = di8fwIJ3qEjT6zN7.strip(' ')
	Pc1HqfYB6rh8jmtw = Pc1HqfYB6rh8jmtw.strip(' ')
	return di8fwIJ3qEjT6zN7,Pc1HqfYB6rh8jmtw
def sfp0ID4RdwWQOXbhy(mOEzG4cJoV9erugyXbLI):
	zqbfFORL9jgys3Q = {}
	BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI)
	if BBdeFJGxahsozUmQKycwV2Ak4SE6Ru: zqbfFORL9jgys3Q['User-Agent'] = BBdeFJGxahsozUmQKycwV2Ak4SE6Ru
	ERsLJomNOCf32bB9zKMQlP1TcUqXpi = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.referer_'+mOEzG4cJoV9erugyXbLI)
	if ERsLJomNOCf32bB9zKMQlP1TcUqXpi: zqbfFORL9jgys3Q['Referer'] = ERsLJomNOCf32bB9zKMQlP1TcUqXpi
	return zqbfFORL9jgys3Q
def RMe5svtD8XQKrkzF6h1mpuGBxoITSq(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP):
	global Z8VWRjcHi2OlSwMx9TG4eh6,OcZztLHx3P67bIMGv25T,soYh8DcCeFx,R2GTvAoYtpB9LIOcwh4jqVmSnCNH,MyzhWa8YufbnkIOVSKl5RGQH,ZQVLBS5JyxsHIgleF370,AWwrZ2e3aQjBl0EScqNChFDstVi,XjO7wMi0px9GhIAsKbuH,KzniUj3fFRw2sd8NXpO
	TAgweYM7k9I6WOB1VEU = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI+'_'+mutkxRodSEY0l8DJVAP)
	BBdeFJGxahsozUmQKycwV2Ak4SE6Ru = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.useragent_'+mOEzG4cJoV9erugyXbLI)
	zqbfFORL9jgys3Q = {'User-Agent':BBdeFJGxahsozUmQKycwV2Ak4SE6Ru}
	p7kLF2JIu6wYno = ao80nC2gE3LkOFvI9BTxXqQW5N.replace('___','_'+mOEzG4cJoV9erugyXbLI+'_'+mutkxRodSEY0l8DJVAP)
	if 1:
		TbESvC7xMBAzRyamKtU6uLwI,tSVQqxk67glzK1Zfc,kyO6F5pcQt1q3bw = True,'',''
		if not TbESvC7xMBAzRyamKtU6uLwI:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not TAgweYM7k9I6WOB1VEU: xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   No M3U URL found to download M3U files')
			else: xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(AdKBOaFs5gt3RoNkwLj)+'   Failed to download M3U files')
			return
		rdRxHWGFJ6Z4g7 = rycVB75alp(TAgweYM7k9I6WOB1VEU,zqbfFORL9jgys3Q,True)
		if not rdRxHWGFJ6Z4g7: return
		open(p7kLF2JIu6wYno,'wb').write(rdRxHWGFJ6Z4g7)
	else: rdRxHWGFJ6Z4g7 = open(p7kLF2JIu6wYno,'rb').read()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H and rdRxHWGFJ6Z4g7: rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.decode('utf8')
	Z8VWRjcHi2OlSwMx9TG4eh6 = AAGT9IPy4BoZN7()
	Z8VWRjcHi2OlSwMx9TG4eh6.create('جلب ملفات M3U جديدة','')
	AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,15,'تنظيف الملف الرئيسي','')
	rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.replace('"tvg-','" tvg-')
	rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.replace('group-title=','group=').replace('tvg-','')
	g82fwN6CxAdTl7juk,cO5eQrXZbC8JNop1Fjla = [],[]
	rdRxHWGFJ6Z4g7 = rdRxHWGFJ6Z4g7.replace('\r','\n')
	ZSkChYJp2a1P = SomeI8i56FaDMGPE.findall('NF:(.+?)'+'#'+'EXTI',rdRxHWGFJ6Z4g7+'\n+'+'#'+'EXTINF:',SomeI8i56FaDMGPE.DOTALL)
	if not ZSkChYJp2a1P:
		xrFqGMab4uLKZcS('ERROR_LINES',zybGoPc6tOmwRTWSE2(AdKBOaFs5gt3RoNkwLj)+'   Folder:'+mOEzG4cJoV9erugyXbLI+'  Sequence:'+mutkxRodSEY0l8DJVAP+'   No video links found in M3U file')
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+mOEzG4cJoV9erugyXbLI+'      رابط رقم '+mutkxRodSEY0l8DJVAP+'[/COLOR]')
		Z8VWRjcHi2OlSwMx9TG4eh6.close()
		return
	x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM = []
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		R3EBpvTyXUiZna7oth45bzAH8GqjF = bDuvmIw28GRWVCBaOsT3HneLSt.lower()
		if 'adult' in R3EBpvTyXUiZna7oth45bzAH8GqjF: continue
		if 'xxx' in R3EBpvTyXUiZna7oth45bzAH8GqjF: continue
		x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM.append(bDuvmIw28GRWVCBaOsT3HneLSt)
	ZSkChYJp2a1P = x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM
	del x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM
	if 'iptv-org' in TAgweYM7k9I6WOB1VEU:
		x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM,ZBjhe8gG7Fiq1HYraxDIk = [],[]
		for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
			ZQVLBS5JyxsHIgleF370 = SomeI8i56FaDMGPE.findall('group="(.*?)"',bDuvmIw28GRWVCBaOsT3HneLSt,SomeI8i56FaDMGPE.DOTALL)
			if ZQVLBS5JyxsHIgleF370:
				ZQVLBS5JyxsHIgleF370 = ZQVLBS5JyxsHIgleF370[0]
				jb1sPS7ruMYpEG02c9n = ZQVLBS5JyxsHIgleF370.split(';')
				if 'region' in TAgweYM7k9I6WOB1VEU: lBg48qDhtuPo = '1_'
				elif 'category' in TAgweYM7k9I6WOB1VEU: lBg48qDhtuPo = '2_'
				elif 'language' in TAgweYM7k9I6WOB1VEU: lBg48qDhtuPo = '3_'
				elif 'country' in TAgweYM7k9I6WOB1VEU: lBg48qDhtuPo = '4_'
				else: lBg48qDhtuPo = '5_'
				TTwLn16WUE = bDuvmIw28GRWVCBaOsT3HneLSt.replace('group="'+ZQVLBS5JyxsHIgleF370+'"','group="'+lBg48qDhtuPo+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM.append(TTwLn16WUE)
				for kvbO7aXiqA0H2JUPoRh in jb1sPS7ruMYpEG02c9n:
					TTwLn16WUE = bDuvmIw28GRWVCBaOsT3HneLSt.replace('group="'+ZQVLBS5JyxsHIgleF370+'"','group="'+lBg48qDhtuPo+kvbO7aXiqA0H2JUPoRh+'"')
					x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM.append(TTwLn16WUE)
			else: x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM.append(bDuvmIw28GRWVCBaOsT3HneLSt)
		ZSkChYJp2a1P = x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM
		del x1wZ2WsRLXKjiCruJGfg9m4nh7dEHM,ZBjhe8gG7Fiq1HYraxDIk
	hNgZTHKdO56 = 1024*1024
	NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG = 1+len(rdRxHWGFJ6Z4g7)//hNgZTHKdO56//10
	del rdRxHWGFJ6Z4g7
	qbsktUhRGL1FMDrVxTO2w95IXE8H3Z = len(ZSkChYJp2a1P)
	ZBjhe8gG7Fiq1HYraxDIk = ms076oaLEyUPNXIHkTuBnWjipCeS8R(ZSkChYJp2a1P,NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG)
	del ZSkChYJp2a1P
	for N6N8FlJCqco7hg in range(NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG):
		AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,35+int(5*N6N8FlJCqco7hg/NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG),'تقطيع الملف الرئيسي','الجزء رقم:-',str(N6N8FlJCqco7hg+1)+' / '+str(NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG))
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
		IIsTiSh9LbJdHFB5Ulo1uV = str(ZBjhe8gG7Fiq1HYraxDIk[N6N8FlJCqco7hg])
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: IIsTiSh9LbJdHFB5Ulo1uV = IIsTiSh9LbJdHFB5Ulo1uV.encode('utf8')
		open(p7kLF2JIu6wYno+'.00'+str(N6N8FlJCqco7hg),'wb').write(IIsTiSh9LbJdHFB5Ulo1uV)
	del ZBjhe8gG7Fiq1HYraxDIk,IIsTiSh9LbJdHFB5Ulo1uV
	mXfu60Z83NoHq9JydjOrLi,mmGDKu7NynFI6QYLOiSrXf5Hcwt,Ef9XDLmV7wByGWshRqnb654Z = [],[],0
	for N6N8FlJCqco7hg in range(NZHLaoRpe4VxrWvPS6Obyd2Fg0mBG):
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
		IIsTiSh9LbJdHFB5Ulo1uV = open(p7kLF2JIu6wYno+'.00'+str(N6N8FlJCqco7hg),'rb').read()
		p1BoraOuWL.sleep(1)
		try: Dh9MOxeTj6FW.remove(p7kLF2JIu6wYno+'.00'+str(N6N8FlJCqco7hg))
		except: pass
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: IIsTiSh9LbJdHFB5Ulo1uV = IIsTiSh9LbJdHFB5Ulo1uV.decode('utf8')
		wUbm6JLO2EWhvRlpQYHSPi30 = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('list',IIsTiSh9LbJdHFB5Ulo1uV)
		del IIsTiSh9LbJdHFB5Ulo1uV
		VVxRSC9foEJiOlUNIh,Ef9XDLmV7wByGWshRqnb654Z,ffrwHxIuDmyiW0FVtR = dEeZpTURnmGkF(wUbm6JLO2EWhvRlpQYHSPi30,cO5eQrXZbC8JNop1Fjla,g82fwN6CxAdTl7juk,Z8VWRjcHi2OlSwMx9TG4eh6,qbsktUhRGL1FMDrVxTO2w95IXE8H3Z,Ef9XDLmV7wByGWshRqnb654Z,TAgweYM7k9I6WOB1VEU)
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
		if not VVxRSC9foEJiOlUNIh:
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
		mmGDKu7NynFI6QYLOiSrXf5Hcwt += VVxRSC9foEJiOlUNIh
		mXfu60Z83NoHq9JydjOrLi += ffrwHxIuDmyiW0FVtR
	del wUbm6JLO2EWhvRlpQYHSPi30,VVxRSC9foEJiOlUNIh
	OcZztLHx3P67bIMGv25T,ffrwHxIuDmyiW0FVtR = t6C0gUaPvzjyxeoYup7rSEXOVWhnkD(mmGDKu7NynFI6QYLOiSrXf5Hcwt,Z8VWRjcHi2OlSwMx9TG4eh6,mutkxRodSEY0l8DJVAP)
	if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
		Z8VWRjcHi2OlSwMx9TG4eh6.close()
		return
	mXfu60Z83NoHq9JydjOrLi += ffrwHxIuDmyiW0FVtR
	del mmGDKu7NynFI6QYLOiSrXf5Hcwt,ffrwHxIuDmyiW0FVtR
	R2GTvAoYtpB9LIOcwh4jqVmSnCNH,MyzhWa8YufbnkIOVSKl5RGQH,ZQVLBS5JyxsHIgleF370,AWwrZ2e3aQjBl0EScqNChFDstVi,XjO7wMi0px9GhIAsKbuH = {},{},{},0,0
	gqNbVhmUBcKL3wXQ = list(OcZztLHx3P67bIMGv25T.keys())
	KzniUj3fFRw2sd8NXpO = len(gqNbVhmUBcKL3wXQ)*3
	if 1:
		D5MxEsKl0LzogT3VAX8JYdiSI1tjF9 = {}
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh] = RrCB5k9XV6hYNSlIKJ2.Thread(target=AVuY1HQPkOcW,args=(sDadiY5cfA3MjkwbyungURQ4HCh,))
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh].start()
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh].join()
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
	else:
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			AVuY1HQPkOcW(sDadiY5cfA3MjkwbyungURQ4HCh)
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return
	Ta5Et9jPIYGURAvxBc7(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP,False)
	gqNbVhmUBcKL3wXQ = list(R2GTvAoYtpB9LIOcwh4jqVmSnCNH.keys())
	soYh8DcCeFx = 0
	if 1:
		D5MxEsKl0LzogT3VAX8JYdiSI1tjF9 = {}
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh] = RrCB5k9XV6hYNSlIKJ2.Thread(target=BqpusIO6jy7rvTzFa5MAwClbgk0f4,args=(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh))
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh].start()
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[sDadiY5cfA3MjkwbyungURQ4HCh].join()
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
			Z8VWRjcHi2OlSwMx9TG4eh6.close()
			return
	else:
		for sDadiY5cfA3MjkwbyungURQ4HCh in gqNbVhmUBcKL3wXQ:
			BqpusIO6jy7rvTzFa5MAwClbgk0f4(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh)
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return
	N6N8FlJCqco7hg = 0
	QDA9ifPhS5U = len(mXfu60Z83NoHq9JydjOrLi)
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'IGNORED')
	for T9pDUqP410RuMfdo3ihKvl in mXfu60Z83NoHq9JydjOrLi:
		if N6N8FlJCqco7hg%27==0:
			AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,95+int(5*N6N8FlJCqco7hg//QDA9ifPhS5U),'تخزين المهملة','الفيديو رقم:-',str(N6N8FlJCqco7hg)+' / '+str(QDA9ifPhS5U))
			if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled():
				Z8VWRjcHi2OlSwMx9TG4eh6.close()
				return
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,'IGNORED_'+mutkxRodSEY0l8DJVAP,str(T9pDUqP410RuMfdo3ihKvl),'',bY2n5MtVA4cjpkFSxZ6K)
		N6N8FlJCqco7hg += 1
	F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,'IGNORED_'+mutkxRodSEY0l8DJVAP,'__COUNT__',str(QDA9ifPhS5U),bY2n5MtVA4cjpkFSxZ6K)
	Z8VWRjcHi2OlSwMx9TG4eh6.close()
	p1BoraOuWL.sleep(1)
	e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI)
	return
def AVuY1HQPkOcW(sDadiY5cfA3MjkwbyungURQ4HCh):
	global Z8VWRjcHi2OlSwMx9TG4eh6,OcZztLHx3P67bIMGv25T,soYh8DcCeFx,R2GTvAoYtpB9LIOcwh4jqVmSnCNH,MyzhWa8YufbnkIOVSKl5RGQH,ZQVLBS5JyxsHIgleF370,AWwrZ2e3aQjBl0EScqNChFDstVi,XjO7wMi0px9GhIAsKbuH,KzniUj3fFRw2sd8NXpO
	R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh] = {}
	NOhEdDuUSfmi437IqyaBXcxe68MGKA,T9H4Bd5RUteOV0nZP1N = {},[]
	zLx3VNO4pTFi2 = len(OcZztLHx3P67bIMGv25T[sDadiY5cfA3MjkwbyungURQ4HCh])
	R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh]['__COUNT__'] = zLx3VNO4pTFi2
	if zLx3VNO4pTFi2>0:
		fomuRpEsQ635FxjeryNnWJhHVw,V56Vdneb3LqwHz2KjR4MPX9v,HjALv9o0RtfZU5VKBelQxhr,NNT6eX5cOKxEsDuj,AOCeXi6Mcvd9k7HREfgUnoBYz3 = zip(*OcZztLHx3P67bIMGv25T[sDadiY5cfA3MjkwbyungURQ4HCh])
		del V56Vdneb3LqwHz2KjR4MPX9v,HjALv9o0RtfZU5VKBelQxhr,NNT6eX5cOKxEsDuj
		jb1sPS7ruMYpEG02c9n = list(set(fomuRpEsQ635FxjeryNnWJhHVw))
		for kvbO7aXiqA0H2JUPoRh in jb1sPS7ruMYpEG02c9n:
			NOhEdDuUSfmi437IqyaBXcxe68MGKA[kvbO7aXiqA0H2JUPoRh] = ''
			R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh][kvbO7aXiqA0H2JUPoRh] = []
		AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,60+int(15*XjO7wMi0px9GhIAsKbuH//KzniUj3fFRw2sd8NXpO),'تصنيع القوائم','الجزء رقم:-',str(XjO7wMi0px9GhIAsKbuH)+' / '+str(KzniUj3fFRw2sd8NXpO))
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled(): return
		XjO7wMi0px9GhIAsKbuH += 1
		UxLY8QJ6PSlpfb = len(jb1sPS7ruMYpEG02c9n)
		del jb1sPS7ruMYpEG02c9n
		T9H4Bd5RUteOV0nZP1N = list(set(zip(fomuRpEsQ635FxjeryNnWJhHVw,AOCeXi6Mcvd9k7HREfgUnoBYz3)))
		del fomuRpEsQ635FxjeryNnWJhHVw,AOCeXi6Mcvd9k7HREfgUnoBYz3
		for kvbO7aXiqA0H2JUPoRh,V56GckjYK2vUw9 in T9H4Bd5RUteOV0nZP1N:
			if not NOhEdDuUSfmi437IqyaBXcxe68MGKA[kvbO7aXiqA0H2JUPoRh] and V56GckjYK2vUw9: NOhEdDuUSfmi437IqyaBXcxe68MGKA[kvbO7aXiqA0H2JUPoRh] = V56GckjYK2vUw9
		AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,60+int(15*XjO7wMi0px9GhIAsKbuH//KzniUj3fFRw2sd8NXpO),'تصنيع القوائم','الجزء رقم:-',str(XjO7wMi0px9GhIAsKbuH)+' / '+str(KzniUj3fFRw2sd8NXpO))
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled(): return
		XjO7wMi0px9GhIAsKbuH += 1
		xPH8hnDbUySdam7 = list(NOhEdDuUSfmi437IqyaBXcxe68MGKA.keys())
		ysFcm3V5Ilb40XNjWfYo = list(NOhEdDuUSfmi437IqyaBXcxe68MGKA.values())
		del NOhEdDuUSfmi437IqyaBXcxe68MGKA
		T9H4Bd5RUteOV0nZP1N = list(zip(xPH8hnDbUySdam7,ysFcm3V5Ilb40XNjWfYo))
		del xPH8hnDbUySdam7,ysFcm3V5Ilb40XNjWfYo
		T9H4Bd5RUteOV0nZP1N = sorted(T9H4Bd5RUteOV0nZP1N)
	else: XjO7wMi0px9GhIAsKbuH += 2
	R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh]['__GROUPS__'] = T9H4Bd5RUteOV0nZP1N
	del T9H4Bd5RUteOV0nZP1N
	for kvbO7aXiqA0H2JUPoRh,lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 in OcZztLHx3P67bIMGv25T[sDadiY5cfA3MjkwbyungURQ4HCh]:
		R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh][kvbO7aXiqA0H2JUPoRh].append((lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0))
	AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,60+int(15*XjO7wMi0px9GhIAsKbuH//KzniUj3fFRw2sd8NXpO),'تصنيع القوائم','الجزء رقم:-',str(XjO7wMi0px9GhIAsKbuH)+' / '+str(KzniUj3fFRw2sd8NXpO))
	if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled(): return
	XjO7wMi0px9GhIAsKbuH += 1
	del OcZztLHx3P67bIMGv25T[sDadiY5cfA3MjkwbyungURQ4HCh]
	ZQVLBS5JyxsHIgleF370[sDadiY5cfA3MjkwbyungURQ4HCh] = list(R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh].keys())
	MyzhWa8YufbnkIOVSKl5RGQH[sDadiY5cfA3MjkwbyungURQ4HCh] = len(ZQVLBS5JyxsHIgleF370[sDadiY5cfA3MjkwbyungURQ4HCh])
	AWwrZ2e3aQjBl0EScqNChFDstVi += MyzhWa8YufbnkIOVSKl5RGQH[sDadiY5cfA3MjkwbyungURQ4HCh]
	return
def BqpusIO6jy7rvTzFa5MAwClbgk0f4(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh):
	global Z8VWRjcHi2OlSwMx9TG4eh6,OcZztLHx3P67bIMGv25T,soYh8DcCeFx,R2GTvAoYtpB9LIOcwh4jqVmSnCNH,MyzhWa8YufbnkIOVSKl5RGQH,ZQVLBS5JyxsHIgleF370,AWwrZ2e3aQjBl0EScqNChFDstVi,XjO7wMi0px9GhIAsKbuH,KzniUj3fFRw2sd8NXpO
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh)
	for Ef9XDLmV7wByGWshRqnb654Z in range(1+MyzhWa8YufbnkIOVSKl5RGQH[sDadiY5cfA3MjkwbyungURQ4HCh]//273):
		qUGkvzRgHFt = []
		lFEA3cSxOVYXHkDnT9h = ZQVLBS5JyxsHIgleF370[sDadiY5cfA3MjkwbyungURQ4HCh][0:273]
		for kvbO7aXiqA0H2JUPoRh in lFEA3cSxOVYXHkDnT9h:
			qUGkvzRgHFt.append(R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh][kvbO7aXiqA0H2JUPoRh])
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,sDadiY5cfA3MjkwbyungURQ4HCh,lFEA3cSxOVYXHkDnT9h,qUGkvzRgHFt,bY2n5MtVA4cjpkFSxZ6K,True)
		soYh8DcCeFx += len(lFEA3cSxOVYXHkDnT9h)
		AYqVCTWQcUuB18DzLR97OtHo(Z8VWRjcHi2OlSwMx9TG4eh6,75+int(20*soYh8DcCeFx//AWwrZ2e3aQjBl0EScqNChFDstVi),'تخزين القوائم','القائمة رقم:-',str(soYh8DcCeFx)+' / '+str(AWwrZ2e3aQjBl0EScqNChFDstVi))
		if Z8VWRjcHi2OlSwMx9TG4eh6.iscanceled(): return
		del ZQVLBS5JyxsHIgleF370[sDadiY5cfA3MjkwbyungURQ4HCh][0:273]
	del R2GTvAoYtpB9LIOcwh4jqVmSnCNH[sDadiY5cfA3MjkwbyungURQ4HCh],ZQVLBS5JyxsHIgleF370[sDadiY5cfA3MjkwbyungURQ4HCh],MyzhWa8YufbnkIOVSKl5RGQH[sDadiY5cfA3MjkwbyungURQ4HCh]
	return
def KlnS5uXmHdEGhJ(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP,SKyG3D4CgRJW7qArbhHljzi6Q=True):
	LTV7xf6hapIsd52mkGAXcgyDo = 'عدد فيديوهات جميع الروابط'
	JBNCip6UgWOMQjxVGutzvrS4o = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'LIVE_ORIGINAL_GROUPED')
	Srz7jDsJIXe95y8 = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'VOD_ORIGINAL_GROUPED')
	if mutkxRodSEY0l8DJVAP:
		LTV7xf6hapIsd52mkGAXcgyDo = 'عدد فيديوهات رابط '+h6OYx3P5fiRXg2LoBK8[int(mutkxRodSEY0l8DJVAP)]
		mutkxRodSEY0l8DJVAP = '_'+mutkxRodSEY0l8DJVAP
	QDA9ifPhS5U = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','IGNORED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	xo0KG4MRv9L = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','LIVE_ORIGINAL_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	wwu3aTvt2IbZ9JXe4OF = yu1pYA2VRHzr876gPJdDw(Srz7jDsJIXe95y8,'int','VOD_ORIGINAL_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	iZlJ21qckB5YuOnGfhHb087vrP = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','LIVE_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	xAqhyaSLW8OcX2NRHDG7t = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','LIVE_UNKNOWN_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	kbsCgVX7R0cDmdUvurAw3E1pIFGfoS = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','VOD_MOVIES_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	i16cG7wtTOxDWqLXYNhAjaK = yu1pYA2VRHzr876gPJdDw(Srz7jDsJIXe95y8,'int','VOD_SERIES_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	JtNlLqoHYRf92 = yu1pYA2VRHzr876gPJdDw(JBNCip6UgWOMQjxVGutzvrS4o,'int','VOD_UNKNOWN_GROUPED'+mutkxRodSEY0l8DJVAP,'__COUNT__')
	ZQVLBS5JyxsHIgleF370 = yu1pYA2VRHzr876gPJdDw(Srz7jDsJIXe95y8,'list','VOD_SERIES_GROUPED'+mutkxRodSEY0l8DJVAP,'__GROUPS__')
	l739pmYUcsQFhkyq = []
	for kvbO7aXiqA0H2JUPoRh,ixHfKALJzXyoYt0 in ZQVLBS5JyxsHIgleF370:
		l190jyWRfuMEVY = kvbO7aXiqA0H2JUPoRh.split('__SERIES__')[1]
		l739pmYUcsQFhkyq.append(l190jyWRfuMEVY)
	mmgqBNhcbp38oUaZTQGwy9kV = len(l739pmYUcsQFhkyq)
	uHKTyMEW7ZGYvnFSaBINcs0XpO = int(kbsCgVX7R0cDmdUvurAw3E1pIFGfoS)+int(i16cG7wtTOxDWqLXYNhAjaK)+int(JtNlLqoHYRf92)+int(xAqhyaSLW8OcX2NRHDG7t)+int(iZlJ21qckB5YuOnGfhHb087vrP)
	mYALwDXM4nfBFqdhRro = ''
	mYALwDXM4nfBFqdhRro += 'قنوات: '+str(iZlJ21qckB5YuOnGfhHb087vrP)
	mYALwDXM4nfBFqdhRro += '   .   أفلام: '+str(kbsCgVX7R0cDmdUvurAw3E1pIFGfoS)
	mYALwDXM4nfBFqdhRro += '\nمسلسلات: '+str(mmgqBNhcbp38oUaZTQGwy9kV)
	mYALwDXM4nfBFqdhRro += '   .   حلقات: '+str(i16cG7wtTOxDWqLXYNhAjaK)
	mYALwDXM4nfBFqdhRro += '\nقنوات مجهولة: '+str(xAqhyaSLW8OcX2NRHDG7t)
	mYALwDXM4nfBFqdhRro += '   .   فيدوهات مجهولة: '+str(JtNlLqoHYRf92)
	mYALwDXM4nfBFqdhRro += '\nمجموع القنوات: '+str(xo0KG4MRv9L)
	mYALwDXM4nfBFqdhRro += '   .   مجموع الفيديوهات: '+str(wwu3aTvt2IbZ9JXe4OF)
	mYALwDXM4nfBFqdhRro += '\n\nمجموع المضافة: '+str(uHKTyMEW7ZGYvnFSaBINcs0XpO)
	mYALwDXM4nfBFqdhRro += '   .   مجموع المهملة: '+str(QDA9ifPhS5U)
	if SKyG3D4CgRJW7qArbhHljzi6Q: ztgqWUaDpe8CE9N('center','',LTV7xf6hapIsd52mkGAXcgyDo,mYALwDXM4nfBFqdhRro)
	xG4lTHtDcavBqum9U3djIC = mYALwDXM4nfBFqdhRro.replace('\n\n','\n')
	if not mutkxRodSEY0l8DJVAP: mutkxRodSEY0l8DJVAP = 'All'
	else: mutkxRodSEY0l8DJVAP = mutkxRodSEY0l8DJVAP[1]
	xrFqGMab4uLKZcS('NOTICE','.  Counts of M3U videos   Folder: '+mOEzG4cJoV9erugyXbLI+'   Sequence: '+mutkxRodSEY0l8DJVAP+'\n'+xG4lTHtDcavBqum9U3djIC)
	return mYALwDXM4nfBFqdhRro
def Ta5Et9jPIYGURAvxBc7(mOEzG4cJoV9erugyXbLI,mutkxRodSEY0l8DJVAP,SKyG3D4CgRJW7qArbhHljzi6Q=True):
	if SKyG3D4CgRJW7qArbhHljzi6Q:
		yka0pczgxUV = nEYJ5OCXG0gcNy('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if yka0pczgxUV!=1: return
		nxDfqd3TusCM69Otel = ao80nC2gE3LkOFvI9BTxXqQW5N.replace('___','_'+mOEzG4cJoV9erugyXbLI+'_'+mutkxRodSEY0l8DJVAP)
		try: Dh9MOxeTj6FW.remove(nxDfqd3TusCM69Otel)
		except: pass
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'')
	if mutkxRodSEY0l8DJVAP:
		gZIUdnFeDO71LQAz0NEmc = []
		for Hmz9PFDbdajReTQso in H56tOjf2BZNiSCUKYsozXA4gdvGuxR:
			gZIUdnFeDO71LQAz0NEmc.append(Hmz9PFDbdajReTQso+'_'+mutkxRodSEY0l8DJVAP)
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,'LINK_'+mutkxRodSEY0l8DJVAP)
	else:
		gZIUdnFeDO71LQAz0NEmc = H56tOjf2BZNiSCUKYsozXA4gdvGuxR
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,'DUMMY')
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,'GROUPS')
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,'ITEMS')
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,'SEARCH')
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_'+mOEzG4cJoV9erugyXbLI)
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for sDadiY5cfA3MjkwbyungURQ4HCh in gZIUdnFeDO71LQAz0NEmc:
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,sDadiY5cfA3MjkwbyungURQ4HCh)
	W2sm89LliTnf(False)
	e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI)
	if SKyG3D4CgRJW7qArbhHljzi6Q: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI='',SKyG3D4CgRJW7qArbhHljzi6Q=True):
	if mOEzG4cJoV9erugyXbLI:
		c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(str(mOEzG4cJoV9erugyXbLI),'DUMMY')
		LL5opKn1gkuEZPf = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'str','DUMMY','__DUMMY__')
		if LL5opKn1gkuEZPf: return True
	else:
		mOEzG4cJoV9erugyXbLI = '1'
		for NNnMxcRFDbEiuB3LzYoGa8XhsCrT in range(1,gx4WbX9yDPm6lk+1):
			c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(str(NNnMxcRFDbEiuB3LzYoGa8XhsCrT),'DUMMY')
			LL5opKn1gkuEZPf = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'str','DUMMY','__DUMMY__')
			if LL5opKn1gkuEZPf: return True
	if SKyG3D4CgRJW7qArbhHljzi6Q:
		E0KNwgItVrU = 'https://iptv-org.github.io/iptv/index.region.m3u'
		mQsUTBJAyrRqeC6gZO2wMdbVFzWh = 'https://iptv-org.github.io/iptv/index.category.m3u'
		LCiwhazFEBKvZsnA = 'https://iptv-org.github.io/iptv/index.language.m3u'
		j1Doy8O2LaHZMAsQFNehl = 'https://iptv-org.github.io/iptv/index.country.m3u'
		MEODmChrygFstHN = E0KNwgItVrU+'\n'+mQsUTBJAyrRqeC6gZO2wMdbVFzWh+'\n'+LCiwhazFEBKvZsnA+'\n'+j1Doy8O2LaHZMAsQFNehl
		yka0pczgxUV = nEYJ5OCXG0gcNy('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+MEODmChrygFstHN+'[/COLOR]',profile='confirm_mediumfont')
		if yka0pczgxUV==1:
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.url_'+str(mOEzG4cJoV9erugyXbLI)+'_1',E0KNwgItVrU)
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.url_'+str(mOEzG4cJoV9erugyXbLI)+'_2',mQsUTBJAyrRqeC6gZO2wMdbVFzWh)
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.url_'+str(mOEzG4cJoV9erugyXbLI)+'_3',LCiwhazFEBKvZsnA)
			LCIFdjzi5kVmRwehouHQ.setSetting('av.m3u.url_'+str(mOEzG4cJoV9erugyXbLI)+'_4',j1Doy8O2LaHZMAsQFNehl)
			yka0pczgxUV = nEYJ5OCXG0gcNy('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if yka0pczgxUV==1:
				ElRn52QjI9VM = snxaPmhUME(mOEzG4cJoV9erugyXbLI)
				return ElRn52QjI9VM
		else:
			LTV7xf6hapIsd52mkGAXcgyDo = 'إضافة وتغيير رابط '+h6OYx3P5fiRXg2LoBK8[1]+' (مجلد '+h6OYx3P5fiRXg2LoBK8[int(mOEzG4cJoV9erugyXbLI)]+')'
			yka0pczgxUV = nEYJ5OCXG0gcNy('','','',LTV7xf6hapIsd52mkGAXcgyDo,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if yka0pczgxUV==1: kGUQdpiLTEWPezxKDv9hNAf(mOEzG4cJoV9erugyXbLI,'1')
	return False
def YnCWskJzK9IRacANQ0UgZ(cOmLPg1usxz940YrjMUvdNBykla,mOEzG4cJoV9erugyXbLI='',sDadiY5cfA3MjkwbyungURQ4HCh='',vUHwKfh5mz6=''):
	if not vUHwKfh5mz6: vUHwKfh5mz6 = '1'
	c1qUnGRSoEZPefVhWv,TZKIYEDaF04ohvjrn,SKyG3D4CgRJW7qArbhHljzi6Q = Xj2G0VZ876Idy(cOmLPg1usxz940YrjMUvdNBykla)
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q): return
	if not c1qUnGRSoEZPefVhWv:
		c1qUnGRSoEZPefVhWv = ymH9jzg2KId5MCvw8lXBZn()
		if not c1qUnGRSoEZPefVhWv: return
	fqWtUJgYAj7G2lbpCFayohw = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not sDadiY5cfA3MjkwbyungURQ4HCh:
		if not SKyG3D4CgRJW7qArbhHljzi6Q:
			if   '_M3U-LIVE_' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[1]
			elif '_M3U-MOVIES' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[2]
			elif '_M3U-SERIES' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[3]
			else: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[0]
		else:
			KN0RFDMH4p = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			U94D8BejHMsrLzO27IRpFEhC6wP = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر البحث المناسب', KN0RFDMH4p)
			if U94D8BejHMsrLzO27IRpFEhC6wP==-1: return
			sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[U94D8BejHMsrLzO27IRpFEhC6wP]
	c1qUnGRSoEZPefVhWv = c1qUnGRSoEZPefVhWv+'_NODIALOGS_'
	if mOEzG4cJoV9erugyXbLI: EvJm4oHYlu0FLe7AUi1Ws8MCaGq(c1qUnGRSoEZPefVhWv,mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh,vUHwKfh5mz6)
	else:
		for mOEzG4cJoV9erugyXbLI in range(1,gx4WbX9yDPm6lk+1):
			EvJm4oHYlu0FLe7AUi1Ws8MCaGq(c1qUnGRSoEZPefVhWv,str(mOEzG4cJoV9erugyXbLI),sDadiY5cfA3MjkwbyungURQ4HCh,vUHwKfh5mz6)
		nUTgq0SFfC9[:] = sorted(nUTgq0SFfC9,reverse=False,key=lambda VVKGWbIES9Ns5dwuiUBt2re: VVKGWbIES9Ns5dwuiUBt2re[1].lower())
	return
def EvJm4oHYlu0FLe7AUi1Ws8MCaGq(cOmLPg1usxz940YrjMUvdNBykla,mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh='',vUHwKfh5mz6=''):
	if not vUHwKfh5mz6: vUHwKfh5mz6 = '1'
	c1qUnGRSoEZPefVhWv,TZKIYEDaF04ohvjrn,SKyG3D4CgRJW7qArbhHljzi6Q = Xj2G0VZ876Idy(cOmLPg1usxz940YrjMUvdNBykla)
	if not mOEzG4cJoV9erugyXbLI: return
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q): return
	if not c1qUnGRSoEZPefVhWv:
		c1qUnGRSoEZPefVhWv = ymH9jzg2KId5MCvw8lXBZn()
		if not c1qUnGRSoEZPefVhWv: return
	fqWtUJgYAj7G2lbpCFayohw = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not sDadiY5cfA3MjkwbyungURQ4HCh:
		if not SKyG3D4CgRJW7qArbhHljzi6Q:
			if   '_M3U-LIVE_' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[1]
			elif '_M3U-MOVIES' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[2]
			elif '_M3U-SERIES' in TZKIYEDaF04ohvjrn: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[3]
			else: sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[0]
		else:
			KN0RFDMH4p = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			U94D8BejHMsrLzO27IRpFEhC6wP = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر البحث المناسب', KN0RFDMH4p)
			if U94D8BejHMsrLzO27IRpFEhC6wP==-1: return
			sDadiY5cfA3MjkwbyungURQ4HCh = fqWtUJgYAj7G2lbpCFayohw[U94D8BejHMsrLzO27IRpFEhC6wP]
	M1MNEofiLeUWSRqXzsmpOrJknH6Y = c1qUnGRSoEZPefVhWv.lower()
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'SEARCH')
	EIBNGzDg8LUe4w = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list','SEARCH',(sDadiY5cfA3MjkwbyungURQ4HCh,M1MNEofiLeUWSRqXzsmpOrJknH6Y))
	if not EIBNGzDg8LUe4w:
		kkDjx8VpG4R,jI5Y0PkRpEXvNJxAnSqB21tTKLW8 = [],[]
		if not sDadiY5cfA3MjkwbyungURQ4HCh: o53WhGm6qvwLMHX91lbNxU8cB0tOY = [1,2,3,4,5]
		else: o53WhGm6qvwLMHX91lbNxU8cB0tOY = [fqWtUJgYAj7G2lbpCFayohw.index(sDadiY5cfA3MjkwbyungURQ4HCh)]
		for N6N8FlJCqco7hg in o53WhGm6qvwLMHX91lbNxU8cB0tOY:
			if N6N8FlJCqco7hg!=3:
				VVxRSC9foEJiOlUNIh = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'dict',fqWtUJgYAj7G2lbpCFayohw[N6N8FlJCqco7hg])
				del VVxRSC9foEJiOlUNIh['__COUNT__']
				del VVxRSC9foEJiOlUNIh['__GROUPS__']
				del VVxRSC9foEJiOlUNIh['__SEQUENCED_COLUMNS__']
				ZQVLBS5JyxsHIgleF370 = list(VVxRSC9foEJiOlUNIh.keys())
				for kvbO7aXiqA0H2JUPoRh in ZQVLBS5JyxsHIgleF370:
					for lsfFwOE5rvtgxQCBo14VU,PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 in VVxRSC9foEJiOlUNIh[kvbO7aXiqA0H2JUPoRh]:
						if M1MNEofiLeUWSRqXzsmpOrJknH6Y in PrfpcmRL8AHyk.lower(): jI5Y0PkRpEXvNJxAnSqB21tTKLW8.append((PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0))
					del VVxRSC9foEJiOlUNIh[kvbO7aXiqA0H2JUPoRh]
				del VVxRSC9foEJiOlUNIh
			else: ZQVLBS5JyxsHIgleF370 = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'list',fqWtUJgYAj7G2lbpCFayohw[N6N8FlJCqco7hg],'__GROUPS__')
			for kvbO7aXiqA0H2JUPoRh in ZQVLBS5JyxsHIgleF370:
				try: kvbO7aXiqA0H2JUPoRh,ixHfKALJzXyoYt0 = kvbO7aXiqA0H2JUPoRh
				except: ixHfKALJzXyoYt0 = ''
				if M1MNEofiLeUWSRqXzsmpOrJknH6Y in kvbO7aXiqA0H2JUPoRh.lower():
					if N6N8FlJCqco7hg!=3: KKatnT5k3QFpX = kvbO7aXiqA0H2JUPoRh
					else:
						JxrDXO2qHYIpaAP9kj3CRNnSW4l,OkQ5sDUVeht = kvbO7aXiqA0H2JUPoRh.split('__SERIES__')
						if M1MNEofiLeUWSRqXzsmpOrJknH6Y in JxrDXO2qHYIpaAP9kj3CRNnSW4l.lower(): KKatnT5k3QFpX = JxrDXO2qHYIpaAP9kj3CRNnSW4l
						else: KKatnT5k3QFpX = OkQ5sDUVeht
					kkDjx8VpG4R.append((kvbO7aXiqA0H2JUPoRh,KKatnT5k3QFpX,fqWtUJgYAj7G2lbpCFayohw[N6N8FlJCqco7hg],ixHfKALJzXyoYt0))
			del ZQVLBS5JyxsHIgleF370
		kkDjx8VpG4R = set(kkDjx8VpG4R)
		jI5Y0PkRpEXvNJxAnSqB21tTKLW8 = set(jI5Y0PkRpEXvNJxAnSqB21tTKLW8)
		kkDjx8VpG4R = sorted(kkDjx8VpG4R,reverse=False,key=lambda VVKGWbIES9Ns5dwuiUBt2re: VVKGWbIES9Ns5dwuiUBt2re[1])
		jI5Y0PkRpEXvNJxAnSqB21tTKLW8 = sorted(jI5Y0PkRpEXvNJxAnSqB21tTKLW8,reverse=False,key=lambda VVKGWbIES9Ns5dwuiUBt2re: VVKGWbIES9Ns5dwuiUBt2re[0])
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,'SEARCH',(sDadiY5cfA3MjkwbyungURQ4HCh,M1MNEofiLeUWSRqXzsmpOrJknH6Y),(kkDjx8VpG4R,jI5Y0PkRpEXvNJxAnSqB21tTKLW8),bY2n5MtVA4cjpkFSxZ6K)
	else: kkDjx8VpG4R,jI5Y0PkRpEXvNJxAnSqB21tTKLW8 = EIBNGzDg8LUe4w
	ZQVLBS5JyxsHIgleF370 = len(kkDjx8VpG4R)
	RzoXf9tEuVTe5 = len(jI5Y0PkRpEXvNJxAnSqB21tTKLW8)
	B2Axl9aIWKdUXNTEtc0YjCR5yPF = int(vUHwKfh5mz6)
	WWwsCr2DY7MIqp3eL = max(0,(B2Axl9aIWKdUXNTEtc0YjCR5yPF-1)*100)
	JXzHmDk1S2MhNAPOLpRE5cUQWuIoa0 = max(0,B2Axl9aIWKdUXNTEtc0YjCR5yPF*100)
	DGqCNbTtJc = max(0,WWwsCr2DY7MIqp3eL-ZQVLBS5JyxsHIgleF370)
	MDp1TG9m0zHqXjhUCbSQ6RwBV7 = max(0,JXzHmDk1S2MhNAPOLpRE5cUQWuIoa0-ZQVLBS5JyxsHIgleF370)
	for kvbO7aXiqA0H2JUPoRh,KKatnT5k3QFpX,pYTJkz3EZ1KFbosW5i7AG,ixHfKALJzXyoYt0 in kkDjx8VpG4R[WWwsCr2DY7MIqp3eL:JXzHmDk1S2MhNAPOLpRE5cUQWuIoa0]:
		UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+KKatnT5k3QFpX,pYTJkz3EZ1KFbosW5i7AG,714,ixHfKALJzXyoYt0,'1',kvbO7aXiqA0H2JUPoRh,'',{'folder':mOEzG4cJoV9erugyXbLI})
	del kkDjx8VpG4R
	for PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,ixHfKALJzXyoYt0 in jI5Y0PkRpEXvNJxAnSqB21tTKLW8[DGqCNbTtJc:MDp1TG9m0zHqXjhUCbSQ6RwBV7]:
		RS6pMitI9K2kzcvZAsd7Vm = jjCeNxAVJ9RpqzDI3Yg6dy(eesaHQO5yPGNvopTtWzR)
		jPqMvmNDgsYiWUyxo = 'live'
		if '.mkv' in RS6pMitI9K2kzcvZAsd7Vm or 'VOD' in sDadiY5cfA3MjkwbyungURQ4HCh: jPqMvmNDgsYiWUyxo = 'video'
		UZ8LYnm5jsl9uKM0xDX(jPqMvmNDgsYiWUyxo,T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+PrfpcmRL8AHyk,eesaHQO5yPGNvopTtWzR,715,ixHfKALJzXyoYt0,'','','',{'folder':mOEzG4cJoV9erugyXbLI})
	del jI5Y0PkRpEXvNJxAnSqB21tTKLW8
	ooUYi4IHuh7alWz(mOEzG4cJoV9erugyXbLI,vUHwKfh5mz6,sDadiY5cfA3MjkwbyungURQ4HCh,719,ZQVLBS5JyxsHIgleF370+RzoXf9tEuVTe5,c1qUnGRSoEZPefVhWv+'_NODIALOGS_')
	return
def ooUYi4IHuh7alWz(mOEzG4cJoV9erugyXbLI,vUHwKfh5mz6,sDadiY5cfA3MjkwbyungURQ4HCh,lOH3hXsnQiFCRjbN12,uHKTyMEW7ZGYvnFSaBINcs0XpO,yy42JUqszVIO89i):
	if not vUHwKfh5mz6: vUHwKfh5mz6 = '1'
	if vUHwKfh5mz6!='1': UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'صفحة '+str(1),sDadiY5cfA3MjkwbyungURQ4HCh,lOH3hXsnQiFCRjbN12,'',str(1),yy42JUqszVIO89i,'',{'folder':mOEzG4cJoV9erugyXbLI})
	if not uHKTyMEW7ZGYvnFSaBINcs0XpO: uHKTyMEW7ZGYvnFSaBINcs0XpO = 0
	RHhoJi30EV6KFb9GZkDBWpmwzMU = int(uHKTyMEW7ZGYvnFSaBINcs0XpO/100)+1
	for B2Axl9aIWKdUXNTEtc0YjCR5yPF in range(2,RHhoJi30EV6KFb9GZkDBWpmwzMU):
		VVQ1IikqU0CDjxJE2tvTONM3G7l = (B2Axl9aIWKdUXNTEtc0YjCR5yPF%10==0 or int(vUHwKfh5mz6)-4<B2Axl9aIWKdUXNTEtc0YjCR5yPF<int(vUHwKfh5mz6)+4)
		jjsYDcpbFiOlNh1AXqG = (VVQ1IikqU0CDjxJE2tvTONM3G7l and int(vUHwKfh5mz6)-40<B2Axl9aIWKdUXNTEtc0YjCR5yPF<int(vUHwKfh5mz6)+40)
		if str(B2Axl9aIWKdUXNTEtc0YjCR5yPF)!=vUHwKfh5mz6 and (B2Axl9aIWKdUXNTEtc0YjCR5yPF%100==0 or jjsYDcpbFiOlNh1AXqG):
			UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'صفحة '+str(B2Axl9aIWKdUXNTEtc0YjCR5yPF),sDadiY5cfA3MjkwbyungURQ4HCh,lOH3hXsnQiFCRjbN12,'',str(B2Axl9aIWKdUXNTEtc0YjCR5yPF),yy42JUqszVIO89i,'',{'folder':mOEzG4cJoV9erugyXbLI})
	if str(RHhoJi30EV6KFb9GZkDBWpmwzMU)!=vUHwKfh5mz6: UZ8LYnm5jsl9uKM0xDX('folder',T4zgsqfUh5jmwtnJ2FcuOV3bpvZHB+'أخر صفحة '+str(RHhoJi30EV6KFb9GZkDBWpmwzMU),sDadiY5cfA3MjkwbyungURQ4HCh,lOH3hXsnQiFCRjbN12,'',str(RHhoJi30EV6KFb9GZkDBWpmwzMU),yy42JUqszVIO89i,'',{'folder':mOEzG4cJoV9erugyXbLI})
	return
def x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,sDadiY5cfA3MjkwbyungURQ4HCh):
	c7VlxmwGrPujtaiX8DQAHYodB = UWteSXYca7.replace('___','_'+mOEzG4cJoV9erugyXbLI)
	return c7VlxmwGrPujtaiX8DQAHYodB
def snxaPmhUME(mOEzG4cJoV9erugyXbLI):
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'')
	yka0pczgxUV = nEYJ5OCXG0gcNy('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if yka0pczgxUV!=1: return False
	bfBW9emaQpcn2r1IUKy(mOEzG4cJoV9erugyXbLI,False)
	DD4trBqkljewOZhGMp9Ncs = [0]
	for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
		vtFnO6UX2f1o4sZbhAMKjdQ0mwYP = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI+'_'+str(tt7LgzAD3j6VwBud))
		if vtFnO6UX2f1o4sZbhAMKjdQ0mwYP: RMe5svtD8XQKrkzF6h1mpuGBxoITSq(mOEzG4cJoV9erugyXbLI,str(tt7LgzAD3j6VwBud))
		DD4trBqkljewOZhGMp9Ncs.append(0)
	for sDadiY5cfA3MjkwbyungURQ4HCh in H56tOjf2BZNiSCUKYsozXA4gdvGuxR:
		e2TAHi7cQpBhdqaUuVx0XIsfMR,WWcrbKN7RAkVCJqOxtefUoE6,ZZz2m6jkBdYJ7ERKrvVUya,N8pkeSfMD20Fg5ZIymnaEqQ4,NOhEdDuUSfmi437IqyaBXcxe68MGKA = 0,{},[],[],[]
		for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
			pYTJkz3EZ1KFbosW5i7AG = sDadiY5cfA3MjkwbyungURQ4HCh+'_'+str(tt7LgzAD3j6VwBud)
			OcZztLHx3P67bIMGv25T = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'dict',pYTJkz3EZ1KFbosW5i7AG)
			try:
				J0JemNsxvM54WKfrQVkh3towGOjL7 = OcZztLHx3P67bIMGv25T['__GROUPS__']
				P12PCQDTINg = OcZztLHx3P67bIMGv25T['__COUNT__']
			except: J0JemNsxvM54WKfrQVkh3towGOjL7,P12PCQDTINg = [],'0'
			for XohzUFEsSlPT9Y24itAaWkOu076 in J0JemNsxvM54WKfrQVkh3towGOjL7:
				kvbO7aXiqA0H2JUPoRh,V56GckjYK2vUw9 = XohzUFEsSlPT9Y24itAaWkOu076
				VVxRSC9foEJiOlUNIh = OcZztLHx3P67bIMGv25T[kvbO7aXiqA0H2JUPoRh]
				if kvbO7aXiqA0H2JUPoRh not in N8pkeSfMD20Fg5ZIymnaEqQ4:
					N8pkeSfMD20Fg5ZIymnaEqQ4.append(kvbO7aXiqA0H2JUPoRh)
					NOhEdDuUSfmi437IqyaBXcxe68MGKA.append(XohzUFEsSlPT9Y24itAaWkOu076)
					WWcrbKN7RAkVCJqOxtefUoE6[kvbO7aXiqA0H2JUPoRh] = []
				WWcrbKN7RAkVCJqOxtefUoE6[kvbO7aXiqA0H2JUPoRh] += VVxRSC9foEJiOlUNIh
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(c7VlxmwGrPujtaiX8DQAHYodB,pYTJkz3EZ1KFbosW5i7AG)
			F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,pYTJkz3EZ1KFbosW5i7AG,'__COUNT__',P12PCQDTINg,bY2n5MtVA4cjpkFSxZ6K)
			DD4trBqkljewOZhGMp9Ncs[tt7LgzAD3j6VwBud] += int(P12PCQDTINg)
		for kvbO7aXiqA0H2JUPoRh in N8pkeSfMD20Fg5ZIymnaEqQ4:
			VVxRSC9foEJiOlUNIh = list(set(WWcrbKN7RAkVCJqOxtefUoE6[kvbO7aXiqA0H2JUPoRh]))
			if 'SORTED' in sDadiY5cfA3MjkwbyungURQ4HCh: VVxRSC9foEJiOlUNIh = sorted(VVxRSC9foEJiOlUNIh,reverse=False,key=lambda key: key[1].lower())
			e2TAHi7cQpBhdqaUuVx0XIsfMR += len(VVxRSC9foEJiOlUNIh)
			ZZz2m6jkBdYJ7ERKrvVUya.append(VVxRSC9foEJiOlUNIh)
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,sDadiY5cfA3MjkwbyungURQ4HCh,'__COUNT__',str(e2TAHi7cQpBhdqaUuVx0XIsfMR),bY2n5MtVA4cjpkFSxZ6K)
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,sDadiY5cfA3MjkwbyungURQ4HCh,'__GROUPS__',NOhEdDuUSfmi437IqyaBXcxe68MGKA,bY2n5MtVA4cjpkFSxZ6K)
		F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,sDadiY5cfA3MjkwbyungURQ4HCh,N8pkeSfMD20Fg5ZIymnaEqQ4,ZZz2m6jkBdYJ7ERKrvVUya,bY2n5MtVA4cjpkFSxZ6K,True)
	QLnb0I1hrYlyVTcu = False
	for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
		if int(DD4trBqkljewOZhGMp9Ncs[tt7LgzAD3j6VwBud])>0:
			vtFnO6UX2f1o4sZbhAMKjdQ0mwYP = LCIFdjzi5kVmRwehouHQ.getSetting('av.m3u.url_'+mOEzG4cJoV9erugyXbLI+'_'+str(tt7LgzAD3j6VwBud))
			F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,'LINK_'+str(tt7LgzAD3j6VwBud),'__LINK__',vtFnO6UX2f1o4sZbhAMKjdQ0mwYP,bY2n5MtVA4cjpkFSxZ6K)
			QLnb0I1hrYlyVTcu = True
	F4QxJHhsMj(c7VlxmwGrPujtaiX8DQAHYodB,'DUMMY','__DUMMY__','DUMMY',bY2n5MtVA4cjpkFSxZ6K)
	if not QLnb0I1hrYlyVTcu:
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	u7fDqHj4N8(mOEzG4cJoV9erugyXbLI)
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin('Container.Refresh')
	return True
def u7fDqHj4N8(mOEzG4cJoV9erugyXbLI):
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'')
	if not G05MeU6Hlrzh(mOEzG4cJoV9erugyXbLI,True): return
	for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
		vtFnO6UX2f1o4sZbhAMKjdQ0mwYP = yu1pYA2VRHzr876gPJdDw(c7VlxmwGrPujtaiX8DQAHYodB,'str','LINK_'+str(tt7LgzAD3j6VwBud),'__LINK__')
		if vtFnO6UX2f1o4sZbhAMKjdQ0mwYP: mYALwDXM4nfBFqdhRro = KlnS5uXmHdEGhJ(mOEzG4cJoV9erugyXbLI,str(tt7LgzAD3j6VwBud))
	KlnS5uXmHdEGhJ(mOEzG4cJoV9erugyXbLI,'')
	return
def bfBW9emaQpcn2r1IUKy(mOEzG4cJoV9erugyXbLI,SKyG3D4CgRJW7qArbhHljzi6Q):
	if SKyG3D4CgRJW7qArbhHljzi6Q:
		yka0pczgxUV = nEYJ5OCXG0gcNy('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if yka0pczgxUV!=1: return
	c7VlxmwGrPujtaiX8DQAHYodB = x7pOz2msTl16D5v0Xb4YH(mOEzG4cJoV9erugyXbLI,'')
	try: Dh9MOxeTj6FW.remove(c7VlxmwGrPujtaiX8DQAHYodB)
	except: pass
	for tt7LgzAD3j6VwBud in range(1,ooH4RO9l3nDvcds2zLf1x+1):
		SDQjzmxGXefu3pKyI = ao80nC2gE3LkOFvI9BTxXqQW5N.replace('___','_'+mOEzG4cJoV9erugyXbLI+'_'+str(tt7LgzAD3j6VwBud))
		Xo69cCJs4qArH2tTjae8YBymQVdIhf = Dh9MOxeTj6FW.path.join(Vd1J5lD9uAsMUoXW,SDQjzmxGXefu3pKyI)
		try: Dh9MOxeTj6FW.remove(Xo69cCJs4qArH2tTjae8YBymQVdIhf)
		except: pass
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_'+mOEzG4cJoV9erugyXbLI)
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if SKyG3D4CgRJW7qArbhHljzi6Q:
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin('Container.Refresh')
	return
def e34THDAiSWvpLEK1o5(mOEzG4cJoV9erugyXbLI):
	oH8g9ANIlfbZGrwKd2zxpyOUJBk = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.provider')
	b6bSrn0KwVyRFYefjJEWsXi = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.code')
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'MENUS_CACHE_'+oH8g9ANIlfbZGrwKd2zxpyOUJBk+'_'+b6bSrn0KwVyRFYefjJEWsXi,'%_MU'+mOEzG4cJoV9erugyXbLI+'_%')
	return
xEH9tgkO3PXVsreRfBauwYLd = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
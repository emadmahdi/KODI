# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMACLUP'
ToYWiIbruzUaNKRPZLG16cAj = '_CMC_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['موقع نتفليكس']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==490: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==491: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==492: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==493: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==494: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==499: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text,url)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMACLUP-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"filter AjaxifyFilter"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('data-filter="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title in C1pRb6K8Qs: continue
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/old/filter/'+ZcAK0askvzIWr4R+'.php'
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,491)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أفلام',BdSZn7YxiHaUcf1Rzt5o+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات',BdSZn7YxiHaUcf1Rzt5o+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="navigation-menu"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if ZcAK0askvzIWr4R=='/': continue
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
		if title in C1pRb6K8Qs: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,491)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"filter"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title in C1pRb6K8Qs: continue
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,491)
	return
def KKlnDcetq8Rrp3GY0(url,YGBW78utSU1gJ0pD=''):
	items = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	L0Uwx52bTBM = ''
	if '.php' in url: L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	elif '?s=' in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"blocks(.*?)"manifest"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Blocks(.*?)"manifest"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not L0Uwx52bTBM: return
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) حلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if not iHPhR4wCQ1oINaL: iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if not iHPhR4wCQ1oINaL or any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,492,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'حلقة' in title:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,493,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,493,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<li><a href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,491)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('"ButtonsBarCo".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMACLUP-EPISODES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"img-responsive" src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
	else: pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Thumb')
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"filter"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"Blocks(.*?)class="pagination"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and '/series/' not in url:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,493,pjMZ802XQCSxYVk)
	elif EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,492,pjMZ802XQCSxYVk)
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = dCFP41Kxv9j8EHM(title)
				title = title.replace('الصفحة ','')
				if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,491)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.strip('/')+'/?view=1'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMACLUP-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	OnjXh8rf1IgEsDvTJ20LycGA3bmP = SomeI8i56FaDMGPE.findall("data: 'q=(.*?)&",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	OnjXh8rf1IgEsDvTJ20LycGA3bmP = OnjXh8rf1IgEsDvTJ20LycGA3bmP[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"serversList"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-server="(.*?)">(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for aNBiPRMqeFzG0pD5yAovKb8k27lJQ,title in items:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/old/servers/server.php?q='+OnjXh8rf1IgEsDvTJ20LycGA3bmP+'&i='+aNBiPRMqeFzG0pD5yAovKb8k27lJQ+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"embedServer".*?SRC="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		title = 'مفضل'
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]+'?named=__embed__'+title
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"downloadsList"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<td>(.*?)</td>.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R in items:
			title = title.strip(' ')
			if 'anavidz' in ZcAK0askvzIWr4R: U2iQmHMJzoNkjORTGY7c51vZ = '__خاص'
			else: U2iQmHMJzoNkjORTGY7c51vZ = ''
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'+U2iQmHMJzoNkjORTGY7c51vZ
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search,BdSZn7YxiHaUcf1Rzt5o=''):
	if not BdSZn7YxiHaUcf1Rzt5o: BdSZn7YxiHaUcf1Rzt5o = aaeRjxiYcqOI6Sf8
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	search = search.replace(' ','+')
	url = BdSZn7YxiHaUcf1Rzt5o+'/index.php?s='+search
	KKlnDcetq8Rrp3GY0(url)
	return
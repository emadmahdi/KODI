# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
headers = { 'User-Agent' : '' }
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'AKOAM'
ToYWiIbruzUaNKRPZLG16cAj = '_AKO_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
m2mCFQsOtSJd8zAE1KkMNGubV4 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==70: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==71: rr60PDpqbMehZsYVuHmiAtN = aGvt7WqXMcuO(url)
	elif mode==72: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==73: rr60PDpqbMehZsYVuHmiAtN = wx9lS3TGYApUKOnCjd(url)
	elif mode==74: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==79: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'سلسلة افلام','',79,'','','سلسلة افلام')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'سلاسل منوعة','',79,'','','سلسلة')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	C1pRb6K8Qs = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','AKOAM-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="partions"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs:
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,71)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def aGvt7WqXMcuO(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,'','AKOAM-CATEGORIES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('sect_parts(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,72)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'جميع الفروع',url,72)
	else: KKlnDcetq8Rrp3GY0(url,'')
	return
def KKlnDcetq8Rrp3GY0(url,type):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('section_title featured_title(.*?)subjects-crousel',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='search':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('akoam_result(.*?)<script',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='more':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('section_title more_title(.*?)footer_bottom_services',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('navigation(.*?)<script',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not items and pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = dCFP41Kxv9j8EHM(title)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in m2mCFQsOtSJd8zAE1KkMNGubV4): UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,73,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,73,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall("</li><li >.*?href='(.*?)'>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,72,'','',type)
	return
def ryd1pixec3(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('"href","(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[1]
	return vfIB6ib8q1hFX5GweRrVPNTjY2E
def wx9lS3TGYApUKOnCjd(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'AKOAM-SECTIONS-1st')
	iEH4cKhMB91rmL5bvtIgJjQn0Z = SomeI8i56FaDMGPE.findall('"(https*://akwam.net/\w+.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vRxqNIM1pEF24w = SomeI8i56FaDMGPE.findall('"(https*://underurl.com/\w+.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if iEH4cKhMB91rmL5bvtIgJjQn0Z or vRxqNIM1pEF24w:
		if iEH4cKhMB91rmL5bvtIgJjQn0Z: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = iEH4cKhMB91rmL5bvtIgJjQn0Z[0]
		elif vRxqNIM1pEF24w: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = ryd1pixec3(vRxqNIM1pEF24w[0])
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = aDebGvrkdptunqTM8m4(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
		import vfhp39d4er
		if '/series/' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv or '/shows/' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv: vfhp39d4er.ooLCwrlF3n0vBjpA(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
		else: vfhp39d4er.fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
		return
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	items = SomeI8i56FaDMGPE.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		title = dCFP41Kxv9j8EHM(title)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,73)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd:
		NCXj2ri3Unm6TFWIgwh('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,pjMZ802XQCSxYVk,L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in L0Uwx52bTBM:
		items = SomeI8i56FaDMGPE.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else:
		KKy3njomMPd4UeE8iOVt1 = SomeI8i56FaDMGPE.findall('sub_file_title\'>(.*?) - <i>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		items = []
		for filename in KKy3njomMPd4UeE8iOVt1:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	r79xJG6jXHD,hRaYosdIulb3mWKyrBLEnFPeH5AJxp = [],[]
	size = len(items)
	for title,filename in items:
		CxhvM0I7d3kcrD9aeTBESPG = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: CxhvM0I7d3kcrD9aeTBESPG = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		r79xJG6jXHD.append(title)
		hRaYosdIulb3mWKyrBLEnFPeH5AJxp.append(count)
		count += 1
	if size>0:
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in name for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in m2mCFQsOtSJd8zAE1KkMNGubV4):
			if size==1:
				I7mfbGiWNFcBVJOn = 0
			else:
				I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الفيديو المناسب:', r79xJG6jXHD)
				if I7mfbGiWNFcBVJOn == -1: return
			fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url+'?section='+str(1+hRaYosdIulb3mWKyrBLEnFPeH5AJxp[size-I7mfbGiWNFcBVJOn-1]))
		else:
			for zz5ZOaoyATpS893tvdXE in reversed(range(size)):
				title = name + ' - ' + r79xJG6jXHD[zz5ZOaoyATpS893tvdXE]
				title = title.replace('\n','').strip(' ')
				ZcAK0askvzIWr4R = url + '?section='+str(size-zz5ZOaoyATpS893tvdXE)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,74,pjMZ802XQCSxYVk)
	else:
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+'الرابط ليس فيديو','',9999,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E,iHPhR4wCQ1oINaL = url.split('?section=')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	VT5qkDNWdA98GucPLerpXO4S = pDTlIgyewF1XV69R8kd[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	VT5qkDNWdA98GucPLerpXO4S = VT5qkDNWdA98GucPLerpXO4S + 'direct_link_box'
	UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('epsoide_box(.*?)direct_link_box',VT5qkDNWdA98GucPLerpXO4S,SomeI8i56FaDMGPE.DOTALL)
	iHPhR4wCQ1oINaL = len(UUTVrGP7Y31a)-int(iHPhR4wCQ1oINaL)
	L0Uwx52bTBM = UUTVrGP7Y31a[iHPhR4wCQ1oINaL]
	TbFRyPoVlrQAw7n3h8BukmfHNq = []
	bH7uPsiWnXhFSEN6 = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = SomeI8i56FaDMGPE.findall("class='download_btn.*?href='(.*?)'",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R in items:
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=________akoam')
	items = SomeI8i56FaDMGPE.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for aug1oFkXrHpnztML5W9,ZcAK0askvzIWr4R in items:
		aug1oFkXrHpnztML5W9 = aug1oFkXrHpnztML5W9.split('/')[-1]
		aug1oFkXrHpnztML5W9 = aug1oFkXrHpnztML5W9.split('.')[0]
		if aug1oFkXrHpnztML5W9 in bH7uPsiWnXhFSEN6:
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+bH7uPsiWnXhFSEN6[aug1oFkXrHpnztML5W9]+'________akoam')
		else: TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+aug1oFkXrHpnztML5W9+'________akoam')
	if not TbFRyPoVlrQAw7n3h8BukmfHNq:
		message = SomeI8i56FaDMGPE.findall('sub-no-file.*?\n(.*?)\n',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if message: ztgqWUaDpe8CE9N('','','رسالة من الموقع الاصلي',message[0])
	else:
		import Y4ILyJBspQ
		Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','%20')
	url = aaeRjxiYcqOI6Sf8 + '/search/'+u9DhgpinLBfmjG3NtMalq7Y
	rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,'search')
	return
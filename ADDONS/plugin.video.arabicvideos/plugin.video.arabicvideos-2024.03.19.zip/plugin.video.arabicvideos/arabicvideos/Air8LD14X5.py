# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'FASELHD2'
headers = {'User-Agent':''}
ToYWiIbruzUaNKRPZLG16cAj = '_FH2_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['wwe']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==590: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==591: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==592: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==593: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,text)
	elif mode==599: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	BdSZn7YxiHaUcf1Rzt5o = aaeRjxiYcqOI6Sf8
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',BdSZn7YxiHaUcf1Rzt5o,'','','','','FASELHD2-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع',BdSZn7YxiHaUcf1Rzt5o,599,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',BdSZn7YxiHaUcf1Rzt5o,591,'','','featured1')
	items = SomeI8i56FaDMGPE.findall('<strong>(.*?)</strong>.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for title,ZcAK0askvzIWr4R in items:
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,591,'','','details1')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-menu"(.*?)header-social',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		vvNkUbe1YW5oDF0S2w3dtnT976X = SomeI8i56FaDMGPE.findall('<li (.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for hmedxznGXRHt1L in vvNkUbe1YW5oDF0S2w3dtnT976X:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',hmedxznGXRHt1L,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,591,'','','details2')
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FASELHD2-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	jjiWJHn5A48Pa6wGD2srgyYqMQ = 0
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"archive-slider(.*?)<h4>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS: K1KV5U7JFXNPsl4h0HBd = EFOPTCNHpGvMYuS[0]
	else: K1KV5U7JFXNPsl4h0HBd = ''
	if type=='featured1':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"slider-carousel"(.*?)</container>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		CCAvDuOGpgtxJmhERUBWNoTs3Yy2,R3Rinqky4ouBgYEtZh,ZZHhmdtY1g = zip(*items)
		items = zip(ZZHhmdtY1g,CCAvDuOGpgtxJmhERUBWNoTs3Yy2,R3Rinqky4ouBgYEtZh)
	elif type=='featured2':
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
	elif type=='filters':
		pDTlIgyewF1XV69R8kd = [BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in K1KV5U7JFXNPsl4h0HBd:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<h4>(.*?)</h4>(.*?)</container>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مميزة',url,591,'','','featured2')
		title = pDTlIgyewF1XV69R8kd[0][0]
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,591,'','','details3')
		return
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<h4>(.*?)</h4>(.*?)</container>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		title,L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	oojL40IJtK = []
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title.lower() for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
		title = title.strip(' ')
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|حلقة).\d+',title,SomeI8i56FaDMGPE.DOTALL)
		if '/movseries/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,591,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and type=='':
			title = '_MOD_'+iHPhR4wCQ1oINaL[0][0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,593,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,592,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,593,pjMZ802XQCSxYVk)
	if type=='filters':
		rTcXIjKgMCUdaPSWkn = SomeI8i56FaDMGPE.findall('"more_button_page":(.*?),',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if rTcXIjKgMCUdaPSWkn:
			count = rTcXIjKgMCUdaPSWkn[0]
			ZcAK0askvzIWr4R = url+'/offset/'+count
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة أخرى',ZcAK0askvzIWr4R,591,'','','filters')
	elif 'details' in type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = 'صفحة '+dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,591,'','','details4')
	return
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	v0hReYLd84QxBaq7Og6nlV = False
	if not type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<seasons(.*?)</seasons>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
				v0hReYLd84QxBaq7Og6nlV = True
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					title = dCFP41Kxv9j8EHM(title)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,593,pjMZ802XQCSxYVk,'','episodes')
	if type=='episodes' or not v0hReYLd84QxBaq7Og6nlV:
		NmX0ZP715phHsSiCzvxR3IB = SomeI8i56FaDMGPE.findall('<bkز*?image:url\((.*?)\)"></bk>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if NmX0ZP715phHsSiCzvxR3IB: pjMZ802XQCSxYVk = NmX0ZP715phHsSiCzvxR3IB[0]
		else: pjMZ802XQCSxYVk = ''
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<all-episodes(.*?)</all-episodes>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,592,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq,yuvWisETBpYaf7k1M3RF9,AH37UN2zyfhutGmL4JkajnF9eT = [],[],[]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','FASELHD2-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	awJOmiIZMDcgo = SomeI8i56FaDMGPE.findall('العمر :.*?<strong">(.*?)</strong>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if awJOmiIZMDcgo and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,awJOmiIZMDcgo): return
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<iframe src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=__embed')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<slice-title(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-url="(.*?)".*?</i>(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name in items:
			name = name.strip(' ')
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+name+'__watch')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<downloads(.*?)</downloads>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</div>(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name in items:
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+name+'__download')
	for YIMRpk6L45v0CXlJdqG in TbFRyPoVlrQAw7n3h8BukmfHNq:
		ZcAK0askvzIWr4R,name = YIMRpk6L45v0CXlJdqG.split('?named')
		if ZcAK0askvzIWr4R not in yuvWisETBpYaf7k1M3RF9:
			yuvWisETBpYaf7k1M3RF9.append(ZcAK0askvzIWr4R)
			AH37UN2zyfhutGmL4JkajnF9eT.append(YIMRpk6L45v0CXlJdqG)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(AH37UN2zyfhutGmL4JkajnF9eT,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	BdSZn7YxiHaUcf1Rzt5o = aaeRjxiYcqOI6Sf8
	url = BdSZn7YxiHaUcf1Rzt5o+'/?s='+search
	KKlnDcetq8Rrp3GY0(url,'details5')
	return
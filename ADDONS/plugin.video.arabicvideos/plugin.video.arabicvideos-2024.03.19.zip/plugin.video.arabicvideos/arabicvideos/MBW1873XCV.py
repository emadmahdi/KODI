# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from FJKmvLp8Tl import *
NCXj2ri3Unm6TFWIgwh(RS7ZoyGAq1c(u"࡚ࠬࡅࡔࡖࠪ૧"),RS7ZoyGAq1c(u"࠭ࡔࡆࡕࡗࠫ૨"))
IItzT2knpKVOevJylmdcACgZYoBL = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡹ࠸࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡵࡪ࡬ࡲࡰࡨࡲࡰࡣࡧࡦࡦࡴࡤ࠯ࡥࡲࡱ࠴࠷࠰ࡎࡄ࠱ࡾ࡮ࡶࠧ૩")
IItzT2knpKVOevJylmdcACgZYoBL = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡩࡪࡪࡴࡦࡵࡷ࠲࡫ࡺࡰ࠯ࡱࡷࡩࡳ࡫ࡴ࠯ࡩࡵ࠳࡫࡯࡬ࡦࡵ࠲ࡸࡪࡹࡴ࠲࠲࠳࡯࠳ࡪࡢࠨ૪")
rycVB75alp(IItzT2knpKVOevJylmdcACgZYoBL,{},S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡘࡷࡻࡥ૭"))
eesaHQO5yPGNvopTtWzR = Y5npATFarf1H9wBjc87(u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠๆำี࠯࡯ࡳ࠷ࠬ૫")
eesaHQO5yPGNvopTtWzR = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡ࡬ࡩ࡭ࡧࡢ࠸࠽࠹࠴ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ૬")
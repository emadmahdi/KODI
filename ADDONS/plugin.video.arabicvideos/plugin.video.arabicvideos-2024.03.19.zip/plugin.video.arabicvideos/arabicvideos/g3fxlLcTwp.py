# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SHAHID4U'
headers = ''
ToYWiIbruzUaNKRPZLG16cAj = '_SH4_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==110: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==111: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==112: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==113: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,True)
	elif mode==114: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FULL_FILTER___'+text)
	elif mode==115: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'DEFINED_FILTER___'+text)
	elif mode==116: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,False)
	elif mode==119: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	BdSZn7YxiHaUcf1Rzt5o,url,ttpgqJBdkoxeKOcwaiP = PP2QEmwzKue6nol57v(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',aaeRjxiYcqOI6Sf8,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',BdSZn7YxiHaUcf1Rzt5o,115)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',BdSZn7YxiHaUcf1Rzt5o,114)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',BdSZn7YxiHaUcf1Rzt5o,111,'','','featured')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('simple-filter(.*?)adv-filter',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd:
		ztgqWUaDpe8CE9N('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for filter,pjMZ802XQCSxYVk,title in items:
			url = BdSZn7YxiHaUcf1Rzt5o+filter
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,url,111,pjMZ802XQCSxYVk,'',filter)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="dropdown"(.*?)<script>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in C1pRb6K8Qs: continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
			if 'netflix' in ZcAK0askvzIWr4R: title = 'نيتفلكس'
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,111)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,YGBW78utSU1gJ0pD='',ttpgqJBdkoxeKOcwaiP=''):
	if not ttpgqJBdkoxeKOcwaiP: ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd,items,oojL40IJtK = [],[],[]
	if YGBW78utSU1gJ0pD=='featured': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('glide__slides(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('shows-container(.*?)pagination',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not items: items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if 'javascript' in ZcAK0askvzIWr4R: continue
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		title = dCFP41Kxv9j8EHM(title)
		title = title.strip(' ')
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if '/film/' in ZcAK0askvzIWr4R or 'فيلم' in ZcAK0askvzIWr4R or any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,112,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,113,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/actor/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,111,pjMZ802XQCSxYVk)
		elif '/series/' in ZcAK0askvzIWr4R and '/list' not in url:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'/list'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,111,pjMZ802XQCSxYVk)
		elif '/list' in url and 'حلقة' in title:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,112,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,113,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		if YGBW78utSU1gJ0pD!='search': items = SomeI8i56FaDMGPE.findall('(updateQuery).*?>(.+?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		else: items = SomeI8i56FaDMGPE.findall('<li>.*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if YGBW78utSU1gJ0pD!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: ZcAK0askvzIWr4R = url+'&page='+title
				else: ZcAK0askvzIWr4R = url+'?page='+title
			title = dCFP41Kxv9j8EHM(title)
			if title: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,111,'','',YGBW78utSU1gJ0pD)
	return
def ooLCwrlF3n0vBjpA(url,McHuF3dWhSEsGXtTOAwrk4UbIg):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('items d-flex(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if len(pDTlIgyewF1XV69R8kd)>1:
		if '/season/' in pDTlIgyewF1XV69R8kd[0]: v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6 = pDTlIgyewF1XV69R8kd[0],pDTlIgyewF1XV69R8kd[1]
		else: v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6 = pDTlIgyewF1XV69R8kd[1],pDTlIgyewF1XV69R8kd[0]
	else: v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6 = pDTlIgyewF1XV69R8kd[0],pDTlIgyewF1XV69R8kd[0]
	for jUSuZAztxy34TB5CIP2 in range(2):
		if McHuF3dWhSEsGXtTOAwrk4UbIg: mode,type,L0Uwx52bTBM = 116,'folder',v0hReYLd84QxBaq7Og6nlV
		else: mode,type,L0Uwx52bTBM = 112,'video',gbRaTlfw5quES79COD2yPhJXzie6
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if McHuF3dWhSEsGXtTOAwrk4UbIg and len(items)<2:
			McHuF3dWhSEsGXtTOAwrk4UbIg = False
			continue
		for ZcAK0askvzIWr4R,uZfwDbhTs2V5dp,U2iQmHMJzoNkjORTGY7c51vZ in items:
			title = uZfwDbhTs2V5dp+' '+U2iQmHMJzoNkjORTGY7c51vZ
			UZ8LYnm5jsl9uKM0xDX(type,ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,mode)
		break
	if not items and '/episodes' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		W7fo8gXqeO = SomeI8i56FaDMGPE.findall('class="breadcrumb"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if W7fo8gXqeO:
			L0Uwx52bTBM = W7fo8gXqeO[0]
			ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if len(ZZHhmdtY1g)>2:
				ZcAK0askvzIWr4R = ZZHhmdtY1g[2]+'list'
				KKlnDcetq8Rrp3GY0(ZcAK0askvzIWr4R)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="actions(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	ttXHYzmkMN = '/watch/' in L0Uwx52bTBM
	download = '/download/' in L0Uwx52bTBM
	if   ttXHYzmkMN and not download: WAD6bfcYdE3mwRk40V5LxpNzJKZ7Se,czdrstVx90GPQI5kR = ZZHhmdtY1g[0],''
	elif not ttXHYzmkMN and download: WAD6bfcYdE3mwRk40V5LxpNzJKZ7Se,czdrstVx90GPQI5kR = '',ZZHhmdtY1g[0]
	elif ttXHYzmkMN and download: WAD6bfcYdE3mwRk40V5LxpNzJKZ7Se,czdrstVx90GPQI5kR = ZZHhmdtY1g[0],ZZHhmdtY1g[1]
	else: WAD6bfcYdE3mwRk40V5LxpNzJKZ7Se,czdrstVx90GPQI5kR = '',''
	if ttXHYzmkMN:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',WAD6bfcYdE3mwRk40V5LxpNzJKZ7Se,'',headers,'','','SHAHID4U-PLAY-2nd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('let servers(.*?)player',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL|SomeI8i56FaDMGPE.IGNORECASE)
		if EFOPTCNHpGvMYuS:
			K1KV5U7JFXNPsl4h0HBd = EFOPTCNHpGvMYuS[0]
			BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('"name":"(.*?)".*?"url":"(.*?)"',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
			for title,ZcAK0askvzIWr4R in BAHbWtFdwNps9ZVUfvR:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\\/','/')
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if download:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',czdrstVx90GPQI5kR,'',headers,'','','SHAHID4U-PLAY-3rd')
		ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
		EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"servers"(.*?)info-container',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if EFOPTCNHpGvMYuS:
			K1KV5U7JFXNPsl4h0HBd = EFOPTCNHpGvMYuS[0]
			BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title,AfejZJoKh4D7k5G1P9gCwxTz in BAHbWtFdwNps9ZVUfvR:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'+'____'+AfejZJoKh4D7k5G1P9gCwxTz
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search?s='+search
	BdSZn7YxiHaUcf1Rzt5o,vfIB6ib8q1hFX5GweRrVPNTjY2E,RKBm27pOP0frivqSgzwMA58 = PP2QEmwzKue6nol57v(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E,'search',RKBm27pOP0frivqSgzwMA58)
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	url = url.split('/smartemadfilter?')[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('adv-filter(.*?)shows-container',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		prjZqOoMUE,wwpNZP87O2YjJIFT0rH95Al43RCWzi,UUTVrGP7Y31a = zip(*v3mSnRD6XCqOjksGlP2MuxpKUt4)
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = zip(wwpNZP87O2YjJIFT0rH95Al43RCWzi,prjZqOoMUE,UUTVrGP7Y31a)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('value="(.*?)".*?>\s*(.*?)\s*<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def wV2LqDT14MiOYa(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	nnjrtO4FdM = url.split('/smartemadfilter?')[0]
	guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(url,'url')
	url = url.replace(nnjrtO4FdM,guUzYdHnWLVvGlQA)
	url = url.replace('/smartemadfilter?','/?')
	return url
xupe2PJyhdBkTXR9iVN3tZQ5azU1E4 = ['quality','year','genre','category']
y8nICQWej1Z6qTv234Y9koOcbg7 = ['category','genre','year']
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='DEFINED_FILTER':
		if y8nICQWej1Z6qTv234Y9koOcbg7[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[0]
		for zz5ZOaoyATpS893tvdXE in range(len(y8nICQWej1Z6qTv234Y9koOcbg7[0:-1])):
			if y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FULL_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,111)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,111)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,mjcA3DUe9IJV4bk,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		name = name.replace('كل ','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='DEFINED_FILTER':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					KKlnDcetq8Rrp3GY0(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'DEFINED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,111)
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,115,'','',ecMSxgw2QqpvI)
		elif type=='FULL_FILTER':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,114,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196533': irE1qv3BUYZMo5 = 'أفلام نيتفلكس'
			elif EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196531': irE1qv3BUYZMo5 = 'مسلسلات نيتفلكس'
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' :'#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' :'+name
			if type=='FULL_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,114,'','',L6iYCRsI1U4ytrW)
			elif type=='DEFINED_FILTER' and y8nICQWej1Z6qTv234Y9koOcbg7[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
				vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,111)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,115,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in xupe2PJyhdBkTXR9iVN3tZQ5azU1E4:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
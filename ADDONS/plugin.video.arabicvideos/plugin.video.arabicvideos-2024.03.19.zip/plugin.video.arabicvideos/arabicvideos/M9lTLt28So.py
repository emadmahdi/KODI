# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMALIGHT'
ToYWiIbruzUaNKRPZLG16cAj = '_CML_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['قنوات فضائية']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==470: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==471: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==472: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==473: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,text)
	elif mode==474: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==479: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMALIGHT-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('"url": "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أفلام مميزة',BdSZn7YxiHaUcf1Rzt5o,471,'','','featured_movies')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"content"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		title = title.replace('  ','').strip(' ')
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('cat=online-movies1','cat=online-movies')
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,474)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('/category.php">(.*?)"navslide-divider"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("'dropdown-menu'(.*?)</ul>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,474)
	return
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if 'topvideos.php' in url: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"caret"(.*?)id="pm-grid"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"caret"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if 'topvideos.php' in ZcAK0askvzIWr4R:
				if 'topvideos.php?c=english-movies' in ZcAK0askvzIWr4R: continue
				if 'topvideos.php?c=online-movies1' in ZcAK0askvzIWr4R: continue
				if 'topvideos.php?c=misc' in ZcAK0askvzIWr4R: continue
				if 'topvideos.php?c=tv-channel' in ZcAK0askvzIWr4R: continue
				if 'منذ البداية' in title and 'do=rating' not in ZcAK0askvzIWr4R: continue
			else: title = 'ترتيب باستخدام:  '+title
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,471)
	else: KKlnDcetq8Rrp3GY0(url)
	return
def KKlnDcetq8Rrp3GY0(url,ZuCJj5EwDPROkb7UXNypofl=''):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = []
	if ZuCJj5EwDPROkb7UXNypofl=='featured_movies':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"container-fluid"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		ZZHhmdtY1g,R3Rinqky4ouBgYEtZh,VrYb6FeavCBJlZOim91x7U = zip(*items)
		items = zip(VrYb6FeavCBJlZOim91x7U,ZZHhmdtY1g,R3Rinqky4ouBgYEtZh)
	elif ZuCJj5EwDPROkb7UXNypofl=='featured_series':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('المسلسلات المميزة(.*?)<style>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		ZZHhmdtY1g,R3Rinqky4ouBgYEtZh,VrYb6FeavCBJlZOim91x7U = zip(*items)
		items = zip(VrYb6FeavCBJlZOim91x7U,ZZHhmdtY1g,R3Rinqky4ouBgYEtZh)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(data-echo=".*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"BlocksList"(.*?)"titleSectionCon"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="pm-grid"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="pm-related"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: return
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not items: items = SomeI8i56FaDMGPE.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items: items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
		if 'http' not in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = BdSZn7YxiHaUcf1Rzt5o+'/'+pjMZ802XQCSxYVk.strip('/')
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			title = '_MOD_'+title
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,472,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'الحلقة' in title:
			title = '_MOD_'+iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,473,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/movseries/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,471,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,473,pjMZ802XQCSxYVk)
	if ZuCJj5EwDPROkb7UXNypofl not in ['featured_movies','featured_series']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if ZcAK0askvzIWr4R=='#': continue
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,471)
		Tted4clSYVMkhwFA1qg = SomeI8i56FaDMGPE.findall('showmore" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if Tted4clSYVMkhwFA1qg:
			ZcAK0askvzIWr4R = Tted4clSYVMkhwFA1qg[0]
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مشاهدة المزيد',ZcAK0askvzIWr4R,471)
	return
def ooLCwrlF3n0vBjpA(url,HHhXlVCJAa4gisn9mxZt16P):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"SeasonsBox"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('id="'+HHhXlVCJAa4gisn9mxZt16P+'"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	items = []
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not HHhXlVCJAa4gisn9mxZt16P:
		pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"series-header".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('openCity\(event\, \'(.*?)\'\)">(.*?)</button>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for HHhXlVCJAa4gisn9mxZt16P,title in items: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,473,pjMZ802XQCSxYVk,'',HHhXlVCJAa4gisn9mxZt16P)
	elif EFOPTCNHpGvMYuS:
		pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"series-header".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall("title='(.*?)' href='(.*?)'",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for title,ZcAK0askvzIWr4R in items:
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,472,pjMZ802XQCSxYVk)
		else:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,472,pjMZ802XQCSxYVk)
	if 'id="pm-related"' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		if items: UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مواضيع ذات صلة',url,471)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<div itemprop="description">(.*?)href=',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		Wch421XkoTwA = SomeI8i56FaDMGPE.findall('<p>(.*?)</p>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA,True): return
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/watch.php','/play.php')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMALIGHT-PLAY-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	JVcOjYnW49 = []
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"embedURL" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		if ZcAK0askvzIWr4R and ZcAK0askvzIWr4R not in JVcOjYnW49:
			JVcOjYnW49.append(ZcAK0askvzIWr4R)
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named=__embed'
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	items = SomeI8i56FaDMGPE.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if ZcAK0askvzIWr4R not in JVcOjYnW49:
			JVcOjYnW49.append(ZcAK0askvzIWr4R)
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/watch.php','/downloads.php')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMALIGHT-PLAY-3rd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"downloadlist"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<strong>(.*?)</strong>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if ZcAK0askvzIWr4R not in JVcOjYnW49:
				JVcOjYnW49.append(ZcAK0askvzIWr4R)
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search.php?keywords='+search
	KKlnDcetq8Rrp3GY0(url)
	return
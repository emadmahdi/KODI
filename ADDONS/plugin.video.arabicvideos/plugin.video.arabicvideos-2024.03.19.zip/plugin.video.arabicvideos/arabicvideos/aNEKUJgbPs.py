# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SHAHIDNEWS'
ToYWiIbruzUaNKRPZLG16cAj = '_SHN_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['قنوات فضائية','فارسكو','Show more']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==580: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==581: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==582: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==583: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,text)
	elif mode==584: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==589: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','SHAHIDNEWS-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',589,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('/category.php">(.*?)"navslide-divider"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("'dropdown-menu'(.*?)</ul>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for K1KV5U7JFXNPsl4h0HBd in pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = L0Uwx52bTBM.replace(K1KV5U7JFXNPsl4h0HBd,'')
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,584)
	return
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHAHIDNEWS-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"caret"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		L0Uwx52bTBM = L0Uwx52bTBM.replace('"presentation"','</ul>')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = [('',L0Uwx52bTBM)]
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for L1AixJmzUDr8P,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if L1AixJmzUDr8P: L1AixJmzUDr8P = L1AixJmzUDr8P+': '
			for ZcAK0askvzIWr4R,title in items:
				title = L1AixJmzUDr8P+title
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,581)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"pm-category-subcats"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if len(items)<30:
			UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ZcAK0askvzIWr4R,title in items:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,581)
	if not q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not EFOPTCNHpGvMYuS: KKlnDcetq8Rrp3GY0(url)
	return
def KKlnDcetq8Rrp3GY0(url,ZuCJj5EwDPROkb7UXNypofl=''):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHAHIDNEWS-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(data-echo=".*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"BlocksList"(.*?)"titleSectionCon"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="pm-grid"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="pm-related"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not items: items = SomeI8i56FaDMGPE.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items: items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
		if 'http' not in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = BdSZn7YxiHaUcf1Rzt5o+'/'+pjMZ802XQCSxYVk.strip('/')
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,582,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'الحلقة' in title:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,583,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/movseries/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,581,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,583,pjMZ802XQCSxYVk)
	if ZuCJj5EwDPROkb7UXNypofl not in ['featured_movies','featured_series']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if ZcAK0askvzIWr4R=='#': continue
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,581)
		Tted4clSYVMkhwFA1qg = SomeI8i56FaDMGPE.findall('showmore" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if Tted4clSYVMkhwFA1qg:
			ZcAK0askvzIWr4R = Tted4clSYVMkhwFA1qg[0]
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مشاهدة المزيد',ZcAK0askvzIWr4R,581)
	return
def ooLCwrlF3n0vBjpA(url,HHhXlVCJAa4gisn9mxZt16P):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHAHIDNEWS-EPISODES-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('nav-seasons"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	items = []
	c5WyqgJPT6tl7LkdXHeiKFBrZ = False
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not HHhXlVCJAa4gisn9mxZt16P:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for HHhXlVCJAa4gisn9mxZt16P,title in items:
			HHhXlVCJAa4gisn9mxZt16P = HHhXlVCJAa4gisn9mxZt16P.strip('#')
			if len(items)>1: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,583,'','',HHhXlVCJAa4gisn9mxZt16P)
			else: c5WyqgJPT6tl7LkdXHeiKFBrZ = True
	else: c5WyqgJPT6tl7LkdXHeiKFBrZ = True
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('id="'+HHhXlVCJAa4gisn9mxZt16P+'"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS and c5WyqgJPT6tl7LkdXHeiKFBrZ:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for ZcAK0askvzIWr4R,title in items:
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,582)
		else:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,582)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHAHIDNEWS-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"Playerholder".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
	if ZcAK0askvzIWr4R and 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
	hash = ZcAK0askvzIWr4R.split('hash=')[1]
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = hash.split('__')
	KcyYsJPRCZ3V = []
	for zdkHhwN2otr4GUsxFie1QbpECqRc in u3gUQexlvJM86CS0bXGRBoEFrkZiP:
		try:
			zdkHhwN2otr4GUsxFie1QbpECqRc = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(zdkHhwN2otr4GUsxFie1QbpECqRc+'=')
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: zdkHhwN2otr4GUsxFie1QbpECqRc = zdkHhwN2otr4GUsxFie1QbpECqRc.decode('utf8')
			KcyYsJPRCZ3V.append(zdkHhwN2otr4GUsxFie1QbpECqRc)
		except: pass
	ZZHhmdtY1g = '>'.join(KcyYsJPRCZ3V)
	ZZHhmdtY1g = ZZHhmdtY1g.splitlines()
	if 'farsol' not in str(ZZHhmdtY1g):
		for ZcAK0askvzIWr4R in ZZHhmdtY1g:
			title,ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split(' => ')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		import Y4ILyJBspQ
		Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	else:
		title,ZcAK0askvzIWr4R = ZZHhmdtY1g[0].split(' => ')
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+'\n'+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search.php?keywords='+search
	KKlnDcetq8Rrp3GY0(url)
	return
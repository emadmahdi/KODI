# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
ToYWiIbruzUaNKRPZLG16cAj = '_SFW_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==210: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==211: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==212: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==213: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==214: rr60PDpqbMehZsYVuHmiAtN = wQ8rhc50smTVW9IUB1SFAdHgMv(url)
	elif mode==215: rr60PDpqbMehZsYVuHmiAtN = YqXRj7Uuzri163(url)
	elif mode==218: rr60PDpqbMehZsYVuHmiAtN = tT9kqZi6Vlxzp28uH0NOJhL3do()
	elif mode==219: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def tT9kqZi6Vlxzp28uH0NOJhL3do():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = aaeRjxiYcqOI6Sf8+'/getpostsPin?type=one&data=pin&limit=25'
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',url,211)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','SERIES4WATCH-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('FiltersButtons(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('data-get="(.*?)".*?</i>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		url = aaeRjxiYcqOI6Sf8+'/getposts?type=one&data='+ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,url,211)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('navigation-menu(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(http.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	C1pRb6K8Qs = ['مسلسلات انمي','الرئيسية']
	for ZcAK0askvzIWr4R,title in items:
		title = title.strip(' ')
		if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,211)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('MediaGrid"(.*?)class="pagination"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		else: return
	items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	HIh214TV6ltv8KusX9mgwRjpSFDd3 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		if '/series/' in ZcAK0askvzIWr4R: continue
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		title = dCFP41Kxv9j8EHM(title)
		title = title.strip(' ')
		if '/film/' in ZcAK0askvzIWr4R or any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in HIh214TV6ltv8KusX9mgwRjpSFDd3):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,212,pjMZ802XQCSxYVk)
		elif '/episode/' in ZcAK0askvzIWr4R and 'الحلقة' in title:
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if iHPhR4wCQ1oINaL:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0]
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,213,pjMZ802XQCSxYVk)
					oojL40IJtK.append(title)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,213,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,211)
	return
def ooLCwrlF3n0vBjpA(url):
	xC5E937S0OouUhc2yXFRTbjmeVi,items,Xg49o5xrDRbMw0 = -1,[],[]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('ti-list-numbered(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		UUTVrGP7Y31a = ''.join(pDTlIgyewF1XV69R8kd)
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"',UUTVrGP7Y31a,SomeI8i56FaDMGPE.DOTALL)
	items.append(url)
	items = set(items)
	for ZcAK0askvzIWr4R in items:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.strip('/')
		title = '_MOD_' + ZcAK0askvzIWr4R.split('/')[-1].replace('-',' ')
		Ydt0oPpx4QAj = SomeI8i56FaDMGPE.findall('الحلقة-(\d+)',ZcAK0askvzIWr4R.split('/')[-1],SomeI8i56FaDMGPE.DOTALL)
		if Ydt0oPpx4QAj: Ydt0oPpx4QAj = Ydt0oPpx4QAj[0]
		else: Ydt0oPpx4QAj = '0'
		Xg49o5xrDRbMw0.append([ZcAK0askvzIWr4R,title,Ydt0oPpx4QAj])
	items = sorted(Xg49o5xrDRbMw0, reverse=False, key=lambda key: int(key[2]))
	tEVms0ThHQ = str(items).count('/season/')
	xC5E937S0OouUhc2yXFRTbjmeVi = str(items).count('/episode/')
	if tEVms0ThHQ>1 and xC5E937S0OouUhc2yXFRTbjmeVi>0 and '/season/' not in url:
		for ZcAK0askvzIWr4R,title,Ydt0oPpx4QAj in items:
			if '/season/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,213)
	else:
		for ZcAK0askvzIWr4R,title,Ydt0oPpx4QAj in items:
			if '/season/' not in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,212)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('/')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace(u3gUQexlvJM86CS0bXGRBoEFrkZiP[3],'watch')
		ppq6Bg4vPbVs = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','SERIES4WATCH-PLAY-2nd')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="servers-list(.*?)</div>',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if items:
				id = SomeI8i56FaDMGPE.findall('post_id=(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
				if id:
					iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = id[0]
					for ZcAK0askvzIWr4R,title in items:
						ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/?postid='+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy+'&serverid='+ZcAK0askvzIWr4R+'?named='+title+'__watch'
						aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
			else:
				items = SomeI8i56FaDMGPE.findall('data-embedd=".*?(http.*?)("|&quot;)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				for ZcAK0askvzIWr4R,fYZzomwSjkedXVcEvLDqKHMt9rFnN in items:
					aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	if '/download/' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace(u3gUQexlvJM86CS0bXGRBoEFrkZiP[3],'download')
		ppq6Bg4vPbVs = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = SomeI8i56FaDMGPE.findall('postId:"(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if id:
			iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = id[0]
			mgDoj8ZAqe0uBLxP4Kzp = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8 + '/ajaxCenter?_action=getdownloadlinks&postId='+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy
			ppq6Bg4vPbVs = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',mgDoj8ZAqe0uBLxP4Kzp,'','SERIES4WATCH-PLAY-4th')
			pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<h3.*?(\d+)(.*?)</div>',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if pDTlIgyewF1XV69R8kd:
				for p1Ti6cA2L0uU7eJvO,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
					items = SomeI8i56FaDMGPE.findall('<td>(.*?)<.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
					for name,ZcAK0askvzIWr4R in items:
						aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R+'?named='+name+'__download'+'____'+p1Ti6cA2L0uU7eJvO)
			else:
				pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<h6(.*?)</table>',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
				if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = [ppq6Bg4vPbVs]
				for L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
					name = ''
					items = SomeI8i56FaDMGPE.findall('href="(http.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
					for ZcAK0askvzIWr4R in items:
						FglT5H2faVGm6IqpcXS9vQsojPLu = '&&' + ZcAK0askvzIWr4R.split('/')[2].lower() + '&&'
						FglT5H2faVGm6IqpcXS9vQsojPLu = FglT5H2faVGm6IqpcXS9vQsojPLu.replace('.com&&','').replace('.co&&','')
						FglT5H2faVGm6IqpcXS9vQsojPLu = FglT5H2faVGm6IqpcXS9vQsojPLu.replace('.net&&','').replace('.org&&','')
						FglT5H2faVGm6IqpcXS9vQsojPLu = FglT5H2faVGm6IqpcXS9vQsojPLu.replace('.live&&','').replace('.online&&','')
						FglT5H2faVGm6IqpcXS9vQsojPLu = FglT5H2faVGm6IqpcXS9vQsojPLu.replace('&&hd.','').replace('&&www.','')
						FglT5H2faVGm6IqpcXS9vQsojPLu = FglT5H2faVGm6IqpcXS9vQsojPLu.replace('&&','')
						ZcAK0askvzIWr4R = ZcAK0askvzIWr4R + '?named=' + name + FglT5H2faVGm6IqpcXS9vQsojPLu + '__download'
						aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + '/search?s='+search
	KKlnDcetq8Rrp3GY0(url)
	return
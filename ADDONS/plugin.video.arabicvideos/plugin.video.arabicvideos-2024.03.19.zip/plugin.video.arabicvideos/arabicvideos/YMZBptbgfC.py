# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ALKAWTHAR'
ToYWiIbruzUaNKRPZLG16cAj = '_KWT_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==130: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==131: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==132: rr60PDpqbMehZsYVuHmiAtN = aGvt7WqXMcuO(url)
	elif mode==133: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,SSGEc76fBan2)
	elif mode==134: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==135: rr60PDpqbMehZsYVuHmiAtN = AAtcZRiU7anLkDGsb5Bv9CIKEhW()
	elif mode==139: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text,url)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',139,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,aaeRjxiYcqOI6Sf8,'','',True,'ALKAWTHAR-MENU-1st')
	pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('dropdown-menu(.*?)dropdown-toggle',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[1]
	items=SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if '/conductor' in ZcAK0askvzIWr4R: continue
		title = title.strip(' ')
		url = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
		if '/category/' in url: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,132)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,131)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المسلسلات',aaeRjxiYcqOI6Sf8+'/category/543',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الأفلام',aaeRjxiYcqOI6Sf8+'/category/628',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'برامج الصغار والشباب',aaeRjxiYcqOI6Sf8+'/category/517',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'ابرز البرامج',aaeRjxiYcqOI6Sf8+'/category/1763',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المحاضرات',aaeRjxiYcqOI6Sf8+'/category/943',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'عاشوراء',aaeRjxiYcqOI6Sf8+'/category/1353',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'البرامج الاجتماعية',aaeRjxiYcqOI6Sf8+'/category/501',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'البرامج الدينية',aaeRjxiYcqOI6Sf8+'/category/509',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'البرامج الوثائقية',aaeRjxiYcqOI6Sf8+'/category/553',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'البرامج السياسية',aaeRjxiYcqOI6Sf8+'/category/545',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'كتب',aaeRjxiYcqOI6Sf8+'/category/291',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'تعلم الفارسية',aaeRjxiYcqOI6Sf8+'/category/88',132,'','1')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أرشيف البرامج',aaeRjxiYcqOI6Sf8+'/category/1279',132,'','1')
	return
def KKlnDcetq8Rrp3GY0(url):
	FrQZKzLqRAJDi7buEXnWxyhva = ['/religious','/social','/political','/films','/series']
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','',True,'ALKAWTHAR-TITLES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('titlebar(.*?)titlebar',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in url for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in FrQZKzLqRAJDi7buEXnWxyhva):
		items = SomeI8i56FaDMGPE.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,133,pjMZ802XQCSxYVk,'1')
	elif '/docs' in url:
		items = SomeI8i56FaDMGPE.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,title,ZcAK0askvzIWr4R in items:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,133,pjMZ802XQCSxYVk,'1')
	return
def aGvt7WqXMcuO(url):
	g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = url.split('/')[-1]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','',True,'ALKAWTHAR-CATEGORIES-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('parentcat(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd:
		ooLCwrlF3n0vBjpA(url,'1')
		return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall("href='(.*?)'.*?>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		title = title.strip(' ')
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,132,'','1')
	return
def ooLCwrlF3n0vBjpA(url,SSGEc76fBan2):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','',True,'ALKAWTHAR-EPISODES-1st')
	items = SomeI8i56FaDMGPE.findall('totalpagecount=[\'"](.*?)[\'"]',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not items:
		url = SomeI8i56FaDMGPE.findall('class="news-detail-body".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,134)
		else: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	DXFGjyToNspg4PR2EOMrm = int(items[0])
	name = SomeI8i56FaDMGPE.findall('main-title.*?</a> >(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if name: name = name[0].strip(' ')
	else: name = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = url.split('/')[-1]
		if SSGEc76fBan2=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8 + '/category/' + g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B + '/' + SSGEc76fBan2
		ppq6Bg4vPbVs = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','',True,'ALKAWTHAR-EPISODES-2nd')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('currentpagenumber(.*?)pagination',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,type,ZcAK0askvzIWr4R,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n','')
			title = title.strip(' ')
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B=='628': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,133,pjMZ802XQCSxYVk,'1')
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,134,pjMZ802XQCSxYVk)
	elif '/episode/' in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('playlist(.*?)col-md-12',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,134,pjMZ802XQCSxYVk)
		elif '/category/628' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
				title = '_MOD_' + 'ملف التشغيل'
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,134)
		else:
			items = SomeI8i56FaDMGPE.findall('id="Categories.*?href=\'(.*?)\'',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = items[0].split('/')[-1]
			url = aaeRjxiYcqOI6Sf8 + '/category/' + g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B
			aGvt7WqXMcuO(url)
			return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		RdXny2FQiKZEWgf = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in RdXny2FQiKZEWgf:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('&amp;','&')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,133)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	if '/news/' in url or '/episode/' in url:
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','',True,'ALKAWTHAR-PLAY-1st')
		items = SomeI8i56FaDMGPE.findall("mobilevideopath.*?value='(.*?)'",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if items: url = items[0]
	kFygcp2jqSUCiNRnur71xMZI96(url,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def AAtcZRiU7anLkDGsb5Bv9CIKEhW():
	url = aaeRjxiYcqOI6Sf8+'/live'
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','',True,'ALKAWTHAR-LIVE-1st')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('live-container.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
	mgDoj8ZAqe0uBLxP4Kzp = {'Referer':aaeRjxiYcqOI6Sf8}
	RKBm27pOP0frivqSgzwMA58 = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'',mgDoj8ZAqe0uBLxP4Kzp,'',True,'ALKAWTHAR-LIVE-2nd')
	ppq6Bg4vPbVs = RKBm27pOP0frivqSgzwMA58.content
	ii1SRMJ8xhIz5yl0Xptb9a = SomeI8i56FaDMGPE.findall('csrf-token" content="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
	ii1SRMJ8xhIz5yl0Xptb9a = ii1SRMJ8xhIz5yl0Xptb9a[0]
	sXFCrSOnM8iuc = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = SomeI8i56FaDMGPE.findall("playUrl = '(.*?)'",ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = sXFCrSOnM8iuc+XuItmjBhoUDa3fRO9nQsbNYrpG1cdv[0]
	crf9moYRDNxwtyJ = {'X-CSRF-TOKEN':ii1SRMJ8xhIz5yl0Xptb9a}
	ry5LDgQtWUwXnCeHsSJk0x = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,'',crf9moYRDNxwtyJ,False,True,'ALKAWTHAR-LIVE-3rd')
	kJRawliTqbIPKuc = ry5LDgQtWUwXnCeHsSJk0x.content
	jx63XqgpYedEM1lZ = SomeI8i56FaDMGPE.findall('"(.*?)"',kJRawliTqbIPKuc,SomeI8i56FaDMGPE.DOTALL)
	jx63XqgpYedEM1lZ = jx63XqgpYedEM1lZ[0].replace('\/','/')
	kFygcp2jqSUCiNRnur71xMZI96(jx63XqgpYedEM1lZ,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'live')
	return
def kV5Wue06vFixocBhPIZY9z(search,url=''):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if url=='':
		if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
		if search=='': return
		search = TbEVs6mLPHF(search)
		url = aaeRjxiYcqOI6Sf8+'/search?q='+search
		ooLCwrlF3n0vBjpA(url,'')
		return
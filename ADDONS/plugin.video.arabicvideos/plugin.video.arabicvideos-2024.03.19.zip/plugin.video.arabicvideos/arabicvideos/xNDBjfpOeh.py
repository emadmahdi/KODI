# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'EGYBEST4'
ToYWiIbruzUaNKRPZLG16cAj = '_EB4_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==800: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==801: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==802: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==803: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==804: rr60PDpqbMehZsYVuHmiAtN = BexcQj7TyYU84szLOSa9JR0(url)
	elif mode==806: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,SSGEc76fBan2)
	elif mode==809: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر',aaeRjxiYcqOI6Sf8+'/trending',804,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','EGYBEST4-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('nav-categories(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('mainContent(.*?)<footer>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801,'','mainmenu')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-menu(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('mainTitle.*?>(.*?)<(.*?)pageContent',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6,items = '','',[]
		for name,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			if 'حلقات' in name: gbRaTlfw5quES79COD2yPhJXzie6 = L0Uwx52bTBM
			if 'مواسم' in name: v0hReYLd84QxBaq7Og6nlV = L0Uwx52bTBM
		if v0hReYLd84QxBaq7Og6nlV and not type:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',v0hReYLd84QxBaq7Og6nlV,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,806,pjMZ802XQCSxYVk,'season')
		if gbRaTlfw5quES79COD2yPhJXzie6 and len(items)<2:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
			if items:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,803,pjMZ802XQCSxYVk)
			else:
				items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
				for ZcAK0askvzIWr4R,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,803)
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	TTCEsZlVieuSa1OWbAmGoPdgtR9,start,C4CEWLV96T8Dwzd,select,LrcJa0TQS632PNu7xHGFiqCdX51ZsR = 0,0,'','',''
	if 'pagination' in type:
		ALIXNYBjeZgf5OEdyD,ZZm1hsDV9ba = url.split('?next=page&')
		mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',ALIXNYBjeZgf5OEdyD,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','EGYBEST4-TITLES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ppq6Bg4vPbVs = 'secContent'+BsJ71WIxDtdFKveTcRPrqM4Cwb+'<footer>'
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ppq6Bg4vPbVs = BsJ71WIxDtdFKveTcRPrqM4Cwb
	items,EEQy35Z2dq6DHvLKXA,LE0VmiWeMGS4dHJ3 = [],False,False
	if not type and '/collections' not in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('mainContent(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801,'','submenu')
				EEQy35Z2dq6DHvLKXA = True
	if not EEQy35Z2dq6DHvLKXA:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('secContent(.*?)mainContent',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.strip('\n')
				title = dCFP41Kxv9j8EHM(title)
				if '/series/' in ZcAK0askvzIWr4R and type=='season': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,806,pjMZ802XQCSxYVk,'season')
				elif '/series/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,806,pjMZ802XQCSxYVk)
				elif '/seasons/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801,pjMZ802XQCSxYVk,'season')
				elif '/collections' in url: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801,pjMZ802XQCSxYVk,'collections')
				else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,803,pjMZ802XQCSxYVk)
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('loadMoreParams = (.*?);',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			xxCrhZTnyoJjWEk6vBqLe1dzI = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',L0Uwx52bTBM)
			LrcJa0TQS632PNu7xHGFiqCdX51ZsR = xxCrhZTnyoJjWEk6vBqLe1dzI['ajaxurl']
			rTcXIjKgMCUdaPSWkn = int(xxCrhZTnyoJjWEk6vBqLe1dzI['current_page'])+1
			nF7YrA4Uu10yVHcdBoqMGjZCtvl5e = int(xxCrhZTnyoJjWEk6vBqLe1dzI['max_page'])
			zvGKEMfx3huC9HAw41RZSymjbTI = xxCrhZTnyoJjWEk6vBqLe1dzI['posts'].replace('False','false').replace('True','true').replace('None','null')
			if rTcXIjKgMCUdaPSWkn<nF7YrA4Uu10yVHcdBoqMGjZCtvl5e:
				ZZm1hsDV9ba = 'action=loadmore&query='+TbEVs6mLPHF(zvGKEMfx3huC9HAw41RZSymjbTI,'')+'&page='+str(rTcXIjKgMCUdaPSWkn)
				vfIB6ib8q1hFX5GweRrVPNTjY2E = LrcJa0TQS632PNu7xHGFiqCdX51ZsR+'?next=page&'+ZZm1hsDV9ba
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'جلب المزيد',vfIB6ib8q1hFX5GweRrVPNTjY2E,801,'','pagination_'+type)
		elif '?next=page&' in url:
			ZZm1hsDV9ba,i0anImls2WOQ79MyZFf = ZZm1hsDV9ba.rsplit('=',1)
			i0anImls2WOQ79MyZFf = int(i0anImls2WOQ79MyZFf)+1
			vfIB6ib8q1hFX5GweRrVPNTjY2E = ALIXNYBjeZgf5OEdyD+'?next=page&'+ZZm1hsDV9ba+'='+str(i0anImls2WOQ79MyZFf)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'جلب المزيد',vfIB6ib8q1hFX5GweRrVPNTjY2E,801,'','pagination_'+type)
	return
def BexcQj7TyYU84szLOSa9JR0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('sub_nav(.*?)secContent ',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('"current_opt">(.*?)<(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for name,L0Uwx52bTBM in UUTVrGP7Y31a:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,EPwT39HrS1tU6Ng8YBGpJADixzLV5C in items:
				title = name+':  '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,801,'','filter')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('<td>التصنيف</td>.*?">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	TbFRyPoVlrQAw7n3h8BukmfHNq,ZqrDM2pIkCR89FP3On = [],[]
	OAp6L3KTXke8EsZF1PCo97 = SomeI8i56FaDMGPE.findall('postEmbed.*?post=(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if OAp6L3KTXke8EsZF1PCo97:
		ZZHhmdtY1g = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(OAp6L3KTXke8EsZF1PCo97[0])
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: ZZHhmdtY1g = ZZHhmdtY1g.decode('utf8')
		ZZHhmdtY1g = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',ZZHhmdtY1g)
		ZZHhmdtY1g = list(ZZHhmdtY1g.values())
		for ZcAK0askvzIWr4R in ZZHhmdtY1g:
			if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
				ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
				FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__watch')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pageContentDown(.*?)</table>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R in items:
			if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
				if '/?url=' in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('/?url=')[1]
				ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
				FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__download____'+AfejZJoKh4D7k5G1P9gCwxTz)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search: search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/?s='+u9DhgpinLBfmjG3NtMalq7Y
	KKlnDcetq8Rrp3GY0(url,'search')
	return
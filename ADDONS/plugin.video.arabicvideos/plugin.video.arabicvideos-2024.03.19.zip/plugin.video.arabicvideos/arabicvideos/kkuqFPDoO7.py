# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
import bs4 as QDsbSf07HVUG8ad25vnyYx
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ELCINEMA'
ToYWiIbruzUaNKRPZLG16cAj = '_ELC_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
headers = {'Referer':aaeRjxiYcqOI6Sf8}
C1pRb6K8Qs = []
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==510: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==511: rr60PDpqbMehZsYVuHmiAtN = cUevYMCfpTLG9q2lRFmtZD5NP0S7j(url)
	elif mode==512: rr60PDpqbMehZsYVuHmiAtN = yH7mPE14qeX8ZfMk(url)
	elif mode==513: rr60PDpqbMehZsYVuHmiAtN = FBopUmhiTvyrKg0YLC1(url)
	elif mode==514: rr60PDpqbMehZsYVuHmiAtN = UUxr70gbm6JTkQPGHtclSvA5Lyw34p(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: rr60PDpqbMehZsYVuHmiAtN = UUxr70gbm6JTkQPGHtclSvA5Lyw34p(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: rr60PDpqbMehZsYVuHmiAtN = TAP5RmH2sZ(text)
	elif mode==517: rr60PDpqbMehZsYVuHmiAtN = OQFaCWP5Az0ER8b9Udwo(url)
	elif mode==518: rr60PDpqbMehZsYVuHmiAtN = PSAwkGb3yJz1TU7xVYlWhe(url)
	elif mode==519: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	elif mode==520: rr60PDpqbMehZsYVuHmiAtN = OC4lH0hicWwxjDY1VzyJpBs5XAt(url)
	elif mode==521: rr60PDpqbMehZsYVuHmiAtN = RxE701ocWqU(url)
	elif mode==522: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==523: rr60PDpqbMehZsYVuHmiAtN = O3PhAu7zcCgEtS6GVTv(text)
	elif mode==524: rr60PDpqbMehZsYVuHmiAtN = VMnefPlqwmdAh0D4O()
	elif mode==525: rr60PDpqbMehZsYVuHmiAtN = mxv9YT6Rusz4F0C1PtEIW()
	elif mode==526: rr60PDpqbMehZsYVuHmiAtN = mCLthWq40xjcsMgenFv()
	elif mode==527: rr60PDpqbMehZsYVuHmiAtN = QHpi9heco2Dz3d()
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث بموسوعة السينما','',519)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'موسوعة الأعمال','',525)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'موسوعة الأشخاص','',526)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'موسوعة المصنفات','',527)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'موسوعة المنوعات','',524)
	return
def VMnefPlqwmdAh0D4O():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' فيديوهات - خاصة',aaeRjxiYcqOI6Sf8+'/video',520)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فيديوهات - أحدث',aaeRjxiYcqOI6Sf8+'/video/latest',521)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فيديوهات - أقدم',aaeRjxiYcqOI6Sf8+'/video/oldest',521)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فيديوهات - أكثر مشاهدة',aaeRjxiYcqOI6Sf8+'/video/views',521)
	return
def mxv9YT6Rusz4F0C1PtEIW():
	TWSqp46tAroe = aaeRjxiYcqOI6Sf8+'/lineup?utf8=%E2%9C%93'
	wG5UAEIDfqWYbdkslR4yZC1pN73 = TWSqp46tAroe+'&type=2&category=1&foreign=false&tag='
	OSFPDYGKxoX6RNvnAIhk = TWSqp46tAroe+'&type=2&category=3&foreign=false&tag='
	lNiSWE2w8hv1P5AHO3VFufbMLmC = TWSqp46tAroe+'&type=2&category=1&foreign=true&tag='
	JApHz8h0g9IrFMuW = TWSqp46tAroe+'&type=2&category=3&foreign=true&tag='
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات أفلام عربي',wG5UAEIDfqWYbdkslR4yZC1pN73,511)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات مسلسلات عربي',OSFPDYGKxoX6RNvnAIhk,511)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات أفلام اجنبي',lNiSWE2w8hv1P5AHO3VFufbMLmC,511)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات مسلسلات اجنبي',JApHz8h0g9IrFMuW,511)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس أعمال أبجدي',aaeRjxiYcqOI6Sf8+'/index/work/alphabet',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس  بلد الإنتاج',aaeRjxiYcqOI6Sf8+'/index/work/country',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس اللغة',aaeRjxiYcqOI6Sf8+'/index/work/language',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس مصنفات العمل',aaeRjxiYcqOI6Sf8+'/index/work/genre',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس سنة الإصدار',aaeRjxiYcqOI6Sf8+'/index/work/release_year',517)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مواسم - فلتر محدد',aaeRjxiYcqOI6Sf8+'/seasonals',515)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مواسم - فلتر كامل',aaeRjxiYcqOI6Sf8+'/seasonals',514)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات - فلتر محدد',aaeRjxiYcqOI6Sf8+'/lineup',515)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات - فلتر كامل',aaeRjxiYcqOI6Sf8+'/lineup',514)
	return
def QHpi9heco2Dz3d():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	L0Uwx52bTBM = TlxJ0N5FHaLGQ7UIoeBw96.find('select',attrs={'name':'tag'})
	lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN = L0Uwx52bTBM.find_all('option')
	for irE1qv3BUYZMo5 in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN:
		EPwT39HrS1tU6Ng8YBGpJADixzLV5C = irE1qv3BUYZMo5.get('value')
		if not EPwT39HrS1tU6Ng8YBGpJADixzLV5C: continue
		title = irE1qv3BUYZMo5.text
		if BhTAck1bPFYGuUqRW:
			title = title.encode('utf8')
			EPwT39HrS1tU6Ng8YBGpJADixzLV5C = EPwT39HrS1tU6Ng8YBGpJADixzLV5C.encode('utf8')
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		title = title.replace('قائمة ','')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,511)
	return
def mCLthWq40xjcsMgenFv():
	TWSqp46tAroe = aaeRjxiYcqOI6Sf8+'/lineup?utf8=%E2%9C%93'
	ePacgFHYrnlXC = TWSqp46tAroe+'&type=1&category=&foreign=&tag='
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات أشخاص',ePacgFHYrnlXC,511)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس أشخاص أبجدي',aaeRjxiYcqOI6Sf8+'/index/person/alphabet',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس موطن',aaeRjxiYcqOI6Sf8+'/index/person/nationality',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس  تاريخ الميلاد',aaeRjxiYcqOI6Sf8+'/index/person/birth_year',517)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فهرس  تاريخ الوفاة',aaeRjxiYcqOI6Sf8+'/index/person/death_year',517)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات - فلتر محدد',aaeRjxiYcqOI6Sf8+'/lineup',515)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مصنفات - فلتر كامل',aaeRjxiYcqOI6Sf8+'/lineup',514)
	return
def cUevYMCfpTLG9q2lRFmtZD5NP0S7j(url):
	if '/seasonals' in url: fMGn2cXPKw9SyUY = 0
	elif '/lineup' in url: fMGn2cXPKw9SyUY = 1
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	UUTVrGP7Y31a = TlxJ0N5FHaLGQ7UIoeBw96.find_all(class_='jumbo-theater clearfix')
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		title = L0Uwx52bTBM.find_all('a')[fMGn2cXPKw9SyUY].text
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+L0Uwx52bTBM.find_all('a')[fMGn2cXPKw9SyUY].get('href')
		if BhTAck1bPFYGuUqRW:
			title = title.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
		if not UUTVrGP7Y31a:
			yH7mPE14qeX8ZfMk(ZcAK0askvzIWr4R)
			return
		else:
			title = title.replace('قائمة ','')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,512)
	ooUYi4IHuh7alWz(TlxJ0N5FHaLGQ7UIoeBw96,511)
	return
def ooUYi4IHuh7alWz(TlxJ0N5FHaLGQ7UIoeBw96,mode):
	L0Uwx52bTBM = TlxJ0N5FHaLGQ7UIoeBw96.find(class_='pagination')
	if L0Uwx52bTBM:
		RdXny2FQiKZEWgf = L0Uwx52bTBM.find_all('a')
		Ol6BaSm04ALYXH1jexTW2f5ZMuRdni = L0Uwx52bTBM.find_all('li')
		fZhoJkXpqDsKS0WGOcMCEY8i = list(zip(RdXny2FQiKZEWgf,Ol6BaSm04ALYXH1jexTW2f5ZMuRdni))
		jUSuZAztxy34TB5CIP2 = -1
		E2EtAT9INQC8Gwkgs7 = len(fZhoJkXpqDsKS0WGOcMCEY8i)
		for i0anImls2WOQ79MyZFf,IIsZOJCNxg0Ep in fZhoJkXpqDsKS0WGOcMCEY8i:
			jUSuZAztxy34TB5CIP2 += 1
			IIsZOJCNxg0Ep = IIsZOJCNxg0Ep['class']
			if 'unavailable' in IIsZOJCNxg0Ep or 'current' in IIsZOJCNxg0Ep: continue
			Fc3PbKsrWIt150De4wYGqmay82X = i0anImls2WOQ79MyZFf.text
			spdYctk0fWD1Z = aaeRjxiYcqOI6Sf8+i0anImls2WOQ79MyZFf.get('href')
			if BhTAck1bPFYGuUqRW:
				Fc3PbKsrWIt150De4wYGqmay82X = Fc3PbKsrWIt150De4wYGqmay82X.encode('utf8')
				spdYctk0fWD1Z = spdYctk0fWD1Z.encode('utf8')
			if   jUSuZAztxy34TB5CIP2==0: Fc3PbKsrWIt150De4wYGqmay82X = 'أولى'
			elif jUSuZAztxy34TB5CIP2==1: Fc3PbKsrWIt150De4wYGqmay82X = 'سابقة'
			elif jUSuZAztxy34TB5CIP2==E2EtAT9INQC8Gwkgs7-2: Fc3PbKsrWIt150De4wYGqmay82X = 'لاحقة'
			elif jUSuZAztxy34TB5CIP2==E2EtAT9INQC8Gwkgs7-1: Fc3PbKsrWIt150De4wYGqmay82X = 'أخيرة'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+Fc3PbKsrWIt150De4wYGqmay82X,spdYctk0fWD1Z,mode)
	return
def yH7mPE14qeX8ZfMk(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	UUTVrGP7Y31a = TlxJ0N5FHaLGQ7UIoeBw96.find_all(class_='row')
	items,Q9yuovbz1BXVkdm = [],True
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		if not L0Uwx52bTBM.find(class_='thumbnail-wrapper'): continue
		if Q9yuovbz1BXVkdm: Q9yuovbz1BXVkdm = False ; continue
		sEqxnXAOT5M6j4zkVSC = []
		xBWhFLQ8l6opdkMy = L0Uwx52bTBM.find_all(class_=['censorship red','censorship purple'])
		for gk1cob8nW5UsTjI4Lz2t96q in xBWhFLQ8l6opdkMy:
			dTsUxZbrBYVlazjgmf9Kw2 = gk1cob8nW5UsTjI4Lz2t96q.find_all('li')[1].text
			if BhTAck1bPFYGuUqRW:
				dTsUxZbrBYVlazjgmf9Kw2 = dTsUxZbrBYVlazjgmf9Kw2.encode('utf8')
			sEqxnXAOT5M6j4zkVSC.append(dTsUxZbrBYVlazjgmf9Kw2)
		if not d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'',sEqxnXAOT5M6j4zkVSC,False):
			NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('data-src')
			title = L0Uwx52bTBM.find('h3')
			name = title.find('a').text
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+title.find('a').get('href')
			wQa4xXdUfzh2M5g30WD = L0Uwx52bTBM.find(class_='no-margin')
			xxDKHemyd1riQnaj4RGskLbp9CI7 = L0Uwx52bTBM.find(class_='legend')
			if wQa4xXdUfzh2M5g30WD: wQa4xXdUfzh2M5g30WD = wQa4xXdUfzh2M5g30WD.text
			if xxDKHemyd1riQnaj4RGskLbp9CI7: xxDKHemyd1riQnaj4RGskLbp9CI7 = xxDKHemyd1riQnaj4RGskLbp9CI7.text
			if BhTAck1bPFYGuUqRW:
				NmX0ZP715phHsSiCzvxR3IB = NmX0ZP715phHsSiCzvxR3IB.encode('utf8')
				name = name.encode('utf8')
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
				if wQa4xXdUfzh2M5g30WD: wQa4xXdUfzh2M5g30WD = wQa4xXdUfzh2M5g30WD.encode('utf8')
			MIe5q0WmGnJF9wp2tfk = {}
			if xxDKHemyd1riQnaj4RGskLbp9CI7: MIe5q0WmGnJF9wp2tfk['stars'] = xxDKHemyd1riQnaj4RGskLbp9CI7
			if wQa4xXdUfzh2M5g30WD:
				wQa4xXdUfzh2M5g30WD = wQa4xXdUfzh2M5g30WD.replace('\n',' .. ')
				MIe5q0WmGnJF9wp2tfk['plot'] = wQa4xXdUfzh2M5g30WD.replace('...اقرأ المزيد','')
			if '/work/' in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,516,NmX0ZP715phHsSiCzvxR3IB,'',name,'',MIe5q0WmGnJF9wp2tfk)
			elif '/person/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,513,NmX0ZP715phHsSiCzvxR3IB,'',name,'',MIe5q0WmGnJF9wp2tfk)
	ooUYi4IHuh7alWz(TlxJ0N5FHaLGQ7UIoeBw96,512)
	return
def FBopUmhiTvyrKg0YLC1(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	UUTVrGP7Y31a = TlxJ0N5FHaLGQ7UIoeBw96.find_all('li')
	wwpNZP87O2YjJIFT0rH95Al43RCWzi,items = [],[]
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		if not L0Uwx52bTBM.find(class_='thumbnail-wrapper'): continue
		if not L0Uwx52bTBM.find(class_=['unstyled','unstyled text-center']): continue
		if L0Uwx52bTBM.find(class_='hide'): continue
		title = L0Uwx52bTBM.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in wwpNZP87O2YjJIFT0rH95Al43RCWzi: continue
		wwpNZP87O2YjJIFT0rH95Al43RCWzi.append(name)
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+title.find('a').get('href')
		if '/search/work/' in url: NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('src')
		elif '/search/person/' in url: NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('data-src')
		elif '/search/video/' in url: NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('data-src')
		else: NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('src')
		if BhTAck1bPFYGuUqRW:
			name = name.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
			NmX0ZP715phHsSiCzvxR3IB = NmX0ZP715phHsSiCzvxR3IB.encode('utf8')
		name = name.strip(' ')
		items.append((name,ZcAK0askvzIWr4R,NmX0ZP715phHsSiCzvxR3IB))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ZcAK0askvzIWr4R,NmX0ZP715phHsSiCzvxR3IB in items:
		if '/search/video/' in url: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,522,NmX0ZP715phHsSiCzvxR3IB)
		elif '/search/person/' in url: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,513,NmX0ZP715phHsSiCzvxR3IB,'',name)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,516,NmX0ZP715phHsSiCzvxR3IB,'',name)
	return
def TAP5RmH2sZ(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	kvQE6NV74smCtblX2dfwJHG = text.count(' ')+1
	if kvQE6NV74smCtblX2dfwJHG==1:
		O3PhAu7zcCgEtS6GVTv(text)
		return
	UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	SSJC1HD5MsO29pXLWnmxAdyKeuobGj = text.split(' ')
	etHVXsyG7ZRWjB4CKxYr1fSvE5A = pow(2,kvQE6NV74smCtblX2dfwJHG)
	uWakC4XPIiZqNGlMS3FJnO = []
	def YCs8BzTcGHMo7SJVL2QgatmExN43Ar(kP0sCD5ZML7viFtzIR8,CAOVeJHpRqzgnx4MG):
		if kP0sCD5ZML7viFtzIR8=='1': return CAOVeJHpRqzgnx4MG
		return ''
	for jUSuZAztxy34TB5CIP2 in range(etHVXsyG7ZRWjB4CKxYr1fSvE5A,0,-1):
		GFVPMdhiaLnQKsx = list(kvQE6NV74smCtblX2dfwJHG*'0'+bin(jUSuZAztxy34TB5CIP2)[2:])[-kvQE6NV74smCtblX2dfwJHG:]
		GFVPMdhiaLnQKsx = reversed(GFVPMdhiaLnQKsx)
		PcwChNBYmt4ruvsIEo = map(YCs8BzTcGHMo7SJVL2QgatmExN43Ar,GFVPMdhiaLnQKsx,SSJC1HD5MsO29pXLWnmxAdyKeuobGj)
		title = ' '.join(filter(None,PcwChNBYmt4ruvsIEo))
		if BhTAck1bPFYGuUqRW: U2iQmHMJzoNkjORTGY7c51vZ = title.decode('utf8')
		else: U2iQmHMJzoNkjORTGY7c51vZ = title
		if len(U2iQmHMJzoNkjORTGY7c51vZ)>2 and title not in uWakC4XPIiZqNGlMS3FJnO:
			uWakC4XPIiZqNGlMS3FJnO.append(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,'',523,'','',title)
	return
def O3PhAu7zcCgEtS6GVTv(IPmuvN2LSdO9nlHw):
	if BhTAck1bPFYGuUqRW:
		IPmuvN2LSdO9nlHw = IPmuvN2LSdO9nlHw.decode('utf8')
		import arabic_reshaper as JJGORcDKPvlWZrB
		IPmuvN2LSdO9nlHw = JJGORcDKPvlWZrB.ArabicReshaper().reshape(IPmuvN2LSdO9nlHw)
		IPmuvN2LSdO9nlHw = Xpa41TEJ2Wl.get_display(IPmuvN2LSdO9nlHw)
	import CPxLIa1p4F
	IPmuvN2LSdO9nlHw = ymH9jzg2KId5MCvw8lXBZn(default=IPmuvN2LSdO9nlHw)
	CPxLIa1p4F.kV5Wue06vFixocBhPIZY9z(IPmuvN2LSdO9nlHw)
	return
def OQFaCWP5Az0ER8b9Udwo(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	L0Uwx52bTBM = TlxJ0N5FHaLGQ7UIoeBw96.find(class_='list-separator list-title')
	R3Rinqky4ouBgYEtZh = L0Uwx52bTBM.find_all('a')
	items = []
	for title in R3Rinqky4ouBgYEtZh:
		name = title.text
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+title.get('href')
		if BhTAck1bPFYGuUqRW:
			name = name.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
		if '#' not in ZcAK0askvzIWr4R: items.append((name,ZcAK0askvzIWr4R))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for MMeFJKLQG4HdIwObZ1l9 in items:
		name,ZcAK0askvzIWr4R = MMeFJKLQG4HdIwObZ1l9
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,518)
	return
def PSAwkGb3yJz1TU7xVYlWhe(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	UUTVrGP7Y31a = TlxJ0N5FHaLGQ7UIoeBw96.find(class_='expand').find_all('tr')
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		AfHKjPRnTG7DCvoBOwtb2uc95 = L0Uwx52bTBM.find_all('a')
		if not AfHKjPRnTG7DCvoBOwtb2uc95: continue
		NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('data-src')
		name = AfHKjPRnTG7DCvoBOwtb2uc95[1].text
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+AfHKjPRnTG7DCvoBOwtb2uc95[1].get('href')
		xxDKHemyd1riQnaj4RGskLbp9CI7 = L0Uwx52bTBM.find(class_='legend')
		if xxDKHemyd1riQnaj4RGskLbp9CI7: xxDKHemyd1riQnaj4RGskLbp9CI7 = xxDKHemyd1riQnaj4RGskLbp9CI7.text
		if BhTAck1bPFYGuUqRW:
			name = name.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
			NmX0ZP715phHsSiCzvxR3IB = NmX0ZP715phHsSiCzvxR3IB.encode('utf8')
		MIe5q0WmGnJF9wp2tfk = {}
		if xxDKHemyd1riQnaj4RGskLbp9CI7: MIe5q0WmGnJF9wp2tfk['stars'] = xxDKHemyd1riQnaj4RGskLbp9CI7
		if '/work/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,516,NmX0ZP715phHsSiCzvxR3IB,'',name,'',MIe5q0WmGnJF9wp2tfk)
		elif '/person/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,513,NmX0ZP715phHsSiCzvxR3IB,'',name,'',MIe5q0WmGnJF9wp2tfk)
	ooUYi4IHuh7alWz(TlxJ0N5FHaLGQ7UIoeBw96,518)
	return
def OC4lH0hicWwxjDY1VzyJpBs5XAt(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	R3Rinqky4ouBgYEtZh = TlxJ0N5FHaLGQ7UIoeBw96.find_all(class_='section-title inline')
	ZZHhmdtY1g = TlxJ0N5FHaLGQ7UIoeBw96.find_all(class_='button green small right')
	items = zip(R3Rinqky4ouBgYEtZh,ZZHhmdtY1g)
	for title,ZcAK0askvzIWr4R in items:
		title = title.text
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R.get('href')
		if BhTAck1bPFYGuUqRW:
			title = title.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,521)
	return
def RxE701ocWqU(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	MePgFBdpkSQs6hrORVC07IU = TlxJ0N5FHaLGQ7UIoeBw96.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	UUTVrGP7Y31a = MePgFBdpkSQs6hrORVC07IU.find_all('li')
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		title = L0Uwx52bTBM.find(class_='title').text
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+L0Uwx52bTBM.find('a').get('href')
		NmX0ZP715phHsSiCzvxR3IB = L0Uwx52bTBM.find('img').get('data-src')
		DD1IVWFZbr7TlzYto5s = L0Uwx52bTBM.find(class_='duration').text
		if BhTAck1bPFYGuUqRW:
			title = title.encode('utf8')
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
			NmX0ZP715phHsSiCzvxR3IB = NmX0ZP715phHsSiCzvxR3IB.encode('utf8')
			DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.encode('utf8')
		DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace('\n','').strip(' ')
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,522,NmX0ZP715phHsSiCzvxR3IB,DD1IVWFZbr7TlzYto5s)
	ooUYi4IHuh7alWz(TlxJ0N5FHaLGQ7UIoeBw96,521)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	ZcAK0askvzIWr4R = TlxJ0N5FHaLGQ7UIoeBw96.find(class_='flex-video').find('iframe').get('src')
	if BhTAck1bPFYGuUqRW: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.encode('utf8')
	kFygcp2jqSUCiNRnur71xMZI96(ZcAK0askvzIWr4R,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','%20')
	url = aaeRjxiYcqOI6Sf8+'/search/?q='+search
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not ttpgqJBdkoxeKOcwaiP.succeeded:
		ePacgFHYrnlXC = aaeRjxiYcqOI6Sf8+'/search_entity/?q='+search+'&entity=work'
		spdYctk0fWD1Z = aaeRjxiYcqOI6Sf8+'/search_entity/?q='+search+'&entity=person'
		z9O4PeyH6JbLto8cgvVFwhWn7E = aaeRjxiYcqOI6Sf8+'/search_entity/?q='+search+'&entity=video'
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن أعمال',ePacgFHYrnlXC,513,'',search)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن أشخاص',spdYctk0fWD1Z,513,'',search)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن فيديوهات',z9O4PeyH6JbLto8cgvVFwhWn7E,513,'',search)
		return
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TlxJ0N5FHaLGQ7UIoeBw96 = QDsbSf07HVUG8ad25vnyYx.BeautifulSoup(BsJ71WIxDtdFKveTcRPrqM4Cwb,'html.parser',multi_valued_attributes=None)
	UUTVrGP7Y31a = TlxJ0N5FHaLGQ7UIoeBw96.find_all(class_='section-title left')
	for L0Uwx52bTBM in UUTVrGP7Y31a:
		title = L0Uwx52bTBM.text
		if BhTAck1bPFYGuUqRW:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: ZcAK0askvzIWr4R = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ZcAK0askvzIWr4R = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ZcAK0askvzIWr4R = url.replace('/search/','/search/video/')
		else: continue
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,513)
	return
def UUxr70gbm6JTkQPGHtclSvA5Lyw34p(url,text):
	global tE62imyGZoBe,JR6bW8Bc7ig
	if '/seasonals' in url:
		tE62imyGZoBe = ['seasonal','year','category']
		JR6bW8Bc7ig = ['seasonal','year','category']
	elif '/lineup' in url:
		tE62imyGZoBe = ['category','foreign','type']
		JR6bW8Bc7ig = ['category','foreign','type']
	gj2tQTVYG87dUpsMXPqrv(url,text)
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	url = url.split('/smartemadfilter?')[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('form action="/(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('<option value="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def b5xIesmNZ73Ju4tKg1T(url):
	nnjrtO4FdM = url.split('/smartemadfilter?')[0]
	guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def Qnbk31TlhXADds(GGw4ZcYsxyNT6BmQf1jEJKa7pR,url):
	rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'all_filters')
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = b5xIesmNZ73Ju4tKg1T(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
	return XuItmjBhoUDa3fRO9nQsbNYrpG1cdv
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tE62imyGZoBe[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[0]
		for zz5ZOaoyATpS893tvdXE in range(len(tE62imyGZoBe[0:-1])):
			if tE62imyGZoBe[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='ALL_ITEMS_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',vfIB6ib8q1hFX5GweRrVPNTjY2E,511)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',vfIB6ib8q1hFX5GweRrVPNTjY2E,511)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,mjcA3DUe9IJV4bk,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		name = name.replace('--','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='SPECIFIED_FILTER':
			if mjcA3DUe9IJV4bk not in tE62imyGZoBe: continue
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]:
					url = b5xIesmNZ73Ju4tKg1T(url)
					yH7mPE14qeX8ZfMk(url)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'SPECIFIED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,511)
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,515,'','',ecMSxgw2QqpvI)
		elif type=='ALL_ITEMS_FILTER':
			if mjcA3DUe9IJV4bk not in JR6bW8Bc7ig: continue
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع: '+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,514,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			if 'مصنفات أخرى' in irE1qv3BUYZMo5: continue
			if 'الكل' in irE1qv3BUYZMo5: continue
			if 'اللغة' in irE1qv3BUYZMo5: continue
			irE1qv3BUYZMo5 = irE1qv3BUYZMo5.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			if name: title = irE1qv3BUYZMo5+' :'+name
			else: title = irE1qv3BUYZMo5
			if type=='ALL_ITEMS_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,514,'','',L6iYCRsI1U4ytrW)
			elif type=='SPECIFIED_FILTER' and tE62imyGZoBe[-2]+'=' in HxWc8KBlSsT:
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = Qnbk31TlhXADds(GGw4ZcYsxyNT6BmQf1jEJKa7pR,url)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,511)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,515,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in JR6bW8Bc7ig:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all_filters': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
tE62imyGZoBe = []
JR6bW8Bc7ig = []
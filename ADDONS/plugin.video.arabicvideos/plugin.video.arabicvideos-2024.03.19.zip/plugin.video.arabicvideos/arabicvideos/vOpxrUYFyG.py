# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMA400'
ToYWiIbruzUaNKRPZLG16cAj = '_C4H_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد','Categories','']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==690: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==691: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==692: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==693: rr60PDpqbMehZsYVuHmiAtN = Zk56uvyAOlmdBTpQhb4znHr0U9GI(url,text)
	elif mode==694: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==699: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMA400-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',699,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"navslide-divider"(.*?)"navslide-divider"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		title = title.replace('<b>','').strip(' ')
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,694)
	return
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA400-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"caret"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		L0Uwx52bTBM = L0Uwx52bTBM.replace('"presentation"','</ul>')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = [('',L0Uwx52bTBM)]
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for L1AixJmzUDr8P,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if L1AixJmzUDr8P: L1AixJmzUDr8P = L1AixJmzUDr8P+': '
			for ZcAK0askvzIWr4R,title in items:
				title = L1AixJmzUDr8P+title
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,691)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"pm-category-subcats"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if len(items)<30:
			UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ZcAK0askvzIWr4R,title in items:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,691)
	if not q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not EFOPTCNHpGvMYuS: KKlnDcetq8Rrp3GY0(url)
	return
def KKlnDcetq8Rrp3GY0(url,ZuCJj5EwDPROkb7UXNypofl=''):
	if ZuCJj5EwDPROkb7UXNypofl=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,headers,'','','CIMA400-TITLES-1st')
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA400-TITLES-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	L0Uwx52bTBM,items = '',[]
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	if ZuCJj5EwDPROkb7UXNypofl=='ajax-search':
		L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
		BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR: items.append(('',ZcAK0askvzIWr4R,title))
	elif ZuCJj5EwDPROkb7UXNypofl=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pm-video-watch-featured"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif ZuCJj5EwDPROkb7UXNypofl=='new_episodes':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"row pm-ul-browse-videos(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif ZuCJj5EwDPROkb7UXNypofl=='new_movies':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"row pm-ul-browse-videos(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if len(pDTlIgyewF1XV69R8kd)>1: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[1]
	elif ZuCJj5EwDPROkb7UXNypofl=='featured_series':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"ba mgb table full"(.*?)"clearfix"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR: items.append(('',ZcAK0askvzIWr4R,title))
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(data-echo=".*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if L0Uwx52bTBM and not items: items = SomeI8i56FaDMGPE.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items: return
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|حلقة).\d+',title,SomeI8i56FaDMGPE.DOTALL)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,692,pjMZ802XQCSxYVk)
		elif ZuCJj5EwDPROkb7UXNypofl=='new_episodes':
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,692,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0][0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,693,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,693,pjMZ802XQCSxYVk)
	if 1:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if ZcAK0askvzIWr4R=='#': continue
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,691)
	return
def Zk56uvyAOlmdBTpQhb4znHr0U9GI(url,HHhXlVCJAa4gisn9mxZt16P):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA400-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	NmX0ZP715phHsSiCzvxR3IB = SomeI8i56FaDMGPE.findall('"series-header".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if NmX0ZP715phHsSiCzvxR3IB: pjMZ802XQCSxYVk = NmX0ZP715phHsSiCzvxR3IB[0]
	else: pjMZ802XQCSxYVk = ''
	items = []
	c5WyqgJPT6tl7LkdXHeiKFBrZ = False
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not HHhXlVCJAa4gisn9mxZt16P:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not items: items = SomeI8i56FaDMGPE.findall('data-serie="(.*?)".*?">(.*?)</',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for HHhXlVCJAa4gisn9mxZt16P,title in items:
			HHhXlVCJAa4gisn9mxZt16P = HHhXlVCJAa4gisn9mxZt16P.strip('#')
			if len(items)>1: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,693,pjMZ802XQCSxYVk,'',HHhXlVCJAa4gisn9mxZt16P)
			else: c5WyqgJPT6tl7LkdXHeiKFBrZ = True
	else: c5WyqgJPT6tl7LkdXHeiKFBrZ = True
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('id="'+HHhXlVCJAa4gisn9mxZt16P+'"(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not EFOPTCNHpGvMYuS: EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('data-serie="'+HHhXlVCJAa4gisn9mxZt16P+'"(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not EFOPTCNHpGvMYuS: EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('id="Season'+HHhXlVCJAa4gisn9mxZt16P+'"(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS and c5WyqgJPT6tl7LkdXHeiKFBrZ:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall("href='(.*?)'><li><em>(.*?)</span>",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not BAHbWtFdwNps9ZVUfvR: BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<em>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		items = []
		for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR: items.append((ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk))
		if not items: items = SomeI8i56FaDMGPE.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.strip('./')
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/'+ZcAK0askvzIWr4R.strip('/')
			title = title.replace('</em><span>',' ')
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,692,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2,JiRmpe1Pwx,TbFRyPoVlrQAw7n3h8BukmfHNq = [],[],[]
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/watch.php','/see.php')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','CIMA400-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"WatchList"(.*?)</div>.</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<iframe src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
			JiRmpe1Pwx.append('?named=__embed')
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('data-embed-url="(.*?)".*?onclick.*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in ZZHhmdtY1g:
			title = title.strip(' ')
			if ZcAK0askvzIWr4R not in aFyREdMQk7Ys95rX6uJieDGLS2:
				JiRmpe1Pwx.append('?named='+title+'__watch')
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in ZZHhmdtY1g:
			if ZcAK0askvzIWr4R not in aFyREdMQk7Ys95rX6uJieDGLS2:
				title = title.strip('\n')
				JiRmpe1Pwx.append('?named='+title+'__download')
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	XTPzvZdUymK2axoEu8W73BjMcheQf = zip(aFyREdMQk7Ys95rX6uJieDGLS2,JiRmpe1Pwx)
	for ZcAK0askvzIWr4R,name in XTPzvZdUymK2axoEu8W73BjMcheQf: TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+name)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/search.php?keywords='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
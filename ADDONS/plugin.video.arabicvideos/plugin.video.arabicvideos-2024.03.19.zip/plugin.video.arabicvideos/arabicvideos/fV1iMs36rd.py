# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
AdKBOaFs5gt3RoNkwLj = 'FAVORITES'
def PLhWMCuV7DtB(lOH3hXsnQiFCRjbN12,aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG):
	if   lOH3hXsnQiFCRjbN12==270: EIBNGzDg8LUe4w = f8i6KDmBoAz(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG)
	else: EIBNGzDg8LUe4w = False
	return EIBNGzDg8LUe4w
def cbk7C68fFEadM1De3(lsfFwOE5rvtgxQCBo14VU):
	if not lsfFwOE5rvtgxQCBo14VU: return
	if '_' in lsfFwOE5rvtgxQCBo14VU: aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,PgyY0pGWawTz2L8cD = lsfFwOE5rvtgxQCBo14VU.split('_',1)
	else: aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,PgyY0pGWawTz2L8cD = lsfFwOE5rvtgxQCBo14VU,''
	if   PgyY0pGWawTz2L8cD=='UP1'	: wBWDNuta1Q5YqV4cUZgGdH(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,True,1)
	elif PgyY0pGWawTz2L8cD=='DOWN1'	: wBWDNuta1Q5YqV4cUZgGdH(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,False,1)
	elif PgyY0pGWawTz2L8cD=='UP4'	: wBWDNuta1Q5YqV4cUZgGdH(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,True,4)
	elif PgyY0pGWawTz2L8cD=='DOWN4'	: wBWDNuta1Q5YqV4cUZgGdH(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,False,4)
	elif PgyY0pGWawTz2L8cD=='ADD1'	: yyfNmzpnHaCAZtrbFjs(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG)
	elif PgyY0pGWawTz2L8cD=='REMOVE1': H5c7v4sChNdljp(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG)
	elif PgyY0pGWawTz2L8cD=='DELETELIST': CZUkjK8GlM(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG)
	return
def f8i6KDmBoAz(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG):
	iKcqvCRx5rVto0uzBE3gd6 = k4tn3CNwPDRBoIpzY2gT()
	if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
		try:
			v8CNoYOSAbGPDyL40lX1ri = iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]
			for jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 in v8CNoYOSAbGPDyL40lX1ri:
				UZ8LYnm5jsl9uKM0xDX(jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60)
		except:
			iKcqvCRx5rVto0uzBE3gd6 = itTndG7sM4oAk90qEX83(YbTWJNjEGPC12RZzHioatgvu)
			v8CNoYOSAbGPDyL40lX1ri = iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]
			for jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 in v8CNoYOSAbGPDyL40lX1ri:
				UZ8LYnm5jsl9uKM0xDX(jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60)
	return
def yyfNmzpnHaCAZtrbFjs(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
	peGKZ47miuytWS8X = jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,'',AFbdWemQRHznuiv60
	iKcqvCRx5rVto0uzBE3gd6 = k4tn3CNwPDRBoIpzY2gT()
	m2ZuVhQTeP7UR9lxNHogK6 = {}
	for XMxZNTL8HbGD5pzVQ63sY72Wafom4 in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
		if XMxZNTL8HbGD5pzVQ63sY72Wafom4!=aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG: m2ZuVhQTeP7UR9lxNHogK6[XMxZNTL8HbGD5pzVQ63sY72Wafom4] = iKcqvCRx5rVto0uzBE3gd6[XMxZNTL8HbGD5pzVQ63sY72Wafom4]
		else:
			if CH3VkKb5LiB1cZUsoE and CH3VkKb5LiB1cZUsoE!='..':
				TduJNary5gQ = iKcqvCRx5rVto0uzBE3gd6[XMxZNTL8HbGD5pzVQ63sY72Wafom4]
				if peGKZ47miuytWS8X in TduJNary5gQ:
					OPsfkuwWCA = TduJNary5gQ.index(peGKZ47miuytWS8X)
					del TduJNary5gQ[OPsfkuwWCA]
				OPkSKmle07hW93GQVg1fbiaZnHR2LY = TduJNary5gQ+[peGKZ47miuytWS8X]
				m2ZuVhQTeP7UR9lxNHogK6[XMxZNTL8HbGD5pzVQ63sY72Wafom4] = OPkSKmle07hW93GQVg1fbiaZnHR2LY
			else: m2ZuVhQTeP7UR9lxNHogK6[XMxZNTL8HbGD5pzVQ63sY72Wafom4] = iKcqvCRx5rVto0uzBE3gd6[XMxZNTL8HbGD5pzVQ63sY72Wafom4]
	if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG not in list(m2ZuVhQTeP7UR9lxNHogK6.keys()): m2ZuVhQTeP7UR9lxNHogK6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG] = [peGKZ47miuytWS8X]
	IVrlSyDn16POXkBf2Mp = str(m2ZuVhQTeP7UR9lxNHogK6)
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: IVrlSyDn16POXkBf2Mp = IVrlSyDn16POXkBf2Mp.encode('utf8')
	open(YbTWJNjEGPC12RZzHioatgvu,'wb').write(IVrlSyDn16POXkBf2Mp)
	return
def H5c7v4sChNdljp(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
	peGKZ47miuytWS8X = jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,'',AFbdWemQRHznuiv60
	iKcqvCRx5rVto0uzBE3gd6 = k4tn3CNwPDRBoIpzY2gT()
	if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()) and peGKZ47miuytWS8X in iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]:
		iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG].remove(peGKZ47miuytWS8X)
		if len(iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG])==0: del iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]
		IVrlSyDn16POXkBf2Mp = str(iKcqvCRx5rVto0uzBE3gd6)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: IVrlSyDn16POXkBf2Mp = IVrlSyDn16POXkBf2Mp.encode('utf8')
		open(YbTWJNjEGPC12RZzHioatgvu,'wb').write(IVrlSyDn16POXkBf2Mp)
	return
def wBWDNuta1Q5YqV4cUZgGdH(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,A5Io8x3M01,BNEJOK7nUplx0GwkCToRiP9aj35Q):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
	peGKZ47miuytWS8X = jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,'',AFbdWemQRHznuiv60
	iKcqvCRx5rVto0uzBE3gd6 = k4tn3CNwPDRBoIpzY2gT()
	if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
		TduJNary5gQ = iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]
		if peGKZ47miuytWS8X not in TduJNary5gQ: return
		ffIg3vtxK2zjs6mZbBupoeQYGTPVL = len(TduJNary5gQ)
		for N6N8FlJCqco7hg in range(0,BNEJOK7nUplx0GwkCToRiP9aj35Q):
			TM1XIDBiQ8KxbCva6FJ329n = TduJNary5gQ.index(peGKZ47miuytWS8X)
			if A5Io8x3M01: WWzrPQuZB7UVy2 = TM1XIDBiQ8KxbCva6FJ329n-1
			else: WWzrPQuZB7UVy2 = TM1XIDBiQ8KxbCva6FJ329n+1
			if WWzrPQuZB7UVy2>=ffIg3vtxK2zjs6mZbBupoeQYGTPVL: WWzrPQuZB7UVy2 = WWzrPQuZB7UVy2-ffIg3vtxK2zjs6mZbBupoeQYGTPVL
			if WWzrPQuZB7UVy2<0: WWzrPQuZB7UVy2 = WWzrPQuZB7UVy2+ffIg3vtxK2zjs6mZbBupoeQYGTPVL
			TduJNary5gQ.insert(WWzrPQuZB7UVy2, TduJNary5gQ.pop(TM1XIDBiQ8KxbCva6FJ329n))
		iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG] = TduJNary5gQ
		IVrlSyDn16POXkBf2Mp = str(iKcqvCRx5rVto0uzBE3gd6)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: IVrlSyDn16POXkBf2Mp = IVrlSyDn16POXkBf2Mp.encode('utf8')
		open(YbTWJNjEGPC12RZzHioatgvu,'wb').write(IVrlSyDn16POXkBf2Mp)
	return
def CZUkjK8GlM(aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG):
	yka0pczgxUV = nEYJ5OCXG0gcNy('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+' ؟!')
	if yka0pczgxUV!=1: return
	iKcqvCRx5rVto0uzBE3gd6 = k4tn3CNwPDRBoIpzY2gT()
	if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
		del iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]
		IVrlSyDn16POXkBf2Mp = str(iKcqvCRx5rVto0uzBE3gd6)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: IVrlSyDn16POXkBf2Mp = IVrlSyDn16POXkBf2Mp.encode('utf8')
		open(YbTWJNjEGPC12RZzHioatgvu,'wb').write(IVrlSyDn16POXkBf2Mp)
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG)
	return
def k4tn3CNwPDRBoIpzY2gT():
	iKcqvCRx5rVto0uzBE3gd6 = {}
	if Dh9MOxeTj6FW.path.exists(YbTWJNjEGPC12RZzHioatgvu):
		PcWjqS2nRl5CEMx1ah6kud = open(YbTWJNjEGPC12RZzHioatgvu,'rb').read()
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: PcWjqS2nRl5CEMx1ah6kud = PcWjqS2nRl5CEMx1ah6kud.decode('utf8')
		iKcqvCRx5rVto0uzBE3gd6 = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',PcWjqS2nRl5CEMx1ah6kud)
	return iKcqvCRx5rVto0uzBE3gd6
def gLaEjQd2H6NtxW8DB37YivFTAe(iKcqvCRx5rVto0uzBE3gd6,peGKZ47miuytWS8X,fUzyxJ4WEIPoFSNtws20):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = peGKZ47miuytWS8X
	if not lOH3hXsnQiFCRjbN12: jPqMvmNDgsYiWUyxo,lOH3hXsnQiFCRjbN12 = 'folder','260'
	mJjfXCF8ZNuLwH,aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG = [],''
	if 'context=' in StrQOzK40pE8Dbgdj95U:
		jxpt0CM3kdaPNmK2U5nD4OibeoES = SomeI8i56FaDMGPE.findall('context=(\d+)',StrQOzK40pE8Dbgdj95U,SomeI8i56FaDMGPE.DOTALL)
		if jxpt0CM3kdaPNmK2U5nD4OibeoES: aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG = str(jxpt0CM3kdaPNmK2U5nD4OibeoES[0])
	if lOH3hXsnQiFCRjbN12=='270':
		aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG = lsfFwOE5rvtgxQCBo14VU
		if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
			mJjfXCF8ZNuLwH.append(('مسح قائمة مفضلة '+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,'RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_DELETELIST'+')'))
	else:
		if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()):
			count = len(iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG])
			if count>1: mJjfXCF8ZNuLwH.append(('تحريك 1 للأعلى','RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_UP1)'))
			if count>4: mJjfXCF8ZNuLwH.append(('تحريك 4 للأعلى','RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_UP4)'))
			if count>1: mJjfXCF8ZNuLwH.append(('تحريك 1 للأسفل','RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_DOWN1)'))
			if count>4: mJjfXCF8ZNuLwH.append(('تحريك 4 للأسفل','RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_DOWN4)'))
		for aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in ['1','2','3','4','5']:
			if aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG in list(iKcqvCRx5rVto0uzBE3gd6.keys()) and peGKZ47miuytWS8X in iKcqvCRx5rVto0uzBE3gd6[aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG]:
				mJjfXCF8ZNuLwH.append(('مسح من مفضلة '+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,'RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_REMOVE1)'))
			else: mJjfXCF8ZNuLwH.append(('إضافة إلى مفضلة '+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG,'RunPlugin('+fUzyxJ4WEIPoFSNtws20+'&context='+aIA6fwtY2e9kMX3xizgRlOBKPcZ5WG+'_ADD1)'))
	kXbSMNtUTPyBl = []
	for dpWxvThYfrSD6HnP4EeBcG0XIy,lyucBEaIHg6DbXS in mJjfXCF8ZNuLwH:
		dpWxvThYfrSD6HnP4EeBcG0XIy = '[COLOR FFFFFF00]'+dpWxvThYfrSD6HnP4EeBcG0XIy+'[/COLOR]'
		kXbSMNtUTPyBl.append((dpWxvThYfrSD6HnP4EeBcG0XIy,lyucBEaIHg6DbXS,))
	return kXbSMNtUTPyBl
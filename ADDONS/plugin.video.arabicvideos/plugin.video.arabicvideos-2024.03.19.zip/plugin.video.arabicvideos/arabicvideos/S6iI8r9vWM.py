# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'EGYBESTVIP'
ToYWiIbruzUaNKRPZLG16cAj = '_EGV_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==220: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==221: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==222: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==223: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==224: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url)
	elif mode==229: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','EGYBEST-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="i i-home"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,222)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="ba(.*?)<script',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R in items:
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,221)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if 'html' not in ZcAK0askvzIWr4R: continue
			if not ZcAK0askvzIWr4R.endswith('/'): UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,221)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="rs_scroll"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,224)
	return
def gj2tQTVYG87dUpsMXPqrv(url):
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',url,221)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="sub_nav(.*?)id="movies',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".+?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if ZcAK0askvzIWr4R=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,221)
	else: KKlnDcetq8Rrp3GY0(url)
	return
def KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2='1'):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	if '/search' in url or '?' in url: vfIB6ib8q1hFX5GweRrVPNTjY2E = url + '&'
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url + '?'
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E + 'page=' + SSGEc76fBan2
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('class="pda"(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[-1]
	elif '/series/' in url:
		pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('class="owl-carousel owl-carousel(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	else:
		pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('id="movies(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[-1]
	items = SomeI8i56FaDMGPE.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		title = dCFP41Kxv9j8EHM(title)
		if '/movie/' in ZcAK0askvzIWr4R or '/episode' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R.rstrip('/'),223,pjMZ802XQCSxYVk)
		else:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,221,pjMZ802XQCSxYVk)
	if len(items)>=16:
		f28ZDrhlucqSQPnv9mM5gVaKO = ['/movies','/tv','/search','/trending']
		SSGEc76fBan2 = int(SSGEc76fBan2)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in url for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in f28ZDrhlucqSQPnv9mM5gVaKO):
			for QzNPCsy3UwX in range(0,1000,100):
				if int(SSGEc76fBan2/100)*100==QzNPCsy3UwX:
					for zz5ZOaoyATpS893tvdXE in range(QzNPCsy3UwX,QzNPCsy3UwX+100,10):
						if int(SSGEc76fBan2/10)*10==zz5ZOaoyATpS893tvdXE:
							for Ir0PyLMiXbTqmhuvj in range(zz5ZOaoyATpS893tvdXE,zz5ZOaoyATpS893tvdXE+10,1):
								if not SSGEc76fBan2==Ir0PyLMiXbTqmhuvj and Ir0PyLMiXbTqmhuvj!=0:
									UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+str(Ir0PyLMiXbTqmhuvj),url,221,'',str(Ir0PyLMiXbTqmhuvj))
						elif zz5ZOaoyATpS893tvdXE!=0: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+str(zz5ZOaoyATpS893tvdXE),url,221,'',str(zz5ZOaoyATpS893tvdXE))
						else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+str(1),url,221,'',str(1))
				elif QzNPCsy3UwX!=0: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+str(QzNPCsy3UwX),url,221,'',str(QzNPCsy3UwX))
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+str(1),url,221)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = [],[]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','','','EGYBESTVIP-PLAY-1st')
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('<td>التصنيف</td>.*?">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	TbYW7z8kxgVln,o9EhkpbY08dez3t = '',''
	ERtKiSZhrv4PnpfzDC,mOG4ihxYjVoDlPUe7C9N = BsJ71WIxDtdFKveTcRPrqM4Cwb,BsJ71WIxDtdFKveTcRPrqM4Cwb
	zJlSmFhCUN0Q62Y8PnE = SomeI8i56FaDMGPE.findall('show_dl api" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if zJlSmFhCUN0Q62Y8PnE:
		for ZcAK0askvzIWr4R in zJlSmFhCUN0Q62Y8PnE:
			if '/watch/' in ZcAK0askvzIWr4R: TbYW7z8kxgVln = ZcAK0askvzIWr4R
			elif '/download/' in ZcAK0askvzIWr4R: o9EhkpbY08dez3t = ZcAK0askvzIWr4R
		if TbYW7z8kxgVln!='': ERtKiSZhrv4PnpfzDC = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,TbYW7z8kxgVln,'','','','EGYBESTVIP-PLAY-2nd')
		if o9EhkpbY08dez3t!='': mOG4ihxYjVoDlPUe7C9N = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,o9EhkpbY08dez3t,'','','','EGYBESTVIP-PLAY-3rd')
	CCyYMmBl9hOFj = SomeI8i56FaDMGPE.findall('id="video".*?data-src="(.*?)"',ERtKiSZhrv4PnpfzDC,SomeI8i56FaDMGPE.DOTALL)
	if CCyYMmBl9hOFj:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = CCyYMmBl9hOFj[0]
		if vfIB6ib8q1hFX5GweRrVPNTjY2E!='' and 'uploaded.egybest.download' in vfIB6ib8q1hFX5GweRrVPNTjY2E and '/?id=_' not in vfIB6ib8q1hFX5GweRrVPNTjY2E:
			ppq6Bg4vPbVs = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','EGYBESTVIP-PLAY-4th')
			B3rwjyhE8n = SomeI8i56FaDMGPE.findall('source src="(.*?)" title="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if B3rwjyhE8n:
				for ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz in B3rwjyhE8n:
					aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R+'?named=ed.egybest.do__watch__mp4__'+AfejZJoKh4D7k5G1P9gCwxTz)
			else:
				FglT5H2faVGm6IqpcXS9vQsojPLu = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('/')[2]
				aFyREdMQk7Ys95rX6uJieDGLS2.append(vfIB6ib8q1hFX5GweRrVPNTjY2E+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__watch')
		elif vfIB6ib8q1hFX5GweRrVPNTjY2E!='':
			FglT5H2faVGm6IqpcXS9vQsojPLu = vfIB6ib8q1hFX5GweRrVPNTjY2E.split('/')[2]
			aFyREdMQk7Ys95rX6uJieDGLS2.append(vfIB6ib8q1hFX5GweRrVPNTjY2E+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__watch')
	rMDG62nwjHfFPsl0TQOaB = SomeI8i56FaDMGPE.findall('<table class="dls_table(.*?)</table>',mOG4ihxYjVoDlPUe7C9N,SomeI8i56FaDMGPE.DOTALL)
	if rMDG62nwjHfFPsl0TQOaB:
		rMDG62nwjHfFPsl0TQOaB = rMDG62nwjHfFPsl0TQOaB[0]
		zzXtRY84pqaPDyMEo = SomeI8i56FaDMGPE.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',rMDG62nwjHfFPsl0TQOaB,SomeI8i56FaDMGPE.DOTALL)
		if zzXtRY84pqaPDyMEo:
			for AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R in zzXtRY84pqaPDyMEo:
				if 'myegyvip' not in ZcAK0askvzIWr4R: continue
				if ZcAK0askvzIWr4R.count('/')>=2:
					FglT5H2faVGm6IqpcXS9vQsojPLu = ZcAK0askvzIWr4R.split('/')[2]
					aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__download__mp4__'+AfejZJoKh4D7k5G1P9gCwxTz)
	lzqkARwVGHcsx8gN = []
	for ZcAK0askvzIWr4R in aFyREdMQk7Ys95rX6uJieDGLS2:
		lzqkARwVGHcsx8gN.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(lzqkARwVGHcsx8gN,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,aaeRjxiYcqOI6Sf8,'','','','EGYBESTVIP-SEARCH-1st')
	ii1SRMJ8xhIz5yl0Xptb9a = SomeI8i56FaDMGPE.findall('name="_token" value="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ii1SRMJ8xhIz5yl0Xptb9a:
		url = aaeRjxiYcqOI6Sf8+'/search?_token='+ii1SRMJ8xhIz5yl0Xptb9a[0]+'&q='+u9DhgpinLBfmjG3NtMalq7Y
		KKlnDcetq8Rrp3GY0(url)
	return
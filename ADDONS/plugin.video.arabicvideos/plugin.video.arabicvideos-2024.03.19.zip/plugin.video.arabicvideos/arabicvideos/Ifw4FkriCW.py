﻿# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
def GI13aCFr0qimdOT(lOH3hXsnQiFCRjbN12,cXoHAYqnCgy):
	if cXoHAYqnCgy=='': return
	if lOH3hXsnQiFCRjbN12==1:
		qZPNitrGH9vfCnI = N7zpvB3VIPrwcSDEC.getCurrentWindowDialogId()
		c0kROfKEr31wMSNCo2HPZIsGpgqF = N7zpvB3VIPrwcSDEC.Window(qZPNitrGH9vfCnI)
		cXoHAYqnCgy = s8sONHML19B5oh(cXoHAYqnCgy)
		c0kROfKEr31wMSNCo2HPZIsGpgqF.getControl(311).setLabel(cXoHAYqnCgy)
	if lOH3hXsnQiFCRjbN12==0:
		DQs7pSx58I4n='X'
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: wbPUYdfmF6yus7HQJI0 = isinstance(cXoHAYqnCgy,str)
		else: wbPUYdfmF6yus7HQJI0 = isinstance(cXoHAYqnCgy,unicode)
		if wbPUYdfmF6yus7HQJI0==True: DQs7pSx58I4n='U'
		XZETzRJtmF7V28Qp0vjh9iu3lYWkOy=str(type(cXoHAYqnCgy))+' '+cXoHAYqnCgy+' '+DQs7pSx58I4n+' '
		for zz5ZOaoyATpS893tvdXE in range(0,len(cXoHAYqnCgy),1):
			XZETzRJtmF7V28Qp0vjh9iu3lYWkOy += hex(ord(cXoHAYqnCgy[zz5ZOaoyATpS893tvdXE])).replace('0x','')+' '
		cXoHAYqnCgy = s8sONHML19B5oh(cXoHAYqnCgy)
		DQs7pSx58I4n='X'
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: wbPUYdfmF6yus7HQJI0 = isinstance(cXoHAYqnCgy, str)
		else: wbPUYdfmF6yus7HQJI0 = isinstance(cXoHAYqnCgy, unicode)
		if wbPUYdfmF6yus7HQJI0==True: DQs7pSx58I4n='U'
		iqDKp6zUbMx=str(type(cXoHAYqnCgy))+' '+cXoHAYqnCgy+' '+DQs7pSx58I4n+' '
		for zz5ZOaoyATpS893tvdXE in range(0,len(cXoHAYqnCgy),1):
			iqDKp6zUbMx += hex(ord(cXoHAYqnCgy[zz5ZOaoyATpS893tvdXE])).replace('0x','')+' '
	return
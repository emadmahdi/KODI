# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
headers = { 'User-Agent' : '' }
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'AKWAM'
ToYWiIbruzUaNKRPZLG16cAj = '_AKW_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
abVgjMZSrNn5Yp9B = ''
C1pRb6K8Qs = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==240: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==241: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==242: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==243: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==244: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FILTERS___'+text)
	elif mode==245: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'CATEGORIES___'+text)
	elif mode==246: rr60PDpqbMehZsYVuHmiAtN = d1khRjeU3XYs5IT069Kb(url)
	elif mode==247: rr60PDpqbMehZsYVuHmiAtN = f3vj2GuqF4A1NhKO(url)
	elif mode==248: rr60PDpqbMehZsYVuHmiAtN = sjCa6miU7E()
	elif mode==249: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def sjCa6miU7E():
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'',headers,'','','AKWAM-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	nGf7m0OgSwFkUtWBx16DNaHYE = SomeI8i56FaDMGPE.findall('home-site-btn-container.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if nGf7m0OgSwFkUtWBx16DNaHYE: nGf7m0OgSwFkUtWBx16DNaHYE = nGf7m0OgSwFkUtWBx16DNaHYE[0]
	else: nGf7m0OgSwFkUtWBx16DNaHYE = aaeRjxiYcqOI6Sf8
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',nGf7m0OgSwFkUtWBx16DNaHYE,'',headers,'','','AKWAM-MENU-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',aaeRjxiYcqOI6Sf8,246)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',aaeRjxiYcqOI6Sf8,247)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',nGf7m0OgSwFkUtWBx16DNaHYE,241,'','','featured')
	recent = SomeI8i56FaDMGPE.findall('recently-container.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	ZcAK0askvzIWr4R = recent[0]
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أضيف حديثا',ZcAK0askvzIWr4R,241)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,name,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
		if name in C1pRb6K8Qs: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+name,ZcAK0askvzIWr4R,241)
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title in C1pRb6K8Qs: continue
			title = name+' '+title
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,241)
	return
def d1khRjeU3XYs5IT069Kb(website=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','AKWAM-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu(.*?)<nav',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?text">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs:
				title = title+' مصنفة'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,245)
		if website=='': UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def f3vj2GuqF4A1NhKO(website=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','AKWAM-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu(.*?)<nav',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?text">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title not in C1pRb6K8Qs:
				title = title+' مفلترة'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,244)
		if website=='': UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('swiper-container(.*?)swiper-button-prev',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	else: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="widget"(.*?)main-footer',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not items:
			items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
			if '/series/' in ZcAK0askvzIWr4R or '/shows/' in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,242,pjMZ802XQCSxYVk)
			elif '/movies/' in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,243,pjMZ802XQCSxYVk)
			elif '/games/' not in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,243,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,241)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','%20')
	url = aaeRjxiYcqOI6Sf8 + '/search?q='+u9DhgpinLBfmjG3NtMalq7Y
	rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	return
def ooLCwrlF3n0vBjpA(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Icon')
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+'رابط التشغيل',url,243,pjMZ802XQCSxYVk)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('-episodes">(.*?)<div class="widget-4',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		gbRaTlfw5quES79COD2yPhJXzie6 = SomeI8i56FaDMGPE.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in gbRaTlfw5quES79COD2yPhJXzie6:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,242,pjMZ802XQCSxYVk)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,243,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,True,'AKWAM-PLAY-1st')
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('badge-danger.*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	Mcjk2V1hHFmRGrLyiCNZSu = SomeI8i56FaDMGPE.findall('li><a href="#(.*?)".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD,UUTVrGP7Y31a,F3gqfClBnSPcpZ06hEaev1ti5KUMV = [],[],[],[]
	if Mcjk2V1hHFmRGrLyiCNZSu:
		CxhvM0I7d3kcrD9aeTBESPG = 'mp4'
		for tPR1pvIJFDrYgVoqGXWixZL0SEb2MU,AfejZJoKh4D7k5G1P9gCwxTz in Mcjk2V1hHFmRGrLyiCNZSu:
			pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('tab-content quality" id="'+tPR1pvIJFDrYgVoqGXWixZL0SEb2MU+'".*?</div>.\s*</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			UUTVrGP7Y31a.append(L0Uwx52bTBM)
			F3gqfClBnSPcpZ06hEaev1ti5KUMV.append(AfejZJoKh4D7k5G1P9gCwxTz)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="qualities(.*?)<h3.*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			L0Uwx52bTBM,filename = pDTlIgyewF1XV69R8kd[0]
			qda6xUMKZRXEQOs5m1gzV0Y2tLNWk = ['zip','rar','txt','pdf','htm','tar','iso','html']
			CxhvM0I7d3kcrD9aeTBESPG = filename.rsplit('.',1)[1].strip(' ')
			if CxhvM0I7d3kcrD9aeTBESPG in qda6xUMKZRXEQOs5m1gzV0Y2tLNWk:
				ztgqWUaDpe8CE9N('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		UUTVrGP7Y31a.append(L0Uwx52bTBM)
		F3gqfClBnSPcpZ06hEaev1ti5KUMV.append('')
	for zz5ZOaoyATpS893tvdXE in range(len(UUTVrGP7Y31a)):
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('href="(.*?)".*?icon-(.*?)"',UUTVrGP7Y31a[zz5ZOaoyATpS893tvdXE],SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,DDJvVyR9e4M6ExKUCOuNrLiFjIntd5 in ZZHhmdtY1g:
			if 'torrent' in DDJvVyR9e4M6ExKUCOuNrLiFjIntd5: continue
			elif 'download' in DDJvVyR9e4M6ExKUCOuNrLiFjIntd5: type = 'download'
			elif 'play' in DDJvVyR9e4M6ExKUCOuNrLiFjIntd5: type = 'watch'
			else: type = 'unknown'
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named=__'+type+'____'+F3gqfClBnSPcpZ06hEaev1ti5KUMV[zz5ZOaoyATpS893tvdXE]+'__akwam'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	tE62imyGZoBe = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='CATEGORIES':
		if tE62imyGZoBe[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[0]
		for zz5ZOaoyATpS893tvdXE in range(len(tE62imyGZoBe[0:-1])):
			if tE62imyGZoBe[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FILTERS':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها',vfIB6ib8q1hFX5GweRrVPNTjY2E,241,'','1')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',vfIB6ib8q1hFX5GweRrVPNTjY2E,241,'','1')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<form id(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	dict = {}
	for mjcA3DUe9IJV4bk,name,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		items = SomeI8i56FaDMGPE.findall('<option(.*?)>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='CATEGORIES':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<=1:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'CATEGORIES___'+ecMSxgw2QqpvI)
				return
			else:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,241,'','1')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,245,'','',ecMSxgw2QqpvI)
		elif type=='FILTERS':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع : '+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,244,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			if 'value' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = irE1qv3BUYZMo5
			else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = SomeI8i56FaDMGPE.findall('"(.*?)"',EPwT39HrS1tU6Ng8YBGpJADixzLV5C,SomeI8i56FaDMGPE.DOTALL)[0]
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' : '#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' : '+name
			if type=='FILTERS': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,244,'','',L6iYCRsI1U4ytrW)
			elif type=='CATEGORIES' and tE62imyGZoBe[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'all')
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,241,'','1')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,245,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	JR6bW8Bc7ig = ['section','category','rating','year','language','formats','quality']
	for key in JR6bW8Bc7ig:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	return y4rSdac1zC26FA9IZnuO7WRU
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'KATKOUTE'
ToYWiIbruzUaNKRPZLG16cAj = '_KTK_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['الصفحة الرئيسية','Sign in','الأقسام']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==670: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==671: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==672: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==673: rr60PDpqbMehZsYVuHmiAtN = Zk56uvyAOlmdBTpQhb4znHr0U9GI(url,text)
	elif mode==674: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==679: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','KATKOUTE-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',679,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"navslide-divider"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title in C1pRb6K8Qs: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,mode)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = aGvt7WqXMcuO(aaeRjxiYcqOI6Sf8+'/watch/browse.html')
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,674,pjMZ802XQCSxYVk)
	return
def aGvt7WqXMcuO(url):
	L8nS9WGlViQCEJxsfFj4RgM = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','KATKOUTE','CATEGORIES')
	if L8nS9WGlViQCEJxsfFj4RgM: return L8nS9WGlViQCEJxsfFj4RgM
	L8nS9WGlViQCEJxsfFj4RgM = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','KATKOUTE-CATEGORIES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"category-header"(.*?)<footer>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		L8nS9WGlViQCEJxsfFj4RgM = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if L8nS9WGlViQCEJxsfFj4RgM: F4QxJHhsMj(qQ4BC6vW5YOfo,'KATKOUTE','CATEGORIES',L8nS9WGlViQCEJxsfFj4RgM,IIbavC96MQ1nHq3Pjx)
	return L8nS9WGlViQCEJxsfFj4RgM
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOUTE-SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"caret"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		L0Uwx52bTBM = L0Uwx52bTBM.replace('"presentation"','</ul>')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = [('',L0Uwx52bTBM)]
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for L1AixJmzUDr8P,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if L1AixJmzUDr8P: L1AixJmzUDr8P = L1AixJmzUDr8P+': '
			for ZcAK0askvzIWr4R,title in items:
				title = L1AixJmzUDr8P+title
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,671)
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"pm-category-subcats"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if EFOPTCNHpGvMYuS:
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if len(items)<30:
			UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for ZcAK0askvzIWr4R,title in items:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,671)
	if not q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and not EFOPTCNHpGvMYuS: KKlnDcetq8Rrp3GY0(url)
	return
def KKlnDcetq8Rrp3GY0(url,ZuCJj5EwDPROkb7UXNypofl=''):
	if ZuCJj5EwDPROkb7UXNypofl=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,headers,'','','KATKOUTE-TITLES-1st')
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOUTE-TITLES-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	L0Uwx52bTBM,items = '',[]
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	if ZuCJj5EwDPROkb7UXNypofl=='ajax-search':
		L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
		BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR: items.append(('',ZcAK0askvzIWr4R,title))
	elif ZuCJj5EwDPROkb7UXNypofl=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pm-video-watch-featured"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif ZuCJj5EwDPROkb7UXNypofl=='new_episodes':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"row pm-ul-browse-videos(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif ZuCJj5EwDPROkb7UXNypofl=='new_movies':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"row pm-ul-browse-videos(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if len(pDTlIgyewF1XV69R8kd)>1: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[1]
	elif ZuCJj5EwDPROkb7UXNypofl=='featured_series':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in BAHbWtFdwNps9ZVUfvR: items.append(('',ZcAK0askvzIWr4R,title))
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(data-echo=".*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if L0Uwx52bTBM and not items: items = SomeI8i56FaDMGPE.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items: return
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|حلقة).\d+',title,SomeI8i56FaDMGPE.DOTALL)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,672,pjMZ802XQCSxYVk)
		elif ZuCJj5EwDPROkb7UXNypofl=='new_episodes':
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,672,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0][0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,673,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/movseries/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,671,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,673,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if ZcAK0askvzIWr4R=='#': continue
			if 'http' not in ZcAK0askvzIWr4R:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = url.rsplit('/',1)[0]
				ZcAK0askvzIWr4R = vfIB6ib8q1hFX5GweRrVPNTjY2E+'/'+ZcAK0askvzIWr4R.strip('/')
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,671,'','',ZuCJj5EwDPROkb7UXNypofl)
	return
def Zk56uvyAOlmdBTpQhb4znHr0U9GI(url,HHhXlVCJAa4gisn9mxZt16P):
	UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+'تشغيل الفيديو',url,672)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	L8nS9WGlViQCEJxsfFj4RgM = aGvt7WqXMcuO(aaeRjxiYcqOI6Sf8+'/watch/browse.html')
	ISjMuUsc6V8l0DQ3T1LNt7,QaIfnABTwW8y5kuX,gsVluN6Dnb7aUmEZYqQxWSXiJp4K = zip(*L8nS9WGlViQCEJxsfFj4RgM)
	FZg9zWCicEs6QxIyqV2fwTm0D = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOUTE-EPISODES-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"row pm-video-heading"(.*?)id="player"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in ZZHhmdtY1g:
			if ZcAK0askvzIWr4R not in ISjMuUsc6V8l0DQ3T1LNt7:
				MMeFJKLQG4HdIwObZ1l9 = (ZcAK0askvzIWr4R,title)
				FZg9zWCicEs6QxIyqV2fwTm0D.append(MMeFJKLQG4HdIwObZ1l9)
		if len(FZg9zWCicEs6QxIyqV2fwTm0D)==1:
			ZcAK0askvzIWr4R,title = FZg9zWCicEs6QxIyqV2fwTm0D[0]
			KKlnDcetq8Rrp3GY0(ZcAK0askvzIWr4R,'new_episodes')
			return
		else:
			for ZcAK0askvzIWr4R,title in FZg9zWCicEs6QxIyqV2fwTm0D:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,671,'','','new_episodes')
	if not FZg9zWCicEs6QxIyqV2fwTm0D: KKlnDcetq8Rrp3GY0(url,'new_episodes')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOUTE-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('sources:(.*?)flashplayer',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('file: "(.*?)".*?label: "(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz in ZZHhmdtY1g:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named=__watch__'+AfejZJoKh4D7k5G1P9gCwxTz
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('"embedded-video".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZZHhmdtY1g: ZZHhmdtY1g = SomeI8i56FaDMGPE.findall("file: '(.*?)'",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZZHhmdtY1g:
		ZcAK0askvzIWr4R = ZZHhmdtY1g[0]
		if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=__embed')
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/watch/search.php?keywords='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'EGYNOW'
ToYWiIbruzUaNKRPZLG16cAj = '_EGN_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==430: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==431: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==432: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==433: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==434: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==437: rr60PDpqbMehZsYVuHmiAtN = W8wKfQCh2IUvLkEMS6(url)
	elif mode==439: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8+'/films','','','','','EGYNOW-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('"canonical" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',BdSZn7YxiHaUcf1Rzt5o,435)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',BdSZn7YxiHaUcf1Rzt5o,434)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المضاف حديثا',BdSZn7YxiHaUcf1Rzt5o,431)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'افلام اون لاين',BdSZn7YxiHaUcf1Rzt5o+'/films1',436)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات اون لاين',BdSZn7YxiHaUcf1Rzt5o+'/series-all1',436)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'قائمة تفصيلية',BdSZn7YxiHaUcf1Rzt5o,437)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"SiteNavigation"(.*?)"Search"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,431)
	return
def W8wKfQCh2IUvLkEMS6(website=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('"canonical" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"ListDroped"(.*?)"SearchingMaster"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,EPwT39HrS1tU6Ng8YBGpJADixzLV5C,title in items:
		if title in C1pRb6K8Qs: continue
		ZcAK0askvzIWr4R = website+'/explore/?'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,431)
	return
def OJuEhdBtkzi5C8NfmGKgoAL0(url):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',url,431)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"titleSectionCon"(.*?)</div></div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('data-key="(.*?)".*?<em>(.*?)</em>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for YGBW78utSU1gJ0pD,title in items:
		if title in C1pRb6K8Qs: continue
		vfIB6ib8q1hFX5GweRrVPNTjY2E = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+YGBW78utSU1gJ0pD
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,vfIB6ib8q1hFX5GweRrVPNTjY2E,431)
	return
def KKlnDcetq8Rrp3GY0(url,ZuCJj5EwDPROkb7UXNypofl=''):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
		mgDoj8ZAqe0uBLxP4Kzp = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','EGYNOW-TITLES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	elif ZuCJj5EwDPROkb7UXNypofl=='featured':
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"MainSlider"(.*?)"MatchesTable"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"BlocksList"(.*?)"Paginate"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"BlocksList"(.*?)"titleSectionCon"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	if not items: items = SomeI8i56FaDMGPE.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R).strip('/')
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,432,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and 'الحلقة' in title:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,433,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/movseries/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,431,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,433,pjMZ802XQCSxYVk)
	if ZuCJj5EwDPROkb7UXNypofl!='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"Paginate"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
				ZcAK0askvzIWr4R = dCFP41Kxv9j8EHM(ZcAK0askvzIWr4R)
				title = dCFP41Kxv9j8EHM(title)
				if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,431)
		Tted4clSYVMkhwFA1qg = SomeI8i56FaDMGPE.findall('showmore" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if Tted4clSYVMkhwFA1qg:
			ZcAK0askvzIWr4R = Tted4clSYVMkhwFA1qg[0]
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مشاهدة المزيد',ZcAK0askvzIWr4R,431)
	return
def ooLCwrlF3n0vBjpA(url):
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ,EFOPTCNHpGvMYuS = [],[]
	if 'Episodes.php' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
		mgDoj8ZAqe0uBLxP4Kzp = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',vfIB6ib8q1hFX5GweRrVPNTjY2E,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','EGYNOW-EPISODES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		EFOPTCNHpGvMYuS = [BsJ71WIxDtdFKveTcRPrqM4Cwb]
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"SeasonsList"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"EpisodesList"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ:
		pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"og:image" content="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		items = SomeI8i56FaDMGPE.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for QumF9ZVCakY4d1KSzqgDyT3EBoX,Cmkb7B9FsfhHNWdZTlwux,title in items:
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+Cmkb7B9FsfhHNWdZTlwux+'&post_id='+QumF9ZVCakY4d1KSzqgDyT3EBoX
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,433,pjMZ802XQCSxYVk)
	elif EFOPTCNHpGvMYuS:
		pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Thumb')
		L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,iHPhR4wCQ1oINaL in items:
			title = title+' '+iHPhR4wCQ1oINaL
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,432,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/watch/'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','EGYNOW-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(vfIB6ib8q1hFX5GweRrVPNTjY2E,'url')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"container-servers"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		OnjXh8rf1IgEsDvTJ20LycGA3bmP = SomeI8i56FaDMGPE.findall('data-id="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if OnjXh8rf1IgEsDvTJ20LycGA3bmP:
			OnjXh8rf1IgEsDvTJ20LycGA3bmP = OnjXh8rf1IgEsDvTJ20LycGA3bmP[0]
			items = SomeI8i56FaDMGPE.findall('data-server="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for FglT5H2faVGm6IqpcXS9vQsojPLu,title in items:
				ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+FglT5H2faVGm6IqpcXS9vQsojPLu+'&post_id='+OnjXh8rf1IgEsDvTJ20LycGA3bmP+'?named='+title+'__watch'
				aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	kBsYhecXD6R0MH = SomeI8i56FaDMGPE.findall('"container-iframe"><iframe src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if kBsYhecXD6R0MH:
		kBsYhecXD6R0MH = kBsYhecXD6R0MH[0].replace('\n','')
		title = DRom9hFTZXKuvfr2(kBsYhecXD6R0MH,'name')
		ZcAK0askvzIWr4R = kBsYhecXD6R0MH+'?named='+title+'__embed'
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"container-download"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,AfejZJoKh4D7k5G1P9gCwxTz in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\n','')
			if AfejZJoKh4D7k5G1P9gCwxTz!='': AfejZJoKh4D7k5G1P9gCwxTz = '____'+AfejZJoKh4D7k5G1P9gCwxTz
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'+AfejZJoKh4D7k5G1P9gCwxTz
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','%20')
	url = aaeRjxiYcqOI6Sf8+'/?s='+search
	KKlnDcetq8Rrp3GY0(url)
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	url = url.split('/smartemadfilter?')[0]
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',BdSZn7YxiHaUcf1Rzt5o,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('("dropdown-button".*?)"SearchingMaster"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('data-term="(\d+)" data-name="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def b5xIesmNZ73Ju4tKg1T(url):
	nnjrtO4FdM = url.split('/smartemadfilter?')[0]
	guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(url,'url')
	url = url.replace(nnjrtO4FdM,guUzYdHnWLVvGlQA)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def Lh5i1kngfHqyXpbevzNxQ24(GGw4ZcYsxyNT6BmQf1jEJKa7pR,url):
	rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = b5xIesmNZ73Ju4tKg1T(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
	return XuItmjBhoUDa3fRO9nQsbNYrpG1cdv
tE62imyGZoBe = ['category','country','genre','release-year']
JR6bW8Bc7ig = ['quality','release-year','genre','category','language','country']
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if tE62imyGZoBe[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[0]
		for zz5ZOaoyATpS893tvdXE in range(len(tE62imyGZoBe[0:-1])):
			if tE62imyGZoBe[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='ALL_ITEMS_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',vfIB6ib8q1hFX5GweRrVPNTjY2E,431)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',vfIB6ib8q1hFX5GweRrVPNTjY2E,431)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,L0Uwx52bTBM,mjcA3DUe9IJV4bk in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		name = name.replace('--','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='SPECIFIED_FILTER':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]:
					url = b5xIesmNZ73Ju4tKg1T(url)
					KKlnDcetq8Rrp3GY0(url)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'SPECIFIED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',vfIB6ib8q1hFX5GweRrVPNTjY2E,431)
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',vfIB6ib8q1hFX5GweRrVPNTjY2E,435,'','',ecMSxgw2QqpvI)
		elif type=='ALL_ITEMS_FILTER':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,434,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196533': irE1qv3BUYZMo5 = 'أفلام نيتفلكس'
			elif EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196531': irE1qv3BUYZMo5 = 'مسلسلات نيتفلكس'
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' :'#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' :'+name
			if type=='ALL_ITEMS_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,434,'','',L6iYCRsI1U4ytrW)
			elif type=='SPECIFIED_FILTER' and tE62imyGZoBe[-2]+'=' in HxWc8KBlSsT:
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = Lh5i1kngfHqyXpbevzNxQ24(GGw4ZcYsxyNT6BmQf1jEJKa7pR,url)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,431)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,435,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in JR6bW8Bc7ig:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all_filters': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
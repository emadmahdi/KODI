# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMA4U'
headers = {'User-Agent':''}
ToYWiIbruzUaNKRPZLG16cAj = '_C4U_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==420: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==421: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==422: rr60PDpqbMehZsYVuHmiAtN = Zo7UmLDVAaduH2IC9xTQbqcXjNh(url)
	elif mode==423: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==424: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==427: rr60PDpqbMehZsYVuHmiAtN = W8wKfQCh2IUvLkEMS6(url)
	elif mode==429: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMA4U-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',BdSZn7YxiHaUcf1Rzt5o,425)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',BdSZn7YxiHaUcf1Rzt5o,424)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الرئيسية',BdSZn7YxiHaUcf1Rzt5o,421)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('NavigationMenu(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="*(.*?)"*>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		if '/actors' in ZcAK0askvzIWr4R: title = 'أفلام النجوم'
		elif '/netflix' in ZcAK0askvzIWr4R: title = 'أفلام ومسلسلات نيتفلكس'
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,421)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'قائمة تفصيلية',BdSZn7YxiHaUcf1Rzt5o,427)
	return
def W8wKfQCh2IUvLkEMS6(website=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','CIMA4U-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('FilteringTitle(.*?)PageTitle',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,id,ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		if 'netflix-movies' in ZcAK0askvzIWr4R: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in ZcAK0askvzIWr4R: title = 'مسلسلات نيتفلكس'
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,421,'','',g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'|'+id)
	return
def KKlnDcetq8Rrp3GY0(url,YGBW78utSU1gJ0pD=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if not YGBW78utSU1gJ0pD or '|' in YGBW78utSU1gJ0pD:
		if '|' not in YGBW78utSU1gJ0pD: znfKP4MimLb3EIh0rejZU = ''
		else: znfKP4MimLb3EIh0rejZU = '/archive/'+YGBW78utSU1gJ0pD
		RFfh93jdt8ora = False
		if 'PinSlider' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',url,421,'','','featured')
			RFfh93jdt8ora = True
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('PageTitle(.*?)PageContent',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			K1KV5U7JFXNPsl4h0HBd = pDTlIgyewF1XV69R8kd[0]
			BAHbWtFdwNps9ZVUfvR = SomeI8i56FaDMGPE.findall('data-tab="(.*?)".*?<span>(.*?)<',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
			for s3BSNJCkFcuXwaP6ETft0VdG9yZq,U2iQmHMJzoNkjORTGY7c51vZ in BAHbWtFdwNps9ZVUfvR:
				spdYctk0fWD1Z = BdSZn7YxiHaUcf1Rzt5o+'/ajaxcenter/action/HomepageLoader/tab/'+s3BSNJCkFcuXwaP6ETft0VdG9yZq+znfKP4MimLb3EIh0rejZU+'/'
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,spdYctk0fWD1Z,421)
				RFfh93jdt8ora = True
		if RFfh93jdt8ora: UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if YGBW78utSU1gJ0pD=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('PinSlider(.*?)MultiFilter',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('PinSlider(.*?)PageTitle',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		else: L0Uwx52bTBM = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	elif '/filter/' in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('PageContent(.*?)class="*pagination"*',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif '/actors' in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('PageContent(.*?)class="*pagination"*',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('Cima4uBlocks(.*?)</li></ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		else: L0Uwx52bTBM = ''
	if not items: items = SomeI8i56FaDMGPE.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items: items = SomeI8i56FaDMGPE.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if not title: continue
		if '?news=' in ZcAK0askvzIWr4R: continue
		title = title.replace('مشاهدة ','')
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) حلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if iHPhR4wCQ1oINaL and 'حلقة' in title:
			title = '_MOD_' + iHPhR4wCQ1oINaL[0]
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,422,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif '/actor/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,421,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,422,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd and YGBW78utSU1gJ0pD!='featured':
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,421)
	Tted4clSYVMkhwFA1qg = SomeI8i56FaDMGPE.findall('</li><a href="(.*?)".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Tted4clSYVMkhwFA1qg:
		ZcAK0askvzIWr4R,title = Tted4clSYVMkhwFA1qg[0]
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,421)
	return
def Zo7UmLDVAaduH2IC9xTQbqcXjNh(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="WatchNow".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		url = pDTlIgyewF1XV69R8kd[0]
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('SeasonsSections(.*?)</div></div></div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if '/tag/' in url or '/actor' in url:
		KKlnDcetq8Rrp3GY0(url)
	elif pDTlIgyewF1XV69R8kd:
		pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Thumb')
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall("href='(.*?)'>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		juF0d8nZQWmbsRG = ['مسلسل','موسم','برنامج','حلقة']
		for ZcAK0askvzIWr4R,title in items:
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in juF0d8nZQWmbsRG):
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,423,pjMZ802XQCSxYVk)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,426,pjMZ802XQCSxYVk)
	else: ooLCwrlF3n0vBjpA(url)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"background-image:url\((.*?)\)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
	else: pjMZ802XQCSxYVk = ''
	W7fo8gXqeO = SomeI8i56FaDMGPE.findall('EpisodesSection(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if W7fo8gXqeO:
		L0Uwx52bTBM = W7fo8gXqeO[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title,iHPhR4wCQ1oINaL in items:
			title = title+' '+iHPhR4wCQ1oINaL
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,426,pjMZ802XQCSxYVk)
	else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+'رابط التشغيل',url,426,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	J0yHYmOT7a6D = ttpgqJBdkoxeKOcwaiP.url
	if BhTAck1bPFYGuUqRW: J0yHYmOT7a6D = J0yHYmOT7a6D.encode('utf8')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(J0yHYmOT7a6D,'url')
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('WatchSection(.*?)</div></div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('data-link="(.*?)".*? />(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for YcBS69pDzGFTlHE,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/structure/server.php?id='+YcBS69pDzGFTlHE+'?named='+title+'__watch'
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\r','')
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('DownloadServers(.*?)</div></div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*? />(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): U2iQmHMJzoNkjORTGY7c51vZ = '__خاص'
			else: U2iQmHMJzoNkjORTGY7c51vZ = ''
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'+U2iQmHMJzoNkjORTGY7c51vZ
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('\r','')
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/Search?q='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	if 'smartemadfilter' not in url: url = DRom9hFTZXKuvfr2(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('MultiFilter(.*?)PageTitle',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('data-id="(.*?)".*?</div>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def b5xIesmNZ73Ju4tKg1T(url):
	nnjrtO4FdM = url.split('/smartemadfilter?')[0]
	guUzYdHnWLVvGlQA = DRom9hFTZXKuvfr2(url,'url')
	url = url.replace(nnjrtO4FdM,guUzYdHnWLVvGlQA)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
tE62imyGZoBe = ['category','types','release-year']
JR6bW8Bc7ig = ['Quality','release-year','types','category']
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global tE62imyGZoBe
			tE62imyGZoBe = tE62imyGZoBe[1:]
		if tE62imyGZoBe[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[0]
		for zz5ZOaoyATpS893tvdXE in range(len(tE62imyGZoBe[0:-1])):
			if tE62imyGZoBe[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = tE62imyGZoBe[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='ALL_ITEMS_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO!='': efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'modified_filters')
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO=='': vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',vfIB6ib8q1hFX5GweRrVPNTjY2E,421,'','','filter')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',vfIB6ib8q1hFX5GweRrVPNTjY2E,421,'','','filter')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,L0Uwx52bTBM,mjcA3DUe9IJV4bk in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		if '/category/' in url and mjcA3DUe9IJV4bk=='category': continue
		name = name.replace('--','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='SPECIFIED_FILTER':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]:
					url = b5xIesmNZ73Ju4tKg1T(url)
					KKlnDcetq8Rrp3GY0(url)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'SPECIFIED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = b5xIesmNZ73Ju4tKg1T(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				if mjcA3DUe9IJV4bk==tE62imyGZoBe[-1]: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,421,'','','filter')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',vfIB6ib8q1hFX5GweRrVPNTjY2E,425,'','',ecMSxgw2QqpvI)
		elif type=='ALL_ITEMS_FILTER':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,424,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196533': irE1qv3BUYZMo5 = 'أفلام نيتفلكس'
			elif EPwT39HrS1tU6Ng8YBGpJADixzLV5C=='196531': irE1qv3BUYZMo5 = 'مسلسلات نيتفلكس'
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' :'#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' :'+name
			if type=='ALL_ITEMS_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,424,'','',L6iYCRsI1U4ytrW)
			elif type=='SPECIFIED_FILTER' and tE62imyGZoBe[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = b5xIesmNZ73Ju4tKg1T(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,421,'','','filter')
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,425,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in JR6bW8Bc7ig:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
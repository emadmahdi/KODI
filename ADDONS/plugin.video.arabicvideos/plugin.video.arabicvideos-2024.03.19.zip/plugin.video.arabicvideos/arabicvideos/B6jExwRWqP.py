# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'CIMAFANS'
headers = { 'User-Agent' : '' }
ToYWiIbruzUaNKRPZLG16cAj = '_CMF_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==90: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==91: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq(url)
	elif mode==92: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==94: rr60PDpqbMehZsYVuHmiAtN = DrWQf8PNSAwocLyKviszal()
	elif mode==95: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==99: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المضاف حديثا','',94)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الأحدث',aaeRjxiYcqOI6Sf8+'/?type=latest',91)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الأعلى تقيماً',aaeRjxiYcqOI6Sf8+'/?type=imdb',91)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الأكثر مشاهدة',aaeRjxiYcqOI6Sf8+'/?type=view',91)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المثبت',aaeRjxiYcqOI6Sf8+'/?type=pin',91)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'جديد الأفلام',aaeRjxiYcqOI6Sf8+'/?type=newMovies',91)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'جديد الحلقات',aaeRjxiYcqOI6Sf8+'/?type=newEpisodes',91)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','CIMAFANS-MENU-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="mainmenu(.*?)nav',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('<li><a href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	C1pRb6K8Qs = ['افلام للكبار فقط']
	for ZcAK0askvzIWr4R,title in items:
		title = title.strip(' ')
		if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,91)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def rum8gIeCX3hYq(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	else:
		headers = { 'User-Agent' : '' }
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="movies-items(.*?)class="listfoot"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	else: L0Uwx52bTBM = ''
	items = SomeI8i56FaDMGPE.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة [0-9]+',title,SomeI8i56FaDMGPE.DOTALL)
			if iHPhR4wCQ1oINaL:
				title = '_MOD_'+iHPhR4wCQ1oINaL[0]
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,95,pjMZ802XQCSxYVk)
					oojL40IJtK.append(title)
		elif '/video/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,92,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,91,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<a href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,91)
	return
def ooLCwrlF3n0vBjpA(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','CIMAFANS-EPISODES-1st')
	pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('img src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="episodes-panel(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		name = SomeI8i56FaDMGPE.findall('itemprop="title">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if name: name = name[1]
		else:
			name = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?name">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+name+' - '+title,ZcAK0askvzIWr4R,92,pjMZ802XQCSxYVk)
	else:
		T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('class="movietitle"><a href="(.*?)">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if T9PyERLBA8wiVN30QjU14mW: ZcAK0askvzIWr4R,title = T9PyERLBA8wiVN30QjU14mW[0]
		else: ZcAK0askvzIWr4R,title = url,name
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,92,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2,ZVP39ulQKcFEjq1MRvhGXbeAwWT = [],[]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','CIMAFANS-PLAY-1st')
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('text-shadow: none;">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="links-panel(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?__download'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('nav-tabs"(.*?)video-panel-more',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('id="(.*?)".*?embed src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,ZcAK0askvzIWr4R in items:
			title = 'سيرفر '+id
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
		items = SomeI8i56FaDMGPE.findall('data-server-src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in items:
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def DrWQf8PNSAwocLyKviszal():
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,aaeRjxiYcqOI6Sf8,'',headers,'','CIMAFANS-LATEST-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="index-last-movie(.*?)id="index-slider-movie',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		if '/video/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,92,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,91,pjMZ802XQCSxYVk)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + '/search.php?t='+search
	rum8gIeCX3hYq(url)
	return
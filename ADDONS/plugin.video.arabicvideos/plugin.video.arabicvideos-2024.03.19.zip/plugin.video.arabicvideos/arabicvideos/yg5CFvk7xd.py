# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'RANDOMS'
ToYWiIbruzUaNKRPZLG16cAj = '_LST_'
ffZSseDR2LUtmCunp = 4
ob0p5ZUyrE7YaOTG6 = 10
def GI13aCFr0qimdOT(lOH3hXsnQiFCRjbN12,url,yy42JUqszVIO89i,SSGEc76fBan2,MIe5q0WmGnJF9wp2tfk):
	try: ffFDzprmdb14nE6ekuILVM = str(MIe5q0WmGnJF9wp2tfk['folder'])
	except: ffFDzprmdb14nE6ekuILVM = ''
	if   lOH3hXsnQiFCRjbN12==160: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif lOH3hXsnQiFCRjbN12==161: rr60PDpqbMehZsYVuHmiAtN = UlDVPzrKRL9mQgBkdJhbcT7(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==162: rr60PDpqbMehZsYVuHmiAtN = mmCF2Z6XGhaAOH(yy42JUqszVIO89i,162)
	elif lOH3hXsnQiFCRjbN12==163: rr60PDpqbMehZsYVuHmiAtN = mmCF2Z6XGhaAOH(yy42JUqszVIO89i,163)
	elif lOH3hXsnQiFCRjbN12==164: rr60PDpqbMehZsYVuHmiAtN = TuOvIpqSNJiFgKl(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==165: rr60PDpqbMehZsYVuHmiAtN = ddCt5sOXRS2uZnTApb(url,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==166: rr60PDpqbMehZsYVuHmiAtN = nToCiVA9GH5t0bqgwOrcMy2(url,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==167: rr60PDpqbMehZsYVuHmiAtN = aaiQUEgHKXM3OJxLcmAW2Z84hzb(url,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==168: rr60PDpqbMehZsYVuHmiAtN = HH9vOCWwzA6(url,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==761: rr60PDpqbMehZsYVuHmiAtN = PZ1i5AVTqOXovK()
	elif lOH3hXsnQiFCRjbN12==762: rr60PDpqbMehZsYVuHmiAtN = YFIktlAXnTcvzZpDw()
	elif lOH3hXsnQiFCRjbN12==763: rr60PDpqbMehZsYVuHmiAtN = o10tFrlQePZIC6bgJxV4cW5MsfGS(ffFDzprmdb14nE6ekuILVM,yy42JUqszVIO89i,SSGEc76fBan2)
	elif lOH3hXsnQiFCRjbN12==764: rr60PDpqbMehZsYVuHmiAtN = tKuIam6928xpUsgroSJy(ffFDzprmdb14nE6ekuILVM,yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==765: rr60PDpqbMehZsYVuHmiAtN = su3CigYqAVaQZb86xtwpEn(ffFDzprmdb14nE6ekuILVM,yy42JUqszVIO89i)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def PZ1i5AVTqOXovK():
	UZ8LYnm5jsl9uKM0xDX('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
		ToYWiIbruzUaNKRPZLG16cAj = '_IP'+str(ffFDzprmdb14nE6ekuILVM)+'_'
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' فيديوهات مجلد '+h6OYx3P5fiRXg2LoBK8[ffFDzprmdb14nE6ekuILVM],'',764,'','','','',{'folder':ffFDzprmdb14nE6ekuILVM})
	return
def YFIktlAXnTcvzZpDw():
	UZ8LYnm5jsl9uKM0xDX('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
		ToYWiIbruzUaNKRPZLG16cAj = '_MU'+str(ffFDzprmdb14nE6ekuILVM)+'_'
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' فيديوهات مجلد '+h6OYx3P5fiRXg2LoBK8[ffFDzprmdb14nE6ekuILVM],'',765,'','','','',{'folder':ffFDzprmdb14nE6ekuILVM})
	return
def nTtYEKRXuUvGI8sh7AVHlz(yPRGDCnXhJbwYalz7fZepiUcA):
	global bjedCxR8lM3JLXv1y6g0K9suf,tsBliLPQcXF8
	Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd = YfxSMg0mF9ZkoBthUHs3Rz6CaeO(yPRGDCnXhJbwYalz7fZepiUcA)
	try:
		if 'IFILM' in yPRGDCnXhJbwYalz7fZepiUcA: Nmq7bQ4yEIoaCM1u32hArxPkp(yPRGDCnXhJbwYalz7fZepiUcA)
		else: Nmq7bQ4yEIoaCM1u32hArxPkp()
		fN9xYAUm7FDKLw0RWcyl = False
	except:
		xxEnCy9DI0()
		fN9xYAUm7FDKLw0RWcyl = True
	yPRGDCnXhJbwYalz7fZepiUcA = AFuJDPbZhS134etQfj(yPRGDCnXhJbwYalz7fZepiUcA)
	if fN9xYAUm7FDKLw0RWcyl:
		NCXj2ri3Unm6TFWIgwh(yPRGDCnXhJbwYalz7fZepiUcA,'فشل للأسف',p1BoraOuWL=2000)
		bjedCxR8lM3JLXv1y6g0K9suf += 1
		tsBliLPQcXF8 += ' '+yPRGDCnXhJbwYalz7fZepiUcA
	else: NCXj2ri3Unm6TFWIgwh(yPRGDCnXhJbwYalz7fZepiUcA,'',p1BoraOuWL=1000)
	return
def g1w9mY7ShpXKTGl0j4bVE(t1l9E0SmQDWGUcCfkhwXO=True):
	global bjedCxR8lM3JLXv1y6g0K9suf,tsBliLPQcXF8
	if not t1l9E0SmQDWGUcCfkhwXO:
		global w1wlgpYj6tbWLhxD
		rr60PDpqbMehZsYVuHmiAtN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if rr60PDpqbMehZsYVuHmiAtN:
			w1wlgpYj6tbWLhxD = rr60PDpqbMehZsYVuHmiAtN
			return
	svOyXbipkwY = nEYJ5OCXG0gcNy('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if svOyXbipkwY!=1: return
	PPEIqwl1Hk7nJKre(False,False,False)
	xAsR71JEaN436kveOolWVGpnB5jgt = nUTgq0SFfC9
	bjedCxR8lM3JLXv1y6g0K9suf,tsBliLPQcXF8,threads = 0,'',{}
	for yPRGDCnXhJbwYalz7fZepiUcA in IEisp6QDSzu1HfZTAGKM8Rle37V:
		p1BoraOuWL.sleep(0.5)
		threads[yPRGDCnXhJbwYalz7fZepiUcA] = RrCB5k9XV6hYNSlIKJ2.Thread(target=nTtYEKRXuUvGI8sh7AVHlz,args=(yPRGDCnXhJbwYalz7fZepiUcA,))
		threads[yPRGDCnXhJbwYalz7fZepiUcA].start()
		if bjedCxR8lM3JLXv1y6g0K9suf>=ob0p5ZUyrE7YaOTG6: break
	else:
		for yPRGDCnXhJbwYalz7fZepiUcA in list(threads.keys()):
			threads[yPRGDCnXhJbwYalz7fZepiUcA].join()
	nUTgq0SFfC9[:] = xAsR71JEaN436kveOolWVGpnB5jgt
	if bjedCxR8lM3JLXv1y6g0K9suf>=ob0p5ZUyrE7YaOTG6: ztgqWUaDpe8CE9N('','','رسالة من المبرمج','لديك مشكلة في '+str(bjedCxR8lM3JLXv1y6g0K9suf)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+tsBliLPQcXF8)
	else:
		F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS_SITES','SECTIONS_SITES_ALL',w1wlgpYj6tbWLhxD,bY2n5MtVA4cjpkFSxZ6K)
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	PPEIqwl1Hk7nJKre('','','')
	return
def punB46xs5Ftwja(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn):
	ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 = False
	zXqKjYcNgLoeRy = nUTgq0SFfC9
	nUTgq0SFfC9[:] = []
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 and '_CREATENEW_' not in TZKIYEDaF04ohvjrn:
		rr60PDpqbMehZsYVuHmiAtN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+ffFDzprmdb14nE6ekuILVM)
	elif '_LIVE_' not in TZKIYEDaF04ohvjrn or '_VOD_' not in TZKIYEDaF04ohvjrn:
		import xTnWLMwOlD
		QQONb7aR2M6L = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in TZKIYEDaF04ohvjrn:
			try: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_UNKNOWN_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـIPTV للفيديوهات',QQONb7aR2M6L)
			try: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_MOVIES_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـIPTV للفيديوهات',QQONb7aR2M6L)
			try: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_SERIES_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـIPTV للفيديوهات',QQONb7aR2M6L)
		if '_VOD_' not in TZKIYEDaF04ohvjrn:
			try: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'LIVE_UNKNOWN_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـIPTV للقنوات',QQONb7aR2M6L)
			try: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'LIVE_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـIPTV للقنوات',QQONb7aR2M6L)
		rr60PDpqbMehZsYVuHmiAtN = nUTgq0SFfC9
		if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS_IPTV','SECTIONS_IPTV_'+ffFDzprmdb14nE6ekuILVM,rr60PDpqbMehZsYVuHmiAtN,bY2n5MtVA4cjpkFSxZ6K)
	nUTgq0SFfC9[:] = zXqKjYcNgLoeRy
	return rr60PDpqbMehZsYVuHmiAtN
def EEgSXToLHxdFKpYf7k(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn):
	ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 = False
	zXqKjYcNgLoeRy = nUTgq0SFfC9
	nUTgq0SFfC9[:] = []
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 and '_CREATENEW_' not in TZKIYEDaF04ohvjrn:
		rr60PDpqbMehZsYVuHmiAtN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS_M3U','SECTIONS_M3U_'+ffFDzprmdb14nE6ekuILVM)
	elif '_LIVE_' not in TZKIYEDaF04ohvjrn or '_VOD_' not in TZKIYEDaF04ohvjrn:
		import oI5xiFN7h4
		QQONb7aR2M6L = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in TZKIYEDaF04ohvjrn:
			try: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_UNKNOWN_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـM3U للفيديوهات',QQONb7aR2M6L)
			try: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_MOVIES_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـM3U للفيديوهات',QQONb7aR2M6L)
			try: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'VOD_SERIES_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـM3U للفيديوهات',QQONb7aR2M6L)
		if '_VOD_' not in TZKIYEDaF04ohvjrn:
			try: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'LIVE_UNKNOWN_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـM3U للقنوات',QQONb7aR2M6L)
			try: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(ffFDzprmdb14nE6ekuILVM,'LIVE_GROUPED_SORTED','','',TZKIYEDaF04ohvjrn+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ztgqWUaDpe8CE9N('','','موقع ـM3U للقنوات',QQONb7aR2M6L)
		rr60PDpqbMehZsYVuHmiAtN = nUTgq0SFfC9
		if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_'+ffFDzprmdb14nE6ekuILVM,rr60PDpqbMehZsYVuHmiAtN,bY2n5MtVA4cjpkFSxZ6K)
	nUTgq0SFfC9[:] = zXqKjYcNgLoeRy
	return rr60PDpqbMehZsYVuHmiAtN
def o10tFrlQePZIC6bgJxV4cW5MsfGS(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn,S8qMyLW35F4s9CI):
	if '_CREATENEW_' in TZKIYEDaF04ohvjrn and S8qMyLW35F4s9CI=='': g1w9mY7ShpXKTGl0j4bVE(True)
	elif S8qMyLW35F4s9CI: g1w9mY7ShpXKTGl0j4bVE(False)
	oXkGFzfSePixnC = TZKIYEDaF04ohvjrn.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not S8qMyLW35F4s9CI:
		UZ8LYnm5jsl9uKM0xDX('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+oXkGFzfSePixnC,'',{'folder':ffFDzprmdb14nE6ekuILVM})
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	L8nS9WGlViQCEJxsfFj4RgM = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	iimPxRg0kGIyJ3MBzFEcv = ['افلام','movie','فيلم','فلم']
	LQXmcAxYahIOeJ1NdV0vw9PGBq7D = ['مسلسل','series']
	blXuoTgFvLP0MmwO7629cEBN = ['مسارح','مسرحيات']
	bPBwmpOAJIefnUq5D = ['برامج','show','تلفزيون','تليفزيون']
	vGLbZ2PHtcy3AXlS = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	nnjBJE4CsNPMHq1ze7lKYRcVUIpQy = ['رمضان']
	DrWQf8PNSAwocLyKviszal = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	puL82G3UIhSnJ1YvlZOt5QfjmB = ['سلاسل','سلسله']
	EykZgl25N94QFH63caMBriTzs = ['اغاني','موسيقى','كليب','حفل','music']
	zzOEJhrvf3j97QeMNTYp = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	VZ8nNuzXKGAFQOH2rpSwEM = ['الان','حالي','مثبت','رائج']
	ppCbPMDgerfJN3xYitU4 = ['ضحك','كوميدي']
	BsUftlTjhrGYZJiD5a61F2PEVq7IH = ['رياضه','كوره','مصارعه','شوت','رياضة']
	HFAitBpbyahXWuCUngPfVLIEsl3M = ['نيتفلكس','netflix','نيتفليكس']
	ncjCXhrxHANpLiaBQszeYG6mRwT2 = ['ممثلين','اشخاص','نجوم']
	AAtcZRiU7anLkDGsb5Bv9CIKEhW = ['بث حي','live','قناه','قنوات']
	mgNWEiD6rM = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	mmedLK2HysAawFrYG = ['19','20','21','22','23','24','25','26']
	if not S8qMyLW35F4s9CI:
		S8qMyLW35F4s9CI = 0
		for JX702pIKotVuefwQByRbkn in L8nS9WGlViQCEJxsfFj4RgM:
			S8qMyLW35F4s9CI += 1
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+JX702pIKotVuefwQByRbkn,'',763,'',str(S8qMyLW35F4s9CI),oXkGFzfSePixnC,'',{'folder':ffFDzprmdb14nE6ekuILVM})
	else:
		for CH3VkKb5LiB1cZUsoE in sorted(list(w1wlgpYj6tbWLhxD.keys())):
			Fc3PbKsrWIt150De4wYGqmay82X = CH3VkKb5LiB1cZUsoE.lower()
			g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = []
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in iimPxRg0kGIyJ3MBzFEcv): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(1)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in LQXmcAxYahIOeJ1NdV0vw9PGBq7D): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(2)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in blXuoTgFvLP0MmwO7629cEBN): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(3)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in bPBwmpOAJIefnUq5D): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(4)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in vGLbZ2PHtcy3AXlS): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(5)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in nnjBJE4CsNPMHq1ze7lKYRcVUIpQy): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(6)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in DrWQf8PNSAwocLyKviszal) and Fc3PbKsrWIt150De4wYGqmay82X not in ['اخرى']: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(7)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in puL82G3UIhSnJ1YvlZOt5QfjmB): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(8)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in EykZgl25N94QFH63caMBriTzs): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(9)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in zzOEJhrvf3j97QeMNTYp): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(10)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in VZ8nNuzXKGAFQOH2rpSwEM): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(11)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in ppCbPMDgerfJN3xYitU4): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(12)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in BsUftlTjhrGYZJiD5a61F2PEVq7IH): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(13)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in HFAitBpbyahXWuCUngPfVLIEsl3M): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(14)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in ncjCXhrxHANpLiaBQszeYG6mRwT2): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(15)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in AAtcZRiU7anLkDGsb5Bv9CIKEhW): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(16)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in mgNWEiD6rM): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(17)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in Fc3PbKsrWIt150De4wYGqmay82X for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in mmedLK2HysAawFrYG): g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B.append(18)
			if not g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = [19]
			for LqRjzmSOEUhB76o in g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B:
				if str(LqRjzmSOEUhB76o)==S8qMyLW35F4s9CI:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+CH3VkKb5LiB1cZUsoE,CH3VkKb5LiB1cZUsoE,166,'','',oXkGFzfSePixnC+'_REMEMBERRESULTS_')
	return
def tKuIam6928xpUsgroSJy(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn):
	ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 = False
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3:
		UZ8LYnm5jsl9uKM0xDX('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':ffFDzprmdb14nE6ekuILVM})
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	zXqKjYcNgLoeRy = nUTgq0SFfC9[:]
	import xTnWLMwOlD
	if ffFDzprmdb14nE6ekuILVM:
		if not xTnWLMwOlD.G05MeU6Hlrzh(ffFDzprmdb14nE6ekuILVM,True): return
		TQPwGvtMJX = punB46xs5Ftwja(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn)
		lzqkARwVGHcsx8gN = sorted(TQPwGvtMJX,reverse=False,key=lambda key: key[1].lower())
	else:
		if not xTnWLMwOlD.G05MeU6Hlrzh('',True): return
		if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 and '_CREATENEW_' not in TZKIYEDaF04ohvjrn:
			lzqkARwVGHcsx8gN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			W3X9627ZHFU1JbGxBpfhQk,lzqkARwVGHcsx8gN,TQPwGvtMJX = [],[],[]
			for PdWUFARswpIgf02qQxZz9oLXKeG in range(1,gx4WbX9yDPm6lk+1):
				lzqkARwVGHcsx8gN += punB46xs5Ftwja(str(PdWUFARswpIgf02qQxZz9oLXKeG),TZKIYEDaF04ohvjrn)
			for type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in lzqkARwVGHcsx8gN:
				if yy42JUqszVIO89i not in W3X9627ZHFU1JbGxBpfhQk:
					W3X9627ZHFU1JbGxBpfhQk.append(yy42JUqszVIO89i)
					ErksxGI8cCNAZh = type,CH3VkKb5LiB1cZUsoE,yy42JUqszVIO89i,165,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,TZKIYEDaF04ohvjrn,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk
					TQPwGvtMJX.append(ErksxGI8cCNAZh)
			lzqkARwVGHcsx8gN = sorted(TQPwGvtMJX,reverse=False,key=lambda key: key[1].lower())
			if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',lzqkARwVGHcsx8gN,bY2n5MtVA4cjpkFSxZ6K)
	nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+lzqkARwVGHcsx8gN
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin('Container.Refresh')
	return
def su3CigYqAVaQZb86xtwpEn(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn):
	ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 = False
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3:
		UZ8LYnm5jsl9uKM0xDX('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':ffFDzprmdb14nE6ekuILVM})
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	zXqKjYcNgLoeRy = nUTgq0SFfC9[:]
	import oI5xiFN7h4
	if ffFDzprmdb14nE6ekuILVM:
		if not oI5xiFN7h4.G05MeU6Hlrzh(ffFDzprmdb14nE6ekuILVM,True): return
		TQPwGvtMJX = EEgSXToLHxdFKpYf7k(ffFDzprmdb14nE6ekuILVM,TZKIYEDaF04ohvjrn)
		lzqkARwVGHcsx8gN = sorted(TQPwGvtMJX,reverse=False,key=lambda key: key[1].lower())
	else:
		if not oI5xiFN7h4.G05MeU6Hlrzh('',True): return
		if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 and '_CREATENEW_' not in TZKIYEDaF04ohvjrn:
			lzqkARwVGHcsx8gN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			W3X9627ZHFU1JbGxBpfhQk,lzqkARwVGHcsx8gN,TQPwGvtMJX = [],[],[]
			for PdWUFARswpIgf02qQxZz9oLXKeG in range(1,gx4WbX9yDPm6lk+1):
				lzqkARwVGHcsx8gN += EEgSXToLHxdFKpYf7k(str(PdWUFARswpIgf02qQxZz9oLXKeG),TZKIYEDaF04ohvjrn)
			for type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in lzqkARwVGHcsx8gN:
				if yy42JUqszVIO89i not in W3X9627ZHFU1JbGxBpfhQk:
					W3X9627ZHFU1JbGxBpfhQk.append(yy42JUqszVIO89i)
					ErksxGI8cCNAZh = type,CH3VkKb5LiB1cZUsoE,yy42JUqszVIO89i,165,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,TZKIYEDaF04ohvjrn,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk
					TQPwGvtMJX.append(ErksxGI8cCNAZh)
			lzqkARwVGHcsx8gN = sorted(TQPwGvtMJX,reverse=False,key=lambda key: key[1].lower())
			if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS_M3U','SECTIONS_M3U_ALL',lzqkARwVGHcsx8gN,bY2n5MtVA4cjpkFSxZ6K)
	nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+lzqkARwVGHcsx8gN
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin('Container.Refresh')
	return
def ddCt5sOXRS2uZnTApb(group,TZKIYEDaF04ohvjrn):
	ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3 = False
	rr60PDpqbMehZsYVuHmiAtN = []
	STHq203FWD = '_IPTV_' if 'IPTV' in TZKIYEDaF04ohvjrn else '_M3U_'
	if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: rr60PDpqbMehZsYVuHmiAtN = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS'+STHq203FWD[:-1],group)
	if not rr60PDpqbMehZsYVuHmiAtN:
		for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
			if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: rr60PDpqbMehZsYVuHmiAtN += yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','SECTIONS'+STHq203FWD[:-1],'SECTIONS'+STHq203FWD+str(ffFDzprmdb14nE6ekuILVM))
			elif STHq203FWD=='_IPTV_': rr60PDpqbMehZsYVuHmiAtN += punB46xs5Ftwja(str(ffFDzprmdb14nE6ekuILVM),'_CREATENEW_')
			elif STHq203FWD=='_M3U_': rr60PDpqbMehZsYVuHmiAtN += EEgSXToLHxdFKpYf7k(str(ffFDzprmdb14nE6ekuILVM),'_CREATENEW_')
		for type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in rr60PDpqbMehZsYVuHmiAtN:
			if yy42JUqszVIO89i==group: ZQJPushbmqFz(type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
		items,BAHbWtFdwNps9ZVUfvR = [],[]
		for type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in nUTgq0SFfC9:
			uZA1NeSrTv = type,CH3VkKb5LiB1cZUsoE[4:],url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,''
			if uZA1NeSrTv not in BAHbWtFdwNps9ZVUfvR:
				BAHbWtFdwNps9ZVUfvR.append(uZA1NeSrTv)
				MMeFJKLQG4HdIwObZ1l9 = type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk
				items.append(MMeFJKLQG4HdIwObZ1l9)
		rr60PDpqbMehZsYVuHmiAtN = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3: F4QxJHhsMj(qQ4BC6vW5YOfo,'SECTIONS'+STHq203FWD[:-1],group,rr60PDpqbMehZsYVuHmiAtN,bY2n5MtVA4cjpkFSxZ6K)
	if '_RANDOM_' in TZKIYEDaF04ohvjrn and len(rr60PDpqbMehZsYVuHmiAtN)>ffZSseDR2LUtmCunp:
		nUTgq0SFfC9[:] = []
		UZ8LYnm5jsl9uKM0xDX('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',STHq203FWD+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		UZ8LYnm5jsl9uKM0xDX('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',STHq203FWD+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		rr60PDpqbMehZsYVuHmiAtN = nUTgq0SFfC9+ttczT0JFy9xID3iLGMXoQm2hjB4.sample(rr60PDpqbMehZsYVuHmiAtN,ffZSseDR2LUtmCunp)
	nUTgq0SFfC9[:] = rr60PDpqbMehZsYVuHmiAtN
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin('Container.Refresh')
	return
def UlDVPzrKRL9mQgBkdJhbcT7(TZKIYEDaF04ohvjrn):
	UZ8LYnm5jsl9uKM0xDX('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EELuVI4p3hdaBv = nUTgq0SFfC9[:]
	nUTgq0SFfC9[:] = []
	import vpgnkoN7IH
	vpgnkoN7IH.rum8gIeCX3hYq('0',False)
	vpgnkoN7IH.rum8gIeCX3hYq('1',False)
	vpgnkoN7IH.rum8gIeCX3hYq('2',False)
	if '_RANDOM_' in TZKIYEDaF04ohvjrn:
		nUTgq0SFfC9[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
		if len(nUTgq0SFfC9)>ffZSseDR2LUtmCunp: nUTgq0SFfC9[:] = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(nUTgq0SFfC9,ffZSseDR2LUtmCunp)
	nUTgq0SFfC9[:] = EELuVI4p3hdaBv+nUTgq0SFfC9
	return
def TuOvIpqSNJiFgKl(TZKIYEDaF04ohvjrn):
	TZKIYEDaF04ohvjrn = TZKIYEDaF04ohvjrn.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = iOyTz1Jgbh25fW7NAdE(data)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(AlcR9Gvo3QZsLnpfjS,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="content"(.*?)class="clearfix"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	zU6LJHMZ3KoSBafwsQk,nwfxpu2eoZtKMjm93alcU86 = list(zip(*items))
	xUdroq2XV5kZjl7tcSEB8TWHOGAwm = []
	MvNzY2F3T7torR = [' ','"','`',',','.',':',';',"'",'-']
	d4dgzvahskcRinpGo706lSWMjA = nwfxpu2eoZtKMjm93alcU86+zU6LJHMZ3KoSBafwsQk
	for vtKAx8WqlrjSkNPy7nez150VpIc in d4dgzvahskcRinpGo706lSWMjA:
		if vtKAx8WqlrjSkNPy7nez150VpIc in nwfxpu2eoZtKMjm93alcU86: s0FtZwVYbGo59r = 2
		if vtKAx8WqlrjSkNPy7nez150VpIc in zU6LJHMZ3KoSBafwsQk: s0FtZwVYbGo59r = 4
		XXoheOtFBU6L1ulpIC = [zz5ZOaoyATpS893tvdXE in vtKAx8WqlrjSkNPy7nez150VpIc for zz5ZOaoyATpS893tvdXE in MvNzY2F3T7torR]
		if any(XXoheOtFBU6L1ulpIC):
			fMGn2cXPKw9SyUY = XXoheOtFBU6L1ulpIC.index(True)
			rCzkyNahR37mFq8nfiWg6V = MvNzY2F3T7torR[fMGn2cXPKw9SyUY]
			r3dktus1TNfx = ''
			if vtKAx8WqlrjSkNPy7nez150VpIc.count(rCzkyNahR37mFq8nfiWg6V)>1: kw9ACmXP87ZF10lGshzNIy,WiHIApEobU360DrOvCaNlPXxLyY,r3dktus1TNfx = vtKAx8WqlrjSkNPy7nez150VpIc.split(rCzkyNahR37mFq8nfiWg6V,2)
			else: kw9ACmXP87ZF10lGshzNIy,WiHIApEobU360DrOvCaNlPXxLyY = vtKAx8WqlrjSkNPy7nez150VpIc.split(rCzkyNahR37mFq8nfiWg6V,1)
			if len(kw9ACmXP87ZF10lGshzNIy)>s0FtZwVYbGo59r: xUdroq2XV5kZjl7tcSEB8TWHOGAwm.append(kw9ACmXP87ZF10lGshzNIy.lower())
			if len(WiHIApEobU360DrOvCaNlPXxLyY)>s0FtZwVYbGo59r: xUdroq2XV5kZjl7tcSEB8TWHOGAwm.append(WiHIApEobU360DrOvCaNlPXxLyY.lower())
			if len(r3dktus1TNfx)>s0FtZwVYbGo59r: xUdroq2XV5kZjl7tcSEB8TWHOGAwm.append(r3dktus1TNfx.lower())
		elif len(vtKAx8WqlrjSkNPy7nez150VpIc)>s0FtZwVYbGo59r: xUdroq2XV5kZjl7tcSEB8TWHOGAwm.append(vtKAx8WqlrjSkNPy7nez150VpIc.lower())
	for zz5ZOaoyATpS893tvdXE in range(9): ttczT0JFy9xID3iLGMXoQm2hjB4.shuffle(xUdroq2XV5kZjl7tcSEB8TWHOGAwm)
	if '_SITES_' in TZKIYEDaF04ohvjrn:
		oonRW5EsSZczqPkB8wA4 = VqCjboemktrAKgz
	elif '_IPTV_' in TZKIYEDaF04ohvjrn:
		oonRW5EsSZczqPkB8wA4 = ['IPTV']
		import xTnWLMwOlD
		if not xTnWLMwOlD.G05MeU6Hlrzh('',True): return
	elif '_M3U_' in TZKIYEDaF04ohvjrn:
		oonRW5EsSZczqPkB8wA4 = ['M3U']
		import oI5xiFN7h4
		if not oI5xiFN7h4.G05MeU6Hlrzh('',True): return
	count,F3kb0XHZDLixd = 0,0
	UZ8LYnm5jsl9uKM0xDX('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
	UZ8LYnm5jsl9uKM0xDX('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QdfYKmcorZJOFA1TtiSbHyLvaC = nUTgq0SFfC9[:]
	nUTgq0SFfC9[:] = []
	X8GDYWAmO6FlrR4x5vpzPIE = []
	for vtKAx8WqlrjSkNPy7nez150VpIc in xUdroq2XV5kZjl7tcSEB8TWHOGAwm:
		WiHIApEobU360DrOvCaNlPXxLyY = SomeI8i56FaDMGPE.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',vtKAx8WqlrjSkNPy7nez150VpIc,SomeI8i56FaDMGPE.DOTALL)
		if WiHIApEobU360DrOvCaNlPXxLyY: vtKAx8WqlrjSkNPy7nez150VpIc = vtKAx8WqlrjSkNPy7nez150VpIc.split(WiHIApEobU360DrOvCaNlPXxLyY[0],1)[0]
		U0U7CPkGoSDmaO138qwpNKFH = vtKAx8WqlrjSkNPy7nez150VpIc.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		U0U7CPkGoSDmaO138qwpNKFH = U0U7CPkGoSDmaO138qwpNKFH.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if U0U7CPkGoSDmaO138qwpNKFH: X8GDYWAmO6FlrR4x5vpzPIE.append(U0U7CPkGoSDmaO138qwpNKFH)
	CVnQy0hzlBsHPmUOgMji = []
	for jUSuZAztxy34TB5CIP2 in range(0,20):
		search = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(X8GDYWAmO6FlrR4x5vpzPIE,1)[0]
		if search in CVnQy0hzlBsHPmUOgMji: continue
		CVnQy0hzlBsHPmUOgMji.append(search)
		yPRGDCnXhJbwYalz7fZepiUcA = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(oonRW5EsSZczqPkB8wA4,1)[0]
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Random Video Search   site:'+str(yPRGDCnXhJbwYalz7fZepiUcA)+'  search:'+search)
		Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd = YfxSMg0mF9ZkoBthUHs3Rz6CaeO(yPRGDCnXhJbwYalz7fZepiUcA)
		RPSrjovJkFNiMEGOWIxUdu8lVp(search+'_NODIALOGS_')
		if len(nUTgq0SFfC9)>0: break
	search = search.replace('_MOD_','')
	QdfYKmcorZJOFA1TtiSbHyLvaC[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	nUTgq0SFfC9[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
	if len(nUTgq0SFfC9)>ffZSseDR2LUtmCunp: nUTgq0SFfC9[:] = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(nUTgq0SFfC9,ffZSseDR2LUtmCunp)
	nUTgq0SFfC9[:] = QdfYKmcorZJOFA1TtiSbHyLvaC+nUTgq0SFfC9
	return
def nToCiVA9GH5t0bqgwOrcMy2(BTyUH7naE48v20JjWh1uI3PsmZ,TZKIYEDaF04ohvjrn):
	BTyUH7naE48v20JjWh1uI3PsmZ = BTyUH7naE48v20JjWh1uI3PsmZ.replace('_MOD_','')
	TZKIYEDaF04ohvjrn = TZKIYEDaF04ohvjrn.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	g1w9mY7ShpXKTGl0j4bVE(False)
	if w1wlgpYj6tbWLhxD=={}: return
	if '_RANDOM_' in TZKIYEDaF04ohvjrn:
		UZ8LYnm5jsl9uKM0xDX('folder','[[COLOR FFC89008]'+BTyUH7naE48v20JjWh1uI3PsmZ+'[/COLOR] :القسم]',BTyUH7naE48v20JjWh1uI3PsmZ,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
		UZ8LYnm5jsl9uKM0xDX('folder','إعادة الطلب العشوائي من نفس القسم',BTyUH7naE48v20JjWh1uI3PsmZ,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(w1wlgpYj6tbWLhxD[BTyUH7naE48v20JjWh1uI3PsmZ].keys())):
		type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = w1wlgpYj6tbWLhxD[BTyUH7naE48v20JjWh1uI3PsmZ][website]
		if '_RANDOM_' in TZKIYEDaF04ohvjrn or len(w1wlgpYj6tbWLhxD[BTyUH7naE48v20JjWh1uI3PsmZ])==1:
			ZQJPushbmqFz(type,'',url,deBF2JXw4DVnTl,'',SSGEc76fBan2,yy42JUqszVIO89i,'','')
			nUTgq0SFfC9[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
			zXqKjYcNgLoeRy,lzqkARwVGHcsx8gN = nUTgq0SFfC9[:3],nUTgq0SFfC9[3:]
			for zz5ZOaoyATpS893tvdXE in range(9): ttczT0JFy9xID3iLGMXoQm2hjB4.shuffle(lzqkARwVGHcsx8gN)
			if '_RANDOM_' in TZKIYEDaF04ohvjrn: nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+lzqkARwVGHcsx8gN[:ffZSseDR2LUtmCunp]
			else: nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+lzqkARwVGHcsx8gN
		elif '_SITES_' in TZKIYEDaF04ohvjrn: UZ8LYnm5jsl9uKM0xDX('folder',website,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
	return
def mmCF2Z6XGhaAOH(TZKIYEDaF04ohvjrn,lOH3hXsnQiFCRjbN12):
	TZKIYEDaF04ohvjrn = TZKIYEDaF04ohvjrn.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	CH3VkKb5LiB1cZUsoE,oQyUGWk36va92YAj = '',[]
	UZ8LYnm5jsl9uKM0xDX('folder','[[COLOR FFC89008]'+CH3VkKb5LiB1cZUsoE+'[/COLOR] :القسم]','',lOH3hXsnQiFCRjbN12,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
	UZ8LYnm5jsl9uKM0xDX('folder','إعادة طلب قسم عشوائي','',lOH3hXsnQiFCRjbN12,'','','_FORGETRESULTS__REMEMBERRESULTS_'+TZKIYEDaF04ohvjrn)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	zXqKjYcNgLoeRy = nUTgq0SFfC9[:]
	nUTgq0SFfC9[:] = []
	rr60PDpqbMehZsYVuHmiAtN = []
	if '_SITES_' in TZKIYEDaF04ohvjrn:
		g1w9mY7ShpXKTGl0j4bVE(False)
		if w1wlgpYj6tbWLhxD=={}: return
		CT398UpMbnHI = list(w1wlgpYj6tbWLhxD.keys())
		BTyUH7naE48v20JjWh1uI3PsmZ = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(CT398UpMbnHI,1)[0]
		xUdroq2XV5kZjl7tcSEB8TWHOGAwm = list(w1wlgpYj6tbWLhxD[BTyUH7naE48v20JjWh1uI3PsmZ].keys())
		website = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(xUdroq2XV5kZjl7tcSEB8TWHOGAwm,1)[0]
		type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = w1wlgpYj6tbWLhxD[BTyUH7naE48v20JjWh1uI3PsmZ][website]
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Random Category   website: '+website+'   name: '+CH3VkKb5LiB1cZUsoE+'   url: '+url+'   mode: '+str(deBF2JXw4DVnTl))
	elif '_IPTV_' in TZKIYEDaF04ohvjrn:
		import xTnWLMwOlD
		if not xTnWLMwOlD.G05MeU6Hlrzh('',True): return
		for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
			rr60PDpqbMehZsYVuHmiAtN += punB46xs5Ftwja(str(ffFDzprmdb14nE6ekuILVM),TZKIYEDaF04ohvjrn)
		if not rr60PDpqbMehZsYVuHmiAtN: return
		type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(rr60PDpqbMehZsYVuHmiAtN,1)[0]
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Random Category   name: '+CH3VkKb5LiB1cZUsoE+'   url: '+url+'   mode: '+str(deBF2JXw4DVnTl))
	elif '_M3U_' in TZKIYEDaF04ohvjrn:
		import oI5xiFN7h4
		if not oI5xiFN7h4.G05MeU6Hlrzh('',True): return
		for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
			rr60PDpqbMehZsYVuHmiAtN += EEgSXToLHxdFKpYf7k(str(ffFDzprmdb14nE6ekuILVM),TZKIYEDaF04ohvjrn)
		if not rr60PDpqbMehZsYVuHmiAtN: return
		type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(rr60PDpqbMehZsYVuHmiAtN,1)[0]
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Random Category   name: '+CH3VkKb5LiB1cZUsoE+'   url: '+url+'   mode: '+str(deBF2JXw4DVnTl))
	zoIlGsHWaLkDVgZRS6AUcdqy2X0u = CH3VkKb5LiB1cZUsoE
	wfSqKp49tm = []
	for zz5ZOaoyATpS893tvdXE in range(0,10):
		if zz5ZOaoyATpS893tvdXE>0: xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Random Category   name: '+CH3VkKb5LiB1cZUsoE+'   url: '+url+'   mode: '+str(deBF2JXw4DVnTl))
		nUTgq0SFfC9[:] = []
		if deBF2JXw4DVnTl==234 and '__IPTVSeries__' in yy42JUqszVIO89i: deBF2JXw4DVnTl = 233
		if deBF2JXw4DVnTl==714 and '__M3USeries__' in yy42JUqszVIO89i: deBF2JXw4DVnTl = 713
		if deBF2JXw4DVnTl==144: deBF2JXw4DVnTl = 291
		fYZzomwSjkedXVcEvLDqKHMt9rFnN = ZQJPushbmqFz(type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
		if '_IPTV_' in TZKIYEDaF04ohvjrn and deBF2JXw4DVnTl==167: del nUTgq0SFfC9[:3]
		if '_M3U_' in TZKIYEDaF04ohvjrn and deBF2JXw4DVnTl==168: del nUTgq0SFfC9[:3]
		oQyUGWk36va92YAj[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
		if wfSqKp49tm and MMjrDyLdKhUb7V(u'حلقة') in str(oQyUGWk36va92YAj) or MMjrDyLdKhUb7V(u'حلقه') in str(oQyUGWk36va92YAj):
			CH3VkKb5LiB1cZUsoE = zoIlGsHWaLkDVgZRS6AUcdqy2X0u
			oQyUGWk36va92YAj[:] = wfSqKp49tm
			break
		zoIlGsHWaLkDVgZRS6AUcdqy2X0u = CH3VkKb5LiB1cZUsoE
		wfSqKp49tm = oQyUGWk36va92YAj
		if str(oQyUGWk36va92YAj).count('video')>0: break
		if str(oQyUGWk36va92YAj).count('live')>0: break
		if deBF2JXw4DVnTl==233: break
		if deBF2JXw4DVnTl==713: break
		if deBF2JXw4DVnTl==291: break
		if oQyUGWk36va92YAj: type,CH3VkKb5LiB1cZUsoE,url,deBF2JXw4DVnTl,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = ttczT0JFy9xID3iLGMXoQm2hjB4.sample(oQyUGWk36va92YAj,1)[0]
	if not CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = '....'
	elif CH3VkKb5LiB1cZUsoE.count('_')>1: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.split('_',2)[2]
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('UNKNOWN: ','')
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('_MOD_','')
	zXqKjYcNgLoeRy[0][1] = '[[COLOR FFC89008]'+CH3VkKb5LiB1cZUsoE+'[/COLOR] :القسم]'
	for zz5ZOaoyATpS893tvdXE in range(9): ttczT0JFy9xID3iLGMXoQm2hjB4.shuffle(oQyUGWk36va92YAj)
	if '_RANDOM_' in TZKIYEDaF04ohvjrn: nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+oQyUGWk36va92YAj[:ffZSseDR2LUtmCunp]
	else: nUTgq0SFfC9[:] = zXqKjYcNgLoeRy+oQyUGWk36va92YAj
	return
def aaiQUEgHKXM3OJxLcmAW2Z84hzb(denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp):
	ARin5sf9V4BldW2ukb7Qyp = ARin5sf9V4BldW2ukb7Qyp.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg = ARin5sf9V4BldW2ukb7Qyp
	if '__IPTVSeries__' in ARin5sf9V4BldW2ukb7Qyp:
		zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg = ARin5sf9V4BldW2ukb7Qyp.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in denEcub0mKtMHWl3C5pOZD6: type = ',VIDEOS: '
	elif 'LIVE' in denEcub0mKtMHWl3C5pOZD6: type = ',LIVE: '
	UZ8LYnm5jsl9uKM0xDX('folder','[[COLOR FFC89008]'+type+zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg+'[/COLOR] :القسم]',denEcub0mKtMHWl3C5pOZD6,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ARin5sf9V4BldW2ukb7Qyp)
	UZ8LYnm5jsl9uKM0xDX('folder','إعادة الطلب العشوائي من نفس القسم',denEcub0mKtMHWl3C5pOZD6,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ARin5sf9V4BldW2ukb7Qyp)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import xTnWLMwOlD
	for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
		if '__IPTVSeries__' in ARin5sf9V4BldW2ukb7Qyp: xTnWLMwOlD.KksoXzFiaIwnRqQZSWUm03HpBtxV(str(ffFDzprmdb14nE6ekuILVM),denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp,'',False)
		else: xTnWLMwOlD.rum8gIeCX3hYq(str(ffFDzprmdb14nE6ekuILVM),denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp,'',False)
	nUTgq0SFfC9[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
	if len(nUTgq0SFfC9)>(ffZSseDR2LUtmCunp+3): nUTgq0SFfC9[:] = nUTgq0SFfC9[:3]+ttczT0JFy9xID3iLGMXoQm2hjB4.sample(nUTgq0SFfC9[3:],ffZSseDR2LUtmCunp)
	return
def HH9vOCWwzA6(denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp):
	ARin5sf9V4BldW2ukb7Qyp = ARin5sf9V4BldW2ukb7Qyp.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg = ARin5sf9V4BldW2ukb7Qyp
	if '__M3USeries__' in ARin5sf9V4BldW2ukb7Qyp:
		zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg = ARin5sf9V4BldW2ukb7Qyp.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in denEcub0mKtMHWl3C5pOZD6: type = ',VIDEOS: '
	elif 'LIVE' in denEcub0mKtMHWl3C5pOZD6: type = ',LIVE: '
	UZ8LYnm5jsl9uKM0xDX('folder','[[COLOR FFC89008]'+type+zCbm3NxdvwHt9PGf8rJ7qk6O1Tsg+'[/COLOR] :القسم]',denEcub0mKtMHWl3C5pOZD6,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ARin5sf9V4BldW2ukb7Qyp)
	UZ8LYnm5jsl9uKM0xDX('folder','إعادة الطلب العشوائي من نفس القسم',denEcub0mKtMHWl3C5pOZD6,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ARin5sf9V4BldW2ukb7Qyp)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import oI5xiFN7h4
	for ffFDzprmdb14nE6ekuILVM in range(1,gx4WbX9yDPm6lk+1):
		if '__M3USeries__' in ARin5sf9V4BldW2ukb7Qyp: oI5xiFN7h4.KksoXzFiaIwnRqQZSWUm03HpBtxV(str(ffFDzprmdb14nE6ekuILVM),denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp,'',False)
		else: oI5xiFN7h4.rum8gIeCX3hYq(str(ffFDzprmdb14nE6ekuILVM),denEcub0mKtMHWl3C5pOZD6,ARin5sf9V4BldW2ukb7Qyp,'',False)
	nUTgq0SFfC9[:] = YyPEFjlKdh309pzAn(nUTgq0SFfC9)
	if len(nUTgq0SFfC9)>(ffZSseDR2LUtmCunp+3): nUTgq0SFfC9[:] = nUTgq0SFfC9[:3]+ttczT0JFy9xID3iLGMXoQm2hjB4.sample(nUTgq0SFfC9[3:],ffZSseDR2LUtmCunp)
	return
def YyPEFjlKdh309pzAn(nUTgq0SFfC9):
	oQyUGWk36va92YAj = []
	for type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in nUTgq0SFfC9:
		if 'صفحة' in CH3VkKb5LiB1cZUsoE or 'صفحه' in CH3VkKb5LiB1cZUsoE or 'page' in CH3VkKb5LiB1cZUsoE.lower(): continue
		oQyUGWk36va92YAj.append([type,CH3VkKb5LiB1cZUsoE,url,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk])
	return oQyUGWk36va92YAj
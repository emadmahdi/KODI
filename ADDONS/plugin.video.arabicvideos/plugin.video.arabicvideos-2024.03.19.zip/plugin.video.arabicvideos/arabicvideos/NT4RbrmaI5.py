# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'EGYBEST1'
ToYWiIbruzUaNKRPZLG16cAj = '_EB1_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['مكتبتي','ايجي بست']
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==770: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==771: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==772: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==773: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==774: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'FULL_FILTER___'+text)
	elif mode==775: rr60PDpqbMehZsYVuHmiAtN = gj2tQTVYG87dUpsMXPqrv(url,'DEFINED_FILTER___'+text)
	elif mode==776: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,SSGEc76fBan2)
	elif mode==779: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text,url)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',779,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','EGYBEST1-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('nav-list(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,771)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-article(.*?)social-box',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('main-title.*?">(.*?)<.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R in items:
			title = title.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,771,'','mainmenu')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-menu(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,771)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST1-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-article".*?">(.*?)<(.*?)article',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6,items = '','',[]
		for name,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			if 'حلقات' in name: gbRaTlfw5quES79COD2yPhJXzie6 = L0Uwx52bTBM
			if 'مواسم' in name: v0hReYLd84QxBaq7Og6nlV = L0Uwx52bTBM
		if v0hReYLd84QxBaq7Og6nlV and not type:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',v0hReYLd84QxBaq7Og6nlV,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,776,pjMZ802XQCSxYVk,'season')
		if gbRaTlfw5quES79COD2yPhJXzie6 and len(items)<2:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
			if items:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,773,pjMZ802XQCSxYVk)
			else:
				items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
				for ZcAK0askvzIWr4R,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,773)
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST1-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items,EEQy35Z2dq6DHvLKXA,LE0VmiWeMGS4dHJ3 = [],False,False
	if not type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-content(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,771,'','submenu')
				EEQy35Z2dq6DHvLKXA = True
	if not type and 'p=' not in url:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('searchform(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			if EEQy35Z2dq6DHvLKXA: UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر محدد',url,775,'','filter')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'فلتر كامل',url,774,'','filter')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث',url,779)
			UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			LE0VmiWeMGS4dHJ3 = True
	if not EEQy35Z2dq6DHvLKXA:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('blocks(.*?)article',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.strip('\n')
				ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
				if '/serie/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,776,pjMZ802XQCSxYVk,'season')
				else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,773,pjMZ802XQCSxYVk)
			SSGEc76fBan2 = '1'
			if 'p=' in url: url,SSGEc76fBan2 = url.split('p=',1)
			Iof8U0xDKbVslWATpzR4OvBe9 = '&' if '?' in url else '?'
			url = url+Iof8U0xDKbVslWATpzR4OvBe9
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(SSGEc76fBan2)+1)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الصفحة التالية',url,771)
			elif SSGEc76fBan2!='1':
				url = url+'p='+str(int(SSGEc76fBan2)-1)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الصفحة السابقة',url,771)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','EGYBEST1-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('<label>التصنيف</label>.*?">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	W0WLuDcR5UI6K,TbFRyPoVlrQAw7n3h8BukmfHNq,ZqrDM2pIkCR89FP3On = [],[],[]
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('video-play-iframe.*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
			ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=__embed')
	items = SomeI8i56FaDMGPE.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R in items:
		if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
			ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
			AfejZJoKh4D7k5G1P9gCwxTz = AfejZJoKh4D7k5G1P9gCwxTz.strip(' ')
			FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__download____'+AfejZJoKh4D7k5G1P9gCwxTz)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search,url=''):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search: search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','%20')
	if not url: url = aaeRjxiYcqOI6Sf8+'/search?query='+u9DhgpinLBfmjG3NtMalq7Y
	else: url = url+'?title='+u9DhgpinLBfmjG3NtMalq7Y+'&genre=&year=&lang='
	KKlnDcetq8Rrp3GY0(url,'search')
	return
def ibIaBw1kV7qvTO380sJ9toKhx(url):
	url = url.split('/smartemadfilter?')[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',url,'','','','','EGYBEST1-GET_FILTERS_BLOCKS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('form-row(.*?)</form>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = SomeI8i56FaDMGPE.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		prjZqOoMUE,wwpNZP87O2YjJIFT0rH95Al43RCWzi,UUTVrGP7Y31a = zip(*v3mSnRD6XCqOjksGlP2MuxpKUt4)
		v3mSnRD6XCqOjksGlP2MuxpKUt4 = zip(wwpNZP87O2YjJIFT0rH95Al43RCWzi,prjZqOoMUE,UUTVrGP7Y31a)
	return v3mSnRD6XCqOjksGlP2MuxpKUt4
def wLVgEovA7S1(L0Uwx52bTBM):
	items = SomeI8i56FaDMGPE.findall('value="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	return items
def wV2LqDT14MiOYa(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
xupe2PJyhdBkTXR9iVN3tZQ5azU1E4 = ['year','lang','genre']
y8nICQWej1Z6qTv234Y9koOcbg7 = ['year','lang','genre']
def gj2tQTVYG87dUpsMXPqrv(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = '',''
	else: HxWc8KBlSsT,efhkATx13dQgs4LyFMGpZYRaJ08iUO = filter.split('___')
	if type=='DEFINED_FILTER':
		if y8nICQWej1Z6qTv234Y9koOcbg7[0]+'=' not in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[0]
		for zz5ZOaoyATpS893tvdXE in range(len(y8nICQWej1Z6qTv234Y9koOcbg7[0:-1])):
			if y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE]+'=' in HxWc8KBlSsT: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = y8nICQWej1Z6qTv234Y9koOcbg7[zz5ZOaoyATpS893tvdXE+1]
		mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B+'=0'
		ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa.strip('&')+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR.strip('&')
		rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
	elif type=='FULL_FILTER':
		ggcHPQdAmEh = zWbQXxYyP2eSFhCBG61IqEDJu4(HxWc8KBlSsT,'modified_values')
		ggcHPQdAmEh = aDebGvrkdptunqTM8m4(ggcHPQdAmEh)
		if efhkATx13dQgs4LyFMGpZYRaJ08iUO: efhkATx13dQgs4LyFMGpZYRaJ08iUO = zWbQXxYyP2eSFhCBG61IqEDJu4(efhkATx13dQgs4LyFMGpZYRaJ08iUO,'all')
		if not efhkATx13dQgs4LyFMGpZYRaJ08iUO: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+efhkATx13dQgs4LyFMGpZYRaJ08iUO
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'أظهار قائمة الفيديو التي تم اختيارها ',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,771,'','filter')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+' [[   '+ggcHPQdAmEh+'   ]]',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,771,'','filter')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v3mSnRD6XCqOjksGlP2MuxpKUt4 = ibIaBw1kV7qvTO380sJ9toKhx(url)
	dict = {}
	for name,mjcA3DUe9IJV4bk,L0Uwx52bTBM in v3mSnRD6XCqOjksGlP2MuxpKUt4:
		name = name.replace('كل ','')
		items = wLVgEovA7S1(L0Uwx52bTBM)
		if '=' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = url
		if type=='DEFINED_FILTER':
			if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B!=mjcA3DUe9IJV4bk: continue
			elif len(items)<2:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					KKlnDcetq8Rrp3GY0(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
				else: gj2tQTVYG87dUpsMXPqrv(vfIB6ib8q1hFX5GweRrVPNTjY2E,'DEFINED_FILTER___'+ecMSxgw2QqpvI)
				return
			else:
				if mjcA3DUe9IJV4bk==y8nICQWej1Z6qTv234Y9koOcbg7[-1]:
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,771,'','filter')
				else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع ',vfIB6ib8q1hFX5GweRrVPNTjY2E,775,'','',ecMSxgw2QqpvI)
		elif type=='FULL_FILTER':
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'=0'
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'=0'
			ecMSxgw2QqpvI = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع :'+name,vfIB6ib8q1hFX5GweRrVPNTjY2E,774,'','',ecMSxgw2QqpvI)
		dict[mjcA3DUe9IJV4bk] = {}
		for EPwT39HrS1tU6Ng8YBGpJADixzLV5C,irE1qv3BUYZMo5 in items:
			if not EPwT39HrS1tU6Ng8YBGpJADixzLV5C: continue
			if irE1qv3BUYZMo5 in C1pRb6K8Qs: continue
			dict[mjcA3DUe9IJV4bk][EPwT39HrS1tU6Ng8YBGpJADixzLV5C] = irE1qv3BUYZMo5
			mmrh9sejwbnFkxTlKMWa = HxWc8KBlSsT+'&'+mjcA3DUe9IJV4bk+'='+irE1qv3BUYZMo5
			GGw4ZcYsxyNT6BmQf1jEJKa7pR = efhkATx13dQgs4LyFMGpZYRaJ08iUO+'&'+mjcA3DUe9IJV4bk+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
			L6iYCRsI1U4ytrW = mmrh9sejwbnFkxTlKMWa+'___'+GGw4ZcYsxyNT6BmQf1jEJKa7pR
			title = irE1qv3BUYZMo5+' :'#+dict[mjcA3DUe9IJV4bk]['0']
			title = irE1qv3BUYZMo5+' :'+name
			if type=='FULL_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,774,'','',L6iYCRsI1U4ytrW)
			elif type=='DEFINED_FILTER' and y8nICQWej1Z6qTv234Y9koOcbg7[-2]+'=' in HxWc8KBlSsT:
				rm1tgvkXOihGYpLJnzuHwyPSZA = zWbQXxYyP2eSFhCBG61IqEDJu4(GGw4ZcYsxyNT6BmQf1jEJKa7pR,'modified_filters')
				vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'/smartemadfilter?'+rm1tgvkXOihGYpLJnzuHwyPSZA
				XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = wV2LqDT14MiOYa(vfIB6ib8q1hFX5GweRrVPNTjY2E)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,771,'','filter')
			elif type=='DEFINED_FILTER': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,775,'','',L6iYCRsI1U4ytrW)
	return
def zWbQXxYyP2eSFhCBG61IqEDJu4(LE0VmiWeMGS4dHJ3,mode):
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.replace('=&','=0&')
	LE0VmiWeMGS4dHJ3 = LE0VmiWeMGS4dHJ3.strip('&')
	tSCH1cAvm5Ki = {}
	if '=' in LE0VmiWeMGS4dHJ3:
		items = LE0VmiWeMGS4dHJ3.split('&')
		for MMeFJKLQG4HdIwObZ1l9 in items:
			kuywHRSrgAUlWN0C7svj94ZOm6,EPwT39HrS1tU6Ng8YBGpJADixzLV5C = MMeFJKLQG4HdIwObZ1l9.split('=')
			tSCH1cAvm5Ki[kuywHRSrgAUlWN0C7svj94ZOm6] = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = ''
	for key in xupe2PJyhdBkTXR9iVN3tZQ5azU1E4:
		if key in list(tSCH1cAvm5Ki.keys()): EPwT39HrS1tU6Ng8YBGpJADixzLV5C = tSCH1cAvm5Ki[key]
		else: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = '0'
		if '%' not in EPwT39HrS1tU6Ng8YBGpJADixzLV5C: EPwT39HrS1tU6Ng8YBGpJADixzLV5C = TbEVs6mLPHF(EPwT39HrS1tU6Ng8YBGpJADixzLV5C)
		if mode=='modified_values' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+' + '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='modified_filters' and EPwT39HrS1tU6Ng8YBGpJADixzLV5C!='0': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif mode=='all': y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU+'&'+key+'='+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip(' + ')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.strip('&')
	y4rSdac1zC26FA9IZnuO7WRU = y4rSdac1zC26FA9IZnuO7WRU.replace('=0','=')
	return y4rSdac1zC26FA9IZnuO7WRU
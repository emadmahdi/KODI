# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'BOKRA'
ToYWiIbruzUaNKRPZLG16cAj = '_BKR_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
headers = {'User-Agent':''}
C1pRb6K8Qs = ['افلام للكبار','بكرا TV']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==370: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==371: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==372: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==374: rr60PDpqbMehZsYVuHmiAtN = LLFGDlydSzXQhp3q(url)
	elif mode==375: rr60PDpqbMehZsYVuHmiAtN = zzOEJhrvf3j97QeMNTYp(url)
	elif mode==376: rr60PDpqbMehZsYVuHmiAtN = g3tIxnpaQOejXP0DRqTAuFd1MSZ(0,url)
	elif mode==377: rr60PDpqbMehZsYVuHmiAtN = g3tIxnpaQOejXP0DRqTAuFd1MSZ(1,url)
	elif mode==379: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','BOKRA-MENU-1st')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('right-side(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',aaeRjxiYcqOI6Sf8,375)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الأحدث',aaeRjxiYcqOI6Sf8,376)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'قائمة الممثلين',aaeRjxiYcqOI6Sf8,374)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="container"(.*?)top-menu',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items[7:]:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371)
		for ZcAK0askvzIWr4R,title in items[0:7]:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371)
	return
def LLFGDlydSzXQhp3q(website=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','BOKRA-ACTORSMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="row cat Tags"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if 'http' in ZcAK0askvzIWr4R: continue
			else: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371)
	return
def zzOEJhrvf3j97QeMNTYp(website=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,'','','','','BOKRA-FEATURED-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"MainContent"(.*?)main-title2',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('://',':///').replace('//','/').replace(' ','%20')
				UZ8LYnm5jsl9uKM0xDX('video',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,372,pjMZ802XQCSxYVk)
	return
def g3tIxnpaQOejXP0DRqTAuFd1MSZ(id,website=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,'','','','','BOKRA-WATCHINGNOW-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-title2(.*?)class="row',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[id]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if not any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs):
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('://',':///').replace('//','/').replace(' ','%20')
				UZ8LYnm5jsl9uKM0xDX('video',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,372,pjMZ802XQCSxYVk)
	return
def KKlnDcetq8Rrp3GY0(url,hv54R8NjbFqzOS6x9PIsu=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','BOKRA-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if 'vidpage_' in url:
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('href="(/Album-.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R[0]
			KKlnDcetq8Rrp3GY0(ZcAK0askvzIWr4R)
			return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class=" subcats"(.*?)class="col-md-3',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if hv54R8NjbFqzOS6x9PIsu=='' and pDTlIgyewF1XV69R8kd and pDTlIgyewF1XV69R8kd[0].count('href')>1:
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الجميع',url,371,'','','titles')
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371)
	else:
		oojL40IJtK = []
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="col-md-3(.*?)col-xs-12',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if not pDTlIgyewF1XV69R8kd: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="col-sm-8"(.*?)col-xs-12',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
				title = title.strip(' ')
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in ZcAK0askvzIWr4R:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371,pjMZ802XQCSxYVk)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) - +الحلقة +\d+',title,SomeI8i56FaDMGPE.DOTALL)
					if iHPhR4wCQ1oINaL: title = '_MOD_مسلسل '+iHPhR4wCQ1oINaL[0]
					if title not in oojL40IJtK:
						oojL40IJtK.append(title)
						UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371,pjMZ802XQCSxYVk)
				else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,372,pjMZ802XQCSxYVk)
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('class="".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
				title = 'صفحة '+dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,371,'','','titles')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','BOKRA-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('label-success mrg-btm-5 ">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = ''
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('var url = "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = url.replace('/vidpage_','/Play/')
	if 'http' not in vfIB6ib8q1hFX5GweRrVPNTjY2E: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+vfIB6ib8q1hFX5GweRrVPNTjY2E
	vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E.strip('-')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','BOKRA-PLAY-2nd')
	ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = SomeI8i56FaDMGPE.findall('src="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
	if XuItmjBhoUDa3fRO9nQsbNYrpG1cdv:
		XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = XuItmjBhoUDa3fRO9nQsbNYrpG1cdv[-1]
		if 'http' not in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv: XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = 'http:'+XuItmjBhoUDa3fRO9nQsbNYrpG1cdv
		if '/PLAY/' not in vfIB6ib8q1hFX5GweRrVPNTjY2E:
			if 'embed.min.js' in XuItmjBhoUDa3fRO9nQsbNYrpG1cdv:
				ViltICrvcTRpxsP1S42F = SomeI8i56FaDMGPE.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
				if ViltICrvcTRpxsP1S42F:
					ePG3JLOyjh61Rl47v, LGdMCOa9So1xq25tw = ViltICrvcTRpxsP1S42F[0]
					XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = DRom9hFTZXKuvfr2(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,'url')+'/v2/'+ePG3JLOyjh61Rl47v+'/config/'+LGdMCOa9So1xq25tw+'.json'
		import Y4ILyJBspQ
		Y4ILyJBspQ.vjr9310yigkK([XuItmjBhoUDa3fRO9nQsbNYrpG1cdv],HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/Search/'+search
	KKlnDcetq8Rrp3GY0(url)
	return
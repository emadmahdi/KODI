# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'FASELHD1'
headers = {'User-Agent':''}
ToYWiIbruzUaNKRPZLG16cAj = '_FH1_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['جوائز الأوسكار','المراجعات','wwe']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==570: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==571: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==572: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==573: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,text)
	elif mode==576: rr60PDpqbMehZsYVuHmiAtN = oXUTNd8L3b0iD()
	elif mode==579: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'لماذا الموقع بطيء','',576)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	BdSZn7YxiHaUcf1Rzt5o,url,ttpgqJBdkoxeKOcwaiP = PP2QEmwzKue6nol57v(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'faselhd1','فاصل إعلاني','dubbed-movies')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع',BdSZn7YxiHaUcf1Rzt5o,579,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المميزة',BdSZn7YxiHaUcf1Rzt5o,571,'','','featured1')
	items = SomeI8i56FaDMGPE.findall('class="h3">(.*?)<.*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not items:
		ztgqWUaDpe8CE9N('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,ZcAK0askvzIWr4R in items:
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,571,'','','details1')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"menu-primary"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		vvNkUbe1YW5oDF0S2w3dtnT976X = SomeI8i56FaDMGPE.findall('<li (.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		irwPuXKA8xZeT = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		jUSuZAztxy34TB5CIP2 = 0
		for hmedxznGXRHt1L in vvNkUbe1YW5oDF0S2w3dtnT976X:
			if jUSuZAztxy34TB5CIP2>0: UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',hmedxznGXRHt1L,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				if ZcAK0askvzIWr4R=='#': continue
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
				if title=='': continue
				if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title.lower() for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
				title = irwPuXKA8xZeT[jUSuZAztxy34TB5CIP2]+title
				UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,571,'','','details2')
			jUSuZAztxy34TB5CIP2 += 1
	return
def oXUTNd8L3b0iD():
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FASELHD1-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('class="h4">(.*?)</div>(.*?)"container"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not EFOPTCNHpGvMYuS: return
	if type=='filters':
		pDTlIgyewF1XV69R8kd = [BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"homeSlide"(.*?)"container"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		CCAvDuOGpgtxJmhERUBWNoTs3Yy2,ZZHhmdtY1g,R3Rinqky4ouBgYEtZh = zip(*items)
		items = zip(ZZHhmdtY1g,CCAvDuOGpgtxJmhERUBWNoTs3Yy2,R3Rinqky4ouBgYEtZh)
	elif type=='featured2':
		title,L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='details2' and len(EFOPTCNHpGvMYuS)>1:
		title = EFOPTCNHpGvMYuS[0][0]
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,571,'','','featured2')
		title = EFOPTCNHpGvMYuS[1][0]
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,571,'','','details3')
		return
	else:
		title,L0Uwx52bTBM = EFOPTCNHpGvMYuS[-1]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title.lower() for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
		pjMZ802XQCSxYVk = c8Fvb4IfHW9XkG1mLK5Z(pjMZ802XQCSxYVk)
		pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.split('?resize=')[0]
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|حلقة).\d+',title,SomeI8i56FaDMGPE.DOTALL)
		if '/collections/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,571,pjMZ802XQCSxYVk)
		elif iHPhR4wCQ1oINaL and type=='':
			title = '_MOD_'+iHPhR4wCQ1oINaL[0][0]
			title = title.strip(' –')
			if title not in oojL40IJtK:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,573,pjMZ802XQCSxYVk)
				oojL40IJtK.append(title)
		elif 'episodes/' in ZcAK0askvzIWr4R or 'movies/' in ZcAK0askvzIWr4R or 'hindi/' in ZcAK0askvzIWr4R:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,572,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,573,pjMZ802XQCSxYVk)
	if type=='filters':
		rTcXIjKgMCUdaPSWkn = SomeI8i56FaDMGPE.findall('"more_button_page":(.*?),',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if rTcXIjKgMCUdaPSWkn:
			count = rTcXIjKgMCUdaPSWkn[0]
			ZcAK0askvzIWr4R = url+'/offset/'+count
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة أخرى',ZcAK0askvzIWr4R,571,'','','filters')
	elif 'details' in type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("class='pagination(.*?)</div>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall("href='(.*?)'.*?>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = 'صفحة '+dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,571,'','','details4')
	return
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	v0hReYLd84QxBaq7Og6nlV = False
	if not type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"seasonList"(.*?)"container"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
				v0hReYLd84QxBaq7Og6nlV = True
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,name,title in items:
					name = dCFP41Kxv9j8EHM(name)
					if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+ZcAK0askvzIWr4R
					title = name+' - '+title
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,573,pjMZ802XQCSxYVk,'','episodes')
	if type=='episodes' or not v0hReYLd84QxBaq7Og6nlV:
		NmX0ZP715phHsSiCzvxR3IB = SomeI8i56FaDMGPE.findall('"posterImg".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if NmX0ZP715phHsSiCzvxR3IB: pjMZ802XQCSxYVk = NmX0ZP715phHsSiCzvxR3IB[0]
		else: pjMZ802XQCSxYVk = ''
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"epAll"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				title = dCFP41Kxv9j8EHM(title)
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,572,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq,yuvWisETBpYaf7k1M3RF9,AH37UN2zyfhutGmL4JkajnF9eT = [],[],[]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','','','','FASELHD1-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	awJOmiIZMDcgo = SomeI8i56FaDMGPE.findall('مستوى المشاهدة.*?">(.*?)</span>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if awJOmiIZMDcgo:
		Wch421XkoTwA = SomeI8i56FaDMGPE.findall('"tag">(.*?)</a>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"videoRow"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&img=')[0]
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=__embed')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="streamHeader(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall("href = '(.*?)'.*?</i>(.*?)</a>",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&img=')[0]
			name = name.strip(' ')
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+name+'__watch')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="downloadLinks(.*?)blackwindow',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</span>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,name in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('&img=')[0]
			TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+name+'__download')
	for YIMRpk6L45v0CXlJdqG in TbFRyPoVlrQAw7n3h8BukmfHNq:
		ZcAK0askvzIWr4R,name = YIMRpk6L45v0CXlJdqG.split('?named')
		if ZcAK0askvzIWr4R not in yuvWisETBpYaf7k1M3RF9:
			yuvWisETBpYaf7k1M3RF9.append(ZcAK0askvzIWr4R)
			AH37UN2zyfhutGmL4JkajnF9eT.append(YIMRpk6L45v0CXlJdqG)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(AH37UN2zyfhutGmL4JkajnF9eT,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/?s='+search
	BdSZn7YxiHaUcf1Rzt5o,vfIB6ib8q1hFX5GweRrVPNTjY2E,RKBm27pOP0frivqSgzwMA58 = PP2QEmwzKue6nol57v(jj0C6IlvPFh,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E,'details5')
	return
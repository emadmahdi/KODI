# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'KATKOTTV'
ToYWiIbruzUaNKRPZLG16cAj = '_KTV_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = []
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==810: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==811: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==812: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==813: rr60PDpqbMehZsYVuHmiAtN = LQXmcAxYahIOeJ1NdV0vw9PGBq7D(url)
	elif mode==819: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','KATKOTTV-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"primary-links"(.*?)"most-viewed"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if title in C1pRb6K8Qs: continue
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,811)
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"home-content"(.*?)"footer"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		oojL40IJtK = []
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|حلقة).\d+',title,SomeI8i56FaDMGPE.DOTALL)
			if 'episodes' not in type and iHPhR4wCQ1oINaL:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0][0]
				title = title.replace('اون لاين','')
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,813,pjMZ802XQCSxYVk)
					oojL40IJtK.append(title)
			else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,812,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("'pagination'(.*?)footer",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,811,'','',type)
	return
def LQXmcAxYahIOeJ1NdV0vw9PGBq7D(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"category".*?href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R: KKlnDcetq8Rrp3GY0(ZcAK0askvzIWr4R[0],'episodes')
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq = []
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url+'?do=watch'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','KATKOTTV-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('" src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		QumF9ZVCakY4d1KSzqgDyT3EBoX = SomeI8i56FaDMGPE.findall('post=(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if QumF9ZVCakY4d1KSzqgDyT3EBoX:
			QumF9ZVCakY4d1KSzqgDyT3EBoX = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(QumF9ZVCakY4d1KSzqgDyT3EBoX[0])
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: QumF9ZVCakY4d1KSzqgDyT3EBoX = QumF9ZVCakY4d1KSzqgDyT3EBoX.decode('utf8')
			QumF9ZVCakY4d1KSzqgDyT3EBoX = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',QumF9ZVCakY4d1KSzqgDyT3EBoX)
			ZZHhmdtY1g = QumF9ZVCakY4d1KSzqgDyT3EBoX['servers']
			R3Rinqky4ouBgYEtZh = list(ZZHhmdtY1g.keys())
			ZZHhmdtY1g = list(ZZHhmdtY1g.values())
			XTPzvZdUymK2axoEu8W73BjMcheQf = zip(R3Rinqky4ouBgYEtZh,ZZHhmdtY1g)
			for title,ZcAK0askvzIWr4R in XTPzvZdUymK2axoEu8W73BjMcheQf:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/?s='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
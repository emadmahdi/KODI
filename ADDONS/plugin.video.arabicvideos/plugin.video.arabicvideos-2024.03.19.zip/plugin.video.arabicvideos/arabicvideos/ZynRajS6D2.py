# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SHOOFPRO'
ToYWiIbruzUaNKRPZLG16cAj = '_SHP_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['مصارعة','بث مباشر']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==480: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==481: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==482: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==483: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url,text)
	elif mode==489: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text,url)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','SHOOFPRO-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = SomeI8i56FaDMGPE.findall('href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BdSZn7YxiHaUcf1Rzt5o = BdSZn7YxiHaUcf1Rzt5o[0].strip('/')
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(BdSZn7YxiHaUcf1Rzt5o,'url')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع',BdSZn7YxiHaUcf1Rzt5o,489,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أحدث المواضيع',BdSZn7YxiHaUcf1Rzt5o,481)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"navigation"(.*?)"myAccount"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</span>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		if ZcAK0askvzIWr4R=='#': continue
		if title in C1pRb6K8Qs: continue
		title = dCFP41Kxv9j8EHM(title)
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,481)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,ZlD4kRsPcHnB1ugX):
	items = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"post(.*?)"footer"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	pPcdB6tDsfmZOFHvkWje2EyAY8 = '/'.join(ZlD4kRsPcHnB1ugX.strip('/').split('/')[4:]).split('-')
	for ZcAK0askvzIWr4R,title,pjMZ802XQCSxYVk in items:
		title = dCFP41Kxv9j8EHM(title)
		iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) حلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
		if ZlD4kRsPcHnB1ugX:
			spdYctk0fWD1Z = '/'.join(ZcAK0askvzIWr4R.strip('/').split('/')[4:]).split('-')
			TWMdDso0KLn = len([IWKVTarP4wnMUtBX6q2185OGHDJ for IWKVTarP4wnMUtBX6q2185OGHDJ in pPcdB6tDsfmZOFHvkWje2EyAY8 if IWKVTarP4wnMUtBX6q2185OGHDJ in spdYctk0fWD1Z])
			if TWMdDso0KLn>2 and '/episodes/' in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,482,pjMZ802XQCSxYVk)
		else:
			if not iHPhR4wCQ1oINaL: iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if set(title.split()) & set(W2XL1cnGkuqaZx) and 'مسلسل' not in title:
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,482,pjMZ802XQCSxYVk)
			elif iHPhR4wCQ1oINaL and 'حلقة' in title:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0]
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,483,pjMZ802XQCSxYVk,'',url)
					oojL40IJtK.append(title)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,483,pjMZ802XQCSxYVk,'',url)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("'pagination'(.*?)</div>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall("href='(.*?)'.*?>(.*?)</a>",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,481,'','',ZlD4kRsPcHnB1ugX)
	return
def ooLCwrlF3n0vBjpA(url,vfIB6ib8q1hFX5GweRrVPNTjY2E):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	pjMZ802XQCSxYVk = SomeI8i56FaDMGPE.findall('"img-responsive" src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk[0]
	else: pjMZ802XQCSxYVk = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Thumb')
	Ev9P2kIhVD3txgQowCSHXA = True
	q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ = SomeI8i56FaDMGPE.findall('"listSeasons(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ and '/ajax/seasons' not in url:
		L0Uwx52bTBM = q2uJtoRlFZ3IxU51D7mcWH8SpyVAQ[0]
		count = L0Uwx52bTBM.count('data-slug=')
		if count==0: count = L0Uwx52bTBM.count('data-season=')
		if count>1:
			Ev9P2kIhVD3txgQowCSHXA = False
			if 'data-slug="' in L0Uwx52bTBM:
				items = SomeI8i56FaDMGPE.findall('data-slug="(.*?)">(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				for id,title in items:
					ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,483,pjMZ802XQCSxYVk)
			else:
				items = SomeI8i56FaDMGPE.findall('data-season="(.*?)">(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				for id,title in items:
					ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,483,pjMZ802XQCSxYVk)
	if Ev9P2kIhVD3txgQowCSHXA:
		L0Uwx52bTBM = ''
		if '/ajax/seasons' in url: L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
		else:
			EFOPTCNHpGvMYuS = SomeI8i56FaDMGPE.findall('"eplist"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if EFOPTCNHpGvMYuS: L0Uwx52bTBM = EFOPTCNHpGvMYuS[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if items:
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,482,pjMZ802XQCSxYVk)
	if not nUTgq0SFfC9: KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E,url)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.strip('/')+'/?do=watch'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','SHOOFPRO-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	BdSZn7YxiHaUcf1Rzt5o = DRom9hFTZXKuvfr2(url,'url')
	OnjXh8rf1IgEsDvTJ20LycGA3bmP = SomeI8i56FaDMGPE.findall('vo_postID = "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not OnjXh8rf1IgEsDvTJ20LycGA3bmP: OnjXh8rf1IgEsDvTJ20LycGA3bmP = SomeI8i56FaDMGPE.findall('\(this\.id\,0\,(.*?)\)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	OnjXh8rf1IgEsDvTJ20LycGA3bmP = OnjXh8rf1IgEsDvTJ20LycGA3bmP[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"serversList"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('id="(.*?)".*?">(.*?)</li>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for aNBiPRMqeFzG0pD5yAovKb8k27lJQ,title in items:
			title = title.strip(' ')
			ZcAK0askvzIWr4R = BdSZn7YxiHaUcf1Rzt5o+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+OnjXh8rf1IgEsDvTJ20LycGA3bmP+'&video='+aNBiPRMqeFzG0pD5yAovKb8k27lJQ[2:]+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('"getEmbed".*?src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZcAK0askvzIWr4R:
		title = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R[0],'url')
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]+'?named='+title+'__embed'
		aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.strip('/')+'/?do=download'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','','SHOOFPRO-PLAY-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"table-responsive"(.*?)</table>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('<td>(.*?)</td>.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R in items:
			title = title.strip(' ')
			if 'anavidz' in ZcAK0askvzIWr4R: U2iQmHMJzoNkjORTGY7c51vZ = '__خاص'
			else: U2iQmHMJzoNkjORTGY7c51vZ = ''
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'+U2iQmHMJzoNkjORTGY7c51vZ
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search,BdSZn7YxiHaUcf1Rzt5o=''):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	if BdSZn7YxiHaUcf1Rzt5o=='': BdSZn7YxiHaUcf1Rzt5o = aaeRjxiYcqOI6Sf8
	url = BdSZn7YxiHaUcf1Rzt5o+'/search/'+search+'/'
	KKlnDcetq8Rrp3GY0(url,'')
	return
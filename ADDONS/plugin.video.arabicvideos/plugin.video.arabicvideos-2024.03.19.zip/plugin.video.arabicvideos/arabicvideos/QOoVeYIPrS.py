# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'SHOOFMAX'
ToYWiIbruzUaNKRPZLG16cAj = '_SHM_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
n9dWOLMBkl = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][1]
dghDltko0P2 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][2]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==50: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==51: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==52: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==53: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==55: rr60PDpqbMehZsYVuHmiAtN = YDAvrwodULmf()
	elif mode==56: rr60PDpqbMehZsYVuHmiAtN = mufj4iEZQAWX5UHJ()
	elif mode==57: rr60PDpqbMehZsYVuHmiAtN = BexcQj7TyYU84szLOSa9JR0(url,1)
	elif mode==58: rr60PDpqbMehZsYVuHmiAtN = BexcQj7TyYU84szLOSa9JR0(url,2)
	elif mode==59: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المسلسلات','',56)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الافلام','',55)
	return ''
def YDAvrwodULmf():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'احدث الافلام',aaeRjxiYcqOI6Sf8+'/movie/1/newest',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'افلام رائجة',aaeRjxiYcqOI6Sf8+'/movie/1/popular',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اخر اضافات الافلام',aaeRjxiYcqOI6Sf8+'/movie/1/latest',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'افلام كلاسيكية',aaeRjxiYcqOI6Sf8+'/movie/1/classic',51)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار افلام مرتبة بسنة الانتاج',aaeRjxiYcqOI6Sf8+'/movie/1/yop',57)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار افلام مرتبة بالافضل تقييم',aaeRjxiYcqOI6Sf8+'/movie/1/review',57)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار افلام مرتبة بالاكثر مشاهدة',aaeRjxiYcqOI6Sf8+'/movie/1/views',57)
	return
def mufj4iEZQAWX5UHJ():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'احدث المسلسلات',aaeRjxiYcqOI6Sf8+'/series/1/newest',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رائجة',aaeRjxiYcqOI6Sf8+'/series/1/popular',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اخر اضافات المسلسلات',aaeRjxiYcqOI6Sf8+'/series/1/latest',51)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات كلاسيكية',aaeRjxiYcqOI6Sf8+'/series/1/classic',51)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار مسلسلات مرتبة بسنة الانتاج',aaeRjxiYcqOI6Sf8+'/series/1/yop',57)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار مسلسلات مرتبة بالافضل تقييم',aaeRjxiYcqOI6Sf8+'/series/1/review',57)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اختيار مسلسلات مرتبة بالاكثر مشاهدة',aaeRjxiYcqOI6Sf8+'/series/1/views',57)
	return
def KKlnDcetq8Rrp3GY0(url):
	if '?' in url:
		u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('?')
		url = u3gUQexlvJM86CS0bXGRBoEFrkZiP[0]
		filter = '?' + TbEVs6mLPHF(u3gUQexlvJM86CS0bXGRBoEFrkZiP[1],'=&:/%')
	else: filter = ''
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('/')
	sort,SSGEc76fBan2,type = u3gUQexlvJM86CS0bXGRBoEFrkZiP[-1],u3gUQexlvJM86CS0bXGRBoEFrkZiP[-2],u3gUQexlvJM86CS0bXGRBoEFrkZiP[-3]
	if sort in ['yop','review','views']:
		if type=='movie': hv54R8NjbFqzOS6x9PIsu='فيلم'
		elif type=='series': hv54R8NjbFqzOS6x9PIsu='مسلسل'
		url = aaeRjxiYcqOI6Sf8 + '/genre/filter/' + TbEVs6mLPHF(hv54R8NjbFqzOS6x9PIsu) + '/' + SSGEc76fBan2 + '/' + sort + filter
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','SHOOFMAX-TITLES-1st')
		items = SomeI8i56FaDMGPE.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		FlkNmICyPuaD46AMG5weBxqnpv=0
		for id,title,DDR4fc6P3gjEHKpmiIoXubtxU5N,pjMZ802XQCSxYVk in items:
			FlkNmICyPuaD46AMG5weBxqnpv += 1
			pjMZ802XQCSxYVk = dghDltko0P2 + '/v2/img/program/main/' + pjMZ802XQCSxYVk + '-2.jpg'
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + '/program/' + id
			if type=='movie': UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,53,pjMZ802XQCSxYVk)
			if type=='series': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسل '+title,ZcAK0askvzIWr4R+'?ep='+DDR4fc6P3gjEHKpmiIoXubtxU5N+'='+title+'='+pjMZ802XQCSxYVk,52,pjMZ802XQCSxYVk)
	else:
		if type=='movie': hv54R8NjbFqzOS6x9PIsu='movies'
		elif type=='series': hv54R8NjbFqzOS6x9PIsu='series'
		url = n9dWOLMBkl + '/json/selected/' + sort + '-' + hv54R8NjbFqzOS6x9PIsu + '-WW.json'
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','SHOOFMAX-TITLES-2nd')
		items = SomeI8i56FaDMGPE.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		FlkNmICyPuaD46AMG5weBxqnpv=0
		for id,DDR4fc6P3gjEHKpmiIoXubtxU5N,pjMZ802XQCSxYVk,title in items:
			FlkNmICyPuaD46AMG5weBxqnpv += 1
			pjMZ802XQCSxYVk = n9dWOLMBkl + '/img/program/' + pjMZ802XQCSxYVk + '-2.jpg'
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + '/program/' + id
			if type=='movie': UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,53,pjMZ802XQCSxYVk)
			elif type=='series': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسل '+title,ZcAK0askvzIWr4R+'?ep='+DDR4fc6P3gjEHKpmiIoXubtxU5N+'='+title+'='+pjMZ802XQCSxYVk,52,pjMZ802XQCSxYVk)
	title='صفحة '
	if FlkNmICyPuaD46AMG5weBxqnpv==16:
		for IXxzM6Hy9PW in range(1,13) :
			if not SSGEc76fBan2==str(IXxzM6Hy9PW):
				url = aaeRjxiYcqOI6Sf8+'/genre/filter/'+type+'/'+str(IXxzM6Hy9PW)+'/'+sort + filter
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title+str(IXxzM6Hy9PW),url,51)
	return
def ooLCwrlF3n0vBjpA(url):
	u3gUQexlvJM86CS0bXGRBoEFrkZiP = url.split('=')
	DDR4fc6P3gjEHKpmiIoXubtxU5N = int(u3gUQexlvJM86CS0bXGRBoEFrkZiP[1])
	name = aDebGvrkdptunqTM8m4(u3gUQexlvJM86CS0bXGRBoEFrkZiP[2])
	name = name.replace('_MOD_مسلسل ','')
	pjMZ802XQCSxYVk = u3gUQexlvJM86CS0bXGRBoEFrkZiP[3]
	url = url.split('?')[0]
	if DDR4fc6P3gjEHKpmiIoXubtxU5N==0:
		BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'','','','SHOOFMAX-EPISODES-1st')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<select(.*?)</select>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('option value="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		DDR4fc6P3gjEHKpmiIoXubtxU5N = int(items[-1])
	for iHPhR4wCQ1oINaL in range(DDR4fc6P3gjEHKpmiIoXubtxU5N,0,-1):
		ZcAK0askvzIWr4R = url + '?ep=' + str(iHPhR4wCQ1oINaL)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(iHPhR4wCQ1oINaL)
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,53,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,url,'','','','SHOOFMAX-PLAY-1st')
	Zkw4pK50sHBeAQTPJ76a81EIOhXN = SomeI8i56FaDMGPE.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Zkw4pK50sHBeAQTPJ76a81EIOhXN:
		p1BoraOuWL = Zkw4pK50sHBeAQTPJ76a81EIOhXN[1].replace('T','    ')
		ztgqWUaDpe8CE9N('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+p1BoraOuWL)
		return
	O8dIADJcTpBsGqLk572o6gyUM9,rUcDTJVyYsaiko4gdQKG1 = [],[]
	Efivsyn8aQ6 = SomeI8i56FaDMGPE.findall('var origin_link = "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	ffFXyuBcvR70IPhzNM2aZC = SomeI8i56FaDMGPE.findall('var backup_origin_link = "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('hls: (.*?)_link\+"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for FglT5H2faVGm6IqpcXS9vQsojPLu,ZcAK0askvzIWr4R in ZZHhmdtY1g:
		if 'backup' in FglT5H2faVGm6IqpcXS9vQsojPLu:
			FglT5H2faVGm6IqpcXS9vQsojPLu = 'backup server'
			url = ffFXyuBcvR70IPhzNM2aZC + ZcAK0askvzIWr4R
		else:
			FglT5H2faVGm6IqpcXS9vQsojPLu = 'main server'
			url = Efivsyn8aQ6 + ZcAK0askvzIWr4R
		if '.m3u8' in url:
			O8dIADJcTpBsGqLk572o6gyUM9.append(url)
			rUcDTJVyYsaiko4gdQKG1.append('m3u8  '+FglT5H2faVGm6IqpcXS9vQsojPLu)
	ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	ZZHhmdtY1g += SomeI8i56FaDMGPE.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for FglT5H2faVGm6IqpcXS9vQsojPLu,ZcAK0askvzIWr4R in ZZHhmdtY1g:
		filename = ZcAK0askvzIWr4R.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in FglT5H2faVGm6IqpcXS9vQsojPLu:
			FglT5H2faVGm6IqpcXS9vQsojPLu = 'backup server'
			url = ffFXyuBcvR70IPhzNM2aZC + ZcAK0askvzIWr4R
		else:
			FglT5H2faVGm6IqpcXS9vQsojPLu = 'main server'
			url = Efivsyn8aQ6 + ZcAK0askvzIWr4R
		O8dIADJcTpBsGqLk572o6gyUM9.append(url)
		rUcDTJVyYsaiko4gdQKG1.append('mp4  '+FglT5H2faVGm6IqpcXS9vQsojPLu+'  '+filename)
	I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('Select Video Quality:', rUcDTJVyYsaiko4gdQKG1)
	if I7mfbGiWNFcBVJOn == -1 : return
	url = O8dIADJcTpBsGqLk572o6gyUM9[I7mfbGiWNFcBVJOn]
	kFygcp2jqSUCiNRnur71xMZI96(url,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video')
	return
def BexcQj7TyYU84szLOSa9JR0(url,type):
	if 'series' in url: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8 + '/genre/مسلسل'
	else: vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8 + '/genre/فيلم'
	vfIB6ib8q1hFX5GweRrVPNTjY2E = TbEVs6mLPHF(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('subgenre(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	elif type==2: pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('country(.*?)div',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('option value="(.*?)">(.*?)</option',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if type==1:
		for VNKQ96ilACfFmY54qogtRjczS1yT,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url+'?subgenre='+VNKQ96ilACfFmY54qogtRjczS1yT,58)
	elif type==2:
		url,VNKQ96ilACfFmY54qogtRjczS1yT = url.split('?')
		for Jo8iROg3wQsBTMCjGz1hZAtpm,title in items:
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url+'?country='+Jo8iROg3wQsBTMCjGz1hZAtpm+'&'+VNKQ96ilACfFmY54qogtRjczS1yT,51)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search: search = ymH9jzg2KId5MCvw8lXBZn()
	if not search: return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','%20')
	url = aaeRjxiYcqOI6Sf8+'/search?q='+u9DhgpinLBfmjG3NtMalq7Y
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('general-body(.*?)search-bottom-padding',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if items:
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			url = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+TbEVs6mLPHF(title)+'='+pjMZ802XQCSxYVk
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,52,pjMZ802XQCSxYVk)
				else:
					title = '_MOD_فيلم '+title
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,53,pjMZ802XQCSxYVk)
	return
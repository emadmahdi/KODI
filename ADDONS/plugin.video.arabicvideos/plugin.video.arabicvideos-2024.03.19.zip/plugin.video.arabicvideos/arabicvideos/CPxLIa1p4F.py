# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'GLOBALSEARCH'
ToYWiIbruzUaNKRPZLG16cAj = '_GLS_'
def GI13aCFr0qimdOT(lOH3hXsnQiFCRjbN12,eesaHQO5yPGNvopTtWzR,yy42JUqszVIO89i,SSGEc76fBan2):
	if   lOH3hXsnQiFCRjbN12==540: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif lOH3hXsnQiFCRjbN12==541: rr60PDpqbMehZsYVuHmiAtN = xm63IuzheTZc(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==542: rr60PDpqbMehZsYVuHmiAtN = dPCS1Rv5Gwpu7U3Fxqjhb86ZDzLy(yy42JUqszVIO89i,eesaHQO5yPGNvopTtWzR,SSGEc76fBan2)
	elif lOH3hXsnQiFCRjbN12==549: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(yy42JUqszVIO89i)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder','بحث جديد','',549)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	EOMV1CcfRrldPiJsQ0 = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'dict','GLOBALSEARCH_SITES')
	if EOMV1CcfRrldPiJsQ0:
		EOMV1CcfRrldPiJsQ0 = EOMV1CcfRrldPiJsQ0['__SEQUENCED_COLUMNS__']
		for c1qUnGRSoEZPefVhWv in reversed(EOMV1CcfRrldPiJsQ0):
			UZ8LYnm5jsl9uKM0xDX('folder',c1qUnGRSoEZPefVhWv,'',549,'','',c1qUnGRSoEZPefVhWv)
	return
def kV5Wue06vFixocBhPIZY9z(c1qUnGRSoEZPefVhWv):
	if not c1qUnGRSoEZPefVhWv:
		c1qUnGRSoEZPefVhWv = ymH9jzg2KId5MCvw8lXBZn()
		if not c1qUnGRSoEZPefVhWv: return
		c1qUnGRSoEZPefVhWv = c1qUnGRSoEZPefVhWv.lower()
	IPmuvN2LSdO9nlHw = c1qUnGRSoEZPefVhWv.replace(ToYWiIbruzUaNKRPZLG16cAj,'')
	DDQZMpTobV5trFIALHfz7l(IPmuvN2LSdO9nlHw)
	UZ8LYnm5jsl9uKM0xDX('link','عمل بحث جماعي - '+IPmuvN2LSdO9nlHw,'search_sites',542,'','',IPmuvN2LSdO9nlHw)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder','نتائج البحث مفصلة - '+IPmuvN2LSdO9nlHw,'opened_sites',542,'','',IPmuvN2LSdO9nlHw)
	UZ8LYnm5jsl9uKM0xDX('folder','نتائج البحث مقسمة - '+IPmuvN2LSdO9nlHw,'listed_sites',542,'','',IPmuvN2LSdO9nlHw)
	UZ8LYnm5jsl9uKM0xDX('folder','بحث منفرد - '+IPmuvN2LSdO9nlHw,'',541,'','',IPmuvN2LSdO9nlHw)
	return
def DDQZMpTobV5trFIALHfz7l(osZrq1zQJYhO5ji2Dd):
	WjQYCcg8he = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_SITES',osZrq1zQJYhO5ji2Dd)
	FdXYwvKNML7zQ = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_SITES',ToYWiIbruzUaNKRPZLG16cAj+osZrq1zQJYhO5ji2Dd)
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES',osZrq1zQJYhO5ji2Dd)
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES',ToYWiIbruzUaNKRPZLG16cAj+osZrq1zQJYhO5ji2Dd)
	WiZ8TD1tUmCSvreIc = WjQYCcg8he+FdXYwvKNML7zQ
	if WiZ8TD1tUmCSvreIc: osZrq1zQJYhO5ji2Dd = ToYWiIbruzUaNKRPZLG16cAj+osZrq1zQJYhO5ji2Dd
	F4QxJHhsMj(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES',osZrq1zQJYhO5ji2Dd,WiZ8TD1tUmCSvreIc,wwSaAipunqYIgcH)
	return
def A5wDbNlaCi2():
	svOyXbipkwY = nEYJ5OCXG0gcNy('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if svOyXbipkwY!=1: return
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES')
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_OPENED')
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_CLOSED')
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def dPCS1Rv5Gwpu7U3Fxqjhb86ZDzLy(jjsvZzyUKYHrt,uzPIslCpEXAe4w136Q9o2JbtaULD,yPRGDCnXhJbwYalz7fZepiUcA=''):
	UUducs3QwfS6LPopqyj9Nmln,IEmrdsaQ80yUiP9Jcobh,ZutnrpAwOqTE3dGXvC6K2QW7eDgsI,OizkrTUY28hvH4dP6VMwF7qyj5,jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw,ZYKD9uOVjg8zRI,D5MxEsKl0LzogT3VAX8JYdiSI1tjF9 = [],[],[],{},{},{},{}
	if uzPIslCpEXAe4w136Q9o2JbtaULD!='search_sites':
		if uzPIslCpEXAe4w136Q9o2JbtaULD=='listed_sites': ZutnrpAwOqTE3dGXvC6K2QW7eDgsI = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_SITES',ToYWiIbruzUaNKRPZLG16cAj+jjsvZzyUKYHrt)
		elif uzPIslCpEXAe4w136Q9o2JbtaULD=='opened_sites': ZutnrpAwOqTE3dGXvC6K2QW7eDgsI = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_OPENED',jjsvZzyUKYHrt)
		elif uzPIslCpEXAe4w136Q9o2JbtaULD=='closed_sites': ZutnrpAwOqTE3dGXvC6K2QW7eDgsI = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_CLOSED',(yPRGDCnXhJbwYalz7fZepiUcA,jjsvZzyUKYHrt))
	if not ZutnrpAwOqTE3dGXvC6K2QW7eDgsI:
		Bro7jZXa2qAFulQW9IkPL = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		yQMg7VfFNB4l9UcpqiX = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+jjsvZzyUKYHrt+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if uzPIslCpEXAe4w136Q9o2JbtaULD=='search_sites': QQONb7aR2M6L = yQMg7VfFNB4l9UcpqiX
		else: QQONb7aR2M6L = Bro7jZXa2qAFulQW9IkPL+yQMg7VfFNB4l9UcpqiX
		svOyXbipkwY = nEYJ5OCXG0gcNy('','','','رسالة من المبرمج',QQONb7aR2M6L)
		if svOyXbipkwY!=1: return
		PPEIqwl1Hk7nJKre(False,False,False)
		xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Search For: [ '+jjsvZzyUKYHrt+' ]')
		jWP8faReSHxQZLhlF9s4IDVKO = 1
		for yPRGDCnXhJbwYalz7fZepiUcA in ScedY1IpRnvosT9xJwD:
			OizkrTUY28hvH4dP6VMwF7qyj5[yPRGDCnXhJbwYalz7fZepiUcA] = []
			TZKIYEDaF04ohvjrn = '_NODIALOGS_'
			if '-' in yPRGDCnXhJbwYalz7fZepiUcA: TZKIYEDaF04ohvjrn = TZKIYEDaF04ohvjrn+'_REMEMBERRESULTS__'+yPRGDCnXhJbwYalz7fZepiUcA+'_'
			Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd = YfxSMg0mF9ZkoBthUHs3Rz6CaeO(yPRGDCnXhJbwYalz7fZepiUcA)
			if jWP8faReSHxQZLhlF9s4IDVKO:
				p1BoraOuWL.sleep(0.5)
				D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[yPRGDCnXhJbwYalz7fZepiUcA] = RrCB5k9XV6hYNSlIKJ2.Thread(target=RPSrjovJkFNiMEGOWIxUdu8lVp,args=(jjsvZzyUKYHrt+TZKIYEDaF04ohvjrn,))
				D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[yPRGDCnXhJbwYalz7fZepiUcA].start()
			else: RPSrjovJkFNiMEGOWIxUdu8lVp(jjsvZzyUKYHrt+TZKIYEDaF04ohvjrn)
			NCXj2ri3Unm6TFWIgwh(AFuJDPbZhS134etQfj(yPRGDCnXhJbwYalz7fZepiUcA),'',p1BoraOuWL=1000)
		if jWP8faReSHxQZLhlF9s4IDVKO:
			p1BoraOuWL.sleep(2)
			for yPRGDCnXhJbwYalz7fZepiUcA in ScedY1IpRnvosT9xJwD:
				D5MxEsKl0LzogT3VAX8JYdiSI1tjF9[yPRGDCnXhJbwYalz7fZepiUcA].join(10)
			p1BoraOuWL.sleep(2)
		for yPRGDCnXhJbwYalz7fZepiUcA in ScedY1IpRnvosT9xJwD:
			Nmq7bQ4yEIoaCM1u32hArxPkp,RPSrjovJkFNiMEGOWIxUdu8lVp,IlVzmjAwygYQeK1LC2qFd = YfxSMg0mF9ZkoBthUHs3Rz6CaeO(yPRGDCnXhJbwYalz7fZepiUcA)
			for hpnDbQ9u8ztEJ0fBaxv in nUTgq0SFfC9:
				jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = hpnDbQ9u8ztEJ0fBaxv
				if IlVzmjAwygYQeK1LC2qFd in CH3VkKb5LiB1cZUsoE:
					if 'IPTV-' in yPRGDCnXhJbwYalz7fZepiUcA and (239>=lOH3hXsnQiFCRjbN12>=230 or 289>=lOH3hXsnQiFCRjbN12>=280):
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['IPTV-LIVE']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['IPTV-MOVIES']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['IPTV-SERIES']: continue
						if 'صفحة' not in CH3VkKb5LiB1cZUsoE:
							if   jPqMvmNDgsYiWUyxo=='live': yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-LIVE'
							elif jPqMvmNDgsYiWUyxo=='video': yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-MOVIES'
							elif jPqMvmNDgsYiWUyxo=='folder': yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-SERIES'
						else:
							if   'LIVE' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-LIVE'
							elif 'MOVIES' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-MOVIES'
							elif 'SERIES' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'IPTV-SERIES'
					elif 'M3U-' in yPRGDCnXhJbwYalz7fZepiUcA and 729>=lOH3hXsnQiFCRjbN12>=710:
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['M3U-LIVE']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['M3U-MOVIES']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['M3U-SERIES']: continue
						if 'صفحة' not in CH3VkKb5LiB1cZUsoE:
							if   jPqMvmNDgsYiWUyxo=='live': yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-LIVE'
							elif jPqMvmNDgsYiWUyxo=='video': yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-MOVIES'
							elif jPqMvmNDgsYiWUyxo=='folder': yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-SERIES'
						else:
							if   'LIVE' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-LIVE'
							elif 'MOVIES' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-MOVIES'
							elif 'SERIES' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'M3U-SERIES'
					elif 'YOUTUBE-' in yPRGDCnXhJbwYalz7fZepiUcA and 149>=lOH3hXsnQiFCRjbN12>=140:
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['YOUTUBE-CHANNELS']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['YOUTUBE-PLAYLISTS']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in CH3VkKb5LiB1cZUsoE or ':: ' in CH3VkKb5LiB1cZUsoE:
							continue
						else:
							if   lOH3hXsnQiFCRjbN12==144 and 'USER' in CH3VkKb5LiB1cZUsoE: yPRGDCnXhJbwYalz7fZepiUcA = 'YOUTUBE-CHANNELS'
							elif lOH3hXsnQiFCRjbN12==144 and 'CHNL' in CH3VkKb5LiB1cZUsoE: yPRGDCnXhJbwYalz7fZepiUcA = 'YOUTUBE-CHANNELS'
							elif lOH3hXsnQiFCRjbN12==144 and 'LIST' in CH3VkKb5LiB1cZUsoE: yPRGDCnXhJbwYalz7fZepiUcA = 'YOUTUBE-PLAYLISTS'
							elif lOH3hXsnQiFCRjbN12==143: yPRGDCnXhJbwYalz7fZepiUcA = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in yPRGDCnXhJbwYalz7fZepiUcA and 419>=lOH3hXsnQiFCRjbN12>=400:
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['DAILYMOTION-PLAYLISTS']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['DAILYMOTION-CHANNELS']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['DAILYMOTION-VIDEOS']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['DAILYMOTION-TOPICS']: continue
						if   lOH3hXsnQiFCRjbN12 in [401,405]: yPRGDCnXhJbwYalz7fZepiUcA = 'DAILYMOTION-PLAYLISTS'
						elif lOH3hXsnQiFCRjbN12 in [402,406]: yPRGDCnXhJbwYalz7fZepiUcA = 'DAILYMOTION-CHANNELS'
						elif lOH3hXsnQiFCRjbN12 in [404]: yPRGDCnXhJbwYalz7fZepiUcA = 'DAILYMOTION-VIDEOS'
						elif lOH3hXsnQiFCRjbN12 in [415]: yPRGDCnXhJbwYalz7fZepiUcA = 'DAILYMOTION-LIVES'
						elif lOH3hXsnQiFCRjbN12 in [412,413]: yPRGDCnXhJbwYalz7fZepiUcA = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in yPRGDCnXhJbwYalz7fZepiUcA and 39>=lOH3hXsnQiFCRjbN12>=30:
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['PANET-SERIES']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['PANET-MOVIES']: continue
						if   lOH3hXsnQiFCRjbN12 in [32,39]: yPRGDCnXhJbwYalz7fZepiUcA = 'PANET-SERIES'
						elif lOH3hXsnQiFCRjbN12 in [33,39]: yPRGDCnXhJbwYalz7fZepiUcA = 'PANET-MOVIES'
					elif 'IFILM-' in yPRGDCnXhJbwYalz7fZepiUcA and 29>=lOH3hXsnQiFCRjbN12>=20:
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['IFILM-ARABIC']: continue
						if hpnDbQ9u8ztEJ0fBaxv in OizkrTUY28hvH4dP6VMwF7qyj5['IFILM-ENGLISH']: continue
						if   '/ar.' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'IFILM-ARABIC'
						elif '/en.' in eesaHQO5yPGNvopTtWzR: yPRGDCnXhJbwYalz7fZepiUcA = 'IFILM-ENGLISH'
					OizkrTUY28hvH4dP6VMwF7qyj5[yPRGDCnXhJbwYalz7fZepiUcA].append(hpnDbQ9u8ztEJ0fBaxv)
		nUTgq0SFfC9[:] = []
		for yPRGDCnXhJbwYalz7fZepiUcA in list(OizkrTUY28hvH4dP6VMwF7qyj5.keys()):
			jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw[yPRGDCnXhJbwYalz7fZepiUcA] = []
			ZYKD9uOVjg8zRI[yPRGDCnXhJbwYalz7fZepiUcA] = []
			for jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in OizkrTUY28hvH4dP6VMwF7qyj5[yPRGDCnXhJbwYalz7fZepiUcA]:
				hpnDbQ9u8ztEJ0fBaxv = (jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
				if 'صفحة' in CH3VkKb5LiB1cZUsoE and jPqMvmNDgsYiWUyxo=='folder': ZYKD9uOVjg8zRI[yPRGDCnXhJbwYalz7fZepiUcA].append(hpnDbQ9u8ztEJ0fBaxv)
				else: jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw[yPRGDCnXhJbwYalz7fZepiUcA].append(hpnDbQ9u8ztEJ0fBaxv)
		Zi0zeQAtDrfRB3v = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for yPRGDCnXhJbwYalz7fZepiUcA in yhwiz64qkKYO5:
			if yPRGDCnXhJbwYalz7fZepiUcA==dHw8OxjqMKbTNVZrtvofy4RC[0]: Zi0zeQAtDrfRB3v = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif yPRGDCnXhJbwYalz7fZepiUcA==LZKTCp21UVlbDQiH7s9xRj3[0]: Zi0zeQAtDrfRB3v = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif yPRGDCnXhJbwYalz7fZepiUcA==EctWpi0OkMgIHX[0]: Zi0zeQAtDrfRB3v = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if yPRGDCnXhJbwYalz7fZepiUcA not in jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw.keys(): continue
			if jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw[yPRGDCnXhJbwYalz7fZepiUcA]:
				Z7X5IUC1Ks = AFuJDPbZhS134etQfj(yPRGDCnXhJbwYalz7fZepiUcA)
				onEu7jNAZrL = [('link','[COLOR FFFFFF00]===== '+Z7X5IUC1Ks+' =====[/COLOR]','',9999,'','','','','')]
				if 0: YrUMgiPQSfXc8JWsOIa9 = jjsvZzyUKYHrt+' - '+'بحث'+' '+Z7X5IUC1Ks
				else: YrUMgiPQSfXc8JWsOIa9 = 'بحث'+' '+Z7X5IUC1Ks+' - '+jjsvZzyUKYHrt
				if len(jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw[yPRGDCnXhJbwYalz7fZepiUcA])<8: yUWpMEuA8F = []
				else:
					shMyTJbtHoz = '[COLOR FFC89008]'+YrUMgiPQSfXc8JWsOIa9+'[/COLOR]'
					yUWpMEuA8F = [('folder',ToYWiIbruzUaNKRPZLG16cAj+shMyTJbtHoz,'closed_sites',542,'',yPRGDCnXhJbwYalz7fZepiUcA,jjsvZzyUKYHrt,'','')]
				smJ3bLBg76nycqevGApX9OKY5 = jZLhSlit3uRvpDdAC0Fq9eU2Q68Bcw[yPRGDCnXhJbwYalz7fZepiUcA]+ZYKD9uOVjg8zRI[yPRGDCnXhJbwYalz7fZepiUcA]
				IEmrdsaQ80yUiP9Jcobh += Zi0zeQAtDrfRB3v+onEu7jNAZrL+smJ3bLBg76nycqevGApX9OKY5[:7]+yUWpMEuA8F
				Bd4YP7ej1mNgWDtCETsKhAcrwG = [('folder',ToYWiIbruzUaNKRPZLG16cAj+YrUMgiPQSfXc8JWsOIa9,'closed_sites',542,'',yPRGDCnXhJbwYalz7fZepiUcA,jjsvZzyUKYHrt,'','')]
				UUducs3QwfS6LPopqyj9Nmln += Zi0zeQAtDrfRB3v+Bd4YP7ej1mNgWDtCETsKhAcrwG
				Zi0zeQAtDrfRB3v = []
				F4QxJHhsMj(qQ4BC6vW5YOfo,'GLOBALSEARCH_CLOSED',(yPRGDCnXhJbwYalz7fZepiUcA,jjsvZzyUKYHrt),smJ3bLBg76nycqevGApX9OKY5,wwSaAipunqYIgcH)
		F4QxJHhsMj(qQ4BC6vW5YOfo,'GLOBALSEARCH_OPENED',jjsvZzyUKYHrt,IEmrdsaQ80yUiP9Jcobh,wwSaAipunqYIgcH)
		ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES',jjsvZzyUKYHrt)
		F4QxJHhsMj(qQ4BC6vW5YOfo,'GLOBALSEARCH_SITES',ToYWiIbruzUaNKRPZLG16cAj+jjsvZzyUKYHrt,UUducs3QwfS6LPopqyj9Nmln,wwSaAipunqYIgcH)
		ztgqWUaDpe8CE9N('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if uzPIslCpEXAe4w136Q9o2JbtaULD=='listed_sites' and UUducs3QwfS6LPopqyj9Nmln: ZutnrpAwOqTE3dGXvC6K2QW7eDgsI = UUducs3QwfS6LPopqyj9Nmln
		else: ZutnrpAwOqTE3dGXvC6K2QW7eDgsI = IEmrdsaQ80yUiP9Jcobh
	if uzPIslCpEXAe4w136Q9o2JbtaULD!='search_sites':
		for jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk in ZutnrpAwOqTE3dGXvC6K2QW7eDgsI:
			if uzPIslCpEXAe4w136Q9o2JbtaULD in ['listed_sites','opened_sites'] and 'صفحة' in CH3VkKb5LiB1cZUsoE and jPqMvmNDgsYiWUyxo=='folder': continue
			UZ8LYnm5jsl9uKM0xDX(jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,yy42JUqszVIO89i,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk)
	PPEIqwl1Hk7nJKre('','','')
	return
def xm63IuzheTZc(jjsvZzyUKYHrt=''):
	c1qUnGRSoEZPefVhWv,TZKIYEDaF04ohvjrn,showDialogs = Xj2G0VZ876Idy(jjsvZzyUKYHrt)
	if not c1qUnGRSoEZPefVhWv:
		c1qUnGRSoEZPefVhWv = ymH9jzg2KId5MCvw8lXBZn()
		if not c1qUnGRSoEZPefVhWv: return
		c1qUnGRSoEZPefVhWv = c1qUnGRSoEZPefVhWv.lower()
	xrFqGMab4uLKZcS('NOTICE',zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+'   Search For: [ '+c1qUnGRSoEZPefVhWv+' ]')
	u9DhgpinLBfmjG3NtMalq7Y = c1qUnGRSoEZPefVhWv+TZKIYEDaF04ohvjrn
	if 0: zc27ZDlNYj0BF5xfnk,IPmuvN2LSdO9nlHw = c1qUnGRSoEZPefVhWv+' - ',''
	else: zc27ZDlNYj0BF5xfnk,IPmuvN2LSdO9nlHw = '',' - '+c1qUnGRSoEZPefVhWv
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	UZ8LYnm5jsl9uKM0xDX('folder','_M3U_'+zc27ZDlNYj0BF5xfnk+'بحث M3U'+IPmuvN2LSdO9nlHw,'',719,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_IPT_'+zc27ZDlNYj0BF5xfnk+'بحث IPTV'+IPmuvN2LSdO9nlHw,'',239,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_BKR_'+zc27ZDlNYj0BF5xfnk+'بحث موقع بكرا'+IPmuvN2LSdO9nlHw,'',379,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_KLA_'+zc27ZDlNYj0BF5xfnk+'بحث موقع كل العرب'+IPmuvN2LSdO9nlHw,'',19,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_ART_'+zc27ZDlNYj0BF5xfnk+'بحث موقع تونز عربية'+IPmuvN2LSdO9nlHw,'',739,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_KRB_'+zc27ZDlNYj0BF5xfnk+'بحث موقع قناة كربلاء'+IPmuvN2LSdO9nlHw,'',329,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_FH1_'+zc27ZDlNYj0BF5xfnk+'بحث موقع فاصل الأول'+IPmuvN2LSdO9nlHw,'',579,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_KTV_'+zc27ZDlNYj0BF5xfnk+'بحث موقع كتكوت تيفي'+IPmuvN2LSdO9nlHw,'',819,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_EB1_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ايجي بيست 1'+IPmuvN2LSdO9nlHw,'',779,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_EB2_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ايجي بيست 2'+IPmuvN2LSdO9nlHw,'',789,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_IFL_'+zc27ZDlNYj0BF5xfnk+'  بحث موقع قناة آي فيلم'+IPmuvN2LSdO9nlHw+'  ','',29,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_AKO_'+zc27ZDlNYj0BF5xfnk+'بحث موقع أكوام القديم'+IPmuvN2LSdO9nlHw,'',79,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_AKW_'+zc27ZDlNYj0BF5xfnk+'بحث موقع أكوام الجديد'+IPmuvN2LSdO9nlHw,'',249,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_MRF_'+zc27ZDlNYj0BF5xfnk+'بحث موقع قناة المعارف'+IPmuvN2LSdO9nlHw,'',49,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_SHM_'+zc27ZDlNYj0BF5xfnk+'بحث موقع شوف ماكس'+IPmuvN2LSdO9nlHw,'',59,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	UZ8LYnm5jsl9uKM0xDX('folder','_FJS_'+zc27ZDlNYj0BF5xfnk+' بحث موقع فجر شو'+IPmuvN2LSdO9nlHw+' ','',399,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_TVF_'+zc27ZDlNYj0BF5xfnk+'بحث موقع تيفي فان'+IPmuvN2LSdO9nlHw,'',469,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_LDN_'+zc27ZDlNYj0BF5xfnk+'بحث موقع لودي نت'+IPmuvN2LSdO9nlHw,'',459,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_CMN_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما ناو'+IPmuvN2LSdO9nlHw,'',309,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_WCM_'+zc27ZDlNYj0BF5xfnk+'بحث موقع وي سيما'+IPmuvN2LSdO9nlHw,'',569,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_SHN_'+zc27ZDlNYj0BF5xfnk+'بحث موقع شاهد نيوز'+IPmuvN2LSdO9nlHw,'',589,'','',u9DhgpinLBfmjG3NtMalq7Y+'_NODIALOGS_')
	UZ8LYnm5jsl9uKM0xDX('folder','_ARS_'+zc27ZDlNYj0BF5xfnk+'بحث موقع عرب سييد'+IPmuvN2LSdO9nlHw,'',259,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_CCB_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما كلوب'+IPmuvN2LSdO9nlHw,'',829,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_SH4_'+zc27ZDlNYj0BF5xfnk+'بحث موقع شاهد فوريو'+IPmuvN2LSdO9nlHw,'',119,'','',u9DhgpinLBfmjG3NtMalq7Y+'_NODIALOGS_')
	UZ8LYnm5jsl9uKM0xDX('folder','_SHT_'+zc27ZDlNYj0BF5xfnk+'بحث موقع شوفها تيفي'+IPmuvN2LSdO9nlHw,'',649,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_EB3_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ايجي بيست 3'+IPmuvN2LSdO9nlHw,'',799,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	UZ8LYnm5jsl9uKM0xDX('folder','_FST_'+zc27ZDlNYj0BF5xfnk+'بحث موقع فوستا'+IPmuvN2LSdO9nlHw,'',609,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_FBK_'+zc27ZDlNYj0BF5xfnk+'بحث موقع فبركة'+IPmuvN2LSdO9nlHw,'',629,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_YQT_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ياقوت'+IPmuvN2LSdO9nlHw,'',669,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_BRS_'+zc27ZDlNYj0BF5xfnk+'بحث موقع برستيج'+IPmuvN2LSdO9nlHw,'',659,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_HLC_'+zc27ZDlNYj0BF5xfnk+'بحث موقع هلا سيما'+IPmuvN2LSdO9nlHw,'',89,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_DR7_'+zc27ZDlNYj0BF5xfnk+'بحث موقع دراما صح'+IPmuvN2LSdO9nlHw,'',689,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_CMF_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما فانز'+IPmuvN2LSdO9nlHw,'',99,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_CML_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما لايت'+IPmuvN2LSdO9nlHw,'',479,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_ABD_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما عبدو'+IPmuvN2LSdO9nlHw,'',559,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_C4H_'+zc27ZDlNYj0BF5xfnk+'بحث موقع سيما 400'+IPmuvN2LSdO9nlHw,'',699,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_AHK_'+zc27ZDlNYj0BF5xfnk+'بحث موقع أهواك تيفي'+IPmuvN2LSdO9nlHw,'',619,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_EB4_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ايجي بيست 4'+IPmuvN2LSdO9nlHw,'',809,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	UZ8LYnm5jsl9uKM0xDX('folder','_YUT_'+zc27ZDlNYj0BF5xfnk+'بحث موقع يوتيوب'+IPmuvN2LSdO9nlHw,'',149,'','',u9DhgpinLBfmjG3NtMalq7Y)
	UZ8LYnm5jsl9uKM0xDX('folder','_DLM_'+zc27ZDlNYj0BF5xfnk+'بحث موقع ديلي موشن'+IPmuvN2LSdO9nlHw,'',409,'','',u9DhgpinLBfmjG3NtMalq7Y)
	return
# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'FAJERSHOW'
ToYWiIbruzUaNKRPZLG16cAj = '_FJS_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==390: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==391: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==392: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==393: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==399: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','FAJERSHOW-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('<header>.*?<h2>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for XBMyFqAriL in range(len(items)):
		title = items[XBMyFqAriL]
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,aaeRjxiYcqOI6Sf8,391,'','','latest'+str(XBMyFqAriL))
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مختارات عشوائية',aaeRjxiYcqOI6Sf8,391,'','','randoms')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أعلى الأفلام تقييماً',aaeRjxiYcqOI6Sf8,391,'','','top_imdb_movies')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أعلى المسلسلات تقييماً',aaeRjxiYcqOI6Sf8,391,'','','top_imdb_series')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أفلام مميزة',aaeRjxiYcqOI6Sf8+'/movies',391,'','','featured_movies')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات مميزة',aaeRjxiYcqOI6Sf8+'/tvshows',391,'','','featured_tvshows')
	L0Uwx52bTBM = ''
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu"(.*?)id="contenedor"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM += pDTlIgyewF1XV69R8kd[0]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8+'/movies','','','','','FAJERSHOW-MENU-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="releases"(.*?)aside',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM += pDTlIgyewF1XV69R8kd[0]
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	Q9yuovbz1BXVkdm = True
	for ZcAK0askvzIWr4R,title in items:
		title = dCFP41Kxv9j8EHM(title)
		if title=='الأعلى مشاهدة':
			if Q9yuovbz1BXVkdm:
				title = 'الافلام '+title
				Q9yuovbz1BXVkdm = False
			else: title = 'المسلسلات '+title
		if title not in C1pRb6K8Qs:
			if title=='أفلام': UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,aaeRjxiYcqOI6Sf8+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,aaeRjxiYcqOI6Sf8+'/tvshows',391,'','','all_movies_tvshows')
			else: UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,391)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type):
	L0Uwx52bTBM,items = [],[]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if type in ['featured_movies','featured_tvshows']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="content"(.*?)id="archive-content"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif type=='all_movies_tvshows':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="archive-content"(.*?)class="pagination"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	elif type=='top_imdb_movies':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='top_imdb_series':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("class='top-imdb-list tright(.*?)footer",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='search':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="search-page"(.*?)class="sidebar',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='sider':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="widget(.*?)class="widget',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		XTPzvZdUymK2axoEu8W73BjMcheQf = SomeI8i56FaDMGPE.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		aFyREdMQk7Ys95rX6uJieDGLS2,rJGefkS38DKoi7HIx26P,r79xJG6jXHD = zip(*XTPzvZdUymK2axoEu8W73BjMcheQf)
		items = zip(rJGefkS38DKoi7HIx26P,aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD)
	elif type=='randoms':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="slider-movies-tvshows"(.*?)<header>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif 'latest' in type:
		XBMyFqAriL = int(type[-1:])
		BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('<header>','<end><start>')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('</div></div></div>','</div></div></div><end>')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<start>(.*?)<end>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[XBMyFqAriL]
		if XBMyFqAriL==6:
			XTPzvZdUymK2axoEu8W73BjMcheQf = SomeI8i56FaDMGPE.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			rJGefkS38DKoi7HIx26P,r79xJG6jXHD,aFyREdMQk7Ys95rX6uJieDGLS2 = zip(*XTPzvZdUymK2axoEu8W73BjMcheQf)
			items = zip(rJGefkS38DKoi7HIx26P,aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="content"(.*?)class="(pagination|sidebar)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][0]
			if '/collection/' in url:
				items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			elif '/quality/' in url:
				items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items and L0Uwx52bTBM:
		items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = SomeI8i56FaDMGPE.findall('^(.*?)<.*?serie">(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
			title = title[0][1]
			if title in oojL40IJtK: continue
			oojL40IJtK.append(title)
			title = '_MOD_'+title
		U2iQmHMJzoNkjORTGY7c51vZ = SomeI8i56FaDMGPE.findall('^(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
		if U2iQmHMJzoNkjORTGY7c51vZ: title = U2iQmHMJzoNkjORTGY7c51vZ[0]
		title = dCFP41Kxv9j8EHM(title)
		if '/tvshows/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,393,pjMZ802XQCSxYVk)
		elif '/episodes/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,393,pjMZ802XQCSxYVk)
		elif '/seasons/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,393,pjMZ802XQCSxYVk)
		elif '/collection/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,391,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,392,pjMZ802XQCSxYVk)
	if type not in ['featured_movies','featured_tvshows']:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,391,'','',type)
	return
def ooLCwrlF3n0vBjpA(url):
	FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(url,'url')
	url = url.replace(FglT5H2faVGm6IqpcXS9vQsojPLu,aaeRjxiYcqOI6Sf8)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('class="C rated".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<ul class="episodios">(.*?)</ul></div></div></div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,392,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = Gtm9xLq6A5YoceJfb3P(jj0C6IlvPFh,'GET',url,'','','FAJERSHOW-PLAY-1st')
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('class="C rated".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][0]
		items = SomeI8i56FaDMGPE.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for type,QumF9ZVCakY4d1KSzqgDyT3EBoX,zzSyv3A715Wplbxf8oGLwhCT,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+QumF9ZVCakY4d1KSzqgDyT3EBoX+'&nume='+zzSyv3A715Wplbxf8oGLwhCT+'&type='+type
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,AfejZJoKh4D7k5G1P9gCwxTz,bjPvhSAfNTOJWk2yCMt1xasVYFr9 in items:
			if '=' in pjMZ802XQCSxYVk:
				yIS3kMN0pU = pjMZ802XQCSxYVk.split('=')[1]
				title = DRom9hFTZXKuvfr2(yIS3kMN0pU,'host')
			else: title = ''
			title = bjPvhSAfNTOJWk2yCMt1xasVYFr9+' '+title
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download____'+AfejZJoKh4D7k5G1P9gCwxTz
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/?s='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
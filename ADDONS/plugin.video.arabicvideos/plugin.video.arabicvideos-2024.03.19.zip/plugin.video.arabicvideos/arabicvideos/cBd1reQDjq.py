# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ALARAB'
headers = {'User-Agent':''}
ToYWiIbruzUaNKRPZLG16cAj = '_KLA_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==10: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==11: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==12: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==13: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==14: rr60PDpqbMehZsYVuHmiAtN = DrWQf8PNSAwocLyKviszal()
	elif mode==15: rr60PDpqbMehZsYVuHmiAtN = eMQd1ziwnFNAXWJ()
	elif mode==16: rr60PDpqbMehZsYVuHmiAtN = nnjBJE4CsNPMHq1ze7lKYRcVUIpQy()
	elif mode==19: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'آخر الإضافات','',14)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان','',15)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','ALARAB-MENU-1st')
	pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('id="nav-slider"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	ssxb90MPAkSu7TyVHYqplEfXv = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',ssxb90MPAkSu7TyVHYqplEfXv,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
		title = title.strip(' ')
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,11)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="navbar"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	K1KV5U7JFXNPsl4h0HBd = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',K1KV5U7JFXNPsl4h0HBd,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,11)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def eMQd1ziwnFNAXWJ():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'جميع المسلسلات العربية',aaeRjxiYcqOI6Sf8+'/view-8/مسلسلات-عربية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات السنة الأخيرة','',16)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان الأخيرة 1',aaeRjxiYcqOI6Sf8+'/view-8/مسلسلات-رمضان-2022',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان الأخيرة 2',aaeRjxiYcqOI6Sf8+'/view-8/مسلسلات-رمضان-2023',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2023',aaeRjxiYcqOI6Sf8+'/ramadan2023/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2022',aaeRjxiYcqOI6Sf8+'/ramadan2022/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2021',aaeRjxiYcqOI6Sf8+'/ramadan2021/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2020',aaeRjxiYcqOI6Sf8+'/ramadan2020/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2019',aaeRjxiYcqOI6Sf8+'/ramadan2019/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2018',aaeRjxiYcqOI6Sf8+'/ramadan2018/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2017',aaeRjxiYcqOI6Sf8+'/ramadan2017/مصرية',11)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات رمضان 2016',aaeRjxiYcqOI6Sf8+'/ramadan2016/مصرية',11)
	return
def DrWQf8PNSAwocLyKviszal():
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,aaeRjxiYcqOI6Sf8,'',headers,True,'ALARAB-LATEST-1st')
	pDTlIgyewF1XV69R8kd=SomeI8i56FaDMGPE.findall('heading-top(.*?)div class=',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]+pDTlIgyewF1XV69R8kd[1]
	items=SomeI8i56FaDMGPE.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		url = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
		if 'series' in url: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,11,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,12,pjMZ802XQCSxYVk)
	return
def KKlnDcetq8Rrp3GY0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('video-category(.*?)right_content',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not pDTlIgyewF1XV69R8kd: return
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	y10vlPSzDYb2BA6HJhi = False
	items = SomeI8i56FaDMGPE.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK,Xg49o5xrDRbMw0 = [],[]
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		if title=='': title = ZcAK0askvzIWr4R.split('/')[-1].replace('-',' ')
		Ydt0oPpx4QAj = SomeI8i56FaDMGPE.findall('(\d+)',title,SomeI8i56FaDMGPE.DOTALL)
		if Ydt0oPpx4QAj: Ydt0oPpx4QAj = int(Ydt0oPpx4QAj[0])
		else: Ydt0oPpx4QAj = 0
		Xg49o5xrDRbMw0.append([pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title,Ydt0oPpx4QAj])
	Xg49o5xrDRbMw0 = sorted(Xg49o5xrDRbMw0, reverse=True, key=lambda key: key[3])
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title,Ydt0oPpx4QAj in Xg49o5xrDRbMw0:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		U2iQmHMJzoNkjORTGY7c51vZ = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if iHPhR4wCQ1oINaL: U2iQmHMJzoNkjORTGY7c51vZ = iHPhR4wCQ1oINaL[0]
		if U2iQmHMJzoNkjORTGY7c51vZ not in oojL40IJtK:
			oojL40IJtK.append(U2iQmHMJzoNkjORTGY7c51vZ)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+U2iQmHMJzoNkjORTGY7c51vZ,ZcAK0askvzIWr4R,13,pjMZ802XQCSxYVk)
				y10vlPSzDYb2BA6HJhi = True
			elif 'series' in ZcAK0askvzIWr4R:
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,11,pjMZ802XQCSxYVk)
				y10vlPSzDYb2BA6HJhi = True
			else:
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,12,pjMZ802XQCSxYVk)
				y10vlPSzDYb2BA6HJhi = True
	if y10vlPSzDYb2BA6HJhi:
		items = SomeI8i56FaDMGPE.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,SSGEc76fBan2 in items:
			url = aaeRjxiYcqOI6Sf8 + ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+SSGEc76fBan2,url,11)
	return
def ooLCwrlF3n0vBjpA(url):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,True,'ALARAB-EPISODES-1st')
	wYVpAWjH3EiLDzyaO = SomeI8i56FaDMGPE.findall('href="(/series.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	vfIB6ib8q1hFX5GweRrVPNTjY2E = aaeRjxiYcqOI6Sf8+wYVpAWjH3EiLDzyaO[0]
	rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(sJF0ga5tzvlRZWK3Xb9,url,'',headers,True,'ALARAB-PLAY-1st')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('class="resp-iframe" src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if vfIB6ib8q1hFX5GweRrVPNTjY2E:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('^(http.*?)(http.*?)$',vfIB6ib8q1hFX5GweRrVPNTjY2E,SomeI8i56FaDMGPE.DOTALL)
		if ZZHhmdtY1g:
			Q9yuovbz1BXVkdm = ZZHhmdtY1g[0][0]
			ktQXNcaUWHvGoh,WT3gDkPVsqNYZFtCh8vQS15iAuxL = ZZHhmdtY1g[0][1].rsplit('/',1)
			XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = ktQXNcaUWHvGoh+'?named=__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(XuItmjBhoUDa3fRO9nQsbNYrpG1cdv)
			jx63XqgpYedEM1lZ = Q9yuovbz1BXVkdm+WT3gDkPVsqNYZFtCh8vQS15iAuxL
		else:
			ppq6Bg4vPbVs = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,False,'ALARAB-PLAY-2nd')
			vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('"src": "(.*?)"',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
			if vfIB6ib8q1hFX5GweRrVPNTjY2E:
				vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]+'?named=__watch__m3u8'
				aFyREdMQk7Ys95rX6uJieDGLS2.append(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('searchBox(.*?)<style>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if vfIB6ib8q1hFX5GweRrVPNTjY2E:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[0]+'?named=__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(vfIB6ib8q1hFX5GweRrVPNTjY2E)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def nnjBJE4CsNPMHq1ze7lKYRcVUIpQy():
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,True,'ALARAB-RAMADAN-1st')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="content_sec"(.*?)id="left_content"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	OUuPxTyYtZdzLDskQWV = SomeI8i56FaDMGPE.findall('/ramadan([0-9]+)/',str(items),SomeI8i56FaDMGPE.DOTALL)
	OUuPxTyYtZdzLDskQWV = OUuPxTyYtZdzLDskQWV[0]
	for ZcAK0askvzIWr4R,title in items:
		url = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
		title = title.strip(' ')+' '+OUuPxTyYtZdzLDskQWV
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,url,11)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	u9DhgpinLBfmjG3NtMalq7Y = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8 + "/q/" + u9DhgpinLBfmjG3NtMalq7Y
	rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	return
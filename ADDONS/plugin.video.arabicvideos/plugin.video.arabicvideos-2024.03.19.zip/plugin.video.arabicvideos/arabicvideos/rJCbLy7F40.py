# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'MOVS4U'
ToYWiIbruzUaNKRPZLG16cAj = '_M4U_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['انواع افلام','جودات افلام']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==380: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==381: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==382: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==383: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==389: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'المميزة',aaeRjxiYcqOI6Sf8,381,'','','featured')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الجانبية',aaeRjxiYcqOI6Sf8,381,'','','sider')
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','MOVS4U-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('<header>.*?<h2>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for XBMyFqAriL in range(len(items)):
		title = items[XBMyFqAriL]
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,aaeRjxiYcqOI6Sf8,381,'','','latest'+str(XBMyFqAriL))
	L0Uwx52bTBM = ''
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="menu"(.*?)id="contenedor"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM += pDTlIgyewF1XV69R8kd[0]
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="sidebar(.*?)aside',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd: L0Uwx52bTBM += pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Q9yuovbz1BXVkdm = True
	for ZcAK0askvzIWr4R,title in items:
		title = dCFP41Kxv9j8EHM(title)
		if title=='الأعلى مشاهدة':
			if Q9yuovbz1BXVkdm:
				title = 'الافلام '+title
				Q9yuovbz1BXVkdm = False
			else: title = 'المسلسلات '+title
		if title not in C1pRb6K8Qs:
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,381)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type):
	L0Uwx52bTBM,items = [],[]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','MOVS4U-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if type=='search':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="search-page"(.*?)class="sidebar',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif type=='sider':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="widget(.*?)class="widget',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		KsXHlQpFD4m08aT = SomeI8i56FaDMGPE.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		aFyREdMQk7Ys95rX6uJieDGLS2,rJGefkS38DKoi7HIx26P,r79xJG6jXHD = zip(*KsXHlQpFD4m08aT)
		items = zip(rJGefkS38DKoi7HIx26P,aFyREdMQk7Ys95rX6uJieDGLS2,r79xJG6jXHD)
	elif type=='featured':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('id="slider-movies-tvshows"(.*?)<header>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	elif 'latest' in type:
		XBMyFqAriL = int(type[-1:])
		BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('<header>','<end><start>')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('<div class="sidebar','<end><div class="sidebar')
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('<start>(.*?)<end>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[XBMyFqAriL]
		if XBMyFqAriL==2: items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="content"(.*?)class="(pagination|sidebar)',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][0]
			if '/collection/' in url:
				items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			elif '/quality/' in url:
				items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	if not items and L0Uwx52bTBM:
		items = SomeI8i56FaDMGPE.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		if 'serie' in title:
			title = SomeI8i56FaDMGPE.findall('^(.*?)<.*?serie">(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
			title = title[0][1]
			if title in oojL40IJtK: continue
			oojL40IJtK.append(title)
			title = '_MOD_'+title
		U2iQmHMJzoNkjORTGY7c51vZ = SomeI8i56FaDMGPE.findall('^(.*?)<',title,SomeI8i56FaDMGPE.DOTALL)
		if U2iQmHMJzoNkjORTGY7c51vZ: title = U2iQmHMJzoNkjORTGY7c51vZ[0]
		title = dCFP41Kxv9j8EHM(title)
		if '/tvshows/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,383,pjMZ802XQCSxYVk)
		elif '/episodes/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,383,pjMZ802XQCSxYVk)
		elif '/seasons/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,383,pjMZ802XQCSxYVk)
		elif '/collection/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,381,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,382,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		UUaIAkrsCjX5gEfd26o1nuOZPHmbtM = pDTlIgyewF1XV69R8kd[0][0]
		zzTCUJ5rgiq = pDTlIgyewF1XV69R8kd[0][1]
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][2]
		items = SomeI8i56FaDMGPE.findall("href='(.*?)'.*?>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if title=='' or title==zzTCUJ5rgiq: continue
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,381,'','',type)
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('/page/'+title+'/','/page/'+zzTCUJ5rgiq+'/')
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'اخر صفحة '+zzTCUJ5rgiq,ZcAK0askvzIWr4R,381,'','',type)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('class="C rated".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA,False):
		UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		vfIB6ib8q1hFX5GweRrVPNTjY2E = SomeI8i56FaDMGPE.findall('''class='item'><a href="(.*?)"''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if vfIB6ib8q1hFX5GweRrVPNTjY2E:
			vfIB6ib8q1hFX5GweRrVPNTjY2E = vfIB6ib8q1hFX5GweRrVPNTjY2E[1]
			ooLCwrlF3n0vBjpA(vfIB6ib8q1hFX5GweRrVPNTjY2E)
			return
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('''class='episodios'(.*?)id="cast"''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for pjMZ802XQCSxYVk,iHPhR4wCQ1oINaL,ZcAK0askvzIWr4R,name in items:
			title = iHPhR4wCQ1oINaL+' : '+name+' الحلقة'
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,382)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','MOVS4U-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	Wch421XkoTwA = SomeI8i56FaDMGPE.findall('class="C rated".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if Wch421XkoTwA and d0HtblNDaOnv4Py9QhkA5iS1omGI(HmvY29bj4dNgF7wZqr1lzkeQxiEasu,url,Wch421XkoTwA): return
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0][0]
		items = SomeI8i56FaDMGPE.findall("data-url='(.*?)'.*?class='server'>(.*?)<",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="remodal"(.*?)class="remodal-close"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+title+'__download'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	url = aaeRjxiYcqOI6Sf8+'/?s='+search
	KKlnDcetq8Rrp3GY0(url,'search')
	return
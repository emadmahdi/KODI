# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'TVFUN'
ToYWiIbruzUaNKRPZLG16cAj = '_TVF_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['بث مباشر']
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==460: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==461: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==462: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==463: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==469: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',aaeRjxiYcqOI6Sf8,'','','','','TVFUN-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"menu-btn"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in C1pRb6K8Qs: continue
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,461)
	return
def KKlnDcetq8Rrp3GY0(url,YGBW78utSU1gJ0pD=''):
	items = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','TVFUN-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="head-title"(.*?)id="footer"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		oojL40IJtK = []
		W2XL1cnGkuqaZx = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) الحلقة \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in W2XL1cnGkuqaZx):
				UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,462,pjMZ802XQCSxYVk)
			elif iHPhR4wCQ1oINaL and 'الحلقة' in title:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0]
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,463,pjMZ802XQCSxYVk)
					oojL40IJtK.append(title)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,463,pjMZ802XQCSxYVk)
	if YGBW78utSU1gJ0pD!='latest':
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('<a href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.strip(' ')
				if ZcAK0askvzIWr4R=="": continue
				if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
				if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,461)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','TVFUN-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="head-title"(.*?)id="footer"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,462,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.strip(' ')
			if ZcAK0askvzIWr4R=="": continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			if title!='': UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,463)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','TVFUN-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	yndFXYKLEheZToCO824WRAm35tBis = SomeI8i56FaDMGPE.findall('"embedUrl": "(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if yndFXYKLEheZToCO824WRAm35tBis:
		yndFXYKLEheZToCO824WRAm35tBis = yndFXYKLEheZToCO824WRAm35tBis[0]
		if 'http' not in yndFXYKLEheZToCO824WRAm35tBis:
			if '//' in yndFXYKLEheZToCO824WRAm35tBis: yndFXYKLEheZToCO824WRAm35tBis = 'http:'+yndFXYKLEheZToCO824WRAm35tBis
			else: yndFXYKLEheZToCO824WRAm35tBis = aaeRjxiYcqOI6Sf8+yndFXYKLEheZToCO824WRAm35tBis
		yndFXYKLEheZToCO824WRAm35tBis = yndFXYKLEheZToCO824WRAm35tBis+'?named=__embed'
		aFyREdMQk7Ys95rX6uJieDGLS2.append(yndFXYKLEheZToCO824WRAm35tBis)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('VideoServers"(.*?)"Play"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for YYDWUJxdrt,name in ZZHhmdtY1g:
			YYDWUJxdrt = YYDWUJxdrt[2:]
			if BhTAck1bPFYGuUqRW: YYDWUJxdrt = YYDWUJxdrt.decode('utf8')
			YYDWUJxdrt = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(YYDWUJxdrt)
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: YYDWUJxdrt = YYDWUJxdrt.decode('utf8')
			ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',YYDWUJxdrt,SomeI8i56FaDMGPE.DOTALL)
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
			if 'http' not in ZcAK0askvzIWr4R:
				if '//' in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = 'http:'+ZcAK0askvzIWr4R
				else: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'?named='+name+'__watch'
			aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	if ' ' in search:
		if showDialogs: ztgqWUaDpe8CE9N('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = aaeRjxiYcqOI6Sf8+'/q/'+search+'/'
	KKlnDcetq8Rrp3GY0(url)
	return
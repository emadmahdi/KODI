# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'LIVETV'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4['PYTHON'][0]
def GI13aCFr0qimdOT(mode,url):
	if   mode==100: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==101: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq('0',True)
	elif mode==102: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq('1',True)
	elif mode==103: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq('2',True)
	elif mode==104: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq('3',True)
	elif mode==105: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==106: rr60PDpqbMehZsYVuHmiAtN = rum8gIeCX3hYq('4',True)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	UZ8LYnm5jsl9uKM0xDX('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	UZ8LYnm5jsl9uKM0xDX('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	UZ8LYnm5jsl9uKM0xDX('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	UZ8LYnm5jsl9uKM0xDX('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	UZ8LYnm5jsl9uKM0xDX('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	UZ8LYnm5jsl9uKM0xDX('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	UZ8LYnm5jsl9uKM0xDX('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	UZ8LYnm5jsl9uKM0xDX('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	UZ8LYnm5jsl9uKM0xDX('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	UZ8LYnm5jsl9uKM0xDX('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def rum8gIeCX3hYq(hmedxznGXRHt1L,showDialogs=True):
	ToYWiIbruzUaNKRPZLG16cAj = '_TV'+hmedxznGXRHt1L+'_'
	OjIPm0do31CZ = vT7q0oj96p(32)
	P8AGL4xSd9rWD1Vz = {'id':'','user':OjIPm0do31CZ,'function':'list','menu':hmedxznGXRHt1L}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',aaeRjxiYcqOI6Sf8,P8AGL4xSd9rWD1Vz,'','','','LIVETV-ITEMS-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		for zz5ZOaoyATpS893tvdXE in range(len(items)):
			name = items[zz5ZOaoyATpS893tvdXE][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[zz5ZOaoyATpS893tvdXE] = items[zz5ZOaoyATpS893tvdXE][0],items[zz5ZOaoyATpS893tvdXE][1],items[zz5ZOaoyATpS893tvdXE][2],name,items[zz5ZOaoyATpS893tvdXE][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for ucGVEfRSBY,FglT5H2faVGm6IqpcXS9vQsojPLu,iBI9R4HkNw6pZvdqMtGTjnUEXulhxy,name,pjMZ802XQCSxYVk in items:
			if '#' in ucGVEfRSBY: continue
			if ucGVEfRSBY!='URL': name = name+'[COLOR FFC89008]   '+ucGVEfRSBY+'[/COLOR]'
			url = ucGVEfRSBY+';;'+FglT5H2faVGm6IqpcXS9vQsojPLu+';;'+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy+';;'+hmedxznGXRHt1L
			UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+''+name,url,105,pjMZ802XQCSxYVk)
	else:
		if showDialogs: UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(id):
	ucGVEfRSBY,FglT5H2faVGm6IqpcXS9vQsojPLu,iBI9R4HkNw6pZvdqMtGTjnUEXulhxy,hmedxznGXRHt1L = id.split(';;')
	url = ''
	OjIPm0do31CZ = vT7q0oj96p(32)
	if ucGVEfRSBY=='URL': url = iBI9R4HkNw6pZvdqMtGTjnUEXulhxy
	elif ucGVEfRSBY=='YOUTUBE':
		url = ZEgwHfRnFV4['YOUTUBE'][0]+'/watch?v='+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy
		import Y4ILyJBspQ
		Y4ILyJBspQ.vjr9310yigkK([url],HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'live',url)
		return
	elif ucGVEfRSBY=='GA':
		P8AGL4xSd9rWD1Vz = { 'id' : '', 'user' : OjIPm0do31CZ , 'function' : 'playGA1' , 'menu' : '' }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,P8AGL4xSd9rWD1Vz,'',False,'','LIVETV-PLAY-1st')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		cookies = ttpgqJBdkoxeKOcwaiP.cookies
		XIaUAzCwD0HqcNGWM7Jpn6l39vRo = cookies['ASP.NET_SessionId']
		url = ttpgqJBdkoxeKOcwaiP.headers['Location']
		P8AGL4xSd9rWD1Vz = { 'id' : iBI9R4HkNw6pZvdqMtGTjnUEXulhxy , 'user' : OjIPm0do31CZ , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+XIaUAzCwD0HqcNGWM7Jpn6l39vRo }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,P8AGL4xSd9rWD1Vz,headers,'','','LIVETV-PLAY-2nd')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		url = SomeI8i56FaDMGPE.findall('resp":"(http.*?m3u8)(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		ZcAK0askvzIWr4R = url[0][0]
		xxCrhZTnyoJjWEk6vBqLe1dzI = url[0][1]
		mvDQlUL87asM9cyferV = 'http://38.'+FglT5H2faVGm6IqpcXS9vQsojPLu+'777/'+iBI9R4HkNw6pZvdqMtGTjnUEXulhxy+'_HD.m3u8'+xxCrhZTnyoJjWEk6vBqLe1dzI
		czqeAdMGrhiVv6kyDWQt1lHNELf4a = mvDQlUL87asM9cyferV.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		qBC678KcAUM9bGmTsLnkR4pr0aN = mvDQlUL87asM9cyferV.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		r79xJG6jXHD = ['HD','SD1','SD2']
		aFyREdMQk7Ys95rX6uJieDGLS2 = [mvDQlUL87asM9cyferV,czqeAdMGrhiVv6kyDWQt1lHNELf4a,qBC678KcAUM9bGmTsLnkR4pr0aN]
		I7mfbGiWNFcBVJOn = 0
		if I7mfbGiWNFcBVJOn == -1: return
		else: url = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	elif ucGVEfRSBY=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		P8AGL4xSd9rWD1Vz = { 'id' : iBI9R4HkNw6pZvdqMtGTjnUEXulhxy , 'user' : OjIPm0do31CZ , 'function' : 'playNT' , 'menu' : hmedxznGXRHt1L }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST', aaeRjxiYcqOI6Sf8, P8AGL4xSd9rWD1Vz, headers, False,'','LIVETV-PLAY-3rd')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		url = ttpgqJBdkoxeKOcwaiP.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in iBI9R4HkNw6pZvdqMtGTjnUEXulhxy:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif ucGVEfRSBY=='PL':
		P8AGL4xSd9rWD1Vz = { 'id' : iBI9R4HkNw6pZvdqMtGTjnUEXulhxy , 'user' : OjIPm0do31CZ , 'function' : 'playPL' , 'menu' : hmedxznGXRHt1L }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST', aaeRjxiYcqOI6Sf8, P8AGL4xSd9rWD1Vz, '',False,'','LIVETV-PLAY-4th')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		url = ttpgqJBdkoxeKOcwaiP.headers['Location']
		headers = {'Referer':ttpgqJBdkoxeKOcwaiP.headers['Referer']}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		items = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		url = items[0]
	elif ucGVEfRSBY in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if ucGVEfRSBY=='TA': iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		P8AGL4xSd9rWD1Vz = { 'id' : iBI9R4HkNw6pZvdqMtGTjnUEXulhxy , 'user' : OjIPm0do31CZ , 'function' : 'play'+ucGVEfRSBY , 'menu' : hmedxznGXRHt1L }
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',aaeRjxiYcqOI6Sf8,P8AGL4xSd9rWD1Vz,headers,'','','LIVETV-PLAY-6th')
		if not ttpgqJBdkoxeKOcwaiP.succeeded:
			ztgqWUaDpe8CE9N('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		url = ttpgqJBdkoxeKOcwaiP.headers['Location']
		if ucGVEfRSBY=='FM':
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = ttpgqJBdkoxeKOcwaiP.headers['Location']
			url = url.replace('https','http')
	kFygcp2jqSUCiNRnur71xMZI96(url,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'live')
	return
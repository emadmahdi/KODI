# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
from PIL import ImageDraw as v0vrR8AL5UbCzsFQdlo,ImageFont as A63OvTSBM5xduK4m8yorhjPYqw,Image as Zm7N6Rv39POxEg8jQnpoKHzlD12G
from arabic_reshaper import ArabicReshaper as zzPFaJUs14uBk5RiSYL
AdKBOaFs5gt3RoNkwLj = 'EXCLUDES'
def o1sSQGH9gD6fknU(CH3VkKb5LiB1cZUsoE,zMjs2DygmKfUQkOb6):
	zMjs2DygmKfUQkOb6 = zMjs2DygmKfUQkOb6.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	VMfQiCctwUdX = SomeI8i56FaDMGPE.findall('[a-zA-Z]',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
	if 'بحث IPTV - ' in CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('بحث IPTV - ',spTWfEz2PU9AL+'بحث IPTV - '+spTWfEz2PU9AL)
	elif ' IPTV' in CH3VkKb5LiB1cZUsoE and zMjs2DygmKfUQkOb6=='IPT': CH3VkKb5LiB1cZUsoE = spTWfEz2PU9AL+CH3VkKb5LiB1cZUsoE
	elif 'بحث M3U - ' in CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('بحث M3U - ',spTWfEz2PU9AL+'بحث M3U - '+spTWfEz2PU9AL)
	elif ' M3U' in CH3VkKb5LiB1cZUsoE and zMjs2DygmKfUQkOb6=='M3U': CH3VkKb5LiB1cZUsoE = spTWfEz2PU9AL+CH3VkKb5LiB1cZUsoE
	elif 'بحث ' in CH3VkKb5LiB1cZUsoE and ' - ' in CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = spTWfEz2PU9AL+CH3VkKb5LiB1cZUsoE
	elif not VMfQiCctwUdX:
		YfTHoQjlaZ1LIg = SomeI8i56FaDMGPE.findall('^( *?)(.*?)( *?)$',CH3VkKb5LiB1cZUsoE)
		WHkv4cnYQpquzTGgiVt03N2BZsC,LbwtKPT2CWmSr6aMz19Jl0sIdgfA,K37cREDl4dzbkNJ = YfTHoQjlaZ1LIg[0]
		Leylj68ha3 = SomeI8i56FaDMGPE.findall('^([!-~])',LbwtKPT2CWmSr6aMz19Jl0sIdgfA)
		if Leylj68ha3: CH3VkKb5LiB1cZUsoE = WHkv4cnYQpquzTGgiVt03N2BZsC+H02Qqy4XO9L3Dui6S8PGWxJt+LbwtKPT2CWmSr6aMz19Jl0sIdgfA+K37cREDl4dzbkNJ
		else: CH3VkKb5LiB1cZUsoE = K37cREDl4dzbkNJ+spTWfEz2PU9AL+LbwtKPT2CWmSr6aMz19Jl0sIdgfA+WHkv4cnYQpquzTGgiVt03N2BZsC
	else:
		if 1:
			zL9B0AKZONueqVxSr81FbJHdyCft = CH3VkKb5LiB1cZUsoE
			KFkRm21pHT3WNSzgICV = Xpa41TEJ2Wl.get_display(CH3VkKb5LiB1cZUsoE,base_dir='L')
			if BhTAck1bPFYGuUqRW: zL9B0AKZONueqVxSr81FbJHdyCft = zL9B0AKZONueqVxSr81FbJHdyCft.decode('utf8')
			if BhTAck1bPFYGuUqRW: KFkRm21pHT3WNSzgICV = KFkRm21pHT3WNSzgICV.decode('utf8')
			TuWlRE6zCKDkhS8OPMmBF3A = zL9B0AKZONueqVxSr81FbJHdyCft.split(' ')
			GCrDnOv6zV4oE8y = KFkRm21pHT3WNSzgICV.split(' ')
			Kg7HrjqNob3YwIl65T,UDv4GYuOXwaSz6PFeAM3bTq8nr,CTHLVD3Scz0MZ24,WWmyDalKqAuOs05i43 = [],[],'',''
			SqZh30T47O6ro9Jk = zip(TuWlRE6zCKDkhS8OPMmBF3A,GCrDnOv6zV4oE8y)
			for rzgZ9Ajw2pHsLh,oyhp9frHNqjJWiAYVQk in SqZh30T47O6ro9Jk:
				if rzgZ9Ajw2pHsLh==oyhp9frHNqjJWiAYVQk=='' and WWmyDalKqAuOs05i43:
					CTHLVD3Scz0MZ24 += ' '
					continue
				if rzgZ9Ajw2pHsLh==oyhp9frHNqjJWiAYVQk:
					di8fwIJ3qEjT6zN7 = 'EN'
					if WWmyDalKqAuOs05i43==di8fwIJ3qEjT6zN7: CTHLVD3Scz0MZ24 += ' '+rzgZ9Ajw2pHsLh
					elif rzgZ9Ajw2pHsLh:
						if CTHLVD3Scz0MZ24:
							UDv4GYuOXwaSz6PFeAM3bTq8nr.append(CTHLVD3Scz0MZ24)
							Kg7HrjqNob3YwIl65T.append('')
						CTHLVD3Scz0MZ24 = rzgZ9Ajw2pHsLh
				else:
					di8fwIJ3qEjT6zN7 = 'AR'
					if WWmyDalKqAuOs05i43==di8fwIJ3qEjT6zN7: CTHLVD3Scz0MZ24 += ' '+rzgZ9Ajw2pHsLh
					elif rzgZ9Ajw2pHsLh:
						if CTHLVD3Scz0MZ24:
							Kg7HrjqNob3YwIl65T.append(CTHLVD3Scz0MZ24)
							UDv4GYuOXwaSz6PFeAM3bTq8nr.append('')
						CTHLVD3Scz0MZ24 = rzgZ9Ajw2pHsLh
				WWmyDalKqAuOs05i43 = di8fwIJ3qEjT6zN7
			if di8fwIJ3qEjT6zN7=='EN':
				Kg7HrjqNob3YwIl65T.append(CTHLVD3Scz0MZ24)
				UDv4GYuOXwaSz6PFeAM3bTq8nr.append('')
			else:
				UDv4GYuOXwaSz6PFeAM3bTq8nr.append(CTHLVD3Scz0MZ24)
				Kg7HrjqNob3YwIl65T.append('')
			xv6F3VjoqCYGLu1Sre7m2lp = ''
			SqZh30T47O6ro9Jk = zip(Kg7HrjqNob3YwIl65T,UDv4GYuOXwaSz6PFeAM3bTq8nr)
			for Wh56odTpF0zVQj2inC97e,bbvlqKW9SNgsofG in SqZh30T47O6ro9Jk:
				if Wh56odTpF0zVQj2inC97e: xv6F3VjoqCYGLu1Sre7m2lp += ' '+Wh56odTpF0zVQj2inC97e
				else:
					Leylj68ha3 = SomeI8i56FaDMGPE.findall('([!-~]) *$',bbvlqKW9SNgsofG)
					if Leylj68ha3:
						Leylj68ha3 = Leylj68ha3[0]
						try:
							h8Mtebc3lHDUkAX = q7N3zjv5lfR6Z.MIRRORED[Leylj68ha3]
							YfTHoQjlaZ1LIg = SomeI8i56FaDMGPE.findall('^( *?)(.*?)( *?)$',bbvlqKW9SNgsofG)
							if YfTHoQjlaZ1LIg: WHkv4cnYQpquzTGgiVt03N2BZsC,bbvlqKW9SNgsofG,K37cREDl4dzbkNJ = YfTHoQjlaZ1LIg[0]
							bbvlqKW9SNgsofG = WHkv4cnYQpquzTGgiVt03N2BZsC+h8Mtebc3lHDUkAX+bbvlqKW9SNgsofG[:-1]+K37cREDl4dzbkNJ
						except: pass
					xv6F3VjoqCYGLu1Sre7m2lp += ' '+bbvlqKW9SNgsofG
			CH3VkKb5LiB1cZUsoE = xv6F3VjoqCYGLu1Sre7m2lp[1:]
			if BhTAck1bPFYGuUqRW: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.encode('utf8')
		else:
			if BhTAck1bPFYGuUqRW: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.decode('utf8')
			CH3VkKb5LiB1cZUsoE = Xpa41TEJ2Wl.get_display(CH3VkKb5LiB1cZUsoE)
			zL9B0AKZONueqVxSr81FbJHdyCft,KFkRm21pHT3WNSzgICV = CH3VkKb5LiB1cZUsoE,CH3VkKb5LiB1cZUsoE
			if 1:
				WWmyDalKqAuOs05i43,VAWcxiNbYG6Urv2zqFPMnD9Xka = '',[]
				NoZ7hEJDt0UTfkRlu1Cg = CH3VkKb5LiB1cZUsoE.split(' ')
				for rhq3BpuJE7b1GZLdKYVOHP in NoZ7hEJDt0UTfkRlu1Cg:
					if not rhq3BpuJE7b1GZLdKYVOHP:
						if VAWcxiNbYG6Urv2zqFPMnD9Xka: VAWcxiNbYG6Urv2zqFPMnD9Xka[-1] += ' '
						else: VAWcxiNbYG6Urv2zqFPMnD9Xka.append('')
						continue
					PPwIj0aLNRsnhzC7iXto = SomeI8i56FaDMGPE.findall('[!-~]',rhq3BpuJE7b1GZLdKYVOHP[0])
					if PPwIj0aLNRsnhzC7iXto==WWmyDalKqAuOs05i43 and VAWcxiNbYG6Urv2zqFPMnD9Xka: VAWcxiNbYG6Urv2zqFPMnD9Xka[-1] += ' '+rhq3BpuJE7b1GZLdKYVOHP
					else:
						if VAWcxiNbYG6Urv2zqFPMnD9Xka:
							yEVdaAq075h1t = SomeI8i56FaDMGPE.findall('[^!-~]',VAWcxiNbYG6Urv2zqFPMnD9Xka[-1])
							if yEVdaAq075h1t:
								VAWcxiNbYG6Urv2zqFPMnD9Xka[-1] = Xpa41TEJ2Wl.get_display(VAWcxiNbYG6Urv2zqFPMnD9Xka[-1])
								bt0PAGWZjdnq = SomeI8i56FaDMGPE.findall('^ +',VAWcxiNbYG6Urv2zqFPMnD9Xka[-1])
								if bt0PAGWZjdnq: VAWcxiNbYG6Urv2zqFPMnD9Xka[-1] = VAWcxiNbYG6Urv2zqFPMnD9Xka[-1].lstrip(' ')+bt0PAGWZjdnq[0]
						VAWcxiNbYG6Urv2zqFPMnD9Xka.append(rhq3BpuJE7b1GZLdKYVOHP)
					WWmyDalKqAuOs05i43 = PPwIj0aLNRsnhzC7iXto
				if VAWcxiNbYG6Urv2zqFPMnD9Xka: VAWcxiNbYG6Urv2zqFPMnD9Xka[-1] = Xpa41TEJ2Wl.get_display(VAWcxiNbYG6Urv2zqFPMnD9Xka[-1])
				CH3VkKb5LiB1cZUsoE = ' '.join(VAWcxiNbYG6Urv2zqFPMnD9Xka)
			if BhTAck1bPFYGuUqRW: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.encode('utf8')
	return CH3VkKb5LiB1cZUsoE
def T8xIzFDE1dGX4tfeS(peGKZ47miuytWS8X,abd5WEw01VRe,ScK0xi1LkgdBUpsXmrM5awW):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,tHuNKT6x0L3CRM,Lroyw1stzO6nf8KZEYpQhj4XTkFi2,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = peGKZ47miuytWS8X
	lOH3hXsnQiFCRjbN12 = int(lOH3hXsnQiFCRjbN12)
	Z3IXupBUGVfkztmo9H2aNy4S1l68 = SomeI8i56FaDMGPE.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
	if Z3IXupBUGVfkztmo9H2aNy4S1l68:
		Z3IXupBUGVfkztmo9H2aNy4S1l68,vnjKzbly6oJRFrakY,quV3sBvprxdD = Z3IXupBUGVfkztmo9H2aNy4S1l68[0]
		CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace(Z3IXupBUGVfkztmo9H2aNy4S1l68,'')
	Kx4rg9w2aZoqO1EfJ = CH3VkKb5LiB1cZUsoE
	zMjs2DygmKfUQkOb6 = SomeI8i56FaDMGPE.findall('^_(\w\w\w)_(.*?)$',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
	if zMjs2DygmKfUQkOb6:
		zMjs2DygmKfUQkOb6,CH3VkKb5LiB1cZUsoE = zMjs2DygmKfUQkOb6[0]
		kmYbhGgl3xXQZfIa6zEBqd4pKV9v = '_MOD_' in CH3VkKb5LiB1cZUsoE
		mOEzG4cJoV9erugyXbLI = jPqMvmNDgsYiWUyxo=='folder'
		if kmYbhGgl3xXQZfIa6zEBqd4pKV9v and mOEzG4cJoV9erugyXbLI: JToZ7jmNBHbIxzV1Yf853uL9M = ';'
		elif kmYbhGgl3xXQZfIa6zEBqd4pKV9v and not mOEzG4cJoV9erugyXbLI: JToZ7jmNBHbIxzV1Yf853uL9M = xWa5bZGlqdDAFP2y
		elif not kmYbhGgl3xXQZfIa6zEBqd4pKV9v and mOEzG4cJoV9erugyXbLI: JToZ7jmNBHbIxzV1Yf853uL9M = ','
		elif not kmYbhGgl3xXQZfIa6zEBqd4pKV9v and not mOEzG4cJoV9erugyXbLI: JToZ7jmNBHbIxzV1Yf853uL9M = ' '
		CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('_MOD_','')
		zMjs2DygmKfUQkOb6 = JToZ7jmNBHbIxzV1Yf853uL9M+'[COLOR FFC89008]'+zMjs2DygmKfUQkOb6+' [/COLOR]'
	else: zMjs2DygmKfUQkOb6 = ''
	if Z3IXupBUGVfkztmo9H2aNy4S1l68:
		if BhTAck1bPFYGuUqRW:
			Z3IXupBUGVfkztmo9H2aNy4S1l68 = '[COLOR FFFFFF00]'+vnjKzbly6oJRFrakY+' '+quV3sBvprxdD+'[/COLOR]'
			if zMjs2DygmKfUQkOb6: CH3VkKb5LiB1cZUsoE = Z3IXupBUGVfkztmo9H2aNy4S1l68+' '+spTWfEz2PU9AL+zMjs2DygmKfUQkOb6+CH3VkKb5LiB1cZUsoE
			else: CH3VkKb5LiB1cZUsoE = Z3IXupBUGVfkztmo9H2aNy4S1l68+spTWfEz2PU9AL+CH3VkKb5LiB1cZUsoE+' '
		elif ZZxLpCcmqhyT6NuMWelkbSvr0H:
			if zMjs2DygmKfUQkOb6:
				Z3IXupBUGVfkztmo9H2aNy4S1l68 = '[COLOR FFFFFF00]'+vnjKzbly6oJRFrakY+' '+quV3sBvprxdD+'[/COLOR]'
				CH3VkKb5LiB1cZUsoE = Z3IXupBUGVfkztmo9H2aNy4S1l68+' '+zMjs2DygmKfUQkOb6+CH3VkKb5LiB1cZUsoE
			else:
				Z3IXupBUGVfkztmo9H2aNy4S1l68 = '[COLOR FFFFFF00]'+quV3sBvprxdD+' '+vnjKzbly6oJRFrakY+'[/COLOR]'
				CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE+' '+spTWfEz2PU9AL+Z3IXupBUGVfkztmo9H2aNy4S1l68
	elif zMjs2DygmKfUQkOb6:
		CH3VkKb5LiB1cZUsoE = o1sSQGH9gD6fknU(CH3VkKb5LiB1cZUsoE,zMjs2DygmKfUQkOb6)
		CH3VkKb5LiB1cZUsoE = zMjs2DygmKfUQkOb6+CH3VkKb5LiB1cZUsoE
	peGKZ47miuytWS8X = jPqMvmNDgsYiWUyxo,Kx4rg9w2aZoqO1EfJ,eesaHQO5yPGNvopTtWzR,str(lOH3hXsnQiFCRjbN12),V56GckjYK2vUw9,tHuNKT6x0L3CRM,Lroyw1stzO6nf8KZEYpQhj4XTkFi2,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60
	Qu7hw1klx9Jyp2K = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	Qu7hw1klx9Jyp2K['name'] = TbEVs6mLPHF(Kx4rg9w2aZoqO1EfJ)
	Qu7hw1klx9Jyp2K['type'] = jPqMvmNDgsYiWUyxo.strip(' ')
	Qu7hw1klx9Jyp2K['mode'] = str(lOH3hXsnQiFCRjbN12).strip(' ')
	if jPqMvmNDgsYiWUyxo=='folder' and tHuNKT6x0L3CRM: Qu7hw1klx9Jyp2K['page'] = TbEVs6mLPHF(tHuNKT6x0L3CRM.strip(' '))
	if lsfFwOE5rvtgxQCBo14VU: Qu7hw1klx9Jyp2K['context'] = lsfFwOE5rvtgxQCBo14VU.strip(' ')
	if Lroyw1stzO6nf8KZEYpQhj4XTkFi2: Qu7hw1klx9Jyp2K['text'] = TbEVs6mLPHF(Lroyw1stzO6nf8KZEYpQhj4XTkFi2.strip(' '))
	if V56GckjYK2vUw9: Qu7hw1klx9Jyp2K['image'] = TbEVs6mLPHF(V56GckjYK2vUw9.strip(' '))
	if AFbdWemQRHznuiv60:
		AFbdWemQRHznuiv60 = str(AFbdWemQRHznuiv60)
		Qu7hw1klx9Jyp2K['infodict'] = TbEVs6mLPHF(AFbdWemQRHznuiv60.strip(' '))
		AFbdWemQRHznuiv60 = eval(AFbdWemQRHznuiv60)
	else: AFbdWemQRHznuiv60 = {}
	if eesaHQO5yPGNvopTtWzR: Qu7hw1klx9Jyp2K['url'] = TbEVs6mLPHF(eesaHQO5yPGNvopTtWzR.strip(' '))
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	xcMCvhZ5gKT0D7RiI8lEyarPqmBu = []
	UOHRWKdhvNV7jGpPL4Fr = 'plugin://'+giwrh4jLPc+'/?type='+Qu7hw1klx9Jyp2K['type']+'&mode='+Qu7hw1klx9Jyp2K['mode']
	if Qu7hw1klx9Jyp2K['page']: UOHRWKdhvNV7jGpPL4Fr += '&page='+Qu7hw1klx9Jyp2K['page']
	if Qu7hw1klx9Jyp2K['name']: UOHRWKdhvNV7jGpPL4Fr += '&name='+Qu7hw1klx9Jyp2K['name']
	if Qu7hw1klx9Jyp2K['text']: UOHRWKdhvNV7jGpPL4Fr += '&text='+Qu7hw1klx9Jyp2K['text']
	if Qu7hw1klx9Jyp2K['infodict']: UOHRWKdhvNV7jGpPL4Fr += '&infodict='+Qu7hw1klx9Jyp2K['infodict']
	if Qu7hw1klx9Jyp2K['image']: UOHRWKdhvNV7jGpPL4Fr += '&image='+Qu7hw1klx9Jyp2K['image']
	if Qu7hw1klx9Jyp2K['url']: UOHRWKdhvNV7jGpPL4Fr += '&url='+Qu7hw1klx9Jyp2K['url']
	if lOH3hXsnQiFCRjbN12!=265: EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['favorites'] = True
	else: EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['favorites'] = False
	if Qu7hw1klx9Jyp2K['context']: UOHRWKdhvNV7jGpPL4Fr += '&context='+Qu7hw1klx9Jyp2K['context']
	if lOH3hXsnQiFCRjbN12 in [235,238] and jPqMvmNDgsYiWUyxo=='live' and 'EPG' in lsfFwOE5rvtgxQCBo14VU:
		MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = 'plugin://'+giwrh4jLPc+'?mode=238&text=SHORT_EPG&url='+eesaHQO5yPGNvopTtWzR
		MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
		xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	if lOH3hXsnQiFCRjbN12==265:
		Q9mNtOP03df7FKIrcvBSs8q4iDX5y = abd5WEw01VRe(Lroyw1stzO6nf8KZEYpQhj4XTkFi2,True)
		if Q9mNtOP03df7FKIrcvBSs8q4iDX5y>0:
			MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = 'plugin://'+giwrh4jLPc+'?mode=266&text='+Lroyw1stzO6nf8KZEYpQhj4XTkFi2
			MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+AFuJDPbZhS134etQfj(Lroyw1stzO6nf8KZEYpQhj4XTkFi2)+'[/COLOR]'
			OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
			xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	if jPqMvmNDgsYiWUyxo=='video' and lOH3hXsnQiFCRjbN12!=331:
		MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = UOHRWKdhvNV7jGpPL4Fr+'&context=6_DOWNLOAD'
		MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
		xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	if lOH3hXsnQiFCRjbN12==331:
		MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = UOHRWKdhvNV7jGpPL4Fr+'&context=6_DELETE'
		MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
		xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	if jPqMvmNDgsYiWUyxo=='folder' and lOH3hXsnQiFCRjbN12==540:
		zrpUTRCKPxBXISiwQ = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','GLOBALSEARCH_SITES')
		if zrpUTRCKPxBXISiwQ:
			MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = 'plugin://'+giwrh4jLPc+'?context=7'
			MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
			xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	yqaAKlc0mx4vu6hd7 = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if lOH3hXsnQiFCRjbN12 not in yqaAKlc0mx4vu6hd7:
		MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = 'plugin://'+giwrh4jLPc+'?context=8&mode=260'
		MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
		xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	H0AZ7Bhzyt = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if lOH3hXsnQiFCRjbN12%10 and lOH3hXsnQiFCRjbN12!=9990:
		JJy7lBacFwG = lOH3hXsnQiFCRjbN12-lOH3hXsnQiFCRjbN12%10
		if JJy7lBacFwG==280: JJy7lBacFwG = 230
		if JJy7lBacFwG==410: JJy7lBacFwG = 400
		if JJy7lBacFwG==520: JJy7lBacFwG = 510
		if JJy7lBacFwG not in H0AZ7Bhzyt:
			MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = 'plugin://'+giwrh4jLPc+'?context=8&mode='+str(JJy7lBacFwG)
			MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
			xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	MjqOkwyLBQ0pKVsXA5dIvf2Ua1 = UOHRWKdhvNV7jGpPL4Fr+'&context=9'
	MhoLsl05Gnw9CaOtfv = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	OOVNm7cbz8qwZ4HC = (MhoLsl05Gnw9CaOtfv,'RunPlugin('+MjqOkwyLBQ0pKVsXA5dIvf2Ua1+')')
	xcMCvhZ5gKT0D7RiI8lEyarPqmBu.append(OOVNm7cbz8qwZ4HC)
	if jPqMvmNDgsYiWUyxo in ['link','video','live']: tPSldHnxfWQkUe5NYcZuq9vjXsgzIr = False
	elif jPqMvmNDgsYiWUyxo=='folder': tPSldHnxfWQkUe5NYcZuq9vjXsgzIr = True
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['name'] = CH3VkKb5LiB1cZUsoE
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['context_menu'] = xcMCvhZ5gKT0D7RiI8lEyarPqmBu
	if 'plot' in list(AFbdWemQRHznuiv60.keys()): EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['plot'] = AFbdWemQRHznuiv60['plot']
	if 'stars' in list(AFbdWemQRHznuiv60.keys()): EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['stars'] = AFbdWemQRHznuiv60['stars']
	if V56GckjYK2vUw9: EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['image'] = V56GckjYK2vUw9
	if jPqMvmNDgsYiWUyxo=='video' and tHuNKT6x0L3CRM:
		ekjmsPHpfun07D6cAqISKZQ1dl = SomeI8i56FaDMGPE.findall('[\d:]+',tHuNKT6x0L3CRM,SomeI8i56FaDMGPE.DOTALL)
		if ekjmsPHpfun07D6cAqISKZQ1dl:
			ekjmsPHpfun07D6cAqISKZQ1dl = '0:0:0:0:0:'+ekjmsPHpfun07D6cAqISKZQ1dl[0]
			LL5opKn1gkuEZPf,D07u1RiqWvMYbNJXx6TpyzsCILm,QgDsiKTPvV5Z7,GotDf9alV51yJ7ECAYPe0cnq8Rzu,oFLQTERpl7Grvw9yM0SiDeW = ekjmsPHpfun07D6cAqISKZQ1dl.rsplit(':',4)
			hH5QjKsy1CgREaVkD0neZw = int(D07u1RiqWvMYbNJXx6TpyzsCILm)*24*nh1uLlGma8wJVsAMyKxkjC9N+int(QgDsiKTPvV5Z7)*nh1uLlGma8wJVsAMyKxkjC9N+int(GotDf9alV51yJ7ECAYPe0cnq8Rzu)*60+int(oFLQTERpl7Grvw9yM0SiDeW)
			EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['duration'] = hH5QjKsy1CgREaVkD0neZw
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['type'] = jPqMvmNDgsYiWUyxo
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['isFolder'] = tPSldHnxfWQkUe5NYcZuq9vjXsgzIr
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['newpath'] = UOHRWKdhvNV7jGpPL4Fr
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['menuItem'] = peGKZ47miuytWS8X
	EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['mode'] = lOH3hXsnQiFCRjbN12
	return EEdQTg67y1Z0BFLmnux8UMbeKYrIaX
def Zv2Sq7k0Bl(abd5WEw01VRe):
	I4ltEGFxyUS = []
	from fV1iMs36rd import k4tn3CNwPDRBoIpzY2gT,gLaEjQd2H6NtxW8DB37YivFTAe
	ScK0xi1LkgdBUpsXmrM5awW = k4tn3CNwPDRBoIpzY2gT()
	for peGKZ47miuytWS8X in nUTgq0SFfC9:
		EEdQTg67y1Z0BFLmnux8UMbeKYrIaX = T8xIzFDE1dGX4tfeS(peGKZ47miuytWS8X,abd5WEw01VRe,ScK0xi1LkgdBUpsXmrM5awW)
		if EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['favorites']:
			EKB7z6VWuvPAFJw = gLaEjQd2H6NtxW8DB37YivFTAe(ScK0xi1LkgdBUpsXmrM5awW,EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['menuItem'],EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['newpath'])
			EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['context_menu'] = EKB7z6VWuvPAFJw+EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['context_menu']
		I4ltEGFxyUS.append(EEdQTg67y1Z0BFLmnux8UMbeKYrIaX)
	return I4ltEGFxyUS
def uK39SBkYyeXf28O5IWdni0mtZ6QJEq(ZSkChYJp2a1P):
	JToZ7jmNBHbIxzV1Yf853uL9M,u62PK9E7CyahvLirdRfjBbol5g, = [],''
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		if not bDuvmIw28GRWVCBaOsT3HneLSt: JToZ7jmNBHbIxzV1Yf853uL9M.append('')
		else: break
	ZSkChYJp2a1P = ZSkChYJp2a1P[len(JToZ7jmNBHbIxzV1Yf853uL9M):]
	yy42JUqszVIO89i = '\n\n\n\n'.join(ZSkChYJp2a1P)
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('===== ===== =====','000001')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFC89008]','000002')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFFFFF00]','000003')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[/COLOR]','000004')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RIGHT]','000005')
	tt7LgzAD3j6VwBud = 100000
	tEAbYiPMyl8QujLsD3Knfkwxc4 = {}
	yy01SKJ8erZoQpqTdwPN4AGI9t = SomeI8i56FaDMGPE.findall('http.*?[\r\n ]',yy42JUqszVIO89i,SomeI8i56FaDMGPE.DOTALL)
	for BgkjUQMv2TdybXCH7DSp in yy01SKJ8erZoQpqTdwPN4AGI9t:
		tt7LgzAD3j6VwBud += 1
		yy42JUqszVIO89i = yy42JUqszVIO89i.replace(BgkjUQMv2TdybXCH7DSp,str(tt7LgzAD3j6VwBud))
		tEAbYiPMyl8QujLsD3Knfkwxc4[str(tt7LgzAD3j6VwBud)] = BgkjUQMv2TdybXCH7DSp
	for N6N8FlJCqco7hg in range(0,len(yy42JUqszVIO89i),4800):
		zL1Q9sCOhG7wKSiZBu4dIa6HyTJ = yy42JUqszVIO89i[N6N8FlJCqco7hg:N6N8FlJCqco7hg+4800]
		b6bSrn0KwVyRFYefjJEWsXi = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.code')
		eesaHQO5yPGNvopTtWzR = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+b6bSrn0KwVyRFYefjJEWsXi
		zqbfFORL9jgys3Q = {'Content-Type':'text/plain'}
		AeSEPxUqNO2R6ytiLzMmXg = zL1Q9sCOhG7wKSiZBu4dIa6HyTJ.encode('utf8')
		fcZNbeuJHKY = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',eesaHQO5yPGNvopTtWzR,AeSEPxUqNO2R6ytiLzMmXg,zqbfFORL9jgys3Q,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if fcZNbeuJHKY.succeeded:
			CGXtvdWw4RHqkMLmeN = fcZNbeuJHKY.content
			rtGkzw5pZFSoMc6WH = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',CGXtvdWw4RHqkMLmeN)
			if rtGkzw5pZFSoMc6WH:
				rtGkzw5pZFSoMc6WH = rtGkzw5pZFSoMc6WH['translation']
				rtGkzw5pZFSoMc6WH = c8Fvb4IfHW9XkG1mLK5Z(rtGkzw5pZFSoMc6WH)
				for Ef9XDLmV7wByGWshRqnb654Z in range(len(rtGkzw5pZFSoMc6WH)):
					u62PK9E7CyahvLirdRfjBbol5g += rtGkzw5pZFSoMc6WH[Ef9XDLmV7wByGWshRqnb654Z][0]
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000001','===== ===== =====')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000002','[COLOR FFC89008]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000003','[COLOR FFFFFF00]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000004','[/COLOR]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000005','[RIGHT]')
	for tt7LgzAD3j6VwBud in list(tEAbYiPMyl8QujLsD3Knfkwxc4.keys()):
		BgkjUQMv2TdybXCH7DSp = tEAbYiPMyl8QujLsD3Knfkwxc4[tt7LgzAD3j6VwBud]
		u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace(tt7LgzAD3j6VwBud,BgkjUQMv2TdybXCH7DSp)
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.split('\n\n\n\n')
	return JToZ7jmNBHbIxzV1Yf853uL9M+u62PK9E7CyahvLirdRfjBbol5g
def cR8sS6O9Feuy(ZSkChYJp2a1P):
	JToZ7jmNBHbIxzV1Yf853uL9M,u62PK9E7CyahvLirdRfjBbol5g, = [],''
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		if not bDuvmIw28GRWVCBaOsT3HneLSt: JToZ7jmNBHbIxzV1Yf853uL9M.append('')
		else: break
	ZSkChYJp2a1P = ZSkChYJp2a1P[len(JToZ7jmNBHbIxzV1Yf853uL9M):]
	yy42JUqszVIO89i = '\\n\\n\\n\\n'.join(ZSkChYJp2a1P)
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('كلا','no')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('استمرار','continue')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('===== ===== =====','000001')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFC89008]','000002')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFFFFF00]','000003')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[/COLOR]','000004')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RIGHT]','000005')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[CENTER]','000006')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RTL]','000007')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace("'","\\\\\\'")
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('"','\\\\\\"')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('\n','\\n')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('\r','\\\\r')
	for N6N8FlJCqco7hg in range(0,len(yy42JUqszVIO89i),4800):
		zL1Q9sCOhG7wKSiZBu4dIa6HyTJ = yy42JUqszVIO89i[N6N8FlJCqco7hg:N6N8FlJCqco7hg+4800]
		eesaHQO5yPGNvopTtWzR = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		zqbfFORL9jgys3Q = {'Content-Type':'application/x-www-form-urlencoded'}
		b6bSrn0KwVyRFYefjJEWsXi = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.code')
		AeSEPxUqNO2R6ytiLzMmXg = 'f.req='+TbEVs6mLPHF('[[["MkEWBc","[[\\"'+zL1Q9sCOhG7wKSiZBu4dIa6HyTJ+'\\",\\"ar\\",\\"'+b6bSrn0KwVyRFYefjJEWsXi+'\\",1],[]]",null,"generic"]]]','')
		AeSEPxUqNO2R6ytiLzMmXg = AeSEPxUqNO2R6ytiLzMmXg.replace('%5Cn','%5C%5Cn')
		fcZNbeuJHKY = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',eesaHQO5yPGNvopTtWzR,AeSEPxUqNO2R6ytiLzMmXg,zqbfFORL9jgys3Q,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if fcZNbeuJHKY.succeeded:
			CGXtvdWw4RHqkMLmeN = fcZNbeuJHKY.content
			CGXtvdWw4RHqkMLmeN = CGXtvdWw4RHqkMLmeN.split('\n')[-1]
			rtGkzw5pZFSoMc6WH = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',CGXtvdWw4RHqkMLmeN)[0][2]
			if rtGkzw5pZFSoMc6WH:
				rtGkzw5pZFSoMc6WH = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('str',rtGkzw5pZFSoMc6WH)[1][0][0][5]
				rtGkzw5pZFSoMc6WH = c8Fvb4IfHW9XkG1mLK5Z(rtGkzw5pZFSoMc6WH)
				for Ef9XDLmV7wByGWshRqnb654Z in range(len(rtGkzw5pZFSoMc6WH)):
					u62PK9E7CyahvLirdRfjBbol5g += rtGkzw5pZFSoMc6WH[Ef9XDLmV7wByGWshRqnb654Z][0]
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('00000','0000').replace('0000','000')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0001','===== ===== =====')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0002','[COLOR FFC89008]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0003','[COLOR FFFFFF00]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0004','[/COLOR]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0005','[RIGHT]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0006','[CENTER]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0007','[RTL]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.split('\n\n\n\n')
	return JToZ7jmNBHbIxzV1Yf853uL9M+u62PK9E7CyahvLirdRfjBbol5g
def nV58YIvdL0kAf7XGRxHmcQjgr9b(ZSkChYJp2a1P):
	JToZ7jmNBHbIxzV1Yf853uL9M,ks04hqwZrRYHU7KTPLpOWdea1 = [],[]
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		if not bDuvmIw28GRWVCBaOsT3HneLSt: JToZ7jmNBHbIxzV1Yf853uL9M.append('')
		else: break
	ZSkChYJp2a1P = ZSkChYJp2a1P[len(JToZ7jmNBHbIxzV1Yf853uL9M):]
	yy42JUqszVIO89i = '\n\n\n\n'.join(ZSkChYJp2a1P)
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('كلا','no')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('استمرار','continue')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('أدناه','below')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFC89008]','00001')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR FFFFFF00]','00002')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[/COLOR]','00003')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('=====','00004')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace(',','00005')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RTL]','00009')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[CENTER]','0000A')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('\r','0000B')
	ZSkChYJp2a1P = yy42JUqszVIO89i.split('\n')
	yy42JUqszVIO89i,u62PK9E7CyahvLirdRfjBbol5g = '',''
	for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
		if len(yy42JUqszVIO89i+bDuvmIw28GRWVCBaOsT3HneLSt)<1800: yy42JUqszVIO89i += '\n'+bDuvmIw28GRWVCBaOsT3HneLSt
		else:
			ks04hqwZrRYHU7KTPLpOWdea1.append(yy42JUqszVIO89i)
			yy42JUqszVIO89i = bDuvmIw28GRWVCBaOsT3HneLSt
	ks04hqwZrRYHU7KTPLpOWdea1.append(yy42JUqszVIO89i)
	from json import dumps as jiu1xadg3w7SUE
	for bDuvmIw28GRWVCBaOsT3HneLSt in ks04hqwZrRYHU7KTPLpOWdea1:
		zqbfFORL9jgys3Q = {'Content-Type':'application/json','User-Agent':''}
		eesaHQO5yPGNvopTtWzR = 'https://api.reverso.net/translate/v1/translation'
		b6bSrn0KwVyRFYefjJEWsXi = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.code')
		AeSEPxUqNO2R6ytiLzMmXg = {"format":"text","from":"ara","to":b6bSrn0KwVyRFYefjJEWsXi,"input":bDuvmIw28GRWVCBaOsT3HneLSt,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		AeSEPxUqNO2R6ytiLzMmXg = jiu1xadg3w7SUE(AeSEPxUqNO2R6ytiLzMmXg)
		fcZNbeuJHKY = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'POST',eesaHQO5yPGNvopTtWzR,AeSEPxUqNO2R6ytiLzMmXg,zqbfFORL9jgys3Q,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if fcZNbeuJHKY.succeeded:
			CGXtvdWw4RHqkMLmeN = fcZNbeuJHKY.content
			CGXtvdWw4RHqkMLmeN = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',CGXtvdWw4RHqkMLmeN)
			u62PK9E7CyahvLirdRfjBbol5g += '\n'+''.join(CGXtvdWw4RHqkMLmeN['translation'])
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g[2:]
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000000','00000').replace('00000','0000').replace('0000','000')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0001','[COLOR FFC89008]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0002','[COLOR FFFFFF00]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0003','[/COLOR]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0004','=====')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0005',',')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('0009','[RTL]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000A','[CENTER]')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.replace('000B','\r')
	u62PK9E7CyahvLirdRfjBbol5g = u62PK9E7CyahvLirdRfjBbol5g.split('\n\n\n\n')
	return JToZ7jmNBHbIxzV1Yf853uL9M+u62PK9E7CyahvLirdRfjBbol5g
def rQ4PKo0cMIyC7Dbux(ZSkChYJp2a1P):
	uuxNFTRwvGVW = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.translate')
	if not uuxNFTRwvGVW or not ZSkChYJp2a1P: return ZSkChYJp2a1P
	oH8g9ANIlfbZGrwKd2zxpyOUJBk = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.provider')
	b6bSrn0KwVyRFYefjJEWsXi = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.code')
	jiBWxtmaKls3MzoVJhneO6H1bGTNc4 = b6bSrn0KwVyRFYefjJEWsXi+'__'+str(ZSkChYJp2a1P)
	LCIFdjzi5kVmRwehouHQ.setSetting('av.language.translate','')
	u62PK9E7CyahvLirdRfjBbol5g = yu1pYA2VRHzr876gPJdDw(qQ4BC6vW5YOfo,'list','TRANSLATE_'+oH8g9ANIlfbZGrwKd2zxpyOUJBk,jiBWxtmaKls3MzoVJhneO6H1bGTNc4)
	if not u62PK9E7CyahvLirdRfjBbol5g:
		if oH8g9ANIlfbZGrwKd2zxpyOUJBk=='GOOGLE': u62PK9E7CyahvLirdRfjBbol5g = cR8sS6O9Feuy(ZSkChYJp2a1P)
		elif oH8g9ANIlfbZGrwKd2zxpyOUJBk=='REVERSO': u62PK9E7CyahvLirdRfjBbol5g = nV58YIvdL0kAf7XGRxHmcQjgr9b(ZSkChYJp2a1P)
		elif oH8g9ANIlfbZGrwKd2zxpyOUJBk=='GLOSBE': u62PK9E7CyahvLirdRfjBbol5g = uK39SBkYyeXf28O5IWdni0mtZ6QJEq(ZSkChYJp2a1P)
		if len(ZSkChYJp2a1P)==len(u62PK9E7CyahvLirdRfjBbol5g):
			F4QxJHhsMj(qQ4BC6vW5YOfo,'TRANSLATE_'+oH8g9ANIlfbZGrwKd2zxpyOUJBk,jiBWxtmaKls3MzoVJhneO6H1bGTNc4,u62PK9E7CyahvLirdRfjBbol5g,wwSaAipunqYIgcH)
		else:
			u62PK9E7CyahvLirdRfjBbol5g = ZSkChYJp2a1P
			NCXj2ri3Unm6TFWIgwh('الترجمة فشلت','Translation Failed')
	LCIFdjzi5kVmRwehouHQ.setSetting('av.language.translate','1')
	return u62PK9E7CyahvLirdRfjBbol5g
def hN4mtYQX8rI(peGKZ47miuytWS8X,I4ltEGFxyUS,TbESvC7xMBAzRyamKtU6uLwI,hkWrmY6O5uVs9QcqCMIwJ0ibRo3Z,haYzbiTBOmjSVG):
	jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60 = peGKZ47miuytWS8X
	L2LoMNvWqjiFxG61r5eIJ = []
	uuxNFTRwvGVW = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.translate')
	if uuxNFTRwvGVW:
		OeRYr0U8AMnyPfsvBWLJwCI3bg9qh5,PzLaykWFZxwR7b,V4vyNdJuOftQmkoiUXP9R6l3Yw = [],[],[]
		if not L2LoMNvWqjiFxG61r5eIJ:
			for EEdQTg67y1Z0BFLmnux8UMbeKYrIaX in I4ltEGFxyUS:
				CH3VkKb5LiB1cZUsoE = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['name'].replace(spTWfEz2PU9AL,'').replace(H02Qqy4XO9L3Dui6S8PGWxJt,'')
				Z3IXupBUGVfkztmo9H2aNy4S1l68 = SomeI8i56FaDMGPE.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
				if Z3IXupBUGVfkztmo9H2aNy4S1l68:
					JToZ7jmNBHbIxzV1Yf853uL9M,vnjKzbly6oJRFrakY,quV3sBvprxdD,urWCk7QVnP53KsENpOb8aY,CH3VkKb5LiB1cZUsoE = Z3IXupBUGVfkztmo9H2aNy4S1l68[0]
					Z3IXupBUGVfkztmo9H2aNy4S1l68 = JToZ7jmNBHbIxzV1Yf853uL9M+vnjKzbly6oJRFrakY+' '+quV3sBvprxdD+urWCk7QVnP53KsENpOb8aY+' '
				else:
					Z3IXupBUGVfkztmo9H2aNy4S1l68 = SomeI8i56FaDMGPE.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
					if Z3IXupBUGVfkztmo9H2aNy4S1l68:
						CH3VkKb5LiB1cZUsoE,JToZ7jmNBHbIxzV1Yf853uL9M,quV3sBvprxdD,vnjKzbly6oJRFrakY,urWCk7QVnP53KsENpOb8aY = Z3IXupBUGVfkztmo9H2aNy4S1l68[0]
						Z3IXupBUGVfkztmo9H2aNy4S1l68 = JToZ7jmNBHbIxzV1Yf853uL9M+vnjKzbly6oJRFrakY+' '+quV3sBvprxdD+urWCk7QVnP53KsENpOb8aY+' '
					else: Z3IXupBUGVfkztmo9H2aNy4S1l68 = ''
				zMjs2DygmKfUQkOb6 = SomeI8i56FaDMGPE.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
				if zMjs2DygmKfUQkOb6: zMjs2DygmKfUQkOb6,CH3VkKb5LiB1cZUsoE = zMjs2DygmKfUQkOb6[0]
				else: zMjs2DygmKfUQkOb6 = ''
				OeRYr0U8AMnyPfsvBWLJwCI3bg9qh5.append(Z3IXupBUGVfkztmo9H2aNy4S1l68+zMjs2DygmKfUQkOb6)
				PzLaykWFZxwR7b.append(CH3VkKb5LiB1cZUsoE)
			V4vyNdJuOftQmkoiUXP9R6l3Yw = rQ4PKo0cMIyC7Dbux(PzLaykWFZxwR7b)
			if V4vyNdJuOftQmkoiUXP9R6l3Yw:
				for N6N8FlJCqco7hg in range(len(I4ltEGFxyUS)):
					EEdQTg67y1Z0BFLmnux8UMbeKYrIaX = I4ltEGFxyUS[N6N8FlJCqco7hg]
					EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['name'] = OeRYr0U8AMnyPfsvBWLJwCI3bg9qh5[N6N8FlJCqco7hg]+V4vyNdJuOftQmkoiUXP9R6l3Yw[N6N8FlJCqco7hg]
					L2LoMNvWqjiFxG61r5eIJ.append(EEdQTg67y1Z0BFLmnux8UMbeKYrIaX)
	if L2LoMNvWqjiFxG61r5eIJ: I4ltEGFxyUS = L2LoMNvWqjiFxG61r5eIJ
	yyW9Fv7oqJsMOdl5,aiR3W028eodUqPYB,sWavGLBXVDgjm5kJ17AI = [],0,0
	ttiWvLd8psGwyzZcR3KEIfXgQO2 = Dh9MOxeTj6FW.path.join(nnyfJE0MzRWolCuK68rxd,lOH3hXsnQiFCRjbN12)
	try: MmdDRyY4PTlIEov6qe7N2ubxBFkJ = Dh9MOxeTj6FW.listdir(ttiWvLd8psGwyzZcR3KEIfXgQO2)
	except:
		try: Dh9MOxeTj6FW.makedirs(ttiWvLd8psGwyzZcR3KEIfXgQO2)
		except: pass
		MmdDRyY4PTlIEov6qe7N2ubxBFkJ = []
	LIhgaMytACvx0cKl3EuTRHq = St9XswdBVKvUjD12Tn5Oa0i6cP('menu_item')
	for EEdQTg67y1Z0BFLmnux8UMbeKYrIaX in I4ltEGFxyUS:
		CH3VkKb5LiB1cZUsoE = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['name']
		xcMCvhZ5gKT0D7RiI8lEyarPqmBu = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['context_menu']
		au4IKtHGi5JUBjAg7oP = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['plot']
		UlaZI8Rnc6Q = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['stars']
		V56GckjYK2vUw9 = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['image']
		jPqMvmNDgsYiWUyxo = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['type']
		ekjmsPHpfun07D6cAqISKZQ1dl = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['duration']
		tPSldHnxfWQkUe5NYcZuq9vjXsgzIr = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['isFolder']
		UOHRWKdhvNV7jGpPL4Fr = EEdQTg67y1Z0BFLmnux8UMbeKYrIaX['newpath']
		OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT = N7zpvB3VIPrwcSDEC.ListItem(CH3VkKb5LiB1cZUsoE)
		OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.addContextMenuItems(xcMCvhZ5gKT0D7RiI8lEyarPqmBu)
		if V56GckjYK2vUw9: OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setArt({'icon':V56GckjYK2vUw9,'thumb':V56GckjYK2vUw9,'fanart':V56GckjYK2vUw9,'banner':V56GckjYK2vUw9,'clearart':V56GckjYK2vUw9,'poster':V56GckjYK2vUw9,'clearlogo':V56GckjYK2vUw9,'landscape':V56GckjYK2vUw9})
		else:
			CH3VkKb5LiB1cZUsoE = JA5CtfUvW3ljmExIYFog(CH3VkKb5LiB1cZUsoE)
			CH3VkKb5LiB1cZUsoE = Hc4VBGR3XzyljCZWvn(CH3VkKb5LiB1cZUsoE)
			dV4WapiFlZ8RMtKOHrQAoDC = CH3VkKb5LiB1cZUsoE+'.png'
			default = True
			if dV4WapiFlZ8RMtKOHrQAoDC in MmdDRyY4PTlIEov6qe7N2ubxBFkJ:
				aaC8fsQHqYUGtyomkgh = Dh9MOxeTj6FW.path.join(ttiWvLd8psGwyzZcR3KEIfXgQO2,dV4WapiFlZ8RMtKOHrQAoDC)
				OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setArt({'icon':aaC8fsQHqYUGtyomkgh,'thumb':aaC8fsQHqYUGtyomkgh,'fanart':aaC8fsQHqYUGtyomkgh,'banner':aaC8fsQHqYUGtyomkgh,'clearart':aaC8fsQHqYUGtyomkgh,'poster':aaC8fsQHqYUGtyomkgh,'clearlogo':aaC8fsQHqYUGtyomkgh,'landscape':aaC8fsQHqYUGtyomkgh})
				default = False
			elif aiR3W028eodUqPYB<60 and sWavGLBXVDgjm5kJ17AI<5:
				aaC8fsQHqYUGtyomkgh = Dh9MOxeTj6FW.path.join(ttiWvLd8psGwyzZcR3KEIfXgQO2,dV4WapiFlZ8RMtKOHrQAoDC)
				try:
					JUtFHpmXb6G7eI9P = gcpz9ky3ZolGqm(LIhgaMytACvx0cKl3EuTRHq,'','','','',CH3VkKb5LiB1cZUsoE,'menu_item','center',False,aaC8fsQHqYUGtyomkgh)
					OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setArt({'icon':aaC8fsQHqYUGtyomkgh,'thumb':aaC8fsQHqYUGtyomkgh,'fanart':aaC8fsQHqYUGtyomkgh,'banner':aaC8fsQHqYUGtyomkgh,'clearart':aaC8fsQHqYUGtyomkgh,'poster':aaC8fsQHqYUGtyomkgh,'clearlogo':aaC8fsQHqYUGtyomkgh,'landscape':aaC8fsQHqYUGtyomkgh})
					aiR3W028eodUqPYB += 1
					default = False
				except: sWavGLBXVDgjm5kJ17AI += 1
			if default: OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setArt({'icon':z8UmNpEWYicXg10Ql,'thumb':OhqLsI3oamdWniz0kp9KE,'fanart':Q8QUpl41kEIC2O,'banner':v0wCsoZl4OxmE5n9bqrA37KuhY8Lg,'clearart':XX7nyCZhWm8,'poster':TIy4RwCMzvoY9h3eEg8jXKQ,'clearlogo':foEqUAadQ43yWx8KFvOSVjTn0X6H5,'landscape':q8SNAgXnfwb0dOVv})
		if Qf8xsJSwoKaUNc<20:
			if au4IKtHGi5JUBjAg7oP: OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setInfo('video',{'Plot':au4IKtHGi5JUBjAg7oP,'PlotOutline':au4IKtHGi5JUBjAg7oP})
			if UlaZI8Rnc6Q: OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setInfo('video',{'Rating':UlaZI8Rnc6Q})
			if not V56GckjYK2vUw9:
				OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setInfo('video',{'Title':CH3VkKb5LiB1cZUsoE})
			if jPqMvmNDgsYiWUyxo=='video':
				OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setInfo('video',{'mediatype':'movie'})
				if ekjmsPHpfun07D6cAqISKZQ1dl: OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setInfo('video',{'duration':ekjmsPHpfun07D6cAqISKZQ1dl})
				OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setProperty('IsPlayable','true')
		else:
			d4ynzePU2sIMRpJKBjghlo6OQX7cZ0 = OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.getVideoInfoTag()
			if UlaZI8Rnc6Q: d4ynzePU2sIMRpJKBjghlo6OQX7cZ0.setRating(float(UlaZI8Rnc6Q))
			if not V56GckjYK2vUw9:
				d4ynzePU2sIMRpJKBjghlo6OQX7cZ0.setTitle(CH3VkKb5LiB1cZUsoE)
			if jPqMvmNDgsYiWUyxo=='video':
				d4ynzePU2sIMRpJKBjghlo6OQX7cZ0.setMediaType('tvshow')
				if ekjmsPHpfun07D6cAqISKZQ1dl: d4ynzePU2sIMRpJKBjghlo6OQX7cZ0.setDuration(ekjmsPHpfun07D6cAqISKZQ1dl)
				OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT.setProperty('IsPlayable','true')
		yyW9Fv7oqJsMOdl5.append((UOHRWKdhvNV7jGpPL4Fr,OOt05Ex3qLdbpnXQSJzNYKZPeaRVCT,tPSldHnxfWQkUe5NYcZuq9vjXsgzIr))
	YRyCdPm9JnNZ5vf.setContent(yR8fePHkvJnx3K0FQVs,'tvshows')
	bDnsEqfYoXJ = YRyCdPm9JnNZ5vf.addDirectoryItems(yR8fePHkvJnx3K0FQVs,yyW9Fv7oqJsMOdl5)
	YRyCdPm9JnNZ5vf.endOfDirectory(yR8fePHkvJnx3K0FQVs,TbESvC7xMBAzRyamKtU6uLwI,hkWrmY6O5uVs9QcqCMIwJ0ibRo3Z,haYzbiTBOmjSVG)
	return bDnsEqfYoXJ
def UZ8LYnm5jsl9uKM0xDX(jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9='',B2Axl9aIWKdUXNTEtc0YjCR5yPF='',yy42JUqszVIO89i='',lsfFwOE5rvtgxQCBo14VU='',AFbdWemQRHznuiv60={}):
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('\r','').replace('\n','').replace('\t','')
	eesaHQO5yPGNvopTtWzR = eesaHQO5yPGNvopTtWzR.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in CH3VkKb5LiB1cZUsoE: AdKBOaFs5gt3RoNkwLj,CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.split('_SCRIPT_',1)
	else: AdKBOaFs5gt3RoNkwLj,CH3VkKb5LiB1cZUsoE = '',CH3VkKb5LiB1cZUsoE
	if AdKBOaFs5gt3RoNkwLj:
		uZOJyRase8goK = CH3VkKb5LiB1cZUsoE
		if not uZOJyRase8goK: uZOJyRase8goK = '....'
		elif uZOJyRase8goK.count('_')>1: uZOJyRase8goK = uZOJyRase8goK.split('_',2)[2]
		uZOJyRase8goK = uZOJyRase8goK.replace(' ','')
		uZOJyRase8goK = uZOJyRase8goK.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		uZOJyRase8goK = uZOJyRase8goK.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		uZOJyRase8goK = uZOJyRase8goK.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		uZOJyRase8goK = uZOJyRase8goK.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		uZOJyRase8goK = uZOJyRase8goK.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		uZOJyRase8goK = uZOJyRase8goK.replace('|','').replace('~','')
		uZOJyRase8goK = uZOJyRase8goK.replace('اون لاين','').replace('سيما لايت','')
		z6vqOGHlmWBJDEL0ShuVe4FQY1p = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(y3QD6VRYHqX in uZOJyRase8goK for y3QD6VRYHqX in z6vqOGHlmWBJDEL0ShuVe4FQY1p): uZOJyRase8goK = uZOJyRase8goK.replace('ال','')
		uZOJyRase8goK = uZOJyRase8goK.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		uZOJyRase8goK = uZOJyRase8goK.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		uZOJyRase8goK = uZOJyRase8goK.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		uZOJyRase8goK = uZOJyRase8goK.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		uZOJyRase8goK = uZOJyRase8goK.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		uZOJyRase8goK = uZOJyRase8goK.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		uZOJyRase8goK = uZOJyRase8goK.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		uZOJyRase8goK = uZOJyRase8goK.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		uZOJyRase8goK = uZOJyRase8goK.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		uZOJyRase8goK = uZOJyRase8goK.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		uZOJyRase8goK = uZOJyRase8goK.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		uZOJyRase8goK = uZOJyRase8goK.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		uZOJyRase8goK = uZOJyRase8goK.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		uZOJyRase8goK = uZOJyRase8goK.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		uZOJyRase8goK = uZOJyRase8goK.replace('  ',' ').strip(' ')
		AdKBOaFs5gt3RoNkwLj = '_LST_'+AFuJDPbZhS134etQfj(AdKBOaFs5gt3RoNkwLj)
		if uZOJyRase8goK not in list(w1wlgpYj6tbWLhxD.keys()): w1wlgpYj6tbWLhxD[uZOJyRase8goK] = {}
		w1wlgpYj6tbWLhxD[uZOJyRase8goK][AdKBOaFs5gt3RoNkwLj] = [jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60]
	nUTgq0SFfC9.append([jPqMvmNDgsYiWUyxo,CH3VkKb5LiB1cZUsoE,eesaHQO5yPGNvopTtWzR,lOH3hXsnQiFCRjbN12,V56GckjYK2vUw9,B2Axl9aIWKdUXNTEtc0YjCR5yPF,yy42JUqszVIO89i,lsfFwOE5rvtgxQCBo14VU,AFbdWemQRHznuiv60])
	return
def dCFP41Kxv9j8EHM(UJEg8j7eZCaIPmw):
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: from html import unescape as _BTWHZNP43rQUm
	else:
		from HTMLParser import HTMLParser as QLKaZJXPn2bI9Nsvy3W56pAUHE4hC
		_BTWHZNP43rQUm = QLKaZJXPn2bI9Nsvy3W56pAUHE4hC().unescape
	if '&' in UJEg8j7eZCaIPmw and ';' in UJEg8j7eZCaIPmw:
		if BhTAck1bPFYGuUqRW: UJEg8j7eZCaIPmw = UJEg8j7eZCaIPmw.decode('utf8')
		UJEg8j7eZCaIPmw = _BTWHZNP43rQUm(UJEg8j7eZCaIPmw)
		if BhTAck1bPFYGuUqRW: UJEg8j7eZCaIPmw = UJEg8j7eZCaIPmw.encode('utf8')
	return UJEg8j7eZCaIPmw
def c8Fvb4IfHW9XkG1mLK5Z(UJEg8j7eZCaIPmw):
	if '\\u' in UJEg8j7eZCaIPmw:
		if BhTAck1bPFYGuUqRW: UJEg8j7eZCaIPmw = UJEg8j7eZCaIPmw.decode('unicode_escape','ignore').encode('utf8')
		elif ZZxLpCcmqhyT6NuMWelkbSvr0H: UJEg8j7eZCaIPmw = UJEg8j7eZCaIPmw.encode('utf8').decode('unicode_escape','ignore')
	return UJEg8j7eZCaIPmw
def DkzsprAlwfGdgqHMhNtZvO5i6Rba(eqbrFhSBWI57nR89w1,mLkRfg3KiToQIdJC1v6zYp7X2wHA,OvSeWj4P9aDBNGlIw81i5TLCExR,Wzpfc28uUC4R,yy42JUqszVIO89i,ztmnTYw0ZQ8pE4,ccxBNrT5HGK6LRh7932S,maLQc7bhwxC5kJE96y3s01KRTM,RRXsBt6uPqUKkQMd9WSIfcVgCNyw):
	lVZBbwg1ovWGTpDQ72Y5kSnXtCE = St9XswdBVKvUjD12Tn5Oa0i6cP(ztmnTYw0ZQ8pE4)
	JUtFHpmXb6G7eI9P = gcpz9ky3ZolGqm(lVZBbwg1ovWGTpDQ72Y5kSnXtCE,eqbrFhSBWI57nR89w1,mLkRfg3KiToQIdJC1v6zYp7X2wHA,OvSeWj4P9aDBNGlIw81i5TLCExR,Wzpfc28uUC4R,yy42JUqszVIO89i,ztmnTYw0ZQ8pE4,ccxBNrT5HGK6LRh7932S,maLQc7bhwxC5kJE96y3s01KRTM,RRXsBt6uPqUKkQMd9WSIfcVgCNyw)
	return JUtFHpmXb6G7eI9P
def St9XswdBVKvUjD12Tn5Oa0i6cP(ztmnTYw0ZQ8pE4):
	vEnQy6j7FTRchK = 5
	uZkGTgP5D1eoNiYCpB7 = 20
	AbVF3Irue7oG5dsZaHjP4kY = 20
	ssoi1P0vZyb = 0
	CWiEpVvFbcsxNX = 'center'
	M8FTsQJ0w19euoXSg4 = 0
	doz8Q5Y4DAC2rhxlwiq37P = 19
	DKoufbBM2Ewv81z = 30
	lluI5c2AK8UDNBZqgnCFtsbmhEwS9 = 8
	WJC3XhvQN6np9wmSMVRtDilgBezy7 = True
	dRO2vYUpX35IonkmfyuQ = 375
	QpSksotcHizhfjPlvMVe8DXGN = 410
	v1tmn3Er2Q = 50
	a8xwDqr3pRPXEKdk9LYibSOHJB0gv = 280
	qZIFLdsv4A = 28
	dr3JCpnLOw2 = 5
	CTHdPymV6gfBSYbNe8rUuAnj = 0
	H59HcVl0EwgbPY = 31
	GTDsLvw3Udxubqg6Sc2KCJ8 = [36,32,28]
	if ztmnTYw0ZQ8pE4 in ['notification','notification_twohalfs']:
		if ztmnTYw0ZQ8pE4=='notification_twohalfs':
			qwScLijCVA8lG6,h9vit8p6KqJ = 'UPPER',720
			CWiEpVvFbcsxNX = 'right'
			WJC3XhvQN6np9wmSMVRtDilgBezy7 = True
			ssoi1P0vZyb = 10
		else:
			qwScLijCVA8lG6,h9vit8p6KqJ = 97+20,720
			CWiEpVvFbcsxNX = 'left'
			WJC3XhvQN6np9wmSMVRtDilgBezy7 = False
		GTDsLvw3Udxubqg6Sc2KCJ8 = [33,33,33]
		AbVF3Irue7oG5dsZaHjP4kY = 20
		uZkGTgP5D1eoNiYCpB7 = 0
		DKoufbBM2Ewv81z = 20
		doz8Q5Y4DAC2rhxlwiq37P = 25+10
	elif ztmnTYw0ZQ8pE4=='menu_item':
		GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [48,44,40],200,400
		DKoufbBM2Ewv81z,doz8Q5Y4DAC2rhxlwiq37P,uZkGTgP5D1eoNiYCpB7 = 0,0,-16
		uwkb2oYIeNgCqOmvf0UZyMF = Zm7N6Rv39POxEg8jQnpoKHzlD12G.open(GGmAxq9Dh2Kgpl)
		uO6t58Z4N19bHFTwse = Zm7N6Rv39POxEg8jQnpoKHzlD12G.new('RGBA',(200,200),(255,0,0,255))
	elif ztmnTYw0ZQ8pE4=='confirm_smallfont': GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [28,24,20],500,900
	elif ztmnTYw0ZQ8pE4=='confirm_mediumfont': GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [32,28,24],500,900
	elif ztmnTYw0ZQ8pE4=='confirm_bigfont': GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [36,32,28],500,900
	elif ztmnTYw0ZQ8pE4=='textview_bigfont': qwScLijCVA8lG6,h9vit8p6KqJ = 740,1270
	elif ztmnTYw0ZQ8pE4=='textview_bigfont_long': qwScLijCVA8lG6,h9vit8p6KqJ = 'UPPER',1270
	elif ztmnTYw0ZQ8pE4=='textview_smallfont': GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [28,23,18],740,1270
	elif ztmnTYw0ZQ8pE4=='textview_smallfont_long': GTDsLvw3Udxubqg6Sc2KCJ8,qwScLijCVA8lG6,h9vit8p6KqJ = [28,23,18],'UPPER',1270
	ZZ2bue6miDwhPCqf1BnkrtLd = GTDsLvw3Udxubqg6Sc2KCJ8[0]
	UcarFmHvTA8 = GTDsLvw3Udxubqg6Sc2KCJ8[1]
	NNsMpPxGu3ZXlKv1 = GTDsLvw3Udxubqg6Sc2KCJ8[2]
	ee5DPh1cAZ2wuEbtaTx6IGgvROCiVs = A63OvTSBM5xduK4m8yorhjPYqw.truetype(RlYCb3esZKO01,size=ZZ2bue6miDwhPCqf1BnkrtLd)
	hhHqCN4Q8pZRBk = A63OvTSBM5xduK4m8yorhjPYqw.truetype(RlYCb3esZKO01,size=UcarFmHvTA8)
	ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6 = A63OvTSBM5xduK4m8yorhjPYqw.truetype(RlYCb3esZKO01,size=NNsMpPxGu3ZXlKv1)
	sbLGSIZR1jk3Fw = Zm7N6Rv39POxEg8jQnpoKHzlD12G.new('RGBA',(100,100),(255,255,255,0))
	Q6ze7ZiObuPD0GaIhcR3Xw1NtT = v0vrR8AL5UbCzsFQdlo.Draw(sbLGSIZR1jk3Fw)
	QQcuK3ZYPaO16sEj,A2rzbWGmNjhpcfuM = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize('HHH BBB 888 000',font=hhHqCN4Q8pZRBk)
	atjgIbynvWUK6edu1J,n1nJEN8l3zPoVUpOawe0LF = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize('HHH BBB 888 000',font=ee5DPh1cAZ2wuEbtaTx6IGgvROCiVs)
	rr6LE5YfCNkxVsimcbJgIQyoMnXBeK = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	Lr7chxzGgNZk580R = zzPFaJUs14uBk5RiSYL(configuration=rr6LE5YfCNkxVsimcbJgIQyoMnXBeK)
	lVZBbwg1ovWGTpDQ72Y5kSnXtCE = {}
	h4mXRwrVloLWv8qnCkOxQ6c2D9J = locals()
	for VVKGWbIES9Ns5dwuiUBt2re in h4mXRwrVloLWv8qnCkOxQ6c2D9J: lVZBbwg1ovWGTpDQ72Y5kSnXtCE[VVKGWbIES9Ns5dwuiUBt2re] = h4mXRwrVloLWv8qnCkOxQ6c2D9J[VVKGWbIES9Ns5dwuiUBt2re]
	return lVZBbwg1ovWGTpDQ72Y5kSnXtCE
def gcpz9ky3ZolGqm(lVZBbwg1ovWGTpDQ72Y5kSnXtCE,eqbrFhSBWI57nR89w1,mLkRfg3KiToQIdJC1v6zYp7X2wHA,OvSeWj4P9aDBNGlIw81i5TLCExR,Wzpfc28uUC4R,yy42JUqszVIO89i,ztmnTYw0ZQ8pE4,ccxBNrT5HGK6LRh7932S,maLQc7bhwxC5kJE96y3s01KRTM,RRXsBt6uPqUKkQMd9WSIfcVgCNyw):
	for VVKGWbIES9Ns5dwuiUBt2re in lVZBbwg1ovWGTpDQ72Y5kSnXtCE: globals()[VVKGWbIES9Ns5dwuiUBt2re] = lVZBbwg1ovWGTpDQ72Y5kSnXtCE[VVKGWbIES9Ns5dwuiUBt2re]
	global qZIFLdsv4A,dr3JCpnLOw2
	uuxNFTRwvGVW = LCIFdjzi5kVmRwehouHQ.getSetting('av.language.translate')
	if uuxNFTRwvGVW:
		if eqbrFhSBWI57nR89w1=='نعم  Yes': eqbrFhSBWI57nR89w1 = 'Yes'
		elif eqbrFhSBWI57nR89w1=='كلا  No': eqbrFhSBWI57nR89w1 = 'No'
		if mLkRfg3KiToQIdJC1v6zYp7X2wHA=='نعم  Yes': mLkRfg3KiToQIdJC1v6zYp7X2wHA = 'Yes'
		elif mLkRfg3KiToQIdJC1v6zYp7X2wHA=='كلا  No': mLkRfg3KiToQIdJC1v6zYp7X2wHA = 'No'
		if OvSeWj4P9aDBNGlIw81i5TLCExR=='نعم  Yes': OvSeWj4P9aDBNGlIw81i5TLCExR = 'Yes'
		elif OvSeWj4P9aDBNGlIw81i5TLCExR=='كلا  No': OvSeWj4P9aDBNGlIw81i5TLCExR = 'No'
		EIBNGzDg8LUe4w = rQ4PKo0cMIyC7Dbux([eqbrFhSBWI57nR89w1,mLkRfg3KiToQIdJC1v6zYp7X2wHA,OvSeWj4P9aDBNGlIw81i5TLCExR,Wzpfc28uUC4R,yy42JUqszVIO89i])
		if EIBNGzDg8LUe4w: eqbrFhSBWI57nR89w1,mLkRfg3KiToQIdJC1v6zYp7X2wHA,OvSeWj4P9aDBNGlIw81i5TLCExR,Wzpfc28uUC4R,yy42JUqszVIO89i = EIBNGzDg8LUe4w
	if BhTAck1bPFYGuUqRW:
		yy42JUqszVIO89i = yy42JUqszVIO89i.decode('utf8')
		Wzpfc28uUC4R = Wzpfc28uUC4R.decode('utf8')
		eqbrFhSBWI57nR89w1 = eqbrFhSBWI57nR89w1.decode('utf8')
		mLkRfg3KiToQIdJC1v6zYp7X2wHA = mLkRfg3KiToQIdJC1v6zYp7X2wHA.decode('utf8')
		OvSeWj4P9aDBNGlIw81i5TLCExR = OvSeWj4P9aDBNGlIw81i5TLCExR.decode('utf8')
	SSdLzhxIyb7KOqQV = Wzpfc28uUC4R.count('\n')+1
	H6doVn8iGhT3a = uZkGTgP5D1eoNiYCpB7+SSdLzhxIyb7KOqQV*(n1nJEN8l3zPoVUpOawe0LF+ssoi1P0vZyb)-ssoi1P0vZyb
	if yy42JUqszVIO89i:
		UPf3qt0QDgXByLpmW9unl = h9vit8p6KqJ-DKoufbBM2Ewv81z*2
		ZZIVi6qhJ8LRB0svtDHn = A2rzbWGmNjhpcfuM+lluI5c2AK8UDNBZqgnCFtsbmhEwS9
		KCqdpFfgQiymeGlvxL5JS = Lr7chxzGgNZk580R.reshape(yy42JUqszVIO89i)
		if WJC3XhvQN6np9wmSMVRtDilgBezy7:
			AUj3teFgoMY5SrC = oRZAx9eB1VfMLtEh(KCqdpFfgQiymeGlvxL5JS,UcarFmHvTA8,UPf3qt0QDgXByLpmW9unl,ZZIVi6qhJ8LRB0svtDHn)
			YBMaFAGx4dl9ChL02rTi8cnb = ESV4e8zdK512TDJFkAwR(AUj3teFgoMY5SrC)
			peRUr8IMbX6OPK7G2BW0qv = YBMaFAGx4dl9ChL02rTi8cnb.count('\n')+1
			if peRUr8IMbX6OPK7G2BW0qv<6:
				hha4xfoRwVUJEjys6dzAQFHuBt = UPf3qt0QDgXByLpmW9unl
				AUj3teFgoMY5SrC = oRZAx9eB1VfMLtEh(KCqdpFfgQiymeGlvxL5JS,UcarFmHvTA8,hha4xfoRwVUJEjys6dzAQFHuBt,ZZIVi6qhJ8LRB0svtDHn)
				YBMaFAGx4dl9ChL02rTi8cnb = ESV4e8zdK512TDJFkAwR(AUj3teFgoMY5SrC)
				peRUr8IMbX6OPK7G2BW0qv = YBMaFAGx4dl9ChL02rTi8cnb.count('\n')+1
			ZZg2myFuxT8KHCcknX0RW6 = doz8Q5Y4DAC2rhxlwiq37P+peRUr8IMbX6OPK7G2BW0qv*ZZIVi6qhJ8LRB0svtDHn-lluI5c2AK8UDNBZqgnCFtsbmhEwS9
		else:
			ZZg2myFuxT8KHCcknX0RW6 = doz8Q5Y4DAC2rhxlwiq37P+A2rzbWGmNjhpcfuM
			YBMaFAGx4dl9ChL02rTi8cnb = KCqdpFfgQiymeGlvxL5JS.split('\n')[0]
			AUj3teFgoMY5SrC = KCqdpFfgQiymeGlvxL5JS.split('\n')[0]
	else: ZZg2myFuxT8KHCcknX0RW6 = doz8Q5Y4DAC2rhxlwiq37P
	OFn5B8CU3ZYVX9W1jcvtmkoAH2EQRu = CTHdPymV6gfBSYbNe8rUuAnj+H59HcVl0EwgbPY
	if maLQc7bhwxC5kJE96y3s01KRTM:
		qqtINKgRcSwviYl32OnBFV64T1s = QpSksotcHizhfjPlvMVe8DXGN-dRO2vYUpX35IonkmfyuQ
		OFn5B8CU3ZYVX9W1jcvtmkoAH2EQRu += qqtINKgRcSwviYl32OnBFV64T1s
	else: qqtINKgRcSwviYl32OnBFV64T1s = 0
	if eqbrFhSBWI57nR89w1 or mLkRfg3KiToQIdJC1v6zYp7X2wHA or OvSeWj4P9aDBNGlIw81i5TLCExR: OFn5B8CU3ZYVX9W1jcvtmkoAH2EQRu += v1tmn3Er2Q
	if qwScLijCVA8lG6!='UPPER': JUtFHpmXb6G7eI9P = qwScLijCVA8lG6
	else: JUtFHpmXb6G7eI9P = H6doVn8iGhT3a+ZZg2myFuxT8KHCcknX0RW6+OFn5B8CU3ZYVX9W1jcvtmkoAH2EQRu
	mQHnAoOWy3Vkl = JUtFHpmXb6G7eI9P-H6doVn8iGhT3a-OFn5B8CU3ZYVX9W1jcvtmkoAH2EQRu-doz8Q5Y4DAC2rhxlwiq37P
	sbLGSIZR1jk3Fw = Zm7N6Rv39POxEg8jQnpoKHzlD12G.new('RGBA',(h9vit8p6KqJ,JUtFHpmXb6G7eI9P),(255,255,255,0))
	Q6ze7ZiObuPD0GaIhcR3Xw1NtT = v0vrR8AL5UbCzsFQdlo.Draw(sbLGSIZR1jk3Fw)
	if not mLkRfg3KiToQIdJC1v6zYp7X2wHA and eqbrFhSBWI57nR89w1 and OvSeWj4P9aDBNGlIw81i5TLCExR:
		qZIFLdsv4A += 105
		dr3JCpnLOw2 -= 110
	if Wzpfc28uUC4R:
		ZonIYj1cPBJGebK4rA0 = uZkGTgP5D1eoNiYCpB7
		Wzpfc28uUC4R = Xpa41TEJ2Wl.get_display(Lr7chxzGgNZk580R.reshape(Wzpfc28uUC4R))
		ZSkChYJp2a1P = Wzpfc28uUC4R.splitlines()
		for bDuvmIw28GRWVCBaOsT3HneLSt in ZSkChYJp2a1P:
			if bDuvmIw28GRWVCBaOsT3HneLSt:
				S1qen3guxwX,g7hjzv0MxRqc6aJy3rXkdH = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(bDuvmIw28GRWVCBaOsT3HneLSt,font=ee5DPh1cAZ2wuEbtaTx6IGgvROCiVs)
				if CWiEpVvFbcsxNX=='center': bbBmpsUaWOVnoSY8HFlZ = vEnQy6j7FTRchK+(h9vit8p6KqJ-S1qen3guxwX)/2
				elif CWiEpVvFbcsxNX=='right': bbBmpsUaWOVnoSY8HFlZ = vEnQy6j7FTRchK+h9vit8p6KqJ-S1qen3guxwX-AbVF3Irue7oG5dsZaHjP4kY
				elif CWiEpVvFbcsxNX=='left': bbBmpsUaWOVnoSY8HFlZ = vEnQy6j7FTRchK+AbVF3Irue7oG5dsZaHjP4kY
				Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((bbBmpsUaWOVnoSY8HFlZ,ZonIYj1cPBJGebK4rA0),bDuvmIw28GRWVCBaOsT3HneLSt,font=ee5DPh1cAZ2wuEbtaTx6IGgvROCiVs,fill='yellow')
			ZonIYj1cPBJGebK4rA0 += ZZ2bue6miDwhPCqf1BnkrtLd+ssoi1P0vZyb
	if eqbrFhSBWI57nR89w1 or mLkRfg3KiToQIdJC1v6zYp7X2wHA or OvSeWj4P9aDBNGlIw81i5TLCExR:
		kE1Q9gzAl85VnI4XUHJW7fSi = H6doVn8iGhT3a+mQHnAoOWy3Vkl+doz8Q5Y4DAC2rhxlwiq37P+qqtINKgRcSwviYl32OnBFV64T1s+CTHdPymV6gfBSYbNe8rUuAnj
		if eqbrFhSBWI57nR89w1:
			eqbrFhSBWI57nR89w1 = Xpa41TEJ2Wl.get_display(Lr7chxzGgNZk580R.reshape(eqbrFhSBWI57nR89w1))
			hqyXruVdOTHA,EeoAKyqz4BnCRIQY0GFrcu2bpLxH = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(eqbrFhSBWI57nR89w1,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6)
			sQMKqR9EGrWfd7 = qZIFLdsv4A+0*(dr3JCpnLOw2+a8xwDqr3pRPXEKdk9LYibSOHJB0gv)+(a8xwDqr3pRPXEKdk9LYibSOHJB0gv-hqyXruVdOTHA)/2
			Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((sQMKqR9EGrWfd7,kE1Q9gzAl85VnI4XUHJW7fSi),eqbrFhSBWI57nR89w1,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6,fill='yellow')
		if mLkRfg3KiToQIdJC1v6zYp7X2wHA:
			mLkRfg3KiToQIdJC1v6zYp7X2wHA = Xpa41TEJ2Wl.get_display(Lr7chxzGgNZk580R.reshape(mLkRfg3KiToQIdJC1v6zYp7X2wHA))
			ETm7C6GPzUs2,Bj8pRbPdyQWlrxkA = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(mLkRfg3KiToQIdJC1v6zYp7X2wHA,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6)
			vpd8GqlhV1wig306QO7yEszWXfP = qZIFLdsv4A+1*(dr3JCpnLOw2+a8xwDqr3pRPXEKdk9LYibSOHJB0gv)+(a8xwDqr3pRPXEKdk9LYibSOHJB0gv-ETm7C6GPzUs2)/2
			Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((vpd8GqlhV1wig306QO7yEszWXfP,kE1Q9gzAl85VnI4XUHJW7fSi),mLkRfg3KiToQIdJC1v6zYp7X2wHA,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6,fill='yellow')
		if OvSeWj4P9aDBNGlIw81i5TLCExR:
			OvSeWj4P9aDBNGlIw81i5TLCExR = Xpa41TEJ2Wl.get_display(Lr7chxzGgNZk580R.reshape(OvSeWj4P9aDBNGlIw81i5TLCExR))
			dCFEJ5xn43jwI7K8b,uutBDwFjrKHkmYbX7WSpqR5 = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(OvSeWj4P9aDBNGlIw81i5TLCExR,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6)
			ziXNBVGY14P98KvrbmyqxnRHw = qZIFLdsv4A+2*(dr3JCpnLOw2+a8xwDqr3pRPXEKdk9LYibSOHJB0gv)+(a8xwDqr3pRPXEKdk9LYibSOHJB0gv-dCFEJ5xn43jwI7K8b)/2
			Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((ziXNBVGY14P98KvrbmyqxnRHw,kE1Q9gzAl85VnI4XUHJW7fSi),OvSeWj4P9aDBNGlIw81i5TLCExR,font=ASMDzjCFw2hi7GHmKQPOt5Eg1evUo6,fill='yellow')
	if yy42JUqszVIO89i:
		B3BvkUOelt,ai3uP2m0VXLpB = [],[]
		AUj3teFgoMY5SrC = aa1eGSinVfq90B5Y7rN4Ww(AUj3teFgoMY5SrC)
		X7CHivRd43AztoKS9M26Z0ab = AUj3teFgoMY5SrC.split('_sss__newline_')
		for Z1Ew4GKA08HniLUW in X7CHivRd43AztoKS9M26Z0ab:
			rEnmNwAIgLPvuhzMHOYR = ccxBNrT5HGK6LRh7932S
			if   '_sss__lineleft_' in Z1Ew4GKA08HniLUW: rEnmNwAIgLPvuhzMHOYR = 'left'
			elif '_sss__lineright_' in Z1Ew4GKA08HniLUW: rEnmNwAIgLPvuhzMHOYR = 'right'
			elif '_sss__linecenter_' in Z1Ew4GKA08HniLUW: rEnmNwAIgLPvuhzMHOYR = 'center'
			AACWrqIFoSP2Ni = Z1Ew4GKA08HniLUW
			ObDBgZLdo75Yt2k4f6w = SomeI8i56FaDMGPE.findall('_sss__.*?_',Z1Ew4GKA08HniLUW,SomeI8i56FaDMGPE.DOTALL)
			for YDj8JwkO7mWnHepQzb in ObDBgZLdo75Yt2k4f6w: AACWrqIFoSP2Ni = AACWrqIFoSP2Ni.replace(YDj8JwkO7mWnHepQzb,'')
			if AACWrqIFoSP2Ni=='': S1qen3guxwX,g7hjzv0MxRqc6aJy3rXkdH = 0,ZZIVi6qhJ8LRB0svtDHn
			else: S1qen3guxwX,g7hjzv0MxRqc6aJy3rXkdH = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(AACWrqIFoSP2Ni,font=hhHqCN4Q8pZRBk)
			if   rEnmNwAIgLPvuhzMHOYR=='left': mmg6nifTzAwKob1B9 = M8FTsQJ0w19euoXSg4+DKoufbBM2Ewv81z
			elif rEnmNwAIgLPvuhzMHOYR=='right': mmg6nifTzAwKob1B9 = M8FTsQJ0w19euoXSg4+DKoufbBM2Ewv81z+UPf3qt0QDgXByLpmW9unl-S1qen3guxwX
			elif rEnmNwAIgLPvuhzMHOYR=='center': mmg6nifTzAwKob1B9 = M8FTsQJ0w19euoXSg4+DKoufbBM2Ewv81z+(UPf3qt0QDgXByLpmW9unl-S1qen3guxwX)/2
			if mmg6nifTzAwKob1B9<DKoufbBM2Ewv81z: mmg6nifTzAwKob1B9 = M8FTsQJ0w19euoXSg4+DKoufbBM2Ewv81z
			B3BvkUOelt.append(mmg6nifTzAwKob1B9)
			ai3uP2m0VXLpB.append(S1qen3guxwX)
		mmg6nifTzAwKob1B9 = B3BvkUOelt[0]
		luPJigCy6jUFkSm = AUj3teFgoMY5SrC.split('_sss_')
		ojnmYO2RM0AKG4Ca6N = (255,255,255,255)
		qS92AMdzkhrxn = ojnmYO2RM0AKG4Ca6N
		qh5Cc8uDSIr0FOG3,qKPjlhIa0cFsmSkvGe = 0,0
		zdXfwGMjNy = False
		v4Joiysc9S = 0
		Jw4dF1eO0u = H6doVn8iGhT3a+doz8Q5Y4DAC2rhxlwiq37P/2
		if ZZg2myFuxT8KHCcknX0RW6<(mQHnAoOWy3Vkl+doz8Q5Y4DAC2rhxlwiq37P):
			z6E5Qwj8hnZMocBexbydmq9fY0u = (mQHnAoOWy3Vkl+doz8Q5Y4DAC2rhxlwiq37P-ZZg2myFuxT8KHCcknX0RW6)/2
			Jw4dF1eO0u = H6doVn8iGhT3a+doz8Q5Y4DAC2rhxlwiq37P+z6E5Qwj8hnZMocBexbydmq9fY0u-A2rzbWGmNjhpcfuM/2
		for bDuvmIw28GRWVCBaOsT3HneLSt in luPJigCy6jUFkSm:
			if not bDuvmIw28GRWVCBaOsT3HneLSt or (bDuvmIw28GRWVCBaOsT3HneLSt and ord(bDuvmIw28GRWVCBaOsT3HneLSt[0])==65279): continue
			decOWk259R = bDuvmIw28GRWVCBaOsT3HneLSt.split('_newline_',1)
			t8Ci0UrJAnFBwGYVkpQOHT3l = bDuvmIw28GRWVCBaOsT3HneLSt.split('_newcolor',1)
			U4Ejg2zs7VZ9XIqR = bDuvmIw28GRWVCBaOsT3HneLSt.split('_endcolor_',1)
			AAwrSHma1CngNzcBL = bDuvmIw28GRWVCBaOsT3HneLSt.split('_linertl_',1)
			xbmewyt16XiCanMSNdOUkBL7Q8029 = bDuvmIw28GRWVCBaOsT3HneLSt.split('_lineleft_',1)
			M7VGlOCUtrcbIksnTRqDho98S1aB = bDuvmIw28GRWVCBaOsT3HneLSt.split('_lineright_',1)
			yXACnV8fPac3W5E9UNljZLhxs0r = bDuvmIw28GRWVCBaOsT3HneLSt.split('_linecenter_',1)
			if len(decOWk259R)>1:
				v4Joiysc9S += 1
				bDuvmIw28GRWVCBaOsT3HneLSt = decOWk259R[1]
				qh5Cc8uDSIr0FOG3 = 0
				mmg6nifTzAwKob1B9 = B3BvkUOelt[v4Joiysc9S]
				qKPjlhIa0cFsmSkvGe += ZZIVi6qhJ8LRB0svtDHn
				zdXfwGMjNy = False
			elif len(t8Ci0UrJAnFBwGYVkpQOHT3l)>1:
				bDuvmIw28GRWVCBaOsT3HneLSt = t8Ci0UrJAnFBwGYVkpQOHT3l[1]
				qS92AMdzkhrxn = bDuvmIw28GRWVCBaOsT3HneLSt[0:8]
				qS92AMdzkhrxn = '#'+qS92AMdzkhrxn[2:]
				bDuvmIw28GRWVCBaOsT3HneLSt = bDuvmIw28GRWVCBaOsT3HneLSt[9:]
			elif len(U4Ejg2zs7VZ9XIqR)>1:
				bDuvmIw28GRWVCBaOsT3HneLSt = U4Ejg2zs7VZ9XIqR[1]
				qS92AMdzkhrxn = ojnmYO2RM0AKG4Ca6N
			elif len(AAwrSHma1CngNzcBL)>1:
				bDuvmIw28GRWVCBaOsT3HneLSt = AAwrSHma1CngNzcBL[1]
				zdXfwGMjNy = True
				qh5Cc8uDSIr0FOG3 = ai3uP2m0VXLpB[v4Joiysc9S]
			elif len(xbmewyt16XiCanMSNdOUkBL7Q8029)>1: bDuvmIw28GRWVCBaOsT3HneLSt = xbmewyt16XiCanMSNdOUkBL7Q8029[1]
			elif len(M7VGlOCUtrcbIksnTRqDho98S1aB)>1: bDuvmIw28GRWVCBaOsT3HneLSt = M7VGlOCUtrcbIksnTRqDho98S1aB[1]
			elif len(yXACnV8fPac3W5E9UNljZLhxs0r)>1: bDuvmIw28GRWVCBaOsT3HneLSt = yXACnV8fPac3W5E9UNljZLhxs0r[1]
			if bDuvmIw28GRWVCBaOsT3HneLSt:
				SXP2NduJ03EW69OsK4G = Jw4dF1eO0u+qKPjlhIa0cFsmSkvGe
				bDuvmIw28GRWVCBaOsT3HneLSt = Xpa41TEJ2Wl.get_display(bDuvmIw28GRWVCBaOsT3HneLSt)
				S1qen3guxwX,g7hjzv0MxRqc6aJy3rXkdH = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(bDuvmIw28GRWVCBaOsT3HneLSt,font=hhHqCN4Q8pZRBk)
				if zdXfwGMjNy: qh5Cc8uDSIr0FOG3 -= S1qen3guxwX
				CO3lAwq49N0UGjZPc2SuJkbi = mmg6nifTzAwKob1B9+qh5Cc8uDSIr0FOG3
				Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((CO3lAwq49N0UGjZPc2SuJkbi,SXP2NduJ03EW69OsK4G),bDuvmIw28GRWVCBaOsT3HneLSt,font=hhHqCN4Q8pZRBk,fill=qS92AMdzkhrxn)
				if ztmnTYw0ZQ8pE4=='menu_item':
					Q6ze7ZiObuPD0GaIhcR3Xw1NtT.text((CO3lAwq49N0UGjZPc2SuJkbi+1,SXP2NduJ03EW69OsK4G+1),bDuvmIw28GRWVCBaOsT3HneLSt,font=hhHqCN4Q8pZRBk,fill=qS92AMdzkhrxn)
				if not zdXfwGMjNy: qh5Cc8uDSIr0FOG3 += S1qen3guxwX
				if SXP2NduJ03EW69OsK4G>mQHnAoOWy3Vkl+ZZIVi6qhJ8LRB0svtDHn: break
	if ztmnTYw0ZQ8pE4=='menu_item':
		sbLGSIZR1jk3Fw = sbLGSIZR1jk3Fw.resize((200,200))
		MqmYwfGjv17x = uwkb2oYIeNgCqOmvf0UZyMF.copy()
		MqmYwfGjv17x.paste(uO6t58Z4N19bHFTwse,(0,0),mask=sbLGSIZR1jk3Fw)
	else: MqmYwfGjv17x = sbLGSIZR1jk3Fw
	if BhTAck1bPFYGuUqRW: RRXsBt6uPqUKkQMd9WSIfcVgCNyw = RRXsBt6uPqUKkQMd9WSIfcVgCNyw.decode('utf8')
	try: MqmYwfGjv17x.save(RRXsBt6uPqUKkQMd9WSIfcVgCNyw)
	except:
		O7KUD86uGqQTXJVIlmEejSYdH5R9n = Dh9MOxeTj6FW.path.dirname(RRXsBt6uPqUKkQMd9WSIfcVgCNyw)
		try: Dh9MOxeTj6FW.makedirs(O7KUD86uGqQTXJVIlmEejSYdH5R9n)
		except: pass
		MqmYwfGjv17x.save(RRXsBt6uPqUKkQMd9WSIfcVgCNyw)
	return JUtFHpmXb6G7eI9P
def oRZAx9eB1VfMLtEh(wPfy6O2XrhSdIpK7ZA,ddCatzK5WDi1HR3Ylm8,YOUPs2rV81ldG3RpyaTSMFH4JbWet0,roRhEBHqfK6eD3WSMUI4Tkp):
	GkgZe643T1oHCOL0EbKmajD2MJPy,x5UbYJ1s9F4Su0taNhiyR8ZVH,x1cMi9FojQVyq3sUa = '',0,15000
	wPfy6O2XrhSdIpK7ZA = wPfy6O2XrhSdIpK7ZA.replace('[COLOR ','[COLOR:::')
	n1ztxhGoWE0QCg3DMFNcrwJq = A63OvTSBM5xduK4m8yorhjPYqw.truetype(RlYCb3esZKO01,size=ddCatzK5WDi1HR3Ylm8)
	YOUPs2rV81ldG3RpyaTSMFH4JbWet0 -= ddCatzK5WDi1HR3Ylm8*2
	sbLGSIZR1jk3Fw = Zm7N6Rv39POxEg8jQnpoKHzlD12G.new('RGBA',(YOUPs2rV81ldG3RpyaTSMFH4JbWet0,99),(255,255,255,0))
	Q6ze7ZiObuPD0GaIhcR3Xw1NtT = v0vrR8AL5UbCzsFQdlo.Draw(sbLGSIZR1jk3Fw)
	for XmDk1yqHORNLhoYn8pZ2ivQga in wPfy6O2XrhSdIpK7ZA.splitlines():
		x5UbYJ1s9F4Su0taNhiyR8ZVH += roRhEBHqfK6eD3WSMUI4Tkp
		Deqcu7iXhzgEtvRyCHVFQNs08,YXRdNoSmc42etPQGhZybUAg = 0,''
		for rhq3BpuJE7b1GZLdKYVOHP in XmDk1yqHORNLhoYn8pZ2ivQga.split(' '):
			VUzPxo0mIasQ = ESV4e8zdK512TDJFkAwR(' '+rhq3BpuJE7b1GZLdKYVOHP)
			eda1N50oZUARXj3rTDEJmsnO2,F7FOQrMtVBJYmoZi = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(VUzPxo0mIasQ,font=n1ztxhGoWE0QCg3DMFNcrwJq)
			if Deqcu7iXhzgEtvRyCHVFQNs08+eda1N50oZUARXj3rTDEJmsnO2<YOUPs2rV81ldG3RpyaTSMFH4JbWet0:
				if not YXRdNoSmc42etPQGhZybUAg: YXRdNoSmc42etPQGhZybUAg += rhq3BpuJE7b1GZLdKYVOHP
				else: YXRdNoSmc42etPQGhZybUAg += ' '+rhq3BpuJE7b1GZLdKYVOHP
				Deqcu7iXhzgEtvRyCHVFQNs08 += eda1N50oZUARXj3rTDEJmsnO2
			else:
				if eda1N50oZUARXj3rTDEJmsnO2<YOUPs2rV81ldG3RpyaTSMFH4JbWet0:
					YXRdNoSmc42etPQGhZybUAg += '\n '+rhq3BpuJE7b1GZLdKYVOHP
					x5UbYJ1s9F4Su0taNhiyR8ZVH += roRhEBHqfK6eD3WSMUI4Tkp
					Deqcu7iXhzgEtvRyCHVFQNs08 = eda1N50oZUARXj3rTDEJmsnO2
				else:
					while eda1N50oZUARXj3rTDEJmsnO2>YOUPs2rV81ldG3RpyaTSMFH4JbWet0:
						for N6N8FlJCqco7hg in range(1,len(' '+rhq3BpuJE7b1GZLdKYVOHP),1):
							EIagW9qcvulh8kBFmxfoNrJ2ROKz3 = ' '+rhq3BpuJE7b1GZLdKYVOHP[:N6N8FlJCqco7hg]
							LngeSyBsFkTNwi5UXADGjM28 = rhq3BpuJE7b1GZLdKYVOHP[N6N8FlJCqco7hg:]
							rreqB7y02NkdMYcvtiLJh9KA = ESV4e8zdK512TDJFkAwR(EIagW9qcvulh8kBFmxfoNrJ2ROKz3)
							DNl6t0GgqoRnWkQT9wZH,YAMHZabveOkFSUp9Qf = Q6ze7ZiObuPD0GaIhcR3Xw1NtT.textsize(rreqB7y02NkdMYcvtiLJh9KA,font=n1ztxhGoWE0QCg3DMFNcrwJq)
							if Deqcu7iXhzgEtvRyCHVFQNs08+DNl6t0GgqoRnWkQT9wZH>YOUPs2rV81ldG3RpyaTSMFH4JbWet0:
								ffU7HYC2LlBowr0N61xuFSab = eda1N50oZUARXj3rTDEJmsnO2-DNl6t0GgqoRnWkQT9wZH
								YXRdNoSmc42etPQGhZybUAg += EIagW9qcvulh8kBFmxfoNrJ2ROKz3+'\n'
								x5UbYJ1s9F4Su0taNhiyR8ZVH += roRhEBHqfK6eD3WSMUI4Tkp
								eda1N50oZUARXj3rTDEJmsnO2 = ffU7HYC2LlBowr0N61xuFSab
								if ffU7HYC2LlBowr0N61xuFSab>YOUPs2rV81ldG3RpyaTSMFH4JbWet0:
									Deqcu7iXhzgEtvRyCHVFQNs08 = 0
									rhq3BpuJE7b1GZLdKYVOHP = LngeSyBsFkTNwi5UXADGjM28
								else:
									Deqcu7iXhzgEtvRyCHVFQNs08 = ffU7HYC2LlBowr0N61xuFSab
									YXRdNoSmc42etPQGhZybUAg += LngeSyBsFkTNwi5UXADGjM28
								break
				if x5UbYJ1s9F4Su0taNhiyR8ZVH>x1cMi9FojQVyq3sUa: break
		GkgZe643T1oHCOL0EbKmajD2MJPy += '\n'+YXRdNoSmc42etPQGhZybUAg
		if x5UbYJ1s9F4Su0taNhiyR8ZVH>x1cMi9FojQVyq3sUa: break
	GkgZe643T1oHCOL0EbKmajD2MJPy = GkgZe643T1oHCOL0EbKmajD2MJPy[1:]
	GkgZe643T1oHCOL0EbKmajD2MJPy = GkgZe643T1oHCOL0EbKmajD2MJPy.replace('[COLOR:::','[COLOR ')
	return GkgZe643T1oHCOL0EbKmajD2MJPy
def ESV4e8zdK512TDJFkAwR(rhq3BpuJE7b1GZLdKYVOHP):
	if '[' in rhq3BpuJE7b1GZLdKYVOHP and ']' in rhq3BpuJE7b1GZLdKYVOHP:
		ObDBgZLdo75Yt2k4f6w = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		bUXBkhYL3j = SomeI8i56FaDMGPE.findall('\[COLOR .*?\]',rhq3BpuJE7b1GZLdKYVOHP,SomeI8i56FaDMGPE.DOTALL)
		Oz8CJt5W6kyTSwv0uQEM7 = SomeI8i56FaDMGPE.findall('\[COLOR:::.*?\]',rhq3BpuJE7b1GZLdKYVOHP,SomeI8i56FaDMGPE.DOTALL)
		MdENXHRIiDz = ObDBgZLdo75Yt2k4f6w+bUXBkhYL3j+Oz8CJt5W6kyTSwv0uQEM7
		for YDj8JwkO7mWnHepQzb in MdENXHRIiDz: rhq3BpuJE7b1GZLdKYVOHP = rhq3BpuJE7b1GZLdKYVOHP.replace(YDj8JwkO7mWnHepQzb,'')
	return rhq3BpuJE7b1GZLdKYVOHP
def aa1eGSinVfq90B5Y7rN4Ww(yy42JUqszVIO89i):
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('\n','_sss__newline_')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RTL]','_sss__linertl_')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[LEFT]','_sss__lineleft_')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[RIGHT]','_sss__lineright_')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[CENTER]','_sss__linecenter_')
	yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[/COLOR]','_sss__endcolor_')
	TVM8f9oiPvesguraWJQOHYhD = SomeI8i56FaDMGPE.findall('\[COLOR (.*?)\]',yy42JUqszVIO89i,SomeI8i56FaDMGPE.DOTALL)
	for O1IruV437a0i in TVM8f9oiPvesguraWJQOHYhD: yy42JUqszVIO89i = yy42JUqszVIO89i.replace('[COLOR '+O1IruV437a0i+']','_sss__newcolor'+O1IruV437a0i+'_')
	return yy42JUqszVIO89i
def JA5CtfUvW3ljmExIYFog(CH3VkKb5LiB1cZUsoE=''):
	if not CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel('ListItem.Label')
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('[/COLOR]','')
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	jxpt0CM3kdaPNmK2U5nD4OibeoES = SomeI8i56FaDMGPE.findall('\d\d:\d\d ',CH3VkKb5LiB1cZUsoE,SomeI8i56FaDMGPE.DOTALL)
	if jxpt0CM3kdaPNmK2U5nD4OibeoES: CH3VkKb5LiB1cZUsoE = CH3VkKb5LiB1cZUsoE.split(jxpt0CM3kdaPNmK2U5nD4OibeoES[0],1)[1]
	if not CH3VkKb5LiB1cZUsoE: CH3VkKb5LiB1cZUsoE = 'Main Menu'
	return CH3VkKb5LiB1cZUsoE
def Hc4VBGR3XzyljCZWvn(SDQjzmxGXefu3pKyI):
	mvCOk8VQ0ISEKlfwqyiHanY = ''.join(N6N8FlJCqco7hg for N6N8FlJCqco7hg in SDQjzmxGXefu3pKyI if N6N8FlJCqco7hg not in '\/":*?<>|'+xWa5bZGlqdDAFP2y)
	return mvCOk8VQ0ISEKlfwqyiHanY
def rZdXbWjBNth8U(AeSEPxUqNO2R6ytiLzMmXg):
	B2Axl9aIWKdUXNTEtc0YjCR5yPF = AeSEPxUqNO2R6ytiLzMmXg
	if 'adilbo_HTML_encoder' in AeSEPxUqNO2R6ytiLzMmXg:
		HG3k7MBb8axT6XewqYJWml = SomeI8i56FaDMGPE.findall('<script.*?;.*?\'(.*?);', AeSEPxUqNO2R6ytiLzMmXg, SomeI8i56FaDMGPE.S)
		MVNnr9hFqYlK28cmGkLAy = SomeI8i56FaDMGPE.findall('/g.....(.*?)\)', AeSEPxUqNO2R6ytiLzMmXg, SomeI8i56FaDMGPE.S)
		if HG3k7MBb8axT6XewqYJWml and MVNnr9hFqYlK28cmGkLAy:
			YfinAHN3xqVFcy5uJQlB7C = HG3k7MBb8axT6XewqYJWml[0].replace("'",'')
			YfinAHN3xqVFcy5uJQlB7C = YfinAHN3xqVFcy5uJQlB7C.replace("+",'')
			YfinAHN3xqVFcy5uJQlB7C = YfinAHN3xqVFcy5uJQlB7C.replace("\n",'')
			sjLheVA9HkIdyxpERCZ = YfinAHN3xqVFcy5uJQlB7C.split('.')
			B2Axl9aIWKdUXNTEtc0YjCR5yPF = ''
			for auoheCLUmEbjVg5yBOKHn10wY in sjLheVA9HkIdyxpERCZ:
				uukmYO0sin42vIQch = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(auoheCLUmEbjVg5yBOKHn10wY+'==').decode('utf8')
				ost40c9yJ1b2eMLiFnP5DTQYudpg = SomeI8i56FaDMGPE.findall('\d+', uukmYO0sin42vIQch, SomeI8i56FaDMGPE.S)
				if ost40c9yJ1b2eMLiFnP5DTQYudpg:
					zyEY0VxRQ2XP31lSMZ8er = int(ost40c9yJ1b2eMLiFnP5DTQYudpg[0])+int(MVNnr9hFqYlK28cmGkLAy[0])
					B2Axl9aIWKdUXNTEtc0YjCR5yPF = B2Axl9aIWKdUXNTEtc0YjCR5yPF + chr(zyEY0VxRQ2XP31lSMZ8er)
			if ZZxLpCcmqhyT6NuMWelkbSvr0H: B2Axl9aIWKdUXNTEtc0YjCR5yPF = B2Axl9aIWKdUXNTEtc0YjCR5yPF.encode('iso-8859-1').decode('utf8')
	return B2Axl9aIWKdUXNTEtc0YjCR5yPF
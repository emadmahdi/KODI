# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
ToYWiIbruzUaNKRPZLG16cAj = '_MVZ_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
n9dWOLMBkl = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][1]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==180: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==181: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,text)
	elif mode==182: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==183: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==188: rr60PDpqbMehZsYVuHmiAtN = tT9kqZi6Vlxzp28uH0NOJhL3do()
	elif mode==189: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def tT9kqZi6Vlxzp28uH0NOJhL3do():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ztgqWUaDpe8CE9N('','','رسالة من المبرمج',message)
	return
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'بوكس اوفيس موفيز لاند',aaeRjxiYcqOI6Sf8,181,'','','box-office')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أحدث الافلام',aaeRjxiYcqOI6Sf8,181,'','','latest-movies')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'تليفزيون موفيز لاند',aaeRjxiYcqOI6Sf8,181,'','','tv')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'الاكثر مشاهدة',aaeRjxiYcqOI6Sf8,181,'','','top-views')
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'أقوى الافلام الحالية',aaeRjxiYcqOI6Sf8,181,'','','top-movies')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,aaeRjxiYcqOI6Sf8,'',headers,'','MOVIZLAND-MENU-1st')
	items = SomeI8i56FaDMGPE.findall('<h2><a href="(.*?)".*?">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,181)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def KKlnDcetq8Rrp3GY0(url,type=''):
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	elif type=='box-office': L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	elif type=='top-movies': L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('btn-2-overlay(.*?)<style>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	elif type=='top-views': L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	elif type=='tv': L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	else: L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
	if type in ['top-views','top-movies']:
		items = SomeI8i56FaDMGPE.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	else: items = SomeI8i56FaDMGPE.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	oojL40IJtK = []
	HIh214TV6ltv8KusX9mgwRjpSFDd3 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for pjMZ802XQCSxYVk,ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,ozslnOGQXvf2c10AWw9NLy in items:
		if type in ['top-views','top-movies']:
			pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,spdYctk0fWD1Z,title = pjMZ802XQCSxYVk,ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,ozslnOGQXvf2c10AWw9NLy
		else: pjMZ802XQCSxYVk,title,ZcAK0askvzIWr4R,spdYctk0fWD1Z = pjMZ802XQCSxYVk,ZUshXQ1nwIHbLMP,v7vlUSFEWZs8Bd5,ozslnOGQXvf2c10AWw9NLy
		ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.replace('?view=true','')
		title = dCFP41Kxv9j8EHM(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			iHPhR4wCQ1oINaL = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|الحلقه) \d+',title,SomeI8i56FaDMGPE.DOTALL)
			if iHPhR4wCQ1oINaL:
				title = '_MOD_' + iHPhR4wCQ1oINaL[0][0]
				if title not in oojL40IJtK:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,183,pjMZ802XQCSxYVk)
					oojL40IJtK.append(title)
		elif any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in HIh214TV6ltv8KusX9mgwRjpSFDd3):
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R + '?servers=' + spdYctk0fWD1Z
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,182,pjMZ802XQCSxYVk)
		else:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R + '?servers=' + spdYctk0fWD1Z
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,183,pjMZ802XQCSxYVk)
	if type=='':
		items = SomeI8i56FaDMGPE.findall('\n<li><a href="(.*?)".*?>(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = dCFP41Kxv9j8EHM(title)
			title = title.replace('الصفحة ','')
			if title!='':
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,181)
	return
def ooLCwrlF3n0vBjpA(url):
	vfIB6ib8q1hFX5GweRrVPNTjY2E = url.split('?servers=')[0]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','MOVIZLAND-EPISODES-1st')
	L0Uwx52bTBM = SomeI8i56FaDMGPE.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	title,fYZzomwSjkedXVcEvLDqKHMt9rFnN,pjMZ802XQCSxYVk = L0Uwx52bTBM[0]
	name = SomeI8i56FaDMGPE.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,SomeI8i56FaDMGPE.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="episodesNumbers"(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R in items:
			ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
			title = SomeI8i56FaDMGPE.findall('(الحلقة|الحلقه)-([0-9]+)',ZcAK0askvzIWr4R.split('/')[-2],SomeI8i56FaDMGPE.DOTALL)
			if not title: title = SomeI8i56FaDMGPE.findall('()-([0-9]+)',ZcAK0askvzIWr4R.split('/')[-2],SomeI8i56FaDMGPE.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,182,pjMZ802XQCSxYVk)
	if not items:
		title = dCFP41Kxv9j8EHM(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,url,182,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	esJu5o91dDibMxQzlfmKR6hAPqyY2 = url.split('?servers=')
	vfIB6ib8q1hFX5GweRrVPNTjY2E = esJu5o91dDibMxQzlfmKR6hAPqyY2[0]
	del esJu5o91dDibMxQzlfmKR6hAPqyY2[0]
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,vfIB6ib8q1hFX5GweRrVPNTjY2E,'',headers,'','MOVIZLAND-PLAY-1st')
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('font-size: 25px;" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)[0]
	if ZcAK0askvzIWr4R not in esJu5o91dDibMxQzlfmKR6hAPqyY2: esJu5o91dDibMxQzlfmKR6hAPqyY2.append(ZcAK0askvzIWr4R)
	aFyREdMQk7Ys95rX6uJieDGLS2 = []
	for ZcAK0askvzIWr4R in esJu5o91dDibMxQzlfmKR6hAPqyY2:
		if '://moshahda.' in ZcAK0askvzIWr4R:
			SCKerq5iFZVaXf34jRIdvOGWo6uT = ZcAK0askvzIWr4R
			aFyREdMQk7Ys95rX6uJieDGLS2.append(SCKerq5iFZVaXf34jRIdvOGWo6uT+'?named=Main')
	for ZcAK0askvzIWr4R in esJu5o91dDibMxQzlfmKR6hAPqyY2:
		if '://vb.movizland.' in ZcAK0askvzIWr4R:
			BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,ZcAK0askvzIWr4R,'',headers,'','MOVIZLAND-PLAY-2nd')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.decode('windows-1256').encode('utf8')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
			if pDTlIgyewF1XV69R8kd:
				VyGZnrjdiz,DGcdskjBKixNSwlW5O7rpM = [],[]
				if len(pDTlIgyewF1XV69R8kd)==1:
					title = ''
					L0Uwx52bTBM = BsJ71WIxDtdFKveTcRPrqM4Cwb
				else:
					for L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
						K1KV5U7JFXNPsl4h0HBd = SomeI8i56FaDMGPE.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
						if K1KV5U7JFXNPsl4h0HBd: L0Uwx52bTBM = 'src="/uploads/13721411411.png"  \n  ' + K1KV5U7JFXNPsl4h0HBd[0][1]
						K1KV5U7JFXNPsl4h0HBd = SomeI8i56FaDMGPE.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
						if K1KV5U7JFXNPsl4h0HBd: L0Uwx52bTBM = 'src="/uploads/13721411411.png"  \n  ' + K1KV5U7JFXNPsl4h0HBd[0]
						K1KV5U7JFXNPsl4h0HBd = SomeI8i56FaDMGPE.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
						if K1KV5U7JFXNPsl4h0HBd: L0Uwx52bTBM = K1KV5U7JFXNPsl4h0HBd[0] + '  \n  src="/uploads/13721411411.png"'
						T6WPsXn4hqgof = SomeI8i56FaDMGPE.findall('<(.*?)http://up.movizland.(online|com)/uploads/',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
						title = SomeI8i56FaDMGPE.findall('> *([^<>]+) *<',T6WPsXn4hqgof[0][0],SomeI8i56FaDMGPE.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						VyGZnrjdiz.append(title)
					I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('أختر الفيديو المطلوب:', VyGZnrjdiz)
					if I7mfbGiWNFcBVJOn == -1 : return
					title = VyGZnrjdiz[I7mfbGiWNFcBVJOn]
					L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[I7mfbGiWNFcBVJOn]
				ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('href="(http://moshahda\..*?/\w+.html)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				U0TnNKBAERyfX = ZcAK0askvzIWr4R[0]
				aFyREdMQk7Ys95rX6uJieDGLS2.append(U0TnNKBAERyfX+'?named=Forum')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('ـ','')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				L0Uwx52bTBM = L0Uwx52bTBM.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Z8m0wqntHF92VRzi76DNxQcOEJ = SomeI8i56FaDMGPE.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
				for Z6apJPHVL7d2bgs8U5EXm in Z8m0wqntHF92VRzi76DNxQcOEJ:
					type = SomeI8i56FaDMGPE.findall(' typetype="(.*?)" ',Z6apJPHVL7d2bgs8U5EXm)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = SomeI8i56FaDMGPE.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',Z6apJPHVL7d2bgs8U5EXm,SomeI8i56FaDMGPE.DOTALL)
					for MXxcbgshOfqRnJ2C5,ZcAK0askvzIWr4R in items:
						title = SomeI8i56FaDMGPE.findall('(\w+[ \w]*)<',MXxcbgshOfqRnJ2C5)
						title = title[-1]
						ZcAK0askvzIWr4R = ZcAK0askvzIWr4R + '?named=' + title + type
						aFyREdMQk7Ys95rX6uJieDGLS2.append(ZcAK0askvzIWr4R)
	XuItmjBhoUDa3fRO9nQsbNYrpG1cdv = vfIB6ib8q1hFX5GweRrVPNTjY2E.replace(aaeRjxiYcqOI6Sf8,n9dWOLMBkl)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(IIbavC96MQ1nHq3Pjx,XuItmjBhoUDa3fRO9nQsbNYrpG1cdv,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = SomeI8i56FaDMGPE.findall('" href="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if items:
		J3JLfgicSojOBKtM = items[-1]
		aFyREdMQk7Ys95rX6uJieDGLS2.append(J3JLfgicSojOBKtM+'?named=Mobile')
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(aFyREdMQk7Ys95rX6uJieDGLS2,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','+')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = aax105ZrnJG(jj0C6IlvPFh,aaeRjxiYcqOI6Sf8,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = SomeI8i56FaDMGPE.findall('<option value="(.*?)">(.*?)</option>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	V30iWpBklfoUM2Tc1dZ5qIHRb8vtL = [ '' ]
	NEurfT6C7vg = [ 'الكل وبدون فلتر' ]
	for g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,title in items:
		V30iWpBklfoUM2Tc1dZ5qIHRb8vtL.append(g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B)
		NEurfT6C7vg.append(title)
	if g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر الفلتر المناسب:', NEurfT6C7vg)
		if I7mfbGiWNFcBVJOn == -1 : return
		g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = V30iWpBklfoUM2Tc1dZ5qIHRb8vtL[I7mfbGiWNFcBVJOn]
	else: g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = ''
	url = aaeRjxiYcqOI6Sf8 + '/?s='+search+'&mcat='+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B
	KKlnDcetq8Rrp3GY0(url)
	return
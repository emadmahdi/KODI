# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from A7vZ89SBgK import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࡏࡎࡊࡖࠪ૮")
xrFqGMab4uLKZcS(Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࡎࡐࡖࡌࡇࡊ࠭૯"),FZBX5WcC3msIDv4hobLd8(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧ૰"))
hpnDbQ9u8ztEJ0fBaxv = miyYvukojaRTM0gDtbCfK(StrQOzK40pE8Dbgdj95U)
DQs7pSx58I4n,x0LXdHBFwj7EtMfu,xTFHrZ1nGWa9fdqsSA5y4htgJNmX,h9h3xqMnC56kjUOKGgBbWQ4,NmX0ZP715phHsSiCzvxR3IB,SSGEc76fBan2,FbewQr7IVXqN0ijhOtm2vAnauzZT,yboV6YS5n9WtE1arxOed,MIe5q0WmGnJF9wp2tfk = hpnDbQ9u8ztEJ0fBaxv
JtU3cDMkSF = int(h9h3xqMnC56kjUOKGgBbWQ4)
p5YZ2bOGk7KPuMrD4acHlFUdBCN = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ૱"))
p5YZ2bOGk7KPuMrD4acHlFUdBCN = p5YZ2bOGk7KPuMrD4acHlFUdBCN.replace(H02Qqy4XO9L3Dui6S8PGWxJt,eaF2N0jWLdvHIs8r(u"ࠩࠪ૲")).replace(spTWfEz2PU9AL,Jbu2G0Qax8PYWpg(u"ࠪࠫ૳"))
if JtU3cDMkSF==FZBX5WcC3msIDv4hobLd8(u"࠳࠸࠳ଛ"): RkL9ljZpIhdrutK0OmN7Uc = RS7ZoyGAq1c(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ૴")+Y0Uhv2t8E67+LsG7EDcei1gMShH2aVOCo(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬ૵")+StEXpdf2BL3wkh1izc8snHFMNAPWql+onweDvmTOUj(u"࠭ࠠ࡞ࠩ૶")
else:
	HOdgLIni960SmxGfE4UJtXsa = aDebGvrkdptunqTM8m4(StrQOzK40pE8Dbgdj95U).replace(d0HDrq8Rtk16AlInw4TXb(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ૷"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩ૸")).replace(d0HDrq8Rtk16AlInw4TXb(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬૹ"),Y5npATFarf1H9wBjc87(u"ࠪࠫૺ"))
	HOdgLIni960SmxGfE4UJtXsa = HOdgLIni960SmxGfE4UJtXsa.replace(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ૻ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠭ૼ")).strip(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࠠࠨ૽"))
	HOdgLIni960SmxGfE4UJtXsa = HOdgLIni960SmxGfE4UJtXsa.replace(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧࠡࠢࠣࠤࠬ૾"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠢࠪ૿")).replace(LsG7EDcei1gMShH2aVOCo(u"ࠩࠣࠤࠥ࠭଀"),onweDvmTOUj(u"ࠪࠤࠬଁ")).replace(Q2ZyGqCNYsftTc4MR7n(u"ࠫࠥࠦࠧଂ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࠦࠧଃ"))
	RkL9ljZpIhdrutK0OmN7Uc = mtEXp14ijx(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬ଄")+p5YZ2bOGk7KPuMrD4acHlFUdBCN+eaF2N0jWLdvHIs8r(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧଅ")+h9h3xqMnC56kjUOKGgBbWQ4+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨଆ")+HOdgLIni960SmxGfE4UJtXsa+QQSULIva4ljNO73mFcWw(u"ࠩࠣࡡࠬଇ")
xrFqGMab4uLKZcS(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪଈ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+RkL9ljZpIhdrutK0OmN7Uc)
fdk8NJMDbPh = LCIFdjzi5kVmRwehouHQ.getSetting(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨଉ"))
Q3PT7xKFt6ZCy9NdopYrAeR0vfU = eaF2N0jWLdvHIs8r(u"ࡆࡢ࡮ࡶࡩଡ") if fdk8NJMDbPh==Y0Uhv2t8E67 else FZBX5WcC3msIDv4hobLd8(u"࡚ࡲࡶࡧଠ")
if not Q3PT7xKFt6ZCy9NdopYrAeR0vfU and JtU3cDMkSF in [onweDvmTOUj(u"࠴࠶࠹ଜ"),FZBX5WcC3msIDv4hobLd8(u"࠺࠵࠺ଝ")]:
	ffFDzprmdb14nE6ekuILVM = str(MIe5q0WmGnJF9wp2tfk[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬଊ")])
	HmvY29bj4dNgF7wZqr1lzkeQxiEasu = q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡩࡱࡶࡹࠫଋ") if JtU3cDMkSF==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠸࠻ଞ") else Q2ZyGqCNYsftTc4MR7n(u"ࠧ࡮࠵ࡸࠫଌ")
	Jhilqrw8nstB7 = LCIFdjzi5kVmRwehouHQ.getSetting(Y5npATFarf1H9wBjc87(u"ࠨࡣࡹ࠲ࠬ଍")+HmvY29bj4dNgF7wZqr1lzkeQxiEasu+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ଎")+ffFDzprmdb14nE6ekuILVM)
	LF56ulcIz2kYqE83Cf = LCIFdjzi5kVmRwehouHQ.getSetting(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࡥࡻ࠴ࠧଏ")+HmvY29bj4dNgF7wZqr1lzkeQxiEasu+RS7ZoyGAq1c(u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧଐ")+ffFDzprmdb14nE6ekuILVM)
	if Jhilqrw8nstB7 or LF56ulcIz2kYqE83Cf:
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX += hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࢂࠧ଑")
		if Jhilqrw8nstB7: xTFHrZ1nGWa9fdqsSA5y4htgJNmX += WWbmNvI40sM9Khlp25Ae(u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ଒")+Jhilqrw8nstB7
		if LF56ulcIz2kYqE83Cf: xTFHrZ1nGWa9fdqsSA5y4htgJNmX += gy9NA3CROZolfEt4vVzMr(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪଓ")+LF56ulcIz2kYqE83Cf
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(FZBX5WcC3msIDv4hobLd8(u"ࠨࡾࠩࠫଔ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠩࡿࠫକ"))
	eeyo3dfKaMLXQJphlqvIU6tm5rRj = LCIFdjzi5kVmRwehouHQ.getSetting(NQ4hg16DPUxtOyo5iGb(u"ࠪࡥࡻ࠴ࠧଖ")+HmvY29bj4dNgF7wZqr1lzkeQxiEasu+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭ଗ")+ffFDzprmdb14nE6ekuILVM)
	if eeyo3dfKaMLXQJphlqvIU6tm5rRj:
		EEH42wWuLfceNOxvVC = SomeI8i56FaDMGPE.findall(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨଘ"),xTFHrZ1nGWa9fdqsSA5y4htgJNmX,SomeI8i56FaDMGPE.DOTALL)
		xTFHrZ1nGWa9fdqsSA5y4htgJNmX = xTFHrZ1nGWa9fdqsSA5y4htgJNmX.replace(EEH42wWuLfceNOxvVC[B2vCEI9FAVP15R8eUbDJdySc(u"࠵ଟ")],eeyo3dfKaMLXQJphlqvIU6tm5rRj)
	HmvY29bj4dNgF7wZqr1lzkeQxiEasu = HmvY29bj4dNgF7wZqr1lzkeQxiEasu.upper()
	kFygcp2jqSUCiNRnur71xMZI96(xTFHrZ1nGWa9fdqsSA5y4htgJNmX,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,DQs7pSx58I4n)
else:
	from FJKmvLp8Tl import xmYBAMKujEkvWUpV,pmefPx7TZo1HYKUBJ9azqhMcQFid,f8CtAYn6NTQc
	zi68Y9T7ngdIXKALbv3fjVEeOJm = d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧଙ")
	xmYBAMKujEkvWUpV(NQ4hg16DPUxtOyo5iGb(u"ࠧࡴࡶࡤࡶࡹ࠭ଚ"))
	try: pmefPx7TZo1HYKUBJ9azqhMcQFid(hpnDbQ9u8ztEJ0fBaxv,p5YZ2bOGk7KPuMrD4acHlFUdBCN)
	except Exception as ESuf43dwJmkx1NtG: zi68Y9T7ngdIXKALbv3fjVEeOJm = AXKHbaOBizntvlsSqP3E5D.format_exc()
	f8CtAYn6NTQc(zi68Y9T7ngdIXKALbv3fjVEeOJm)
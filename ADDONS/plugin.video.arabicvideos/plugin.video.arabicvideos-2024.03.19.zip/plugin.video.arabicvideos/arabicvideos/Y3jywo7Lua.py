# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'DAILYMOTION'
ToYWiIbruzUaNKRPZLG16cAj = '_DLM_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
n9dWOLMBkl = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][1]
def GI13aCFr0qimdOT(mode,url,text,type,SSGEc76fBan2):
	if	 mode==400: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==401: rr60PDpqbMehZsYVuHmiAtN = aX4QJYv56r(url,text)
	elif mode==402: rr60PDpqbMehZsYVuHmiAtN = LOtSgEC7fqa9ozKipWXmQhkZxFs(url,text)
	elif mode==403: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,text)
	elif mode==404: rr60PDpqbMehZsYVuHmiAtN = swoD8JG20r9Fku64aXAQ(text,SSGEc76fBan2)
	elif mode==405: rr60PDpqbMehZsYVuHmiAtN = G72KTIet4QBdbjUPOl6RhXA5finMvu(text,SSGEc76fBan2)
	elif mode==406: rr60PDpqbMehZsYVuHmiAtN = PuRiaWIfl9woxpHDQkC(text,SSGEc76fBan2)
	elif mode==407: rr60PDpqbMehZsYVuHmiAtN = e1EK07BuhzNdO63vsTUI(url,SSGEc76fBan2)
	elif mode==408: rr60PDpqbMehZsYVuHmiAtN = RSnWHBkmrPsixa0GXfqAUzDKvj2O(url,SSGEc76fBan2)
	elif mode==409: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text,SSGEc76fBan2)
	elif mode==411: rr60PDpqbMehZsYVuHmiAtN = niK3eUVpPtMlf6DuGzEHdqjr41(url,text)
	elif mode==412: rr60PDpqbMehZsYVuHmiAtN = QA38k5wn09RPcY(text,SSGEc76fBan2)
	elif mode==413: rr60PDpqbMehZsYVuHmiAtN = o1Egm4klfZXaviepQsKOn6LHbDU8AV(url,SSGEc76fBan2)
	elif mode==414: rr60PDpqbMehZsYVuHmiAtN = DnHquZxzPvTWOV9yRoj87bUd(text)
	elif mode==415: rr60PDpqbMehZsYVuHmiAtN = V2g1WZ3J7UKhvD6N5Olt8bkwIsaM(text,SSGEc76fBan2)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الرئيسية','',414)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def LOtSgEC7fqa9ozKipWXmQhkZxFs(url,Vbj25gIOTdPhSu4nka9JCY):
	if '/dm_' in url:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = ttpgqJBdkoxeKOcwaiP.headers
		if 'Location' in list(headers.keys()): url = aaeRjxiYcqOI6Sf8+headers['Location']
	Vbj25gIOTdPhSu4nka9JCY = '[COLOR FFC89008]'+Vbj25gIOTdPhSu4nka9JCY+'[/COLOR]'
	Vbj25gIOTdPhSu4nka9JCY = f6dL2ob4FuQe(Vbj25gIOTdPhSu4nka9JCY)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: بث حي',url,411,'','','channel_lives_now')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: آخر الفيديوهات',url+'/videos',408)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: المميزة',url,411,'','','channel_featured_videos')
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: قوائم التشغيل',url+'/playlists',407)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def f6dL2ob4FuQe(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = c8Fvb4IfHW9XkG1mLK5Z(title)
	return title
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url,YmaiRV2dCwZnS87U):
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK([url],HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def swoD8JG20r9Fku64aXAQ(search,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysearchwords',search)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	if sort=='': ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysortmethod','')
	else: ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = aaeRjxiYcqOI6Sf8+'/search/'+search+'/videos'
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"videos"(.*?)"VideoConnection"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,title,gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY,DD1IVWFZbr7TlzYto5s,pjMZ802XQCSxYVk in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
			if '"' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace('"','')
			if '"' in gof74pV0mH: gof74pV0mH = gof74pV0mH.replace('"','')
			if '"' in Vbj25gIOTdPhSu4nka9JCY: Vbj25gIOTdPhSu4nka9JCY = Vbj25gIOTdPhSu4nka9JCY.replace('"','')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+id
			title = f6dL2ob4FuQe(title)
			YmaiRV2dCwZnS87U = gof74pV0mH+'::'+Vbj25gIOTdPhSu4nka9JCY
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s,YmaiRV2dCwZnS87U)
		if '"hasNextPage":true' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,404,'',SSGEc76fBan2,search)
	return
def G72KTIet4QBdbjUPOl6RhXA5finMvu(search,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysearchwords',search)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	url = aaeRjxiYcqOI6Sf8+'/search/'+search+'/playlists'
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	items = SomeI8i56FaDMGPE.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for id,name,KZvM6GjrqQF18xYW0L4n2StuEOVaP,gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY,pjMZ802XQCSxYVk,count in items:
		if '"' in KZvM6GjrqQF18xYW0L4n2StuEOVaP: KZvM6GjrqQF18xYW0L4n2StuEOVaP = KZvM6GjrqQF18xYW0L4n2StuEOVaP.replace('"','')
		if '"' in gof74pV0mH: gof74pV0mH = gof74pV0mH.replace('"','')
		if '"' in Vbj25gIOTdPhSu4nka9JCY: Vbj25gIOTdPhSu4nka9JCY = Vbj25gIOTdPhSu4nka9JCY.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
		if '"' in count: count = count.replace('"','')
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = f6dL2ob4FuQe(title)
		YmaiRV2dCwZnS87U = gof74pV0mH+'::'+Vbj25gIOTdPhSu4nka9JCY
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,401,pjMZ802XQCSxYVk,'',YmaiRV2dCwZnS87U)
	if '"hasNextPage":true' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
		SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,405,'',SSGEc76fBan2,search)
	return
def PuRiaWIfl9woxpHDQkC(search,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysearchwords',search)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	url = aaeRjxiYcqOI6Sf8+'/search/'+search+'/channels'
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"channels"(.*?)"ChannelConnection"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,name,pjMZ802XQCSxYVk in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+id
			title = 'CHNL:  '+name
			title = f6dL2ob4FuQe(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,402,pjMZ802XQCSxYVk,'',name)
		if '"hasNextPage":true' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,406,'',SSGEc76fBan2,search)
	return
def DnHquZxzPvTWOV9yRoj87bUd(rGboR8wln1QyVe):
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	YY0QqVKEhGunm2O19HRrMjyBcv = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	if YY0QqVKEhGunm2O19HRrMjyBcv:
		FuWH3SGtT1Y = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',YY0QqVKEhGunm2O19HRrMjyBcv)
		sgfTlyIkEmVqtAhpBJn20oa6 = FuWH3SGtT1Y['data']['home']['neon']['sections']['edges']
		if not rGboR8wln1QyVe:
			MoayAiYNOeJLEr7XFI = []
			for Ffky3RsrQPtg0 in sgfTlyIkEmVqtAhpBJn20oa6:
				RzpSfwWMoND3UXlhG9ZnJe2 = Ffky3RsrQPtg0['node']['title']
				if RzpSfwWMoND3UXlhG9ZnJe2 not in MoayAiYNOeJLEr7XFI: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+RzpSfwWMoND3UXlhG9ZnJe2,'',414,'','',RzpSfwWMoND3UXlhG9ZnJe2)
				MoayAiYNOeJLEr7XFI.append(RzpSfwWMoND3UXlhG9ZnJe2)
		else:
			for Ffky3RsrQPtg0 in sgfTlyIkEmVqtAhpBJn20oa6:
				RzpSfwWMoND3UXlhG9ZnJe2 = Ffky3RsrQPtg0['node']['title']
				if RzpSfwWMoND3UXlhG9ZnJe2==rGboR8wln1QyVe:
					BQ0y3CKV7dhPU9XoWuqt = Ffky3RsrQPtg0['node']['components']['edges']
					for q3hDvU4C7VzN9 in BQ0y3CKV7dhPU9XoWuqt:
						DD1IVWFZbr7TlzYto5s = str(q3hDvU4C7VzN9['node']['duration'])
						title = c8Fvb4IfHW9XkG1mLK5Z(q3hDvU4C7VzN9['node']['title'])
						title = title.replace('\/','/')
						AdDvkOKSgBn = q3hDvU4C7VzN9['node']['xid']
						pjMZ802XQCSxYVk = q3hDvU4C7VzN9['node']['thumbnailx480']
						pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('\/','/')
						ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+AdDvkOKSgBn
						UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s)
	return
def V2g1WZ3J7UKhvD6N5Olt8bkwIsaM(search,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysearchwords',search)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	url = aaeRjxiYcqOI6Sf8+'/search/'+search+'/lives'
	YY0QqVKEhGunm2O19HRrMjyBcv = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	if YY0QqVKEhGunm2O19HRrMjyBcv:
		FuWH3SGtT1Y = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',YY0QqVKEhGunm2O19HRrMjyBcv)
		try: sgfTlyIkEmVqtAhpBJn20oa6 = FuWH3SGtT1Y['data']['search']['lives']['edges']
		except: sgfTlyIkEmVqtAhpBJn20oa6 = []
		for Ffky3RsrQPtg0 in sgfTlyIkEmVqtAhpBJn20oa6:
			name = Ffky3RsrQPtg0['node']['title']
			AdDvkOKSgBn = Ffky3RsrQPtg0['node']['xid']
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+AdDvkOKSgBn
			UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'LIVE: '+name,ZcAK0askvzIWr4R,403)
		if '"hasNextPage":true' in YY0QqVKEhGunm2O19HRrMjyBcv:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,415,'',SSGEc76fBan2,search)
	return
def QA38k5wn09RPcY(search,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysearchwords',search)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	url = aaeRjxiYcqOI6Sf8+'/search/'+search+'/topics'
	YY0QqVKEhGunm2O19HRrMjyBcv = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	if YY0QqVKEhGunm2O19HRrMjyBcv:
		FuWH3SGtT1Y = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',YY0QqVKEhGunm2O19HRrMjyBcv)
		try: sgfTlyIkEmVqtAhpBJn20oa6 = FuWH3SGtT1Y['data']['search']['topics']['edges']
		except: sgfTlyIkEmVqtAhpBJn20oa6 = []
		for Ffky3RsrQPtg0 in sgfTlyIkEmVqtAhpBJn20oa6:
			name = Ffky3RsrQPtg0['node']['name']
			AdDvkOKSgBn = Ffky3RsrQPtg0['node']['xid']
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/topic/'+AdDvkOKSgBn
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'TOPIC: '+name,ZcAK0askvzIWr4R,413)
		if '"hasNextPage":true' in YY0QqVKEhGunm2O19HRrMjyBcv:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,412,'',SSGEc76fBan2,search)
	return
def o1Egm4klfZXaviepQsKOn6LHbDU8AV(url,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	AdDvkOKSgBn = url.split('/')[-1]
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mytopicid',AdDvkOKSgBn)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	YY0QqVKEhGunm2O19HRrMjyBcv = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	if YY0QqVKEhGunm2O19HRrMjyBcv:
		FuWH3SGtT1Y = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',YY0QqVKEhGunm2O19HRrMjyBcv)
		sgfTlyIkEmVqtAhpBJn20oa6 = FuWH3SGtT1Y['data']['topic']['videos']['edges']
		for Ffky3RsrQPtg0 in sgfTlyIkEmVqtAhpBJn20oa6:
			DD1IVWFZbr7TlzYto5s = str(Ffky3RsrQPtg0['node']['duration'])
			title = c8Fvb4IfHW9XkG1mLK5Z(Ffky3RsrQPtg0['node']['title'])
			title = title.replace('\/','/')
			AdDvkOKSgBn = Ffky3RsrQPtg0['node']['xid']
			pjMZ802XQCSxYVk = Ffky3RsrQPtg0['node']['thumbnailx480']
			pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('\/','/')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+AdDvkOKSgBn
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s)
		if '"hasNextPage":true' in YY0QqVKEhGunm2O19HRrMjyBcv:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,413,'',SSGEc76fBan2)
	return
def aX4QJYv56r(url,YmaiRV2dCwZnS87U):
	id = url.split('/')[-1]
	gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY = YmaiRV2dCwZnS87U.split('::',1)
	ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+gof74pV0mH
	Vbj25gIOTdPhSu4nka9JCY = f6dL2ob4FuQe(Vbj25gIOTdPhSu4nka9JCY)
	title = '[COLOR FFC89008]OWNER:  '+Vbj25gIOTdPhSu4nka9JCY+'[/COLOR]'
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,402,'','',Vbj25gIOTdPhSu4nka9JCY)
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('myplaylistid',id)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"collection_videos"(.*?)"SectionEdge"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,title,DD1IVWFZbr7TlzYto5s,pjMZ802XQCSxYVk,gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
			if '"' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace('"','')
			if '"' in gof74pV0mH: gof74pV0mH = gof74pV0mH.replace('"','')
			if '"' in Vbj25gIOTdPhSu4nka9JCY: Vbj25gIOTdPhSu4nka9JCY = Vbj25gIOTdPhSu4nka9JCY.replace('"','')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+id
			title = f6dL2ob4FuQe(title)
			YmaiRV2dCwZnS87U = gof74pV0mH+'::'+Vbj25gIOTdPhSu4nka9JCY
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s,YmaiRV2dCwZnS87U)
	return
def RSnWHBkmrPsixa0GXfqAUzDKvj2O(url,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mychannelid',iBI9R4HkNw6pZvdqMtGTjnUEXulhxy)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysortmethod',sort)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,title,DD1IVWFZbr7TlzYto5s,gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY,pjMZ802XQCSxYVk in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
			if '"' in DD1IVWFZbr7TlzYto5s: DD1IVWFZbr7TlzYto5s = DD1IVWFZbr7TlzYto5s.replace('"','')
			if '"' in gof74pV0mH: gof74pV0mH = gof74pV0mH.replace('"','')
			if '"' in Vbj25gIOTdPhSu4nka9JCY: Vbj25gIOTdPhSu4nka9JCY = Vbj25gIOTdPhSu4nka9JCY.replace('"','')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+id
			title = f6dL2ob4FuQe(title)
			YmaiRV2dCwZnS87U = gof74pV0mH+'::'+Vbj25gIOTdPhSu4nka9JCY
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s,YmaiRV2dCwZnS87U)
		if '"hasNextPage":true' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,408,'',SSGEc76fBan2)
	return
def e1EK07BuhzNdO63vsTUI(url,SSGEc76fBan2=''):
	if SSGEc76fBan2=='': SSGEc76fBan2 = '1'
	iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mychannelid',iBI9R4HkNw6pZvdqMtGTjnUEXulhxy)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagelimit','40')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mypagenumber',SSGEc76fBan2)
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mysortmethod',sort)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for id,name,pjMZ802XQCSxYVk,count,KZvM6GjrqQF18xYW0L4n2StuEOVaP,gof74pV0mH,Vbj25gIOTdPhSu4nka9JCY in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in pjMZ802XQCSxYVk: pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in KZvM6GjrqQF18xYW0L4n2StuEOVaP: KZvM6GjrqQF18xYW0L4n2StuEOVaP = KZvM6GjrqQF18xYW0L4n2StuEOVaP.replace('"','')
			if '"' in gof74pV0mH: gof74pV0mH = gof74pV0mH.replace('"','')
			if '"' in Vbj25gIOTdPhSu4nka9JCY: Vbj25gIOTdPhSu4nka9JCY = Vbj25gIOTdPhSu4nka9JCY.replace('"','')
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = f6dL2ob4FuQe(title)
			YmaiRV2dCwZnS87U = gof74pV0mH+'::'+Vbj25gIOTdPhSu4nka9JCY
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,401,pjMZ802XQCSxYVk,'',YmaiRV2dCwZnS87U)
		if '"hasNextPage":true' in BsJ71WIxDtdFKveTcRPrqM4Cwb:
			SSGEc76fBan2 = str(int(SSGEc76fBan2)+1)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+SSGEc76fBan2,url,407,'',SSGEc76fBan2)
	return
def niK3eUVpPtMlf6DuGzEHdqjr41(url,Q2wdFOCjlJZonz3xMukshN6WIGmvp):
	iBI9R4HkNw6pZvdqMtGTjnUEXulhxy = url.split('/')[3]
	ZuCJj5EwDPROkb7UXNypofl = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('mychannelid',iBI9R4HkNw6pZvdqMtGTjnUEXulhxy)
	BsJ71WIxDtdFKveTcRPrqM4Cwb = TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl)
	import json as mMzqnoiYfaSC
	t9l5zXMbx26e8yg3DuZcCnmTdSBiR = mMzqnoiYfaSC.loads(BsJ71WIxDtdFKveTcRPrqM4Cwb)
	try: items = t9l5zXMbx26e8yg3DuZcCnmTdSBiR['data']['channel'][Q2wdFOCjlJZonz3xMukshN6WIGmvp]['edges']
	except: items = []
	if not items: UZ8LYnm5jsl9uKM0xDX('link',ToYWiIbruzUaNKRPZLG16cAj+'لا توجد نتائج','',9999)
	else:
		for MMeFJKLQG4HdIwObZ1l9 in items:
			gTBrshUpXZ5uFGa9CePNAt = MMeFJKLQG4HdIwObZ1l9['node']
			AdDvkOKSgBn = gTBrshUpXZ5uFGa9CePNAt['xid']
			keys = list(gTBrshUpXZ5uFGa9CePNAt.keys())
			LSwXTCcO3M2iFagV9HpJYmB4qjb = gTBrshUpXZ5uFGa9CePNAt['__typename'].lower()
			if LSwXTCcO3M2iFagV9HpJYmB4qjb=='channel':
				name = gTBrshUpXZ5uFGa9CePNAt['name']
				eTAH4oDYmwsNdOkG = gTBrshUpXZ5uFGa9CePNAt['displayName']
				title = 'CHNL:  '+eTAH4oDYmwsNdOkG
				pjMZ802XQCSxYVk = gTBrshUpXZ5uFGa9CePNAt['coverURLx375']
			else:
				name = gTBrshUpXZ5uFGa9CePNAt['channel']['name']
				eTAH4oDYmwsNdOkG = gTBrshUpXZ5uFGa9CePNAt['channel']['displayName']
				title = gTBrshUpXZ5uFGa9CePNAt['title']
				pjMZ802XQCSxYVk = gTBrshUpXZ5uFGa9CePNAt['thumbnailx360']
				if LSwXTCcO3M2iFagV9HpJYmB4qjb=='live': title = 'LIVE:  '+title
			title = f6dL2ob4FuQe(title)
			YmaiRV2dCwZnS87U = name+'::'+eTAH4oDYmwsNdOkG
			if BhTAck1bPFYGuUqRW:
				title = title.encode('utf8')
				YmaiRV2dCwZnS87U = YmaiRV2dCwZnS87U.encode('utf8')
			if LSwXTCcO3M2iFagV9HpJYmB4qjb=='channel':
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+AdDvkOKSgBn
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,402,pjMZ802XQCSxYVk,'',YmaiRV2dCwZnS87U)
			else:
				if LSwXTCcO3M2iFagV9HpJYmB4qjb=='video': DD1IVWFZbr7TlzYto5s = str(gTBrshUpXZ5uFGa9CePNAt['duration'])
				else: DD1IVWFZbr7TlzYto5s = ''
				ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/video/'+AdDvkOKSgBn
				UZ8LYnm5jsl9uKM0xDX(LSwXTCcO3M2iFagV9HpJYmB4qjb,ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,403,pjMZ802XQCSxYVk,DD1IVWFZbr7TlzYto5s,YmaiRV2dCwZnS87U)
	return
def TvU7mGce25qdDQy0CX(ZuCJj5EwDPROkb7UXNypofl):
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace(' \"',' \\"')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('\", ','\\", ')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('\n','\\n')
	ZuCJj5EwDPROkb7UXNypofl = ZuCJj5EwDPROkb7UXNypofl.replace('")','\\")')
	MOTqEciWnbxgk = wwDUc6Fijt2HEBIKuR()
	headers = {"Authorization":MOTqEciWnbxgk,"Origin":aaeRjxiYcqOI6Sf8}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',n9dWOLMBkl,ZuCJj5EwDPROkb7UXNypofl,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def wwDUc6Fijt2HEBIKuR():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'GET',aaeRjxiYcqOI6Sf8,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	IT1cgRYUuwa = SomeI8i56FaDMGPE.findall('var r="(.*?)",o="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	cGSml2ip4DYMCks8,MY6ZcNTPfyC3Fh7 = IT1cgRYUuwa[-1]
	MCuBlzwImOA5 = 'https://graphql.api.dailymotion.com/oauth/token'
	VbrpJvDSwg1 = 'client_credentials'
	data = {'client_id':cGSml2ip4DYMCks8,'client_secret':MY6ZcNTPfyC3Fh7,'grant_type':VbrpJvDSwg1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(sJF0ga5tzvlRZWK3Xb9,'POST',MCuBlzwImOA5,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	IT1cgRYUuwa = SomeI8i56FaDMGPE.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	bahYJEDNwm6ozeCvrGcuFq3L7j,pU2hfOGPFELyStMCD36onjicAx8 = IT1cgRYUuwa[0]
	MOTqEciWnbxgk = pU2hfOGPFELyStMCD36onjicAx8+" "+bahYJEDNwm6ozeCvrGcuFq3L7j
	return MOTqEciWnbxgk
def kV5Wue06vFixocBhPIZY9z(search,type=''):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if not type and showDialogs:
		r1wAilZmkcxFgpSRIX3oQs8aB = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('موقع ديلي موشن - اختر البحث',r1wAilZmkcxFgpSRIX3oQs8aB)
		if I7mfbGiWNFcBVJOn==-1: return
		elif I7mfbGiWNFcBVJOn==0: type = 'videos?sortBy='
		elif I7mfbGiWNFcBVJOn==1: type = 'videos?sortBy=RECENT'
		elif I7mfbGiWNFcBVJOn==2: type = 'videos?sortBy=VIEW_COUNT'
		elif I7mfbGiWNFcBVJOn==3: type = 'playlists'
		elif I7mfbGiWNFcBVJOn==4: type = 'channels'
		elif I7mfbGiWNFcBVJOn==5: type = 'topics'
		elif I7mfbGiWNFcBVJOn==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: type = 'lives'
	if not search:
		search = ymH9jzg2KId5MCvw8lXBZn()
		if not search: return
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: swoD8JG20r9Fku64aXAQ(search+'/'+type)
	elif 'playlists' in type: G72KTIet4QBdbjUPOl6RhXA5finMvu(search)
	elif 'channels' in type: PuRiaWIfl9woxpHDQkC(search)
	elif 'topics' in type: QA38k5wn09RPcY(search)
	elif 'lives' in type: V2g1WZ3J7UKhvD6N5Olt8bkwIsaM(search)
	return
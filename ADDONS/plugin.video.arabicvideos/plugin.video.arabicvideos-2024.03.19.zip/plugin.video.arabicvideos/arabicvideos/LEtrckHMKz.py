# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ARABICTOONS'
ToYWiIbruzUaNKRPZLG16cAj = '_ART_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
def GI13aCFr0qimdOT(mode,url,text):
	if   mode==730: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==731: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url)
	elif mode==732: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==733: rr60PDpqbMehZsYVuHmiAtN = ooLCwrlF3n0vBjpA(url)
	elif mode==734: rr60PDpqbMehZsYVuHmiAtN = uuoUrPOKXRCVvTQ0JLjnH5(url)
	elif mode==735: rr60PDpqbMehZsYVuHmiAtN = JefsKFMuYUp40ClcoaGjR(url)
	elif mode==739: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات مميزة',aaeRjxiYcqOI6Sf8+'/top.php',735)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'مسلسلات',aaeRjxiYcqOI6Sf8+'/cartoon.php',734)
	UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+'افلام',aaeRjxiYcqOI6Sf8+'/movies.php',731)
	return
def uuoUrPOKXRCVvTQ0JLjnH5(url):
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'الكل',url,731)
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('label="navigation"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall("href='(.*?)'>(.*?)</a>",L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = 'حرف '+title
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,731)
	return
def JefsKFMuYUp40ClcoaGjR(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="slider"(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
			title = title.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,733,pjMZ802XQCSxYVk)
	return
def KKlnDcetq8Rrp3GY0(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("class='moviesBlocks(.*?)navigation",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
	items = SomeI8i56FaDMGPE.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
		pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
		title = title.strip(' ')
		if 'movies.php' in url: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,732,pjMZ802XQCSxYVk)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,733,pjMZ802XQCSxYVk)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('"pagination(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[-1]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			title = title.strip(' ')
			title = dCFP41Kxv9j8EHM(title)
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,ZcAK0askvzIWr4R,731)
	return
def ooLCwrlF3n0vBjpA(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall("class='moviesBlocks(.*?)script",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,heXizOAPcHCdLZnwBVoql7py in items:
			ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
			pjMZ802XQCSxYVk = aaeRjxiYcqOI6Sf8+'/'+pjMZ802XQCSxYVk
			title = title.strip(' ')
			title = title+' '+heXizOAPcHCdLZnwBVoql7py.strip(' ')
			UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,732,pjMZ802XQCSxYVk)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	TbFRyPoVlrQAw7n3h8BukmfHNq = []
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZZHhmdtY1g = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if ZZHhmdtY1g:
		ZcAK0askvzIWr4R = ZZHhmdtY1g[0]
		if 'Referer=' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R+'|Referer=https://www.arabic-toons.com'
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named=__embed')
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	if search=='': search = ymH9jzg2KId5MCvw8lXBZn()
	if search=='': return
	search = search.replace(' ','%20')
	aFyREdMQk7Ys95rX6uJieDGLS2 = ['','m']
	JiRmpe1Pwx = ['مسلسلات','افلام']
	if showDialogs:
		I7mfbGiWNFcBVJOn = wKxBD1f6FgH54qRvTYP0c2eJbS3X('اختر النوع المطلوب:', JiRmpe1Pwx)
		if I7mfbGiWNFcBVJOn==-1: return
	else: I7mfbGiWNFcBVJOn = 0
	type = aFyREdMQk7Ys95rX6uJieDGLS2[I7mfbGiWNFcBVJOn]
	url = aaeRjxiYcqOI6Sf8+'/livesearch.php?'+type+'&q='+search
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for ZcAK0askvzIWr4R,title in items:
		ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+'/'+ZcAK0askvzIWr4R
		title = title.strip(' ')
		if type=='m': UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,732)
		else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,733)
	return
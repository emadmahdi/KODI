﻿# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'ALMAAREF'
headers = {'User-Agent':''}
ToYWiIbruzUaNKRPZLG16cAj = '_MRF_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def GI13aCFr0qimdOT(mode,url,text,SSGEc76fBan2):
	if   mode==40: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==41: rr60PDpqbMehZsYVuHmiAtN = AAtcZRiU7anLkDGsb5Bv9CIKEhW()
	elif mode==42: rr60PDpqbMehZsYVuHmiAtN = WMqF6fSd2aHPr3Q1nbAhTXE5t48mU(text,SSGEc76fBan2)
	elif mode==43: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==44: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(text,SSGEc76fBan2)
	elif mode==49: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	UZ8LYnm5jsl9uKM0xDX('live',ToYWiIbruzUaNKRPZLG16cAj+'البث الحي لقناة المعارف','',41)
	UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'بحث في الموقع','',49)
	UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WMqF6fSd2aHPr3Q1nbAhTXE5t48mU('','1')
	return
def GDb4HtcsXRygaN3K7jSlYip(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,xmyQ1v6BnlTNSdqO):
	search,sort,wYVpAWjH3EiLDzyaO,g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,S9L5OzgZB2sDtXJC = '',[],[],[],[]
	fYZzomwSjkedXVcEvLDqKHMt9rFnN,HHg8BJpUMwVSls0EhZm = RyQ1vTDniwqI7jCNMHmtcLaVK(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN)
	for irE1qv3BUYZMo5 in list(HHg8BJpUMwVSls0EhZm.keys()):
		EPwT39HrS1tU6Ng8YBGpJADixzLV5C = HHg8BJpUMwVSls0EhZm[irE1qv3BUYZMo5]
		if not EPwT39HrS1tU6Ng8YBGpJADixzLV5C: continue
		if   irE1qv3BUYZMo5=='sort': sort = [EPwT39HrS1tU6Ng8YBGpJADixzLV5C]
		elif irE1qv3BUYZMo5=='series': wYVpAWjH3EiLDzyaO = [EPwT39HrS1tU6Ng8YBGpJADixzLV5C]
		elif irE1qv3BUYZMo5=='search': search = EPwT39HrS1tU6Ng8YBGpJADixzLV5C
		elif irE1qv3BUYZMo5=='category': g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B = [EPwT39HrS1tU6Ng8YBGpJADixzLV5C]
		elif irE1qv3BUYZMo5=='specialist': S9L5OzgZB2sDtXJC = [EPwT39HrS1tU6Ng8YBGpJADixzLV5C]
	P8AGL4xSd9rWD1Vz = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,"specialist":S9L5OzgZB2sDtXJC,"series":wYVpAWjH3EiLDzyaO,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(xmyQ1v6BnlTNSdqO)}}
	import json as mMzqnoiYfaSC
	P8AGL4xSd9rWD1Vz = mMzqnoiYfaSC.dumps(P8AGL4xSd9rWD1Vz)
	ZcAK0askvzIWr4R = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',ZcAK0askvzIWr4R,P8AGL4xSd9rWD1Vz,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	data = sX8pkIh2J4MCZHtcr0ERmlqWDL16O('dict',BsJ71WIxDtdFKveTcRPrqM4Cwb)
	return data
def WMqF6fSd2aHPr3Q1nbAhTXE5t48mU(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,level):
	UUTVrGP7Y31a = GDb4HtcsXRygaN3K7jSlYip(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,'1')
	L0Uwx52bTBM = UUTVrGP7Y31a['facets']
	if level=='1':
		L0Uwx52bTBM = L0Uwx52bTBM['video_categories']
		items = SomeI8i56FaDMGPE.findall('<div(.*?)/div>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for MMeFJKLQG4HdIwObZ1l9 in items:
			T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',MMeFJKLQG4HdIwObZ1l9+'<',SomeI8i56FaDMGPE.DOTALL)
			if not T9PyERLBA8wiVN30QjU14mW: T9PyERLBA8wiVN30QjU14mW = SomeI8i56FaDMGPE.findall('data-value=\\"(.*?)\\">(.*?)<',MMeFJKLQG4HdIwObZ1l9+'<',SomeI8i56FaDMGPE.DOTALL)
			g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,title = T9PyERLBA8wiVN30QjU14mW[0]
			if not lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN: UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,'',42,'','2','?category='+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B)
			else: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,'',42,'','2',lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN+'&category='+g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B)
	if level=='2':
		L0Uwx52bTBM = L0Uwx52bTBM['specialist']
		items = SomeI8i56FaDMGPE.findall('value="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for S9L5OzgZB2sDtXJC,title in items:
			if not S9L5OzgZB2sDtXJC: title = title = 'الجميع'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,'',42,'','3',lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN+'&specialist='+S9L5OzgZB2sDtXJC)
	elif level=='3':
		L0Uwx52bTBM = L0Uwx52bTBM['series']
		items = SomeI8i56FaDMGPE.findall('value="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for wYVpAWjH3EiLDzyaO,title in items:
			if not wYVpAWjH3EiLDzyaO: title = title = 'الجميع'
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,'',42,'','4',lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN+'&series='+wYVpAWjH3EiLDzyaO)
	elif level=='4':
		L0Uwx52bTBM = L0Uwx52bTBM['sort_video']
		items = SomeI8i56FaDMGPE.findall('value="(.*?)".*?>(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for sort,title in items:
			if not sort: continue
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,'',44,'','1',lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN+'&sort='+sort)
	return
def KKlnDcetq8Rrp3GY0(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,xmyQ1v6BnlTNSdqO):
	UUTVrGP7Y31a = GDb4HtcsXRygaN3K7jSlYip(lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,xmyQ1v6BnlTNSdqO)
	L0Uwx52bTBM = UUTVrGP7Y31a['template']
	items = SomeI8i56FaDMGPE.findall('src="(.*?)".*?href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for pjMZ802XQCSxYVk,ZcAK0askvzIWr4R,title in items:
		UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,43,pjMZ802XQCSxYVk)
	L0Uwx52bTBM = UUTVrGP7Y31a['facets']['pagination']
	items = SomeI8i56FaDMGPE.findall('data-page="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
	for SSGEc76fBan2,title in items:
		if xmyQ1v6BnlTNSdqO==SSGEc76fBan2: continue
		UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'صفحة '+title,'',44,'',SSGEc76fBan2,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN)
	return
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('<video src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if not ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('youtube_url.*?(http.*?)&',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	TbFRyPoVlrQAw7n3h8BukmfHNq = []
	if ZcAK0askvzIWr4R:
		ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0].replace('\/','/')
		TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def AAtcZRiU7anLkDGsb5Bv9CIKEhW():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	items = SomeI8i56FaDMGPE.findall('source src="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	url = aDebGvrkdptunqTM8m4(items[0])
	kFygcp2jqSUCiNRnur71xMZI96(url,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'live')
	return
def kV5Wue06vFixocBhPIZY9z(search):
	search,lxJ9ieTKCqbSYjQgDU6kr7dw5Mn8hN,showDialogs = Xj2G0VZ876Idy(search)
	xAzf5svGES3M6 = False
	if search=='':
		search = ymH9jzg2KId5MCvw8lXBZn()
		xAzf5svGES3M6 = True
	if search=='': return
	if not xAzf5svGES3M6: KKlnDcetq8Rrp3GY0('?search='+search,'1')
	else: WMqF6fSd2aHPr3Q1nbAhTXE5t48mU('?search='+search,'1')
	return
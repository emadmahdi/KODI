# -*- coding: utf-8 -*-
import sys as EuOf9ozUdyP
Klfn6kHtjASghyZ2wU = EuOf9ozUdyP.version_info [0] == 2
bkJ2OKTL5BsF = 2048
BTIm6w7uCWApsKlezZRF9yNjY = 7
def zHlvUQ84ZVqofmxRc3bsdA (mmIjHqVEhWSZ):
	global MgluQD32iJb
	ccWNt3ePsKlE = ord (mmIjHqVEhWSZ [-1])
	ZrF6elhwLTSgJskGU4E1BOt3qWR = mmIjHqVEhWSZ [:-1]
	aJPIpXWvwnM57AdOKUfC8cYRHjGN = ccWNt3ePsKlE % len (ZrF6elhwLTSgJskGU4E1BOt3qWR)
	mZOJeaG273yvqYn4pUuASod = ZrF6elhwLTSgJskGU4E1BOt3qWR [:aJPIpXWvwnM57AdOKUfC8cYRHjGN] + ZrF6elhwLTSgJskGU4E1BOt3qWR [aJPIpXWvwnM57AdOKUfC8cYRHjGN:]
	if Klfn6kHtjASghyZ2wU:
		yUpilH7eqZMFOK = unicode () .join ([unichr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	else:
		yUpilH7eqZMFOK = str () .join ([chr (ord (slIFPuOHW6mqxdNrBVyS21gb) - bkJ2OKTL5BsF - (X8qnsbDrzi6md1RkW + ccWNt3ePsKlE) % BTIm6w7uCWApsKlezZRF9yNjY) for X8qnsbDrzi6md1RkW, slIFPuOHW6mqxdNrBVyS21gb in enumerate (mZOJeaG273yvqYn4pUuASod)])
	return eval (yUpilH7eqZMFOK)
WWbmNvI40sM9Khlp25Ae,hRFbZmJoxpKWwBMDQnyOzcXItdEl,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT=zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA,zHlvUQ84ZVqofmxRc3bsdA
FZBX5WcC3msIDv4hobLd8,lh6URegmQNq8LWX0HaK5,B2vCEI9FAVP15R8eUbDJdySc=KdhPA4SiFLHlJk0BGWjqDbaIcOzVT,hRFbZmJoxpKWwBMDQnyOzcXItdEl,WWbmNvI40sM9Khlp25Ae
q6yUEoKVDb0fXmc8vhrMk7N,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,MOwK1lpyNfCgqksX3jhV=B2vCEI9FAVP15R8eUbDJdySc,lh6URegmQNq8LWX0HaK5,FZBX5WcC3msIDv4hobLd8
gt48FLoNMrJRI7sdDpYGjcZBPuiqm,Q1QS6w8saLEuPW0O7XjlipekBTbq,d0HDrq8Rtk16AlInw4TXb=MOwK1lpyNfCgqksX3jhV,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo,q6yUEoKVDb0fXmc8vhrMk7N
LsG7EDcei1gMShH2aVOCo,RS7ZoyGAq1c,IPkQW7LojF3HO18V=d0HDrq8Rtk16AlInw4TXb,Q1QS6w8saLEuPW0O7XjlipekBTbq,gt48FLoNMrJRI7sdDpYGjcZBPuiqm
QQSULIva4ljNO73mFcWw,Y5npATFarf1H9wBjc87,Q2ZyGqCNYsftTc4MR7n=IPkQW7LojF3HO18V,RS7ZoyGAq1c,LsG7EDcei1gMShH2aVOCo
a1IrjsC9KbUv6ZqJnQASYkPTuBEi,onweDvmTOUj,gy9NA3CROZolfEt4vVzMr=Q2ZyGqCNYsftTc4MR7n,Y5npATFarf1H9wBjc87,QQSULIva4ljNO73mFcWw
aSf0iWG1kA7FsqjHbuC8NXB,NQ4hg16DPUxtOyo5iGb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR=gy9NA3CROZolfEt4vVzMr,onweDvmTOUj,a1IrjsC9KbUv6ZqJnQASYkPTuBEi
Rz34c0NP5BGo1WuTZxSfOKj,eaF2N0jWLdvHIs8r,OnvTrikzfEsY7qU8pgaRBtZy=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR,NQ4hg16DPUxtOyo5iGb,aSf0iWG1kA7FsqjHbuC8NXB
RWnd79GQpKM1gV5xAO2amZkTrL8F,Jbu2G0Qax8PYWpg,wKdxVbTc0X9NSiespM8OvHGUhf=OnvTrikzfEsY7qU8pgaRBtZy,eaF2N0jWLdvHIs8r,Rz34c0NP5BGo1WuTZxSfOKj
hxSBTdGpyNVbfu4tr9,mtEXp14ijx,Sj1PYDmIpCUXO26=wKdxVbTc0X9NSiespM8OvHGUhf,Jbu2G0Qax8PYWpg,RWnd79GQpKM1gV5xAO2amZkTrL8F
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = onweDvmTOUj(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧᶔ")
def GI13aCFr0qimdOT(lOH3hXsnQiFCRjbN12,yy42JUqszVIO89i=q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࠧᶕ")):
	if   lOH3hXsnQiFCRjbN12==  gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵ঢ়"): ojGUD7k6EYtAeRsaWCS(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==  gy9NA3CROZolfEt4vVzMr(u"࠸৞"): bbP5YM4p3QCHhi6(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==  Sj1PYDmIpCUXO26(u"࠳য়"): DjqriRSkMZl()
	elif lOH3hXsnQiFCRjbN12==  Rz34c0NP5BGo1WuTZxSfOKj(u"࠵ৠ"): hceUB9uxLZ(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==  QQSULIva4ljNO73mFcWw(u"࠷ৡ"): e9CfrQj5l6Sx()
	elif lOH3hXsnQiFCRjbN12==  WWbmNvI40sM9Khlp25Ae(u"࠹ৢ"): VbALIM4mvWkGJz2QgwohTjERHY()
	elif lOH3hXsnQiFCRjbN12==  gy9NA3CROZolfEt4vVzMr(u"࠻ৣ"): wwnd49zbIZB(Rz34c0NP5BGo1WuTZxSfOKj(u"ࡖࡵࡹࡪઐ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࡖࡵࡹࡪઐ"))
	elif lOH3hXsnQiFCRjbN12==  QQSULIva4ljNO73mFcWw(u"࠽৤"): xKTGgtV1JA4DwYZUEch()
	elif lOH3hXsnQiFCRjbN12==  RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠿৥"): o2Prut1ZLTwDA()
	elif lOH3hXsnQiFCRjbN12==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠱࠶࠲০"): GFfSeMJ2sC0XQ1EjTdW56BvAZU()
	elif lOH3hXsnQiFCRjbN12==Sj1PYDmIpCUXO26(u"࠲࠷࠴১"): XhQFZ9Nfj8VlqA0()
	elif lOH3hXsnQiFCRjbN12==LsG7EDcei1gMShH2aVOCo(u"࠳࠸࠶২"): DxQspVP56kH3N()
	elif lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠴࠹࠸৩"): BBuGHOLYMA()
	elif lOH3hXsnQiFCRjbN12==gy9NA3CROZolfEt4vVzMr(u"࠵࠺࠺৪"): qqeNbd1yW5nBZMIHfm3SP6C()
	elif lOH3hXsnQiFCRjbN12==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠻࠵৫"): UGsd7O6vc9NPH0()
	elif lOH3hXsnQiFCRjbN12==FZBX5WcC3msIDv4hobLd8(u"࠷࠵࠷৬"): FeKLjQHTNsb139Wo8hx4()
	elif lOH3hXsnQiFCRjbN12==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠱࠶࠹৭"): ccbprLiXNVRBqz0ufFG()
	elif lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠲࠷࠻৮"): fJTqHgAdX2Rw()
	elif lOH3hXsnQiFCRjbN12==d0HDrq8Rtk16AlInw4TXb(u"࠳࠸࠽৯"): ccuUSARfBCDlvHy7(B2vCEI9FAVP15R8eUbDJdySc(u"ࡗࡶࡺ࡫ઑ"))
	elif lOH3hXsnQiFCRjbN12==B2vCEI9FAVP15R8eUbDJdySc(u"࠴࠻࠵ৰ"): BkyTMHzu3VPwtpG7DcbgfRdIqC0r()
	elif lOH3hXsnQiFCRjbN12==aSf0iWG1kA7FsqjHbuC8NXB(u"࠵࠼࠷ৱ"): lBGHzr6qwcsA3TOD()
	elif lOH3hXsnQiFCRjbN12==OnvTrikzfEsY7qU8pgaRBtZy(u"࠶࠽࠲৲"): AAHIlgDhjCR7kNmuF3(yy42JUqszVIO89i,RS7ZoyGAq1c(u"ࡘࡷࡻࡥ઒"),RS7ZoyGAq1c(u"ࡘࡷࡻࡥ઒"))
	elif lOH3hXsnQiFCRjbN12==Rz34c0NP5BGo1WuTZxSfOKj(u"࠷࠷࠴৳"): cPzAIOrxUw5XlveWpHSEhR(d0HDrq8Rtk16AlInw4TXb(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧᶖ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࡙ࡸࡵࡦઓ"))
	elif lOH3hXsnQiFCRjbN12==wKdxVbTc0X9NSiespM8OvHGUhf(u"࠱࠸࠶৴"): cPzAIOrxUw5XlveWpHSEhR(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫᶗ"),eaF2N0jWLdvHIs8r(u"࡚ࡲࡶࡧઔ"))
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠲࠹࠸৵"): sstHkbULPJ8dpVXqBKTwAfxD7R()
	elif lOH3hXsnQiFCRjbN12==MOwK1lpyNfCgqksX3jhV(u"࠳࠺࠺৶"): oCZIvhMW6wmp9tQPTfSaX7c8E2qD()
	elif lOH3hXsnQiFCRjbN12==IPkQW7LojF3HO18V(u"࠴࠻࠼৷"): dZAzEX3mG4OY0kHTL(NQ4hg16DPUxtOyo5iGb(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ᶘ"))
	elif lOH3hXsnQiFCRjbN12==RS7ZoyGAq1c(u"࠵࠼࠾৸"): dZAzEX3mG4OY0kHTL(onweDvmTOUj(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧᶙ"))
	elif lOH3hXsnQiFCRjbN12==Jbu2G0Qax8PYWpg(u"࠶࠽࠹৹"): dZAzEX3mG4OY0kHTL(LsG7EDcei1gMShH2aVOCo(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫᶚ"))
	elif lOH3hXsnQiFCRjbN12==Sj1PYDmIpCUXO26(u"࠷࠹࠱৺"): cCb97ROZ2yWUSYx6GqoPn()
	elif lOH3hXsnQiFCRjbN12==B2vCEI9FAVP15R8eUbDJdySc(u"࠱࠺࠳৻"): qxmuSN0OsAQH7VPeGzLUoC9()
	elif lOH3hXsnQiFCRjbN12==q6yUEoKVDb0fXmc8vhrMk7N(u"࠲࠻࠵ৼ"): NicWUdQDxMuTSZB0aOLzVg()
	elif lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠳࠼࠷৽"): pR9CAzSjUD6v()
	elif lOH3hXsnQiFCRjbN12==LsG7EDcei1gMShH2aVOCo(u"࠴࠽࠹৾"): kjDg1VlqL4J9()
	elif lOH3hXsnQiFCRjbN12==Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠵࠾࠻৿"): hIR8ote4Dw()
	elif lOH3hXsnQiFCRjbN12==eaF2N0jWLdvHIs8r(u"࠶࠿࠶਀"): WSfBRwlG8U4x()
	elif lOH3hXsnQiFCRjbN12==Sj1PYDmIpCUXO26(u"࠷࠹࠸ਁ"): a4aGrHBMfp()
	elif lOH3hXsnQiFCRjbN12==Jbu2G0Qax8PYWpg(u"࠱࠺࠺ਂ"): QGetiy1EpLfsokl8cT()
	elif lOH3hXsnQiFCRjbN12==Rz34c0NP5BGo1WuTZxSfOKj(u"࠲࠻࠼ਃ"): CGBeYtkf30lVAFW()
	elif lOH3hXsnQiFCRjbN12==hxSBTdGpyNVbfu4tr9(u"࠵࠷࠴਄"): zqCHFSkEdhiDc7Un3YtZexr4(yy42JUqszVIO89i)
	elif lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠶࠸࠶ਅ"): z9bBQFsXTWgGtlC8PoryMw1pfnAL0V()
	elif lOH3hXsnQiFCRjbN12==LsG7EDcei1gMShH2aVOCo(u"࠷࠹࠸ਆ"): qqJkh86fEOTyr()
	elif lOH3hXsnQiFCRjbN12==NQ4hg16DPUxtOyo5iGb(u"࠸࠺࠳ਇ"): r2tWck4ZmIaFTeNzp()
	elif lOH3hXsnQiFCRjbN12==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠹࠴࠵ਈ"): P3VF8mK2uN4kTgHL(MOwK1lpyNfCgqksX3jhV(u"ࡔࡳࡷࡨક"))
	elif lOH3hXsnQiFCRjbN12==OnvTrikzfEsY7qU8pgaRBtZy(u"࠳࠵࠷ਉ"): c1W9ULBSzrpOtiG6D72jfusV4gbk()
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠴࠶࠹ਊ"): XfdG8SZ1laKkut(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡇࡣ࡯ࡷࡪખ"))
	elif lOH3hXsnQiFCRjbN12==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠵࠷࠻਋"): pdHeIDkWABLxGiFhzturXRMZ97K(mtEXp14ijx(u"ࡖࡵࡹࡪગ"))
	elif lOH3hXsnQiFCRjbN12==onweDvmTOUj(u"࠶࠸࠽਌"): uTU07tompv8AIHNWnFd3LGQlfCY9K1()
	elif lOH3hXsnQiFCRjbN12==hxSBTdGpyNVbfu4tr9(u"࠷࠹࠿਍"): pass
	elif lOH3hXsnQiFCRjbN12==mtEXp14ijx(u"࠺࠶࠰਎"): W4OapukCqn()
	elif lOH3hXsnQiFCRjbN12==FZBX5WcC3msIDv4hobLd8(u"࠻࠰࠲ਏ"): T28qhRlVEwHSgNz5DJBbCWAOMPo()
	elif lOH3hXsnQiFCRjbN12==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠵࠱࠴ਐ"): b6ORNrZ5wVgaTmByAto(LsG7EDcei1gMShH2aVOCo(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᶛ"),RS7ZoyGAq1c(u"ࡗࡶࡺ࡫ઘ"))
	elif lOH3hXsnQiFCRjbN12==WWbmNvI40sM9Khlp25Ae(u"࠶࠲࠶਑"): poqbg0fhkZMzv(kRpnCV8cqdhDew2suUxPfaQTA5)
	elif lOH3hXsnQiFCRjbN12==q6yUEoKVDb0fXmc8vhrMk7N(u"࠷࠳࠸਒"): poqbg0fhkZMzv(YbTWJNjEGPC12RZzHioatgvu)
	elif lOH3hXsnQiFCRjbN12==RS7ZoyGAq1c(u"࠸࠴࠺ਓ"): LM03ksGUP9F5ZT4cn()
	elif lOH3hXsnQiFCRjbN12==lh6URegmQNq8LWX0HaK5(u"࠹࠵࠼ਔ"): W2sm89LliTnf(Q2ZyGqCNYsftTc4MR7n(u"ࡘࡷࡻࡥઙ"))
	elif lOH3hXsnQiFCRjbN12==Y5npATFarf1H9wBjc87(u"࠺࠶࠷ਕ"): kkvSXEJ68UA0uFD(yy42JUqszVIO89i,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠧᶜ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࡙ࡸࡵࡦચ"))
	elif lOH3hXsnQiFCRjbN12==aSf0iWG1kA7FsqjHbuC8NXB(u"࠻࠰࠹ਖ"): mzlSXPkiJtbLMTQNfAGrDsp5()
	elif lOH3hXsnQiFCRjbN12==RS7ZoyGAq1c(u"࠵࠱࠻ਗ"): N1ShGsHKOC4jVpAEw()
	return
def N1ShGsHKOC4jVpAEw():
	svOyXbipkwY = nEYJ5OCXG0gcNy(mtEXp14ijx(u"ࠧࠨᶝ"),Sj1PYDmIpCUXO26(u"ࠨࠩᶞ"),LsG7EDcei1gMShH2aVOCo(u"ࠩࠪᶟ"),LsG7EDcei1gMShH2aVOCo(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᶠ"),IPkQW7LojF3HO18V(u"ࠫ์๊ࠠหำํำࠥ็ูๅษุ้ࠣำࠠอ็ํ฽ࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ๋ำฮࠢฯ้๏฿ࠠๆๆไหฯࠦวๅสิ๊ฬ๋ฬࠡษ็ๆิ๐ๅสࠢ࠱࠲๊ࠥใ๋ࠢํ฽ํีࠠศๆหี๋อๅอࠢศ่๎ࠦอศๆฬࠤฬ๊ีโำࠣ࠲࠳ฺ๊่ࠦํࠤฯาฯ๋ัࠣห้ฮั็ษ่ะࠥ๎สึใํี์ุ่้ࠦ฼๋ࠥฮอศๆฬࠤฬ๊ๅึ่฼ࠤฬ๊สฺ๋๋ࠢ฾ํวࠡษ็้อืๅอࠢยࠥࠦ࠭ᶡ"))
	if svOyXbipkwY:
		P3VF8mK2uN4kTgHL(Jbu2G0Qax8PYWpg(u"ࡌࡡ࡭ࡵࡨછ"))
		IlTEWy8f4bpjLa7UR0c2qDY6S15Q(Vd1J5lD9uAsMUoXW,B2vCEI9FAVP15R8eUbDJdySc(u"ࡕࡴࡸࡩઝ"),hxSBTdGpyNVbfu4tr9(u"ࡆࡢ࡮ࡶࡩજ"))
		ztgqWUaDpe8CE9N(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬ࠭ᶢ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠧᶣ"),gy9NA3CROZolfEt4vVzMr(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶤ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨฬ่ࠤู๊อࠡฮ่๎฾ࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡๆ็ฬึ์วๆฮࠣ࠲࠳ฺ่ࠦษาࠤฬ๊ศา่ส้ัࠦลๅ๋ࠣ์฻฿๊สࠢสฺ่็ัࠡ࠰࠱ࠤํ฼ู๋หࠣห้๋ี็฻ࠪᶥ"))
	return
def kkvSXEJ68UA0uFD(giwrh4jLPc,aulpIzZLT2KhjMxPiOBGfWve,showDialogs):
	Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(hvGPU2bmasopzFJxIEqfRYW41uQ6y)
	Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
	lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
	if BhTAck1bPFYGuUqRW: L0GkXjlpd9cAZwFKeyuf6MNa = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬᶦ")
	else: L0GkXjlpd9cAZwFKeyuf6MNa = Q2ZyGqCNYsftTc4MR7n(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩᶧ")
	lU7cFRC6jSwkVLTmIM.execute(lh6URegmQNq8LWX0HaK5(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬᶨ")+L0GkXjlpd9cAZwFKeyuf6MNa+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᶩ")+giwrh4jLPc+QQSULIva4ljNO73mFcWw(u"࠭ࠢࠡ࠽ࠪᶪ"))
	TiF5HCp4Zzf6ubclUONXI1AEL = lU7cFRC6jSwkVLTmIM.fetchall()
	if TiF5HCp4Zzf6ubclUONXI1AEL and aulpIzZLT2KhjMxPiOBGfWve in [onweDvmTOUj(u"ࠧࠨᶫ"),NQ4hg16DPUxtOyo5iGb(u"ࠨࡧࡱࡥࡧࡲࡥࠨᶬ")]:
		svOyXbipkwY = nEYJ5OCXG0gcNy(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࠪᶭ"),QQSULIva4ljNO73mFcWw(u"ࠪࠫᶮ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠬᶯ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶰ"),aSf0iWG1kA7FsqjHbuC8NXB(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪᶱ")+giwrh4jLPc+d0HDrq8Rtk16AlInw4TXb(u"ࠧࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨᶲ"))
		if svOyXbipkwY!=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠲ਘ"): return
		lU7cFRC6jSwkVLTmIM.execute(IPkQW7LojF3HO18V(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧᶳ")+L0GkXjlpd9cAZwFKeyuf6MNa+IPkQW7LojF3HO18V(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧᶴ")+giwrh4jLPc+Y5npATFarf1H9wBjc87(u"ࠪࠦࠥࡁࠧᶵ"))
	elif aulpIzZLT2KhjMxPiOBGfWve in [KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࠬᶶ"),QQSULIva4ljNO73mFcWw(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ᶷ")]:
		svOyXbipkwY = nEYJ5OCXG0gcNy(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠧᶸ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨᶹ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠩᶺ"),lh6URegmQNq8LWX0HaK5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶻ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧᶼ")+giwrh4jLPc+WWbmNvI40sM9Khlp25Ae(u"ࠫࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢอๅ฾๐ไ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨᶽ"))
		if svOyXbipkwY!=Q2ZyGqCNYsftTc4MR7n(u"࠳ਙ"): return
		if BhTAck1bPFYGuUqRW: lU7cFRC6jSwkVLTmIM.execute(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡦࡱࡧࡣ࡬࡮࡬ࡷࡹࠦࠨࡢࡦࡧࡳࡳࡏࡄ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬᶾ")+giwrh4jLPc+FZBX5WcC3msIDv4hobLd8(u"࠭ࠢࠪࠢ࠾ࠫᶿ"))
		else: lU7cFRC6jSwkVLTmIM.execute(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠲ࡵࡱࡦࡤࡸࡪࡘࡵ࡭ࡧࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧ᷀")+giwrh4jLPc+NQ4hg16DPUxtOyo5iGb(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨ᷁"))
	Iof8U0xDKbVslWATpzR4OvBe9.commit()
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	p1BoraOuWL.sleep(Y5npATFarf1H9wBjc87(u"࠴ਚ"))
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(WWbmNvI40sM9Khlp25Ae(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ᷂࠭"))
	p1BoraOuWL.sleep(NQ4hg16DPUxtOyo5iGb(u"࠵ਛ"))
	if showDialogs: ztgqWUaDpe8CE9N(eaF2N0jWLdvHIs8r(u"ࠪࠫ᷃"),NQ4hg16DPUxtOyo5iGb(u"ࠫࠬ᷄"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᷅"),NQ4hg16DPUxtOyo5iGb(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ᷆"))
	if aulpIzZLT2KhjMxPiOBGfWve in [IPkQW7LojF3HO18V(u"ࠧࠨ᷇"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡧࡱࡥࡧࡲࡥࠨ᷈")]: ccuUSARfBCDlvHy7(showDialogs)
	return
def LM03ksGUP9F5ZT4cn():
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,gy9NA3CROZolfEt4vVzMr(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ᷉"),mtEXp14ijx(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ᷊࠭"))
	PPtQZgSW3H7pbKk5lhiV = iFD752WvpSOGkxd6LlR0fZTQUb4CE(WWbmNvI40sM9Khlp25Ae(u"ࡈࡤࡰࡸ࡫ઞ"))
	Lrq7PlOQjeg3 = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡡࡴࠧ᷋")
	k240di7lI3ra = d0HDrq8Rtk16AlInw4TXb(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᷌")
	lmCqgKJhDI5829VfXkp7eONPAQtc = OnvTrikzfEsY7qU8pgaRBtZy(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ᷍")
	for id,OjIPm0do31CZ,rT84VWkePRZBIUab2oQn,j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP,reason in reversed(PPtQZgSW3H7pbKk5lhiV):
		if id==FZBX5WcC3msIDv4hobLd8(u"ࠧ࠱᷎ࠩ"):
			GYMFoOBcHCEpfJ0j,E5EzWlp7eDOALB8r1jyFQiw = j2jpfQzAmwUo6G.split(eaF2N0jWLdvHIs8r(u"ࠨ࡞ࡱ࠿ࡀ᷏࠭"))
			continue
		if Lrq7PlOQjeg3!=QQSULIva4ljNO73mFcWw(u"ࠩ࡟ࡲ᷐ࠬ"): Lrq7PlOQjeg3 += lmCqgKJhDI5829VfXkp7eONPAQtc
		Bro7jZXa2qAFulQW9IkPL = IPkQW7LojF3HO18V(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ᷑")+id+NQ4hg16DPUxtOyo5iGb(u"ࠫࠥࡀࠠࠨ᷒")+FZBX5WcC3msIDv4hobLd8(u"ࠬอไิฦส่ࠥࡀࠠࠨᷓ")+Q2ZyGqCNYsftTc4MR7n(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᷔ")+rT84VWkePRZBIUab2oQn
		yQMg7VfFNB4l9UcpqiX = hxSBTdGpyNVbfu4tr9(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ั๎วษࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᷕ")+j2jpfQzAmwUo6G
		p2sfgbe9xhl3JXnkLc = LsG7EDcei1gMShH2aVOCo(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᷖ")+ctQaYd8BKeVT4qLHxNRkjUIgP
		KXHul4UAnW = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำษสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᷗ")+reason
		Lrq7PlOQjeg3 += Bro7jZXa2qAFulQW9IkPL+yQMg7VfFNB4l9UcpqiX+eaF2N0jWLdvHIs8r(u"ࠪࡠࡳ࠭ᷘ")+k240di7lI3ra+nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡡࡴࠧᷙ")+p2sfgbe9xhl3JXnkLc+KXHul4UAnW+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡢ࡮ࠨᷚ")
	DPfOyNk6YarWmFKU2ezZlAiG(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࡲࡪࡩ࡫ࡸࠬᷛ"),E5EzWlp7eDOALB8r1jyFQiw,Lrq7PlOQjeg3,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᷜ"))
	return
def poqbg0fhkZMzv(file):
	if file==YbTWJNjEGPC12RZzHioatgvu: hS7nptDLOzNJPQAlRBCj = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨᷝ")
	elif file==kRpnCV8cqdhDew2suUxPfaQTA5: hS7nptDLOzNJPQAlRBCj = Sj1PYDmIpCUXO26(u"ࠩๅ์ฬฬๅࠡฤัีࠥอไโ์า๎ํํวหࠩᷞ")
	U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(RS7ZoyGAq1c(u"ࠪࡧࡪࡴࡴࡦࡴࠪᷟ"),lh6URegmQNq8LWX0HaK5(u"ู๊ࠫอࠨᷠ"),eaF2N0jWLdvHIs8r(u"ࠬหีๅษะࠫᷡ"),IPkQW7LojF3HO18V(u"࠭ฮา๊ฯࠫᷢ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᷣ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨ้็ࠤฯื๊ะࠢศู้ออࠡ็็ๅࠥ࠭ᷤ")+hS7nptDLOzNJPQAlRBCj+mtEXp14ijx(u"ࠩࠣว๊ࠦสา์าࠤู๊อࠡษ็้้็ࠠภࠩᷥ"))
	if U94D8BejHMsrLzO27IRpFEhC6wP==RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠵ਜ"):
		if Dh9MOxeTj6FW.path.exists(file):
			try: Dh9MOxeTj6FW.remove(file)
			except: pass
		ztgqWUaDpe8CE9N(d0HDrq8Rtk16AlInw4TXb(u"ࠪࠫᷦ"),NQ4hg16DPUxtOyo5iGb(u"ࠫࠬᷧ"),gy9NA3CROZolfEt4vVzMr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᷨ"),B2vCEI9FAVP15R8eUbDJdySc(u"࠭สๆ่ࠢืาࠦๅๅใࠣࠫᷩ")+hS7nptDLOzNJPQAlRBCj)
	elif U94D8BejHMsrLzO27IRpFEhC6wP==B2vCEI9FAVP15R8eUbDJdySc(u"࠷ਝ"):
		data = itTndG7sM4oAk90qEX83(file)
		ztgqWUaDpe8CE9N(NQ4hg16DPUxtOyo5iGb(u"ࠧࠨᷪ"),Sj1PYDmIpCUXO26(u"ࠨࠩᷫ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷬ"),Sj1PYDmIpCUXO26(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪᷭ")+hS7nptDLOzNJPQAlRBCj)
	return
def T28qhRlVEwHSgNz5DJBbCWAOMPo():
	if Qf8xsJSwoKaUNc<B2vCEI9FAVP15R8eUbDJdySc(u"࠱࠹ਞ"):
		QQONb7aR2M6L = MOwK1lpyNfCgqksX3jhV(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧᷮ")+str(Qf8xsJSwoKaUNc)+Y5npATFarf1H9wBjc87(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭ᷯ")
		ztgqWUaDpe8CE9N(gy9NA3CROZolfEt4vVzMr(u"࠭ࠧᷰ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠨᷱ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᷲ"),QQONb7aR2M6L)
		return
	IuorNOL7BDiSbPlJQkh4jZ6Fapm = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(WWbmNvI40sM9Khlp25Ae(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬᷳ"))
	jcx62oQkzE5gIy = mGk5l3R8KAPgZ7vyQ1rFNxUsT([eaF2N0jWLdvHIs8r(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᷴ")])
	lSf5UiBMyzRED2nbPO7Ytpxdaw,tPXNFwqjEirYgQBf56Um8o,WiKq721uYnPjlb,pCEPOumRltIr3SD,eKFptPWva3woY,vN93t1zo2GKrfdaZhLuxTp,zgDKWYACLI3OBTvmVNnPf = jcx62oQkzE5gIy[aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ᷵")]
	if lSf5UiBMyzRED2nbPO7Ytpxdaw or Y5npATFarf1H9wBjc87(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ᷶") not in str(IuorNOL7BDiSbPlJQkh4jZ6Fapm):
		ztgqWUaDpe8CE9N(FZBX5WcC3msIDv4hobLd8(u"᷷࠭ࠧ"),eaF2N0jWLdvHIs8r(u"ࠧࠨ᷸"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯ᷹ࠫ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯ᷺ࠧ"))
		sycSign827ZrEldIB = b6ORNrZ5wVgaTmByAto(MOwK1lpyNfCgqksX3jhV(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ᷻"),Sj1PYDmIpCUXO26(u"ࡗࡶࡺ࡫ટ"))
		if not sycSign827ZrEldIB: return
	arkQJHYMfi0RIKz3m4hG17ZPup9U(NQ4hg16DPUxtOyo5iGb(u"ࡘࡷࡻࡥઠ"))
	return
def arkQJHYMfi0RIKz3m4hG17ZPup9U(showDialogs=RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࡙ࡸࡵࡦડ")):
	IuorNOL7BDiSbPlJQkh4jZ6Fapm = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ᷼"))
	if lh6URegmQNq8LWX0HaK5(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ᷽ࠫ") not in str(IuorNOL7BDiSbPlJQkh4jZ6Fapm):
		if showDialogs:
			ztgqWUaDpe8CE9N(d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧ᷾"),NQ4hg16DPUxtOyo5iGb(u"ࠧࠨ᷿"),Jbu2G0Qax8PYWpg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḀ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧḁ"))
		return
	AEJm8cgPlU9FuY26 = Dh9MOxeTj6FW.path.join(mKdhSjzZPWany,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪḂ"),IPkQW7LojF3HO18V(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪḃ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࠽࠲࠱ࡲࠪḄ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧḅ"))
	if not Dh9MOxeTj6FW.path.exists(AEJm8cgPlU9FuY26): return
	P8wc1gZWR7KV = open(AEJm8cgPlU9FuY26,RS7ZoyGAq1c(u"ࠧࡳࡤࠪḆ")).read()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: P8wc1gZWR7KV = P8wc1gZWR7KV.decode(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠨࡷࡷࡪ࠽࠭ḇ"))
	jtzCZksBIM = SomeI8i56FaDMGPE.findall(FZBX5WcC3msIDv4hobLd8(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩḈ"),P8wc1gZWR7KV,SomeI8i56FaDMGPE.DOTALL)
	SlWJrfqn19A6FDObC720jdVBc4X,CCM4xwKVRWzN09U = jtzCZksBIM[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠱ਟ")]
	ioA3htIVanmRju = d0HDrq8Rtk16AlInw4TXb(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫḉ")+SlWJrfqn19A6FDObC720jdVBc4X+RS7ZoyGAq1c(u"ࠫ࠱࠭Ḋ")+CCM4xwKVRWzN09U+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧḋ")
	if showDialogs:
		s9YWr0LQAilagMOH4PD3mF = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(NQ4hg16DPUxtOyo5iGb(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫḌ"))
		if s9YWr0LQAilagMOH4PD3mF==FZBX5WcC3msIDv4hobLd8(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪḍ"): zfvDmBkquSpdIYwhoK = Sj1PYDmIpCUXO26(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨḎ")
		elif s9YWr0LQAilagMOH4PD3mF==Y5npATFarf1H9wBjc87(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨḏ"): zfvDmBkquSpdIYwhoK = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨḐ")
		else: zfvDmBkquSpdIYwhoK = WWbmNvI40sM9Khlp25Ae(u"ࠫ็๎วว็ࠣวำื้ࠨḑ")
		U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(Y5npATFarf1H9wBjc87(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬḒ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭โ้ษษ้ࠥษฮา๋ࠪḓ"),RS7ZoyGAq1c(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧḔ"),WWbmNvI40sM9Khlp25Ae(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭ḕ"),d0HDrq8Rtk16AlInw4TXb(u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭Ḗ")+zfvDmBkquSpdIYwhoK,lh6URegmQNq8LWX0HaK5(u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḗ"))
		if U94D8BejHMsrLzO27IRpFEhC6wP==d0HDrq8Rtk16AlInw4TXb(u"࠳ਠ"): RzghXMBCAN9jEWZHkqxVKQYio14 = Sj1PYDmIpCUXO26(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧḘ")
		elif U94D8BejHMsrLzO27IRpFEhC6wP==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠵ਡ"): RzghXMBCAN9jEWZHkqxVKQYio14 = B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫḙ")
		else: RzghXMBCAN9jEWZHkqxVKQYio14 = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠧḚ")
	else:
		s9YWr0LQAilagMOH4PD3mF = LCIFdjzi5kVmRwehouHQ.getSetting(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬḛ"))
		if   s9YWr0LQAilagMOH4PD3mF==Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࠩḜ"): U94D8BejHMsrLzO27IRpFEhC6wP = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠴ਢ")
		elif s9YWr0LQAilagMOH4PD3mF==NQ4hg16DPUxtOyo5iGb(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬḝ"): U94D8BejHMsrLzO27IRpFEhC6wP = eaF2N0jWLdvHIs8r(u"࠶ਣ")
		elif s9YWr0LQAilagMOH4PD3mF==WWbmNvI40sM9Khlp25Ae(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩḞ"): U94D8BejHMsrLzO27IRpFEhC6wP = gy9NA3CROZolfEt4vVzMr(u"࠸ਤ")
		RzghXMBCAN9jEWZHkqxVKQYio14 = s9YWr0LQAilagMOH4PD3mF
	if   U94D8BejHMsrLzO27IRpFEhC6wP==KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠰ਥ"): iNVQS4dr6YI3MBov7xsbDyep2c9Z = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨḟ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==lh6URegmQNq8LWX0HaK5(u"࠲ਦ"): iNVQS4dr6YI3MBov7xsbDyep2c9Z = eaF2N0jWLdvHIs8r(u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩḠ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠴ਧ"): iNVQS4dr6YI3MBov7xsbDyep2c9Z = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪḡ")
	else: return
	LCIFdjzi5kVmRwehouHQ.setSetting(MOwK1lpyNfCgqksX3jhV(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬḢ"),RzghXMBCAN9jEWZHkqxVKQYio14)
	EBGFsUno3l7xMYZgfy51zwmQkCaRdK = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩḣ")+iNVQS4dr6YI3MBov7xsbDyep2c9Z+gy9NA3CROZolfEt4vVzMr(u"ࠩ࠯ࠫḤ")+CCM4xwKVRWzN09U+IPkQW7LojF3HO18V(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬḥ")
	fwvNpHLU8jziVcdKuSmQatAWrF = P8wc1gZWR7KV.replace(ioA3htIVanmRju,EBGFsUno3l7xMYZgfy51zwmQkCaRdK)
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: fwvNpHLU8jziVcdKuSmQatAWrF = fwvNpHLU8jziVcdKuSmQatAWrF.encode(MOwK1lpyNfCgqksX3jhV(u"ࠫࡺࡺࡦ࠹ࠩḦ"))
	open(AEJm8cgPlU9FuY26,mtEXp14ijx(u"ࠬࡽࡢࠨḧ")).write(fwvNpHLU8jziVcdKuSmQatAWrF)
	xrFqGMab4uLKZcS(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ḩ"),MOwK1lpyNfCgqksX3jhV(u"ࠧ࠯ࠢࠣࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬḩ")+iNVQS4dr6YI3MBov7xsbDyep2c9Z+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠢࡠࠫḪ"))
	if showDialogs: WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(IPkQW7LojF3HO18V(u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨḫ"))
	return
def W4OapukCqn():
	svOyXbipkwY = nEYJ5OCXG0gcNy(IPkQW7LojF3HO18V(u"ࠪࠫḬ"),lh6URegmQNq8LWX0HaK5(u"ࠫࠬḭ"),mtEXp14ijx(u"ࠬ࠭Ḯ"),QQSULIva4ljNO73mFcWw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩḯ"),QQSULIva4ljNO73mFcWw(u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬḰ"))
	if svOyXbipkwY==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴ਨ"): wwnd49zbIZB(FZBX5WcC3msIDv4hobLd8(u"࡚ࡲࡶࡧઢ"),FZBX5WcC3msIDv4hobLd8(u"࡚ࡲࡶࡧઢ"))
	return
def xKTGgtV1JA4DwYZUEch():
	ztgqWUaDpe8CE9N(FZBX5WcC3msIDv4hobLd8(u"ࠨࠩḱ"),hxSBTdGpyNVbfu4tr9(u"ࠩࠪḲ"),Sj1PYDmIpCUXO26(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ḳ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧḴ"))
	return
def uTU07tompv8AIHNWnFd3LGQlfCY9K1():
	Bro7jZXa2qAFulQW9IkPL = QQSULIva4ljNO73mFcWw(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห฻าหิࠦิ๋฻ฬࠤว๊ࠠๆฯ่ำ๊ࠥำ็หࠣ࠶࠵࠸࠱ࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḵ")
	Bro7jZXa2qAFulQW9IkPL += hxSBTdGpyNVbfu4tr9(u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬḶ")
	Bro7jZXa2qAFulQW9IkPL += hxSBTdGpyNVbfu4tr9(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪḷ")
	yQMg7VfFNB4l9UcpqiX = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮุࠣึ๐ืࠡษ็ุ้๊ๅࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḸ")
	yQMg7VfFNB4l9UcpqiX += Q2ZyGqCNYsftTc4MR7n(u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭ḹ")
	yQMg7VfFNB4l9UcpqiX += NQ4hg16DPUxtOyo5iGb(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨḺ")
	QQONb7aR2M6L = WWbmNvI40sM9Khlp25Ae(u"ࠫࡠࡘࡔࡍ࡟ࠪḻ")+Bro7jZXa2qAFulQW9IkPL+B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪḼ")+yQMg7VfFNB4l9UcpqiX
	DPfOyNk6YarWmFKU2ezZlAiG(mtEXp14ijx(u"࠭ࡲࡪࡩ࡫ࡸࠬḽ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࠨḾ"),QQONb7aR2M6L)
	return
def XfdG8SZ1laKkut(ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3):
	JoTFl8d72rKjpI0NY6x(ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡆࡢ࡮ࡶࡩણ"))
	PPtQZgSW3H7pbKk5lhiV = iFD752WvpSOGkxd6LlR0fZTQUb4CE(ygt2OrdbRqEZFPn5W6Qkx0sp4JYe3)
	id,OjIPm0do31CZ,rT84VWkePRZBIUab2oQn,j2jpfQzAmwUo6G,ctQaYd8BKeVT4qLHxNRkjUIgP,reason = PPtQZgSW3H7pbKk5lhiV[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠴਩")]
	GYMFoOBcHCEpfJ0j,E5EzWlp7eDOALB8r1jyFQiw = j2jpfQzAmwUo6G.split(RS7ZoyGAq1c(u"ࠨ࡞ࡱ࠿ࡀ࠭ḿ"))
	yQMg7VfFNB4l9UcpqiX,p2sfgbe9xhl3JXnkLc,KXHul4UAnW = ctQaYd8BKeVT4qLHxNRkjUIgP.split(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩ࡟ࡲࡀࡁࠧṀ"))
	zMnZVY3fDGs = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡕࡴࡸࡩત")
	while zMnZVY3fDGs:
		kkEAZU9SKcbtRCDMVsoNlipw64 = bxBWM9d53zOAcar(QQSULIva4ljNO73mFcWw(u"ࠪࠫṁ"),hxSBTdGpyNVbfu4tr9(u"ࠫำื่อࠩṂ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫṃ"),Jbu2G0Qax8PYWpg(u"࠭โศศ่อࠥอไหสิ฽ฬะࠧṄ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧṅ"),yQMg7VfFNB4l9UcpqiX)
		if kkEAZU9SKcbtRCDMVsoNlipw64==hxSBTdGpyNVbfu4tr9(u"࠷ਪ"): J8FBNdRGshbQYZE3fK = bxBWM9d53zOAcar(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࠩṆ"),RS7ZoyGAq1c(u"ࠩࠪṇ"),QQSULIva4ljNO73mFcWw(u"ࠪ฽ํีษࠨṈ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࠬṉ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬṊ"),p2sfgbe9xhl3JXnkLc,NQ4hg16DPUxtOyo5iGb(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪṋ"))
		elif kkEAZU9SKcbtRCDMVsoNlipw64==Q2ZyGqCNYsftTc4MR7n(u"࠷ਫ"): bbP5YM4p3QCHhi6()
		else: zMnZVY3fDGs = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡈࡤࡰࡸ࡫થ")
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫṌ"))
	return
def P3VF8mK2uN4kTgHL(showDialogs):
	svOyXbipkwY = mtEXp14ijx(u"ࡗࡶࡺ࡫દ")
	if showDialogs: svOyXbipkwY = nEYJ5OCXG0gcNy(d0HDrq8Rtk16AlInw4TXb(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨṍ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࠪṎ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࠫṏ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ุࠫสวๅࠩṐ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬํไࠡล้ฮ๋ࠥสฤๅาࠤํะั๋ัุ้ࠣำ้ࠠฬุๅ๏ืࠠอ็ํ฽ࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤา๐หࠡฬ฼์ิࠦฬๆ์฼ࠤฬ๊ลฺัสำฬะࠠฦๆ์ࠤํ฼ู๋หࠣฮะฮ๊หࠢส่อืๆศ็ฯࠤฤ࠭ṑ"))
	if svOyXbipkwY:
		sycSign827ZrEldIB = LsG7EDcei1gMShH2aVOCo(u"ࡘࡷࡻࡥધ")
		if Dh9MOxeTj6FW.path.exists(cj6P0SH4bTkwt2sIWqKYXaRNQCGJ5):
			try: Dh9MOxeTj6FW.remove(cj6P0SH4bTkwt2sIWqKYXaRNQCGJ5)
			except: sycSign827ZrEldIB = gy9NA3CROZolfEt4vVzMr(u"ࡋࡧ࡬ࡴࡧન")
		if showDialogs:
			if sycSign827ZrEldIB: ztgqWUaDpe8CE9N(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࠧṒ"),Sj1PYDmIpCUXO26(u"ࠧࠨṓ"),Y5npATFarf1H9wBjc87(u"ࠨࠩṔ"),Y5npATFarf1H9wBjc87(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩṕ"))
			else: ztgqWUaDpe8CE9N(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࠫṖ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠬṗ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠬ࠭Ṙ"),WWbmNvI40sM9Khlp25Ae(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅๅใࠣห้หูะษาหฯ࠭ṙ"))
	return
def c1W9ULBSzrpOtiG6D72jfusV4gbk():
	cCb97ROZ2yWUSYx6GqoPn()
	UBSChO2Tunz5aM3 = LCIFdjzi5kVmRwehouHQ.getSetting(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭Ṛ"))
	QQONb7aR2M6L = {}
	QQONb7aR2M6L[OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨࡃࡘࡘࡔ࠭ṛ")] = gy9NA3CROZolfEt4vVzMr(u"ࠩส่่อิࠡษ็ฮ้่วว์ࠣ๎฾๋ไࠨṜ")
	QQONb7aR2M6L[eaF2N0jWLdvHIs8r(u"ࠪࡗ࡙ࡕࡐࠨṝ")] = Jbu2G0Qax8PYWpg(u"ࠫฬ๊ใศึ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪṞ")
	QQONb7aR2M6L[OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ṟ")] = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ใศึࠣะิอࠠใืํีࠥอไๆั์ࠤ࠳ࠦࠧṠ")+str(gfKLySYJpj9/Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠶࠱ਬ"))+LsG7EDcei1gMShH2aVOCo(u"ࠧࠡัๅ๎็ฯࠠโไฺࠫṡ")
	KQaBemEwklWip6hTr3NFjosU = QQONb7aR2M6L[UBSChO2Tunz5aM3]
	U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩṢ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩๆหูࠦࠧṣ")+str(gfKLySYJpj9/IPkQW7LojF3HO18V(u"࠷࠲ਭ"))+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࠤิ่๊ใหࠪṤ"),Sj1PYDmIpCUXO26(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪṥ"),WWbmNvI40sM9Khlp25Ae(u"ࠬห๊ใษไࠤ่อๅๅࠩṦ"),KQaBemEwklWip6hTr3NFjosU,MOwK1lpyNfCgqksX3jhV(u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩṧ"))
	if U94D8BejHMsrLzO27IRpFEhC6wP==gy9NA3CROZolfEt4vVzMr(u"࠲ਮ"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = mtEXp14ijx(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨṨ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==MOwK1lpyNfCgqksX3jhV(u"࠴ਯ"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡃࡘࡘࡔ࠭ṩ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==Jbu2G0Qax8PYWpg(u"࠶ਰ"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = QQSULIva4ljNO73mFcWw(u"ࠩࡖࡘࡔࡖࠧṪ")
	else: F9ULWayiTr3SJp5jB7PdKH8Nb1 = mtEXp14ijx(u"ࠪࠫṫ")
	if F9ULWayiTr3SJp5jB7PdKH8Nb1:
		LCIFdjzi5kVmRwehouHQ.setSetting(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪṬ"),F9ULWayiTr3SJp5jB7PdKH8Nb1)
		PkGM94wmLCD = QQONb7aR2M6L[F9ULWayiTr3SJp5jB7PdKH8Nb1]
		ztgqWUaDpe8CE9N(Q2ZyGqCNYsftTc4MR7n(u"ࠬ࠭ṭ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠧṮ"),RS7ZoyGAq1c(u"ࠧࠨṯ"),PkGM94wmLCD)
	return
def r2tWck4ZmIaFTeNzp():
	QQONb7aR2M6L = {}
	QQONb7aR2M6L[a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡃࡘࡘࡔ࠭Ṱ")] = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥอไหๆๅหห๐๋ࠠ฻่่࠿ࠦࠧṱ")
	QQONb7aR2M6L[LsG7EDcei1gMShH2aVOCo(u"ࠪࡅࡘࡑࠧṲ")] = eaF2N0jWLdvHIs8r(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์ࡀࠠࠨṳ")
	QQONb7aR2M6L[onweDvmTOUj(u"࡙ࠬࡔࡐࡒࠪṴ")] = eaF2N0jWLdvHIs8r(u"࠭ำ๋ำไีࠥࡊࡎࡔ่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩṵ")
	EN2zafm9ML4KUrVIGgAwbt6 = LCIFdjzi5kVmRwehouHQ.getSetting(B2vCEI9FAVP15R8eUbDJdySc(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧṶ"))
	UBSChO2Tunz5aM3 = LCIFdjzi5kVmRwehouHQ.getSetting(WWbmNvI40sM9Khlp25Ae(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫṷ"))
	KQaBemEwklWip6hTr3NFjosU = QQONb7aR2M6L[UBSChO2Tunz5aM3]+EN2zafm9ML4KUrVIGgAwbt6
	U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(IPkQW7LojF3HO18V(u"ࠩࠪṸ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨṹ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪṺ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬห๊ใษไࠤ่อๅๅࠩṻ"),KQaBemEwklWip6hTr3NFjosU,aSf0iWG1kA7FsqjHbuC8NXB(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪṼ"))
	if U94D8BejHMsrLzO27IRpFEhC6wP==Rz34c0NP5BGo1WuTZxSfOKj(u"࠵਱"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࡂࡕࡎࠫṽ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷ਲ"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = FZBX5WcC3msIDv4hobLd8(u"ࠨࡃࡘࡘࡔ࠭Ṿ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==hxSBTdGpyNVbfu4tr9(u"࠲ਲ਼"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = gy9NA3CROZolfEt4vVzMr(u"ࠩࡖࡘࡔࡖࠧṿ")
	if U94D8BejHMsrLzO27IRpFEhC6wP in [RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠲ਵ"),lh6URegmQNq8LWX0HaK5(u"࠲਴")]:
		svOyXbipkwY = nEYJ5OCXG0gcNy(gy9NA3CROZolfEt4vVzMr(u"ࠪࡧࡪࡴࡴࡦࡴࠪẀ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ุࠫ๐ัโำ࠽ࠤࠬẁ")+urVJDsPi2IFh[MOwK1lpyNfCgqksX3jhV(u"࠴ਸ਼")],hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ู๊ࠬาใิ࠾ࠥ࠭Ẃ")+urVJDsPi2IFh[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠴਷")],S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠧẃ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧฤะอหึࠦำ๋ำไีࠥࡊࡎࡔࠢส่๊์วิส่่ࠣ࠭Ẅ"))
		if svOyXbipkwY==IPkQW7LojF3HO18V(u"࠶ਸ"): LPpdqHBWN8DZU9o2cza30Xw4 = urVJDsPi2IFh[gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶ਹ")]
		else: LPpdqHBWN8DZU9o2cza30Xw4 = urVJDsPi2IFh[OnvTrikzfEsY7qU8pgaRBtZy(u"࠱਺")]
	elif U94D8BejHMsrLzO27IRpFEhC6wP==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠳਻"): LPpdqHBWN8DZU9o2cza30Xw4 = mtEXp14ijx(u"ࠨࠩẅ")
	else: F9ULWayiTr3SJp5jB7PdKH8Nb1 = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࠪẆ")
	if F9ULWayiTr3SJp5jB7PdKH8Nb1:
		LCIFdjzi5kVmRwehouHQ.setSetting(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ẇ"),F9ULWayiTr3SJp5jB7PdKH8Nb1)
		LCIFdjzi5kVmRwehouHQ.setSetting(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫẈ"),LPpdqHBWN8DZU9o2cza30Xw4)
		PkGM94wmLCD = QQONb7aR2M6L[F9ULWayiTr3SJp5jB7PdKH8Nb1]+LPpdqHBWN8DZU9o2cza30Xw4
		ztgqWUaDpe8CE9N(WWbmNvI40sM9Khlp25Ae(u"ࠬ࠭ẉ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ࠧẊ"),QQSULIva4ljNO73mFcWw(u"ࠧࠨẋ"),PkGM94wmLCD)
	return
def qqJkh86fEOTyr():
	UBSChO2Tunz5aM3 = LCIFdjzi5kVmRwehouHQ.getSetting(B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭Ẍ"))
	QQONb7aR2M6L = {}
	QQONb7aR2M6L[hxSBTdGpyNVbfu4tr9(u"ࠩࡄ࡙࡙ࡕࠧẍ")] = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪห้ฮั้ๅึ๎ࠥอไหๆๅหห๐ࠠอษ๊ึ๊ࠥไฺ็็ࠫẎ")
	QQONb7aR2M6L[Jbu2G0Qax8PYWpg(u"ࠫࡆ࡙ࡋࠨẏ")] = WWbmNvI40sM9Khlp25Ae(u"ࠬอไษำ๋็ุ๐ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์࠭Ẑ")
	QQONb7aR2M6L[Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡓࡕࡑࡓࠫẑ")] = aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧศๆหีํ้ำ๋่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩẒ")
	KQaBemEwklWip6hTr3NFjosU = QQONb7aR2M6L[UBSChO2Tunz5aM3]
	U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(MOwK1lpyNfCgqksX3jhV(u"ࠨࠩẓ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧẔ"),RS7ZoyGAq1c(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩẕ"),LsG7EDcei1gMShH2aVOCo(u"ࠫส๐โศใࠣ็ฬ๋ไࠨẖ"),KQaBemEwklWip6hTr3NFjosU,hxSBTdGpyNVbfu4tr9(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨẗ"))
	if U94D8BejHMsrLzO27IRpFEhC6wP==QQSULIva4ljNO73mFcWw(u"࠲਼"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = gy9NA3CROZolfEt4vVzMr(u"࠭ࡁࡔࡍࠪẘ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==Y5npATFarf1H9wBjc87(u"࠴਽"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = mtEXp14ijx(u"ࠧࡂࡗࡗࡓࠬẙ")
	elif U94D8BejHMsrLzO27IRpFEhC6wP==aSf0iWG1kA7FsqjHbuC8NXB(u"࠶ਾ"): F9ULWayiTr3SJp5jB7PdKH8Nb1 = QQSULIva4ljNO73mFcWw(u"ࠨࡕࡗࡓࡕ࠭ẚ")
	else: F9ULWayiTr3SJp5jB7PdKH8Nb1 = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࠪẛ")
	if F9ULWayiTr3SJp5jB7PdKH8Nb1:
		LCIFdjzi5kVmRwehouHQ.setSetting(Q2ZyGqCNYsftTc4MR7n(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨẜ"),F9ULWayiTr3SJp5jB7PdKH8Nb1)
		PkGM94wmLCD = QQONb7aR2M6L[F9ULWayiTr3SJp5jB7PdKH8Nb1]
		ztgqWUaDpe8CE9N(lh6URegmQNq8LWX0HaK5(u"ࠫࠬẝ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬ࠭ẞ"),onweDvmTOUj(u"࠭ࠧẟ"),PkGM94wmLCD)
	return
def mzlSXPkiJtbLMTQNfAGrDsp5():
	exWqyzvc6BgsXV = LCIFdjzi5kVmRwehouHQ.getSetting(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧẠ"))
	if exWqyzvc6BgsXV==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࡕࡗࡓࡕ࠭ạ"): header = Y5npATFarf1H9wBjc87(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨẢ")
	else: header = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨả")
	svOyXbipkwY = nEYJ5OCXG0gcNy(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࠬẤ"),FZBX5WcC3msIDv4hobLd8(u"ࠬห๊ใษไࠫấ"),MOwK1lpyNfCgqksX3jhV(u"࠭สโ฻ํ่ࠬẦ"),header,d0HDrq8Rtk16AlInw4TXb(u"ࠧใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ์อ้ࠥะอะ์ฮ๋ฬࠦร้ฬ๋้ฬะ๊ไ์สࠤอ฿ฯࠡ࠳࠹ࠤุอูส่๊ࠢࠥษ่ๅࠢฦืฯิฯศ็ࠣ࠲࠳่ࠦฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊๊ࠦลัํࠤส๊้ࠡฬะำ๏ั็ศࠢไ๎้ࠥไࠡ็ิอࠥ๐สๆࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤ࠳࠴้้ࠠำหࠥ๐ำษสࠣฬ฼ฬࠠโ์ࠣๅฯำࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠠภࠣࠤࠫầ"))
	if svOyXbipkwY==-aSf0iWG1kA7FsqjHbuC8NXB(u"࠶ਿ"): return
	elif svOyXbipkwY:
		LCIFdjzi5kVmRwehouHQ.setSetting(NQ4hg16DPUxtOyo5iGb(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨẨ"),IPkQW7LojF3HO18V(u"ࠩࡄ࡙࡙ࡕࠧẩ"))
		ztgqWUaDpe8CE9N(NQ4hg16DPUxtOyo5iGb(u"ࠪࠫẪ"),FZBX5WcC3msIDv4hobLd8(u"ࠫࠬẫ"),onweDvmTOUj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨẬ"),Q2ZyGqCNYsftTc4MR7n(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨậ"))
	else:
		LCIFdjzi5kVmRwehouHQ.setSetting(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧẮ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡕࡗࡓࡕ࠭ắ"))
		ztgqWUaDpe8CE9N(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࠪẰ"),IPkQW7LojF3HO18V(u"ࠪࠫằ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẲ"),LsG7EDcei1gMShH2aVOCo(u"ࠬะๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧẳ"))
	return
def ojGUD7k6EYtAeRsaWCS(yy42JUqszVIO89i):
	if yy42JUqszVIO89i!=NQ4hg16DPUxtOyo5iGb(u"࠭ࠧẴ"):
		yy42JUqszVIO89i = s8sONHML19B5oh(yy42JUqszVIO89i)
		yy42JUqszVIO89i = yy42JUqszVIO89i.decode(Jbu2G0Qax8PYWpg(u"ࠧࡶࡶࡩ࠼ࠬẵ")).encode(Y5npATFarf1H9wBjc87(u"ࠨࡷࡷࡪ࠽࠭Ặ"))
		qZPNitrGH9vfCnI = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠷࠰࠲࠲࠶ੀ")
		c0kROfKEr31wMSNCo2HPZIsGpgqF = N7zpvB3VIPrwcSDEC.Window(qZPNitrGH9vfCnI)
		c0kROfKEr31wMSNCo2HPZIsGpgqF.getControl(IPkQW7LojF3HO18V(u"࠳࠲࠳ੁ")).setLabel(yy42JUqszVIO89i)
	return
Khm0G1Wf76Pi3TAMXOo49VcNgZEj = [
			 OnvTrikzfEsY7qU8pgaRBtZy(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࠭ࠧࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢặ")
			,LsG7EDcei1gMShH2aVOCo(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭Ẹ")
			,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ẹ")
			,Jbu2G0Qax8PYWpg(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧẺ")
			,hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧẻ")
			,gy9NA3CROZolfEt4vVzMr(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩẼ")
			,Y5npATFarf1H9wBjc87(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧẽ")+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࠦࠫẾ")+eaF2N0jWLdvHIs8r(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩế")
			,B2vCEI9FAVP15R8eUbDJdySc(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧỀ")
			,Y5npATFarf1H9wBjc87(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨề")
			,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧỂ")
			,S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧ࡟ࡠࡡࡢࡣ࠭ể")
			,WWbmNvI40sM9Khlp25Ae(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭Ễ")
			]
def gg3izLJDBR1Xw6Klo(BNvjADpPbo8fXZ6E4xLnczuWHT):
	if gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧễ") in BNvjADpPbo8fXZ6E4xLnczuWHT and gy9NA3CROZolfEt4vVzMr(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨỆ") in BNvjADpPbo8fXZ6E4xLnczuWHT: return B2vCEI9FAVP15R8eUbDJdySc(u"࡚ࡲࡶࡧ઩")
	for yy42JUqszVIO89i in Khm0G1Wf76Pi3TAMXOo49VcNgZEj:
		if yy42JUqszVIO89i in BNvjADpPbo8fXZ6E4xLnczuWHT: return nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࡔࡳࡷࡨપ")
	return a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡇࡣ࡯ࡷࡪફ")
def wG1pUVPoTNlj0(data):
	data = data.replace(NQ4hg16DPUxtOyo5iGb(u"ࠫࡡࡸ࡜࡯ࠩệ")+q6yUEoKVDb0fXmc8vhrMk7N(u"࠶࠳ੂ")*a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬࠦࠧỈ")+Y5npATFarf1H9wBjc87(u"࠭࡜ࡳ࡞ࡱࠫỉ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧ࡝ࡴ࡟ࡲࠬỊ"))
	data = data.replace(Sj1PYDmIpCUXO26(u"ࠨ࡞ࡱࠫị")+LsG7EDcei1gMShH2aVOCo(u"࠷࠴੃")*Q2ZyGqCNYsftTc4MR7n(u"ࠩࠣࠫỌ")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡠࡷࡢ࡮ࠨọ"),QQSULIva4ljNO73mFcWw(u"ࠫࡡࡸ࡜࡯ࠩỎ"))
	data = data.replace(WWbmNvI40sM9Khlp25Ae(u"ࠬࡢ࡮ࠨỏ")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠸࠵੄")*a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࠠࠨỐ")+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧ࡝ࡰࠪố"),Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡞ࡱࠫỒ"))
	data = data.replace(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩ࡟ࡲࠬồ")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠺࠷੆")*Y5npATFarf1H9wBjc87(u"ࠪࠤࠬỔ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡡࡴࠧổ")+MOwK1lpyNfCgqksX3jhV(u"࠷࠶੅")*RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࠦࠧỖ"))
	data = data.replace(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬỗ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧ࠻ࠢࠪỘ"))
	ZZm1hsDV9ba = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩộ")
	for BNvjADpPbo8fXZ6E4xLnczuWHT in data.splitlines():
		LqeRihS0pKogOI6GvTjB8FkCZQ = SomeI8i56FaDMGPE.findall(Q2ZyGqCNYsftTc4MR7n(u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠯ࠫࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨỚ"),BNvjADpPbo8fXZ6E4xLnczuWHT,SomeI8i56FaDMGPE.DOTALL)
		if LqeRihS0pKogOI6GvTjB8FkCZQ: BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(LqeRihS0pKogOI6GvTjB8FkCZQ[gy9NA3CROZolfEt4vVzMr(u"࠶ੇ")],eaF2N0jWLdvHIs8r(u"ࠪࠫớ"))
		ZZm1hsDV9ba += FZBX5WcC3msIDv4hobLd8(u"ࠫࡡࡴࠧỜ")+BNvjADpPbo8fXZ6E4xLnczuWHT
	return ZZm1hsDV9ba
def zqCHFSkEdhiDc7Un3YtZexr4(OaQzSUX1wIitVHJhqefxWs8loBgkLZ):
	if RS7ZoyGAq1c(u"ࠬࡕࡌࡅࠩờ") in OaQzSUX1wIitVHJhqefxWs8loBgkLZ:
		HHr84w7NSyadXY2eUGjcM0tgC = rrJcyI8Zl90
		header = lh6URegmQNq8LWX0HaK5(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭Ở")
	else:
		HHr84w7NSyadXY2eUGjcM0tgC = SSiIRuULQTe6taoBd
		header = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧở")
	svOyXbipkwY = nEYJ5OCXG0gcNy(Y5npATFarf1H9wBjc87(u"ࠨࠩỠ"),Y5npATFarf1H9wBjc87(u"ࠩࠪỡ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࠫỢ"),header,LsG7EDcei1gMShH2aVOCo(u"ุࠫาไࠡษ็วำ฽วยࠢํัฯ๎๊ࠡลํฺฬูࠦๅ๋ࠣืั๊ࠠศๆสืฯิฯศ็ࠣ࠲ࠥ๎วๅษฮ๊๏์ࠠืำ๋ี๏ฯࠠๅ็฼ีๆฯࠠไ์ไࠤาีหหࠢสฺ่๊ใๅหࠣ์๊อ่๊ࠠࠣห้๋ใศ่ࠣห้ึ๊ࠡีหฬࠥำฯ้อࠣห้๋ิไๆฬࠤ࠳ࠦใ้ัํࠤ๏ำสโฺࠣฬุาไ๋่ࠣ࠲ࠥอไฤ๊็ࠤ์๎ࠠศๆึะ้ࠦวๅฯส่๏่ࠦโ์๊ࠤ๊฿ไ้็สฮࠥะศะล้๋ࠣึࠠษัส๎ฮࠦวๅฬื฾๏๊ࠠศๆะห้๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦศๆ์ࠤฬ๊ย็ࠢ࠱ࠤศ๋วࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠโ้๋ࠤฬ๊ำอๆࠣหู้วษไࠣห้ึ๊ࠡฬ่ࠤัู๋่่๊ࠢࠥฮั็ษ่ะ้่ࠥะ์ࠣๆอ๊ࠠระิࠤส฽แศร่ࠣ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧợ"))
	if svOyXbipkwY!=MOwK1lpyNfCgqksX3jhV(u"࠱ੈ"): return
	sqpGTLdbA4S,ZKaC36j9WkcqXeML = [],Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠱੉")
	size,count = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(HHr84w7NSyadXY2eUGjcM0tgC)
	file = open(HHr84w7NSyadXY2eUGjcM0tgC,RS7ZoyGAq1c(u"ࠬࡸࡢࠨỤ"))
	if size>QQSULIva4ljNO73mFcWw(u"࠴࠴࠵࠸࠰࠱ੋ"): file.seek(-hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠳࠳࠴࠶࠶࠰੊"),Dh9MOxeTj6FW.SEEK_END)
	data = file.read()
	file.close()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: data = data.decode(hxSBTdGpyNVbfu4tr9(u"࠭ࡵࡵࡨ࠻ࠫụ"))
	data = wG1pUVPoTNlj0(data)
	IozWafE1PiOCyMLjR = data.split(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧ࡝ࡰࠪỦ"))
	for BNvjADpPbo8fXZ6E4xLnczuWHT in reversed(IozWafE1PiOCyMLjR):
		I2ILqFcZBHMvpn1XEj5rz = gg3izLJDBR1Xw6Klo(BNvjADpPbo8fXZ6E4xLnczuWHT)
		if I2ILqFcZBHMvpn1XEj5rz: continue
		BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࡡࠪủ"),FZBX5WcC3msIDv4hobLd8(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨỨ"))
		BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(d0HDrq8Rtk16AlInw4TXb(u"ࠪࡉࡗࡘࡏࡓ࠼ࠪứ"),eaF2N0jWLdvHIs8r(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇ࠲࠳࠴࠵ࡣࡅࡓࡔࡒࡖ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧỪ"))
		UZhlSE0O9CDP5 = LsG7EDcei1gMShH2aVOCo(u"ࠬ࠭ừ")
		sLHD9dj2WI04aBZni = SomeI8i56FaDMGPE.findall(hxSBTdGpyNVbfu4tr9(u"࠭࡞ࠩ࡞ࡧ࠯࠲࠮࡜ࡥ࠭࠰ࡠࡩ࠱ࠠ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭ࠬ࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭Ử"),BNvjADpPbo8fXZ6E4xLnczuWHT,SomeI8i56FaDMGPE.DOTALL)
		if sLHD9dj2WI04aBZni:
			BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(sLHD9dj2WI04aBZni[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵੍")][S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵੍")],sLHD9dj2WI04aBZni[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵੍")][hxSBTdGpyNVbfu4tr9(u"࠵ੌ")]).replace(sLHD9dj2WI04aBZni[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵੍")][IPkQW7LojF3HO18V(u"࠸੎")],KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨử"))
			UZhlSE0O9CDP5 = sLHD9dj2WI04aBZni[eaF2N0jWLdvHIs8r(u"࠱੐")][eaF2N0jWLdvHIs8r(u"࠱੏")]
		else:
			sLHD9dj2WI04aBZni = SomeI8i56FaDMGPE.findall(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨỮ"),BNvjADpPbo8fXZ6E4xLnczuWHT,SomeI8i56FaDMGPE.DOTALL)
			if sLHD9dj2WI04aBZni:
				BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(sLHD9dj2WI04aBZni[nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠳੒")][MOwK1lpyNfCgqksX3jhV(u"࠳ੑ")],Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࠪữ"))
				UZhlSE0O9CDP5 = sLHD9dj2WI04aBZni[OnvTrikzfEsY7qU8pgaRBtZy(u"࠴੓")][OnvTrikzfEsY7qU8pgaRBtZy(u"࠴੓")]
		if UZhlSE0O9CDP5: BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(UZhlSE0O9CDP5,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭Ự")+UZhlSE0O9CDP5+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ự"))
		sqpGTLdbA4S.append(BNvjADpPbo8fXZ6E4xLnczuWHT)
		if len(str(sqpGTLdbA4S))>hxSBTdGpyNVbfu4tr9(u"࠺࠶࠱࠱࠲੔"): break
	sqpGTLdbA4S = reversed(sqpGTLdbA4S)
	WyBrDTnwP0gUi8YCkb = hxSBTdGpyNVbfu4tr9(u"ࠬࡢ࡮ࠨỲ").join(sqpGTLdbA4S)
	DPfOyNk6YarWmFKU2ezZlAiG(lh6URegmQNq8LWX0HaK5(u"࠭࡬ࡦࡨࡷࠫỳ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧระิࠤศูืาࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠫỴ"),WyBrDTnwP0gUi8YCkb,nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫỵ"))
	return
def CGBeYtkf30lVAFW():
	ki7EWwgAh43lc0RnqTmObM = open(ondphfgrlZ,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡵࡦࠬỶ")).read()
	if ZZxLpCcmqhyT6NuMWelkbSvr0H: ki7EWwgAh43lc0RnqTmObM = ki7EWwgAh43lc0RnqTmObM.decode(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡹࡹ࡬࠸ࠨỷ"))
	ki7EWwgAh43lc0RnqTmObM = ki7EWwgAh43lc0RnqTmObM.replace(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡡࡺࠧỸ"),LsG7EDcei1gMShH2aVOCo(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧỹ"))
	jcx62oQkzE5gIy = SomeI8i56FaDMGPE.findall(MOwK1lpyNfCgqksX3jhV(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧỺ"),ki7EWwgAh43lc0RnqTmObM,SomeI8i56FaDMGPE.DOTALL)
	for BNvjADpPbo8fXZ6E4xLnczuWHT in jcx62oQkzE5gIy:
		ki7EWwgAh43lc0RnqTmObM = ki7EWwgAh43lc0RnqTmObM.replace(BNvjADpPbo8fXZ6E4xLnczuWHT,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪỻ")+BNvjADpPbo8fXZ6E4xLnczuWHT+Y5npATFarf1H9wBjc87(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪỼ"))
	CvFLQP9JtbqH(onweDvmTOUj(u"ࠩส่ฯเ๊๋ำสฮࠥอไฤะํีฮࠦแ๋ࠢส่อืวๆฮࠪỽ"),ki7EWwgAh43lc0RnqTmObM)
	return
def QGetiy1EpLfsokl8cT():
	Bro7jZXa2qAFulQW9IkPL = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪฬ฾฼ࠠศๆฦึึอัࠡ฻็ํࠥอไา์่์ฯࠦใ้่อีํ๊ࠠห๊ไีࠥหๅไษ้๎ฮࠦสใัํ้ࠥ๎สฤะํีࠥอไโ์า๎ํ่่ࠦา๊ࠤฬ๊รำำสีࠥํ๊ࠡษ็วุํๅ๊ࠡส่ศืโศ็้ࠣ฾ࠦศฺุࠣ์่อไหษ็๎ࠬỾ")
	yQMg7VfFNB4l9UcpqiX = gy9NA3CROZolfEt4vVzMr(u"้ࠫะโะ์่ࠤฬ๊แ๋ัํ์ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ๆ์้ࠤํ๊สฤะํี์ࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋ีสีࠥ࠴ࠠฤ็สࠤ฾ีษࠡษึ๋๊ࠦๅหฬส่๏ฯࠠโ้ำ๋ࠥะโ้็ࠣฬฯำั๋ๅࠣห้็๊ะ์๋ࠤอ๎โหࠢส็อืࠠๆ่ࠣ์็ะࠠศๆึ๋๊ࠦวๅ๊สัิࠦ࠮ࠡล่หࠥอไิ้่ࠤฬ๊รฺๆ์ࠤํอไฤีไ่ࠥ็็้ࠢํัึ้ࠠศๆไ๎ิ๐่ࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥ๎ไไ่ࠣฬ็็าสࠢๆฬ๏ืษࠨỿ")
	p2sfgbe9xhl3JXnkLc = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬษๅศࠢส่ศืโศ็ࠣๅ์๐ࠠหีอาิ๋ࠠๅๆอๆิ๐ๅ๊ࠡส่ฯษฮ๋ำࠣ์้้ๆࠡส่ๆิอัࠡ฻าำࠥอไฬ๊ส๊๏่ࠦศๆาๆฬฬโࠡ࠰้ࠣะ๊วࠡำๅ้ࠥ࠻࠴࠵ࠢอ฽๋๐ࠠ࠶ࠢาๆฬฬโ๊ࠡࠣ࠸࠹ࠦหศ่ํอࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวยࠢหัุฮࠠศีอาิอๅไࠢ็ุ่ํๅࠡษ็๎๊๐ๆࠡล๋ࠤุํๅࠡษ็๎ุอัࠨἀ")
	QQONb7aR2M6L = Bro7jZXa2qAFulQW9IkPL+aSf0iWG1kA7FsqjHbuC8NXB(u"࠭࠺ࠡࠩἁ")+yQMg7VfFNB4l9UcpqiX+mtEXp14ijx(u"ࠧࠡ࠰ࠣࠫἂ")+p2sfgbe9xhl3JXnkLc
	DPfOyNk6YarWmFKU2ezZlAiG(Sj1PYDmIpCUXO26(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἃ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἄ"),QQONb7aR2M6L,WWbmNvI40sM9Khlp25Ae(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ἅ"))
	return
def sOki9wK4yjEg3oHa(type,QQONb7aR2M6L,showDialogs=B2vCEI9FAVP15R8eUbDJdySc(u"ࡖࡵࡹࡪબ"),url=wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠫࠬἆ"),ucGVEfRSBY=Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬ࠭ἇ"),yy42JUqszVIO89i=RS7ZoyGAq1c(u"࠭ࠧἈ"),Sp56QBE7k483g9hWRTD=LsG7EDcei1gMShH2aVOCo(u"ࠧࠨἉ")):
	v1h3z6Vd2pbjJOSir08Bu = aSf0iWG1kA7FsqjHbuC8NXB(u"ࡗࡶࡺ࡫ભ")
	if not tvwmlYcDnVybgPHKU84GOFI0uAq(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩἊ")):
		if showDialogs:
			QDiBh23IyZcqTRsVfCXuJpkmta = (IPkQW7LojF3HO18V(u"ࠩสุ่฽ั࠻ࠩἋ") in QQONb7aR2M6L and B2vCEI9FAVP15R8eUbDJdySc(u"ࠪห้๋ใศ่࠽ࠫἌ") in QQONb7aR2M6L and S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫฬ๊ๅๅใ࠽ࠫἍ") in QQONb7aR2M6L and RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬอไฯูฦࠫἎ") in QQONb7aR2M6L and hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭วๅ็ุำึࡀࠧἏ") in QQONb7aR2M6L)
			if not QDiBh23IyZcqTRsVfCXuJpkmta: v1h3z6Vd2pbjJOSir08Bu = nEYJ5OCXG0gcNy(lh6URegmQNq8LWX0HaK5(u"ࠧࡤࡧࡱࡸࡪࡸࠧἐ"),d0HDrq8Rtk16AlInw4TXb(u"ࠨࠩἑ"),mtEXp14ijx(u"ࠩࠪἒ"),q6yUEoKVDb0fXmc8vhrMk7N(u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧἓ"),QQONb7aR2M6L.replace(lh6URegmQNq8LWX0HaK5(u"ࠫࡡࡢ࡮ࠨἔ"),RS7ZoyGAq1c(u"ࠬࡢ࡮ࠨἕ")))
	elif showDialogs:
		QQONb7aR2M6L = NQ4hg16DPUxtOyo5iGb(u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭἖")
		HDNfaCt1Pud5j6ETrUzmgW7k = nEYJ5OCXG0gcNy(Jbu2G0Qax8PYWpg(u"ࠧࡤࡧࡱࡸࡪࡸࠧ἗"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩἘ"),Jbu2G0Qax8PYWpg(u"ࠩࠪἙ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪἚ")+IPkQW7LojF3HO18V(u"ࠫࠥࠦ࠱࠰࠷ࠪἛ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪἜ"))
		o6yMWTEehSvzfAwZuFKdCis1m = nEYJ5OCXG0gcNy(RS7ZoyGAq1c(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ἕ"),IPkQW7LojF3HO18V(u"ࠧࠨ἞"),MOwK1lpyNfCgqksX3jhV(u"ࠨࠩ἟"),Q2ZyGqCNYsftTc4MR7n(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩἠ")+lh6URegmQNq8LWX0HaK5(u"ࠪࠤࠥ࠸࠯࠶ࠩἡ"),mtEXp14ijx(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩἢ"))
		mKRC9BEgnkz01PODcXeSQY4Hvja6 = nEYJ5OCXG0gcNy(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬἣ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࠧἤ"),onweDvmTOUj(u"ࠧࠨἥ"),lh6URegmQNq8LWX0HaK5(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨἦ")+RS7ZoyGAq1c(u"ࠩࠣࠤ࠸࠵࠵ࠨἧ"),hxSBTdGpyNVbfu4tr9(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨἨ"))
		N25Y8XEKQt = nEYJ5OCXG0gcNy(QQSULIva4ljNO73mFcWw(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫἩ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭Ἢ"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧἫ"),Y5npATFarf1H9wBjc87(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧἬ")+q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠢࠣ࠸࠴࠻ࠧἭ"),hxSBTdGpyNVbfu4tr9(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧἮ"))
		v1h3z6Vd2pbjJOSir08Bu = nEYJ5OCXG0gcNy(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡧࡪࡴࡴࡦࡴࠪἯ"),WWbmNvI40sM9Khlp25Ae(u"ࠫࠬἰ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠭ἱ"),B2vCEI9FAVP15R8eUbDJdySc(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ἲ")+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࠡࠢ࠸࠳࠺࠭ἳ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ἴ"))
	OjIPm0do31CZ = vT7q0oj96p(onweDvmTOUj(u"࠹࠲੕"),Y5npATFarf1H9wBjc87(u"ࡊࡦࡲࡳࡦમ"))
	HGn0NOoeaShfVkMD3qvmugtUc5Y = eaF2N0jWLdvHIs8r(u"ࠩࡄ࡚࠿ࠦࠧἵ")+OjIPm0do31CZ+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪ࠱ࠬἶ")+type
	fjrgCSVBFcNdAaoWMOv = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࡚ࡲࡶࡧર") if nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧἷ") in yy42JUqszVIO89i else QQSULIva4ljNO73mFcWw(u"ࡋࡧ࡬ࡴࡧય")
	if not v1h3z6Vd2pbjJOSir08Bu:
		if showDialogs: ztgqWUaDpe8CE9N(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭Ἰ"),Sj1PYDmIpCUXO26(u"࠭ࠧἹ"),WWbmNvI40sM9Khlp25Ae(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪἺ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫἻ"))
		return Y5npATFarf1H9wBjc87(u"ࡆࡢ࡮ࡶࡩ઱")
	wblIOZ1qakNzcsFBUgjH = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getInfoLabel(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨἼ"))
	QQONb7aR2M6L += hxSBTdGpyNVbfu4tr9(u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩἽ")+Y0Uhv2t8E67+lh6URegmQNq8LWX0HaK5(u"ࠫࠥࡀ࡜࡝ࡰࠪἾ")
	QQONb7aR2M6L += B2vCEI9FAVP15R8eUbDJdySc(u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭Ἷ")+OjIPm0do31CZ+mtEXp14ijx(u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬὀ")+StEXpdf2BL3wkh1izc8snHFMNAPWql+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧࠡ࠼࡟ࡠࡳ࠭ὁ")
	QQONb7aR2M6L += RS7ZoyGAq1c(u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭ὂ")+wblIOZ1qakNzcsFBUgjH
	JDvtTgnMmr3GhfSLVoWzd9N = dNGVlWsQaB23Y4vtRZ70c()
	JDvtTgnMmr3GhfSLVoWzd9N = TbEVs6mLPHF(JDvtTgnMmr3GhfSLVoWzd9N)
	if JDvtTgnMmr3GhfSLVoWzd9N: QQONb7aR2M6L += Q2ZyGqCNYsftTc4MR7n(u"ࠩࠣ࠾ࡡࡢ࡮ࡍࡱࡦࡥࡹ࡯࡯࡯࠼ࠣࠫὃ")+JDvtTgnMmr3GhfSLVoWzd9N
	if url: QQONb7aR2M6L += hxSBTdGpyNVbfu4tr9(u"ࠪࠤ࠿ࡢ࡜࡯ࡗࡕࡐ࠿ࠦࠧὄ")+url
	if ucGVEfRSBY: QQONb7aR2M6L += RS7ZoyGAq1c(u"ࠫࠥࡀ࡜࡝ࡰࡖࡳࡺࡸࡣࡦ࠼ࠣࠫὅ")+ucGVEfRSBY
	QQONb7aR2M6L += Y5npATFarf1H9wBjc87(u"ࠬࠦ࠺࡝࡞ࡱࠫ὆")
	if showDialogs: NCXj2ri3Unm6TFWIgwh(RS7ZoyGAq1c(u"࠭ฬศำํࠤฬ๊ลาีส่ࠬ὇"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧศๆิะฬวࠠศๆส๊ฯ฾วาࠩὈ"))
	if Sp56QBE7k483g9hWRTD:
		WyBrDTnwP0gUi8YCkb = Sp56QBE7k483g9hWRTD
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: WyBrDTnwP0gUi8YCkb = WyBrDTnwP0gUi8YCkb.encode(mtEXp14ijx(u"ࠨࡷࡷࡪ࠽࠭Ὁ"))
		WyBrDTnwP0gUi8YCkb = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64encode(WyBrDTnwP0gUi8YCkb)
	elif fjrgCSVBFcNdAaoWMOv:
		if Jbu2G0Qax8PYWpg(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩὊ") in yy42JUqszVIO89i: o0hF8JRbGsWPfqSQgex62kiVKrY = rrJcyI8Zl90
		else: o0hF8JRbGsWPfqSQgex62kiVKrY = SSiIRuULQTe6taoBd
		if not Dh9MOxeTj6FW.path.exists(o0hF8JRbGsWPfqSQgex62kiVKrY):
			ztgqWUaDpe8CE9N(Sj1PYDmIpCUXO26(u"ࠪࠫὋ"),lh6URegmQNq8LWX0HaK5(u"ࠫࠬὌ"),Y5npATFarf1H9wBjc87(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨὍ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ὎"))
			return hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡇࡣ࡯ࡷࡪલ")
		sqpGTLdbA4S,ZKaC36j9WkcqXeML = [],S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠰੖")
		size,count = Bq4eSinuNOvIaLX6KHWxMm8P0zThYf(o0hF8JRbGsWPfqSQgex62kiVKrY)
		file = open(o0hF8JRbGsWPfqSQgex62kiVKrY,Sj1PYDmIpCUXO26(u"ࠧࡳࡤࠪ὏"))
		if size>S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠴࠸࠴࠷࠶࠰੘"): file.seek(-B2vCEI9FAVP15R8eUbDJdySc(u"࠳࠷࠳࠵࠵࠶੗"),Dh9MOxeTj6FW.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡷࡷࡪ࠽࠭ὐ"))
		data = wG1pUVPoTNlj0(data)
		IozWafE1PiOCyMLjR = data.splitlines()
		for BNvjADpPbo8fXZ6E4xLnczuWHT in reversed(IozWafE1PiOCyMLjR):
			I2ILqFcZBHMvpn1XEj5rz = gg3izLJDBR1Xw6Klo(BNvjADpPbo8fXZ6E4xLnczuWHT)
			if I2ILqFcZBHMvpn1XEj5rz: continue
			sLHD9dj2WI04aBZni = SomeI8i56FaDMGPE.findall(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩὑ"),BNvjADpPbo8fXZ6E4xLnczuWHT,SomeI8i56FaDMGPE.DOTALL)
			if sLHD9dj2WI04aBZni:
				BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(sLHD9dj2WI04aBZni[lh6URegmQNq8LWX0HaK5(u"࠴ਗ਼")][lh6URegmQNq8LWX0HaK5(u"࠴ਗ਼")],sLHD9dj2WI04aBZni[lh6URegmQNq8LWX0HaK5(u"࠴ਗ਼")][gy9NA3CROZolfEt4vVzMr(u"࠴ਖ਼")]).replace(sLHD9dj2WI04aBZni[lh6URegmQNq8LWX0HaK5(u"࠴ਗ਼")][Sj1PYDmIpCUXO26(u"࠷ਜ਼")],RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࠫὒ"))
			else:
				sLHD9dj2WI04aBZni = SomeI8i56FaDMGPE.findall(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫὓ"),BNvjADpPbo8fXZ6E4xLnczuWHT,SomeI8i56FaDMGPE.DOTALL)
				if sLHD9dj2WI04aBZni: BNvjADpPbo8fXZ6E4xLnczuWHT = BNvjADpPbo8fXZ6E4xLnczuWHT.replace(sLHD9dj2WI04aBZni[gy9NA3CROZolfEt4vVzMr(u"࠰੝")][q6yUEoKVDb0fXmc8vhrMk7N(u"࠷ੜ")],hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬ࠭ὔ"))
			sqpGTLdbA4S.append(BNvjADpPbo8fXZ6E4xLnczuWHT)
			if len(str(sqpGTLdbA4S))>Y5npATFarf1H9wBjc87(u"࠲࠴࠴࠴࠵࠶ਫ਼"): break
		sqpGTLdbA4S = reversed(sqpGTLdbA4S)
		WyBrDTnwP0gUi8YCkb = Sj1PYDmIpCUXO26(u"࠭࡜ࡳ࡞ࡱࠫὕ").join(sqpGTLdbA4S)
		WyBrDTnwP0gUi8YCkb = WyBrDTnwP0gUi8YCkb.encode(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧࡶࡶࡩ࠼ࠬὖ"))
		WyBrDTnwP0gUi8YCkb = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64encode(WyBrDTnwP0gUi8YCkb)
	else: WyBrDTnwP0gUi8YCkb = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠩὗ")
	url = ZEgwHfRnFV4[eaF2N0jWLdvHIs8r(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ὘")][aSf0iWG1kA7FsqjHbuC8NXB(u"࠴੟")]
	P8AGL4xSd9rWD1Vz = {wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫὙ"):HGn0NOoeaShfVkMD3qvmugtUc5Y,IPkQW7LojF3HO18V(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡪ࠭὚"):QQONb7aR2M6L,RS7ZoyGAq1c(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭Ὓ"):WyBrDTnwP0gUi8YCkb}
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,hxSBTdGpyNVbfu4tr9(u"࠭ࡐࡐࡕࡗࠫ὜"),url,P8AGL4xSd9rWD1Vz,eaF2N0jWLdvHIs8r(u"ࠧࠨὝ"),hxSBTdGpyNVbfu4tr9(u"ࠨࠩ὞"),lh6URegmQNq8LWX0HaK5(u"ࠩࠪὟ"),NQ4hg16DPUxtOyo5iGb(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭ὠ"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	if MOwK1lpyNfCgqksX3jhV(u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭ὡ") in BsJ71WIxDtdFKveTcRPrqM4Cwb: sycSign827ZrEldIB = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡖࡵࡹࡪળ")
	else: sycSign827ZrEldIB = OnvTrikzfEsY7qU8pgaRBtZy(u"ࡉࡥࡱࡹࡥ઴")
	if showDialogs:
		if sycSign827ZrEldIB:
			NCXj2ri3Unm6TFWIgwh(mtEXp14ijx(u"ࠬะๅࠡษ็ษึูวๅࠩὢ"),LsG7EDcei1gMShH2aVOCo(u"࠭ศ็ฮสัࠬὣ"))
			ztgqWUaDpe8CE9N(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࠨὤ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠩὥ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨὦ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬὧ"))
		else:
			NCXj2ri3Unm6TFWIgwh(NQ4hg16DPUxtOyo5iGb(u"้๊ࠫริใࠪὨ"),IPkQW7LojF3HO18V(u"ࠬ็ิๅࠢไ๎ࠥอไฦำึห้࠭Ὡ"))
			ztgqWUaDpe8CE9N(d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧὪ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧࠨὫ"),onweDvmTOUj(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫὬ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩั฻ศ่ࠦโึ็ࠤๆ๐ࠠฦำึห้ࠦวๅำึห้ฯࠧὭ"))
	return sycSign827ZrEldIB
def XhQFZ9Nfj8VlqA0():
	Bro7jZXa2qAFulQW9IkPL = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠪ࠵࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡰࡳࡱࡥࡰࡪࡳࠠࡸ࡫ࡷ࡬ࠥࡇࡲࡢࡤ࡬ࡧࠥࡺࡥࡹࡶࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩὮ")
	yQMg7VfFNB4l9UcpqiX = RS7ZoyGAq1c(u"ࠫ࠶࠴ࠠࠡࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭Ὧ")
	ztgqWUaDpe8CE9N(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭ὰ"),mtEXp14ijx(u"࠭ࠧά"),LsG7EDcei1gMShH2aVOCo(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡑࡴࡲࡦࡱ࡫࡭ࠨὲ"),Bro7jZXa2qAFulQW9IkPL+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨ࡞ࡱࡠࡳ࠭έ")+yQMg7VfFNB4l9UcpqiX)
	Bro7jZXa2qAFulQW9IkPL = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩ࠵࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡦࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠨὴ")
	yQMg7VfFNB4l9UcpqiX = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪ࠶࠳ࠦࠠࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆ่ๅࠡสอ฾๏๐ัࠡษ็ะ้ีࠠฬ็ࠣๆ๊ࠦศห฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪή")
	ztgqWUaDpe8CE9N(onweDvmTOUj(u"ࠫࠬὶ"),onweDvmTOUj(u"ࠬ࠭ί"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬὸ"),Bro7jZXa2qAFulQW9IkPL+Sj1PYDmIpCUXO26(u"ࠧ࡝ࡰ࡟ࡲࠬό")+yQMg7VfFNB4l9UcpqiX)
	Bro7jZXa2qAFulQW9IkPL = B2vCEI9FAVP15R8eUbDJdySc(u"ࠨ࠵࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡤࡰࡰ࡟ࠫࡹࠦࡨࡢࡸࡨࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭ὺ")
	yQMg7VfFNB4l9UcpqiX = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩ࠶࠲ࠥࠦࠠฦาสࠤ้๋๋ࠠๅ้ࠤ้ี๊ไࠢ็์าฯࠠๆใสฮ๏ำฺࠠำห๎ฮࠦแศา๊ฬࠥหไ๊ࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้๋฽โสࠢส่ัเัศใํอࠬύ")
	ztgqWUaDpe8CE9N(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪࠫὼ"),mtEXp14ijx(u"ࠫࠬώ"),LsG7EDcei1gMShH2aVOCo(u"ࠬࡌ࡯࡯ࡶࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ὾"),Bro7jZXa2qAFulQW9IkPL+q6yUEoKVDb0fXmc8vhrMk7N(u"࠭࡜࡯࡞ࡱࠫ὿")+yQMg7VfFNB4l9UcpqiX)
	svOyXbipkwY = nEYJ5OCXG0gcNy(Y5npATFarf1H9wBjc87(u"ࠧࡤࡧࡱࡸࡪࡸࠧᾀ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࠩᾁ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠩࠪᾂ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪࡊࡴࡴࡴࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠪᾃ"),onweDvmTOUj(u"ࠫࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡱࡳࡼࠦ࠿ࠨᾄ")+NQ4hg16DPUxtOyo5iGb(u"ࠬࡢ࡮࡝ࡰࠪᾅ")+gy9NA3CROZolfEt4vVzMr(u"࠭็ๅࠢอี๏ีࠠศๆำ๋ฬฮࠠฦๆ์ࠤ้๎อสࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฤๆล๊ฤ࠭ᾆ"))
	if svOyXbipkwY==IPkQW7LojF3HO18V(u"࠴੠"): VbALIM4mvWkGJz2QgwohTjERHY()
	return
def BBuGHOLYMA():
	ztgqWUaDpe8CE9N(hxSBTdGpyNVbfu4tr9(u"ࠧࠨᾇ"),FZBX5WcC3msIDv4hobLd8(u"ࠨࠩᾈ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᾉ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอ๋่้ࠢะรไัࠣๆ๊ࠦศหึ฽๎้ࠦวๅำสฬ฼ࠦวๅาํࠤ้อ๋ࠠ฻่่ࠥัๅࠡไ่ࠤอหัิษ็ࠤฺ๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤฬ๊โศศ่อࠥอไาศํื๏ฯࠠๅๆหี๋อๅอࠩᾊ"))
	return
def qqeNbd1yW5nBZMIHfm3SP6C():
	QQONb7aR2M6L = d0HDrq8Rtk16AlInw4TXb(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ้ࠣำ฻ีࠡใๅ฻๊ࠥไ฻หࠣห้฿ัษ์ฬࠤํ๊ใ็๊ࠢิฬࠦไศࠢํ้๋฿้ࠠฮ๋ำ๋่ࠥศไ฼ࠤๆ๐็ศࠢฦๅ้อๅ๊่ࠡืู้ไศฬ้ࠣฯืฬๆหࠣวํࠦๅะส็ะฮࠦลๅ๋ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ์ฬ๊้ࠡๆ฽หฯࠦวฯำ์ࠤํ๊วࠡ์๋ะิࠦำษส่้ࠣะใาษิࠫᾋ")
	ztgqWUaDpe8CE9N(RS7ZoyGAq1c(u"ࠬ࠭ᾌ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࠧᾍ"),mtEXp14ijx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾎ"),QQONb7aR2M6L)
	return
def UGsd7O6vc9NPH0():
	QQONb7aR2M6L = mtEXp14ijx(u"ࠨษ็ีํอศุࠢส่อ฽๊วห่ࠣฬูࠦๅษๅอ๊ࠥ็ศࠢหห้ฮั็ษ่ะࠥ๎ฺศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠬᾏ")
	ztgqWUaDpe8CE9N(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࠪᾐ"),IPkQW7LojF3HO18V(u"ࠪࠫᾑ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᾒ"),QQONb7aR2M6L)
	return
def FeKLjQHTNsb139Wo8hx4():
	QQONb7aR2M6L = QQSULIva4ljNO73mFcWw(u"ࠬํ๊ࠡีํีๆืวหࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠศีอาิอๅ่ษࠣฬุฮศࠡๅ๋๊์อࠠๆฯ่๎ฮࠦๅ็ࠢส่๊฻ฯาࠢฦ์ࠥฮอศฮฬࠤส๊้ࠡษืฮึอใࠡำึ้๏ࠦร้ࠢฯำ๏ีษࠡล๋ࠤ้อ๋ࠠ฻ิๅ์อࠠศๆหี๋อๅอࠩᾓ")
	ztgqWUaDpe8CE9N(lh6URegmQNq8LWX0HaK5(u"࠭ࠧᾔ"),onweDvmTOUj(u"ࠧࠨᾕ"),QQSULIva4ljNO73mFcWw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᾖ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫᾗ"),QQONb7aR2M6L)
	return
def ccbprLiXNVRBqz0ufFG():
	QQONb7aR2M6L = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨᾘ")
	DPfOyNk6YarWmFKU2ezZlAiG(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᾙ"),IPkQW7LojF3HO18V(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᾚ"),QQONb7aR2M6L,a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᾛ"))
	return
def fJTqHgAdX2Rw():
	Bro7jZXa2qAFulQW9IkPL = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨᾜ")
	yQMg7VfFNB4l9UcpqiX = WWbmNvI40sM9Khlp25Ae(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪᾝ")
	p2sfgbe9xhl3JXnkLc = QQSULIva4ljNO73mFcWw(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᾞ")
	ztgqWUaDpe8CE9N(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࠫᾟ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫࠬᾠ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᾡ"),Bro7jZXa2qAFulQW9IkPL,yQMg7VfFNB4l9UcpqiX,p2sfgbe9xhl3JXnkLc)
	return
def cCb97ROZ2yWUSYx6GqoPn():
	yQMg7VfFNB4l9UcpqiX = LsG7EDcei1gMShH2aVOCo(u"࠭วๅๅสุࠥํ่ࠡ็ัึ๋ࠦๅลไอࠤ้๊ๅฺๆ๋้ฬะ๋ࠠีอาิ๋็ࠡษ็ฬึ์วๆฮ่ࠣำุๆࠡืไัฬะࠠศๆศ๊ฯืๆ๋ฬࠣ์ึ๎วษูࠣห้็๊ะ์๋๋ฬะࠠๅๆู๋ํ๊ࠠฦๆํ๋ฬࠦศิำ฼อࠥ๎ศะ๊้ࠤส์สา่ํฮࠥ๎วๅสิ๊ฬ๋ฬࠡ์่ืาํวࠡฬ็ๆฬฬ๊ศࠢห฽ิࠦว็ฬ๊หฦูࠦๆำ๊หࠥ๎รุ๋สࠤ฾์ฯࠡฬะำ๏ัࠠศๆหี๋อๅอࠢ࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤุฮูสࠢฦ๊ํอูࠡๆ฼้ึࠦวๅๅสุࠥࡀࠧᾢ")
	yQMg7VfFNB4l9UcpqiX += lh6URegmQNq8LWX0HaK5(u"ࠧ࡝ࡰ࡟ࡲࠬᾣ") + RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨ࠳࠱ࠤะอศหࠢ็ฺ่็อศฬࠣห้ะ๊ࠡ็฼ีํ็ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ืࠠ็้สส๏อ้ࠠ็าฮ์ࠦࠧᾤ") + str(bY2n5MtVA4cjpkFSxZ6K/eaF2N0jWLdvHIs8r(u"࠺࠵੡")/eaF2N0jWLdvHIs8r(u"࠺࠵੡")/Y5npATFarf1H9wBjc87(u"࠷࠺੢")/MOwK1lpyNfCgqksX3jhV(u"࠹࠰੣")) + OnvTrikzfEsY7qU8pgaRBtZy(u"ุࠩࠣ์ืࠧᾥ")
	yQMg7VfFNB4l9UcpqiX += eaF2N0jWLdvHIs8r(u"ࠪࡠࡳ࠭ᾦ") + gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫ࠷࠴ࠠอัสࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่๊็ัุ้ࠣว๋ํวࠡๆสࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪᾧ") + str(wwSaAipunqYIgcH/eaF2N0jWLdvHIs8r(u"࠶࠱੤")/eaF2N0jWLdvHIs8r(u"࠶࠱੤")/aSf0iWG1kA7FsqjHbuC8NXB(u"࠳࠶੥")) + MOwK1lpyNfCgqksX3jhV(u"๊้ࠬࠦ็ࠪᾨ")
	yQMg7VfFNB4l9UcpqiX += wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭࡜࡯ࠩᾩ") + FZBX5WcC3msIDv4hobLd8(u"ࠧ࠴࠰ࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๆศัิหࠥะส฻์ิࠤํ๋ฯห้ࠣࠫᾪ") + str(IIbavC96MQ1nHq3Pjx/lh6URegmQNq8LWX0HaK5(u"࠸࠳੦")/lh6URegmQNq8LWX0HaK5(u"࠸࠳੦")/S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠵࠸੧")) + QQSULIva4ljNO73mFcWw(u"ࠨࠢํ์๊࠭ᾫ")
	yQMg7VfFNB4l9UcpqiX += wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩ࡟ࡲࠬᾬ") + S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬᾭ") + str(jj0C6IlvPFh/nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠺࠵੨")/nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠺࠵੨")) + onweDvmTOUj(u"ูࠫࠥวฺหࠪᾮ")
	yQMg7VfFNB4l9UcpqiX += nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬࡢ࡮ࠨᾯ") + wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭࠵࠯ࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤิอฦๆษࠣ์๊ีส่ࠢࠪᾰ") + str(sJF0ga5tzvlRZWK3Xb9/WWbmNvI40sM9Khlp25Ae(u"࠻࠶੩")/WWbmNvI40sM9Khlp25Ae(u"࠻࠶੩")) + Sj1PYDmIpCUXO26(u"ࠧࠡีส฽ฮ࠭ᾱ")
	yQMg7VfFNB4l9UcpqiX += MOwK1lpyNfCgqksX3jhV(u"ࠨ࡞ࡱࠫᾲ") + mtEXp14ijx(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪᾳ") + str(AlcR9Gvo3QZsLnpfjS/aSf0iWG1kA7FsqjHbuC8NXB(u"࠼࠰੪")) + aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࠤิ่๊ใหࠪᾴ")
	yQMg7VfFNB4l9UcpqiX += a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡡࡴࠧ᾵") + onweDvmTOUj(u"ࠬ࠽࠮ࠡสา์๋ࠦใศึ่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡสึี฾ฯ้ࠠ็าฮ์ࠦࠧᾶ") + str(fyIAplJLe9MGiPosBvrEOtZUm6) + MOwK1lpyNfCgqksX3jhV(u"࠭ࠠะไํๆฮ࠭ᾷ")
	yQMg7VfFNB4l9UcpqiX += nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧ࡝ࡰ࡟ࡲࠬᾸ") + KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨ็ฮ่ฬࡀࠠึใะหฯࠦโ้ษษ้ࠥอไฤใ็ห๊่ࠦศๆ่ืู้ไศฬࠣ์ฬ๊อๅไสฮࠥ฿ๅา้สࠤࠬᾹ") + str(jj0C6IlvPFh/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")) + d0HDrq8Rtk16AlInw4TXb(u"ࠩࠣืฬ฿ษࠡ࠰ࠣว๊อࠠใ๊สส๊ࠦร็๊ส฽ࠥอไโ์า๎ํํวหࠢไ฽๊ื็ศࠢࠪᾺ") + str(IIbavC96MQ1nHq3Pjx/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")/S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠳࠶੬")) + IPkQW7LojF3HO18V(u"ࠪࠤศ๐วๆࠢ࠱ࠤศ๋วࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡใ฼้ึํวࠡࠩΆ") + str(sJF0ga5tzvlRZWK3Xb9/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")) + eaF2N0jWLdvHIs8r(u"ูࠫࠥวฺหࠣๅ็฽ࠠ࠯ࠢฦ้ฬࠦแฮืࠣี็๋ࠠศๆศูิอัࠡใ฼้ึํࠠࠨᾼ") + str(AlcR9Gvo3QZsLnpfjS/gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠶࠱੫")) + gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬࠦฯใ์ๅอࠥ࠴ࠠฤ็สࠤๆำีࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠโ฻่ี์ࠦࠧ᾽") + str(fyIAplJLe9MGiPosBvrEOtZUm6) + wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࠠะไํๆฮ࠭ι")
	DPfOyNk6YarWmFKU2ezZlAiG(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭᾿"),LsG7EDcei1gMShH2aVOCo(u"ࠨ็สࠤ์๎ࠠศๆๆหูࠦวๅ็ึฮำีๅࠡใํࠤฬ๊ศา่ส้ั࠭῀"),yQMg7VfFNB4l9UcpqiX,q6yUEoKVDb0fXmc8vhrMk7N(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ῁"))
	return
def qxmuSN0OsAQH7VPeGzLUoC9():
	QQONb7aR2M6L = gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪห้็วึๆฬࠤฯ฿ๆ๋่ࠢะ้ีࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠣ์ฬ๊ๆใูฬࠤฯ฿ๆ๋ࠢฦ๊ࠥอไศี่ࠤฬ๊รึๆํࠤฯ๋ࠠห฻า๎้ํ้ࠠใสู้ฯ้่ࠠๅ฻ฮࠦสฺ่์ࠤ๊าไะ๋ࠢฮ๊ࠦสฺัํ่ࠥอำๆ้ࠣ์อี่็ࠢ฼่ฬ๋ษࠡฬ฼๊๏ࠦๅๅใࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏࠭ῂ")
	ztgqWUaDpe8CE9N(IPkQW7LojF3HO18V(u"ࠫࠬῃ"),LsG7EDcei1gMShH2aVOCo(u"ࠬ࠭ῄ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ῅"),QQONb7aR2M6L)
	return
def NicWUdQDxMuTSZB0aOLzVg():
	QQONb7aR2M6L = LsG7EDcei1gMShH2aVOCo(u"ࠧฦาสࠤํอฬ่ฬๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅึห็ฮ่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥษ่ࠡษ้็ࠥะุ็ࠢฦ๊ࠥอไๆ๊ๅ฽ࠥอไฤื็๎้ࠥว็ࠢไ๎์ࠦๅีๅ็อ๋ࠥฤใฬ๊ࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣๅสึๆࠡฮิฬ๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮืๅสࠣห้฻แฮหࠣห้฻อ๋ฯฬࠤํะฮำ์้๋ฬࠦศะๆสࠤ๊์ࠠศๆุๅาฯࠠศๆๅำ๏๋ษࠨῆ")
	ztgqWUaDpe8CE9N(FZBX5WcC3msIDv4hobLd8(u"ࠨࠩῇ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࠪῈ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Έ"),QQONb7aR2M6L)
	return
def pR9CAzSjUD6v():
	QQONb7aR2M6L = d0HDrq8Rtk16AlInw4TXb(u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨῊ")
	ztgqWUaDpe8CE9N(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࠭Ή"),eaF2N0jWLdvHIs8r(u"࠭ࠧῌ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ῍"),QQONb7aR2M6L)
	return
def kjDg1VlqL4J9():
	ztgqWUaDpe8CE9N(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨࠩ῎"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠩࠪ῏"),d0HDrq8Rtk16AlInw4TXb(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῐ"),IPkQW7LojF3HO18V(u"้้๊ࠫࠡ์฼้้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไโ์า๎ํํวหࠢ࡟ࡲࠥ๐ฬษࠢอๅ฾๐ไࠡวูหๆฯࠠศี่๋ฬࠦ࡜࡯ࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩῑ"))
	cPzAIOrxUw5XlveWpHSEhR(QQSULIva4ljNO73mFcWw(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬῒ"),lh6URegmQNq8LWX0HaK5(u"ࡘࡷࡻࡥવ"))
	return
def hIR8ote4Dw():
	QQONb7aR2M6L  = onweDvmTOUj(u"࠭ๅละิห่ࠥวๆฬࠣฬ฾฼ࠠีำๆหฯࠦวๅว้ฮึ์สࠡษ็ำํ๊๊ࠡสฺ๋฾ูࠦศศๅࠤ฻ีࠠศๆหีฬ๋ฬࠡ็ฮ่้่ࠥะ์่ࠣฯูๅฮࠢไๆ฼ࠦไษ฻ูࠤู๊สฯั่๎ࠥอไๆฬุๅาࠦศศๆาาํ๊ࠠๅ็๋ห็฿ࠠศๆไ๎ิ๐่ࠨΐ")
	QQONb7aR2M6L += Jbu2G0Qax8PYWpg(u"๊้ࠧࠡฮ๏าษࠡๆ๊ิฬࠦวๅ฻สส็ࠦแศ่๊ࠤฯ่ั๋สสࠤัฺ๋๊่ࠢืฯิฯๆ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡๆสࠤ๏ูสุ์฼์๋ࠦวๅัั์้ࠦไอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ัࠦอห๋้ࠣ฾ࠦวิฬัำฬ๋ࠧ῔")
	QQONb7aR2M6L += gy9NA3CROZolfEt4vVzMr(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢๆࠠࠡࡘࡓࡒࠥࠦร้ࠢࠣࡔࡷࡵࡸࡺࠢࠣวํࠦࠠࡅࡐࡖࠤࠥษ่ࠡลํࠤา๊ࠠษีํ฻ࠥศฮา࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࠬ῕")
	QQONb7aR2M6L += MOwK1lpyNfCgqksX3jhV(u"ࠩ࡟ࡲ้อๆ้ࠡำห๊ࠥๆࠡ์ะ่ࠥอไๆึๆ่ฮ่ࠦฦ่่หࠥ็โุࠢึ๎็๎ๅࠡสศู้ออࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฦ฻สๆฮࠦๅ้ษๅ฽ࠥอฮา๋ࠣ็ฬ์สࠡฬ฼้้ࠦำศสๅหࠥฮฯู้่้ࠣอใๅࠩῖ")
	DPfOyNk6YarWmFKU2ezZlAiG(onweDvmTOUj(u"ࠪࡶ࡮࡭ࡨࡵࠩῗ"),MOwK1lpyNfCgqksX3jhV(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧῘ"),QQONb7aR2M6L,Q2ZyGqCNYsftTc4MR7n(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨῙ"))
	QQONb7aR2M6L = RS7ZoyGAq1c(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩῚ")
	QQONb7aR2M6L += OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧ࡝ࡰࠪΊ")+onweDvmTOUj(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡰࡵࡡ࡮ࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠢࠣࡱࡴࡼࡩࡻ࡮ࡤࡲࡩࠦࠠࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭ࠦࠠࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ῜")
	QQONb7aR2M6L += IPkQW7LojF3HO18V(u"ࠩ࡟ࡲࡡࡴࠧ῝")+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪห้ี่ๅࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ῞")
	QQONb7aR2M6L += onweDvmTOUj(u"ࠫࡡࡴࠧ῟")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆืิࠤࠥอไไ๊ํฮࠥࠦรๆ์ิ็ฬࠦࠠไ่าหࠥࠦแา่ึหࠥࠦวๅ์๋๊ฬ์ࠠࠡสิ๎฼อๆ๋ษࠣห้หๅศำสฮࠥษไๆษ้๎ฬࠦั้ีํหࠥอไ๋ษหห๋ࠦวๅี฼์ิ๐ษࠡำ๋้ฬ์๊ศ๊ࠢ์้์ฯศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪῠ")
	QQONb7aR2M6L += LsG7EDcei1gMShH2aVOCo(u"࠭࡜࡯࡞ࡱࠫῡ")+hxSBTdGpyNVbfu4tr9(u"ࠧศๆ่ฬึ๋ฬ๊ࠡฯำࠥ฽ั๋ไฬࠤ้ะฬศ๊ีࠤฬู๊ศศๅࠤํ๊ใ็้สࠤฯำสศฮࠣะ์ีࠠไสํีࠥ๎วๅ็หี๊าฺ๋้ࠠࠤฬ๊ๅีๅ็อࠥ฻ฺ๋ำฬࠤํ๊วࠡฬึฮา่ࠠศๆอ฽อࠦแฦาสࠤ้ี๊ไุ่่๊ࠢษࠡสส่ิิ่ๅࠢ็ฬ฾฼ࠠศๆ่์ฬู่๊ࠡฦ๎฻อࠠๅๅํࠤ๏ะึฮࠢะะ๊ࠦวๅ็ื็้ฯࠠࠨῢ")
	QQONb7aR2M6L += OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠหึูไࠡำึห้ฯࠠๆฦาฬฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอใหสࠣๅ๏ํวࠡษึ้ࠥฮไะๅࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะำหูํ฽ࠥีฮ้ๆ๊หࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ΰ")
	DPfOyNk6YarWmFKU2ezZlAiG(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡵ࡭࡬࡮ࡴࠨῤ"),WWbmNvI40sM9Khlp25Ae(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῥ"),QQONb7aR2M6L,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧῦ"))
	return
def WSfBRwlG8U4x():
	ztgqWUaDpe8CE9N(Q2ZyGqCNYsftTc4MR7n(u"ࠬ࠭ῧ"),lh6URegmQNq8LWX0HaK5(u"࠭ࠧῨ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧῩ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢัำ๊อส้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲศ๎ࠠษษิืฬ๊ࠠศ์่๎้ࠦวๅ๋ࠣวิ์ว่ࠢࠣࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࡄ࡬ࡳࡡࡪ࡮࠱ࡧࡴࡳ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨῪ"))
	return
def o2Prut1ZLTwDA():
	cCb97ROZ2yWUSYx6GqoPn()
	svOyXbipkwY = nEYJ5OCXG0gcNy(Y5npATFarf1H9wBjc87(u"ࠩࡦࡩࡳࡺࡥࡳࠩΎ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࠫῬ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠬ῭"),mtEXp14ijx(u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡษ็็ฬฺࠠภࠩ΅"),NQ4hg16DPUxtOyo5iGb(u"࠭วๅๅสุࠥ๐ำา฻ࠣ฽๊๊ࠠศๆหี๋อๅอุ๋้ࠢำ็ࠡ์฼๎ิࠦำฮสࠣห้฻แฮษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢ฼๊ิࠦวๅฯสะฮࠦลๅ์๊หࠥ๎วๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ๎วๅ็ึั๊ࠥวࠡ์ูีࠥ๎ๅๆๅ้ࠤ๏ำไࠡส฼ฺࠥอไๆึส็้࠭`"))
	if svOyXbipkwY==B2vCEI9FAVP15R8eUbDJdySc(u"࠳੭"):
		wh7i1HEySabUpQJ6frj3lVX(mtEXp14ijx(u"࡙ࡸࡵࡦશ"))
		ztgqWUaDpe8CE9N(WWbmNvI40sM9Khlp25Ae(u"ࠧࠨ῰"),IPkQW7LojF3HO18V(u"ࠨࠩ῱"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡสส่่อๅๅࠩῲ"),lh6URegmQNq8LWX0HaK5(u"ࠪษีอࠠไษ้ฮࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥออะࠢส่๊๎วใ฻ࠣๅัืศࠡษ็้ํู่ࠡษ็ฦ๋ࠦ࠮࠯࠰ࠣ์ศึวࠡษ็ู้้ไส่ࠢืฯ๋ัสࠢไษี์ࠠศำึ่ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫῳ"))
	return svOyXbipkwY
def hceUB9uxLZ(showDialogs=d0HDrq8Rtk16AlInw4TXb(u"࡚ࡲࡶࡧષ")):
	if not showDialogs: showDialogs = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࡔࡳࡷࡨસ")
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠫࡌࡋࡔࠨῴ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫ῵"),Jbu2G0Qax8PYWpg(u"࠭ࠧῶ"),Jbu2G0Qax8PYWpg(u"ࠧࠨῷ"),FZBX5WcC3msIDv4hobLd8(u"ࡇࡣ࡯ࡷࡪહ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠨࠩῸ"),lh6URegmQNq8LWX0HaK5(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬΌ"))
	if not ttpgqJBdkoxeKOcwaiP.succeeded:
		veAcT2PbuanJhw9E8Sr = mtEXp14ijx(u"ࡈࡤࡰࡸ࡫઺")
		UMlKSYDNfaR0Z1sbFvPwp = JA5CtfUvW3ljmExIYFog()
		xrFqGMab4uLKZcS(Y5npATFarf1H9wBjc87(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨῺ"),zybGoPc6tOmwRTWSE2(HmvY29bj4dNgF7wZqr1lzkeQxiEasu)+NQ4hg16DPUxtOyo5iGb(u"ࠫࠥࠦࠠࡉࡖࡗࡔࡘࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡎࡤࡦࡪࡲ࠺࡜ࠩΏ")+UMlKSYDNfaR0Z1sbFvPwp+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠬࡣࠧῼ"))
		if showDialogs: ztgqWUaDpe8CE9N(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠧ´"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨ῾"),QQSULIva4ljNO73mFcWw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ῿"),lh6URegmQNq8LWX0HaK5(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨࠀ"))
	else:
		veAcT2PbuanJhw9E8Sr = QQSULIva4ljNO73mFcWw(u"ࡗࡶࡺ࡫઻")
		if showDialogs: ztgqWUaDpe8CE9N(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬ࠭ࠁ"),Jbu2G0Qax8PYWpg(u"࠭ࠧࠂ"),LsG7EDcei1gMShH2aVOCo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠃ"),onweDvmTOUj(u"ࠨฮํำࠥาฯศࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡ์฼ู้้ࠦ็ัๆࠤํอไษำ้ห๊าࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬࠄ"))
	if not veAcT2PbuanJhw9E8Sr and showDialogs: DxQspVP56kH3N()
	return veAcT2PbuanJhw9E8Sr
def DxQspVP56kH3N():
	ztgqWUaDpe8CE9N(onweDvmTOUj(u"ࠩࠪࠅ"),Sj1PYDmIpCUXO26(u"ࠪࠫࠆ"),lh6URegmQNq8LWX0HaK5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠇ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫࠈ"))
	ukZGxgIpD8mTYK2AfQe()
	return
def bbP5YM4p3QCHhi6(yy42JUqszVIO89i=QQSULIva4ljNO73mFcWw(u"࠭ࠧࠉ")):
	fjrgCSVBFcNdAaoWMOv = d0HDrq8Rtk16AlInw4TXb(u"ࡘࡷࡻࡥ઼")
	if QQSULIva4ljNO73mFcWw(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪࠊ") not in yy42JUqszVIO89i:
		fjrgCSVBFcNdAaoWMOv = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡋࡧ࡬ࡴࡧઽ")
		U94D8BejHMsrLzO27IRpFEhC6wP = bxBWM9d53zOAcar(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨࠋ"),gy9NA3CROZolfEt4vVzMr(u"ࠩัีําࠧࠌ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪษึูวๅุ่่๊ࠢษࠨࠍ"),gy9NA3CROZolfEt4vVzMr(u"ࠫสืำศๆࠣีุอไสࠩࠎ"),gy9NA3CROZolfEt4vVzMr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࠏ"),FZBX5WcC3msIDv4hobLd8(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩࠐ"))
		if U94D8BejHMsrLzO27IRpFEhC6wP in [-WWbmNvI40sM9Khlp25Ae(u"࠴੮"),MOwK1lpyNfCgqksX3jhV(u"࠴੯")]: return
		elif U94D8BejHMsrLzO27IRpFEhC6wP==RS7ZoyGAq1c(u"࠶ੰ"):
			fjrgCSVBFcNdAaoWMOv = Q2ZyGqCNYsftTc4MR7n(u"࡚ࡲࡶࡧા")
			yy42JUqszVIO89i = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪࠑ")
	if fjrgCSVBFcNdAaoWMOv:
		if FZBX5WcC3msIDv4hobLd8(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨࠒ") not in yy42JUqszVIO89i:
			svOyXbipkwY = nEYJ5OCXG0gcNy(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࡦࡩࡳࡺࡥࡳࠩࠓ"),lh6URegmQNq8LWX0HaK5(u"ࠪࠫࠔ"),eaF2N0jWLdvHIs8r(u"ࠫࠬࠕ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬࠖ"),eaF2N0jWLdvHIs8r(u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭ࠗ"))
			if svOyXbipkwY!=mtEXp14ijx(u"࠷ੱ"):
				ztgqWUaDpe8CE9N(FZBX5WcC3msIDv4hobLd8(u"ࠧࠨ࠘"),NQ4hg16DPUxtOyo5iGb(u"ࠨࠩ࠙"),hxSBTdGpyNVbfu4tr9(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬࠚ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠛ"))
				return
	ztgqWUaDpe8CE9N(QQSULIva4ljNO73mFcWw(u"ࠫࠬࠜ"),Jbu2G0Qax8PYWpg(u"ࠬ࠭ࠝ"),hxSBTdGpyNVbfu4tr9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠞ"),RS7ZoyGAq1c(u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไฦ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫࠟ"))
	search = ymH9jzg2KId5MCvw8lXBZn(header=nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࡨࠤࠥࠦวไฬหࠤึูวๅหࠪࠠ"),source=HmvY29bj4dNgF7wZqr1lzkeQxiEasu)
	if not search: return
	QQONb7aR2M6L = search
	if fjrgCSVBFcNdAaoWMOv: type = eaF2N0jWLdvHIs8r(u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪࠡ")
	else: type = Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫࠢ")
	sycSign827ZrEldIB = sOki9wK4yjEg3oHa(type,QQONb7aR2M6L,LsG7EDcei1gMShH2aVOCo(u"ࡔࡳࡷࡨિ"),eaF2N0jWLdvHIs8r(u"ࠫࠬࠣ"),gy9NA3CROZolfEt4vVzMr(u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡘࡗࡊࡘࡓࠨࠤ"),yy42JUqszVIO89i)
	return
def DjqriRSkMZl():
	yy42JUqszVIO89i = Y5npATFarf1H9wBjc87(u"࠭็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์๋ะิࠦไ่ࠢฦ๎ู๊ࠥาใิࠤ๏ูสื์ไࠤศ๐ࠠๆฯอ์๏อส࠯ࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤึ๎วษูࠣ์ฯ฼ๅ๋่่๊ࠣำส้์สฮ๋ࠥัโ๊฼อࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣาฬืฬ๋ห࠱ࠤฬ๊ศา่ส้ัฺ๋ࠦำุ้ࠣส่ๅࠢ฼๊ࠥษ๊ࠡ็ะฮํ๐วหࠢอ้ࠥะอๆ์็๋ฬูࠦๅ๋ࠣื๏ืแาษอࠤํ๋่ศไ฼ࠤำอัอ์ฬࠤ๋่ࠧศไ฼ࠤ฼ืแࠡอส่ะࠨ࠮ࠡฮ่๎฾ࠦวๅลึ้ฬว้ࠠษ็้ฬืใศฬࠣ์ฬ๊ี้ำࠣ์ฬ๊ๅ็ึ๋ีฬะ่ࠠ์ࠣาฬ฻ษࠡสสูาอศ่ษ࠱ࠤฬ๊ศา่ส้ัࠦไศࠢํ๊ฯํใࠡฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠡࡆࡐࡇࡆࠦลัษࠣ็ฬ์ࠠๅัํ็ฺࠥใ้๋ࠣาฬ฻ษࠡสส่ึ๎วษูࠣ์ฬ๊สืษ่๎๋ࠦวๅะสีั๐ษࠡใส่ึาวยࠢส่ฯ๎วึๆ้ࠣ฾ࠦละษิอࠥํะ่ࠢสุ่๐ัโำสฮࠥ๎วๅ็๋ห็฿ࠠศๆัหึา๊ส࠰๋ࠣีอࠠศๆหี๋อๅอ๊ࠢ์ࠥฮศิษฺอ๋ࠥสึใะࠤ้๋่ศไ฼ࠤฬ๊่๋สࠪࠥ")
	DPfOyNk6YarWmFKU2ezZlAiG(MOwK1lpyNfCgqksX3jhV(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ࠦ"),FZBX5WcC3msIDv4hobLd8(u"ࠨฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠨࠧ"),yy42JUqszVIO89i,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬࠨ"))
	yy42JUqszVIO89i = onweDvmTOUj(u"ࠪࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤ࡭ࡵࡳࡵࠢࡤࡲࡾࠦࡣࡰࡰࡷࡩࡳࡺࠠࡰࡰࠣࡥࡳࡿࠠࡴࡧࡵࡺࡪࡸ࠮ࠡࡋࡷࠤࡴࡴ࡬ࡺࠢࡸࡷࡪࡹࠠ࡭࡫ࡱ࡯ࡸࠦࡴࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡺࡨࡢࡶࠣࡻࡦࡹࠠࡶࡲ࡯ࡳࡦࡪࡥࡥࠢࡷࡳࠥࡶ࡯ࡱࡷ࡯ࡥࡷࠦ࡯࡯࡮࡬ࡲࡪࠦࡶࡪࡦࡨࡳࠥ࡮࡯ࡴࡶ࡬ࡲ࡬ࠦࡳࡪࡶࡨࡷ࠳ࠦࡁ࡭࡮ࠣࡸࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠬࠡࡸ࡬ࡨࡪࡵࡳ࠭ࠢࡷࡶࡦࡪࡥࠡࡰࡤࡱࡪࡹࠬࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡰࡥࡷࡱࡳ࠭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࡪࡪࠠࡸࡱࡵ࡯࠱ࠦ࡬ࡰࡩࡲࡷࠥࡸࡥࡧࡧࡵࡩࡳࡩࡥࡥࠢ࡫ࡩࡷ࡫ࡩ࡯ࠢࡥࡩࡱࡵ࡮ࡨࠢࡷࡳࠥࡺࡨࡦ࡫ࡵࠤࡷ࡫ࡳࡱࡧࡦࡸ࡮ࡼࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣࡧࡴࡳࡰࡢࡰ࡬ࡩࡸ࠴ࠠࡕࡪࡨࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡸ࡯ࡢ࡭ࡧࠣࡪࡴࡸࠠࡸࡪࡤࡸࠥࡵࡴࡩࡧࡵࠤࡵ࡫࡯ࡱ࡮ࡨࠤࡺࡶ࡬ࡰࡣࡧࠤࡹࡵࠠ࠴ࡴࡧࠤࡵࡧࡲࡵࡻࠣࡷ࡮ࡺࡥࡴ࠰࡛ࠣࡪࠦࡵࡳࡩࡨࠤࡦࡲ࡬ࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࠤࡴࡽ࡮ࡦࡴࡶ࠰ࠥࡺ࡯ࠡࡴࡨࡧࡴ࡭࡮ࡪࡼࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮ࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡤࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡢࡴࡨࠤࡱࡵࡣࡢࡶࡨࡨࠥࡹ࡯࡮ࡧࡺ࡬ࡪࡸࡥࠡࡧ࡯ࡷࡪࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡳࡷࠦࡶࡪࡦࡨࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡢࡴࡨࠤ࡫ࡸ࡯࡮ࠢࡲࡸ࡭࡫ࡲࠡࡸࡤࡶ࡮ࡵࡵࡴࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡢࡰࡼࠤࡱ࡫ࡧࡢ࡮ࠣ࡭ࡸࡹࡵࡦࡵࠣࡴࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡰࡩࡩ࡯ࡡࠡࡨ࡬ࡰࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡪࡲࡷࡹ࡫ࡲࡴ࠰ࠣࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡹࡩ࡮ࡲ࡯ࡽࠥࡧࠠࡸࡧࡥࠤࡧࡸ࡯ࡸࡵࡨࡶ࠳࠭ࠩ")
	DPfOyNk6YarWmFKU2ezZlAiG(aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡱ࡫ࡦࡵࠩࠪ"),LsG7EDcei1gMShH2aVOCo(u"ࠬࡊࡩࡨ࡫ࡷࡥࡱࠦࡍࡪ࡮࡯ࡩࡳࡴࡩࡶ࡯ࠣࡇࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦࡁࡤࡶࠣࠬࡉࡓࡃࡂࠫࠪࠫ"),yy42JUqszVIO89i,Sj1PYDmIpCUXO26(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩࠬ"))
	return
def F8VGbcrHE0twmvq6o(giwrh4jLPc):
	PcwChNBYmt4ruvsIEo = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ࠭")+giwrh4jLPc+NQ4hg16DPUxtOyo5iGb(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧ࠮"))
	sF0NOtG4b1RY = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࡕࡴࡸࡩી")
	if sF0NOtG4b1RY:
		p1BoraOuWL.sleep(WWbmNvI40sM9Khlp25Ae(u"࠱ੲ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(LsG7EDcei1gMShH2aVOCo(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭࠯"))
		p1BoraOuWL.sleep(Sj1PYDmIpCUXO26(u"࠲ੳ"))
	return
def lBGHzr6qwcsA3TOD():
	ztgqWUaDpe8CE9N(B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࠫ࠰"),Q2ZyGqCNYsftTc4MR7n(u"ࠫࠬ࠱"),gy9NA3CROZolfEt4vVzMr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠲"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫ࠳"))
	pR9CAzSjUD6v()
	return
def ukZGxgIpD8mTYK2AfQe():
	url = lh6URegmQNq8LWX0HaK5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬ࠴")
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,Sj1PYDmIpCUXO26(u"ࠨࡉࡈࡘࠬ࠵"),url,Jbu2G0Qax8PYWpg(u"ࠩࠪ࠶"),lh6URegmQNq8LWX0HaK5(u"ࠪࠫ࠷"),WWbmNvI40sM9Khlp25Ae(u"ࠫࠬ࠸"),Sj1PYDmIpCUXO26(u"ࠬ࠭࠹"),mtEXp14ijx(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩ࠺"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BBP0FOm87u = SomeI8i56FaDMGPE.findall(onweDvmTOUj(u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭࠻"),BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	BBP0FOm87u = BBP0FOm87u[RS7ZoyGAq1c(u"࠲ੴ")].split(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨ࠯ࠪ࠼"))[RS7ZoyGAq1c(u"࠲ੴ")]
	o6XxB0KrI9zt = str(Qf8xsJSwoKaUNc)
	KXHul4UAnW = d0HDrq8Rtk16AlInw4TXb(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ࠽")+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭࠾")+BBP0FOm87u+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠿")
	KXHul4UAnW += LsG7EDcei1gMShH2aVOCo(u"ࠬࡢ࡮࡝ࡰࠪࡀ")+Y5npATFarf1H9wBjc87(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬࡁ")+IPkQW7LojF3HO18V(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࡂ")+o6XxB0KrI9zt+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡃ")
	ztgqWUaDpe8CE9N(Sj1PYDmIpCUXO26(u"ࠩࠪࡄ"),LsG7EDcei1gMShH2aVOCo(u"ࠪࠫࡅ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡆ"),KXHul4UAnW)
	return
def oCZIvhMW6wmp9tQPTfSaX7c8E2qD():
	Bro7jZXa2qAFulQW9IkPL,yQMg7VfFNB4l9UcpqiX,p2sfgbe9xhl3JXnkLc,KXHul4UAnW,PbJxY6tDHcQuEN9z0h,vwOG7juVpr8NWQsh9P6n4y,fwxhdUYALtR2JQ8McqiOm7ogIl = NQ4hg16DPUxtOyo5iGb(u"ࠬ࠭ࡇ"),gy9NA3CROZolfEt4vVzMr(u"࠭ࠧࡈ"),RS7ZoyGAq1c(u"ࠧࠨࡉ"),d0HDrq8Rtk16AlInw4TXb(u"ࠨࠩࡊ"),mtEXp14ijx(u"ࠩࠪࡋ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࠫࡌ"),mtEXp14ijx(u"ࠫࠬࡍ")
	P8AGL4xSd9rWD1Vz,XX3MdAeTahqVJtr6uKD2ZOx,l7BWnw1MTEA,PI3rLTqeAyUKoVuJv0 = {wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࡧࠧࡎ"):mtEXp14ijx(u"࠭ࡡࠨࡏ")},{},[],{}
	url = ZEgwHfRnFV4[wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧࡐ")][OnvTrikzfEsY7qU8pgaRBtZy(u"࠴ੵ")]
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(AlcR9Gvo3QZsLnpfjS,eaF2N0jWLdvHIs8r(u"ࠨࡒࡒࡗ࡙࠭ࡑ"),url,P8AGL4xSd9rWD1Vz,wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩࠪࡒ"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠪࠫࡓ"),d0HDrq8Rtk16AlInw4TXb(u"ࠫࠬࡔ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪࡕ"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(wKdxVbTc0X9NSiespM8OvHGUhf(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡓࡵࡣࡷࡩࡸ࠭ࡖ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࡖࡕࡄࠫࡗ"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡍ࡬ࡲ࡬ࡪ࡯࡮ࠩࡘ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࡘࡏ࡙ࠬ"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(d0HDrq8Rtk16AlInw4TXb(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡅࡷࡧࡢࠡࡇࡰ࡭ࡷࡧࡴࡦࡵ࡚ࠪ"),gy9NA3CROZolfEt4vVzMr(u"࡚ࠫࡇࡅࠨ࡛"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(LsG7EDcei1gMShH2aVOCo(u"࡙ࠬࡡࡶࡦ࡬ࠤࡆࡸࡡࡣ࡫ࡤࠫ࡜"),hxSBTdGpyNVbfu4tr9(u"࠭ࡋࡔࡃࠪ࡝"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(RS7ZoyGAq1c(u"ࠧࡏࡱࡵࡸ࡭ࠦࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ࡞"),d0HDrq8Rtk16AlInw4TXb(u"ࠨࡐ࠱ࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭࡟"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(hxSBTdGpyNVbfu4tr9(u"࡚ࠩࡩࡸࡺࡥࡳࡰࠣࡗࡦ࡮ࡡࡳࡣࠪࡠ"),MOwK1lpyNfCgqksX3jhV(u"࡛ࠪ࠳࡙ࡡࡩࡣࡵࡥࠬࡡ"))
	BsJ71WIxDtdFKveTcRPrqM4Cwb = BsJ71WIxDtdFKveTcRPrqM4Cwb.replace(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡤࡥ࡟ࠨࡢ"),onweDvmTOUj(u"ࠬࠦࠠࠨࡣ"))
	try: VkAuafXy68s = sX8pkIh2J4MCZHtcr0ERmlqWDL16O(Y5npATFarf1H9wBjc87(u"࠭࡬ࡪࡵࡷࠫࡤ"),BsJ71WIxDtdFKveTcRPrqM4Cwb)
	except:
		ztgqWUaDpe8CE9N(lh6URegmQNq8LWX0HaK5(u"ࠧࠨࡥ"),NQ4hg16DPUxtOyo5iGb(u"ࠨࠩࡦ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡧ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪࡨ"))
		return
	iiqV9LM6CJPyv,XV1HDKcyCdgbEuonTP,cNqbpVBtZLWH24RQuvn = VkAuafXy68s
	PI3rLTqeAyUKoVuJv0 = {}
	PGvLlV9KDo84SabfOXrQtY76nEFj = [RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧࡩ"),Y5npATFarf1H9wBjc87(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫࡪ")]
	sO98tzLpNEC1v = [gy9NA3CROZolfEt4vVzMr(u"࠭ࡁࡍࡎࠪ࡫"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࡬"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ࡭"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭࡮"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠪࡖࡊࡖࡏࡔࠩ࡯")]+PGvLlV9KDo84SabfOXrQtY76nEFj+aiwHkjxJEgl0WDeonX1U6fzbuLCp2M+b9GYdZJsgNV6oF7
	for yPRGDCnXhJbwYalz7fZepiUcA,C98IXo5lYWEBzmKRi0vnjJhcd,GzmbR8XgTkILSUe in XV1HDKcyCdgbEuonTP:
		GzmbR8XgTkILSUe = c8Fvb4IfHW9XkG1mLK5Z(GzmbR8XgTkILSUe)
		GzmbR8XgTkILSUe = GzmbR8XgTkILSUe.strip(NQ4hg16DPUxtOyo5iGb(u"ࠫࠥ࠭ࡰ")).strip(Q2ZyGqCNYsftTc4MR7n(u"ࠬࠦ࠮ࠨࡱ"))
		KXHul4UAnW += a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫࡲ")+yPRGDCnXhJbwYalz7fZepiUcA+Q2ZyGqCNYsftTc4MR7n(u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡳ")+GzmbR8XgTkILSUe+aSf0iWG1kA7FsqjHbuC8NXB(u"ࠨ࡞ࡱࠫࡴ")
		if C98IXo5lYWEBzmKRi0vnjJhcd.isdigit():
			PI3rLTqeAyUKoVuJv0[yPRGDCnXhJbwYalz7fZepiUcA] = int(C98IXo5lYWEBzmKRi0vnjJhcd)
			if int(C98IXo5lYWEBzmKRi0vnjJhcd)>MOwK1lpyNfCgqksX3jhV(u"࠵࠵࠶੶"): C98IXo5lYWEBzmKRi0vnjJhcd = d0HDrq8Rtk16AlInw4TXb(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬࡵ")
			else: C98IXo5lYWEBzmKRi0vnjJhcd = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬࡶ")
		if yPRGDCnXhJbwYalz7fZepiUcA not in sO98tzLpNEC1v:
			if   C98IXo5lYWEBzmKRi0vnjJhcd==IPkQW7LojF3HO18V(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧࡷ"): Bro7jZXa2qAFulQW9IkPL += S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠬࠦࠠࠨࡸ")+yPRGDCnXhJbwYalz7fZepiUcA
			elif C98IXo5lYWEBzmKRi0vnjJhcd==d0HDrq8Rtk16AlInw4TXb(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨࡹ"): yQMg7VfFNB4l9UcpqiX += NQ4hg16DPUxtOyo5iGb(u"ࠧࠡࠢࠪࡺ")+yPRGDCnXhJbwYalz7fZepiUcA
	lnLr7SCmPRGctM54aN,jwPtFROmqHvf,Qg9Yr0KRajh2fHzxI5Z7dW6v = list(zip(*XV1HDKcyCdgbEuonTP))
	for yPRGDCnXhJbwYalz7fZepiUcA in sorted(VqCjboemktrAKgz):
		if yPRGDCnXhJbwYalz7fZepiUcA not in lnLr7SCmPRGctM54aN:
			KXHul4UAnW += Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࡻ")+yPRGDCnXhJbwYalz7fZepiUcA+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡼ")+q6yUEoKVDb0fXmc8vhrMk7N(u"่ࠪฬ๊้ࠦฮาࠫࡽ")+Sj1PYDmIpCUXO26(u"ࠫࡡࡴ࡜࡯ࠩࡾ")
			if yPRGDCnXhJbwYalz7fZepiUcA not in sO98tzLpNEC1v: p2sfgbe9xhl3JXnkLc += gy9NA3CROZolfEt4vVzMr(u"ࠬࠦࠠࠨࡿ")+yPRGDCnXhJbwYalz7fZepiUcA
	for GzmbR8XgTkILSUe,ZKaC36j9WkcqXeML in iiqV9LM6CJPyv:
		GzmbR8XgTkILSUe = c8Fvb4IfHW9XkG1mLK5Z(GzmbR8XgTkILSUe)
		PbJxY6tDHcQuEN9z0h += GzmbR8XgTkILSUe+Rz34c0NP5BGo1WuTZxSfOKj(u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࢀ")+str(ZKaC36j9WkcqXeML)+IPkQW7LojF3HO18V(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬࢁ")
	Bro7jZXa2qAFulQW9IkPL = Bro7jZXa2qAFulQW9IkPL.strip(Q2ZyGqCNYsftTc4MR7n(u"ࠨࠢࠪࢂ"))
	yQMg7VfFNB4l9UcpqiX = yQMg7VfFNB4l9UcpqiX.strip(lh6URegmQNq8LWX0HaK5(u"ࠩࠣࠫࢃ"))
	p2sfgbe9xhl3JXnkLc = p2sfgbe9xhl3JXnkLc.strip(Y5npATFarf1H9wBjc87(u"ࠪࠤࠬࢄ"))
	w9w1i4Fq7sPxO5jSURAEg0CQLM = Bro7jZXa2qAFulQW9IkPL+Y5npATFarf1H9wBjc87(u"ࠫࠥࠦࠧࢅ")+yQMg7VfFNB4l9UcpqiX
	ftK0R1imCykY6nrH  = Q1QS6w8saLEuPW0O7XjlipekBTbq(u"๋่ࠬศไ฼ࠤ๋าอࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩࢆ")+aSf0iWG1kA7FsqjHbuC8NXB(u"࠭࡜࡯ࠩࢇ")+Sj1PYDmIpCUXO26(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠬ࢈")+Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡞ࡱࠫࢉ")
	ftK0R1imCykY6nrH += aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬࢊ")+w9w1i4Fq7sPxO5jSURAEg0CQLM+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩࢋ")
	ftK0R1imCykY6nrH += FZBX5WcC3msIDv4hobLd8(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪࢌ")+NQ4hg16DPUxtOyo5iGb(u"ࠬࡢ࡮ࠨࢍ")+FZBX5WcC3msIDv4hobLd8(u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪࢎ")+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧ࡝ࡰࠪ࢏")
	ftK0R1imCykY6nrH += Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ࢐")+p2sfgbe9xhl3JXnkLc+FZBX5WcC3msIDv4hobLd8(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢑")
	fb5EiW8FmudGPqphkwlv,SNDdx8UOT32ngLHVGqk,KKLWsZuclXvaYz8Vjrh7ASg,lTCOuNYGfZ6Vq5U0PmAhpdsxXatBS8 = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵੷"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵੷"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵੷"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"࠵੷")
	all = PI3rLTqeAyUKoVuJv0[onweDvmTOUj(u"ࠪࡅࡑࡒࠧ࢒")]
	if S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ࢓") in list(PI3rLTqeAyUKoVuJv0.keys()): fb5EiW8FmudGPqphkwlv = PI3rLTqeAyUKoVuJv0[eaF2N0jWLdvHIs8r(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ࢔")]
	if B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ࢕") in list(PI3rLTqeAyUKoVuJv0.keys()): SNDdx8UOT32ngLHVGqk = PI3rLTqeAyUKoVuJv0[RS7ZoyGAq1c(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ࢖")]
	if Sj1PYDmIpCUXO26(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬࢗ") in list(PI3rLTqeAyUKoVuJv0.keys()): KKLWsZuclXvaYz8Vjrh7ASg = PI3rLTqeAyUKoVuJv0[gy9NA3CROZolfEt4vVzMr(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭࢘")]
	if WWbmNvI40sM9Khlp25Ae(u"ࠪࡖࡊࡖࡏࡔ࢙ࠩ") in list(PI3rLTqeAyUKoVuJv0.keys()): lTCOuNYGfZ6Vq5U0PmAhpdsxXatBS8 = PI3rLTqeAyUKoVuJv0[S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡗࡋࡐࡐࡕ࢚ࠪ")]
	uuxVoHOIpA = all-fb5EiW8FmudGPqphkwlv-SNDdx8UOT32ngLHVGqk-KKLWsZuclXvaYz8Vjrh7ASg-lTCOuNYGfZ6Vq5U0PmAhpdsxXatBS8
	fYZzomwSjkedXVcEvLDqKHMt9rFnN,f16ms28oKtqTzxcJ0WSQXUyEiGAd = cNqbpVBtZLWH24RQuvn[WWbmNvI40sM9Khlp25Ae(u"࠶੸")]
	fYZzomwSjkedXVcEvLDqKHMt9rFnN,e4oHKtkEuZzqyw9R8Vn0 = cNqbpVBtZLWH24RQuvn[NQ4hg16DPUxtOyo5iGb(u"࠱੹")]
	m7KTDcXR5gQBtfLU1Fj4heWq0GnJ2 = f16ms28oKtqTzxcJ0WSQXUyEiGAd-e4oHKtkEuZzqyw9R8Vn0
	fwxhdUYALtR2JQ8McqiOm7ogIl += eaF2N0jWLdvHIs8r(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࢛")+str(e4oHKtkEuZzqyw9R8Vn0)+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࢜")+gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫ࢝")
	fwxhdUYALtR2JQ8McqiOm7ogIl += RS7ZoyGAq1c(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭࢞")+str(m7KTDcXR5gQBtfLU1Fj4heWq0GnJ2)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟")+Q2ZyGqCNYsftTc4MR7n(u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧࢠ")
	fwxhdUYALtR2JQ8McqiOm7ogIl += gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢡ")+str(f16ms28oKtqTzxcJ0WSQXUyEiGAd)+mtEXp14ijx(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢢ")+lh6URegmQNq8LWX0HaK5(u"࠭วๅ฻าำࠥอไไๆํࠤ้าๅ๋฻ࠣห้ษฬ่ิฬࠤ࠿ࠦࠧࢣ")
	fwxhdUYALtR2JQ8McqiOm7ogIl += RS7ZoyGAq1c(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢤ")+str(len(cNqbpVBtZLWH24RQuvn[Rz34c0NP5BGo1WuTZxSfOKj(u"࠳੺"):]))+LsG7EDcei1gMShH2aVOCo(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢥ")+B2vCEI9FAVP15R8eUbDJdySc(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧࢦ")
	for Jo8iROg3wQsBTMCjGz1hZAtpm,OjIPm0do31CZ in cNqbpVBtZLWH24RQuvn[RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠴੻"):]:
		Jo8iROg3wQsBTMCjGz1hZAtpm = c8Fvb4IfHW9XkG1mLK5Z(Jo8iROg3wQsBTMCjGz1hZAtpm)
		Jo8iROg3wQsBTMCjGz1hZAtpm = Jo8iROg3wQsBTMCjGz1hZAtpm.strip(Y5npATFarf1H9wBjc87(u"ࠪࠤࠬࢧ")).strip(gy9NA3CROZolfEt4vVzMr(u"ࠫࠥ࠴ࠧࢨ"))
		fwxhdUYALtR2JQ8McqiOm7ogIl += Jo8iROg3wQsBTMCjGz1hZAtpm+WWbmNvI40sM9Khlp25Ae(u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪࢩ")+str(OjIPm0do31CZ)+Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫࢪ")
	vwOG7juVpr8NWQsh9P6n4y += Q2ZyGqCNYsftTc4MR7n(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢫ")+str(uuxVoHOIpA)+Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢬ")+d0HDrq8Rtk16AlInw4TXb(u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧࢭ")
	vwOG7juVpr8NWQsh9P6n4y += FZBX5WcC3msIDv4hobLd8(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨࢮ")+str(fb5EiW8FmudGPqphkwlv)+eaF2N0jWLdvHIs8r(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢯ")+gy9NA3CROZolfEt4vVzMr(u"ࠬ฽ไษษอࠤุ๐ัโำࠣฬฬ๐ห้่ࠣ࠾ࠥ࠭ࢰ")
	vwOG7juVpr8NWQsh9P6n4y += lh6URegmQNq8LWX0HaK5(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫࢱ")+str(lTCOuNYGfZ6Vq5U0PmAhpdsxXatBS8)+eaF2N0jWLdvHIs8r(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢲ")+Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫࢳ")
	vwOG7juVpr8NWQsh9P6n4y += gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧࢴ")+str(SNDdx8UOT32ngLHVGqk)+mtEXp14ijx(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢵ")+onweDvmTOUj(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨࢶ")
	vwOG7juVpr8NWQsh9P6n4y += Y5npATFarf1H9wBjc87(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢷ")+str(KKLWsZuclXvaYz8Vjrh7ASg)+B2vCEI9FAVP15R8eUbDJdySc(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࢸ")+gy9NA3CROZolfEt4vVzMr(u"ࠧหอห๎ฯࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠾ࠥ࠭ࢹ")
	vwOG7juVpr8NWQsh9P6n4y += WWbmNvI40sM9Khlp25Ae(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࢺ")+str(len(iiqV9LM6CJPyv))+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢻ")+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪำํ๊ࠠี฼็ฮࠥ็๊ะ์๋๋ฬะࠠ࠻ࠢࠪࢼ")
	vwOG7juVpr8NWQsh9P6n4y += FZBX5WcC3msIDv4hobLd8(u"ࠫࡡࡴ࡜࡯ࠩࢽ")+PbJxY6tDHcQuEN9z0h
	DPfOyNk6YarWmFKU2ezZlAiG(d0HDrq8Rtk16AlInw4TXb(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬࢾ"),Y5npATFarf1H9wBjc87(u"ู࠭ะัࠣห้ษฬ่ิฬࠤฬ๊ส๋ࠢสืฯิฯๆฬ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ࢿ"),fwxhdUYALtR2JQ8McqiOm7ogIl,OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪࣀ"))
	DPfOyNk6YarWmFKU2ezZlAiG(RS7ZoyGAq1c(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨࣁ"),eaF2N0jWLdvHIs8r(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪࣂ"),vwOG7juVpr8NWQsh9P6n4y,Sj1PYDmIpCUXO26(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ࣃ"))
	DPfOyNk6YarWmFKU2ezZlAiG(MOwK1lpyNfCgqksX3jhV(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࣄ"),IPkQW7LojF3HO18V(u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨࣅ"),ftK0R1imCykY6nrH,gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩࣆ"))
	DPfOyNk6YarWmFKU2ezZlAiG(IPkQW7LojF3HO18V(u"ࠧ࡭ࡧࡩࡸࠬࣇ"),Y5npATFarf1H9wBjc87(u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠศีอาิ๋สࠡษ็ฬึ์วๆฮࠪࣈ"),KXHul4UAnW,aSf0iWG1kA7FsqjHbuC8NXB(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪࣉ"))
	return
def a4aGrHBMfp():
	QQONb7aR2M6L = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡลฯ์อฯࠠศๆหี๋อๅอࠩ࣊")
	DPfOyNk6YarWmFKU2ezZlAiG(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࣋"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣌"),QQONb7aR2M6L,KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ࣍"))
	return
def z9bBQFsXTWgGtlC8PoryMw1pfnAL0V():
	QQONb7aR2M6L = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅิฬ๋ำ฾ูࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬ࣎")+Q2ZyGqCNYsftTc4MR7n(u"ࠨ࡞ࡱ࣏ࠫ")+mtEXp14ijx(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࣐ࠬ")+ZEgwHfRnFV4[Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑ࣑ࠩ")][WWbmNvI40sM9Khlp25Ae(u"࠴੽")]+mtEXp14ijx(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ࣒")+ZEgwHfRnFV4[LsG7EDcei1gMShH2aVOCo(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓ࣓ࠫ")][RWnd79GQpKM1gV5xAO2amZkTrL8F(u"࠴੼")]+q6yUEoKVDb0fXmc8vhrMk7N(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࣔ")
	QQONb7aR2M6L += mtEXp14ijx(u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼ࠦระ่ส๋ࠥํ่ࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩࣕ")+ZEgwHfRnFV4[hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩࣖ")][Jbu2G0Qax8PYWpg(u"࠶੾")]+OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣗ")
	QQONb7aR2M6L += KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࡠࡳࡢ࡮࡝ࡰฯ้๏฿ࠠๆๆไหฯูࠦๆษาࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆ่์็฿ࠠฤั้ห์࠭ࣘ")+LsG7EDcei1gMShH2aVOCo(u"ࠫࡡࡴࠧࣙ")+eaF2N0jWLdvHIs8r(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨࣚ")+ZEgwHfRnFV4[gy9NA3CROZolfEt4vVzMr(u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧࣛ")][Y5npATFarf1H9wBjc87(u"࠸੿")]+d0HDrq8Rtk16AlInw4TXb(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣜ")
	DPfOyNk6YarWmFKU2ezZlAiG(Sj1PYDmIpCUXO26(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨࣝ"),d0HDrq8Rtk16AlInw4TXb(u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨࣞ"),QQONb7aR2M6L,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ࣟ"))
	return
def dZAzEX3mG4OY0kHTL(RuI6T51ZqCPHAGJkVNb0YMFz):
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪ࣠")+RuI6T51ZqCPHAGJkVNb0YMFz+NQ4hg16DPUxtOyo5iGb(u"ࠬ࠯ࠧ࣡"), S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡖࡵࡹࡪુ"))
	return
def VbALIM4mvWkGJz2QgwohTjERHY():
	xmYBAMKujEkvWUpV(LsG7EDcei1gMShH2aVOCo(u"࠭ࡳࡵࡱࡳࠫ࣢"))
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(QQSULIva4ljNO73mFcWw(u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨࣣ"))
	return
def e9CfrQj5l6Sx():
	WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(Q2ZyGqCNYsftTc4MR7n(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧࣤ"), LsG7EDcei1gMShH2aVOCo(u"ࡗࡶࡺ࡫ૂ"))
	return
def ccuUSARfBCDlvHy7(showDialogs):
	if not showDialogs: svOyXbipkwY = KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࡘࡷࡻࡥૃ")
	else: svOyXbipkwY = nEYJ5OCXG0gcNy(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࡦࡩࡳࡺࡥࡳࠩࣥ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࣦࠪࠫ"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠫࠬࣧ"),Y5npATFarf1H9wBjc87(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࣨ"),NQ4hg16DPUxtOyo5iGb(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦวๅฤ้ࠤฤࣩ࠭"))
	if svOyXbipkwY==S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠱઀"):
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(IPkQW7LojF3HO18V(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ࣪"))
		if showDialogs: ztgqWUaDpe8CE9N(Sj1PYDmIpCUXO26(u"ࠨࠩ࣫"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠩࠪ࣬"),IPkQW7LojF3HO18V(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࣭࠭"),d0HDrq8Rtk16AlInw4TXb(u"ࠫฯ๋ࠠฦำึห้ࠦืๅสࠣษ้๏ࠠษำ้ห๊าࠠไ๊า๎ࠥอไั์ࠣๅ๏ࠦฬ่ษี็๊ࠥใ๋ࠢํๆํ๋ࠠษฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣ࠲ࠥฮๅศࠢไ๎์อࠠหฯา๎ะࠦ็ัษࠣห้ฮั็ษ่ะࠥ๎สฮัํฯ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲ࠥ๐ัอ๋ࠣษ฾฽วยࠢๆ์ิ๐ࠠ࠶ࠢาๆฬฬโࠡล๋ࠤศ้หาࠢ็็๏๊ࠦ็้ํࠤ฾๋ไ๋หࠣห้ะอะ์ฮ࣮ࠫ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩ࣯ࠩ"))
	return
def BkyTMHzu3VPwtpG7DcbgfRdIqC0r():
	ztgqWUaDpe8CE9N(hxSBTdGpyNVbfu4tr9(u"ࣰ࠭ࠧ"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨࣱ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࣲࠫ"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦร้ࠢสืฯิฯๆࠢࠥห้้๊ษ๊ิำ่ࠧࠦศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣห฻เืࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠩࣳ"))
	return
def GFfSeMJ2sC0XQ1EjTdW56BvAZU():
	ztgqWUaDpe8CE9N(Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪࠫࣴ"),MOwK1lpyNfCgqksX3jhV(u"ࠫࠬࣵ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࣶ"),eaF2N0jWLdvHIs8r(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩࣷ"))
	return
def pdHeIDkWABLxGiFhzturXRMZ97K(showDialogs=IPkQW7LojF3HO18V(u"࡙ࡸࡵࡦૄ")):
	EcpOD6fvg14QnlZkh = [OnvTrikzfEsY7qU8pgaRBtZy(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩࣸ"),MOwK1lpyNfCgqksX3jhV(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࣹࠩ"),gy9NA3CROZolfEt4vVzMr(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࣺࠬ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬࣻ"),onweDvmTOUj(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬࣼ"),IPkQW7LojF3HO18V(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩࣽ")]
	ZIBhKsgUS06rDTAEMmi1lozFeYWL = EcpOD6fvg14QnlZkh+[Q2ZyGqCNYsftTc4MR7n(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࣾ"),LsG7EDcei1gMShH2aVOCo(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬࣿ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧऀ"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨँ"),eaF2N0jWLdvHIs8r(u"ࠪࡷࡰ࡯࡮࠯ࡲ࡫ࡩࡳࡵ࡭ࡦࡰࡤࡰࡊࡓࡁࡅࠩं"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨः"),d0HDrq8Rtk16AlInw4TXb(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩऄ")]
	jcx62oQkzE5gIy = mGk5l3R8KAPgZ7vyQ1rFNxUsT([q6yUEoKVDb0fXmc8vhrMk7N(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨअ")])
	HjtILMZlfVP = []
	for giwrh4jLPc in [Y5npATFarf1H9wBjc87(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩआ")]:
		if giwrh4jLPc not in list(jcx62oQkzE5gIy.keys()): continue
		lSf5UiBMyzRED2nbPO7Ytpxdaw,bbY4m9hSGQ3TFXg,WiKq721uYnPjlb,pCEPOumRltIr3SD,eKFptPWva3woY,vN93t1zo2GKrfdaZhLuxTp,zgDKWYACLI3OBTvmVNnPf = jcx62oQkzE5gIy[giwrh4jLPc]
		if not bbY4m9hSGQ3TFXg or (bbY4m9hSGQ3TFXg and lSf5UiBMyzRED2nbPO7Ytpxdaw): HjtILMZlfVP.append(giwrh4jLPc)
	LT9IjaNyFEtfzSqgv = len(HjtILMZlfVP)>Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠱ઁ")
	Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(hvGPU2bmasopzFJxIEqfRYW41uQ6y)
	Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
	lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
	IFLocmGK52VsltyibDWn = []
	for giwrh4jLPc in EcpOD6fvg14QnlZkh:
		lU7cFRC6jSwkVLTmIM.execute(WWbmNvI40sM9Khlp25Ae(u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦࠢ࠲ࠤࠣࡥࡳࡪࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬइ")+giwrh4jLPc+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠥࠤࡀ࠭ई"))
		TiF5HCp4Zzf6ubclUONXI1AEL = lU7cFRC6jSwkVLTmIM.fetchall()
		if TiF5HCp4Zzf6ubclUONXI1AEL: IFLocmGK52VsltyibDWn.append(giwrh4jLPc)
	SOT9l7VrGEYWQwKqhf3 = len(IFLocmGK52VsltyibDWn)>OnvTrikzfEsY7qU8pgaRBtZy(u"࠲ં")
	for giwrh4jLPc in ZIBhKsgUS06rDTAEMmi1lozFeYWL:
		lU7cFRC6jSwkVLTmIM.execute(mtEXp14ijx(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨउ")+giwrh4jLPc+RS7ZoyGAq1c(u"ࠫࠧࠦ࠻ࠨऊ"))
		p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ = lU7cFRC6jSwkVLTmIM.fetchall()
		if p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ and Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧऋ") not in str(p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ): HjtILMZlfVP.append(giwrh4jLPc)
	C7Y896GHOASgn1MRIqvWTBxouF0k = len(HjtILMZlfVP)>FZBX5WcC3msIDv4hobLd8(u"࠳ઃ")
	HjtILMZlfVP = list(set(HjtILMZlfVP))
	Iof8U0xDKbVslWATpzR4OvBe9.close()
	lSf5UiBMyzRED2nbPO7Ytpxdaw = B2vCEI9FAVP15R8eUbDJdySc(u"ࡌࡡ࡭ࡵࡨૅ")
	if SOT9l7VrGEYWQwKqhf3 or C7Y896GHOASgn1MRIqvWTBxouF0k:
		svOyXbipkwY = nEYJ5OCXG0gcNy(QQSULIva4ljNO73mFcWw(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ऌ"),hxSBTdGpyNVbfu4tr9(u"ࠧࠨऍ"),QQSULIva4ljNO73mFcWw(u"ࠨࠩऎ"),onweDvmTOUj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬए"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪห้ฮั็ษ่ะࠥ๎ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡษ็ฦ๋ࠦฟ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩऐ"))
		if svOyXbipkwY==Y5npATFarf1H9wBjc87(u"࠵઄"):
			qSMOi0vwdIFGHx6hbjaWTVzA7XmNo = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡔࡳࡷࡨ૆")
			if LT9IjaNyFEtfzSqgv:
				qSMOi0vwdIFGHx6hbjaWTVzA7XmNo = AAHIlgDhjCR7kNmuF3(gy9NA3CROZolfEt4vVzMr(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ऑ"),onweDvmTOUj(u"ࡇࡣ࡯ࡷࡪે"),onweDvmTOUj(u"ࡇࡣ࡯ࡷࡪે"))
			xFDjYWR8KTbMSqed0sa19izgP7kEc = Sj1PYDmIpCUXO26(u"ࡖࡵࡹࡪૈ")
			if SOT9l7VrGEYWQwKqhf3:
				for giwrh4jLPc in IFLocmGK52VsltyibDWn: F8VGbcrHE0twmvq6o(giwrh4jLPc)
				xFDjYWR8KTbMSqed0sa19izgP7kEc = gy9NA3CROZolfEt4vVzMr(u"ࡗࡶࡺ࡫ૉ")
			vyezTUiW9ZQVB2aAb6 = eaF2N0jWLdvHIs8r(u"ࡘࡷࡻࡥ૊")
			if C7Y896GHOASgn1MRIqvWTBxouF0k:
				Iof8U0xDKbVslWATpzR4OvBe9 = RH0kWPhBvOFlu3m1eSqEj9.connect(hvGPU2bmasopzFJxIEqfRYW41uQ6y)
				Iof8U0xDKbVslWATpzR4OvBe9.text_factory = str
				lU7cFRC6jSwkVLTmIM = Iof8U0xDKbVslWATpzR4OvBe9.cursor()
				for giwrh4jLPc in HjtILMZlfVP:
					if Jbu2G0Qax8PYWpg(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࠨऒ") in giwrh4jLPc: p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ = giwrh4jLPc
					else: p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ = eaF2N0jWLdvHIs8r(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨओ")
					try: lU7cFRC6jSwkVLTmIM.execute(eaF2N0jWLdvHIs8r(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫऔ")+p2HKYl40cOzbrhJkB3dsSyQa6fmCDZ+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧक")+giwrh4jLPc+onweDvmTOUj(u"ࠩࠥࠤࡀ࠭ख"))
					except: vyezTUiW9ZQVB2aAb6 = FZBX5WcC3msIDv4hobLd8(u"ࡋࡧ࡬ࡴࡧો")
				Iof8U0xDKbVslWATpzR4OvBe9.commit()
				Iof8U0xDKbVslWATpzR4OvBe9.close()
			p1BoraOuWL.sleep(Y5npATFarf1H9wBjc87(u"࠶અ"))
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(Sj1PYDmIpCUXO26(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧग"))
			p1BoraOuWL.sleep(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷આ"))
			if qSMOi0vwdIFGHx6hbjaWTVzA7XmNo or xFDjYWR8KTbMSqed0sa19izgP7kEc or vyezTUiW9ZQVB2aAb6:
				lSf5UiBMyzRED2nbPO7Ytpxdaw = QQSULIva4ljNO73mFcWw(u"ࡌࡡ࡭ࡵࡨૌ")
				ztgqWUaDpe8CE9N(gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࠬघ"),RS7ZoyGAq1c(u"ࠬ࠭ङ"),Rz34c0NP5BGo1WuTZxSfOKj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩच"),FZBX5WcC3msIDv4hobLd8(u"ࠧอ์าࠤ࠳࠴ࠠห็ࠣฬ๋าวฮࠢอๅ฾๐ไ๊ࠡศู้ออࠡษ็ุ้ะ่ะ฻ࠣ์ฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅฮ่๎฾ࠦลืษไหฯࠦศา่ส้ัูࠦๆษาࠫछ"))
			else:
				lSf5UiBMyzRED2nbPO7Ytpxdaw = Sj1PYDmIpCUXO26(u"ࡔࡳࡷࡨ્")
				ztgqWUaDpe8CE9N(q6yUEoKVDb0fXmc8vhrMk7N(u"ࠨࠩज"),Q2ZyGqCNYsftTc4MR7n(u"ࠩࠪझ"),NQ4hg16DPUxtOyo5iGb(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ञ"),d0HDrq8Rtk16AlInw4TXb(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮ่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠวุ่ฬำࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩट"))
	elif showDialogs: ztgqWUaDpe8CE9N(onweDvmTOUj(u"ࠬ࠭ठ"),mtEXp14ijx(u"࠭ࠧड"),mtEXp14ijx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪढ"),Q2ZyGqCNYsftTc4MR7n(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤ๊ࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨण"))
	return lSf5UiBMyzRED2nbPO7Ytpxdaw
def K5k9UcFfMebQHdLZ1Wmio():
	NN2p0X1kfrABWD8RlaZw7vSsILz,LgWIRTJcuzCGlSfBr6Zjky7Aa,XQwCA1naGulc7Ve3y8FoOLI05qgD = RS7ZoyGAq1c(u"ࡇࡣ࡯ࡷࡪ૎"),Jbu2G0Qax8PYWpg(u"ࠩࠪत"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠪࠫथ")
	tM8Suavp4l6j,AQ7ykKb19LpCUlzR2s,iwHasBelt39ZDI7NjpycSh = S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡈࡤࡰࡸ࡫૏"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫࠬद"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠬ࠭ध")
	llOADhoufJ = [gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫन"),a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ऩ"),NQ4hg16DPUxtOyo5iGb(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪप"),Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨफ")]
	jcx62oQkzE5gIy = mGk5l3R8KAPgZ7vyQ1rFNxUsT(llOADhoufJ)
	for giwrh4jLPc in llOADhoufJ:
		if giwrh4jLPc not in list(jcx62oQkzE5gIy.keys()): continue
		lSf5UiBMyzRED2nbPO7Ytpxdaw,bbY4m9hSGQ3TFXg,fSqR6GPpTUFuIt48ZcgneB7Yi,JyVfD4seCUq9,O9sUkGbIecLPrT5d,EEhw76zSm9n,qqEfQzCNO3KJpu7iLeHd8FoTM = jcx62oQkzE5gIy[giwrh4jLPc]
		if giwrh4jLPc==MOwK1lpyNfCgqksX3jhV(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨब"):
			tM8Suavp4l6j = lSf5UiBMyzRED2nbPO7Ytpxdaw
			AQ7ykKb19LpCUlzR2s = q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫ࠭࠭भ")+bbY4m9hSGQ3TFXg+FZBX5WcC3msIDv4hobLd8(u"ࠬࠦࠧम")+AFuJDPbZhS134etQfj(EEhw76zSm9n)+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭ࠩࠨय")
			iwHasBelt39ZDI7NjpycSh = JyVfD4seCUq9
		elif giwrh4jLPc==MOwK1lpyNfCgqksX3jhV(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩर"):
			NN2p0X1kfrABWD8RlaZw7vSsILz = NN2p0X1kfrABWD8RlaZw7vSsILz or lSf5UiBMyzRED2nbPO7Ytpxdaw
			LgWIRTJcuzCGlSfBr6Zjky7Aa += LsG7EDcei1gMShH2aVOCo(u"ࠨࠢࠣ࠰ࠥࠦࠨࠨऱ")+bbY4m9hSGQ3TFXg+KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠩࠣࠫल")+AFuJDPbZhS134etQfj(EEhw76zSm9n)+hxSBTdGpyNVbfu4tr9(u"ࠪ࠭ࠬळ")
			XQwCA1naGulc7Ve3y8FoOLI05qgD += aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࠥࠦࠬࠡࠢࠪऴ")+JyVfD4seCUq9
		elif giwrh4jLPc==Y5npATFarf1H9wBjc87(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫव"):
			VldJKj6rQZhBc = lSf5UiBMyzRED2nbPO7Ytpxdaw
			Vm1lWXDEM4cA = gy9NA3CROZolfEt4vVzMr(u"࠭ࠨࠨश")+bbY4m9hSGQ3TFXg+RS7ZoyGAq1c(u"ࠧࠡࠩष")+AFuJDPbZhS134etQfj(EEhw76zSm9n)+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠨࠫࠪस")
			CCG2pHcDVqTEZKFQA1tb8YUv46JIgo = JyVfD4seCUq9
	LgWIRTJcuzCGlSfBr6Zjky7Aa = LgWIRTJcuzCGlSfBr6Zjky7Aa.strip(d0HDrq8Rtk16AlInw4TXb(u"ࠩࠣࠤ࠱ࠦࠠࠨह"))
	XQwCA1naGulc7Ve3y8FoOLI05qgD = XQwCA1naGulc7Ve3y8FoOLI05qgD.strip(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪࠤࠥ࠲ࠠࠡࠩऺ"))
	IM0OJWo2Ef3ga6nrS  = LsG7EDcei1gMShH2aVOCo(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫऻ")+iwHasBelt39ZDI7NjpycSh+IPkQW7LojF3HO18V(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ़ࠧ")
	IM0OJWo2Ef3ga6nrS += B2vCEI9FAVP15R8eUbDJdySc(u"࠭࡜࡯ࠩऽ")+Y5npATFarf1H9wBjc87(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫा")+AQ7ykKb19LpCUlzR2s+LsG7EDcei1gMShH2aVOCo(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪि")
	IM0OJWo2Ef3ga6nrS += IPkQW7LojF3HO18V(u"ࠩ࡟ࡲࡡࡴࠧी")+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪु")+XQwCA1naGulc7Ve3y8FoOLI05qgD+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ू")
	IM0OJWo2Ef3ga6nrS += Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬࡢ࡮ࠨृ")+hxSBTdGpyNVbfu4tr9(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪॄ")+LgWIRTJcuzCGlSfBr6Zjky7Aa+hxSBTdGpyNVbfu4tr9(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॅ")
	IM0OJWo2Ef3ga6nrS += IPkQW7LojF3HO18V(u"ࠨ࡞ࡱࡠࡳ࠭ॆ")+MOwK1lpyNfCgqksX3jhV(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨे")+CCG2pHcDVqTEZKFQA1tb8YUv46JIgo+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬै")
	IM0OJWo2Ef3ga6nrS += RS7ZoyGAq1c(u"ࠫࡡࡴࠧॉ")+WWbmNvI40sM9Khlp25Ae(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨॊ")+Vm1lWXDEM4cA+NQ4hg16DPUxtOyo5iGb(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨो")
	lSf5UiBMyzRED2nbPO7Ytpxdaw = (tM8Suavp4l6j or NN2p0X1kfrABWD8RlaZw7vSsILz)
	if lSf5UiBMyzRED2nbPO7Ytpxdaw:
		header = wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩौ")
		zawksMKvuS = Y5npATFarf1H9wBjc87(u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะ्ࠩ")
	else:
		header = a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪॎ")
		zawksMKvuS = Sj1PYDmIpCUXO26(u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬॏ")
	TqfupLx1VejQN6nzyiHvoO5wd8U = Sj1PYDmIpCUXO26(u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬॐ")
	YSr7Gq3EjLAV2JvM1tn5UPKZWw = IM0OJWo2Ef3ga6nrS+Sj1PYDmIpCUXO26(u"ࠬࡢ࡮࡝ࡰࠪ॑")+zawksMKvuS+FZBX5WcC3msIDv4hobLd8(u"࠭࡜࡯࡞ࡱ॒ࠫ")+TqfupLx1VejQN6nzyiHvoO5wd8U
	DPfOyNk6YarWmFKU2ezZlAiG(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭॓"),header,YSr7Gq3EjLAV2JvM1tn5UPKZWw,Rz34c0NP5BGo1WuTZxSfOKj(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ॔"))
	return
def wwnd49zbIZB(showDialogs,Jq7ZAfnuFT9dlrm1CWyBcNHRv):
	ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,mtEXp14ijx(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬॕ"),d0HDrq8Rtk16AlInw4TXb(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫॖ"))
	if showDialogs:
		K5k9UcFfMebQHdLZ1Wmio()
		ukZGxgIpD8mTYK2AfQe()
	if Jq7ZAfnuFT9dlrm1CWyBcNHRv:
		pdHeIDkWABLxGiFhzturXRMZ97K(IPkQW7LojF3HO18V(u"ࡉࡥࡱࡹࡥૐ"))
		kjAoQq7Ct3S0zv = [QQSULIva4ljNO73mFcWw(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩॗ"),IPkQW7LojF3HO18V(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫक़"),OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨख़"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫग़"),gy9NA3CROZolfEt4vVzMr(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬज़")]
		for jjk62BoRbyC3sDwAKWpv1xr4NheU0V in kjAoQq7Ct3S0zv:
			sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy,bbY4m9hSGQ3TFXg = AAHIlgDhjCR7kNmuF3(jjk62BoRbyC3sDwAKWpv1xr4NheU0V,RS7ZoyGAq1c(u"࡙ࡸࡵࡦ૒"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࡊࡦࡲࡳࡦ૑"))
		ccuUSARfBCDlvHy7(showDialogs)
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(mtEXp14ijx(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ड़"))
	return
def b6ORNrZ5wVgaTmByAto(nCfHXSeujoFNyEbvOpP=B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩढ़"),showDialogs=B2vCEI9FAVP15R8eUbDJdySc(u"࡚ࡲࡶࡧ૓")):
	IuorNOL7BDiSbPlJQkh4jZ6Fapm = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(QQSULIva4ljNO73mFcWw(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧफ़"))
	import json as mMzqnoiYfaSC
	data = mMzqnoiYfaSC.loads(IuorNOL7BDiSbPlJQkh4jZ6Fapm)
	aZwpMHfBAJPFUtsvkKm5 = data[MOwK1lpyNfCgqksX3jhV(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬय़")][B2vCEI9FAVP15R8eUbDJdySc(u"࠭ࡶࡢ࡮ࡸࡩࠬॠ")]
	if BhTAck1bPFYGuUqRW: aZwpMHfBAJPFUtsvkKm5 = aZwpMHfBAJPFUtsvkKm5.encode(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡶࡶࡩ࠼ࠬॡ"))
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(Jbu2G0Qax8PYWpg(u"ࠨࠩॢ"),hxSBTdGpyNVbfu4tr9(u"ࠩࠪॣ"),hxSBTdGpyNVbfu4tr9(u"ࠪࠫ।"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ॥"),hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪ०")+aZwpMHfBAJPFUtsvkKm5+S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨ१")+nCfHXSeujoFNyEbvOpP+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࠡมࠤࠫ२"))
		if svOyXbipkwY!=d0HDrq8Rtk16AlInw4TXb(u"࠱ઇ"): return Sj1PYDmIpCUXO26(u"ࡆࡢ࡮ࡶࡩ૔")
	sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy,sLtIxGhcrZFgoivmeYSnqpyl843 = AAHIlgDhjCR7kNmuF3(nCfHXSeujoFNyEbvOpP,RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡇࡣ࡯ࡷࡪ૕"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡇࡣ࡯ࡷࡪ૕"))
	if sycSign827ZrEldIB:
		if showDialogs: ztgqWUaDpe8CE9N(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࠩ३"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠩࠪ४"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭५"),eaF2N0jWLdvHIs8r(u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭६"))
		PcwChNBYmt4ruvsIEo = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩ७")+nCfHXSeujoFNyEbvOpP+RS7ZoyGAq1c(u"࠭ࠢࡾࡿࠪ८"))
		if wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧࡐࡍࠪ९") in PcwChNBYmt4ruvsIEo: sycSign827ZrEldIB = d0HDrq8Rtk16AlInw4TXb(u"ࡖࡵࡹࡪ૖")
		p1BoraOuWL.sleep(QQSULIva4ljNO73mFcWw(u"࠲ઈ"))
		WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(MOwK1lpyNfCgqksX3jhV(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ॰"))
	elif showDialogs: ztgqWUaDpe8CE9N(Y5npATFarf1H9wBjc87(u"ࠩࠪॱ"),Sj1PYDmIpCUXO26(u"ࠪࠫॲ"),Y5npATFarf1H9wBjc87(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧॳ"),lh6URegmQNq8LWX0HaK5(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧॴ"))
	return sycSign827ZrEldIB
def cPzAIOrxUw5XlveWpHSEhR(giwrh4jLPc,showDialogs=mtEXp14ijx(u"ࡗࡶࡺ࡫૗")):
	if showDialogs==Sj1PYDmIpCUXO26(u"࠭ࠧॵ"): showDialogs = LsG7EDcei1gMShH2aVOCo(u"ࡘࡷࡻࡥ૘")
	bLauGzhFlVrgdR0xU3kHTBQ8 = BONw71npD8mETluiGLPkdZM6rS0zoC([giwrh4jLPc])
	syBXTWJwnh7,j64jagcTHPLQN2m = bLauGzhFlVrgdR0xU3kHTBQ8[giwrh4jLPc]
	if j64jagcTHPLQN2m:
		sycSign827ZrEldIB = OnvTrikzfEsY7qU8pgaRBtZy(u"࡙ࡸࡵࡦ૙")
		if showDialogs: ztgqWUaDpe8CE9N(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠧࠨॶ"),WWbmNvI40sM9Khlp25Ae(u"ࠨࠩॷ"),NQ4hg16DPUxtOyo5iGb(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬॸ"),LsG7EDcei1gMShH2aVOCo(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬॹ")+giwrh4jLPc+RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧॺ"))
	else:
		sycSign827ZrEldIB = onweDvmTOUj(u"ࡌࡡ࡭ࡵࡨ૚")
		svOyXbipkwY = nEYJ5OCXG0gcNy(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬॻ"),d0HDrq8Rtk16AlInw4TXb(u"࠭ࠧॼ"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠧࠨॽ"),nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫॾ"),eaF2N0jWLdvHIs8r(u"ࠩࠪॿ")+giwrh4jLPc+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨঀ"))
		if svOyXbipkwY==q6yUEoKVDb0fXmc8vhrMk7N(u"࠳ઉ"):
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫঁ")+giwrh4jLPc+a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠬ࠯ࠧং"))
			p1BoraOuWL.sleep(Y5npATFarf1H9wBjc87(u"࠴ઊ"))
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(Jbu2G0Qax8PYWpg(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭ঃ"))
			p1BoraOuWL.sleep(OnvTrikzfEsY7qU8pgaRBtZy(u"࠵ઋ"))
			while WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.getCondVisibility(a1IrjsC9KbUv6ZqJnQASYkPTuBEi(u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ঄")): p1BoraOuWL.sleep(eaF2N0jWLdvHIs8r(u"࠶ઌ"))
			PcwChNBYmt4ruvsIEo = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(Q1QS6w8saLEuPW0O7XjlipekBTbq(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫঅ")+giwrh4jLPc+RS7ZoyGAq1c(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧআ"))
			if mtEXp14ijx(u"ࠪࡓࡐ࠭ই") in PcwChNBYmt4ruvsIEo:
				sycSign827ZrEldIB = d0HDrq8Rtk16AlInw4TXb(u"ࡔࡳࡷࡨ૛")
				if showDialogs: ztgqWUaDpe8CE9N(Q2ZyGqCNYsftTc4MR7n(u"ࠫࠬঈ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠬ࠭উ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩঊ"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠧห็ࠣๅา฻ࠠฤ๊ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭ঋ"))
			elif showDialogs: ztgqWUaDpe8CE9N(LsG7EDcei1gMShH2aVOCo(u"ࠨࠩঌ"),IPkQW7LojF3HO18V(u"ࠩࠪ঍"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭঎"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭এ"))
	return sycSign827ZrEldIB
def yAmNbVieUI39x0(giwrh4jLPc,qqEfQzCNO3KJpu7iLeHd8FoTM,showDialogs):
	sycSign827ZrEldIB = RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࡇࡣ࡯ࡷࡪ૜")
	if showDialogs:
		svOyXbipkwY = nEYJ5OCXG0gcNy(KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"ࠬ࠭ঐ"),eaF2N0jWLdvHIs8r(u"࠭ࠧ঑"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠧࠨ঒"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫও"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬঔ"))
		if svOyXbipkwY!=hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࠷ઍ"): return S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࡈࡤࡰࡸ࡫૝")
	WcH7gaZnESADRxbky1vGifLBVOjC = rycVB75alp(qqEfQzCNO3KJpu7iLeHd8FoTM,{},showDialogs)
	if WcH7gaZnESADRxbky1vGifLBVOjC:
		unB4qv2689foKhaEZPkH = Dh9MOxeTj6FW.path.join(COjW7yrR8DhcLg4IadwBU,giwrh4jLPc)
		IlTEWy8f4bpjLa7UR0c2qDY6S15Q(unB4qv2689foKhaEZPkH,eaF2N0jWLdvHIs8r(u"ࡘࡷࡻࡥ૟"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࡉࡥࡱࡹࡥ૞"))
		import zipfile as VRBt4c905n7SI8PJgZFaC6MuUheq,io as DQ0nr39kp7UEqHsmhTwLe658Y
		llSHNunIZ3qVdsOvFY18LpEmjRA = DQ0nr39kp7UEqHsmhTwLe658Y.BytesIO(WcH7gaZnESADRxbky1vGifLBVOjC)
		try:
			TdzLkKJ6ua3wDb1NeGVEoxX = VRBt4c905n7SI8PJgZFaC6MuUheq.ZipFile(llSHNunIZ3qVdsOvFY18LpEmjRA)
			TdzLkKJ6ua3wDb1NeGVEoxX.extractall(COjW7yrR8DhcLg4IadwBU)
			p1BoraOuWL.sleep(Sj1PYDmIpCUXO26(u"࠱઎"))
			WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executebuiltin(B2vCEI9FAVP15R8eUbDJdySc(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧক"))
			p1BoraOuWL.sleep(IPkQW7LojF3HO18V(u"࠳એ"))
			PcwChNBYmt4ruvsIEo = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(lh6URegmQNq8LWX0HaK5(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧখ")+giwrh4jLPc+hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪগ"))
			if Q1QS6w8saLEuPW0O7XjlipekBTbq(u"࠭ࡏࡌࠩঘ") in PcwChNBYmt4ruvsIEo: sycSign827ZrEldIB = hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"࡙ࡸࡵࡦૠ")
			ppr4YNOjLsDUF1K6Zh9mkbwXaH(qQ4BC6vW5YOfo,IPkQW7LojF3HO18V(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪঙ"),Sj1PYDmIpCUXO26(u"ࠨࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩচ"))
		except: sycSign827ZrEldIB = Jbu2G0Qax8PYWpg(u"ࡌࡡ࡭ࡵࡨૡ")
	if showDialogs:
		if sycSign827ZrEldIB: ztgqWUaDpe8CE9N(gy9NA3CROZolfEt4vVzMr(u"ࠩࠪছ"),mtEXp14ijx(u"ࠪࠫজ"),lh6URegmQNq8LWX0HaK5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧঝ"),aSf0iWG1kA7FsqjHbuC8NXB(u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩঞ"))
		else: ztgqWUaDpe8CE9N(OnvTrikzfEsY7qU8pgaRBtZy(u"࠭ࠧট"),gy9NA3CROZolfEt4vVzMr(u"ࠧࠨঠ"),OnvTrikzfEsY7qU8pgaRBtZy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫড"),MOwK1lpyNfCgqksX3jhV(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧঢ"))
	return sycSign827ZrEldIB
def AAHIlgDhjCR7kNmuF3(giwrh4jLPc,showDialogs,HrDLvCoOExZwIQYy1KfGb):
	svOyXbipkwY,sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy,bbY4m9hSGQ3TFXg = LsG7EDcei1gMShH2aVOCo(u"ࡕࡴࡸࡩૣ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࡆࡢ࡮ࡶࡩૢ"),IPkQW7LojF3HO18V(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪণ"),gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"ࠫࠬত")
	jcx62oQkzE5gIy = mGk5l3R8KAPgZ7vyQ1rFNxUsT([giwrh4jLPc])
	if giwrh4jLPc in list(jcx62oQkzE5gIy.keys()):
		lSf5UiBMyzRED2nbPO7Ytpxdaw,bbY4m9hSGQ3TFXg,fSqR6GPpTUFuIt48ZcgneB7Yi,JyVfD4seCUq9,O9sUkGbIecLPrT5d,EEhw76zSm9n,qqEfQzCNO3KJpu7iLeHd8FoTM = jcx62oQkzE5gIy[giwrh4jLPc]
		if EEhw76zSm9n==gy9NA3CROZolfEt4vVzMr(u"ࠬ࡭࡯ࡰࡦࠪথ"):
			sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy = LsG7EDcei1gMShH2aVOCo(u"ࡖࡵࡹࡪ૤"),KdhPA4SiFLHlJk0BGWjqDbaIcOzVT(u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧদ")
			if HrDLvCoOExZwIQYy1KfGb: ztgqWUaDpe8CE9N(QQSULIva4ljNO73mFcWw(u"ࠧࠨধ"),S8KcEIdhw7yVuNQgGHOMlpBTfe3Xo(u"ࠨࠩন"),Q2ZyGqCNYsftTc4MR7n(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ঩"),Sj1PYDmIpCUXO26(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠไ๊า๎ࠥ๐ำหะา้ࠥษฮาࠢศูิอัࠡ็อ์ๆืࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠๅ้ำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪপ")+giwrh4jLPc)
		else:
			if showDialogs:
				if EEhw76zSm9n==Sj1PYDmIpCUXO26(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ফ"): QQONb7aR2M6L = nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"๋ࠬส้ไไอࠬব")
				elif EEhw76zSm9n==gt48FLoNMrJRI7sdDpYGjcZBPuiqm(u"࠭࡯࡭ࡦࠪভ"): QQONb7aR2M6L = aSf0iWG1kA7FsqjHbuC8NXB(u"ࠧใัํ้ฮ࠭ম")
				elif EEhw76zSm9n==nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩয"): QQONb7aR2M6L = WWbmNvI40sM9Khlp25Ae(u"ࠩ฽๎ึࠦๅฬสออࠬর")
				svOyXbipkwY = nEYJ5OCXG0gcNy(B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࠫ঱"),hxSBTdGpyNVbfu4tr9(u"ࠫࠬল"),wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠬ࠭঳"),Sj1PYDmIpCUXO26(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ঴"),onweDvmTOUj(u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭঵")+QQONb7aR2M6L+wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪশ")+giwrh4jLPc)
			if not svOyXbipkwY: VVviTYwN6sz29MdukFeEW3QDy = FZBX5WcC3msIDv4hobLd8(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫষ")
			else:
				if EEhw76zSm9n==mtEXp14ijx(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬস"):
					rr60PDpqbMehZsYVuHmiAtN = WCdaXB2bfwyI0S3Fqet1LQoO5Rhv.executeJSONRPC(d0HDrq8Rtk16AlInw4TXb(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧহ")+giwrh4jLPc+FZBX5WcC3msIDv4hobLd8(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ঺"))
					if mtEXp14ijx(u"࠭ࡏࡌࠩ঻") in rr60PDpqbMehZsYVuHmiAtN:
						sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy = eaF2N0jWLdvHIs8r(u"ࡗࡶࡺ࡫૥"),eaF2N0jWLdvHIs8r(u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨ়")
						if showDialogs: ztgqWUaDpe8CE9N(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠩঽ"),WWbmNvI40sM9Khlp25Ae(u"ࠩࠪা"),LsG7EDcei1gMShH2aVOCo(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ি"),hxSBTdGpyNVbfu4tr9(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩী")+giwrh4jLPc)
					elif showDialogs: ztgqWUaDpe8CE9N(RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠬ࠭ু"),Sj1PYDmIpCUXO26(u"࠭ࠧূ"),eaF2N0jWLdvHIs8r(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪৃ"),onweDvmTOUj(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫৄ")+giwrh4jLPc)
				elif EEhw76zSm9n in [OnvTrikzfEsY7qU8pgaRBtZy(u"ࠩࡲࡰࡩ࠭৅"),B2vCEI9FAVP15R8eUbDJdySc(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ৆")]:
					sycSign827ZrEldIB = yAmNbVieUI39x0(giwrh4jLPc,qqEfQzCNO3KJpu7iLeHd8FoTM,Rz34c0NP5BGo1WuTZxSfOKj(u"ࡊࡦࡲࡳࡦ૦"))
					if sycSign827ZrEldIB:
						if EEhw76zSm9n==aSf0iWG1kA7FsqjHbuC8NXB(u"ࠫࡴࡲࡤࠨে"): VVviTYwN6sz29MdukFeEW3QDy = OnvTrikzfEsY7qU8pgaRBtZy(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ৈ")
						elif EEhw76zSm9n==Sj1PYDmIpCUXO26(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ৉"): VVviTYwN6sz29MdukFeEW3QDy = IPkQW7LojF3HO18V(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪ৊")
						bbY4m9hSGQ3TFXg = JyVfD4seCUq9
						if showDialogs:
							if VVviTYwN6sz29MdukFeEW3QDy==onweDvmTOUj(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩো"): ztgqWUaDpe8CE9N(Y5npATFarf1H9wBjc87(u"ࠩࠪৌ"),QQSULIva4ljNO73mFcWw(u"্ࠪࠫ"),Y5npATFarf1H9wBjc87(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧৎ"),Rz34c0NP5BGo1WuTZxSfOKj(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ৏")+giwrh4jLPc)
							elif VVviTYwN6sz29MdukFeEW3QDy==Sj1PYDmIpCUXO26(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ৐"): ztgqWUaDpe8CE9N(hRFbZmJoxpKWwBMDQnyOzcXItdEl(u"ࠧࠨ৑"),RWnd79GQpKM1gV5xAO2amZkTrL8F(u"ࠨࠩ৒"),lh6URegmQNq8LWX0HaK5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৓"),WWbmNvI40sM9Khlp25Ae(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫ৔")+giwrh4jLPc)
					elif showDialogs: ztgqWUaDpe8CE9N(nn4vXdlLQVkSxW1sEDTt9ZfgaBbqR(u"ࠫࠬ৕"),QQSULIva4ljNO73mFcWw(u"ࠬ࠭৖"),MOwK1lpyNfCgqksX3jhV(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩৗ"),q6yUEoKVDb0fXmc8vhrMk7N(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ৘")+giwrh4jLPc)
	elif showDialogs: ztgqWUaDpe8CE9N(wKdxVbTc0X9NSiespM8OvHGUhf(u"ࠨࠩ৙"),eaF2N0jWLdvHIs8r(u"ࠩࠪ৚"),WWbmNvI40sM9Khlp25Ae(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭৛"),RS7ZoyGAq1c(u"้๊ࠫริใࠣ࠲࠳ࠦ็ั้ࠣห้หึศใฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨড়")+giwrh4jLPc)
	return sycSign827ZrEldIB,VVviTYwN6sz29MdukFeEW3QDy,bbY4m9hSGQ3TFXg
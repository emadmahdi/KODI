# -*- coding: utf-8 -*-
from FJKmvLp8Tl import *
HmvY29bj4dNgF7wZqr1lzkeQxiEasu = 'EGYBEST3'
ToYWiIbruzUaNKRPZLG16cAj = '_EB3_'
aaeRjxiYcqOI6Sf8 = ZEgwHfRnFV4[HmvY29bj4dNgF7wZqr1lzkeQxiEasu][0]
C1pRb6K8Qs = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def GI13aCFr0qimdOT(mode,url,SSGEc76fBan2,text):
	if   mode==790: rr60PDpqbMehZsYVuHmiAtN = De6s5ngUzirypRbLmKcdq()
	elif mode==791: rr60PDpqbMehZsYVuHmiAtN = KKlnDcetq8Rrp3GY0(url,SSGEc76fBan2)
	elif mode==792: rr60PDpqbMehZsYVuHmiAtN = OJuEhdBtkzi5C8NfmGKgoAL0(url)
	elif mode==793: rr60PDpqbMehZsYVuHmiAtN = fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url)
	elif mode==796: rr60PDpqbMehZsYVuHmiAtN = N9Z2eImKc1vWlwaT0bYrRpqt6(url,SSGEc76fBan2)
	elif mode==799: rr60PDpqbMehZsYVuHmiAtN = kV5Wue06vFixocBhPIZY9z(text)
	else: rr60PDpqbMehZsYVuHmiAtN = False
	return rr60PDpqbMehZsYVuHmiAtN
def De6s5ngUzirypRbLmKcdq():
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(IIbavC96MQ1nHq3Pjx,'GET',aaeRjxiYcqOI6Sf8,'','','','','EGYBEST3-MENU-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('list-pages(.*?)fa-folder',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?<span>(.*?)</span>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791)
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-article(.*?)social-box',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('main-title.*?">(.*?)<.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for title,ZcAK0askvzIWr4R in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791,'','mainmenu')
		UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-menu(.*?)</ul>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for ZcAK0askvzIWr4R,title in items:
			title = title.strip(' ')
			if any(EPwT39HrS1tU6Ng8YBGpJADixzLV5C in title for EPwT39HrS1tU6Ng8YBGpJADixzLV5C in C1pRb6K8Qs): continue
			if 'http' not in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = aaeRjxiYcqOI6Sf8+ZcAK0askvzIWr4R
			UZ8LYnm5jsl9uKM0xDX('folder',HmvY29bj4dNgF7wZqr1lzkeQxiEasu+'_SCRIPT_'+ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791)
	return BsJ71WIxDtdFKveTcRPrqM4Cwb
def N9Z2eImKc1vWlwaT0bYrRpqt6(url,type=''):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-article".*?">(.*?)<(.*?)article',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		v0hReYLd84QxBaq7Og6nlV,gbRaTlfw5quES79COD2yPhJXzie6,items = '','',[]
		for name,L0Uwx52bTBM in pDTlIgyewF1XV69R8kd:
			if 'حلقات' in name: gbRaTlfw5quES79COD2yPhJXzie6 = L0Uwx52bTBM
			if 'مواسم' in name: v0hReYLd84QxBaq7Og6nlV = L0Uwx52bTBM
		if v0hReYLd84QxBaq7Og6nlV and not type:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',v0hReYLd84QxBaq7Og6nlV,SomeI8i56FaDMGPE.DOTALL)
			if len(items)>1:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,796,pjMZ802XQCSxYVk,'season')
		if gbRaTlfw5quES79COD2yPhJXzie6 and len(items)<2:
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
			if items:
				for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,793,pjMZ802XQCSxYVk)
			else:
				items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',gbRaTlfw5quES79COD2yPhJXzie6,SomeI8i56FaDMGPE.DOTALL)
				for ZcAK0askvzIWr4R,title in items:
					UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,793)
	return
def KKlnDcetq8Rrp3GY0(url,type=''):
	TTCEsZlVieuSa1OWbAmGoPdgtR9,start,C4CEWLV96T8Dwzd,select,LrcJa0TQS632PNu7xHGFiqCdX51ZsR = 0,0,'','',''
	if 'pagination' in type:
		ALIXNYBjeZgf5OEdyD,data = RyQ1vTDniwqI7jCNMHmtcLaVK(url)
		TTCEsZlVieuSa1OWbAmGoPdgtR9 = int(data['limit'])
		start = int(data['start'])
		C4CEWLV96T8Dwzd = data['type']
		select = data['select']
		ZZm1hsDV9ba = 'limit='+str(TTCEsZlVieuSa1OWbAmGoPdgtR9)+'&start='+str(start)+'&type='+C4CEWLV96T8Dwzd+'&select='+select
		mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded'}
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',ALIXNYBjeZgf5OEdyD,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','EGYBEST3-TITLES-1st')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ppq6Bg4vPbVs = 'blocks'+BsJ71WIxDtdFKveTcRPrqM4Cwb+'article'
	else:
		ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
		ppq6Bg4vPbVs = BsJ71WIxDtdFKveTcRPrqM4Cwb
		code = SomeI8i56FaDMGPE.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			fYZzomwSjkedXVcEvLDqKHMt9rFnN,data = RyQ1vTDniwqI7jCNMHmtcLaVK('?'+code)
			TTCEsZlVieuSa1OWbAmGoPdgtR9 = int(data['limit'])
			start = int(data['start'])
			C4CEWLV96T8Dwzd = data['type']
			select = data['select']
			LrcJa0TQS632PNu7xHGFiqCdX51ZsR = data['ajaxurl']
			ZZm1hsDV9ba = 'limit='+str(TTCEsZlVieuSa1OWbAmGoPdgtR9)+'&start='+str(start)+'&type='+C4CEWLV96T8Dwzd+'&select='+select
			ALIXNYBjeZgf5OEdyD = aaeRjxiYcqOI6Sf8+LrcJa0TQS632PNu7xHGFiqCdX51ZsR
			mgDoj8ZAqe0uBLxP4Kzp = {'Content-Type':'application/x-www-form-urlencoded'}
			ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(jj0C6IlvPFh,'POST',ALIXNYBjeZgf5OEdyD,ZZm1hsDV9ba,mgDoj8ZAqe0uBLxP4Kzp,'','','EGYBEST3-TITLES-3rd')
			ppq6Bg4vPbVs = ttpgqJBdkoxeKOcwaiP.content
			ppq6Bg4vPbVs = 'blocks'+ppq6Bg4vPbVs+'article'
	items,EEQy35Z2dq6DHvLKXA,LE0VmiWeMGS4dHJ3 = [],False,False
	if not type:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-content(.*?)</div>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?</i>(.*?)</a>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,title in items:
				title = title.strip(' ')
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791,'','submenu')
				EEQy35Z2dq6DHvLKXA = True
	if not type:
		LE0VmiWeMGS4dHJ3 = BexcQj7TyYU84szLOSa9JR0(BsJ71WIxDtdFKveTcRPrqM4Cwb)
	if not EEQy35Z2dq6DHvLKXA and not LE0VmiWeMGS4dHJ3:
		pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('blocks(.*?)article',ppq6Bg4vPbVs,SomeI8i56FaDMGPE.DOTALL)
		if pDTlIgyewF1XV69R8kd:
			L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
			items = SomeI8i56FaDMGPE.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,pjMZ802XQCSxYVk,title in items:
				pjMZ802XQCSxYVk = pjMZ802XQCSxYVk.strip('\n')
				ZcAK0askvzIWr4R = aDebGvrkdptunqTM8m4(ZcAK0askvzIWr4R)
				if '/selary/' in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791,pjMZ802XQCSxYVk)
				elif 'مسلسل' in ZcAK0askvzIWr4R and 'حلقة' not in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,796,pjMZ802XQCSxYVk)
				elif 'موسم' in ZcAK0askvzIWr4R and 'حلقة' not in ZcAK0askvzIWr4R: UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,796,pjMZ802XQCSxYVk)
				else: UZ8LYnm5jsl9uKM0xDX('video',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,793,pjMZ802XQCSxYVk)
		E2EtAT9INQC8Gwkgs7 = 12
		data = SomeI8i56FaDMGPE.findall('class="(load-more.*?)<',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
		if len(items)==E2EtAT9INQC8Gwkgs7 and (data or 'pagination' in type):
			ZZm1hsDV9ba = 'limit='+str(E2EtAT9INQC8Gwkgs7)+'&start='+str(start+E2EtAT9INQC8Gwkgs7)+'&type='+C4CEWLV96T8Dwzd+'&select='+select
			vfIB6ib8q1hFX5GweRrVPNTjY2E = ALIXNYBjeZgf5OEdyD+'?next=page&'+ZZm1hsDV9ba
			UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+'المزيد',vfIB6ib8q1hFX5GweRrVPNTjY2E,791,'','pagination_'+type)
	return
def BexcQj7TyYU84szLOSa9JR0(BsJ71WIxDtdFKveTcRPrqM4Cwb):
	LE0VmiWeMGS4dHJ3 = False
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('main-article(.*?)article',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		UUTVrGP7Y31a = SomeI8i56FaDMGPE.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		if UUTVrGP7Y31a: UZ8LYnm5jsl9uKM0xDX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for g2SEJ1ObmZnIX0dAKFPzqNiRH95W4B,name,L0Uwx52bTBM in UUTVrGP7Y31a:
			name = name.strip(' ')
			items = SomeI8i56FaDMGPE.findall('href="(.*?)">(.*?)<',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
			for ZcAK0askvzIWr4R,EPwT39HrS1tU6Ng8YBGpJADixzLV5C in items:
				title = name+':  '+EPwT39HrS1tU6Ng8YBGpJADixzLV5C
				UZ8LYnm5jsl9uKM0xDX('folder',ToYWiIbruzUaNKRPZLG16cAj+title,ZcAK0askvzIWr4R,791,'','filter')
				LE0VmiWeMGS4dHJ3 = True
	return LE0VmiWeMGS4dHJ3
def fN8bEVYjUF0IlJ1xQL5RuWXe2oSM(url):
	ttpgqJBdkoxeKOcwaiP = eWltKEO6ar3XBdZ(fyIAplJLe9MGiPosBvrEOtZUm6,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	BsJ71WIxDtdFKveTcRPrqM4Cwb = ttpgqJBdkoxeKOcwaiP.content
	TbFRyPoVlrQAw7n3h8BukmfHNq,ZqrDM2pIkCR89FP3On = [],[]
	items = SomeI8i56FaDMGPE.findall('server-item.*?data-code="(.*?)"',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	for OAp6L3KTXke8EsZF1PCo97 in items:
		eqQY5uMRSydV61a93Bprf8LvtWKg = jjsSA3nOp2Qz5MdX7Nf9vHDy1V.b64decode(OAp6L3KTXke8EsZF1PCo97)
		if ZZxLpCcmqhyT6NuMWelkbSvr0H: eqQY5uMRSydV61a93Bprf8LvtWKg = eqQY5uMRSydV61a93Bprf8LvtWKg.decode('utf8')
		ZcAK0askvzIWr4R = SomeI8i56FaDMGPE.findall('src="(.*?)"',eqQY5uMRSydV61a93Bprf8LvtWKg,SomeI8i56FaDMGPE.DOTALL)
		if ZcAK0askvzIWr4R:
			ZcAK0askvzIWr4R = ZcAK0askvzIWr4R[0]
			if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
				ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
				FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__watch')
	pDTlIgyewF1XV69R8kd = SomeI8i56FaDMGPE.findall('class="downloads(.*?)</section>',BsJ71WIxDtdFKveTcRPrqM4Cwb,SomeI8i56FaDMGPE.DOTALL)
	if pDTlIgyewF1XV69R8kd:
		L0Uwx52bTBM = pDTlIgyewF1XV69R8kd[0]
		items = SomeI8i56FaDMGPE.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',L0Uwx52bTBM,SomeI8i56FaDMGPE.DOTALL)
		for AfejZJoKh4D7k5G1P9gCwxTz,ZcAK0askvzIWr4R in items:
			if ZcAK0askvzIWr4R not in ZqrDM2pIkCR89FP3On:
				if '/?url=' in ZcAK0askvzIWr4R: ZcAK0askvzIWr4R = ZcAK0askvzIWr4R.split('/?url=')[1]
				ZqrDM2pIkCR89FP3On.append(ZcAK0askvzIWr4R)
				FglT5H2faVGm6IqpcXS9vQsojPLu = DRom9hFTZXKuvfr2(ZcAK0askvzIWr4R,'name')
				TbFRyPoVlrQAw7n3h8BukmfHNq.append(ZcAK0askvzIWr4R+'?named='+FglT5H2faVGm6IqpcXS9vQsojPLu+'__download____'+AfejZJoKh4D7k5G1P9gCwxTz)
	import Y4ILyJBspQ
	Y4ILyJBspQ.vjr9310yigkK(TbFRyPoVlrQAw7n3h8BukmfHNq,HmvY29bj4dNgF7wZqr1lzkeQxiEasu,'video',url)
	return
def kV5Wue06vFixocBhPIZY9z(text):
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ擤")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ擥")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
l1l11lll1ll_l1_ = l1ll11l_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1111l_l1_(url)
	elif mode==52: results = l1llllll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1lll1l11ll11_l1_()
	elif mode==56: results = l1lll1l11l11l_l1_()
	elif mode==57: results = l1lll1l11ll_l1_(url,1)
	elif mode==58: results = l1lll1l11ll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ擦"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ擧"),l11lll_l1_ (u"ࠩࠪ擨"),59,l11lll_l1_ (u"ࠪࠫ擩"),l11lll_l1_ (u"ࠫࠬ擪"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ擫"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ擬"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ擭"),l11lll_l1_ (u"ࠨࠩ擮"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ擯"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ擰")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ擱"),l11lll_l1_ (u"ࠬ࠭擲"),56)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擳"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ擴")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็หๆ๊วๆࠩ擵"),l11lll_l1_ (u"ࠩࠪ擶"),55)
	return l11lll_l1_ (u"ࠪࠫ擷")
def l1lll1l11ll11_l1_():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擸"),l111ll_l1_+l11lll_l1_ (u"ࠬออะอࠣห้อแๅษ่ࠫ擹"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ擺"),51)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ擻"),l111ll_l1_+l11lll_l1_ (u"ࠨษไ่ฬ๋ࠠาษษะฮ࠭擼"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ擽"),51)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ擾"),l111ll_l1_+l11lll_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็หๆ๊วๆࠩ擿"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ攀"),51)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攁"),l111ll_l1_+l11lll_l1_ (u"ࠧศใ็ห๊ࠦใๅษึ๎่๐ษࠨ攂"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ攃"),51)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ攄"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ攅"),l11lll_l1_ (u"ࠫࠬ攆"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ攇"),l111ll_l1_+l11lll_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ攈"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡼࡳࡵ࠭攉"),57)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攊"),l111ll_l1_+l11lll_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ攋"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ攌"),57)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ攍"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ攎"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ攏"),57)
	return
def l1lll1l11l11l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ攐"),l111ll_l1_+l11lll_l1_ (u"ࠨษะำะࠦวๅ็ึุ่๊วหࠩ攑"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ攒"),51)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ攓"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥืววฮฬࠫ攔"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ攕"),51)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攖"),l111ll_l1_+l11lll_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊ๅิๆึ่ฬะࠧ攗"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ攘"),51)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ攙"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤ่๊วิ์ๆ๎ฮ࠭攚"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ攛"),51)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ攜"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭攝"),l11lll_l1_ (u"ࠧࠨ攞"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攟"),l111ll_l1_+l11lll_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ攠"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡹࡰࡲࠪ攡"),57)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ攢"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ攣"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ攤"),57)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ攥"),l111ll_l1_+l11lll_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ攦"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ攧"),57)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ攨"),l11lll_l1_ (u"ࠫࠬ攩"),url,url)
	if l11lll_l1_ (u"ࠬࡅࠧ攪") in url:
		parts = url.split(l11lll_l1_ (u"࠭࠿ࠨ攫"))
		url = parts[0]
		filter = l11lll_l1_ (u"ࠧࡀࠩ攬") + QUOTE(parts[1],l11lll_l1_ (u"ࠨ࠿ࠩ࠾࠴ࠫࠧ攭"))
	else: filter = l11lll_l1_ (u"ࠩࠪ攮")
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ支"),l11lll_l1_ (u"ࠫࠬ攰"),filter,l11lll_l1_ (u"ࠬ࠭攱"))
	parts = url.split(l11lll_l1_ (u"࠭࠯ࠨ攲"))
	sort,l1l11l1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11lll_l1_ (u"ࠧࡺࡱࡳࠫ攳"),l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࠨ攴"),l11lll_l1_ (u"ࠩࡹ࡭ࡪࡽࡳࠨ攵")]:
		if type==l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ收"): l1l1111l1_l1_=l11lll_l1_ (u"ࠫๆ๐ไๆࠩ攷")
		elif type==l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ攸"): l1l1111l1_l1_=l11lll_l1_ (u"࠭ๅิๆึ่ࠬ改")
		#url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ攺") + QUOTE(l1l1111l1_l1_) + l11lll_l1_ (u"ࠨ࠱ࠪ攻") + l1l11l1_l1_ + l11lll_l1_ (u"ࠩ࠲ࠫ攼") + sort + filter
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ攽") + QUOTE(l1l1111l1_l1_) + l11lll_l1_ (u"ࠫ࠴࠭放") + l1l11l1_l1_ + l11lll_l1_ (u"ࠬ࠵ࠧ政") + sort + filter
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ敀"),l11lll_l1_ (u"ࠧࠨ敁"),l11lll_l1_ (u"ࠨࠩ敂"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠩࠪ敃"),l11lll_l1_ (u"ࠪࠫ敄"),l11lll_l1_ (u"ࠫࠬ故"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ敆"))
		#items = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡴࡵ࡮ࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡸࡥࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ敇"),html,re.DOTALL)
		items = re.findall(l11lll_l1_ (u"ࠧࠣࡲ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࠤࡳࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠰ࡅࠢࡱࡧࡳ࡭ࡸࡵࡤࡦࡵࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡵࡸࡥࡴࡤࡤࡷࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ效"),html,re.DOTALL)
		l1l11ll1111_l1_=0
		for id,title,l1lll1l111l1l_l1_,l1llll_l1_ in items:
			l1l11ll1111_l1_ += 1
			#l1llll_l1_ = l11lllll11_l1_ + l11lll_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ敉") + l1llll_l1_ + l11lll_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ敊")
			l1llll_l1_ = l1l11lll1ll_l1_ + l11lll_l1_ (u"ࠪ࠳ࡻ࠸࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴ࡳࡡࡪࡰ࠲ࠫ敋") + l1llll_l1_ + l11lll_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ敌")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ敍") + id
			if type==l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ敎"): addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭敏"),l111ll_l1_+title,link,53,l1llll_l1_)
			if type==l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ敐"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ救"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪ敒")+title,link+l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ敓")+l1lll1l111l1l_l1_+l11lll_l1_ (u"ࠬࡃࠧ敔")+title+l11lll_l1_ (u"࠭࠽ࠨ敕")+l1llll_l1_,52,l1llll_l1_)
	else:
		if type==l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭敖"): l1l1111l1_l1_=l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ敗")
		elif type==l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ敘"): l1l1111l1_l1_=l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ教")
		url = l11lllll11_l1_ + l11lll_l1_ (u"ࠫ࠴ࡰࡳࡰࡰ࠲ࡷࡪࡲࡥࡤࡶࡨࡨ࠴࠭敚") + sort + l11lll_l1_ (u"ࠬ࠳ࠧ敛") + l1l1111l1_l1_ + l11lll_l1_ (u"࠭࠭ࡘ࡙࠱࡮ࡸࡵ࡮ࠨ敜")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ敝"),l11lll_l1_ (u"ࠨࠩ敞"),l11lll_l1_ (u"ࠩࠪ敟"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ敠"))
		items = re.findall(l11lll_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ敡"),html,re.DOTALL)
		l1l11ll1111_l1_=0
		for id,l1lll1l111l1l_l1_,l1llll_l1_,title in items:
			l1l11ll1111_l1_ += 1
			l1llll_l1_ = l11lllll11_l1_ + l11lll_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ敢") + l1llll_l1_ + l11lll_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭散")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ敤") + id
			if type==l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ敥"): addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ敦"),l111ll_l1_+title,link,53,l1llll_l1_)
			elif type==l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ敧"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ敨"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็ࠤࠬ敩")+title,link+l11lll_l1_ (u"࠭࠿ࡦࡲࡀࠫ敪")+l1lll1l111l1l_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ敫")+title+l11lll_l1_ (u"ࠨ࠿ࠪ敬")+l1llll_l1_,52,l1llll_l1_)
	title=l11lll_l1_ (u"ุࠩๅาฯࠠࠨ敭")
	if l1l11ll1111_l1_==16:
		for l1l11llll11_l1_ in range(1,13) :
			if not l1l11l1_l1_==str(l1l11llll11_l1_):
				#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ敮")+type+l11lll_l1_ (u"ࠫ࠴࠭敯")+str(l1l11llll11_l1_)+l11lll_l1_ (u"ࠬ࠵ࠧ数")+sort + filter
				url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ敱")+type+l11lll_l1_ (u"ࠧ࠰ࠩ敲")+str(l1l11llll11_l1_)+l11lll_l1_ (u"ࠨ࠱ࠪ敳")+sort + filter
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ整"),l111ll_l1_+title+str(l1l11llll11_l1_),url,51)
	return
def l1llllll_l1_(url):
	parts = url.split(l11lll_l1_ (u"ࠪࡁࠬ敵"))
	l1lll1l111l1l_l1_ = int(parts[1])
	name = l111l_l1_(parts[2])
	name = name.replace(l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ敶"),l11lll_l1_ (u"ࠬ࠭敷"))
	l1llll_l1_ = parts[3]
	url = url.split(l11lll_l1_ (u"࠭࠿ࠨ數"))[0]
	if l1lll1l111l1l_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ敹"),l11lll_l1_ (u"ࠨࠩ敺"),l11lll_l1_ (u"ࠩࠪ敻"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ敼"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬ敽"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ敾"),block,re.DOTALL)
		l1lll1l111l1l_l1_ = int(items[-1])
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ敿"),l11lll_l1_ (u"ࠧࠨ斀"),l1lll1l111l1l_l1_,l11lll_l1_ (u"ࠨࠩ斁"))
	#name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡯ࡴ࡭ࡧࠥ斂") )
	#l1llll_l1_ = xbmc.getInfoLabel( l11lll_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠦ斃") )
	for l1lll11_l1_ in range(l1lll1l111l1l_l1_,0,-1):
		link = url + l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ斄") + str(l1lll11_l1_)
		title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ斅")+name+l11lll_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ斆")+str(l1lll11_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭文"),l111ll_l1_+title,link,53,l1llll_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠨࠩ斈"),l11lll_l1_ (u"ࠩࠪ斉"),l11lll_l1_ (u"ࠪࠫ斊"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ斋"))
	l1lll1l11l111_l1_ = re.findall(l11lll_l1_ (u"๋ࠬส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี࠮ࠫࡁࡰࡳࡲ࡫࡮ࡵ࡞ࠫࠦ࠭࠴ࠪࡀࠫࠥࠫ斌"),html,re.DOTALL)
	if l1lll1l11l111_l1_:
		time = l1lll1l11l111_l1_[1].replace(l11lll_l1_ (u"࠭ࡔࠨ斍"),l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠬ斎"))
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ斏"),l11lll_l1_ (u"ࠩࠪ斐"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠬ斑"),l11lll_l1_ (u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢึ๎่๎ๆࠡ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั๋ࠣีอࠠศๆ๋ๆฯ࠭斒")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ斓")+time)
		return
	#if l11lll_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ斔") in html:
	#	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ斕"),l11lll_l1_ (u"ࠨࠩ斖"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠫ斗"),l11lll_l1_ (u"๊ࠪ฾ะะาࠢ฼่๎่ࠦใ๊฼ࠤำ฽รࠨ斘"))
	#	return
	l1lll1l1111ll_l1_,l1lll1l11l1l1_l1_ = [],[]
	l1lll1l11l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡱࡵ࡭࡬࡯࡮ࡠ࡮࡬ࡲࡰࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ料"),html,re.DOTALL)[0]
	l1lll1l111lll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡼࡡࡳࠢࡥࡥࡨࡱࡵࡱࡡࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ斚"),html,re.DOTALL)[0]
	# l1llll1l1_l1_ links
	links = re.findall(l11lll_l1_ (u"࠭ࡨ࡭ࡵ࠽ࠤ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ斛"),html,re.DOTALL)
	for server,link in links:
		if l11lll_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠧ斜") in server:
			server = l11lll_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠡࡵࡨࡶࡻ࡫ࡲࠨ斝")
			url = l1lll1l111lll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴࠠࡴࡧࡵࡺࡪࡸࠧ斞")
			url = l1lll1l11l1ll_l1_ + link
		if l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ斟") in url:
			l1lll1l1111ll_l1_.append(url)
			l1lll1l11l1l1_l1_.append(l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠣࠫ斠")+server)
		l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡭࡫ࠦࠧ࠯࡯࠶ࡹ࠽࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡹࡷࡲࠩࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࠴ࡢࡃ࠽ࠨ࠯࠴ࠫ࠿ࠐࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴࡡࡸࡶࡱ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟࡯ࡣࡰࡩ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࡭࠴ࡷ࠻ࠤࠥ࠭ࠫࡴࡧࡵࡺࡪࡸࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࡮ࡨࡲ࠭ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠫ࠽ࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡷࡵࡰ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡪ࡟ࠬࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠤࡂࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࡝࡬ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠦࠧࠪ࡝࠳ࡡࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠣࠤࠥ࠭ࠬࠨࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࡨ࡬ࡰࡪࡺࡹࡱࡧ࠮ࠫࠥࠦࠧࠬࡵࡨࡶࡻ࡫ࡲࠬࠩࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠤࠥࠦ斡")
	# l1111lll_l1_ links
	links = re.findall(l11lll_l1_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ斢"),html,re.DOTALL)
	links += re.findall(l11lll_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ斣"),html,re.DOTALL)
	for server,link in links:
		filename = link.split(l11lll_l1_ (u"ࠨ࠱ࠪ斤"))[-1]
		filename = filename.replace(l11lll_l1_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ斥"),l11lll_l1_ (u"ࠪࠫ斦"))
		filename = filename.replace(l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ斧"),l11lll_l1_ (u"ࠬ࠭斨"))
		filename = filename.replace(l11lll_l1_ (u"࠭࠭ࠨ斩"),l11lll_l1_ (u"ࠧࠨ斪"))
		if l11lll_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ斫") in server:
			server = l11lll_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ斬")
			url = l1lll1l111lll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ断")
			url = l1lll1l11l1ll_l1_ + link
		l1lll1l1111ll_l1_.append(url)
		l1lll1l11l1l1_l1_.append(l11lll_l1_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ斮")+server+l11lll_l1_ (u"ࠬࠦࠠࠨ斯")+filename)
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ新"), l1lll1l11l1l1_l1_)
	if l1l_l1_ == -1 : return
	url = l1lll1l1111ll_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭斱"))
	return
def l1lll1l11ll_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ斲"),l11lll_l1_ (u"ࠩࠪ斳"),url,url)
	if l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ斴") in url: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳ู๊ไิๆࠪ斵")
	else: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴็๊ๅ็ࠪ斶")
	l11l11l_l1_ = QUOTE(l11l11l_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ斷"),l11lll_l1_ (u"ࠧࠨ斸"),l11lll_l1_ (u"ࠨࠩ方"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡋࡏࡌࡕࡇࡕࡗ࠲࠷ࡳࡵࠩ斺"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ斻"),l11lll_l1_ (u"ࠫࠬ於"),url,html)
	if type==1: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ施"),html,re.DOTALL)
	elif type==2: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ斾"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ斿"),block,re.DOTALL)
	if type==1:
		for l1lll1l111l11_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ旀"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭旁")+l1lll1l111l11_l1_,58)
	elif type==2:
		url,l1lll1l111l11_l1_ = url.split(l11lll_l1_ (u"ࠪࡃࠬ旂"))
		for l1ll111ll11l_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ旃"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ旄")+l1ll111ll11l_l1_+l11lll_l1_ (u"࠭ࠦࠨ旅")+l1lll1l111l11_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ旆"),l11lll_l1_ (u"ࠨࠩ旇"),search,search)
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠩࠣࠫ旈"),l11lll_l1_ (u"ࠪࠩ࠷࠶ࠧ旉"))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ旊"), l11ll1_l1_, l11lll_l1_ (u"ࠬ࠭旋"), l11lll_l1_ (u"࠭ࠧ旌"), True,l11lll_l1_ (u"ࠧࠨ旍"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ旎"))
	#html = response.content
	#cookies = response.cookies
	#l11ll11l1_l1_ = cookies[l11lll_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࠪ族")]
	#l1lll1l111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡧࡸࡸࡦࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪ旐"),html,re.DOTALL)
	#l1lll1l111ll1_l1_ = l1lll1l111ll1_l1_[0]
	#payload = l11lll_l1_ (u"ࠫࡤࡩࡳࡳࡨࡀࠫ旑") + l1lll1l111ll1_l1_ + l11lll_l1_ (u"ࠬࠬࡱ࠾ࠩ旒") + QUOTE(l111l1l_l1_)
	#headers = { l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ旓"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭旔") , l11lll_l1_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨ旕"):l11lll_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡀࠫ旖")+l11ll11l1_l1_ }
	#url = l11ll1_l1_ + l11lll_l1_ (u"ࠥ࠳ࡸ࡫ࡡࡳࡥ࡫ࠦ旗")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ旘"), url, payload, headers, True,l11lll_l1_ (u"ࠬ࠭旙"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ旚"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ旛")+l111l1l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ旜"),url,l11lll_l1_ (u"ࠩࠪ旝"),l11lll_l1_ (u"ࠪࠫ旞"),True,l11lll_l1_ (u"ࠫࠬ旟"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠳ࡰࡧࠫ无"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡧࡦࡰࡨࡶࡦࡲ࠭ࡣࡱࡧࡽ࠭࠴ࠪࡀࠫࡶࡩࡦࡸࡣࡩ࠯ࡥࡳࡹࡺ࡯࡮࠯ࡳࡥࡩࡪࡩ࡯ࡩࠪ旡"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ既"),block,re.DOTALL)
	if items:
		for link,l1llll_l1_,title in items:
			#title = title.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭旣")).encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ旤"))
			url = l11ll1_l1_ + link
			if l11lll_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭日") in url:
				if l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ旦") in url:
					title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ旧")+title
					url = url.replace(l11lll_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ旨"),l11lll_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭早"))
					url = url+l11lll_l1_ (u"ࠨ࠿ࠪ旪")+QUOTE(title)+l11lll_l1_ (u"ࠩࡀࠫ旫")+l1llll_l1_
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ旬"),l111ll_l1_+title,url,52,l1llll_l1_)
				else:
					title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ旭")+title
					addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ旮"),l111ll_l1_+title,url,53,l1llll_l1_)
	#else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ旯"),l11lll_l1_ (u"ࠧࠨ旰"),l11lll_l1_ (u"ࠨࡰࡲࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬ旱"),l11lll_l1_ (u"ࠩ็หࠥะ่อั๊ࠣฯอฦอࠢ็่อำหࠨ旲"))
	return
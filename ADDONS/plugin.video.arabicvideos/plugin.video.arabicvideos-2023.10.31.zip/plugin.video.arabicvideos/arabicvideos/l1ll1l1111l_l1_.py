# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࠪ〹")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡇࡍࡕࡢࠫ〺")
def MAIN(mode,url,text,l1l11l1_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1l1ll11l1l_l1_(text)
	elif mode==542: results = l1l1l1ll11l_l1_(text,url,l1l11l1_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭〻"),l11lll_l1_ (u"ࠧษฯฮࠤัี๊ะࠩ〼"),l11lll_l1_ (u"ࠨࠩ〽"),549)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ〾"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࠣ็้๋วห่ࠢาื์ษࠡ࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〿"),l11lll_l1_ (u"ࠫࠬ぀"),9999)
	l1l1ll11111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪぁ"),l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫあ"))
	if l1l1ll11111_l1_:
		l1l1ll11111_l1_ = l1l1ll11111_l1_[l11lll_l1_ (u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨぃ")]
		for search in reversed(l1l1ll11111_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨい"),search,l11lll_l1_ (u"ࠩࠪぅ"),549,l11lll_l1_ (u"ࠪࠫう"),l11lll_l1_ (u"ࠫࠬぇ"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1ll1_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1ll1l11ll1_l1_ = search.replace(l111ll_l1_,l11lll_l1_ (u"ࠬ࠭え"))
	l1l1l1l111l_l1_(l1ll1l11ll1_l1_)
	#l1l1l11ll11_l1_ = search+options+l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪぉ")
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬお"),l11lll_l1_ (u"ࠨ฻่่ࠥฮอฬࠢฯ้ฬ฿๊ࠡ࠯ࠣࠫか")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨが"),542,l11lll_l1_ (u"ࠪࠫき"),l11lll_l1_ (u"ࠫࠬぎ"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪく"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫぐ"),l11lll_l1_ (u"ࠧࠨけ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨげ"),l11lll_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆใุ่ฮࠦ࠭ࠡࠩこ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩご"),542,l11lll_l1_ (u"ࠫࠬさ"),l11lll_l1_ (u"ࠬ࠭ざ"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭し"),l11lll_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥโิ็ฬࠤ࠲ࠦࠧじ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧす"),542,l11lll_l1_ (u"ࠩࠪず"),l11lll_l1_ (u"ࠪࠫせ"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫぜ"),l11lll_l1_ (u"ࠬฮอฬ่๊ࠢๆืฯࠡ࠯ࠣࠫそ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧぞ"),541,l11lll_l1_ (u"ࠧࠨた"),l11lll_l1_ (u"ࠨࠩだ"),l1ll1l11ll1_l1_)
	return
def l1l1l1l111l_l1_(l1l1ll1l1l1_l1_):
	l1l1ll1ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧち"),l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨぢ"),l1l1ll1l1l1_l1_)
	l1l1ll1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩっ"),l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪつ"),l111ll_l1_+l1l1ll1l1l1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫづ"),l1l1ll1l1l1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬて"),l111ll_l1_+l1l1ll1l1l1_l1_)
	old_value = l1l1ll1ll11_l1_+l1l1ll1l1ll_l1_
	if old_value: l1l1ll1l1l1_l1_ = l111ll_l1_+l1l1ll1l1l1_l1_
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭で"),l1l1ll1l1l1_l1_,old_value,VERYLONG_CACHE)
	return
def l1l1l1l1l1l_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪと"),l11lll_l1_ (u"ࠪࠫど"),l11lll_l1_ (u"ࠫࠬな"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨに"),l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪぬ"))
	if l1ll111ll1_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬね"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧの"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨは"))
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫば"),l11lll_l1_ (u"ࠫࠬぱ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨひ"),l11lll_l1_ (u"࠭สๆࠢห๊ัออࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠧび"))
	return
def l1l1l1ll11l_l1_(l1l1l1l1ll1_l1_,action,l1l1l1ll1ll_l1_=l11lll_l1_ (u"ࠧࠨぴ")):
	l1l1l1lll11_l1_,l1l1l1lll1l_l1_,l1l1ll111l1_l1_,l1l1l11l1l1_l1_,l1l1l11ll1l_l1_,l1l1ll1111l_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧふ"):
		if action==l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨぶ"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨぷ"),l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩへ"),l111ll_l1_+l1l1l1l1ll1_l1_)
		elif action==l11lll_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫべ"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫぺ"),l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭ほ"),l1l1l1l1ll1_l1_)
		elif action==l11lll_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧぼ"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧぽ"),l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩま"),(l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_))
	if not l1l1ll111l1_l1_:
		l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠫ์ึวࠡษ็ฬาัࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰ࡟ࡲࠬみ")
		l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤฬ๊ศฮอࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥ฿ๆࠡ࡞ࡱࠤࠧࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡࠩむ")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠣࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊ศฮอࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠨめ")
		if action==l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭も"): message = l1l1ll11lll_l1_
		else: message = l1l1ll11ll1_l1_+l1l1ll11lll_l1_
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩゃ"),l11lll_l1_ (u"ࠩࠪや"),l11lll_l1_ (u"ࠪࠫゅ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧゆ"),message)
		if l1ll111ll1_l1_!=1: return
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬょ"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪよ")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪら"))
		#global menuItemsLIST
		import threading
		#l1l1l1lllll_l1_ = [l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧり"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫる"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫれ")]
		l1l1lll111l_l1_ = 1
		for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
			l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_] = []
			options = l11lll_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩろ")
			if l11lll_l1_ (u"ࠬ࠳ࠧゎ") in l1l1l1ll1ll_l1_: options = options+l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࠫわ")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠧࡠࠩゐ")
			l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
			if l1l1lll111l_l1_:
				time.sleep(0.5)
				threads[l1l1l1ll1ll_l1_] = threading.Thread(target=l1l1l1ll1l1_l1_,args=(l1l1l1l1ll1_l1_+options,))
				threads[l1l1l1ll1ll_l1_].start()
			else: l1l1l1ll1l1_l1_(l1l1l1l1ll1_l1_+options)
			DIALOG_NOTIFICATION(TRANSLATE(l1l1l1ll1ll_l1_),l11lll_l1_ (u"ࠨࠩゑ"),time=1000)
		if l1l1lll111l_l1_:
			time.sleep(2)
			for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
				threads[l1l1l1ll1ll_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪを"),l11lll_l1_ (u"ࠪࠫん"),l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠣࡪࡴࡻ࡮ࡥࡧࡧ࠾ࠬゔ"),str(len(menuItemsLIST)))
		for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
			l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
			for l1l1l1ll111_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
				if l1l1lll1111_l1_ in name:
					if l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࠫゕ") in l1l1l1ll1ll_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩゖ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ゗")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭゘")]: continue
						if l11lll_l1_ (u"ุࠩๅาฯ゙ࠧ") not in name:
							if   type==l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ゚"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ゛")
							elif type==l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ゜"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫゝ")
							elif type==l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧゞ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭ゟ")
						else:
							if   l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ゠") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭ァ")
							elif l11lll_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫア") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪィ")
							elif l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭イ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬゥ")
					elif l11lll_l1_ (u"ࠨࡏ࠶࡙࠲࠭ウ") in l1l1l1ll1ll_l1_ and 729>=mode>=710:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫェ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧエ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨォ")]: continue
						if l11lll_l1_ (u"ࠬ฻แฮหࠪオ") not in name:
							if   type==l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫカ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩガ")
							elif type==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧキ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭ギ")
							elif type==l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪク"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨグ")
						else:
							if   l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪケ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨゲ")
							elif l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧコ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬゴ")
							elif l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩサ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧザ")
					elif l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࠭シ") in l1l1l1ll1ll_l1_ and 149>=mode>=140:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨジ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪス")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨズ")]: continue
						if l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫセ") in name or l11lll_l1_ (u"ࠩ࠽࠾ࠥ࠭ゼ") in name:
							continue
							#if   l11l_l1_==l11lll_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬソ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧゾ")
							#elif l11l_l1_==l11lll_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨタ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪダ")
							#else: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨチ")
						else:
							if   mode==144 and l11lll_l1_ (u"ࠨࡗࡖࡉࡗ࠭ヂ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬッ")
							elif mode==144 and l11lll_l1_ (u"ࠪࡇࡍࡔࡌࠨツ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧヅ")
							elif mode==144 and l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪテ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪデ")
							elif mode==143: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨト")
							else: continue
					elif l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࠧド") in l1l1l1ll1ll_l1_ and 419>=mode>=400:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪナ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪニ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩヌ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪネ")]: continue
						if   mode in [401,405]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧノ")
						elif mode in [402,406]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧハ")
						elif mode in [403,404]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭バ")
						elif mode in [412,413]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧパ")
					elif l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࠪヒ") in l1l1l1ll1ll_l1_ and 39>=mode>=30:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪビ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫピ")]: continue
						if   mode in [32,39]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬフ")
						elif mode in [33,39]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭ブ")
					elif l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࠨプ") in l1l1l1ll1ll_l1_ and 29>=mode>=20:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨヘ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪベ")]: continue
						if   l11lll_l1_ (u"ࠫ࠴ࡧࡲ࠯ࠩペ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫホ")
						elif l11lll_l1_ (u"࠭࠯ࡦࡰ࠱ࠫボ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧポ")
					#elif l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࠬマ") in l1l1l1ll1ll_l1_ and 319>=mode>=310:
					#	if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_]: continue
					#	if mode==312: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠩ࠰ࡅ࡚ࡊࡉࡐࡕࠪミ")
					#	elif l11lll_l1_ (u"ࠪ࠳ࡨࡧࡴ࠮ࠩム") in url: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠫ࠲ࡇࡌࡃࡗࡐࡗࠬメ")
					#	else: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠬ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧモ")
					l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
		menuItemsLIST[:] = []
		for l1l1l1ll1ll_l1_ in list(l1l1l11l1l1_l1_.keys()):
			l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_] = []
			l1l1ll1111l_l1_[l1l1l1ll1ll_l1_] = []
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_]:
				l1l1l1ll111_l1_ = (type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
				if l11lll_l1_ (u"࠭ีโฯฬࠫャ") in name and type==l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧヤ"): l1l1ll1111l_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
				else: l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
		l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ュ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬユ"),l11lll_l1_ (u"ࠪࠫョ"),157,l11lll_l1_ (u"ࠫࠬヨ"),l11lll_l1_ (u"ࠬ࠭ラ"),l11lll_l1_ (u"࠭ࠧリ"),l11lll_l1_ (u"ࠧࠨル"),l11lll_l1_ (u"ࠨࠩレ"))]
		for l1l1l1ll1ll_l1_ in l1l1l1llll1_l1_:
			if l1l1l1ll1ll_l1_==l1l1l1l1l11_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧロ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬヮ"),l11lll_l1_ (u"ࠫࠬワ"),157,l11lll_l1_ (u"ࠬ࠭ヰ"),l11lll_l1_ (u"࠭ࠧヱ"),l11lll_l1_ (u"ࠧࠨヲ"),l11lll_l1_ (u"ࠨࠩン"),l11lll_l1_ (u"ࠩࠪヴ"))]
			elif l1l1l1ll1ll_l1_==l1l1ll1ll1l_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨヵ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧヶ"),l11lll_l1_ (u"ࠬ࠭ヷ"),157,l11lll_l1_ (u"࠭ࠧヸ"),l11lll_l1_ (u"ࠧࠨヹ"),l11lll_l1_ (u"ࠨࠩヺ"),l11lll_l1_ (u"ࠩࠪ・"),l11lll_l1_ (u"ࠪࠫー"))]
			elif l1l1l1ll1ll_l1_==l1l1l11l1ll_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩヽ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨヾ"),l11lll_l1_ (u"࠭ࠧヿ"),157,l11lll_l1_ (u"ࠧࠨ㄀"),l11lll_l1_ (u"ࠨࠩ㄁"),l11lll_l1_ (u"ࠩࠪ㄂"),l11lll_l1_ (u"ࠪࠫ㄃"),l11lll_l1_ (u"ࠫࠬ㄄"))]
			if l1l1l1ll1ll_l1_ not in l1l1l11ll1l_l1_.keys(): continue
			if l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_]:
				l1l1l1l1111_l1_ = TRANSLATE(l1l1l1ll1ll_l1_)
				l1l1l1l1lll_l1_ = [(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪㄅ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞࠿ࡀࡁࡂࡃࠠࠨㄆ")+l1l1l1l1111_l1_+l11lll_l1_ (u"ࠧࠡ࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨㄇ"),l11lll_l1_ (u"ࠨࠩㄈ"),9999,l11lll_l1_ (u"ࠩࠪㄉ"),l11lll_l1_ (u"ࠪࠫㄊ"),l11lll_l1_ (u"ࠫࠬㄋ"),l11lll_l1_ (u"ࠬ࠭ㄌ"),l11lll_l1_ (u"࠭ࠧㄍ"))]
				if 0:
					l1l1ll1lll1_l1_ = l1l1l1l1ll1_l1_+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫㄎ")+l11lll_l1_ (u"ࠨสะฯࠬㄏ")+l11lll_l1_ (u"ࠩࠣࠫㄐ")+l1l1l1l1111_l1_
				else:
					l1l1ll1lll1_l1_ = l11lll_l1_ (u"ࠪฬาัࠧㄑ")+l11lll_l1_ (u"ࠫࠥ࠭ㄒ")+l1l1l1l1111_l1_+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩㄓ")+l1l1l1l1ll1_l1_
				if len(l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_])<8: l1l1ll111ll_l1_ = []
				else:
					l1l1ll1llll_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩㄔ")+l1l1ll1lll1_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩㄕ")
					l1l1ll111ll_l1_ = [(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄖ"),l111ll_l1_+l1l1ll1llll_l1_,l11lll_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨㄗ"),542,l11lll_l1_ (u"ࠪࠫㄘ"),l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠫࠬㄙ"),l11lll_l1_ (u"ࠬ࠭ㄚ"))]
				l1l1ll1l111_l1_ = l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_]+l1l1ll1111l_l1_[l1l1l1ll1ll_l1_]
				l1l1l1lll1l_l1_ += l1l1ll11l11_l1_+l1l1l1l1lll_l1_+l1l1ll1l111_l1_[:7]+l1l1ll111ll_l1_
				l1l1l11llll_l1_ = [(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄛ"),l111ll_l1_+l1l1ll1lll1_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ㄜ"),542,l11lll_l1_ (u"ࠨࠩㄝ"),l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠩࠪㄞ"),l11lll_l1_ (u"ࠪࠫㄟ"))]
				l1l1l1lll11_l1_ += l1l1ll11l11_l1_+l1l1l11llll_l1_
				l1l1ll11l11_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪㄠ"),(l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_),l1l1ll1l111_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫㄡ"),l1l1l1l1ll1_l1_,l1l1l1lll1l_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫㄢ"),l1l1l1l1ll1_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬㄣ"),l111ll_l1_+l1l1l1l1ll1_l1_,l1l1l1lll11_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩㄤ"),l11lll_l1_ (u"ࠩࠪㄥ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ㄦ"),l11lll_l1_ (u"ࠫฬ๊ศฮอࠣห้าๅศ฻ํࠤฬ์ส่๋ࠣฬ๋าวฮࠢ࡟ࡲࡡࡴࠠห็ࠣฮำุ๊็ࠢส่๋ะววฮࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะ๊ࠥๅะหࠣฯ้อห๋่ࠣ๎ํ๋ࠠๅๅํࠤฯูสุ์฼ࠤฬู๊้ัฬࠤส๊๊่ษࠣฬิ๎ๆࠡ฻่่ࠥฮอฬࠢฯำ๏ีࠧㄧ"))
		if action==l11lll_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫㄨ") and l1l1l1lll11_l1_: l1l1ll111l1_l1_ = l1l1l1lll11_l1_
		else: l1l1ll111l1_l1_ = l1l1l1lll1l_l1_
	if action!=l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬㄩ"):
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1l1ll111l1_l1_:
			if action in [l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ㄪ"),l11lll_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧㄫ")] and l11lll_l1_ (u"ุࠩๅาฯࠧㄬ") in name and type==l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄭ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
	return
def l1l1ll11l1l_l1_(l1l1l1l1ll1_l1_=l11lll_l1_ (u"ࠫࠬㄮ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1ll1_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬㄯ"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪ㄰")+search+l11lll_l1_ (u"ࠧࠡ࡟ࠪㄱ"))
	l111l1l_l1_ = search+options
	if 0:
		l1l1ll1l11l_l1_,l1ll1l11ll1_l1_ = search+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬㄲ"),l11lll_l1_ (u"ࠩࠪㄳ")
	else:
		l1l1ll1l11l_l1_,l1ll1l11ll1_l1_ = l11lll_l1_ (u"ࠪࠫㄴ"),l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨㄵ")+search
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪㄶ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩㄷ"),l11lll_l1_ (u"ࠧࠨㄸ"),157)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄹ"),l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨㄺ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠࡎ࠵ࡘࠫㄻ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬㄼ"),719,l11lll_l1_ (u"ࠬ࠭ㄽ"),l11lll_l1_ (u"࠭ࠧㄾ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄿ"),l11lll_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧㅀ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦࡉࡑࡖ࡙ࠫㅁ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫㅂ"),239,l11lll_l1_ (u"ࠫࠬㅃ"),l11lll_l1_ (u"ࠬ࠭ㅄ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅅ"),l11lll_l1_ (u"ࠧࡠࡄࡎࡖࡤ࠭ㅆ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬ่ืวࠨㅇ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪㅈ"),379,l11lll_l1_ (u"ࠪࠫㅉ"),l11lll_l1_ (u"ࠫࠬㅊ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅋ"),l11lll_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬㅌ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหห๋๐สࠨㅍ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩㅎ"),39,l11lll_l1_ (u"ࠩࠪㅏ"),l11lll_l1_ (u"ࠪࠫㅐ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅑ"),l11lll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫㅒ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠศใ็ห๊࠭ㅓ"),l11lll_l1_ (u"ࠧࠨㅔ"),39,l11lll_l1_ (u"ࠨࠩㅕ"),l11lll_l1_ (u"ࠩࠪㅖ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨㅗ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅘ"),l11lll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫㅙ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨㅚ"),l11lll_l1_ (u"ࠧࠨㅛ"),39,l11lll_l1_ (u"ࠨࠩㅜ"),l11lll_l1_ (u"ࠩࠪㅝ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙࡟ࠨㅞ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅟ"),l11lll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫㅠ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪㅡ"),l11lll_l1_ (u"ࠧࠨㅢ"),149,l11lll_l1_ (u"ࠨࠩㅣ"),l11lll_l1_ (u"ࠩࠪㅤ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪㅥ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅦ"),l11lll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫㅧ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧㅨ"),l11lll_l1_ (u"ࠧࠨㅩ"),149,l11lll_l1_ (u"ࠨࠩㅪ"),l11lll_l1_ (u"ࠩࠪㅫ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭ㅬ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅭ"),l11lll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫㅮ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧㅯ"),l11lll_l1_ (u"ࠧࠨㅰ"),149,l11lll_l1_ (u"ࠨࠩㅱ"),l11lll_l1_ (u"ࠩࠪㅲ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬㅳ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅴ"),l11lll_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫㅵ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪㅶ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨㅷ"),19,l11lll_l1_ (u"ࠨࠩㅸ"),l11lll_l1_ (u"ࠩࠪㅹ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅺ"),l11lll_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪㅻ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫㅼ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧㅽ"),739,l11lll_l1_ (u"ࠧࠨㅾ"),l11lll_l1_ (u"ࠨࠩㅿ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆀ"),l11lll_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩㆁ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫㆂ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭ㆃ"),329,l11lll_l1_ (u"࠭ࠧㆄ"),l11lll_l1_ (u"ࠧࠨㆅ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㆆ"),l11lll_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨㆇ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩㆈ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬㆉ"),579,l11lll_l1_ (u"ࠬ࠭ㆊ"),l11lll_l1_ (u"࠭ࠧㆋ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆌ"),l11lll_l1_ (u"ࠨࡡࡈࡋࡇࡥࠧㆍ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧㆎ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㆏"),129,l11lll_l1_ (u"ࠫࠬ㆐"),l11lll_l1_ (u"ࠬ࠭㆑"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㆒"),l11lll_l1_ (u"ࠧࡠࡇࡅ࠵ࡤ࠭㆓")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨ㆔")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㆕"),779,l11lll_l1_ (u"ࠪࠫ㆖"),l11lll_l1_ (u"ࠫࠬ㆗"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㆘"),l11lll_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬ㆙")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧ㆚")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㆛"),789,l11lll_l1_ (u"ࠩࠪ㆜"),l11lll_l1_ (u"ࠪࠫ㆝"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㆞"),l11lll_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫ㆟")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ㆠ"),l11lll_l1_ (u"ࠧࠨㆡ"),409,l11lll_l1_ (u"ࠨࠩㆢ"),l11lll_l1_ (u"ࠩࠪㆣ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘࡥࠧㆤ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆥ"),l11lll_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫㆦ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪㆧ"),l11lll_l1_ (u"ࠧࠨㆨ"),409,l11lll_l1_ (u"ࠨࠩㆩ"),l11lll_l1_ (u"ࠩࠪㆪ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪㆫ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆬ"),l11lll_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫㆭ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪㆮ"),l11lll_l1_ (u"ࠧࠨㆯ"),409,l11lll_l1_ (u"ࠨࠩㆰ"),l11lll_l1_ (u"ࠩࠪㆱ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩㆲ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆳ"),l11lll_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫㆴ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩㆵ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠧࠡࠢࠪㆶ"),l11lll_l1_ (u"ࠨࠩㆷ"),29,l11lll_l1_ (u"ࠩࠪㆸ"),l11lll_l1_ (u"ࠪࠫㆹ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆺ"),l11lll_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫㆻ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬㆼ"),l11lll_l1_ (u"ࠧࠨㆽ"),29,l11lll_l1_ (u"ࠨࠩㆾ"),l11lll_l1_ (u"ࠩࠪㆿ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉ࡟ࠨ㇀"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㇁"),l11lll_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㇂")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨ㇃"),l11lll_l1_ (u"ࠧࠨ㇄"),29,l11lll_l1_ (u"ࠨࠩ㇅"),l11lll_l1_ (u"ࠩࠪ㇆"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࡠࠩ㇇"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㇈"),l11lll_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫ㇉")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ㇊")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㇋"),79,l11lll_l1_ (u"ࠨࠩ㇌"),l11lll_l1_ (u"ࠩࠪ㇍"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㇎"),l11lll_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪ㇏")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭㇐")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㇑"),249,l11lll_l1_ (u"ࠧࠨ㇒"),l11lll_l1_ (u"ࠨࠩ㇓"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇔"),l11lll_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩ㇕")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬ㇖"),l11lll_l1_ (u"ࠬ࠭㇗"),49,l11lll_l1_ (u"࠭ࠧ㇘"),l11lll_l1_ (u"ࠧࠨ㇙"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇚"),l11lll_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ㇛")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧ㇜")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㇝"),59,l11lll_l1_ (u"ࠬ࠭㇞"),l11lll_l1_ (u"࠭ࠧ㇟"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇠"),l11lll_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧ㇡")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ㇢")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㇣"),69,l11lll_l1_ (u"ࠫࠬ㇤"),l11lll_l1_ (u"ࠬ࠭㇥"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㇦"),l11lll_l1_ (u"ࠧࡠࡍ࡚ࡘࡤ࠭㇧")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็็ํััࠨ㇨"),l11lll_l1_ (u"ࠩࠪ㇩"),139,l11lll_l1_ (u"ࠪࠫ㇪"),l11lll_l1_ (u"ࠫࠬ㇫"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㇬"),l11lll_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬ㇭")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭㇮"),l11lll_l1_ (u"ࠨࠩ㇯"),319,l11lll_l1_ (u"ࠩࠪㇰ"),l11lll_l1_ (u"ࠪࠫㇱ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㇲ"),l11lll_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫㇳ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪㇴ"),l11lll_l1_ (u"ࠧࠨㇵ"),319,l11lll_l1_ (u"ࠨࠩㇶ"),l11lll_l1_ (u"ࠩࠪㇷ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࡤ࠭ㇸ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㇹ"),l11lll_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫㇺ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อ๋ࠥฬๅัࠪㇻ"),l11lll_l1_ (u"ࠧࠨㇼ"),319,l11lll_l1_ (u"ࠨࠩㇽ"),l11lll_l1_ (u"ࠩࠪㇾ"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬㇿ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㈀"),l11lll_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ㈁")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬ㈂"),l11lll_l1_ (u"ࠧࠨ㈃"),319,l11lll_l1_ (u"ࠨࠩ㈄"),l11lll_l1_ (u"ࠩࠪ㈅"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬ㈆"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㈇"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㈈"),l11lll_l1_ (u"࠭ࠧ㈉"),157)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈊"),l11lll_l1_ (u"ࠨࡡࡎࡘࡐࡥࠧ㈋")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠪ㈌")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㈍"),679,l11lll_l1_ (u"ࠫࠬ㈎"),l11lll_l1_ (u"ࠬ࠭㈏"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈐"),l11lll_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭㈑")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨࠢหัะࠦๅ้ไ฼ࠤๆาัࠡึ๋ࠫ㈒")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠩࠣࠫ㈓"),l11lll_l1_ (u"ࠪࠫ㈔"),399,l11lll_l1_ (u"ࠫࠬ㈕"),l11lll_l1_ (u"ࠬ࠭㈖"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈗"),l11lll_l1_ (u"ࠧࡠࡖ࡙ࡊࡤ࠭㈘")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬ㈙")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㈚"),469,l11lll_l1_ (u"ࠪࠫ㈛"),l11lll_l1_ (u"ࠫࠬ㈜"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㈝"),l11lll_l1_ (u"࠭࡟ࡍࡆࡑࡣࠬ㈞")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ็์ิ๐ࠠ็ฬࠪ㈟")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㈠"),459,l11lll_l1_ (u"ࠩࠪ㈡"),l11lll_l1_ (u"ࠪࠫ㈢"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㈣"),l11lll_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫ㈤")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦๆศ๊ࠪ㈥")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㈦"),309,l11lll_l1_ (u"ࠨࠩ㈧"),l11lll_l1_ (u"ࠩࠪ㈨"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㈩"),l11lll_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ㈪")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿้ࠠ์ࠣื๏๋วࠨ㈫")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㈬"),569,l11lll_l1_ (u"ࠧࠨ㈭"),l11lll_l1_ (u"ࠨࠩ㈮"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈯"),l11lll_l1_ (u"ࠪࡣࡘࡎࡎࡠࠩ㈰")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩ㈱")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㈲"),589,l11lll_l1_ (u"࠭ࠧ㈳"),l11lll_l1_ (u"ࠧࠨ㈴"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㈵"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈶"),l11lll_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩ㈷")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨ㈸")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㈹"),369,l11lll_l1_ (u"࠭ࠧ㈺"),l11lll_l1_ (u"ࠧࠨ㈻"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈼"),l11lll_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨ㈽")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭㈾")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㈿"),489,l11lll_l1_ (u"ࠬ࠭㉀"),l11lll_l1_ (u"࠭ࠧ㉁"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉂"),l11lll_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧ㉃")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭㉄")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㉅"),259,l11lll_l1_ (u"ࠫࠬ㉆"),l11lll_l1_ (u"ࠬ࠭㉇"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㉈"),l11lll_l1_ (u"ࠧࡠࡅࡐࡇࡤ࠭㉉")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๅ็หอ࠭㉊"),l11lll_l1_ (u"ࠩࠪ㉋"),639,l11lll_l1_ (u"ࠪࠫ㉌"),l11lll_l1_ (u"ࠫࠬ㉍"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㉎"),l11lll_l1_ (u"࠭࡟ࡄ࠶ࡘࡣࠬ㉏")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㉐")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㉑"),429,l11lll_l1_ (u"ࠩࠪ㉒"),l11lll_l1_ (u"ࠪࠫ㉓"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㉔"),l11lll_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ㉕")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦแ้ำํ์ࠬ㉖")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㉗"),119,l11lll_l1_ (u"ࠨࠩ㉘"),l11lll_l1_ (u"ࠩࠪ㉙"),l111l1l_l1_+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㉚"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㉛"),l11lll_l1_ (u"ࠬࡥࡅࡃ࠵ࡢࠫ㉜")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭㉝")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㉞"),799,l11lll_l1_ (u"ࠨࠩ㉟"),l11lll_l1_ (u"ࠩࠪ㉠"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㉡"),l11lll_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ㉢")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ㉣"),l11lll_l1_ (u"࠭ࠧ㉤"),389,l11lll_l1_ (u"ࠧࠨ㉥"),l11lll_l1_ (u"ࠨࠩ㉦"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉧"),l11lll_l1_ (u"ࠪࡣࡊࡍࡖࡠࠩ㉨")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦล๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭㉩"),l11lll_l1_ (u"ࠬ࠭㉪"),229,l11lll_l1_ (u"࠭ࠧ㉫"),l11lll_l1_ (u"ࠧࠨ㉬"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㉭"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㉮"),l11lll_l1_ (u"ࠪࠫ㉯"),157)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㉰"),l11lll_l1_ (u"ࠬࡥࡌࡓ࡜ࡢࠫ㉱")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๆสีํุวࠨ㉲")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㉳"),709,l11lll_l1_ (u"ࠨࠩ㉴"),l11lll_l1_ (u"ࠩࠪ㉵"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㉶"),l11lll_l1_ (u"ࠫࡤࡌࡓࡕࡡࠪ㉷")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโ๊ึฮฬ࠭㉸")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㉹"),609,l11lll_l1_ (u"ࠧࠨ㉺"),l11lll_l1_ (u"ࠨࠩ㉻"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉼"),l11lll_l1_ (u"ࠪࡣࡋࡈࡋࡠࠩ㉽")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแษำๆอࠬ㉾")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㉿"),629,l11lll_l1_ (u"࠭ࠧ㊀"),l11lll_l1_ (u"ࠧࠨ㊁"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊂"),l11lll_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨ㊃")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐วใ๊อࠫ㊄")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㊅"),669,l11lll_l1_ (u"ࠬ࠭㊆"),l11lll_l1_ (u"࠭ࠧ㊇"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊈"),l11lll_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧ㊉")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอืำห์ฯࠫ㊊")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㊋"),659,l11lll_l1_ (u"ࠫࠬ㊌"),l11lll_l1_ (u"ࠬ࠭㊍"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊎"),l11lll_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭㊏")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻๋้ࠣอࠠิ์่หࠬ㊐")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㊑"),89,l11lll_l1_ (u"ࠪࠫ㊒"),l11lll_l1_ (u"ࠫࠬ㊓"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㊔"),l11lll_l1_ (u"࠭࡟ࡅࡔ࠺ࡣࠬ㊕")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢาีฬ๋วࠡืะࠫ㊖")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㊗"),689,l11lll_l1_ (u"ࠩࠪ㊘"),l11lll_l1_ (u"ࠪࠫ㊙"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊚"),l11lll_l1_ (u"ࠬࡥࡃࡎࡈࡢࠫ㊛")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦแศ่ีࠫ㊜")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㊝"),99,l11lll_l1_ (u"ࠨࠩ㊞"),l11lll_l1_ (u"ࠩࠪ㊟"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㊠"),l11lll_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪ㊡")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㊢")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㊣"),479,l11lll_l1_ (u"ࠧࠨ㊤"),l11lll_l1_ (u"ࠨࠩ㊥"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㊦"),l11lll_l1_ (u"ࠪࡣࡆࡈࡄࡠࠩ㊧")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩ㊨")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㊩"),559,l11lll_l1_ (u"࠭ࠧ㊪"),l11lll_l1_ (u"ࠧࠨ㊫"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊬"),l11lll_l1_ (u"ࠩࡢࡇ࠹ࡎ࡟ࠨ㊭")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧ㊮")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㊯"),699,l11lll_l1_ (u"ࠬ࠭㊰"),l11lll_l1_ (u"࠭ࠧ㊱"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊲"),l11lll_l1_ (u"ࠨࡡࡄࡌࡐࡥࠧ㊳")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨ㊴")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㊵"),619,l11lll_l1_ (u"ࠫࠬ㊶"),l11lll_l1_ (u"ࠬ࠭㊷"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊸"),l11lll_l1_ (u"ࠧࡠࡅࡆࡆࡤ࠭㊹")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๅ็์อ࠭㊺")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㊻"),639,l11lll_l1_ (u"ࠪࠫ㊼"),l11lll_l1_ (u"ࠫࠬ㊽"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㊾"),l11lll_l1_ (u"࠭࡟ࡔࡊࡗࡣࠬ㊿")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆํวࠡฬํๅ๏࠭㋀")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㋁"),649,l11lll_l1_ (u"ࠩࠪ㋂"),l11lll_l1_ (u"ࠪࠫ㋃"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋄"),l11lll_l1_ (u"ࠬࡥࡅࡈࡐࡢࠫ㋅")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡวํะ๏ࠦๆศ๊ࠪ㋆")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㋇"),439,l11lll_l1_ (u"ࠨࠩ㋈"),l11lll_l1_ (u"ࠩࠪ㋉"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋊"),l11lll_l1_ (u"ࠫࡤࡌࡈ࠳ࡡࠪ㋋")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโษุ่ࠥอไฬษ้๎ࠬ㋌")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㋍"),599,l11lll_l1_ (u"ࠧࠨ㋎"),l11lll_l1_ (u"ࠨࠩ㋏"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋐"),l11lll_l1_ (u"ࠪࡣࡊࡈ࠴ࡠࠩ㋑")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫ㋒")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㋓"),809,l11lll_l1_ (u"࠭ࠧ㋔"),l11lll_l1_ (u"ࠧࠨ㋕"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋖"),l11lll_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨ㋗")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧ㋘"),l11lll_l1_ (u"ࠫࠬ㋙"),449,l11lll_l1_ (u"ࠬ࠭㋚"),l11lll_l1_ (u"࠭ࠧ㋛"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋜"),l11lll_l1_ (u"ࠨࡡࡄࡏࡈࡥࠧ㋝")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ้่ศ็ࠣ็ฬ๋ࠧ㋞"),l11lll_l1_ (u"ࠪࠫ㋟"),359,l11lll_l1_ (u"ࠫࠬ㋠"),l11lll_l1_ (u"ࠬ࠭㋡"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋢"),l11lll_l1_ (u"ࠧࡠࡃࡕࡐࡤ࠭㋣")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ฽ึฮࠠๅ์๋๊ื࠭㋤"),l11lll_l1_ (u"ࠩࠪ㋥"),209,l11lll_l1_ (u"ࠪࠫ㋦"),l11lll_l1_ (u"ࠫࠬ㋧"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋨"),l11lll_l1_ (u"࠭࡟ࡉࡇࡏࡣࠬ㋩")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๊่ࠢฬ๊๋๊ࠠอ๎ํฮࠧ㋪"),l11lll_l1_ (u"ࠨࠩ㋫"),99,l11lll_l1_ (u"ࠩࠪ㋬"),l11lll_l1_ (u"ࠪࠫ㋭"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋮"),l11lll_l1_ (u"ࠬࡥࡓࡇ࡙ࡢࠫ㋯")+search+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํี๏ูࠠโ๊ิࠤํะิࠨ㋰"),l11lll_l1_ (u"ࠧࠨ㋱"),218,l11lll_l1_ (u"ࠨࠩ㋲"),l11lll_l1_ (u"ࠩࠪ㋳"),search) # 219
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋴"),l11lll_l1_ (u"ࠫࡤࡓࡖ࡛ࡡࠪ㋵")+search+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๆ๊ไ๎ืࠦไศ่าࠫ㋶"),l11lll_l1_ (u"࠭ࠧ㋷"),188,l11lll_l1_ (u"ࠧࠨ㋸"),l11lll_l1_ (u"ࠨࠩ㋹"),search)# 189
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㋺"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㋻"),l11lll_l1_ (u"ࠫࠬ㋼"),157)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋽"),l11lll_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ㋾")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํ์ฯ๐่ษࠩ㋿")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㌀"),149,l11lll_l1_ (u"ࠩࠪ㌁"),l11lll_l1_ (u"ࠪࠫ㌂"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌃"),l11lll_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫ㌄")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ้ࠫ㌅")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㌆"),409,l11lll_l1_ (u"ࠨࠩ㌇"),l11lll_l1_ (u"ࠩࠪ㌈"),l111l1l_l1_)
	return
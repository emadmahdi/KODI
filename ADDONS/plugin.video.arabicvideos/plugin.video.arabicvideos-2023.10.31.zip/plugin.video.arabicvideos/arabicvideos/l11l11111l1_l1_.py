# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ梡")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪ梢")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ梣"),l11lll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ梤"),l11lll_l1_ (u"ࠧหีฯ๎้࠭梥"),l11lll_l1_ (u"ࠨฬึะ๏๊ࠠศๆาาํ๊ࠧ梦"),l11lll_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭梧")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l1111l_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l11111_l1_(url,text)
	elif mode==664: results = l1l11l_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ梨"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ梩"),l11lll_l1_ (u"ࠬ࠭梪"),l11lll_l1_ (u"࠭ࠧ梫"),l11lll_l1_ (u"ࠧࠨ梬"),l11lll_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ梭"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梮"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ梯"),l11lll_l1_ (u"ࠫࠬ械"),669,l11lll_l1_ (u"ࠬ࠭梱"),l11lll_l1_ (u"࠭ࠧ梲"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ梳"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭梴"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ梵"),l11lll_l1_ (u"ࠪࠫ梶"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ梷"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ梸")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ梹"),l11ll1_l1_,661,l11lll_l1_ (u"ࠧࠨ梺"),l11lll_l1_ (u"ࠨࠩ梻"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ梼"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ梽"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭梾")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ梿"),l11ll1_l1_,661,l11lll_l1_ (u"࠭ࠧ检"),l11lll_l1_ (u"ࠧࠨ棁"),l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ棂"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棃"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ棄")+l111ll_l1_+l11lll_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪ棅"),l11ll1_l1_,661,l11lll_l1_ (u"ࠬ࠭棆"),l11lll_l1_ (u"࠭ࠧ棇"),l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ棈"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ棉"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ棊")+l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧ棋"),l11ll1_l1_,661,l11lll_l1_ (u"ࠫࠬ棌"),l11lll_l1_ (u"ࠬ࠭棍"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ棎"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ棏"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ棐"),l11lll_l1_ (u"ࠩࠪ棑"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ棒"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ棓"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ棔"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ棕")+l111ll_l1_+title,link,664)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ棖"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ棗"),l11lll_l1_ (u"ࠩࠪ棘"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ棙"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ棚"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠬ࠭棛"))
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ棜"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠧ࠽ࡤࡁࠫ棝"),l11lll_l1_ (u"ࠨࠩ棞")).replace(l11lll_l1_ (u"ࠩ࠿࠳ࡧࡄࠧ棟"),l11lll_l1_ (u"ࠪࠫ棠")).replace(l11lll_l1_ (u"ࠫࡁࡨࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡵࡩࡹࠨ࠾ࠨ棡"),l11lll_l1_ (u"ࠬ࠭棢")).replace(l11lll_l1_ (u"࠭࠼ࡣࡀࠪ棣"),l11lll_l1_ (u"ࠧࠨ棤")).strip(l11lll_l1_ (u"ࠨࠢࠪ棥"))
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棦"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ棧")+l111ll_l1_+title,link,664)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ棨"),url,l11lll_l1_ (u"ࠬ࠭棩"),l11lll_l1_ (u"࠭ࠧ棪"),l11lll_l1_ (u"ࠧࠨ棫"),l11lll_l1_ (u"ࠨࠩ棬"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭棭"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ森"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ棯"),l11lll_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ棰"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ棱"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠧࠨ棲"),block)]
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭棳"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ棴"),l11lll_l1_ (u"ࠪࠫ棵"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ棶"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠬࡀࠠࠨ棷")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棸"),l111ll_l1_+title,link,661)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ棹"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ棺"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ棻"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ棼"),l11lll_l1_ (u"ࠫࠬ棽"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ棾"),l111ll_l1_+title,link,661)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"࠭ࠧ棿")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ椀"),l11lll_l1_ (u"ࠨࠩ椁"),request,url)
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ椂"):
		url,search = url.split(l11lll_l1_ (u"ࠪࡃࠬ椃"),1)
		data = l11lll_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ椄")+search
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ椅"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭椆")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ椇"),url,data,headers,l11lll_l1_ (u"ࠨࠩ椈"),l11lll_l1_ (u"ࠩࠪ椉"),l11lll_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭椊"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ椋"),url,l11lll_l1_ (u"ࠬ࠭椌"),l11lll_l1_ (u"࠭ࠧ植"),l11lll_l1_ (u"ࠧࠨ椎"),l11lll_l1_ (u"ࠨࠩ椏"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ椐"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠪࠫ椑"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ椒"))
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ椓"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ椔"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨ椕"),link,title))
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ椖"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ椗"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ椘"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ椙"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ椚"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭椛"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ検"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ椝"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ椞"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ椟"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ椠"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭椡"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"࠭ๅีษ๊ำฮ࠭椢"),l11lll_l1_ (u"ࠧโ์็้ࠬ椣"),l11lll_l1_ (u"ࠨษ฽๊๏ฯࠧ椤"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ椥"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ椦"),l11lll_l1_ (u"ࠫ์ีวโࠩ椧"),l11lll_l1_ (u"๋ࠬศศำสอࠬ椨"),l11lll_l1_ (u"ู࠭าุࠪ椩"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ椪"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ椫"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ椬")]
	for l1llll_l1_,link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠥ࠭椭"),l11lll_l1_ (u"ࠫࠬ椮")).replace(l11lll_l1_ (u"ࠬอ่็ๆส๎๋ࠦࠧ椯"),l11lll_l1_ (u"࠭ࠧ椰")).replace(l11lll_l1_ (u"ࠧๆึส๋ิฯࠠࠨ椱"),l11lll_l1_ (u"ࠨࠩ椲"))
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ椳"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ椴") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭椵")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ椶"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ椷") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ椸")+l1llll_l1_.strip(l11lll_l1_ (u"ࠨ࠱ࠪ椹"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ椺"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭椻"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ椼"),l111ll_l1_+title,link,662,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ椽"):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ椾"),l111ll_l1_+title,link,662,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭椿") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ楀"),l111ll_l1_+title,link,663,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ楁") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楂"),l111ll_l1_+title,link,661,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ楃"),l111ll_l1_+title,link,663,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ楄"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ楅")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ楆"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭楇"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠩࠦࠫ楈"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ楉")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭楊"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ楋"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ楌")+title,link,661)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ楍"),l11lll_l1_ (u"ࠨࠩ楎"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭楏"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ楐"),url,l11lll_l1_ (u"ࠫࠬ楑"),l11lll_l1_ (u"ࠬ࠭楒"),l11lll_l1_ (u"࠭ࠧ楓"),l11lll_l1_ (u"ࠧࠨ楔"),l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ楕"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ楖"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ楗"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠫࠬ楘")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ楙"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"࠭ࠣࠨ楚"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ楛"),l111ll_l1_+title,url,663,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ楜"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ楝")+l1ll1_l1_+l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ楞"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ楟"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ楠"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ楡")+link.strip(l11lll_l1_ (u"ࠧ࠯࠱ࠪ楢"))
			title = title.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡩࡲࡄ࠼ࡴࡲࡤࡲࡃ࠭楣"),l11lll_l1_ (u"ࠩࠣࠫ楤"))
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ楥"),l111ll_l1_+title,link,662,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ楦"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ楧") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ楨")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ楩"))
		#		addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ楪"),l111ll_l1_+title,link,662,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭楫"),l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭楬"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ業"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭楮"),l11lll_l1_ (u"࠭ࠧ楯"),l11lll_l1_ (u"ࠧࠨ楰"),l11lll_l1_ (u"ࠨࠩ楱"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ楲"))
	html = response.content
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ楳"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		link = re.findall(l11lll_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ楴"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭極"))
			l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ楶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨ楷"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ楸")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ楹"))
				l1111_l1_.append(link)
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠤࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡱ࡯࡮࡬ࡵࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ࠭ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪ࠭ࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠴࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩ࡜ࡅࡖࡕࡔ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࡲࡩ࡯࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣࡰ࡮ࡴ࡫ࡴ࠼ࠍࠍࠎࠏࡩࡧࠢ࡯࡭ࡳࡱࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠼ࠍࠍࠎࠏࠉ࡯ࡣࡰࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩࠬࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ楺")
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ楻"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ楼"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ楽"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ楾"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ楿"),l11lll_l1_ (u"ࠩ࠮ࠫ榀"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ榁")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ概"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ榃")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ榄"))
	return
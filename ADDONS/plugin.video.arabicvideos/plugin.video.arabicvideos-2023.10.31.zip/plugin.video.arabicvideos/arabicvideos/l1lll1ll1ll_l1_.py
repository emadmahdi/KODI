# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ⑶")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡋࡂ࠳ࡡࠪ⑷")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1llll11l1l_l1_.l1llll11ll1_l1_
# l1l1ll11_l1_	https://l1lll1lllll_l1_.l1llll11l1l_l1_.l1llll111l1_l1_
# l1llll111ll_l1_ content l1llll1lll1_l1_ html	https://l1llll11l11_l1_.faselhd.l1lll1lll11_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l1lll1lll1l_l1_.l1lllll1111_l1_
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1llll1ll1l_l1_
# l1llll1ll11_l1_	https://www.l1llll1ll11_l1_.com/l1llll11l1l_l1_
# l1llll1l1ll_l1_	https://www.l1llll1l1ll_l1_.com/l1llll11lll_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭⑸"),l11lll_l1_ (u"࠭ว๋ฮํࠤอ๐ำหࠩ⑹"),l11lll_l1_ (u"ฺࠧำฺ๋ࠥอไๆืสี฾ฯࠧ⑺"),l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ⑻"),l11lll_l1_ (u"ࠩส๎ั๐ࠠษีอࠤฬ๊ศะ์็ࠫ⑼"),l11lll_l1_ (u"ࠪห๏า้ࠡสึฮࠥอไอัํำࠬ⑽")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==780: results = MENU()
	elif mode==781: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==782: results = l1l11l_l1_(url)
	elif mode==783: results = PLAY(url)
	elif mode==784: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ⑾")+text)
	elif mode==785: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⑿")+text)
	elif mode==786: results = l1lll1l1l1_l1_(url,l1l11l1_l1_)
	elif mode==789: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒀"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⒁"),l11lll_l1_ (u"ࠨࠩ⒂"),789,l11lll_l1_ (u"ࠩࠪ⒃"),l11lll_l1_ (u"ࠪࠫ⒄"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⒅"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒆"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⒇"),l11lll_l1_ (u"ࠧࠨ⒈"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⒉"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ⒊"),l11lll_l1_ (u"ࠪࠫ⒋"),l11lll_l1_ (u"ࠫࠬ⒌"),l11lll_l1_ (u"ࠬ࠭⒍"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⒎"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸ࠲ࡶࡡࡨࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⒏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ⒐"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⒑"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⒒") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⒓"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⒔")+l111ll_l1_+title,link,781)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⒕"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⒖"),l11lll_l1_ (u"ࠨࠩ⒗"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࡹ࡯ࡤ࡫ࡤࡰ࠲ࡨ࡯ࡹࠩ⒘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⒙"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭⒚"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⒛") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒜"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⒝")+l111ll_l1_+title,link,781,l11lll_l1_ (u"ࠨࠩ⒞"),l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠫ⒟"))
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⒠"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⒡"),l11lll_l1_ (u"ࠬ࠭⒢"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⒣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⒤"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⒥"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⒦") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒧"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⒨")+l111ll_l1_+title,link,781)
	return
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠬ࠭⒩")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ⒪"),l11lll_l1_ (u"ࠧࠨ⒫"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⒬"),url,l11lll_l1_ (u"ࠩࠪ⒭"),l11lll_l1_ (u"ࠪࠫ⒮"),l11lll_l1_ (u"ࠫࠬ⒯"),l11lll_l1_ (u"ࠬ࠭⒰"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⒱"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩ⒲"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠨࠩ⒳"),l11lll_l1_ (u"ࠩࠪ⒴"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠪั้่วหࠩ⒵") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"๊ࠫ๎วิ็ࠪⒶ") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⒷ"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓒ"),l111ll_l1_+title,link,786,l1llll_l1_,l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧⒹ"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⒺ"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⒻ"),l111ll_l1_+title,link,783,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩⒼ"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⒽ"),l111ll_l1_+title,link,783)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠬ࠭Ⓘ")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧⒿ"),l11lll_l1_ (u"ࠧࠨⓀ"),l11lll_l1_ (u"ࠨࡖࡌࡘࡑࡋࡓࠨⓁ"),url)
	# next l1l11l1_l1_
	if l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭Ⓜ") in type or l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪⓃ") in type:
		l11l11l_l1_,data = url.split(l11lll_l1_ (u"ࠫࡄࡹࡥࡱࡣࡵࡥࡹࡵࡲࠧࠩⓄ"))
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫⓅ"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬⓆ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬⓇ"),l11l11l_l1_,data,headers,l11lll_l1_ (u"ࠨࠩⓈ"),l11lll_l1_ (u"ࠩࠪⓉ"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩⓊ"))
		html = response.content
		html = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡶࠫⓋ")+html+l11lll_l1_ (u"ࠬࡧࡲࡵ࡫ࡦࡰࡪ࠭Ⓦ")
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪⓍ"),url,l11lll_l1_ (u"ࠧࠨⓎ"),l11lll_l1_ (u"ࠨࠩⓏ"),l11lll_l1_ (u"ࠩࠪⓐ"),l11lll_l1_ (u"ࠪࠫⓑ"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪⓒ"))
		html = response.content
	items,l1lllll1l1l_l1_,filters = [],False,False
	if not type:
		# l1lllll1l1l_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨⓓ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧⓔ"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩⓕ"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓖ"),l111ll_l1_+title,link,781,l11lll_l1_ (u"ࠩࠪⓗ"),l11lll_l1_ (u"ࠪࡷࡺࡨ࡭ࡦࡰࡸࠫⓘ"))
				l1lllll1l1l_l1_ = True
	if not type:
		# filter
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡲ࡬࠮ࡶࡤࡼࡪࡹࠨ࠯ࠬࡂ࠭ࠧࡲ࡯ࡢࡦࠥࠫⓙ"),html,re.DOTALL)
		if l1l1ll1_l1_ and type!=l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬⓚ"):
			if l1lllll1l1l_l1_: addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⓛ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⓜ"),l11lll_l1_ (u"ࠨࠩⓝ"),9999)
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓞ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ⓟ"),url,785,l11lll_l1_ (u"ࠫࠬⓠ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬⓡ"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⓢ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪⓣ"),url,784,l11lll_l1_ (u"ࠨࠩⓤ"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩⓥ"))
			filters = True
	if not l1lllll1l1l_l1_ and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨⓦ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⓧ"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨⓨ"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨⓩ") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⓪"),l111ll_l1_+title,link,781,l1llll_l1_)
				elif l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ⓫") in link and l11lll_l1_ (u"ࠩะ่็ฯࠧ⓬") not in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⓭"),l111ll_l1_+title,link,786,l1llll_l1_)
				elif l11lll_l1_ (u"๊ࠫ๎ำๆࠩ⓮") in link and l11lll_l1_ (u"ࠬำไใหࠪ⓯") not in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⓰"),l111ll_l1_+title,link,786,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⓱"),l111ll_l1_+title,link,783,l1llll_l1_)
		# l1lll1lll1_l1_
		length = 12 if l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⓲") in type else 16
		data = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠫࡰࡴࡧࡤ࠮࡯ࡲࡶࡪ࠴ࠪࡀࠫࠣ࠲࠯ࡅࡤࡢࡶࡤ࠱࠭࠴ࠪࡀࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⓳"),html,re.DOTALL)
		if len(items)==length and (data or l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ⓴") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l11lll_l1_ (u"ࠫࡱࡵࡡࡥࠩ⓵"),l11lll_l1_ (u"ࠬ࡭ࡥࡵࠩ⓶")).replace(l11lll_l1_ (u"࠭࠭ࠨ⓷"),l11lll_l1_ (u"ࠧࡠࠩ⓸")).replace(l11lll_l1_ (u"ࠨࠤࠪ⓹"),l11lll_l1_ (u"ࠩࠪ⓺"))
			else:
				data = re.findall(l11lll_l1_ (u"ࠪࡥࡨࡺࡩࡰࡰࡀࠬ࠳࠰࠿ࠪࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠫ࠲࠯ࡅࠩࠧࠪ࠱࠮ࡄ࠯࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ⓻"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l11lll_l1_ (u"ࠫࡦࡩࡴࡪࡱࡱࡁࠬ⓼")+action+l11lll_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧ⓽")+str(offset)+l11lll_l1_ (u"࠭ࠦࠨ⓾")+name+l11lll_l1_ (u"ࠧ࠾ࠩ⓿")+value
			url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࡦࡪ࡭ࡪࡰ࠰ࡥ࡯ࡧࡸ࠯ࡲ࡫ࡴࡄࡹࡥࡱࡣࡵࡥࡹࡵࡲࠧࠩ─")+data
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ━"),l111ll_l1_+l11lll_l1_ (u"ࠪห้๋า๋ัࠪ│"),url,781,l11lll_l1_ (u"ࠫࠬ┃"),l11lll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡡࠪ┄")+type)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ┅"),url,l11lll_l1_ (u"ࠧࠨ┆"),l11lll_l1_ (u"ࠨࠩ┇"),l11lll_l1_ (u"ࠩࠪ┈"),l11lll_l1_ (u"ࠪࠫ┉"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ┊"))
	html = response.content
	#l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂ࡬ࡢࡤࡨࡰࡃอไหื้๎ๆࡂ࠯࡭ࡣࡥࡩࡱࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ┋"),html,re.DOTALL)
	#if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l11ll1l1l_l1_ links
	items = re.findall(l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡨࡵࡤࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ┌"),html,re.DOTALL)
	for l1lll1llll1_l1_ in items:
		l1llll1111l_l1_ = base64.b64decode(l1lll1llll1_l1_)
		if kodi_version>18.99: l1llll1111l_l1_ = l1llll1111l_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ┍"))
		link = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭┎"),l1llll1111l_l1_,re.DOTALL)
		if link:
			link = link[0]
			if link not in l1lll11ll1_l1_:
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ┏"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ┐")+server+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ┑"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠩ┒"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࠼ࡥ࡫ࡹࡂࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪࠩ࡞ࡧࡿ࠸࠲࠴ࡾࠫ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࡧࡳࡼࡴ࡬ࡰࡣࡧࡁ࠭࠴ࠪࡀࠫࠥࠫ┓"),block,re.DOTALL)
		for l11l111l_l1_,l1llll1llll_l1_ in items:
			link = base64.b64decode(l1llll1llll_l1_)
			if kodi_version>18.99: link = link.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ└"))
			if link not in l1lll11ll1_l1_:
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭┕"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ┖")+server+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ┗")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬ┘"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ┙"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"࠭ࠠࠨ┚"),l11lll_l1_ (u"ࠧ࠮ࠩ┛"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡳࡪ࠯ࡀࡳࡀࠫ├")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ┝"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_ l1lllll1l_l1_ 2023-10-23
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ┞"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ┟"),url,l11lll_l1_ (u"ࠬ࠭┠"),l11lll_l1_ (u"࠭ࠧ┡"),l11lll_l1_ (u"ࠧࠨ┢"),l11lll_l1_ (u"ࠨࠩ┣"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭┤"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡣࡵࡸ࡮ࡩ࡬ࡦࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ┥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ┦"),block,re.DOTALL)
		l1lll1l111_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ┧"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	if l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩ┨") not in url: l11l11l_l1_,l1llll1l11l_l1_ = url,l11lll_l1_ (u"ࠧࠨ┩")
	else: l11l11l_l1_,l1llll1l11l_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࠫ┪"))
	l11l1l1_l1_,l1llll1l1l1_l1_ = l1llll11ll_l1_(l1llll1l11l_l1_)
	l1llll11111_l1_ = l11lll_l1_ (u"ࠩࠪ┫")
	for key in list(l1llll1l1l1_l1_.keys()):
		l1llll11111_l1_ += l11lll_l1_ (u"ࠪࠪࡦࡸࡧࡴࠧ࠸ࡆࠬ┬")+key+l11lll_l1_ (u"ࠫࠪ࠻ࡄ࠾ࠩ┭")+l1llll1l1l1_l1_[key]
	# filter final url
	l1111111_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡶࡩࡵࡧࡲࡢࡶࡲࡶࠫࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡡࡩ࡭ࡱࡺࡥࡳࡦࡢࡦࡱࡵࡣ࡬ࡵࠪ┮")+l1llll11111_l1_
	return l1111111_l1_
l1lll11lll_l1_ = [l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ┯"),l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ┰"),l11lll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ┱"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ┲"),l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ┳"),l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ┴"),l11lll_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ┵")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ┶"),l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ┷"),l11lll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ┸")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ┹"),l11lll_l1_ (u"ࠪࠫ┺"))
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ┻"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ┼"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ┽"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ┾"),l11lll_l1_ (u"ࠨࠩ┿")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭╀"))
	if type==l11lll_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ╁"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"ࠫࡂ࠭╂") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"ࠬࡃࠧ╃") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ╄")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ╅")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ╆")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ╇")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ╈"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ╉")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ╊"))
		# l1lll1l1ll_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ╋"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ╌")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭╍"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ╎"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1lll1ll1l_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭╏"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ═")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ║"),l111ll_l1_+l11lll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ╒"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠧࠨ╓"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ╔"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╕"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ╖")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ╗"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠬ࠭╘"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭╙"))
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╚"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ╛"),l11lll_l1_ (u"ࠩࠪ╜"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠪ็้ࠦࠧ╝"),l11lll_l1_ (u"ࠫࠬ╞"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧ╟") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ╠"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_,l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ╡"))
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ╢")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╣"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ╤"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠫࠬ╥"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ╦"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╧"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ╨"),l11l11l_l1_,785,l11lll_l1_ (u"ࠨࠩ╩"),l11lll_l1_ (u"ࠩࠪ╪"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ╫"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭╬")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ╭")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ╮")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ╯")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ╰")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╱"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ╲")+name,l11l11l_l1_,784,l11lll_l1_ (u"ࠫࠬ╳"),l11lll_l1_ (u"ࠬ࠭╴"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ╵"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ╶")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ╷")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ╸")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ╹")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ╺")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ╻")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"࠭࠰ࠨ╼")]
			title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ╽")+name
			if type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭╾"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╿"),l111ll_l1_+title,url,784,l11lll_l1_ (u"ࠪࠫ▀"),l11lll_l1_ (u"ࠫࠬ▁"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ▂"))
			elif type==l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ▃") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"ࠧ࠾ࠩ▄") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ▅"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭▆")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▇"),l111ll_l1_+title,l11l1l1_l1_,781,l11lll_l1_ (u"ࠫࠬ█"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ▉"))
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭▊"),l111ll_l1_+title,url,785,l11lll_l1_ (u"ࠧࠨ▋"),l11lll_l1_ (u"ࠨࠩ▌"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ▍")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭▎")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ▏")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠬࡃࠦࠨ▐"),l11lll_l1_ (u"࠭࠽࠱ࠨࠪ░"))
	filters = filters.strip(l11lll_l1_ (u"ࠧࠧࠩ▒"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠨ࠿ࠪ▓") in filters:
		items = filters.split(l11lll_l1_ (u"ࠩࠩࠫ▔"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠪࡁࠬ▕"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠫࠬ▖")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠬ࠶ࠧ▗")
		if l11lll_l1_ (u"࠭ࠥࠨ▘") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ▙") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ▚"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭▛")+value
		elif mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭▜") and value!=l11lll_l1_ (u"ࠫ࠵࠭▝"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ▞")+key+l11lll_l1_ (u"࠭࠽ࠨ▟")+value
		elif mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ■"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ□")+key+l11lll_l1_ (u"ࠩࡀࠫ▢")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ▣"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭▤"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠬࡃ࠰ࠨ▥"),l11lll_l1_ (u"࠭࠽ࠨ▦"))
	return l1ll1l1l_l1_
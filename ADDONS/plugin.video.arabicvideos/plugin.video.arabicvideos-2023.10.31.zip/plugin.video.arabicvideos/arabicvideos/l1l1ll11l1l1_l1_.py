# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ䱅")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩ䱆")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫฬ์่ศ฻ࠣหๆ๊วๆࠩ䱇"),l11lll_l1_ (u"ࠬา่ะษอࠤฬ็ไศ็ࠪ䱈")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1111l_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llllll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱉"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䱊"),l11lll_l1_ (u"ࠨࠩ䱋"),389,l11lll_l1_ (u"ࠩࠪ䱌"),l11lll_l1_ (u"ࠪࠫ䱍"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䱎"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䱏"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䱐"),l11lll_l1_ (u"ࠧࠨ䱑"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䱒"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䱓")+l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ䱔"),l11ll1_l1_,381,l11lll_l1_ (u"ࠫࠬ䱕"),l11lll_l1_ (u"ࠬ࠭䱖"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䱗"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䱘"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䱙")+l111ll_l1_+l11lll_l1_ (u"ࠩส่ัอๆษ์ฬࠫ䱚"),l11ll1_l1_,381,l11lll_l1_ (u"ࠪࠫ䱛"),l11lll_l1_ (u"ࠫࠬ䱜"),l11lll_l1_ (u"ࠬࡹࡩࡥࡧࡵࠫ䱝"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䱞"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䱟"),l11lll_l1_ (u"ࠨࠩ䱠"),l11lll_l1_ (u"ࠩࠪ䱡"),l11lll_l1_ (u"ࠪࠫ䱢"),l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䱣"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䱤"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱥"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䱦")+l111ll_l1_+title,l11ll1_l1_,381,l11lll_l1_ (u"ࠨࠩ䱧"),l11lll_l1_ (u"ࠩࠪ䱨"),l11lll_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䱩")+str(seq))
	block = l11lll_l1_ (u"ࠫࠬ䱪")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪ䱫"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ䱬"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䱭"),block,re.DOTALL)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䱮"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䱯"),l11lll_l1_ (u"ࠪࠫ䱰"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫ䱱"):
			if first:
				title = l11lll_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ䱲")+title
				first = False
			else: title = l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ䱳")+title
		if title not in l1l1l1_l1_:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䱴"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䱵")+l111ll_l1_+title,link,381)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䱶"),l11lll_l1_ (u"ࠪࠫ䱷"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䱸"),url,l11lll_l1_ (u"ࠬ࠭䱹"),l11lll_l1_ (u"࠭ࠧ䱺"),l11lll_l1_ (u"ࠧࠨ䱻"),l11lll_l1_ (u"ࠨࠩ䱼"),l11lll_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䱽"))
	html = response.content
	if type==l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ䱾"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䱿"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲀"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ䲁"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ䲂"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		z = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䲃"),block,re.DOTALL)
		l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_ = zip(*z)
		items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䲄"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ䲅"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䲆"),block,re.DOTALL)
	elif l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䲇") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ䲈"),l11lll_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭䲉"))
		html = html.replace(l11lll_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ䲊"),l11lll_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭䲋"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ䲌"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==2: items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䲍"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ䲎"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ䲏") in url:
				items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䲐"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ䲑") in url:
				items = re.findall(l11lll_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲒"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䲓"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࠪ䲔") in title:
			title = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡨࡶ࡮࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲕"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪ䲖")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䲗")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ䲘"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ䲙") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲚"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ䲛") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䲜"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ䲝") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䲞"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ䲟") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲠"),l111ll_l1_+title,link,381,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䲡"),l111ll_l1_+title,link,382,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡕࡧࡧࡦࠢࠫ࠲࠯ࡅࠩࠡࡱࡩࠤ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䲢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		current = l1l1ll1_l1_[0][0]
		last = l1l1ll1_l1_[0][1]
		block = l1l1ll1_l1_[0][2]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ䲣"),block,re.DOTALL)
		for link,title in items:
			if title==l11lll_l1_ (u"࠭ࠧ䲤") or title==last: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䲥"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ䲦")+title,link,381,l11lll_l1_ (u"ࠩࠪ䲧"),l11lll_l1_ (u"ࠪࠫ䲨"),type)
		#if title==last:
		link = link.replace(l11lll_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䲩")+title+l11lll_l1_ (u"ࠬ࠵ࠧ䲪"),l11lll_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭䲫")+last+l11lll_l1_ (u"ࠧ࠰ࠩ䲬"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䲭"),l111ll_l1_+l11lll_l1_ (u"ࠩสาึࠦีโฯฬࠤࠬ䲮")+last,link,381,l11lll_l1_ (u"ࠪࠫ䲯"),l11lll_l1_ (u"ࠫࠬ䲰"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䲱"),url,l11lll_l1_ (u"࠭ࠧ䲲"),l11lll_l1_ (u"ࠧࠨ䲳"),l11lll_l1_ (u"ࠨࠩ䲴"),l11lll_l1_ (u"ࠩࠪ䲵"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䲶"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䲷"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,False):
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䲸"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊ࠠๅๆๆฬฬื้ࠠษ็้อืๅอ่๊ࠢ฾ํࠧ䲹"),l11lll_l1_ (u"ࠧࠨ䲺"),9999)
		return
	if l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䲻") in url or l11lll_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ䲼") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡯ࡴࡦ࡯ࠪࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ䲽"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[1]
			l1llllll_l1_(l11l11l_l1_)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠩࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡧࡳࡵࠤࠪࠫࠬ䲾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ䲿"),block,re.DOTALL)
		for l1llll_l1_,l1lll11_l1_,link,name in items:
			title = l1lll11_l1_+l11lll_l1_ (u"࠭ࠠ࠻ࠢࠪ䳀")+name+l11lll_l1_ (u"ࠧࠡษ็ั้่ษࠨ䳁")
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䳂"),l111ll_l1_+title,link,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䳃"),url,l11lll_l1_ (u"ࠪࠫ䳄"),l11lll_l1_ (u"ࠫࠬ䳅"),l11lll_l1_ (u"ࠬ࠭䳆"),l11lll_l1_ (u"࠭ࠧ䳇"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䳈"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䳉"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠥࠦ࡮ࡪ࠽ࠨࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠪࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠩࠤࡶ࡬ࡪࡧࡤࡦࡴࠥࢀࠬࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࠮ࠨࠢࠣ䳊"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠥࡨࡦࡺࡡ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡵࡨࡶࡻ࡫ࡲࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ䳋"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䳌")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䳍")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡮ࡱࡧࡥࡱ࠳ࡣ࡭ࡱࡶࡩࠧ࠭䳎"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡠࡡࡢࡨࡱࡥࡧࡥࡴ࡬ࡺࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䳏"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䳐")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䳑")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䳒"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䳓"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭䳔"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ䳕"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ䳖"),l11lll_l1_ (u"ࠨ࠭ࠪ䳗"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ䳘")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ䳙"))
	return
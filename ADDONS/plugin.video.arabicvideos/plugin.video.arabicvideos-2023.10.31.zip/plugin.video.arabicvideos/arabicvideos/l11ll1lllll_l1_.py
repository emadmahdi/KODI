# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨ岇")
def MAIN(mode,text=l11lll_l1_ (u"ࠧࠨ岈")):
	if   mode==  0: l1llll1l1ll11_l1_(text)
	elif mode==  2: l1l1lll11ll1_l1_(text)
	elif mode==  3: l1llllll11111_l1_()
	elif mode==  4: l1lll111111l_l1_(text)
	elif mode==  5: l1llll1l1l111_l1_()
	elif mode==  6: l1llllll11l1l_l1_()
	elif mode==  7: l1ll11l111ll_l1_()
	elif mode==  8: l1llll1l1111l_l1_()
	elif mode==  9: l1llll1l111ll_l1_()
	elif mode==150: l1llll11l1ll1_l1_()
	elif mode==151: l1lll1l1llll1_l1_()
	elif mode==152: l1lllll111111_l1_()
	elif mode==153: l11111111l1l_l1_()
	elif mode==154: l1llllll1llll_l1_()
	elif mode==155: l1llll1ll1111_l1_()
	elif mode==156: l1lll1l1ll1ll_l1_()
	elif mode==157: l1llllll11ll1_l1_()
	elif mode==158: l1lllll11111l_l1_()
	elif mode==159: l1llll111lll1_l1_(True)
	elif mode==170: l1llll11l1111_l1_()
	elif mode==171: l1lllll11llll_l1_()
	elif mode==172: l1lll1lllllll_l1_(text,True,True)
	elif mode==173: l111ll1ll1l_l1_(l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ岉"),True)
	elif mode==174: l111ll1ll1l_l1_(l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ岊"),True)
	elif mode==175: l1llll1ll1lll_l1_()
	elif mode==176: l1llll1111111_l1_()
	elif mode==177: l1llllll1ll11_l1_(l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ岋"))
	elif mode==178: l1llllll1ll11_l1_(l11lll_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ岌"))
	elif mode==179: l1llllll1ll11_l1_(l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ岍"))
	elif mode==190: l1llll1l1l1ll_l1_()
	elif mode==191: l1lll1lll1l11_l1_()
	elif mode==192: l1llll111111l_l1_()
	elif mode==193: l1lllll1l111l_l1_()
	elif mode==194: l1lll1lllll11_l1_()
	elif mode==195: l1llll11l1l1l_l1_()
	elif mode==196: l1llll1l11lll_l1_()
	elif mode==197: l1llll11lll11_l1_()
	elif mode==198: l1lllll11ll1l_l1_()
	elif mode==199: l1llll11ll1l1_l1_()
	elif mode==340: l1lll1ll1lll1_l1_(text)
	elif mode==341: l1l1l111l11l_l1_()
	elif mode==342: l1llll1ll11ll_l1_()
	elif mode==343: l1llll11lll1l_l1_()
	elif mode==344: l1lll1lll1l1l_l1_(True)
	elif mode==345: l1lllll111ll1_l1_()
	elif mode==346: l11lll1ll1l_l1_(False)
	elif mode==347: l1l11llllll1_l1_(True)
	elif mode==348: l1lllll1l1111_l1_()
	elif mode==349: l1lllll1llll1_l1_(l1l111l11lll_l1_)
	elif mode==500: l1lll1lll1ll1_l1_()
	elif mode==501: l1lll1ll11lll_l1_()
	elif mode==502: l1lllll11ll11_l1_(l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ岎"),True)
	elif mode==503: l1lllll1llll1_l1_(l11lll11l11_l1_)
	elif mode==504: l1lllll1llll1_l1_(favoritesfile)
	elif mode==505: l1llll1ll1l1l_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1111lll_l1_(text,l11lll_l1_ (u"ࠧࠨ岏"),True)
	elif mode==508: l1lllll11lll1_l1_()
	elif mode==509: l111111111l1_l1_()
	return
def l111111111l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ岐"),l11lll_l1_ (u"ࠩࠪ岑"),l11lll_l1_ (u"ࠪࠫ岒"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ岓"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧ岔"))
	if l1ll111ll1_l1_:
		l1lll1lll1l1l_l1_(False)
		l1ll11l1ll_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ岕"),l11lll_l1_ (u"ࠧࠨ岖"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ岗"),l11lll_l1_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤฬ๊ๅึ่฼ࠫ岘"))
	return
def l1l1l1111lll_l1_(addon_id,function,l1ll_l1_):
	# function: l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ岙"),l11lll_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࠬ岚"),l11lll_l1_ (u"ࠬ࠭岛")
	conn = sqlite3.connect(l1l1l11llll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1llll1111l11_l1_ = l11lll_l1_ (u"࠭ࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠩ岜")
	else: l1llll1111l11_l1_ = l11lll_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸ࠭岝")
	cc.execute(l11lll_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩ岞")+l1llll1111l11_l1_+l11lll_l1_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ岟")+addon_id+l11lll_l1_ (u"ࠪࠦࠥࡁࠧ岠"))
	l11ll1lll1l_l1_ = cc.fetchall()
	if l11ll1lll1l_l1_ and function in [l11lll_l1_ (u"ࠫࠬ岡"),l11lll_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ岢")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ岣"),l11lll_l1_ (u"ࠧࠨ岤"),l11lll_l1_ (u"ࠨࠩ岥"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ岦"),l11lll_l1_ (u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧ岧")+addon_id+l11lll_l1_ (u"ࠫࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦๅห๊ๅๅࠥ๎ไศࠢํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ็ู๋ๆ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ岨"))
		if l1ll111ll1_l1_!=1: return
		cc.execute(l11lll_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫ岩")+l1llll1111l11_l1_+l11lll_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ岪")+addon_id+l11lll_l1_ (u"ࠧࠣࠢ࠾ࠫ岫"))
	elif function in [l11lll_l1_ (u"ࠨࠩ岬"),l11lll_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ岭")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ岮"),l11lll_l1_ (u"ࠫࠬ岯"),l11lll_l1_ (u"ࠬ࠭岰"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ岱"),l11lll_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ岲")+addon_id+l11lll_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣๆ฿ไ๊ࠡํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦสโ฻ํ่์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ岳"))
		if l1ll111ll1_l1_!=1: return
		if kodi_version<19: cc.execute(l11lll_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ岴")+addon_id+l11lll_l1_ (u"ࠪࠦ࠮ࠦ࠻ࠨ岵"))
		else: cc.execute(l11lll_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫ岶")+addon_id+l11lll_l1_ (u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬ岷"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ岸"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ岹"),l11lll_l1_ (u"ࠨࠩ岺"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ岻"),l11lll_l1_ (u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧ岼"))
	if function in [l11lll_l1_ (u"ࠫࠬ岽"),l11lll_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ岾")]: l1llll111lll1_l1_(l1ll_l1_)
	return
def l1llll1ll1l1l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ岿"),l11lll_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ峀"))
	l1l1l1l11l1l_l1_ = l11l111l1l1_l1_(False)
	l1llll11ll1l_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱࠫ峁")
	l11111111lll_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ峂")
	l11111111ll1_l1_ = l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ峃")
	for id,l1l111l11l11_l1_,l1l11l11l1ll_l1_,l1111l11111_l1_,l11111ll111_l1_,reason in reversed(l1l1l1l11l1l_l1_):
		if id==l11lll_l1_ (u"ࠫ࠵࠭峄"):
			l1lll1ll111l_l1_,l1lll1ll11l1_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ峅"))
			continue
		if l1llll11ll1l_l1_!=l11lll_l1_ (u"࠭࡜࡯ࠩ峆"): l1llll11ll1l_l1_ += l11111111ll1_l1_
		l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ峇")+id+l11lll_l1_ (u"ࠨࠢ࠽ࠤࠬ峈")+l11lll_l1_ (u"ࠩสุ่สวๅࠢ࠽ࠤࠬ峉")+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ峊")+l1l11l11l1ll_l1_
		l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅฮ๋หอࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ峋")+l1111l11111_l1_
		l11l1111ll11_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ峌")+l11111ll111_l1_
		l11l1111ll1l_l1_ = l11lll_l1_ (u"࠭࡜࡯࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ือฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ峍")+reason
		l1llll11ll1l_l1_ += l1l1ll11ll1_l1_+l1l1ll11lll_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ峎")+l11111111lll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ峏")+l11l1111ll11_l1_+l11l1111ll1l_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ峐")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ峑"),l1lll1ll11l1_l1_,l1llll11ll1l_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ峒"))
	return
def l1lllll1llll1_l1_(file):
	if file==favoritesfile: l1llll1lll1l1_l1_ = l11lll_l1_ (u"่่ࠬศศ่ࠤฬ๊ๅโุ็อࠬ峓")
	elif file==l1l111l11lll_l1_: l1llll1lll1l1_l1_ = l11lll_l1_ (u"࠭วๅำึหห๊ࠧ峔")
	elif file==l11lll11l11_l1_: l1llll1lll1l1_l1_ = l11lll_l1_ (u"ࠧใ๊สส๊ࠦยฯำࠣห้็๊ะ์๋๋ฬะࠧ峕")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ峖"),l11lll_l1_ (u"่ࠩืา࠭峗"),l11lll_l1_ (u"ࠪษฺ๊วฮࠩ峘"),l11lll_l1_ (u"ࠫำื่อࠩ峙"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ峚"),l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ峛")+l1llll1lll1l1_l1_+l11lll_l1_ (u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ峜"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ峝"),l11lll_l1_ (u"ࠩࠪ峞"),l11lll_l1_ (u"ࠪࠫ峟"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ峠"),l11lll_l1_ (u"ࠬ࠭峡"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ峢"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠๆๆไࠤࠬ峣")+l1llll1lll1l1_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ峤"),l11lll_l1_ (u"ࠩࠪ峥"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭峦"),l11lll_l1_ (u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫ峧")+l1llll1lll1l1_l1_)
	return
def l1lll1ll11lll_l1_():
	if kodi_version<18:
		message = l11lll_l1_ (u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨ峨")+str(kodi_version)+l11lll_l1_ (u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧ峩")
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ峪"),l11lll_l1_ (u"ࠨࠩ峫"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ峬"),message)
		return
	l1111l1111l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭峭"))
	l1l111lll11l_l1_ = l1ll1llll11l_l1_([l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ峮")])
	l1l1111ll1ll_l1_,l1lllll1ll1ll_l1_,l1lllll1lll1l_l1_,l1lllll1lll11_l1_,l1lllll1ll11l_l1_,l1lll1ll1ll1l_l1_,l1lllll1ll1l1_l1_ = l1l111lll11l_l1_[l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ峯")]
	if l1l1111ll1ll_l1_ or l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ峰") not in str(l1111l1111l_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ峱"),l11lll_l1_ (u"ࠨࠩ峲"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ峳"),l11lll_l1_ (u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ峴"))
		succeeded = l1lllll11ll11_l1_(l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ峵"),True)
		if not succeeded: return
	l111lll1ll1_l1_(True)
	return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠭ࠩࠋࠋ࡬ࡪࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅ࠿ࡀࠫ࠺࠺࠴ࠨ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨࠌࠌࡩࡱ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠷࠸ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้฻่าࠩࠍࠍࡪࡲࡳࡦ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠๆฮ๊์้ฯࠧࠋࠋ࡬ࡪࠥࡩࡨࡰ࡫ࡦࡩࡂࡃ࠰࠻ࠋࠌࠧࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠭ࠊࠊࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡸ࡬ࡩࡼࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࠊࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧࡼࡩࡦࡹࠥࠤ࡜ࡎࡅࡓࡇࠣࡺ࡮࡫ࡷࡎࡱࡧࡩࠥࡃࠠ࠲࠻࠺࠵࠶࠽ࠠ࠼ࠩࠬࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠼࠶࠱࠺࠳ࠤࡀ࠭ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎ࡫࡬ࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠶ࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࠧ࠶࠶࠷ࠫࠎࠩࠠࠣࡎ࡬ࡷࡹࠦࡅ࡮ࡣࡧࠦࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠳࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠺࠻ࠧࠊࠥࠣࠦࡌࡧ࡬࡭ࡧࡵࡽࡤࡋ࡭ࡢࡦࠥࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠬ࠲ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠬࠎࠎࠨࠢࠣ島")
def l111lll1ll1_l1_(l1ll_l1_=True):
	l1111l1111l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ峷"))
	if l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭峸") not in str(l1111l1111l_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ峹"),l11lll_l1_ (u"ࠩࠪ峺"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭峻"),l11lll_l1_ (u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ峼"))
		return
	l1llllll111ll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ峽"),l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ峾"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ峿"),l11lll_l1_ (u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩ崀"))
	if not os.path.exists(l1llllll111ll_l1_): return
	l11ll1l11ll_l1_ = open(l1llllll111ll_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ崁")).read()
	if kodi_version>18.99: l11ll1l11ll_l1_ = l11ll1l11ll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ崂"))
	l1lll1ll11l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ崃"),l11ll1l11ll_l1_,re.DOTALL)
	l1lll1lll1111_l1_,l11111111l11_l1_ = l1lll1ll11l11_l1_[0]
	l1lllllll11l1_l1_ = l11lll_l1_ (u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭崄")+l1lll1lll1111_l1_+l11lll_l1_ (u"࠭ࠬࠨ崅")+l11111111l11_l1_+l11lll_l1_ (u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ崆")
	if l1ll_l1_:
		l1lllllll1l11_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭崇"))
		if l1lllllll1l11_l1_==l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ崈"): l11l11l1111_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢส่่ะวษหࠪ崉")
		elif l1lllllll1l11_l1_==l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ崊"): l11l11l1111_l1_ = l11lll_l1_ (u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ崋")
		else: l11l11l1111_l1_ = l11lll_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ崌")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ崍"),l11lll_l1_ (u"ࠨไ๋หห๋ࠠฤะิํࠬ崎"),l11lll_l1_ (u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ崏"),l11lll_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ崐"),l11lll_l1_ (u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ崑")+l11l11l1111_l1_,l11lll_l1_ (u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ崒"))
		if choice==1: l1llll1lll111_l1_ = l11lll_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ崓")
		elif choice==2: l1llll1lll111_l1_ = l11lll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭崔")
		else: l1llll1lll111_l1_ = l11lll_l1_ (u"ࠨࠩ崕")
	else:
		l1lllllll1l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ崖"))
		if   l1lllllll1l11_l1_==l11lll_l1_ (u"ࠪࠫ崗"): choice = 0
		elif l1lllllll1l11_l1_==l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ崘"): choice = 1
		elif l1lllllll1l11_l1_==l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ崙"): choice = 2
		l1llll1lll111_l1_ = l1lllllll1l11_l1_
	if   choice==0: l1llll1l1l1l1_l1_ = l11lll_l1_ (u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪ崚")
	elif choice==1: l1llll1l1l1l1_l1_ = l11lll_l1_ (u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫ崛")
	elif choice==2: l1llll1l1l1l1_l1_ = l11lll_l1_ (u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬ崜")
	else: return
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ崝"),l1llll1lll111_l1_)
	l1lll1llll111_l1_ = l11lll_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ崞")+l1llll1l1l1l1_l1_+l11lll_l1_ (u"ࠫ࠱࠭崟")+l11111111l11_l1_+l11lll_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ崠")
	l11ll111l1l_l1_ = l11ll1l11ll_l1_.replace(l1lllllll11l1_l1_,l1lll1llll111_l1_)
	if kodi_version>18.99: l11ll111l1l_l1_ = l11ll111l1l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ崡"))
	open(l1llllll111ll_l1_,l11lll_l1_ (u"ࠧࡸࡤࠪ崢")).write(l11ll111l1l_l1_)
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ崣"),l11lll_l1_ (u"ࠩ࠱ࠤ࡙ࠥ࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧ崤")+l1llll1l1l1l1_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭崥"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪ崦"))
	return
def l1lll1lll1ll1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭崧"),l11lll_l1_ (u"࠭ใๅษࠪ崨"),l11lll_l1_ (u"ࠧ็฻่ࠫ崩"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ崪"),l11lll_l1_ (u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ崫"))
	if l1ll111ll1_l1_==1: l1ll11l111ll_l1_()
	return
def l1llll1l1111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ崬"),l11lll_l1_ (u"ࠫࠬ崭"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ崮"),l11lll_l1_ (u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩ崯"))
	return
def l1lllll1l1111_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ崰")
	l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧ崱")
	l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ崲")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ崳")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨ崴")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ崵")
	message = l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ崶")+l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬ崷")+l1l1ll11lll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ崸"),l11lll_l1_ (u"ࠩࠪ崹"),message)
	return
def l11lll1ll1l_l1_(l1l1111111l_l1_):
	try: status = l11111ll1l1_l1_(l1l1111111l_l1_,False)
	except: pass
	l1l1l1l11l1l_l1_ = l11l111l1l1_l1_(l1l1111111l_l1_)
	id,l1l111l11l11_l1_,l1l11l11l1ll_l1_,l1111l11111_l1_,l11111ll111_l1_,reason = l1l1l1l11l1l_l1_[0]
	l1lll1ll111l_l1_,l1lll1ll11l1_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ崺"))
	l1l1ll11lll_l1_,l11l1111ll11_l1_,l11l1111ll1l_l1_ = l11111ll111_l1_.split(l11lll_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ崻"))
	l1l111l1111l_l1_ = True
	while l1l111l1111l_l1_:
		l1llll1l11l1l_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭崼"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ崽"),l11lll_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ崾"),l11lll_l1_ (u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩ崿"),l11lll_l1_ (u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩ嵀"),l1l1ll11lll_l1_)
		if l1llll1l11l1l_l1_==2: l1llll1l11l11_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ嵁"),l11lll_l1_ (u"ࠫࠬ嵂"),l11lll_l1_ (u"ࠬ฿่ะหࠪ嵃"),l11lll_l1_ (u"࠭ࠧ嵄"),l11lll_l1_ (u"ࠧๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧ嵅"),l11l1111ll11_l1_,l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ嵆"))
		elif l1llll1l11l1l_l1_==1: l1l1lll11ll1_l1_()
		else: l1l111l1111l_l1_ = False
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ嵇"),l1l1lll1l11l_l1_(now))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ嵈"))
	return
def l1lll1lll1l1l_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ嵉"),l11lll_l1_ (u"ࠬ࠭嵊"),l11lll_l1_ (u"࠭ࠧ嵋"),l11lll_l1_ (u"ࠧิฦส่ࠬ嵌"),l11lll_l1_ (u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ嵍"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_:
		succeeded = True
		if os.path.exists(l1l1ll1l1lll_l1_):
			try: os.remove(l1l1ll1l1lll_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嵎"),l11lll_l1_ (u"ࠪࠫ嵏"),l11lll_l1_ (u"ࠫࠬ嵐"),l11lll_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤํะีโ์ิࠤ๊๊แࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ嵑"))
		else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嵒"),l11lll_l1_ (u"ࠧࠨ嵓"),l11lll_l1_ (u"ࠨࠩ嵔"),l11lll_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่่ࠢๆࠦวๅว฼ำฬีวหࠩ嵕"))
	return
def l1lllll111ll1_l1_():
	l1llll1l1l1ll_l1_()
	l1llllllll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ嵖"))
	message = {}
	message[l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ嵗")] = l11lll_l1_ (u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫ嵘")
	message[l11lll_l1_ (u"࠭ࡓࡕࡑࡓࠫ嵙")] = l11lll_l1_ (u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭嵚")
	message[l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ嵛")] = l11lll_l1_ (u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪ嵜")+str(l11ll1111ll_l1_/60)+l11lll_l1_ (u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧ嵝")
	l1llll111ll1l_l1_ = message[l1llllllll11l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࠬ嵞"),l11lll_l1_ (u"้ࠬวีࠢࠪ嵟")+str(l11ll1111ll_l1_/60)+l11lll_l1_ (u"࠭ࠠะไํๆฮ࠭嵠"),l11lll_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭嵡"),l11lll_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ嵢"),l1llll111ll1l_l1_,l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬ嵣"))
	if choice==0: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ嵤")
	elif choice==1: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ嵥")
	elif choice==2: l1llll111l1l1_l1_ = l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ嵦")
	else: l1llll111l1l1_l1_ = l11lll_l1_ (u"࠭ࠧ嵧")
	if l1llll111l1l1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ嵨"),l1llll111l1l1_l1_)
		l1lll1llllll1_l1_ = message[l1llll111l1l1_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嵩"),l11lll_l1_ (u"ࠩࠪ嵪"),l11lll_l1_ (u"ࠪࠫ嵫"),l1lll1llllll1_l1_)
	return
def l1llll11lll1l_l1_():
	message = {}
	message[l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ嵬")] = l11lll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪ嵭")
	message[l11lll_l1_ (u"࠭ࡁࡔࡍࠪ嵮")] = l11lll_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫ嵯")
	message[l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭嵰")] = l11lll_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ嵱")
	l1llllll1l111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ嵲"))
	l1llllllll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ嵳"))
	l1llll111ll1l_l1_ = message[l1llllllll11l_l1_]+l1llllll1l111_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭嵴"),l11lll_l1_ (u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ嵵"),l11lll_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭嵶"),l11lll_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ嵷"),l1llll111ll1l_l1_,l11lll_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭嵸"))
	if choice==0: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠪࡅࡘࡑࠧ嵹")
	elif choice==1: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ嵺")
	elif choice==2: l1llll111l1l1_l1_ = l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ嵻")
	if choice in [0,1]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭嵼"),l11lll_l1_ (u"ࠧิ์ิๅึࡀࠠࠨ嵽")+l1lll1l1l1ll_l1_[1],l11lll_l1_ (u"ࠨีํีๆื࠺ࠡࠩ嵾")+l1lll1l1l1ll_l1_[0],l11lll_l1_ (u"ࠩࠪ嵿"),l11lll_l1_ (u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩ嶀"))
		if l1ll111ll1_l1_==1: l1111ll111l_l1_ = l1lll1l1l1ll_l1_[0]
		else: l1111ll111l_l1_ = l1lll1l1l1ll_l1_[1]
	elif choice==2: l1111ll111l_l1_ = l11lll_l1_ (u"ࠫࠬ嶁")
	else: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠬ࠭嶂")
	if l1llll111l1l1_l1_:
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭嶃"),l1llll111l1l1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ嶄"),l1111ll111l_l1_)
		l1lll1llllll1_l1_ = message[l1llll111l1l1_l1_]+l1111ll111l_l1_
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嶅"),l11lll_l1_ (u"ࠩࠪ嶆"),l11lll_l1_ (u"ࠪࠫ嶇"),l1lll1llllll1_l1_)
	return
def l1llll1ll11ll_l1_():
	l1llllllll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭嶈"))
	message = {}
	message[l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ嶉")] = l11lll_l1_ (u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧ嶊")
	message[l11lll_l1_ (u"ࠧࡂࡕࡎࠫ嶋")] = l11lll_l1_ (u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩ嶌")
	message[l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ嶍")] = l11lll_l1_ (u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ嶎")
	l1llll111ll1l_l1_ = message[l1llllllll11l_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࠬ嶏"),l11lll_l1_ (u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ嶐"),l11lll_l1_ (u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ嶑"),l11lll_l1_ (u"ࠧฦ์ๅหๆࠦใศ็็ࠫ嶒"),l1llll111ll1l_l1_,l11lll_l1_ (u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫ嶓"))
	if choice==0: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠩࡄࡗࡐ࠭嶔")
	elif choice==1: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ嶕")
	elif choice==2: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ嶖")
	else: l1llll111l1l1_l1_ = l11lll_l1_ (u"ࠬ࠭嶗")
	if l1llll111l1l1_l1_:
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ嶘"),l1llll111l1l1_l1_)
		l1lll1llllll1_l1_ = message[l1llll111l1l1_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嶙"),l11lll_l1_ (u"ࠨࠩ嶚"),l11lll_l1_ (u"ࠩࠪ嶛"),l1lll1llllll1_l1_)
	return
def l1lllll11lll1_l1_():
	l1l111l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ嶜"))
	if l1l111l1ll11_l1_==l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ嶝"): header = l11lll_l1_ (u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ嶞")
	else: header = l11lll_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ嶟")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࠨ嶠"),l11lll_l1_ (u"ࠨวํๆฬ็ࠧ嶡"),l11lll_l1_ (u"ࠩอๅ฾๐ไࠨ嶢"),header,l11lll_l1_ (u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮่ๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭嶣"))
	if l1ll111ll1_l1_==-1: return
	elif l1ll111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ嶤"),l11lll_l1_ (u"ࠬ࠭嶥"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嶦"),l11lll_l1_ (u"ࠧࠨ嶧"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嶨"),l11lll_l1_ (u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫ嶩"))
	else:
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ嶪"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ嶫"))
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭嶬"),l11lll_l1_ (u"࠭ࠧ嶭"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ嶮"),l11lll_l1_ (u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ嶯"))
	return
def l1llll1l1ll11_l1_(text):
	if text!=l11lll_l1_ (u"ࠩࠪ嶰"):
		text = l1l111lllll_l1_(text)
		text = text.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ嶱")).encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嶲"))
		l1l11l111l1_l1_ = 10103
		l1l11l11111_l1_ = xbmcgui.l1l111ll111_l1_(l1l11l111l1_l1_)
		l1l11l11111_l1_.getControl(311).l1l11l11l1l_l1_(text)
		#l1l11l1llll1_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡐ࡫ࡹࡣࡱࡤࡶࡩ࠸࠲࠯ࡺࡰࡰࠬ嶳"), xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ嶴")).decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嶵")),l11lll_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ嶶"),l11lll_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ嶷"))
		#l1l11l1llll1_l1_.show()
		#l1l11l1llll1_l1_.getControl(99991).setPosition(0,0)
		#l1l11l1llll1_l1_.getControl(311).l1l11l11l1l_l1_(text)
		#l1l11l1llll1_l1_.getControl(5).l1ll1lll11ll_l1_(l1llllll11l11_l1_)
		#width = xbmcgui.l1llll1111ll1_l1_()
		#l1ll1111l1ll_l1_ = xbmcgui.l1llll1llllll_l1_()
		#resolution = (0.0+width)/l1ll1111l1ll_l1_
		#l1l11l1llll1_l1_.getControl(5).l1l11l1l1111_l1_(width-180)
		#l1l11l1llll1_l1_.getControl(5).setHeight(l1ll1111l1ll_l1_-180)
		#l1l11l1llll1_l1_.doModal()
		#del l1l11l1llll1_l1_
	return
l1lll1lll11l1_l1_ = [
			 l11lll_l1_ (u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࠧࠨࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣ嶸")
			,l11lll_l1_ (u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧ嶹")
			,l11lll_l1_ (u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧ嶺")
			,l11lll_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨ嶻")
			,l11lll_l1_ (u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨ嶼")
			,l11lll_l1_ (u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪ嶽")
			,l11lll_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠤࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧ嶾")
			,l11lll_l1_ (u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭嶿")
			,l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡁ࠵ࠬࡴࡦࡺࡷࡁࠬ巀")
			,l11lll_l1_ (u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭巁")
			,l11lll_l1_ (u"࠭࡞࡟ࡠࡡࡢࠬ巂")
			,l11lll_l1_ (u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬ巃")
			]
def l1llll1l11111_l1_(line):
	if l11lll_l1_ (u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭巄") in line and l11lll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ巅") in line: return True
	for text in l1lll1lll11l1_l1_:
		if text in line: return True
	return False
def l1lll1ll1111l_l1_(data):
	data = data.replace(l11lll_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ巆")+51*l11lll_l1_ (u"ࠫࠥ࠭巇")+l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ巈"),l11lll_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ巉"))
	data = data.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ巊")+51*l11lll_l1_ (u"ࠨࠢࠪ巋")+l11lll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ巌"),l11lll_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ巍"))
	data = data.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ巎")+51*l11lll_l1_ (u"ࠬࠦࠧ巏")+l11lll_l1_ (u"࠭࡜࡯ࠩ巐"),l11lll_l1_ (u"ࠧ࡝ࡰࠪ巑"))
	data = data.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ巒")+51*l11lll_l1_ (u"ࠩࠣࠫ巓"),l11lll_l1_ (u"ࠪࡠࡳ࠭巔")+31*l11lll_l1_ (u"ࠫࠥ࠭巕"))
	#data = data.replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰࠰ࡃࡱࡨࡷࡵࡩࡥ࠱ࡧࡥࡹࡧ࠯ࡰࡴࡪ࠲ࡽࡨ࡭ࡤ࠰࡮ࡳࡩ࡯࠯ࡧ࡫࡯ࡩࡸ࠵࠮࡬ࡱࡧ࡭࠴ࡧࡤࡥࡱࡱࡷ࠴࠭巖"),l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠫ巗"))
	data = data.replace(l11lll_l1_ (u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭巘"),l11lll_l1_ (u"ࠨ࠼ࠣࠫ巙"))
	l11llll11_l1_ = l11lll_l1_ (u"ࠩࠪ巚")
	for line in data.splitlines():
		delete = re.findall(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ巛"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11lll_l1_ (u"ࠫࠬ巜"))
		l11llll11_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ川")+line
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ州"),l11llll11_l1_)
	return l11llll11_l1_
def l1lll1ll1lll1_l1_(l1llll1lll11l_l1_):
	if l11lll_l1_ (u"ࠧࡐࡎࡇࠫ巟") in l1llll1lll11l_l1_:
		l1llllll1l11l_l1_ = l1ll1lllll1l_l1_
		header = l11lll_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ巠")
	else:
		l1llllll1l11l_l1_ = l1ll1l1l111l_l1_
		header = l11lll_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ巡")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ巢"),l11lll_l1_ (u"ࠫࠬ巣"),l11lll_l1_ (u"ࠬ࠭巤"),header,l11lll_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ工"))
	if l1ll111ll1_l1_!=1: return
	l1lll1ll11l1l_l1_,counts = [],0
	size,count = l1l1l11ll1_l1_(l1llllll1l11l_l1_)
	#size = os.path.getsize(l1llllll1l11l_l1_)
	file = open(l1llllll1l11l_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ左"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭巧"))
	data = l1lll1ll1111l_l1_(data)
	lines = data.split(l11lll_l1_ (u"ࠩ࡟ࡲࠬ巨"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ巩"))
		#if line.strip(l11lll_l1_ (u"ࠫࠥ࠭巪"))==l11lll_l1_ (u"ࠬ࠭巫"): continue
		ignore = l1llll1l11111_l1_(line)
		if ignore: continue
		line = line.replace(l11lll_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡤ࠭巬"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ巭"))
		line = line.replace(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ差"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬ巯"))
		l1llll1lll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ巰")
		l1lll1lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ己"),line,re.DOTALL)
		if l1lll1lll111l_l1_:
			line = line.replace(l1lll1lll111l_l1_[0][0],l1lll1lll111l_l1_[0][1]).replace(l1lll1lll111l_l1_[0][2],l11lll_l1_ (u"ࠬ࠭已"))
			l1llll1lll1ll_l1_ = l1lll1lll111l_l1_[0][1]
		else:
			l1lll1lll111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭巳"),line,re.DOTALL)
			if l1lll1lll111l_l1_:
				line = line.replace(l1lll1lll111l_l1_[0][1],l11lll_l1_ (u"ࠧࠨ巴"))
				l1llll1lll1ll_l1_ = l1lll1lll111l_l1_[0][0]
		if l1llll1lll1ll_l1_: line = line.replace(l1llll1lll1ll_l1_,l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ巵")+l1llll1lll1ll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ巶"))
		l1lll1ll11l1l_l1_.append(line)
		if len(str(l1lll1ll11l1l_l1_))>50100: break
	l1lll1ll11l1l_l1_ = reversed(l1lll1ll11l1l_l1_)
	l1llllll11l11_l1_ = l11lll_l1_ (u"ࠪࡠࡳ࠭巷").join(l1lll1ll11l1l_l1_)
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ巸"),l11lll_l1_ (u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ巹"),l1llllll11l11_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ巺"))
	return
def l1llll11ll1l1_l1_():
	l1llllll1l1l1_l1_ = open(l1l1lll11l11_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ巻")).read()
	if kodi_version>18.99: l1llllll1l1l1_l1_ = l1llllll1l1l1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭巼"))
	l1llllll1l1l1_l1_ = l1llllll1l1l1_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡸࠬ巽"),l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬ巾"))
	l1l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ巿"),l1llllll1l1l1_l1_,re.DOTALL)
	for line in l1l111lll11l_l1_:
		l1llllll1l1l1_l1_ = l1llllll1l1l1_l1_.replace(line,l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ帀")+line+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ币"))
	DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨ市"),l1llllll1l1l1_l1_)
	return
def l1lllll11ll1l_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪ布")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭帄")
	l11l1111ll11_l1_ = l11lll_l1_ (u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭帅")
	message = l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠫ࠿ࠦࠧ帆")+l1l1ll11lll_l1_+l11lll_l1_ (u"ࠬࠦ࠮ࠡࠩ帇")+l11l1111ll11_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭师"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ帉"),message,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ帊"))
	return
def l1111ll11l1_l1_(type,message,l1ll_l1_=True,url=l11lll_l1_ (u"ࠩࠪ帋"),source=l11lll_l1_ (u"ࠪࠫ希"),text=l11lll_l1_ (u"ࠫࠬ帍"),l11l1l1111l1_l1_=l11lll_l1_ (u"ࠬ࠭帎")):
	l1lll1l1lll11_l1_ = True
	if not l11ll11111l_l1_(l11lll_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ帏")):
		if l1ll_l1_:
			#if message.count(l11lll_l1_ (u"ࠧ࡝࡞ࡱࠫ帐"))>1: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ帑")
			#else: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ帒")
			l1lll1llll11l_l1_ = (l11lll_l1_ (u"ࠪหู้ืา࠼ࠪ帓") in message and l11lll_l1_ (u"ࠫฬ๊ๅไษ้࠾ࠬ帔") in message and l11lll_l1_ (u"ࠬอไๆๆไ࠾ࠬ帕") in message and l11lll_l1_ (u"࠭วๅะฺวࠬ帖") in message and l11lll_l1_ (u"ࠧศๆู่ิื࠺ࠨ帗") in message)
			if not l1lll1llll11l_l1_: l1lll1l1lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ帘"),l11lll_l1_ (u"ࠩࠪ帙"),l11lll_l1_ (u"ࠪࠫ帚"),l11lll_l1_ (u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ帛"),message.replace(l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ帜"),l11lll_l1_ (u"࠭࡜࡯ࠩ帝")))
	elif l1ll_l1_:
		message = l11lll_l1_ (u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧ帞")
		l1lllllllll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ帟"),l11lll_l1_ (u"ࠩࠪ帠"),l11lll_l1_ (u"ࠪࠫ帡"),l11lll_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ帢")+l11lll_l1_ (u"ࠬࠦࠠ࠲࠱࠸ࠫ帣"),l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ帤"))
		l1llllllll1ll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ帥"),l11lll_l1_ (u"ࠨࠩ带"),l11lll_l1_ (u"ࠩࠪ帧"),l11lll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ帨")+l11lll_l1_ (u"ࠫࠥࠦ࠲࠰࠷ࠪ帩"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ帪"))
		l1llllllll1l1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭師"),l11lll_l1_ (u"ࠧࠨ帬"),l11lll_l1_ (u"ࠨࠩ席"),l11lll_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ帮")+l11lll_l1_ (u"ࠪࠤࠥ࠹࠯࠶ࠩ帯"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ帰"))
		l1lllllllllll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ帱"),l11lll_l1_ (u"࠭ࠧ帲"),l11lll_l1_ (u"ࠧࠨ帳"),l11lll_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ帴")+l11lll_l1_ (u"ࠩࠣࠤ࠹࠵࠵ࠨ帵"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ帶"))
		l1lll1l1lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ帷"),l11lll_l1_ (u"ࠬ࠭常"),l11lll_l1_ (u"࠭ࠧ帹"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ帺")+l11lll_l1_ (u"ࠨࠢࠣ࠹࠴࠻ࠧ帻"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ帼"))
	user = l11llll1l1l_l1_(32,False)
	l1lllll1ll111_l1_ = l11lll_l1_ (u"ࠪࡅ࡛ࡀࠠࠨ帽")+user+l11lll_l1_ (u"ࠫ࠲࠭帾")+type
	l1l111ll11ll_l1_ = True if l11lll_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ帿") in text else False
	if not l1lll1l1lll11_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ幀"),l11lll_l1_ (u"ࠧࠨ幁"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ幂"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠥฮๆศรࠣ฽้๏ุࠠๆห็ࠬ幃"))
		return False
	l11111111111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩ幄"))
	message += l11lll_l1_ (u"ࠫࠥࡢ࡜࡯࡞࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡢ࡜࡯ࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪ幅")+l11ll111l11_l1_+l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ幆")
	message += l11lll_l1_ (u"࠭ࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧ幇")+user+l11lll_l1_ (u"ࠧࠡ࠼࡟ࡠࡳࡑ࡯ࡥ࡫࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭幈")+l11lll11lll_l1_+l11lll_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ幉")
	message += l11lll_l1_ (u"ࠩࡎࡳࡩ࡯ࠠࡏࡣࡰࡩ࠿ࠦࠧ幊")+l11111111111_l1_
	#l11lll111l1_l1_ = l11l1ll1l11_l1_(l11lll_l1_ (u"ࠪ࠻࠻࠴࠶࠶࠰࠴࠷࠽࠴࠲࠴࠲ࠪ幋"))
	l1lll1lll1ll_l1_ = l11l1ll1l11_l1_()
	l1lll1lll1ll_l1_ = QUOTE(l1lll1lll1ll_l1_)
	if l1lll1lll1ll_l1_: message += l11lll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭幌")+l1lll1lll1ll_l1_
	if url: message += l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩ幍")+url
	if source: message += l11lll_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭幎")+source
	message += l11lll_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭幏")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧ幐"),l11lll_l1_ (u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫ幑"))
	if l11l1l1111l1_l1_:
		l1llllll11l11_l1_ = l11l1l1111l1_l1_
		if kodi_version>18.99: l1llllll11l11_l1_ = l1llllll11l11_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幒"))
		l1llllll11l11_l1_ = base64.b64encode(l1llllll11l11_l1_)
	elif l1l111ll11ll_l1_:
		if l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫ幓") in text: l1llllllll111_l1_ = l1ll1lllll1l_l1_
		else: l1llllllll111_l1_ = l1ll1l1l111l_l1_
		if not os.path.exists(l1llllllll111_l1_):
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭幔"),l11lll_l1_ (u"࠭ࠧ幕"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ幖"),l11lll_l1_ (u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭幗"))
			return False
		l1lll1ll11l1l_l1_,counts = [],0
		size,count = l1l1l11ll1_l1_(l1llllllll111_l1_)
		#size = os.path.getsize(l1llllllll111_l1_)
		file = open(l1llllllll111_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ幘"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幙"))
		data = l1lll1ll1111l_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ幚"))
			ignore = l1llll1l11111_l1_(line)
			if ignore: continue
			l1lll1lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ幛"),line,re.DOTALL)
			if l1lll1lll111l_l1_:
				line = line.replace(l1lll1lll111l_l1_[0][0],l1lll1lll111l_l1_[0][1]).replace(l1lll1lll111l_l1_[0][2],l11lll_l1_ (u"࠭ࠧ幜"))
			else:
				l1lll1lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ幝"),line,re.DOTALL)
				if l1lll1lll111l_l1_: line = line.replace(l1lll1lll111l_l1_[0][1],l11lll_l1_ (u"ࠨࠩ幞"))
			l1lll1ll11l1l_l1_.append(line)
			if len(str(l1lll1ll11l1l_l1_))>121000: break
		l1lll1ll11l1l_l1_ = reversed(l1lll1ll11l1l_l1_)
		l1llllll11l11_l1_ = l11lll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ幟").join(l1lll1ll11l1l_l1_)
		l1llllll11l11_l1_ = l1llllll11l11_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幠"))
		l1llllll11l11_l1_ = base64.b64encode(l1llllll11l11_l1_)
	else: l1llllll11l11_l1_ = l11lll_l1_ (u"ࠫࠬ幡")
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ幢")][2]
	payload = {l11lll_l1_ (u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ幣"):l1lllll1ll111_l1_,l11lll_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ幤"):message,l11lll_l1_ (u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ幥"):l1llllll11l11_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ幦"),url,payload,l11lll_l1_ (u"ࠪࠫ幧"),l11lll_l1_ (u"ࠫࠬ幨"),l11lll_l1_ (u"ࠬ࠭幩"),l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ幪"))
	#succeeded = response.succeeded
	html = response.content
	if l11lll_l1_ (u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ幫") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠬ幬"),l11lll_l1_ (u"ࠩห๊ัออࠨ幭"))
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ幮"),l11lll_l1_ (u"ࠫࠬ幯"),l11lll_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫ幰"),l11lll_l1_ (u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ幱"))
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧๅๆฦืๆ࠭干"),l11lll_l1_ (u"ࠨใื่ࠥ็๊ࠡษ็ษึูวๅࠩ平"))
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ年"),l11lll_l1_ (u"ࠪࠫ幵"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ并"),l11lll_l1_ (u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ幷"))
	return succeeded
def l1lll1l1llll1_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ幸")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢส่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ幹")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ幺"),l11lll_l1_ (u"ࠩࠪ幻"),l11lll_l1_ (u"ࠪࡅࡷࡧࡢࡪࡥࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ幼"),l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ幽")+l1l1ll11lll_l1_)
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠬ࠸࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠫ幾")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"࠭࠲࠯ࠢࠣࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโไ่ࠤอะฺ๋์ิࠤฬ๊ฬๅัࠣฯ๊ࠦโๆࠢหฮ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡษ็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭广")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ庀"),l11lll_l1_ (u"ࠨࠩ庁"),l11lll_l1_ (u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ庂"),l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ広")+l1l1ll11lll_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ庄"),l11lll_l1_ (u"ࠬ࠭庅"),l11lll_l1_ (u"࠭ࠧ庆"),l11lll_l1_ (u"ࠧࡇࡱࡱࡸࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧ庇"),l11lll_l1_ (u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࡮ࡰࡹࠣࡃࠬ庈")+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ庉")+l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ะ่ษหࠤส๊้ࠡๆ๋ัฮࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤศ๊ย็มࠪ床"))
	if l1ll111ll1_l1_==1: l1llllll11l1l_l1_()
	return
def l11111111l1l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ庋"),l11lll_l1_ (u"ࠬ࠭庌"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ庍"),l11lll_l1_ (u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭庎"))
	return
def l1llllll1llll_l1_():
	message = l11lll_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨ序")
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ庐"),l11lll_l1_ (u"ࠪࠫ庑"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ庒"),message)
	return
def l1llll1ll1111_l1_():
	message = l11lll_l1_ (u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ库")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ应"),l11lll_l1_ (u"ࠧࠨ底"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ庖"),message)
	return
def l1lll1l1ll1ll_l1_():
	message = l11lll_l1_ (u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭店")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ庘"),l11lll_l1_ (u"ࠫࠬ庙"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ庚"),l11lll_l1_ (u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨ庛"),message)
	return
def l1llllll11ll1_l1_():
	message = l11lll_l1_ (u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬ府")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ庝"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庞"),message,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭废"))
	return
def l1lllll11111l_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ庠")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ庡")
	l11l1111ll11_l1_ = l11lll_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ庢")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ庣"),l11lll_l1_ (u"ࠨࠩ庤"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ庥"),l1l1ll11ll1_l1_,l1l1ll11lll_l1_,l11l1111ll11_l1_)
	return
def l1llll1l1l1ll_l1_():
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ度")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ座") + l11lll_l1_ (u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ庨") + str(PERMANENT_CACHE/60/60/24/30) + l11lll_l1_ (u"࠭ࠠี้ิࠫ庩")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࠪ庪") + l11lll_l1_ (u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ庫") + str(VERYLONG_CACHE/60/60/24) + l11lll_l1_ (u"ࠩࠣ๎ํ๋ࠧ庬")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭庭") + l11lll_l1_ (u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ庮") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"๊้ࠬࠦ็ࠪ庯")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ庰") + l11lll_l1_ (u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ庱") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"ࠨࠢึห฾ฯࠧ庲")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ庳") + l11lll_l1_ (u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧ庴") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ูࠫࠥวฺหࠪ庵")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ庶") + l11lll_l1_ (u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ康") + str(l1ll1111l111_l1_/60) + l11lll_l1_ (u"ࠧࠡัๅ๎็ฯࠧ庸")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ庹") + l11lll_l1_ (u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ庺") + str(NO_CACHE) + l11lll_l1_ (u"ࠪࠤิ่๊ใหࠪ庻")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ庼") + l11lll_l1_ (u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ庽") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧ庾") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭庿") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ廀") + str(l1ll1111l111_l1_/60) + l11lll_l1_ (u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ廁") + str(NO_CACHE) + l11lll_l1_ (u"ࠪࠤิ่๊ใหࠪ廂")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ廃"),l11lll_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ廄"),l1l1ll11lll_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ廅"))
	return
def l1lll1lll1l11_l1_():
	message = l11lll_l1_ (u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ廆")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ廇"),l11lll_l1_ (u"ࠩࠪ廈"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭廉"),message)
	return
def l1llll111111l_l1_():
	message = l11lll_l1_ (u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ廊")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭廋"),l11lll_l1_ (u"࠭ࠧ廌"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ廍"),message)
	return
def l1lllll1l111l_l1_():
	message = l11lll_l1_ (u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ廎")
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ廏"),l11lll_l1_ (u"ࠪࠫ廐"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ廑"),message)
	return
def l1lll1lllll11_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭廒"),l11lll_l1_ (u"࠭ࠧ廓"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ廔"),l11lll_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭廕"))
	l111ll1ll1l_l1_(l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ廖"),True)
	return
def l1llll11l1l1l_l1_():
	message  = l11lll_l1_ (u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ廗")
	#message += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞๊๊ิฬࠦวๅ฻สส็ࠦ็้ࠢࡵࡩࡈࡇࡐࡕࡅࡋࡅࠥอไฯษุࠤอฺัไหࠣะําไ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ廘")
	#message += l11lll_l1_ (u"ࠬ๎วๅาํࠤฺ์ูหุ้ࠣึ้ษࠡฮ๋ะ้ࠦฮึ์ุห๊ࠥๅ็฻ࠣฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ๊์ࠠหืไัࠥอไฦ่อี๋ะࠧ廙")
	message += l11lll_l1_ (u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭廚")
	message += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิั࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ廛")
	message += l11lll_l1_ (u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ廜")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ廝"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭廞"),message,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ廟"))
	message = l11lll_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ廠")
	message += l11lll_l1_ (u"࠭࡜࡯ࠩ廡")+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ廢")
	message += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭廣")+l11lll_l1_ (u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ廤")
	message += l11lll_l1_ (u"ࠪࡠࡳ࠭廥")+l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ廦")
	message += l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ廧")+l11lll_l1_ (u"࠭วๅ็หี๊า้ࠠฮาࠤ฼ื๊ให่ࠣฯาว้ิࠣห้฿ววไࠣ์้้ๆ่ษࠣฮาะวอࠢฯ๋ิࠦใษ์ิࠤํอไๆสิ้ัู๊่ࠦࠣห้๋ิไๆฬࠤฺเ๊าหࠣ์้อࠠหีอั็ࠦวๅฬ฼ฬࠥ็ลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠษษ็ำำ๎ไࠡๆห฽฻ࠦวๅ็๋ห็฿้ࠠลํฺฬࠦไไ์ࠣ๎ฯ฼อࠡฯฯ้ࠥอไๆึๆ่ฮࠦࠧ廨")
	message += l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟สีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ廩")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ廪"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ廫"),message,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭廬"))
	#l1l1lll11ll1_l1_(l11lll_l1_ (u"ࠫࡎࡹࡐࡳࡱࡥࡰࡪࡳ࠽ࡇࡣ࡯ࡷࡪ࠭廭"))
	#message = l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ廮")+l11lll_l1_ (u"่࠭ๅไาࠤ้ออู่สࠤฬ๐ึศࠢฦ๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠหะอ่ๆࠦศศะอ่ฬ็ࠠศๆห่ิ่ࠦหะอ่ๆࠦศศะอ่ฬ็ࠠีำๆอࠥอไศ่อี๋๐สࠡใํࠤี๊ใࠡษ็ฬ้ี้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์็ࠡฯอํ๊่ࠥࠡฬ่ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥࡖࡲࡰࡺࡼࠤศ๎ࠠฤ์ࠣ์ุ๐ไสࠢสาึ๏ࠠโษ้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦำ้ใࠣฮำะไโ๋่่ࠢ์็ศࠢ็๊ࠥะูๆๆࠣะ๊๐ู่ษࠪ廯")
	#message += l11lll_l1_ (u"ࠧๅฯ็ࠤฬ๊ๅีๅ็อ่ࠥๅࠡส฼้้๐ๆ࠻ࠢࠣࠤࠥอไฤ๊็࠾ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า๊ࠩࠡส็ฯฮࠠๆ฻๊ࠤฬูๅࠡส็ำ่่ࠦศี่ࠤูืใสࠢส่ส์สา่ํฮࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠห฻่่ࠥ฿ๆะๅࠪ廰")
	#message += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭廱")+l11lll_l1_ (u"๋ࠩห้ัว็์࠽ࠤัืศࠡษึฮำีวๆ࡙ࠢࡔࡓฺ่่ࠦาࠤฬ๊ศฺุࠣๆิࠦสฮฬสะࠥ็โุࠢอ฾๏๐ัࠡࡆࡑࡗࠥ๎วๅละื๋ࠦร็ࠢํ็ํ์ࠠโ์ࠣฬ้ีࠠศะิࠤ฾๊ๅศࠢส๊ࠥอำหะาห๊ࠦࡐࡳࡱࡻࡽ่ࠥฯࠡ์ะ่๋ࠥิไๆฬࠤอ฿ึࠡษ็้ํอโฺ๋่่ࠢ์ࠠๅ์ึࠤๆ๐ࠠอ็ํ฽ࠥอไะ๊็ࠫ廲")
	#DIALOG_TEXTVIEWER(l11lll_l1_ (u"ู้้ࠪไสࠢ฼๊ิࠦศฺุࠣห้์วิࠩ廳"),message)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ廴"),l11lll_l1_ (u"ࠬ็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠨ廵"),l11lll_l1_ (u"࠭็ัษࠣห้็อึ๊ࠢ์๊ࠥๅฺำไอࠥํไࠡษ็ู้้ไส่๊ࠢࠥ฿ๆะๅࠣห๊ࠦๅ็ࠢส่อืๆศ็ฯ࠲ู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ็อึ่ࠢ์ฬู่่่ࠢีฯ๐ๆࠡษ็วํ๊้ࠡสฺ๋฾้ࠠศๆฺฬ๏฿๊๊ࠡส่ะอๆ๋หࠣฬฬูสฯัส้ࠥฮั้ๅึ๎๋ࠥฬศ่ํࠤฬ์สࠡฬัฮฬื็ࠡ็้ࠤฬ๊โศศ่อࠥอไห์ࠣืฯ฾็าࠢ็หา่ว࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึลࠧ延"),l11lll_l1_ (u"ࠧࠨ廷"),l11lll_l1_ (u"ࠨࠩ廸"),l11lll_l1_ (u"ࠩๆ่ฬ࠭廹"),l11lll_l1_ (u"๊ࠪ฾๋ࠧ建"))
	#if l1ll111ll1_l1_==1:
	#l1llll1ll1lll_l1_()
	return
def l1llll1l11lll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ廻"),l11lll_l1_ (u"ࠬ࠭廼"),l11lll_l1_ (u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭廽"),l11lll_l1_ (u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥฮวิฬัำฬ๋ࠠศๆไ๎ุฮ่ไࠢฦำ๋อ็࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱวํࠦศศำึห้ࠦว๋็ํ่ࠥอไ๊ࠢฦำ๋อ็ࠡࠢ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ廾"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ廿"),l11lll_l1_ (u"ࠩࠪ开"),l11lll_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ弁"),l11lll_l1_ (u"ࠫ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹࡜࡯࡞ࡱ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼࡟࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ异"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭弃"),l11lll_l1_ (u"࠭ࠧ弄"),l11lll_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弅"),l11lll_l1_ (u"ࠨ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠳ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡ࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ弆"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ弇"),l11lll_l1_ (u"ࠪࠫ弈"),l11lll_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ弉"),l11lll_l1_ (u"ࠬ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠫ弊"))
	#text = l11lll_l1_ (u"࠭ࠨࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࠡࠫࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠩ弋")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ弌"),l11lll_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ弍"),l11lll_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ弎"),l11lll_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ式"),l11lll_l1_ (u"ࠫ࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸࠲࠳࠴࠵࠶ࠬ弐"),text,l11lll_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ弑"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࠧ弒"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弓"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ弔"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ引"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弖"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ弗"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭弘"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭弙"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弚"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ弛"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭弜"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ弝"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࠬ弞"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ弟"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭张"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弡"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭弢"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭弣"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ弤"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ弥"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ弦"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭弧"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊ࡟ࡲࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ弨"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ弩"))
	return
def l1llll1l111ll_l1_():
	l1llll1l1l1ll_l1_()
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ弪"),l11lll_l1_ (u"ࠪࠫ弫"),l11lll_l1_ (u"ࠫࠬ弬"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡษ็็ฬฺࠠภࠩ弭"),l11lll_l1_ (u"࠭วๅๅสุࠥ๐ำา฻ࠣ฽๊๊ࠠศๆหี๋อๅอุ๋้ࠢำ็ࠡ์฼๎ิࠦำฮสࠣห้฻แฮษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢ฼๊ิࠦวๅฯสะฮࠦลๅ์๊หࠥ๎วๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ๎วๅ็ึั๊ࠥวࠡ์ูีࠥ๎ๅๆๅ้ࠤ๏ำไࠡส฼ฺࠥอไๆึส็้࠭弮"))
	if l1ll111ll1_l1_==1:
		l111l1l1111_l1_(True)
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ弯"),l11lll_l1_ (u"ࠨࠩ弰"),l11lll_l1_ (u"ࠩอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡสส่่อๅๅࠩ弱"),l11lll_l1_ (u"ࠪษีอࠠไษ้ฮࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥออะࠢส่๊๎วใ฻ࠣๅัืศࠡษ็้ํู่ࠡษ็ฦ๋ࠦ࠮࠯࠰ࠣ์ศึวࠡษ็ู้้ไส่ࠢืฯ๋ัสࠢไษี์ࠠศำึ่ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫ弲"))
	return l1ll111ll1_l1_
def l1lll111111l_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ弳"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫ弴"),l11lll_l1_ (u"࠭ࠧ張"),l11lll_l1_ (u"ࠧࠨ弶"),False,l11lll_l1_ (u"ࠨࠩ強"),l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ弸"))
	#html = response.content
	if not response.succeeded:
		l1llll11l11l1_l1_ = False
		l11l1lll11_l1_ = l11l1l1l1l_l1_()
		LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ弹"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡉࡖࡗࡔࡘࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡎࡤࡦࡪࡲ࠺࡜ࠩ强")+l11l1lll11_l1_+l11lll_l1_ (u"ࠬࡣࠧ弻"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ弼"),l11lll_l1_ (u"ࠧࠨ弽"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ弾"),l11lll_l1_ (u"ࠩไัฺࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠ࠯࠰࠱ࠤฺ๊ใๅหࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠡ฻็ํ้่ࠥะ์ࠣ࠲࠳࠴้ࠠ฻้ำ่ࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭弿"))
	else:
		l1llll11l11l1_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ彀"),l11lll_l1_ (u"ࠫࠬ彁"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彂"),l11lll_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪ彃"))
	if not l1llll11l11l1_l1_ and l1ll_l1_: l1lllll111111_l1_()
	return l1llll11l11l1_l1_
def l1lllll111111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ彄"),l11lll_l1_ (u"ࠨࠩ彅"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ彆"),l11lll_l1_ (u"ࠪฬ฾฼ࠠศๆ่์ฬู่ࠡฬะฮฬาࠠาสฺࠤฺ๊แา๋ࠢๆิ๊ࠦไ๊้ࠤัํวำๅࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢส่ึฮืࠡษ็ู้็ัࠡล๋ࠤ์์วไุ่่๊ࠢษࠡใํࠤูํวะหࠣห้ะิโ์ิࠤฬ๊ฮศืฬࠤอ้่ะ์ࠣ฽๋ีใࠡ฻็้ฬࠦว็้ࠣฮ๊ࠦแฮืࠣห้ฮั็ษ่ะࠥ฿ไ๊ࠢๆ์ิ๐ࠠศๆศูิอัศฬࠣࡠࡳࠦ࠱࠸࠰࠹ࠤࠥࠬࠠࠡ࠳࠻࠲ࡠ࠶࠭࠺࡟ࠣࠤࠫࠦࠠ࠲࠻࠱࡟࠵࠳࠳࡞ࠩ彇"))
	#l1l1ll11lll_l1_ = l11lll_l1_ (u"ูࠫํวะหࠣห้ะิโ์ิࠤ์๐ࠠๆๆไࠤ๏ำส้์ࠣ฽้๏ࠠีใิอࠥิวึหࠣวํࠦส้ษๅ๎฾ࠦฮศืฬࠤฺ้ัไษอࠤ๊฿ั้ใฬࠤํ๊็ࠡฬสี๏ิࠠึๆสั๏ฯ้่ࠠไหี่ࠦศๆ฽ี฻ࠦๅ็้๋ࠣํࠦสษษา่ࠥอไๆ฻็์๊อสࠡสฺี๏่ษࠡ็ืๅึฯ๋ࠠื฼ฬࠥอฮหำสๆ์อ้ࠠใ๊้์อࠧ彈")
	l1lllll1l11l1_l1_()
	return
def l1l1lll11ll1_l1_(text=l11lll_l1_ (u"ࠬ࠭彉")):
	l1l111ll11ll_l1_ = True
	if l11lll_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ彊") not in text:
		l1l111ll11ll_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ彋"),l11lll_l1_ (u"ࠨะิ์ั࠭彌"),l11lll_l1_ (u"ࠩศีุอไࠡ็ื็้ฯࠧ彍"),l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠨ彎"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ彏"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨ彐"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l111ll11ll_l1_ = True
			text = l11lll_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ彑")
	if l1l111ll11ll_l1_:
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ归"),l11lll_l1_ (u"ࠨࠩ当"),l11lll_l1_ (u"ࠩࠪ彔"),l11lll_l1_ (u"ࠪษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠫ录"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ึฮ฼๐ูࠡษ็้อืๅอ่ࠢ฽ึ็ษࠡษ็ู้้ไส๋ࠢษฺ๊วฮ้สࠫ彖"))
		#if not l1ll111ll1_l1_:
		#	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭彗"),l11lll_l1_ (u"࠭ࠧ彘"),l11lll_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ彙"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ彚"))
		#	return
		l11lll_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࡷࡩࡽࡺࠠࠬ࠿ࠣࠫࡱࡵࡧࡴ࠿ࡼࡩࡸ࠭ࠊࠊࠋࠌࡽࡪࡹࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡ࡜ࡉࡘࡔࡏࠩࠩࡦࡩࡳࡺࡥࡳࠩ࠯ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ࠰่ࠬศๅࠢสีุอไࠡีฯ่ࠥอไศะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻็๎่ࠦว็ࠢอๆํ๋ࠠษฬื฾๏๊ࠠศๆไ๎ิ๐่ࠡษ๋ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢํ฽฼๐ใࠡษ็ู้้ไสࠢ็็๏๊ࠦห็ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅ࠯๊่ࠢࠥะั๋ัࠣห้อัิษ็ࠤฬ๊ว็ࠢยࠫ࠱࠭ࠧ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠍࠍࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠱࠼ࠍࠍࠎࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭สๆࠢส่฿อมࠡษ็หึูวๅࠩࠬࠎࠎࠏࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࠩࠪࠎࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࠰ࠬอะศࠢๆห๋ะࠠๅัํ็๋ࠥิไๆฬࠤๆอไาฮสล่ࠥัศรฬࠤ็ูๅࠡษ็ู้อใๅ๋ࠢห้อำวๆฬࠤํอะศࠢ็้ࠥะฬะࠢส่า๊่่ࠠส็ࠥ็อศ๊็ࠤ่ะวษหࠣะ๊๐ูࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧࠪࠌࠌࠍࠧࠨࠢ彛")
		if l11lll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ彜") not in text:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ彝"),l11lll_l1_ (u"ࠬ࠭彞"),l11lll_l1_ (u"࠭ࠧ彟"),l11lll_l1_ (u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧ彠"),l11lll_l1_ (u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨ彡"))
			if l1ll111ll1_l1_!=1:
				DIALOG_OK(l11lll_l1_ (u"ࠩࠪ形"),l11lll_l1_ (u"ࠪࠫ彣"),l11lll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧ彤"),l11lll_l1_ (u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ彥"))
				return
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ彦"),l11lll_l1_ (u"ࠧࠨ彧"),l11lll_l1_ (u"ࠨๅอหอฯ้ࠠึิัࠥอไๆู๊์฾ࠦไๅ็หี๊าࠧ彨"),l11lll_l1_ (u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆส๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭彩"))
	search = OPEN_KEYBOARD(header=l11lll_l1_ (u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࠦࠠศๅอฬࠥืำศๆฬࠫ彪"),source=script_name)
	if not search: return
	message = search
	if l1l111ll11ll_l1_: type = l11lll_l1_ (u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬ彫")
	else: type = l11lll_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭彬")
	succeeded = l1111ll11l1_l1_(type,message,True,l11lll_l1_ (u"࠭ࠧ彭"),l11lll_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ彮"),text)
	#	url = l11lll_l1_ (u"ࠨ࡯ࡼࠤࡆࡖࡉࠡࡣࡱࡨ࠴ࡵࡲࠡࡕࡐࡘࡕࠦࡳࡦࡴࡹࡩࡷ࠭彯")
	#	payload = l11lll_l1_ (u"ࠩࡾࠦࡦࡶࡩࡠ࡭ࡨࡽࠧࡀࠢࡎ࡛ࠣࡅࡕࡏࠠࡌࡇ࡜ࠦ࠱ࠨࡴࡰࠤ࠽࡟ࠧࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠦࡢ࠲ࠢࡴࡧࡱࡨࡪࡸࠢ࠻ࠤࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠣ࠮ࠥࡷࡺࡨࡪࡦࡥࡷࠦ࠿ࠨࡆࡳࡱࡰࠤࡆࡸࡡࡣ࡫ࡦࠤ࡛࡯ࡤࡦࡱࡶࠦ࠱ࠨࡴࡦࡺࡷࡣࡧࡵࡤࡺࠤ࠽ࠦࠬ彰")+message+l11lll_l1_ (u"ࠪࠦࢂ࠭影")
	#	#auth=(l11lll_l1_ (u"ࠦࡦࡶࡩࠣ彲"), l11lll_l1_ (u"ࠧࡳࡹࠡࡲࡨࡶࡸࡵ࡮ࡢ࡮ࠣࡥࡵ࡯ࠠ࡬ࡧࡼࠦ彳")),
	#	import requests
	#	response = requests.request(l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ彴"),url, data=payload, headers=l11lll_l1_ (u"ࠧࠨ彵"), auth=l11lll_l1_ (u"ࠨࠩ彶"))
	#	response = requests.post(url, data=payload, headers=l11lll_l1_ (u"ࠩࠪ彷"), auth=l11lll_l1_ (u"ࠪࠫ彸"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ役"),l11lll_l1_ (u"ࠬ࠭彺"),l11lll_l1_ (u"࠭ࠧ彻"),l11lll_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ彼"))
	#	else:
	#		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ彽"),l11lll_l1_ (u"ࠩࠪ彾"),l11lll_l1_ (u"ࠪา฼ษࠠโ์ࠣห้หัิษ็ࠫ彿"),l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࡿࢂࡀࠠࡼࠣࡵࢁࠬ往").format(response.status_code, response.content))
	#	l1llll111l1ll_l1_ = l11lll_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ征")
	#	l1llll1l11ll1_l1_ = l11lll_l1_ (u"࠭࡭ࡦࡂࡨࡱࡦ࡯࡬࠯ࡥࡲࡱࠬ徂")
	#	header = l11lll_l1_ (u"ࠧࠨ徃")
	#	#header += l11lll_l1_ (u"ࠨࡈࡵࡳࡲࡀࠠࠨ径") + l1llll111l1ll_l1_
	#	#header += l11lll_l1_ (u"ࠩ࡟ࡲ࡙ࡵ࠺ࠡࠩ待") + l1lll1l1ll1l1_l1_
	#	#header += l11lll_l1_ (u"ࠪࡠࡳࡉࡣ࠻ࠢࠪ徆") + l1lll1l1ll1l1_l1_
	#	header += l11lll_l1_ (u"ࠫࡡࡴࡓࡶࡤ࡭ࡩࡨࡺ࠺ࠡ็้ࠤ่๎ฯ๋ࠢส่ๆ๐ฯ๋๊ࠣห้฿ัษ์ࠪ徇")
	#	server = l1lllllll1l1l_l1_.l1llll11l1lll_l1_(l11lll_l1_ (u"ࠬࡹ࡭ࡵࡲ࠰ࡷࡪࡸࡶࡦࡴࠪ很"),25)
	#	#server.l1llll1ll11l1_l1_()
	#	server.l1llll1ll1ll1_l1_(l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥࠨ徉"),l11lll_l1_ (u"ࠧࡱࡣࡶࡷࡼࡵࡲࡥࠩ徊"))
	#	response = server.l1lllll11l111_l1_(l1llll111l1ll_l1_,l1llll1l11ll1_l1_, header + l11lll_l1_ (u"ࠨ࡞ࡱࠫ律") + message)
	#	server.quit()
	return
def l1llllll11111_l1_():
	text = l11lll_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭後")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ徍"),l11lll_l1_ (u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫ徎"),text,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ徏"))
	text = l11lll_l1_ (u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩ徐")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ徑"),l11lll_l1_ (u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭徒"),text,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ従"))
	return
def l1llll1ll1l11_l1_(addon_id):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ徔"),l11lll_l1_ (u"ࠫࠬ徕"),l11lll_l1_ (u"ࠬ࠭徖"),addon_id)
	result = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ得")+addon_id+l11lll_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭徘"))
	l1l11llll1_l1_ = True
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡹࡨࡶࡶ࡬ࡰࠏࠏࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡻࡦࡲࡩࡦࡰ࡮ࡧࡩࡷ࠲ࠧࡢࡦࡧࡳࡳࡹࠧ࠭ࡣࡧࡨࡴࡴ࡟ࡪࡦࠬࠎࠎ࡯ࡦࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰ࡨࡼ࡮ࡹࡴࡴࠪࡻࡦࡲࡩࡦࡪ࡮ࡨ࠭࠿ࠐࠉࠊࡵ࡫ࡹࡹ࡯࡬࠯ࡴࡰࡸࡷ࡫ࡥࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡲࡦࡨࡵࡩࡸ࡮ࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡺࡹࡥࡳࡨࡲࡰࡩ࡫ࡲ࠭ࠩࡤࡨࡩࡵ࡮ࡴࠩ࠯ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮ࠐࠉࡪࡨࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲ࡪࡾࡩࡴࡶࡶࠬࡺࡹࡥࡳࡨ࡬ࡰࡪ࠯࠺ࠋࠋࠌࡷ࡭ࡻࡴࡪ࡮࠱ࡶࡲࡺࡲࡦࡧࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡴࡨࡪࡷ࡫ࡳࡩࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠧ࡮ࡳࡰࡰࡴࡷࠤࡸࡷ࡬ࡪࡶࡨ࠷ࠏࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡣࡧࡨࡴࡴࡳࡠࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࡤࡥࠣࡁࠥࡩ࡯࡯ࡰ࠱ࡧࡺࡸࡳࡰࡴࠫ࠭ࠏࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡤࡨࡩࡵ࡮ࡴ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࠧࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡳࡧࡳࡳࡸࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠣࠢ࠾ࠫ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡯࡮࡯࡬ࡸ࠭࠯ࠊࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠤࠥࠦ徙")
	if l1l11llll1_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭徚"))
		time.sleep(1)
	return
def l1lllll11llll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ徛"),l11lll_l1_ (u"ࠫࠬ徜"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ徝"),l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫ從"))
	l1lllll1l111l_l1_()
	return
def l1lllll1l11l1_l1_():
	#	https://l1111ll1l1l_l1_.tv/download/849
	#   https://play.google.com/l1llll11lllll_l1_/l1llll1ll111l_l1_/details?id=l1ll1lll111_l1_.xbmc.l1111ll1l1l_l1_
	#	http://mirror.l1lllll11l1ll_l1_.l1llll111ll11_l1_.l111111111ll_l1_/l1lllll111l11_l1_/xbmc/l1llll11ll1ll_l1_/l1lll1ll11111_l1_/l1lllll111lll_l1_
	#	http://l1lll1lllll1l_l1_.l1lll1ll1l1ll_l1_.l111111111ll_l1_/l1111ll1l1l_l1_/l1llll11ll1ll_l1_/l1lll1ll11111_l1_/l1lllll111lll_l1_
	url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬ徟")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ徠"),url,l11lll_l1_ (u"ࠩࠪ御"),l11lll_l1_ (u"ࠪࠫ徢"),l11lll_l1_ (u"ࠫࠬ徣"),l11lll_l1_ (u"ࠬ࠭徤"),l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩ徥"))
	html = response.content
	l1lll1ll1l111_l1_ = re.findall(l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭徦"),html,re.DOTALL)
	l1lll1ll1l111_l1_ = l1lll1ll1l111_l1_[0].split(l11lll_l1_ (u"ࠨ࠯ࠪ徧"))[0]
	l1llllllllll1_l1_ = str(kodi_version)
	#l11l1111ll1l_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ徨")+l11lll_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์฼้้ࠦๅฺࠢๆ์ิ๐ࠠฦืาหึࠦ࠱࠺๋้ࠢฬࠦศฺั๊ࠫ復")+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭循")
	l11l1111ll1l_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧ徫")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ徬")+l1lll1ll1l111_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ徭")
	l11l1111ll1l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭微")+l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨ徯")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭徰")+l1llllllllll1_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭徱")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭徲"),l11lll_l1_ (u"࠭ࠧ徳"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ徴"),l11l1111ll1l_l1_)
	return
def l1llll1111111_l1_():
	# https://l111lllllll_l1_-l1llll11ll1_l1_-l111l11lll1_l1_.l1111111l11l_l1_.com/request-l1llll1l1ll1l_l1_
	# https://l111lllllll_l1_-l1llll11ll1_l1_-l111l11lll1_l1_.l1111111l11l_l1_.com/query-l1lll1ll1l11l_l1_
	l1l1ll11ll1_l1_,l1l1ll11lll_l1_,l11l1111ll11_l1_,l11l1111ll1l_l1_,l1lllll1l1l11_l1_,l1lll1l1lllll_l1_,l1llll11ll111_l1_ = l11lll_l1_ (u"ࠨࠩ徵"),l11lll_l1_ (u"ࠩࠪ徶"),l11lll_l1_ (u"ࠪࠫ德"),l11lll_l1_ (u"ࠫࠬ徸"),l11lll_l1_ (u"ࠬ࠭徹"),l11lll_l1_ (u"࠭ࠧ徺"),l11lll_l1_ (u"ࠧࠨ徻")
	payload,l1lll1ll1l1l1_l1_,l1lllll1111ll_l1_,l1lll1ll111l1_l1_ = {l11lll_l1_ (u"ࠨࡣࠪ徼"):l11lll_l1_ (u"ࠩࡤࠫ徽")},{},[],{}
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ徾")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ徿"),url,payload,l11lll_l1_ (u"ࠬ࠭忀"),l11lll_l1_ (u"࠭ࠧ忁"),l11lll_l1_ (u"ࠧࠨ忂"),l11lll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭心"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩ忄"),l11lll_l1_ (u"࡙ࠪࡘࡇࠧ必"))
	html = html.replace(l11lll_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬ忆"),l11lll_l1_ (u"࡛ࠬࡋࠨ忇"))
	html = html.replace(l11lll_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭忈"),l11lll_l1_ (u"ࠧࡖࡃࡈࠫ忉"))
	html = html.replace(l11lll_l1_ (u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧ忊"),l11lll_l1_ (u"ࠩࡎࡗࡆ࠭忋"))
	html = html.replace(l11lll_l1_ (u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ忌"),l11lll_l1_ (u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ忍"))
	html = html.replace(l11lll_l1_ (u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭忎"),l11lll_l1_ (u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨ忏"))
	html = html.replace(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ忐"),l11lll_l1_ (u"ࠨࠢࠣࠫ忑"))
	try: l1lllll1111l1_l1_ = EVAL(l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ忒"),html)
	except:
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ忓"),l11lll_l1_ (u"ࠫࠬ忔"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ忕"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦฬๅส้ࠣาะ่๋ษอࠤฯ่ั๋ำࠣห้อำหะาห๊࠭忖"))
		return
	l1llllll1ll1l_l1_,l1111111111l_l1_,l1llll1l1l11l_l1_ = l1lllll1111l1_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ志"),str(l1llllll1ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ忘"),str(l1111111111l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ忙"),str(l1llll1l1l11l_l1_))
	l1lll1ll111l1_l1_ = {}
	l1111l1l11l_l1_ = [l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࠪ忚"),l11lll_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭忛"),l11lll_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ応")]
	l1llll111ll1_l1_ = [l11lll_l1_ (u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ忝"),l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨ忞"),l11lll_l1_ (u"ࠨࡇࡐࡅࡎࡒࡓࠨ忟"),l11lll_l1_ (u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ忠"),l11lll_l1_ (u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ忡"),l11lll_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ忢"),l11lll_l1_ (u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪ忣"),l11lll_l1_ (u"࠭ࡃࡂࡒࡗࡇࡍࡇࡇࡆࡖࡌࡈࠬ忤"),l11lll_l1_ (u"ࠧࡄࡃࡓࡘࡈࡎࡁࡈࡇࡗࡘࡔࡑࡅࡏࠩ忥")]
	l1111111l1l1_l1_ = [l11lll_l1_ (u"ࠨࡃࡏࡐࠬ忦"),l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ忧"),l11lll_l1_ (u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ忨"),l11lll_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ忩"),l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ忪")]+l1llll111ll1_l1_+l1111l1l11l_l1_
	for l1l1l1ll1ll_l1_,l1lllllll1ll1_l1_,l1llllll1l1ll_l1_ in l1111111111l_l1_:
		l1llllll1l1ll_l1_ = escapeUNICODE(l1llllll1l1ll_l1_)
		l1llllll1l1ll_l1_ = l1llllll1l1ll_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ快")).strip(l11lll_l1_ (u"ࠧࠡ࠰ࠪ忬"))
		l11l1111ll1l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭忭")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭忮")+l1llllll1l1ll_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭忯")
		if l1lllllll1ll1_l1_.isdigit():
			l1lll1ll111l1_l1_[l1l1l1ll1ll_l1_] = int(l1lllllll1ll1_l1_)
			if int(l1lllllll1ll1_l1_)>100: l1lllllll1ll1_l1_ = l11lll_l1_ (u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ忰")
			else: l1lllllll1ll1_l1_ = l11lll_l1_ (u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧ忱")
		if l1l1l1ll1ll_l1_ not in l1111111l1l1_l1_:
			if   l1lllllll1ll1_l1_==l11lll_l1_ (u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ忲"): l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠧࠡࠢࠪ忳")+l1l1l1ll1ll_l1_
			elif l1lllllll1ll1_l1_==l11lll_l1_ (u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ忴"): l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠩࠣࠤࠬ念")+l1l1l1ll1ll_l1_
	l1111111l111_l1_,l1llll11l11ll_l1_,l1llll11ll11l_l1_ = list(zip(*l1111111111l_l1_))
	for l1l1l1ll1ll_l1_ in sorted(l1l1ll11ll11_l1_):
		if l1l1l1ll1ll_l1_ not in l1111111l111_l1_:
			l11l1111ll1l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ忶")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ忷")+l11lll_l1_ (u"๊ࠬวࠡ์๋ะิ࠭忸")+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ忹")
			if l1l1l1ll1ll_l1_ not in l1111111l1l1_l1_: l11l1111ll11_l1_ += l11lll_l1_ (u"ࠧࠡࠢࠪ忺")+l1l1l1ll1ll_l1_
	for l1llllll1l1ll_l1_,counts in l1llllll1ll1l_l1_:
		l1llllll1l1ll_l1_ = escapeUNICODE(l1llllll1l1ll_l1_)
		l1lllll1l1l11_l1_ += l1llllll1l1ll_l1_+l11lll_l1_ (u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭忻")+str(counts)+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧ忼")
	l1l1ll11ll1_l1_ = l1l1ll11ll1_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ忽"))
	l1l1ll11lll_l1_ = l1l1ll11lll_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭忾"))
	l11l1111ll11_l1_ = l11l1111ll11_l1_.strip(l11lll_l1_ (u"ࠬࠦࠧ忿"))
	l11l1111llll_l1_ = l1l1ll11ll1_l1_+l11lll_l1_ (u"࠭ࠠࠡࠩ怀")+l1l1ll11lll_l1_
	#l111l111111l_l1_  = l11lll_l1_ (u"ࠧ࡝ࡰࡋ࡭࡬࡮ࡕࡴࡣࡪࡩ࠿࡛ࠦࠡࠩ态")+l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ怂")
	#l111l111111l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡑࡵࡷࡖࡵࡤ࡫ࡪࠦ࠺ࠡ࡝ࠣࠫ怃")+l1l1ll11lll_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭怄")
	#l111l111111l_l1_ += l11lll_l1_ (u"ࠫࡡࡴࡎࡰࡗࡶࡥ࡬࡫ࠠࠡ࠼ࠣ࡟ࠥ࠭怅")+l11l1111ll11_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ怆")
	l11l1111lll1_l1_  = l11lll_l1_ (u"࠭ๅ้ษๅ฽ࠥ์ฬฮࠢส่อืๆศ็ฯࠤอะิ฻์็ࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪ怇")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ怈")+l11lll_l1_ (u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ่์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั࠭怉")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ怊")
	l11l1111lll1_l1_ += l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭怋")+l11l1111llll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪ怌")
	l11l1111lll1_l1_ += l11lll_l1_ (u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫ怍")+l11lll_l1_ (u"࠭࡜࡯ࠩ怎")+l11lll_l1_ (u"้้ࠧำหู๋ࠥ็ษ๊ࠤฬำสๆษ็ࠤ่ฮ๊า๋ࠢะํีࠠๆึๆ่ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ怏")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ怐")
	l11l1111lll1_l1_ += l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ怑")+l11l1111ll11_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ怒")
	l1llllll1ll1_l1_,l1llll11111l1_l1_,l1lllll11l1l1_l1_,l1lll1llll1ll_l1_ = 0,0,0,0
	all = l1lll1ll111l1_l1_[l11lll_l1_ (u"ࠫࡆࡒࡌࠨ怓")]
	if l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ怔") in list(l1lll1ll111l1_l1_.keys()): l1llllll1ll1_l1_ = l1lll1ll111l1_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭怕")]
	if l11lll_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ怖") in list(l1lll1ll111l1_l1_.keys()): l1llll11111l1_l1_ = l1lll1ll111l1_l1_[l11lll_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ怗")]
	if l11lll_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭怘") in list(l1lll1ll111l1_l1_.keys()): l1lllll11l1l1_l1_ = l1lll1ll111l1_l1_[l11lll_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ怙")]
	if l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ怚") in list(l1lll1ll111l1_l1_.keys()): l1lll1llll1ll_l1_ = l1lll1ll111l1_l1_[l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ怛")]
	l1llll1111lll_l1_ = all-l1llllll1ll1_l1_-l1llll11111l1_l1_-l1lllll11l1l1_l1_-l1lll1llll1ll_l1_
	dummy,l1llll1lllll1_l1_ = l1llll1l1l11l_l1_[0]
	dummy,l1lll1lll11ll_l1_ = l1llll1l1l11l_l1_[1]
	l1llll111l111_l1_ = l1llll1lllll1_l1_-l1lll1lll11ll_l1_
	l1llll11ll111_l1_ += l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ怜")+str(l1lll1lll11ll_l1_)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ思")+l11lll_l1_ (u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬ怞")
	l1llll11ll111_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ怟")+str(l1llll111l111_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ怠")+l11lll_l1_ (u"ࠫออำหะาห๊ࠦࡰࡳࡱࡻࡽࠥษ่ࠡࡸࡳࡲࠥࡀࠠࠨ怡")
	l1llll11ll111_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ怢")+str(l1llll1lllll1_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ怣")+l11lll_l1_ (u"ࠧศๆ฼ำิࠦวๅๅ็๎๊ࠥฬๆ์฼ࠤฬ๊รอ้ีอࠥࡀࠠࠨ怤")
	l1llll11ll111_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭急")+str(len(l1llll1l1l11l_l1_[2:]))+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ怦")+l11lll_l1_ (u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨ性")
	for l1ll111ll11l_l1_,l1l111l11l11_l1_ in l1llll1l1l11l_l1_[2:]:
		l1ll111ll11l_l1_ = escapeUNICODE(l1ll111ll11l_l1_)
		l1ll111ll11l_l1_ = l1ll111ll11l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭怨")).strip(l11lll_l1_ (u"ࠬࠦ࠮ࠨ怩"))
		l1llll11ll111_l1_ += l1ll111ll11l_l1_+l11lll_l1_ (u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ怪")+str(l1l111l11l11_l1_)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬ怫")
	#l1llll11ll111_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࠲ࠬ怬")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ怭")+str(l1llll1111lll_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ怮")+l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩ怯")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ怰")+str(l1llllll1ll1_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ怱")+l11lll_l1_ (u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨ怲")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭怳")+str(l1lll1llll1ll_l1_)+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ怴")+l11lll_l1_ (u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭怵")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ怶")+str(l1llll11111l1_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ怷")+l11lll_l1_ (u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪ怸")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ怹")+str(l1lllll11l1l1_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ怺")+l11lll_l1_ (u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨ总")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ怼")+str(len(l1llllll1ll1l_l1_))+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭怽")+l11lll_l1_ (u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬ怾")
	#l1lll1l1lllll_l1_ += l11lll_l1_ (u"࠭࡜࡯࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭怿")+l11lll_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠศๆ฼ห้๋๋๊่ࠠࠤศ๋ำࠡࠪส่ออัฮหࠬࠫ恀")+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恁")
	l1lll1l1lllll_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ恂")+l1lllll1l1l11_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ恃"),l11lll_l1_ (u"ࠫ฾ีฯࠡษ็วัําสࠢส่ฯ๐ࠠศีอาิ๋ส้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ恄"),l1llll11ll111_l1_,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ恅"))
	#l11ll11lll_l1_(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭恆"),l11lll_l1_ (u"ࠧอ็ํ฽ࠥํะ่ࠢส่ศืโศ็ࠣฮำ฻ࠠฤีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠࠡใๅ฻ࠥ๐่ๆࠢฦุ้ࠦࠨศๆหหึำษࠪࠩ恇"),l1lll1l1lllll_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ恈"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ恉"),l11lll_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ恊"),l1lll1l1lllll_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ恋"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ恌"),l11lll_l1_ (u"࠭ๅ้ษๅ฽ࠥอิห฼็ฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ恍"),l11l1111lll1_l1_,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ恎"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭恏"),l11lll_l1_ (u"ࠩฦ฽้๏ࠠศๆา์้ࠦวๅฬํࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡษึฮำีๅหࠢส่อืๆศ็ฯࠫ恐"),l11l1111ll1l_l1_,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ恑"))
	return
def l1llll11lll11_l1_():
	message = l11lll_l1_ (u"ࠫ์ึวࠡษ็ฬึ์วๆฮࠣ๎฾๋ไࠡษไฺ้ࠦศศีอาิอๅࠡฮ็ำ้่ࠥะ์ࠣࠬࡐࡵࡤࡪࠢࡖ࡯࡮ࡴࠩࠡษ็ิ๏ࠦวิ็๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࡠࡳ่ࠦๆ็ๆ๊ࠥะหษ์อ๋ࠥฮวิฬัำฬ๋ࠠๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠠฤ๊ࠣฮา๋๊ๅ้้๋ࠣࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢฦะํฮษࠡษ็ฬึ์วๆฮࠪ恒")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ恓"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ恔"),message,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ恕"))
	return
def l1l1l111l11l_l1_():
	message = l11lll_l1_ (u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭恖")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ恗")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭恘")+l1ll11l_l1_[l11lll_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ恙")][0]+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠣࠤࠥษ่ࠡࠢࠣࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ恚")+l1ll11l_l1_[l11lll_l1_ (u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ恛")][1]+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ恜")
	message += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡢ࡮ศๆิหอ฽ࠠฤั้ห์ࠦ็้ࠢสุ่๎ัิࠢส่ี๐๋ࠠฯอหัํࠠๆัํี๋ࠥไโษอࠤ่๎ฯ๋ࠢ็ฮะฮ๊หࠢหี๋อๅอࠢ฼้ฬีࠠษษ็฻ึ๐โสࠢส่ฯ่ไ๋ัํอࠥอไใัํ้ฮࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ恝")+l1ll11l_l1_[l11lll_l1_ (u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ恞")][1]+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ恟")
	message += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํࠧ恠")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ恡")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ恢")+l1ll11l_l1_[l11lll_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ恣")][2]+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恤")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ恥"),l11lll_l1_ (u"ࠪห้๋่ศไ฼ࠤฬ๊ัิ็ํอ๊ࠥศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ恦"),message,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ恧"))
	return
def l1llllll1ll11_l1_(l1llllll1lll1_l1_):
	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫࠫ恨")+l1llllll1lll1_l1_+l11lll_l1_ (u"࠭ࠩࠨ恩"), True)
	return
def l1llllll11l1l_l1_():
	l1ll11l11_l1_(l11lll_l1_ (u"ࠧࡴࡶࡲࡴࠬ恪"))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠣࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡌࡲࡹ࡫ࡲࡧࡣࡦࡩࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠯ࠢ恫"))
	return
def l1llll1l1l111_l1_():
	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠩࠨ恬"), True)
	return
def l1llll111lll1_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111ll1_l1_ = True
	else: l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ恭"),l11lll_l1_ (u"ࠫࠬ恮"),l11lll_l1_ (u"ࠬ࠭息"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ恰"),l11lll_l1_ (u"ࠧษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣฬ฾๋ไ๋หࠣฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢอ่็อฦ๋ษࠣ็้ࠦ࠲࠵ࠢึห฾ฯ้ࠠๆๆ๊๋ࠥๅไ่ࠣษัืวย้สࠤฬ๊ย็ࠢ࠱ࠤ์๊ࠠหำํำࠥะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠศๆล๊ࠥลࠧ恱"))
	if l1ll111ll1_l1_==1:
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡂࡦࡧࡳࡳࡘࡥࡱࡱࡶࠫ恲"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ恳"),l11lll_l1_ (u"ࠪࠫ恴"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ恵"),l11lll_l1_ (u"ࠬะๅࠡวิืฬุ๊ࠠๆหࠤส๊้ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦวๅาํࠤๆ๐ࠠอ้สึ่ࠦไไ์ࠣ๎็๎ๅࠡสอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤ࠳ࠦศๆษࠣๅ๏ํวࠡฬะำ๏ั่ࠠาสࠤฬ๊ศา่ส้ั่ࠦหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬ恶"))
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ恷"))
	return
def l1llll11l1111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ恸"),l11lll_l1_ (u"ࠨࠩ恹"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ恺"),l11lll_l1_ (u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠฤ๊ࠣหุะฮะ็ࠣࠦฬ๊ใ๋ส๋ีิࠨ้ࠠษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤฬ฼ฺุࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠪ恻"))
	return
def l1llll11l1ll1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ恼"),l11lll_l1_ (u"ࠬ࠭恽"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ恾"),l11lll_l1_ (u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ์โาࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࠪ恿"))
	return
#l1lllllll1111_l1_ 	  required	and l1lllllll1111_l1_     installed	and		not l1l1111ll1ll_l1_		ignore
#l1lllllll1111_l1_ not required	and	l1lllllll1111_l1_ not installed 	and 	    l1l1111ll1ll_l1_		ignore
#l1lllllll1111_l1_ not required	and	l1lllllll1111_l1_ not installed 	and 	not l1l1111ll1ll_l1_		ignore
#l1lllllll1111_l1_ not required	and	l1lllllll1111_l1_     installed 	and 	not l1l1111ll1ll_l1_		ignore
#l1lllllll1111_l1_     required	and	l1lllllll1111_l1_ not installed 	and 	    l1l1111ll1ll_l1_		l111111ll1_l1_ l1llll11111l1_l1_	l1lllll1l1l1l_l1_
#l1lllllll1111_l1_     required	and	l1lllllll1111_l1_ not installed 	and 	not l1l1111ll1ll_l1_		l111111ll1_l1_ l1llll11111l1_l1_	l1lllll1l1l1l_l1_
#l1lllllll1111_l1_     required 	and l1lllllll1111_l1_     installed 	and 	    l1l1111ll1ll_l1_		l111111ll1_l1_ l1lllllllll1l_l1_	l1lllll1l1l1l_l1_
#l1lllllll1111_l1_ not required	and	l1lllllll1111_l1_     installed 	and 	    l1l1111ll1ll_l1_		l111111ll1_l1_ l1lllllllll1l_l1_	l1lllll1l1l1l_l1_
#l1ll1l111111_l1_: required and not installed: l111111ll1_l1_ l1llll11111l1_l1_
#l1ll11lllll1_l1_: installed and l111111ll1_l1_ update: l111111ll1_l1_ l1lllllllll1l_l1_
def l1l11llllll1_l1_(l1ll_l1_=True):
	l1llll1llll11_l1_ = [l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ悀"),l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪ悁"),l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭悂"),l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭悃"),l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭悄"),l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ悅")]
	l1lllll111l1l_l1_ = l1llll1llll11_l1_+[l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ悆"),l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭悇"),l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ悈"),l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯ࡲ࡫ࡩࡳࡵ࡭ࡦࡰࡤࡰࡊࡓࡁࡅࠩ悉"),l11lll_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ悊"),l11lll_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ悋")]		# ,l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲࡮ࡴࡳࡵࡣ࡯ࡰࡊࡓࡁࡅࠩ悌")
	l1l111lll11l_l1_ = l1ll1llll11l_l1_([l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ悍")])
	l1lllll11l11l_l1_ = []
	for addon_id in [l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ悎")]:
		if addon_id not in list(l1l111lll11l_l1_.keys()): continue
		l1l1111ll1ll_l1_,l1llll111l11_l1_,l1lllll1lll1l_l1_,l1lllll1lll11_l1_,l1lllll1ll11l_l1_,l1lll1ll1ll1l_l1_,l1lllll1ll1l1_l1_ = l1l111lll11l_l1_[addon_id]
		if not l1llll111l11_l1_ or (l1llll111l11_l1_ and l1l1111ll1ll_l1_): l1lllll11l11l_l1_.append(addon_id)
	l1lll1l1lll1l_l1_ = len(l1lllll11l11l_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1l11llll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1llllll111l1_l1_ = []
	for addon_id in l1llll1llll11_l1_:
		cc.execute(l11lll_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡪࡴࡡࡣ࡮ࡨࡨࠥࡃࠠࠣ࠳ࠥࠤࡦࡴࡤࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭悏")+addon_id+l11lll_l1_ (u"ࠪࠦࠥࡁࠧ悐"))
		l11ll1lll1l_l1_ = cc.fetchall()
		if l11ll1lll1l_l1_: l1llllll111l1_l1_.append(addon_id)
	l1llll1l111l1_l1_ = len(l1llllll111l1_l1_)>0
	for addon_id in l1lllll111l1l_l1_:
		cc.execute(l11lll_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ悑")+addon_id+l11lll_l1_ (u"ࠬࠨࠠ࠼ࠩ悒"))
		l1111111l1ll_l1_ = cc.fetchall()
		if l1111111l1ll_l1_ and l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ悓") not in str(l1111111l1ll_l1_): l1lllll11l11l_l1_.append(addon_id)
	l1llll1111l1l_l1_ = len(l1lllll11l11l_l1_)>0
	l1lllll11l11l_l1_ = list(set(l1lllll11l11l_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ悔"),l11lll_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥࡲࡦࡲࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࡀࠠࠡࠩ悕")+str(l1lll1l1lll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ悖"),l11lll_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡦࡨࡰࡪࡺࡩ࡯ࡩࡢࡳࡱࡪ࡟ࡢࡦࡧࡳࡳࡹ࠺ࠡࠢࠪ悗")+str(l1llll1l111l1_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ悘"),l11lll_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡳࡷ࡯ࡧࡪࡰ࠽ࠤࠥ࠭悙")+str(l1llll1111l1l_l1_))
	l1l1111ll1ll_l1_ = False
	if l1llll1l111l1_l1_ or l1llll1111l1l_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭悚"),l11lll_l1_ (u"ࠧࠨ悛"),l11lll_l1_ (u"ࠨࠩ悜"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ悝"),l11lll_l1_ (u"ࠪห้ฮั็ษ่ะࠥ๎ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡษ็ฦ๋ࠦฟ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ悞"))
		if l1ll111ll1_l1_==1:
			l1lllllll1lll_l1_ = True
			if l1lll1l1lll1l_l1_:
				l1lllllll1lll_l1_ = l1lll1lllllll_l1_(l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭悟"),False,False)
			l1lll1lll1lll_l1_ = True
			if l1llll1l111l1_l1_:
				for addon_id in l1llllll111l1_l1_: l1llll1ll1l11_l1_(addon_id)
				l1lll1lll1lll_l1_ = True
			l1lll1llll1l1_l1_ = True
			if l1llll1111l1l_l1_:
				conn = sqlite3.connect(l1l1l11llll1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1lllll11l11l_l1_:
					if l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࠨ悠") in addon_id: l1111111l1ll_l1_ = addon_id
					else: l1111111l1ll_l1_ = l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ悡")
					try: cc.execute(l11lll_l1_ (u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫ悢")+l1111111l1ll_l1_+l11lll_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ患")+addon_id+l11lll_l1_ (u"ࠩࠥࠤࡀ࠭悤"))
					except: l1lll1llll1l1_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ悥"))
			time.sleep(1)
			if l1lllllll1lll_l1_ or l1lll1lll1lll_l1_ or l1lll1llll1l1_l1_:
				l1l1111ll1ll_l1_ = False
				DIALOG_OK(l11lll_l1_ (u"ࠫࠬ悦"),l11lll_l1_ (u"ࠬ࠭悧"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ您"),l11lll_l1_ (u"ࠧอ์าࠤ࠳࠴ࠠห็ࠣฬ๋าวฮࠢอๅ฾๐ไ๊ࠡศู้ออࠡษ็ุ้ะ่ะ฻ࠣ์ฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅฮ่๎฾ࠦลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ悩"))
			else:
				l1l1111ll1ll_l1_ = True
				DIALOG_OK(l11lll_l1_ (u"ࠨࠩ悪"),l11lll_l1_ (u"ࠩࠪ悫"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭悬"),l11lll_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮ่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠวุ่ฬำࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ悭"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭悮"),l11lll_l1_ (u"࠭ࠧ悯"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ悰"),l11lll_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤ๊ࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ悱"))
	return l1l1111ll1ll_l1_
def l1llll11111ll_l1_():
	l1lll1ll111ll_l1_,l1lllllll11ll_l1_,l1lllll1l1ll1_l1_ = False,l11lll_l1_ (u"ࠩࠪ悲"),l11lll_l1_ (u"ࠪࠫ悳")
	l1lllllll111l_l1_,l1llll1l1llll_l1_,l1llll1llll1l_l1_ = False,l11lll_l1_ (u"ࠫࠬ悴"),l11lll_l1_ (u"ࠬ࠭悵")
	l1l111lll11l_l1_ = l1ll1llll11l_l1_([l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ悶"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ悷"),l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ悸")])
	for addon_id in [l11lll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ悹"),l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ悺"),l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ悻")]:
		if addon_id not in list(l1l111lll11l_l1_.keys()): continue
		l1l1111ll1ll_l1_,l1llll111l11_l1_,l11111l1111_l1_,l1ll1l11ll11_l1_,l111lll1l1l_l1_,l11l1l111ll_l1_,l1l1111ll11l_l1_ = l1l111lll11l_l1_[addon_id]
		if addon_id==l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ悼"):
			l1lllllll111l_l1_ = l1l1111ll1ll_l1_
			l1llll1l1llll_l1_ = l11lll_l1_ (u"࠭ࠨࠨ悽")+l1llll111l11_l1_+l11lll_l1_ (u"ࠧࠡࠩ悾")+TRANSLATE(l11l1l111ll_l1_)+l11lll_l1_ (u"ࠨࠫࠪ悿")
			l1llll1llll1l_l1_ = l1ll1l11ll11_l1_
		elif addon_id==l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ惀"):
			l1lll1ll111ll_l1_ = l1lll1ll111ll_l1_ or l1l1111ll1ll_l1_
			l1lllllll11ll_l1_ += l11lll_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠪࠪ惁")+l1llll111l11_l1_+l11lll_l1_ (u"ࠫࠥ࠭惂")+TRANSLATE(l11l1l111ll_l1_)+l11lll_l1_ (u"ࠬ࠯ࠧ惃")
			l1lllll1l1ll1_l1_ += l11lll_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ惄")+l1ll1l11ll11_l1_
		elif addon_id==l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭情"):
			l1llll11llll1_l1_ = l1l1111ll1ll_l1_
			l1llll11l1l11_l1_ = l11lll_l1_ (u"ࠨࠪࠪ惆")+l1llll111l11_l1_+l11lll_l1_ (u"ࠩࠣࠫ惇")+TRANSLATE(l11l1l111ll_l1_)+l11lll_l1_ (u"ࠪ࠭ࠬ惈")
			l1lllll1l11ll_l1_ = l1ll1l11ll11_l1_
	l1lllllll11ll_l1_ = l1lllllll11ll_l1_.strip(l11lll_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ惉"))
	l1lllll1l1ll1_l1_ = l1lllll1l1ll1_l1_.strip(l11lll_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠫ惊"))
	l1l11ll1l1_l1_  = l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭惋")+l1llll1llll1l_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ惌")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ惍")+l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭惎")+l1llll1l1llll_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ惏")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ惐")+l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ惑")+l1lllll1l1ll1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ惒")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࠪ惓")+l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ惔")+l1lllllll11ll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ惕")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ惖")+l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ惗")+l1lllll1l11ll_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ惘")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ惙")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ惚")+l1llll11l1l11_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ惛")
	l1l1111ll1ll_l1_ = (l1lllllll111l_l1_ or l1lll1ll111ll_l1_)
	if l1l1111ll1ll_l1_:
		header = l11lll_l1_ (u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫ惜")
		l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫ惝")
	else:
		header = l11lll_l1_ (u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬ惞")
		l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧ惟")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ惠")
	l1ll11ll1l_l1_ = l1l11ll1l1_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ惡")+l1l1l1ll11_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭惢")+l1l1l1l1ll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ惣"),header,l1ll11ll1l_l1_,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭惤"))
	return
def l1ll11l111ll_l1_(l1ll_l1_=True,l1llll111l11l_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ惥"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ惦"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ惧"),l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ惨"))
	if l1ll_l1_:
		l1llll11111ll_l1_()
		l1lllll1l11l1_l1_()
	if l1llll111l11l_l1_:
		l1l11llllll1_l1_(False)
		l1l1l1111ll1_l1_ = []
		l1lllll1lllll_l1_ = [l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭惩"),l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ惪"),l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ惫"),l11lll_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ惬")]
		for l1llll111llll_l1_ in l1lllll1lllll_l1_:
			succeeded,l1lllll1l1lll_l1_,l1llll111l11_l1_ = l1lll1lllllll_l1_(l1llll111llll_l1_,True,False)
			l1l1l1111ll1_l1_.append(succeeded)
		l1llll111lll1_l1_(l1ll_l1_)
		l1l11111lll1_l1_ = l11lll_l1_ (u"ࠬ࠭惭") if all(l1l1l1111ll1_l1_) else l11lll_l1_ (u"࠭࠱ࠨ惮")
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪࡶ࡯ࡴ࠰ࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠧ惯"),l1l11111lll1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡰࡰࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭惰"),str(now))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭惱"))
	return
def l1lllll11ll11_l1_(l1llllll11lll_l1_=l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ惲"),l1ll_l1_=True):
	l1111l1111l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ想"))
	import json
	data = json.loads(l1111l1111l_l1_)
	l1lll1ll1ll11_l1_ = data[l11lll_l1_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ惴")][l11lll_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ惵")]
	if kodi_version<19: l1lll1ll1ll11_l1_ = l1lll1ll1ll11_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ惶"))
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ惷"),l11lll_l1_ (u"ࠩࠪ惸"),l11lll_l1_ (u"ࠪࠫ惹"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ惺"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪ惻")+l1lll1ll1ll11_l1_+l11lll_l1_ (u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨ惼")+l1llllll11lll_l1_+l11lll_l1_ (u"ࠧࠡมࠤࠫ惽"))
		if l1ll111ll1_l1_!=1: return False
	succeeded,l1lllll1l1lll_l1_,l1lll1ll1llll_l1_ = l1lll1lllllll_l1_(l1llllll11lll_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ惾"),l11lll_l1_ (u"ࠩࠪ惿"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭愀"),l11lll_l1_ (u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭愁"))
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩ愂")+l1llllll11lll_l1_+l11lll_l1_ (u"࠭ࠢࡾࡿࠪ愃"))
		if l11lll_l1_ (u"ࠧࡐࡍࠪ愄") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ愅"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ愆"),l11lll_l1_ (u"ࠪࠫ愇"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ愈"),l11lll_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧ愉"))
	return succeeded
def l111ll1ll1l_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11lll_l1_ (u"࠭ࠧ愊"): l1ll_l1_ = True
	#l1ll1l1lll11_l1_ = xbmc.getCondVisibility(l11lll_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠪ愋")+addon_id+l11lll_l1_ (u"ࠨࠫࠪ愌"))
	l11l1111111_l1_ = l1l1ll1llll1_l1_([addon_id])
	l111l1l111l_l1_,l1ll1l1lll11_l1_ = l11l1111111_l1_[addon_id]
	if l1ll1l1lll11_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ愍"),l11lll_l1_ (u"ࠪࠫ愎"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ意"),l11lll_l1_ (u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ愐")+addon_id+l11lll_l1_ (u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ愑"))
	else:
		succeeded = False
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ愒"),l11lll_l1_ (u"ࠨࠩ愓"),l11lll_l1_ (u"ࠩࠪ愔"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭愕"),l11lll_l1_ (u"ࠫࠬ愖")+addon_id+l11lll_l1_ (u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪ愗"))
		if l1ll111ll1_l1_==1:
			xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭愘")+addon_id+l11lll_l1_ (u"ࠧࠪࠩ愙"))
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ愚"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11lll_l1_ (u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭愛")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭愜")+addon_id+l11lll_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ愝"))
			if l11lll_l1_ (u"ࠬࡕࡋࠨ愞") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ感"),l11lll_l1_ (u"ࠧࠨ愠"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ愡"),l11lll_l1_ (u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨ愢"))
			elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ愣"),l11lll_l1_ (u"ࠫࠬ愤"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ愥"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨ愦"))
	return succeeded
def l1llll11l111l_l1_(addon_id,l1l1111ll11l_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࠨ愧"),l11lll_l1_ (u"ࠨࠩ愨"),l11lll_l1_ (u"ࠩࠪ愩"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭愪"),l11lll_l1_ (u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧ愫"))
		if l1ll111ll1_l1_!=1: return False
	l1lll1ll11ll1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111ll11l_l1_,{},l1ll_l1_)
	if l1lll1ll11ll1_l1_:
		l1l111l11l1l_l1_ = os.path.join(l1ll11llll_l1_,addon_id)
		l1ll11l1ll_l1_(l1l111l11l1l_l1_,True,False)
		import zipfile,io
		l1llll1l1lll1_l1_ = io.BytesIO(l1lll1ll11ll1_l1_)
		zf = zipfile.ZipFile(l1llll1l1lll1_l1_)
		zf.extractall(l1ll11llll_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ愬"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ愭")+addon_id+l11lll_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ愮"))
		if l11lll_l1_ (u"ࠨࡑࡎࠫ愯") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ愰"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ愱"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ愲"),l11lll_l1_ (u"ࠬ࠭愳"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ愴"),l11lll_l1_ (u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ愵"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ愶"),l11lll_l1_ (u"ࠩࠪ愷"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭愸"),l11lll_l1_ (u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ愹"))
	return succeeded
def l1lll1lllllll_l1_(addon_id,l1ll_l1_,l1llllll1111l_l1_):
	l1ll111ll1_l1_,succeeded,l1lllll1l1lll_l1_,l1llll111l11_l1_ = True,False,l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ愺"),l11lll_l1_ (u"࠭ࠧ愻")
	l1l111lll11l_l1_ = l1ll1llll11l_l1_([addon_id])
	if addon_id in list(l1l111lll11l_l1_.keys()):
		l1l1111ll1ll_l1_,l1llll111l11_l1_,l11111l1111_l1_,l1ll1l11ll11_l1_,l111lll1l1l_l1_,l11l1l111ll_l1_,l1l1111ll11l_l1_ = l1l111lll11l_l1_[addon_id]
		if l11l1l111ll_l1_==l11lll_l1_ (u"ࠧࡨࡱࡲࡨࠬ愼"):
			succeeded,l1lllll1l1lll_l1_ = True,l11lll_l1_ (u"ࠨࡰࡲࡸ࡭࡯࡮ࡨࠩ愽")
			if l1llllll1111l_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ愾"),l11lll_l1_ (u"ࠪࠫ愿"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ慀"),l11lll_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬ慁")+addon_id)
		else:
			if l1ll_l1_:
				if l11l1l111ll_l1_==l11lll_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ慂"): message = l11lll_l1_ (u"ࠧๆฬ๋ๆๆฯࠧ慃")
				elif l11l1l111ll_l1_==l11lll_l1_ (u"ࠨࡱ࡯ࡨࠬ慄"): message = l11lll_l1_ (u"ࠩๅำ๏๋ษࠨ慅")
				elif l11l1l111ll_l1_==l11lll_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ慆"): message = l11lll_l1_ (u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧ慇")
				l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭慈"),l11lll_l1_ (u"࠭ࠧ慉"),l11lll_l1_ (u"ࠧࠨ慊"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ態"),l11lll_l1_ (u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨ慌")+message+l11lll_l1_ (u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬ慍")+addon_id)
			if not l1ll111ll1_l1_: l1lllll1l1lll_l1_ = l11lll_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭慎")
			else:
				if l11l1l111ll_l1_==l11lll_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ慏"):
					results = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ慐")+addon_id+l11lll_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ慑"))
					if l11lll_l1_ (u"ࠨࡑࡎࠫ慒") in results:
						succeeded,l1lllll1l1lll_l1_ = True,l11lll_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪ慓")
						if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ慔"),l11lll_l1_ (u"ࠫࠬ慕"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ慖"),l11lll_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫ慗")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ慘"),l11lll_l1_ (u"ࠨࠩ慙"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ慚"),l11lll_l1_ (u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭慛")+addon_id)
				elif l11l1l111ll_l1_ in [l11lll_l1_ (u"ࠫࡴࡲࡤࠨ慜"),l11lll_l1_ (u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭慝")]:
					succeeded = l1llll11l111l_l1_(addon_id,l1l1111ll11l_l1_,False)
					if succeeded:
						if l11l1l111ll_l1_==l11lll_l1_ (u"࠭࡯࡭ࡦࠪ慞"): l1lllll1l1lll_l1_ = l11lll_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ慟")
						elif l11l1l111ll_l1_==l11lll_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ慠"): l1lllll1l1lll_l1_ = l11lll_l1_ (u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬ慡")
						l1llll111l11_l1_ = l1ll1l11ll11_l1_
						if l1ll_l1_:
							if l1lllll1l1lll_l1_==l11lll_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫ慢"): DIALOG_OK(l11lll_l1_ (u"ࠫࠬ慣"),l11lll_l1_ (u"ࠬ࠭慤"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ慥"),l11lll_l1_ (u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬࠣๆิ๐ๅสࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฮัํฯ์อ࡜࡯࡞ࡱࠫ慦")+addon_id)
							elif l1lllll1l1lll_l1_==l11lll_l1_ (u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫ慧"): DIALOG_OK(l11lll_l1_ (u"ࠩࠪ慨"),l11lll_l1_ (u"ࠪࠫ慩"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ慪"),l11lll_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭慫")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ慬"),l11lll_l1_ (u"ࠧࠨ慭"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ慮"),l11lll_l1_ (u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬ慯")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ慰"),l11lll_l1_ (u"ࠫࠬ慱"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ慲"),l11lll_l1_ (u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ慳")+addon_id)
	return succeeded,l1lllll1l1lll_l1_,l1llll111l11_l1_
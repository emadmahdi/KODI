# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ⽢")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡈࡖࡘࡤ࠭⽣")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ⽤"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ⽥"),l11lll_l1_ (u"ࠪฮัํ๊ำࠢส่า๊โศฬࠣห้่วะ็ฬࠫ⽦")]
def MAIN(mode,url,text):
	if   mode==600: results = MENU()
	elif mode==601: results = l1111l_l1_(url,text)
	elif mode==602: results = PLAY(url)
	elif mode==603: results = l11111_l1_(url,text)
	elif mode==604: results = l1l11l_l1_(url)
	elif mode==609: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠫ࡫ࡵࡳࡵࡣࠪ⽧"),l11lll_l1_ (u"ࠬ็่ิฬสࠤ࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠭⽨"),l11lll_l1_ (u"࠭࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡹࡵࡥࡵ࠭⽩"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⽪"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⽫"),l11lll_l1_ (u"ࠩࠪ⽬"),609,l11lll_l1_ (u"ࠪࠫ⽭"),l11lll_l1_ (u"ࠫࠬ⽮"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⽯"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⽰"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⽱"),l11lll_l1_ (u"ࠨࠩ⽲"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽳"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⽴")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ⽵"),l1ll1l1_l1_,601,l11lll_l1_ (u"ࠬ࠭⽶"),l11lll_l1_ (u"࠭ࠧ⽷"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⽸"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⽹"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⽺")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ⽻"),l1ll1l1_l1_,601,l11lll_l1_ (u"ࠫࠬ⽼"),l11lll_l1_ (u"ࠬ࠭⽽"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⽾"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⽿"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⾀")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ⾁"),l1ll1l1_l1_,601,l11lll_l1_ (u"ࠪࠫ⾂"),l11lll_l1_ (u"ࠫࠬ⾃"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ⾄"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾅"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⾆")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ⾇"),l1ll1l1_l1_,601,l11lll_l1_ (u"ࠩࠪ⾈"),l11lll_l1_ (u"ࠪࠫ⾉"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⾊"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⾋"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⾌"),l11lll_l1_ (u"ࠧࠨ⾍"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⾎"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⾏"),l11lll_l1_ (u"ࠪࠫ⾐"),l11lll_l1_ (u"๊ࠫ๎โฺࠢไ์ุะวࠨ⾑"),l11lll_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ⾒"))
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⾓"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾔"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⾕")+l111ll_l1_+title,link,604)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⾖"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⾗"),l11lll_l1_ (u"ࠫࠬ⾘"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ⾙"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ⾚"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠧࠨ⾛"))
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⾜"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾝"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⾞")+l111ll_l1_+title,link,604)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⾟"),url,l11lll_l1_ (u"ࠬ࠭⾠"),l11lll_l1_ (u"࠭ࠧ⾡"),l11lll_l1_ (u"ࠧࠨ⾢"),l11lll_l1_ (u"ࠨࠩ⾣"),l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⾤"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⾥"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ⾦"),l11lll_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ⾧"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⾨"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠧࠨ⾩"),block)]
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⾪"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⾫"),l11lll_l1_ (u"ࠪࠫ⾬"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⾭"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠬࡀࠠࠨ⾮")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾯"),l111ll_l1_+title,link,601)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⾰"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⾱"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⾲"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⾳"),l11lll_l1_ (u"ࠫࠬ⾴"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⾵"),l111ll_l1_+title,link,601)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"࠭ࠧ⾶")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⾷"),l11lll_l1_ (u"ࠨࠩ⾸"),request,url)
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ⾹"):
		url,search = url.split(l11lll_l1_ (u"ࠪࡃࠬ⾺"),1)
		data = l11lll_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ⾻")+search
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⾼"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭⾽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ⾾"),url,data,headers,l11lll_l1_ (u"ࠨࠩ⾿"),l11lll_l1_ (u"ࠩࠪ⿀"),l11lll_l1_ (u"ࠪࡊࡔ࡙ࡔࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⿁"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⿂"),url,l11lll_l1_ (u"ࠬ࠭⿃"),l11lll_l1_ (u"࠭ࠧ⿄"),l11lll_l1_ (u"ࠧࠨ⿅"),l11lll_l1_ (u"ࠨࠩ⿆"),l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⿇"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠪࠫ⿈"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ⿉"))
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ⿊"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⿋"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨ⿌"),link,title))
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⿍"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⿎"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⿏"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⿐"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ⿑"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⿒"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ⿓"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ⿔"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⿕"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ⿖"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⿗"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⿘"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"࠭ๅีษ๊ำฮ࠭⿙"),l11lll_l1_ (u"ࠧโ์็้ࠬ⿚"),l11lll_l1_ (u"ࠨษ฽๊๏ฯࠧ⿛"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ⿜"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ⿝"),l11lll_l1_ (u"ࠫ์ีวโࠩ⿞"),l11lll_l1_ (u"๋ࠬศศำสอࠬ⿟"),l11lll_l1_ (u"ู࠭าุࠪ⿠"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ⿡"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ⿢"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ⿣")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ⿤"))
		#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⿥") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ⿦")+link.strip(l11lll_l1_ (u"࠭࠯ࠨ⿧"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⿨") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ⿩")+l1llll_l1_.strip(l11lll_l1_ (u"ࠩ࠲ࠫ⿪"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⿫"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧ⿬"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⿭"),l111ll_l1_+title,link,602,l1llll_l1_)
		elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⿮"):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿯"),l111ll_l1_+title,link,602,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⿰") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿱"),l111ll_l1_+title,link,603,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⿲") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿳"),l111ll_l1_+title,link,601,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿴"),l111ll_l1_+title,link,603,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⿵"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ⿶")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⿷"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⿸"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠪࠧࠬ⿹"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭⿺")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ⿻"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿼"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭⿽")+title,link,601)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⿾"),l11lll_l1_ (u"ࠩࠪ⿿"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ　"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ、"),url,l11lll_l1_ (u"ࠬ࠭。"),l11lll_l1_ (u"࠭ࠧ〃"),l11lll_l1_ (u"ࠧࠨ〄"),l11lll_l1_ (u"ࠨࠩ々"),l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ〆"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭〇"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭〈"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠬ࠭〉")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡱࡱࡧࡱ࡯ࡣ࡬࠿ࠥࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸ࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭《"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠤࠩ》"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ「"),l111ll_l1_+title,url,603,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ」"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ『")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ』"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂࡁࡲࡩ࠿࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠦ【"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ】"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ〒")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ〓"))
			title = title.replace(l11lll_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧ〔"),l11lll_l1_ (u"ࠪࠤࠬ〕"))
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ〖"),l111ll_l1_+title,link,602,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭〗"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ〘") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ〙")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ〚"))
		#		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ〛"),l111ll_l1_+title,link,602,l1llll_l1_)
	return
def PLAY(url):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ〜"))
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ〝"),url,l11lll_l1_ (u"ࠬ࠭〞"),l11lll_l1_ (u"࠭ࠧ〟"),l11lll_l1_ (u"ࠧࠨ〠"),l11lll_l1_ (u"ࠨࠩ〡"),l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ〢"))
	html = response.content
	# l1llll1_l1_ l1l11l1_l1_
	link = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ〣"),html,re.DOTALL)
	link = link[0]
	post = link.split(l11lll_l1_ (u"ࠫࡵࡵࡳࡵ࠿ࠪ〤"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ〥"))
	post = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ〦"),post)
	if l11lll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳࠨ〧") in list(post.keys()):
		links = post[l11lll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࡴࠩ〨")]
		l1l111_l1_ = list(links.keys())
		links = list(links.values())
		l111l1_l1_ = zip(l1l111_l1_,links)
		for title,link in l111l1_l1_:
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ〩")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫〪ࠫ")
			l1111_l1_.append(link)
		l11lll_l1_ (u"ࠦࠧࠨࠊࠊࠋࠦ࡭࡫ࠦ࡬ࡪࡰ࡮ࠤࡦࡴࡤࠡࠩ࡫ࡸࡹࡶࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠ࡭࡫ࡱ࡯ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠬ࡮࡬ࡲࡰࠐࠉࠊࡪࡤࡷ࡭ࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࡨࡢࡵ࡫ࡁࠬ࠯࡛࠲࡟ࠍࠍࠎࡶࡡࡳࡶࡶࠤࡂࠦࡨࡢࡵ࡫࠲ࡸࡶ࡬ࡪࡶࠫࠫࡤࡥࠧࠪࠌࠌࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࠉࡧࡱࡵࠤࡵࡧࡲࡵࠢ࡬ࡲࠥࡶࡡࡳࡶࡶ࠾ࠏࠏࠉࠊࡶࡵࡽ࠿ࠐࠉࠊࠋࠌࡴࡦࡸࡴࠡ࠿ࠣࡦࡦࡹࡥ࠷࠶࠱ࡦ࠻࠺ࡤࡦࡥࡲࡨࡪ࠮ࡰࡢࡴࡷ࠯ࠬࡃࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠿࠳࠻࠲࠾࠿࠺ࠡࡲࡤࡶࡹࠦ࠽ࠡࡲࡤࡶࡹ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࠋࠌࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡱࡣࡵࡸ࠮ࠐࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠋࠋࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࠎࡲࡩ࡯࡭ࡶࠤࡂࠦ࡬ࡪࡰ࡮ࡷ࠳ࡹࡰ࡭࡫ࡷࡰ࡮ࡴࡥࡴࠪࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠳ࠢ࡬ࡲࠥࢀࡺࡻ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠵࠲ࡸࡶ࡬ࡪࡶࠫࠫࠥࡃ࠾ࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋ〫ࠥࠦࠧ")
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ〬"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ〭ࠬ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ〮"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨ〯ࠩ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ〰"),l11lll_l1_ (u"ࠪ࠯ࠬ〱"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ〲")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ〳"),l11lll_l1_ (u"࠭แ้ีอหࠥ࡬࡯ࡴࡶࡤ࠱ࡹࡼࠧ〴"),l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࠪ〵"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ〶"))
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭〷")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ〸"))
	return
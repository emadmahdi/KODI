# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨ伩")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡏࡗ࡙ࡥࠧ伪")
l11lll1ll111_l1_ = 4
l11lll1l11ll_l1_ = 10
def MAIN(mode,url,text,l1l11l1_l1_,l1ll111l111_l1_):
	try: l11lll111l11_l1_ = str(l1ll111l111_l1_[l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伫")])
	except: l11lll111l11_l1_ = l11lll_l1_ (u"ࠪࠫ伬")
	if   mode==160: results = MENU()
	elif mode==161: results = l11llll1l111_l1_(text)
	elif mode==162: results = l11ll1lll11l_l1_(text,162)
	elif mode==163: results = l11ll1lll11l_l1_(text,163)
	elif mode==164: results = l11llll11ll1_l1_(text)
	elif mode==165: results = l11ll1l1lll1_l1_(url,text)
	elif mode==166: results = l11lll1lll1l_l1_(url,text)
	elif mode==167: results = l11ll1l1ll1l_l1_(url,text)
	elif mode==168: results = l11ll1l111l1_l1_(url,text)
	elif mode==761: results = l11llll111ll_l1_()
	elif mode==762: results = l11lll11l11l_l1_()
	elif mode==763: results = l11lll111lll_l1_(l11lll111l11_l1_,text,l1l11l1_l1_)
	elif mode==764: results = l11lll1l1l1l_l1_(l11lll111l11_l1_,text)
	elif mode==765: results = l11llll1111l_l1_(l11lll111l11_l1_,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伭"),l11lll_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭伮"),l11lll_l1_ (u"࠭ࠧ伯"),161,l11lll_l1_ (u"ࠧࠨ估"),l11lll_l1_ (u"ࠨࠩ伱"),l11lll_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ伲"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ伳"),l11lll_l1_ (u"ࠫ็ูๅࠡ฻ื์ฬฬ๊ࠨ伴"),l11lll_l1_ (u"ࠬ࠭伵"),162,l11lll_l1_ (u"࠭ࠧ伶"),l11lll_l1_ (u"ࠧࠨ伷"),l11lll_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ伸"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伹"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭伺"),l11lll_l1_ (u"ࠫࠬ伻"),163,l11lll_l1_ (u"ࠬ࠭似"),l11lll_l1_ (u"࠭ࠧ伽"),l11lll_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ伾"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ伿"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ佀"),l11lll_l1_ (u"ࠪࠫ佁"),164,l11lll_l1_ (u"ࠫࠬ佂"),l11lll_l1_ (u"ࠬ࠭佃"),l11lll_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ佄"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ佅"),l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ但"),l11lll_l1_ (u"ࠩࠪ佇"),763,l11lll_l1_ (u"ࠪࠫ佈"),l11lll_l1_ (u"ࠫࠬ佉"),l11lll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ佊"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ佋"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ佌"),l11lll_l1_ (u"ࠨࠩ位"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ低"),l11lll_l1_ (u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ住"),l11lll_l1_ (u"ࠫࠬ佐"),163,l11lll_l1_ (u"ࠬ࠭佑"),l11lll_l1_ (u"࠭ࠧ佒"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ体"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ佔"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ何"),l11lll_l1_ (u"ࠪࠫ佖"),163,l11lll_l1_ (u"ࠫࠬ佗"),l11lll_l1_ (u"ࠬ࠭佘"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ余"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ佚"),l11lll_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ佛"),l11lll_l1_ (u"ࠩࠪ作"),162,l11lll_l1_ (u"ࠪࠫ佝"),l11lll_l1_ (u"ࠫࠬ佞"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭佟"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭你"),l11lll_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ佡"),l11lll_l1_ (u"ࠨࠩ佢"),162,l11lll_l1_ (u"ࠩࠪ佣"),l11lll_l1_ (u"ࠪࠫ佤"),l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ佥"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佦"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩ佧"),l11lll_l1_ (u"ࠧࠨ佨"),164,l11lll_l1_ (u"ࠨࠩ佩"),l11lll_l1_ (u"ࠩࠪ佪"),l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭佫"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ佬"),l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ佭"),l11lll_l1_ (u"࠭ࠧ佮"),765,l11lll_l1_ (u"ࠧࠨ佯"),l11lll_l1_ (u"ࠨࠩ佰"),l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ佱"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ佲"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ佳"),l11lll_l1_ (u"ࠬ࠭佴"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭併"),l11lll_l1_ (u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ佶"),l11lll_l1_ (u"ࠨࠩ佷"),163,l11lll_l1_ (u"ࠩࠪ佸"),l11lll_l1_ (u"ࠪࠫ佹"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ佺"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佻"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ佼"),l11lll_l1_ (u"ࠧࠨ佽"),163,l11lll_l1_ (u"ࠨࠩ佾"),l11lll_l1_ (u"ࠩࠪ使"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ侀"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ侁"),l11lll_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭侂"),l11lll_l1_ (u"࠭ࠧ侃"),162,l11lll_l1_ (u"ࠧࠨ侄"),l11lll_l1_ (u"ࠨࠩ侅"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ來"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侇"),l11lll_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ侈"),l11lll_l1_ (u"ࠬ࠭侉"),162,l11lll_l1_ (u"࠭ࠧ侊"),l11lll_l1_ (u"ࠧࠨ例"),l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ侌"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侍"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧ侎"),l11lll_l1_ (u"ࠫࠬ侏"),164,l11lll_l1_ (u"ࠬ࠭侐"),l11lll_l1_ (u"࠭ࠧ侑"),l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ侒"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侓"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ侔"),l11lll_l1_ (u"ࠪࠫ侕"),764,l11lll_l1_ (u"ࠫࠬ侖"),l11lll_l1_ (u"ࠬ࠭侗"),l11lll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ侘"))
	return
def l11llll111ll_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侙"),l11lll_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧ侚")+l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧ供"),l11lll_l1_ (u"ࠪࠫ侜"),764)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ依"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ侞"),l11lll_l1_ (u"࠭ࠧ侟"),9999)
	for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
		l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡋࡓࠫ侠")+str(l11lll111l11_l1_)+l11lll_l1_ (u"ࠨࡡࠪ価")
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侢"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬ侣")+text_numbers[l11lll111l11_l1_],l11lll_l1_ (u"ࠫࠬ侤"),764,l11lll_l1_ (u"ࠬ࠭侥"),l11lll_l1_ (u"࠭ࠧ侦"),l11lll_l1_ (u"ࠧࠨ侧"),l11lll_l1_ (u"ࠨࠩ侨"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侩"):l11lll111l11_l1_})
	return
def l11lll11l11l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侪"),l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ侫")+l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩ侬"),l11lll_l1_ (u"࠭ࠧ侭"),765)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ侮"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ侯"),l11lll_l1_ (u"ࠩࠪ侰"),9999)
	for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
		#l11lll111111_l1_ = l11lll_l1_ (u"ࠪࠤࡒ࠹ࡕࠨ侱")+str(l11lll111l11_l1_)
		l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡓࡕࠨ侲")+str(l11lll111l11_l1_)+l11lll_l1_ (u"ࠬࡥࠧ侳")
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侴"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ侵")+text_numbers[l11lll111l11_l1_],l11lll_l1_ (u"ࠨࠩ侶"),765,l11lll_l1_ (u"ࠩࠪ侷"),l11lll_l1_ (u"ࠪࠫ侸"),l11lll_l1_ (u"ࠫࠬ侹"),l11lll_l1_ (u"ࠬ࠭侺"),{l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭侻"):l11lll111l11_l1_})
	return
def l11llll111l1_l1_(l1l1l1ll1ll_l1_):
	l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
	try:
		if l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭侼") in l1l1l1ll1ll_l1_: l1l1l1l11l1_l1_(l1l1l1ll1ll_l1_)
		else: l1l1l1l11l1_l1_()
		l11lll11l111_l1_ = False
	except: l11lll11l111_l1_ = True
	l1l1l1ll1ll_l1_ = TRANSLATE(l1l1l1ll1ll_l1_)
	if l11lll11l111_l1_: DIALOG_NOTIFICATION(l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨใื่ࠥฮ็ัษࠣห้๋่ใ฻ࠪ侽"),time=2000)
	else: DIALOG_NOTIFICATION(l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩอ้ࠥาไษࠢส่ศ่ำศ็ࠪ侾"),time=2000)
	return l11lll11l111_l1_
def l11lll1111l1_l1_(l11lll11l1l1_l1_=True):
	if not l11lll11l1l1_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ便"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ俀"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ俁"))
		if results:
			contentsDICT = results
			return
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭係"),l11lll_l1_ (u"ࠧࠨ促"),l11lll_l1_ (u"ࠨࠩ俄"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ俅"),l11lll_l1_ (u"่่ࠪ๐ࠠห็็สࠥํะ่ࠢส่็อฦๆหࠣ࠲ࠥอไษำ้ห๊า๋ࠠฯอหัࠦร็ࠢํๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์ࠥอไห์ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐ำหะิะ๋ࠥๆ่ษࠣๅ็฽ࠠศๆฦๆุอๅࠡษ็ีห๐ำ๋หࠣ࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰ࠣ฽๊๊๊ส่่ࠢหࠦฬๆ์฼ࠤฬ๊รใีส้ࠥะอหษฯࠤ฾อฯสࠢฦๆ้ࠦๅ็ࠢ࠶ࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠศๆล๊ࠥลࠧ俆"))
	if l1ll111ll1_l1_!=1: return
	l11ll1l11lll_l1_ = menuItemsLIST
	l11ll1llllll_l1_,l11ll1llll1l_l1_ = 0,l11lll_l1_ (u"ࠫࠬ俇")
	for l1l1l1ll1ll_l1_ in l11l1l1l1l1_l1_:
		time.sleep(0.5)
		l11lll11l111_l1_ = l11llll111l1_l1_(l1l1l1ll1ll_l1_)
		if l11lll11l111_l1_:
			l11ll1llllll_l1_ += 1
			l11ll1llll1l_l1_ += l11lll_l1_ (u"ࠬࠦࠧ俈")+l1l1l1ll1ll_l1_
			if l11ll1llllll_l1_>=l11lll1l11ll_l1_: break
	menuItemsLIST[:] = l11ll1l11lll_l1_
	if l11ll1llllll_l1_>=l11lll1l11ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ俉"),l11lll_l1_ (u"ࠧࠨ俊"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ俋"),l11lll_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ俌")+str(l11ll1llllll_l1_)+l11lll_l1_ (u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ俍")+l11ll1llll1l_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ俎"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ俏"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ俐"),l11lll_l1_ (u"ࠧࠨ俑"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ俒"),l11lll_l1_ (u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ俓"))
	return
def l11ll1ll1ll1_l1_(l11lll111l11_l1_,options):
	l1l1111111l_l1_ = False
	l11ll1l111ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1111111l_l1_ and l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ俔") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ俕"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ俖"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ俗")+l11lll111l11_l1_)
	elif l11lll_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ俘") not in options or l11lll_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ俙") not in options:
		import IPTV
		message = l11lll_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ俚")
		if l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ俛") not in options:
			try: IPTV.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ俜"),l11lll_l1_ (u"ࠬ࠭保"),l11lll_l1_ (u"࠭ࠧ俞"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ俟"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ俠"),l11lll_l1_ (u"ࠩࠪ信"),l11lll_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ俢"),message)
			try: IPTV.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ俣"),l11lll_l1_ (u"ࠬ࠭俤"),l11lll_l1_ (u"࠭ࠧ俥"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ俦"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ俧"),l11lll_l1_ (u"ࠩࠪ俨"),l11lll_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ俩"),message)
			try: IPTV.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ俪"),l11lll_l1_ (u"ࠬ࠭俫"),l11lll_l1_ (u"࠭ࠧ俬"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ俭"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ修"),l11lll_l1_ (u"ࠩࠪ俯"),l11lll_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ俰"),message)
		if l11lll_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ俱") not in options:
			try: IPTV.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ俲"),l11lll_l1_ (u"࠭ࠧ俳"),l11lll_l1_ (u"ࠧࠨ俴"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俵"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ俶"),l11lll_l1_ (u"ࠪࠫ俷"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ俸"),message)
			try: IPTV.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ俹"),l11lll_l1_ (u"࠭ࠧ俺"),l11lll_l1_ (u"ࠧࠨ俻"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭俼"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ俽"),l11lll_l1_ (u"ࠪࠫ俾"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ俿"),message)
		results = menuItemsLIST
		if l1l1111111l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ倀"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ倁")+l11lll111l11_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll1l111ll_l1_
	return results
def l11lll111ll1_l1_(l11lll111l11_l1_,options):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ倂"),l11lll_l1_ (u"ࠨࠩ倃"),l11lll_l1_ (u"ࠩࠪ倄"),options)
	l1l1111111l_l1_ = False
	l11ll1l111ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1111111l_l1_ and l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ倅") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ倆"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ倇"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭倈")+l11lll111l11_l1_)
	elif l11lll_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ倉") not in options or l11lll_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ倊") not in options:
		import M3U
		message = l11lll_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ個")
		if l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ倌") not in options:
			try: M3U.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ倍"),l11lll_l1_ (u"ࠬ࠭倎"),l11lll_l1_ (u"࠭ࠧ倏"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倐"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ們"),l11lll_l1_ (u"ࠩࠪ倒"),l11lll_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ倓"),message)
			try: M3U.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ倔"),l11lll_l1_ (u"ࠬ࠭倕"),l11lll_l1_ (u"࠭ࠧ倖"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倗"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ倘"),l11lll_l1_ (u"ࠩࠪ候"),l11lll_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ倚"),message)
			try: M3U.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ倛"),l11lll_l1_ (u"ࠬ࠭倜"),l11lll_l1_ (u"࠭ࠧ倝"),options+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倞"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ借"),l11lll_l1_ (u"ࠩࠪ倠"),l11lll_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ倡"),message)
		if l11lll_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ倢") not in options:
			try: M3U.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ倣"),l11lll_l1_ (u"࠭ࠧ値"),l11lll_l1_ (u"ࠧࠨ倥"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倦"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ倧"),l11lll_l1_ (u"ࠪࠫ倨"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ倩"),message)
			try: M3U.GROUPS(l11lll111l11_l1_,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ倪"),l11lll_l1_ (u"࠭ࠧ倫"),l11lll_l1_ (u"ࠧࠨ倬"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倭"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ倮"),l11lll_l1_ (u"ࠪࠫ倯"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ倰"),message)
		results = menuItemsLIST
		if l1l1111111l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ倱"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭倲")+l11lll111l11_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll1l111ll_l1_
	return results
def l11lll111lll_l1_(l11lll111l11_l1_,options,l11ll1ll1111_l1_):
	if l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ倳") in options and l11ll1ll1111_l1_==l11lll_l1_ (u"ࠨࠩ倴"): l11lll1111l1_l1_(True)
	elif l11ll1ll1111_l1_: l11lll1111l1_l1_(False)
	l11ll1ll11ll_l1_ = options.replace(l11lll_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ倵"),l11lll_l1_ (u"ࠪࠫ倶")).replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭倷"),l11lll_l1_ (u"ࠬ࠭倸")).replace(l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ倹"),l11lll_l1_ (u"ࠧࠨ债"))
	if not l11ll1ll1111_l1_:
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭倻"),l11lll_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭值"),l11lll_l1_ (u"ࠪࠫ倽"),763,l11lll_l1_ (u"ࠫࠬ倾"),l11lll_l1_ (u"ࠬ࠭倿"),l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ偀")+l11ll1ll11ll_l1_,l11lll_l1_ (u"ࠧࠨ偁"),{l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ偂"):l11lll111l11_l1_})
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ偃"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ偄"),l11lll_l1_ (u"ࠫࠬ偅"),9999)
	l1ll1l1111_l1_ = [l11lll_l1_ (u"ࠬษแๅษ่ࠫ偆"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠧ假"),l11lll_l1_ (u"ࠧๆีิั๏อสࠨ偈"),l11lll_l1_ (u"ࠨสิห๊าࠧ偉"),l11lll_l1_ (u"ࠩฦ฻ๆอไ๊ࠡๆีฯ๎ๆࠨ偊"),l11lll_l1_ (u"ࠪี๊฼ว็ࠩ偋"),l11lll_l1_ (u"ࠫศำฯฬ࠯ฦาึ࠭偌"),l11lll_l1_ (u"ูࠬไศี็ࠫ偍"),l11lll_l1_ (u"࠭ๅ้ีํๆ๎࠭偎"),l11lll_l1_ (u"ࠧฤึ๊ี࠲ษใฬำࠪ偏"),l11lll_l1_ (u"ࠨษ็ฦ๋࠭偐"),l11lll_l1_ (u"ูࠩั่࠭偑"),l11lll_l1_ (u"ࠪี๏อึสࠩ偒"),l11lll_l1_ (u"๋ࠫ๐สโๆๆืࠬ偓"),l11lll_l1_ (u"๋ࠬๅฬๆํ๊ࠬ偔"),l11lll_l1_ (u"࠭ศฬࠢะ๎ࠬ偕"),l11lll_l1_ (u"ࠧะ์้๎ฮ࠭偖"),l11lll_l1_ (u"ࠨี้์ฬะࠧ偗"),l11lll_l1_ (u"ࠩฦาึ๏ࠧ偘")]
	l11ll1l1l111_l1_ = [l11lll_l1_ (u"ࠪหๆ๊วๆࠩ偙"),l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ做"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ偛"),l11lll_l1_ (u"࠭แๅ็ࠪ停")]
	l11lll1l1ll1_l1_ = [l11lll_l1_ (u"ࠧๆี็ื้࠭偝"),l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ偞")]
	l11llll11lll_l1_ = [l11lll_l1_ (u"่ࠩืฬือࠨ偟"),l11lll_l1_ (u"ุ้ࠪือ๋ษอࠫ偠")]
	l11ll1ll11l1_l1_ = [l11lll_l1_ (u"ࠫอืวๆฮࠪ偡"),l11lll_l1_ (u"ࠬࡹࡨࡰࡹࠪ偢"),l11lll_l1_ (u"࠭สๅใี๎ํ์ࠧ偣"),l11lll_l1_ (u"ࠧหๆํๅื๐่็ࠩ偤")]
	l11lll1l111l_l1_ = [l11lll_l1_ (u"ࠨษ้้๏࠭健"),l11lll_l1_ (u"ࠩๆีฯ๎ๆࠨ偦"),l11lll_l1_ (u"ࠪ็ฬืส้่ࠪ偧"),l11lll_l1_ (u"ࠫࡰ࡯ࡤࡴࠩ偨"),l11lll_l1_ (u"ࠬ฽แๅࠩ偩"),l11lll_l1_ (u"࠭วุใส่ࠬ偪")]
	l111l111_l1_ = [l11lll_l1_ (u"ࠧา็ูห๋࠭偫")]
	l1lllll1l_l1_ = [l11lll_l1_ (u"ࠨษะำะ࠭偬"),l11lll_l1_ (u"ࠩสาึ࠭偭"),l11lll_l1_ (u"้ࠪํิัࠨ偮"),l11lll_l1_ (u"ࠫัี๊ะࠩ偯"),l11lll_l1_ (u"๋ࠬึศใࠪ偰"),l11lll_l1_ (u"࠭อะ์ฮࠫ偱")]
	l11ll1ll1lll_l1_ = [l11lll_l1_ (u"ࠧิๆสื้࠭偲"),l11lll_l1_ (u"ࠨี็ื้ํࠧ偳")]
	l11ll1l1111l_l1_ = [l11lll_l1_ (u"ࠩส฾ฬ์๊ࠨ側"),l11lll_l1_ (u"้ࠪํู๊ใ๋ࠪ偵"),l11lll_l1_ (u"่๊๊ࠫษࠩ偶"),l11lll_l1_ (u"ࠬำแๅࠩ偷"),l11lll_l1_ (u"࠭࡭ࡶࡵ࡬ࡧࠬ偸")]
	l1111ll1l_l1_ = [l11lll_l1_ (u"ࠧศๅฮีࠬ偹"),l11lll_l1_ (u"ࠨษื๋ึ࠭偺"),l11lll_l1_ (u"่้ࠩ๏ุ็ࠨ偻"),l11lll_l1_ (u"ࠪห฾๊้ࠨ偼"),l11lll_l1_ (u"๊ࠫิสศำ๊ࠫ偽"),l11lll_l1_ (u"๋ࠬฮหษิหฯ࠭偾"),l11lll_l1_ (u"࠭วใ๊์ࠫ偿")]
	l11ll1l11111_l1_ = [l11lll_l1_ (u"ࠧศๆส๊ࠬ傀"),l11lll_l1_ (u"ࠨฯส่๏࠭傁"),l11lll_l1_ (u"่ࠩฯอะࠧ傂"),l11lll_l1_ (u"ࠪีฬฬฬࠨ傃")]
	l11ll1l11l11_l1_ = [l11lll_l1_ (u"ࠫ฻ำใࠨ傄"),l11lll_l1_ (u"้่ࠬๆ์า๎ࠬ傅")]
	l11lll1lll11_l1_ = [l11lll_l1_ (u"࠭ั๋ษู๋ࠬ傆"),l11lll_l1_ (u"ࠧไ๊ิ๋ࠬ傇"),l11lll_l1_ (u"ࠨ็ุหึ฿็ࠨ傈"),l11lll_l1_ (u"ࠩื์ฯ࠭傉"),l11lll_l1_ (u"ࠪี๏อึสࠩ傊")]
	l11lll11ll11_l1_ = [l11lll_l1_ (u"๋ࠫ๐สโๆๆืࠬ傋"),l11lll_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭傌"),l11lll_l1_ (u"࠭ๆ๋ฬไ่๏้ำࠨ傍")]
	l11ll1l11ll1_l1_ = [l11lll_l1_ (u"ࠧๆ็ฮ่๏์ࠧ傎"),l11lll_l1_ (u"ࠨษืาฬ฻ࠧ傏"),l11lll_l1_ (u"้ࠩะํ๋ࠧ傐")]
	l1l1lll1l_l1_ = [l11lll_l1_ (u"ࠪฬะࠦอ๋ࠩ傑"),l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ傒"),l11lll_l1_ (u"่ࠬๆศ้ࠪ傓"),l11lll_l1_ (u"࠭โ็๊สฮࠬ傔")]
	l11lll11llll_l1_ = [l11lll_l1_ (u"ࠧะ์้ࠫ傕"),l11lll_l1_ (u"ࠨษา฽๏ํࠧ傖"),l11lll_l1_ (u"ࠩี๎ฬืวหࠩ傗"),l11lll_l1_ (u"่ࠪ฼๋๊ศฬࠪ傘"),l11lll_l1_ (u"ࠫิ฿วยࠩ備"),l11lll_l1_ (u"่ࠬัศ่ࠪ傚"),l11lll_l1_ (u"࠭โึษษำࠬ傛"),l11lll_l1_ (u"ࠧาอสลࠬ傜"),l11lll_l1_ (u"ࠨ็ิะ฾๐็ࠨ傝"),l11lll_l1_ (u"ࠩสิฬ์ࠧ傞"),l11lll_l1_ (u"ࠪหุ๊วๆࠩ傟"),l11lll_l1_ (u"ࠫฯ๎วี์ะࠫ傠"),l11lll_l1_ (u"ࠬิืษࠩ傡"),l11lll_l1_ (u"࠭อ้ิ๋๎ࠬ傢"),l11lll_l1_ (u"ฺࠧฬหหฯ࠭傣"),l11lll_l1_ (u"ࠨ็๋ห้๐ฯࠨ傤"),l11lll_l1_ (u"้ࠩ์ฬ฿๊ࠨ傥"),l11lll_l1_ (u"ࠪ฽็อฦะࠩ傦"),l11lll_l1_ (u"ࠫฬ์วี์าࠫ傧")]
	l11ll1l1l11l_l1_ = [l11lll_l1_ (u"ࠬ࠷࠹ࠨ储"),l11lll_l1_ (u"࠭࠲࠱ࠩ傩"),l11lll_l1_ (u"ࠧ࠳࠳ࠪ傪"),l11lll_l1_ (u"ࠨ࠴࠵ࠫ傫"),l11lll_l1_ (u"ࠩ࠵࠷ࠬ催"),l11lll_l1_ (u"ࠪ࠶࠹࠭傭"),l11lll_l1_ (u"ࠫ࠷࠻ࠧ傮"),l11lll_l1_ (u"ࠬ࠸࠶ࠨ傯")]
	if not l11ll1ll1111_l1_:
		l11ll1ll1111_l1_ = 0
		for l11lll1111ll_l1_ in l1ll1l1111_l1_:
			l11ll1ll1111_l1_ += 1
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭傰"),l111ll_l1_+l11lll1111ll_l1_,l11lll_l1_ (u"ࠧࠨ傱"),763,l11lll_l1_ (u"ࠨࠩ傲"),str(l11ll1ll1111_l1_),l11ll1ll11ll_l1_,l11lll_l1_ (u"ࠩࠪ傳"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ傴"):l11lll111l11_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1ll111lll1_l1_ = name.lower()
			category = []
			if any(value in l1ll111lll1_l1_ for value in l11ll1l1l111_l1_): category.append(1)
			if any(value in l1ll111lll1_l1_ for value in l11lll1l1ll1_l1_): category.append(2)
			if any(value in l1ll111lll1_l1_ for value in l11llll11lll_l1_): category.append(3)
			if any(value in l1ll111lll1_l1_ for value in l11ll1ll11l1_l1_): category.append(4)
			if any(value in l1ll111lll1_l1_ for value in l11lll1l111l_l1_): category.append(5)
			if any(value in l1ll111lll1_l1_ for value in l111l111_l1_): category.append(6)
			if any(value in l1ll111lll1_l1_ for value in l1lllll1l_l1_) and l1ll111lll1_l1_ not in [l11lll_l1_ (u"ࠫฬิั๊ࠩ債")]: category.append(7)
			if any(value in l1ll111lll1_l1_ for value in l11ll1ll1lll_l1_): category.append(8)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l1111l_l1_): category.append(9)
			if any(value in l1ll111lll1_l1_ for value in l1111ll1l_l1_): category.append(10)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l11111_l1_): category.append(11)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l11l11_l1_): category.append(12)
			if any(value in l1ll111lll1_l1_ for value in l11lll1lll11_l1_): category.append(13)
			if any(value in l1ll111lll1_l1_ for value in l11lll11ll11_l1_): category.append(14)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l11ll1_l1_): category.append(15)
			if any(value in l1ll111lll1_l1_ for value in l1l1lll1l_l1_): category.append(16)
			if any(value in l1ll111lll1_l1_ for value in l11lll11llll_l1_): category.append(17)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l1l11l_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l11ll1ll1111_l1_:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傶"),l111ll_l1_+name,name,166,l11lll_l1_ (u"࠭ࠧ傷"),l11lll_l1_ (u"ࠧࠨ傸"),l11ll1ll11ll_l1_+l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ傹"))
	return
def l11lll1l1l1l_l1_(l11lll111l11_l1_,options):
	l1l1111111l_l1_ = False
	if l1l1111111l_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ傺"),l11lll_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ傻"),l11lll_l1_ (u"ࠫࠬ傼"),764,l11lll_l1_ (u"ࠬ࠭傽"),l11lll_l1_ (u"࠭ࠧ傾"),l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ傿"),l11lll_l1_ (u"ࠨࠩ僀"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ僁"):l11lll111l11_l1_})
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ僂"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ僃"),l11lll_l1_ (u"ࠬ࠭僄"),9999)
	l11ll1l111ll_l1_ = menuItemsLIST[:]
	import IPTV
	if l11lll111l11_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l11lll111l11_l1_,True): return
		l11ll1lll111_l1_ = l11ll1ll1ll1_l1_(l11lll111l11_l1_,options)
		l1ll1lll1ll_l1_ = sorted(l11ll1lll111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"࠭ࠧ僅"),True): return
		if l1l1111111l_l1_ and l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ僆") not in options:
			l1ll1lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭僇"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ僈"),l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࡅࡑࡒࠧ僉"))
		else:
			l11ll1l1l1l1_l1_,l1ll1lll1ll_l1_,l11ll1lll111_l1_ = [],[],[]
			for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1lll1ll_l1_ += l11ll1ll1ll1_l1_(str(l11lll111111_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1ll1lll1ll_l1_:
				if text not in l11ll1l1l1l1_l1_:
					l11ll1l1l1l1_l1_.append(text)
					l11lll1llll1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll111l111_l1_
					l11ll1lll111_l1_.append(l11lll1llll1_l1_)
			l1ll1lll1ll_l1_ = sorted(l11ll1lll111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1111111l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ僊"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤࡇࡌࡍࠩ僋"),l1ll1lll1ll_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll1l111ll_l1_+l1ll1lll1ll_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ僌"))
	return
def l11llll1111l_l1_(l11lll111l11_l1_,options):
	l1l1111111l_l1_ = False
	if l1l1111111l_l1_:
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ働"),l11lll_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ僎"),l11lll_l1_ (u"ࠩࠪ像"),765,l11lll_l1_ (u"ࠪࠫ僐"),l11lll_l1_ (u"ࠫࠬ僑"),l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ僒"),l11lll_l1_ (u"࠭ࠧ僓"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僔"):l11lll111l11_l1_})
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭僕"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ僖"),l11lll_l1_ (u"ࠪࠫ僗"),9999)
	l11ll1l111ll_l1_ = menuItemsLIST[:]
	import M3U
	if l11lll111l11_l1_:
		if not M3U.CHECK_TABLES_EXIST(l11lll111l11_l1_,True): return
		l11ll1lll111_l1_ = l11lll111ll1_l1_(l11lll111l11_l1_,options)
		l1ll1lll1ll_l1_ = sorted(l11ll1lll111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠫࠬ僘"),True): return
		if l1l1111111l_l1_ and l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ僙") not in options:
			l1ll1lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ僚"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭僛"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫ僜"))
		else:
			l11ll1l1l1l1_l1_,l1ll1lll1ll_l1_,l11ll1lll111_l1_ = [],[],[]
			for l11lll111111_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1lll1ll_l1_ += l11lll111ll1_l1_(str(l11lll111111_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1ll1lll1ll_l1_:
				if text not in l11ll1l1l1l1_l1_:
					l11ll1l1l1l1_l1_.append(text)
					l11lll1llll1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll111l111_l1_
					l11ll1lll111_l1_.append(l11lll1llll1_l1_)
			l1ll1lll1ll_l1_ = sorted(l11ll1lll111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1111111l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ僝"),l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࡄࡐࡑ࠭僞"),l1ll1lll1ll_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll1l111ll_l1_+l1ll1lll1ll_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ僟"))
	return
def l11ll1l1lll1_l1_(group,options):
	# l11ll1l1ll11_l1_ & iptv
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭僠"),l11lll_l1_ (u"࠭ࠧ僡"),group,options)
	l1l1111111l_l1_ = False
	results = []
	l11lll111l1l_l1_ = l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ僢") if l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠭僣") in options else l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ僤")
	if l1l1111111l_l1_: results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ僥"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭僦")+l11lll111l1l_l1_[:-1],group)
	if not results:
		for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1111111l_l1_: results += READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ僧"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ僨")+l11lll111l1l_l1_[:-1],l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ僩")+l11lll111l1l_l1_+str(l11lll111l11_l1_))
			elif l11lll111l1l_l1_==l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ僪"): results += l11ll1ll1ll1_l1_(str(l11lll111l11_l1_),l11lll_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ僫"))
			elif l11lll111l1l_l1_==l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ僬"): results += l11lll111ll1_l1_(str(l11lll111l11_l1_),l11lll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ僭"))
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in results:
			if text==group: l1l1l1l11ll1_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
		items,l1l1lll_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in menuItemsLIST:
			l11lll11lll1_l1_ = type,name[4:],url,mode,l11l_l1_,l1l11l1_l1_,text,context,l11lll_l1_ (u"ࠬ࠭僮")
			if l11lll11lll1_l1_ not in l1l1lll_l1_:
				l1l1lll_l1_.append(l11lll11lll1_l1_)
				item = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_
				items.append(item)
		results = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1111111l_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ僯")+l11lll111l1l_l1_[:-1],group,results,PERMANENT_CACHE)
	if l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ僰") in options and len(results)>l11lll1ll111_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僱"),l11lll_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭僲")+group+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭僳"),group,165,l11lll_l1_ (u"ࠫࠬ僴"),l11lll_l1_ (u"ࠬ࠭僵"),l11lll111l1l_l1_+l11lll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ僶"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僷"),l11lll_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ僸"),group,165,l11lll_l1_ (u"ࠩࠪ價"),l11lll_l1_ (u"ࠪࠫ僺"),l11lll111l1l_l1_+l11lll_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ僻"))
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ僼"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭僽"),l11lll_l1_ (u"ࠧࠨ僾"),9999)
		results = menuItemsLIST+random.sample(results,l11lll1ll111_l1_)
	menuItemsLIST[:] = results
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ僿"))
	return
def l11llll1l111_l1_(options):
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ儀"),l11lll_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭儁"),l11lll_l1_ (u"ࠫࠬ儂"),161,l11lll_l1_ (u"ࠬ࠭儃"),l11lll_l1_ (u"࠭ࠧ億"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ儅"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭儆"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儇"),l11lll_l1_ (u"ࠪࠫ儈"),9999)
	l1l1l1l11111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ儉"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儊")+l11lll_l1_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ儋"),l11lll_l1_ (u"ࠧࠨ儌"),147)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ儍"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ࡟ࡕࡕࠢࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭儎")+l11lll_l1_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ儏"),l11lll_l1_ (u"ࠫࠬ儐"),148)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ儑"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡌࡊࡑࠦࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ儒")+l11lll_l1_ (u"ࠧใ่สอࠥศ๊ࠡใํ่๊ࠦๅ็่ࠢ์็฿็ๆࠩ儓"),l11lll_l1_ (u"ࠨࠩ儔"),28)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ儕"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡍࡓࡈࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭儖")+l11lll_l1_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭儗"),l11lll_l1_ (u"ࠬ࠭儘"),41)
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ儙"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡏ࡜࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ儚")+l11lll_l1_ (u"ࠨไ้หฮࠦวๅๅ๋ฯึࠦๅ็่ࠢ์็฿็ๆࠩ儛"),l11lll_l1_ (u"ࠩࠪ儜"),135)
	import l1ll11l1l1ll_l1_
	l1ll11l1l1ll_l1_.ITEMS(l11lll_l1_ (u"ࠪ࠴ࠬ儝"),False)
	l1ll11l1l1ll_l1_.ITEMS(l11lll_l1_ (u"ࠫ࠶࠭儞"),False)
	l1ll11l1l1ll_l1_.ITEMS(l11lll_l1_ (u"ࠬ࠸ࠧ償"),False)
	#l1ll11l1l1ll_l1_.ITEMS(l11lll_l1_ (u"࠭࠳ࠨ儠"),False)
	if l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ儡") in options:
		menuItemsLIST[:] = l11ll1llll11_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11lll1ll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1ll111_l1_)
	menuItemsLIST[:] = l1l1l1l11111_l1_+menuItemsLIST
	return
def l11llll11ll1_l1_(options):
	options = options.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ儢"),l11lll_l1_ (u"ࠩࠪ儣")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ儤"),l11lll_l1_ (u"ࠫࠬ儥"))
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ儦") : l11lll_l1_ (u"࠭ࠧ儧") }
	url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭儨")
	data = {l11lll_l1_ (u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪ儩"):l11lll_l1_ (u"ࠩ࠸࠴ࠬ優")}
	data = l1ll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ儫"),url,data,headers,l11lll_l1_ (u"ࠫࠬ儬"),l11lll_l1_ (u"ࠬ࠭儭"),l11lll_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࡙࠭ࡓࡃࡑࡈࡔࡓ࡟ࡗࡋࡇࡉࡔ࡙࡟ࡇࡔࡒࡑࡤ࡝ࡏࡓࡆࡖ࠱࠶ࡹࡴࠨ儮"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩ儯"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭儰"),block,re.DOTALL)
	l11ll11llll1_l1_,l11ll1l1l1ll_l1_ = list(zip(*items))
	l11llll11111_l1_ = []
	l11llll11l1l_l1_ = [l11lll_l1_ (u"ࠩࠣࠫ儱"),l11lll_l1_ (u"ࠪࠦࠬ儲"),l11lll_l1_ (u"ࠫࡥ࠭儳"),l11lll_l1_ (u"ࠬ࠲ࠧ儴"),l11lll_l1_ (u"࠭࠮ࠨ儵"),l11lll_l1_ (u"ࠧ࠻ࠩ儶"),l11lll_l1_ (u"ࠨ࠽ࠪ儷"),l11lll_l1_ (u"ࠤࠪࠦ儸"),l11lll_l1_ (u"ࠪ࠱ࠬ儹")]
	l11lll1l1l11_l1_ = l11ll1l1l1ll_l1_+l11ll11llll1_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ儺"),l11lll_l1_ (u"ࠬ࠭儻"),l11lll_l1_ (u"࠭ࠧ儼"),str(l11lll1l1l11_l1_))
	for word in l11lll1l1l11_l1_:
		if word in l11ll1l1l1ll_l1_: l11lll11l1ll_l1_ = 2
		if word in l11ll11llll1_l1_: l11lll11l1ll_l1_ = 4
		l11ll1ll1l1l_l1_ = [i in word for i in l11llll11l1l_l1_]
		if any(l11ll1ll1l1l_l1_):
			index = l11ll1ll1l1l_l1_.index(True)
			l11ll1ll111l_l1_ = l11llll11l1l_l1_[index]
			l11lll1ll1l1_l1_ = l11lll_l1_ (u"ࠧࠨ儽")
			if word.count(l11ll1ll111l_l1_)>1: l11lll1ll1ll_l1_,l11lll1ll11l_l1_,l11lll1ll1l1_l1_ = word.split(l11ll1ll111l_l1_,2)
			else: l11lll1ll1ll_l1_,l11lll1ll11l_l1_ = word.split(l11ll1ll111l_l1_,1)
			if len(l11lll1ll1ll_l1_)>l11lll11l1ll_l1_: l11llll11111_l1_.append(l11lll1ll1ll_l1_.lower())
			if len(l11lll1ll11l_l1_)>l11lll11l1ll_l1_: l11llll11111_l1_.append(l11lll1ll11l_l1_.lower())
			if len(l11lll1ll1l1_l1_)>l11lll11l1ll_l1_: l11llll11111_l1_.append(l11lll1ll1l1_l1_.lower())
		elif len(word)>l11lll11l1ll_l1_: l11llll11111_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11llll11111_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11llll11111_l1_)),l11llll11111_l1_)
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࡲࡩࡴࡶࠣࡁࠥࡡࠧไๆ่หฯูࠦี๊สส๏ฯฺࠠำห๎ฮ࠭ࠬࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡว้็้๐า๋หࠪࡡࠏࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤ่๊ๅสࠢ็่อำหࠡ฻้๋ฬࡀࠧ࠭ࠢ࡯࡭ࡸࡺ࠲ࠪࠌࠌࡰ࡮ࡹࡴ࠲ࠢࡀࠤࡠࡣࠊࠊࡥࡲࡹࡳࡺࡳࠡ࠿ࠣࡰࡪࡴࠨ࡭࡫ࡶࡸ࠷࠯ࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪࡦࡳࡺࡴࡴࡴࠬ࠸࠭࠿ࠦࡲࡢࡰࡧࡳࡲ࠴ࡳࡩࡷࡩࡪࡱ࡫ࠨ࡭࡫ࡶࡸ࠷࠯ࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࡯ࡩࡳ࡭ࡴࡩࠫ࠽ࠤࡱ࡯ࡳࡵ࠳࠱ࡥࡵࡶࡥ࡯ࡦ่๊ࠫࠫๅสࠢ฼ุํอฦ๋หࠣี็๋ࠠࠨ࠭ࡶࡸࡷ࠮ࡩࠪࠫࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠌࠌࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่้เษ࠻ࠩ࠯ࠤࡱ࡯ࡳࡵࠫࠍࠍࠎࠩࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࠉࠤࡧ࡯࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࠿ࡀ࠴࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡢࡴࡥࡐࡎ࡙ࡔࠋࠋࠌࠧࡪࡲࡳࡦ࠼ࠣࡰ࡮ࡹࡴ࠳ࠢࡀࠤࡪࡴࡧࡍࡋࡖࡘࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤ่๊ๅสࠢ็่อำหࠡ฻้๋ฬࡀࠧ࠭ࠢ࡯࡭ࡸࡺ࠱ࠪࠌࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࠥࡂࠦ࠭࠲࠼ࠣࡦࡷ࡫ࡡ࡬ࠌࠌࠍࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࡳࡦࡣࡵࡧ࡭ࠦ࠽ࠡ࡮࡬ࡷࡹ࠸࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎࠨࠢࠣ儾")
	if l11lll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ儿") in options:
		l11ll1l11l1l_l1_ = l1l1ll11ll11_l1_
	elif l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ兀") in options:
		l11ll1l11l1l_l1_ = [l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ允")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠬ࠭兂"),True): return
	elif l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ元") in options:
		l11ll1l11l1l_l1_ = [l11lll_l1_ (u"ࠧࡎ࠵ࡘࠫ兄")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠨࠩ充"),True): return
	count,l11lll11111l_l1_ = 0,0
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ兆"),l11lll_l1_ (u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫ兇"),l11lll_l1_ (u"ࠫࠬ先"),164,l11lll_l1_ (u"ࠬ࠭光"),l11lll_l1_ (u"࠭ࠧ兊"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ克")+options)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ兌"),l11lll_l1_ (u"ࠩศ฽ฬีษࠡษ็ฬาัࠠศๆ฼ุํอฦ๋ࠩ免"),l11lll_l1_ (u"ࠪࠫ兎"),164,l11lll_l1_ (u"ࠫࠬ兏"),l11lll_l1_ (u"ࠬ࠭児"),l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ兑")+options)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ兒"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ兓"),l11lll_l1_ (u"ࠩࠪ兔"),9999)
	l11ll11lll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11llll11l11_l1_ = []
	for word in l11llll11111_l1_:
		l11lll1ll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂ࡟ࠧࡡࠪ࡜ࠦ࡞ࡡࡠࠫࡢࠪ࡝ࡡ࡟ࡀࡡࡄ࡝ࠨ兕"),word,re.DOTALL)
		if l11lll1ll11l_l1_: word = word.split(l11lll1ll11l_l1_[0],1)[0]
		l11lll1l11l1_l1_ = word.replace(l11lll_l1_ (u"ࠫ๖࠭兖"),l11lll_l1_ (u"ࠬ࠭兗")).replace(l11lll_l1_ (u"࠭๎ࠨ兘"),l11lll_l1_ (u"ࠧࠨ兙")).replace(l11lll_l1_ (u"ࠨํࠪ党"),l11lll_l1_ (u"ࠩࠪ兛")).replace(l11lll_l1_ (u"ࠪ๓ࠬ兜"),l11lll_l1_ (u"ࠫࠬ兝")).replace(l11lll_l1_ (u"ࠬ๒ࠧ兞"),l11lll_l1_ (u"࠭ࠧ兟"))
		l11lll1l11l1_l1_ = l11lll1l11l1_l1_.replace(l11lll_l1_ (u"ࠧ๑ࠩ兠"),l11lll_l1_ (u"ࠨࠩ兡")).replace(l11lll_l1_ (u"ࠩ๐ࠫ兢"),l11lll_l1_ (u"ࠪࠫ兣")).replace(l11lll_l1_ (u"ࠫ๗࠭兤"),l11lll_l1_ (u"ࠬ࠭入")).replace(l11lll_l1_ (u"࠭ฌࠨ兦"),l11lll_l1_ (u"ࠧࠨ內")).replace(l11lll_l1_ (u"ࠨโࠪ全"),l11lll_l1_ (u"ࠩࠪ兩"))
		if l11lll1l11l1_l1_: l11llll11l11_l1_.append(l11lll1l11l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11llll11l11_l1_)),l11llll11l11_l1_)
	l11lll1l1111_l1_ = []
	for l11l1lllll_l1_ in range(0,20):
		search = random.sample(l11llll11l11_l1_,1)[0]
		if search in l11lll1l1111_l1_: continue
		l11lll1l1111_l1_.append(search)
		l1l1l1ll1ll_l1_ = random.sample(l11ll1l11l1l_l1_,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ兪"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧ八")+str(l1l1l1ll1ll_l1_)+l11lll_l1_ (u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨ公")+search)
		#results = l1l1l1l11ll1_l1_(l11lll_l1_ (u"࠭ࠧ六"),l11lll_l1_ (u"ࠧࠨ兮"),l11lll_l1_ (u"ࠨࠩ兯"),l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ兰"),l11lll_l1_ (u"ࠪࠫ共"),search+l11lll_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ兲"),l11lll_l1_ (u"ࠬ࠭关"),l11lll_l1_ (u"࠭ࠧ兴"))
		l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
		l1l1l1ll1l1_l1_(search+l11lll_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ兵"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ其"),l11lll_l1_ (u"ࠩࠪ具"))
	l11ll11lll1l_l1_[0][1] = l11lll_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ典")+search+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ษฯฮࠤ฾์࡝ࠨ兹")
	menuItemsLIST[:] = l11ll1llll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11lll1ll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1ll111_l1_)
	menuItemsLIST[:] = l11ll11lll1l_l1_+menuItemsLIST
	#import l1ll1l1111l_l1_
	#l1ll1l1111l_l1_.SEARCH(search)
	return
def l11lll1lll1l_l1_(l11ll1l1llll_l1_,options):
	l11ll1l1llll_l1_ = l11ll1l1llll_l1_.replace(l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ兺"),l11lll_l1_ (u"࠭ࠧ养"))
	options = options.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ兼"),l11lll_l1_ (u"ࠨࠩ兽")).replace(l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭兾"),l11lll_l1_ (u"ࠪࠫ兿"))
	l11lll1111l1_l1_(False)
	if contentsDICT=={}: return
	if l11lll_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭冀") in options:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冁"),l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ冂")+l11ll1l1llll_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ冃"),l11ll1l1llll_l1_,166,l11lll_l1_ (u"ࠨࠩ冄"),l11lll_l1_ (u"ࠩࠪ内"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ円")+options)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ冇"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ冈"),l11ll1l1llll_l1_,166,l11lll_l1_ (u"࠭ࠧ冉"),l11lll_l1_ (u"ࠧࠨ冊"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭冋")+options)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ册"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ再"),l11lll_l1_ (u"ࠫࠬ冎"),9999)
	for l1l1ll11_l1_ in sorted(list(contentsDICT[l11ll1l1llll_l1_].keys())):
		type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = contentsDICT[l11ll1l1llll_l1_][l1l1ll11_l1_]
		if l11lll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ冏") in options or len(contentsDICT[l11ll1l1llll_l1_])==1:
			l1l1l1l11ll1_l1_(type,l11lll_l1_ (u"࠭ࠧ冐"),url,l1l1ll1l11l1_l1_,l11lll_l1_ (u"ࠧࠨ冑"),l1l11l1_l1_,text,l11lll_l1_ (u"ࠨࠩ冒"),l11lll_l1_ (u"ࠩࠪ冓"))
			menuItemsLIST[:] = l11ll1llll11_l1_(menuItemsLIST)
			l11ll1l111ll_l1_,l1ll1lll1ll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1ll1lll1ll_l1_)
			if l11lll_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ冔") in options: menuItemsLIST[:] = l11ll1l111ll_l1_+l1ll1lll1ll_l1_[:l11lll1ll111_l1_]
			else: menuItemsLIST[:] = l11ll1l111ll_l1_+l1ll1lll1ll_l1_
		elif l11lll_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ冕") in options: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冖"),l1l1ll11_l1_,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
	return
def l11ll1lll11l_l1_(options,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ冗"),l11lll_l1_ (u"ࠧࠨ冘"),l11lll_l1_ (u"ࠨࠩ写"),options)
	options = options.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ冚"),l11lll_l1_ (u"ࠪࠫ军")).replace(l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ农"),l11lll_l1_ (u"ࠬ࠭冝"))
	name,l11ll1ll1l11_l1_ = l11lll_l1_ (u"࠭ࠧ冞"),[]
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冟"),l11lll_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ冠")+name+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ冡"),l11lll_l1_ (u"ࠪࠫ冢"),mode,l11lll_l1_ (u"ࠫࠬ冣"),l11lll_l1_ (u"ࠬ࠭冤"),l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ冥")+options)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冦"),l11lll_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨ冧"),l11lll_l1_ (u"ࠩࠪ冨"),mode,l11lll_l1_ (u"ࠪࠫ冩"),l11lll_l1_ (u"ࠫࠬ冪"),l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ冫")+options)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ冬"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ冭"),l11lll_l1_ (u"ࠨࠩ冮"),9999)
	l11ll1l111ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	results = []
	if l11lll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ冯") in options:
		l11lll1111l1_l1_(False)
		if contentsDICT=={}: return
		l11ll1lll1ll_l1_ = list(contentsDICT.keys())
		l11ll1l1llll_l1_ = random.sample(l11ll1lll1ll_l1_,1)[0]
		l11llll11111_l1_ = list(contentsDICT[l11ll1l1llll_l1_].keys())
		l1l1ll11_l1_ = random.sample(l11llll11111_l1_,1)[0]
		type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = contentsDICT[l11ll1l1llll_l1_][l1l1ll11_l1_]
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ冰"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧ冱")+l1l1ll11_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ冲")+name+l11lll_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ决")+url+l11lll_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ冴")+str(l1l1ll1l11l1_l1_))
	elif l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ况") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ冶"),True): return
		for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11ll1ll1ll1_l1_(str(l11lll111l11_l1_),options)
		if not results: return
		type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ冷"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ冸")+name+l11lll_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ冹")+url+l11lll_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ冺")+str(l1l1ll1l11l1_l1_))
	elif l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭冻") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠨࠩ冼"),True): return
		for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11lll111ll1_l1_(str(l11lll111l11_l1_),options)
		if not results: return
		type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ冽"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ冾")+name+l11lll_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭冿")+url+l11lll_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ净")+str(l1l1ll1l11l1_l1_))
	l11lll11ll1l_l1_ = name
	l11ll1lllll1_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭凁"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ凂")+name+l11lll_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ凃")+url+l11lll_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ凄")+str(l1l1ll1l11l1_l1_))
		menuItemsLIST[:] = []
		if l1l1ll1l11l1_l1_==234 and l11lll_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ凅") in text: l1l1ll1l11l1_l1_ = 233
		if l1l1ll1l11l1_l1_==714 and l11lll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ准") in text: l1l1ll1l11l1_l1_ = 713
		if l1l1ll1l11l1_l1_==144: l1l1ll1l11l1_l1_ = 291
		dummy = l1l1l1l11ll1_l1_(type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
		#if l11lll_l1_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ凇") in html: l11ll1lll11l_l1_(options,mode)
		if l11lll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭凈") in options and l1l1ll1l11l1_l1_==167: del menuItemsLIST[:3]
		if l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭凉") in options and l1l1ll1l11l1_l1_==168: del menuItemsLIST[:3]
		l11ll1ll1l11_l1_[:] = l11ll1llll11_l1_(menuItemsLIST)
		if l11ll1lllll1_l1_ and l1l1l11111ll_l1_(l11lll_l1_ (u"ࡶࠩะ่็ฯࠧ凊")) in str(l11ll1ll1l11_l1_) or l1l1l11111ll_l1_(l11lll_l1_ (u"ࡷࠪั้่็ࠨ凋")) in str(l11ll1ll1l11_l1_):
			name = l11lll11ll1l_l1_
			l11ll1ll1l11_l1_[:] = l11ll1lllll1_l1_
			break
		l11lll11ll1l_l1_ = name
		l11ll1lllll1_l1_ = l11ll1ll1l11_l1_
		if str(l11ll1ll1l11_l1_).count(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ凌"))>0: break
		if str(l11ll1ll1l11_l1_).count(l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ凍"))>0: break
		if l1l1ll1l11l1_l1_==233: break	# iptv l111ll11_l1_ names l11l1lllll1_l1_ of l1l1l_l1_ name
		if l1l1ll1l11l1_l1_==713: break	# l11ll1l1ll11_l1_ l111ll11_l1_ names l11l1lllll1_l1_ of l1l1l_l1_ name
		if l1l1ll1l11l1_l1_==291: break	# l1ll1llll_l1_ l11lll1lllll_l1_ names l11l1lllll1_l1_ of l1ll1llll_l1_ l11lll1lllll_l1_ contents
		if l11ll1ll1l11_l1_: type,name,url,l1l1ll1l11l1_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(l11ll1ll1l11_l1_,1)[0]
	if not name: name = l11lll_l1_ (u"ࠬ࠴࠮࠯࠰ࠪ凎")
	elif name.count(l11lll_l1_ (u"࠭࡟ࠨ减"))>1: name = name.split(l11lll_l1_ (u"ࠧࡠࠩ凐"),2)[2]
	name = name.replace(l11lll_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫ凑"),l11lll_l1_ (u"ࠩࠪ凒"))#.replace(l11lll_l1_ (u"ࠪ࠰ࡒࡕࡖࡊࡇࡖ࠾ࠥ࠭凓"),l11lll_l1_ (u"ࠫࠬ凔")).replace(l11lll_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ凕"),l11lll_l1_ (u"࠭ࠧ凖")).replace(l11lll_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ凗"),l11lll_l1_ (u"ࠨࠩ凘"))
	name = name.replace(l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ凙"),l11lll_l1_ (u"ࠪࠫ凚"))
	l11ll1l111ll_l1_[0][1] = l11lll_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ凛")+name+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ凜")
	for i in range(9): random.shuffle(l11ll1ll1l11_l1_)
	if l11lll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ凝") in options: menuItemsLIST[:] = l11ll1l111ll_l1_+l11ll1ll1l11_l1_[:l11lll1ll111_l1_]
	else: menuItemsLIST[:] = l11ll1l111ll_l1_+l11ll1ll1l11_l1_
	return
def l11ll1l1ll1l_l1_(l11ll11lllll_l1_,l11lll1l1lll_l1_):
	l11lll1l1lll_l1_ = l11lll1l1lll_l1_.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ凞"),l11lll_l1_ (u"ࠨࠩ凟")).replace(l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭几"),l11lll_l1_ (u"ࠪࠫ凡"))
	l11ll1lll1l1_l1_ = l11lll1l1lll_l1_
	if l11lll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ凢") in l11lll1l1lll_l1_:
		l11ll1lll1l1_l1_ = l11lll1l1lll_l1_.split(l11lll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭凣"))[0]
		type = l11lll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ凤")
	elif l11lll_l1_ (u"ࠧࡗࡑࡇࠫ凥") in l11ll11lllll_l1_: type = l11lll_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ処")
	elif l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ凧") in l11ll11lllll_l1_: type = l11lll_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ凨")
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ凩"),l11lll_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ凪")+type+l11ll1lll1l1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ凫"),l11ll11lllll_l1_,167,l11lll_l1_ (u"ࠧࠨ凬"),l11lll_l1_ (u"ࠨࠩ凭"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凮")+l11lll1l1lll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ凯"),l11lll_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ凰"),l11ll11lllll_l1_,167,l11lll_l1_ (u"ࠬ࠭凱"),l11lll_l1_ (u"࠭ࠧ凲"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ凳")+l11lll1l1lll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭凴"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ凵"),l11lll_l1_ (u"ࠪࠫ凶"),9999)
	import IPTV
	for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ凷") in l11lll1l1lll_l1_: IPTV.GROUPS(str(l11lll111l11_l1_),l11ll11lllll_l1_,l11lll1l1lll_l1_,l11lll_l1_ (u"ࠬ࠭凸"),False)
		else: IPTV.ITEMS(str(l11lll111l11_l1_),l11ll11lllll_l1_,l11lll1l1lll_l1_,l11lll_l1_ (u"࠭ࠧ凹"),False)
	menuItemsLIST[:] = l11ll1llll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1ll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1ll111_l1_)
	return
def l11ll1l111l1_l1_(l11ll11lllll_l1_,l11lll1l1lll_l1_):
	l11lll1l1lll_l1_ = l11lll1l1lll_l1_.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ出"),l11lll_l1_ (u"ࠨࠩ击")).replace(l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭凼"),l11lll_l1_ (u"ࠪࠫ函"))
	l11ll1lll1l1_l1_ = l11lll1l1lll_l1_
	if l11lll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ凾") in l11lll1l1lll_l1_:
		l11ll1lll1l1_l1_ = l11lll1l1lll_l1_.split(l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ凿"))[0]
		type = l11lll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ刀")
	elif l11lll_l1_ (u"ࠧࡗࡑࡇࠫ刁") in l11ll11lllll_l1_: type = l11lll_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ刂")
	elif l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ刃") in l11ll11lllll_l1_: type = l11lll_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ刄")
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ刅"),l11lll_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ分")+type+l11ll1lll1l1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ切"),l11ll11lllll_l1_,168,l11lll_l1_ (u"ࠧࠨ刈"),l11lll_l1_ (u"ࠨࠩ刉"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ刊")+l11lll1l1lll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ刋"),l11lll_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ刌"),l11ll11lllll_l1_,168,l11lll_l1_ (u"ࠬ࠭刍"),l11lll_l1_ (u"࠭ࠧ刎"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ刏")+l11lll1l1lll_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭刐"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ刑"),l11lll_l1_ (u"ࠪࠫ划"),9999)
	import M3U
	for l11lll111l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ刓") in l11lll1l1lll_l1_: M3U.GROUPS(str(l11lll111l11_l1_),l11ll11lllll_l1_,l11lll1l1lll_l1_,l11lll_l1_ (u"ࠬ࠭刔"),False)
		else: M3U.ITEMS(str(l11lll111l11_l1_),l11ll11lllll_l1_,l11lll1l1lll_l1_,l11lll_l1_ (u"࠭ࠧ刕"),False)
	menuItemsLIST[:] = l11ll1llll11_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1ll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1ll111_l1_)
	return
def l11ll1llll11_l1_(menuItemsLIST):
	l11ll1ll1l11_l1_ = []
	for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in menuItemsLIST:
		if l11lll_l1_ (u"ࠧึใะอࠬ刖") in name or l11lll_l1_ (u"ࠨืไั์࠭列") in name or l11lll_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ刘") in name.lower(): continue
		l11ll1ll1l11_l1_.append([type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_])
	return l11ll1ll1l11_l1_
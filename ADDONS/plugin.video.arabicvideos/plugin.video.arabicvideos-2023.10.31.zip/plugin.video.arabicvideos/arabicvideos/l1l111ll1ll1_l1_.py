# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ䭛")
headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䭜") : l11lll_l1_ (u"ࠨࠩ䭝") }
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡑ࡛ࡠ࡟ࠨ䭞")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l1111l_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llllll_l1_(url)
	elif mode==188: results = l11lllll1lll_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11lllll1lll_l1_():
	message = l11lll_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ䭟")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䭠"),l11lll_l1_ (u"ࠬ࠭䭡"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䭢"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䭣"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䭤"),l11lll_l1_ (u"ࠩࠪ䭥"),189,l11lll_l1_ (u"ࠪࠫ䭦"),l11lll_l1_ (u"ࠫࠬ䭧"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䭨"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭩"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䭪")+l111ll_l1_+l11lll_l1_ (u"ࠨส๋็ุࠦว้ใํื๋่ࠥโ์ีࠤ้อๆะࠩ䭫"),l11ll1_l1_,181,l11lll_l1_ (u"ࠩࠪ䭬"),l11lll_l1_ (u"ࠪࠫ䭭"),l11lll_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ䭮"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭯"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭰")+l111ll_l1_+l11lll_l1_ (u"ࠧฤฯาฯࠥอไศใ็ห๊࠭䭱"),l11ll1_l1_,181,l11lll_l1_ (u"ࠨࠩ䭲"),l11lll_l1_ (u"ࠩࠪ䭳"),l11lll_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䭴"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭵"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䭶")+l111ll_l1_+l11lll_l1_ (u"࠭สๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࠬ䭷"),l11ll1_l1_,181,l11lll_l1_ (u"ࠧࠨ䭸"),l11lll_l1_ (u"ࠨࠩ䭹"),l11lll_l1_ (u"ࠩࡷࡺࠬ䭺"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䭻"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䭼")+l111ll_l1_+l11lll_l1_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬ䭽"),l11ll1_l1_,181,l11lll_l1_ (u"࠭ࠧ䭾"),l11lll_l1_ (u"ࠧࠨ䭿"),l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䮀"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䮁"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䮂")+l111ll_l1_+l11lll_l1_ (u"ࠫศ่่๊ࠢส่ฬ็ไศ็ࠣห้ำวๅ์ฬࠫ䮃"),l11ll1_l1_,181,l11lll_l1_ (u"ࠬ࠭䮄"),l11lll_l1_ (u"࠭ࠧ䮅"),l11lll_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䮆"))
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ䮇"),headers,l11lll_l1_ (u"ࠩࠪ䮈"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䮉"))
	items = re.findall(l11lll_l1_ (u"ࠫࡁ࡮࠲࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䮊"),html,re.DOTALL)
	for link,title in items:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䮋"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䮌")+l111ll_l1_+title,link,181)
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠧࠨ䮍")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ䮎"),headers,l11lll_l1_ (u"ࠩࠪ䮏"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ䮐"))
	if type==l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ䮑"): block = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃษอะอࠣห้ษแๅษ่ࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ䮒"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ䮓"): block = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧ䮔"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䮕"): block = re.findall(l11lll_l1_ (u"ࠩࡥࡸࡳ࠳࠲࠮ࡱࡹࡩࡷࡲࡡࡺࠪ࠱࠮ࡄ࠯࠼ࡴࡶࡼࡰࡪࡄࠧ䮖"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䮗"): block = re.findall(l11lll_l1_ (u"ࠫࡧࡺ࡮࠮࠳ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠨ࠯ࠬࡂ࠭ࡧࡺ࡮࠮࠴ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠧ䮘"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠬࡺࡶࠨ䮙"): block = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄสๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳ࡭ࠢࠨ䮚"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11lll_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䮛"),l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䮜")]:
		items = re.findall(l11lll_l1_ (u"ࠩࡶࡸࡾࡲࡥ࠾ࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䮝"),block,re.DOTALL)
	else: items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠸ࡡ࠰࠮࠻ࡠ࠯ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䮞"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l11ll1_l1_ = [l11lll_l1_ (u"ࠫๆ๐ไๆࠩ䮟"),l11lll_l1_ (u"ࠬอไฮๆๅอࠬ䮠"),l11lll_l1_ (u"࠭วๅฯ็ๆ์࠭䮡"),l11lll_l1_ (u"ฺࠧำูࠫ䮢"),l11lll_l1_ (u"ࠨࡔࡤࡻࠬ䮣"),l11lll_l1_ (u"ࠩࡖࡱࡦࡩ࡫ࡅࡱࡺࡲࠬ䮤"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ䮥"),l11lll_l1_ (u"ࠫฬาาศรࠪ䮦")]
	for l1llll_l1_,l11llll1ll11_l1_,l11llllll111_l1_,l11llllll11l_l1_ in items:
		if type in [l11lll_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䮧"),l11lll_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䮨")]:
			l1llll_l1_,link,l1lllllll1_l1_,title = l1llll_l1_,l11llll1ll11_l1_,l11llllll111_l1_,l11llllll11l_l1_
		else: l1llll_l1_,title,link,l1lllllll1_l1_ = l1llll_l1_,l11llll1ll11_l1_,l11llllll111_l1_,l11llllll11l_l1_
		link = l111l_l1_(link)
		link = link.replace(l11lll_l1_ (u"ࠧࡀࡸ࡬ࡩࡼࡃࡴࡳࡷࡨࠫ䮩"),l11lll_l1_ (u"ࠨࠩ䮪"))
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䮫"),l11lll_l1_ (u"ࠪࠫ䮬"),link,l1lllllll1_l1_)
		title = unescapeHTML(title)
		#l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠫฬั๎ฯสࡾหะํี็ࠪࠩ䮭"),title,re.DOTALL)
		#if l1lll1lll_l1_: title = l1lll1lll_l1_[0][0]
		if l11lll_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䮮") in title or l11lll_l1_ (u"࠭ศอ๊า๋ࠥ࠭䮯") in title:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䮰") + title.replace(l11lll_l1_ (u"ࠨสฯ์ิฯࠠࠨ䮱"),l11lll_l1_ (u"ࠩࠪ䮲")).replace(l11lll_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䮳"),l11lll_l1_ (u"ࠫࠬ䮴"))
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ䮵"))
		if l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭䮶") in title or l11lll_l1_ (u"ࠧศๆะ่็ํࠧ䮷") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡟ࡨ࠰࠭䮸"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䮹") + l1lll11_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䮺"),l111ll_l1_+title,link,183,l1llll_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l11l11ll1_l1_):
			link = link + l11lll_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䮻") + l1lllllll1_l1_
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䮼"),l111ll_l1_+title,link,182,l1llll_l1_)
		else:
			link = link + l11lll_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䮽") + l1lllllll1_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䮾"),l111ll_l1_+title,link,183,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠨࠩ䮿"):
		items = re.findall(l11lll_l1_ (u"ࠩ࡟ࡲࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䯀"),html,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠪห้฻แฮหࠣࠫ䯁"),l11lll_l1_ (u"ࠫࠬ䯂"))
			if title!=l11lll_l1_ (u"ࠬ࠭䯃"):
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䯄"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭䯅")+title,link,181)
	return
def l1llllll_l1_(url):
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䯆"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ䯇"),headers,l11lll_l1_ (u"ࠪࠫ䯈"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䯉"))
	block = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂ࠳࠰࠿ࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࡞࠴࠲࠿࡝ࠬࠫࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䯊"),html,re.DOTALL)
	title,dummy,l1llll_l1_ = block[0]
	name = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡜࠲࠰࠽ࡢ࠱ࠧ䯋"),title,re.DOTALL)
	if name: name = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䯌") + name[0][0]
	else: name = title
	items = []
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࡑࡹࡲࡨࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䯍"),html,re.DOTALL)
	if l1l1ll1_l1_:
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䯎"),l11lll_l1_ (u"ࠪࠫ䯏"),l11l11l_l1_,str(l1l1ll1_l1_))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䯐"),block,re.DOTALL)
		for link in items:
			link = l111l_l1_(link)
			title = re.findall(l11lll_l1_ (u"ࠬ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ䯑"),link.split(l11lll_l1_ (u"࠭࠯ࠨ䯒"))[-2],re.DOTALL)
			if not title: title = re.findall(l11lll_l1_ (u"ࠧࠩࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ䯓"),link.split(l11lll_l1_ (u"ࠨ࠱ࠪ䯔"))[-2],re.DOTALL)
			if title: title = l11lll_l1_ (u"ࠩࠣࠫ䯕") + title[0][1]
			else: title = l11lll_l1_ (u"ࠪࠫ䯖")
			title = name + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ䯗") + l11lll_l1_ (u"ࠬอไฮๆๅอࠬ䯘") + title
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䯙"),l111ll_l1_+title,link,182,l1llll_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䯚") in title or l11lll_l1_ (u"ࠨสฯ์ิํࠠࠨ䯛") in title:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䯜") + title.replace(l11lll_l1_ (u"ࠪฬั๎ฯสࠢࠪ䯝"),l11lll_l1_ (u"ࠫࠬ䯞")).replace(l11lll_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䯟"),l11lll_l1_ (u"࠭ࠧ䯠"))
		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䯡"),l111ll_l1_+title,url,182,l1llll_l1_)
	return
def PLAY(url):
	l11llllll1l1_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䯢"))
	l11l11l_l1_ = l11llllll1l1_l1_[0]
	del l11llllll1l1_l1_[0]
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ䯣"),headers,l11lll_l1_ (u"ࠪࠫ䯤"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䯥"))
	link = re.findall(l11lll_l1_ (u"ࠬ࡬࡯࡯ࡶ࠰ࡷ࡮ࢀࡥ࠻ࠢ࠵࠹ࡵࡾ࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯦"),html,re.DOTALL)[0]
	if link not in l11llllll1l1_l1_: l11llllll1l1_l1_.append(link)
	l1111_l1_ = []
	# l11lllll1l11_l1_
	for link in l11llllll1l1_l1_:
		if l11lll_l1_ (u"࠭࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ䯧") in link:
			l11lllll1l11_l1_ = link
			l1111_l1_.append(l11lllll1l11_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡣ࡬ࡲࠬ䯨"))
	# l11lllll11ll_l1_
	for link in l11llllll1l1_l1_:
		if l11lll_l1_ (u"ࠨ࠼࠲࠳ࡻࡨ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠫ䯩") in link:
			html = OPENURL_CACHED(l11111l_l1_,link,l11lll_l1_ (u"ࠩࠪ䯪"),headers,l11lll_l1_ (u"ࠪࠫ䯫"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䯬"))
			html = html.decode(l11lll_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡸ࠳࠱࠳࠷࠹ࠫ䯭")).encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䯮"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11llll1l1ll_l1_><l11llll1llll_l1_ /><l11llll1l1ll_l1_ l11lllll1ll1_l1_=l11lll_l1_ (u"ࠢࡤࡧࡱࡸࡪࡸࠢ䯯")>(\*\*\*\*\*\*\*\*|13721411411.l11llll1l11l_l1_|)
			html = html.replace(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䯰"),l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䯱"))
			html = html.replace(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䯲"),l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䯳"))
			html = html.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ䯴"),l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䯵"))
			html = html.replace(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ䯶"),l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䯷"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䯸"),html,re.DOTALL)
			if l1l1ll1_l1_:
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䯹"),l11lll_l1_ (u"ࠫࠬ䯺"),url,str(len(l1l1ll1_l1_)))
				l11llll1l1l1_l1_,l11lllll11l1_l1_ = [],[]
				if len(l1l1ll1_l1_)==1:
					title = l11lll_l1_ (u"ࠬ࠭䯻")
					block = html
				else:
					for block in l1l1ll1_l1_:
						l11l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠲࠯ࡅ࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰ࠫࠩ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䯼"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ䯽") + l11l1_l1_[0][1]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅ࠼ࡩࡴࠣࡷ࡮ࢀࡥ࠾ࠤ࠴ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴࠽ࠣࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶ࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䯾"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ䯿") + l11l1_l1_[0]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࠩ࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࠧࠦ࠯࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䰀"),block,re.DOTALL)
						if l11l1_l1_: block = l11l1_l1_[0] + l11lll_l1_ (u"ࠫࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䰁")
						l11lllll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࠨ࠯ࠬࡂ࠭࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲ࠫ䰂"),block,re.DOTALL)
						title = re.findall(l11lll_l1_ (u"࠭࠾ࠡࠬࠫ࡟ࡣࡂ࠾࡞࠭ࠬࠤ࠯ࡂࠧ䰃"),l11lllll1l1l_l1_[0][0],re.DOTALL)
						title = l11lll_l1_ (u"ࠧࠡࠩ䰄").join(title)
						title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ䰅"))
						title = title.replace(l11lll_l1_ (u"ࠩࠣࠤࠬ䰆"),l11lll_l1_ (u"ࠪࠤࠬ䰇")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ䰈"),l11lll_l1_ (u"ࠬࠦࠧ䰉")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ䰊"),l11lll_l1_ (u"ࠧࠡࠩ䰋")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ䰌"),l11lll_l1_ (u"ࠩࠣࠫ䰍")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭䰎"),l11lll_l1_ (u"ࠫࠥ࠭䰏"))
						l11llll1l1l1_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬ࠿࠭䰐"), l11llll1l1l1_l1_)
					if l1l_l1_ == -1 : return
					title = l11llll1l1l1_l1_[l1l_l1_]
					block = l1l1ll1_l1_[l1l_l1_]
				link = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠪࠤࠪ䰑"),block,re.DOTALL)
				l11lllll1111_l1_ = link[0]
				l1111_l1_.append(l11lllll1111_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡇࡱࡵࡹࡲ࠭䰒"))
				block = block.replace(l11lll_l1_ (u"ࠨโࠪ䰓"),l11lll_l1_ (u"ࠩࠪ䰔"))
				block = block.replace(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠸࠵࠼࠺࠱࠳࠳࠺࠹࠷࠿࠶࠯ࡲࡱ࡫ࠧ࠭䰕"),l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䰖"))
				block = block.replace(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ䰗"),l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ䰘"))
				block = block.replace(l11lll_l1_ (u"ࠧิ์ิๅึอสࠡษ็ฮา๋๊ๅࠩ䰙"),l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ䰚"))
				block = block.replace(l11lll_l1_ (u"ࠩิ์ฬฮืࠡษ็ฮา๋๊ๅࠩ䰛"),l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ䰜"))
				block = block.replace(l11lll_l1_ (u"ุࠫ๐ัโำสฮࠥอไๆึส๋ิ࠭䰝"),l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ䰞"))
				block = block.replace(l11lll_l1_ (u"࠭ั้ษห฻ࠥอไๆึส๋ิ࠭䰟"),l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䰠"))
				l11llll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲ࡠࡩ࠱ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ䰡"),block,re.DOTALL)
				for l11lllll111l_l1_ in l11llll1ll1l_l1_:
					#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䰢"),l11lll_l1_ (u"ࠪࠫ䰣"),l11lll_l1_ (u"ࠫࠬ䰤"),str(l11lllll111l_l1_))
					type = re.findall(l11lll_l1_ (u"ࠬࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠪ䰥"),l11lllll111l_l1_)
					if type:
						if type[0]!=l11lll_l1_ (u"࠭ࡢࡰࡶ࡫ࠫ䰦"): type = l11lll_l1_ (u"ࠧࡠࡡࠪ䰧")+type[0]
						else: type = l11lll_l1_ (u"ࠨࠩ䰨")
					items = re.findall(l11lll_l1_ (u"ࠩࠫࡃࡁࠧࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠭࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽࠱ࡩࡳࡳࡺ࠾࠯ࠬࡂࢀࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰࠼ࡣࡴࠣ࠳ࡃ࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࠬ䰩"),l11lllll111l_l1_,re.DOTALL)
					for l11llll1lll1_l1_,link in items:
						title = re.findall(l11lll_l1_ (u"ࠪࠬࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰ࠩ࠽ࠩ䰪"),l11llll1lll1_l1_)
						title = title[-1]
						link = link + l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䰫") + title + type
						l1111_l1_.append(link)
	# l11llllll1ll_l1_
	l11l1l1_l1_ = l11l11l_l1_.replace(l11ll1_l1_,l11lllll11_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠬ࠭䰬"),headers,l11lll_l1_ (u"࠭ࠧ䰭"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䰮"))
	items = re.findall(l11lll_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰯"),html,re.DOTALL)
	#l11lll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡪࡳࡢࡦࡦࡐ࠱࠭ࡢࡷࠬࠫ࠰࠲࠯ࡅ࠮ࡩࡶࡰࡰ࠮࠭䰰"),html,re.DOTALL)
	#if l11lll11ll_l1_:
	if items:
		#l11llllll1ll_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴࠭䰱") + l11lll11ll_l1_[-1] + l11lll_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ䰲")
		l11llllll1ll_l1_ = items[-1]
		l1111_l1_.append(l11llllll1ll_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ䰳"))
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䰴"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ䰵"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ䰶"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ䰷"),l11lll_l1_ (u"ࠪ࠯ࠬ䰸"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ䰹"),headers,l11lll_l1_ (u"ࠬ࠭䰺"),l11lll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䰻"))
	items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ䰼"),html,re.DOTALL)
	l11l11l11_l1_ = [ l11lll_l1_ (u"ࠨࠩ䰽") ]
	l111lll11_l1_ = [ l11lll_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ䰾") ]
	for category,title in items:
		l11l11l11_l1_.append(category)
		l111lll11_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ䰿"), l111lll11_l1_)
		if l1l_l1_ == -1 : return
		category = l11l11l11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"ࠫࠬ䱀")
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䱁")+search+l11lll_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭䱂")+category
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䱃"),l11lll_l1_ (u"ࠨࠩ䱄"),url,url)
	l1111l_l1_(url)
	return
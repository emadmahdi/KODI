# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ㛛")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡐࡗࡠ࡟ࠨ㛜")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ㛝"),l11lll_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ㛞"),l11lll_l1_ (u"ࠬอไศไึห๊࠭㛟"),l11lll_l1_ (u"ู࠭าุࠣห้๋า๋ัࠪ㛠")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l1111l_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l11111_l1_(url,text)
	elif mode==704: results = l1l11l_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡼ࡬࡯ࡦ࠴࠹ࠨ㛡")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㛢"),l1ll1l1_l1_,l11lll_l1_ (u"ࠩࠪ㛣"),l11lll_l1_ (u"ࠪࠫ㛤"),l11lll_l1_ (u"ࠫࠬ㛥"),l11lll_l1_ (u"ࠬ࠭㛦"),l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㛧"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㛨"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㛩"),l11lll_l1_ (u"ࠩࠪ㛪"),709,l11lll_l1_ (u"ࠪࠫ㛫"),l11lll_l1_ (u"ࠫࠬ㛬"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㛭"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㛮"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㛯"),l11lll_l1_ (u"ࠨࠩ㛰"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㛱"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㛲")+l111ll_l1_+l11lll_l1_ (u"๊๋๊ࠫำࠩ㛳"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠬ࠭㛴"),l11lll_l1_ (u"࠭ࠧ㛵"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㛶"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㛷"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㛸")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ㛹"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠫࠬ㛺"),l11lll_l1_ (u"ࠬ࠭㛻"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㛼"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㛽"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㛾")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ㛿"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠪࠫ㜀"),l11lll_l1_ (u"ࠫࠬ㜁"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㜂"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㜃"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㜄")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ㜅"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠩࠪ㜆"),l11lll_l1_ (u"ࠪࠫ㜇"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㜈"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㜉"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㜊"),l11lll_l1_ (u"ࠧࠨ㜋"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡰ࠱ࡹࡵࡰ࠮ࡰࡤࡺࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠪ㜌"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ㜍"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠪࡀࡧࡄࠧ㜎"),l11lll_l1_ (u"ࠫࠬ㜏")).strip(l11lll_l1_ (u"ࠬࠦࠧ㜐"))
		if title in l1l1l1_l1_: continue
		if link.endswith(l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠬ㜑")): continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㜒"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㜓")+l111ll_l1_+title,link,704)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㜔"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜕"),l11lll_l1_ (u"ࠫࠬ㜖"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ㜗"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ㜘"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠧࠨ㜙"))
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㜚"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	title = title.replace(l11lll_l1_ (u"ࠩ࠿ࡦࡃ࠭㜛"),l11lll_l1_ (u"ࠪࠫ㜜")).strip(l11lll_l1_ (u"ࠫࠥ࠭㜝"))
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㜞"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㜟")+l111ll_l1_+title,link,704)
	return
def l1l11l_l1_(url):
	l1ll1ll1l_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㜠"),url,l11lll_l1_ (u"ࠨࠩ㜡"),l11lll_l1_ (u"ࠩࠪ㜢"),l11lll_l1_ (u"ࠪࠫ㜣"),l11lll_l1_ (u"ࠫࠬ㜤"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㜥"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡲࡰ࡮ࡨࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㜦"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ㜧"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ㜨"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㜩"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫ㜪"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㜫"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜬"),l11lll_l1_ (u"࠭ࠧ㜭"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㜮"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫ㜯")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㜰"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㜱"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㜲"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㜳"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㜴"),l11lll_l1_ (u"ࠧࠨ㜵"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㜶"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡹ࡬࡯ࡰࡶࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㜷"),html,re.DOTALL)
	if l1llll1l1l_l1_:
		block = l1llll1l1l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㜸"),block,re.DOTALL)
		if 1:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㜹"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㜺"),l11lll_l1_ (u"࠭ࠧ㜻"),9999)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ㜼"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㜽"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	if not l1ll1ll1l_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪ㜾")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㜿"),l11lll_l1_ (u"ࠫࠬ㝀"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ㝁"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨ㝂"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭㝃")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㝄"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ㝅")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㝆"),url,data,headers,l11lll_l1_ (u"ࠫࠬ㝇"),l11lll_l1_ (u"ࠬ࠭㝈"),l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ㝉"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㝊"),url,l11lll_l1_ (u"ࠨࠩ㝋"),l11lll_l1_ (u"ࠩࠪ㝌"),l11lll_l1_ (u"ࠪࠫ㝍"),l11lll_l1_ (u"ࠫࠬ㝎"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ㝏"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧ㝐"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ㝑"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭㝒"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㝓"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ㝔"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㝕"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㝖"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㝗"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㝘"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ㝙"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㝚"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㝛"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡨࡡࠡ࡯ࡪࡦࠥࡺࡡࡣ࡮ࡨࠤ࡫ࡻ࡬࡭ࠤࠫ࠲࠯ࡅࠩࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫ㝜"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㝝"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ㝞"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㝟"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㝠"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ㝡"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ㝢"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ㝣"),l11lll_l1_ (u"้ࠬไ๋สࠪ㝤"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ㝥"),l11lll_l1_ (u"่ࠧัสๅࠬ㝦"),l11lll_l1_ (u"ࠨ็หหึอษࠨ㝧"),l11lll_l1_ (u"ࠩ฼ี฻࠭㝨"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ㝩"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ㝪"),l11lll_l1_ (u"๋ࠬำาฯํอࠬ㝫")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨ㝬"))
		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ㝭") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㝮")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㝯"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㝰") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭㝱")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧ㝲"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㝳"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ㝴"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㝵"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㝶"):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㝷"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㝸") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㝹"),l111ll_l1_+title,link,703,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ㝺") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㝻"),l111ll_l1_+title,link,701,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㝼"),l111ll_l1_+title,link,703,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㝽"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㝾")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㝿"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㞀"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ㞁"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㞂")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ㞃"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㞄"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ㞅")+title,link,701)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㞆"),l11lll_l1_ (u"ࠬ࠭㞇"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㞈"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㞉"),url,l11lll_l1_ (u"ࠨࠩ㞊"),l11lll_l1_ (u"ࠩࠪ㞋"),l11lll_l1_ (u"ࠪࠫ㞌"),l11lll_l1_ (u"ࠫࠬ㞍"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㞎"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ㞏"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㞐"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩ㞑")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ㞒"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭㞓"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠫࠨ࠭㞔"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㞕"),l111ll_l1_+title,url,703,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ㞖"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭㞗"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㞘"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ㞙")+l1ll1_l1_+l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㞚"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ㞛")+l1ll1_l1_+l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㞜"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪ㞝")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㞞"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢ㞟"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㞠"),l11lll_l1_ (u"ࠪࠫ㞡"),l11lll_l1_ (u"ࠫࠬ㞢"),l11lll_l1_ (u"ࠬ࠸࠲࠳࠴࠵ࠫ㞣"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㞤"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㞥"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"ࠨ࠰࠲ࠫ㞦"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㞧")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㞨"))
			title = title.replace(l11lll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ㞩"),l11lll_l1_ (u"ࠬࠦࠧ㞪"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㞫"),l111ll_l1_+title,link,702,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ㞬"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㞭") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㞮")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㞯"))
		#		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㞰"),l111ll_l1_+title,link,702,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㞱"),l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ㞲"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㞳"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㞴"),l11lll_l1_ (u"ࠩࠪ㞵"),l11lll_l1_ (u"ࠪࠫ㞶"),l11lll_l1_ (u"ࠫࠬ㞷"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㞸"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ㞹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ link
		link = re.findall(l11lll_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㞺"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ㞻"))
			l1111_l1_.append(link)
		# l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪ㞼"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ㞽"))
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㞾")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㞿"))
				l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡕࡨࡶࡻ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㟀"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㟁"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				title = title.strip(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㟂"))
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㟃")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㟄"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ㟅"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㟆"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ㟇"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ㟈"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ㟉"),l11lll_l1_ (u"ࠩ࠮ࠫ㟊"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ㟋")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ㟌"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ㟍")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ㟎"))
	return
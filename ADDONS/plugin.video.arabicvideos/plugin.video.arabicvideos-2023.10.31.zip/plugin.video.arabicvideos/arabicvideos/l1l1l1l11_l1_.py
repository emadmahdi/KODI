# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭༧")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡅࡗ࡚࡟ࠨ༨")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==730: results = MENU()
	elif mode==731: results = l1111l_l1_(url)
	elif mode==732: results = PLAY(url)
	elif mode==733: results = l1llllll_l1_(url)
	elif mode==734: results = l1l1l11l1_l1_(url)
	elif mode==735: results = l1l1l1111_l1_(url)
	elif mode==739: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༩"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ༪"),l11lll_l1_ (u"ࠬ࠭༫"),739,l11lll_l1_ (u"࠭ࠧ༬"),l11lll_l1_ (u"ࠧࠨ༭"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ༮"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ༯"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ༰"),l11lll_l1_ (u"ࠫࠬ༱"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ༲"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ༳")+l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧ༴"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡷࡳࡵ࠴ࡰࡩࡲ༵ࠪ"),735)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ༶"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ༷ࠬ")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠬ༸"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡣࡢࡴࡷࡳࡴࡴ࠮ࡱࡪࡳ༹ࠫ"),734)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༺"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ༻")+l111ll_l1_+l11lll_l1_ (u"ࠨษไ่ฬ๋ࠧ༼"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠱ࡴ࡭ࡶࠧ༽"),731)
	return
def l1l1l11l1_l1_(url):
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༾"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ใๅࠩ༿"),url,731)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩཀ"),url,l11lll_l1_ (u"࠭ࠧཁ"),l11lll_l1_ (u"ࠧࠨག"),l11lll_l1_ (u"ࠨࠩགྷ"),l11lll_l1_ (u"ࠩࠪང"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓ࠮ࡕࡈࡖࡎࡋࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ཅ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࡀࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬཆ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢཇ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ཈")+link
			title = l11lll_l1_ (u"ࠧฮำไࠤࠬཉ")+title
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨཊ"),l111ll_l1_+title,link,731)
	return
def l1l1l1111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ཋ"),url,l11lll_l1_ (u"ࠪࠫཌ"),l11lll_l1_ (u"ࠫࠬཌྷ"),l11lll_l1_ (u"ࠬ࠭ཎ"),l11lll_l1_ (u"࠭ࠧཏ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡙ࡅࡓࡋࡈࡗࡤࡌࡅࡂࡖࡘࡖࡊࡊ࠭࠳ࡰࡧࠫཐ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬད"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨདྷ"),block,re.DOTALL)
		for title,link,l1llll_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬན")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭པ")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧཕ"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭བ"),l111ll_l1_+title,link,733,l1llll_l1_)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨབྷ"),l11lll_l1_ (u"ࠨࠩམ"),request,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ཙ"),url,l11lll_l1_ (u"ࠪࠫཚ"),l11lll_l1_ (u"ࠫࠬཛ"),l11lll_l1_ (u"ࠬ࠭ཛྷ"),l11lll_l1_ (u"࠭ࠧཝ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩཞ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨ࡯ࡲࡺ࡮࡫ࡳࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣཟ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡳࡻ࡯ࡥࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡁࠫའ"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬཡ")+link
		l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ར")+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧལ"))
		if l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠴ࡰࡩࡲࠪཤ") in url: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ཥ"),l111ll_l1_+title,link,732,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨས"),l111ll_l1_+title,link,733,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪཧ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨཨ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ཀྵ")+link
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧཪ"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ཫ"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ཬ")+title,link,731)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ཭"),l11lll_l1_ (u"ࠩࠪ཮"),l11lll_l1_ (u"ࠪࠫ཯"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ཰"),url,l11lll_l1_ (u"ཱࠬ࠭"),l11lll_l1_ (u"ི࠭ࠧ"),l11lll_l1_ (u"ࠧࠨཱི"),l11lll_l1_ (u"ࠨུࠩ"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹཱུ࠭"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡱࡴࡼࡩࡦࡵࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡳࡤࡴ࡬ࡴࡹࠨྲྀ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨ࠾ࠨཷ"),block,re.DOTALL)
		for title,link,l1llll_l1_,l1l1l111l_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧླྀ")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨཹ")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"ེࠧࠡࠩ"))
			title = title+l11lll_l1_ (u"ࠨཻࠢࠪ")+l1l1l111l_l1_.strip(l11lll_l1_ (u"ོࠩࠣࠫ"))
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰཽࠩ"),l111ll_l1_+title,link,732,l1llll_l1_)
	return
def PLAY(url):
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰ࠳ࡳࡧࡵࡴ࡫ࡦࡥࡦ࠳࠳࠴࠲࠶࠹࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲ࡹࡴࡳࡧࡤࡱ࡮ࡴࡧ࠯ࡪࡷࡱࡱ࠭ཾ")
	l1lllll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩཿ"),url,l11lll_l1_ (u"ྀ࠭ࠧ"),l11lll_l1_ (u"ࠧࠨཱྀ"),l11lll_l1_ (u"ࠨࠩྂ"),l11lll_l1_ (u"ࠩࠪྃ"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶ྄ࠪ"))
	html = response.content
	# l1l11llll_l1_ link
	links = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ྅"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧ྆") not in link: link = link+l11lll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩ྇")
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨྈ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ྉ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨྊ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫྋ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬྌ"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧྍ"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪྎ"))
	l1111_l1_ = [l11lll_l1_ (u"ࠧࠨྏ"),l11lll_l1_ (u"ࠨ࡯ࠪྐ")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"่ࠩืู้ไศฬࠪྑ"),l11lll_l1_ (u"ࠪหๆ๊วๆࠩྒ")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪྒྷ"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	type = l1111_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡬ࡪࡸࡨࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨྔ")+type+l11lll_l1_ (u"࠭ࠦࡲ࠿ࠪྕ")+search
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫྖ"),url,l11lll_l1_ (u"ࠨࠩྗ"),l11lll_l1_ (u"ࠩࠪ྘"),l11lll_l1_ (u"ࠪࠫྙ"),l11lll_l1_ (u"ࠫࠬྚ"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧྛ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬྜ"),html,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩྜྷ")+link
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪྞ"))
		if type==l11lll_l1_ (u"ࠩࡰࠫྟ"): addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩྠ"),l111ll_l1_+title,link,732)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྡ"),l111ll_l1_+title,link,733)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ抰")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍࡔ࡟ࠨ抱")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪๆ๋๎วหࠢไฺฬฬ๊สࠩ抲"),l11lll_l1_ (u"ࠫๆอัิๅ๋ࠫ抳"),l11lll_l1_ (u"࡙ࠬࡨࡰࡹࠣࡱࡴࡸࡥࠨ抴")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l1111l_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1llllll_l1_(url,text)
	elif mode==584: results = l1l11l_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ抵"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ抶"),l11lll_l1_ (u"ࠨࠩ抷"),l11lll_l1_ (u"ࠩࠪ抸"),l11lll_l1_ (u"ࠪࠫ抹"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ抺"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ抻"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭押"),l11lll_l1_ (u"ࠧࠨ抽"),589,l11lll_l1_ (u"ࠨࠩ抾"),l11lll_l1_ (u"ࠩࠪ抿"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ拀"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ拁"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ拂"),l11lll_l1_ (u"࠭ࠧ拃"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ拄"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ担"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠩࠪ拆"))
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ拇"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ拈"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ拉")+l111ll_l1_+title,link,584)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ拊"),url,l11lll_l1_ (u"ࠧࠨ拋"),l11lll_l1_ (u"ࠨࠩ拌"),l11lll_l1_ (u"ࠩࠪ拍"),l11lll_l1_ (u"ࠪࠫ拎"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭拏"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ拐"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ拑"),l11lll_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭拒"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ拓"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠩࠪ拔"),block)]
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ拕"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ拖"),l11lll_l1_ (u"ࠬ࠭拗"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ拘"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠪ拙")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ拚"),l111ll_l1_+title,link,581)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭招"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ拜"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ拝"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ拞"),l11lll_l1_ (u"࠭ࠧ拟"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拠"),l111ll_l1_+title,link,581)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠨࠩ拡")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ拢"),l11lll_l1_ (u"ࠪࠫ拣"),request,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ拤"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ拥"),url,l11lll_l1_ (u"࠭ࠧ拦"),l11lll_l1_ (u"ࠧࠨ拧"),l11lll_l1_ (u"ࠨࠩ拨"),l11lll_l1_ (u"ࠩࠪ择"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ拪"))
	html = response.content
	items = []
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ拫"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬ括"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ拭"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ拮"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ拯"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ拰"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ拱"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ拲"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ拳"),l11lll_l1_ (u"࠭ใๅ์หࠫ拴"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭拵"),l11lll_l1_ (u"ࠨ้าหๆ࠭拶"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ拷"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ拸"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ拹"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ拺"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭拻")]
	for l1llll_l1_,link,title in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩ拼"))
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭拽") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ拾")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ拿"))
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ挀") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ持")+l1llll_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨ挂"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ挃"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ挄"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ挅"),l111ll_l1_+title,link,582,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠪห้ำไใหࠪ挆") in title:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ指") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ挈"),l111ll_l1_+title,link,583,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ按") in link:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ挊"),l111ll_l1_+title,link,581,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ挋"),l111ll_l1_+title,link,583,l1llll_l1_)
	if request not in [l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ挌"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ挍")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ挎"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ挏"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ挐"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ挑")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ挒"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挓"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ挔")+title,link,581)
		l11111l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭挕"),html,re.DOTALL)
		if l11111l11_l1_:
			link = l11111l11_l1_[0]
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ挖"),l111ll_l1_+l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭挗"),link,581)
	return
def l1llllll_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ挘"),l11lll_l1_ (u"ࠨࠩ挙"),l1ll1_l1_,url)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ挚"),l11lll_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪ挛")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ挜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ挝"),url,l11lll_l1_ (u"࠭ࠧ挞"),l11lll_l1_ (u"ࠧࠨ挟"),l11lll_l1_ (u"ࠨࠩ挠"),l11lll_l1_ (u"ࠩࠪ挡"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭挢"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡳࡧࡶ࠮ࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭挣"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭挤"),str(l1ll1_l1_))
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ挥"),str(l1l11ll_l1_))
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ挦"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠨࠥࠪ挧"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挨"),l111ll_l1_+title,url,583,l11lll_l1_ (u"ࠪࠫ挩"),l11lll_l1_ (u"ࠫࠬ挪"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ挫")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ挬"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭挭"),block,re.DOTALL)
		if items:
			for link,title in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ挮")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ振"))
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ挰"),l111ll_l1_+title,link,582)
		else:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ挱"),block,re.DOTALL)
			for link,title,l1llll_l1_ in items:
				if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ挲") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ挳")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ挴"))
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ挵"),l111ll_l1_+title,link,582)
	return
def PLAY(url):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭挶"))
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ挷"),url,l11lll_l1_ (u"ࠫࠬ挸"),l11lll_l1_ (u"ࠬ࠭挹"),l11lll_l1_ (u"࠭ࠧ挺"),l11lll_l1_ (u"ࠧࠨ挻"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ挼"))
	html = response.content
	# l1llll1_l1_ l1l11l1_l1_
	link = re.findall(l11lll_l1_ (u"ࠩࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ挽"),html,re.DOTALL)
	link = link[0]
	if link and l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ挾") not in link: link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ挿")+link
	#//www.l1lll1l1l11ll_l1_.l1lll1l1l11l1_l1_/l1lll1l1l1l11_l1_/?l1lll1l1l1l1l_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = link.split(l11lll_l1_ (u"ࠬ࡮ࡡࡴࡪࡀࠫ捀"))[1]
	parts = hash.split(l11lll_l1_ (u"࠭࡟ࡠࠩ捁"))
	l1l11l11ll1l_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11lll_l1_ (u"ࠧ࠾ࠩ捂"))
			if kodi_version>18.99: part = part.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭捃"))
			l1l11l11ll1l_l1_.append(part)
		except: pass
	links = l11lll_l1_ (u"ࠩࡁࠫ捄").join(l1l11l11ll1l_l1_)
	links = links.splitlines()
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ捅"),str(links))
	if l11lll_l1_ (u"ࠫ࡫ࡧࡲࡴࡱ࡯ࠫ捆") not in str(links):
		for link in links:
			title,link = link.split(l11lll_l1_ (u"ࠬࠦ࠽࠿ࠢࠪ捇"))
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ捈")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ捉")
			l1111_l1_.append(link)
		#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭捊"),l1111_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ捋"),url)
	else:
		title,link = links[0].split(l11lll_l1_ (u"ࠪࠤࡂࡄࠠࠨ捌"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ捍"),l11lll_l1_ (u"ࠬ࠭捎"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ捏"),l11lll_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋࠭捐")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ捑")+l11lll_l1_ (u"ࠩํีั๏ࠠศๆ่ัฬ๎ไสࠢ็หา่วࠨ捒")+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ捓")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ捔"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭捕"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ捖"),l11lll_l1_ (u"ࠧࠬࠩ捗"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ捘")+search
	l1111l_l1_(url)
	return
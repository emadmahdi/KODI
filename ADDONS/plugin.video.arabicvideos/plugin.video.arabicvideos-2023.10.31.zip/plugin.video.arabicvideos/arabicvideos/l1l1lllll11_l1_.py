# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪⷱ")
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ⷲ"):l11lll_l1_ (u"ࠪࠫⷳ")}
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡌࡈ࠲ࡡࠪⷴ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://www.faselhd.l1ll1ll1l1l_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/faselhd.l1lll1111l_l1_
# l1llll1ll11_l1_	https://www.l1llll1ll11_l1_.com/faselhd
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1l1llll11l_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬา่ศศีࠤฬ๊ร้ีๆหึ࠭ⷵ"),l11lll_l1_ (u"࠭วๅ็ิหั฿วหࠩⷶ"),l11lll_l1_ (u"ࠧࡸࡹࡨࠫⷷ")]
def MAIN(mode,url,text):
	if   mode==570: results = MENU()
	elif mode==571: results = l1111l_l1_(url,text)
	elif mode==572: results = PLAY(url)
	elif mode==573: results = l1lll1l1l1_l1_(url,text)
	#elif mode==574: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨⷸ")+text)
	#elif mode==575: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ⷹ")+text)
	elif mode==579: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫⷺ"):l1ll1l1_l1_,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨⷻ"):l1l11l11l_l1_(False)}
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧⷼ"),l11lll_l1_ (u"࠭แศื็ࠤส฿ไศ่ํࠫⷽ"),l11lll_l1_ (u"ࠧࡥࡷࡥࡦࡪࡪ࠭࡮ࡱࡹ࡭ࡪࡹࠧⷾ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷿ"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⸀"),l1ll1l1_l1_,579,l11lll_l1_ (u"ࠪࠫ⸁"),l11lll_l1_ (u"ࠫࠬ⸂"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⸃"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸄"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ⸅"),l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ⸆"),574)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸇"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭⸈"),l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ⸉"),575)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⸊"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⸋"),l11lll_l1_ (u"ࠧࠨ⸌"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸍"),l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ⸎"),l1ll1l1_l1_,571,l11lll_l1_ (u"ࠪࠫ⸏"),l11lll_l1_ (u"ࠫࠬ⸐"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠱ࠨ⸑"))
	items = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨ࠴ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⸒"),html,re.DOTALL)
	if not items:
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⸓"),l11lll_l1_ (u"ࠨࠩ⸔"),l11lll_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอฬࠡัํࠤํออะࠩ⸕"),l11lll_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭⸖"))
		return
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸗"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⸘")+l111ll_l1_+title,link,571,l11lll_l1_ (u"࠭ࠧ⸙"),l11lll_l1_ (u"ࠧࠨ⸚"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠳ࠪ⸛"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡱࡪࡴࡵ࠮ࡲࡵ࡭ࡲࡧࡲࡺࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⸜"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1llll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡱ࡯ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ⸝"),block,re.DOTALL)
		l1l1llll111_l1_ = [l11lll_l1_ (u"ࠫࠬ⸞"),l11lll_l1_ (u"ࠬษแๅษ่࠾ࠥ࠭⸟"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะ࠺ࠡࠩ⸠"),l11lll_l1_ (u"ࠧษำส้ัࡀࠠࠨ⸡"),l11lll_l1_ (u"ࠨฤึ๎ํ๐࠺ࠡࠩ⸢"),l11lll_l1_ (u"ࠩฦ๊๊๐࠺ࠡࠩ⸣")]
		l11l1lllll_l1_ = 0
		for menu in l1llll11l1_l1_:
			if l11l1lllll_l1_>0: addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⸤"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⸥"),l11lll_l1_ (u"ࠬ࠭⸦"),9999)
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⸧"),menu,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠧࠤࠩ⸨"): continue
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⸩") not in link: link = l1ll1l1_l1_+link
				if title==l11lll_l1_ (u"ࠩࠪ⸪"): continue
				if any(value in title.lower() for value in l1l1l1_l1_): continue
				title = l1l1llll111_l1_[l11l1lllll_l1_]+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸫"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⸬")+l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠬ࠭⸭"),l11lll_l1_ (u"࠭ࠧ⸮"),l11lll_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩⸯ"))
			l11l1lllll_l1_ += 1
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠨࠩ⸰")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⸱"),l11lll_l1_ (u"ࠪࠫ⸲"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ⸳"):url,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⸴"):l1l11l11l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⸵"),url,l11lll_l1_ (u"ࠧࠨ⸶"),l11lll_l1_ (u"ࠨࠩ⸷"),l11lll_l1_ (u"ࠩࠪ⸸"),l11lll_l1_ (u"ࠪࠫ⸹"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⸺"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠴ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⸻"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	if type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⸼"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ⸽"),l11lll_l1_ (u"ࠨ࠱ࠪ⸾")).replace(l11lll_l1_ (u"ࠩ࡟ࡠࠧ࠭⸿"),l11lll_l1_ (u"ࠪࠦࠬ⹀"))]
	elif type==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⹁"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡨࡰ࡯ࡨࡗࡱ࡯ࡤࡦࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⹂"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⹃"),block,re.DOTALL)
		l1l1l1lll_l1_,links,l1l111_l1_ = zip(*items)
		items = zip(links,l1l1l1lll_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠴ࠪ⹄"):
		title,block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹅"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠵ࠫ⹆") and len(l1l11ll_l1_)>1:
		title = l1l11ll_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹇"),l111ll_l1_+title,url,571,l11lll_l1_ (u"ࠫࠬ⹈"),l11lll_l1_ (u"ࠬ࠭⹉"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⹊"))
		title = l1l11ll_l1_[1][0]
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹋"),l111ll_l1_+title,url,571,l11lll_l1_ (u"ࠨࠩ⹌"),l11lll_l1_ (u"ࠩࠪ⹍"),l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠷ࠬ⹎"))
		return
	else:
		title,block = l1l11ll_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧ࡮࠱ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⹏"),block,re.DOTALL)
	#l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ⹐"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ⹑"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭⹒"),l11lll_l1_ (u"ࠨๅ็๎อ࠭⹓"),l11lll_l1_ (u"ࠩส฽้อๆࠨ⹔"),l11lll_l1_ (u"๋ࠪิอแࠨ⹕"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ⹖"),l11lll_l1_ (u"ࠬ฿ัืࠩ⹗"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭⹘"),l11lll_l1_ (u"ࠧศๆห์๊࠭⹙"),l11lll_l1_ (u"ࠨ็ึีา๐ษࠨ⹚")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		l1llll_l1_ = escapeUNICODE(l1llll_l1_)
		l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠩࡂࡶࡪࡹࡩࡻࡧࡀࠫ⹛"))[0]
		title = unescapeHTML(title)
		#title = escapeUNICODE(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭⹜"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡵ࠲ࠫ⹝") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹞"),l111ll_l1_+title,link,571,l1llll_l1_)
		#elif any(value in title for value in l1lll1_l1_):
		#	addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⹟"),l111ll_l1_+title,link,572,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"ࠧࠨ⹠"):
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⹡")+l1lll11_l1_[0][0]
			title = title.strip(l11lll_l1_ (u"ࠩࠣ⠗ࠬ⹢"))
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹣"),l111ll_l1_+title,link,573,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ⹤") in link or l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷ࠴࠭⹥") in link or l11lll_l1_ (u"࠭ࡨࡪࡰࡧ࡭࠴࠭⹦") in link:
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⹧"),l111ll_l1_+title,link,572,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹨"),l111ll_l1_+title,link,573,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⹩"):
		l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ⹪"),block,re.DOTALL)
		if l1lll11ll1l_l1_:
			count = l1lll11ll1l_l1_[0]
			link = url+l11lll_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭⹫")+count
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹬"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⹭"),link,571,l11lll_l1_ (u"ࠧࠨ⹮"),l11lll_l1_ (u"ࠨࠩ⹯"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⹰"))
	elif l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶࠫ⹱") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࡨࡲࡡࡴࡵࡀࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ⹲"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⹳"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"࠭ีโฯฬࠤࠬ⹴")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹵"),l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠨࠩ⹶"),l11lll_l1_ (u"ࠩࠪ⹷"),l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠸ࠬ⹸"))
	return
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠫࠬ⹹")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⹺"),url,l11lll_l1_ (u"࠭ࠧ⹻"),l11lll_l1_ (u"ࠧࠨ⹼"),l11lll_l1_ (u"ࠨࠩ⹽"),l11lll_l1_ (u"ࠩࠪ⹾"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࡙ࡅࡂࡕࡒࡒࡘࡥࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⹿"))
	html = response.content
	#link = l11lll_l1_ (u"ࠫࠬ⺀")
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭⺁"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠤࡂࠦ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⺂"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ⺃"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,name,title in items:
					name = unescapeHTML(name)
					if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⺄") not in link: link = l1ll1l1_l1_+link
					title = name+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭⺅")+title
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺆"),l111ll_l1_+title,link,573,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ⺇"),l11lll_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⺈"))
	if type==l11lll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⺉") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡲࡷࡹ࡫ࡲࡊ࡯ࡪࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⺊"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩ⺋")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡩࡵࡇ࡬࡭ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⺌"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⺍"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭⺎"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⺏"),l111ll_l1_+title,link,572,l1llll_l1_)
	#if not link: l1111l_l1_(url)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1llll1ll_l1_,l1l1lllll1l_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⺐"),url,l11lll_l1_ (u"ࠧࠨ⺑"),l11lll_l1_ (u"ࠨࠩ⺒"),l11lll_l1_ (u"ࠩࠪ⺓"),l11lll_l1_ (u"ࠪࠫ⺔"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⺕"))
	html = response.content
	l1l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"๋ࠬำห๊์ࠤฬ๊ๅีษ๊ำฮ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⺖"),html,re.DOTALL)
	if l1l1lll1lll_l1_:
		l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡣࡪࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⺗"),html,re.DOTALL)
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡒࡰࡹࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⺘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⺙"),block,re.DOTALL)
		for link in items:
			link = link.split(l11lll_l1_ (u"ࠩࠩ࡭ࡲ࡭࠽ࠨ⺚"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ⺛"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸࡺࡲࡦࡣࡰࡌࡪࡧࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⺜"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ⺝"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"࠭ࠦࡪ࡯ࡪࡁࠬ⺞"))[0]
			name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ⺟"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⺠")+name+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⺡"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠫ࠲࠯ࡅࠩࡣ࡮ࡤࡧࡰࡽࡩ࡯ࡦࡲࡻࠬ⺢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⺣"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"ࠬࠬࡩ࡮ࡩࡀࠫ⺤"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⺥")+name+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⺦"))
	for l1l1llll1l1_l1_ in l1lllll1_l1_:
		link,name = l1l1llll1l1_l1_.split(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤࠨ⺧"))
		if link not in l1l1llll1ll_l1_:
			l1l1llll1ll_l1_.append(link)
			l1l1lllll1l_l1_.append(l1l1llll1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆ่๊ฬูศࠨ⺨"), l1l1lllll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1lllll1l_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⺩"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ⺪"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭⺫"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ⺬"),l11lll_l1_ (u"ࠧࠬࠩ⺭"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⺮")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ⺯"),l11lll_l1_ (u"ࠪๅฬ฻ไࠡว฼่ฬ์๊ࠨ⺰"),l11lll_l1_ (u"ࠫࡩࡻࡢࡣࡧࡧ࠱ࡲࡵࡶࡪࡧࡶࠫ⺱"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠻ࠧ⺲"))
	return
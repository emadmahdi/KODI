# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1llll1l_l1_ import *
script_name = l11lll_l1_ (u"ࠨࡋࡑࡍ࡙࠭燝")
LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ燞"),l11lll_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠨ營"))
l1l1l1ll111_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
l1l1ll1l111l_l1_ = int(mode)
l1ll11l1ll1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ燠"))
l1ll11l1ll1l_l1_ = l1ll11l1ll1l_l1_.replace(ltr,l11lll_l1_ (u"ࠬ࠭燡")).replace(rtl,l11lll_l1_ (u"࠭ࠧ燢"))
if l1l1ll1l111l_l1_==260: message = l11lll_l1_ (u"࡚ࠧࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࡡࠠࠨ燣")+l11ll111l11_l1_+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡋࡰࡦ࡬࠾ࠥࡡࠠࠨ燤")+l11lll11lll_l1_+l11lll_l1_ (u"ࠩࠣࡡࠬ燥")
else:
	l1ll1lll1llll_l1_ = l111l_l1_(addon_path).replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭燦"),l11lll_l1_ (u"ࠫࠬ燧")).replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ燨"),l11lll_l1_ (u"࠭ࠧ燩"))
	l1ll1lll1llll_l1_ = l1ll1lll1llll_l1_.replace(l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ燪"),l11lll_l1_ (u"ࠨࠩ燫")).strip(l11lll_l1_ (u"ࠩࠣࠫ燬"))
	l1ll1lll1llll_l1_ = l1ll1lll1llll_l1_.replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ燭"),l11lll_l1_ (u"ࠫࠥ࠭燮")).replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠩ燯"),l11lll_l1_ (u"࠭ࠠࠨ燰")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ燱"),l11lll_l1_ (u"ࠨࠢࠪ燲"))
	message = l11lll_l1_ (u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨ燳")+l1ll11l1ll1l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪ燴")+mode+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ燵")+l1ll1lll1llll_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ燶")
LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭燷"),LOGGING(script_name)+message)
l1l1l1llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ燸"))
l1llll1l11l1_l1_ = True if l1l1l1llll1l_l1_==l11ll111l11_l1_ else False
if not l1llll1l11l1_l1_ and l1l1ll1l111l_l1_ in [235,715]:
	l11lll111l11_l1_ = str(l1ll111l111_l1_[l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ燹")])
	script_name = l11lll_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ燺") if l1l1ll1l111l_l1_==235 else l11lll_l1_ (u"ࠪࡱ࠸ࡻࠧ燻")
	l111lll1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࠨ燼")+script_name+l11lll_l1_ (u"ࠬ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ燽")+l11lll111l11_l1_)
	l11l111ll1_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࠪ燾")+script_name+l11lll_l1_ (u"ࠧ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪ燿")+l11lll111l11_l1_)
	if l111lll1l1_l1_ or l11l111ll1_l1_:
		url += l11lll_l1_ (u"ࠨࡾࠪ爀")
		if l111lll1l1_l1_: url += l11lll_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ爁")+l111lll1l1_l1_
		if l11l111ll1_l1_: url += l11lll_l1_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭爂")+l11l111ll1_l1_
		url = url.replace(l11lll_l1_ (u"ࠫࢁࠬࠧ爃"),l11lll_l1_ (u"ࠬࢂࠧ爄"))
	l1111l11ll_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࠪ爅")+script_name+l11lll_l1_ (u"ࠧ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ爆")+l11lll111l11_l1_)
	if l1111l11ll_l1_:
		l1ll1llll1111_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫ爇"),url,re.DOTALL)
		url = url.replace(l1ll1llll1111_l1_[0],l1111l11ll_l1_)
	script_name = script_name.upper()
	l11llll1ll1_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1llll1111l1_l1_ = l11lll_l1_ (u"ࠩࠪ爈")
	l1ll11l11_l1_(l11lll_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ爉"))
	try: l1lll11l11l1_l1_(l1l1l1ll111_l1_,l1ll11l1ll1l_l1_)
	except Exception as error: l1llll1111l1_l1_ = traceback.format_exc()
	l1ll11l11_l1_(l11lll_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ爊"))
	l1l1lll11l1l_l1_(l1llll1111l1_l1_)
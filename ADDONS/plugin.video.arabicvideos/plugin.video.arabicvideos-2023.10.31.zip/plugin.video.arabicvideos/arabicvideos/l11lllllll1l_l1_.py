# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
DIALOG_NOTIFICATION(l11lll_l1_ (u"࡚ࠬࡅࡔࡖࠪ暏"),l11lll_l1_ (u"࠭ࡔࡆࡕࡗࠫ暐"))
l1l1111ll1l1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡹ࠸࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡵࡪ࡬ࡲࡰࡨࡲࡰࡣࡧࡦࡦࡴࡤ࠯ࡥࡲࡱ࠴࠷࠰ࡎࡄ࠱ࡾ࡮ࡶࠧ暑")
l1l1111ll1l1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡩࡪࡪࡴࡦࡵࡷ࠲࡫ࡺࡰ࠯ࡱࡷࡩࡳ࡫ࡴ࠯ࡩࡵ࠳࡫࡯࡬ࡦࡵ࠲ࡸࡪࡹࡴ࠲࠲࠳࡯࠳ࡪࡢࠨ暒")
DOWNLOAD_USING_PROGRESSBAR(l1l1111ll1l1_l1_,{},True)
#l1lll11l1l11_l1_()
#l1l1lll11l1l_l1_()
#url = l11lll_l1_ (u"ࠩࡆ࠾ࡡࡢࡐࡰࡴࡷࡥࡧࡲࡥࠡࡒࡵࡳ࡬ࡸࡡ࡮ࡵ࡟ࡠࡐࡕࡄࡊࡡࡹ࠵࠽ࡥ࠶࠵ࡤ࡬ࡸࡡࡢࡋࡰࡦ࡬ࡠࡡࡶ࡯ࡳࡶࡤࡦࡱ࡫࡟ࡥࡣࡷࡥࡡࡢࡣࡢࡥ࡫ࡩࡡࡢࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࡠࡡ࡬ࡩ࡭ࡧࡢ࠴࠽࠿࠶ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ暓")
#url = l11lll_l1_ (u"ࠪࡧ࠿ࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ暔")
#url = l11lll_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ暕")
#url = l11lll_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ暖")
url = l11lll_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ใะู࠳ࡳࡰ࠴ࠩ暗")
url = l11lll_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡩ࡭ࡱ࡫࡟࠵࠺࠶࠸ࡤ࡙ࡈࡗࡡี๎ฬืษࡠษ็ีุ๎ไࡠษ็ว฾฾ๅࡠุࠪ࠭ࡤ࠮รษษำีࡤอไฮๆ๋หั๐ࠩ࠯࡯ࡳ࠷ࠬ暘")
#url = url.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭暙"))
#xbmc.Player().play(url)
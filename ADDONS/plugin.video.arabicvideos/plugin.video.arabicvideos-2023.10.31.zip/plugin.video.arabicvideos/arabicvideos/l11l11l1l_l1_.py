# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ᅡ")
headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᅢ") : l11lll_l1_ (u"࠭ࠧᅣ") }
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡃࡕࡐࡤ࠭ᅤ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨ฻ิ์฻ࠦวๅ็ุหึ฿ษࠨᅥ"),l11lll_l1_ (u"ࠩส่่๊ࠧᅦ"),l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬᅧ"),l11lll_l1_ (u"ࠫฬู๊ศสࠪᅨ"),l11lll_l1_ (u"ࠬฮัศ็ฯࠤ่๋ศ๋๊อีࠬᅩ"),l11lll_l1_ (u"࠭ๅ้สส๎้่ࠦࠡฮ๋ห้࠭ᅪ"),l11lll_l1_ (u"ࠧศๆๅื๊ࠦวๅษึ่ฬ๋๊ࠨᅫ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l1111l_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l1llllll_l1_(url)
	elif mode==204: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬᅬ")+text)
	elif mode==205: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩᅭ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅮ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᅯ"),l11lll_l1_ (u"ࠬ࠭ᅰ"),209,l11lll_l1_ (u"࠭ࠧᅱ"),l11lll_l1_ (u"ࠧࠨᅲ"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᅳ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅴ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᅵ"),l11ll1_l1_,205)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅶ"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᅷ"),l11ll1_l1_,204)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᅸ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᅹ"),l11lll_l1_ (u"ࠨࠩᅺ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅻ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᅼ")+l111ll_l1_+l11lll_l1_ (u"๊๋๊ࠫำหࠪᅽ"),l11ll1_l1_+l11lll_l1_ (u"ࠬࡅ࠿ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩᅾ"),201)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅿ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆀ")+l111ll_l1_+l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠๆ็ํึฮ࠭ᆁ"),l11ll1_l1_+l11lll_l1_ (u"ࠩࡂࡃࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᆂ"),201)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆃ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᆄ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬᆅ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡷࡪࡸࡩࡦࡵࠪᆆ"),201)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆇ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᆈ")+l111ll_l1_+l11lll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᆉ"),l11ll1_l1_+l11lll_l1_ (u"ࠪࡃࡄࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᆊ"),201)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᆋ"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭ᆌ"),headers,True,l11lll_l1_ (u"࠭ࠧᆍ"),l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᆎ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡺࡡࡣࡵࠫ࠲࠯ࡅࠩࡎࡣ࡬ࡲࡗࡵࡷࠨᆏ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᆐ"),block,re.DOTALL)
		for filter,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡫ࡳࡲ࡫࠯࡮ࡱࡵࡩࡄ࡬ࡩ࡭ࡶࡨࡶࡂ࠭ᆑ")+filter
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆒ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᆓ")+l111ll_l1_+title,link,201)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᆔ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᆕ"),l11lll_l1_ (u"ࠨࠩᆖ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᆗ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᆘ"),block,re.DOTALL)
	#l111ll1l1_l1_ = [l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ࠭ᆙ"),l11lll_l1_ (u"ࠬอแๅษ่ࠤࠬᆚ"),l11lll_l1_ (u"࠭ศาษ่ะࠬᆛ"),l11lll_l1_ (u"ฺࠧำฺ๋ࠬᆜ"),l11lll_l1_ (u"ࠨๅ็๎ออสࠨᆝ"),l11lll_l1_ (u"ࠩส฾ฬ์้ࠨᆞ")]
	for link,title in items:
		if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᆟ") not in link: link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᆠ"))
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆡ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆢ")+l111ll_l1_+title,link,201)
	return html
def l1111l_l1_(url):
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠨࠦࡦࡰࡴࠣࡔࡔ࡙ࡔࠡࡨ࡬ࡰࡹ࡫ࡲ࠻ࠌࠌ࡭࡫ࠦࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࡷࡵࡰ࠷࠲ࡦࡪ࡮ࡷࡩࡷࡹ࠲ࠡ࠿ࠣࡹࡷࡲ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡀࠩࠬࠎࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࠩ࠯ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠦࡠࡥࡲࡹࡳࡺ࠽࠶࠲ࠪ࠭ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡷࡲ࠲࠭ࡨ࡬ࡰࡹ࡫ࡲࡴ࠴ࠬࠎࠎࠏࡤࡢࡶࡤ࠶ࠥࡃࠠࡼࠩࡩࡳࡷࡳࠧ࠻ࡨ࡬ࡰࡹ࡫ࡲࡴ࠴࠯ࠫࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤ࠾ࠩ࠽ࠫࠬࢃࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵ࠤࡂࠦࡨࡦࡣࡧࡩࡷࡹ࠮ࡤࡱࡳࡽ࠭࠯ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫࡢࠦ࠽ࠡࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࠍࠍࠎ࡮ࡥࡢࡦࡨࡶࡸ࠸࡛ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫࡢࠦ࠽࡛ࠡࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡈ࡙ࡒࡇ࠯ࡗࡓࡐࡋࡎࠨ࡟ࠣࡁࠥ࠭ࡇ࡛࠶ࡒࡨ࠵ࡴࡪࡕࡅࡤࡋࡼࡩࡇࡲ࠶ࡌࡾࡌࡷࡈࡆࡴ࡜࠴ࡺࡠ࡯ࡢࡗ࡛࡞ࡈ࠼ࡈࡦ࡚ࡻࡼࠬࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴ࠴࡞ࠫࡈࡵ࡯࡬࡫ࡨࠫࡢࠦ࠽ࠡࠩࡺࡥࡷࡨ࡬ࡪࡱࡱࡾࡹࡼ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࡧࡼࡎࡵࡪࡩࡊ࠸ࡌࡱࡗ࠶ࡍ࡙ࡐࡍ࡝ࡱࡘࡌࡒ࡬ࡧࡥࡓࡊ࡫ࡹࡘࡱࡨࡌࡠ࠱ࡃ࠴࡜ࡰࡊ࠿ࡐࡔࡋࡶࡍࡳࡠࡨࡣࡊ࡙ࡰࡎࡰ࡯ࡪࡓࡗࡖࡗ࡜ࡘࡎ࠳ࡘ࡮ࡱࡍࡢࡇࡈࡵࡥ࡚ࡌ࡫ࡐࡇࡻࡉࡔ࡛ࡖࡒ࡛ࡘ࠸࠶ࡪ࠱ࡏ࡙ࡨࡌࡨࡽࡥ࡯ࡏࡼ࡚࡜ࡘࡆࡒ࡯࡯࠶࡚࡞ࡉ࠱ࡦ࡮ࡼࡱࡠ࠱ࡃࡰࡤ࠷ࡵ࡞ࡓ࠲ࡄ࡚ࡦ࡙ࡇ࠳ࡔ࡯ࡑ࡮ࡩࡌࡤ࠴࡙ࡆࡍࡸࡏ࡭࠲ࡪ࡜ࡽࡎ࠼ࡉ࡫ࡗࡻ࡞࡙࡭ࡹࡏ࡯ࡐࡽࡔࡍࡅࡺࡏ࡭ࡍ࠵ࡔࡄࡏ࡮࡝࡮࡭ࡲࡎ࠳ࡐ࡮࡞࡙ࡈ࡭ࡏ࡬ࡧࡱ࡞ࢀࡁ࠱ࡐ࡭ࡅࡼࡓࡔࡋ࡭ࡐࡾ࡟ࡰࡏࡅࡋࡽࡒ࡙࡟ࡹࡎࡼ࡮࠴ࡓࡊࡣ࠶ࡏࡗࡆ࡯ࡔࡗࡊࡻࡒࡘࡱࡰࡎ࡫ࡩ࡬ࡪࡖࡃ࠽ࠨࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࡺࡸ࡬࠳࠮ࡧࡥࡹࡧ࠲࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠴࠯ࡘࡷࡻࡥ࠭ࠩࠪ࠰ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠧ࠳࡫࡮ࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠣࠤࠥᆣ")
	if l11lll_l1_ (u"ࠨࡁࡂࠫᆤ") in url: url,type = url.split(l11lll_l1_ (u"ࠩࡂࡃࠬᆥ"))
	else: type = l11lll_l1_ (u"ࠪࠫᆦ")
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᆧ"),l11lll_l1_ (u"ࠬ࠭ᆨ"),url,type)
	#if url==l11ll1_l1_: url = url+l11lll_l1_ (u"࠭࠯ࡢ࡮ࡽࠫᆩ")
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᆪ"),l11lll_l1_ (u"ࠨࠩᆫ"),url,l11lll_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠩᆬ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᆭ"),url,l11lll_l1_ (u"ࠫࠬᆮ"),headers,True,l11lll_l1_ (u"ࠬ࠭ᆯ"),l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᆰ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᆱ"))
	#WRITE_THIS(html)
	if l11lll_l1_ (u"ࠨࡩࡨࡸࡵࡵࡳࡵࡵࠪᆲ") in url: l1l1ll1_l1_ = [html]
	elif type==l11lll_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࠫᆳ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡑࡦࡹࡴࡦࡴࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡢ࡮ࠡࠬ࠿࠳ࡩ࡯ࡶ࠿࡞ࡱࠤ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬᆴ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠫࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᆵ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡤ࠷ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᆶ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡴࡳࡧࡱࡨ࡮ࡴࡧࡠࡵࡨࡶ࡮࡫ࡳࠨᆷ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡔ࡮࡬ࡨࡪࡸ࡟࠳ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ᆸ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨ࠳࠴࠵ࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᆹ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠥࡶࡡࡨࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡷࡥࡧࡹࠢࠨᆺ"),html,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱࡫ࡵ࡯ࡵࡧࡵࠫᆻ"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᆼ"),l11lll_l1_ (u"ࠬ࠭ᆽ"),l11lll_l1_ (u"࠭ࠧᆾ"),str(l1l1ll1_l1_))
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡱࡻ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᆿ"),block,re.DOTALL)
	l11l11ll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨᇀ"),l11lll_l1_ (u"ࠩไ๎้๋ࠧᇁ"),l11lll_l1_ (u"ࠪห฿์๊สࠩᇂ"),l11lll_l1_ (u"่๊๊ࠫษࠩᇃ"),l11lll_l1_ (u"ࠬอูๅษ้ࠫᇄ"),l11lll_l1_ (u"࠭็ะษไࠫᇅ"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧᇆ"),l11lll_l1_ (u"ࠨ฻ิฺࠬᇇ"),l11lll_l1_ (u"่๋ࠩึาว็ࠩᇈ"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩᇉ")]
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᇊ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᇋ"),l11lll_l1_ (u"࠭ࠧᇌ"),9999)
	items = re.findall(l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇍ"),block,re.DOTALL)
	if not items:
		items = re.findall(l11lll_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡊࡶࡨࡱࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᇎ"),block,re.DOTALL)
		links,l1l1l1lll_l1_,l1l111_l1_ = zip(*items)
		items = zip(l1l1l1lll_l1_,links,l1l111_l1_)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		#link = escapeUNICODE(link)
		#link = QUOTE(link)
		if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᇏ") in link: continue
		link = link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᇐ"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᇑ"))
		if l11lll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬᇒ") in link or any(value in title for value in l11l11ll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᇓ"),l111ll_l1_+title,link,202,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᇔ") in link and l11lll_l1_ (u"ࠨษ็ั้่ษࠨᇕ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᇖ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᇗ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᇘ"),l111ll_l1_+title,link,203,l1llll_l1_)
					l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠬ࠵ࡰࡢࡥ࡮࠳ࠬᇙ") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇚ"),l111ll_l1_+title,link+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧᇛ"),201,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇜ"),l111ll_l1_+title,link,203,l1llll_l1_)
	if type in [l11lll_l1_ (u"ࠩࠪᇝ"),l11lll_l1_ (u"ࠪࡱࡦ࡯࡮ࡱࡣࡪࡩࠬᇞ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᇟ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᇠ"),block,re.DOTALL)
			for link,title in items:
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				title = title.replace(l11lll_l1_ (u"࠭วๅืไัฮࠦࠧᇡ"),l11lll_l1_ (u"ࠧࠨᇢ"))
				if l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫᇣ") in url:
					l111ll111_l1_ = link.split(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨᇤ"))[1]
					l11l1111l_l1_ = url.split(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇥ"))[1]
					link = url.replace(l11lll_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᇦ")+l11l1111l_l1_,l11lll_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᇧ")+l111ll111_l1_)
				if title!=l11lll_l1_ (u"࠭ࠧᇨ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇩ"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧᇪ")+title,link,201)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᇫ"),l11lll_l1_ (u"ࠪࠫᇬ"),url,l11lll_l1_ (u"ࠫࠬᇭ"))
	l11l1l11l_l1_,items,l111l11l_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᇮ"),url,l11lll_l1_ (u"࠭ࠧᇯ"),headers,True,l11lll_l1_ (u"ࠧࠨᇰ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᇱ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᇲ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᇳ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11l_l1_ = []
		l111l11_l1_ = l11lll_l1_ (u"ࠫࠬᇴ").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᇵ"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᇶ"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠧ࠰ࠩᇷ"))
		title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᇸ") + link.split(l11lll_l1_ (u"ࠩ࠲ࠫᇹ"))[-1].replace(l11lll_l1_ (u"ࠪ࠱ࠬᇺ"),l11lll_l1_ (u"ࠫࠥ࠭ᇻ"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫᇼ"),link.split(l11lll_l1_ (u"࠭࠯ࠨᇽ"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠧ࠱ࠩᇾ")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11lll_l1_ = str(items).count(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪᇿ"))
	l11l1l11l_l1_ = str(items).count(l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬሀ"))
	if l11l11lll_l1_>1 and l11l1l11l_l1_>0 and l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬሁ") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ሂ") in link:
				#link = QUOTE(link)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬሃ"),l111ll_l1_+title,link,203)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨሄ") not in link:
				#if l11lll_l1_ (u"ࠧࠦࠩህ") not in link: link = QUOTE(link)
				#else: link = QUOTE(l111l_l1_(link))
				#link = l111l_l1_(link)
				title = l111l_l1_(title)
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧሆ"),l111ll_l1_+title,link,202)
	return
def PLAY(url):
	#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩሇ"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡ࠳࠴࠵ࠬለ"))
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭ሉ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ሊ"),l11lll_l1_ (u"࠭ࠧላ"),url,l11lll_l1_ (u"ࠧࡑࡎࡄ࡝࠲࠷ࡳࡵࠩሌ"))
	#url = l111l_l1_(QUOTE(url))
	hostname = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬል"),url,l11lll_l1_ (u"ࠩࠪሎ"),headers,True,True,l11lll_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧሏ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩሐ"))
	id = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሑ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧሒ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩሓ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩሔ"),l11lll_l1_ (u"ࠩࠪሕ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ሖ"),l11lll_l1_ (u"ࠫ๏ืฬ๊ࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨሗ"))
	#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬመ"),l11lll_l1_ (u"࠭ࡅࡎࡃࡇࠤࡘ࡚ࡁࡓࡖࠣࡘࡎࡓࡉࡏࡉࠣ࠵࠶࠷ࠧሙ"))
	if l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨሚ") in html:
		#parts = url.split(l11lll_l1_ (u"ࠨ࠱ࠪማ"))
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨሜ"))
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧም"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬሞ"),headers,True,True,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩሟ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫሠ"))
		l111l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሡ"),l11lll1l_l1_,re.DOTALL)
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩሢ"),l11lll1l_l1_,re.DOTALL)
		l111l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ሣ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࡟ࡲ࠯࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫሤ"),l11lll1l_l1_)
		l111l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬሥ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l11l11111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧሦ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		items = l111l1ll1_l1_+l1l1lll_l1_+l111l1lll_l1_+l111l1l11_l1_+l111l11ll_l1_+l11l11111_l1_
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሧ"),l11lll_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠹࠺࠴ࠨረ"))
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሩ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l11lll_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧሪ") in server: continue
			if l11lll_l1_ (u"ࠪ࠲࡯ࡶࡧࠨራ") in server: continue
			if l11lll_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫሬ") in server: continue
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ር"),title,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11l111l_l1_[0]
				if l11l111l_l1_ in title: title = title.replace(l11l111l_l1_+l11lll_l1_ (u"࠭ࡰࠨሮ"),l11lll_l1_ (u"ࠧࠨሯ")).replace(l11l111l_l1_,l11lll_l1_ (u"ࠨࠩሰ")).strip(l11lll_l1_ (u"ࠩࠣࠫሱ"))
				l11l111l_l1_ = l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨሲ")+l11l111l_l1_
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠫࠬሳ")
			#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬሴ"),l11lll_l1_ (u"࡛࠭ࠨስ")+str(id)+l11lll_l1_ (u"ࠧ࡞ࠢࠣ࡟ࠬሶ")+str(hostname)+l11lll_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ሷ")+str(title)+l11lll_l1_ (u"ࠩࡠࠤࠥࡡࠧሸ")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠪࡡࠬሹ"))
			if server.isdigit():
				link = hostname+l11lll_l1_ (u"ࠫ࠴ࡅࡰࡰࡵࡷ࡭ࡩࡃࠧሺ")+id+l11lll_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩሻ")+server+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧሼ")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨሽ")+l11l111l_l1_
			else:
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ሾ") not in server: server = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨሿ")+server
				l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫቀ"),title,re.DOTALL)
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩቁ")+l11l111l_l1_[0]
				else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭ቂ")
				link = server+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧቃ")+l11l111l_l1_
			l1111_l1_.append(link)
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧቄ"),l11lll_l1_ (u"ࠨ࡝ࠪቅ")+l11l111l_l1_+l11lll_l1_ (u"ࠩࡠࠤࠥࠦࠠ࡜ࠩቆ")+title+l11lll_l1_ (u"ࠪࡡࠬቇ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩቈ"), l1111_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭቉"),l11lll_l1_ (u"࠭ࠧቊ"),l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࠦ࠱ࠨቋ"),	str(len(items)))
	if l11lll_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦࡑࡳࡼ࠭ቌ") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨቍ"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ቎") }
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ቏")
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩቐ"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧቑ"),l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠧࠨቒ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬቓ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧቔ"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫቕ"),l11lll_l1_ (u"ࠫࠬቖ"),l11l11l_l1_,l11lll1l_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭቗"),l11lll1l_l1_,re.DOTALL)
		for block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨቘ"),block,re.DOTALL)
			for link,name,l11l111l_l1_ in items:
				link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ቙")+name+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬቚ")+l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧቛ")+l11l111l_l1_
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧቜ") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨቝ"):l11lll_l1_ (u"ࠬ࠭቞") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ቟"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨበ") }
		l11l11l_l1_ = hostname + l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫቡ")+id
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ቢ"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫባ"),l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨቤ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪብ"))
		if l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤࡷࡲࡸ࠭ቦ") in l11lll1l_l1_:
			l111l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ቧ"),l11lll1l_l1_,re.DOTALL)
			for l11l1l1_l1_ in l111l1lll_l1_:
				if l11lll_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨቨ") not in l11l1l1_l1_ and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧቩ") in l11l1l1_l1_:
					l11l1l1_l1_ = l11l1l1_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧቪ")
					l1111_l1_.append(l11l1l1_l1_)
				elif l11lll_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫቫ") in l11l1l1_l1_:
					l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭ቬ")
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪቭ"),l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨቮ"),headers,True,True,l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬቯ"))
					l111ll1ll_l1_ = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧተ"))
					l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡁࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࠫ࠰࠱࠲࠳࠭ࠨቱ"),l111ll1ll_l1_,re.DOTALL)
					for l11l1l111_l1_ in l111l11_l1_:
						l111lll1l_l1_ = l11lll_l1_ (u"ࠫࠬቲ")
						l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧታ"),l11l1l111_l1_,re.DOTALL)
						for l11l111l1_l1_ in l111l1l11_l1_:
							item = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧቴ"),l11l111l1_l1_,re.DOTALL)
							if item:
								l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬት")+item[0]
								break
						for l11l111l1_l1_ in reversed(l111l1l11_l1_):
							item = re.findall(l11lll_l1_ (u"ࠨ࡞ࡺࡠࡼ࠱ࠧቶ"),l11l111l1_l1_,re.DOTALL)
							if item:
								l111lll1l_l1_ = item[0]
								break
						l111l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨቷ"),l11l1l111_l1_,re.DOTALL)
						for l111lllll_l1_ in l111l11ll_l1_:
							l111lllll_l1_ = l111lllll_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫቸ")+l111lll1l_l1_+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨቹ")+l11l111l_l1_
							l1111_l1_.append(l111lllll_l1_)
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ቺ"),l11lll_l1_ (u"࠭ࠧቻ"),l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠢ࠴ࠫቼ"),	str(len(l1111_l1_))	)
		elif l11lll_l1_ (u"ࠨࡵ࡯ࡳࡼ࠳࡭ࡰࡶ࡬ࡳࡳ࠭ች") in l11lll1l_l1_:
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"ࠩ࠿࡬࠻ࠦࠧቾ"),l11lll_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠤࡂࡃࡓࡕࡃࡕࡘࡂࡃࠧቿ"))+l11lll_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠬኀ")
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"ࠬࡂࡨ࠴ࠢࠪኁ"),l11lll_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠠ࠾࠿ࡖࡘࡆࡘࡔ࠾࠿ࠪኂ"))+l11lll_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠨኃ")
			#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨኄ"),l11lll1l_l1_)
			#open(l11lll_l1_ (u"ࠩࡶ࠾ࡡࡢࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩኅ"),l11lll_l1_ (u"ࠪࡻࠬኆ")).write(l11lll1l_l1_)
			l111l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡂࡃࡓࡕࡃࡕࡘࡂࡃࠨ࠯ࠬࡂ࠭ࡂࡃࡅࡏࡆࡀࡁࠬኇ"),l11lll1l_l1_,re.DOTALL)
			if l111l1l1l_l1_:
				for l11l1l111_l1_ in l111l1l1l_l1_:
					if l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫኈ") not in l11l1l111_l1_: continue
					#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ኉"),l11lll_l1_ (u"ࠧࠨኊ"),l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵࠶࠷ࠧኋ"),	l11l1l111_l1_	)
					l11l111ll_l1_ = l11lll_l1_ (u"ࠩࠪኌ")
					l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩኍ"),l11l1l111_l1_,re.DOTALL)
					for l11l111l1_l1_ in l111l1l11_l1_:
						item = re.findall(l11lll_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ኎"),l11l111l1_l1_,re.DOTALL)
						if item:
							l11l111ll_l1_ = l11lll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ኏")+item[0]
							break
					l111l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬነ"),l11l1l111_l1_,re.DOTALL)
					if l111l1l11_l1_:
						for l111lll1l_l1_,l111llll1_l1_ in l111l1l11_l1_:
							l111llll1_l1_ = l111llll1_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨኑ")+l111lll1l_l1_+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬኒ")+l11l111ll_l1_
							l1111_l1_.append(l111llll1_l1_)
					else:
						l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩና"),l11l1l111_l1_,re.DOTALL)
						for l111llll1_l1_,l111lll1l_l1_ in l111l1l11_l1_:
							l111llll1_l1_ = l111llll1_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬኔ"))+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬን")+l111lll1l_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩኖ")+l11l111ll_l1_
							l1111_l1_.append(l111llll1_l1_)
			else:
				l111l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࡟ࡻ࠰࠯࠼ࠨኗ"),l11lll1l_l1_,re.DOTALL)
				for l111llll1_l1_,l111lll1l_l1_ in l111l1l11_l1_:
					l111llll1_l1_ = l111llll1_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩኘ"))+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩኙ")+l111lll1l_l1_+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ኚ")
					l1111_l1_.append(l111llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨኛ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪኜ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭ኝ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧኞ"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩኟ"),l11lll_l1_ (u"ࠨ࠭ࠪአ"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ኡ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡲࡺࠨኢ"),l11lll_l1_ (u"ࠫࠬኣ"),headers,True,l11lll_l1_ (u"ࠬ࠭ኤ"),l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬእ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬኦ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ኧ"),html,re.DOTALL)
	if l1ll_l1_ and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬከ"),block,re.DOTALL)
		l11l11l11_l1_,l111lll11_l1_ = [],[]
		for category,title in items:
			#if title in [l11lll_l1_ (u"ࠪี๏อึส๋ࠢࠤ๊฻วา฻๊ࠫኩ")]: continue
			l11l11l11_l1_.append(category)
			l111lll11_l1_.append(title)
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫኪ"), l111lll11_l1_)
		if l1l_l1_ == -1 : return
		category = l11l11l11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"ࠬ࠭ካ")
	url = l11ll1_l1_ + l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪኬ")+search+l11lll_l1_ (u"ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫክ")+category+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽࠲ࠩኮ")
	l1111l_l1_(url)
	return
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫኯ"),l11lll_l1_ (u"ࠪࠫኰ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ኱"),l11lll_l1_ (u"ࠬ࠭ኲ"),filter,url)
	# for l111ll11l_l1_ filter:		l1l11lll_l1_ = [l11lll_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩኳ"),l11lll_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ኴ"),l11lll_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨኵ"),l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫ኶")]
	l1l11lll_l1_ = [l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ኷"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪኸ"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫኹ"),l11lll_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧኺ")]
	if l11lll_l1_ (u"ࠧࡀࠩኻ") in url: url = url.split(l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬኼ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ኽ"),1)
	if filter==l11lll_l1_ (u"ࠪࠫኾ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬ኿"),l11lll_l1_ (u"ࠬ࠭ዀ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ዁"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫዂ"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࠪዃ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠩࡀࠫዄ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬዅ")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ዆")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧ዇")+category+l11lll_l1_ (u"࠭࠽࠱ࠩወ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩዉ"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬዊ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫዋ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ዌ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨው")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ዎ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨዏ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨዐ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫዑ"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪዒ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࠧዓ")+l1l11l11_l1_
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዔ"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨዕ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዖ"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ዗")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧዘ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧዙ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪዚ"),l11lll_l1_ (u"ࠫࠬዛ"),9999)
	html = OPENURL_CACHED(l11111l_l1_,url+l11lll_l1_ (u"ࠬ࠵ࡡ࡭ࡼࠪዜ"),l11lll_l1_ (u"࠭ࠧዝ"),headers,l11lll_l1_ (u"ࠧࠨዞ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ዟ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡄ࡮ࡦࡾࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡆࡤࡸࡦ࠮࠮ࠫࡁࠬࡊ࡮ࡲࡴࡦࡴ࡚ࡳࡷࡪࠧዠ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# for l111ll11l_l1_ filter:		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂࡨ࠳ࠩዡ"),block,re.DOTALL)
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡨࡦࡺࡡ࠮ࡨࡲࡶ࡙ࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪዢ"),block,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ዣ"),l11lll_l1_ (u"࠭ࠧዤ"),l11lll_l1_ (u"ࠧࠨዥ"),str(l1lll11l_l1_))
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#name = name.replace(l11lll_l1_ (u"ࠨ࠯࠰ࠫዦ"),l11lll_l1_ (u"ࠩࠪዧ"))
		name = name.replace(l11lll_l1_ (u"ࠪหำะ๊ศำࠣࠫየ"),l11lll_l1_ (u"ࠫࠬዩ"))
		name = name.replace(l11lll_l1_ (u"ูࠬๆสࠢส่ส์สศฮࠪዪ"),l11lll_l1_ (u"࠭วๅี้อࠬያ"))
		items = re.findall(l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨዬ"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠨ࠿ࠪይ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ዮ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪዯ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫደ"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ዱ"),l11l11l_l1_,201)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዲ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨዳ"),l11l11l_l1_,205,l11lll_l1_ (u"ࠨࠩዴ"),l11lll_l1_ (u"ࠩࠪድ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫዶ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ዷ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨዸ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨዹ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪዺ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬዻ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዼ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬዽ")+name,l11l11l_l1_,204,l11lll_l1_ (u"ࠫࠬዾ"),l11lll_l1_ (u"ࠬ࠭ዿ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨጀ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			option = option.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪጁ"),l11lll_l1_ (u"ࠨࠩጂ"))
			if option in l1l1l1_l1_: continue
			#if option==l11lll_l1_ (u"ࠩส่่๊ࠧጃ"): continue
			#option = l11lll_l1_ (u"ࠪ࡟ࠬጄ")+option+l11lll_l1_ (u"ࠫࡢ࠭ጅ")
			#if l11lll_l1_ (u"ࠬอไไๆࠪጆ") in option: DIALOG_OK(l11lll_l1_ (u"࠭ࠧጇ"),l11lll_l1_ (u"ࠧࠨገ"),l11lll_l1_ (u"ࠨࠩጉ"),l11lll_l1_ (u"ࠩ࡞ࠫጊ")+str(option)+l11lll_l1_ (u"ࠪࡡࠬጋ"))
			#if l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪጌ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ግ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨጎ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩጏ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪጐ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ጑")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧጒ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧጓ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧጔ")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩጕ")+name
			if type==l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ጖"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ጗"),l111ll_l1_+title,url,204,l11lll_l1_ (u"ࠩࠪጘ"),l11lll_l1_ (u"ࠪࠫጙ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ጚ"))
			elif type==l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩጛ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨጜ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪጝ"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬጞ")+l1l1111l_l1_
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩጟ"),l111ll_l1_+title,l11l1l1_l1_,201)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጠ"),l111ll_l1_+title,url,205,l11lll_l1_ (u"ࠫࠬጡ"),l11lll_l1_ (u"ࠬ࠭ጢ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧጣ"),l11lll_l1_ (u"ࠧࠨጤ"),filters,l11lll_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠱࠲ࠩጥ"))
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫጦ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ጧ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨጨ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.replace(l11lll_l1_ (u"ࠬࡃࠦࠨጩ"),l11lll_l1_ (u"࠭࠽࠱ࠨࠪጪ"))
	filters = filters.strip(l11lll_l1_ (u"ࠧࠧࠩጫ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠨ࠿ࠪጬ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠩࠩࠫጭ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠪࡁࠬጮ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠫࠬጯ")
	# for l111ll11l_l1_ filter:		l1ll11ll_l1_ = [l11lll_l1_ (u"ࠬࡉࡡࡵࡧࡪࡳࡷࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጰ"),l11lll_l1_ (u"࡙࠭ࡦࡣࡵࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬጱ"),l11lll_l1_ (u"ࠧࡈࡧࡱࡶࡪࡉࡨࡦࡥ࡮ࡆࡴࡾࠧጲ"),l11lll_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪጳ")]
	l1ll11ll_l1_ = [l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫጴ"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩጵ"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪጶ"),l11lll_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ጷ")]
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨጸ")
		if l11lll_l1_ (u"ࠧࠦࠩጹ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪጺ") and value!=l11lll_l1_ (u"ࠩ࠳ࠫጻ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧጼ")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧጽ") and value!=l11lll_l1_ (u"ࠬ࠶ࠧጾ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨጿ")+key+l11lll_l1_ (u"ࠧ࠾ࠩፀ")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬፁ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫፂ")+key+l11lll_l1_ (u"ࠪࡁࠬፃ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨፄ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧፅ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩፆ"),l11lll_l1_ (u"ࠧ࠾ࠩፇ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩፈ"),l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪፉ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫፊ"),l11lll_l1_ (u"ࠫࠬፋ"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ፌ"))
	return l1ll1l1l_l1_
l11lll_l1_ (u"ࠨࠢࠣࠌࡩ࡭ࡱࡺࡥࡳࡵ࠽ࠍ࠶ࡹࡴࠡ࡯ࡨࡸ࡭ࡵࡤࠊࠋࠫࡹࡸ࡫ࡤࠡࡰࡲࡻࠥ࡯࡮ࠡࡹࡨࡦࡸ࡯ࡴࡦࠫࠍࡥࡩࡪࡩ࡯ࡩࠣࡪ࡮ࡲࡴࡦࡴࠣࡸࡴࠦࡳࡦࡣࡵࡧ࡭ࠐࡐࡐࡕࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠦࡠࡥࡲࡹࡳࡺ࠽࠶࠲ࠍࠍࡩࡧࡴࡢ࠼ࠌ࡟ࠬࡉࡡࡵࡧࡪࡳࡷࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨ࠮ࠪ࡝ࡪࡧࡲࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫࡌ࡫࡮ࡳࡧࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫ࠱࠭ࡑࡶࡣ࡯࡭ࡹࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨ࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷ࠿ࠏࡃࡰࡱ࡮࡭ࡪ࡚ࠦࠫࠡࡕࡉࡋ࠳ࡔࡐࡍࡈࡒࠏࠐࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠵ࡲࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡱ࡯ࡨࠥࡳࡥࡵࡪࡲࡨࠥࡨࡵࡵࠢࡶࡸ࡮ࡲ࡬ࠡࡹࡲࡶࡰ࡯࡮ࡨࠫࠌࠍ࠭ࡻࡳࡦࡦࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠮ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡱࡶࡣ࡯࡭ࡹࡿ࠽ࡘࡇࡅ࠱ࡉࡒࠦࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷࡃ࠲࠱࠴࠳ࠎࠏࠐࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠶ࡶࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡱ࡯ࡨࠥࡳࡥࡵࡪࡲࡨࠥࡨࡵࡵࠢࡶࡸ࡮ࡲ࡬ࠡࡹࡲࡶࡰ࡯࡮ࡨࠫࠍࡋࡊ࡚࠺ࠊࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡦࡸࡴ࠰ࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠯࠳࠲࠴࠽ࠏࡍࡅࡕ࠼ࠌ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴ࡡࡳࡶ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳࠹ࡑࠥ࠳࠲ࡅࡰࡺࡘࡡࡺࠌࠥࠦࠧፍ")
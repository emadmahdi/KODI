# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡉࡌࡆࡃࡑࡉࡗ࠭ᳳ")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡄࡎࡑࡣࠬ᳴")
l1l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l11lll_l1_ (u"ࠧࡵࡧࡰࡴࠬᳵ"))
l1l11l1ll1_l1_ = os.path.join(l1ll11llll_l1_,l11lll_l1_ (u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪᳶ"))
l1l1ll1ll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ᳷"),l11lll_l1_ (u"ࠪࡘ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ᳸"))
l1l1l1111l_l1_ = l1ll111lll_l1_
l1l11l1lll_l1_ = l11lll_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ᳹")
l1l11ll111_l1_ = l11lll_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡸࡿࡳࡵࡧࡰ࠳ࡩࡸ࡯ࡱࡤࡲࡼࠬᳺ")
l1l1ll1l1l_l1_ = l11lll_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩ᳻")
l1l1lll11l_l1_ = l11lll_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࡪࡩࡷ࠭᳼")
l1l11ll1ll_l1_ = l11lll_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯࡭ࡱࡪࠫ᳽")
l1l11lll11_l1_ = l11lll_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡣࡱࡶࠬ᳾")
def MAIN(mode):
	if   mode==740: results = l1ll11lll1_l1_()
	elif mode==741: results = l1ll11l1ll_l1_(l1l1lll111_l1_,True,True)
	elif mode==742: results = l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,True)
	elif mode==743: results = l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,True)
	elif mode==744: results = l1l11lllll_l1_(l1l1l1111l_l1_,True)
	elif mode==745: results = l1l11l1l11_l1_(True)
	elif mode==750: results = l1l1l1lll1_l1_()
	elif mode==751: results = l1ll11l1ll_l1_(l1l11l1lll_l1_,False,True)
	elif mode==752: results = l1ll11l1ll_l1_(l1l11ll111_l1_,False,True)
	elif mode==753: results = l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,True)
	elif mode==754: results = l1ll11l1ll_l1_(l1l1lll11l_l1_,False,True)
	elif mode==755: results = l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,True)
	elif mode==756: results = l1ll11l1ll_l1_(l1l11lll11_l1_,False,True)
	elif mode==757: results = l1l1ll1111_l1_(True)
	elif mode==758: results = l1l1l1l1l1_l1_()
	else: results = False
	return results
def l1ll11lll1_l1_():
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l1lll111_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11l1ll1_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1ll1_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l1l11ll1_l1_(l1l1l1111l_l1_)
	l1ll11111l_l1_ -= 36864
	l1l1l111l1_l1_ -= 1
	l1l11ll1l1_l1_ = l11lll_l1_ (u"ࠪࠤ࠭࠭᳿")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨᴀ")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᴁ")
	l1l1l1ll11_l1_ = l11lll_l1_ (u"࠭ࠠࠩࠩᴂ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫᴃ")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᴄ")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"ࠩࠣࠬࠬᴅ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧᴆ")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᴇ")
	l1ll11ll1l_l1_ = l11lll_l1_ (u"ࠬࠦࠨࠨᴈ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11lll_l1_ (u"࠭ࠩࠨᴉ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_
	text = l11lll_l1_ (u"ࠧࠡࠪࠪᴊ")+l1ll11ll11_l1_(size)+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬᴋ")+str(count)+l11lll_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᴌ")
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᴍ"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫอࠡษ็ะ๊๐ูࠨᴎ")+text,l11lll_l1_ (u"ࠬ࠭ᴏ"),745)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᴐ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᴑ"),l11lll_l1_ (u"ࠨࠩᴒ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᴓ"),l111ll_l1_+l11lll_l1_ (u"ุ้ࠪำࠠศๆ่่ๆอสࠡษ็้ษ่สสࠩᴔ")+l1l11ll1l1_l1_,l11lll_l1_ (u"ࠫࠬᴕ"),741)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᴖ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิฯࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮ࠭ᴗ")+l1l1l1ll11_l1_,l11lll_l1_ (u"ࠧࠨᴘ"),742)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᴙ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืาࠦวๅื๋ีࠥอไใัํ้ฮ࠭ᴚ")+l1l1l1l1ll_l1_,l11lll_l1_ (u"ࠪࠫᴛ"),743)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᴜ"),l111ll_l1_+l11lll_l1_ (u"ࠬะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧᴝ")+l1ll11ll1l_l1_,l11lll_l1_ (u"࠭ࠧᴞ"),744)
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᴟ"),l11lll_l1_ (u"ࠨࠩᴠ"))
	return
def l1l1l1lll1_l1_():
	l1ll11l11l_l1_ = True if l11lll_l1_ (u"ࠩ࠲ࠫᴡ") in l1l1l11111_l1_ else False
	if not l1ll11l11l_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫᴢ"),l11lll_l1_ (u"ࠫࠬᴣ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᴤ"),l11lll_l1_ (u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤ๊ะ่โำฬࠤๆ่ืࠡๆฦะ์ุษࠡ์ู๋๊่ࠠ࠯࠰ࠣ์ัํวำๅ่ࠣ๏ูࠠๆ่๊ࠣํ฿๋๊้ࠠ็ุ࠭ᴥ"))
		return
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᴦ"))
	if not l1l11llll1_l1_: l1l1l1l1l1_l1_()
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l11l1lll_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11ll111_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1l1l_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l11ll11l_l1_(l1l1lll11l_l1_)
	l1ll111111_l1_,l1l1l111ll_l1_ = l1l11ll11l_l1_(l1l11ll1ll_l1_)
	l1l1llllll_l1_,l1l1lll1l1_l1_ = l1l11ll11l_l1_(l1l11lll11_l1_)
	l1l11ll1l1_l1_ = l11lll_l1_ (u"ࠨࠢࠫࠫᴧ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭ᴨ")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᴩ")
	l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠫࠥ࠮ࠧᴪ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩᴫ")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᴬ")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"ࠧࠡࠪࠪᴭ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬᴮ")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᴯ")
	l1ll11ll1l_l1_ = l11lll_l1_ (u"ࠪࠤ࠭࠭ᴰ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨᴱ")+str(l1l1l111l1_l1_)+l11lll_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᴲ")
	l1l1l11lll_l1_ = l11lll_l1_ (u"࠭ࠠࠩࠩᴳ")+l1ll11ll11_l1_(l1ll111111_l1_)+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫᴴ")+str(l1l1l111ll_l1_)+l11lll_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᴵ")
	l1l1l1l11l_l1_ = l11lll_l1_ (u"ࠩࠣࠬࠬᴶ")+l1ll11ll11_l1_(l1l1llllll_l1_)+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧᴷ")+str(l1l1lll1l1_l1_)+l11lll_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᴸ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_+l1ll111111_l1_+l1l1llllll_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_+l1l1l111ll_l1_+l1l1lll1l1_l1_
	text = l11lll_l1_ (u"ࠬࠦࠨࠨᴹ")+l1ll11ll11_l1_(size)+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪᴺ")+str(count)+l11lll_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᴻ")
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᴼ"),l111ll_l1_+l11lll_l1_ (u"ࠩศ฽฼อมࠡำัูฮࠦโาษฤอࠥ๎ใหษหอࠬᴽ"),l11lll_l1_ (u"ࠪࠫᴾ"),758)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᴿ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำฮࠢส่ัฺ๋๊ࠩᵀ")+text,l11lll_l1_ (u"࠭ࠧᵁ"),757)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᵂ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᵃ"),l11lll_l1_ (u"ࠩࠪᵄ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᵅ"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠫᵆ")+l1l11ll1l1_l1_,l11lll_l1_ (u"ࠬ࠭ᵇ"),751)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᵈ"),l111ll_l1_+l11lll_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫᵉ")+l1l1l1ll11_l1_,l11lll_l1_ (u"ࠨࠩᵊ"),752)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᵋ"),l111ll_l1_+l11lll_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪᵌ")+l1l1l1l1ll_l1_,l11lll_l1_ (u"ࠫࠬᵍ"),753)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᵎ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩᵏ")+l1ll11ll1l_l1_,l11lll_l1_ (u"ࠧࠨᵐ"),754)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᵑ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡲ࡯ࡨࠩᵒ")+l1l1l11lll_l1_,l11lll_l1_ (u"ࠪࠫᵓ"),755)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᵔ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡣࡱࡶࠬᵕ")+l1l1l1l11l_l1_,l11lll_l1_ (u"࠭ࠧᵖ"),756)
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᵗ"),l11lll_l1_ (u"ࠨࠩᵘ"))
	return
def l1l1l1l1l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪᵙ"),l11lll_l1_ (u"ࠪࠫᵚ"),l11lll_l1_ (u"ࠫࠬᵛ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᵜ"),l11lll_l1_ (u"࠭ไไ์ࠣ๎฾๋ไࠡษ็ฮ๋฾๊โࠢ฼๊ิ้ࠠ࠯࠰ࠣฬึ์วๆฮࠣ฽๊อฯࠡสะหัฯࠠฦๆ์ࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤ้๊ๅๅใสฮࠥ๎วๅ็ฯ่ิอสࠡษ็ฮ๏ࠦำ้ใࠣ๎ู๊อ่ษࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ฽฼อม้ࠡำ๋ࠥอไาะุอࠥอไร่ࠣรࠦ࠭ᵝ"))
	if l1ll111ll1_l1_==-1: return
	if l1ll111ll1_l1_:
		l1ll11l111_l1_ = True
		import subprocess
		try: subprocess.Popen(l11lll_l1_ (u"ࠧࡴࡷࠪᵞ"))
		except: l1ll11l111_l1_ = False
		if l1ll11l111_l1_:
			l1l1ll11l1_l1_ = l1l11l1lll_l1_+l11lll_l1_ (u"ࠨࠢࠪᵟ")+l1l11ll111_l1_+l11lll_l1_ (u"ࠩࠣࠫᵠ")+l1l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤࠬᵡ")+l1l1lll11l_l1_+l11lll_l1_ (u"ࠫࠥ࠭ᵢ")+l1l11ll1ll_l1_+l11lll_l1_ (u"ࠬࠦࠧᵣ")+l1l11lll11_l1_
			proc = subprocess.Popen(l11lll_l1_ (u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧᵤ")+l1l1ll11l1_l1_+l11lll_l1_ (u"ࠧࠣࠩᵥ"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩᵦ"),l11lll_l1_ (u"ࠩࠪᵧ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᵨ"),l11lll_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡว฼฻ฬวࠠศๆิาฺฯࠧᵩ"))
			settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᵪ"),l11lll_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᵫ"))
			xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᵬ"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩᵭ"),l11lll_l1_ (u"ࠩࠪᵮ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᵯ"),l11lll_l1_ (u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠫᵰ"))
	return
def l1ll11ll11_l1_(size):
	for x in [l11lll_l1_ (u"ࠬࡈࠧᵱ"),l11lll_l1_ (u"࠭ࡋࡃࠩᵲ"),l11lll_l1_ (u"ࠧࡎࡄࠪᵳ"),l11lll_l1_ (u"ࠨࡉࡅࠫᵴ"),l11lll_l1_ (u"ࠩࡗࡆࠬᵵ")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11lll_l1_ (u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧᵶ")%(size,x)
	return text
def l1l11ll11l_l1_(l1ll111l1l_l1_=l11lll_l1_ (u"ࠫ࠳࠭ᵷ")):
	global l1l1ll1l11_l1_,l1ll1111ll_l1_
	l1l1ll1l11_l1_,l1ll1111ll_l1_ = 0,0
	def l1l1ll1lll_l1_(l1ll111l1l_l1_):
		global l1l1ll1l11_l1_,l1ll1111ll_l1_
		if os.path.exists(l1ll111l1l_l1_):
			if 0 and l11lll_l1_ (u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ᵸ") in dir(os):
				# using l1l1lll1ll_l1_ l11lll_l1_ (u"࠭࡯ࡴ࠰ࡶࡧࡦࡴࡤࡪࡴࠪᵹ") method (new in version 3.5)
				for l1l11l1l1l_l1_ in os.scandir(l1ll111l1l_l1_):
					if l1l11l1l1l_l1_.l1ll111l11_l1_(follow_symlinks=False):
						l1l1ll1lll_l1_(l1l11l1l1l_l1_.path)
					elif l1l11l1l1l_l1_.l1l1l1l111_l1_(follow_symlinks=False):
						l1l1ll1l11_l1_ += l1l11l1l1l_l1_.stat().st_size
						l1ll1111ll_l1_ += 1
			else:
				# using l1l111l11_l1_, l1l1l1ll1l_l1_ l1l11lll1l_l1_ l11lll_l1_ (u"ࠧࡰࡵ࠱ࡰ࡮ࡹࡴࡥ࡫ࡵࠫᵺ") method
				for l1l11l1l1l_l1_ in os.listdir(l1ll111l1l_l1_):
					l1l11l11ll_l1_ = os.path.abspath(os.path.join(l1ll111l1l_l1_,l1l11l1l1l_l1_))
					if os.path.isdir(l1l11l11ll_l1_):
						l1l1ll1lll_l1_(l1l11l11ll_l1_)
					elif os.path.isfile(l1l11l11ll_l1_):
						size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
						l1l1ll1l11_l1_ += size
						l1ll1111ll_l1_ += count
		return
	try: l1l1ll1lll_l1_(l1ll111l1l_l1_)
	except: pass
	return l1l1ll1l11_l1_,l1ll1111ll_l1_
def l1ll1111l1_l1_(l1l1ll11ll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩᵻ"),l11lll_l1_ (u"ࠩࠪᵼ"),l11lll_l1_ (u"ࠪࠫᵽ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᵾ"),l1l1ll11ll_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪᵿ")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᶀ"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1ll11ll_l1_):
		try: os.remove(l1l1ll11ll_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨᶁ"),l11lll_l1_ (u"ࠨࠩᶂ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶃ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫᶄ"),l11lll_l1_ (u"ࠫࠬᶅ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶆ"),l11lll_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧᶇ"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᶈ"),l11lll_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᶉ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ᶊ"))
	return
def l1l11l1l11_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫᶋ"),l11lll_l1_ (u"ࠫࠬᶌ"),l11lll_l1_ (u"ࠬ࠭ᶍ"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᶎ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠧᶏ")+l11lll_l1_ (u"ࠨ࡞ࡱࠫᶐ")+l11lll_l1_ (u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨᶑ")+l11lll_l1_ (u"ࠪࡠࡳ࠭ᶒ")+l11lll_l1_ (u"ࠫฤࠧࠡࠨᶓ")+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᶔ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l1lll111_l1_,True,False)
	l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,False)
	l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,False)
	l1l11lllll_l1_(l1l1l1111l_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧᶕ"),l11lll_l1_ (u"ࠧࠨᶖ"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᶗ"),l11lll_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᶘ"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᶙ"),l11lll_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᶚ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᶛ"))
	return
def l1l1ll1111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧᶜ"),l11lll_l1_ (u"ࠧࠨᶝ"),l11lll_l1_ (u"ࠨࠩᶞ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶟ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩᶠ")+l11lll_l1_ (u"ࠫࡡࡴࠧᶡ")+l11lll_l1_ (u"ࠬࡻࡳࡢࡩࡨࡷࡹࡧࡴࡴࠢ࠱࠲ࠥࡪࡲࡰࡲࡥࡳࡽࠦ࠮࠯ࠢࡷࡳࡲࡨࡳࡵࡱࡱࡩࡸࠦ࠮࠯ࠢ࡯ࡳ࡬࡭ࡥࡳࠢ࠱࠲ࠥࡲ࡯ࡨࠢ࠱࠲ࠥࡧ࡮ࡳࠩᶢ")+l11lll_l1_ (u"࠭࡜࡯ࠩᶣ")+l11lll_l1_ (u"ࠧࡀࠣࠤࠫᶤ")+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᶥ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l11l1lll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll111_l1_,False,False)
	l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,False)
	l1ll11l1ll_l1_(l1l1lll11l_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11lll11_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪᶦ"),l11lll_l1_ (u"ࠪࠫᶧ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶨ"),l11lll_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᶩ"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᶪ"),l11lll_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᶫ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᶬ"))
	return
def l1l11lllll_l1_(l1l1ll111l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪᶭ"),l11lll_l1_ (u"ࠪࠫᶮ"),l11lll_l1_ (u"ࠫࠬᶯ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶰ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫᶱ")+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᶲ"))
		if l1ll111ll1_l1_!=1: return
	conn = sqlite3.connect(l1l1ll111l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11lll_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡰࡢࡶ࡫࠿ࠬᶳ"))
	cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡴ࡫ࡽࡩࡸࡁࠧᶴ"))
	cc.execute(l11lll_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡶࡨࡼࡹࡻࡲࡦ࠽ࠪᶵ"))
	conn.commit()
	cc.execute(l11lll_l1_ (u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬᶶ"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᶷ"),l11lll_l1_ (u"࠭ࠧᶸ"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶹ"),l11lll_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᶺ"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᶻ"),l11lll_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭ᶼ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨᶽ"))
	return
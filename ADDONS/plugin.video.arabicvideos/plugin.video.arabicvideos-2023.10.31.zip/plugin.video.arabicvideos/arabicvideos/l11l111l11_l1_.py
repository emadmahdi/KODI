# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩῢ")
def MAIN(mode,url):
	if   mode==330: results = l11ll111l1_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l11ll1l_l1_()
	elif mode==333: results = l111llll11_l1_()
	elif mode==334: results = l1ll1111l1_l1_(url)
	else: results = False
	return results
def l1ll1111l1_l1_(l11l1l11l1_l1_):
	try: os.remove(l11l1l11l1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ΰ")))
	except: os.remove(l11l1l11l1_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨῤ"))
	return
def l111llll11_l1_():
	message = l11lll_l1_ (u"ࠪวีํศࠡว็ํࠥืวษูࠣห้็๊ะ์๋ࠤศ๎ࠠศๆุ์ฯࠦแ๋ࠢส่๊๎โฺࠢส่๊฽ไ้สࠣฯ๊ࠦรื฼ฺࠤ฾๊้ࠡิิࠤฬ๊โศศ่อࠥอไ๋็ํ๊ࠥัๅࠡลัฮฬืࠠࠣฬะ้๏๊ࠠๆๆไหฯࠦแ๋ัํ์ࠧࠦหๆࠢสาฯอัࠡัๅอࠥอไึ๊ิอࠥ๎วฯฬสีࠥ์ฺ่่่ࠢๆࠦวๅื๋ีฮ่ࠦษ฻า๋ฬࠦำ้ใࠣ๎อีรࠡษ็ฮา๋๊ๅࠩῥ")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬῦ"),l11lll_l1_ (u"ࠬ࠭ῧ"),l11lll_l1_ (u"࠭ืา์ๅอࠥะอๆ์็ࠤฬ๊ๅๅใสฮࠬῨ"),message)
	return
def l11ll111l1_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬῩ"),l11lll_l1_ (u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭Ὺ"),l11lll_l1_ (u"ࠩࠪΎ"),333)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨῬ"),l11lll_l1_ (u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫ῭"),l11lll_l1_ (u"ࠬ࠭΅"),332)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ`"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ῰"),l11lll_l1_ (u"ࠨࠩ῱"),9999)
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	mtime = os.stat(l11l1ll111_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1l1lll_l1_ = os.listdir(l11l1ll111_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧῲ")))
	else: l11l1l1lll_l1_ = os.listdir(l11l1ll111_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨῳ")))
	for filename in l11l1l1lll_l1_:
		if kodi_version>18.99: filename = filename.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩῴ"))
		if not filename.startswith(l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡢࠫ῵")): continue
		filepath = os.path.join(l11l1ll111_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11l1llll1_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫῶ"))
			except: pass
			filename = filename.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬῷ"))
		filepath = os.path.join(l11l1ll111_l1_,filename)
		addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧῸ"),filename,filepath,331)
	return
def l11l11l1ll_l1_():
	l11l1ll111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬΌ"))
	if l11l1ll111_l1_: return l11l1ll111_l1_
	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭Ὼ"),addoncachefolder)
	return addoncachefolder
def l11l11ll1l_l1_():
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	l11l1111ll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫΏ"),l11lll_l1_ (u"ࠬ࠭ῼ"),l11lll_l1_ (u"࠭ࠧ´"),l11l1ll111_l1_,l11lll_l1_ (u"่ࠧาสࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣฮ฿๐๊าࠢส่๊้ว็ࠢยࠫ῾"))
	if l11l1111ll_l1_==1:
		newpath = l11l11llll_l1_(3,l11lll_l1_ (u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬ῿"),l11lll_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࠨ "),l11lll_l1_ (u"ࠪࠫ "),False,True,l11l1ll111_l1_)
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ "),l11lll_l1_ (u"ࠬ࠭ "),l11lll_l1_ (u"࠭ࠧ "),newpath,l11lll_l1_ (u"่ࠧาสࠤ์๎ࠠศๆ่็ฬ์ࠠศๆฯำ๏ีࠠๅฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ࠡสา่ฬࠦๅ็ࠢส่๊้ว็ࠢส่็ี๊ๆࠢยࠫ "))
		if l1ll111ll1_l1_==1:
			settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫ "),newpath)
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ "),l11lll_l1_ (u"ࠪࠫ "),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ "),l11lll_l1_ (u"ࠬะๅࠡฬ฽๎๏ืࠠๆๅส๊ࠥะฮำ์้ࠤฬ๊ๅๅใสฮࠥอไๆฯ่่ฮ࠭ "))
	#if not l11l1111ll_l1_ or not l1ll111ll1_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ​"),l11lll_l1_ (u"ࠧࠨ‌"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ‍"),l11lll_l1_ (u"ࠩอ้ࠥอไ฻ษฤࠤฬู๊ๆๆํอࠬ‎"))
	return
def l11l11lll1_l1_(filename):
	l11ll1111l_l1_ = l11lll_l1_ (u"ࠪࠫ‏").join(l11l1lllll_l1_ for l11l1lllll_l1_ in filename if l11l1lllll_l1_ not in l11lll_l1_ (u"ࠫࡡ࠵ࠢ࠻ࠬࡂࡀࡃࢂࠧ‐")+half_triangular_colon)
	return l11ll1111l_l1_
def l11l11l1l1_l1_(url,l111lll11l_l1_=l11lll_l1_ (u"ࠬ࠭‑"),l1l1ll11_l1_=l11lll_l1_ (u"࠭ࠧ‒")):
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧ–"),l11lll_l1_ (u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨ—"))
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ―"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ‖")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ‗"))
	if not l111lll11l_l1_: l111lll11l_l1_ = l11l1ll1ll_l1_(url,l1l1ll11_l1_)
	#if not l111lll11l_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭‘"),l11lll_l1_ (u"࠭ࠧ’"),l11lll_l1_ (u"ࠧห่ี๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫ‚"),l11lll_l1_ (u"ࠨษ็้้็ࠠๆ่๊ࠣํ฿ࠠࠨ‛")+l111lll11l_l1_+l11lll_l1_ (u"ࠩࠣ์ฬ๊ศา่ส้ัࠦอศๆํหࠥเ๊าࠢฯห์ุࠠๅฬะ้๏๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅ็็ๅฬะࠧ“"))
	#	LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ”"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡴࡺࡲࡨ࠳ࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡪࡵࠣࡲࡴࡺࠠࡴࡷࡳࡴࡴࡸࡴࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭„")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ‟"))
	#	return False
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	l11l1lll11_l1_ = l11l1l1l1l_l1_()
	filename = l11l1lll11_l1_.replace(l11lll_l1_ (u"࠭ࠠࠨ†"),l11lll_l1_ (u"ࠧࡠࠩ‡"))
	filename = l11l11lll1_l1_(filename)
	#l111lll11l_l1_ = l111lll11l_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭•"))
	filename = l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ‣")+str(int(now))[-4:]+l11lll_l1_ (u"ࠪࡣࠬ․")+filename+l111lll11l_l1_
	l111llll1l_l1_ = os.path.join(l11l1ll111_l1_,filename)
	headers = {}
	headers[l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭‥")] = l11lll_l1_ (u"ࠬ࠭…")
	headers[l11lll_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭‧")] = l11lll_l1_ (u"ࠧࠫ࠱࠭ࠫ ")
	url = url.replace(l11lll_l1_ (u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ "),l11lll_l1_ (u"ࠩࠪ‪"))
	if l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ‫") in url:
		l11l11l_l1_,l111lll1l1_l1_ = url.rsplit(l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ‬"),1)
		l111lll1l1_l1_ = l111lll1l1_l1_.replace(l11lll_l1_ (u"ࠬࢂࠧ‭"),l11lll_l1_ (u"࠭ࠧ‮")).replace(l11lll_l1_ (u"ࠧࠧࠩ "),l11lll_l1_ (u"ࠨࠩ‰"))
	else: l11l11l_l1_,l111lll1l1_l1_ = url,None
	if not l111lll1l1_l1_: l111lll1l1_l1_ = l1l11l11l_l1_()
	if l111lll1l1_l1_: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭‱")] = l111lll1l1_l1_
	if l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ′") in l11l11l_l1_: l11l11l_l1_,l11l111ll1_l1_ = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭″"),1)
	else: l11l11l_l1_,l11l111ll1_l1_ = l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭‴")
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"࠭ࡼࠨ‵")).strip(l11lll_l1_ (u"ࠧࠧࠩ‶")).strip(l11lll_l1_ (u"ࠨࡾࠪ‷")).strip(l11lll_l1_ (u"ࠩࠩࠫ‸"))
	l11l111ll1_l1_ = l11l111ll1_l1_.replace(l11lll_l1_ (u"ࠪࢀࠬ‹"),l11lll_l1_ (u"ࠫࠬ›")).replace(l11lll_l1_ (u"ࠬࠬࠧ※"),l11lll_l1_ (u"࠭ࠧ‼"))
	if l11l111ll1_l1_:	headers[l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ‽")] = l11l111ll1_l1_
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ‾"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ‿")+l11l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭⁀")+str(headers)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ⁁")+l111llll1l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ⁂"))
	l11ll111ll_l1_ = 1024*1024
	l11l1ll1l1_l1_ = 0
	try:
		l11l1ll11l_l1_ =	xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳࡧࡨࡗࡵࡧࡣࡦࠩ⁃"))
		l11l1ll11l_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡝ࡦ࠮ࠫ⁄"),l11l1ll11l_l1_)
		l11l1ll1l1_l1_ = int(l11l1ll11l_l1_[0])
	except: pass
	if not l11l1ll1l1_l1_:
		try:
			l11l1l11ll_l1_ = os.l111lll111_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l1l11ll_l1_.f_frsize*l11l1l11ll_l1_.f_bavail//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		try:
			l11l1l11ll_l1_ = os.l11ll11111_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l1l11ll_l1_.f_frsize*l11l1l11ll_l1_.f_bavail//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		try:
			import shutil
			total,l11l11ll11_l1_,l11l11l11l_l1_ = shutil.l11ll11ll1_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l11l11l_l1_//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ⁅"),l11lll_l1_ (u"่ࠩืฬำษࠡษ็ฮำุ๊็่ࠢะ์๎ไสࠩ⁆"),l11lll_l1_ (u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํัิีࠠๆไาหึࠦๅิษะอࠥอไหะี๎๋ࠦวๅใสี฿ฯࠠโ์ࠣะ์อาไ๋ࠢ฽้๐็ࠡใส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡๆ้ࠤ๏฿ๅๅࠢ฼๊ิ้ࠠฦๆ์ࠤศ์๋ࠠไ๋้๋ࠥศา็ฯ๎ࠥฮั็ษ่ะ้่ࠥะ์ࠣฬา๊่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ่ࠥฯࠡ์ึฬอࠦวๆฬ็หฦࠦฬ่ษี็ࠥฮวๅ็็ๅฬะ้้ࠠำหࠥ็๊่ࠢั฻ํืษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสุ์ึฯࠠึฯํัฮ่ࠦๅ้ำหࠥอไิสหࠤ็อๅࠡษ็้อืๅอ่ࠢศ็ะวࠡส่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧ⁇"),l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ⁈"))
		LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ⁉"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧ⁊"))
		return False
	import requests
	if l111lll11l_l1_==l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭⁋"):
		l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(l11l11l_l1_,headers)
		#DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭⁌"), l1lll1ll_l1_)
		#DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ⁍"), l1111_l1_)
		if len(l1lll1ll_l1_)==0:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧ⁎"),l11lll_l1_ (u"ࠫࠬ⁏"))
			return False
		elif len(l1lll1ll_l1_)==1: l1l_l1_ = 0
		elif len(l1lll1ll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪ⁐"), l1lll1ll_l1_)
			if l1l_l1_ == -1 :
				DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩ⁑"),l11lll_l1_ (u"ࠧࠨ⁒"))
				return False
		l11l11l_l1_ = l1111_l1_[l1l_l1_]
	filesize = 0
	if l111lll11l_l1_==l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ⁓"):
		l111llll1l_l1_ = l111llll1l_l1_.rsplit(l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ⁔"))[0]+l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ⁕")
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⁖"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭⁗"),headers,l11lll_l1_ (u"࠭ࠧ⁘"),l11lll_l1_ (u"ࠧࠨ⁙"),l11lll_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ⁚"))
		l1llll1l1_l1_ = response.content
		links = re.findall(l11lll_l1_ (u"ࠩ࡟ࠧࡊ࡞ࡔࡊࡐࡉ࠾࠳࠰࠿࡜࡞ࡱࡠࡷࡣࠨ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠫ⁛"),l1llll1l1_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢࡲࠨ⁜"),re.DOTALL)
		if not links:
			LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⁝"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⁞")+l11l11l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ "))
			return False
		link = links[0]
		if not link.startswith(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⁠")):
			if link.startswith(l11lll_l1_ (u"ࠨ࠱࠲ࠫ⁡")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠩ࠽ࠫ⁢"),1)[0]+l11lll_l1_ (u"ࠪ࠾ࠬ⁣")+link
			elif link.startswith(l11lll_l1_ (u"ࠫ࠴࠭⁤")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⁥"))+link
			else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"࠭࠯ࠨ⁦"),1)[0]+l11lll_l1_ (u"ࠧ࠰ࠩ⁧")+link
		response = requests.request(l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⁨"),link,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l11l111_l1_ = len(links)
		filesize = chunksize*l11l11l111_l1_
	else:
		chunksize = 1*l11ll111ll_l1_
		response = requests.request(l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⁩"),l11l11l_l1_,headers=headers,verify=False,stream=True)
		if l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ⁪") in response.headers: filesize = int(response.headers[l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬ⁫")])
		l11l11l111_l1_ = int(filesize//chunksize)
	#l11l1lll1l_l1_ = l11l11l111_l1_+1
	l11l1lll1l_l1_ = int(filesize//l11ll111ll_l1_)+1
	if filesize<21000:
		LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ⁬"),LOGGING(script_name)+l11lll_l1_ (u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⁭")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ⁮")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ⁯")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ⁰")+l111llll1l_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭ⁱ"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⁲"),l11lll_l1_ (u"ࠬ࠭⁳"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⁴"),l11lll_l1_ (u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩ⁵"))
		return False
	l11l111l1l_l1_ = 400
	l11l111111_l1_ = l11l1ll1l1_l1_-l11l1lll1l_l1_
	if l11l111111_l1_<l11l111l1l_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭⁶"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⁷")+l11l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ⁸")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ⁹")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢ࠰ࠤࠬ⁺")+str(l11l111l1l_l1_)+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ⁻")+l111llll1l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ⁼"))
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⁽"),l11lll_l1_ (u"ࠩࠪ⁾"),l11lll_l1_ (u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪⁿ"),l11lll_l1_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪ₀")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫ₁")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭₂")+str(l11l111l1l_l1_)+l11lll_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩ₃"))
		return False
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ₄"),l11lll_l1_ (u"ࠩࠪ₅"),l11lll_l1_ (u"ࠪࠫ₆"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬ₇"),l11lll_l1_ (u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ₈")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ₉")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ₊"))
	if l1ll111ll1_l1_!=1:
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ₋"),l11lll_l1_ (u"ࠩࠪ₌"),l11lll_l1_ (u"ࠪࠫ₍"),l11lll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ₎"))
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ₏"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩₐ")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧₑ")+l111llll1l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫₒ"))
		return False
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩₓ"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨₔ"))
	l11l1l1ll1_l1_ = DIALOG_PROGRESS()
	l11l1l1ll1_l1_.create(l111llll1l_l1_,l11lll_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬₕ"))
	l11l111lll_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111llll1l_l1_,l11lll_l1_ (u"ࠬࡽࡢࠨₖ"))
	else: file = open(l111llll1l_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫₗ")),l11lll_l1_ (u"ࠧࡸࡤࠪₘ"))
	if l111lll11l_l1_==l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧₙ"): # l11l11ll11_l1_ for l1llll1l1_l1_ and l11l11111l_l1_ chunks video files such as .l11l1l1l11_l1_
		for l11l1lllll_l1_ in range(1,l11l11l111_l1_+1):
			link = links[l11l1lllll_l1_-1]
			if not link.startswith(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧₚ")):
				if link.startswith(l11lll_l1_ (u"ࠪ࠳࠴࠭ₛ")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠫ࠿࠭ₜ"),1)[0]+l11lll_l1_ (u"ࠬࡀࠧ₝")+link
				elif link.startswith(l11lll_l1_ (u"࠭࠯ࠨ₞")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ₟"))+link
				else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠨ࠱ࠪ₠"),1)[0]+l11lll_l1_ (u"ࠩ࠲ࠫ₡")+link
			response = requests.request(l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ₢"),link,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l111llllll_l1_ = time.time()
			l111lll1ll_l1_ = l111llllll_l1_-t1
			l111lllll1_l1_ = l111lll1ll_l1_//l11l1lllll_l1_
			l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
			l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			PROGRESS_UPDATE(l11l1l1ll1_l1_,int(100*l11l1lllll_l1_//(l11l11l111_l1_+1)),l11lll_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬ₣"),l11lll_l1_ (u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ₤"),str(l11l1lllll_l1_*chunksize//l11ll111ll_l1_)+l11lll_l1_ (u"࠭࠯ࠨ₥")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ₦")+time.strftime(l11lll_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ₧"),time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠩࠣไࠬ₨"))
			if l11l1l1ll1_l1_.iscanceled():
				l11l111lll_l1_ = False
				break
	else: # l1111lll_l1_ and other l11l1l111l_l1_ file l11ll11l1l_l1_
		l11l1lllll_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11l1lllll_l1_ = l11l1lllll_l1_+1
			l111llllll_l1_ = time.time()
			l111lll1ll_l1_ = l111llllll_l1_-t1
			l111lllll1_l1_ = l111lll1ll_l1_/l11l1lllll_l1_
			l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
			l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			PROGRESS_UPDATE(l11l1l1ll1_l1_,int(100*l11l1lllll_l1_/(l11l11l111_l1_+1)),l11lll_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ₩"),l11lll_l1_ (u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ₪"),str(l11l1lllll_l1_*chunksize//l11ll111ll_l1_)+l11lll_l1_ (u"ࠬ࠵ࠧ₫")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ€")+time.strftime(l11lll_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ₭"),time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠨࠢใࠫ₮"))
			if l11l1l1ll1_l1_.iscanceled():
				l11l111lll_l1_ = False
				break
		response.close()
	file.close()
	l11l1l1ll1_l1_.close()
	if not l11l111lll_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ₯"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ₰")+l11l11l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ₱")+l111llll1l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ₲"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ₳"),l11lll_l1_ (u"ࠧࠨ₴"),l11lll_l1_ (u"ࠨࠩ₵"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ₶"))
		return True
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ₷"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ₸")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ₹")+l111llll1l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ₺"))
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ₻"),l11lll_l1_ (u"ࠨࠩ₼"),l11lll_l1_ (u"ࠩࠪ₽"),l11lll_l1_ (u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ₾"))
	return True
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㕸")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡑࡔࡌࡡࠪ㕹")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ㕺"),l11lll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ㕻"),l11lll_l1_ (u"ࠧศๆฦๆุอๅࠨ㕼")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l1111l_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l11111_l1_(url,text)
	elif mode==674: results = l1l11l_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㕽"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㕾"),l11lll_l1_ (u"ࠪࠫ㕿"),l11lll_l1_ (u"ࠫࠬ㖀"),l11lll_l1_ (u"ࠬ࠭㖁"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㖂"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖃"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㖄"),l11lll_l1_ (u"ࠩࠪ㖅"),679,l11lll_l1_ (u"ࠪࠫ㖆"),l11lll_l1_ (u"ࠫࠬ㖇"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㖈"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖉"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㖊"),l11lll_l1_ (u"ࠨࠩ㖋"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖌"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㖍")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ㖎"),l11ll1_l1_,671,l11lll_l1_ (u"ࠬ࠭㖏"),l11lll_l1_ (u"࠭ࠧ㖐"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㖑"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㖒"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㖓")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ㖔"),l11ll1_l1_,671,l11lll_l1_ (u"ࠫࠬ㖕"),l11lll_l1_ (u"ࠬ࠭㖖"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㖗"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖘"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㖙")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ㖚"),l11ll1_l1_,671,l11lll_l1_ (u"ࠪࠫ㖛"),l11lll_l1_ (u"ࠫࠬ㖜"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㖝"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㖞"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㖟")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ㖠"),l11ll1_l1_,671,l11lll_l1_ (u"ࠩࠪ㖡"),l11lll_l1_ (u"ࠪࠫ㖢"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㖣"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㖤"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㖥"),l11lll_l1_ (u"ࠧࠨ㖦"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㖧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㖨"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			if title==l11lll_l1_ (u"ࠪห้ษโิษ่ࠫ㖩"): mode = 675
			else: mode = 674
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㖪"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㖫")+l111ll_l1_+title,link,mode)
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖬"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㖭"),l11lll_l1_ (u"ࠨࠩ㖮"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭㖯"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ㖰"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠫࠬ㖱"))
	#items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㖲"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㖳"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㖴")+l111ll_l1_+title,link,674)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㖵"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㖶"),l11lll_l1_ (u"ࠪࠫ㖷"),9999)
	items = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡧࡸ࡯ࡸࡵࡨ࠲࡭ࡺ࡭࡭ࠩ㖸"))
	for link,l1llll_l1_,title in items:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㖹"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㖺")+l111ll_l1_+title,link,674,l1llll_l1_)
	return
def CATEGORIES(url):
	l1ll1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㖻"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ㖼"),l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭㖽"))
	if l1ll1l1111_l1_: return l1ll1l1111_l1_
	#DIALOG_OK()
	l1ll1l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㖾"),url,l11lll_l1_ (u"ࠫࠬ㖿"),l11lll_l1_ (u"ࠬ࠭㗀"),l11lll_l1_ (u"࠭ࠧ㗁"),l11lll_l1_ (u"ࠧࠨ㗂"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫ㗃"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡺࡥࡨࡱࡵࡽ࠲࡮ࡥࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬ㗄"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1ll1l1111_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㗅"),block,re.DOTALL)
		if l1ll1l1111_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㗆"),l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ㗇"),l1ll1l1111_l1_,l11111l_l1_)
	return l1ll1l1111_l1_
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㗈"),url,l11lll_l1_ (u"ࠧࠨ㗉"),l11lll_l1_ (u"ࠨࠩ㗊"),l11lll_l1_ (u"ࠩࠪ㗋"),l11lll_l1_ (u"ࠪࠫ㗌"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㗍"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㗎"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ㗏"),l11lll_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭㗐"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㗑"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠩࠪ㗒"),block)]
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㗓"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㗔"),l11lll_l1_ (u"ࠬ࠭㗕"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㗖"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠪ㗗")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㗘"),l111ll_l1_+title,link,671)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㗙"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㗚"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㗛"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㗜"),l11lll_l1_ (u"࠭ࠧ㗝"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗞"),l111ll_l1_+title,link,671)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠨࠩ㗟")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㗠"),l11lll_l1_ (u"ࠪࠫ㗡"),request,url)
	if request==l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㗢"):
		url,search = url.split(l11lll_l1_ (u"ࠬࡅࠧ㗣"),1)
		data = l11lll_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ㗤")+search
		headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㗥"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ㗦")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㗧"),url,data,headers,l11lll_l1_ (u"ࠪࠫ㗨"),l11lll_l1_ (u"ࠫࠬ㗩"),l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ㗪"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㗫"),url,l11lll_l1_ (u"ࠧࠨ㗬"),l11lll_l1_ (u"ࠨࠩ㗭"),l11lll_l1_ (u"ࠩࠪ㗮"),l11lll_l1_ (u"ࠪࠫ㗯"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㗰"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠬ࠭㗱"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㗲"))
	if request==l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ㗳"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㗴"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠩࠪ㗵"),link,title))
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㗶"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㗷"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㗸"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㗹"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ㗺"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㗻"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㗼"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ㗽"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㗾"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠬ࠭㗿"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㘀"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㘁"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨ㘂"),l11lll_l1_ (u"ࠩไ๎้๋ࠧ㘃"),l11lll_l1_ (u"ࠪห฿์๊สࠩ㘄"),l11lll_l1_ (u"่๊๊ࠫษࠩ㘅"),l11lll_l1_ (u"ࠬอูๅษ้ࠫ㘆"),l11lll_l1_ (u"࠭็ะษไࠫ㘇"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧ㘈"),l11lll_l1_ (u"ࠨ฻ิฺࠬ㘉"),l11lll_l1_ (u"่๋ࠩึาว็ࠩ㘊"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩ㘋"),l11lll_l1_ (u"ู๊ࠫัฮ์ฬࠫ㘌"),l11lll_l1_ (u"ࠬ็ไๆࠩ㘍")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨ㘎"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ㘏") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㘐")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㘑"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㘒") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭㘓")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧ㘔"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㘕"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ㘖"),title,re.DOTALL)
		#addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㘗"),l111ll_l1_+title,link,672,l1llll_l1_)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㘘"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㘙"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㘚"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㘛") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘜"),l111ll_l1_+title,link,673,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㘝") in link:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘞"),l111ll_l1_+title,link,671,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㘟"),l111ll_l1_+title,link,673,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㘠"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㘡"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠬࠩࠧ㘢"): continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㘣") not in link:
				l11l11l_l1_ = url.rsplit(l11lll_l1_ (u"ࠧ࠰ࠩ㘤"),1)[0]
				link = l11l11l_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㘥")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㘦"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘧"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ㘨")+title,link,671,l11lll_l1_ (u"ࠬ࠭㘩"),l11lll_l1_ (u"࠭ࠧ㘪"),request)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㘫"),l11lll_l1_ (u"ࠨࠩ㘬"),l1ll1_l1_,url)
	addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㘭"),l111ll_l1_+l11lll_l1_ (u"ࠪฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ㘮"),url,672)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㘯"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㘰"),l11lll_l1_ (u"࠭ࠧ㘱"),9999)
	l1ll1l1111_l1_ = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡣࡴࡲࡻࡸ࡫࠮ࡩࡶࡰࡰࠬ㘲"))
	l1l11l11lll_l1_,l1l11l11ll1_l1_,l1l11l1ll1l_l1_ = zip(*l1ll1l1111_l1_)
	l1l11l1l11l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㘳"),url,l11lll_l1_ (u"ࠩࠪ㘴"),l11lll_l1_ (u"ࠪࠫ㘵"),l11lll_l1_ (u"ࠫࠬ㘶"),l11lll_l1_ (u"ࠬ࠭㘷"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ㘸"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠫ㘹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡼࡆࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㘺"),block,re.DOTALL)
		for link,title in links:
			if link not in l1l11l11lll_l1_:
				item = (link,title)
				l1l11l1l11l_l1_.append(item)
		if len(l1l11l1l11l_l1_)==1:
			link,title = l1l11l1l11l_l1_[0]
			l1111l_l1_(link,l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㘻"))
			return
		else:
			for link,title in l1l11l1l11l_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘼"),l111ll_l1_+title,link,671,l11lll_l1_ (u"ࠫࠬ㘽"),l11lll_l1_ (u"ࠬ࠭㘾"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㘿"))
	if not l1l11l1l11l_l1_: l1111l_l1_(url,l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㙀"))
	return
#https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1ll1lll1l_l1_?l1l11l1ll11_l1_=l1l11l1l1ll_l1_
#https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1ll11_l1_=l1l11l1l1ll_l1_
def PLAY(url):
	l1lllll1_l1_ = []
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪ࠲ๅ๏๊ๅ࠮ๅิฮํ์࠭ษษิฬ๏࠳แ๋࠯่฾ฬ๋ัส࠯่ฮ้ษไวห࠰้ิฮ࡟ࡥ࠻࠺࠹ࡨࡨ࠷࠶࠵࠱࡬ࡹࡳ࡬ࠨ㙁")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㙂"),url,l11lll_l1_ (u"ࠪࠫ㙃"),l11lll_l1_ (u"ࠫࠬ㙄"),l11lll_l1_ (u"ࠬ࠭㙅"),l11lll_l1_ (u"࠭ࠧ㙆"),l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㙇"))
	html = response.content
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡧ࡮ࡤࡷ࡭ࡶ࡬ࡢࡻࡨࡶࠬ㙈"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ㙉"),block,re.DOTALL)
		for link,l11l111l_l1_ in links:
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࡣࡤ࠭㙊")+l11l111l_l1_
			l1lllll1_l1_.append(link)
	# l1l11llll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡨࡪࡪ࠭ࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㙋"),html,re.DOTALL)
	if not links: links = re.findall(l11lll_l1_ (u"ࠧ࡬ࡩ࡭ࡧ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ㙌"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㙍") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㙎")+link
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ㙏"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㙐"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㙑"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ㙒"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭㙓"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ㙔"),l11lll_l1_ (u"ࠧࠬࠩ㙕"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ㙖")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ㙗"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ㙘")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㙙"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ寛")
headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ寜") : l11lll_l1_ (u"ࠫࠬ寝") }
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡓࡇ࡙ࡢࠫ寞")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1111l_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llllll_l1_(url)
	elif mode==214: results = l1111111ll11_l1_(url)
	elif mode==215: results = l1111111ll1l_l1_(url)
	elif mode==218: results = l11lllll1lll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11lllll1lll_l1_():
	message = l11lll_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ察")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ寠"),l11lll_l1_ (u"ࠨࠩ寡"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ寢"),l11lll_l1_ (u"ࠪห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠩ寣"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寤"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ寥"),l11lll_l1_ (u"࠭ࠧ實"),219,l11lll_l1_ (u"ࠧࠨ寧"),l11lll_l1_ (u"ࠨࠩ寨"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭審"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寪"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠩ寫"),l11lll_l1_ (u"ࠬ࠭寬"),114,l11ll1_l1_)
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡒ࡬ࡲࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂࡶࡩ࡯ࠨ࡯࡭ࡲ࡯ࡴ࠾࠴࠸ࠫ寭")
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寮"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ寯")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ寰"),url,211)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ寱"),headers,l11lll_l1_ (u"ࠫࠬ寲"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭寳"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡆࡪ࡮ࡷࡩࡷࡹࡂࡶࡶࡷࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ寴"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ寵"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡹࡿࡰࡦ࠿ࡲࡲࡪࠬࡤࡢࡶࡤࡁࠬ寶")+link
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寷"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ寸")+l111ll_l1_+title,url,211)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ对"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ寺"),block,re.DOTALL)
	l1l1l1_l1_ = [l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠศ่่๎ࠬ寻"),l11lll_l1_ (u"ࠧศๆิส๏ู๊สࠩ导")]
	#l111ll1l1_l1_ = [l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢࠪ寽"),l11lll_l1_ (u"ࠩสๅ้อๅࠡࠩ対"),l11lll_l1_ (u"ࠪฬึอๅอࠩ寿"),l11lll_l1_ (u"ࠫ฾ื่ืࠩ尀"),l11lll_l1_ (u"้ࠬไ๋สสฮࠬ封"),l11lll_l1_ (u"࠭ว฻ษ้ํࠬ専")]
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ尃"))
		if not any(value in title for value in l1l1l1_l1_):
		#	if any(value in title for value in l111ll1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ射"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ尅")+l111ll_l1_+title,link,211)
	return html
def l1111l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫ将"),headers,l11lll_l1_ (u"ࠫࠬ將"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ專"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ尉"),l11lll_l1_ (u"ࠧࠨ尊"),url,html)
	if l11lll_l1_ (u"ࠨࡩࡨࡸࡵࡵࡳࡵࡵࠪ尋") in url or l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭尌") in url: block = html
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡑࡪࡪࡩࡢࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ對"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: return
	items = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ導"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l11ll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ小"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ尐"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭少"),l11lll_l1_ (u"ࠨๅ็๎อ࠭尒"),l11lll_l1_ (u"ࠩส฽้อๆࠨ尓"),l11lll_l1_ (u"๋ࠪิอแࠨ尔"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ尕"),l11lll_l1_ (u"ࠬ฿ัืࠩ尖"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭尗"),l11lll_l1_ (u"ࠧศๆห์๊࠭尘")]
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ尙") in link: continue
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ尚"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ尛"))
		if l11lll_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫ尜") in link or any(value in title for value in l11l11ll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ尝"),l111ll_l1_+title,link,212,l1llll_l1_)
		elif l11lll_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ尞") in link and l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ尟") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ尠"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ尡") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ尢"),l111ll_l1_+title,link,213,l1llll_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ尣"),l111ll_l1_+title,link,213,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭尤"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ尥"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠧศๆุๅาฯࠠࠨ尦"),l11lll_l1_ (u"ࠨࠩ尧"))
			if title!=l11lll_l1_ (u"ࠩࠪ尨"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ尩"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ尪")+title,link,211)
	return
def l1llllll_l1_(url):
	l11l1l11l_l1_,items,l111l11l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭尫"),headers,l11lll_l1_ (u"࠭ࠧ尬"),l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ尭"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡶ࡬࠱ࡱ࡯ࡳࡵ࠯ࡱࡹࡲࡨࡥࡳࡧࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ尮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11_l1_ = l11lll_l1_ (u"ࠩࠪ尯").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ尰"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ就"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ尲"))
		title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ尳") + link.split(l11lll_l1_ (u"ࠧ࠰ࠩ尴"))[-1].replace(l11lll_l1_ (u"ࠨ࠯ࠪ尵"),l11lll_l1_ (u"ࠩࠣࠫ尶"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪห้ำไให࠰ࠬࡡࡪࠫࠪࠩ尷"),link.split(l11lll_l1_ (u"ࠫ࠴࠭尸"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ尹")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11lll_l1_ = str(items).count(l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ尺"))
	l11l1l11l_l1_ = str(items).count(l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ尻"))
	if l11l11lll_l1_>1 and l11l1l11l_l1_>0 and l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ尼") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ尽") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ尾"),l111ll_l1_+title,link,213)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭尿") not in link: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ局"),l111ll_l1_+title,link,212)
	return
def PLAY(url):
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"࠭࠯ࠨ屁"))
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠧࠨ层"),headers,l11lll_l1_ (u"ࠨࠩ屃"),l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ屄"))
	# l11ll1l1l_l1_ links
	if l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ居") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ屆"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭屇"),headers,l11lll_l1_ (u"࠭ࠧ屈"),l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ屉"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ届"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡪࡸࡶࡦࡴࡢ࡭ࡲࡧࡧࡦࠤࡁࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭屋"),block,re.DOTALL)
			if items:
				id = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫ屌"),l11lll1l_l1_,re.DOTALL)
				if id:
					l11lll11ll_l1_ = id[0]
					for link,title in items:
						link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡅࡰࡰࡵࡷ࡭ࡩࡃࠧ屍")+l11lll11ll_l1_+l11lll_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ屎")+link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ屏")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ屐")
						l1111_l1_.append(link)
			else:
				# https://l1111111lll1_l1_.tv/l11ll1l1l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩ屑"),block,re.DOTALL)
				for link,dummy in items:
					l1111_l1_.append(link)
	# download links
	if l11lll_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭屒") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ屓"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ屔"),headers,l11lll_l1_ (u"ࠬ࠭展"),l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ屖"))
		id = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡎࡪ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ屗"),l11lll1l_l1_,re.DOTALL)
		if id:
			l11lll11ll_l1_ = id[0]
			l1l1ll1ll_l1_ = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ屘"):l11lll_l1_ (u"ࠩࠪ屙") , l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭屚"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ屛") }
			l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡲࡰࡹࠦࡱࡱࡶࡸࡎࡪ࠽ࠨ屜")+l11lll11ll_l1_
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ屝"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠧࠨ属"),l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ屟"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿࡬࠸࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ屠"),l11lll1l_l1_,re.DOTALL)
			if l1l1ll1_l1_:
				for resolution,block in l1l1ll1_l1_:
					items = re.findall(l11lll_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ屡"),block,re.DOTALL)
					for name,link in items:
						l1111_l1_.append(link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ屢")+name+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ屣")+l11lll_l1_ (u"࠭࡟ࡠࡡࡢࠫ層")+resolution)
			else:
				l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠹ࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ履"),l11lll1l_l1_,re.DOTALL)
				if not l1l1ll1_l1_: l1l1ll1_l1_ = [l11lll1l_l1_]
				for block in l1l1ll1_l1_:
					l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠏࠉࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡴࡧࡵࡺࡪࡸࡳࡕ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࠌࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠐࠉࠊࠋࠌࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࡞࠱࠶ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩส่ิ่ษࠡࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࠉࠊࠋ࡬ࡪࠥࡴࡡ࡮ࡧࠤࡁࠬ࠭࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࠦࠫࠡࠩࠣไࠥ࠭ࠊࠊࠋࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡳࡧ࡭ࡦࠢࡀࠤࠬ࠭ࠊࠊࠋࠌࠍࠎࠨࠢࠣ屦")
					name = l11lll_l1_ (u"ࠩࠪ屧")
					items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭屨"),block,re.DOTALL)
					for link in items:
						server = l11lll_l1_ (u"ࠫࠫࠬࠧ屩") + link.split(l11lll_l1_ (u"ࠬ࠵ࠧ屪"))[2].lower() + l11lll_l1_ (u"࠭ࠦࠧࠩ屫")
						server = server.replace(l11lll_l1_ (u"ࠧ࠯ࡥࡲࡱࠫࠬࠧ屬"),l11lll_l1_ (u"ࠨࠩ屭")).replace(l11lll_l1_ (u"ࠩ࠱ࡧࡴࠬࠦࠨ屮"),l11lll_l1_ (u"ࠪࠫ屯"))
						server = server.replace(l11lll_l1_ (u"ࠫ࠳ࡴࡥࡵࠨࠩࠫ屰"),l11lll_l1_ (u"ࠬ࠭山")).replace(l11lll_l1_ (u"࠭࠮ࡰࡴࡪࠪࠫ࠭屲"),l11lll_l1_ (u"ࠧࠨ屳"))
						server = server.replace(l11lll_l1_ (u"ࠨ࠰࡯࡭ࡻ࡫ࠦࠧࠩ屴"),l11lll_l1_ (u"ࠩࠪ屵")).replace(l11lll_l1_ (u"ࠪ࠲ࡴࡴ࡬ࡪࡰࡨࠪࠫ࠭屶"),l11lll_l1_ (u"ࠫࠬ屷"))
						server = server.replace(l11lll_l1_ (u"ࠬࠬࠦࡩࡦ࠱ࠫ屸"),l11lll_l1_ (u"࠭ࠧ屹")).replace(l11lll_l1_ (u"ࠧࠧࠨࡺࡻࡼ࠴ࠧ屺"),l11lll_l1_ (u"ࠨࠩ屻"))
						server = server.replace(l11lll_l1_ (u"ࠩࠩࠪࠬ屼"),l11lll_l1_ (u"ࠪࠫ屽"))
						link = link + l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ屾") + name + server + l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ屿")
						l1111_l1_.append(link)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ岀"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ岁"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ岂"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ岃"),l11lll_l1_ (u"ࠪ࠯ࠬ岄"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ岅")+search
	l1111l_l1_(url)
	return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡳࡦࡣࡵࡧ࡭ࠦࡳࡦࡥࡲࡲࡩࡧࡲࡺࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡨࡦࡺࡡ࠮ࡥࡤࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡫ࡩࡨࡱ࡭ࡢࡴ࡮࠱ࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚ࠬࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࠉࡧࡱࡵࠤࡨࡧࡴࡦࡩࡲࡶࡾ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡧࡦࡺࡥࡨࡱࡵࡽ࠮ࠐࠉࠊࠋࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไโๆอีࠥอไๆ่สือࡀࠧ࠭ࠢࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙࠯ࠊࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷ࠠ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎࠏࡵࡳ࡮ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ࠭ࡶࡩࡦࡸࡣࡩ࠭ࠪࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧࠬࡥࡤࡸࡪ࡭࡯ࡳࡻࠍࠍࠎ࡚ࡉࡕࡎࡈࡗ࠭ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࠨࠢࠣ岆")
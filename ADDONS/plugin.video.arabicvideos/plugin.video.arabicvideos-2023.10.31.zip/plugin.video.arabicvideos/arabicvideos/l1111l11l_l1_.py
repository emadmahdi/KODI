# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᗑ")
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᗒ"):l11lll_l1_ (u"ࠨࠩᗓ")}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨᗔ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧᗕ"),l11lll_l1_ (u"ࠫฬิั๋ࠩᗖ"),l11lll_l1_ (u"ࠬอฮา๋ࠪᗗ"),l11lll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᗘ"),l11lll_l1_ (u"ࠧษั๋๊ࠥหฮห์สีࠬᗙ"),l11lll_l1_ (u"ࠨษไ่ฬ๋ࠧᗚ"),l11lll_l1_ (u"่ࠩืู้ไศฬࠪᗛ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l1111l_l1_(url,text)
	elif mode==422: results = l1llll1l11_l1_(url)
	elif mode==423: results = l1llllll_l1_(url)
	elif mode==424: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᗜ")+text)
	elif mode==425: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗝ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l111111l1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1lllll111_l1_(l11lll_l1_ (u"ࠬࡍࡅࡕࠩᗞ"),l11ll1_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧᗟ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᗠ"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᗡ"),l11lll_l1_ (u"ࠩࠪᗢ"),l11lll_l1_ (u"ࠪࠫᗣ"),l11lll_l1_ (u"ࠫࠬᗤ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᗥ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᗦ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩᗧ"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᗨ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗩ"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᗪ"),l11lll_l1_ (u"ࠫࠬᗫ"),429,l11lll_l1_ (u"ࠬ࠭ᗬ"),l11lll_l1_ (u"࠭ࠧᗭ"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᗮ"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗯ"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᗰ"),l1ll1l1_l1_,425)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗱ"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᗲ"),l1ll1l1_l1_,424)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᗳ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᗴ"),l11lll_l1_ (u"ࠧࠨᗵ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗶ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗷ")+l111ll_l1_+l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬᗸ"),l1ll1l1_l1_,421)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗹ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᗺ")+l111ll_l1_+l11lll_l1_ (u"࠭รโๆส้ࠥอไ็ฮ๋้ࠬᗻ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳ࠰ࠩᗼ"),421)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗽ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗾ")+l111ll_l1_+l11lll_l1_ (u"๊ࠪ๏ะแๅๅึࠫᗿ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡴࡥࡵࡨ࡯࡭ࡽ࠵ࠧᘀ"),421)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᘁ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᘂ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳࠨᘃ") in link: title = l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠศๆ้ะํ๋ࠧᘄ")
		elif l11lll_l1_ (u"ࠩ࠲ࡲࡪࡺࡦ࡭࡫ࡻࠫᘅ") in link: title = l11lll_l1_ (u"ࠪวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๋๐สโๆๆืࠬᘆ")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘇ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᘈ")+l111ll_l1_+title,link,421)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘉ"),l111ll_l1_+l11lll_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧᘊ"),l1ll1l1_l1_,427)
	return
def l111111l1_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠨࠩᘋ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᘌ"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫᘍ"),l11lll_l1_ (u"ࠫࠬᘎ"),l11lll_l1_ (u"ࠬ࠭ᘏ"),l11lll_l1_ (u"࠭ࠧᘐ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᘑ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡘ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᘒ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᘓ"),block,re.DOTALL)
	for category,id,link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻ࠱ࡲࡵࡶࡪࡧࡶࠫᘔ") in link: title = l11lll_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫᘕ")
		elif l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠲ࡴࡥࡵࡨ࡯࡭ࡽ࠭ᘖ") in link: title = l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᘗ")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘘ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᘙ")+l111ll_l1_+title,link,421,l11lll_l1_ (u"ࠩࠪᘚ"),l11lll_l1_ (u"ࠪࠫᘛ"),category+l11lll_l1_ (u"ࠫࢁ࠭ᘜ")+id)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠬ࠭ᘝ")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧᘞ"),l11lll_l1_ (u"ࠧࠨᘟ"),l1111l111_l1_,url)
	if l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫᘠ") in url: url = url.strip(l11lll_l1_ (u"ࠩ࠲ࠫᘡ"))+l11lll_l1_ (u"ࠪ࠳ࡲࡶࡡࡢ࠱ࡩࡥࡲ࡯࡬ࡺ࠱ࠪᘢ")
	items = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᘣ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᘤ"),url,l11lll_l1_ (u"࠭ࠧᘥ"),headers,l11lll_l1_ (u"ࠧࠨᘦ"),l11lll_l1_ (u"ࠨࠩᘧ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᘨ"))
	html = response.content
	if not l1111l111_l1_ or l11lll_l1_ (u"ࠪࢀࠬᘩ") in l1111l111_l1_:
		#if l11lll_l1_ (u"ࠫࡒࡻ࡬ࡵ࡫ࡉ࡭ࡱࡺࡥࡳࠩᘪ") in html:
		#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘫ"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩᘬ"),url,425)
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘭ"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫᘮ"),url,424)
		#	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᘯ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᘰ"),l11lll_l1_ (u"ࠫࠬᘱ"),9999)
		if l11lll_l1_ (u"ࠬࢂࠧᘲ") not in l1111l111_l1_: l1111111l_l1_ = l11lll_l1_ (u"࠭ࠧᘳ")
		else: l1111111l_l1_ = l11lll_l1_ (u"ࠧ࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠱ࠪᘴ")+l1111l111_l1_
		separator = False
		if l11lll_l1_ (u"ࠨࡒ࡬ࡲࡘࡲࡩࡥࡧࡵࠫᘵ") in html:
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘶ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᘷ"),url,421,l11lll_l1_ (u"ࠫࠬᘸ"),l11lll_l1_ (u"ࠬ࠭ᘹ"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᘺ"))
			separator = True
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸࠬᘻ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l1_l1_ = l1l1ll1_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡤࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᘼ"),l11l1_l1_,re.DOTALL)
			for l1llllllll_l1_,l1lll1lll_l1_ in l1l1lll_l1_:
				l1lllllll1_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡤࡧࡱࡸࡪࡸ࠯ࡢࡥࡷ࡭ࡴࡴ࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࡶࡤࡦ࠴࠭ᘽ")+l1llllllll_l1_+l1111111l_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᘾ")
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘿ"),l111ll_l1_+l1lll1lll_l1_,l1lllllll1_l1_,421)
				separator = True
		if separator: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᙀ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᙁ"),l11lll_l1_ (u"ࠧࠨᙂ"),9999)
	if l1111l111_l1_==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᙃ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠧᙄ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᙅ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"ࠫࠬᙆ")
	elif l11lll_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᙇ") in url or l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࡣࡦࡰࡷࡩࡷ࠵ࠧᙈ") in url:
		block = html
	elif l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩᙉ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠬࠪᙊ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵࠪᙋ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡔࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠰ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠮ࠬᙌ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠫ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡅࡨࡺ࡯ࡳࡐࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙍ"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡉࡩ࡮ࡣ࠷ࡹࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࠬᙎ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"࠭ࠧᙏ")
	if not items: items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠫࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠰࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠮ࠫࡁࡅࡳࡽ࡚ࡩࡵ࡮ࡨࡍࡳ࡬࡯࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙐ"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᙑ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if not title: continue
		if l11lll_l1_ (u"ࠩࡂࡲࡪࡽࡳ࠾ࠩᙒ") in link: continue
		title = title.replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫᙓ"),l11lll_l1_ (u"ࠫࠬᙔ"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭ᙕ"),title,re.DOTALL)
		if l1lll11_l1_ and l11lll_l1_ (u"࠭อๅไฬࠫᙖ") in title:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᙗ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙘ"),l111ll_l1_+title,link,422,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪᙙ") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙚ"),l111ll_l1_+title,link,421,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙛ"),l111ll_l1_+title,link,422,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙜ"),html,re.DOTALL)
	if l1l1ll1_l1_ and l1111l111_l1_!=l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᙝ"):
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡ࡜ࠨ࡞ࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࡢࠢ࡞ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙞ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠨษ็ูๆำษࠡࠩᙟ"),l11lll_l1_ (u"ࠩࠪᙠ"))
			if title!=l11lll_l1_ (u"ࠪࠫᙡ"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙢ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫᙣ")+title,link,421)
	l11111l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼࠰࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙤ"),html,re.DOTALL)
	if l11111l11_l1_:
		link,title = l11111l11_l1_[0]
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙥ"),l111ll_l1_+title,link,421)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᙦ"),url,l11lll_l1_ (u"ࠩࠪᙧ"),l11lll_l1_ (u"ࠪࠫᙨ"),l11lll_l1_ (u"ࠫࠬᙩ"),l11lll_l1_ (u"ࠬ࠭ᙪ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫᙫ"))
	html = response.content
	# l11ll1l1l_l1_/download main l11l1ll1_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡔ࡯ࡸࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᙬ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		url = l1l1ll1_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᙭"),url,l11lll_l1_ (u"ࠩࠪ᙮"),l11lll_l1_ (u"ࠪࠫᙯ"),l11lll_l1_ (u"ࠫࠬᙰ"),l11lll_l1_ (u"ࠬ࠭ᙱ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠳ࡰࡧࠫᙲ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᙳ"),l11lll_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᙴ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡖࡩࡦࡹ࡯࡯ࡵࡖࡩࡨࡺࡩࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᙵ"),html,re.DOTALL)
	# l1llll1ll1_l1_ l11111111_l1_
	if l11lll_l1_ (u"ࠪ࠳ࡹࡧࡧ࠰ࠩᙶ") in url or l11lll_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵࠫᙷ") in url:
		l1111l_l1_(url)
	# l1lllll_l1_
	elif l1l1ll1_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭ᙸ"))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧᙹ"),block,re.DOTALL)
		l1lllll11l_l1_ = [l11lll_l1_ (u"ࠧๆี็ื้࠭ᙺ"),l11lll_l1_ (u"ࠨ็๋ื๊࠭ᙻ"),l11lll_l1_ (u"ࠩหี๋อๅอࠩᙼ"),l11lll_l1_ (u"ࠪั้่ษࠨᙽ")]
		for link,title in items:
			if any(value in title for value in l1lllll11l_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙾ"),l111ll_l1_+title,link,423,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᙿ"),l111ll_l1_+title,link,426,l1llll_l1_)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ "),url,l11lll_l1_ (u"ࠧࠨᚁ"),l11lll_l1_ (u"ࠨࠩᚂ"),l11lll_l1_ (u"ࠩࠪᚃ"),l11lll_l1_ (u"ࠪࠫᚄ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᚅ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᚆ"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᚇ"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᚈ"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩᚉ")
	# l1l1l_l1_
	l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚊ"),html,re.DOTALL)
	if l1llll1l1l_l1_:
		block = l1llll1l1l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚋ"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠫࠥ࠭ᚌ")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᚍ"),l111ll_l1_+title,link,426,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚎ"),l111ll_l1_+l11lll_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭ᚏ"),url,426,l1llll_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᚐ"),url,l11lll_l1_ (u"ࠩࠪᚑ"),headers,l11lll_l1_ (u"ࠪࠫᚒ"),l11lll_l1_ (u"ࠫࠬᚓ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᚔ"))
	html = response.content
	#newurl = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡶࡼࡰࡪࡹࡨࡦࡧࡷࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᚕ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᚖ"))
	l1ll1l1_l1_ = SERVER(newurl,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᚗ"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᚘ"),l11lll_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᚙ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡜ࡧࡴࡤࡪࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᚚ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᚛"),block,re.DOTALL)
		for l1l11111_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ᚜"))
			if l11lll_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭᚝") in title.lower(): title = l11lll_l1_ (u"ࠨะสูࠥ࠭᚞")+title
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡹࡸࡵࡤࡶࡸࡶࡪ࠵ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧ᚟")+l1l11111_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᚠ")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᚡ")
			#link = link.replace(l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡥ࠹ࡻ࠮ࡪࡥࡸࠫᚢ"),l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠴࡭ࡹࠩᚣ"))
			link = link.replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪᚤ"),l11lll_l1_ (u"ࠨࠩᚥ"))
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᚦ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚧ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᚨ"))
			if l11lll_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫᚩ") in title.lower(): l1lll1lll_l1_ = l11lll_l1_ (u"࠭࡟ࡠะสูࠬᚪ")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠧࠨᚫ")
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᚬ")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᚭ")+l1lll1lll_l1_
			link = link.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭ᚮ"),l11lll_l1_ (u"ࠫࠬᚯ"))
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᚰ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚱ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨᚲ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩᚳ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫᚴ"),l11lll_l1_ (u"ࠪ࠯ࠬᚵ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᚶ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬᚷ"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	if l11lll_l1_ (u"࠭ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨᚸ") not in url: url = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᚹ"))
	else: url = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᚺ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᚻ"),url,l11lll_l1_ (u"ࠪࠫᚼ"),l11lll_l1_ (u"ࠫࠬᚽ"),l11lll_l1_ (u"ࠬ࠭ᚾ"),l11lll_l1_ (u"࠭ࠧᚿ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩᛀ"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᛁ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡋࡳࡻ࡫ࡲࡢࡤ࡯ࡩ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿ࠣࡣ࡯ࡰࠧ࠴ࠪࡀࠪࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᛂ"),block,re.DOTALL)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id + title
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᛃ"),block,re.DOTALL)
	return items
def l111111ll_l1_(url):
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᛄ"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩᛅ"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	url = url.replace(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᛆ"),l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡩࡥ࡯ࡶࡨࡶ࠴ࡧࡣࡵ࡫ࡲࡲ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧᛇ"))
	url = url.replace(l11lll_l1_ (u"ࠨ࠿ࠪᛈ"),l11lll_l1_ (u"ࠩ࠲ࠫᛉ")).replace(l11lll_l1_ (u"ࠪࠪࠬᛊ"),l11lll_l1_ (u"ࠫ࠴࠭ᛋ"))
	url = url+l11lll_l1_ (u"ࠬ࠵ࠧᛌ")
	return url
l1l11lll_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᛍ"),l11lll_l1_ (u"ࠧࡵࡻࡳࡩࡸ࠭ᛎ"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᛏ")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᛐ"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᛑ"),l11lll_l1_ (u"ࠫࡹࡿࡰࡦࡵࠪᛒ"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᛓ")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᛔ"),l11lll_l1_ (u"ࠧࠨᛕ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᛖ"),l11lll_l1_ (u"ࠩࠪᛗ"),filter,url)
	if l11lll_l1_ (u"ࠪࡃࠬᛘ") in url: url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᛙ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩᛚ"),1)
	if filter==l11lll_l1_ (u"࠭ࠧᛛ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨᛜ"),l11lll_l1_ (u"ࠨࠩᛝ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ᛞ"))
	if type==l11lll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᛟ"):
		if l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨᛠ") in url:
			global l1l11lll_l1_
			l1l11lll_l1_ = l1l11lll_l1_[1:]
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠬࡃࠧᛡ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"࠭࠽ࠨᛢ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩᛣ")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫᛤ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫᛥ")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭ᛦ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭ᛧ"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩᛨ")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨᛩ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᛪ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ᛫")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ᛬"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ᛭"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠫࠬᛮ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᛯ"))
		if l1l11l11_l1_==l11lll_l1_ (u"࠭ࠧᛰ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᛱ")+l1l11l11_l1_
		l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᛲ"),l111ll_l1_+l11lll_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬᛳ"),l11l11l_l1_,421,l11lll_l1_ (u"ࠪࠫᛴ"),l11lll_l1_ (u"ࠫࠬᛵ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᛶ"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛷ"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧᛸ")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ᛹"),l11l11l_l1_,421,l11lll_l1_ (u"ࠩࠪ᛺"),l11lll_l1_ (u"ࠪࠫ᛻"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ᛼"))
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᛽"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᛾"),l11lll_l1_ (u"ࠧࠨ᛿"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		if l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬᜀ") in url and l1ll1lll_l1_==l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᜁ"): continue
		name = name.replace(l11lll_l1_ (u"ࠪ࠱࠲࠭ᜂ"),l11lll_l1_ (u"ࠫࠬᜃ"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧᜄ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᜅ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l111111ll_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ᜆ")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜇ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩᜈ"),l11l11l_l1_,421,l11lll_l1_ (u"ࠪࠫᜉ"),l11lll_l1_ (u"ࠫࠬᜊ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᜋ"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜌ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧᜍ"),l11l11l_l1_,425,l11lll_l1_ (u"ࠨࠩᜎ"),l11lll_l1_ (u"ࠩࠪᜏ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᜐ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᜑ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨᜒ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨᜓ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲᜔ࠪ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣ᜕ࠬ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᜖"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ᜗")+name,l11l11l_l1_,424,l11lll_l1_ (u"ࠫࠬ᜘"),l11lll_l1_ (u"ࠬ࠭᜙"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᜚"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ᜛"): option = l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ᜜")
			elif value==l11lll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ᜝"): option = l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ᜞")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪᜟ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᜠ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨᜡ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩᜢ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪᜣ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫᜤ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧᜥ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧᜦ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧᜧ")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩᜨ")+name
			if type==l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᜩ"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜪ"),l111ll_l1_+title,url,424,l11lll_l1_ (u"ࠩࠪᜫ"),l11lll_l1_ (u"ࠪࠫᜬ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᜭ"))
			elif type==l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᜮ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨᜯ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᜰ"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᜱ")+l1l1111l_l1_
				l11l1l1_l1_ = l111111ll_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜲ"),l111ll_l1_+title,l11l1l1_l1_,421,l11lll_l1_ (u"ࠪࠫᜳ"),l11lll_l1_ (u"᜴ࠫࠬ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ᜵"))
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᜶"),l111ll_l1_+title,url,425,l11lll_l1_ (u"ࠧࠨ᜷"),l11lll_l1_ (u"ࠨࠩ᜸"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ᜹"),l11lll_l1_ (u"ࠪࠫ᜺"),filters,l11lll_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬ᜻"))
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ᜼")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ᜽")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ᜾")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠨ࠿ࠩࠫ᜿"),l11lll_l1_ (u"ࠩࡀ࠴ࠫ࠭ᝀ"))
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠬᝁ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠫࡂ࠭ᝂ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠬࠬࠧᝃ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"࠭࠽ࠨᝄ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠧࠨᝅ")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪᝆ")
		if l11lll_l1_ (u"ࠩࠨࠫᝇ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᝈ") and value!=l11lll_l1_ (u"ࠫ࠵࠭ᝉ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩᝊ")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᝋ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᝌ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪᝍ")+key+l11lll_l1_ (u"ࠩࡀࠫᝎ")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᝏ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᝐ")+key+l11lll_l1_ (u"ࠬࡃࠧᝑ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪᝒ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩᝓ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨ࠿࠳ࠫ᝔"),l11lll_l1_ (u"ࠩࡀࠫ᝕"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ᝖"),l11lll_l1_ (u"ࠫࠬ᝗"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭᝘"))
	return l1ll1l1l_l1_
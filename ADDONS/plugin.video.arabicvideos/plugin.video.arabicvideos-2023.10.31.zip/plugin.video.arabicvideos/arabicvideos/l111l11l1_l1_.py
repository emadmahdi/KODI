# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭ፎ")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧፏ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ፐ"):l11lll_l1_ (u"ࠪࠫፑ")}
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫฬ็ไศ็่้้ࠣศศำࠪፒ"),l11lll_l1_ (u"ࠬฮใาษࠣࡘ࡛࠭ፓ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l1111l_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l111l111l_l1_(url)
	elif mode==375: results = l1111ll1l_l1_(url)
	elif mode==376: results = l1111lll1_l1_(0,url)
	elif mode==377: results = l1111lll1_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪፔ"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨፕ"),l11lll_l1_ (u"ࠨࠩፖ"),l11lll_l1_ (u"ࠩࠪፗ"),l11lll_l1_ (u"ࠪࠫፘ"),l11lll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬፙ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፚ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭፛"),l11lll_l1_ (u"ࠧࠨ፜"),379,l11lll_l1_ (u"ࠨࠩ፝"),l11lll_l1_ (u"ࠩࠪ፞"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ፟"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ፠"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ፡"),l11lll_l1_ (u"࠭ࠧ።"),9999)
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠳ࡳࡪࡦࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ፣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ፤"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፥"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፦")+l111ll_l1_+title,link,371)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፧"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፨")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ፩"),l11ll1_l1_,375)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፪"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፫")+l111ll_l1_+l11lll_l1_ (u"ࠩส่ศำฯฬࠩ፬"),l11ll1_l1_,376)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ፭"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭፮")+l111ll_l1_+l11lll_l1_ (u"ࠬ๐ิศ้าࠤฬ๊ย็ࠩ፯"),l11ll1_l1_,377)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭፰"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ፱")+l111ll_l1_+l11lll_l1_ (u"ࠨไสส๊ฯࠠศๆ่้ะ๊๊็ࠩ፲"),l11ll1_l1_,374)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ፳"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ፴"),l11lll_l1_ (u"ࠫࠬ፵"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡴࡰࡲ࠰ࡱࡪࡴࡵࠨ፶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ፷"),block,re.DOTALL)
		for link,title in items[7:]:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ፸"))
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፹"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፺")+l111ll_l1_+title,link,371)
		for link,title in items[0:7]:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ፻"))
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፼"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፽")+l111ll_l1_+title,link,371)
	return
def l111l111l_l1_(l1l1ll11_l1_=l11lll_l1_ (u"࠭ࠧ፾")):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ፿"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᎀ"),l11lll_l1_ (u"ࠩࠪᎁ"),l11lll_l1_ (u"ࠪࠫᎂ"),l11lll_l1_ (u"ࠫࠬᎃ"),l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡆࡉࡔࡐࡔࡖࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᎄ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠣࡧࡦࡺࠠࡕࡣࡪࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᎅ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᎆ"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᎇ") in link: continue
			else: link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎈ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᎉ")+l111ll_l1_+title,link,371)
	return
def l1111ll1l_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬᎊ")):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᎋ"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧᎌ"),l11lll_l1_ (u"ࠧࠨᎍ"),l11lll_l1_ (u"ࠨࠩᎎ"),l11lll_l1_ (u"ࠩࠪᎏ"),l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡉࡉࡆ࡚ࡕࡓࡇࡇ࠱࠶ࡹࡴࠨ᎐"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡓࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠷࠭᎑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡶࡪࡦࡳࡥ࡬࡫࡟࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ᎒"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"࠭࠺࠰࠱ࠪ᎓"),l11lll_l1_ (u"ࠧ࠻࠱࠲࠳ࠬ᎔")).replace(l11lll_l1_ (u"ࠨ࠱࠲ࠫ᎕"),l11lll_l1_ (u"ࠩ࠲ࠫ᎖")).replace(l11lll_l1_ (u"ࠪࠤࠬ᎗"),l11lll_l1_ (u"ࠫࠪ࠸࠰ࠨ᎘"))
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᎙"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᎚")+l111ll_l1_+title,link,372,l1llll_l1_)
	return
def l1111lll1_l1_(id,l1l1ll11_l1_=l11lll_l1_ (u"ࠧࠨ᎛")):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᎜"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ᎝"),l11lll_l1_ (u"ࠪࠫ᎞"),l11lll_l1_ (u"ࠫࠬ᎟"),l11lll_l1_ (u"ࠬ࠭Ꭰ"),l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡝ࡁࡕࡅࡋࡍࡓࡍࡎࡐ࡙࠰࠵ࡸࡺࠧᎡ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠶࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡳࡼ࠭Ꭲ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[id]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫᎣ"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠩ࠽࠳࠴࠭Ꭴ"),l11lll_l1_ (u"ࠪ࠾࠴࠵࠯ࠨᎥ")).replace(l11lll_l1_ (u"ࠫ࠴࠵ࠧᎦ"),l11lll_l1_ (u"ࠬ࠵ࠧᎧ")).replace(l11lll_l1_ (u"࠭ࠠࠨᎨ"),l11lll_l1_ (u"ࠧࠦ࠴࠳ࠫᎩ"))
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᎪ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᎫ")+l111ll_l1_+title,link,372,l1llll_l1_)
	return
def l1111l_l1_(url,l1l1111l1_l1_=l11lll_l1_ (u"ࠪࠫᎬ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᎭ"),l11lll_l1_ (u"ࠬ࠭Ꭾ"),l1l1111l1_l1_,url)
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ꭿ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᎰ"),url,l11lll_l1_ (u"ࠨࠩᎱ"),l11lll_l1_ (u"ࠩࠪᎲ"),l11lll_l1_ (u"ࠪࠫᎳ"),l11lll_l1_ (u"ࠫࠬᎴ"),l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᎵ"))
	html = response.content
	if l11lll_l1_ (u"࠭ࡶࡪࡦࡳࡥ࡬࡫࡟ࠨᎶ") in url:
		link = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠰ࡃ࡯ࡦࡺࡳ࠭࠯ࠬࡂ࠭ࠧ࠭Ꮇ"),html,re.DOTALL)
		if link:
			link = l11ll1_l1_+link[0]
			l1111l_l1_(link)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠢࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡳࡤ࠮࠵ࠪᎸ"),html,re.DOTALL)
	if l1l1111l1_l1_==l11lll_l1_ (u"ࠩࠪᎹ") and l1l1ll1_l1_ and l1l1ll1_l1_[0].count(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨᎺ"))>1:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᎻ"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠬᎼ"),url,371,l11lll_l1_ (u"࠭ࠧᎽ"),l11lll_l1_ (u"ࠧࠨᎾ"),l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࡳࠨᎿ"))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᏀ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᏁ")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭Ꮒ"))
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏃ"),l111ll_l1_+title,link,371)
	else:
		l1l1_l1_ = []
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡱࡩ࠳࠳ࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡻࡷ࠲࠷࠲ࠨᏄ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠹ࠤࠫ࠲࠯ࡅࠩࡤࡱ࡯࠱ࡽࡹ࠭࠲࠴ࠪᏅ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠪᏆ"),block,re.DOTALL)
			l11lll_l1_ (u"ࠤࠥࠦࠏࠏࠉࠊ࡫ࡷࡩࡲࡹ࠲ࠡ࠿ࠣ࡟ࡢࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰࡮ࡳࡧ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵࡴࡼ࠾ࠥࡩ࡯ࡶࡰࡷࠤࡂࠦࡩ࡯ࡶࠫࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨษ็ั้่ษࠡ࠭ࠫࡠࡩ࠱ࠩࠨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࡠ࠶࡝ࠪࠌࠌࠍࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡤࡱࡸࡲࡹࠦ࠽ࠡ࠯࠴ࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࠲࠯ࡣࡳࡴࡪࡴࡤࠩࠪ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠫࠬࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡵࡲࡶࡹ࡫ࡤࠩ࡫ࡷࡩࡲࡹ࠲࠭ࠢࡵࡩࡻ࡫ࡲࡴࡧࡀࡊࡦࡲࡳࡦ࠮ࠣ࡯ࡪࡿ࠽࡭ࡣࡰࡦࡩࡧࠠ࡬ࡧࡼ࠾ࠥࡱࡥࡺ࡝࠶ࡡ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰࡮ࡳࡧ࠭ࡶ࡬ࡸࡱ࡫ࠬࡤࡱࡸࡲࡹࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠨࠢࠣᏇ")
			for link,l1llll_l1_,title in items:
				#LOG_THIS(l11lll_l1_ (u"ࠪࠫᏈ"),l1llll_l1_)
				link = l11ll1_l1_+link
				title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭Ꮙ"))
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠬࡀ࠯࠰ࠩᏊ"),l11lll_l1_ (u"࠭࠺࠰࠱࠲ࠫᏋ")).replace(l11lll_l1_ (u"ࠧ࠰࠱ࠪᏌ"),l11lll_l1_ (u"ࠨ࠱ࠪᏍ")).replace(l11lll_l1_ (u"ࠩࠣࠫᏎ"),l11lll_l1_ (u"ࠪࠩ࠷࠶ࠧᏏ"))
				if l11lll_l1_ (u"ࠫ࠴ࡧ࡬ࡠࠩᏐ") in link:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏑ"),l111ll_l1_+title,link,371,l1llll_l1_)
				elif l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭Ꮢ") in title and (l11lll_l1_ (u"ࠧ࠰ࡅࡤࡸ࠲࠭Ꮣ") in url or l11lll_l1_ (u"ࠨ࠱ࡖࡩࡦࡸࡣࡩ࠱ࠪᏔ") in url):
					l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠯ࠣ࠯ฬ๊อๅไฬࠤ࠰ࡢࡤࠬࠩᏕ"),title,re.DOTALL)
					if l1lll11_l1_: title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨᏖ")+l1lll11_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᏗ"),l111ll_l1_+title,link,371,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᏘ"),l111ll_l1_+title,link,372,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᏙ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᏚ"),block,re.DOTALL)
			for link,title in items:
				link = l11ll1_l1_+link
				title = l11lll_l1_ (u"ࠨืไัฮࠦࠧᏛ")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏜ"),l111ll_l1_+title,link,371,l11lll_l1_ (u"ࠪࠫᏝ"),l11lll_l1_ (u"ࠫࠬᏞ"),l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡷࠬᏟ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᏠ"),url,l11lll_l1_ (u"ࠧࠨᏡ"),l11lll_l1_ (u"ࠨࠩᏢ"),l11lll_l1_ (u"ࠩࠪᏣ"),l11lll_l1_ (u"ࠪࠫᏤ"),l11lll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᏥ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡲࡡࡣࡧ࡯࠱ࡸࡻࡣࡤࡧࡶࡷࠥࡳࡲࡨ࠯ࡥࡸࡲ࠳࠵ࠡࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᏦ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l11l1l1_l1_ = l11lll_l1_ (u"࠭ࠧᏧ")
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡺࡸ࡬ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᏨ"),html,re.DOTALL)
	if l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_[0]
	else: l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠨ࠱ࡹ࡭ࡩࡶࡡࡨࡧࡢࠫᏩ"),l11lll_l1_ (u"ࠩ࠲ࡔࡱࡧࡹ࠰ࠩᏪ"))
	if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᏫ") not in l11l11l_l1_: l11l11l_l1_ = l11ll1_l1_+l11l11l_l1_
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠫ࠲࠭Ꮼ"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᏭ"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧᏮ"),l11lll_l1_ (u"ࠧࠨᏯ"),l11lll_l1_ (u"ࠨࠩᏰ"),l11lll_l1_ (u"ࠩࠪᏱ"),l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫᏲ"))
	l11lll1l_l1_ = response.content
	l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᏳ"),l11lll1l_l1_,re.DOTALL)
	if l11l1l1_l1_:
		l11l1l1_l1_ = l11l1l1_l1_[-1]
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᏴ") not in l11l1l1_l1_: l11l1l1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᏵ")+l11l1l1_l1_
		if l11lll_l1_ (u"ࠧ࠰ࡒࡏࡅ࡞࠵ࠧ᏶") not in l11l11l_l1_:
			if l11lll_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠮࡮࡫ࡱ࠲࡯ࡹࠧ᏷") in l11l1l1_l1_:
				l1111llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᏸ"),l11lll1l_l1_,re.DOTALL)
				if l1111llll_l1_:
					l1111ll11_l1_, l111l1111_l1_ = l1111llll_l1_[0]
					l11l1l1_l1_ = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧᏹ"))+l11lll_l1_ (u"ࠫ࠴ࡼ࠲࠰ࠩᏺ")+l1111ll11_l1_+l11lll_l1_ (u"ࠬ࠵ࡣࡰࡰࡩ࡭࡬࠵ࠧᏻ")+l111l1111_l1_+l11lll_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬᏼ")
		import ll_l1_
		ll_l1_.l11_l1_([l11l1l1_l1_],script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᏽ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩ᏾"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪ᏿"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ᐀"),l11lll_l1_ (u"ࠫ࠰࠭ᐁ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡓࡦࡣࡵࡧ࡭࠵ࠧᐂ")+search
	l1111l_l1_(url)
	return
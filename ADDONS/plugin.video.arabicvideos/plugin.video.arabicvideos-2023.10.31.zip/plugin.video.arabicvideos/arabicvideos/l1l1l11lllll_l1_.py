# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ朝")
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ朞"):l11lll_l1_ (u"ࠩࠪ期")}
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ朠")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ朡"),l11lll_l1_ (u"ࠬࡽࡷࡦࠩ朢")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1111l_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llllll_l1_(url,text)
	elif mode==564: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭朣")+text)
	elif mode==565: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ朤")+text)
	elif mode==566: results = l1l11l_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ朥"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ朦"),l11lll_l1_ (u"ࠪࠫ朧"),False,l11lll_l1_ (u"ࠫࠬ木"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ朩"))
	#hostname = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ未")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠧ࠰ࠩ末"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ本")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭札"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ朮"),l11lll_l1_ (u"ࠫࠬ术"),l11lll_l1_ (u"ࠬ࠭朰"),l11lll_l1_ (u"࠭ࠧ朱"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ朲"))
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭朳"),l111ll_l1_+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ朴"),l11lll_l1_ (u"ࠪࠫ朵"),8)
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ朶"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ朷"),l11lll_l1_ (u"࠭ࠧ朸"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ朹"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ机"),l11ll1_l1_,569,l11lll_l1_ (u"ࠩࠪ朻"),l11lll_l1_ (u"ࠪࠫ朼"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ朽"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ朾"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ朿"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ杀"),564)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杁"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ杂"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ权"),565)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ杄"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ杅"),l11lll_l1_ (u"࠭ࠧ杆"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ杇"):hostname,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ杈"):l11lll_l1_ (u"ࠩࠪ杉")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"ࠪࡠ࠴࠭杊"),l11lll_l1_ (u"ࠫ࠴࠭杋"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ杌"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ杍"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ李") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杏"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ材")+l111ll_l1_+title,link,566)
	#	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ村"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ杒"),l11lll_l1_ (u"ࠬ࠭杓"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ杔"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ杕"),l11lll_l1_ (u"ࠨࠩ杖"),l11lll_l1_ (u"ࠩࠪ杗"),l11lll_l1_ (u"ࠪࠫ杘"),l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭杙"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭杚"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ杛"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ杜") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ杝"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠩࠪ杞"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ束"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭杠")+l111ll_l1_+title,link,566)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ条"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭杢"),l11lll_l1_ (u"ࠧࠨ杣"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ杤"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ来"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ杦"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭杧")+l111ll_l1_+title,link,566,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭杨"),l11lll_l1_ (u"࠭ࠧ杩"),url,l11lll_l1_ (u"ࠧࠨ杪"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ杫"):url,l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭杬"):l11lll_l1_ (u"ࠪࠫ杭")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ杮"),url,l11lll_l1_ (u"ࠬ࠭杯"),l11lll_l1_ (u"࠭ࠧ杰"),l11lll_l1_ (u"ࠧࠨ東"),l11lll_l1_ (u"ࠨࠩ杲"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ杳"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ杴"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ杵"),url,564)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ杶"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ杷"),url,565)
	if l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ杸") in html:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杹"),l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ杺"),url,561,l11lll_l1_ (u"ࠪࠫ杻"),l11lll_l1_ (u"ࠫࠬ杼"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ杽"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ松"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ板"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枀"),l111ll_l1_+title,link,561)
	return
def l1111l_l1_(l1ll11l11lll_l1_,type=l11lll_l1_ (u"ࠩࠪ极")):
	if l11lll_l1_ (u"ࠪ࠾࠿࠭枂") in l1ll11l11lll_l1_:
		l11l1l1_l1_,url = l1ll11l11lll_l1_.split(l11lll_l1_ (u"ࠫ࠿ࡀࠧ枃"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ构"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l11lll_l1_,l1ll11l11lll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ枅"):l11l1l1_l1_,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ枆"):l11lll_l1_ (u"ࠨࠩ枇")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭枈"),url,l11lll_l1_ (u"ࠪࠫ枉"),l11lll_l1_ (u"ࠫࠬ枊"),l11lll_l1_ (u"ࠬ࠭枋"),l11lll_l1_ (u"࠭ࠧ枌"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ枍"))
	html = response.content
	if type==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ枎"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭枏"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ析"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠫࡡࡢ࠯ࠨ枑"),l11lll_l1_ (u"ࠬ࠵ࠧ枒")).replace(l11lll_l1_ (u"࠭࡜࡝ࠤࠪ枓"),l11lll_l1_ (u"ࠧࠣࠩ枔"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡘࡧࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ枕"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ枖"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫ林"),l11lll_l1_ (u"ࠫࠬ枘"))
			if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ枙") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭枚"),l111ll_l1_+title,link,563,l1llll_l1_)
			elif l11lll_l1_ (u"ࠧฮๆๅอࠬ枛") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ果"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ枝") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ枞"),l111ll_l1_+title,link,563,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ枟"),l111ll_l1_+title,link,562,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭枠"):
			l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ枡"),block,re.DOTALL)
			if l1lll11ll1l_l1_:
				count = l1lll11ll1l_l1_[0]
				link = url+l11lll_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ枢")+count
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ枣"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ枤"),link,561,l11lll_l1_ (u"ࠪࠫ枥"),l11lll_l1_ (u"ࠫࠬ枦"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭枧"))
		elif type==l11lll_l1_ (u"࠭ࠧ枨"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ枩"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ枪"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ุࠩๅาฯࠠࠨ枫")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ枬"),l111ll_l1_+title,link,561)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠫࠬ枭")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭枮"),l11lll_l1_ (u"࠭ࠧ枯"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ枰"),url,l11lll_l1_ (u"ࠨࠩ枱"),l11lll_l1_ (u"ࠩࠪ枲"),l11lll_l1_ (u"ࠪࠫ枳"),l11lll_l1_ (u"ࠫࠬ枴"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ枵"))
	html = response.content
	html = l111l_l1_(html)
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࡞࠱࠶ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠰ࠫ࠱࠭ࠠࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪ࠳ࠬ࠯ࠊࠊ࡫ࡩࠤ๋่ࠬิ็ࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡴࡺࡲࡨ࠾ࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡹࡰ࡭࡫ࡷ๋่ࠬࠬิ็ࠪ࠭ࡠ࠶࡝ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡴࡨࡴࡱࡧࡣࡦู้ࠪࠪอ็ะหࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬำไใหࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭อๅไฬࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠣࠤࠥ架")
	# l1lllll_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ枷"),html,re.DOTALL)
	if not type and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ枸"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭枹")+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ枺"),l111ll_l1_+title,link,563,l11lll_l1_ (u"ࠫࠬ枻"),l11lll_l1_ (u"ࠬ࠭枼"),l11lll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ枽"))
			return
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳࡹ࠾ࠨ枾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ枿"),block)
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ柀"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ柁"),str(items))
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭柂"))
			#title = name+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ柃")+title
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ柄"),l111ll_l1_+title,link,562)
	if not menuItemsLIST:
		title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ柅"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭柆"),l11lll_l1_ (u"ࠩࠪ柇")).replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫ柈"),l11lll_l1_ (u"ࠫࠬ柉"))
		else: title = l11lll_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ柊")
		addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ柋"),l111ll_l1_+title,url,562)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ柌"),url,l11lll_l1_ (u"ࠨࠩ柍"),l11lll_l1_ (u"ࠩࠪ柎"),l11lll_l1_ (u"ࠪࠫ柏"),l11lll_l1_ (u"ࠫࠬ某"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ柑"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭柒"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭染"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭柔"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ柕") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"ࠪื๏ืแา๋ࠢ๎ู๊ࠥๆษࠪ柖"): name = l11lll_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ柗")
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭柘")+name+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ柙")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ柚"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭柛"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ柜") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ柝"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ柞")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭柟")
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡷࡦࡥ࡬ࡱࡦ࠭柠")+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ柡")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭柢"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ柣"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"ࠪࠫ柤")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ查"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭柦"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ柧"),l11lll_l1_ (u"ࠧࠬࠩ柨"))
	l1111_l1_ = [l11lll_l1_ (u"ࠨ࠱ࠪ柩"),l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡵࡨࡶ࡮࡫ࡳࠨ柪"),l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡤࡲ࡮ࡳࡥࠨ柫"),l11lll_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡸࡻ࠭柬"),l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ柭")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"࠭รโๆส้ࠬ柮"),l11lll_l1_ (u"ࠧๆี็ื้อสࠨ柯"),l11lll_l1_ (u"ࠨล้๎๊๐้ࠠๅิฮํ์ࠧ柰"),l11lll_l1_ (u"ࠩหีฬ๋ฬࠡฬ็๎ๆุ๊้่ࠪ柱"),l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤํษๆ๋็ํࠫ柲")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ柳"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11ll1_l1_
		#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ柴"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ柵"),l11lll_l1_ (u"ࠧࠨ柶"),False,l11lll_l1_ (u"ࠨࠩ柷"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭柸"))
		#hostname = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ柹")]
		#hostname = response.url
		#hostname = hostname.strip(l11lll_l1_ (u"ࠫ࠴࠭柺"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ査")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l11lll_l1_,filter):
	if l11lll_l1_ (u"࠭࠿ࡀࠩ柼") in l1ll11l11lll_l1_: url = l1ll11l11lll_l1_.split(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭柽"))[0]
	else: url = l1ll11l11lll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ柾"):l1ll11l11lll_l1_,l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭柿"):l11lll_l1_ (u"ࠪࠫ栀")}
	filter = filter.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭栁"),l11lll_l1_ (u"ࠬ࠭栂"))
	type,filter = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ栃"),1)
	if filter==l11lll_l1_ (u"ࠧࠨ栄"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠨࠩ栅"),l11lll_l1_ (u"ࠩࠪ栆")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ标"))
	if type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ栈"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"ࠬࡃ࠽ࠨ栉") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"࠭࠽࠾ࠩ栊") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ栋")+category+l11lll_l1_ (u"ࠨ࠿ࡀ࠴ࠬ栌")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ栍")+category+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧ栎")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫࠬࠧ栏"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ栐")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠧࠩ树"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ栒"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ栓")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ栔"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ栕"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠫࠬ栖"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ栗"))
		if l1l11l11_l1_==l11lll_l1_ (u"࠭ࠧ栘"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭栙")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll11l11lll_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ栚"),l111ll_l1_+l11lll_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ栛"),l1111111_l1_,561,l11lll_l1_ (u"ࠪࠫ栜"),l11lll_l1_ (u"ࠫࠬ栝"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭栞"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭栟"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ栠")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ校"),l1111111_l1_,561,l11lll_l1_ (u"ࠩࠪ栢"),l11lll_l1_ (u"ࠪࠫ栣"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ栤"))
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ栥"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭栦"),l11lll_l1_ (u"ࠧࠨ栧"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ栨"),url,l11lll_l1_ (u"ࠩࠪ栩"),l11lll_l1_ (u"ࠪࠫ株"),l11lll_l1_ (u"ࠫࠬ栫"),l11lll_l1_ (u"ࠬ࠭栬"),l11lll_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ栭"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠧ࡝࡞ࠥࠫ栮"),l11lll_l1_ (u"ࠨࠤࠪ栯")).replace(l11lll_l1_ (u"ࠩ࡟ࡠ࠴࠭栰"),l11lll_l1_ (u"ࠪ࠳ࠬ栱"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ栲"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ栳"),block+l11lll_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ栴"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ栵") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ栶"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠩࡀࡁࠬ样") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ核"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ根")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll11l11lll_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ栺"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾࠭栻"),l1111111_l1_,561,l11lll_l1_ (u"ࠧࠨ格"),l11lll_l1_ (u"ࠨࠩ栽"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ栾"))
				else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ栿"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ桀"),l11l11l_l1_,564,l11lll_l1_ (u"ࠬ࠭桁"),l11lll_l1_ (u"࠭ࠧ桂"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ桃"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ桄")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࡁ࠵࠭桅")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭框")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨ桇")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ案")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桉"),l111ll_l1_+name+l11lll_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ桊"),l11l11l_l1_,565,l11lll_l1_ (u"ࠨࠩ桋"),l11lll_l1_ (u"ࠩࠪ桌"),l1l1l11l_l1_+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ桍"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠫࡷ࠭桎") or value==l11lll_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ桏"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ桐") in option: continue
			if l11lll_l1_ (u"ࠧศๆๆ่ࠬ桑") in option: continue
			if l11lll_l1_ (u"ࠨࡰ࠰ࡥࠬ桒") in value: continue
			#if value in [l11lll_l1_ (u"ࠩࡵࠫ桓"),l11lll_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ桔"),l11lll_l1_ (u"ࠫࡹࡼ࠭࡮ࡣࠪ桕")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ桖"): option = value
			if option==l11lll_l1_ (u"࠭ࠧ桗"): option = value
			l11ll1l11_l1_ = option
			l1l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ桘"),option,re.DOTALL)
			if l1l11ll11ll_l1_: l11ll1l11_l1_ = l1l11ll11ll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠨ࠼ࠣࠫ桙")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ桚")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࡂ࠭桛")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ桜")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽ࠨ桝")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ桞")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ桟"):
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ桠"),l111ll_l1_+l1lll1lll_l1_,url,565,l11lll_l1_ (u"ࠩࠪ桡"),l11lll_l1_ (u"ࠪࠫ桢"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭档"))
			elif type==l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ桤") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"࠭࠽࠾ࠩ桥") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ桦"))
				#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ桧"),l11lll_l1_ (u"ࠩࠪ桨"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ桩")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_,l1ll11l11lll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桪"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,561,l11lll_l1_ (u"ࠬ࠭桫"),l11lll_l1_ (u"࠭ࠧ桬"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ桭"))
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ桮"),l111ll_l1_+l1lll1lll_l1_,url,564,l11lll_l1_ (u"ࠩࠪ桯"),l11lll_l1_ (u"ࠪࠫ桰"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ桱"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ桲"),l11lll_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭桳")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ桴"),l11lll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ桵"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ桶"),l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ桷"),l11lll_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ桸"),l11lll_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ桹"),l11lll_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭桺"),l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ桻")]
def l11llllll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ桼") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ桽"),l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ桾"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ桿"),l11lll_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ梀"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭࠽࠾ࠩ梁"),l11lll_l1_ (u"ࠧ࠰ࠩ梂"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨࠨࠩࠫ梃"),l11lll_l1_ (u"ࠩ࠲ࠫ梄"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ梅"),l11lll_l1_ (u"ࠫࠬ梆"),filters,l11lll_l1_ (u"ࠬࡏࡎࠡࠢࠣࠤࠬ梇")+mode)
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ梈")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ梉")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ梊")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ梋"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠪࠫ梌")
	if l11lll_l1_ (u"ࠫࡂࡃࠧ梍") in filters:
		items = filters.split(l11lll_l1_ (u"ࠬࠬࠦࠨ梎"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"࠭࠽࠾ࠩ梏"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠧ࠱ࠩ梐")
		if l11lll_l1_ (u"ࠨࠧࠪ梑") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ梒") and value!=l11lll_l1_ (u"ࠪ࠴ࠬ梓"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ梔")+value
		elif mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ梕") and value!=l11lll_l1_ (u"࠭࠰ࠨ梖"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ梗")+key+l11lll_l1_ (u"ࠨ࠿ࡀࠫ梘")+value
		elif mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭梙"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭梚")+key+l11lll_l1_ (u"ࠫࡂࡃࠧ梛")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠦࠫࠡࠩ梜"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠦࠧࠩ條"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ梞"),l11lll_l1_ (u"ࠨࠩ梟"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠩࡒ࡙࡙࠭梠"))
	return l1ll1l1l_l1_
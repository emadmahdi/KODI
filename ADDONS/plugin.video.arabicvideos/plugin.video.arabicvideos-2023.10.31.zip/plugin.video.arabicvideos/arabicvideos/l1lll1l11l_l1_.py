# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭᠍")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫ᠎")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ู࠭าู๊ࠤฬ๊ๅึษิ฽์࠭᠏"),l11lll_l1_ (u"ࠧๅๆๆฬฬืࠠโไฺࠤ࠰࠷࠸ࠨ᠐"),l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ᠑"),l11lll_l1_ (u"ࠩสๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬ᠒")]
headers = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ᠓"):l11ll1_l1_}
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l1lll1l1l1_l1_(url)
	elif mode==634: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ᠔")+text)
	elif mode==635: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ᠕")+text)
	elif mode==639: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᠖"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ᠗"),headers,l11lll_l1_ (u"ࠨࠩ᠘"),l11lll_l1_ (u"ࠩࠪ᠙"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ᠚"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠛"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ᠜"),l11ll1_l1_,639,l11lll_l1_ (u"࠭ࠧ᠝"),l11lll_l1_ (u"ࠧࠨ᠞"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᠟"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠠ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᠡ"),l11ll1_l1_,635,l11lll_l1_ (u"ࠫࠬᠢ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᠣ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᠤ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪᠥ"),l11ll1_l1_,634,l11lll_l1_ (u"ࠨࠩᠦ"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᠧ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᠨ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᠩ"),l11lll_l1_ (u"ࠬ࠭ᠪ"),9999)
	link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡲ࡬ࡲࡵࡵࡳࡵࡵࠩࡣࡨࡵࡵ࡯ࡶࡀ࠵࠵࠭ᠫ")
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᠬ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᠭ")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪᠮ"),link,631,l11lll_l1_ (u"ࠪࠫᠯ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᠰ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᠱ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡕࡣࡥࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᠲ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᠳ"),block,re.DOTALL)
	for data,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡹࡿࡰࡦ࠿ࡲࡲࡪࠬࡤࡢࡶࡤࡁࠬᠴ")+data
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠵ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᠶ")+l111ll_l1_+title,link,631)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᠷ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᠸ"),l11lll_l1_ (u"࠭ࠧᠹ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᠺ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᠻ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠼ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᠽ")+l111ll_l1_+title,link,631)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠫࠬᠾ")):
	if type==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᠿ"):
		l1l1ll1ll_l1_ = headers.copy()
		l1l1ll1ll_l1_[l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᡀ")] = l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᡁ")
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᡂ"),url,l11lll_l1_ (u"ࠩࠪᡃ"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫᡄ"),l11lll_l1_ (u"ࠫࠬᡅ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᡆ"))
		html = response.content
		block = html
	else:
		block = l11lll_l1_ (u"࠭ࠧᡇ")
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᡈ"),url,l11lll_l1_ (u"ࠨࠩᡉ"),headers,l11lll_l1_ (u"ࠩࠪᡊ"),l11lll_l1_ (u"ࠪࠫᡋ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᡌ"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡥࡥ࡫ࡤ࠱ࡧࡲ࡯ࡤ࡭ࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸ࠭࡮ࡧࡱࡹࠬᡍ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡣࡱࡻ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡎ"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		l1llll_l1_ = l1llll_l1_+l11lll_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᡏ")+l11ll1_l1_
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪᡐ") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᡑ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᡒ")+l111ll_l1_+title,link,633,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᡓ") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡔ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᡕ")+l111ll_l1_+title,link,633,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᡖ") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᡗ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᡘ")+l111ll_l1_+title,link,631,l1llll_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬᡙ") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡚ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᡛ")+l111ll_l1_+title,link,631,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᡜ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᡝ")+l111ll_l1_+title,link,632,l1llll_l1_)
	# l1lll1lll1_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᡞ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᡟ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠪห้฻แฮหࠣࠫᡠ"),l11lll_l1_ (u"ࠫࠬᡡ"))
			if title!=l11lll_l1_ (u"ࠬ࠭ᡢ"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡣ"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ᡤ")+title,link,631)
	return
def l1lll1l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᡥ"),url,l11lll_l1_ (u"ࠩࠪᡦ"),headers,l11lll_l1_ (u"ࠪࠫᡧ"),l11lll_l1_ (u"ࠫࠬᡨ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᡩ"))
	html = response.content
	l1llll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠳ࡩ࡮ࡣࡪࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᡪ"),html,re.DOTALL)
	l1llll_l1_ = l1llll_l1_[0] if l1llll_l1_ else l11lll_l1_ (u"ࠧࠨᡫ")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡲࡰࡩ࡫ࡲ࠮ࡤ࡯ࡳࡨࡱ࠮ࠫࡁ࠿࡬࠷࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᡬ"),html,re.DOTALL)
	for name,block in l1l1ll1_l1_:
		# l1lllll_l1_
		if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᡭ") in url and l11lll_l1_ (u"้ࠪํอำๆࠩᡮ") in name:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭ᡯ"),block,re.DOTALL)
			for link,title in items:
				title = title.replace(l11lll_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂࠬᡰ"),l11lll_l1_ (u"࠭ࠠࠨᡱ")).replace(l11lll_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨᡲ"),l11lll_l1_ (u"ࠨࠩᡳ"))
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᡴ"),l111ll_l1_+title,link,633,l1llll_l1_)
		# l1l1l_l1_
		if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬᡵ") in url and l11lll_l1_ (u"ࠫา๊โศฬࠪᡶ") in name:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧᡷ"),block,re.DOTALL)
			for link,title in items:
				title = title.replace(l11lll_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠭ᡸ"),l11lll_l1_ (u"ࠧࠡࠩ᡹")).replace(l11lll_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩ᡺"),l11lll_l1_ (u"ࠩࠪ᡻"))
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᡼"),l111ll_l1_+title,link,632,l1llll_l1_)
	return
def PLAY(url):
	url = url.replace(l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ᡽"),l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭᡾")).replace(l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭᡿"),l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨᢀ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᢁ"),url,l11lll_l1_ (u"ࠩࠪᢂ"),headers,l11lll_l1_ (u"ࠪࠫᢃ"),l11lll_l1_ (u"ࠫࠬᢄ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᢅ"))
	html = response.content
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠳ࡷࡳࡣࡳࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᢆ"),html,re.DOTALL)
	if link:
		link = link[0]
		l1lll11ll1_l1_.append(link)
		server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬᢇ"))
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᢈ")+server+l11lll_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪᢉ"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡶ࠱ࡹࡧࡢࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᢊ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11llll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬᢋ"),html,re.DOTALL)
		l11llll1_l1_ = l11llll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᢌ"),block,re.DOTALL)
		for l1l11111_l1_,title in items:
			title = title.replace(l11lll_l1_ (u"࠭࡜࡯ࠩᢍ"),l11lll_l1_ (u"ࠧࠨᢎ"))
			if not title: title = l11lll_l1_ (u"ࠨษ็ื๏ืแาࠢส่๊๋๊ำࠩᢏ")
			link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧᢐ")+l11llll1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧᢑ")+l1l11111_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᢒ")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᢓ")
			l1lllll1_l1_.append(link)
	# download links
	items = re.findall(l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤ࡯ࡳࡨࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫᢔ"),html,re.DOTALL)
	for link,title in items:
		if link not in l1lll11ll1_l1_:
			l1lll11ll1_l1_.append(link)
			title = title.replace(l11lll_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠧᢕ"),l11lll_l1_ (u"ࠨࠢࠪᢖ")).replace(l11lll_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪᢗ"),l11lll_l1_ (u"ࠪࠫᢘ")).replace(l11lll_l1_ (u"ࠫࡁ࡯࠾ࠨᢙ"),l11lll_l1_ (u"ࠬ࠭ᢚ")).replace(l11lll_l1_ (u"࠭࠼࠰࡫ࡁࠫᢛ"),l11lll_l1_ (u"ࠧࠡࠩᢜ"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᢝ")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᢞ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᢟ"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᢠ"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠬ࠭ᢡ")):
	if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨᢢ"),l11lll_l1_ (u"ࠧࠬࠩᢣ"))
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᢤ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᢥ"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_ l1lllll1l_l1_ 2023-10-30
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᢦ"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᢧ"),url,l11lll_l1_ (u"ࠬ࠭ᢨ"),headers,l11lll_l1_ (u"ᢩ࠭ࠧ"),l11lll_l1_ (u"ࠧࠨᢪ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ᢫"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ᢬"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡴࡵࠣࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᢭"),block,re.DOTALL)
		names,l1lll1l111_l1_,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠫࡨࡧࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᢮"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	if l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ᢯") in url:
		url,filters = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᢰ"))
		# filter final url
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫᢱ")+filters
	else: link = l11ll1_l1_
	return link
l1lll11lll_l1_ = [l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᢲ"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᢳ"),l11lll_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᢴ"),l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬᢵ")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᢶ"),l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᢷ"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᢸ")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᢹ"),l11lll_l1_ (u"ࠩࠪᢺ"))
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᢻ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨᢼ"),1)
	if filter==l11lll_l1_ (u"ࠬ࠭ᢽ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"࠭ࠧᢾ"),l11lll_l1_ (u"ࠧࠨᢿ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬᣀ"))
	if type==l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᣁ"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"ࠪࡁࠬᣂ") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"ࠫࡂ࠭ᣃ") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧᣄ")+category+l11lll_l1_ (u"࠭࠽࠱ࠩᣅ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩᣆ")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫᣇ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫᣈ"))+l11lll_l1_ (u"ࠪࡣࡤࡥࠧᣉ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭ᣊ"))
		# l1lll1l1ll_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᣋ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᣌ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬᣍ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᣎ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1lll1ll1l_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᣏ"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᣐ")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᣑ"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨᣒ"),l11l1l1_l1_,631,l11lll_l1_ (u"࠭ࠧᣓ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᣔ"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣕ"),l111ll_l1_+l11lll_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩᣖ")+l11lll11_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩᣗ"),l11l1l1_l1_,631,l11lll_l1_ (u"ࠫࠬᣘ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᣙ"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᣚ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᣛ"),l11lll_l1_ (u"ࠨࠩᣜ"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠩๆ่ࠥ࠭ᣝ"),l11lll_l1_ (u"ࠪࠫᣞ"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠫࡂ࠭ᣟ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᣠ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_,l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᣡ"))
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᣢ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣣ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪᣤ"),l11l1l1_l1_,631,l11lll_l1_ (u"ࠪࠫᣥ"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᣦ"))
				else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣧ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᣨ"),l11l11l_l1_,635,l11lll_l1_ (u"ࠧࠨᣩ"),l11lll_l1_ (u"ࠨࠩᣪ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧᣫ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬᣬ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧᣭ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧᣮ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩᣯ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫᣰ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣱ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᣲ")+name,l11l11l_l1_,634,l11lll_l1_ (u"ࠪࠫᣳ"),l11lll_l1_ (u"ࠫࠬᣴ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᣵ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ᣶")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ᣷")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ᣸")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ᣹")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ᣺")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧ᣻")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧ᣼")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩ᣽")+name
			if type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ᣾"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᣿"),l111ll_l1_+title,url,634,l11lll_l1_ (u"ࠩࠪᤀ"),l11lll_l1_ (u"ࠪࠫᤁ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᤂ"))
			elif type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᤃ") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨᤄ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᤅ"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᤆ")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤇ"),l111ll_l1_+title,l11l1l1_l1_,631,l11lll_l1_ (u"ࠪࠫᤈ"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᤉ"))
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤊ"),l111ll_l1_+title,url,635,l11lll_l1_ (u"࠭ࠧᤋ"),l11lll_l1_ (u"ࠧࠨᤌ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᤍ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᤎ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᤏ")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠫࡂࠬࠧᤐ"),l11lll_l1_ (u"ࠬࡃ࠰ࠧࠩᤑ"))
	filters = filters.strip(l11lll_l1_ (u"࠭ࠦࠨᤒ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠧ࠾ࠩᤓ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠪᤔ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࠫᤕ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠪࠫᤖ")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠫ࠵࠭ᤗ")
		if l11lll_l1_ (u"ࠬࠫࠧᤘ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᤙ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᤚ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬᤛ")+value
		elif mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᤜ") and value!=l11lll_l1_ (u"ࠪ࠴ࠬᤝ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᤞ")+key+l11lll_l1_ (u"ࠬࡃࠧ᤟")+value
		elif mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪᤠ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩᤡ")+key+l11lll_l1_ (u"ࠨ࠿ࠪᤢ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭ᤣ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬᤤ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠫࡂ࠶ࠧᤥ"),l11lll_l1_ (u"ࠬࡃࠧᤦ"))
	return l1ll1l1l_l1_
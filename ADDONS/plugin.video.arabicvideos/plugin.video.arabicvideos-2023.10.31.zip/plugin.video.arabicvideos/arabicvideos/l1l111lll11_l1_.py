﻿# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#import unicodedata,simplejson
def MAIN(mode,l1l11l111ll_l1_):
	if l1l11l111ll_l1_==l11lll_l1_ (u"ࠬ࠭㙚"): return
	if mode==1:
		l1l11l111l1_l1_ = xbmcgui.l1l11l1111l_l1_()
		l1l11l11111_l1_ = xbmcgui.l1l111ll111_l1_(l1l11l111l1_l1_)
		l1l11l111ll_l1_ = l1l111lllll_l1_(l1l11l111ll_l1_)
		l1l11l11111_l1_.getControl(311).l1l11l11l1l_l1_(l1l11l111ll_l1_)
	if mode==0:
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㙛"))
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㙜"))
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㙝"))
		l1l111ll1l1_l1_=l11lll_l1_ (u"࡛ࠩࠫ㙞")
		if kodi_version>18.99: check = isinstance(l1l11l111ll_l1_,str)
		else: check = isinstance(l1l11l111ll_l1_,unicode)
		if check==True: l1l111ll1l1_l1_=l11lll_l1_ (u"࡙ࠪࠬ㙟")
		l1l111ll11l_l1_=str(type(l1l11l111ll_l1_))+l11lll_l1_ (u"ࠫࠥ࠭㙠")+l1l11l111ll_l1_+l11lll_l1_ (u"ࠬࠦࠧ㙡")+l1l111ll1l1_l1_+l11lll_l1_ (u"࠭ࠠࠨ㙢")
		for i in range(0,len(l1l11l111ll_l1_),1):
			l1l111ll11l_l1_ += hex(ord(l1l11l111ll_l1_[i])).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㙣"),l11lll_l1_ (u"ࠨࠩ㙤"))+l11lll_l1_ (u"ࠩࠣࠫ㙥")
		l1l11l111ll_l1_ = l1l111lllll_l1_(l1l11l111ll_l1_)
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㙦"))
		l1l111ll1l1_l1_=l11lll_l1_ (u"ࠫ࡝࠭㙧")
		if kodi_version>18.99: check = isinstance(l1l11l111ll_l1_, str)
		else: check = isinstance(l1l11l111ll_l1_, unicode)
		if check==True: l1l111ll1l1_l1_=l11lll_l1_ (u"࡛ࠬࠧ㙨")
		l1l111ll1ll_l1_=str(type(l1l11l111ll_l1_))+l11lll_l1_ (u"࠭ࠠࠨ㙩")+l1l11l111ll_l1_+l11lll_l1_ (u"ࠧࠡࠩ㙪")+l1l111ll1l1_l1_+l11lll_l1_ (u"ࠨࠢࠪ㙫")
		for i in range(0,len(l1l11l111ll_l1_),1):
			l1l111ll1ll_l1_ += hex(ord(l1l11l111ll_l1_[i])).replace(l11lll_l1_ (u"ࠩ࠳ࡼࠬ㙬"),l11lll_l1_ (u"ࠪࠫ㙭"))+l11lll_l1_ (u"ࠫࠥ࠭㙮")
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㙯"),l11lll_l1_ (u"࠭ࠧ㙰"),l1l111ll11l_l1_,l1l111ll1ll_l1_)
	return
	#for i in range(0,len(l1l11l111ll_l1_)-2,3):
	#	string=hex(ord(l1l11l111ll_l1_[i+0]))+l11lll_l1_ (u"ࠧࠡࠢࠪ㙱")+hex(ord(l1l11l111ll_l1_[i+1]))+l11lll_l1_ (u"ࠨࠢࠣࠫ㙲")+hex(ord(l1l11l111ll_l1_[i+2]))
	#	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㙳"),l11lll_l1_ (u"ࠪࠫ㙴"),l11lll_l1_ (u"ࠫࠬ㙵"),string)
	#return
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㙶"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㙷"),l11lll_l1_ (u"ࠧࠨ㙸"),l11lll_l1_ (u"ࠨࠩ㙹"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l111lllll_l1_(l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㙺"))
	#l1l11l111ll_l1_ = unicodedata.normalize(l11lll_l1_ (u"ࠪࡒࡋࡑࡄࠨ㙻"),l1l11l111ll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㙼"),l11lll_l1_ (u"ࠬ࠭㙽"),l11lll_l1_ (u"࠭ࠧ㙾"),   hex(  unicodedata.combining(l1l11l111ll_l1_[0])  )   )
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㙿"),l11lll_l1_ (u"ࠨࠩ㚀"),l1l11l111ll_l1_,   hex(ord(  l1l11l111ll_l1_[0]  ))   )
	#new = l11lll_l1_ (u"ࠩࠪ㚁")
	#for l1l111lll1l_l1_ in l1l11l111ll_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㚂"),l11lll_l1_ (u"ࠫࠬ㚃"),l11lll_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㚄"),unicodedata.decomposition(l1l111lll1l_l1_) )
	#	new += l11lll_l1_ (u"࠭࡜ࡶ࠲ࠪ㚅") + hex(ord(l1l111lll1l_l1_)).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㚆"),l11lll_l1_ (u"ࠨࠩ㚇"))
	#l1l11l111ll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㚈"),l11lll_l1_ (u"ࠪࠫ㚉"),l11lll_l1_ (u"ࠫࠬ㚊"),l1l11l111ll_l1_)
	#new = l11lll_l1_ (u"ࠬ࠭㚋")
	#for i in range(len(l1l11l111ll_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㚌"),l11lll_l1_ (u"ࠧࠨ㚍"),l11lll_l1_ (u"ࠨࠩ㚎"),str(i))
	#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1] + l1l11l111ll_l1_[i+2] + l1l11l111ll_l1_[i+3] + l1l11l111ll_l1_[i+4] + l1l11l111ll_l1_[i+5]
	#l1l11l111ll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㚏"),l11lll_l1_ (u"ࠪࠫ㚐"),l11lll_l1_ (u"ࠫࠬ㚑"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㚒"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㚓"),l11lll_l1_ (u"ࠧࠨ㚔"),l11lll_l1_ (u"ࠨࠩ㚕"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚖"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㚗"),l11lll_l1_ (u"ࠫࠬ㚘"),l11lll_l1_ (u"ࠬ࠭㚙"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l11lll_l1_ (u"࠭ࡥ࡮ࡣࡧࠫ㚚")
	#l1l111llll1_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡉ࡯ࡲࡸࡸ࠳࡙ࡥ࡯ࡦࡗࡩࡽࡺࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠭㚛")+l1l11l111ll_l1_+l11lll_l1_ (u"ࠨࠤ࠯ࠦࡩࡵ࡮ࡦࠤ࠽ࡪࡦࡲࡳࡦࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫ㚜"))
	#simplejson.loads(l1l111llll1_l1_)
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚝"))
	#new = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㚞"))
	#l1l11l111ll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㚟"),l11lll_l1_ (u"ࠬ࠭㚠"),l11lll_l1_ (u"࠭ࠧ㚡"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l111lllll_l1_(l1l11l111ll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㚢"),l11lll_l1_ (u"ࠨࠩ㚣"),l11lll_l1_ (u"ࠩࠪ㚤"),l1l11l111ll_l1_)
	#new = l11lll_l1_ (u"ࠪࠫ㚥")
	#for i in range(len(l1l11l111ll_l1_)-2,-1,-2):
	#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1]
	#l1l11l111ll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㚦"),l11lll_l1_ (u"ࠬ࠭㚧"),l11lll_l1_ (u"࠭ࠧ㚨"),l1l11l111ll_l1_)
	#l1l11l111ll_l1_ = l1l11l111ll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚩"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㚪"),l11lll_l1_ (u"ࠩࠪ㚫"),l11lll_l1_ (u"ࠪࠫ㚬"),l1l11l111ll_l1_)
	#new = l11lll_l1_ (u"ࠫࠬ㚭")
	#for i in range(len(l1l11l111ll_l1_)-2,-1,-2):
	#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1]
	#l1l11l111ll_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㚮"),l11lll_l1_ (u"࠭ࠧ㚯"),l11lll_l1_ (u"ࠧࠨ㚰"),l1l11l111ll_l1_)
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.replace(l11lll_l1_ (u"ࠨࠢࠪ㚱"),l11lll_l1_ (u"ࠩࠪ㚲"))
		#new = l11lll_l1_ (u"ࠪࠫ㚳")
		#for i in range(len(l1l11l111ll_l1_)-3,-2,-3):
		#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1] + l1l11l111ll_l1_[i+2]
		#l1l11l111ll_l1_ = new
		#new = l11lll_l1_ (u"ࠫࠬ㚴")
		#for i in range(len(l1l11l111ll_l1_)-2,-1,-2):
		#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1]
		#l1l11l111ll_l1_ = new
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㚵"),l11lll_l1_ (u"࠭ࠧ㚶"),l11lll_l1_ (u"ࠧࠨ㚷"),l1l11l111ll_l1_)
		#l1l11l111ll_l1_ = l1l11l111ll_l1_.l1l11l11l11_l1_(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㚸"))
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㚹"),l11lll_l1_ (u"ࠪࠫ㚺"),str(ord(l1l11l111ll_l1_[0]))+l11lll_l1_ (u"ࠫࠥ࠭㚻")+str(ord(l1l11l111ll_l1_[1]))+l11lll_l1_ (u"ࠬࠦࠧ㚼")+str(ord(l1l11l111ll_l1_[2])),str(len(l1l11l111ll_l1_)))
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㚽"),l11lll_l1_ (u"ࠧࠨ㚾"),l11lll_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠡࡎࡨࡸࡹ࡫ࡲࡴࠩ㚿"),l1l11l111ll_l1_)
		#new = l11lll_l1_ (u"ࠩࠪ㛀")
		#for i in range(len(l1l11l111ll_l1_)-2,-1,-2):
		#	new += l1l11l111ll_l1_[i] + l1l11l111ll_l1_[i+1]
		#l1l11l111ll_l1_ = new
		#new = l1l11l111ll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛁"))
		#new = new.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㛂"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㛃"),l11lll_l1_ (u"࠭ࠧ㛄"),l11lll_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ㛅"),new )
		#l1l111ll11l_l1_ = l11lll_l1_ (u"ࠨࠩ㛆")
		#for l1l111lll1l_l1_ in new:
		#	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㛇"),l11lll_l1_ (u"ࠪࠫ㛈"),l11lll_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㛉"),unicodedata.decomposition(l1l111lll1l_l1_) )
		#	l1l111ll11l_l1_ += l11lll_l1_ (u"ࠬࡢࡵࠨ㛊") + hex(ord(l1l111lll1l_l1_)).replace(l11lll_l1_ (u"࠭ࡸࠨ㛋"),l11lll_l1_ (u"ࠧࠨ㛌"))
		#l1l111ll11l_l1_ = l1l111ll11l_l1_.decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㛍"))
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㛎"),l11lll_l1_ (u"ࠪࠫ㛏"),l11lll_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㛐"),l1l111ll11l_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l111lllll_l1_(new)
		#l1l11l111ll_l1_ = new.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㛑"))
		#new = new.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㛒")) #.decode(l11lll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㛓"))
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㛔"),l11lll_l1_ (u"ࠩࠪ㛕"),l11lll_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㛖"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㛗")))   )
		#l1l11l111ll_l1_ = l1l111lllll_l1_(new)
		#l1l11l111ll_l1_ = l1l111lllll_l1_(l1l11l111ll_l1_)
		#method=l11lll_l1_ (u"ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨ㛘")
		#params=l11lll_l1_ (u"࠭ࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠧࡶࠦ࠱ࠦࠢࡥࡱࡱࡩࠧࡀࡦࡢ࡮ࡶࡩࢂ࠭㛙") % l1l11l111ll_l1_
		#l1l111llll1_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠥࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠡࠤࠨࡷࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࠣࠩࡸ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ㛚") % (method, params))
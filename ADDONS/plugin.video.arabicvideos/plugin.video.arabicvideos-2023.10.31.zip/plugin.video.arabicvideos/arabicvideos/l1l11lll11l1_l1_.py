# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ旳")
#headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ旴"):l11lll_l1_ (u"ࠬ࠭旵")}
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ时")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧๆืสี฾ฯࠧ旷"),l11lll_l1_ (u"ࠨสฮࠤ๊ฮวีำࠪ旸")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l1111l_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llllll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭旹"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ旺"),l11lll_l1_ (u"ࠫࠬ旻"),l11lll_l1_ (u"ࠬ࠭旼"),l11lll_l1_ (u"࠭ࠧ旽"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ旾"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ旿"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠩ࠲ࠫ昀"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ昁"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昂"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ昃"),l1ll1l1_l1_,489,l11lll_l1_ (u"࠭ࠧ昄"),l11lll_l1_ (u"ࠧࠨ昅"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ昆"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ昇"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ昈"),l11lll_l1_ (u"ࠫࠬ昉"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ昊"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ昋")+l111ll_l1_+l11lll_l1_ (u"ࠧฤฯาฯࠥอไๆ๊สฺ๏฿ࠧ昌"),l1ll1l1_l1_,481)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࠧࡳࡹࡂࡥࡦࡳࡺࡴࡴࠣࠩ昍"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ明"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠪࠧࠬ昏"): continue
		if title in l1l1l1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ昐"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ昑")+l111ll_l1_+title,link,481)
	return html
def l1111l_l1_(url,l1lll1l111111_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ昒"),url,l11lll_l1_ (u"ࠧࠨ易"),l11lll_l1_ (u"ࠨࠩ昔"),l11lll_l1_ (u"ࠩࠪ昕"),l11lll_l1_ (u"ࠪࠫ昖"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ昗"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡰࡵࡷࠬ࠳࠰࠿ࠪࠤࡩࡳࡴࡺࡥࡳࠤࠪ昘"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ昙"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ昚"),l11lll_l1_ (u"ࠨใํ่๊࠭昛"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ昜"),l11lll_l1_ (u"ࠪว฿์๊สࠩ昝"),l11lll_l1_ (u"่๊๊ࠫษࠩ昞"),l11lll_l1_ (u"ࠬอูๅษ้ࠫ星"),l11lll_l1_ (u"࠭็ะษไࠫ映"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧ昡"),l11lll_l1_ (u"ࠨ฻ิฺࠬ昢"),l11lll_l1_ (u"่๋ࠩึาว็ࠩ昣"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩ昤"),l11lll_l1_ (u"ู๊ࠫัฮ์ฬࠫ春")]
	l1lll1l11111l_l1_ = l11lll_l1_ (u"ࠬ࠵ࠧ昦").join(l1lll1l111111_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨ昧")).split(l11lll_l1_ (u"ࠧ࠰ࠩ昨"))[4:]).split(l11lll_l1_ (u"ࠨ࠯ࠪ昩"))
	for link,title,l1llll_l1_ in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ昪"),title,re.DOTALL)
		if l1lll1l111111_l1_:
			l1lllllll1_l1_ = l11lll_l1_ (u"ࠪ࠳ࠬ昫").join(link.strip(l11lll_l1_ (u"ࠫ࠴࠭昬")).split(l11lll_l1_ (u"ࠬ࠵ࠧ昭"))[4:]).split(l11lll_l1_ (u"࠭࠭ࠨ昮"))
			l1lll1l1111l1_l1_ = len([x for x in l1lll1l11111l_l1_ if x in l1lllllll1_l1_])
			if l1lll1l1111l1_l1_>2 and l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ是") in link:
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ昰"),l111ll_l1_+title,link,482,l1llll_l1_)
		else:
			if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ昱"),title,re.DOTALL)
			#if any(value in title for value in l1lll1_l1_):
			if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"ุ้๊ࠪำๅࠩ昲") not in title:
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ昳"),l111ll_l1_+title,link,482,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠬำไใหࠪ昴") in title:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ昵") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ昶"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ昷"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ昸"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"ࠪࠫ昹"),url)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ昺"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ昻"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"࠭วๅืไัฮࠦࠧ昼"),l11lll_l1_ (u"ࠧࠨ昽"))
			if title!=l11lll_l1_ (u"ࠨࠩ显"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ昿"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ晀")+title,link,481,l11lll_l1_ (u"ࠫࠬ晁"),l11lll_l1_ (u"ࠬ࠭時"),l1lll1l111111_l1_)
	return
def l1llllll_l1_(url,l11l11l_l1_):
	headers = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ晃"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ晄")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ晅"),url,l11lll_l1_ (u"ࠩࠪ晆"),headers,l11lll_l1_ (u"ࠪࠫ晇"),l11lll_l1_ (u"ࠫࠬ晈"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭晉"))
	html = response.content
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ晊"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ晋"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ晌"))
	l1lll11llllll_l1_ = True
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡰ࡮ࡹࡴࡔࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ晍"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ晎") not in url:
		block = l1l1l11_l1_[0]
		count = block.count(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠨ晏"))
		if count==0: count = block.count(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠫ晐"))
		if count>1:
			l1lll11llllll_l1_ = False
			if l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠫ晑") in block:
				items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ晒"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠵࠲ࡵ࡮ࡰࡀࡵ࡯ࡹ࡬ࡃࠧ晓")+id
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ晔"),l111ll_l1_+title,link,483,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭晕"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠴ࡰࡩࡲࡂࡷࡪࡸࡩࡦࡵࡌࡈࡂ࠭晖")+id
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ晗"),l111ll_l1_+title,link,483,l1llll_l1_)
	# l1l1l_l1_
	if l1lll11llllll_l1_:
		block = l11lll_l1_ (u"࠭ࠧ晘")
		if l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ晙") in url: block = html
		else:
			l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡨࡴࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭晚"),html,re.DOTALL)
			if l1l11ll_l1_: block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ晛"),block,re.DOTALL)
		if items:
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ晜"))
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ晝"),l111ll_l1_+title,link,482,l1llll_l1_)
	if not menuItemsLIST: l1111l_l1_(l11l11l_l1_,url)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠬ࠵ࠧ晞"))+l11lll_l1_ (u"࠭࠯ࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ晟")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ晠"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ晡"),l11lll_l1_ (u"ࠩࠪ晢"),l11lll_l1_ (u"ࠪࠫ晣"),l11lll_l1_ (u"ࠫࠬ晤"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ晥"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ晦"))
	l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡱࡢࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭晧"),html,re.DOTALL)
	if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ晨"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ晩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ晪"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭晫"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡩࡧࡴࡤࡱࡪ࠸࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ晬")+l1ll1llll1_l1_+l11lll_l1_ (u"࠭ࠦࡷ࡫ࡧࡩࡴࡃࠧ晭")+l1lll111l1_l1_[2:]+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ普")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ景")
			l1111_l1_.append(link)
	# l1l11llll_l1_ l11ll1l1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠩࠥ࡫ࡪࡺࡅ࡮ࡤࡨࡨࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭晰"),html,re.DOTALL)
	if link:
		title = SERVER(link[0],l11lll_l1_ (u"ࠪࡹࡷࡲࠧ晱"))
		link = link[0]+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ晲")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭晳")
		l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"࠭࠯ࠨ晴"))+l11lll_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ晵")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ晶"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ晷"),l11lll_l1_ (u"ࠪࠫ晸"),l11lll_l1_ (u"ࠫࠬ晹"),l11lll_l1_ (u"ࠬ࠭智"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ晻"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡶࡤࡦࡱ࡫࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ晼"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ晽"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ晾"))
			if l11lll_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ晿") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠫࡤࡥฮศืࠪ暀")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠬ࠭暁")
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ暂")+title+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ暃")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭暄"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ暅"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠪࠫ暆")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ暇"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭暈"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ暉"),l11lll_l1_ (u"ࠧࠬࠩ暊"))
	if l1ll1l1_l1_==l11lll_l1_ (u"ࠨࠩ暋"): l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ暌")+search+l11lll_l1_ (u"ࠪ࠳ࠬ暍")
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࠬ暎"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ䳚")
headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䳛"):l11lll_l1_ (u"࠭ࠧ䳜")}
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭䳝")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ䳞"),l11lll_l1_ (u"ࠩࡺࡻࡪ࠭䳟")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1111l_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llllll_l1_(url,text)
	elif mode==364: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ䳠")+text)
	elif mode==365: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ䳡")+text)
	elif mode==366: results = l1l11l_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䳢"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ䳣"),l11lll_l1_ (u"ࠧࠨ䳤"),False,l11lll_l1_ (u"ࠨࠩ䳥"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䳦"))
	#hostname = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䳧")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠫ࠴࠭䳨"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䳩")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䳪"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䳫"),l11lll_l1_ (u"ࠨࠩ䳬"),l11lll_l1_ (u"ࠩࠪ䳭"),l11lll_l1_ (u"ࠪࠫ䳮"),l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䳯"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䳰"),l111ll_l1_+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้ำหࠥอไๆ๊ๅ฽ฺ๋ࠥๅไ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䳱"),l11lll_l1_ (u"ࠧࠨ䳲"),8)
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䳳"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䳴"),l11lll_l1_ (u"ࠪࠫ䳵"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳶"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䳷"),l11ll1_l1_,369,l11lll_l1_ (u"࠭ࠧ䳸"),l11lll_l1_ (u"ࠧࠨ䳹"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䳺"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳻"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭䳼"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䳽"),364)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳾"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䳿"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䴀"),365)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䴁"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䴂"),l11lll_l1_ (u"ࠪࠫ䴃"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䴄"):hostname,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䴅"):l11lll_l1_ (u"࠭ࠧ䴆")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"ࠧ࡝࠱ࠪ䴇"),l11lll_l1_ (u"ࠨ࠱ࠪ䴈"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࡣࡣࡵࠬ࠳࠰࠿ࠪࡨ࡬ࡰࡹ࡫ࡲࠨ䴉"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴊"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠫࠪࡪ࠹ࠦ࠺࠸ࠩࡩ࠾ࠥࡣ࠷ࠨࡨ࠽ࠫࡡ࠸ࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡧ࠿ࠥࡥ࠺ࠨࡥ࠾࠳ࠥࡥ࠺ࠨࡥࡩࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡣ࠼ࠫ䴋") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴌"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䴍")+l111ll_l1_+title,link,366)
	#	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䴎"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䴏"),l11lll_l1_ (u"ࠩࠪ䴐"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䴑"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ䴒"),l11lll_l1_ (u"ࠬ࠭䴓"),l11lll_l1_ (u"࠭ࠧ䴔"),l11lll_l1_ (u"ࠧࠨ䴕"),l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ䴖"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡒࡵࡳࡩࡻࡣࡵ࡫ࡲࡲࡸࡒࡩࡴࡶࡅࡹࡹࡺ࡯࡯ࠤࠪ䴗"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䴘"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䴙") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䴚"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"࠭ࠧ䴛"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴜"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䴝")+l111ll_l1_+title,link,366)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䴞"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䴟"),l11lll_l1_ (u"ࠫࠬ䴠"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠧ䴡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䴢"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴣"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䴤")+l111ll_l1_+title,link,366,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䴥"),l11lll_l1_ (u"ࠪࠫ䴦"),url,l11lll_l1_ (u"ࠫࠬ䴧"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䴨"):url,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䴩"):l11lll_l1_ (u"ࠧࠨ䴪")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䴫"),url,l11lll_l1_ (u"ࠩࠪ䴬"),l11lll_l1_ (u"ࠪࠫ䴭"),l11lll_l1_ (u"ࠫࠬ䴮"),l11lll_l1_ (u"ࠬ࠭䴯"),l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䴰"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䴱"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ䴲"),url,364)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䴳"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭䴴"),url,365)
	if l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ䴵") in html:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴶"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ䴷"),url,361,l11lll_l1_ (u"ࠧࠨ䴸"),l11lll_l1_ (u"ࠨࠩ䴹"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䴺"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䴻"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䴼"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴽"),l111ll_l1_+title,link,361)
	return
def l1111l_l1_(l1ll11l11lll_l1_,type=l11lll_l1_ (u"࠭ࠧ䴾")):
	if l11lll_l1_ (u"ࠧ࠻࠼ࠪ䴿") in l1ll11l11lll_l1_:
		l11l1l1_l1_,url = l1ll11l11lll_l1_.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ䵀"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭䵁"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l11lll_l1_,l1ll11l11lll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䵂"):l11l1l1_l1_,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䵃"):l11lll_l1_ (u"ࠬ࠭䵄")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䵅"),url,l11lll_l1_ (u"ࠧࠨ䵆"),l11lll_l1_ (u"ࠨࠩ䵇"),l11lll_l1_ (u"ࠩࠪ䵈"),l11lll_l1_ (u"ࠪࠫ䵉"),l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䵊"))
	html = response.content
	if type==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䵋"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ䵌"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䵍"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠨ࡞࡟࠳ࠬ䵎"),l11lll_l1_ (u"ࠩ࠲ࠫ䵏")).replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ䵐"),l11lll_l1_ (u"ࠫࠧ࠭䵑"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡍࡲࡪࡦ࠰࠱ࡒࡿࡣࡪ࡯ࡤࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䵒"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡇࡳ࡫ࡧࡍࡹ࡫࡭ࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ䵓"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䵔"),l11lll_l1_ (u"ࠨࠩ䵕"))
			if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䵖") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵗"),l111ll_l1_+title,link,363,l1llll_l1_)
			elif l11lll_l1_ (u"ࠫา๊โสࠩ䵘") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠰ำไใหࠣ࠯ࡡࡪࠫࠨ䵙"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䵚") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䵛"),l111ll_l1_+title,link,363,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䵜"),l111ll_l1_+title,link,362,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䵝"):
			l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ䵞"),block,re.DOTALL)
			if l1lll11ll1l_l1_:
				count = l1lll11ll1l_l1_[0]
				link = url+l11lll_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭䵟")+count
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䵠"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ䵡"),link,361,l11lll_l1_ (u"ࠧࠨ䵢"),l11lll_l1_ (u"ࠨࠩ䵣"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䵤"))
		elif type==l11lll_l1_ (u"ࠪࠫ䵥"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䵦"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䵧"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"࠭ีโฯฬࠤࠬ䵨")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䵩"),l111ll_l1_+title,link,361)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠨࠩ䵪")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䵫"),url,l11lll_l1_ (u"ࠪࠫ䵬"),l11lll_l1_ (u"ࠫࠬ䵭"),l11lll_l1_ (u"ࠬ࠭䵮"),l11lll_l1_ (u"࠭ࠧ䵯"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䵰"))
	html = response.content
	html = l111l_l1_(html)
	name = re.findall(l11lll_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭䵱"),html,re.DOTALL)
	if name: name = name[-1].replace(l11lll_l1_ (u"ࠩ࠰ࠫ䵲"),l11lll_l1_ (u"ࠪࠤࠬ䵳")).strip(l11lll_l1_ (u"ࠫ࠴࠭䵴"))
	if l11lll_l1_ (u"๋่ࠬิ็ࠪ䵵") in name and type==l11lll_l1_ (u"࠭ࠧ䵶"):
		name = name.split(l11lll_l1_ (u"ࠧๆ๊ึ้ࠬ䵷"))[0]
		name = name.replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠨ䵸"),l11lll_l1_ (u"ࠩࠪ䵹")).strip(l11lll_l1_ (u"ࠪࠤࠬ䵺"))
	elif l11lll_l1_ (u"ࠫา๊โสࠩ䵻") in name:
		name = name.split(l11lll_l1_ (u"ࠬำไใหࠪ䵼"))[0]
		name = name.replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮ࠭䵽"),l11lll_l1_ (u"ࠧࠨ䵾")).strip(l11lll_l1_ (u"ࠨࠢࠪ䵿"))
	else: name = name
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳ࠭䶀"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if type==l11lll_l1_ (u"ࠪࠫ䶁"):
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䶂"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࠫ䶃") in title: continue
				if l11lll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ䶄") in title: continue
				title = name+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ䶅")+title
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶆"),l111ll_l1_+title,link,363,l11lll_l1_ (u"ࠩࠪ䶇"),l11lll_l1_ (u"ࠪࠫ䶈"),l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䶉"))
		if len(menuItemsLIST)==0:
			l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠪࠫ࠭䶊"),block+l11lll_l1_ (u"࠭ࠦࠧࠩ䶋"),re.DOTALL)
			if l11l1_l1_: block = l11l1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䶌"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ䶍"))
				title = name+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭䶎")+title
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䶏"),l111ll_l1_+title,link,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11lll_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶐"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠬࠦ࠭ࠡ็ส๎ู๊ࠥๆษࠪ䶑"),l11lll_l1_ (u"࠭ࠧ䶒")).replace(l11lll_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䶓"),l11lll_l1_ (u"ࠨࠩ䶔"))
		else: title = l11lll_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ䶕")
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䶖"),l111ll_l1_+title,url,362)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䶗"),url,l11lll_l1_ (u"ࠬ࠭䶘"),l11lll_l1_ (u"࠭ࠧ䶙"),l11lll_l1_ (u"ࠧࠨ䶚"),l11lll_l1_ (u"ࠨࠩ䶛"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䶜"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀส่ฯ฻ๆ๋ใ࠿࠲࠯ࡅ࠼ࡢ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶝"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡉࡲࡨࡥࡥࠤࠪ䶞"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶟"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ䶠") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"ࠧิ์ิๅึࠦๅศ์ࠣื๏๋วࠨ䶡"): name = l11lll_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䶢")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䶣")+name+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䶤")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯ࡳࡵ࠯࠰ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䶥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶦"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ䶧") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ䶨"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠨࡡࡢࡣࡤ࠭䶩")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠩࠪ䶪")
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡱࡾࡩࡩ࡮ࡣࠪ䶫")+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䶬")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䶭"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䶮"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"ࠧࠨ䶯")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩ䶰"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪ䶱"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ䶲"),l11lll_l1_ (u"ࠫ࠰࠭䶳"))
	l1111_l1_ = [l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ䶴"),l11lll_l1_ (u"࠭࠯ࠨ䶵"),l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡳࡦࡴ࡬ࡩࡸ࠭䶶"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡢࡰ࡬ࡱࡪ࠭䶷"),l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡶࡹࠫ䶸")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"ࠪห้้ไࠨ䶹"),l11lll_l1_ (u"ࠫฬ๊รโๆส้ࠬ䶺"),l11lll_l1_ (u"ࠬอไๆี็ื้อสࠨ䶻"),l11lll_l1_ (u"࠭วๅษ้๎๊๐้ࠠࠢส่่ืส้่ࠪ䶼"),l11lll_l1_ (u"ࠧศๆหีฬ๋ฬࠡฬ็๎ๆุ๊้่ํอࠬ䶽")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ䶾"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11lll_l1_ (u"ࠩࠪ䶿"):
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䷀"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ䷁"),l11lll_l1_ (u"ࠬ࠭䷂"),False,l11lll_l1_ (u"࠭ࠧ䷃"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䷄"))
		hostname = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䷅")]
		hostname = hostname.strip(l11lll_l1_ (u"ࠩ࠲ࠫ䷆"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ䷇")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l11lll_l1_,filter):
	if l11lll_l1_ (u"ࠫࡄࡅࠧ䷈") in l1ll11l11lll_l1_: url = l1ll11l11lll_l1_.split(l11lll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䷉"))[0]
	else: url = l1ll11l11lll_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䷊"):l1ll11l11lll_l1_,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䷋"):l11lll_l1_ (u"ࠨࠩ䷌")}
	filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䷍"),l11lll_l1_ (u"ࠪࠫ䷎"))
	type,filter = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ䷏"),1)
	if filter==l11lll_l1_ (u"ࠬ࠭䷐"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"࠭ࠧ䷑"),l11lll_l1_ (u"ࠧࠨ䷒")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬ䷓"))
	if type==l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䷔"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"ࠪࡁࡂ࠭䷕") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"ࠫࡂࡃࠧ䷖") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ䷗")+category+l11lll_l1_ (u"࠭࠽࠾࠲ࠪ䷘")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ䷙")+category+l11lll_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䷚")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ䷛"))+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ䷜")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠫࠫࠬࠧ䷝"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䷞"))
		l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䷟")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䷠"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䷡"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠩࠪ䷢"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䷣"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠫࠬ䷤"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䷥")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll11l11lll_l1_)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷦"),l111ll_l1_+l11lll_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ䷧"),l1111111_l1_,361,l11lll_l1_ (u"ࠨࠩ䷨"),l11lll_l1_ (u"ࠩࠪ䷩"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䷪"))
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷫"),l111ll_l1_+l11lll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ䷬")+l11lll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ䷭"),l1111111_l1_,361,l11lll_l1_ (u"ࠧࠨ䷮"),l11lll_l1_ (u"ࠨࠩ䷯"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䷰"))
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䷱"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䷲"),l11lll_l1_ (u"ࠬ࠭䷳"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䷴"),url,l11lll_l1_ (u"ࠧࠨ䷵"),l11lll_l1_ (u"ࠨࠩ䷶"),l11lll_l1_ (u"ࠩࠪ䷷"),l11lll_l1_ (u"ࠪࠫ䷸"),l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䷹"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠣࠩ䷺"),l11lll_l1_ (u"࠭ࠢࠨ䷻")).replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ䷼"),l11lll_l1_ (u"ࠨ࠱ࠪ䷽"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ䷾"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䷿"),block+l11lll_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ一"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ丁") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ丂"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠧ࠾࠿ࠪ七") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ丄"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ丅")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll11l11lll_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丆"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ万"),l1111111_l1_,361,l11lll_l1_ (u"ࠬ࠭丈"),l11lll_l1_ (u"࠭ࠧ三"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ上"))
				else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ下"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩ丌"),l11l11l_l1_,364,l11lll_l1_ (u"ࠪࠫ不"),l11lll_l1_ (u"ࠫࠬ与"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭丏"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ丐")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ丑")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ丒")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࡁ࠵࠭专")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ且")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ丕"),l111ll_l1_+name+l11lll_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ世"),l11l11l_l1_,365,l11lll_l1_ (u"࠭ࠧ丗"),l11lll_l1_ (u"ࠧࠨ丘"),l1l1l11l_l1_+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ丙"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠩࡵࠫ业") or value==l11lll_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ丛"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ东") in option: continue
			if l11lll_l1_ (u"ࠬอไไๆࠪ丝") in option: continue
			if l11lll_l1_ (u"࠭࡮࠮ࡣࠪ丞") in value: continue
			#if value in [l11lll_l1_ (u"ࠧࡳࠩ丟"),l11lll_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ丠"),l11lll_l1_ (u"ࠩࡷࡺ࠲ࡳࡡࠨ両")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ丢"): option = value
			if option==l11lll_l1_ (u"ࠫࠬ丣"): option = value
			l11ll1l11_l1_ = option
			l1l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ两"),option,re.DOTALL)
			if l1l11ll11ll_l1_: l11ll1l11_l1_ = l1l11ll11ll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"࠭࠺ࠡࠩ严")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ並")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫ丧")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ丨")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࡂ࠭丩")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ个")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭丫"):
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭丬"),l111ll_l1_+l1lll1lll_l1_,url,365,l11lll_l1_ (u"ࠧࠨ中"),l11lll_l1_ (u"ࠨࠩ丮"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ丯"))
			elif type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ丰") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"ࠫࡂࡃࠧ丱") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ串"))
				#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ丳"),l11lll_l1_ (u"ࠧࠨ临"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ丵")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_,l1ll11l11lll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ丶"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,361,l11lll_l1_ (u"ࠪࠫ丷"),l11lll_l1_ (u"ࠫࠬ丸"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭丹"))
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭为"),l111ll_l1_+l1lll1lll_l1_,url,364,l11lll_l1_ (u"ࠧࠨ主"),l11lll_l1_ (u"ࠨࠩ丼"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ丽"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ举"),l11lll_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ丿")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠬࡳࡰࡢࡣࠪ乀"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ乁"),l11lll_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭乂"),l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ乃"),l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ乄"),l11lll_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ久"),l11lll_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ乆"),l11lll_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ乇")]
def l11llllll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭么") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ义"),l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ乊"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ之"),l11lll_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ乌"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫࡂࡃࠧ乍"),l11lll_l1_ (u"ࠬ࠵ࠧ乎"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭ࠦࠧࠩ乏"),l11lll_l1_ (u"ࠧ࠰ࠩ乐"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ乑"),l11lll_l1_ (u"ࠩࠪ乒"),filters,l11lll_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ乓")+mode)
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭乔")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ乕")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪ乖")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ乗"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠨࠩ乘")
	if l11lll_l1_ (u"ࠩࡀࡁࠬ乙") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠫ࠭乚"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂࡃࠧ乛"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠬ࠶ࠧ乜")
		if l11lll_l1_ (u"࠭ࠥࠨ九") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ乞") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ也"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭习")+value
		elif mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭乡") and value!=l11lll_l1_ (u"ࠫ࠵࠭乢"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ乣")+key+l11lll_l1_ (u"࠭࠽࠾ࠩ乤")+value
		elif mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ乥"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ书")+key+l11lll_l1_ (u"ࠩࡀࡁࠬ乧")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ乨"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠫࠬࠧ乩"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭乪"),l11lll_l1_ (u"࠭ࠧ乫"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠧࡐࡗࡗࠫ乬"))
	return l1ll1l1l_l1_
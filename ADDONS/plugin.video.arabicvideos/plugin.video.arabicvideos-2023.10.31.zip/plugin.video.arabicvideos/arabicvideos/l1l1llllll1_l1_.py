# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫⴘ")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨⴙ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ะี็์ไหฯ࠭ⴚ"),l11lll_l1_ (u"ࠫฬ์ิศรࠣัุอศࠨⴛ"),l11lll_l1_ (u"ࠬ฽ไษษอࠤฬ๊า้๓สีࠬⴜ")]
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪⴝ"):l11lll_l1_ (u"ࠧࠨⴞ")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l1111l_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llllll_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴟ"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩⴠ"),l11lll_l1_ (u"ࠪࠫⴡ"),399,l11lll_l1_ (u"ࠫࠬⴢ"),l11lll_l1_ (u"ࠬ࠭ⴣ"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪⴤ"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⴥ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⴦"),l11lll_l1_ (u"ࠩࠪⴧ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⴨"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ⴩"),l11lll_l1_ (u"ࠬ࠭⴪"),l11lll_l1_ (u"࠭ࠧ⴫"),l11lll_l1_ (u"ࠧࠨ⴬"),l11lll_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ⴭ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⴮"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴯"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ⴰ")+l111ll_l1_+title,l11ll1_l1_,391,l11lll_l1_ (u"ࠬ࠭ⴱ"),l11lll_l1_ (u"࠭ࠧⴲ"),l11lll_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧⴳ")+str(seq))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴴ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⴵ")+l111ll_l1_+l11lll_l1_ (u"้ࠪำะวาษอࠤ฾ฺ่ศศํอࠬⴶ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠫࠬⴷ"),l11lll_l1_ (u"ࠬ࠭ⴸ"),l11lll_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧⴹ"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴺ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⴻ")+l111ll_l1_+l11lll_l1_ (u"ࠩฦ฽้๏ࠠศๆฦๅ้อๅࠡฬๅ๎๏๋ว์ࠩⴼ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠪࠫⴽ"),l11lll_l1_ (u"ࠫࠬⴾ"),l11lll_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟࡮ࡱࡹ࡭ࡪࡹࠧⴿ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵀ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⵁ")+l111ll_l1_+l11lll_l1_ (u"ࠨล฼่๎ࠦวๅ็ึุ่๊วหࠢอๆ๏๐ๅศํࠪⵂ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠩࠪⵃ"),l11lll_l1_ (u"ࠪࠫⵄ"),l11lll_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥࡳࡦࡴ࡬ࡩࡸ࠭ⵅ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵆ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⵇ")+l111ll_l1_+l11lll_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬⵈ"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩⵉ"),391,l11lll_l1_ (u"ࠩࠪⵊ"),l11lll_l1_ (u"ࠪࠫⵋ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ⵌ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵍ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⵎ")+l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧⵏ"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵࠪⵐ"),391,l11lll_l1_ (u"ࠩࠪⵑ"),l11lll_l1_ (u"ࠪࠫⵒ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡴࡷࡵ࡫ࡳࡼࡹࠧⵓ"))
	block = l11lll_l1_ (u"ࠬ࠭ⵔ")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫⵕ"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫⵖ"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩⵗ"),l11lll_l1_ (u"ࠩࠪⵘ"),l11lll_l1_ (u"ࠪࠫⵙ"),l11lll_l1_ (u"ࠫࠬⵚ"),l11lll_l1_ (u"ࠬ࠭ⵛ"),l11lll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫⵜ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧ࡯ࡩࡦࡹࡥࡴࠤࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭ⵝ"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⵞ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⵟ"),l11lll_l1_ (u"ࠪࠫⵠ"),9999)
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⵡ"),block,re.DOTALL)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬⵢ"):
			if first:
				title = l11lll_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨⵣ")+title
				first = False
			else: title = l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫⵤ")+title
		if title not in l1l1l1_l1_:
			if title==l11lll_l1_ (u"ࠨลไ่ฬ๋ࠧⵥ"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵦ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⵧ")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⵨"),391,l11lll_l1_ (u"ࠬ࠭⵩"),l11lll_l1_ (u"࠭ࠧ⵪"),l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⵫"))
			elif title==l11lll_l1_ (u"ࠨ็ึุ่๊วหࠩ⵬"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵭"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⵮")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭ⵯ"),391,l11lll_l1_ (u"ࠬ࠭⵰"),l11lll_l1_ (u"࠭ࠧ⵱"),l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⵲"))
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵳"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⵴")+l111ll_l1_+title,link,391)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⵵"),l11lll_l1_ (u"ࠫࠬ⵶"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⵷"),url,l11lll_l1_ (u"࠭ࠧ⵸"),l11lll_l1_ (u"ࠧࠨ⵹"),l11lll_l1_ (u"ࠨࠩ⵺"),l11lll_l1_ (u"ࠩࠪ⵻"),l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⵼"))
	html = response.content
	if type in [l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⵽"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⵾")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡧࡴࡴࡴࡦࡰࡷ⵿ࠦࠬ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨⶀ"),l11lll_l1_ (u"ࠨࠩⶁ"),url,block)
	elif type==l11lll_l1_ (u"ࠩࡤࡰࡱࡥ࡭ࡰࡸ࡬ࡩࡸࡥࡴࡷࡵ࡫ࡳࡼࡹࠧⶂ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬⶃ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif type==l11lll_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ⶄ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡺ࡯ࡱ࠯࡬ࡱࡩࡨ࠭࡭࡫ࡶࡸࠥࡺ࡬ࡦࡨࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠣⶅ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧⶆ"),l11lll_l1_ (u"ࠧࠨⶇ"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦⶈ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫⶉ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡷ࡯ࡧࡩࡶࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸࠢⶊ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠫࠬⶋ"),l11lll_l1_ (u"ࠬ࠭ⶌ"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤⶍ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧⶎ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡷࡩࡨ࠮ࡲࡤ࡫ࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬⶏ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⶐ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩⶑ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠨⶒ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶓ"),block,re.DOTALL)
		l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_ = zip(*l111l1_l1_)
		items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧⶔ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࡶ࠱ࡹࡼࡳࡩࡱࡺࡷࠧ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࡂࠬⶕ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶖ"),block,re.DOTALL)
	elif l11lll_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⶗") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⶘"),l11lll_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡷࡹࡧࡲࡵࡀࠪ⶙"))
		html = html.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⶚"),l11lll_l1_ (u"࠭࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀࡪࡴࡤ࠿ࠩ⶛"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡷࡥࡷࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡯ࡦࡁࠫ⶜"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==6:
			l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⶝"),block,re.DOTALL)
			l1l11ll11_l1_,l1lll1ll_l1_,l1111_l1_ = zip(*l111l1_l1_)
			items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࢂࡳࡪࡦࡨࡦࡦࡸࠩࠨ⶞"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⶟") in url:
				items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶠ"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠬ࠵ࡱࡶࡣ࡯࡭ࡹࡿ࠯ࠨⶡ") in url:
				items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⶢ"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩⶣ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠨࡵࡵࡧࡂ࠭ⶤ") in title: continue
		if l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࠨⶥ") in title:
			title = re.findall(l11lll_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⶦ"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ⶧")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫⶨ")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂࠧⶩ"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪⶪ") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶫ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ⶬ") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶭ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧⶮ") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⶯"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬⶰ") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶱ"),l111ll_l1_+title,link,391,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⶲ"),l111ll_l1_+title,link,392,l1llll_l1_)
	if type not in [l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫⶳ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭ⶴ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧⶵ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶶ"),block,re.DOTALL)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⶷"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ⶸ")+title,link,391,l11lll_l1_ (u"ࠨࠩⶹ"),l11lll_l1_ (u"ࠩࠪⶺ"),type)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫⶻ"),l11lll_l1_ (u"ࠫࠬⶼ"),l11lll_l1_ (u"ࠬ࠭ⶽ"),url)
	server = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪⶾ"))
	url = url.replace(server,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⶿"),url,l11lll_l1_ (u"ࠨࠩⷀ"),l11lll_l1_ (u"ࠩࠪⷁ"),l11lll_l1_ (u"ࠪࠫⷂ"),l11lll_l1_ (u"ࠫࠬⷃ"),l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧⷄ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫⷅ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩⷆ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⷇"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⷈ"),l111ll_l1_+title,link,392,l1llll_l1_)
	return
def PLAY(url):
	html = l1ll1l11l1_l1_(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧⷉ"),url,l11lll_l1_ (u"ࠫࠬⷊ"),l11lll_l1_ (u"ࠬ࠭ⷋ"),l11lll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫⷌ"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫⷍ"),url,l11lll_l1_ (u"ࠨࠩⷎ"),l11lll_l1_ (u"ࠩࠪ⷏"),l11lll_l1_ (u"ࠪࠫⷐ"),l11lll_l1_ (u"ࠫࠬⷑ"),l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪⷒ"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫⷓ"),l11lll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧⷔ"))
		except: pass
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⷕ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࡡࠢࡽ࡞ࠪࡡ࠭ࡹࡨࡦࡣࡧࡩࡷࢂࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠮ࡡࠢࡽ࡞ࠪࡡࠬⷖ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡶ࡯ࡴࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡹࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪ࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⷗"),block,re.DOTALL)
		for type,post,l1l1lllllll_l1_,title in items:
			#link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡹ࠱ࡥࡱ࡬ࡡ࡫ࡧࡵࡸࡻ࠴ࡣࡰ࡯࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵ࠭ⷘ")
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡧࡳࡴࡥࡰ࡭ࡣࡼࡩࡷࡥࡡ࡫ࡣࡻࠪࡵࡵࡳࡵ࠿ࠪⷙ")+post+l11lll_l1_ (u"࠭ࠦ࡯ࡷࡰࡩࡂ࠭ⷚ")+l1l1lllllll_l1_+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧⷛ")+type
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩⷜ")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪⷝ")
			l1111_l1_.append(link)
	# download links
	#WRITE_THIS(html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠫࠬ࡯ࡤ࠾࡝ࠥࠫࡢࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡛ࠣࠩࡠࠤࡨࡲࡡࡴࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃ࡛ࠣࠩࡠࡷࡧࡵࡸ࡜ࠤࠪࡡࠬ࠭ࠧⷞ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࠬ࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣ࠮ࠫࡁ࡞ࠦࠬࡣࡱࡶࡣ࡯࡭ࡹࡿ࡛ࠣࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ⷟"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ⷠ"),l11lll_l1_ (u"࠭ࠧⷡ"),str(items),str(block))
		for l1llll_l1_,link,l11l111l_l1_,l1ll1111111_l1_ in items:
			if l11lll_l1_ (u"ࠧ࠾ࠩⷢ") in l1llll_l1_:
				host = l1llll_l1_.split(l11lll_l1_ (u"ࠨ࠿ࠪⷣ"))[1]
				title = SERVER(host,l11lll_l1_ (u"ࠩ࡫ࡳࡸࡺࠧⷤ"))
			else: title = l11lll_l1_ (u"ࠪࠫⷥ")
			title = l1ll1111111_l1_+l11lll_l1_ (u"ࠫࠥ࠭ⷦ")+title
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ⷧ")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡤࡥࠧⷨ")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬⷩ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⷪ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪⷫ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫⷬ"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭ⷭ"),l11lll_l1_ (u"ࠬ࠱ࠧⷮ"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫⷯ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧⷰ"))
	return
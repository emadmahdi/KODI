# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ搇")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍ࡚࡟ࠨ搈")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ搉"),l11lll_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ搊"),l11lll_l1_ (u"ࠬษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠨ搋")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1111l_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11111_l1_(url,text)
	elif mode==644: results = l1l11l_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ搌"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ損"),l11lll_l1_ (u"ࠨࠩ搎"),l11lll_l1_ (u"ࠩࠪ搏"),l11lll_l1_ (u"ࠪࠫ搐"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭搑"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ搒"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭搓"),l11lll_l1_ (u"ࠧࠨ搔"),649,l11lll_l1_ (u"ࠨࠩ搕"),l11lll_l1_ (u"ࠩࠪ搖"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ搗"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ搘"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ搙"),l11lll_l1_ (u"࠭ࠧ搚"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ搛"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ搜")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ搝"),l11ll1_l1_,641,l11lll_l1_ (u"ࠪࠫ搞"),l11lll_l1_ (u"ࠫࠬ搟"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ搠"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭搡"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ搢")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅ็๋ๆ฾࠭搣"),l11ll1_l1_,641,l11lll_l1_ (u"ࠩࠪ搤"),l11lll_l1_ (u"ࠪࠫ搥"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ搦"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ搧"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭搨"),l11lll_l1_ (u"ࠧࠨ搩"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ搪"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ搫")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ搬"),l11ll1_l1_,641,l11lll_l1_ (u"ࠫࠬ搭"),l11lll_l1_ (u"ࠬ࠭搮"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ搯"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ搰"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ搱")+l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭搲"),l11ll1_l1_,641,l11lll_l1_ (u"ࠪࠫ搳"),l11lll_l1_ (u"ࠫࠬ搴"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ搵"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ搶"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ搷"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ搸"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ搹")+l111ll_l1_+title,link,644)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ携"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ搻"),l11lll_l1_ (u"ࠬ࠭搼"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ搽"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ搾"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠨࠩ搿"))
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ摀"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ摁"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭摂")+l111ll_l1_+title,link,644)
	return
def l1l11l_l1_(url):
	l111l1ll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ摃"),url,l11lll_l1_ (u"࠭ࠧ摄"),l11lll_l1_ (u"ࠧࠨ摅"),l11lll_l1_ (u"ࠨࠩ摆"),l11lll_l1_ (u"ࠩࠪ摇"),l11lll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ摈"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ摉"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭摊"),l11lll_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ摋"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ摌"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠨࠩ摍"),block)]
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ摎"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ摏"),l11lll_l1_ (u"ࠫࠬ摐"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			l111l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ摑"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"࠭࠺ࠡࠩ摒")
			for link,title in l111l1ll1_l1_:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ摓"),l111ll_l1_+title,link,641)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ摔"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ摕"),block,re.DOTALL)
		if len(l1l1lll_l1_)<30:
			if l111l1ll1_l1_: addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ摖"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ摗"),l11lll_l1_ (u"ࠬ࠭摘"),9999)
			for link,title in l1l1lll_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭摙"),l111ll_l1_+title,link,641)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠧࠨ摚")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ摛"),l11lll_l1_ (u"ࠩࠪ摜"),request,url)
	if request==l11lll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ摝"):
		url,search = url.split(l11lll_l1_ (u"ࠫࡄ࠭摞"),1)
		data = l11lll_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ摟")+search
		headers = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ摠"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ摡")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭摢"),url,data,headers,l11lll_l1_ (u"ࠩࠪ摣"),l11lll_l1_ (u"ࠪࠫ摤"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ摥"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ摦"),url,l11lll_l1_ (u"࠭ࠧ摧"),l11lll_l1_ (u"ࠧࠨ摨"),l11lll_l1_ (u"ࠨࠩ摩"),l11lll_l1_ (u"ࠩࠪ摪"),l11lll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ摫"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠫࠬ摬"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ摭"))
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ摮"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ摯"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠨࠩ摰"),link,title))
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ摱"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ摲"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ摳"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ摴"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ摵"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ摶"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ摷"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ摸"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ摹"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬ摺"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭摻"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ摼"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ摽"),l11lll_l1_ (u"ࠨใํ่๊࠭摾"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ摿"),l11lll_l1_ (u"ࠪ็้๐ศࠨ撀"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ撁"),l11lll_l1_ (u"ࠬํฯศใࠪ撂"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭撃"),l11lll_l1_ (u"ฺࠧำูࠫ撄"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ撅"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ撆"),l11lll_l1_ (u"ุ้ࠪือ๋หࠪ撇")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭撈"))
		#if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ撉") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ撊")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ撋"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭撌") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ撍")+l1llll_l1_.strip(l11lll_l1_ (u"ࠪ࠳ࠬ撎"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭撏"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ撐"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ撑"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭撒"):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ撓"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ撔") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撕"),l111ll_l1_+title,link,643,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ撖") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ撗"),l111ll_l1_+title,link,641,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭撘"),l111ll_l1_+title,link,643,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭撙"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ撚")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ撛"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ撜"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠫࠨ࠭撝"): continue
				if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ撞") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ撟")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ撠"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撡"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ撢")+title,link,641)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ撣"),l11lll_l1_ (u"ࠫࠬ撤"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ撥"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ撦"),url,l11lll_l1_ (u"ࠧࠨ撧"),l11lll_l1_ (u"ࠨࠩ撨"),l11lll_l1_ (u"ࠩࠪ撩"),l11lll_l1_ (u"ࠪࠫ撪"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ撫"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ撬"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ播"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠧࠨ撮")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ撯"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠩࠦࠫ撰"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撱"),l111ll_l1_+title,url,643,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ撲"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭撳")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ撴"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩ撵"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ撶"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ撷") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ撸")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭撹"))
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃࡂࡥ࡮ࡀࠪ撺"),l11lll_l1_ (u"࠭ࠠࠨ撻"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭撼"),l111ll_l1_+title,link,642,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ撽"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ撾") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ撿")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭擀"))
		#		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ擁"),l111ll_l1_+title,link,642,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ擂"),l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠴ࡰࡩࡲࠪ擃"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ擄"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ擅"),l11lll_l1_ (u"ࠪࠫ擆"),l11lll_l1_ (u"ࠫࠬ擇"),l11lll_l1_ (u"ࠬ࠭擈"),l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ擉"))
	html = response.content
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ擊"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭擋"),block,re.DOTALL)
		if links:
			link = links[0]
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ擌"))
				l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ操"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1111llll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ擎"),block,re.DOTALL)
		block = block.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠣࠩ擏"),l11lll_l1_ (u"࠭ࠢࠨ擐")).replace(l11lll_l1_ (u"ࠧ࡝࠱ࠪ擑"),l11lll_l1_ (u"ࠨ࠱ࠪ擒"))
		links = re.findall(l11lll_l1_ (u"ࠩࠥࡀ࡮࡬ࡲࡢ࡯ࡨ࠲ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ擓"),block,re.DOTALL)
		if len(l1111llll_l1_)==len(links):
			for id,title in l1111llll_l1_:
				link = links[int(id)]
				if link not in l1111_l1_:
					l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ擔")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ擕"))
					l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ擖"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ擗"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ擘")+title+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ擙"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ據"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ擛"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ擜"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭擝"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ擞"),l11lll_l1_ (u"ࠧࠬࠩ擟"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ擠")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ擡"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ擢")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ擣"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ⺳")
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⺴"):l11lll_l1_ (u"ࠨࠩ⺵")}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡊࡍ࠸࡟ࠨ⺶")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1l1lll11ll_l1_.faselhd.l1l1lll1l1l_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/faselhd.l1lll1111l_l1_
# l1llll1ll11_l1_	https://www.l1llll1ll11_l1_.com/faselhd
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1l1llll11l_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪࡻࡼ࡫ࠧ⺷")]
def MAIN(mode,url,text):
	if   mode==590: results = MENU()
	elif mode==591: results = l1111l_l1_(url,text)
	elif mode==592: results = PLAY(url)
	elif mode==593: results = l1lll1l1l1_l1_(url,text)
	#elif mode==594: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ⺸")+text)
	#elif mode==595: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ⺹")+text)
	elif mode==599: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ⺺"):l1ll1l1_l1_,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⺻"):l1l11l11l_l1_(False)}
	l1ll1l1_l1_ = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⺼"),l1ll1l1_l1_,l11lll_l1_ (u"ࠩࠪ⺽"),l11lll_l1_ (u"ࠪࠫ⺾"),l11lll_l1_ (u"ࠫࠬ⺿"),l11lll_l1_ (u"ࠬ࠭⻀"),l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⻁"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻂"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⻃"),l1ll1l1_l1_,599,l11lll_l1_ (u"ࠩࠪ⻄"),l11lll_l1_ (u"ࠪࠫ⻅"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⻆"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻇"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⻈"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ⻉"),594)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⻊"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⻋"),l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ⻌"),595)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⻍"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⻎"),l11lll_l1_ (u"࠭ࠧ⻏"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻐"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩ⻑"),l1ll1l1_l1_,591,l11lll_l1_ (u"ࠩࠪ⻒"),l11lll_l1_ (u"ࠪࠫ⻓"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⻔"))
	items = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⻕"),html,re.DOTALL)
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻖"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⻗")+l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠨࠩ⻘"),l11lll_l1_ (u"ࠩࠪ⻙"),l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠵ࠬ⻚"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⻛"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⻜"),l11lll_l1_ (u"࠭ࠧ⻝"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡪࡨࡥࡩ࡫ࡲ࠮ࡵࡲࡧ࡮ࡧ࡬ࠨ⻞"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1llll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾࡯࡭ࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⻟"),block,re.DOTALL)
		for menu in l1llll11l1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⻠"),menu,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⻡") not in link: link = l1ll1l1_l1_+link
				#if any(value in title.lower() for value in l1l1l1_l1_): continue
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻢"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⻣")+l111ll_l1_+title,link,591,l11lll_l1_ (u"࠭ࠧ⻤"),l11lll_l1_ (u"ࠧࠨ⻥"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠴ࠪ⻦"))
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪ⻧")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⻨"),l11lll_l1_ (u"ࠫࠬ⻩"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭⻪"):url,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⻫"):l1l11l11l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⻬"),url,l11lll_l1_ (u"ࠨࠩ⻭"),l11lll_l1_ (u"ࠩࠪ⻮"),l11lll_l1_ (u"ࠪࠫ⻯"),l11lll_l1_ (u"ࠫࠬ⻰"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⻱"))
	html = response.content
	l1l1lll1l11_l1_ = 0
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡵ࡯࡭ࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂࡨ࠵ࡀࠪ⻲"),html,re.DOTALL)
	if l1l11ll_l1_: l11l1_l1_ = l1l11ll_l1_[0]
	else: l11l1_l1_ = l11lll_l1_ (u"ࠧࠨ⻳")
	if type==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦ࠴ࠫ⻴"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡧࡦࡸ࡯ࡶࡵࡨࡰࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠿ࠩ⻵"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡹ࡬ࡪࡦࡨࡶ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⻶"),block,re.DOTALL)
		l1l1l1lll_l1_,l1l111_l1_,links = zip(*items)
		items = zip(links,l1l1l1lll_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠸ࠧ⻷"):
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⻸"),l11l1_l1_,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⻹"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ⻺"),l11lll_l1_ (u"ࠨ࠱ࠪ⻻")).replace(l11lll_l1_ (u"ࠩ࡟ࡠࠧ࠭⻼"),l11lll_l1_ (u"ࠪࠦࠬ⻽"))]
	elif type==l11lll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠷࠭⻾") and l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ⻿") in l11l1_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࡀࠪ⼀"),html,re.DOTALL)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼁"),l111ll_l1_+l11lll_l1_ (u"ࠨ็่๎ืฯࠧ⼂"),url,591,l11lll_l1_ (u"ࠩࠪ⼃"),l11lll_l1_ (u"ࠪࠫ⼄"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠸ࠧ⼅"))
		title = l1l1ll1_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼆"),l111ll_l1_+title,url,591,l11lll_l1_ (u"࠭ࠧ⼇"),l11lll_l1_ (u"ࠧࠨ⼈"),l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠵ࠪ⼉"))
		return
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡦࡳࡳࡺࡡࡪࡰࡨࡶࡃ࠭⼊"),html,re.DOTALL)
		title,block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⼋"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫ⼌"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ⼍"),l11lll_l1_ (u"࠭ว฻่ํอࠬ⼎"),l11lll_l1_ (u"ࠧไๆํฬࠬ⼏"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ⼐"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ⼑"),l11lll_l1_ (u"้ࠪออัศหࠪ⼒"),l11lll_l1_ (u"ࠫ฾ืึࠨ⼓"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ⼔"),l11lll_l1_ (u"࠭วๅส๋้ࠬ⼕"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧ⼖"),l11lll_l1_ (u"ࠨฯ็ๆฮ࠭⼗")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⼘"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭⼙"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⼚") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼛"),l111ll_l1_+title,link,591,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"࠭ࠧ⼜"):
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⼝")+l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼞"),l111ll_l1_+title,link,593,l1llll_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⼟"),l111ll_l1_+title,link,592,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼠"),l111ll_l1_+title,link,593,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⼡"):
		l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ⼢"),block,re.DOTALL)
		if l1lll11ll1l_l1_:
			count = l1lll11ll1l_l1_[0]
			link = url+l11lll_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ⼣")+count
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼤"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⼥"),link,591,l11lll_l1_ (u"ࠩࠪ⼦"),l11lll_l1_ (u"ࠪࠫ⼧"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⼨"))
	elif l11lll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭⼩") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⼪"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⼫"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"ࠨืไัฮࠦࠧ⼬")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼭"),l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠪࠫ⼮"),l11lll_l1_ (u"ࠫࠬ⼯"),l11lll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠺ࠧ⼰"))
	return
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"࠭ࠧ⼱")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⼲"),url,l11lll_l1_ (u"ࠨࠩ⼳"),l11lll_l1_ (u"ࠩࠪ⼴"),l11lll_l1_ (u"ࠪࠫ⼵"),l11lll_l1_ (u"ࠫࠬ⼶"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⼷"))
	html = response.content
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧࡤࡷࡴࡴࡳ࠿ࠩ⼸"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩ⼹"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⼺"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼻"),l111ll_l1_+title,link,593,l1llll_l1_,l11lll_l1_ (u"ࠪࠫ⼼"),l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⼽"))
	if type==l11lll_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⼾") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡣ࡭ี࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠥࡂࡁ࠵ࡢ࡬ࡀࠪ⼿"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"ࠧࠨ⽀")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡤࡰࡱ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢ࡮࡯࠱ࡪࡶࡩࡴࡱࡧࡩࡸࡄࠧ⽁"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⽂"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⽃"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⽄"),l111ll_l1_+title,link,592,l1llll_l1_)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1llll1ll_l1_,l1l1lllll1l_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⽅"),url,l11lll_l1_ (u"࠭ࠧ⽆"),l11lll_l1_ (u"ࠧࠨ⽇"),l11lll_l1_ (u"ࠨࠩ⽈"),l11lll_l1_ (u"ࠩࠪ⽉"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⽊"))
	html = response.content
	l1l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫฬู๊ๆำࠣ࠾࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ⽋"),html,re.DOTALL)
	if l1l1lll1lll_l1_ and l11ll11_l1_(script_name,url,l1l1lll1lll_l1_): return
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⽌"),html,re.DOTALL)
	if link:
		link = link[0]
		l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ⽍"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵ࡯࡭ࡨ࡫࠭ࡵ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⽎"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ⽏"),block,re.DOTALL)
		for link,name in items:
			name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ⽐"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⽑")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⽒"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡤࡰࡹࡱࡰࡴࡧࡤࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࡂࠬ⽓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⽔"),block,re.DOTALL)
		for link,name in items:
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⽕")+name+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⽖"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆ่๊ฬูศࠨ⽗"), l1lllll1_l1_)
	for l1l1llll1l1_l1_ in l1lllll1_l1_:
		link,name = l1l1llll1l1_l1_.split(l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࠪ⽘"))
		if link not in l1l1llll1ll_l1_:
			l1l1llll1ll_l1_.append(link)
			l1l1lllll1l_l1_.append(l1l1llll1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่๊์วิสࠪ⽙"), l1l1lllll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1lllll1l_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⽚"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ⽛"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ⽜"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ⽝"),l11lll_l1_ (u"ࠩ࠮ࠫ⽞"))
	#l1ll1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠲࠯ࡪࡲࡷࡹ࠭⽟"))
	#if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⽠")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠻ࠧ⽡"))
	return
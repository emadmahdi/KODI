# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㎪")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ㎫")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
l1l11lll1ll_l1_ = l1ll11l_l1_[script_name][2]
l1l11llll1l_l1_ = l1ll11l_l1_[script_name][3]
#l1l1l1111ll_l1_  = l1ll11l_l1_[script_name][4]
#l1l1l1111ll_l1_  = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==20: results = l1l11lllll1_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==23: results = l1llllll_l1_(url,l1l11l1_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l11ll11l1_l1_(url)
	elif mode==27: results = l1l1lll1l_l1_(url)
	elif mode==28: results = l1l1l11111l_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l11lllll1_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㎬"),l111ll_l1_+l11lll_l1_ (u"ู࠭าสํࠫ㎭"),l11ll1_l1_,21,l11lll_l1_ (u"ࠧࠨ㎮"),l11lll_l1_ (u"ࠨ࠳࠳࠵ࠬ㎯"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㎰"),l111ll_l1_+l11lll_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ㎱"),l11lllll11_l1_,21,l11lll_l1_ (u"ࠫࠬ㎲"),l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㎳"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㎴"),l111ll_l1_+l11lll_l1_ (u"ࠧโษิื๎࠭㎵"),l1l11lll1ll_l1_,21,l11lll_l1_ (u"ࠨࠩ㎶"),l11lll_l1_ (u"ࠩ࠴࠴࠶࠭㎷"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㎸"),l111ll_l1_+l11lll_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ㎹"),l1l11llll1l_l1_,21,l11lll_l1_ (u"ࠬ࠭㎺"),l11lll_l1_ (u"࠭࠱࠱࠳ࠪ㎻"))
	return
def l1l1l11111l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㎼"),l111ll_l1_+l11lll_l1_ (u"ࠨ฻ิฬ๏࠭㎽"),l11ll1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㎾"),l111ll_l1_+l11lll_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ㎿"),l11lllll11_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㏀"),l111ll_l1_+l11lll_l1_ (u"ࠬ็วาี์ࠫ㏁"),l1l11lll1ll_l1_,27)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ㏂"),l111ll_l1_+l11lll_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ㏃"),l1l11llll1l_l1_,27)
	return
def MENU(l1l1l1111l1_l1_):
	script_name = l1l1l1111l1_l1_
	if l1l1l1111l1_l1_==l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ㏄"): l1l1l1111l1_l1_ = l11ll1_l1_
	elif l1l1l1111l1_l1_==l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ㏅"): l1l1l1111l1_l1_ = l11lllll11_l1_
	else: script_name = l11lll_l1_ (u"ࠪࠫ㏆")
	l1ll1111111_l1_ = l1l1l111l11_l1_(l1l1l1111l1_l1_)
	if l1ll1111111_l1_==l11lll_l1_ (u"ࠫࡦࡸࠧ㏇") or script_name==l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㏈"):
		l1l11ll1l11_l1_ = l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㏉")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣัฬ๊๊สࠩ㏊")
		l1ll111lll1_l1_ = l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศำฯฬࠩ㏋")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษศอัํࠫ㏌")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"ࠪฬะࠦอ๋ࠢล๎ࠥ็๊ๅ็ࠪ㏍")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠫศ็ไศ็ࠪ㏎")
		l1l11lll11l_l1_ = l11lll_l1_ (u"๋่ࠬิ์ๅํࠬ㏏")
		l1l11lll111_l1_ = l11lll_l1_ (u"࠭ศาษ่ะࠬ㏐")
	elif l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡦࡰࠪ㏑") or script_name==l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ㏒"):
		l1l11ll1l11_l1_ = l11lll_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢ࡬ࡲࠥࡹࡩࡵࡧࠪ㏓")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡉࡵࡳࡴࡨࡲࡹ࠭㏔")
		l1ll111lll1_l1_ = l11lll_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡌࡢࡶࡨࡷࡹ࠭㏕")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡂ࡮ࡳ࡬ࡦࡨࡥࡵࠩ㏖")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"࠭ࡌࡪࡸࡨࠤ࡮ࡌࡩ࡭࡯ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫ㏗")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠧࡎࡱࡹ࡭ࡪࡹࠧ㏘")
		l1l11lll11l_l1_ = l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㏙")
		l1l11lll111_l1_ = l11lll_l1_ (u"ࠩࡖ࡬ࡴࡽࡳࠨ㏚")
	elif l1ll1111111_l1_ in [l11lll_l1_ (u"ࠪࡪࡦ࠭㏛"),l11lll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ㏜")]:
		l1l11ll1l11_l1_ = l11lll_l1_ (u"ࠬาำหฮ๋ࠤิืࠠิษ໏ฮࠬ㏝")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠอษิ໐ࠬ㏞")
		l1ll111lll1_l1_ = l11lll_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฤัี໑์ࠧ㏟")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢส่ๆฮวࠨ㏠")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"ࠩກาูࠦา็ั๊ࠤฬ๐ࠠโ์็้ࠬ㏡")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ㏢")
		l1l11lll11l_l1_ = l11lll_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ㏣")
		l1l11lll111_l1_ = l11lll_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠨ㏤")
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㏥"),l111ll_l1_+l1l11ll1l11_l1_,l1l1l1111l1_l1_,29,l11lll_l1_ (u"ࠧࠨ㏦"),l11lll_l1_ (u"ࠨࠩ㏧"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㏨"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㏩"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㏪")+l111ll_l1_+l1l11ll1lll_l1_,l1l1l1111l1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㏫"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㏬"),l11lll_l1_ (u"ࠧࠨ㏭"),9999)
	menu = [l11lll_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ㏮"),l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㏯"),l11lll_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ㏰")]
	html = OPENURL_CACHED(l11111l_l1_,l1l1l1111l1_l1_+l11lll_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ㏱"),l11lll_l1_ (u"ࠬ࠭㏲"),l11lll_l1_ (u"࠭ࠧ㏳"),l11lll_l1_ (u"ࠧࠨ㏴"),l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㏵"))
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭࠴ࡉ࡯࡯ࡶࡤࡧࡹ࠭㏶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㏷"),block,re.DOTALL)
		for link,title in items:
			if any(value in link for value in menu):
				url = l1l1l1111l1_l1_+link
				if l11lll_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ㏸") in link:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㏹"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㏺")+l111ll_l1_+l1l11ll11ll_l1_,url,22,l11lll_l1_ (u"ࠧࠨ㏻"),l11lll_l1_ (u"ࠨ࠳࠳࠴ࠬ㏼"))
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㏽"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㏾")+l111ll_l1_+l1ll111lll1_l1_,url,22,l11lll_l1_ (u"ࠫࠬ㏿"),l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㐀"))
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐁"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㐂")+l111ll_l1_+l1l11ll1l1l_l1_,url,22,l11lll_l1_ (u"ࠨࠩ㐃"),l11lll_l1_ (u"ࠩ࠵࠴࠶࠭㐄"))
				elif l11lll_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ㐅") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㐆"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㐇")+l111ll_l1_+l1l11ll1ll1_l1_,url,22,l11lll_l1_ (u"࠭ࠧ㐈"),l11lll_l1_ (u"ࠧ࠲࠲࠳ࠫ㐉"))
				elif l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㐊") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㐋"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㐌")+l111ll_l1_+l1l11lll11l_l1_,url,25,l11lll_l1_ (u"ࠫࠬ㐍"),l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㐎"))
				elif l11lll_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ㐏") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐐"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㐑")+l111ll_l1_+l1l11lll111_l1_,url,22,l11lll_l1_ (u"ࠩࠪ㐒"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㐓"))
	return html
def l1l11ll11l1_l1_(url):
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ㐔"),l11lll_l1_ (u"ࠬ࠭㐕"),l11lll_l1_ (u"࠭ࠧ㐖"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡖࡕࡌࡇࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㐗"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩ࠭ࡵࡱࡲࡰࡸ࠳ࡨࡦࡣࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡹࡩࡤ࠯ࡥࡳࡩࡿࠧ㐘"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	title = re.findall(l11lll_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ㐙"),block,re.DOTALL)[0]
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㐚"),l111ll_l1_+title,url,22,l11lll_l1_ (u"ࠫࠬ㐛"),l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㐜"))
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㐝"),block,re.DOTALL)
	for link,title in items:
		link = l1l1l1111l1_l1_ + link
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐞"),l111ll_l1_+title,link,23,l11lll_l1_ (u"ࠨࠩ㐟"),l11lll_l1_ (u"ࠩ࠴࠴࠶࠭㐠"))
	return
def l1111l_l1_(url,l1l11l1_l1_):
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	type = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ㐡"))[-1]
	l1l11l1llll_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㐢"),l11lll_l1_ (u"ࠬ࠭㐣"),url, type)
	if type==l11lll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭㐤") and l1l11l1_l1_==l11lll_l1_ (u"ࠧ࠱ࠩ㐥"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ㐦"),l11lll_l1_ (u"ࠩࠪ㐧"),l11lll_l1_ (u"ࠪࠫ㐨"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ㐩"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫ㐪"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠭࠴ࠪࡀࠫࡁ࠲࠯ࡅࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㐫"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			link = l1l1l1111l1_l1_ + link
			l1llll_l1_ = l1l1l1111l1_l1_ + QUOTE(l1llll_l1_)
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐬"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"ࠨ࠲࠴ࠫ㐭"))
	l1l11ll1111_l1_=0
	if type==l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ㐮"): category=l11lll_l1_ (u"ࠪ࠷ࠬ㐯")
	if type==l11lll_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ㐰"): category=l11lll_l1_ (u"ࠬ࠻ࠧ㐱")
	if type==l11lll_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ㐲"): category=l11lll_l1_ (u"ࠧ࠸ࠩ㐳")
	if type in [l11lll_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ㐴"),l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㐵"),l11lll_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ㐶")] and l1l11l1_l1_!=l11lll_l1_ (u"ࠫ࠵࠭㐷"):
		l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡕࡧࡧࡦ࡫ࡱ࡫ࡎࡺࡥ࡮ࡁࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ㐸")+category+l11lll_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭㐹")+l1l11l1_l1_+l11lll_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡲࡶࡩ࡫ࡲࡣࡻࡀࠫ㐺")+l1l11l1llll_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㐻"),l11lll_l1_ (u"ࠩࠪ㐼"),l11lll_l1_ (u"ࠪࠫ㐽"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㐾"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㐿"),l11lll_l1_ (u"࠭ࠧ㑀"),l11l11l_l1_, html)
		items = re.findall(l11lll_l1_ (u"ࠧࠣࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠱࠿ࠣࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㑁"),html,re.DOTALL)
		for id,title,l1llll_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ࠨ࡞࡟ࠫ㑂"),l11lll_l1_ (u"ࠩࠪ㑃"))
			title = title.replace(l11lll_l1_ (u"ࠪࠦࠬ㑄"),l11lll_l1_ (u"ࠫࠬ㑅"))
			l1l11ll1111_l1_ += 1
			link = l1l1l1111l1_l1_ + l11lll_l1_ (u"ࠬ࠵ࠧ㑆") + type + l11lll_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰ࠩ㑇") + id
			l1llll_l1_ = l1l1l1111l1_l1_ + QUOTE(l1llll_l1_)
			if type==l11lll_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ㑈"): addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㑉"),l111ll_l1_+title,link,24,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"ࠩ࠳࠵ࠬ㑊"))
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㑋"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"ࠫ࠵࠷ࠧ㑌"))
	if type==l11lll_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ㑍"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1111l1_l1_+l11lll_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡉ࡯ࡦࡨࡼࡄࡶࡡࡨࡧࡀࠫ㑎")+l1l11l1_l1_,l11lll_l1_ (u"ࠧࠨ㑏"),l11lll_l1_ (u"ࠨࠩ㑐"),l11lll_l1_ (u"ࠩࠪ㑑"),l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭㑒"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࠭ࡥࡧࡰࡳࠬ㑓"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ㑔"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			l1l11ll1111_l1_ += 1
			l1llll_l1_ = l1l1l1111l1_l1_ + l1llll_l1_
			link = l1l1l1111l1_l1_ + link
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㑕"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠧ࠲࠲࠴ࠫ㑖"))
	if l1l11ll1111_l1_>20:
		title=l11lll_l1_ (u"ࠨืไัฮࠦࠧ㑗")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡨࡲࠬ㑘"): title = l11lll_l1_ (u"ࠪࡔࡦ࡭ࡥࠡࠩ㑙")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࠧ㑚"): title = l11lll_l1_ (u"ࠬ฻แฮ้ࠣࠫ㑛")
		if l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡦࡢ࠴ࠪ㑜"): title = l11lll_l1_ (u"ࠧึใะ๋ࠥ࠭㑝")
		for l1l11llll11_l1_ in range(1,11) :
			if not l1l11l1_l1_==str(l1l11llll11_l1_):
				l1l11ll111l_l1_ = l11lll_l1_ (u"ࠨ࠲ࠪ㑞")+str(l1l11llll11_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑟"),l111ll_l1_+title+str(l1l11llll11_l1_),url,22,l11lll_l1_ (u"ࠪࠫ㑠"),l1l11l1llll_l1_+l1l11ll111l_l1_[-2:])
	return
def l1llllll_l1_(url,l1l11l1_l1_):
	if not l1l11l1_l1_: l1l11l1_l1_ = 0
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	l1l1l1111ll_l1_ = l1l11lll1l1_l1_(url)
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭㑡"))
	id,type = parts[-1],parts[3]
	l1l11l1llll_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	l1l11ll1111_l1_ = 0
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㑢"),l11lll_l1_ (u"࠭ࠧ㑣"),url, type)
	if type==l11lll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ㑤"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ㑥"),l11lll_l1_ (u"ࠩࠪ㑦"),l11lll_l1_ (u"ࠪࠫ㑧"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㑨"))
		items = re.findall(l11lll_l1_ (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡥࡰࡢࡰࡨࡰࡤࡏࡴࡦ࡯࠱࠮ࡄࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࡩ࠯࠭ࡂࡺࡦࡸࠠࡪࡰࡷࡩࡷࡥࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨࠩ㑩"),html,re.DOTALL)
		title = l11lll_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ㑪")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡦࡰࠪ㑫"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭㑬")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥࠬ㑭"): title = l11lll_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ㑮")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ㑯"): title = l11lll_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ㑰")
		if l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡦࡢࠩ㑱"): l1l11llllll_l1_ = l11lll_l1_ (u"ࠧࠨ㑲")
		else: l1l11llllll_l1_ = l1ll1111111_l1_
		l1l1l111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ㑳"),html,re.DOTALL)
		for name,count,l1llll_l1_,link in items:
			for l1lll11_l1_ in range(int(count),0,-1):
				l1l1l111l1l_l1_ = l1llll_l1_ + l1l11llllll_l1_ + id + l11lll_l1_ (u"ࠩ࠲ࠫ㑴") + str(l1lll11_l1_) + l11lll_l1_ (u"ࠪ࠲ࡵࡴࡧࠨ㑵")
				#l1ll11l1l1l_l1_ = l1l1l111ll1_l1_[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"ࠫ࠴࠲ࠧ㑶")+str(l1lll11_l1_)+l11lll_l1_ (u"ࠬ࠲ࠧ㑷")+str(l1lll11_l1_)+l11lll_l1_ (u"࠭࡟ࠨ㑸")+l1l1l111ll1_l1_[0][2]
				l1l11ll11ll_l1_ = name + title + str(l1lll11_l1_)
				l1l11ll11ll_l1_ = unescapeHTML(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㑹"),l111ll_l1_+l1l11ll11ll_l1_,url,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠨࠩ㑺"),str(l1lll11_l1_))
	elif type==l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㑻"):
		l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡄࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡏࡴࡦ࡯ࡂ࡭ࡩࡃࠧ㑼")+str(id)+l11lll_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ㑽")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾࠳ࠪ㑾")
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㑿"),l11lll_l1_ (u"ࠧࠨ㒀"),l11lll_l1_ (u"ࠨࠩ㒁"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ㒂"))
		items = re.findall(l11lll_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡆ࡬ࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㒃"),html,re.DOTALL)
		title = l11lll_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ㒄")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㒅"): title = l11lll_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ㒆")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡧࡣࠪ㒇"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ㒈")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㒉"): title = l11lll_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ㒊")
		for l1lll11_l1_,l1llll_l1_,link,desc,name in items:
			l1l11ll1111_l1_ += 1
			l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
			#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
			name = escapeUNICODE(name)
			l1l11ll11ll_l1_ = name + title + str(l1lll11_l1_)
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㒋"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠬ࠭㒌"),str(l1l11ll1111_l1_))
	elif type==l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ㒍"):
		if l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴࠨ㒎") in url and l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ㒏") not in url:
			l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀࠫ㒐")+str(id)+l11lll_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ㒑")+l1l11l1_l1_+l11lll_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠵࠭㒒")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭㒓"),l11lll_l1_ (u"࠭ࠧ㒔"),l11lll_l1_ (u"ࠧࠨ㒕"),l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠶ࡶࡩ࠭㒖"))
			items = re.findall(l11lll_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㒗"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = name + l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ㒘") + title
				l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭㒙"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㒚"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"࠭ࠧ㒛"),str(l1l11ll1111_l1_))
		elif l11lll_l1_ (u"ࠧࡄ࡮࡬ࡴࡸ࠭㒜") in url:
			l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ㒝")+l1l11l1_l1_+l11lll_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠴࠹ࠬ㒞")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㒟"),l11lll_l1_ (u"ࠫࠬ㒠"),l11lll_l1_ (u"ࠬ࠭㒡"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠵ࡶ࡫ࠫ㒢"))
			items = re.findall(l11lll_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㒣"),html,re.DOTALL)
			for l1llll_l1_,title,link in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = title.strip(l11lll_l1_ (u"ࠨࠢࠪ㒤"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㒥"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠪࠫ㒦"),str(l1l11ll1111_l1_))
		elif l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭㒧") in url:
			if l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠷ࠩ㒨") in url:
				l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ㒩")+l1l11l1_l1_+l11lll_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠷ࠩ㒪")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㒫"),l11lll_l1_ (u"ࠩࠪ㒬"),l11lll_l1_ (u"ࠪࠫ㒭"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠻ࡴࡩࠩ㒮"))
			elif l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠵ࠩ㒯") in url:
				l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ㒰")+l1l11l1_l1_+l11lll_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠵ࠩ㒱")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㒲"),l11lll_l1_ (u"ࠩࠪ㒳"),l11lll_l1_ (u"ࠪࠫ㒴"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠼ࡴࡩࠩ㒵"))
			items = re.findall(l11lll_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㒶"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = name + l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪ㒷") + title
				l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩ㒸"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㒹"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠩࠪ㒺"),str(l1l11ll1111_l1_))
	if type==l11lll_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ㒻") or type==l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㒼"):
		if l1l11ll1111_l1_>25:
			title=l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ㒽")
			if l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡥ࡯ࠩ㒾"): title = l11lll_l1_ (u"ࠧࠡࡒࡤ࡫ࡪࠦࠧ㒿")
			if l1ll1111111_l1_==l11lll_l1_ (u"ࠨࡨࡤࠫ㓀"): title = l11lll_l1_ (u"ูࠩࠣๆำ็ࠡࠩ㓁")
			if l1ll1111111_l1_==l11lll_l1_ (u"ࠪࡪࡦ࠸ࠧ㓂"): title = l11lll_l1_ (u"ࠫࠥ฻แฮ้ࠣࠫ㓃")
			for l1l11llll11_l1_ in range(1,11):
				if not l1l11l1_l1_==str(l1l11llll11_l1_):
					l1l11ll111l_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ㓄")+str(l1l11llll11_l1_)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓅"),l111ll_l1_+title+str(l1l11llll11_l1_),url,23,l11lll_l1_ (u"ࠧࠨ㓆"),l1l11l1llll_l1_+l1l11ll111l_l1_[-2:])
	return
def PLAY(url,l1lll11_l1_):
	l1l1l1111ll_l1_ = l1l11lll1l1_l1_(url)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ㓇"),l11lll_l1_ (u"ࠩࠪ㓈"),l11lll_l1_ (u"ࠪࠫ㓉"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㓊"))
	# l1l1l_l1_ l1llll1l1_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࡢ࠭࠭࠴ࠪࡀࠫࠥࡂࠬ㓋"),html,re.DOTALL)
	if items:
		l1ll1111111_l1_ = l1l1l111l11_l1_(url)
		parts = url.split(l11lll_l1_ (u"࠭࠯ࠨ㓌"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"ࠧ࠰࠮ࠪ㓍")+l1lll11_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ㓎")+l1lll11_l1_+l11lll_l1_ (u"ࠩࡢࠫ㓏")+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ㓐"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ url
	items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪ࠭࠭ࡢ࠮࠯ࠬࡂ࠭ࠧ࠭㓑"),html,re.DOTALL)
	if items:
		l1ll1111111_l1_ = l1l1l111l11_l1_(url)
		parts = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ㓒"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"࠭࠯ࠨ㓓")+l1lll11_l1_+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡺࡸ࡬ࠨ㓔"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ src
	items = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㓕"),html,re.DOTALL)
	for link in items:
		link = link.replace(l11lll_l1_ (u"ࠩ࠲࠳ࠬ㓖"),l11lll_l1_ (u"ࠪ࠳ࠬ㓗"))
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࡲࡶ࠴ࠡࡵࡵࡧࠬ㓘"))
		l1111_l1_.append(link)
	# l1l1l111111_l1_ l1111lll_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㓙"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l1l1111ll_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"࠭࡭ࡱ࠶ࠣࡥࡩࡪࡲࡦࡵࡶࠫ㓚"))
		l1111_l1_.append(link)
	# l1l1l111111_l1_ l1l1l111lll_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠧࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㓛"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l1l1111ll_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨ࡯ࡳ࠷ࠥࡧࡤࡥࡴࡨࡷࡸ࠭㓜"))
		l1111_l1_.append(link)
	# l1l_l1_
	if len(l1111_l1_)==1: link = l1111_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ㓝"), l1lll1ll_l1_)
		if l1l_l1_ == -1 : return
		link = l1111_l1_[l1l_l1_]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㓞"))
	return
def l1l11lll1l1_l1_(url):
	if l11ll1_l1_ in url: l1l1l1ll1ll_l1_ = l11ll1_l1_
	elif l11lllll11_l1_ in url: l1l1l1ll1ll_l1_ = l11lllll11_l1_
	elif l1l11lll1ll_l1_ in url: l1l1l1ll1ll_l1_ = l1l11lll1ll_l1_
	elif l1l11llll1l_l1_ in url: l1l1l1ll1ll_l1_ = l1l11llll1l_l1_
	else: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࠬ㓟")
	return l1l1l1ll1ll_l1_
def l1l1l111l11_l1_(url):
	if   l11ll1_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠬࡧࡲࠨ㓠")
	elif l11lllll11_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"࠭ࡥ࡯ࠩ㓡")
	elif l1l11lll1ll_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠧࡧࡣࠪ㓢")
	elif l1l11llll1l_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠨࡨࡤ࠶ࠬ㓣")
	else: l1ll1111111_l1_ = l11lll_l1_ (u"ࠩࠪ㓤")
	return l1ll1111111_l1_
def l1l1lll1l_l1_(url):
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	l11l11l_l1_ = url + l11lll_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡏ࡭ࡻ࡫ࠧ㓥")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㓦"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭㓧"),l11lll_l1_ (u"࠭ࠧ㓨"),l11lll_l1_ (u"ࠧࠨ㓩"),l11lll_l1_ (u"ࠨࠩ㓪"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ㓫"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㓬"),html,re.DOTALL)
	l11l1l1_l1_ = items[0]
	PLAY_VIDEO(l11l1l1_l1_,script_name,l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㓭"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ㓮"),l11lll_l1_ (u"࠭ࠫࠨ㓯"))
	if l1ll_l1_:
		l1ll1ll1l1_l1_ = [ l11ll1_l1_ , l11lllll11_l1_ , l1l11lll1ll_l1_ , l1l11llll1l_l1_ ]
		l1l1l11ll_l1_ = [ l11lll_l1_ (u"ฺࠧำห๎ࠬ㓰") , l11lll_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ㓱") , l11lll_l1_ (u"ࠩไหึู้ࠨ㓲") , l11lll_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ㓳") ]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่้เษࠡษ็้๋อำษห࠽ࠫ㓴"), l1l1l11ll_l1_)
		if l1l_l1_ == -1 : return
		l1l1ll11_l1_ = l1ll1ll1l1_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭㓵") in options: l1l1ll11_l1_ = l11ll1_l1_
		elif l11lll_l1_ (u"࠭࡟ࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎ࡟ࠨ㓶") in options: l1l1ll11_l1_ = l11lllll11_l1_
		else: l1l1ll11_l1_ = l11lll_l1_ (u"ࠧࠨ㓷")
	if not l1l1ll11_l1_: return
	l1ll1111111_l1_ = l1l1l111l11_l1_(l1l1ll11_l1_)
	l11l11l_l1_ = l1l1ll11_l1_ + l11lll_l1_ (u"ࠣ࠱ࡋࡳࡲ࡫࠯ࡔࡧࡤࡶࡨ࡮࠿ࡴࡧࡤࡶࡨ࡮ࡳࡵࡴ࡬ࡲ࡬ࡃࠢ㓸") + l111l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㓹"),l11lll_l1_ (u"ࠪࠫ㓺"),l1ll1111111_l1_,l11l11l_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ㓻"),l11lll_l1_ (u"ࠬ࠭㓼"),l11lll_l1_ (u"࠭ࠧ㓽"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ㓾"))
	items = re.findall(l11lll_l1_ (u"ࠨࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠬ㓿"),html,re.DOTALL)
	if items:
		for l1llll_l1_,category,id,title in items:
			#if category in [l11lll_l1_ (u"ࠩ࠶ࠫ㔀"),l11lll_l1_ (u"ࠪ࠹ࠬ㔁"),l11lll_l1_ (u"ࠫ࠼࠭㔂")]:
			if category in [l11lll_l1_ (u"ࠬ࠹ࠧ㔃"),l11lll_l1_ (u"࠭࠷ࠨ㔄")]:
				title = title.replace(l11lll_l1_ (u"ࠧ࡝࡞ࠪ㔅"),l11lll_l1_ (u"ࠨࠩ㔆"))
				title = title.replace(l11lll_l1_ (u"ࠩࠥࠫ㔇"),l11lll_l1_ (u"ࠪࠫ㔈"))
				if category==l11lll_l1_ (u"ࠫ࠸࠭㔉"):
					type = l11lll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ㔊")
					if l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡡࡳࠩ㔋"): name = l11lll_l1_ (u"ࠧๆี็ื้ࠦ࠺ࠡࠩ㔌")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠨࡧࡱࠫ㔍"): name = l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠽ࠤࠬ㔎")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠪࡪࡦ࠭㔏"): name = l11lll_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ㔐")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡬ࡡ࠳ࠩ㔑"): name = l11lll_l1_ (u"࠭ำา์ส่ࠥํวࠡ࠼ࠣࠫ㔒")
				elif category==l11lll_l1_ (u"ࠧ࠶ࠩ㔓"):
					type = l11lll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭㔔")
					if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡤࡶࠬ㔕"): name = l11lll_l1_ (u"ࠪๅ๏๊ๅࠡ࠼ࠣࠫ㔖")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠫࡪࡴࠧ㔗"): name = l11lll_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࠤ࠿ࠦࠧ㔘")
					elif l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡦࡢࠩ㔙"): name = l11lll_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ㔚")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠨࡨࡤ࠶ࠬ㔛"): name = l11lll_l1_ (u"ࠩไ่๊ࠦ็ศࠢ࠽ࠤࠬ㔜")
				elif category==l11lll_l1_ (u"ࠪ࠻ࠬ㔝"):
					type = l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㔞")
					if l1ll1111111_l1_==l11lll_l1_ (u"ࠬࡧࡲࠨ㔟"): name = l11lll_l1_ (u"࠭ศา่ส้ัࠦ࠺ࠡࠩ㔠")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡦࡰࠪ㔡"): name = l11lll_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢ࠽ࠤࠬ㔢")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥࠬ㔣"): name = l11lll_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ㔤")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ㔥"): name = l11lll_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠡ࠼ࠣࠫ㔦")
				title = name + title
				link = l1l1ll11_l1_ + l11lll_l1_ (u"࠭࠯ࠨ㔧") + type + l11lll_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ㔨") + id
				l1llll_l1_ = QUOTE(l1llll_l1_)
				l1llll_l1_ = l1l1ll11_l1_+l1llll_l1_
				#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㔩"),l1llll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔪"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㔫"))
	#else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㔬"),l11lll_l1_ (u"ࠬ࠭㔭"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㔮"),,لا توجد نتائج للبحث')
	return
﻿# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨຮ")
headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫຯ") : l11lll_l1_ (u"ࠨࠩະ") }
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨັ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ะ่ศื็ࠤฬ๊วอฬ่ห฾๐ࠧາ"),l11lll_l1_ (u"ฺࠫ๎ัࠡษ็ฮํอีๅࠢส่ฬาสๆษ฼๎ࠬຳ")]
def MAIN(mode,url,text,l1l11l1_l1_):
	if   mode==40: results = MENU()
	elif mode==41: results = l1l1lll1l_l1_()
	elif mode==42: results = l1llllll_l1_(url)
	elif mode==43: results = PLAY(url)
	elif mode==44: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==45: results = l1l1l1l1l_l1_(url)
	elif mode==49: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪິ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅสฮࠤฬ๊อ๋ࠢ็ๆ๋อษࠡษ็้฾อัโࠩີ"),l11lll_l1_ (u"ࠧࠨຶ"),41)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨື"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺຸࠩ"),l11lll_l1_ (u"ູࠪࠫ"),49,l11lll_l1_ (u"຺ࠫࠬ"),l11lll_l1_ (u"ࠬ࠭ົ"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪຼ"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬຽ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ຾"),l11lll_l1_ (u"ࠩࠪ຿"),9999)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠪࠫເ"),headers,l11lll_l1_ (u"ࠫࠬແ"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩໂ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠯࠷࠵࠻࠹࠳ࠩ࠰࠭ࡃ࠮ࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠮࠶࠴࠸࠷࠹ࠧໃ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡯ࡨࡲࡺ࠳ࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬໄ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໅"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫໆ")+l111ll_l1_+title,link,44)
	return
def l1111l_l1_(url,type):
	if type==l11lll_l1_ (u"ࠪࡰ࡮ࡳࡩࡵࡧࡧࡣࡸ࡫ࡡࡳࡥ࡫ࠫ໇"):
		search = OPEN_KEYBOARD()
		if not search: return
		url = url.replace(l11lll_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࡢࡗࡊࡇࡒࡄࡊࡢ࡛ࡔࡘࡄࠨ່"),search)
	#DIALOG_OK(l11lll_l1_ (u"້ࠬ࠭"),l11lll_l1_ (u"໊࠭ࠧ"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗ໋ࠫ"),url,l11lll_l1_ (u"ࠨࠩ໌"),l11lll_l1_ (u"ࠩࠪໍ"),l11lll_l1_ (u"ࠪࠫ໎"),l11lll_l1_ (u"ࠫࠬ໏"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ໐"))
	html = response.content
	if not type:
		data = re.findall(l11lll_l1_ (u"࠭ࡪࡦࡶ࠰ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࡠࡡࡩࡳࡷࡳ࠮ࠫࡁࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໑"),html,re.DOTALL)
		if data:
			data = l111l_l1_(unescapeHTML(data[0]))
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ໒")+l11lll_l1_ (u"ࠨࡆࡘࡑࡒ࡟࡟ࡔࡇࡄࡖࡈࡎ࡟ࡘࡑࡕࡈࠬ໓")+l11lll_l1_ (u"ࠩࠩ࡮ࡪࡺ࡟ࡢ࡬ࡤࡼࡤࡹࡥࡢࡴࡦ࡬ࡤࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠽ࠨ໔")+data+l11lll_l1_ (u"ࠪࠪࡵࡵࡳࡵࡡࡷࡽࡵ࡫࠽ࡷ࡫ࡧࡩࡴࡹࠧ໕")
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ໖"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥํะศࠢส่็ูๅࠨ໗"),link,44,l11lll_l1_ (u"࠭ࠧ໘"),l11lll_l1_ (u"ࠧ࡭࡫ࡰ࡭ࡹ࡫ࡤࡠࡵࡨࡥࡷࡩࡨࠨ໙"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ໚"))
			addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ໛"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪໜ"),l11lll_l1_ (u"ࠫࠬໝ"),9999)
		#else:
		#	link = url+l11lll_l1_ (u"ࠬࡅ࡟ࡴࡧࡤࡶࡨ࡮࠽ࡅࡗࡐࡑ࡞ࡥࡓࡆࡃࡕࡇࡍࡥࡗࡐࡔࡇࠫໞ")
		#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ໟ"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐่ࠠาสࠤฬ๊โิ็ࠪ໠"),link,44,l11lll_l1_ (u"ࠨࠩ໡"),l11lll_l1_ (u"ࠩ࡯࡭ࡲ࡯ࡴࡦࡦࡢࡷࡪࡧࡲࡤࡪࠪ໢"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ໣"))
		#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ໤"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ໥"),l11lll_l1_ (u"࠭ࠧ໦"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡧ࡯ࡩࡲ࡫࡮ࡵࡱࡵ࠱ࡵࡵࡳࡵࡡࡢࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡥ࡟࡭࡫ࡱ࡯ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ໧"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡥࡧࡶ࡯ࡹࡵࡰࡠࡲࡲࡷࡹࡹࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬ໨"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡩࡱ࡫࡭ࡦࡰࡷࡳࡷ࠳ࡩࡤࡱࡱ࠱ࡱ࡯ࡳࡵ࠯ࡷࡩࡽࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡳࡪࡶࡨ࠱࡫ࡵ࡯ࡵࡧࡵࠦࠬ໩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		items = []
		block = l1l1ll1_l1_[0]
		if l11lll_l1_ (u"ࠪࡷࡴࡩࡩࡢ࡮ࠪ໪") in url:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ໫"),block,re.DOTALL)
			links,l1l111_l1_,l1l1l1lll_l1_ = zip(*items)
			items = zip(l1l1l1lll_l1_,links,l1l111_l1_)
		if not items: items = re.findall(l11lll_l1_ (u"ࠬࡂ࡮ࡰࡵࡦࡶ࡮ࡶࡴ࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭໬"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ໭"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭໮"),l111ll_l1_+title,link,43,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡧ࠰ࡰࡴࡧࡤ࠮࡯ࡲࡶࡪ࠳ࡡ࡯ࡥ࡫ࡳࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ໯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ໰"),block,re.DOTALL)
		l1ll1ll1l_l1_ = False
		for link,title in items:
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ໱") not in link: continue
			l1ll1ll1l_l1_ = True
			title = unescapeHTML(title)
			link = unescapeHTML(link)
			if l11lll_l1_ (u"ࠫࡃ࠭໲") in title: title = title.rsplit(l11lll_l1_ (u"ࠬࡄࠧ໳"),1)[1]
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭໴"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭໵")+title,link,44,l11lll_l1_ (u"ࠨࠩ໶"),l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭໷"))
		if not l1ll1ll1l_l1_:
			link = re.findall(l11lll_l1_ (u"ࠪࡲࡪࡾࡴ࠮ࡲࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ໸"),block,re.DOTALL)
			if link:
				link = link[0]
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ໹"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ໺")+l11lll_l1_ (u"࠭วๅ็ี๎ิ࠭໻"),link,44,l11lll_l1_ (u"ࠧࠨ໼"),l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ໽"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭໾"),url,l11lll_l1_ (u"ࠪࠫ໿"),l11lll_l1_ (u"ࠫࠬༀ"),l11lll_l1_ (u"ࠬ࠭༁"),l11lll_l1_ (u"࠭ࠧ༂"),l11lll_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ༃"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯ࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭༄"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࡢࡹࡷࡲ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠫ࠭༅"),html,re.DOTALL)
	l1lllll1_l1_ = []
	if link:
		link = link[0].replace(l11lll_l1_ (u"ࠪࡠ࠴࠭༆"),l11lll_l1_ (u"ࠫ࠴࠭༇"))
		l1lllll1_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭༈"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ༉"),url)
	return
def l1l1lll1l_l1_():
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰สฮ࠱๊ฮวีำࠪ༊"),l11lll_l1_ (u"ࠨࠩ་"),l11lll_l1_ (u"ࠩࠪ༌"),l11lll_l1_ (u"ࠪࠫ།"),l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ༎"))
	items = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ༏"),html,re.DOTALL)
	url = l111l_l1_(items[0])
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ༐"),l11lll_l1_ (u"ࠧࠨ༑"),url,str(html))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭༒"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ༓"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ༔"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠫࠥ࠭༕"),l11lll_l1_ (u"ࠬ࠱ࠧ༖"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫ༗") +l111l1l_l1_
	l1l1l1l1l_l1_(url)
	return
def l1l1l1l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗ༘ࠫ"),url,l11lll_l1_ (u"ࠨ༙ࠩ"),l11lll_l1_ (u"ࠩࠪ༚"),l11lll_l1_ (u"ࠪࠫ༛"),l11lll_l1_ (u"ࠫࠬ༜"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ༝"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡴ࡫ࡷࡩ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪࠤࡶ࡭ࡹ࡫࠭ࡧࡱࡲࡸࡪࡸࠢࠨ༞"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡥࡳࡴࡱ࡭ࡢࡴ࡮ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ༟"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ༠"),l111ll_l1_+title,link,43,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨࡳࡪࡶࡨ࠱࡫ࡵ࡯ࡵࡧࡵࠦࠬ༡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ༢"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭༣"))
			if not title: continue
			if l11lll_l1_ (u"ࠬ฻แฮหࠪ༤") not in title: title = l11lll_l1_ (u"࠭ีโฯฬࠤࠬ༥")+title
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ༦"),l111ll_l1_+title,link,45)
	return
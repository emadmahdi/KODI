# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ乭")
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭乮"):l11lll_l1_ (u"ࠪࠫ乯")}
script_name = l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ买")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ乱")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11lll_l1_ (u"࠭࠳ࠨ乲"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11lll_l1_ (u"ࠧ࠲ࠩ乳"))
	elif mode==36: results = CATEGORIES(url,l11lll_l1_ (u"ࠨ࠴ࠪ乴"))
	elif mode==37: results = CATEGORIES(url,l11lll_l1_ (u"ࠩ࠷ࠫ乵"))
	elif mode==38: results = l1l1lll1l_l1_()
	elif mode==39: results = SEARCH(text,l1l11l1_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ乶"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ乷"),l11lll_l1_ (u"ࠬ࠭乸"),39,l11lll_l1_ (u"࠭ࠧ乹"),l11lll_l1_ (u"ࠧࠨ乺"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ乻"))
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ乼"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ乽"),l11lll_l1_ (u"ࠫࠬ乾"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ乿"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ亀")+l111ll_l1_+l11lll_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ亁"),l11lll_l1_ (u"ࠨࠩ亂"),38)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ亃"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ亄")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ศาษ่ะࠬ亅"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ了"),31)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭亇"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ予")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊วไอิࠤฺ๊ว่ัฬࠫ争"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ亊"),37)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ事"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭二")+l111ll_l1_+l11lll_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็๊ํ฿ࠧ亍"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ于"),35)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亏"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ亐")+l111ll_l1_+l11lll_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไๆ็ฮ่ࠬ云"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ互"),36)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亓"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ五")+l111ll_l1_+l11lll_l1_ (u"࠭วฮัฮࠤฬ๊วโๆส้ࠬ井"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ亖"),32)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ亗"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ亘")+l111ll_l1_+l11lll_l1_ (u"ุ้ࠪือ๋ษอࠫ亙"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳࠹࠵࠱ࠨ亚"),32)
	return l11lll_l1_ (u"ࠬ࠭些")
def CATEGORIES(url,select=l11lll_l1_ (u"࠭ࠧ亜")):
	type = url.split(l11lll_l1_ (u"ࠧ࠰ࠩ亝"))[3]
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ亞"),l11lll_l1_ (u"ࠩࠪ亟"),type, url)
	if type==l11lll_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ亠"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ亡"),headers,l11lll_l1_ (u"ࠬ࠭亢"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹ࠭亣"))
		if select==l11lll_l1_ (u"ࠧ࠴ࠩ交"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯ࡳࡦࡴ࡬ࡩࡸࡌ࡯ࡳ࡯ࠪ亥"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ亦"),block,re.DOTALL)
			for link,name in items:
				if l11lll_l1_ (u"ࠪ็้๐ศศฬ้ࠣ฻ำใสࠩ产") in name: continue
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠫࠥ࠭亨"))
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ亩"),l111ll_l1_+name,url,32)
		if select==l11lll_l1_ (u"࠭࠴ࠨ亪"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡤࡦࡶࡤ࡭ࡱࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡺࡃࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ享"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ京"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				url = l11ll1_l1_ + link
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ亭"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ亮"),l111ll_l1_+title,url,32,l1llll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ亯"),l11lll_l1_ (u"ࠬ࠭亰"),url,l11lll_l1_ (u"࠭ࠧ亱"))
	if type==l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ亲"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠨࠩ亳"),headers,l11lll_l1_ (u"ࠩࠪ亴"),l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠲࡯ࡦࠪ亵"))
		if select==l11lll_l1_ (u"ࠫ࠶࠭亶"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡌ࡫࡮ࡥࡧࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ亷"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ亸"),block,re.DOTALL)
			for value,name in items:
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯ࠨ亹") + value
				name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ人"))
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ亻"),l111ll_l1_+name,url,32)
		elif select==l11lll_l1_ (u"ࠪ࠶ࠬ亼"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡅࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭亽"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭亾"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ亿"))
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡣࡦࡸࡴࡸ࠯ࠨ什") + value
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ仁"),l111ll_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ仂"),l11lll_l1_ (u"ࠪࠫ仃"),url,l11lll_l1_ (u"ࠫࠬ仄"))
	type = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ仅"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ仆"),headers,l11lll_l1_ (u"ࠧࠨ仇"),l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ仈"))
	if l11lll_l1_ (u"ࠩ࡫ࡳࡲ࡫ࠧ仉") in url: type=l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ今")
	if type==l11lll_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ介"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠩ࠰࠭ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ仌"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ仍"),block,re.DOTALL)
			for link,l1llll_l1_,name in items:
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ从"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ仏"),l111ll_l1_+name,url,32,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ仐"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ仑"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨ仒"),block,re.DOTALL)
		for link,l1llll_l1_,name in items:
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ仓"))
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ仔"),l111ll_l1_+name,url,33,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ仕"):
		l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ他"))[-1]
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ仗"),l11lll_l1_ (u"ࠪࠫ付"),url,l11lll_l1_ (u"ࠫࠬ仙"))
		if l1l11l1_l1_==l11lll_l1_ (u"ࠬ࠷ࠧ仚"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠫ仛"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶࠨ仜"),block,re.DOTALL)
			count = 0
			for link,l1llll_l1_,l1lll11_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ仝") + l1lll11_l1_
				url = l11ll1_l1_ + link
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ仞"),l111ll_l1_+name,url,33,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹ࠮ࠫࡁࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭仟"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࠬ仠"),block,re.DOTALL)
		for link,l1llll_l1_,title,l1lll11_l1_ in items:
			l1lll11_l1_ = l1lll11_l1_.strip(l11lll_l1_ (u"ࠬࠦࠧ仡"))
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ仢"))
			name = title + l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ代") + l1lll11_l1_
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ令"),l111ll_l1_+name,url,33,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡪࡰࡾࡶࡨࡪࡥࡲࡲ࠲ࡩࡨࡦࡸࡵࡳࡳ࠳ࡲࡪࡩ࡫ࡸ࠭࠴ࠫࡀࠫࡧࡥࡹࡧ࠭ࡳࡧࡹ࡭ࡻ࡫࠭ࡻࡱࡱࡩ࡮ࡪ࠽ࠣ࠶ࠥࠫ以"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ仦"),block,re.DOTALL)
	for link,l1l11l1_l1_ in items:
		url = l11ll1_l1_ + link
		name = l11lll_l1_ (u"ฺࠫ็อสࠢࠪ仧") + l1l11l1_l1_
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ仨"),l111ll_l1_+name,url,32)
	return
def PLAY(url):
	if l11lll_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ仩") in url:
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸ࠴ࡼ࠱࠰ࡵࡨࡶ࡮࡫ࡳࡍ࡫ࡱ࡯࠴࠭仪") + url.split(l11lll_l1_ (u"ࠨ࠱ࠪ仫"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭们"),url,l11lll_l1_ (u"ࠪࠫ仭"),headers,l11lll_l1_ (u"ࠫࠬ仮"),l11lll_l1_ (u"ࠬ࠭仯"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ仰"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠧࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭仱"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ仲"),l11lll_l1_ (u"ࠩ࠲ࠫ仳"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ仴"),url,l11lll_l1_ (u"ࠫࠬ仵"),headers,l11lll_l1_ (u"ࠬ࠭件"),l11lll_l1_ (u"࠭ࠧ价"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ仸"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡗࡕࡐࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ仹"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ仺"))
	return
def SEARCH(search,l1l11l1_l1_=l11lll_l1_ (u"ࠪࠫ任")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠫࠥ࠭仼"),l11lll_l1_ (u"ࠬࠫ࠲࠱ࠩ份"))
	l1ll1111l_l1_ = [l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭仾"),l11lll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ仿")]
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠨ࠳ࠪ伀")
	else: l1l11l1_l1_,type = l1l11l1_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ企"))
	if l1ll_l1_:
		l1l1l11ll_l1_ = [ l11lll_l1_ (u"ࠪฬาัฺ่ࠠࠣหๆ๊วๆࠩ伂") , l11lll_l1_ (u"ࠫอำหࠡ฻้ࠤู๊ไิๆสฮࠬ伃")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢ࠰ࠤฬิสาࠢส่อำหࠨ伄"), l1l1l11ll_l1_)
		if l1l_l1_ == -1 : return
		type = l1ll1111l_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧ伅") in options: type = l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ伆")
		elif l11lll_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࡠࠩ伇") in options: type = l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ伈")
		else: return
	headers[l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ伉")] = l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ伊")
	data = {l11lll_l1_ (u"ࠬࡷࡵࡦࡴࡼࠫ伋"):l111l1l_l1_ , l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡊ࡯࡮ࡣ࡬ࡲࠬ伌"):type}
	if l1l11l1_l1_!=l11lll_l1_ (u"ࠧ࠲ࠩ伍"): data[l11lll_l1_ (u"ࠨࡨࡵࡳࡲ࠭伎")] = l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ伏"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ伐"),data,headers,l11lll_l1_ (u"ࠫࠬ休"),l11lll_l1_ (u"ࠬ࠭伒"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ伓"))
	html = response.content
	items=re.findall(l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ伔"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l11ll1_l1_ + link.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ伕"),l11lll_l1_ (u"ࠩ࠲ࠫ伖"))
			if l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ众") in url: addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ优"),l111ll_l1_+l11lll_l1_ (u"ࠬ็๊ๅ็ࠣࠫ伙")+title,url,33)
			elif l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ会") in url:
				url = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ伛"),l11lll_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࠧ伜"))
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伝"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪ伞")+title,url+l11lll_l1_ (u"ࠫ࠴࠷ࠧ伟"),32)
	count=re.findall(l11lll_l1_ (u"ࠬࠨࡴࡰࡶࡤࡰࠧࡀࠨ࠯ࠬࡂ࠭ࢂ࠭传"),html,re.DOTALL)
	if count:
		l1l1ll11l_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll11l1l_l1_ in range(1,l1l1ll11l_l1_):
			l1ll11l1l_l1_ = str(l1ll11l1l_l1_)
			if l1ll11l1l_l1_!=l1l11l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭伡"),l11lll_l1_ (u"ࠧึใะอࠥ࠭伢")+l1ll11l1l_l1_,l11lll_l1_ (u"ࠨࠩ伣"),39,l11lll_l1_ (u"ࠩࠪ伤"),l1ll11l1l_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ伥")+type,search)
	return
def l1l1lll1l_l1_():
	link = l11lll_l1_ (u"ࠫࡦࡎࡒ࠱ࡥࡇࡳࡻࡒ࠲ࡥࡼࡧࡌࡏࡲ࡙ࡘ࠲࠳ࡐࡳࡈࡨࡣ࡯࡙࠴ࡑࡳࡎࡷࡎࡰࡰࡸࡒ࠲ࡗ࡭࡝࠶࡛࡬࡙ࡘࡌࡼࡐ࠷࡮ࡨࡣࡉࡉ࡙࡛࡯࠹ࡸࡤࡊࡊ࠺ࡨࡇ࡭ࡼࡧࡇ࠺ࡺࡍ࠴ࡗ࠷ࠫ伦")
	link = base64.b64decode(link)
	link = link.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ伧"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ伨"))
	return
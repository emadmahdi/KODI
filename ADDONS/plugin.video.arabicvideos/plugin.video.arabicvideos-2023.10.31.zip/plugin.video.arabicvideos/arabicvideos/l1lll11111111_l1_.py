# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ汜")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭汝")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠨࠩ汞")
#headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭江"):l11lll_l1_ (u"ࠪࠫ池")}
def MAIN(mode,url,text,type,l1l11l1_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11111l1_l1_(url)
	#elif mode==142: results = l1ll1llllll11_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l11l1_l1_)
	elif mode==145: results = l1lll11ll1ll1_l1_(url)
	elif mode==146: results = l1ll1llll1lll_l1_(url)
	elif mode==147: results = l1lll11l111l1_l1_()
	elif mode==148: results = l1lll11l11l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎࡇ࠷࡝ࡩࡘࡌࡄࡘࡷࡿࡲࡂࡵࡏࡖࡻࡋ࡬࡚࡛ࡘࡗࡐࡕࡑࡺࡻࡲࡵࡼࡔ࡙ࠧ污")
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ汢"),l111ll_l1_+l11lll_l1_ (u"࠭ࡔࡆࡕࡗࠤ࡞ࡕࡕࡕࡗࡅࡉࠬ汣"),url,144)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ汤"),l111ll_l1_+l11lll_l1_ (u"ࠨࡱ࡯ࡨࡪࡸࠠࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠢࡱࡳࡹࠦ࡬ࡪࡵࡷ࡭ࡳ࡭ࠠ࡯ࡧࡺࡩࡷࠦࡰ࡭ࡻࡤࡰ࡮ࡹࡴࠨ汥"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡇࡲࡴࡩ࡞ࢀࡘ࡛ࡨ࡮ࠪࡱ࡯ࡳࡵ࠿ࡕࡈࡖࡓ࠶࠴ࡸࡋ࡮ࡕ࠶ࡨࡦࡖࡶࠫ汦"),144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ汧"),l111ll_l1_+l11lll_l1_ (u"๊ࠫ๎โฺࠢไหึเࠧ汨"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡖࡅࡷࡓࡻࡵ࡮࡫࠶ࡊࡽࡴࡶࡍࡕࡏࡅࡥ࠷࠹ࡱࡖࡥࡺࠫ汩"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭汪"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ汫"),l11lll_l1_ (u"ࠨࠩ汬"),149,l11lll_l1_ (u"ࠩࠪ汭"),l11lll_l1_ (u"ࠪࠫ汮"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ汯"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ汰"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ汱")+l11lll_l1_ (u"ࠧࡠ࡛ࡗࡇࡤ࠭汲")+l11lll_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡษ็้อืๅอࠩ汳"),l11lll_l1_ (u"ࠩࠪ汴"),290)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ汵"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭汶")+l111ll_l1_+l11lll_l1_ (u"๋่ࠬศไ฼ࠤฬิสศำ๊หࠥ๐่ห์๋ฬࠬ汷"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ汸"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ汹"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ決")+l111ll_l1_+l11lll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ汻"),l11ll1_l1_,144,l11lll_l1_ (u"ࠪࠫ汼"),l11lll_l1_ (u"ࠫࠬ汽"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ汾"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭汿"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ沀")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้าะ่๊ࠢส่ึอฦอࠩ沁"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ沂"),146)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ沃"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ沄"),l11lll_l1_ (u"ࠬ࠭沅"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭沆"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ沇")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ沈"),l11lll_l1_ (u"ࠩࠪ沉"),147)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ沊"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭沋")+l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢฦะ๋ฮ๊สࠩ沌"),l11lll_l1_ (u"࠭ࠧ沍"),148)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沎"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ沏")+l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠศใ็หู๊ࠦาสํอࠬ沐"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁๆ๐ไๆࠩ沑"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ沒"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ沓")+l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ沔"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ沕"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ沖"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ沗")+l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡ็ึีา๐วหࠢ฼ีอ๐ษࠨ沘"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำาฯํอࠬ沙"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ沚"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ沛")+l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯูࠦาสํอࠬ沜"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืู้ไࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭沝"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ沞"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ沟")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣหั์ศ๋หࠪ沠"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡳࡦࡴ࡬ࡩࡸࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ没"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭沢"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ沣")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ沤"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ沥"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ沦"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭沧")+l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ࠣา฼ฮษࠡษ็้ึาู๋หࠪ沨"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰้ัษๆสล࠰อไโุสส๏ฯࠫฯูหอ࠰อไอ็฼อࠫࡹࡰ࠾ࡅࡄࡍࡘࡇࡨࡂࡄࠪ沩"),144)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沪"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ沫")+l111ll_l1_+l11lll_l1_ (u"ࠩส่฾ืวใࠢั฻อฯࠠศๆ่ีั฿๊สࠩ沬"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒ࠴࡫ࡗࡴ࠺ࡵࡴࡇ࠴࠸ࡔ࡮ࡺ࡞ࡄࡩࡐࡱࡍࡱࡸࡩࡶࡼࡵࡳ࡙ࡌࡴ࡮ࡨࡵࠫ沭"),144)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ沮"),l111ll_l1_+l11lll_l1_ (u"ࠬอูะษาหฯࠦวืษไอࠥ๐่ห์๋ฬࠬ沯"),l11lll_l1_ (u"࠭ࠧ沰"),144)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ沱"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ沲"),l11lll_l1_ (u"๊ࠩิฬࠦวๅษัฮ๏อัࠡี๋ๅࠥ๐ฮาฮๆࠤ๊์ࠠศๆหี๋อๅอࠩ河"),l11lll_l1_ (u"่ࠪศ์็ࠡี๋ๅࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣฬึ์วๆฮࠣ๎ํะ๊้สࠪ沴"))
	#if l1ll111ll1_l1_==1:
	#	url = l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭沵")
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠪࠩ沶"))
	#	xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡒࡦࡲ࡯ࡥࡨ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡶࡪࡦࡨࡳࡸ࠲ࠧ沷")+url+l11lll_l1_ (u"ࠧࠪࠩ沸"))
	#	#xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡔࡸࡲࡆࡪࡤࡰࡰࠫࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠬࠫ油"))
	return
l11lll_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡐࡅࡎࡔࡐࡂࡉࡈࠬࡺࡸ࡬ࠪ࠼ࠍࠍ࡭ࡺ࡭࡭࠮ࡦࡧ࠱ࡪࡡࡵࡣࠣࡁࠥࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠭ࡻࡲ࡭ࠫࠍࠍ࡮࡬ࠠࠨࡔࡨࡪࡦࡧࡴࠡࡃ࡯࠱ࡌࡧ࡭࡮ࡣ࡯ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡀࠠࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡺࡧࡶࠫ࠮ࠐࠉࡥࡦࠣࡁࠥࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡴࡡࡨࡧࠫࡰࡪࡴࠨࡥࡦࠬ࠭࠿ࠐࠉࠊ࡫ࡷࡩࡲࠦ࠽ࠡࡦࡧ࡟࡮ࡣࠊࠊࠋࡌࡒࡘࡋࡒࡕࡡࡌࡘࡊࡓ࡟ࡕࡑࡢࡑࡊࡔࡕࠩ࡫ࡷࡩࡲ࠯ࠊࠊࡋࡗࡉࡒ࡙ࠨࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤ沺")
def l1lll11l111l1_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ治"))
	return
def l1lll11l11l11_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭沼"))
	return
def PLAY(url,type):
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ沽")
	#items = re.findall(l11lll_l1_ (u"࠭ࡶ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ沾"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ沿")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ泀"))
	#return
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠫࡹࡷࡲࠩࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࠭࠮࠯࠰࠱ࠫࠡࠢࠪ࠯ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩࠪࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡐࡍࡃ࡜ࡣ࡛ࡏࡄࡆࡑࠫࡰ࡮ࡴ࡫ࡴ࡝࠳ࡡ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࡸࡾࡶࡥࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠍࠧࠨࠢ況")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1llll1lll_l1_(url):
	html,cc,data = l1lll111lll1l_l1_(url)
	dd = cc[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ泂")][l11lll_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ泃")][l11lll_l1_ (u"ࠬࡺࡡࡣࡵࠪ泄")]
	for l11l1lllll_l1_ in range(len(dd)):
		item = dd[l11l1lllll_l1_]
		l1lll11ll111l_l1_(item,url,str(l11l1lllll_l1_))
	ee = dd[0][l11lll_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ泅")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ泆")][l11lll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ泇")][l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ泈")]
	s = 0
	for l11l1lllll_l1_ in range(len(ee)):
		item = ee[l11l1lllll_l1_][l11lll_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ泉")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭泊")][0]
		if list(item[l11lll_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ泋")][l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ泌")].keys())[0]==l11lll_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ泍"): continue
		succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_ = l1lll11lll1l1_l1_(item)
		if not title:
			s += 1
			title = l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣีฬฬฬสࠢࠪ泎")+str(s)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ泏"),l111ll_l1_+title,url,144,l11lll_l1_ (u"ࠪࠫ泐"),str(l11l1lllll_l1_))
	key = re.findall(l11lll_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ泑"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ泒")+key[0]
	html,cc,l11llll11_l1_ = l1lll111lll1l_l1_(l11l11l_l1_)
	for l1ll111lll1l_l1_ in range(3,4):
		dd = cc[l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ泓")][l1ll111lll1l_l1_][l11lll_l1_ (u"ࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ泔")][l11lll_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ法")]
		for l11l1lllll_l1_ in range(len(dd)):
			item = dd[l11l1lllll_l1_]
			if l11lll_l1_ (u"ࠩ࡜ࡳࡺ࡚ࡵࡣࡧࠣࡔࡷ࡫࡭ࡪࡷࡰࠫ泖") in str(item): continue
			l1lll11ll111l_l1_(item)
	return
def ITEMS(url,data=l11lll_l1_ (u"ࠪࠫ泗"),index=0):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭泘"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ泙"),l11lll_l1_ (u"࠭ࠧ泚"))
	html,cc,l11llll11_l1_ = l1lll111lll1l_l1_(url,data)
	l11lllllll_l1_,ff = l11lll_l1_ (u"ࠧࠨ泛"),l11lll_l1_ (u"ࠨࠩ泜")
	#if l11lll_l1_ (u"ࠩࡲࡻࡳ࡫ࡲࠨ泝") in html.lower(): DIALOG_OK(l11lll_l1_ (u"ࠪࠫ泞"),l11lll_l1_ (u"ࠫࠬ泟"),l11lll_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠤࡪࡾࡩࡴࡶࠪ泠"),l11lll_l1_ (u"࠭ࡩ࡯ࠢ࡫ࡸࡲࡲࠧ泡"))
	owner = re.findall(l11lll_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࡎࡢ࡯ࡨࠦ࠳࠰࠿ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ波"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠨࠤࡹ࡭ࡩ࡫࡯ࡐࡹࡱࡩࡷࠨ࠮ࠫࡁࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ泣"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ泤"),html,re.DOTALL)
	if owner:
		l11lllllll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭泥")+owner[0][0]+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭泦")
		link = owner[0][1]
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ泧") not in link: link = l11ll1_l1_+link
		#if l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ注") in url and l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ泩") not in url and l11lll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ泪") not in url and l11lll_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ泫") not in url:
		if l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ泬") in url: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ泭"),l111ll_l1_+l11lllllll_l1_,link,144)
	#if cc==l11lll_l1_ (u"ࠬ࠭泮"): l1ll1lllll1ll_l1_(url,html) ; return
	l1ll1lllll11l_l1_ = [l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ泯"),l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ泰"),l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ泱"),l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭泲"),l11lll_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭泳"),l11lll_l1_ (u"ࠫࡸࡹ࠽ࠨ泴"),l11lll_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭泵"),l11lll_l1_ (u"࠭࡫ࡦࡻࡀࠫ泶"),l11lll_l1_ (u"ࠧࡣࡲࡀࠫ泷"),l11lll_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ泸")]
	l1ll1llll1l1l_l1_ = not any(value in url for value in l1ll1lllll11l_l1_)
	if l1ll1llll1l1l_l1_ and l11lllllll_l1_:
		l11ll1l11_l1_ = l11lll_l1_ (u"ࠩส่อำหࠨ泹")
		l1lll1lll_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ泺")
		l11ll11ll_l1_ = l11lll_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠨ泻")
		l1ll1llll1ll1_l1_ = l11lll_l1_ (u"ࠬอไใ่๋หฯ࠭泼")
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ泽"),l111ll_l1_+l11lllllll_l1_,url,9999)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤหัะࠨࠧ泾") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ泿"),l111ll_l1_+l11ll1l11_l1_,url,145,l11lll_l1_ (u"ࠩࠪ洀"),l11lll_l1_ (u"ࠪࠫ洁"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ洂"))
		if l11lll_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ洃") in html: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洄"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ洅"),144)
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ洆") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洇"),l111ll_l1_+l11ll11ll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ洈"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ洉") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ洊"),l111ll_l1_+l1ll1llll1ll1_l1_,url+l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ洋"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡖࡩࡦࡸࡣࡩࠤࠪ洌") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ洍"),l111ll_l1_+l11ll1l11_l1_,url,145,l11lll_l1_ (u"ࠩࠪ洎"),l11lll_l1_ (u"ࠪࠫ洏"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ洐"))
		if l11lll_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ洑") in html: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洒"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ洓"),144)
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ洔") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洕"),l111ll_l1_+l11ll11ll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ洖"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ洗") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ洘"),l111ll_l1_+l1ll1llll1ll1_l1_,url+l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ洙"),144)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ洚"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ洛"),l11lll_l1_ (u"ࠩࠪ洜"),9999)
	if l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ洝") in url:
		dd = cc[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭洞")][l11lll_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ洟")][l11lll_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ洠")][l11lll_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭洡")][l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ洢")]
		l1ll1llll1l11_l1_ = 0
		for i in range(len(dd)):
			if l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ洣") in list(dd[i].keys()):
				l1ll1llll11ll_l1_ = dd[i][l11lll_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ洤")]
				length = len(str(l1ll1llll11ll_l1_))
				if length>l1ll1llll1l11_l1_:
					l1ll1llll1l11_l1_ = length
					ff = l1ll1llll11ll_l1_
		if l1ll1llll1l11_l1_==0: return
	elif l11lll_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ津") in url or l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ洦") in url or l11lll_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ洧") in url or l11lll_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ洨") in url or l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ洩") in url or url==l11ll1_l1_:
		l1lll1111l1l1_l1_ = []
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ洪"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ洫"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ洬"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ洭"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ洮"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠯࠴ࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ洯"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ洰"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡗࡢࡶࡦ࡬ࡓ࡫ࡸࡵࡔࡨࡷࡺࡲࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣࠢ洱"))
		l1ll1lllll111_l1_,ff = l1ll1llllllll_l1_(cc,l11lll_l1_ (u"ࠪࠫ洲"),l1lll1111l1l1_l1_)
	if not ff:
		try:
			dd = cc[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭洳")][l11lll_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ洴")][l11lll_l1_ (u"࠭ࡴࡢࡤࡶࠫ洵")]
			l1ll1l111111_l1_ = l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ洶") in url or l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ洷") in url or l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ洸") in url
			l1lll111111ll_l1_ = l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ洹") in html or l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ洺") in html or l11lll_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ活") in html
			l1lll111111l1_l1_ = l11lll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ洼") in html or l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭洽") in html or l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭派") in html
			if l1ll1l111111_l1_ and (l1lll111111ll_l1_ or l1lll111111l1_l1_):
				for l11l1lllll_l1_ in range(len(dd)):
					if l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ洿") not in list(dd[l11l1lllll_l1_].keys()): continue
					ee = dd[l11l1lllll_l1_][l11lll_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ浀")]
					try: gg = ee[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ流")][l11lll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ浂")][l11lll_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ浃")][l11lll_l1_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ浄")][l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫ浅")][l11l1lllll_l1_]
					except: gg = ee
					try: link = gg[l11lll_l1_ (u"ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫ浆")][l11lll_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ浇")][l11lll_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ浈")][l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ浉")]
					except: continue
					if   l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ浊")		in link	and l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ测")		in url: ee = dd[l11l1lllll_l1_] ; break
					elif l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ浌")	in link	and l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭浍")	in url: ee = dd[l11l1lllll_l1_] ; break
					elif l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭济")	in link	and l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ浏")		in url: ee = dd[l11l1lllll_l1_] ; break
					else: ee = dd[0]
			elif l11lll_l1_ (u"ࠬࡨࡰ࠾ࠩ浐") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11lll_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ浑")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ浒")]
		except: pass
	if not ff: return
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ浓"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ浔"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ浕"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ浖"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ浗"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ浘"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ浙"))
	if l11lll_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ浚") not in url: l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩࡠ࡟ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭࡝ࠣ浛"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ浜"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ浝"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ浞"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ浟"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ浠"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ浡"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ浢"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ浣"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬ࠢ浤"))
	l1111l11l1l_l1_ = l1l1l11111ll_l1_(l11lll_l1_ (u"ࡺ࠭ใๅࠢๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ浥"))
	l1111l11ll1_l1_ = l1l1l11111ll_l1_(l11lll_l1_ (u"ࡻࠧไๆࠣห้็๊ะ์๋๋ฬะࠧ浦"))
	l1ll1llllll1l_l1_ = l1l1l11111ll_l1_(l11lll_l1_ (u"ࡵࠨๅ็ࠤฬ๊โ็๊สฮࠬ浧"))
	l11ll1lll1ll_l1_ = [l1111l11l1l_l1_,l1111l11ll1_l1_,l1ll1llllll1l_l1_,l11lll_l1_ (u"ࠨࡃ࡯ࡰࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ浨"),l11lll_l1_ (u"ࠩࡄࡰࡱࠦࡶࡪࡦࡨࡳࡸ࠭浩"),l11lll_l1_ (u"ࠪࡅࡱࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ浪")]
	l1ll1lllll1l1_l1_,gg = l1ll1llllllll_l1_(ff,index,l1lll1111l1l1_l1_)
	if l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ浫") in str(type(gg)) and any(value in str(gg[0]) for value in l11ll1lll1ll_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1lll1111l1l1_l1_ = []
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ浬"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ浭"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ浮"))
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ浯"))		#4
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ浰"))		#7
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ浱"))		#6
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ浲"))		#5
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞ࠤ浳"))
		l1ll1lllll111_l1_,item = l1ll1llllllll_l1_(gg,index2,l1lll1111l1l1_l1_)
		#if l1ll1lllll111_l1_ not in [l11lll_l1_ (u"࠭࠲ࠨ浴"),l11lll_l1_ (u"ࠧ࠵ࠩ浵"),l11lll_l1_ (u"ࠨ࠷ࠪ浶")]: l1lll11ll111l_l1_(item)		# 2,4,7
		#else: l1lll11ll111l_l1_(item,url,str(index2))
		l1lll11ll111l_l1_(item,url,str(index2))
		if l1ll1lllll111_l1_==l11lll_l1_ (u"ࠩ࠷ࠫ海"):
			try:
				hh = item[l11lll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ浸")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ浹")][l11lll_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ浺")][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ浻")]
				for l1lll11l11111_l1_ in range(len(hh)):
					l11lll11lll1_l1_ = hh[l1lll11l11111_l1_]
					l1lll11ll111l_l1_(l11lll11lll1_l1_)
			except: pass
	l1lllll1l1l_l1_ = False
	if l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭浼") not in url and l1ll1lllll1l1_l1_==l11lll_l1_ (u"ࠨ࠺ࠪ浽"): l1lllll1l1l_l1_ = True
	if l11lll_l1_ (u"ࠩ࠽࠾࠿࠭浾") in l11llll11_l1_: l1lll11l1l11l_l1_,key,l1lll11lll11l_l1_,l1lll11l111ll_l1_,token,l1lll111l1l1l_l1_ = l11llll11_l1_.split(l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ浿"))
	else: l1lll11l1l11l_l1_,key,l1lll11lll11l_l1_,l1lll11l111ll_l1_,token,l1lll111l1l1l_l1_ = l11lll_l1_ (u"ࠫࠬ涀"),l11lll_l1_ (u"ࠬ࠭涁"),l11lll_l1_ (u"࠭ࠧ涂"),l11lll_l1_ (u"ࠧࠨ涃"),l11lll_l1_ (u"ࠨࠩ涄"),l11lll_l1_ (u"ࠩࠪ涅")
	l11l11l_l1_,l1lll11ll1l_l1_ = l11lll_l1_ (u"ࠪࠫ涆"),l11lll_l1_ (u"ࠫࠬ涇")
	if menuItemsLIST:
		l1lll1111111l_l1_ = str(menuItemsLIST[-1][1])
		if   l111ll_l1_+l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ消") in l1lll1111111l_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ涉")
		elif l111ll_l1_+l11lll_l1_ (u"ࠧࡖࡕࡈࡖࠬ涊") in l1lll1111111l_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ涋")
		elif l111ll_l1_+l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ涌") in l1lll1111111l_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"ࠪࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭涍")
	if l11lll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡷࠧ࠭涎") in html and l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ涏") not in url and not l1lllll1l1l_l1_ and l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤࠨ涐") not in url:	# and (index!=l11lll_l1_ (u"ࠧࠨ涑") or l11lll_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ涒") in url or l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ涓") in url or l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ涔") in url or l11lll_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ涕") in url):
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡥࡡ࡫ࡣࡻࡃࡨࡺ࡯࡬ࡧࡱࡁࠬ涖")+l1lll11lll11l_l1_
	elif l11lll_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨࠧ涗") in html and l11lll_l1_ (u"ࠧࡣࡲࡀࠫ涘") not in url and l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ涙") in url or l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ涚") in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ涛")+key
	elif l11lll_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ涜") in html and l11lll_l1_ (u"ࠬࡨࡰ࠾ࠩ涝") not in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ涞")+key
	if l11l11l_l1_: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ涟"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ涠"),l11l11l_l1_,144,l1lll11ll1l_l1_,l11lll_l1_ (u"ࠩࠪ涡"),l11llll11_l1_)
	return
def l1ll1llllllll_l1_(l11llll1ll11_l1_,l11llllll111_l1_,l1lll111l11l1_l1_):
	cc = l11llll1ll11_l1_
	ff,index = l11llll1ll11_l1_,l11llllll111_l1_
	gg,index2 = l11llll1ll11_l1_,l11llllll111_l1_
	item,render = l11llll1ll11_l1_,l11llllll111_l1_
	count = len(l1lll111l11l1_l1_)
	for l11l1lllll_l1_ in range(count):
		try:
			out = eval(l1lll111l11l1_l1_[l11l1lllll_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"ࠪࠫ涢")
			return str(l11l1lllll_l1_+1),out
		except: pass
	return l11lll_l1_ (u"ࠫࠬ涣"),l11lll_l1_ (u"ࠬ࠭涤")
def l1lll11lll1l1_l1_(item):
	try: l1lll11l1ll1l_l1_ = list(item.keys())[0]
	except: return False,l11lll_l1_ (u"࠭ࠧ涥"),l11lll_l1_ (u"ࠧࠨ润"),l11lll_l1_ (u"ࠨࠩ涧"),l11lll_l1_ (u"ࠩࠪ涨"),l11lll_l1_ (u"ࠪࠫ涩"),l11lll_l1_ (u"ࠫࠬ涪"),l11lll_l1_ (u"ࠬ࠭涫")
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_ = False,l11lll_l1_ (u"࠭ࠧ涬"),l11lll_l1_ (u"ࠧࠨ涭"),l11lll_l1_ (u"ࠨࠩ涮"),l11lll_l1_ (u"ࠩࠪ涯"),l11lll_l1_ (u"ࠪࠫ涰"),l11lll_l1_ (u"ࠫࠬ涱"),l11lll_l1_ (u"ࠬ࠭液")
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ涳"),str(item))
	render = item[l1lll11l1ll1l_l1_]
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡷࡱࡴࡱࡧࡹࡢࡤ࡯ࡩ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ涴"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡩࡳࡷࡳࡡࡵࡶࡨࡨ࡙࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ涵"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ涶"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ涷"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ涸"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ涹"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ涺"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ涻"))
	l1ll1lllll111_l1_,title = l1ll1llllllll_l1_(item,render,l1lll1111l1l1_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ涼"),l11lll_l1_ (u"ࠩࠪ涽"),l11lll_l1_ (u"ࠪࠫ涾"),title)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ涿"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ淀"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ淁"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ淂")) # required for l11lll1lllll_l1_ l1lllll1l1l_l1_
	l1ll1lllll111_l1_,link = l1ll1llllllll_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ淃"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ淄"))
	l1ll1lllll111_l1_,l1llll_l1_ = l1ll1llllllll_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࠨ࡟ࠥ淅"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࡖࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ淆"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡇࡵࡴࡵࡱࡰࡔࡦࡴࡥ࡭ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ淇"))
	l1ll1lllll111_l1_,count = l1ll1llllllll_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ淈"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ淉"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ淊"))
	l1ll1lllll111_l1_,l1l111l1ll_l1_ = l1ll1llllllll_l1_(item,render,l1lll1111l1l1_l1_)
	if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ淋") in l1l111l1ll_l1_: l1l111l1ll_l1_,l111l1111ll_l1_ = l11lll_l1_ (u"ࠪࠫ淌"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ淍")
	if l11lll_l1_ (u"๋ࠬศศึิࠫ淎") in l1l111l1ll_l1_: l1l111l1ll_l1_,l111l1111ll_l1_ = l11lll_l1_ (u"࠭ࠧ淏"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ淐")
	if l11lll_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ淑") in list(render.keys()):
		l1lll11ll11l1_l1_ = str(render[l11lll_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ淒")])
		if l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ淓") in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠫࠩࡀࠧ淔")
		if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠣࡒࡔ࡝ࠧ淕") in l1lll11ll11l1_l1_: l111l1111ll_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ淖")
		if l11lll_l1_ (u"ࠧࡃࡷࡼࠫ淗") in l1lll11ll11l1_l1_ or l11lll_l1_ (u"ࠨࡔࡨࡲࡹ࠭淘") in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿࠭淙")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡸ๊ࠫฮวีำࠪ淚")) in l1lll11ll11l1_l1_: l111l1111ll_l1_ = l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ淛")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡺ࠭ิาษฤࠫ淜")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"࠭ࠤࠥ࠼ࠪ淝")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡵࠨษึฮหาวาࠩ淞")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠨࠦࠧ࠾ࠬ淟")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ淠")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠪࠨ࠿࠭淡")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ淢") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠬࡅࠧ淣"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ淤") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ淥")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll111llll1_l1_: title = l1lll111llll1_l1_+l11lll_l1_ (u"ࠨࠢࠣࠫ淦")+title
	#title = unescapeHTML(title)
	l1l111l1ll_l1_ = l1l111l1ll_l1_.replace(l11lll_l1_ (u"ࠩ࠯ࠫ淧"),l11lll_l1_ (u"ࠪࠫ淨"))
	count = count.replace(l11lll_l1_ (u"ࠫ࠱࠭淩"),l11lll_l1_ (u"ࠬ࠭淪"))
	count = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࠭ࠪ淫"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"ࠧࠨ淬")
	return True,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_
def l1lll11ll111l_l1_(item,url=l11lll_l1_ (u"ࠨࠩ淭"),index=l11lll_l1_ (u"ࠩࠪ淮")):
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_ = l1lll11lll1l1_l1_(item)
	#if l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ淯") in url and index==l11lll_l1_ (u"ࠫ࠵࠭淰"):
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ深"),l111ll_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ淲") in str(item): return	# l1lll11lll11l_l1_ not items
	elif l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ淳") in str(item): return			# l1lll11l1llll_l1_ not items
	elif not link and l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ淴") in url: return			# separator l1ll1llll11l1_l1_ list not items
	elif title and not link and (l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ淵") in url or l11lll_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ淶") in str(item) or url==l11ll1_l1_):
		title = l11lll_l1_ (u"ࠫࡂࡃ࠽ࠡࠩ混")+title+l11lll_l1_ (u"ࠬࠦ࠽࠾࠿ࠪ淸")
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ淹"),l111ll_l1_+title,l11lll_l1_ (u"ࠧࠨ淺"),9999)
	elif title and l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ添") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ淼"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ淽"),9999)
	elif l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ淾") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ淿"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif not title: return
	elif l111l1111ll_l1_: addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ渀"),l111ll_l1_+l111l1111ll_l1_+title,link,143,l1llll_l1_)
	#elif l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭渁") in link and l11lll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ渂") not in link and l11lll_l1_ (u"ࠩࡷࡁ࠵࠭渃") not in link:
	#	l1lll111lllll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ渄"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭清")+l1lll111lllll_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ渆"),l111ll_l1_+l11lll_l1_ (u"࠭ࡌࡊࡕࡗࠫ渇")+count+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ済")+title,link,144,l1llll_l1_)
	elif l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ渉") in link or l11lll_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ渊") in link:
		if l11lll_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ渋") in link and l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ渌") not in link:
			l1lll111lllll_l1_ = link.split(l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ渍"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ渎")+l1lll111lllll_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ渏"),l111ll_l1_+l11lll_l1_ (u"ࠨࡎࡌࡗ࡙࠭渐")+count+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭渑")+title,link,144,l1llll_l1_)
		else:
			link = link.split(l11lll_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ渒"),1)[0]
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ渓"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	else:
		type = l11lll_l1_ (u"ࠬ࠭渔")
		if not link: link = url
		#if l11lll_l1_ (u"࠭ࡳࡴ࠿ࠪ渕") in link: link = url
		#elif l11lll_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ渖") in link: link = url		# not needed it will stop l1ll1lllllll1_l1_ l11lll1lllll_l1_ l1lllll1l1l_l1_
		elif not any(value in link for value in [l11lll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ渗"),l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭渘"),l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭渙"),l11lll_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ渚"),l11lll_l1_ (u"ࠬࡹࡳ࠾ࠩ減"),l11lll_l1_ (u"࠭ࡢࡱ࠿ࠪ渜")]):
			if l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ渝")	in link or l11lll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ渞") in link: type = l11lll_l1_ (u"ࠩࡆࡌࡓࡒࠧ渟")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ渠")
			if l11lll_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ渡") in link: type = l11lll_l1_ (u"࡛ࠬࡓࡆࡔࠪ渢")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ渣")
			index,l1lll11l11lll_l1_ = l11lll_l1_ (u"ࠧࠨ渤"),l11lll_l1_ (u"ࠨࠩ渥")
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ渦"),l111ll_l1_+type+title,link,144,l1llll_l1_,index)
	return
def l1lll111lll1l_l1_(url,data=l11lll_l1_ (u"ࠪࠫ渧"),request=l11lll_l1_ (u"ࠫࠬ渨")):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ温"))
	#if l11lll_l1_ (u"࠭࡟ࡠࠩ渪") in l1lll11l11lll_l1_: l1lll11l11lll_l1_ = l11lll_l1_ (u"ࠧࠨ渫")
	#if l11lll_l1_ (u"ࠨࡵࡶࡁࠬ測") in url: url = url.split(l11lll_l1_ (u"ࠩࡶࡷࡂ࠭渭"))[0]
	if request==l11lll_l1_ (u"ࠪࠫ渮"): request = l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ港")
	l111lll1l1_l1_ = l1l11l11l_l1_()
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ渰"):l111lll1l1_l1_,l11lll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭渱"):l11lll_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ渲")}
	#l1l1ll1ll_l1_ = headers.copy()
	if l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ渳") in data: l1lll11l1l11l_l1_,key,l1lll11lll11l_l1_,l1lll11l111ll_l1_,token,l1lll111l1l1l_l1_ = data.split(l11lll_l1_ (u"ࠩ࠽࠾࠿࠭渴"))
	else: l1lll11l1l11l_l1_,key,l1lll11lll11l_l1_,l1lll11l111ll_l1_,token,l1lll111l1l1l_l1_ = l11lll_l1_ (u"ࠪࠫ渵"),l11lll_l1_ (u"ࠫࠬ渶"),l11lll_l1_ (u"ࠬ࠭渷"),l11lll_l1_ (u"࠭ࠧ游"),l11lll_l1_ (u"ࠧࠨ渹"),l11lll_l1_ (u"ࠨࠩ渺")
	if l11lll_l1_ (u"ࠩࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭渻") in url:
		l11llll11_l1_ = {}
		l11llll11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ渼")] = {l11lll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ渽"):{l11lll_l1_ (u"ࠧ࡮࡬ࠣ渾"):l11lll_l1_ (u"ࠨࡡࡳࠤ渿"),l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ湀"):l11lll_l1_ (u"࡙ࠣࡈࡆࠧ湁"),l11lll_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ湂"):l1lll11l111ll_l1_}}
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ湃"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠷ࡳࡵࠩ湄"))
	elif l11lll_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ湅") in url and l1lll11l1l11l_l1_:
		l11llll11_l1_ = {l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ湆"):token}
		l11llll11_l1_[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ湇")] = {l11lll_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ湈"):{l11lll_l1_ (u"ࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ湉"):l1lll11l1l11l_l1_,l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ湊"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ湋"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ湌"):l1lll11l111ll_l1_}}
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ湍"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠴ࡱࡨࠬ湎"))
	elif l11lll_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ湏") in url and l1lll111l1l1l_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ湐"):l11lll_l1_ (u"ࠪ࠵ࠬ湑"),l11lll_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ湒"):l1lll11l111ll_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ湓"):l11lll_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࡁࠬ湔")+l1lll111l1l1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ湕"),url,l11lll_l1_ (u"ࠨࠩ湖"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ湗"),l11lll_l1_ (u"ࠪࠫ湘"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ湙"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ湚"),url,l11lll_l1_ (u"࠭ࠧ湛"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠧࠨ湜"),l11lll_l1_ (u"ࠨࠩ湝"),l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ湞"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ湟"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠫࠧࡩࡶࡦࡴࠥ࠲࠯ࡅࠢࡷࡣ࡯ࡹࡪࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ湠"),html,re.DOTALL|re.I)
	if tmp: l1lll11l111ll_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ湡"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ湢"),html,re.DOTALL|re.I)
	if tmp: l1lll11l1l11l_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ湣"),html,re.DOTALL|re.I)
	if tmp: l1lll11lll11l_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭湤") in list(cookies.keys()): l1lll111l1l1l_l1_ = cookies[l11lll_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ湥")]
	data = l1lll11l1l11l_l1_+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ湦")+key+l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ湧")+l1lll11lll11l_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ湨")+l1lll11l111ll_l1_+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ湩")+token+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ湪")+l1lll111l1l1l_l1_
	if request==l11lll_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ湫") and l11lll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ湬") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ湭"),html,re.DOTALL)
		if not l111ll1ll1_l1_: l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ湮"),html,re.DOTALL)
		l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠬࡹࡴࡳࠩ湯"),l111ll1ll1_l1_[0])
	elif request==l11lll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ湰") and l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ湱") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ湲"),html,re.DOTALL)
		l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭湳"),l111ll1ll1_l1_[0])
	elif l11lll_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭湴") not in html: l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠫࡸࡺࡲࠨ湵"),html)
	else: l1lll1111l1ll_l1_ = l11lll_l1_ (u"ࠬ࠭湶")
	#open(l11lll_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳ࡰࡳࡰࡰࠪ湷"),l11lll_l1_ (u"ࠧࡸࠩ湸")).write(str(l1lll1111l1ll_l1_))
	#open(l11lll_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬ湹"),l11lll_l1_ (u"ࠩࡺࠫ湺")).write(html)
	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ湻"),data)
	return html,l1lll1111l1ll_l1_,data
def l1lll11ll1ll1_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭湼"),l11lll_l1_ (u"ࠬ࠱ࠧ湽"))
	l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲࡷࡨࡶࡾࡃࠧ湾")+search
	ITEMS(l11l11l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ湿"),l11lll_l1_ (u"ࠨ࠭ࠪ満"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࠫ溁")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭溂") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡑࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ溃")
		elif l11lll_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ溄") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭溅")
		elif l11lll_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬ溆") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄ࡫ࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ溇")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111l1lll_l1_
	else:
		l1lll111l1ll1_l1_,l1lll11111lll_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠩࠪ溈")
		l1lll1111l11l_l1_ = [l11lll_l1_ (u"ࠪฬิ๎ๆࠡฬิฮ๏ฮࠧ溉"),l11lll_l1_ (u"ࠫฯืส๋สࠣัุฮࠠๆั์ࠤฬ๊ีๅหࠪ溊"),l11lll_l1_ (u"ࠬะัห์หࠤาูศࠡฬสี๏ิࠠศๆอั๊๐ไࠨ溋"),l11lll_l1_ (u"࠭สาฬํฬࠥำำษࠢ฼ำิࠦวๅ็ืห์ีวหࠩ溌"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิสࠣห้ะโ๋์่ࠫ溍")]
		l1lll11l1lll1_l1_ = [l11lll_l1_ (u"ࠨࠩ溎"),l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡃࠨ࠶࠺࠹ࡄࠨ溏"),l11lll_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡌࠩ࠷࠻࠳ࡅࠩ源"),l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡑࠪ࠸࠵࠴ࡆࠪ溑"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡊࠫ࠲࠶࠵ࡇࠫ溒")]
		l1lll11ll11ll_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊สาฬํฬࠬ溓"),l1lll1111l11l_l1_)
		if l1lll11ll11ll_l1_ == -1: return
		l1lll111l1l11_l1_ = l1lll11l1lll1_l1_[l1lll11ll11ll_l1_]
		html,c,data = l1lll111lll1l_l1_(l11l11l_l1_+l1lll111l1l11_l1_)
		if c:
			d = c[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ溔")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ溕")][l11lll_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ準")][l11lll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ溗")][l11lll_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ溘")][l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭溙")][l11lll_l1_ (u"࠭ࡧࡳࡱࡸࡴࡸ࠭溚")]
			for l1lll11111ll1_l1_ in range(len(d)):
				group = d[l1lll11111ll1_l1_][l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡍࡲࡰࡷࡳࡖࡪࡴࡤࡦࡴࡨࡶࠬ溛")][l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ溜")]
				for l1lll11ll1lll_l1_ in range(len(group)):
					render = group[l1lll11ll1lll_l1_][l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩ溝")]
					if l11lll_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ溞") in list(render.keys()):
						link = render[l11lll_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ溟")][l11lll_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ溠")][l11lll_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ溡")][l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ溢")]
						link = link.replace(l11lll_l1_ (u"ࠨ࡞ࡸ࠴࠵࠸࠶ࠨ溣"),l11lll_l1_ (u"ࠩࠩࠫ溤"))
						title = render[l11lll_l1_ (u"ࠪࡸࡴࡵ࡬ࡵ࡫ࡳࠫ溥")]
						title = title.replace(l11lll_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦࠧ溦"),l11lll_l1_ (u"ࠬ࠭溧"))
						if l11lll_l1_ (u"࠭ลำษ็อࠥอไโๆอีࠬ溨") in title: continue
						if l11lll_l1_ (u"ࠧใษษ้ฮࠦสี฼ํ่ࠬ溩") in title:
							title = l11lll_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ溪")+title
							l1lll1lll_l1_ = title
							l1lllllll1_l1_ = link
						if l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠬ溫") in title: continue
						title = title.replace(l11lll_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠠࠨ溬"),l11lll_l1_ (u"ࠫࠬ溭"))
						if l11lll_l1_ (u"ࠬࡘࡥ࡮ࡱࡹࡩࠬ溮") in title: continue
						if l11lll_l1_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ溯") in title:
							title = l11lll_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ溰")+title
							l1lll1lll_l1_ = title
							l1lllllll1_l1_ = link
						if l11lll_l1_ (u"ࠨࡕࡲࡶࡹࠦࡢࡺࠩ溱") in title: continue
						l1lll111l1ll1_l1_.append(escapeUNICODE(title))
						l1lll11111lll_l1_.append(link)
		if not l1lll1lll_l1_: l1lll11l1l1ll_l1_ = l11lll_l1_ (u"ࠩࠪ溲")
		else:
			l1lll111l1ll1_l1_ = [l11lll_l1_ (u"ࠪฬิ๎ๆࠡใ็ฮึ࠭溳"),l1lll1lll_l1_]+l1lll111l1ll1_l1_
			l1lll11111lll_l1_ = [l11lll_l1_ (u"ࠫࠬ溴"),l1lllllll1_l1_]+l1lll11111lll_l1_
			l1lll11ll1l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้็ไหำࠪ溵"),l1lll111l1ll1_l1_)
			if l1lll11ll1l1l_l1_ == -1: return
			l1lll11l1l1ll_l1_ = l1lll11111lll_l1_[l1lll11ll1l1l_l1_]
		if l1lll11l1l1ll_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll11l1l1ll_l1_
		elif l1lll111l1l11_l1_: l11l1l1_l1_ = l11l11l_l1_+l1lll111l1l11_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡫࡯࡬ࡵࡧࡵ࠱ࡩࡸ࡯ࡱࡦࡲࡻࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡹ࡫࡭࠮ࡵࡨࡧࡹ࡯࡯࡯ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡪࡨࠣࠫࡗ࡫࡭ࡰࡸࡨࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷ࠭ࠬࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡖࡳࡷࡺࠠࡣࡻࠪ࠰࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠬࠎࠎࠏࠉࠊ࡫ࡩࠤࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹࡥࡢࡴࡦ࡬࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠉࠊ࡫ࡩࠤ࡙ࠬ࡯ࡳࡶࠣࡦࡾࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡳࡷࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠣࠤࠥ溶")
	ITEMS(l11l1l1_l1_)
	return
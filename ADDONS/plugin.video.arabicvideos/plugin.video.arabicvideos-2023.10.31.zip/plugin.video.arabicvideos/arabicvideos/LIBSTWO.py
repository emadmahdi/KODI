# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1llll1l_l1_ import *
import traceback,bidi.algorithm
#import l1l1l1ll11ll_l1_
script_name = l11lll_l1_ (u"࠭ࡌࡊࡄࡖࡘ࡜ࡕࠧ㣻")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1lll11lll11_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ㣼"))
	l1l1l11111_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ㣽"))
	l11l1111lll_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭㣾"))
	l1l1l11llll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㣿"),l11lll_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㤀"),l11lll_l1_ (u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪ㤁"))
	l111l1l11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㤂"),l11lll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㤃"),l11lll_l1_ (u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨ㤄"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㤅"),l11lll_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㤆"),l11lll_l1_ (u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫ㤇"))
	half_triangular_colon = l11lll_l1_ (u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭㤈")
	from urllib.parse import quote as _1ll1l11lll1_l1_
	#from io import BytesIO as _1ll111l1lll_l1_
else:
	l1lll11lll11_l1_ = xbmc.translatePath(l11lll_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ㤉"))
	l1l1l11111_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ㤊"))
	l11l1111lll_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ㤋"))
	l1l1l11llll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㤌"),l11lll_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㤍"),l11lll_l1_ (u"ࠫࡆࡪࡤࡰࡰࡶ࠶࠼࠴ࡤࡣࠩ㤎"))
	l111l1l11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㤏"),l11lll_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㤐"),l11lll_l1_ (u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ㤑"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㤒"),l11lll_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㤓"),l11lll_l1_ (u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪ㤔"))
	half_triangular_colon = l11lll_l1_ (u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬ㤕").encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤖"))
	from urllib import quote as _1ll1l11lll1_l1_
	#from StringIO import StringIO as _1ll111l1lll_l1_
#l1lll1ll1lll_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11l1lll1l1_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡈࡲࡰࡩ࡫ࡲࡑࡣࡷ࡬ࠬ㤗"))
l1ll1l1l111l_l1_ = os.path.join(l11l1111lll_l1_,l11lll_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ㤘"))
l1ll1lllll1l_l1_ = os.path.join(l11l1111lll_l1_,l11lll_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧ㤙"))
iptv1_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ㤚"))
iptv2_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㤛"))
m3u_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ㤜"))
#l1lll1111111_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬࡾࡴࡳࡧࡤࡱࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㤝"))
#l1ll1lll1l1l_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭࡬ࡢࡵࡷࡱࡪࡴࡵ࠯ࡦࡤࡸࠬ㤞"))
favoritesfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨ㤟"))
#dummyiptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨࡦࡸࡱࡲࡿࡩࡱࡶࡹ࠲ࡩࡧࡴࠨ㤠"))
fulliptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩ࡬ࡴࡹࡼࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫ㤡"))
fullm3ufile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪࡱ࠸ࡻࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫ㤢"))
l1l111l11lll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡤࡢࡶࠪ㤣"))
l1l111llllll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨ㤤"))
l11lll1llll_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ㤥"))
defaulticon = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩ㤦"))
defaultthumb = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫ㤧"))
defaultfanart = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭㤨"))
defaultbanner = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ㤩"))
defaultlandscape = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫ㤪"))
defaultposter = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩ㤫"))
defaultclearlogo = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭㤬"))
defaultclearart = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭㤭"))
l1l1lll11l11_l1_ = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨ㤮"))
l1ll11llll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ㤯"))
l1l1ll1l1lll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㤰"),l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ㤱"),addon_id,l11lll_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㤲"))
l1lll1l1ll11_l1_ = os.path.join(l1lll11lll11_l1_,l11lll_l1_ (u"࠭࡭ࡦࡦ࡬ࡥࠬ㤳"),l11lll_l1_ (u"ࠧࡇࡱࡱࡸࡸ࠭㤴"),l11lll_l1_ (u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫ㤵"))
FOLDERS_COUNT = 5
text_numbers = [l11lll_l1_ (u"ุࠩๅึ࠭㤶"),l11lll_l1_ (u"ࠪวํ๊ࠧ㤷"),l11lll_l1_ (u"ࠫะอๆ๋ࠩ㤸"),l11lll_l1_ (u"ࠬัวๅอࠪ㤹"),l11lll_l1_ (u"࠭ัศส฼ࠫ㤺"),l11lll_l1_ (u"ࠧฯษ่ืࠬ㤻"),l11lll_l1_ (u"ࠨีสำุ࠭㤼"),l11lll_l1_ (u"ࠩึหอ฿ࠧ㤽"),l11lll_l1_ (u"ࠪฯฬ๋ๆࠨ㤾"),l11lll_l1_ (u"ࠫฯอำฺࠩ㤿"),l11lll_l1_ (u"ࠬ฿วีำࠪ㥀")]
l1ll1llll1ll_l1_ = l11lll_l1_ (u"࠭⸻ࠡ⼟ࠣ⸮ࠥ⹁ࠧ㥁")
NO_CACHE = 0
l1ll1111l111_l1_ = 30*l1l111111ll_l1_
l1lll1111_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
VERYLONG_CACHE = 30*l11l1llll11_l1_
l11ll1111ll_l1_ = 1*HOUR
l1ll1llll111_l1_ = [l11lll_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭㥂")]
l1lll11ll1ll_l1_ = [l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ㥃"),l11lll_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ㥄"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧ㥅"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㥆"),l11lll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ㥇"),l11lll_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭㥈"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ㥉"),l11lll_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ㥊")]
l1lll11ll1ll_l1_ += [l11lll_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ㥋"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ㥌"),l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭㥍"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㥎"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ㥏"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㥐"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ㥑"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ㥒")]
l1l111l1l1l1_l1_ = [l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㥓"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ㥔"),l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㥕"),l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ㥖")]
l1l111l1l1l1_l1_ += [l11lll_l1_ (u"ࠧࡎ࠵ࡘࠫ㥗"),l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ㥘"),l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭㥙"),l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ㥚")]
l1l111l1l1l1_l1_ += [l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㥛"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㥜"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㥝")]
l1l111l1l1l1_l1_ += [l11lll_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㥞"),l11lll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㥟"),l11lll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㥠"),l11lll_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㥡"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭㥢"),l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㥣")]
l1l111l1l1l1_l1_ += [l11lll_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㥤"),l11lll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㥥"),l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㥦"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㥧"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㥨"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㥩")]
#l1l111l1l1l1_l1_ += [l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㥪"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ㥫"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭㥬"),l11lll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㥭")]
#l1l111l1l1l1_l1_ += [l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ㥮"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘ࠭㥯"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࠨ㥰"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࠨ㥱")]
l1l1l11l1ll_l1_ = [l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㥲"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ㥳"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㥴"),l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㥵")]
l1l1l11l1ll_l1_ += [l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㥶"),l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ㥷"),l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㥸"),l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㥹"),l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ㥺")]
l1l1l1l1l11_l1_ = [l11lll_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㥻"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㥼"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㥽"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㥾"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㥿"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㦀"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ㦁")]
l1l1l1l1l11_l1_ += [l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㦂"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㦃"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㦄"),l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㦅"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㦆")]
#l1l1l1l1l11_l1_ += [l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ㦇"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㦈")]
l1l1ll1ll1l_l1_ = [l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㦉"),l11lll_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ㦊"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㦋"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㦌"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ㦍"),l11lll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㦎"),l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㦏"),l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㦐")]
l1l1ll1ll1l_l1_ += [l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㦑"),l11lll_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㦒"),l11lll_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㦓"),l11lll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㦔"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㦕"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㦖")]
#l1l1ll1ll1l_l1_ += [l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ㦗"),l11lll_l1_ (u"ࠩࡋࡉࡑࡇࡌࠨ㦘"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ㦙"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㦚"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㦛"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㦜"),l11lll_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㦝")]
l1l1lll1l1l1_l1_  = [l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㦞"),l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㦟"),l11lll_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㦠"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㦡"),l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㦢"),l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㦣"),l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㦤"),l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㦥")]
l1l1lll1l1l1_l1_ += [l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㦦"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㦧"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㦨"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㦩"),l11lll_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㦪"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㦫"),l11lll_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㦬"),l11lll_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㦭"),l11lll_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㦮")]
l1l1lll1l1l1_l1_ += [l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㦯"),l11lll_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㦰"),l11lll_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㦱"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㦲"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㦳"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㦴"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㦵")]
l1l1lll1l1l1_l1_ += [l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㦶"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㦷"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㦸"),l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㦹"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㦺"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㦻"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㦼")]
l1l1lll1l1l1_l1_ += [l11lll_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㦽"),l11lll_l1_ (u"ࠬ࡟ࡁࡒࡑࡗࠫ㦾"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㦿"),l11lll_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㧀"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㧁"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㧂"),l11lll_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㧃")]
l1l11llll1l1_l1_  = [l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ㧄"),l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㧅"),l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㧆"),l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ㧇")]
l1l11llll1l1_l1_ += [l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ㧈"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ㧉")]
l1l11llll1l1_l1_ += [l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ㧊"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ㧋"),l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ㧌")]
l1l11llll1l1_l1_ += [l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ㧍"),l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ㧎"),l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭㧏")]
l1l11llll1l1_l1_ += [l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ㧐"),l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㧑"),l11lll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㧒")]
#l1l11llll1l1_l1_ += [l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ㧓"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ㧔")]
#l1l11llll1l1_l1_ += [l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࠫ㧕"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࠫ㧖"),l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࠬ㧗")]
l1l1l11lll11_l1_ = [l11lll_l1_ (u"ࠪࡑ࠸࡛ࠧ㧘"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ㧙"),l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㧚"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㧛"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㧜")]		# l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㧝"),l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ㧞")
l1l1l1lllll_l1_ = l1l1lll1l1l1_l1_+l1l11llll1l1_l1_
l1l1ll11ll11_l1_ = l1l1lll1l1l1_l1_+l1l1l11lll11_l1_
l11l1l1l1l1_l1_ = l1l1lll1l1l1_l1_+l1l1l11lll11_l1_
l1l1l1llll1_l1_ = l1l111l1l1l1_l1_+l1l1l1l1l11_l1_+l1l1ll1ll1l_l1_+l1l1l11l1ll_l1_
# l1ll1llllll1_l1_ will not show l1llll1lll11_l1_ errors and will not exit from the l11l11lll11_l1_
l1llllllll11_l1_ = [
						l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㧟")
						,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㧠")
						,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭㧡")
						,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ㧢")
						,l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ㧣")
						,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ㧤")
						,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭㧥")
						,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ㧦")
						,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㧧")
						,l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ㧨")
						,l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭㧩")
						,l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ㧪")
						]
l1111llll11_l1_ = l1llllllll11_l1_+[
				 l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㧫")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㧬")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭㧭")
				,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧ㧮")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ㧯")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ㧰")
				,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ㧱")
				,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪ㧲")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫ㧳")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㧴")
				,l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ㧵")
				,l11lll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ㧶")
				,l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ㧷")
				,l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ㧸")
				,l11lll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ㧹")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㧺")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ㧻")
				#,l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㧼")
				#,l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㧽")
				#,l11lll_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ㧾")
				#,l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㧿")
				#,l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ㨀")
				#,l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡌࡋࡔࡠࡎࡄࡘࡊ࡙ࡔࡠࡘࡈࡖࡘࡏࡏࡏࡡࡑ࡙ࡒࡈࡅࡓࡕ࠰࠵ࡸࡺࠧ㨁")
				#,l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㨂")
				#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㨃")
				#,l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㨄")
				]
l1lll1l1l1ll_l1_ = [l11lll_l1_ (u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ㨅"),l11lll_l1_ (u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨ㨆"),l11lll_l1_ (u"ࠨ࠳࠱࠴࠳࠶࠮࠲ࠩ㨇"),l11lll_l1_ (u"ࠩ࠻࠲࠽࠴࠴࠯࠶ࠪ㨈"),l11lll_l1_ (u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠸࠮࠳࠴࠵ࠫ㨉"),l11lll_l1_ (u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠰࠯࠴࠵࠴ࠬ㨊")]
l1ll11l_l1_ = {
			#,l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㨋")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ㨌")]
			#,l11lll_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㨍")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡ࡭࡭ࡤࡻࡹ࡮ࡡࡳࡶࡹ࠲࡮ࡸࠧ㨎")]
			#,l11lll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ㨏")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴࡮ࡦࡶࠪ㨐")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙࠵ࡄࡈࡗ࡙࠭㨑")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ㨒")]
			#,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ㨓")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭㨔")]
			#,l11lll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ㨕")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡦࡩࡼࡲࡴࡽ࠮࡭࡫ࡹࡩࠬ㨖")]
			#,l11lll_l1_ (u"ࠪࡌࡊࡒࡁࡍࠩ㨗")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠺ࡨࡦ࡮ࡤࡰ࠳ࡳࡥࠨ㨘")]
			#,l11lll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ㨙")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧࠪ㨚"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭㨛")]
			#,l11lll_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ㨜")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡱࡹࡷ࠹ࡻ࠮ࡸࡵࠪ㨝")]
			#,l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ㨞")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳࡹࡤ࡫ࡰࡥ࠳ࡩ࡯ࠨ㨟")]
			#,l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ㨠"):[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶࠪ㨡")]
			#,l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㨢")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠳ࡩ࡯࡮ࠩ㨣")]
			#,l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㨤")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࠴ࡳࡩࡱࡲࡪࡵࡸ࡯࠯ࡱࡱࡰ࡮ࡴࡥࠨ㨥")]    #	 https://l1l1l11l11l1_l1_.com
			#,l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㨦")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣ࠰࡬ࡳࠬ㨧")]
			#,l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡠࡑࡕࡋࠬ㨨"):[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡦ࠲ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡷࡰࡴ࡮ࠫ㨩")]
			#,l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㨪")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ㨫")]
			#,l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ㨬")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳ࡵ࡮ࡦࠩ㨭")]
			 l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㨮")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡲࡥࡲ࠴࡮ࡦࡶࠪ㨯")]
			,l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㨰")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡧࡨࡸࡣ࡮ࡸࡻ࠴࡮ࡦࡶࠪ㨱")]
			,l11lll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㨲")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺࠧ㨳")]
			,l11lll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ㨴")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ㨵")]
			,l11lll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㨶")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮ࡩࡥࡹ࡯࡭ࡪ࠰ࡷࡺࠬ㨷")]
			,l11lll_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㨸")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡱࡳࡡࡢࡴࡨࡪ࠳ࡩࡨࠨ㨹")]
			,l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ㨺")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫ㨻")]
			,l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ㨼")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭㨽")]
			,l11lll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㨾")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧ㨿")]
			,l11lll_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ㩀")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨ㩁")]
			,l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㩂")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫ㩃")]
			,l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㩄")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࠳ࡦ࡭ࡲࡧ࠴ࡶ࠰ࡦࡳࡲ࠭㩅")]
			,l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㩆")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡢࡤࡧࡳ࠳ࡩ࡯࡮ࠩ㩇")]
			,l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㩈")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢ࠯ࡸ࡬ࡴࠬ㩉")]
			,l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㩊")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰ࡯ࠪ㩋")]
			,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㩌")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠻࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷࠫ㩍")]
			,l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㩎")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠯ࡱࡳࡼ࠴ࡣࡰ࡯ࠪ㩏")]
			,l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㩐")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ㩑"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ㩒")]
			,l11lll_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㩓")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡧ࠳ࡪࡲࡢ࡯ࡤࡷ࠼࠴ࡣࡰ࡯ࠪ㩔")]
			,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㩕")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳ࠳ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ㩖")]
			,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㩗")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࡨࡺࠬ㩘")]
			,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㩙")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧ㩚")]
			,l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㩛")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ㩜")]
			,l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㩝")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ㩞")]
			,l11lll_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ㩟")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭㩠")]
			,l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㩡")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭㩢")]
			,l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㩣")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ㩤")]
			,l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㩥")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡻ࡯ࡰࠨ㩦")]
			,l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㩧")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭㩨")]
			,l11lll_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㩩")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭㩪")]
			,l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㩫")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮ࡶࡵࠪ㩬")]
			,l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㩭")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㩮"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㩯"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㩰"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㩱"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ㩲")]
			,l11lll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㩳")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭㩴")]
			,l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㩵")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰࠫ㩶")]
			,l11lll_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ㩷")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭㩸"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ㩹")]
			,l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㩺")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮ࡤࡣࡰࠫ㩻")]
			,l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ㩼")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ㩽")]
			,l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㩾")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠶࠴ࡶࡪࡲࠪ㩿")]
			,l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㪀")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪ㪁")]
			,l11lll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㪂")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬ㪃")]
			,l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㪄")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ㪅"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㪆"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭㪇")]
			,l11lll_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㪈")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪ㪉")]
			,l11lll_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㪊")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡶࡸࡦࡪ࠭㪋")]
			,l11lll_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㪌")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ㪍")]
			,l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㪎")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧ㪏")]
			#,l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㪐")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㪑"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㪒"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㪓"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㪔"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㪕"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㪖"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㪗")]
			#,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㪘")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㪙"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㪚"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㪛"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㪜"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㪝"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㪞"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㪟")]
			#,l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㪠")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㪡"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㪢"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㪣"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㪤"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㪥"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㪦"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㪧")]
			#,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㪨")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㪩"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㪪"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㪫"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㪬"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㪭"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㪮"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㪯"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㪰")]
			#,l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧ㪱")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㪲"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㪳"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㪴"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㪵"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㪶"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㪷"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㪸"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭㪹")]
			,l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㪺")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㪻"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㪼"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㪽"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㪾"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㪿"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㫀"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㫁"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㫂")]
			,l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㫃")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㫄"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㫅"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㫆"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㫇"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㫈"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㫉"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㫊"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡦࡥࡵࡺࡣࡩࡣࠪ㫋")]
			,l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㫌")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㫍"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ㫎"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ㫏")]
			,l11lll_l1_ (u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ㫐")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ㫑"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ㫒"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ㫓")]
			,l11lll_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ㫔")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫ㫕"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪ㫖"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐࠩ㫗")]
			}
class l1ll11l11l1l_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l11ll11l_l1_ = -1
	def onClick(self,l1lll1l1llll_l1_):
		if l1lll1l1llll_l1_>=9010: self.l11l11ll11l_l1_ = l1lll1l1llll_l1_-9010
		self.delete()
	def l111111l11l_l1_(self,*args):
		#self.getControl(9001).l1l11l11l1l_l1_(header)
		#self.getControl(9009).l1ll1lll11ll_l1_(text)
		#self.getControl(9010).l1l11l11l1l_l1_(l1llll1l1ll1_l1_)
		#self.getControl(9011).l1l11l11l1l_l1_(l1l1l11l1111_l1_)
		#self.getControl(9012).l1l11l11l1l_l1_(l1llll1ll1ll_l1_)
		self.l1llll1l1ll1_l1_,self.l1l1l11l1111_l1_,self.l1llll1ll1ll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l1lllll1ll_l1_ = args[5],args[6]
		self.l1ll11111111_l1_,self.l1l111l111ll_l1_,self.l1l11ll1111l_l1_ = args[7],args[8],args[9]
		if self.l1l111l111ll_l1_>0 or self.l1l11ll1111l_l1_>0: self.l1l1ll1lll1l_l1_ = True
		else: self.l1l1ll1lll1l_l1_ = False
		self.l1lll11111l1_l1_,self.l111111l1l1_l1_ = l1l11ll1l111_l1_(self.l1llll1l1ll1_l1_,self.l1l1l11l1111_l1_,self.l1llll1ll1ll_l1_,self.header,self.text,self.profile,self.l1l1lllll1ll_l1_,self.l1ll11111111_l1_,self.l1l1ll1lll1l_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll11111l1_l1_)
		self.getControl(9050).setHeight(self.l111111l1l1_l1_)
		if not self.l1l1l11l1111_l1_ and self.l1llll1l1ll1_l1_ and self.l1llll1ll1ll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll11111l1_l1_,self.l111111l1l1_l1_
	def l11l11l1l11_l1_(self):
		if self.l1l111l111ll_l1_:
			import threading
			self.l11l1llllll_l1_ = threading.Thread(target=self.l1ll111l1l11_l1_,args=())
			self.l11l1llllll_l1_.start()
			#self.l11l1llllll_l1_.join()
		else: self.enableButtons()
	def l1ll111l1l11_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11l1lllll_l1_ in range(1,self.l1l111l111ll_l1_+1):
			time.sleep(1)
			l1l111l1l111_l1_ = int(100*l11l1lllll_l1_/self.l1l111l111ll_l1_)
			self.l1l11l111ll1_l1_(l1l111l1l111_l1_)
			if self.l11l11ll11l_l1_>0: break
		self.enableButtons()
	def l111lllll11_l1_(self):
		if self.l1l11ll1111l_l1_:
			import threading
			self.l1l1ll11l1ll_l1_ = threading.Thread(target=self.l1lll111l111_l1_,args=())
			self.l1l1ll11l1ll_l1_.start()
			#self.l1l1ll11l1ll_l1_.join()
		else: self.enableButtons()
	def l1lll111l111_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l111l111ll_l1_)
		for l11l1lllll_l1_ in range(self.l1l11ll1111l_l1_-1,-1,-1):
			time.sleep(1)
			l1l111l1l111_l1_ = int(100*l11l1lllll_l1_/self.l1l11ll1111l_l1_)
			self.l1l11l111ll1_l1_(l1l111l1l111_l1_)
			if self.l11l11ll11l_l1_>0: break
		if self.l1l11ll1111l_l1_>0: self.l11l11ll11l_l1_ = 10
		self.delete()
	def l1l11l111ll1_l1_(self,l1l111l1l111_l1_):
		self.l1ll1lllll11_l1_ = l1l111l1l111_l1_
		self.getControl(9020).setPercent(self.l1ll1lllll11_l1_)
	def enableButtons(self):
		if self.l1llll1l1ll1_l1_!=l11lll_l1_ (u"ࠧࠨ㫘"): self.getControl(9010).setEnabled(True)
		if self.l1l1l11l1111_l1_!=l11lll_l1_ (u"ࠨࠩ㫙"): self.getControl(9011).setEnabled(True)
		if self.l1llll1ll1ll_l1_!=l11lll_l1_ (u"ࠩࠪ㫚"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll11111l1_l1_)
		except: pass
		#del self
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࡦࡨࡪࠥࡻࡰࡥࡣࡷࡩ࠭ࡹࡥ࡭ࡨ࠯ࡴࡪࡸࡣࡦࡰࡷ࠰࠯ࡧࡲࡨࡵࠬ࠾ࠒࠐࠉࠊࡶࡨࡼࡹࠦ࠽ࠡࡣࡵ࡫ࡸࡡ࠰࡞ࠏࠍࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡧࡲࡨࡵࠬࡂ࠶ࡀࠠࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࡡࡳࡩࡶ࡟࠶ࡣࠍࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡥࡷ࡭ࡳࠪࡀ࠵࠾ࠥࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࡦࡸࡧࡴ࡝࠵ࡡࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡰࡦࡴࡦࡩࡳࡺࠬࡴࡧ࡯ࡪ࠳ࡺࡥࡹࡶࠣࡁࠥࡶࡥࡳࡥࡨࡲࡹ࠲ࡴࡦࡺࡷࠑࠏࠏࠉࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢ࡬ࡪ࡯ࡧࡩࡶࠣࡁࠥࡹࡥ࡭ࡨ࠱ࡧࡷ࡫ࡡࡵࡧࡖ࡬ࡴࡽࡉ࡮ࡣࡪࡩ࠭ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠳࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯࠳࠯ࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮࠳࠮ࡶࡩࡱ࡬࠮ࡩࡧࡤࡨࡪࡸࠬࡴࡧ࡯ࡪ࠳ࡺࡥࡹࡶ࠯ࡷࡪࡲࡦ࠯ࡲࡵࡳ࡫࡯࡬ࡦ࠮ࡶࡩࡱ࡬࠮ࡥ࡫ࡵࡩࡨࡺࡩࡰࡰ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡸ࡫ࡧࡸ࡭࠲ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱࡷࡹ࡯࡭ࡦࡱࡸࡸ࠱ࡹࡥ࡭ࡨ࠱ࡧࡱࡵࡳࡦࡶ࡬ࡱࡪࡵࡵࡵࠫࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡺࡶࡤࡢࡶࡨࡔࡷࡵࡧࡳࡧࡶࡷࡇࡧࡲࠩࡲࡨࡶࡨ࡫࡮ࡵࠫࠐࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠱ࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡ࡫ࡩ࡮࡭ࡨࡵࠏࠍࠍࠧࠨࠢ㫛")
class l1111l111ll_l1_():
	def __init__(self,l1ll_l1_=False,l1l1lll11111_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1l1lll11111_l1_ = l1l1lll11111_l1_
		self.l1111ll1ll1_l1_,self.l11l1l1l11l_l1_ = [],[]
		self.l1lll1ll1111_l1_,self.l1ll1ll1111l_l1_ = {},{}
		self.l1llllll1l1l_l1_ = []
		self.l1lll1l1l11l_l1_,self.l1l11l1l1l1l_l1_,self.l11l111ll1l_l1_ = {},{},{}
	def l11111l1lll_l1_(self,id,func,*args):
		id = str(id)
		self.l1lll1ll1111_l1_[id] = l11lll_l1_ (u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬ㫜")
		if self.l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ࠭㫝"),id)
		# l1llllll1ll1_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1llllll1ll1_l1_ 2 & 3
		import threading
		l11l11ll1ll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1llllll1l1l_l1_.append(l11l11ll1ll_l1_)
		#l11l11ll1ll_l1_.start()
		return l11l11ll1ll_l1_
	def start_new_thread(self,id,func,*args):
		l11l11ll1ll_l1_ = self.l11111l1lll_l1_(id,func,*args)
		l11l11ll1ll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1lll1l1l11l_l1_[id] = time.time()
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㫞"),l11lll_l1_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡴࡶࡤࡶࡹ࡫ࡤࠡ࡫ࡧ࠾ࠥ࠭㫟")+id)
		try:
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㫠"),l11lll_l1_ (u"ࠩࡈࡑࡆࡊ࠺࠻ࠢࠪ㫡")+str(func))
			self.l1ll1ll1111l_l1_[id] = func(*args)
			if l11lll_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࠫ㫢") in str(func) and not self.l1ll1ll1111l_l1_[id].succeeded:
				l1lll11l1l11_l1_(l11lll_l1_ (u"ࠫࡋࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠢࡧࡹࡪࠦࡴࡰࠢࡷ࡬ࡷ࡫ࡡࡥࡧࡧࠤࡔࡖࡅࡏࡗࡕࡐࠥ࡬ࡡࡪ࡮ࠪ㫣"))
			self.l1111ll1ll1_l1_.append(id)
			self.l1lll1ll1111_l1_[id] = l11lll_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧ㫤")
			#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㫥"),l11lll_l1_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠢ࡬ࡨ࠿ࠦࠧ㫦")+id)
		except Exception as err:
			#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㫧"),l11lll_l1_ (u"ࠩࡷ࡬ࡷ࡫ࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢ࡬ࡨ࠿ࠦࠧ㫨")+id)
			if self.l1l1lll11111_l1_:
				l1llll1111l1_l1_ = traceback.format_exc()
				sys.stderr.write(l1llll1111l1_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l1l1l11l_l1_.append(id)
			self.l1lll1ll1111_l1_[id] = l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㫩")
		self.l1l11l1l1l1l_l1_[id] = time.time()
		self.l11l111ll1l_l1_[id] = self.l1l11l1l1l1l_l1_[id] - self.l1lll1l1l11l_l1_[id]
	def l1l1ll1lllll_l1_(self):
		for proc in self.l1llllll1l1l_l1_:
			proc.start()
	def l1l111l1ll1l_l1_(self):
		while l11lll_l1_ (u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬ㫪") in list(self.l1lll1ll1111_l1_.values()): time.sleep(1.000)
def l1l1llll11ll_l1_():
	l1l1l1llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ㫫"))
	l1llll1l11l1_l1_ = True
	if l1l1l1llll1l_l1_==l11ll111l11_l1_:
		status = l11lll_l1_ (u"࠭ࡎࡐࡡࡘࡔࡉࡇࡔࡆࠩ㫬")
		l1llll1l11l1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤ࡛ࡐࡅࡃࡗࡉࠬ㫭")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11lll_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ㫮")
	else:
		status = l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㫯")
		l111l11llll_l1_ = [l11lll_l1_ (u"ࠪ࠼࠳࠻࠮࠱ࠩ㫰"),l11lll_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠴࠳࠷࠹ࠨ㫱"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠶࠴࠲࠵ࡣࠪ㫲"),l11lll_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠸࠮࠴࠲ࠪ㫳"),l11lll_l1_ (u"ࠧ࠳࠲࠵࠶࠳࠶࠲࠯࠲࠵ࠫ㫴"),l11lll_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠱࠱࠰࠵࠶ࠬ㫵"),l11lll_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠵࠱࠴࠻࠭㫶"),l11lll_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠸࠲࠶࠼ࠧ㫷"),l11lll_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠺࠳࠶࠶ࠨ㫸"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠵࠵࠴࠲࠹ࠩ㫹")]
		l1ll1l1l1l11_l1_ = l111l11llll_l1_[-1]
		l1llll1lllll_l1_ = l1l111l11ll1_l1_(l1ll1l1l1l11_l1_)
		l1ll11ll1lll_l1_ = l1l111l11ll1_l1_(l11ll111l11_l1_)
		if l1ll11ll1lll_l1_>l1llll1lllll_l1_:
			status = l11lll_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㫺")
			l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡧ࡫࡯ࡩࡸࠦ࠽ࠡࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲࠪࠏࠍࠍࠎࠏࡦࡪ࡮ࡨࡷࠥࡃࠠࡴࡱࡵࡸࡪࡪࠨࡧ࡫࡯ࡩࡸ࠲ࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠮ࠓࠊࠊࠋࠌࡪࡴࡸࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡶ࠾ࠒࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡥࡣࡷࡥࡤ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡥ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࠪ࠲ࡩࡨࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢࡡࠫ࠲࠯ࡅࠩ࡝࠰ࡧࡦࠬ࠲ࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯࡝࠳ࡡࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࡡࡦࡳࡲࡶࡡࡳࡧࠣࡁࠥ࡜ࡅࡓࡕࡌࡓࡓࡥࡃࡐࡏࡓࡅࡗࡋ࡟ࡑࡃࡕࡗࡊࡘࠨࡰ࡮ࡧࡣࡻ࡫ࡲࡴ࡫ࡲࡲ࠮ࠓࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬࠦࡩ࡯ࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠾ࠒࠐࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠾࠾࡮ࡤࡷࡹ࡬ࡵ࡭࡮ࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩ࠿ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡰ࡮ࡧࡣࡩࡨࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩࠦࡃ࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠾ࠥࡵࡳ࠯ࡴࡨࡲࡦࡳࡥࠩࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩ࠱ࡳࡡࡪࡰࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡳࡵࡣࡷࡹࡸࠦ࠽ࠡࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠑࠏࠏࠉࠊࠋࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠉࠊࠤࠥࠦ㫻")
	return status,l1llll1l11l1_l1_
def l1lll11l11l1_l1_(l1l1l1ll111_l1_,l1ll11l1ll1l_l1_):
	succeeded,l1llll111111_l1_,l111ll1lll1_l1_ = True,False,False
	type,name,l11lll1l1ll_l1_,mode,l11llll1l11_l1_,l11l1ll111l_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
	l1l1l1111111_l1_ = type,name,l11lll1l1ll_l1_,mode,l11llll1l11_l1_,l11l1ll111l_l1_,text,l11lll_l1_ (u"ࠨࠩ㫼"),l1ll111l111_l1_
	l1l1ll1l111l_l1_ = int(mode)
	l111111ll11_l1_ = int(l1l1ll1l111l_l1_%10)
	l1l1ll1l11l1_l1_ = int(l1l1ll1l111l_l1_/10)
	l1l111l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㫽"))
	l1llll111lll_l1_,l1llll1l11l1_l1_ = l1l1llll11ll_l1_()
	if l1llll1l11l1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㫾"),l11lll_l1_ (u"ࠫࠬ㫿"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㬀"),l11lll_l1_ (u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭㬁")+l11ll111l11_l1_)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㬂"),l11lll_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㬃"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㬄"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㬅"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㬆"),l11lll_l1_ (u"ࠬࡇࡕࡕࡊࠪ㬇"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩ㬈"),l11lll_l1_ (u"ࠧࠨ㬉"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨ㬊"),l11lll_l1_ (u"ࠩࠪ㬋"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬ㬌"),l11lll_l1_ (u"ࠫࠬ㬍"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ㬎"),l11lll_l1_ (u"࠭ࠧ㬏"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㬐"),l11lll_l1_ (u"ࠨࠩ㬑"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㬒"),l11lll_l1_ (u"ࠪࠫ㬓"))
		#settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㬔"),l11lll_l1_ (u"ࠬ࠭㬕"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭㬖"),l11lll_l1_ (u"ࠧࠨ㬗"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㬘"),l11lll_l1_ (u"ࠩࠪ㬙"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭㬚"),l11lll_l1_ (u"ࠫࠬ㬛"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡴࡴࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㬜"),l11lll_l1_ (u"࠭ࠧ㬝"))
		#if not l1l111l1ll11_l1_: settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㬞"),l11lll_l1_ (u"ࠨࠩ㬟"))
		#l1l1l1llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㬠"))
		#if l1l1l1llll1l_l1_:
		#	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㬡"),l11lll_l1_ (u"ࠫࠬ㬢"))
		#	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㬣"))
		#	return
		#l111l1l1111_l1_([main_dbfile])
		import l11ll1lllll_l1_
		if l1llll111lll_l1_==l11lll_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㬤"):
			LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㬥"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㬦")+addon_path+l11lll_l1_ (u"ࠩࠣࡡࠬ㬧"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ㬨"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ㬩"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ㬪"))
		else:
			LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㬫"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ㬬")+addon_path+l11lll_l1_ (u"ࠨࠢࡠࠫ㬭"))
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㬮"),l11lll_l1_ (u"ࠪࠫ㬯"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㬰"),l11lll_l1_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ㬱"))
			l111l1l1111_l1_()
			FIX_ALL_DATABASES(False)
			user = l11llll1l1l_l1_(32)
			l11ll1lllll_l1_.l1l1l111l11l_l1_()
			l11ll1lllll_l1_.l111ll1ll1l_l1_(l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㬲"),False)
			l11ll1lllll_l1_.l111ll1ll1l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ㬳"),False)
			l11ll1lllll_l1_.l1lll111111l_l1_(False)
			l11ll1lllll_l1_.l1l11llllll1_l1_(False)
			l11ll1lllll_l1_.l1l1l1111lll_l1_(l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㬴"),l11lll_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ㬵"),False)
			l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࠋࠌࡸࡷࡿ࠺ࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳࡧ࡫࡯ࡩ࠷ࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ࠭ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠬࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ࠮ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠶ࠥࡃࠠࡹࡤࡰࡧࡦࡪࡤࡰࡰ࠱ࡅࡩࡪ࡯࡯ࠪ࡬ࡨࡂ࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧ࡬ࡱࡧ࡭ࡴࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡱࡶࡣ࡯࡭ࡹࡿ࠮ࡢࡵ࡮ࠫ࠱࠭ࡴࡳࡷࡨࠫ࠮ࠓࠊࠊࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠎࠏࠢࠣࠤ㬶")
			try:
				l111l1111l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㬷"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㬸"),l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㬹"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㬺"))
				l1l11l111lll_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㬻"))
				l1l11l111lll_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ㬼"),l11lll_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ㬽"))
			except: pass
			try:
				l111l1111l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㬾"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㬿"),l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㭀"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㭁"))
				l1l11l111lll_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㭂"))
				l1l11l111lll_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ㭃"),l11lll_l1_ (u"ࠪ࠷ࠬ㭄"))
			except: pass
			try:
				l111l1111l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㭅"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㭆"),l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㭇"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㭈"))
				l1l11l111lll_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㭉"))
				l1l11l111lll_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ㭊"),l11lll_l1_ (u"ࠪ࠶ࠬ㭋"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㭌"),l11lll_l1_ (u"ࠬ࠭㭍"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㭎"),l11lll_l1_ (u"ࠧฦาสࠤ่์สࠡฬึฮำีๅࠡะา้ฮࠦเࡊࡒࡗ࡚ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢฯำ๏ีษࠨ㭏"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(dummym3ufile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㭐"),l11lll_l1_ (u"ࠩࠪ㭑"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭒"),l11lll_l1_ (u"ࠫสึวࠡๅ้ฮࠥะำหะา้ࠥิฯๆหࠣไࡒ࠹ࡕࠡษ็้ํา่ะหࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ็ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡฬ็ๆฬฬ๊ศࠢหะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ㭓"))
			#	import M3U
			#	M3U.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11lll11l11_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l111l11lll_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ㭔"),l11ll111l11_l1_)
		l11ll1lllll_l1_.l111lll1ll1_l1_(False)
		#return
	#text = text.replace(l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㭕"),l11lll_l1_ (u"ࠧࠨ㭖"))
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭗"))
	l11l1lll11_l1_ = RESTORE_PATH_NAME(l1ll11l1ll1l_l1_)
	l11ll1ll111_l1_ = RESTORE_PATH_NAME(name)
	l1lll11l1ll1_l1_ = [0,15,17,19,26,34,50,53]
	l1l1lllllll1_l1_ = [0,15,17,19,26,34,50,53]
	l11l11l11l1_l1_ = l1l1ll1l11l1_l1_ not in l1l1lllllll1_l1_
	l1l111l1llll_l1_ = l1l1ll1l11l1_l1_ in [23,28,71,72]
	l1ll11l11ll1_l1_ = l1l1ll1l111l_l1_ in [265,270]
	l1ll1ll1l111_l1_ = (l11l11l11l1_l1_ or l1l111l1llll_l1_) and not l1ll11l11ll1_l1_
	l111l11l1l1_l1_ = l1l11llll1_l1_!=l11lll_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㭘") and (l1l11llll1_l1_!=l11lll_l1_ (u"ࠪࠫ㭙") or context==l11lll_l1_ (u"ࠫࠬ㭚"))
	l1l1ll1ll11l_l1_ = l11lll_l1_ (u"ࠬࡺࡹࡱࡧࡀࠫ㭛") in l1l11llll1_l1_
	l1l1l11111l1_l1_ = l1l1ll1l111l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	SEARCH = l111111ll11_l1_==9 or l1l1ll1l111l_l1_ in [145,516,523]
	l11l111111l_l1_ = not l1l1l11111l1_l1_
	l1111ll11ll_l1_ = not SEARCH
	l1l1l1lll111_l1_ = l11l1lll11_l1_ in [l11lll_l1_ (u"࠭ࠧ㭜"),l11lll_l1_ (u"ࠧ࠯࠰ࠪ㭝")]
	l1llll1ll1l1_l1_ = l1l1l1lll111_l1_ or l11l111111l_l1_
	l1lll11ll1l1_l1_ = l1l1l1lll111_l1_ or l1111ll11ll_l1_ or l1l1ll1ll11l_l1_
	l1l11l1ll11l_l1_ = l1l1ll1l111l_l1_ not in [260,265,270,330,540]
	if l1l111l1ll11_l1_: l1llll1l1lll_l1_ = SEARCH or l1l1l11111l1_l1_
	else: l1llll1l1lll_l1_ = True
	l1l1l1llll_l1_ = l1l1ll1l11l1_l1_ in [74,75]
	l111llll111_l1_ = l1l1ll1l111l_l1_ in [280,720]
	l1lllll11lll_l1_ = not l1l1l1llll_l1_ and not l111llll111_l1_
	l1ll11lll11l_l1_ = l1llll1ll1l1_l1_ and l1lll11ll1l1_l1_ and l1l11l1ll11l_l1_ and l1llll1l1lll_l1_ and l1lllll11lll_l1_
	l1111l1ll1l_l1_ = l1l11l1ll11l_l1_ and l1llll1l1lll_l1_ and l1lllll11lll_l1_
	l111l1l1lll_l1_ = l1111l1ll1l_l1_ and l111l11l1l1_l1_ and l1ll11lll11l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㭞"),l11lll_l1_ (u"ࠩࠪ㭟"),l11lll_l1_ (u"ࠪࠫ㭠"),type+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㭡")+l1l11llll1_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㭢")+str(l1l1llllllll_l1_))
	l11l1l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭㭣"))
	trans_code = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ㭤"))
	if 1 and l111l11l1l1_l1_ and l1ll11lll11l_l1_:
		l1ll1l1llll1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㭥"),l11lll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㭦")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠪࡣࠬ㭧")+trans_code,l1l1l1111111_l1_)
		if l1ll1l1llll1_l1_:
			#xbmcgui.Dialog().l1l11lll1l1l_l1_(l11lll_l1_ (u"ࠫࠬ㭨"),l11lll_l1_ (u"ࠬࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࠬ㭩"),l11lll_l1_ (u"࠭ࠧ㭪"),100,False)
			LOG_THIS(l11lll_l1_ (u"ࠧࠨ㭫"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㭬")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠩࡢࠫ㭭")+trans_code+l11lll_l1_ (u"ࠪࠤࠥࠦࡌࡰࡣࡧ࡭ࡳ࡭ࠠ࡮ࡧࡱࡹࠥ࡬ࡲࡰ࡯ࠣࡧࡦࡩࡨࡦࠩ㭮"))
			if 1 and l1l1ll1ll11l_l1_:
				#xbmcgui.Dialog().l1l11lll1l1l_l1_(l11lll_l1_ (u"ࠫࠬ㭯"),l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩࡽ࡮ࡴࡧࠡࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ㭰"),l11lll_l1_ (u"࠭ࠧ㭱"),100,False)
				l111llll1l1_l1_ = []
				import l1l11ll1l1l1_l1_,FAVORITES
				l1ll11l1llll_l1_ = l1l11ll1l1l1_l1_.l1ll1l1ll11l_l1_
				l111lll11ll_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lll1ll11ll_l1_ = l1l11llll1_l1_
				l1111l1l1l1_l1_,l1111ll1lll_l1_,l1ll11l11lll_l1_,l1l1ll11l11l_l1_,l1l11ll1l11l_l1_,l1lll111lll1_l1_,l1111lll111_l1_,l1ll11111l11_l1_,l1lll111l1l1_l1_ = EXTRACT_KODI_PATH(l1lll1ll11ll_l1_)
				l1ll11ll11l1_l1_ = l1111l1l1l1_l1_,l1111ll1lll_l1_,l1ll11l11lll_l1_,l1l1ll11l11l_l1_,l1l11ll1l11l_l1_,l1lll111lll1_l1_,l1111lll111_l1_,l11lll_l1_ (u"ࠧࠨ㭲"),l1lll111l1l1_l1_
				#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㭳"),str(l1ll11ll11l1_l1_))
				for l1l1lll1ll11_l1_ in l1ll1l1llll1_l1_:
					l1l1l1l111ll_l1_ = l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ㭴")]
					#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㭵"),str(l1l1l1l111ll_l1_))
					if l1l1l1l111ll_l1_==l1ll11ll11l1_l1_ or l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠫࡲࡵࡤࡦࠩ㭶")] in [265,270]:
						l1l1lll1ll11_l1_ = GET_LIST_ITEM(l1l1l1l111ll_l1_,l1ll11l1llll_l1_,l111lll11ll_l1_)
						if l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ㭷")]:
							#xbmcgui.Dialog().l1l11lll1l1l_l1_(l11lll_l1_ (u"࠭ࠧ㭸"),l11lll_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡯࡮ࡨࠢࡦࡳࡳࡺࡥࡹࡶࠪ㭹"),l11lll_l1_ (u"ࠨࠩ㭺"),100,False)
							l1l1l1lllll1_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111lll11ll_l1_,l1l1l1l111ll_l1_,l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠩࡱࡩࡼࡶࡡࡵࡪࠪ㭻")])
							#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㭼"),str(l1l1l1lllll1_l1_))
							#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㭽"),str(l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㭾")]))
							l1l1lll1ll11_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㭿")] = l1l1l1lllll1_l1_+l1l1lll1ll11_l1_[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭㮀")]
					l111llll1l1_l1_.append(l1l1lll1ll11_l1_)
				settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㮁"),l11lll_l1_ (u"ࠩࠪ㮂"))
				if type==l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮃"): WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㮄")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠬࡥࠧ㮅")+trans_code,l1l1l1111111_l1_,l111llll1l1_l1_,REGULAR_CACHE)
			else: l111llll1l1_l1_ = l1ll1l1llll1_l1_
			if type==l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮆") and l11l1lll11_l1_!=l11lll_l1_ (u"ࠧ࠯࠰ࠪ㮇") and l1ll1ll1l111_l1_: l11llll11ll_l1_()
			l111l111111_l1_ = CREATE_KODI_MENU(l1l1l1111111_l1_,l111llll1l1_l1_,succeeded,l1llll111111_l1_,l111ll1lll1_l1_)
			#xbmcgui.Dialog().l1l11lll1l1l_l1_(l11lll_l1_ (u"ࠨࠩ㮈"),l11lll_l1_ (u"ࠩࡦࡶࡪࡧࡴࡪࡰࡪࠤࡲ࡫࡮ࡶࠩ㮉"),l11lll_l1_ (u"ࠪࠫ㮊"),100,False)
			return
	elif type==l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮋") and l1l11llll1_l1_==l11lll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㮌") and l1111l1ll1l_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㮍"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㮎")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠨࡡࠪ㮏")+trans_code+l11lll_l1_ (u"ࠩࠣࠤࠥࡊࡥ࡭ࡧࡷ࡭ࡳ࡭ࠠࡰ࡮ࡧࠤࡨࡧࡣࡩࡧࡧࠤࡲ࡫࡮ࡶࠩ㮐"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㮑")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠫࡤ࠭㮒")+trans_code,l1l1l1111111_l1_)
	#context = l11lll_l1_ (u"ࠬ࠭㮓")
	if l11lll_l1_ (u"࠭࡟ࠨ㮔") in context: l1ll1111111l_l1_,l1l11l1lll1l_l1_ = context.split(l11lll_l1_ (u"ࠧࡠࠩ㮕"),1)
	else: l1ll1111111l_l1_,l1l11l1lll1l_l1_ = context,l11lll_l1_ (u"ࠨࠩ㮖")
	if l1ll1111111l_l1_ in [l11lll_l1_ (u"ࠩ࠴ࠫ㮗"),l11lll_l1_ (u"ࠪ࠶ࠬ㮘"),l11lll_l1_ (u"ࠫ࠸࠭㮙"),l11lll_l1_ (u"ࠬ࠺ࠧ㮚"),l11lll_l1_ (u"࠭࠵ࠨ㮛")] and l1l11l1lll1l_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㮜") l11l11ll11_l1_ l1l11lllllll_l1_ l1l11l11ll11_l1_ is no addon_handle l1l1l111l_l1_ to l111l11l11l_l1_ for l1ll1ll1l1ll_l1_ directory
		#l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠫ㮝") l11l11ll11_l1_ to open a menu list using l1l1l1111l11_l1_ addon_path
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ㮞")+sys.argv[0]+addon_path.split(l11lll_l1_ (u"ࠪࠪࡨࡵ࡮ࡵࡧࡻࡸࡂ࠭㮟"))[0]+l11lll_l1_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃ࠰ࠨ㮠")+l11lll_l1_ (u"ࠧ࠯ࠢ㮡"))
		#xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㮢")+addon_id+l11lll_l1_ (u"ࠧ࠰ࡁࡷࡩࡽࡺ࠽ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠫࠪ㮣"))
		# l1111l11l1_l1_ not remove addon_path .. it is needed to update l1l1l1llllll_l1_ status
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㮤"),addon_path)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㮥"))
		return
	elif l1ll1111111l_l1_==l11lll_l1_ (u"ࠪ࠺ࠬ㮦"):
		if l1l11l1lll1l_l1_==l11lll_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㮧"): DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬ㮨"),l11lll_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭㮩"))
		elif l1l11l1lll1l_l1_==l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠧ㮪"): l1l1ll1l111l_l1_ = 334
		results = l1l1l1l11ll1_l1_(type,l11ll1ll111_l1_,l11lll1l1ll_l1_,l1l1ll1l111l_l1_,l11llll1l11_l1_,l11l1ll111l_l1_,text,context,l1ll111l111_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㮫"))
		return
	elif context==l11lll_l1_ (u"ࠩ࠺ࠫ㮬"):
		import l1ll1l1111l_l1_
		l1ll1l1111l_l1_.l1l1l1l1l1l_l1_()
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㮭"))
		return
	elif context==l11lll_l1_ (u"ࠫ࠽࠭㮮"):
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ㮯")+addon_id+l11lll_l1_ (u"࠭࠿࡮ࡱࡧࡩࡂ࠭㮰")+str(mode)+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷ࠯ࠧ㮱"))
		return
	elif context==l11lll_l1_ (u"ࠨ࠻ࠪ㮲"):
		# l1l1lll1l1ll_l1_ update the l1l111lll111_l1_ menu
		#results = l1l1l1l11ll1_l1_(type,l11ll1ll111_l1_,l11lll1l1ll_l1_,mode,l11llll1l11_l1_,l11l1ll111l_l1_,text,context,l1ll111l111_l1_)
		# l1l1lll1l1ll_l1_ update the l1ll1ll111l1_l1_ menu
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㮳"),l11lll_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭㮴"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㮵"))
		return
	if settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㮶")) not in [l11lll_l1_ (u"࠭ࡁࡖࡖࡒࠫ㮷"),l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ㮸"),l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㮹")]: settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㮺"),l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㮻"))
	if not settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ㮼")): settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㮽"),l1lll1l1l1ll_l1_[0])
	l1l111llll11_l1_ = False if l11ll11111l_l1_(l11lll_l1_ (u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧ㮾")) else True
	l11l11l1lll_l1_ = l1lll1111_l1_ if l1l111llll11_l1_ else REGULAR_CACHE
	l11l11111ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㮿"))
	l1l11l1ll1l1_l1_ = l1lll11l111l_l1_(settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㯀")))
	l1l11l1ll1l1_l1_ = 0 if not l1l11l1ll1l1_l1_ else int(l1l11l1ll1l1_l1_)
	if l11l11111ll_l1_ in [l11lll_l1_ (u"ࠩࠪ㯁"),l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㯂")] or not l11l11l1lll_l1_ or not l1l11l1ll1l1_l1_ or now-l1l11l1ll1l1_l1_<0 or now-l1l11l1ll1l1_l1_>l11l11l1lll_l1_:
		l11l11111ll_l1_ = l11111ll1l1_l1_(True,False)
	l11l111lll1_l1_ = l1lll11l111l_l1_(settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㯃")))
	l11l111lll1_l1_ = 0 if not l11l111lll1_l1_ else int(l11l111lll1_l1_)
	l1111ll1l11_l1_ = l1lll11l111l_l1_(settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㯄")))
	l1111ll1l11_l1_ = 0 if not l1111ll1l11_l1_ else int(l1111ll1l11_l1_)
	if not l11l111lll1_l1_ or not l1111ll1l11_l1_ or now-l1111ll1l11_l1_<0 or now-l1111ll1l11_l1_>l11l111lll1_l1_:
		auth = 1
		if l1l111llll11_l1_:
			# https://www.l1lll1l11l1l_l1_.com/l1l1l111l1l1_l1_/l1111111l1l_l1_
			# unescapeHTML(l11lll_l1_ (u"࠭ࠠࠧࠥࡻ࠶࠻࠹ࡂ࠼ࠢࠩࠧࡽ࠸࠷࠲ࡆ࠾ࠤࠫࠩࡸ࠳࠸࠵ࡅࡀࠦࠦࠤࡺ࠵࠺࠸ࡈ࠻ࠨ㯅"))
			#l1ll11ll1l11_l1_ = l11lll_l1_ (u"ࠧ⸼ࠢ⼠ࠤࠥ⾐ࠠࠡ⸬ࠣ⸿ࠬ㯆")
			#l1lll1111ll1_l1_ = l11lll_l1_ (u"ࠨ⸽ࠣ⼡ࠥࠦ⾋ࠡࠢ⸭ࠤ⹀࠭㯇")
			l1l1l1l11l1l_l1_ = l11l111l1l1_l1_(True)
			if len(l1l1l1l11l1l_l1_)>1:
				LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㯈"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡓࡩࡱࡺ࡭ࡳ࡭ࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㯉")+addon_path+l11lll_l1_ (u"ࠫࠥࡣࠧ㯊"))
				id,l1l111l11l11_l1_,l1l11l11l1ll_l1_,l1111l11111_l1_,l11111ll111_l1_,reason = l1l1l1l11l1l_l1_[0]
				#if l11lll_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ㯋") in reason: l1l1llll1ll1_l1_,l1l1llll1lll_l1_,l1l1lllll111_l1_ = reason.split(l11lll_l1_ (u"࠭࡜࡯࠽࠾ࠫ㯌"),2)
				#else: l1l1llll1ll1_l1_,l1l1llll1lll_l1_,l1l1lllll111_l1_ = reason,reason,reason
				l1lll1ll111l_l1_,l1lll1ll11l1_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㯍"))
				del l1l1l1l11l1l_l1_[0]
				l1l1ll1l11ll_l1_ = random.sample(l1l1l1l11l1l_l1_,1)
				id,l1l111l11l11_l1_,l1l11l11l1ll_l1_,l1111l11111_l1_,l11111ll111_l1_,reason = l1l1ll1l11ll_l1_[0]
				l1l11l11l1ll_l1_ = l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ㯎")+id+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㯏")+l1l11l11l1ll_l1_
				l11111ll111_l1_ = l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㯐")
				l1ll1llll1ll_l1_ = l11lll_l1_ (u"ࠫฬ๊สษำ฼หฯ࠭㯑")
				l1llll1l1ll1_l1_,l1l1l11l1111_l1_ = l1111l11111_l1_,l11111ll111_l1_
				l11l1l11_l1_ = [l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1ll1llll1ll_l1_]
				l111111l111_l1_ = 5 if l11ll11111l_l1_(l11lll_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㯒")) else 15
				choice = -9
				while choice<0:
					l1111lll1ll_l1_ = random.sample(l11l1l11_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࠧ㯓"),l1111lll1ll_l1_[0],l1111lll1ll_l1_[1],l1111lll1ll_l1_[2],l1lll1ll111l_l1_,l1l11l11l1ll_l1_,l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㯔"),l111111l111_l1_,60)
					if choice==10: break
					import l11ll1lllll_l1_
					if choice>=0 and l1111lll1ll_l1_[choice]==l11l1l11_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ㯕"),l11lll_l1_ (u"ࠩࠪ㯖"),l11lll_l1_ (u"ࠪ฽ํีษࠨ㯗"),l11lll_l1_ (u"ࠫࠬ㯘"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㯙"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ㯚")+reason,l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㯛"),20)
						l11ll1lllll_l1_.l1l1lll11ll1_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l1111lll1ll_l1_[choice]==l11l1l11_l1_[2]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ㯜"),l11lll_l1_ (u"ࠩࠪ㯝"),l1ll1llll1ll_l1_,l11lll_l1_ (u"ࠪࠫ㯞"),l1lll1ll111l_l1_,l1l11l11l1ll_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㯟")+l11l1l11_l1_[0]+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㯠"),l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㯡"),30)
						l11ll1lllll_l1_.l11lll1ll1l_l1_(False)
					if choice==-1: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㯢"),l11lll_l1_ (u"ࠨࠩ㯣"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㯤"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ㯥"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㯦"),l1l1lll1l11l_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㯧"),l11lll_l1_ (u"࠭ࡁࡖࡖࡋࠫ㯨"),auth,PERMANENT_CACHE)
	# l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㯩")	l111l11l11l_l1_ file to read/write the l1l1l1l11111_l1_ menu list
	# l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㯪")		no l11l1l11l11_l1_ l1l11lllll1l_l1_ to the l1l1l1l11111_l1_ menu list
	l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉࡔࡋࡗࡉࡘࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡋࡗࡉࡘࡥࡍࡐࡆࡈࡗࠥࡧ࡮ࡥࠢࡰࡳࡩ࡫࠱࠾࠿࠼ࠑࠏࠏࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠺࠲࠵࠲࠸࠯࠹࠷࠹࡝ࠎࠌࠌࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡏࡔࡆࡕࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠐࠎࠎࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠶ࡂࡃ࠱࠷ࠢࡤࡲࡩࠦ࡭ࡰࡦࡨ࠴ࠦࡃ࠱࠷࠲ࠐࠎࠎ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠺࡝ࠎࠌࠌࠧࡳࡧ࡭ࡦࡡࠣࡁࠥࡉࡌࡆࡃࡑࡣࡒࡋࡎࡖࡡࡏࡅࡇࡋࡌࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡲࡦࡳࡥࡠࠢࡀࠤࡗࡋࡓࡕࡑࡕࡉࡤࡖࡁࡕࡊࡢࡒࡆࡓࡅࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࡯ࡳࠢࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠑࠏࠏࡩࡧࠢࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖ࠾ࠒࠐࠉࠊࠥ࡬ࡪࠥࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖ࠾ࠥࡩ࡯࡯ࡦ࠴ࠤࡂࠦࠨ࡮ࡧࡱࡹࡤࡲࡡࡣࡧ࡯ࠤ࡮ࡴࠠ࡜ࠩ࠱࠲ࠬ࠲ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪࡡ࠮ࠓࠊࠊࠋࠦࡩࡱ࡯ࡦࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙࠺ࠡࡥࡲࡲࡩ࠷ࠠ࠾ࠢࠫࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠩࠎࠌࠌࠍ࡮࡬ࠠࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࠦࡩ࡯ࠢࡷࡩࡽࡺࠠࡢࡰࡧࠤࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠡࡣࡱࡨࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠮ࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡵ࡫࡮ࠩ࡮ࡤࡷࡹࡳࡥ࡯ࡷࡩ࡭ࡱ࡫ࠬࠨࡴࡥࠫ࠮࠴ࡲࡦࡣࡧࠬ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱ࡯ࡨࡋࡏࡌࡆ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚࡛࠻࡟ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡳࡱࡪࡆࡊࡎࡈ࠭ࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥ࡝ࡲࡪࡶ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡳࡧࡶࡹࡱࡺࡳࠡ࠿ࠣࡑࡆࡏࡎࡠࡆࡌࡗࡕࡇࡔࡄࡊࡈࡖ࠭ࡺࡹࡱࡧ࠯ࡲࡦࡳࡥࡠ࠮ࡸࡶࡱࡥࠬ࡮ࡱࡧࡩ࠱࡯࡭ࡢࡩࡨࡣ࠱ࡶࡡࡨࡧࡢ࠰ࡹ࡫ࡸࡵ࠮ࡦࡳࡳࡺࡥࡹࡶ࠯࡭ࡳ࡬࡯ࡥ࡫ࡦࡸ࠮ࠓࠊࠊࠋࠌࡲࡪࡽࡆࡊࡎࡈࠤࡂࠦࡳࡵࡴࠫࡱࡪࡴࡵࡊࡶࡨࡱࡸࡒࡉࡔࡖࠬࠑࠏࠏࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡲࡪࡽࡆࡊࡎࡈࠤࡂࠦ࡮ࡦࡹࡉࡍࡑࡋ࠮ࡦࡰࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠎࠌࠌࠍࠎࡵࡰࡦࡰࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦ࠮ࠪࡻࡧ࠭ࠩ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡯ࡧࡺࡊࡎࡒࡅࠪࠏࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡂࠦࡍࡂࡋࡑࡣࡉࡏࡓࡑࡃࡗࡇࡍࡋࡒࠩࡶࡼࡴࡪ࠲࡮ࡢ࡯ࡨࡣ࠱ࡻࡲ࡭ࡡ࠯ࡱࡴࡪࡥ࠭࡫ࡰࡥ࡬࡫࡟࠭ࡲࡤ࡫ࡪࡥࠬࡵࡧࡻࡸ࠱ࡩ࡯࡯ࡶࡨࡼࡹ࠲ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠪࠏࠍࠍࠧࠨࠢ㯫")
	results = l1l1l1l11ll1_l1_(type,l11ll1ll111_l1_,l11lll1l1ll_l1_,mode,l11llll1l11_l1_,l11l1ll111l_l1_,text,context,l1ll111l111_l1_)
	# l1111ll1l1l_l1_ l1llll1l1111_l1_: succeeded,l1llll111111_l1_,l111ll1lll1_l1_ = True,False,True
	# l1llll111111_l1_ = True => l1ll1l1ll1ll_l1_ this list is l1l1ll1111ll_l1_ and will exit to main menu
	# l1llll111111_l1_ = False => l1ll1l1ll1ll_l1_ this list is l1lllllll11l_l1_ and will exit to l1l1l1l11111_l1_ menu
	# l111ll1lll1_l1_ = True => will cause the l1l111l1l1ll_l1_ status to l1l111ll11l1_l1_ l1l1ll1l1l11_l1_
	# l111ll1lll1_l1_ = False => will l1l1ll11ll1l_l1_ the l1l111l1l1ll_l1_ status to l111l11l111_l1_ l1llll1lll1l_l1_
	#succeeded,l1llll111111_l1_,l111ll1lll1_l1_ = True,False,True
	#if not l11l1l11l1l_l1_: l111ll1lll1_l1_ = False
	if l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㯬") in text: l1llll111111_l1_ = True
	if type==l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯭"):
		if l11l1lll11_l1_!=l11lll_l1_ (u"ࠬ࠴࠮ࠨ㯮") and l1ll1ll1l111_l1_: l11llll11ll_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡩ࡯ࡶࠪ㯯"),l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㯰"),l11lll_l1_ (u"ࠨࡃࡘࡘࡍ࠭㯱")) or l1l1ll1l111l_l1_ not in l1lll11l1ll1_l1_) and not l11ll11111l_l1_(l11lll_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㯲")):
				import l1l11ll1l1l1_l1_
				l1ll1l1llll1_l1_ = GET_ALL_LIST_ITEMS(l1l11ll1l1l1_l1_.l1ll1l1ll11l_l1_)
				l111l111111_l1_ = CREATE_KODI_MENU(l1l1l1111111_l1_,l1ll1l1llll1_l1_,succeeded,l1llll111111_l1_,l111ll1lll1_l1_)
				if 1 and l1ll1l1llll1_l1_ and l111l1l1lll_l1_:
					#xbmcgui.Dialog().l1l11lll1l1l_l1_(l11lll_l1_ (u"ࠪࠫ㯳"),l11lll_l1_ (u"ࠫࡼࡸࡩࡵ࡫ࡱ࡫ࠥࡩࡡࡤࡪࡨࠫ㯴"),l11lll_l1_ (u"ࠬ࠭㯵"),100,False)
					WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㯶")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠧࡠࠩ㯷")+trans_code,l1l1l1111111_l1_,l1ll1l1llll1_l1_,REGULAR_CACHE)
				#elif 1 and not l1ll1l1llll1_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㯸")+l11l1l1ll11_l1_+l11lll_l1_ (u"ࠩࡢࠫ㯹")+trans_code,l1l1l1111111_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㯺")+addon_id+l11lll_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㯻"),xbmcgui.ListItem(l11lll_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫ㯼")))
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㯽")+addon_id+l11lll_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㯾"),xbmcgui.ListItem(l11lll_l1_ (u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ㯿")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llll111111_l1_,l111ll1lll1_l1_)
	return
def l1l1l1l11ll1_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_):
	l1l1ll1l111l_l1_ = int(mode)
	l1l1ll1l11l1_l1_ = int(l1l1ll1l111l_l1_//10)
	if   l1l1ll1l11l1_l1_==0:  import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==1:  import l111l1l1_l1_ 		; results = l111l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==2:  import l1l1l11l111_l1_ 		; results = l1l1l11l111_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==3:  import l1111l11lll_l1_ 		; results = l1111l11lll_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==4:  import l1l1l1ll1_l1_ 	; results = l1l1l1ll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll1l11l1_l1_==5:  import l11l111ll11_l1_ 	; results = l11l111ll11_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==6:  import l1ll11ll1_l1_ 	; results = l1ll11ll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==7:  import l1l111l_l1_ 		; results = l1l111l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==8:  import l1l1l11l11l_l1_ 	; results = l1l1l11l11l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==9:  import l1ll1ll1ll_l1_		; results = l1ll1ll1ll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==10: import l1ll11l1l1ll_l1_ 		; results = l1ll11l1l1ll_l1_.MAIN(l1l1ll1l111l_l1_,url)
	elif l1l1ll1l11l1_l1_==11: import l1l1l11ll111_l1_ 	; results = l1l1l11ll111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==12: import l11111l1l1_l1_ 		; results = l11111l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==13: import l1l1ll111_l1_	; results = l1l1ll111_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==14: import l111lllll1l_l1_ 		; results = l111lllll1l_l1_.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_,name,l11l_l1_)
	elif l1l1ll1l11l1_l1_==15: import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==16: import l1l1l11111l1_l1_	 	; results = l1l1l11111l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==17: import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==18: import l1l111ll1ll1_l1_	; results = l1l111ll1ll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==19: import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==20: import l11l11l1l_l1_		; results = l11l11l1l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==21: import l1111111lll_l1_ ; results = l1111111lll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==22: import l1ll1lll1l1_l1_ 	; results = l1ll1lll1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==23: import IPTV 		; results = IPTV.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==24: import l111111_l1_ 		; results = l111111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==25: import l11ll1111_l1_ 	; results = l11ll1111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==26: import l1l11ll1l1l1_l1_ 		; results = l1l11ll1l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1l1ll1l111l_l1_,context)
	elif l1l1ll1l11l1_l1_==28: import IPTV 		; results = IPTV.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==29: import l111ll1111l_l1_	; results = l111ll1111l_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==30: import l1ll1l1l1l_l1_		; results = l1ll1l1l1l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==31: import l1111l1lll1_l1_	; results = l1111l1lll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==32: import l1l11l1lll1_l1_	; results = l1l11l1lll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==33: import l11l111l11_l1_		; results = l11l111l11_l1_.MAIN(l1l1ll1l111l_l1_,url)
	elif l1l1ll1l11l1_l1_==34: import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==35: import l1l1l111_l1_		; results = l1l1l111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==36: import l1ll111l1111_l1_		; results = l1ll111l1111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==37: import l111l11l1_l1_		; results = l111l11l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==38: import l1l1ll11l1l1_l1_ 		; results = l1l1ll11l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==39: import l1l1llllll1_l1_	; results = l1l1llllll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==40: import l11lll1l11_l1_	; results = l11lll1l11_l1_.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll1l11l1_l1_==41: import l11lll1l11_l1_	; results = l11lll1l11_l1_.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll1l11l1_l1_==42: import l1111l11l_l1_		; results = l1111l11l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==43: import l1ll1ll111l_l1_		; results = l1ll1ll111l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==44: import l1ll1ll11l1_l1_		; results = l1ll1ll11l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==45: import l11l11lll1l_l1_		; results = l11l11lll1l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==46: import l1lll11ll11l_l1_		; results = l1lll11ll11l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==47: import l1ll1l1lll_l1_	; results = l1ll1l1lll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==48: import l1l11lll11l1_l1_		; results = l1l11lll11l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==49: import l1lll111ll_l1_		; results = l1lll111ll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==50: import l11ll1lllll_l1_ 	; results = l11ll1lllll_l1_.MAIN(l1l1ll1l111l_l1_,text)
	elif l1l1ll1l11l1_l1_==51: import l1ll1l11111_l1_ 	; results = l1ll1l11111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==52: import l1ll1l11111_l1_ 	; results = l1ll1l11111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==53: import l1l11ll1l1l1_l1_ 		; results = l1l11ll1l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==54: import l1ll1l1111l_l1_	; results = l1ll1l1111l_l1_.MAIN(l1l1ll1l111l_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll1l11l1_l1_==55: import l1llll1111_l1_ 	; results = l1llll1111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==56: import l1l1l11lllll_l1_		; results = l1l1l11lllll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==57: import l1l1lllll11_l1_		; results = l1l1lllll11_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==58: import l111lll111l_l1_	; results = l111lll111l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==59: import l1l1lll1ll1_l1_		; results = l1l1lll1ll1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==60: import l1l1lll11l1_l1_		; results = l1l1lll11l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==61: import l1ll1ll_l1_		; results = l1ll1ll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==62: import l1ll111111l_l1_		; results = l1ll111111l_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==63: import l1lll1l11l_l1_		; results = l1lll1l11l_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==64: import l1lll1llllll_l1_		; results = l1lll1llllll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==65: import l1111l1ll_l1_		; results = l1111l1ll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==66: import l11l11111l1_l1_		; results = l11l11111l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==67: import l1l11l1l111_l1_		; results = l1l11l1l111_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==68: import l111ll1lll_l1_		; results = l111ll1lll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==69: import l1111l1l1_l1_		; results = l1111l1l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==70: import l1l111l1lll_l1_		; results = l1l111l1lll_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==71: import M3U			; results = M3U.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==72: import M3U			; results = M3U.MAIN(l1l1ll1l111l_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==73: import l1l1l1l11_l1_	; results = l1l1l1l11_l1_.MAIN(l1l1ll1l111l_l1_,url,text)
	elif l1l1ll1l11l1_l1_==74: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1l1ll1l111l_l1_)
	elif l1l1ll1l11l1_l1_==75: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1l1ll1l111l_l1_)
	elif l1l1ll1l11l1_l1_==76: import l1l1l11111l1_l1_	 	; results = l1l1l11111l1_l1_.MAIN(l1l1ll1l111l_l1_,url,text,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll1l11l1_l1_==77: import l1lllll111l_l1_ 	; results = l1lllll111l_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==78: import l1lll1ll1ll_l1_ 	; results = l1lll1ll1ll_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==79: import l1lll1l111l_l1_ 	; results = l1lll1l111l_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll1l11l1_l1_==80: import l1lll11llll_l1_ 	; results = l1lll11llll_l1_.MAIN(l1l1ll1l111l_l1_,url,l1l11l1_l1_,text)
	else: results = None
	return results
def l11l1l1l1l_l1_(name=l11lll_l1_ (u"ࠩࠪ㰀")):
	if not name: name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ㰁"))
	name = name.replace(l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㰂"),l11lll_l1_ (u"ࠬ࠭㰃"))
	name = name.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ㰄"),l11lll_l1_ (u"ࠧࠡࠩ㰅")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㰆"),l11lll_l1_ (u"ࠩࠣࠫ㰇")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭㰈"),l11lll_l1_ (u"ࠫࠥ࠭㰉")).strip(l11lll_l1_ (u"ࠬࠦࠧ㰊"))
	name = name.replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㰋"),l11lll_l1_ (u"ࠧࠨ㰌")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㰍"),l11lll_l1_ (u"ࠩࠪ㰎"))
	tmp = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦࠧ㰏"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11lll_l1_ (u"ࠫࡒࡧࡩ࡯ࠢࡐࡩࡳࡻࠧ㰐")
	return name
def l1ll1l1ll1l1_l1_(code,reason,source,l1ll_l1_):
	l1lll111l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㰑"))
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㰒"),l11lll_l1_ (u"ࠧࠨ㰓"))
	if l11lll_l1_ (u"ࠨ࠯ࠪ㰔") in source: l1l1l1ll1ll_l1_ = source.split(l11lll_l1_ (u"ࠩ࠰ࠫ㰕"),1)[0]
	else: l1l1l1ll1ll_l1_ = source
	l111l11111l_l1_ = code in [7,11001,11002,10054]
	l1l111ll111l_l1_ = reason.lower()
	l1ll1l11l11l_l1_ = code in [0,104,10061,111]
	l1ll1l11l111_l1_ = l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㰖") in l1l111ll111l_l1_
	l1ll1l111lll_l1_ = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ㰗") in l1l111ll111l_l1_
	l1ll1l111ll1_l1_ = l11lll_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㰘") in l1l111ll111l_l1_
	l1ll1l111l1l_l1_ = l11lll_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ㰙") in l1l111ll111l_l1_
	l1l1l111l111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㰚"))
	l1l11ll11lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㰛"))
	l1lll1l1111l_l1_ = l11lll_l1_ (u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ㰜")
	l1l1ll1lll11_l1_ = l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠪ㰝")+str(code)+l11lll_l1_ (u"ࠫ࠿ࠦࠧ㰞")+reason
	l1l1ll1lll11_l1_ = l111l_l1_(l1l1ll1lll11_l1_)
	if l1ll1l11l11l_l1_ or l1ll1l11l111_l1_ or l1ll1l111lll_l1_ or l1ll1l111ll1_l1_ or l1ll1l111l1l_l1_:
		l1lll1l1111l_l1_ += l11lll_l1_ (u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬ㰟")
	if l111l11111l_l1_: l1lll1l1111l_l1_ += l11lll_l1_ (u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭㰠")
	l1l1ll1lll11_l1_ = l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㰡")+l1l1ll1lll11_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㰢")
	if l1l1l111l111_l1_==l11lll_l1_ (u"ࠩࡄࡗࡐ࠭㰣") or l1l11ll11lll_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ㰤"):
		l1lll1l1111l_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㰥")
	l11l111l111_l1_ = False
	if l1ll_l1_ and source not in l1llllllll11_l1_:
		if l1l1l111l111_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ㰦") or l1l11ll11lll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ㰧"):
			#if kodi_version<19: l1l1ll1lll11_l1_ = l1l1ll1lll11_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㰨"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㰩"),l11lll_l1_ (u"ࠩัีําࠧ㰪"),l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㰫"),l11lll_l1_ (u"ࠫส฻ไศฯࠣห้๋ิไๆฬࠫ㰬"),l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㰭")+TRANSLATE(l1l1l1ll1ll_l1_),l1lll1l1111l_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㰮")+l1l1ll1lll11_l1_)
			if choice==1:
				import l11ll1lllll_l1_
				l11ll1lllll_l1_.l1l1lll11ll1_l1_()
			elif choice==2: l11l111l111_l1_ = True
		else: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㰯"),l11lll_l1_ (u"ࠨࠩ㰰"),l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㰱")+TRANSLATE(l1l1l1ll1ll_l1_),l1lll1l1111l_l1_,l1l1ll1lll11_l1_)
	#if reason.endswith(l11lll_l1_ (u"ࠪࠤ࠮࠭㰲")): reason = reason.rsplit(l11lll_l1_ (u"ࠫࡡࡴࠧ㰳"))[0]
	#if l11l111l111_l1_: LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㰴"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㰵")+str(code)+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ㰶")+reason+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㰷")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ㰸")+l1lll1l1111l_l1_+l11lll_l1_ (u"ࠪࠤࡢࡣࠠࠡࠢࡈࡒࡌࡒࡉࡔࡊ࠽ࠤࡠࠦࠧ㰹")+l1l1ll1lll11_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ㰺"))
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㰻"),l1lll111l11l_l1_)
	return l11l111l111_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࡥࡰࡶࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠲ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠸ࠠࡰࡴࠣࡦࡱࡵࡣ࡬ࡧࡧ࠷࠿ࠓࠊࠊࠋࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭ๆ้฻้๋ࠣࠦวๅฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไ࠰ࠪࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣ࠯ࡂ้ࠦࠧࠡ็ࠤฯื๊ะࠢอๅฬ฻๊ๅࠢส็ะืࠠภࠩࠐࠎࠎࠏࡩࡧࠢࡧࡲࡸࡀࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤࡂࠦࠧๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่ࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠠࠬ࠿ࠣࠫࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์๋ࠦࠧࠬࡤ࡯ࡳࡨࡱ࡟࡮ࡧࡨࡷࡸࡧࡧࡦࠏࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤࡂ่ࠦࠧาสࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࠮ࡏࡓࡌࡍࡉࡏࡉࠫࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠪ࠭ࠪࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ࠯ࡸࡵࡵࡳࡥࡨ࠯ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡵࡴࠫࡧࡴࡪࡥࠪ࠭ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ࠱ࡲࡦࡣࡶࡳࡳ࠱ࠧࠡ࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠿࡛ࠦࠡࠩ࠮ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠮ࠫࠥࡣ࡝ࠡࠢࠣࡱࡪࡹࡳࡢࡩࡨࡉࡓࡍࡌࡊࡕࡋ࠾ࠥࡡࠠࠨ࠭ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠮ࠫࠥࡣࠧࠪࠏࠍࠍࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࡀࠍࠋࠋࠌࠍࡾ࡫ࡳࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢ࡝ࡊ࡙ࡎࡐࠪࠪࡧࡪࡴࡴࡦࡴࠪ࠰ࡸ࡯ࡴࡦ࠭ࠪࠤࠥࠦࠧࠬࡖࡕࡅࡓ࡙ࡌࡂࡖࡈࠬࡸ࡯ࡴࡦࠫ࠯ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠯ࡱࡪࡹࡳࡢࡩࡨࡉࡓࡍࡌࡊࡕࡋ࠰ࠬ࠭ࠬࠨๅ็หࠬ࠲ࠧ็฻่ࠫ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦࡹࡦࡵࡀࡁ࠶ࡀࠠࡪ࡯ࡳࡳࡷࡺࠠࡔࡇࡕ࡚ࡎࡉࡅࡔࠢ࠾ࠤࡘࡋࡒࡗࡋࡆࡉࡘ࠴ࡍࡂࡋࡑࠬ࠶࠿࠵ࠪࠏࠍࠍࡪࡲࡩࡧࠢࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹ࠺ࠎࠌࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠶ࠥࡃࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠫࠨࠢ࠱ࠤ์๊ࠠหำํำู๋ࠥาใฬࠤฬ๊ริสสฬࠥ๎วๅฯ็์้ࠦฟࠨࠏࠍࠍࠎࡿࡥࡴࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣ࡞ࡋࡓࡏࡑࠫࠫࡨ࡫࡮ࡵࡧࡵࠫ࠱ࡹࡩࡵࡧ࠮ࠫࠥࠦࠠࠨ࠭ࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠭ࡹࡩࡵࡧࠬ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠶࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠷࠺ࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦ࠽ࠡࠩๅำࠥ๐ใ้่๋๋ࠣอใ่๋ࠡ฽๋ࠥๆࠡษ็ััฮฺ่ࠠา็ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่ส์สา่อࠤ฾์ฯไ่ࠢๅฺ๎ไสࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅำห฻ࠥอไๆึไี๊ࠥวࠡ์฼ู้้ࠦ็ัๆࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็ࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ฺ๋ࠦำ๋ࠣีํࠠศๆุๅาฯ้ࠠษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯࡞ࡱࠫ࠰࠭ฬาสุ้ࠣำࠠศๆๆหูࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡลิื้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ัใࠢิๅ฾ࠦวๅฯฯฬࠥ࠮ๅฬๆสࠤ࡛ࡖࡎࠡ࠮ࠣࡔࡷࡵࡸࡺࠢ࠯ࠤࡉࡔࡓࠪࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦฬาสࠣ฻้ฮ่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ้ออใษࠪࠑࠏࠏࠉࠊࡆࡌࡅࡑࡕࡇࡠࡖࡈ࡜࡙࡜ࡉࡆ࡙ࡈࡖ࠭࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ࠮ࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠬࠑࠏࠏࠢࠣࠤ㰼")
def l111l1l1111_l1_(l1l11ll11ll1_l1_=False):
	l1lll1l11lll_l1_ = [l11lll11l11_l1_,favoritesfile,l1l111l11lll_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l11ll11ll1_l1_ and (filename.startswith(l11lll_l1_ (u"ࠧࡪࡲࡷࡺࠬ㰽")) or filename.startswith(l11lll_l1_ (u"ࠨ࡯࠶ࡹࠬ㰾"))): continue
		if filename.startswith(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ㰿")): continue
		l1ll1ll11111_l1_ = os.path.join(addoncachefolder,filename)
		if l1ll1ll11111_l1_ in l1lll1l11lll_l1_: continue
		try: os.remove(l1ll1ll11111_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll111llll1_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l1ll_l1_=True,l1l1llll111l_l1_=True):
	l1l1l11ll1l1_l1_,l1ll11l11111_l1_ = proxy.split(l11lll_l1_ (u"ࠪ࠾ࠬ㱀"))
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ㱁"),l11lll_l1_ (u"ูࠬรอำหࠤࠬ㱂")+name,time=2000)
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㱃"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ㱄")+name+l11lll_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㱅")+proxy+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㱆")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㱇"))
	url = url+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㱈")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l1ll_l1_,l1l1llll111l_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㱉"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ㱊")+name+l11lll_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㱋")+proxy+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㱌")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㱍"))
		l1lll11l1l11_l1_(l11lll_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ㱎"))
	#else: LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㱏"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ㱐")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㱑")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㱒"))
	return response
def l1l11ll1l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㱓"),url,l11lll_l1_ (u"ࠩࠪ㱔"),l11lll_l1_ (u"ࠪࠫ㱕"),True,l11lll_l1_ (u"ࠫࠬ㱖"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭㱗"),True,False)
	l1llll1ll111_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l111l11_l1_
		l1l1lll11lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ㱘"),html)
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㱙"),str(l1l1lll11lll_l1_))
		if l1l1lll11lll_l1_: html = l11lll_l1_ (u"ࠨ࡞ࡱࠫ㱚").join(l1l1lll11lll_l1_)
		proxies = html.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ㱛"),l11lll_l1_ (u"ࠪࠫ㱜")).strip(l11lll_l1_ (u"ࠫࡡࡴࠧ㱝")).split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㱞"))
		l1llll1ll111_l1_ = []
		for proxy in proxies:
			if proxy.count(l11lll_l1_ (u"࠭࠮ࠨ㱟"))==3: l1llll1ll111_l1_.append(proxy)
	return l1llll1ll111_l1_
def l111ll1ll11_l1_(*args):
	#l1l1lllll1l1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠵࠷࠱࠷࠸࠴࠱࠸࠰࠴࠶࠼࠵ࡡࡱ࡫࠲ࡴࡷࡵࡸࡺࡁࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡹࡰࡦࡧࡧࡁ࠶࠶ࠦ࡭ࡣࡶࡸࡤࡩࡨࡦࡥ࡮ࡁ࠶࠶ࠦࡩࡶࡷࡴࡸࡃࡴࡳࡷࡨࠪࡵࡵࡳࡵ࠿ࡷࡶࡺ࡫ࠦࡧࡱࡵࡱࡦࡺ࠽ࡵࡺࡷࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ㱠")
	l11l111llll_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ㱡")
	l1ll1l11llll_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭㱢")
	#l1llll1ll11l_l1_ = l1l11ll1l1ll_l1_(l1l1lllll1l1_l1_)
	l1llll1ll11l_l1_ = l1l11ll1l1ll_l1_(l1ll1l11llll_l1_)
	l1llll1ll111_l1_ = l1l11ll1l1ll_l1_(l11l111llll_l1_)
	l11l11llll1_l1_ = l1llll1ll11l_l1_+l1llll1ll111_l1_
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㱣"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ㱤")+str(len(l1llll1ll11l_l1_))+l11lll_l1_ (u"ࠬ࠱ࠧ㱥")+str(len(l1llll1ll111_l1_))+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㱦"))
	proxy = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㱧"))
	response = l1l1111ll1l_l1_()
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㱨"),l11lll_l1_ (u"ࠩࠪ㱩"))
	if proxy or l11l11llll1_l1_:
		id,timeout = 0,10
		l1l1l111111l_l1_ = len(l11l11llll1_l1_)
		l1111111l11_l1_ = timeout
		if l1l1l111111l_l1_>l1111111l11_l1_: counts = l1111111l11_l1_
		else: counts = l1l1l111111l_l1_
		l1111lll1l1_l1_ = random.sample(l11l11llll1_l1_,counts)
		if proxy: l1111lll1l1_l1_ = [proxy]+l1111lll1l1_l1_
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㱪"),str(l1111lll1l1_l1_))
		threads = l1111l111ll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l1111ll1ll1_l1_:
			if id<counts:
				proxy = l1111lll1l1_l1_[id]
				threads.start_new_thread(id,l1ll111llll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㱫"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㱬")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㱭"))
		l1111ll1ll1_l1_ = threads.l1111ll1ll1_l1_
		if l1111ll1ll1_l1_:
			l1ll1ll1111l_l1_ = threads.l1ll1ll1111l_l1_
			l1lll111ll1l_l1_ = l1111ll1ll1_l1_[0]
			response = l1ll1ll1111l_l1_[l1lll111ll1l_l1_]
			proxy = l1111lll1l1_l1_[int(l1lll111ll1l_l1_)]
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㱮"),proxy)
			if l1lll111ll1l_l1_!=0: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㱯"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ㱰")+proxy+l11lll_l1_ (u"ࠪࠤࡢ࠭㱱"))
			else: LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㱲"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㱳")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㱴"))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㱵"),l11lll_l1_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙࠸ࠠ࠻࠼ࠣࠫ㱶")+str(l1111lll1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㱷"),l11lll_l1_ (u"ࠪࡴࡷࡵࡸࡪࡧࡶࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㱸")+str(l11l11llll1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㱹"),l11lll_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ㱺")+str(threads.l1111ll1ll1_l1_))
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㱻"),l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ㱼")+str(threads.l11l1l1l11l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㱽"),l11lll_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࡵࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ㱾")+str(threads.l1ll1ll1111l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㱿"),l11lll_l1_ (u"ࠫࡪࡲࡰࡢࡵࡨࡨࡹ࡯࡭ࡦࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ㲀")+str(threads.l11l111ll1l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㲁"),l11lll_l1_ (u"࠭ࡳࡰࡴࡷࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ㲂")+str(l1lll11lllll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㲃"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㲄")+l1l11llll11l_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㲅")+str(l1lll11lllll_l1_))
	return response
def l1l11l1l111l_l1_(connection,l1l111lll1ll_l1_):
	l11111ll1ll_l1_ = connection.create_connection
	def l1l1l1l1l1l1_l1_(address,*args,**kwargs):
		host,port = address
		l1l1ll1ll1ll_l1_ = DNS_RESOLVER(host,l1l111lll1ll_l1_)
		if l1l1ll1ll1ll_l1_: host = l1l1ll1ll1ll_l1_[0]
		else:
			if l1l111lll1ll_l1_ in l1lll1l1l1ll_l1_: l1lll1l1l1ll_l1_.remove(l1l111lll1ll_l1_)
			if l1lll1l1l1ll_l1_:
				l1lllllll111_l1_ = l1lll1l1l1ll_l1_[0]
				#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㲆"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡗࡪ࡮࡯ࠤࡹࡸࡹࠡࡶ࡫ࡩࠥࡵࡴࡩࡧࡵࠤࡉࡔࡓ࠻࡝ࠣࠫ㲇")+l1lllllll111_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡴࡹࡴ࠻࡝ࠣࠫ㲈")+str(host)+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㲉"))
				l1l1ll1ll1ll_l1_ = DNS_RESOLVER(host,l1lllllll111_l1_)
				if l1l1ll1ll1ll_l1_: host = l1l1ll1ll1ll_l1_[0]
		address = (host,port)
		return l11111ll1ll_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1l1l1l1l1_l1_
	return l11111ll1ll_l1_
def l1ll1l11l1_l1_(l11llll1111_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡴࡶࡵࠫ㲊"),l11lll_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㲋"),(method,url,data,headers))
	if html:
		l11llll11l1_l1_(l11lll_l1_ (u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ㲌"),url,data,headers,source,method)
		return html
	html = l1lllll111_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ㲍"),(method,url,data,headers),html,l11llll1111_l1_)
	return html
def l1l111ll1l11_l1_(url):
	l111l11l1ll_l1_,l111l1ll11l_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴࠭㲎"))[2],80
	if l11lll_l1_ (u"ࠬࡀࠧ㲏") in l111l11l1ll_l1_: l111l11l1ll_l1_,l111l1ll11l_l1_ = l111l11l1ll_l1_.split(l11lll_l1_ (u"࠭࠺ࠨ㲐"))
	l11111l111l_l1_ = l11lll_l1_ (u"ࠧ࠰ࠩ㲑")+l11lll_l1_ (u"ࠨ࠱ࠪ㲒").join(url.split(l11lll_l1_ (u"ࠩ࠲ࠫ㲓"))[3:])
	request = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠠࠨ㲔")+l11111l111l_l1_+l11lll_l1_ (u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫ㲕")
	#request += l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠼ࠣࡠࡷࡢ࡮ࠨ㲖")
	request += l11lll_l1_ (u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭㲗")+l111l11l1ll_l1_+l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㲘")
	request += l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㲙")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l111l11l1ll_l1_,l111l1ll11l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11lll_l1_ (u"ࠩࠪ㲚")
	return html
def SERVER(link,type):
	# url:	http://www.l1lllll1111l_l1_.com
	# host:	www.l1lllll1111l_l1_.com
	# name:	l1lllll1111l_l1_
	#server = l11lll_l1_ (u"ࠪ࠳ࠬ㲛").join(link.split(l11lll_l1_ (u"ࠫ࠴࠭㲜"))[:3])
	if l11lll_l1_ (u"ࠬ࠴ࠧ㲝") not in link: return link
	link = link+l11lll_l1_ (u"࠭࠯ࠨ㲞")
	l1l1l1ll1lll_l1_,l1l1l1ll1ll1_l1_ = link.split(l11lll_l1_ (u"ࠧ࠯ࠩ㲟"),1)
	l1l1l1ll1l1l_l1_,l1l1l1ll1l11_l1_ = l1l1l1ll1ll1_l1_.split(l11lll_l1_ (u"ࠨ࠱ࠪ㲠"),1)
	server = l1l1l1ll1lll_l1_+l11lll_l1_ (u"ࠩ࠱ࠫ㲡")+l1l1l1ll1l1l_l1_
	if type in [l11lll_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ㲢"),l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㲣")] and l11lll_l1_ (u"ࠬ࠵ࠧ㲤") in server: server = server.rsplit(l11lll_l1_ (u"࠭࠯ࠨ㲥"),1)[1]
	if type==l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㲦") and l11lll_l1_ (u"ࠨ࠰ࠪ㲧") in server:
		l1l1llllll11_l1_ = server.split(l11lll_l1_ (u"ࠩ࠱ࠫ㲨"))
		length = len(l1l1llllll11_l1_)
		if length<=2 or l11lll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㲩") in server: l1l1llllll11_l1_ = l1l1llllll11_l1_[0]
		elif length>=3: l1l1llllll11_l1_ = l1l1llllll11_l1_[1]
		if len(l1l1llllll11_l1_)>1: server = l1l1llllll11_l1_
	return server
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࠪ࠳ࠬ࠱ࡵࡳ࡮࠵࠯ࠬ࠵ࠧࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡳ࡫ࡴ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡵ࡭࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡴࡸࡧ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡶࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺࡶ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡼࡹ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡸࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡳࡷ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣࡢ࡯࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡯࡯࡮࡬ࡲࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰࡯࡭ࡻ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡱࡻࡢ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡦࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡳࡸ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲࡮ࡴ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡻࡼࡽ࠮ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡱ࠳࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࠥࠦࠧ㲪")
def l1l1l11111ll_l1_(l1111l11l1l_l1_):
	l1111l11ll1_l1_ = repr(l1111l11l1l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㲫"))).replace(l11lll_l1_ (u"ࠨࠧࠣ㲬"),l11lll_l1_ (u"ࠧࠨ㲭"))
	return l1111l11ll1_l1_
def l1l111lllll_l1_(string):
	#if l11lll_l1_ (u"ࠨ࡞ࡸࠫ㲮") in string:
	#	string = string.decode(l11lll_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㲯"))
	#	l1ll1lll1111_l1_=re.findall(l11lll_l1_ (u"ࡵࠫࡡࡻ࡛࠱࠯࠼ࡅ࠲ࡌ࡝ࠨ㲰"),string)
	#	for unicode in l1ll1lll1111_l1_
	#		char = l1l111l11111_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㲱"))
	l1l11l1l11ll_l1_ = l11lll_l1_ (u"ࠬ࠭㲲")
	if kodi_version<19: string = string.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㲳"))
	import unicodedata
	for l1l111lll1l_l1_ in string:
		if   l1l111lll1l_l1_==l11lll_l1_ (u"ࡵࠨฤࠪ㲴"): l111111ll1l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳ࠩ㲵")
		elif l1l111lll1l_l1_==l11lll_l1_ (u"ࡷࠪวࠬ㲶"): l111111ll1l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠶ࠫ㲷")
		elif l1l111lll1l_l1_==l11lll_l1_ (u"ࡹࠬสࠧ㲸"): l111111ll1l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹࠭㲹")
		elif l1l111lll1l_l1_==l11lll_l1_ (u"ࡻࠧฦࠩ㲺"): l111111ll1l_l1_ = l11lll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨ㲻")
		elif l1l111lll1l_l1_==l11lll_l1_ (u"ࡶࠩษࠫ㲼"): l111111ll1l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ࠪ㲽")
		else:
			l1l1111lll11_l1_ = unicodedata.decomposition(l1l111lll1l_l1_)
			if l11lll_l1_ (u"ࠪࠤࠬ㲾") in l1l1111lll11_l1_: l111111ll1l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵࠨ㲿")+l1l1111lll11_l1_.split(l11lll_l1_ (u"ࠬࠦࠧ㳀"),1)[1]
			else:
				l111111ll1l_l1_ = l11lll_l1_ (u"࠭࠰࠱࠲࠳ࠫ㳁")+hex(ord(l1l111lll1l_l1_)).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㳂"),l11lll_l1_ (u"ࠨࠩ㳃"))
				l111111ll1l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠭㳄")+l111111ll1l_l1_[-4:]
			#if ord(l1l111lll1l_l1_)<256: l111111ll1l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠱ࠩ㳅")+l1l1l1llll11_l1_
			#elif ord(l1l111lll1l_l1_)<4096: l111111ll1l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵ࠱ࠩ㳆")+l1l1l1llll11_l1_
			#elif l11lll_l1_ (u"ࠬࠦࠧ㳇") in l1l1111lll11_l1_: l111111ll1l_l1_ = l11lll_l1_ (u"࠭࡜࡝ࡷࠪ㳈")+l1l1111lll11_l1_.split(l11lll_l1_ (u"ࠧࠡࠩ㳉"),1)[1]
			#else: l111111ll1l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹࠬ㳊")+l1l1l1llll11_l1_
		l1l11l1l11ll_l1_ += l111111ll1l_l1_
	l1l11l1l11ll_l1_ = l1l11l1l11ll_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪ㳋"),l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫ㳌"))
	if kodi_version<19: l1l11l1l11ll_l1_ = l1l11l1l11ll_l1_.decode(l11lll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㳍")).encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳎"))
	else: l1l11l1l11ll_l1_ = l1l11l1l11ll_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㳏")).decode(l11lll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㳐"))
	return l1l11l1l11ll_l1_
def OPEN_KEYBOARD(header=l11lll_l1_ (u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨ㳑"),default=l11lll_l1_ (u"ࠩࠪ㳒"),l11111111l1_l1_=False,source=l11lll_l1_ (u"ࠪࠫ㳓")):
	text = l111l1ll1ll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11lll_l1_ (u"ࠫࠥࠦࠧ㳔"),l11lll_l1_ (u"ࠬࠦࠧ㳕")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ㳖"),l11lll_l1_ (u"ࠧࠡࠩ㳗")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ㳘"),l11lll_l1_ (u"ࠩࠣࠫ㳙"))
	if not text and not l11111111l1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㳚"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨ㳛")+text+l11lll_l1_ (u"ࠬࠨࠧ㳜"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㳝"),l11lll_l1_ (u"ࠧࠨ㳞"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㳟"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬ㳠"))
		return l11lll_l1_ (u"ࠪࠫ㳡")
	if text not in [l11lll_l1_ (u"ࠫࠬ㳢"),l11lll_l1_ (u"ࠬࠦࠧ㳣")]:
		text = text.strip(l11lll_l1_ (u"࠭ࠠࠨ㳤"))
		text = l1l111lllll_l1_(text)
	if source!=l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩ㳥") and l11ll11_l1_(l11lll_l1_ (u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ㳦"),l11lll_l1_ (u"ࠩࠪ㳧"),[text],False):
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㳨"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧ㳩")+text+l11lll_l1_ (u"ࠬࠨࠧ㳪"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㳫"),l11lll_l1_ (u"ࠧࠨ㳬"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㳭"),l11lll_l1_ (u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫ㳮"))
		return l11lll_l1_ (u"ࠪࠫ㳯")
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㳰"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨ㳱")+text+l11lll_l1_ (u"࠭ࠢࠨ㳲"))
	return text
def l11ll11l11_l1_(l11l11l_l1_,headers={}):
	#if headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㳳")]==l11lll_l1_ (u"ࠨࠩ㳴"): headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㳵")] = l11lll_l1_ (u"ࠪࠤࠬ㳶")
	#l1ll1lll1ll1_l1_ = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㳷") : l11lll_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠺࠹࠳࠶࠮࠴࠹࠺࠴࠳࠷࠴࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ㳸") }
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡦ࠻࠸࠳ࡳࡹࡤࡦࡱ࠲ࡲ࡫࠯ࡷ࡫ࡧࡩࡴ࠴࡭࠴ࡷ࠻ࠫ㳹")
	#open(l11lll_l1_ (u"ࠧࡔ࠼࡟ࡠࡹ࡫ࡳࡵ࠴࠱ࡱ࠸ࡻ࠸ࠨ㳺"), l11lll_l1_ (u"ࠨࡴࠪ㳻")).read()
	url,params = l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ㳼")
	if l11lll_l1_ (u"ࠪࢀࠬ㳽") in l11l11l_l1_:
		url,params = l11l11l_l1_.split(l11lll_l1_ (u"ࠫࢁ࠭㳾"),1)
		if l11lll_l1_ (u"ࠬࡃࠧ㳿") not in params: url,params = l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㴀")
	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㴁"),url,l11lll_l1_ (u"ࠨࠩ㴂"),headers,l11lll_l1_ (u"ࠩࠪ㴃"),l11lll_l1_ (u"ࠪࠫ㴄"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㴅"),False,False)
	html = response.content
	if l11lll_l1_ (u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ㴆") not in html: return [l11lll_l1_ (u"࠭࠭࠲ࠩ㴇")],[l11l11l_l1_]
	#	if l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㴈") in list(headers.keys()): del headers[l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㴉")]
	#	else: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㴊")] = l11lll_l1_ (u"ࠪࠫ㴋")
	#	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㴌"),url,l11lll_l1_ (u"ࠬ࠭㴍"),headers,l11lll_l1_ (u"࠭ࠧ㴎"),l11lll_l1_ (u"ࠧࠨ㴏"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠴ࡱࡨࠬ㴐"),False,False)
	#	html = response.content
	if l11lll_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭㴑") in html: return [l11lll_l1_ (u"ࠪ࠱࠶࠭㴒")],[l11l11l_l1_]
	if l11lll_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ㴓") in html: return [l11lll_l1_ (u"ࠬ࠳࠱ࠨ㴔")],[l11l11l_l1_]
	#if l11lll_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠧ㴕") in html: return [l11lll_l1_ (u"ࠧ࠮࠳ࠪ㴖")],[l11l11l_l1_]
	l1lll1ll_l1_,l1111_l1_,l1lllll11l1l_l1_,l1l1lllll11l_l1_ = [],[],[],[]
	lines = re.findall(l11lll_l1_ (u"ࠨ࡞ࠦࡉ࡝࡚࡙࠭࠯ࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠪ㴗"),html+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㴘"),re.DOTALL)
	if not lines: return [l11lll_l1_ (u"ࠪ࠱࠶࠭㴙")],[l11l11l_l1_]
	for line,link in lines:
		l1l11l11l111_l1_,l111ll111ll_l1_,l11l111l_l1_ = {},-1,-1
		title = l11lll_l1_ (u"ࠫࠬ㴚")
		#hostname = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㴛"))
		#title = title+l11lll_l1_ (u"࠭ࠠࠡࠩ㴜")+hostname+l11lll_l1_ (u"ࠧࠡࠢࠪ㴝")
		#line = line.lower()
		items = line.split(l11lll_l1_ (u"ࠨ࠮ࠪ㴞"))
		for item in items:
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㴟"),l11lll_l1_ (u"ࠪࠫ㴠"),item,l11lll_l1_ (u"ࠫࠬ㴡"))
			#if l11lll_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㴢") in item: l1l11l11l111_l1_[key] = value
			if l11lll_l1_ (u"࠭࠽ࠨ㴣") in item:
				key,value = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ㴤"),1)
				l1l11l11l111_l1_[key.lower()] = value
		if l11lll_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㴥") in line.lower():
			l111ll111ll_l1_ = int(l1l11l11l111_l1_[l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㴦")])//1024
			#title += l11lll_l1_ (u"ࠪࡅࡻ࡭ࡂࡘ࠼ࠣࠫ㴧")+str(l111ll111ll_l1_)+l11lll_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㴨")
			title += str(l111ll111ll_l1_)+l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ㴩")
		elif l11lll_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㴪") in line.lower():
			l111ll111ll_l1_ = int(l1l11l11l111_l1_[l11lll_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㴫")])//1024
			#title += l11lll_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭㴬")+str(l111ll111ll_l1_)+l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㴭")
			title += str(l111ll111ll_l1_)+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㴮")
		if l11lll_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㴯") in line.lower():
			l11l111l_l1_ = int(l1l11l11l111_l1_[l11lll_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㴰")].split(l11lll_l1_ (u"࠭ࡸࠨ㴱"))[1])
			#title += l11lll_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭㴲")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠫ㴳")
			title += str(l11l111l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠬ㴴")
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠥ࠭㴵"))
		if not title: title = l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ㴶")
		if not link.startswith(l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㴷")):
			if link.startswith(l11lll_l1_ (u"࠭࠯࠰ࠩ㴸")): link = url.split(l11lll_l1_ (u"ࠧ࠻ࠩ㴹"),1)[0]+l11lll_l1_ (u"ࠨ࠼ࠪ㴺")+link
			elif link.startswith(l11lll_l1_ (u"ࠩ࠲ࠫ㴻")): link = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ㴼"))+link
			else: link = url.rsplit(l11lll_l1_ (u"ࠫ࠴࠭㴽"),1)[0]+l11lll_l1_ (u"ࠬ࠵ࠧ㴾")+link
		if params!=l11lll_l1_ (u"࠭ࠧ㴿"): link = link+l11lll_l1_ (u"ࠧࡽࠩ㵀")+params
		if l11lll_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㵁") in list(l1l11l11l111_l1_.keys()):
			l1lllllll1_l1_ = l1l11l11l111_l1_[l11lll_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㵂")]
			l1lllllll1_l1_ = l1lllllll1_l1_.replace(l11lll_l1_ (u"ࠪࠦࠬ㵃"),l11lll_l1_ (u"ࠫࠬ㵄")).replace(l11lll_l1_ (u"ࠧ࠭ࠢ㵅"),l11lll_l1_ (u"࠭ࠧ㵆")).split(l11lll_l1_ (u"ࠧࠤࠩ㵇"),1)[0]
			l111lll11l_l1_ = l11l1ll1ll_l1_(l1lllllll1_l1_)
			if l111lll11l_l1_: l1lll1lll_l1_ = title+l11lll_l1_ (u"ࠨࠢࠣࠫ㵈")+l111lll11l_l1_
			else: l1lll1lll_l1_ = title
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠩࠣࠤࡕࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦࠩ㵉")
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠪࠤࠥ࠭㵊")+SERVER(l1lllllll1_l1_,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㵋"))
			l1lll1ll_l1_.append(l1lll1lll_l1_)
			l1111_l1_.append(l1lllllll1_l1_)
			l1lllll11l1l_l1_.append(l11l111l_l1_)
			l1l1lllll11l_l1_.append(l111ll111ll_l1_)
		link = link.split(l11lll_l1_ (u"ࠬࠩࠧ㵌"),1)[0]
		l111lll11l_l1_ = l11l1ll1ll_l1_(link)
		if l111lll11l_l1_: title = title+l11lll_l1_ (u"࠭ࠠࠡࠩ㵍")+l111lll11l_l1_
		title = title+l11lll_l1_ (u"ࠧࠡࠢࠪ㵎")+SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㵏"))
		l1lll1ll_l1_.append(title)
		l1111_l1_.append(link)
		l1lllll11l1l_l1_.append(l11l111l_l1_)
		l1l1lllll11l_l1_.append(l111ll111ll_l1_)
	zz = list(zip(l1lll1ll_l1_,l1111_l1_,l1lllll11l1l_l1_,l1l1lllll11l_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll1ll_l1_,l1111_l1_,l1lllll11l1l_l1_,l1l1lllll11l_l1_ = list(zip(*zz))
	l1lll1ll_l1_,l1111_l1_ = list(l1lll1ll_l1_),list(l1111_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩࠪ㵐"), l1lll1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪࠫ㵑"), l1111_l1_)
	return l1lll1ll_l1_,l1111_l1_
def DNS_RESOLVER(host,l1l111lll1ll_l1_=l11lll_l1_ (u"ࠫࠬ㵒")):
	if not l1l111lll1ll_l1_: l1l111lll1ll_l1_ = l1lll1l1l1ll_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㵓"),l11lll_l1_ (u"࠭ࠧ㵔"),str(l1l111lll1ll_l1_),str(host))
	if host.replace(l11lll_l1_ (u"ࠧ࠯ࠩ㵕"),l11lll_l1_ (u"ࠨࠩ㵖")).isdigit(): return [host]
	import struct,socket
	try:
		l1111l1l1ll_l1_ = struct.pack(l11lll_l1_ (u"ࠤࡁࡌࠧ㵗"), 12049)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㵘"), 256)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠦࡃࡎࠢ㵙"), 1)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡄࡈࠣ㵚"), 0)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠨ࠾ࡉࠤ㵛"), 0)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠢ࠿ࡊࠥ㵜"), 0)
		if kodi_version>18.99: l1ll1l1ll111_l1_ = host.split(l11lll_l1_ (u"ࠨ࠰ࠪ㵝"))
		else: l1ll1l1ll111_l1_ = host.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㵞")).split(l11lll_l1_ (u"ࠪ࠲ࠬ㵟"))
		for part in l1ll1l1ll111_l1_:
			parts = part.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㵠"))
			l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡈࠢ㵡"), len(part))
			for l1llll11l11l_l1_ in part:
				l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠨࡣࠣ㵢"), l1llll11l11l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㵣")))
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠣࡄࠥ㵤"), 0)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠤࡁࡌࠧ㵥"), 1)
		l1111l1l1ll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㵦"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l1111l1l1ll_l1_), (l1l111lll1ll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1111llllll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ㵧"), data, 0)
		l1llllll11l1_l1_ = l1111llllll_l1_[3]
		offset = len(host)+18
		l1111l11111_l1_ = []
		for _ in range(l1llllll11l1_l1_):
			l1lllll111ll_l1_ = offset
			l1ll11l1l111_l1_ = 1
			l1lll1l11111_l1_ = False
			while True:
				l1llll11l11l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠧࡄࡂࠣ㵨"), data, l1lllll111ll_l1_)[0]
				if l1llll11l11l_l1_ == 0:
					l1lllll111ll_l1_ += 1
					break
				# l1l1l1ll1111_l1_ the field l1l1l11l1l1l_l1_ the first l111l111ll1_l1_ bits l1l1ll1ll111_l1_ to 1, l1llllllllll_l1_ a pointer
				if l1llll11l11l_l1_ >= 192:
					l1llll11111l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠨ࠾ࡃࠤ㵩"), data, l1lllll111ll_l1_ + 1)[0]
					# l1l11l111111_l1_ the pointer
					l1lllll111ll_l1_ = ((l1llll11l11l_l1_ << 8) + l1llll11111l_l1_ - 0xc000) - 1
					l1lll1l11111_l1_ = True
				l1lllll111ll_l1_ += 1
				if l1lll1l11111_l1_ == False: l1ll11l1l111_l1_ += 1
			if l1lll1l11111_l1_ == True: l1ll11l1l111_l1_ += 1
			offset = offset + l1ll11l1l111_l1_
			l11l11ll1l1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠢ࠿ࡊࡋࡍࡍࠨ㵪"), data, offset)
			offset = offset + 10
			l111l111lll_l1_ = l11l11ll1l1_l1_[0]
			l1lll1l111l1_l1_ = l11l11ll1l1_l1_[3]
			if l111l111lll_l1_ == 1: # l11111lll1l_l1_ type
				l1llll11l1l1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠣࡀࠥ㵫")+l11lll_l1_ (u"ࠤࡅࠦ㵬")*l1lll1l111l1_l1_, data, offset)
				l1l1ll1ll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ㵭")
				for l1llll11l11l_l1_ in l1llll11l1l1_l1_: l1l1ll1ll1ll_l1_ += str(l1llll11l11l_l1_) + l11lll_l1_ (u"ࠫ࠳࠭㵮")
				l1l1ll1ll1ll_l1_ = l1l1ll1ll1ll_l1_[0:-1]
				l1111l11111_l1_.append(l1l1ll1ll1ll_l1_)
			if l111l111lll_l1_ in [1,2,5,6,15,28]: offset = offset + l1lll1l111l1_l1_
	except: l1111l11111_l1_ = []
	if not l1111l11111_l1_: LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㵯"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬ㵰")+host+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㵱"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㵲"),l11lll_l1_ (u"ࠩࠪ㵳"),str(host),str(l1111l11111_l1_))
	return l1111l11111_l1_
def l11ll11_l1_(script_name,url,l11ll1l_l1_,l1ll_l1_=True):
	if l11ll1l_l1_:
		l1111llll1l_l1_ = [l11lll_l1_ (u"ࠪ็ออัࠨ㵴"),l11lll_l1_ (u"ࠫออไ฻ࠩ㵵"),l11lll_l1_ (u"ࠬࡧࡤࡶ࡮ࡷࠫ㵶"),l11lll_l1_ (u"࠭ࡸࡹࠩ㵷"),l11lll_l1_ (u"ࠧࡴࡧࡻࠫ㵸")]
		if script_name!=l11lll_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㵹"):
			l1111llll1l_l1_ += [l11lll_l1_ (u"ࠩࡵ࠾ࠬ㵺"),l11lll_l1_ (u"ࠪࡶ࠲࠭㵻"),l11lll_l1_ (u"ࠫ࠲ࡳࡡࠨ㵼")]
			l1111llll1l_l1_ += [l11lll_l1_ (u"ࠬࡀࡲࠨ㵽"),l11lll_l1_ (u"࠭࠭ࡳࠩ㵾"),l11lll_l1_ (u"ࠧ࡮ࡣ࠰ࠫ㵿")]
		for l1ll1ll111_l1_ in l11ll1l_l1_:
			if l11lll_l1_ (u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ㶀") in l1ll1ll111_l1_: continue
			if l11lll_l1_ (u"ࠩะ่็ฯࠧ㶁") in l1ll1ll111_l1_: continue
			l1ll1ll111_l1_ = l1ll1ll111_l1_.lower()
			if kodi_version<19: l1ll1ll111_l1_ = l1ll1ll111_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㶂")).encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㶃"))
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㶄"),l11lll_l1_ (u"࠭ࠧ㶅"),l11lll_l1_ (u"ࠧࠨ㶆"),str(l1ll1ll111_l1_))
			#l1lllll1ll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࡠࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ㶇"),l1ll1ll111_l1_,re.DOTALL)
			#l1lllll1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࡠ࠰࠮࠱࡜࠸࠰࠽ࡢࢂ࠲࡜࠲࠰࠽ࡢ࠯ࠤࠨ㶈"),l1ll1ll111_l1_,re.DOTALL)
			#l1lllll1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢ࠭࠷࡛࠷࠯࠼ࡡࢁ࠸࡛࠱࠯࠼ࡡ࠮ࡢࠫࠥࠩ㶉"),l1ll1ll111_l1_,re.DOTALL)
			#l11111ll11l_l1_ = any(l1lllll1ll11_l1_,l1lllll1lll1_l1_,l1lllll1ll1l_l1_,l1lllll1l1l1_l1_)
			l1ll1ll111_l1_ = l1ll1ll111_l1_.replace(l11lll_l1_ (u"ࠫ࠿࠭㶊"),l11lll_l1_ (u"ࠬ࠭㶋"))
			l11111ll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪ㶌"),l1ll1ll111_l1_,re.DOTALL)
			l1l1llllll1l_l1_ = False
			for digits in l11111ll11l_l1_:
				if len(digits)==2:
					l1l1llllll1l_l1_ = True
					break
			if l11lll_l1_ (u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪ㶍") in l1ll1ll111_l1_: continue
			elif l11lll_l1_ (u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩ㶎") in l1ll1ll111_l1_: continue
			elif l11lll_l1_ (u"ࠩ฽๎ึࠦๅึ่ไࠫ㶏") in l1ll1ll111_l1_: continue
			elif l11ll11111l_l1_(l11lll_l1_ (u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘࡰ࡛ࡊࡖࡆࡘࡈ࡜ࠬ㶐")): continue
			elif l1ll1ll111_l1_ in [l11lll_l1_ (u"ࠫࡷ࠭㶑")] or l1l1llllll1l_l1_ or any(value in l1ll1ll111_l1_ for value in l1111llll1l_l1_):
				LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㶒"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㶓")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㶔"))
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㶕"),l11lll_l1_ (u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ㶖"))
				return True
	return False
def l1l11l1l1l11_l1_(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ㶗"),l11l1ll1111_l1_=l11lll_l1_ (u"ࠫࠬ㶘")):
	global l1l111l1l1l_l1_
	import threading
	l11l1llllll_l1_ = threading.Thread(target=l1lllll1l11l_l1_,args=(l11l1l1_l1_,l1l1ll11_l1_,l11l1ll1111_l1_))
	l11l1llllll_l1_.start()
	l11l1llllll_l1_.join()
	return l1l111l1l1l_l1_
def PLAY_VIDEO(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭㶙"),l11l1ll1111_l1_=l11lll_l1_ (u"࠭ࠧ㶚")):
	global l1l111l1l1l_l1_
	if not l11l1ll1111_l1_: l11l1ll1111_l1_ = l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㶛")
	l1l111l1l1l_l1_,l111l111l1l_l1_,httpd = l11lll_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ㶜"),l11lll_l1_ (u"ࠩࠪ㶝"),l11lll_l1_ (u"ࠪࠫ㶞")
	if len(l11l1l1_l1_)==3:
		url,l1ll111l111l_l1_,httpd = l11l1l1_l1_
		if l1ll111l111l_l1_: l111l111l1l_l1_ = l11lll_l1_ (u"ࠫࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼ࠣ࡟ࠥ࠭㶟")+l1ll111l111l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㶠")
	else: url,l1ll111l111l_l1_,httpd = l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ㶡"),l11lll_l1_ (u"ࠧࠨ㶢")
	#url = l111l_l1_(url)		# cause l1l111l111l1_l1_ for l1ll1llll_l1_ l1llll1l1_l1_ l111l1111ll_l1_ l1ll111l1l1l_l1_
	url = url.replace(l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ㶣"),l11lll_l1_ (u"ࠩࠣࠫ㶤"))	# needed for l1l11l1111l1_l1_
	l111lll11l_l1_ = l11l1ll1ll_l1_(url,l1l1ll11_l1_)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㶥"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ㶦")]:
		if l1l1ll11_l1_!=l11lll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㶧"): url = url.replace(l11lll_l1_ (u"࠭ࠠࠨ㶨"),l11lll_l1_ (u"ࠧࠦ࠴࠳ࠫ㶩"))
		LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㶪"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㶫")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㶬")+l111l111l1l_l1_)
		if l111lll11l_l1_==l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㶭") and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ㶮"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㶯")]:
			headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㶰"):l11lll_l1_ (u"ࠨࠩ㶱")}
			l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(url,headers)
			count = len(l1111_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪ㶲")+str(count)+l11lll_l1_ (u"ࠪࠤ๊๊แࠪࠩ㶳"), l1lll1ll_l1_)
				if l1l_l1_ == -1:
					DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬื฾๏๊ࠧ㶴"),l11lll_l1_ (u"ࠬ࠭㶵"))
					return l1l111l1l1l_l1_
			else: l1l_l1_ = 0
			url = l1111_l1_[l1l_l1_]
			if l1lll1ll_l1_[0]!=l11lll_l1_ (u"࠭࠭࠲ࠩ㶶"):
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㶷"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡲࡥࡤࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡩࡰࡰ࠽ࠤࡠࠦࠧ㶸")+l1lll1ll_l1_[l1l_l1_]+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㶹")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㶺"))
		#url = url+l11lll_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠲࠺࠹࠴࠵࠶࠰ࠨ㶻")
		#url = url+l11lll_l1_ (u"ࠬࢂࡄࡏࡖࡀ࠵ࠫࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫࠽ࡦࡰ࠰࡙ࡘ࠲ࡥ࡯࠽ࡴࡁ࠵࠴࠵ࠧࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࡀ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠩࡅࡨࡩࡥࡱࡶࡀ࠮࠴࠰ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫࡐ࡮ࡴࡵࡹ࠽ࠣࡅࡳࡪࡲࡰ࡫ࡧࠤ࠼࠴࠰࠼ࠢࡖࡑ࠲ࡍ࠸࠺࠴ࡄࠤࡇࡻࡩ࡭ࡦ࠲ࡒࡗࡊ࠹࠱ࡏ࠾ࠤࡼࡼࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥ࡜ࡥࡳࡵ࡬ࡳࡳ࠵࠴࠯࠲ࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠺࠼࠴࠰࠯࠵࠶࠽࠻࠴࠸࠸ࠢࡐࡳࡧ࡯࡬ࡦࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ㶼")
		if l11lll_l1_ (u"࠭࠯ࡪࡨ࡬ࡰࡲ࠵ࠧ㶽") in url: url = url+l11lll_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㶾")
		elif l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㶿") in url.lower() and l11lll_l1_ (u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩ㷀") not in url and l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ㷁") not in url:
			if l11lll_l1_ (u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࠩ㷂") not in url and l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ㷃") in url.lower():
				if l11lll_l1_ (u"࠭ࡼࠨ㷄") not in url: url = url+l11lll_l1_ (u"ࠧࡽࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ㷅")
				else: url = url+l11lll_l1_ (u"ࠨࠨࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㷆")
			if l11lll_l1_ (u"ࠩࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭㷇") not in url.lower() and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㷈"),l11lll_l1_ (u"ࠫࡒ࠹ࡕࠨ㷉")]:
				if l11lll_l1_ (u"ࠬࢂࠧ㷊") not in url: url = url+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㷋")
				else: url = url+l11lll_l1_ (u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㷌")
		#url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ㷍"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ㷎"))
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㷏"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㷐")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㷑"))
	l11l1ll1l1l_l1_ = xbmcgui.ListItem()
	#l11l1ll1l1l_l1_ = xbmcgui.ListItem(l11lll_l1_ (u"࠭ࡴࡦࡵࡷࠫ㷒"))
	l11l1ll1111_l1_,l11ll1ll111_l1_,l11lll1l1ll_l1_,l11l1lll111_l1_,l11llll1l11_l1_,l11l1ll111l_l1_,l11ll1l1lll_l1_,l11ll1l1l1l_l1_,l11lll11l1l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㷓"),l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠭㷔")]:
		if kodi_version<19: l1l11ll11l1l_l1_ = l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬ㷕")
		else: l1l11ll11l1l_l1_ = l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨ㷖")
		#l11l1ll1l1l_l1_ = xbmcgui.ListItem(path=url)
		l11l1ll1l1l_l1_.setProperty(l1l11ll11l1l_l1_, l11lll_l1_ (u"ࠫࠬ㷗"))
		l11l1ll1l1l_l1_.setMimeType(l11lll_l1_ (u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪ㷘"))
		if kodi_version<20: l11l1ll1l1l_l1_.setInfo(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㷙"),{l11lll_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ㷚"):l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㷛")})
		else:
			l1l11l1lllll_l1_ = l11l1ll1l1l_l1_.getVideoInfoTag()
			l1l11l1lllll_l1_.setMediaType(l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㷜"))
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡯ࡣࡰࡰࠪ㷝"))
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㷞"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆ࠽࠾࠿ࡀ࠺ࠡࠩ㷟")+l11l_l1_)
		#l11l1ll1l1l_l1_.setArt({l11lll_l1_ (u"࠭ࡩࡤࡱࡱࠫ㷠"):l11l_l1_,l11lll_l1_ (u"ࠧࡵࡪࡸࡱࡧ࠭㷡"):l11l_l1_,l11lll_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨ㷢"):l11l_l1_})
		l11l1ll1l1l_l1_.setArt({l11lll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢࠨ㷣"):l11llll1l11_l1_,l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪ㷤"):l11llll1l11_l1_,l11lll_l1_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫ㷥"):l11llll1l11_l1_,l11lll_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ㷦"):l11llll1l11_l1_,l11lll_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨ㷧"):l11llll1l11_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪ㷨"):l11llll1l11_l1_,l11lll_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ㷩"):l11llll1l11_l1_,l11lll_l1_ (u"ࠩ࡬ࡧࡴࡴࠧ㷪"):l11llll1l11_l1_})
		#l11l1ll1l1l_l1_.setInfo(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㷫"),{l11lll_l1_ (u"࡙ࠫ࡯ࡴ࡭ࡧࠪ㷬"):name})
		#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭㷭"))
		#name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ㷮"))
		# when set to l11lll_l1_ (u"ࠢࡇࡣ࡯ࡷࡪࠨ㷯") it l111l1ll111_l1_ l1l1ll1l1111_l1_ l1ll11ll111l_l1_ and l1l1ll11ll1l_l1_ l11111l11l1_l1_ l1l11l111l11_l1_ l1l1lll1ll_l1_
		if l111lll11l_l1_ in [l11lll_l1_ (u"ࠨ࠰ࡰࡴࡩ࠭㷰"),l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㷱")]: l11l1ll1l1l_l1_.setContentLookup(True)
		else: l11l1ll1l1l_l1_.setContentLookup(False)
		#if l111lll11l_l1_ in [l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㷲")]: l11l1ll1l1l_l1_.setContentLookup(False)
		if l11lll_l1_ (u"ࠫࡷࡺ࡭ࡱࠩ㷳") in url:
			import l11ll1lllll_l1_
			l11ll1lllll_l1_.l111ll1ll1l_l1_(l11lll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㷴"),False)
		elif l111lll11l_l1_==l11lll_l1_ (u"࠭࠮࡮ࡲࡧࠫ㷵") or l11lll_l1_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ㷶") in url:
			import l11ll1lllll_l1_
			l11ll1lllll_l1_.l111ll1ll1l_l1_(l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㷷"),False)
			l11l1ll1l1l_l1_.setProperty(l1l11ll11l1l_l1_,l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㷸"))
			l11l1ll1l1l_l1_.setProperty(l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ㷹"),l11lll_l1_ (u"ࠫࡲࡶࡤࠨ㷺"))
			#l11l1ll1l1l_l1_.setMimeType(l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡨࡦࡹࡨࠬࡺࡰࡰࠬ㷻"))
			#l11l1ll1l1l_l1_.setContentLookup(False)
		if l1ll111l111l_l1_:
			l11l1ll1l1l_l1_.setSubtitles([l1ll111l111l_l1_])
			#xbmc.log(LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࡇࡤࡥࡧࡧࠤࡸࡻࡢࡵ࡫ࡷࡰࡪࠦࡴࡰࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿ࡡࠧ㷼")+l1ll111l111l_l1_+l11lll_l1_ (u"ࠧ࡞ࠩ㷽"), level=xbmc.LOGNOTICE)
	if l11l1ll1111_l1_==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㷾") and l1l1ll11_l1_==l11lll_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㷿"):
		l1l111l1l1l_l1_ = l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㸀")
		l1l1ll11_l1_ = l11lll_l1_ (u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫ㸁")
	elif l11l1ll1111_l1_==l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㸂") and l11ll1l1l1l_l1_.startswith(l11lll_l1_ (u"࠭࠶ࠨ㸃")):
		l1l111l1l1l_l1_ = l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㸄")
		l1l1ll11_l1_ = l1l1ll11_l1_+l11lll_l1_ (u"ࠨࡡࡇࡐࠬ㸅")
	# l11l1lll11l_l1_ l1l1111ll11_l1_
	#	l11ll1ll1ll_l1_ = l11lll1lll1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11ll11_l1_ with xbmc.sleep(step*1000)
	if l1l111l1l1l_l1_!=l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㸆"): l11llll11ll_l1_()
	l11ll1ll1ll_l1_ = l11lll1lll1_l1_()
	if l11ll1ll1ll_l1_.status:
		l1l111l1l1l_l1_ == l11lll_l1_ (u"ࠪࠫ㸇")
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㸈"),l11lll_l1_ (u"ࠬ࠭㸉"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㸊"),l11lll_l1_ (u"ࠧๅไาࠤ็อๅࠡษ็้อืๅอࠢหษ๏่วโࠢอุ฿๐ไ๊ࠡอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠥ็๊้ࠡำหࠥอไอ้สึࠬ㸋"))
	elif l11l1ll1111_l1_==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㸌") and not l11ll1l1l1l_l1_.startswith(l11lll_l1_ (u"ࠩ࠹ࠫ㸍")):
		#title = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡩࡵ࡮ࡨࠫ㸎"))
		#l11l1ll1l1l_l1_.setInfo(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㸏"),{l11lll_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ㸐"): 3600})
		#xbmcplugin.setContent(addon_handle,l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭㸑"))
		#l11l1ll1l1l_l1_.setInfo(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㸒"),{l11lll_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ㸓"):l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㸔")})
		#l11l1ll1l1l_l1_.setProperty(l11lll_l1_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧ㸕"),l11lll_l1_ (u"ࠫࡹࡸࡵࡦࠩ㸖"))
		#l11l1ll1l1l_l1_.setInfo(type=l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㸗"),l1l11l1l1lll_l1_={l11lll_l1_ (u"ࠨࡔࡪࡶ࡯ࡩࠧ㸘"):l11lll_l1_ (u"ࠧࡩࡧ࡯ࡰࡴࠦࡷࡰࡴ࡯ࡨࠬ㸙")})
		l11l1ll1l1l_l1_.setPath(url)
		LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㸚"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㸛")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㸜"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll1l1l_l1_)
	elif l11l1ll1111_l1_==l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㸝"):
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㸞"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㸟")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㸠"))
		l11ll1ll1ll_l1_.play(url,l11l1ll1l1l_l1_)
		#xbmc.Player().play(url,l11l1ll1l1l_l1_)
	succeeded = False
	if l1l111l1l1l_l1_==l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㸡"):
		import l11l111l11_l1_
		succeeded = l11l111l11_l1_.l11l11l1l1_l1_(url,l111lll11l_l1_,l1l1ll11_l1_)
		if succeeded: l11llll11ll_l1_()
	else:
		timeout,l1l111l1l1l_l1_ = 10,l11lll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ㸢")
		for l11l1lllll_l1_ in range(timeout):
			# l11l1lll11l_l1_ l1l1111ll11_l1_
			#	if using time.sleep() l11l1lllll1_l1_ of xbmc.sleep() l1l1111l111_l1_ the l11ll111lll_l1_ status
			#	l11lll_l1_ (u"ࠥࡱࡾࡶ࡬ࡢࡻࡨࡶ࠳ࡹࡴࡢࡶࡸࡷࠧ㸣") will stop l11ll1lll11_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l1l1l_l1_ = l11ll1ll1ll_l1_.status
			if l1l111l1l1l_l1_==l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㸤"):
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬอไโ์า๎ํฺ๊ࠦ็็ࠫ㸥"),l11lll_l1_ (u"࠭ࠧ㸦"),time=500)
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㸧"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࡶࡪࡦࡨࡳࠥ࡯ࡳࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㸨")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㸩")+l111l111l1l_l1_)
				break
			elif l1l111l1l1l_l1_==l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㸪"):
				LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㸫"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㸬")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㸭")+l111l111l1l_l1_)
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠩ㸮"),l11lll_l1_ (u"ࠨࠩ㸯"),time=500)
				break
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩฯหึ๐ࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧ㸰"),l11lll_l1_ (u"ࠪฬฬ่๊ࠡࠩ㸱")+str(timeout-l11l1lllll_l1_)+l11lll_l1_ (u"ࠫࠥัว็์ฬࠫ㸲"))
			if l1l111l1l1l_l1_:
				LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㸳"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㸴")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㸵"))
				break
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ㸶"),l11lll_l1_ (u"ࠩࠪ㸷"),time=500)
			LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㸸"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴࠡࡷࡱ࡯ࡳࡵࡷ࡯ࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㸹")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㸺")+l111l111l1l_l1_)
			l1l111l1l1l_l1_ = l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㸻")
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡪࡷࡸࡵࡪ࠺ࠎࠌࠌࠍࠨࠦࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ࠼࠸࠹࠵࠻࠵࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩࠓࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡦࡰ࡮ࡩ࡫ࠡࡱ࡮ࠤࡹࡵࠠࡴࡪࡸࡸࡩࡵࡷ࡯ࠢࡷ࡬ࡪࠦࡨࡵࡶࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ࠮ࠓࠊࠊࠋࠦ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡓࡕ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠻ࡴࡩࠩࠬࠑࠏࠏࠉࡵ࡫ࡰࡩ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠯ࠍࠋࠋࠌ࡬ࡹࡺࡰࡥ࠰ࡶ࡬ࡺࡺࡤࡰࡹࡱࠬ࠮ࠓࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࡨࡵࡶࡳࠤࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠬ࠲ࠧࠨࠫࠐࠎࠎࠨࠢࠣ㸼")
	if l1l111l1l1l_l1_ in [l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㸽"),l11lll_l1_ (u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㸾")] or succeeded: response = l1l111l1111_l1_(l1l1ll11_l1_)
	else: l11ll1ll1ll_l1_.stop()
	#if l1l111l1l1l_l1_ in [l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㸿"),l11lll_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㹀"),l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㹁"),l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㹂"),l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㹃")]: l111l11ll1l_l1_(l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪ㹄"),False)
	#l111l11ll1l_l1_(l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠴ࡴࡧࠫ㹅"))
	#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ㹆") in url and l1l111l1l1l_l1_ in [l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㹇"),l11lll_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㹈")]:
	#	l11ll1lll11_l1_ = HTTPS(False)
	#	if not l11ll1lll11_l1_:
	#		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㹉"),l11lll_l1_ (u"ࠧࠨ㹊"),l11lll_l1_ (u"ࠨษ็หฯ฻วๅุ่ࠢๆืࠧ㹋"),l11lll_l1_ (u"ุ่่๊ࠩษࠡ࠰࠱࠲ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣ๎าะวอࠢส่๎ࠦวหืส่๋ࠥิโำࠣࠬึฮืࠡ็ืๅึ࠯้ࠠๆๆ๊๊ࠥไฤีไࠤฬ๊วหืส่ࠥอไๆึไี๊ࠥวࠡ์฼ู้้ࠦๅ๋ࠣะ์อาไࠩ㹌"))
	#		return l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㹍")
	#sys.exit()
	if 0 and l1l111l1l1l_l1_==l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㹎"):
		LOG_THIS(l11lll_l1_ (u"ࠬ࠭㹏"),l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ㹐")+l11lll_l1_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ㹑"))
		while True:
			l1l111l1l1l_l1_ = l11ll1ll1ll_l1_.status
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㹒"),l11lll_l1_ (u"ࠩࡓࡐࡆ࡟࡟ࡔࡖࡄࡘ࡚࡙࠺࠻ࠢࠣࠤࠬ㹓")+l1l111l1l1l_l1_)
			if l1l111l1l1l_l1_!=l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㹔"): break
			xbmc.sleep(1000)
		LOG_THIS(l11lll_l1_ (u"ࠫࠬ㹕"),l11lll_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡗ࡙ࡇࡔࡖࡕ࠽࠾ࠥࠦࠠࠨ㹖")+l11lll_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㹗"))
	return l1l111l1l1l_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1lllll1ll_l1_ = args[0]
		l11l1ll1_l1_ = args[1]
		if not l1l1lllll1ll_l1_: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㹘")
		if not l11l1ll1_l1_: l11l1ll1_l1_ = l11lll_l1_ (u"ࠨษึฮ๊ืวาࠩ㹙")
		header = args[2]
		text = l11lll_l1_ (u"ࠩ࡟ࡲࠬ㹚").join(args[3:])
	else: l1l1lllll1ll_l1_,l11l1ll1_l1_,header,text = l11lll_l1_ (u"ࠪࠫ㹛"),l11lll_l1_ (u"ࠫࡔࡑࠧ㹜"),l11lll_l1_ (u"ࠬ࠭㹝"),l11lll_l1_ (u"࠭ࠧ㹞")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l1lllll1ll_l1_,l11lll_l1_ (u"ࠧࠨ㹟"),l11l1ll1_l1_,l11lll_l1_ (u"ࠨࠩ㹠"),header,text,**kwargs)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1lllll1ll_l1_ = args[0]
	l1ll11llll1l_l1_ = args[1]
	l1ll11l11l11_l1_ = args[2]
	if l1ll11l11l11_l1_ or l1ll11llll1l_l1_: l1ll11lll111_l1_ = True
	else: l1ll11lll111_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1lllll1ll_l1_: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㹡")
	if not l1ll11llll1l_l1_: l1ll11llll1l_l1_ = l11lll_l1_ (u"ࠪ็้อࠧ㹢")
	if not l1ll11l11l11_l1_: l1ll11l11l11_l1_ = l11lll_l1_ (u"๋ࠫ฿ๅࠨ㹣")
	if len(args)>=6: text += l11lll_l1_ (u"ࠬࡢ࡮ࠨ㹤")+args[5]
	if len(args)>=7: text += l11lll_l1_ (u"࠭࡜࡯ࠩ㹥")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1lllll1ll_l1_,l1ll11llll1l_l1_,l11lll_l1_ (u"ࠧࠨ㹦"),l1ll11l11l11_l1_,header,text,**kwargs)
	if choice==-1 and l1ll11lll111_l1_: choice = -1
	elif choice==-1 and not l1ll11lll111_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1lll11l1lll_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11lll_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㹧") in list(kwargs.keys()): l11l1l11lll_l1_ = kwargs[l11lll_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㹨")]
	else: l11l1l11lll_l1_ = 1000
	if len(args)>2 and l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㹩") not in args[2]: profile = args[2]
	else: profile = l11lll_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㹪")
	l1l11l1llll1_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬ㹫"),l11lll1llll_l1_,l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㹬"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㹭"))
	l1lll11111l1_l1_,l111111l1l1_l1_ = l1l11ll1l111_l1_(l11lll_l1_ (u"ࠨࠩ㹮"),l11lll_l1_ (u"ࠩࠪ㹯"),l11lll_l1_ (u"ࠪࠫ㹰"),header,text,profile,l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㹱"),720,False)
	#time.sleep(0.200)
	l1l11l1llll1_l1_.show()
	if profile==l11lll_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㹲"):
		l1l11l1llll1_l1_.getControl(9040).setHeight(215)
		l1l11l1llll1_l1_.getControl(9040).setPosition(55,-80)
		l1l11l1llll1_l1_.getControl(9050).setPosition(120,-60)
		l1l11l1llll1_l1_.getControl(400).setPosition(90,-35)
	l1l11l1llll1_l1_.getControl(401).setVisible(False)
	l1l11l1llll1_l1_.getControl(402).setVisible(False)
	l1l11l1llll1_l1_.getControl(9050).setImage(l1lll11111l1_l1_)
	l1l11l1llll1_l1_.getControl(9050).setHeight(l111111l1l1_l1_)
	import threading
	l11l11ll1ll_l1_ = threading.Thread(target=l1l1111llll1_l1_,args=(l1l11l1llll1_l1_,l1lll11111l1_l1_,l11l1l11lll_l1_))
	l11l11ll1ll_l1_.start()
	#l11l11ll1ll_l1_.join()
	return
	#return xbmcgui.Dialog().l1l11lll1l1l_l1_(l1l1lll1lll1_l1_=False,*args,**kwargs)
def l1l1111llll1_l1_(l1l11l1llll1_l1_,l1lll11111l1_l1_,l11l1l11lll_l1_):
	time.sleep(l11l1l11lll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll11111l1_l1_):
		try: os.remove(l1lll11111l1_l1_)
		except: pass
	#del l1l11l1llll1_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l1lllll1ll_l1_ = l11lll_l1_ (u"࠭ࠧ㹳"),l11lll_l1_ (u"ࠧࠨ㹴"),l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㹵"),l11lll_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㹶")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l1lllll1ll_l1_ = args[3]
	return l11ll11lll_l1_(l1l1lllll1ll_l1_,header,text,profile)
	#return xbmcgui.Dialog().l1ll1l11l1ll_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1l1lll1ll_l1_(*args,**kwargs)
def l11l11llll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111l1ll1ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text,profile,l1l1lllll1ll_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l11l1llll1_l1_ = l1ll11l11l1l_l1_(l11lll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㹷"),l11lll1llll_l1_,l11lll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㹸"),l11lll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㹹"))
	#l1l11l1llll1_l1_.l111111l11l_l1_(l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text,profile,l1l1lllll1ll_l1_,855)
	#return l1l11l1llll1_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠿࠲࠽ࠤࡩ࡯ࡡ࡭ࡱࡪ࠲ࡸࡺࡡࡳࡶࡅࡹࡹࡺ࡯࡯ࡵࡗ࡭ࡲ࡫࡯ࡶࡶࠫࡸ࡮ࡳࡥࡰࡷࡷ࠭ࠒࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡥ࡯ࡣࡥࡰࡪࡈࡵࡵࡶࡲࡲࡸ࠮ࠩࠎࠌࠌࠧࡩ࡯ࡡ࡭ࡱࡪ࠲ࡺࡶࡤࡢࡶࡨࡔࡷࡵࡧࡳࡧࡶࡷࡇࡧࡲࠩ࠹࠳࠭ࠎࠩࠠ࠸࠲ࠨࠑࠏࠏࡤࡪࡣ࡯ࡳ࡬࠴ࡤࡰࡏࡲࡨࡦࡲࠨࠪࠏࠍࠍࡨ࡮࡯ࡪࡥࡨࠤࡂࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡣࡩࡱ࡬ࡧࡪࡏࡄࠎࠌࠌࡸࡷࡿ࠺ࠡࡱࡶ࠲ࡷ࡫࡭ࡰࡸࡨࠬࡩ࡯ࡡ࡭ࡱࡪ࠲࡮ࡳࡡࡨࡧࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠓࠊࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠍࠋࠋࠦࡨࡪࡲࠠࡥ࡫ࡤࡰࡴ࡭ࠍࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡦ࡬ࡴ࡯ࡣࡦࠏࠍࠍࠧࠨࠢ㹺")
def l1ll11l11_l1_(l1ll111lllll_l1_):
	if kodi_version>17.99: l1l11l1llll1_l1_ = l11lll_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬ㹻")
	else: l1l11l1llll1_l1_ = l11lll_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬ㹼")
	l1ll111lllll_l1_ = l1ll111lllll_l1_.lower()
	if l1ll111lllll_l1_==l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㹽"): xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬ㹾")+l1l11l1llll1_l1_+l11lll_l1_ (u"ࠫ࠮࠭㹿"))
	elif l1ll111lllll_l1_==l11lll_l1_ (u"ࠬࡹࡴࡰࡲࠪ㺀"): xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠭㺁")+l1l11l1llll1_l1_+l11lll_l1_ (u"ࠧࠪࠩ㺂"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l1lllll1ll_l1_,l1llll1l1ll1_l1_=l11lll_l1_ (u"ࠨࠩ㺃"),l1l1l11l1111_l1_=l11lll_l1_ (u"ࠩࠪ㺄"),l1llll1ll1ll_l1_=l11lll_l1_ (u"ࠪࠫ㺅"),header=l11lll_l1_ (u"ࠫࠬ㺆"),text=l11lll_l1_ (u"ࠬ࠭㺇"),profile=l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㺈"),l1ll11ll1l1l_l1_=0,l1l1ll11lll1_l1_=0):
	if not l1l1lllll1ll_l1_: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㺉")
	l1l11l1llll1_l1_ = l1ll11l11l1l_l1_(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㺊"),l11lll1llll_l1_,l11lll_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㺋"),l11lll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㺌"))
	l1l11l1llll1_l1_.l111111l11l_l1_(l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text,profile,l1l1lllll1ll_l1_,900,l1ll11ll1l1l_l1_,l1l1ll11lll1_l1_)
	if l1ll11ll1l1l_l1_>0: l1l11l1llll1_l1_.l11l11l1l11_l1_()
	if l1l1ll11lll1_l1_>0: l1l11l1llll1_l1_.l111lllll11_l1_()
	if l1ll11ll1l1l_l1_==0 and l1l1ll11lll1_l1_==0: l1l11l1llll1_l1_.enableButtons()
	l1l11l1llll1_l1_.doModal()
	choice = l1l11l1llll1_l1_.l11l11ll11l_l1_
	return choice
def l11ll11lll_l1_(l1l1lllll1ll_l1_,header,text,profile=l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㺍")):
	if not l1l1lllll1ll_l1_: l1l1lllll1ll_l1_ = l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ㺎")
	#text = l11lll_l1_ (u"࠭࡜࡯ࠩ㺏").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11lll_l1_ (u"ࠧࠨ㺐")
	l1l11l1llll1_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡕࡧࡻࡸ࡛࡯ࡥࡸࡧࡵࡊࡺࡲ࡬ࡔࡥࡵࡩࡪࡴ࠮ࡹ࡯࡯ࠫ㺑"),l11lll1llll_l1_,l11lll_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㺒"),l11lll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㺓"))
	l1lll11111l1_l1_,l111111l1l1_l1_ = l1l11ll1l111_l1_(l11lll_l1_ (u"ࠫࠬ㺔"),l11lll_l1_ (u"ࠬ࠭㺕"),l11lll_l1_ (u"࠭ࠧ㺖"),header,text,profile,l1l1lllll1ll_l1_,1270,False)
	l1l11l1llll1_l1_.show()
	#time.sleep(1)
	#l1l11l1llll1_l1_.getControl(9050).l1l11l1l1111_l1_(1270-60)
	l1l11l1llll1_l1_.getControl(9050).setHeight(l111111l1l1_l1_)
	l1l11l1llll1_l1_.getControl(9050).setImage(l1lll11111l1_l1_)
	result = l1l11l1llll1_l1_.doModal()
	#del l1l11l1llll1_l1_
	try: os.remove(l1lll11111l1_l1_)
	except: pass
	return result
def l1l11l11l_l1_(l1l1ll11111l_l1_=True):
	if l1l1ll11111l_l1_:
		l111lll1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡴࡶࡵࠫ㺗"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㺘"),l11lll_l1_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ㺙"))
		if l111lll1l1_l1_: return l111lll1l1_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㺚"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࠤࡺࡹࡥࡳࡣࡪࡩࡳࡺ࠺ࠡࠩ㺛")+results)
	# l11l11ll111_l1_ and l11111l11l_l1_ common user l1ll11111ll1_l1_ (l111l11l111_l1_ l11l11l1l1l_l1_)
	text = l11lll_l1_ (u"ࠬ࠭㺜")
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵࡧࡦ࡬ࡧࡲ࡯ࡨ࠰ࡺ࡭ࡱࡲࡳࡩࡱࡸࡷࡪ࠴ࡣࡰ࡯࠲࠶࠵࠷࠲࠰࠲࠴࠳࠵࠹࠯࡮ࡱࡶࡸ࠲ࡩ࡯࡮࡯ࡲࡲ࠲ࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࡵ࠲ࠫ㺝")
	headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㺞"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㺟"),url,l11lll_l1_ (u"ࠩࠪ㺠"),headers,l11lll_l1_ (u"ࠪࠫ㺡"),l11lll_l1_ (u"ࠫࠬ㺢"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭㺣"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11lll_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧ㺤"))
		if count>80:
			text = re.findall(l11lll_l1_ (u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㺥"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㺦"),l11lll_l1_ (u"ࠩࠪ㺧"),l11lll_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠭㺨"),l11lll_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡘࡗࡊࡘ࠭ࡂࡉࡈࡒ࡙࡙ࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࠫ㺩"))
	if not text:
		l1ll1l1l1lll_l1_ = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㺪"),l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧ㺫"))
		text = open(l1ll1l1l1lll_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ㺬")).read()
		if kodi_version>18.99: text = text.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㺭"))
		text = text.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ㺮"),l11lll_l1_ (u"ࠪࠫ㺯"))
	l1ll1lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡓ࡯ࡻ࡫࡯ࡰࡦ࠴ࠪࡀࠫ࡟ࡲࠬ㺰"),text,re.DOTALL)
	l111ll1l11l_l1_ = []
	for line in l1ll1lll111l_l1_:
		l1ll111lll11_l1_ = line.lower()
		if l11lll_l1_ (u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭㺱") in l1ll111lll11_l1_: continue
		if l11lll_l1_ (u"࠭ࡵࡣࡷࡱࡸࡺ࠭㺲") in l1ll111lll11_l1_: continue
		if l11lll_l1_ (u"ࠧࡪࡲ࡫ࡳࡳ࡫ࠧ㺳") in l1ll111lll11_l1_: continue
		if l11lll_l1_ (u"ࠨࡥࡵࡳࡸ࠭㺴") in l1ll111lll11_l1_: continue
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡲࡲࠧ㺵") in l1ll111lll11_l1_: continue
		l111ll1l11l_l1_.append(line)
	l111lll1l1_l1_ = random.sample(l111ll1l11l_l1_,1)
	l111lll1l1_l1_ = l111lll1l1_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㺶"),l11lll_l1_ (u"ࠫࠬ㺷"),str(len(l1ll1lll111l_l1_)),l111lll1l1_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㺸"),l11lll_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㺹"),l111lll1l1_l1_,REGULAR_CACHE)
	return l111lll1l1_l1_
def l11l11l1ll1_l1_(l1llll1111l1_l1_):
	#if l11lll_l1_ (u"ࠧࡧࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠬ㺺") in str(error).lower(): return
	#l1llll1111l1_l1_ = traceback.format_exc()
	sys.stderr.write(l1llll1111l1_l1_)
	lines = l1llll1111l1_l1_.splitlines()
	error = lines[-1]
	l1lllll11l11_l1_ = open(l1ll1l1l111l_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㺻")).read()
	if kodi_version>18.99: l1lllll11l11_l1_ = l1lllll11l11_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㺼"))
	l1lllll11l11_l1_ = l1lllll11l11_l1_[-8000:]
	sep = l11lll_l1_ (u"ࠪࡁࠬ㺽")*100
	if sep in l1lllll11l11_l1_: l1lllll11l11_l1_ = l1lllll11l11_l1_.rsplit(sep,1)[1]
	if error in l1lllll11l11_l1_: l1lllll11l11_l1_ = l1lllll11l11_l1_.rsplit(error,1)[0]
	#l11ll11lll_l1_(l11lll_l1_ (u"ࠫࠬ㺾"),error,l1lllll11l11_l1_)
	#l11llllll11_l1_ = l1lllll11l11_l1_.splitlines()
	#for line in reversed(l11llllll11_l1_):
	#	if l11lll_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳࠨ㺿") in line or l11lll_l1_ (u"࠭ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠭㻀") in line: continue
	#	if l11lll_l1_ (u"ࠧࡎࡱࡧࡩ࠿࡛ࠦࠨ㻁") not in line: continue
	l1l1l1l11lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧ㻂"),l1lllll11l11_l1_,re.DOTALL)
	for typ,source in reversed(l1l1l1l11lll_l1_):
		#if l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࠫ㻃") in source: continue
		#if l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࠭㻄") in source: continue
		if source: break
	else: source = l11lll_l1_ (u"ࠫࡓࡕࡔࠡࡕࡓࡉࡈࡏࡆࡊࡇࡇࠫ㻅")
	#l11ll11lll_l1_(l11lll_l1_ (u"ࠬ࠭㻆"),source,str(l1l1l1l11lll_l1_))
	file,line,func = l11lll_l1_ (u"࠭ࠧ㻇"),l11lll_l1_ (u"ࠧࠨ㻈"),l11lll_l1_ (u"ࠨࠩ㻉")
	l111l1lllll_l1_ = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㻊")+error
	l1lll1l11l11_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㻋")+source
	for l1ll11lll1ll_l1_ in reversed(lines):
		if l11lll_l1_ (u"ࠫࡋ࡯࡬ࡦࠢࠥࠫ㻌") in l1ll11lll1ll_l1_ and l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㻍") in l1ll11lll1ll_l1_: break
	l1ll11lll1ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩ㻎"),l1ll11lll1ll_l1_,re.DOTALL)
	if l1ll11lll1ll_l1_:
		file,line,func = l1ll11lll1ll_l1_[0]
		if l11lll_l1_ (u"ࠧ࠰ࠩ㻏") in file: file = file.rsplit(l11lll_l1_ (u"ࠨ࠱ࠪ㻐"),1)[1]
		else: file = file.rsplit(l11lll_l1_ (u"ࠩ࡟ࡠࠬ㻑"),1)[1]
		l1l11l1ll111_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㻒")+file
		line2 = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㻓")+line
		l1111l1ll11_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㻔")+func
		l1lllll11ll1_l1_ = l1l11l1ll111_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㻕")+line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㻖")+l1111l1ll11_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㻗")+l1lll1l11l11_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㻘")+l111l1lllll_l1_
		l1ll1111l1l1_l1_ = line2+l11lll_l1_ (u"ࠪࡠࡳ࠭㻙")+l1lll1l11l11_l1_+l11lll_l1_ (u"ࠫࡡࡴࠧ㻚")+l111l1lllll_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㻛")+l1l11l1ll111_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㻜")+l1111l1ll11_l1_
		l111lll1lll_l1_ = line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㻝")+l111l1lllll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㻞")+l1l11l1ll111_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㻟")+l1111l1ll11_l1_
	else:
		l1l11l1ll111_l1_,line2,l1111l1ll11_l1_ = l11lll_l1_ (u"ࠪࠫ㻠"),l11lll_l1_ (u"ࠫࠬ㻡"),l11lll_l1_ (u"ࠬ࠭㻢")
		l1lllll11ll1_l1_ = l1lll1l11l11_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ㻣")+l111l1lllll_l1_
		l1ll1111l1l1_l1_ = l1lll1l11l11_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㻤")+l111l1lllll_l1_
		l111lll1lll_l1_ = l111l1lllll_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l11lll_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡵࡹࡲ࡬ࡦࡲࡦࡴࠩ㻥"),time=2000)
	l1111l1l111_l1_ = l11lll_l1_ (u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭㻦")+l11lll_l1_ (u"ࠪࡠࡳ࠭㻧")
	addons = l111111111l_l1_()
	l1ll1l11ll1l_l1_ = []
	results = addons[l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㻨")]
	l1ll11ll1lll_l1_ = l1l111l11ll1_l1_(l11ll111l11_l1_)
	if l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㻩") in list(addons.keys()):
		for l1l1l1llll1l_l1_,l1lll1lll11l_l1_,l111ll11111_l1_ in results: l1ll1l11ll1l_l1_ = max(l1ll1l11ll1l_l1_,l1lll1lll11l_l1_)
		if l1ll11ll1lll_l1_<l1ll1l11ll1l_l1_:
			header = l11lll_l1_ (u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ㻪")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㻫"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㻬"),l11lll_l1_ (u"ࠩอัิ๐หࠨ㻭"),l11lll_l1_ (u"ࠪาึ๎ฬࠨ㻮"),l1111l1l111_l1_+header,l1lllll11ll1_l1_)
			if choice==0:
				l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㻯"),l11lll_l1_ (u"ࠬิั้ฮࠪ㻰"),l11lll_l1_ (u"࠭สฮัํฯࠬ㻱"),l11lll_l1_ (u"ࠧࠨ㻲"),header)
				if l1ll111ll1_l1_==1: choice = 1
			if choice==1:
				import l11ll1lllll_l1_
				l11ll1lllll_l1_.l1ll11l111ll_l1_()
			return
	l1l1111lll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㻳"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㻴"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㻵"))
	if not l1l1111lll1l_l1_: l1l1111lll1l_l1_ = []
	l1ll1111l1l1_l1_ = l1ll1111l1l1_l1_.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ㻶"),l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ㻷")).replace(l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ㻸"),l11lll_l1_ (u"ࠧࠨ㻹")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㻺"),l11lll_l1_ (u"ࠩࠪ㻻")).replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㻼"),l11lll_l1_ (u"ࠫࠬ㻽"))
	l111lll1lll_l1_ = l111lll1lll_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㻾"),l11lll_l1_ (u"࠭࡜࡝ࡰࠪ㻿")).replace(l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㼀"),l11lll_l1_ (u"ࠨࠩ㼁")).replace(l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㼂"),l11lll_l1_ (u"ࠪࠫ㼃")).replace(l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㼄"),l11lll_l1_ (u"ࠬ࠭㼅"))
	l1l111ll1111_l1_ = l11ll111l11_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ㼆")+l111lll1lll_l1_
	if l1l111ll1111_l1_ in l1l1111lll1l_l1_:
		header = l11lll_l1_ (u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㼇")
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㼈"),l11lll_l1_ (u"ࠩัีําࠧ㼉"),l11lll_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㼊"),l1111l1l111_l1_+header,l1lllll11ll1_l1_)
		#if l1ll111ll1_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㼋"),l11lll_l1_ (u"ࠬิั้ฮࠪ㼌"),l11lll_l1_ (u"࠭ࠧ㼍"),header)
		DIALOG_OK(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㼎"),l11lll_l1_ (u"ࠨࠩ㼏"),l1111l1l111_l1_+header,l1lllll11ll1_l1_)
		return
	l1l111lll1l1_l1_ = str(kodi_version).split(l11lll_l1_ (u"ࠩ࠱ࠫ㼐"))[0]
	#l111llll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㼑"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㼒"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡎࡒࡔ࡝ࡎࡠࡇࡕࡖࡔࡘࡓࠨ㼓"))
	url = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㼔")][6]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㼕"),url,l11lll_l1_ (u"ࠨࠩ㼖"),l11lll_l1_ (u"ࠩࠪ㼗"),l11lll_l1_ (u"ࠪࠫ㼘"),l11lll_l1_ (u"ࠫࠬ㼙"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨ㼚"),False,False)
	html = response.content
	l111llll1ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㼛"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㼜"),l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡑࡎࡐ࡙ࡑࡣࡊࡘࡒࡐࡔࡖࠫ㼝"),l111llll1ll_l1_,REGULAR_CACHE)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㼞"),line+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㼟")+error+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㼠")+l11ll111l11_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㼡")+l1l111lll1l1_l1_)
	for l1111l11l11_l1_,l111l1llll1_l1_,l1lll111l1ll_l1_,l1ll1111l11l_l1_ in l111llll1ll_l1_:
		l1111l11l11_l1_ = l1111l11l11_l1_.split(l11lll_l1_ (u"࠭ࠫࠨ㼢"))
		l1lll111l1ll_l1_ = l1lll111l1ll_l1_.split(l11lll_l1_ (u"ࠧࠬࠩ㼣"))
		l1ll1111l11l_l1_ = l1ll1111l11l_l1_.split(l11lll_l1_ (u"ࠨ࠭ࠪ㼤"))
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㼥"),str(l1111l11l11_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㼦")+l111l1llll1_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㼧")+str(l1lll111l1ll_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㼨")+str(l1ll1111l11l_l1_))
		if line in l1111l11l11_l1_ and error==l111l1llll1_l1_ and l11ll111l11_l1_ in l1lll111l1ll_l1_ and l1l111lll1l1_l1_ in l1ll1111l11l_l1_:
			header = l11lll_l1_ (u"࠭็ัษࠣห้ิืฤ่ࠢ฽ึ๎แ๊ࠡึ๎฾อไอࠢหห้หีะษิࠤฬ๊โศั่ࠫ㼩")
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㼪"),l11lll_l1_ (u"ࠨะิ์ั࠭㼫"),l11lll_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㼬"),l1111l1l111_l1_+header,l1lllll11ll1_l1_)
			if l1ll111ll1_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㼭"),l11lll_l1_ (u"ࠫࠬ㼮"),l11lll_l1_ (u"ࠬ࠭㼯"),header)
			return
	header = l11lll_l1_ (u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㼰")
	DIALOG_OK(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㼱"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㼲"),l1111l1l111_l1_+header,l1lllll11ll1_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㼳"),l11lll_l1_ (u"ࠪ็้อࠧ㼴"),l11lll_l1_ (u"๋ࠫ฿ๅࠨ㼵"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㼶"),l11lll_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎฾ืแࠡษ็้อืๅอࠢฦ๎๋่ࠦๆฬ์ࠤํ้๊โ๋่๊ࠢอะศࠢะู้ะ่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠศื็หาࠦๅีๅ็อࠥ๎็้ࠢ็หࠥ๐ูาใࠣ็๏็ู้ࠠิฮࠥ๎ไๆษำหࠥ฾็าฬࠣ์๊ะฺ้๊ࠡีฯࠦ็ั้ࠣห้๋ิไๆฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤำึห้ࠦวๅีฯ่ࠥลࠧ㼷"))
	if l1ll111ll1_l1_==1: l1l111ll11ll_l1_ = l11lll_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ㼸")
	else:
		DIALOG_OK(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㼹"),l11lll_l1_ (u"ࠩࠪ㼺"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㼻"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสๆࠢศ่฿อมࠡวิืฬ๊ࠠศๆั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ㼼"))
		return
	message = l1ll1111l1l1_l1_
	import l11ll1lllll_l1_
	succeeded = l11ll1lllll_l1_.l1111ll11l1_l1_(l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵࡷࠬ㼽"),message,True,l11lll_l1_ (u"࠭ࠧ㼾"),l11lll_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ㼿"),l1l111ll11ll_l1_)
	if succeeded and l1l111ll11ll_l1_:
		l1l1111lll1l_l1_.append(l1l111ll1111_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㽀"),l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ㽁"),l1l1111lll1l_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㽂"))
	filename = l11lll_l1_ (u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ㽃")+str(time.time())+l11lll_l1_ (u"ࠬ࠴ࡤࡢࡶࠪ㽄")
	open(filename,l11lll_l1_ (u"࠭ࡷࡣࠩ㽅")).write(data)
	return
def l11l111l1l1_l1_(l1l1111111l_l1_):
	if l1l1111111l_l1_:
		l1l1l1l11l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㽆"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㽇"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㽈"))
		if l1l1l1l11l1l_l1_: return l1l1l1l11l1l_l1_
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㽉")][5]
	user = l11llll1l1l_l1_(32)
	l1lll1lll1ll_l1_ = l11l1ll1l11_l1_()
	l1ll111ll11l_l1_ = l1lll1lll1ll_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭㽊"))[2]
	l1l1lll1llll_l1_ = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㽋"))
	l1ll1ll1ll1l_l1_ = l1l11l11llll_l1_()
	payload = {l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ㽌"):user,l11lll_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㽍"):l11ll111l11_l1_,l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㽎"):l1ll111ll11l_l1_,l11lll_l1_ (u"ࠩ࡬ࡨࡸ࠭㽏"):l1l1lll1l11l_l1_(l1ll1ll1ll1l_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㽐"),url,payload,l11lll_l1_ (u"ࠫࠬ㽑"),l11lll_l1_ (u"ࠬ࠭㽒"),l11lll_l1_ (u"࠭ࠧ㽓"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬ㽔"))
	if not response.succeeded: return []
	html = response.content
	l1l1l1l11l1l_l1_ = html.replace(l11lll_l1_ (u"ࠨ࡞࡟ࡶࠬ㽕"),l11lll_l1_ (u"ࠩ࡟ࡲࠬ㽖")).replace(l11lll_l1_ (u"ࠪࡠࡡࡴࠧ㽗"),l11lll_l1_ (u"ࠫࡡࡴࠧ㽘")).replace(l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㽙"),l11lll_l1_ (u"࠭࡜࡯ࠩ㽚")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ㽛"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ㽜"))
	l1l1l1l11l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ㽝"),l1l1l1l11l1l_l1_,re.DOTALL)
	if not l1l1l1l11l1l_l1_: return []
	l1l1l1l11l1l_l1_ = sorted(l1l1l1l11l1l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l111l11l11_l1_,l1l11l11l1ll_l1_,l1111l11111_l1_,l11111ll111_l1_,reason = l1l1l1l11l1l_l1_[0]
	#if l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ㽞") in reason: l1l1llll1ll1_l1_,l1l1llll1lll_l1_,l1l1lllll111_l1_ = reason.split(l11lll_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ㽟"),2)
	#else: l1l1llll1ll1_l1_,l1l1llll1lll_l1_,l1l1lllll111_l1_ = reason,reason,reason
	l1ll1111ll1l_l1_ = reason if l11ll11111l_l1_(l11lll_l1_ (u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ㽠")) else l1l11l11l1ll_l1_
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㽡"),l1ll1111ll1l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㽢"),l11lll_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㽣"),l1l1l1l11l1l_l1_,REGULAR_CACHE)
	return l1l1l1l11l1l_l1_
def SPLIT_BIGLIST(items,l1l111l1lll1_l1_=0,l1ll1l1lllll_l1_=0):
	if l1l111l1lll1_l1_ and not l1ll1l1lllll_l1_: l1ll1l1lllll_l1_ = len(items)//l1l111l1lll1_l1_
	l1ll11ll1ll1_l1_,l11l1lllll_l1_,l1ll111lll1l_l1_ = [],-1,0
	for item in items:
		if l1ll111lll1l_l1_%l1ll1l1lllll_l1_==0:
			l11l1lllll_l1_ += 1
			l1ll11ll1ll1_l1_.append([])
		l1ll11ll1ll1_l1_[l11l1lllll_l1_].append(item)
		l1ll111lll1l_l1_ += 1
	return l1ll11ll1ll1_l1_
	l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉ࡭ࡧࡱ࡫ࡹ࡮ࠠ࠾ࠢ࡯ࡩࡳ࠮ࡢࡪࡩ࡯࡭ࡸࡺࠩࠎࠌࠌࡷࡵࡲࡩࡵࡶࡨࡨࠥࡃࠠ࡜࡟ࠐࠎࠎ࡬࡯ࡳࠢ࡬࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠲࠮ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴࠬ࠳ࠬ࠾ࠒࠐࠉࠊ࡫ࡩࠤ࡮࡯ࠡ࠾ࡵࡳࡰ࡮ࡺࡳࡠࡥࡲࡹࡳࡺ࠺ࠎࠌࠌࠍࠎࡲࡩ࡯ࡧࡶ࠴ࠥࡃࠠࡣ࡫ࡪࡰ࡮ࡹࡴ࡜࠲࠽࡭ࡳࡺࠨ࡭ࡧࡱ࡫ࡹ࡮࠯ࡴࡲ࡯࡭ࡹࡹ࡟ࡤࡱࡸࡲࡹ࠯࡝ࠎࠌࠌࠍࠎࡪࡥ࡭ࠢࡥ࡭࡬ࡲࡩࡴࡶ࡞࠴࠿࡯࡮ࡵࠪ࡯ࡩࡳ࡭ࡴࡩ࠱ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴࠪ࡟ࠌࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠓࠊࠊࠋࠌࡰ࡮ࡴࡥࡴ࠲ࠣࡁࠥࡨࡩࡨ࡮࡬ࡷࡹࠓࠊࠊࠋࠌࡨࡪࡲࠠࡣ࡫ࡪࡰ࡮ࡹࡴࠎࠌࠌࠍࡸࡶ࡬ࡪࡶࡷࡩࡩ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰࡨࡷ࠵࠯ࠍࠋࠋࠌࡨࡪࡲࠠ࡭࡫ࡱࡩࡸ࠶ࠍࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡶࡴࡱ࡯ࡴࡵࡧࠐࠎࠎࠨࠢࠣ㽤")
def l1lllllll1l1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11lll_l1_ (u"ࠪࡨࡺࡳ࡭ࡺࡰࡤࡱࡪ࠭㽥"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11lll_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ㽦") not in filename or l11lll_l1_ (u"ࠬࡓ࠳ࡖࡡࠪ㽧") not in filename: text = str(data)
	else:
		l1ll11ll1ll1_l1_ = SPLIT_BIGLIST(data,8)
		text = l11lll_l1_ (u"࠭ࠧ㽨")
		for split in l1ll11ll1ll1_l1_:
			text += str(split)+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㽩")
		text = text.strip(l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㽪"))
	l11lll1ll11_l1_ = zlib.compress(text)
	open(filepath,l11lll_l1_ (u"ࠩࡺࡦࠬ㽫")).write(l11lll1ll11_l1_)
	return
def l111ll11lll_l1_(l11llll111l_l1_,filename):
	if l11llll111l_l1_==l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㽬"): data = {}
	elif l11llll111l_l1_==l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㽭"): data = []
	elif l11llll111l_l1_==l11lll_l1_ (u"ࠬࡹࡴࡳࠩ㽮"): data = l11lll_l1_ (u"࠭ࠧ㽯")
	elif l11llll111l_l1_==l11lll_l1_ (u"ࠧࡪࡰࡷࠫ㽰"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l11lll1ll11_l1_ = open(filepath,l11lll_l1_ (u"ࠨࡴࡥࠫ㽱")).read()
	text = zlib.decompress(l11lll1ll11_l1_)
	#open(l11lll_l1_ (u"ࠩࡶ࠾ࡡࡢࡉࡑࡖ࡙࠵࠳ࡺࡸࡵࠩ㽲"),l11lll_l1_ (u"ࠪࡻࡧ࠭㽳")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11lll_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ㽴"))
	#if l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㽵") not in text: data = EVAL(l11lll_l1_ (u"࠭ࡳࡵࡴࠪ㽶"),text)
	if l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㽷") not in text: data = eval(text)
	else:
		l1ll11ll1ll1_l1_ = text.split(l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㽸"))
		del text
		data = []
		l1111lll11l_l1_ = l1111l111ll_l1_()
		id = 0
		for split in l1ll11ll1ll1_l1_:
			#data += EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭㽹"),split)
			l1111lll11l_l1_.l11111l1lll_l1_(str(id),eval,split)
			id += 1
		del l1ll11ll1ll1_l1_
		l1111lll11l_l1_.l1l1ll1lllll_l1_()
		l1111lll11l_l1_.l1l111l1ll1l_l1_()
		l1l11l11l1l1_l1_ = list(l1111lll11l_l1_.l1ll1ll1111l_l1_.keys())
		l1l11lllll11_l1_ = sorted(l1l11l11l1l1_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l11lllll11_l1_:
			data += l1111lll11l_l1_.l1ll1ll1111l_l1_[id]
	return data
def l1ll11l111l1_l1_(addon_id):
	l111l1l1ll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㽺"),addon_id,l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㽻"))
	try: l1ll1ll1llll_l1_ = open(l111l1l1ll1_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ㽼")).read()
	except:
		l1ll111ll1l1_l1_ = os.path.join(l1lll11lll11_l1_,l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㽽"),addon_id,l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ㽾"))
		try: l1ll1ll1llll_l1_ = open(l1ll111ll1l1_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㽿")).read()
		except: return l11lll_l1_ (u"ࠩࠪ㾀"),[]
	if kodi_version>18.99: l1ll1ll1llll_l1_ = l1ll1ll1llll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㾁"))
	version = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ㾂"),l1ll1ll1llll_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11lll_l1_ (u"ࠬ࠭㾃"),[]
	l11l1l11111_l1_,l11111l1l11_l1_ = version[0],l1l111l11ll1_l1_(version[0])
	return l11l1l11111_l1_,l11111l1l11_l1_
def l111111111l_l1_():
	l1llll1l11ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ㾄"),l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㾅"),l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㾆"))
	if l1llll1l11ll_l1_: return l1llll1l11ll_l1_
	addons,l1llll1l11ll_l1_ = {},{}
	l1l1l1l11lll_l1_ = [l1ll11l_l1_[l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㾇")][0]]
	if kodi_version>17.99: l1l1l1l11lll_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㾈")][1])
	if kodi_version>18.99: l1l1l1l11lll_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㾉")][2])
	for l1l1l111ll11_l1_ in l1l1l1l11lll_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㾊"),l1l1l111ll11_l1_,l11lll_l1_ (u"࠭ࠧ㾋"),l11lll_l1_ (u"ࠧࠨ㾌"),l11lll_l1_ (u"ࠨࠩ㾍"),l11lll_l1_ (u"ࠩࠪ㾎"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㾏"))
		if response.succeeded:
			html = response.content
			l1l111ll1lll_l1_ = l1l1l111ll11_l1_.rsplit(l11lll_l1_ (u"ࠫ࠴࠭㾐"),1)[0]
			l1llll1l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㾑"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1llllll1lll_l1_ in l1llll1l1l1l_l1_:
				l11111l1l1l_l1_ = l1l111ll1lll_l1_+l11lll_l1_ (u"࠭࠯ࠨ㾒")+addon_id+l11lll_l1_ (u"ࠧ࠰ࠩ㾓")+addon_id+l11lll_l1_ (u"ࠨ࠯ࠪ㾔")+l1llllll1lll_l1_+l11lll_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ㾕")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1llll1l11ll_l1_[addon_id] = []
				l1lll111llll_l1_ = l1l111l11ll1_l1_(l1llllll1lll_l1_)
				addons[addon_id].append((l1llllll1lll_l1_,l1lll111llll_l1_,l11111l1l1l_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㾖"),str(addon_id)+l11lll_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ㾗")+str(addons[addon_id]))
		l1llll1l11ll_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㾘"),l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㾙"),l1llll1l11ll_l1_,REGULAR_CACHE)
	return l1llll1l11ll_l1_
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯ࡥࡧࡥࡩࡷ࡭࠮ࡰࡴࡪ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡥࡶࡦࡴࡣࡩ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡦࡣ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡨࡲࡢࡰࡦ࡬࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷࡩࡪ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠶࠴ࡸࡡࡸ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࠧࠨࠢ㾚")
def l1l111l11ll1_l1_(l1llllll1lll_l1_):
	l1lll111llll_l1_ = []
	l1l1llll111_l1_ = l1llllll1lll_l1_.split(l11lll_l1_ (u"ࠨ࠰ࠪ㾛"))
	for l1l1111l1l_l1_ in l1l1llll111_l1_:
		parts = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰ࢂ࡛࡝࠭࡟࠱ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠭㾜"),l1l1111l1l_l1_,re.DOTALL)
		l1l11l11ll1l_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11l11ll1l_l1_.append(part)
		l1lll111llll_l1_.append(l1l11l11ll1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㾝"),str(l1llllll1lll_l1_)+l11lll_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ㾞")+str(l1lll111llll_l1_))
	return l1lll111llll_l1_
def l1ll111111ll_l1_(l1lll111llll_l1_):
	l1llllll1lll_l1_ = l11lll_l1_ (u"ࠬ࠭㾟")
	for l1l1111l1l_l1_ in l1lll111llll_l1_:
		for part in l1l1111l1l_l1_: l1llllll1lll_l1_ += str(part)
		l1llllll1lll_l1_ += l11lll_l1_ (u"࠭࠮ࠨ㾠")
	l1llllll1lll_l1_ = l1llllll1lll_l1_.strip(l11lll_l1_ (u"ࠧ࠯ࠩ㾡"))
	return l1llllll1lll_l1_
def l1ll1llll11l_l1_(l111ll11l11_l1_):
	# l1l1l11lll1l_l1_ not l111l11l11l_l1_ l1l1ll1ll1l1_l1_ l1l11lllllll_l1_ addons status l1llllll1l1_l1_ l11l1111ll_l1_ l111l1ll11_l1_ l111111l1ll_l1_
	#l1l111lll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㾢"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㾣"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࡠࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ㾤"))
	#if l1l111lll11l_l1_: return l1l111lll11l_l1_
	l1l111lll11l_l1_ = {}
	addons = l111111111l_l1_()
	l11l1111111_l1_ = l1l1ll1llll1_l1_(l111ll11l11_l1_)
	for addon_id in l111ll11l11_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1llll1l11ll_l1_ = addons[addon_id]
		l1ll1l11ll11_l1_,l111lll1l1l_l1_,l1l1111ll11l_l1_ = l1llll1l11ll_l1_[0]
		#l1llll111l11_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ㾥")+addon_id+l11lll_l1_ (u"ࠬ࠯ࠧ㾦"))
		l1llll111l11_l1_,l11111l1111_l1_ = l1ll11l111l1_l1_(addon_id)
		l111l1l111l_l1_,l1ll1l1lll11_l1_ = l11l1111111_l1_[addon_id]
		l11l111l1ll_l1_ = l111lll1l1l_l1_>l11111l1111_l1_ and l111l1l111l_l1_
		l1l1111ll1ll_l1_ = True
		if not l111l1l111l_l1_: l11l1l111ll_l1_ = l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ㾧")
		elif not l1ll1l1lll11_l1_: l11l1l111ll_l1_ = l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㾨")
		elif l11l111l1ll_l1_: l11l1l111ll_l1_ = l11lll_l1_ (u"ࠨࡱ࡯ࡨࠬ㾩")
		else:
			l11l1l111ll_l1_ = l11lll_l1_ (u"ࠩࡪࡳࡴࡪࠧ㾪")
			l1l1111ll1ll_l1_ = False
		l1l111lll11l_l1_[addon_id] = (l1l1111ll1ll_l1_,l1llll111l11_l1_,l11111l1111_l1_,l1ll1l11ll11_l1_,l111lll1l1l_l1_,l11l1l111ll_l1_,l1l1111ll11l_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㾫"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ㾬"),l1l111lll11l_l1_,REGULAR_CACHE)
	return l1l111lll11l_l1_
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࠧ࡮࡬ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳ࠮࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠰࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥࡼࡥࡳࡵ࡬ࡳࡳ࠲ࡔࡳࡷࡨ࠰࡙ࡸࡵࡦࠏࠍࠍࠨ࡫࡬ࡴࡧ࠽ࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵ࠰࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠲ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࠨࠩ࠯ࡊࡦࡲࡳࡦ࠮ࡉࡥࡱࡹࡥࠎࠌࠌࠧ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹࠦ࠽ࠡࠪࡻࡦࡲࡩ࠮ࡨࡧࡷࡇࡴࡴࡤࡗ࡫ࡶ࡭ࡧ࡯࡬ࡪࡶࡼ࡙ࠬࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬ࠯ࠧࠪ࠿ࡀ࠵࠮ࠓࠊࠊࠥ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡁࠫࠬࠓࠊࠊࠥ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠬࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡉ࡯࡯ࡦ࡙࡭ࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠮ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳࡏࡳࡆࡰࡤࡦࡱ࡫ࡤࠩࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠩࠨࠫࡀࡁ࠶࠯ࠍࠋࠋࠦࡩࡱࡹࡥ࠻ࠢ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࡰࡲࡸࠥ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡩࡴࡡࡨࡼ࡮ࡹࡴࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡨࡪࡩ࡫ࡩࡸࡺ࡟ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠊࠋࠪ࠯ࡸࡺࡲࠩࡪ࡬࡫࡭࡫ࡳࡵࡡࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠋࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡲࡰࡩࠏࠧࠬࡵࡷࡶ࠭࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡴࡲࡤࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡳ࡫ࡥࡥࡡࡸࡴࡩࡧࡴࡦࠋࠌࠫ࠰ࡹࡴࡳࠪࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡳࡵࡣࡷࡹࡸࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠫࠬࠑࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡶࡦࡴࡶ࡭ࡴࡴࡳ࠻ࠢࠣࠫ࠰ࡹࡴࡳࠪࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭࠰࠭ࠠࠡࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨ࠮࠯ࠍࠋࠋࠥࠦࠧ㾭")
def PROGRESS_UPDATE(l11l1l1ll1_l1_,l1lll1l1lll1_l1_,l1111l111l1_l1_=l11lll_l1_ (u"࠭ࠧ㾮"),line2=l11lll_l1_ (u"ࠧࠨ㾯"),l1111l11l11_l1_=l11lll_l1_ (u"ࠨࠩ㾰")):
	if kodi_version<19: l11l1l1ll1_l1_.update(l1lll1l1lll1_l1_,l1111l111l1_l1_,line2,l1111l11l11_l1_)
	else: l11l1l1ll1_l1_.update(l1lll1l1lll1_l1_,l1111l111l1_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㾱")+line2+l11lll_l1_ (u"ࠪࡠࡳ࠭㾲")+l1111l11l11_l1_)
	return
def l1l1lll111l1_l1_(l1ll11ll11ll_l1_):
	# l111l11l11l_l1_ it for this:  function(p,a,c,k,e,d)
	# l111l11l11l_l1_ it for this:  function(p,a,c,k,e,r)
	# l1lll1111l1l_l1_ l1l1l1ll111l_l1_:  https://l1ll11lll1l1_l1_.io
	def l1ll1ll1ll11_l1_(num,b,l1l1ll111l11_l1_=l11lll_l1_ (u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦ㾳")):
		return ((num == 0) and l1l1ll111l11_l1_[0]) or (l1ll1ll1ll11_l1_(num // b, b, l1l1ll111l11_l1_).lstrip(l1l1ll111l11_l1_[0]) + l1l1ll111l11_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11lll_l1_ (u"ࠧࡢ࡜ࡣࠤ㾴") + l1ll1ll1ll11_l1_(c, a) + l11lll_l1_ (u"ࠨ࡜࡝ࡤࠥ㾵"),  k[c], p)
		return p
	l1ll11ll11ll_l1_ = l1ll11ll11ll_l1_.split(l11lll_l1_ (u"ࠧࡾࠪࠪ㾶"))[1][:-1]
	l1l1l1lll11l_l1_ = eval(l11lll_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ㾷")+l1ll11ll11ll_l1_,{l11lll_l1_ (u"ࠩࡥࡥࡸ࡫ࡎࠨ㾸"):l1ll1ll1ll11_l1_,l11lll_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ㾹"):unpack})   #,locals())
	return l1l1l1lll11l_l1_
def l1ll1l1l11_l1_(url,l1ll11l1ll11_l1_=l11lll_l1_ (u"ࠫࠬ㾺")):
	if l1ll11l1ll11_l1_==l11lll_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ㾻"): url = re.sub(l11lll_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭㾼"),lambda l11l11l11ll_l1_: l11l11l11ll_l1_.group(0).lower(),url)
	elif l1ll11l1ll11_l1_==l11lll_l1_ (u"ࠧࡶࡲࡳࡩࡷ࠭㾽"): url = re.sub(l11lll_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ㾾"),lambda l11l11l11ll_l1_: l11l11l11ll_l1_.group(0).upper(),url)
	return url
def l1l1ll1llll1_l1_(l111ll11l11_l1_):
	installed,l1lll11lll1l_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1l11llll1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll11l11_l1_)==1: l1111111111_l1_ = l11lll_l1_ (u"ࠩࠫࠦࠬ㾿")+l111ll11l11_l1_[0]+l11lll_l1_ (u"ࠪࠦ࠮࠭㿀")
	else: l1111111111_l1_ = str(tuple(l111ll11l11_l1_))
	cc.execute(l11lll_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ㿁")+l1111111111_l1_+l11lll_l1_ (u"ࠬࠦ࠻ࠨ㿂"))
	l11ll1lll1l_l1_ = cc.fetchall()
	l11l1111111_l1_ = {}
	for addon_id in l111ll11l11_l1_: l11l1111111_l1_[addon_id] = (False,False)
	for addon_id,l1lll11lll1l_l1_ in l11ll1lll1l_l1_:
		installed = True
		l1lll11lll1l_l1_ = l1lll11lll1l_l1_==1
		l11l1111111_l1_[addon_id] = (installed,l1lll11lll1l_l1_)
	conn.close()
	return l11l1111111_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11lll_l1_ (u"࠭ࠧ㿃")
	if file==l1l111l11lll_l1_: status = l11111ll1l1_l1_(True,False)
	if os.path.exists(file):
		l11ll1l11ll_l1_ = open(file,l11lll_l1_ (u"ࠧࡳࡤࠪ㿄")).read()
		if kodi_version>18.99: l11ll1l11ll_l1_ = l11ll1l11ll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㿅"))
		if file==l1l111l11lll_l1_: results = l11ll1l11ll_l1_
		else:
			l1llll11l111_l1_ = EVAL(l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㿆"),l11ll1l11ll_l1_)
			if l1llll11l111_l1_:
				results = {}
				for key in l1llll11l111_l1_.keys():
					results[key] = []
					for l1ll1llll1l1_l1_ in l1llll11l111_l1_[key]:
						type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l11lll_l1_ (u"ࠪࠫ㿇"),l11lll_l1_ (u"ࠫࠬ㿈"),l11lll_l1_ (u"ࠬ࠭㿉"),l11lll_l1_ (u"࠭ࠧ㿊"),l11lll_l1_ (u"ࠧࠨ㿋"),l11lll_l1_ (u"ࠨࠩ㿌"),l11lll_l1_ (u"ࠩࠪ㿍"),l11lll_l1_ (u"ࠪࠫ㿎"),l11lll_l1_ (u"ࠫࠬ㿏")
						type = l1ll1llll1l1_l1_[0]
						name = l1ll1llll1l1_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1ll1llll1l1_l1_[2]
						mode = l1ll1llll1l1_l1_[3]
						l11l_l1_ = l1ll1llll1l1_l1_[4]
						l1l11l1_l1_ = l1ll1llll1l1_l1_[5]
						if len(l1ll1llll1l1_l1_)>6: text = l1ll1llll1l1_l1_[6]
						if len(l1ll1llll1l1_l1_)>7: context = l1ll1llll1l1_l1_[7]
						if len(l1ll1llll1l1_l1_)>8: l1ll111l111_l1_ = l1ll1llll1l1_l1_[8]
						if file==favoritesfile: l1l11l1111ll_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,l11lll_l1_ (u"ࠬ࠭㿐"),l1ll111l111_l1_
						else: l1l11l1111ll_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_
						results[key].append(l1l11l1111ll_l1_)
			l11ll111l1l_l1_ = str(results)
			if kodi_version>18.99: l11ll111l1l_l1_ = l11ll111l1l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㿑"))
			open(file,l11lll_l1_ (u"ࠧࡸࡤࠪ㿒")).write(l11ll111l1l_l1_)
	return results
def l1l1l11lll1_l1_(l1l1l1ll1ll_l1_):
	l1l1l1l11ll_l1_ = l1l1l1ll1ll_l1_.split(l11lll_l1_ (u"ࠨ࠯ࠪ㿓"),1)[0]
	l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l11lll_l1_ (u"ࠩࠪ㿔"),l11lll_l1_ (u"ࠪࠫ㿕"),l11lll_l1_ (u"ࠫࠬ㿖")
	if   l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㿗")		:	from l1l111l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ㿘")	:	from l1l1l111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㿙")		:	from l111111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㿚")	:	from l111l1l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㿛")	:	from l1ll11ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㿜")	: 	from l1l1ll111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㿝")	:	from l1l1l1ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ㿞")	:	from l11ll1111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㿟")		:	from l111l11l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㿠")	:	from l1111l11l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㿡")	:	from l1lll111ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㿢")	:	from l1ll1ll1ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㿣")	:	from l1ll1l1lll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㿤"):	from l111lll111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㿥")		:	from l1l1lll11l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㿦")		:	from l1ll1ll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㿧")	:	from l1ll111111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㿨")	:	from l1lll1l11l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㿩")	:	from l1lll1llllll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㿪")	:	from l1111l1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ㿫")	:	from l1l111l1lll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㿬")	:	from l1111l1ll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㿭")		:	from l11l11111l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ㿮")	:	from l1l11l1l111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㿯"):	from l1l1l1l11_l1_	import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㿰")	:	from l111ll1lll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㿱")	:	from l1ll1l1l1l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㿲"):	from l11lll1l11_l1_	import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㿳")	:	from l11111l1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㿴")	:	from l1lllll111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㿵")	:	from l1lll1ll1ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ㿶")	:	from l1lll1l111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㿷")	:	from l1lll11llll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㿸")	:	from l1ll1ll11l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㿹")	:	from l1ll1ll111l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㿺")	:	from l1l1llllll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㿻")	:	from l1l1l11l11l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㿼")	:	from l1llll1111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㿽")		:	from l1l1l11l111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㿾")	:	from l1l11l1lll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㿿")	:	from l11l11lll1l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ䀀")	:	from l1l1ll11l1l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ䀁")	:	from l1ll111l1111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭䀂")	:	from l1l1l11lllll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ䀃")	:	from l1l1lllll11_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ䀄")	:	from l1l1lll1ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ䀅")		:	from l1111l11lll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ䀆")	:	from l1l1l11ll111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ䀇")	:	from l1111l1lll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ䀈")	:	from l11l111ll11_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ䀉")	:	from l1l11lll11l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭䀊")		:	from l1lll11ll11l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䀋")	:	from l111lllll1l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ䀌"):	from l111ll1111l_l1_	import MENU as l1l1l1l11l1_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ䀍")		:	from IPTV			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,menu_namee as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡒ࠹ࡕࠨ䀎")		:	from M3U			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,menu_namee as l1l1lll1111_l1_
	return l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l1111ll1l1_l1_,headers,l1ll_l1_):
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭䀏"),l11lll_l1_ (u"࠭ࠧ䀐"),l11lll_l1_ (u"ࠧࠨ䀑"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䀒"),l11lll_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ์็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠤࠫ䀓"))
	#if l1ll111ll1_l1_!=1: return l11lll_l1_ (u"ࠪࠫ䀔")
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䀕"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪ䀖")+l1l1111ll1l1_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩ䀗")+str(headers)+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䀘"))
	l11l1l1ll1_l1_ = DIALOG_PROGRESS()
	l11l1l1ll1_l1_.create(l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䀙"),l11lll_l1_ (u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫ䀚"))
	l11ll111ll_l1_ = 1024*1024
	l111l1lll11_l1_ = bytes()
	chunk_size = 1*l11ll111ll_l1_
	import requests
	response = requests.get(l1l1111ll1l1_l1_,stream=True,headers=headers)
	l1l11lll111l_l1_ = response.headers
	response.close()
	if not l1l11lll111l_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䀛"),l11lll_l1_ (u"ࠫࠬ䀜"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䀝"),l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩ䀞"))
		l11l1l1ll1_l1_.close()
	else:
		if l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ䀟") not in list(l1l11lll111l_l1_.keys()): filesize = 0
		else: filesize = int(l1l11lll111l_l1_[l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ䀠")])
		l11l1lll1l_l1_ = str(int(1000*filesize/l11ll111ll_l1_)/1000.0)
		l11l11l111_l1_ = int(filesize/chunk_size)+1
		if l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩ䀡") in list(l1l11lll111l_l1_.keys()) and filesize>l11ll111ll_l1_:
			l1l1l111lll1_l1_ = True
			ranges = []
			l1l1l11ll1ll_l1_ = 10
			ranges.append(str(0*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ䀢")+str(1*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(1*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠫ࠲࠭䀣")+str(2*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(2*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ䀤")+str(3*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(3*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"࠭࠭ࠨ䀥")+str(4*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(4*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠧ࠮ࠩ䀦")+str(5*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(5*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠨ࠯ࠪ䀧")+str(6*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(6*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠩ࠰ࠫ䀨")+str(7*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(7*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ䀩")+str(8*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(8*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠫ࠲࠭䀪")+str(9*filesize//l1l1l11ll1ll_l1_-1))
			ranges.append(str(9*filesize//l1l1l11ll1ll_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ䀫"))
			l111ll1llll_l1_ = float(l11l11l111_l1_)/l1l1l11ll1ll_l1_
			l1lll111ll11_l1_ = l111ll1llll_l1_/int(1+l111ll1llll_l1_)
		else:
			l1l1l111lll1_l1_ = False
			l1l1l11ll1ll_l1_ = 1
			l1lll111ll11_l1_ = 1
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䀬"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨ䀭")+str(l1l1l111lll1_l1_)+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ䀮")+str(filesize)+l11lll_l1_ (u"ࠩࠣࡡࠬ䀯"))
		l11l1lllll_l1_ = 0
		#t1 = time.time()-30
		for l1ll111lll1l_l1_ in range(l1l1l11ll1ll_l1_):
			l1l1ll1ll_l1_ = headers.copy()
			if l1l1l111lll1_l1_: l1l1ll1ll_l1_[l11lll_l1_ (u"ࠪࡖࡦࡴࡧࡦࠩ䀰")] = l11lll_l1_ (u"ࠫࡧࡿࡴࡦࡵࡀࠫ䀱")+ranges[l1ll111lll1l_l1_]
			response = requests.get(l1l1111ll1l1_l1_,stream=True,headers=l1l1ll1ll_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1l1ll1_l1_.iscanceled():
					LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䀲"),l11lll_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭䀳"))
					break
				l11l1lllll_l1_ += l1lll111ll11_l1_
				PROGRESS_UPDATE(l11l1l1ll1_l1_,100*l11l1lllll_l1_//l11l11l111_l1_,l11lll_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨ䀴"),str(int(100*l11l1lllll_l1_*chunk_size//l11ll111ll_l1_)/100.0)+l11lll_l1_ (u"ࠨࠢ࠲ࠤࠬ䀵")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠩࠣࡑࡇ࠭䀶"))
				l111l1lll11_l1_ += chunk
				#PROGRESS_UPDATE(l11l1l1ll1_l1_,0+int(35*l11l1lllll_l1_/l11l11l111_l1_),l11lll_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆࠦวๅำษ๎ุ๐࠺࠮ࠢส่ัุมࠡำๅ้ࠬ䀷")+l11lll_l1_ (u"ࠫࡡࡴࠧ䀸")+str(l11l1lllll_l1_*chunksize/l11ll111ll_l1_)+l11lll_l1_ (u"ࠬࠦ࠯ࠡࠩ䀹")+l11l1lll1l_l1_+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ䀺")+time.strftime(l11lll_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ䀻")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ䀼")+time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠩࠣไࠬ䀽"))
				#l111llllll_l1_ = time.time()
				#l111lll1ll_l1_ = l111llllll_l1_-t1
				#l111lllll1_l1_ = l111lll1ll_l1_/l11l1lllll_l1_
				#l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
				#l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			response.close()
		l11l1l1ll1_l1_.close()
		if len(l111l1lll11_l1_)<filesize and filesize>0:
			LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䀾"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ䀿")+str(len(l111l1lll11_l1_)//l11ll111ll_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪ䁀")+l11l1lll1l_l1_+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ䁁"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ䁂"),l11lll_l1_ (u"ࠨว็฾ฬว้ࠠะิ์ั࠭䁃"),l11lll_l1_ (u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩ䁄"),l11lll_l1_ (u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬ䁅"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䁆"),l11lll_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩ䁇")+str(len(l111l1lll11_l1_)//l11ll111ll_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ䁈")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ䁉"))
			if choice==2: l111l1lll11_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111ll1l1_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䁊"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ䁋"))
			else: return l11lll_l1_ (u"ࠪࠫ䁌")
			if not l111l1lll11_l1_: return l11lll_l1_ (u"ࠫࠬ䁍")
		else: LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䁎"),l11lll_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ䁏")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭䁐"))
	return l111l1lll11_l1_
def l1lll11l1111_l1_(script_name):
	# old l1lll11llll1_l1_ l1ll11ll1111_l1_ l1l1ll111111_l1_
	# hit method:    https://l11ll11ll11_l1_.google.com/l11lllll111_l1_/l1ll1l1lll1l_l1_/collection/protocol/l1l1ll111111_l1_/l1ll1ll11l1l_l1_
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠳ࠩࡸ࡮ࡪ࠽ࡖࡃ࠰࠵࠷࠽࠰࠵࠷࠴࠴࠹࠳࠵ࠧࡥ࡬ࡨࡂ࠭䁑")+l11llll1l1l_l1_(32)+l11lll_l1_ (u"ࠩࠩࡸࡂ࡫ࡶࡦࡰࡷࠪࡸࡩ࠽ࡦࡰࡧࠪࡪࡩ࠽ࠨ䁒")+l11ll111l11_l1_+l11lll_l1_ (u"ࠪࠪࡦࡼ࠽ࠨ䁓")+l11ll111l11_l1_+l11lll_l1_ (u"ࠫࠫࡧ࡮࠾ࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࡠࡐࡈ࡛ࡈࡒࡉࡆࡐࡗࡍࡉࠬࡥࡢ࠿ࠪ䁔")+script_name+l11lll_l1_ (u"ࠬࠬࡥ࡭࠿ࠪ䁕")+str(kodi_version)+l11lll_l1_ (u"࠭ࠦࡻ࠿ࠪ䁖")+l11ll11lll1_l1_
	#response = l11lll1l111_l1_(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䁗"),url,l11lll_l1_ (u"ࠨࠩ䁘"),l11lll_l1_ (u"ࠩࠪ䁙"),l11lll_l1_ (u"ࠪࠫ䁚"),l11lll_l1_ (u"ࠫࠬ䁛"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ䁜"))
	# new l1ll1lll1l11_l1_ l1ll11ll1111_l1_ 4
	# l1l1ll111l1l_l1_ test:    https://l111lllllll_l1_-l1llll11ll1_l1_-l111l11lll1_l1_.google/l1ll1111lll1_l1_/l1llll1llll1_l1_-l1l1l1lll1l1_l1_
	# l1l1ll111l1l_l1_ json method:    https://l11ll11ll11_l1_.google.com/l11lllll111_l1_/l1ll1l1lll1l_l1_/collection/protocol/l1ll1111lll1_l1_/l1ll11llllll_l1_/l1l1ll111l1l_l1_
	# l1l1ll111l1l_l1_ json method:    https://l11ll11ll11_l1_.google.com/l11lllll111_l1_/l1ll1l1lll1l_l1_/collection/protocol/l1ll1111lll1_l1_/l1ll11llllll_l1_?l1l11lll11ll_l1_=l1l11l11lll1_l1_
	# l1l1ll111l1l_l1_ hit method:   https://www.l1lll1ll1ll1_l1_.com/l1ll1111lll1_l1_-l1lllll11111_l1_-protocol-l1lll1111lll_l1_
	# l1l1ll111l1l_l1_ hit method:   https://www.l1lll1ll1ll1_l1_.com/l111l1l1l11_l1_-l111ll11ll1_l1_-google-l11lllll111_l1_-l1lllll11111_l1_-protocol-version-2
	# l1l1ll111l1l_l1_ params:  https://data.l1l11ll11111_l1_.com
	# l1l1ll1111l1_l1_ json method
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳ࡲࡶ࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡣࡳ࡭ࡤࡹࡥࡤࡴࡨࡸࡂ࠶࠭ࡷ࠳࠸ࡅࡩࡩࡒࡈࡣࡓ࡫ࡶࡸ࡯ࡨ࡮࠸࠽ࡐࡇࠦ࡮ࡧࡤࡷࡺࡸࡥ࡮ࡧࡱࡸࡤ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠧ䁝")
	#headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䁞"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ䁟")}
	#params = {l11lll_l1_ (u"ࠩࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ䁠"):l11ll111l11_l1_,l11lll_l1_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭䁡"):kodi_version}
	#data = {l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡣ࡮ࡪࠧ䁢"):l11llll1l1l_l1_(32),l11lll_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡷࠬ䁣"):[{l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䁤"):script_name,l11lll_l1_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ䁥"):params}]}
	#response = l11lll1l111_l1_(l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䁦"),url,str(data),headers,l11lll_l1_ (u"ࠩࠪ䁧"),l11lll_l1_ (u"ࠪࠫ䁨"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ䁩"))
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࡩࡻ࡫࡮ࡵࡐࡤࡱࡪࠓࠊࠊࡣࡳࡴ࡛࡫ࡲࡴ࡫ࡲࡲࠒࠐࠉࡰࡲࡨࡶࡦࡺࡩ࡯ࡩࡖࡽࡸࡺࡥ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠏࠍࠍࡺࡧࡰࡷࠏࠍࠍࡺࡹࡥࡳࡡ࡬ࡨࠒࠐࠉࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠒࠐࠉࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡡࡹࡩࡷࡹࡩࡰࡰࠐࠎࠎ࡫ࡶࡦࡰࡷࡣࡳࡧ࡭ࡦࠏࠍࠍࠧࠨࠢ䁪")
	# l1l1ll1111l1_l1_ hit method (l11l11ll11_l1_ l11l1l1ll1l_l1_ l1l11lll1111_l1_)
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡤ࡫ࡧࡁࠬ䁫")+l11llll1l1l_l1_(32)+l11lll_l1_ (u"ࠧࠧࡡࡶࡁ࠶ࠬࡥ࡯࠿ࠪ䁬")+script_name+l11lll_l1_ (u"ࠨࠨࡸࡴ࠳ࡧࡶࡠࡸࡨࡶࡂ࠭䁭")+l11ll111l11_l1_+l11lll_l1_ (u"ࠩࠩࡹࡵ࠴࡫ࡰࡦ࡬ࡣࡻ࡫ࡲ࠾ࠩ䁮")+str(kodi_version)
	#url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡠࡦࡥ࡫ࡂ࠷ࠦࡤ࡫ࡧࡁ࠶࠾࠵࠷࠲࠷࠼࠹࠿࠷࠯࠳࠹࠽࠵࠷࠴࠶࠶࠸࠻ࠬ䁯")
	#l11ll11lll1_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡡࡧࡦ࡬ࡃ࠱ࠧࡥ࡬ࡨࡂ࠭䁰")+str(l11ll11lll1_l1_)+l11lll_l1_ (u"ࠬ࠴ࠧ䁱")+str(int(time.time()))
	#url += l11lll_l1_ (u"࠭ࠦࡶࡣࡳࡺࡂ࠷࠹࠯࠳ࠩࡨࡹࡃࡋࡐࡆࡌࠩ࠷࠶ࡅࡎࡃࡇࠪࡪࡴ࠽ࡱࡣࡪࡩࡤࡼࡩࡦࡹࠩࡣࡪ࡫࠽࠲ࠨࡸ࡭ࡩࡃ࠲࠳࠴࠵࠱࠷࠸࠲࠳࠯࠶࠷࠸࠹ࠦࡠࡵࡶࡁ࠶࠭䁲")
	#response = l11lll1l111_l1_(l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䁳"),url,l11lll_l1_ (u"ࠨࠩ䁴"),l11lll_l1_ (u"ࠩࠪ䁵"),l11lll_l1_ (u"ࠪࠫ䁶"),l11lll_l1_ (u"ࠫࠬ䁷"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ䁸"))
	# l1l1ll1111l1_l1_ modified (not good l1l111lllll1_l1_)
	#l11ll11lll1_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡤ࡫ࡧࡁࠬ䁹")+l11llll1l1l_l1_(32)+l11lll_l1_ (u"ࠧࠧࡡࡶࡁ࠶ࠬࡥ࡯࠿ࠪ䁺")+script_name+l11lll_l1_ (u"ࠨࠨࡸࡴ࠳ࡧࡶࡠࡸࡨࡶࡂ࠭䁻")+l11ll111l11_l1_+l11lll_l1_ (u"ࠩࠩࡹࡦࡶࡶ࠾ࠩ䁼")+str(kodi_version)+l11lll_l1_ (u"ࠪࠪࡤࡶ࠽ࠨ䁽")+l11ll11lll1_l1_
	#l11lll111l1_l1_ = l11l1ll1l11_l1_()
	#l1l1ll1ll1ll_l1_ = l11lll111l1_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭䁾"),1)[0]
	return response
def l11l1ll1l11_l1_(l1l1ll1ll1ll_l1_=l11lll_l1_ (u"ࠬ࠭䁿")):
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲ࡯ࡳࡨࡧࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ䂀")
	# l1l1ll111111_l1_   url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡻ࡭ࡵࡩࡴ࠰ࡤࡴࡵ࠵ࡪࡴࡱࡱ࠳ࠬ䂁")+l1l1ll1ll1ll_l1_
	# l11l1ll1ll1_l1_   url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭䂂")
	l1l1l11l1lll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡶࡸࡷ࠭䂃"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭䂄"),l11lll_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ䂅"))
	if l1l1l11l1lll_l1_: return l1l1l11l1lll_l1_
	l1l1ll1ll1ll_l1_,l1l1l1l1111l_l1_,l1ll111ll11l_l1_,l11l1l11ll1_l1_,l1ll111ll111_l1_,l1llll11llll_l1_,timezone = l11lll_l1_ (u"ࠬ࠭䂆"),l11lll_l1_ (u"࠭ࠧ䂇"),l11lll_l1_ (u"ࠧࠨ䂈"),l11lll_l1_ (u"ࠨࠩ䂉"),l11lll_l1_ (u"ࠩࠪ䂊"),l11lll_l1_ (u"ࠪࠫ䂋"),l11lll_l1_ (u"ࠫࠬ䂌")
	url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ䂍")+l1l1ll1ll1ll_l1_+l11lll_l1_ (u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ䂎")
	headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䂏"):l11lll_l1_ (u"ࠨࠩ䂐")}
	response = l11lll1l111_l1_(l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䂑"),url,l11lll_l1_ (u"ࠪࠫ䂒"),headers,l11lll_l1_ (u"ࠫࠬ䂓"),l11lll_l1_ (u"ࠬ࠭䂔"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ䂕"))
	if not response.succeeded: l1lll1lll1ll_l1_ = l1l1ll1ll1ll_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ䂖")+l1l1l1l1111l_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ䂗")+l1ll111ll11l_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ䂘")+l1ll111ll111_l1_+l11lll_l1_ (u"ࠪ࠰ࠬ䂙")+l1llll11llll_l1_+l11lll_l1_ (u"ࠫ࠱࠭䂚")+timezone
	else:
		html = response.content
		html = re.findall(l11lll_l1_ (u"ࠬࡢࡻ࠯ࠬࡂࡠࢂࡢࡽࠨ䂛"),html,re.DOTALL)
		if html:
			html = html[0]
			l11111lll11_l1_ = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ䂜"),html)
			if l11lll_l1_ (u"ࠧࡪࡲࠪ䂝") in list(l11111lll11_l1_.keys()): l1l1ll1ll1ll_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠨ࡫ࡳࠫ䂞")]
			if l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ䂟") in list(l11111lll11_l1_.keys()): l1l1l1l1111l_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭䂠")]
			if l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ䂡") in list(l11111lll11_l1_.keys()): l1ll111ll11l_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䂢")]
			if l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ䂣") in list(l11111lll11_l1_.keys()): l11l1l11ll1_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭䂤")]
			if l11lll_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ䂥") in list(l11111lll11_l1_.keys()): l1ll111ll111_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ䂦")]
			if l11lll_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ䂧") in list(l11111lll11_l1_.keys()): l1llll11llll_l1_ = l11111lll11_l1_[l11lll_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ䂨")]
			if l11lll_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ䂩") in list(l11111lll11_l1_.keys()):
				timezone = l11111lll11_l1_[l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ䂪")][l11lll_l1_ (u"ࠧࡶࡶࡦࠫ䂫")]
				if timezone[0] not in [l11lll_l1_ (u"ࠨ࠯ࠪ䂬"),l11lll_l1_ (u"ࠩ࠮ࠫ䂭")]: timezone = l11lll_l1_ (u"ࠪ࠯ࠬ䂮")+timezone
			l1lll1lll1ll_l1_ = l1l1ll1ll1ll_l1_+l11lll_l1_ (u"ࠫ࠱࠭䂯")+l1l1l1l1111l_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ䂰")+l1ll111ll11l_l1_+l11lll_l1_ (u"࠭ࠬࠨ䂱")+l1ll111ll111_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ䂲")+l1llll11llll_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ䂳")+timezone
			if kodi_version>18.99: l1lll1lll1ll_l1_ = l1lll1lll1ll_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䂴")).decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ䂵"))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ䂶"),l11lll_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ䂷"),l1lll1lll1ll_l1_,l1lll1111_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ䂸"),l1lll1lll1ll_l1_)
	return l1lll1lll1ll_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11lll_l1_ (u"ࠧࠨ䂹"),True
	if search.count(l11lll_l1_ (u"ࠨࡡࠪ䂺"))>=2:
		search,options = search.split(l11lll_l1_ (u"ࠩࡢࠫ䂻"),1)
		options = l11lll_l1_ (u"ࠪࡣࠬ䂼")+options
		if l11lll_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ䂽") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䂾"),l11lll_l1_ (u"࠭ࠧ䂿"),search,options)
	return search,options,l1ll_l1_
def l1l11l11llll_l1_():
	l1l1lll1llll_l1_ = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭䃀"))
	l1ll1ll1ll1l_l1_ = 0
	if os.path.exists(l1l1lll1llll_l1_):
		for filename in os.listdir(l1l1lll1llll_l1_):
			if l11lll_l1_ (u"ࠨ࠰ࡳࡽࡴ࠭䃁") in filename: continue
			if l11lll_l1_ (u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧ䃂") in filename: continue
			l1l11l11ll_l1_ = os.path.join(l1l1lll1llll_l1_,filename)
			size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
			l1ll1ll1ll1l_l1_ += size
	return l1ll1ll1ll1l_l1_
def l11111ll1l1_l1_(l1l1111111l_l1_,l1ll_l1_):
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ䃃")][3]
	user = l11llll1l1l_l1_(32)
	l1lll1lll1ll_l1_ = l11l1ll1l11_l1_()
	l1ll111ll11l_l1_ = l1lll1lll1ll_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭䃄"))[2]
	l1ll1ll1ll1l_l1_ = l1l11l11llll_l1_()
	payload = {l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ䃅"):user,l11lll_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䃆"):l11ll111l11_l1_,l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ䃇"):l1ll111ll11l_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࡷࠬ䃈"):l1l1lll1l11l_l1_(l1ll1ll1ll1l_l1_)}
	if not l1l1111111l_l1_: DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ䃉"),(l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䃊"),url,payload,l11lll_l1_ (u"ࠫࠬ䃋"),l11lll_l1_ (u"ࠬ࠭䃌"),l11lll_l1_ (u"࠭ࠧ䃍")))
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ䃎"),l11lll_l1_ (u"ࠨࠩ䃏"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䃐"),url,payload,l11lll_l1_ (u"ࠪࠫ䃑"),l11lll_l1_ (u"ࠫࠬ䃒"),l11lll_l1_ (u"ࠬ࠭䃓"),l11lll_l1_ (u"࠭ࡍࡆࡐࡘࡗ࠲࡙ࡈࡐ࡙ࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ䃔"),True,True)
	l11l111l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ䃕"))
	if not l11l111l11l_l1_: l11l111l11l_l1_ = l11lll_l1_ (u"ࠨࡐࡈ࡛ࠬ䃖")
	l1ll11111l1l_l1_ = l11l111l11l_l1_
	if not response.succeeded: l1ll11111l1l_l1_ = l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ䃗")
	else:
		l11ll1l111l_l1_,l1llll1111ll_l1_,l1llll11lll1_l1_,l1llll111l1l_l1_ = l11lll_l1_ (u"ࠪࠫ䃘"),l11lll_l1_ (u"ࠫࠬ䃙"),l11lll_l1_ (u"ࠬ࠭䃚"),[]
		newfile = response.content
		if newfile:
			l1llll111l1l_l1_ = EVAL(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ䃛"),newfile)
			for l1ll1l1l11ll_l1_,l1l1l1l1l111_l1_,message in l1llll111l1l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ䃜")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䃝"))
				if l1ll1l1l11ll_l1_==l11lll_l1_ (u"ࠩ࠳ࠫ䃞"): l11ll1l111l_l1_ += message+l11lll_l1_ (u"ࠪ࠾࠿࠭䃟")
				else: l1llll1111ll_l1_ += message+l11lll_l1_ (u"ࠫࡡࡴࠧ䃠")
			l1llll1111ll_l1_ = l1llll1111ll_l1_.strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䃡"))
			l11ll1l111l_l1_ = l11ll1l111l_l1_.strip(l11lll_l1_ (u"࠭࠺࠻ࠩ䃢"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ䃣"),l11ll1l111l_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ䃤"),l1l1lll1l11l_l1_(now))
		if os.path.exists(l1l111l11lll_l1_): l1llll11lll1_l1_ = open(l1l111l11lll_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ䃥")).read()
		if kodi_version>18.99: l1llll1111ll_l1_ = l1llll1111ll_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䃦"))
		if l1llll1111ll_l1_!=l1llll11lll1_l1_:
			l1ll11111l1l_l1_ = l11lll_l1_ (u"ࠫࡓࡋࡗࠨ䃧")
			try: open(l1l111l11lll_l1_,l11lll_l1_ (u"ࠬࡽࡢࠨ䃨")).write(l1llll1111ll_l1_)
			except: pass
		if l1ll_l1_:
			l1llll111l1l_l1_ = sorted(l1llll111l1l_l1_,reverse=True,key=lambda key: int(key[0]))
			l1llll11ll1l_l1_ = l11lll_l1_ (u"࠭ࠧ䃩")
			for l1ll1l1l11ll_l1_,l1l1l1l1l111_l1_,message in l1llll111l1l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ䃪")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䃫"))
				if l1llll11ll1l_l1_: l1llll11ll1l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪ䃬")
				if l1ll1l1l11ll_l1_==l11lll_l1_ (u"ࠪ࠴ࠬ䃭"): continue
				date = message.split(l11lll_l1_ (u"ࠫࡡࡴࠧ䃮"))[0]
				l1lll1ll1_l1_ = l11lll_l1_ (u"ࠬ࠭䃯")
				if l1l1l1l1l111_l1_:
					l1lll1ll1_l1_ = l11lll_l1_ (u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪ䃰")
					if kodi_version>18.99: l1lll1ll1_l1_ = l1lll1ll1_l1_.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ䃱")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䃲"))
				l1llll11ll1l_l1_ += message.replace(date,l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䃳")+date+l1lll1ll1_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䃴"))+l11lll_l1_ (u"ࠫࡡࡴࠧ䃵")
			l1llll11ll1l_l1_ = escapeUNICODE(l1llll11ll1l_l1_)
			l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䃶"),l11lll_l1_ (u"࠭ัิษษ่๋ࠥๆࠡษ็้อืๅอࠢศ่๎ࠦๅิฬัำ๊๐ࠠศๆหี๋อๅอࠩ䃷"),l1llll11ll1l_l1_,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ䃸"))
			l1ll11111l1l_l1_ = l11lll_l1_ (u"ࠨࡑࡏࡈࠬ䃹")
	if l1ll11111l1l_l1_!=l11l111l11l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䃺"),l1ll11111l1l_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䃻"))
	return l1ll11111l1l_l1_
def l11l1ll1ll_l1_(url,l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬ䃼")):
	l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࡜࠯ࡣࡹ࡭ࢁࡢ࠮ࡵࡵࡿࡠ࠳ࡧࡡࡤࡾ࡟࠲ࡲࡶ࠴ࡽ࡞࠱ࡱ࠸ࡻࡼ࡝࠰ࡰ࠷ࡺ࠾ࡼ࡝࠰ࡰࡴࡩࢂ࡜࠯࡯࡮ࡺࢁࡢ࠮ࡧ࡮ࡹࢀࡡ࠴࡭ࡱ࠵ࡿࡠ࠳ࡽࡥࡣ࡯ࠬࠬࢁࡢ࠿࠯ࠬࡂࢀ࠴ࡢ࠿࠯ࠬࡂࢀࡡࢂ࠮ࠫࡁࠬࠨࠬ䃽"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111lll11l_l1_: l111lll11l_l1_ = l111lll11l_l1_[0][0]
	else: l111lll11l_l1_ = l11lll_l1_ (u"࠭ࠧ䃾")
	return l111lll11l_l1_
	#elif not l111lll11l_l1_ and l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ䃿") in l1l1ll11_l1_: l111lll11l_l1_ = l11lll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䄀")
	#elif not l111lll11l_l1_ and l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ䄁") in l1l1ll11_l1_: l111lll11l_l1_ = l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ䄂")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l1l1111ll1_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l1l1111ll1_l1_ = False
	l111llllll_l1_ = time.time()
	if l1l1l1111ll1_l1_: resp = l111llllll_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ䄃"),l11lll_l1_ (u"ࠬ࠭䄄"),l11lll_l1_ (u"࠭ࠧ䄅"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䄆"),l11lll_l1_ (u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧ䄇"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11lll_l1_ (u"ࠩ࠱ࡨࡧ࠭䄈")) and l11lll_l1_ (u"ࠪࡨࡦࡺࡡࠨ䄉") in filename:
				l1l1ll111l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l1111l1l1_l1_(l1l1ll111l_l1_)
				except: return
				cc.execute(l11lll_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧ䄊"))
				cc.execute(l11lll_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨ䄋"))
				cc.execute(l11lll_l1_ (u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧ䄌"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䄍"),l11lll_l1_ (u"ࠨࠩ䄎"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䄏"),l11lll_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ䄐"))
	return
def l1l1lll1ll1l_l1_(word):
	if l11lll_l1_ (u"ࠫࡠ࠭䄑") in word and l11lll_l1_ (u"ࠬࡣࠧ䄒") in word:
		l111ll1l1l1_l1_ = [l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䄓"),l11lll_l1_ (u"ࠧ࡜࠱ࡕࡘࡑࡣࠧ䄔"),l11lll_l1_ (u"ࠨ࡝࠲ࡐࡊࡌࡔ࡞ࠩ䄕"),l11lll_l1_ (u"ࠩ࡞࠳ࡗࡏࡇࡉࡖࡠࠫ䄖"),l11lll_l1_ (u"ࠪ࡟࠴ࡉࡅࡏࡖࡈࡖࡢ࠭䄗"),l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ䄘"),l11lll_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ䄙"),l11lll_l1_ (u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ䄚"),l11lll_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ䄛")]
		l1l1l11l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢ࠱࠮ࡄࡢ࡝ࠨ䄜"),word,re.DOTALL)
		l111l1l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠴ࠪࡀ࡞ࡠࠫ䄝"),word,re.DOTALL)
		l1l1l1l11l11_l1_ = l111ll1l1l1_l1_+l1l1l11l11ll_l1_+l111l1l1l1l_l1_
		for tag in l1l1l1l11l11_l1_: word = word.replace(tag,l11lll_l1_ (u"ࠪࠫ䄞"))
	return word
def l1ll1l1l1ll1_l1_(l11l1l1l1ll_l1_,l1lll1l11ll1_l1_,l1ll11l1l1l1_l1_,l1l1ll111ll1_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll11l1l_l1_,l1111ll1111_l1_,l1l11ll1ll1l_l1_ = l11lll_l1_ (u"ࠫࠬ䄟"),0,15000
	l11l1l1l1ll_l1_ = l11l1l1l1ll_l1_.replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭䄠"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠩࠣࠤࠩ䄡"))
	l1l11l11111l_l1_ = PIL.ImageFont.truetype(l1lll1l1ll11_l1_,size=l1lll1l11ll1_l1_)
	l1ll11l1l1l1_l1_ -= l1lll1l11ll1_l1_*2
	txt = PIL.Image.new(l11lll_l1_ (u"ࠧࡓࡉࡅࡅࠬ䄢"),(l1ll11l1l1l1_l1_,99),(255,255,255,0))
	l1lllllll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l1l111l1ll_l1_ in l11l1l1l1ll_l1_.splitlines():
		l1111ll1111_l1_ += l1l1ll111ll1_l1_
		l1lll1l1l1l1_l1_,newline = 0,l11lll_l1_ (u"ࠨࠩ䄣")
		for word in l1l1l111l1ll_l1_.split(l11lll_l1_ (u"ࠩࠣࠫ䄤")):
			l1lllll1l111_l1_ = l1l1lll1ll1l_l1_(l11lll_l1_ (u"ࠪࠤࠬ䄥")+word)
			l1l1l1l1l11l_l1_,l1lllll1llll_l1_ = l1lllllll1ll_l1_.textsize(l1lllll1l111_l1_,font=l1l11l11111l_l1_)
			if l1lll1l1l1l1_l1_+l1l1l1l1l11l_l1_<l1ll11l1l1l1_l1_:
				if not newline: newline += word
				else: newline += l11lll_l1_ (u"ࠫࠥ࠭䄦")+word
				l1lll1l1l1l1_l1_ += l1l1l1l1l11l_l1_
			else:
				if l1l1l1l1l11l_l1_<l1ll11l1l1l1_l1_:
					newline += l11lll_l1_ (u"ࠬࡢ࡮ࠡࠩ䄧")+word
					l1111ll1111_l1_ += l1l1ll111ll1_l1_
					l1lll1l1l1l1_l1_ = l1l1l1l1l11l_l1_
				else:
					while l1l1l1l1l11l_l1_>l1ll11l1l1l1_l1_:
						for l11l1lllll_l1_ in range(1,len(l11lll_l1_ (u"࠭ࠠࠨ䄨")+word),1):
							l1lllllllll1_l1_ = l11lll_l1_ (u"ࠧࠡࠩ䄩")+word[:l11l1lllll_l1_]
							l11111l1ll_l1_ = word[l11l1lllll_l1_:]
							l1l11l1lll11_l1_ = l1l1lll1ll1l_l1_(l1lllllllll1_l1_)
							l111l1lll1l_l1_,l1llll1l1l11_l1_ = l1lllllll1ll_l1_.textsize(l1l11l1lll11_l1_,font=l1l11l11111l_l1_)
							if l1lll1l1l1l1_l1_+l111l1lll1l_l1_>l1ll11l1l1l1_l1_:
								l1ll111l1ll1_l1_ = l1l1l1l1l11l_l1_-l111l1lll1l_l1_
								newline += l1lllllllll1_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ䄪")
								l1111ll1111_l1_ += l1l1ll111ll1_l1_
								l1l1l1l1l11l_l1_ = l1ll111l1ll1_l1_
								if l1ll111l1ll1_l1_>l1ll11l1l1l1_l1_:
									l1lll1l1l1l1_l1_ = 0
									word = l11111l1ll_l1_
								else:
									l1lll1l1l1l1_l1_ = l1ll111l1ll1_l1_
									newline += l11111l1ll_l1_
								break
				if l1111ll1111_l1_>l1l11ll1ll1l_l1_: break
		l111ll11l1l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ䄫")+newline
		if l1111ll1111_l1_>l1l11ll1ll1l_l1_: break
	l111ll11l1l_l1_ = l111ll11l1l_l1_[1:]
	l111ll11l1l_l1_ = l111ll11l1l_l1_.replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠭䄬"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ䄭"))
	return l111ll11l1l_l1_
def l1111lllll1_l1_(text):
	text = text.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䄮"),l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ䄯"))
	text = text.replace(l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭䄰"),l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ䄱"))
	text = text.replace(l11lll_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ䄲"),l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ䄳"))
	text = text.replace(l11lll_l1_ (u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ䄴"),l11lll_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ䄵"))
	text = text.replace(l11lll_l1_ (u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ䄶"),l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ䄷"))
	text = text.replace(l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䄸"),l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ䄹"))
	l1ll1ll1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ䄺"),text,re.DOTALL)
	for l1ll1111llll_l1_ in l1ll1ll1l1l1_l1_: text = text.replace(l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ䄻")+l1ll1111llll_l1_+l11lll_l1_ (u"ࠬࡣࠧ䄼"),l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ䄽")+l1ll1111llll_l1_+l11lll_l1_ (u"ࠧࡠࠩ䄾"))
	return text
def l1l11ll1l111_l1_(l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text,profile,l111ll111l1_l1_,l1ll11111111_l1_,l1l1ll1lll1l_l1_):
	l1lll111l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ䄿"))
	if l1lll111l11l_l1_:
		results = LANGUAGE_TRANSLATE([l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text])
		if results: l1llll1l1ll1_l1_,l1l1l11l1111_l1_,l1llll1ll1ll_l1_,header,text = results
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䅀"))
		header = header.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䅁"))
		l1llll1l1ll1_l1_ = l1llll1l1ll1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䅂"))
		l1l1l11l1111_l1_ = l1l1l11l1111_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䅃"))
		l1llll1ll1ll_l1_ = l1llll1ll1ll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䅄"))
	l1llllll11ll_l1_ = 5
	l1l111llll1l_l1_ = 20
	l1ll1l11l1l1_l1_ = 20
	l1ll111ll1ll_l1_ = 0
	l11l1l1lll1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䅅")
	l1l11ll111l1_l1_ = 0
	l1l11llll111_l1_ = 19
	l1111l1llll_l1_ = 30
	l1ll1l1111ll_l1_ = 8
	l1ll111l11ll_l1_ = True
	l1l1l11l111l_l1_ = 375
	l1l11l11l11l_l1_ = 410
	l1l1ll1l1ll1_l1_ = 50
	l1l1ll11l111_l1_ = 280
	l1llll11l1ll_l1_ = 28
	l1l11l1ll1ll_l1_ = 5
	l1lll11ll111_l1_ = 0
	l1ll11l1l11l_l1_ = 31
	l111111llll_l1_ = [36,32,28]
	if profile in [l11lll_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ䅆"),l11lll_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ䅇")]:
		if profile==l11lll_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ䅈"):
			l11l1l1l111_l1_ = l11lll_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ䅉")
			l11l1l1lll1_l1_ = l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䅊")
			l1ll111l11ll_l1_ = True
			l1ll111ll1ll_l1_ = 10
		else:
			l11l1l1l111_l1_ = 97+20
			l11l1l1lll1_l1_ = l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ䅋")
			l1ll111l11ll_l1_ = False
		l111111llll_l1_ = [33,33,33]
		l1ll1l11l1l1_l1_ = 20
		l1l111llll1l_l1_ = 0
		l1111l1llll_l1_ = 20
		l1l11llll111_l1_ = 25+10
	elif profile==l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ䅌"): l111111llll_l1_ = [28,24,20] ; l11l1l1l111_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭䅍"): l111111llll_l1_ = [32,28,24] ; l11l1l1l111_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ䅎"): l111111llll_l1_ = [36,32,28] ; l11l1l1l111_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䅏"): l11l1l1l111_l1_ = 740
	elif profile==l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ䅐"): l11l1l1l111_l1_ = l11lll_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ䅑")
	elif profile==l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ䅒"): l111111llll_l1_ = [28,23,18] ; l11l1l1l111_l1_ = 740
	elif profile==l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ䅓"): l111111llll_l1_ = [28,23,18] ; l11l1l1l111_l1_ = l11lll_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ䅔")
	l1lll1l111ll_l1_ = l111111llll_l1_[0]
	l11111lllll_l1_ = l111111llll_l1_[1]
	l11l1l1111l_l1_ = l111111llll_l1_[2]
	l1lll1l1ll1l_l1_ = PIL.ImageFont.truetype(l1lll1l1ll11_l1_,size=l1lll1l111ll_l1_)
	l1ll1l1l1111_l1_ = PIL.ImageFont.truetype(l1lll1l1ll11_l1_,size=l11111lllll_l1_)
	l1ll1ll1l11l_l1_ = PIL.ImageFont.truetype(l1lll1l1ll11_l1_,size=l11l1l1111l_l1_)
	txt = PIL.Image.new(l11lll_l1_ (u"ࠩࡕࡋࡇࡇࠧ䅕"),(100,100),(255,255,255,0))
	l1lllllll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	l1lllll1l1ll_l1_,l1l1llll1111_l1_ = l1lllllll1ll_l1_.textsize(l11lll_l1_ (u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬ䅖"),font=l1ll1l1l1111_l1_)
	l1l1l111ll1l_l1_,l1llll1l111l_l1_ = l1lllllll1ll_l1_.textsize(l11lll_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭䅗"),font=l1lll1l1ll1l_l1_)
	l1l11ll11l11_l1_ = header.count(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䅘"))+1
	l1l1lll1111l_l1_ = l1l111llll1l_l1_+l1l11ll11l11_l1_*(l1llll1l111l_l1_+l1ll111ll1ll_l1_)-l1ll111ll1ll_l1_
	l1l11ll1lll1_l1_ = {l11lll_l1_ (u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡨࡢࡴࡤ࡯ࡦࡺࠧ䅙"):False,l11lll_l1_ (u"ࠧࡴࡷࡳࡴࡴࡸࡴࡠ࡮࡬࡫ࡦࡺࡵࡳࡧࡶࠫ䅚"):True,l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࠡࡎࡌࡋࡆ࡚ࡕࡓࡇࠣࡅࡑࡒࡁࡉࠩ䅛"):False}
	l111l1ll1l1_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l11ll1lll1_l1_)
	if text:
		l11l11lllll_l1_ = l1ll11111111_l1_-l1111l1llll_l1_*2
		l1l11lll1ll1_l1_ = l1l1llll1111_l1_+l1ll1l1111ll_l1_
		l1ll11111lll_l1_ = l111l1ll1l1_l1_.reshape(text)
		if l1ll111l11ll_l1_:
			l1l1111lllll_l1_ = l1ll1l1l1ll1_l1_(l1ll11111lll_l1_,l11111lllll_l1_,l11l11lllll_l1_,l1l11lll1ll1_l1_)
			l1lll11111ll_l1_ = l1l1lll1ll1l_l1_(l1l1111lllll_l1_)
			l1ll111111l1_l1_ = l1lll11111ll_l1_.count(l11lll_l1_ (u"ࠩ࡟ࡲࠬ䅜"))+1
			if l1ll111111l1_l1_<6:
				#l1l1l11l1l11_l1_ = int(0.8*l11l11lllll_l1_) if l1ll111111l1_l1_<4 else int(0.9*l11l11lllll_l1_)
				l1l1l11l1l11_l1_ = l11l11lllll_l1_
				l1l1111lllll_l1_ = l1ll1l1l1ll1_l1_(l1ll11111lll_l1_,l11111lllll_l1_,l1l1l11l1l11_l1_,l1l11lll1ll1_l1_)
				l1lll11111ll_l1_ = l1l1lll1ll1l_l1_(l1l1111lllll_l1_)
				l1ll111111l1_l1_ = l1lll11111ll_l1_.count(l11lll_l1_ (u"ࠪࡠࡳ࠭䅝"))+1
			l111llll11l_l1_ = l1l11llll111_l1_+l1ll111111l1_l1_*l1l11lll1ll1_l1_-l1ll1l1111ll_l1_
		else:
			l111llll11l_l1_ = l1l11llll111_l1_+l1l1llll1111_l1_
			l1lll11111ll_l1_ = l1ll11111lll_l1_.split(l11lll_l1_ (u"ࠫࡡࡴࠧ䅞"))[0]
			l1l1111lllll_l1_ = l1ll11111lll_l1_.split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䅟"))[0]
	else: l111llll11l_l1_ = l1l11llll111_l1_
	l1ll11l1111l_l1_ = l1lll11ll111_l1_+l1ll11l1l11l_l1_
	if l1l1ll1lll1l_l1_:
		l1l1l1ll11l1_l1_ = l1l11l11l11l_l1_-l1l1l11l111l_l1_
		l1ll11l1111l_l1_ += l1l1l1ll11l1_l1_
	else: l1l1l1ll11l1_l1_ = 0
	if l1llll1l1ll1_l1_ or l1l1l11l1111_l1_ or l1llll1ll1ll_l1_: l1ll11l1111l_l1_ += l1l1ll1l1ll1_l1_
	if l11l1l1l111_l1_!=l11lll_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ䅠"): l111111l1l1_l1_ = l11l1l1l111_l1_
	else: l111111l1l1_l1_ = l1l1lll1111l_l1_+l111llll11l_l1_+l1ll11l1111l_l1_
	l1ll1lll1lll_l1_ = l111111l1l1_l1_-l1l1lll1111l_l1_-l1ll11l1111l_l1_-l1l11llll111_l1_
	txt = PIL.Image.new(l11lll_l1_ (u"ࠧࡓࡉࡅࡅࠬ䅡"),(l1ll11111111_l1_,l111111l1l1_l1_),(255,255,255,0))
	l1lllllll1ll_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l1l11l1111_l1_ and l1llll1l1ll1_l1_ and l1llll1ll1ll_l1_:
		l1llll11l1ll_l1_ += 105
		l1l11l1ll1ll_l1_ -= 110
	if header:
		l1llllll1l11_l1_ = l1l111llll1l_l1_
		header = bidi.algorithm.get_display(l111l1ll1l1_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1ll1111l1ll_l1_ = l1lllllll1ll_l1_.textsize(line,font=l1lll1l1ll1l_l1_)
				if l11l1l1lll1_l1_==l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䅢"): l1l1l11ll11l_l1_ = l1llllll11ll_l1_+(l1ll11111111_l1_-width)/2
				elif l11l1l1lll1_l1_==l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ䅣"): l1l1l11ll11l_l1_ = l1llllll11ll_l1_+l1ll11111111_l1_-width-l1ll1l11l1l1_l1_
				elif l11l1l1lll1_l1_==l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ䅤"): l1l1l11ll11l_l1_ = l1llllll11ll_l1_+l1ll1l11l1l1_l1_
				l1lllllll1ll_l1_.text((l1l1l11ll11l_l1_,l1llllll1l11_l1_),line,font=l1lll1l1ll1l_l1_,fill=l11lll_l1_ (u"ࠫࡾ࡫࡬࡭ࡱࡺࠫ䅥"))
			l1llllll1l11_l1_ += l1lll1l111ll_l1_+l1ll111ll1ll_l1_
	if l1llll1l1ll1_l1_ or l1l1l11l1111_l1_ or l1llll1ll1ll_l1_:
		l1llll11ll11_l1_ = l1l1lll1111l_l1_+l1ll1lll1lll_l1_+l1l11llll111_l1_+l1l1l1ll11l1_l1_+l1lll11ll111_l1_
		if l1llll1l1ll1_l1_:
			l1llll1l1ll1_l1_ = bidi.algorithm.get_display(l111l1ll1l1_l1_.reshape(l1llll1l1ll1_l1_))
			l1l1llll1l1l_l1_,l1111111ll1_l1_ = l1lllllll1ll_l1_.textsize(l1llll1l1ll1_l1_,font=l1ll1ll1l11l_l1_)
			l111111lll1_l1_ = l1llll11l1ll_l1_+0*(l1l11l1ll1ll_l1_+l1l1ll11l111_l1_)+(l1l1ll11l111_l1_-l1l1llll1l1l_l1_)/2
			l1lllllll1ll_l1_.text((l111111lll1_l1_,l1llll11ll11_l1_),l1llll1l1ll1_l1_,font=l1ll1ll1l11l_l1_,fill=l11lll_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ䅦"))
		if l1l1l11l1111_l1_:
			l1l1l11l1111_l1_ = bidi.algorithm.get_display(l111l1ll1l1_l1_.reshape(l1l1l11l1111_l1_))
			l1ll1l111l11_l1_,l1ll11l1lll1_l1_ = l1lllllll1ll_l1_.textsize(l1l1l11l1111_l1_,font=l1ll1ll1l11l_l1_)
			l11111llll1_l1_ = l1llll11l1ll_l1_+1*(l1l11l1ll1ll_l1_+l1l1ll11l111_l1_)+(l1l1ll11l111_l1_-l1ll1l111l11_l1_)/2
			l1lllllll1ll_l1_.text((l11111llll1_l1_,l1llll11ll11_l1_),l1l1l11l1111_l1_,font=l1ll1ll1l11l_l1_,fill=l11lll_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭䅧"))
		if l1llll1ll1ll_l1_:
			l1llll1ll1ll_l1_ = bidi.algorithm.get_display(l111l1ll1l1_l1_.reshape(l1llll1ll1ll_l1_))
			l111l11ll11_l1_,l11l1l111l1_l1_ = l1lllllll1ll_l1_.textsize(l1llll1ll1ll_l1_,font=l1ll1ll1l11l_l1_)
			l1lll11l1l1l_l1_ = l1llll11l1ll_l1_+2*(l1l11l1ll1ll_l1_+l1l1ll11l111_l1_)+(l1l1ll11l111_l1_-l111l11ll11_l1_)/2
			l1lllllll1ll_l1_.text((l1lll11l1l1l_l1_,l1llll11ll11_l1_),l1llll1ll1ll_l1_,font=l1ll1ll1l11l_l1_,fill=l11lll_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ䅨"))
	if text:
		l1l111ll1l1l_l1_,l111l1l11ll_l1_ = [],[]
		l1l1111lllll_l1_ = l1111lllll1_l1_(l1l1111lllll_l1_)
		l1l11lll1lll_l1_ = l1l1111lllll_l1_.split(l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ䅩"))
		for l1l11l1l11l1_l1_ in l1l11lll1lll_l1_:
			l111llllll1_l1_ = l111ll111l1_l1_
			if   l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ䅪") in l1l11l1l11l1_l1_: l111llllll1_l1_ = l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ䅫")
			elif l11lll_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ䅬") in l1l11l1l11l1_l1_: l111llllll1_l1_ = l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䅭")
			elif l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ䅮") in l1l11l1l11l1_l1_: l111llllll1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䅯")
			l11l1111ll1_l1_ = l1l11l1l11l1_l1_
			l111ll1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࠯ࠬࡂࡣࠬ䅰"),l1l11l1l11l1_l1_,re.DOTALL)
			for tag in l111ll1l1l1_l1_: l11l1111ll1_l1_ = l11l1111ll1_l1_.replace(tag,l11lll_l1_ (u"ࠩࠪ䅱"))
			if l11l1111ll1_l1_==l11lll_l1_ (u"ࠪࠫ䅲"): width,l1ll1111l1ll_l1_ = 0,l1l11lll1ll1_l1_
			else: width,l1ll1111l1ll_l1_ = l1lllllll1ll_l1_.textsize(l11l1111ll1_l1_,font=l1ll1l1l1111_l1_)
			if   l111llllll1_l1_==l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ䅳"): l1lll1llll1l_l1_ = l1l11ll111l1_l1_+l1111l1llll_l1_
			elif l111llllll1_l1_==l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䅴"): l1lll1llll1l_l1_ = l1l11ll111l1_l1_+l1111l1llll_l1_+l11l11lllll_l1_-width
			elif l111llllll1_l1_==l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䅵"): l1lll1llll1l_l1_ = l1l11ll111l1_l1_+l1111l1llll_l1_+(l11l11lllll_l1_-width)/2
			if l1lll1llll1l_l1_<l1111l1llll_l1_: l1lll1llll1l_l1_ = l1l11ll111l1_l1_+l1111l1llll_l1_
			l1l111ll1l1l_l1_.append(l1lll1llll1l_l1_)
			l111l1l11ll_l1_.append(width)
		l1lll1llll1l_l1_ = l1l111ll1l1l_l1_[0]
		l1l1l11l1ll1_l1_ = l1l1111lllll_l1_.split(l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤ࠭䅶"))
		l11l11l111l_l1_ = (255,255,255,255)
		l1ll1l1l1l1l_l1_ = l11l11l111l_l1_
		l1l11lll1l11_l1_,l1ll11llll11_l1_ = 0,0
		l1lll11l11ll_l1_ = False
		l1lllll111l1_l1_ = 0
		l1l11ll111ll_l1_ = l1l1lll1111l_l1_+l1l11llll111_l1_/2
		if l111llll11l_l1_<(l1ll1lll1lll_l1_+l1l11llll111_l1_):
			l1llllll1111_l1_ = (l1ll1lll1lll_l1_+l1l11llll111_l1_-l111llll11l_l1_)/2
			l1l11ll111ll_l1_ = l1l1lll1111l_l1_+l1l11llll111_l1_+l1llllll1111_l1_-l1l1llll1111_l1_/2
		for line in l1l1l11l1ll1_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1l1l1ll1l_l1_ = line.split(l11lll_l1_ (u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ䅷"),1)
			l1l1l1l1lll1_l1_ = line.split(l11lll_l1_ (u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ䅸"),1)
			l1l1l1l1llll_l1_ = line.split(l11lll_l1_ (u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ䅹"),1)
			l1ll1ll111ll_l1_ = line.split(l11lll_l1_ (u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ䅺"),1)
			l1ll1ll11ll1_l1_ = line.split(l11lll_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ䅻"),1)
			l1ll1ll11lll_l1_ = line.split(l11lll_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ䅼"),1)
			l1l1l1l1ll11_l1_ = line.split(l11lll_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭䅽"),1)
			if len(l1l1l1l1ll1l_l1_)>1:
				l1lllll111l1_l1_ += 1
				line = l1l1l1l1ll1l_l1_[1]
				l1l11lll1l11_l1_ = 0
				l1lll1llll1l_l1_ = l1l111ll1l1l_l1_[l1lllll111l1_l1_]
				l1ll11llll11_l1_ += l1l11lll1ll1_l1_
				l1lll11l11ll_l1_ = False
			elif len(l1l1l1l1lll1_l1_)>1:
				line = l1l1l1l1lll1_l1_[1]
				l1ll1l1l1l1l_l1_ = line[0:8]
				l1ll1l1l1l1l_l1_ = l11lll_l1_ (u"ࠨࠥࠪ䅾")+l1ll1l1l1l1l_l1_[2:]
				line = line[9:]
			elif len(l1l1l1l1llll_l1_)>1:
				line = l1l1l1l1llll_l1_[1]
				l1ll1l1l1l1l_l1_ = l11l11l111l_l1_
			elif len(l1ll1ll111ll_l1_)>1:
				line = l1ll1ll111ll_l1_[1]
				l1lll11l11ll_l1_ = True
				l1l11lll1l11_l1_ = l111l1l11ll_l1_[l1lllll111l1_l1_]
			elif len(l1ll1ll11ll1_l1_)>1:
				line = l1ll1ll11ll1_l1_[1]
			elif len(l1ll1ll11lll_l1_)>1:
				line = l1ll1ll11lll_l1_[1]
			elif len(l1l1l1l1ll11_l1_)>1:
				line = l1l1l1l1ll11_l1_[1]
			if line:
				l1l1ll111lll_l1_ = l1l11ll111ll_l1_+l1ll11llll11_l1_
				line = bidi.algorithm.get_display(line)
				width,l1ll1111l1ll_l1_ = l1lllllll1ll_l1_.textsize(line,font=l1ll1l1l1111_l1_)
				if l1lll11l11ll_l1_: l1l11lll1l11_l1_ -= width
				l1lll1llll11_l1_ = l1lll1llll1l_l1_+l1l11lll1l11_l1_
				l1lllllll1ll_l1_.text((l1lll1llll11_l1_,l1l1ll111lll_l1_),line,font=l1ll1l1l1111_l1_,fill=l1ll1l1l1l1l_l1_)
				if not l1lll11l11ll_l1_: l1l11lll1l11_l1_ += width
				if l1l1ll111lll_l1_>l1ll1lll1lll_l1_+l1l11lll1ll1_l1_: break
	l1lll11111l1_l1_ = l1l111llllll_l1_.replace(l11lll_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ䅿"),l11lll_l1_ (u"ࠪࡣࠬ䆀")+str(time.time())+l11lll_l1_ (u"ࠫࡤ࠭䆁"))
	l1lll11111l1_l1_ = l1lll11111l1_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ䆂"),l11lll_l1_ (u"࠭࡜࡝࡞࡟ࠫ䆃")).replace(l11lll_l1_ (u"ࠧ࠰࠱ࠪ䆄"),l11lll_l1_ (u"ࠨ࠱࠲࠳࠴࠭䆅"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1lll11111l1_l1_)
	return l1lll11111l1_l1_,l111111l1l1_l1_
def l11lll1l111_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l1ll_l1_=True,l1l1llll111l_l1_=True):
	# should l1l111l1111l_l1_ ==l11lll_l1_ (u"ࠩࠪ䆆") l1111l11l1_l1_ not l11l1111ll_l1_ it to l11lll_l1_ (u"ࠪࡲࡴࡺࠧ䆇")
	if allow_redirects==l11lll_l1_ (u"ࠫࠬ䆈"): allow_redirects = True
	if l1ll_l1_==l11lll_l1_ (u"ࠬ࠭䆉"): l1ll_l1_ = True
	if l111ll1l1ll_l1_==l11lll_l1_ (u"࠭ࠧ䆊"): l111ll1l1ll_l1_ = True
	if l1l1llll111l_l1_==l11lll_l1_ (u"ࠧࠨ䆋"): l1l1llll111l_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll111l11l1_l1_ = list(headers.keys())
	if l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䆌") not in l1ll111l11l1_l1_: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䆍")] = l11lll_l1_ (u"ࠪࡄࡅࡆࡓࡌࡋࡓࡣࡍࡋࡁࡅࡇࡕࡄࡅࡆࠧ䆎")
	#if l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䆏") not in l1ll111l11l1_l1_: headers[l11lll_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䆐")] = l11lll_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䆑")
	l11l11l_l1_,l1l11llll1ll_l1_,l1l1llll1l11_l1_,l1l1ll1l1l1l_l1_ = l1l1l111llll_l1_(url)
	l1l111lll1ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ䆒"))
	l1l11ll11lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ䆓"))
	l1l1l111l111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䆔"))
	l1l11l111l1l_l1_ = (l1l11llll1ll_l1_==None and l1l1llll1l11_l1_==None and l1l1ll1l1l1l_l1_==None)
	l1llllll111l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ䆕")]
	l1l11ll1ll11_l1_ = l11l11l_l1_ in l1llllll111l_l1_
	l1llllllll1l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ䆖")]
	l111lll1111_l1_ = l11l11l_l1_ in l1llllllll1l_l1_
	l11111111ll_l1_ = l1l11ll1ll11_l1_ or l111lll1111_l1_
	if l1l11l111l1l_l1_ and l11111111ll_l1_:
		if l1l11ll1ll11_l1_:
			l1ll1lll11l1_l1_ = l1llllll111l_l1_.index(l11l11l_l1_)
			l1lll1lllll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ䆗")][l1ll1lll11l1_l1_]
			l1llll111ll1_l1_ = [l11lll_l1_ (u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ䆘"),l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨ䆙"),l11lll_l1_ (u"ࠨࡇࡐࡅࡎࡒࡓࠨ䆚"),l11lll_l1_ (u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ䆛"),l11lll_l1_ (u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ䆜"),l11lll_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ䆝"),l11lll_l1_ (u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪ䆞"),l11lll_l1_ (u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ䆟")]
			l1llll1llll1_l1_ = l1llll111ll1_l1_[l1ll1lll11l1_l1_]
		elif l111lll1111_l1_:
			l1ll1lll11l1_l1_ = l1llllllll1l_l1_.index(l11l11l_l1_)
			l1lll1lllll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ䆠")][l1ll1lll11l1_l1_]
			l1111l1l11l_l1_ = [l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࠨ䆡"),l11lll_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ䆢"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ䆣")]
			l1llll1llll1_l1_ = l1111l1l11l_l1_[l1ll1lll11l1_l1_]
	if l1l1llll1l11_l1_==l11lll_l1_ (u"ࠫࠬ䆤"): l1l1llll1l11_l1_ = l1l111lll1ll_l1_
	elif l1l1llll1l11_l1_==None and l1l11ll11lll_l1_ in [l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ䆥"),l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䆦")] and l111ll1l1ll_l1_: l1l1llll1l11_l1_ = l1l111lll1ll_l1_
	l1l1llll11l1_l1_ = l11l11l_l1_==l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ䆧")][7]
	if source==l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ䆨"): timeout = 120
	elif source==l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ䆩"): timeout = 20
	elif source==l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ䆪"): timeout = 20
	elif source in l1llllllll11_l1_: timeout = 10
	elif l1l11ll1ll11_l1_ or l111lll1111_l1_: timeout = 15
	elif l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭䆫") in source: timeout = 70
	elif l11lll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ䆬") in source: timeout = 75
	elif l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭䆭") in source: timeout = 25
	elif l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭䆮") in source: timeout = 20
	elif l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ䆯") in source: timeout = 20
	elif l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ䆰") in source: timeout = 20
	elif l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䆱") in source: timeout = 25
	elif l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ䆲") in source: timeout = 30
	else: timeout = 15
	if l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ䆳") in source and not data and l11lll_l1_ (u"࠭ࠦࠨ䆴") not in l11l11l_l1_ and l11lll_l1_ (u"ࠧࡀࠩ䆵") not in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪ䆶"))+l11lll_l1_ (u"ࠩ࠲ࠫ䆷")
	l111lll1l11_l1_ = (l1l11llll1ll_l1_!=None)
	l1l1lll1l111_l1_ = (l1l1llll1l11_l1_!=None and l1l11ll11lll_l1_!=l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ䆸"))
	if l111lll1l11_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧ䆹"),l1l11llll1ll_l1_)
	elif l1l1lll1l111_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ䆺"),l1l1llll1l11_l1_)
	if l111lll1l11_l1_:
		proxies = {l11lll_l1_ (u"ࠨࡨࡵࡶࡳࠦ䆻"):l1l11llll1ll_l1_,l11lll_l1_ (u"ࠢࡩࡶࡷࡴࡸࠨ䆼"):l1l11llll1ll_l1_}
		l1ll1lllllll_l1_ = l1l11llll1ll_l1_
	else: proxies,l1ll1lllllll_l1_ = {},l11lll_l1_ (u"ࠨࠩ䆽")
	if l1l1lll1l111_l1_:
		import urllib3.util.connection as connection
		l11111ll1ll_l1_ = l1l11l1l111l_l1_(connection,l1l111lll1ll_l1_)
	verify = True
	l1lll1lll1l1_l1_,l1lll1l11l11_l1_,l11lll1ll_l1_,l11l1111l1l_l1_,l111lll11l1_l1_ = allow_redirects,source,method,False,False
	if l1l1llll11l1_l1_: l111lll11l1_l1_ = True
	#if l11111111ll_l1_ or (method==l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䆾") and allow_redirects): l1lll1lll1l1_l1_ = False
	if l11111111ll_l1_ or allow_redirects: l1lll1lll1l1_l1_ = False
	if l1l11ll1ll11_l1_: l11lll1ll_l1_ = l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䆿")
	import requests
	code,reason = -1,l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫ䇀")
	for l11l1lllll_l1_ in range(9):
		l1ll1l1l11l1_l1_ = True
		succeeded = False
		try:
			if l11l1lllll_l1_: l1lll1l11l11_l1_ = l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭䇁")
			if not l111lll1l11_l1_: l11llll11l1_l1_(l11lll_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫ䇂"),l11l11l_l1_,data,headers,l1lll1l11l11_l1_,l11lll1ll_l1_)
			try: response.close()
			except: pass
			l11l1l1_l1_ = l11l11l_l1_
			#LOG_THIS(l11lll_l1_ (u"ࠧࠨ䇃"),str(l11lll1ll_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ䇄")+str(l11l11l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭䇅")+str(data)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ䇆")+str(headers)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ䇇")+str(verify)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ䇈")+str(l1lll1lll1l1_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ䇉")+str(timeout)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ䇊")+str(proxies))
			response = requests.request(l11lll1ll_l1_,l11l11l_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll1lll1l1_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l1111l1l_l1_:
					l1lll1111l11_l1_ = list(response.headers.keys())
					if l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䇋") in l1lll1111l11_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䇌")]
					elif l11lll_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ䇍") in l1lll1111l11_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭䇎")]
					else: l11l1111l1l_l1_ = True
					if l11l11l_l1_!=l11l1l1_l1_: l11l11l_l1_ = l11l11l_l1_.encode(l11lll_l1_ (u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭䇏"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭䇐")).decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䇑"),l11lll_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ䇒"))
					if l11111111ll_l1_ and response.status_code==307:
						l1lll1lll1l1_l1_ = allow_redirects
						l11lll1ll_l1_ = method
						l11l1111l1l_l1_ = True
						l1ll1111ll11_l1_
				if not l11l1111l1l_l1_ or allow_redirects:
					if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䇓") not in l11l11l_l1_:
						server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ䇔"))
						l11l11l_l1_ = server+l11lll_l1_ (u"ࠫ࠴࠭䇕")+l11l11l_l1_
				if not l11l1111l1l_l1_ and allow_redirects:
					l111lll11l_l1_ = l11l1ll1ll_l1_(l11l11l_l1_)
					if l111lll11l_l1_ not in [l11lll_l1_ (u"ࠬ࠴ࡡࡷ࡫ࠪ䇖"),l11lll_l1_ (u"࠭࠮ࡵࡵࠪ䇗"),l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ䇘"),l11lll_l1_ (u"ࠨ࠰ࡤࡥࡨ࠭䇙"),l11lll_l1_ (u"ࠩ࠱ࡱࡰࡼࠧ䇚"),l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ䇛"),l11lll_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ䇜")]: l1ll1111ll11_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111lll11l1_l1_ = True
			l11l1l1_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status l1ll1ll11l11_l1_ a log line: l11lll_l1_ (u"ࠧࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࠨ䇝")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l11lll_l1_ (u"࠭࠺ࠡࠩ䇞"))[1]
			else: reason = str(err).split(l11lll_l1_ (u"ࠧ࠻ࠢࠪ䇟"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l11lll_l1_ (u"ࠨࡇࡵࡶࡳࡵࠧ䇠") in error: code,reason = re.findall(l11lll_l1_ (u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦ䇡"),error)[0]
				elif l11lll_l1_ (u"ࠪ࠰ࠥ࡫ࡲࡳࡱࡵࠬࠬ䇢") in error: code,reason = re.findall(l11lll_l1_ (u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䇣"),error)[0]
				elif error.count(l11lll_l1_ (u"ࠬࡀࠧ䇤"))>=2: reason,code = re.findall(l11lll_l1_ (u"࠭࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪࠩ䇥"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1ll1l1l11l1_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䇦"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭䇧")+str(code)+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ䇨")+reason+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ䇩")+source+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ䇪")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ䇫"))
		if l1ll1l1l11l1_l1_ and l11111111ll_l1_ and not l111lll11l1_l1_ and code!=200:
			l11l11l_l1_ = l1lll1lllll1_l1_
			l111lll11l1_l1_ = True
			continue
		if l1ll1l1l11l1_l1_: break
	if l1l1llll1l11_l1_!=None and l1l11ll11lll_l1_!=l11lll_l1_ (u"࠭ࡓࡕࡑࡓࠫ䇬"): connection.create_connection = l11111ll1ll_l1_
	if l1l11ll11lll_l1_==l11lll_l1_ (u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧ䇭") and l111ll1l1ll_l1_: l1l1llll1l11_l1_ = None
	if not succeeded and l1l11llll1ll_l1_==None and source not in l1llllllll11_l1_:
		l1llll1111l1_l1_ = traceback.format_exc()
		sys.stderr.write(l1llll1111l1_l1_)
	l1ll111ll_l1_ = l1l1111ll1l_l1_()
	l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡴࡳࡻ࠽ࠑࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦ࠴࠱ࡶࡦࡽࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡷࡧࡷࠎࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸࠮ࡵࡧࡻࡸࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡷࡩࡽࡺࠍࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩ࠷࠴ࡪࡴࡱࡱࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯࡬ࡶࡳࡳ࠮ࠩࠎࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸࠮ࡩ࡫ࡶࡸࡴࡸࡹࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࡮ࡩࡴࡶࡲࡶࡾࠓࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠳࡫࡬ࡢࡲࡶࡩࡩࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡩࡱࡧࡰࡴࡧࡧࠑࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦ࠴࠱ࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡨࡲࡨࡵࡤࡪࡰࡪࠑࠏࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠒࠐࠉࠣࠤࠥ䇮")
	l1ll111ll_l1_.url = l11l1l1_l1_
	try: content = response.content
	except: content = l11lll_l1_ (u"ࠩࠪ䇯")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䇰"))
		except: pass
	code = int(code)
	l1ll111ll_l1_.code = code
	l1ll111ll_l1_.reason = reason
	l1ll111ll_l1_.content = content
	l1ll111ll_l1_.headers = headers
	l1ll111ll_l1_.cookies = cookies
	l1ll111ll_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1ll111ll_l1_.content,str): l1l11ll1llll_l1_ = l1ll111ll_l1_.content.lower()
	else: l1l11ll1llll_l1_ = l11lll_l1_ (u"ࠫࠬ䇱")
	l1ll1l111111_l1_ = (l11lll_l1_ (u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ䇲") in l1l11ll1llll_l1_ or l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭䇳") in l1l11ll1llll_l1_) and l1l11ll1llll_l1_.count(l11lll_l1_ (u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ䇴"))>2 and l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䇵") not in source and l11lll_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱࠫ䇶") not in l1l11ll1llll_l1_
	if code==200 and l1ll1l111111_l1_: l1ll111ll_l1_.succeeded = False
	if l1ll111ll_l1_.succeeded and l1l11l111l1l_l1_ and l11111111ll_l1_:
		if l1l1llll11l1_l1_: l1llll1llll1_l1_ = l11lll_l1_ (u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫ䇷")+data[l11lll_l1_ (u"ࠫ࡯ࡵࡢࠨ䇸")].upper()
		l1ll111l1_l1_ = l1l111l1111_l1_(l1llll1llll1_l1_)
	if not l1ll111ll_l1_.succeeded and l1l11l111l1l_l1_:
		l1ll11lllll1_l1_ = (l11lll_l1_ (u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ䇹") in l1l11ll1llll_l1_ and l11lll_l1_ (u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨ䇺") in l1l11ll1llll_l1_)
		l1lll1ll1l11_l1_ = (l11lll_l1_ (u"ࠧ࠶ࠢࡶࡩࡨ࠭䇻") in l1l11ll1llll_l1_ and l11lll_l1_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩ䇼") in l1l11ll1llll_l1_)
		l1ll1l11111l_l1_ = (code in [403] and l11lll_l1_ (u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬ䇽") in l1l11ll1llll_l1_)
		l1ll1l1111l1_l1_ = (l11lll_l1_ (u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬ䇾") in l1l11ll1llll_l1_ and l11lll_l1_ (u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨ䇿") in l1l11ll1llll_l1_)
		if   l1ll1l111111_l1_: reason = l11lll_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ䈀")
		elif l1ll11lllll1_l1_: reason = l11lll_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ䈁")
		elif l1lll1ll1l11_l1_: reason = l11lll_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ䈂")
		elif l1ll1l11111l_l1_: reason = l11lll_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩ䈃")
		elif l1ll1l1111l1_l1_: reason = l11lll_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ䈄")
		else: reason = str(reason)
		if source in l1llllllll11_l1_:
			LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ䈅"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭䈆")+str(code)+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭䈇")+reason+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䈈")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䈉")+l11l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ䈊"))
		else: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䈋"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ䈌")+str(code)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭䈍")+reason+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䈎")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䈏")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䈐"))
		l1lll1l1l111_l1_ = l111l_l1_(l11l11l_l1_)
		if kodi_version<19 and isinstance(l1lll1l1l111_l1_,unicode): l1lll1l1l111_l1_ = l1lll1l1l111_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䈑"))
		if l11111111ll_l1_: l1lll1l1l111_l1_ = l1lll1l1l111_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ䈒"))[-1]
		reason = str(reason)+l11lll_l1_ (u"ࠪࡠࡳ࠮ࠠࠨ䈓")+l1lll1l1l111_l1_+l11lll_l1_ (u"ࠫࠥ࠯ࠧ䈔")
		if l1ll1l111111_l1_ or l1ll11lllll1_l1_ or l1lll1ll1l11_l1_ or l1ll1l11111l_l1_ or l1ll1l1111l1_l1_:
			code = -2
			l1ll111ll_l1_.code = code
			l1ll111ll_l1_.reason = reason
		l1ll111ll1_l1_ = True
		if (l1l11ll11lll_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䈕") or l1l1l111l111_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䈖")) and (l111ll1l1ll_l1_ or l1l1llll111l_l1_):
			l1ll111ll1_l1_ = l1ll1l1ll1l1_l1_(code,reason,source,l1ll_l1_)
			if l1ll111ll1_l1_ and l1l11ll11lll_l1_==l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䈗"): l1l11ll11lll_l1_ = l11lll_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ䈘")
			else: l1l11ll11lll_l1_ = l11lll_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ䈙")
			if l1ll111ll1_l1_ and l1l1l111l111_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ䈚"): l1l1l111l111_l1_ = l11lll_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭䈛")
			else: l1l1l111l111_l1_ = l11lll_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ䈜")
			settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䈝"),l1l11ll11lll_l1_)
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ䈞"),l1l1l111l111_l1_)
		if l1ll111ll1_l1_:
			l1lll1lll111_l1_ = True
			if code==8 and l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䈟") in l11l11l_l1_ and l1lll1lll111_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ䈠"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䈡"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ䈢")
				l1ll111l1_l1_ = l11lll1l111_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ䈣"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䈤")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭䈥")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ䈦"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭䈧"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䈨"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䈩"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ䈪")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䈫")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䈬"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫ䈭"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䈮"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l1l111l111_l1_ in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䈯"),l11lll_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭䈰")] and l1l1llll111l_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ䈱"),l11lll_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ䈲"),time=2000)
				l1ll111l1_l1_ = l111ll1ll11_l1_(method,l11l11l_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭䈳"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ䈴")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ䈵")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭䈶"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ䈷"),l11lll_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ䈸"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䈹"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ䈺")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䈻")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䈼"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ䈽"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䈾"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l11ll11lll_l1_ in [l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ䈿"),l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䉀")] and l111ll1l1ll_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩ䉁"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䉂"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ䉃")
				l1ll111l1_l1_ = l11lll1l111_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ䉄"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ䉅")+l1l111lll1ll_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䉆")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䉇")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䉈"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩ䉉"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䉊"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䉋"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ䉌")+l1l111lll1ll_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䉍")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䉎")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䉏"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨ䉐"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䉑"),time=2000)
		if l1l1l111l111_l1_==l11lll_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ䉒") or l1l11ll11lll_l1_==l11lll_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭䉓"): l1ll_l1_ = False
		if not l1ll111ll_l1_.succeeded:
			if l1ll_l1_: l11l111l111_l1_ = l1ll1l1ll1l1_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l1111llll11_l1_ and l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩ䉔") not in source:
				l1lll11l1l11_l1_(l11lll_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬ䉕")+source)
	if settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䉖")) not in [l11lll_l1_ (u"ࠨࡃࡘࡘࡔ࠭䉗"),l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ䉘"),l11lll_l1_ (u"ࠪࡅࡘࡑࠧ䉙")]: settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ䉚"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䉛"))
	if settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䉜")) not in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ䉝"),l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭䉞"),l11lll_l1_ (u"ࠩࡄࡗࡐ࠭䉟")]: settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ䉠"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䉡"))
	return l1ll111ll_l1_
def OPENURL_REQUESTS_CACHED(l11llll1111_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l1ll_l1_=True,l1l1llll111l_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	if l11llll1111_l1_:
		response = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ䉢"),l11lll_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ䉣"),item)
		if response.succeeded:
			l11llll11l1_l1_(l11lll_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ䉤"),url,data,headers,source,method)
			return response
	response = l11lll1l111_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l1ll_l1_,l1l1llll111l_l1_)
	if response.succeeded:
		if l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ䉥") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l11llll1111_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ䉦"),item,response,l11llll1111_l1_)
	return response
def OPENURL_CACHED(l11llll1111_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䉧")
	else:
		method = l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䉨")
		data = l111l_l1_(data)
		dummy,data = l1llll11ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l11llll1111_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䉩"))
	html = str(html)
	return html
def l1l1l111llll_l1_(url):
	l1l1l1111l1l_l1_ = url.split(l11lll_l1_ (u"࠭ࡼࡽࠩ䉪"))
	l11l11l_l1_,l1l11llll1ll_l1_,l1l1llll1l11_l1_,l1l1ll1l1l1l_l1_ = l1l1l1111l1l_l1_[0],None,None,None
	for item in l1l1l1111l1l_l1_:
		if l11lll_l1_ (u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ䉫") in item: l1l11llll1ll_l1_ = item.split(l11lll_l1_ (u"ࠨ࠿ࠪ䉬"))[1]
		elif l11lll_l1_ (u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ䉭") in item: l1l1llll1l11_l1_ = item.split(l11lll_l1_ (u"ࠪࡁࠬ䉮"))[1]
		elif l11lll_l1_ (u"ࠫࡒࡿࡓࡔࡎࡘࡶࡱࡃࠧ䉯") in item: l1l1ll1l1l1l_l1_ = item.split(l11lll_l1_ (u"ࠬࡃࠧ䉰"))[1]
	return l11l11l_l1_,l1l11llll1ll_l1_,l1l1llll1l11_l1_,l1l1ll1l1l1l_l1_
def RESTORE_PATH_NAME(name):
	start,l1l1l1ll1ll_l1_,modified = l11lll_l1_ (u"࠭ࠧ䉱"),l11lll_l1_ (u"ࠧࠨ䉲"),l11lll_l1_ (u"ࠨࠩ䉳")
	name = name.replace(ltr,l11lll_l1_ (u"ࠩࠪ䉴")).replace(rtl,l11lll_l1_ (u"ࠪࠫ䉵"))
	tmp = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫ䉶"),name,re.DOTALL)
	if tmp: start,l1l1l1ll1ll_l1_,name = tmp[0]
	if start not in [l11lll_l1_ (u"ࠬࠦࠧ䉷"),l11lll_l1_ (u"࠭ࠬࠨ䉸"),l11lll_l1_ (u"ࠧࠨ䉹")]: modified = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䉺")
	if l1l1l1ll1ll_l1_: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࡢࠫ䉻")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠪࡣࠬ䉼")
	#datetime = re.findall(l11lll_l1_ (u"ࠫ࠭ࡥ࡜ࡥ࡞ࡧࡠ࠳ࡢࡤ࡝ࡦࡢࡠࡩࡢࡤ࡝࠼࡟ࡨࡡࡪ࡟ࠪࠩ䉽"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11lll_l1_ (u"ࠬ࠭䉾"))
	name = l1l1l1ll1ll_l1_+modified+name
	return name
def l1ll11111l1_l1_(url,l1l1ll11llll_l1_,l1l1lll111ll_l1_,l1ll1ll1lll1_l1_,headers={}):
	l1l111l1l11l_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ䉿"))
	l1111ll111l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ䊀")+l1l1ll11llll_l1_)
	if l1111ll111l_l1_: l11l1l1_l1_ = url.replace(l1l111l1l11l_l1_,l1111ll111l_l1_)
	else:
		l11l1l1_l1_ = url
		l1111ll111l_l1_ = l1l111l1l11l_l1_
	l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䊁"),l11l1l1_l1_,l11lll_l1_ (u"ࠩࠪ䊂"),headers,l11lll_l1_ (u"ࠪࠫ䊃"),l11lll_l1_ (u"ࠫࠬ䊄"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ䊅"))
	html = l1ll111l1_l1_.content
	try: html = html.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䊆"),l11lll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ䊇"))
	except: pass
	if not l1ll111l1_l1_.succeeded or l1ll1ll1lll1_l1_ not in html:
		l11l11l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭䊈")+l1l1lll111ll_l1_
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䊉"):l11lll_l1_ (u"ࠪࠫ䊊")}
		l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䊋"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭䊌"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ䊍"),l11lll_l1_ (u"ࠧࠨ䊎"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬ䊏"))
		if l1ll111ll_l1_.succeeded:
			html = l1ll111ll_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䊐"),l11lll_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ䊑"))
				except: pass
			links = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡶࡴ࡯ࡠࡄࡷ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ䊒"),html,re.DOTALL)
			l1lll1ll1l1l_l1_ = [l1111ll111l_l1_]
			for link in links:
				l1111ll111l_l1_ = SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䊓"))
				if l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯ࠪ䊔") in link: continue
				if l1111ll111l_l1_ in l1lll1ll1l1l_l1_: continue
				if len(l1lll1ll1l1l_l1_)==9:
					LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䊕"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ䊖")+l1l1ll11llll_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ䊗")+l1l111l1l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭䊘"))
					settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭䊙")+l1l1ll11llll_l1_,l11lll_l1_ (u"ࠬ࠭䊚"))
					break
				l1lll1ll1l1l_l1_.append(l1111ll111l_l1_)
				l11l1l1_l1_ = url.replace(l1l111l1l11l_l1_,l1111ll111l_l1_)
				l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䊛"),l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨ䊜"),headers,l11lll_l1_ (u"ࠨࠩ䊝"),l11lll_l1_ (u"ࠩࠪ䊞"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ䊟"))
				html = l1ll111l1_l1_.content
				if l1ll111l1_l1_.succeeded and l1ll1ll1lll1_l1_ in html:
					LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䊠"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ䊡")+l1l1ll11llll_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬ䊢")+l1111ll111l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ䊣")+l1l111l1l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ䊤"))
					settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ䊥")+l1l1ll11llll_l1_,l1111ll111l_l1_)
					break
	return l1111ll111l_l1_,l11l1l1_l1_,l1ll111l1_l1_
def TRANSLATE(text):
	dict = {
	 l11lll_l1_ (u"ࠪࡳࡱࡪࠧ䊦")			:l11lll_l1_ (u"ࠫ็ี๊ๆࠩ䊧")
	,l11lll_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ䊨")		:l11lll_l1_ (u"࠭ๅห๊ๅๅࠬ䊩")
	,l11lll_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ䊪")		:l11lll_l1_ (u"ࠨ็ไๆํีࠧ䊫")
	,l11lll_l1_ (u"ࠩࡪࡳࡴࡪࠧ䊬")			:l11lll_l1_ (u"ࠪะ๏ีࠧ䊭")
	,l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䊮")		:l11lll_l1_ (u"ࠬ็ิๅࠩ䊯")
	,l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊰")		:l11lll_l1_ (u"ࠧๆฮ็ำࠬ䊱")
	,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䊲")		:l11lll_l1_ (u"ࠩไ๎ิ๐่ࠨ䊳")
	,l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䊴")			:l11lll_l1_ (u"ࠫ็์วสࠩ䊵")
	,l11lll_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࠫ䊶")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ䊷")
	,l11lll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭䊸")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬ䊹")
	,l11lll_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࡤࡣࡰࠫ䊺")		:l11lll_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫ䊻")
	,l11lll_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䊼")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬ䊽")
	,l11lll_l1_ (u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨ䊾")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭䊿")
	,l11lll_l1_ (u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫ䋀")	:l11lll_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ䋁")
	,l11lll_l1_ (u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬ䋂")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨ䋃")
	,l11lll_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ䋄")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧ䋅")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ䋆")	:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭䋇")
	,l11lll_l1_ (u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫ䋈")		:l11lll_l1_ (u"้ࠪํู่ࠡษ็ื๏์ๅศࠩ䋉")
	,l11lll_l1_ (u"ࠫ࡭࡫࡬ࡢ࡮ࠪ䋊")		:l11lll_l1_ (u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨ䋋")
	,l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨ䋌")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨ䋍")
	,l11lll_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ䋎")		:l11lll_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫ䋏")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬ䋐")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫ䋑")
	,l11lll_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䋒")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭䋓")
	,l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䋔")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ䋕")
	,l11lll_l1_ (u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬ䋖")	:l11lll_l1_ (u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭䋗")
	,l11lll_l1_ (u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䋘")	:l11lll_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫ䋙")
	,l11lll_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䋚")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧ䋛")
	,l11lll_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ䋜")		:l11lll_l1_ (u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠨ䋝")
	,l11lll_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ䋞")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭䋟")
	,l11lll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧ䋠")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩ䋡")
	,l11lll_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䋢")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦศไำสࠫ䋣")
	,l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䋤")		:l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫ䋥")
	,l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࡶࡹࠫ䋦")		:l11lll_l1_ (u"๋ࠬไโࠩ䋧")
	,l11lll_l1_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ䋨")		:l11lll_l1_ (u"ࠧๆๆไࠫ䋩")
	,l11lll_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䋪")		:l11lll_l1_ (u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ䋫")
	,l11lll_l1_ (u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭䋬")	:l11lll_l1_ (u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩ䋭")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䋮")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ䋯")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ䋰")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ䋱")
	,l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ䋲")		:l11lll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭䋳")
	,l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭䋴")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨ䋵")
	,l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨ䋶")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪ䋷")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨ䋸")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫ䋹")
	,l11lll_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ䋺")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫ䋻")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭䋼")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭䋽")
	,l11lll_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䋾")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ䋿")
	,l11lll_l1_ (u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪ䌀")		:l11lll_l1_ (u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩ䌁")
	,l11lll_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䌂")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬ䌃")
	,l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ䌄")	:l11lll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ䌅")
	,l11lll_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬ䌆")	:l11lll_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪ䌇")
	,l11lll_l1_ (u"ࠪࡪࡴࡹࡴࡢࠩ䌈")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢไ์ุะวࠨ䌉")
	,l11lll_l1_ (u"ࠬࡧࡨࡸࡣ࡮ࠫ䌊")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨ䌋")
	,l11lll_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ䌌")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦแษำๆอࠬ䌍")
	,l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫ䌎")		:l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫ䌏")
	,l11lll_l1_ (u"ࠫࡸ࡮࡯ࡧࡪࡤࠫ䌐")		:l11lll_l1_ (u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧ䌑")
	,l11lll_l1_ (u"࠭ࡢࡳࡵࡷࡩ࡯࠭䌒")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬ䌓")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩ䌔")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩ䌕")
	,l11lll_l1_ (u"ࠪࡰࡦࡸ࡯ࡻࡣࠪ䌖")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢ็หึ๎าศࠩ䌗")
	,l11lll_l1_ (u"ࠬࡿࡡࡲࡱࡷࠫ䌘")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏อโ้ฬࠪ䌙")
	,l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ䌚")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ䌛")
	,l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧ䌜")	:l11lll_l1_ (u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬ䌝")
	,l11lll_l1_ (u"ࠫࡩࡸࡡ࡮ࡣࡶ࠻ࠬ䌞")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣำึอๅศุࠢัࠬ䌟")
	,l11lll_l1_ (u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ䌠")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭䌡")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪ䌢")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪ䌣")
	,l11lll_l1_ (u"ࠪ࡭࡫࡯࡬࡮ࠩ䌤")				:l11lll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ䌥")
	,l11lll_l1_ (u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫ䌦")			:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨ䌧")
	,l11lll_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧ䌨")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭䌩")
	,l11lll_l1_ (u"ࠩࡳࡥࡳ࡫ࡴࠨ䌪")				:l11lll_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠧ䌫")
	,l11lll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䌬")			:l11lll_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨ䌭")
	,l11lll_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬ䌮")			:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬ䌯")
	,l11lll_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ䌰")				:l11lll_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧ䌱")
	,l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠫ䌲")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫ䌳")
	,l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ䌴")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪ䌵")
	,l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䌶")		:l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ䌷")
	,l11lll_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬ䌸")			:l11lll_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬ䌹")
	,l11lll_l1_ (u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨ䌺")	:l11lll_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬ䌻")
	,l11lll_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩ䌼")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨ䌽")
	,l11lll_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫ䌾")		:l11lll_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫ䌿")
	,l11lll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䍀")			:l11lll_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠬ䍁")
	,l11lll_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵࠪ䍂")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ䍃")
	,l11lll_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ䍄"):l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨ䍅")
	,l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䍆")	:l11lll_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪ䍇")
	,l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡷࡳࡵ࡯ࡣࡴࠩ䍈")	:l11lll_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦๅ้ษู๎฾࠭䍉")
	,l11lll_l1_ (u"࠭ࡩࡱࡶࡹࠫ䍊")					:l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䍋")
	,l11lll_l1_ (u"ࠨ࡫ࡳࡸࡻ࠳࡬ࡪࡸࡨࠫ䍌")			:l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭䍍")
	,l11lll_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䍎")			:l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨ䍏")
	,l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡷࡪࡸࡩࡦࡵࠪ䍐")			:l11lll_l1_ (u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬ䍑")
	,l11lll_l1_ (u"ࠧ࡮࠵ࡸࠫ䍒")					:l11lll_l1_ (u"ࠨࡏ࠶࡙ࠬ䍓")
	,l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ䍔")				:l11lll_l1_ (u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭䍕")
	,l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䍖")			:l11lll_l1_ (u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨ䍗")
	,l11lll_l1_ (u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ䍘")			:l11lll_l1_ (u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬ䍙")
	}
	try: result = dict[text.lower()]
	except: result = l11lll_l1_ (u"ࠨࠩ䍚")
	return result
def l1lll11l1l11_l1_(message=l11lll_l1_ (u"ࠩࠪ䍛")):
	l1l1lll11l1l_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11lll_l1_ (u"ࠪ࠾࠴࠭䍜")):
	return _1ll1l11lll1_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l11111l11ll_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠫࠬ䍝"),l11lll_l1_ (u"ࠬ࠶ࠧ䍞"),0]: return l11lll_l1_ (u"࠭ࠧ䍟")
	l1l1l111l_l1_ = int(l1l1l111l_l1_)
	first = l1l1l111l_l1_^l11111l_l1_
	second = l1l1l111l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l1l111l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1l11l1l1ll1_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠧࠨ䍠"),l11lll_l1_ (u"ࠨ࠲ࠪ䍡"),0]: return l11lll_l1_ (u"ࠩࠪ䍢")
	l1l1l111l_l1_ = str(l1l1l111l_l1_)
	result = l11lll_l1_ (u"ࠪࠫ䍣")
	if len(l1l1l111l_l1_)==15:
		first,second,l1lll111l_l1_ = l1l1l111l_l1_[0:4],l1l1l111l_l1_[4:9],l1l1l111l_l1_[9:]
		first = int(first)^l1lll1111_l1_
		second = int(second)^REGULAR_CACHE
		l1lll111l_l1_ = int(l1lll111l_l1_)^l11111l_l1_
		if first==second==l1lll111l_l1_: result = str(first*60)
	return result
def l1l1lll1l11l_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠫࠬ䍤"),l11lll_l1_ (u"ࠬ࠶ࠧ䍥"),0]: return l11lll_l1_ (u"࠭ࠧ䍦")
	l1l1l111l_l1_ = int(l1l1l111l_l1_)+63841823
	first = l1l1l111l_l1_^l11111l_l1_
	second = l1l1l111l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l1l111l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1lll11l111l_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠧࠨ䍧"),l11lll_l1_ (u"ࠨ࠲ࠪ䍨"),0]: return l11lll_l1_ (u"ࠩࠪ䍩")
	l1l1l111l_l1_ = str(l1l1l111l_l1_)
	length = int(len(l1l1l111l_l1_)/3)
	first = int(l1l1l111l_l1_[0:length])^l11111l_l1_
	second = int(l1l1l111l_l1_[length:2*length])^REGULAR_CACHE
	l1lll111l_l1_ = int(l1l1l111l_l1_[2*length:3*length])^l1lll1111_l1_
	result = l11lll_l1_ (u"ࠪࠫ䍪")
	if first==second==l1lll111l_l1_: result = str(int(first)-63841823)
	return result
def l1l1l11ll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11l1ll_l1_(l1l1l1l1l1ll_l1_,l1l1l1l111l1_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ䍫"),l11lll_l1_ (u"ࠬ࠭䍬"),l11lll_l1_ (u"࠭ࠧ䍭"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䍮"),l1l1l1l1l1ll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䍯")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䍰"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1l1l1l1ll_l1_):
		#os.chmod(l1l1l1l1l1ll_l1_,0o777)
		for root,dirs,files in os.walk(l1l1l1l1l1ll_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䍱"),l11lll_l1_ (u"ࠫࠬ䍲"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䍳"),str(err))
					error = True
			if l1l1l1l111l1_l1_:
				for dir in dirs:
					l1l111l11l1l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l111l11l1l_l1_)
					except: pass
		if l1l1l1l111l1_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䍴"),l11lll_l1_ (u"ࠧࠨ䍵"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䍶"),l11lll_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ䍷"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ䍸"),l11lll_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ䍹"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ䍺"))
	return
def l1l1lll11l1l_l1_(l1llll1111l1_l1_=l11lll_l1_ (u"࠭ࠧ䍻")):
	#if l1llll1111l1_l1_:
	#	if l11lll_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ䍼") in l1llll1111l1_l1_:
	#		message  = l1llll1111l1_l1_.split(l11lll_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ䍽"))[1]
	#		LOG_THIS(l11lll_l1_ (u"ࠩࠪ䍾"),l11lll_l1_ (u"ࠪࡊࡔࡘࡃࡆࡆࠣࡉ࡝ࡏࡔࠡࠢࠣࠤ࠳ࠦࠠࠡࠩ䍿")+message)
	#		#sys.stderr.write(l11lll_l1_ (u"ࠫࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕ࠼࡟ࡲࠬ䎀")+message+l11lll_l1_ (u"ࠬࡢ࡮ࡠࠩ䎁"))
	#	else: l11l11l1ll1_l1_(l1llll1111l1_l1_)
	if l1llll1111l1_l1_:
		l1lll111l11l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ䎂"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ䎃"),l11lll_l1_ (u"ࠨࠩ䎄"))
		l11l11l1ll1_l1_(l1llll1111l1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ䎅"),l1lll111l11l_l1_)
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ䎆"))
	if l1l11llll1_l1_==l11lll_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ䎇"): settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ䎈"),l11lll_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ䎉"))
	elif l1l11llll1_l1_==l11lll_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ䎊"): settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ䎋"),l11lll_l1_ (u"ࠩࠪ䎌"))
	if settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ䎍")) not in [l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䎎"),l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ䎏"),l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䎐")]: settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䎑"),l11lll_l1_ (u"ࠨࡃࡖࡏࠬ䎒"))
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䎓")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䎔"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䎕"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䎖")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䎗"),l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䎘"))
	l11l11l1111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ䎙"))
	l1111l1111l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ䎚"))
	if l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䎛") in str(l1111l1111l_l1_) and l11l11l1111_l1_ in [l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ䎜"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ䎝")]:
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ࠧ䎞"),l11l11l1111_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡗࡪࡺࡖࡪࡧࡺࡑࡴࡪࡥࠩ࠲ࠬࠫ䎟"))
	#l111ll1l111_l1_ = sys.version_info[0]
	#l11111l1ll1_l1_ = sys.version_info[1]
	#if l111ll1l111_l1_==2: python_version = l11lll_l1_ (u"ࠨ࠴࠺ࠫ䎠")
	#else: python_version = str(l111ll1l111_l1_)+str(l11111l1ll1_l1_)
	#l11l1111l11_l1_ = os.path.join(l11lll1llll_l1_,l11lll_l1_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ䎡")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䎢"),l11lll_l1_ (u"ࠫࠬ䎣"),l11lll_l1_ (u"ࠬ࠭䎤"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1llll111111_l1_,l111ll1lll1_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1llll111111_l1_,l111ll1lll1_l1_)
	return
from EXCLUDES import *